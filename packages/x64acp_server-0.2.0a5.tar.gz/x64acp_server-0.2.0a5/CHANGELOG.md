# Changelog

All notable changes to `x64acp-server` (Python) are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Major versions are kept in lockstep with `@x64acp/client` and `@x64acp/server` (Node).
Any breaking change in any of the three repos bumps all three to the next major together.

## [Unreleased]

## [0.2.0a5] - 2026-04-10

Defense-in-depth: opt-in Socket.IO namespace isolation via `namespace_keys`.

### Added

- `AcpServer(namespace_keys=["organization", "workspace"])` — opt-in
  per-tenant-key Socket.IO namespace isolation. When set, each unique
  combination of those field values becomes its own Socket.IO namespace
  (e.g. `/org_A/ws_X`), giving paranoid multi-tenant SaaS consumers hard
  blast-radius containment on top of the room-join authorization gate.
  Default remains `None` (single namespace `/`) with no behavior change.
- `x64acp.server.namespace` module exposing `derive_namespace_path`,
  `parse_namespace_path`, `validate_namespace_value`, and the
  `NamespaceViolation` exception. Namespace values are constrained to
  `[A-Za-z0-9._-]{1,32}` (no slashes, no whitespace).
- `AcpServer.namespace_for_thread(thread) -> str | None` and
  `AcpServer.enforce_namespace_on_identity(identity)` helpers used by
  the Socket.IO and REST layers.
- Socket.IO layer:
  - `AcpSocketIO` now registers its handlers via an
    `AcpNamespace(socketio.AsyncNamespace)` subclass, bound to `/` in
    single-namespace mode and `*` (wildcard) when `namespace_keys` is
    set, so every dynamically-connected namespace routes to the same
    handler code.
  - Connect handler validates the identity's tenant contains every
    required namespace key with the value parsed from the incoming
    namespace path, and rejects with `ConnectionRefusedError` on
    mismatch.
  - `thread:join`, `message:send`, `assistant:invoke`, and `run:cancel`
    now return `not_found` when the thread's tenant doesn't agree with
    the session namespace on the declared keys, even if the thread
    exists and the identity is tenant-visible under the regular
    `matches()` gate.
- `Broadcaster` protocol methods (`broadcast_event`,
  `broadcast_thread_updated`, `broadcast_members_updated`,
  `broadcast_run_updated`) now accept a keyword-only
  `namespace: str | None = None`. `SocketIOBroadcaster` forwards it to
  `sio.emit(...)` so events land in the right namespace;
  `RecordingBroadcaster` captures it on parallel
  `*_with_namespace` lists. Default `None` preserves pre-namespace
  behavior.
- `AcpServer.publish_event(event, *, thread=None)` gained the optional
  `thread` kwarg so the broadcaster can compute the namespace without
  an extra store round-trip. All in-repo callers (REST handlers,
  `RunExecutor._drive`, Socket.IO `on_message_send`) now pass the
  thread they already have in hand.
- REST gates (symmetric with the WS connect gate):
  - `POST /threads` returns 400 when `namespace_keys` is configured
    and the posted tenant is missing any required key.
  - `resolve_identity` dependency raises 403 after authentication if
    the authenticated identity's tenant is missing any required key.
- Tests: ~25 new tests covering namespace path helpers (~21), Socket.IO
  connect and thread-level enforcement (4 integration), REST gates
  (2 integration). Total suite grows from 96 → 141.
- `uv run poe dev` task: full sanity check (`check + typecheck + test`).
- `uv run poe build` task: build wheel + sdist via `python -m build`.
- `build` package added to dev deps.
- `authorize` callback wired end-to-end across REST and Socket.IO
  surfaces; `ctx.invoke` chaining; configurable `replay_cap` on
  `thread:join` resume.
- Consumer-facing `README.md` rewrite.

### Changed

- `RecordingBroadcaster` adds parallel
  `events_with_namespace` / `threads_updated_with_namespace` /
  `members_updated_with_namespace` / `runs_updated_with_namespace`
  lists. The original attributes (`events`, `threads_updated`, etc.)
  are unchanged, so existing tests continue to work.
- `pyproject.toml` version bumped from `0.2.0a0` (drifted since
  `0.2.0a1`) directly to `0.2.0a5`, which also rolls up the four
  post-`v0.2.0a3` HEAD commits (README rewrite, authorize wiring,
  docker-compose cleanup, poe dev/build tasks).
- `tests/conftest.py` `DATABASE_URL` now defaults to the bundled
  `docker-compose.test.yml` service
  (`postgresql://x64acp:x64acp@localhost:55432/x64acp_test`). Override the env
  var to point at your own Postgres if you'd rather wire one yourself.
- `CLAUDE.md` updated with the new task list and both test-database options
  (docker-compose vs custom `DATABASE_URL`).
- Code reformatted: `ruff format .` collapsed many multi-line function bodies
  and string literals onto single lines (no logic changes).

### Notes

- `namespace_keys` does **not** replace the existing
  `matches(thread.tenant, identity.tenant)` subset-match check or the
  explicit membership check. Both still run. The namespace layer is
  additive blast-radius containment.
- The room-join authorization gate remains authoritative for default
  consumers. Consumers who do not set `namespace_keys` see exactly the
  same behavior as `0.2.0a3`.
- Value constraint `[A-Za-z0-9._-]{1,32}` is intentionally strict.
  Consumers with fancier identifiers should map them into a safe form
  inside `authenticate` before writing them to `identity.metadata.tenant`.
- The `namespace_keys` list is frozen at `AcpServer` construction —
  runtime mutation is not supported.
- Node mirror of this feature is a follow-up. The React client
  requires no changes for this slice — consumers pass the
  namespace-derived URL through the provider's `url` prop themselves.
- Plan document: `docs/plans/2026-04-10-namespace-keys-defense-in-depth.md`.

## [0.2.0a3] - 2026-04-10

Slice 3 complete: Socket.IO transport, live event broadcast, resume cursor.

### Changed (BREAKING)

- **`AuthenticateCallback` signature** changed from
  `Callable[[dict], Awaitable[Identity | None]]` to
  `Callable[[HandshakeData], Awaitable[Identity | None]]`. `HandshakeData` is a
  Pydantic model with `headers: dict[str, str]` (lowercased) and
  `auth: dict[str, Any]` (populated from Socket.IO connect-time auth payload,
  empty dict for REST requests).

  **Migration:**

  ```python
  # before (slice 2):
  async def auth(headers: dict[str, Any]) -> Identity | None:
      token = headers.get("authorization")
      ...

  # after (slice 3):
  from x64acp.server.auth import HandshakeData

  async def auth(handshake: HandshakeData) -> Identity | None:
      token = handshake.headers.get("authorization")
      socket_auth_payload = handshake.auth  # only populated for WS connects
      ...
  ```

  This change unifies REST and Socket.IO authentication under a single callback
  the consumer provides.

### Added

- `x64acp.broadcast.protocol.Broadcaster`: Protocol with four methods
  (`broadcast_event`, `broadcast_thread_updated`, `broadcast_members_updated`,
  `broadcast_run_updated`).
- `x64acp.broadcast.recording.RecordingBroadcaster`: in-memory implementation
  for tests; records every emitted broadcast in lists.
- `x64acp.broadcast.socketio.SocketIOBroadcaster`: emits to Socket.IO rooms
  (`thread:<id>`) via the `event`, `thread:updated`, `members:updated`,
  `run:updated` event names.
- `x64acp.server.auth.HandshakeData`: Pydantic model unifying REST headers and
  Socket.IO auth payload.
- `AcpServer.publish_event(event)`: single funnel — `store.append_event` +
  optional broadcast. **All event appends now go through this method**, including
  the run executor's lifecycle events and yielded handler events. Slice 1+2
  REST handlers refactored to use it.
- `AcpServer.publish_thread_updated`, `publish_members_updated`,
  `publish_run_updated`: matching funnels for the other broadcast channels.
- `RunExecutor` constructor accepts a `publish_event` callable; defaults to
  `store.append_event` for back-compat in tests, and is wired to
  `AcpServer.publish_event` when constructed via `AcpServer`.
- `x64acp.socketio.server.AcpSocketIO`: full Socket.IO server with event handlers
  for `connect` (binds identity to session via `authenticate` callback),
  `disconnect`, `thread:join` (with optional `since` cursor for resume, capped
  at 500 events), `thread:leave`, `message:send`, `assistant:invoke`,
  `run:cancel`. All gated by tenant subset-match + membership, identical to
  the REST surface.
- `AcpServer.mount_socketio(fastapi_app) -> ASGI3App`: constructs `AcpSocketIO`,
  wires the `SocketIOBroadcaster`, returns the wrapped ASGI app for uvicorn.
- REST: `POST /threads` now publishes `members:updated` after the creator is
  auto-added. `PATCH /threads/:id` publishes both `thread:updated` and
  `thread.tenant_changed` (when tenant changes). `POST/DELETE` member endpoints
  publish `members:updated`.
- Tests: 7 new tests — broadcaster recording (3), live uvicorn integration
  (4) covering subscribe + receive, resume cursor, message:send via socket,
  invoke via socket. Total suite: **96 tests, all passing**.
- Plan document: `docs/plans/2026-04-10-slice-3-socketio-transport.md`.

### Notes

- Dev deps added: `uvicorn>=0.32.0` and `aiohttp>=3.11.0` (the latter is
  required by `socketio.AsyncClient` for the integration test transport).
- The Socket.IO server uses `async_mode="asgi"` and is mounted via
  `socketio.ASGIApp(sio, fastapi_app)`. Consumers run the wrapped app with
  uvicorn (or any ASGI server).

## [0.2.0a2] - 2026-04-10

Slice 2 complete: handler runtime, run lifecycle, invoke endpoint.

### Added

- `x64acp.analytics.collector`: `AnalyticsEvent`, `OnAnalyticsCallback`,
  `AssistantAnalytics` (sidecar telemetry buffered per-run, flushed on run
  completion via consumer-provided callback).
- `x64acp.handler.types.HandlerCallable`: type alias for the consumer's
  `(ctx, send) -> AsyncGenerator[Event, None]` async generator.
- `x64acp.handler.send.HandlerSend`: event factories `message`, `reasoning`,
  `tool_call`, `tool_result` that pre-fill `thread_id`, `run_id`, `author`,
  `created_at`, and a fresh event id.
- `x64acp.handler.context.HandlerContext`: `ctx.thread`, `ctx.run`,
  `ctx.assistant`, `ctx.analytics`, `await ctx.events()`, `await ctx.members()`.
  Handlers read thread state, not "the message that triggered me" — works
  identically for user messages, webhooks, and assistant chains.
- `x64acp.handler.executor.RunExecutor`: drives the full run lifecycle —
  idempotency lookup → concurrency check (advisory + partial unique index as
  authoritative gate) → run row creation → background `asyncio.Task` →
  `run.started` event → handler yields persisted as events → final
  `run.completed` / `run.failed` / `run.cancelled` event with status update.
  Catches `UniqueViolationError` from races and recovers by returning the
  existing active or idempotent run. Catches `TimeoutError` and emits
  `run.failed { code: 'timeout' }`. Catches handler exceptions, emits
  `run.failed { code: 'handler_error' }`, and re-raises so consumer error
  tracking sees the exception. Catches `CancelledError`, emits `run.cancelled`,
  and re-raises. Always flushes analytics on `finally`.
- `x64acp.store.postgres.store.PostgresThreadStore`: 5 new run methods —
  `create_run`, `get_run`, `update_run_status`, `find_run_by_idempotency_key`,
  `find_active_run`. Run partial unique indexes (`runs_active_per_assistant`,
  `runs_idempotency`) verified by tests as the load-bearing concurrency gate.
- `x64acp.server.AcpServer`: constructor gains `on_analytics` and
  `run_timeout_seconds` parameters. Holds a `RunExecutor`. Handler registration
  via `@acp.assistant("id")` decorator and `acp.register_assistant(id, handler)`.
- REST: `POST /threads/:id/invocations` accepts `{ assistant_ids: string[],
  idempotency_key?, options? }` and returns `{ runs: Run[] }`. Each entry in
  `assistant_ids` spawns its own independent run in parallel. Gates: tenant
  match, caller membership, every assistant must be registered AND a member of
  the thread (with `role: 'assistant'`).
- REST: `GET /runs/:id` and `DELETE /runs/:id` (cancellation). Both gated by
  tenant match + caller membership of the run's thread.
- Tests: 26 new tests covering run storage CRUD, partial unique race
  invariants, send factories, analytics, the full executor matrix (happy path,
  exception, timeout, cancellation, idempotency, concurrent invoke), the
  invoke REST endpoint, and an end-to-end "user sends + assistant reads
  history + reasons + tool-calls + responds" scenario.
- Plan document: `docs/plans/2026-04-10-slice-2-handlers-and-runs.md`.

### Changed

- `.gitignore`: removed `/docs/plans` (inherited from v1). Plans and the design
  doc are load-bearing artifacts referenced by `CLAUDE.md` and should be tracked.

## [0.2.0a1] - 2026-04-10

Slice 1 complete: Python server REST + storage layer.

### Added

- `x64acp.server.AcpServer`: constructor accepts `store` (ThreadStore),
  `authenticate` callback, optional `authorize` callback. Exposes `.router` for
  mounting onto FastAPI apps. Uses `app.state.acp` for dependency resolution.
- `x64acp.server.auth`: `AuthenticateCallback` and `AuthorizeCallback` type aliases.
- `x64acp.server.rest.deps`: FastAPI dependencies (`get_server`, `resolve_identity`,
  `identity_tenant`).
- REST: `POST /threads` (creator auto-added as member), `GET /threads`
  (tenant-filtered list), `GET /threads/:id`, `PATCH /threads/:id` (emits
  `thread.tenant_changed` event when tenant changes), `DELETE /threads/:id`
  (cascades events and members via FK).
- REST: `POST /threads/:id/messages` (appends a `MessageEvent`),
  `GET /threads/:id/events` (paginated event history).
- REST: `GET /threads/:id/members`, `POST /threads/:id/members`,
  `DELETE /threads/:id/members/:identity_id`. `add_member` is idempotent.
- All per-thread routes gated by tenant subset-match (returns 404 to avoid info
  leak) plus explicit membership check (returns 403). The thread creator is the
  only initial member; consumers add others via the members endpoint.
- Slice 1 reads identity tenant from `identity.metadata['tenant']`. Slice 2 may
  promote `tenant` to a top-level field on Identity.
- End-to-end test: full two-user chat scenario through REST surface.
- Test infrastructure: `docker-compose.test.yml` (Postgres 16 on port 55432) and
  `tests/conftest.py` with session-scoped `pg_pool` and per-test `clean_db`
  fixtures. `pyproject.toml` configured with session-scoped event loop.
- `x64acp.protocol.identity`: `UserIdentity`, `AssistantIdentity`, `SystemIdentity`
  with `role` discriminator and `parse_identity()` for raw dispatch.
- `x64acp.protocol.tenant`: `TenantScope` type alias and `matches()` subset
  predicate for visibility filtering.
- `x64acp.protocol.content`: `TextPart`, `ImagePart`, `AudioPart`, `DocumentPart`,
  `FormPart` (URL-only binaries; form schema aliased to `json_schema` in Python
  to avoid Pydantic shadow, serialized as `schema` on the wire).
- `x64acp.protocol.thread`: `Thread`, `ThreadMember`, `ThreadPatch`.
- `x64acp.protocol.run`: `Run`, `RunStatus`, `RunError`.
- `x64acp.store.protocol.ThreadStore`: storage contract (threads, events, runs,
  members) with `Page[T]`, `ThreadCursor`, `EventCursor` pagination types.
- `x64acp.store.postgres.schema.sql`: Postgres reference schema with GIN tenant
  index, partial unique indexes for run idempotency and per-assistant concurrency,
  indexed `(thread_id, created_at, id)` for event cursor pagination.
- `x64acp.store.postgres.store.PostgresThreadStore`: asyncpg-backed reference
  implementation of the ThreadStore protocol covering threads (CRUD + tenant
  subset-match listing), events (append, get, list with cursor + type filter),
  and members (add idempotent, remove, list, is_member).
- `x64acp.protocol.event`: full Event discriminated union (12 variants:
  `MessageEvent`, `ReasoningEvent`, `ToolCallEvent`, `ToolResultEvent`,
  `ThreadCreatedEvent`, `ThreadMemberAddedEvent`, `ThreadMemberRemovedEvent`,
  `ThreadTenantChangedEvent`, `RunStartedEvent`, `RunCompletedEvent`,
  `RunFailedEvent`, `RunCancelledEvent`), `EventDraft`, and `parse_event()`.
- Initial scaffold (tooling copied from `x64acp-server-v1`).
- Design document at `docs/plans/2026-04-09-x64acp-v2-design.md`.

## [0.2.0a0] - 2026-04-09

Initial alpha. Empty `src/x64acp/`. See design doc for the architecture this
version will implement: `docs/plans/2026-04-09-x64acp-v2-design.md`.
