from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("x64acp-server")

from x64acp_server.analytics.collector import (
    AnalyticsEvent,
    AssistantAnalytics,
    OnAnalyticsCallback,
)
from x64acp_server.broadcast.protocol import Broadcaster
from x64acp_server.broadcast.recording import RecordingBroadcaster
from x64acp_server.broadcast.socketio import SocketIOBroadcaster
from x64acp_server.handler.context import HandlerContext
from x64acp_server.handler.send import HandlerSend
from x64acp_server.handler.types import HandlerCallable
from x64acp_server.protocol.content import (
    AudioPart,
    ContentPart,
    DocumentPart,
    FormPart,
    FormStatus,
    ImagePart,
    TextPart,
    parse_content_part,
)
from x64acp_server.protocol.event import (
    Event,
    EventDraft,
    MessageEvent,
    ReasoningEvent,
    RunCancelledEvent,
    RunCompletedEvent,
    RunFailedEvent,
    RunStartedEvent,
    ThreadCreatedEvent,
    ThreadMemberAddedEvent,
    ThreadMemberRemovedEvent,
    ThreadTenantChangedEvent,
    ToolCall,
    ToolCallEvent,
    ToolResult,
    ToolResultEvent,
    parse_event,
)
from x64acp_server.protocol.identity import (
    AssistantIdentity,
    Identity,
    SystemIdentity,
    UserIdentity,
    parse_identity,
)
from x64acp_server.protocol.run import Run, RunError, RunStatus
from x64acp_server.protocol.tenant import TenantScope, matches
from x64acp_server.protocol.thread import Thread, ThreadMember, ThreadPatch
from x64acp_server.server.acp import AcpServer
from x64acp_server.server.auth import AuthenticateCallback, AuthorizeCallback, HandshakeData
from x64acp_server.server.namespace import (
    NamespaceViolation,
    derive_namespace_path,
    parse_namespace_path,
    validate_namespace_value,
)
from x64acp_server.store.postgres.store import PostgresThreadStore
from x64acp_server.store.protocol import ThreadStore
from x64acp_server.store.types import EventCursor, Page, ThreadCursor

__all__ = [
    "AcpServer",
    "AnalyticsEvent",
    "AssistantAnalytics",
    "AssistantIdentity",
    "AudioPart",
    "AuthenticateCallback",
    "AuthorizeCallback",
    "Broadcaster",
    "ContentPart",
    "DocumentPart",
    "Event",
    "EventCursor",
    "EventDraft",
    "FormPart",
    "FormStatus",
    "HandlerCallable",
    "HandlerContext",
    "HandlerSend",
    "HandshakeData",
    "Identity",
    "ImagePart",
    "MessageEvent",
    "NamespaceViolation",
    "OnAnalyticsCallback",
    "Page",
    "PostgresThreadStore",
    "ReasoningEvent",
    "RecordingBroadcaster",
    "Run",
    "RunCancelledEvent",
    "RunCompletedEvent",
    "RunError",
    "RunFailedEvent",
    "RunStartedEvent",
    "RunStatus",
    "SocketIOBroadcaster",
    "SystemIdentity",
    "TenantScope",
    "TextPart",
    "Thread",
    "ThreadCreatedEvent",
    "ThreadCursor",
    "ThreadMember",
    "ThreadMemberAddedEvent",
    "ThreadMemberRemovedEvent",
    "ThreadPatch",
    "ThreadStore",
    "ThreadTenantChangedEvent",
    "ToolCall",
    "ToolCallEvent",
    "ToolResult",
    "ToolResultEvent",
    "UserIdentity",
    "__version__",
    "derive_namespace_path",
    "matches",
    "parse_content_part",
    "parse_event",
    "parse_identity",
    "parse_namespace_path",
    "validate_namespace_value",
]
