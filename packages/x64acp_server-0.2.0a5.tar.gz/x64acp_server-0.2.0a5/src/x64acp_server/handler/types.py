from __future__ import annotations

from collections.abc import AsyncGenerator, Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from x64acp_server.handler.context import HandlerContext
    from x64acp_server.handler.send import HandlerSend
    from x64acp_server.protocol.event import Event

HandlerCallable = Callable[
    ["HandlerContext", "HandlerSend"],
    AsyncGenerator["Event", None],
]
