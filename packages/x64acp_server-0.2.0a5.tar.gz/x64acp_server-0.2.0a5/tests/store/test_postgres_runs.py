from __future__ import annotations

from datetime import UTC, datetime

import asyncpg
import pytest

from x64acp_server.protocol.identity import AssistantIdentity, UserIdentity
from x64acp_server.protocol.run import Run, RunError
from x64acp_server.protocol.thread import Thread
from x64acp_server.store.postgres.store import PostgresThreadStore


@pytest.fixture
async def store(clean_db: asyncpg.Pool) -> PostgresThreadStore:
    s = PostgresThreadStore(pool=clean_db)
    now = datetime.now(UTC)
    await s.create_thread(Thread(id="th_1", tenant={}, metadata={}, created_at=now, updated_at=now))
    return s


def _new_run(id: str = "run_1", idempotency_key: str | None = None) -> Run:
    return Run(
        id=id,
        thread_id="th_1",
        assistant=AssistantIdentity(id="a1", name="Helper"),
        triggered_by=UserIdentity(id="u1", name="Alice"),
        status="pending",
        started_at=datetime.now(UTC),
        idempotency_key=idempotency_key,
    )


async def test_create_and_get_run(store: PostgresThreadStore) -> None:
    created = await store.create_run(_new_run())
    assert created.id == "run_1"
    assert created.status == "pending"

    got = await store.get_run("run_1")
    assert got is not None
    assert got.assistant.id == "a1"


async def test_update_run_status_to_running(store: PostgresThreadStore) -> None:
    await store.create_run(_new_run())
    updated = await store.update_run_status("run_1", "running")
    assert updated.status == "running"
    assert updated.completed_at is None


async def test_update_run_status_to_completed_sets_completed_at(
    store: PostgresThreadStore,
) -> None:
    await store.create_run(_new_run())
    updated = await store.update_run_status("run_1", "completed")
    assert updated.status == "completed"
    assert updated.completed_at is not None


async def test_update_run_status_failed_with_error(store: PostgresThreadStore) -> None:
    await store.create_run(_new_run())
    err = RunError(code="handler_error", message="boom")
    updated = await store.update_run_status("run_1", "failed", error=err)
    assert updated.status == "failed"
    assert updated.error is not None
    assert updated.error.code == "handler_error"


async def test_find_run_by_idempotency_key(store: PostgresThreadStore) -> None:
    await store.create_run(_new_run(idempotency_key="key_1"))
    found = await store.find_run_by_idempotency_key("th_1", "key_1")
    assert found is not None
    assert found.id == "run_1"

    missing = await store.find_run_by_idempotency_key("th_1", "nope")
    assert missing is None


async def test_find_active_run(store: PostgresThreadStore) -> None:
    await store.create_run(_new_run())
    found = await store.find_active_run("th_1", "a1")
    assert found is not None
    assert found.id == "run_1"

    await store.update_run_status("run_1", "completed")
    after = await store.find_active_run("th_1", "a1")
    assert after is None


async def test_concurrency_partial_unique_blocks_second_active(
    store: PostgresThreadStore,
) -> None:
    await store.create_run(_new_run(id="run_1"))
    with pytest.raises(asyncpg.exceptions.UniqueViolationError):
        await store.create_run(_new_run(id="run_2"))


async def test_idempotency_key_partial_unique(store: PostgresThreadStore) -> None:
    await store.create_run(_new_run(id="run_1", idempotency_key="key_a"))
    with pytest.raises(asyncpg.exceptions.UniqueViolationError):
        await store.create_run(_new_run(id="run_2", idempotency_key="key_a"))
