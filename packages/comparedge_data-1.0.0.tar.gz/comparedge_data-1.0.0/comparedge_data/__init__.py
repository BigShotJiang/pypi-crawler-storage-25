"""ComparEdge Data — Open dataset of 331 SaaS, AI & Crypto tools."""
import json
import os

__version__ = "1.0.0"
__homepage__ = "https://comparedge.com"

_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def get_products():
    """Get all 331 software tools with pricing and ratings."""
    with open(os.path.join(_DATA_DIR, "products.json")) as f:
        return json.load(f)

def get_llms():
    """Get all 25 LLM tools."""
    with open(os.path.join(_DATA_DIR, "llm.json")) as f:
        return json.load(f)

def get_benchmarks():
    """Get category benchmarks (28 categories)."""
    with open(os.path.join(_DATA_DIR, "benchmarks.json")) as f:
        return json.load(f)

def get_categories():
    """Get category listing."""
    with open(os.path.join(_DATA_DIR, "categories.json")) as f:
        return json.load(f)
