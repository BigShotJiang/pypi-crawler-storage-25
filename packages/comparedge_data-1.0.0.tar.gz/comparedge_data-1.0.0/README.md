# comparedge-data

Open dataset of **331 SaaS, AI & Crypto tools** with pricing, ratings, and features.

## Install

```bash
pip install comparedge-data
```

## Usage

```python
from comparedge_data import get_products, get_llms, get_benchmarks

// Get all 331 products
products = get_products()  # 331 tools

// Get LLM tools only
llms = get_llms()  # 25 LLM tools

// Get category benchmarks
benchmarks = get_benchmarks()  # 28 categories
```

## Data Included

- **331 software tools** across 28 categories
- **Pricing data** (free plans, starting prices)
- **Ratings** (G2, Capterra, TrustRadius)
- **Features** and comparisons
- **3 verticals**: AI, Business, Crypto

## Links

- **Website**: [comparedge.com](https://comparedge.com)
- **Live Rankings**: [comparedge.com/best](https://comparedge.com/best)
- **Compare Tools**: [comparedge.com/compare](https://comparedge.com/compare)
- **Blog**: [blog.comparedge.com](https://blog.comparedge.com)
- **GitHub**: [github.com/comparedge/awesome-saas-comparison-data](https://github.com/comparedge/awesome-saas-comparison-data)
- **Kaggle**: [kaggle.com/datasets/comparedge](https://www.kaggle.com/datasets/comparedge/saas-ai-tools-market-2026)

## License

CC BY 4.0 — Free to use with attribution to [ComparEdge](https://comparedge.com).
