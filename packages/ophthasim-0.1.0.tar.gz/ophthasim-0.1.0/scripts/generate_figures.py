"""Generate publication-quality figures from OpthaSim training results.

Produces 3 figures:
  1. Training curves (2x2 grid with variance bands)
  2. Baseline comparison (grouped bar chart)
  3. Architecture diagram (system overview)

All figures meet publication standards: 300 dpi, serif fonts, colorblind-safe
palette, labeled axes with units.

Usage:
    python3 scripts/generate_figures.py
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

# ---------------------------------------------------------------------------
# Publication style settings
# ---------------------------------------------------------------------------
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.size"] = 10
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["xtick.major.width"] = 0.6
plt.rcParams["ytick.major.width"] = 0.6
plt.rcParams["legend.framealpha"] = 0.9
plt.rcParams["legend.edgecolor"] = "0.7"

# Colorblind-safe palette (Wong 2011 / Tol / IBM Design)
COLORS = {
    "ppo":       "#0072B2",   # Blue
    "heuristic": "#E69F00",   # Orange
    "random":    "#999999",   # Gray
    "accent":    "#009E73",   # Teal
    "alert":     "#D55E00",   # Vermilion
}

ENV_DISPLAY_NAMES = {
    "GlaucomaIOP-v0": "Glaucoma IOP\nManagement",
    "AntiVEGF-v0": "Anti-VEGF\nInjection Timing",
    "LaserTrabeculoplasty-v0": "Laser\nTrabeculoplasty",
    "DiabeticRetinopathy-v0": "Diabetic\nRetinopathy",
}

ENV_SHORT_LABELS = {
    "GlaucomaIOP-v0": "Glaucoma IOP",
    "AntiVEGF-v0": "Anti-VEGF",
    "LaserTrabeculoplasty-v0": "Laser Trabec.",
    "DiabeticRetinopathy-v0": "Diabetic Ret.",
}


def load_results(results_path: Path) -> dict:
    with open(results_path) as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Figure 1: Training Curves
# ---------------------------------------------------------------------------
def generate_training_curves(results: dict, output_path: Path) -> None:
    """2x2 grid of training curves with variance bands."""
    fig, axes = plt.subplots(2, 2, figsize=(7, 5.5))
    axes = axes.flatten()

    env_names = list(results.keys())

    for idx, env_name in enumerate(env_names):
        ax = axes[idx]
        data = results[env_name]
        curve = np.array(data["training_curve"])

        if len(curve) == 0:
            ax.text(0.5, 0.5, "No data", transform=ax.transAxes,
                    ha="center", va="center")
            continue

        steps = curve[:, 0]
        rewards = curve[:, 1]

        # Compute moving average and std for variance bands
        window = max(3, len(rewards) // 15)
        if len(rewards) >= window:
            # Pad for convolution
            padded = np.pad(rewards, (window // 2, window // 2), mode="edge")
            smoothed = np.convolve(padded, np.ones(window) / window, mode="valid")
            # Truncate to match original length
            smoothed = smoothed[:len(rewards)]

            # Rolling std for bands
            rolling_std = np.array([
                np.std(rewards[max(0, i - window // 2):i + window // 2 + 1])
                for i in range(len(rewards))
            ])
        else:
            smoothed = rewards
            rolling_std = np.zeros_like(rewards)

        # Plot
        ax.plot(steps / 1000, smoothed, color=COLORS["ppo"], linewidth=1.5,
                label="PPO (smoothed)")
        ax.fill_between(
            steps / 1000,
            smoothed - rolling_std,
            smoothed + rolling_std,
            color=COLORS["ppo"],
            alpha=0.2,
            label="$\\pm 1$ std",
        )
        # Light raw data
        ax.plot(steps / 1000, rewards, color=COLORS["ppo"], alpha=0.25,
                linewidth=0.5, zorder=1)

        # Reference lines for baselines
        ppo_final = data["ppo"]["mean_reward"]
        random_mean = data["random"]["mean_reward"]
        heuristic_mean = data["heuristic"]["mean_reward"]

        ax.axhline(y=random_mean, color=COLORS["random"], linestyle="--",
                    linewidth=0.8, label=f"Random ({random_mean:.1f})")
        ax.axhline(y=heuristic_mean, color=COLORS["heuristic"], linestyle="-.",
                    linewidth=0.8, label=f"Heuristic ({heuristic_mean:.1f})")

        ax.set_title(ENV_SHORT_LABELS.get(env_name, env_name), fontsize=10,
                      fontweight="bold")
        ax.set_xlabel("Training Steps (x1000)", fontsize=8)
        ax.set_ylabel("Mean Episode Reward", fontsize=8)
        ax.tick_params(labelsize=7)
        ax.legend(fontsize=6, loc="lower right")
        ax.grid(True, alpha=0.3, linewidth=0.5)

    fig.suptitle("PPO Training Curves Across OpthaSim Environments",
                 fontsize=12, fontweight="bold", y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Saved: {output_path}")


# ---------------------------------------------------------------------------
# Figure 2: Baseline Comparison
# ---------------------------------------------------------------------------
def generate_baseline_comparison(results: dict, output_path: Path) -> None:
    """Grouped bar chart comparing PPO, Heuristic, and Random across envs."""
    env_names = list(results.keys())
    n_envs = len(env_names)

    fig, (ax_abs, ax_norm) = plt.subplots(1, 2, figsize=(8, 4.5))

    x = np.arange(n_envs)
    width = 0.25

    # Panel A: Absolute rewards
    ppo_means = [results[e]["ppo"]["mean_reward"] for e in env_names]
    ppo_stds = [results[e]["ppo"]["std_reward"] for e in env_names]
    heur_means = [results[e]["heuristic"]["mean_reward"] for e in env_names]
    heur_stds = [results[e]["heuristic"]["std_reward"] for e in env_names]
    rand_means = [results[e]["random"]["mean_reward"] for e in env_names]
    rand_stds = [results[e]["random"]["std_reward"] for e in env_names]

    bars_ppo = ax_abs.bar(x - width, ppo_means, width, yerr=ppo_stds,
                           label="PPO", color=COLORS["ppo"],
                           capsize=3, error_kw={"linewidth": 0.8})
    bars_heur = ax_abs.bar(x, heur_means, width, yerr=heur_stds,
                            label="Heuristic", color=COLORS["heuristic"],
                            capsize=3, error_kw={"linewidth": 0.8})
    bars_rand = ax_abs.bar(x + width, rand_means, width, yerr=rand_stds,
                            label="Random", color=COLORS["random"],
                            capsize=3, error_kw={"linewidth": 0.8})

    ax_abs.set_ylabel("Mean Episode Reward", fontsize=9)
    ax_abs.set_xticks(x)
    ax_abs.set_xticklabels(
        [ENV_SHORT_LABELS.get(e, e) for e in env_names],
        fontsize=7, rotation=15, ha="right",
    )
    ax_abs.legend(fontsize=8)
    ax_abs.grid(True, axis="y", alpha=0.3, linewidth=0.5)
    ax_abs.set_title("(A) Absolute Reward", fontsize=10, fontweight="bold")
    ax_abs.axhline(y=0, color="black", linewidth=0.5)

    # Panel B: Improvement over random baseline (absolute reward delta)
    ppo_improvement = [
        results[e]["ppo"]["mean_reward"] - results[e]["random"]["mean_reward"]
        for e in env_names
    ]
    heur_improvement = [
        results[e]["heuristic"]["mean_reward"] - results[e]["random"]["mean_reward"]
        for e in env_names
    ]

    bar_width = 0.35
    ax_norm.bar(x - bar_width / 2, ppo_improvement, bar_width,
                label="PPO", color=COLORS["ppo"])
    ax_norm.bar(x + bar_width / 2, heur_improvement, bar_width,
                label="Heuristic", color=COLORS["heuristic"])

    ax_norm.set_ylabel("Improvement Over Random\n(Reward Delta)", fontsize=9)
    ax_norm.set_xticks(x)
    ax_norm.set_xticklabels(
        [ENV_SHORT_LABELS.get(e, e) for e in env_names],
        fontsize=7, rotation=15, ha="right",
    )
    ax_norm.axhline(y=0, color="black", linewidth=0.5)
    ax_norm.legend(fontsize=8)
    ax_norm.grid(True, axis="y", alpha=0.3, linewidth=0.5)
    ax_norm.set_title("(B) Improvement Over Random", fontsize=10, fontweight="bold")

    fig.suptitle("Agent Performance Comparison Across OpthaSim Environments",
                 fontsize=11, fontweight="bold", y=1.0)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Saved: {output_path}")


# ---------------------------------------------------------------------------
# Figure 3: Architecture Diagram
# ---------------------------------------------------------------------------
def generate_architecture_diagram(output_path: Path) -> None:
    """System overview: Patient Model -> Environment -> Agent -> Action cycle."""
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 8)
    ax.axis("off")

    def draw_box(ax, xy, w, h, text, color="#E8E8E8", text_color="black",
                 fontsize=9, fontweight="normal", edgecolor="0.3"):
        box = FancyBboxPatch(
            xy, w, h,
            boxstyle="round,pad=0.15",
            facecolor=color,
            edgecolor=edgecolor,
            linewidth=1.2,
        )
        ax.add_patch(box)
        ax.text(
            xy[0] + w / 2, xy[1] + h / 2, text,
            ha="center", va="center",
            fontsize=fontsize, fontweight=fontweight,
            color=text_color,
        )

    def draw_arrow(ax, start, end, color="0.3", style="->"):
        arrow = FancyArrowPatch(
            start, end,
            arrowstyle=style,
            color=color,
            linewidth=1.5,
            mutation_scale=15,
            connectionstyle="arc3,rad=0.0",
        )
        ax.add_patch(arrow)

    # Title
    ax.text(5, 7.6, "OpthaSim: Reinforcement Learning for Ophthalmic Treatment",
            ha="center", va="center", fontsize=13, fontweight="bold",
            color="0.15")
    ax.text(5, 7.2, "System Architecture",
            ha="center", va="center", fontsize=10, color="0.4")

    # Core loop components
    # Patient Model (top left)
    draw_box(ax, (0.5, 5.5), 2.5, 1.0, "Patient Model\n(Physiological\nSimulation)",
             color="#D4E6F1", fontsize=8, fontweight="bold", edgecolor="#2980B9")

    # Environment (center)
    draw_box(ax, (3.8, 5.5), 2.4, 1.0, "Gymnasium\nEnvironment",
             color="#D5F5E3", fontsize=9, fontweight="bold", edgecolor="#27AE60")

    # RL Agent (right)
    draw_box(ax, (7.0, 5.5), 2.5, 1.0, "RL Agent\n(PPO / Heuristic\n/ Random)",
             color="#FADBD8", fontsize=8, fontweight="bold", edgecolor="#E74C3C")

    # Arrows for core loop
    draw_arrow(ax, (3.0, 6.0), (3.8, 6.0))  # Patient -> Env
    draw_arrow(ax, (6.2, 6.2), (7.0, 6.2))  # Env -> Agent (observation)
    draw_arrow(ax, (7.0, 5.8), (6.2, 5.8))  # Agent -> Env (action)

    # Labels on arrows
    ax.text(3.35, 6.25, "state", fontsize=7, ha="center", color="0.4", style="italic")
    ax.text(6.6, 6.45, "obs", fontsize=7, ha="center", color="0.4", style="italic")
    ax.text(6.6, 5.55, "action", fontsize=7, ha="center", color="0.4", style="italic")

    # Reward arrow (from env back, curved)
    reward_arrow = FancyArrowPatch(
        (5.0, 5.5), (8.25, 5.5),
        arrowstyle="->",
        color="#E67E22",
        linewidth=1.2,
        mutation_scale=12,
        connectionstyle="arc3,rad=-0.5",
    )
    ax.add_patch(reward_arrow)
    ax.text(6.6, 4.5, "reward", fontsize=7, ha="center", color="#E67E22",
            style="italic", fontweight="bold")

    # 4 Environment boxes (bottom row)
    env_data = [
        ("Glaucoma\nIOP", "#AED6F1", "#2980B9", "Daily IOP\nmedication\n365 steps"),
        ("Anti-VEGF\nInjection", "#A9DFBF", "#27AE60", "Monthly\ninjection\n24 steps"),
        ("Laser\nTrabeculoplasty", "#F9E79F", "#F39C12", "Monthly\nSLT params\n36 steps"),
        ("Diabetic\nRetinopathy", "#F5B7B1", "#E74C3C", "Quarterly\nscreening\n40 steps"),
    ]

    for i, (name, color, edge, detail) in enumerate(env_data):
        x_pos = 0.5 + i * 2.4
        draw_box(ax, (x_pos, 2.5), 2.0, 1.2, name,
                 color=color, fontsize=8, fontweight="bold", edgecolor=edge)
        ax.text(x_pos + 1.0, 1.9, detail, ha="center", va="top",
                fontsize=6, color="0.4")

    # Connecting arrows from env boxes to central environment
    for i in range(4):
        x_center = 0.5 + i * 2.4 + 1.0
        draw_arrow(ax, (x_center, 3.7), (5.0, 5.5), color="0.6", style="-|>")

    # Bottom note
    ax.text(5, 0.8,
            "Each environment models a distinct ophthalmic condition with clinically-calibrated\n"
            "physiological dynamics, guideline-based heuristic baselines, and standard RL interfaces.",
            ha="center", va="center", fontsize=7.5, color="0.45",
            style="italic")

    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Saved: {output_path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    project_root = Path(__file__).resolve().parent.parent
    results_path = project_root / "results" / "training_results.json"
    figures_dir = project_root / "paper" / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)

    if not results_path.exists():
        print(f"ERROR: Results file not found: {results_path}")
        print("Run scripts/train_all_envs.py first.")
        return

    print("Loading results...")
    results = load_results(results_path)
    print(f"  Found {len(results)} environments\n")

    print("Generating Figure 1: Training Curves...")
    generate_training_curves(results, figures_dir / "training_curves.png")

    print("\nGenerating Figure 2: Baseline Comparison...")
    generate_baseline_comparison(results, figures_dir / "baseline_comparison.png")

    print("\nGenerating Figure 3: Architecture Diagram...")
    generate_architecture_diagram(figures_dir / "architecture.png")

    print(f"\nAll figures saved to: {figures_dir}")
    print("Files:")
    for f in sorted(figures_dir.glob("*.png")):
        size_kb = f.stat().st_size / 1024
        print(f"  {f.name}: {size_kb:.0f} KB")


if __name__ == "__main__":
    main()
