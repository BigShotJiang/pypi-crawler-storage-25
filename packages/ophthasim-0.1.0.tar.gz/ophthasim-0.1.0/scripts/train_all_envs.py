"""Train PPO on all 4 OpthaSim environments, evaluate baselines, and save results.

Trains PPO using configs from ophthasim.training.configs, evaluates random and
heuristic baselines over 50 episodes, records training curves at 10k step
intervals, and saves everything to results/training_results.json.

Usage:
    python3 scripts/train_all_envs.py
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import gymnasium as gym
import numpy as np

# Ensure ophthasim is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import ophthasim  # noqa: F401  -- triggers env registration

from ophthasim.agents.heuristic_agent import get_heuristic_agent
from ophthasim.agents.random_agent import RandomAgent
from ophthasim.training.configs import ENV_CONFIGS

from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback


# ---------------------------------------------------------------------------
# Training curve callback -- records mean episode reward at checkpoint intervals
# ---------------------------------------------------------------------------
class TrainingCurveCallback(BaseCallback):
    """Records cumulative reward snapshots every `check_freq` timesteps."""

    def __init__(self, check_freq: int = 10_000, n_eval_episodes: int = 5,
                 env_id: str = "", seed: int = 42, verbose: int = 0):
        super().__init__(verbose)
        self.check_freq = check_freq
        self.n_eval_episodes = n_eval_episodes
        self.env_id = env_id
        self.seed = seed
        self.curve: list[list[float]] = []  # [[steps, mean_reward], ...]

    def _on_step(self) -> bool:
        if self.num_timesteps % self.check_freq == 0:
            mean_r = self._quick_eval()
            self.curve.append([self.num_timesteps, mean_r])
            if self.verbose:
                print(f"  [{self.env_id}] step={self.num_timesteps:>7d}  mean_reward={mean_r:.2f}")
        return True

    def _quick_eval(self) -> float:
        """Run a few evaluation episodes with the current policy."""
        rewards = []
        env = gym.make(self.env_id)
        for ep in range(self.n_eval_episodes):
            obs, _ = env.reset(seed=self.seed + 1000 + ep)
            total_r = 0.0
            done = False
            while not done:
                action, _ = self.model.predict(obs, deterministic=True)
                obs, r, terminated, truncated, _ = env.step(action)
                total_r += r
                done = terminated or truncated
            rewards.append(total_r)
        env.close()
        return float(np.mean(rewards))


# ---------------------------------------------------------------------------
# Evaluation helpers
# ---------------------------------------------------------------------------
def evaluate_ppo(model: PPO, env_id: str, n_episodes: int = 50, seed: int = 42) -> dict:
    """Evaluate a trained PPO model over n_episodes."""
    rewards = []
    env = gym.make(env_id)
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        total_r = 0.0
        done = False
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, r, terminated, truncated, _ = env.step(action)
            total_r += r
            done = terminated or truncated
        rewards.append(total_r)
    env.close()
    return {
        "mean_reward": float(np.mean(rewards)),
        "std_reward": float(np.std(rewards)),
        "n_episodes": n_episodes,
    }


def evaluate_random(env_id: str, n_episodes: int = 50, seed: int = 42) -> dict:
    """Evaluate random agent over n_episodes."""
    rewards = []
    env = gym.make(env_id)
    agent = RandomAgent(env.action_space, seed=seed)
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        agent.reset()
        total_r = 0.0
        done = False
        while not done:
            action = agent.act(obs)
            obs, r, terminated, truncated, _ = env.step(action)
            total_r += r
            done = terminated or truncated
        rewards.append(total_r)
    env.close()
    return {
        "mean_reward": float(np.mean(rewards)),
        "std_reward": float(np.std(rewards)),
        "n_episodes": n_episodes,
    }


def evaluate_heuristic(env_id: str, n_episodes: int = 50, seed: int = 42) -> dict:
    """Evaluate guideline-based heuristic agent over n_episodes."""
    rewards = []
    env = gym.make(env_id)
    agent = get_heuristic_agent(env_id, seed=seed)
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        agent.reset()
        total_r = 0.0
        done = False
        while not done:
            action = agent.act(obs)
            obs, r, terminated, truncated, _ = env.step(action)
            total_r += r
            done = terminated or truncated
        rewards.append(total_r)
    env.close()
    return {
        "mean_reward": float(np.mean(rewards)),
        "std_reward": float(np.std(rewards)),
        "n_episodes": n_episodes,
    }


def compute_ratio(ppo_mean: float, random_mean: float) -> tuple[float, str]:
    """Compute PPO vs random improvement ratio, handling negative baselines.

    When random baseline is negative:
      - If PPO is positive: ratio = |PPO - random| / |random|  (massive improvement)
      - If PPO is also negative but better: ratio = random / PPO  (both negative, PPO less bad)
    When random baseline is zero: return inf if PPO > 0, else 0.

    Returns:
        (ratio, explanation_note)
    """
    if abs(random_mean) < 1e-8:
        if ppo_mean > 0:
            return float("inf"), "Random baseline ~0; PPO is positive"
        return 0.0, "Random baseline ~0; PPO also ~0"

    if random_mean < 0:
        if ppo_mean >= 0:
            # PPO turned a negative baseline positive
            ratio = (ppo_mean - random_mean) / abs(random_mean)
            return ratio, (
                f"Negative random baseline ({random_mean:.2f}). "
                f"Ratio = (PPO - random) / |random| = {ratio:.2f}x improvement"
            )
        else:
            # Both negative -- PPO is less bad
            ratio = random_mean / ppo_mean
            return ratio, (
                f"Both negative (PPO={ppo_mean:.2f}, random={random_mean:.2f}). "
                f"Ratio = random/PPO = {ratio:.2f}x (PPO is {ratio:.2f}x less bad)"
            )
    else:
        ratio = ppo_mean / random_mean
        return ratio, f"Standard ratio: PPO/random = {ratio:.2f}x"


# ---------------------------------------------------------------------------
# Main training loop
# ---------------------------------------------------------------------------
def main():
    seed = 42
    results_dir = Path(__file__).resolve().parent.parent / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    models_dir = results_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    all_results = {}

    env_ids = list(ENV_CONFIGS.keys())

    for env_id in env_ids:
        config = ENV_CONFIGS[env_id].copy()
        total_timesteps = config.pop("total_timesteps")
        env_seed = config.pop("seed", seed)
        short_name = env_id.split("/")[1]

        print(f"\n{'='*70}")
        print(f"  Training: {env_id}")
        print(f"  Timesteps: {total_timesteps}, Seed: {env_seed}")
        print(f"{'='*70}")

        # ------------------------------------------------------------------
        # 1. Train PPO
        # ------------------------------------------------------------------
        t0 = time.time()
        vec_env = make_vec_env(env_id, n_envs=1, seed=env_seed)

        # Extract PPO-specific kwargs
        ppo_kwargs = {
            k: v for k, v in config.items()
            if k in ("learning_rate", "n_steps", "batch_size", "n_epochs",
                      "gamma", "ent_coef", "vf_coef", "max_grad_norm",
                      "gae_lambda", "clip_range")
        }

        model = PPO(
            "MlpPolicy",
            vec_env,
            seed=env_seed,
            verbose=0,
            **ppo_kwargs,
        )

        # Training curve callback
        curve_cb = TrainingCurveCallback(
            check_freq=10_000,
            n_eval_episodes=5,
            env_id=env_id,
            seed=env_seed,
            verbose=1,
        )

        model.learn(total_timesteps=total_timesteps, callback=curve_cb)
        train_time = time.time() - t0
        vec_env.close()

        # Save model
        model_path = models_dir / f"ppo_{short_name}"
        model.save(str(model_path))
        print(f"  Model saved: {model_path}")
        print(f"  Training time: {train_time:.1f}s")

        # ------------------------------------------------------------------
        # 2. Evaluate all agents
        # ------------------------------------------------------------------
        print(f"  Evaluating PPO (50 episodes)...")
        ppo_results = evaluate_ppo(model, env_id, n_episodes=50, seed=seed)
        print(f"    PPO: mean={ppo_results['mean_reward']:.2f} +/- {ppo_results['std_reward']:.2f}")

        print(f"  Evaluating Random (50 episodes)...")
        random_results = evaluate_random(env_id, n_episodes=50, seed=seed)
        print(f"    Random: mean={random_results['mean_reward']:.2f} +/- {random_results['std_reward']:.2f}")

        print(f"  Evaluating Heuristic (50 episodes)...")
        heuristic_results = evaluate_heuristic(env_id, n_episodes=50, seed=seed)
        print(f"    Heuristic: mean={heuristic_results['mean_reward']:.2f} +/- {heuristic_results['std_reward']:.2f}")

        # ------------------------------------------------------------------
        # 3. Compute ratio
        # ------------------------------------------------------------------
        ratio, ratio_note = compute_ratio(
            ppo_results["mean_reward"], random_results["mean_reward"]
        )
        print(f"  PPO vs Random ratio: {ratio:.2f} -- {ratio_note}")

        # Check 1.5x gate
        if ratio < 1.5:
            print(f"  WARNING: PPO did not exceed 1.5x random baseline ({ratio:.2f}x).")
            print(f"  Extending training by 500k more timesteps...")
            vec_env = make_vec_env(env_id, n_envs=1, seed=env_seed)
            model.set_env(vec_env)
            extra_cb = TrainingCurveCallback(
                check_freq=10_000,
                n_eval_episodes=5,
                env_id=env_id,
                seed=env_seed,
                verbose=1,
            )
            model.learn(total_timesteps=500_000, callback=extra_cb)
            vec_env.close()

            # Re-save and re-evaluate
            model.save(str(model_path))
            ppo_results = evaluate_ppo(model, env_id, n_episodes=50, seed=seed)
            ratio, ratio_note = compute_ratio(
                ppo_results["mean_reward"], random_results["mean_reward"]
            )
            # Append extra curve data
            curve_cb.curve.extend(
                [[s + total_timesteps, r] for s, r in extra_cb.curve]
            )
            total_timesteps += 500_000
            print(f"  After extended training: PPO mean={ppo_results['mean_reward']:.2f}, ratio={ratio:.2f}")

        # ------------------------------------------------------------------
        # 4. Assemble results for this env
        # ------------------------------------------------------------------
        all_results[short_name] = {
            "ppo": ppo_results,
            "random": random_results,
            "heuristic": heuristic_results,
            "ppo_vs_random_ratio": ratio if not np.isinf(ratio) else 999.0,
            "ppo_vs_random_ratio_note": ratio_note,
            "training_curve": curve_cb.curve,
            "total_timesteps": total_timesteps,
            "seed": env_seed,
            "training_time_seconds": round(train_time, 1),
        }

    # Save results
    results_path = results_dir / "training_results.json"
    with open(results_path, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\n{'='*70}")
    print(f"  All results saved to: {results_path}")
    print(f"{'='*70}")

    # Print summary table
    print(f"\n{'Environment':<30} {'PPO':>10} {'Random':>10} {'Heuristic':>10} {'Ratio':>8}")
    print("-" * 70)
    for env_name, res in all_results.items():
        print(
            f"{env_name:<30} "
            f"{res['ppo']['mean_reward']:>10.2f} "
            f"{res['random']['mean_reward']:>10.2f} "
            f"{res['heuristic']['mean_reward']:>10.2f} "
            f"{res['ppo_vs_random_ratio']:>8.2f}x"
        )


if __name__ == "__main__":
    main()
