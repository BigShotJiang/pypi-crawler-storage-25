"""Tests for visual acuity conversion utilities."""

import pytest
import numpy as np

from ophthasim.models.visual_acuity import (
    etdrs_to_logmar,
    logmar_to_etdrs,
    snellen_to_logmar,
    logmar_to_snellen,
    etdrs_to_snellen,
    snellen_to_etdrs,
    ETDRS_MIN,
    ETDRS_MAX,
)


class TestETDRSToLogMAR:
    """Tests for ETDRS letter -> LogMAR conversion."""

    def test_20_20_vision(self):
        """85 ETDRS letters = 0.0 LogMAR (20/20 Snellen)."""
        assert abs(etdrs_to_logmar(85.0) - 0.0) < 1e-10

    def test_20_200_vision(self):
        """35 ETDRS letters ~ 1.0 LogMAR (20/200 Snellen)."""
        logmar = etdrs_to_logmar(35.0)
        assert abs(logmar - 1.0) < 0.01

    def test_good_vision(self):
        """95 ETDRS letters = -0.2 LogMAR (better than 20/20)."""
        logmar = etdrs_to_logmar(95.0)
        assert abs(logmar - (-0.2)) < 1e-10

    def test_zero_letters(self):
        """0 ETDRS letters = 1.7 LogMAR (very poor vision)."""
        logmar = etdrs_to_logmar(0.0)
        assert abs(logmar - 1.7) < 1e-10

    def test_monotonic_decrease(self):
        """More ETDRS letters -> lower LogMAR (better vision)."""
        logmar_values = [etdrs_to_logmar(float(x)) for x in range(0, 101, 5)]
        for i in range(len(logmar_values) - 1):
            assert logmar_values[i] > logmar_values[i + 1]

    def test_out_of_range_high(self):
        """ETDRS > 100 should raise AssertionError."""
        with pytest.raises(AssertionError):
            etdrs_to_logmar(101.0)

    def test_out_of_range_low(self):
        """ETDRS < 0 should raise AssertionError."""
        with pytest.raises(AssertionError):
            etdrs_to_logmar(-1.0)


class TestLogMARToETDRS:
    """Tests for LogMAR -> ETDRS letter conversion."""

    def test_roundtrip_20_20(self):
        """LogMAR 0.0 -> 85 ETDRS -> LogMAR 0.0."""
        letters = logmar_to_etdrs(0.0)
        assert abs(letters - 85.0) < 1e-6

    def test_roundtrip(self):
        """Roundtrip conversion should preserve values."""
        for logmar in [0.0, 0.3, 0.5, 1.0, -0.2]:
            letters = logmar_to_etdrs(logmar)
            logmar_back = etdrs_to_logmar(letters)
            assert abs(logmar - logmar_back) < 0.01

    def test_clamping(self):
        """Output should be clamped to [0, 100]."""
        letters = logmar_to_etdrs(-0.3)
        assert 0 <= letters <= 100

    def test_out_of_range(self):
        with pytest.raises(AssertionError):
            logmar_to_etdrs(2.0)


class TestSnellenToLogMAR:
    """Tests for Snellen fraction -> LogMAR conversion."""

    def test_20_20(self):
        """20/20 Snellen = 0.0 LogMAR."""
        logmar = snellen_to_logmar(20, 20)
        assert abs(logmar - 0.0) < 1e-10

    def test_20_200(self):
        """20/200 Snellen = 1.0 LogMAR."""
        logmar = snellen_to_logmar(20, 200)
        assert abs(logmar - 1.0) < 1e-6

    def test_20_40(self):
        """20/40 Snellen ~ 0.3 LogMAR."""
        logmar = snellen_to_logmar(20, 40)
        assert abs(logmar - 0.301) < 0.01

    def test_invalid_numerator(self):
        with pytest.raises(AssertionError):
            snellen_to_logmar(0, 20)

    def test_invalid_denominator(self):
        with pytest.raises(AssertionError):
            snellen_to_logmar(20, 0)


class TestLogMARToSnellen:
    """Tests for LogMAR -> Snellen fraction conversion."""

    def test_0_logmar(self):
        """LogMAR 0.0 -> 20/20."""
        num, denom = logmar_to_snellen(0.0)
        assert num == 20
        assert denom == 20

    def test_1_logmar(self):
        """LogMAR 1.0 -> 20/200."""
        num, denom = logmar_to_snellen(1.0)
        assert num == 20
        assert denom == 200

    def test_negative_logmar(self):
        """LogMAR -0.1 -> 20/16 (better than 20/20)."""
        num, denom = logmar_to_snellen(-0.1)
        assert num == 20
        assert denom == 16


class TestCrossConversions:
    """Tests for ETDRS <-> Snellen conversions."""

    def test_etdrs_to_snellen_85(self):
        """85 ETDRS -> 20/20 Snellen."""
        num, denom = etdrs_to_snellen(85.0)
        assert num == 20
        assert denom == 20

    def test_snellen_to_etdrs_20_20(self):
        """20/20 Snellen -> ~85 ETDRS."""
        letters = snellen_to_etdrs(20, 20)
        assert abs(letters - 85.0) < 1.0

    def test_snellen_to_etdrs_20_200(self):
        """20/200 Snellen -> ~35 ETDRS."""
        letters = snellen_to_etdrs(20, 200)
        assert abs(letters - 35.0) < 2.0
