"""Tests for diabetic retinopathy Markov chain progression model."""

import pytest
import numpy as np

from ophthasim.models.retinal_progression import (
    DiabeticRetinopathyProgression,
    DR_STATES,
    NUM_STATES,
    BASE_TRANSITION_MATRIX,
    DME_PREVALENCE,
    PARAMETER_RANGES,
)


class TestDRInit:
    """Tests for DR model initialization."""

    def test_default_init(self):
        dr = DiabeticRetinopathyProgression(seed=42)
        assert dr.stage == 0
        assert dr.HbA1c == 7.0
        assert not dr.has_dme

    def test_custom_stage(self):
        dr = DiabeticRetinopathyProgression(initial_stage=2, seed=42)
        assert dr.stage == 2

    def test_invalid_stage_raises(self):
        with pytest.raises(AssertionError):
            DiabeticRetinopathyProgression(initial_stage=5)

    def test_invalid_hba1c_raises(self):
        with pytest.raises(AssertionError):
            DiabeticRetinopathyProgression(HbA1c=20.0)

    def test_hba1c_lower_bound(self):
        with pytest.raises(AssertionError):
            DiabeticRetinopathyProgression(HbA1c=3.0)


class TestTransitionMatrix:
    """Tests for base transition matrix properties."""

    def test_rows_sum_to_one(self):
        for i in range(NUM_STATES):
            row_sum = np.sum(BASE_TRANSITION_MATRIX[i])
            assert abs(row_sum - 1.0) < 1e-10

    def test_no_backward_transitions(self):
        """No regression in base matrix."""
        for i in range(NUM_STATES):
            for j in range(i):
                assert BASE_TRANSITION_MATRIX[i, j] == 0.0

    def test_pdr_absorbing(self):
        """PDR (stage 4) is an absorbing state."""
        assert BASE_TRANSITION_MATRIX[4, 4] == 1.0

    def test_probabilities_non_negative(self):
        assert np.all(BASE_TRANSITION_MATRIX >= 0.0)

    def test_diagonal_dominant(self):
        """Self-loop probability should be largest in each row."""
        for i in range(NUM_STATES):
            assert BASE_TRANSITION_MATRIX[i, i] >= np.max(
                np.delete(BASE_TRANSITION_MATRIX[i], i)
            )


class TestDRProgression:
    """Tests for DR stage progression mechanics."""

    def test_single_step(self):
        dr = DiabeticRetinopathyProgression(seed=42)
        stage, dme = dr.step()
        assert 0 <= stage < NUM_STATES
        assert isinstance(dme, bool)
        assert dr.quarter == 1

    def test_forward_only_progression(self):
        """Stage should only increase or stay the same (no regression)."""
        dr = DiabeticRetinopathyProgression(seed=42)
        max_stage = 0
        for _ in range(100):
            stage, _ = dr.step()
            assert stage >= max_stage or stage == max_stage
            max_stage = max(max_stage, stage)

    def test_high_hba1c_faster_progression(self):
        """Higher HbA1c should lead to faster progression on average."""
        # Run many trials with low and high HbA1c
        low_stages = []
        high_stages = []
        for trial in range(200):
            dr_low = DiabeticRetinopathyProgression(HbA1c=6.0, seed=trial)
            dr_high = DiabeticRetinopathyProgression(HbA1c=11.0, seed=trial)
            for _ in range(20):
                dr_low.step()
                dr_high.step()
            low_stages.append(dr_low.stage)
            high_stages.append(dr_high.stage)
        assert np.mean(high_stages) > np.mean(low_stages)

    def test_pdr_absorbing(self):
        """Once at PDR, should stay at PDR."""
        dr = DiabeticRetinopathyProgression(initial_stage=4, seed=42)
        for _ in range(20):
            stage, _ = dr.step()
            assert stage == 4

    def test_simulate(self):
        dr = DiabeticRetinopathyProgression(seed=42)
        trajectory = dr.simulate(10)
        assert len(trajectory) == 10
        for stage, dme in trajectory:
            assert 0 <= stage < NUM_STATES
            assert isinstance(dme, bool)


class TestTreatmentEffects:
    """Tests for PRP and anti-VEGF treatment effects."""

    def test_prp_reduces_progression(self):
        """PRP should reduce Severe->PDR transition rate."""
        untreated_pdrs = 0
        treated_pdrs = 0
        n_trials = 500

        for trial in range(n_trials):
            # Untreated
            dr = DiabeticRetinopathyProgression(initial_stage=3, HbA1c=9.0, seed=trial)
            for _ in range(8):
                dr.step()
            if dr.stage == 4:
                untreated_pdrs += 1

            # PRP treated
            dr = DiabeticRetinopathyProgression(initial_stage=3, HbA1c=9.0, seed=trial)
            dr.start_prp()
            for _ in range(8):
                dr.step()
            if dr.stage == 4:
                treated_pdrs += 1

        assert treated_pdrs < untreated_pdrs

    def test_anti_vegf_reduces_dme(self):
        """Anti-VEGF should reduce DME occurrence."""
        dr = DiabeticRetinopathyProgression(initial_stage=3, seed=42)
        dr.start_anti_vegf()
        # anti-VEGF should be active
        assert dr.on_anti_vegf

    def test_stop_anti_vegf(self):
        dr = DiabeticRetinopathyProgression(seed=42)
        dr.start_anti_vegf()
        dr.stop_anti_vegf()
        assert not dr.on_anti_vegf


class TestDMEPrevalence:
    """Tests for DME prevalence by DR stage."""

    def test_no_dme_without_dr(self):
        assert DME_PREVALENCE[0] == 0.0

    def test_dme_increases_with_stage(self):
        for i in range(NUM_STATES - 1):
            assert DME_PREVALENCE[i] <= DME_PREVALENCE[i + 1]

    def test_dme_probabilities_valid(self):
        for stage, prob in DME_PREVALENCE.items():
            assert 0.0 <= prob <= 1.0


class TestVisionLossRisk:
    """Tests for vision loss risk estimation."""

    def test_risk_increases_with_stage(self):
        risks = []
        for stage in range(NUM_STATES):
            dr = DiabeticRetinopathyProgression(initial_stage=stage, seed=42)
            risks.append(dr.get_vision_loss_risk())
        for i in range(len(risks) - 1):
            assert risks[i] <= risks[i + 1]

    def test_risk_bounded(self):
        dr = DiabeticRetinopathyProgression(initial_stage=4, seed=42)
        dr.has_dme = True
        risk = dr.get_vision_loss_risk()
        assert 0.0 <= risk <= 1.0


class TestDRReset:
    """Tests for DR model reset."""

    def test_reset_restores_state(self):
        dr = DiabeticRetinopathyProgression(seed=42)
        dr.step()
        dr.step()
        dr.start_prp()
        dr.reset()
        assert dr.stage == 0
        assert dr.quarter == 0
        assert not dr.on_prp

    def test_reset_with_hba1c(self):
        dr = DiabeticRetinopathyProgression(seed=42)
        dr.reset(HbA1c=10.0)
        assert dr.HbA1c == 10.0


class TestDRStateName:
    """Tests for state name lookup."""

    def test_all_states_have_names(self):
        for i in range(NUM_STATES):
            dr = DiabeticRetinopathyProgression(initial_stage=i, seed=42)
            name = dr.get_state_name()
            assert isinstance(name, str)
            assert len(name) > 0

    def test_stage_names_match(self):
        dr = DiabeticRetinopathyProgression(initial_stage=0, seed=42)
        assert dr.get_state_name() == "None"
        dr.stage = 4
        assert dr.get_state_name() == "PDR"
