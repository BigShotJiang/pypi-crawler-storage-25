"""Tests for LaserTrabeculoplasty-v0 Gymnasium environment."""

import pytest
import numpy as np
import gymnasium as gym

import ophthasim


class TestLaserEnvInit:
    """Tests for environment initialization."""

    def test_make_env(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        assert env is not None
        env.close()

    def test_action_space(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        assert isinstance(env.action_space, gym.spaces.MultiDiscrete)
        np.testing.assert_array_equal(env.action_space.nvec, [2, 3, 3])
        env.close()

    def test_observation_space(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        assert isinstance(env.observation_space, gym.spaces.Box)
        assert env.observation_space.shape == (7,)
        env.close()

    def test_all_difficulties(self):
        for diff in ["easy", "medium", "hard"]:
            env = gym.make("ophthasim/LaserTrabeculoplasty-v0", difficulty=diff)
            obs, info = env.reset(seed=42)
            assert obs.shape == (7,)
            env.close()


class TestLaserReset:
    """Tests for environment reset."""

    def test_reset_returns_tuple(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        obs, info = env.reset(seed=42)
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)
        env.close()

    def test_obs_in_space(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        obs, _ = env.reset(seed=42)
        assert env.observation_space.contains(obs)
        env.close()

    def test_info_keys(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        _, info = env.reset(seed=42)
        assert "iop_baseline" in info
        assert "iop_current" in info
        assert "treatment_count" in info
        env.close()


class TestLaserStep:
    """Tests for environment stepping."""

    def test_step_returns_tuple(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        env.reset(seed=42)
        action = np.array([0, 1, 1])  # No treatment
        obs, reward, terminated, truncated, info = env.step(action)
        assert len((obs, reward, terminated, truncated, info)) == 5
        env.close()

    def test_no_treatment_action(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        env.reset(seed=42)
        _, _, _, _, info = env.step(np.array([0, 0, 0]))
        assert info["treatment_count"] <= 1  # May have previous from patient gen
        env.close()

    def test_treatment_action(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        env.reset(seed=42)
        _, _, _, _, info_before = env.step(np.array([0, 0, 0]))
        count_before = info_before["treatment_count"]
        env.reset(seed=42)
        _, _, _, _, info_after = env.step(np.array([1, 2, 1]))  # Treat, 360, medium
        assert info_after["treatment_count"] >= count_before
        env.close()

    def test_episode_length_36(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        env.reset(seed=42)
        steps = 0
        terminated, truncated = False, False
        while not (terminated or truncated):
            _, _, terminated, truncated, _ = env.step(np.array([0, 0, 0]))
            steps += 1
        assert steps == 36
        env.close()

    def test_all_action_combinations(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        for treat in range(2):
            for coverage in range(3):
                for energy in range(3):
                    env.reset(seed=42)
                    action = np.array([treat, coverage, energy])
                    obs, reward, _, _, _ = env.step(action)
                    assert env.observation_space.contains(obs)
                    assert np.isfinite(reward)
        env.close()

    def test_obs_in_space_after_step(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        env.reset(seed=42)
        obs, _, _, _, _ = env.step(np.array([1, 2, 1]))
        assert env.observation_space.contains(obs)
        env.close()


class TestLaserReward:
    def test_reward_finite(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        env.reset(seed=42)
        for _ in range(36):
            _, reward, term, trunc, _ = env.step(np.array([0, 0, 0]))
            assert np.isfinite(reward)
            if term or trunc:
                break
        env.close()


class TestLaserRender:
    def test_ansi_render(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0", render_mode="ansi")
        env.reset(seed=42)
        env.step(np.array([0, 0, 0]))
        output = env.render()
        assert isinstance(output, str)
        assert "IOP" in output
        env.close()
