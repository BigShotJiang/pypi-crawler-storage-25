"""Tests for IOP dynamics model (Goldmann equation with circadian modulation)."""

import pytest
import numpy as np

from ophthasim.models.iop_dynamics import (
    IOPDynamicsModel,
    DEFAULT_PARAMS,
    PARAMETER_RANGES,
    MEDICATION_EFFECTS,
)


class TestIOPDynamicsInit:
    """Tests for model initialization and parameter validation."""

    def test_default_params(self):
        model = IOPDynamicsModel(seed=42)
        assert model.iop == DEFAULT_PARAMS["IOP_initial"]
        assert model.time_hours == 0.0
        assert len(model.active_medications) == 0

    def test_custom_params(self):
        params = {"IOP_initial": 25.0, "C": 0.30}
        model = IOPDynamicsModel(params=params, seed=42)
        assert model.iop == 25.0
        assert model.params["C"] == 0.30

    def test_invalid_param_raises(self):
        with pytest.raises(AssertionError, match="out of range"):
            IOPDynamicsModel(params={"IOP_initial": 50.0})

    def test_all_default_params_in_range(self):
        for key, value in DEFAULT_PARAMS.items():
            lo, hi, _ = PARAMETER_RANGES[key]
            assert lo <= value <= hi, f"{key}={value} not in [{lo}, {hi}]"


class TestIOPDynamicsStep:
    """Tests for time-stepping the IOP model."""

    def test_single_step(self):
        model = IOPDynamicsModel(seed=42)
        initial_iop = model.iop
        new_iop = model.step(dt_hours=24.0)
        assert isinstance(new_iop, float)
        assert model.time_hours == 24.0

    def test_equilibrium_convergence(self):
        """After many steps without medication, IOP should converge to equilibrium."""
        model = IOPDynamicsModel(params={"A_circ": 0.0}, seed=42)  # No circadian
        eq_iop = model.get_equilibrium_iop()
        for _ in range(100):
            model.step(dt_hours=24.0)
        assert abs(model.iop - eq_iop) < 0.5

    def test_iop_stays_positive(self):
        model = IOPDynamicsModel(seed=42)
        for _ in range(365):
            model.step(dt_hours=24.0)
            assert model.iop > 0.0

    def test_time_advances(self):
        model = IOPDynamicsModel(seed=42)
        model.step(dt_hours=24.0)
        model.step(dt_hours=12.0)
        assert abs(model.time_hours - 36.0) < 1e-10

    def test_reproducibility(self):
        m1 = IOPDynamicsModel(seed=42)
        m2 = IOPDynamicsModel(seed=42)
        for _ in range(10):
            iop1 = m1.step(24.0)
            iop2 = m2.step(24.0)
            assert abs(iop1 - iop2) < 1e-10


class TestIOPMedications:
    """Tests for medication effects on IOP."""

    def test_add_prostaglandin(self):
        model = IOPDynamicsModel(params={"A_circ": 0.0}, seed=42)
        eq_before = model.get_equilibrium_iop()
        model.add_medication("prostaglandin")
        assert "prostaglandin" in model.active_medications
        # After settling, IOP should be lower
        for _ in range(30):
            model.step(24.0)
        assert model.iop < eq_before

    def test_add_beta_blocker(self):
        model = IOPDynamicsModel(params={"A_circ": 0.0}, seed=42)
        eq_before = model.get_equilibrium_iop()
        model.add_medication("beta_blocker")
        for _ in range(30):
            model.step(24.0)
        assert model.iop < eq_before

    def test_add_all_medications(self):
        model = IOPDynamicsModel(params={"A_circ": 0.0}, seed=42)
        eq_before = model.get_equilibrium_iop()
        for med in MEDICATION_EFFECTS:
            model.add_medication(med)
        for _ in range(30):
            model.step(24.0)
        # Combination therapy should lower IOP significantly
        assert model.iop < eq_before - 3.0

    def test_remove_medication(self):
        model = IOPDynamicsModel(params={"A_circ": 0.0}, seed=42)
        model.add_medication("prostaglandin")
        model.remove_medication("prostaglandin")
        assert "prostaglandin" not in model.active_medications

    def test_invalid_medication_raises(self):
        model = IOPDynamicsModel(seed=42)
        with pytest.raises(AssertionError, match="Unknown medication"):
            model.add_medication("aspirin")

    def test_medication_duration_tracking(self):
        model = IOPDynamicsModel(seed=42)
        model.add_medication("prostaglandin")
        model.step(dt_hours=48.0)
        assert model.active_medications["prostaglandin"] == 2.0  # 2 days


class TestIOPMeasurement:
    """Tests for IOP measurement with noise."""

    def test_noise_distribution(self):
        model = IOPDynamicsModel(seed=42)
        measurements = [model.get_iop_with_noise(1.5) for _ in range(1000)]
        mean_meas = np.mean(measurements)
        assert abs(mean_meas - model.iop) < 0.5  # Should center near true IOP

    def test_zero_noise(self):
        model = IOPDynamicsModel(seed=42)
        meas = model.get_iop_with_noise(0.0)
        assert abs(meas - model.iop) < 1e-10

    def test_noise_non_negative(self):
        model = IOPDynamicsModel(seed=42)
        for _ in range(100):
            meas = model.get_iop_with_noise(3.0)
            assert meas >= 0.0

    def test_invalid_noise_raises(self):
        model = IOPDynamicsModel(seed=42)
        with pytest.raises(AssertionError):
            model.get_iop_with_noise(10.0)


class TestIOPReset:
    """Tests for model reset."""

    def test_reset_returns_initial_iop(self):
        model = IOPDynamicsModel(seed=42)
        model.step(24.0)
        model.add_medication("prostaglandin")
        iop = model.reset()
        assert iop == DEFAULT_PARAMS["IOP_initial"]
        assert model.time_hours == 0.0
        assert len(model.active_medications) == 0

    def test_reset_with_new_params(self):
        model = IOPDynamicsModel(seed=42)
        model.reset(params={"IOP_initial": 30.0})
        assert model.iop == 30.0


class TestIOPEquilibrium:
    """Tests for analytical equilibrium calculation."""

    def test_equilibrium_formula(self):
        model = IOPDynamicsModel(seed=42)
        eq = model.get_equilibrium_iop()
        p = model.params
        expected = (p["F_in_mean"] - p["F_u"]) / p["C"] + p["P_e"]
        assert abs(eq - expected) < 1e-10

    def test_equilibrium_positive(self):
        model = IOPDynamicsModel(seed=42)
        eq = model.get_equilibrium_iop()
        assert eq > 0
