"""Tests for patient parameter generation."""

import pytest

from ophthasim.models.patient import PatientGenerator, PARAMETER_RANGES


class TestPatientGeneratorInit:
    """Tests for generator initialization."""

    def test_seeded_init(self):
        gen = PatientGenerator(seed=42)
        assert gen.rng is not None

    def test_reproducibility(self):
        gen1 = PatientGenerator(seed=42)
        gen2 = PatientGenerator(seed=42)
        p1 = gen1.generate_glaucoma_patient("medium")
        p2 = gen2.generate_glaucoma_patient("medium")
        assert p1 == p2


class TestGlaucomaPatient:
    """Tests for glaucoma patient generation."""

    def test_easy_difficulty(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_glaucoma_patient("easy")
        assert 22.0 <= p["IOP_baseline"] <= 26.0
        assert p["compliance"] >= 0.90
        assert p["circadian_amplitude"] == 0.15

    def test_medium_difficulty(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_glaucoma_patient("medium")
        assert 24.0 <= p["IOP_baseline"] <= 30.0
        assert p["compliance"] >= 0.75

    def test_hard_difficulty(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_glaucoma_patient("hard")
        assert 28.0 <= p["IOP_baseline"] <= 36.0
        assert p["medication_resistance"] > 0

    def test_invalid_difficulty(self):
        gen = PatientGenerator(seed=42)
        with pytest.raises(AssertionError):
            gen.generate_glaucoma_patient("impossible")

    def test_iop_in_range(self):
        gen = PatientGenerator(seed=42)
        for diff in ["easy", "medium", "hard"]:
            p = gen.generate_glaucoma_patient(diff)
            lo, hi, _ = PARAMETER_RANGES["IOP_baseline"]
            assert lo <= p["IOP_baseline"] <= hi

    def test_all_params_present(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_glaucoma_patient("medium")
        required = ["age", "IOP_baseline", "target_IOP", "CCT", "VFI",
                     "compliance", "circadian_amplitude", "measurement_noise",
                     "medication_resistance"]
        for key in required:
            assert key in p, f"Missing key: {key}"


class TestAntiVEGFPatient:
    """Tests for anti-VEGF patient generation."""

    def test_easy_full_responder(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_anti_vegf_patient("easy")
        assert p["drug_response"] == 1.0

    def test_hard_partial_responder(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_anti_vegf_patient("hard")
        assert p["drug_response"] < 1.0

    def test_va_in_range(self):
        gen = PatientGenerator(seed=42)
        for diff in ["easy", "medium", "hard"]:
            p = gen.generate_anti_vegf_patient(diff)
            lo, hi, _ = PARAMETER_RANGES["VA_baseline"]
            assert lo <= p["VA_baseline"] <= hi

    def test_cst_in_range(self):
        gen = PatientGenerator(seed=42)
        for diff in ["easy", "medium", "hard"]:
            p = gen.generate_anti_vegf_patient(diff)
            lo, hi, _ = PARAMETER_RANGES["CST_baseline"]
            assert lo <= p["CST_baseline"] <= hi


class TestLaserPatient:
    """Tests for laser trabeculoplasty patient generation."""

    def test_easy_no_previous(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_laser_patient("easy")
        assert p["previous_laser_count"] == 0

    def test_hard_higher_iop(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_laser_patient("hard")
        assert p["IOP_baseline"] >= 30.0

    def test_lens_status_binary(self):
        gen = PatientGenerator(seed=42)
        for diff in ["easy", "medium", "hard"]:
            p = gen.generate_laser_patient(diff)
            assert p["lens_status"] in (0, 1)


class TestDRPatient:
    """Tests for diabetic retinopathy patient generation."""

    def test_easy_low_hba1c(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_dr_patient("easy")
        assert p["HbA1c"] <= 7.5

    def test_hard_high_hba1c(self):
        gen = PatientGenerator(seed=42)
        p = gen.generate_dr_patient("hard")
        assert p["HbA1c"] >= 9.0

    def test_hba1c_in_range(self):
        gen = PatientGenerator(seed=42)
        for diff in ["easy", "medium", "hard"]:
            p = gen.generate_dr_patient(diff)
            lo, hi, _ = PARAMETER_RANGES["HbA1c"]
            assert lo <= p["HbA1c"] <= hi

    def test_initial_stage_valid(self):
        gen = PatientGenerator(seed=42)
        for diff in ["easy", "medium", "hard"]:
            p = gen.generate_dr_patient(diff)
            assert 0 <= p["initial_dr_stage"] <= 4


class TestDifficultyScaling:
    """Tests that difficulty tiers produce progressively harder patients."""

    def test_glaucoma_iop_increases(self):
        gen = PatientGenerator(seed=42)
        iops = {}
        for diff in ["easy", "medium", "hard"]:
            patients = [gen.generate_glaucoma_patient(diff) for _ in range(50)]
            iops[diff] = sum(p["IOP_baseline"] for p in patients) / 50
        assert iops["easy"] < iops["medium"] < iops["hard"]

    def test_dr_hba1c_increases(self):
        gen = PatientGenerator(seed=42)
        hba1cs = {}
        for diff in ["easy", "medium", "hard"]:
            patients = [gen.generate_dr_patient(diff) for _ in range(50)]
            hba1cs[diff] = sum(p["HbA1c"] for p in patients) / 50
        assert hba1cs["easy"] < hba1cs["medium"] < hba1cs["hard"]
