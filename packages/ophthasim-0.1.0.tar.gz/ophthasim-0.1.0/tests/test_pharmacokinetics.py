"""Tests for anti-VEGF pharmacokinetic model."""

import pytest
import numpy as np

from ophthasim.models.pharmacokinetics import (
    AntiVEGFPharmacokinetics,
    DRUG_LIBRARY,
    PARAMETER_RANGES,
)


class TestPKInit:
    """Tests for PK model initialization."""

    def test_default_init(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        assert pk.drug_name == "ranibizumab"
        assert pk.C_vit == 0.0
        assert pk.injection_count == 0

    def test_all_drugs_init(self):
        for drug in DRUG_LIBRARY:
            pk = AntiVEGFPharmacokinetics(drug=drug, seed=42)
            assert pk.drug_name == drug
            assert pk.k_el > 0

    def test_invalid_drug_raises(self):
        with pytest.raises(AssertionError, match="Unknown drug"):
            AntiVEGFPharmacokinetics(drug="tylenol")

    def test_invalid_volume_raises(self):
        with pytest.raises(AssertionError, match="out of range"):
            AntiVEGFPharmacokinetics(V_vit=10.0)

    def test_all_drug_params_in_range(self):
        for drug, params in DRUG_LIBRARY.items():
            assert params["t_half_days"] > 0
            assert params["dose_mg"] > 0
            assert params["C_0_nM"] > 0


class TestPKInjection:
    """Tests for drug injection mechanics."""

    def test_injection_increases_concentration(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        assert pk.C_vit == 0.0
        c = pk.inject()
        assert c > 0
        assert pk.injection_count == 1

    def test_multiple_injections_accumulate(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        c1 = pk.inject()
        c2 = pk.inject()
        assert c2 > c1  # Second injection adds to residual

    def test_injection_resets_timer(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.step(dt_days=30.0)
        assert pk.time_since_last_injection == float("inf") or pk.time_since_last_injection > 0
        pk.inject()
        assert pk.time_since_last_injection == 0.0


class TestPKDecay:
    """Tests for first-order elimination kinetics."""

    def test_concentration_decreases(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        c0 = pk.C_vit
        pk.step(dt_days=1.0)
        assert pk.C_vit < c0

    def test_half_life(self):
        """Concentration should halve after one half-life."""
        for drug_name, drug_params in DRUG_LIBRARY.items():
            pk = AntiVEGFPharmacokinetics(drug=drug_name, seed=42)
            pk.inject()
            c0 = pk.C_vit
            t_half = drug_params["t_half_days"]
            pk.step(dt_days=t_half)
            assert abs(pk.C_vit - c0 / 2.0) < c0 * 0.01

    def test_exponential_decay_formula(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        c0 = pk.C_vit
        dt = 5.0
        pk.step(dt_days=dt)
        expected = c0 * np.exp(-pk.k_el * dt)
        assert abs(pk.C_vit - expected) < 1.0

    def test_long_term_clearance(self):
        """After many half-lives, concentration should be near zero."""
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        pk.step(dt_days=100.0)  # ~11 half-lives for ranibizumab
        assert pk.C_vit < 10.0  # Near zero (C_0=10000, 11 half-lives -> ~4.9 nM)

    def test_step_days_returns_array(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        concentrations = pk.step_days(30)
        assert concentrations.shape == (30,)
        # Should be monotonically decreasing
        for i in range(len(concentrations) - 1):
            assert concentrations[i] > concentrations[i + 1]


class TestPKDrugSwitching:
    """Tests for drug switching mechanics."""

    def test_switch_drug(self):
        pk = AntiVEGFPharmacokinetics(drug="ranibizumab", seed=42)
        pk.inject()
        old_c = pk.C_vit
        pk.switch_drug("aflibercept")
        assert pk.drug_name == "aflibercept"
        assert pk.C_vit == old_c  # Residual concentration preserved

    def test_switch_updates_half_life(self):
        pk = AntiVEGFPharmacokinetics(drug="ranibizumab", seed=42)
        old_kel = pk.k_el
        pk.switch_drug("aflibercept")
        assert pk.k_el != old_kel

    def test_invalid_switch_raises(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        with pytest.raises(AssertionError):
            pk.switch_drug("unknown_drug")


class TestPKTherapeutic:
    """Tests for therapeutic level checking."""

    def test_not_therapeutic_initially(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        assert not pk.is_therapeutic()

    def test_therapeutic_after_injection(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        assert pk.is_therapeutic()

    def test_custom_threshold(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        assert pk.is_therapeutic(threshold_nM=5000.0)


class TestPKReset:
    """Tests for PK model reset."""

    def test_reset_clears_state(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        pk.step(dt_days=10.0)
        pk.reset()
        assert pk.C_vit == 0.0
        assert pk.time_days == 0.0
        assert pk.injection_count == 0

    def test_reproducibility_after_reset(self):
        pk = AntiVEGFPharmacokinetics(seed=42)
        pk.inject()
        pk.step(dt_days=10.0)
        c1 = pk.C_vit

        pk.reset()
        pk.inject()
        pk.step(dt_days=10.0)
        c2 = pk.C_vit

        # Note: RNG state advances, so c2 == c1 is not guaranteed
        # But PK is deterministic (no RNG used in step/inject)
        assert abs(c1 - c2) < 1e-6
