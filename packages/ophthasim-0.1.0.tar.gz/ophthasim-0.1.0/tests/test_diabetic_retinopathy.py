"""Tests for DiabeticRetinopathy-v0 Gymnasium environment."""

import pytest
import numpy as np
import gymnasium as gym

import ophthasim


class TestDREnvInit:
    """Tests for environment initialization."""

    def test_make_env(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        assert env is not None
        env.close()

    def test_action_space(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        assert isinstance(env.action_space, gym.spaces.Discrete)
        assert env.action_space.n == 5
        env.close()

    def test_observation_space(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        assert isinstance(env.observation_space, gym.spaces.Box)
        assert env.observation_space.shape == (8,)
        env.close()

    def test_all_difficulties(self):
        for diff in ["easy", "medium", "hard"]:
            env = gym.make("ophthasim/DiabeticRetinopathy-v0", difficulty=diff)
            obs, info = env.reset(seed=42)
            assert obs.shape == (8,)
            env.close()


class TestDREnvReset:
    """Tests for environment reset."""

    def test_reset_returns_tuple(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        obs, info = env.reset(seed=42)
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)
        env.close()

    def test_obs_in_space(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        obs, _ = env.reset(seed=42)
        assert env.observation_space.contains(obs)
        env.close()

    def test_info_keys(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        _, info = env.reset(seed=42)
        assert "true_stage" in info
        assert "HbA1c" in info
        assert "VA" in info
        assert "total_screens" in info
        env.close()

    def test_reproducibility(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        obs1, _ = env.reset(seed=42)
        obs2, _ = env.reset(seed=42)
        np.testing.assert_array_equal(obs1, obs2)
        env.close()


class TestDREnvStep:
    """Tests for environment stepping."""

    def test_step_returns_tuple(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        env.reset(seed=42)
        obs, reward, terminated, truncated, info = env.step(0)
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        env.close()

    def test_all_actions_valid(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        for action in range(5):
            env.reset(seed=42)
            obs, reward, _, _, _ = env.step(action)
            assert env.observation_space.contains(obs)
            assert np.isfinite(reward)
        env.close()

    def test_episode_length_40_quarters(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        env.reset(seed=42)
        steps = 0
        terminated, truncated = False, False
        while not (terminated or truncated):
            _, _, terminated, truncated, _ = env.step(0)
            steps += 1
        assert steps == 40
        env.close()

    def test_screening_updates_known_stage(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        env.reset(seed=42)
        # Screen action
        _, _, _, _, info = env.step(1)  # screen_3mo
        assert info["total_screens"] >= 1
        env.close()

    def test_unnecessary_treatment_penalty(self):
        """Anti-VEGF without DME should incur extra penalty."""
        env = gym.make("ophthasim/DiabeticRetinopathy-v0", difficulty="easy")
        env.reset(seed=42)
        # Easy patient likely has no DME initially
        _, r_observe, _, _, _ = env.step(0)
        env.reset(seed=42)
        _, r_treat, _, _, _ = env.step(3)  # anti-VEGF without DME
        # Treatment without indication should have lower reward
        assert r_treat < r_observe + 0.1  # Allow margin for stochastic effects
        env.close()

    def test_obs_in_space_throughout(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        env.reset(seed=42)
        for _ in range(40):
            obs, _, term, trunc, _ = env.step(0)
            assert env.observation_space.contains(obs)
            if term or trunc:
                break
        env.close()


class TestDREnvReward:
    def test_reward_finite(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        env.reset(seed=42)
        for _ in range(40):
            _, reward, term, trunc, _ = env.step(0)
            assert np.isfinite(reward)
            if term or trunc:
                break
        env.close()


class TestDREnvRender:
    def test_ansi_render(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0", render_mode="ansi")
        env.reset(seed=42)
        env.step(0)
        output = env.render()
        assert isinstance(output, str)
        assert "DR" in output
        assert "HbA1c" in output
        env.close()
