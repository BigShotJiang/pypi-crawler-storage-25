"""Tests for training configuration (no actual training -- that requires GPU/time)."""

import pytest

from ophthasim.training.configs import ENV_CONFIGS


class TestTrainingConfigs:
    """Tests for training configuration validity."""

    def test_all_envs_have_configs(self):
        expected_envs = [
            "ophthasim/GlaucomaIOP-v0",
            "ophthasim/AntiVEGF-v0",
            "ophthasim/LaserTrabeculoplasty-v0",
            "ophthasim/DiabeticRetinopathy-v0",
        ]
        for env_id in expected_envs:
            assert env_id in ENV_CONFIGS, f"Missing config for {env_id}"

    def test_required_keys(self):
        required = ["total_timesteps", "learning_rate", "n_steps", "batch_size",
                     "n_epochs", "gamma", "seed"]
        for env_id, config in ENV_CONFIGS.items():
            for key in required:
                assert key in config, f"Missing '{key}' in config for {env_id}"

    def test_gamma_range(self):
        for env_id, config in ENV_CONFIGS.items():
            assert 0.0 < config["gamma"] <= 1.0, f"Invalid gamma for {env_id}"

    def test_learning_rate_positive(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["learning_rate"] > 0, f"Invalid lr for {env_id}"

    def test_timesteps_positive(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["total_timesteps"] > 0

    def test_batch_size_divides_n_steps(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["n_steps"] % config["batch_size"] == 0, (
                f"batch_size must divide n_steps for {env_id}"
            )

    def test_seed_is_int(self):
        for env_id, config in ENV_CONFIGS.items():
            assert isinstance(config["seed"], int)

    def test_dr_has_highest_gamma(self):
        """DR environment has 10-year horizon -- should have highest gamma."""
        dr_gamma = ENV_CONFIGS["ophthasim/DiabeticRetinopathy-v0"]["gamma"]
        for env_id, config in ENV_CONFIGS.items():
            if "DiabeticRetinopathy" not in env_id:
                assert config["gamma"] <= dr_gamma

    def test_anti_vegf_gamma_higher_than_glaucoma(self):
        """Anti-VEGF (24mo) should have higher gamma than Glaucoma (1yr daily)."""
        vegf_gamma = ENV_CONFIGS["ophthasim/AntiVEGF-v0"]["gamma"]
        glaucoma_gamma = ENV_CONFIGS["ophthasim/GlaucomaIOP-v0"]["gamma"]
        assert vegf_gamma >= glaucoma_gamma


class TestPPOImport:
    """Tests for PPO module (without running training)."""

    def test_train_function_exists(self):
        from ophthasim.agents.ppo import train, main
        assert callable(train)
        assert callable(main)

    def test_train_all_exists(self):
        from ophthasim.training.train_all import train_all, main
        assert callable(train_all)
        assert callable(main)
