"""Tests for anti-VEGF pharmacodynamic model."""

import pytest
import numpy as np

from ophthasim.models.pharmacodynamics import (
    AntiVEGFPharmacodynamics,
    DEFAULT_PARAMS,
    PARAMETER_RANGES,
)


class TestPDInit:
    """Tests for PD model initialization."""

    def test_default_init(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        assert pd.CST == DEFAULT_PARAMS["CST_initial"]
        assert pd.VA == DEFAULT_PARAMS["VA_baseline"]
        assert pd.VEGF_free == DEFAULT_PARAMS["VEGF_basal"]

    def test_custom_params(self):
        pd = AntiVEGFPharmacodynamics(params={"CST_initial": 500.0}, seed=42)
        assert pd.CST == 500.0

    def test_invalid_params_raise(self):
        with pytest.raises(AssertionError, match="out of range"):
            AntiVEGFPharmacodynamics(params={"VEGF_basal": 1000.0})

    def test_all_defaults_in_range(self):
        for key, value in DEFAULT_PARAMS.items():
            lo, hi, _ = PARAMETER_RANGES[key]
            assert lo <= value <= hi, f"{key}={value} not in [{lo}, {hi}]"


class TestVEGFSuppression:
    """Tests for VEGF suppression model (Emax)."""

    def test_no_drug_full_vegf(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        vegf = pd.compute_vegf_suppression(0.0)
        assert abs(vegf - DEFAULT_PARAMS["VEGF_basal"]) < 1e-6

    def test_high_drug_low_vegf(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        vegf = pd.compute_vegf_suppression(100000.0)  # Very high concentration
        assert vegf < DEFAULT_PARAMS["VEGF_basal"] * 0.01

    def test_ic50_gives_half_suppression(self):
        """At IC50 concentration, VEGF should be ~half of basal."""
        pd = AntiVEGFPharmacodynamics(seed=42)
        ic50_nM = DEFAULT_PARAMS["IC50_pM"] / 1000.0  # Convert pM to nM
        vegf = pd.compute_vegf_suppression(ic50_nM)
        expected = DEFAULT_PARAMS["VEGF_basal"] / 2.0
        assert abs(vegf - expected) < 1.0

    def test_monotonic_suppression(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        concentrations = [0, 10, 100, 1000, 10000, 100000]
        vegf_values = [pd.compute_vegf_suppression(c) for c in concentrations]
        for i in range(len(vegf_values) - 1):
            assert vegf_values[i] > vegf_values[i + 1]


class TestCSTDynamics:
    """Tests for central subfield thickness dynamics."""

    def test_cst_decreases_with_drug(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        initial_cst = pd.CST
        # Simulate with high drug concentration
        for _ in range(30):
            pd.step_cst(10000.0, dt_days=1.0)
        assert pd.CST < initial_cst

    def test_cst_bounded_below_normal(self):
        """CST should not go below CST_normal."""
        pd = AntiVEGFPharmacodynamics(seed=42)
        for _ in range(1000):
            pd.step_cst(100000.0, dt_days=1.0)
        assert pd.CST >= DEFAULT_PARAMS["CST_normal"]

    def test_cst_rises_without_drug(self):
        """Without drug, elevated VEGF should maintain/increase CST."""
        pd = AntiVEGFPharmacodynamics(seed=42)
        initial_cst = pd.CST
        # Step with no drug for a while
        for _ in range(10):
            pd.step_cst(0.0, dt_days=1.0)
        # CST should be maintained or increase (VEGF drives edema)
        # At least should not dramatically decrease
        assert pd.CST >= initial_cst * 0.95

    def test_time_advances(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        pd.step_cst(1000.0, dt_days=5.0)
        assert abs(pd.time_days - 5.0) < 1e-10


class TestVAModel:
    """Tests for visual acuity response model."""

    def test_va_improves_with_cst_reduction(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        initial_va = pd.compute_va()
        # Reduce CST significantly
        pd.CST = DEFAULT_PARAMS["CST_normal"]
        improved_va = pd.compute_va()
        assert improved_va > initial_va

    def test_va_clamped(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        pd.CST = DEFAULT_PARAMS["CST_normal"]
        va = pd.compute_va()
        assert 0.0 <= va <= 100.0

    def test_va_at_baseline_cst(self):
        """When CST equals baseline, VA should equal VA_baseline."""
        pd = AntiVEGFPharmacodynamics(seed=42)
        va = pd.compute_va()
        assert abs(va - DEFAULT_PARAMS["VA_baseline"]) < 0.1


class TestFullPDStep:
    """Tests for the combined PD step function."""

    def test_step_returns_tuple(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        result = pd.step(1000.0, dt_days=1.0)
        assert len(result) == 3
        vegf, cst, va = result
        assert isinstance(vegf, float)
        assert isinstance(cst, float)
        assert isinstance(va, float)

    def test_step_updates_state(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        pd.step(5000.0, dt_days=1.0)
        state = pd.get_state()
        assert state["time_days"] == 1.0
        assert state["VEGF_free"] < DEFAULT_PARAMS["VEGF_basal"]

    def test_treatment_course(self):
        """Simulate a full treatment course: CST should decrease, VA should improve."""
        pd = AntiVEGFPharmacodynamics(seed=42)
        initial_va = pd.VA
        # Monthly injections for 3 months
        for month in range(3):
            for day in range(30):
                # Simulate decaying drug concentration
                c_vit = 10000.0 * np.exp(-0.077 * day)  # ~9 day half-life
                pd.step(c_vit, dt_days=1.0)
        assert pd.VA >= initial_va - 5.0  # Should not lose significant VA


class TestPDReset:
    """Tests for PD model reset."""

    def test_reset_restores_state(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        pd.step(5000.0, dt_days=30.0)
        pd.reset()
        assert pd.CST == DEFAULT_PARAMS["CST_initial"]
        assert pd.VA == DEFAULT_PARAMS["VA_baseline"]
        assert pd.time_days == 0.0

    def test_reset_with_params(self):
        pd = AntiVEGFPharmacodynamics(seed=42)
        pd.reset(params={"CST_initial": 600.0})
        assert pd.CST == 600.0
