"""Tests for baseline agents (random and heuristic)."""

import pytest
import numpy as np
import gymnasium as gym

import ophthasim
from ophthasim.agents.random_agent import RandomAgent
from ophthasim.agents.heuristic_agent import (
    GlaucomaHeuristicAgent,
    AntiVEGFHeuristicAgent,
    LaserHeuristicAgent,
    DRHeuristicAgent,
    get_heuristic_agent,
)


class TestRandomAgent:
    """Tests for random baseline agent."""

    def test_discrete_action(self):
        space = gym.spaces.Discrete(6)
        agent = RandomAgent(space, seed=42)
        obs = np.zeros(8, dtype=np.float32)
        action = agent.act(obs)
        assert 0 <= action < 6

    def test_multidiscrete_action(self):
        space = gym.spaces.MultiDiscrete([2, 3, 3])
        agent = RandomAgent(space, seed=42)
        obs = np.zeros(7, dtype=np.float32)
        action = agent.act(obs)
        assert action.shape == (3,)
        assert 0 <= action[0] < 2
        assert 0 <= action[1] < 3
        assert 0 <= action[2] < 3

    def test_reproducibility(self):
        space = gym.spaces.Discrete(6)
        a1 = RandomAgent(space, seed=42)
        a2 = RandomAgent(space, seed=42)
        obs = np.zeros(8, dtype=np.float32)
        assert a1.act(obs) == a2.act(obs)

    def test_reset_is_noop(self):
        space = gym.spaces.Discrete(6)
        agent = RandomAgent(space, seed=42)
        agent.reset()  # Should not raise

    def test_random_agent_full_episode(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        obs, _ = env.reset(seed=42)
        agent = RandomAgent(env.action_space, seed=42)
        total_reward = 0.0
        terminated, truncated = False, False
        while not (terminated or truncated):
            action = agent.act(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
        assert np.isfinite(total_reward)
        env.close()


class TestGlaucomaHeuristicAgent:
    """Tests for glaucoma heuristic agent."""

    def test_adds_medication_for_high_iop(self):
        agent = GlaucomaHeuristicAgent(target_iop=16.0)
        # High IOP, no medications active
        obs = np.array([25.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.9, 0.9], dtype=np.float32)
        action = agent.act(obs)
        assert action in (1, 2, 3, 4)  # Should add a medication

    def test_no_change_at_target(self):
        agent = GlaucomaHeuristicAgent(target_iop=16.0)
        # IOP at target, one med active
        obs = np.array([16.0, 0.5, 1.0, 0.0, 0.0, 0.0, 0.9, 0.9], dtype=np.float32)
        action = agent.act(obs)
        assert action == 0  # No change

    def test_full_episode(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        obs, info = env.reset(seed=42)
        agent = GlaucomaHeuristicAgent(target_iop=info["target_iop"], seed=42)
        total_reward = 0.0
        terminated, truncated = False, False
        while not (terminated or truncated):
            action = agent.act(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
        assert np.isfinite(total_reward)
        env.close()


class TestAntiVEGFHeuristicAgent:
    """Tests for anti-VEGF PRN agent."""

    def test_loading_phase_injects(self):
        agent = AntiVEGFHeuristicAgent()
        # Month 0 (normalized: 0/24 = 0)
        obs = np.array([55.0, 0.6, 0.5, 0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        action = agent.act(obs)
        assert action == 1  # Should inject during loading

    def test_full_episode(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        obs, _ = env.reset(seed=42)
        agent = AntiVEGFHeuristicAgent(seed=42)
        total_reward = 0.0
        terminated, truncated = False, False
        while not (terminated or truncated):
            action = agent.act(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
        assert np.isfinite(total_reward)
        env.close()


class TestLaserHeuristicAgent:
    """Tests for SLT heuristic agent."""

    def test_treats_high_iop(self):
        agent = LaserHeuristicAgent()
        # High IOP, long since laser, no previous treatments
        obs = np.array([0.6, 0.6, 0.9, 0.0, 0.65, 0.0, 0.2], dtype=np.float32)
        action = agent.act(obs)
        assert action[0] == 1  # Should treat

    def test_no_treat_low_iop(self):
        agent = LaserHeuristicAgent()
        # Low IOP
        obs = np.array([0.4, 0.3, 0.5, 0.0, 0.65, 0.0, 0.2], dtype=np.float32)
        action = agent.act(obs)
        assert action[0] == 0  # Should not treat

    def test_full_episode(self):
        env = gym.make("ophthasim/LaserTrabeculoplasty-v0")
        obs, _ = env.reset(seed=42)
        agent = LaserHeuristicAgent(seed=42)
        total_reward = 0.0
        terminated, truncated = False, False
        while not (terminated or truncated):
            action = agent.act(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
        assert np.isfinite(total_reward)
        env.close()


class TestDRHeuristicAgent:
    """Tests for DR screening agent."""

    def test_screens_after_long_gap(self):
        agent = DRHeuristicAgent()
        # No DR, long time since screen
        obs = np.array([0.0, 0.0, 0.3, 0.8, 0.8, 0.0, 0.0, 0.2], dtype=np.float32)
        action = agent.act(obs)
        assert action in (1, 2)  # Should screen

    def test_treats_dme(self):
        agent = DRHeuristicAgent()
        # Has DME, not on anti-VEGF
        obs = np.array([0.5, 1.0, 0.5, 0.1, 0.7, 0.0, 0.0, 0.2], dtype=np.float32)
        action = agent.act(obs)
        assert action == 3  # Anti-VEGF for DME

    def test_prp_for_pdr(self):
        agent = DRHeuristicAgent()
        # PDR stage (4/4 = 1.0), no DME, not on PRP
        obs = np.array([1.0, 0.0, 0.5, 0.1, 0.6, 0.0, 0.0, 0.3], dtype=np.float32)
        action = agent.act(obs)
        assert action == 4  # PRP

    def test_full_episode(self):
        env = gym.make("ophthasim/DiabeticRetinopathy-v0")
        obs, _ = env.reset(seed=42)
        agent = DRHeuristicAgent(seed=42)
        total_reward = 0.0
        terminated, truncated = False, False
        while not (terminated or truncated):
            action = agent.act(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
        assert np.isfinite(total_reward)
        env.close()


class TestGetHeuristicAgent:
    """Tests for agent factory function."""

    def test_all_envs(self):
        envs = [
            "ophthasim/GlaucomaIOP-v0",
            "ophthasim/AntiVEGF-v0",
            "ophthasim/LaserTrabeculoplasty-v0",
            "ophthasim/DiabeticRetinopathy-v0",
        ]
        for env_id in envs:
            agent = get_heuristic_agent(env_id)
            assert agent is not None

    def test_invalid_env_raises(self):
        with pytest.raises(AssertionError):
            get_heuristic_agent("ophthasim/NonexistentEnv-v0")

    def test_kwargs_forwarded(self):
        agent = get_heuristic_agent("ophthasim/GlaucomaIOP-v0", target_iop=12.0)
        assert agent.target_iop == 12.0
