"""Tests for benchmark runner."""

import pytest
import numpy as np

import ophthasim
from ophthasim.benchmarks.runner import BenchmarkRunner, ALL_ENVS


class TestBenchmarkRunner:
    """Tests for the benchmark runner."""

    def test_init(self):
        runner = BenchmarkRunner(n_episodes=5, seed=42)
        assert runner.n_episodes == 5
        assert runner.seed == 42
        assert runner.results == {}

    def test_run_single_env(self):
        runner = BenchmarkRunner(n_episodes=3, seed=42)
        results = runner.run_all(env_ids=["ophthasim/GlaucomaIOP-v0"])
        assert "ophthasim/GlaucomaIOP-v0" in results
        assert "random" in results["ophthasim/GlaucomaIOP-v0"]
        assert "heuristic" in results["ophthasim/GlaucomaIOP-v0"]

    def test_result_structure(self):
        runner = BenchmarkRunner(n_episodes=3, seed=42)
        results = runner.run_all(env_ids=["ophthasim/AntiVEGF-v0"])
        stats = results["ophthasim/AntiVEGF-v0"]["random"]
        assert "reward_mean" in stats
        assert "reward_std" in stats
        assert "reward_min" in stats
        assert "reward_max" in stats
        assert "length_mean" in stats
        assert stats["n_episodes"] == 3

    def test_heuristic_beats_random(self):
        """Heuristic agent should generally outperform random."""
        runner = BenchmarkRunner(n_episodes=10, seed=42)
        results = runner.run_all(env_ids=["ophthasim/GlaucomaIOP-v0"])
        random_mean = results["ophthasim/GlaucomaIOP-v0"]["random"]["reward_mean"]
        heuristic_mean = results["ophthasim/GlaucomaIOP-v0"]["heuristic"]["reward_mean"]
        # Heuristic should be better (higher reward)
        assert heuristic_mean > random_mean

    def test_to_json(self):
        runner = BenchmarkRunner(n_episodes=2, seed=42)
        runner.run_all(env_ids=["ophthasim/GlaucomaIOP-v0"])
        json_str = runner.to_json()
        assert isinstance(json_str, str)
        assert "GlaucomaIOP" in json_str

    def test_print_summary(self, capsys):
        runner = BenchmarkRunner(n_episodes=2, seed=42)
        runner.run_all(env_ids=["ophthasim/GlaucomaIOP-v0"])
        runner.print_summary()
        captured = capsys.readouterr()
        assert "BENCHMARK RESULTS" in captured.out

    def test_all_envs_listed(self):
        assert len(ALL_ENVS) == 4
        assert "ophthasim/GlaucomaIOP-v0" in ALL_ENVS
        assert "ophthasim/AntiVEGF-v0" in ALL_ENVS
        assert "ophthasim/LaserTrabeculoplasty-v0" in ALL_ENVS
        assert "ophthasim/DiabeticRetinopathy-v0" in ALL_ENVS

    def test_run_all_envs(self):
        """Run benchmarks on all environments (smoke test)."""
        runner = BenchmarkRunner(n_episodes=2, seed=42)
        results = runner.run_all()
        assert len(results) == 4
        for env_id in ALL_ENVS:
            assert env_id in results
            assert "random" in results[env_id]
            assert "heuristic" in results[env_id]
