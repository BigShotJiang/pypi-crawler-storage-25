"""Tests for AntiVEGF-v0 Gymnasium environment."""

import pytest
import numpy as np
import gymnasium as gym

import ophthasim


class TestAntiVEGFEnvInit:
    """Tests for environment initialization."""

    def test_make_env(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        assert env is not None
        env.close()

    def test_action_space(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        assert isinstance(env.action_space, gym.spaces.Discrete)
        assert env.action_space.n == 3
        env.close()

    def test_observation_space(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        assert isinstance(env.observation_space, gym.spaces.Box)
        assert env.observation_space.shape == (7,)
        env.close()

    def test_all_difficulties(self):
        for diff in ["easy", "medium", "hard"]:
            env = gym.make("ophthasim/AntiVEGF-v0", difficulty=diff)
            obs, info = env.reset(seed=42)
            assert obs.shape == (7,)
            env.close()


class TestAntiVEGFReset:
    """Tests for environment reset."""

    def test_reset_returns_tuple(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        obs, info = env.reset(seed=42)
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)
        env.close()

    def test_obs_in_space(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        obs, _ = env.reset(seed=42)
        assert env.observation_space.contains(obs)
        env.close()

    def test_info_keys(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        _, info = env.reset(seed=42)
        assert "VA" in info
        assert "CST" in info
        assert "injection_count" in info
        assert "drug" in info
        env.close()

    def test_reproducibility(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        obs1, _ = env.reset(seed=42)
        obs2, _ = env.reset(seed=42)
        np.testing.assert_array_equal(obs1, obs2)
        env.close()


class TestAntiVEGFStep:
    """Tests for environment stepping."""

    def test_step_returns_tuple(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        obs, reward, terminated, truncated, info = env.step(0)
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        env.close()

    def test_all_actions_valid(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        for action in range(3):
            env.reset(seed=42)
            obs, reward, _, _, info = env.step(action)
            assert env.observation_space.contains(obs)
        env.close()

    def test_episode_length_24_months(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        steps = 0
        terminated = False
        truncated = False
        while not (terminated or truncated):
            _, _, terminated, truncated, info = env.step(0)
            steps += 1
        assert steps == 24
        env.close()

    def test_injection_increases_count(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        _, _, _, _, info = env.step(1)  # Inject
        assert info["injection_count"] == 1
        env.close()

    def test_drug_switch(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        _, _, _, _, info_before = env.step(1)  # Inject ranibizumab
        drug_before = info_before["drug"]
        _, _, _, _, info_after = env.step(2)  # Switch and inject
        assert info_after["drug"] != drug_before
        env.close()

    def test_wait_no_injection(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        _, _, _, _, info = env.step(0)  # Wait
        assert info["injection_count"] == 0
        env.close()


class TestAntiVEGFReward:
    """Tests for reward structure."""

    def test_injection_has_cost(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        _, r_wait, _, _, _ = env.step(0)
        env.reset(seed=42)
        _, r_inject, _, _, _ = env.step(1)
        # Injection should incur burden cost
        # (exact comparison depends on VA change, but burden is constant)
        env.close()

    def test_reward_finite(self):
        env = gym.make("ophthasim/AntiVEGF-v0")
        env.reset(seed=42)
        for _ in range(24):
            _, reward, term, trunc, _ = env.step(1)
            assert np.isfinite(reward)
            if term or trunc:
                break
        env.close()


class TestAntiVEGFRender:
    def test_ansi_render(self):
        env = gym.make("ophthasim/AntiVEGF-v0", render_mode="ansi")
        env.reset(seed=42)
        env.step(1)
        output = env.render()
        assert isinstance(output, str)
        assert "VA" in output
        assert "CST" in output
        env.close()
