"""Tests for GlaucomaIOP-v0 Gymnasium environment."""

import pytest
import numpy as np
import gymnasium as gym

import ophthasim  # Register environments


class TestGlaucomaIOPEnvInit:
    """Tests for environment initialization."""

    def test_make_env(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        assert env is not None
        env.close()

    def test_action_space(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        assert isinstance(env.action_space, gym.spaces.Discrete)
        assert env.action_space.n == 6
        env.close()

    def test_observation_space(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        assert isinstance(env.observation_space, gym.spaces.Box)
        assert env.observation_space.shape == (8,)
        env.close()

    def test_difficulty_tiers(self):
        for diff in ["easy", "medium", "hard"]:
            env = gym.make("ophthasim/GlaucomaIOP-v0", difficulty=diff)
            obs, info = env.reset(seed=42)
            assert obs.shape == (8,)
            env.close()


class TestGlaucomaIOPReset:
    """Tests for environment reset."""

    def test_reset_returns_tuple(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        result = env.reset(seed=42)
        assert isinstance(result, tuple)
        assert len(result) == 2
        obs, info = result
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)
        env.close()

    def test_obs_in_space(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        obs, _ = env.reset(seed=42)
        assert env.observation_space.contains(obs)
        env.close()

    def test_info_keys(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        _, info = env.reset(seed=42)
        assert "true_iop" in info
        assert "target_iop" in info
        assert "day" in info
        env.close()

    def test_reproducibility(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        obs1, _ = env.reset(seed=42)
        obs2, _ = env.reset(seed=42)
        np.testing.assert_array_equal(obs1, obs2)
        env.close()


class TestGlaucomaIOPStep:
    """Tests for environment stepping."""

    def test_step_returns_tuple(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        result = env.step(0)
        assert len(result) == 5
        obs, reward, terminated, truncated, info = result
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)
        env.close()

    def test_obs_in_space_after_step(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        obs, _, _, _, _ = env.step(0)
        assert env.observation_space.contains(obs)
        env.close()

    def test_all_actions_valid(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        for action in range(6):
            obs, reward, terminated, truncated, info = env.step(action)
            if terminated or truncated:
                env.reset(seed=42)
        env.close()

    def test_episode_truncates_at_365(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        for day in range(365):
            obs, reward, terminated, truncated, info = env.step(0)
            if terminated:
                break
        # Should be truncated or terminated by day 365
        assert terminated or truncated
        env.close()

    def test_medication_adds_to_model(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        # Action 1 = start prostaglandin
        env.step(1)
        info = env.step(0)[4]
        # Check that medication was potentially added (compliance-dependent)
        assert isinstance(info["active_medications"], list)
        env.close()

    def test_high_iop_terminates(self):
        """Environment should terminate if IOP > 40 mmHg."""
        env = gym.make("ophthasim/GlaucomaIOP-v0", difficulty="hard")
        env.reset(seed=42)
        # Run many steps - hard difficulty may trigger termination
        terminated = False
        for _ in range(365):
            _, _, term, trunc, _ = env.step(0)
            if term:
                terminated = True
                break
            if trunc:
                break
        # We can't guarantee termination, but the path exists
        env.close()


class TestGlaucomaIOPReward:
    """Tests for reward structure."""

    def test_reward_is_float(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        _, reward, _, _, _ = env.step(0)
        assert isinstance(reward, float)

    def test_reward_finite(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0")
        env.reset(seed=42)
        for _ in range(100):
            _, reward, terminated, truncated, _ = env.step(0)
            assert np.isfinite(reward)
            if terminated or truncated:
                break
        env.close()


class TestGlaucomaIOPRender:
    """Tests for rendering."""

    def test_ansi_render(self):
        env = gym.make("ophthasim/GlaucomaIOP-v0", render_mode="ansi")
        env.reset(seed=42)
        env.step(0)
        output = env.render()
        assert isinstance(output, str)
        assert "Day" in output
        assert "IOP" in output
        env.close()
