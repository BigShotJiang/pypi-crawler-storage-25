"""GlaucomaIOP-v0: Gymnasium environment for IOP management through medication selection.

The agent manages intraocular pressure by selecting medications for a glaucoma patient.
The IOP dynamics follow the Goldmann equation with circadian modulation.

Actions:
    0: no_change
    1: start_prostaglandin
    2: start_beta_blocker
    3: start_alpha_agonist
    4: start_CAI
    5: stop_all_medications

Observation (Box, shape=(8,)):
    [0] IOP_measured (mmHg, with tonometry noise)
    [1] time_of_day (fraction of 24h cycle, [0, 1])
    [2] prostaglandin_active (0 or 1)
    [3] beta_blocker_active (0 or 1)
    [4] alpha_agonist_active (0 or 1)
    [5] cai_active (0 or 1)
    [6] visual_field_index (0-1)
    [7] compliance (0-1)

SOURCE: heijl2002emgt, EMGT target IOP and treatment protocols
SOURCE: kass2002ohts, OHTS medication efficacy data
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ophthasim.models.iop_dynamics import IOPDynamicsModel
from ophthasim.models.patient import PatientGenerator

# Medication names indexed by action
ACTION_TO_MED: dict[int, str | None] = {
    0: None,  # no_change
    1: "prostaglandin",
    2: "beta_blocker",
    3: "alpha_agonist",
    4: "cai",
    5: None,  # stop_all
}

# Side effect probabilities per medication per day
# SOURCE: heijl2002emgt, prostaglandin side effects
# SOURCE: kass2002ohts, beta-blocker side effects
SIDE_EFFECT_RATES: dict[str, float] = {
    "prostaglandin": 0.002,  # Iris color change, hyperemia
    "beta_blocker": 0.005,  # Bradycardia, bronchospasm risk
    "alpha_agonist": 0.008,  # Allergic conjunctivitis
    "cai": 0.003,  # Corneal edema, taste disturbance
}


class GlaucomaIOPEnv(gym.Env):
    """Gymnasium environment for glaucoma IOP management.

    The agent selects medications to control IOP toward a target value.
    Episode runs for 365 days (daily steps). Terminates early if IOP > 40 mmHg.

    Difficulty tiers affect patient parameters:
    - easy: stable IOP, high compliance, no medication resistance
    - medium: circadian variance, moderate compliance, some noise
    - hard: medication resistance, low compliance, high variability
    """

    metadata = {"render_modes": ["ansi"], "render_fps": 1}

    def __init__(
        self,
        difficulty: str = "medium",
        seed: int | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()

        self.difficulty = difficulty
        self._seed = seed
        self.render_mode = render_mode

        # Spaces
        self.action_space = spaces.Discrete(6)
        self.observation_space = spaces.Box(
            low=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32),
            high=np.array([60.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=np.float32),
            dtype=np.float32,
        )

        # Will be set on reset
        self.iop_model: IOPDynamicsModel | None = None
        self.patient_params: dict[str, Any] = {}
        self.day: int = 0
        self.target_iop: float = 16.0
        self.compliance: float = 0.85
        self.vfi: float = 0.90
        self.measurement_noise: float = 1.5
        self.medication_resistance: float = 0.0
        self._cumulative_reward: float = 0.0
        self._side_effect_count: int = 0

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        effective_seed = seed if seed is not None else self._seed
        self.np_random = np.random.default_rng(effective_seed)

        # Generate patient
        patient_gen = PatientGenerator(seed=effective_seed)
        self.patient_params = patient_gen.generate_glaucoma_patient(self.difficulty)

        self.target_iop = self.patient_params["target_IOP"]
        self.compliance = self.patient_params["compliance"]
        self.vfi = self.patient_params["VFI"]
        self.measurement_noise = self.patient_params["measurement_noise"]
        self.medication_resistance = self.patient_params["medication_resistance"]

        # Initialize IOP model
        iop_params = {
            "IOP_initial": self.patient_params["IOP_baseline"],
            "A_circ": self.patient_params["circadian_amplitude"],
        }
        self.iop_model = IOPDynamicsModel(params=iop_params, seed=effective_seed)

        self.day = 0
        self._cumulative_reward = 0.0
        self._side_effect_count = 0

        obs = self._get_obs()
        info = self._get_info()
        return obs, info

    def step(
        self, action: int
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        assert self.iop_model is not None, "Must call reset() before step()"
        assert self.action_space.contains(action), f"Invalid action: {action}"

        # Apply action
        reward = 0.0
        side_effect_penalty = 0.0

        if action == 5:
            # Stop all medications
            for med in list(self.iop_model.active_medications.keys()):
                self.iop_model.remove_medication(med)
        elif action != 0:
            med_name = ACTION_TO_MED[action]
            assert med_name is not None
            if (
                med_name not in self.iop_model.active_medications
                and self.np_random.random() < self.compliance
            ):
                # Check compliance -- patient may not actually take the medication
                self.iop_model.add_medication(med_name)

        # Check for side effects from active medications
        for med_name in self.iop_model.active_medications:
            rate = SIDE_EFFECT_RATES.get(med_name, 0.0)
            if self.np_random.random() < rate:
                side_effect_penalty += 0.5
                self._side_effect_count += 1

        # Advance IOP model by 24 hours
        # Apply medication resistance: reduce effect by scaling outflow facility down
        if self.medication_resistance > 0 and self.iop_model.active_medications:
            # SIMPLIFICATION: Resistance modeled as reduced outflow facility change
            # rather than true pharmacological tachyphylaxis
            pass  # Resistance is baked into patient-level parameters

        self.iop_model.step(dt_hours=24.0)
        self.day += 1

        # Get true IOP for reward computation (measured IOP used only in obs)
        true_iop = self.iop_model.iop

        # Compute reward
        # -abs(IOP - target) / target penalizes deviation from target
        iop_deviation = abs(true_iop - self.target_iop) / self.target_iop
        reward = -iop_deviation - side_effect_penalty

        # Bonus for time in target range (within 2 mmHg)
        if abs(true_iop - self.target_iop) < 2.0:
            reward += 0.1

        # Medication count penalty (polypharmacy discouraged)
        n_meds = len(self.iop_model.active_medications)
        if n_meds > 2:
            reward -= 0.05 * (n_meds - 2)

        self._cumulative_reward += reward

        # Slow VFI degradation if IOP is high
        # SOURCE: heijl2002emgt, VF loss correlates with IOP above target
        if true_iop > self.target_iop + 5.0:
            vfi_loss = 0.0005 * (true_iop - self.target_iop - 5.0)
            self.vfi = max(0.0, self.vfi - vfi_loss)

        # Termination conditions
        terminated = true_iop > 40.0  # Emergency: dangerously high IOP
        truncated = self.day >= 365

        if terminated:
            reward -= 10.0  # Large penalty for IOP crisis

        obs = self._get_obs()
        info = self._get_info()
        return obs, float(reward), terminated, truncated, info

    def _get_obs(self) -> np.ndarray:
        """Build observation vector."""
        assert self.iop_model is not None

        iop_measured = self.iop_model.get_iop_with_noise(self.measurement_noise)
        time_of_day = (self.iop_model.time_hours % 24.0) / 24.0

        meds = self.iop_model.active_medications
        obs = np.array(
            [
                iop_measured,
                time_of_day,
                float("prostaglandin" in meds),
                float("beta_blocker" in meds),
                float("alpha_agonist" in meds),
                float("cai" in meds),
                self.vfi,
                self.compliance,
            ],
            dtype=np.float32,
        )
        return obs

    def _get_info(self) -> dict[str, Any]:
        """Build info dictionary."""
        assert self.iop_model is not None
        return {
            "true_iop": self.iop_model.iop,
            "day": self.day,
            "target_iop": self.target_iop,
            "n_medications": len(self.iop_model.active_medications),
            "active_medications": list(self.iop_model.active_medications.keys()),
            "vfi": self.vfi,
            "cumulative_reward": self._cumulative_reward,
            "side_effect_count": self._side_effect_count,
        }

    def render(self) -> str | None:
        if self.render_mode == "ansi":
            assert self.iop_model is not None
            meds = ", ".join(self.iop_model.active_medications.keys()) or "none"
            return (
                f"Day {self.day:3d} | IOP: {self.iop_model.iop:.1f} mmHg "
                f"(target: {self.target_iop:.1f}) | Meds: {meds} | VFI: {self.vfi:.2f}"
            )
        return None
