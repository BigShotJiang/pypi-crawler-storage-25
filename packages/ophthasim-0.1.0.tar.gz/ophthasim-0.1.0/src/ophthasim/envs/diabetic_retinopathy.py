"""DiabeticRetinopathy-v0: Gymnasium environment for DR screening and treatment.

The agent manages diabetic retinopathy screening intervals and treatment
escalation over a 10-year horizon (120 months, quarterly steps).

Actions:
    0: observe (no action this quarter)
    1: screen_3mo (schedule next screen in 3 months)
    2: screen_6mo (schedule next screen in 6 months)
    3: anti_vegf_for_dme (treat DME with anti-VEGF)
    4: prp_for_pdr (panretinal photocoagulation for PDR)

Observation (Box, shape=(8,)):
    [0] DR_stage (normalized /4)
    [1] has_DME (0 or 1)
    [2] HbA1c (normalized: (HbA1c - 4) / 11)
    [3] time_since_screen (quarters, /8 normalized)
    [4] VA (ETDRS letters, /100 normalized)
    [5] on_anti_vegf (0 or 1)
    [6] on_prp (0 or 1)
    [7] quarter_in_episode (/40 normalized)

SOURCE: klein1994wisconsin, WESDR screening intervals and progression
SOURCE: aiello1998prp, PRP treatment protocols
SOURCE: diabeticretinopathydrstudy2015protocol, anti-VEGF for DME
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ophthasim.models.patient import PatientGenerator
from ophthasim.models.retinal_progression import DiabeticRetinopathyProgression

# Cost/burden weights (arbitrary units for reward shaping)
SCREENING_COST = 0.1  # Per screening visit
ANTI_VEGF_COST = 0.5  # Per anti-VEGF injection
PRP_COST = 0.8  # Per PRP session
VISION_LOSS_COST = 2.0  # Per ETDRS letter lost
EARLY_DETECTION_BONUS = 1.0  # Catching progression early


class DiabeticRetinopathyEnv(gym.Env):
    """Gymnasium environment for DR screening and treatment management.

    Episode runs for 40 quarters (10 years) with quarterly decision steps.
    The agent balances screening/treatment costs against vision preservation.

    SIMPLIFICATION: Quarterly decision steps (3-month granularity). Real-world
    DR management has variable follow-up intervals and concurrent systemic care.
    """

    metadata = {"render_modes": ["ansi"], "render_fps": 1}

    def __init__(
        self,
        difficulty: str = "medium",
        seed: int | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()

        self.difficulty = difficulty
        self._seed = seed
        self.render_mode = render_mode

        self.action_space = spaces.Discrete(5)
        self.observation_space = spaces.Box(
            low=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32),
            high=np.array([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=np.float32),
            dtype=np.float32,
        )

        # State
        self.dr_model: DiabeticRetinopathyProgression | None = None
        self.quarter: int = 0
        self.quarters_since_screen: int = 0
        self.last_known_stage: int = 0
        self.last_known_dme: bool = False
        self.VA: float = 80.0
        self.VA_initial: float = 80.0
        self.HbA1c: float = 8.0
        self.hba1c_volatility: float = 0.5
        self.total_screens: int = 0
        self.total_anti_vegf: int = 0
        self.total_prp: int = 0
        self._cumulative_reward: float = 0.0
        self._prev_stage: int = 0

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        effective_seed = seed if seed is not None else self._seed
        self.np_random = np.random.default_rng(effective_seed)

        # Generate patient
        patient_gen = PatientGenerator(seed=effective_seed)
        patient = patient_gen.generate_dr_patient(self.difficulty)

        self.HbA1c = patient["HbA1c"]
        self.hba1c_volatility = patient["hba1c_volatility"]
        self.VA = patient["VA_baseline"]
        self.VA_initial = patient["VA_baseline"]

        # Initialize DR progression model
        self.dr_model = DiabeticRetinopathyProgression(
            initial_stage=int(patient["initial_dr_stage"]),
            HbA1c=self.HbA1c,
            seed=effective_seed,
        )

        self.quarter = 0
        self.quarters_since_screen = 0
        self.last_known_stage = int(patient["initial_dr_stage"])
        self.last_known_dme = False
        self._prev_stage = int(patient["initial_dr_stage"])
        self.total_screens = 0
        self.total_anti_vegf = 0
        self.total_prp = 0
        self._cumulative_reward = 0.0

        # Initial screening
        self.total_screens = 1
        self.quarters_since_screen = 0

        obs = self._get_obs()
        info = self._get_info()
        return obs, info

    def step(
        self, action: int
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        assert self.dr_model is not None
        assert self.action_space.contains(action), f"Invalid action: {action}"

        reward = 0.0

        # HbA1c drifts over time
        # SIMPLIFICATION: Random walk model for HbA1c, bounded to clinical range
        hba1c_change = self.np_random.normal(0.0, self.hba1c_volatility * 0.1)
        self.HbA1c = float(np.clip(self.HbA1c + hba1c_change, 5.0, 14.0))
        self.dr_model.HbA1c = self.HbA1c

        # Apply treatment actions
        if action == 3:
            # Anti-VEGF for DME
            if self.last_known_dme:
                self.dr_model.start_anti_vegf()
                self.total_anti_vegf += 1
                reward -= ANTI_VEGF_COST
            else:
                # Unnecessary treatment penalty
                reward -= ANTI_VEGF_COST * 1.5

        elif action == 4:
            # PRP for PDR
            if self.last_known_stage >= 3:
                self.dr_model.start_prp()
                self.total_prp += 1
                reward -= PRP_COST
            else:
                # Unnecessary PRP penalty
                reward -= PRP_COST * 1.5

        # Advance DR model one quarter
        self._prev_stage = self.dr_model.stage
        new_stage, has_dme = self.dr_model.step()

        # Screening actions
        screened_this_quarter = False
        if action in (1, 2):
            # Screening visit
            self.total_screens += 1
            self.quarters_since_screen = 0
            self.last_known_stage = new_stage
            self.last_known_dme = has_dme
            reward -= SCREENING_COST
            screened_this_quarter = True

            # Early detection bonus
            if new_stage > self._prev_stage:
                reward += EARLY_DETECTION_BONUS
        else:
            self.quarters_since_screen += 1

        # Vision loss from undetected/untreated disease
        vision_loss_risk = self.dr_model.get_vision_loss_risk()

        # Undetected progression increases risk
        if not screened_this_quarter and self.quarters_since_screen > 4:
            vision_loss_risk *= 1.5  # Penalty for infrequent screening

        # Sample vision loss
        if self.np_random.random() < vision_loss_risk:
            letters_lost = self.np_random.uniform(1.0, 5.0)
            # Untreated DME causes more loss
            if has_dme and not self.dr_model.on_anti_vegf:
                letters_lost *= 2.0
            self.VA = max(0.0, self.VA - letters_lost)
            reward -= letters_lost * VISION_LOSS_COST / 5.0  # Normalized

        self.quarter += 1
        self._cumulative_reward += reward

        # Termination
        terminated = False
        truncated = self.quarter >= 40

        obs = self._get_obs()
        info = self._get_info()
        return obs, float(reward), terminated, truncated, info

    def _get_obs(self) -> np.ndarray:
        assert self.dr_model is not None
        return np.array(
            [
                self.last_known_stage / 4.0,
                float(self.last_known_dme),
                (self.HbA1c - 4.0) / 11.0,
                min(self.quarters_since_screen / 8.0, 1.0),
                self.VA / 100.0,
                float(self.dr_model.on_anti_vegf),
                float(self.dr_model.on_prp),
                min(self.quarter / 40.0, 1.0),
            ],
            dtype=np.float32,
        )

    def _get_info(self) -> dict[str, Any]:
        assert self.dr_model is not None
        return {
            "quarter": self.quarter,
            "true_stage": self.dr_model.stage,
            "true_stage_name": self.dr_model.get_state_name(),
            "true_dme": self.dr_model.has_dme,
            "last_known_stage": self.last_known_stage,
            "last_known_dme": self.last_known_dme,
            "HbA1c": self.HbA1c,
            "VA": self.VA,
            "VA_initial": self.VA_initial,
            "total_screens": self.total_screens,
            "total_anti_vegf": self.total_anti_vegf,
            "total_prp": self.total_prp,
            "quarters_since_screen": self.quarters_since_screen,
            "cumulative_reward": self._cumulative_reward,
        }

    def render(self) -> str | None:
        if self.render_mode == "ansi":
            assert self.dr_model is not None
            return (
                f"Q{self.quarter:2d} | DR: {self.dr_model.get_state_name()} "
                f"| DME: {'Y' if self.dr_model.has_dme else 'N'} "
                f"| HbA1c: {self.HbA1c:.1f}% "
                f"| VA: {self.VA:.1f} letters "
                f"| Screens: {self.total_screens}"
            )
        return None
