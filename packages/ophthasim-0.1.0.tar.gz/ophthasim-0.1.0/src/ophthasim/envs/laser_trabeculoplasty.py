"""LaserTrabeculoplasty-v0: Gymnasium environment for SLT parameter optimization.

The agent decides when to perform selective laser trabeculoplasty (SLT),
coverage angle, and energy level. IOP response follows a probabilistic
success model with exponential decay of effect over time.

Actions (MultiDiscrete([2, 3, 3])):
    [0] treat_now: 0=no, 1=yes
    [1] coverage: 0=180, 1=270, 2=360 degrees
    [2] energy: 0=low(0.4mJ), 1=medium(0.8mJ), 2=high(1.2mJ)

Observation (Box, shape=(7,)):
    [0] IOP_baseline (mmHg, /50 normalized)
    [1] IOP_current (mmHg, /50 normalized)
    [2] months_since_laser (/36 normalized)
    [3] previous_treatments (/5 normalized)
    [4] age (/100 normalized)
    [5] lens_status (0=phakic, 1=pseudophakic)
    [6] month_in_episode (/36 normalized)

SOURCE: latina1998qswitchedlaser, SLT mechanism and outcomes
SOURCE: mcalinden2014slt, SLT success rates and retreatment
SOURCE: gazzard2019ligo, LiGHT trial SLT outcomes
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ophthasim.models.patient import PatientGenerator

# Coverage angles in degrees
COVERAGE_OPTIONS = [180, 270, 360]

# Energy levels in mJ
ENERGY_OPTIONS = [0.4, 0.8, 1.2]

# Complication rates by energy level
# SOURCE: latina1998qswitchedlaser
COMPLICATION_RATES: dict[float, float] = {
    0.4: 0.01,  # Low energy: minimal risk
    0.8: 0.03,  # Medium energy: standard risk
    1.2: 0.06,  # High energy: elevated IOP spike risk
}


class LaserTrabeculoplastyEnv(gym.Env):
    """Gymnasium environment for SLT treatment optimization.

    Episode runs for 36 months with monthly decision steps.
    The agent optimizes IOP reduction through SLT timing and parameters.

    SLT success model:
        P_success = sigmoid(-2.0 + 0.08 * IOP_baseline + 3.0 * (coverage/360))
        delta_IOP_pct = Normal(mean=0.25, std=0.08) * IOP_baseline
        IOP_reduction(t) = delta_IOP * exp(-0.023 * t_months)

    SOURCE: mcalinden2014slt, success probability model
    SOURCE: gazzard2019ligo, durability of SLT effect
    """

    metadata = {"render_modes": ["ansi"], "render_fps": 1}

    def __init__(
        self,
        difficulty: str = "medium",
        seed: int | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()

        self.difficulty = difficulty
        self._seed = seed
        self.render_mode = render_mode

        # MultiDiscrete: [treat_now(2), coverage(3), energy(3)]
        self.action_space = spaces.MultiDiscrete([2, 3, 3])
        self.observation_space = spaces.Box(
            low=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32),
            high=np.array([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=np.float32),
            dtype=np.float32,
        )

        # State
        self.iop_baseline: float = 28.0
        self.iop_current: float = 28.0
        self.month: int = 0
        self.months_since_laser: int = 99
        self.treatment_count: int = 0
        self.age: float = 65.0
        self.lens_status: int = 0
        self.response_multiplier: float = 1.0
        self._active_treatments: list[dict[str, float]] = []
        self._cumulative_reward: float = 0.0
        self._complication_count: int = 0

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        effective_seed = seed if seed is not None else self._seed
        self.np_random = np.random.default_rng(effective_seed)

        # Generate patient
        patient_gen = PatientGenerator(seed=effective_seed)
        patient = patient_gen.generate_laser_patient(self.difficulty)

        self.iop_baseline = patient["IOP_baseline"]
        self.iop_current = patient["IOP_baseline"]
        self.age = patient["age"]
        self.lens_status = int(patient["lens_status"])
        self.response_multiplier = patient["response_multiplier"]
        self.treatment_count = int(patient.get("previous_laser_count", 0))

        self.month = 0
        self.months_since_laser = 99
        self._active_treatments = []
        self._cumulative_reward = 0.0
        self._complication_count = 0

        obs = self._get_obs()
        info = self._get_info()
        return obs, info

    def _compute_success_probability(self, coverage_deg: int) -> float:
        """Compute SLT success probability.

        P_success = sigmoid(-2.0 + 0.08 * IOP_baseline + 3.0 * (coverage/360))

        SOURCE: mcalinden2014slt
        """
        logit = -2.0 + 0.08 * self.iop_current + 3.0 * (coverage_deg / 360.0)
        prob = 1.0 / (1.0 + np.exp(-logit))
        return float(prob * self.response_multiplier)

    def _apply_iop_reduction(self) -> float:
        """Compute total IOP reduction from all active treatments.

        Each treatment's effect decays exponentially:
            reduction(t) = delta_IOP * exp(-0.023 * t_months)

        SOURCE: gazzard2019ligo, SLT durability ~30-month effective duration
        """
        total_reduction = 0.0
        for tx in self._active_treatments:
            months_elapsed = self.month - tx["start_month"]
            # Decay rate: 0.023/month gives ~50% effect at 30 months
            # SOURCE: gazzard2019ligo
            decay = np.exp(-0.023 * months_elapsed)
            total_reduction += tx["delta_iop"] * decay
        return total_reduction

    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        assert self.action_space.contains(action), f"Invalid action: {action}"

        treat_now = int(action[0])
        coverage_idx = int(action[1])
        energy_idx = int(action[2])

        reward = 0.0
        complication = False

        if treat_now == 1:
            coverage_deg = COVERAGE_OPTIONS[coverage_idx]
            energy_mj = ENERGY_OPTIONS[energy_idx]

            # Retreatment penalty (diminishing returns)
            # SOURCE: mcalinden2014slt, repeat SLT less effective
            retreatment_factor = 0.7 ** self.treatment_count

            # Check for success
            p_success = self._compute_success_probability(coverage_deg)
            p_success *= retreatment_factor

            if self.np_random.random() < min(p_success, 0.95):
                # Successful treatment
                delta_iop_pct = self.np_random.normal(0.25, 0.08)
                delta_iop_pct = max(0.05, min(0.45, delta_iop_pct))
                delta_iop = delta_iop_pct * self.iop_current * self.response_multiplier

                self._active_treatments.append({
                    "start_month": self.month,
                    "delta_iop": delta_iop,
                    "coverage": coverage_deg,
                    "energy": energy_mj,
                })

            # Check for complications (IOP spike)
            # SOURCE: latina1998qswitchedlaser
            comp_rate = COMPLICATION_RATES[energy_mj]
            if self.np_random.random() < comp_rate:
                complication = True
                self._complication_count += 1
                reward -= 2.0  # Complication penalty

            self.treatment_count += 1
            self.months_since_laser = 0
            reward -= 0.5  # Treatment burden (procedure cost/risk)
        else:
            self.months_since_laser += 1

        # Update IOP
        reduction = self._apply_iop_reduction()
        # Add monthly IOP noise
        noise = self.np_random.normal(0.0, 1.0)
        self.iop_current = max(5.0, self.iop_baseline - reduction + noise)

        if complication:
            # Transient IOP spike (resolves next month)
            self.iop_current += self.np_random.uniform(5.0, 15.0)

        self.month += 1

        # IOP-based reward
        # Good: IOP < 21 mmHg
        if self.iop_current <= 21.0:
            reward += 0.3
        elif self.iop_current <= 24.0:
            reward += 0.1
        else:
            reward -= 0.1 * (self.iop_current - 24.0) / 10.0

        # Excessive treatment penalty
        if self.treatment_count > 3:
            reward -= 0.3

        self._cumulative_reward += reward

        terminated = False
        truncated = self.month >= 36

        obs = self._get_obs()
        info = self._get_info()
        return obs, float(reward), terminated, truncated, info

    def _get_obs(self) -> np.ndarray:
        return np.array(
            [
                min(self.iop_baseline / 50.0, 1.0),
                min(self.iop_current / 50.0, 1.0),
                min(self.months_since_laser / 36.0, 1.0),
                min(self.treatment_count / 5.0, 1.0),
                min(self.age / 100.0, 1.0),
                float(self.lens_status),
                min(self.month / 36.0, 1.0),
            ],
            dtype=np.float32,
        )

    def _get_info(self) -> dict[str, Any]:
        return {
            "month": self.month,
            "iop_baseline": self.iop_baseline,
            "iop_current": self.iop_current,
            "treatment_count": self.treatment_count,
            "months_since_laser": self.months_since_laser,
            "active_treatments": len(self._active_treatments),
            "complication_count": self._complication_count,
            "cumulative_reward": self._cumulative_reward,
        }

    def render(self) -> str | None:
        if self.render_mode == "ansi":
            return (
                f"Month {self.month:2d} | IOP: {self.iop_current:.1f} mmHg "
                f"(baseline: {self.iop_baseline:.1f}) "
                f"| Treatments: {self.treatment_count} "
                f"| Since laser: {self.months_since_laser}mo"
            )
        return None
