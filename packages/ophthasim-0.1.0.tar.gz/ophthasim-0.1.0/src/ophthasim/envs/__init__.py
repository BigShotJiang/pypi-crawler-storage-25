"""Gymnasium environment registration for OpthaSim."""

from __future__ import annotations

import gymnasium as gym


def register_envs() -> None:
    """Register all OpthaSim environments with Gymnasium."""
    gym.register(
        id="ophthasim/GlaucomaIOP-v0",
        entry_point="ophthasim.envs.glaucoma_iop:GlaucomaIOPEnv",
        max_episode_steps=365,
    )
    gym.register(
        id="ophthasim/AntiVEGF-v0",
        entry_point="ophthasim.envs.anti_vegf:AntiVEGFEnv",
        max_episode_steps=24,
    )
    gym.register(
        id="ophthasim/LaserTrabeculoplasty-v0",
        entry_point="ophthasim.envs.laser_trabeculoplasty:LaserTrabeculoplastyEnv",
        max_episode_steps=36,
    )
    gym.register(
        id="ophthasim/DiabeticRetinopathy-v0",
        entry_point="ophthasim.envs.diabetic_retinopathy:DiabeticRetinopathyEnv",
        max_episode_steps=40,
    )
