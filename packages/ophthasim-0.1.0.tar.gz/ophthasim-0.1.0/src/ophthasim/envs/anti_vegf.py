"""AntiVEGF-v0: Gymnasium environment for anti-VEGF injection timing optimization.

The agent decides monthly whether to inject, wait, or switch drugs for a
wet AMD patient. PK/PD models drive CST and VA dynamics.

Actions:
    0: wait_month (no injection)
    1: inject_same_drug
    2: switch_drug (cycles through ranibizumab -> aflibercept -> bevacizumab)

Observation (Box, shape=(7,)):
    [0] VA_current (ETDRS letters, 0-100)
    [1] CST_current (um, normalized to [0, 1] via /700)
    [2] VEGF_estimate (pg/mL, normalized to [0, 1] via /600)
    [3] time_since_injection (months, /24 normalized)
    [4] injection_count (normalized /30)
    [5] drug_type (0=ranibizumab, 0.5=aflibercept, 1.0=bevacizumab)
    [6] month_in_episode (normalized /24)

SOURCE: rosenfeld2006ranibizumab, MARINA trial treatment protocol
SOURCE: heier2012aflibercept, VIEW1/VIEW2 switching criteria
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ophthasim.models.patient import PatientGenerator
from ophthasim.models.pharmacodynamics import AntiVEGFPharmacodynamics
from ophthasim.models.pharmacokinetics import DRUG_LIBRARY, AntiVEGFPharmacokinetics

DRUG_LIST = list(DRUG_LIBRARY.keys())  # ["ranibizumab", "aflibercept", "bevacizumab"]
DRUG_TO_INDEX: dict[str, float] = {
    "ranibizumab": 0.0,
    "aflibercept": 0.5,
    "bevacizumab": 1.0,
}


class AntiVEGFEnv(gym.Env):
    """Gymnasium environment for anti-VEGF treatment optimization in wet AMD.

    Episode runs for 24 months with monthly decision steps. The agent balances
    visual acuity outcomes against injection burden.

    Reward = VA_improvement - injection_burden - vision_loss_penalty
    """

    metadata = {"render_modes": ["ansi"], "render_fps": 1}

    def __init__(
        self,
        difficulty: str = "medium",
        seed: int | None = None,
        render_mode: str | None = None,
    ) -> None:
        super().__init__()

        self.difficulty = difficulty
        self._seed = seed
        self.render_mode = render_mode

        self.action_space = spaces.Discrete(3)
        self.observation_space = spaces.Box(
            low=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32),
            high=np.array([100.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=np.float32),
            dtype=np.float32,
        )

        # Will be initialized on reset
        self.pk_model: AntiVEGFPharmacokinetics | None = None
        self.pd_model: AntiVEGFPharmacodynamics | None = None
        self.month: int = 0
        self.injection_count: int = 0
        self.time_since_injection: int = 0
        self.current_drug_idx: int = 0
        self.VA_initial: float = 55.0
        self.VA_best: float = 55.0
        self._cumulative_reward: float = 0.0

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        effective_seed = seed if seed is not None else self._seed
        self.np_random = np.random.default_rng(effective_seed)

        # Generate patient
        patient_gen = PatientGenerator(seed=effective_seed)
        patient = patient_gen.generate_anti_vegf_patient(self.difficulty)

        # Initialize PK
        self.current_drug_idx = 0
        drug_name = DRUG_LIST[self.current_drug_idx]
        self.pk_model = AntiVEGFPharmacokinetics(drug=drug_name, seed=effective_seed)

        # Initialize PD with patient parameters
        pd_params = {
            "VA_baseline": patient["VA_baseline"],
            "CST_initial": patient["CST_baseline"],
            "VEGF_basal": patient["VEGF_basal"],
            "alpha": patient["CST_alpha"],
            "beta": patient["CST_beta"],
        }
        self.pd_model = AntiVEGFPharmacodynamics(params=pd_params, seed=effective_seed)

        self.VA_initial = patient["VA_baseline"]
        self.VA_best = patient["VA_baseline"]
        self.month = 0
        self.injection_count = 0
        self.time_since_injection = 99  # Never injected
        self._cumulative_reward = 0.0
        self._drug_response = patient["drug_response"]

        obs = self._get_obs()
        info = self._get_info()
        return obs, info

    def step(
        self, action: int
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        assert self.pk_model is not None and self.pd_model is not None
        assert self.action_space.contains(action), f"Invalid action: {action}"

        # Apply action
        if action == 1:
            # Inject same drug
            self.pk_model.inject()
            self.injection_count += 1
            self.time_since_injection = 0
        elif action == 2:
            # Switch drug and inject
            self.current_drug_idx = (self.current_drug_idx + 1) % len(DRUG_LIST)
            new_drug = DRUG_LIST[self.current_drug_idx]
            self.pk_model.switch_drug(new_drug)
            self.pk_model.inject()
            self.injection_count += 1
            self.time_since_injection = 0
        else:
            # Wait
            self.time_since_injection += 1

        # Advance PK by 30 days (1 month)
        # SIMPLIFICATION: All months are 30 days
        for _ in range(30):
            self.pk_model.step(dt_days=1.0)
            c_vit = self.pk_model.get_concentration()
            # Apply drug response modifier
            effective_c = c_vit * self._drug_response
            self.pd_model.step(effective_c, dt_days=1.0)

        self.month += 1

        # Get current clinical state
        va_current = self.pd_model.compute_va()
        self.VA_best = max(self.VA_best, va_current)

        # Compute reward
        reward = 0.0

        # VA improvement from baseline (positive is good)
        va_change = va_current - self.VA_initial
        reward += va_change * 0.02  # Scale factor

        # Injection burden penalty
        if action in (1, 2):
            reward -= 0.3  # Each injection has cost/risk

        # Drug switch penalty (additional)
        if action == 2:
            reward -= 0.2

        # Vision loss penalty (losing > 10 letters from best)
        if va_current < self.VA_best - 10.0:
            reward -= 0.5

        # Severe vision loss
        if va_current < 35.0:
            reward -= 1.0

        self._cumulative_reward += reward

        # Episode ends at 24 months
        terminated = False
        truncated = self.month >= 24

        obs = self._get_obs()
        info = self._get_info()
        return obs, float(reward), terminated, truncated, info

    def _get_obs(self) -> np.ndarray:
        assert self.pk_model is not None and self.pd_model is not None

        drug_name = DRUG_LIST[self.current_drug_idx]
        obs = np.array(
            [
                self.pd_model.VA,
                min(self.pd_model.CST / 700.0, 1.0),
                min(self.pd_model.VEGF_free / 600.0, 1.0),
                min(self.time_since_injection / 24.0, 1.0),
                min(self.injection_count / 30.0, 1.0),
                DRUG_TO_INDEX[drug_name],
                min(self.month / 24.0, 1.0),
            ],
            dtype=np.float32,
        )
        return obs

    def _get_info(self) -> dict[str, Any]:
        assert self.pk_model is not None and self.pd_model is not None
        return {
            "month": self.month,
            "VA": self.pd_model.VA,
            "CST": self.pd_model.CST,
            "VEGF_free": self.pd_model.VEGF_free,
            "C_vit": self.pk_model.get_concentration(),
            "injection_count": self.injection_count,
            "drug": DRUG_LIST[self.current_drug_idx],
            "VA_initial": self.VA_initial,
            "VA_best": self.VA_best,
            "cumulative_reward": self._cumulative_reward,
        }

    def render(self) -> str | None:
        if self.render_mode == "ansi":
            assert self.pd_model is not None
            return (
                f"Month {self.month:2d} | VA: {self.pd_model.VA:.1f} letters "
                f"| CST: {self.pd_model.CST:.0f} um "
                f"| Injections: {self.injection_count} "
                f"| Drug: {DRUG_LIST[self.current_drug_idx]}"
            )
        return None
