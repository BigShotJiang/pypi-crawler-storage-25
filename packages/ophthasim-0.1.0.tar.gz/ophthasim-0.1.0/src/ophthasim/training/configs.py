"""Shared training configurations for all OpthaSim environments.

These configs are used by both the PPO training wrapper and the train_all script.
Parameters are tuned for stable learning on each environment's characteristics.
"""

from __future__ import annotations

ENV_CONFIGS: dict[str, dict] = {
    "ophthasim/GlaucomaIOP-v0": {
        "total_timesteps": 500_000,
        "learning_rate": 3e-4,
        "n_steps": 2048,
        "batch_size": 64,
        "n_epochs": 10,
        "gamma": 0.99,
        "seed": 42,
    },
    "ophthasim/AntiVEGF-v0": {
        "total_timesteps": 500_000,
        "learning_rate": 3e-4,
        "n_steps": 2048,
        "batch_size": 64,
        "n_epochs": 10,
        "gamma": 0.995,  # Long horizon (24 months)
        "seed": 42,
    },
    "ophthasim/LaserTrabeculoplasty-v0": {
        "total_timesteps": 300_000,
        "learning_rate": 1e-3,
        "n_steps": 1024,
        "batch_size": 64,
        "n_epochs": 10,
        "gamma": 0.99,
        "seed": 42,
    },
    "ophthasim/DiabeticRetinopathy-v0": {
        "total_timesteps": 500_000,
        "learning_rate": 3e-4,
        "n_steps": 2048,
        "batch_size": 64,
        "n_epochs": 10,
        "gamma": 0.999,  # Very long horizon (10 years)
        "seed": 42,
    },
}
