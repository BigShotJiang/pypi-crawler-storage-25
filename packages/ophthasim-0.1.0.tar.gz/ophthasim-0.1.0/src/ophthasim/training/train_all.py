"""Train PPO agents on all OpthaSim environments sequentially.

Usage:
    python -m ophthasim.training.train_all [--output-dir results/models]
"""

from __future__ import annotations

import argparse
from pathlib import Path

from ophthasim.training.configs import ENV_CONFIGS


def train_all(output_dir: str = "results/models") -> list[Path]:
    """Train PPO agents on all registered environments.

    Args:
        output_dir: Base directory for saved models.

    Returns:
        List of paths to saved models.
    """
    from ophthasim.agents.ppo import train

    saved = []
    for env_id in ENV_CONFIGS:
        print(f"\n{'='*60}")
        print(f"Training: {env_id}")
        print(f"{'='*60}")
        path = train(env_id=env_id, output_dir=output_dir)
        saved.append(path)
        print(f"Saved: {path}")

    return saved


def main() -> None:
    parser = argparse.ArgumentParser(description="Train PPO on all OpthaSim environments")
    parser.add_argument(
        "--output-dir",
        type=str,
        default="results/models",
        help="Directory to save trained models",
    )
    args = parser.parse_args()
    train_all(output_dir=args.output_dir)


if __name__ == "__main__":
    main()
