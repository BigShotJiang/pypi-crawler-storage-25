"""Training utilities for OpthaSim environments."""

from ophthasim.training.configs import ENV_CONFIGS

__all__ = ["ENV_CONFIGS"]
