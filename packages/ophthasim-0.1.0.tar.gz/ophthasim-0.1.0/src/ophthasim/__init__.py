"""OpthaSim: Gymnasium-compatible RL environments for ophthalmic treatment optimization."""

__version__ = "0.1.0"

from ophthasim.envs import register_envs

register_envs()
