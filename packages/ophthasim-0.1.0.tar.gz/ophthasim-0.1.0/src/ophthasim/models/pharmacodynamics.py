"""Anti-VEGF pharmacodynamic model: VEGF suppression, CST response, and VA outcomes.

Models the downstream effects of vitreous anti-VEGF drug concentration on:
1. Free VEGF levels (Emax-style inhibition)
2. Central subfield thickness (CST) - edema response
3. Visual acuity (VA) - functional outcome

SOURCE: papadopoulos2012pharmacokinetics, VEGF IC50 and basal levels
SOURCE: rosenfeld2006ranibizumab, MARINA trial VA/CST outcomes
SOURCE: heier2012aflibercept, VIEW1/VIEW2 trial CST/VA data
"""

from __future__ import annotations

import numpy as np

# ============================================================================
# Parameter ranges
# ============================================================================

PARAMETER_RANGES: dict[str, tuple[float, float, str]] = {
    "VEGF_basal": (100.0, 600.0, "papadopoulos2012pharmacokinetics"),  # pg/mL
    "IC50_pM": (200.0, 1500.0, "papadopoulos2012pharmacokinetics"),  # pM
    "CST_normal": (200.0, 300.0, "rosenfeld2006ranibizumab"),  # um
    "CST_initial": (250.0, 700.0, "rosenfeld2006ranibizumab"),  # um, wet AMD range
    "alpha": (0.1, 1.0, "heier2012aflibercept"),  # um/day per pg/mL VEGF
    "beta": (0.005, 0.05, "heier2012aflibercept"),  # 1/day, CST restoration rate
    "gamma": (5.0, 25.0, "rosenfeld2006ranibizumab"),  # ETDRS letters per ln-unit CST
    "VA_baseline": (40.0, 75.0, "rosenfeld2006ranibizumab"),  # ETDRS letters
}

# ============================================================================
# Default parameters
# ============================================================================

DEFAULT_PARAMS: dict[str, float] = {
    "VEGF_basal": 300.0,  # SOURCE: papadopoulos2012pharmacokinetics, pg/mL
    "IC50_pM": 675.0,  # SOURCE: papadopoulos2012pharmacokinetics, pM
    "CST_normal": 250.0,  # SOURCE: rosenfeld2006ranibizumab, um
    "CST_initial": 450.0,  # SOURCE: rosenfeld2006ranibizumab, typical wet AMD
    "alpha": 0.5,  # SOURCE: heier2012aflibercept, um/day per pg/mL VEGF
    "beta": 0.02,  # SOURCE: heier2012aflibercept, 1/day CST restoration
    "gamma": 15.0,  # SOURCE: rosenfeld2006ranibizumab, ETDRS letters per ln-unit
    "VA_baseline": 55.0,  # SOURCE: rosenfeld2006ranibizumab, typical wet AMD baseline
}

# ============================================================================
# Concentration conversion
# ============================================================================

# Drug concentrations are tracked in nM; VEGF IC50 is in pM
# 1 nM = 1000 pM
_NM_TO_PM = 1000.0


def _validate_params(params: dict[str, float]) -> None:
    """Validate PD parameters against literature-backed ranges."""
    for key, value in params.items():
        if key in PARAMETER_RANGES:
            lo, hi, source = PARAMETER_RANGES[key]
            assert lo <= value <= hi, (
                f"PD parameter '{key}' = {value} out of range [{lo}, {hi}] "
                f"(SOURCE: {source})"
            )


class AntiVEGFPharmacodynamics:
    """Pharmacodynamic model linking drug concentration to clinical outcomes.

    Three coupled models:
    1. VEGF suppression: VEGF_free(t) = VEGF_basal * IC50 / (C_vit(t) + IC50)
    2. CST dynamics: dCST/dt = alpha * VEGF_free(t) - beta * (CST - CST_normal)
    3. VA response: VA = VA_baseline + gamma * ln(CST_baseline / max(CST, CST_normal))

    SIMPLIFICATION: VA model uses a log-linear relationship with CST. In reality,
    VA recovery depends on photoreceptor integrity, duration of edema, and
    irreversible structural damage not captured here.
    """

    def __init__(
        self,
        params: dict[str, float] | None = None,
        seed: int | None = None,
    ) -> None:
        self.params = {**DEFAULT_PARAMS, **(params or {})}
        _validate_params(self.params)
        self.rng = np.random.default_rng(seed)

        # State
        self.CST: float = self.params["CST_initial"]
        self.CST_baseline: float = self.params["CST_initial"]
        self.VA: float = self.params["VA_baseline"]
        self.VEGF_free: float = self.params["VEGF_basal"]  # No drug initially
        self.time_days: float = 0.0

    def reset(self, params: dict[str, float] | None = None) -> None:
        """Reset PD state to initial conditions."""
        if params is not None:
            self.params.update(params)
            _validate_params(self.params)
        self.CST = self.params["CST_initial"]
        self.CST_baseline = self.params["CST_initial"]
        self.VA = self.params["VA_baseline"]
        self.VEGF_free = self.params["VEGF_basal"]
        self.time_days = 0.0

    def compute_vegf_suppression(self, C_vit_nM: float) -> float:
        """Compute free VEGF level given drug concentration.

        Uses Emax model:
            VEGF_free = VEGF_basal * IC50 / (C_drug_pM + IC50)

        SOURCE: papadopoulos2012pharmacokinetics

        Args:
            C_vit_nM: Vitreous drug concentration in nM.

        Returns:
            Free VEGF concentration in pg/mL.
        """
        C_pM = C_vit_nM * _NM_TO_PM
        IC50 = self.params["IC50_pM"]
        VEGF_basal = self.params["VEGF_basal"]

        self.VEGF_free = VEGF_basal * IC50 / (C_pM + IC50)
        return self.VEGF_free

    def step_cst(self, C_vit_nM: float, dt_days: float = 1.0) -> float:
        """Advance CST dynamics by one time step.

        dCST/dt = alpha * VEGF_free - beta * (CST - CST_normal)

        Uses Euler integration.
        SIMPLIFICATION: Euler integration with daily steps. A stiff ODE solver
        would be more accurate but this is adequate for the time scales involved.

        Args:
            C_vit_nM: Current vitreous drug concentration in nM.
            dt_days: Time step in days.

        Returns:
            Updated CST in um.
        """
        p = self.params
        vegf_free = self.compute_vegf_suppression(C_vit_nM)

        # CST ODE (Euler step)
        dCST = p["alpha"] * vegf_free - p["beta"] * (self.CST - p["CST_normal"])
        self.CST += dCST * dt_days

        # CST cannot go below normal
        self.CST = max(self.CST, p["CST_normal"])

        self.time_days += dt_days
        return self.CST

    def compute_va(self) -> float:
        """Compute visual acuity from current CST.

        VA = VA_baseline + gamma * ln(CST_baseline / max(CST, CST_normal))

        SOURCE: rosenfeld2006ranibizumab, log-linear CST-VA relationship

        Returns:
            Visual acuity in ETDRS letters.
        """
        p = self.params
        cst_effective = max(self.CST, p["CST_normal"])

        # VA improvement is proportional to log of CST reduction
        va = p["VA_baseline"] + p["gamma"] * np.log(
            self.CST_baseline / cst_effective
        )

        # Clamp to valid ETDRS range
        self.VA = float(np.clip(va, 0.0, 100.0))
        return self.VA

    def step(self, C_vit_nM: float, dt_days: float = 1.0) -> tuple[float, float, float]:
        """Full PD step: update VEGF, CST, and VA.

        Args:
            C_vit_nM: Current vitreous drug concentration in nM.
            dt_days: Time step in days.

        Returns:
            Tuple of (VEGF_free, CST, VA).
        """
        self.step_cst(C_vit_nM, dt_days)
        va = self.compute_va()
        return (self.VEGF_free, self.CST, va)

    def get_state(self) -> dict[str, float]:
        """Get current PD state."""
        return {
            "VEGF_free": self.VEGF_free,
            "CST": self.CST,
            "VA": self.VA,
            "time_days": self.time_days,
        }
