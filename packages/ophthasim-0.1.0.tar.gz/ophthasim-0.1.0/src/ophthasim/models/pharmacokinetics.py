"""One-compartment pharmacokinetic model for intravitreal anti-VEGF drugs.

Models drug concentration in the vitreous humor following intravitreal injection
using first-order elimination kinetics:

    dC_vit/dt = -k_el * C_vit
    On injection: C_vit += dose / V_vit

SOURCE: gadkar2015pharmacokinetics, ranibizumab vitreous half-life and PK
SOURCE: stewart2012pharmacokinetics, bevacizumab vitreous half-life
SOURCE: kaiser2021intravitreal, aflibercept PK parameters
SOURCE: shatz2016vitreous, vitreous humor volume
"""

from __future__ import annotations

import numpy as np

# ============================================================================
# Parameter ranges
# ============================================================================

PARAMETER_RANGES: dict[str, tuple[float, float, str]] = {
    "V_vit": (3.0, 5.5, "shatz2016vitreous"),  # mL, vitreous volume
    "t_half_days": (4.0, 20.0, "gadkar2015pharmacokinetics"),  # days, vitreous half-life
    "dose_mg": (0.05, 6.0, "kaiser2021intravitreal"),  # mg, injection dose
    "molecular_weight_kda": (25.0, 150.0, "gadkar2015pharmacokinetics"),  # kDa
}

# ============================================================================
# Drug library
# ============================================================================

# Each drug specifies: half-life, dose, initial concentration estimate, MW
# SOURCE: gadkar2015pharmacokinetics (ranibizumab)
# SOURCE: stewart2012pharmacokinetics (bevacizumab)
# SOURCE: kaiser2021intravitreal (aflibercept)

DRUG_LIBRARY: dict[str, dict[str, float]] = {
    "ranibizumab": {
        "t_half_days": 9.0,  # SOURCE: gadkar2015pharmacokinetics
        "dose_mg": 0.5,  # Standard clinical dose
        "molecular_weight_kda": 48.0,  # Fab fragment
        "C_0_nM": 10000.0,  # SOURCE: gadkar2015pharmacokinetics, initial vitreous conc
    },
    "aflibercept": {
        "t_half_days": 11.4,  # SOURCE: kaiser2021intravitreal
        "dose_mg": 2.0,  # Standard clinical dose
        "molecular_weight_kda": 115.0,  # Fc fusion protein
        "C_0_nM": 25000.0,  # SOURCE: kaiser2021intravitreal
    },
    "bevacizumab": {
        "t_half_days": 8.25,  # SOURCE: stewart2012pharmacokinetics
        "dose_mg": 1.25,  # Standard off-label dose
        "molecular_weight_kda": 149.0,  # Full IgG antibody
        "C_0_nM": 12000.0,  # SOURCE: stewart2012pharmacokinetics
    },
}


def _validate_params(params: dict[str, float]) -> None:
    """Validate parameters against literature-backed ranges."""
    for key, value in params.items():
        if key in PARAMETER_RANGES:
            lo, hi, source = PARAMETER_RANGES[key]
            assert lo <= value <= hi, (
                f"PK parameter '{key}' = {value} out of range [{lo}, {hi}] "
                f"(SOURCE: {source})"
            )


class AntiVEGFPharmacokinetics:
    """One-compartment PK model for intravitreal anti-VEGF drugs.

    Models vitreous drug concentration with first-order elimination:
        C(t) = C_0 * exp(-k_el * t)
    where k_el = ln(2) / t_half

    SIMPLIFICATION: Assumes instantaneous mixing in vitreous upon injection.
    Real-world vitreous is a gel with diffusion gradients, but the well-mixed
    compartment assumption is standard for clinical PK modeling.
    """

    def __init__(
        self,
        drug: str = "ranibizumab",
        V_vit: float = 4.0,
        seed: int | None = None,
    ) -> None:
        """Initialize PK model.

        Args:
            drug: Drug name from DRUG_LIBRARY.
            V_vit: Vitreous volume in mL. SOURCE: shatz2016vitreous
            seed: RNG seed for reproducibility.
        """
        assert drug in DRUG_LIBRARY, (
            f"Unknown drug '{drug}'. Valid: {list(DRUG_LIBRARY.keys())}"
        )
        _validate_params({"V_vit": V_vit})

        self.drug_name = drug
        self.drug_params = DRUG_LIBRARY[drug].copy()
        self.V_vit = V_vit
        self.rng = np.random.default_rng(seed)

        # Elimination rate constant
        self.k_el = np.log(2) / self.drug_params["t_half_days"]

        # State
        self.C_vit: float = 0.0  # nM, vitreous drug concentration
        self.time_days: float = 0.0
        self.injection_count: int = 0
        self.time_since_last_injection: float = float("inf")

    def reset(self) -> None:
        """Reset PK state to drug-free."""
        self.C_vit = 0.0
        self.time_days = 0.0
        self.injection_count = 0
        self.time_since_last_injection = float("inf")

    def inject(self) -> float:
        """Administer an intravitreal injection.

        Returns:
            Post-injection vitreous concentration in nM.
        """
        # Add concentration from new dose
        # C_addition = dose / (V_vit * MW) converted to nM
        # SIMPLIFICATION: We use the literature-reported C_0 directly rather
        # than computing from dose/volume/MW, since C_0 accounts for binding
        # and distribution effects measured in vivo.
        self.C_vit += self.drug_params["C_0_nM"]
        self.injection_count += 1
        self.time_since_last_injection = 0.0
        return self.C_vit

    def step(self, dt_days: float = 1.0) -> float:
        """Advance PK model by dt_days using analytical solution.

        Args:
            dt_days: Time step in days.

        Returns:
            Current vitreous concentration in nM.
        """
        assert dt_days > 0, f"Time step must be positive, got {dt_days}"

        # Analytical solution of first-order decay
        self.C_vit *= np.exp(-self.k_el * dt_days)
        self.time_days += dt_days
        self.time_since_last_injection += dt_days

        return self.C_vit

    def step_days(self, n_days: int = 30) -> np.ndarray:
        """Advance PK model for n_days, returning daily concentrations.

        Args:
            n_days: Number of days to simulate.

        Returns:
            Array of vitreous concentrations (shape: (n_days,)).
        """
        concentrations = np.empty(n_days)
        for i in range(n_days):
            concentrations[i] = self.step(dt_days=1.0)
        return concentrations

    def get_concentration(self) -> float:
        """Get current vitreous drug concentration in nM."""
        return self.C_vit

    def switch_drug(self, new_drug: str) -> None:
        """Switch to a different anti-VEGF drug.

        Retains any residual concentration from the previous drug.
        SIMPLIFICATION: Cross-drug residual concentration is carried over
        without PK conversion. In reality, different molecular weights and
        binding affinities would affect the transition.

        Args:
            new_drug: Drug name from DRUG_LIBRARY.
        """
        assert new_drug in DRUG_LIBRARY, (
            f"Unknown drug '{new_drug}'. Valid: {list(DRUG_LIBRARY.keys())}"
        )
        self.drug_name = new_drug
        self.drug_params = DRUG_LIBRARY[new_drug].copy()
        self.k_el = np.log(2) / self.drug_params["t_half_days"]

    def get_half_life(self) -> float:
        """Get current drug's vitreous half-life in days."""
        return self.drug_params["t_half_days"]

    def is_therapeutic(self, threshold_nM: float = 100.0) -> bool:
        """Check if drug concentration is above therapeutic threshold.

        Args:
            threshold_nM: Therapeutic threshold in nM.
                SIMPLIFICATION: Uses a single threshold for all drugs.
                Real therapeutic windows vary by drug and target.

        Returns:
            True if concentration exceeds threshold.
        """
        return self.C_vit >= threshold_nM
