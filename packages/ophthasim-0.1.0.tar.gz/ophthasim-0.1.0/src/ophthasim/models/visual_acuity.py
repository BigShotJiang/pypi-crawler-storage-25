"""Visual acuity conversion utilities (ETDRS letters, Snellen fraction, LogMAR).

Conversions follow standard clinical ophthalmology conventions.

Reference scale:
    - 85 ETDRS letters = 20/20 Snellen = 0.0 LogMAR
    - Each ETDRS line = 5 letters = 0.1 LogMAR
    - 0 ETDRS letters = 20/20000 (approximate) = 1.7 LogMAR

SOURCE: ferris1982newvisualacuity, original ETDRS chart calibration
SOURCE: bailey1976newdesign, LogMAR scale definition
"""

from __future__ import annotations

import numpy as np

# PARAMETER_RANGES: ETDRS letters in [0, 100], LogMAR in [-0.3, 1.7]
ETDRS_MIN = 0
ETDRS_MAX = 100
LOGMAR_MIN = -0.3
LOGMAR_MAX = 1.7

# Conversion constants
# SOURCE: ferris1982newvisualacuity
# 85 ETDRS letters = LogMAR 0.0, each letter = 0.02 LogMAR
_ETDRS_AT_ZERO_LOGMAR = 85.0  # SOURCE: ferris1982newvisualacuity
_LOGMAR_PER_LETTER = 0.02  # SOURCE: bailey1976newdesign

# Common Snellen denominators and their LogMAR equivalents
# SOURCE: holladay1997propersedmethod
_SNELLEN_LOGMAR_MAP: dict[int, float] = {
    10: -0.3,
    12: -0.2,  # SIMPLIFICATION: 12.5 rounded to 12
    16: -0.1,
    20: 0.0,
    25: 0.1,
    32: 0.2,  # SIMPLIFICATION: 31.5 rounded to 32
    40: 0.3,
    50: 0.4,
    63: 0.5,  # SIMPLIFICATION: 62.5 rounded to 63
    80: 0.6,
    100: 0.7,
    125: 0.8,
    160: 0.9,
    200: 1.0,
    250: 1.1,
    320: 1.2,  # SIMPLIFICATION: 315 rounded to 320
    400: 1.3,
    500: 1.4,
    630: 1.5,  # SIMPLIFICATION: 625 rounded to 630
    800: 1.6,
}


def etdrs_to_logmar(etdrs_letters: float) -> float:
    """Convert ETDRS letter score to LogMAR.

    Args:
        etdrs_letters: ETDRS letter score (0-100).

    Returns:
        LogMAR value.
    """
    assert ETDRS_MIN <= etdrs_letters <= ETDRS_MAX, (
        f"ETDRS letters must be in [{ETDRS_MIN}, {ETDRS_MAX}], got {etdrs_letters}"
    )
    return (_ETDRS_AT_ZERO_LOGMAR - etdrs_letters) * _LOGMAR_PER_LETTER


def logmar_to_etdrs(logmar: float) -> float:
    """Convert LogMAR to ETDRS letter score.

    Args:
        logmar: LogMAR value.

    Returns:
        ETDRS letter score (clamped to [0, 100]).
    """
    assert LOGMAR_MIN <= logmar <= LOGMAR_MAX, (
        f"LogMAR must be in [{LOGMAR_MIN}, {LOGMAR_MAX}], got {logmar}"
    )
    letters = _ETDRS_AT_ZERO_LOGMAR - logmar / _LOGMAR_PER_LETTER
    return float(np.clip(letters, ETDRS_MIN, ETDRS_MAX))


def snellen_to_logmar(numerator: int, denominator: int) -> float:
    """Convert Snellen fraction to LogMAR.

    Uses the formula: LogMAR = log10(denominator / numerator).

    Args:
        numerator: Snellen numerator (typically 20).
        denominator: Snellen denominator.

    Returns:
        LogMAR value.

    SOURCE: bailey1976newdesign
    """
    assert numerator > 0, f"Snellen numerator must be positive, got {numerator}"
    assert denominator > 0, f"Snellen denominator must be positive, got {denominator}"
    return float(np.log10(denominator / numerator))


def logmar_to_snellen(logmar: float, numerator: int = 20) -> tuple[int, int]:
    """Convert LogMAR to Snellen fraction.

    Finds the closest standard Snellen denominator.

    Args:
        logmar: LogMAR value.
        numerator: Snellen numerator (default 20).

    Returns:
        Tuple of (numerator, denominator).
    """
    exact_denom = numerator * (10**logmar)
    # Find closest standard denominator
    best_denom = min(_SNELLEN_LOGMAR_MAP.keys(), key=lambda d: abs(d - exact_denom))
    return (numerator, best_denom)


def etdrs_to_snellen(etdrs_letters: float, numerator: int = 20) -> tuple[int, int]:
    """Convert ETDRS letters to Snellen fraction."""
    logmar = etdrs_to_logmar(etdrs_letters)
    return logmar_to_snellen(logmar, numerator)


def snellen_to_etdrs(numerator: int, denominator: int) -> float:
    """Convert Snellen fraction to ETDRS letters."""
    logmar = snellen_to_logmar(numerator, denominator)
    return logmar_to_etdrs(logmar)
