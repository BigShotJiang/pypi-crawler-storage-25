"""Goldmann-equation IOP dynamics with circadian modulation and medication effects.

The model solves the Goldmann ODE for aqueous humor dynamics:
    dIOP/dt = (1/K) * [F_in(t) - C * (IOP - P_e) - F_u]

where F_in(t) includes circadian modulation:
    F_in(t) = F_in_mean * (1 + A_circ * cos(2*pi*(t - phi)/24))

SOURCE: goldmann1951minute, original Goldmann equation
SOURCE: brubaker1991flow, aqueous production rate F_in_mean = 2.75 uL/min
SOURCE: bill1966conventional, uveoscleral outflow F_u = 0.8 uL/min
SOURCE: toris2002aqueoushumor, outflow facility C = 0.28 uL/min/mmHg
SOURCE: liu1998circadian, circadian IOP variation amplitude ~30%
"""

from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp

# ============================================================================
# Parameter ranges with literature sources
# ============================================================================

PARAMETER_RANGES: dict[str, tuple[float, float, str]] = {
    "F_in_mean": (1.5, 4.5, "brubaker1991flow"),  # uL/min, aqueous production
    "C": (0.10, 0.50, "toris2002aqueoushumor"),  # uL/min/mmHg, outflow facility
    "F_u": (0.3, 1.5, "bill1966conventional"),  # uL/min, uveoscleral outflow
    "P_e": (7.0, 12.0, "brubaker1991flow"),  # mmHg, episcleral venous pressure
    "K": (0.5, 3.0, "friedenwald1937tonometer"),  # uL/mmHg, ocular compliance
    "A_circ": (0.0, 0.5, "liu1998circadian"),  # circadian amplitude fraction
    "phi": (0.0, 6.0, "liu1998circadian"),  # circadian peak hour (AM)
    "IOP_initial": (8.0, 35.0, "kass2002ohts"),  # mmHg, initial IOP
}

# ============================================================================
# Default parameter values
# ============================================================================

DEFAULT_PARAMS: dict[str, float] = {
    "F_in_mean": 2.75,  # SOURCE: brubaker1991flow, aqueous production rate
    "C": 0.28,  # SOURCE: toris2002aqueoushumor, outflow facility
    "F_u": 0.80,  # SOURCE: bill1966conventional, uveoscleral outflow
    "P_e": 9.0,  # SOURCE: brubaker1991flow, episcleral venous pressure
    "K": 1.5,  # SOURCE: friedenwald1937tonometer, ocular compliance
    "A_circ": 0.30,  # SOURCE: liu1998circadian, 30% circadian amplitude
    "phi": 2.0,  # SOURCE: liu1998circadian, peak at 2 AM
    "IOP_initial": 21.0,  # SOURCE: kass2002ohts, untreated OHTS baseline
}

# ============================================================================
# Medication effects
# ============================================================================

# SOURCE: heijl2002emgt, prostaglandin analog efficacy
# SOURCE: kass2002ohts, beta-blocker efficacy
# SOURCE: krupin1999alphagan, brimonidine (alpha-agonist) efficacy
# SOURCE: lippa1992dorzolamide, CAI efficacy

MEDICATION_EFFECTS: dict[str, dict[str, float]] = {
    "prostaglandin": {
        "F_u_multiplier": 1.65,  # SOURCE: heijl2002emgt, increases F_u by 50-80%
        "F_in_multiplier": 1.0,
        "onset_days": 3.0,  # SIMPLIFICATION: linear ramp over onset period
        "max_effect_days": 14.0,
    },
    "beta_blocker": {
        "F_u_multiplier": 1.0,
        "F_in_multiplier": 0.70,  # SOURCE: kass2002ohts, reduces F_in by 25-35%
        "onset_days": 1.0,
        "max_effect_days": 7.0,
    },
    "alpha_agonist": {
        "F_u_multiplier": 1.10,  # SOURCE: krupin1999alphagan, increases F_u by ~10%
        "F_in_multiplier": 0.775,  # SOURCE: krupin1999alphagan, reduces F_in by 20-25%
        "onset_days": 2.0,
        "max_effect_days": 7.0,
    },
    "cai": {
        "F_u_multiplier": 1.0,
        "F_in_multiplier": 0.80,  # SOURCE: lippa1992dorzolamide, reduces F_in by 15-25%
        "onset_days": 2.0,
        "max_effect_days": 7.0,
    },
}


def _validate_params(params: dict[str, float]) -> None:
    """Validate all parameters are within literature-backed ranges."""
    for key, value in params.items():
        if key in PARAMETER_RANGES:
            lo, hi, source = PARAMETER_RANGES[key]
            assert lo <= value <= hi, (
                f"Parameter '{key}' = {value} out of range [{lo}, {hi}] "
                f"(SOURCE: {source})"
            )


class IOPDynamicsModel:
    """Goldmann-equation IOP dynamics with circadian rhythm and medication effects.

    Solves the ODE:
        dIOP/dt = (1/K) * [F_in(t) - C * (IOP - P_e) - F_u]

    with circadian-modulated aqueous inflow:
        F_in(t) = F_in_mean * (1 + A_circ * cos(2*pi*(t - phi)/24))
    """

    def __init__(self, params: dict[str, float] | None = None, seed: int | None = None) -> None:
        self.params = {**DEFAULT_PARAMS, **(params or {})}
        _validate_params(self.params)
        self.rng = np.random.default_rng(seed)

        self.iop: float = self.params["IOP_initial"]
        self.time_hours: float = 0.0

        # Active medications: {name: duration_days}
        self.active_medications: dict[str, float] = {}

    def reset(self, params: dict[str, float] | None = None) -> float:
        """Reset model state. Optionally update parameters."""
        if params is not None:
            self.params.update(params)
            _validate_params(self.params)
        self.iop = self.params["IOP_initial"]
        self.time_hours = 0.0
        self.active_medications = {}
        return self.iop

    def _compute_medication_effects(self) -> tuple[float, float]:
        """Compute aggregate medication multipliers for F_in and F_u.

        SIMPLIFICATION: Medication effects are multiplicative (not additive).
        This is a common clinical assumption for combination therapy but
        real-world interactions are more complex.
        """
        f_in_mult = 1.0
        f_u_mult = 1.0

        for med_name, duration_days in self.active_medications.items():
            effects = MEDICATION_EFFECTS[med_name]
            onset = effects["onset_days"]
            max_effect = effects["max_effect_days"]

            # Linear ramp-up during onset
            # SIMPLIFICATION: linear onset rather than pharmacokinetic curve
            if duration_days < onset:
                fraction = duration_days / onset
            elif duration_days < max_effect:
                fraction = 1.0
            else:
                fraction = 1.0  # Steady state

            f_in_effect = 1.0 + fraction * (effects["F_in_multiplier"] - 1.0)
            f_u_effect = 1.0 + fraction * (effects["F_u_multiplier"] - 1.0)

            f_in_mult *= f_in_effect
            f_u_mult *= f_u_effect

        return f_in_mult, f_u_mult

    def _ode(self, t: float, y: np.ndarray, f_in_mult: float, f_u_mult: float) -> np.ndarray:
        """Goldmann ODE right-hand side."""
        iop = y[0]
        p = self.params

        # Circadian-modulated inflow
        # SOURCE: liu1998circadian
        f_in = (
            p["F_in_mean"]
            * f_in_mult
            * (1.0 + p["A_circ"] * np.cos(2.0 * np.pi * (t - p["phi"]) / 24.0))
        )

        f_u = p["F_u"] * f_u_mult
        c = p["C"]
        p_e = p["P_e"]
        k = p["K"]

        diop_dt = (1.0 / k) * (f_in - c * (iop - p_e) - f_u)
        return np.array([diop_dt])

    def step(self, dt_hours: float = 24.0) -> float:
        """Advance the IOP model by dt_hours.

        Args:
            dt_hours: Time step in hours (default 24 = one day).

        Returns:
            New IOP value in mmHg.
        """
        f_in_mult, f_u_mult = self._compute_medication_effects()

        sol = solve_ivp(
            self._ode,
            [self.time_hours, self.time_hours + dt_hours],
            [self.iop],
            args=(f_in_mult, f_u_mult),
            method="RK45",
            max_step=1.0,  # Max 1-hour internal steps for accuracy
        )

        self.iop = float(sol.y[0, -1])
        self.time_hours += dt_hours

        # Update medication durations
        dt_days = dt_hours / 24.0
        for med_name in list(self.active_medications.keys()):
            self.active_medications[med_name] += dt_days

        return self.iop

    def add_medication(self, medication: str) -> None:
        """Start a medication.

        Args:
            medication: One of 'prostaglandin', 'beta_blocker', 'alpha_agonist', 'cai'.
        """
        assert medication in MEDICATION_EFFECTS, (
            f"Unknown medication '{medication}'. Valid: {list(MEDICATION_EFFECTS.keys())}"
        )
        self.active_medications[medication] = 0.0

    def remove_medication(self, medication: str) -> None:
        """Stop a medication."""
        self.active_medications.pop(medication, None)

    def get_iop_with_noise(self, measurement_noise_std: float = 1.5) -> float:
        """Get IOP with Goldmann tonometry measurement noise.

        Args:
            measurement_noise_std: Standard deviation of measurement noise in mmHg.
                SOURCE: whitacre1993accuracy, Goldmann tonometry repeatability ~1.5 mmHg

        Returns:
            Measured IOP in mmHg.
        """
        # PARAMETER_RANGES check
        assert 0.0 <= measurement_noise_std <= 5.0, (
            f"Measurement noise std must be in [0, 5], got {measurement_noise_std}"
        )
        noise = self.rng.normal(0.0, measurement_noise_std)
        return max(0.0, self.iop + noise)

    def get_equilibrium_iop(self) -> float:
        """Compute steady-state IOP analytically (ignoring circadian variation).

        At equilibrium: F_in = C * (IOP_eq - P_e) + F_u
        => IOP_eq = (F_in - F_u) / C + P_e
        """
        f_in_mult, f_u_mult = self._compute_medication_effects()
        p = self.params
        f_in = p["F_in_mean"] * f_in_mult
        f_u = p["F_u"] * f_u_mult
        return (f_in - f_u) / p["C"] + p["P_e"]
