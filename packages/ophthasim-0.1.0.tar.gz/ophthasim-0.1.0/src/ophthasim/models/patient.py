"""Patient parameter generation for ophthalmic simulation environments.

Generates physiologically plausible patient profiles with difficulty tiers
for each environment type.

SOURCE: leske2007riskfactors, glaucoma risk factors and demographics
SOURCE: wong2014agerelateddmacular, AMD demographics and risk factors
SOURCE: yau2012globalprevalence, DR prevalence and risk factors
"""

from __future__ import annotations

from typing import Any

import numpy as np

# ============================================================================
# Parameter ranges (global demographics)
# ============================================================================

PARAMETER_RANGES: dict[str, tuple[float, float, str]] = {
    "age": (20.0, 95.0, "leske2007riskfactors"),
    "IOP_baseline": (10.0, 40.0, "leske2007riskfactors"),
    "target_IOP": (10.0, 21.0, "heijl2002emgt"),
    "CCT": (450.0, 650.0, "leske2007riskfactors"),  # um, central corneal thickness
    "VFI": (0.5, 1.0, "heijl2002emgt"),  # visual field index (fraction)
    "compliance": (0.5, 1.0, "olthoff2005noncompliance"),  # medication adherence
    "HbA1c": (4.0, 15.0, "ukpds1998intensive"),
    "VA_baseline": (20.0, 85.0, "rosenfeld2006ranibizumab"),  # ETDRS letters
    "CST_baseline": (250.0, 700.0, "rosenfeld2006ranibizumab"),  # um
}


def _validate_patient(params: dict[str, Any]) -> None:
    """Validate patient parameters against clinical ranges."""
    for key, value in params.items():
        if key in PARAMETER_RANGES and isinstance(value, (int, float)):
            lo, hi, source = PARAMETER_RANGES[key]
            assert lo <= value <= hi, (
                f"Patient parameter '{key}' = {value} out of range [{lo}, {hi}] "
                f"(SOURCE: {source})"
            )


class PatientGenerator:
    """Generate patient profiles for ophthalmic environments.

    Each environment type has three difficulty tiers:
    - easy: stable patient, good prognosis
    - medium: moderate variability, typical clinical case
    - hard: treatment-resistant, high variability, comorbidities
    """

    def __init__(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)

    def generate_glaucoma_patient(
        self, difficulty: str = "medium"
    ) -> dict[str, Any]:
        """Generate a glaucoma patient profile.

        Args:
            difficulty: One of 'easy', 'medium', 'hard'.

        Returns:
            Dictionary of patient parameters for GlaucomaIOP-v0.
        """
        assert difficulty in ("easy", "medium", "hard")

        if difficulty == "easy":
            params = {
                "age": float(self.rng.integers(50, 65)),
                "IOP_baseline": self.rng.uniform(22.0, 26.0),
                "target_IOP": 18.0,
                "CCT": self.rng.uniform(530.0, 580.0),
                "VFI": self.rng.uniform(0.90, 1.0),
                "compliance": self.rng.uniform(0.90, 1.0),
                "circadian_amplitude": 0.15,
                "measurement_noise": 1.0,
                "medication_resistance": 0.0,
            }
        elif difficulty == "medium":
            params = {
                "age": float(self.rng.integers(45, 75)),
                "IOP_baseline": self.rng.uniform(24.0, 30.0),
                "target_IOP": 16.0,
                "CCT": self.rng.uniform(500.0, 600.0),
                "VFI": self.rng.uniform(0.75, 0.95),
                "compliance": self.rng.uniform(0.75, 0.95),
                "circadian_amplitude": 0.30,
                "measurement_noise": 1.5,
                "medication_resistance": 0.1,
            }
        else:  # hard
            params = {
                "age": float(self.rng.integers(55, 85)),
                "IOP_baseline": self.rng.uniform(28.0, 36.0),
                "target_IOP": 14.0,
                "CCT": self.rng.uniform(470.0, 550.0),
                "VFI": self.rng.uniform(0.60, 0.80),
                "compliance": self.rng.uniform(0.55, 0.80),
                "circadian_amplitude": 0.40,
                "measurement_noise": 2.0,
                "medication_resistance": 0.3,
            }

        _validate_patient(params)
        return params

    def generate_anti_vegf_patient(
        self, difficulty: str = "medium"
    ) -> dict[str, Any]:
        """Generate a wet AMD patient profile for AntiVEGF-v0.

        SOURCE: wong2014agerelateddmacular, AMD patient demographics
        SOURCE: rosenfeld2006ranibizumab, MARINA trial baselines
        """
        assert difficulty in ("easy", "medium", "hard")

        if difficulty == "easy":
            # Good responder
            params = {
                "age": float(self.rng.integers(60, 75)),
                "VA_baseline": self.rng.uniform(55.0, 65.0),
                "CST_baseline": self.rng.uniform(350.0, 450.0),
                "VEGF_basal": self.rng.uniform(250.0, 350.0),
                "drug_response": 1.0,  # Full response
                "CST_alpha": 0.4,  # Lower VEGF-CST coupling
                "CST_beta": 0.025,  # Faster restoration
            }
        elif difficulty == "medium":
            # Partial responder
            params = {
                "age": float(self.rng.integers(65, 80)),
                "VA_baseline": self.rng.uniform(45.0, 60.0),
                "CST_baseline": self.rng.uniform(400.0, 550.0),
                "VEGF_basal": self.rng.uniform(300.0, 450.0),
                "drug_response": 0.75,
                "CST_alpha": 0.5,
                "CST_beta": 0.02,
            }
        else:  # hard
            # Treatment-resistant, may need switching
            params = {
                "age": float(self.rng.integers(70, 90)),
                "VA_baseline": self.rng.uniform(35.0, 50.0),
                "CST_baseline": self.rng.uniform(500.0, 650.0),
                "VEGF_basal": self.rng.uniform(400.0, 550.0),
                "drug_response": 0.5,
                "CST_alpha": 0.7,
                "CST_beta": 0.015,
            }

        _validate_patient(params)
        return params

    def generate_laser_patient(
        self, difficulty: str = "medium"
    ) -> dict[str, Any]:
        """Generate a patient profile for LaserTrabeculoplasty-v0.

        SOURCE: latina1998qswitchedlaser, SLT patient selection criteria
        """
        assert difficulty in ("easy", "medium", "hard")

        if difficulty == "easy":
            params = {
                "age": float(self.rng.integers(50, 65)),
                "IOP_baseline": self.rng.uniform(24.0, 28.0),
                "previous_laser_count": 0,
                "lens_status": 0,  # 0=phakic, 1=pseudophakic
                "angle_pigmentation": self.rng.uniform(2.0, 3.0),  # 0-4 scale
                "response_multiplier": self.rng.uniform(0.9, 1.1),
            }
        elif difficulty == "medium":
            params = {
                "age": float(self.rng.integers(55, 75)),
                "IOP_baseline": self.rng.uniform(26.0, 32.0),
                "previous_laser_count": self.rng.integers(0, 2),
                "lens_status": int(self.rng.random() < 0.3),
                "angle_pigmentation": self.rng.uniform(1.5, 3.5),
                "response_multiplier": self.rng.uniform(0.7, 1.0),
            }
        else:  # hard
            params = {
                "age": float(self.rng.integers(65, 85)),
                "IOP_baseline": self.rng.uniform(30.0, 38.0),
                "previous_laser_count": self.rng.integers(1, 3),
                "lens_status": int(self.rng.random() < 0.5),
                "angle_pigmentation": self.rng.uniform(1.0, 2.5),
                "response_multiplier": self.rng.uniform(0.5, 0.8),
            }

        _validate_patient(params)
        return params

    def generate_dr_patient(
        self, difficulty: str = "medium"
    ) -> dict[str, Any]:
        """Generate a diabetic retinopathy patient for DiabeticRetinopathy-v0.

        SOURCE: yau2012globalprevalence, DR risk factors
        SOURCE: ukpds1998intensive, HbA1c levels and outcomes
        """
        assert difficulty in ("easy", "medium", "hard")

        if difficulty == "easy":
            params = {
                "age": float(self.rng.integers(40, 55)),
                "HbA1c": self.rng.uniform(6.5, 7.5),
                "diabetes_duration_years": self.rng.uniform(2.0, 8.0),
                "initial_dr_stage": 0,
                "VA_baseline": self.rng.uniform(75.0, 85.0),
                "hba1c_volatility": 0.2,  # Low HbA1c variation
            }
        elif difficulty == "medium":
            params = {
                "age": float(self.rng.integers(45, 65)),
                "HbA1c": self.rng.uniform(7.5, 9.0),
                "diabetes_duration_years": self.rng.uniform(5.0, 15.0),
                "initial_dr_stage": int(self.rng.integers(0, 2)),
                "VA_baseline": self.rng.uniform(65.0, 80.0),
                "hba1c_volatility": 0.5,
            }
        else:  # hard
            params = {
                "age": float(self.rng.integers(50, 75)),
                "HbA1c": self.rng.uniform(9.0, 12.0),
                "diabetes_duration_years": self.rng.uniform(10.0, 25.0),
                "initial_dr_stage": int(self.rng.integers(1, 3)),
                "VA_baseline": self.rng.uniform(50.0, 70.0),
                "hba1c_volatility": 1.0,
            }

        _validate_patient(params)
        return params
