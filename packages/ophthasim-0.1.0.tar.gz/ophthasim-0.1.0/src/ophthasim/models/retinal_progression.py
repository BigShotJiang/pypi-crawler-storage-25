"""Diabetic retinopathy Markov chain progression model.

Models DR progression through 5 stages with HbA1c-modulated transition
probabilities and treatment effects.

States: {0: None, 1: Mild_NPDR, 2: Moderate_NPDR, 3: Severe_NPDR, 4: PDR}

Transition probabilities are quarterly and modulated by:
    modifier(HbA1c) = exp(0.075 * (HbA1c - 7.0))

SOURCE: klein1994wisconsin (WESDR), DR progression rates
SOURCE: ukpds1998intensive (UKPDS 33), HbA1c effect on DR progression
SOURCE: aiello1998prp, PRP treatment effect on PDR progression
SOURCE: diabeticretinopathystudy1981photocoagulation (DRS), PRP efficacy
"""

from __future__ import annotations

import numpy as np

# ============================================================================
# State definitions
# ============================================================================

DR_STATES: dict[int, str] = {
    0: "None",
    1: "Mild_NPDR",
    2: "Moderate_NPDR",
    3: "Severe_NPDR",
    4: "PDR",
}

NUM_STATES = len(DR_STATES)

# ============================================================================
# Parameter ranges
# ============================================================================

PARAMETER_RANGES: dict[str, tuple[float, float, str]] = {
    "HbA1c": (4.0, 15.0, "ukpds1998intensive"),  # %
    "hba1c_coefficient": (0.03, 0.15, "ukpds1998intensive"),
    "hba1c_reference": (6.0, 8.0, "ukpds1998intensive"),  # reference HbA1c
    "prp_modifier": (0.3, 0.7, "diabeticretinopathystudy1981photocoagulation"),
    "anti_vegf_modifier": (0.5, 0.8, "aiello1998prp"),
    "dme_prevalence_mild": (0.01, 0.10, "klein1994wisconsin"),
    "dme_prevalence_moderate": (0.05, 0.20, "klein1994wisconsin"),
    "dme_prevalence_severe": (0.10, 0.30, "klein1994wisconsin"),
    "dme_prevalence_pdr": (0.20, 0.50, "klein1994wisconsin"),
}

# ============================================================================
# Base quarterly transition matrix (no treatment, HbA1c = 7.0)
# ============================================================================

# SOURCE: klein1994wisconsin (WESDR) — 4-year progression rates converted to
# quarterly probabilities
# SIMPLIFICATION: Only forward transitions + self-loops. Regression is possible
# with tight glycemic control but is rare and not modeled here.

BASE_TRANSITION_MATRIX = np.array(
    [
        # None   Mild   Mod    Severe PDR
        [0.975, 0.025, 0.000, 0.000, 0.000],  # None -> Mild (quarterly)
        [0.000, 0.960, 0.035, 0.005, 0.000],  # Mild -> Mod/Severe
        [0.000, 0.000, 0.950, 0.040, 0.010],  # Mod -> Severe/PDR
        [0.000, 0.000, 0.000, 0.930, 0.070],  # Severe -> PDR
        [0.000, 0.000, 0.000, 0.000, 1.000],  # PDR (absorbing)
    ],
    dtype=np.float64,
)  # SOURCE: klein1994wisconsin, derived from 4-year rates

# DME prevalence by DR stage (probability of concurrent DME)
# SOURCE: klein1994wisconsin
DME_PREVALENCE: dict[int, float] = {
    0: 0.00,  # No DR = no DME
    1: 0.03,  # SOURCE: klein1994wisconsin, mild NPDR
    2: 0.10,  # SOURCE: klein1994wisconsin, moderate NPDR
    3: 0.20,  # SOURCE: klein1994wisconsin, severe NPDR
    4: 0.35,  # SOURCE: klein1994wisconsin, PDR
}


class DiabeticRetinopathyProgression:
    """Markov chain model for diabetic retinopathy progression.

    Transitions are quarterly with HbA1c modulation and treatment effects.

    SIMPLIFICATION: Uses a discrete Markov chain rather than a continuous-time
    model. Quarterly resolution matches typical screening intervals but may
    miss rapid progression in high-risk patients.
    """

    def __init__(
        self,
        initial_stage: int = 0,
        HbA1c: float = 7.0,
        seed: int | None = None,
    ) -> None:
        """Initialize DR progression model.

        Args:
            initial_stage: Starting DR stage (0-4).
            HbA1c: Baseline HbA1c percentage.
            seed: RNG seed.
        """
        assert 0 <= initial_stage < NUM_STATES, (
            f"Initial stage must be in [0, {NUM_STATES - 1}], got {initial_stage}"
        )
        lo, hi, source = PARAMETER_RANGES["HbA1c"]
        assert lo <= HbA1c <= hi, (
            f"HbA1c must be in [{lo}, {hi}], got {HbA1c} (SOURCE: {source})"
        )

        self.stage: int = initial_stage
        self.HbA1c: float = HbA1c
        self.has_dme: bool = False
        self.rng = np.random.default_rng(seed)
        self.quarter: int = 0

        # Treatment state
        self.on_prp: bool = False
        self.on_anti_vegf: bool = False

    def reset(
        self,
        initial_stage: int = 0,
        HbA1c: float | None = None,
    ) -> int:
        """Reset model to initial state."""
        self.stage = initial_stage
        if HbA1c is not None:
            lo, hi, _ = PARAMETER_RANGES["HbA1c"]
            assert lo <= HbA1c <= hi
            self.HbA1c = HbA1c
        self.has_dme = False
        self.quarter = 0
        self.on_prp = False
        self.on_anti_vegf = False
        return self.stage

    def _hba1c_modifier(self) -> float:
        """Compute HbA1c-based transition rate modifier.

        modifier = exp(0.075 * (HbA1c - 7.0))

        SOURCE: ukpds1998intensive, each 1% HbA1c increase ~ 7.5% higher progression risk
        """
        return np.exp(0.075 * (self.HbA1c - 7.0))

    def _get_transition_probs(self) -> np.ndarray:
        """Get transition probabilities for current state with all modifiers.

        Returns:
            Probability vector of length NUM_STATES.
        """
        base_probs = BASE_TRANSITION_MATRIX[self.stage].copy()

        # Apply HbA1c modifier to forward transition probabilities
        modifier = self._hba1c_modifier()

        # Treatment modifiers
        # SOURCE: diabeticretinopathystudy1981photocoagulation (PRP)
        # SOURCE: aiello1998prp (anti-VEGF)
        treatment_modifier = 1.0
        if self.on_prp and self.stage >= 3:
            treatment_modifier *= 0.50  # SOURCE: diabeticretinopathystudy1981photocoagulation
        if self.on_anti_vegf:
            treatment_modifier *= 0.65  # SOURCE: aiello1998prp

        # Modify forward transitions (all except self-loop)
        for j in range(self.stage + 1, NUM_STATES):
            base_probs[j] *= modifier * treatment_modifier

        # Renormalize: self-loop absorbs remaining probability
        forward_sum = np.sum(base_probs[self.stage + 1:])
        # Clamp forward probabilities so they don't exceed 1
        if forward_sum > 0.95:
            scale = 0.95 / forward_sum
            base_probs[self.stage + 1:] *= scale
            forward_sum = 0.95

        base_probs[self.stage] = 1.0 - forward_sum

        return base_probs

    def step(self) -> tuple[int, bool]:
        """Advance one quarter.

        Returns:
            Tuple of (new_stage, has_dme).
        """
        probs = self._get_transition_probs()

        # Sample next state
        self.stage = int(self.rng.choice(NUM_STATES, p=probs))
        self.quarter += 1

        # Sample DME status
        # SOURCE: klein1994wisconsin
        dme_prob = DME_PREVALENCE[self.stage]
        if self.on_anti_vegf and self.has_dme:
            # Anti-VEGF treats existing DME
            # SOURCE: diabeticretinopathydrstudy2015protocol
            dme_prob *= 0.3  # SIMPLIFICATION: fixed 70% DME resolution rate
        self.has_dme = bool(self.rng.random() < dme_prob)

        return self.stage, self.has_dme

    def start_prp(self) -> None:
        """Start panretinal photocoagulation treatment."""
        self.on_prp = True

    def start_anti_vegf(self) -> None:
        """Start anti-VEGF treatment."""
        self.on_anti_vegf = True

    def stop_anti_vegf(self) -> None:
        """Stop anti-VEGF treatment."""
        self.on_anti_vegf = False

    def get_state_name(self) -> str:
        """Get human-readable name of current DR stage."""
        return DR_STATES[self.stage]

    def get_vision_loss_risk(self) -> float:
        """Estimate quarterly risk of significant vision loss.

        SIMPLIFICATION: Uses stage-based risk estimates rather than
        continuous modeling of visual function.

        SOURCE: klein1994wisconsin, vision loss rates by DR stage
        """
        # Quarterly risk of losing >= 15 ETDRS letters
        stage_risks = {
            0: 0.001,  # SOURCE: klein1994wisconsin
            1: 0.005,
            2: 0.015,
            3: 0.04,
            4: 0.08,
        }
        risk = stage_risks[self.stage]
        if self.has_dme:
            risk *= 2.0  # DME doubles vision loss risk
        return min(risk, 1.0)

    def simulate(self, n_quarters: int) -> list[tuple[int, bool]]:
        """Simulate progression for n_quarters.

        Args:
            n_quarters: Number of quarters to simulate.

        Returns:
            List of (stage, has_dme) tuples for each quarter.
        """
        trajectory = []
        for _ in range(n_quarters):
            state = self.step()
            trajectory.append(state)
        return trajectory
