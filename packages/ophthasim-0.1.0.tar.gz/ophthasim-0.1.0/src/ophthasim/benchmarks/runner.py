"""Benchmark runner for evaluating agents across OpthaSim environments.

Runs multiple episodes per agent-environment pair and computes statistics.
Provides CLI entrypoint for standardized benchmarking.

Usage:
    ophthasim-bench --episodes 100 --seed 42
"""

from __future__ import annotations

import argparse
import json
from typing import Any

import gymnasium as gym
import numpy as np

from ophthasim.agents.heuristic_agent import get_heuristic_agent
from ophthasim.agents.random_agent import RandomAgent
from ophthasim.training.configs import ENV_CONFIGS

# All registered environments
ALL_ENVS = list(ENV_CONFIGS.keys())


class BenchmarkRunner:
    """Run benchmark episodes for agent-environment evaluation.

    Evaluates random and heuristic agents (and optionally trained PPO agents)
    across all environments with statistical summaries.
    """

    def __init__(self, n_episodes: int = 50, seed: int = 42) -> None:
        self.n_episodes = n_episodes
        self.seed = seed
        self.results: dict[str, dict[str, dict[str, Any]]] = {}

    def run_agent(
        self,
        env_id: str,
        agent_name: str,
        agent,
        n_episodes: int | None = None,
    ) -> dict[str, Any]:
        """Run an agent for multiple episodes and collect statistics.

        Args:
            env_id: Gymnasium environment ID.
            agent_name: Name for this agent in results.
            agent: Agent with .act(obs) and .reset() methods.
            n_episodes: Override number of episodes.

        Returns:
            Dictionary with mean/std/min/max for rewards and episode lengths.
        """
        n_eps = n_episodes or self.n_episodes
        rewards = []
        lengths = []
        final_infos = []

        for ep in range(n_eps):
            env = gym.make(env_id)
            obs, info = env.reset(seed=self.seed + ep)
            agent.reset()

            total_reward = 0.0
            steps = 0
            terminated = False
            truncated = False

            while not (terminated or truncated):
                action = agent.act(obs)
                obs, reward, terminated, truncated, info = env.step(action)
                total_reward += reward
                steps += 1

            rewards.append(total_reward)
            lengths.append(steps)
            final_infos.append(info)
            env.close()

        result = {
            "reward_mean": float(np.mean(rewards)),
            "reward_std": float(np.std(rewards)),
            "reward_min": float(np.min(rewards)),
            "reward_max": float(np.max(rewards)),
            "length_mean": float(np.mean(lengths)),
            "length_std": float(np.std(lengths)),
            "n_episodes": n_eps,
        }

        # Store in results
        if env_id not in self.results:
            self.results[env_id] = {}
        self.results[env_id][agent_name] = result

        return result

    def run_all(self, env_ids: list[str] | None = None) -> dict:
        """Run benchmarks for random and heuristic agents on all environments.

        Args:
            env_ids: List of environment IDs (defaults to all).

        Returns:
            Complete results dictionary.
        """
        envs = env_ids or ALL_ENVS

        for env_id in envs:
            print(f"\nBenchmarking: {env_id}")
            print("-" * 50)

            # Create environment to get action space
            env = gym.make(env_id)

            # Random agent
            random_agent = RandomAgent(env.action_space, seed=self.seed)
            result = self.run_agent(env_id, "random", random_agent)
            print(f"  Random:    reward={result['reward_mean']:.2f} +/- {result['reward_std']:.2f}")

            # Heuristic agent
            heuristic_agent = get_heuristic_agent(env_id, seed=self.seed)
            result = self.run_agent(env_id, "heuristic", heuristic_agent)
            print(f"  Heuristic: reward={result['reward_mean']:.2f} +/- {result['reward_std']:.2f}")

            env.close()

        return self.results

    def to_json(self) -> str:
        """Serialize results to JSON string."""
        return json.dumps(self.results, indent=2)

    def print_summary(self) -> None:
        """Print a formatted summary table of results."""
        print(f"\n{'='*70}")
        print("BENCHMARK RESULTS")
        print(f"{'='*70}")
        print(f"{'Environment':<35} {'Agent':<12} {'Reward':>10} {'Std':>8}")
        print(f"{'-'*70}")

        for env_id, agents in self.results.items():
            short_name = env_id.split("/")[1] if "/" in env_id else env_id
            for agent_name, stats in agents.items():
                print(
                    f"{short_name:<35} {agent_name:<12} "
                    f"{stats['reward_mean']:>10.2f} {stats['reward_std']:>8.2f}"
                )


def main() -> None:
    """CLI entrypoint for benchmarking."""
    parser = argparse.ArgumentParser(description="Benchmark OpthaSim agents")
    parser.add_argument(
        "--episodes",
        type=int,
        default=50,
        help="Number of episodes per agent-env pair",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    parser.add_argument(
        "--env",
        type=str,
        default=None,
        help="Specific environment to benchmark (default: all)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON",
    )
    args = parser.parse_args()

    runner = BenchmarkRunner(n_episodes=args.episodes, seed=args.seed)
    env_ids = [args.env] if args.env else None
    runner.run_all(env_ids=env_ids)

    if args.json:
        print(runner.to_json())
    else:
        runner.print_summary()


if __name__ == "__main__":
    main()
