"""Benchmarking utilities for OpthaSim environments."""

from ophthasim.benchmarks.runner import BenchmarkRunner

__all__ = ["BenchmarkRunner"]
