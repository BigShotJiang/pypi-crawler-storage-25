"""Clinical guideline-based heuristic agents for OpthaSim environments.

Each agent implements a simplified version of standard clinical protocols:

GlaucomaHeuristicAgent:
    SOURCE: heijl2002emgt, EMGT target-based IOP management
    - Add medications stepwise if IOP > target
    - Step down if IOP controlled for 6+ months

AntiVEGFHeuristicAgent:
    SOURCE: rosenfeld2006ranibizumab, PRN (pro re nata) protocol
    - Inject if VA drops > 5 letters or CST increases > 50 um
    - Monthly monitoring

LaserHeuristicAgent:
    SOURCE: gazzard2019ligo, LiGHT trial protocol
    - Treat at IOP > 24 mmHg, 360-degree, medium energy
    - Repeat at 12 months if IOP rising

DRHeuristicAgent:
    SOURCE: aiello1998prp, DR screening guidelines
    - Annual screening for no/mild DR
    - Treat DME with anti-VEGF, PRP for severe/PDR
"""

from __future__ import annotations

import numpy as np


class GlaucomaHeuristicAgent:
    """Target IOP-based medication titration agent.

    Protocol:
    1. If IOP > target + 3: add next medication in stepwise order
    2. If IOP in [target, target+3]: maintain current therapy
    3. If IOP < target for 180+ consecutive days: consider stepping down
    4. Never exceed 3 concurrent medications

    SOURCE: heijl2002emgt, stepwise medication protocol
    """

    def __init__(self, target_iop: float = 16.0, seed: int | None = None) -> None:
        self.target_iop = target_iop
        self.rng = np.random.default_rng(seed)
        self.days_in_target: int = 0
        self.med_order = [1, 2, 3, 4]  # Prostaglandin first, then add-on

    def act(self, observation: np.ndarray) -> int:
        """Select medication action based on current IOP.

        Args:
            observation: [IOP, time_of_day, prostaglandin, beta_blocker,
                         alpha_agonist, cai, VFI, compliance]

        Returns:
            Action integer (0-5).
        """
        iop_measured = float(observation[0])
        active_meds = [int(observation[i] > 0.5) for i in range(2, 6)]
        n_active = sum(active_meds)

        # Track time in target
        if iop_measured <= self.target_iop + 2.0:
            self.days_in_target += 1
        else:
            self.days_in_target = 0

        # Step down if controlled for 6 months
        if self.days_in_target > 180 and n_active > 1:
            self.days_in_target = 0
            return 5  # Stop all (simplification: restart with fewer)

        # Add medication if IOP too high
        if iop_measured > self.target_iop + 3.0 and n_active < 3:
            for med_action in self.med_order:
                if active_meds[med_action - 1] == 0:
                    return med_action
            return 0  # All slots full

        # IOP dangerously high -- add any available med
        if iop_measured > 35.0:
            for med_action in self.med_order:
                if active_meds[med_action - 1] == 0:
                    return med_action

        return 0  # No change

    def reset(self) -> None:
        self.days_in_target = 0


class AntiVEGFHeuristicAgent:
    """PRN (as-needed) injection protocol agent.

    Protocol:
    1. Loading phase: 3 monthly injections
    2. Then PRN: inject if VA drops > 5 letters or CST > threshold
    3. Switch drug if VA declining after 3+ injections on same drug

    SOURCE: rosenfeld2006ranibizumab, MARINA PRN criteria
    """

    def __init__(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)
        self.prev_va: float = 55.0
        self.prev_cst: float = 0.5
        self.injections_since_switch: int = 0
        self.month: int = 0
        self.loading_complete: bool = False

    def act(self, observation: np.ndarray) -> int:
        """Select injection action based on PRN criteria.

        Args:
            observation: [VA, CST_norm, VEGF_norm, time_since_inj_norm,
                         inj_count_norm, drug_type, month_norm]

        Returns:
            Action integer (0-2).
        """
        va = float(observation[0])
        cst_norm = float(observation[1])
        month_norm = float(observation[6])

        current_month = int(month_norm * 24)

        # Loading phase: monthly injections for first 3 months
        if current_month < 3:
            self.month = current_month
            self.prev_va = va
            self.prev_cst = cst_norm
            self.injections_since_switch += 1
            return 1  # Inject

        self.loading_complete = True

        # PRN criteria
        va_drop = self.prev_va - va
        cst_increase = cst_norm - self.prev_cst

        inject = False

        # VA drop > 5 letters
        if va_drop > 5.0:
            inject = True

        # CST increase > 50 um (normalized: ~0.07 of 700)
        if cst_increase > 0.07:
            inject = True

        # CST still elevated (> 300 um normalized)
        if cst_norm > 300.0 / 700.0:
            inject = True

        self.prev_va = va
        self.prev_cst = cst_norm

        if inject:
            self.injections_since_switch += 1
            # Consider switching if poor response after 3+ injections
            if self.injections_since_switch >= 3 and va_drop > 3.0:
                self.injections_since_switch = 0
                return 2  # Switch drug
            return 1  # Inject same drug

        return 0  # Wait

    def reset(self) -> None:
        self.prev_va = 55.0
        self.prev_cst = 0.5
        self.injections_since_switch = 0
        self.month = 0
        self.loading_complete = False


class LaserHeuristicAgent:
    """SLT treatment protocol agent.

    Protocol:
    1. Treat if IOP > 24 mmHg and not recently treated
    2. Use 360-degree coverage, medium energy
    3. Repeat at 12+ months if IOP rising
    4. Max 3 total treatments

    SOURCE: gazzard2019ligo, LiGHT trial SLT protocol
    """

    def __init__(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)

    def act(self, observation: np.ndarray) -> np.ndarray:
        """Select SLT treatment parameters.

        Args:
            observation: [IOP_baseline_norm, IOP_current_norm,
                         months_since_laser_norm, prev_treatments_norm,
                         age_norm, lens_status, month_norm]

        Returns:
            MultiDiscrete action [treat, coverage, energy].
        """
        iop_current = float(observation[1]) * 50.0  # Denormalize
        months_since = float(observation[2]) * 36.0  # Denormalize
        prev_treatments = float(observation[3]) * 5.0  # Denormalize

        treat = 0
        coverage = 2  # 360 degrees (default)
        energy = 1  # Medium (default)

        # Treat if IOP high and not recently treated
        if iop_current > 24.0 and months_since > 6.0 and prev_treatments < 3:
            treat = 1

        # First treatment: prefer 360/medium
        # Retreatment: same parameters
        # SOURCE: gazzard2019ligo

        return np.array([treat, coverage, energy])

    def reset(self) -> None:
        pass


class DRHeuristicAgent:
    """DR screening and treatment guideline agent.

    Protocol:
    1. No/Mild NPDR: screen every 12 months (4 quarters)
    2. Moderate NPDR: screen every 6 months (2 quarters)
    3. Severe NPDR/PDR: screen every 3 months + consider PRP
    4. DME present: treat with anti-VEGF
    5. PDR: apply PRP

    SOURCE: aiello1998prp, AAO DR screening guidelines
    """

    def __init__(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)

    def act(self, observation: np.ndarray) -> int:
        """Select screening/treatment action.

        Args:
            observation: [DR_stage_norm, has_DME, HbA1c_norm,
                         time_since_screen_norm, VA_norm,
                         on_anti_vegf, on_prp, quarter_norm]

        Returns:
            Action integer (0-4).
        """
        dr_stage = float(observation[0]) * 4.0  # Denormalize
        has_dme = float(observation[1]) > 0.5
        time_since_screen = float(observation[3]) * 8.0  # Denormalize quarters
        on_anti_vegf = float(observation[5]) > 0.5
        on_prp = float(observation[6]) > 0.5

        # Priority 1: Treat DME
        if has_dme and not on_anti_vegf:
            return 3  # anti_vegf_for_dme

        # Priority 2: PRP for PDR/severe
        if dr_stage >= 3.5 and not on_prp:
            return 4  # prp_for_pdr

        # Priority 3: Screening intervals based on stage
        if dr_stage < 1.5:
            # None/Mild: annual (every 4 quarters)
            if time_since_screen >= 3.5:
                return 2  # screen_6mo
        elif dr_stage < 2.5:
            # Moderate: semi-annual (every 2 quarters)
            if time_since_screen >= 1.5:
                return 1  # screen_3mo
        else:
            # Severe/PDR: quarterly
            if time_since_screen >= 0.5:
                return 1  # screen_3mo

        return 0  # Observe

    def reset(self) -> None:
        pass


def get_heuristic_agent(env_id: str, **kwargs) -> (
    GlaucomaHeuristicAgent
    | AntiVEGFHeuristicAgent
    | LaserHeuristicAgent
    | DRHeuristicAgent
):
    """Factory function to get the appropriate heuristic agent for an environment.

    Args:
        env_id: Gymnasium environment ID.
        **kwargs: Additional arguments passed to the agent constructor.

    Returns:
        Heuristic agent instance.
    """
    agents = {
        "ophthasim/GlaucomaIOP-v0": GlaucomaHeuristicAgent,
        "ophthasim/AntiVEGF-v0": AntiVEGFHeuristicAgent,
        "ophthasim/LaserTrabeculoplasty-v0": LaserHeuristicAgent,
        "ophthasim/DiabeticRetinopathy-v0": DRHeuristicAgent,
    }
    assert env_id in agents, f"No heuristic agent for '{env_id}'. Valid: {list(agents.keys())}"
    return agents[env_id](**kwargs)
