"""Random baseline agent for OpthaSim environments."""

from __future__ import annotations

import numpy as np
from gymnasium import spaces


class RandomAgent:
    """Agent that takes uniformly random actions.

    Used as a lower-bound baseline for all environments.
    """

    def __init__(self, action_space: spaces.Space, seed: int | None = None) -> None:
        self.action_space = action_space
        self.rng = np.random.default_rng(seed)

    def act(self, observation: np.ndarray) -> int | np.ndarray:
        """Select a random action.

        Args:
            observation: Current observation (ignored by random agent).

        Returns:
            Random action from the action space.
        """
        if isinstance(self.action_space, spaces.Discrete):
            return int(self.rng.integers(0, self.action_space.n))
        elif isinstance(self.action_space, spaces.MultiDiscrete):
            nvec = self.action_space.nvec
            return np.array([int(self.rng.integers(0, n)) for n in nvec])
        else:
            raise NotImplementedError(
                f"RandomAgent does not support action space type: {type(self.action_space)}"
            )

    def reset(self) -> None:
        """Reset agent state (no-op for random agent)."""
        pass
