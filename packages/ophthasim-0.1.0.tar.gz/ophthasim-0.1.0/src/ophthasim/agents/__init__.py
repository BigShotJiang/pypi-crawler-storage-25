"""Baseline agents for OpthaSim environments."""

from ophthasim.agents.heuristic_agent import (
    AntiVEGFHeuristicAgent,
    DRHeuristicAgent,
    GlaucomaHeuristicAgent,
    LaserHeuristicAgent,
    get_heuristic_agent,
)
from ophthasim.agents.random_agent import RandomAgent

__all__ = [
    "RandomAgent",
    "GlaucomaHeuristicAgent",
    "AntiVEGFHeuristicAgent",
    "LaserHeuristicAgent",
    "DRHeuristicAgent",
    "get_heuristic_agent",
]
