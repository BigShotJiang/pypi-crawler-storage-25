"""PPO training wrapper using Stable-Baselines3.

Provides a CLI entrypoint for training PPO agents on OpthaSim environments.
Requires the [train] optional dependency group.

Usage:
    ophthasim-train --env ophthasim/GlaucomaIOP-v0 --timesteps 500000
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from ophthasim.training.configs import ENV_CONFIGS


def train(
    env_id: str,
    total_timesteps: int | None = None,
    output_dir: str = "results/models",
    seed: int = 42,
    **override_kwargs,
) -> Path:
    """Train a PPO agent on an OpthaSim environment.

    Args:
        env_id: Gymnasium environment ID.
        total_timesteps: Override training timesteps (uses config default if None).
        output_dir: Directory to save trained model.
        seed: Random seed.
        **override_kwargs: Override any config parameter.

    Returns:
        Path to saved model.

    Raises:
        ImportError: If stable-baselines3 is not installed.
    """
    try:
        from stable_baselines3 import PPO
        from stable_baselines3.common.env_util import make_vec_env
    except ImportError:
        print(
            "stable-baselines3 is required for training. "
            "Install with: pip install ophthasim[train]",
            file=sys.stderr,
        )
        raise

    # Get config
    config = ENV_CONFIGS.get(env_id, {}).copy()
    config.update(override_kwargs)

    timesteps = total_timesteps or config.pop("total_timesteps", 100_000)
    effective_seed = config.pop("seed", seed)

    # Create vectorized environment
    env = make_vec_env(env_id, n_envs=1, seed=effective_seed)

    # Extract PPO-specific kwargs
    ppo_kwargs = {
        k: v
        for k, v in config.items()
        if k in ("learning_rate", "n_steps", "batch_size", "n_epochs", "gamma", "ent_coef",
                  "vf_coef", "max_grad_norm", "gae_lambda", "clip_range")
    }

    model = PPO(
        "MlpPolicy",
        env,
        seed=effective_seed,
        verbose=1,
        **ppo_kwargs,
    )

    model.learn(total_timesteps=timesteps)

    # Save model
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    model_name = env_id.replace("/", "_")
    save_path = output_path / f"ppo_{model_name}"
    model.save(str(save_path))

    env.close()
    return save_path


def main() -> None:
    """CLI entrypoint for PPO training."""
    parser = argparse.ArgumentParser(description="Train PPO agent on OpthaSim environment")
    parser.add_argument(
        "--env",
        type=str,
        required=True,
        help="Gymnasium environment ID (e.g., ophthasim/GlaucomaIOP-v0)",
    )
    parser.add_argument(
        "--timesteps",
        type=int,
        default=None,
        help="Total training timesteps (overrides config default)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="results/models",
        help="Directory to save trained model",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    args = parser.parse_args()

    save_path = train(
        env_id=args.env,
        total_timesteps=args.timesteps,
        output_dir=args.output_dir,
        seed=args.seed,
    )
    print(f"Model saved to: {save_path}")


if __name__ == "__main__":
    main()
