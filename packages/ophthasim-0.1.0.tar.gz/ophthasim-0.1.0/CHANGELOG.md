# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-04-28

### Added

- Four Gymnasium-compatible environments: GlaucomaIOP-v0, AntiVEGF-v0, LaserTrabeculoplasty-v0, DiabeticRetinopathy-v0
- Physiological models: Goldmann IOP dynamics with circadian modulation, anti-VEGF pharmacokinetics/pharmacodynamics, diabetic retinopathy Markov progression, SLT outcome model
- Visual acuity conversion utilities (ETDRS, Snellen, LogMAR)
- Patient parameter generation with difficulty tiers
- Heuristic agents implementing clinical guideline protocols
- Random baseline agent
- PPO training wrapper (stable-baselines3)
- Benchmark runner with statistical comparison
- 100+ unit and integration tests
- Complete documentation and citation files
