# Contributing to OpthaSim

Thank you for your interest in contributing to OpthaSim.

## Development Setup

```bash
git clone https://github.com/HassDhia/ophthasim.git
cd ophthasim
python -m venv .venv
source .venv/bin/activate
pip install -e ".[all]"
```

## Running Tests

```bash
pytest tests/ -v
```

All tests must pass without network access or GPU. Use synthetic data and deterministic seeds.

## Code Quality

```bash
ruff check src/ --select F,E9,W6,I,UP,B,A,SIM
```

## Domain Parameter Requirements

Every physiological or pharmacological parameter **must** include:

1. A `SOURCE` comment citing the literature reference (e.g., `# SOURCE: brubaker1991flow`)
2. A `PARAMETER_RANGES` entry with clinically valid bounds
3. A runtime assertion enforcing those bounds

If you simplify a real-world process, add a `SIMPLIFICATION` comment explaining what was simplified and why.

## Adding a New Environment

1. Create the environment class in `src/ophthasim/envs/`
2. Register it in `src/ophthasim/envs/__init__.py`
3. Add a heuristic agent in `src/ophthasim/agents/heuristic_agent.py`
4. Write tests covering: reset, step, reward bounds, episode termination, seeding
5. Add training config in `src/ophthasim/training/configs.py`

## Pull Request Guidelines

- Every PR must include tests
- All existing tests must continue to pass
- Parameter changes require literature citations
- Follow the existing code style (enforced by ruff)
