# -*- coding: utf-8 -*-

"""
Core mixins package providing compatibility
utilities and interfaces.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version


try:
    __version__ = version("core-mixins")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "__version__",
]
