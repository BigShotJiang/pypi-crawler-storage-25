# Contributing

Thanks for your interest in improving `butt-dial-sdk`.

## Dev setup

```bash
git clone https://github.com/95percent-ai/butt-dial-sdk.git
cd butt-dial-sdk
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -e '.[dev]'
```

## Running tests

```bash
pytest                          # run the full suite (currently 117 tests)
pytest --cov                    # with coverage report (target: ≥85%)
pytest tests/test_doctor.py -v  # a single module
```

## Code style

- `ruff` + `black` with `line-length = 100`. Run `ruff check src tests && black src tests`.
- `mypy --strict` on `src/buttdial`. The SDK has a strict type contract.
- Async-first. Prefer `async def` over threaded/sync variants for anything that might do I/O.

## Docs discipline

This project uses a lightweight docs-as-truth framework. Before merging non-trivial changes:

- Update `docs/SPEC.md` if the public API contract changes.
- Add to `docs/DECISIONS.md` when you pick one approach over another with a non-obvious trade-off.
- Add to `docs/ERRORS.md` when you discover a pitfall that'll bite the next person.
- Add to `docs/REASONING.md` when a debugging session took more than 3 steps.
- Bump the version header on any doc you modify.

## Commit / PR conventions

- Small, focused commits. One task per commit.
- Messages describe the **why**, not just the **what**.
- PRs should include a test that demonstrates the behavior changing.

## Design principles to preserve

1. **SDK is stateless.** No DB. No global mutable state beyond a configured `Client`.
2. **Host owns persistence.** Protocol adapters (`FailedMessageRepository`, `AgentDirectory`) are the contract; SDK never calls `async_session()` or opens a file.
3. **Errors are reported, not raised.** `SendResult` carries `failed/error/stage_failed/remediation`. Exceptions are reserved for misconfiguration and external auth failures (see `buttdial.errors`).
4. **Every known failure mode has a remediation.** If you add a new error path, add a matching entry to `REMEDIATIONS` in `doctor.py`.
5. **Handler errors are isolated.** In `InboundHandler` and `RetryWorker.on_dead_letter`, a bad host callback must not break the SDK's own work.

## Running the diagnostic against a real server

```bash
export BUTT_DIAL_URL=https://your-server/sse
export BUTT_DIAL_TOKEN=your-token
buttdial doctor --to +14155550123
```

## Reporting bugs

Open an issue with:
- Python version
- SDK version (`python -c "import buttdial; print(buttdial.__version__)"`)
- `buttdial doctor` output (redact tokens)
- Minimal repro if possible
