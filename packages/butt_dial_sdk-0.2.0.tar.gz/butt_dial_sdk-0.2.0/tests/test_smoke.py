"""Smoke test — package imports and exposes a version. Prevents an empty test suite."""

import buttdial


def test_version_is_exported() -> None:
    assert buttdial.__version__ == "0.2.0"


def test_cli_group_loads() -> None:
    from buttdial.doctor import cli

    assert callable(cli)
