"""Unit tests for `buttdial.settings`."""

from __future__ import annotations

import os
from unittest.mock import patch

from buttdial.settings import Settings, load


def test_reads_butt_dial_env_vars() -> None:
    with patch.dict(
        os.environ,
        {
            "BUTT_DIAL_URL": "https://example.test/sse",
            "BUTT_DIAL_TOKEN": "org-tok",
            "BUTT_DIAL_CLIENT_TOKEN": "client-tok",
        },
        clear=False,
    ):
        s = load()
    assert s.url == "https://example.test/sse"
    assert s.token == "org-tok"
    assert s.client_token == "client-tok"


def test_defaults_to_empty_strings() -> None:
    # Isolate: remove any Butt-Dial env vars that may be set on the dev box.
    cleaned = {
        k: v
        for k, v in os.environ.items()
        if not k.startswith("BUTT_DIAL_")
    }
    with patch.dict(os.environ, cleaned, clear=True):
        s = Settings(_env_file=None)  # type: ignore[call-arg]
    assert s.url == ""
    assert s.token == ""
    assert s.client_token == ""
