"""Unit tests for `buttdial.inbound.InboundHandler`."""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any

import pytest

from buttdial import DeliveryReceipt, InboundHandler, InboundMessage

WA_TEXT_PAYLOAD: dict[str, Any] = {
    "entry": [
        {
            "changes": [
                {
                    "value": {
                        "messages": [
                            {
                                "from": "+972501234567",
                                "id": "wamid.ABC",
                                "type": "text",
                                "text": {"body": "Hi there"},
                                "timestamp": "1745308800",  # 2025-04-22T08:00:00Z
                            }
                        ]
                    }
                }
            ]
        }
    ]
}

WA_STATUSES_PAYLOAD: dict[str, Any] = {
    "entry": [
        {
            "changes": [
                {
                    "value": {
                        "statuses": [
                            {
                                "id": "SM123",
                                "status": "delivered",
                                "timestamp": "1745308900",
                            },
                            {
                                "id": "SM124",
                                "status": "failed",
                                "timestamp": "1745308901",
                                "errors": [{"code": 131053, "title": "Media upload error"}],
                            },
                        ]
                    }
                }
            ]
        }
    ]
}


# ----- decorator registration + dispatch --------------------------------


@pytest.mark.asyncio
async def test_on_message_decorator_fires_for_matching_channel() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message(channel="whatsapp")
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    result = await h.handle_whatsapp_payload(WA_TEXT_PAYLOAD)

    assert result["messages"] == 1
    assert len(captured) == 1
    assert captured[0].sender == "+972501234567"
    assert captured[0].text == "Hi there"
    assert captured[0].channel == "whatsapp"
    assert captured[0].received_at is not None


@pytest.mark.asyncio
async def test_on_message_wildcard_gets_all_channels() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()  # no channel → wildcard
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    await h.handle_whatsapp_payload(WA_TEXT_PAYLOAD)
    await h.handle_generic_payload({"from": "+1", "body": "sms hi", "channel": "sms"})

    assert len(captured) == 2
    assert captured[0].channel == "whatsapp"
    assert captured[1].channel == "sms"


@pytest.mark.asyncio
async def test_channel_scoped_handler_does_not_fire_for_other_channels() -> None:
    h = InboundHandler()
    wa: list[InboundMessage] = []

    @h.on_message(channel="whatsapp")
    async def handle_wa(msg: InboundMessage) -> None:
        wa.append(msg)

    await h.handle_generic_payload({"from": "+1", "body": "sms hi", "channel": "sms"})

    assert wa == []  # SMS should not trigger WA-scoped handler


@pytest.mark.asyncio
async def test_handler_error_is_isolated() -> None:
    """If one handler raises, other handlers still run."""
    h = InboundHandler()
    successes: list[str] = []

    @h.on_message()
    async def bad(_msg: InboundMessage) -> None:
        raise RuntimeError("boom")

    @h.on_message()
    async def good(msg: InboundMessage) -> None:
        successes.append(msg.text)

    result = await h.handle_whatsapp_payload(WA_TEXT_PAYLOAD)

    assert result["messages"] == 1
    assert successes == ["Hi there"]


# ----- WhatsApp message parsing ----------------------------------------


@pytest.mark.asyncio
async def test_whatsapp_interactive_message_json_serialized() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "type": "interactive",
                                    "interactive": {"type": "button_reply", "id": "yes"},
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    assert len(captured) == 1
    parsed = json.loads(captured[0].text)
    assert parsed["id"] == "yes"


@pytest.mark.asyncio
async def test_whatsapp_skips_message_with_no_sender() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [{"type": "text", "text": {"body": "hi"}}]  # no "from"
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    assert captured == []


# ----- WhatsApp statuses → DeliveryReceipt -----------------------------


@pytest.mark.asyncio
async def test_whatsapp_statuses_dispatched_as_delivery_receipts() -> None:
    h = InboundHandler()
    captured: list[DeliveryReceipt] = []

    @h.on_delivery_receipt()
    async def handle(r: DeliveryReceipt) -> None:
        captured.append(r)

    result = await h.handle_whatsapp_payload(WA_STATUSES_PAYLOAD)

    assert result["receipts"] == 2
    assert captured[0].message_sid == "SM123"
    assert captured[0].status == "delivered"
    assert captured[1].message_sid == "SM124"
    assert captured[1].status == "failed"
    assert captured[1].error_code == "131053"


@pytest.mark.asyncio
async def test_whatsapp_statuses_with_unknown_status_skipped() -> None:
    h = InboundHandler()
    captured: list[DeliveryReceipt] = []

    @h.on_delivery_receipt()
    async def handle(r: DeliveryReceipt) -> None:
        captured.append(r)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "statuses": [
                                {"id": "SM1", "status": "unknown_new_state"},
                                {"status": "delivered"},  # no id
                            ]
                        }
                    }
                ]
            }
        ]
    }
    result = await h.handle_whatsapp_payload(payload)
    assert result["receipts"] == 0
    assert captured == []


# ----- Generic butt-dial payload ---------------------------------------


@pytest.mark.asyncio
async def test_generic_payload_parsed() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    result = await h.handle_generic_payload(
        {"from": "+1555", "body": "text me back", "channel": "sms", "thread_id": "T-9"}
    )
    assert result["messages"] == 1
    assert captured[0].channel == "sms"
    assert captured[0].thread_id == "T-9"


@pytest.mark.asyncio
async def test_generic_payload_missing_fields_ignored() -> None:
    h = InboundHandler()
    result = await h.handle_generic_payload({"from": "+1"})  # no body
    assert result["status"] == "ignored"


# ----- Verification ----------------------------------------------------


def test_whatsapp_signature_valid() -> None:
    secret = "s3cr3t"
    h = InboundHandler(whatsapp_webhook_secret=secret)
    body = b'{"hello":"world"}'
    sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    assert h.verify_whatsapp_signature(body, sig) is True


def test_whatsapp_signature_invalid() -> None:
    h = InboundHandler(whatsapp_webhook_secret="s3cr3t")
    assert h.verify_whatsapp_signature(b'{"hello":"world"}', "sha256=deadbeef") is False


def test_whatsapp_signature_skipped_when_no_secret() -> None:
    """Dev mode: no secret configured → signature check passes."""
    h = InboundHandler()
    assert h.verify_whatsapp_signature(b"anything", "") is True


def test_whatsapp_subscription_verify_ok() -> None:
    h = InboundHandler(whatsapp_verify_token="secret-verify")
    assert h.verify_whatsapp_subscription("subscribe", "secret-verify") is True


def test_whatsapp_subscription_verify_bad_token() -> None:
    h = InboundHandler(whatsapp_verify_token="secret-verify")
    assert h.verify_whatsapp_subscription("subscribe", "wrong") is False


def test_whatsapp_subscription_verify_no_config() -> None:
    h = InboundHandler()  # no verify_token
    assert h.verify_whatsapp_subscription("subscribe", "anything") is False


# ----- FastAPI router (integration) ------------------------------------


@pytest.fixture
def app_with_handler():
    """FastAPI app wrapping an InboundHandler, returned with TestClient."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    handler = InboundHandler(
        whatsapp_verify_token="verify-me",
        whatsapp_webhook_secret="",  # no sig check → simpler test
    )
    captured: dict[str, list] = {"msgs": [], "receipts": []}

    @handler.on_message(channel="whatsapp")
    async def on_msg(m: InboundMessage) -> None:
        captured["msgs"].append(m)

    @handler.on_delivery_receipt()
    async def on_r(r: DeliveryReceipt) -> None:
        captured["receipts"].append(r)

    app = FastAPI()
    app.include_router(handler.router, prefix="/api/buttdial/webhook")
    return TestClient(app), captured


def test_router_get_verify_success(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.get(
        "/api/buttdial/webhook/whatsapp/verify",
        params={
            "hub.mode": "subscribe",
            "hub.verify_token": "verify-me",
            "hub.challenge": "12345",
        },
    )
    assert resp.status_code == 200
    assert resp.json() == 12345


def test_router_get_verify_wrong_token(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.get(
        "/api/buttdial/webhook/whatsapp/verify",
        params={"hub.mode": "subscribe", "hub.verify_token": "wrong"},
    )
    assert resp.status_code == 403


def test_router_get_verify_unknown_channel(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.get("/api/buttdial/webhook/fax/verify")
    assert resp.status_code == 400


def test_router_post_whatsapp_dispatches(app_with_handler) -> None:
    client, captured = app_with_handler
    resp = client.post("/api/buttdial/webhook/whatsapp", json=WA_TEXT_PAYLOAD)
    assert resp.status_code == 200
    body = resp.json()
    assert body["messages"] == 1
    assert len(captured["msgs"]) == 1


def test_router_post_signature_invalid_rejected() -> None:
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    handler = InboundHandler(whatsapp_webhook_secret="s3cr3t")
    app = FastAPI()
    app.include_router(handler.router, prefix="/api/buttdial/webhook")
    client = TestClient(app)

    resp = client.post(
        "/api/buttdial/webhook/whatsapp",
        json=WA_TEXT_PAYLOAD,
        headers={"X-Hub-Signature-256": "sha256=bad"},
    )
    assert resp.status_code == 403


def test_router_post_butt_dial_generic(app_with_handler) -> None:
    client, _captured = app_with_handler
    resp = client.post(
        "/api/buttdial/webhook/butt-dial",
        json={"from": "+1", "body": "sms arrived", "channel": "sms"},
    )
    assert resp.status_code == 200
    assert resp.json()["messages"] == 1


def test_router_post_unknown_channel_ignored(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.post("/api/buttdial/webhook/fax", json={"x": 1})
    assert resp.status_code == 200
    assert resp.json()["status"] == "ignored"
