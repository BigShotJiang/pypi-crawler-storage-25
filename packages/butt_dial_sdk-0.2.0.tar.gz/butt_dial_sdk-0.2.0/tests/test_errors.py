"""Unit tests for `buttdial.errors`."""

from __future__ import annotations

import pytest

from buttdial import (
    AgentNotFound,
    AgentNotProvisioned,
    ButtDialError,
    ConfigError,
    TransportError,
)


def test_base_error_carries_optional_metadata() -> None:
    e = ButtDialError(
        "bad config",
        code="NO_TOKEN",
        stage="config",
        remediation="Set BUTT_DIAL_TOKEN.",
    )
    assert str(e) == "bad config"
    assert e.code == "NO_TOKEN"
    assert e.stage == "config"
    assert e.remediation == "Set BUTT_DIAL_TOKEN."


def test_base_error_without_metadata() -> None:
    e = ButtDialError("something broke")
    assert e.code is None
    assert e.stage is None
    assert e.remediation is None


def test_config_error_is_buttdial_error() -> None:
    assert issubclass(ConfigError, ButtDialError)
    with pytest.raises(ButtDialError):
        raise ConfigError("boom")


def test_transport_error_is_buttdial_error() -> None:
    assert issubclass(TransportError, ButtDialError)
    with pytest.raises(ButtDialError):
        raise TransportError("boom")


def test_agent_not_found_dual_inheritance() -> None:
    """Catchable via ButtDialError OR the plain KeyError idiom."""
    e = AgentNotFound("A-1")
    assert isinstance(e, ButtDialError)
    assert isinstance(e, KeyError)

    with pytest.raises(ButtDialError):
        raise AgentNotFound("A-1")

    with pytest.raises(KeyError):
        raise AgentNotFound("A-1")


def test_agent_not_provisioned_dual_inheritance() -> None:
    e = AgentNotProvisioned("A-2")
    assert isinstance(e, ButtDialError)
    assert isinstance(e, ValueError)

    with pytest.raises(ButtDialError):
        raise AgentNotProvisioned("A-2")

    with pytest.raises(ValueError):
        raise AgentNotProvisioned("A-2")
