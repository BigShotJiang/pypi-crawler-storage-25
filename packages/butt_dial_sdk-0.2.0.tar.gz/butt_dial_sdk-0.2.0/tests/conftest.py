"""Shared pytest fixtures. Real fixtures land in Phase 7 (`buttdial.testing`)."""
