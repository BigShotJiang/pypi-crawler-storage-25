"""Tests for `buttdial.accounts` — the onboarding + token-rotation REST surface.

Uses `httpx.MockTransport` (built into httpx, no extra dep) to intercept
requests. `AccountsClient.__init__` accepts a `transport=` kwarg so tests can
inject the mock; production passes nothing and gets the real httpx transport.
"""

from __future__ import annotations

import json
from typing import Callable

import httpx
import pytest

from buttdial import (
    AccountsClient,
    AccountsError,
    ChallengeNotFound,
    ConfigError,
    EmailAlreadyRegistered,
    OTPExpired,
    OTPInvalid,
    OTPMaxAttempts,
    PhoneNotConfigured,
    TokenRevoked,
    TransportError,
    VerificationTokenExpired,
)

BASE = "https://bd.test"


def _json_handler(
    routes: dict[tuple[str, str], httpx.Response],
    *,
    recorded: list[httpx.Request] | None = None,
) -> Callable[[httpx.Request], httpx.Response]:
    """Build a MockTransport handler from a (method, path) → Response map.

    Records each incoming request on `recorded` if provided so tests can
    assert on headers/body.
    """
    def handler(request: httpx.Request) -> httpx.Response:
        if recorded is not None:
            recorded.append(request)
        key = (request.method.upper(), request.url.path)
        if key not in routes:
            return httpx.Response(404, json={"code": "UNMOCKED", "message": f"no mock for {key}"})
        resp = routes[key]
        # Return a fresh Response so the stream isn't drained between calls.
        return httpx.Response(
            status_code=resp.status_code,
            headers=resp.headers,
            content=resp.content,
        )
    return handler


def _client(
    routes: dict[tuple[str, str], httpx.Response] | None = None,
    *,
    owner_token: str | None = None,
    recorded: list[httpx.Request] | None = None,
) -> AccountsClient:
    transport = httpx.MockTransport(_json_handler(routes or {}, recorded=recorded))
    return AccountsClient(BASE, owner_token=owner_token, transport=transport)


# ---------------------------------------------------------------------------
# Configuration guardrails
# ---------------------------------------------------------------------------


def test_construct_requires_base_url() -> None:
    with pytest.raises(ConfigError):
        AccountsClient("")


def test_with_token_returns_a_new_instance() -> None:
    a = AccountsClient(BASE)
    b = a.with_token("tok-1")
    assert a.owner_token is None
    assert b.owner_token == "tok-1"
    assert a is not b


@pytest.mark.asyncio
async def test_authenticated_call_without_token_raises_config_error() -> None:
    c = _client()
    with pytest.raises(ConfigError):
        await c.set_phone("+14155550123")


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_register_returns_org_id_and_verification_sent() -> None:
    recorded: list[httpx.Request] = []
    c = _client({
        ("POST", "/api/orgs/register"):
            httpx.Response(200, json={"org_id": "org-1", "verification_sent": True}),
    }, recorded=recorded)

    result = await c.register("Acme", "alice@acme.com")
    assert result == {"org_id": "org-1", "verification_sent": True}
    assert len(recorded) == 1
    body = json.loads(recorded[0].content)
    # Server contract is camelCase.
    assert body == {"orgName": "Acme", "ownerEmail": "alice@acme.com"}
    # Register is unauthenticated — no bearer header attached.
    assert "authorization" not in {k.lower(): v for k, v in recorded[0].headers.items()}


@pytest.mark.asyncio
async def test_verify_returns_owner_token() -> None:
    c = _client({
        ("POST", "/api/orgs/verify"):
            httpx.Response(200, json={
                "owner_token": "tok-alpha", "org_id": "org-1", "mode": "aggregated",
            }),
    })
    result = await c.verify("email-link-token")
    assert result["owner_token"] == "tok-alpha"


@pytest.mark.asyncio
async def test_set_and_confirm_phone_attach_bearer_token() -> None:
    recorded: list[httpx.Request] = []
    c = _client({
        ("POST", "/api/orgs/me/phone/set"):
            httpx.Response(200, json={"challenge_id": "ch-1"}),
        ("POST", "/api/orgs/me/phone/confirm"):
            httpx.Response(200, json={"ok": True, "phone_hint": "+1********23"}),
    }, owner_token="tok-alpha", recorded=recorded)

    ch = await c.set_phone("+14155550123")
    assert ch == {"challenge_id": "ch-1"}
    result = await c.confirm_phone("ch-1", "654321")
    assert result["ok"] is True

    for req in recorded:
        assert req.headers["authorization"] == "Bearer tok-alpha"


@pytest.mark.asyncio
async def test_rotate_token_convenience_chains_request_then_confirm() -> None:
    recorded: list[httpx.Request] = []
    c = _client({
        ("POST", "/api/orgs/me/rotate-token/request"):
            httpx.Response(200, json={"challenge_id": "ch-rot", "phone_hint": "+1********23"}),
        ("POST", "/api/orgs/me/rotate-token/confirm"):
            httpx.Response(200, json={"token": "tok-beta"}),
    }, owner_token="tok-alpha", recorded=recorded)

    prompted_hints: list[str] = []

    def prompt(hint: str) -> str:
        prompted_hints.append(hint)
        return "999888"

    result = await c.rotate_token(otp_prompt=prompt)
    assert result == {"token": "tok-beta"}
    assert prompted_hints == ["+1********23"]

    # Confirm request carried the OTP and the challenge id.
    confirm_body = json.loads(recorded[-1].content)
    assert confirm_body == {"challengeId": "ch-rot", "otp": "999888"}


@pytest.mark.asyncio
async def test_rotate_token_supports_async_prompt() -> None:
    recorded: list[httpx.Request] = []
    c = _client({
        ("POST", "/api/orgs/me/rotate-token/request"):
            httpx.Response(200, json={"challenge_id": "ch", "phone_hint": "+1***"}),
        ("POST", "/api/orgs/me/rotate-token/confirm"):
            httpx.Response(200, json={"token": "tok-new"}),
    }, owner_token="tok-alpha", recorded=recorded)

    async def prompt(_hint: str) -> str:
        return "111222"

    result = await c.rotate_token(otp_prompt=prompt)
    assert result["token"] == "tok-new"
    confirm_body = json.loads(recorded[-1].content)
    assert confirm_body["otp"] == "111222"


@pytest.mark.asyncio
async def test_get_account_returns_account_shape() -> None:
    c = _client({
        ("GET", "/api/orgs/me"):
            httpx.Response(200, json={
                "org_id": "org-1",
                "name": "Acme",
                "owner_email": "alice@acme.com",
                "owner_phone_hint": "+1********23",
                "mode": "aggregated",
                "created_at": "2026-04-24T12:00:00Z",
                "status": "active",
            }),
    }, owner_token="tok-alpha")
    info = await c.get_account()
    assert info["org_id"] == "org-1"
    assert info["owner_phone_hint"] == "+1********23"


# ---------------------------------------------------------------------------
# Error-code → exception mapping
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_email_already_registered() -> None:
    c = _client({
        ("POST", "/api/orgs/register"):
            httpx.Response(409, json={
                "code": "EMAIL_ALREADY_REGISTERED",
                "message": "alice@acme.com already owns an org",
            }),
    })
    with pytest.raises(EmailAlreadyRegistered) as exc:
        await c.register("Acme", "alice@acme.com")
    assert exc.value.code == "EMAIL_ALREADY_REGISTERED"
    assert exc.value.status_code == 409
    assert isinstance(exc.value, AccountsError)


@pytest.mark.asyncio
async def test_verification_token_expired() -> None:
    c = _client({
        ("POST", "/api/orgs/verify"):
            httpx.Response(400, json={
                "code": "VERIFICATION_TOKEN_EXPIRED", "message": "Link expired",
            }),
    })
    with pytest.raises(VerificationTokenExpired):
        await c.verify("stale-token")


@pytest.mark.asyncio
async def test_phone_not_configured_on_rotate() -> None:
    c = _client({
        ("POST", "/api/orgs/me/rotate-token/request"):
            httpx.Response(400, json={
                "code": "PHONE_NOT_CONFIGURED",
                "message": "Set an admin phone before rotating",
            }),
    }, owner_token="tok-alpha")
    with pytest.raises(PhoneNotConfigured):
        await c.rotate_token_request()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "code,cls",
    [
        ("OTP_INVALID", OTPInvalid),
        ("OTP_EXPIRED", OTPExpired),
        ("OTP_MAX_ATTEMPTS", OTPMaxAttempts),
        ("CHALLENGE_NOT_FOUND", ChallengeNotFound),
    ],
)
async def test_otp_and_challenge_errors_map_to_typed_exceptions(code, cls) -> None:
    c = _client({
        ("POST", "/api/orgs/me/phone/confirm"):
            httpx.Response(400, json={"code": code, "message": "nope"}),
    }, owner_token="tok-alpha")
    with pytest.raises(cls) as exc:
        await c.confirm_phone("ch-1", "000000")
    assert exc.value.code == code


@pytest.mark.asyncio
async def test_token_revoked_on_get_account_after_rotation() -> None:
    c = _client({
        ("GET", "/api/orgs/me"):
            httpx.Response(401, json={
                "code": "TOKEN_REVOKED",
                "message": "This token was rotated out",
            }),
    }, owner_token="tok-old")
    with pytest.raises(TokenRevoked):
        await c.get_account()


@pytest.mark.asyncio
async def test_unknown_error_code_falls_back_to_base_accounts_error() -> None:
    c = _client({
        ("POST", "/api/orgs/register"):
            httpx.Response(500, json={
                "code": "INTERNAL_UNKNOWN", "message": "something exploded",
            }),
    })
    with pytest.raises(AccountsError) as exc:
        await c.register("Acme", "alice@acme.com")
    # Not one of the typed subclasses — raw AccountsError.
    assert type(exc.value) is AccountsError
    assert exc.value.code == "INTERNAL_UNKNOWN"
    assert exc.value.status_code == 500


@pytest.mark.asyncio
async def test_error_without_code_uses_reason_phrase() -> None:
    c = _client({
        ("POST", "/api/orgs/register"): httpx.Response(503, text=""),
    })
    with pytest.raises(AccountsError) as exc:
        await c.register("Acme", "alice@acme.com")
    assert "503" in str(exc.value)


# ---------------------------------------------------------------------------
# Transport errors
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_network_error_surfaces_as_transport_error() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("dns blackhole")

    transport = httpx.MockTransport(handler)
    c = AccountsClient(BASE, transport=transport)

    with pytest.raises(TransportError):
        await c.register("Acme", "alice@acme.com")
