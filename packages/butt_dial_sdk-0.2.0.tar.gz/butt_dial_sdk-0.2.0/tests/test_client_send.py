"""Unit tests for `buttdial.client.Client.send_message`.

Tests use monkeypatch on `Client._call_send_tool` to avoid hitting the real
MCP/SSE transport. Transport-level behavior (real SSE handshake, tool list)
is covered by the fake server in Phase 7.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from buttdial import Client, SendResult


def _make_client(**kwargs: Any) -> Client:
    defaults: dict[str, Any] = {"token": "org-tok", "url": "https://fake/sse"}
    defaults.update(kwargs)
    return Client(**defaults)


@pytest.mark.asyncio
async def test_no_token_returns_config_error() -> None:
    c = Client(url="https://fake/sse")  # neither token nor client_token
    result = await c.send_message(to="+1", body="hi")
    assert isinstance(result, SendResult)
    assert result.failed is True
    assert result.stage_failed == "config"
    assert result.message_sid is None
    assert result.error is not None and "token" in result.error.lower()
    assert result.remediation  # non-empty guidance


@pytest.mark.asyncio
async def test_successful_send_returns_sid(monkeypatch: pytest.MonkeyPatch) -> None:
    c = _make_client()
    captured: dict[str, Any] = {}

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["token"] = token
        captured["args"] = args
        return {"messageId": "SM123"}, object()

    monkeypatch.setattr(c, "_call_send_tool", fake_call)

    result = await c.send_message(to="+972501234567", body="hi", sender_name="Sara")

    assert result.message_sid == "SM123"
    assert result.failed is False
    assert result.ok is True
    assert result.delivered is True  # SPEC alias for .ok
    assert captured["token"] == "org-tok"
    assert captured["args"]["to"] == "+972501234567"
    assert captured["args"]["body"] == "hi"
    assert captured["args"]["channel"] == "whatsapp"
    assert captured["args"]["senderName"] == "Sara"
    assert "idempotencyKey" in captured["args"]


@pytest.mark.asyncio
async def test_agent_token_overrides_client_token(monkeypatch: pytest.MonkeyPatch) -> None:
    c = _make_client(client_token="legacy-client-tok")
    captured: dict[str, Any] = {}

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["token"] = token
        return {"messageId": "SM1"}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    await c.send_message(to="+1", body="x", agent_token="agent-tok")
    assert captured["token"] == "agent-tok"


@pytest.mark.asyncio
async def test_token_fallback_order(monkeypatch: pytest.MonkeyPatch) -> None:
    """Priority: agent_token > self.token (org) > self.client_token (legacy)."""
    # Only legacy client_token set
    c = Client(url="https://fake/sse", client_token="legacy")
    captured: dict[str, Any] = {}

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["token"] = token
        return {"messageId": "SM1"}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    await c.send_message(to="+1", body="x")
    assert captured["token"] == "legacy"


@pytest.mark.asyncio
async def test_retry_three_times_on_transport_error(monkeypatch: pytest.MonkeyPatch) -> None:
    c = _make_client(max_send_attempts=3)
    calls = {"n": 0}

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        calls["n"] += 1
        raise ConnectionError("SSE connection refused")

    async def no_sleep(_delay: float) -> None:
        return None

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    monkeypatch.setattr(asyncio, "sleep", no_sleep)

    result = await c.send_message(to="+1", body="x")
    assert calls["n"] == 3
    assert result.failed is True
    assert result.stage_failed == "transport"
    assert result.error is not None
    assert "refused" in result.error.lower()


@pytest.mark.asyncio
async def test_extracts_sid_from_alternate_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    """Responses in the wild use `messageId`, `sid`, or `message_sid` interchangeably."""
    c = _make_client()

    async def fake_call_sid(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"sid": "SMabc"}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call_sid)
    r = await c.send_message(to="+1", body="hi")
    assert r.message_sid == "SMabc"

    async def fake_call_snake(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"message_sid": "SMxyz"}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call_snake)
    r = await c.send_message(to="+1", body="hi")
    assert r.message_sid == "SMxyz"


@pytest.mark.asyncio
async def test_missing_sid_returns_failed_like_result(monkeypatch: pytest.MonkeyPatch) -> None:
    """If the server returns no SID and no error, `.ok` is False with a parse-stage failure."""
    c = _make_client()

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"ok": True}, None  # no sid/messageId/message_sid, no error

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    result = await c.send_message(to="+1", body="hi")
    assert result.message_sid is None
    assert result.ok is False
    assert result.failed is True
    assert result.stage_failed == "parse"


@pytest.mark.asyncio
async def test_server_error_surfaced_in_send_result(monkeypatch: pytest.MonkeyPatch) -> None:
    """When the server returns {"error": "..."}, SendResult.error carries the real message.

    Regression test — in v0.1.0 we swallowed server errors silently. iv-bknd
    hit this with an "agentId is required" error that the doctor reported as
    the useless "no message_sid returned".
    """
    c = _make_client()

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"error": "agentId is required (or use a client token)"}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    result = await c.send_message(to="+1", body="hi")
    assert result.failed is True
    assert result.stage_failed == "server"
    assert "agentid is required" in (result.error or "").lower()
    # Remediation should be the specific agentId guidance
    assert result.remediation is not None
    assert "agent_token" in result.remediation.lower()


@pytest.mark.asyncio
async def test_server_errors_list_variant_is_surfaced(monkeypatch: pytest.MonkeyPatch) -> None:
    """Some Butt-Dial tools respond with {"errors": [...]} (list, plural)."""
    c = _make_client()

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"errors": ["bad recipient", "over quota"]}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    result = await c.send_message(to="+1", body="hi")
    assert result.failed is True
    assert "bad recipient" in (result.error or "")
    assert "over quota" in (result.error or "")


@pytest.mark.asyncio
async def test_optional_fields_mapped_to_camel_case(monkeypatch: pytest.MonkeyPatch) -> None:
    c = _make_client()
    captured: dict[str, Any] = {}

    async def fake_call(token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["args"] = args
        return {"messageId": "S1"}, None

    monkeypatch.setattr(c, "_call_send_tool", fake_call)
    await c.send_message(
        to="+1",
        body="hi",
        language="en",
        thread_id="T-1",
        entity_id="E-1",
        reply_msg_id="M-1",
        fallback_channels=["sms"],
        scheduled_at="2026-12-31T00:00:00Z",
        idempotency_key="idem-1",
        extra={"customField": 42},
    )
    args = captured["args"]
    assert args["language"] == "en"
    assert args["threadId"] == "T-1"
    assert args["entityId"] == "E-1"
    assert args["replyMsgId"] == "M-1"
    assert args["fallbackChannels"] == ["sms"]
    assert args["scheduledAt"] == "2026-12-31T00:00:00Z"
    assert args["idempotencyKey"] == "idem-1"
    assert args["customField"] == 42


def test_client_requires_url() -> None:
    with pytest.raises(ValueError, match="url"):
        Client(token="t")


def test_from_env_reads_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BUTT_DIAL_URL", "https://env.test/sse")
    monkeypatch.setenv("BUTT_DIAL_TOKEN", "env-tok")
    monkeypatch.setenv("BUTT_DIAL_CLIENT_TOKEN", "env-client-tok")
    c = Client.from_env()
    assert c.url == "https://env.test/sse"
    assert c.token == "env-tok"
    assert c.client_token == "env-client-tok"
