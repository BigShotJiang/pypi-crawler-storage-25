<!-- version: 1.11 | updated: 2026-04-23 -->

# TODO

Status: **open** / **done**

Phased plan for extracting butt-dial from **iv-bknd** (the shared backend where `engine/comms.py` lives today) into a standalone OSS SDK. v95 is a downstream consumer of iv-bknd; it benefits transitively but does not import the SDK directly. Do phases in order; do not jump ahead without developer direction.

## Phase 1 — Repo setup
- [x] done — Initialize git repo in `butt-dial-sdk/`
- [x] done — Write `pyproject.toml` (name `butt-dial-sdk`, version 0.1.0, deps, extras `[router]` `[all]`, CLI entry point `buttdial`)
- [x] done — Write `LICENSE` (MIT)
- [x] done — Write `README.md` stub (quickstart placeholder)
- [x] done — Write `.gitignore` + `ruff` / `black` config
- [x] done — Create `src/buttdial/` + `tests/` skeleton

## Phase 2 — Core outbound (extract from iv-bknd)
- [x] done — `buttdial.settings` — env-var loader (`BUTT_DIAL_URL` / `BUTT_DIAL_TOKEN` / `BUTT_DIAL_CLIENT_TOKEN`)
- [x] done — `buttdial.client.Client` — MCP/SSE connect, send tool invocation, SID extraction
- [x] done — `Client.send_message(...)` → `SendResult` with full optional-field mapping (camelCase on the wire)
- [x] done — Token resolution: agent > org > legacy client (preserves iv-bknd priority)
- [x] done — `buttdial.models` — `SendResult`, `FailedMessage`, `InboundMessage`, `DeliveryReceipt`, `StatusUpdate`, `AgentInfo`, `DoctorStage`, `DoctorReport`
- [x] done — Phase 2 tests (12 new, 14 total) all pass

## Phase 3 — Callbacks / inbound
- [x] done — `buttdial.inbound.InboundHandler` — decorator registry (`on_message`, `on_delivery_receipt`, `on_status_update`) with channel filter + wildcard + error isolation
- [x] done — WhatsApp payload parser: text / interactive / generic (normalize envelope → `InboundMessage`)
- [x] done — WhatsApp **statuses** parser → `DeliveryReceipt` (new — iv-bknd does not have this)
- [x] done — Generic Butt-Dial payload parser for SMS / email / voice
- [x] done — Webhook signature verification — HMAC-SHA256 with `X-Hub-Signature-256`
- [x] done — `handler.router` — `POST /{channel}` + `GET /{channel}/verify` (lazy fastapi via module-top try/except)
- [x] done — Subscription verification for WhatsApp (`hub.mode` + `hub.verify_token` + `hub.challenge` echo)
- [x] done — Phase 3 tests (23 new, 37 total) all pass
- [x] done — Captured FastAPI lazy-import 422 bug in `docs/ERRORS.md` + `docs/REASONING.md`

## Phase 4 — Retry worker (protocol only, no DB)
- [x] done — `buttdial.retry.FailedMessageRepository` protocol (fetch_due, mark_delivered, increment_retry, mark_dead) — `runtime_checkable`
- [x] done — `RetryWorker.run_once()` — fetch due, send, update via repo; poison-row isolation (one bad msg doesn't stop batch)
- [x] done — `RetryWorker.start(interval_seconds, warmup_seconds)` / `stop()` — background loop lifecycle with `CancelledError` handling
- [x] done — Pluggable backoff (default `2^n` minutes matching iv-bknd; `default_backoff` exported)
- [x] done — Dead-letter transition when `retry_count >= max_retries` + optional `on_dead_letter` host hook (error-isolated)
- [x] done — Phase 4 tests (13 new, 50 total) all pass

## Phase 5 — Admin router
- [x] done — `buttdial.router.AgentDirectory` protocol (list_agents, overview_snapshot, activate, deactivate) — `runtime_checkable`
- [x] done — `buttdial.router.AdminFailedMessageRepository` protocol (extends worker protocol with `list`, `count_pending`, `force_retry`, `dismiss`)
- [x] done — SDK exceptions: `AgentNotFound(KeyError)`, `AgentNotProvisioned(ValueError)`
- [x] done — `Client.list_tools()`, `Client.ping()`, `Client.fetch_usage_summary()` helpers for overview composition
- [x] done — `make_router(client, repo, directory)` factory
- [x] done — `GET /overview` (connection + tools + totals + failed queue + cost summary)
- [x] done — `GET /agents`
- [x] done — `POST /agents/{id}/activate` — 404 on AgentNotFound, 400 on AgentNotProvisioned (fixes iv-bknd's buggy update() call)
- [x] done — `POST /agents/{id}/deactivate`
- [x] done — `GET /failed-messages` with `?status=&limit=` filters
- [x] done — `POST /failed-messages/{id}/retry` (404 if not pending)
- [x] done — `POST /failed-messages/{id}/dismiss` (changed from iv-bknd's DELETE)
- [~] skip — `GET /usage` — iv-bknd's version is heavy host-specific SQL reporting; out of scope for SDK v0.1. Hosts build their own.
- [x] done — Phase 5 tests (20 new, 70 total) all pass

## Phase 6 — Diagnostic (`buttdial doctor`)
- [x] done — `DoctorReport` + `DoctorStage` (already in Phase 2 `models.py`)
- [x] done — Stage 1: config validation (`stage_config`)
- [x] done — Stage 2: server reachability via `httpx` (`stage_reachability`)
- [x] done — Stages 3+4: SSE handshake + tool list share one session (`_probe_session`)
- [x] done — Stage 5: `send_message` contract (`stage_send`)
- [x] done — Stage 6: delivery receipt watcher (`stage_receipt`) — subscribes to `InboundHandler`, awaits matching SID
- [x] done — Stage 7: human ack loopback (`stage_ack`) — awaits inbound reply from test recipient
- [x] done — Remediation map `REMEDIATIONS` + `find_remediation()` (11 known modes: 401, 403, connection refused, timeouts, DNS, SSL, invalid recipient, missing token)
- [x] done — `run_diagnostic()` orchestration with fail-fast short-circuit between stages 1-4 and skip logic for stages 5-7
- [x] done — CLI: `buttdial doctor --to <phone> [--expect-ack]` via click; prints ✓/✗ per stage with remediation on failure
- [x] done — Pytest usage pattern established (call `run_diagnostic()` with a live `InboundHandler` + fire `_dispatch_receipt` / `_dispatch_message` from the test)
- [x] done — Phase 6 tests (23 new, 93 total) all pass

## Phase 7 — Testing utilities
- [x] done — `buttdial.testing.FakeButtDialServer` — monkeypatches `mcp.ClientSession` + `mcp.client.sse.sse_client`; covers `send_message`, `list_tools`, `ping` uniformly
- [x] done — `fake_server` pytest fixture (in `buttdial.testing.__init__`)
- [x] done — Inbound simulation: `simulate_inbound()` / `simulate_receipt()` fire events into host's `InboundHandler`
- [x] done — Error scenario helpers: `on_send(sid=..., error=..., raw_text=..., count=N)`
- [x] done — Install/uninstall lifecycle (context manager + idempotent manual)
- [x] done — `sent_messages` capture (tool + token + args) for assertions
- [x] done — End-to-end doctor integration tests against the fake (no per-stage monkeypatching)
- [x] done — Phase 7 tests (18 new, 111 total) all pass

## Phase 8 — Typed errors
- [x] done — `buttdial.errors.ButtDialError` base + `ConfigError` + `TransportError` (`.code` / `.stage` / `.remediation` attributes mirror `SendResult`/`DoctorStage` fields)
- [x] done — `AgentNotFound`/`AgentNotProvisioned` now inherit from both `ButtDialError` AND their builtin (`KeyError`/`ValueError`) — `except ButtDialError:` catches all SDK-raised errors, Python idioms still work
- [~] note — Most SDK failures are *reported* (`SendResult`) not raised, by design. Central remediation map lives in `doctor.py`; the error classes reference it via the `.remediation` attribute.
- [x] done — Phase 8 tests (6 new, 117 total) all pass

## Phase 9 — Tests
All items already delivered across Phases 2-8. Documenting mapping here:

- [x] done — Unit tests: `Client` → `tests/test_client_send.py` (10)
- [x] done — Unit tests: `RetryWorker` → `tests/test_retry.py` (13)
- [x] done — Unit tests: `InboundHandler` → `tests/test_inbound.py` (23)
- [x] done — Integration: `FakeButtDialServer` → `tests/test_fake_server.py` (18, incl. 2 end-to-end doctor runs)
- [x] done — Contract tests: every doctor stage → `tests/test_doctor.py` (23)
- [x] done — Router tests: FastAPI TestClient for all endpoints → `tests/test_router.py` (20)
- [x] done — Typed errors → `tests/test_errors.py` (6)
- [x] done — Settings env loading → `tests/test_settings.py` (2)
- [x] done — Smoke tests → `tests/test_smoke.py` (2)
- [x] done — Added `pytest-cov` with coverage config in pyproject
- [x] done — Current coverage: **86%** overall (`__init__`/`errors`/`settings` 100%, lower bands in defensive error-handling branches)

## Phase 10 — Integrate into iv-bknd
Scope for first pass: swap `engine/comms.py send_message()` to delegate to `buttdial.Client` while preserving the 28-caller signature exactly. Retry worker, admin router, and webhook handler left intact — those are lower-risk follow-up swaps once this one proves the SDK works against real iv-bknd traffic.

- [x] done — Add editable install: `pip install -e ../butt-dial-sdk` in iv-bknd env
- [x] done — iv-bknd `pyproject.toml` declares `butt-dial-sdk>=0.1.0` dependency (local editable for dev; PyPI pin once published)
- [x] done — `engine/comms.py send_message()` now delegates MCP transport to `buttdial.Client`; preserves signature + return dict shape
- [x] done — Pre-send helpers (`validate_number`, `check_consent`, `detect_language`) remain iv-bknd concerns as designed
- [x] done — Full iv-bknd test suite green — **187 passed, 0 failed** (16 butt-dial-relevant tests all still pass without a single call-site change)
- [ ] open (follow-up) — Swap `engine/comms_retry_worker.py` to use SDK `RetryWorker` + host-implemented `FailedMessageRepository`
- [ ] open (follow-up) — Swap `api/routes/butt_dial.py` to use SDK `make_router(client, repo, directory)`
- [ ] open (follow-up) — Swap `api/routes/webhook.py` to use SDK `InboundHandler` + register iv-bknd's `inbound_poller.process_inbound_message` as `on_message` callback
- [ ] open (follow-up) — Delete iv-bknd tests that duplicate SDK coverage once the above swaps are done
- [ ] open (follow-up) — Update iv-bknd `docs/SPEC.md` to reference SDK

## v0.1.1 — bugfix pass (discovered during first real-world run)
- [ ] open — `buttdial doctor` stage 3 unwraps `ExceptionGroup` / `TaskGroup` sub-exceptions. Current behavior reports *"unhandled errors in a TaskGroup (1 sub-exception)"* instead of the real `HTTPStatusError`/etc. Root cause: the `mcp` library runs SSE inside `asyncio.TaskGroup` (Python 3.11+), which wraps failures in `ExceptionGroup`. Fix in `doctor._probe_session` + `Client._call_send_tool`.
- [ ] open — Add remediation for `401 Unauthorized` in `REMEDIATIONS` pointing to token regeneration (iv-bknd hit this with a stale `BUTT_DIAL_TOKEN` on 2026-04-23).
- [ ] open — Add remediation for `429 Too Many Requests` — "Butt-Dial is rate-limiting. Wait 60-180s then retry. If persistent, check your account's rate limit quota." (iv-bknd hit this immediately after the 401 during debug on 2026-04-23.)
- [ ] open — Force UTF-8 stdout in `buttdial doctor` CLI output on Windows, OR provide an `--ascii` flag / auto-fallback when stdout encoding can't encode `✓`/`✗`. iv-bknd's default PowerShell handles them fine; Git Bash + cp1252 crashes with `UnicodeEncodeError`. Simplest fix: catch UnicodeEncodeError once and retry with `[OK]` / `[FAIL]`.
- [ ] open — Similar: surface underlying `httpx.HTTPStatusError` through stage 2 + 5 so remediation matcher can hit the right remedy.
- [ ] open — Release as `butt-dial-sdk==0.1.1` once iv-bknd confirms improved diagnostic works.

## Phase 11 — OSS polish
- [x] done — README quickstart (zero → first message in < 10 min, component table, design principles)
- [x] done — `examples/minimal/send_one.py` — standalone script
- [x] done — `examples/with-retry/sqlalchemy_repo.py` — reference `FailedMessageRepository` impl
- [x] done — `examples/with-inbound/app.py` — full round-trip FastAPI app
- [x] done — `CONTRIBUTING.md`
- [x] done — GitHub Actions CI workflow (`.github/workflows/ci.yml`) — lint + format + mypy + pytest + coverage on Py 3.11/3.12/3.13
- [x] done — `docs/PUBLISHING.md` — step-by-step release checklist
- [ ] open (requires Inon) — Decide GitHub repo location: personal or `95percent-ai` org
- [ ] open (requires Inon) — Create the GitHub repo and push `main`
- [ ] open (requires Inon) — Publish to TestPyPI, smoke test
- [ ] open (requires Inon) — Publish to PyPI v0.1.0
