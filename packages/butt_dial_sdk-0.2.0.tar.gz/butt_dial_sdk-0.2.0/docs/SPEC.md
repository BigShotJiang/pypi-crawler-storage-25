<!-- version: 1.2 | updated: 2026-04-22 -->

# butt-dial-sdk

Open-source Python SDK that is a **client-side tunnel** between a host application and the Butt-Dial communication server. Wraps all the integration knowledge — MCP/SSE transport, outbound message sending with token validation, retry orchestration, inbound callback handling, and an end-to-end diagnostic — so any agentic system can add reliable human-facing communication with minimal setup.

**Key principle:** the SDK is stateless transport + protocol. The host app owns all persistence (agents, messages, failed-message queue). The SDK defines the interfaces; the host plugs in its DB.

## Goals

1. **Testing** — host apps can verify their Butt-Dial integration works end-to-end, with a staged diagnostic that pinpoints failures and returns actionable remediation.
2. **SDK for agentic systems** — any Python agent framework installs the package, implements two small interfaces (token source, failed-message repo), and starts sending + receiving messages reliably.

## Who uses it

- Agentic systems that need to send/receive messages to/from humans via Butt-Dial channels (WhatsApp / SMS / email).
- **iv-bknd** as the reference consumer — current home of the `engine/comms.py` being extracted. v95 benefits transitively as a downstream consumer of iv-bknd.
- Third-party Python apps installing from PyPI.

## Public API

### `buttdial.Client` — outbound

```python
from buttdial import Client, SendResult

bd = Client(token="...", url="https://...")          # or Client.from_env()

result: SendResult = await bd.send_message(
    to="+972501234567",
    body="hi",
    channel="whatsapp",           # default "whatsapp"; also "sms", "email"
    agent_token=None,             # per-agent token overrides client token
    sender_name=None,
    thread_id=None,
    entity_id=None,
    reply_msg_id=None,
)
# SendResult: message_sid, delivered, failed, error, stage_failed, remediation, raw
```

### `buttdial.InboundHandler` — callbacks

Normalizes channel-specific inbound payloads (WhatsApp envelopes, SMS, email) into a single `InboundMessage` shape. Handles webhook verification. Exposes a FastAPI router the host mounts.

```python
from buttdial import InboundHandler, InboundMessage, DeliveryReceipt, StatusUpdate

handler = InboundHandler(verify_token="...", webhook_secret="...")

@handler.on_message(channel="whatsapp")
async def on_msg(msg: InboundMessage):
    # msg.from, msg.channel, msg.text, msg.thread_id, msg.raw, msg.received_at
    ...

@handler.on_delivery_receipt()
async def on_receipt(receipt: DeliveryReceipt):
    # receipt.message_sid, receipt.status, receipt.timestamp
    ...

@handler.on_status_update()
async def on_status(status: StatusUpdate):
    ...

# Mount — handler.router serves POST /{channel} and GET /{channel}/verify
app.include_router(handler.router, prefix="/api/buttdial/webhook")
```

### `buttdial.retry.RetryWorker` — host-backed repository

```python
from buttdial.retry import RetryWorker, FailedMessageRepository, FailedMessage

class MyRepo(FailedMessageRepository):
    async def fetch_due(self, limit: int) -> list[FailedMessage]: ...
    async def mark_delivered(self, msg_id: str, message_sid: str) -> None: ...
    async def increment_retry(self, msg_id: str, error: str, next_retry_at: datetime) -> None: ...
    async def mark_dead(self, msg_id: str, error: str) -> None: ...

worker = RetryWorker(
    repo=MyRepo(),
    client=bd,
    backoff=lambda n: timedelta(minutes=2 ** n),  # default: 2^n minutes
    batch_size=50,
)

count = await worker.run_once()      # one pass; returns rows processed
await worker.start(interval_seconds=30)   # background loop
```

SDK provides the protocol + the algorithm. Host owns the table, the ORM, and the migration.

### `buttdial.router` — admin router

Operational endpoints for host apps to expose (overview, usage dashboard, manual retry/dismiss, agent activation). Host plugs in an `AgentDirectory` adapter so the SDK stays ignorant of host-specific agent models.

```python
from buttdial.router import make_router, AgentDirectory

class MyAgentDirectory(AgentDirectory):
    async def list_agents(self) -> list[AgentInfo]: ...
    async def activate(self, agent_id: str) -> AgentInfo: ...
    async def deactivate(self, agent_id: str) -> AgentInfo: ...

router = make_router(client=bd, repo=MyRepo(), directory=MyAgentDirectory())
app.include_router(router, prefix="/api/butt-dial")
```

Endpoints mounted:
- `GET /overview` — connection_status, tool_count, agents_provisioned, totals, failed_queue_size, last_ping
- `GET /agents` — per-agent list with status, token presence, counts, channels
- `GET /usage` — usage dashboard (agents list + totals)
- `GET /failed-messages` — failed queue contents
- `POST /agents/{id}/activate` / `POST /agents/{id}/deactivate`
- `POST /failed-messages/{id}/retry` / `POST /failed-messages/{id}/dismiss`

### `buttdial.doctor` — diagnostic

```bash
$ buttdial doctor --to +972501234567
[✓] Config loaded (BUTT_DIAL_CLIENT_TOKEN, BUTT_DIAL_URL)
[✓] Server reachable                           (240ms)
[✓] SSE handshake OK
[✓] Tool list: 7 tools, found comms_send_message
[✓] send_message accepted → message_sid SM123
[✓] Delivery receipt received                  (4.2s)
[✗] Human ack loopback: timeout after 60s
    → Fix: inbound webhook not reaching your app. Check:
       - POST /api/buttdial/webhook/whatsapp is reachable from the internet
       - Butt-Dial server has your webhook URL registered
       - ngrok / tunnel is running in dev
```

Also:
```python
from buttdial.doctor import run_diagnostic
report = await run_diagnostic(client=bd, to="+1234...", expect_ack=True)
assert report.ok, report.summary()
```

Seven stages: config → reachability → SSE → tool list → send → delivery → human ack (optional).
Each stage emits a typed result with a remediation string on failure.

### `buttdial.testing` — fakes + fixtures

```python
from buttdial.testing import FakeButtDialServer, fake_server

async def test_my_integration(fake_server):      # pytest fixture
    # fake_server is a running fake MCP endpoint; program responses:
    fake_server.on_send(success={"messageId": "SM123"})
    fake_server.on_send(error="INVALID_RECIPIENT")
    fake_server.simulate_inbound(channel="whatsapp", text="hi")
    ...
```

## Architecture

```
butt-dial-sdk/
├── src/buttdial/
│   ├── __init__.py         re-exports Client, InboundHandler, SendResult, errors
│   ├── client.py           Client — MCP/SSE transport, send_message
│   ├── settings.py         env-var config loader
│   ├── models.py           Pydantic: SendResult, FailedMessage, InboundMessage,
│   │                                  DeliveryReceipt, StatusUpdate, DoctorReport
│   ├── retry.py            RetryWorker, FailedMessageRepository protocol
│   ├── inbound.py          InboundHandler, channel parsers, webhook verification
│   ├── router.py           make_router, AgentDirectory protocol
│   ├── doctor.py           staged diagnostic + remediation map
│   ├── testing/            FakeButtDialServer, pytest fixtures
│   └── errors.py           typed exceptions + remediation map
├── tests/
├── docs/
├── examples/
│   ├── minimal/            send one message
│   ├── with-retry/         add retry worker + SQLAlchemy repo
│   └── with-inbound/       full round-trip
├── pyproject.toml
├── README.md
├── LICENSE                 MIT
└── CHANGELOG.md
```

## Design principles

- **Zero coupling to host app** — no imports from iv-bknd, v95, or any host codebase.
- **Stateless** — SDK owns no DB, no files, no global state beyond a configured `Client`.
- **Protocols over base classes** — host implements `FailedMessageRepository`, `AgentDirectory` as protocols; SDK never instantiates or queries the DB.
- **Async-first** — `asyncio`, `httpx`, `mcp` client library.
- **Typed errors** — every failure has `.code`, `.stage`, `.remediation`.
- **Test-first** — every doctor stage is backed by a contract test.
- **Easy integration** — two env vars + three lines of code to send; add repo impl for retry; add handler decorators for inbound.

## Dependencies

- Python 3.11+
- `mcp` (MCP client library)
- `httpx`
- `pydantic` v2
- `click` (CLI)

Optional extras:
- `butt-dial-sdk[router]` → `fastapi`
- `butt-dial-sdk[all]` → all of the above

No `sqlalchemy` in any extra — the SDK never touches a DB directly.

## What iv-bknd keeps (out of SDK scope)

- **Database** — `failed_messages` table, schema, migrations stay in iv-bknd. iv-bknd implements `FailedMessageRepository` against its own DB.
- **Agent identity** — `agent_leaders.butt_dial_client_id` / `butt_dial_client_token` columns stay on iv-bknd's tables.
- **Agent directory implementation** — iv-bknd implements `AgentDirectory` for its agent model.
- **Frontend pages** — stay in v95/iv-frnt, consume SDK via iv-bknd's API.
- **Business logic** — activation rules, per-agent usage rollups, iv-bknd's event log (`observability.event_log`), number validation, consent checks, language detection.
- **Optional pre-send checks** — `validate_number()`, `check_consent()`, `detect_language()` remain iv-bknd helpers. iv-bknd calls them before `Client.send_message()`; SDK does not embed these.

## Out of scope

- The Butt-Dial *server* (this is the client SDK only).
- Agent identity storage.
- Any ORM or persistence layer.
- UI / frontend components.
- Non-Python client libraries (for now).

## Success criteria

- A third-party developer goes from zero to sending a message in < 10 minutes following the quickstart.
- iv-bknd deletes its in-repo Butt-Dial engine/routes/webhook handler and depends on `butt-dial-sdk`, with no behavior regression and equal/better test coverage. v95 inherits the improvement transitively.
- `buttdial doctor` correctly identifies and explains the top 10 failure modes seen during iv-bknd/v95 production operation.
- Inbound round-trip test (human sends WA message → SDK parses → host handler fires) passes in the example app.
