<!-- version: 1.0 | updated: 2026-04-22 -->

# Reasoning

Breadcrumb trails for non-trivial debugging. Short entries — the logic chain, not the full fix (that's in ERRORS.md).

---

## FastAPI 422 on lazy-imported `Request` annotation
**Symptom:** All POST router tests failed with `422 Unprocessable Entity`, response body `{"detail":[{"type":"missing","loc":["query","request"],...}]}`. GET verify tests passed.
**Trace:**
1. 422 with `loc: ["query", "request"]` → FastAPI tried to treat `request` as a **query parameter**, not a `Request` object.
2. For that to happen, FastAPI's dependency resolver must fail to recognize `request: Request` as the starlette/fastapi Request type.
3. GET routes didn't hit the bug because they don't use `Request`.
4. `fastapi` imports were inside `_build_router()` (local scope), while the decorated inner function `receive(channel, request: Request)` lives in that same scope — **but FastAPI resolves annotations via `typing.get_type_hints()`, which only looks at `__globals__`**, not the enclosing function's locals.
5. `from __future__ import annotations` made it worse — all annotations become strings, resolved lazily against globals alone.
**Key insight:** Lazy imports of types used as function annotations don't work if the annotation resolver uses `get_type_hints(fn)` — that function uses the wrapped function's `__globals__`, not the closure.
**Pattern:** Any lib that introspects type annotations (FastAPI, Pydantic, dataclasses with `get_type_hints`) will fail on annotations that aren't reachable from module globals. Either import at module top (with try/except fallback if optional) or use string annotations + explicit `localns` — the former is simpler.
