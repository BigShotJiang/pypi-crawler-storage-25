<!-- version: 1.0 | updated: 2026-04-22 -->

# Errors

Pattern library. Check here **before** debugging a symptom from scratch.

---

### FastAPI 422 with `loc: ["query", "<param_name>"]` on a typed FastAPI object
**Pattern:** Route returns `422 Unprocessable Entity` with `{"detail":[{"type":"missing","loc":["query","<param>"],"msg":"Field required"}]}` when `<param>` is annotated as `Request`, `WebSocket`, `BackgroundTasks`, or similar.
**Cause:** FastAPI resolves annotations with `typing.get_type_hints()`, which uses the function's `__globals__`. If the annotated type is imported inside a closure (lazy import inside a factory function), it is not in globals and FastAPI falls back to treating the parameter as a query field.
**Fix:** Move the import to module top-level. Guard with `try/except ImportError` + `_FEATURE_AVAILABLE` flag if the dep is optional; fail fast at the factory if the flag is False.
