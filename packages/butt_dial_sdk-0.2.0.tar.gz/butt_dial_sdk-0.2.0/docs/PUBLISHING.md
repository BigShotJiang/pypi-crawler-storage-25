<!-- version: 1.0 | updated: 2026-04-23 -->

# Publishing to PyPI

Checklist to ship a new release. Requires maintainer decisions that the SDK itself can't make.

## One-time setup (pending decisions)

Three decisions Inon needs to make before the first release:

1. **GitHub repo location**
   - Option A — personal account (`inon95` or `inonax`): fastest, no org politics.
   - Option B — `95percent-ai` org: signals corporate stewardship, better for commercial adoption.
   - **Recommendation:** `95percent-ai` org for the OSS story the SDK was built for.

2. **PyPI account owner**
   - PyPI name `butt-dial-sdk` is currently unclaimed (check at https://pypi.org/project/butt-dial-sdk/).
   - Publish under `95percent-ai` org if created on PyPI, or under personal account.

3. **Maintainer contact**
   - `pyproject.toml` currently lists `95percent.ai <inon@95percent.ai>`.
   - Update to whatever address should receive vulnerability reports.

## Release process

Once decisions above are made, for each release:

1. **Update the version**
   ```toml
   # pyproject.toml
   version = "0.1.1"
   ```
   Also update `src/buttdial/__init__.py::__version__` to match.

2. **Update `CHANGELOG.md`** — move Unreleased content under a new `## [0.1.1] — 2026-MM-DD` heading.

3. **Run the full gate**
   ```bash
   pytest --cov            # must be green, coverage ≥85%
   ruff check src tests
   black --check src tests
   buttdial doctor --help  # CLI entry point still resolves
   ```

4. **Build**
   ```bash
   pip install --upgrade build
   python -m build            # creates dist/*.whl and dist/*.tar.gz
   ```

5. **Upload to TestPyPI first**
   ```bash
   pip install --upgrade twine
   python -m twine upload --repository testpypi dist/*
   ```

6. **Install from TestPyPI in a clean venv, run `buttdial doctor --help`** to verify.

7. **Upload to real PyPI**
   ```bash
   python -m twine upload dist/*
   ```

8. **Tag the release**
   ```bash
   git tag -a v0.1.1 -m "release v0.1.1"
   git push origin v0.1.1
   ```

9. **Cut a GitHub release** from the tag, paste the CHANGELOG section.

## Automating this

A GitHub Actions workflow at `.github/workflows/publish.yml` could run steps 4-7 on tag push. Left as an intentional follow-up — first release should be manual to catch surprises.
