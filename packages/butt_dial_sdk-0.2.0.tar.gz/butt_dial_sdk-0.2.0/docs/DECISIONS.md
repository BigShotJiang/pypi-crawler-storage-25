<!-- version: 1.2 | updated: 2026-04-22 -->

# Decisions

## 2026-04-21 — Separate repo, not in-repo package
**What:** butt-dial-sdk is a standalone git repository at `C:\Users\inon\Documents\work\butt-dial-sdk\`, developed alongside iv-bknd via editable install.
**Why:** Open-source story requires clean boundaries — own versioning, README, issues, release cadence. iv-bknd becomes the *reference consumer*, not the host. Third parties install from PyPI without ever seeing iv-bknd.
**Alternatives:** In-repo `packages/buttdial/` (muddies OSS story); hybrid in-repo-then-split (postpones the hard boundary work).

## 2026-04-21 — MIT license
**What:** MIT.
**Why:** Most permissive, standard OSS default, no friction for commercial adoption.

## 2026-04-21 — Package name `butt-dial-sdk`
**What:** PyPI name `butt-dial-sdk`, Python import `buttdial`, CLI entry point `buttdial`.
**Why:** PyPI prefers lowercase + hyphens; Python imports can't have hyphens. `-sdk` suffix signals this is the client library, distinct from any future server package.

## 2026-04-21 — Scope boundary: agent identity stays in iv-bknd
**What:** iv-bknd's `agent_leaders.butt_dial_client_id` / `butt_dial_client_token` columns stay in iv-bknd. The SDK consumes a token at runtime; it does not own agent identity storage.
**Why:** Agent identity is a host-app concern. Embedding it would force every consumer to adopt iv-bknd's data model. SDK stays focused on protocol + resilience + diagnostic layers.

## 2026-04-21 — SDK is stateless; host owns the database (reversed from v1.0)
**What:** The SDK does not ship migrations, does not open DB connections, does not import any ORM. It defines two protocols — `FailedMessageRepository` and `AgentDirectory` — and the host implements them against its own DB.
**Why:** Developer framed the SDK as a "client-side tunnel." A tunnel has no state. This also prevents every consumer from inheriting iv-bknd's schema choices. Hosts on any stack (SQLAlchemy, Tortoise, Django ORM, raw asyncpg) can integrate.
**Alternatives:** Ship `buttdial.migrations` with `[retry]` extra (v1.0 decision) — rejected for coupling.

## 2026-04-21 — Callbacks are a first-class SDK surface
**What:** SDK includes `InboundHandler` — decorator-based registration for inbound messages, delivery receipts, and status updates. Ships channel-specific payload parsers (WhatsApp first) and a FastAPI router for `POST /{channel}` + `GET /{channel}/verify`.
**Why:** Developer explicitly included callbacks in scope ("yes also callback"). iv-bknd already has inbound webhook handling at `POST /api/webhook/{channel}` — that logic is part of the "knowledge wrapped in the SDK." A tunnel without a return path isn't a tunnel.

## 2026-04-21 — Retry backoff: `2^n` minutes, pluggable
**What:** Default backoff is `timedelta(minutes=2 ** retry_count)`, matching iv-bknd's current algorithm. `RetryWorker` accepts a `backoff: Callable[[int], timedelta]` override.
**Why:** Preserve iv-bknd behavior by default (no semantic regression during extraction). Pluggable because different hosts will want different policies.

## 2026-04-22 — Extraction source is iv-bknd, not v95
**What:** The real `engine/comms.py`, `config/settings.py`, and `storage/schema.py` all live in `C:\Users\inon\Documents\work\iv\iv-bknd\` (shared backend). v95 has no `engine/` directory at all — it's a downstream consumer of iv-bknd. SDK extraction pulls from iv-bknd; Phase 10 integration targets iv-bknd as the first consumer. v95 benefits transitively.
**Why:** Initial session assumption was that v95 was the host. Discovered during Phase 2 code review that the tests I'd been reading in v95 actually reference iv-bknd modules (v95 imports from iv-bknd). Fixing the extraction target now — before any code is ported — prevents us from building against a downstream consumer instead of the real owner.

## 2026-04-21 — Diagnostic (`buttdial doctor`) is a staged, remediation-mapped end-to-end test
**What:** Seven-stage diagnostic: config → reachability → SSE → tool list → send → delivery → optional human ack. Each stage emits a typed result with a remediation string on failure. Runnable as CLI, Python function, and pytest fixture.
**Why:** Developer's core ask for the testing surface — "pinpoint where the error is with information how to resolve." First-class product feature, not an afterthought. Stage 7 (human ack loopback) directly tests the callback path end-to-end.
