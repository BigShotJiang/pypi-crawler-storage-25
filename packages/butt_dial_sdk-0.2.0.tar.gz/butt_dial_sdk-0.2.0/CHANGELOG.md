# Changelog

All notable changes to this project are documented here. Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] — 2026-04-24

### Added
- `buttdial.accounts` — onboarding + token-rotation REST wrapper. `AccountsClient(base_url, owner_token=...)` exposes `register(org_name, owner_email)`, `verify(token)`, `set_phone(phone)`, `confirm_phone(challenge_id, otp)`, `rotate_token_request()`, `rotate_token_confirm(challenge_id, otp)`, `rotate_token(otp_prompt)` convenience helper, and `get_account()`. Covers the "first bearer token" lifecycle — after onboarding, existing provisioning flows (channels, callbacks) continue through `Client`. Works with plain `httpx.AsyncClient` (no MCP/SSE needed), and accepts a `transport=` kwarg so hosts and tests can inject `httpx.MockTransport` without extra deps.
- Typed exception hierarchy mirroring the server's machine-readable codes: `AccountsError` base + `EmailAlreadyRegistered`, `VerificationTokenExpired`, `PhoneNotConfigured`, `OTPInvalid`, `OTPExpired`, `OTPMaxAttempts`, `ChallengeNotFound`, `TokenRevoked`. All re-exported from the top-level `buttdial` package so `from buttdial import OTPInvalid` works.
- 20 tests under `tests/test_accounts.py` using `httpx.MockTransport` — full onboarding cycle, both sync and async OTP prompts, every typed error code, unknown-code fallthrough, revoked-token self-heal on `get_account`, transport-error mapping.
- 20-line "Connect butt-dial" snippet in the README showing a full `register → verify → set_phone → rotate_token` cycle.

### Changed
- Version bumped to 0.2.0 (additive — no breaking changes to existing `Client`, `InboundHandler`, `RetryWorker`, or admin router APIs).

## [0.1.1] and earlier

### Added
- Initial repo scaffold: `pyproject.toml`, `LICENSE` (MIT), `README.md`, `.gitignore`, source skeleton under `src/buttdial/`, tests skeleton, docs (`SPEC.md`, `TODO.md`, `DECISIONS.md`).
- Phase 2 — core outbound extracted from iv-bknd: `buttdial.Client` with `send_message()`, `buttdial.settings` (env-var loader), `buttdial.models` (Pydantic types: `SendResult`, `FailedMessage`, `InboundMessage`, `DeliveryReceipt`, `StatusUpdate`, `AgentInfo`, `DoctorStage`, `DoctorReport`).
- `pydantic-settings` added as a dependency.
- Phase 3 — inbound callbacks: `buttdial.InboundHandler` with decorator-based registration (`on_message`, `on_delivery_receipt`, `on_status_update`), channel filtering + wildcard, error-isolated dispatch. Ported iv-bknd's WhatsApp parser and added delivery-receipt parsing (WA statuses) that iv-bknd lacks. HMAC-SHA256 signature verification + Meta subscription challenge verification. Lazy FastAPI router mounted via `handler.router`.
- `docs/ERRORS.md` + `docs/REASONING.md` — first entries, capturing the FastAPI 422 lazy-import bug.
- Phase 4 — retry worker: `buttdial.RetryWorker` orchestrates retries against a host-provided `FailedMessageRepository` protocol (`runtime_checkable`). Preserves iv-bknd's three-state transition (delivered / dead / pending-with-backoff) and default `2^n` minute backoff. Adds pluggable `backoff` function, optional `on_dead_letter` host hook (error-isolated), poison-row isolation (one failing message doesn't stall the batch), and proper `start()`/`stop()` lifecycle.
- Phase 5 — admin router: `buttdial.make_router(client, repo, directory)` mounts 7 operational endpoints (overview, agents list, activate/deactivate, failed-message list/retry/dismiss). New `AgentDirectory` and `AdminFailedMessageRepository` protocols let hosts plug in their own models. Typed exceptions `AgentNotFound` / `AgentNotProvisioned` (inherit from builtins). `Client.list_tools()`, `Client.ping()`, `Client.fetch_usage_summary()` helpers added for overview composition. `/usage` endpoint dropped vs iv-bknd (host-specific reporting, out of SDK scope). Activate/deactivate uses a clean protocol instead of iv-bknd's buggy `update(id, dict)` call.
- Phase 6 — `buttdial doctor` diagnostic: seven-stage end-to-end health check (config, reachability, SSE handshake, tool list, send contract, delivery receipt, human-ack loopback) with typed `DoctorStage` per stage (ok/detail/remediation/duration_ms). `REMEDIATIONS` map covers 11 known failure modes (401/403, connection refused, timeouts, DNS, SSL, invalid recipient, missing token). `run_diagnostic()` orchestrates with fail-fast short-circuit; stages 5-7 skip gracefully when prerequisites are missing. `buttdial doctor --to <phone> [--expect-ack]` CLI prints ✓/✗ per stage with remediation on failure and exits non-zero on any failure.
- Phase 7 — testing utilities: `buttdial.testing.FakeButtDialServer` is a programmable in-process fake that monkeypatches `mcp.ClientSession` + `mcp.client.sse.sse_client`. Covers `send_message`, `list_tools`, and `ping` through one mechanism. `on_send(sid=..., error=..., raw_text=..., count=N)` programs responses; `sent_messages` captures every call. `simulate_inbound()` / `simulate_receipt()` fire events into a host's `InboundHandler`. `fake_server` pytest fixture exports directly. Enables first end-to-end doctor integration tests (stages 1-6 against the fake with a scheduled simulated receipt).
- Phase 8 — typed errors: `buttdial.errors.ButtDialError` base with optional `code`/`stage`/`remediation` attributes; `ConfigError` + `TransportError` subclasses. `AgentNotFound` / `AgentNotProvisioned` now inherit from both `ButtDialError` and their builtin (`KeyError`/`ValueError`) — `except ButtDialError:` catches any SDK-raised error while existing Python idioms still work.
- Phase 9 — test coverage: added `pytest-cov` with coverage config. Current coverage **86%** overall; all items from the Phase 9 TODO were already delivered in Phases 2-8 (117 tests across 9 test files).
- Phase 10 — iv-bknd integration (first pass): `engine/comms.py send_message()` in iv-bknd now delegates MCP transport to `buttdial.Client` while preserving its original signature and return-dict shape exactly. All 28 existing callers (auth, routes, autonomy, scheduler, inbound_poller, etc.) work unchanged. Full iv-bknd test suite passes (187/187). Retry worker, admin router, and webhook handler intentionally left intact for a lower-risk follow-up swap.
- Phase 11 — OSS polish: README rewrite (10-minute quickstart, component table, design principles, full API walkthrough), three working examples (`minimal/send_one.py`, `with-retry/sqlalchemy_repo.py` reference implementation, `with-inbound/app.py` full round-trip FastAPI app), `CONTRIBUTING.md`, GitHub Actions CI (lint + format + mypy + pytest + coverage on Python 3.11/3.12/3.13), `docs/PUBLISHING.md` release checklist. Remaining work is external (GitHub repo creation, PyPI publish) — blocked on a repo-location decision.

### Changed
- Extraction source clarified: docs updated to reflect that iv-bknd (not v95) is the real source of `engine/comms.py` and the primary integration target. v95 is a downstream consumer of iv-bknd.
