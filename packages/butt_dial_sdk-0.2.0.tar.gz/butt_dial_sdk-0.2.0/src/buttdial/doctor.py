"""`buttdial doctor` — staged end-to-end diagnostic with remediation.

The testing surface the developer asked for from day one:

> test enables to check communication via butt-dial server onward to human.
> this is real test for validating no production errors or pinpoint where
> the error is with information how to resolve.

Seven stages. Each produces a `DoctorStage` with `ok`, `detail`, `remediation`,
and optional `duration_ms`. On any stage failure, remaining stages short-
circuit to `skipped` — there's no value in probing further once the chain is
broken.

Runnable three ways:

- **CLI** (`buttdial doctor --to +1... [--expect-ack]`). Stages 6-7 skip in
  CLI mode because there's no live webhook server to receive callbacks.
- **Python API** — `await run_diagnostic(client=..., to=..., inbound_handler=...)`.
  Pass a live `InboundHandler` to exercise stages 6-7.
- **Pytest fixture** — same as Python API, with `FakeButtDialServer` in
  Phase 7 providing a programmable backend.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import click

from buttdial.client import Client
from buttdial.inbound import InboundHandler
from buttdial.models import DeliveryReceipt, DoctorReport, DoctorStage, InboundMessage, SendResult

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Remediation map — substring match against the error message, most specific
# first. Returns a one-line actionable fix.
# ---------------------------------------------------------------------------

REMEDIATIONS: list[tuple[str, str]] = [
    (
        "401",
        "Token is invalid, revoked, or wrong scope. Set BUTT_DIAL_TOKEN to a fresh org token.",
    ),
    (
        "unauthorized",
        "Token is invalid or revoked. Regenerate via the Butt-Dial admin console.",
    ),
    (
        "429",
        "Rate limited by Butt-Dial. Wait 60-180 seconds and retry. "
        "If persistent, check your account's rate-limit quota.",
    ),
    (
        "too many requests",
        "Rate limited. Wait a minute and retry.",
    ),
    (
        "agentid is required",
        "This tool needs agent context. Pass `--agent-id <token>` to the CLI, "
        "or send with `agent_token=<per-agent token>` from code.",
    ),
    (
        "403",
        "Token lacks permission for this operation. Check token scopes or contact your Butt-Dial admin.",
    ),
    (
        "connection refused",
        "Server is not accepting connections. Verify BUTT_DIAL_URL and that the server is running.",
    ),
    (
        "timed out",
        "Server took too long to respond. Check network path and any proxy/firewall on BUTT_DIAL_URL.",
    ),
    (
        "timeout",
        "Server took too long to respond. Check network path and any proxy/firewall on BUTT_DIAL_URL.",
    ),
    (
        "name or service not known",
        "DNS lookup failed. Check BUTT_DIAL_URL for typos.",
    ),
    (
        "ssl",
        "TLS/SSL handshake failed. If using a self-signed cert, adjust your trust store — do not disable verification.",
    ),
    (
        "certificate",
        "TLS certificate problem. Verify the server's cert chain is valid and trusted on this machine.",
    ),
    (
        "invalid_recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "invalid recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "no butt-dial token",
        "Set BUTT_DIAL_TOKEN (preferred) or BUTT_DIAL_CLIENT_TOKEN in the environment.",
    ),
]


def find_remediation(error: str | None) -> str | None:
    """Return the first remediation whose trigger substring appears in `error`."""
    if not error:
        return None
    lower = error.lower()
    for trigger, advice in REMEDIATIONS:
        if trigger in lower:
            return advice
    return None


def _unwrap_exception(exc: BaseException) -> str:
    """Extract the most specific error message from (possibly nested) ExceptionGroup.

    Python 3.11+ `asyncio.TaskGroup` wraps all inner failures in an
    `ExceptionGroup`, and the `mcp` client library uses TaskGroups
    internally — so the top-level exception text is a useless wrapper
    like "unhandled errors in a TaskGroup (1 sub-exception)". This
    helper walks into `.exceptions` recursively and returns the
    deepest/most-specific message. Falls back to `str(exc)` when no
    sub-exceptions are present.
    """
    if hasattr(exc, "exceptions") and exc.exceptions:  # type: ignore[attr-defined]
        # Dig into the first sub-exception; recurse in case it's also an
        # ExceptionGroup (which happens with nested TaskGroups).
        return _unwrap_exception(exc.exceptions[0])  # type: ignore[index,union-attr]
    return f"{type(exc).__name__}: {exc}" if not isinstance(exc, Exception) else str(exc)


# ---------------------------------------------------------------------------
# Individual stages — each returns a DoctorStage. Free functions so tests can
# call them directly.
# ---------------------------------------------------------------------------


async def stage_config(client: Client) -> DoctorStage:
    """Stage 1 — is the client configured with a URL and a token?"""
    if not client.url:
        return DoctorStage(
            name="Config loaded",
            ok=False,
            detail="BUTT_DIAL_URL is empty",
            remediation="Set BUTT_DIAL_URL to your Butt-Dial server SSE endpoint.",
        )
    token = client._resolve_token(None)
    if not token:
        return DoctorStage(
            name="Config loaded",
            ok=False,
            detail="no Butt-Dial token configured",
            remediation=find_remediation("no butt-dial token"),
        )
    return DoctorStage(name="Config loaded", ok=True, detail=f"url={client.url}")


async def stage_reachability(client: Client, *, timeout: float = 10.0) -> DoctorStage:
    """Stage 2 — can we open a TCP/TLS connection to the server?"""
    import httpx

    base_url = client.url.rsplit("/sse", 1)[0] if client.url.endswith("/sse") else client.url
    start = time.monotonic()
    try:
        async with httpx.AsyncClient(timeout=timeout) as http:
            resp = await http.get(base_url)
    except BaseException as exc:
        err = _unwrap_exception(exc)
        return DoctorStage(
            name="Server reachable",
            ok=False,
            detail=err,
            remediation=find_remediation(err),
        )
    duration_ms = int((time.monotonic() - start) * 1000)
    # Any HTTP response (even 404) means the server is reachable. 5xx means
    # reachable-but-sick; still counts as reachable.
    return DoctorStage(
        name="Server reachable",
        ok=True,
        detail=f"HTTP {resp.status_code}",
        duration_ms=duration_ms,
    )


async def _probe_session(
    client: Client,
) -> tuple[DoctorStage, DoctorStage]:
    """Stages 3 + 4 in one SSE session (avoids opening twice)."""
    from mcp import ClientSession
    from mcp.client.sse import sse_client

    token = client._resolve_token(None)
    headers = {"Authorization": f"Bearer {token}"} if token else {}

    start = time.monotonic()
    try:
        async with sse_client(
            client.url, headers=headers, timeout=client.sse_timeout
        ) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                handshake_ms = int((time.monotonic() - start) * 1000)
                result = await session.list_tools()
                tools = [t.name for t in result.tools]
    except BaseException as exc:
        # Unwrap ExceptionGroup/TaskGroup so the user sees the real error
        # (e.g. "401 Unauthorized") instead of "unhandled errors in a
        # TaskGroup (1 sub-exception)". Filed in v0.1.1 after iv-bknd
        # hit this in production (docs/ERRORS.md).
        err = _unwrap_exception(exc)
        handshake = DoctorStage(
            name="SSE handshake",
            ok=False,
            detail=err,
            remediation=find_remediation(err),
        )
        tool_list = DoctorStage(
            name="Tool list",
            ok=False,
            detail="skipped (handshake failed)",
        )
        return handshake, tool_list

    handshake = DoctorStage(
        name="SSE handshake", ok=True, duration_ms=handshake_ms
    )

    if client.send_tool in tools:
        tool_list = DoctorStage(
            name="Tool list",
            ok=True,
            detail=f"{len(tools)} tool(s), includes {client.send_tool}",
        )
    else:
        tool_list = DoctorStage(
            name="Tool list",
            ok=False,
            detail=f"{client.send_tool!r} not found; got {tools}",
            remediation=(
                f"Butt-Dial server does not expose {client.send_tool!r}. Verify server "
                "version or pass send_tool=... to Client()."
            ),
        )
    return handshake, tool_list


async def stage_send(
    client: Client, *, to: str, body: str = "[buttdial doctor] smoke test — ignore"
) -> tuple[DoctorStage, SendResult]:
    """Stage 5 — real send to `to`. Returns (stage, result)."""
    start = time.monotonic()
    result = await client.send_message(to=to, body=body)
    duration_ms = int((time.monotonic() - start) * 1000)

    if result.message_sid:
        return (
            DoctorStage(
                name="send_message accepted",
                ok=True,
                detail=f"sid={result.message_sid}",
                duration_ms=duration_ms,
            ),
            result,
        )
    err = result.error or "no message_sid returned"
    return (
        DoctorStage(
            name="send_message accepted",
            ok=False,
            detail=err,
            remediation=result.remediation or find_remediation(err),
            duration_ms=duration_ms,
        ),
        result,
    )


async def stage_receipt(
    inbound: InboundHandler, *, expected_sid: str, timeout: float = 30.0
) -> DoctorStage:
    """Stage 6 — wait for a DeliveryReceipt with the expected message_sid."""
    queue: asyncio.Queue[DeliveryReceipt] = asyncio.Queue()

    async def capture(r: DeliveryReceipt) -> None:
        if r.message_sid == expected_sid:
            await queue.put(r)

    inbound._receipt_handlers.append(capture)
    start = time.monotonic()
    try:
        receipt = await asyncio.wait_for(queue.get(), timeout=timeout)
    except asyncio.TimeoutError:
        return DoctorStage(
            name="Delivery receipt",
            ok=False,
            detail=f"no receipt for {expected_sid} within {timeout:.0f}s",
            remediation=(
                "Inbound webhook did not deliver a receipt for the test send. "
                "Verify POST /{channel} is reachable from Butt-Dial and that the "
                "server is configured to POST delivery receipts to this app."
            ),
            duration_ms=int((time.monotonic() - start) * 1000),
        )
    finally:
        try:
            inbound._receipt_handlers.remove(capture)
        except ValueError:
            pass
    return DoctorStage(
        name="Delivery receipt",
        ok=True,
        detail=f"status={receipt.status}",
        duration_ms=int((time.monotonic() - start) * 1000),
    )


async def stage_ack(
    inbound: InboundHandler, *, from_sender: str, timeout: float = 60.0
) -> DoctorStage:
    """Stage 7 — optional human-ack loopback.

    Waits for an `InboundMessage` from `from_sender` (the test recipient).
    This tests the full loop: server → user → reply → webhook → host.
    """
    queue: asyncio.Queue[InboundMessage] = asyncio.Queue()

    async def capture(msg: InboundMessage) -> None:
        if msg.sender == from_sender:
            await queue.put(msg)

    inbound._message_handlers.setdefault("*", []).append(capture)
    start = time.monotonic()
    try:
        msg = await asyncio.wait_for(queue.get(), timeout=timeout)
    except asyncio.TimeoutError:
        return DoctorStage(
            name="Human ack loopback",
            ok=False,
            detail=f"no reply from {from_sender} within {timeout:.0f}s",
            remediation=(
                "No inbound message received from the test recipient. Reply to the "
                "smoke-test message from that number within the timeout, and verify "
                "the host's webhook URL is registered with the Butt-Dial server."
            ),
            duration_ms=int((time.monotonic() - start) * 1000),
        )
    finally:
        try:
            inbound._message_handlers["*"].remove(capture)
        except ValueError:
            pass
    return DoctorStage(
        name="Human ack loopback",
        ok=True,
        detail=f"received: {msg.text[:40]!r}",
        duration_ms=int((time.monotonic() - start) * 1000),
    )


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


def _skipped(name: str, reason: str) -> DoctorStage:
    return DoctorStage(name=name, ok=False, detail=f"skipped: {reason}")


async def run_diagnostic(
    client: Client,
    *,
    to: str | None = None,
    inbound_handler: InboundHandler | None = None,
    expect_ack: bool = False,
    receipt_timeout: float = 30.0,
    ack_timeout: float = 60.0,
) -> DoctorReport:
    """Run the full staged diagnostic and return a `DoctorReport`.

    Fail-fast between stages 1-4: if any of config / reachability / SSE /
    tool list fails, later stages are marked skipped. Stages 5-7 also skip
    when prerequisites are missing (no `to`, no `inbound_handler`, etc.).
    """
    stages: list[DoctorStage] = []

    s1 = await stage_config(client)
    stages.append(s1)
    if not s1.ok:
        for name in (
            "Server reachable",
            "SSE handshake",
            "Tool list",
            "send_message accepted",
            "Delivery receipt",
            "Human ack loopback",
        ):
            stages.append(_skipped(name, "config stage failed"))
        return DoctorReport(ok=False, stages=stages)

    s2 = await stage_reachability(client)
    stages.append(s2)
    if not s2.ok:
        for name in (
            "SSE handshake",
            "Tool list",
            "send_message accepted",
            "Delivery receipt",
            "Human ack loopback",
        ):
            stages.append(_skipped(name, "server unreachable"))
        return DoctorReport(ok=False, stages=stages)

    s3, s4 = await _probe_session(client)
    stages.append(s3)
    stages.append(s4)
    if not s3.ok or not s4.ok:
        for name in (
            "send_message accepted",
            "Delivery receipt",
            "Human ack loopback",
        ):
            stages.append(_skipped(name, "session / tool list failed"))
        return DoctorReport(ok=False, stages=stages)

    if not to:
        for name in (
            "send_message accepted",
            "Delivery receipt",
            "Human ack loopback",
        ):
            stages.append(_skipped(name, "no --to recipient provided"))
        return DoctorReport(ok=all(s.ok for s in stages[:-3]), stages=stages)

    s5, send_result = await stage_send(client, to=to)
    stages.append(s5)
    if not s5.ok:
        for name in ("Delivery receipt", "Human ack loopback"):
            stages.append(_skipped(name, "send failed"))
        return DoctorReport(ok=False, stages=stages)

    if inbound_handler is None:
        for name in ("Delivery receipt", "Human ack loopback"):
            stages.append(
                _skipped(name, "no inbound_handler (run in integrated mode to enable)")
            )
        return DoctorReport(ok=all(s.ok for s in stages[:-2]), stages=stages)

    assert send_result.message_sid is not None  # narrowed by s5.ok check
    s6 = await stage_receipt(
        inbound_handler, expected_sid=send_result.message_sid, timeout=receipt_timeout
    )
    stages.append(s6)

    if not expect_ack:
        stages.append(_skipped("Human ack loopback", "disabled (--expect-ack not set)"))
        return DoctorReport(ok=s6.ok, stages=stages)

    s7 = await stage_ack(inbound_handler, from_sender=to, timeout=ack_timeout)
    stages.append(s7)
    return DoctorReport(ok=s6.ok and s7.ok, stages=stages)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _format_stage(stage: DoctorStage, *, ascii_only: bool = False) -> str:
    """Format a stage line. Uses Unicode check marks unless `ascii_only`."""
    if ascii_only:
        mark = "OK" if stage.ok else "FAIL"
        line = f"[{mark}] {stage.name}"
    else:
        mark = "✓" if stage.ok else "✗"
        line = f"[{mark}] {stage.name}"
    if stage.duration_ms is not None:
        line += f" ({stage.duration_ms}ms)"
    if stage.detail:
        line += f" — {stage.detail}" if not ascii_only else f" -- {stage.detail}"
    return line


def _stdout_supports_unicode() -> bool:
    """True if stdout's encoding can emit `✓` / `✗` without raising."""
    import sys

    encoding = getattr(sys.stdout, "encoding", "") or ""
    try:
        "✓".encode(encoding)
        "✗".encode(encoding)
        return True
    except (UnicodeEncodeError, LookupError):
        return False


@click.group()
@click.version_option(package_name="butt-dial-sdk")
def cli() -> None:
    """Butt-Dial SDK — diagnostic and utility CLI."""


@cli.command("doctor")
@click.option(
    "--to",
    default=None,
    help="Recipient (E.164, e.g. +14155550123). Stages 5-7 skip if omitted.",
)
@click.option(
    "--expect-ack",
    is_flag=True,
    help="Wait for a human reply (stage 7). CLI mode cannot observe ack; use pytest fixture.",
)
@click.option(
    "--agent-id",
    "agent_token",
    default=None,
    help=(
        "Per-agent token to use for the send. Required by some Butt-Dial tools "
        "that won't accept an org token alone. If omitted, falls back to the "
        "org token from BUTT_DIAL_TOKEN."
    ),
)
@click.option(
    "--ascii",
    "ascii_only",
    is_flag=True,
    help="Use ASCII [OK]/[FAIL] instead of Unicode check marks. Auto-enabled on terminals that can't encode Unicode.",
)
def doctor_cmd(
    to: str | None,
    expect_ack: bool,
    agent_token: str | None,
    ascii_only: bool,
) -> None:
    """Run the staged Butt-Dial end-to-end diagnostic."""
    import asyncio as _asyncio

    # Auto-detect Unicode capability; user can force ASCII with --ascii.
    use_ascii = ascii_only or not _stdout_supports_unicode()
    arrow = "->" if use_ascii else "→"

    async def _run() -> DoctorReport:
        client = Client.from_env()
        # If --agent-id was supplied, replace the client's default token so
        # list_tools / ping / send_message all use it.
        if agent_token:
            client.token = agent_token
        return await run_diagnostic(client, to=to, expect_ack=expect_ack)

    try:
        report = _asyncio.run(_run())
    except Exception as exc:
        click.echo(f"doctor crashed: {exc}", err=True)
        raise SystemExit(2) from exc

    for stage in report.stages:
        click.echo(_format_stage(stage, ascii_only=use_ascii))
        if not stage.ok and stage.remediation:
            click.echo(f"    {arrow} {stage.remediation}")

    if report.ok:
        click.echo("\nAll stages passed.")
        raise SystemExit(0)
    click.echo("\nOne or more stages failed - see above.", err=True)
    raise SystemExit(1)


if __name__ == "__main__":
    cli()


# Backwards-compat alias for anything that imported `doctor` before the rename.
doctor = doctor_cmd
