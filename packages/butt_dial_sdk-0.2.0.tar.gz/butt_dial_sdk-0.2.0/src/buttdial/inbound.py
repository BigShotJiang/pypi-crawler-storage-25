"""Inbound callbacks — webhook parsing + dispatch.

Normalizes channel-specific webhook payloads (WhatsApp envelopes, Butt-Dial
generic format) into typed `InboundMessage`, `DeliveryReceipt`, and
`StatusUpdate` events, then dispatches to host-registered handlers.

Ported from iv-bknd/api/routes/webhook.py. Two behavioral upgrades over
iv-bknd:

- WhatsApp **statuses** envelope (delivery receipts) is parsed into
  `DeliveryReceipt` events. iv-bknd silently ignores it today — this is a
  documented TODO there. Hosts can register `@handler.on_delivery_receipt()`
  to consume them.
- Handler errors are isolated: one handler raising does not prevent the
  others from running. iv-bknd's single-path handler crashes the whole
  webhook on any error.

`fastapi` is an optional dependency — imported lazily when `.router` is
accessed. Core parsing + dispatch works without it.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from typing import Any

from buttdial.models import Channel, DeliveryReceipt, InboundMessage, StatusUpdate

# `fastapi` is an optional dependency — required only when building the router.
# Imported at module top so type hints on the router's inner handlers resolve
# via `typing.get_type_hints()` (which uses function __globals__). Without this,
# `request: Request` inside `_build_router` is treated as a query parameter.
try:
    from fastapi import APIRouter, HTTPException, Query, Request  # noqa: F401

    _FASTAPI_AVAILABLE = True
except ImportError:  # pragma: no cover - import-time fallback
    APIRouter = None  # type: ignore[assignment,misc]
    HTTPException = None  # type: ignore[assignment,misc]
    Query = None  # type: ignore[assignment,misc]
    Request = None  # type: ignore[assignment,misc]
    _FASTAPI_AVAILABLE = False

logger = logging.getLogger(__name__)

MessageHandler = Callable[[InboundMessage], Awaitable[None]]
ReceiptHandler = Callable[[DeliveryReceipt], Awaitable[None]]
StatusHandler = Callable[[StatusUpdate], Awaitable[None]]

_WILDCARD = "*"


class InboundHandler:
    """Registry + dispatcher for inbound webhook events.

    Lifecycle: construct once, register handlers via decorators, mount
    `.router` on a FastAPI app, serve. One `InboundHandler` per host app.
    """

    def __init__(
        self,
        *,
        whatsapp_verify_token: str | None = None,
        whatsapp_webhook_secret: str | None = None,
    ) -> None:
        self.whatsapp_verify_token = whatsapp_verify_token or ""
        self.whatsapp_webhook_secret = whatsapp_webhook_secret or ""
        self._message_handlers: dict[str, list[MessageHandler]] = {}
        self._receipt_handlers: list[ReceiptHandler] = []
        self._status_handlers: list[StatusHandler] = []
        self._router: Any = None  # cached, built lazily

    # ----- decorator registration ---------------------------------------

    def on_message(
        self, channel: Channel | None = None
    ) -> Callable[[MessageHandler], MessageHandler]:
        """Register a handler for inbound messages.

        `channel=None` (default) receives messages on all channels.
        `channel="whatsapp"` receives only WhatsApp messages, etc.
        """

        key: str = channel if channel else _WILDCARD

        def decorator(fn: MessageHandler) -> MessageHandler:
            self._message_handlers.setdefault(key, []).append(fn)
            return fn

        return decorator

    def on_delivery_receipt(self) -> Callable[[ReceiptHandler], ReceiptHandler]:
        """Register a handler for delivery receipts (WhatsApp statuses, etc.)."""

        def decorator(fn: ReceiptHandler) -> ReceiptHandler:
            self._receipt_handlers.append(fn)
            return fn

        return decorator

    def on_status_update(self) -> Callable[[StatusHandler], StatusHandler]:
        """Register a handler for channel / connection status events."""

        def decorator(fn: StatusHandler) -> StatusHandler:
            self._status_handlers.append(fn)
            return fn

        return decorator

    # ----- dispatch (error-isolated) ------------------------------------

    async def _dispatch_message(self, msg: InboundMessage) -> None:
        handlers = [
            *self._message_handlers.get(msg.channel, []),
            *self._message_handlers.get(_WILDCARD, []),
        ]
        for fn in handlers:
            try:
                await fn(msg)
            except Exception:
                logger.exception("inbound message handler raised; continuing")

    async def _dispatch_receipt(self, receipt: DeliveryReceipt) -> None:
        for fn in self._receipt_handlers:
            try:
                await fn(receipt)
            except Exception:
                logger.exception("delivery receipt handler raised; continuing")

    async def _dispatch_status(self, status: StatusUpdate) -> None:
        for fn in self._status_handlers:
            try:
                await fn(status)
            except Exception:
                logger.exception("status update handler raised; continuing")

    # ----- verification -------------------------------------------------

    def verify_whatsapp_subscription(self, mode: str, token: str) -> bool:
        """True if Meta's subscription challenge is valid.

        Meta sends `GET /webhook?hub.mode=subscribe&hub.verify_token=...&hub.challenge=...`
        during webhook setup. The host echoes the challenge back on success.
        """
        if not self.whatsapp_verify_token:
            return False
        return mode == "subscribe" and token == self.whatsapp_verify_token

    def verify_whatsapp_signature(self, body: bytes, signature_header: str) -> bool:
        """Verify HMAC-SHA256 `X-Hub-Signature-256` header against the raw body.

        Returns True if the configured secret is empty (dev/test mode).
        Returns True on match. Returns False on mismatch.
        """
        if not self.whatsapp_webhook_secret:
            return True
        expected = "sha256=" + hmac.new(
            self.whatsapp_webhook_secret.encode(),
            body,
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(signature_header or "", expected)

    # ----- payload parsers ---------------------------------------------

    async def handle_whatsapp_payload(self, payload: dict[str, Any]) -> dict[str, int | str]:
        """Parse WhatsApp Cloud API webhook envelope and dispatch events.

        Handles both `messages` (inbound chats) and `statuses` (delivery
        receipts). Returns a summary suitable for returning from an HTTP
        handler — matches iv-bknd's return shape (`{status, messages}`)
        with `receipts` added.
        """
        messages_processed = 0
        receipts_processed = 0
        for entry in payload.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value") or {}
                for raw_msg in value.get("messages") or []:
                    msg = self._parse_whatsapp_message(raw_msg)
                    if msg is not None:
                        await self._dispatch_message(msg)
                        messages_processed += 1
                for raw_status in value.get("statuses") or []:
                    receipt = self._parse_whatsapp_status(raw_status)
                    if receipt is not None:
                        await self._dispatch_receipt(receipt)
                        receipts_processed += 1
        return {
            "status": "processed",
            "messages": messages_processed,
            "receipts": receipts_processed,
        }

    @staticmethod
    def _parse_whatsapp_message(msg: dict[str, Any]) -> InboundMessage | None:
        sender = msg.get("from", "")
        if not sender:
            return None
        msg_type = msg.get("type", "text")
        if msg_type == "text":
            text = (msg.get("text") or {}).get("body", "")
        elif msg_type == "interactive":
            text = json.dumps(msg.get("interactive") or {})
        else:
            text = f"[{msg_type} message]"
        if not text:
            return None
        ts_raw = msg.get("timestamp")
        received_at: datetime | None = None
        if ts_raw:
            try:
                received_at = datetime.fromtimestamp(int(ts_raw), tz=timezone.utc)
            except (ValueError, TypeError):
                received_at = None
        return InboundMessage(
            sender=sender,
            channel="whatsapp",
            text=text,
            received_at=received_at,
            raw=msg,
        )

    @staticmethod
    def _parse_whatsapp_status(st: dict[str, Any]) -> DeliveryReceipt | None:
        sid = st.get("id")
        status = st.get("status")
        if not sid or status not in ("sent", "delivered", "read", "failed"):
            return None
        ts_raw = st.get("timestamp")
        timestamp: datetime | None = None
        if ts_raw:
            try:
                timestamp = datetime.fromtimestamp(int(ts_raw), tz=timezone.utc)
            except (ValueError, TypeError):
                timestamp = None
        errors = st.get("errors") or []
        error_code: str | None = None
        if errors and isinstance(errors, list) and isinstance(errors[0], dict):
            code = errors[0].get("code")
            error_code = str(code) if code is not None else None
        return DeliveryReceipt(
            message_sid=sid,
            status=status,
            timestamp=timestamp,
            error_code=error_code,
            raw=st,
        )

    async def handle_generic_payload(self, payload: dict[str, Any]) -> dict[str, int | str]:
        """Parse Butt-Dial's generic inbound format (SMS / email / voice).

        Expected shape (normalized by the Butt-Dial server before reaching the
        host): ``{"from": str, "body": str, "channel": str, ...}``. Unknown
        fields are forwarded on `.raw`.
        """
        sender = payload.get("from") or payload.get("sender") or ""
        channel = payload.get("channel", "sms")
        text = payload.get("body") or payload.get("text") or ""
        if not sender or not text:
            return {"status": "ignored", "messages": 0}
        msg = InboundMessage(
            sender=sender,
            channel=channel,
            text=text,
            thread_id=payload.get("thread_id"),
            raw=payload,
        )
        await self._dispatch_message(msg)
        return {"status": "processed", "messages": 1}

    # ----- router (lazy fastapi import) --------------------------------

    @property
    def router(self) -> Any:
        """FastAPI router for mounting. Requires `butt-dial-sdk[router]`."""
        if self._router is None:
            self._router = self._build_router()
        return self._router

    def _build_router(self) -> Any:
        if not _FASTAPI_AVAILABLE:  # pragma: no cover - exercised at install time
            raise ImportError(
                "InboundHandler.router requires fastapi. "
                "Install with: pip install 'butt-dial-sdk[router]'"
            )

        router = APIRouter()

        @router.get("/{channel}/verify")
        async def verify(  # type: ignore[no-untyped-def]
            channel: str,
            hub_mode: str = Query("", alias="hub.mode"),
            hub_verify_token: str = Query("", alias="hub.verify_token"),
            hub_challenge: str = Query("", alias="hub.challenge"),
        ):
            if channel != "whatsapp":
                raise HTTPException(
                    status_code=400, detail=f"Verify not supported for channel {channel!r}"
                )
            if not self.verify_whatsapp_subscription(hub_mode, hub_verify_token):
                raise HTTPException(status_code=403, detail="Verification failed")
            # Meta expects the challenge echoed back; it's typically numeric.
            return int(hub_challenge) if hub_challenge.isdigit() else hub_challenge

        @router.post("/{channel}")
        async def receive(channel: str, request: Request):  # type: ignore[no-untyped-def]
            body = await request.body()
            if channel == "whatsapp":
                sig = request.headers.get("X-Hub-Signature-256", "")
                if not self.verify_whatsapp_signature(body, sig):
                    raise HTTPException(status_code=403, detail="Invalid signature")
                try:
                    payload = json.loads(body) if body else {}
                except json.JSONDecodeError as e:
                    raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}") from e
                return await self.handle_whatsapp_payload(payload)
            if channel == "butt-dial":
                try:
                    payload = json.loads(body) if body else {}
                except json.JSONDecodeError as e:
                    raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}") from e
                return await self.handle_generic_payload(payload)
            logger.warning("unhandled webhook channel: %s", channel)
            return {"status": "ignored", "channel": channel}

        return router
