"""Testing utilities — `FakeButtDialServer` + pytest fixtures.

Install into tests via:

    from buttdial.testing import FakeButtDialServer

Or use the pytest fixture directly (in `conftest.py` or a test file):

    from buttdial.testing import fake_server  # noqa: F401

    async def test_x(fake_server):
        fake_server.on_send(sid="SM-1")
        ...
"""

from __future__ import annotations

from collections.abc import Iterator

import pytest

from buttdial.testing.fake_server import FakeButtDialServer

__all__ = ["FakeButtDialServer", "fake_server"]


@pytest.fixture
def fake_server() -> Iterator[FakeButtDialServer]:
    """Pytest fixture — install `FakeButtDialServer` for the test, uninstall after."""
    with FakeButtDialServer() as fake:
        yield fake
