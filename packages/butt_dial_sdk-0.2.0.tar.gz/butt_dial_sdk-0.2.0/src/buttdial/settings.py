"""Env-var config loader.

Reads Butt-Dial connection parameters from the environment. Hosts can also
pass values directly to `Client(...)` — settings are a convenience, not
required. Uses `pydantic-settings` so hosts already using a `.env` file get
free compatibility.
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Butt-Dial SDK settings.

    Reads three env vars:

    - `BUTT_DIAL_URL`          — MCP/SSE endpoint of the Butt-Dial server.
    - `BUTT_DIAL_TOKEN`        — org-level token (preferred).
    - `BUTT_DIAL_CLIENT_TOKEN` — legacy per-team client token (fallback).

    Also reads from a `.env` file in the current working directory when present.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    url: str = Field(default="", validation_alias="BUTT_DIAL_URL")
    token: str = Field(default="", validation_alias="BUTT_DIAL_TOKEN")
    client_token: str = Field(default="", validation_alias="BUTT_DIAL_CLIENT_TOKEN")


def load() -> Settings:
    """Load settings from the environment / `.env`."""
    return Settings()
