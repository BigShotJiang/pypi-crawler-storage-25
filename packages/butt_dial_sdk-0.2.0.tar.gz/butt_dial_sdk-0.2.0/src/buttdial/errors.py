"""Typed exceptions for explicit failure handling.

Most SDK failures are *reported*, not raised — `SendResult.failed/error/
stage_failed/remediation` is the primary surface for outbound send failures
since callers want structured data, not a blown-up stack. This module
exists for the few cases where raising is the right choice:

- `ButtDialError` — base class for every exception the SDK raises
  intentionally. Catch this to handle any SDK-raised error in one block.
- `ConfigError` — misconfiguration the caller must fix (missing URL/token).
- `TransportError` — low-level connectivity failures the SDK couldn't wrap
  into a `SendResult`.
- `AgentNotFound` / `AgentNotProvisioned` — raised by `AgentDirectory`
  implementations; the admin router maps them to HTTP 404 / 400.

`AgentNotFound` and `AgentNotProvisioned` also inherit from `KeyError` and
`ValueError` respectively, so existing Python idioms continue to work
without needing to import buttdial-specific classes.
"""

from __future__ import annotations


class ButtDialError(Exception):
    """Base class for every exception the SDK raises on purpose.

    Carries optional `code`, `stage`, and `remediation` attributes mirroring
    the fields on `SendResult` / `DoctorStage`, so host apps can use a
    single error-handling pattern everywhere:

        try:
            ...
        except ButtDialError as e:
            log(code=e.code, stage=e.stage, remediation=e.remediation)
    """

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        stage: str | None = None,
        remediation: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.stage = stage
        self.remediation = remediation


class ConfigError(ButtDialError):
    """Raised when the SDK is misconfigured (missing URL, missing token, etc.)."""


class TransportError(ButtDialError):
    """Raised for connectivity / auth failures the SDK can't wrap into a SendResult."""
