"""Admin FastAPI router factory.

Seven operational endpoints a host can mount to give operators visibility
into Butt-Dial integration health, per-agent provisioning, and the retry
queue. Ported from iv-bknd/api/routes/butt_dial.py with these changes:

- `/usage` dropped — iv-bknd's version is heavy reporting SQL that's
  host-specific. Hosts needing usage dashboards build their own route.
- Activate/deactivate use a clean `AgentDirectory.activate(id)` protocol
  instead of iv-bknd's buggy `update(id, dict)` pattern (which mismatches
  the real `AgentLeaderRegistry.update(agent)` signature in iv-bknd — a
  latent production bug).
- `DELETE /failed-messages/{id}` changed to `POST .../dismiss` — explicit
  action URL, matches SPEC.

`fastapi` is imported at module top (behind try/except) so type hints on
inner handlers resolve via `get_type_hints()` — see docs/ERRORS.md.
"""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

from buttdial.client import Client
from buttdial.errors import ButtDialError
from buttdial.models import AgentInfo, FailedMessage, FailedStatus, OverviewSnapshot
from buttdial.retry import FailedMessageRepository

try:
    from fastapi import APIRouter, HTTPException

    _FASTAPI_AVAILABLE = True
except ImportError:  # pragma: no cover
    APIRouter = None  # type: ignore[assignment,misc]
    HTTPException = None  # type: ignore[assignment,misc]
    _FASTAPI_AVAILABLE = False

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SDK exceptions — host protocol implementations raise these; router maps
# to HTTP status codes. Inherit from builtins so Python idioms work.
# ---------------------------------------------------------------------------


class AgentNotFound(ButtDialError, KeyError):
    """Raised by `AgentDirectory.activate/deactivate` when agent_id is unknown.

    Inherits from both `ButtDialError` (so `except ButtDialError:` catches it)
    and `KeyError` (so existing Python idioms still work).
    """


class AgentNotProvisioned(ButtDialError, ValueError):
    """Raised by `AgentDirectory.activate` when the agent has no Butt-Dial token.

    Inherits from both `ButtDialError` and `ValueError`.
    """


# ---------------------------------------------------------------------------
# Host-implemented protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class AgentDirectory(Protocol):
    """Host-provided adapter for per-agent queries + activation state.

    The SDK never touches the host's agent tables directly — implementations
    read from and write to whatever agent model the host uses.
    """

    async def list_agents(self) -> list[AgentInfo]:
        """Return every agent known to the host, whether provisioned or not."""
        ...

    async def overview_snapshot(self) -> OverviewSnapshot:
        """Return aggregated counts for the `/overview` endpoint."""
        ...

    async def activate(self, agent_id: str) -> AgentInfo:
        """Transition agent to `active`.

        Raise `AgentNotFound` if the id is unknown.
        Raise `AgentNotProvisioned` if the agent has no Butt-Dial token yet.
        """
        ...

    async def deactivate(self, agent_id: str) -> AgentInfo:
        """Transition agent to `paused`. Raise `AgentNotFound` if unknown."""
        ...


@runtime_checkable
class AdminFailedMessageRepository(FailedMessageRepository, Protocol):
    """Adds admin-surface methods to the retry-worker `FailedMessageRepository`.

    Required for the admin router's `/failed-messages` endpoints. Hosts that
    only want the retry worker implement the simpler `FailedMessageRepository`.
    """

    async def list(
        self, status: FailedStatus = "pending", limit: int = 50
    ) -> list[FailedMessage]:
        """Return messages with the given status, newest first, up to `limit`."""
        ...

    async def count_pending(self) -> int:
        """Return the number of messages currently waiting for retry."""
        ...

    async def force_retry(self, msg_id: str) -> bool:
        """Reschedule a pending message for immediate retry (`next_retry_at = NOW()`).

        Returns True if a row was updated, False otherwise.
        """
        ...

    async def dismiss(self, msg_id: str) -> bool:
        """Mark a message as `dismissed` regardless of current state.

        Returns True if a row was updated, False otherwise.
        """
        ...


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def make_router(
    client: Client,
    repo: AdminFailedMessageRepository,
    directory: AgentDirectory,
) -> Any:
    """Build a FastAPI router exposing the seven admin endpoints.

    Mount with any prefix:

        app.include_router(make_router(client, repo, directory), prefix="/api/butt-dial")
    """
    if not _FASTAPI_AVAILABLE:  # pragma: no cover
        raise ImportError(
            "make_router requires fastapi. Install with: pip install 'butt-dial-sdk[router]'"
        )

    router = APIRouter()

    @router.get("/overview")
    async def overview() -> dict[str, Any]:
        tools = await client.list_tools()
        tool_count = len(tools)
        connection_status = "connected" if tool_count > 0 else "disconnected"

        last_ping: str | None = None
        if connection_status == "connected":
            if await client.ping():
                last_ping = "ok"
            else:
                connection_status = "degraded"

        snap = await directory.overview_snapshot()
        failed_queue_size = await repo.count_pending()
        cost_summary = await client.fetch_usage_summary()

        return {
            "connection_status": connection_status,
            "server_url": client.url,
            "tool_count": tool_count,
            "agents_provisioned": snap.agents_provisioned,
            "total_messages_sent": snap.total_messages_sent,
            "total_messages_failed": snap.total_messages_failed,
            "total_messages_received": snap.total_messages_received,
            "failed_queue_size": failed_queue_size,
            "cost_summary": cost_summary,
            "last_ping": last_ping,
        }

    @router.get("/agents")
    async def agents() -> list[dict[str, Any]]:
        agent_list = await directory.list_agents()
        return [a.model_dump(mode="json") for a in agent_list]

    @router.post("/agents/{agent_id}/activate")
    async def activate(agent_id: str) -> dict[str, Any]:
        try:
            agent = await directory.activate(agent_id)
        except AgentNotFound as e:
            raise HTTPException(status_code=404, detail="Agent not found") from e
        except AgentNotProvisioned as e:
            raise HTTPException(
                status_code=400,
                detail="Agent has no Butt-Dial token — provision first",
            ) from e
        return {"status": agent.status, "agent": agent.name, "id": agent.id}

    @router.post("/agents/{agent_id}/deactivate")
    async def deactivate(agent_id: str) -> dict[str, Any]:
        try:
            agent = await directory.deactivate(agent_id)
        except AgentNotFound as e:
            raise HTTPException(status_code=404, detail="Agent not found") from e
        return {"status": agent.status, "agent": agent.name, "id": agent.id}

    @router.get("/failed-messages")
    async def failed_messages(
        status: FailedStatus = "pending", limit: int = 50
    ) -> list[dict[str, Any]]:
        rows = await repo.list(status=status, limit=limit)
        return [r.model_dump(mode="json") for r in rows]

    @router.post("/failed-messages/{msg_id}/retry")
    async def retry_failed(msg_id: str) -> dict[str, Any]:
        updated = await repo.force_retry(msg_id)
        if not updated:
            raise HTTPException(status_code=404, detail="Message not found or not pending")
        return {"queued": True, "id": msg_id}

    @router.post("/failed-messages/{msg_id}/dismiss")
    async def dismiss_failed(msg_id: str) -> dict[str, Any]:
        updated = await repo.dismiss(msg_id)
        if not updated:
            raise HTTPException(status_code=404, detail="Message not found")
        return {"dismissed": True, "id": msg_id}

    return router
