"""butt-dial-sdk — client-side tunnel for the Butt-Dial communication service."""

from buttdial.accounts import (
    AccountsClient,
    AccountsError,
    ChallengeNotFound,
    EmailAlreadyRegistered,
    OTPExpired,
    OTPInvalid,
    OTPMaxAttempts,
    PhoneNotConfigured,
    TokenRevoked,
    VerificationTokenExpired,
)
from buttdial.client import Client
from buttdial.errors import ButtDialError, ConfigError, TransportError
from buttdial.inbound import InboundHandler
from buttdial.models import (
    AgentInfo,
    Channel,
    DeliveryReceipt,
    DoctorReport,
    DoctorStage,
    FailedMessage,
    InboundMessage,
    OverviewSnapshot,
    SendResult,
    StatusUpdate,
)
from buttdial.retry import (
    FailedMessageRepository,
    RetryWorker,
    default_backoff,
)
from buttdial.router import (
    AdminFailedMessageRepository,
    AgentDirectory,
    AgentNotFound,
    AgentNotProvisioned,
    make_router,
)
from buttdial.doctor import find_remediation, run_diagnostic

__version__ = "0.2.0"

__all__ = [
    "Client",
    "InboundHandler",
    "RetryWorker",
    "FailedMessageRepository",
    "default_backoff",
    "make_router",
    "AgentDirectory",
    "AdminFailedMessageRepository",
    "AgentNotFound",
    "AgentNotProvisioned",
    "ButtDialError",
    "ConfigError",
    "TransportError",
    # Accounts (onboarding + token rotation)
    "AccountsClient",
    "AccountsError",
    "EmailAlreadyRegistered",
    "VerificationTokenExpired",
    "PhoneNotConfigured",
    "OTPInvalid",
    "OTPExpired",
    "OTPMaxAttempts",
    "ChallengeNotFound",
    "TokenRevoked",
    "Channel",
    "SendResult",
    "FailedMessage",
    "InboundMessage",
    "DeliveryReceipt",
    "StatusUpdate",
    "AgentInfo",
    "OverviewSnapshot",
    "DoctorReport",
    "DoctorStage",
    "run_diagnostic",
    "find_remediation",
    "__version__",
]
