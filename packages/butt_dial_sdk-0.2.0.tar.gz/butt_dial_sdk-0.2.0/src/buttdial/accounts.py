"""Butt-Dial account lifecycle — register, verify, phone setup, token rotation.

This module wraps the REST endpoints a third-party platform needs to onboard
a tenant onto Butt-Dial and manage their owner bearer token. It is deliberately
**separate** from :class:`buttdial.client.Client` (which handles MCP/SSE tool
calls) — accounts are a plain HTTP surface with different auth semantics.

Scope
-----
This module covers the **first-bearer-token lifecycle only**. Once a tenant
has an owner token and a configured admin phone, the ongoing work of buying
phones / emails / SMS numbers and activating IM devices goes through the
existing provisioning endpoints hit by :class:`buttdial.client.Client`
(channel provisioning, callback registration, etc.) — not this module.

Auth modes
----------
- ``register`` / ``verify`` run **unauthenticated**. The verification token
  returned via email is the only secret needed to claim the owner token.
- Everything else requires the owner bearer token returned by ``verify``.
  Stale or rotated-out tokens produce ``TokenRevoked``, which the host app
  should interpret as "refresh my stored value, prompt re-auth if I don't
  have a new one".

Error handling
--------------
The server returns machine-readable codes in the JSON body
(``{"code": "OTP_INVALID", "message": "..."}``). We map each documented
code to a dedicated exception subclass so hosts can react with
``except OTPInvalid: ...`` instead of matching on strings.

Example
-------

.. code-block:: python

    from buttdial import AccountsClient

    accounts = AccountsClient("https://call.95percent.ai")

    r = await accounts.register("Acme Inc", "alice@acme.com")
    # ... user clicks the email link, deep-links back to your app with
    # ?verification=<token> ...
    info = await accounts.verify(verification_token)
    owner_token = info["owner_token"]

    # Authenticated calls now. Set the phone, confirm via SMS-delivered OTP.
    authed = AccountsClient("https://call.95percent.ai", owner_token=owner_token)
    challenge = await authed.set_phone("+14155550123")
    otp = prompt_user("Enter the 6-digit code")  # host app's UI
    await authed.confirm_phone(challenge["challenge_id"], otp)

    # Later: rotate the owner token. Old token is revoked atomically.
    new = await authed.rotate_token(otp_prompt=lambda hint: prompt_user(
        f"Enter the code sent to {hint}"
    ))
    save_to_vault(new["token"])
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Union

import httpx

from buttdial.errors import ButtDialError, ConfigError, TransportError


# ---------------------------------------------------------------------------
# Typed error hierarchy
# ---------------------------------------------------------------------------

class AccountsError(ButtDialError):
    """Base class for Butt-Dial accounts-API errors.

    Carries the server-returned ``code`` (e.g. ``OTP_INVALID``) and the HTTP
    status. Subclasses are raised for each documented code so host apps can
    use ``except OTPInvalid:`` style handlers instead of inspecting the code.
    """

    #: Server-side code this subclass maps to. Empty on the base class.
    server_code: str = ""

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message, code=code)
        self.status_code = status_code


class EmailAlreadyRegistered(AccountsError):
    """The email used in ``register`` already owns a Butt-Dial org."""

    server_code = "EMAIL_ALREADY_REGISTERED"


class VerificationTokenExpired(AccountsError):
    """The email-link verification token passed to ``verify`` is too old."""

    server_code = "VERIFICATION_TOKEN_EXPIRED"


class PhoneNotConfigured(AccountsError):
    """Rotate was requested but no admin phone has been set + confirmed yet.

    The host UI should redirect the admin to the phone-setup screen
    (``set_phone`` → OTP → ``confirm_phone``) and retry the rotation after.
    """

    server_code = "PHONE_NOT_CONFIGURED"


class OTPInvalid(AccountsError):
    """The OTP entered didn't match the challenge."""

    server_code = "OTP_INVALID"


class OTPExpired(AccountsError):
    """The OTP challenge TTL elapsed before the user submitted the code."""

    server_code = "OTP_EXPIRED"


class OTPMaxAttempts(AccountsError):
    """Too many wrong OTP attempts on this challenge; request a fresh one."""

    server_code = "OTP_MAX_ATTEMPTS"


class ChallengeNotFound(AccountsError):
    """The ``challenge_id`` doesn't exist.

    Usually means another tab consumed it, or the server restarted.
    """

    server_code = "CHALLENGE_NOT_FOUND"


class TokenRevoked(AccountsError):
    """The owner token used was revoked (usually by a successful rotation)."""

    server_code = "TOKEN_REVOKED"


# Map server code → exception class. Lookup table for `_raise_for_code`.
_ERROR_BY_CODE: dict[str, type[AccountsError]] = {
    cls.server_code: cls
    for cls in (
        EmailAlreadyRegistered,
        VerificationTokenExpired,
        PhoneNotConfigured,
        OTPInvalid,
        OTPExpired,
        OTPMaxAttempts,
        ChallengeNotFound,
        TokenRevoked,
    )
}


def _raise_for_code(code: str, message: str, status: int) -> None:
    """Raise the mapped AccountsError subclass for `code`, or a generic one."""
    cls = _ERROR_BY_CODE.get(code, AccountsError)
    raise cls(message or code, code=code, status_code=status)


# Type for the OTP prompt callback — sync or async.
OtpPrompt = Callable[[str], Union[str, Awaitable[str]]]


# ---------------------------------------------------------------------------
# AccountsClient
# ---------------------------------------------------------------------------

class AccountsClient:
    """REST client for Butt-Dial account lifecycle endpoints.

    Parameters
    ----------
    base_url:
        Butt-Dial server base URL (no trailing ``/api/orgs/...``). Example:
        ``https://call.95percent.ai``. Required.
    owner_token:
        Bearer token for authenticated calls. Can be ``None`` at construction
        if the first call will be ``register`` or ``verify`` (those are
        unauthenticated). Set via :meth:`with_token` after ``verify``.
    timeout:
        Per-request timeout in seconds. Default 15.
    transport:
        Optional ``httpx.AsyncBaseTransport`` — used by tests to inject
        ``respx``. Production leaves this ``None``.
    """

    def __init__(
        self,
        base_url: str,
        *,
        owner_token: str | None = None,
        timeout: float = 15.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not base_url:
            raise ConfigError("base_url is required")
        self._base_url = base_url.rstrip("/")
        self._owner_token = owner_token
        self._timeout = timeout
        self._transport = transport

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def with_token(self, owner_token: str) -> "AccountsClient":
        """Return a copy of this client with a fresh owner token.

        Useful right after ``verify`` returns the first token, or after
        ``rotate_token`` returns a new one — keeps the existing instance
        immutable while the caller swaps its stored value.
        """
        return AccountsClient(
            self._base_url,
            owner_token=owner_token,
            timeout=self._timeout,
            transport=self._transport,
        )

    @property
    def owner_token(self) -> str | None:
        return self._owner_token

    # ------------------------------------------------------------------
    # Unauthenticated endpoints
    # ------------------------------------------------------------------

    async def register(
        self, org_name: str, owner_email: str,
    ) -> dict[str, Any]:
        """Start signup. Returns ``{org_id, verification_sent}``.

        The server sends a verification email to ``owner_email`` with a
        time-boxed link. The host app's deep-link handler must call
        :meth:`verify` with the token embedded in that link.

        Raises ``EmailAlreadyRegistered`` if the email already owns an org.
        """
        return await self._request(
            "POST", "/api/orgs/register",
            body={"orgName": org_name, "ownerEmail": owner_email},
            authenticated=False,
        )

    async def verify(self, token: str) -> dict[str, Any]:
        """Exchange a verification token for the owner bearer token.

        Returns ``{owner_token, org_id, mode}``. Store ``owner_token`` in
        your vault keyed by tenant id — everything authenticated uses it.

        Raises ``VerificationTokenExpired`` if the link is too old.
        """
        return await self._request(
            "POST", "/api/orgs/verify",
            body={"token": token},
            authenticated=False,
        )

    # ------------------------------------------------------------------
    # Admin phone setup
    # ------------------------------------------------------------------

    async def set_phone(self, phone: str) -> dict[str, Any]:
        """Start an admin-phone challenge. Returns ``{challenge_id}``.

        Server sends a 6-digit OTP to ``phone`` via SMS. Follow up with
        :meth:`confirm_phone` passing the ``challenge_id`` and the code
        the admin enters.

        `phone` must be E.164 (e.g. ``+14155550123``).
        """
        return await self._request(
            "POST", "/api/orgs/me/phone/set",
            body={"phone": phone},
        )

    async def confirm_phone(
        self, challenge_id: str, otp: str,
    ) -> dict[str, Any]:
        """Confirm the admin-phone challenge. Returns ``{ok, phone_hint}``.

        On success the phone is officially registered as the admin phone
        for this org — future rotations deliver OTPs here.

        Raises ``OTPInvalid`` / ``OTPExpired`` / ``OTPMaxAttempts`` /
        ``ChallengeNotFound`` depending on the failure mode.
        """
        return await self._request(
            "POST", "/api/orgs/me/phone/confirm",
            body={"challengeId": challenge_id, "otp": otp},
        )

    # ------------------------------------------------------------------
    # Token rotation
    # ------------------------------------------------------------------

    async def rotate_token_request(self) -> dict[str, Any]:
        """Start a token-rotation challenge. Returns ``{challenge_id, phone_hint}``.

        Server sends a fresh OTP to the admin phone. Use the returned
        ``phone_hint`` (e.g. ``+1********23``) to remind the user which
        number to check.

        Raises ``PhoneNotConfigured`` if the admin phone was never set +
        confirmed; the host UI must run the phone-setup flow first.
        """
        return await self._request(
            "POST", "/api/orgs/me/rotate-token/request",
            body={},
        )

    async def rotate_token_confirm(
        self, challenge_id: str, otp: str,
    ) -> dict[str, Any]:
        """Confirm rotation. Returns ``{token}`` — a fresh owner bearer token.

        On success the **old token is revoked atomically** on the server
        side. The host app must replace its stored copy before the next
        authenticated request, otherwise stale holders will hit ``TokenRevoked``.

        Raises OTP errors on bad input or ``ChallengeNotFound`` if another
        tab consumed the challenge first.
        """
        return await self._request(
            "POST", "/api/orgs/me/rotate-token/confirm",
            body={"challengeId": challenge_id, "otp": otp},
        )

    async def rotate_token(
        self, otp_prompt: OtpPrompt,
    ) -> dict[str, Any]:
        """Convenience: request + confirm in one call.

        ``otp_prompt`` is a callable that takes ``phone_hint`` (str) and
        returns the 6-digit code the user entered. It can be sync or
        async; both are awaited uniformly.

        Returns the same shape as :meth:`rotate_token_confirm` — ``{token}``.

        Error semantics are identical to the individual calls. Callers
        still need to update their stored token value on success; this
        helper intentionally does **not** mutate ``self._owner_token``
        because rotating and continuing to use the same client instance
        is often what hosts want *only* after they've persisted the new
        token (crash-safety).
        """
        challenge = await self.rotate_token_request()
        hint = challenge.get("phone_hint", "")
        maybe_otp = otp_prompt(hint)
        if hasattr(maybe_otp, "__await__"):
            otp: str = await maybe_otp  # type: ignore[misc,assignment]
        else:
            otp = maybe_otp  # type: ignore[assignment]
        return await self.rotate_token_confirm(challenge["challenge_id"], otp)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    async def get_account(self) -> dict[str, Any]:
        """Return the current owner's account state.

        ``{org_id, name, owner_email, owner_phone_hint, mode, created_at, status}``.

        Raises ``TokenRevoked`` if the stored token was rotated out (or
        otherwise revoked). This is the canonical self-heal check for a
        rotation that timed out mid-flight — a 200 here means the stored
        value is still good; a ``TokenRevoked`` means the rotation landed
        and the host must refresh its copy.
        """
        return await self._request(
            "GET", "/api/orgs/me",
        )

    # ------------------------------------------------------------------
    # Internal HTTP helper
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
        authenticated: bool = True,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if authenticated:
            if not self._owner_token:
                raise ConfigError(
                    f"{path} requires an owner token. Construct AccountsClient "
                    "with owner_token=..., or call verify() first."
                )
            headers["Authorization"] = f"Bearer {self._owner_token}"

        url = f"{self._base_url}{path}"
        try:
            async with httpx.AsyncClient(
                timeout=self._timeout,
                transport=self._transport,
            ) as client:
                resp = await client.request(
                    method,
                    url,
                    headers=headers,
                    json=body if body is not None else None,
                )
        except (httpx.TransportError, httpx.TimeoutException) as e:
            raise TransportError(
                f"Butt-Dial accounts {method} {path}: {e}",
                stage="transport",
            ) from e

        # Successful 2xx — return parsed JSON (or {} when body is empty).
        if 200 <= resp.status_code < 300:
            if not resp.content:
                return {}
            try:
                return resp.json()
            except ValueError:
                # Server sent 2xx with non-JSON body. Unusual but survivable —
                # treat as empty success so callers don't crash on missing keys.
                return {}

        # Error response — parse code and raise the typed exception.
        code = ""
        message = ""
        try:
            payload = resp.json()
            if isinstance(payload, dict):
                code = str(payload.get("code") or "")
                message = str(payload.get("message") or "")
        except ValueError:
            pass

        if not message:
            # Fall back to the HTTP reason phrase so the user gets something
            # human-readable even when the server didn't populate `message`.
            message = f"{resp.status_code} {resp.reason_phrase}"

        _raise_for_code(code, message, resp.status_code)
        # Unreachable — _raise_for_code always raises.
        raise AccountsError(message, code=code, status_code=resp.status_code)
