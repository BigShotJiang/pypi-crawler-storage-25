"""Butt-Dial client — MCP/SSE transport + `send_message`.

Ported from iv-bknd/engine/comms.py. Semantics preserved exactly:

- Token resolution: per-agent token > client token (caller's org token) >
  legacy per-team client token. Org token is preferred over client token
  because client tokens are per-team and get rotated/revoked; iv-bknd hit
  this in production when `BUTT_DIAL_CLIENT_TOKEN` went stale and system
  sends (OTP, magic link) silently 401'd.
- Idempotency key per send (UUID4). Retries re-use the same key so the
  server deduplicates.
- 3 attempts with exponential backoff (2s, 4s, 8s, capped at 10s). On
  exhaustion, returns `SendResult(failed=True)` — does not raise.
- SID extraction tries `messageId`, `sid`, `message_sid` (all three have been
  observed in responses from different Butt-Dial versions).

What was NOT ported (stays in the host app):
- `validate_number` / `check_consent` / `detect_language` pre-checks.
- Emitting `observability.event_log` on failure.
- Inserting into the `failed_messages` dead-letter queue (Phase 4 protocol).
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from buttdial.models import Channel, SendResult
from buttdial.settings import load as load_settings

logger = logging.getLogger(__name__)

SEND_TOOL = "comms_send_message"


# Mapping of server-error substrings → remediation text. Used when
# Butt-Dial returns a business-level `{"error": "..."}` response so
# callers see actionable next steps, not just the raw server string.
_SERVER_ERROR_REMEDIATIONS: list[tuple[str, str]] = [
    (
        "agentid is required",
        "This tool needs agent context. Either pass `agent_token=<per-agent token>` "
        "to send_message(), OR construct Client(..., client_token=<per-agent token>) "
        "and leave the org token out. See docs/DECISIONS.md on token priority.",
    ),
    (
        "agent id is required",
        "Pass `agent_token=<per-agent token>` or set the per-agent client_token on Client.",
    ),
    (
        "invalid recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "invalid_recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "consent",
        "Recipient has not consented / is opted out. Check the opt-in status "
        "before sending, or configure consent-on-first-message in the Butt-Dial admin console.",
    ),
    (
        "rate limit",
        "Rate limit hit. Back off and retry with exponential delay, or request a higher quota.",
    ),
    (
        "not provisioned",
        "The sending channel is not provisioned for this team. Provision the channel "
        "in the Butt-Dial admin console before sending.",
    ),
]


def _server_error_remediation(error_text: str) -> str | None:
    """Map a server-returned error string to an actionable remediation. None if unknown."""
    lower = (error_text or "").lower()
    for trigger, remedy in _SERVER_ERROR_REMEDIATIONS:
        if trigger in lower:
            return remedy
    return None


class Client:
    """Client-side tunnel to a Butt-Dial MCP server."""

    def __init__(
        self,
        token: str | None = None,
        url: str | None = None,
        *,
        client_token: str | None = None,
        send_tool: str = SEND_TOOL,
        max_send_attempts: int = 3,
        sse_timeout: float = 30.0,
    ) -> None:
        if not url:
            raise ValueError("Client requires `url` (Butt-Dial SSE endpoint).")
        self.url = url
        self.token = token or ""
        self.client_token = client_token or ""
        self.send_tool = send_tool
        self.max_send_attempts = max_send_attempts
        self.sse_timeout = sse_timeout

    @classmethod
    def from_env(cls, **overrides: Any) -> "Client":
        """Build a Client from `BUTT_DIAL_URL` / `BUTT_DIAL_TOKEN` / `BUTT_DIAL_CLIENT_TOKEN`."""
        s = load_settings()
        return cls(
            token=overrides.pop("token", s.token),
            url=overrides.pop("url", s.url),
            client_token=overrides.pop("client_token", s.client_token),
            **overrides,
        )

    def _resolve_token(self, agent_token: str | None) -> str:
        return agent_token or self.token or self.client_token

    async def send_message(
        self,
        to: str,
        body: str,
        channel: Channel = "whatsapp",
        *,
        agent_token: str | None = None,
        sender_name: str | None = None,
        language: str | None = None,
        fallback_channels: list[str] | None = None,
        scheduled_at: str | None = None,
        thread_id: str | None = None,
        entity_id: str | None = None,
        reply_msg_id: str | None = None,
        idempotency_key: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> SendResult:
        """Send a single message via Butt-Dial.

        Returns a `SendResult`; does not raise on transient failures (retried
        internally). On exhaustion returns `SendResult(failed=True)` with
        `stage_failed` + `remediation` set.
        """
        token = self._resolve_token(agent_token)
        if not token:
            logger.error("send_message: no Butt-Dial token configured")
            return SendResult(
                failed=True,
                error="No Butt-Dial token configured",
                stage_failed="config",
                remediation=(
                    "Set BUTT_DIAL_TOKEN (preferred) or BUTT_DIAL_CLIENT_TOKEN, "
                    "or pass token=... to Client(), or agent_token=... to send_message()."
                ),
            )

        args: dict[str, Any] = {
            "to": to,
            "body": body,
            "channel": channel,
            "idempotencyKey": idempotency_key or str(uuid.uuid4()),
        }
        if sender_name:
            args["senderName"] = sender_name
        if language:
            args["language"] = language
        if fallback_channels:
            args["fallbackChannels"] = fallback_channels
        if scheduled_at:
            args["scheduledAt"] = scheduled_at
        if thread_id:
            args["threadId"] = thread_id
        if entity_id:
            args["entityId"] = entity_id
        if reply_msg_id:
            args["replyMsgId"] = reply_msg_id
        if extra:
            args.update(extra)

        last_exc: BaseException | None = None
        parsed: Any = None
        raw: Any = None

        for attempt_num in range(self.max_send_attempts):
            try:
                parsed, raw = await self._call_send_tool(token, args)
                last_exc = None
                break
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "send_message attempt %d/%d failed: %s",
                    attempt_num + 1,
                    self.max_send_attempts,
                    exc,
                )
                if attempt_num < self.max_send_attempts - 1:
                    delay = min(10.0, 2.0 ** (attempt_num + 1))
                    await asyncio.sleep(delay)

        if last_exc is not None:
            return SendResult(
                failed=True,
                error=str(last_exc),
                stage_failed="transport",
                remediation=(
                    "Check Butt-Dial server reachability and token validity — "
                    "run `buttdial doctor` for a staged diagnostic."
                ),
            )

        message_sid = self._extract_sid(parsed)
        if message_sid:
            logger.info("send_message: to=%s channel=%s sid=%s", to, channel, message_sid)
            return SendResult(message_sid=message_sid, raw=raw)

        # No SID — did the server tell us why? Many Butt-Dial tools respond
        # with `{"error": "..."}` on business-level failures (e.g. missing
        # agentId, recipient validation, consent). Surfacing that text —
        # rather than "no message_sid returned" — is what makes failures
        # diagnosable without a separate debug session.
        server_error = self._extract_server_error(parsed)
        if server_error:
            logger.warning("send_message: server returned error: %s", server_error)
            return SendResult(
                failed=True,
                error=server_error,
                stage_failed="server",
                remediation=_server_error_remediation(server_error),
                raw=raw,
            )

        logger.warning("send_message: no message_sid and no error in response: %r", parsed)
        return SendResult(
            failed=True,
            error="server response contained no message_sid and no error",
            stage_failed="parse",
            remediation=(
                "Butt-Dial server returned an unrecognized response shape. "
                "Check the server version and the SDK's Client.send_tool name."
            ),
            raw=raw,
        )

    async def _call_send_tool(self, token: str, args: dict[str, Any]) -> tuple[Any, Any]:
        """Open SSE, initialize session, invoke the send tool. Returns (parsed, raw_result)."""
        from mcp import ClientSession
        from mcp.client.sse import sse_client

        headers = {"Authorization": f"Bearer {token}"}
        async with sse_client(self.url, headers=headers, timeout=self.sse_timeout) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(self.send_tool, arguments=args)
                text = result.content[0].text if result.content else None
                try:
                    parsed = json.loads(text) if text else None
                except (json.JSONDecodeError, TypeError):
                    parsed = text
                return parsed, result

    @staticmethod
    def _extract_sid(parsed: Any) -> str | None:
        if isinstance(parsed, dict):
            return parsed.get("messageId") or parsed.get("sid") or parsed.get("message_sid")
        return None

    @staticmethod
    def _extract_server_error(parsed: Any) -> str | None:
        """Pull a human-readable error text from a business-level failure response.

        Butt-Dial tools return `{"error": "..."}` on validation / config
        failures. Some tools return `{"errors": [...]}` (list) for multi-
        failure responses. This helper tries both.
        """
        if not isinstance(parsed, dict):
            return None
        err = parsed.get("error")
        if isinstance(err, str) and err:
            return err
        errors = parsed.get("errors")
        if isinstance(errors, list) and errors:
            return "; ".join(str(e) for e in errors)
        return None

    # ----- admin / introspection -------------------------------------------

    async def list_tools(self) -> list[str]:
        """Return the names of tools exposed by the Butt-Dial MCP server.

        Returns an empty list on any error (disconnected, auth failure, etc.).
        Used by the admin router's `/overview` endpoint to report connection
        health.
        """
        token = self._resolve_token(None)
        if not token:
            return []
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client

            headers = {"Authorization": f"Bearer {token}"}
            async with sse_client(self.url, headers=headers, timeout=self.sse_timeout) as (
                read,
                write,
            ):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [t.name for t in result.tools]
        except Exception as exc:
            logger.warning("list_tools failed: %s", exc)
            return []

    async def ping(self, tool_name: str = "comms_ping") -> bool:
        """Call the server's ping tool. True if it returned anything; False on error."""
        token = self._resolve_token(None)
        if not token:
            return False
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client

            headers = {"Authorization": f"Bearer {token}"}
            async with sse_client(self.url, headers=headers, timeout=self.sse_timeout) as (
                read,
                write,
            ):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.call_tool(tool_name, arguments={})
                    return bool(result and result.content)
        except Exception as exc:
            logger.debug("ping failed: %s", exc)
            return False

    async def fetch_usage_summary(self, path: str = "/api/v1/usage") -> dict[str, Any] | None:
        """Fetch the Butt-Dial usage summary via REST (not MCP).

        The Butt-Dial server exposes `<base>/api/v1/usage` with the same
        bearer token. The SSE URL is assumed to end with `/sse`; the base is
        the URL with `/sse` stripped. Returns the parsed JSON body on 200;
        None on any error (including no token configured).
        """
        import httpx

        token = self._resolve_token(None)
        if not token:
            return None
        base_url = self.url.rsplit("/sse", 1)[0] if self.url.endswith("/sse") else self.url
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{base_url}{path}",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return data if isinstance(data, dict) else None
        except Exception as exc:
            logger.debug("fetch_usage_summary failed: %s", exc)
        return None
