"""Minimal example — send one message.

Run:
    export BUTT_DIAL_URL=https://your-server.example/sse
    export BUTT_DIAL_TOKEN=your-org-token
    python examples/minimal/send_one.py +14155550123
"""

from __future__ import annotations

import asyncio
import sys

from buttdial import Client


async def main(recipient: str) -> int:
    bd = Client.from_env()
    result = await bd.send_message(to=recipient, body="Hello from butt-dial-sdk 👋")
    if result.ok:
        print(f"sent: {result.message_sid}")
        return 0
    print(f"failed at stage {result.stage_failed}: {result.error}")
    if result.remediation:
        print(f"  fix: {result.remediation}")
    return 1


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: send_one.py <recipient E.164>")
        raise SystemExit(2)
    raise SystemExit(asyncio.run(main(sys.argv[1])))
