"""API package scaffold."""
