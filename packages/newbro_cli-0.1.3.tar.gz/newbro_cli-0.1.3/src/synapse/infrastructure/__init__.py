"""Infrastructure package scaffold."""
