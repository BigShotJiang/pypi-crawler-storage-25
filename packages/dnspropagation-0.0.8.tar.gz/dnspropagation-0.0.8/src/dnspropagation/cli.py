import argparse
import json
import sys

import yaml
#import pkg_resources

try:
    from dnspropagation.core import DNSpropagation
    from dnspropagation.exitcodes import (
        EXIT_SUCCESS, EXIT_MISSING_ARGS, EXIT_NO_SERVERS, EXIT_EXPECTED_MISMATCH,
    )
except ImportError:
    from core import DNSpropagation
    from exitcodes import (
        EXIT_SUCCESS, EXIT_MISSING_ARGS, EXIT_NO_SERVERS, EXIT_EXPECTED_MISMATCH,
    )

version = "0.0.8"

def main():
    dns_servers = []
    args_dict = {'json': False, 'simple': False, 'debug': False, 'dnslist': None, 'random': None, 'tags': None,
                 'owner': None, 'expected': None, 'server': None, 'custom_list': None, 'show_default': False}

    parser = argparse.ArgumentParser()

    # Add optional arguments with no parameters
    parser.add_argument("--json",
                        action="store_true",
                        help="Print JSON output instead of a human-readable table.")
    parser.add_argument("--yaml",
                        action="store_true",
                        help="Print YAML output instead of a human-readable table.")
    parser.add_argument("--show-default",
                        action="store_true",
                        help="Show YAML-formattes list of default DNS servers.")
    parser.add_argument("--version",
                        action="store_true")
    parser.add_argument("--ttl",
                        action="store_true",
                        help="Show TTL value in the output.")
    parser.add_argument("--no-color",
                        action="store_true",
                        help="Disable colored output.")
    parser.add_argument("--timeout",
                        type=float,
                        default=None,
                        help="Timeout in seconds for each DNS query (e.g. 2.5). Defaults to dnspython's built-in timeout.")

    parser.add_argument("--html",
                        action="store_true",
                        help="Print results as a self-contained HTML page.")

    parser.add_argument("--random",
                        type=int,
                        help="Selects N random DNS server to query")
    parser.add_argument("--tags",
                        type=str,
                        action="append",
                        help="Filter DNS servers by tag. Accepts comma-separated values and can be used multiple times.")
    parser.add_argument("--owner",
                        type=str,
                        action="append",
                        help="Use only DNS servers from given owner. The argument can be used multiple times.")
    parser.add_argument("--expected",
                        type=str,
                        action="append",
                        help="Checks that DNS servers return expected values. The argument can be used multiple times.")
    parser.add_argument("--server",
                        type=str,
                        action="append",
                        help="IPv4 address of custom DNS server to query. Overrides default list. Can be used multiple times"
                             " to add multiple servers.")
    parser.add_argument("--custom_list",
                        type=str,
                        help="Local file path or http(s):// URL to a custom YAML-formatted list of DNS servers to query.")
    parser.add_argument("--file",
                        type=str,
                        help="YAML formatted file")

    parser.add_argument("record_type",
                        metavar="TYPE",
                        type=str,
                        nargs="?",
                        help="Type of DNS record to check; e.g. TXT, A, CAA. Case insensitive.")
    parser.add_argument("domain",
                        metavar="DOMAIN",
                        type=str,
                        nargs="?",
                        help="Domain name to check; e.g. google.com")

    # Parse the arguments
    args = parser.parse_args()
    args_dict = vars(args)

    # Flatten comma-separated tag values
    if args_dict["tags"]:
        args_dict["tags"] = [t.strip() for entry in args_dict["tags"] for t in entry.split(",")]

    checker = DNSpropagation()
    checker.set_args_dict(args_dict)



    if args_dict["version"]:
        print(version)
        exit(EXIT_SUCCESS)

    if len(sys.argv) <= 1:
        print("You have to specify record type and domain name. Run the program with the --help to show more information.")
        exit(EXIT_MISSING_ARGS)

    if args_dict["custom_list"] is None and args_dict["server"] is None:
        dns_servers = checker.default_dns
        if args_dict["show_default"]:
            if args_dict["yaml"]:
                print(yaml.dump(checker.default_dns))
            else:
                print(checker.default_dns)
            exit(EXIT_SUCCESS)

    if args_dict["file"] is None and (args_dict["record_type"] is None or args_dict["domain"] is None):
        print("You have to specify record type and domain name. Run the program with the --help to show more information.")
        exit(EXIT_MISSING_ARGS)

    if args_dict['custom_list']:
        dns_servers = checker.parse_server_list(args_dict["custom_list"])
        checker.set_dns_servers(dns_servers)

    if args_dict["server"] is not None:
        for s in args_dict["server"]:
            tmp_server = {
                "ipv4": s,
                "owner": None,
                "tags": [],
            }
            dns_servers.append(tmp_server)

    # filter DNS servers
    dns_servers = checker.filter_servers(dns_servers, args_dict["tags"], args_dict["owner"])

    if not dns_servers:
        print("No DNS servers matched the specified filters.")
        sys.exit(EXIT_NO_SERVERS)

    if args_dict["random"] is not None:
        dns_servers = checker.random_servers(dns_servers, args_dict["random"])


    # run multiple checks at once
    if args_dict["file"] is not None:
        to_check = checker.parse_yaml(args_dict["file"])
        checker.multicheck(to_check, args_dict["tags"], args_dict["owner"])
        exit(EXIT_SUCCESS)

    args_dict["domain"] = checker.sanitize_domain(args_dict["domain"])

    results = checker.check_entries(dns_servers, args_dict["record_type"], args_dict["domain"], timeout=args_dict["timeout"])

    if args_dict["json"]:
        print(json.dumps(checker.dns_answer_to_strings(results, show_ttl=args_dict["ttl"])))
    elif args_dict["yaml"]:
        print(yaml.dump(checker.dns_answer_to_strings(results, show_ttl=args_dict["ttl"])))
    elif args_dict["html"]:
        print(checker.generate_html(results, args_dict["record_type"], args_dict["domain"],
                                    expected=args_dict["expected"], show_ttl=args_dict["ttl"]))
    else:
        checker.print_pretty_table(results, args_dict["expected"], show_ttl=args_dict["ttl"], no_color=args_dict["no_color"])

    if args_dict["expected"] is not None and not checker.check_expected(results, args_dict["expected"]):
        sys.exit(EXIT_EXPECTED_MISMATCH)



if __name__ == "__main__":
    main()
