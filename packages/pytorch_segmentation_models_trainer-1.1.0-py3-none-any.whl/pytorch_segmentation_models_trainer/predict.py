# -*- coding: utf-8 -*-
"""
/***************************************************************************
 pytorch_segmentation_models_trainer
                              -------------------
        begin                : 2021-03-02
        git sha              : $Format:%H$
        copyright            : (C) 2021 by Philipe Borba - Cartographic Engineer
                                                            @ Brazilian Army
        email                : philipeborba at gmail dot com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ****
"""

import logging
from typing import List

import hydra
import omegaconf
import torch
from hydra.utils import instantiate
from omegaconf import DictConfig
from omegaconf.omegaconf import OmegaConf
from tqdm import tqdm

from pytorch_segmentation_models_trainer.tools.inference.inference_processors import (
    AbstractInferenceProcessor,
)
from pytorch_segmentation_models_trainer.tools.inference.export_inference import (
    ConfidenceExportStrategy,
)
from pytorch_segmentation_models_trainer.tools.polygonization.polygonizer import (
    TemplatePolygonizerProcessor,
)
from pytorch_segmentation_models_trainer.utils.os_utils import import_module_from_cfg
from pytorch_segmentation_models_trainer.fine_tuning.lora_utils import (
    is_peft_model,
    merge_lora_weights,
)

logger = logging.getLogger(__name__)


def instantiate_model_from_checkpoint(cfg: DictConfig) -> torch.nn.Module:
    checkpoint_path = cfg.checkpoint_path

    # Determine the best map location
    if torch.cuda.is_available():
        device_count = torch.cuda.device_count()
        if "devices" not in cfg.pl_trainer:
            map_location = "cuda:0"
        elif cfg.pl_trainer.devices == -1:
            map_location = "cuda:0"
        else:
            if isinstance(cfg.pl_trainer.devices, int):
                # If devices=1, we want cuda:0. If devices=2, we might want cuda:0 or cuda:1 depending on context.
                # However, for loading a single model, cuda:0 is usually the safest default if we only have 1 device requested or available.
                device_idx = (
                    cfg.pl_trainer.devices
                    if cfg.pl_trainer.devices < device_count
                    else 0
                )
                map_location = f"cuda:{device_idx}"
            else:
                device_idx = (
                    cfg.pl_trainer.devices[0]
                    if cfg.pl_trainer.devices[0] < device_count
                    else 0
                )
                map_location = f"cuda:{device_idx}"
    else:
        map_location = "cpu"

    pl_model = import_module_from_cfg(cfg.pl_model).load_from_checkpoint(
        checkpoint_path,
        cfg=cfg,
        inference_mode=True,
        map_location=map_location,
        weights_only=False,
        strict=False,
    )
    model = pl_model.model
    del pl_model  # free duplicate weights (EMA + original) from checkpoint
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    # Merge LoRA adapter weights (if any) before inference so that the model
    # runs without the PEFT wrapper overhead.  Set keep_lora_adapters=true in
    # config to keep adapters active (e.g. for continued fine-tuning).
    should_merge = not bool(getattr(cfg, "keep_lora_adapters", False))
    if should_merge and is_peft_model(model):
        logger.info("Merging LoRA adapter weights before inference.")
        model = merge_lora_weights(model)

    model.to(cfg.device)
    model.eval()
    return model


def instantiate_polygonizer(cfg: DictConfig) -> TemplatePolygonizerProcessor:
    polygonizer = instantiate(cfg.polygonizer) if "polygonizer" in cfg else None
    return polygonizer


def instantiate_inference_processor(cfg: DictConfig) -> AbstractInferenceProcessor:
    obj_params = dict(cfg.inference_processor)
    obj_params["model"] = instantiate_model_from_checkpoint(cfg)
    obj_params["polygonizer"] = instantiate_polygonizer(cfg)
    obj_params["export_strategy"] = (
        instantiate(cfg.export_strategy, _recursive_=False)
        if "export_strategy" in cfg
        else None
    )
    obj_params["device"] = cfg.device
    obj_params["batch_size"] = cfg.hyperparameters.batch_size
    if "MultiClassInferenceProcessor" not in cfg.inference_processor._target_:
        obj_params["mask_bands"] = (
            sum(cfg.seg_params.values()) if "seg_params" in cfg else 1
        )
    else:
        obj_params["num_classes"] = cfg.inference_processor.num_classes
    if "normalize_mean" in cfg.inference_processor:
        obj_params["normalize_mean"] = cfg.inference_processor.normalize_mean
    if "normalize_std" in cfg.inference_processor:
        obj_params["normalize_std"] = cfg.inference_processor.normalize_std
    if "tta_mode" in cfg.inference_processor:
        obj_params["tta_mode"] = cfg.inference_processor.tta_mode
    if "confidence_mode" in cfg.inference_processor:
        obj_params["confidence_mode"] = cfg.inference_processor.confidence_mode
        if "export_strategy" in cfg:
            obj_params["confidence_export_strategy"] = ConfidenceExportStrategy(
                output_file_path=cfg.export_strategy.output_file_path
            )
    obj_params.pop("_target_")
    for key, value in obj_params.items():
        if isinstance(value, omegaconf.listconfig.ListConfig):
            obj_params[key] = list(value)

    return import_module_from_cfg(cfg.inference_processor)(**obj_params)


def get_images(cfg: DictConfig) -> List[str]:
    image_reader = instantiate(cfg.inference_image_reader, _recursive_=False)
    return image_reader.get_images()


@hydra.main(config_path=None, version_base="1.2")
def predict(cfg: DictConfig):
    logger.info(
        "Starting the prediction of a model with the following configuration: \n%s",
        OmegaConf.to_yaml(cfg),
    )
    inference_processor = instantiate_inference_processor(cfg)
    images = get_images(cfg)
    params = {
        "save_inference_output": cfg.save_inference if "save_inference" in cfg else True
    }
    if "inference_threshold" in cfg:
        params["inference_threshold"] = cfg.inference_threshold
    compute_func = lambda image: inference_processor.process(
        image,
        **params,
    )
    for image in tqdm(images):
        compute_func(image)


if __name__ == "__main__":
    predict()
