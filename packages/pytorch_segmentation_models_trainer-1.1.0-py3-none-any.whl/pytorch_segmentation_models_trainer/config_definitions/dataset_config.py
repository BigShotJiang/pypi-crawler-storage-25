# -*- coding: utf-8 -*-
"""
/***************************************************************************
 pytorch_segmentation_models_trainer
                              -------------------
        begin                : 2021-07-19
        git sha              : $Format:%H$
        copyright            : (C) 2021 by Philipe Borba - Cartographic Engineer
                                                            @ Brazilian Army
        email                : philipeborba at gmail dot com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ****
"""
from dataclasses import dataclass, field
from typing import List, Optional

from omegaconf import MISSING


@dataclass
class DataLoaderConfig:
    shuffle: bool = True
    num_workers: int = 6
    pin_memory: bool = True
    drop_last: bool = True
    prefetch_factor: str = "${hyperparameters.batch_size}"


@dataclass
class DatasetConfig:
    _target_: str = (
        "pytorch_segmentation_models_trainer.dataset_loader.dataset.SegmentationDataset"
    )
    input_csv_path: str = MISSING
    root_dir: str = MISSING
    gpu_augmentation_list: List = field(default_factory=list)
    augmentation_list: List = field(default_factory=list)
    data_loader: DataLoaderConfig = field(default_factory=DataLoaderConfig)
    image_dtype: str = "uint8"


@dataclass
class RasterPatchDatasetConfig:
    """Configuração para RasterPatchDataset (janela deslizante determinística).

    O dataset varre dois diretórios recursivamente, emparelha imagens e máscaras
    por caminho relativo, e expõe cada patch possível como um item independente.
    O total de items em ``__len__`` é a soma de patches de todas as imagens — não
    o número de imagens.

    Exemplo de YAML::

        train_dataset:
          _target_: pytorch_segmentation_models_trainer.dataset_loader.raster_patch_dataset.RasterPatchDataset
          image_dir: /data/images
          mask_dir: /data/masks
          extension: .tif
          patch_size: 256
          stride: 128
    """

    _target_: str = (
        "pytorch_segmentation_models_trainer.dataset_loader"
        ".raster_patch_dataset.RasterPatchDataset"
    )
    image_dir: str = MISSING
    mask_dir: str = MISSING
    extension: str = ".tif"
    patch_size: int = 256
    stride: int = 128
    mask_extension: Optional[str] = None
    augmentation_list: List = field(default_factory=list)
    data_loader: DataLoaderConfig = field(default_factory=DataLoaderConfig)
    selected_bands: Optional[List[int]] = None
    image_dtype: str = "uint8"
    n_classes: int = 2
    reset_augmentation_function: bool = False


@dataclass
class FrameFieldDatasetConfig(DatasetConfig):
    _target_: str = "pytorch_segmentation_models_trainer.dataset_loader.dataset.FrameFieldSegmentationDataset"
    return_distance_mask: str = "${loss_params.seg_loss_params.use_dist}"
    return_size_mask: str = "${loss_params.seg_loss_params.use_size}"
    image_width: str = "${backbone.input_width}"
    image_height: str = "${backbone.input_height}"
