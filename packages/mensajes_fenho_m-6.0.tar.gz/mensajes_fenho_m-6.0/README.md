# Mensajes

El paquete de mensajería para pruebas de Fernando Martinez, para curso Python.
