"""SFTP / FTP connection helpers for the unified session model."""

import socket
from ftplib import FTP, error_perm
from typing import Any, Optional, Tuple

try:
    import paramiko
except ImportError:
    paramiko = None  # type: ignore


def connect_sftp(
    host: str,
    port: int,
    username: str,
    password: str,
    timeout: int = 25,
) -> Tuple[Optional[Any], Optional["paramiko.SFTPClient"], str]:
    """Return (SSHClient, SFTPClient, error). SSHClient is used instead of a bare Transport
    so host keys and channel setup match `ssh`/OpenSSH more closely (fewer hangs on odd servers).
    """
    if paramiko is None:
        return None, None, "paramiko is not installed (pip install paramiko)"
    if not host.strip():
        return None, None, "Host is empty"
    sock = None
    client = None
    try:
        sock = socket.create_connection((host.strip(), int(port)), timeout=timeout)
        sock.settimeout(float(timeout))
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        uname = (username or "").strip() or None
        pwd = password if password else None
        client.connect(
            host.strip(),
            port=int(port),
            username=uname,
            password=pwd,
            timeout=timeout,
            banner_timeout=timeout,
            auth_timeout=timeout,
            allow_agent=False,
            look_for_keys=False,
            sock=sock,
        )
        sftp = client.open_sftp()
        return client, sftp, ""
    except Exception as exc:
        try:
            if client is not None:
                client.close()
        except Exception:
            pass
        try:
            if sock is not None:
                sock.close()
        except Exception:
            pass
        return None, None, str(exc)


def disconnect_sftp(transport: Any, sftp: Any) -> None:
    try:
        if sftp is not None:
            sftp.close()
    except Exception:
        pass
    try:
        if transport is not None:
            transport.close()
    except Exception:
        pass


def sftp_first_listable_path(sftp: Any, username: str = "") -> str:
    """Return a remote path that exists for SFTP listing (many embedded images lack /root or /home)."""
    u = (username or "").strip()
    candidates = ["/", "/tmp", "/storage", "/sdcard", "/mnt", "/media"]
    if u == "root":
        candidates.insert(0, "/root")
    if u:
        candidates.insert(1, f"/home/{u}")
    for c in candidates:
        try:
            sftp.listdir_attr(c)
            return c
        except Exception:
            continue
    return "/"


def connect_ftp(
    host: str,
    port: int,
    user: str,
    password: str,
    timeout: int = 25,
) -> Tuple[Optional[FTP], str]:
    if not host.strip():
        return None, "Host is empty"
    try:
        ftp = FTP()
        ftp.connect(host.strip(), int(port), timeout=timeout)
        ftp.login(user or "", password or "")
        ftp.set_pasv(True)
        try:
            ftp.encoding = "utf-8"
        except Exception:
            pass
        return ftp, ""
    except Exception as exc:
        return None, str(exc)


def disconnect_ftp(ftp: Optional[FTP]) -> None:
    if ftp is None:
        return
    try:
        ftp.quit()
    except Exception:
        try:
            ftp.close()
        except Exception:
            pass
