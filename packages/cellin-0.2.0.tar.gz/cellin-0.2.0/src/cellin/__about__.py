"""Single-source package version metadata."""

__all__ = ["__version__"]

__version__ = "0.2.0"  # x-release-please-version
