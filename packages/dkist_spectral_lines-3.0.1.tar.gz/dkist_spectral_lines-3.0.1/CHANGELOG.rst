v3.0.1 (2026-04-17)
===================

Misc
----

- Update Bitbucket pipelines to use standardized lint and scan steps. (`#5 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/5>`__)
- Update Bitbucket pipelines to use execute script for standard steps. (`#6 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/6>`__)
- Add code coverage badge to README.rst. (`#7 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/7>`__)
- Update pre-commit hook versions and replace python-reorder-imports with isort. (`#8 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/8>`__)
- Upgrade Read the Docs LTS build image to Ubuntu 24.04, and Read the Docs python build version to 3.13. (`#9 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/9>`__)


v3.0.0 (2024-05-23)
===================

Misc
----

- Update pydantic usages to follow the v2 api. (`#4 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/4>`__)


v2.0.0 (2023-06-29)
===================

Misc
----

- Fix the link to documentation that renders in pypi (`#2 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/2>`__)
- Require python 3.11 (`#3 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/3>`__)


v1.0.0 (2023-04-14)
===================

Features
--------

- Initial functionality for the dkist-spectral-line package. (`#1 <https://bitbucket.org/dkistdc/dkist-spectral-lines/pull-requests/1>`__)
