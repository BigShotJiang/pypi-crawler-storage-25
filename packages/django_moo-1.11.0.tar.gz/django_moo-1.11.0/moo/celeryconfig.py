# -*- coding: utf-8 -*-
"""
Celery configuration for the moo project.
https://docs.celeryq.dev/en/stable/userguide/configuration.html
"""

import os

redis_hostname = os.environ.get("REDIS_HOSTNAME", "redis")
broker_url = os.environ.get("CELERY_BROKER_URL", f"redis://{redis_hostname}:6379/0")
accept_content = ["moojson", "json"]
event_serializer = "moojson"
task_serializer = "moojson"
result_serializer = "moojson"
result_backend = os.environ.get("CELERY_RESULT_BACKEND", f"redis://{redis_hostname}:6379/0")
cache_backend = "default"
beat_scheduler = "django_celery_beat.schedulers:DatabaseScheduler"
task_time_limit = int(os.environ.get("CELERY_TASK_TIME_LIMIT", "3"))
broker_connection_retry_on_startup = True

logging = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {
            "format": "%(asctime)s: %(levelname)s %(message)s",
        },
        "celeryTask": {
            "()": "moo.logging.ShortTaskFormatter",
            "fmt": "%(asctime)s: %(levelname)s %(task_name)s[%(task_id)s]: %(message)s",
        },
        "celeryProcess": {
            "()": "moo.logging.ShortProcessFormatter",
            "fmt": "%(asctime)s: %(levelname)s %(message)s",
        },
    },
    "filters": {
        "celeryTask": {
            "()": "moo.logging.CeleryTaskFilter",
        },
        "celeryProcess": {
            "()": "moo.logging.CeleryProcessFilter",
        },
        "notCelery": {
            "()": "moo.logging.NotCeleryFilter",
        },
    },
    "handlers": {
        "console": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "simple",
            "filters": ["notCelery"],
        },
        "console2": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "celeryTask",
            "filters": ["celeryTask"],
        },
        "console3": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "celeryProcess",
            "filters": ["celeryProcess"],
        },
    },
    "loggers": {
        "": {
            "handlers": ["console", "console2", "console3"],
            "level": "INFO",
            "propagate": False,
        }
    },
}
