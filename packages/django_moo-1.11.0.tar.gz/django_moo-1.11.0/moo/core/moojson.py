"""
Encode/decode MOO JSON.

This module is *also* the registered Celery task serializer (``moojson`` in
``celeryconfig.py``), not just the storage format for ``Property.value``.
Anything that crosses a Celery boundary — task args, kwargs, results,
``invoke_verb`` payloads queued from ``transaction.on_commit`` — round-trips
through ``dumps`` and ``loads``. Two consequences flow from this:

1. ``loads`` runs *before* the worker's :class:`ContextManager` is entered.
   Logic that reads ``ContextManager.get_site()`` must tolerate ``None`` and
   not silently rewrite refs against the default site, or every cross-site
   Object arg gets clobbered to ``$nothing`` on its way into a task.
2. Anything that goes into ``Property.value`` *also* travels through Celery,
   so the two encodings must stay reversible without a site context.
"""

import base64
import json
from datetime import date, datetime, time
from typing import Any

_nothing_cache: dict = {}  # site_id -> Object


def _get_nothing() -> Any:
    """
    Return the $nothing sentinel object for the current site.
    Uses a per-site cache; call clear_nothing_cache() in test teardown.
    """
    from django.conf import settings

    from .code import ContextManager

    site = ContextManager.get_site()
    site_id = site.pk if site is not None else getattr(settings, "SITE_ID", 1)

    if site_id not in _nothing_cache:
        from .models.object import Object

        _nothing_cache[site_id] = Object.global_objects.filter(name="nothing", site_id=site_id).first()
    return _nothing_cache[site_id]


def clear_nothing_cache() -> None:
    """Reset the $nothing object cache (call between tests that reset the DB)."""
    _nothing_cache.clear()


def loads(j):
    from .models.object import Object
    from .models.property import Property
    from .models.verb import Verb

    from .code import ContextManager

    def to_entity(d):
        if len(d) != 1:
            return d
        key = list(d.keys())[0]
        if key == "dt#":
            return datetime.fromisoformat(d[key])
        if key == "d#":
            return date.fromisoformat(d[key])
        if key == "t#":
            return time.fromisoformat(d[key])
        if key == "b#":
            return base64.b64decode(d[key])
        if len(key) >= 2 and key[1] == "#":
            if key[0] == "o":
                try:
                    obj = Object.global_objects.get(pk=int(key[2:]))
                    # Cross-universe filtering only applies when a site context
                    # is active. Outside one — e.g. while Celery deserializes
                    # task args before invoke_verb's ContextManager is entered
                    # — pass the object through unchanged; the task body will
                    # establish its own site.
                    site = ContextManager.get_site()
                    if site is not None and obj.site_id != site.pk:
                        return _get_nothing()
                    return obj
                except Object.DoesNotExist:
                    return _get_nothing()
            elif key[0] == "v":
                try:
                    return Verb.objects.get(pk=int(key[2:]))
                except Verb.DoesNotExist:
                    return _get_nothing()
            elif key[0] == "p":
                try:
                    return Property.objects.get(pk=int(key[2:]))
                except Property.DoesNotExist:
                    return _get_nothing()
        return d

    return json.loads(j, object_hook=to_entity)


def dumps(obj):
    from .models.object import Object
    from .models.property import Property
    from .models.verb import Verb

    def from_entity(o):
        if isinstance(o, datetime):
            return {"dt#": o.isoformat()}
        elif isinstance(o, date):
            return {"d#": o.isoformat()}
        elif isinstance(o, time):
            return {"t#": o.isoformat()}
        elif isinstance(o, Object):
            return {"o#%d" % o.pk: o.name}
        elif isinstance(o, Verb):
            return {"v#%d" % o.pk: o.name()}
        elif isinstance(o, Property):
            return {"p#%d" % o.pk: o.name}
        elif isinstance(o, (bytes, bytearray)):
            return {"b#": base64.b64encode(bytes(o)).decode("ascii")}
        else:
            raise TypeError("Unserializable object {} of type {}".format(obj, type(obj)))

    return json.dumps(obj, default=from_entity)


def filter_nothing(value):
    """
    Remove $nothing sentinel entries from list property values.
    Non-list values are returned unchanged.  Called automatically by
    :meth:`Object.get_property` so callers never see stale object refs.
    """
    nothing = _get_nothing()
    if nothing is None or not isinstance(value, list):
        return value
    nothing_pk = nothing.pk
    return [v for v in value if not (hasattr(v, "pk") and v.pk == nothing_pk)]


def replace_object_refs(j, old_pk, new_obj):
    """
    Return a new JSON string with all ``{"o#<old_pk>": ...}`` references replaced
    by a reference to *new_obj*.  Used at recycle time to substitute ``$nothing``
    for every property that still points at the object being deleted.
    """
    new_ref = {"o#%d" % new_obj.pk: new_obj.name}

    def _replace(data):
        if isinstance(data, dict):
            if len(data) == 1:
                key = list(data.keys())[0]
                if key == "o#%d" % old_pk:
                    return new_ref
            return {k: _replace(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [_replace(item) for item in data]
        return data

    return json.dumps(_replace(json.loads(j)))
