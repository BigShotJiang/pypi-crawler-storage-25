"""Sparkline data builder — compact trend summaries for HTML score cards and CLI output."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from raki.report.history import HistoryEntry

# Direction threshold: 2% (absolute) — changes smaller than this are treated as flat.
_DIRECTION_THRESHOLD = 0.02


@dataclass(frozen=True)
class SparklineData:
    """Trend summary for a single metric, suitable for SVG sparklines and delta badges.

    Attributes:
        metric_name: Canonical metric name (e.g. ``"first_pass_success_rate"``).
        values: Raw metric values in oldest-first order.
        normalized: Values scaled to [0, 1] for SVG rendering.
            When all values are equal, each entry is 0.5.
        delta: Signed difference between the latest and penultimate value
            (``values[-1] - values[-2]``).  ``None`` when fewer than two values exist.
        pct_delta: Relative percentage change: ``abs(delta) / previous * 100``.
            ``None`` when fewer than two values or previous is zero.
        direction: ``"up"`` / ``"down"`` / ``"flat"`` — polarity-aware.
            ``"up"`` means *improving* (green), ``"down"`` means *declining* (red).
        value_direction: ``"up"`` / ``"down"`` / ``"flat"`` — raw value movement.
            ``"up"`` means value increased, ``"down"`` means value decreased,
            regardless of whether higher is better.
    """

    metric_name: str
    values: list[float]
    normalized: list[float]
    delta: float | None
    pct_delta: float | None
    direction: Literal["up", "down", "flat"]
    value_direction: Literal["up", "down", "flat"]


def _normalize(values: list[float]) -> list[float]:
    """Scale *values* to [0, 1].  Returns all 0.5 when all values are equal."""
    if not values:
        return []
    min_val = min(values)
    max_val = max(values)
    if max_val == min_val:
        return [0.5] * len(values)
    span = max_val - min_val
    return [(val - min_val) / span for val in values]


def _direction(delta: float | None, higher_is_better: bool = True) -> Literal["up", "down", "flat"]:
    """Classify *delta* as ``"up"``, ``"down"``, or ``"flat"``.

    When *higher_is_better* is ``False`` (e.g. ``rework_cycles``, ``cost_efficiency``),
    the polarity is flipped: a negative delta (decrease) is an improvement and maps
    to ``"up"``, while a positive delta (increase) maps to ``"down"``.
    """
    if delta is None or abs(delta) <= _DIRECTION_THRESHOLD:
        return "flat"
    is_increase = delta > 0
    improving = is_increase if higher_is_better else not is_increase
    return "up" if improving else "down"


def build_sparkline_data(
    entries: list[HistoryEntry],
    *,
    manifest: str | None = None,
    config_hash: str | None = None,
    n: int = 10,
    metric_polarity: dict[str, bool] | None = None,
) -> dict[str, SparklineData]:
    """Build a mapping of metric_name → :class:`SparklineData` from history entries.

    Args:
        entries: Raw history entries in any order.
        manifest: When set, only entries whose ``manifest`` field matches are included.
        config_hash: When set, only entries whose ``config_hash`` field matches are included.
        n: Maximum number of history entries to consider (most recent N entries,
            ordered by timestamp after filtering).
        metric_polarity: Optional mapping of metric name → ``higher_is_better`` flag.
            When a metric maps to ``False`` (e.g. ``rework_cycles``, ``cost_efficiency``),
            direction polarity is flipped: a decrease is classified as ``"up"``
            (improving) and an increase as ``"down"`` (declining).
            Metrics absent from this dict default to ``higher_is_better=True``.

    Returns:
        A dict keyed by metric name.  Metrics that do not appear in the filtered
        entries are absent from the result.
    """
    # --- Filter ---
    filtered: list[HistoryEntry] = []
    for entry in entries:
        if manifest is not None and entry.manifest != manifest:
            continue
        if config_hash is not None and entry.config_hash != config_hash:
            continue
        filtered.append(entry)

    # --- Sort by timestamp (oldest first) and cap to N most recent ---
    filtered.sort(key=lambda entry: entry.timestamp)
    if len(filtered) > n:
        filtered = filtered[-n:]

    # --- Collect per-metric values ---
    metric_values: dict[str, list[float]] = {}
    for entry in filtered:
        for metric_name, value in entry.metrics.items():
            metric_values.setdefault(metric_name, []).append(value)

    # --- Build SparklineData per metric ---
    result: dict[str, SparklineData] = {}
    for metric_name, values in metric_values.items():
        delta: float | None = None
        if len(values) >= 2:
            delta = values[-1] - values[-2]

        hib: bool = True
        if metric_polarity is not None:
            hib = metric_polarity.get(metric_name, True)

        pct_delta: float | None = None
        val_dir: Literal["up", "down", "flat"] = "flat"
        if delta is not None:
            prev = values[-2]
            if prev != 0:
                pct_delta = abs(delta) / abs(prev) * 100
            # prev == 0: pct_delta stays None (infinite relative change)
            if abs(delta) > _DIRECTION_THRESHOLD:
                val_dir = "up" if delta > 0 else "down"

        result[metric_name] = SparklineData(
            metric_name=metric_name,
            values=values,
            normalized=_normalize(values),
            delta=delta,
            pct_delta=pct_delta,
            direction=_direction(delta, higher_is_better=hib),
            value_direction=val_dir,
        )

    return result
