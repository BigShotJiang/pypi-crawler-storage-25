"""Cohort analysis — date-based session split and multi-cohort grouping.

This module provides functions to:

- Split an EvalDataset into two temporal cohorts (before/after a cutoff date)
  and compute a DiffReport comparing their aggregate metrics.
- Group sessions by an arbitrary SessionMeta field (``group_by_field``).
- Inject cohort tags from a manifest into grouped sessions
  (``inject_cohort_tags``).
- Produce ``CohortSummary`` objects for multi-cohort Rich Table rendering
  and HTML report generation.

Cohort mode does NOT perform session-level matching (sessions are different
in each cohort by construction).  The MatchResult uses empty sets for
matched_ids/new_ids/dropped_ids, and has_session_data=False prevents
print_diff_summary() from attempting per-session verdict transitions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from raki.model.dataset import EvalSample
from raki.report.diff import DiffReport, MatchResult, compute_deltas


def split_by_date(
    samples: list[EvalSample],
    cutoff: datetime,
) -> tuple[list[EvalSample], list[EvalSample]]:
    """Split samples into before/after cohorts based on session start date.

    Sessions started before ``cutoff`` belong to the baseline cohort.
    Sessions started on or after ``cutoff`` belong to the compare cohort.

    Parameters
    ----------
    samples:
        Flat list of EvalSample instances to partition.
    cutoff:
        UTC-aware datetime.  Sessions with ``started_at < cutoff`` are
        placed in the *before* list; sessions with ``started_at >= cutoff``
        are placed in the *after* list.

    Returns
    -------
    tuple[list[EvalSample], list[EvalSample]]
        A (before, after) tuple — each is a plain Python list of EvalSample.
    """
    before: list[EvalSample] = []
    after: list[EvalSample] = []
    for sample in samples:
        if sample.session.started_at < cutoff:
            before.append(sample)
        else:
            after.append(sample)
    return before, after


def _reaggregate_from_samples(samples: list[EvalSample]) -> dict[str, float | None]:
    """Run operational metrics on a list of samples and return aggregate scores.

    Uses MetricsEngine with ALL_OPERATIONAL (no LLM calls).  Returns an
    empty dict when *samples* is empty.
    """
    if not samples:
        return {}

    from raki.metrics import MetricsEngine
    from raki.metrics.operational import ALL_OPERATIONAL
    from raki.metrics.protocol import MetricConfig
    from raki.model.dataset import EvalDataset

    dataset = EvalDataset(samples=samples)
    config = MetricConfig()
    engine = MetricsEngine(list(ALL_OPERATIONAL), config=config)
    report = engine.run(dataset, skip_judge=True)
    return report.aggregate_scores


def build_cohort_diff_report(
    before_samples: list[EvalSample],
    after_samples: list[EvalSample],
    before_label: str,
    after_label: str,
) -> DiffReport:
    """Build a DiffReport by comparing metrics across two temporal cohorts.

    Runs MetricsEngine on each cohort independently, reaggregates scores,
    and produces a DiffReport suitable for ``print_diff_summary()``.

    The resulting DiffReport has:
    - ``has_session_data=False`` — suppresses per-session verdict transitions.
    - ``MatchResult`` with empty matched/new/dropped id sets and cohort
      sizes in ``baseline_total`` / ``compare_total``.

    Parameters
    ----------
    before_samples:
        Sessions from the baseline (before-cutoff) cohort.
    after_samples:
        Sessions from the compare (after-cutoff) cohort.
    before_label:
        Human-readable label for the baseline cohort (used as ``baseline_run_id``).
    after_label:
        Human-readable label for the compare cohort (used as ``compare_run_id``).

    Returns
    -------
    DiffReport
        Fully populated diff report.  Metric deltas are empty when either
        cohort produces no scores (i.e., is empty).
    """
    before_scores = _reaggregate_from_samples(before_samples)
    after_scores = _reaggregate_from_samples(after_samples)

    deltas = compute_deltas(before_scores, after_scores)

    match_result = MatchResult(
        matched_ids=set(),
        new_ids=set(),
        dropped_ids=set(),
        baseline_total=len(before_samples),
        compare_total=len(after_samples),
    )

    return DiffReport(
        baseline_run_id=before_label,
        compare_run_id=after_label,
        match_result=match_result,
        deltas=deltas,
        improvements=[],
        regressions=[],
        has_session_data=False,
    )


@dataclass
class CohortSummary:
    """Aggregate summary for a single cohort in a multi-cohort comparison.

    Holds the cohort label, the samples belonging to that cohort, and the
    aggregate metric scores produced by the MetricsEngine run on those samples.

    Attributes
    ----------
    label:
        Human-readable cohort identifier (e.g. ``"soda"``, ``"bridge"``,
        ``"before-2026-04-01"``).
    samples:
        EvalSample instances belonging to this cohort.
    scores:
        Aggregate metric scores from the operational MetricsEngine run on
        ``samples``.  Empty dict when ``samples`` is empty.
    """

    label: str
    samples: list[EvalSample] = field(default_factory=list)
    scores: dict[str, float | None] = field(default_factory=dict)


def group_by_field(
    samples: list[EvalSample],
    field_name: str,
) -> dict[str | None, list[EvalSample]]:
    """Group EvalSample instances by the value of a SessionMeta field.

    Parameters
    ----------
    samples:
        Flat list of EvalSample instances to group.
    field_name:
        Name of a field on ``SessionMeta`` to group by.  Supported fields
        include ``"cohort"``, ``"orchestrator"``, ``"provider"``,
        ``"model_id"``, and any other ``str | None`` attribute on
        ``SessionMeta``.

    Returns
    -------
    dict[str | None, list[EvalSample]]
        Ordered dict mapping each distinct field value (or ``None``) to the
        list of samples with that value.  Insertion order reflects the order
        in which distinct values first appeared in ``samples``.

    Raises
    ------
    AttributeError
        If ``field_name`` does not exist on ``SessionMeta``.
    """
    groups: dict[str | None, list[EvalSample]] = {}
    for sample in samples:
        value = getattr(sample.session, field_name)
        if value not in groups:
            groups[value] = []
        groups[value].append(sample)
    return groups


def inject_cohort_tags(
    groups: dict[str | None, list[EvalSample]],
    cohort_tags: list[str],
) -> dict[str, list[EvalSample]]:
    """Re-label grouped sessions with manifest-defined cohort tags.

    Replaces the automatically-derived group keys (field values) with the
    ordered human-readable labels from ``cohort_tags``.  The first label in
    ``cohort_tags`` is assigned to the first group (by insertion order), the
    second label to the second group, and so on.

    When ``cohort_tags`` is shorter than the number of groups, remaining
    groups keep their original string key (or ``"None"`` when the key is
    ``None``).  When ``cohort_tags`` is longer than the number of groups, the
    extra tags are silently ignored.

    Parameters
    ----------
    groups:
        Ordered dict produced by ``group_by_field()``.
    cohort_tags:
        Ordered list of human-readable labels from ``EvalManifest.cohort_tags``.

    Returns
    -------
    dict[str, list[EvalSample]]
        New ordered dict with string keys replacing the original field values.
        The relative group order is preserved.
    """
    relabeled: dict[str, list[EvalSample]] = {}
    tags_iter = iter(cohort_tags)
    for original_key, group_samples in groups.items():
        tag = next(tags_iter, None)
        label = (
            tag if tag is not None else (str(original_key) if original_key is not None else "None")
        )
        relabeled[label] = group_samples
    return relabeled


def build_multi_cohort_summaries(
    groups: dict[str, list[EvalSample]],
) -> list[CohortSummary]:
    """Build CohortSummary objects for each group in a multi-cohort comparison.

    Runs the operational MetricsEngine on each group independently and
    collects aggregate scores into ``CohortSummary`` instances.

    Parameters
    ----------
    groups:
        Ordered dict mapping cohort labels to lists of EvalSample instances.
        Typically produced by ``group_by_field()`` + ``inject_cohort_tags()``.

    Returns
    -------
    list[CohortSummary]
        One ``CohortSummary`` per group, in the same order as ``groups``.
    """
    summaries: list[CohortSummary] = []
    for label, group_samples in groups.items():
        scores = _reaggregate_from_samples(group_samples)
        summaries.append(CohortSummary(label=label, samples=group_samples, scores=scores))
    return summaries
