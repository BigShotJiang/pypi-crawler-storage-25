# Comparing Runs

Use `raki report --diff` to compare two evaluation runs side by side. This workflow answers the question "did this change improve things?" — quantified, with per-session detail.

## Quick start

This section walks through a complete before/after comparison in four commands.

### Step 1: Evaluate pre-change sessions

To evaluate the pre-change sessions, run the following command:

```bash
uv run raki run -m manifests/before.yaml -o results/ --include-sessions
```

RAKI writes `results/raki-report-<timestamp>.json`. Rename or copy it to a stable path so you can reference it later:

```bash
cp results/raki-report-*.json results/before.json
```

### Step 2: Evaluate post-change sessions

To evaluate the post-change sessions, run the following command:

```bash
uv run raki run -m manifests/after.yaml -o results/ --include-sessions
```

Copy the new report to a stable path:

```bash
cp results/raki-report-*.json results/after.json
```

### Step 3: Compare the two reports

To compare the two reports, run the following command:

```bash
uv run raki report --diff results/before.json results/after.json
```

Example output:

```
Comparing raki-20260501T100000 → raki-20260512T140000
Matched: 12/14 sessions (2 new)

  First-pass success rate  0.36 → 0.67  (+0.31)  ▲
  Rework cycles            0.72 → 0.33  (-0.39)  ▲
  Cost / session           $12.30 → $8.50  (-$3.80)  ▲
  Severity score           0.45 → 0.22  (-0.23)  ▲

Improvements: 4 sessions (fail→pass: 3, rework→pass: 1)
Regressions:  1 session (pass→rework: 1)
```

### Step 4: Generate an HTML diff report

To generate an HTML diff report, add `--html`:

```bash
uv run raki report --diff results/before.json results/after.json --html diff-report.html
```

The HTML report is a self-contained file with a dark theme. Open it in any browser.

### Step 5: Gate CI on regressions

To fail CI when metrics regress, add `--fail-on-regression`:

```bash
uv run raki report --diff results/baseline.json results/current.json --fail-on-regression
```

RAKI exits with code 3 when any metric regresses beyond the 2% noise margin. See [CI Integration](ci-integration.md) for exit code reference.

## Reading the diff output

### Header

The first line identifies the two runs being compared:

```
Comparing raki-20260501T100000 → raki-20260512T140000
```

The run IDs come from the report timestamps. The left-hand run is the baseline; the right-hand run is the comparison target.

### Judge config warnings

When the two reports used different judge providers or models, RAKI prints a warning before the metric table:

```
Warning: judge config differs between runs
  Baseline:  vertex-anthropic / claude-sonnet-4-6
  Compare:   anthropic / claude-opus-4
```

Analytical metric deltas (faithfulness, answer relevancy, context precision, context recall) may not be meaningful when the judge changed. Operational metric deltas are unaffected.

When only one report used a judge, RAKI warns that analytical metrics are missing from the other run and omits those metric rows from the diff.

### Agent model warnings

When the sessions in each report used different agent models, RAKI prints a warning noting that the model changed. This is informational — the diff proceeds, but metric differences may reflect model differences as much as prompt or config differences.

### Coverage line

The coverage line shows how many sessions were matched by `session_id`:

```
Matched: 12/14 sessions (2 new)
```

- **Matched**: sessions present in both reports, compared directly
- **New**: sessions present only in the comparison report
- **Dropped**: sessions present only in the baseline report

Aggregate metric deltas are computed from matched sessions only. New and dropped sessions are counted but do not affect the deltas.

### Metric deltas

Each metric is shown with its baseline value, comparison value, numeric delta, and direction indicator:

```
  First-pass success rate  0.36 → 0.67  (+0.31)  ▲
  Rework cycles            0.72 → 0.33  (-0.39)  ▲
  Cost / session           $12.30 → $8.50  (-$3.80)  ▲
  Severity score           0.45 → 0.22  (-0.23)  ▲
```

The direction indicator (`▲` / `▼` / `=`) respects each metric's `higher_is_better` setting:

| Indicator | Meaning |
|-----------|---------|
| `▲` | Improvement (value moved in the desired direction) |
| `▼` | Regression (value moved in the wrong direction) |
| `=` | No change |

For example, a decrease in `rework_cycles` is shown as `▲` because lower is better for that metric.

### Session transitions

When both reports were generated with `--include-sessions`, RAKI groups sessions by verdict change:

```
Improvements: 4 sessions (fail→pass: 3, rework→pass: 1)
Regressions:  1 session (pass→rework: 1)
```

Sessions with unchanged verdicts are not listed. Each transition line names the session ID and the verdict change so you can investigate specific sessions.

## Producing reports to compare

### Manifest scoping

Create one manifest per session set to scope each evaluation run to the correct sessions:

```yaml
# manifests/before.yaml — sessions from before the change
sessions:
  paths:
    - sessions/2026-04-01/
    - sessions/2026-04-15/
```

```yaml
# manifests/after.yaml — sessions from after the change
sessions:
  paths:
    - sessions/2026-05-01/
    - sessions/2026-05-12/
```

Alternatively, use a single manifest that covers all sessions and run it twice — once pointing at the before session directories and once at the after directories.

### The --include-sessions flag

Pass `--include-sessions` to both evaluation runs to enable per-session verdict transitions in the diff output. Without it, RAKI still shows aggregate metric deltas but cannot report which individual sessions improved or regressed.

To evaluate with per-session data, run the following command:

```bash
uv run raki run -m manifests/before.yaml -o results/ --include-sessions
```

### Consistent judge configuration

Verify that both reports use the same judge configuration (provider and model) when comparing analytical metrics. RAKI warns when they differ, but does not block the comparison. To ensure consistency, pin the judge config in both manifests:

```yaml
judge:
  provider: vertex-anthropic
  model: claude-sonnet-4-6
```

## When to use --diff vs raki trends

Both `raki report --diff` and `raki trends` help you understand whether evaluation quality is improving. They answer different questions.

| Situation | Use |
|-----------|-----|
| Before/after a specific prompt change | `raki report --diff` |
| Before/after a config or model change | `raki report --diff` |
| Monitoring quality over many runs | `raki trends` |
| Checking if a PR introduces a regression | `raki report --diff --fail-on-regression` |
| Weekly or monthly trajectory review | `raki trends` |
| Identifying a regression's first occurrence | `raki trends` |

**`raki report --diff`** is a point-in-time comparison between two specific evaluation runs. Use it when you have a concrete before/after hypothesis and want to confirm that a change had the intended effect.

**`raki trends`** shows metric trajectories over many runs. Use it for ongoing monitoring — for example, to verify that quality is improving sprint over sprint, or to spot a gradual degradation that no single diff would catch.

See the `raki trends --help` output for trajectory options such as `--since`, `--last`, and `--metrics`.

## Trends report

`raki trends` can generate a self-contained HTML report with SVG dot-chart timelines for each metric.

### Generating the HTML report

```bash
raki trends --html trends.html
```

This writes a standalone HTML file — no external dependencies, dark-themed — to `trends.html`. Open it in any browser.

Combine with time filters to narrow the chart range:

```bash
raki trends --since 2026-03-01 --html trends-q1.html
```

### Saving JSON output to a file

Use `--json -o FILE` to write the JSON output to a file instead of stdout:

```bash
raki trends --json -o trends.json
```

### Chart anatomy

Each metric card in the HTML report shows:

- **Dot chart**: one dot per evaluation run, left-to-right in chronological order. Higher values map to higher dot positions for `higher_is_better` metrics; lower values do for `lower_is_better` metrics.
- **Zone colour**: the dot colour reflects the current (latest) value — green (on target), yellow (below threshold), or red (off target) — using the same thresholds as the run report.
- **Config-break marker**: a dashed vertical line indicates runs where the evaluation configuration (`config_hash`) changed. Metric shifts near these markers may reflect a configuration change rather than a true quality change.
- **Delta badge**: the signed change from oldest to newest value in the visible window (e.g. `+5%`, `-$0.30`, or `—` when fewer than two runs exist).
- **Direction indicator**: `▲ improving`, `▼ declining`, `= stable`, or `— n/a` based on the last three runs.

### Tier grouping

Metrics are grouped by tier in the same order as the CLI table:

| Tier | Metrics |
|------|---------|
| Operational | First-pass success rate, Rework cycles, Cost / session, … |
| Knowledge | Knowledge gap rate, Knowledge miss rate |
| Analytical | Faithfulness, Answer relevancy, Context precision, Context recall |

## Tips and caveats

- **Reports without `--include-sessions`** still show aggregate metric deltas. Only per-session verdict transitions (improvements and regressions) require session data in both reports.

- **New and dropped sessions** are displayed in the coverage line and counted separately. They do not affect aggregate metric deltas, which are computed from matched sessions only.

- **Judge config mismatches** trigger a warning but do not block comparison. Operational metric deltas remain meaningful regardless of judge config. Analytical metric deltas may reflect judge differences rather than true quality changes when the judge changed between runs.

- **Exit codes** from `raki report --diff`:

  | Code | Meaning |
  |------|---------|
  | 0 | No regressions detected |
  | 3 | Regression detected (`--fail-on-regression`) |
  | 4 | Regression and threshold violation |

  See [CI Integration](ci-integration.md) for the full exit code reference.

- **Noise margin**: `--fail-on-regression` uses a 2% noise margin. Metric changes smaller than 2% are treated as flat and do not trigger a regression exit.

## Cohort comparison with `raki cohort`

`raki cohort` compares sessions split into temporal cohorts or grouped by a metadata field, without requiring separate pre-built report files. It is useful for answering "did quality change before vs. after this date?" or "how does quality differ across orchestrators?" directly from session directories.

### Quick start — temporal split

```bash
uv run raki cohort sessions/ --since 2026-04-01
```

This splits all sessions under `sessions/` into two temporal cohorts:

- **Baseline cohort**: sessions with `started_at` before `2026-04-01`
- **Compare cohort**: sessions with `started_at` on or after `2026-04-01`

Operational metrics are computed for each cohort independently and a diff summary is printed.

### Quick start — multi-cohort field grouping

```bash
uv run raki cohort sessions/ --group-by orchestrator
```

This groups all sessions by the `orchestrator` field from their session metadata and produces a side-by-side comparison table showing metric scores for each distinct orchestrator value:

```
  Multi-cohort comparison — grouped by orchestrator
┏━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━┳━━━━━━━┓
┃                          ┃  soda  ┃ bridge ┃ alcove┃
┃ Metric                   ┃    n=5 ┃    n=4 ┃   n=3 ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━╇━━━━━━━┩
│ First-pass success rate  │   0.80 │   0.50 │  0.33 │
│ Rework cycles            │    0.2 │    1.0 │   1.7 │
│ Cost / session           │  $5.20 │  $8.10 │ $12.40│
…
```

When two groups are produced, a standard diff summary is shown instead.

### Options

| Option | Description |
|--------|-------------|
| `--since DATE` | Split date (YYYY-MM-DD). Sessions before this date form the baseline cohort. Mutually exclusive with `--group-by`. |
| `--group-by FIELD` | Group by a session metadata field: `orchestrator`, `model_id`, `provider`, or `cohort`. Mutually exclusive with `--since`. |
| `--until DATE` | *(optional)* Upper bound for the compare cohort. Sessions on or after this date are excluded from the compare cohort. |
| `--html FILE` | Write an HTML diff report (2 cohorts) or multi-cohort report (N cohorts) to `FILE`. |
| `--json` | Output machine-readable data as JSON on stdout. |
| `--fail-on-regression` | Exit with code 3 when any metric regresses between cohorts. |
| `-q / --quiet` | CI mode — suppress verbose output. |
| `--adapter NAME` | Force a specific session adapter (default: auto-detect). |

### Filtering the compare cohort with --until

Use `--until` to restrict the compare cohort to a specific time window:

```bash
uv run raki cohort sessions/ --since 2026-04-01 --until 2026-05-01
```

This compares sessions from before April 2026 against sessions in April 2026 only, excluding any sessions from May onwards.

### Grouping by metadata field

Use `--group-by` to split sessions by a SessionMeta field rather than by date:

```bash
# Compare across orchestrators
uv run raki cohort sessions/ --group-by orchestrator

# Compare across model versions
uv run raki cohort sessions/ --group-by model_id

# Compare across LLM providers
uv run raki cohort sessions/ --group-by provider
```

`--group-by` and `--since` are **mutually exclusive** — exactly one is required.

When exactly **two groups** are produced, a standard diff summary is shown (identical to the `--since` output). When **three or more groups** are produced, a side-by-side Rich Table is rendered.

### Grouping by cohort tag

The `cohort` field in session metadata is set when sessions are loaded from a manifest that defines `cohort_tags`:

```yaml
# raki.yaml
cohort_tags:
  - v1-prompt
  - v2-prompt
```

Sessions can be tagged with `--group-by cohort` when the session `cohort` field is populated. Without explicit tagging, `--group-by cohort` will report an error with a helpful suggestion.

### Generating an HTML report

```bash
# Temporal split — diff HTML report
uv run raki cohort sessions/ --since 2026-04-01 --html cohort-diff.html

# Field grouping — multi-cohort HTML report
uv run raki cohort sessions/ --group-by orchestrator --html multi-cohort.html
```

For 2 cohorts, a diff HTML report is written. For 3+ cohorts, a multi-cohort comparison table HTML report is written.

### Machine-readable output

```bash
# Temporal split — DiffReport JSON
uv run raki cohort sessions/ --since 2026-04-01 --json

# Field grouping — list of cohort summaries
uv run raki cohort sessions/ --group-by orchestrator --json
```

For 2 cohorts, the `DiffReport` is serialized to JSON. For 3+ cohorts, a list of `{label, session_count, scores}` objects is output.

### CI gate

```bash
uv run raki cohort sessions/ --since 2026-04-01 --fail-on-regression
```

Exits with code 3 when any metric regresses between cohorts. Use this in CI to block merges that degrade evaluation quality.

### Small-n warning

When either cohort has fewer than 10 sessions, `raki cohort` prints a warning to stderr:

```
Warning: small cohort size — baseline (3 sessions), compare (2 sessions).
Results may not be statistically reliable (fewer than 10 sessions).
```

The comparison proceeds, but aggregate metric deltas may not be statistically meaningful.

### Error conditions

| Condition | Exit code | Message |
|-----------|-----------|---------|
| Either cohort is empty (`--since`) | 1 | `No sessions found in the 'before'/'after' cohort` |
| Only one group produced (`--group-by`) | 1 | `--group-by produced only 1 group` |
| `--group-by cohort` with no cohort tags | 1 | `all sessions have cohort=None` |
| No sessions loaded (all failed) | 1 | `report has no sample_results` |
| Both `--since` and `--group-by` given | 2 | `mutually exclusive` |
| Neither `--since` nor `--group-by` given | 2 | `required` |
| Sessions path does not exist | 2 | Click path error |

### Differences from `raki report --diff`

| Feature | `raki report --diff` | `raki cohort` |
|---------|---------------------|----------------|
| Input | Two pre-built report JSON files | Session directories |
| Session matching | Matched by `session_id` | No session matching (temporal split) |
| Per-session transitions | Yes (improvements / regressions) | No |
| Analytical metrics | Yes (if judge was used) | No (operational only) |
| Split mechanism | Explicit before/after reports | Date-based `--since` or field-based `--group-by` |
| N-way comparison | No (always 2 runs) | Yes (N cohorts via `--group-by`) |

Use `raki cohort` when you want a quick before/after or cross-orchestrator comparison from a single session directory, without needing to manage separate report files.

## Inline trend indicators (Tech Preview)

> **Tech Preview** — this feature is experimental and may change in future releases.

When `raki run` has prior history for the same manifest (stored in `.raki/history.jsonl`), the HTML report score cards display inline trend indicators next to each metric value:

```
47%  ▲ 12%      (value increased 12% vs last run — green = improving)
0.7  ▼ 13%      (value decreased 13% vs last run — green = improving for lower-is-better)
1576.3s  ▲ 14%  (value increased 14% — red = declining for lower-is-better)
```

### How it works

- The **arrow** (▲/▼) shows the raw value direction: ▲ = value increased, ▼ = value decreased
- The **color** reflects whether the change is good or bad: green = improving, red = declining (based on each metric's `higher_is_better` flag)
- The **percentage** is the relative change vs the previous run: `abs(current - previous) / previous × 100`
- Changes below 2% are treated as flat and hidden
- Changes above 999% are capped to `>999%`
- When no prior history exists (first run), no indicators appear

### Requirements

- At least two history entries for the same manifest filename
- History is written automatically by `raki run` to `.raki/history.jsonl`
- Use `--no-history` to suppress history writes; `--force` to bypass duplicate detection

### Sticky nav context

When scrolling the HTML report, the navigation bar pins to the top and reveals the project name, run ID, and session count — providing context when the header scrolls out of view. This appears with a CSS transition and disappears when scrolling back to the top.
