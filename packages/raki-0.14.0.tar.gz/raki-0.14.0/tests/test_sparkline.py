"""Tests for SparklineData dataclass and build_sparkline_data() factory — raki.report.sparkline."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from conftest import make_history_entry
from raki.report.sparkline import SparklineData, build_sparkline_data


class TestSparklineDataClass:
    def test_fields_present(self) -> None:
        """SparklineData must expose metric_name, values, normalized, delta, direction."""
        sd = SparklineData(
            metric_name="first_pass_success_rate",
            values=[0.6, 0.7, 0.8],
            normalized=[0.0, 0.5, 1.0],
            delta=0.1,
            pct_delta=10.0,
            direction="up",
            value_direction="up",
        )
        assert sd.metric_name == "first_pass_success_rate"
        assert sd.values == [0.6, 0.7, 0.8]
        assert sd.normalized == [0.0, 0.5, 1.0]
        assert sd.delta == pytest.approx(0.1)
        assert sd.direction == "up"

    def test_direction_literal_values(self) -> None:
        """direction must be one of 'up', 'down', 'flat'."""
        for d in ("up", "down", "flat"):
            sd = SparklineData(
                metric_name="x",
                values=[0.5],
                normalized=[0.5],
                delta=None,
                pct_delta=None,
                direction=d,  # type: ignore[arg-type]
                value_direction="flat",
            )
            assert sd.direction == d

    def test_delta_can_be_none(self) -> None:
        """delta must accept None when insufficient history."""
        sd = SparklineData(
            metric_name="x",
            values=[0.5],
            normalized=[0.5],
            delta=None,
            pct_delta=None,
            direction="flat",
            value_direction="flat",
        )
        assert sd.delta is None


class TestBuildSparklineData:
    def test_returns_dict_keyed_by_metric(self) -> None:
        """build_sparkline_data returns dict[str, SparklineData]."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.80},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.85},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        assert "first_pass_success_rate" in result
        assert isinstance(result["first_pass_success_rate"], SparklineData)

    def test_values_sorted_oldest_first(self) -> None:
        """values list must be sorted oldest-first."""
        entries = [
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.9},
                timestamp=datetime(2026, 1, 3, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.7},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.values[0] == pytest.approx(0.7)
        assert sd.values[-1] == pytest.approx(0.9)

    def test_delta_is_latest_minus_penultimate(self) -> None:
        """delta must be values[-1] - values[-2] (latest vs previous)."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.70},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.80},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r3",
                metrics={"first_pass_success_rate": 0.85},
                timestamp=datetime(2026, 1, 3, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.delta == pytest.approx(0.05)

    def test_delta_none_when_single_value(self) -> None:
        """delta must be None when only one value exists."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.80},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.delta is None

    def test_direction_up_when_improvement(self) -> None:
        """direction='up' when delta > 2% threshold."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.70},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.75},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.direction == "up"

    def test_direction_down_when_decline(self) -> None:
        """direction='down' when delta < -2% threshold."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.80},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.75},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.direction == "down"

    def test_direction_flat_when_within_threshold(self) -> None:
        """direction='flat' when |delta| <= 2% threshold."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.800},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.801},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.direction == "flat"

    def test_n_cap_limits_values(self) -> None:
        """build_sparkline_data respects the n-cap, keeping the N most recent entries."""
        entries = [
            make_history_entry(
                run_id=f"r{idx}",
                metrics={"first_pass_success_rate": float(idx) / 10},
                timestamp=datetime(2026, 1, idx, tzinfo=timezone.utc),
            )
            for idx in range(1, 16)
        ]
        result = build_sparkline_data(entries, n=5)
        sd = result["first_pass_success_rate"]
        assert len(sd.values) == 5

    def test_filters_by_manifest(self) -> None:
        """build_sparkline_data must filter entries by manifest name."""
        entries = [
            make_history_entry(
                run_id="r1",
                manifest="project-a.yaml",
                metrics={"first_pass_success_rate": 0.70},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                manifest="project-b.yaml",
                metrics={"first_pass_success_rate": 0.90},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries, manifest="project-a.yaml")
        sd = result["first_pass_success_rate"]
        assert len(sd.values) == 1
        assert sd.values[0] == pytest.approx(0.70)

    def test_filters_by_config_hash(self) -> None:
        """build_sparkline_data must filter entries by config_hash."""
        entries = [
            make_history_entry(
                run_id="r1",
                config_hash="abc123",
                metrics={"first_pass_success_rate": 0.70},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                config_hash="def456",
                metrics={"first_pass_success_rate": 0.90},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries, config_hash="abc123")
        sd = result["first_pass_success_rate"]
        assert len(sd.values) == 1
        assert sd.values[0] == pytest.approx(0.70)

    def test_normalized_range_zero_to_one(self) -> None:
        """normalized values must be in [0, 1] range (min=0.0, max=1.0)."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.6},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r2",
                metrics={"first_pass_success_rate": 0.8},
                timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc),
            ),
            make_history_entry(
                run_id="r3",
                metrics={"first_pass_success_rate": 1.0},
                timestamp=datetime(2026, 1, 3, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        assert sd.normalized[0] == pytest.approx(0.0)
        assert sd.normalized[-1] == pytest.approx(1.0)

    def test_normalized_flat_when_all_equal(self) -> None:
        """normalized must be all 0.5 when all values are equal."""
        entries = [
            make_history_entry(
                run_id=f"r{idx}",
                metrics={"first_pass_success_rate": 0.80},
                timestamp=datetime(2026, 1, idx, tzinfo=timezone.utc),
            )
            for idx in range(1, 4)
        ]
        result = build_sparkline_data(entries)
        sd = result["first_pass_success_rate"]
        for norm_val in sd.normalized:
            assert norm_val == pytest.approx(0.5)

    def test_empty_entries_returns_empty_dict(self) -> None:
        """Empty history returns empty dict."""
        result = build_sparkline_data([])
        assert result == {}

    def test_multiple_metrics(self) -> None:
        """Multiple metrics in history produce multiple SparklineData entries."""
        entries = [
            make_history_entry(
                run_id="r1",
                metrics={"first_pass_success_rate": 0.80, "rework_cycles": 0.5},
                timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            ),
        ]
        result = build_sparkline_data(entries)
        assert "first_pass_success_rate" in result
        assert "rework_cycles" in result
