"""Tests for HTML trend report — TrendChartData, build_trends_template_data(),
write_trends_html_report(), and build_summary_sentence()."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from conftest import make_history_entry
from raki.report.trends import (
    MetricTrend,
    build_trends_template_data,
    compute_all_trends,
    compute_trend,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_trend(
    metric_name: str = "first_pass_success_rate",
    values: list[tuple[datetime, float]] | None = None,
    delta: float | None = None,
) -> MetricTrend:
    """Build a MetricTrend with optional values for testing."""
    return compute_trend(
        [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={metric_name: val},
            )
            for idx, (_, val) in enumerate(values or [])
        ],
        metric_name,
    )


def _make_entries_with_hashes(
    hashes: list[str],
    metric_name: str = "rework_cycles",
) -> list:
    """Build history entries with distinct config_hash values."""
    from raki.report.history import HistoryEntry

    return [
        HistoryEntry(
            run_id=f"run-{idx}",
            timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
            sessions_count=5,
            metrics={metric_name: float(idx + 1)},
            config_hash=h,
        )
        for idx, h in enumerate(hashes)
    ]


# ---------------------------------------------------------------------------
# Task 1: TrendChartData dataclass
# ---------------------------------------------------------------------------


class TestTrendChartDataFields:
    def test_trend_chart_data_has_dot_positions(self) -> None:
        """TrendChartData must expose dot_positions."""
        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.70 + idx * 0.05},
            )
            for idx in range(3)
        ]
        trend = compute_trend(entries, "first_pass_success_rate")
        chart_data_list = build_trends_template_data([trend], entries)
        assert len(chart_data_list) == 1
        cd = chart_data_list[0]
        assert hasattr(cd, "dot_positions")

    def test_trend_chart_data_has_zone_color(self) -> None:
        """TrendChartData must expose zone_color."""
        entries = [make_history_entry(metrics={"first_pass_success_rate": 0.90})]
        trend = compute_trend(entries, "first_pass_success_rate")
        cd_list = build_trends_template_data([trend], entries)
        assert hasattr(cd_list[0], "zone_color")

    def test_trend_chart_data_has_config_break_indices(self) -> None:
        """TrendChartData must expose config_break_indices as a list."""
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        assert hasattr(cd_list[0], "config_break_indices")
        assert isinstance(cd_list[0].config_break_indices, list)

    def test_trend_chart_data_has_delta_badge(self) -> None:
        """TrendChartData must expose delta_badge."""
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        assert hasattr(cd_list[0], "delta_badge")


# ---------------------------------------------------------------------------
# Task 1: SVG coordinates
# ---------------------------------------------------------------------------


class TestDotPositions:
    def test_dot_count_matches_value_count(self) -> None:
        """dot_positions length must equal number of values in the trend."""
        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"rework_cycles": float(idx + 1)},
            )
            for idx in range(4)
        ]
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        assert len(cd_list[0].dot_positions) == 4

    def test_x_positions_span_svg_width(self) -> None:
        """First dot x=padding, last dot x=width-padding (relative to defaults)."""
        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"rework_cycles": float(idx + 1)},
            )
            for idx in range(3)
        ]
        trend = compute_trend(entries, "rework_cycles")
        # Use explicit SVG dimensions
        cd_list = build_trends_template_data([trend], entries, svg_width=300.0, svg_padding=8.0)
        positions = cd_list[0].dot_positions
        # First x should equal svg_padding
        assert positions[0][0] == pytest.approx(8.0, abs=0.5)
        # Last x should equal svg_width - svg_padding
        assert positions[-1][0] == pytest.approx(292.0, abs=0.5)

    def test_y_positions_within_svg_height(self) -> None:
        """All y positions must be within [0, svg_height]."""
        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.60 + idx * 0.10},
            )
            for idx in range(4)
        ]
        trend = compute_trend(entries, "first_pass_success_rate")
        cd_list = build_trends_template_data([trend], entries, svg_height=60.0)
        for _x, y in cd_list[0].dot_positions:
            assert 0 <= y <= 60.0

    def test_high_value_has_lower_y_than_low_value(self) -> None:
        """Higher values must map to lower y (SVG origin is top-left)."""
        entries = [
            make_history_entry(
                run_id="low",
                timestamp=datetime(2026, 4, 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.30},
            ),
            make_history_entry(
                run_id="high",
                timestamp=datetime(2026, 4, 2, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.90},
            ),
        ]
        trend = compute_trend(entries, "first_pass_success_rate")
        cd_list = build_trends_template_data([trend], entries)
        pos = cd_list[0].dot_positions
        # pos[0] is low value (high y), pos[1] is high value (low y)
        assert pos[1][1] < pos[0][1]

    def test_empty_values_produces_empty_positions(self) -> None:
        """A trend with no values must produce empty dot_positions."""
        trend = compute_trend([], "rework_cycles")
        cd_list = build_trends_template_data([trend], [])
        assert cd_list[0].dot_positions == []


# ---------------------------------------------------------------------------
# Task 1: Zone colors
# ---------------------------------------------------------------------------


class TestZoneColors:
    def test_green_for_high_success_rate(self) -> None:
        """first_pass_success_rate >= 0.85 must produce zone_color='green'."""
        entries = [make_history_entry(metrics={"first_pass_success_rate": 0.92})]
        trend = compute_trend(entries, "first_pass_success_rate")
        cd_list = build_trends_template_data([trend], entries)
        assert cd_list[0].zone_color == "green"

    def test_red_for_low_success_rate(self) -> None:
        """first_pass_success_rate < 0.60 must produce zone_color='red'."""
        entries = [make_history_entry(metrics={"first_pass_success_rate": 0.40})]
        trend = compute_trend(entries, "first_pass_success_rate")
        cd_list = build_trends_template_data([trend], entries)
        assert cd_list[0].zone_color == "red"

    def test_white_for_empty_trend(self) -> None:
        """Trend with no values must produce zone_color='white'."""
        trend = compute_trend([], "rework_cycles")
        cd_list = build_trends_template_data([trend], [])
        assert cd_list[0].zone_color == "white"


# ---------------------------------------------------------------------------
# Task 1: Config-break detection
# ---------------------------------------------------------------------------


class TestConfigBreakDetection:
    def test_no_config_change_no_breaks(self) -> None:
        """When all entries have the same config_hash, no breaks are detected."""
        entries = _make_entries_with_hashes(["abc", "abc", "abc"])
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        assert cd_list[0].config_break_indices == []

    def test_config_change_detected(self) -> None:
        """When config_hash changes, the index of the change is in config_break_indices."""
        entries = _make_entries_with_hashes(["abc", "abc", "xyz"])
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        # The break is at index 2 (when hash changed from "abc" to "xyz")
        assert 2 in cd_list[0].config_break_indices

    def test_single_entry_no_breaks(self) -> None:
        """Single-entry trend must always produce empty config_break_indices."""
        entries = _make_entries_with_hashes(["abc"])
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        assert cd_list[0].config_break_indices == []


# ---------------------------------------------------------------------------
# Task 1: Delta badges
# ---------------------------------------------------------------------------


class TestDeltaBadges:
    def test_positive_delta_badge(self) -> None:
        """Positive delta for a percent metric produces '+X%' badge."""
        entries = [
            make_history_entry(
                run_id="a",
                timestamp=datetime(2026, 4, 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.70},
            ),
            make_history_entry(
                run_id="b",
                timestamp=datetime(2026, 4, 2, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.80},
            ),
        ]
        trend = compute_trend(entries, "first_pass_success_rate")
        cd_list = build_trends_template_data([trend], entries)
        badge = cd_list[0].delta_badge
        assert "+" in badge
        assert "%" in badge

    def test_negative_delta_badge(self) -> None:
        """Negative delta produces a badge with '-' sign."""
        entries = [
            make_history_entry(
                run_id="a",
                timestamp=datetime(2026, 4, 1, tzinfo=timezone.utc),
                metrics={"rework_cycles": 2.0},
            ),
            make_history_entry(
                run_id="b",
                timestamp=datetime(2026, 4, 2, tzinfo=timezone.utc),
                metrics={"rework_cycles": 1.0},
            ),
        ]
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        badge = cd_list[0].delta_badge
        assert "-" in badge

    def test_no_delta_single_run(self) -> None:
        """Single-run trend must produce '—' delta badge."""
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trend = compute_trend(entries, "rework_cycles")
        cd_list = build_trends_template_data([trend], entries)
        assert cd_list[0].delta_badge == "—"


# ---------------------------------------------------------------------------
# Task 2: HTML template rendering
# ---------------------------------------------------------------------------


class TestTrendsHtmlTemplate:
    def _render_html(self, trends: list[MetricTrend], entries: list) -> str:
        """Helper: write HTML report to tmp file and return content."""
        from raki.report.trends import write_trends_html_report
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            output = Path(tmpdir) / "trends.html"
            write_trends_html_report(trends, entries, output)
            return output.read_text(encoding="utf-8")

    def test_html_contains_svg_elements(self) -> None:
        """Rendered HTML must contain SVG elements for dot charts."""
        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.70 + idx * 0.05},
            )
            for idx in range(3)
        ]
        trends = compute_all_trends(entries)
        html = self._render_html(trends, entries)
        assert "<svg" in html.lower()

    def test_html_contains_tier_labels(self) -> None:
        """Rendered HTML must contain tier group labels."""
        entries = [
            make_history_entry(
                metrics={
                    "first_pass_success_rate": 0.80,
                    "rework_cycles": 1.0,
                }
            )
        ]
        trends = compute_all_trends(entries)
        html = self._render_html(trends, entries)
        assert "Operational" in html

    def test_html_contains_zone_color_class(self) -> None:
        """Rendered HTML must contain zone color CSS classes."""
        entries = [make_history_entry(metrics={"first_pass_success_rate": 0.92})]
        trends = compute_all_trends(entries)
        html = self._render_html(trends, entries)
        # Should have color classes like "green", "red", "yellow"
        assert any(color in html for color in ("green", "red", "yellow", "white"))

    def test_html_contains_metric_display_names(self) -> None:
        """Rendered HTML must show metric display names."""
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trends = compute_all_trends(entries)
        html = self._render_html(trends, entries)
        assert "Rework cycles" in html

    def test_html_contains_summary_sentence(self) -> None:
        """Rendered HTML must contain the summary sentence."""
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trends = compute_all_trends(entries)
        html = self._render_html(trends, entries)
        # Summary sentence should mention metrics/data
        assert any(word in html.lower() for word in ("metric", "trend", "data"))


# ---------------------------------------------------------------------------
# Task 3: write_trends_html_report() and build_summary_sentence()
# ---------------------------------------------------------------------------


class TestWriteTrendsHtmlReport:
    def test_creates_output_file(self, tmp_path: Path) -> None:
        """write_trends_html_report must create the output file."""
        from raki.report.trends import write_trends_html_report

        output = tmp_path / "trends.html"
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trends = compute_all_trends(entries)
        write_trends_html_report(trends, entries, output)
        assert output.exists()

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        """write_trends_html_report must create missing parent directories."""
        from raki.report.trends import write_trends_html_report

        output = tmp_path / "nested" / "deep" / "trends.html"
        entries = [make_history_entry(metrics={"rework_cycles": 1.5})]
        trends = compute_all_trends(entries)
        write_trends_html_report(trends, entries, output)
        assert output.exists()

    def test_empty_trends_produces_valid_html(self, tmp_path: Path) -> None:
        """write_trends_html_report with empty trends list must not raise."""
        from raki.report.trends import write_trends_html_report

        output = tmp_path / "trends.html"
        write_trends_html_report([], [], output)
        assert output.exists()
        content = output.read_text()
        assert "<html" in content.lower()

    def test_output_is_valid_html(self, tmp_path: Path) -> None:
        """Output file must contain a proper HTML structure."""
        from raki.report.trends import write_trends_html_report

        output = tmp_path / "trends.html"
        entries = [make_history_entry(metrics={"first_pass_success_rate": 0.80})]
        trends = compute_all_trends(entries)
        write_trends_html_report(trends, entries, output)
        content = output.read_text()
        assert "<html" in content.lower()
        assert "</html>" in content.lower()


class TestBuildSummarySentence:
    def test_empty_trends(self) -> None:
        """build_summary_sentence with empty list must return a message."""
        from raki.report.trends import build_summary_sentence

        result = build_summary_sentence([])
        assert len(result) > 0

    def test_counts_improving(self) -> None:
        """build_summary_sentence must count improving metrics."""
        from raki.report.trends import build_summary_sentence

        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.60 + idx * 0.10},
            )
            for idx in range(3)
        ]
        trends = compute_all_trends(entries)
        result = build_summary_sentence(trends)
        assert "improving" in result.lower()

    def test_counts_declining(self) -> None:
        """build_summary_sentence must count declining metrics."""
        from raki.report.trends import build_summary_sentence

        entries = [
            make_history_entry(
                run_id=f"run-{idx}",
                timestamp=datetime(2026, 4, idx + 1, tzinfo=timezone.utc),
                metrics={"first_pass_success_rate": 0.90 - idx * 0.15},
            )
            for idx in range(3)
        ]
        trends = compute_all_trends(entries)
        result = build_summary_sentence(trends)
        assert "declining" in result.lower()

    def test_mentions_total_metric_count(self) -> None:
        """build_summary_sentence must mention the total number of metrics."""
        from raki.report.trends import build_summary_sentence

        entries = [
            make_history_entry(
                metrics={
                    "first_pass_success_rate": 0.80,
                    "rework_cycles": 1.0,
                }
            )
        ]
        trends = compute_all_trends(entries)
        result = build_summary_sentence(trends)
        # Should mention count of metrics
        assert str(len(trends)) in result
