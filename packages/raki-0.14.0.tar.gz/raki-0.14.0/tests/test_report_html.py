"""Tests for HTML report generation — self-contained, dark-themed, collapsible drill-down."""

from datetime import datetime, timezone
from pathlib import Path

import pytest

pytest.importorskip("jinja2")

from raki.model.dataset import EvalSample, SessionMeta
from raki.model.phases import ReviewFinding
from raki.model.report import EvalReport, MetricResult, SampleResult

from conftest import make_sample


def _make_minimal_report() -> EvalReport:
    """Report with only aggregate scores, no sample results."""
    return EvalReport(
        run_id="eval-html-001",
        timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
        config={"adapter": "session-schema", "metrics": ["rework_cycles"]},
        aggregate_scores={
            "first_pass_success_rate": 0.58,
            "rework_cycles": 1.3,
            "review_severity_distribution": 0.85,
            "cost_efficiency": 18.4,
        },
    )


def _make_report_with_samples() -> EvalReport:
    """Report with sample results including sessions, phases, and findings."""
    findings_session_a = [
        ReviewFinding(
            reviewer="reviewer-1",
            severity="critical",
            file="main.py",
            line=42,
            issue="SQL injection vulnerability",
            suggestion="Use parameterized queries",
        ),
        ReviewFinding(
            reviewer="reviewer-1",
            severity="minor",
            file="utils.py",
            line=10,
            issue="Unused import",
        ),
    ]
    findings_session_b = [
        ReviewFinding(
            reviewer="reviewer-2",
            severity="critical",
            file="main.py",
            line=50,
            issue="SQL injection vulnerability",
            suggestion="Use parameterized queries",
        ),
        ReviewFinding(
            reviewer="reviewer-2",
            severity="major",
            file="config.py",
            line=5,
            issue="Hardcoded credentials",
            suggestion="Use environment variables",
        ),
    ]
    sample_a = make_sample(
        "session-alpha",
        rework_cycles=2,
        cost=25.0,
        verify_status="failed",
        findings=findings_session_a,
    )
    sample_b = make_sample(
        "session-beta",
        rework_cycles=1,
        cost=15.0,
        verify_status="completed",
        findings=findings_session_b,
    )
    sample_c = make_sample(
        "session-gamma",
        rework_cycles=0,
        cost=8.0,
        verify_status="completed",
    )

    metric_rework = MetricResult(
        name="rework_cycles",
        score=1.0,
        sample_scores={
            "session-alpha": 2.0,
            "session-beta": 1.0,
            "session-gamma": 0.0,
        },
    )
    metric_verify = MetricResult(
        name="first_pass_success_rate",
        score=0.67,
        sample_scores={
            "session-alpha": 0.0,
            "session-beta": 1.0,
            "session-gamma": 1.0,
        },
    )
    metric_faith = MetricResult(
        name="faithfulness",
        score=0.80,
        details={"claims_verified": 24, "claims_total": 30},
        sample_scores={
            "session-alpha": 0.60,
            "session-beta": 0.90,
            "session-gamma": 0.90,
        },
    )

    sample_results = [
        SampleResult(sample=sample_a, scores=[metric_rework, metric_verify, metric_faith]),
        SampleResult(sample=sample_b, scores=[metric_rework, metric_verify, metric_faith]),
        SampleResult(sample=sample_c, scores=[metric_rework, metric_verify, metric_faith]),
    ]

    return EvalReport(
        run_id="eval-html-samples-001",
        timestamp=datetime(2026, 4, 18, 14, 30, 0, tzinfo=timezone.utc),
        config={"adapter": "session-schema"},
        aggregate_scores={
            "first_pass_success_rate": 0.67,
            "rework_cycles": 1.0,
            "review_severity_distribution": 0.85,
            "cost_efficiency": 16.0,
            "faithfulness": 0.80,
        },
        sample_results=sample_results,
    )


def _make_report_with_many_sessions() -> EvalReport:
    """Report with 7 sessions to test 'worst 5' shortcut.

    Uses a retrieval metric (context_precision) so compute_worst_sessions
    correctly ranks sessions — operational metrics are excluded from ranking.
    """
    sample_results = []
    scores_map = {
        "session-01": 0.95,
        "session-02": 0.30,
        "session-03": 0.85,
        "session-04": 0.10,
        "session-05": 0.50,
        "session-06": 0.20,
        "session-07": 0.75,
    }
    for session_id, score in scores_map.items():
        sample = make_sample(session_id, rework_cycles=int((1 - score) * 3))
        metric = MetricResult(
            name="context_precision",
            score=score,
            sample_scores={session_id: score},
        )
        sample_results.append(SampleResult(sample=sample, scores=[metric]))

    return EvalReport(
        run_id="eval-html-many",
        timestamp=datetime(2026, 4, 18, 16, 0, 0, tzinfo=timezone.utc),
        aggregate_scores={"context_precision": sum(scores_map.values()) / len(scores_map)},
        sample_results=sample_results,
    )


def _make_report_with_recurring_failures() -> EvalReport:
    """Report with an issue that appears in exactly 3 sessions (meets ≥3 threshold).

    Used to verify the Recurring Failures section is shown when the clustering
    threshold is met.
    """
    from raki.model.phases import ReviewFinding

    sql_finding = ReviewFinding(
        reviewer="reviewer",
        severity="critical",
        file="main.py",
        issue="SQL injection vulnerability",
        suggestion="Use parameterized queries",
    )
    samples = [
        make_sample("session-alpha", findings=[sql_finding]),
        make_sample("session-beta", findings=[sql_finding]),
        make_sample("session-gamma", findings=[sql_finding]),
    ]
    return EvalReport(
        run_id="eval-html-recurring",
        timestamp=datetime(2026, 4, 18, 14, 30, 0, tzinfo=timezone.utc),
        aggregate_scores={"first_pass_success_rate": 0.0},
        sample_results=[SampleResult(sample=s, scores=[]) for s in samples],
    )


# --- HTML generation tests ---


class TestHtmlReportGeneration:
    def test_generates_html_file(self, tmp_path: Path) -> None:
        """write_html_report should create an HTML file at the given path."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        assert output.exists()
        assert output.stat().st_size > 0

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        """Should create parent directories if they do not exist."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "nested" / "deep" / "report.html"
        write_html_report(report, output)
        assert output.exists()

    def test_output_is_valid_html(self, tmp_path: Path) -> None:
        """Output should start with <!DOCTYPE html> and contain closing </html>."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert content.strip().startswith("<!DOCTYPE html>")
        assert "</html>" in content


class TestHtmlSelfContained:
    def test_no_external_css_links(self, tmp_path: Path) -> None:
        """HTML should not reference any external CSS files."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'rel="stylesheet"' not in content
        assert "<style>" in content

    def test_no_external_js_scripts(self, tmp_path: Path) -> None:
        """HTML should not reference any external JavaScript files."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should have inline script but no src= attributes on script tags
        assert "<script src=" not in content

    def test_inline_styles_present(self, tmp_path: Path) -> None:
        """CSS should be inline within a <style> tag."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "<style>" in content
        assert "</style>" in content


class TestHtmlDarkTheme:
    def test_dark_background_color(self, tmp_path: Path) -> None:
        """Dark theme should use a dark background color."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should reference a dark background (e.g., #1a1a2e or similar dark color)
        assert "background" in content.lower()


class TestHtmlSections:
    def test_aggregate_scores_section(self, tmp_path: Path) -> None:
        """HTML should contain an aggregate scores section."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "Aggregate" in content or "aggregate" in content

    def test_operational_health_displayed(self, tmp_path: Path) -> None:
        """Operational metrics should appear in the report using display names."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "First-pass success rate" in content
        assert "Rework cycles" in content

    def test_retrieval_quality_displayed(self, tmp_path: Path) -> None:
        """Retrieval metrics should appear when present."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "faithfulness" in content

    def test_recurring_failures_section(self, tmp_path: Path) -> None:
        """Should show recurring failures when an issue appears in ≥3 sessions."""
        from raki.report.html_report import write_html_report

        # SQL injection appears in 3 sessions — meets the ≥3 threshold
        report = _make_report_with_recurring_failures()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "<h2>Recurring Failures</h2>" in content
        assert "SQL injection" in content

    def test_recurring_failures_section_hidden_when_empty(self, tmp_path: Path) -> None:
        """Recurring failures section should be completely hidden when no issues meet the threshold."""
        from raki.report.html_report import write_html_report

        # _make_minimal_report has no sample results → no findings → recurring_failures is empty
        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The entire section must be absent — not just empty
        assert "<h2>Recurring Failures</h2>" not in content

    def test_per_session_drilldown(self, tmp_path: Path) -> None:
        """Each session should be present in the drill-down section."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "session-alpha" in content
        assert "session-beta" in content
        assert "session-gamma" in content


class TestHtmlCollapsibleDetails:
    def test_collapsible_elements_present(self, tmp_path: Path) -> None:
        """Session details should use HTML <details>/<summary> for collapsible sections."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "<details" in content
        assert "<summary" in content

    def test_phases_shown_in_drilldown(self, tmp_path: Path) -> None:
        """Phase details should be visible in the session drill-down."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "implement" in content
        assert "verify" in content

    def test_findings_shown_in_drilldown(self, tmp_path: Path) -> None:
        """Findings should be shown within session drill-down."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "SQL injection vulnerability" in content
        assert "critical" in content.lower()


class TestHtmlColorCoding:
    def test_color_function_matches_cli(self) -> None:
        """html_color_for_score should match CLI color_for_score semantics."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.85) != html_color_for_score(0.45)
        # High score should be greenish, low score should be reddish
        high_color = html_color_for_score(0.85)
        low_color = html_color_for_score(0.45)
        assert high_color != low_color

    def test_score_colors_in_html(self, tmp_path: Path) -> None:
        """Score values in HTML should have color styling applied."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Color values should appear in the HTML (as inline styles or CSS classes)
        assert "color:" in content or "class=" in content


class TestHtmlWorstSessions:
    def test_worst_sessions_section(self, tmp_path: Path) -> None:
        """Should show a 'Worst 5 sessions' section when there are enough sessions."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_many_sessions()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "Worst" in content or "worst" in content

    def test_worst_sessions_ordered(self, tmp_path: Path) -> None:
        """Worst sessions should show lowest-scoring sessions first."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_many_sessions()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # session-04 (score 0.10) should appear in worst sessions
        assert "session-04" in content
        # session-06 (score 0.20) should appear in worst sessions
        assert "session-06" in content

    def test_worst_sessions_limited_to_five(self, tmp_path: Path) -> None:
        """Worst sessions shortcut should show at most 5 sessions."""
        from raki.report.html_report import compute_worst_sessions

        report = _make_report_with_many_sessions()
        worst = compute_worst_sessions(report, limit=5)
        assert len(worst) == 5

    def test_worst_sessions_section_hidden_when_empty(self, tmp_path: Path) -> None:
        """Worst sessions section should be completely hidden when no retrieval metrics exist."""
        from raki.report.html_report import write_html_report

        # _make_minimal_report has no retrieval metrics → worst_sessions is empty
        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'class="worst-sessions"' not in content


class TestHtmlTimestampFilename:
    def test_html_timestamp_filename(self) -> None:
        """HTML report should use timestamp-based filename similar to JSON report."""
        from raki.report.html_report import html_timestamp_filename

        report = _make_minimal_report()
        filename = html_timestamp_filename(report)
        assert filename.endswith(".html")
        assert "raki-report" in filename


class TestHtmlMetadata:
    def test_run_id_in_html(self, tmp_path: Path) -> None:
        """The run ID should appear in the HTML report."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "eval-html-001" in content

    def test_timestamp_in_html(self, tmp_path: Path) -> None:
        """The report timestamp should appear in the HTML report."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "2026" in content


class TestHtmlFaithfulnessBreakdown:
    def test_faithfulness_details_shown(self, tmp_path: Path) -> None:
        """When faithfulness metric has claim details, they should be shown."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The faithfulness metric has details with claims_verified/claims_total
        assert "claims" in content.lower() or "faithfulness" in content.lower()


class TestHtmlSessionStripping:
    def test_strips_session_data_by_default(self, tmp_path: Path) -> None:
        """HTML report should strip raw session data by default (--include-sessions to opt in).

        Verifies that write_html_report applies strip_session_data to the report
        before rendering, matching the JSON report's default behavior.
        """
        from unittest.mock import patch

        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"

        # Capture the report object that gets passed to the template
        captured_reports: list[EvalReport] = []
        original_build_env = __import__(
            "raki.report.html_report", fromlist=["_build_jinja_env"]
        )._build_jinja_env

        def capture_env():
            env = original_build_env()
            original_get_template = env.get_template

            def patched_get_template(name):
                template = original_get_template(name)
                original_render = template.render

                def patched_render(**kwargs):
                    captured_reports.append(kwargs["report"])
                    return original_render(**kwargs)

                template.render = patched_render
                return template

            env.get_template = patched_get_template
            return env

        with patch("raki.report.html_report._build_jinja_env", side_effect=capture_env):
            write_html_report(report, output)

        assert len(captured_reports) == 1
        rendered_report = captured_reports[0]
        # Phase outputs should be replaced with the stripped sentinel
        for sample_result in rendered_report.sample_results:
            for phase in sample_result.sample.phases:
                assert phase.output == "<stripped>"
                assert phase.knowledge_context is None
                assert phase.instruction_context is None
                if phase.output_structured is not None:
                    from raki.report.json_report import STRUCTURED_DISPLAY_FIELDS

                    for key in phase.output_structured:
                        assert key in STRUCTURED_DISPLAY_FIELDS

    def test_include_sessions_retains_data(self, tmp_path: Path) -> None:
        """When include_sessions=True, raw session data should be retained."""
        from unittest.mock import patch

        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"

        captured_reports: list[EvalReport] = []
        original_build_env = __import__(
            "raki.report.html_report", fromlist=["_build_jinja_env"]
        )._build_jinja_env

        def capture_env():
            env = original_build_env()
            original_get_template = env.get_template

            def patched_get_template(name):
                template = original_get_template(name)
                original_render = template.render

                def patched_render(**kwargs):
                    captured_reports.append(kwargs["report"])
                    return original_render(**kwargs)

                template.render = patched_render
                return template

            env.get_template = patched_get_template
            return env

        with patch("raki.report.html_report._build_jinja_env", side_effect=capture_env):
            write_html_report(report, output, include_sessions=True)

        assert len(captured_reports) == 1
        rendered_report = captured_reports[0]
        # Phase outputs should NOT be stripped
        has_real_output = False
        for sample_result in rendered_report.sample_results:
            for phase in sample_result.sample.phases:
                if phase.output != "<stripped>":
                    has_real_output = True
        assert has_real_output


class TestComputeWorstSessionsRetrieval:
    def test_excludes_operational_metrics(self) -> None:
        """compute_worst_sessions should only use retrieval metrics, not operational ones."""
        from raki.report.html_report import compute_worst_sessions

        sample = make_sample("session-ops-only", rework_cycles=3, cost=50.0)
        metric = MetricResult(
            name="rework_cycles",
            score=3.0,
            sample_scores={"session-ops-only": 3.0},
        )
        report = EvalReport(
            run_id="ops-only",
            aggregate_scores={"rework_cycles": 3.0},
            sample_results=[SampleResult(sample=sample, scores=[metric])],
        )
        worst = compute_worst_sessions(report, limit=5)
        # No retrieval metrics -> should return empty
        assert worst == []

    def test_uses_retrieval_metrics_only(self) -> None:
        """compute_worst_sessions should rank by retrieval scores, ignoring operational."""
        from raki.report.html_report import compute_worst_sessions

        sample = make_sample("session-mixed", rework_cycles=2, cost=30.0)
        operational_metric = MetricResult(
            name="rework_cycles",
            score=2.0,
            sample_scores={"session-mixed": 2.0},
        )
        retrieval_metric = MetricResult(
            name="faithfulness",
            score=0.70,
            sample_scores={"session-mixed": 0.70},
        )
        report = EvalReport(
            run_id="mixed",
            aggregate_scores={"rework_cycles": 2.0, "faithfulness": 0.70},
            sample_results=[
                SampleResult(sample=sample, scores=[operational_metric, retrieval_metric])
            ],
        )
        worst = compute_worst_sessions(report, limit=5)
        assert len(worst) == 1
        # Should use faithfulness (0.70), not the blended avg of (2.0 + 0.70) / 2
        assert worst[0].avg_score == pytest.approx(0.70)


# --- Issue #284: Jaccard clustering and 3-session threshold ---


class TestCollectRecurringFailuresJaccard:
    """_collect_recurring_failures uses Jaccard clustering and ≥3 session threshold."""

    def test_same_issue_in_three_sessions_is_returned(self) -> None:
        """Issue appearing in exactly 3 sessions meets the ≥3 threshold and is returned."""
        from raki.model.phases import ReviewFinding
        from raki.report.html_report import _collect_recurring_failures

        finding = ReviewFinding(
            reviewer="r", severity="critical", issue="SQL injection vulnerability"
        )
        samples = [make_sample(f"s{i}", findings=[finding]) for i in range(3)]
        report = EvalReport(
            run_id="three-sessions",
            sample_results=[SampleResult(sample=s, scores=[]) for s in samples],
        )
        result = _collect_recurring_failures(report)
        assert len(result) == 1
        assert result[0].issue == "SQL injection vulnerability"
        assert len(result[0].sessions) == 3

    def test_issue_in_only_two_sessions_excluded(self) -> None:
        """Issue appearing in only 2 sessions does NOT meet the ≥3 threshold."""
        from raki.model.phases import ReviewFinding
        from raki.report.html_report import _collect_recurring_failures

        finding = ReviewFinding(
            reviewer="r", severity="critical", issue="SQL injection vulnerability"
        )
        samples = [make_sample(f"s{i}", findings=[finding]) for i in range(2)]
        report = EvalReport(
            run_id="two-sessions",
            sample_results=[SampleResult(sample=s, scores=[]) for s in samples],
        )
        result = _collect_recurring_failures(report)
        assert result == []

    def test_similar_issues_clustered_by_jaccard(self) -> None:
        """Issues with Jaccard similarity ≥0.60 across 3+ sessions are merged into one cluster."""
        from raki.model.phases import ReviewFinding
        from raki.report.html_report import _collect_recurring_failures

        # "parameterized query missing SQL injection" vs "parameterized query missing SQL"
        # tokens A: {parameterized, query, missing, sql, injection} = 5 tokens
        # tokens B: {parameterized, query, missing, sql} = 4 tokens
        # intersection = 4, union = 5, Jaccard = 4/5 = 0.80 ≥ 0.60
        issue_a = "parameterized query missing SQL injection"
        issue_b = "parameterized query missing SQL"
        issue_c = "parameterized query missing SQL"

        samples = [
            make_sample(
                "s1", findings=[ReviewFinding(reviewer="r", severity="major", issue=issue_a)]
            ),
            make_sample(
                "s2", findings=[ReviewFinding(reviewer="r", severity="major", issue=issue_b)]
            ),
            make_sample(
                "s3", findings=[ReviewFinding(reviewer="r", severity="major", issue=issue_c)]
            ),
        ]
        report = EvalReport(
            run_id="jaccard-cluster",
            sample_results=[SampleResult(sample=s, scores=[]) for s in samples],
        )
        result = _collect_recurring_failures(report)
        # All three sessions should be in the same cluster (one recurring failure)
        assert len(result) == 1
        assert len(result[0].sessions) == 3

    def test_dissimilar_issues_not_clustered(self) -> None:
        """Issues with Jaccard similarity <0.60 are kept as separate clusters."""
        from raki.model.phases import ReviewFinding
        from raki.report.html_report import _collect_recurring_failures

        # "SQL injection vulnerability" vs "XSS cross site scripting attack"
        # tokens A: {sql, injection, vulnerability} = 3
        # tokens B: {xss, cross, site, scripting, attack} = 5
        # intersection = 0, Jaccard = 0/8 = 0.0 < 0.60
        issue_a = "SQL injection vulnerability"
        issue_b = "XSS cross site scripting attack"

        # Give each 3 sessions so threshold is met; check they remain separate
        samples_a = [
            make_sample(
                f"s_a_{i}",
                findings=[ReviewFinding(reviewer="r", severity="critical", issue=issue_a)],
            )
            for i in range(3)
        ]
        samples_b = [
            make_sample(
                f"s_b_{i}", findings=[ReviewFinding(reviewer="r", severity="major", issue=issue_b)]
            )
            for i in range(3)
        ]
        report = EvalReport(
            run_id="separate-clusters",
            sample_results=[SampleResult(sample=s, scores=[]) for s in samples_a + samples_b],
        )
        result = _collect_recurring_failures(report)
        assert len(result) == 2

    def test_highest_severity_used_for_cluster(self) -> None:
        """When similar issues have different severities, the highest severity is used."""
        from raki.model.phases import ReviewFinding
        from raki.report.html_report import _collect_recurring_failures

        # Same issue text in 3 sessions but different severities
        issue = "SQL injection vulnerability"
        samples = [
            make_sample(
                "s1", findings=[ReviewFinding(reviewer="r", severity="minor", issue=issue)]
            ),
            make_sample(
                "s2", findings=[ReviewFinding(reviewer="r", severity="critical", issue=issue)]
            ),
            make_sample(
                "s3", findings=[ReviewFinding(reviewer="r", severity="major", issue=issue)]
            ),
        ]
        report = EvalReport(
            run_id="severity-cluster",
            sample_results=[SampleResult(sample=s, scores=[]) for s in samples],
        )
        result = _collect_recurring_failures(report)
        assert len(result) == 1
        assert result[0].severity == "critical"

    def test_sorted_by_count_descending(self) -> None:
        """Recurring failures should be sorted by occurrence count, highest first."""
        from raki.model.phases import ReviewFinding
        from raki.report.html_report import _collect_recurring_failures

        common_issue = "SQL injection vulnerability"
        rare_issue = "XSS cross site scripting"

        # common_issue: 4 sessions (1 occurrence each), rare_issue: 3 sessions
        samples_common = [
            make_sample(
                f"c{i}",
                findings=[ReviewFinding(reviewer="r", severity="critical", issue=common_issue)],
            )
            for i in range(4)
        ]
        samples_rare = [
            make_sample(
                f"r{i}", findings=[ReviewFinding(reviewer="r", severity="major", issue=rare_issue)]
            )
            for i in range(3)
        ]
        report = EvalReport(
            run_id="sorted-failures",
            sample_results=[
                SampleResult(sample=s, scores=[]) for s in samples_common + samples_rare
            ],
        )
        result = _collect_recurring_failures(report)
        assert len(result) == 2
        assert result[0].count >= result[1].count


# --- Issue #33: HTML report fixes ---


class TestHtmlColorHigherIsBetter:
    """html_color_for_score respects higher_is_better for inverted metrics."""

    def test_inverted_metric_low_score_is_green(self) -> None:
        """For inverted metrics (higher_is_better=False), low scores should be green."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.1, higher_is_better=False) == "green"

    def test_inverted_metric_high_score_is_red(self) -> None:
        """For inverted metrics (higher_is_better=False), high scores should be red."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.8, higher_is_better=False) == "red"

    def test_inverted_metric_mid_score_is_yellow(self) -> None:
        """For inverted metrics (higher_is_better=False), mid scores should be yellow."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.3, higher_is_better=False) == "yellow"

    def test_non_normalized_currency_returns_color_zone(self) -> None:
        """Currency metrics should return zone color: green <=$5, amber $5-$15, red >$15."""
        from raki.report.html_report import html_color_for_score

        assert (
            html_color_for_score(18.4, higher_is_better=False, display_format="currency") == "red"
        )

    def test_non_normalized_count_returns_white(self) -> None:
        """Non-normalized metrics (count) should return white, not a color band."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(3.0, higher_is_better=False, display_format="count") == "white"

    def test_inverted_metric_colors_in_report(self, tmp_path: Path) -> None:
        """Inverted metrics like knowledge_miss_rate should show correct colors."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-inverted",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "knowledge_miss_rate": 0.1,  # Low miss rate = good = green
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Miss rate 0.1 with higher_is_better=False should be green
        assert "color-green" in content


class TestProgressBarOmission:
    """Progress bars omitted for non-normalized metrics (cost, rework count)."""

    def test_no_progress_bar_for_cost(self, tmp_path: Path) -> None:
        """Cost metric should not have a progress bar since it's not 0-1 normalized."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-cost",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"cost_efficiency": 18.4},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The cost card should not have a metric-bar element
        # Look for the display name "Cost / session" which is now used in the template
        cost_idx = content.find("Cost / session")
        assert cost_idx != -1, "Expected 'Cost / session' display name in HTML"
        # Find the end of this score-card div
        card_end = content.find("</div>", cost_idx + 50)
        next_card_end = content.find("</div>", card_end + 1)
        cost_section = (
            content[cost_idx:next_card_end] if next_card_end != -1 else content[cost_idx:]
        )
        assert "metric-bar" not in cost_section

    def test_no_progress_bar_for_rework_count(self, tmp_path: Path) -> None:
        """Rework cycles metric should not have a progress bar since it's a count."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-rework",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"rework_cycles": 1.3},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # rework_cycles card should not have a metric-bar — uses display name "Rework cycles"
        rework_idx = content.find("Rework cycles")
        assert rework_idx != -1, "Expected 'Rework cycles' display name in HTML"
        card_end = content.find("</div>", rework_idx + 50)
        next_card_end = content.find("</div>", card_end + 1)
        rework_section = (
            content[rework_idx:next_card_end] if next_card_end != -1 else content[rework_idx:]
        )
        assert "metric-bar" not in rework_section

    def test_progress_bar_present_for_normalized_metric(self, tmp_path: Path) -> None:
        """Normalized metrics (like verify rate, 0-1) should still have progress bars."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-verify",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "metric-bar" in content


class TestSessionCount:
    """session_count passed as separate template variable, not derived from sample_results."""

    def test_session_count_in_header(self, tmp_path: Path) -> None:
        """Session count should appear in the header from the session_count variable."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-count",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
            config={"session_count": 42},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, session_count=42)
        content = output.read_text()
        assert "42" in content

    def test_session_count_defaults_to_sample_results_length(self, tmp_path: Path) -> None:
        """When session_count not provided, it should fall back to sample_results length."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # 3 sample results in _make_report_with_samples
        assert ">3<" in content or ">3 " in content or "Sessions:</strong> 3" in content


class TestEmptyStates:
    """All conditional sections have .empty-state messages when data is empty."""

    def test_no_retrieval_metrics_shows_empty_state(self, tmp_path: Path) -> None:
        """When there are no retrieval metrics, show a footnote note (no category-section div)."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-no-retrieval",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.85,
                "rework_cycles": 1.0,
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # A footnote note appears instead of a category-section with empty-state
        assert 'class="footnote"' in content
        assert "Retrieval" in content
        assert "Retrieval Quality" not in content

    def test_no_recurring_failures_shows_empty_state(self, tmp_path: Path) -> None:
        """When no failures meet the ≥3-session threshold, the Recurring Failures section is hidden."""
        from raki.report.html_report import write_html_report

        # _make_minimal_report has no sample results → recurring_failures is empty → section hidden
        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Section is hidden entirely, not replaced with an empty-state message
        assert "<h2>Recurring Failures</h2>" not in content

    def test_no_drilldown_shows_empty_state(self, tmp_path: Path) -> None:
        """When sample_results is empty, the drill-down section should show empty-state."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "empty-state" in content

    def test_no_worst_sessions_shows_empty_state(self, tmp_path: Path) -> None:
        """When no retrieval metrics exist, the Worst N Sessions section is hidden."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Section is hidden entirely when worst_sessions is empty
        assert 'class="worst-sessions"' not in content


class TestDisplayNames:
    """display_name used on score cards, raw metric names in JSON only."""

    def test_display_name_on_score_card(self, tmp_path: Path) -> None:
        """Score cards should show display_name (e.g., 'First-pass success rate') not raw name."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-display",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.85,
                "cost_efficiency": 7.74,
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should show display names
        assert "First-pass success rate" in content
        assert "Cost / session" in content

    def test_metric_description_subtitle(self, tmp_path: Path) -> None:
        """Score cards should show plain-English subtitle from METRIC_METADATA."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-desc",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Subtitle from METRIC_METADATA["first_pass_success_rate"]["subtitle"]
        assert "without requiring any rework" in content


class TestAccessibility:
    """Accessibility improvements: button, aria-expanded, main landmark."""

    def test_main_landmark_present(self, tmp_path: Path) -> None:
        """HTML should use a <main> landmark for the main content area."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "<main" in content
        assert "</main>" in content

    def test_button_for_worst_session_rows(self, tmp_path: Path) -> None:
        """Worst session rows should use <button> instead of <a> for clickable rows."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_many_sessions()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should use button, not anchor
        assert "<button" in content
        assert 'class="worst-session-row"' in content or "worst-session-row" in content
        # Should NOT use <a> for worst session rows
        assert '<a class="worst-session-row"' not in content

    def test_aria_expanded_on_collapsibles(self, tmp_path: Path) -> None:
        """Collapsible sections should have aria-expanded attributes."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "aria-expanded" in content


class TestCostFormatting:
    """Cost should display as $7.74, not 7.74."""

    def test_cost_displays_with_dollar_sign(self, tmp_path: Path) -> None:
        """Cost values should be formatted with a dollar sign prefix."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-cost-fmt",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"cost_efficiency": 7.74},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "$7.74" in content

    def test_cost_in_drilldown_has_dollar_sign(self, tmp_path: Path) -> None:
        """Cost in the per-session drill-down should also show dollar sign."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The drill-down already shows $25.00 etc. - verify this is still the case
        assert "$25.00" in content or "$15.00" in content


class TestMetricMetadataSync:
    """METRIC_METADATA stays in sync with actual metric class attributes."""

    def test_metadata_matches_metric_classes(self) -> None:
        """Every metric class's display_name, higher_is_better, and display_format
        must match the corresponding entry in METRIC_METADATA."""
        from raki.metrics.knowledge import ALL_KNOWLEDGE
        from raki.metrics.operational import ALL_OPERATIONAL
        from raki.metrics.ragas.faithfulness import FaithfulnessMetric
        from raki.metrics.ragas.precision import ContextPrecisionMetric
        from raki.metrics.ragas.recall import ContextRecallMetric
        from raki.metrics.ragas.relevancy import AnswerRelevancyMetric
        from raki.report.html_report import METRIC_METADATA

        all_metrics = (
            list(ALL_OPERATIONAL)
            + list(ALL_KNOWLEDGE)
            + [
                FaithfulnessMetric(),
                AnswerRelevancyMetric(),
                ContextPrecisionMetric(),
                ContextRecallMetric(),
            ]
        )

        for metric in all_metrics:
            meta = METRIC_METADATA.get(metric.name)
            assert meta is not None, f"Metric '{metric.name}' missing from METRIC_METADATA"
            assert meta["display_name"] == metric.display_name, (
                f"display_name mismatch for '{metric.name}': "
                f"metadata={meta['display_name']!r}, class={metric.display_name!r}"
            )
            assert meta["higher_is_better"] == metric.higher_is_better, (
                f"higher_is_better mismatch for '{metric.name}': "
                f"metadata={meta['higher_is_better']!r}, class={metric.higher_is_better!r}"
            )
            assert meta["display_format"] == metric.display_format, (
                f"display_format mismatch for '{metric.name}': "
                f"metadata={meta['display_format']!r}, class={metric.display_format!r}"
            )

    def test_all_metadata_entries_have_metric_class(self) -> None:
        """Every key in METRIC_METADATA must correspond to an actual metric class."""
        from raki.metrics.knowledge import ALL_KNOWLEDGE
        from raki.metrics.operational import ALL_OPERATIONAL
        from raki.metrics.ragas.faithfulness import FaithfulnessMetric
        from raki.metrics.ragas.precision import ContextPrecisionMetric
        from raki.metrics.ragas.recall import ContextRecallMetric
        from raki.metrics.ragas.relevancy import AnswerRelevancyMetric
        from raki.report.html_report import METRIC_METADATA

        all_metrics = (
            list(ALL_OPERATIONAL)
            + list(ALL_KNOWLEDGE)
            + [
                FaithfulnessMetric(),
                AnswerRelevancyMetric(),
                ContextPrecisionMetric(),
                ContextRecallMetric(),
            ]
        )
        metric_names = {metric.name for metric in all_metrics}

        for metadata_key in METRIC_METADATA:
            assert metadata_key in metric_names, (
                f"METRIC_METADATA key '{metadata_key}' has no corresponding metric class"
            )


class TestPercentFormat:
    """display_format='percent' renders as '85%' not '0.85'."""

    def test_first_pass_success_rate_shows_percentage(self, tmp_path: Path) -> None:
        """first_pass_success_rate (display_format=percent) should render as percentage."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-percent",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "85%" in content
        # Should NOT show raw 0.85 in the metric value
        # (0.85 may appear elsewhere, e.g. in a bar width, so we check the metric-value div)
        verify_idx = content.find("First-pass success rate")
        assert verify_idx != -1
        value_start = content.find("metric-value", verify_idx)
        value_end = content.find("</div>", value_start)
        value_section = content[value_start:value_end]
        assert "85%" in value_section


# --- Issue #70: Score cards redesign tests ---


def _make_session_meta_helper(session_id: str) -> SessionMeta:
    """Helper to create a SessionMeta for tests."""
    return SessionMeta(
        session_id=session_id,
        started_at=datetime(2026, 4, 10, tzinfo=timezone.utc),
        total_phases=1,
        rework_cycles=0,
    )


class TestSummarySentenceInHtml:
    """Summary sentence above score cards."""

    def test_summary_sentence_present(self, tmp_path: Path) -> None:
        """HTML report should include a summary sentence above the score cards."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "summary-sentence" in content

    def test_summary_sentence_contains_success_rate(self, tmp_path: Path) -> None:
        """Summary sentence in HTML should contain the first-pass success rate percentage."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # 0.67 = 67%
        assert "67%" in content


class TestHeroCard:
    """First-pass success rate should render as a hero card (wider, larger)."""

    def test_hero_card_class_present(self, tmp_path: Path) -> None:
        """First-pass success rate card should have a hero-card CSS class."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-hero",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.91},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "hero-card" in content


class TestPlainEnglishSubtitles:
    """Every card has a plain-English subtitle."""

    def test_first_pass_success_rate_subtitle(self, tmp_path: Path) -> None:
        """First-pass success rate card should have the plain-English subtitle."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-subtitles",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "without requiring any rework" in content

    def test_rework_cycles_subtitle(self, tmp_path: Path) -> None:
        """Rework cycles card should have the plain-English subtitle."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-subtitles",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"rework_cycles": 1.0},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "redo its work after feedback" in content

    def test_cost_subtitle(self, tmp_path: Path) -> None:
        """Cost card should have the plain-English subtitle."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-subtitles",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"cost_efficiency": 10.0},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "costs in API fees" in content


class TestDirectionBadges:
    """Direction badges on directional metrics (higher/lower is better)."""

    def test_first_pass_success_rate_shows_higher_is_better(self, tmp_path: Path) -> None:
        """First-pass success rate should show 'higher is better' direction badge."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-direction",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "higher is better" in content.lower()

    def test_rework_cycles_shows_lower_is_better(self, tmp_path: Path) -> None:
        """Rework cycles should show 'lower is better' direction badge."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-direction",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"rework_cycles": 1.0},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "lower is better" in content.lower()

    def test_first_pass_success_rate_shows_target_threshold(self, tmp_path: Path) -> None:
        """First-pass success rate card should show target threshold of >85%."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-threshold",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "&gt;85%" in content or ">85%" in content


class TestSeverityDistributionBar:
    """Severity as stacked distribution bar with counts + traffic-light label."""

    def test_severity_bar_present(self, tmp_path: Path) -> None:
        """Severity section should show a distribution bar, not a single score."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "severity-distribution" in content or "severity-bar" in content

    def test_severity_counts_shown(self, tmp_path: Path) -> None:
        """Severity distribution should show counts for each severity level."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # _make_report_with_samples has 2 critical, 1 major, 1 minor findings
        assert "critical" in content.lower()
        assert "major" in content.lower()
        assert "minor" in content.lower()

    def test_severity_label_shown(self, tmp_path: Path) -> None:
        """Severity distribution should show a traffic-light label."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        content_lower = content.lower()
        assert "clean" in content_lower or "moderate" in content_lower or "severe" in content_lower


class TestSeverityDistributionCompute:
    """compute_severity_distribution helper tests."""

    def test_clean_label_when_no_findings(self) -> None:
        """No findings at all should produce 'Clean' label."""
        from raki.report.html_report import SeverityDistribution, compute_severity_distribution

        report = EvalReport(
            run_id="clean",
            aggregate_scores={"review_severity_distribution": 1.0},
            sample_results=[
                SampleResult(sample=make_sample("s1"), scores=[]),
            ],
        )
        dist = compute_severity_distribution(report)
        assert isinstance(dist, SeverityDistribution)
        assert dist.label == "Clean"
        assert dist.critical == 0
        assert dist.major == 0
        assert dist.minor == 0

    def test_minor_label_with_only_major(self) -> None:
        """0 critical + some major = 'Minor' label."""
        from raki.report.html_report import compute_severity_distribution

        findings = [
            ReviewFinding(reviewer="r1", severity="major", issue="test issue"),
        ]
        report = EvalReport(
            run_id="minor-label",
            aggregate_scores={},
            sample_results=[
                SampleResult(sample=make_sample("s1", findings=findings), scores=[]),
            ],
        )
        dist = compute_severity_distribution(report)
        assert dist.label == "Minor"
        assert dist.critical == 0
        assert dist.major == 1

    def test_severe_label_when_weighted_above_threshold(self) -> None:
        """When weighted score > 0.5, label should be 'Severe'."""
        from raki.report.html_report import compute_severity_distribution

        findings = [
            ReviewFinding(reviewer="r1", severity="critical", issue="crit1"),
            ReviewFinding(reviewer="r1", severity="critical", issue="crit2"),
            ReviewFinding(reviewer="r1", severity="critical", issue="crit3"),
        ]
        report = EvalReport(
            run_id="severe-label",
            aggregate_scores={},
            sample_results=[
                SampleResult(sample=make_sample("s1", findings=findings), scores=[]),
            ],
        )
        dist = compute_severity_distribution(report)
        assert dist.label == "Severe"

    def test_moderate_label(self) -> None:
        """When there are some critical but weighted <= 0.5, label should be 'Moderate'."""
        from raki.report.html_report import compute_severity_distribution

        findings = [
            ReviewFinding(reviewer="r1", severity="critical", issue="crit1"),
            ReviewFinding(reviewer="r1", severity="minor", issue="minor1"),
            ReviewFinding(reviewer="r1", severity="minor", issue="minor2"),
            ReviewFinding(reviewer="r1", severity="minor", issue="minor3"),
            ReviewFinding(reviewer="r1", severity="minor", issue="minor4"),
            ReviewFinding(reviewer="r1", severity="minor", issue="minor5"),
        ]
        report = EvalReport(
            run_id="moderate-label",
            aggregate_scores={},
            sample_results=[
                SampleResult(sample=make_sample("s1", findings=findings), scores=[]),
            ],
        )
        dist = compute_severity_distribution(report)
        assert dist.label == "Moderate"


class TestKnowledgeMissRateConditional:
    """Knowledge Miss Rate hidden when no knowledge_context."""

    def test_hidden_when_no_knowledge_context(self, tmp_path: Path) -> None:
        """Knowledge Miss Rate is hidden when no session has knowledge_context.

        When knowledge_miss_rate is in operational metrics and no session
        has knowledge_context, the template hides the metric card entirely
        and shows a footnote explaining why.
        """
        from raki.report.html_report import write_html_report

        sample = make_sample("s1")
        report = EvalReport(
            run_id="eval-no-knowledge",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.85,
                "knowledge_miss_rate": None,
            },
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Knowledge metrics are hidden (not rendered as N/A) when no context;
        # a footnote explains the omission
        assert "Knowledge Miss Rate omitted" in content

    def test_shown_when_knowledge_context_present(self, tmp_path: Path) -> None:
        """Knowledge Miss Rate should be shown when sessions have knowledge_context."""
        from raki.model.phases import PhaseResult
        from raki.report.html_report import write_html_report

        meta = _make_session_meta_helper("s1")
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                knowledge_context="some reference docs",
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="eval-with-knowledge",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.85,
                "knowledge_miss_rate": 0.15,
            },
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "Knowledge miss rate" in content or "Knowledge Miss Rate" in content


class TestRetrievalQualityConditional:
    """Retrieval Quality hidden when --judge is not passed."""

    def test_footnote_when_no_retrieval(self, tmp_path: Path) -> None:
        """When has_retrieval=False, a .footnote note appears; no category-section div rendered."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-no-retrieval",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.85,
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, has_retrieval=False)
        content = output.read_text()
        assert 'class="footnote"' in content
        assert "Retrieval" in content
        assert "Retrieval Quality" not in content


class TestReworkCyclesColorThresholds:
    """Rework Cycles colored by threshold (green <=0.3, amber 0.3-1.0, red >1.0)."""

    def test_green_at_or_below_threshold(self, tmp_path: Path) -> None:
        """Rework cycles at or below 0.3 should be green."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-rework-green",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"rework_cycles": 0.2},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        rework_idx = content.find("Rework")
        assert rework_idx != -1
        card_section = content[rework_idx : rework_idx + 500]
        assert "color-green" in card_section or "rework-green" in card_section

    def test_yellow_between_threshold_and_one(self, tmp_path: Path) -> None:
        """Rework cycles between 0.3-1.0 should be yellow."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-rework-yellow",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"rework_cycles": 0.7},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        rework_idx = content.find("Rework")
        assert rework_idx != -1
        card_section = content[rework_idx : rework_idx + 500]
        assert "color-yellow" in card_section or "rework-yellow" in card_section

    def test_red_above_one(self, tmp_path: Path) -> None:
        """Rework cycles above 1.0 should be red."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-rework-red",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"rework_cycles": 1.5},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        rework_idx = content.find("Rework")
        assert rework_idx != -1
        card_section = content[rework_idx : rework_idx + 500]
        assert "color-red" in card_section or "rework-red" in card_section


class TestCostRange:
    """Cost shows min-max range."""

    def test_cost_range_shown(self, tmp_path: Path) -> None:
        """Cost card should show min-max range when samples exist."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "$8.00" in content or "8.00" in content
        assert "$25.00" in content or "25.00" in content


class TestComputeCostRange:
    """compute_cost_range helper tests."""

    def test_returns_min_max(self) -> None:
        """compute_cost_range should return min and max from sample costs."""
        from raki.report.html_report import compute_cost_range

        report = _make_report_with_samples()
        cost_min, cost_max = compute_cost_range(report)
        assert cost_min == pytest.approx(8.0)
        assert cost_max == pytest.approx(25.0)

    def test_returns_none_when_no_costs(self) -> None:
        """compute_cost_range should return None when no costs available."""
        from raki.report.html_report import compute_cost_range

        report = _make_minimal_report()
        result = compute_cost_range(report)
        assert result is None


class TestHasKnowledgeContext:
    """has_knowledge_context helper tests."""

    def test_false_when_no_context(self) -> None:
        """has_knowledge_context should return False when no phase has knowledge_context."""
        from raki.report.html_report import has_knowledge_context

        report = _make_report_with_samples()
        assert has_knowledge_context(report) is False

    def test_true_when_context_present(self) -> None:
        """has_knowledge_context should return True when any phase has knowledge_context."""
        from raki.model.phases import PhaseResult
        from raki.report.html_report import has_knowledge_context

        meta = _make_session_meta_helper("s1")
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                knowledge_context="reference docs here",
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="with-context",
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        assert has_knowledge_context(report) is True


class TestMetricLinksToInterpretingDocs:
    """Metric names link to docs/interpreting-results.md."""

    def test_metric_name_is_link(self, tmp_path: Path) -> None:
        """Metric names on score cards should be rendered as links."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-links",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 0.85},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "interpreting-results" in content
        assert "<a " in content


# --- Issue #68: Drill-down redesign tests ---


class TestDrillDownRowDataclass:
    """DrillDownRow frozen dataclass with verdict, detail, severity counts, cost, duration."""

    def test_drill_down_row_creation(self) -> None:
        """DrillDownRow should store session_id, verdict, detail, severity counts, cost, duration."""
        from raki.report.html_report import DrillDownRow

        row = DrillDownRow(
            session_id="session-101",
            verdict="fail",
            detail="implement failed",
            critical_count=2,
            major_count=0,
            minor_count=1,
            cost=4.20,
            duration_seconds=42,
            sort_key=(0, -4.20),
        )
        assert row.session_id == "session-101"
        assert row.verdict == "fail"
        assert row.detail == "implement failed"
        assert row.critical_count == 2
        assert row.major_count == 0
        assert row.minor_count == 1
        assert row.cost == pytest.approx(4.20)
        assert row.duration_seconds == 42
        assert row.sort_key == (0, -4.20)

    def test_drill_down_row_is_frozen(self) -> None:
        """DrillDownRow should be immutable (frozen dataclass)."""
        from raki.report.html_report import DrillDownRow

        row = DrillDownRow(
            session_id="session-101",
            verdict="pass",
            detail="5 phases",
            critical_count=0,
            major_count=0,
            minor_count=0,
            cost=8.50,
            duration_seconds=252,
            sort_key=(2, -8.50),
        )
        with pytest.raises(AttributeError):
            row.verdict = "fail"  # type: ignore[misc]


class TestDetermineVerdict:
    """determine_verdict: failed phase -> fail, rework_cycles > 0 -> rework, else pass."""

    def test_fail_when_phase_failed(self) -> None:
        """Session with a failed phase should have verdict 'fail'."""
        from raki.report.html_report import determine_verdict

        sample = make_sample("s1", verify_status="failed")
        assert determine_verdict(sample) == "fail"

    def test_rework_when_cycles_positive(self) -> None:
        """Session with rework_cycles > 0 but no failed phase should have verdict 'rework'."""
        from raki.report.html_report import determine_verdict

        sample = make_sample("s1", rework_cycles=2, verify_status="completed")
        assert determine_verdict(sample) == "rework"

    def test_pass_when_clean(self) -> None:
        """Session with no failed phases and 0 rework_cycles should have verdict 'pass'."""
        from raki.report.html_report import determine_verdict

        sample = make_sample("s1", rework_cycles=0, verify_status="completed")
        assert determine_verdict(sample) == "pass"

    def test_fail_takes_precedence_over_rework(self) -> None:
        """When both failed phase and rework_cycles > 0, verdict should be 'fail'."""
        from raki.report.html_report import determine_verdict

        sample = make_sample("s1", rework_cycles=2, verify_status="failed")
        assert determine_verdict(sample) == "fail"


class TestBuildDetail:
    """build_detail: "implement failed" / "2 cycles" / "5 phases"."""

    def test_detail_for_fail(self) -> None:
        """When a phase fails, detail should name the failed phase."""
        from raki.report.html_report import build_detail

        sample = make_sample("s1", verify_status="failed")
        detail = build_detail(sample)
        assert "verify failed" in detail

    def test_detail_for_rework(self) -> None:
        """When rework_cycles > 0 and no failure, detail should show cycle count."""
        from raki.report.html_report import build_detail

        sample = make_sample("s1", rework_cycles=2, verify_status="completed")
        detail = build_detail(sample)
        assert "2 cycles" in detail

    def test_detail_for_pass(self) -> None:
        """When clean pass, detail should show phase count."""
        from raki.report.html_report import build_detail

        sample = make_sample("s1", rework_cycles=0, verify_status="completed")
        detail = build_detail(sample)
        assert "phases" in detail


class TestComputeDuration:
    """_compute_duration: sum phase durations in seconds."""

    def test_sums_phase_durations(self) -> None:
        """Should sum all phase duration_ms values and convert to seconds."""
        from raki.model.phases import PhaseResult
        from raki.report.html_report import _compute_duration

        meta = SessionMeta(
            session_id="s1",
            started_at=datetime(2026, 4, 10, tzinfo=timezone.utc),
            total_phases=2,
            rework_cycles=0,
        )
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                duration_ms=60000,
            ),
            PhaseResult(
                name="verify",
                generation=1,
                status="completed",
                output="PASS",
                duration_ms=30000,
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        assert _compute_duration(sample) == 90

    def test_zero_when_no_duration_data(self) -> None:
        """Should return 0 when phases have no duration_ms."""
        from raki.report.html_report import _compute_duration

        sample = make_sample("s1")
        assert _compute_duration(sample) == 0


class TestFormatDuration:
    """_format_duration: format seconds as M:SS."""

    def test_format_minutes_seconds(self) -> None:
        """Should format 252 seconds as '4:12'."""
        from raki.report.html_report import _format_duration

        assert _format_duration(252) == "4:12"

    def test_format_zero(self) -> None:
        """Should format 0 seconds as '0:00'."""
        from raki.report.html_report import _format_duration

        assert _format_duration(0) == "0:00"

    def test_format_under_minute(self) -> None:
        """Should format 42 seconds as '0:42'."""
        from raki.report.html_report import _format_duration

        assert _format_duration(42) == "0:42"

    def test_format_exact_minutes(self) -> None:
        """Should format 120 seconds as '2:00'."""
        from raki.report.html_report import _format_duration

        assert _format_duration(120) == "2:00"

    def test_format_large_duration(self) -> None:
        """Should format 454 seconds as '7:34'."""
        from raki.report.html_report import _format_duration

        assert _format_duration(454) == "7:34"


class TestComputeDrillDownRows:
    """compute_drill_down_rows: build and sort rows with FAIL first, then REWORK, then PASS."""

    def test_sorts_fail_first(self) -> None:
        """FAIL rows should come before REWORK and PASS."""
        from raki.report.html_report import compute_drill_down_rows

        sample_fail = make_sample("s-fail", verify_status="failed", cost=4.20)
        sample_rework = make_sample("s-rework", rework_cycles=2, cost=26.10)
        sample_pass = make_sample("s-pass", rework_cycles=0, cost=8.50)
        sample_results = [
            SampleResult(sample=sample_pass, scores=[]),
            SampleResult(sample=sample_fail, scores=[]),
            SampleResult(sample=sample_rework, scores=[]),
        ]
        rows = compute_drill_down_rows(sample_results)
        assert rows[0].verdict == "fail"
        assert rows[1].verdict == "rework"
        assert rows[2].verdict == "pass"

    def test_cost_descending_within_verdict_group(self) -> None:
        """Within the same verdict group, rows should be sorted by cost descending."""
        from raki.report.html_report import compute_drill_down_rows

        sample_pass_cheap = make_sample("s-cheap", rework_cycles=0, cost=5.00)
        sample_pass_expensive = make_sample("s-expensive", rework_cycles=0, cost=20.00)
        sample_results = [
            SampleResult(sample=sample_pass_cheap, scores=[]),
            SampleResult(sample=sample_pass_expensive, scores=[]),
        ]
        rows = compute_drill_down_rows(sample_results)
        assert rows[0].session_id == "s-expensive"
        assert rows[1].session_id == "s-cheap"

    def test_severity_counts_from_findings(self) -> None:
        """Row severity counts should reflect actual findings."""
        from raki.report.html_report import compute_drill_down_rows

        findings = [
            ReviewFinding(reviewer="r1", severity="critical", issue="crit1"),
            ReviewFinding(reviewer="r1", severity="critical", issue="crit2"),
            ReviewFinding(reviewer="r1", severity="major", issue="maj1"),
        ]
        sample = make_sample("s1", rework_cycles=1, findings=findings)
        rows = compute_drill_down_rows([SampleResult(sample=sample, scores=[])])
        assert rows[0].critical_count == 2
        assert rows[0].major_count == 1
        assert rows[0].minor_count == 0

    def test_empty_sample_results_returns_empty(self) -> None:
        """Empty sample_results should return empty list."""
        from raki.report.html_report import compute_drill_down_rows

        rows = compute_drill_down_rows([])
        assert rows == []


class TestDrillDownRowsInHtml:
    """Drill-down rows render in HTML with verdict badges, borders, cost, and duration."""

    def test_verdict_badges_in_html(self, tmp_path: Path) -> None:
        """HTML drill-down should show FAIL/REWORK/PASS verdict badges."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # session-alpha has verify failed -> FAIL
        assert "verdict-fail" in content or "FAIL" in content
        # session-beta has rework_cycles=1 -> REWORK
        assert "verdict-rework" in content or "REWORK" in content
        # session-gamma has no rework/failure -> PASS
        assert "verdict-pass" in content or "PASS" in content

    def test_verdict_left_border_colors(self, tmp_path: Path) -> None:
        """Rows should have left border colored by verdict (red/yellow/none)."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "border-fail" in content or "border-left" in content

    def test_cost_shown_in_drilldown_row(self, tmp_path: Path) -> None:
        """Each drill-down row should show cost with dollar sign."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "$25.00" in content
        assert "$15.00" in content
        assert "$8.00" in content

    def test_severity_badges_on_fail_rework_only(self, tmp_path: Path) -> None:
        """Severity badges should appear on FAIL/REWORK rows but not on clean PASS rows."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # session-gamma is PASS with no findings -- should not have severity pills in row
        # Find the gamma session in the drill-down section (verdict-pass details element)
        drilldown_start = content.find("Per-Session Drill-Down")
        assert drilldown_start != -1
        gamma_idx = content.find("session-gamma", drilldown_start)
        assert gamma_idx != -1
        # Find the next summary/details boundary after gamma
        next_detail_idx = content.find("</summary>", gamma_idx)
        gamma_row = content[gamma_idx:next_detail_idx]
        assert "row-severity-pill-critical" not in gamma_row
        assert "row-severity-pill-major" not in gamma_row

    def test_drill_down_sorted_fail_first(self, tmp_path: Path) -> None:
        """In HTML, FAIL sessions should appear before REWORK which appear before PASS."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # session-alpha is FAIL (verify failed), session-beta is REWORK, session-gamma is PASS
        fail_pos = content.find("session-alpha")
        rework_pos = content.find("session-beta")
        pass_pos = content.find("session-gamma")
        assert fail_pos < rework_pos < pass_pos


class TestNeedsAttentionSection:
    """'Needs Attention' section above full drill-down with FAIL+REWORK count badge."""

    def test_needs_attention_present(self, tmp_path: Path) -> None:
        """When FAIL or REWORK sessions exist, 'Needs Attention' section should appear."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "needs-attention" in content.lower() or "Needs Attention" in content

    def test_needs_attention_count_badge(self, tmp_path: Path) -> None:
        """Needs Attention section should show count of FAIL+REWORK sessions."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # session-alpha (FAIL) + session-beta (REWORK) = 2
        assert "2 sessions need attention" in content.lower() or "2 session" in content.lower()

    def test_needs_attention_shows_only_fail_rework(self, tmp_path: Path) -> None:
        """Needs Attention section should only contain FAIL and REWORK sessions."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Find the Needs Attention heading in the HTML body (not CSS)
        attention_heading = content.find("Needs Attention")
        assert attention_heading != -1
        # The section should end before the full drill-down starts
        drilldown_idx = content.find("Per-Session Drill-Down", attention_heading)
        assert drilldown_idx != -1
        attention_section = content[attention_heading:drilldown_idx]
        # session-gamma (PASS) should NOT be in attention section
        assert "session-gamma" not in attention_section
        # session-alpha (FAIL) and session-beta (REWORK) should be present
        assert "session-alpha" in attention_section
        assert "session-beta" in attention_section

    def test_no_needs_attention_when_all_pass(self, tmp_path: Path) -> None:
        """When all sessions pass, Needs Attention section element should not be rendered."""
        from raki.report.html_report import write_html_report

        all_pass_sample = make_sample("s1", rework_cycles=0, cost=10.0)
        report = EvalReport(
            run_id="all-pass",
            aggregate_scores={"first_pass_success_rate": 1.0},
            sample_results=[SampleResult(sample=all_pass_sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The section element must not be rendered — CSS class name in <style> is OK
        assert 'class="needs-attention"' not in content


class TestDrillDownEmptyState:
    """Empty state when no session data."""

    def test_empty_state_message(self, tmp_path: Path) -> None:
        """When sample_results is empty, show message about --include-sessions."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "--include-sessions" in content


class TestDrillDownExpandedView:
    """Expanded view: phase timeline with status dots + duration, findings with severity."""

    def test_phase_timeline_in_expanded_view(self, tmp_path: Path) -> None:
        """Expanded session should show phase timeline with status dots."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Phase status dots
        assert "phase-status" in content
        assert "implement" in content
        assert "verify" in content

    def test_findings_with_severity_in_expanded_view(self, tmp_path: Path) -> None:
        """Expanded session should show findings with severity badges and file location."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "SQL injection vulnerability" in content
        assert "main.py" in content
        assert "severity-critical" in content or "critical" in content.lower()

    def test_reviewer_name_in_expanded_view(self, tmp_path: Path) -> None:
        """Expanded session should show reviewer name for findings."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "reviewer-1" in content or "reviewer" in content.lower()


class TestPassRowsClean:
    """PASS rows should be visually clean -- no severity badges unless minor findings exist."""

    def test_pass_row_no_badges_when_clean(self, tmp_path: Path) -> None:
        """PASS row with no findings should have no severity badges in the summary."""
        from raki.report.html_report import write_html_report

        clean_pass = make_sample("s-clean", rework_cycles=0, cost=6.80)
        report = EvalReport(
            run_id="clean-pass",
            aggregate_scores={},
            sample_results=[SampleResult(sample=clean_pass, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Find the summary row for s-clean
        clean_idx = content.find("s-clean")
        assert clean_idx != -1
        summary_end = content.find("</summary>", clean_idx)
        row_text = content[clean_idx:summary_end]
        # No severity pills in summary
        assert "critical" not in row_text.lower()
        assert "major" not in row_text.lower()

    def test_pass_row_shows_minor_badge_when_minor_findings(self, tmp_path: Path) -> None:
        """PASS row with minor findings should show minor badge."""
        from raki.report.html_report import write_html_report

        findings = [
            ReviewFinding(reviewer="r1", severity="minor", issue="Style issue"),
        ]
        minor_pass = make_sample("s-minor", rework_cycles=0, cost=8.50, findings=findings)
        report = EvalReport(
            run_id="minor-pass",
            aggregate_scores={},
            sample_results=[SampleResult(sample=minor_pass, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Find the summary row for s-minor
        minor_idx = content.find("s-minor")
        assert minor_idx != -1
        summary_end = content.find("</summary>", minor_idx)
        row_text = content[minor_idx:summary_end]
        assert "1 minor" in row_text or "minor" in row_text.lower()


class TestCollectAgentModels:
    """collect_agent_models helper — extracts distinct model IDs from sample results."""

    def test_empty_when_no_model_ids(self) -> None:
        """Returns empty list when no session has a model_id."""
        from raki.report.html_report import collect_agent_models

        report = _make_report_with_samples()
        assert collect_agent_models(report) == []

    def test_returns_unique_sorted_model_ids(self) -> None:
        """Returns a sorted, deduplicated list of model IDs."""
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import collect_agent_models

        sample_a = make_sample("s1", model_id="claude-opus-4")
        sample_b = make_sample("s2", model_id="claude-sonnet-4-6")
        sample_c = make_sample("s3", model_id="claude-opus-4")  # duplicate
        report = EvalReport(
            run_id="model-test",
            aggregate_scores={},
            sample_results=[
                SampleResult(sample=sample_a, scores=[]),
                SampleResult(sample=sample_b, scores=[]),
                SampleResult(sample=sample_c, scores=[]),
            ],
        )
        models = collect_agent_models(report)
        assert models == ["claude-opus-4", "claude-sonnet-4-6"]

    def test_single_model_id(self) -> None:
        """Returns a one-element list when all sessions use the same model."""
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import collect_agent_models

        sample = make_sample("s1", model_id="gemini-pro")
        report = EvalReport(
            run_id="single-model",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        assert collect_agent_models(report) == ["gemini-pro"]

    def test_ignores_none_model_ids(self) -> None:
        """Sessions with model_id=None are excluded from the result."""
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import collect_agent_models

        sample_with = make_sample("s1", model_id="claude-opus-4")
        sample_without = make_sample("s2", model_id=None)
        report = EvalReport(
            run_id="mixed-model",
            aggregate_scores={},
            sample_results=[
                SampleResult(sample=sample_with, scores=[]),
                SampleResult(sample=sample_without, scores=[]),
            ],
        )
        assert collect_agent_models(report) == ["claude-opus-4"]

    def test_empty_sample_results(self) -> None:
        """Returns empty list when sample_results is empty."""
        from raki.report.html_report import collect_agent_models

        report = _make_minimal_report()
        assert collect_agent_models(report) == []


class TestAgentModelInHtmlHeader:
    """Agent model IDs should appear in the HTML report header when present."""

    def test_agent_model_shown_in_html_header(self, tmp_path: Path) -> None:
        """When sessions have model_id, it should appear in the HTML header."""
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        sample = make_sample("s1", model_id="claude-opus-4")
        report = EvalReport(
            run_id="agent-model-html",
            aggregate_scores={"first_pass_success_rate": 0.9},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "claude-opus-4" in content
        assert "Agent model" in content

    def test_no_agent_model_line_when_absent(self, tmp_path: Path) -> None:
        """When no session has model_id, 'Agent model' should not appear in the header."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "Agent model" not in content

    def test_multiple_agent_models_joined(self, tmp_path: Path) -> None:
        """Multiple distinct model IDs should be shown joined by commas."""
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        sample_a = make_sample("s1", model_id="claude-opus-4")
        sample_b = make_sample("s2", model_id="claude-sonnet-4-6")
        report = EvalReport(
            run_id="multi-model-html",
            aggregate_scores={},
            sample_results=[
                SampleResult(sample=sample_a, scores=[]),
                SampleResult(sample=sample_b, scores=[]),
            ],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "claude-opus-4" in content
        assert "claude-sonnet-4-6" in content


# --- Metric health warnings in HTML report (ticket #162) ---


class TestMetricHealthWarningsInHTML:
    """Metric health warnings should appear in the HTML report when present."""

    def test_no_warnings_section_when_empty(self, tmp_path: Path) -> None:
        """When report.warnings is empty, no 'Metric Health' section should appear."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="no-warn-html",
            aggregate_scores={"first_pass_success_rate": 0.8},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "Metric Health" not in content

    def test_warnings_section_appears_when_warnings_present(self, tmp_path: Path) -> None:
        """When report.warnings has entries, the Metric Health section should appear."""
        from raki.model.report import MetricWarning
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="warn-html",
            aggregate_scores={"token_efficiency": 0.0},
            warnings=[
                MetricWarning(
                    metric_name="token_efficiency",
                    check="dead_metric",
                    severity="error",
                    message="Token efficiency is N/A for 98% of sessions.",
                )
            ],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "Metric Health" in content
        assert "dead_metric" in content
        assert "token_efficiency" in content

    def test_error_severity_uses_critical_badge(self, tmp_path: Path) -> None:
        """Error-severity warnings should use the severity-critical CSS class."""
        from raki.model.report import MetricWarning
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="error-badge-html",
            aggregate_scores={"token_efficiency": 0.0},
            warnings=[
                MetricWarning(
                    metric_name="token_efficiency",
                    check="dead_metric",
                    severity="error",
                    message="Dead metric.",
                )
            ],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "severity-critical" in content

    def test_warning_severity_uses_major_badge(self, tmp_path: Path) -> None:
        """Warning-severity warnings should use the severity-major CSS class."""
        from raki.model.report import MetricWarning
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="warn-badge-html",
            aggregate_scores={"first_pass_success_rate": 1.0},
            warnings=[
                MetricWarning(
                    metric_name="first_pass_success_rate",
                    check="degenerate_metric",
                    severity="warning",
                    message="Constant score of 1.0.",
                )
            ],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "severity-major" in content

    def test_warning_message_is_escaped_in_html(self, tmp_path: Path) -> None:
        """Warning message with HTML special chars should be escaped in output."""
        from raki.model.report import MetricWarning
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="escape-html",
            aggregate_scores={"some_metric": 0.5},
            warnings=[
                MetricWarning(
                    metric_name="some_metric",
                    check="dead_metric",
                    severity="error",
                    message="Score < 0.05 for all & every session.",
                )
            ],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Jinja2's autoescape should convert < to &lt; and & to &amp;
        assert "&lt;" in content
        assert "&amp;" in content


# --- Ticket #194: Phase output/transcript in HTML drill-down ---


class TestPhaseTranscriptInDrillDown:
    """Phase output/transcript is shown in the session drill-down when available."""

    def _make_report_with_phase_output(self, session_id: str, output_text: str) -> EvalReport:
        """Build a minimal report with one session whose phase has a known output string."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult

        meta = _make_session_meta_helper(session_id)
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output=output_text,
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        return EvalReport(
            run_id="transcript-test",
            aggregate_scores={"first_pass_success_rate": 1.0},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )

    def test_transcript_shown_when_include_sessions(self, tmp_path: Path) -> None:
        """Phase output should appear in HTML when include_sessions=True."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phase_output(
            "session-transcript-01",
            "Implementation complete. All tests pass.",
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        assert "Implementation complete. All tests pass." in content
        assert "phase-transcript" in content
        assert "View transcript" in content

    def test_transcript_hidden_when_stripped(self, tmp_path: Path) -> None:
        """Phase transcript should not appear when output is '<stripped>' (default mode)."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phase_output(
            "session-transcript-02",
            "Implementation complete. All tests pass.",
        )
        output = tmp_path / "report.html"
        # Default: include_sessions=False — phase.output becomes "<stripped>"
        write_html_report(report, output, include_sessions=False)
        content = output.read_text()
        # The raw output text should not appear; no transcript element either
        assert "Implementation complete. All tests pass." not in content
        assert "View transcript" not in content

    def test_transcript_content_is_html_escaped(self, tmp_path: Path) -> None:
        """Phase output with HTML special characters should be safely escaped."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phase_output(
            "session-escape-01",
            "Result: x < 10 & y > 0",
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # Jinja2 autoescape converts < > & to HTML entities
        assert "&lt;" in content or "x &lt; 10" in content
        assert "&amp;" in content or "&amp; y" in content
        # The raw unescaped string should NOT appear verbatim
        assert "x < 10 & y > 0" not in content

    def test_transcript_uses_preformatted_block(self, tmp_path: Path) -> None:
        """Phase transcript should be in a <pre> block with phase-transcript-content class."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phase_output(
            "session-pre-01",
            "line one\nline two",
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        assert "phase-transcript-content" in content
        assert "<pre" in content

    def test_no_transcript_element_when_output_is_empty(self, tmp_path: Path) -> None:
        """No transcript element should be rendered when phase output is an empty string."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        meta = _make_session_meta_helper("session-empty-output")
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="",
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="empty-output-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # Empty output should not render a transcript element
        assert "View transcript" not in content

    def test_multiple_phases_each_get_transcript(self, tmp_path: Path) -> None:
        """Every phase with non-empty output should get its own transcript block."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        meta = _make_session_meta_helper("session-multi-phase")
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="Implementation transcript here.",
            ),
            PhaseResult(
                name="verify",
                generation=1,
                status="completed",
                output="Verification transcript here.",
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="multi-phase-transcript",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        assert "Implementation transcript here." in content
        assert "Verification transcript here." in content
        # Both phases should have transcript elements
        assert content.count("View transcript") == 2


class TestHtmlReportHeaderEnrichment:
    """Tests for project identity and evaluation context in the HTML report header (ticket #236)."""

    def _make_report_with_config(self, config: dict) -> EvalReport:
        return EvalReport(
            run_id="eval-header-test",
            timestamp=datetime(2026, 4, 30, 10, 0, 0, tzinfo=timezone.utc),
            config=config,
            aggregate_scores={"first_pass_success_rate": 0.8},
        )

    def test_title_includes_project_name_when_set(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({"project_name": "my-cool-project"})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "my-cool-project" in content
        # Should appear in the <title> tag
        assert "my-cool-project" in content[: content.index("</title>")]

    def test_title_omits_project_name_when_empty(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({"project_name": ""})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        title_end = content.index("</title>")
        title_section = content[:title_end]
        # The separator "—" before project name should not appear in title
        assert "RAKI Evaluation Report" in title_section

    def test_header_shows_project_name(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({"project_name": "acme-rag"})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "acme-rag" in content

    def test_header_omits_project_name_when_absent_from_config(self, tmp_path: Path) -> None:
        """Old reports without project_name in config should render without error."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should still render successfully
        assert "RAKI Evaluation Report" in content

    def test_header_shows_docs_path_basename(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({"docs_path": "/home/user/project/docs"})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Basename should appear in the header
        assert "docs" in content
        # Full path should appear in the title tooltip attribute
        assert "/home/user/project/docs" in content

    def test_header_shows_not_configured_when_docs_absent(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "<strong>Docs:</strong>" in content
        assert "not configured" in content

    def test_header_shows_session_formats(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({"session_formats": ["alcove", "session-schema"]})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "alcove" in content
        assert "session-schema" in content

    def test_header_omits_format_when_absent(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_config({})
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "<strong>Format:</strong>" not in content

    def test_backward_compat_old_report_renders_without_error(self, tmp_path: Path) -> None:
        """Reports with no project_name / docs_path / session_formats in config
        must render without any errors (backward compatibility)."""
        from raki.report.html_report import write_html_report

        # Simulate an old report without any of the new fields
        report = EvalReport(
            run_id="old-report-001",
            timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            config={"llm_provider": None, "skip_judge": True, "metrics": []},
            aggregate_scores={"rework_cycles": 0.5},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert output.exists()
        assert "RAKI Evaluation Report" in content


# --- Ticket #249: Phase timeline ordering and dot coloring ---


class TestSortPhases:
    """sort_phases orders phases chronologically: (generation, PHASE_ORDER index)."""

    def _make_phase(
        self,
        name: str,
        generation: int = 1,
        status: str = "completed",
    ):
        from raki.model.phases import PhaseResult

        return PhaseResult(
            name=name,
            generation=generation,
            status=status,  # type: ignore[arg-type]
            output="done",
        )

    def test_sorts_by_phase_order(self) -> None:
        """Phases should be returned in PHASE_ORDER order regardless of input order."""
        from raki.report.html_report import sort_phases

        verify = self._make_phase("verify")
        implement = self._make_phase("implement")
        triage = self._make_phase("triage")
        sorted_phases = sort_phases([verify, implement, triage])
        assert [ph.name for ph in sorted_phases] == ["triage", "implement", "verify"]

    def test_sorts_generation_within_same_phase(self) -> None:
        """Multiple generations of same phase should be ordered by generation number."""
        from raki.report.html_report import sort_phases

        impl_gen2 = self._make_phase("implement", generation=2)
        impl_gen1 = self._make_phase("implement", generation=1)
        sorted_phases = sort_phases([impl_gen2, impl_gen1])
        assert sorted_phases[0].generation == 1
        assert sorted_phases[1].generation == 2

    def test_unknown_phase_goes_to_end(self) -> None:
        """Phases not in PHASE_ORDER should be sorted after all known phases."""
        from raki.report.html_report import sort_phases

        implement = self._make_phase("implement")
        custom = self._make_phase("custom-phase")
        sorted_phases = sort_phases([custom, implement])
        assert sorted_phases[0].name == "implement"
        assert sorted_phases[1].name == "custom-phase"

    def test_pipeline_phases_adds_unknown_names(self) -> None:
        """pipeline_phases contributes unknown phase names after PHASE_ORDER entries."""
        from raki.report.html_report import sort_phases

        implement = self._make_phase("implement")
        verify = self._make_phase("verify")
        custom_step = self._make_phase("await-review")
        sorted_phases = sort_phases(
            [custom_step, implement, verify],
            pipeline_phases=["await-review"],
        )
        assert sorted_phases[0].name == "implement"
        assert sorted_phases[1].name == "verify"
        assert sorted_phases[2].name == "await-review"

    def test_canonical_order_ignores_alphabetical_pipeline_phases(self) -> None:
        """pipeline_phases in alphabetical order should not override PHASE_ORDER."""
        from raki.report.html_report import sort_phases

        implement = self._make_phase("implement")
        verify = self._make_phase("verify")
        triage = self._make_phase("triage")
        sorted_phases = sort_phases(
            [implement, verify, triage],
            pipeline_phases=["implement", "triage", "verify"],
        )
        assert sorted_phases[0].name == "triage"
        assert sorted_phases[1].name == "implement"
        assert sorted_phases[2].name == "verify"

    def test_empty_list_returns_empty(self) -> None:
        """sort_phases on an empty list should return an empty list."""
        from raki.report.html_report import sort_phases

        assert sort_phases([]) == []

    def test_chronological_interleaving(self) -> None:
        """Rework cycles interleave by generation: impl(1)→verify(1)→impl(2)→verify(2)."""
        from raki.report.html_report import sort_phases

        triage = self._make_phase("triage", generation=1)
        plan = self._make_phase("plan", generation=1)
        impl1 = self._make_phase("implement", generation=1)
        verify1 = self._make_phase("verify", generation=1)
        impl2 = self._make_phase("implement", generation=2)
        verify2 = self._make_phase("verify", generation=2)
        review2 = self._make_phase("review", generation=2)

        sorted_phases = sort_phases([review2, verify2, impl2, verify1, impl1, plan, triage])
        names_gens = [(ph.name, ph.generation) for ph in sorted_phases]
        assert names_gens == [
            ("triage", 1),
            ("plan", 1),
            ("implement", 1),
            ("verify", 1),
            ("implement", 2),
            ("verify", 2),
            ("review", 2),
        ]


class TestPhaseTimelineDotColoring:
    """Phase status dots use correct colors: green gen-1, yellow rework (gen>1), red failed."""

    def _make_report_with_phases(self, phases: list):
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult

        meta = _make_session_meta_helper("session-dots")
        phase_results = [
            PhaseResult(
                name=ph["name"],
                generation=ph["generation"],
                status=ph["status"],
                output="done",
            )
            for ph in phases
        ]
        sample = EvalSample(session=meta, phases=phase_results, findings=[], events=[])
        return EvalReport(
            run_id="dot-color-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )

    def test_completed_gen1_phase_has_green_dot(self, tmp_path: Path) -> None:
        """Completed generation-1 phases should use the green status dot."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phases(
            [{"name": "implement", "generation": 1, "status": "completed"}]
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # Assert on the specific class attribute in the rendered <span> element, not
        # the CSS definition (which uses a leading dot: `.phase-status-completed`).
        assert 'class="phase-status phase-status-completed"' in content
        assert 'class="phase-status phase-status-rework"' not in content

    def test_rework_phase_gen2_has_rework_dot(self, tmp_path: Path) -> None:
        """A completed phase with generation > 1 should have the rework status dot class."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phases(
            [{"name": "implement", "generation": 2, "status": "completed"}]
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # Rework dot uses phase-status-rework class, not phase-status-completed.
        assert 'class="phase-status phase-status-rework"' in content
        assert 'class="phase-status phase-status-completed"' not in content

    def test_failed_phase_has_failed_dot(self, tmp_path: Path) -> None:
        """Failed phases should use the red failed status dot regardless of generation."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phases(
            [{"name": "verify", "generation": 1, "status": "failed"}]
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        assert 'class="phase-status phase-status-failed"' in content

    def test_skipped_phase_has_skipped_dot(self, tmp_path: Path) -> None:
        """Skipped phases should use the muted skipped status dot."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_phases(
            [{"name": "monitor", "generation": 1, "status": "skipped"}]
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        assert 'class="phase-status phase-status-skipped"' in content


# --- Ticket #250: Structured drill-down sections ---


class TestDrillDownSubSections:
    """Drill-down expanded view wraps Phases, Findings, and Metrics in collapsible <details>."""

    def test_drill_down_section_class_present(self, tmp_path: Path) -> None:
        """Expanded drill-down should use drill-down-section class for sub-sections."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "drill-down-section" in content

    def test_phases_subsection_is_collapsible(self, tmp_path: Path) -> None:
        """The Phases sub-section in the drill-down should use a <details> element."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # There should be a details.drill-down-section element containing phase info
        assert "drill-down-section" in content
        # The phases sub-section should have a summary label containing "Phases"
        assert "Phases" in content

    def test_findings_subsection_is_collapsible(self, tmp_path: Path) -> None:
        """The Findings sub-section in the drill-down should use a <details> element."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The findings sub-section should have a summary label containing "Findings"
        assert "Findings" in content
        assert "drill-down-section" in content

    def test_phases_count_in_summary_label(self, tmp_path: Path) -> None:
        """Phase sub-section summary should include the phase count like 'Phases (2)'."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        meta = _make_session_meta_helper("session-phasecount")
        phases = [
            PhaseResult(name="implement", generation=1, status="completed", output="done"),
            PhaseResult(name="verify", generation=1, status="completed", output="PASS"),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="phase-count-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The Phases sub-section summary should include the count (2)
        assert "Phases (2)" in content

    def test_findings_count_in_summary_label(self, tmp_path: Path) -> None:
        """Findings sub-section summary should include the finding count like 'Findings (2)'."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # session-alpha has 2 findings
        assert "Findings (2)" in content

    def test_metrics_subsection_present_when_scores_exist(self, tmp_path: Path) -> None:
        """When sample_result has scores, a Metrics sub-section should be present."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # There should be a Metrics section with score chips
        assert "Metrics" in content

    def test_no_findings_section_when_empty(self, tmp_path: Path) -> None:
        """When a session has no findings, the Findings sub-section should show empty state."""
        from raki.report.html_report import write_html_report

        clean_sample = make_sample("s-no-findings", rework_cycles=0, cost=5.0)
        report = EvalReport(
            run_id="no-findings-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=clean_sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "No review findings" in content


class TestDrillDownFilesModified:
    """Files-modified section appears in each phase item when PhaseResult.files_modified is set."""

    def _make_report_with_files(
        self,
        session_id: str,
        files: list[str],
    ) -> EvalReport:
        """Build a report with a phase that has files_modified populated."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult

        meta = _make_session_meta_helper(session_id)
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                files_modified=files,
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        return EvalReport(
            run_id="files-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )

    def test_files_modified_shown_when_present(self, tmp_path: Path) -> None:
        """When phase has files_modified, the file names should appear in the HTML drill-down."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_files(
            "session-files-01",
            ["src/raki/cli.py", "tests/test_cli.py"],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "src/raki/cli.py" in content
        assert "tests/test_cli.py" in content

    def test_no_files_section_when_empty(self, tmp_path: Path) -> None:
        """When phase has no files_modified, no files list should appear in the drill-down."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        meta = _make_session_meta_helper("session-no-files")
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                files_modified=[],
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="no-files-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The phase-file-item element should not appear when files_modified is empty
        # (the CSS class definition may still be in the <style> block, so check for the element)
        assert 'class="phase-file-item"' not in content

    def test_files_use_phase_files_class(self, tmp_path: Path) -> None:
        """Files modified list should use the phase-files CSS class."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_files(
            "session-files-css",
            ["main.py"],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "phase-files" in content

    def test_files_count_in_label(self, tmp_path: Path) -> None:
        """The files-modified section label should include the file count."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_files(
            "session-files-count",
            ["a.py", "b.py", "c.py"],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should show count "3 files" or "Files (3)"
        assert "3 file" in content or "files (3)" in content.lower()


class TestDrillDownToolCallCount:
    """Tool-call count badge appears on phase items when PhaseResult.tool_calls is non-empty."""

    def _make_report_with_tool_calls(
        self,
        session_id: str,
        tool_call_count: int,
    ) -> EvalReport:
        """Build a report with a phase that has tool_calls populated."""
        from raki.model.phases import PhaseResult, ToolCall
        from raki.model.report import EvalReport, SampleResult

        meta = _make_session_meta_helper(session_id)
        tool_calls = [
            ToolCall(name=f"tool_{idx}", arguments={"arg": idx}) for idx in range(tool_call_count)
        ]
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                tool_calls=tool_calls,
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        return EvalReport(
            run_id="tool-call-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )

    def test_tool_call_count_shown_when_present(self, tmp_path: Path) -> None:
        """When phase has tool_calls, the count should appear in the phase item."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_tool_calls("session-tools-01", tool_call_count=5)
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # Should show "5 tool calls" — match the exact rendered phrase for precision
        assert "5 tool calls" in content
        assert 'class="tool-call-count"' in content

    def test_no_tool_count_when_empty(self, tmp_path: Path) -> None:
        """When phase has no tool_calls, no tool count badge should appear."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report

        meta = _make_session_meta_helper("session-no-tools")
        phases = [
            PhaseResult(
                name="implement",
                generation=1,
                status="completed",
                output="done",
                tool_calls=[],
            ),
        ]
        sample = EvalSample(session=meta, phases=phases, findings=[], events=[])
        report = EvalReport(
            run_id="no-tools-test",
            aggregate_scores={},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The tool-call-count element should not appear when tool_calls is empty.
        # The CSS class definition may be present in the <style> block, so check
        # that no actual HTML element uses the class.
        assert 'class="tool-call-count"' not in content

    def test_tool_call_count_uses_css_class(self, tmp_path: Path) -> None:
        """Tool call count badge should use the tool-call-count CSS class."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_tool_calls("session-tools-css", tool_call_count=3)
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "tool-call-count" in content


class TestStructuredDetailSections:
    """Tests for output_structured rendering as formatted HTML inline per-phase."""

    @staticmethod
    def _make_report_with_structured(
        session_id: str,
        phase_name: str,
        output_structured: dict,
    ) -> EvalReport:
        from raki.model.dataset import EvalSample, SessionMeta
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult

        meta = SessionMeta(
            session_id=session_id,
            started_at=datetime(2026, 5, 15, tzinfo=timezone.utc),
            total_phases=1,
            rework_cycles=0,
            total_cost_usd=5.0,
        )
        phase = PhaseResult(
            name=phase_name,
            generation=1,
            status="completed",
            output="done",
            output_structured=output_structured,
        )
        sample = EvalSample(session=meta, phases=[phase], findings=[], events=[])
        return EvalReport(
            run_id="test-structured",
            sample_results=[SampleResult(sample=sample, scores=[])],
        )

    def test_triage_approach_renders(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-tri",
            "triage",
            {
                "approach": "Add a new metric to the operational tier",
                "complexity": "medium",
                "code_area": "src/raki/metrics/operational",
                "files": ["metric.py", "test_metric.py"],
                "risks": ["May break existing tests"],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "structured-detail" in content
        assert "Add a new metric to the operational tier" in content
        assert "medium" in content
        assert "metric.py" in content
        assert "May break existing tests" in content

    def test_plan_tasks_render_as_list(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-plan",
            "plan",
            {
                "tasks": [
                    {"id": "1", "description": "Write failing test for the new metric"},
                    {"id": "2", "description": "Implement the metric class"},
                ],
                "verification": {"commands": ["uv run pytest tests/ -v"]},
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "Plan (2 tasks)" in content
        assert "Write failing test for the new metric" in content
        assert "Implement the metric class" in content
        assert "uv run pytest tests/ -v" in content

    def test_implement_files_changed_render(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-impl",
            "implement",
            {
                "files_changed": [
                    {"path": "src/metric.py", "action": "added"},
                    {"path": "src/cli.py", "action": "modified"},
                ],
                "commits": [{"message": "feat: add new metric"}],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "2 files changed" in content
        assert "src/metric.py" in content
        assert "src/cli.py" in content
        assert "file-action-A" in content
        assert "file-action-M" in content
        assert "feat: add new metric" in content

    def test_verify_fail_renders_expanded(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-ver",
            "verify",
            {
                "verdict": "FAIL",
                "command_results": [
                    {"command": "pytest tests/", "exit_code": 1, "passed": False},
                    {"command": "ruff check src/", "exit_code": 0, "passed": True},
                ],
                "fixes_required": ["Fix failing test assertions"],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "verdict-inline-fail" in content
        assert "FAIL" in content
        assert "pytest tests/" in content
        assert "ruff check src/" in content
        assert "Fix failing test assertions" in content

    def test_verify_pass_renders_collapsed(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-ver-pass",
            "verify",
            {
                "verdict": "PASS",
                "command_results": [
                    {"command": "pytest tests/", "exit_code": 0, "passed": True},
                ],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "verdict-inline-pass" in content
        assert 'structured-detail" open' not in content.replace(
            'structured-detail"', 'structured-detail"'
        )

    def test_review_verdict_renders(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-rev",
            "review",
            {
                "verdict": "approve",
                "findings": [
                    {"severity": "MINOR", "file": "cli.py", "issue": "Unused import"},
                ],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "verdict-inline-pass" in content
        assert "approve" in content
        assert "1 finding" in content

    def test_no_structured_section_without_data(self, tmp_path: Path) -> None:
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured("sess-empty", "implement", {})
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert '<details class="structured-detail"' not in content

    def test_structured_renders_without_include_sessions(self, tmp_path: Path) -> None:
        """Structured sections should render even without --include-sessions."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-stripped",
            "triage",
            {
                "approach": "Visible even when stripped",
                "complexity": "small",
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=False, session_count=1)
        content = output.read_text()
        assert "Visible even when stripped" in content
        assert "structured-detail" in content

    def test_verify_command_fail_shows_cross(self, tmp_path: Path) -> None:
        """exit_code=1 with passed=True must show ✗, not ✓."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-ver-cross",
            "verify",
            {
                "verdict": "FAIL",
                "command_results": [
                    {"command": "go test ./...", "exit_code": 1, "passed": True},
                ],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "✗" in content
        assert "go test ./..." in content
        # Must NOT show a checkmark for a failed command
        assert "✓" not in content

    def test_verify_command_pass_shows_check(self, tmp_path: Path) -> None:
        """exit_code=0 must show ✓."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-ver-check",
            "verify",
            {
                "verdict": "PASS",
                "command_results": [
                    {"command": "uv run pytest tests/", "exit_code": 0, "passed": True},
                ],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "✓" in content
        assert "uv run pytest tests/" in content
        assert "✗" not in content

    def test_verify_command_no_exit_code_uses_passed(self, tmp_path: Path) -> None:
        """When exit_code is absent, fall back to cmd.passed for ✓/✗."""
        from raki.report.html_report import write_html_report

        report = self._make_report_with_structured(
            "sess-ver-fallback",
            "verify",
            {
                "verdict": "PASS",
                "command_results": [
                    {"command": "ruff check src/", "passed": True},
                    {"command": "mypy src/", "passed": False},
                ],
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True, session_count=1)
        content = output.read_text()
        assert "✓" in content
        assert "✗" in content
        assert "ruff check src/" in content
        assert "mypy src/" in content


class TestStripSessionDataPreservesStructured:
    """Tests for strip_session_data preserving curated output_structured fields."""

    def test_preserves_display_fields(self) -> None:
        from raki.report.json_report import strip_session_data

        data = {
            "sample_results": [
                {
                    "sample": {
                        "phases": [
                            {
                                "output": "raw text",
                                "output_structured": {
                                    "verdict": "PASS",
                                    "approach": "do the thing",
                                    "raw_output": "should be stripped",
                                    "knowledge_context": "also stripped",
                                },
                            }
                        ],
                        "events": [],
                    },
                }
            ],
        }
        strip_session_data(data)
        structured = data["sample_results"][0]["sample"]["phases"][0]["output_structured"]
        assert structured is not None
        assert "verdict" in structured
        assert "approach" in structured
        assert "raw_output" not in structured
        assert "knowledge_context" not in structured

    def test_sets_none_when_no_display_fields(self) -> None:
        from raki.report.json_report import strip_session_data

        data = {
            "sample_results": [
                {
                    "sample": {
                        "phases": [
                            {
                                "output": "raw text",
                                "output_structured": {
                                    "raw_output": "nothing useful",
                                    "ticket_key": "123",
                                },
                            }
                        ],
                        "events": [],
                    },
                }
            ],
        }
        strip_session_data(data)
        structured = data["sample_results"][0]["sample"]["phases"][0]["output_structured"]
        assert structured is None

    def test_handles_none_output_structured(self) -> None:
        from raki.report.json_report import strip_session_data

        data = {
            "sample_results": [
                {
                    "sample": {
                        "phases": [{"output": "raw", "output_structured": None}],
                        "events": [],
                    },
                }
            ],
        }
        strip_session_data(data)
        assert "output_structured" not in data["sample_results"][0]["sample"]["phases"][0]


# --- Issue #287: Severity distribution chart and zone coloring fixes ---


class TestSeverityDistributionPercentageRounding:
    """Stacked bar percentages must sum to exactly 100.0 (no floating-point gap)."""

    def test_pcts_sum_to_100_with_equal_counts(self) -> None:
        """critical_pct + major_pct + minor_pct must equal 100.0 for equal counts.

        With 1 of each type (total=3), naive division gives 33.333...% each, which
        sums to 99.999...% — leaving a visible gap in the stacked bar chart.
        """
        from raki.report.html_report import SeverityDistribution

        dist = SeverityDistribution(critical=1, major=1, minor=1, label="Severe", total=3)
        total_pct = dist.critical_pct + dist.major_pct + dist.minor_pct
        assert total_pct == 100.0

    def test_pcts_sum_to_100_with_prime_total(self) -> None:
        """Percentages must sum to 100.0 when total doesn't divide evenly by 100."""
        from raki.report.html_report import SeverityDistribution

        dist = SeverityDistribution(critical=7, major=3, minor=2, label="Severe", total=12)
        total_pct = dist.critical_pct + dist.major_pct + dist.minor_pct
        assert total_pct == 100.0

    def test_minor_pct_is_100_minus_others(self) -> None:
        """minor_pct must equal 100.0 - critical_pct - major_pct (no rounding gap)."""
        from raki.report.html_report import SeverityDistribution

        dist = SeverityDistribution(critical=1, major=1, minor=1, label="Severe", total=3)
        expected_minor = 100.0 - dist.critical_pct - dist.major_pct
        assert dist.minor_pct == expected_minor

    def test_pcts_sum_to_100_with_only_critical(self) -> None:
        """With only critical findings, critical_pct must be 100.0."""
        from raki.report.html_report import SeverityDistribution

        dist = SeverityDistribution(critical=5, major=0, minor=0, label="Severe", total=5)
        assert dist.critical_pct == 100.0
        assert dist.major_pct == 0.0
        assert dist.minor_pct == 0.0
        assert dist.critical_pct + dist.major_pct + dist.minor_pct == 100.0

    def test_pcts_all_zero_when_no_findings(self) -> None:
        """With no findings, all percentages must be 0.0."""
        from raki.report.html_report import SeverityDistribution

        dist = SeverityDistribution(critical=0, major=0, minor=0, label="Clean", total=0)
        assert dist.critical_pct == 0.0
        assert dist.major_pct == 0.0
        assert dist.minor_pct == 0.0


class TestSeverityLabelZoneColoring:
    """Severity distribution label badge colors must match the standard zone system.

    The 4-tier label system maps to zones:
    - 'Clean'    → green  (no issues at all)
    - 'Minor'    → yellow (major findings present, no critical) [CAUTION zone]
    - 'Moderate' → red    (critical findings present but not dominant) [DANGER zone]
    - 'Severe'   → red    (many critical findings) [DANGER zone]
    """

    def test_severity_label_minor_uses_yellow_not_lime(self, tmp_path: Path) -> None:
        """The 'Minor' severity label badge must use yellow (caution), not lime green.

        'Minor' means there are MAJOR findings (just no critical). Major findings
        warrant a caution (yellow) signal, not an 'almost clean' lime-green signal.
        """
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()

        style_start = content.find("<style>")
        style_end = content.find("</style>")
        assert style_start != -1 and style_end != -1
        style_block = content[style_start:style_end]

        # Locate the .severity-label-minor CSS rule
        minor_rule_start = style_block.find(".severity-label-minor")
        assert minor_rule_start != -1, ".severity-label-minor CSS rule not found"
        minor_rule_end = style_block.find("}", minor_rule_start)
        minor_css = style_block[minor_rule_start:minor_rule_end]

        # Must NOT use lime green (--severity-minor)
        assert "var(--severity-minor)" not in minor_css, (
            ".severity-label-minor uses lime green (--severity-minor), expected yellow (--yellow)"
        )
        # Must use standard yellow zone color
        assert "var(--yellow)" in minor_css, (
            ".severity-label-minor should use var(--yellow) for the caution zone"
        )

    def test_severity_label_minor_badge_background_uses_yellow_rgba(self, tmp_path: Path) -> None:
        """The 'Minor' badge background should use yellow-tinted rgba, not lime-tinted."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()

        style_start = content.find("<style>")
        style_end = content.find("</style>")
        style_block = content[style_start:style_end]

        minor_rule_start = style_block.find(".severity-label-minor")
        assert minor_rule_start != -1
        minor_rule_end = style_block.find("}", minor_rule_start)
        minor_css = style_block[minor_rule_start:minor_rule_end]

        # Lime-tinted background rgba(139, 195, 58, 0.2) must NOT appear
        assert "rgba(139, 195, 58" not in minor_css, (
            ".severity-label-minor uses lime background color; should use yellow"
        )

    def test_severity_label_moderate_uses_red_not_orange(self, tmp_path: Path) -> None:
        """The 'Moderate' severity label badge must use red (danger), not orange.

        'Moderate' means critical findings ARE present — always in the DANGER zone.
        Orange (--severity-major) is the color for major-level findings,
        but the label should reflect that critical findings are present.
        """
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()

        style_start = content.find("<style>")
        style_end = content.find("</style>")
        assert style_start != -1 and style_end != -1
        style_block = content[style_start:style_end]

        moderate_rule_start = style_block.find(".severity-label-moderate")
        assert moderate_rule_start != -1, ".severity-label-moderate CSS rule not found"
        moderate_rule_end = style_block.find("}", moderate_rule_start)
        moderate_css = style_block[moderate_rule_start:moderate_rule_end]

        # Must NOT use orange (--severity-major) — critical findings present
        assert "var(--severity-major)" not in moderate_css, (
            ".severity-label-moderate uses orange (--severity-major), expected red (--red)"
        )
        # Must use red zone color
        assert "var(--red)" in moderate_css, (
            ".severity-label-moderate should use var(--red) since critical findings are present"
        )


# --- Issue #287: Zone threshold boundary tests ---


class TestZoneThresholdBoundaries:
    """Boundary tests for zone coloring thresholds (sourced from ZONE_THRESHOLDS)."""

    # --- Score (0-1) boundaries ---

    def test_score_0_85_is_green(self) -> None:
        """Score exactly at 0.85 should be green (green >= 0.85)."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.85, higher_is_better=True) == "green"

    def test_score_0_8499_is_amber(self) -> None:
        """Score just below 0.85 should be amber."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.8499, higher_is_better=True) == "yellow"

    def test_score_0_60_is_amber(self) -> None:
        """Score exactly at 0.60 should be amber (amber >= 0.60)."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.60, higher_is_better=True) == "yellow"

    def test_score_0_5999_is_red(self) -> None:
        """Score just below 0.60 should be red."""
        from raki.report.html_report import html_color_for_score

        assert html_color_for_score(0.5999, higher_is_better=True) == "red"

    # --- Cost (currency) boundaries ---

    def test_cost_5_is_green(self) -> None:
        """Cost exactly at $5 should be green (green <= $5)."""
        from raki.report.html_report import html_color_for_score

        assert (
            html_color_for_score(5.0, higher_is_better=False, display_format="currency") == "green"
        )

    def test_cost_5_01_is_amber(self) -> None:
        """Cost just above $5 should be amber."""
        from raki.report.html_report import html_color_for_score

        assert (
            html_color_for_score(5.01, higher_is_better=False, display_format="currency")
            == "yellow"
        )

    def test_cost_15_is_amber(self) -> None:
        """Cost exactly at $15 should be amber (amber <= $15)."""
        from raki.report.html_report import html_color_for_score

        assert (
            html_color_for_score(15.0, higher_is_better=False, display_format="currency")
            == "yellow"
        )

    def test_cost_15_01_is_red(self) -> None:
        """Cost just above $15 should be red."""
        from raki.report.html_report import html_color_for_score

        assert (
            html_color_for_score(15.01, higher_is_better=False, display_format="currency") == "red"
        )

    # --- Rework cycles boundaries ---

    def test_rework_0_3_is_green(self) -> None:
        """Rework cycles exactly at 0.3 should be green (green <= 0.3)."""
        from raki.report.html_report import rework_cycles_color

        assert rework_cycles_color(0.3) == "green"

    def test_rework_0_31_is_amber(self) -> None:
        """Rework cycles just above 0.3 should be amber."""
        from raki.report.html_report import rework_cycles_color

        assert rework_cycles_color(0.31) == "yellow"

    def test_rework_1_0_is_amber(self) -> None:
        """Rework cycles exactly at 1.0 should be amber (amber <= 1.0)."""
        from raki.report.html_report import rework_cycles_color

        assert rework_cycles_color(1.0) == "yellow"

    def test_rework_1_01_is_red(self) -> None:
        """Rework cycles just above 1.0 should be red."""
        from raki.report.html_report import rework_cycles_color

        assert rework_cycles_color(1.01) == "red"


class TestMetricContextCards:
    """Task 1: metric-context sub-text for triage_calibration and file_prediction_accuracy."""

    def test_triage_calibration_shows_threshold_context(self, tmp_path: Path) -> None:
        """Triage calibration card shows static threshold context text."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-triage-ctx",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"triage_calibration": 0.75},
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "metric-context" in content
        # Threshold text for triage calibration
        assert "80%" in content or "calibrated" in content

    def test_file_prediction_accuracy_shows_precision_recall(self, tmp_path: Path) -> None:
        """File prediction accuracy card shows micro precision and recall from metric_details."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-file-pred-ctx",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"file_prediction_accuracy": 0.72},
            metric_details={
                "file_prediction_accuracy": {
                    "micro_precision": 0.80,
                    "micro_recall": 0.65,
                    "sessions_with_file_predictions": 5,
                }
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "metric-context" in content
        # Precision and recall values should appear
        assert "80%" in content
        assert "65%" in content


class TestScoreChipTooltips:
    """Task 2: score chips in per-session drill-down have hover tooltips from metric description."""

    def test_score_chip_has_title_attribute_with_description(self, tmp_path: Path) -> None:
        """Score chips in drill-down Metrics section carry a title= tooltip from metric_metadata."""
        from raki.report.html_report import write_html_report

        sample = make_sample("sess-tooltip", rework_cycles=0, cost=10.0)
        metric = MetricResult(
            name="faithfulness",
            score=0.90,
            sample_scores={"sess-tooltip": 0.90},
        )
        report = EvalReport(
            run_id="eval-chip-tooltip",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"faithfulness": 0.90},
            sample_results=[SampleResult(sample=sample, scores=[metric])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # score-chip span should have title= attribute with the metric description
        assert 'class="score-chip"' in content
        assert 'title="' in content
        # faithfulness description from METRIC_METADATA
        assert "Fraction of claims supported by retrieved context" in content


class TestRetrievalSectionCollapsed:
    """Task 3: empty Retrieval Quality section shows only a footnote, no category-section div."""

    def test_no_category_section_when_no_retrieval_scores(self, tmp_path: Path) -> None:
        """When has_retrieval=True but no retrieval scores, no category-section div is rendered."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-no-ret-scores",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.80,
                "rework_cycles": 1.0,
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, has_retrieval=True)
        content = output.read_text()
        # The footnote should appear instead of a full category-section
        assert 'class="footnote"' in content
        assert "Retrieval" in content
        # No category-section with Retrieval Quality label should be present
        assert "Retrieval Quality" not in content

    def test_no_category_section_when_has_retrieval_false(self, tmp_path: Path) -> None:
        """When has_retrieval=False, no category-section div is rendered for retrieval."""
        from raki.report.html_report import write_html_report

        report = EvalReport(
            run_id="eval-has-ret-false",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={
                "first_pass_success_rate": 0.80,
            },
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, has_retrieval=False)
        content = output.read_text()
        # The footnote should appear instead of a full category-section
        assert 'class="footnote"' in content
        assert "Retrieval" in content
        # No category-section with Retrieval Quality label
        assert "Retrieval Quality" not in content


class TestTruncateTranscript:
    """Task 1 (ticket 285): truncate_transcript() helper function tests."""

    def test_long_transcript_is_truncated(self) -> None:
        """Transcript with >100 lines is truncated to first 50 + last 50 lines."""
        from raki.report.html_report import truncate_transcript

        lines = [f"line {i}" for i in range(1, 152)]  # 151 lines
        transcript = "\n".join(lines)
        result = truncate_transcript(transcript)
        result_lines = result.splitlines()

        # First 50 lines preserved
        assert result_lines[0] == "line 1"
        assert result_lines[49] == "line 50"
        # Last 50 lines preserved
        assert result_lines[-50] == "line 102"
        assert result_lines[-1] == "line 151"
        # Total = 50 + 1 marker + 50 = 101
        assert len(result_lines) == 101

    def test_short_transcript_unchanged(self) -> None:
        """Transcript with <=100 lines is returned unchanged."""
        from raki.report.html_report import truncate_transcript

        lines = [f"line {i}" for i in range(1, 51)]  # 50 lines
        transcript = "\n".join(lines)
        result = truncate_transcript(transcript)
        assert result == transcript

    def test_exact_threshold_transcript_unchanged(self) -> None:
        """Transcript with exactly 100 lines is returned unchanged (boundary)."""
        from raki.report.html_report import truncate_transcript

        lines = [f"line {i}" for i in range(1, 101)]  # exactly 100 lines
        transcript = "\n".join(lines)
        result = truncate_transcript(transcript)
        assert result == transcript

    def test_marker_text_correct(self) -> None:
        """The truncation marker contains the omitted-lines count."""
        from raki.report.html_report import truncate_transcript

        lines = [f"line {i}" for i in range(1, 202)]  # 201 lines, omits 101
        transcript = "\n".join(lines)
        result = truncate_transcript(transcript)
        # Marker should mention the number of omitted lines (201 - 100 = 101)
        assert "101" in result
        # Marker is between first 50 and last 50
        result_lines = result.splitlines()
        marker_line = result_lines[50]
        assert "101" in marker_line


class TestTruncateTranscriptIntegration:
    """Task 2 (ticket 285): truncate_transcript Jinja filter integration tests."""

    def test_long_transcript_truncated_in_html_output(self, tmp_path: Path) -> None:
        """Phase transcript >100 lines is truncated in HTML report output."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.report.html_report import write_html_report
        from raki.model.dataset import EvalSample, SessionMeta
        from datetime import datetime, timezone

        long_output = "\n".join(f"line {i}" for i in range(1, 152))  # 151 lines

        meta = SessionMeta(
            session_id="sess-long-transcript",
            started_at=datetime(2026, 4, 10, tzinfo=timezone.utc),
            total_phases=1,
            rework_cycles=0,
            total_cost_usd=5.0,
        )
        phase = PhaseResult(
            name="implement",
            generation=1,
            status="completed",
            output=long_output,
        )
        sample_with_long = EvalSample(
            session=meta,
            phases=[phase],
            findings=[],
            events=[],
        )
        report = EvalReport(
            run_id="eval-long-transcript",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 1.0},
            sample_results=[SampleResult(sample=sample_with_long, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # Truncation marker should appear in HTML
        assert "lines omitted" in content
        # Full transcript should NOT be present (line 75 is in the omitted range)
        assert "line 75" not in content

    def test_short_transcript_not_truncated_in_html_output(self, tmp_path: Path) -> None:
        """Phase transcript <=100 lines is rendered fully in HTML report output."""
        from raki.model.phases import PhaseResult
        from raki.model.report import EvalReport, SampleResult
        from raki.model.dataset import EvalSample, SessionMeta
        from raki.report.html_report import write_html_report
        from datetime import datetime, timezone

        short_output = "\n".join(f"output line {i}" for i in range(1, 51))  # 50 lines
        meta = SessionMeta(
            session_id="sess-short-transcript",
            started_at=datetime(2026, 4, 10, tzinfo=timezone.utc),
            total_phases=1,
            rework_cycles=0,
            total_cost_usd=5.0,
        )
        phase = PhaseResult(
            name="implement",
            generation=1,
            status="completed",
            output=short_output,
        )
        sample = EvalSample(
            session=meta,
            phases=[phase],
            findings=[],
            events=[],
        )
        report = EvalReport(
            run_id="eval-short-transcript",
            timestamp=datetime(2026, 4, 18, 12, 0, 0, tzinfo=timezone.utc),
            aggregate_scores={"first_pass_success_rate": 1.0},
            sample_results=[SampleResult(sample=sample, scores=[])],
        )
        output = tmp_path / "report.html"
        write_html_report(report, output, include_sessions=True)
        content = output.read_text()
        # All 50 lines should be present
        assert "output line 1" in content
        assert "output line 50" in content
        # No truncation marker
        assert "lines omitted" not in content


# ---------------------------------------------------------------------------
# Task 1 — Sticky nav + section id attributes
# ---------------------------------------------------------------------------


class TestHtmlNavigation:
    """Sticky navigation bar with section anchors (ticket #286 Task 1)."""

    def test_section_scores_id(self, tmp_path: Path) -> None:
        """The Aggregate Scores section should have id='section-scores'."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="section-scores"' in content

    def test_section_drilldown_id(self, tmp_path: Path) -> None:
        """The Per-Session Drill-Down section should have id='section-drilldown'."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="section-drilldown"' in content

    def test_section_failures_id_when_present(self, tmp_path: Path) -> None:
        """The Recurring Failures section should have id='section-failures' when shown."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_recurring_failures()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="section-failures"' in content

    def test_section_attention_id_when_present(self, tmp_path: Path) -> None:
        """The Needs Attention section should have id='section-attention' when shown."""
        from raki.report.html_report import write_html_report

        # session-alpha has verify_status="failed" so needs_attention_count > 0
        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="section-attention"' in content

    def test_sticky_nav_element_present(self, tmp_path: Path) -> None:
        """Report should contain a <nav id='report-nav'> element."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="report-nav"' in content

    def test_nav_anchor_scores(self, tmp_path: Path) -> None:
        """Nav bar should contain a link to #section-scores."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'href="#section-scores"' in content

    def test_nav_anchor_drilldown(self, tmp_path: Path) -> None:
        """Nav bar should contain a link to #section-drilldown."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'href="#section-drilldown"' in content

    def test_nav_failures_link_conditional(self, tmp_path: Path) -> None:
        """'Failures' nav link should only appear when recurring failures exist."""
        from raki.report.html_report import write_html_report

        # Minimal report has no findings → no recurring failures
        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'href="#section-failures"' not in content

    def test_nav_failures_link_shown_when_failures_exist(self, tmp_path: Path) -> None:
        """'Failures' nav link should appear when recurring failures are present."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_recurring_failures()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'href="#section-failures"' in content

    def test_nav_attention_link_conditional(self, tmp_path: Path) -> None:
        """Attention nav link should only appear when needs_attention_count > 0."""
        from raki.report.html_report import write_html_report

        # Minimal report has no sample results → no failing sessions
        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'href="#section-attention"' not in content

    def test_nav_sticky_css(self, tmp_path: Path) -> None:
        """Nav bar should use 'position: sticky' CSS."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "position: sticky" in content or "position:sticky" in content

    def test_scroll_margin_top_css(self, tmp_path: Path) -> None:
        """Sections should have scroll-margin-top to prevent sticky nav overlap."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "scroll-margin-top" in content


# ---------------------------------------------------------------------------
# Task 2 — data attributes on session details + sort-bar markup
# ---------------------------------------------------------------------------


class TestHtmlSortBar:
    """Data attributes on session <details> + sort-bar pill buttons (ticket #286 Task 2)."""

    def test_data_verdict_attribute(self, tmp_path: Path) -> None:
        """Session <details> elements should carry a data-verdict attribute."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'data-verdict="' in content

    def test_data_cost_attribute(self, tmp_path: Path) -> None:
        """Session <details> elements should carry a data-cost attribute."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'data-cost="' in content

    def test_data_rework_attribute(self, tmp_path: Path) -> None:
        """Session <details> elements should carry a data-rework attribute."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'data-rework="' in content

    def test_sort_bar_element_present(self, tmp_path: Path) -> None:
        """Sort bar with id='sort-bar' should be present in the drill-down section."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="sort-bar"' in content

    def test_sort_bar_attention_element_present(self, tmp_path: Path) -> None:
        """Sort bar with id='sort-bar-attention' should be present in the Needs Attention section."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'id="sort-bar-attention"' in content

    def test_sort_pill_verdict(self, tmp_path: Path) -> None:
        """Sort bar should contain a pill button for verdict sorting."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'data-sort="verdict"' in content

    def test_sort_pill_cost(self, tmp_path: Path) -> None:
        """Sort bar should contain a pill button for cost sorting."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'data-sort="cost"' in content

    def test_sort_pill_rework(self, tmp_path: Path) -> None:
        """Sort bar should contain a pill button for rework sorting."""
        from raki.report.html_report import write_html_report

        report = _make_report_with_samples()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert 'data-sort="rework"' in content

    def test_sort_bar_css_present(self, tmp_path: Path) -> None:
        """CSS for the sort bar and pill buttons should be present in the <style> block."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert ".sort-bar" in content
        assert ".sort-pill" in content


# ---------------------------------------------------------------------------
# Task 3 — Client-side JS: sort logic, ▲/▼ indicators, IntersectionObserver
# ---------------------------------------------------------------------------


class TestHtmlSortJS:
    """Client-side sort JS and IntersectionObserver (ticket #286 Task 3)."""

    def test_sort_js_reorders_sessions(self, tmp_path: Path) -> None:
        """Sort JS should reference data-sort attribute and contain sort logic."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # JS should reference the sort attribute and do comparisons
        assert "data-sort" in content
        assert "sort" in content

    def test_direction_indicator_asc(self, tmp_path: Path) -> None:
        """Direction indicator ▲ for ascending sort should appear in the JS/HTML."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "▲" in content

    def test_direction_indicator_desc(self, tmp_path: Path) -> None:
        """Direction indicator ▼ for descending sort should appear in the JS/HTML."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "▼" in content

    def test_intersection_observer_present(self, tmp_path: Path) -> None:
        """IntersectionObserver code for active nav highlighting should be present."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        assert "IntersectionObserver" in content

    def test_active_nav_class_referenced(self, tmp_path: Path) -> None:
        """JS should apply an active class to the current nav link."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # The active class can be named anything but must exist in CSS and JS
        assert "nav-active" in content or "active" in content


# ---------------------------------------------------------------------------
# Task 2: sparklines kwarg in write_html_report
# ---------------------------------------------------------------------------


class TestWriteHtmlReportSparklines:
    """write_html_report must accept an optional sparklines kwarg and pass it to template."""

    def test_sparklines_kwarg_accepted_without_error(self, tmp_path: Path) -> None:
        """write_html_report must accept sparklines kwarg without raising."""

        from raki.report.html_report import write_html_report
        from raki.report.sparkline import SparklineData

        report = _make_minimal_report()
        sparklines = {
            "first_pass_success_rate": SparklineData(
                metric_name="first_pass_success_rate",
                values=[0.7, 0.8, 0.85],
                normalized=[0.0, 0.5, 1.0],
                delta=0.05,
                pct_delta=5.0,
                direction="up",
                value_direction="up",
            )
        }
        output = tmp_path / "report.html"
        # Must not raise
        write_html_report(report, output, sparklines=sparklines)
        assert output.exists()

    def test_sparklines_none_by_default(self, tmp_path: Path) -> None:
        """write_html_report without sparklines kwarg must render without error."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        assert output.exists()

    def test_sparklines_passed_to_template(self, tmp_path: Path) -> None:
        """When sparklines data is provided, the rendered HTML must include sparkline content."""
        from raki.report.html_report import write_html_report
        from raki.report.sparkline import SparklineData

        report = _make_minimal_report()
        sparklines = {
            "first_pass_success_rate": SparklineData(
                metric_name="first_pass_success_rate",
                values=[0.6, 0.7, 0.8],
                normalized=[0.0, 0.5, 1.0],
                delta=0.1,
                pct_delta=10.0,
                direction="up",
                value_direction="up",
            )
        }
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        # Template renders successfully with sparklines context
        assert "<!DOCTYPE html>" in content


# ---------------------------------------------------------------------------
# Task 3: SVG sparklines and delta badges in template
# ---------------------------------------------------------------------------


class TestSparklineSvgRendering:
    """Template must render inline SVG sparklines and delta badges when sparklines are provided."""

    def _make_report_with_sparklines(self) -> tuple:
        """Return (report, sparklines) ready for rendering."""
        from raki.report.sparkline import SparklineData

        report = _make_minimal_report()
        sparklines = {
            "first_pass_success_rate": SparklineData(
                metric_name="first_pass_success_rate",
                values=[0.6, 0.7, 0.8],
                normalized=[0.0, 0.5, 1.0],
                delta=0.1,
                pct_delta=10.0,
                direction="up",
                value_direction="up",
            ),
            "rework_cycles": SparklineData(
                metric_name="rework_cycles",
                values=[1.5, 1.2, 0.9],
                normalized=[1.0, 0.5, 0.0],
                delta=-0.3,
                pct_delta=30.0,
                direction="down",
                value_direction="down",
            ),
        }
        return report, sparklines

    def test_delta_badge_present_when_sparklines_provided(self, tmp_path: Path) -> None:
        """When sparklines are provided for a metric, a delta badge must appear in the output."""
        from raki.report.html_report import write_html_report

        report, sparklines = self._make_report_with_sparklines()
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        assert "delta-badge" in content

    def test_delta_badge_up_indicator_present(self, tmp_path: Path) -> None:
        """An 'up' direction must emit a ▲ delta indicator."""
        from raki.report.html_report import write_html_report

        report, sparklines = self._make_report_with_sparklines()
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        assert "▲" in content

    def test_delta_badge_down_indicator_present(self, tmp_path: Path) -> None:
        """A 'down' direction must emit a ▼ delta indicator."""
        from raki.report.html_report import write_html_report

        report, sparklines = self._make_report_with_sparklines()
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        assert "▼" in content

    def test_no_sparkline_when_not_provided(self, tmp_path: Path) -> None:
        """When sparklines kwarg is omitted, no SVG sparklines appear in score cards."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output)
        content = output.read_text()
        # When no sparklines are provided, no SVG polyline should appear
        assert "<polyline" not in content

    def test_sparkline_css_present(self, tmp_path: Path) -> None:
        """Sparkline CSS rules must be present in the rendered output."""
        from raki.report.html_report import write_html_report

        report, sparklines = self._make_report_with_sparklines()
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        assert "sparkline" in content

    def test_delta_badge_css_present(self, tmp_path: Path) -> None:
        """Delta badge CSS must be present when sparklines are rendered."""
        from raki.report.html_report import write_html_report

        report, sparklines = self._make_report_with_sparklines()
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        assert "delta-badge" in content

    def test_flat_indicator_absent_when_no_flat_metrics(self, tmp_path: Path) -> None:
        """When all directions are up/down, no = indicator appears for sparklines."""
        from raki.report.html_report import write_html_report
        from raki.report.sparkline import SparklineData

        report = _make_minimal_report()
        sparklines = {
            "first_pass_success_rate": SparklineData(
                metric_name="first_pass_success_rate",
                values=[0.6, 0.7, 0.8],
                normalized=[0.0, 0.5, 1.0],
                delta=0.1,
                pct_delta=10.0,
                direction="up",
                value_direction="up",
            ),
        }
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=sparklines)
        content = output.read_text()
        # ▲ appears but = does not appear in a delta-badge context
        assert "▲" in content

    def test_degraded_gracefully_without_sparklines(self, tmp_path: Path) -> None:
        """Score cards must render without sparklines when sparklines=None."""
        from raki.report.html_report import write_html_report

        report = _make_minimal_report()
        output = tmp_path / "report.html"
        write_html_report(report, output, sparklines=None)
        content = output.read_text()
        # Report still has score cards
        assert "score-card" in content
        # No SVG polyline (sparklines not provided)
        assert "<polyline" not in content
