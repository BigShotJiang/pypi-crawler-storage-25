# CLAUDE.md

## Design Document Rules

1. **After modifying any sub-design MD file under `design/`, you must also update `design/0.0-design-overview.md`** to keep the overview consistent with the sub-documents. Design documents are written in Chinese.

## Language Rules

1. **Everything outside the `design/` folder must be written in English**, including code comments, examples, commit messages, etc.
