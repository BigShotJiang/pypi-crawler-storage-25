# Changelog

All notable changes to this project will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). Versioning follows [SemVer](https://semver.org/).

## [Unreleased]

## [0.1.0a2] - 2026-05-24

Pack 3 — sequential router shell + Cloudflare Browser Rendering engine + comprehensive cost/policy/timeout enforcement. The public `scrape()` path is live for sequential ladders and explicit `opts.engines` overrides; the router now walks `RaceStep` members sequentially (parallel fan-out remains deferred to v0.2). `AllEnginesFailed` is now a structured exception with `.url` and `.failures` attributes. Release mechanics scaffolded: dynamic version from `__init__.py`, dep-freshness audit script, CHANGELOG gate.

### Changed — dependency floors refreshed

- Bumped lower-bound pins to current PyPI stable (pack-opening
  freshness policy from spec §4.4). Affected pins:
  - `tldextract` 5.0 → 5.3
  - `beautifulsoup4` 4.12 → 4.14
  - `typer` 0.12 → 0.25
  - `firecrawl-py` 4.0 → 4.27
  - `selenium` 4.25 → 4.44
  - `apify-client` 2.2 → 3.0
  - `mcp` 1.0 → 1.27
  - `pytest` 7.0 → 9.0
  - `pytest-asyncio` 0.21 → 1.3
  - `pytest-httpx` 0.30 → 0.36
  - `ruff` 0.4 → 0.15
  - `mypy` 1.8 → 2.1

### Changed — structured AllEnginesFailed (consumer error contract)

- `AllEnginesFailed` now carries `.url: str` and `.failures: list[str]`.
  Consumers no longer need to parse the exception message. The
  `failures` list shape is `"<engine>:<reason>:<detail>"` (e.g.
  `"firecrawl:error:404 Not Found"`, `"jina:empty"`,
  `"scrapingbee:unavailable"`, `"budget:cost"`). Pack 7 consumer
  migrations (phynder + ai-utils) target this contract directly.

### Fixed — golden-rule violation: router now consults detection.is_suspicious

- The sequential router shell originally only checked `result.is_empty()`
  for advancement — a captcha page with non-empty text would have been
  returned as success. Per `docs/conventions/golden-rules.md` ("Suspicious-
  content detection lives in one place"), the router now calls
  `scrapefold.detection.is_suspicious(result)` after the empty check and
  advances on True with a `"<engine>:suspicious"` failure entry.
- Internal: `_resolve_policy` site_class arg typed as `SiteClass` instead
  of `str`; load-bearing `type: ignore[arg-type]` removed.

### Fixed — detection: is_suspicious short-text check is now conjoint

- `detection.is_suspicious` previously flagged any result with fewer than
  50 chars regardless of HTTP status. Now short-text is only suspicious
  when the status code is also non-2xx or when the result is empty,
  eliminating false positives for legitimately short pages (e.g. API
  endpoints returning `{"ok":true}`).

### Added — Pack 3 cloudflare engine

- `src/scrapefold/engines/cloudflare.py` — port of ai-utils
  `get_content_cloudflare` to scrapefold's `ScrapeEngine` ABC. Calls
  Cloudflare Browser Rendering `/markdown` first (native markdown), falls
  back to `/content` (raw HTML → html_to_text). Env: `CLOUDFLARE_API_TOKEN`
  + `CLOUDFLARE_ACCOUNT_ID`.
- `tests/test_engine_cloudflare.py` — 13 tests covering both endpoints,
  fallback paths, auth headers, body shape, is_available gating,
  registry registration.
- `docs/workflows/development.md` — env-var table fixed
  (`CLOUDFLARE_API_KEY` → `CLOUDFLARE_API_TOKEN`, matching Cloudflare's
  Bearer-token convention).

### Added — Pack 3 router shell (sequential)

- `src/scrapefold/router.py` — `async walk(url, opts) -> ScrapeResult` walks the per-site-class ladder. Honors `Policy` (paid_allowed / legal_constraints_blocked / geography_required), `WalkBudget` ceilings (`max_engines`, `max_cost_usd`, `timeout_s`), and the `engines_tried` dedup set. `RaceStep` entries are walked sequentially with a DEBUG log until Pack 9.
- `tests/test_router.py` — 13 tests covering happy path, empty-result advance, EngineError advance, unavailable-engine skip, AllEnginesFailed, unknown-engine skip, policy gating, budget halt, RaceStep skip, public `scrape()` delegation, failures-list, no-retry-within-walk, EngineError-non-propagation.
- `scrapefold.scrape(url, opts)` now delegates to `router.walk` instead of raising `NotImplementedError`.
- `tests/test_smoke.py` — the obsolete `NotImplementedError` smoke test is removed.
- Budget enforcement: 12 rounds of Codex review hardening. Key fixes: cost-budget skips engine (not halts walk), unavailable engines don't consume `max_engines` slot, timeout boundary uses `>=`, actual cost credits over estimate, `opts.engines` override respects all budget/policy gates, geography `()` means global.

### Added — release mechanics scaffolding

- `scripts/check-deps-fresh.sh` — pack-opening dep-floor nag: parses `pyproject.toml` lower bounds and warns when a dependency is more than 90 days behind PyPI stable.
- `scripts/check-changelog.sh` — PR-time gate: fails if `## [Unreleased]` is empty (no changes documented), scoped to the `[Unreleased]` section only.
- `scripts/check.sh` — version-equality gate added: reads dynamic version from `pyproject.toml` (via `tomli`) and asserts it matches `__init__.__version__`; prevents version drift between the two sources.
- `pyproject.toml` — `tomli` added as Python 3.10 compat dep for the version check; broken `obscura` and `brightdata` optional extras removed.

## [0.1.0a1] — 2026-05-22

### Added — S1.5 per-site-class escalation ladders

- `src/scrapefold/ladders.py` — full v3 design after three Codex review rounds.
  - `SiteClass` literal with 27 classes (LinkedIn ×5, Amazon ×2, social ×4, SERP ×3, easy content ×4, paywall_news, yandex_protected, anti-bot vendor ×4, js_spa, static_general).
  - Sum type for steps: `SequentialStep` + `RaceStep` (no more weak tuple of tuples).
    - `RaceStep` carries explicit `winner_policy`, `cancel_policy`, `cancel_grace_ms`, `budget_accounting` — race semantics are data, not router convention.
  - `LADDERS: dict[SiteClass, Ladder]` — per-class ordered tuple of steps.
  - `WalkBudget` — mutable walk state (elapsed_ms, cost_usd, engines_tried, **visited_site_classes** to block A→B→A reclassification loops, reclassifications, `MAX_RECLASSIFICATIONS=3`).
  - `BudgetExceeded` + `AllEnginesFailed` — typed exceptions surfaced to the router.
  - `Policy` + `DEFAULT_POLICY` — `paid_allowed`, `legal_constraints_blocked`, `geography_required`. Government class defaults to `paid_allowed=False`.
  - `is_step_allowed(step, policy)` and `check_budget(step, walk, ...)` — pure functions consumed by the router. `check_budget` accounts for **race fan-out** in the engine-count ceiling (Codex round-3 fix).
  - `_estimate_step_cost(step, avg_response_mb)` — converts `(estimated_cost_usd, billing_unit)` into per-call USD; `gb` billing scales with response size.
  - `URL_PATTERNS` + `classify_url` — ordered specific-first regex table, fallback `static_general`.
  - `GOLDEN_CORPUS` — 22 `(url, class)` rows pinning regex-order safety. The parametrized test `test_url_classification_golden_corpus` makes any reorder regression visible per-row.
  - `SIGNATURES` — response-content matchers (Cloudflare / Datadome / PerimeterX / Akamai cookies, body phrases, headers) for mid-walk reclassification by `detection.py` (S2). `min_matches=2` prevents single-phrase false positives.
- `src/scrapefold/engines/base.py` — extended `EngineCapabilities` with `estimated_cost_usd`, `billing_unit`, `avg_response_mb_estimate`, `geography`, `proxy_type`, `legal_constraints`, `default_timeout_s`. Added `PROBE_SCOPE: Literal["none", "per_url", "per_domain", "per_session"]` and default `async def probe(url) -> bool` returning `True`. Reddit's requests-engine override (`PROBE_SCOPE="per_domain"`) means a 50-URL crawl on reddit.com costs one probe, not 50.
- `src/scrapefold/engines/__init__.py` — `ENGINE_ALIASES`, `register_alias`, `resolve_alias`. Multi-mode engines (Bright Data Unlocker async/sync, Scrapling stealth/fast) register as distinct names; user-facing aliases route a bare `scrapling` to `scrapling_stealth`.
- `src/scrapefold/__init__.py` — re-exports `Policy`, `SequentialStep`, `RaceStep`, `WalkBudget`, `SiteClass`, `BudgetExceeded`, `AllEnginesFailed`, `classify_url`, `get_ladder`. Version bumped to `0.1.0a1`.
- `tests/test_ladders.py` — 59 tests covering structural well-formedness, 22-row golden corpus + completeness, `is_step_allowed` policy enforcement (paid/legal/geography), `check_budget` ceilings + race fan-out, sum-type defaults, multi-mode engine separation, `WalkBudget` visited-class loop guard, `_estimate_step_cost` billing-unit math.

### Changed

- Architecture overview (`docs/architecture/overview.md`) — replaced universal T0-T5 ladder narrative with per-class ladder description, race-step semantics, walk-time contracts.
- Golden rules (`docs/conventions/golden-rules.md`) — rewrote the escalation rule, added three new rules: "Ladders are data", "Multi-mode engines register as distinct names", "New URL pattern → new GOLDEN_CORPUS row".

### Deferred

Seven Codex round-3 implementation items tracked in `docs/TECH_DEBT.md`:

1. `budget_mode` wiring in the router (S7).
2. Race fan-out cost crediting when `budget_accounting="sum_all"`.
3. Per-engine `avg_response_mb` override wiring through `_estimate_step_cost`.
4. Race billing default re-examination once benchmarks land.
5. `avg_response_mb_estimate` default tuning per engine.
6. Engine-registration code must populate `ENGINE_ALIASES` (S2-S11).
7. Probe-cache implementation in the router (S7).

## [0.1.0a0] — 2026-05-22

### Added — S1 scaffold

- Package layout: `src/scrapefold/` with `options.py`, `result.py`, `engines/base.py`, lazy engine registry.
- `ScrapeOptions` dataclass — single unified parameter schema (language, country, render_js, wait_ms, stealth, premium_proxy, user_agent, custom_headers, cookies, output_format, take_screenshot, max_pages, max_depth, engines, parallel, timeout_s, skip_cache, extra).
- `ScrapeResult` dataclass — four format slots (`text`, `markdown`, `html`, `json`) + `screenshot_b64`, `meta`, `failures`, `elapsed_ms`, `cost_usd`.
- `ScrapeEngine` ABC with `EngineCapabilities` + `EngineError`. Base class handles option-stripping (DEBUG log, never raises), timing, error wrapping.
- Public `scrape()` and `crawl_site()` stubs in `__init__.py` (raise `NotImplementedError` until S7/S8).
- CLI scaffold (`scrapefold` console script via Typer).
- MCP server scaffold (`scrapefold-mcp` console script).
- Docs graph per HARNESS_BOOTSTRAP: `docs/README.md`, `docs/architecture/overview.md`, `docs/workflows/{development,testing}.md`, `docs/conventions/golden-rules.md`, `docs/tools/{agent-mode,scripts}.md`.
- Anti-bot escalation ladder documented (T0→T4 + stop rules + suspicious-content detection heuristics planned in `detection.py`).
- Golden rules: unified options, options-dropping-never-raises, ScrapeResult invariant (all four slots), escalate-and-stop, suspicious-detection-in-one-place, no vendor LLM SDK, lazy engine imports, async everywhere.
- Helper scripts: `scripts/check.sh`, `scripts/describe.sh`, `scripts/quick-test.sh`.
- GitHub Actions CI: lint + type-check + offline tests on Python 3.10/3.11/3.12; PyPI publish via trusted publishing on `v*` tag; opt-in `paid` and `network` test jobs via `workflow_dispatch`.
- Smoke tests + `ScrapeEngine` ABC contract tests.

[Unreleased]: https://github.com/mihailorama/scrapefold/compare/v0.1.0a2...HEAD
[0.1.0a2]: https://github.com/mihailorama/scrapefold/compare/v0.1.0a1...v0.1.0a2
[0.1.0a1]: https://github.com/mihailorama/scrapefold/compare/v0.1.0a0...v0.1.0a1
[0.1.0a0]: https://github.com/mihailorama/scrapefold/releases/tag/v0.1.0a0
