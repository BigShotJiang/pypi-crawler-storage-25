# coding: utf-8

import datetime as dt
import itertools
import logging
import multiprocessing
from collections import namedtuple
from typing import Dict, Iterable, List, Optional

import numpy as np  # noqa
from nzshm_common.grids import RegionGrid
from nzshm_common.location import CodedLocation

from toshi_hazard_store import query
from toshi_hazard_store.model.gridded.gridded_hazard_pydantic import GriddedHazardPoeLevels
from toshi_hazard_store.model.pyarrow import pyarrow_dataset

from .gridded_poe import compute_hazard_at_poe

log = logging.getLogger(__name__)
INVESTIGATION_TIME = 50
SPOOF_SAVE = False
COV_AGG_KEY = "cov"

DEFAULT_GRID_ACCEL_VALUE = np.nan  # historically was None, but this cannot be serialised by pyarrow
PRODUCE_COV_GRID = True

GridHazTaskArgs = namedtuple(
    "GridHazTaskArgs",
    "poe_levels location_grid_id compatible_calc_id hazard_model_id vs30 imt agg output_target",
)


def process_gridded_hazard(
    poe_levels: List[float],
    location_grid_id: str,
    compatible_calc_id: str,
    hazard_model_id: str,
    vs30: int,
    imt: str,
    agg: str,
) -> Iterable[GriddedHazardPoeLevels]:
    """
    Compute and yield GriddedHazardPoeLevels for the given arguments.

    Args:
        poe_levels (List[float]): POE levels to compute for.
        location_grid_id (str): ID of the region grid.
        compatible_calc_id (str): ID of the compatible calculation.
        hazard_model_id (str): ID of the hazard model.
        vs30 (int): VS30 value for each location.
        imt (str): Intensity measure type (e.g. PGA, PGV).
        agg (str): Aggregation method (e.g. mean, max).

    Yields:
        GriddedHazardPoeLevels: Computed GriddedHazardPoeLevels.
    """
    log.debug(f">>> process_gridded_hazard() poe_levels: {poe_levels}")
    grid = RegionGrid[location_grid_id]
    locations = list(
        map(
            lambda grd_loc: CodedLocation(grd_loc[0], grd_loc[1], resolution=grid.resolution),
            grid.load(),
        )
    )
    location_keys = [loc.resample(0.001).code for loc in locations]
    grid_accel_levels: Dict[float, List] = {
        poe: [DEFAULT_GRID_ACCEL_VALUE for i in range(len(location_keys))] for poe in poe_levels
    }

    for haz in query.get_hazard_curves(location_keys, [vs30], hazard_model_id, imts=[imt], aggs=[agg], strategy="d1"):
        accel_levels = [val.lvl for val in haz.values]
        poe_values = [val.val for val in haz.values]
        index = location_keys.index(haz.nloc_001)
        for poe_lvl in poe_levels:
            if not (0 < poe_lvl < 1):
                raise ValueError(f"poe value {poe_lvl} is not supported.")
            try:
                grid_accel_levels[poe_lvl][index] = compute_hazard_at_poe(
                    poe_lvl, accel_levels, poe_values, INVESTIGATION_TIME
                )
            except Exception as err:
                log.error(
                    "Error in compute_hazard_at_poe: `%s` for poe_lvl: `%s`, hazard_model: `%s`,`"
                    " vs30: `%s`, imt: `%s`, agg: `%s`, loc:%s"
                    % (err, poe_lvl, hazard_model_id, vs30, imt, agg, haz.nloc_001)
                )
                log.warning(f"index: {index}; ` poe_values`: {poe_values}")
                continue
            log.debug("replaced %s with %s" % (index, grid_accel_levels[poe_lvl][index]))

    # DONE: no evidence now of this problem, that we have validated that the grid_accel_levels values are all floats ...
    # NB this seems to be caused only at loc = -40.100~175.000, and with max_poe = 0.632, where we see the non-monotonic
    #
    # try:
    #     GriddedHazardPoeLevels.validate_grid_accel_levels(grid_accel_levels)  # raise
    # except ValueError as err:
    #     log.warning(f"invalid values found in `grid_accel_levels`. 1st 20 indices_computed: {indices_computed[:20]}.")
    #     log.warning(err)
    #     raise err

    log.debug("No problem detected in in `grid_accel_levels`, all values are floats")

    if agg == "mean" and PRODUCE_COV_GRID:
        grid_covs: Dict[float, List] = {
            poe: [DEFAULT_GRID_ACCEL_VALUE for i in range(len(location_keys))] for poe in poe_levels
        }
        for cov in query.get_hazard_curves(location_keys, [vs30], hazard_model_id, imts=[imt], aggs=[COV_AGG_KEY]):
            cov_values = [val.val for val in cov.values]
            index = location_keys.index(cov.nloc_001)
            for poe_lvl in poe_levels:
                grid_covs[poe_lvl][index] = np.exp(
                    np.interp(
                        np.log(grid_accel_levels[poe_lvl][index]),
                        np.log(accel_levels),
                        np.log(cov_values),
                    )
                )

        for poe_lvl in poe_levels:
            yield GriddedHazardPoeLevels(
                compatible_calc_id=compatible_calc_id,
                hazard_model_id=hazard_model_id,
                location_grid_id=location_grid_id,
                vs30=vs30,
                imt=imt,
                aggr=COV_AGG_KEY,
                investigation_time=INVESTIGATION_TIME,
                poe=poe_lvl,
                accel_levels=grid_covs[poe_lvl],
            )

    for poe_lvl in poe_levels:
        yield GriddedHazardPoeLevels(
            compatible_calc_id=compatible_calc_id,
            hazard_model_id=hazard_model_id,
            location_grid_id=location_grid_id,
            vs30=vs30,
            imt=imt,
            aggr=agg,
            investigation_time=INVESTIGATION_TIME,
            poe=poe_lvl,
            accel_levels=grid_accel_levels[poe_lvl],
        )


class GriddedHazardWorkerMP(multiprocessing.Process):
    """A worker that batches and saves records to parquet datasets."""

    def __init__(self, task_queue):
        multiprocessing.Process.__init__(self)
        self.task_queue = task_queue

    def run(self):
        log.info("worker %s running." % self.name)
        proc_name = self.name

        while True:
            nt = self.task_queue.get()
            if nt is None:
                # Poison pill means shutdown
                self.task_queue.task_done()
                log.info("%s: Exiting" % proc_name)
                break

            # log.info(f"nt: {nt[:4]}")
            t0 = dt.datetime.now()
            try:
                gridded_models = list(process_gridded_hazard(*nt[:-1]))
                # assert 0
                # write the dataset
                table = pyarrow_dataset.table_from_models(gridded_models)
                output_folder, filesystem = pyarrow_dataset.configure_output(nt.output_target)
                pyarrow_dataset.append_models_to_dataset(
                    table,
                    output_folder,
                    filesystem=filesystem,
                    partitioning=["hazard_model_id"],
                    schema=GriddedHazardPoeLevels.pyarrow_schema(),
                    write_meta=False,  # We saw this error
                    #  Error: [Errno 2] No such file or directory:
                    # '/private/tmp/ds5/hazard_model_id=NSHM_v1.0.4/_metadata.csv'
                )
            except Exception as err:
                log.warning(f"Error in process_gridded_hazard: with task args `{nt}`")
                log.warning(f"Error: {err}")
            finally:
                self.task_queue.task_done()
                t1 = dt.datetime.now()
                log.info("%s task done in %s seconds, args: `%s`" % (self.name, (t1 - t0).total_seconds(), nt))


def calc_gridded_hazard(
    output_target: str,
    location_grid_id: str,
    poe_levels: Iterable[float],
    hazard_model_ids: Iterable[str],
    vs30s: Iterable[float],
    imts: Iterable[str],
    aggs: Iterable[str],
    num_workers: int,
    filter_locations: Optional[Iterable[CodedLocation]] = None,
):
    """
    Compute and save gridded hazard rows for the given parameters.

    Args:
        output_target (str): URL of the output dataset.
        location_grid_id (str): ID of the region grid.
        poe_levels (Iterable[float]): POE levels to compute for.
        hazard_model_ids (Iterable[str]): IDs of the hazard models.
        vs30s (Iterable[float]): VS30 values for each location.
        imts (Iterable[str]): Intensity measure types (e.g. PGA, PGV).
        aggs (Iterable[str]): Aggregation methods (e.g. mean, max).
        num_workers (int): Number of worker processes to use.
        filter_locations (Optional[Iterable[CodedLocation]]): Optional list of locations to filter by.

    Returns:
        None
    """
    log.debug(
        "calc_gridded_hazard( grid: %s poes: %s models: %s vs30s: %s imts: %s aggs: %s"
        % (location_grid_id, poe_levels, hazard_model_ids, vs30s, imts, aggs)
    )
    count = 0

    task_queue: multiprocessing.JoinableQueue = multiprocessing.JoinableQueue()

    log.debug("Creating %d workers" % num_workers)
    workers = [GriddedHazardWorkerMP(task_queue) for i in range(num_workers)]
    for w in workers:
        w.start()

    for hazard_model_id, vs30, imt, agg in itertools.product(hazard_model_ids, vs30s, imts, aggs):
        t = GridHazTaskArgs(
            poe_levels,
            location_grid_id,
            "NZSHM22",
            hazard_model_id,
            vs30,
            imt,
            agg,
            output_target,
        )
        task_queue.put(t)
        count += 1

    # Add a poison pill for each to signal we've done everything
    for i in range(num_workers):
        task_queue.put(None)

    # Wait for all of the tasks to finish
    task_queue.join()

    log.info("calc_gridded_hazard() produced %s gridded_hazard rows " % count)
