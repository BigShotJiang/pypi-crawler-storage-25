import os

from mkpipe.spark import JdbcLoader

JAR_PACKAGES = ['org.xerial:sqlite-jdbc:3.47.1.0']


class SqliteLoader(JdbcLoader, variant='sqlite'):
    driver_name = 'sqlite'
    driver_jdbc = 'org.sqlite.JDBC'
    _dialect = 'sqlite'

    def build_jdbc_url(self):
        db_path = self.connection.extra.get('db_path', self.database or 'data.db')
        db_path = os.path.abspath(db_path)
        return f'jdbc:sqlite:{db_path}'
