"""
TLS Fingerprint HTTP Client на базі curl-cffi.

Професійний HTTP клієнт для обходу anti-bot систем через:
- Імітацію TLS fingerprint реальних браузерів (Chrome, Firefox, Safari)
- JA3/JA4 fingerprint matching
- HTTP/2 support
- Brotli/Zstd compression

Features:
- Обходить DataDome, PerimeterX, Kasada без браузера
- Швидший за Playwright/Selenium для статичних сайтів
- Async та sync API
"""

import logging
import random
from dataclasses import dataclass
from typing import Any, Optional

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.core.base_sync import BaseSyncDriver
from graph_crawler.infrastructure.transport.core.base_async import BaseAsyncDriver

logger = logging.getLogger(__name__)


@dataclass
class TLSClientConfig:
    """Конфігурація TLS клієнта."""

    # Browser impersonation
    # Options: chrome110, chrome116, chrome120, chrome124
    #          firefox117, firefox120, safari15_5, safari17_0
    impersonate: str = "chrome120"

    # Proxy
    proxy: Optional[str] = None  # Format: "http://user:pass@host:port"

    # Timeouts
    timeout: float = 30.0
    connect_timeout: float = 10.0

    # Headers
    default_headers: Optional[dict[str, str]] = None

    # Retry
    max_retries: int = 3
    retry_delay: float = 1.0

    # SSL
    verify_ssl: bool = True

    # HTTP/2
    http2: bool = True


class TLSFingerprintClient(BaseSyncDriver):
    """
    HTTP клієнт з імітацією TLS fingerprint.

    Дозволяє обходити anti-bot системи без використання браузера,
    імітуючи TLS fingerprint реальних браузерів.

    Успадковує BaseSyncDriver для сумісності з IDriver інтерфейсом.

    Приклад:

        from graph_crawler.infrastructure.transport.tls_client import TLSFingerprintClient

        client = TLSFingerprintClient(TLSClientConfig(
            impersonate="chrome131",
            proxy="http://user:pass@proxy:8080"
        ))

        response = client.fetch("https://protected-site.com")
        print(response.html)
    """

    driver_name = "tls_fingerprint"

    # Browser fingerprints
    BROWSERS = [
        "chrome110", "chrome116", "chrome120", "chrome124",
        "firefox117", "firefox120",
        "safari15_5", "safari17_0",
        "edge99", "edge101",
    ]

    def __init__(
        self,
        config: Optional[TLSClientConfig] = None,
        event_bus: EventBus | None = None,
    ):
        # Ініціалізуємо TLS-специфічний конфіг
        self.tls_config = config or TLSClientConfig()
        
        # Ініціалізуємо базовий клас з загальним config dict
        super().__init__(
            config={
                "timeout": self.tls_config.timeout,
                "max_retries": self.tls_config.max_retries,
            },
            event_bus=event_bus,
        )
        
        self._session = None
        self._setup_session()

    def _setup_session(self):
        try:
            from curl_cffi.requests import Session
        except ImportError as e:
            raise ImportError(
                "curl-cffi not installed. Run: pip install curl-cffi"
            ) from e

        self._session = Session(
            impersonate=self.tls_config.impersonate,
            timeout=self.tls_config.timeout,
            verify=self.tls_config.verify_ssl,
        )

        # Set proxy if provided
        if self.tls_config.proxy:
            self._session.proxies = {
                "http": self.tls_config.proxy,
                "https": self.tls_config.proxy,
            }

        # Set default headers
        if self.tls_config.default_headers:
            self._session.headers.update(self.tls_config.default_headers)

        logger.info(
            "TLSFingerprintClient initialized (impersonate: %s)",
            self.tls_config.impersonate
        )

    def _get_headers(self) -> dict[str, str]:
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,uk;q=0.8",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Cache-Control": "max-age=0",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
        }

        # Add sec-ch-ua for Chrome
        if "chrome" in self.tls_config.impersonate:
            version = self.tls_config.impersonate.replace("chrome", "")
            headers["sec-ch-ua"] = f'"Google Chrome";v="{version}", "Chromium";v="{version}", "Not?A_Brand";v="99"'
            headers["sec-ch-ua-mobile"] = "?0"
            headers["sec-ch-ua-platform"] = '"Windows"'

        return headers

    def get(self, url: str, **kwargs) -> Any:
        """
        HTTP GET запит.

        Args:
            url: URL
            **kwargs: Додаткові параметри для requests

        Returns:
            Response об'єкт
        """
        return self._request("GET", url, **kwargs)

    def post(self, url: str, data: Any = None, json: Any = None, **kwargs) -> Any:
        """
        HTTP POST запит.

        Args:
            url: URL
            data: Form data
            json: JSON data
            **kwargs: Додаткові параметри

        Returns:
            Response об'єкт
        """
        return self._request("POST", url, data=data, json=json, **kwargs)

    def _request(self, method: str, url: str, **kwargs) -> Any:
        """Виконує HTTP запит з retry logic."""
        if not self._session:
            raise RuntimeError("Session not initialized")

        # Merge headers
        headers = self._get_headers()
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        last_error = None
        for attempt in range(self.tls_config.max_retries):
            try:
                response = self._session.request(
                    method,
                    url,
                    headers=headers,
                    timeout=self.tls_config.timeout,
                    **kwargs
                )

                # Check for anti-bot blocks
                if self._is_blocked(response):
                    logger.warning(
                        "Request blocked (attempt %d/%d): %s",
                        attempt + 1, self.tls_config.max_retries, url
                    )
                    if attempt < self.tls_config.max_retries - 1:
                        # Change fingerprint and retry
                        self._rotate_fingerprint()
                        import time
                        time.sleep(self.tls_config.retry_delay * (attempt + 1))
                        continue

                logger.info(
                    "Request successful: %s [%d] (%d bytes)",
                    url, response.status_code, len(response.content)
                )
                return response

            except Exception as e:
                last_error = e
                logger.warning(
                    "Request error (attempt %d/%d): %s - %s",
                    attempt + 1, self.tls_config.max_retries, url, e
                )
                if attempt < self.tls_config.max_retries - 1:
                    import time
                    time.sleep(self.tls_config.retry_delay * (attempt + 1))

        raise last_error or Exception(f"Request failed after {self.tls_config.max_retries} attempts")

    def _is_blocked(self, response: Any) -> bool:
        """Перевіряє чи запит заблоковано anti-bot системою."""
        # Status code check
        if response.status_code in [403, 429, 503]:
            return True

        # Content check
        text = response.text.lower()
        block_indicators = [
            "access denied",
            "blocked",
            "captcha",
            "challenge",
            "checking your browser",
            "cloudflare",
            "datadome",
            "perimeterx",
            "bot detection",
            "suspicious activity",
        ]

        return any(indicator in text for indicator in block_indicators)

    def _rotate_fingerprint(self):
        new_browser = random.choice(self.BROWSERS)
        logger.info("Rotating fingerprint: %s -> %s", self.tls_config.impersonate, new_browser)

        self.tls_config.impersonate = new_browser

        # Recreate session
        try:
            from curl_cffi.requests import Session

            self._session = Session(
                impersonate=self.tls_config.impersonate,
                timeout=self.tls_config.timeout,
                verify=self.tls_config.verify_ssl,
            )

            if self.tls_config.proxy:
                self._session.proxies = {
                    "http": self.tls_config.proxy,
                    "https": self.tls_config.proxy,
                }
        except Exception as e:
            logger.error("Fingerprint rotation error: %s", e)

    def _do_fetch(self, url: str) -> FetchResponse:
        """
        Реалізація абстрактного методу BaseSyncDriver.
        
        Завантажує сторінку через TLS fingerprint клієнт.
        
        Args:
            url: URL для завантаження
            
        Returns:
            FetchResponse з результатом
        """
        response = self.get(url)
        
        return FetchResponse(
            url=url,
            html=response.text,
            status_code=response.status_code,
            headers={k: str(v) for k, v in response.headers.items()},
            error=None,
        )

    def _do_close(self) -> None:
        """Закриває сесію (реалізація для BaseSyncDriver)."""
        if self._session:
            self._session.close()
            self._session = None
        logger.info("TLSFingerprintClient closed")


class AsyncTLSFingerprintClient(BaseAsyncDriver):
    """
    Асинхронний HTTP клієнт з TLS fingerprint імітацією.

    Успадковує BaseAsyncDriver для сумісності з IDriver інтерфейсом.

    Приклад:

        async with AsyncTLSFingerprintClient() as client:
            response = await client.fetch("https://protected-site.com")
            print(response.html)
    """

    driver_name = "async_tls_fingerprint"

    def __init__(
        self,
        config: Optional[TLSClientConfig] = None,
        event_bus: EventBus | None = None,
    ):
        self.tls_config = config or TLSClientConfig()
        
        # Ініціалізуємо базовий клас
        super().__init__(
            config={
                "timeout": self.tls_config.timeout,
            },
            event_bus=event_bus,
        )
        
        self._session = None

    async def _get_session(self):
        if self._session is None:
            try:
                from curl_cffi.requests import AsyncSession
            except ImportError as e:
                raise ImportError(
                    "curl-cffi not installed. Run: pip install curl-cffi"
                ) from e

            self._session = AsyncSession(
                impersonate=self.tls_config.impersonate,
                timeout=self.tls_config.timeout,
                verify=self.tls_config.verify_ssl,
            )

            if self.tls_config.proxy:
                self._session.proxies = {
                    "http": self.tls_config.proxy,
                    "https": self.tls_config.proxy,
                }

        return self._session

    def _get_headers(self) -> dict[str, str]:
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Cache-Control": "max-age=0",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
        }

        if "chrome" in self.tls_config.impersonate:
            version = self.tls_config.impersonate.replace("chrome", "")
            headers["sec-ch-ua"] = f'"Google Chrome";v="{version}", "Chromium";v="{version}", "Not?A_Brand";v="99"'
            headers["sec-ch-ua-mobile"] = "?0"
            headers["sec-ch-ua-platform"] = '"Windows"'

        return headers

    async def get(self, url: str, **kwargs) -> Any:
        return await self._request("GET", url, **kwargs)

    async def post(self, url: str, data: Any = None, json: Any = None, **kwargs) -> Any:
        return await self._request("POST", url, data=data, json=json, **kwargs)

    async def _request(self, method: str, url: str, **kwargs) -> Any:
        """Виконує async HTTP запит."""
        session = await self._get_session()

        headers = self._get_headers()
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        response = await session.request(
            method,
            url,
            headers=headers,
            timeout=self.tls_config.timeout,
            **kwargs
        )

        logger.info(
            "Async request: %s [%d] (%d bytes)",
            url, response.status_code, len(response.content)
        )

        return response

    async def _do_fetch(self, url: str) -> FetchResponse:
        """
        Реалізація абстрактного методу BaseAsyncDriver.
        
        Завантажує сторінку через async TLS fingerprint клієнт.
        
        Args:
            url: URL для завантаження
            
        Returns:
            FetchResponse з результатом
        """
        response = await self.get(url)
        
        return FetchResponse(
            url=url,
            html=response.text,
            status_code=response.status_code,
            headers={k: str(v) for k, v in response.headers.items()},
            error=None,
        )

    async def _do_close(self) -> None:
        """Закриває async session (реалізація для BaseAsyncDriver)."""
        if self._session:
            await self._session.close()
            self._session = None
        logger.info("AsyncTLSFingerprintClient closed")
