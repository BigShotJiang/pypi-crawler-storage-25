"""
Pooled Playwright Driver - динамічний пул браузерів з вкладками.

Оптимізації (Січень 2026):
- Startup Jitter: рандомна затримка перед кожним page.goto() для:
  - Зменшення burst навантаження на мережу
  - Обходу anti-bot детекції паттернів
  - Дозволу HTTP кешу заповнитись
- Cache Warmup: опціональний режим запуску 1 вкладки спочатку
- Адаптивний Jitter: залежить від кількості вкладок та доменів

"""
from __future__ import annotations

import asyncio
import logging
import random
import time
import warnings
from collections import Counter
from typing import Any
from urllib.parse import urlparse

from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.base import BaseDriver
from graph_crawler.infrastructure.transport.base_plugin import BaseDriverPlugin
from graph_crawler.infrastructure.transport.playwright.context import BrowserContext
from graph_crawler.infrastructure.transport.playwright.stages import BrowserStage
from graph_crawler.infrastructure.transport.plugin_manager import DriverPluginManager
from graph_crawler.shared.constants import (
    DEFAULT_BLOCK_RESOURCES,
    DEFAULT_BROWSER_TYPE,
    DEFAULT_BROWSER_VIEWPORT_HEIGHT,
    DEFAULT_BROWSER_VIEWPORT_WIDTH,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_USER_AGENT,
    PLAYWRIGHT_MEMORY_ARGS,
    PLAYWRIGHT_STEALTH_ARGS,
    SUPPORTED_BROWSERS,
)

logger = logging.getLogger(__name__)

def _setup_asyncio_exception_handler():
    """
    Встановлює глобальний обробник для придушення очікуваних помилок
    при cleanup браузера (TargetClosedError, InvalidStateError).

    Ці помилки виникають коли:
    - Навігації ще активні при закритті браузера
    - Playwright transport намагається set_result на finished future

    Це НЕ помилки в нашому коді - просто cleanup artifacts.
    """
    try:
        loop = asyncio.get_running_loop()
        original_handler = loop.get_exception_handler()

        def custom_exception_handler(loop, context):
            exception = context.get("exception")

            # Suppress відомі cleanup помилки
            if exception:
                exc_name = type(exception).__name__
                exc_str = str(exception)

                # TargetClosedError - браузер закрито під час навігації
                if (
                    "TargetClosedError" in exc_name
                    or "Target page, context or browser has been closed" in exc_str
                ):
                    logger.debug("Suppressed cleanup error: %s", exc_name)
                    return

                # InvalidStateError - future вже в final state
                if "InvalidStateError" in exc_name and "invalid state" in exc_str:
                    logger.debug("Suppressed cleanup error: %s", exc_name)
                    return

            # Для інших помилок - викликаємо оригінальний handler
            if original_handler:
                original_handler(loop, context)
            else:
                # Default behavior
                logger.error("Unhandled exception in asyncio: %s", context)

        loop.set_exception_handler(custom_exception_handler)
    except RuntimeError:
        # No running loop - skip
        pass

def calculate_optimal_jitter(
    num_tabs: int,
    unique_domains: int,
    has_block_resources: bool,
    base_jitter: float = 0.05,  # 50ms
) -> float:
    """
    Обчислює оптимальний jitter на основі контексту.
    
    Чим більше вкладок на один домен — тим більше jitter.
    Чим більше блокуємо ресурси — тим менше jitter потрібен.
    
    Args:
        num_tabs: Кількість вкладок
        unique_domains: Кількість унікальних доменів
        has_block_resources: Чи блокуються ресурси (CSS/JS/images)
        base_jitter: Базовий jitter в секундах (default 50ms)
    
    Returns:
        float: Оптимальний jitter в секундах
    
    Рекомендації з industry research:
    - 5-10 вкладок: 50-200ms
    - 10-20 вкладок: 100-500ms  
    - 20-50 вкладок: 200-1000ms
    - 50+ вкладок: 500-2000ms
    """
    # Фактор кількості вкладок (до 2x при великій кількості)
    tab_factor = min(num_tabs / 10, 2.0)
    
    # Фактор концентрації на одному домені
    # Більше вкладок на один домен = більше jitter (cache race condition)
    domain_factor = num_tabs / max(unique_domains, 1)
    
    # Якщо блокуємо ресурси — менше jitter потрібен
    # (CSS/JS не завантажуються, cache race condition менш ймовірний)
    resource_factor = 0.5 if has_block_resources else 1.0
    
    optimal = base_jitter * tab_factor * domain_factor * resource_factor
    
    # Обмеження: не менше 10ms, не більше 2s
    return max(0.01, min(optimal, 2.0))


def extract_domain(url: str) -> str:
    """Витягує домен з URL."""
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return url


class PooledPlaywrightDriver(BaseDriver):
    """
    Playwright драйвер з динамічним пулом браузерів та вкладок.

    Проста архітектура:
    - Відкриває браузери по потребі (не більше ліміту)
    - Кожен браузер має N вкладок (не більше ліміту)
    - Після fetch_many закриває ВСЕ (як PlaywrightDriver)

    Оптимізації (Січень 2026):
    - Startup Jitter: рандомна затримка (10-300ms) перед кожним page.goto()
    - Cache Warmup: опціональний режим (enable_cache_warmup=True)
    - Адаптивний Jitter: автоматичний розрахунок на основі контексту

    Приклад для 10 URLs з browsers=3, tabs_per_browser=5:
        Browser 1: Tab1, Tab2, Tab3, Tab4, Tab5 (5 URLs)
        Browser 2: Tab1, Tab2, Tab3, Tab4, Tab5 (5 URLs)
        → Всього 2 браузери, 10 вкладок

    Args:
        config: Конфігурація (headless, timeout, wait_until, etc.)
        browsers: Максимум браузерів (default: 3)
        tabs_per_browser: Максимум вкладок на браузер (default: 5)
        plugins: Список плагінів
        
    Config options:
        enable_jitter: bool - включити startup jitter (default: True)
        jitter_min: float - мінімальний jitter в секундах (default: 0.01)
        jitter_max: float - максимальний jitter в секундах (default: 0.3)
        adaptive_jitter: bool - автоматичний розрахунок jitter (default: True)
        enable_cache_warmup: bool - включити cache warmup режим (default: False)
        cache_warmup_delay: float - затримка після warmup в секундах (default: 0.3)
    """

    def __init__(
        self,
        config: dict[str, Any | None] = None,
        browsers: int = 3,
        tabs_per_browser: int = 5,
        plugins: list[BaseDriverPlugin | None] = None,
        event_bus: Any | None = None,
        max_concurrent_fetches: int = 0,  # 0 = no limit
    ):
        super().__init__(config or {}, event_bus)

        self.max_browsers = browsers
        self.max_tabs_per_browser = tabs_per_browser
        self.total_slots = self.max_browsers * self.max_tabs_per_browser
        # При багатьох вкладках одночасний fetch на всіх створює memory spike
        # max_concurrent_fetches обмежує скільки сторінок вантажиться паралельно
        self.max_concurrent_fetches = max_concurrent_fetches or self.total_slots
        self._fetch_semaphore: asyncio.Semaphore | None = None  # Створюється при fetch

        self.playwright = None

        # Plugin Manager
        self.plugin_manager = DriverPluginManager(is_async=True)
        if plugins:
            for plugin in plugins:
                self.plugin_manager.register(plugin)

        browser_type = self.config.get("browser", DEFAULT_BROWSER_TYPE).lower()
        if browser_type not in SUPPORTED_BROWSERS:
            browser_type = DEFAULT_BROWSER_TYPE
        self.browser_type = browser_type

        self.headless = self.config.get("headless", True)

        timeout_seconds = self.config.get("timeout", DEFAULT_REQUEST_TIMEOUT)
        self.timeout = timeout_seconds * 1000 if timeout_seconds < 1000 else timeout_seconds

        self.user_agent = self.config.get("user_agent", DEFAULT_USER_AGENT)
        self.viewport = self.config.get(
            "viewport",
            {
                "width": DEFAULT_BROWSER_VIEWPORT_WIDTH,
                "height": DEFAULT_BROWSER_VIEWPORT_HEIGHT,
            },
        )

        self.wait_until = self.config.get("wait_until", "domcontentloaded")
        self.wait_selector = self.config.get("wait_selector")
        wait_timeout_seconds = self.config.get("wait_timeout", 10)
        self.wait_timeout = (
            wait_timeout_seconds * 1000 if wait_timeout_seconds < 1000 else wait_timeout_seconds
        )

        self.scroll_page = self.config.get("scroll_page", False)
        self.scroll_step = self.config.get("scroll_step", 500)
        self.scroll_pause = self.config.get("scroll_pause", 0.3)

        self.javascript_enabled = self.config.get("javascript_enabled", True)

        # Fetch timeout для Cloudflare challenge (за замовчуванням 90 секунд)
        self.fetch_timeout = self.config.get("fetch_timeout", 90)

        # Затримки після операцій (параметризовані замість hardcoded)
        self.post_selector_delay = self.config.get("post_selector_delay", 0.5)
        self.post_scroll_delay = self.config.get("post_scroll_delay", 0.3)

        # Resource blocking (за замовчуванням блокуємо для економії RAM)
        self.block_resources = self.config.get("block_resources", list(DEFAULT_BLOCK_RESOURCES))

        # Memory optimization
        self.memory_optimization = self.config.get("memory_optimization", True)

        # === OPTIMIZATION: Startup Jitter (Січень 2026) ===
        # Рандомна затримка перед кожним page.goto() для:
        # 1. Зменшення burst навантаження на мережу
        # 2. Обходу anti-bot детекції паттернів
        # 3. Дозволу HTTP кешу заповнитись
        self.enable_jitter = self.config.get("enable_jitter", True)
        self.jitter_min = self.config.get("jitter_min", 0.01)  # 10ms
        self.jitter_max = self.config.get("jitter_max", 0.3)   # 300ms
        self.adaptive_jitter = self.config.get("adaptive_jitter", True)
        
        # === OPTIMIZATION: Cache Warmup (Січень 2026) ===
        # Запуск 1 вкладки спочатку для заповнення HTTP кешу
        # Рекомендовано для: block_resources=False, SPA парсинг
        self.enable_cache_warmup = self.config.get("enable_cache_warmup", False)
        self.cache_warmup_delay = self.config.get("cache_warmup_delay", 0.3)  # 300ms
        
        # === Метрики для моніторингу ===
        self._jitter_stats = {
            "total_jitter_applied_ms": 0.0,
            "jitter_count": 0,
            "cache_warmup_used": False,
        }

        # Suppress cleanup exceptions (TargetClosedError, InvalidStateError)
        self._exception_handler_installed = False

        logger.info(
            f"PooledPlaywrightDriver initialized: "
            f"max {self.max_browsers} browsers × {self.max_tabs_per_browser} tabs, "
            f"browser={self.browser_type}, headless={self.headless}, "
            f"memory_opt={self.memory_optimization}, block={self.block_resources}, "
            f"jitter={self.enable_jitter} ({self.jitter_min*1000:.0f}-{self.jitter_max*1000:.0f}ms), "
            f"adaptive_jitter={self.adaptive_jitter}, cache_warmup={self.enable_cache_warmup}"
        )

    def _calculate_distribution(self, num_urls: int) -> list[int]:
        """
        Розраховує розподіл URLs по браузерах.
        """
        if num_urls == 0:
            return []

        distribution = []
        remaining = num_urls

        while remaining > 0 and len(distribution) < self.max_browsers:
            tabs_in_browser = min(remaining, self.max_tabs_per_browser)
            distribution.append(tabs_in_browser)
            remaining -= tabs_in_browser

        return distribution

    async def _fetch_with_page(
        self, url: str, page: Any, browser_id: int, tab_id: int, jitter_delay: float = 0.0
    ) -> FetchResponse:
        """Fetch з semaphore для обмеження concurrent operations."""
        # Обмежуємо скільки сторінок вантажиться одночасно
        if self._fetch_semaphore:
            async with self._fetch_semaphore:
                return await self._fetch_with_page_impl(url, page, browser_id, tab_id, jitter_delay)
        else:
            return await self._fetch_with_page_impl(url, page, browser_id, tab_id, jitter_delay)

    async def _fetch_with_page_impl(
        self, url: str, page: Any, browser_id: int, tab_id: int, jitter_delay: float = 0.0
    ) -> FetchResponse:
        """Внутрішня реалізація fetch (без semaphore)."""
        start_time = time.time()
        ctx = BrowserContext(
            url=url,
            page=page,
            wait_selector=self.wait_selector,
            scroll_page=self.scroll_page,
            timeout=self.timeout,
        )

        try:
            # Використовуємо конфігурований fetch_timeout замість жорстко закодованих 45 секунд
            return await asyncio.wait_for(
                self._fetch_with_page_internal(url, page, ctx, browser_id, tab_id, start_time, jitter_delay),
                timeout=float(self.fetch_timeout),
            )
        except asyncio.TimeoutError:
            # Спробувати отримати частковий HTML що вже завантажився
            partial_html = None
            try:
                partial_html = await page.content()
            except Exception:
                pass  # Non-critical: partial content retrieval

            error_msg = f"Fetch timeout ({self.fetch_timeout}s) for {url}"
            logger.warning("%s (partial_html: %s)", error_msg, bool(partial_html))
            return FetchResponse(
                url=url,
                html=partial_html,  # Partial content замість None
                status_code=None,
                headers={},
                error=error_msg,
                is_partial=bool(partial_html),  # Позначаємо як partial
            )
        except Exception as e:
            error_msg = f"Error fetching {url}: {type(e).__name__}: {e}"
            logger.error(error_msg)
            return FetchResponse(url=url, html=None, status_code=None, headers={}, error=error_msg)

    async def _safe_get_content(self, page: Any, max_retries: int = 3, retry_delay: float = 0.5) -> str | None:
        """
        Безпечно отримує контент сторінки з retry при активній навігації.
        
        Проблема: деякі сайти (наприклад careers.ibm.com) роблять JS редіректи
        після початкової навігації, і page.content() падає з помилкою:
        "Unable to retrieve content because the page is navigating"
        
        Рішення: retry з невеликою затримкою поки сторінка стабілізується.
        """
        for attempt in range(max_retries):
            try:
                return await page.content()
            except Exception as e:
                error_str = str(e).lower()
                if "navigating" in error_str or "changing the content" in error_str:
                    if attempt < max_retries - 1:
                        logger.debug(f"Page still navigating, retry {attempt + 1}/{max_retries}")
                        await asyncio.sleep(retry_delay)
                        continue
                # Для інших помилок або останньої спроби - пробуємо ще раз
                raise
        return None

    async def _wait_for_navigation_stable(self, page: Any, max_checks: int = 5, check_interval: float = 0.3) -> None:
        """
        Чекає поки URL сторінки стабілізується (редіректи завершились).
        
        Деякі сайти роблять клієнтські редіректи через JS, які не блокують
        page.goto(). Ця функція чекає поки URL перестане змінюватись.
        """
        last_url = ""
        for _ in range(max_checks):
            current_url = page.url
            if current_url == last_url:
                return  # URL стабільний
            last_url = current_url
            await asyncio.sleep(check_interval)

    async def _fetch_with_page_internal(
        self,
        url: str,
        page: Any,
        ctx: BrowserContext,
        browser_id: int,
        tab_id: int,
        start_time: float,
        jitter_delay: float = 0.0,  # Затримка jitter, обчислена в _fetch_batch
    ) -> FetchResponse:
        try:
            # === OPTIMIZATION: Startup Jitter (Січень 2026) ===
            # Рандомна затримка перед навігацією для:
            # 1. Зменшення burst навантаження на мережу
            # 2. Обходу anti-bot детекції паттернів (burst = bot signature)
            # 3. Дозволу HTTP кешу заповнитись (cache race condition prevention)
            if jitter_delay > 0:
                await asyncio.sleep(jitter_delay)
                self._jitter_stats["total_jitter_applied_ms"] += jitter_delay * 1000
                self._jitter_stats["jitter_count"] += 1
                logger.debug(
                    f"Applied jitter {jitter_delay*1000:.1f}ms before fetching {url} "
                    f"(browser {browser_id}, tab {tab_id})"
                )
            
            # Хук перед навігацією
            ctx = await self.plugin_manager.execute_hook_async(
                BrowserStage.NAVIGATION_STARTING, ctx
            )

            # Навігація на сторінку
            # Використовуємо commit для швидшого старту, потім чекаємо DOM
            try:
                response = await page.goto(url, wait_until=self.wait_until, timeout=self.timeout)
            except Exception as nav_error:
                if "Timeout" in str(nav_error) and self.wait_until == "networkidle":
                    response = await page.goto(
                        url, wait_until="domcontentloaded", timeout=self.timeout
                    )
                else:
                    raise

            ctx.response = response
            ctx.status_code = response.status if response else None

            # Для статусів 202, 3xx чекаємо стабілізації URL (можливі JS редіректи)
            if ctx.status_code and (ctx.status_code == 202 or 300 <= ctx.status_code < 400):
                await self._wait_for_navigation_stable(page)

            ctx = await self.plugin_manager.execute_hook_async(
                BrowserStage.NAVIGATION_COMPLETED, ctx
            )
            if ctx.data.get("cloudflare_failed") or ctx.data.get("cloudflare_blocked"):
                error_msg = f"Cloudflare challenge failed for {url}"
                logger.warning(error_msg)
                return FetchResponse(
                    url=url, html=None, status_code=ctx.status_code, headers={}, error=error_msg
                )

            # Очікування селектора
            if self.wait_selector:
                try:
                    await page.wait_for_selector(self.wait_selector, timeout=self.wait_timeout)
                except Exception:
                    pass  # Non-critical: selector wait timeout

            # Параметризована затримка після селектора (замість hardcoded 2 сек)
            if self.post_selector_delay > 0:
                await asyncio.sleep(self.post_selector_delay)

            # Скрол сторінки (швидкий, виконується в браузері)
            if self.scroll_page:
                await self._scroll_page(page)
                # Параметризована затримка після скролу (замість hardcoded 1 сек)
                if self.post_scroll_delay > 0:
                    await asyncio.sleep(self.post_scroll_delay)
            
            # Отримуємо контент з retry при активній навігації
            html = await self._safe_get_content(page)
            ctx.html = html

            # Хук після отримання контенту
            ctx = await self.plugin_manager.execute_hook_async(BrowserStage.CONTENT_READY, ctx)

            # Фінальна перевірка на Cloudflare
            if ctx.data.get("cloudflare_failed") or ctx.data.get("cloudflare_blocked"):
                error_msg = f"Cloudflare challenge failed after content ready for {url}"
                logger.warning(error_msg)
                return FetchResponse(
                    url=url, html=ctx.html, status_code=ctx.status_code, headers={}, error=error_msg
                )

            headers = {}
            if response:
                headers = dict(await response.all_headers())

            duration = time.time() - start_time
            logger.debug("Fetched %s in %.2fs (browser %s, tab %s)", url, duration, browser_id, tab_id)

            return FetchResponse(
                url=url,
                html=ctx.html,
                status_code=ctx.status_code,
                headers=headers,
                error=ctx.error,
            )

        except asyncio.TimeoutError:
            # Спробувати отримати частковий HTML при navigation timeout
            partial_html = None
            partial_status = ctx.status_code if ctx else None
            try:
                partial_html = await self._safe_get_content(page, max_retries=2, retry_delay=0.3)
            except Exception:
                pass  # Non-critical: partial content retrieval

            error_msg = f"Navigation timeout for {url}"
            logger.warning("%s (partial_html: %s)", error_msg, bool(partial_html))
            return FetchResponse(
                url=url,
                html=partial_html,
                status_code=partial_status,
                headers={},
                error=error_msg,
                is_partial=bool(partial_html),
            )

        except Exception as e:
            error_msg = f"Error in fetch_with_page_internal: {type(e).__name__}: {e}"
            logger.error(error_msg)
            return FetchResponse(url=url, html=None, status_code=None, headers={}, error=error_msg)

    async def _wait_for_content_stable(self, page: Any, check_interval: float = 0.3, stable_checks: int = 2, max_wait: float = 3.0) -> bool:
        """Чекає стабілізації DOM контенту після lazy loading."""
        start = time.time()
        last_length = 0
        stable_count = 0
        
        while time.time() - start < max_wait:
            try:
                length = await page.evaluate("document.body?.innerHTML?.length || 0")
                if length == last_length:
                    stable_count += 1
                    if stable_count >= stable_checks:
                        return True
                else:
                    stable_count = 0
                last_length = length
            except Exception:
                pass
            await asyncio.sleep(check_interval)
        
        return False

    async def _scroll_page(self, page):
        """Скрол сторінки для завантаження lazy content з очікуванням стабілізації."""
        try:
            await page.evaluate("""
                async () => {
                    const delay = ms => new Promise(r => setTimeout(r, ms));
                    const height = document.body.scrollHeight;
                    const step = Math.max(height / 5, 500);
                    for (let y = 0; y < height; y += step) {
                        window.scrollTo(0, y);
                        await delay(100);
                    }
                    window.scrollTo(0, height);
                    await delay(200);
                    window.scrollTo(0, 0);
                }
            """)
        except Exception:
            try:
                await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                await asyncio.sleep(0.2)
                await page.evaluate("window.scrollTo(0, 0)")
            except Exception:
                pass
        
        # Чекаємо стабілізації контенту (для SPA/React)
        await self._wait_for_content_stable(page)

    async def _fetch_many_async(self, urls: list[str]) -> list[FetchResponse]:
        """
        Завантажує URLs батчами по total_slots (browsers × tabs).

        Якщо URLs > total_slots, обробляємо в кілька раундів:
        - Раунд 1: URLs[0:10]
        - Раунд 2: URLs[10:20]
        - і т.д.
        """
        if not urls:
            return []

        hint_ctx = BrowserContext(url="<fetch_many>", data={"total_urls": len(urls)})
        hint_ctx = await self.plugin_manager.execute_hook_async(BrowserStage.BEFORE_FETCH_MANY, hint_ctx)
        if "suggested_concurrent" in hint_ctx.data:
            self.max_concurrent_fetches = hint_ctx.data["suggested_concurrent"]

        if len(urls) > self.total_slots:
            logger.info(
                f"URLs ({len(urls)}) > slots ({self.total_slots}), "
                f"processing in batches of {self.total_slots}"
            )
            all_responses = []
            for i in range(0, len(urls), self.total_slots):
                batch = urls[i : i + self.total_slots]
                batch_num = i // self.total_slots + 1
                total_batches = (len(urls) + self.total_slots - 1) // self.total_slots
                logger.info("Processing batch %s/%s: %s URLs", batch_num, total_batches, len(batch))

                batch_responses = await self._fetch_batch(batch)
                all_responses.extend(batch_responses)

                # Невелика пауза між батчами для стабільності
                if i + self.total_slots < len(urls):
                    await asyncio.sleep(1.0)

            return all_responses
        else:
            return await self._fetch_batch(urls)

    async def _fetch_batch(self, urls: list[str]) -> list[FetchResponse]:
        """Обробляє один батч URLs (≤ total_slots)."""
        if not urls:
            return []

        distribution = self._calculate_distribution(len(urls))
        # Обмежує concurrent fetches щоб не було memory spike
        if self.max_concurrent_fetches < len(urls):
            self._fetch_semaphore = asyncio.Semaphore(self.max_concurrent_fetches)
            logger.debug("Fetch semaphore: max %s concurrent", self.max_concurrent_fetches)
        else:
            self._fetch_semaphore = None

        logger.info(
            f"Fetching {len(urls)} URLs: {len(distribution)} browser(s) with {distribution} tabs"
        )

        try:
            from playwright.async_api import async_playwright  # type: ignore[import-not-found]
        except ImportError:
            raise ImportError(
                "Playwright не встановлено. Виконайте: pip install playwright && playwright install"
            )

        # Install exception handler on first fetch (once per event loop)
        if not self._exception_handler_installed:
            _setup_asyncio_exception_handler()
            self._exception_handler_installed = True

        self.playwright = await async_playwright().start()
        browser_launcher = getattr(self.playwright, self.browser_type)

        browsers = []
        contexts = []
        pages = []
        tasks = []
        url_index = 0

        # Формуємо аргументи запуску
        # Можна перевизначити через config['args']
        if self.config.get("args"):
            launch_args = list(self.config.get("args"))
        else:
            launch_args = list(PLAYWRIGHT_STEALTH_ARGS)
            if self.memory_optimization:
                launch_args.extend(PLAYWRIGHT_MEMORY_ARGS)

        # Канал браузера (chrome, msedge, chrome-beta, etc.)
        browser_channel = self.config.get("channel")

        try:
            launch_kwargs = {
                "headless": self.headless,
                "args": launch_args,
            }
            if browser_channel:
                launch_kwargs["channel"] = browser_channel

            async def _launch_browser_with_tabs(browser_id: int, num_tabs: int):
                """Запускає один браузер з вкладками (виконується паралельно)."""
                browser = await browser_launcher.launch(**launch_kwargs)

                context = await browser.new_context(
                    user_agent=self.user_agent,
                    viewport=self.viewport,
                    java_script_enabled=self.javascript_enabled,
                )
                # Замість окремого handler на кожну page - один на context
                # Це значно економить RAM та CPU при багатьох вкладках
                if self.block_resources:
                    block_types = frozenset(self.block_resources)  # frozenset швидший

                    async def context_route_handler(route):
                        if route.request.resource_type in block_types:
                            await route.abort()
                        else:
                            await route.continue_()

                    await context.route("**/*", context_route_handler)
                    logger.debug(
                        f"Browser {browser_id}: route handler on context level (not per-page)"
                    )

                # Plugin hook для context
                ctx = BrowserContext(url="", context=context)
                await self.plugin_manager.execute_hook_async(BrowserStage.CONTEXT_CREATED, ctx)

                # Паралельне створення вкладок в межах одного браузера
                browser_pages = await asyncio.gather(*[context.new_page() for _ in range(num_tabs)])

                # Паралельне налаштування всіх вкладок (без route - він вже на context)
                async def _setup_page(page):
                    """Налаштовує одну вкладку (виконується паралельно)."""
                    page.set_default_timeout(self.timeout)

                    # Plugin hook для page
                    page_ctx = BrowserContext(url="", browser=browser, context=context, page=page)
                    await self.plugin_manager.execute_hook_async(
                        BrowserStage.PAGE_CREATED, page_ctx
                    )
                    return page

                # Налаштовуємо всі вкладки паралельно
                await asyncio.gather(*[_setup_page(page) for page in browser_pages])

                logger.debug("Browser %s launched with %s tabs", browser_id, num_tabs)
                return browser, context, browser_pages

            # Паралельний запуск всіх браузерів
            browser_results = await asyncio.gather(
                *[
                    _launch_browser_with_tabs(browser_id, num_tabs)
                    for browser_id, num_tabs in enumerate(distribution)
                ]
            )

            # Розпаковуємо результати
            for browser, context, browser_pages in browser_results:
                browsers.append(browser)
                contexts.append(context)
                pages.extend(browser_pages)
            
            # === OPTIMIZATION: Calculate Jitter Parameters (Січень 2026) ===
            # Обчислюємо jitter на основі контексту URLs
            unique_domains = len(set(extract_domain(u) for u in urls))
            has_block_resources = bool(self.block_resources)
            
            if self.enable_jitter:
                if self.adaptive_jitter:
                    # Адаптивний jitter на основі контексту
                    optimal_jitter = calculate_optimal_jitter(
                        num_tabs=len(urls),
                        unique_domains=unique_domains,
                        has_block_resources=has_block_resources,
                    )
                    jitter_min = self.jitter_min
                    jitter_max = min(self.jitter_max, optimal_jitter * 2)
                    logger.debug(
                        f"Adaptive jitter: {jitter_min*1000:.0f}-{jitter_max*1000:.0f}ms "
                        f"(tabs={len(urls)}, domains={unique_domains}, block={has_block_resources})"
                    )
                else:
                    jitter_min = self.jitter_min
                    jitter_max = self.jitter_max
            else:
                jitter_min = 0.0
                jitter_max = 0.0
            
            # === OPTIMIZATION: Cache Warmup (Січень 2026) ===
            # Запуск 1 вкладки спочатку для заповнення HTTP кешу
            warmup_tasks = []
            warmup_indices = set()
            
            if self.enable_cache_warmup and len(urls) > 1:
                # Знаходимо унікальні домени та вибираємо по одному URL для кожного
                domain_first_urls = {}
                for idx, url in enumerate(urls):
                    domain = extract_domain(url)
                    if domain not in domain_first_urls:
                        domain_first_urls[domain] = idx
                        warmup_indices.add(idx)
                
                # Обмежуємо кількість warmup URLs (не більше ніж сторінок)
                warmup_indices = set(list(warmup_indices)[:len(pages)])
                
                if warmup_indices:
                    self._jitter_stats["cache_warmup_used"] = True
                    logger.info(
                        f"Cache warmup: starting {len(warmup_indices)} tab(s) first "
                        f"for {len(domain_first_urls)} domain(s)"
                    )
                    
                    # Запускаємо warmup tasks (без jitter, вони перші)
                    for page_idx, url_idx in enumerate(sorted(warmup_indices)):
                        if page_idx < len(pages):
                            url = urls[url_idx]
                            page = pages[page_idx]
                            browser_id = 0
                            accumulated = 0
                            for bid, num_tabs in enumerate(distribution):
                                if page_idx < accumulated + num_tabs:
                                    browser_id = bid
                                    break
                                accumulated += num_tabs
                            
                            warmup_task = self._fetch_with_page(
                                url, page, browser_id, page_idx % self.max_tabs_per_browser, 0.0
                            )
                            warmup_tasks.append((url_idx, warmup_task))
                    
                    # Чекаємо завершення warmup
                    if warmup_tasks:
                        warmup_results = await asyncio.gather(
                            *[task for _, task in warmup_tasks], return_exceptions=True
                        )
                        logger.debug(f"Cache warmup completed, waiting {self.cache_warmup_delay}s")
                        await asyncio.sleep(self.cache_warmup_delay)
            
            # Створюємо tasks для решти URLs (з jitter)
            url_index = 0
            for i, page in enumerate(pages):
                browser_id = 0
                accumulated = 0
                for bid, num_tabs in enumerate(distribution):
                    if i < accumulated + num_tabs:
                        browser_id = bid
                        break
                    accumulated += num_tabs

                url = urls[url_index]
                
                # Пропускаємо URL якщо вже оброблено в warmup
                if url_index in warmup_indices:
                    url_index += 1
                    if url_index < len(urls):
                        url = urls[url_index]
                    else:
                        continue
                
                # Генеруємо рандомний jitter для цього запиту
                jitter_delay = random.uniform(jitter_min, jitter_max) if self.enable_jitter else 0.0
                
                task = self._fetch_with_page(url, page, browser_id, i % self.max_tabs_per_browser, jitter_delay)
                tasks.append((url_index, task))
                url_index += 1

            logger.info("Starting parallel fetch on %s tabs...", len(tasks))

            # Activate tabs to avoid background throttling
            for page in pages:
                try:
                    await page.bring_to_front()
                except Exception:
                    pass

            task_results = await asyncio.gather(
                *[task for _, task in tasks], return_exceptions=True
            )

            responses = [None] * len(urls)
            
            # Спочатку додаємо результати warmup tasks
            if warmup_tasks:
                for i, result in enumerate(warmup_results):
                    original_index = warmup_tasks[i][0]
                    if isinstance(result, Exception):
                        responses[original_index] = FetchResponse(
                            url=urls[original_index],
                            html=None,
                            status_code=None,
                            headers={},
                            error=f"Exception: {type(result).__name__}: {result}",
                        )
                    else:
                        responses[original_index] = result
            
            # Потім додаємо результати основних tasks
            for i, result in enumerate(task_results):
                original_index = tasks[i][0]
                if isinstance(result, Exception):
                    responses[original_index] = FetchResponse(
                        url=urls[original_index],
                        html=None,
                        status_code=None,
                        headers={},
                        error=f"Exception: {type(result).__name__}: {result}",
                    )
                else:
                    responses[original_index] = result

            success_count = sum(1 for r in responses if r and r.status_code == 200)
            failed_count = sum(1 for r in responses if r and r.error)
            cloudflare_failed = sum(
                1 for r in responses if r and r.error and "Cloudflare" in r.error
            )
            timeout_count = sum(
                1 for r in responses if r and r.error and "timeout" in r.error.lower()
            )

            logger.info(
                f"Fetch completed: {success_count}/{len(urls)} successful, "
                f"{failed_count} failed (Cloudflare: {cloudflare_failed}, Timeout: {timeout_count})"
            )

            return responses

        finally:
            logger.debug("Closing all browsers...")

            # Suppress asyncio "Future exception was never retrieved" warnings
            # Ці помилки виникають коли навігації ще активні при закритті браузера
            # Вони не критичні - результат вже отримано
            def _suppress_pending_exceptions():
                try:
                    loop = asyncio.get_running_loop()
                    for task in asyncio.all_tasks(loop):
                        if task.done() and not task.cancelled():
                            try:
                                # Retrieve exception to suppress warning
                                task.exception()
                            except (asyncio.CancelledError, asyncio.InvalidStateError):
                                pass
                except Exception:
                    pass  # Non-critical: cleanup/fallback

            async def _safe_close(coro, name: str, timeout: float = 2.0):
                """Безпечно закриває ресурс з таймаутом."""
                try:
                    await asyncio.wait_for(coro, timeout=timeout)
                except asyncio.TimeoutError:
                    logger.warning(" %s close timeout - forcing", name)
                except Exception as e:
                    # Suppress TargetClosedError - expected during cleanup
                    if "TargetClosedError" not in type(e).__name__:
                        logger.debug("%s close error: %s", name, e)

            # Закриваємо всі сторінки паралельно
            if pages:
                await asyncio.gather(
                    *[_safe_close(page.close(), f"Page {i}", 2.0) for i, page in enumerate(pages)]
                )

            # Закриваємо всі контексти паралельно
            if contexts:
                await asyncio.gather(
                    *[
                        _safe_close(context.close(), f"Context {i}", 2.0)
                        for i, context in enumerate(contexts)
                    ]
                )

            # Закриваємо всі браузери паралельно
            if browsers:
                await asyncio.gather(
                    *[
                        _safe_close(browser.close(), f"Browser {i}", 3.0)
                        for i, browser in enumerate(browsers)
                    ]
                )

            # Зупиняємо Playwright з таймаутом
            if self.playwright:
                try:
                    await asyncio.wait_for(self.playwright.stop(), timeout=3.0)
                    logger.debug("Playwright stopped successfully")
                except asyncio.TimeoutError:
                    logger.warning(" Playwright.stop() timeout - forcing cleanup")
                    self.playwright = None
                except Exception as e:
                    logger.debug("Playwright stop error: %s", e)
                finally:
                    self.playwright = None

            # Suppress pending Future exceptions from cancelled navigations
            _suppress_pending_exceptions()

            logger.debug("All browsers closed (cleanup complete)")

    async def fetch(self, url: str) -> FetchResponse:
        """Async завантаження однієї сторінки."""
        results = await self._fetch_many_async([url])
        return (
            results[0]
            if results
            else FetchResponse(url=url, html=None, status_code=None, headers={}, error="No result")
        )

    async def fetch_many(self, urls: list[str]) -> list[FetchResponse]:
        """Async паралельне завантаження багатьох сторінок."""
        return await self._fetch_many_async(urls)

    def supports_batch_fetching(self) -> bool:
        return True

    def get_pool_stats(self) -> dict[str, Any]:
        """
        Повертає статистику пулу браузерів та оптимізацій.
        
        Нові метрики (Січень 2026):
        - avg_jitter_applied_ms: середній застосований jitter
        - cache_warmup_enabled: чи увімкнено cache warmup
        - burst_factor: наскільки розподілений старт (0=burst, 1=рівномірно)
        """
        jitter_count = self._jitter_stats["jitter_count"]
        avg_jitter = (
            self._jitter_stats["total_jitter_applied_ms"] / jitter_count
            if jitter_count > 0
            else 0.0
        )
        
        # burst_factor: 0 = всі стартували одночасно, 1 = рівномірно розподілені
        # Формула: avg_jitter / max_jitter (нормалізовано)
        max_expected_jitter = self.jitter_max * 1000  # в мс
        burst_factor = min(avg_jitter / max_expected_jitter, 1.0) if max_expected_jitter > 0 else 0.0
        
        return {
            "max_browsers": self.max_browsers,
            "max_tabs_per_browser": self.max_tabs_per_browser,
            "total_slots": self.total_slots,
            # Нові метрики оптимізації
            "jitter_enabled": self.enable_jitter,
            "adaptive_jitter": self.adaptive_jitter,
            "jitter_range_ms": f"{self.jitter_min*1000:.0f}-{self.jitter_max*1000:.0f}",
            "avg_jitter_applied_ms": round(avg_jitter, 2),
            "jitter_applications_count": jitter_count,
            "cache_warmup_enabled": self.enable_cache_warmup,
            "cache_warmup_used": self._jitter_stats["cache_warmup_used"],
            "burst_factor": round(burst_factor, 3),
        }

    async def close(self) -> None:
        """Async закриває браузери, контексти, сторінки та плагіни."""

        # 1️⃣ Форсоване закриття плагінів з таймаутом
        try:
            await asyncio.wait_for(self.plugin_manager.teardown_all_async(), timeout=5.0)
        except asyncio.TimeoutError:
            logger.warning(" Plugin teardown timeout - skipping")
        except Exception as e:
            logger.debug("Plugin teardown error: %s", e)

        # 2️⃣ Паралельне закриття всіх браузерів
        if hasattr(self, "browsers") and self.browsers:

            async def _close_browser(i: int, browser):
                """Закриває браузер з таймаутом та force kill."""
                try:
                    await asyncio.wait_for(browser.close(), timeout=3.0)
                except asyncio.TimeoutError:
                    logger.warning(" Browser %s close timeout - forcing kill", i)
                    try:
                        browser.process().kill()
                    except Exception as e:
                        logger.error("Cannot kill browser %s: %s", i, e)
                except Exception as e:
                    logger.debug("Browser %s close error: %s", i, e)

            await asyncio.gather(
                *[_close_browser(i, browser) for i, browser in enumerate(self.browsers)]
            )

        # 3️⃣ Форсоване завершення Playwright
        if getattr(self, "playwright", None):
            try:
                await asyncio.wait_for(self.playwright.stop(), timeout=3.0)
            except asyncio.TimeoutError:
                logger.warning(" Playwright.stop() timeout - forcing cleanup")
                self.playwright = None
            except Exception as e:
                logger.debug("Playwright stop error: %s", e)
            finally:
                self.playwright = None

        logger.debug("PooledPlaywrightDriver closed (all resources released)")
