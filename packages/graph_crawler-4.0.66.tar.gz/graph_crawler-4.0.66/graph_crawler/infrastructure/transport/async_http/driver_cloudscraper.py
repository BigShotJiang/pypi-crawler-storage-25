"""AsyncCloudscraperDriver — async-обгортка над sync ``cloudscraper``.

``cloudscraper`` не має нативного async API, тому ми виконуємо sync-виклики
через ``asyncio.to_thread`` (Python 3.9+).

Що дає (на відміну від AsyncCurlCffiDriver):
- Обходить **Cloudflare JS Challenge / IUAM** (саме ті випадки, коли сайт
  повертає 503 + JS-сторінку, яку треба виконати).
- ``curl_cffi`` цього **не вміє** — він обходить тільки на TLS-рівні; коли
  Cloudflare ставить JS-челендж, потрібен саме ``cloudscraper`` або
  реальний браузер.

Обмеження:
- Виконується в thread pool → є GIL-обмеження.
- Concurrency в межах одного драйвера обмежена ``max_concurrent``
  та розміром thread pool (за замовчуванням ``asyncio.to_thread`` ділить
  default ThreadPoolExecutor, ~32 потоки).
- Для масового краулу через cloudscraper краще запускати batch-and-wait pattern.

Сценарії використання:
    >>> from graph_crawler.application.services.driver_factory import create_driver
    >>>
    >>> async with create_driver("cloudscraper_async") as driver:
    ...     resp = await driver.fetch("https://cf-protected.example.com")
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

try:
    import cloudscraper
    CLOUDSCRAPER_AVAILABLE = True
except ImportError:
    CLOUDSCRAPER_AVAILABLE = False
    cloudscraper = None  # type: ignore[assignment]

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.base_plugin import BaseDriverPlugin
from graph_crawler.infrastructure.transport.core.base_async import BaseAsyncDriver
from graph_crawler.infrastructure.transport.core.mixins import (
    PluginSupportMixin,
    RetryMixin,
)
from graph_crawler.shared.constants import (
    DEFAULT_MAX_CONCURRENT_REQUESTS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_RETRY_DELAY,
    DEFAULT_USER_AGENT,
)

logger = logging.getLogger(__name__)


class AsyncCloudscraperDriver(BaseAsyncDriver, PluginSupportMixin, RetryMixin):
    """
    Async-обгортка над sync ``cloudscraper`` через ``asyncio.to_thread``.

    Example:
        >>> async with AsyncCloudscraperDriver() as drv:
        ...     resp = await drv.fetch("https://cf-protected.example.com")

    Конфіг (всі ключі опціональні):
        - timeout: int
        - user_agent: str
        - max_retries: int
        - retry_delay: float
        - max_concurrent_requests: int
        - delay: float (cloudscraper-only)
        - debug: bool (cloudscraper-only)
        - browser: dict — {"browser": "chrome", "platform": "windows", "mobile": False}
        - proxy: str | None
    """

    driver_name = "cloudscraper_async"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        event_bus: EventBus | None = None,
        plugins: list[BaseDriverPlugin] | None = None,
    ):
        if not CLOUDSCRAPER_AVAILABLE:
            raise ImportError(
                "AsyncCloudscraperDriver requires cloudscraper. "
                "Install with: pip install cloudscraper"
            )

        BaseAsyncDriver.__init__(self, config, event_bus)
        self._init_plugin_support(plugins, is_async=True)

        self._timeout = self.config.get("timeout", DEFAULT_REQUEST_TIMEOUT)
        self._user_agent = self.config.get("user_agent", DEFAULT_USER_AGENT)
        self._max_retries = self.config.get("max_retries", DEFAULT_MAX_RETRIES)
        self._retry_delay = self.config.get("retry_delay", DEFAULT_RETRY_DELAY)

        self.max_concurrent = self.config.get(
            "max_concurrent_requests", DEFAULT_MAX_CONCURRENT_REQUESTS
        )

        browser_config = self.config.get("browser", {}) or {}
        self._scraper = cloudscraper.create_scraper(
            browser={
                "browser": browser_config.get("browser", "chrome"),
                "platform": browser_config.get("platform", "windows"),
                "mobile": browser_config.get("mobile", False),
            },
            delay=self.config.get("delay", 0),
            debug=self.config.get("debug", False),
        )
        if self._user_agent:
            self._scraper.headers.update({"User-Agent": self._user_agent})

        proxy = self.config.get("proxy")
        if proxy:
            self._scraper.proxies = {"http": proxy, "https": proxy}

        logger.info(
            "AsyncCloudscraperDriver: concurrent=%s, timeout=%ss, max_retries=%s",
            self.max_concurrent,
            self._timeout,
            self._max_retries,
        )

    # ------------------------------------------------------------------ #
    # Fetch logic
    # ------------------------------------------------------------------ #

    async def _do_fetch(self, url: str) -> FetchResponse:
        return await self._with_retry_async(
            self._fetch_in_thread,
            url,
            max_retries=self._max_retries,
            retry_delay=self._retry_delay,
            retry_on=(Exception,),
        )

    async def _fetch_in_thread(self, url: str) -> FetchResponse:
        """Викликає sync ``cloudscraper.get`` у thread pool через asyncio.to_thread."""
        return await asyncio.to_thread(self._sync_fetch, url)

    def _sync_fetch(self, url: str) -> FetchResponse:
        """Синхронний fetch (виконується в worker-thread)."""
        try:
            response = self._scraper.get(url, timeout=self._timeout)
            return FetchResponse(
                url=url,
                html=response.text,
                status_code=response.status_code,
                headers={k: str(v) for k, v in response.headers.items()},
            )
        except cloudscraper.exceptions.CloudflareChallengeError as e:
            logger.warning("Cloudflare challenge failed for %s: %s", url, e)
            return FetchResponse(
                url=url,
                html=None,
                status_code=None,
                headers={},
                error=f"CloudflareChallengeError: {e}",
            )

    # ------------------------------------------------------------------ #
    # Batch fetching with concurrency limit
    # ------------------------------------------------------------------ #

    async def fetch_many(self, urls: list[str]) -> list[FetchResponse]:
        if not urls:
            return []

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def fetch_limited(url: str) -> FetchResponse:
            async with semaphore:
                return await self.fetch(url)

        tasks = [fetch_limited(url) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed: list[FetchResponse] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed.append(
                    self._create_error_response(
                        urls[i], f"{type(result).__name__}: {result}"
                    )
                )
            else:
                processed.append(result)
        return processed

    async def fetch_fast(self, url: str) -> FetchResponse:
        """Ultra-fast fetch БЕЗ retry/плагінів (все ж виконується в thread)."""
        return await asyncio.to_thread(self._sync_fetch, url)

    async def fetch_many_fast(self, urls: list[str]) -> list[FetchResponse]:
        if not urls:
            return []

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def fetch_limited(url: str) -> FetchResponse:
            async with semaphore:
                return await self.fetch_fast(url)

        tasks = [asyncio.create_task(fetch_limited(url)) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed: list[FetchResponse] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed.append(
                    FetchResponse(
                        url=urls[i],
                        html=None,
                        status_code=None,
                        headers={},
                        error=f"{type(result).__name__}: {result}",
                    )
                )
            else:
                processed.append(result)
        return processed

    # ------------------------------------------------------------------ #
    # Cleanup
    # ------------------------------------------------------------------ #

    async def _do_close(self) -> None:
        if self._scraper is not None:
            try:
                # close() — sync, але дешевий, можна не виносити в thread
                self._scraper.close()
            except Exception as e:  # pragma: no cover
                logger.warning("cloudscraper close error: %s", e)
        await self._teardown_plugins_async()
