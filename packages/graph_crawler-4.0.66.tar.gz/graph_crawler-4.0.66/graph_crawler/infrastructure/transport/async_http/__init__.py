"""Async HTTP Driver module - asynchronous async-based drivers with plugin support.

Drivers:
- AsyncDriver (driver_v4.py): Main driver with adaptive DNS resolver (works on Windows!)
- AsyncDriverHTTP2 (driver_httpx.py): HTTP/2 support via httpx
- AsyncCurlCffiDriver (driver_curl_cffi.py): TLS fingerprint via curl_cffi (anti-bot bypass)
- AsyncCloudscraperDriver (driver_cloudscraper.py): Cloudflare JS challenge bypass
  via cloudscraper wrapped through asyncio.to_thread.
"""

from graph_crawler.infrastructure.transport.async_http.config import AsyncDriverConfig
from graph_crawler.infrastructure.transport.async_http.context import AsyncHTTPContext
from graph_crawler.infrastructure.transport.async_http.driver_cloudscraper import (
    AsyncCloudscraperDriver,
)
from graph_crawler.infrastructure.transport.async_http.driver_curl_cffi import (
    AsyncCurlCffiDriver,
)
from graph_crawler.infrastructure.transport.async_http.driver_httpx import AsyncDriverHTTP2
from graph_crawler.infrastructure.transport.async_http.driver_v4 import AsyncDriver
from graph_crawler.infrastructure.transport.async_http.stages import AsyncHTTPStage

__all__ = [
    "AsyncDriver",
    "AsyncDriverHTTP2",
    "AsyncCurlCffiDriver",
    "AsyncCloudscraperDriver",
    "AsyncDriverConfig",
    "AsyncHTTPStage",
    "AsyncHTTPContext",
]
