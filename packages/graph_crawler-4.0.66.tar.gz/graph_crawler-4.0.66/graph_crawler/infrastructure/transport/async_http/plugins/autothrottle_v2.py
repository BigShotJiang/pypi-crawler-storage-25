# graph_crawler/infrastructure/transport/async_http/plugins/autothrottle_v2_improved.py
"""
Enhanced AutoThrottle Plugin V2 — Production-Ready Adaptive Throttling.

IMPROVEMENTS V2 (April 2026):
- 🛡️ Robust edge case handling (zero delays, overflow protection)
- 🎯 Circuit breaker pattern для захисту від cascading failures
- 📐 Gradual recovery замість різкого backoff
- 🔒 Thread-safe operations з proper locking
- 📊 Exponential moving average для стабільніших метрик
- ✨ Clean code відповідно до CODE_STYLE_GUIDE.md

Architecture: Production-grade, battle-tested patterns
Version: 2.1
Author: E1 AI Agent (April 2026)
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional
from urllib.parse import urlparse

from graph_crawler.infrastructure.transport.async_http.context import AsyncHTTPContext
from graph_crawler.infrastructure.transport.async_http.stages import AsyncHTTPStage
from graph_crawler.infrastructure.transport.base_plugin import BaseDriverPlugin
from graph_crawler.infrastructure.transport.context import EventPriority

logger = logging.getLogger(__name__)

__all__ = [
    "EnhancedAutoThrottlePlugin",
    "EnhancedDomainSlot",
    "EnhancedAutoThrottleConfig",
    "ThrottleMode",
    "CircuitState",
]

# =============================================================================
# CONSTANTS
# =============================================================================

# Safety limits to prevent edge cases
MIN_SAFE_DELAY = 0.001  # 1ms мінімум для уникнення division by zero
MAX_SAFE_CONCURRENCY = 1000.0  # Захист від overflow
MIN_SAFE_CONCURRENCY = 0.1  # Мінімум для розрахунків

# Exponential Moving Average alpha
EMA_ALPHA = 0.3  # Вага нових даних (0.3 = 30% нові, 70% історія)

# Circuit breaker
CIRCUIT_FAILURE_THRESHOLD = 5  # Кількість помилок для відкриття circuit
CIRCUIT_SUCCESS_THRESHOLD = 3  # Кількість успіхів для закриття
CIRCUIT_HALF_OPEN_TIMEOUT = 10.0  # Секунд до спроби відновлення


# =============================================================================
# ENUMS
# =============================================================================

class ThrottleMode(Enum):
    """Режим роботи throttle алгоритму."""

    SLOW_START = "slow_start"
    ADDITIVE_INCREASE = "additive"
    MULTIPLICATIVE_DECREASE = "mult"
    CONGESTION_AVOIDANCE = "avoidance"
    FAST_RECOVERY = "recovery"
    BLOCKED = "blocked"


class CircuitState(Enum):
    """Стан circuit breaker."""

    CLOSED = "closed"  # Нормальна робота
    OPEN = "open"  # Circuit відкритий, запити блокуються
    HALF_OPEN = "half_open"  # Тестування відновлення


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class EnhancedAutoThrottleConfig:
    """
    Production-ready конфігурація для Enhanced AutoThrottle V2.

    Attributes:
        start_delay: Початкова затримка між запитами (секунди)
        min_delay: Мінімальна затримка (не може бути < MIN_SAFE_DELAY)
        max_delay: Максимальна затримка (upper bound)
        initial_concurrency: Початкова кількість паралельних запитів
        min_concurrency: Мінімальна concurrency
        max_concurrency: Максимальна concurrency (не може бути > MAX_SAFE_CONCURRENCY)
        additive_increase: Крок збільшення concurrency (AIMD)
        multiplicative_decrease: Множник зменшення concurrency (AIMD)
        error_threshold: Поріг error rate для slowdown (%)
        success_threshold: Поріг success rate для speedup (%)
        rate_limit_backoff: Множник при rate limiting
        max_backoff_delay: Максимальна затримка при backoff
        gradual_recovery_steps: Кількість кроків для поступового відновлення
        optimization_interval: Інтервал запитів між оптимізаціями
        use_ema: Використовувати Exponential Moving Average
        enable_circuit_breaker: Увімкнути circuit breaker
        debug: Детальне логування
    """

    # Базові параметри
    start_delay: float = 2.0
    min_delay: float = 0.05
    max_delay: float = 60.0

    # Concurrency
    initial_concurrency: float = 2.0
    min_concurrency: float = 1.0
    max_concurrency: float = 16.0

    # AIMD
    additive_increase: float = 0.5
    multiplicative_decrease: float = 0.5

    # Пороги
    error_threshold: float = 5.0
    success_threshold: float = 95.0

    # Rate limiting
    rate_limit_backoff: float = 3.0
    max_backoff_delay: float = 300.0

    # Recovery
    gradual_recovery_steps: int = 5

    optimization_interval: int = 20

    # Advanced features
    use_ema: bool = True
    enable_circuit_breaker: bool = True

    # Debug
    debug: bool = False

    def __post_init__(self):
        """Валідація конфігурації."""
        # Validate concurrency
        if self.initial_concurrency < self.min_concurrency:
            raise ValueError(
                f"initial_concurrency ({self.initial_concurrency}) < "
                f"min_concurrency ({self.min_concurrency})"
            )

        if self.min_concurrency <= 0:
            raise ValueError(f"min_concurrency must be > 0, got {self.min_concurrency}")

        if self.max_concurrency > MAX_SAFE_CONCURRENCY:
            raise ValueError(
                f"max_concurrency ({self.max_concurrency}) > "
                f"MAX_SAFE_CONCURRENCY ({MAX_SAFE_CONCURRENCY})"
            )

        # Validate delays
        if self.min_delay < MIN_SAFE_DELAY:
            raise ValueError(
                f"min_delay ({self.min_delay}) < "
                f"MIN_SAFE_DELAY ({MIN_SAFE_DELAY})"
            )

        if self.min_delay > self.max_delay:
            raise ValueError(
                f"min_delay ({self.min_delay}) > max_delay ({self.max_delay})"
            )

        # Validate AIMD parameters
        if self.additive_increase <= 0:
            raise ValueError(
                f"additive_increase must be > 0, got {self.additive_increase}"
            )

        if not 0 < self.multiplicative_decrease < 1:
            raise ValueError(
                f"multiplicative_decrease must be in (0, 1), "
                f"got {self.multiplicative_decrease}"
            )

    @classmethod
    def wikipedia_optimized(cls) -> "EnhancedAutoThrottleConfig":
        """Оптимізовано для Wikipedia."""
        return cls(
            start_delay=0.5,
            min_delay=0.05,
            max_delay=10.0,
            initial_concurrency=4.0,
            min_concurrency=1.0,
            max_concurrency=16.0,
            additive_increase=1.0,
            multiplicative_decrease=0.5,
            error_threshold=3.0,
            success_threshold=97.0,
            gradual_recovery_steps=4,
            use_ema=True,
            enable_circuit_breaker=True,
            debug=False,
        )

    @classmethod
    def aggressive(cls) -> "EnhancedAutoThrottleConfig":
        """Агресивний режим для потужних серверів."""
        return cls(
            start_delay=0.1,
            min_delay=0.01,
            max_delay=5.0,
            initial_concurrency=8.0,
            min_concurrency=2.0,
            max_concurrency=32.0,
            additive_increase=2.0,
            multiplicative_decrease=0.5,
            error_threshold=2.0,
            success_threshold=98.0,
            gradual_recovery_steps=3,
            use_ema=True,
            enable_circuit_breaker=True,
        )

    @classmethod
    def conservative(cls) -> "EnhancedAutoThrottleConfig":
        """Консервативний режим для чутливих сайтів."""
        return cls(
            start_delay=5.0,
            min_delay=1.0,
            max_delay=120.0,
            initial_concurrency=1.0,
            min_concurrency=0.5,
            max_concurrency=4.0,
            additive_increase=0.25,
            multiplicative_decrease=0.5,
            error_threshold=8.0,
            success_threshold=92.0,
            gradual_recovery_steps=10,
            use_ema=True,
            enable_circuit_breaker=True,
        )


# =============================================================================
# DOMAIN SLOT WITH CIRCUIT BREAKER
# =============================================================================

@dataclass(slots=True)
class EnhancedDomainSlot:
    """
    Production-ready слот з circuit breaker та EMA.

    Improvements:
    - Circuit breaker для захисту від cascading failures
    - Exponential Moving Average для стабільних метрик
    - Gradual recovery замість різкого backoff
    - Safe математичні операції
    """

    domain: str

    # Поточний стан
    delay: float = 2.0
    target_concurrency: float = 2.0
    mode: ThrottleMode = ThrottleMode.SLOW_START
    last_request_time: float = field(default_factory=time.time)

    # Circuit breaker
    circuit_state: CircuitState = CircuitState.CLOSED
    circuit_failures: int = 0
    circuit_successes: int = 0
    circuit_last_failure: float = 0.0

    # Активні запити
    active_requests: int = 0

    # Лічильники
    total_requests: int = 0
    success_count: int = 0
    error_count: int = 0
    rate_limit_count: int = 0
    timeout_count: int = 0

    # Latency з EMA
    recent_latencies: deque = field(default_factory=lambda: deque(maxlen=100))
    ema_latency: float = 0.0

    # Throughput
    last_throughput_check: float = field(default_factory=time.time)
    requests_since_check: int = 0
    current_throughput: float = 0.0
    best_throughput: float = 0.0

    # Gradual recovery
    recovery_step: int = 0
    recovery_target_concurrency: float = 0.0

    optimization_counter: int = 0

    # Backoff
    consecutive_errors: int = 0
    in_backoff: bool = False
    backoff_until: float = 0.0
    backoff_level: int = 0  # Для exponential backoff

    def _safe_divide(self, numerator: float, denominator: float, default: float = 0.0) -> float:
        """Безпечне ділення з захистом від division by zero."""
        if denominator == 0 or denominator < MIN_SAFE_DELAY:
            return default
        return numerator / denominator

    @property
    def avg_latency(self) -> float:
        if not self.recent_latencies:
            return 0.0
        return sum(self.recent_latencies) / len(self.recent_latencies)

    @property
    def p95_latency(self) -> float:
        if not self.recent_latencies:
            return 0.0
        sorted_latencies = sorted(self.recent_latencies)
        idx = min(int(len(sorted_latencies) * 0.95), len(sorted_latencies) - 1)
        return sorted_latencies[idx]

    @property
    def error_rate(self) -> float:
        """Відсоток помилок (%)."""
        if self.total_requests == 0:
            return 0.0
        return (self.error_count / self.total_requests) * 100

    @property
    def success_rate(self) -> float:
        """Відсоток успішних запитів (%)."""
        if self.total_requests == 0:
            return 100.0
        return (self.success_count / self.total_requests) * 100

    @property
    def effective_rps(self) -> float:
        """Ефективна швидкість (requests/sec) з safe division."""
        return self._safe_divide(
            self.target_concurrency,
            max(self.delay, MIN_SAFE_DELAY),
            default=0.0
        )

    def update_ema_latency(self, new_latency: float, alpha: float = EMA_ALPHA) -> None:
        """
        Оновити EMA latency для стабільніших метрик.

        Args:
            new_latency: Нова latency
            alpha: Вага нових даних (0.3 = 30% нові, 70% історія)
        """
        if self.ema_latency == 0.0:
            # Перше значення
            self.ema_latency = new_latency
        else:
            # EMA: new_ema = alpha * new_value + (1 - alpha) * old_ema
            self.ema_latency = alpha * new_latency + (1 - alpha) * self.ema_latency

    def update_throughput(self) -> None:
        now = time.time()
        elapsed = now - self.last_throughput_check

        if elapsed >= 1.0:
            self.current_throughput = self._safe_divide(
                self.requests_since_check,
                elapsed,
                default=0.0
            )

            if self.current_throughput > self.best_throughput:
                self.best_throughput = self.current_throughput

            self.requests_since_check = 0
            self.last_throughput_check = now

    def is_in_backoff(self) -> bool:
        """Перевірити чи в backoff режимі."""
        if self.in_backoff and time.time() < self.backoff_until:
            return True

        if self.in_backoff:
            # Backoff закінчився
            self.in_backoff = False
            self.backoff_until = 0.0

        return False

    def should_circuit_open(self, threshold: int = CIRCUIT_FAILURE_THRESHOLD) -> bool:
        return (
            self.circuit_state == CircuitState.CLOSED
            and self.circuit_failures >= threshold
        )

    def should_circuit_attempt_recovery(self) -> bool:
        """Перевірити чи можна спробувати відновлення."""
        if self.circuit_state != CircuitState.OPEN:
            return False

        time_since_failure = time.time() - self.circuit_last_failure
        return time_since_failure >= CIRCUIT_HALF_OPEN_TIMEOUT

    def should_circuit_close(self, threshold: int = CIRCUIT_SUCCESS_THRESHOLD) -> bool:
        return (
            self.circuit_state == CircuitState.HALF_OPEN
            and self.circuit_successes >= threshold
        )

    def to_dict(self) -> dict[str, Any]:
        """Експорт метрик."""
        return {
            "domain": self.domain,
            "delay_ms": round(self.delay * 1000, 2),
            "target_concurrency": round(self.target_concurrency, 2),
            "mode": self.mode.value,
            "circuit_state": self.circuit_state.value,
            "active_requests": self.active_requests,
            "total_requests": self.total_requests,
            "success_rate": round(self.success_rate, 2),
            "error_rate": round(self.error_rate, 2),
            "rate_limit_count": self.rate_limit_count,
            "avg_latency_ms": round(self.avg_latency * 1000, 2),
            "ema_latency_ms": round(self.ema_latency * 1000, 2),
            "p95_latency_ms": round(self.p95_latency * 1000, 2),
            "current_rps": round(self.current_throughput, 3),
            "best_rps": round(self.best_throughput, 3),
            "effective_rps": round(self.effective_rps, 3),
            "in_backoff": self.in_backoff,
            "recovery_step": self.recovery_step,
        }


# =============================================================================
# ENHANCED AUTOTHROTTLE PLUGIN V2
# =============================================================================

class EnhancedAutoThrottlePlugin(BaseDriverPlugin):
    """
    Production-ready AutoThrottle з circuit breaker та gradual recovery.

    IMPROVEMENTS V2:
    1. Circuit Breaker Pattern:
       - Захист від cascading failures
       - Автоматичне відновлення через half-open state

    2. Gradual Recovery:
       - Поступове відновлення після блокування
       - Уникнення thundering herd problem

    3. Safe Math Operations:
       - Захист від division by zero
       - Overflow protection
       - Bounds checking

    4. Exponential Moving Average:
       - Стабільніші метрики
       - Менше noise в measurements

    5. Clean Code:
       - Відповідність CODE_STYLE_GUIDE.md
       - Proper error handling
       - Comprehensive logging
    """

    CTX_START_TIME = "enhanced_autothrottle_v2_start_time"
    CTX_DOMAIN = "enhanced_autothrottle_v2_domain"

    def __init__(
        self,
        config: EnhancedAutoThrottleConfig | dict[str, Any] | None = None,
        priority: int = EventPriority.HIGH,
    ):
        """Ініціалізація Enhanced AutoThrottle V2."""
        # Обробка конфігурації
        if config is None:
            throttle_config = EnhancedAutoThrottleConfig()
        elif isinstance(config, EnhancedAutoThrottleConfig):
            throttle_config = config
        else:
            throttle_config = EnhancedAutoThrottleConfig(**config)

        config_dict = asdict(throttle_config)
        super().__init__(config=config_dict, priority=priority)

        self._config = throttle_config
        self._slots: dict[str, EnhancedDomainSlot] = {}
        self._lock = asyncio.Lock()

        logger.info(
            "🚀 EnhancedAutoThrottlePlugin V2 initialized: "
            "concurrency=[%.1f-%.1f], delay=[%.3fs-%.3fs], "
            "circuit_breaker=%s, ema=%s",
            self._config.min_concurrency,
            self._config.max_concurrency,
            self._config.min_delay,
            self._config.max_delay,
            self._config.enable_circuit_breaker,
            self._config.use_ema,
        )

    @property
    def name(self) -> str:
        return "enhanced_autothrottle_v2"

    def get_hooks(self) -> list[str]:
        return [
            AsyncHTTPStage.PREPARING_REQUEST,
            AsyncHTTPStage.RESPONSE_RECEIVED,
            AsyncHTTPStage.REQUEST_FAILED,
        ]

    # -------------------------------------------------------------------------
    # DOMAIN MANAGEMENT
    # -------------------------------------------------------------------------

    @staticmethod
    def _extract_domain(url: str) -> str:
        """Витягує домен з URL."""
        parsed = urlparse(url)
        return parsed.netloc or parsed.path.split("/")[0] or url

    async def _get_or_create_slot(self, domain: str) -> EnhancedDomainSlot:
        """Отримує або створює слот."""
        async with self._lock:
            if domain not in self._slots:
                self._slots[domain] = EnhancedDomainSlot(
                    domain=domain,
                    delay=self._config.start_delay,
                    target_concurrency=self._config.initial_concurrency,
                )
                logger.debug("[EnhancedThrottle V2] Created slot: %s", domain)

            return self._slots[domain]

    # -------------------------------------------------------------------------
    # SAFE HELPERS
    # -------------------------------------------------------------------------

    def _clamp_value(self, value: float, min_val: float, max_val: float) -> float:
        """Обмежити значення діапазоном."""
        return max(min_val, min(value, max_val))

    def _safe_delay(self, delay: float) -> float:
        return self._clamp_value(delay, self._config.min_delay, self._config.max_delay)

    def _safe_concurrency(self, concurrency: float) -> float:
        return self._clamp_value(
            concurrency,
            self._config.min_concurrency,
            min(self._config.max_concurrency, MAX_SAFE_CONCURRENCY),
        )

    # -------------------------------------------------------------------------
    # CIRCUIT BREAKER
    # -------------------------------------------------------------------------

    async def _check_circuit_breaker(self, slot: EnhancedDomainSlot) -> bool:
        """
        Перевірити circuit breaker.

        Returns:
            True якщо запит можна виконувати, False якщо треба блокувати
        """
        if not self._config.enable_circuit_breaker:
            return True

        if slot.circuit_state == CircuitState.CLOSED:
            return True

        if slot.circuit_state == CircuitState.OPEN:
            if slot.should_circuit_attempt_recovery():
                # Спробувати перейти в HALF_OPEN
                slot.circuit_state = CircuitState.HALF_OPEN
                slot.circuit_successes = 0
                slot.circuit_failures = 0

                logger.info(
                    "[EnhancedThrottle V2][%s] 🔄 Circuit HALF_OPEN - attempting recovery",
                    slot.domain,
                )
                return True

            # Circuit все ще відкритий
            if self._config.debug:
                logger.debug(
                    "[EnhancedThrottle V2][%s] ⛔ Circuit OPEN - blocking request",
                    slot.domain,
                )
            return False

        # HALF_OPEN - дозволяємо запити для тестування
        return True

    async def _handle_circuit_success(self, slot: EnhancedDomainSlot) -> None:
        if not self._config.enable_circuit_breaker:
            return

        if slot.circuit_state == CircuitState.CLOSED:
            # Скидаємо лічильник помилок
            slot.circuit_failures = 0
            return

        if slot.circuit_state == CircuitState.HALF_OPEN:
            slot.circuit_successes += 1

            if slot.should_circuit_close():
                slot.circuit_state = CircuitState.CLOSED
                slot.circuit_failures = 0
                slot.circuit_successes = 0

                logger.info(
                    "[EnhancedThrottle V2][%s] ✅ Circuit CLOSED - recovery successful",
                    slot.domain,
                )

    async def _handle_circuit_failure(self, slot: EnhancedDomainSlot) -> None:
        if not self._config.enable_circuit_breaker:
            return

        slot.circuit_failures += 1
        slot.circuit_last_failure = time.time()

        if slot.circuit_state == CircuitState.HALF_OPEN:
            # Повертаємось в OPEN при помилці під час recovery
            slot.circuit_state = CircuitState.OPEN
            slot.circuit_successes = 0

            logger.warning(
                "[EnhancedThrottle V2][%s] 🔴 Circuit OPEN - recovery failed",
                slot.domain,
            )

        elif slot.should_circuit_open():
            slot.circuit_state = CircuitState.OPEN

            logger.error(
                "[EnhancedThrottle V2][%s] 🚨 Circuit OPENED - too many failures (%d)",
                slot.domain,
                slot.circuit_failures,
            )

    # -------------------------------------------------------------------------
    # AIMD ALGORITHM WITH GRADUAL RECOVERY
    # -------------------------------------------------------------------------

    def _should_increase_throughput(self, slot: EnhancedDomainSlot) -> bool:
        """Перевірити чи можна збільшити throughput."""
        # Не збільшуємо якщо:
        # 1. В backoff режимі
        # 2. Circuit відкритий
        # 3. Недостатньо даних
        # 4. Низький success rate

        if slot.is_in_backoff() or slot.circuit_state != CircuitState.CLOSED:
            return False

        if slot.total_requests < 10:
            return False

        # Перевіряємо метрики
        has_good_success_rate = slot.success_rate >= self._config.success_threshold
        has_low_error_rate = slot.error_rate <= self._config.error_threshold
        no_recent_rate_limits = (
            slot.rate_limit_count == 0 or slot.total_requests > slot.rate_limit_count * 20
        )

        return has_good_success_rate and has_low_error_rate and no_recent_rate_limits

    def _should_decrease_throughput(self, slot: EnhancedDomainSlot) -> bool:
        """Перевірити чи потрібно зменшити throughput."""
        # Зменшуємо якщо:
        # 1. Високий error rate
        # 2. Rate limiting виявлено
        # 3. Багато consecutive errors

        if slot.error_rate > self._config.error_threshold:
            return True

        if slot.rate_limit_count > 0 and slot.total_requests < 100:
            return True

        if slot.consecutive_errors >= 3:
            return True

        return False

    async def _apply_aimd_increase(self, slot: EnhancedDomainSlot) -> None:
        """Additive Increase - обережне збільшення."""
        async with self._lock:
            old_concurrency = slot.target_concurrency
            old_delay = slot.delay

            # Збільшуємо concurrency
            new_concurrency = slot.target_concurrency + self._config.additive_increase
            slot.target_concurrency = self._safe_concurrency(new_concurrency)

            # Пропорційне зменшення delay
            if slot.target_concurrency > old_concurrency and old_concurrency > 0:
                ratio = old_concurrency / slot.target_concurrency
                new_delay = slot.delay * ratio
                slot.delay = self._safe_delay(new_delay)

            slot.mode = ThrottleMode.ADDITIVE_INCREASE

            if self._config.debug:
                logger.info(
                    "[EnhancedThrottle V2][%s] 📈 AIMD Increase: "
                    "concurrency %.1f→%.1f, delay %.0f→%.0fms",
                    slot.domain,
                    old_concurrency,
                    slot.target_concurrency,
                    old_delay * 1000,
                    slot.delay * 1000,
                )

    async def _apply_aimd_decrease(self, slot: EnhancedDomainSlot) -> None:
        """Multiplicative Decrease - швидке зменшення."""
        async with self._lock:
            old_concurrency = slot.target_concurrency
            old_delay = slot.delay

            # Зменшуємо concurrency
            new_concurrency = slot.target_concurrency * self._config.multiplicative_decrease
            slot.target_concurrency = self._safe_concurrency(new_concurrency)

            # Збільшуємо delay
            new_delay = slot.delay / self._config.multiplicative_decrease
            slot.delay = self._safe_delay(new_delay)

            slot.mode = ThrottleMode.MULTIPLICATIVE_DECREASE

            if self._config.debug:
                logger.warning(
                    "[EnhancedThrottle V2][%s] 📉 AIMD Decrease: "
                    "concurrency %.1f→%.1f, delay %.0f→%.0fms (error_rate=%.1f%%)",
                    slot.domain,
                    old_concurrency,
                    slot.target_concurrency,
                    old_delay * 1000,
                    slot.delay * 1000,
                    slot.error_rate,
                )

    # -------------------------------------------------------------------------
    # GRADUAL RECOVERY
    # -------------------------------------------------------------------------

    async def _start_gradual_recovery(self, slot: EnhancedDomainSlot) -> None:
        """Почати поступове відновлення після backoff."""
        async with self._lock:
            # Зберігаємо target для поступового досягнення
            slot.recovery_target_concurrency = slot.target_concurrency
            slot.recovery_step = 0

            # Починаємо з мінімальної concurrency
            slot.target_concurrency = self._config.min_concurrency
            slot.mode = ThrottleMode.FAST_RECOVERY

            logger.info(
                "[EnhancedThrottle V2][%s] 🔄 Starting gradual recovery: "
                "target_concurrency=%.1f, steps=%d",
                slot.domain,
                slot.recovery_target_concurrency,
                self._config.gradual_recovery_steps,
            )

    async def _step_gradual_recovery(self, slot: EnhancedDomainSlot) -> None:
        """Крок поступового відновлення."""
        if slot.mode != ThrottleMode.FAST_RECOVERY:
            return

        async with self._lock:
            slot.recovery_step += 1

            if slot.recovery_step >= self._config.gradual_recovery_steps:
                # Recovery завершено
                slot.target_concurrency = slot.recovery_target_concurrency
                slot.mode = ThrottleMode.CONGESTION_AVOIDANCE
                slot.recovery_step = 0

                logger.info(
                    "[EnhancedThrottle V2][%s] ✅ Gradual recovery complete: "
                    "concurrency=%.1f",
                    slot.domain,
                    slot.target_concurrency,
                )
            else:
                # Поступове збільшення
                progress = slot.recovery_step / self._config.gradual_recovery_steps
                new_concurrency = (
                    self._config.min_concurrency
                    + (slot.recovery_target_concurrency - self._config.min_concurrency)
                    * progress
                )
                slot.target_concurrency = self._safe_concurrency(new_concurrency)

                if self._config.debug:
                    logger.debug(
                        "[EnhancedThrottle V2][%s] Recovery step %d/%d: concurrency=%.1f",
                        slot.domain,
                        slot.recovery_step,
                        self._config.gradual_recovery_steps,
                        slot.target_concurrency,
                    )

    # -------------------------------------------------------------------------
    # RATE LIMITING
    # -------------------------------------------------------------------------

    def _is_rate_limited(self, status_code: int) -> bool:
        return status_code in (429, 503, 509)

    async def _handle_rate_limiting(self, slot: EnhancedDomainSlot) -> None:
        async with self._lock:
            slot.rate_limit_count += 1
            slot.backoff_level += 1

            old_delay = slot.delay

            # Exponential backoff: delay * (backoff_factor ^ level)
            backoff_multiplier = self._config.rate_limit_backoff ** slot.backoff_level
            new_delay = slot.delay * backoff_multiplier
            slot.delay = min(new_delay, self._config.max_backoff_delay)

            # Зменшуємо concurrency до мінімуму
            slot.target_concurrency = self._config.min_concurrency

            # Встановлюємо backoff період
            slot.in_backoff = True
            slot.backoff_until = time.time() + slot.delay
            slot.mode = ThrottleMode.BLOCKED

            logger.error(
                "[EnhancedThrottle V2][%s] 🚨 RATE LIMIT! "
                "Backoff level %d: %.0f→%.0fms, wait=%.1fs",
                slot.domain,
                slot.backoff_level,
                old_delay * 1000,
                slot.delay * 1000,
                slot.delay,
            )

            # Запускаємо circuit breaker
            await self._handle_circuit_failure(slot)

    # -------------------------------------------------------------------------
    # OPTIMIZATION
    # -------------------------------------------------------------------------

    async def _optimize_parameters(self, slot: EnhancedDomainSlot) -> None:
        """Періодична оптимізація параметрів."""
        async with self._lock:
            slot.optimization_counter += 1

            if slot.optimization_counter < self._config.optimization_interval:
                return

            slot.optimization_counter = 0
            slot.update_throughput()


        if slot.mode == ThrottleMode.FAST_RECOVERY:
            await self._step_gradual_recovery(slot)
        elif self._should_increase_throughput(slot):
            await self._apply_aimd_increase(slot)
        elif self._should_decrease_throughput(slot):
            await self._apply_aimd_decrease(slot)

        # Скидаємо consecutive errors якщо все добре
        async with self._lock:
            if slot.success_rate > self._config.success_threshold:
                slot.consecutive_errors = 0
                # Зменшуємо backoff level при успіхах
                if slot.backoff_level > 0:
                    slot.backoff_level = max(0, slot.backoff_level - 1)

    # -------------------------------------------------------------------------
    # LIFECYCLE HOOKS
    # -------------------------------------------------------------------------

    async def on_preparing_request(self, ctx: AsyncHTTPContext) -> AsyncHTTPContext:
        """Підготовка запиту з throttling."""
        domain = self._extract_domain(ctx.url)
        slot = await self._get_or_create_slot(domain)

        # Circuit breaker check
        can_proceed = await self._check_circuit_breaker(slot)
        if not can_proceed:
            # Блокуємо запит - circuit відкритий
            # Можна кинути exception або просто чекати
            await asyncio.sleep(CIRCUIT_HALF_OPEN_TIMEOUT)
            return ctx

        # Backoff check
        if slot.is_in_backoff():
            wait_time = slot.backoff_until - time.time()
            if wait_time > 0:
                if self._config.debug:
                    logger.debug(
                        "[EnhancedThrottle V2][%s] ⏸️ Backoff wait: %.1fs",
                        domain,
                        wait_time,
                    )
                await asyncio.sleep(wait_time)
                slot.in_backoff = False

                # Починаємо gradual recovery
                await self._start_gradual_recovery(slot)

        # Обчислюємо wait time та резервуємо слот
        wait_time = 0.0
        async with self._lock:
            now = time.time()
            time_since_last = now - slot.last_request_time
            wait_time = slot.delay - time_since_last

            if wait_time > 0:
                slot.last_request_time = now + wait_time
            else:
                slot.last_request_time = now

            slot.active_requests += 1
            slot.requests_since_check += 1

        # Sleep без lock
        if wait_time > 0:
            await asyncio.sleep(wait_time)

        # Зберігаємо метадані
        ctx.data[self.CTX_START_TIME] = time.time()
        ctx.data[self.CTX_DOMAIN] = domain

        return ctx

    async def on_response_received(self, ctx: AsyncHTTPContext) -> AsyncHTTPContext:
        """Обробка відповіді."""
        domain = ctx.data.get(self.CTX_DOMAIN)
        start_time = ctx.data.get(self.CTX_START_TIME)

        if not domain or start_time is None:
            return ctx

        latency = time.time() - start_time
        status_code = ctx.status_code or 0

        slot = await self._get_or_create_slot(domain)

        async with self._lock:
            # Оновлюємо лічильники
            slot.active_requests = max(0, slot.active_requests - 1)
            slot.total_requests += 1
            slot.recent_latencies.append(latency)

            # Оновлюємо EMA latency
            if self._config.use_ema:
                slot.update_ema_latency(latency)

        # Rate limiting check
        if self._is_rate_limited(status_code):
            await self._handle_rate_limiting(slot)
            return ctx

        # Записуємо результат
        async with self._lock:
            if 200 <= status_code < 300:
                slot.success_count += 1
                slot.consecutive_errors = 0
                await self._handle_circuit_success(slot)
            else:
                slot.error_count += 1
                slot.consecutive_errors += 1
                await self._handle_circuit_failure(slot)

        await self._optimize_parameters(slot)

        if self._config.debug and slot.total_requests % 10 == 0:
            logger.info(
                "[EnhancedThrottle V2][%s] 📊 mode=%s, circuit=%s, "
                "concurrency=%.1f, delay=%.0fms, rps=%.2f, success=%.1f%%",
                domain,
                slot.mode.value,
                slot.circuit_state.value,
                slot.target_concurrency,
                slot.delay * 1000,
                slot.current_throughput,
                slot.success_rate,
            )

        return ctx

    async def on_request_failed(self, ctx: AsyncHTTPContext) -> AsyncHTTPContext:
        """Обробка помилки запиту."""
        domain = ctx.data.get(self.CTX_DOMAIN)

        if not domain:
            return ctx

        slot = await self._get_or_create_slot(domain)

        async with self._lock:
            slot.active_requests = max(0, slot.active_requests - 1)
            slot.total_requests += 1
            slot.error_count += 1
            slot.consecutive_errors += 1
            slot.timeout_count += 1

        # Circuit breaker
        await self._handle_circuit_failure(slot)

        # Агресивне зменшення при багатьох помилках
        if slot.consecutive_errors >= 3:
            await self._apply_aimd_decrease(slot)

        if self._config.debug:
            logger.warning(
                "[EnhancedThrottle V2][%s] ❌ Request failed "
                "(consecutive=%d, timeout=%d, circuit=%s)",
                domain,
                slot.consecutive_errors,
                slot.timeout_count,
                slot.circuit_state.value,
            )

        return ctx

    # -------------------------------------------------------------------------
    # PUBLIC API
    # -------------------------------------------------------------------------

    def get_stats(self) -> dict[str, dict[str, Any]]:
        """Отримати статистику."""
        return {domain: slot.to_dict() for domain, slot in self._slots.items()}

    def get_summary(self) -> dict[str, Any]:
        """Загальна статистика."""
        if not self._slots:
            return {}

        total_requests = sum(s.total_requests for s in self._slots.values())
        total_success = sum(s.success_count for s in self._slots.values())
        total_errors = sum(s.error_count for s in self._slots.values())
        total_rate_limits = sum(s.rate_limit_count for s in self._slots.values())

        avg_throughput = sum(s.current_throughput for s in self._slots.values()) / len(
            self._slots
        )
        best_throughput = max(
            (s.best_throughput for s in self._slots.values()), default=0.0
        )

        circuits_open = sum(
            1 for s in self._slots.values() if s.circuit_state == CircuitState.OPEN
        )

        return {
            "total_domains": len(self._slots),
            "total_requests": total_requests,
            "total_success": total_success,
            "total_errors": total_errors,
            "total_rate_limits": total_rate_limits,
            "overall_success_rate": (
                (total_success / total_requests * 100) if total_requests > 0 else 0
            ),
            "avg_throughput_rps": round(avg_throughput, 3),
            "best_throughput_rps": round(best_throughput, 3),
            "circuits_open": circuits_open,
        }

    async def reset(self, domain: Optional[str] = None) -> None:
        """Скинути стан."""
        async with self._lock:
            if domain:
                if domain in self._slots:
                    self._slots[domain] = EnhancedDomainSlot(
                        domain=domain,
                        delay=self._config.start_delay,
                        target_concurrency=self._config.initial_concurrency,
                    )
            else:
                self._slots.clear()

    def __repr__(self) -> str:
        return (
            f"EnhancedAutoThrottlePlugin("
            f"domains={len(self._slots)}, "
            f"concurrency=[{self._config.min_concurrency}-{self._config.max_concurrency}], "
            f"circuit_breaker={self._config.enable_circuit_breaker})"
        )
