"""AsyncCurlCffiDriver — async HTTP-драйвер з реальним TLS fingerprint.

Базується на ``curl_cffi.requests.AsyncSession`` — нативний async, не обгортка.

Що дає (на відміну від AsyncDriver/AsyncDriverHTTP2):
- Справжній JA3/JA4 fingerprint реального браузера через ``impersonate=...``
- HTTP/2 з коробки
- Швидкість співмірна з aiohttp (C-бекенд через libcurl)
- Обходить **DataDome, PerimeterX, Imperva, Kasada, Akamai Bot Manager** на сайтах,
  які перевіряють лише TLS-рівень (без JS-челенджу).
- Обходить **частину Cloudflare** (там, де немає JS challenge / Turnstile).

Сценарії використання:
    >>> from graph_crawler.application.services.driver_factory import create_driver
    >>>
    >>> async with create_driver("curl_cffi", impersonate="chrome131") as driver:
    ...     response = await driver.fetch("https://protected.example.com")
    ...     print(response.status_code, len(response.html or ""))

Інтерфейс ідентичний AsyncDriver: ``fetch()``, ``fetch_many()``, ``fetch_fast()``,
``fetch_many_fast()``, async context manager.
"""
from __future__ import annotations

import asyncio
import logging
import random
from typing import Any

try:
    from curl_cffi.requests import AsyncSession
    from curl_cffi.requests.errors import RequestsError
    CURL_CFFI_AVAILABLE = True
except ImportError:
    CURL_CFFI_AVAILABLE = False
    AsyncSession = None  # type: ignore[assignment]
    RequestsError = Exception  # type: ignore[assignment,misc]

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.base_plugin import BaseDriverPlugin
from graph_crawler.infrastructure.transport.core.base_async import BaseAsyncDriver
from graph_crawler.infrastructure.transport.core.mixins import (
    PluginSupportMixin,
    RetryMixin,
)
from graph_crawler.shared.constants import (
    DEFAULT_MAX_CONCURRENT_REQUESTS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_RETRY_DELAY,
    DEFAULT_USER_AGENT,
)

logger = logging.getLogger(__name__)


# Список підтримуваних браузерних fingerprint'ів curl_cffi
# (актуально на момент імплементації; нові версії curl_cffi додають більше)
SUPPORTED_IMPERSONATIONS: tuple[str, ...] = (
    "chrome110", "chrome116", "chrome119", "chrome120",
    "chrome123", "chrome124", "chrome131",
    "firefox117", "firefox120", "firefox133",
    "safari15_3", "safari15_5", "safari17_0", "safari17_2_ios",
    "edge99", "edge101",
)

DEFAULT_IMPERSONATE = "chrome131"


class AsyncCurlCffiDriver(BaseAsyncDriver, PluginSupportMixin, RetryMixin):
    """
    Async HTTP драйвер на основі ``curl_cffi.requests.AsyncSession``.

    Підтримує:
    - Реальний TLS fingerprint браузера (``impersonate``)
    - HTTP/2
    - Ротацію fingerprint'ів між запитами (``rotate_impersonate=True``)
    - Проксі (HTTP / HTTPS / SOCKS5h)
    - Плагіни (через PluginSupportMixin)
    - Retry (через RetryMixin)

    Example:
        >>> async with AsyncCurlCffiDriver(config={"impersonate": "chrome131"}) as drv:
        ...     resp = await drv.fetch("https://example.com")
    """

    driver_name = "curl_cffi"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        event_bus: EventBus | None = None,
        plugins: list[BaseDriverPlugin] | None = None,
    ):
        """
        Args:
            config: dict з опціональними ключами:
                - timeout: int (DEFAULT_REQUEST_TIMEOUT)
                - user_agent: str (DEFAULT_USER_AGENT)
                - max_retries: int (DEFAULT_MAX_RETRIES)
                - retry_delay: float (DEFAULT_RETRY_DELAY)
                - max_concurrent_requests: int (DEFAULT_MAX_CONCURRENT_REQUESTS)
                - impersonate: str ("chrome131") — TLS fingerprint
                - rotate_impersonate: bool (False) — ротувати fingerprint між запитами
                - proxy: str | None — "http://...", "socks5h://..."
                - verify_ssl: bool (True)
            event_bus: опціональний EventBus
            plugins: опціональний список плагінів
        Raises:
            ImportError: якщо ``curl_cffi`` не встановлено
        """
        if not CURL_CFFI_AVAILABLE:
            raise ImportError(
                "AsyncCurlCffiDriver requires curl-cffi. "
                "Install with: pip install curl-cffi"
            )

        BaseAsyncDriver.__init__(self, config, event_bus)
        self._init_plugin_support(plugins, is_async=True)

        # Session
        self._session: "AsyncSession | None" = None

        # Basic settings
        self._timeout = self.config.get("timeout", DEFAULT_REQUEST_TIMEOUT)
        self._user_agent = self.config.get("user_agent", DEFAULT_USER_AGENT)
        self._max_retries = self.config.get("max_retries", DEFAULT_MAX_RETRIES)
        self._retry_delay = self.config.get("retry_delay", DEFAULT_RETRY_DELAY)
        self._verify_ssl = self.config.get("verify_ssl", True)

        # TLS fingerprint
        self._impersonate = self.config.get("impersonate", DEFAULT_IMPERSONATE)
        self._rotate_impersonate = self.config.get("rotate_impersonate", False)

        # Proxy (HTTP / HTTPS / SOCKS5h)
        self._proxy = self.config.get("proxy", None)

        # Concurrency
        self.max_concurrent = self.config.get(
            "max_concurrent_requests", DEFAULT_MAX_CONCURRENT_REQUESTS
        )

        logger.info(
            "AsyncCurlCffiDriver: impersonate=%s, rotate=%s, "
            "concurrent=%s, timeout=%ss, proxy=%s",
            self._impersonate,
            self._rotate_impersonate,
            self.max_concurrent,
            self._timeout,
            "yes" if self._proxy else "no",
        )

    # ------------------------------------------------------------------ #
    # Session management
    # ------------------------------------------------------------------ #

    async def _get_session(self) -> "AsyncSession":
        """Лінива ініціалізація AsyncSession."""
        if self._session is None:
            kwargs: dict[str, Any] = {
                "impersonate": self._impersonate,
                "timeout": self._timeout,
                "verify": self._verify_ssl,
            }
            if self._proxy:
                kwargs["proxies"] = {"http": self._proxy, "https": self._proxy}

            self._session = AsyncSession(**kwargs)
            logger.debug(
                "curl_cffi AsyncSession created (impersonate=%s)", self._impersonate
            )
        return self._session

    def _next_impersonate(self) -> str:
        """Обирає наступний fingerprint при ввімкненій ротації."""
        if not self._rotate_impersonate:
            return self._impersonate
        return random.choice(SUPPORTED_IMPERSONATIONS)

    # ------------------------------------------------------------------ #
    # Fetch logic
    # ------------------------------------------------------------------ #

    async def _do_fetch(self, url: str) -> FetchResponse:
        return await self._with_retry_async(
            self._fetch_simple,
            url,
            max_retries=self._max_retries,
            retry_delay=self._retry_delay,
            retry_on=(RequestsError, asyncio.TimeoutError),
        )

    async def _fetch_simple(self, url: str) -> FetchResponse:
        """Simple fetch без плагінів (curl_cffi не має stage-моделі як aiohttp)."""
        session = await self._get_session()
        impersonate = self._next_impersonate()

        try:
            # При rotate_impersonate=True передаємо impersonate per-request
            request_kwargs: dict[str, Any] = {"timeout": self._timeout}
            if self._rotate_impersonate:
                request_kwargs["impersonate"] = impersonate
            if self._user_agent:
                request_kwargs["headers"] = {"User-Agent": self._user_agent}

            response = await session.get(url, **request_kwargs)

            try:
                html = response.text
            except UnicodeDecodeError:
                html = None

            return FetchResponse(
                url=url,
                html=html,
                status_code=response.status_code,
                headers={k: str(v) for k, v in response.headers.items()},
            )
        except RequestsError as e:
            logger.warning("curl_cffi error for %s: %s", url, e)
            return FetchResponse(
                url=url,
                html=None,
                status_code=None,
                headers={},
                error=f"RequestsError: {e}",
            )

    # ------------------------------------------------------------------ #
    # Batch fetching with concurrency
    # ------------------------------------------------------------------ #

    async def fetch_many(self, urls: list[str]) -> list[FetchResponse]:
        """Паралельне завантаження з обмеженням ``max_concurrent``."""
        if not urls:
            return []

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def fetch_limited(url: str) -> FetchResponse:
            async with semaphore:
                return await self.fetch(url)

        tasks = [fetch_limited(url) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed: list[FetchResponse] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed.append(
                    self._create_error_response(
                        urls[i], f"{type(result).__name__}: {result}"
                    )
                )
            else:
                processed.append(result)
        return processed

    async def fetch_fast(self, url: str) -> FetchResponse:
        """Ultra-fast fetch БЕЗ retry/плагінів."""
        session = await self._get_session()
        try:
            response = await session.get(url, timeout=self._timeout)
            try:
                html = response.text
            except UnicodeDecodeError:
                html = None
            return FetchResponse(
                url=url,
                html=html,
                status_code=response.status_code,
                headers={k: str(v) for k, v in response.headers.items()},
            )
        except Exception as e:
            return FetchResponse(
                url=url,
                html=None,
                status_code=None,
                headers={},
                error=f"{type(e).__name__}: {e}",
            )

    async def fetch_many_fast(self, urls: list[str]) -> list[FetchResponse]:
        if not urls:
            return []

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def fetch_limited(url: str) -> FetchResponse:
            async with semaphore:
                return await self.fetch_fast(url)

        tasks = [asyncio.create_task(fetch_limited(url)) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed: list[FetchResponse] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed.append(
                    FetchResponse(
                        url=urls[i],
                        html=None,
                        status_code=None,
                        headers={},
                        error=f"{type(result).__name__}: {result}",
                    )
                )
            else:
                processed.append(result)
        return processed

    # ------------------------------------------------------------------ #
    # Cleanup
    # ------------------------------------------------------------------ #

    async def _do_close(self) -> None:
        if self._session is not None:
            try:
                await self._session.close()
            except Exception as e:  # pragma: no cover
                logger.warning("AsyncSession close error: %s", e)
            self._session = None

        await self._teardown_plugins_async()
