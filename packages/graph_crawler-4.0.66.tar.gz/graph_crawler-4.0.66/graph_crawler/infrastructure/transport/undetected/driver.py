"""
Undetected Chrome Driver для синхронних операцій.

Професійний драйвер на базі undetected-chromedriver для обходу:
- Cloudflare (включаючи Turnstile)
- DataDome
- PerimeterX
- Imperva
- Kasada
- Shape Security

Features:
- Автоматичне видалення automation flags
- Рандомізація fingerprint
- Human-like поведінка
- Proxy support
- Cookie persistence
"""

import logging
import os
import random
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.core.base_sync import BaseSyncDriver

logger = logging.getLogger(__name__)


@dataclass
class UndetectedConfig:
    """Конфігурація для UndetectedChromeDriver."""

    # Browser settings
    headless: bool = True
    use_subprocess: bool = True

    # Proxy
    proxy: Optional[str] = None  # Format: "http://user:pass@host:port"

    # Timeouts
    page_load_timeout: int = 60
    script_timeout: int = 30
    implicit_wait: int = 10

    # Anti-detection
    version_main: Optional[int] = None  # Chrome version to emulate
    patcher_force_close: bool = True

    # Profile
    user_data_dir: Optional[str] = None
    profile_directory: str = "Default"

    # Window
    window_size: tuple[int, int] = (1920, 1080)

    # Human behavior
    human_behavior: bool = True
    typing_delay: tuple[float, float] = (0.05, 0.15)
    click_delay: tuple[float, float] = (0.1, 0.3)

    # Additional options
    extra_args: list[str] = field(default_factory=list)


class UndetectedChromeDriver(BaseSyncDriver):
    """
    Професійний anti-bot драйвер на базі undetected-chromedriver.

    Успадковує BaseSyncDriver для сумісності з IDriver інтерфейсом.

    Приклад використання:

        from graph_crawler.infrastructure.transport.undetected import UndetectedChromeDriver

        config = UndetectedConfig(
            headless=True,
            proxy="http://user:pass@proxy:8080",
            human_behavior=True
        )

        driver = UndetectedChromeDriver(config)

        try:
            response = driver.fetch("https://protected-site.com")
            print(f"Got {len(response.html)} bytes")
        finally:
            driver.close()
    """

    driver_name = "undetected_chrome"

    def __init__(
        self,
        config: Optional[UndetectedConfig] = None,
        event_bus: EventBus | None = None,
    ):
        self.uc_config = config or UndetectedConfig()
        
        # Ініціалізуємо базовий клас
        super().__init__(
            config={
                "timeout": self.uc_config.page_load_timeout,
            },
            event_bus=event_bus,
        )
        
        self._driver = None
        self._setup_driver()

    def _setup_driver(self):
        try:
            import undetected_chromedriver as uc
            from fake_useragent import UserAgent
        except ImportError as e:
            raise ImportError(
                "Required packages not installed. Run: "
                "pip install undetected-chromedriver fake-useragent"
            ) from e

        options = uc.ChromeOptions()

        # Базові anti-detection options
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-infobars")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-browser-side-navigation")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-first-run")
        options.add_argument("--no-service-autorun")
        options.add_argument("--password-store=basic")

        # Window size
        width, height = self.uc_config.window_size
        options.add_argument(f"--window-size={width},{height}")

        # User agent
        try:
            ua = UserAgent()
            user_agent = ua.chrome
            options.add_argument(f"--user-agent={user_agent}")
        except Exception:
            pass  # Use default UA

        # Headless mode
        if self.uc_config.headless:
            options.add_argument("--headless=new")

        # Proxy
        if self.uc_config.proxy:
            options.add_argument(f"--proxy-server={self.uc_config.proxy}")

        # User data directory (for cookie persistence)
        if self.uc_config.user_data_dir:
            options.add_argument(f"--user-data-dir={self.uc_config.user_data_dir}")
            options.add_argument(f"--profile-directory={self.uc_config.profile_directory}")

        # Extra arguments
        for arg in self.uc_config.extra_args:
            options.add_argument(arg)

        self._driver = uc.Chrome(
            options=options,
            use_subprocess=self.uc_config.use_subprocess,
            version_main=self.uc_config.version_main,
            patcher_force_close=self.uc_config.patcher_force_close,
        )

        # Set timeouts
        self._driver.set_page_load_timeout(self.uc_config.page_load_timeout)
        self._driver.set_script_timeout(self.uc_config.script_timeout)
        self._driver.implicitly_wait(self.uc_config.implicit_wait)

        logger.info("UndetectedChromeDriver initialized successfully")

    def _get_html(self, url: str, wait_for_element: Optional[str] = None) -> str:
        """
        Внутрішній метод завантаження HTML.

        Args:
            url: URL для завантаження
            wait_for_element: CSS селектор елемента для очікування (опціонально)

        Returns:
            HTML контент сторінки
        """
        if not self._driver:
            raise RuntimeError("Driver not initialized")

        logger.info("Fetching: %s", url)

        self._driver.get(url)

        # Human-like behavior
        if self.uc_config.human_behavior:
            self._simulate_human_behavior()

        # Wait for element if specified
        if wait_for_element:
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support import expected_conditions as EC
            from selenium.webdriver.support.ui import WebDriverWait

            WebDriverWait(self._driver, self.uc_config.page_load_timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, wait_for_element))
            )

        # Check for Cloudflare
        if self._detect_cloudflare():
            logger.info("Cloudflare detected, waiting for challenge...")
            self._wait_cloudflare()

        html = self._driver.page_source
        logger.info("Fetched %d bytes from %s", len(html), url)

        return html

    def _do_fetch(self, url: str) -> FetchResponse:
        """
        Реалізація абстрактного методу BaseSyncDriver.
        
        Завантажує сторінку через undetected-chromedriver.
        
        Args:
            url: URL для завантаження
            
        Returns:
            FetchResponse з результатом
        """
        html = self._get_html(url)
        
        return FetchResponse(
            url=url,
            html=html,
            status_code=200,  # Browser drivers don't have direct access to status code
            headers={},
            error=None,
        )

    def _simulate_human_behavior(self):
        """Симулює людську поведінку."""
        try:
            from selenium.webdriver.common.action_chains import ActionChains

            # Random mouse movements
            actions = ActionChains(self._driver)

            width, height = self.config.window_size
            for _ in range(random.randint(2, 5)):
                x = random.randint(100, width - 100)
                y = random.randint(100, height - 100)
                actions.move_by_offset(x - width // 2, y - height // 2)
                actions.pause(random.uniform(0.1, 0.3))

            actions.perform()

            # Random scroll
            scroll_amount = random.randint(100, 500)
            self._driver.execute_script(f"window.scrollBy(0, {scroll_amount})")

            # Small delay
            time.sleep(random.uniform(0.5, 1.5))

        except Exception as e:
            logger.debug("Human behavior error (non-critical): %s", e)

    def _detect_cloudflare(self) -> bool:
        try:
            html = self._driver.page_source.lower()
            title = self._driver.title.lower()

            cf_indicators = [
                "checking your browser",
                "just a moment",
                "cloudflare",
                "attention required",
                "cf-browser-verification",
                "challenge-running",
                "ray id",
            ]

            return any(indicator in html or indicator in title for indicator in cf_indicators)
        except Exception:
            return False

    def _wait_cloudflare(self, timeout: int = 30):
        start = time.time()

        while time.time() - start < timeout:
            if not self._detect_cloudflare():
                logger.info("Cloudflare challenge passed")
                return True

            # Additional human-like behavior during waiting
            if self.uc_config.human_behavior:
                self._simulate_human_behavior()

            time.sleep(1)

        logger.warning("Cloudflare challenge timeout after %ds", timeout)
        return False

    def click(self, selector: str):
        """
        Клікає на елемент з human-like затримкою.

        Args:
            selector: CSS селектор елемента
        """
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.by import By

        element = self._driver.find_element(By.CSS_SELECTOR, selector)

        if self.uc_config.human_behavior:
            # Move to element with offset
            actions = ActionChains(self._driver)
            offset_x = random.randint(-3, 3)
            offset_y = random.randint(-3, 3)
            actions.move_to_element_with_offset(element, offset_x, offset_y)
            actions.pause(random.uniform(*self.uc_config.click_delay))
            actions.click()
            actions.perform()
        else:
            element.click()

    def type_text(self, selector: str, text: str):
        """
        Вводить текст з human-like затримкою.

        Args:
            selector: CSS селектор елемента
            text: Текст для введення
        """
        from selenium.webdriver.common.by import By

        element = self._driver.find_element(By.CSS_SELECTOR, selector)
        element.click()

        if self.uc_config.human_behavior:
            for char in text:
                element.send_keys(char)
                time.sleep(random.uniform(*self.uc_config.typing_delay))
        else:
            element.send_keys(text)

    def get_cookies(self) -> list[dict]:
        return self._driver.get_cookies() if self._driver else []

    def set_cookies(self, cookies: list[dict]):
        if self._driver:
            for cookie in cookies:
                try:
                    self._driver.add_cookie(cookie)
                except Exception as e:
                    logger.debug("Cookie set error: %s", e)

    def screenshot(self, path: str):
        """Зберігає скріншот сторінки."""
        if self._driver:
            self._driver.save_screenshot(path)

    def execute_script(self, script: str, *args) -> Any:
        if self._driver:
            return self._driver.execute_script(script, *args)
        return None

    @property
    def current_url(self) -> Optional[str]:
        return self._driver.current_url if self._driver else None

    @property
    def page_source(self) -> Optional[str]:
        """Повертає HTML поточної сторінки."""
        return self._driver.page_source if self._driver else None

    def _do_close(self) -> None:
        """Закриває браузер (реалізація для BaseSyncDriver)."""
        if self._driver:
            try:
                self._driver.quit()
                logger.info("UndetectedChromeDriver closed")
            except Exception as e:
                logger.debug("Error closing driver: %s", e)
            finally:
                self._driver = None
