"""
Async Undetected Driver на базі nodriver.

Професійний асинхронний драйвер для обходу anti-bot систем:
- Cloudflare (включаючи автоматичне вирішення Turnstile)
- DataDome
- PerimeterX
- Akamai Bot Manager

Features:
- Повністю асинхронний API
- Автоматичне вирішення Cloudflare challenges
- Human-like mouse та keyboard emulation
- TLS fingerprint matching через curl-cffi
"""

import asyncio
import logging
import random
from dataclasses import dataclass, field
from typing import Any, Optional

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.core.base_async import BaseAsyncDriver

logger = logging.getLogger(__name__)


@dataclass
class AsyncUndetectedConfig:
    """Конфігурація для AsyncUndetectedDriver."""

    # Browser settings
    headless: bool = True
    browser_executable_path: Optional[str] = None

    # Proxy
    proxy: Optional[str] = None  # Format: "http://user:pass@host:port"

    # Timeouts (seconds)
    page_load_timeout: int = 60
    navigation_timeout: int = 30

    # Anti-detection
    sandbox: bool = True

    # Window
    window_width: int = 1920
    window_height: int = 1080

    # Human behavior
    human_behavior: bool = True

    # Cloudflare specific
    cf_auto_solve: bool = True
    cf_wait_timeout: int = 30


class AsyncUndetectedDriver(BaseAsyncDriver):
    """
    Професійний async anti-bot драйвер на базі nodriver.

    Успадковує BaseAsyncDriver для сумісності з IDriver інтерфейсом.

    Приклад використання:

        from graph_crawler.infrastructure.transport.undetected import AsyncUndetectedDriver

        async def main():
            config = AsyncUndetectedConfig(
                headless=True,
                human_behavior=True,
                cf_auto_solve=True
            )

            async with AsyncUndetectedDriver(config) as driver:
                response = await driver.fetch("https://protected-site.com")
                print(f"Got {len(response.html)} bytes")

        asyncio.run(main())
    """

    driver_name = "async_undetected"

    def __init__(
        self,
        config: Optional[AsyncUndetectedConfig] = None,
        event_bus: EventBus | None = None,
    ):
        self.nd_config = config or AsyncUndetectedConfig()
        
        # Ініціалізуємо базовий клас
        super().__init__(
            config={
                "timeout": self.nd_config.page_load_timeout,
            },
            event_bus=event_bus,
        )
        
        self._browser = None
        self._tab = None

    async def start(self):
        """Запускає браузер."""
        try:
            import nodriver as uc
        except ImportError as e:
            raise ImportError(
                "nodriver not installed. Run: pip install nodriver"
            ) from e

        logger.info("Starting nodriver browser...")

        # Launch browser with sandbox disabled for container environments
        self._browser = await uc.start(
            headless=self.nd_config.headless,
            sandbox=False,  # Disable sandbox for root/container
            browser_executable_path=self.nd_config.browser_executable_path,
        )

        self._tab = await self._browser.get("about:blank")

        logger.info("nodriver browser started successfully")

    async def _get_html(
        self,
        url: str,
        wait_for_element: Optional[str] = None,
        wait_for_cf: bool = True
    ) -> str:
        """
        Внутрішній метод асинхронного завантаження HTML.

        Args:
            url: URL для завантаження
            wait_for_element: CSS селектор для очікування (опціонально)
            wait_for_cf: Чи чекати на Cloudflare challenge

        Returns:
            HTML контент сторінки
        """
        if not self._tab:
            await self.start()

        logger.info("Fetching: %s", url)

        # Navigate
        await self._tab.get(url)

        # Wait a bit for page to load
        await asyncio.sleep(1)

        # Human behavior before checking CF
        if self.nd_config.human_behavior:
            await self._simulate_human_behavior()

        # Check for Cloudflare
        if wait_for_cf and self.nd_config.cf_auto_solve:
            if await self._detect_cloudflare():
                logger.info("Cloudflare detected, attempting bypass...")
                await self._handle_cloudflare()

        # Wait for element if specified
        if wait_for_element:
            try:
                await self._tab.select(wait_for_element, timeout=self.nd_config.page_load_timeout)
            except Exception as e:
                logger.warning("Element wait timeout: %s", e)

        # Get HTML
        html = await self._tab.get_content()
        logger.info("Fetched %d bytes from %s", len(html), url)

        return html

    async def _do_fetch(self, url: str) -> FetchResponse:
        """
        Реалізація абстрактного методу BaseAsyncDriver.
        
        Завантажує сторінку через nodriver.
        
        Args:
            url: URL для завантаження
            
        Returns:
            FetchResponse з результатом
        """
        html = await self._get_html(url)
        
        return FetchResponse(
            url=url,
            html=html,
            status_code=200,  # Browser drivers don't have direct access to status code
            headers={},
            error=None,
        )

    async def _simulate_human_behavior(self):
        """Симулює людську поведінку."""
        try:
            # Random mouse movements
            for _ in range(random.randint(2, 4)):
                x = random.randint(100, self.nd_config.window_width - 100)
                y = random.randint(100, self.nd_config.window_height - 100)
                await self._tab.mouse.move(x, y)
                await asyncio.sleep(random.uniform(0.1, 0.3))

            # Random scroll
            scroll = random.randint(100, 400)
            await self._tab.scroll_down(scroll)

            await asyncio.sleep(random.uniform(0.3, 0.8))

        except Exception as e:
            logger.debug("Human behavior error (non-critical): %s", e)

    async def _detect_cloudflare(self) -> bool:
        try:
            html = await self._tab.get_content()
            html_lower = html.lower()

            cf_indicators = [
                "checking your browser",
                "just a moment",
                "cloudflare",
                "cf-browser-verification",
                "challenge-running",
                "turnstile",
                "cf-turnstile",
                "__cf_chl",
            ]

            return any(indicator in html_lower for indicator in cf_indicators)
        except Exception:
            return False

    async def _handle_cloudflare(self):
        logger.info("Handling Cloudflare challenge...")

        start_time = asyncio.get_event_loop().time()
        timeout = self.nd_config.cf_wait_timeout

        while asyncio.get_event_loop().time() - start_time < timeout:
            # Try nodriver's built-in Cloudflare bypass
            try:
                # nodriver має вбудований метод для Cloudflare
                if hasattr(self._tab, 'verify_cf'):
                    await self._tab.verify_cf()
                    logger.info("nodriver verify_cf executed")
            except Exception as e:
                logger.debug("verify_cf error: %s", e)

            # Human-like behavior during waiting
            if self.nd_config.human_behavior:
                await self._simulate_human_behavior()

            # Try to find and click Turnstile checkbox
            await self._try_click_turnstile()

            # Wait and check
            await asyncio.sleep(2)

            if not await self._detect_cloudflare():
                logger.info("Cloudflare challenge passed!")
                return True

        logger.warning("Cloudflare challenge timeout after %ds", timeout)
        return False

    async def _try_click_turnstile(self):
        """Пробує клікнути на Turnstile checkbox."""
        try:
            # Turnstile selectors
            selectors = [
                'iframe[src*="turnstile"]',
                '.cf-turnstile',
                '#cf-turnstile',
                'input[name="cf-turnstile-response"]',
            ]

            for selector in selectors:
                try:
                    element = await self._tab.select(selector, timeout=2)
                    if element:
                        # Get bounding box
                        box = await element.get_position()
                        if box:
                            # Click with random offset
                            x = box.x + box.width / 2 + random.uniform(-5, 5)
                            y = box.y + box.height / 2 + random.uniform(-5, 5)

                            # Human-like movement to element
                            await self._tab.mouse.move(x, y, steps=random.randint(10, 20))
                            await asyncio.sleep(random.uniform(0.1, 0.3))
                            await self._tab.mouse.click(x, y)

                            logger.info("Clicked Turnstile element: %s", selector)
                            return True
                except Exception:
                    continue

        except Exception as e:
            logger.debug("Turnstile click error: %s", e)

        return False

    async def click(self, selector: str):
        """
        Клікає на елемент.

        Args:
            selector: CSS селектор
        """
        if not self._tab:
            raise RuntimeError("Browser not started")

        element = await self._tab.select(selector)

        if self.nd_config.human_behavior:
            box = await element.get_position()
            if box:
                x = box.x + box.width / 2 + random.uniform(-3, 3)
                y = box.y + box.height / 2 + random.uniform(-3, 3)
                await self._tab.mouse.move(x, y, steps=random.randint(5, 15))
                await asyncio.sleep(random.uniform(0.1, 0.2))

        await element.click()

    async def type_text(self, selector: str, text: str):
        """
        Вводить текст в елемент.

        Args:
            selector: CSS селектор
            text: Текст для введення
        """
        if not self._tab:
            raise RuntimeError("Browser not started")

        element = await self._tab.select(selector)
        await element.click()

        if self.nd_config.human_behavior:
            for char in text:
                await self._tab.send_keys(char)
                await asyncio.sleep(random.uniform(0.05, 0.15))
        else:
            await self._tab.send_keys(text)

    async def screenshot(self, path: str):
        """Зберігає скріншот."""
        if self._tab:
            await self._tab.save_screenshot(path)

    async def get_cookies(self) -> list[dict]:
        if self._tab:
            return await self._tab.get_cookies()
        return []

    async def evaluate(self, script: str) -> Any:
        """Виконує JavaScript."""
        if self._tab:
            return await self._tab.evaluate(script)
        return None

    @property
    def current_url(self) -> Optional[str]:
        return self._tab.url if self._tab else None

    async def _do_close(self) -> None:
        """Закриває браузер (реалізація для BaseAsyncDriver)."""
        if self._browser:
            try:
                await self._browser.stop()
                logger.info("nodriver browser closed")
            except Exception as e:
                logger.debug("Error closing browser: %s", e)
            finally:
                self._browser = None
                self._tab = None

    async def __aenter__(self):
        await self.start()
        return self


# Convenience function for quick scraping
async def quick_fetch(url: str, **kwargs) -> FetchResponse:
    """
    Швидкий fetch URL з anti-bot обходом.

    Args:
        url: URL для завантаження
        **kwargs: Додаткові параметри для AsyncUndetectedConfig

    Returns:
        FetchResponse з результатом
    """
    config = AsyncUndetectedConfig(**kwargs)
    async with AsyncUndetectedDriver(config) as driver:
        return await driver.fetch(url)
