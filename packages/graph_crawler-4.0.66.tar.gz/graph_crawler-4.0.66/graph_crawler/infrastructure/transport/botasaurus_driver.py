"""
Botasaurus Driver - Enterprise-grade anti-bot драйвер.

Botasaurus - це професійний фреймворк для веб-скрапінгу, який включає:
- Автоматичний обхід Cloudflare, DataDome, PerimeterX
- Human-like cursor movements
- Профілі браузера з persistence
- Proxy rotation
- Rate limiting
- Automatic retries

Usage через API:
    graph = gc.crawl(
        url="https://protected-site.com",
        driver="botasaurus",
        driver_config={
            "headless": True,
            "proxy": "http://user:pass@host:port",
            "block_images": True
        }
    )
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Optional

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.core.base_sync import BaseSyncDriver

logger = logging.getLogger(__name__)


@dataclass
class BotasaurusConfig:
    """Конфігурація для BotasaurusDriver."""

    # Browser
    headless: bool = True

    # Proxy
    proxy: Optional[str] = None

    block_images: bool = True
    block_css: bool = False

    # Timeouts
    page_load_timeout: int = 60

    # User Agent
    user_agent: Optional[str] = None

    # Window
    window_width: int = 1920
    window_height: int = 1080


class BotasaurusDriver(BaseSyncDriver):
    """
    Enterprise-grade anti-bot драйвер на базі botasaurus.

    Успадковує BaseSyncDriver для сумісності з IDriver інтерфейсом.

    Приклад через graph_crawler API:

        import graph_crawler as gc

        graph = gc.crawl(
            url="https://cloudflare-protected.com",
            driver="botasaurus",
            driver_config={
                "headless": True,
                "block_images": True,
                "proxy": "http://user:pass@proxy:8080"
            }
        )
    """

    driver_name = "botasaurus"

    def __init__(
        self,
        config: dict | BotasaurusConfig | None = None,
        event_bus: EventBus | None = None,
    ):
        if isinstance(config, dict):
            self.bot_config = BotasaurusConfig(
                headless=config.get("headless", True),
                proxy=config.get("proxy"),
                block_images=config.get("block_images", True),
                block_css=config.get("block_css", False),
                page_load_timeout=config.get("page_load_timeout", config.get("timeout", 60)),
                user_agent=config.get("user_agent"),
                window_width=config.get("window_width", 1920),
                window_height=config.get("window_height", 1080),
            )
        elif isinstance(config, BotasaurusConfig):
            self.bot_config = config
        else:
            self.bot_config = BotasaurusConfig()

        # Ініціалізуємо базовий клас
        super().__init__(
            config={
                "timeout": self.bot_config.page_load_timeout,
            },
            event_bus=event_bus,
        )

        self._driver = None
        self._browser = None

    def _setup_driver(self):
        try:
            from botasaurus.browser import Driver, browser
            from botasaurus_driver import Driver as BotDriver
        except ImportError as e:
            raise ImportError(
                "botasaurus not installed. Run: pip install botasaurus botasaurus-driver"
            ) from e

        # Botasaurus використовує декоратор @browser для конфігурації
        # Тут ми створюємо низькорівневий Driver для інтеграції
        self._driver = BotDriver(
            headless=self.bot_config.headless,
            proxy=self.bot_config.proxy,
            block_images=self.bot_config.block_images,
            user_agent=self.bot_config.user_agent,
            window_size=[self.bot_config.window_width, self.bot_config.window_height],
        )

        logger.info("BotasaurusDriver initialized")
        return self._driver

    def _get_html(self, url: str, wait_for_element: Optional[str] = None) -> str:
        """
        Внутрішній метод завантаження HTML.

        Args:
            url: URL для завантаження
            wait_for_element: CSS селектор для очікування

        Returns:
            HTML контент
        """
        if not self._driver:
            self._setup_driver()

        logger.info("Fetching: %s", url)

        self._driver.get(url)

        if wait_for_element:
            self._driver.wait_for_element(wait_for_element, timeout=self.bot_config.page_load_timeout)

        # Botasaurus автоматично обходить Cloudflare
        html = self._driver.page_html

        logger.info("Fetched %d bytes from %s", len(html), url)
        return html

    def _do_fetch(self, url: str) -> FetchResponse:
        """
        Реалізація абстрактного методу BaseSyncDriver.
        
        Завантажує сторінку через botasaurus.
        
        Args:
            url: URL для завантаження
            
        Returns:
            FetchResponse з результатом
        """
        html = self._get_html(url)
        
        return FetchResponse(
            url=url,
            html=html,
            status_code=200,  # Browser drivers don't have direct access to status code
            headers={},
            error=None,
        )

    async def fetch_async(self, url: str, wait_for_element: Optional[str] = None) -> FetchResponse:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, self.fetch, url
        )

    def click(self, selector: str):
        """Клікає на елемент."""
        if self._driver:
            self._driver.click(selector)

    def type_text(self, selector: str, text: str):
        """Вводить текст."""
        if self._driver:
            self._driver.type(selector, text)

    def scroll(self, amount: int = 500):
        """Скролить сторінку."""
        if self._driver:
            self._driver.scroll(amount)

    def screenshot(self, path: str):
        """Зберігає скріншот."""
        if self._driver:
            self._driver.save_screenshot(path)

    def get_cookies(self) -> list[dict]:
        if self._driver:
            return self._driver.get_cookies()
        return []

    @property
    def page_source(self) -> Optional[str]:
        """HTML поточної сторінки."""
        return self._driver.page_html if self._driver else None

    @property
    def current_url(self) -> Optional[str]:
        return self._driver.current_url if self._driver else None

    def _do_close(self) -> None:
        """Закриває браузер (реалізація для BaseSyncDriver)."""
        if self._driver:
            try:
                self._driver.close()
                logger.info("BotasaurusDriver closed")
            except Exception as e:
                logger.debug("Error closing driver: %s", e)
            finally:
                self._driver = None
