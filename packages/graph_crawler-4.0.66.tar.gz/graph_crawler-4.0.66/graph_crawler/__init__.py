"""GraphCrawler - Sync-First Web Crawler.

>>> import graph_crawler as gc
>>> graph = gc.crawl("https://example.com")
>>> print(f"Знайдено {len(graph.nodes)} сторінок")

З параметрами:
>>> graph = gc.crawl("https://example.com", max_depth=5, max_pages=200, driver="playwright")

Async:
>>> graph = await gc.async_crawl("https://example.com")
"""

from __future__ import annotations

from graph_crawler.api import AsyncCrawler, Crawler, async_crawl, crawl, crawl_sitemap
from graph_crawler.domain.entities.edge import Edge
from graph_crawler.domain.entities.graph import Graph
from graph_crawler.domain.entities.node import Node
from graph_crawler.domain.value_objects.models import (
    ContentType,
    EdgeCreationStrategy,
    Rule,
    RuleScope,
    SmartURLRule,
    URLRule,
    build_smart_rules,
)
from graph_crawler.domain.value_objects.settings import (
    CrawlerSettings,
    DriverSettings,
    StorageSettings,
)
from graph_crawler.extensions.plugins.node import BaseNodePlugin, NodePluginType
from graph_crawler.infrastructure.transport import HTTPDriver

try:
    from graph_crawler.infrastructure.transport import AsyncDriver
except ImportError:
    AsyncDriver = None

try:
    from graph_crawler.infrastructure.transport import PlaywrightDriver
except ImportError:
    PlaywrightDriver = None

from graph_crawler.api.client.client import GraphCrawlerClient
from graph_crawler.application.services import create_driver, create_storage
from graph_crawler.application.services.exporters.edge_exporter import EdgeExporter
from graph_crawler.application.services.exporters.node_exporter import NodeExporter
from graph_crawler.application.use_cases.crawling.dead_letter_queue import (
    DeadLetterQueue,
    FailedURL,
)
from graph_crawler.application.use_cases.graph_export import GraphExportUseCase
from graph_crawler.domain.interfaces.driver import IDriver
from graph_crawler.domain.interfaces.storage import IStorage
from graph_crawler.infrastructure.persistence import (
    JSONStorage,
    MemoryStorage,
    SQLiteStorage,
)
from graph_crawler.infrastructure.persistence.base import StorageType
from graph_crawler.shared.error_handling.error_handler import (
    ErrorCategory,
    ErrorHandler,
    ErrorHandlerBuilder,
    ErrorSeverity,
)
from graph_crawler.shared.exceptions import (
    ConfigurationError,
    CrawlerError,
    DriverError,
    FetchError,
    GraphCrawlerError,
    InvalidURLError,
    LoadError,
    MaxDepthReachedError,
    MaxPagesReachedError,
    SaveError,
    StorageError,
    URLBlockedError,
    URLError,
)

try:
    from importlib.metadata import version

    __version__ = version("graph-crawler")
except ImportError:
    from graph_crawler.__version__ import __version__

__author__ = "0-EternalJunior-0"

from graph_crawler.shared.constants import (
    DEFAULT_REQUEST_DELAY,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_USER_AGENT,
    MAX_DEPTH_DEFAULT,
    MAX_PAGES_DEFAULT,
)

try:
    from graph_crawler.infrastructure.messaging import (
        EasyDistributedCrawler,
        celery,
        crawl_batch_task,
        crawl_page_task,
    )
except ImportError:
    celery = None
    crawl_page_task = None
    crawl_batch_task = None
    EasyDistributedCrawler = None

try:
    from graph_crawler.application.use_cases.crawling.celery_batch_spider import (
        CeleryBatchSpider,
    )
except ImportError:
    CeleryBatchSpider = None


def save_graph(graph: Graph, filepath: str, format: str = "json") -> None:
    """Зберігає граф у файл. При low_memory_mode об'єднує evicted ноди з RAM."""
    import asyncio

    async def _save_and_close():
        await async_save_graph(graph, filepath, format)

    try:
        asyncio.get_running_loop()
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(lambda: asyncio.run(_save_and_close()))
            future.result()
    except RuntimeError:
        asyncio.run(_save_and_close())


async def async_save_graph(graph: Graph, filepath: str, format: str = "json") -> None:
    """
    Асинхронно зберігає граф. При low_memory_mode об'єднує evicted ноди.
    
    REFACTORED: Low-memory mode логіка винесена в LowMemoryGraphSaver
    для кращої організації коду та тестування.
    
    Args:
        graph: Graph для збереження
        filepath: Шлях до файлу
        format: Формат збереження ("json" або "sqlite")
    """
    import logging

    from graph_crawler.application.dto.mappers import GraphMapper

    logger = logging.getLogger(__name__)

    # REFACTORED: Використовуємо окремий клас для low_memory_mode
    if graph._low_memory_mode and graph._eviction_storage:
        from graph_crawler.application.services.low_memory_graph_saver import (
            LowMemoryGraphSaver,
        )
        
        saver = LowMemoryGraphSaver(graph, batch_size=1000)
        graph_dto = await saver.create_merged_dto()
    else:
        graph_dto = GraphMapper.to_dto(graph)

    if format == "json":
        storage = JSONStorage(filepath)
    elif format == "sqlite":
        storage = SQLiteStorage(filepath)
    else:
        raise ValueError(f"Unknown format: {format}. Use 'json' or 'sqlite'")

    try:
        await storage.save_graph(graph_dto)
        logger.info("Graph saved to %s (%s format)", filepath, format)
    finally:
        if hasattr(storage, "close"):
            await storage.close()


def load_graph(filepath: str, format: str = "json") -> Graph:
    """Завантажує граф з файлу."""
    import asyncio

    from graph_crawler.application.dto.mappers import GraphMapper

    result_holder = [None]

    async def _load_and_close():
        if format == "json":
            storage = JSONStorage(filepath)
        elif format == "sqlite":
            storage = SQLiteStorage(filepath)
        else:
            raise ValueError(f"Unknown format: {format}. Use 'json' or 'sqlite'")

        try:
            result_holder[0] = await storage.load_graph()
        finally:
            if hasattr(storage, "close"):
                await storage.close()

    try:
        asyncio.get_running_loop()
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(lambda: asyncio.run(_load_and_close()))
            future.result()
    except RuntimeError:
        asyncio.run(_load_and_close())

    graph_dto = result_holder[0]
    if graph_dto is None:
        raise ValueError(f"Could not load graph from {filepath}")
    return GraphMapper.to_domain(graph_dto)


def quick_stats(graph: Graph) -> str:
    """Швидка статистика графу одним рядком."""
    stats = graph.get_stats()
    total = stats["total_nodes"]
    scanned = stats["scanned_nodes"]
    edges = stats["total_edges"]
    return f"📊 {total} nodes ({scanned} scanned) | {edges} edges"


__all__ = [
    "save_graph",
    "async_save_graph",
    "load_graph",
    "quick_stats",
    "crawl",
    "crawl_sitemap",
    "Crawler",
    "async_crawl",
    "AsyncCrawler",
    "Graph",
    "Node",
    "Edge",
    "URLRule",
    "SmartURLRule",
    "RuleScope",
    "Rule",
    "build_smart_rules",
    "EdgeCreationStrategy",
    "ContentType",
    "BaseNodePlugin",
    "NodePluginType",
    "CrawlerSettings",
    "DriverSettings",
    "StorageSettings",
    "HTTPDriver",
    "AsyncDriver",
    "PlaywrightDriver",
    "IDriver",
    "MemoryStorage",
    "JSONStorage",
    "SQLiteStorage",
    "IStorage",
    "StorageType",
    "create_driver",
    "create_storage",
    "GraphCrawlerClient",
    "DeadLetterQueue",
    "FailedURL",
    "GraphExportUseCase",
    "NodeExporter",
    "EdgeExporter",
    "ErrorHandler",
    "ErrorHandlerBuilder",
    "ErrorCategory",
    "ErrorSeverity",
    "GraphCrawlerError",
    "ConfigurationError",
    "URLError",
    "InvalidURLError",
    "URLBlockedError",
    "CrawlerError",
    "MaxPagesReachedError",
    "MaxDepthReachedError",
    "DriverError",
    "FetchError",
    "StorageError",
    "SaveError",
    "LoadError",
    "celery",
    "crawl_page_task",
    "crawl_batch_task",
    "CeleryBatchSpider",
    "EasyDistributedCrawler",
]

from graph_crawler.application.bootstrap import bootstrap

bootstrap()
