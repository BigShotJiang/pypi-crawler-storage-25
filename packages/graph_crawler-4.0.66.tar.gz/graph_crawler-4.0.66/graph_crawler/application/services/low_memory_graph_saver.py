"""Low Memory Graph Saver - оптимізоване збереження графу при low_memory_mode.

Рефакторинг: Винесено з __init__.py для кращої організації коду та тестування.

Features:
- Batch processing evicted nodes для економії RAM
- Streaming merge RAM + evicted даних
- Async-safe SQLite операції
- Progress logging для моніторингу
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Iterator

if TYPE_CHECKING:
    from graph_crawler.domain.entities.graph import Graph
    from graph_crawler.shared.dto import EdgeDTO, GraphDTO, GraphStatsDTO, NodeDTO

logger = logging.getLogger(__name__)


class LowMemoryGraphSaver:
    """
    Оптимізоване збереження графу при low_memory_mode.
    
    Об'єднує RAM nodes/edges з evicted nodes/edges з SQLite storage.
    Використовує batch processing для економії пам'яті.
    
    Example:
        >>> saver = LowMemoryGraphSaver(graph, batch_size=1000)
        >>> graph_dto = await saver.create_merged_dto()
        >>> await storage.save_graph(graph_dto)
    """
    
    DEFAULT_BATCH_SIZE = 1000
    
    def __init__(self, graph: "Graph", batch_size: int | None = None):
        """
        Args:
            graph: Graph з low_memory_mode=True та eviction_storage
            batch_size: Розмір батчу для обробки evicted nodes (default: 1000)
        """
        self.graph = graph
        self.batch_size = batch_size or self.DEFAULT_BATCH_SIZE
        
        if not graph._low_memory_mode:
            raise ValueError("LowMemoryGraphSaver requires graph with low_memory_mode=True")
        if not graph._eviction_storage:
            raise ValueError("LowMemoryGraphSaver requires graph with eviction_storage")
    
    def get_eviction_stats(self) -> dict[str, int]:
        """Повертає статистику evicted даних."""
        stats = self.graph._eviction_storage.get_stats()
        return {
            "evicted_nodes": stats.get("evicted_nodes", 0),
            "evicted_edges": stats.get("evicted_edges", 0),
            "ram_nodes": len(self.graph._nodes),
            "ram_edges": len(self.graph._edges) if hasattr(self.graph, "_edges") else 0,
        }
    
    def _log_merge_start(self) -> None:
        stats = self.get_eviction_stats()
        logger.info(
            "LOW-MEMORY MODE: Starting merge of %d evicted nodes + %d evicted edges "
            "with %d RAM nodes",
            stats["evicted_nodes"],
            stats["evicted_edges"],
            stats["ram_nodes"],
        )
    
    def _iter_ram_nodes_dto(self) -> Iterator["NodeDTO"]:
        from graph_crawler.application.dto.mappers.node_mapper import NodeMapper
        
        for node in self.graph.iter_nodes():
            yield NodeMapper.to_dto(node)
    
    def _iter_ram_edges_dto(self) -> Iterator["EdgeDTO"]:
        from graph_crawler.application.dto.mappers.edge_mapper import EdgeMapper
        
        for edge in self.graph.iter_edges():
            yield EdgeMapper.to_dto(edge)
    
    def _create_node_dto_from_evicted(self, node_data: dict[str, Any]) -> "NodeDTO":
        from graph_crawler.shared.dto import NodeDTO
        
        return NodeDTO(
            node_id=node_data["node_id"],
            url=node_data["url"],
            depth=node_data["depth"],
            scanned=node_data["scanned"],
            should_scan=node_data.get("should_scan", True),
            can_create_edges=node_data.get("can_create_edges", True),
            metadata=node_data.get("metadata", {}),
            user_data=node_data.get("user_data", {}),
            response_status=node_data.get("response_status"),
            content_hash=node_data.get("content_hash"),
            simhash=node_data.get("simhash"),
            priority=node_data.get("priority", 0),
            created_at=node_data.get("created_at") or datetime.now(timezone.utc),
            lifecycle_stage="scanned" if node_data["scanned"] else "url_stage",
            content_type=node_data.get("content_type", "unknown"),
        )
    
    def _iter_evicted_nodes_dto(self) -> Iterator["NodeDTO"]:
        """
        Генератор для evicted nodes -> NodeDTO з batch loading.
        
        Завантажує evicted nodes батчами для економії RAM.
        """
        evicted_urls = self.graph._eviction_storage.get_all_evicted_urls()
        evicted_urls_list = list(evicted_urls)
        
        total_batches = (len(evicted_urls_list) + self.batch_size - 1) // self.batch_size
        
        for batch_num, i in enumerate(range(0, len(evicted_urls_list), self.batch_size)):
            batch_urls = evicted_urls_list[i : i + self.batch_size]
            batch_data = self.graph._eviction_storage.load_nodes_batch_sync(batch_urls)
            
            if batch_num % 10 == 0:  # Log every 10 batches
                logger.debug(
                    "Processing evicted nodes batch %d/%d (%d nodes)",
                    batch_num + 1, total_batches, len(batch_data)
                )
            
            for _url, node_data in batch_data.items():
                yield self._create_node_dto_from_evicted(node_data)
    
    def _create_edge_dto_from_row(self, row: Any) -> "EdgeDTO":
        from graph_crawler.shared.dto import EdgeDTO
        
        metadata = {}
        if row["metadata"]:
            try:
                metadata = json.loads(row["metadata"])
            except json.JSONDecodeError:
                logger.warning("Failed to parse edge metadata: %s", row["edge_id"])
        
        created_at = row["created_at"]
        if isinstance(created_at, str):
            # Вже ISO string
            pass
        elif created_at is None:
            created_at = datetime.now(timezone.utc).isoformat()
        
        return EdgeDTO(
            edge_id=row["edge_id"],
            source_node_id=row["source_node_id"],
            target_node_id=row["target_node_id"],
            metadata=metadata,
            created_at=created_at,
        )
    
    def _iter_evicted_edges_dto(self) -> Iterator["EdgeDTO"]:
        conn = self.graph._eviction_storage._get_connection()
        
        # Використовуємо курсор для streaming замість fetchall()
        cursor = conn.execute("SELECT * FROM evicted_edges")
        
        batch_count = 0
        for row in cursor:
            yield self._create_edge_dto_from_row(row)
            batch_count += 1
            
            if batch_count % 10000 == 0:
                logger.debug("Processed %d evicted edges", batch_count)
    
    def _merge_nodes(
        self,
        ram_nodes: Iterator["NodeDTO"],
        evicted_nodes: Iterator["NodeDTO"],
    ) -> list["NodeDTO"]:
        """
        Об'єднує RAM та evicted nodes з дедуплікацією по URL.
        
        RAM nodes мають пріоритет (новіші дані).
        """
        nodes_by_url: dict[str, "NodeDTO"] = {}
        
        # Спочатку evicted (будуть перезаписані RAM якщо дублікат)
        for node_dto in evicted_nodes:
            nodes_by_url[node_dto.url] = node_dto
        
        # Потім RAM (перезаписують evicted)
        for node_dto in ram_nodes:
            nodes_by_url[node_dto.url] = node_dto
        
        return list(nodes_by_url.values())
    
    def _merge_edges(
        self,
        ram_edges: Iterator["EdgeDTO"],
        evicted_edges: Iterator["EdgeDTO"],
    ) -> list["EdgeDTO"]:
        """
        Об'єднує RAM та evicted edges з дедуплікацією по (source, target).
        
        RAM edges мають пріоритет.
        """
        edges_by_key: dict[tuple[str, str], "EdgeDTO"] = {}
        
        # Спочатку evicted
        for edge_dto in evicted_edges:
            key = (edge_dto.source_node_id, edge_dto.target_node_id)
            edges_by_key[key] = edge_dto
        
        # Потім RAM
        for edge_dto in ram_edges:
            key = (edge_dto.source_node_id, edge_dto.target_node_id)
            edges_by_key[key] = edge_dto
        
        return list(edges_by_key.values())
    
    def _compute_stats(
        self,
        nodes: list["NodeDTO"],
        edges: list["EdgeDTO"],
    ) -> "GraphStatsDTO":
        """Обчислює статистику для merged графу."""
        from graph_crawler.shared.dto import GraphStatsDTO as StatsDTO
        
        scanned_count = sum(1 for n in nodes if n.scanned)
        depths = [n.depth for n in nodes]
        
        return StatsDTO(
            total_nodes=len(nodes),
            scanned_nodes=scanned_count,
            unscanned_nodes=len(nodes) - scanned_count,
            total_edges=len(edges),
            avg_depth=sum(depths) / len(depths) if depths else 0.0,
            max_depth=max(depths) if depths else 0,
        )
    
    async def create_merged_dto(self) -> "GraphDTO":
        """
        Створює GraphDTO з об'єднанням RAM та evicted даних.
        
        Returns:
            GraphDTO з усіма nodes та edges
        """
        from graph_crawler.shared.dto import GraphDTO
        
        self._log_merge_start()
        
        # Merge nodes (RAM має пріоритет)
        logger.info("Merging nodes...")
        all_nodes = self._merge_nodes(
            ram_nodes=self._iter_ram_nodes_dto(),
            evicted_nodes=self._iter_evicted_nodes_dto(),
        )
        logger.info("Merged %d total nodes", len(all_nodes))
        
        # Merge edges (RAM має пріоритет)
        logger.info("Merging edges...")
        all_edges = self._merge_edges(
            ram_edges=self._iter_ram_edges_dto(),
            evicted_edges=self._iter_evicted_edges_dto(),
        )
        logger.info("Merged %d total edges", len(all_edges))
        
        # Compute stats
        stats = self._compute_stats(all_nodes, all_edges)
        
        return GraphDTO(nodes=all_nodes, edges=all_edges, stats=stats)


async def save_graph_low_memory(
    graph: "Graph",
    filepath: str,
    format: str = "json",
    batch_size: int = 1000,
) -> None:
    """
    Convenience function для збереження графу в low_memory_mode.
    
    Args:
        graph: Graph з low_memory_mode=True
        filepath: Шлях для збереження
        format: Формат ("json" або "sqlite")
        batch_size: Розмір батчу для обробки evicted nodes
    
    Example:
        >>> await save_graph_low_memory(graph, "output.json", batch_size=2000)
    """
    from graph_crawler.infrastructure.persistence import JSONStorage, SQLiteStorage
    
    saver = LowMemoryGraphSaver(graph, batch_size=batch_size)
    graph_dto = await saver.create_merged_dto()
    
    if format == "json":
        storage = JSONStorage(filepath)
    elif format == "sqlite":
        storage = SQLiteStorage(filepath)
    else:
        raise ValueError(f"Unknown format: {format}. Use 'json' or 'sqlite'")
    
    try:
        await storage.save_graph(graph_dto)
        logger.info("Graph saved to %s (%s format)", filepath, format)
    finally:
        if hasattr(storage, "close"):
            await storage.close()
