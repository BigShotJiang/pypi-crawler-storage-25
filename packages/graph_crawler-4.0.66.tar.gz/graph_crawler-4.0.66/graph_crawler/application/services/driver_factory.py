"""Factory для створення драйверів.

Створює драйвер з string або повертає готовий instance.

для дотримання Open/Closed Principle.

Приклади:
    >>> driver = create_driver("http")
    >>> driver = create_driver("playwright", {"headless": True})
    >>> driver = create_driver(CustomDriver())

    # Реєстрація кастомного драйвера
    >>> register_driver("mydriver", MyDriverClass)
    >>> driver = create_driver("mydriver")
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Union

if TYPE_CHECKING:
    from graph_crawler.domain.interfaces.driver import IDriver

logger = logging.getLogger(__name__)

# Type aliases
DriverType = Union[str, "IDriver", None]
DriverFactory = Callable[[dict], Any]  # Can return IDriver or sync driver

# DRIVER REGISTRY (OCP)
# Registry pattern дозволяє додавати нові драйвери без зміни коду factory

_DRIVER_REGISTRY: dict[str, DriverFactory] = {}

def _register_builtin_drivers():
    """Реєструє вбудовані драйвери."""

    def http_factory(config: dict) -> "IDriver":
        from graph_crawler.infrastructure.transport import HTTPDriver

        return HTTPDriver(config)  # type: ignore[return-value]

    def async_factory(config: dict) -> "IDriver":
        try:
            from graph_crawler.infrastructure.transport.async_http import AsyncDriver
            from graph_crawler.infrastructure.transport.async_http.plugins.http_cache import (
                AsyncHTTPCachePlugin,
            )

            # Автоматично додаємо HTTP Cache plugin якщо увімкнено
            plugins = config.pop("plugins", []) if isinstance(config, dict) else []

            http_cache_enabled = config.pop("http_cache_enabled", True) if isinstance(config, dict) else True
            if http_cache_enabled:
                cache_config = AsyncHTTPCachePlugin.create_config(
                    enabled=True,
                    max_cache_size=config.pop("http_cache_max_size", 10000) if isinstance(config, dict) else 10000,
                    store_content=config.pop("http_cache_store_content", False) if isinstance(config, dict) else False,
                    max_age_seconds=config.pop("http_cache_max_age", 3600) if isinstance(config, dict) else 3600,
                )
                plugins.append(AsyncHTTPCachePlugin(cache_config))

            return AsyncDriver(config, plugins=plugins if plugins else None)  # type: ignore[return-value]
        except ImportError:
            raise ImportError("AsyncDriver requires aiohttp. Install with: pip install aiohttp")

    def playwright_factory(config: dict) -> "IDriver":
        try:
            from graph_crawler.infrastructure.transport.playwright import (
                PlaywrightDriver,
            )
            from graph_crawler.infrastructure.transport.playwright.plugins import (
                EnhancedStealthPlugin,
            )

            # Автоматично додаємо EnhancedStealthPlugin якщо stealth не вимкнено
            # Це вирішує проблему блокування на захищених сайтах (Google, тощо)
            stealth_enabled = config.pop("stealth", True) if isinstance(config, dict) else True
            plugins = config.pop("plugins", []) if isinstance(config, dict) else []

            if stealth_enabled:
                # Перевіряємо чи вже є EnhancedStealthPlugin
                has_enhanced_stealth = any(
                    isinstance(p, EnhancedStealthPlugin) or
                    (hasattr(p, 'name') and p.name == 'enhanced_stealth')
                    for p in plugins
                )
                if not has_enhanced_stealth:
                    # Створюємо конфіг через create_config або dict
                    stealth_config = {
                        "stealth_level": "maximum",
                        "human_behavior": True,
                        "randomize_fingerprint": True,
                        "webrtc_protection": True
                    }
                    plugins.append(EnhancedStealthPlugin(stealth_config))
                    logger.info("Auto-added EnhancedStealthPlugin for anti-bot protection")

            return PlaywrightDriver(config, plugins=plugins if plugins else None)
        except ImportError:
            raise ImportError(
                "PlaywrightDriver requires playwright. "
                "Install with: pip install playwright && playwright install"
            )

    def stealth_factory(config: dict) -> "IDriver":
        try:
            from graph_crawler.infrastructure.transport.async_http.plugins.stealth_driver import (
                StealthHTTPDriver,
            )

            return StealthHTTPDriver(config)
        except ImportError:
            raise ImportError(
                "StealthHTTPDriver requires curl_cffi. Install with: pip install curl_cffi"
            )

    def cloudscraper_factory(config: dict) -> "IDriver":
        try:
            from graph_crawler.infrastructure.transport.sync.cloudscraper_driver import (
                CloudscraperDriver,
            )

            return CloudscraperDriver(config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "CloudscraperDriver requires cloudscraper. Install with: pip install cloudscraper"
            )

    def httpx_factory(config: dict) -> "IDriver":
        try:
            from graph_crawler.infrastructure.transport.async_http.driver_httpx import (
                AsyncDriverHTTP2,
            )

            return AsyncDriverHTTP2(config)
        except ImportError:
            raise ImportError(
                "AsyncDriverHTTP2 requires httpx[http2]. Install with: pip install 'httpx[http2]'"
            )

    def undetected_factory(config: dict) -> "IDriver":
        """
        Професійний anti-bot драйвер на базі undetected-chromedriver.

        Обходить: Cloudflare, DataDome, PerimeterX, Imperva, Kasada.

        Config options:
            headless: bool = True
            proxy: str = None  # "http://user:pass@host:port"
            human_behavior: bool = True
            page_load_timeout: int = 60
        """
        try:
            from graph_crawler.infrastructure.transport.undetected import (
                UndetectedChromeDriver,
            )
            from graph_crawler.infrastructure.transport.undetected.driver import (
                UndetectedConfig,
            )

            # Map config dict to UndetectedConfig
            uc_config = UndetectedConfig(
                headless=config.get("headless", True),
                proxy=config.get("proxy"),
                page_load_timeout=config.get("page_load_timeout", config.get("timeout", 60)),
                human_behavior=config.get("human_behavior", True),
                window_size=config.get("window_size", (1920, 1080)),
            )

            return UndetectedChromeDriver(uc_config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "UndetectedChromeDriver requires undetected-chromedriver. "
                "Install with: pip install undetected-chromedriver fake-useragent"
            )

    def nodriver_factory(config: dict) -> "IDriver":
        """
        Async anti-bot драйвер на базі nodriver.

        Обходить: Cloudflare (включаючи Turnstile), DataDome.
        Підходить для async crawling.

        Config options:
            headless: bool = True
            proxy: str = None
            human_behavior: bool = True
            cf_auto_solve: bool = True
            cf_wait_timeout: int = 30
        """
        try:
            from graph_crawler.infrastructure.transport.undetected import (
                AsyncUndetectedDriver,
            )
            from graph_crawler.infrastructure.transport.undetected.async_driver import (
                AsyncUndetectedConfig,
            )

            nd_config = AsyncUndetectedConfig(
                headless=config.get("headless", True),
                proxy=config.get("proxy"),
                human_behavior=config.get("human_behavior", True),
                cf_auto_solve=config.get("cf_auto_solve", True),
                cf_wait_timeout=config.get("cf_wait_timeout", 30),
                window_width=config.get("window_width", 1920),
                window_height=config.get("window_height", 1080),
            )

            return AsyncUndetectedDriver(nd_config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "AsyncUndetectedDriver requires nodriver. "
                "Install with: pip install nodriver"
            )

    def tls_factory(config: dict) -> "IDriver":
        """
        TLS Fingerprint HTTP клієнт на базі curl-cffi.

        Імітує TLS fingerprint реальних браузерів (Chrome, Firefox, Safari).
        Швидший за browser automation для статичних сайтів.

        Обходить: DataDome, PerimeterX, Kasada (без JavaScript challenges).

        Config options:
            impersonate: str = "chrome131"  # chrome110-131, firefox117-120, safari15-17
            proxy: str = None
            timeout: float = 30.0
            max_retries: int = 3
        """
        try:
            from graph_crawler.infrastructure.transport.tls_client import (
                TLSClientConfig,
                TLSFingerprintClient,
            )

            tls_config = TLSClientConfig(
                impersonate=config.get("impersonate", "chrome131"),
                proxy=config.get("proxy"),
                timeout=config.get("timeout", 30.0),
                max_retries=config.get("max_retries", 3),
                http2=config.get("http2", True),
            )

            return TLSFingerprintClient(tls_config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "TLSFingerprintClient requires curl-cffi. "
                "Install with: pip install curl-cffi"
            )

    def botasaurus_factory(config: dict) -> "IDriver":
        """
        Професійний anti-bot драйвер на базі botasaurus.

        Enterprise-grade обхід anti-bot систем.

        Config options:
            headless: bool = True
            proxy: str = None
            block_images: bool = True
            user_agent: str = None
        """
        try:
            from graph_crawler.infrastructure.transport.botasaurus_driver import (
                BotasaurusDriver,
            )

            return BotasaurusDriver(config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "BotasaurusDriver requires botasaurus. "
                "Install with: pip install botasaurus"
            )

    def curl_cffi_factory(config: dict) -> "IDriver":
        """
        Async TLS fingerprint драйвер на базі curl_cffi.requests.AsyncSession.

        Працює в нашому async-pipeline (на відміну від sync TLSFingerprintClient).
        Обходить: DataDome, PerimeterX, Imperva, Kasada, частину Cloudflare
        (без JS-челенджу).

        Config options:
            impersonate: str = "chrome131"
            rotate_impersonate: bool = False
            proxy: str = None  # http:// | https:// | socks5h://
            timeout: int = DEFAULT_REQUEST_TIMEOUT
            max_retries: int = DEFAULT_MAX_RETRIES
            max_concurrent_requests: int = DEFAULT_MAX_CONCURRENT_REQUESTS
        """
        try:
            from graph_crawler.infrastructure.transport.async_http.driver_curl_cffi import (
                AsyncCurlCffiDriver,
            )

            return AsyncCurlCffiDriver(config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "AsyncCurlCffiDriver requires curl-cffi. "
                "Install with: pip install curl-cffi"
            )

    def cloudscraper_async_factory(config: dict) -> "IDriver":
        """
        Async-обгортка над sync ``cloudscraper`` через ``asyncio.to_thread``.

        Обходить Cloudflare JS Challenge / IUAM (там, де curl_cffi недостатньо).
        Виконується у thread pool — concurrency обмежена.

        Config options:
            timeout: int
            max_retries: int
            max_concurrent_requests: int
            browser: dict — {"browser": "chrome", "platform": "windows", "mobile": False}
            proxy: str = None
            delay: float = 0
            debug: bool = False
        """
        try:
            from graph_crawler.infrastructure.transport.async_http.driver_cloudscraper import (
                AsyncCloudscraperDriver,
            )

            return AsyncCloudscraperDriver(config)  # type: ignore[return-value]
        except ImportError:
            raise ImportError(
                "AsyncCloudscraperDriver requires cloudscraper. "
                "Install with: pip install cloudscraper"
            )

    # Реєструємо вбудовані драйвери
    _DRIVER_REGISTRY["http"] = http_factory
    _DRIVER_REGISTRY["async"] = async_factory
    _DRIVER_REGISTRY["httpx"] = httpx_factory  # HTTP/2 драйвер
    _DRIVER_REGISTRY["playwright"] = playwright_factory
    _DRIVER_REGISTRY["stealth"] = stealth_factory
    _DRIVER_REGISTRY["cloudscraper"] = cloudscraper_factory
    _DRIVER_REGISTRY["cloudscraper_async"] = cloudscraper_async_factory  # async-обгортка
    _DRIVER_REGISTRY["curl_cffi"] = curl_cffi_factory  # async TLS fingerprint

    # Професійні anti-bot драйвери
    _DRIVER_REGISTRY["undetected"] = undetected_factory      # undetected-chromedriver
    _DRIVER_REGISTRY["nodriver"] = nodriver_factory          # nodriver async
    _DRIVER_REGISTRY["tls"] = tls_factory                    # curl-cffi TLS fingerprint (sync)
    _DRIVER_REGISTRY["botasaurus"] = botasaurus_factory      # botasaurus enterprise

# Ініціалізуємо вбудовані драйвери
_register_builtin_drivers()

def register_driver(name: str, factory: DriverFactory) -> None:
    """
    Реєструє новий тип драйвера (Open/Closed Principle).

    Дозволяє додавати нові драйвери без зміни коду factory.

    Args:
        name: Назва драйвера (lowercase)
        factory: Функція-фабрика яка приймає config і повертає IDriver

    Example:
        def my_driver_factory(config: dict) -> IDriver:
            return MyCustomDriver(config)

        register_driver("mydriver", my_driver_factory)
        driver = create_driver("mydriver", {"option": "value"})
    """
    name = name.lower()
    if name in _DRIVER_REGISTRY:
        logger.warning("Overwriting existing driver registration: %s", name)
    _DRIVER_REGISTRY[name] = factory
    logger.debug("Registered driver: %s", name)

def get_available_drivers() -> list[str]:
    """
    Повертає список доступних типів драйверів.

    Returns:
        Список назв зареєстрованих драйверів

    Example:
        >>> get_available_drivers()
        ['http', 'async', 'playwright', 'stealth']
    """
    return list(_DRIVER_REGISTRY.keys())

def create_driver(driver: DriverType = None, config: dict[str, Any | None] = None) -> "IDriver":
    """
    Створює драйвер з string або повертає instance.

    Returns:
        IDriver: Готовий до використання драйвер
    Raises:
        ValueError: Якщо невідомий тип драйвера
    Examples:
        Простий HTTP драйвер:
        >>> driver = create_driver("http")
        >>> response = driver.fetch("https://example.com")
    """
    config = config or {}

    # Якщо передали готовий драйвер (instance) - повертаємо як є
    if driver is not None and not isinstance(driver, (str, type)):
        # Перевіряємо чи це схоже на драйвер (має метод fetch)
        if hasattr(driver, "fetch"):
            logger.debug("Using custom driver instance: %s", type(driver).__name__)
            return driver
        else:
            raise ValueError(
                f"Invalid driver instance: {type(driver).__name__}. "
                f"Driver must have 'fetch' method."
            )

    # Якщо передали клас драйвера - створюємо instance
    if driver is not None and isinstance(driver, type):
        logger.debug("Creating driver from class: %s", driver.__name__)
        return driver(config)

    # String shortcuts - використовуємо registry (OCP)
    driver_type = driver or "http"
    driver_type = driver_type.lower()

    # Перевіряємо registry
    if driver_type in _DRIVER_REGISTRY:
        factory = _DRIVER_REGISTRY[driver_type]
        logger.debug("Creating %s driver from registry", driver_type)
        return factory(config)
    else:
        available = ", ".join(f"'{d}'" for d in get_available_drivers())
        raise ValueError(
            f"Unknown driver type: '{driver}'. "
            f"Available: {available} "
            f"or provide IDriver instance. "
            f"Use register_driver() to add custom drivers."
        )
