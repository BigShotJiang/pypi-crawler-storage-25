"""Factories та сервіси для GraphCrawler.

Фабрики дозволяють створювати драйвери та storage з простих string параметрів:

    >>> from graph_crawler.application.services import create_driver, create_storage
    >>>
    >>> # String shortcuts
    >>> driver = create_driver("http")
    >>> driver = create_driver("playwright")
    >>>
    >>> storage = create_storage("memory")
    >>> storage = create_storage("sqlite")
    >>>
    >>> # Або передати готовий instance
    >>> driver = create_driver(CustomDriver())

Low-Memory Mode збереження:

    >>> from graph_crawler.application.services import LowMemoryGraphSaver
    >>> saver = LowMemoryGraphSaver(graph, batch_size=1000)
    >>> graph_dto = await saver.create_merged_dto()
"""

from graph_crawler.application.services.application_container import (
    ApplicationContainer,
)
from graph_crawler.application.services.driver_factory import (
    create_driver,
    get_available_drivers,
    register_driver,
)
from graph_crawler.application.services.low_memory_graph_saver import (
    LowMemoryGraphSaver,
    save_graph_low_memory,
)
from graph_crawler.application.services.storage_factory import (
    create_storage,
    register_storage,
)

__all__ = [
    "create_driver",
    "create_storage",
    "ApplicationContainer",
    "LowMemoryGraphSaver",
    "save_graph_low_memory",
    "register_driver",
    "get_available_drivers",
    "register_storage",
]
