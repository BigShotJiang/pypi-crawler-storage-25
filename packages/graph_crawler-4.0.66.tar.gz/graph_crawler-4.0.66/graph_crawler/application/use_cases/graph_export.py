"""
GraphExportUseCase - Use Case для експорту графів (Clean Architecture).

"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Type

if TYPE_CHECKING:
    from graph_crawler.domain.entities.graph import Graph

logger = logging.getLogger(__name__)

class GraphExportUseCase:
    """
    Use Case для експорту графів.

    Реалізує Clean Architecture патерн - Graph не залежить від експортерів напряму.

    Args:
        node_exporter: Клас NodeExporter (або сумісний)
        edge_exporter: Клас EdgeExporter (опціонально)

    Example:
        >>> exporter = GraphExportUseCase()
        >>> exporter.export_to_json(graph, 'graph.json')
        >>> exporter.export_to_csv(graph, 'nodes.csv', 'edges.csv')
        >>> exporter.export_to_graphml(graph, 'graph.graphml')
    """

    def __init__(
        self,
        node_exporter: Type | None = None,
        edge_exporter: Type | None = None,
    ):
        self._node_exporter = node_exporter
        self._edge_exporter = edge_exporter

    # ==================== NEW DOCUMENTED API ====================
    
    def export_to_json(
        self,
        graph: "Graph",
        filepath: str,
        **kwargs,
    ) -> dict:
        """
        Експортує повний граф у JSON файл.
        
        Args:
            graph: Граф для експорту
            filepath: Шлях до файлу
            **kwargs: Додаткові параметри
            
        Returns:
            dict з результатом експорту
            
        Example:
            >>> exporter = GraphExportUseCase()
            >>> exporter.export_to_json(graph, "graph.json")
        """
        import json
        
        nodes_data = []
        edges_data = []
        
        for node in graph.iter_nodes() if hasattr(graph, "iter_nodes") else graph:
            node_dict = {
                "url": node.url,
                "depth": node.depth,
                "scanned": node.scanned,
                "response_status": node.response_status,
                "title": node.get_title() if hasattr(node, "get_title") else None,
                "user_data": dict(node.user_data) if hasattr(node, "user_data") else {},
            }
            nodes_data.append(node_dict)
        
        for edge in graph.iter_edges() if hasattr(graph, "iter_edges") else []:
            edge_dict = {
                "source": edge.source_url,
                "target": edge.target_url,
                "link_text": edge.link_text if hasattr(edge, "link_text") else None,
            }
            edges_data.append(edge_dict)
        
        result = {
            "nodes": nodes_data,
            "edges": edges_data,
            "stats": graph.get_stats() if hasattr(graph, "get_stats") else {},
        }
        
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2, default=str)
        
        logger.info("Exported graph to JSON: %s (%d nodes, %d edges)", 
                   filepath, len(nodes_data), len(edges_data))
        
        return {"filepath": filepath, "total_nodes": len(nodes_data), "total_edges": len(edges_data)}
    
    def export_to_csv(
        self,
        graph: "Graph",
        nodes_filepath: str,
        edges_filepath: str = None,
        **kwargs,
    ) -> dict:
        """
        Експортує граф у CSV файли (nodes та edges окремо).
        
        Args:
            graph: Граф для експорту
            nodes_filepath: Шлях до файлу нод
            edges_filepath: Шлях до файлу ребер (опціонально)
            **kwargs: Додаткові параметри
            
        Returns:
            dict з результатом експорту
            
        Example:
            >>> exporter = GraphExportUseCase()
            >>> exporter.export_to_csv(graph, "nodes.csv", "edges.csv")
        """
        import csv
        
        nodes_count = 0
        edges_count = 0
        
        # Export nodes
        with open(nodes_filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["url", "depth", "scanned", "response_status", "title"])
            
            for node in graph.iter_nodes() if hasattr(graph, "iter_nodes") else graph:
                writer.writerow([
                    node.url,
                    node.depth,
                    node.scanned,
                    node.response_status,
                    node.get_title() if hasattr(node, "get_title") else "",
                ])
                nodes_count += 1
        
        # Export edges if filepath provided
        if edges_filepath:
            with open(edges_filepath, "w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["source", "target", "link_text"])
                
                for edge in graph.iter_edges() if hasattr(graph, "iter_edges") else []:
                    writer.writerow([
                        edge.source_url,
                        edge.target_url,
                        edge.link_text if hasattr(edge, "link_text") else "",
                    ])
                    edges_count += 1
        
        logger.info("Exported graph to CSV: %s (%d nodes), %s (%d edges)", 
                   nodes_filepath, nodes_count, edges_filepath or "N/A", edges_count)
        
        return {
            "nodes_filepath": nodes_filepath,
            "edges_filepath": edges_filepath,
            "total_nodes": nodes_count,
            "total_edges": edges_count,
        }
    
    def export_to_graphml(
        self,
        graph: "Graph",
        filepath: str,
        **kwargs,
    ) -> dict:
        """
        Експортує граф у GraphML формат (XML для візуалізації).
        
        GraphML — стандартний формат для візуалізації графів у:
        - Gephi
        - yEd
        - Cytoscape
        - NetworkX
        
        Args:
            graph: Граф для експорту
            filepath: Шлях до файлу (.graphml)
            **kwargs: Додаткові параметри
            
        Returns:
            dict з результатом експорту
            
        Example:
            >>> exporter = GraphExportUseCase()
            >>> exporter.export_to_graphml(graph, "graph.graphml")
        """
        import xml.etree.ElementTree as ET
        
        # Create GraphML root
        graphml = ET.Element("graphml")
        graphml.set("xmlns", "http://graphml.graphdrawing.org/xmlns")
        graphml.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        graphml.set("xsi:schemaLocation", 
                   "http://graphml.graphdrawing.org/xmlns http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd")
        
        # Define node attributes
        key_url = ET.SubElement(graphml, "key")
        key_url.set("id", "url")
        key_url.set("for", "node")
        key_url.set("attr.name", "url")
        key_url.set("attr.type", "string")
        
        key_depth = ET.SubElement(graphml, "key")
        key_depth.set("id", "depth")
        key_depth.set("for", "node")
        key_depth.set("attr.name", "depth")
        key_depth.set("attr.type", "int")
        
        key_title = ET.SubElement(graphml, "key")
        key_title.set("id", "title")
        key_title.set("for", "node")
        key_title.set("attr.name", "title")
        key_title.set("attr.type", "string")
        
        key_scanned = ET.SubElement(graphml, "key")
        key_scanned.set("id", "scanned")
        key_scanned.set("for", "node")
        key_scanned.set("attr.name", "scanned")
        key_scanned.set("attr.type", "boolean")
        
        key_link_text = ET.SubElement(graphml, "key")
        key_link_text.set("id", "link_text")
        key_link_text.set("for", "edge")
        key_link_text.set("attr.name", "link_text")
        key_link_text.set("attr.type", "string")
        
        # Create graph element
        graph_elem = ET.SubElement(graphml, "graph")
        graph_elem.set("id", "G")
        graph_elem.set("edgedefault", "directed")
        
        nodes_count = 0
        edges_count = 0
        url_to_id = {}
        
        # Add nodes
        for node in graph.iter_nodes() if hasattr(graph, "iter_nodes") else graph:
            node_id = f"n{nodes_count}"
            url_to_id[node.url] = node_id
            
            node_elem = ET.SubElement(graph_elem, "node")
            node_elem.set("id", node_id)
            
            # Add node data
            data_url = ET.SubElement(node_elem, "data")
            data_url.set("key", "url")
            data_url.text = node.url
            
            data_depth = ET.SubElement(node_elem, "data")
            data_depth.set("key", "depth")
            data_depth.text = str(node.depth)
            
            data_scanned = ET.SubElement(node_elem, "data")
            data_scanned.set("key", "scanned")
            data_scanned.text = str(node.scanned).lower()
            
            title = node.get_title() if hasattr(node, "get_title") else ""
            if title:
                data_title = ET.SubElement(node_elem, "data")
                data_title.set("key", "title")
                data_title.text = title
            
            nodes_count += 1
        
        # Add edges
        for edge in graph.iter_edges() if hasattr(graph, "iter_edges") else []:
            source_id = url_to_id.get(edge.source_url)
            target_id = url_to_id.get(edge.target_url)
            
            if source_id and target_id:
                edge_elem = ET.SubElement(graph_elem, "edge")
                edge_elem.set("id", f"e{edges_count}")
                edge_elem.set("source", source_id)
                edge_elem.set("target", target_id)
                
                link_text = edge.link_text if hasattr(edge, "link_text") else ""
                if link_text:
                    data_link = ET.SubElement(edge_elem, "data")
                    data_link.set("key", "link_text")
                    data_link.text = link_text
                
                edges_count += 1
        
        # Write to file
        tree = ET.ElementTree(graphml)
        ET.indent(tree, space="  ")
        tree.write(filepath, encoding="utf-8", xml_declaration=True)
        
        logger.info("Exported graph to GraphML: %s (%d nodes, %d edges)", 
                   filepath, nodes_count, edges_count)
        
        return {"filepath": filepath, "total_nodes": nodes_count, "total_edges": edges_count}

    # ==================== LEGACY API (backward compatibility) ====================

    def export_nodes(
        self,
        graph: "Graph",
        filepath: str,
        format: str = "json",
        node_fields: list[str | None] = None,
        transform_node: Callable | None = None,
        predicate: Callable | None = None,
        **kwargs,
    ) -> Any:
        """
        Експортує ноди графу в файл.

        Args:
            graph: Граф для експорту
            filepath: Шлях до файлу
            format: Формат експорту ('json', 'csv')
            node_fields: Список полів для включення (dot notation підтримується)
            transform_node: Функція трансформації (node) -> dict
            predicate: Фільтр нод (node) -> bool
            **kwargs: Додаткові параметри для експортера
        Returns:
            Результат експорту (залежить від формату)
        Raises:
            ValueError: Якщо node_exporter не встановлено або формат не підтримується
        Example:
            >>> exporter.export_nodes(
            ...     graph,
            ...     'vacancies.json',
            ...     format='json',
            ...     node_fields=['url', 'metadata.title'],
            ...     predicate=lambda n: n.scanned and n.depth <= 2
            ... )
        """
        if not self._node_exporter:
            raise ValueError(
                "node_exporter not configured. "
                "Initialize with: GraphExportUseCase(node_exporter=NodeExporter)"
            )

        # Отримуємо список нод (streaming через iter_nodes для великих графів)
        nodes = (
            list(graph.iter_nodes())
            if hasattr(graph, "iter_nodes")
            else (list(graph.iter_nodes()) if hasattr(graph, "iter_nodes") else list(graph))
        )

        logger.info("Exporting %s nodes to %s (format=%s)", len(nodes), filepath, format)

        format_lower = format.lower()

        if format_lower == "json":
            return self._node_exporter.export_to_json(
                nodes=nodes,
                filepath=filepath,
                node_fields=node_fields,
                transform_node=transform_node,
                predicate=predicate,
                **kwargs,
            )
        elif format_lower == "csv":
            return self._node_exporter.export_to_csv(
                nodes=nodes,
                filepath=filepath,
                node_fields=node_fields,
                transform_node=transform_node,
                predicate=predicate,
                **kwargs,
            )
        else:
            raise ValueError(f"Unsupported format: {format}. Supported formats: json, csv")

    async def export_nodes_async(
        self,
        graph: "Graph",
        filepath: str,
        format: str = "json",
        node_fields: list[str | None] = None,
        transform_node: Callable | None = None,
        predicate: Callable | None = None,
        **kwargs,
    ) -> Any:
        """
        Async версія експорту нод (неблокуюча).

        Args:
            graph: Граф для експорту
            filepath: Шлях до файлу
            format: Формат експорту ('json', 'csv')
            node_fields: Список полів для включення
            transform_node: Функція трансформації
            predicate: Фільтр нод
            **kwargs: Додаткові параметри

        Returns:
            Результат експорту
        """
        if not self._node_exporter:
            raise ValueError("node_exporter not configured")

        nodes = (
            list(graph.iter_nodes())
            if hasattr(graph, "iter_nodes")
            else (list(graph.nodes.values()) if hasattr(graph, "nodes") else list(graph))
        )

        logger.info("Async exporting %s nodes to %s", len(nodes), filepath)

        format_lower = format.lower()

        if format_lower == "json":
            if hasattr(self._node_exporter, "export_to_json_async"):
                return await self._node_exporter.export_to_json_async(
                    nodes=nodes,
                    filepath=filepath,
                    node_fields=node_fields,
                    transform_node=transform_node,
                    predicate=predicate,
                    **kwargs,
                )
            else:
                # Fallback до sync версії
                return self._node_exporter.export_to_json(
                    nodes=nodes,
                    filepath=filepath,
                    node_fields=node_fields,
                    transform_node=transform_node,
                    predicate=predicate,
                    **kwargs,
                )
        elif format_lower == "csv":
            if hasattr(self._node_exporter, "export_to_csv_async"):
                return await self._node_exporter.export_to_csv_async(
                    nodes=nodes,
                    filepath=filepath,
                    node_fields=node_fields,
                    transform_node=transform_node,
                    predicate=predicate,
                    **kwargs,
                )
            else:
                return self._node_exporter.export_to_csv(
                    nodes=nodes,
                    filepath=filepath,
                    node_fields=node_fields,
                    transform_node=transform_node,
                    predicate=predicate,
                    **kwargs,
                )
        else:
            raise ValueError(f"Unsupported format: {format}")

    def export_edges(self, graph: "Graph", filepath: str, format: str = "json", **kwargs) -> Any:
        """
        Експортує edges графу в файл.

        Args:
            graph: Граф для експорту
            filepath: Шлях до файлу
            format: Формат експорту ('json', 'csv', 'dot')
            **kwargs: Додаткові параметри

        Returns:
            Результат експорту
        """
        if not self._edge_exporter:
            raise ValueError(
                "edge_exporter not configured. "
                "Initialize with: GraphExportUseCase(edge_exporter=EdgeExporter)"
            )

        # Конвертуємо граф в DTO якщо потрібно
        from graph_crawler.application.dto.mappers.graph_mapper import GraphMapper

        graph_dto = GraphMapper.to_dto(graph)

        format_lower = format.lower()

        if format_lower == "json":
            return self._edge_exporter.export_to_json(graph_dto, filepath, **kwargs)
        elif format_lower == "csv":
            return self._edge_exporter.export_to_csv(graph_dto, filepath, **kwargs)
        elif format_lower == "dot":
            return self._edge_exporter.export_to_dot(graph_dto, filepath, **kwargs)
        else:
            raise ValueError(f"Unsupported edge format: {format}")

__all__ = ["GraphExportUseCase"]
