"""DependencyRegistry - Singleton для управління залежностями.

Вирішує проблему відновлення plugin_manager, tree_parser, hash_strategy
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Type

logger = logging.getLogger(__name__)

@dataclass(slots=True)
class DependencyConfig:
    """
    Конфігурація залежностей для Node.

    Зберігає factory functions замість інстансів для lazy initialization
    та підтримки різних конфігурацій.

    Attributes:
        plugin_manager_factory: Фабрика для створення plugin_manager
        tree_parser_factory: Фабрика для створення tree_parser
        hash_strategy_factory: Фабрика для створення hash_strategy
        node_class: Клас Node для створення (default: Node)
        edge_class: Клас Edge для створення (default: Edge)
        default_merge_strategy: Дефолтна стратегія merge (default: 'last')
    """

    plugin_manager_factory: Callable[[], Any] | None = None
    tree_parser_factory: Callable[[], Any] | None = None
    hash_strategy_factory: Callable[[], Any] | None = None
    node_class: Type | None = None
    edge_class: Type | None = None
    default_merge_strategy: str = "last"

    # Кешовані інстанси (lazy initialization)
    _plugin_manager_instance: Any | None = field(default=None, repr=False)
    _tree_parser_instance: Any | None = field(default=None, repr=False)
    _hash_strategy_instance: Any | None = field(default=None, repr=False)

    def get_plugin_manager(self) -> Any | None:
        if self._plugin_manager_instance is None and self.plugin_manager_factory:
            self._plugin_manager_instance = self.plugin_manager_factory()
        return self._plugin_manager_instance

    def get_tree_parser(self) -> Any | None:
        if self._tree_parser_instance is None and self.tree_parser_factory:
            self._tree_parser_instance = self.tree_parser_factory()
        return self._tree_parser_instance

    def get_hash_strategy(self) -> Any | None:
        if self._hash_strategy_instance is None and self.hash_strategy_factory:
            self._hash_strategy_instance = self.hash_strategy_factory()
        return self._hash_strategy_instance

class DependencyRegistry:
    """
    Thread-safe Singleton для управління дефолтними залежностями.

    Підтримує як спеціалізований Node-dependency API (configure/get_context),
    так і generic DI-контейнер API (register/resolve).
    """

    _instance: "DependencyRegistry" | None = None
    _lock = threading.Lock()
    _config: DependencyConfig = DependencyConfig()

    # Generic DI-контейнер (register/resolve API)
    _factories: dict[type, Callable[..., Any]] = {}
    _singleton_types: set[type] = set()
    _singletons: dict[type, Any] = {}

    def __new__(cls):
        """Singleton pattern з thread-safety."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        """Ініціалізація (виконується один раз)."""
        if getattr(self, "_initialized", False):
            return
        self._initialized = True
        logger.debug("DependencyRegistry initialized")

    @classmethod
    def configure(
        cls,
        plugin_manager: Any | None = None,
        plugin_manager_factory: Callable[[], Any] | None = None,
        tree_parser: Any | None = None,
        tree_parser_factory: Callable[[], Any] | None = None,
        hash_strategy: Any | None = None,
        hash_strategy_factory: Callable[[], Any] | None = None,
        node_class: Type | None = None,
        edge_class: Type | None = None,
        default_merge_strategy: str = "last",
    ) -> None:
        """
        Конфігурує дефолтні залежності.

        Args:
            plugin_manager: Готовий інстанс plugin_manager
            plugin_manager_factory: Фабрика для створення plugin_manager
            tree_parser: Готовий інстанс tree_parser
            tree_parser_factory: Фабрика для створення tree_parser
            hash_strategy: Готовий інстанс hash_strategy
            hash_strategy_factory: Фабрика для створення hash_strategy
            node_class: Клас Node для створення
            edge_class: Клас Edge для створення
            default_merge_strategy: Дефолтна стратегія merge
        Example:
            >>> # Через factory (рекомендовано)
            >>> DependencyRegistry.configure(
            ...     plugin_manager_factory=lambda: NodePluginManager(),
            ...     default_merge_strategy='merge',
            ... )
            >>>
            >>> # Або через готовий інстанс
            >>> pm = NodePluginManager()
            >>> DependencyRegistry.configure(plugin_manager=pm)
        """
        with cls._lock:
            # Створюємо factory з інстансу якщо передано інстанс
            pm_factory: Callable[[], Any] | None = plugin_manager_factory
            if plugin_manager is not None and pm_factory is None:
                _pm = plugin_manager

                def _pm_factory(pm=_pm):
                    return pm

                pm_factory = _pm_factory

            tp_factory: Callable[[], Any] | None = tree_parser_factory
            if tree_parser is not None and tp_factory is None:
                _tp = tree_parser

                def _tp_factory(tp=_tp):
                    return tp

                tp_factory = _tp_factory

            hs_factory: Callable[[], Any] | None = hash_strategy_factory
            if hash_strategy is not None and hs_factory is None:
                _hs = hash_strategy

                def _hs_factory(hs=_hs):
                    return hs

                hs_factory = _hs_factory

            cls._config = DependencyConfig(
                plugin_manager_factory=pm_factory,
                tree_parser_factory=tp_factory,
                hash_strategy_factory=hs_factory,
                node_class=node_class,
                edge_class=edge_class,
                default_merge_strategy=default_merge_strategy,
            )

            logger.info(
                f"DependencyRegistry configured: "
                f"merge_strategy={default_merge_strategy}, "
                f"node_class={node_class}, "
                f"has_plugin_manager={pm_factory is not None}"
            )

    @classmethod
    def get_context(
        cls,
        plugin_manager: Any | None = None,
        tree_parser: Any | None = None,
        hash_strategy: Any | None = None,
        node_class: Type | None = None,
        edge_class: Type | None = None,
        default_merge_strategy: str | None = None,
    ) -> dict[str, Any]:
        """
        Отримує контекст для десеріалізації з можливістю override.

        Args:
            plugin_manager: Override для plugin_manager (опціонально)
            tree_parser: Override для tree_parser (опціонально)
            hash_strategy: Override для hash_strategy (опціонально)
            node_class: Override для node_class (опціонально)
            edge_class: Override для edge_class (опціонально)
            default_merge_strategy: Override для merge strategy (опціонально)
        Returns:
            Dict з усіма залежностями
        Example:
            >>> # Використати всі дефолти
            >>> context = DependencyRegistry.get_context()
            >>> graph = GraphMapper.to_domain(graph_dto, context=context)
            >>>
            >>> # Override тільки plugin_manager
            >>> context = DependencyRegistry.get_context(
            ...     plugin_manager=custom_pm,
            ... )
        """
        with cls._lock:
            config = cls._config

            return {
                "plugin_manager": plugin_manager
                if plugin_manager is not None
                else config.get_plugin_manager(),
                "tree_parser": tree_parser if tree_parser is not None else config.get_tree_parser(),
                "hash_strategy": hash_strategy
                if hash_strategy is not None
                else config.get_hash_strategy(),
                "node_class": node_class if node_class is not None else config.node_class,
                "edge_class": edge_class if edge_class is not None else config.edge_class,
                "default_merge_strategy": default_merge_strategy
                if default_merge_strategy is not None
                else config.default_merge_strategy,
            }

    @classmethod
    def get_default_merge_strategy(cls) -> str:
        """Отримує дефолтну стратегію merge."""
        with cls._lock:
            return cls._config.default_merge_strategy

    @classmethod
    def set_default_merge_strategy(cls, strategy: str) -> None:
        """
        Встановлює дефолтну стратегію merge.

        Args:
            strategy: Одна з: 'first', 'last', 'merge', 'newest', 'oldest', 'custom'
        """
        valid_strategies = ["first", "last", "merge", "newest", "oldest", "custom"]
        if strategy not in valid_strategies:
            raise ValueError(f"Invalid merge strategy: {strategy}. Valid: {valid_strategies}")

        with cls._lock:
            cls._config.default_merge_strategy = strategy
            logger.debug("Default merge strategy set to: %s", strategy)

    @classmethod
    def reset(cls) -> None:
        """
        Скидає всі налаштування до дефолтних значень.

        Корисно для тестування.
        """
        with cls._lock:
            cls._config = DependencyConfig()
            logger.debug("DependencyRegistry reset to defaults")

    @classmethod
    def set_plugin_manager(cls, plugin_manager: Any) -> None:
        with cls._lock:
            cls._config._plugin_manager_instance = plugin_manager
            if cls._config.plugin_manager_factory is None:
                cls._config.plugin_manager_factory = lambda pm=plugin_manager: pm

    @classmethod
    def set_tree_parser(cls, tree_parser: Any) -> None:
        with cls._lock:
            cls._config._tree_parser_instance = tree_parser
            if cls._config.tree_parser_factory is None:
                cls._config.tree_parser_factory = lambda tp=tree_parser: tp

    @classmethod
    def set_hash_strategy(cls, hash_strategy: Any) -> None:
        with cls._lock:
            cls._config._hash_strategy_instance = hash_strategy
            if cls._config.hash_strategy_factory is None:
                cls._config.hash_strategy_factory = lambda hs=hash_strategy: hs

    @classmethod
    def get_plugin_manager(cls) -> Any | None:
        with cls._lock:
            return cls._config.get_plugin_manager()

    @classmethod
    def get_tree_parser(cls) -> Any | None:
        with cls._lock:
            return cls._config.get_tree_parser()

    @classmethod
    def get_hash_strategy(cls) -> Any | None:
        with cls._lock:
            return cls._config.get_hash_strategy()

    # =========================================================================
    # Generic DI-контейнер API (register / resolve)
    # =========================================================================

    @classmethod
    def register(
        cls,
        interface: type,
        factory: Callable[..., Any],
        singleton: bool = False,
    ) -> None:
        """Реєстрація довільної залежності.

        Args:
            interface: Тип (клас або Protocol), що використовується як ключ
            factory: Callable без аргументів, що повертає екземпляр залежності
            singleton: True — фабрика викликається один раз, інстанс кешується

        Example:
            >>> DependencyRegistry.register(HashingService, lambda: XxHashService(), singleton=True)
            >>> DependencyRegistry.register(NodeRepository, lambda: InMemoryNodeRepository())
        """
        with cls._lock:
            cls._factories[interface] = factory
            if singleton:
                cls._singleton_types.add(interface)
            else:
                # Якщо перереєстрували як non-singleton - видаляємо старий singleton
                cls._singleton_types.discard(interface)
                cls._singletons.pop(interface, None)

        logger.debug("Registered dependency: %s (singleton=%s)", interface, singleton)

    @classmethod
    def resolve(cls, interface: type) -> Any:
        """Отримання екземпляра залежності.

        Args:
            interface: Тип, зареєстрований через register()

        Returns:
            Екземпляр залежності (кешований для singleton, новий для transient)

        Raises:
            KeyError: Якщо interface не зареєстровано

        Example:
            >>> hasher = DependencyRegistry.resolve(HashingService)   # Singleton
            >>> repo   = DependencyRegistry.resolve(NodeRepository)   # New instance
        """
        with cls._lock:
            if interface in cls._singleton_types:
                if interface not in cls._singletons:
                    cls._singletons[interface] = cls._factories[interface]()
                return cls._singletons[interface]

            if interface in cls._factories:
                return cls._factories[interface]()

        raise KeyError(f"No registration for {interface!r}")
