"""BaseStorageListener - події storage."""

from graph_crawler.domain.events import CrawlerEvent


class BaseStorageListener:
    """
    Базовий listener для подій storage.

        Відповідальність: події зберігання даних.

        Події:
        - on_storage_upgraded() - зміна типу storage
        - on_batch_completed() - завершення batch обробки
    """

    def on_storage_upgraded(self, event: CrawlerEvent) -> None:
        pass

    def on_batch_completed(self, event: CrawlerEvent) -> None:
        pass
