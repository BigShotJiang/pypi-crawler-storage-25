"""OpenTelemetry tracing integration for GraphCrawler.

Provides distributed tracing capabilities for production crawlers.

Usage:
    from graph_crawler.observability.tracing import traced, get_tracer, init_tracing
    
    # Initialize tracing (optional - auto-configures from env)
    init_tracing(service_name="my-crawler")
    
    # Use decorator for async functions
    @traced("crawl_page")
    async def crawl(url: str) -> Graph:
        ...
    
    # Manual spans
    tracer = get_tracer()
    with tracer.start_as_current_span("my_operation") as span:
        span.set_attribute("url", url)
        ...

Environment variables:
    OTEL_ENABLED: Enable/disable tracing (default: false)
    OTEL_SERVICE_NAME: Service name for traces (default: graphcrawler)
    OTEL_EXPORTER_OTLP_ENDPOINT: OTLP endpoint for exporting traces
    OTEL_EXPORTER_OTLP_HEADERS: Headers for OTLP exporter (comma-separated key=value)
"""
from __future__ import annotations

import asyncio
import logging
import os
from functools import wraps
from typing import Any, Callable, ParamSpec, TypeVar

logger = logging.getLogger(__name__)

P = ParamSpec("P")
T = TypeVar("T")

# Lazy-loaded tracer to avoid import errors when opentelemetry is not installed
_tracer = None
_tracing_initialized = False


def is_tracing_enabled() -> bool:
    return os.environ.get("OTEL_ENABLED", "false").lower() == "true"


def init_tracing(
    service_name: str | None = None,
    endpoint: str | None = None,
    headers: dict[str, str] | None = None,
) -> bool:
    """Initialize OpenTelemetry tracing.
    
    Args:
        service_name: Service name for traces (default: from env or "graphcrawler")
        endpoint: OTLP endpoint (default: from env)
        headers: OTLP headers (default: from env)
    
    Returns:
        True if tracing was initialized successfully, False otherwise
    
    Note:
        This function is idempotent - calling it multiple times has no effect.
        Tracing is only initialized if OTEL_ENABLED=true or explicitly called.
    """
    global _tracer, _tracing_initialized

    if _tracing_initialized:
        return True

    if not is_tracing_enabled():
        logger.debug("OpenTelemetry tracing disabled (OTEL_ENABLED != true)")
        return False

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        # Get configuration from environment or parameters
        svc_name = service_name or os.environ.get("OTEL_SERVICE_NAME", "graphcrawler")
        otlp_endpoint = endpoint or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")

        # Parse headers from environment
        env_headers = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "")
        parsed_headers = {}
        if env_headers:
            for pair in env_headers.split(","):
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    parsed_headers[key.strip()] = value.strip()

        otlp_headers = headers or parsed_headers if parsed_headers else None

        # Create resource with service info
        resource = Resource.create({
            "service.name": svc_name,
            "service.version": "4.0.34",
        })

        # Create and configure tracer provider
        provider = TracerProvider(resource=resource)

        # Add OTLP exporter if endpoint is configured
        if otlp_endpoint:
            try:
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

                exporter = OTLPSpanExporter(
                    endpoint=otlp_endpoint,
                    headers=otlp_headers,
                )
                provider.add_span_processor(BatchSpanProcessor(exporter))
                logger.info("OTLP tracing exporter configured: %s", otlp_endpoint)
            except ImportError:
                logger.warning("OTLP exporter not available - install opentelemetry-exporter-otlp")

        # Set global tracer provider
        trace.set_tracer_provider(provider)
        _tracer = trace.get_tracer("graphcrawler")
        _tracing_initialized = True

        logger.info("OpenTelemetry tracing initialized: service=%s", svc_name)
        return True

    except ImportError:
        logger.debug("OpenTelemetry not installed - tracing disabled")
        return False
    except Exception as e:
        logger.warning("Failed to initialize OpenTelemetry tracing: %s", e)
        return False


def get_tracer():
    """Get the OpenTelemetry tracer instance.
    
    Returns:
        Tracer instance or NoOpTracer if tracing is disabled
    """
    global _tracer

    if _tracer is not None:
        return _tracer

    # Try to initialize if enabled
    if is_tracing_enabled():
        init_tracing()
        if _tracer is not None:
            return _tracer

    # Return NoOp tracer
    try:
        from opentelemetry import trace
        return trace.get_tracer("graphcrawler")
    except ImportError:
        return _NoOpTracer()


class _NoOpTracer:
    """No-op tracer for when OpenTelemetry is not available."""

    def start_as_current_span(self, name: str, **kwargs):
        return _NoOpSpan()

    def start_span(self, name: str, **kwargs):
        return _NoOpSpan()


class _NoOpSpan:
    """No-op span context manager."""

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_attributes(self, attributes: dict[str, Any]) -> None:
        pass

    def add_event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        pass

    def record_exception(self, exception: Exception) -> None:
        pass

    def set_status(self, status) -> None:
        pass


def traced(span_name: str, attributes: dict[str, Any] | None = None):
    """Decorator for tracing async and sync functions.
    
    Args:
        span_name: Name of the span (e.g., "crawl_page", "parse_html")
        attributes: Static attributes to add to every span
    
    Returns:
        Decorated function with automatic tracing
    
    Examples:
        >>> @traced("fetch_url")
        ... async def fetch(url: str) -> str:
        ...     return await client.get(url)
        
        >>> @traced("process_batch", {"batch_type": "urls"})
        ... def process(items: list) -> list:
        ...     return [process_item(i) for i in items]
    """
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        tracer = get_tracer()

        if asyncio.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
                with tracer.start_as_current_span(span_name) as span:
                    span.set_attribute("function", func.__name__)
                    span.set_attribute("module", func.__module__)
                    if attributes:
                        span.set_attributes(attributes)
                    try:
                        result = await func(*args, **kwargs)
                        return result
                    except Exception as e:
                        span.record_exception(e)
                        raise
            return async_wrapper
        else:
            @wraps(func)
            def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
                with tracer.start_as_current_span(span_name) as span:
                    span.set_attribute("function", func.__name__)
                    span.set_attribute("module", func.__module__)
                    if attributes:
                        span.set_attributes(attributes)
                    try:
                        result = func(*args, **kwargs)
                        return result
                    except Exception as e:
                        span.record_exception(e)
                        raise
            return sync_wrapper
    return decorator


def trace_crawl_context(url: str, depth: int = 0, **extra_attrs) -> Any:
    """Create a span for crawl context with standard attributes.
    
    Args:
        url: URL being crawled
        depth: Crawl depth
        **extra_attrs: Additional attributes to add
    
    Returns:
        Span context manager
    
    Example:
        >>> with trace_crawl_context("https://example.com", depth=2):
        ...     await process_page()
    """
    tracer = get_tracer()
    span = tracer.start_as_current_span("crawl_context")
    span.set_attribute("url", url)
    span.set_attribute("depth", depth)
    if extra_attrs:
        span.set_attributes(extra_attrs)
    return span


__all__ = [
    "traced",
    "get_tracer",
    "init_tracing",
    "is_tracing_enabled",
    "trace_crawl_context",
]
