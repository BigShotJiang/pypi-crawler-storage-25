"""Platform detection module.

Detects operating system, Python version, and environment characteristics.
"""
from __future__ import annotations

import logging
import os
import platform
import sys
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class PlatformInfo:
    """Complete platform information snapshot.
    
    Attributes:
        os_name: Operating system name (Windows, Linux, Darwin, etc.)
        os_version: OS version string
        os_release: OS release identifier
        architecture: CPU architecture (x86_64, arm64, etc.)
        python_version: Python version tuple (major, minor, micro)
        python_implementation: CPython, PyPy, etc.
        cpu_cores: Number of CPU cores (logical)
        cpu_cores_physical: Number of physical CPU cores
        memory_total_gb: Total system RAM in GB
        memory_available_gb: Available RAM in GB
        is_64bit: Whether running on 64-bit system
        is_container: Whether running inside container (Docker, K8s)
        is_wsl: Whether running under WSL (Windows Subsystem for Linux)
        is_android: Whether running on Android (Termux, etc.)
        hostname: Machine hostname
        has_aiodns: Whether aiodns is available
        has_uvloop: Whether uvloop is available (Linux/macOS optimization)
        free_threading_enabled: Python 3.14+ free-threading mode
    """
    os_name: str
    os_version: str
    os_release: str
    architecture: str
    python_version: tuple[int, int, int]
    python_implementation: str
    cpu_cores: int
    cpu_cores_physical: Optional[int]
    memory_total_gb: float
    memory_available_gb: float
    is_64bit: bool
    is_container: bool
    is_wsl: bool
    is_android: bool
    hostname: str
    has_aiodns: bool
    has_uvloop: bool
    free_threading_enabled: bool
    extra: dict = field(default_factory=dict)

    @property
    def python_version_str(self) -> str:
        return f"{self.python_version[0]}.{self.python_version[1]}.{self.python_version[2]}"

    @property
    def is_windows(self) -> bool:
        return self.os_name == "Windows"

    @property
    def is_linux(self) -> bool:
        return self.os_name == "Linux" and not self.is_android

    @property
    def is_macos(self) -> bool:
        return self.os_name == "Darwin"

    def to_dict(self) -> dict:
        return {
            "os": {
                "name": self.os_name,
                "version": self.os_version,
                "release": self.os_release,
                "architecture": self.architecture,
                "is_64bit": self.is_64bit,
                "is_container": self.is_container,
                "is_wsl": self.is_wsl,
                "is_android": self.is_android,
            },
            "python": {
                "version": self.python_version_str,
                "version_tuple": list(self.python_version),
                "implementation": self.python_implementation,
                "free_threading": self.free_threading_enabled,
            },
            "hardware": {
                "cpu_cores": self.cpu_cores,
                "cpu_cores_physical": self.cpu_cores_physical,
                "memory_total_gb": round(self.memory_total_gb, 2),
                "memory_available_gb": round(self.memory_available_gb, 2),
            },
            "capabilities": {
                "has_aiodns": self.has_aiodns,
                "has_uvloop": self.has_uvloop,
            },
            "hostname": self.hostname,
            "extra": self.extra,
        }


def _detect_cpu_cores() -> tuple[int, Optional[int]]:
    logical_cores = os.cpu_count() or 1
    physical_cores = None

    try:
        import psutil
        physical_cores = psutil.cpu_count(logical=False)
    except ImportError:
        # Fallback: try to estimate from /proc/cpuinfo on Linux
        if platform.system() == "Linux":
            try:
                with open("/proc/cpuinfo") as f:
                    physical_ids = set()
                    for line in f:
                        if line.startswith("physical id"):
                            physical_ids.add(line.strip())
                    if physical_ids:
                        physical_cores = len(physical_ids)
            except Exception:
                pass

    return logical_cores, physical_cores


def _detect_memory() -> tuple[float, float]:
    try:
        import psutil
        mem = psutil.virtual_memory()
        total_gb = mem.total / (1024 ** 3)
        available_gb = mem.available / (1024 ** 3)
        return total_gb, available_gb
    except ImportError:
        # Fallback: try /proc/meminfo on Linux
        if platform.system() == "Linux":
            try:
                with open("/proc/meminfo") as f:
                    meminfo = {}
                    for line in f:
                        parts = line.split(":")
                        if len(parts) == 2:
                            key = parts[0].strip()
                            value = parts[1].strip().split()[0]
                            meminfo[key] = int(value)

                    total_kb = meminfo.get("MemTotal", 0)
                    available_kb = meminfo.get("MemAvailable", meminfo.get("MemFree", 0))
                    return total_kb / (1024 ** 2), available_kb / (1024 ** 2)
            except Exception:
                pass

        # Cannot detect memory
        return 0.0, 0.0


def _detect_container() -> bool:
    # Check cgroup (Docker, K8s)
    if os.path.exists("/.dockerenv"):
        return True

    if os.path.exists("/run/.containerenv"):  # Podman
        return True

    try:
        with open("/proc/1/cgroup", "r") as f:
            content = f.read()
            if "docker" in content or "kubepods" in content or "containerd" in content:
                return True
    except Exception:
        pass

    # Check environment variables
    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return True

    return False


def _detect_wsl() -> bool:
    if platform.system() != "Linux":
        return False

    try:
        with open("/proc/version", "r") as f:
            version = f.read().lower()
            if "microsoft" in version or "wsl" in version:
                return True
    except Exception:
        pass

    return "WSL_DISTRO_NAME" in os.environ


def _detect_android() -> bool:
    # Check for Termux
    if "com.termux" in os.environ.get("PREFIX", ""):
        return True

    if os.path.exists("/system/build.prop"):
        return True

    if "ANDROID_ROOT" in os.environ:
        return True

    return False


def _check_aiodns() -> bool:
    try:
        import aiodns
        # On Windows, aiodns may be installed but not work properly
        if platform.system() == "Windows":
            try:
                # Try to create resolver - this may fail on Windows
                resolver = aiodns.DNSResolver()
                return True
            except Exception:
                return False
        return True
    except ImportError:
        return False


def _check_uvloop() -> bool:
    if platform.system() == "Windows":
        return False  # uvloop doesn't support Windows

    try:
        import uvloop
        return True
    except ImportError:
        return False


def _check_free_threading() -> bool:
    if sys.version_info < (3, 14):
        return False

    try:
        # Python 3.14 has sys._is_gil_enabled()
        return not sys._is_gil_enabled()
    except AttributeError:
        return False


def get_platform_info() -> PlatformInfo:
    """Collect complete platform information.
    
    Returns:
        PlatformInfo object with all detected information.
    
    Example:
        >>> info = get_platform_info()
        >>> print(f"Running on {info.os_name} with {info.cpu_cores} cores")
        Running on Linux with 8 cores
    """
    cpu_logical, cpu_physical = _detect_cpu_cores()
    mem_total, mem_available = _detect_memory()

    info = PlatformInfo(
        os_name=platform.system(),
        os_version=platform.version(),
        os_release=platform.release(),
        architecture=platform.machine(),
        python_version=sys.version_info[:3],
        python_implementation=platform.python_implementation(),
        cpu_cores=cpu_logical,
        cpu_cores_physical=cpu_physical,
        memory_total_gb=mem_total,
        memory_available_gb=mem_available,
        is_64bit=sys.maxsize > 2**32,
        is_container=_detect_container(),
        is_wsl=_detect_wsl(),
        is_android=_detect_android(),
        hostname=platform.node(),
        has_aiodns=_check_aiodns(),
        has_uvloop=_check_uvloop(),
        free_threading_enabled=_check_free_threading(),
    )

    logger.info(
        "Platform detected: %s %s, Python %s, %d cores, %.1fGB RAM, container=%s",
        info.os_name,
        info.architecture,
        info.python_version_str,
        info.cpu_cores,
        info.memory_total_gb,
        info.is_container,
    )

    return info


# Convenience functions
def is_windows() -> bool:
    return platform.system() == "Windows"


def is_linux() -> bool:
    return platform.system() == "Linux" and not _detect_android()


def is_macos() -> bool:
    return platform.system() == "Darwin"


def is_android() -> bool:
    return _detect_android()


def is_container() -> bool:
    return _detect_container()


# Cached platform info (lazily initialized)
_cached_platform_info: Optional[PlatformInfo] = None


def get_cached_platform_info() -> PlatformInfo:
    global _cached_platform_info
    if _cached_platform_info is None:
        _cached_platform_info = get_platform_info()
    return _cached_platform_info
