"""Adaptive DNS Resolver with automatic fallback.

Universal solution for DNS resolution issues across all platforms.
Automatically detects DNS problems and switches to reliable public DNS servers.

Strategy (Windows-first approach):
1. On Windows: ALWAYS use public DNS (Google/Cloudflare) - system DNS is unreliable
2. On Linux/macOS: Test system DNS first, fallback to public if needed
3. Caches successful resolutions for performance
4. Platform-agnostic configuration via environment variables

Features:
- Automatic platform detection
- Public DNS fallback (Google 8.8.8.8, Cloudflare 1.1.1.1)
- DNS health checking with latency measurement
- Configurable via GRAPH_CRAWLER_DNS_SERVERS environment variable
"""
from __future__ import annotations

import asyncio
import logging
import os
import platform
import socket
from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple
import time

logger = logging.getLogger(__name__)

# Reliable public DNS servers (ordered by reliability and speed)
PUBLIC_DNS_SERVERS = [
    "8.8.8.8",      # Google Primary
    "8.8.4.4",      # Google Secondary  
    "1.1.1.1",      # Cloudflare Primary
    "1.0.0.1",      # Cloudflare Secondary
    "9.9.9.9",      # Quad9 (security-focused)
    "208.67.222.222",  # OpenDNS
]

# Test domains for DNS health check
DNS_TEST_DOMAINS = [
    "google.com",
    "cloudflare.com", 
    "microsoft.com",
]

def _is_windows() -> bool:
    return platform.system() == "Windows"


def _get_env_dns_servers() -> Optional[List[str]]:
    env_value = os.environ.get("GRAPH_CRAWLER_DNS_SERVERS")
    if env_value:
        return [s.strip() for s in env_value.split(",") if s.strip()]
    return None


@dataclass
class DNSHealthStatus:
    """DNS health check result."""
    is_healthy: bool
    latency_ms: float
    resolver_type: str  # "system" or "public"
    nameservers: List[str] = field(default_factory=list)
    error: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "is_healthy": self.is_healthy,
            "latency_ms": round(self.latency_ms, 2),
            "resolver_type": self.resolver_type,
            "nameservers": self.nameservers,
            "error": self.error,
        }


class AdaptiveResolver:
    """Adaptive DNS resolver with automatic fallback to public DNS.
    
    This resolver provides reliable DNS resolution across all platforms by:
    1. First attempting system DNS (respects local config, VPN, etc.)
    2. Automatically falling back to public DNS servers on failure
    3. Caching the working resolver configuration
    
    Usage:
        resolver = AdaptiveResolver()
        aiohttp_resolver = await resolver.get_aiohttp_resolver()
        
        # Or with health check
        health = await resolver.check_dns_health()
        if health.is_healthy:
            resolver = await resolver.get_aiohttp_resolver()
    """
    
    def __init__(
        self,
        custom_nameservers: Optional[List[str]] = None,
        fallback_to_public: bool = True,
        cache_ttl: int = 300,
    ):
        """Initialize adaptive resolver.
        
        Args:
            custom_nameservers: Custom DNS servers to try first (before public)
            fallback_to_public: Whether to fallback to public DNS on failure
            cache_ttl: How long to cache resolver choice (seconds)
        """
        self.custom_nameservers = custom_nameservers or []
        self.fallback_to_public = fallback_to_public
        self.cache_ttl = cache_ttl
        
        self._cached_resolver_type: Optional[str] = None
        self._cached_nameservers: Optional[List[str]] = None
        self._cache_timestamp: float = 0
        self._health_status: Optional[DNSHealthStatus] = None
        
    def _is_cache_valid(self) -> bool:
        if self._cached_resolver_type is None:
            return False
        return (time.time() - self._cache_timestamp) < self.cache_ttl
    
    async def _test_dns_resolution(
        self, 
        domain: str = "google.com",
        timeout: float = 5.0,
    ) -> Tuple[bool, float, Optional[str]]:
        """Test if DNS resolution works.
        
        Returns:
            Tuple of (success, latency_ms, error_message)
        """
        start = time.time()
        try:
            loop = asyncio.get_event_loop()
            await asyncio.wait_for(
                loop.getaddrinfo(domain, 80, family=socket.AF_INET),
                timeout=timeout
            )
            latency = (time.time() - start) * 1000
            return True, latency, None
        except asyncio.TimeoutError:
            return False, timeout * 1000, "DNS resolution timeout"
        except socket.gaierror as e:
            return False, (time.time() - start) * 1000, f"DNS resolution failed: {e}"
        except Exception as e:
            return False, (time.time() - start) * 1000, f"DNS error: {e}"
    
    async def _test_aiodns_resolution(
        self,
        nameservers: List[str],
        domain: str = "google.com", 
        timeout: float = 5.0,
    ) -> Tuple[bool, float, Optional[str]]:
        """Test DNS resolution using aiodns with specific nameservers.
        
        Returns:
            Tuple of (success, latency_ms, error_message)
        """
        try:
            import aiodns
        except ImportError:
            return False, 0, "aiodns not installed"
            
        start = time.time()
        try:
            resolver = aiodns.DNSResolver(nameservers=nameservers)
            await asyncio.wait_for(
                resolver.query(domain, "A"),
                timeout=timeout
            )
            latency = (time.time() - start) * 1000
            return True, latency, None
        except asyncio.TimeoutError:
            return False, timeout * 1000, "DNS resolution timeout"
        except Exception as e:
            return False, (time.time() - start) * 1000, f"DNS error: {e}"
    
    async def check_dns_health(self, force: bool = False) -> DNSHealthStatus:
        """Check DNS health and determine best resolver strategy.
        
        This method tests DNS resolution and caches the result.
        
        Args:
            force: Force recheck even if cache is valid
            
        Returns:
            DNSHealthStatus with health info and recommended resolver
        """
        # Return cached result if valid
        if not force and self._health_status and self._is_cache_valid():
            return self._health_status
            
        logger.info("Checking DNS health...")
        
        # Test 1: System DNS
        for domain in DNS_TEST_DOMAINS:
            success, latency, error = await self._test_dns_resolution(domain)
            if success:
                logger.info(
                    "System DNS healthy: resolved %s in %.1fms",
                    domain, latency
                )
                self._health_status = DNSHealthStatus(
                    is_healthy=True,
                    latency_ms=latency,
                    resolver_type="system",
                    nameservers=[],
                )
                self._cached_resolver_type = "system"
                self._cached_nameservers = None
                self._cache_timestamp = time.time()
                return self._health_status
        
        logger.warning("System DNS failed, testing public DNS servers...")
        
        # Test 2: Custom nameservers (if provided)
        if self.custom_nameservers:
            success, latency, error = await self._test_aiodns_resolution(
                self.custom_nameservers, DNS_TEST_DOMAINS[0]
            )
            if success:
                logger.info(
                    "Custom DNS healthy: resolved via %s in %.1fms",
                    self.custom_nameservers[0], latency
                )
                self._health_status = DNSHealthStatus(
                    is_healthy=True,
                    latency_ms=latency,
                    resolver_type="custom",
                    nameservers=self.custom_nameservers,
                )
                self._cached_resolver_type = "custom"
                self._cached_nameservers = self.custom_nameservers
                self._cache_timestamp = time.time()
                return self._health_status
        
        # Test 3: Public DNS servers
        if self.fallback_to_public:
            # Try pairs of DNS servers for redundancy
            for i in range(0, len(PUBLIC_DNS_SERVERS), 2):
                nameservers = PUBLIC_DNS_SERVERS[i:i+2]
                success, latency, error = await self._test_aiodns_resolution(
                    nameservers, DNS_TEST_DOMAINS[0]
                )
                if success:
                    logger.info(
                        "Public DNS healthy: resolved via %s in %.1fms",
                        nameservers[0], latency
                    )
                    self._health_status = DNSHealthStatus(
                        is_healthy=True,
                        latency_ms=latency,
                        resolver_type="public",
                        nameservers=nameservers,
                    )
                    self._cached_resolver_type = "public"
                    self._cached_nameservers = nameservers
                    self._cache_timestamp = time.time()
                    return self._health_status
        
        # All DNS options failed
        logger.error("All DNS resolution methods failed!")
        self._health_status = DNSHealthStatus(
            is_healthy=False,
            latency_ms=0,
            resolver_type="none",
            error="All DNS resolution methods failed. Check network connectivity.",
        )
        return self._health_status
    
    async def get_aiohttp_resolver(self) -> Any:
        """Get appropriate aiohttp resolver based on platform and DNS health.
        
        Strategy:
        - Windows: ALWAYS use public DNS (AsyncResolver with Google/Cloudflare)
          because Windows system DNS is unreliable with async libraries
        - Linux/macOS: Test system DNS, fallback to public if needed
        
        Returns:
            aiohttp resolver (AsyncResolver or ThreadedResolver)
        """
        import aiohttp
        
        # Check for environment override first
        env_servers = _get_env_dns_servers()
        if env_servers:
            logger.info(
                "Using DNS servers from GRAPH_CRAWLER_DNS_SERVERS: %s",
                env_servers
            )
            try:
                return aiohttp.AsyncResolver(nameservers=env_servers)
            except Exception as e:
                logger.warning("Failed to create AsyncResolver with env servers: %s", e)
        
        # Windows: ALWAYS use public DNS - don't even test system DNS
        # System DNS on Windows has known issues with aiohttp/asyncio
        if _is_windows():
            nameservers = self.custom_nameservers or PUBLIC_DNS_SERVERS[:3]
            logger.info(
                "Windows detected: Using public DNS servers directly: %s",
                nameservers
            )
            try:
                resolver = aiohttp.AsyncResolver(nameservers=nameservers)
                self._cached_resolver_type = "public"
                self._cached_nameservers = nameservers
                self._cache_timestamp = time.time()
                return resolver
            except Exception as e:
                logger.error(
                    "Failed to create AsyncResolver on Windows: %s. "
                    "DNS resolution may fail. Try: pip install aiodns",
                    e
                )
                # Last resort fallback
                return aiohttp.ThreadedResolver()
        
        # Linux/macOS: Check DNS health and use appropriate resolver
        if not self._is_cache_valid():
            await self.check_dns_health()
        
        resolver_type = self._cached_resolver_type
        nameservers = self._cached_nameservers
        
        if resolver_type == "system":
            # System DNS works - use ThreadedResolver (uses system DNS)
            logger.info("Using system DNS via ThreadedResolver")
            return aiohttp.ThreadedResolver()
            
        elif resolver_type in ("custom", "public") and nameservers:
            # Need specific nameservers - use AsyncResolver
            try:
                resolver = aiohttp.AsyncResolver(nameservers=nameservers)
                logger.info(
                    "Using AsyncResolver with nameservers: %s",
                    nameservers
                )
                return resolver
            except Exception as e:
                logger.warning(
                    "Failed to create AsyncResolver: %s. Falling back to ThreadedResolver.",
                    e
                )
                return aiohttp.ThreadedResolver()
        
        else:
            # Fallback to ThreadedResolver
            logger.warning("DNS health unknown, using ThreadedResolver as fallback")
            return aiohttp.ThreadedResolver()
    
    def get_resolver_info(self) -> dict:
        return {
            "resolver_type": self._cached_resolver_type,
            "nameservers": self._cached_nameservers,
            "cache_valid": self._is_cache_valid(),
            "health_status": self._health_status.to_dict() if self._health_status else None,
        }


# Global adaptive resolver instance (lazy initialized)
_adaptive_resolver: Optional[AdaptiveResolver] = None


def get_adaptive_resolver(
    custom_nameservers: Optional[List[str]] = None,
    fallback_to_public: bool = True,
) -> AdaptiveResolver:
    """Get or create global adaptive resolver.
    
    Args:
        custom_nameservers: Custom DNS servers to prefer
        fallback_to_public: Whether to fallback to public DNS
        
    Returns:
        AdaptiveResolver instance
    """
    global _adaptive_resolver
    
    if _adaptive_resolver is None or custom_nameservers:
        _adaptive_resolver = AdaptiveResolver(
            custom_nameservers=custom_nameservers,
            fallback_to_public=fallback_to_public,
        )
    
    return _adaptive_resolver


async def get_best_aiohttp_resolver(
    custom_nameservers: Optional[List[str]] = None,
) -> Any:
    """Convenience function to get best aiohttp resolver.
    
    Automatically checks DNS health and returns appropriate resolver.
    
    Args:
        custom_nameservers: Custom DNS servers to prefer
        
    Returns:
        aiohttp resolver instance
    """
    resolver = get_adaptive_resolver(custom_nameservers)
    return await resolver.get_aiohttp_resolver()
