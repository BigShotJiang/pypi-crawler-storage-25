"""Platform-specific configuration and optimizations.

Provides optimized settings based on detected platform.
Supports manual override via environment variables and config files.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from graph_crawler.shared.platform.detector import (
    PlatformInfo,
    get_cached_platform_info,
)

logger = logging.getLogger(__name__)

# Environment variable prefix
_ENV_PREFIX = "GRAPH_CRAWLER_"


def _get_env(key: str, default: Optional[str] = None) -> Optional[str]:
    return os.environ.get(f"{_ENV_PREFIX}{key}", default)


def _load_config_file() -> dict:
    config = {}

    # Try TOML
    toml_path = Path(".graph_crawler.toml")
    if toml_path.exists():
        try:
            import tomllib
            with open(toml_path, "rb") as f:
                data = tomllib.load(f)
                config = data.get("platform", {})
        except ImportError:
            try:
                import tomli
                with open(toml_path, "rb") as f:
                    data = tomli.load(f)
                    config = data.get("platform", {})
            except ImportError:
                pass
        except Exception:
            pass

    # Try YAML as fallback
    if not config:
        yaml_path = Path("graph_crawler.yaml")
        if yaml_path.exists():
            try:
                import yaml
                with open(yaml_path) as f:
                    data = yaml.safe_load(f)
                    config = data.get("platform", {}) if data else {}
            except ImportError:
                pass
            except Exception:
                pass

    return config


class DNSResolverType(Enum):
    """DNS resolver types with platform compatibility."""
    AIODNS = "aiodns"           # Async DNS (best for Linux/macOS)
    THREADED = "threaded"       # ThreadedResolver (Windows fallback)
    SYSTEM = "system"           # System default resolver
    CUSTOM_NAMESERVERS = "custom_nameservers"  # Explicit DNS servers
    ADAPTIVE = "adaptive"       # Auto-detect best resolver (recommended)


class EventLoopPolicy(Enum):
    """Event loop policy options."""
    DEFAULT = "default"         # Default asyncio policy
    UVLOOP = "uvloop"           # uvloop (Linux/macOS, faster)
    WINDOWS_SELECTOR = "windows_selector"  # SelectorEventLoop for Windows
    WINDOWS_PROACTOR = "windows_proactor"  # ProactorEventLoop for Windows


@dataclass
class PlatformConfig:
    """Platform-optimized configuration.
    
    Attributes:
        dns_resolver_type: Recommended DNS resolver type
        dns_nameservers: Custom DNS servers (if needed)
        event_loop_policy: Recommended event loop policy
        recommended_concurrency: Optimal concurrent connections
        recommended_connections_per_host: Connections per host limit
        use_tcp_keepalive: Whether to enable TCP keepalive
        connector_ttl_dns_cache: DNS cache TTL in seconds
        connector_keepalive_timeout: Keepalive timeout in seconds
        warnings: List of platform-specific warnings
        optimizations: List of applied optimizations
    """
    dns_resolver_type: DNSResolverType
    dns_nameservers: Optional[list[str]]
    event_loop_policy: EventLoopPolicy
    recommended_concurrency: int
    recommended_connections_per_host: int
    use_tcp_keepalive: bool
    connector_ttl_dns_cache: int
    connector_keepalive_timeout: int
    warnings: list[str]
    optimizations: list[str]
    platform_info: PlatformInfo

    def to_dict(self) -> dict:
        return {
            "dns": {
                "resolver_type": self.dns_resolver_type.value,
                "nameservers": self.dns_nameservers,
            },
            "event_loop": {
                "policy": self.event_loop_policy.value,
            },
            "connections": {
                "recommended_concurrency": self.recommended_concurrency,
                "connections_per_host": self.recommended_connections_per_host,
                "tcp_keepalive": self.use_tcp_keepalive,
            },
            "connector": {
                "ttl_dns_cache": self.connector_ttl_dns_cache,
                "keepalive_timeout": self.connector_keepalive_timeout,
            },
            "warnings": self.warnings,
            "optimizations": self.optimizations,
            "platform": self.platform_info.to_dict(),
        }

    def get_aiohttp_connector_kwargs(self) -> dict[str, Any]:
        """Get kwargs for aiohttp.TCPConnector.
        
        Returns:
            Dictionary of connector settings optimized for current platform.
        """
        kwargs = {
            "limit": self.recommended_concurrency,
            "limit_per_host": self.recommended_connections_per_host,
            "ttl_dns_cache": self.connector_ttl_dns_cache,
            "keepalive_timeout": self.connector_keepalive_timeout,
            "force_close": False,
            "enable_cleanup_closed": True,
        }

        # TCP keepalive (available in newer aiohttp)
        if self.use_tcp_keepalive:
            kwargs["enable_cleanup_closed"] = True

        return kwargs

    def get_resolver(self) -> Any:
        """Create appropriate aiohttp resolver based on config.
        
        Returns:
            aiohttp resolver instance (AsyncResolver or ThreadedResolver).
            
        Note:
            For ADAPTIVE type, use get_resolver_async() instead for proper
            DNS health checking.
        """
        import aiohttp

        if self.dns_resolver_type == DNSResolverType.AIODNS:
            try:
                if self.dns_nameservers:
                    return aiohttp.AsyncResolver(nameservers=self.dns_nameservers)
                return aiohttp.AsyncResolver()
            except Exception as e:
                logger.warning("Failed to create AsyncResolver: %s, falling back to ThreadedResolver", e)
                return aiohttp.ThreadedResolver()

        elif self.dns_resolver_type == DNSResolverType.THREADED:
            return aiohttp.ThreadedResolver()

        elif self.dns_resolver_type == DNSResolverType.CUSTOM_NAMESERVERS:
            if self.dns_nameservers:
                try:
                    resolver = aiohttp.AsyncResolver(nameservers=self.dns_nameservers)
                    logger.info(
                        "Created AsyncResolver with custom nameservers: %s",
                        self.dns_nameservers
                    )
                    return resolver
                except Exception as e:
                    logger.warning(
                        "Failed to create AsyncResolver with nameservers %s: %s. "
                        "Falling back to ThreadedResolver.",
                        self.dns_nameservers, e
                    )
            return aiohttp.ThreadedResolver()

        elif self.dns_resolver_type == DNSResolverType.ADAPTIVE:
            # For sync context, return ThreadedResolver as safe default
            # Use get_resolver_async() for proper adaptive behavior
            logger.info(
                "ADAPTIVE resolver requested in sync context. "
                "Using ThreadedResolver. For full adaptive behavior, use get_resolver_async()."
            )
            return aiohttp.ThreadedResolver()

        else:  # SYSTEM
            return None  # Use default

    async def get_resolver_async(self) -> Any:
        """Create appropriate aiohttp resolver with async DNS health check.
        
        This is the recommended method for ADAPTIVE resolver type.
        It performs actual DNS health checks and selects the best resolver.
        
        Returns:
            aiohttp resolver instance optimized for current network conditions.
        """
        if self.dns_resolver_type == DNSResolverType.ADAPTIVE:
            from graph_crawler.shared.platform.adaptive_resolver import get_adaptive_resolver
            
            adaptive = get_adaptive_resolver(
                custom_nameservers=self.dns_nameservers,
                fallback_to_public=True,
            )
            resolver = await adaptive.get_aiohttp_resolver()
            
            # Log resolver info
            info = adaptive.get_resolver_info()
            logger.info(
                "Adaptive resolver selected: type=%s, nameservers=%s",
                info.get("resolver_type"),
                info.get("nameservers"),
            )
            return resolver
        
        # For non-adaptive types, use sync method
        return self.get_resolver()


def _calculate_concurrency(info: PlatformInfo) -> tuple[int, int]:
    """Calculate optimal concurrency based on resources.
    
    Returns:
        Tuple of (total_concurrency, per_host_limit)
    """
    base_concurrency = 100
    per_host_base = 10

    # Adjust based on CPU cores
    if info.cpu_cores >= 16:
        base_concurrency = 200
        per_host_base = 20
    elif info.cpu_cores >= 8:
        base_concurrency = 150
        per_host_base = 15
    elif info.cpu_cores >= 4:
        base_concurrency = 100
        per_host_base = 10
    elif info.cpu_cores >= 2:
        base_concurrency = 50
        per_host_base = 8
    else:
        base_concurrency = 25
        per_host_base = 5

    # Adjust based on memory
    if info.memory_available_gb < 1:
        base_concurrency = min(base_concurrency, 25)
        per_host_base = min(per_host_base, 5)
    elif info.memory_available_gb < 2:
        base_concurrency = min(base_concurrency, 50)
        per_host_base = min(per_host_base, 8)

    # Python 3.14 free-threading boost
    if info.free_threading_enabled:
        base_concurrency = int(base_concurrency * 1.5)
        per_host_base = int(per_host_base * 1.5)

    # Container environments may have limited resources
    if info.is_container:
        # Don't reduce, container usually has guaranteed resources
        pass

    # Android/mobile - be conservative
    if info.is_android:
        base_concurrency = min(base_concurrency, 30)
        per_host_base = min(per_host_base, 5)

    return base_concurrency, per_host_base


def _get_platform_info_with_override(platform_override: Optional[str]) -> PlatformInfo:
    """Get platform info, optionally overriding platform type for testing.
    
    Args:
        platform_override: Override platform type (windows, linux, macos, android, wsl, container)
    
    Returns:
        PlatformInfo with potentially modified flags for testing.
    """
    info = get_cached_platform_info()

    if not platform_override:
        return info

    platform_override = platform_override.lower().strip()

    overrides = {
        "windows": {"os_name": "Windows"},
        "linux": {"os_name": "Linux"},
        "macos": {"os_name": "Darwin"},
        "android": {"is_android": True},
        "wsl": {"is_wsl": True},
        "container": {"is_container": True},
    }

    if platform_override in overrides:
        # Create new instance with overridden values
        override_values = overrides[platform_override]
        modified_dict = {
            "os_name": override_values.get("os_name", info.os_name),
            "os_version": info.os_version,
            "os_release": info.os_release,
            "architecture": info.architecture,
            "python_version": info.python_version,
            "python_implementation": info.python_implementation,
            "cpu_cores": info.cpu_cores,
            "cpu_cores_physical": info.cpu_cores_physical,
            "memory_total_gb": info.memory_total_gb,
            "memory_available_gb": info.memory_available_gb,
            "is_64bit": info.is_64bit,
            "is_container": override_values.get("is_container", info.is_container),
            "is_wsl": override_values.get("is_wsl", info.is_wsl),
            "is_android": override_values.get("is_android", info.is_android),
            "hostname": info.hostname,
            "has_aiodns": info.has_aiodns,
            "has_uvloop": info.has_uvloop,
            "free_threading_enabled": info.free_threading_enabled,
        }

        logger.info("Platform override active: %s", platform_override)
        return PlatformInfo(**modified_dict)

    return info


def get_optimized_config(
    custom_dns_servers: Optional[list[str]] = None,
    force_threaded_resolver: bool = False,
    concurrency_override: Optional[int] = None,
    per_host_override: Optional[int] = None,
) -> PlatformConfig:
    """Get optimized configuration for current platform.
    
    Configuration priority (highest to lowest):
    1. Function kwargs (custom_dns_servers, force_threaded_resolver, etc.)
    2. Environment variables (GRAPH_CRAWLER_*)
    3. Config file (.graph_crawler.toml or graph_crawler.yaml)
    4. Auto-detection defaults
    
    Args:
        custom_dns_servers: Custom DNS servers (e.g., ["8.8.8.8", "8.8.4.4"])
        force_threaded_resolver: Force ThreadedResolver
        concurrency_override: Override recommended concurrency
        per_host_override: Override per-host connection limit
    
    Returns:
        PlatformConfig with optimized settings.
    
    Environment variables:
        GRAPH_CRAWLER_DNS_RESOLVER: aiodns | threaded | system
        GRAPH_CRAWLER_DNS_SERVERS: Comma-separated DNS servers
        GRAPH_CRAWLER_CONCURRENCY: Override concurrency
        GRAPH_CRAWLER_PLATFORM_OVERRIDE: windows | linux | macos | android | wsl | container
    """
    # Load config file (lowest priority)
    file_config = _load_config_file()

    # Get platform info (may be overridden for testing)
    platform_override = _get_env("PLATFORM_OVERRIDE") or file_config.get("platform_override")
    info = _get_platform_info_with_override(platform_override)

    warnings: list[str] = []
    optimizations: list[str] = []

    # Resolve DNS configuration (priority: kwargs > env > file > auto)
    env_dns_resolver = _get_env("DNS_RESOLVER")
    env_dns_servers = _get_env("DNS_SERVERS")

    dns_resolver_type = DNSResolverType.AIODNS
    dns_nameservers = custom_dns_servers

    # Apply DNS servers (priority: kwargs > env > file)
    if not dns_nameservers and env_dns_servers:
        dns_nameservers = [s.strip() for s in env_dns_servers.split(",")]

    if not dns_nameservers and file_config.get("dns_servers"):
        dns_nameservers = file_config["dns_servers"]

    # Determine DNS resolver type
    # Check for explicit resolver choice first
    if env_dns_resolver == "adaptive" or file_config.get("dns_resolver") == "adaptive":
        dns_resolver_type = DNSResolverType.ADAPTIVE
        optimizations.append("Adaptive DNS resolver (auto-detect best option)")
        
    elif force_threaded_resolver or env_dns_resolver == "threaded" or file_config.get("dns_resolver") == "threaded":
        dns_resolver_type = DNSResolverType.THREADED
        optimizations.append("Forced ThreadedResolver (user request)")

    elif env_dns_resolver == "aiodns" or file_config.get("dns_resolver") == "aiodns":
        dns_resolver_type = DNSResolverType.AIODNS
        optimizations.append("Forced AsyncResolver (user request)")

    elif dns_nameservers:
        # User provided custom DNS servers
        dns_resolver_type = DNSResolverType.CUSTOM_NAMESERVERS
        optimizations.append(f"Custom DNS servers: {', '.join(dns_nameservers[:2])}")

    else:
        # AUTO MODE: Use ADAPTIVE resolver for all platforms
        # This provides the most reliable DNS resolution by:
        # 1. Testing system DNS first (fastest, respects local config)
        # 2. Falling back to public DNS on failure (Google, Cloudflare)
        dns_resolver_type = DNSResolverType.ADAPTIVE
        
        if info.is_windows:
            optimizations.append("Adaptive DNS for Windows (auto-fallback to public DNS if needed)")
            warnings.append(
                "Windows detected: Using adaptive DNS resolver. "
                "If DNS issues persist, try: GRAPH_CRAWLER_DNS_SERVERS=8.8.8.8,8.8.4.4"
            )
        elif info.is_wsl:
            optimizations.append("Adaptive DNS for WSL")
            warnings.append(
                "WSL detected: Using adaptive DNS resolver. "
                "If DNS issues occur, try: GRAPH_CRAWLER_DNS_SERVERS=8.8.8.8,8.8.4.4"
            )
        elif info.is_android:
            optimizations.append("Adaptive DNS for Android")
        else:
            optimizations.append("Adaptive DNS resolver (universal)")

    # Event loop policy
    event_loop_policy = EventLoopPolicy.DEFAULT

    if info.is_windows:
        event_loop_policy = EventLoopPolicy.WINDOWS_SELECTOR
        optimizations.append("SelectorEventLoop for Windows")
    elif info.has_uvloop and not info.is_android:
        event_loop_policy = EventLoopPolicy.UVLOOP
        optimizations.append("uvloop enabled for faster event loop")

    # Concurrency calculation with override support
    concurrency, per_host = _calculate_concurrency(info)

    # Apply concurrency overrides (priority: kwargs > env > file > auto)
    env_concurrency = _get_env("CONCURRENCY")
    env_per_host = _get_env("PER_HOST_LIMIT")

    if concurrency_override:
        concurrency = concurrency_override
        optimizations.append(f"Concurrency override: {concurrency}")
    elif env_concurrency:
        concurrency = int(env_concurrency)
        optimizations.append(f"Concurrency from env: {concurrency}")
    elif file_config.get("concurrency"):
        concurrency = int(file_config["concurrency"])
        optimizations.append(f"Concurrency from config: {concurrency}")

    if per_host_override:
        per_host = per_host_override
    elif env_per_host:
        per_host = int(env_per_host)
    elif file_config.get("per_host_limit"):
        per_host = int(file_config["per_host_limit"])

    # TCP keepalive
    use_keepalive = not info.is_windows  # Windows has issues with keepalive
    if info.free_threading_enabled:
        use_keepalive = True
        optimizations.append("TCP keepalive for Python 3.14+ free-threading")

    # DNS cache and keepalive timeouts
    ttl_dns_cache = 300  # 5 minutes default
    keepalive_timeout = 30

    if info.free_threading_enabled:
        ttl_dns_cache = 600  # Longer cache for 3.14+
        keepalive_timeout = 60
        optimizations.append("Extended DNS cache and keepalive for Python 3.14+")

    if info.is_container:
        # Container environments usually have stable networking
        ttl_dns_cache = 120  # Shorter for containers (IPs may change)
        optimizations.append("Reduced DNS cache TTL for container environment")

    # Resource warnings
    if info.memory_available_gb < 1:
        warnings.append(
            f"Low memory detected ({info.memory_available_gb:.1f}GB available). "
            f"Concurrency limited to {concurrency} connections."
        )

    if info.cpu_cores < 2:
        warnings.append(
            f"Single CPU core detected. Performance may be limited. "
            f"Concurrency set to {concurrency}."
        )

    config = PlatformConfig(
        dns_resolver_type=dns_resolver_type,
        dns_nameservers=dns_nameservers,
        event_loop_policy=event_loop_policy,
        recommended_concurrency=concurrency,
        recommended_connections_per_host=per_host,
        use_tcp_keepalive=use_keepalive,
        connector_ttl_dns_cache=ttl_dns_cache,
        connector_keepalive_timeout=keepalive_timeout,
        warnings=warnings,
        optimizations=optimizations,
        platform_info=info,
    )

    logger.info(
        "Platform config: dns=%s, concurrency=%d, keepalive=%s, optimizations=%d",
        dns_resolver_type.value,
        concurrency,
        use_keepalive,
        len(optimizations),
    )

    for warning in warnings:
        logger.warning("Platform warning: %s", warning)

    return config


# Global cached config
_cached_config: Optional[PlatformConfig] = None


def get_cached_config() -> PlatformConfig:
    global _cached_config
    if _cached_config is None:
        _cached_config = get_optimized_config()
    return _cached_config
