"""System metrics collection module.

Collects runtime metrics for monitoring and optimization decisions.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from graph_crawler.shared.platform.detector import PlatformInfo, get_cached_platform_info

logger = logging.getLogger(__name__)


@dataclass
class SystemMetrics:
    """Runtime system metrics snapshot.
    
    Attributes:
        timestamp: When metrics were collected
        cpu_percent: Current CPU usage (0-100)
        memory_used_gb: Currently used memory in GB
        memory_available_gb: Available memory in GB
        memory_percent: Memory usage percentage
        disk_usage_percent: Disk usage percentage (optional)
        open_files: Number of open file descriptors (optional)
        threads_count: Number of active threads
        asyncio_tasks_count: Number of asyncio tasks (optional)
        network_connections: Number of network connections (optional)
        platform_info: Associated platform info
    """
    timestamp: datetime
    cpu_percent: float
    memory_used_gb: float
    memory_available_gb: float
    memory_percent: float
    disk_usage_percent: Optional[float]
    open_files: Optional[int]
    threads_count: int
    asyncio_tasks_count: Optional[int]
    network_connections: Optional[int]
    platform_info: PlatformInfo
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp.isoformat(),
            "cpu": {
                "percent": round(self.cpu_percent, 1),
            },
            "memory": {
                "used_gb": round(self.memory_used_gb, 2),
                "available_gb": round(self.memory_available_gb, 2),
                "percent": round(self.memory_percent, 1),
            },
            "disk": {
                "usage_percent": round(self.disk_usage_percent, 1) if self.disk_usage_percent else None,
            },
            "resources": {
                "open_files": self.open_files,
                "threads": self.threads_count,
                "asyncio_tasks": self.asyncio_tasks_count,
                "network_connections": self.network_connections,
            },
            "extra": self.extra,
        }

    def is_memory_critical(self, threshold_percent: float = 90.0) -> bool:
        return self.memory_percent >= threshold_percent

    def is_cpu_high(self, threshold_percent: float = 80.0) -> bool:
        return self.cpu_percent >= threshold_percent

    def should_reduce_concurrency(self) -> bool:
        """Check if system resources suggest reducing concurrency."""
        return self.is_memory_critical(85.0) or self.is_cpu_high(90.0)


def collect_system_metrics() -> SystemMetrics:
    """Collect current system metrics.
    
    Returns:
        SystemMetrics object with current values.
    
    Example:
        >>> metrics = collect_system_metrics()
        >>> if metrics.should_reduce_concurrency():
        ...     print("System under load, reducing concurrency")
    """
    platform_info = get_cached_platform_info()
    timestamp = datetime.now(timezone.utc)

    # Default values
    cpu_percent = 0.0
    memory_used_gb = 0.0
    memory_available_gb = platform_info.memory_available_gb
    memory_percent = 0.0
    disk_usage_percent = None
    open_files = None
    threads_count = 1
    asyncio_tasks_count = None
    network_connections = None

    # Try to get detailed metrics with psutil
    try:
        import psutil

        # CPU
        cpu_percent = psutil.cpu_percent(interval=0.1)

        # Memory
        mem = psutil.virtual_memory()
        memory_used_gb = (mem.total - mem.available) / (1024 ** 3)
        memory_available_gb = mem.available / (1024 ** 3)
        memory_percent = mem.percent

        # Disk
        try:
            disk = psutil.disk_usage("/")
            disk_usage_percent = disk.percent
        except Exception:
            pass

        # Process-specific metrics
        try:
            process = psutil.Process()
            open_files = len(process.open_files())
            threads_count = process.num_threads()

            # Network connections (may require elevated permissions)
            try:
                network_connections = len(process.net_connections() if hasattr(process, "net_connections") else process.connections())
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                pass
        except Exception:
            pass

    except ImportError:
        # Fallback without psutil
        import threading
        threads_count = threading.active_count()

        # Try to get memory from platform_info
        if platform_info.memory_total_gb > 0:
            memory_available_gb = platform_info.memory_available_gb
            memory_used_gb = platform_info.memory_total_gb - memory_available_gb
            memory_percent = (memory_used_gb / platform_info.memory_total_gb) * 100

    # Try to get asyncio tasks count
    try:
        import asyncio
        try:
            loop = asyncio.get_running_loop()
            asyncio_tasks_count = len(asyncio.all_tasks(loop))
        except RuntimeError:
            # No running event loop
            pass
    except Exception:
        pass

    metrics = SystemMetrics(
        timestamp=timestamp,
        cpu_percent=cpu_percent,
        memory_used_gb=memory_used_gb,
        memory_available_gb=memory_available_gb,
        memory_percent=memory_percent,
        disk_usage_percent=disk_usage_percent,
        open_files=open_files,
        threads_count=threads_count,
        asyncio_tasks_count=asyncio_tasks_count,
        network_connections=network_connections,
        platform_info=platform_info,
    )

    logger.debug(
        "System metrics: CPU=%.1f%%, Memory=%.1f%% (%.1fGB available), Threads=%d",
        metrics.cpu_percent,
        metrics.memory_percent,
        metrics.memory_available_gb,
        metrics.threads_count,
    )

    return metrics


class MetricsCollector:
    """Continuous metrics collector with history.
    
    Example:
        >>> collector = MetricsCollector(max_history=100)
        >>> collector.collect()  # Collect current metrics
        >>> collector.collect()  # Collect again
        >>> print(collector.get_average_cpu())
        45.5
    """

    def __init__(self, max_history: int = 100):
        """Initialize collector.
        
        Args:
            max_history: Maximum number of metrics snapshots to keep.
        """
        self.max_history = max_history
        self.history: list[SystemMetrics] = []
        self._last_collection_time: float = 0
        self._min_interval: float = 1.0  # Minimum seconds between collections

    def collect(self, force: bool = False) -> SystemMetrics:
        """Collect and store metrics.
        
        Args:
            force: Force collection even if min_interval hasn't passed.
        
        Returns:
            Collected SystemMetrics.
        """
        current_time = time.time()

        # Rate limiting
        if not force and (current_time - self._last_collection_time) < self._min_interval:
            if self.history:
                return self.history[-1]

        metrics = collect_system_metrics()
        self.history.append(metrics)
        self._last_collection_time = current_time

        # Trim history
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]

        return metrics

    def get_latest(self) -> Optional[SystemMetrics]:
        return self.history[-1] if self.history else None

    def get_average_cpu(self) -> float:
        if not self.history:
            return 0.0
        return sum(m.cpu_percent for m in self.history) / len(self.history)

    def get_average_memory_percent(self) -> float:
        if not self.history:
            return 0.0
        return sum(m.memory_percent for m in self.history) / len(self.history)

    def get_peak_memory_gb(self) -> float:
        if not self.history:
            return 0.0
        return max(m.memory_used_gb for m in self.history)

    def get_summary(self) -> dict:
        if not self.history:
            return {"samples": 0}

        return {
            "samples": len(self.history),
            "time_range_seconds": (
                self.history[-1].timestamp - self.history[0].timestamp
            ).total_seconds() if len(self.history) > 1 else 0,
            "cpu": {
                "average": round(self.get_average_cpu(), 1),
                "peak": round(max(m.cpu_percent for m in self.history), 1),
            },
            "memory": {
                "average_percent": round(self.get_average_memory_percent(), 1),
                "peak_gb": round(self.get_peak_memory_gb(), 2),
            },
        }

    def clear(self) -> None:
        self.history.clear()
        self._last_collection_time = 0


# Global metrics collector instance
_global_collector: Optional[MetricsCollector] = None


def get_global_collector() -> MetricsCollector:
    global _global_collector
    if _global_collector is None:
        _global_collector = MetricsCollector()
    return _global_collector
