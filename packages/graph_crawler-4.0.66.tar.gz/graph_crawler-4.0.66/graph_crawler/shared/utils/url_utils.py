"""Утіліти для роботи з URL.

Python 3.14+:
- @lru_cache для normalize_url(), get_domain(), is_valid_url()
- _parse_url_cached() для кешування urlparse
- Прискорення ~5x для повторних URL (типово 60-80% cache hit rate)
- Автоматична інтеграція з Cython native функціями (якщо доступні)

Очищення кешів:
- clear_url_caches() після завершення краулінгу запобігає витоку пам'яті
  при краулінгу великої кількості URL

URL Resolution Intelligence:
- Smart overlap detection для уникнення подвійних сегментів
- Підтримка різних framework-ів (React Router, Vue Router, Next.js, тощо)
- Контекстно-залежне визначення правильного шляху
"""
from __future__ import annotations

import re
from functools import lru_cache
from urllib.parse import urljoin, urlparse, urlunparse

from graph_crawler.shared.exceptions import InvalidURLError

# Pre-compiled regex для нормалізації подвійних сегментів URL
# Патерн: /segment/segment/ -> /segment/
_DOUBLE_SEGMENT_RE = re.compile(r'/([^/?#]+)/\1/')

# Regex для знаходження повторюваних мульти-сегментних патернів
# Наприклад: /jobs/results/jobs/results/ -> /jobs/results/
# Патерн: (група з 1-5 сегментів)(та сама група повторюється)
_MULTI_SEGMENT_DUPLICATE_RE = re.compile(r'((?:/[^/?#]+){1,5})\1')


def _find_path_overlap(base_path: str, relative_path: str) -> int:
    """
    Знаходить overlap між кінцем base_path та початком relative_path.
    
    Це вирішує проблему коли:
    - base_path: /about/careers/applications/jobs/results/
    - relative_path: jobs/results/74102020973175494-...
    - Overlap: "jobs/results/" - потрібно видалити з relative_path
    
    Args:
        base_path: Шлях з base URL (з trailing slash)
        relative_path: Відносний шлях (без leading slash)
        
    Returns:
        Кількість символів overlap в relative_path (0 якщо немає)
    """
    if not base_path or not relative_path:
        return 0
    
    # Нормалізуємо base_path - видаляємо leading slash для порівняння
    base_segments = [s for s in base_path.split('/') if s]
    if not base_segments:
        return 0
    
    # Розбиваємо relative_path на сегменти
    rel_parts = relative_path.split('/')
    rel_segments = [s for s in rel_parts if s and '?' not in s and '#' not in s]
    
    if not rel_segments:
        return 0
    
    # Шукаємо найдовший overlap
    # Перебираємо suffix'и base_path і перевіряємо чи вони є prefix'ом relative_path
    max_overlap_segments = min(len(base_segments), len(rel_segments))
    
    for overlap_len in range(max_overlap_segments, 0, -1):
        # Беремо останні overlap_len сегментів з base_path
        base_suffix = base_segments[-overlap_len:]
        # Беремо перші overlap_len сегментів з relative_path
        rel_prefix = rel_segments[:overlap_len]
        
        if base_suffix == rel_prefix:
            # Знайшли overlap! Рахуємо кількість символів для видалення
            # Потрібно видалити prefix з relative_path
            overlap_str = '/'.join(rel_prefix) + '/'
            return len(overlap_str)
    
    return 0


def _normalize_duplicated_path_segments(path: str) -> str:
    """
    Видаляє повторювані послідовності сегментів з шляху.
    
    Обробляє випадки:
    - /jobs/jobs/ -> /jobs/
    - /jobs/results/jobs/results/ -> /jobs/results/
    - /a/b/c/a/b/c/d -> /a/b/c/d
    
    Args:
        path: URL path для нормалізації
        
    Returns:
        Нормалізований path без дублікатів
    """
    if not path:
        return path
    
    # Крок 1: Видаляємо прості подвійні сегменти (/jobs/jobs/)
    normalized = _DOUBLE_SEGMENT_RE.sub(r'/\1/', path)
    
    # Крок 2: Видаляємо мульти-сегментні дублікати (/jobs/results/jobs/results/)
    # Повторюємо поки є зміни (може бути кілька рівнів дублікатів)
    prev = None
    max_iterations = 10  # Захист від infinite loop
    iteration = 0
    while prev != normalized and iteration < max_iterations:
        prev = normalized
        # Шукаємо патерн де група сегментів повторюється
        match = _MULTI_SEGMENT_DUPLICATE_RE.search(normalized)
        if match:
            # Видаляємо перше входження дублікату
            normalized = normalized[:match.start()] + match.group(1) + normalized[match.end():]
        iteration += 1
    
    return normalized


# Кеш для urlparse - найчастіша операція
# maxsize=50000 ≈ 5MB RAM для типового краулінгу
@lru_cache(maxsize=50000)
def _parse_url_cached(url: str) -> tuple[str, str, str, str, str, str]:
    """
    Кешований urlparse.

    Повертає tuple замість ParseResult для сумісності з lru_cache.
    Типовий cache hit rate: 60-80% (багато посилань на ті самі домени).

    Args:
        url: URL для парсингу

    Returns:
        Tuple (scheme, netloc, path, params, query, fragment)
    """
    parsed = urlparse(url)
    return (
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        parsed.params,
        parsed.query,
        parsed.fragment,
    )


class URLUtils:
    """
    Допоміжні функції для роботи з URL.

    Кешування urlparse результатів забезпечує ~5x прискорення.
    Швидка валідація через startswith() перед urlparse.
    Batch операції для списків URL.
    Автоматична інтеграція з Cython native.
    """

    # Префікси для швидкої перевірки (без urlparse)
    _VALID_SCHEMES = ("http://", "https://")
    _SPECIAL_PREFIXES = ("mailto:", "javascript:", "tel:", "#", "data:")

    @staticmethod
    @lru_cache(maxsize=50000)
    def normalize_url(url: str) -> str:
        """
        Нормалізує URL (видаляє фрагменти).

        Кешується для повторних URL.

        Args:
            url: URL для нормалізації

        Returns:
            Нормалізований URL
        """
        scheme, netloc, path, params, query, _ = _parse_url_cached(url)
        # Видаляємо fragment (#...)
        return urlunparse((scheme, netloc, path, params, query, ""))

    @staticmethod
    @lru_cache(maxsize=100000)
    def make_absolute(base_url: str, relative_url: str) -> str:
        """
        Перетворює відносний URL на абсолютний з інтелектуальним визначенням overlap.

        Результат кешується для повторних комбінацій.
        
        IMPROVED: Інтелектуальне визначення overlap між base_url та relative_url.
        Вирішує проблеми з modern SPA frameworks (React Router, Vue Router, Next.js):
        
        Приклад проблеми:
        - base_url: https://google.com/about/careers/applications/jobs/results/?page=1
        - relative_url: jobs/results/74102020973175494-data-center-lead
        - Стандартний urljoin: .../jobs/results/jobs/results/74102020973175494-... (НЕПРАВИЛЬНО!)
        - Наша логіка: .../jobs/results/74102020973175494-... (ПРАВИЛЬНО!)

        Args:
            base_url: Базовий URL
            relative_url: Відносний URL

        Returns:
            Абсолютний URL без подвійних сегментів
        """
        # Fast path: якщо вже абсолютний
        if relative_url.startswith(("http://", "https://")):
            return relative_url
        
        # Fast path: якщо relative починається з /
        if relative_url.startswith('/'):
            result = urljoin(base_url, relative_url)
            return URLUtils._normalize_result_path(result)
        
        # Парсимо base_url для отримання path
        base_parsed = urlparse(base_url)
        base_path = base_parsed.path
        
        # ВАЖЛИВО: Для коректного urljoin потрібно додати trailing slash до base_url,
        # якщо path не закінчується на / і relative_url не починається з /
        # Це імітує поведінку браузера при резолвінгу href
        effective_base_url = base_url
        if base_path and not base_path.endswith('/') and not relative_url.startswith('/'):
            # Знаходимо позицію query string або fragment
            query_pos = base_url.find('?')
            fragment_pos = base_url.find('#')
            
            if query_pos > 0 or fragment_pos > 0:
                # Є query або fragment - вставляємо / перед ними
                insert_pos = query_pos if query_pos > 0 else fragment_pos
                if fragment_pos > 0 and (query_pos < 0 or fragment_pos < query_pos):
                    insert_pos = fragment_pos
                effective_base_url = base_url[:insert_pos] + '/' + base_url[insert_pos:]
            else:
                # Немає query/fragment - просто додаємо / в кінець
                effective_base_url = base_url + '/'
        
        # Стандартний urljoin з ефективним base URL
        result = urljoin(effective_base_url, relative_url)
        
        # POST-PROCESSING: Нормалізуємо результат на випадок подвійних сегментів
        return URLUtils._normalize_result_path(result)
    
    @staticmethod
    def _normalize_result_path(url: str) -> str:
        """
        Нормалізує path в URL, видаляючи подвійні сегменти.
        
        Args:
            url: Повний URL
            
        Returns:
            URL з нормалізованим path
        """
        # Знаходимо початок path (після scheme://domain)
        path_start = url.find('/', 8)  # Пропускаємо https://
        if path_start <= 0:
            return url
        
        # Знаходимо кінець path (до query або fragment)
        query_start = url.find('?', path_start)
        fragment_start = url.find('#', path_start)
        
        if query_start > 0 and fragment_start > 0:
            path_end = min(query_start, fragment_start)
        elif query_start > 0:
            path_end = query_start
        elif fragment_start > 0:
            path_end = fragment_start
        else:
            path_end = len(url)
        
        # Витягуємо та нормалізуємо path
        path_part = url[path_start:path_end]
        normalized_path = _normalize_duplicated_path_segments(path_part)
        
        if normalized_path != path_part:
            return url[:path_start] + normalized_path + url[path_end:]
        
        return url

    @staticmethod
    @lru_cache(maxsize=50000)
    def get_domain(url: str) -> str | None:
        """
        Витягує домен з URL.

        Кешується для повторних URL.
        """
        _, netloc, _, _, _, _ = _parse_url_cached(url)
        return netloc if netloc else None

    @staticmethod
    @lru_cache(maxsize=50000)
    def get_root_domain(url: str) -> str | None:
        """
        Витягує root домен з URL (без www. префіксу).

        Корисно для коректного визначення субдоменів:
        - www.ciklum.com -> ciklum.com
        - jobs.ciklum.com -> ciklum.com
        - ciklum.com -> ciklum.com

        Видаляє тільки www. префікс, інші субдомени залишає.
        Кешується для повторних URL.

        Args:
            url: URL для парсингу

        Returns:
            Root домен
        """
        domain = URLUtils.get_domain(url)
        if domain and domain.startswith("www."):
            return domain[4:]  # Видаляємо 'www.'
        return domain

    @staticmethod
    @lru_cache(maxsize=50000)
    def is_valid_url(url: str) -> bool:
        """
        Перевіряє чи URL валідний.

        Швидка перевірка startswith() перед urlparse.
        Результати кешуються.

        Args:
            url: URL для перевірки

        Returns:
            True якщо URL валідний
        """
        # Швидка перевірка без urlparse
        if not url or not url.startswith(URLUtils._VALID_SCHEMES):
            return False

        # Перевіряємо наявність домену
        try:
            _, netloc, _, _, _, _ = _parse_url_cached(url)
            return bool(netloc)
        except Exception:
            return False

    @staticmethod
    def is_special_link(href: str) -> bool:
        """
        Перевіряє чи це спеціальне посилання (mailto, javascript, тощо).

        Використовує tuple startswith (C-level).

        Args:
            href: URL або href для перевірки

        Returns:
            True якщо спеціальне посилання
        """
        return href.startswith(URLUtils._SPECIAL_PREFIXES)

    @staticmethod
    def validate_url(url: str) -> str:
        """
        Валідує URL і повертає його, або викидає InvalidURLError.

        Args:
            url: URL для валідації

        Returns:
            Валідний URL

        Raises:
            InvalidURLError: Якщо URL невалідний
        """
        if not url:
            raise InvalidURLError("URL cannot be empty")

        if not url.startswith(("http://", "https://")):
            raise InvalidURLError(f"URL must start with http:// or https://, got: {url}")

        try:
            parsed = urlparse(url)
            if not parsed.netloc:
                raise InvalidURLError(f"URL must have a valid domain: {url}")
            return url
        except Exception as e:
            if isinstance(e, InvalidURLError):
                raise
            raise InvalidURLError(f"Invalid URL format: {url}") from e

    @staticmethod
    def clean_urls(urls: list[str]) -> list[str]:
        """
        Очищує список URL (видаляє дублікати, невалідні).

        dict.fromkeys() забезпечує O(1) дедуплікацію зі збереженням порядку.

        Args:
            urls: Список URL

        Returns:
            Очищений список унікальних валідних URL
        """
        return list(
            dict.fromkeys(URLUtils.normalize_url(url) for url in urls if URLUtils.is_valid_url(url))
        )

    @staticmethod
    def clean_urls_batch(urls: list[str]) -> list[str]:
        """
        Batch версія clean_urls з використанням native функцій.

        Використовує Cython native функції якщо доступні.

        Args:
            urls: Список URL

        Returns:
            Очищений список URL
        """
        try:
            from graph_crawler.native import filter_valid_urls, normalize_urls

            # Використовуємо native batch функції
            valid_urls = filter_valid_urls(urls)
            normalized_urls = normalize_urls(valid_urls)

            # Дедуплікація
            return list(dict.fromkeys(normalized_urls))
        except ImportError:
            # Fallback на стандартну версію
            return URLUtils.clean_urls(urls)

    # SECURITY: URL Input Sanitization
    # Заборонені схеми (можуть бути небезпечними)
    _DANGEROUS_SCHEMES = (
        "javascript:",
        "vbscript:",
        "data:",
        "file:",
        "ftp:",
        "gopher:",
        "ldap:",
        "telnet:",
    )

    # Максимальна довжина URL (захист від DoS)
    _MAX_URL_LENGTH = 8192

    # Заборонені символи в URL
    _DANGEROUS_CHARS = ("\x00", "\n", "\r", "\t", "<", ">", '"', "'", "`")

    # Приватні IP діапазони (SSRF protection)
    _PRIVATE_IP_PREFIXES = (
        "127.",
        "10.",
        "192.168.",
        "172.16.",
        "172.17.",
        "172.18.",
        "172.19.",
        "172.20.",
        "172.21.",
        "172.22.",
        "172.23.",
        "172.24.",
        "172.25.",
        "172.26.",
        "172.27.",
        "172.28.",
        "172.29.",
        "172.30.",
        "172.31.",
        "169.254.",  # Link-local
        "0.0.0.0",
        "0.",
        "localhost",
        "[::1]",
        "[::]",
    )

    @staticmethod
    def sanitize_url(url: str, allow_private_ips: bool = False) -> str | None:
        """
        Безпечна санітизація URL для захисту від атак.

        Args:
            url: URL для санітизації
            allow_private_ips: Дозволити приватні IP (за замовчуванням False)
        Returns:
            Санітизований URL або None якщо URL небезпечний
        Example:
            >>> URLUtils.sanitize_url("https://example.com/page")
            'https://example.com/page'
            >>> URLUtils.sanitize_url("javascript:alert(1)")
            None
            >>> URLUtils.sanitize_url("http://127.0.0.1/admin")
            None  # SSRF protection
        """
        if not url:
            return None

        # Trim whitespace
        url = url.strip()

        # Перевірка довжини (DoS protection)
        if len(url) > URLUtils._MAX_URL_LENGTH:
            return None

        # Перевірка на небезпечні символи
        url_lower = url.lower()
        for char in URLUtils._DANGEROUS_CHARS:
            if char in url:
                return None

        # Перевірка на небезпечні схеми
        for scheme in URLUtils._DANGEROUS_SCHEMES:
            if url_lower.startswith(scheme):
                return None

        # Перевірка на валідну схему
        if not url_lower.startswith(("http://", "https://")):
            return None

        # SSRF protection: перевірка на приватні IP
        if not allow_private_ips:
            try:
                domain = URLUtils.get_domain(url)
                if domain:
                    domain_lower = domain.lower()
                    for prefix in URLUtils._PRIVATE_IP_PREFIXES:
                        if domain_lower.startswith(prefix):
                            return None
            except Exception:
                return None

        # URL пройшов всі перевірки
        return url

    @staticmethod
    def sanitize_urls_batch(urls: list[str], allow_private_ips: bool = False) -> list[str]:
        """
        Batch санітизація списку URL.

        Args:
            urls: Список URL для санітизації
            allow_private_ips: Дозволити приватні IP

        Returns:
            Список безпечних URL
        """
        return [
            sanitized
            for url in urls
            if (sanitized := URLUtils.sanitize_url(url, allow_private_ips)) is not None
        ]

    @staticmethod
    def clear_caches() -> None:
        """
        Очищає всі lru_cache для звільнення пам'яті.

        Викликайте після завершення краулінгу для запобігання витоку пам'яті.

        Example:
            >>> # Після завершення краулінгу
            >>> URLUtils.clear_caches()
        """
        _parse_url_cached.cache_clear()
        URLUtils.normalize_url.cache_clear()
        URLUtils.make_absolute.cache_clear()
        URLUtils.get_domain.cache_clear()
        URLUtils.get_root_domain.cache_clear()
        URLUtils.is_valid_url.cache_clear()

    @staticmethod
    def is_safe_redirect(original_url: str, redirect_url: str) -> bool:
        """
        Перевіряє чи redirect URL безпечний (той самий домен).

        Захищає від Open Redirect вразливостей.

        Args:
            original_url: Оригінальний URL
            redirect_url: URL редіректу

        Returns:
            True якщо redirect безпечний (той самий домен)
        """
        if not redirect_url:
            return False

        # Санітизуємо redirect URL
        if not URLUtils.sanitize_url(redirect_url):
            return False

        # Порівнюємо домени
        original_domain = URLUtils.get_root_domain(original_url)
        redirect_domain = URLUtils.get_root_domain(redirect_url)

        if not original_domain or not redirect_domain:
            return False

        return original_domain == redirect_domain
