"""Base classes for CAPTCHA bypass."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class BypassStrategy(str, Enum):
    """Стратегії обходу CAPTCHA."""

    COOKIE_PERSISTENCE = "cookie_persistence"  # Зберігання cookies
    SESSION_REUSE = "session_reuse"  # Переіспользування сесій
    DELAY_STRATEGY = "delay_strategy"  # Очікування
    ALTERNATIVE_ENDPOINTS = "alternative_endpoints"  # Альтернативні endpoints
    ROTATING = "rotating"  # Ротація різних стратегій


class BypassResult(str, Enum):
    """Результати спроби обходу."""

    SUCCESS = "success"  # Успішно обійшли
    FAILED = "failed"  # Не вдалося обійти
    CAPTCHA_STILL_PRESENT = "captcha_still_present"  # CAPTCHA все ще є
    RETRY_NEEDED = "retry_needed"  # Потрібна повторна спроба


@dataclass(slots=True)
class BypassAttempt:
    """Результат спроби обходу CAPTCHA."""

    strategy: BypassStrategy
    result: BypassResult
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    response_status: int | None = None
    response_time: float | None = None
    error_message: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SessionInfo:
    """Інформація про збережену сесію."""

    url: str
    cookies: dict[str, str]
    headers: dict[str, str]
    created_at: datetime
    last_used: datetime
    success_count: int = 0
    failure_count: int = 0

    def is_expired(self, max_age_hours: int = 24) -> bool:
        """Перевірка чи сесія прострочена."""
        age = datetime.now(timezone.utc) - self.created_at
        return age > timedelta(hours=max_age_hours)

    @property
    def success_rate(self) -> float:
        """Відсоток успішних запитів."""
        total = self.success_count + self.failure_count
        if total == 0:
            return 0.0
        return (self.success_count / total) * 100

    def to_dict(self) -> dict[str, Any]:
        return {
            "url": self.url,
            "cookies": self.cookies,
            "headers": self.headers,
            "created_at": self.created_at.isoformat(),
            "last_used": self.last_used.isoformat(),
            "success_count": self.success_count,
            "failure_count": self.failure_count,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SessionInfo":
        return cls(
            url=data["url"],
            cookies=data["cookies"],
            headers=data["headers"],
            created_at=datetime.fromisoformat(data["created_at"]),
            last_used=datetime.fromisoformat(data["last_used"]),
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
        )
