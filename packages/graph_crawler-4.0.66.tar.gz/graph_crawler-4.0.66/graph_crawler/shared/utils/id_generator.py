"""Централізована генерація ID для Graph Crawler.

Використовує XXH3_64 для максимальної швидкості:
- ~5M ops/sec (в 15x швидше за UUID v5)
- Детермінований: той самий input = той самий ID
- Collision boundary: ~2³² ≈ 4 млрд записів

Output формат: str (hex representation of int64)
- Сумісність з існуючою інфраструктурою (VARCHAR в БД)
- Легка міграція на BIGINT в майбутньому

Benchmark:
- XXH3_64:  0.020s / 100k ops (~5M ops/sec)
- UUID v5:  0.295s / 100k ops (~340k ops/sec)
"""
from __future__ import annotations

from typing import Final, Iterator

__all__ = [
    "generate_node_id",
    "generate_edge_id",
    "generate_node_id_int",
    "generate_edge_id_int",
    "IdGenerator",
    "get_id_generator_info",
]

# Namespace prefixes (для детермінованості та уникнення колізій між типами)
_NAMESPACE_NODE: Final[bytes] = b"gc:n:"
_NAMESPACE_EDGE: Final[bytes] = b"gc:e:"

# XXH3_64 - найшвидший сучасний non-crypto hash
try:
    from xxhash import xxh3_64
    _BACKEND = "xxh3_64"
except ImportError:
    # Fallback якщо xxhash не встановлено
    import hashlib
    
    class _XXH3Fallback:
        """Fallback на SHA-1 з обрізанням до 64 біт."""
        __slots__ = ('_data',)
        
        def __init__(self, data: bytes):
            self._data = data
            
        def intdigest(self) -> int:
            h = hashlib.sha1(self._data, usedforsecurity=False).digest()
            return int.from_bytes(h[:8], 'big')
    
    def xxh3_64(data: bytes) -> _XXH3Fallback:
        return _XXH3Fallback(data)
    
    _BACKEND = "sha1_fallback"


# ============================================================================
# PUBLIC API - String output (для сумісності з існуючою інфраструктурою)
# ============================================================================

def generate_node_id(url: str) -> str:
    """Генерує детермінований Node ID на основі URL.
    
    Args:
        url: URL веб-сторінки
        
    Returns:
        str: 16-char hex string (64-bit hash)
        
    Example:
        >>> generate_node_id("https://example.com")
        '4d0b7b8f1a2b3c4d'
        
    Performance:
        ~5M ops/sec
    """
    h = xxh3_64(_NAMESPACE_NODE + url.encode()).intdigest()
    return format(h, '016x')


def generate_edge_id(source_node_id: str, target_node_id: str, anchor_hash: int = 0) -> str:
    """Генерує детермінований Edge ID.
    
    Args:
        source_node_id: ID вузла-джерела
        target_node_id: ID вузла-цілі
        anchor_hash: hash(anchor_text) для унікальності
        
    Returns:
        str: 16-char hex string
        
    Performance:
        ~5M ops/sec
    """
    key = f"{source_node_id}:{target_node_id}:{anchor_hash}"
    h = xxh3_64(_NAMESPACE_EDGE + key.encode()).intdigest()
    return format(h, '016x')


# ============================================================================
# INT API - для прямого використання з BIGINT в PostgreSQL (майбутнє)
# ============================================================================

def generate_node_id_int(url: str) -> int:
    """Генерує Node ID як int64 (для BIGINT в PostgreSQL).
    
    Returns:
        int: unsigned 64-bit integer
    """
    return xxh3_64(_NAMESPACE_NODE + url.encode()).intdigest()


def generate_edge_id_int(source_node_id: int, target_node_id: int, anchor_hash: int = 0) -> int:
    """Генерує Edge ID як int64.
    
    Args:
        source_node_id: int64 node ID
        target_node_id: int64 node ID
        anchor_hash: anchor hash
        
    Returns:
        int: unsigned 64-bit integer
    """
    data = (
        _NAMESPACE_EDGE +
        source_node_id.to_bytes(8, 'big', signed=False) +
        target_node_id.to_bytes(8, 'big', signed=False) +
        anchor_hash.to_bytes(8, 'big', signed=True)
    )
    return xxh3_64(data).intdigest()


# ============================================================================
# BATCH GENERATOR - для обробки великих обсягів
# ============================================================================

class IdGenerator:
    """Batch генератор ID з оптимізаціями для великих обсягів.
    
    Example:
        >>> gen = IdGenerator()
        >>> 
        >>> # Batch генерація node IDs
        >>> for url, node_id in gen.node_ids(urls):
        ...     print(f"{url} -> {node_id}")
    """
    
    __slots__ = ()
    
    @staticmethod
    def node_ids(urls: list[str]) -> Iterator[tuple[str, str]]:
        """Генератор для batch генерації node IDs.
        
        Yields:
            Tuple[str, str]: (url, node_id)
        """
        prefix = _NAMESPACE_NODE
        for url in urls:
            h = xxh3_64(prefix + url.encode()).intdigest()
            yield url, format(h, '016x')
    
    @staticmethod
    def edge_ids(edges: list[tuple[str, str, int]]) -> Iterator[tuple[str, str, str]]:
        """Генератор для batch генерації edge IDs.
        
        Args:
            edges: List of (source_id, target_id, anchor_hash)
            
        Yields:
            Tuple[str, str, str]: (source_id, target_id, edge_id)
        """
        prefix = _NAMESPACE_EDGE
        for source_id, target_id, anchor_hash in edges:
            key = f"{source_id}:{target_id}:{anchor_hash}"
            h = xxh3_64(prefix + key.encode()).intdigest()
            yield source_id, target_id, format(h, '016x')
    
    @staticmethod  
    def node_id(url: str) -> str:
        return generate_node_id(url)
    
    @staticmethod
    def edge_id(source_id: str, target_id: str, anchor_hash: int = 0) -> str:
        return generate_edge_id(source_id, target_id, anchor_hash)


def get_id_generator_info() -> dict:
    """Інформація про поточний backend."""
    return {
        "backend": _BACKEND,
        "output_format": "16-char hex string",
        "output_bits": 64,
        "speed_estimate": "~5M ops/sec" if _BACKEND == "xxh3_64" else "~2M ops/sec",
        "collision_boundary": "~4 billion records",
        "deterministic": True,
        "db_compatible": "VARCHAR(16) or BIGINT",
    }
