"""Markdown AST (MDAST) — проміжне представлення між HTML та Markdown.

Inspired by ``html-to-markdown v2`` / ``mdast``. Конвертер будує дерево
``Document → Block → Inline``, потім ``MarkdownRenderer`` серіалізує його
у Markdown-рядок з контекстно-чутливим екрануванням (P1.12), bullet
cycling (P1.11) та підтримкою task-lists/strikethrough (P1.10).

Етап 7.1 (P1) з ``docs/md_generator_analysis/README.md``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional, Union


# ──────────────────────────────────────────────────────────────────────────
#  Inline-вузли
# ──────────────────────────────────────────────────────────────────────────


@dataclass
class Text:
    """Текстовий inline-вузол.

    Якщо ``raw=True``, текст вже містить готову Markdown-розмітку
    (``**bold**``, ``[txt](url)``, ``"  \\n"`` hard break, ``\\|``-escaped
    pipes тощо) і renderer його НЕ екранує. Це дозволяє поетапно мігрувати
    з legacy regex-пайплайна без зміни байтового виводу.
    """

    value: str
    raw: bool = False


@dataclass
class Link:
    href: str
    children: list["Inline"]
    title: str = ""


@dataclass
class Image:
    src: str
    alt: str = ""
    title: str = ""


Inline = Union[Text, Link, Image]


# ──────────────────────────────────────────────────────────────────────────
#  Block-вузли
# ──────────────────────────────────────────────────────────────────────────


@dataclass
class Heading:
    level: int  # 1..6
    children: list[Inline]


@dataclass
class Paragraph:
    children: list[Inline]


@dataclass
class ListItem:
    children: list["Block"]
    # ``None`` → звичайний li, ``True/False`` → GFM task-list (P1.10)
    checked: Optional[bool] = None


@dataclass
class List:
    ordered: bool
    items: list[ListItem]
    tight: bool = True


@dataclass
class CodeBlock:
    code: str
    lang: str = ""


@dataclass
class Blockquote:
    children: list["Block"]


@dataclass
class TableCell:
    children: list[Inline]
    colspan: int = 1
    rowspan: int = 1
    is_header: bool = False


@dataclass
class TableRow:
    cells: list[TableCell]


@dataclass
class Table:
    rows: list[TableRow]
    alignments: list[Optional[Literal["left", "right", "center"]]] = field(
        default_factory=list
    )
    caption: str = ""


@dataclass
class ThematicBreak:
    """``<hr>`` → ``---`` (P0.4)."""

    pass


@dataclass
class HtmlRaw:
    """Відновлений сирий Markdown-фрагмент (наприклад, image inline)."""

    markdown: str


Block = Union[
    Heading,
    Paragraph,
    List,
    CodeBlock,
    Blockquote,
    Table,
    ThematicBreak,
    HtmlRaw,
]


@dataclass
class Document:
    children: list[Block]
