"""Базова абстракція для HTML адаптерів.

Визначає інтерфейс для роботи з різними HTML парсерами через уніфікований API.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Iterator


@dataclass
class HTMLElement:
    """Уніфікований wrapper для HTML елемента.
    
    Обгортає елементи різних парсерів (BeautifulSoup, Selectolax)
    в єдиний інтерфейс для зручної роботи.
    
    Attributes:
        tag_name: Назва HTML тегу (наприклад, 'div', 'p', 'a')
        native: Оригінальний об'єкт з парсера (для доступу до специфічних методів)
        adapter: Посилання на адаптер що створив цей елемент
    """
    
    tag_name: str
    native: Any  # BeautifulSoup Tag або Selectolax Node
    adapter: BaseHTMLAdapter
    
    def get_text(self, strip: bool = True, separator: str = ' ') -> str:
        """Отримує текстовий контент елемента.
        
        Args:
            strip: Чи очищати пробіли на початку/кінці
            separator: Роздільник між текстовими вузлами
            
        Returns:
            Текстовий контент
        """
        return self.adapter.get_text(self.native, strip=strip, separator=separator)
    
    def get_attribute(self, name: str, default: str = '') -> str:
        """Отримує значення атрибута.
        
        Args:
            name: Назва атрибута (наприклад, 'href', 'src', 'class')
            default: Значення за замовчуванням якщо атрибут відсутній
            
        Returns:
            Значення атрибута або default
        """
        return self.adapter.get_attribute(self.native, name, default)
    
    def find_children(self, tag_names: list[str] | None = None, recursive: bool = True) -> list[HTMLElement]:
        """Знаходить дочірні елементи.
        
        Args:
            tag_names: Список назв тегів для фільтрації (None = всі)
            recursive: Шукати рекурсивно або тільки прямих дітей
            
        Returns:
            Список дочірніх елементів
        """
        return self.adapter.find_children(self.native, tag_names, recursive)
    
    def has_children(self, tag_names: list[str]) -> bool:
        """Перевіряє наявність дочірніх елементів з певними тегами.
        
        Args:
            tag_names: Список назв тегів для перевірки
            
        Returns:
            True якщо є хоча б один дочірній елемент з цими тегами
        """
        return len(self.find_children(tag_names, recursive=False)) > 0
    
    def get_html(self) -> str:
        """Отримує HTML представлення елемента.
        
        Returns:
            HTML string
        """
        return self.adapter.get_html(self.native)
    
    def iter_descendants(self) -> Iterator[HTMLElement]:
        """Ітерує по всіх нащадках (descendants) в порядку появи в DOM.
        
        Yields:
            HTMLElement об'єкти для кожного нащадка
        """
        return self.adapter.iter_descendants(self.native)

    def iter_direct_children_mixed(self) -> Iterator[tuple[str, Any]]:
        """Ітерує по ПРЯМИХ дітях, включаючи текстові вузли.

        Делегує до ``adapter.iter_direct_children_mixed``. Призначено для
        обробки mixed content: текст + inline-теги + block-теги в одному
        контейнері (типовий патерн bootstrap-карток).

        Yields:
            tuple[kind, value] — див. ``BaseHTMLAdapter.iter_direct_children_mixed``.
        """
        return self.adapter.iter_direct_children_mixed(self.native)

    @property
    def native_id(self) -> int:
        """Стабільний ідентифікатор DOM-вузла.

        Працює коректно навіть коли парсер (наприклад, Selectolax) створює
        нові Python-обгортки для того самого C-вузла при кожному обході.
        Для BS4 повертає ``id()``, для Selectolax — ``mem_id``.
        """
        return self.adapter.get_native_id(self.native)


class BaseHTMLAdapter(ABC):
    """Базовий клас для HTML адаптерів.
    
    Визначає уніфікований інтерфейс для роботи з різними HTML парсерами.
    Реалізації повинні перетворювати специфічні API парсерів в єдиний формат.
    """
    
    @abstractmethod
    def get_root(self) -> HTMLElement:
        """Отримує кореневий елемент документа.
        
        Returns:
            HTMLElement для кореня (зазвичай <body> або <html>)
        """
        pass
    
    @abstractmethod
    def get_tag_name(self, element: Any) -> str:
        """Отримує назву тегу елемента.
        
        Args:
            element: Нативний об'єкт елемента з парсера
            
        Returns:
            Назва тегу в нижньому регістрі (наприклад, 'div', 'p')
        """
        pass
    
    @abstractmethod
    def get_text(self, element: Any, strip: bool = True, separator: str = ' ') -> str:
        """Отримує текстовий контент елемента.
        
        Args:
            element: Нативний об'єкт елемента
            strip: Чи очищати пробіли
            separator: Роздільник між текстовими вузлами
            
        Returns:
            Текстовий контент
        """
        pass
    
    @abstractmethod
    def get_attribute(self, element: Any, name: str, default: str = '') -> str:
        """Отримує значення атрибута елемента.
        
        Args:
            element: Нативний об'єкт елемента
            name: Назва атрибута
            default: Значення за замовчуванням
            
        Returns:
            Значення атрибута
        """
        pass
    
    @abstractmethod
    def find_children(
        self, 
        element: Any, 
        tag_names: list[str] | None = None,
        recursive: bool = True
    ) -> list[HTMLElement]:
        """Знаходить дочірні елементи.
        
        Args:
            element: Нативний об'єкт елемента
            tag_names: Список тегів для фільтрації
            recursive: Рекурсивний пошук
            
        Returns:
            Список HTMLElement об'єктів
        """
        pass
    
    @abstractmethod
    def iter_descendants(self, element: Any) -> Iterator[HTMLElement]:
        """Ітерує по всіх нащадках в порядку DOM.
        
        Args:
            element: Нативний об'єкт елемента
            
        Yields:
            HTMLElement для кожного нащадка
        """
        pass
    
    @abstractmethod
    def get_html(self, element: Any) -> str:
        """Отримує HTML представлення елемента.
        
        Args:
            element: Нативний об'єкт елемента
            
        Returns:
            HTML string
        """
        pass
    
    @abstractmethod
    def find_all(self, tag_names: list[str]) -> list[HTMLElement]:
        """Знаходить всі елементи з певними тегами в документі.
        
        Args:
            tag_names: Список назв тегів
            
        Returns:
            Список знайдених елементів
        """
        pass

    @abstractmethod
    def iter_direct_children_mixed(
        self, element: Any
    ) -> Iterator[tuple[str, Any]]:
        """Ітерує по ПРЯМИХ дітях елемента, включаючи текстові вузли.

        Уніфікований інтерфейс для обробки mixed content (текст + inline-теги
        + block-теги, що вкладені у одному контейнері — типовий патерн
        бутстрапних карток / списків вакансій).

        Args:
            element: Нативний об'єкт елемента

        Yields:
            tuple[kind, value] де:
              - kind == 'text'    → value: str (текстовий сегмент, може містити
                                    whitespace; коментарі НЕ повертаються)
              - kind == 'element' → value: HTMLElement (тег-нащадок 1-го рівня)
        """
        pass

    def get_native_id(self, element: Any) -> int:
        """Стабільний ідентифікатор нативного DOM-вузла.

        За замовчуванням — ``id()`` (валідно для BeautifulSoup, де об'єкт
        вузла зберігається у дереві). Адаптери, що створюють нові Python-
        обгортки при кожному обході (наприклад, Selectolax), мають
        перевизначити метод і повертати стабільний ID (``mem_id``).
        """
        return id(element)
    
    def wrap_element(self, native_element: Any) -> HTMLElement:
        """Обгортає нативний елемент в HTMLElement.
        
        Utility метод для створення HTMLElement з нативного об'єкта.
        
        Args:
            native_element: Нативний об'єкт з парсера
            
        Returns:
            HTMLElement wrapper
        """
        tag_name = self.get_tag_name(native_element)
        return HTMLElement(tag_name=tag_name, native=native_element, adapter=self)
