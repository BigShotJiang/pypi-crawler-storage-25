"""BeautifulSoup адаптер для уніфікованої роботи з HTML.

Обгортає BeautifulSoup API в BaseHTMLAdapter інтерфейс.
"""
from __future__ import annotations

from typing import Any, Iterator

from graph_crawler.shared.utils.markdown.adapters.base import (
    BaseHTMLAdapter,
    HTMLElement,
)


class BeautifulSoupAdapter(BaseHTMLAdapter):
    """Адаптер для BeautifulSoup парсера.
    
    Конвертує BeautifulSoup специфічні методи в уніфікований інтерфейс BaseHTMLAdapter.
    
    Attributes:
        soup: BeautifulSoup об'єкт
    """
    
    def __init__(self, soup: Any):
        """Ініціалізує адаптер.
        
        Args:
            soup: BeautifulSoup об'єкт (результат BeautifulSoup(html, parser))
        """
        self.soup = soup
    
    def get_root(self) -> HTMLElement:
        """Отримує кореневий елемент.
        
        Шукає <body>, якщо не знайдено - повертає весь soup.
        
        Returns:
            HTMLElement для кореня
        """
        root = self.soup.find('body') or self.soup
        return self.wrap_element(root)
    
    def get_tag_name(self, element: Any) -> str:
        """Отримує назву тегу BeautifulSoup елемента.
        
        Args:
            element: BeautifulSoup Tag об'єкт
            
        Returns:
            Назва тегу в нижньому регістрі
        """
        if hasattr(element, 'name') and element.name:
            return element.name.lower()
        return ''
    
    def get_text(self, element: Any, strip: bool = True, separator: str = ' ') -> str:
        """Отримує текст з BeautifulSoup елемента.
        
        Args:
            element: BeautifulSoup Tag
            strip: Очищати пробіли
            separator: Роздільник між текстовими вузлами
            
        Returns:
            Текстовий контент
        """
        if not hasattr(element, 'get_text'):
            return ''
        return element.get_text(strip=strip, separator=separator)
    
    def get_attribute(self, element: Any, name: str, default: str = '') -> str:
        """Отримує атрибут BeautifulSoup елемента.
        
        Args:
            element: BeautifulSoup Tag
            name: Назва атрибута
            default: Значення за замовчуванням
            
        Returns:
            Значення атрибута
        """
        if not hasattr(element, 'get'):
            return default
        
        value = element.get(name, default)
        
        # BS4 може повертати list для class та інших multi-value атрибутів
        if isinstance(value, list):
            return ' '.join(value)
        
        return str(value) if value else default
    
    def find_children(
        self, 
        element: Any, 
        tag_names: list[str] | None = None,
        recursive: bool = True
    ) -> list[HTMLElement]:
        """Знаходить дочірні елементи через BeautifulSoup.
        
        Args:
            element: BeautifulSoup Tag
            tag_names: Фільтр по тегах (None = всі)
            recursive: Рекурсивний пошук
            
        Returns:
            Список HTMLElement
        """
        if not hasattr(element, 'find_all'):
            return []
        
        # BeautifulSoup приймає list тегів або True для всіх
        search_tags = tag_names if tag_names else True
        
        found = element.find_all(search_tags, recursive=recursive)
        return [self.wrap_element(el) for el in found if hasattr(el, 'name')]
    
    def iter_descendants(self, element: Any) -> Iterator[HTMLElement]:
        """Ітерує по нащадках BeautifulSoup елемента.
        
        Використовує BS4 descendants для обходу в порядку DOM.
        
        Args:
            element: BeautifulSoup Tag
            
        Yields:
            HTMLElement для кожного нащадка з name атрибутом
        """
        if not hasattr(element, 'descendants'):
            return
        
        for descendant in element.descendants:
            # Фільтруємо тільки Tag об'єкти (не NavigableString)
            if hasattr(descendant, 'name') and descendant.name:
                yield self.wrap_element(descendant)
    
    def get_html(self, element: Any) -> str:
        """Отримує HTML BeautifulSoup елемента.
        
        Args:
            element: BeautifulSoup Tag
            
        Returns:
            HTML string
        """
        if not hasattr(element, 'decode'):
            return ''
        
        # decode() в BS4 конвертує Tag назад в HTML string
        try:
            return element.decode()
        except (AttributeError, TypeError):
            return str(element)
    
    def find_all(self, tag_names: list[str]) -> list[HTMLElement]:
        """Знаходить всі елементи з певними тегами в документі.
        
        Args:
            tag_names: Список назв тегів
            
        Returns:
            Список HTMLElement
        """
        if not hasattr(self.soup, 'find_all'):
            return []
        
        found = self.soup.find_all(tag_names)
        return [self.wrap_element(el) for el in found if hasattr(el, 'name')]

    def iter_direct_children_mixed(
        self, element: Any
    ) -> Iterator[tuple[str, Any]]:
        """Прямі діти елемента (Tag + NavigableString), без коментарів.

        BS4 ``Tag.children`` віддає і ``Tag``, і ``NavigableString``. Ми
        фільтруємо ``Comment`` (підклас ``NavigableString``), щоб у вивід
        не потрапляла HTML-коментарна служба.
        """
        # Lazy import — не тягнемо bs4 у адаптер на module level.
        try:
            from bs4 import Comment, NavigableString
        except ImportError:
            Comment = None  # type: ignore[assignment]
            NavigableString = None  # type: ignore[assignment]

        if not hasattr(element, 'children'):
            return

        for child in element.children:
            # NavigableString (включно з Comment, CData, Doctype) — текст.
            if NavigableString is not None and isinstance(child, NavigableString):
                if Comment is not None and isinstance(child, Comment):
                    continue
                yield ('text', str(child))
                continue

            # Tag — обгортаємо в HTMLElement.
            if hasattr(child, 'name') and child.name:
                yield ('element', self.wrap_element(child))
