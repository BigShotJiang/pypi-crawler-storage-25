"""Markdown Renderer — серіалізує MDAST (``ast.py``) у Markdown-рядок.

Контекстно-чутливе екранування (P1.12), bullet cycling (P1.11),
task lists (P1.10), GFM strikethrough.

Етап 7.1 (P1) з ``docs/md_generator_analysis/README.md``.
"""
from __future__ import annotations

import re

from graph_crawler.shared.utils.markdown.ast import (
    Block,
    Blockquote,
    CodeBlock,
    Document,
    Heading,
    HtmlRaw,
    Image,
    Inline,
    Link,
    List,
    Paragraph,
    Table,
    TableCell,
    TableRow,
    Text,
    ThematicBreak,
)
from graph_crawler.shared.utils.markdown.options import MarkdownOptions


class MarkdownRenderer:
    """Рендерить ``Document`` у Markdown-рядок.

    Тримає у контексті стан (``_inside_code``, ``_inside_table``), щоб
    екранування ``|`` / ``\\n`` робилося лише там, де воно потрібно.
    
    Для reference-style links (P1.9) збирає посилання у ``_link_references``
    і виводить їх блоком наприкінці документа.
    """

    __slots__ = ("opt", "_inside_code", "_inside_table", "_link_references", "_link_ref_map")

    def __init__(self, options: MarkdownOptions):
        self.opt = options
        self._inside_code = False
        self._inside_table = False
        # P1.9: reference-style links
        self._link_references: list[tuple[str, str]] = []  # [(href, title), ...]
        self._link_ref_map: dict[tuple[str, str], int] = {}  # {(href, title): ref_num}

    # ──────────────────────────────────────────────────────────────────
    #  Public API
    # ──────────────────────────────────────────────────────────────────

    def render(self, doc: Document) -> str:
        # Скидаємо reference-стан перед кожним новим рендерингом
        self._link_references.clear()
        self._link_ref_map.clear()
        
        parts = [self._block(b) for b in doc.children]
        parts = [p for p in parts if p]
        body = "\n".join(parts)
        
        # P1.9: додаємо reference block якщо link_style == 'reference'
        if self.opt.link_style == "reference" and self._link_references:
            ref_lines = []
            for i, (href, title) in enumerate(self._link_references, 1):
                if title:
                    ref_lines.append(f'[{i}]: {href} "{title}"')
                else:
                    ref_lines.append(f"[{i}]: {href}")
            ref_block = "\n".join(ref_lines)
            return f"{body}\n\n{ref_block}"
        
        return body

    # ──────────────────────────────────────────────────────────────────
    #  Block dispatcher
    # ──────────────────────────────────────────────────────────────────

    def _block(self, node: Block) -> str:
        if isinstance(node, Heading):
            return self._heading(node)
        if isinstance(node, Paragraph):
            return self._paragraph(node)
        if isinstance(node, List):
            return self._list(node, depth=0)
        if isinstance(node, CodeBlock):
            return self._code_block(node)
        if isinstance(node, Blockquote):
            return self._blockquote(node)
        if isinstance(node, Table):
            return self._table(node)
        if isinstance(node, ThematicBreak):
            return "\n---\n"
        if isinstance(node, HtmlRaw):
            return node.markdown
        return ""

    # ──────────────────────────────────────────────────────────────────
    #  Block renderers
    # ──────────────────────────────────────────────────────────────────

    def _heading(self, h: Heading) -> str:
        text = self._inline_seq(h.children)
        return f"\n{'#' * h.level} {text}\n"

    def _paragraph(self, p: Paragraph) -> str:
        text = self._inline_seq(p.children)
        return f"\n{text}\n"

    def _code_block(self, c: CodeBlock) -> str:
        prev = self._inside_code
        self._inside_code = True
        try:
            return f"\n```{c.lang}\n{c.code.strip()}\n```\n"
        finally:
            self._inside_code = prev

    def _blockquote(self, b: Blockquote) -> str:
        inner = "\n".join(self._block(child) for child in b.children).strip()
        if not inner:
            return ""
        lines = inner.split("\n")
        quoted = "\n".join(f"> {line}" if line.strip() else ">" for line in lines)
        return f"\n{quoted}\n"

    def _list(self, lst: List, depth: int) -> str:
        bullets = self.opt.bullets if self.opt.bullets else "-"
        bullet_char = bullets[depth % len(bullets)]
        indent = "  " * depth
        lines: list[str] = []

        for i, item in enumerate(lst.items, 1):
            marker = f"{i}." if lst.ordered else bullet_char
            # GFM task-list (P1.10)
            checkbox = ""
            if item.checked is not None:
                checkbox = "[x] " if item.checked else "[ ] "

            # Розкладаємо item.children: перший inline-блок іде на одну
            # лінію з маркером, наступні (вкладені списки тощо) —
            # окремими лініями з відступом.
            head_text = ""
            tail_blocks: list[Block] = []
            for j, child in enumerate(item.children):
                if j == 0 and isinstance(child, Paragraph):
                    head_text = self._inline_seq(child.children)
                else:
                    tail_blocks.append(child)

            line = f"{indent}{marker} {checkbox}{head_text}".rstrip()
            if line.strip() == marker:
                # Порожній item — пропускаємо
                continue
            lines.append(line)

            for tail in tail_blocks:
                if isinstance(tail, List):
                    nested = self._list(tail, depth + 1)
                    if nested:
                        lines.append(nested)
                else:
                    rendered = self._block(tail).strip()
                    if rendered:
                        lines.append(f"{indent}  {rendered}")

        body = "\n".join(lines)
        # На верхньому рівні обгортаємо у blank-lines, щоб збігалося з
        # поточним виводом ``UnifiedMarkdownConverter``.
        if depth == 0:
            return f"\n{body}\n" if body else ""
        return body

    # ──────────────────────────────────────────────────────────────────
    #  Tables
    # ──────────────────────────────────────────────────────────────────

    def _table(self, t: Table) -> str:
        if not t.rows:
            return ""
        prev = self._inside_table
        self._inside_table = True
        try:
            lines: list[str] = []
            max_cols = max(len(r.cells) for r in t.rows) if t.rows else 0
            header_row = t.rows[0]
            header_has_th = any(c.is_header for c in header_row.cells)

            if header_has_th:
                lines.append(self._render_row(header_row, max_cols))
                lines.append(self._render_separator(max_cols, t.alignments))
                body_rows = t.rows[1:]
            else:
                # Автогенерований header (поведінка legacy-конвертера)
                auto_header = TableRow(
                    cells=[
                        TableCell(children=[Text(f"Col {i + 1}")], is_header=True)
                        for i in range(max_cols)
                    ]
                )
                lines.append(self._render_row(auto_header, max_cols))
                lines.append(self._render_separator(max_cols, t.alignments))
                body_rows = t.rows  # перший рядок все одно тіло

            for row in body_rows:
                lines.append(self._render_row(row, max_cols))

            return "\n" + "\n".join(lines) + "\n"
        finally:
            self._inside_table = prev

    def _render_row(self, row: TableRow, max_cols: int) -> str:
        cells: list[str] = []
        for cell in row.cells:
            text = self._inline_seq(cell.children)
            text = self._escape_table_cell(text) if text else " "
            cells.append(text)
            for _ in range(max(0, cell.colspan - 1)):
                cells.append(" ")
        while len(cells) < max_cols:
            cells.append(" ")
        return "| " + " | ".join(cells) + " |"

    @staticmethod
    def _render_separator(n: int, alignments: list) -> str:
        seps = []
        for i in range(n):
            align = alignments[i] if i < len(alignments) else None
            if align == "left":
                seps.append(":---")
            elif align == "right":
                seps.append("---:")
            elif align == "center":
                seps.append(":---:")
            else:
                seps.append("---")
        return "| " + " | ".join(seps) + " |"

    @staticmethod
    def _escape_table_cell(text: str) -> str:
        """Екранує ``|`` / ``\\n`` у клітинці (P0.3)."""
        if not text:
            return " "
        # Не екрануємо ``\\``, бо raw inline вже містить готовий ``\\|``.
        # Екрануємо тільки сирі pipes (``|`` без префіксу ``\\``).
        text = re.sub(r"(?<!\\)\|", r"\\|", text)
        text = text.replace("\r\n", "<br>").replace("\n", "<br>").replace("\r", "<br>")
        return text

    # ──────────────────────────────────────────────────────────────────
    #  Inline
    # ──────────────────────────────────────────────────────────────────

    def _inline_seq(self, nodes: list[Inline]) -> str:
        return "".join(self._inline(n) for n in nodes)

    def _inline(self, node: Inline) -> str:
        if isinstance(node, Text):
            return node.value if node.raw else self._escape(node.value)
        if isinstance(node, Link):
            inner = self._inline_seq(node.children)
            
            # P1.9: reference-style links
            if self.opt.link_style == "reference":
                key = (node.href, node.title)
                if key not in self._link_ref_map:
                    self._link_references.append(key)
                    self._link_ref_map[key] = len(self._link_references)
                ref_num = self._link_ref_map[key]
                return f"[{inner}][{ref_num}]"
            
            # inline-style (default)
            if node.title:
                return f'[{inner}]({node.href} "{node.title}")'
            return f"[{inner}]({node.href})"
        if isinstance(node, Image):
            if node.title:
                return f'![{node.alt}]({node.src} "{node.title}")'
            return f"![{node.alt}]({node.src})"
        return ""

    def _escape(self, s: str) -> str:
        """Контекстно-чутливе екранування (P1.12)."""
        if not s:
            return s
        if self._inside_code:
            return s
        if self._inside_table:
            s = re.sub(r"(?<!\\)\|", r"\\|", s)
            s = s.replace("\n", " ")
        if getattr(self.opt, "strict_escape", False):
            # CommonMark spec §2.4 — escape спецсимволів
            s = re.sub(r"([\\`*_{}\[\]()#+\-!])", r"\\\1", s)
        return s
