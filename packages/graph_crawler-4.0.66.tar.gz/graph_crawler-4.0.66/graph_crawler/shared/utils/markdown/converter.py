"""Уніфікований Markdown конвертер.

Єдиний алгоритм конвертації HTML → Markdown що працює з будь-яким
адаптером (BeautifulSoup, Selectolax, lxml) через BaseHTMLAdapter інтерфейс.
"""
from __future__ import annotations

import html
import re
from typing import Any
from urllib.parse import urljoin

from graph_crawler.shared.utils.markdown.adapters.base import (
    BaseHTMLAdapter,
    HTMLElement,
)
from graph_crawler.shared.utils.markdown.options import MarkdownOptions


class UnifiedMarkdownConverter:
    """Уніфікований конвертер HTML в Markdown.
    
    Використовує Adapter Pattern для роботи з різними парсерами.
    Один алгоритм замість дублювання коду для кожного парсера.
    
    Attributes:
        options: Налаштування конвертації
    """
    
    def __init__(self, options: MarkdownOptions):
        """Ініціалізує конвертер.
        
        Args:
            options: Налаштування генерації markdown
        """
        self.options = options
    
    def convert(self, adapter: BaseHTMLAdapter) -> tuple[str, dict[str, int]]:
        """Конвертує HTML в Markdown через адаптер.
        
        Основний метод конвертації. Обробляє всі елементи в порядку DOM.
        
        Args:
            adapter: HTML адаптер (BS4, Selectolax, тощо)
            
        Returns:
            tuple[markdown_string, stats_dict] де stats містить кількість елементів
        """
        root = adapter.get_root()

        use_density = (
            hasattr(self.options, 'use_content_density')
            and self.options.use_content_density
        )

        if use_density:
            main_root = self._find_main_content(adapter, root)
            markdown, stats = self._convert_subtree(main_root)

            # Fallback chain: якщо main-content занадто короткий, повторюємо
            # на повному root (Trafilatura-style recall).
            min_words = getattr(self.options, 'min_content_words', 100)
            if min_words > 0 and main_root is not root:
                word_count = len(markdown.split())
                if word_count < min_words:
                    markdown, stats = self._convert_subtree(root)
            return markdown, stats

        return self._convert_subtree(root)

    def _convert_subtree(
        self, root: HTMLElement
    ) -> tuple[str, dict[str, int]]:
        """Обходить піддерево root і генерує markdown.

        Винесено з `convert()`, щоб content-density fallback міг
        викликати однакову логіку для main-content та повного root.
        """
        md_parts: list[str] = []
        stats = {"headings": 0, "links": 0, "images": 0, "code": 0, "lists": 0, "tables": 0}
        processed_elements: set[int] = set()

        for element in root.iter_descendants():
            elem_id = element.native_id

            if elem_id in processed_elements:
                continue

            self._dispatch_element(element, md_parts, stats, processed_elements)

        markdown = "\n".join(md_parts)
        
        if self.options.normalize_whitespace:
            markdown = re.sub(r"\n{3,}", "\n\n", markdown)
            markdown = markdown.strip()
        
        return markdown, stats

    def _dispatch_element(
        self,
        element: HTMLElement,
        md_parts: list[str],
        stats: dict[str, int],
        processed_elements: set[int],
    ) -> None:
        """Делегує елемент відповідному обробнику за тегом.

        Винесено з ``_convert_subtree`` для перевикористання у mixed-content
        гілці ``_process_container`` (там block-діти обробляються рекурсивно
        у порядку DOM, без повернення в головний цикл).
        """
        tag_name = element.tag_name.lower()

        if tag_name in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self._process_heading(element, md_parts, stats, processed_elements)
        elif tag_name == "p":
            self._process_paragraph(element, md_parts, processed_elements)
        elif tag_name == "pre" and self.options.include_code_blocks:
            self._process_code_block(element, md_parts, stats, processed_elements)
        elif tag_name in ("ul", "ol") and self.options.include_lists:
            self._process_list(element, md_parts, stats, processed_elements)
        elif tag_name == "blockquote" and self.options.include_blockquotes:
            self._process_blockquote(element, md_parts, processed_elements)
        elif tag_name == "img" and self.options.include_images:
            self._process_image(element, md_parts, stats, processed_elements)
        elif tag_name == "table" and self.options.include_tables:
            self._process_table(element, md_parts, stats, processed_elements)
        elif tag_name == "a" and self.options.include_links:
            href = element.get_attribute("href")
            if href:
                stats["links"] += 1
        elif tag_name == "hr":
            md_parts.append("\n---\n")
            processed_elements.add(element.native_id)
        elif tag_name == "dl" and self.options.include_lists:
            # Definition list (Pandoc-style).
            self._process_definition_list(
                element, md_parts, stats, processed_elements
            )
        elif tag_name in (
            "div", "section", "aside", "span", "main", "article",
        ):
            self._process_container(element, md_parts, stats, processed_elements)
    
    def _process_heading(
        self, 
        element: HTMLElement, 
        md_parts: list[str], 
        stats: dict[str, int],
        processed: set[int]
    ) -> None:
        """Обробляє заголовок (h1-h6)."""
        level = int(element.tag_name[1])
        text = element.get_text(strip=True)
        
        if text and len(text) >= self.options.min_heading_length:
            # Context-sensitive escaping: екрануємо CommonMark спецсимволи,
            # якщо ввімкнено strict_escape.
            if getattr(self.options, "strict_escape", False):
                text = self._escape_commonmark_text(text)
            md_parts.append(f"\n{'#' * level} {text}\n")
            stats["headings"] += 1
        
        processed.add(element.native_id)
    
    def _process_paragraph(
        self, 
        element: HTMLElement, 
        md_parts: list[str],
        processed: set[int]
    ) -> None:
        """Обробляє параграф з inline форматуванням."""
        text = element.get_text(strip=True)
        
        if text and len(text) >= self.options.min_paragraph_length:
            # Обробка inline форматування
            md_text = self._process_inline_formatting(element)
            md_parts.append(f"\n{md_text}\n")
        
        processed.add(element.native_id)
    
    def _process_code_block(
        self, 
        element: HTMLElement, 
        md_parts: list[str],
        stats: dict[str, int],
        processed: set[int]
    ) -> None:
        """Обробляє блок коду (pre)."""
        code = element.get_text(strip=False)
        
        if code and code.strip():
            code_elements = element.find_children(['code'], recursive=False)
            lang = ""
            
            if code_elements:
                code_elem = code_elements[0]
                classes = code_elem.get_attribute('class', '')
                
                if 'language-' in classes:
                    lang = classes.split('language-')[1].split()[0]
                elif 'lang-' in classes:
                    lang = classes.split('lang-')[1].split()[0]
                
                processed.add(code_elem.native_id)
            
            md_parts.append(f"\n```{lang}\n{code.strip()}\n```\n")
            stats["code"] += 1
        
        processed.add(element.native_id)
    
    def _process_list(
        self, 
        element: HTMLElement, 
        md_parts: list[str],
        stats: dict[str, int],
        processed: set[int],
        indent: int = 0
    ) -> None:
        """Обробляє список (ul/ol) з вкладеністю."""
        list_md = self._list_to_markdown(element, indent)
        
        if list_md:
            md_parts.append(f"\n{list_md}\n")
            stats["lists"] += 1
        
        for child in element.iter_descendants():
            processed.add(child.native_id)
        
        processed.add(element.native_id)
    
    def _list_to_markdown(self, element: HTMLElement, indent: int = 0) -> str:
        """Конвертує список в Markdown з підтримкою вкладеності.

        Підтримує GFM task-list (``<input type="checkbox">`` →
        ``- [x] ...`` / ``- [ ] ...``) та bullet cycling — символ маркера
        для UL береться з ``options.bullets`` за глибиною:
        ``bullets[depth % len(bullets)]``.

        Args:
            element: HTMLElement для ul або ol
            indent: Рівень вкладеності

        Returns:
            Markdown string для списку
        """
        lines = []
        indent_str = "  " * indent
        is_ordered = element.tag_name == "ol"

        # Bullet cycling за рівнем вкладеності.
        bullets = getattr(self.options, "bullets", "-") or "-"
        bullet = bullets[indent % len(bullets)]

        list_items = element.find_children(['li'], recursive=False)

        for i, li in enumerate(list_items, 1):
            # GFM task-list — шукаємо безпосередній <input type=checkbox>.
            checkbox_marker = self._extract_task_marker(li)

            text = self._process_inline_formatting(li)

            nested_lists = li.find_children(['ul', 'ol'], recursive=False)
            for nested in nested_lists:
                nested_text = nested.get_text(strip=True)
                text = text.replace(nested_text, "").strip()

            text = " ".join(text.split()).strip()

            if text:
                prefix = f"{i}." if is_ordered else bullet
                if checkbox_marker is not None:
                    lines.append(f"{indent_str}{prefix} {checkbox_marker} {text}")
                else:
                    lines.append(f"{indent_str}{prefix} {text}")

            for nested in nested_lists:
                nested_md = self._list_to_markdown(nested, indent + 1)
                if nested_md:
                    lines.append(nested_md)

        return "\n".join(lines)

    def _extract_task_marker(self, li: HTMLElement) -> str | None:
        """Повертає GFM task-list маркер для ``<li>`` або ``None``.

        Шукає ``<input type="checkbox">`` серед дітей ``<li>``. Якщо є
        атрибут ``checked`` — ``[x]``, інакше ``[ ]``. Якщо чекбоксу нема —
        повертає ``None``, і список рендериться як звичайний.
        """
        try:
            inputs = li.find_children(['input'], recursive=True)
        except Exception:
            return None

        for inp in inputs:
            input_type = (inp.get_attribute('type', '') or '').lower()
            if input_type != 'checkbox':
                continue
            # `checked` у HTML5 — boolean attribute: <input checked> валідно.
            # BS4 зберігає його як '' (порожній рядок), Selectolax — як None.
            # Наш get_attribute() повертає default для обох (str(value) if value),
            # тому дивимося у нативний attrs dict напряму (parser-agnostic).
            native = getattr(inp, 'native', None)
            attrs = (
                getattr(native, 'attrs', None)
                or getattr(native, 'attributes', None)
                or {}
            )
            is_checked = 'checked' in attrs
            return "[x]" if is_checked else "[ ]"

        return None
    
    def _process_definition_list(
        self,
        element: HTMLElement,
        md_parts: list[str],
        stats: dict[str, int],
        processed: set[int],
    ) -> None:
        """Обробляє definition list (``<dl>``) у Pandoc-стилі.

        Формат виводу::

            term
            : definition

        Підтримує множинні ``<dd>`` для одного ``<dt>`` (всі ``<dd>``,
        що йдуть до наступного ``<dt>``, прив'язуються до останнього
        зустрінутого терміна).
        """
        children = element.find_children(['dt', 'dd'], recursive=False)
        if not children:
            processed.add(element.native_id)
            return

        lines: list[str] = []
        current_term: str | None = None

        for child in children:
            tag = child.tag_name.lower()
            text = self._process_inline_formatting(child)
            text = " ".join(text.split()).strip()
            if not text:
                continue

            if tag == 'dt':
                if current_term is not None and lines and lines[-1] != '':
                    lines.append('')
                lines.append(text)
                current_term = text
            elif tag == 'dd':
                # Якщо <dd> зустрінувся без попереднього <dt> — рендеримо
                # як осиротілу definition (це валідний Pandoc edge-case).
                lines.append(f": {text}")

        if lines:
            md_parts.append("\n" + "\n".join(lines) + "\n")
            stats["lists"] += 1

        for d in element.iter_descendants():
            processed.add(d.native_id)
        processed.add(element.native_id)

    def _process_blockquote(
        self,
        element: HTMLElement,
        md_parts: list[str],
        processed: set[int]
    ) -> None:
        """Обробляє blockquote з inline форматуванням."""
        inner_text = self._process_inline_formatting(element)
        
        if inner_text:
            lines = inner_text.split('\n')
            quoted = '\n'.join(f'> {line}' if line.strip() else '>' for line in lines)
            md_parts.append(f"\n{quoted}\n")
        
        processed.add(element.native_id)
    
    def _process_image(
        self, 
        element: HTMLElement, 
        md_parts: list[str],
        stats: dict[str, int],
        processed: set[int]
    ) -> None:
        """Обробляє зображення."""
        src = element.get_attribute('src', '')
        alt = element.get_attribute('alt', '')
        
        if src:
            # Нормалізуємо URL зображення
            if self.options.normalize_urls and self.options.base_url:
                src = self._normalize_url(src)
            
            md_parts.append(f"\n![{alt}]({src})\n")
            stats["images"] += 1
        
        processed.add(element.native_id)
    
    def _process_table(
        self, 
        element: HTMLElement, 
        md_parts: list[str],
        stats: dict[str, int],
        processed: set[int]
    ) -> None:
        """Обробляє таблицю."""
        table_md = self._table_to_markdown(element)
        
        if table_md:
            md_parts.append(f"\n{table_md}\n")
            stats["tables"] += 1
        
        for child in element.iter_descendants():
            processed.add(child.native_id)
        
        processed.add(element.native_id)
    
    def _table_to_markdown(self, table: HTMLElement) -> str:
        """Конвертує HTML таблицю в Markdown з підтримкою colspan.
        
        Args:
            table: HTMLElement для table
            
        Returns:
            Markdown table string
        """
        rows = []
        header_found = False
        max_cols = 0
        thead_tr_ids: set[int] = set()
        
        thead_elements = table.find_children(['thead'], recursive=False)
        if thead_elements:
            thead = thead_elements[0]
            tr_elements = thead.find_children(['tr'], recursive=False)
            
            # Запам'ятовуємо id всіх trs у thead, щоб виключити їх з body-loop
            # (для Selectolax, де parent.name відсутнє).
            for thead_tr in tr_elements:
                thead_tr_ids.add(thead_tr.native_id)
            
            if tr_elements:
                header_row = tr_elements[0]
                th_td_elements = header_row.find_children(['th', 'td'], recursive=False)
                cells = self._process_table_row_with_colspan(th_td_elements)
                
                if cells:
                    max_cols = len(cells)
                    rows.append("| " + " | ".join(cells) + " |")
                    rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
                    header_found = True
        
        tbody_elements = table.find_children(['tbody'], recursive=False)
        tbody = tbody_elements[0] if tbody_elements else table
        
        all_trs = tbody.find_children(['tr'])
        
        for tr in all_trs:
            # Уніфікований skip для thead trs (без залежності від parent.name).
            if tr.native_id in thead_tr_ids:
                continue
            parent = getattr(tr.native, 'parent', None)
            parent_tag = getattr(parent, 'name', None) or getattr(parent, 'tag', None) or ''
            if parent_tag == 'thead':
                continue
            
            td_th_elements = tr.find_children(['td', 'th'], recursive=False)
            cells = self._process_table_row_with_colspan(td_th_elements)
            
            if not cells:
                continue
            
            if len(cells) > max_cols:
                max_cols = len(cells)
            
            if not header_found and not rows:
                has_th = any(cell.tag_name == 'th' for cell in td_th_elements)
                
                if has_th or cells:
                    if not has_th:
                        rows.append("| " + " | ".join([f"Col {i + 1}" for i in range(len(cells))]) + " |")
                    else:
                        rows.append("| " + " | ".join(cells) + " |")
                    
                    rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
                    header_found = True
                    
                    if not has_th:
                        rows.append("| " + " | ".join(cells) + " |")
            else:
                while len(cells) < max_cols:
                    cells.append(" ")
                
                rows.append("| " + " | ".join(cells) + " |")
        
        return "\n".join(rows)
    
    def _process_table_row_with_colspan(self, cells: list[HTMLElement]) -> list[str]:
        """Обробляє рядок таблиці з підтримкою colspan.
        
        Args:
            cells: Список HTMLElement клітинок (td або th)
            
        Returns:
            Список текстових значень з урахуванням colspan
        """
        result = []
        
        for cell in cells:
            text = cell.get_text(strip=True)
            colspan = cell.get_attribute('colspan', '1')
            
            try:
                colspan_int = int(colspan)
            except (ValueError, TypeError):
                colspan_int = 1
            
            # Екрануємо '|' та '\n' у вмісті клітинки.
            cell_value = self._escape_table_cell(text) if text else " "
            result.extend([cell_value] + [" "] * (colspan_int - 1))
        
        return result

    @staticmethod
    def _escape_table_cell(text: str) -> str:
        """Екранує символи, що ламають Markdown-таблицю.

        - ``|`` → ``\\|`` (інакше зіпсує колонку)
        - newline → ``<br>`` (CommonMark забороняє real newline у клітинці)
        """
        if not text:
            return " "
        text = text.replace("\\", "\\\\").replace("|", "\\|")
        text = text.replace("\r\n", "<br>").replace("\n", "<br>").replace("\r", "<br>")
        return text

    # ──────────────────────────────────────────────────────────────────
    #  Context-sensitive CommonMark escaping
    # ──────────────────────────────────────────────────────────────────

    # ASCII punctuation, що може починати inline-конструкцію у CommonMark.
    # Ми НЕ екрануємо те, що вже використовується як наш згенерований
    # markdown (``**``, ``*`` для strong/em, `` ` `` для code тощо). Тому
    # escape застосовується ТІЛЬКИ до text-сегментів HTML-входу, ще ДО
    # того як regex-заміни згенерують markers. Див. ``_escape_text_nodes_in_html``.
    _CM_ESCAPE_RE = re.compile(r"([\\`*_{}\[\]()#+\-!~|])")

    @classmethod
    def _escape_commonmark_text(cls, text: str) -> str:
        """Екранує CommonMark/GFM спецсимволи у plain-text.

        Використовується для тексту з ``get_text()`` (там немає HTML-тегів,
        що могли б згенерувати markers). Код-інлайн / посилання / таблиці
        викликають цей метод через власні гілки, бо контекст різний.
        """
        if not text:
            return text
        return cls._CM_ESCAPE_RE.sub(r"\\\1", text)

    @classmethod
    def _escape_text_nodes_in_html(cls, html_str: str) -> str:
        """Екранує CommonMark-спецсимволи тільки у ТЕКСТОВИХ сегментах HTML.

        Проходить html_str ззовні ``<...>`` тегів та екранує спецсимволи у
        текстових регіонах. HTML-теги (і HTML-атрибути всередині них)
        залишаються недоторканими, тому подальші regex-заміни коректно
        перетворюють ``<strong>`` → ``**`` без хибного екранування.

        **Контекстно** пропускає вміст ``<code>``/``<pre>``/``<kbd>``/
        ``<samp>`` — усередині них CommonMark забороняє escape.
        Також пропускає ``<a>`` (текст посилання залишаємо як є, бо він
        фінальний — без перекладу у markers).

        HTML-entities (``&amp;`` / ``&lt;``) залишаємо — вони нормалізуються
        пізніше через ``html.unescape`` і на markdown-рендер не впливають.
        """
        if not html_str or "<" not in html_str:
            return cls._escape_commonmark_text(html_str)

        # Теги, всередині яких escape НЕ застосовується.
        skip_tags = {"code", "pre", "kbd", "samp", "a"}
        out: list[str] = []
        i = 0
        n = len(html_str)
        tag_re = re.compile(r"<(/?)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*?>", re.IGNORECASE)

        while i < n:
            m = tag_re.search(html_str, i)
            if not m:
                out.append(cls._escape_commonmark_text(html_str[i:]))
                break
            # Текст до тега — escape
            if m.start() > i:
                out.append(cls._escape_commonmark_text(html_str[i : m.start()]))
            tag_full = m.group(0)
            is_close = m.group(1) == "/"
            tag_name = m.group(2).lower()
            out.append(tag_full)
            i = m.end()

            if not is_close and tag_name in skip_tags:
                # Знайти відповідний закриваючий тег — скіпаємо вміст.
                close_re = re.compile(
                    r"</" + re.escape(tag_name) + r"\s*>", re.IGNORECASE
                )
                cm = close_re.search(html_str, i)
                if cm:
                    out.append(html_str[i : cm.end()])
                    i = cm.end()
                else:
                    out.append(html_str[i:])
                    i = n
        return "".join(out)

    def _process_container(
        self, 
        element: HTMLElement, 
        md_parts: list[str],
        stats: dict[str, int],
        processed: set[int]
    ) -> None:
        """Обробляє контейнери (div, section, aside, span).

        Дві гілки:

        1. **Без block-дітей** — увесь вміст інлайновий, генеруємо один
           параграф через ``_process_inline_formatting`` (стара поведінка).
        2. **Mixed content** — block-теги перемежовані з текстом/inline-
           елементами як прямі діти. Block-діти диспатчимо рекурсивно
           через ``_dispatch_element`` У ПОРЯДКУ DOM, а text + inline між
           ними згруповуємо у віртуальні параграфи. Це фіксить кейс,
           коли всередині ``<div>`` є текст і ``<strong>``-заголовки
           поза ``<p>``-обгортками (типовий Bootstrap-патерн).

        Усі нащадки контейнера, опрацьовані тут, мітяться у ``processed``,
        щоб головний цикл ``_convert_subtree`` не дублював вивід.
        """
        # Block-теги, які мають власний обробник. Широкий список — щоб
        # mixed-content фолбек не дублював уже відрендерений block-контент.
        block_tags = {
            "p", "h1", "h2", "h3", "h4", "h5", "h6",
            "ul", "ol", "table", "pre", "blockquote", "div",
            "section", "article", "aside", "dl", "hr", "img",
            "figure", "form", "nav", "header", "footer", "main",
        }

        # Дешева перевірка через адаптер (без повного списку дітей).
        has_block_children = element.has_children(list(block_tags))

        if not has_block_children:
            # Стара гілка: повністю інлайновий контейнер.
            text = element.get_text(strip=True)
            if text and len(text) >= self.options.min_paragraph_length:
                md_text = self._process_inline_formatting(element)
                md_parts.append(f"\n{md_text}\n")

                for child in element.iter_descendants():
                    processed.add(child.native_id)
                processed.add(element.native_id)
            return

        # ──────────────────────────────────────────────────────────────
        # Mixed content: ходимо ПРЯМИМИ дітьми, інлайн-сегменти збираємо
        # у буфер, block-діти диспатчимо рекурсивно у порядку DOM.
        # ──────────────────────────────────────────────────────────────
        try:
            mixed = list(element.iter_direct_children_mixed())
        except (AttributeError, TypeError):
            # Адаптер без mixed-iter — нічого не робимо (block-діти
            # обробляться головним циклом, інлайн-mixed втрачається,
            # але хоча б нічого не падає).
            return

        inline_html_buffer: list[str] = []
        # Кореневі inline-діти, які увійшли у буфер — мітимо їх (та їхніх
        # нащадків) як processed, щоб головний цикл не повторив обробку.
        inline_roots: list[HTMLElement] = []

        def flush() -> None:
            if not inline_html_buffer:
                return
            merged = "".join(inline_html_buffer)
            md_text = self._html_fragment_to_markdown(merged)
            stripped = md_text.strip() if md_text else ""
            if stripped and len(stripped) >= self.options.min_paragraph_length:
                md_parts.append(f"\n{md_text}\n")

            for root in inline_roots:
                processed.add(root.native_id)
                try:
                    for desc in root.iter_descendants():
                        processed.add(desc.native_id)
                except (AttributeError, TypeError):
                    pass

            inline_html_buffer.clear()
            inline_roots.clear()

        for kind, value in mixed:
            if kind == 'text':
                inline_html_buffer.append(value)
                continue

            # kind == 'element'
            tag = value.tag_name.lower()
            if tag in block_tags:
                # Закриваємо попередню inline-групу, потім диспатчимо
                # block-дитину рекурсивно — порядок DOM зберігається.
                flush()
                if value.native_id not in processed:
                    self._dispatch_element(value, md_parts, stats, processed)
                continue

            # Inline-елемент: додаємо його HTML у буфер.
            try:
                html_part = value.get_html()
            except (AttributeError, TypeError):
                html_part = ''
            if html_part:
                inline_html_buffer.append(html_part)
                inline_roots.append(value)

        flush()

        # Контейнер та всі його нащадки опрацьовані — мітимо, щоб головний
        # цикл (iter_descendants від root) не зайшов у них повторно.
        processed.add(element.native_id)
        try:
            for desc in element.iter_descendants():
                processed.add(desc.native_id)
        except (AttributeError, TypeError):
            pass

    def _html_fragment_to_markdown(self, html_str: str) -> str:
        """Конвертує HTML-фрагмент (string, без єдиного кореня) у Markdown.

        Використовує той самий пайплайн regex-замін, що й
        ``_process_inline_formatting`` для одиничного елемента, але приймає
        вже готовий HTML-string. Потрібно для mixed-content: коли треба
        склеїти text + inline + text + inline між block-дітьми у один
        віртуальний параграф.

        Підтримує: ``<br>``, ``<code>``, ``<strong>/<b>``, ``<em>/<i>``,
        ``<del>/<s>/<strike>``, ``<a>`` (за ``options.include_links``),
        strict_escape (за ``options.strict_escape``), CommonMark hard-break.
        """
        if not html_str:
            return ""

        # strict_escape — екранує спецсимволи у text-сегментах ДО regex-replace.
        if getattr(self.options, "strict_escape", False):
            html_str = self._escape_text_nodes_in_html(html_str)

        result = html_str

        ns = getattr(self.options, "newline_style", "spaces") or "spaces"
        hard_break = "\\\n" if ns == "backslash" else "  \n"

        result = re.sub(r'<br\s*/?>', hard_break, result, flags=re.IGNORECASE)

        result = re.sub(
            r'<code[^>]*>(.*?)</code>',
            r'`\1`',
            result,
            flags=re.IGNORECASE | re.DOTALL,
        )

        result = re.sub(
            r'<(?:strong|b)[^>]*>(.*?)</(?:strong|b)>',
            r'**\1**',
            result,
            flags=re.IGNORECASE | re.DOTALL,
        )

        result = re.sub(
            r'<(?:em|i)[^>]*>(.*?)</(?:em|i)>',
            r'*\1*',
            result,
            flags=re.IGNORECASE | re.DOTALL,
        )

        result = re.sub(
            r'<(?:del|s|strike)[^>]*>(.*?)</(?:del|s|strike)>',
            r'~~\1~~',
            result,
            flags=re.IGNORECASE | re.DOTALL,
        )

        if self.options.include_links:
            def replace_link(match):
                href_match = re.search(r'href=["\']([^"\']+)["\']', match.group(1))
                href = href_match.group(1) if href_match else ''
                text = match.group(2)

                if href and self.options.normalize_urls and self.options.base_url:
                    href = self._normalize_url(href)

                text = re.sub(r'<[^>]+>', '', text)
                text = text.strip()

                if href and text:
                    return f'[{text}]({href})'
                return text

            result = re.sub(
                r'<a\s+([^>]*?)>(.*?)</a>',
                replace_link,
                result,
                flags=re.IGNORECASE | re.DOTALL,
            )
        else:
            result = re.sub(
                r'<a[^>]*>(.*?)</a>',
                r'\1',
                result,
                flags=re.IGNORECASE | re.DOTALL,
            )

        # Видаляємо інші теги (span, etc.) лишаючи їхній текст.
        result = re.sub(r'<[^>]+>', '', result)
        result = html.unescape(result)

        # Зберігаємо hard-break до нормалізації пробілів (як у
        # _process_inline_formatting).
        placeholder = "\x00HARDBREAK\x00"
        result = re.sub(r' {2,}\n', placeholder, result)
        result = re.sub(r'\\\n', placeholder, result)
        result = re.sub(r'[ \t]+', ' ', result)
        result = re.sub(r' *\n *', '\n', result)
        result = re.sub(r'\n{3,}', '\n\n', result)
        result = result.replace(placeholder, hard_break)

        return result.strip()
    
    def _process_inline_formatting(self, element: HTMLElement) -> str:
        """Обробляє inline форматування (strong, em, code, a, br).
        
        Конвертує inline HTML теги в Markdown форматування.
        
        Args:
            element: HTMLElement для обробки
            
        Returns:
            Markdown string з inline форматуванням
        """
        # Не використовуємо ім'я `html` як змінну, щоб не затіняти
        # імпортований модуль `html`.
        html_str = element.get_html()

        if not html_str:
            text_only = element.get_text(strip=True)
            # strict_escape також застосовується до plain-text fallback.
            if text_only and getattr(self.options, "strict_escape", False):
                text_only = self._escape_commonmark_text(text_only)
            return text_only

        # Context-sensitive escaping: екрануємо CommonMark спецсимволи ЛИШЕ
        # у text-сегментах HTML, ДО того як regex-заміни згенерують
        # markdown-markers (``**``, ``*``, `` ` ``, ``[]()``).
        if getattr(self.options, "strict_escape", False):
            html_str = self._escape_text_nodes_in_html(html_str)

        result = html_str

        # Hard-break style: 'spaces' (CommonMark) або 'backslash' (GFM).
        ns = getattr(self.options, "newline_style", "spaces") or "spaces"
        hard_break = "\\\n" if ns == "backslash" else "  \n"

        # CommonMark hard break за замовчуванням ('  \n').
        result = re.sub(r'<br\s*/?>', hard_break, result, flags=re.IGNORECASE)
        
        result = re.sub(
            r'<code[^>]*>(.*?)</code>',
            r'`\1`',
            result,
            flags=re.IGNORECASE | re.DOTALL
        )
        
        result = re.sub(
            r'<(?:strong|b)[^>]*>(.*?)</(?:strong|b)>',
            r'**\1**',
            result,
            flags=re.IGNORECASE | re.DOTALL
        )
        
        result = re.sub(
            r'<(?:em|i)[^>]*>(.*?)</(?:em|i)>',
            r'*\1*',
            result,
            flags=re.IGNORECASE | re.DOTALL
        )

        # Strikethrough (<del>, <s>, <strike>) → ~~text~~ (GFM).
        result = re.sub(
            r'<(?:del|s|strike)[^>]*>(.*?)</(?:del|s|strike)>',
            r'~~\1~~',
            result,
            flags=re.IGNORECASE | re.DOTALL
        )
        
        if self.options.include_links:
            def replace_link(match):
                href_match = re.search(r'href=["\']([^"\']+)["\']', match.group(1))
                href = href_match.group(1) if href_match else ''
                text = match.group(2)
                
                if href and self.options.normalize_urls and self.options.base_url:
                    href = self._normalize_url(href)
                
                text = re.sub(r'<[^>]+>', '', text)
                text = text.strip()
                
                if href and text:
                    return f'[{text}]({href})'
                return text
            
            result = re.sub(
                r'<a\s+([^>]*?)>(.*?)</a>',
                replace_link,
                result,
                flags=re.IGNORECASE | re.DOTALL
            )
        else:
            result = re.sub(
                r'<a[^>]*>(.*?)</a>',
                r'\1',
                result,
                flags=re.IGNORECASE | re.DOTALL
            )
        
        result = re.sub(r'<[^>]+>', '', result)
        result = html.unescape(result)
        # Зберігаємо hard break перед схлопуванням пробілів.
        # Підтримуємо обидва стилі: 'spaces' (`  \n`) і 'backslash' (`\\\n`).
        placeholder = "\x00HARDBREAK\x00"
        result = re.sub(r' {2,}\n', placeholder, result)
        result = re.sub(r'\\\n', placeholder, result)
        result = re.sub(r' +', ' ', result)
        result = re.sub(r'\n{3,}', '\n\n', result)
        result = result.replace(placeholder, hard_break)

        return result.strip()
    
    def _normalize_url(self, href: str) -> str:
        """Нормалізує URL (конвертує відносні в абсолютні)."""
        if not href or not self.options.base_url:
            return href
        
        if href.startswith(('http://', 'https://', 'mailto:', 'tel:', 'javascript:', '#')):
            return href
        
        return urljoin(self.options.base_url, href)
    
    def _calculate_text_density(self, element: HTMLElement) -> float:
        """Обчислює щільність тексту (text density) для елемента.
        
        Text density = кількість тексту / кількість HTML коду
        Вищий показник = більше корисного контенту
        
        Args:
            element: HTMLElement для аналізу
            
        Returns:
            Коефіцієнт щільності тексту (0.0 - 1.0)
        """
        text_len = len(element.get_text(strip=True))
        html_len = len(element.get_html())
        
        if html_len == 0:
            return 0.0
        
        return text_len / html_len

    def _calculate_link_density(self, element: HTMLElement) -> float:
        """Обчислює щільність посилань (link density) для елемента.

        Trafilatura-style: link_density = link_chars / total_chars.
        Навігаційне меню / футер мають link_density ≈ 1.0, стаття — < 0.3.

        Args:
            element: HTMLElement для аналізу

        Returns:
            Коефіцієнт щільності посилань (0.0 - 1.0).
            1.0 означає, що весь текст — у `<a>` (або елемент порожній).
        """
        text_len = len(element.get_text(strip=True))
        if text_len == 0:
            # Порожній блок — трактуємо як «повністю посилання», щоб
            # fallback логіка його відкинула (безпечний default).
            return 1.0

        link_chars = 0
        for anchor in element.find_children(['a'], recursive=True):
            link_chars += len(anchor.get_text(strip=True))

        # clamp в [0, 1] — на випадок, коли text_len якось менше сумарного
        # (такого не має бути, але страхуємося).
        density = link_chars / text_len
        return density if density <= 1.0 else 1.0
    
    def _find_main_content(self, adapter: BaseHTMLAdapter, root: HTMLElement) -> HTMLElement:
        """Знаходить основний контент за допомогою аналізу щільності тексту.
        
        Алгоритм схожий на Trafilatura: score = text_density * text_length
        з штрафом за link_density. Кандидати з link_density вище
        `options.link_density_threshold` відкидаються як навігація/футер.
        
        Args:
            adapter: HTML адаптер
            root: Кореневий елемент
            
        Returns:
            HTMLElement з основним контентом (або root якщо не знайдено)
        """
        candidates = []

        # Пріоритетні теги для основного контенту
        priority_tags = ['article', 'main', 'div', 'section']

        link_density_threshold = getattr(
            self.options, 'link_density_threshold', 0.5
        )

        for element in root.iter_descendants():
            tag_name = element.tag_name.lower()

            # Розглядаємо тільки потенційні контейнери контенту
            if tag_name not in priority_tags:
                continue

            text = element.get_text(strip=True)
            text_length = len(text)

            # Пропускаємо елементи з малою кількістю тексту
            if text_length < 200:
                continue

            # Обчислюємо link_density; викидаємо навігацію.
            link_density = self._calculate_link_density(element)
            if link_density > link_density_threshold:
                continue

            # Обчислюємо щільність тексту
            density = self._calculate_text_density(element)

            # Score = density * text_length * (1 - link_density)
            # Штраф за посилання: стаття з 80% звичайного тексту і 20%
            # посилань отримує множник 0.8; пусте меню (якщо не відкинуте
            # порогом) — близький до 0.
            score = density * text_length * (1.0 - link_density)

            # Бонус для семантичних тегів
            if tag_name in ('article', 'main'):
                score *= 1.5

            # Перевіряємо класи та ID на noise
            class_attr = element.get_attribute('class', '')
            id_attr = element.get_attribute('id', '')

            # Зменшуємо score якщо має noise класи
            if self.options.should_remove_by_class(class_attr):
                score *= 0.3

            if self.options.should_remove_by_id(id_attr):
                score *= 0.3

            candidates.append((score, element, text_length))
        
        if not candidates:
            return root
        
        # Сортуємо за score (від найвищого)
        candidates.sort(key=lambda x: x[0], reverse=True)
        
        # Повертаємо елемент з найвищим score
        return candidates[0][1]
