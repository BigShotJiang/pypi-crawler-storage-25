"""Markdown Generator - Core Implementation.

Standalone утиліта для генерації Markdown з HTML.
Швидка, асинхронна, налаштовувана.

Дизайн:
- Не плагін - викликається вибірково коли потрібно
- Працює з BaseTreeAdapter або з HTML string
- Thread-safe
"""
from __future__ import annotations

import logging
import re
import threading
from typing import Any, Union

from graph_crawler.shared.utils.markdown.options import MarkdownOptions
from graph_crawler.shared.utils.markdown.result import MarkdownResult
from graph_crawler.shared.utils.markdown.converter import UnifiedMarkdownConverter
from graph_crawler.shared.utils.markdown.adapters import BeautifulSoupAdapter, SelectolaxAdapter

logger = logging.getLogger(__name__)

# Thread-safe lazy import з кешуванням
_parser_lock = threading.Lock()
_parser_cache = {}


def _get_bs4():
    """Thread-safe lazy import BeautifulSoup."""
    if "BeautifulSoup" not in _parser_cache:
        with _parser_lock:
            if "BeautifulSoup" not in _parser_cache:
                from bs4 import BeautifulSoup
                _parser_cache["BeautifulSoup"] = BeautifulSoup
    return _parser_cache["BeautifulSoup"]


# Selectolax availability check
_selectolax_available = False
try:
    from selectolax.parser import HTMLParser as SelectolaxParser
    _selectolax_available = True
except ImportError:
    SelectolaxParser = None


class MarkdownGenerator:
    """
    Генератор Markdown з HTML.
    
    Підтримує:
    - BeautifulSoup (default fallback)
    - Selectolax (~5x швидший, якщо доступний)
    """

    __slots__ = ("options", "_use_selectolax")

    def __init__(self, options: MarkdownOptions | None = None):
        """
        Ініціалізує MarkdownGenerator.

        Args:
            options: Налаштування генерації (опціонально)
        """
        self.options = options or MarkdownOptions()
        
        # Selectolax використовується якщо доступний і не примушено BeautifulSoup
        self._use_selectolax = (
            _selectolax_available 
            and not self.options.force_beautifulsoup
        )

    @staticmethod
    def quick_generate(html: str) -> MarkdownResult:
        """
        Статичний метод для швидкої генерації з дефолтними опціями.

        Для простих випадків коли не потрібна кастомізація.

        Args:
            html: HTML string

        Returns:
            MarkdownResult
        """
        return MarkdownGenerator().generate_from_html(html)

    def generate(self, source: Union[str, Any]) -> MarkdownResult:
        """
        Генерує Markdown з HTML або adapter.

        Універсальний метод - автоматично визначає тип input.

        Args:
            source: HTML string або BaseTreeAdapter

        Returns:
            MarkdownResult з різними варіантами тексту
        """
        if isinstance(source, str):
            return self.generate_from_html(source)

        # Припускаємо що це adapter з методом parse
        if hasattr(source, "tree") and hasattr(source, "find_all"):
            return self.generate_from_adapter(source)

        logger.warning("Unknown source type: %s", type(source))
        return MarkdownResult.empty()

    def generate_from_html(self, html: str) -> MarkdownResult:
        """
        Генерує Markdown з HTML string.

        Основний метод для standalone використання.
        Використовує selectolax якщо доступний, інакше BeautifulSoup.

        Args:
            html: HTML string

        Returns:
            MarkdownResult
        """
        if not html or not html.strip():
            return MarkdownResult.empty()

        try:
            # Вибір парсера: selectolax якщо доступний, інакше BeautifulSoup
            if self._use_selectolax:
                return self._process_selectolax(html)
            else:
                return self._process_beautifulsoup(html)
        except (ValueError, AttributeError, TypeError) as e:
            logger.error("Error generating markdown: %s", e)
            return MarkdownResult.empty()

    def _process_beautifulsoup(self, html: str) -> MarkdownResult:
        """
        Обробляє HTML через BeautifulSoup з UnifiedConverter.
        
        Args:
            html: HTML string
            
        Returns:
            MarkdownResult
        """
        BeautifulSoup = _get_bs4()

        try:
            soup = BeautifulSoup(html, "lxml")
        except ImportError:
            soup = BeautifulSoup(html, "html.parser")

        # Створюємо адаптер та конвертер
        adapter = BeautifulSoupAdapter(soup)
        converter = UnifiedMarkdownConverter(self.options)
        
        # 1. Витягуємо метадані ДО очищення
        title = self._extract_title(soup)
        h1 = self._extract_h1(soup)
        description = self._extract_description(soup)
        
        # 2. Для fit_markdown - очищаємо копію
        clean_soup = BeautifulSoup(str(soup), "lxml" if "lxml" in str(type(soup)) else "html.parser")
        self._remove_noise_optimized(clean_soup)
        
        # 3. Генеруємо fit_markdown через UnifiedConverter
        clean_adapter = BeautifulSoupAdapter(clean_soup)
        fit_markdown, stats = converter.convert(clean_adapter)
        
        # 4. Чистий текст
        text = self._extract_text(clean_soup)
        
        # 5. Застосовуємо dynamic patterns
        text = self._apply_dynamic_patterns(text)
        fit_markdown = self._apply_dynamic_patterns(fit_markdown, preserve_newlines=True)
        
        # 6. Перевірка довжини
        is_truncated = False
        if len(text) > self.options.max_length:
            text = text[: self.options.max_length]
            is_truncated = True
        
        # 7. Citations (якщо потрібно) - НА КОПІЇ soup
        md_citations = ""
        references = []
        if self.options.generate_citations:
            citations_soup = BeautifulSoup(html, "lxml" if "lxml" in str(type(soup)) else "html.parser")
            self._remove_noise_optimized(citations_soup)
            md_citations, references = self._generate_citations(citations_soup)
        
        # 8. Створюємо результат
        result = MarkdownResult(
            text=text,
            fit_markdown=fit_markdown,
            markdown_with_citations=md_citations,
            references=references,
            title=title,
            h1=h1,
            description=description,
            word_count=len(text.split()),
            char_count=len(text),
            heading_count=stats.get("headings", 0),
            link_count=stats.get("links", 0),
            image_count=stats.get("images", 0),
            is_truncated=is_truncated,
        )
        
        # Lazy raw_markdown
        result.set_lazy_raw_markdown(html, self)
        
        return result

    def _process_selectolax(self, html: str) -> MarkdownResult:
        """
        Обробляє HTML через Selectolax з UnifiedConverter (~5x швидше за BeautifulSoup).
        
        Args:
            html: HTML string
            
        Returns:
            MarkdownResult
        """
        # Якщо потрібні citations - використовуємо BeautifulSoup
        # (selectolax не підтримує модифікацію дерева для citations)
        if self.options.generate_citations:
            return self._process_beautifulsoup(html)
        
        try:
            tree = SelectolaxParser(html)
            
            # Створюємо адаптер та конвертер
            converter = UnifiedMarkdownConverter(self.options)
            
            # 1. Витягуємо метадані ДО очищення
            title = self._extract_title_selectolax(tree)
            h1 = self._extract_h1_selectolax(tree)
            description = self._extract_description_selectolax(tree)

            # 2. Для fit_markdown - очищаємо копію
            clean_tree = SelectolaxParser(html)
            self._remove_noise_selectolax(clean_tree)
            
            # 3. Генеруємо fit_markdown через UnifiedConverter
            clean_adapter = SelectolaxAdapter(clean_tree)
            fit_markdown, stats = converter.convert(clean_adapter)

            # 4. Чистий текст
            text = self._extract_text_selectolax(clean_tree)

            # 5. Застосовуємо dynamic patterns
            text = self._apply_dynamic_patterns(text)
            fit_markdown = self._apply_dynamic_patterns(fit_markdown, preserve_newlines=True)

            # 6. Перевірка довжини
            is_truncated = False
            if len(text) > self.options.max_length:
                text = text[: self.options.max_length]
                is_truncated = True

            # Створюємо результат з lazy raw_markdown
            result = MarkdownResult(
                text=text,
                fit_markdown=fit_markdown,
                title=title,
                h1=h1,
                description=description,
                word_count=len(text.split()),
                char_count=len(text),
                heading_count=stats.get("headings", 0),
                link_count=stats.get("links", 0),
                image_count=stats.get("images", 0),
                is_truncated=is_truncated,
            )
            
            # Lazy raw_markdown — генерується тільки при запиті
            result.set_lazy_raw_markdown(html, self)
            
            return result
            
        except Exception as e:
            logger.warning("Selectolax failed, falling back to BeautifulSoup: %s", e)
            return self._process_beautifulsoup(html)

    def _remove_noise_selectolax(self, tree) -> None:
        """
        Видаляє noise елементи з selectolax дерева.
        Оптимізовано: один прохід для всіх тегів.
        """
        # Прохід 1: Важкі теги (script, style, etc.)
        heavy_tags = list(self.options.noise_tags)
        for tag in heavy_tags:
            for node in tree.css(tag):
                node.decompose()

        # Прохід 2: Структурні елементи
        structural = []
        if self.options.remove_nav:
            structural.append('nav')
        if self.options.remove_header:
            structural.append('header')
        if self.options.remove_footer:
            structural.append('footer')
        if self.options.remove_aside:
            structural.append('aside')
        if self.options.remove_buttons:
            structural.append('button')

        for tag in structural:
            for node in tree.css(tag):
                node.decompose()

        # Прохід 3: По класам/id (ads, popups)
        if self.options.remove_ads:
            # Видаляємо елементи з noise класами
            for css_class in self.options.noise_classes:
                for node in tree.css(f'.{css_class}'):
                    node.decompose()
            # Видаляємо елементи з noise id
            for noise_id in self.options.noise_ids:
                for node in tree.css(f'#{noise_id}'):
                    node.decompose()

    def _extract_title_selectolax(self, tree) -> str:
        title_node = tree.css_first('title')
        return title_node.text(strip=True) if title_node else ""

    def _extract_h1_selectolax(self, tree) -> str:
        h1_node = tree.css_first('h1')
        return h1_node.text(strip=True) if h1_node else ""

    def _extract_description_selectolax(self, tree) -> str:
        meta = tree.css_first('meta[name="description"]')
        if meta:
            return meta.attributes.get('content') or ''
        og_meta = tree.css_first('meta[property="og:description"]')
        if og_meta:
            return og_meta.attributes.get('content') or ''
        return ""

    def _extract_text_selectolax(self, tree) -> str:
        """Витягує чистий текст з selectolax дерева."""
        body = tree.css_first('body') or tree.root
        raw = body.text(separator=' ', strip=True) if body else ""
        if self.options.normalize_whitespace:
            return " ".join(raw.split())
        return raw

    def generate_from_adapter(self, adapter: Any) -> MarkdownResult:
        """
        Генерує Markdown з BaseTreeAdapter.

        Серіалізує дерево у HTML і делегує в ``generate_from_html``,
        щоб уся логіка пройшла через ``UnifiedMarkdownConverter``.

        Args:
            adapter: BaseTreeAdapter instance

        Returns:
            MarkdownResult
        """
        try:
            tree = adapter.tree
            if hasattr(tree, "find_all"):  # BeautifulSoup
                html_str = str(tree)
            elif hasattr(tree, "cssselect"):  # lxml
                from lxml import html as lxml_html
                html_str = lxml_html.tostring(tree, encoding="unicode")
            else:
                # Fallback: витягуємо текст через adapter
                text = adapter.text if hasattr(adapter, "text") else ""
                return MarkdownResult(text=text, fit_markdown=text)

            return self.generate_from_html(html_str)

        except (ValueError, AttributeError, TypeError, ImportError) as e:
            logger.error("Error generating markdown from adapter: %s", e)
            return MarkdownResult.empty()

    def _generate_raw_markdown(self, html: str) -> str:
        """
        Генерує raw_markdown з HTML (для lazy generation) через UnifiedConverter.
        Видаляє тільки scripts, зберігає весь інший контент.
        
        Args:
            html: Оригінальний HTML
            
        Returns:
            Raw markdown string
        """
        BeautifulSoup = _get_bs4()
        
        try:
            raw_soup = BeautifulSoup(html, "lxml")
        except ImportError:
            raw_soup = BeautifulSoup(html, "html.parser")
            
        self._remove_scripts_only(raw_soup)
        
        # Використовуємо UnifiedConverter
        adapter = BeautifulSoupAdapter(raw_soup)
        converter = UnifiedMarkdownConverter(self.options)
        raw_markdown, _ = converter.convert(adapter)
        
        return raw_markdown

    def _remove_scripts_only(self, soup) -> None:
        """
        Видаляє тільки технічні теги (scripts, styles).

        Для raw_markdown - зберігаємо весь контент крім скриптів.

        Args:
            soup: BeautifulSoup object
        """
        for tag_name in ("script", "style", "noscript", "template"):
            for tag in soup.find_all(tag_name):
                tag.decompose()

    def _remove_noise_optimized(self, soup) -> None:
        """
        Видаляє noise елементи з soup оптимізовано.
        Групує видалення по типах для мінімізації проходів.

        Args:
            soup: BeautifulSoup object
        """
        # Прохід 1: Великі блоки (мають багато вкладень, видаляємо разом)
        heavy_tags = list(self.options.noise_tags)
        for tag in soup.find_all(heavy_tags):
            tag.decompose()

        # Прохід 2: Структурні елементи (якщо опції дозволяють)
        structural = []
        if self.options.remove_nav:
            structural.append('nav')
        if self.options.remove_header:
            structural.append('header')
        if self.options.remove_footer:
            structural.append('footer')
        if self.options.remove_aside:
            structural.append('aside')
        if self.options.remove_buttons:
            structural.append('button')
        if self.options.remove_forms:
            structural.append('form')

        if structural:
            for tag in soup.find_all(structural):
                tag.decompose()

        # Прохід 3: По класам/id (один прохід з фільтром)
        if self.options.remove_ads:
            def should_remove(tag):
                if not hasattr(tag, "get") or tag.get is None:
                    return False
                try:
                    # Перевірка класів
                    classes = tag.get("class", [])
                    if classes:
                        class_set = {c.lower() for c in classes}
                        if class_set & self.options.noise_classes:
                            return True
                    # Перевірка ID
                    tag_id = tag.get("id", "")
                    if tag_id:
                        id_lower = tag_id.lower()
                        if id_lower in self.options.noise_ids:
                            return True
                except (AttributeError, TypeError):
                    return False
                return False

            for tag in soup.find_all(
                lambda t: hasattr(t, "get") and (t.get("class") or t.get("id"))
            ):
                if should_remove(tag):
                    tag.decompose()

    def _apply_dynamic_patterns(self, text: str, preserve_newlines: bool = False) -> str:
        """
        Видаляє текст по regex патернам (dynamic noise patterns).

        Args:
            text: Текст для очищення
            preserve_newlines: якщо True — не схлопуємо ``\\n`` в пробіли
                (потрібно для ``fit_markdown`` — інакше втрачається структура).

        Returns:
            Очищений текст
        """
        if not self.options.dynamic_noise_patterns:
            return text

        for pattern in self.options.dynamic_noise_patterns:
            try:
                text = re.sub(pattern, '', text)
            except re.error as e:
                logger.warning("Invalid regex pattern '%s': %s", pattern, e)

        # Нормалізуємо пробіли після видалення
        if self.options.normalize_whitespace:
            if preserve_newlines:
                # Зберігаємо CommonMark hard break (`  \n`) до нормалізації
                placeholder = "\x00HARDBREAK\x00"
                text = re.sub(r' {2,}\n', placeholder, text)
                # Схлопуємо лише горизонтальні пробіли, переноси зберігаємо.
                text = re.sub(r'[ \t]+', ' ', text)
                text = re.sub(r' *\n *', '\n', text)
                text = re.sub(r'\n{3,}', '\n\n', text)
                text = text.replace(placeholder, "  \n")
                return text.strip()
            return ' '.join(text.split())
        return text

    def _extract_text(self, soup) -> str:
        """
        Витягує чистий текст з soup.

        Args:
            soup: BeautifulSoup object

        Returns:
            Clean text string
        """
        raw = soup.get_text(separator=" ", strip=True)

        if self.options.normalize_whitespace:
            return " ".join(raw.split())
        return raw

    def _extract_title(self, soup) -> str:
        title_tag = soup.find("title")
        return title_tag.get_text(strip=True) if title_tag else ""

    def _extract_h1(self, soup) -> str:
        h1_tag = soup.find("h1")
        return h1_tag.get_text(strip=True) if h1_tag else ""

    def _extract_description(self, soup) -> str:
        meta = soup.find("meta", attrs={"name": "description"})
        if meta:
            return meta.get("content", "")

        # Fallback: og:description
        og_meta = soup.find("meta", attrs={"property": "og:description"})
        if og_meta:
            return og_meta.get("content", "")

        return ""

    def _generate_citations(self, soup) -> tuple[str, list[dict[str, str]]]:
        """
        Генерує Markdown з citations [1], [2].

        Працює на копії soup, не модифікує оригінал.

        Args:
            soup: BeautifulSoup object (копія)

        Returns:
            tuple[markdown_with_citations, references_list]
        """
        references = []
        ref_counter = 1

        # Знаходимо всі посилання
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            text = a.get_text(strip=True)

            if href and text and not href.startswith("#"):
                references.append(
                    {
                        "id": ref_counter,
                        "text": text,
                        "url": href,
                    }
                )
                # Замінюємо посилання на citation
                a.replace_with(f"{text} [{ref_counter}]")
                ref_counter += 1

        # Генеруємо markdown через UnifiedConverter
        adapter = BeautifulSoupAdapter(soup)
        converter = UnifiedMarkdownConverter(self.options)
        md, _ = converter.convert(adapter)

        # Додаємо references в кінці
        if references:
            md += "\n\n## References\n\n"
            for ref in references:
                md += f"[{ref['id']}] {ref['url']}\n"

        return md, references


# Async версія для асинхронного використання
async def generate_markdown_async(
    html: str,
    options: MarkdownOptions | None = None,
) -> MarkdownResult:
    """
    Асинхронна генерація Markdown.

    Виконується в thread executor для non-blocking операції.
    Сумісно з Python 3.9+.

    Args:
        html: HTML string
        options: MarkdownOptions (опціонально)

    Returns:
        MarkdownResult
    """
    import asyncio

    generator = MarkdownGenerator(options)

    # Python 3.9+ compatible
    try:
        # Preferred method for Python 3.9+
        return await asyncio.to_thread(generator.generate_from_html, html)
    except AttributeError:
        # Fallback for older Python versions
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            generator.generate_from_html,
            html,
        )
