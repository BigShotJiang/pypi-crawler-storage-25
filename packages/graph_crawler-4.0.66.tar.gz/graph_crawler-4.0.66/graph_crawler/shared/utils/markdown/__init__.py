"""Markdown Generation Utilities.

Standalone модуль для генерації Markdown з HTML.
Використовується вибірково - Node класи вирішують коли викликати.

Приклад використання:
    >>> from graph_crawler.shared.utils.markdown import MarkdownGenerator, MarkdownOptions
    >>>
    >>> # В кастомному Node (як JobsNode)
    >>> if self.is_jobs_url:  # Тільки для потрібних сторінок!
    ...     md = MarkdownGenerator()
    ...     result = md.generate(context.html)
    ...     self.text = result.text
    ...     self.text_markdown = result.fit_markdown
    
    >>> # З selectolax (автоматично якщо встановлено)
    >>> md = MarkdownGenerator()  # Використовує selectolax якщо доступний
    
    >>> # Примусово BeautifulSoup
    >>> md = MarkdownGenerator(MarkdownOptions(force_beautifulsoup=True))
    
    >>> # З dynamic noise patterns
    >>> from graph_crawler.shared.utils.markdown import COMMON_NOISE_PATTERNS
    >>> md = MarkdownGenerator(MarkdownOptions(
    ...     dynamic_noise_patterns=COMMON_NOISE_PATTERNS
    ... ))
"""

from graph_crawler.shared.utils.markdown.generator import (
    MarkdownGenerator,
    generate_markdown_async,
)
from graph_crawler.shared.utils.markdown.options import (
    MarkdownOptions,
    COMMON_NOISE_PATTERNS,
)
from graph_crawler.shared.utils.markdown.result import MarkdownResult
from graph_crawler.shared.utils.markdown.renderer import MarkdownRenderer
from graph_crawler.shared.utils.markdown import ast as mdast

__all__ = [
    "MarkdownGenerator",
    "MarkdownOptions",
    "MarkdownResult",
    "MarkdownRenderer",
    "mdast",
    "generate_markdown_async",
    "COMMON_NOISE_PATTERNS",
]
