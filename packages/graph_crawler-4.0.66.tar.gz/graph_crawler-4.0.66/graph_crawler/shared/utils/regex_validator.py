"""
Комплексна валідація regex патернів.

Цей модуль надає повну валідацію regex патернів з детальними
попередженнями та рекомендаціями для користувачів.

Підтримує два рівні повідомлень:
- Простий (beginner): зрозуміле пояснення без технічного жаргону
- Технічний (expert): повні деталі для досвідчених розробників

Підтримувані перевірки:
- Валідність regex синтаксису
- Неекрановані спеціальні символи (., $, ^, [], (), |, *, +, ?)
- Незбалансовані дужки та квадратні дужки
- Порожні групи та класи символів
- Неправильне використання квантифікаторів
- Потенційні проблеми продуктивності (catastrophic backtracking)

Author: GraphCrawler Team
Version: 1.1.0
"""
from __future__ import annotations

import logging
import re
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable


logger = logging.getLogger(__name__)


class ValidationSeverity(str, Enum):
    """Рівень серйозності проблеми."""
    ERROR = "error"      # Критична помилка - патерн не працюватиме
    WARNING = "warning"  # Попередження - патерн може працювати некоректно
    INFO = "info"        # Інформаційне повідомлення


@dataclass
class ValidationIssue:
    """Проблема знайдена при валідації regex."""
    severity: ValidationSeverity
    code: str
    message: str
    position: int | None = None
    suggestion: str | None = None
    examples: list[str] = field(default_factory=list)
    # Просте пояснення для користувачів без знання regex
    simple_message: str | None = None


@dataclass
class ValidationResult:
    """Результат валідації regex патерну."""
    pattern: str
    is_valid: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    
    def has_errors(self) -> bool:
        """Перевіряє чи є критичні помилки."""
        return any(issue.severity == ValidationSeverity.ERROR for issue in self.issues)
    
    def has_warnings(self) -> bool:
        """Перевіряє чи є попередження."""
        return any(issue.severity == ValidationSeverity.WARNING for issue in self.issues)
    
    def format_message(
        self,
        include_examples: bool = True,
        user_level: str = "auto",
    ) -> str:
        """
        Форматує повідомлення про всі знайдені проблеми.

        Args:
            include_examples: Чи включати приклади правильного використання.
            user_level: Рівень деталізації повідомлень:
                - ``"beginner"`` — просте пояснення без технічного жаргону.
                  Підходить для тих, хто не знає що таке regex.
                - ``"expert"``  — повні технічні деталі для розробників.
                - ``"auto"``    — спочатку просте пояснення, потім технічні
                  деталі (за замовчуванням).

        Returns:
            Відформатоване повідомлення.

        Examples:
            >>> result = validate_regex_pattern(r'.pdf$', warn_on_issues=False)
            >>> print(result.format_message(user_level="beginner"))
            >>> print(result.format_message(user_level="expert"))
        """
        if not self.issues:
            return ""

        severity_icon = {
            ValidationSeverity.ERROR: "❌",
            ValidationSeverity.WARNING: "⚠️",
            ValidationSeverity.INFO: "ℹ️",
        }

        # ── Режим: тільки для новачків ───────────────────────────────────────
        if user_level == "beginner":
            lines = [
                f"Перевірка фільтру: '{self.pattern}'",
                "",
            ]
            for issue in self.issues:
                icon = severity_icon.get(issue.severity, "•")
                text = issue.simple_message or issue.message
                lines.append(f"{icon} {text}")
                if issue.suggestion and not issue.simple_message:
                    # Якщо немає спрощеного тексту — показуємо підказку
                    lines.append(f"   Підказка: {issue.suggestion}")
                if include_examples and issue.examples and not issue.simple_message:
                    for example in issue.examples:
                        lines.append(f"   {example}")
                lines.append("")
            return "\n".join(lines)

        # ── Режим: тільки для експертів ─────────────────────────────────────
        if user_level == "expert":
            lines = [f"🔍 Валідація regex патерну: '{self.pattern}'", ""]
            for issue in self.issues:
                icon = severity_icon.get(issue.severity, "•")
                lines.append(f"{icon} [{issue.code}] {issue.message}")
                if issue.position is not None:
                    lines.append(f"   📍 Позиція: {issue.position}")
                if issue.suggestion:
                    lines.append(f"   💡 Рекомендація: {issue.suggestion}")
                if include_examples and issue.examples:
                    lines.append("   📚 Приклади:")
                    for example in issue.examples:
                        lines.append(f"      {example}")
                lines.append("")
            return "\n".join(lines)

        # ── Режим: auto — обидва рівні ────────────────────────────────────────
        lines = [f"🔍 Перевірка патерну: '{self.pattern}'", ""]
        for issue in self.issues:
            icon = severity_icon.get(issue.severity, "•")

            # Спочатку просте пояснення
            if issue.simple_message:
                lines.append(f"{icon} {issue.simple_message}")
                lines.append(f"   ─── Технічні деталі: [{issue.code}] {issue.message}")
            else:
                lines.append(f"{icon} [{issue.code}] {issue.message}")

            if issue.position is not None:
                lines.append(f"   📍 Позиція: {issue.position}")

            if issue.suggestion:
                lines.append(f"   💡 {issue.suggestion}")

            if include_examples and issue.examples:
                lines.append("   📚 Приклади:")
                for example in issue.examples:
                    lines.append(f"      {example}")

            lines.append("")
        return "\n".join(lines)


# ===== Список розширень файлів для перевірки =====
FILE_EXTENSIONS = (
    'pdf', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'ico', 'bmp', 'tiff',
    'css', 'js', 'mjs', 'ts', 'tsx', 'jsx',
    'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods',
    'zip', 'rar', 'tar', 'gz', '7z', 'bz2',
    'exe', 'dmg', 'msi', 'deb', 'rpm',
    'html', 'htm', 'xml', 'json', 'yaml', 'yml', 'md', 'txt',
    'mp4', 'mp3', 'wav', 'avi', 'mkv', 'webm', 'ogg', 'flac',
    'woff', 'woff2', 'ttf', 'eot', 'otf',
    'php', 'asp', 'aspx', 'jsp', 'py', 'rb', 'pl',
)


def _check_regex_syntax(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє валідність regex синтаксису.
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    try:
        re.compile(pattern)
    except re.error as e:
        issues.append(ValidationIssue(
            severity=ValidationSeverity.ERROR,
            code="INVALID_REGEX",
            message=f"Невалідний regex синтаксис: {e}",
            position=e.pos if hasattr(e, 'pos') else None,
            suggestion="Перевірте синтаксис регулярного виразу",
            examples=[
                "Документація: https://docs.python.org/3/library/re.html"
            ],
            simple_message=(
                f"Фільтр '{pattern}' містить помилку і не буде працювати взагалі. "
                "Перевірте, чи правильно розставлені всі дужки та спеціальні символи."
            ),
        ))
    
    return issues


def _check_unescaped_dot_before_extension(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє неекрановані крапки перед розширеннями файлів.
    
    Патерн типу `.pdf$` або `.(jpg|png)$` без екранування крапки -
    це дуже поширена помилка!
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Паттерн 1: Крапка на початку без екранування перед розширенням/групою
    # Приклади: .pdf$, .(jpg|png)$, .css$
    if re.match(r'^\.(?:\(|[a-z])', pattern) and not pattern.startswith('\\.'):
        # Визначаємо що саме йде після крапки
        after_dot = pattern[1:]
        
        # Якщо це група розширень
        if after_dot.startswith('('):
            match = re.match(r'^\(([^)]+)\)', after_dot)
            if match:
                extensions = match.group(1)
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="UNESCAPED_DOT_GROUP",
                    message=f"Неекранована крапка перед групою розширень '({extensions})'",
                    position=0,
                    suggestion="Крапка '.' в regex означає 'БУДЬ-ЯКИЙ символ'. Для буквальної крапки використовуйте '\\.'",
                    examples=[
                        f"❌ НЕправильно: r'{pattern}'",
                        f"   Зматчить: 'X{extensions.split('|')[0]}', '1{extensions.split('|')[0]}' - будь-який символ перед розширенням!",
                        f"✅ Правильно:   r'\\.{after_dot}'",
                        f"   Зматчить тільки: '.{extensions.split('|')[0]}', '.{extensions.split('|')[-1]}' і т.д.",
                    ],
                    simple_message=(
                        f"Увага! Фільтр '{pattern}' може спрацювати неправильно.\n"
                        f"   Він збігатиметься з адресами де перед розширенням стоїть БУДЬ-ЯКИЙ символ,\n"
                        f"   а не лише крапка (наприклад: 'X{extensions.split('|')[0]}', '1{extensions.split('|')[0]}').\n"
                        f"   Виправте: замініть '{pattern}' на r'\\.{after_dot}'"
                    ),
                ))
        else:
            # Просте розширення
            ext_match = re.match(r'^[a-z]+', after_dot, re.IGNORECASE)
            if ext_match:
                ext = ext_match.group()
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="UNESCAPED_DOT_EXTENSION",
                    message=f"Неекранована крапка перед розширенням '{ext}'",
                    position=0,
                    suggestion="Крапка '.' в regex означає 'БУДЬ-ЯКИЙ символ'. Для буквальної крапки використовуйте '\\.'",
                    examples=[
                        f"❌ НЕправильно: r'{pattern}'",
                        f"   Зматчить: 'X{ext}', '1{ext}', 'A{ext}' - НЕ тільки '.{ext}'!",
                        f"✅ Правильно:   r'\\.{after_dot}'",
                        f"   Зматчить тільки: '.{ext}'",
                    ],
                    simple_message=(
                        f"Увага! Фільтр '{pattern}' може спрацювати неправильно.\n"
                        f"   Він збігатиметься з 'X{ext}', '1{ext}' та іншими, а не лише з '.{ext}'.\n"
                        f"   Виправте: використовуйте r'\\.{after_dot}' замість r'{pattern}'"
                    ),
                ))
    
    # Паттерн 2: Крапка всередині патерну без екранування перед розширенням
    for i, char in enumerate(pattern):
        if char == '.' and i > 0:
            # Перевіряємо чи попередній символ НЕ бекслеш
            if pattern[i - 1] != '\\':
                rest = pattern[i + 1:] if i + 1 < len(pattern) else ""
                
                # Перевіряємо чи далі йде щось схоже на розширення файлу
                ext_match = re.match(
                    r'^(?:\()?(' + '|'.join(FILE_EXTENSIONS) + r')(?:\)|\||$|\$)',
                    rest,
                    re.IGNORECASE
                )
                if ext_match:
                    ext = ext_match.group(1)
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        code="UNESCAPED_DOT_MIDDLE",
                        message=f"Можлива помилка: неекранована крапка перед '{ext}' на позиції {i}",
                        position=i,
                        suggestion="Якщо ви хочете матчити буквальну крапку, використовуйте '\\.'",
                        examples=[
                            f"❌ Поточний патерн: r'{pattern}'",
                            f"   Крапка на позиції {i} матчить будь-який символ",
                            f"✅ Для буквальної крапки: замініть '.' на '\\.' на позиції {i}",
                        ],
                        simple_message=(
                            f"Увага! У фільтрі '{pattern}' крапка перед '{ext}' збігається з БУДЬ-ЯКИМ символом.\n"
                            f"   Якщо ви хочете фільтрувати саме файли '.{ext}', "
                            f"замініть '.' на '\\.' у вашому фільтрі."
                        ),
                    ))
                    break  # Показуємо тільки перше попередження
    
    return issues


def _check_unescaped_special_chars(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє потенційно неекрановані спеціальні символи.
    
    Символи: $ ^ | 
    (Для дужок та квадратних дужок є окремі перевірки)
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Перевірка $ не в кінці (може бути помилка)
    for i, char in enumerate(pattern):
        if char == '$':
            # $ в кінці - це нормально (якір кінця рядка)
            if i < len(pattern) - 1:
                # $ не в кінці - перевіряємо чи це не екрановано
                if i == 0 or pattern[i - 1] != '\\':
                    # Якщо далі йде ще щось крім дужки групи
                    rest = pattern[i + 1:]
                    if rest and not rest.startswith((')', '|')):
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.INFO,
                            code="DOLLAR_NOT_AT_END",
                            message=f"Символ '$' на позиції {i} не в кінці патерну",
                            position=i,
                            suggestion="'$' зазвичай використовується як якір кінця рядка. Якщо ви хочете буквальний символ '$', екрануйте його: '\\$'",
                            examples=[
                                "Якір кінця рядка: r'pattern$'",
                                "Буквальний $: r'price\\$100'",
                            ],
                            simple_message=(
                                f"Примітка: символ '$' у вашому фільтрі стоїть не в кінці. "
                                "Зазвичай '$' позначає 'кінець адреси'. "
                                "Якщо вам потрібен знак долара як символ — напишіть '\\$'."
                            ),
                        ))
        
        elif char == '^':
            # ^ на початку - це нормально (якір початку рядка)
            # ^ всередині [] - це заперечення
            if i > 0:
                # Перевіряємо чи не в character class
                in_char_class = False
                for j in range(i - 1, -1, -1):
                    if pattern[j] == '[' and (j == 0 or pattern[j - 1] != '\\'):
                        in_char_class = True
                        break
                    if pattern[j] == ']' and (j == 0 or pattern[j - 1] != '\\'):
                        break
                
                if not in_char_class and (i == 0 or pattern[i - 1] != '\\'):
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.INFO,
                        code="CARET_NOT_AT_START",
                        message=f"Символ '^' на позиції {i} не на початку патерну",
                        position=i,
                        suggestion="'^' зазвичай використовується як якір початку рядка. Якщо ви хочете буквальний символ '^', екрануйте його: '\\^'",
                        examples=[
                            "Якір початку рядка: r'^pattern'",
                            "Буквальний ^: r'2\\^10'",
                        ],
                        simple_message=(
                            f"Примітка: символ '^' у вашому фільтрі стоїть не на початку. "
                            "Зазвичай '^' означає 'початок адреси'. "
                            "Якщо вам потрібен сам символ '^' — напишіть '\\^'."
                        ),
                    ))
    
    return issues


def _check_brackets_balance(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє збалансованість дужок та квадратних дужок.
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Стек для відстеження дужок
    paren_stack = []  # Для ()
    bracket_stack = []  # Для []
    
    i = 0
    while i < len(pattern):
        char = pattern[i]
        
        # Пропускаємо екрановані символи
        if char == '\\' and i + 1 < len(pattern):
            i += 2
            continue
        
        # Круглі дужки
        if char == '(':
            paren_stack.append(i)
        elif char == ')':
            if not paren_stack:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="UNMATCHED_CLOSE_PAREN",
                    message=f"Непарна закриваюча дужка ')' на позиції {i}",
                    position=i,
                    suggestion="Додайте відповідну відкриваючу дужку '(' або екрануйте: '\\)'",
                    examples=[
                        "Група: r'(pattern)'",
                        "Буквальна дужка: r'func\\(\\)'",
                    ],
                    simple_message=(
                        f"У фільтрі '{pattern}' є зайва закриваюча дужка ')'. "
                        "Кожна ')' повинна мати відповідну '(' перед нею."
                    ),
                ))
            else:
                paren_stack.pop()
        
        # Квадратні дужки
        if char == '[':
            bracket_stack.append(i)
        elif char == ']':
            if not bracket_stack:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="UNMATCHED_CLOSE_BRACKET",
                    message=f"Непарна закриваюча дужка ']' на позиції {i}",
                    position=i,
                    suggestion="Додайте відповідну відкриваючу дужку '[' або екрануйте: '\\]'",
                    examples=[
                        "Клас символів: r'[a-z]'",
                        "Буквальна дужка: r'array\\[0\\]'",
                    ],
                    simple_message=(
                        f"У фільтрі '{pattern}' є зайва закриваюча квадратна дужка ']'. "
                        "Кожна ']' повинна мати відповідну '[' перед нею."
                    ),
                ))
            else:
                bracket_stack.pop()
        
        i += 1
    
    # Перевіряємо незакриті дужки
    for pos in paren_stack:
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="UNMATCHED_OPEN_PAREN",
            message=f"Незакрита відкриваюча дужка '(' на позиції {pos}",
            position=pos,
            suggestion="Додайте відповідну закриваючу дужку ')' або екрануйте: '\\('",
            examples=[
                "Група: r'(pattern)'",
                "Буквальна дужка: r'func\\(arg\\)'",
            ],
            simple_message=(
                f"У фільтрі '{pattern}' є незакрита дужка '('. "
                "Кожна '(' повинна мати відповідну ')' після неї."
            ),
        ))
    
    for pos in bracket_stack:
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="UNMATCHED_OPEN_BRACKET",
            message=f"Незакрита відкриваюча дужка '[' на позиції {pos}",
            position=pos,
            suggestion="Додайте відповідну закриваючу дужку ']' або екрануйте: '\\['",
            examples=[
                "Клас символів: r'[a-z0-9]'",
                "Буквальна дужка: r'array\\[index\\]'",
            ],
            simple_message=(
                f"У фільтрі '{pattern}' є незакрита квадратна дужка '['. "
                "Кожна '[' повинна мати відповідну ']' після неї."
            ),
        ))
    
    return issues


def _check_empty_groups(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє порожні групи та класи символів.
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Порожня група ()
    for match in re.finditer(r'(?<!\\)\(\)', pattern):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="EMPTY_GROUP",
            message=f"Порожня група '()' на позиції {match.start()}",
            position=match.start(),
            suggestion="Порожня група не має сенсу. Якщо ви хочете буквальні дужки, екрануйте їх: '\\(\\)'",
            examples=[
                "Група з контентом: r'(pattern)'",
                "Буквальні дужки: r'func\\(\\)'",
            ],
            simple_message=(
                f"У фільтрі '{pattern}' є порожні дужки '()' — вони нічого не роблять. "
                "Або додайте вміст всередину, або видаліть їх."
            ),
        ))
    
    # Порожній клас символів [] - хоча це валідний regex, він нічого не матчить
    for match in re.finditer(r'(?<!\\)\[\]', pattern):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="EMPTY_CHAR_CLASS",
            message=f"Порожній клас символів '[]' на позиції {match.start()}",
            position=match.start(),
            suggestion="Порожній клас символів нічого не матчить. Якщо ви хочете буквальні дужки, екрануйте їх: '\\[\\]'",
            examples=[
                "Клас символів: r'[a-z]'",
                "Буквальні дужки: r'array\\[\\]'",
            ],
            simple_message=(
                f"У фільтрі '{pattern}' є порожні квадратні дужки '[]' — вони не збігатимуться ні з чим. "
                "Якщо потрібні самі дужки як символи — напишіть '\\[\\]'."
            ),
        ))
    
    return issues


def _check_quantifier_issues(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє проблеми з квантифікаторами.
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Квантифікатор на початку патерну (помилка)
    if pattern and pattern[0] in '*+?':
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="QUANTIFIER_AT_START",
            message=f"Квантифікатор '{pattern[0]}' на початку патерну",
            position=0,
            suggestion="Квантифікатор має бути після елемента який він кількісно визначає",
            examples=[
                "Правильно: r'a+' - один або більше 'a'",
                "Буквальний символ: r'\\*' або r'\\+'",
            ],
            simple_message=(
                f"Фільтр '{pattern}' починається зі спеціального символу '{pattern[0]}', "
                "що є помилкою. Такий символ повинен стояти після того, що він описує."
            ),
        ))
    
    # Подвійний квантифікатор (типу ** або ++)
    for match in re.finditer(r'(?<!\\)([*+?])\1', pattern):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="DOUBLE_QUANTIFIER",
            message=f"Подвійний квантифікатор '{match.group()}' на позиції {match.start()}",
            position=match.start(),
            suggestion="Подвійні квантифікатори зазвичай є помилкою",
            examples=[
                "Один квантифікатор: r'a+' замість r'a++'",
                "Possessive quantifier (якщо підтримується): r'a++' - але краще уникати",
            ],
            simple_message=(
                f"У фільтрі '{pattern}' є подвоєний символ '{match.group()}' — "
                "це зазвичай помилка. Достатньо одного такого символу."
            ),
        ))
    
    # Потенційний catastrophic backtracking (вкладені квантифікатори)
    for match in re.finditer(r'\([^)]*[*+][^)]*\)[*+]', pattern):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="NESTED_QUANTIFIERS",
            message=f"Вкладені квантифікатори можуть призвести до catastrophic backtracking: '{match.group()}'",
            position=match.start(),
            suggestion="Спростіть патерн або використайте atomic groups/possessive quantifiers",
            examples=[
                "❌ Небезпечно: r'(a+)+'",
                "✅ Безпечніше: r'a+' або r'(?:a+)' з обмеженням",
            ],
            simple_message=(
                f"Фільтр '{pattern}' містить складну конструкцію, яка може "
                "суттєво сповільнити сканування на деяких сторінках. "
                "Розгляньте можливість спростити цей фільтр."
            ),
        ))
    
    return issues


def _check_alternation_issues(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє проблеми з альтернацією (|).
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Порожня альтернатива
    # |pattern або pattern| або pattern||pattern
    
    # | на початку
    if pattern.startswith('|'):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="EMPTY_ALTERNATIVE_START",
            message="Порожня альтернатива на початку патерну",
            position=0,
            suggestion="Порожня альтернатива матчить порожній рядок. Якщо це не навмисно, видаліть '|'",
            examples=[
                "❌ r'|pattern' - матчить '' або 'pattern'",
                "✅ r'pattern' - матчить тільки 'pattern'",
            ],
            simple_message=(
                f"Фільтр '{pattern}' починається з '|' — це означає, що він збігатиметься "
                "також з порожнім рядком. Якщо це не те що ви хотіли — видаліть '|' з початку."
            ),
        ))
    
    # | в кінці
    if pattern.endswith('|') and not pattern.endswith('\\|'):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="EMPTY_ALTERNATIVE_END",
            message="Порожня альтернатива в кінці патерну",
            position=len(pattern) - 1,
            suggestion="Порожня альтернатива матчить порожній рядок. Якщо це не навмисно, видаліть '|'",
            examples=[
                "❌ r'pattern|' - матчить 'pattern' або ''",
                "✅ r'pattern' - матчить тільки 'pattern'",
            ],
            simple_message=(
                f"Фільтр '{pattern}' закінчується на '|' — це означає, що він збігатиметься "
                "також з порожнім рядком. Якщо це помилка — видаліть '|' з кінця."
            ),
        ))
    
    # || (подвійна альтернація)
    for match in re.finditer(r'(?<!\\)\|\|', pattern):
        issues.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="DOUBLE_ALTERNATION",
            message=f"Подвійна альтернація '||' на позиції {match.start()}",
            position=match.start(),
            suggestion="Подвійна альтернація створює порожню альтернативу між ними",
            examples=[
                "❌ r'a||b' - матчить 'a', '' або 'b'",
                "✅ r'a|b' - матчить 'a' або 'b'",
            ],
            simple_message=(
                f"У фільтрі '{pattern}' є подвоєний символ '||' — це схоже на помилку. "
                "Замість '||' використовуйте один '|'."
            ),
        ))
    
    return issues


def _check_common_mistakes(pattern: str) -> list[ValidationIssue]:
    """
    Перевіряє типові помилки користувачів.
    
    Args:
        pattern: Regex патерн
        
    Returns:
        Список знайдених проблем
    """
    issues = []
    
    # Неекранований ? в URL query патернах
    # Приклад: /page?id=123 замість /page\?id=123
    if '?' in pattern and '\\?' not in pattern:
        # Перевіряємо чи це схоже на URL query
        if re.search(r'\?[a-zA-Z_]+=', pattern):
            issues.append(ValidationIssue(
                severity=ValidationSeverity.INFO,
                code="URL_QUERY_PATTERN",
                message="Патерн схожий на URL з query параметрами",
                suggestion="'?' в regex означає 'опціональний'. Для URL query використовуйте '\\?'",
                examples=[
                    "❌ r'/page?id=\\d+' - '?' робить 'e' опціональним",
                    "✅ r'/page\\?id=\\d+' - матчить буквально '/page?id=...'",
                ],
                simple_message=(
                    f"Фільтр '{pattern}' схожий на адресу із запитом (наприклад: '/page?id=123'). "
                    "Знак '?' тут обробляється особливим чином — він робить попередню літеру необов'язковою. "
                    "Щоб фільтрувати саме такі адреси, замініть '?' на '\\?'."
                ),
            ))
    
    # Невикористані іменовані групи
    named_groups = re.findall(r'\?P<([^>]+)>', pattern)
    if named_groups:
        # Просто інформаційне повідомлення
        issues.append(ValidationIssue(
            severity=ValidationSeverity.INFO,
            code="NAMED_GROUPS_FOUND",
            message=f"Знайдено іменовані групи: {', '.join(named_groups)}",
            suggestion="Переконайтесь, що ви використовуєте ці групи в коді",
            examples=[
                "import re",
                f"match = re.search(r'{pattern}', text)",
                f"value = match.group('{named_groups[0]}') if match else None",
            ],
            simple_message=None,  # Ця перевірка тільки для розробників
        ))
    
    # Використання \d, \w, \s - це добре, просто інформуємо
    # (пропускаємо, бо це не помилка)
    
    return issues


def validate_regex_pattern(
    pattern: str,
    context: str = "URL фільтрація",
    raise_on_error: bool = True,
    warn_on_issues: bool = True,
    user_level: str = "auto",
) -> ValidationResult:
    """
    Комплексна валідація regex патерну.
    
    Виконує всі перевірки та повертає детальний результат.
    
    Args:
        pattern: Regex патерн для валідації
        context: Контекст використання (для кращих повідомлень)
        raise_on_error: Чи викидати ValueError при критичних помилках
        warn_on_issues: Чи виводити warnings.warn при знайдених проблемах
        user_level: Рівень деталізації повідомлень (``"beginner"``,
            ``"expert"``, ``"auto"``). Передається в ``format_message``.
            
    Returns:
        ValidationResult з детальною інформацією
        
    Raises:
        ValueError: Якщо raise_on_error=True і патерн невалідний
        
    Example:
        >>> # Для новачків — прості пояснення
        >>> result = validate_regex_pattern(r'.pdf$', user_level='beginner')
        >>> # Для експертів — технічні деталі
        >>> result = validate_regex_pattern(r'.pdf$', user_level='expert')
        >>> # За замовчуванням — обидва рівні
        >>> result = validate_regex_pattern(r'.pdf$')
        >>> if result.has_warnings():
        ...     print(result.format_message())
    """
    all_issues: list[ValidationIssue] = []
    
    # Виконуємо всі перевірки
    checkers: list[Callable[[str], list[ValidationIssue]]] = [
        _check_regex_syntax,
        _check_unescaped_dot_before_extension,
        _check_unescaped_special_chars,
        _check_brackets_balance,
        _check_empty_groups,
        _check_quantifier_issues,
        _check_alternation_issues,
        _check_common_mistakes,
    ]
    
    for checker in checkers:
        all_issues.extend(checker(pattern))
    
    result = ValidationResult(
        pattern=pattern,
        is_valid=not any(
            issue.severity == ValidationSeverity.ERROR 
            for issue in all_issues
        ),
        issues=all_issues
    )
    
    # Обробка помилок та попереджень
    if result.has_errors():
        error_msg = result.format_message(user_level=user_level)
        logger.error(error_msg)
        if raise_on_error:
            first_error = next(
                issue for issue in all_issues 
                if issue.severity == ValidationSeverity.ERROR
            )
            raise ValueError(f"Невалідний regex патерн '{pattern}': {first_error.message}")
    
    if warn_on_issues and result.has_warnings():
        warning_msg = result.format_message(user_level=user_level)
        logger.warning(warning_msg)
        warnings.warn(warning_msg, UserWarning, stacklevel=3)
    
    return result


def suggest_fix(pattern: str) -> str | None:
    """
    Пропонує виправлення для патерну з типовими помилками.
    
    Args:
        pattern: Патерн з потенційними помилками
        
    Returns:
        Виправлений патерн або None якщо виправлення не потрібне
        
    Example:
        >>> suggest_fix(r'.pdf$')
        '\\.pdf$'
        >>> suggest_fix(r'\\.(jpg|png)$')  # Вже правильний
        None
    """
    original = pattern
    fixed = pattern
    
    # Виправлення 1: Крапка на початку перед розширенням
    if re.match(r'^\.(?:\(|[a-z])', pattern) and not pattern.startswith('\\.'):
        fixed = '\\' + fixed
    
    # Виправлення 2: ? в URL query патернах
    if re.search(r'(?<!\\)\?[a-zA-Z_]+=', fixed):
        # Замінюємо неекрановані ? перед параметрами
        fixed = re.sub(r'(?<!\\)\?(?=[a-zA-Z_]+=)', r'\\?', fixed)
    
    return fixed if fixed != original else None


# ===== Експортовані функції та класи =====
__all__ = [
    'ValidationSeverity',
    'ValidationIssue',
    'ValidationResult',
    'validate_regex_pattern',
    'suggest_fix',
]
