"""Engine Plugins - плагіни рівня ядра краулера.

Engine плагіни впливають на всю систему краулінгу:
- Anti-bot обхід (Cloudflare, Akamai, DataDome)
- CAPTCHA розв'язувач
- Stealth режим

Example:
    >>> from graph_crawler.extensions.plugins.engine import (
    ...     AntiBotStealthPlugin,
    ...     AntiBotPlaywrightPlugin,
    ...     AntiBotDetectionPlugin,
    ...     CaptchaSolverPlugin,
    ...     CAPTCHAPlugin,
    ... )
    >>>
    >>> anti_bot = AntiBotStealthPlugin(config={'stealth_mode': 'high'})
    >>> captcha = CaptchaSolverPlugin(config={'service': '2captcha', 'api_key': '...'})
"""
from __future__ import annotations

import logging
from typing import Any

from graph_crawler.extensions.plugins.base import BasePlugin, PluginContext, PluginType
from graph_crawler.extensions.plugins.engine.anti_bot_stealth import (
    AntiBotStealthPlugin,
    AntiBotSystem,
)
from graph_crawler.extensions.plugins.engine.captcha import (
    CaptchaInfo,
    CaptchaService,
    CaptchaSolution,
    CaptchaSolverPlugin,
    CaptchaType,
)

logger = logging.getLogger(__name__)


class AntiBotPlaywrightPlugin(BasePlugin):
    """Plugin що застосовує stealth-заголовки та конфігурацію Playwright для обходу anti-bot."""

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)

    @property
    def plugin_type(self) -> PluginType:
        return PluginType.PRE_REQUEST

    @property
    def name(self) -> str:
        return "anti_bot_playwright"

    def setup(self) -> None:
        logger.info("AntiBotPlaywrightPlugin initialized")

    def execute(self, context: PluginContext) -> PluginContext:
        from graph_crawler.extensions.plugins.engine.anti_bot_playwright import (
            build_stealth_headers,
        )
        stealth_headers = build_stealth_headers()
        if not hasattr(context, "extra"):
            context.extra = {}
        context.extra.setdefault("headers", {}).update(stealth_headers)
        return context


class AntiBotDetectionPlugin(BasePlugin):
    """Plugin що детектує anti-bot системи (Cloudflare, Akamai, DataDome тощо) в HTML відповідях."""

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)
        self.last_detected: AntiBotSystem | None = None

    @property
    def plugin_type(self) -> PluginType:
        return PluginType.PRE_REQUEST

    @property
    def name(self) -> str:
        return "anti_bot_detection"

    def setup(self) -> None:
        logger.info("AntiBotDetectionPlugin initialized")

    def execute(self, context: PluginContext) -> PluginContext:
        from graph_crawler.extensions.plugins.engine.anti_bot_detection import (
            detect_anti_bot_system,
        )
        html = getattr(context, "html", None) or context.extra.get("html") if hasattr(context, "extra") else None
        detected = detect_anti_bot_system(html)
        self.last_detected = detected
        if detected:
            logger.warning("Anti-bot system detected: %s", detected)
            if not hasattr(context, "extra"):
                context.extra = {}
            context.extra["detected_anti_bot"] = detected
        return context


# Alias: CAPTCHAPlugin → CaptchaSolverPlugin (backward compatibility)
CAPTCHAPlugin = CaptchaSolverPlugin

__all__ = [
    # Anti-Bot
    "AntiBotStealthPlugin",
    "AntiBotSystem",
    "AntiBotPlaywrightPlugin",
    "AntiBotDetectionPlugin",
    # CAPTCHA
    "CaptchaSolverPlugin",
    "CAPTCHAPlugin",
    "CaptchaType",
    "CaptchaService",
    "CaptchaInfo",
    "CaptchaSolution",
]
