"""Node Plugins - плагіни для обробки контенту веб-сторінок.

Node плагіни працюють з HTML контентом після завантаження сторінки:
"""

# Base classes
from graph_crawler.extensions.plugins.node.base import (
    BaseNodePlugin,
    NodePluginContext,
    NodePluginManager,
    NodePluginType,
)

# Defaults
from graph_crawler.extensions.plugins.node.defaults import get_default_node_plugins
from graph_crawler.extensions.plugins.node.links import LinkExtractorPlugin

# Built-in Plugins
from graph_crawler.extensions.plugins.node.metadata import MetadataExtractorPlugin

# Markdown Plugin (VECTOR 3)
from graph_crawler.extensions.plugins.node.markdown_plugin import (
    MarkdownPlugin,
    MarkdownPluginML,
    create_markdown_plugin,
)

# ML Smart Page Finder Plugin
from graph_crawler.extensions.plugins.node.smart_page_finder import (
    RelevanceLevel,
    SmartFinderNode,
    SmartPageFinderPlugin,
    create_smart_finder_node_class,
)

# Structured Data Plugin (Microdata)
from graph_crawler.extensions.plugins.node.structured_data import (
    SchemaType,
    StructuredDataExtractor,
    StructuredDataOptions,
    StructuredDataPlugin,
    StructuredDataResult,
)
from graph_crawler.extensions.plugins.node.text import TextExtractorPlugin

# URL Normalizer Plugin - для кастомної нормалізації URL
from graph_crawler.extensions.plugins.node.url_normalizer import (
    URLNormalizerPlugin,
    create_pagination_normalizer,
    create_tracking_params_normalizer,
    create_custom_normalizer,
)

# Vectorization Plugins - SAFE IMPORT (numpy is optional dependency)
# Graceful degradation: returns None if dependencies not installed (no crash!)
try:
    from graph_crawler.extensions.plugins.node.vectorization import (
        BatchVectorizerPlugin,
        RealTimeVectorizerPlugin,
    )
except ImportError:
    # Production-safe: no crash, just None
    BatchVectorizerPlugin = None  # type: ignore[misc, assignment]
    RealTimeVectorizerPlugin = None  # type: ignore[misc, assignment]

__all__ = [
    # Base classes
    "BaseNodePlugin",
    "NodePluginType",
    "NodePluginContext",
    "NodePluginManager",
    # Built-in Plugins
    "MetadataExtractorPlugin",
    "LinkExtractorPlugin",
    "TextExtractorPlugin",
    # URL Normalizer Plugin
    "URLNormalizerPlugin",
    "create_pagination_normalizer",
    "create_tracking_params_normalizer",
    "create_custom_normalizer",
    # Markdown Plugin (VECTOR 3)
    "MarkdownPlugin",
    "MarkdownPluginML",
    "create_markdown_plugin",
    # ML Smart Page Finder
    "SmartPageFinderPlugin",
    "SmartFinderNode",
    "RelevanceLevel",
    "create_smart_finder_node_class",
    # Structured Data Plugin
    "StructuredDataPlugin",
    "StructuredDataOptions",
    "StructuredDataResult",
    "StructuredDataExtractor",
    "SchemaType",
    # Vectorization Plugins
    "RealTimeVectorizerPlugin",
    "BatchVectorizerPlugin",
    # Defaults
    "get_default_node_plugins",
]
