"""MarkdownPlugin - плагін для автоматичної генерації Markdown.

Підключається до ON_HTML_PARSED lifecycle hook.
Генерує MD з HTML ДО того як Node.process_html() видалить HTML.

Usage:
    from graph_crawler.extensions.plugins.node import MarkdownPlugin
    
    crawler = Crawler(
        plugins=[
            MarkdownPlugin(),  # Дефолтні опції
            # або
            MarkdownPlugin(MarkdownOptions(remove_footer=True)),
        ]
    )
    
    # Після краулінгу
    for node in graph.iter_nodes():
        md = node.user_data.get("text_markdown")  # MD є, HTML видалено
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from graph_crawler.extensions.plugins.node.base import BaseNodePlugin
from graph_crawler.domain.interfaces.node_interfaces import (
    NodePluginContext,
    NodePluginType,
)
from graph_crawler.shared.utils.markdown import (
    MarkdownGenerator,
    MarkdownOptions,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class MarkdownPlugin(BaseNodePlugin):
    """
    Плагін для автоматичної генерації Markdown з HTML.
    
    Підключається до ON_HTML_PARSED lifecycle hook.
    
    Зберігає результати в context.user_data:
    - text_markdown: очищений fit_markdown (основний output)
    - text_content: чистий текст
    - md_stats: статистика (word_count, char_count, headings, links)
    
    Також заповнює context.metadata:
    - title: title сторінки
    - h1: перший H1 заголовок  
    - description: meta description
    
    Attributes:
        generator: MarkdownGenerator instance
        
    Example:
        >>> plugin = MarkdownPlugin()
        >>> # або з кастомними опціями
        >>> plugin = MarkdownPlugin(MarkdownOptions(
        ...     remove_nav=False,  # Зберегти навігацію для ML
        ...     remove_footer=True,
        ... ))
    """

    def __init__(self, options: MarkdownOptions | None = None):
        """
        Ініціалізує MarkdownPlugin.
        
        Args:
            options: Налаштування генерації Markdown (опціонально)
        """
        super().__init__({})
        self.generator = MarkdownGenerator(options)

    @property
    def plugin_type(self) -> NodePluginType:
        """Тип плагіна - виконується після парсингу HTML."""
        return NodePluginType.ON_HTML_PARSED

    @property
    def name(self) -> str:
        """Назва плагіна."""
        return "MarkdownPlugin"

    def execute(self, context: NodePluginContext) -> NodePluginContext:
        """
        Генерує Markdown з HTML контенту.
        
        Синхронний метод - викликається NodePluginManager.
        Підтримує як sync так і async виконання (через manager).
        
        Args:
            context: NodePluginContext з HTML
            
        Returns:
            Оновлений context з MD в user_data
        """
        # Пропускаємо якщо немає HTML
        if not context.html:
            logger.debug("MarkdownPlugin: No HTML for %s", context.url)
            return context

        try:
            # Генеруємо Markdown
            result = self.generator.generate_from_html(context.html)

            # Зберігаємо в user_data
            context.user_data["text_markdown"] = result.fit_markdown
            context.user_data["text_content"] = result.text
            context.user_data["md_stats"] = {
                "word_count": result.word_count,
                "char_count": result.char_count,
                "headings": result.heading_count,
                "links": result.link_count,
                "images": result.image_count,
            }

            # Зберігаємо raw_markdown якщо потрібно
            # (lazy - генерується тільки при доступі)
            if result._raw_html:
                context.user_data["_md_raw_html"] = result._raw_html
                context.user_data["_md_generator"] = self.generator

            # Заповнюємо metadata (якщо ще не заповнені)
            if result.title and "title" not in context.metadata:
                context.metadata["title"] = result.title
            if result.h1 and "h1" not in context.metadata:
                context.metadata["h1"] = result.h1
            if result.description and "description" not in context.metadata:
                context.metadata["description"] = result.description

            logger.debug(
                "MarkdownPlugin: Generated MD for %s (words=%d, headings=%d)",
                context.url,
                result.word_count,
                result.heading_count,
            )

        except Exception as e:
            logger.error("MarkdownPlugin error for %s: %s", context.url, e)
            # Не блокуємо pipeline - просто логуємо помилку
            context.user_data["text_markdown"] = ""
            context.user_data["text_content"] = ""
            context.user_data["md_stats"] = {
                "word_count": 0,
                "char_count": 0,
                "headings": 0,
                "links": 0,
                "images": 0,
                "error": str(e),
            }

        return context


class MarkdownPluginML(MarkdownPlugin):
    """
    MarkdownPlugin для ML/AI use cases.
    
    Відмінності від базового:
    - НЕ видаляє навігацію (потрібна для LLM пошуку сторінок)
    - НЕ видаляє aside (може містити корисну інформацію)
    
    Example:
        >>> from graph_crawler.extensions.plugins.node import MarkdownPluginML
        >>> 
        >>> # В AIExtractionPlugin або SmartPageFinderPlugin
        >>> md_plugin = MarkdownPluginML()
    """

    def __init__(self, options: MarkdownOptions | None = None):
        """
        Ініціалізує MarkdownPluginML з ML-friendly опціями.
        
        Args:
            options: Базові опції (будуть доповнені ML налаштуваннями)
        """
        # ML-friendly defaults
        ml_options = options or MarkdownOptions()
        ml_options = ml_options.with_overrides(
            remove_nav=False,   # LLM потребує навігацію для пошуку
            remove_aside=False, # Може містити корисну інформацію
            include_links=True, # Посилання важливі для навігації
            # P1.8 §7.3: main-content extraction за замовчуванням ON
            # для ML (підвищує якість LLM-контексту, бо ріже noise).
            # Fallback chain (`min_content_words`) гарантує, що для
            # коротких сторінок ми не втратимо контент.
            use_content_density=True,
        )
        super().__init__(ml_options)

    @property
    def name(self) -> str:
        """Назва плагіна."""
        return "MarkdownPluginML"


# Convenience function для швидкого створення плагіна
def create_markdown_plugin(
    remove_nav: bool = True,
    remove_footer: bool = True,
    remove_ads: bool = True,
    include_links: bool = True,
    **kwargs
) -> MarkdownPlugin:
    """
    Створює MarkdownPlugin з кастомними опціями.
    
    Convenience function для швидкого налаштування.
    
    Args:
        remove_nav: Видаляти навігацію
        remove_footer: Видаляти footer
        remove_ads: Видаляти рекламу
        include_links: Включати посилання в MD
        **kwargs: Інші опції для MarkdownOptions
        
    Returns:
        Налаштований MarkdownPlugin
        
    Example:
        >>> plugin = create_markdown_plugin(
        ...     remove_nav=False,
        ...     remove_footer=True,
        ... )
    """
    options = MarkdownOptions(
        remove_nav=remove_nav,
        remove_footer=remove_footer,
        remove_ads=remove_ads,
        include_links=include_links,
        **kwargs
    )
    return MarkdownPlugin(options)
