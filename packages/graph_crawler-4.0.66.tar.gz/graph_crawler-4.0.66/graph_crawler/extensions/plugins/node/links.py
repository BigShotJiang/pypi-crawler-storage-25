"""Плагін для витягування посилань з HTML.

- Використовує URLUtils.is_special_link() замість локальної функції
- List comprehension для швидшої обробки
- Мінімізація викликів URLUtils методів
- Підтримка <base href> тегу для правильного резолвінгу відносних URL
"""

import logging
from urllib.parse import urljoin

from graph_crawler.extensions.plugins.node.base import (
    BaseNodePlugin,
    NodePluginContext,
    NodePluginType,
)
from graph_crawler.shared.utils.url_utils import URLUtils

logger = logging.getLogger(__name__)


def extract_base_href(parser, page_url: str) -> str:
    """
    Витягує базовий URL для резолвінгу відносних посилань.
    
    HTML специфікація: якщо є <base href="...">, він визначає базовий URL
    для ВСІХ відносних посилань на сторінці. Якщо <base href> відсутній,
    використовується URL поточної сторінки.
    
    Приклад проблеми без цього фікса:
    - Сторінка: https://google.com/about/careers/applications/jobs/results/123-job-title
    - <base href="https://google.com/about/careers/applications/">
    - href="jobs/results/456-another-job"
    - БЕЗ фікса: https://google.com/about/careers/applications/jobs/results/jobs/results/456-... (НЕПРАВИЛЬНО!)
    - З фіксом: https://google.com/about/careers/applications/jobs/results/456-... (ПРАВИЛЬНО!)
    
    Args:
        parser: HTML parser з контексту
        page_url: URL поточної сторінки (fallback якщо <base> відсутній)
        
    Returns:
        Базовий URL для резолвінгу відносних посилань
    """
    try:
        # Шукаємо <base href="..."> в <head>
        base_elements = parser.find_all("base[href]")
        if base_elements:
            base_href = base_elements[0].get_attribute("href")
            if base_href:
                base_href = base_href.strip()
                # <base href> може бути відносним - резолвимо відносно page_url
                if base_href.startswith(("http://", "https://")):
                    logger.debug("Found <base href>: %s", base_href)
                    return base_href
                else:
                    # Відносний <base href> - резолвимо відносно поточної сторінки
                    resolved = urljoin(page_url, base_href)
                    logger.debug("Found relative <base href>: %s -> %s", base_href, resolved)
                    return resolved
    except Exception as e:
        logger.debug("Error extracting <base href>: %s", e)
    
    # Fallback: використовуємо URL поточної сторінки
    return page_url


class LinkExtractorPlugin(BaseNodePlugin):
    """
    Дефолтний плагін для витягування посилань з HTML.

    - Використовує кешовані методи URLUtils
    - List comprehension для швидшої обробки
    - Мінімізовані перевірки
    - Підтримка <base href> для коректного резолвінгу URL (як у браузері)

    Цей плагін можна:
    - Підключити (дефолтно увімкнено)
    - Відключити (config={'enabled': False})
    - Налаштувати (config={'extract_images': True})
    """

    @property
    def plugin_type(self) -> NodePluginType:
        return NodePluginType.ON_HTML_PARSED

    @property
    def name(self) -> str:
        return "LinkExtractorPlugin"

    def execute(self, context: NodePluginContext) -> NodePluginContext:
        """Витягує посилання з HTML дерева."""
        # Перевірка чи не пропущено витягування посилань
        if context.skip_link_extraction:
            logger.debug("Skipping link extraction for %s", context.url)
            return context

        # Перевірка наявності parser
        if not context.parser:
            logger.warning("No parser for link extraction: %s", context.url)
            return context

        try:
            links = self._extract_all_links(context)
            context.extracted_links = links
            logger.debug("Extracted %s links from %s", len(links), context.url)

        except Exception as e:
            logger.error("Error extracting links for %s: %s", context.url, e)

        return context

    def _extract_all_links(self, context: NodePluginContext) -> list[str]:
        """
        Реалізація: Витягує всі посилання з HTML дерева.

        Args:
            context: Контекст з parser та URL

        Returns:
            Список абсолютних URL
        """
        links = self._extract_anchor_links(context)

        # Опціонально: витягуємо зображення
        if self.config.get("extract_images", False):
            links.extend(self._extract_image_links(context))

        # Опціонально: витягуємо iframe
        if self.config.get("extract_iframes", False):
            links.extend(self._extract_iframe_links(context))

        return links

    def _extract_anchor_links(self, context: NodePluginContext) -> list[str]:
        """
        ОПТИМІЗОВАНО Витягує посилання з <a href> тегів.

        Оптимізації:
        - Один прохід через list comprehension
        - Використання URLUtils.is_special_link() (кешована)
        - URLUtils.is_valid_url() з кешем
        - Підтримка <base href> для коректного резолвінгу (як у браузері)

        Args:
            context: Контекст з parser та URL

        Returns:
            Список валідних абсолютних URL
        """
        # Витягуємо базовий URL з <base href> або використовуємо URL сторінки
        base_url = extract_base_href(context.parser, context.url)
        a_elements = context.parser.find_all("a[href]")

        # List comprehension + walrus operator
        # Один прохід замість кількох циклів
        links = []
        for a_elem in a_elements:
            href = a_elem.get_attribute("href")
            if not href:
                continue
            # Швидка перевірка special links (без urlparse)
            if URLUtils.is_special_link(href):
                continue
            # Конвертуємо в абсолютний URL
            absolute_url = URLUtils.make_absolute(base_url, href)
            # Перевіряємо валідність (кешовано)
            if URLUtils.is_valid_url(absolute_url):
                links.append(absolute_url)

        return links

    def _extract_image_links(self, context: NodePluginContext) -> list[str]:
        """
        Витягує посилання з <img src> тегів.
        """
        # Використовуємо <base href> якщо є
        base_url = extract_base_href(context.parser, context.url)
        return [
            absolute_url
            for img_elem in context.parser.find_all("img[src]")
            if (src := img_elem.get_attribute("src"))
            and (absolute_url := URLUtils.make_absolute(base_url, src))
            and URLUtils.is_valid_url(absolute_url)
        ]

    def _extract_iframe_links(self, context: NodePluginContext) -> list[str]:
        """
        Витягує посилання з <iframe src> тегів.
        """
        # Використовуємо <base href> якщо є
        base_url = extract_base_href(context.parser, context.url)
        return [
            absolute_url
            for iframe_elem in context.parser.find_all("iframe[src]")
            if (src := iframe_elem.get_attribute("src"))
            and (absolute_url := URLUtils.make_absolute(base_url, src))
            and URLUtils.is_valid_url(absolute_url)
        ]
