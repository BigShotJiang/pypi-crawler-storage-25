r"""URL Normalizer Plugin - плагін для кастомної нормалізації URL.

Цей плагін дозволяє користувачам задавати власні правила нормалізації URL
для уникнення повторного сканування однакових сторінок з різними URL.

Проблема яку вирішує:
    Краулер сканує одну й ту саму сторінку кілька разів через різні URL:
    - https://google.com/careers/jobs?page=1
    - https://google.com/careers/jobs?page=2
    - https://google.com/careers/jobs?page=3
    
    Якщо параметр page не впливає на контент - це марнування ресурсів.

Рішення:
    URLNormalizerPlugin нормалізує URL ПЕРЕД перевіркою на дублікати:
    - Всі ?page=N стають одним URL
    - Краулер сканує сторінку тільки один раз

Етапи роботи:
    1. ON_NODE_CREATED - нормалізуємо URL при створенні ноди
    2. URL перевіряється на дублікати вже в нормалізованому вигляді

Examples:
    >>> from graph_crawler.extensions.plugins.node import URLNormalizerPlugin
    >>> from graph_crawler.domain.value_objects.url_normalization import (
    ...     URLNormalizationConfig,
    ...     URLNormalizationRule,
    ...     create_pagination_rule,
    ... )
    >>> 
    >>> # Конфігурація з правилом для Google Careers
    >>> config = URLNormalizationConfig(
    ...     rules=[
    ...         URLNormalizationRule(
    ...             name="google_careers_pagination",
    ...             pattern=r'\?page=\d+$',
    ...             replacement='',
    ...             domain_pattern=r'google\.com',
    ...             description="Видаляє параметр пагінації з Google Careers"
    ...         ),
    ...     ]
    ... )
    >>> 
    >>> # Або використовуємо готове правило
    >>> config = URLNormalizationConfig(
    ...     rules=[
    ...         create_pagination_rule(
    ...             name="google_pagination",
    ...             domain_pattern=r'google\.com'
    ...         ),
    ...     ]
    ... )
    >>> 
    >>> # Створюємо плагін
    >>> normalizer = URLNormalizerPlugin(config={"normalization_config": config})
    >>> 
    >>> # Використання з краулером
    >>> from graph_crawler.api import GraphCrawlerClient
    >>> 
    >>> client = GraphCrawlerClient(
    ...     start_url="https://google.com/careers/jobs",
    ...     node_plugins=[normalizer],
    ... )

Інтеграція з існуючим кодом:
    Плагін працює на етапі ON_NODE_CREATED і модифікує URL ноди ДО того, як
    вона потрапить у scheduler чи graph. Це означає:
    - scheduler.has_url() буде перевіряти нормалізований URL
    - graph.get_node_by_url() буде шукати по нормалізованому URL
    - Не потрібно змінювати існуючий код link_processor чи scheduler
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from graph_crawler.domain.interfaces.node_interfaces import (
    NodePluginContext,
    NodePluginType,
)
from graph_crawler.domain.value_objects.url_normalization import (
    URLNormalizationConfig,
    URLNormalizationRule,
    get_default_normalization_rules,
)
from graph_crawler.extensions.plugins.node.base import BaseNodePlugin

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class URLNormalizerPlugin(BaseNodePlugin):
    r"""
    Плагін для кастомної нормалізації URL.
    
    Виконується на етапі ON_NODE_CREATED - нормалізує URL перед будь-якими
    перевірками на дублікати.
    
    Attributes:
        normalization_config: Конфігурація з правилами нормалізації
        
    Configuration options (через config dict):
        normalization_config: URLNormalizationConfig - повна конфігурація
        rules: list[URLNormalizationRule] - список правил (альтернатива config)
        use_defaults: bool - чи використовувати дефолтні правила (default: False)
        enabled: bool - чи увімкнений плагін (default: True)
        
    Examples:
        >>> # Варіант 1: Через URLNormalizationConfig
        >>> plugin = URLNormalizerPlugin(config={
        ...     "normalization_config": URLNormalizationConfig(
        ...         rules=[...]
        ...     )
        ... })
        >>> 
        >>> # Варіант 2: Через список правил напряму
        >>> plugin = URLNormalizerPlugin(config={
        ...     "rules": [
        ...         URLNormalizationRule(
        ...             name="remove_page",
        ...             pattern=r'\?page=\d+',
        ...             replacement=''
        ...         )
        ...     ]
        ... })
        >>> 
        >>> # Варіант 3: З дефолтними правилами
        >>> plugin = URLNormalizerPlugin(config={
        ...     "use_defaults": True,
        ...     "rules": [  # Додаткові правила
        ...         URLNormalizationRule(...)
        ...     ]
        ... })
    """
    
    def __init__(self, config: dict[str, Any] | None = None):
        """
        Ініціалізує плагін.
        
        Args:
            config: Словник конфігурації з опціями:
                - normalization_config: URLNormalizationConfig
                - rules: list[URLNormalizationRule]
                - use_defaults: bool
                - enabled: bool
        """
        super().__init__(config)
        
        # Ініціалізуємо конфігурацію
        self.normalization_config = self._build_config()
        
        # Логуємо ініціалізацію
        rules_count = len(self.normalization_config.rules)
        enabled_count = len([r for r in self.normalization_config.rules if r.enabled])
        logger.info(
            "URLNormalizerPlugin initialized with %d rules (%d enabled)",
            rules_count, enabled_count
        )
        
        # Статистика
        self._normalized_count = 0
        self._total_processed = 0
    
    def _build_config(self) -> URLNormalizationConfig:
        """Будує конфігурацію з параметрів."""
        # Якщо передано готову конфігурацію
        if "normalization_config" in self.config:
            config = self.config["normalization_config"]
            if isinstance(config, URLNormalizationConfig):
                return config
            elif isinstance(config, dict):
                return URLNormalizationConfig(**config)
        
        # Збираємо правила
        rules: list[URLNormalizationRule] = []
        
        # Додаємо дефолтні правила якщо потрібно
        if self.config.get("use_defaults", False):
            rules.extend(get_default_normalization_rules())
        
        # Додаємо кастомні правила
        custom_rules = self.config.get("rules", [])
        for rule in custom_rules:
            if isinstance(rule, URLNormalizationRule):
                rules.append(rule)
            elif isinstance(rule, dict):
                rules.append(URLNormalizationRule(**rule))
        
        return URLNormalizationConfig(
            rules=rules,
            enabled=self.config.get("enabled", True),
            log_normalizations=self.config.get("log_normalizations", True)
        )
    
    @property
    def plugin_type(self) -> NodePluginType:
        """Повертає тип плагіна - ON_NODE_CREATED."""
        return NodePluginType.ON_NODE_CREATED
    
    @property
    def name(self) -> str:
        """Повертає ім'я плагіна."""
        return "URLNormalizerPlugin"
    
    def execute(self, context: NodePluginContext) -> NodePluginContext:
        """
        Виконує нормалізацію URL.
        
        Args:
            context: Контекст з даними ноди
            
        Returns:
            Оновлений контекст з нормалізованим URL
        """
        if not self.normalization_config.enabled:
            return context
        
        self._total_processed += 1
        
        original_url = context.url
        normalized_url = self.normalization_config.normalize(original_url)
        
        if normalized_url != original_url:
            self._normalized_count += 1
            
            # Оновлюємо URL в контексті
            context.url = normalized_url
            
            # Оновлюємо URL в ноді
            if context.node is not None:
                # Зберігаємо оригінальний URL в user_data для reference
                if "original_urls" not in context.node.user_data:
                    context.node.user_data["original_urls"] = []
                context.node.user_data["original_urls"].append(original_url)
                
                # Оновлюємо URL ноди
                # ВАЖЛИВО: Це потребує оновлення node_id через XXH3 hash
                context.node.url = normalized_url
                
                # Перегенеровуємо node_id для нового URL
                from graph_crawler.shared.utils.id_generator import generate_node_id
                context.node.node_id = generate_node_id(normalized_url)
                
                logger.debug(
                    "Node URL normalized: %s -> %s (node_id updated)",
                    original_url, normalized_url
                )
            
            # Зберігаємо інформацію про нормалізацію в user_data
            context.user_data["url_normalized"] = True
            context.user_data["original_url"] = original_url
            context.user_data["normalized_url"] = normalized_url
        
        return context
    
    def get_stats(self) -> dict[str, Any]:
        """
        Повертає статистику роботи плагіна.
        
        Returns:
            Словник зі статистикою
        """
        return {
            "total_processed": self._total_processed,
            "normalized_count": self._normalized_count,
            "normalization_rate": (
                self._normalized_count / self._total_processed * 100
                if self._total_processed > 0 else 0
            ),
            "rules_count": len(self.normalization_config.rules),
            "enabled_rules_count": len([
                r for r in self.normalization_config.rules if r.enabled
            ]),
        }
    
    def add_rule(self, rule: URLNormalizationRule) -> None:
        """
        Додає нове правило нормалізації.
        
        Args:
            rule: Правило для додавання
        """
        self.normalization_config.add_rule(rule)
        logger.info("Added normalization rule: %s", rule.name)
    
    def remove_rule(self, name: str) -> bool:
        """
        Видаляє правило за іменем.
        
        Args:
            name: Ім'я правила
            
        Returns:
            True якщо правило видалено
        """
        removed = self.normalization_config.remove_rule(name)
        if removed:
            logger.info("Removed normalization rule: %s", name)
        return removed
    
    def __repr__(self) -> str:
        return (
            f"URLNormalizerPlugin("
            f"rules={len(self.normalization_config.rules)}, "
            f"normalized={self._normalized_count}/{self._total_processed})"
        )


# Фабричні функції для швидкого створення плагіна з типовими конфігураціями

def create_pagination_normalizer(
    domain_pattern: str | None = None,
    additional_rules: list[URLNormalizationRule] | None = None
) -> URLNormalizerPlugin:
    r"""
    Створює плагін для нормалізації пагінації.
    
    Видаляє параметри page=N, p=N з URL.
    
    Args:
        domain_pattern: Regex для обмеження по домену
        additional_rules: Додаткові правила
        
    Returns:
        URLNormalizerPlugin
        
    Example:
        >>> # Для конкретного домену
        >>> plugin = create_pagination_normalizer(domain_pattern=r'google\.com')
        >>> 
        >>> # Глобально для всіх доменів
        >>> plugin = create_pagination_normalizer()
    """
    from graph_crawler.domain.value_objects.url_normalization import (
        create_pagination_rule,
    )
    
    rules = [
        create_pagination_rule(
            name="pagination",
            domain_pattern=domain_pattern
        )
    ]
    
    if additional_rules:
        rules.extend(additional_rules)
    
    return URLNormalizerPlugin(config={"rules": rules})


def create_tracking_params_normalizer(
    include_utm: bool = True,
    include_session: bool = True,
    additional_rules: list[URLNormalizationRule] | None = None
) -> URLNormalizerPlugin:
    """
    Створює плагін для видалення tracking параметрів.
    
    Args:
        include_utm: Включити правило для UTM параметрів
        include_session: Включити правило для session параметрів
        additional_rules: Додаткові правила
        
    Returns:
        URLNormalizerPlugin
        
    Example:
        >>> plugin = create_tracking_params_normalizer()
    """
    from graph_crawler.domain.value_objects.url_normalization import (
        create_utm_rule,
        create_session_rule,
    )
    
    rules = []
    
    if include_utm:
        rules.append(create_utm_rule())
    
    if include_session:
        rules.append(create_session_rule())
    
    if additional_rules:
        rules.extend(additional_rules)
    
    return URLNormalizerPlugin(config={"rules": rules})


def create_custom_normalizer(
    rules: list[URLNormalizationRule],
    use_defaults: bool = False
) -> URLNormalizerPlugin:
    r"""
    Створює плагін з кастомними правилами.
    
    Args:
        rules: Список правил нормалізації
        use_defaults: Чи додавати дефолтні правила
        
    Returns:
        URLNormalizerPlugin
        
    Example:
        >>> from graph_crawler.domain.value_objects.url_normalization import (
        ...     URLNormalizationRule,
        ...     NormalizationScope,
        ... )
        >>> 
        >>> rules = [
        ...     URLNormalizationRule(
        ...         name="google_careers",
        ...         pattern=r'\?page=\d+$',
        ...         replacement='',
        ...         domain_pattern=r'google\.com'
        ...     ),
        ... ]
        >>> 
        >>> plugin = create_custom_normalizer(rules)
    """
    return URLNormalizerPlugin(config={
        "rules": rules,
        "use_defaults": use_defaults
    })


__all__ = [
    "URLNormalizerPlugin",
    "create_pagination_normalizer",
    "create_tracking_params_normalizer",
    "create_custom_normalizer",
]
