"""Module: domain/value_objects - Value Objects та конфігурації"""

from graph_crawler.domain.value_objects.models import (
    ContentType,
    DomainFilterConfig,
    EdgeCreationStrategy,
    EdgeRule,
    FetchResponse,
    GraphComparisonResult,
    GraphMetadata,
    GraphStats,
    PageMetadata,
    PathFilterConfig,
    URLRule,
)

# URL Normalization - кастомна нормалізація URL
from graph_crawler.domain.value_objects.url_normalization import (
    URLNormalizationRule,
    URLNormalizationConfig,
    NormalizationScope,
    create_pagination_rule,
    create_utm_rule,
    create_session_rule,
    create_trailing_slash_rule,
    get_default_normalization_rules,
)

try:
    from graph_crawler.domain.value_objects.configs import (
        DriverConfig,
        MiddlewareConfig,
        StorageConfig,
    )
except ImportError:
    # Якщо configs.py не існує, пропускаємо
    DriverConfig = None
    StorageConfig = None
    MiddlewareConfig = None

__all__ = [
    # Models
    "ContentType",
    "URLRule",
    "EdgeCreationStrategy",
    "EdgeRule",
    "FetchResponse",
    "DomainFilterConfig",
    "PathFilterConfig",
    "PageMetadata",
    "GraphMetadata",
    "GraphStats",
    "GraphComparisonResult",
    # URL Normalization
    "URLNormalizationRule",
    "URLNormalizationConfig",
    "NormalizationScope",
    "create_pagination_rule",
    "create_utm_rule",
    "create_session_rule",
    "create_trailing_slash_rule",
    "get_default_normalization_rules",
    # Configs
    "DriverConfig",
    "StorageConfig",
    "MiddlewareConfig",
]
