r"""URL Normalization Rules - правила для нормалізації URL перед обробкою.

Цей модуль дозволяє користувачам задавати кастомні правила нормалізації URL
через regex патерни. Корисно для:
- Видалення несуттєвих query параметрів (?page=1, ?utm_source=...)
- Нормалізації шляхів (видалення trailing slashes, дублікатів)
- Уніфікації URL для уникнення повторного сканування однакових сторінок

Examples:
    >>> # Видалити параметр page з Google Careers URL
    >>> rule = URLNormalizationRule(
    ...     name="google_careers_pagination",
    ...     pattern=r'\?page=\d+$',
    ...     replacement='',
    ...     domain_pattern=r'google\.com',  # Тільки для google.com
    ...     description="Видаляє параметр пагінації з Google Careers"
    ... )
    
    >>> # Видалити всі utm_ параметри
    >>> rule = URLNormalizationRule(
    ...     name="remove_utm",
    ...     pattern=r'[&?]utm_[^&]+',
    ...     replacement='',
    ...     description="Видаляє UTM tracking параметри"
    ... )
"""
from __future__ import annotations

import logging
import re
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

logger = logging.getLogger(__name__)


class NormalizationScope(str, Enum):
    """
    Область застосування правила нормалізації.
    
    Визначає до якої частини URL застосовується патерн.
    """
    FULL_URL = "full_url"      # Весь URL
    PATH = "path"              # Тільки шлях (без домену та query)
    QUERY = "query"            # Тільки query параметри
    PATH_AND_QUERY = "path_and_query"  # Шлях + query


class URLNormalizationRule(BaseModel):
    r"""
    Правило для нормалізації URL.
    
    Дозволяє задати regex патерн та replacement для трансформації URL
    перед перевіркою на дублікати.
    
    Attributes:
        name: Унікальне ім'я правила (для логування та ідентифікації)
        pattern: Regex патерн для пошуку
        replacement: Рядок заміни (може містити групи: \1, \2, ...)
        domain_pattern: Опціональний regex для обмеження по домену
        scope: Область застосування (full_url, path, query, path_and_query)
        priority: Пріоритет виконання (вищий - раніше)
        enabled: Чи увімкнене правило
        description: Опис правила для документації
    
    Examples:
        >>> # Видалити параметр page
        >>> rule = URLNormalizationRule(
        ...     name="remove_page_param",
        ...     pattern=r'[?&]page=\d+',
        ...     replacement='',
        ...     scope=NormalizationScope.QUERY
        ... )
        
        >>> # Замінити /jobs/results/X?page=N на /jobs/results/X
        >>> rule = URLNormalizationRule(
        ...     name="google_careers_normalize",
        ...     pattern=r'(\?page=\d+)$',
        ...     replacement='',
        ...     domain_pattern=r'google\.com'
        ... )
    """
    
    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Унікальне ім'я правила"
    )
    
    pattern: str = Field(
        ...,
        min_length=1,
        description="Regex патерн для пошуку"
    )
    
    replacement: str = Field(
        default='',
        description="Рядок заміни (може містити групи: \\1, \\2)"
    )
    
    domain_pattern: str | None = Field(
        default=None,
        description="Regex для обмеження по домену (None = всі домени)"
    )
    
    scope: NormalizationScope = Field(
        default=NormalizationScope.FULL_URL,
        description="Область застосування патерну"
    )
    
    priority: int = Field(
        default=5,
        ge=1,
        le=10,
        description="Пріоритет (1=низький, 10=високий). Вищий виконується раніше"
    )
    
    enabled: bool = Field(
        default=True,
        description="Чи увімкнене правило"
    )
    
    description: str = Field(
        default='',
        max_length=500,
        description="Опис правила"
    )
    
    # Кешовані скомпільовані regex
    _compiled_pattern: re.Pattern | None = None
    _compiled_domain_pattern: re.Pattern | None = None
    
    model_config = ConfigDict(
        frozen=False,
        arbitrary_types_allowed=True,
    )
    
    @field_validator("pattern")
    @classmethod
    def validate_pattern(cls, v: str) -> str:
        """Валідація regex патерну."""
        try:
            re.compile(v)
        except re.error as e:
            raise ValueError(f"Невалідний regex патерн: {e}")
        return v
    
    @field_validator("domain_pattern")
    @classmethod
    def validate_domain_pattern(cls, v: str | None) -> str | None:
        """Валідація domain regex патерну."""
        if v is not None:
            try:
                re.compile(v)
            except re.error as e:
                raise ValueError(f"Невалідний domain regex патерн: {e}")
        return v
    
    def _get_compiled_pattern(self) -> re.Pattern:
        """Повертає скомпільований regex (з кешуванням)."""
        if self._compiled_pattern is None:
            self._compiled_pattern = re.compile(self.pattern)
        return self._compiled_pattern
    
    def _get_compiled_domain_pattern(self) -> re.Pattern | None:
        """Повертає скомпільований domain regex (з кешуванням)."""
        if self.domain_pattern is None:
            return None
        if self._compiled_domain_pattern is None:
            self._compiled_domain_pattern = re.compile(self.domain_pattern)
        return self._compiled_domain_pattern
    
    def _matches_domain(self, url: str) -> bool:
        """Перевіряє чи URL відповідає domain_pattern."""
        if self.domain_pattern is None:
            return True  # Немає обмеження по домену
        
        domain_regex = self._get_compiled_domain_pattern()
        if domain_regex is None:
            return True
        
        # Витягуємо домен з URL
        from urllib.parse import urlparse
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            return bool(domain_regex.search(domain))
        except Exception:
            return False
    
    def _extract_url_part(self, url: str) -> tuple[str, str, str]:
        """
        Витягує частину URL для обробки згідно scope.
        
        Returns:
            Tuple (prefix, part_to_process, suffix)
        """
        from urllib.parse import urlparse, urlunparse
        
        try:
            parsed = urlparse(url)
        except Exception:
            return ('', url, '')
        
        if self.scope == NormalizationScope.FULL_URL:
            return ('', url, '')
        
        elif self.scope == NormalizationScope.PATH:
            # Тільки path
            prefix = f"{parsed.scheme}://{parsed.netloc}"
            suffix = ''
            if parsed.query:
                suffix += f"?{parsed.query}"
            if parsed.fragment:
                suffix += f"#{parsed.fragment}"
            return (prefix, parsed.path, suffix)
        
        elif self.scope == NormalizationScope.QUERY:
            # Тільки query
            prefix = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            if parsed.query:
                prefix += '?'
                return (prefix, parsed.query, '')
            return (prefix, '', '')
        
        elif self.scope == NormalizationScope.PATH_AND_QUERY:
            # Path + query
            prefix = f"{parsed.scheme}://{parsed.netloc}"
            part = parsed.path
            if parsed.query:
                part += f"?{parsed.query}"
            suffix = ''
            if parsed.fragment:
                suffix = f"#{parsed.fragment}"
            return (prefix, part, suffix)
        
        return ('', url, '')
    
    def normalize(self, url: str) -> str:
        r"""
        Застосовує правило до URL.
        
        Args:
            url: URL для нормалізації
            
        Returns:
            Нормалізований URL
            
        Example:
            >>> rule = URLNormalizationRule(
            ...     name="remove_page",
            ...     pattern=r'\?page=\d+$',
            ...     replacement=''
            ... )
            >>> rule.normalize("https://example.com/jobs?page=5")
            'https://example.com/jobs'
        """
        if not self.enabled:
            return url
        
        # Перевіряємо domain
        if not self._matches_domain(url):
            return url
        
        # Витягуємо частину для обробки
        prefix, part, suffix = self._extract_url_part(url)
        
        # Застосовуємо regex
        pattern = self._get_compiled_pattern()
        new_part = pattern.sub(self.replacement, part)
        
        # Збираємо результат
        result = prefix + new_part + suffix
        
        # Очищаємо артефакти (пусті ? або &)
        result = self._cleanup_url(result)
        
        if result != url:
            logger.debug(
                "URL normalized by rule '%s': %s -> %s",
                self.name, url, result
            )
        
        return result
    
    def _cleanup_url(self, url: str) -> str:
        """Очищає URL від артефактів після заміни."""
        # Видаляємо пусті query string (?)
        url = re.sub(r'\?$', '', url)
        # Видаляємо подвійні &&
        url = re.sub(r'&&+', '&', url)
        # Видаляємо ?& або &?
        url = re.sub(r'\?&', '?', url)
        # Видаляємо trailing &
        url = re.sub(r'&$', '', url)
        # Видаляємо пусті ? знову після очищення
        url = re.sub(r'\?$', '', url)
        return url
    
    def __repr__(self) -> str:
        parts = [f"name={self.name!r}", f"pattern={self.pattern!r}"]
        if self.replacement:
            parts.append(f"replacement={self.replacement!r}")
        if self.domain_pattern:
            parts.append(f"domain_pattern={self.domain_pattern!r}")
        if self.scope != NormalizationScope.FULL_URL:
            parts.append(f"scope={self.scope.value}")
        if self.priority != 5:
            parts.append(f"priority={self.priority}")
        if not self.enabled:
            parts.append("enabled=False")
        return f"URLNormalizationRule({', '.join(parts)})"


class URLNormalizationConfig(BaseModel):
    r"""
    Конфігурація для URL нормалізації.
    
    Містить набір правил та налаштування для URL Normalizer Plugin.
    
    Attributes:
        rules: Список правил нормалізації
        enabled: Глобальний вимикач
        log_normalizations: Логувати всі нормалізації
        
    Examples:
        >>> config = URLNormalizationConfig(
        ...     rules=[
        ...         URLNormalizationRule(
        ...             name="remove_page",
        ...             pattern=r'\?page=\d+$',
        ...             replacement='',
        ...             domain_pattern=r'google\.com'
        ...         ),
        ...         URLNormalizationRule(
        ...             name="remove_utm",
        ...             pattern=r'[&?]utm_[^&]+',
        ...             replacement=''
        ...         )
        ...     ]
        ... )
    """
    
    rules: list[URLNormalizationRule] = Field(
        default_factory=list,
        description="Список правил нормалізації"
    )
    
    enabled: bool = Field(
        default=True,
        description="Глобальний вимикач нормалізації"
    )
    
    log_normalizations: bool = Field(
        default=True,
        description="Логувати нормалізації"
    )
    
    model_config = ConfigDict(frozen=False)
    
    def normalize(self, url: str) -> str:
        """
        Застосовує всі правила до URL.
        
        Правила застосовуються в порядку пріоритету (вищий - раніше).
        
        Args:
            url: URL для нормалізації
            
        Returns:
            Нормалізований URL
        """
        if not self.enabled:
            return url
        
        # Сортуємо правила за пріоритетом (вищий першим)
        sorted_rules = sorted(
            [r for r in self.rules if r.enabled],
            key=lambda r: r.priority,
            reverse=True
        )
        
        original_url = url
        for rule in sorted_rules:
            url = rule.normalize(url)
        
        if url != original_url and self.log_normalizations:
            logger.info(
                "URL normalized: %s -> %s",
                original_url, url
            )
        
        return url
    
    def add_rule(self, rule: URLNormalizationRule) -> None:
        """Додає правило до конфігурації."""
        self.rules.append(rule)
    
    def remove_rule(self, name: str) -> bool:
        """Видаляє правило за іменем. Повертає True якщо видалено."""
        for i, rule in enumerate(self.rules):
            if rule.name == name:
                del self.rules[i]
                return True
        return False
    
    def get_rule(self, name: str) -> URLNormalizationRule | None:
        """Отримує правило за іменем."""
        for rule in self.rules:
            if rule.name == name:
                return rule
        return None


# Готові правила для типових сценаріїв
def create_pagination_rule(
    name: str = "remove_pagination",
    domain_pattern: str | None = None
) -> URLNormalizationRule:
    """
    Створює правило для видалення параметрів пагінації.
    
    Видаляє: ?page=N, &page=N, ?p=N, &p=N
    
    Args:
        name: Ім'я правила
        domain_pattern: Обмеження по домену (regex)
        
    Returns:
        URLNormalizationRule
    """
    return URLNormalizationRule(
        name=name,
        pattern=r'[?&](page|p)=\d+',
        replacement='',
        domain_pattern=domain_pattern,
        scope=NormalizationScope.FULL_URL,  # FULL_URL для коректної обробки ? на початку
        priority=7,
        description="Видаляє параметри пагінації (page=N, p=N)"
    )


def create_utm_rule(
    name: str = "remove_utm_params"
) -> URLNormalizationRule:
    """
    Створює правило для видалення UTM параметрів.
    
    Видаляє: utm_source, utm_medium, utm_campaign, utm_term, utm_content
    
    Returns:
        URLNormalizationRule
    """
    return URLNormalizationRule(
        name=name,
        pattern=r'[?&]utm_[a-z_]+=([^&]*)',
        replacement='',
        scope=NormalizationScope.QUERY,
        priority=6,
        description="Видаляє UTM tracking параметри"
    )


def create_session_rule(
    name: str = "remove_session_params"
) -> URLNormalizationRule:
    """
    Створює правило для видалення session параметрів.
    
    Видаляє: sid, session_id, PHPSESSID, jsessionid
    
    Returns:
        URLNormalizationRule
    """
    return URLNormalizationRule(
        name=name,
        pattern=r'[?&](sid|session_id|PHPSESSID|jsessionid|sessid)=([^&]*)',
        replacement='',
        scope=NormalizationScope.QUERY,
        priority=8,
        description="Видаляє session параметри"
    )


def create_trailing_slash_rule(
    name: str = "normalize_trailing_slash"
) -> URLNormalizationRule:
    """
    Створює правило для нормалізації trailing slashes.
    
    Видаляє trailing slash крім кореневого шляху.
    
    Returns:
        URLNormalizationRule
    """
    return URLNormalizationRule(
        name=name,
        pattern=r'/+$',
        replacement='',
        scope=NormalizationScope.PATH,
        priority=5,
        description="Видаляє trailing slashes"
    )


def get_default_normalization_rules() -> list[URLNormalizationRule]:
    """
    Повертає набір дефолтних правил нормалізації.
    
    Включає:
    - Видалення UTM параметрів
    - Видалення session параметрів
    
    Returns:
        Список URLNormalizationRule
    """
    return [
        create_utm_rule(),
        create_session_rule(),
    ]


__all__ = [
    "URLNormalizationRule",
    "URLNormalizationConfig",
    "NormalizationScope",
    "create_pagination_rule",
    "create_utm_rule",
    "create_session_rule",
    "create_trailing_slash_rule",
    "get_default_normalization_rules",
]
