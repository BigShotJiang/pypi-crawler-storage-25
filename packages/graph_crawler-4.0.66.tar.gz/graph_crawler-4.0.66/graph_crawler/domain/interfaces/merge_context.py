"""
Interface for Merge Context Provider (Clean Architecture).

This interface allows Graph to depend on abstraction for merge strategy context.

Usage:
    Graph can receive IMergeContextProvider through DI or use thread-local context.
"""
from __future__ import annotations

from typing import Callable, Protocol, runtime_checkable


@runtime_checkable
class IMergeContext(Protocol):
    """
    Interface for merge context data.

    Holds the merge strategy and optional custom merge function
    for Graph union operations.
    """

    @property
    def strategy(self) -> str:
        ...

    @property
    def custom_merge_fn(self) -> Callable | None:
        ...


@runtime_checkable
class IMergeContextProvider(Protocol):
    """
    Interface for merge context provider (Dependency Injection).

        without importing Application layer directly.

    Example:
        >>> # In Graph.__init__ or through DI
        >>> graph = Graph(merge_context_provider=MergeContextManager)
        >>> strategy, fn = graph._get_effective_merge_strategy()
    """

    @classmethod
    def current(cls) -> IMergeContext | None:
        """
        Returns the current merge context from thread-local storage.

        Returns:
            IMergeContext or None if no context is active
        """
        ...


__all__ = [
    "IMergeContext",
    "IMergeContextProvider",
]
