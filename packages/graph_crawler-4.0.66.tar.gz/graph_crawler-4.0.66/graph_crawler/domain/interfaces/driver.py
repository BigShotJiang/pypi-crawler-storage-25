"""Protocol для драйверів завантаження сторінок ."""
from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from graph_crawler.domain.value_objects.models import FetchResponse


@runtime_checkable
class IDriver(Protocol):
    """Async-First інтерфейс для драйвера завантаження сторінок."""

    async def fetch(self, url: str) -> FetchResponse:
        """
        Async завантаження сторінки за URL.

        Args:
            url: URL сторінки для завантаження

        Returns:
            FetchResponse з HTML або помилкою
        """
        ...

    async def fetch_many(self, urls: list[str]) -> list[FetchResponse]:
        """
        Async batch завантаження множини URL.

        Всі запити виконуються паралельно для максимальної швидкості.

        Args:
            urls: Список URL

        Returns:
            Список FetchResponse
        """
        ...

    async def close(self) -> None:
        """Async закриття драйвера та вивільнення ресурсів."""
        ...

    def supports_batch_fetching(self) -> bool:
        ...

    async def __aenter__(self) -> "IDriver":
        """Async context manager entry."""
        ...

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool | None:
        """Async context manager exit - автоматично закриває драйвер."""
        ...
