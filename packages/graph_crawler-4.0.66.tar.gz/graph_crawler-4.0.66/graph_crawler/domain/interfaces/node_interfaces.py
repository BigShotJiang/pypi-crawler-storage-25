"""
Внутрішні інтерфейси для Core модуля.

Цей модуль створено для вирішення circular imports в Node.py.
Замість імпорту конкретних реалізацій (NodePluginContext, NodePluginType),
Node тепер залежить тільки від абстракцій (Protocols).

Dependency Inversion Principle (DIP):
- High-level modules (Node) не повинні залежати від low-level modules (Plugins)
- Обидва повинні залежати від абстракцій (Protocols)

Переваги:
1. Немає circular imports
2. Швидші імпорти (no lazy imports)
3. Краща IDE підтримка (type hints працюють)
4. Легше тестувати (можна підміняти реалізації)

PHASE 2 REFACTORING:
- NodePluginType та NodePluginContext перенесені в Domain layer
- Extensions тепер імпортують з domain.interfaces замість навпаки
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field


class NodePluginType(str, Enum):
    """
    Типи плагінів для обробки Node.
    
    Lifecycle:
    - ЕТАП 1 (URL_STAGE): ON_NODE_CREATED
    - ЕТАП 2 (HTML_STAGE): ON_BEFORE_SCAN, ON_HTML_PARSED, ON_AFTER_SCAN
    - ЕТАП 3 (CRAWL_STAGE): BEFORE_CRAWL, AFTER_CRAWL
    """

    # ЕТАП 1: URL_STAGE (при створенні ноди)
    ON_NODE_CREATED = "on_node_created"  # Після створення ноди

    # ЕТАП 2: HTML_STAGE (при скануванні)
    ON_BEFORE_SCAN = "on_before_scan"  # Перед скануванням
    ON_HTML_PARSED = "on_html_parsed"  # Після парсингу HTML в дерево
    ON_AFTER_SCAN = "on_after_scan"  # Після сканування

    # ЕТАП 3: CRAWL_STAGE (життєвий цикл краулінгу)
    BEFORE_CRAWL = "before_crawl"  # Перед початком краулінгу
    AFTER_CRAWL = "after_crawl"  # Після завершення краулінгу


class NodePluginContext(BaseModel):
    """
    Контекст для Node плагінів (Pydantic BaseModel).
    
    Перенесено з extensions.plugins.node.base в domain.interfaces
    для дотримання Dependency Inversion Principle.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Основні дані
    node: Any  # Node об'єкт

    # Етап 1: URL_STAGE (завжди доступні)
    url: str
    depth: int = 0
    should_scan: bool = True
    can_create_edges: bool = True

    # Етап 2: HTML_STAGE INPUT (доступні тільки після парсингу HTML)
    html: str | None = None
    html_tree: Any | None = None  # Any замість BeautifulSoup (підтримка різних парсерів)
    parser: Any | None = None  # Tree adapter/parser instance

    # Етап 2: HTML_STAGE OUTPUT (заповнюються плагінами)
    metadata: dict[str, Any] = Field(default_factory=dict)
    extracted_links: list[str] = Field(default_factory=list)

    # Додаткові дані від користувача (заповнюються плагінами)
    user_data: dict[str, Any] = Field(default_factory=dict)

    # Флаги
    skip_link_extraction: bool = False  # Не витягувати посилання
    skip_metadata_extraction: bool = False  # Не витягувати метадані

    # Phase 1: AI Agent Integration - глобальний контекст краулінгу
    crawl_context: Any | None = None  # CrawlContext

    # Phase 2: AI Agent Integration - канал керування
    control_channel: Any | None = None  # IControlChannel

    def get_metadata(self, key: str, default: Any = None) -> Any:
        return self.metadata.get(key, default)

    def set_metadata(self, key: str, value: Any) -> None:
        self.metadata[key] = value

    def has_metadata(self, key: str) -> bool:
        return key in self.metadata

    def get_from_crawl_context(self, key: str, default: Any = None) -> Any:
        """Безпечно отримує значення з глобального crawl_context."""
        if self.crawl_context:
            return self.crawl_context.get(key, default)
        return default

    def set_in_crawl_context(self, key: str, value: Any) -> None:
        """Встановлює значення в глобальному crawl_context."""
        if self.crawl_context:
            self.crawl_context.set(key, value)

    def add_extracted_to_context(self, data: dict[str, Any]) -> None:
        """Додає витягнуті дані до глобального контексту."""
        if self.crawl_context:
            # Метод crawl_context.add_extracted_data приймає data як dict та source_url
            self.crawl_context.add_extracted_data(data, self.url)

    def request_stop(self, reason: str = "Plugin requested stop") -> None:
        """Запитує зупинку краулінгу через control_channel."""
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import (
                ControlMessage,
                CrawlCommand,
            )
            self.control_channel.send(
                ControlMessage(
                    command=CrawlCommand.STOP,
                    data={"reason": reason},
                    sender="plugin",
                )
            )

    def reprioritize_url(self, url: str, priority: int = 8) -> None:
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import (
                ControlMessage,
                CrawlCommand,
            )
            self.control_channel.send(
                ControlMessage(
                    command=CrawlCommand.REPRIORITIZE_URL,
                    data={"url": url, "priority": priority},
                    sender="plugin",
                )
            )

    def force_visit_url(self, url: str) -> None:
        """Запитує примусове відвідування URL."""
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import (
                ControlMessage,
                CrawlCommand,
            )
            self.control_channel.send(
                ControlMessage(
                    command=CrawlCommand.FORCE_VISIT,
                    data={"url": url},
                    sender="plugin",
                )
            )


@runtime_checkable
class INodePluginType(Protocol):
    """
    Protocol для NodePluginType enum (для зворотної сумісності).
    """
    value: str


@runtime_checkable
class INodePluginContext(Protocol):
    """
    Protocol для NodePluginContext (для зворотної сумісності).
    """
    url: str
    depth: int
    html: str | None
    html_tree: Any | None
    metadata: dict[str, Any]
    extracted_links: list
    user_data: dict[str, Any]


@runtime_checkable
class IPluginManager(Protocol):
    """
    Protocol для NodePluginManager.
    """

    def execute(self, plugin_type: Any, context: Any) -> Any:
        """Виконує всі зареєстровані плагіни вказаного типу."""
        ...

    def execute_sync(self, plugin_type: Any, context: Any) -> Any:
        """Синхронна версія execute."""
        ...


@runtime_checkable
class ISimHashStrategy(Protocol):
    """
    Protocol для обчислення SimHash (Locality-Sensitive Hash).
    """

    def compute_simhash(self, node: Any) -> str:
        ...


__all__ = [
    # Concrete implementations (moved from extensions)
    "NodePluginType",
    "NodePluginContext",
    # Protocols (for duck typing)
    "INodePluginType",
    "INodePluginContext",
    "IPluginManager",
    "ISimHashStrategy",
]
