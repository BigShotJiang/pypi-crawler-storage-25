"""Спеціалізований Node для sitemap структури."""
from __future__ import annotations

import logging
from typing import Literal

from pydantic import Field

from graph_crawler.domain.entities.node import Node

logger = logging.getLogger(__name__)


class SitemapNode(Node):
    """
    Спеціалізований Node для представлення елементів sitemap структури.

    """

    # Тип вузла в sitemap ієрархії
    node_type: Literal["robots_txt", "sitemap_index", "sitemap", "url"] = Field(
        default="url", description="Тип вузла в sitemap структурі"
    )

    # Тип sitemap файлу (якщо це sitemap)
    sitemap_type: Literal["xml", "xml.gz", "text"] | None = Field(
        default=None, description="Тип sitemap файлу (xml, xml.gz, text)"
    )

    # URL батьківського sitemap
    parent_sitemap: str | None = Field(
        default=None, description="URL батьківського sitemap або robots.txt"
    )

    # Кількість URL у sitemap (якщо це sitemap або sitemap_index)
    urls_count: int | None = Field(
        default=None, ge=0, description="Кількість URL у цьому sitemap"
    )

    # Повідомлення про помилку (якщо є)
    error_message: str | None = Field(
        default=None, description="Повідомлення про помилку (404, parse error тощо)"
    )

    def is_robots_txt(self) -> bool:
        return self.node_type == "robots_txt"

    def is_sitemap_index(self) -> bool:
        return self.node_type == "sitemap_index"

    def is_sitemap(self) -> bool:
        return self.node_type == "sitemap"

    def is_url(self) -> bool:
        return self.node_type == "url"

    def has_error(self) -> bool:
        """Перевіряє чи є помилка."""
        return self.error_message is not None

    def is_gzipped(self) -> bool:
        """Перевіряє чи це gzip sitemap."""
        return self.sitemap_type == "xml.gz" or (self.url and self.url.endswith(".gz"))

    def __repr__(self):
        parts = [f"url={self.url}"]
        parts.append(f"type={self.node_type}")

        if self.urls_count is not None:
            parts.append(f"urls={self.urls_count}")

        if self.error_message:
            parts.append(f"error='{self.error_message}'")

        return f"SitemapNode({', '.join(parts)})"
