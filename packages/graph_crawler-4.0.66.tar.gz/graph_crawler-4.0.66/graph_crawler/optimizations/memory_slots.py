"""Memory-optimized data structures with __slots__.

Цей модуль містить оптимізовані версії часто використовуваних класів
з використанням __slots__ для економії пам'яті.

Економія пам'яті:
- Клас без __slots__: ~1000 байт/об'єкт (через __dict__)
- Клас з __slots__: ~400 байт/об'єкт
- Економія: ~60% на об'єкт

При 1M+ об'єктів: ~600MB економії RAM.

Техніки оптимізації:
1. __slots__ - фіксований набір атрибутів, без __dict__
2. __sizeof__ - явний контроль розміру об'єкта
3. Compact representations - мінімальні типи даних

Usage:
    >>> from graph_crawler.optimizations.memory_slots import (
    ...     SlottedURLInfo,
    ...     SlottedCrawlProgress,
    ...     SlottedMemorySnapshot,
    ... )
    >>>
    >>> # Замість dict для URL info
    >>> url_info = SlottedURLInfo(
    ...     url="https://example.com",
    ...     depth=1,
    ...     priority=5,
    ... )
    >>>
    >>> # Перевірка економії пам'яті
    >>> import sys
    >>> print(f"Size: {sys.getsizeof(url_info)} bytes")
"""

from __future__ import annotations

import sys
import time
from datetime import datetime
from typing import Any, Iterator


class SlottedURLInfo:
    """
    Memory-optimized URL information container.

    Замінює dict для зберігання URL metadata.

    Memory savings:
    - dict: ~240 bytes + key/value overhead
    - SlottedURLInfo: ~96 bytes
    - Savings: ~60%

    Attributes:
        url: URL string
        depth: Crawl depth (0-255)
        priority: Priority level (1-10)
        scanned: Whether URL was scanned
        response_status: HTTP status code or None
    """

    __slots__ = ('url', 'depth', 'priority', 'scanned', 'response_status', '_hash')

    def __init__(
        self,
        url: str,
        depth: int = 0,
        priority: int = 5,
        scanned: bool = False,
        response_status: int | None = None,
    ):
        self.url = url
        self.depth = depth
        self.priority = priority
        self.scanned = scanned
        self.response_status = response_status
        self._hash = hash(url)  # Cache hash for O(1) lookups

    def __hash__(self) -> int:
        return self._hash

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SlottedURLInfo):
            return self.url == other.url
        if isinstance(other, str):
            return self.url == other
        return False

    def __repr__(self) -> str:
        return f"URLInfo({self.url!r}, d={self.depth}, p={self.priority})"

    def __sizeof__(self) -> int:
        """Explicit memory size calculation."""
        size = object.__sizeof__(self)
        size += sys.getsizeof(self.url)
        size += sys.getsizeof(self.depth)
        size += sys.getsizeof(self.priority)
        size += sys.getsizeof(self.scanned)
        if self.response_status is not None:
            size += sys.getsizeof(self.response_status)
        return size

    def to_dict(self) -> dict[str, Any]:
        return {
            'url': self.url,
            'depth': self.depth,
            'priority': self.priority,
            'scanned': self.scanned,
            'response_status': self.response_status,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SlottedURLInfo:
        return cls(
            url=data['url'],
            depth=data.get('depth', 0),
            priority=data.get('priority', 5),
            scanned=data.get('scanned', False),
            response_status=data.get('response_status'),
        )


class SlottedCrawlProgress:
    """
    Memory-optimized crawl progress tracker.

    Tracks crawl statistics without dict overhead.

    Attributes:
        total_urls: Total URLs discovered
        scanned_urls: Number of scanned URLs
        failed_urls: Number of failed URLs
        current_depth: Current crawl depth
        start_time: Crawl start timestamp
        last_update: Last progress update timestamp
    """

    __slots__ = (
        'total_urls', 'scanned_urls', 'failed_urls',
        'current_depth', 'start_time', 'last_update',
        '_rate_samples', '_rate_sample_times'
    )

    def __init__(self):
        self.total_urls: int = 0
        self.scanned_urls: int = 0
        self.failed_urls: int = 0
        self.current_depth: int = 0
        self.start_time: float = time.time()
        self.last_update: float = self.start_time
        # Rate calculation (circular buffer, max 10 samples)
        self._rate_samples: list[int] = []
        self._rate_sample_times: list[float] = []

    def increment_scanned(self) -> None:
        self.scanned_urls += 1
        self.last_update = time.time()

        # Update rate samples (keep last 10)
        self._rate_samples.append(self.scanned_urls)
        self._rate_sample_times.append(self.last_update)
        if len(self._rate_samples) > 10:
            self._rate_samples.pop(0)
            self._rate_sample_times.pop(0)

    def increment_failed(self) -> None:
        self.failed_urls += 1
        self.last_update = time.time()

    def add_discovered(self, count: int = 1) -> None:
        self.total_urls += count

    def set_depth(self, depth: int) -> None:
        self.current_depth = depth

    @property
    def pending_urls(self) -> int:
        return self.total_urls - self.scanned_urls - self.failed_urls

    @property
    def success_rate(self) -> float:
        if self.scanned_urls == 0:
            return 0.0
        return (self.scanned_urls - self.failed_urls) / self.scanned_urls

    @property
    def pages_per_second(self) -> float:
        """Current crawl rate (pages/second)."""
        if len(self._rate_samples) < 2:
            return 0.0

        pages_diff = self._rate_samples[-1] - self._rate_samples[0]
        time_diff = self._rate_sample_times[-1] - self._rate_sample_times[0]

        if time_diff <= 0:
            return 0.0

        return pages_diff / time_diff

    @property
    def elapsed_seconds(self) -> float:
        return time.time() - self.start_time

    def __repr__(self) -> str:
        return (
            f"CrawlProgress(scanned={self.scanned_urls}/{self.total_urls}, "
            f"failed={self.failed_urls}, rate={self.pages_per_second:.1f}/s)"
        )

    def __sizeof__(self) -> int:
        size = object.__sizeof__(self)
        # Add size of numeric attributes (minimal)
        size += 6 * sys.getsizeof(0)  # 6 integers
        size += 2 * sys.getsizeof(0.0)  # 2 floats
        size += sys.getsizeof(self._rate_samples)
        size += sys.getsizeof(self._rate_sample_times)
        return size

    def to_dict(self) -> dict[str, Any]:
        return {
            'total_urls': self.total_urls,
            'scanned_urls': self.scanned_urls,
            'failed_urls': self.failed_urls,
            'current_depth': self.current_depth,
            'pending_urls': self.pending_urls,
            'success_rate': round(self.success_rate, 3),
            'pages_per_second': round(self.pages_per_second, 2),
            'elapsed_seconds': round(self.elapsed_seconds, 1),
        }


class SlottedMemorySnapshot:
    """
    Memory-optimized snapshot of memory usage.

    Replaces MemorySnapshot class with __slots__ for reduced overhead.

    Memory savings:
    - Original MemorySnapshot: ~400 bytes
    - SlottedMemorySnapshot: ~160 bytes
    - Savings: ~60%

    Attributes:
        timestamp: Unix timestamp of snapshot
        pages_crawled: Number of pages at snapshot time
        current_memory_mb: Current memory usage in MB
        peak_memory_mb: Peak memory usage in MB
        top_stats: Top memory consumers (file, size_bytes, count)
    """

    __slots__ = (
        'timestamp', 'pages_crawled', 'current_memory_mb',
        'peak_memory_mb', 'top_stats'
    )

    def __init__(
        self,
        timestamp: float,
        pages_crawled: int,
        current_memory_mb: float,
        peak_memory_mb: float,
        top_stats: list[tuple[str, int, int]] | None = None,
    ):
        self.timestamp = timestamp
        self.pages_crawled = pages_crawled
        self.current_memory_mb = current_memory_mb
        self.peak_memory_mb = peak_memory_mb
        self.top_stats = top_stats or []

    @property
    def datetime_str(self) -> str:
        return datetime.fromtimestamp(self.timestamp).isoformat()

    def __repr__(self) -> str:
        return (
            f"MemSnapshot(pages={self.pages_crawled}, "
            f"mem={self.current_memory_mb:.1f}MB)"
        )

    def __sizeof__(self) -> int:
        size = object.__sizeof__(self)
        size += sys.getsizeof(self.timestamp)
        size += sys.getsizeof(self.pages_crawled)
        size += sys.getsizeof(self.current_memory_mb)
        size += sys.getsizeof(self.peak_memory_mb)
        size += sys.getsizeof(self.top_stats)
        for stat in self.top_stats:
            size += sys.getsizeof(stat)
        return size

    def to_dict(self) -> dict[str, Any]:
        return {
            'timestamp': self.timestamp,
            'datetime': self.datetime_str,
            'pages_crawled': self.pages_crawled,
            'current_memory_mb': round(self.current_memory_mb, 2),
            'peak_memory_mb': round(self.peak_memory_mb, 2),
            'top_consumers': [
                {
                    'file': stat[0],
                    'size_mb': round(stat[1] / (1024 * 1024), 2),
                    'count': stat[2],
                }
                for stat in self.top_stats[:10]
            ],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SlottedMemorySnapshot:
        top_stats = []
        for consumer in data.get('top_consumers', []):
            top_stats.append((
                consumer['file'],
                int(consumer['size_mb'] * 1024 * 1024),
                consumer['count'],
            ))

        return cls(
            timestamp=data['timestamp'],
            pages_crawled=data['pages_crawled'],
            current_memory_mb=data['current_memory_mb'],
            peak_memory_mb=data['peak_memory_mb'],
            top_stats=top_stats,
        )


class SlottedBatchResult:
    """
    Memory-optimized batch processing result.

    Used for storing results of URL batch processing.

    Attributes:
        successful_urls: List of successfully processed URLs
        failed_urls: List of failed URLs with error messages
        new_urls_found: List of newly discovered URLs
        processing_time_ms: Batch processing time in milliseconds
    """

    __slots__ = (
        'successful_urls', 'failed_urls', 'new_urls_found',
        'processing_time_ms', '_success_count', '_fail_count'
    )

    def __init__(self):
        self.successful_urls: list[str] = []
        self.failed_urls: list[tuple[str, str]] = []  # (url, error_message)
        self.new_urls_found: list[str] = []
        self.processing_time_ms: float = 0.0
        self._success_count: int = 0
        self._fail_count: int = 0

    def add_success(self, url: str, new_urls: list[str] | None = None) -> None:
        self.successful_urls.append(url)
        self._success_count += 1
        if new_urls:
            self.new_urls_found.extend(new_urls)

    def add_failure(self, url: str, error: str) -> None:
        self.failed_urls.append((url, error))
        self._fail_count += 1

    @property
    def total_processed(self) -> int:
        return self._success_count + self._fail_count

    @property
    def success_rate(self) -> float:
        total = self.total_processed
        if total == 0:
            return 0.0
        return self._success_count / total

    def clear(self) -> None:
        self.successful_urls.clear()
        self.failed_urls.clear()
        self.new_urls_found.clear()
        self.processing_time_ms = 0.0
        self._success_count = 0
        self._fail_count = 0

    def __repr__(self) -> str:
        return (
            f"BatchResult(ok={self._success_count}, fail={self._fail_count}, "
            f"new={len(self.new_urls_found)}, time={self.processing_time_ms:.0f}ms)"
        )


class CompactURLSet:
    """
    Memory-efficient URL set using hash integers instead of full strings.

    Stores only URL hashes for O(1) membership testing.
    Full URLs can be optionally stored in a separate list.

    Memory comparison (1M URLs, avg 80 chars):
    - set[str]: ~80MB (strings) + ~56MB (set overhead) = ~136MB
    - CompactURLSet: ~8MB (hashes only)
    - Savings: ~94%

    Trade-off: Cannot iterate URLs without separate storage.

    Attributes:
        _hashes: Set of URL hashes (integers)
        _urls: Optional list of actual URLs (for iteration)
        _store_urls: Whether to store actual URLs
    """

    __slots__ = ('_hashes', '_urls', '_store_urls')

    def __init__(self, store_urls: bool = False):
        """
        Initialize CompactURLSet.

        Args:
            store_urls: If True, stores actual URLs for iteration.
                       If False, only stores hashes (maximum memory savings).
        """
        self._hashes: set[int] = set()
        self._urls: list[str] | None = [] if store_urls else None
        self._store_urls = store_urls

    def add(self, url: str) -> bool:
        """
        Add URL to set.

        Args:
            url: URL to add

        Returns:
            True if URL was added (not duplicate)
        """
        url_hash = hash(url)
        if url_hash in self._hashes:
            return False

        self._hashes.add(url_hash)
        if self._store_urls and self._urls is not None:
            self._urls.append(url)
        return True

    def __contains__(self, url: str) -> bool:
        """Check if URL is in set (O(1))."""
        return hash(url) in self._hashes

    def __len__(self) -> int:
        """Number of URLs in set."""
        return len(self._hashes)

    def __iter__(self) -> Iterator[str]:
        if self._urls is not None:
            return iter(self._urls)
        raise TypeError(
            "Cannot iterate CompactURLSet without store_urls=True. "
            "Use 'url in set' for membership testing."
        )

    def discard(self, url: str) -> None:
        """Remove URL from set (no-op if not present)."""
        url_hash = hash(url)
        self._hashes.discard(url_hash)
        if self._store_urls and self._urls is not None:
            try:
                self._urls.remove(url)
            except ValueError:
                pass

    def clear(self) -> None:
        self._hashes.clear()
        if self._urls is not None:
            self._urls.clear()

    def __repr__(self) -> str:
        return f"CompactURLSet(count={len(self)}, store_urls={self._store_urls})"

    def __sizeof__(self) -> int:
        size = object.__sizeof__(self)
        size += sys.getsizeof(self._hashes)
        # Each hash is ~28 bytes in Python
        size += len(self._hashes) * 28
        if self._urls is not None:
            size += sys.getsizeof(self._urls)
            for url in self._urls:
                size += sys.getsizeof(url)
        return size

    def memory_usage_mb(self) -> float:
        return self.__sizeof__() / (1024 * 1024)


class SlottedQueueItem:
    """
    Memory-optimized queue item for URL scheduling.

    Attributes:
        url: URL string
        priority: Scheduling priority (higher = sooner)
        depth: Crawl depth
        parent_url_hash: Hash of parent URL (saves memory vs full URL)
        added_at: Timestamp when added to queue
    """

    __slots__ = ('url', 'priority', 'depth', 'parent_url_hash', 'added_at', '_url_hash')

    def __init__(
        self,
        url: str,
        priority: int = 5,
        depth: int = 0,
        parent_url: str | None = None,
    ):
        self.url = url
        self.priority = priority
        self.depth = depth
        self.parent_url_hash = hash(parent_url) if parent_url else 0
        self.added_at = time.time()
        self._url_hash = hash(url)

    def __lt__(self, other: SlottedQueueItem) -> bool:
        """For priority queue ordering (higher priority first)."""
        if self.priority != other.priority:
            return self.priority > other.priority  # Higher priority = earlier
        return self.added_at < other.added_at  # Earlier added = earlier

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SlottedQueueItem):
            return self._url_hash == other._url_hash
        return False

    def __hash__(self) -> int:
        return self._url_hash

    def __repr__(self) -> str:
        return f"QueueItem({self.url!r}, p={self.priority}, d={self.depth})"


# Utility functions for memory measurement

def measure_object_size(obj: Any, seen: set[int] | None = None) -> int:
    """
    Recursively measure object memory size including nested objects.

    Args:
        obj: Object to measure
        seen: Set of already-seen object ids (for cycle detection)

    Returns:
        Total memory size in bytes
    """
    size = sys.getsizeof(obj)

    if seen is None:
        seen = set()

    obj_id = id(obj)
    if obj_id in seen:
        return 0
    seen.add(obj_id)

    if isinstance(obj, dict):
        size += sum(
            measure_object_size(k, seen) + measure_object_size(v, seen)
            for k, v in obj.items()
        )
    elif hasattr(obj, '__dict__'):
        size += measure_object_size(obj.__dict__, seen)
    elif hasattr(obj, '__iter__') and not isinstance(obj, (str, bytes, bytearray)):
        try:
            size += sum(measure_object_size(item, seen) for item in obj)
        except TypeError:
            pass

    return size


def compare_memory_savings(
    slotted_cls: type,
    regular_cls: type,
    sample_count: int = 1000,
    **init_kwargs: Any,
) -> dict[str, Any]:
    """
    Compare memory usage between slotted and regular class.

    Args:
        slotted_cls: Class with __slots__
        regular_cls: Regular class (with __dict__)
        sample_count: Number of instances to create
        **init_kwargs: Arguments for class initialization

    Returns:
        Dict with comparison results
    """
    import gc

    gc.collect()

    # Create slotted instances
    slotted_instances = [slotted_cls(**init_kwargs) for _ in range(sample_count)]
    slotted_size = sum(sys.getsizeof(obj) for obj in slotted_instances)

    gc.collect()

    # Create regular instances
    regular_instances = [regular_cls(**init_kwargs) for _ in range(sample_count)]
    regular_size = sum(sys.getsizeof(obj) for obj in regular_instances)

    gc.collect()

    savings_bytes = regular_size - slotted_size
    savings_percent = (savings_bytes / regular_size * 100) if regular_size > 0 else 0

    return {
        'slotted_class': slotted_cls.__name__,
        'regular_class': regular_cls.__name__,
        'sample_count': sample_count,
        'slotted_total_bytes': slotted_size,
        'regular_total_bytes': regular_size,
        'slotted_per_instance': slotted_size / sample_count,
        'regular_per_instance': regular_size / sample_count,
        'savings_bytes': savings_bytes,
        'savings_percent': round(savings_percent, 1),
        'savings_per_million_instances_mb': round(
            savings_bytes * 1000 / (1024 * 1024), 1
        ),
    }


__all__ = [
    'SlottedURLInfo',
    'SlottedCrawlProgress',
    'SlottedMemorySnapshot',
    'SlottedBatchResult',
    'CompactURLSet',
    'SlottedQueueItem',
    'measure_object_size',
    'compare_memory_savings',
]
