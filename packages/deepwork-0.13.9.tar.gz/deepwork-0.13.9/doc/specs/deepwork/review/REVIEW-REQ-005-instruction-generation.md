# REVIEW-REQ-005: Review Instruction Generation

## Overview

For each `ReviewTask`, the system generates a self-contained markdown instruction file that provides a review agent with everything it needs: the review instructions, the files to examine, and any additional context. These files are written to `.deepwork/tmp/review_instructions/` and referenced by path in the final CLI output. The instruction files use `@path` syntax so that Claude Code automatically reads the referenced files when the prompt is loaded.

## Requirements

### REVIEW-REQ-005.1: Instruction File Content

1. Each instruction file MUST be a valid markdown document.
2. The file MUST begin with a heading identifying the review rule and scope (e.g., `# Review: python_file_best_practices — src/app.py`).
3. The file MUST contain a "Review Instructions" section with the rule's resolved instruction text.
4. The file MUST contain a "Files to Review" section listing the file paths to examine when the task has at least one file to review.
5. File paths in the "Files to Review" section MUST be relative to the repository root.
6. When the task has `additional_files` (unchanged matching files), the file MUST contain an "Unchanged Matching Files" section listing those file paths.
7. When the task has `all_changed_filenames`, the file MUST contain an "All Changed Files" section listing every changed filename for context.
8. When the task has `inline_content` set (used for `type: string` step outputs — see JOBS-REQ-004.8), the file MUST contain a "Content to Review" section whose body is the inline content verbatim.
9. The file MUST contain a "Project Root" section near the top (between the header and "Review Instructions") that states the absolute path of the project root against which all relative file paths in the document are resolved, and that instructs the reviewer to prepend this root when calling the Read tool. This is required so reviewer subagents read files from the correct working tree when their current working directory differs from the project root — e.g., when the review runs against a git worktree dispatched from the main checkout.
10. Inline-content tasks (see REVIEW-REQ-005.1.8) MUST NOT include a "Files to Review" section.
11. The review heading scope MUST read `inline content` when the task has `inline_content` and no `files_to_review`.

### REVIEW-REQ-005.2: File Path Formatting

1. File paths in the "Files to Review" section MUST be prefixed with `@` to trigger Claude Code's file-reading behavior (e.g., `@src/app.py`).
2. File paths in the "Unchanged Matching Files" section MUST also be prefixed with `@`.
3. File paths in the "All Changed Files" section MUST NOT be prefixed with `@` (they are listed for informational context only, not for the agent to read in full).

### REVIEW-REQ-005.3: File Writing

1. Instruction files MUST be written to `.deepwork/tmp/review_instructions/` under the project root.
2. The directory MUST be created if it does not exist (with `parents=True, exist_ok=True`).
3. Each file MUST have a unique filename with a `.md` extension.
4. ~~The filename MUST be a random numeric ID (e.g., `7142141.md`) to avoid collisions.~~ *Superseded by REVIEW-REQ-009.3.4*: filenames MUST be deterministic `{review_id}.md`.
5. The system MUST use `fs.safe_write()` for writing instruction files.
6. The system MUST return a list of `(ReviewTask, Path)` tuples mapping each task to its generated instruction file path.

### REVIEW-REQ-005.4: Instruction Resolution

1. When the rule's instructions reference a file (`{file: "path"}`), the system MUST resolve the path relative to the rule's `source_dir` and read the file contents.
2. The resolved instruction text MUST be included verbatim in the instruction file.
3. If the referenced file cannot be read, the system MUST raise an error with the file path and reason.

### REVIEW-REQ-005.5: Cleanup

1. The system SHOULD clear the `.deepwork/tmp/review_instructions/` directory at the start of each `deepwork review` invocation to avoid stale instruction files from previous runs.

### REVIEW-REQ-005.6: Policy Traceability

1. Each instruction file MUST end with a traceability line linking back to the source `.deepreview` file and rule location.
2. The traceability line MUST be formatted as: `This review was requested by the policy at \`{source_location}\`.` where `source_location` is the relative file path and line number (e.g., `src/.deepreview:5`).
3. The traceability line MUST be preceded by a markdown horizontal rule (`---`).
4. When `source_location` is empty, the traceability section MUST be omitted.

### REVIEW-REQ-005.7: Precomputed Context Section

1. When a task has precomputed info, the instruction file MUST contain a "Precomputed Context" section.
2. The "Precomputed Context" section MUST be the last content section in the instruction file, appearing after all file listing sections and before the "After Review" section.
3. The section MUST contain the verbatim stdout of the precomputed command.
4. When the command failed, the section MUST contain an error message with stderr and exit code.

### REVIEW-REQ-005.8: Relevant File Contents Section

1. When a task's `reference_files` is empty, the instruction file MUST NOT contain a "Relevant File Contents" section.
2. When a task has `reference_files`, the instruction file MUST contain a "## Relevant File Contents" section placed between "Review Instructions" and "Files to Review".
3. Each inlined file MUST be rendered with a `### {relative_label}` subheading, the optional description, and the file contents inside a fenced code block whose language is inferred from the file extension.
4. The number of inlined reference files MUST NOT exceed `MAX_INLINE_FILES` (20).
5. The total inlined byte size of reference file contents MUST NOT exceed `MAX_INLINE_TOTAL_BYTES` (256 * 1024).
6. When a referenced file cannot be read (missing, permission denied, or invalid UTF-8), the system MUST emit a graceful marker line referencing the file and the error.
7. Reference file entries beyond the `MAX_INLINE_FILES` cap MUST be listed in an "omitted due to size/count caps" summary line rather than inlined.
8. When a reference file's content would exceed the remaining byte budget, the file MUST be truncated with a visible truncation marker.
9. Reference file entries that cannot be inlined because the byte budget was exhausted by a preceding truncation MUST be reported in the omitted summary line.
10. When a referenced file cannot be read, the system MUST NOT abort the "Relevant File Contents" section.
11. When a referenced file cannot be read, the system MUST NOT count the file's would-be bytes against the total byte budget.
