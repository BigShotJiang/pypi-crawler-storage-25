"""Tests for the review MCP adapter (deepwork.review.mcp).

Validates requirements: REVIEW-REQ-002, REVIEW-REQ-002.1, REVIEW-REQ-002.2,
REVIEW-REQ-002.3, REVIEW-REQ-002.4, REVIEW-REQ-008, REVIEW-REQ-008.1, REVIEW-REQ-008.2,
REVIEW-REQ-008.3, REVIEW-REQ-008.4.
"""

from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from deepwork.review.config import ReviewRule, ReviewTask
from deepwork.review.mcp import (
    ReviewToolError,
    all_reviews_passed_for_files,
    get_configured_reviews,
    mark_passed,
    run_review,
)


def _make_rule(tmp_path: Path) -> ReviewRule:
    """Create a ReviewRule for testing."""
    return ReviewRule(
        name="test_rule",
        description="Test rule description.",
        include_patterns=["**/*.py"],
        exclude_patterns=[],
        strategy="individual",
        instructions="Review it.",
        agent=None,
        all_changed_filenames=False,
        unchanged_matching_files=False,
        precomputed_info_bash_command=None,
        source_dir=tmp_path,
        source_file=tmp_path / ".deepreview",
        source_line=1,
    )


class TestRunReview:
    """Tests for the run_review adapter function."""

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_no_deepreview_files_returns_message(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.4.1).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([], [])
        result = run_review(tmp_path, "claude")
        assert "No .deepreview configuration files" in result

    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_no_changed_files_git_diff(
        self, mock_load: Any, mock_diff: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.4.2).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([_make_rule(tmp_path)], [])
        mock_diff.return_value = []
        result = run_review(tmp_path, "claude")
        assert "No changed files detected" in result

    @patch("deepwork.review.mcp.load_all_rules")
    def test_no_changed_files_explicit_empty_list(self, mock_load: Any, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.4.2).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([_make_rule(tmp_path)], [])
        result = run_review(tmp_path, "claude", files=[])
        assert "No changed files detected" in result

    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_no_rules_match(
        self, mock_load: Any, mock_diff: Any, mock_match: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.4.3).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([_make_rule(tmp_path)], [])
        mock_diff.return_value = ["app.ts"]
        mock_match.return_value = []
        result = run_review(tmp_path, "claude")
        assert "No review rules matched" in result

    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_git_diff_error_raises_review_tool_error(
        self, mock_load: Any, mock_diff: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.5.2).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        from deepwork.review.matcher import GitDiffError

        mock_load.return_value = ([_make_rule(tmp_path)], [])
        mock_diff.side_effect = GitDiffError("not a git repo")
        with pytest.raises(ReviewToolError, match="Git error"):
            run_review(tmp_path, "claude")

    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_explicit_files_bypass_git_diff(
        self, mock_load: Any, mock_diff: Any, mock_match: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.6.1).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([_make_rule(tmp_path)], [])
        mock_match.return_value = []
        run_review(tmp_path, "claude", files=["src/a.py", "src/b.py"])
        mock_diff.assert_not_called()
        mock_match.assert_called_once()
        called_files = mock_match.call_args[0][0]
        assert called_files == ["src/a.py", "src/b.py"]

    @patch("deepwork.review.mcp.write_instruction_files")
    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_full_pipeline_returns_formatted_output(
        self, mock_load: Any, mock_diff: Any, mock_match: Any, mock_write: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.2.1, REVIEW-REQ-006.3.2).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        rule = _make_rule(tmp_path)
        task = ReviewTask(
            rule_name="test_rule",
            files_to_review=["app.py"],
            instructions="Review it.",
            agent_name=None,
        )
        mock_load.return_value = ([rule], [])
        mock_diff.return_value = ["app.py"]
        mock_match.return_value = [task]
        mock_write.return_value = [(task, tmp_path / "instr.md")]

        result = run_review(tmp_path, "claude")
        assert "Invoke the following" in result
        mock_write.assert_called_once()

    def test_unsupported_platform_raises_review_tool_error(self, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.1.3).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        with pytest.raises(ReviewToolError, match="Unsupported platform"):
            run_review(tmp_path, "unsupported_platform")

    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_files_are_deduplicated_and_sorted(
        self, mock_load: Any, mock_match: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.6.4).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([_make_rule(tmp_path)], [])
        mock_match.return_value = []
        run_review(tmp_path, "claude", files=["z.py", "a.py", "z.py"])
        called_files = mock_match.call_args[0][0]
        assert called_files == ["a.py", "z.py"]

    @patch("deepwork.review.mcp.write_instruction_files")
    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_write_error_raises_review_tool_error(
        self, mock_load: Any, mock_diff: Any, mock_match: Any, mock_write: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.5.3).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        rule = _make_rule(tmp_path)
        task = ReviewTask(
            rule_name="test_rule",
            files_to_review=["app.py"],
            instructions="Review it.",
            agent_name=None,
        )
        mock_load.return_value = ([rule], [])
        mock_diff.return_value = ["app.py"]
        mock_match.return_value = [task]
        mock_write.side_effect = OSError("Permission denied")

        with pytest.raises(ReviewToolError, match="Error writing instruction files"):
            run_review(tmp_path, "claude")


def _get_tool_names(server: Any) -> set[str]:
    """Get registered tool names from a FastMCP server (works with v2 and v3)."""
    import asyncio

    tools = asyncio.run(server.list_tools())
    return {t.name for t in tools}


class TestRunReviewDiscoveryWarnings:
    """Tests for discovery warning handling in run_review."""

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-002.3.4).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.gen_schema_rules")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_no_valid_rules_with_parse_errors_shows_warnings(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        """When no valid rules exist but there are discovery errors, shows parse errors."""
        from deepwork.review.discovery import DiscoveryError

        mock_load.return_value = (
            [],
            [DiscoveryError(file_path=Path("bad/.deepreview"), error="bad yaml")],
        )
        mock_schema.return_value = ([], [])

        result = run_review(tmp_path, "claude")
        assert "No valid review rules found" in result
        assert "bad/.deepreview" in result
        assert "bad yaml" in result

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-002.3.4).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.gen_schema_rules")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_schema_errors_appended_to_discovery_errors(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        """DeepSchema errors are appended to discovery_errors."""

        mock_load.return_value = ([], [])
        mock_schema.return_value = ([], ["schema parse failed"])

        result = run_review(tmp_path, "claude")
        # No rules at all (empty from both sources), but there's a schema error
        assert "No valid review rules found" in result
        assert "schema parse failed" in result

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-002.3.4).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.write_instruction_files")
    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.gen_schema_rules")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_discovery_warnings_prepended_to_output(
        self,
        mock_load: Any,
        mock_schema: Any,
        mock_diff: Any,
        mock_match: Any,
        mock_write: Any,
        tmp_path: Path,
    ) -> None:
        """When discovery errors exist alongside valid rules, warnings are prepended."""
        from deepwork.review.discovery import DiscoveryError

        rule = _make_rule(tmp_path)
        task = ReviewTask(
            rule_name="test_rule",
            files_to_review=["app.py"],
            instructions="Review it.",
            agent_name=None,
        )
        mock_load.return_value = (
            [rule],
            [DiscoveryError(file_path=Path("x/.deepreview"), error="parse error")],
        )
        mock_schema.return_value = ([], [])
        mock_diff.return_value = ["app.py"]
        mock_match.return_value = [task]
        mock_write.return_value = [(task, tmp_path / "instr.md")]

        result = run_review(tmp_path, "claude")
        assert "Warning: Some .deepreview files could not be parsed" in result
        assert "x/.deepreview" in result
        assert "parse error" in result


class TestReviewToolRegistration:
    """Test that the review tool is registered on the MCP server."""

    def test_review_tool_is_registered(self, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.1.1).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        """Review tool is registered on the MCP server with or without explicit platform."""
        from deepwork.jobs.mcp.server import create_server

        # With explicit platform
        server = create_server(
            project_root=tmp_path,
            enable_quality_gate=False,
            platform="claude",
        )
        assert "get_review_instructions" in _get_tool_names(server)

        # Without platform (defaults to claude)
        server_default = create_server(
            project_root=tmp_path,
            enable_quality_gate=False,
        )
        assert "get_review_instructions" in _get_tool_names(server_default)

    def test_get_configured_reviews_tool_is_registered(self, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.1.1).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        """get_configured_reviews is registered on the MCP server."""
        from deepwork.jobs.mcp.server import create_server

        server = create_server(
            project_root=tmp_path,
            enable_quality_gate=False,
        )
        assert "get_configured_reviews" in _get_tool_names(server)


@pytest.mark.usefixtures("without_standard_schemas")
class TestGetConfiguredReviews:
    """Tests for the get_configured_reviews adapter function — validates REVIEW-REQ-008."""

    @patch("deepwork.review.mcp.load_all_rules")
    def test_returns_all_rules(self, mock_load: Any, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.1.3, REVIEW-REQ-008.2.1, REVIEW-REQ-008.2.2, REVIEW-REQ-008.2.3).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        rule1 = _make_rule(tmp_path)
        rule2 = ReviewRule(
            name="lint_rule",
            description="Lint rule description.",
            include_patterns=["**/*.ts"],
            exclude_patterns=[],
            strategy="matches_together",
            instructions="Lint it.",
            agent=None,
            all_changed_filenames=False,
            unchanged_matching_files=False,
            precomputed_info_bash_command=None,
            source_dir=tmp_path,
            source_file=tmp_path / ".deepreview",
            source_line=10,
        )
        mock_load.return_value = ([rule1, rule2], [])

        result = get_configured_reviews(tmp_path)
        assert len(result) == 2
        assert result[0]["name"] == "test_rule"
        assert result[0]["description"] == "Test rule description."
        assert result[0]["defining_file"] == ".deepreview:1"
        assert result[1]["name"] == "lint_rule"
        assert result[1]["defining_file"] == ".deepreview:10"

    @patch("deepwork.review.mcp.load_all_rules")
    def test_returns_empty_when_no_rules(self, mock_load: Any, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.1.3).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([], [])
        result = get_configured_reviews(tmp_path)
        assert result == []

    @patch("deepwork.review.mcp.load_all_rules")
    def test_filters_by_matching_files(self, mock_load: Any, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.3.1).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        py_rule = _make_rule(tmp_path)  # includes **/*.py
        ts_rule = ReviewRule(
            name="ts_rule",
            description="TypeScript rule.",
            include_patterns=["**/*.ts"],
            exclude_patterns=[],
            strategy="individual",
            instructions="Review TS.",
            agent=None,
            all_changed_filenames=False,
            unchanged_matching_files=False,
            precomputed_info_bash_command=None,
            source_dir=tmp_path,
            source_file=tmp_path / ".deepreview",
            source_line=5,
        )
        mock_load.return_value = ([py_rule, ts_rule], [])

        result = get_configured_reviews(tmp_path, only_rules_matching_files=["src/app.py"])
        assert len(result) == 1
        assert result[0]["name"] == "test_rule"

    @patch("deepwork.review.mcp.load_all_rules")
    def test_no_filter_returns_all(self, mock_load: Any, tmp_path: Path) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.3.2).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        rule = _make_rule(tmp_path)
        mock_load.return_value = ([rule], [])

        result = get_configured_reviews(tmp_path, only_rules_matching_files=None)
        assert len(result) == 1
        assert result[0]["name"] == "test_rule"

    @patch("deepwork.review.mcp.load_all_rules")
    def test_duplicate_names_from_different_files_appear_separately(
        self, mock_load: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.2.4).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        """Same-named rules from different .deepreview files each appear as separate entries."""
        dir_a = tmp_path / "packages" / "alpha"
        dir_b = tmp_path / "packages" / "beta"
        dir_a.mkdir(parents=True)
        dir_b.mkdir(parents=True)

        rule_a = ReviewRule(
            name="lint",
            description="Lint check from alpha.",
            include_patterns=["**/*.py"],
            exclude_patterns=[],
            strategy="individual",
            instructions="Lint alpha.",
            agent=None,
            all_changed_filenames=False,
            unchanged_matching_files=False,
            precomputed_info_bash_command=None,
            source_dir=dir_a,
            source_file=dir_a / ".deepreview",
            source_line=1,
        )
        rule_b = ReviewRule(
            name="lint",
            description="Lint check from beta.",
            include_patterns=["**/*.py"],
            exclude_patterns=[],
            strategy="individual",
            instructions="Lint beta.",
            agent=None,
            all_changed_filenames=False,
            unchanged_matching_files=False,
            precomputed_info_bash_command=None,
            source_dir=dir_b,
            source_file=dir_b / ".deepreview",
            source_line=1,
        )
        mock_load.return_value = ([rule_a, rule_b], [])

        result = get_configured_reviews(tmp_path)

        assert len(result) == 2
        # Both entries share the same name
        assert result[0]["name"] == "lint"
        assert result[1]["name"] == "lint"
        # defining_file disambiguates them
        assert result[0]["defining_file"] == "packages/alpha/.deepreview:1"
        assert result[1]["defining_file"] == "packages/beta/.deepreview:1"
        # The two defining_file values must be distinct
        assert result[0]["defining_file"] != result[1]["defining_file"]

    @patch("deepwork.review.mcp.load_all_rules")
    def test_discovery_errors_still_return_valid_rules(
        self, mock_load: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.4.1, REVIEW-REQ-008.4.2).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        from deepwork.review.discovery import DiscoveryError

        rule = _make_rule(tmp_path)
        errors = [DiscoveryError(file_path=Path("/bad/.deepreview"), error="invalid YAML")]
        mock_load.return_value = ([rule], errors)

        result = get_configured_reviews(tmp_path)
        # Valid rules are returned, plus parse errors are surfaced
        valid_rules = [r for r in result if not r["name"].startswith("PARSE_ERROR:")]
        assert len(valid_rules) == 1
        assert valid_rules[0]["name"] == "test_rule"
        error_entries = [r for r in result if r["name"].startswith("PARSE_ERROR:")]
        assert len(error_entries) == 1


def _make_catch_all_rule(
    tmp_path: Path, name: str = "catch_all", pattern: str = "**/*"
) -> ReviewRule:
    return ReviewRule(
        name=name,
        description="Catch-all rule.",
        include_patterns=[pattern],
        exclude_patterns=[],
        strategy="individual",
        instructions="Review all.",
        agent=None,
        all_changed_filenames=False,
        unchanged_matching_files=False,
        precomputed_info_bash_command=None,
        source_dir=tmp_path,
        source_file=tmp_path / ".deepreview",
        source_line=1,
    )


class TestCatchAllFiltering:
    """When files are specified, rules with pure-wildcard include patterns are dropped."""

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_get_configured_reviews_drops_catch_all_when_files_specified(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.3.3).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        specific_rule = _make_rule(tmp_path)  # **/*.py
        mock_load.return_value = (
            [
                specific_rule,
                _make_catch_all_rule(tmp_path, "all_star", "*"),
                _make_catch_all_rule(tmp_path, "all_double", "**"),
                _make_catch_all_rule(tmp_path, "all_nested", "**/*"),
                _make_catch_all_rule(tmp_path, "all_trailing", "*/**"),
            ],
            [],
        )

        result = get_configured_reviews(tmp_path, only_rules_matching_files=["src/app.py"])
        names = [r["name"] for r in result]
        assert names == ["test_rule"]

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_get_configured_reviews_keeps_catch_all_when_no_files_specified(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-008.3.4).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        mock_load.return_value = ([_make_catch_all_rule(tmp_path)], [])
        result = get_configured_reviews(tmp_path, only_rules_matching_files=None)
        assert len(result) == 1
        assert result[0]["name"] == "catch_all"

    @patch("deepwork.review.mcp.write_instruction_files", return_value={})
    @patch("deepwork.review.mcp.format_for_claude", return_value="ok")
    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_run_review_drops_catch_all_when_files_specified(
        self,
        mock_load: Any,
        mock_schema: Any,
        mock_fmt: Any,
        mock_write: Any,
        tmp_path: Path,
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.6.6).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        specific_rule = _make_rule(tmp_path)
        catch_all = _make_catch_all_rule(tmp_path)
        mock_load.return_value = ([specific_rule, catch_all], [])

        with patch("deepwork.review.mcp.match_files_to_rules") as mock_match:
            mock_match.return_value = []
            run_review(tmp_path, "claude", files=["src/app.py"])
            passed_rules = mock_match.call_args[0][1]
            names = [r.name for r in passed_rules]
            assert names == ["test_rule"]

    @patch("deepwork.review.mcp.get_changed_files", return_value=["src/app.py"])
    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_run_review_keeps_catch_all_when_using_git_diff(
        self,
        mock_load: Any,
        mock_schema: Any,
        mock_diff: Any,
        tmp_path: Path,
    ) -> None:
        # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-006.6.6).
        # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
        catch_all = _make_catch_all_rule(tmp_path)
        mock_load.return_value = ([catch_all], [])

        with patch("deepwork.review.mcp.match_files_to_rules") as mock_match:
            mock_match.return_value = []
            run_review(tmp_path, "claude", files=None)
            passed_rules = mock_match.call_args[0][1]
            assert [r.name for r in passed_rules] == ["catch_all"]


class TestMarkPassed:
    """Tests for the mark_passed adapter function — validates REVIEW-REQ-009.2."""

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.3).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_creates_passed_file(self, tmp_path: Path) -> None:
        mark_passed(tmp_path, "rule--file--abc123def456")
        passed_file = (
            tmp_path
            / ".deepwork"
            / "tmp"
            / "review_instructions"
            / "rule--file--abc123def456.passed"
        )
        assert passed_file.exists()

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.3).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_passed_file_is_empty(self, tmp_path: Path) -> None:
        mark_passed(tmp_path, "rule--file--abc123def456")
        passed_file = (
            tmp_path
            / ".deepwork"
            / "tmp"
            / "review_instructions"
            / "rule--file--abc123def456.passed"
        )
        assert passed_file.read_bytes() == b""

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.4).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_creates_directory_if_missing(self, tmp_path: Path) -> None:
        instructions_dir = tmp_path / ".deepwork" / "tmp" / "review_instructions"
        assert not instructions_dir.exists()

        mark_passed(tmp_path, "rule--file--abc123def456")

        assert instructions_dir.exists()

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.7).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_returns_confirmation_message(self, tmp_path: Path) -> None:
        result = mark_passed(tmp_path, "rule--file--abc123def456")
        assert "rule--file--abc123def456" in result
        assert "marked as passed" in result

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.5).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_rejects_empty_review_id(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="must not be empty"):
            mark_passed(tmp_path, "")

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.6).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_rejects_path_traversal(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="path traversal"):
            mark_passed(tmp_path, "../etc/passwd")

        with pytest.raises(ValueError, match="path traversal"):
            mark_passed(tmp_path, "/absolute/path")


class TestMarkReviewAsPassedMCPTool:
    """Tests for mark_review_as_passed tool registration — validates REVIEW-REQ-009.2.1, REVIEW-REQ-009.2.2."""

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.1).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_tool_is_registered(self, tmp_path: Path) -> None:
        from deepwork.jobs.mcp.server import create_server

        server = create_server(
            project_root=tmp_path,
            enable_quality_gate=False,
        )
        assert "mark_review_as_passed" in _get_tool_names(server)

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.2.2).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    def test_review_id_is_required_string_parameter(self, tmp_path: Path) -> None:
        """The review_id parameter MUST be a required string."""
        import asyncio

        from deepwork.jobs.mcp.server import create_server

        server = create_server(
            project_root=tmp_path,
            enable_quality_gate=False,
        )
        tools = asyncio.run(server.list_tools())
        tool = next(t for t in tools if t.name == "mark_review_as_passed")
        params = tool.parameters
        assert "review_id" in params["properties"]
        assert params["properties"]["review_id"]["type"] == "string"
        assert "review_id" in params["required"]


class TestRunReviewPassedFiltering:
    """Test that passed reviews are excluded from run_review output — validates REVIEW-REQ-009.0, REVIEW-REQ-009.3."""

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.0.1).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_passed_review_not_rerun_when_files_unchanged(
        self, mock_load: Any, mock_diff: Any, mock_match: Any, tmp_path: Path
    ) -> None:
        """A review that passed is not re-run while the triggering files remain unchanged."""
        from deepwork.review.instructions import compute_review_id

        rule = _make_rule(tmp_path)
        task = ReviewTask(
            rule_name="test_rule",
            files_to_review=["app.py"],
            instructions="Review it.",
            agent_name=None,
        )
        mock_load.return_value = ([rule], [])
        mock_diff.return_value = ["app.py"]
        mock_match.return_value = [task]

        # Simulate: the review passed and the agent called mark_review_as_passed
        review_id = compute_review_id(task, tmp_path)
        mark_passed(tmp_path, review_id)

        # Subsequent run with unchanged files → review is skipped
        result = run_review(tmp_path, "claude")
        assert "No review tasks to execute" in result

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.3.2).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.match_files_to_rules")
    @patch("deepwork.review.mcp.get_changed_files")
    @patch("deepwork.review.mcp.load_all_rules")
    def test_passed_reviews_excluded_from_output(
        self, mock_load: Any, mock_diff: Any, mock_match: Any, tmp_path: Path
    ) -> None:
        """When all reviews have .passed markers, write_instruction_files returns empty → 'No review tasks'."""
        from deepwork.review.instructions import compute_review_id

        rule = _make_rule(tmp_path)
        task = ReviewTask(
            rule_name="test_rule",
            files_to_review=["app.py"],
            instructions="Review it.",
            agent_name=None,
        )
        mock_load.return_value = ([rule], [])
        mock_diff.return_value = ["app.py"]
        mock_match.return_value = [task]

        # Pre-create the .passed marker for this task
        review_id = compute_review_id(task, tmp_path)
        instructions_dir = tmp_path / ".deepwork" / "tmp" / "review_instructions"
        instructions_dir.mkdir(parents=True)
        (instructions_dir / f"{review_id}.passed").write_bytes(b"")

        result = run_review(tmp_path, "claude")
        assert "No review tasks to execute" in result


@pytest.mark.usefixtures("without_standard_schemas")
class TestGetConfiguredReviewsUnaffectedByCache:
    """Tests that get_configured_reviews ignores pass caching — validates REVIEW-REQ-009.6."""

    # THIS TEST VALIDATES A HARD REQUIREMENT (REVIEW-REQ-009.6.1).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.load_all_rules")
    def test_get_configured_reviews_ignores_passed_markers(
        self, mock_load: Any, tmp_path: Path
    ) -> None:
        """Creating .passed markers does not affect get_configured_reviews output."""
        rule = _make_rule(tmp_path)
        mock_load.return_value = ([rule], [])

        # Create a .passed marker
        instructions_dir = tmp_path / ".deepwork" / "tmp" / "review_instructions"
        instructions_dir.mkdir(parents=True)
        (instructions_dir / "test_rule--src-app.py--abc123def456.passed").write_bytes(b"")

        result = get_configured_reviews(tmp_path)
        assert len(result) == 1
        assert result[0]["name"] == "test_rule"


@pytest.mark.usefixtures("without_standard_schemas")
class TestAllReviewsPassedForFiles:
    """Tests for all_reviews_passed_for_files — validates PLUG-REQ-001.7."""

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules", return_value=([], []))
    def test_empty_file_list(self, mock_load: Any, mock_schema: Any, tmp_path: Path) -> None:
        assert all_reviews_passed_for_files(tmp_path, []) is True

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules", return_value=([], []))
    def test_no_rules(self, mock_load: Any, mock_schema: Any, tmp_path: Path) -> None:
        assert all_reviews_passed_for_files(tmp_path, ["src/app.py"]) is True

    # THIS TEST VALIDATES A HARD REQUIREMENT (PLUG-REQ-001.7.3).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_only_catch_all_rule(self, mock_load: Any, mock_schema: Any, tmp_path: Path) -> None:
        """Catch-all rules are excluded, so only having one means True."""
        mock_load.return_value = ([_make_catch_all_rule(tmp_path)], [])
        assert all_reviews_passed_for_files(tmp_path, ["src/app.py"]) is True

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_non_matching_rule(self, mock_load: Any, mock_schema: Any, tmp_path: Path) -> None:
        """A non-catch-all rule that doesn't match the files returns True."""
        py_rule = _make_rule(tmp_path)  # **/*.py
        mock_load.return_value = ([py_rule], [])
        assert all_reviews_passed_for_files(tmp_path, ["src/app.ts"]) is True

    # THIS TEST VALIDATES A HARD REQUIREMENT (PLUG-REQ-001.7.4).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_matching_rule_with_passed_marker(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        from deepwork.review.instructions import INSTRUCTIONS_DIR, compute_review_id

        rule = _make_rule(tmp_path)
        mock_load.return_value = ([rule], [])

        # Create the file so compute_review_id produces a stable hash
        (tmp_path / "src").mkdir(parents=True, exist_ok=True)
        (tmp_path / "src" / "app.py").write_text("print('hello')")

        # First call to get the tasks and compute their IDs
        from deepwork.review.matcher import match_files_to_rules

        tasks = match_files_to_rules(["src/app.py"], [rule], tmp_path)
        assert len(tasks) >= 1
        review_id = compute_review_id(tasks[0], tmp_path)

        # Create the .passed marker
        instructions_dir = tmp_path / INSTRUCTIONS_DIR
        instructions_dir.mkdir(parents=True, exist_ok=True)
        (instructions_dir / f"{review_id}.passed").write_bytes(b"")

        assert all_reviews_passed_for_files(tmp_path, ["src/app.py"]) is True

    # THIS TEST VALIDATES A HARD REQUIREMENT (PLUG-REQ-001.7.2).
    # YOU MUST NOT MODIFY THIS TEST UNLESS THE REQUIREMENT CHANGES
    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_matching_rule_without_passed_marker(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        rule = _make_rule(tmp_path)
        mock_load.return_value = ([rule], [])

        (tmp_path / "src").mkdir(parents=True, exist_ok=True)
        (tmp_path / "src" / "app.py").write_text("print('hello')")

        assert all_reviews_passed_for_files(tmp_path, ["src/app.py"]) is False

    @patch("deepwork.review.mcp.gen_schema_rules", return_value=([], []))
    @patch("deepwork.review.mcp.load_all_rules")
    def test_mixed_passed_and_not_passed(
        self, mock_load: Any, mock_schema: Any, tmp_path: Path
    ) -> None:
        from deepwork.review.instructions import INSTRUCTIONS_DIR, compute_review_id
        from deepwork.review.matcher import match_files_to_rules

        rule_py = _make_rule(tmp_path)  # **/*.py
        rule_ts = ReviewRule(
            name="ts_rule",
            description="TS rule.",
            include_patterns=["**/*.ts"],
            exclude_patterns=[],
            strategy="individual",
            instructions="Review TS.",
            agent=None,
            all_changed_filenames=False,
            unchanged_matching_files=False,
            precomputed_info_bash_command=None,
            source_dir=tmp_path,
            source_file=tmp_path / ".deepreview",
            source_line=5,
        )
        mock_load.return_value = ([rule_py, rule_ts], [])

        (tmp_path / "src").mkdir(parents=True, exist_ok=True)
        (tmp_path / "src" / "app.py").write_text("py")
        (tmp_path / "src" / "app.ts").write_text("ts")

        # Mark only the py task as passed
        py_tasks = match_files_to_rules(["src/app.py"], [rule_py], tmp_path)
        review_id = compute_review_id(py_tasks[0], tmp_path)
        instructions_dir = tmp_path / INSTRUCTIONS_DIR
        instructions_dir.mkdir(parents=True, exist_ok=True)
        (instructions_dir / f"{review_id}.passed").write_bytes(b"")

        # ts task is not passed → overall False
        assert all_reviews_passed_for_files(tmp_path, ["src/app.py", "src/app.ts"]) is False
