"""Tests for jobs module."""
