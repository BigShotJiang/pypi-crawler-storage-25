# coding: utf-8

"""
    OneLogin API Python SDK

    Official Python SDK for the OneLogin API
"""


from __future__ import annotations
import pprint
import re  # noqa: F401
import json


from typing import List, Optional
from pydantic import BaseModel, Field, StrictStr, conlist
from onelogin.models.error import Error

class GetCustomAttributes200Response(BaseModel):
    """
    GetCustomAttributes200Response
    """
    status: Optional[Error] = None
    data: Optional[conlist(conlist(StrictStr))] = Field(None, description="Provides a list of custom attribute fields (also known as custom user fields) that are available for your account. The values returned correspond to the values you provided in the Shortname field when you defined the custom user field. For details about defining custom user fields, see Custom User Fields.")
    __properties = ["status", "data"]

    """Pydantic configuration"""
    model_config = {
        "validate_by_name": True,
        "validate_by_alias": True,
        "validate_assignment": True
    }

    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> GetCustomAttributes200Response:
        """Create an instance of GetCustomAttributes200Response from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self):
        """Returns the dictionary representation of the model using alias"""
        _dict = self.model_dump(by_alias=True,
                          exclude={
                          },
                          exclude_none=True)
        # override the default output from pydantic by calling `to_dict()` of status
        if self.status:
            _dict['status'] = self.status.to_dict()
        return _dict

    @classmethod
    def from_dict(cls, obj: dict) -> GetCustomAttributes200Response:
        """Create an instance of GetCustomAttributes200Response from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return GetCustomAttributes200Response.model_validate(obj)

        _obj = GetCustomAttributes200Response.model_validate({
            "status": Error.from_dict(obj.get("status")) if obj.get("status") is not None else None,
            "data": obj.get("data")
        })
        return _obj

