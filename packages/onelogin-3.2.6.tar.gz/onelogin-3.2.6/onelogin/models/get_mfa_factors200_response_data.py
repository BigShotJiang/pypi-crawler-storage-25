# coding: utf-8

"""
    OneLogin API Python SDK

    Official Python SDK for the OneLogin API
"""


from __future__ import annotations
import pprint
import re  # noqa: F401
import json


from typing import List, Optional
from pydantic import BaseModel, conlist
from onelogin.models.get_mfa_factors200_response_data_auth_factors_inner import GetMFAFactors200ResponseDataAuthFactorsInner

class GetMFAFactors200ResponseData(BaseModel):
    """
    GetMFAFactors200ResponseData
    """
    auth_factors: Optional[conlist(GetMFAFactors200ResponseDataAuthFactorsInner)] = None
    __properties = ["auth_factors"]

    """Pydantic configuration"""
    model_config = {
        "validate_by_name": True,
        "validate_by_alias": True,
        "validate_assignment": True
    }

    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> GetMFAFactors200ResponseData:
        """Create an instance of GetMFAFactors200ResponseData from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self):
        """Returns the dictionary representation of the model using alias"""
        _dict = self.model_dump(by_alias=True,
                          exclude={
                          },
                          exclude_none=True)
        # override the default output from pydantic by calling `to_dict()` of each item in auth_factors (list)
        _items = []
        if self.auth_factors:
            for _item in self.auth_factors:
                if _item:
                    _items.append(_item.to_dict())
            _dict['auth_factors'] = _items
        return _dict

    @classmethod
    def from_dict(cls, obj: dict) -> GetMFAFactors200ResponseData:
        """Create an instance of GetMFAFactors200ResponseData from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return GetMFAFactors200ResponseData.model_validate(obj)

        _obj = GetMFAFactors200ResponseData.model_validate({
            "auth_factors": [GetMFAFactors200ResponseDataAuthFactorsInner.from_dict(_item) for _item in obj.get("auth_factors")] if obj.get("auth_factors") is not None else None
        })
        return _obj

