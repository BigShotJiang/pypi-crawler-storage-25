# coding: utf-8

"""
    OneLogin API Python SDK

    Official Python SDK for the OneLogin API
"""


from __future__ import annotations
import pprint
import re  # noqa: F401
import json


from typing import Optional
from pydantic import BaseModel, Field, StrictInt, StrictStr

class ListMappingActionValues200ResponseInner(BaseModel):
    """
    ListMappingActionValues200ResponseInner
    """
    name: Optional[StrictStr] = Field(None, description="Name or description of operator")
    value: Optional[StrictInt] = Field(None, description="The action operator value to use when creating or updating User Mappings.")
    __properties = ["name", "value"]

    """Pydantic configuration"""
    model_config = {
        "validate_by_name": True,
        "validate_by_alias": True,
        "validate_assignment": True
    }

    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> ListMappingActionValues200ResponseInner:
        """Create an instance of ListMappingActionValues200ResponseInner from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self):
        """Returns the dictionary representation of the model using alias"""
        _dict = self.model_dump(by_alias=True,
                          exclude={
                          },
                          exclude_none=True)
        return _dict

    @classmethod
    def from_dict(cls, obj: dict) -> ListMappingActionValues200ResponseInner:
        """Create an instance of ListMappingActionValues200ResponseInner from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return ListMappingActionValues200ResponseInner.model_validate(obj)

        _obj = ListMappingActionValues200ResponseInner.model_validate({
            "name": obj.get("name"),
            "value": obj.get("value")
        })
        return _obj

