"""Default descriptions and server registry for well-known MCP servers."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# ── Shared constants ─────────────────────────────────────────────────────────

# VS Code / Agency shared Entra app registration.
SHARED_ENTRA_CLIENT_ID = "aebc6443-996d-45c2-90f0-388ff96faa56"

# GitHub CLI's public OAuth App client ID (https://github.com/cli/cli)
GH_CLI_CLIENT_ID = "178c6fc778ccc68e1d6a"
# Scopes matching `gh auth login` defaults — needed for GitHub MCP (repos, PRs, etc.)
GH_MCP_SCOPE = "repo read:org gist workflow"

# Microsoft corp tenant (default for agent365 URLs).
DEFAULT_TENANT = "72f988bf-86f1-41af-91ab-2d7cd011db47"

_AGENT365_BASE = "https://agent365.svc.cloud.microsoft/agents/tenants/{tenant}/servers/"

# Servers that should NOT be pre-selected in --all / interactive default.
NOT_RECOMMENDED: set[str] = {"workiq", "enghub"}

# ── Recommendation groups ───────────────────────────────────────────────────
# Used by mcp setup to pre-select servers based on detected user profile.

# Office: productivity tools, recommended for all Microsoft 365 users.
GROUP_OFFICE: set[str] = {
    "teams",
    "calendar",
    "mail",
    "onedrive",
    "word",
    "sharepoint",
    "user",
    "m365copilot",
}

# Engineering: recommended when dev tools detected (git, gh, az, ADO remote).
GROUP_ENGINEERING: set[str] = {
    "github",
    "ado",
    "bluebird",
    "icm",
    "es-chat",
    "microsoft-learn",
    "cloudbuild",
    "service-tree",
}

# Security: not recommended by default, manual selection.
GROUP_SECURITY: set[str] = {"security-context", "s360-breeze"}

# Data: recommended when Kusto/KQL detected (.kql files, kusto CLI).
GROUP_DATA: set[str] = {"kusto"}

# Regex for {var} placeholders in URLs, headers, env values.
_PLACEHOLDER_RE = re.compile(r"\{([a-zA-Z_]\w*)\}")

# ── Server Registry ──────────────────────────────────────────────────────────
# Only servers needing installation metadata (stdio command/env) or legacy
# aliases belong here. HTTP servers (including those with {var} params like
# ado, bluebird) are fully defined in workpilot.yaml.


@dataclass(frozen=True)
class ServerEntry:
    """Metadata for a well-known MCP server (HTTP, stdio, or legacy alias)."""

    url: str  # May contain {var} placeholders. Empty for stdio-only.
    description: str
    recommended: bool = True
    headers: dict[str, str] = field(default_factory=dict)
    auth_server_url: str | None = None  # Override for servers without PRM
    package_server: bool = False  # npx/uvx — needs longer timeout
    # Stdio server config (command + args + env) — no Agency dependency.
    command: str | None = None
    command_args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)

    @property
    def params(self) -> set[str]:
        """Parameter names extracted from {var} placeholders in url/headers/env."""
        texts: list[str] = []
        if self.url:
            texts.append(self.url)
        texts.extend(self.headers.values())
        texts.extend(self.env.values())
        return set(_PLACEHOLDER_RE.findall(" ".join(texts)))


def _a365(server_name: str) -> str:
    """Build agent365 URL template for a given server."""
    return f"{_AGENT365_BASE}{server_name}"


SERVER_REGISTRY: dict[str, ServerEntry] = {
    # ── Servers with installation metadata (command/env) ─────────
    "kusto": ServerEntry(
        url="",
        description="run KQL queries, explore Kusto database schemas, manage Eventstreams and Activator triggers",
        package_server=True,
        command="uvx",
        command_args=["microsoft-fabric-rti-mcp"],
        env={"KUSTO_SERVICE_URI": "{service_uri}"},
    ),
    # ── Legacy aliases (description fallback for old local configs) ───
    "workiq": ServerEntry(
        url=_a365("mcp_M365Copilot"),
        description="query Microsoft 365 Copilot data, emails, docs, meetings",
        recommended=False,
    ),
    "enghub": ServerEntry(
        url="",
        description="docs, TSGs, ServiceTree search",
        recommended=False,
    ),
}


# ── Descriptions (runtime fallback when config has no explicit description) ──

AGENCY_DESCRIPTIONS: dict[str, str] = {
    name: entry.description for name, entry in SERVER_REGISTRY.items()
}

PACKAGE_SERVERS = {name for name, entry in SERVER_REGISTRY.items() if entry.package_server}

# Backward-compat aliases (old name → new name).
HTTPServerEntry = ServerEntry
HTTP_SERVER_REGISTRY = SERVER_REGISTRY


def get_default_description(name: str, *, is_agency: bool = False) -> str | None:
    """Return the preset description for a known MCP server, or None."""
    entry = SERVER_REGISTRY.get(name)
    if entry:
        return entry.description
    return None


# ── Runtime placeholder resolution ───────────────────────────────────────────


def extract_params(
    url: str | None,
    headers: dict[str, str],
    env: dict[str, str] | None = None,
) -> set[str]:
    """Extract ``{var}`` parameter names from URL, headers, and env values."""
    texts: list[str] = []
    if url:
        texts.append(url)
    texts.extend(headers.values())
    if env:
        texts.extend(env.values())
    return set(_PLACEHOLDER_RE.findall(" ".join(texts))) if texts else set()


def resolve_server_params(
    url: str | None,
    headers: dict[str, str],
    env: dict[str, str] | None = None,
    overrides: dict[str, str] | None = None,
) -> tuple[str | None, dict[str, str], dict[str, str], set[str]]:
    """Resolve ``{var}`` placeholders in a server's URL, headers, and env.

    *overrides* are typically LLM-provided arguments or stored values
    from a prior connection.

    Returns ``(resolved_url, resolved_headers, resolved_env, unresolved_params)``.
    """
    merged = dict(overrides) if overrides else {}

    unresolved: set[str] = set()

    def _sub(text: str) -> str:
        def _replace(m: re.Match[str]) -> str:
            key = m.group(1)
            val = merged.get(key)
            if val is None:
                unresolved.add(key)
                return m.group(0)  # leave unresolved
            return val

        return _PLACEHOLDER_RE.sub(_replace, text)

    resolved_url = _sub(url) if url else url
    resolved_headers = {k: _sub(v) for k, v in headers.items()}
    resolved_env = {k: _sub(v) for k, v in env.items()} if env else {}

    return resolved_url, resolved_headers, resolved_env, unresolved


def has_unresolved_params(
    url: str | None,
    headers: dict[str, str],
    env: dict[str, str] | None = None,
) -> bool:
    """True if server has ``{var}`` placeholders that cannot be resolved."""
    _, _, _, unresolved = resolve_server_params(url, headers, env=env)
    return bool(unresolved)


# Connectivity-test-only defaults. When `workpilot mcp setup` / `mcp test`
# runs against a server whose `{var}` placeholders the user hasn't filled
# in, these values substitute in so the test can proceed end-to-end.
# Runtime resolution (actual tool calls) still requires proper user values.
# Microsoft internal users: `microsoft` is the canonical ADO org.
TEST_PARAM_DEFAULTS: dict[str, dict[str, str]] = {
    "ado": {"organization": "microsoft"},
    "bluebird": {"organization": "microsoft"},
}
