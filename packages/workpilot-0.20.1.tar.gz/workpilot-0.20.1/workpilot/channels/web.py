"""
Web channel — HTTP/SSE/WebSocket channel via self-hosted web server.

Routes messages through the message bus using per-request asyncio.Queue
for bridging synchronous HTTP request-response with async bus messaging.
"""

from __future__ import annotations

import asyncio
import uuid
from collections.abc import AsyncIterable, Callable
from dataclasses import dataclass
from typing import Any

from loguru import logger

from workpilot.bus.events import (
    NOTIFICATION_SOURCES,
    EventType,
    StreamingChunk,
    frame_notification,
)
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel
from workpilot.config.schema import ChannelType


@dataclass(frozen=True)
class PushAttachmentNotification:
    """Atomic ``control + N WPAB streams`` push payload.

    Producer enqueues a single instance per notification so the server
    side can never see a half-enqueued bundle (control without all
    binaries, or vice versa). ``stream_factories`` is the list of
    callables returned by ``resolve_outbound_for_binary`` — invoked
    by the consumer once each so a fresh async iterator is created on
    use; the underlying file handle isn't opened until iteration starts.
    """

    control: dict[str, Any]
    stream_factories: list[Callable[[], AsyncIterable[bytes]]]


class WebChannel(BaseChannel):
    """HTTP/SSE/WebSocket channel via self-hosted web server."""

    def __init__(self, bus: MessageBus, allow_from: list[str] | None = None) -> None:
        super().__init__(bus, allow_from)
        # Per-request response routing: channel_id -> asyncio.Queue[str | None]
        self._response_queues: dict[str, asyncio.Queue[str | None]] = {}
        # Per-request streaming routing: channel_id -> asyncio.Queue[StreamingChunk | None]
        self._stream_queues: dict[str, asyncio.Queue[StreamingChunk | None]] = {}
        # Push notification queues for connected WebSocket clients
        # (scheduler / background jobs). Payloads come in three shapes:
        #   * ``str`` — pre-framed notification content; the WS server
        #     wraps it as ``{type: "push", content}``.
        #   * ``dict`` — a full frame already in
        #     ``{type, content, attachments, …}`` shape; forwarded
        #     verbatim. Used for push frames that don't carry binary
        #     attachments.
        #   * ``PushAttachmentNotification`` — atomic bundle of
        #     ``{control, stream_factories}`` for notify-with-image.
        #     The server expands it into ``send_json(control)`` then
        #     N ``send_bytes(...)`` calls (each factory invoked once;
        #     bytes are streamed off disk via aiofiles inside the
        #     factory). The bundle is one queue item so partial
        #     enqueue is impossible — see ``send`` below.
        self._push_queues: dict[
            str,
            asyncio.Queue[str | dict[str, Any] | PushAttachmentNotification | None],
        ] = {}
        # connection_id → canonical session id, populated by
        # ``register_push`` when the websocket endpoint registers a new
        # client. Used by ``broadcast_frame`` to scope delivery: a
        # mid-run control-plane frame for session A must not reach a
        # browser tab attached to session B (would leak msg_ids /
        # session ids and historically also user-content previews).
        self._push_session_map: dict[str, str] = {}
        self._running = False

    @property
    def name(self) -> str:
        return ChannelType.WEB

    @property
    def is_connected(self) -> bool:
        """True when at least one WebSocket client is connected."""
        return bool(self._push_queues)

    async def start(self) -> None:
        self._running = True
        logger.info("Web channel started")

    async def stop(self) -> None:
        self._running = False
        # Signal all waiting queues to terminate
        for rq in self._response_queues.values():
            try:
                rq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        for sq in self._stream_queues.values():
            try:
                sq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        for pq in self._push_queues.values():
            try:
                pq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        self._response_queues.clear()
        self._stream_queues.clear()
        self._push_queues.clear()
        logger.info("Web channel stopped")

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Route outbound messages to the correct per-request queue.

        If no request queue matches (e.g. scheduler notifications), broadcast
        to all connected push subscribers (WebSocket clients).

        For notify / delegate / scheduler outbounds we prepend the same
        inline framing prefix that ``AgentLoop._capture_for_persist``
        stamps on the session JSONL entry, AND we always route through
        the push-queue broadcast path — never the per-request response
        queue. Two reasons:

        * Out-of-band notifications aren't the answer to a pending
          request, so they should arrive as ``{type: "push"}`` frames;
          delivering them through the response queue would land them as
          ``{type: "response"}`` and the frontend's ``onNotification``
          handler would never fire.
        * The response queue has ``maxsize=1`` — a stray notification
          landing in there would either drop (QueueFull) or evict the
          real agent reply that the request is waiting for.
        """
        if kwargs.get("source") in NOTIFICATION_SOURCES:
            content = frame_notification(content, kwargs)
            # Resolve outbound attachment refs into (a) metadata-only dicts
            # for the JSON control frame and (b) WPAB binary frames for the
            # raw bytes — no base64 inflation on the WSS wire. Producers
            # populate ``OutboundMessage.attachments`` via the markdown-hoist
            # path; the framed content is the notification text the agent
            # emitted. No attachments → legacy string payload; with
            # attachments → enqueue control dict followed by N binary frames.
            from workpilot.security.attachments import resolve_outbound_for_binary

            metadata, stream_factories, drop_notes = resolve_outbound_for_binary(
                kwargs.get("attachments")
            )
            if drop_notes:
                # Mirror the text-note behaviour on the Cloud channel so the
                # user can tell why an image was skipped rather than getting
                # a silent drop.
                content = f"{content}\n\n{' '.join(drop_notes)}".strip()

            # Notifications bypass response queues entirely — always
            # broadcast to push subscribers. If no client is connected
            # we drop silently; session JSONL already has the entry
            # (see ``AgentLoop._capture_for_persist``) so the user
            # sees it on next page load.
            if self._push_queues:
                if metadata:
                    # Two-frame protocol: control dict first, then per-
                    # attachment streaming binary frames. We invoke the
                    # factory **once per subscriber** so each browser tab
                    # gets a fresh async iterator (file-handles are
                    # opened lazily inside the iterator, so no resource
                    # leak even if a subscriber disconnects mid-stream).
                    # The ``_push_loop`` server-side dispatches dict→
                    # send_json, async-iterable→drain-then-send_bytes
                    # (FastAPI/Starlette doesn't expose WSS frame
                    # fragmentation, so we coalesce). Receivers correlate
                    # control + binary by ``sha256`` in the WPAB header.
                    bundle = PushAttachmentNotification(
                        control={
                            "type": "push",
                            "content": content,
                            "attachments": metadata,
                        },
                        stream_factories=list(stream_factories),
                    )
                    # One queue item per notification: server expands it
                    # into ``send_json(control)`` + N ``send_bytes(...)``
                    # in a single ``_push_loop`` step. No partial-enqueue
                    # race possible — the bundle is either fully accepted
                    # or fully rejected.
                    for pid, pq in list(self._push_queues.items()):
                        try:
                            pq.put_nowait(bundle)
                        except asyncio.QueueFull:
                            logger.warning(f"Push queue full for {pid}")
                else:
                    # Plain text notification — keep legacy string payload
                    # so the WS server's text-frame wrap still applies.
                    for pid, pq in list(self._push_queues.items()):
                        try:
                            pq.put_nowait(content)
                        except asyncio.QueueFull:
                            logger.warning(f"Push queue full for {pid}")
            else:
                logger.debug(
                    f"Notification ({kwargs.get('source')}) had no WS push subscribers — "
                    f"relying on session JSONL for delivery on reconnect"
                )
            return

        q = self._response_queues.get(channel_id)
        if q is not None:
            try:
                q.put_nowait(content)
            except asyncio.QueueFull:
                logger.warning(f"Response queue full for {channel_id}")
        elif self._push_queues:
            # Broadcast non-notification responses (e.g. approval prompts
            # that arrive after the caller's request queue unregistered)
            # to WS clients.
            for pid, pq in list(self._push_queues.items()):
                try:
                    pq.put_nowait(content)
                except asyncio.QueueFull:
                    logger.warning(f"Push queue full for {pid}")
        else:
            logger.warning(
                f"Response dropped ({self.name}): no queue for channel_id={channel_id} (request may have timed out)"
            )

    async def send_streaming(self, channel_id: str, chunk: StreamingChunk) -> None:
        """Route streaming chunks to the correct per-request queue."""
        q = self._stream_queues.get(channel_id)
        if q is not None:
            try:
                q.put_nowait(chunk)
            except asyncio.QueueFull:
                logger.warning(f"Stream queue full for {channel_id}")

    def register_request(self, channel_id: str) -> asyncio.Queue[str | None]:
        """Register a per-request response queue. Returns the queue to await."""
        q: asyncio.Queue[str | None] = asyncio.Queue(maxsize=1)
        self._response_queues[channel_id] = q
        return q

    def unregister_request(self, channel_id: str) -> None:
        """Clean up queues after request completes."""
        self._response_queues.pop(channel_id, None)
        self._stream_queues.pop(channel_id, None)

    def register_stream(self, channel_id: str) -> asyncio.Queue[StreamingChunk | None]:
        """Register a streaming queue for SSE/WS. Returns queue to iterate."""
        q: asyncio.Queue[StreamingChunk | None] = asyncio.Queue(maxsize=100)
        self._stream_queues[channel_id] = q
        return q

    def register_push(
        self, connection_id: str, *, canonical_sid: str | None = None
    ) -> asyncio.Queue[str | dict[str, Any] | PushAttachmentNotification | None]:
        """Register a push notification queue for a persistent connection (WebSocket).

        Push queues receive unsolicited messages (scheduler notifications,
        background job results) that don't match any per-request queue.
        Payloads are strings (pre-framed notification text — WS server wraps
        them), full-frame dicts (already in ``{type,content,…}`` shape),
        or ``PushAttachmentNotification`` bundles (atomic control + N
        WPAB streams for notify-with-image).

        ``canonical_sid`` lets ``broadcast_frame`` scope per-session
        delivery so cross-session control-plane events (e.g. mid-run
        chip state) don't leak to unrelated browser tabs. Optional —
        omitting it falls through to broadcast-to-all.
        """
        was_empty = not self._push_queues
        q: asyncio.Queue[str | dict[str, Any] | PushAttachmentNotification | None] = asyncio.Queue(
            maxsize=50
        )
        self._push_queues[connection_id] = q
        if canonical_sid:
            self._push_session_map[connection_id] = canonical_sid
        # First WebSocket client → channel is now connected
        if was_empty:
            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
        return q

    def unregister_push(self, connection_id: str) -> None:
        """Remove a push notification queue when a connection closes."""
        self._push_queues.pop(connection_id, None)
        self._push_session_map.pop(connection_id, None)

    def broadcast_push(self, payload: str, *, critical: bool = False) -> None:
        """Broadcast a push message to all connected WebSocket clients.

        When *critical* is True (e.g. E-stop), a full queue will have its
        oldest message dropped so the latest state change is always delivered.
        """
        for pid, pq in list(self._push_queues.items()):
            try:
                pq.put_nowait(payload)
            except asyncio.QueueFull:
                if critical:
                    try:
                        pq.get_nowait()  # drop oldest
                    except asyncio.QueueEmpty:
                        continue
                    try:
                        pq.put_nowait(payload)
                    except asyncio.QueueFull:
                        logger.warning(f"Push queue still full for {pid}")
                else:
                    logger.warning(f"Push queue full for {pid}, message dropped")

    def broadcast_frame(self, frame: dict[str, Any], *, session_id: str | None = None) -> None:
        """Broadcast a typed frame dict to connected WebSocket clients.

        Used for control-plane events (mid-run lifecycle, etc.) where the
        ``broadcast_push`` string-wrapping ``{type:"push", content}`` would
        require the client to re-parse and re-dispatch on an inner type.
        Dict items pass through ``_push_loop`` verbatim via
        ``send_json``, so the frame's ``type`` is the dispatch key.

        ``session_id`` (when provided) scopes delivery to clients
        registered under the matching canonical session id. Connections
        without a registered sid are skipped — never broadcast to all
        when scoping is requested. Without ``session_id`` the frame
        goes to every connected client (current behaviour for events
        that genuinely apply globally).

        Backpressure: the push queue holds a mix of payloads — control-
        plane frames (this method), regular pushes (``broadcast_push``),
        and atomic ``PushAttachmentNotification`` bundles. Evicting the
        oldest item to make room for a control-plane frame would risk
        dropping a user-visible notification or breaking a notify-with-
        image bundle, so we drop the new frame on queue-full instead and
        log at WARNING.
        Trade-off: a dropped control-plane frame can leave the chip
        stuck mid-lifecycle (e.g. "queued" forever) — but a queue full
        of 50 items already implies severe backpressure, so a wrong-
        looking chip is a lesser evil than swallowing a notification
        the user is waiting on.
        """
        for pid, pq in list(self._push_queues.items()):
            if session_id is not None:
                # Skip connections that aren't on the target session.
                # Connections registered without a sid (legacy callers)
                # are also skipped under scoped delivery — preventing a
                # silent broadcast-to-all on a frame that's meant to be
                # session-private.
                if self._push_session_map.get(pid) != session_id:
                    continue
            try:
                pq.put_nowait(frame)
            except asyncio.QueueFull:
                logger.warning(
                    "Push queue full for {}, control-plane frame dropped: {}",
                    pid,
                    frame.get("type"),
                )

    @staticmethod
    def make_channel_id(prefix: str = "web-req") -> str:
        """Generate a unique channel_id for a request."""
        return f"{prefix}-{uuid.uuid4().hex[:12]}"

    async def submit_and_wait(
        self,
        *,
        channel_id: str,
        sender_id: str,
        content: str,
        timeout: float = 300,
        attachments: list[dict[str, Any]] | None = None,
    ) -> str:
        """Submit a message through the bus and wait for the response.

        Creates a response queue, publishes via _handle_message, and awaits
        the agent's response with a timeout.

        Raises ``ValueError`` when ``_handle_message`` filtered the
        input (allowlist or empty-content drop) — without this short-
        circuit, the caller would block on ``response_queue.get()``
        until ``timeout`` elapses for a message that never reached the
        agent. REST API handlers translate this to HTTP 400.
        """
        response_queue = self.register_request(channel_id)
        try:
            published = await self._handle_message(
                channel_id=channel_id,
                sender_id=sender_id,
                sender_name=sender_id,
                content=content,
                attachments=attachments,
            )
            if not published:
                raise ValueError("Empty or blocked input — message was not published to the bus")
            result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
            if result is None:
                raise TimeoutError("Channel shutting down")
            return result
        finally:
            self.unregister_request(channel_id)
