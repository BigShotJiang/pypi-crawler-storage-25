"""
CLI channel — interactive REPL for local terminal use.
"""

from __future__ import annotations

import asyncio
import json
import sys
from collections.abc import Callable
from typing import Any

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from rich.console import Console
from rich.markup import escape as _rich_escape

from workpilot.bus.events import EventType, OutboundMessage, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel
from workpilot.config.schema import ChannelType

console = Console()

# ── Shared thinking spinner (Rich Status — cross-platform) ───────────────────

# Module-level Status instance shared by CLIChannel and ws_chat_repl.
# Rich Status handles cursor hide/show, line clearing, and terminal compat
# internally — no manual ANSI needed.
_status: Any = None


def start_thinking() -> None:
    """Show a 'Thinking…' spinner. Call stop_thinking() when first output arrives."""
    global _status
    stop_thinking()  # idempotent — no double-start
    _status = console.status("", spinner="dots")
    _status.start()


def stop_thinking() -> None:
    """Stop the thinking spinner (idempotent)."""
    global _status
    if _status is not None:
        _status.stop()
        _status = None


# ── Shared tool chunk rendering (used by CLIChannel + ws_chat_repl) ──────────

# Budget for a single tool line.
_TOOL_LINE_MAX = 80

# Stash tool_start data so tool_end can render the combined single line.
# tool_id → {"name": str, "hint": str}
_pending_tools: dict[str, dict[str, str]] = {}


def _truncate(text: str, budget: int) -> str:
    """Truncate *text* to *budget* chars, replacing the tail with '…'."""
    if len(text) <= budget:
        return text
    return text[: max(budget - 1, 0)] + "…"


def _first_arg_hint(args: dict) -> str:
    """Return a one-line preview of the most informative arg value."""
    for v in args.values():
        if isinstance(v, str) and v.strip():
            return v.strip().replace("\n", " ")
    return ""


def render_tool_start(content: str) -> None:
    """Show the running tool in the spinner label (immediate feedback)."""
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return
    if not isinstance(data, dict):
        return

    raw_args = data.get("args", {})
    args = raw_args if isinstance(raw_args, dict) else {}
    tool_id = str(data.get("id", ""))
    name = str(data.get("name", "?"))
    hint = _first_arg_hint(args)
    _pending_tools[tool_id] = {"name": name, "hint": hint}

    args_part = f"({_rich_escape(_truncate(hint, 30))})" if hint else ""
    if _status is not None:
        _status.update(f"[dim]{_rich_escape(name)}{args_part}[/dim]")


def render_tool_end(content: str) -> None:
    """Print completed tool line above spinner, reset spinner text."""
    try:
        data = json.loads(content)
        tool_id = data.get("id", "")
        name = data.get("name", "?")
        duration = data.get("durationMs", 0)
        is_error = data.get("error", False)
        result_raw = data.get("result", "")
        dur_str = f"~{duration / 1000:.1f}s" if duration else ""

        stashed = _pending_tools.pop(tool_id, None)
        hint = stashed["hint"] if stashed else ""

        args_part = f"({_rich_escape(_truncate(hint, 20))})" if hint else ""
        tail = f" [bright_black]{dur_str}[/bright_black]" if dur_str else ""
        head_len = len(f"  {name}{args_part}")
        icon_len = 3  # " ✓ "
        tail_len = len(f" {dur_str}") if dur_str else 0

        snippet = ""
        raw = result_raw.replace("\n", " ").strip() if result_raw else ""
        if raw:
            budget = _TOOL_LINE_MAX - head_len - icon_len - tail_len
            if budget > 5:
                snippet = _rich_escape(_truncate(raw, budget))

        esc_name = _rich_escape(name)
        # Completed line prints above the spinner (Rich Live handles this)
        if is_error:
            console.print(
                f"  [red]✗[/red] [dim]{esc_name}{args_part}[/dim] [dim]{snippet}[/dim]{tail}",
                highlight=False,
            )
        else:
            console.print(
                f"  [green]✓[/green] [dim]{esc_name}{args_part}[/dim] [dim]{snippet}[/dim]{tail}",
                highlight=False,
            )

        # Reset spinner text (next tool_start will set it again)
        if _status is not None:
            _status.update("")
    except Exception:
        pass


def render_commentary(content: str) -> None:
    """Render commentary chunk as a dim italic line."""
    text = (content or "").strip()
    if text:
        console.print(f"  [dim italic]{_rich_escape(text)}[/dim italic]", highlight=False)


_SLASH_COMMANDS = [
    ("/new", "Clear session, start fresh"),
    ("/help", "Show all available commands"),
    ("/status", "Show agent status and session info"),
    ("/memory", "Show MEMORY.md content"),
    ("/tools", "List available tools"),
    ("/skills", "List loaded skills"),
    ("/history", "Show last 10 messages in session"),
    ("/history 20", "Show last 20 messages in session"),
    ("/model", "Show current model"),
    ("/bridge", "Show bridge mode status"),
    ("/bridge claude", "Forward all messages to Claude Code CLI"),
    ("/bridge copilot", "Forward all messages to GitHub Copilot CLI"),
    ("/bridge off", "Exit bridge mode"),
    ("/cancel", "Interrupt the current agent operation"),
    ("/next ", "Defer message to run after current task (skips mid-run merge)"),
    ("/estop", "Emergency stop all tools"),
    ("/exit", "Exit the REPL"),
]


class _SlashCompleter(Completer):
    def get_completions(self, document: Document, complete_event: Any):  # type: ignore[override]
        text = document.text_before_cursor
        if not text.startswith("/"):
            return
        for cmd, desc in _SLASH_COMMANDS:
            if cmd.startswith(text):
                yield Completion(cmd[len(text) :], display=cmd, display_meta=desc)


class CLIChannel(BaseChannel):
    """Terminal-based interactive channel."""

    def __init__(
        self,
        bus: MessageBus,
        prompt: str = "you> ",
        interrupt_fn: Callable[[str], bool] | None = None,
        agent_name: str = "assistant",
        bridge_target_fn: Callable[[], str | None] | None = None,
    ) -> None:
        super().__init__(bus)
        self._prompt = prompt
        self._running = False
        self._in_repl = False
        self._streaming = False
        self._interrupt_fn = interrupt_fn
        self._current_session_id: str | None = None
        self._agent_name = agent_name
        self._bridge_target_fn = bridge_target_fn
        self._mid_run_inbox_depth: dict[str, int] = {}
        self._mid_run_subscribed = False
        # Set when the agent's reply is fully delivered (OutboundMessage or
        # streaming done=True), so the REPL waits before re-showing the prompt.
        self._reply_done: asyncio.Event = asyncio.Event()

    def _reply_name(self) -> str:
        """Name to show before a reply — bridge target when bridged, agent name otherwise."""
        if self._bridge_target_fn is not None:
            target = self._bridge_target_fn()
            if target:
                return target
        return self._agent_name

    @property
    def name(self) -> str:
        return ChannelType.CLI

    @property
    def is_connected(self) -> bool:
        """True only when the interactive REPL is running."""
        return self._in_repl

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Send a non-streamed response (used for slash-command results, etc.)."""
        stop_thinking()
        try:
            import html as _html

            from prompt_toolkit.formatted_text import HTML
            from prompt_toolkit.shortcuts import print_formatted_text

            safe = _html.escape(content)
            print_formatted_text(HTML(f"\n<b>{safe}</b>\n"))
        except (ImportError, ValueError):
            sys.stdout.write(f"\n{content}\n\n")
            sys.stdout.flush()
        self._reply_done.set()

    async def _handle_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Handle both full messages and streaming chunks from the bus."""
        if isinstance(msg, StreamingChunk) and msg.channel == self.name:
            ct = msg.chunk_type or "token"

            if ct == "tool_start":
                render_tool_start(msg.content)
                return
            if ct == "tool_end":
                render_tool_end(msg.content)
                return
            if ct in ("tool_progress", "status"):
                return  # suppress metadata noise in CLI
            if ct == "commentary":
                render_commentary(msg.content)
                return

            # token streaming
            if msg.done:
                if self._streaming:
                    console.print("\n")
                    self._streaming = False
                stop_thinking()
                self._reply_done.set()
            else:
                if not self._streaming:
                    stop_thinking()
                    console.print()  # blank line before reply
                    self._streaming = True
                console.print(f"[bold]{_rich_escape(msg.content)}[/bold]", end="", highlight=False)

    # ── Mid-run UX (design §5.8) ─────────────────────────────────────────

    def _subscribe_mid_run_events(self) -> None:
        """Subscribe to all MID_RUN_* bus events and render an inline
        notice under the prompt. Called once on REPL start.

        Idempotent — guarded by ``_mid_run_subscribed`` so multiple REPL
        starts in the same process don't double-subscribe.
        """
        if self._mid_run_subscribed:
            return
        self._mid_run_subscribed = True
        self._bus.events.on(EventType.MID_RUN_QUEUED, self._on_mid_run_queued)
        self._bus.events.on(EventType.MID_RUN_INJECTED, self._on_mid_run_injected)
        self._bus.events.on(EventType.MID_RUN_DEFERRED, self._on_mid_run_deferred)
        self._bus.events.on(EventType.MID_RUN_DROPPED, self._on_mid_run_dropped)
        self._bus.events.on(EventType.MID_RUN_PROMOTED, self._on_mid_run_promoted)

    def _print_mid_run_line(self, line: str) -> None:
        """Render an inline mid-run status line. Uses console (rich) so
        that the prompt_toolkit bottom_toolbar redraw doesn't clobber it.
        """
        try:
            console.print(f"[dim]{line}[/dim]")
        except Exception:  # noqa: BLE001
            sys.stdout.write(f"{line}\n")
            sys.stdout.flush()

    async def _on_mid_run_queued(self, event_type: EventType, payload: dict[str, Any]) -> None:
        sid = payload.get("session_id", "")
        depth = int(payload.get("depth", 0))
        self._mid_run_inbox_depth[sid] = depth
        # ``deferred=True`` for ``/next X`` messages — they sit in the
        # inbox but will NOT be merged into the running task; they run
        # as a fresh turn after the current one ends. Distinguish from
        # the regular mid-run "queued" message so the user sees the
        # correct expectation up front.
        if payload.get("deferred"):
            self._print_mid_run_line(f"→ next turn · will run after current task (depth={depth})")
        else:
            self._print_mid_run_line(
                f"→ queued · will merge at next safe checkpoint (depth={depth})"
            )

    async def _on_mid_run_injected(self, event_type: EventType, payload: dict[str, Any]) -> None:
        sid = payload.get("session_id", "")
        depth_after = int(payload.get("inbox_depth_after", 0))
        self._mid_run_inbox_depth[sid] = depth_after
        count = int(payload.get("count", 0))
        self._print_mid_run_line(
            f"✓ merged {count} into running task" if count > 1 else "✓ merged into running task"
        )

    async def _on_mid_run_deferred(self, event_type: EventType, payload: dict[str, Any]) -> None:
        sid = payload.get("session_id", "")
        # Residuals re-pushed to bus → no longer in our inbox accounting.
        self._mid_run_inbox_depth[sid] = 0
        count = int(payload.get("count", 0))
        self._print_mid_run_line(
            f"⤵ deferred {count} to next turn" if count > 1 else "⤵ deferred to next turn"
        )

    async def _on_mid_run_dropped(self, event_type: EventType, payload: dict[str, Any]) -> None:
        sid = payload.get("session_id", "")
        reason = payload.get("reason", "unknown")
        # Most DROPPED reasons (interrupted, bus_full at re-push)
        # empty the inbox → depth=0. ``inbox_full`` only drops the
        # incoming message; the inbox stays at cap, so the server
        # carries the explicit ``depth`` field. Apply it
        # authoritatively when present.
        if "depth" in payload:
            self._mid_run_inbox_depth[sid] = int(payload.get("depth", 0))
        else:
            self._mid_run_inbox_depth[sid] = 0
        count = int(payload.get("count", 0))
        if count <= 1:
            self._print_mid_run_line(f"✗ canceled before merge ({reason})")
        else:
            self._print_mid_run_line(f"✗ canceled {count} before merge ({reason})")

    async def _on_mid_run_promoted(self, event_type: EventType, payload: dict[str, Any]) -> None:
        # Once the formerly-deferred message becomes the primary turn,
        # "deferred" + "running" is contradictory phrasing. Just say
        # the message is now running — the prior "deferred" line
        # already told the user how it got here.
        self._print_mid_run_line("▶ now running")

    def _bottom_toolbar(self) -> str:
        """prompt_toolkit bottom_toolbar callback — shows aggregate
        mid-run state across all active sessions.

        Wording note: "queued messages" reflects mid-run inbox state,
        while ``/next`` explicitly defers to a future turn.
        """
        depth = sum(self._mid_run_inbox_depth.values())
        if depth <= 0:
            return ""
        noun = "queued message" if depth == 1 else "queued messages"
        return f"  [Agent running · {depth} {noun}]  "

    async def run_repl(self) -> None:
        """Run the interactive read-eval-print loop."""
        self._running = True
        self._in_repl = True
        try:
            await self._run_repl_inner()
        finally:
            self._in_repl = False

    async def _run_repl_inner(self) -> None:
        """Inner REPL loop — separated so run_repl can use try/finally."""
        self._bus.on_outbound(self._handle_outbound)
        self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
        # Mid-run UX (§5.8): subscribe to MID_RUN_* events so each
        # transition produces an inline status line under the prompt.
        self._subscribe_mid_run_events()
        # Gradient "WorkPilot" (same colors as serve.py banner)
        from rich.text import Text

        _LETTERS = [
            ("W", "#a1d2de"), ("o", "#8dcce0"), ("r", "#79c5d8"), ("k", "#79C0FF"),
            ("P", "#79C0FF"), ("i", "#6DC8B2"), ("l", "#62CE82"), ("o", "#56D364"),
            ("t", "#56D364"),
        ]  # fmt: skip
        _wp = Text()
        for ch, color in _LETTERS:
            _wp.append(ch, style=f"bold {color}")
        _wp.append(" Chat", style="bold")
        _wp.append(" — type /exit to quit, /new to reset\n")
        console.print(_wp)

        # Try prompt_toolkit for rich input (autocomplete, history).
        # Fall back to plain input() on incompatible terminals (Git Bash, Cygwin, etc.).
        use_prompt_toolkit = True
        session: Any = None
        try:
            import os as _os

            from prompt_toolkit import PromptSession
            from prompt_toolkit.history import FileHistory
            from prompt_toolkit.key_binding import KeyBindings
            from prompt_toolkit.patch_stdout import patch_stdout as _patch_stdout

            from workpilot.utils.helpers import get_data_dir

            _kb = KeyBindings()

            @_kb.add("escape", "enter")  # Alt+Enter → newline
            def _newline(event: Any) -> None:
                event.current_buffer.insert_text("\n")

            _history_path = get_data_dir() / "cli_history"
            if _os.name == "posix":
                try:
                    if not _history_path.exists():
                        fd = _os.open(_history_path, _os.O_CREAT | _os.O_WRONLY, 0o600)
                        _os.close(fd)
                    else:
                        _os.chmod(_history_path, 0o600)
                except OSError:
                    pass

            import html as _html_mod

            from prompt_toolkit.formatted_text import HTML
            from prompt_toolkit.styles import Style as PTStyle

            _safe_prompt = _html_mod.escape(self._prompt.rstrip())
            _prompt_html = HTML(f"<style fg='#5fafaf'>{_safe_prompt}</style> ")
            _input_style = PTStyle.from_dict({"": "bold #5fafaf"})

            session = PromptSession(
                _prompt_html,
                style=_input_style,
                completer=_SlashCompleter(),
                complete_while_typing=True,
                history=FileHistory(str(_history_path)),
                key_bindings=_kb,
                multiline=False,
                bottom_toolbar=self._bottom_toolbar,
            )
            # Probe compatibility with a dry-run (catches xterm-256color on Windows)
            import prompt_toolkit.output

            prompt_toolkit.output.create_output()
        except Exception:
            use_prompt_toolkit = False
            console.print("[dim](basic input mode — autocomplete unavailable)[/dim]\n")

        while self._running:
            try:
                if use_prompt_toolkit and session is not None:
                    try:
                        with _patch_stdout():
                            text = await asyncio.get_event_loop().run_in_executor(
                                None, lambda: session.prompt()
                            )
                    except Exception:
                        # Runtime failure (e.g. terminal resized to incompatible type)
                        use_prompt_toolkit = False
                        console.print("[dim](switching to basic input mode)[/dim]\n")
                        continue

                else:
                    text = await asyncio.get_event_loop().run_in_executor(
                        None, lambda: input(self._prompt)
                    )
            except EOFError:
                break
            except KeyboardInterrupt:
                # Use interrupt_fn return value as source of truth:
                # True = agent was busy → interrupt, stay in REPL
                # False = agent was idle → exit REPL
                if self._interrupt_fn:
                    sid = self._current_session_id or "cli_local"
                    if self._interrupt_fn(sid):
                        console.print("[dim]Interrupting...[/dim]")
                        continue
                break

            text = text.strip()
            if not text:
                continue
            if text in ("/exit", "/quit"):
                break

            # /cancel fast-path: bypass the inbound queue
            if text.lower() == "/cancel":
                if self._interrupt_fn:
                    sid = self._current_session_id or "cli_local"
                    if self._interrupt_fn(sid):
                        console.print("[dim]Interrupting...[/dim]")
                    else:
                        console.print("[dim]Nothing to interrupt.[/dim]")
                continue

            self._current_session_id = "cli_local"

            self._reply_done.clear()
            published = await self._handle_message(
                channel_id="terminal",
                sender_id="local",
                sender_name="User",
                content=text,
            )

            # Show thinking spinner until the first output arrives.
            if published:
                start_thinking()
                try:
                    await asyncio.wait_for(self._reply_done.wait(), timeout=600)
                except TimeoutError:
                    pass
                except KeyboardInterrupt:
                    # Ctrl+C during agent run → interrupt agent, stay in REPL
                    if self._interrupt_fn:
                        sid = self._current_session_id or "cli_local"
                        self._interrupt_fn(sid)
                    console.print("[dim]Interrupted.[/dim]")
                finally:
                    stop_thinking()
