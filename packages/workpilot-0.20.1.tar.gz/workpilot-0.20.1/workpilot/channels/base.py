"""
Base channel — abstract interface with allowlist-based access control.

Every channel enforces an allow-list before publishing to the bus.
Empty allow_from = allow all (enterprise deployments should always set this).
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import Any

from loguru import logger

from workpilot.bus.events import InboundMessage
from workpilot.bus.queue import MessageBus


class BaseChannel(ABC):
    """Abstract base for all communication channels."""

    def __init__(self, bus: MessageBus, allow_from: list[str] | None = None) -> None:
        self._bus = bus
        self._allow_from = set(allow_from) if allow_from else set()

    @property
    @abstractmethod
    def name(self) -> str:
        """Channel identifier."""

    @abstractmethod
    async def start(self) -> None:
        """Connect and begin receiving messages."""

    @abstractmethod
    async def stop(self) -> None:
        """Disconnect and clean up."""

    @abstractmethod
    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Send a message to a specific channel destination."""

    @property
    def is_connected(self) -> bool:
        """True when the channel has at least one active client.

        Subclasses override to reflect their real connection state.
        Default returns True for backward compatibility.
        """
        return True

    def get_push_delivery(self, request_id: str) -> dict[str, bool] | None:
        """Return push delivery results for *request_id*, or ``None``.

        Only CloudChannel returns meaningful data — other channels return
        ``None`` (no push delivery tracking).
        """
        return None

    def wait_push_delivery(self, request_id: str) -> Any:
        """Return an awaitable that resolves when a push_ack arrives for *request_id*.

        Returns ``None`` for channels that don't support push delivery
        tracking.  CloudChannel returns an ``asyncio.Event``.
        """
        return None

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:  # noqa: B027
        """Send a typing indicator to the channel. No-op by default.

        Subclasses (Teams, Cloud) override to show a typing indicator
        while the agent is processing a request.
        """

    def is_allowed(self, sender_id: str) -> bool:
        """Check if the sender is in the allow list."""
        if not self._allow_from:
            return True  # Empty list = allow all
        return sender_id in self._allow_from

    async def _handle_message(
        self,
        *,
        channel_id: str,
        sender_id: str,
        sender_name: str,
        content: str,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        attachments: list[dict[str, Any]] | None = None,
    ) -> bool:
        """Shared message handler — checks allowlist then publishes to bus.

        ``attachments`` carries refs as dicts of
        ``{sha256, path, content_type, size, kind, name?}`` (see
        ``AttachmentRef.to_dict`` in ``workpilot/security/attachments.py``;
        ``kind`` is ``"image" | "text"``). ``None`` = plain-text message.

        Returns ``True`` if the message was published to the bus,
        ``False`` if it was filtered (allowlist or empty-content drop).
        Synchronous request/response callers (e.g.
        ``WebChannel.submit_and_wait``) MUST short-circuit on a False
        return — otherwise they'd block on the response queue until
        timeout for a message that never reached the agent.
        Fire-and-forget callers can ignore the return.
        """
        if not self.is_allowed(sender_id):
            logger.warning(f"Message blocked from {sender_id} on {self.name} (not in allow_from)")
            return False

        # D13: filter pure-empty inbound at the channel boundary. An empty
        # message has no semantic value to inject and would just become a
        # blank user item if it reached the engine. An attachment-only
        # message (image with no caption) is steerable and DOES pass.
        # See design/features/mid-run-injection.md §5.3, T29, T30.
        has_text = bool((content or "").strip())
        has_atts = bool(attachments)
        if not has_text and not has_atts:
            logger.debug("Channel {} dropped empty inbound from {}", self.name, sender_id)
            return False

        meta = dict(metadata or {})
        # E15: stamp a stable msg_id at message construction time so the
        # frontend bubble carries the same id that flows through every
        # MID_RUN_* event payload. Channels that don't pre-stamp get a
        # UUID v4 here; channels that do (e.g. the Web channel may
        # receive a client-side id over the wire) keep their value.
        meta.setdefault("msg_id", uuid.uuid4().hex[:16])
        msg = InboundMessage(
            channel=self.name,
            channel_id=channel_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_format=meta.get("content_format", "text"),
            thread_id=thread_id,
            metadata=meta,
            attachments=attachments or None,
        )
        await self._bus.publish_inbound(msg)
        return True
