"""
WebServer — FastAPI-based HTTP web server for WorkPilot.

Provides:
- /  /chat  /app  /app/* — React SPA (unified portal)
- /health — basic health check (backward compat)
- /v1/chat/completions — OpenAI-compatible chat completions (backward compat)
- /api/chat — send prompt, receive response (via bus)
- /api/chat/stream — SSE streaming response
- /api/ws — WebSocket bidirectional chat
- /api/sessions — session management
- /api/tools — tool discovery
- /api/health — detailed health check
- /api/status — comprehensive runtime status (polled by dashboard)
- /api/estop — E-stop trigger
- /api/reset — E-stop reset

FastAPI and uvicorn are imported at use time so the rest of
WorkPilot can start without them installed.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from collections.abc import Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger
from pydantic import BaseModel, Field

from workpilot import __version__
from workpilot.bus.events import MSG_ID_RE
from workpilot.config.schema import ChannelType, WebServerConfig
from workpilot.security.approval_format import match_approval_prompt
from workpilot.security.attachments import portable_attachments
from workpilot.utils.helpers import webchat_url_from_connect
from workpilot.web.auth import AuthMiddleware
from workpilot.web.estop_middleware import EStopMiddleware
from workpilot.web.middleware import RateLimiter, RequestLogger

if TYPE_CHECKING:
    from workpilot.channels.web import WebChannel
    from workpilot.runtime import Runtime

# FastAPI types needed at module level for annotation resolution
# (from __future__ import annotations defers evaluation, so get_type_hints()
# needs these in module globals).
try:
    from fastapi import Request, UploadFile, WebSocket
except ImportError:
    pass

try:
    from starlette.responses import Response as _StarletteResponse
    from starlette.staticfiles import StaticFiles as _StaticFilesBase
    from starlette.types import Scope as _StarletteScope

    class _HashedStaticFiles(_StaticFilesBase):
        """StaticFiles subclass that marks content-hashed assets as immutable.

        Vite emits `app-[hash].js/css` and `chunks/[name]-[hash].js` — content-hashed,
        so a new build produces new URLs and the cache can be considered immutable.
        Non-hashed public files (`logo.svg`, `auth-callback.html`,
        `msal-redirect-bridge.min.js`, `assets/*`) keep StaticFiles defaults
        (ETag + 304).

        The guard covers 200 (full response), 206 (Range request), and 304
        (conditional revalidation) so the Cache-Control directive survives every
        path a cache might take. Error responses (404/405/416) are left alone.
        """

        async def get_response(self, path: str, scope: _StarletteScope) -> _StarletteResponse:
            resp = await super().get_response(path, scope)
            # StaticFiles.get_path returns OS-normalized paths (backslashes on
            # Windows); normalize to forward slashes before prefix matching.
            _p = path.replace("\\", "/")
            if resp.status_code in (200, 206, 304) and (
                _p.startswith("app-") or _p.startswith("chunks/")
            ):
                resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"
            return resp
except ImportError:
    _HashedStaticFiles = None  # type: ignore[misc,assignment]


# Mid-run client msg_id gate — single source of truth lives in
# ``workpilot.bus.events.MSG_ID_RE`` so all ingress paths
# (here + workpilot/channels/cloud) enforce the same shape and can't
# drift. Aliased so the inline use-site stays readable.
_MSG_ID_RE = MSG_ID_RE


# ── Request / Response schemas (backward-compat OpenAI format) ─────────────


class ChatMessage(BaseModel):
    """Single message in a chat completion request."""

    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request."""

    messages: list[ChatMessage]
    model: str | None = None
    stream: bool = False
    temperature: float | None = None
    max_tokens: int | None = None


class ChatChoiceMessage(BaseModel):
    """Message inside a chat completion choice."""

    role: str = "assistant"
    content: str


class ChatChoice(BaseModel):
    """Single choice in a chat completion response."""

    index: int = 0
    message: ChatChoiceMessage
    finish_reason: str = "stop"


class UsageInfo(BaseModel):
    """Token usage statistics."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    """OpenAI-compatible chat completion response."""

    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:12]}")
    object: str = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str = "workpilot"
    choices: list[ChatChoice]
    usage: UsageInfo = Field(default_factory=UsageInfo)


class HealthResponse(BaseModel):
    """Basic health check response."""

    status: str = "ok"
    version: str = __version__


class ErrorResponse(BaseModel):
    """Standard error response body."""

    error: str
    message: str = ""


# ── New /api/* schemas ─────────────────────────────────────────────────────


class ChatRequest(BaseModel):
    """Request for /api/chat and /api/chat/stream."""

    prompt: str
    session_id: str | None = None
    # Attachments for this turn (images or text/code files). Each entry
    # carries at minimum a ``sha256`` (hex) pointing at a previously-
    # uploaded file via POST /api/attachments. Optional ``content_type``
    # is accepted but re-resolved server-side from the on-disk ref.
    attachments: list[dict[str, Any]] | None = None


class AttachmentResponse(BaseModel):
    """Response from POST /api/attachments."""

    sha256: str
    content_type: str
    size: int
    kind: str  # "image" | "text"
    name: str | None = None


class ChatResponse(BaseModel):
    """Response from /api/chat."""

    response: str
    session_id: str


class ToolInfo(BaseModel):
    """Tool metadata for /api/tools."""

    name: str
    description: str
    risk_score: int | None = None
    tier: str = "core"
    active: bool = True
    type: str = "builtin"  # builtin | mcp_tool | mcp_server
    state: str | None = None  # MCP only: idle, connected, etc.
    tool_count: int | None = None  # MCP only


class HealthDetailResponse(BaseModel):
    """Detailed health for /api/health."""

    status: str
    version: str = __version__
    estop: dict[str, Any] = Field(default_factory=dict)
    bus: dict[str, Any] = Field(default_factory=dict)


class EStopRequest(BaseModel):
    """Request for /api/estop."""

    reason: str


class EStopResetRequest(BaseModel):
    """Request for /api/reset."""

    actor: str = "api"


# ── Web Server ─────────────────────────────────────────────────────────────


class WebServer:
    """
    FastAPI-based HTTP web server for WorkPilot.

    Wraps the Runtime to expose an HTTP API with:
    - Legacy endpoints: /health, /v1/chat/completions
    - New API endpoints: /api/chat, /api/chat/stream, /api/ws,
      /api/sessions, /api/tools, /api/health, /api/estop, /api/reset
    """

    def __init__(
        self,
        config: WebServerConfig,
        runtime: Runtime,
        on_started: Callable[[int], None] | None = None,
    ) -> None:
        self._config = config
        self._runtime = runtime
        self._rate_limiter = RateLimiter(config.rate_limit_per_minute)
        self._web_channel: WebChannel | None = None
        self._server: Any = None  # uvicorn.Server instance
        self._on_started = on_started

        # Generate a temporary in-memory API key when no API key is configured
        # AND either: (a) Entra ID is not configured, or (b) cloud channel
        # fell back to the shared app (primary app blocked → MSAL popup won't
        # work either).  Passed to browser via URL fragment (#key=...).
        self.temp_key: str | None = None
        _entra_configured = bool(config.entra_tenant_id and config.entra_client_id)
        _cloud_fallback = False
        cloud_ch = (
            runtime.channel_manager.get("cloud") if hasattr(runtime, "channel_manager") else None
        )
        if cloud_ch and getattr(cloud_ch, "_using_shared_app", False):
            _cloud_fallback = True
        if config.api_key is None and (not _entra_configured or _cloud_fallback):
            import secrets

            self.temp_key = secrets.token_urlsafe(32)
            from pydantic import SecretStr

            config.api_key = SecretStr(self.temp_key)
            logger.info("Generated temporary API key (in-memory only)")

        self._app = self._create_app()

    def set_web_channel(self, channel: WebChannel) -> None:
        """Inject the WebChannel after construction (called by Runtime)."""
        self._web_channel = channel
        self._register_push_events()

    def _register_push_events(self) -> None:
        """Subscribe to EventBus events and broadcast to WS push queues.

        Idempotent — unregisters any previous handler before re-subscribing.
        """
        from workpilot.bus.events import EventType

        bus = self._runtime.bus
        rt = self._runtime

        # Unregister previous handler if set_web_channel is called again
        prev = getattr(self, "_estop_handler", None)
        if prev is not None:
            bus.events.off(EventType.SECURITY_ESTOP, prev)

        async def _on_estop(_et: EventType, _payload: dict[str, Any]) -> None:
            ch = self._web_channel
            if ch is None:
                return
            estop_status = rt.estop.status()
            payload = json.dumps(
                {
                    "type": "estop",
                    "halted": estop_status.get("halted", False),
                    "reason": estop_status.get("reason"),
                    "triggered_at": estop_status.get("triggered_at"),
                },
                ensure_ascii=False,
            )
            ch.broadcast_push(payload, critical=True)

        self._estop_handler = _on_estop
        bus.events.on(EventType.SECURITY_ESTOP, _on_estop)

        # Mid-run lifecycle events — relayed verbatim to the browser as
        # typed frames so the chip state machine can colour the user
        # bubble (queued/merging/merged/canceled/deferred/running). The
        # frame's ``type`` is the dispatch key in ``useWebSocket``;
        # payload fields mirror the bus-event payload (msg_id /
        # msg_ids / count / depth / inbox_depth_after / reason). See
        # design/features/mid-run-injection.md §5.8.
        prev_handlers: dict[EventType, Any] = getattr(self, "_mid_run_handlers", {}) or {}
        for et, handler in prev_handlers.items():
            bus.events.off(et, handler)

        def _make_relay(frame_type: str) -> Any:
            async def _relay(_et: EventType, payload: dict[str, Any]) -> None:
                ch = self._web_channel
                if ch is None:
                    return
                # ``type`` set LAST so a payload field of the same name
                # can never override the dispatch key the browser
                # ``useWebSocket`` switches on. Defence-in-depth — the
                # current MID_RUN_* event payloads don't carry ``type``,
                # but a future field addition shouldn't be able to
                # silently misroute frames.
                #
                # ``session_id`` scopes delivery so a mid-run event for
                # session A doesn't leak to a browser tab attached to
                # session B. Every MID_RUN_* event payload carries
                # ``session_id`` (canonical sid); broadcast_frame skips
                # any connection whose registered canonical_sid doesn't
                # match. Frames without a session_id (none today) would
                # broadcast to all — explicit None is the opt-out.
                sid = payload.get("session_id")
                ch.broadcast_frame(
                    {**payload, "type": frame_type},
                    session_id=sid if isinstance(sid, str) and sid else None,
                )

            return _relay

        mid_run_map: dict[EventType, str] = {
            EventType.MID_RUN_QUEUED: "mid_run_queued",
            EventType.MID_RUN_INJECTED: "mid_run_injected",
            EventType.MID_RUN_DEFERRED: "mid_run_deferred",
            EventType.MID_RUN_DROPPED: "mid_run_dropped",
            EventType.MID_RUN_PROMOTED: "mid_run_promoted",
        }
        new_handlers: dict[EventType, Any] = {}
        for et, ftype in mid_run_map.items():
            handler = _make_relay(ftype)
            bus.events.on(et, handler)
            new_handlers[et] = handler
        self._mid_run_handlers = new_handlers

    # ── App factory ──────────────────────────────────────────────────────

    def _create_app(self) -> Any:  # noqa: C901
        """Build and return the FastAPI application."""
        try:
            from fastapi import FastAPI, File, WebSocketDisconnect
            from fastapi.middleware.cors import CORSMiddleware
            from fastapi.responses import (
                HTMLResponse,
                JSONResponse,
                RedirectResponse,
                StreamingResponse,
            )
        except ImportError as exc:
            raise ImportError(
                "FastAPI is required for the web server. "
                "Install it with: pip install fastapi uvicorn"
            ) from exc

        @asynccontextmanager
        async def _lifespan(app: Any) -> Any:
            # Install access-log filter AFTER uvicorn's configure_logging().
            self._install_access_log_filter()
            yield

        app = FastAPI(
            title="WorkPilot Web Server",
            version=__version__,
            docs_url=None,
            redoc_url=None,
            lifespan=_lifespan,
        )

        # ── Middleware (outermost first) ─────────────────────────────────
        # FastAPI executes middleware in reverse add order:
        # Auth (innermost) → E-stop → RequestLogger → CORS (outermost)

        # CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self._config.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Request logging
        app.add_middleware(RequestLogger)

        # E-stop gate (returns 503 for /api/* when halted)
        app.add_middleware(EStopMiddleware, estop=self._runtime.estop)

        # Auth (skips /health and /api/health)
        if self._config.api_key is None and not (
            self._config.entra_tenant_id and self._config.entra_client_id
        ):
            logger.warning(
                "Web server running WITHOUT authentication — set api_key or Entra ID "
                "in config to secure the API"
            )
        app.add_middleware(AuthMiddleware, config=self._config)

        # ── Helper ───────────────────────────────────────────────────────

        def _get_client_ip(request: Request) -> str:
            return request.client.host if request.client else "unknown"

        def _check_rate_limit(request: Request) -> JSONResponse | None:
            """Return a 429 JSONResponse if rate-limited, else None."""
            if not self._rate_limiter.check(_get_client_ip(request)):
                return JSONResponse(
                    status_code=429,
                    content=ErrorResponse(
                        error="rate_limit_exceeded",
                        message="Too many requests. Please try again later.",
                    ).model_dump(),
                )
            return None

        def _require_web_channel() -> JSONResponse | None:
            """Return a 503 JSONResponse if WebChannel is not available."""
            if self._web_channel is None:
                return JSONResponse(
                    status_code=503,
                    content=ErrorResponse(
                        error="service_unavailable",
                        message="Web channel not initialized.",
                    ).model_dump(),
                )
            return None

        def _resolve_attachment_refs(
            raw: list[dict[str, Any]] | None,
        ) -> list[dict[str, Any]] | None:
            """Validate client-supplied attachment refs against the on-disk store.

            Drops entries whose sha256 is missing or not found locally. Returns
            ``None`` when the resolved list is empty so downstream stays on the
            plain-text fast path.
            """
            if not raw:
                return None
            from workpilot.security.attachments import load_ref

            out: list[dict[str, Any]] = []
            for item in raw:
                if not isinstance(item, dict):
                    continue
                sha = item.get("sha256")
                if not isinstance(sha, str) or not sha:
                    continue
                ref = load_ref(sha)
                if ref is None:
                    logger.warning(f"Attachment sha256 not found on disk: {sha}")
                    continue
                d = ref.to_dict()
                if isinstance(item.get("name"), str):
                    d["name"] = item["name"]
                out.append(d)
            return out or None

        # ── Static files (React SPA build output) ─────────────────────────
        # pip install: real files at workpilot/web/static (via force-include)
        # dev (editable): fall back to web/dist in the repo root
        _dist = Path(__file__).parent / "static"
        _dist_ok = _dist.is_dir()
        if not _dist_ok:
            _dist = Path(__file__).resolve().parents[2] / "web" / "dist"
            _dist_ok = _dist.is_dir()
        if _dist_ok and _HashedStaticFiles is not None:
            app.mount("/static", _HashedStaticFiles(directory=str(_dist)), name="static")

        # ── Web UI (React SPA) ───────────────────────────────────────────

        _app_html: str | None = None
        if _dist_ok:
            _app_path = _dist / "index.html"
            if _app_path.exists():
                _app_html = _app_path.read_text(encoding="utf-8")

        _SPA_NOT_BUILT = "<h1>WorkPilot</h1><p>Web UI is not available.</p>"

        # Track server start time for uptime calculation
        _started_at: datetime = datetime.now(UTC)

        @app.get("/chat")
        async def ui_chat_redirect() -> RedirectResponse:
            """Legacy /chat → permanent redirect to /."""
            return RedirectResponse("/", status_code=301)

        @app.get("/", response_class=HTMLResponse)
        @app.get("/app", response_class=HTMLResponse)
        @app.get("/app/{path:path}", response_class=HTMLResponse)
        async def ui_spa(path: str = "") -> HTMLResponse:
            """React SPA — serves index.html for all UI routes."""
            if _app_html is None:
                return HTMLResponse(_SPA_NOT_BUILT, status_code=503)
            return HTMLResponse(_app_html)

        # ── Legacy routes (backward compat) ──────────────────────────────

        @app.get("/health", response_model=HealthResponse)
        async def health() -> HealthResponse:
            return HealthResponse()

        @app.post("/v1/chat/completions", response_model=ChatCompletionResponse)
        async def chat_completions(
            body: ChatCompletionRequest,
            request: Request,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            if body.stream:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="unsupported",
                        message="Streaming is not yet supported on this endpoint. Use /api/chat/stream.",
                    ).model_dump(),
                )

            user_messages = [m for m in body.messages if m.role == "user"]
            if not user_messages:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="bad_request",
                        message="At least one user message is required.",
                    ).model_dump(),
                )

            prompt = user_messages[-1].content

            try:
                response_text = await self._runtime.run_prompt(prompt)
            except Exception as exc:
                logger.error(f"Chat completion error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            result = ChatCompletionResponse(
                model=body.model or "workpilot",
                choices=[
                    ChatChoice(
                        message=ChatChoiceMessage(content=response_text),
                    ),
                ],
            )
            return JSONResponse(status_code=200, content=result.model_dump())

        # ── New /api/* routes ────────────────────────────────────────────

        @app.get("/api/auth/config")
        async def auth_config() -> JSONResponse:
            from workpilot.config.schema import SecurityProfile

            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            # Explicit override wins; otherwise derive from security profile
            # (off only for restricted, matching the POST /api/attachments gate).
            if self._config.attachments_enabled is not None:
                attachments_on = self._config.attachments_enabled
            else:
                attachments_on = self._runtime.config.security.profile != SecurityProfile.RESTRICTED
            return JSONResponse(
                content={
                    "entra_enabled": bool(entra_tid and entra_cid),
                    "entra_tenant_id": entra_tid,
                    "entra_client_id": entra_cid,
                    "api_key_enabled": self._config.api_key is not None,
                    "attachments_enabled": attachments_on,
                    "gateway_mode": "local",
                }
            )

        # ── Device code flow (no redirect URI needed) ────────────────────
        # Stores pending device code flows keyed by user_code
        _device_flows: dict[str, Any] = {}
        _device_msal_apps: dict[str, Any] = {}

        @app.post("/api/auth/device-code")
        async def device_code_start() -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            if not entra_tid or not entra_cid:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "entra_not_configured",
                        "message": "Entra ID is not configured on this server.",
                    },
                )

            try:
                import msal as _msal

                app = _msal.PublicClientApplication(
                    client_id=entra_cid,
                    authority=f"https://login.microsoftonline.com/{entra_tid}",
                )
                flow = app.initiate_device_flow(scopes=[f"{entra_cid}/.default"])
                if "user_code" not in flow:
                    return JSONResponse(
                        status_code=500,
                        content={
                            "error": "device_flow_failed",
                            "message": flow.get(
                                "error_description", "Failed to initiate device code flow"
                            ),
                        },
                    )

                user_code = flow["user_code"]
                _device_flows[user_code] = flow
                _device_msal_apps[user_code] = app

                return JSONResponse(
                    content={
                        "user_code": user_code,
                        "verification_uri": flow.get(
                            "verification_uri", "https://microsoft.com/devicelogin"
                        ),
                        "expires_in": flow.get("expires_in", 900),
                        "message": flow.get("message", ""),
                    }
                )
            except ImportError:
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "msal_not_installed",
                        "message": "MSAL library is not installed on the server.",
                    },
                )
            except Exception as exc:
                logger.error(f"Device code initiation error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "internal_error",
                        "message": "Failed to start device code flow.",
                    },
                )

        @app.post("/api/auth/device-code/poll")
        async def device_code_poll(request: Request) -> JSONResponse:
            body = await request.json()
            user_code = body.get("user_code", "")

            flow = _device_flows.get(user_code)
            msal_app = _device_msal_apps.get(user_code)
            if not flow or not msal_app:
                return JSONResponse(
                    status_code=404,
                    content={
                        "error": "flow_not_found",
                        "message": "No pending device code flow for this code.",
                    },
                )

            try:
                result = await asyncio.to_thread(
                    msal_app.acquire_token_by_device_flow,
                    flow,
                    exit_condition=lambda flow: True,  # Return immediately after one poll
                )

                token = result.get("id_token") or result.get("access_token")
                if token:
                    # Success — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    # Persist user identity to USER.md (offloaded to thread — sync I/O)
                    from workpilot.utils.identity import save_identity

                    await asyncio.to_thread(
                        save_identity,
                        result.get("id_token_claims", {}),
                        self._runtime.workspace,
                        self._runtime.config.agents.default.user_file,
                    )
                    return JSONResponse(
                        content={
                            "status": "complete",
                            "access_token": token,
                            "account": {
                                "name": result.get("id_token_claims", {}).get("name", ""),
                                "username": result.get("id_token_claims", {}).get(
                                    "preferred_username", ""
                                ),
                            },
                        }
                    )
                elif result.get("error") == "authorization_pending":
                    return JSONResponse(content={"status": "pending"})
                else:
                    # Error — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    return JSONResponse(
                        status_code=400,
                        content={
                            "status": "error",
                            "error": result.get("error", "unknown"),
                            "message": result.get("error_description", "Authentication failed."),
                        },
                    )
            except Exception as exc:
                logger.error(f"Device code poll error: {exc}")
                return JSONResponse(content={"status": "pending"})

        @app.get("/api/health")
        async def api_health() -> JSONResponse:
            from workpilot.web.api_handlers import handle_health

            return JSONResponse(content=handle_health(self._runtime))

        @app.get("/api/status")
        async def api_status() -> JSONResponse:
            """Comprehensive runtime snapshot — polled by the status dashboard."""
            from workpilot.web.api_handlers import handle_status

            rt = self._runtime
            uptime = int((datetime.now(UTC) - _started_at).total_seconds())

            # Build channel list (web server-specific — tracks live connections)
            _cloud_chan = rt.channel_manager.get(ChannelType.CLOUD)
            cloud_connected = getattr(_cloud_chan, "is_connected", False)
            cloud_cfg = rt.config.channels.cloud

            from workpilot.utils.helpers import local_web_url

            web_cfg = rt.config.channels.web
            web_url = local_web_url(web_cfg.host, web_cfg.port)

            def _channel_entries(name: str) -> list[dict]:
                if name == ChannelType.CLOUD:
                    return []
                if name in (ChannelType.WEB, "gateway"):
                    return [{"name": name, "url": web_url, "connected": True}]
                return [{"name": name, "url": None, "connected": True}]

            channels = [e for n in rt.channel_manager._channels for e in _channel_entries(n)]
            if cloud_cfg.enabled and cloud_cfg.url:
                try:
                    wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
                except ValueError:
                    wc_url = None
                channels.append(
                    {"name": "Web Chat (Cloud)", "url": wc_url, "connected": cloud_connected}
                )
                from workpilot.utils.helpers import teams_bot_url

                teams_url = teams_bot_url(cloud_cfg.bot_app_id) or None
                channels.append(
                    {
                        "name": "Teams (Cloud)",
                        "url": teams_url,
                        "connected": cloud_connected and bool(teams_url),
                    }
                )

            return JSONResponse(
                handle_status(
                    rt,
                    uptime_seconds=uptime,
                    started_at=_started_at.isoformat(),
                    channels=channels,
                )
            )

        @app.get("/api/attachments/{sha256}")
        async def api_get_attachment(sha256: str, request: Request) -> Any:
            """Serve a previously-uploaded attachment by sha256.

            Returns either an image or a text/code file — whichever is on
            disk under the digest (``load_ref`` resolves both kinds).
            Enforces a strict hex-digest check on *sha256* so the handler
            cannot be coerced into serving arbitrary paths. Attachments
            are immutable (content-addressed) so we set a long cache TTL.
            """
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            # Restricted profile disables the whole feature — POST is blocked
            # (see api_upload_attachment) and the flag is false on
            # /api/auth/config, but previously-stored bytes could still be
            # served on GET. Gate symmetrically.
            from workpilot.config.schema import SecurityProfile

            if self._runtime.config.security.profile == SecurityProfile.RESTRICTED:
                return JSONResponse(
                    status_code=403,
                    content=ErrorResponse(
                        error="forbidden",
                        message="Attachments are disabled in the restricted security profile.",
                    ).model_dump(),
                )
            if len(sha256) != 64 or not all(c in "0123456789abcdef" for c in sha256.lower()):
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="invalid_sha256", message="bad digest format"
                    ).model_dump(),
                )

            from fastapi.responses import FileResponse

            from workpilot.security.attachments import load_ref

            ref = load_ref(sha256.lower())
            if ref is None:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found", message="attachment not found"
                    ).model_dump(),
                )
            return FileResponse(
                ref.path,
                media_type=ref.content_type,
                headers={"Cache-Control": "private, max-age=31536000, immutable"},
            )

        @app.post("/api/attachments", response_model=AttachmentResponse)
        async def api_upload_attachment(
            request: Request,
            file: UploadFile = File(...),
        ) -> JSONResponse:
            """Upload an attachment (image or text/code file). Returns its
            content-addressed sha256.

            Bytes are classified (``kind_of``) + size-checked, then stored
            in ``~/.workpilot/data/attachments/`` via :func:`save_attachment`.
            The same sha256 is referenced from subsequent chat messages via
            the ``attachments`` field on ``/api/chat`` or on the
            ``{type:"message", content, attachments}`` WebSocket frame.
            """
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            from workpilot.config.schema import SecurityProfile
            from workpilot.security.attachments import (
                AttachmentError,
                cap_for,
                kind_of,
                save_attachment,
            )

            # Restricted profile bans attachments entirely.
            if self._runtime.config.security.profile == SecurityProfile.RESTRICTED:
                audit = getattr(self._runtime, "audit", None)
                if audit is not None:
                    audit.log_security(
                        event="attachment_blocked_restricted",
                        details={"reason": "security profile=restricted"},
                        severity="warning",
                    )
                return JSONResponse(
                    status_code=403,
                    content=ErrorResponse(
                        error="forbidden",
                        message="Attachments are disabled in the restricted security profile.",
                    ).model_dump(),
                )

            content_type = (file.content_type or "").lower()
            kind = kind_of(content_type, file.filename)
            if kind is None:
                return JSONResponse(
                    status_code=415,
                    content=ErrorResponse(
                        error="unsupported_media_type",
                        message="Allowed: images (png/jpeg/gif/webp) or text/code files.",
                    ).model_dump(),
                )

            # Stream-read with early 413 — avoids holding the full upload
            # in memory when the caller sends bytes well past the cap.
            # (FastAPI still spools the multipart body to a temp file via
            # SpooledTemporaryFile, but we don't amplify that into memory.)
            cap = cap_for(kind)
            buffer = bytearray()
            while True:
                chunk = await file.read(64 * 1024)
                if not chunk:
                    break
                if len(buffer) + len(chunk) > cap:
                    return JSONResponse(
                        status_code=413,
                        content=ErrorResponse(
                            error="payload_too_large",
                            message=f"Max {cap} bytes for kind={kind}",
                        ).model_dump(),
                    )
                buffer.extend(chunk)

            try:
                ref = save_attachment(bytes(buffer), content_type=content_type, name=file.filename)
            except AttachmentError as exc:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="invalid_attachment", message=str(exc)
                    ).model_dump(),
                )

            audit = getattr(self._runtime, "audit", None)
            if audit is not None:
                audit.log_event(
                    action="attachment:saved",
                    data={
                        "sha256": ref.sha256,
                        "content_type": ref.content_type,
                        "size": ref.size,
                        "kind": ref.kind,
                        "name": ref.name,
                    },
                )

            return JSONResponse(
                content=AttachmentResponse(
                    sha256=ref.sha256,
                    content_type=ref.content_type,
                    size=ref.size,
                    kind=ref.kind,
                    name=ref.name,
                ).model_dump()
            )

        @app.post("/api/chat", response_model=ChatResponse)
        async def api_chat(body: ChatRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None  # guarded above
            channel_id = self._web_channel.make_channel_id("web-req")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            try:
                response_text = await self._web_channel.submit_and_wait(
                    channel_id=channel_id,
                    sender_id=sender_id,
                    content=body.prompt,
                    timeout=timeout,
                    attachments=_resolve_attachment_refs(body.attachments),
                )
            except ValueError as exc:
                # _handle_message filtered the input (empty content or
                # allowlist block). Without this fast-path the awaited
                # response_queue.get() would block until ``timeout``
                # elapses for a message that was never published.
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="bad_request",
                        message=str(exc),
                    ).model_dump(),
                )
            except TimeoutError:
                return JSONResponse(
                    status_code=504,
                    content=ErrorResponse(
                        error="timeout",
                        message=f"Agent did not respond within {timeout} seconds.",
                    ).model_dump(),
                )
            except Exception as exc:
                logger.error(f"API chat error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            session_id = body.session_id or self._runtime.session_manager.get_or_create_id(
                ChannelType.WEB, sender_id
            )
            return JSONResponse(
                content=ChatResponse(
                    response=response_text,
                    session_id=session_id,
                ).model_dump(),
            )

        @app.post("/api/chat/stream")
        async def api_chat_stream(
            body: ChatRequest, request: Request
        ) -> StreamingResponse | JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-sse")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            # Register response queue — SSE yields the final response as events
            response_queue = self._web_channel.register_request(channel_id)

            # Publish message through the bus
            published = await self._web_channel._handle_message(
                channel_id=channel_id,
                sender_id=sender_id,
                sender_name=sender_id,
                content=body.prompt,
                attachments=_resolve_attachment_refs(body.attachments),
            )
            if not published:
                # _handle_message filtered the input (empty / allow-list).
                # Without this short-circuit, the SSE generator would
                # block on response_queue.get() until the configured
                # timeout (default 300s) and emit a misleading timeout
                # error. Unregister + return a synchronous 400 so the
                # client sees the real reason immediately.
                self._web_channel.unregister_request(channel_id)
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="bad_request",
                        message="Empty or blocked input — message was not published to the bus",
                    ).model_dump(),
                )

            async def event_generator():
                try:
                    result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
                    if result is not None:
                        yield f"event: message\ndata: {json.dumps({'content': result, 'done': False}, ensure_ascii=False)}\n\n"
                    yield f"event: done\ndata: {json.dumps({'done': True})}\n\n"
                except TimeoutError:
                    yield f"event: error\ndata: {json.dumps({'error': 'timeout'})}\n\n"
                except Exception as exc:
                    logger.error(f"SSE stream error: {exc}")
                    yield f"event: error\ndata: {json.dumps({'error': 'internal_error'})}\n\n"
                finally:
                    self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        @app.post("/api/ws/ticket")
        async def ws_ticket(request: Request) -> JSONResponse:
            """Generate a short-lived, single-use WebSocket auth ticket."""
            from workpilot.web.auth import ticket_store

            claims = request.scope.get("user_claims", {})
            ticket = ticket_store.create(claims)
            return JSONResponse(
                content={"ticket": ticket, "expires_in": ticket_store.ttl},
                headers={"Cache-Control": "no-store"},
            )

        @app.websocket("/api/ws")
        async def websocket_endpoint(websocket: WebSocket) -> None:
            await websocket.accept()

            # Save user identity from Entra JWT (injected by AuthMiddleware).
            # Fire-and-forget background task — sync I/O offloaded to thread.
            user_claims: dict = websocket.scope.get("user_claims", {})
            if user_claims:
                from workpilot.utils.identity import save_identity

                asyncio.create_task(
                    asyncio.to_thread(
                        save_identity,
                        user_claims,
                        self._runtime.workspace,
                        self._runtime.config.agents.default.user_file,
                    )
                )

            channel_check = _require_web_channel()
            if channel_check:
                await websocket.close(code=1011, reason="Web channel not initialized")
                return

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-ws")
            # Resolve the canonical session id BEFORE registering the
            # push queue so ``register_push`` can scope future
            # control-plane frames (mid-run chip events) to this
            # connection. Without it ``broadcast_frame`` would have to
            # fall back to broadcast-to-all, leaking msg_ids across
            # sessions.
            connection_sender_id = websocket.query_params.get("sender_id") or "web-user"
            sender_id = connection_sender_id  # backward-compat alias for below
            canonical_sid = self._runtime.session_manager._normalize_id(
                f"{ChannelType.WEB.value}_{connection_sender_id}"
            )
            response_queue = self._web_channel.register_request(channel_id)
            push_queue = self._web_channel.register_push(channel_id, canonical_sid=canonical_sid)
            stream_queue = self._web_channel.register_stream(channel_id)

            # Send connected handshake — unified protocol with Cloud Gateway.
            # Include THIS session's bridge state (if any) so the client can
            # restore the banner on reconnect without waiting for the first
            # round-trip. The client advertises its identity via the
            # ``sender_id`` query param on connect; we resolve it to the
            # canonical session id and look up the one state that matters.
            #
            # Defaults:
            #   browser       → no query param → sender_id "web-user"  → local_web
            #   attached CLI  → ?sender_id=cli-user                    → local_cli
            # Connection-sticky sender_id — per-message frames MAY carry a
            # ``sender_id`` field, but we ignore it below: the handshake's
            # value is authoritative for this socket. Otherwise a stale
            # client could route a message to session A while the
            # connection's ``canonical_sid`` (used for ``bridge_target``
            # stamps and buffered-frame routing) still points at session
            # B, and the client would render the wrong bridge state.
            #
            # ``connection_sender_id`` / ``sender_id`` / ``canonical_sid``
            # were computed above (before ``register_push``) so the
            # mid-run scoping has them; do not redeclare here.

            # ``bridge_state`` is ALWAYS included (object when bridged,
            # explicit ``null`` when not) so the client can distinguish a
            # server that has authoritative state ("present-with-null =
            # confirmed not bridged") from one that doesn't ("absent =
            # I don't know"). The Cloud Gateway path omits the field
            # entirely on its connected handshake — that absence tells
            # the React client to defer to ``loadHistory``'s session-
            # detail fetch instead. Without this distinction, a cloud
            # ``connected`` frame's missing field would clobber a state
            # that the prior ``loadHistory`` call already restored. (See
            # ``useWebSocket.ts``'s connected-case ``"bridge_state" in
            # data`` presence check.)
            handshake: dict = {"type": "connected", "buffered_count": 0}
            state = self._runtime.bridge_service.get_state(canonical_sid)
            handshake["bridge_state"] = (
                {"target": state.target, "external_id": state.external_id}
                if state is not None
                else None
            )
            # Mid-run refresh recovery (see design/features/mid-run-injection.md
            # §5.10). Pre-drain inbox messages live in
            # ``agent._mid_run_inbox`` only — they're not in JSONL until the
            # next iteration's drain writes them. Without this, a refresh
            # mid-turn makes the user's just-sent message disappear from the
            # UI even though the agent will still process it: the agent
            # would silently respond to a question the user can't see they
            # asked. We surface the inbox snapshot here so the client can
            # rehydrate placeholder bubbles + chips on reconnect.
            #
            # Schema:
            #   session_id    — canonical sid (matches MID_RUN_*.session_id)
            #   active        — agent currently in turn for this session
            #   inbox_depth   — len(_mid_run_inbox[sid])
            #   queued        — [{msg_id, content, deferred}] in arrival order
            #
            # Including ``session_id`` lets the client use the same key
            # the bus events use, so depth tracked here and depth from
            # later MID_RUN_INJECTED / DEFERRED / DROPPED events live in
            # the same map slot. Without it, the composer status strip
            # would double-count (handshake under a synthetic key + real
            # event under canonical sid).
            agent = getattr(self._runtime, "agent", None)
            mid_run_inbox: list = (
                getattr(agent, "_mid_run_inbox", {}).get(canonical_sid, []) if agent else []
            )
            active_sessions: set[str] = (
                getattr(agent, "_active_sessions", set()) if agent else set()
            )
            handshake["mid_run_state"] = {
                "session_id": canonical_sid,
                "active": canonical_sid in active_sessions,
                "inbox_depth": len(mid_run_inbox),
                "queued": [
                    {
                        # msg_id may be missing on legacy in-flight messages
                        # that pre-date E15; emit "" so the client can drop
                        # those rather than render a chip without a key.
                        "msg_id": (m.metadata or {}).get("msg_id", ""),
                        # Prefer ``_raw_content`` (literal user input —
                        # stashed by ``_normalize_next_prefix`` before
                        # the ``/next`` prefix is stripped). The
                        # locally-rendered bubble before refresh shows
                        # ``/next X``; the rehydrated placeholder must
                        # match. Falls back to ``m.content`` for plain
                        # mid-run messages where the two are identical.
                        "content": (m.metadata or {}).get("_raw_content") or (m.content or ""),
                        "deferred": bool((m.metadata or {}).get("deferred")),
                        # Attachment refs survive refresh too — D13/T30
                        # explicitly allow attachment-only mid-run
                        # messages, so the snapshot must carry the refs
                        # for the UI to rehydrate the bubble correctly.
                        # Strip non-portable fields (notably absolute
                        # ``path``) before sending to the browser —
                        # see ``portable_attachments`` for rationale.
                        "attachments": portable_attachments(m.attachments),
                    }
                    for m in mid_run_inbox
                ],
            }
            await websocket.send_json(handshake)

            def _current_bridge_target() -> str | None:
                # Looked up fresh per frame so toggling /bridge mid-connection
                # takes effect on the next reply. Scoped to this connection's
                # canonical session — one user's bridge doesn't leak into
                # another's frames.
                st = self._runtime.bridge_service.get_state(canonical_sid)
                return st.target if st is not None else None

            async def _stream_loop() -> None:
                """Forward streaming chunks (e.g. tool_progress) to WebSocket."""
                while True:
                    chunk = await stream_queue.get()
                    if chunk is None:
                        break
                    try:
                        frame: dict = {
                            "type": "chunk",
                            "content": chunk.content,
                            "chunk_type": chunk.chunk_type or "text",
                            # Always include — null means "not bridged".
                            # Needed on chunks for attached-CLI rendering:
                            # chunks arrive BEFORE the final ``response``
                            # frame (bridge handlers still publish one
                            # even when ``streamed=True`` — AgentLoop only
                            # skips its OWN publish), and the CLI needs
                            # to render the ``claude>`` / ``copilot>``
                            # prefix on the first chunk rather than wait
                            # for the trailing response.
                            "bridge_target": _current_bridge_target(),
                        }
                        if chunk.done:
                            frame["done"] = True
                        await websocket.send_json(frame)
                    except Exception:
                        break

            async def _push_loop() -> None:
                """Forward push notifications (scheduler/background) to WebSocket.

                The push queue carries three shapes:
                  * ``str`` — plain text notification, wrap as
                    ``{type:"push", content}`` and send as JSON text.
                  * ``dict`` — pre-built control frame, send verbatim as
                    JSON text. Used for legacy / non-attachment pushes.
                  * ``PushAttachmentNotification`` — atomic bundle of
                    ``{control, stream_factories}`` for a notify-with-
                    image. The control JSON is sent first, then each
                    factory is invoked and the resulting WPAB stream
                    drained into one ``send_bytes`` call (FastAPI has
                    no native streaming send). Producer enqueues a
                    single bundle so partial enqueue can never happen.
                    Receiver correlates JSON metadata + binary by
                    ``sha256`` in the WPAB header.
                See ``WebChannel.send`` for the producer contract.
                """
                from workpilot.channels.web import PushAttachmentNotification
                from workpilot.security.attachments import (
                    MAX_OUTBOUND_ATTACHMENT_B64,
                )
                from workpilot.security.binary_frame import (
                    MAX_HEADER_LEN,
                    PREAMBLE_LEN,
                )

                # Cap = raw image budget (≈ 12 MiB, derived from
                # ``MAX_OUTBOUND_ATTACHMENT_B64`` * 3/4) plus the WPAB
                # codec's defensive header maximum AND the fixed 8-byte
                # preamble (magic + length prefix). All three are
                # sourced directly from ``binary_frame`` so they stay in
                # lockstep if the codec ever shifts. The browser's
                # ``_MAX_SEED_RAW_BYTES`` checks the *post-decode*
                # payload size, so an at-cap image with a ~200-byte
                # header decodes cleanly even though the raw WS message
                # is slightly larger. Without the header + preamble
                # allowance an at-cap image emitted by the producer
                # would be dropped here even though both the producer
                # and the browser-side cap accept it.
                drain_cap = (MAX_OUTBOUND_ATTACHMENT_B64 * 3 // 4) + MAX_HEADER_LEN + PREAMBLE_LEN

                async def _drain_one_stream(factory: Any) -> None:
                    stream = factory()
                    buf: bytearray | None = bytearray()
                    try:
                        async for chunk in stream:
                            if buf is None or len(buf) + len(chunk) > drain_cap:
                                if buf is not None:
                                    logger.warning(
                                        "WPAB push stream exceeded {}-byte cap, dropping",
                                        drain_cap,
                                    )
                                    buf = None
                                # Stop reading — closing the generator
                                # below releases the underlying file
                                # handle so we don't keep paying disk
                                # I/O for bytes we're going to discard.
                                break
                            buf.extend(chunk)
                    finally:
                        aclose = getattr(stream, "aclose", None)
                        if aclose is not None:
                            try:
                                await aclose()
                            except Exception:
                                pass
                    if buf is not None:
                        # Pass the bytearray directly — uvicorn's
                        # websockets backend explicitly accepts
                        # ``bytes`` / ``bytearray`` / ``memoryview``,
                        # so we avoid the ~12 MiB ``bytes(buf)`` copy
                        # at peak. Starlette's ``send_bytes`` is typed
                        # ``bytes`` strictly, hence the type-ignore.
                        await websocket.send_bytes(buf)  # type: ignore[arg-type]

                while True:
                    msg = await push_queue.get()
                    if msg is None:
                        break
                    try:
                        if isinstance(msg, PushAttachmentNotification):
                            await websocket.send_json(msg.control)
                            for factory in msg.stream_factories:
                                # Per-stream try so a single failing
                                # attachment (file vanished, disk error,
                                # producer exception) doesn't take down
                                # the whole push loop. The control frame
                                # already advertised the sha; the
                                # browser falls back to a fetch — same
                                # path it uses on cache miss.
                                try:
                                    await _drain_one_stream(factory)
                                except WebSocketDisconnect:
                                    raise
                                except Exception as exc:
                                    logger.warning(
                                        "WPAB push stream failed for one attachment, skipping: {}",
                                        exc,
                                    )
                        elif isinstance(msg, dict):
                            await websocket.send_json(msg)
                        elif isinstance(msg, str):
                            await websocket.send_json({"type": "push", "content": msg})
                        else:
                            # Unknown queue-item type — keep the loop
                            # running but surface the producer bug so it
                            # doesn't silently drop notifications.
                            logger.warning(
                                "Push queue received unexpected item type: {}",
                                type(msg).__name__,
                            )
                    except WebSocketDisconnect:
                        # Client gone — exit the loop; the outer
                        # connection handler tears down state.
                        break
                    except Exception as exc:
                        # send_json failure (most often a closed socket)
                        # ends this connection's push loop. A producer
                        # error on the next item alone shouldn't —
                        # those are handled per-item above.
                        logger.debug("Push loop send failed: {}", exc)
                        break

            push_task = asyncio.create_task(_push_loop())
            stream_task = asyncio.create_task(_stream_loop())

            async def _forward(msg: str) -> None:
                """Send one queue item to the WebSocket.

                Internal frame types (approval_request, approval_resolved) are
                sent unwrapped so the client can dispatch on ``type``.
                Everything else is wrapped as ``{"type":"response","content":…}``.
                """
                _INTERNAL_TYPES = {"approval_request", "approval_resolved"}
                try:
                    parsed = json.loads(msg) if isinstance(msg, str) else None
                    if isinstance(parsed, dict) and parsed.get("type") in _INTERNAL_TYPES:
                        await websocket.send_json(parsed)
                        return
                except (json.JSONDecodeError, TypeError):
                    pass
                # ``bridge_target`` is always included (null when unbridged)
                # so client-side banner state transitions deterministically
                # — absence cannot be conflated with "same as last frame".
                frame: dict = {
                    "type": "response",
                    "content": msg,
                    "bridge_target": _current_bridge_target(),
                }
                await websocket.send_json(frame)

            def _resolve_approval(prompt: str, sender_id: str) -> str | None:
                """If prompt is an approval response, resolve it and return the
                resolved action verb (``"approve"`` / ``"deny"`` / ``"always"``).
                Returns ``None`` when the prompt isn't an approval response.

                Thin wrapper around :func:`match_approval_prompt` — that
                module-level helper is the unit-tested core; this closure
                only adds the ApprovalManager lookup + the bus emit so it
                stays unit-testable in isolation (see
                ``test_approval_format.py::TestMatchApprovalPrompt``).
                """
                if not self._runtime.approval_manager:
                    return None
                mgr = self._runtime.approval_manager
                match = match_approval_prompt(prompt, mgr.get_pending())
                if match is None:
                    return None
                action, req_id = match
                from workpilot.bus.events import EventType

                self._runtime.bus.events.emit(
                    EventType.APPROVAL_RESOLVED,
                    {"request_id": req_id, "action": action, "resolver": sender_id},
                )
                return action

            try:
                # ── Concurrent receive: user input OR agent response ───────────
                # After an approval card is shown the tool result arrives in
                # response_queue asynchronously (either via "y" text or REST
                # button click).  We must monitor BOTH simultaneously so neither
                # blocks the other.
                recv_task: asyncio.Task | None = None
                resp_task: asyncio.Task | None = None

                while True:
                    if recv_task is None or recv_task.done():
                        recv_task = asyncio.create_task(websocket.receive_json())
                    if resp_task is None or resp_task.done():
                        resp_task = asyncio.create_task(response_queue.get())

                    done, _ = await asyncio.wait(
                        {recv_task, resp_task},
                        return_when=asyncio.FIRST_COMPLETED,
                    )

                    # ── Agent sent something (approval card or tool result) ────
                    if resp_task in done:
                        resp_task_result = resp_task.result()
                        resp_task = None  # mark consumed
                        await _forward(resp_task_result or "")
                        # If it was an approval card, keep waiting (recv_task still
                        # active) so the user can respond without sending a new prompt.
                        # If it was a plain response we also keep waiting — the
                        # conversation is now back to idle.
                        continue

                    # ── User sent a message ───────────────────────────────────
                    if recv_task in done:
                        data = recv_task.result()
                        recv_task = None  # mark consumed
                        # Accept both unified format {type:"message", content:"..."}
                        # and legacy format {prompt:"...", sender_id:"..."}.
                        # ``sender_id`` on per-message frames is IGNORED —
                        # the handshake's connection_sender_id is the
                        # authoritative routing key (see connect-time
                        # comment). This prevents a frame's sender_id
                        # from diverging the agent session it routes to
                        # from the canonical_sid that stamps
                        # ``bridge_target`` on outgoing frames.
                        #
                        # Legacy clients that routed via per-frame
                        # ``sender_id`` (without setting the query-param
                        # at connect time) would silently route to the
                        # default "web-user" session under this rule.
                        # Log a warning on divergence so the mismatch is
                        # diagnosable from server logs instead of silent.
                        frame_sender_id = data.get("sender_id")
                        if (
                            isinstance(frame_sender_id, str)
                            and frame_sender_id
                            and frame_sender_id != connection_sender_id
                        ):
                            logger.warning(
                                "ws: per-frame sender_id={!r} differs from "
                                "connection sender_id={!r}; connection id wins "
                                "(routing key is locked at handshake)",
                                frame_sender_id,
                                connection_sender_id,
                            )
                        sender_id = connection_sender_id
                        if data.get("type") == "message":
                            prompt = data.get("content", "")
                            raw_attachments = data.get("attachments") or None
                        else:
                            prompt = data.get("prompt", "")
                            raw_attachments = data.get("attachments") or None
                        # E15: client may stamp its own msg_id so the
                        # browser bubble carries the same id that flows
                        # through MID_RUN_* event payloads. Validate
                        # against the same hex-only shape the WorkPilot
                        # frontend produces (uuid4().hex[:16]) so a
                        # third-party / hostile client can't smuggle
                        # arbitrary metadata through this field; the
                        # value flows back to browsers via MID_RUN_*
                        # frames and is used as a React dict key, so
                        # length / character-set should be bounded.
                        # Invalid → drop, BaseChannel falls back to
                        # uuid stamping.
                        client_msg_id = data.get("msg_id")
                        # Normalise to lowercase so a hostile / buggy
                        # client that sends mixed-case can't fragment
                        # ``chipByMsgId`` on the React side (the canonical
                        # generator produces lowercase hex; same regex
                        # accepts both via re.IGNORECASE, so we just
                        # lowercase here for downstream consistency).
                        client_metadata: dict[str, Any] | None = (
                            {"msg_id": client_msg_id.lower()}
                            if (isinstance(client_msg_id, str) and _MSG_ID_RE.match(client_msg_id))
                            else None
                        )

                        if not prompt and not raw_attachments:
                            await websocket.send_json(
                                {
                                    "type": "error",
                                    "code": "empty_prompt",
                                    "message": "prompt is required",
                                }
                            )
                            continue

                        # Interrupt fast-path: /cancel bypasses the inbound queue
                        if prompt.strip().lower() == "/cancel":
                            sid = self._runtime.session_manager.get_or_create_id(
                                ChannelType.WEB, sender_id
                            )
                            interrupted = self._runtime.agent.interrupt(sid)
                            if not interrupted:
                                # Agent idle — respond immediately (no agent turn to deliver it).
                                # Stamp ``bridge_target`` like the regular ``_forward`` path so
                                # the client doesn't drop the banner just because this fast-path
                                # response omits the field (missing → null → banner clears).
                                await websocket.send_json(
                                    {
                                        "type": "response",
                                        "content": "Nothing to interrupt.",
                                        "bridge_target": _current_bridge_target(),
                                    }
                                )
                            # If interrupted: agent loop will respond via response_queue
                            continue

                        # Approval fast-path: resolve directly via bus event so
                        # the sequential agent loop is not deadlocked. The
                        # returned action verb drives the user-visible ack —
                        # using the raw prompt would misclassify chip payloads
                        # like "✗ Deny" as approved.
                        resolved_action = _resolve_approval(prompt, sender_id)
                        if resolved_action:
                            status_word = "denied" if resolved_action == "deny" else "approved"
                            await websocket.send_json(
                                {
                                    "type": "response",
                                    "content": f"Tool call {status_word}.",
                                    "bridge_target": _current_bridge_target(),
                                }
                            )
                            # Tool result will arrive in response_queue; resp_task picks it up.
                            continue

                        # Normal message → submit to agent
                        published = await self._web_channel._handle_message(
                            channel_id=channel_id,
                            sender_id=sender_id,
                            sender_name=sender_id,
                            content=prompt,
                            attachments=_resolve_attachment_refs(raw_attachments),
                            metadata=client_metadata,
                        )
                        if not published:
                            # Filtered at the channel boundary — either
                            # an allow-list block OR an empty-content
                            # drop. The two have different remedies
                            # (sign in vs. type something), but the
                            # frontend can't easily tell from the
                            # boolean return alone. Use a generic
                            # ``message_filtered`` code so the UI
                            # surfaces "your message wasn't delivered"
                            # rather than implying the user typed
                            # nothing. Sends an error frame so the
                            # optimistic merging chip / spinner doesn't
                            # dangle waiting for a response that will
                            # never arrive.
                            await websocket.send_json(
                                {
                                    "type": "error",
                                    "code": "message_filtered",
                                    "message": "Message was not delivered to the agent (empty content or sender not allowed).",
                                }
                            )
                            continue
                        # Response (or approval card) will arrive in response_queue;
                        # resp_task will pick it up on the next asyncio.wait iteration.
            except WebSocketDisconnect:
                logger.debug(f"WebSocket disconnected: {channel_id}")
            except Exception as exc:
                logger.error(f"WebSocket error: {exc}")
            finally:
                for t in (push_task, stream_task, recv_task, resp_task):
                    if t is not None and not t.done():
                        t.cancel()
                for t in (push_task, stream_task, recv_task, resp_task):
                    if t is not None:
                        try:
                            await t
                        except (asyncio.CancelledError, Exception):
                            pass
                self._web_channel.unregister_push(channel_id)  # type: ignore[union-attr]
                self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

        @app.get("/api/sessions")
        async def list_sessions(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_sessions

            return JSONResponse(content=handle_sessions(self._runtime))

        @app.get("/api/sessions/{session_id:path}")
        async def get_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_session_detail

            result = handle_session_detail(self._runtime, session_id)
            if result is None:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found",
                        message=f"Session not found: {session_id}",
                    ).model_dump(),
                )
            return JSONResponse(content=result)

        @app.delete("/api/sessions/{session_id:path}")
        async def delete_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            self._runtime.session_manager.delete(session_id)
            return JSONResponse(content={"status": "deleted", "session_id": session_id})

        @app.get("/api/session/recent")
        async def api_session_recent(
            request: Request,
            channel: str = "web",
            sender_id: str = "web-user",
            limit: int = 10,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_session_recent

            return JSONResponse(
                content=handle_session_recent(
                    self._runtime, channel=channel, sender_id=sender_id, limit=limit
                )
            )

        @app.get("/api/tools")
        async def list_tools(request: Request, limit: int = 1000) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_tools

            clamped = max(1, min(limit, 1000))
            return JSONResponse(content=handle_tools(self._runtime)[:clamped])

        @app.get("/api/skills")
        async def list_skills(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_skills

            return JSONResponse(content=handle_skills(self._runtime))

        @app.get("/api/models")
        async def list_models(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_models

            return JSONResponse(content=handle_models(self._runtime))

        @app.get("/api/memory")
        async def api_memory(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_memory

            return JSONResponse(content=handle_memory(self._runtime))

        @app.get("/api/audit")
        async def api_audit(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_audit

            return JSONResponse(content=handle_audit(self._runtime))

        @app.get("/api/cost")
        async def api_cost(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_cost

            return JSONResponse(content=handle_cost(self._runtime))

        @app.get("/api/system-prompts")
        async def api_system_prompts(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_system_prompts

            return JSONResponse(content=handle_system_prompts(self._runtime))

        @app.get("/api/config")
        async def api_config(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_config

            result = handle_config(self._runtime)
            if result is None:
                return JSONResponse(
                    status_code=500, content={"error": "Failed to serialize config."}
                )
            return JSONResponse(content=result)

        @app.patch("/api/config/agent")
        async def api_patch_agent(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            try:
                body = await request.json()
            except Exception:
                return JSONResponse(status_code=400, content={"error": "Invalid JSON body"})
            agent_name = body.get("agent", "default")
            model = body.get("model")
            reasoning_effort = body.get("reasoning_effort")
            clear_effort = body.get("clear_effort", False)
            if not isinstance(agent_name, str):
                return JSONResponse(status_code=400, content={"error": "'agent' must be a string"})
            if model is not None and not isinstance(model, str):
                return JSONResponse(status_code=400, content={"error": "'model' must be a string"})
            if reasoning_effort is not None and not isinstance(reasoning_effort, str):
                return JSONResponse(
                    status_code=400, content={"error": "'reasoning_effort' must be a string"}
                )
            if not isinstance(clear_effort, bool):
                return JSONResponse(
                    status_code=400, content={"error": "'clear_effort' must be a JSON boolean"}
                )
            if clear_effort and reasoning_effort is not None:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "'clear_effort' and 'reasoning_effort' are mutually exclusive"
                    },
                )
            if isinstance(model, str):
                model = model.strip()
                if not model:
                    return JSONResponse(
                        status_code=400,
                        content={"error": "'model' must not be empty or whitespace"},
                    )
                if len(model) > 200:
                    return JSONResponse(
                        status_code=400,
                        content={"error": "'model' must be 200 characters or fewer"},
                    )
            from workpilot.web.api_handlers import handle_patch_agent

            result = handle_patch_agent(
                self._runtime,
                agent_name=agent_name,
                model=model,
                reasoning_effort=reasoning_effort,
                clear_effort=clear_effort,
            )
            if "error" in result:
                return JSONResponse(status_code=400, content=result)
            return JSONResponse(content=result)

        @app.post("/api/config/session-agent")
        async def api_post_session_agent(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            try:
                body = await request.json()
            except Exception:
                return JSONResponse(status_code=400, content={"error": "Invalid JSON body"})
            model = body.get("model")
            reasoning_effort = body.get("reasoning_effort")
            clear_effort = body.get("clear_effort", False)
            if model is not None and not isinstance(model, str):
                return JSONResponse(status_code=400, content={"error": "'model' must be a string"})
            if reasoning_effort is not None and not isinstance(reasoning_effort, str):
                return JSONResponse(
                    status_code=400, content={"error": "'reasoning_effort' must be a string"}
                )
            if not isinstance(clear_effort, bool):
                return JSONResponse(
                    status_code=400, content={"error": "'clear_effort' must be a JSON boolean"}
                )
            if clear_effort and reasoning_effort is not None:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "'clear_effort' and 'reasoning_effort' are mutually exclusive"
                    },
                )
            if isinstance(model, str):
                model = model.strip()
                if not model:
                    return JSONResponse(
                        status_code=400,
                        content={"error": "'model' must not be empty or whitespace"},
                    )
                if len(model) > 200:
                    return JSONResponse(
                        status_code=400,
                        content={"error": "'model' must be 200 characters or fewer"},
                    )
            from workpilot.web.api_handlers import handle_patch_session_agent

            result = handle_patch_session_agent(
                self._runtime,
                model=model,
                reasoning_effort=reasoning_effort,
                clear_effort=clear_effort,
            )
            if "error" in result:
                return JSONResponse(status_code=400, content=result)
            return JSONResponse(content=result)

        @app.get("/api/user-settings")
        async def api_user_settings(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_user_settings

            return JSONResponse(content=handle_user_settings(self._runtime))

        @app.get("/api/approvals")
        async def api_approvals(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_approvals

            return JSONResponse(content=handle_approvals(self._runtime))

        @app.post("/api/approvals/{request_id}/resolve")
        async def api_resolve_approval(request_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_approval_resolve

            try:
                body = await request.json()
            except Exception:
                return JSONResponse(status_code=400, content={"error": "Invalid JSON body."})

            code, result = handle_approval_resolve(
                self._runtime,
                request_id,
                body.get("approved", False),
                body.get("resolver", "web-user"),
                always=body.get("always", False),
            )
            return JSONResponse(status_code=code, content=result)

        @app.post("/api/estop")
        async def trigger_estop(body: EStopRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_estop

            return JSONResponse(content=handle_estop(self._runtime, body.reason))

        @app.post("/api/reset")
        async def reset_estop(body: EStopResetRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.web.api_handlers import handle_reset

            return JSONResponse(content=handle_reset(self._runtime, body.actor))

        return app

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def _notify_when_started(self) -> None:
        """Wait until uvicorn is listening, then fire the on_started callback.

        Passes the *actual* bound port (from the server socket) so callers
        receive the correct port even when port=0 was configured (ephemeral).
        Exceptions from the callback are logged as warnings and swallowed so
        a pid-file write failure never takes down the web server.
        """
        while self._server is not None and not self._server.started:
            await asyncio.sleep(0.05)
        # Exit without calling the callback if stop() cleared the server
        # reference before uvicorn finished binding (rapid shutdown).
        if self._server is None or not self._server.started:
            return
        if self._on_started is None:
            return
        # Read the actual bound port from the first server socket.
        try:
            actual_port: int = self._server.servers[0].sockets[0].getsockname()[1]
        except Exception:
            actual_port = self._config.port  # fallback to configured value
        try:
            self._on_started(actual_port)
        except Exception:
            logger.warning(
                "Exception in on_started callback during web server startup", exc_info=True
            )

    @staticmethod
    def _install_access_log_filter() -> None:
        """Route all uvicorn loggers through loguru and redact JWT tokens.

        Replaces uvicorn's default StreamHandlers with an InterceptHandler that
        forwards records to loguru (unified format + token redaction).

        Must be called AFTER uvicorn's configure_logging() (i.e. from a FastAPI
        startup event) so uvicorn's handlers exist before we replace them.
        """
        import logging

        _TOKEN_RE = re.compile(r"(token=)[A-Za-z0-9._\-+/]+=*")

        class _RedactToken(logging.Filter):
            def filter(self, record: logging.LogRecord) -> bool:
                if record.levelno <= logging.DEBUG:
                    return True
                if record.args:
                    record.args = tuple(
                        _TOKEN_RE.sub(r"\1[redacted]", a) if isinstance(a, str) else a
                        for a in record.args
                    )
                return True

        # Route uvicorn's standard logging through loguru so all logs share
        # the same format.  Also install the token-redaction filter on the
        # intercept handler so JWT tokens are still redacted.
        from loguru import logger as _loguru

        class _InterceptHandler(logging.Handler):
            """Forward stdlib log records to loguru."""

            _f = _RedactToken()

            # Paths and file extensions whose access-log entries should be
            # downgraded to DEBUG to reduce noise from health checks and
            # static-asset requests (JS, CSS, SVG, fonts, images, etc.).
            # Note: relies on uvicorn.access passing the URL path as a str arg
            # in record.args — stable across uvicorn 0.20+.
            _QUIET_PATHS = ("/health", "/api/health", "/api/status")
            _QUIET_SUFFIXES = (".js", ".css", ".svg", ".ico", ".png", ".woff2", ".map")

            def emit(self, record: logging.LogRecord) -> None:
                self._f.filter(record)  # redact tokens
                try:
                    level = _loguru.level(record.levelname).name
                except ValueError:
                    level = record.levelno  # type: ignore[assignment]
                # Downgrade health/status and static-asset access logs to DEBUG.
                if record.name == "uvicorn.access" and record.args:
                    for a in record.args:
                        if isinstance(a, str) and (
                            a in self._QUIET_PATHS or a.endswith(self._QUIET_SUFFIXES)
                        ):
                            level = "DEBUG"
                            break
                frame, depth = logging.currentframe(), 0
                while frame and (depth == 0 or frame.f_code.co_filename == logging.__file__):
                    frame = frame.f_back  # type: ignore[assignment]
                    depth += 1
                _loguru.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())

        handler = _InterceptHandler()
        for name in ("uvicorn", "uvicorn.access", "uvicorn.error"):
            log = logging.getLogger(name)
            log.handlers = [handler]
            log.propagate = False

    async def start(self) -> None:
        """Start the web server using uvicorn."""
        try:
            import uvicorn
        except ImportError as exc:
            raise ImportError(
                "uvicorn is required for the web server. Install it with: pip install uvicorn"
            ) from exc

        config = uvicorn.Config(
            app=self._app,
            host=self._config.host,
            port=self._config.port,
            log_level="info",
            timeout_graceful_shutdown=3,
        )
        self._server = uvicorn.Server(config)

        if self._on_started is not None:
            asyncio.create_task(self._notify_when_started())

        logger.info(f"Web server starting on http://{self._config.host}:{self._config.port}")
        await self._server.serve()

    async def stop(self) -> None:
        """Gracefully shut down the web server."""
        if self._server is not None:
            logger.info("Web server shutting down")
            self._server.should_exit = True
            self._server = None

    @property
    def app(self) -> Any:
        """Return the underlying FastAPI app (for testing or ASGI mounting)."""
        return self._app
