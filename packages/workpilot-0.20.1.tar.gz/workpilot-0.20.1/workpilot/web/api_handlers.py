"""
Shared API handler functions for the admin dashboard.

Pure functions that take a Runtime and return a dict (or list).
handle_approval_resolve returns a (status_code, body_dict) tuple.
Used by both:
  - WebServer (FastAPI endpoints in server.py)
  - CloudChannel admin relay (_handle_admin_endpoint in cloud.py)
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot import __version__
from workpilot.config.schema import ChannelType

if TYPE_CHECKING:
    from workpilot.agent.tools.base import Tool
    from workpilot.runtime import Runtime


def _score_to_tier(score: int) -> dict[str, Any]:
    """Map a risk score to display info."""
    if score <= 2:
        tier = "safe"
    elif score <= 4:
        tier = "moderate"
    elif score <= 6:
        tier = "elevated"
    elif score <= 8:
        tier = "high"
    else:
        tier = "critical"
    return {"mode": "fixed", "base_score": score, "tier": tier}


def _tool_risk_info(tool: Tool) -> dict[str, Any]:
    """Get a tool's risk display info from ``risk_range``.

    Range span ≤ 1 → treat as fixed (show single score).
    Range span > 1 → dynamic (show range).
    """
    try:
        lo, hi = tool.risk_range
    except (TypeError, ValueError):
        lo, hi = 0, 10
    if hi - lo <= 1:
        score = (lo + hi) // 2 if lo != hi else lo
        info = _score_to_tier(score)
        info["range"] = [lo, hi]
        return info
    return {"mode": "dynamic", "base_score": None, "tier": "dynamic", "range": [lo, hi]}


def _skills_summary(rt: Runtime) -> dict[str, int]:
    """Skills count for the status endpoint."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return {"count": 0, "active": 0}
    registry = getattr(rt, "tool_registry", None)
    skills = loader.list_loaded()
    active = sum(
        1
        for s in skills
        if s.is_platform_eligible()
        and not s.is_superseded(registry)
        and not s.disable_model_invocation
        and not s.check_requirements(registry)
    )
    return {"count": len(skills), "active": active}


def handle_status(
    rt: Runtime,
    *,
    uptime_seconds: int | None = None,
    started_at: str | None = None,
    channels: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """GET /api/status — comprehensive runtime snapshot.

    Optional kwargs are added by the local web server which tracks
    uptime and channel state; the cloud relay omits them.
    """
    tools = rt.tool_registry.list_tools()
    by_tier: dict[str, int] = {
        "safe": 0,
        "moderate": 0,
        "elevated": 0,
        "high": 0,
        "critical": 0,
        "dynamic": 0,
    }
    for t in tools:
        by_tier[_tool_risk_info(t)["tier"]] += 1

    try:
        session_count = len(rt.session_manager.list_sessions())
    except Exception:
        session_count = 0

    sched_health = rt.scheduler.health() if rt.scheduler else {}

    result: dict[str, Any] = {
        "version": __version__,
        "status": "halted" if rt.estop.is_halted else "ok",
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
        "provider": (
            lambda _live: (
                lambda _cfg: {
                    "model": (
                        (getattr(_cfg, "model", None) if _cfg is not None else None)
                        or rt.config.agents.default.model
                    ),
                    # Distinguish "no live config" (fall back to default) from
                    # "live config present with effort=None" (faithfully report
                    # a cleared/unset session effort so the UI reflects state).
                    "reasoning_effort": (
                        (
                            str(_cfg.reasoning_effort)
                            if getattr(_cfg, "reasoning_effort", None) is not None
                            else None
                        )
                        if _cfg is not None
                        else (
                            str(rt.config.agents.default.reasoning_effort)
                            if rt.config.agents.default.reasoning_effort is not None
                            else None
                        )
                    ),
                }
            )(getattr(_live, "_config", None))
        )(getattr(rt, "agent", None)),
        "sessions": {"count": session_count},
        "tools": {"count": len(tools), "by_tier": by_tier},
        "skills": _skills_summary(rt),
        "scheduler": {
            "enabled": sched_health.get("running", False),
            "job_count": sched_health.get("total_jobs", 0),
            "active_jobs": sched_health.get("active_jobs", 0),
        },
        "workspace": str(rt.workspace),
        "agent": {
            "name": rt.config.agents.default.name,
            "max_iterations": rt.config.agents.default.max_iterations,
        },
        "security": {
            "profile": rt.config.security.profile.value,
            "audit_enabled": rt.config.security.audit.enabled,
            "audit_redact": rt.config.security.audit.redact_secrets,
            "estop_on_leak": rt.config.security.estop.trigger_on_leak,
            "entra_enabled": bool(
                rt.config.channels.web.entra_tenant_id and rt.config.channels.web.entra_client_id
            ),
            "api_key_enabled": rt.config.channels.web.api_key is not None,
        },
    }
    if uptime_seconds is not None:
        result["uptime_seconds"] = uptime_seconds
    if started_at is not None:
        result["started_at"] = started_at
    if channels is not None:
        result["channels"] = channels
    return result


def handle_health(rt: Runtime) -> dict[str, Any]:
    """GET /api/health — basic health with E-stop and bus state."""
    return {
        "status": "halted" if rt.estop.is_halted else "ok",
        "version": __version__,
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
    }


def handle_models(rt: Runtime) -> dict[str, Any]:
    """GET /api/models — list all configured models with context window, input token limits,
    and reasoning_effort per agent."""
    from workpilot.providers.model_catalog import get_context_window, get_max_input_tokens
    from workpilot.providers.resolver import resolve_model_chain

    providers = rt.config.providers
    agents_cfg = rt.config.agents

    def _chain_with_limits(chain: list[str]) -> list[dict[str, Any]]:
        return [
            {
                "model": m,
                "context_window": get_context_window(m),
                "max_input_tokens": get_max_input_tokens(m),
            }
            for m in chain
        ]

    # Collect all agent models (builtin + user-defined)
    agents: dict[str, Any] = {}
    all_agents = dict(getattr(rt, "_all_agents", {}))
    if "default" not in all_agents:
        all_agents["default"] = agents_cfg.default
    for name, cfg in all_agents.items():
        model = cfg.model
        chain = resolve_model_chain(model, providers)
        effort = cfg.reasoning_effort
        entry: dict[str, Any] = {
            "alias": model,
            "chain": _chain_with_limits(chain),
            "reasoning_effort": str(effort) if effort is not None else None,
        }
        if cfg.metadata.get("internal"):
            entry["internal"] = True
        agents[name] = entry

    # Collect alias mappings
    aliases: dict[str, Any] = {}
    for alias in ("auto", "fast", "reasoning", "coding"):
        chain = resolve_model_chain(alias, providers)
        aliases[alias] = {"chain": _chain_with_limits(chain)}

    return {"agents": agents, "aliases": aliases}


def handle_sessions(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/sessions — list all sessions.

    Augmented with per-target bridge logs as distinct entries with
    ``kind: "bridge"``, so the UI can surface them as a separate
    category without a second round-trip. Regular sessions carry
    ``kind: "session"``. Consumers that don't know about ``kind`` can
    ignore the field and treat both uniformly.
    """
    entries: list[dict[str, Any]] = []
    for s in rt.session_manager.list_sessions():
        entries.append({**s, "kind": "session"})

    # Per-target bridge logs live in ``<sessions>/bridge/<sid>.<target>.jsonl``.
    # BridgeSessionStore.list_logs() is intentionally stat-only (no file
    # reads, no line counting) so this endpoint stays O(file count), not
    # O(total bridge bytes). That means no ``message_count`` here — the
    # UI badge falls back to 0 for bridge entries in the list, and the
    # detail drill-in (``GET /api/sessions/<sid>.<target>``) loads the
    # full turn list where an exact count can be computed if needed.
    bridge_store = getattr(rt, "bridge_store", None)
    if bridge_store is not None:
        for log in bridge_store.list_logs():
            entries.append(
                {
                    "session_id": log["stem"],
                    "kind": "bridge",
                    "parent_session_id": log["parent_sid"],
                    "target": log["target"],
                    "size_bytes": log["size_bytes"],
                }
            )
    return entries


def _normalize_content(msg: dict[str, Any]) -> dict[str, Any]:
    """Normalize native Responses API items to Chat-like format for web display.

    - ``content: [{type: "output_text", text}]`` → plain string
    - ``function_call_output`` → ``{role: "tool", content: output, tool_call_id: call_id}``
    - ``function_call`` → ``{role: "assistant", tool_calls: [{id, function}]}``
    """
    item_type = msg.get("type", "")

    if item_type == "function_call_output":
        output = msg.get("output", "")
        if not isinstance(output, str):
            output = json.dumps(output, ensure_ascii=False)
        call_id = msg.get("call_id") or ""
        return {**msg, "role": "tool", "content": output, "tool_call_id": call_id}

    if item_type == "function_call":
        call_id = msg.get("call_id") or msg.get("id") or ""
        name = msg.get("name", "?")
        arguments = msg.get("arguments", "{}")
        return {
            **msg,
            "role": "assistant",
            "content": "",
            "tool_calls": [
                {
                    "id": call_id,
                    "function": {"name": name, "arguments": arguments},
                }
            ],
        }

    content = msg.get("content")
    if isinstance(content, list):
        text = "".join(
            p.get("text", "") or p.get("refusal", "") for p in content if isinstance(p, dict)
        )
        return {**msg, "content": text}
    return msg


def handle_session_detail(rt: Runtime, session_id: str) -> dict[str, Any] | None:
    """GET /api/sessions/{id} — session messages.

    Two id shapes:

    * ``<sid>`` — regular session; returns main JSONL messages with
      per-target bridge turns spliced in by timestamp. Bridge turns live
      in separate files (context isolation; see design/features/bridge-
      mode.md §4) but the user-facing scroll-back should be complete, so
      the detail endpoint merges them here. Assistant bridge turns are
      stamped with ``_origin: "<target>-bridge"`` so the UI applies its
      target-tinted accent.
    * ``<sid>.<target>`` — bridge log only; returns just that target's
      turns. Used by the Sessions view when the user drills into a
      bridge entry surfaced by ``handle_sessions``.

    Returns ``None`` when neither shape resolves to any content.
    """
    bridge_store = getattr(rt, "bridge_store", None)

    # Main session takes precedence over bridge-log-only detail. A
    # legitimate session whose id contains a dot (e.g. sender_id
    # ``foo.claude`` → ``web_foo.claude``) would otherwise be
    # mis-routed into the ``<parent>.<target>`` bridge branch below.
    messages = rt.session_manager.get_messages(session_id)

    # Bridge-log-only detail — id matches ``<parent>.<target>`` AND there
    # is NO main-session file on disk at the full id. The previous gate
    # (``not messages``) was a proxy for "no main session"; that proxy
    # is wrong for the (rare) case of an empty-but-existing main session
    # whose id happens to end in ``.claude`` or ``.copilot`` — it would
    # misroute that empty session into the bridge branch and return
    # bridge content for an unrelated bridge log. Checking real session
    # existence closes the loophole without adding a new public API.
    # Surface entries of this shape come from ``handle_sessions``'s
    # ``kind: "bridge"`` list, which deliberately keys them on the
    # canonical ``<canonical_sid>.<target>`` stem — not a value that a
    # user's ``sender_id`` is likely to collide with.
    main_session_exists = (
        session_id in rt.session_manager._sessions
        or rt.session_manager._session_path(session_id).exists()
    )
    if not main_session_exists and bridge_store is not None and "." in session_id:
        parent_sid_raw, _, target = session_id.rpartition(".")
        if target in ("claude", "copilot"):
            # Normalize the parent sid — bridge files are keyed on the
            # canonical form, so a caller hitting ``/api/sessions/cli_local.claude``
            # (legacy) must resolve to the canonical ``local_cli.claude.jsonl``.
            parent_sid = rt.session_manager._normalize_id(parent_sid_raw)
            turns = bridge_store.get_turns(parent_sid, target)  # type: ignore[arg-type]
            if turns:
                stamped = [
                    {**t, "_origin": f"{target}-bridge"} if t.get("role") == "assistant" else t
                    for t in turns
                ]
                # Bridge-log-only detail belongs to its parent session;
                # the parent's live target (if any) is the relevant one
                # for banner restore — not this view's static target.
                # Same defensive isinstance(str) check as below — keeps
                # mocked bridge_service shapes from breaking JSON encode.
                bridge_service_early = getattr(rt, "bridge_service", None)
                parent_active: str | None = None
                if bridge_service_early is not None:
                    parent_state = bridge_service_early.get_state(parent_sid)
                    if parent_state is not None:
                        parent_target_val = getattr(parent_state, "target", None)
                        if isinstance(parent_target_val, str):
                            parent_active = parent_target_val
                return {
                    "session_id": session_id,
                    "kind": "bridge",
                    "parent_session_id": parent_sid,
                    "target": target,
                    "messages": [_normalize_content(m) for m in stamped],
                    "active_bridge_target": parent_active,
                }

    if not messages:
        return None

    # Determine which target (if any) is ACTIVELY bridged for this
    # session in the current runtime. Used below to distinguish a still-
    # live ON marker from an orphan one (process killed mid-bridge,
    # never wrote an OFF). Orphans get a synthetic OFF injected into
    # the response so the UI sees a clean ON/OFF segment; the JSONL is
    # NOT mutated here — on-disk healing happens opportunistically the
    # next time ``BridgeService.toggle`` fires for this session.
    bridge_service = getattr(rt, "bridge_service", None)
    active_bridge_target: str | None = None
    if bridge_service is not None:
        live_state = bridge_service.get_state(session_id)
        if live_state is not None:
            # ``isinstance(... , str)`` filters out non-string sentinels —
            # mocked bridge services in tests return MagicMock attributes,
            # which would otherwise reach JSON serialization here (the
            # field is now part of the wire response, not just used
            # internally for orphan detection) and raise.
            target_val = getattr(live_state, "target", None)
            if isinstance(target_val, str):
                active_bridge_target = target_val

    # Splice in bridge turns from all targets referenced by this session's
    # ``_bridge_toggle`` markers, merged by timestamp. Cheap when bridge
    # was never used (no markers → no fetch).
    #
    # CRITICAL: bridge logs are append-only per ``(canonical_sid, target)``
    # and survive ``/new`` (which only clears the main session JSONL via
    # ``SessionManager.clear``, not the bridge store). If we just splice
    # every turn in the bridge log whenever a marker exists, a post-``/new``
    # bridge attempt would re-render EVERY historical turn under the fresh
    # timeline. Filter bridge turns to those whose ``_ts`` falls inside an
    # ON/OFF window recorded in the CURRENT main-session JSONL for that
    # target — markers themselves are cleared by /new, so only the
    # post-clear windows remain.
    if bridge_store is not None:
        from workpilot.agent.bridge import BRIDGE_TARGETS, build_synthetic_off

        # Per-target list of (on_ts, off_ts_or_empty) windows drawn from
        # the main session's _bridge_toggle markers in order. Targets
        # not in BRIDGE_TARGETS are filtered defensively — those values
        # feed into ``bridge_store.path_for`` which builds filesystem
        # paths, and we don't trust arbitrary strings from a possibly
        # manually edited JSONL.
        windows_by_target: dict[str, list[tuple[str, str]]] = {}
        current_on: dict[str, str] = {}
        for m in messages:
            if not m.get("_bridge_toggle"):
                continue
            tgt = m.get("_bridge_target")
            if not isinstance(tgt, str) or tgt not in BRIDGE_TARGETS:
                continue
            ts = str(m.get("_ts") or m.get("timestamp") or "")
            action = m.get("_bridge_action")
            if action == "on":
                current_on[tgt] = ts
            elif action == "off" and tgt in current_on:
                windows_by_target.setdefault(tgt, []).append((current_on.pop(tgt), ts))
        # Any still-open ``on`` markers (bridge still active) → window
        # extends to the end of time. ``"￿"`` (U+FFFF, the max
        # character in the Basic Multilingual Plane) sorts after any
        # real ISO-8601 timestamp under lexicographic comparison, which
        # is the ordering used everywhere else in this function.
        for tgt, on_ts in current_on.items():
            windows_by_target.setdefault(tgt, []).append((on_ts, "￿"))

        # Synthesize OFF markers for orphan ON markers — any still-open
        # ON whose target is NOT the one currently active in the live
        # registry. Reuses ``current_on`` from the walk above (identical
        # definition to ``detect_orphan_ons`` would produce, minus the
        # filter here for the active target). Response-only — JSONL
        # stays untouched; on-disk healing happens lazily in
        # ``BridgeService.toggle``. ``build_synthetic_off`` keeps the
        # marker shape byte-identical with the heal path.
        canonical_sid = rt.session_manager._normalize_id(session_id)
        orphan_synthetic_offs = [
            build_synthetic_off(tgt, on_ts, bridge_store, canonical_sid)
            for tgt, on_ts in current_on.items()
            if tgt != active_bridge_target
        ]

        if windows_by_target:
            bridge_turns: list[dict[str, Any]] = []
            for target, windows in windows_by_target.items():
                turns = bridge_store.get_turns(canonical_sid, target)  # type: ignore[arg-type]
                for t in turns:
                    turn_ts = str(t.get("_ts") or t.get("timestamp") or "")
                    # Turn is in-window if its _ts falls within any recorded
                    # (on, off) pair. Missing _ts never matches — safer to
                    # drop than guess (an old untimestamped turn could land
                    # in the current timeline otherwise).
                    if not turn_ts:
                        continue
                    in_window = any(on <= turn_ts <= off for on, off in windows)
                    if not in_window:
                        continue
                    if t.get("role") == "assistant":
                        bridge_turns.append({**t, "_origin": f"{target}-bridge"})
                    else:
                        bridge_turns.append(t)
            if bridge_turns or orphan_synthetic_offs:
                # Stable merge by timestamp. ``_ts``/``timestamp`` absent
                # → treat as epoch 0 so orphan entries sort first.
                # Orphan synthetic OFFs come LAST in the concat so, when
                # their ts ties with a bridge turn's ts, the OFF sorts
                # after the turn (stable sort preserves input order).
                def _ts(m: dict[str, Any]) -> str:
                    return str(m.get("_ts") or m.get("timestamp") or "")

                merged = sorted(
                    [*messages, *bridge_turns, *orphan_synthetic_offs],
                    key=_ts,
                )
                return {
                    "session_id": session_id,
                    "kind": "session",
                    "messages": [_normalize_content(m) for m in merged],
                    "active_bridge_target": active_bridge_target,
                }

    return {
        "session_id": session_id,
        "kind": "session",
        "messages": [_normalize_content(m) for m in messages],
        "active_bridge_target": active_bridge_target,
    }


def handle_session_recent(
    rt: Runtime,
    channel: ChannelType | str = "web",
    sender_id: str = "web-user",
    limit: int = 10,
) -> list[dict[str, Any]]:
    """GET /api/session/recent — last N visible messages for a channel/sender.

    Returns user, assistant, and approval_request turns (tool messages excluded).
    """
    session_id = rt.session_manager.get_or_create_id(ChannelType.of(channel), sender_id)
    messages = rt.session_manager.get_messages(session_id)
    visible = [
        m
        for m in messages
        if m.get("role") in ("user", "assistant", "approval_request", "approval_resolved")
    ]
    return [_normalize_content(m) for m in visible[-limit:]]


def handle_skills(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/skills — list all loaded skills with eligibility status."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return []

    registry = getattr(rt, "tool_registry", None)
    result: list[dict[str, Any]] = []
    for s in loader.list_loaded():
        # Compute status — cheap checks first, expensive last
        missing: list[str] = []
        if not s.is_platform_eligible():
            status = "platform-ineligible"
        elif s.is_superseded(registry):
            status = "superseded"
        elif s.disable_model_invocation:
            status = "disabled"
        else:
            missing = s.check_requirements(registry)
            status = "ineligible" if missing else "active"

        result.append(
            {
                "name": s.name,
                "description": s.description,
                "mode": s.mode,
                "source_tier": s.source_tier,
                "source_path": s.source_path,
                "status": status,
                "keywords": s.keywords,
                "missing_requirements": missing,
                "superseded_by": s.superseded_by_tools,
                "os_filter": s.os_filter,
            }
        )
    return result


def handle_tools(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/tools — list all registered tools and MCP servers with status."""
    active_names = {t.name for t in rt.tool_registry.get_active_tools()}
    result: list[dict[str, Any]] = []

    for t in rt.tool_registry.list_tools_sorted():
        category = t.metadata.category if t.metadata else "builtin"
        is_mcp_tool = category == "mcp"
        ri = _tool_risk_info(t)
        result.append(
            {
                "name": t.name,
                "description": t.description,
                "tier": "mcp" if is_mcp_tool else (t.metadata.tier if t.metadata else "core"),
                "active": t.name in active_names,
                "type": "mcp_tool" if is_mcp_tool else "builtin",
                "risk_mode": ri["mode"],
                "risk_score": ri["base_score"],
                "risk_tier": ri["tier"],
                "risk_range": ri.get("range"),
            }
        )

    # MCP servers (connection-level entries)
    mcp_mgr = getattr(rt, "_mcp_manager", None)
    risk_policy = rt.config.tools.mcp_risk_policy or {}
    if mcp_mgr:
        for s in mcp_mgr.list_servers():
            if not s.enabled:
                continue
            # Resolve server-level risk from policy.
            # If server has per-tool overrides or _rules, risk varies per tool → dynamic.
            server_policy = risk_policy.get(s.name, {})
            has_per_tool = False
            default_risk = None
            if isinstance(server_policy, dict):
                has_per_tool = any(k for k in server_policy if not k.startswith("_")) or bool(
                    server_policy.get("_rules")
                )
                default_risk = server_policy.get("_default_risk")
            else:
                default_risk = server_policy  # bare int or str
            if default_risk is None:
                default_risk = risk_policy.get("_default_risk")
            if has_per_tool:
                # Compute range from all configured int values
                scores: list[int] = []
                if isinstance(server_policy, dict):
                    for k, v in server_policy.items():
                        if not k.startswith("_") and isinstance(v, int):
                            scores.append(v)
                    if isinstance(default_risk, int):
                        scores.append(default_risk)
                if scores and max(scores) - min(scores) <= 1:
                    # Narrow range — treat as fixed
                    score = (min(scores) + max(scores)) // 2
                    ri = _score_to_tier(score)
                    ri["range"] = [min(scores), max(scores)]
                elif scores:
                    ri = {
                        "mode": "dynamic",
                        "base_score": None,
                        "tier": "dynamic",
                        "range": [min(scores), max(scores)],
                    }
                else:
                    ri = {
                        "mode": "dynamic",
                        "base_score": None,
                        "tier": "dynamic",
                        "range": [0, 10],
                    }
            elif isinstance(default_risk, int):
                ri = _score_to_tier(default_risk)
                ri["range"] = [default_risk, default_risk]
            else:
                ri = {"mode": "dynamic", "base_score": None, "tier": "dynamic", "range": [0, 10]}
            result.append(
                {
                    "name": f"MCP_{s.name}",
                    "description": s.description or "",
                    "tier": "mcp",
                    "active": s.state.value == "connected",
                    "type": "mcp_server",
                    "state": s.state.value,
                    "tool_count": s.tool_count,
                    "risk_mode": ri["mode"],
                    "risk_score": ri["base_score"],
                    "risk_tier": ri["tier"],
                    "risk_range": ri.get("range"),
                }
            )

    return result


_LEADING_DATE_RE = re.compile(r"^#{1,3}\s+\d{4}-\d{2}-\d{2}\s*\n?")


def _strip_leading_date(content: str) -> str:
    """Remove leading markdown date headers like '## 2026-04-13' from content."""
    return _LEADING_DATE_RE.sub("", content).strip()


def handle_memory(rt: Runtime) -> dict[str, Any]:
    """GET /api/memory — MEMORY.md content + knowledge store entries."""
    result: dict[str, Any] = {"memory_md": "", "knowledge": []}

    mem = getattr(rt, "_memory", None)
    if mem:
        try:
            result["memory_md"] = mem.read_memory() or ""
        except Exception:
            result["memory_md"] = "(error reading MEMORY.md)"
    else:
        memory_path = Path.home() / ".workpilot" / "MEMORY.md"
        if memory_path.exists():
            try:
                result["memory_md"] = memory_path.read_text(encoding="utf-8")
            except Exception:
                result["memory_md"] = "(error reading MEMORY.md)"

    try:
        if mem and hasattr(mem, "history"):
            entries = mem.history.list_recent(top_k=50)
            result["knowledge"] = [
                {
                    "id": e.get("id"),
                    "content": _strip_leading_date(e.get("content", "")),
                    "category": e.get("category", ""),
                    "source": e.get("source", ""),
                    "created_at": e.get("created_at", ""),
                }
                for e in entries
            ]
    except Exception:
        pass

    return result


def handle_audit(rt: Runtime) -> dict[str, Any]:
    """GET /api/audit — recent audit log entries (last 200, newest first)."""
    return {"entries": rt.audit.recent_entries(200)}


def handle_cost(rt: Runtime) -> dict[str, Any]:
    """GET /api/cost — token usage stats."""
    return rt.usage_tracker.stats()


def handle_config(rt: Runtime) -> dict[str, Any] | None:
    """GET /api/config — read-only config snapshot. Returns None on error.

    Pydantic ``SecretStr`` fields (api_key, token, client_secret, password…)
    are rendered as ``"**********"`` by ``model_dump(mode="json")``.
    ``MCPServerConfig.env`` and ``.headers`` are untyped ``dict[str, str]``
    so Pydantic won't mask them, and ``${ENV_VAR}`` placeholders are
    already resolved to plaintext by the loader — redact those subtrees
    here before the dict reaches the browser.
    """
    try:
        cfg = rt.config.model_dump(mode="json")
    except Exception:
        return None
    _redact_mcp_subtrees(cfg)
    return cfg


def handle_patch_agent(
    rt: Runtime,
    agent_name: str,
    model: str | None,
    reasoning_effort: str | None,
    clear_effort: bool,
) -> dict[str, Any]:
    """PATCH /api/config/agent — update model and/or reasoning_effort for an agent.

    Writes the change to workpilot.local.yaml for persistence and also
    updates the live in-memory config so the change takes effect immediately
    without a restart.
    """
    import re

    from workpilot.config.loader import remove_local_config_value, set_local_config_value
    from workpilot.config.schema import ReasoningEffort

    if agent_name != "default" and not re.match(r"^[a-zA-Z_][a-zA-Z0-9_-]*$", agent_name):
        return {"error": f"Invalid agent name: {agent_name!r}"}

    _VALID_EFFORTS = {e.value for e in ReasoningEffort}

    agents_cfg = rt.config.agents
    _all_agents = dict(getattr(rt, "_all_agents", {}))
    if agent_name == "default":
        agent_cfg = agents_cfg.default
    else:
        # Use _all_agents as the source — it holds the fully merged config
        # (builtin defaults + user overrides). agents_cfg.agents contains only
        # the user portion and may be missing builtin fields like tools/permissions.
        _agent = _all_agents.get(agent_name)
        if _agent is None:
            return {"error": f"Unknown agent: {agent_name!r}"}
        agent_cfg = _agent

    prefix = "agents.default" if agent_name == "default" else f"agents.agents.{agent_name}"
    changed: dict[str, Any] = {}

    if model is not None:
        agent_cfg.model = model
        set_local_config_value(f"{prefix}.model", model)
        changed["model"] = model

    if clear_effort:
        agent_cfg.reasoning_effort = None  # disk: null/omit → schema default AUTO on next load
        remove_local_config_value(f"{prefix}.reasoning_effort")
        changed["reasoning_effort"] = None
    elif reasoning_effort is not None:
        if reasoning_effort not in _VALID_EFFORTS:
            return {"error": f"Invalid reasoning_effort: {reasoning_effort!r}"}
        agent_cfg.reasoning_effort = ReasoningEffort(reasoning_effort)  # type: ignore[assignment]
        set_local_config_value(f"{prefix}.reasoning_effort", reasoning_effort)
        changed["reasoning_effort"] = reasoning_effort

    # Also update the live AgentLoop._config so the change takes effect
    # immediately without a restart. Only update when the patched agent IS the
    # running entrypoint — don't mutate the live loop for non-running agents.
    _live = getattr(rt, "agent", None)
    if _live is not None and hasattr(_live, "_config"):
        live_name = getattr(rt.config, "entrypoint", "default")
        if agent_name == live_name:
            from workpilot.config.schema import ReasoningEffort

            if model is not None:
                _live._config.model = model
                if hasattr(_live, "_effective_model"):
                    _live._effective_model = model
                if hasattr(_live, "_consecutive_fallbacks"):
                    _live._consecutive_fallbacks = 0
            if clear_effort:
                # Reset to AUTO — the schema default — not None (null/omit).
                _live._config.reasoning_effort = ReasoningEffort.AUTO  # type: ignore[assignment]
            elif reasoning_effort is not None:
                _live._config.reasoning_effort = ReasoningEffort(reasoning_effort)  # type: ignore[assignment]

    # Keep rt._all_agents in sync so spawn/delegation picks up the change.
    # Include "default" — it is the authoritative source for spawn (runtime.py:447).
    _all = getattr(rt, "_all_agents", None)
    if _all is not None and agent_name in _all:
        _all[agent_name] = agent_cfg

    return {"agent": agent_name, "updated": changed}


def handle_user_settings(rt: Runtime) -> dict[str, Any]:
    """GET /api/user-settings — user local overrides from workpilot.local.yaml."""
    from workpilot.config.loader import _home_local_override

    local_file = _home_local_override()
    # Show ~/.workpilot/... (posix) to avoid leaking host details
    try:
        display_path = "~/" + local_file.relative_to(Path.home()).as_posix()
    except ValueError:
        display_path = local_file.name

    result: dict[str, Any] = {"path": display_path, "exists": False, "data": {}}
    if not local_file.is_file():
        return result

    result["exists"] = True
    try:
        import yaml  # type: ignore[import-untyped]

        text = local_file.read_text(encoding="utf-8")
        loaded = yaml.safe_load(text) if text.strip() else None
        if isinstance(loaded, dict):
            _normalize_yaml_types(loaded)
            _redact_plaintext_yaml(loaded)
            result["data"] = loaded
        elif loaded is not None:
            result["error"] = "Expected YAML mapping at top level"
    except Exception as exc:
        logger.warning("Failed to read user settings: {}", exc)
        result["error"] = f"{type(exc).__name__}: {exc}"

    return result


def handle_approvals(rt: Runtime) -> dict[str, Any]:
    """GET /api/approvals — pending + recently resolved approval queue."""
    pending: list[dict[str, Any]] = []
    resolved: list[dict[str, Any]] = []
    if hasattr(rt, "approval_manager") and rt.approval_manager:
        mgr = rt.approval_manager
        try:
            for req in mgr.get_pending():
                pending.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "args": req.args,
                        "agent_name": req.agent_name,
                        "score": req.score,
                        "reason": req.reason,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "created_at": req.created_at.isoformat() if req.created_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
        # Include recently resolved requests (kept for 60s in _resolved)
        try:
            for req in mgr._resolved.values():
                resolved.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "resolver": req.resolver,
                        "resolved_at": req.resolved_at.isoformat() if req.resolved_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
    return {"pending": pending, "resolved": resolved}


def handle_estop(rt: Runtime, reason: str = "admin dashboard") -> dict[str, Any]:
    """POST /api/estop — trigger emergency stop."""
    rt.estop.trigger(reason, actor="admin")
    return rt.estop.status()


def handle_reset(rt: Runtime, actor: str = "admin") -> dict[str, Any]:
    """POST /api/reset — reset emergency stop."""
    rt.estop.reset(actor=actor)
    return rt.estop.status()


def handle_approval_resolve(
    rt: Runtime,
    request_id: str,
    approved: bool,
    resolver: str = "admin",
    always: bool = False,
) -> tuple[int, dict[str, Any]]:
    """POST /api/approvals/{id}/resolve — returns (status_code, body)."""
    if not hasattr(rt, "approval_manager") or not rt.approval_manager:
        return 503, {"error": "Approval manager not available."}
    try:
        req = rt.approval_manager.get_request(request_id)
        _action = "always" if (always and approved) else ("approve" if approved else "deny")
        rt.approval_manager.resolve(
            request_id, approved=approved, resolver=resolver, action=_action
        )
        allowlist = getattr(rt, "_allowlist", None)
        if always and approved and req and allowlist:
            allowlist.add(
                req.tool_name, req.args, added_by=resolver, note="Added via web UI 'Always Allow'"
            )

        # Persist resolution to session history directly
        # (Don't emit APPROVAL_RESOLVED — that handler also calls
        # approval_manager.resolve() which would fail with "already resolved")
        import json as _json

        status = "approved" if approved else "denied"
        for sid, msgs in rt.session_manager._sessions.items():
            for m in msgs:
                if m.get("role") != "approval_request":
                    continue
                try:
                    data = _json.loads(m.get("content", "{}"))
                except Exception:  # noqa: S112
                    continue
                if data.get("request_id") != request_id:
                    continue
                rt.session_manager.add_message(
                    sid,
                    {
                        "role": "approval_resolved",
                        "content": _json.dumps(
                            {
                                "request_id": request_id,
                                "status": status,
                                "resolver": resolver,
                            }
                        ),
                    },
                )
                break  # unique request_id

        return 200, {"status": "resolved", "approved": approved, "always": always}
    except KeyError:
        # resolve() raises KeyError when request_id not in _pending — but it
        # may exist in _resolved.  Return 409 (not 404) for already-resolved.
        if req and req.status.value != "pending":
            return 409, {
                "error": f"Approval request already resolved as {req.status.value}: {request_id}",
                "request_id": request_id,
                "resolved_status": req.status.value,
            }
        return 404, {
            "error": f"Approval request not found: {request_id}",
            "request_id": request_id,
        }
    except ValueError:
        status = req.status.value if req else "unknown"
        return 409, {
            "error": f"Approval request already resolved as {status}: {request_id}",
            "request_id": request_id,
            "resolved_status": status,
        }
    except Exception as exc:
        return 500, {"error": f"Internal error: {type(exc).__name__}"}


def handle_system_prompts(rt: Runtime) -> dict[str, Any]:
    """GET /api/system-prompts — return the assembled system prompt and its individual sections.

    Uses the runtime's ContextBuilder for the full prompt, and reads the
    individual identity files via the same resolution logic as ContextBuilder:

    - ``_load_identity_or_builtin``: config path (if file exists) →
      ``~/.workpilot/<name>`` override → bundled default.
    - ``USER.md``: only included if a real file exists (no bundled fallback).
    - ``TOOLS.md``: wrapped with ``## Guidelines`` header when not markdown.
    - ``MEMORY.md``: prefixed with section headers and capped at 8 KB.
    """
    from workpilot.agent.compaction import count_tokens
    from workpilot.agent.context import MEMORY_CAP
    from workpilot.utils.defaults import load_default

    sections: list[dict[str, Any]] = []
    errors: list[str] = []

    # Prefer the active AgentLoop's config/workspace so sections match the
    # same agent used to build the full prompt (entrypoint may not be "default").
    agent = getattr(rt, "agent", None)
    agent_cfg = getattr(agent, "_config", None) if agent is not None else None
    if agent_cfg is None:
        agent_cfg = rt.config.agents.default
    workspace = getattr(agent, "_workspace", None) if agent is not None else None
    if workspace is None:
        workspace = rt.workspace

    def _resolve_and_read(config_path: str | None, default_name: str) -> str:
        """Resolve an identity file using the same precedence as ContextBuilder.

        config path → load_default (checks ~/.workpilot/ then bundled).
        When no config path: ~/.workpilot/<name> → bundled default.
        """
        if config_path:
            p = Path(config_path).expanduser()
            if not p.is_absolute():
                p = workspace / p
            if p.is_file():
                return p.read_text(encoding="utf-8").strip()
            # Config path set but file missing — fall through to load_default
            # which checks ~/.workpilot/ then bundled (same as ContextBuilder).
            return load_default(default_name)
        candidate = Path.home() / ".workpilot" / default_name
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8").strip()
        return load_default(default_name)

    def _section(name: str, content: str) -> dict[str, Any]:
        return {
            "name": name,
            "content": content,
            "tokens": count_tokens(content),
            "bytes": len(content.encode("utf-8")),
        }

    # 1. SOUL.md
    soul = _resolve_and_read(agent_cfg.soul_file, "SOUL.md")
    if soul:
        sections.append(_section("SOUL.md", soul))

    # 2. Config instructions
    if agent_cfg.instructions:
        sections.append(_section("Config Instructions", agent_cfg.instructions))

    # 3. AGENTS.md
    agents = _resolve_and_read(agent_cfg.agents_file, "AGENTS.md")
    if agents:
        sections.append(_section("AGENTS.md", agents))

    # 4. TOOLS.md — match ContextBuilder._load_tools_md() wrapping
    tools_content = load_default("TOOLS.md", allow_empty_override=True)
    if tools_content:
        if not tools_content.lstrip().startswith("#"):
            tools_content = f"## Guidelines\n\n{tools_content}"
        sections.append(_section("TOOLS.md", tools_content))

    # 5. USER.md — only include if a real file exists (no bundled fallback)
    user_path: Path | None = None
    if agent_cfg.user_file:
        p = Path(agent_cfg.user_file).expanduser()
        if not p.is_absolute():
            p = workspace / p
        if p.is_file():
            user_path = p
    else:
        candidate = Path.home() / ".workpilot" / "USER.md"
        if candidate.is_file():
            user_path = candidate
    if user_path is not None:
        user_content = user_path.read_text(encoding="utf-8").strip()
        if user_content:
            sections.append(_section("USER.md", user_content))

    # 6. MEMORY.md — add headers and cap at 8 KB to match ContextBuilder
    mem = getattr(rt, "_memory", None)
    if mem:
        try:
            shared = mem.read_shared("MEMORY.md").strip()
            if shared:
                sections.append(
                    _section("MEMORY.md (Shared)", f"## Shared Memory\n\n{shared[:MEMORY_CAP]}")
                )
        except Exception:
            errors.append("Error reading shared MEMORY.md")
        try:
            personal = mem.read_memory().strip()
            if personal:
                sections.append(
                    _section("MEMORY.md (Personal)", f"## Memory\n\n{personal[:MEMORY_CAP]}")
                )
        except Exception:
            errors.append("Error reading personal MEMORY.md")
    else:
        memory_path = Path.home() / ".workpilot" / "MEMORY.md"
        if memory_path.is_file():
            try:
                mc = memory_path.read_text(encoding="utf-8").strip()
                if mc:
                    sections.append(_section("MEMORY.md", mc[:MEMORY_CAP]))
            except Exception:
                errors.append("Error reading MEMORY.md")

    # Build the full assembled system prompt from the agent loop's ContextBuilder
    full_prompt = ""
    ctx = getattr(agent, "_context", None) if agent is not None else None
    if ctx:
        try:
            full_prompt = ctx.build_system_prompt(mode="full")
        except Exception as exc:
            errors.append(f"Error building system prompt: {type(exc).__name__}")
            full_prompt = ""

    result: dict[str, Any] = {
        "sections": sections,
        "full_prompt": full_prompt,
        "full_prompt_length": len(full_prompt.encode("utf-8")),
        "full_prompt_tokens": count_tokens(full_prompt),
    }
    if errors:
        result["errors"] = errors
    return result


# ── Helpers ──────────────────────────────────────────────────────────────────


_SECRET_SUFFIXES = frozenset(
    {
        "api_key",
        "secret",
        "token",
        "password",
        "client_secret",
        "connection_string",
        # HTTP credential headers. Names are normalized (hyphen → underscore)
        # before matching so "Authorization", "Proxy-Authorization",
        # "Set-Cookie" all hit via the suffix rule.
        "authorization",
        "cookie",
    }
)
_REDACTED = "***REDACTED***"


def _is_safe_ref(v: Any) -> bool:
    """``SECRET[name]`` / ``${VAR}`` references are names, not values — keep."""
    return isinstance(v, str) and (v.startswith("SECRET[") or v.startswith("${"))


def _is_secret_key(key: str) -> bool:
    """Key name matches a secret-naming convention (suffix-or-equal).

    Suffix match avoids the substring false positives that would flag
    ``secret_backend``, ``token_path``, ``auto_migrate_secrets``, etc.
    Hyphens (HTTP header style, e.g. ``X-Api-Key``) are normalized to
    underscores before matching so both ``GITHUB_TOKEN`` and
    ``X-Api-Key`` are caught.
    """
    lower = key.lower().replace("-", "_")
    return any(lower == s or lower.endswith("_" + s) for s in _SECRET_SUFFIXES)


def _normalize_yaml_types(d: dict[str, Any] | list[Any]) -> None:
    """Convert non-JSON-native YAML types (date, datetime) to ISO strings."""
    import datetime

    if isinstance(d, list):
        for i, v in enumerate(d):
            if isinstance(v, (dict, list)):
                _normalize_yaml_types(v)
            elif isinstance(v, (datetime.date, datetime.datetime)):
                d[i] = v.isoformat()
        return

    for key in list(d.keys()):
        v = d[key]
        if isinstance(v, (dict, list)):
            _normalize_yaml_types(v)
        elif isinstance(v, (datetime.date, datetime.datetime)):
            d[key] = v.isoformat()


def _redact_mcp_subtrees(cfg: dict[str, Any]) -> None:
    """Mask MCP ``env`` / ``headers`` values in the serialized config.

    Pydantic masks ``SecretStr`` fields automatically, but MCP servers
    declare ``env: dict[str, str]`` and ``headers: dict[str, str]`` which
    the loader fills with ``${ENV_VAR}``-resolved plaintext. Redact values
    whose key names fit the ``_is_secret_key`` convention; leave the rest
    (``LOG_LEVEL``, ``NODE_ENV``…) visible so the UI stays useful.
    """
    servers = cfg.get("tools", {}).get("mcp_servers")
    if not servers:
        return
    items: list[dict[str, Any]] = []
    if isinstance(servers, dict):
        items = [s for s in servers.values() if isinstance(s, dict)]
    elif isinstance(servers, list):
        items = [s for s in servers if isinstance(s, dict)]
    for srv in items:
        for subtree in ("env", "headers"):
            sub = srv.get(subtree)
            if not isinstance(sub, dict):
                continue
            for k, v in list(sub.items()):
                if isinstance(v, str) and v and _is_secret_key(k) and not _is_safe_ref(v):
                    sub[k] = _REDACTED


def _redact_plaintext_yaml(d: dict[str, Any] | list[Any], _parent_key: str = "") -> None:
    """Redact secret-looking keys in raw user YAML.

    Safety net for when ``auto_migrate_secrets=false`` or the user edits
    ``workpilot.local.yaml`` by hand after startup — plaintext values at
    ``SecretStr`` paths would otherwise reach the browser as-is.
    """
    if isinstance(d, list):
        for v in d:
            if isinstance(v, (dict, list)):
                _redact_plaintext_yaml(v, _parent_key)
        return

    parent_is_secret = _is_secret_key(_parent_key) if _parent_key else False
    for key in list(d.keys()):
        v = d[key]
        key_str = str(key)
        key_secret = parent_is_secret or _is_secret_key(key_str)
        if isinstance(v, dict):
            _redact_plaintext_yaml(v, key_str)
        elif isinstance(v, list):
            if key_secret and v and not all(_is_safe_ref(x) for x in v):
                d[key] = [_REDACTED]
            else:
                _redact_plaintext_yaml(v, key_str)
        elif key_secret and v is not None and v != "" and not _is_safe_ref(v):
            d[key] = _REDACTED


def handle_patch_session_agent(
    rt: Runtime,
    *,
    model: str | None,
    reasoning_effort: str | None,
    clear_effort: bool,
) -> dict[str, Any]:
    """POST /api/config/session-agent — session-only model/effort switch.

    Mutates the live AgentLoop config so the change takes effect immediately
    without persisting to ``workpilot.local.yaml``. Equivalent to the
    ``/model`` slash command but invokable from the web UI without injecting
    a chat message.

    Validates the requested model up front via ``resolve_model_chain`` so
    unresolvable aliases/IDs are rejected with the same wording as ``/model``,
    instead of failing later during an LLM call.

    Clearing effort sets ``reasoning_effort = None`` (matching the slash
    command's ``effort=null`` semantics — falls back to the model default at
    call time). Returns ``{"error": ...}`` when no live loop is attached, the
    effort value is invalid, or the model cannot be resolved.
    """
    from workpilot.config.schema import ReasoningEffort
    from workpilot.providers.resolver import describe_resolution_failure, resolve_model_chain

    valid_efforts = {e.value for e in ReasoningEffort}
    if reasoning_effort is not None and reasoning_effort not in valid_efforts:
        return {"error": f"Invalid reasoning_effort: {reasoning_effort!r}"}

    live = getattr(rt, "agent", None)
    if live is None or not hasattr(live, "_config"):
        return {"error": "No live agent loop is running"}

    if model is not None:
        providers_cfg = getattr(rt.config, "providers", None)
        try:
            chain = resolve_model_chain(model, providers_cfg)
        except Exception as exc:
            return {"error": f"Cannot switch to {model!r}: {exc}"}
        if not chain:
            return {"error": f"Cannot switch to {model!r}: {describe_resolution_failure(model)}"}

    changed: dict[str, Any] = {}
    if model is not None:
        live._config.model = model
        if hasattr(live, "_effective_model"):
            live._effective_model = model
        if hasattr(live, "_consecutive_fallbacks"):
            live._consecutive_fallbacks = 0
        changed["model"] = model

    if clear_effort:
        # Match /model effort=null: clear the override (None), not AUTO.
        # Schema default still applies on subsequent reloads.
        live._config.reasoning_effort = None  # type: ignore[assignment]
        changed["reasoning_effort"] = None
    elif reasoning_effort is not None:
        live._config.reasoning_effort = ReasoningEffort(reasoning_effort)  # type: ignore[assignment]
        changed["reasoning_effort"] = reasoning_effort

    return {"updated": changed, "persisted": False}
