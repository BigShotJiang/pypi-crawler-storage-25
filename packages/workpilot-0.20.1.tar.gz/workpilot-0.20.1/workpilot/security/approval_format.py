"""
Channel-specific approval prompt formatters.

Each formatter renders an approval request for a specific channel type:
- CLI:   rich text prompt with ANSI colour
- Cloud: structured JSON for web chat clients
- Teams: Bot Framework Activity with Adaptive Card

Shared helpers:
- ``risk_level()``      — score → (label, web_color, cli_ansi)
- ``action_preview()``  — tool+args → human-readable one-liner
- ``trigger_context()`` — metadata → trigger line with emoji (or empty)
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from typing import Any, NamedTuple

from workpilot.config.schema import ChannelType

# ── Shared approval action definitions ─────────────────────────────────────
# Single source of truth for the three approval actions, used by both the
# Adaptive Card buttons (`_build_adaptive_card`) and the SuggestedActions
# quick replies (`_build_suggested_actions`). Keeping them together prevents
# label / verb drift between the two surfaces.


class _ApprovalAction(NamedTuple):
    """One approval action's labels + Adaptive Card metadata."""

    verb: str  # slash-command verb, e.g. "approve"
    title: str  # button label, shared across surfaces
    ac_style: str | None  # Adaptive Card Action.Submit style; None = default
    ac_outcome: str  # _build_resolved_card outcome key


_APPROVAL_BASE_ACTIONS: tuple[_ApprovalAction, ...] = (
    _ApprovalAction("approve", "✓ Approve", "positive", "approved"),
    _ApprovalAction("deny", "✗ Deny", "destructive", "denied"),
)
_APPROVAL_ALWAYS_ACTION = _ApprovalAction("always", "Always Allow", None, "approved_always")


# Strict allowlist: only the exact emojis used in the chip ``title``s in
# ``_APPROVAL_BASE_ACTIONS`` above (``"✓ Approve"`` / ``"✗ Deny"``). If the
# chip titles ever change emoji, update this regex in lockstep — keeping the
# allowlist scoped to characters actually shipped means we do not silently
# strip user-typed prefixes on real conversation text.
_CHIP_DECORATION_PREFIX = re.compile(r"^[✓✗]+", re.UNICODE)

# ── Zero-width ID encoding (base-4) ─────────────────────────────────────
# Empirically validated 2026-05 on Teams iOS — see
# design/features/approval-ux.md §11.1.2 and the chip-encoding test log.
# Four "purely functional" zero-width characters with no rendering
# side-effects on adjacent characters; each chip-title-trailing char
# encodes 2 bits of the request id.
_ZW_CHARS: tuple[str, ...] = (
    "​",  # ZERO WIDTH SPACE — digit 0
    "‌",  # ZERO WIDTH NON-JOINER — digit 1
    "⁠",  # WORD JOINER — digit 2
    "﻿",  # ZERO WIDTH NO-BREAK SPACE (BOM) — digit 3
)
_ZW_TO_DIGIT = {c: i for i, c in enumerate(_ZW_CHARS)}
# Exactly 16 ZW characters at end-of-string — the **only** canonical shape
# ``encode_request_id_in_title`` produces (4-byte hex id × 4 base-4 digits).
# The negative lookbehind ``(?<![...])`` rejects a 16-char tail that's
# part of a longer run (e.g. a 17- or 32-char trailing block), keeping
# the encoder/decoder/normalizer contracts in lockstep:
#  - ``normalize_approval_text`` only strips the canonical 16-char tail;
#    a stray pasted ZWSP / BOM (1 char) or a 32-char run won't trigger
#    keyword collapse.
#  - ``extract_request_id_from_text`` only decodes a canonical 16-char
#    tail; longer / shorter runs return None outright.
#  - Mid-string ZW chars are preserved (the ``\Z`` anchor + the
#    ``(?<![ZW])`` boundary guarantee the match is purely the trailing
#    canonical block, never a substring earlier in the text).
_ZW_ID_BLOCK = re.compile(f"(?<![{''.join(_ZW_CHARS)}])[{''.join(_ZW_CHARS)}]{{16}}\\Z")


def normalize_approval_text(text: str) -> str:
    """Normalise a free-form user message before approval-keyword matching.

    Workaround for a known Teams **mobile** ``imBack`` bug where the
    SuggestedActions chip's ``title`` (e.g. ``"✓ Approve"``) is delivered
    as ``Activity.Text`` instead of the configured ``value``
    (``"/approve <id>"``). After stripping the leading emoji decoration
    and lower-casing, ``"✓ Approve"`` collapses to ``"approve"`` — which
    the existing bare-keyword fast-paths in ``CloudChannel._on_message`` /
    ``AgentLoop._try_route_approval`` / ``WebServer._resolve_approval``
    already resolve against the single pending approval.

    The desktop Teams imBack contract (``value`` = both displayed text
    and ``Activity.Text``) is unaffected — ``"/approve abc-123"`` has
    no leading decoration, so this normalisation is a no-op for it.

    Trailing zero-width ID block (see ``encode_request_id_in_title``) is
    also stripped — but **only when it is exactly 16 chars at
    end-of-string** (the canonical shape; see ``_ZW_ID_BLOCK``).
    Mid-string ZW chars and trailing runs of any other length are
    preserved verbatim, so inputs like ``"a<ZWSP>pprove"`` or
    ``"approve<single-ZWSP>"`` do **not** silently collapse into the
    approval keyword and trigger routing. Call sites must extract the id
    with ``extract_request_id_from_text`` *before* invoking this helper;
    once the trailing block is stripped, the id is unrecoverable.

    >>> normalize_approval_text("✓ Approve")
    'approve'
    >>> normalize_approval_text("/approve abc-123")
    '/approve abc-123'
    >>> normalize_approval_text("yes")
    'yes'
    """
    s = text.strip()
    s = _CHIP_DECORATION_PREFIX.sub("", s).strip()
    s = _ZW_ID_BLOCK.sub("", s).strip()
    return s.lower()


# ── Zero-width ID encoding (Teams mobile imBack workaround) ─────────────
# Empirically validated 2026-05 on Teams iOS:
# - The mobile client delivers the chip ``title`` as ``Activity.Text``
#   instead of the configured ``value`` (the historical imBack bug).
# - It also preserves zero-width characters byte-for-byte across the
#   click round-trip.
# Encoding the id into the title therefore gives us 100% accurate routing
# even when the bug fires, with no impact on visible rendering.
#
# Wire size: a 4-byte (8 hex char) request id compresses to 16 base-4
# zero-width characters trailing the visible label. ``"✓ Approve"`` plus
# the encoded id stays under ~60 UTF-8 bytes total.


def encode_request_id_in_title(title: str, request_id: str) -> str:
    """Append a zero-width base-4 encoding of ``request_id`` to ``title``.

    Only ``ApprovalRequest``'s canonical 8-char hex id shape is supported
    — those decode to 4 raw bytes, encoded as 16 zero-width characters
    (≈ 48 wire bytes). Non-canonical ids raise ``ValueError``: a single
    encoding shape keeps the inverse (``extract_request_id_from_text``)
    unambiguous and matches the only id form callers actually produce.

    The visible button label is unchanged — zero-width characters render
    at zero width — but if the Teams client forwards the title verbatim
    on click, the bot recovers the id via ``extract_request_id_from_text``.

    >>> t = encode_request_id_in_title("✓ Approve", "abcd1234")
    >>> sum(1 for c in t if c in _ZW_CHARS)
    16
    >>> extract_request_id_from_text(t)
    'abcd1234'
    """
    # Strict lowercase: ApprovalRequest.id is always lowercase hex
    # (`uuid.uuid4().hex[:8]`). Accepting uppercase here would silently
    # break round-trip — `bytes.hex()` always returns lowercase, so
    # `ABCDEF12` would extract back as `abcdef12` and miss the dict key.
    if len(request_id) != 8 or not all(c in "0123456789abcdef" for c in request_id):
        raise ValueError(
            f"request_id must be 8 lowercase hex chars "
            f"(canonical ApprovalRequest.id), got {request_id!r}"
        )
    out = [title]
    for byte in bytes.fromhex(request_id):
        # 4 base-4 digits per byte, MSB first.
        for shift in (6, 4, 2, 0):
            out.append(_ZW_CHARS[(byte >> shift) & 0b11])
    return "".join(out)


_BARE_APPROVAL_KEYWORDS: frozenset[str] = frozenset(
    {"yes", "y", "approve", "/approve", "no", "n", "deny", "/deny", "always", "a", "/always"}
)


def match_approval_prompt(prompt: str, pending_list: list[Any]) -> tuple[str, str] | None:
    """Decide whether ``prompt`` is an approval response and which one.

    Returns ``(action_verb, request_id)`` where ``action_verb`` is one of
    ``"approve"`` / ``"deny"`` / ``"always"``, or ``None`` if the prompt
    is regular conversation text.

    Routing tiers (first match wins):

    1. Bare keyword (``"yes"`` / ``"approve"`` / ``"✓ Approve"`` mobile
       chip-bug payload) **with** a recoverable ZW-encoded id in the
       prompt — exact id, regardless of pending count.
    2. Bare keyword **without** a ZW id — fall back to "single pending
       request" heuristic; ambiguous when ≥2 pending so we return None
       rather than guess.
    3. Slash form (``/approve <id>``) — id is explicit in the text.

    Centralised so the cloud channel, agent loop, and web server fast
    paths share the same routing contract — and so the contract can be
    unit-tested in isolation. Each call site still controls *what to do*
    with the returned tuple (emit event, route through manager, etc.).
    """
    recovered_id = extract_request_id_from_text(prompt)
    cl = normalize_approval_text(prompt)

    if cl in _BARE_APPROVAL_KEYWORDS:
        if cl in ("yes", "y", "approve", "/approve"):
            verb = "approve"
        elif cl in ("no", "n", "deny", "/deny"):
            verb = "deny"
        else:
            verb = "always"
        # Tier 1: precise ZW-id routing (works at any pending count).
        if recovered_id:
            return verb, recovered_id
        # Tier 2: typed bare keyword — only safe when exactly one pending.
        if len(pending_list) == 1:
            return verb, pending_list[0].id
        return None

    # Tier 3: slash form with explicit id. Verb is matched case-insensitively
    # so ``/Approve abc12345`` (mobile keyboard auto-capitalisation) still
    # resolves; the id portion is preserved verbatim because the dict lookup
    # against ``ApprovalManager._pending`` is case-sensitive (and the canonical
    # id is always lowercase hex anyway).
    parts = prompt.split(maxsplit=1)
    if len(parts) == 2:
        verb_token = parts[0].lower()
        if verb_token == "/approve":
            return "approve", parts[1]
        if verb_token == "/deny":
            return "deny", parts[1]
        if verb_token == "/always":
            return "always", parts[1]

    return None


def extract_request_id_from_text(text: str) -> str | None:
    """Decode an 8-char hex request id from a zero-width block in ``text``.

    The shared ``_ZW_ID_BLOCK`` regex requires a trailing run of exactly
    16 ZW chars (the canonical shape ``encode_request_id_in_title``
    produces); shorter / longer trailing runs match neither the regex
    here nor the stripping path in ``normalize_approval_text``, so a
    stray pasted ZWSP / BOM never accidentally triggers approval routing.

    >>> extract_request_id_from_text(encode_request_id_in_title("✓ Approve", "abcd1234"))
    'abcd1234'
    >>> extract_request_id_from_text("just a normal message") is None
    True
    """
    match = _ZW_ID_BLOCK.search(text)
    if not match:
        return None
    block = match.group(0)  # always 16 chars (regex enforces it)
    out = bytearray()
    for i in range(0, 16, 4):
        byte = 0
        for c in block[i : i + 4]:
            byte = (byte << 2) | _ZW_TO_DIGIT[c]
        out.append(byte)
    return out.hex()


# ── Helpers ────────────────────────────────────────────────────────────────────

# (max_score_inclusive, label, web_color, cli_ansi)
_RISK_LEVELS: list[tuple[int | None, str, str, str]] = [
    (2, "low", "#22c55e", "\033[32m"),
    (4, "medium", "#eab308", "\033[33m"),
    (6, "elevated", "#f59e0b", "\033[33m"),
    (8, "high", "#ef4444", "\033[31m"),
    (10, "critical", "#dc2626", "\033[35m"),
]
_UNKNOWN_LEVEL = ("unknown", "#a855f7", "\033[35m")


def risk_level(score: int | None) -> tuple[str, str, str]:
    """Map a numeric risk score to ``(label, web_color, cli_ansi)``.

    >>> risk_level(None)
    ('unknown', '#a855f7', '\\033[35m')
    >>> risk_level(3)[0]
    'medium'
    """
    if score is None:
        return _UNKNOWN_LEVEL
    for max_score, label, web_color, cli_ansi in _RISK_LEVELS:
        if max_score is not None and score <= max_score:
            return label, web_color, cli_ansi
    return _UNKNOWN_LEVEL  # out-of-range fallback


_PREVIEW_EXTRACTORS: dict[str, Any] = {
    "shell": lambda a: a.get("command", ""),
    "write_file": lambda a: f"Write \u2192 {a.get('path', '?')}",
    "edit_file": lambda a: f"Edit \u2192 {a.get('path', '?')}",
    "read_file": lambda a: f"Read \u2192 {a.get('path', '?')}",
    "http_request": lambda a: f"{a.get('method', 'GET')} {a.get('url', '?')}",
    "git": lambda a: f"git {a.get('subcommand', '')} {a.get('args', '')}".strip(),
    "web_search": lambda a: f"Search: {a.get('query', '?')}",
    "web_fetch": lambda a: f"Fetch: {a.get('url', '?')}",
    "spawn": lambda a: f"Spawn agent: {a.get('agent', a.get('agent_name', '?'))}",
}


# Keys likely to contain human-readable content (preferred for preview)
_PREVIEW_PREFERRED_KEYS = (
    "message",
    "content",
    "body",
    "text",
    "query",
    "prompt",
    "command",
    "url",
    "path",
)
# Keys likely to contain IDs (skip for preview)
_PREVIEW_SKIP_KEYS = (
    "id",
    "conversation_id",
    "conversationId",
    "channel_id",
    "thread_id",
    "session_id",
)


def action_preview(tool_name: str, args: dict[str, Any]) -> str:
    """Extract a human-readable action summary from *tool_name* and *args*.

    Returns a single line, max 120 chars, newlines replaced with spaces.
    """
    extractor = _PREVIEW_EXTRACTORS.get(tool_name)
    if extractor:
        raw = str(extractor(args))
    elif args:
        # Prefer meaningful keys (message, content, etc.) over IDs
        raw = ""
        for key in _PREVIEW_PREFERRED_KEYS:
            if key in args and args[key]:
                raw = str(args[key])
                break
        if not raw:
            # Fall back to first non-ID value
            for k, v in args.items():
                if k.lower() not in _PREVIEW_SKIP_KEYS and v:
                    raw = str(v)
                    break
        if not raw:
            raw = str(next(iter(args.values())))
    else:
        raw = tool_name
    raw = raw.replace("\n", " ").replace("\r", "")
    return raw[:120] + ("..." if len(raw) > 120 else "")


_TRIGGER_MAP: dict[str, tuple[str, str]] = {
    "cron": ("\U0001f4c5", "Scheduled"),  # 📅
    "heartbeat": ("\U0001f493", "Heartbeat"),  # 💓
    "subagent": ("\U0001f916", "Sub-agent"),  # 🤖
}


def trigger_context(metadata: dict[str, Any]) -> str:
    """Derive a trigger line (with emoji) from *metadata*.

    Returns an empty string for interactive sources.

    >>> trigger_context({"source": "cron", "job_name": "daily-cleanup"})
    '📅 Scheduled: daily-cleanup'
    >>> trigger_context({"source": "cloud_teams"})
    ''
    """
    source = metadata.get("source", "")
    entry = _TRIGGER_MAP.get(source)
    if not entry:
        return ""
    emoji, label = entry
    if source == "cron":
        job_name = metadata.get("job_name", "")
        return f"{emoji} {label}: {job_name}" if job_name else f"{emoji} {label}"
    if source == "subagent":
        agent = metadata.get("agent_name", "")
        return f"{emoji} {label}: {agent}" if agent else f"{emoji} {label}"
    return f"{emoji} {label}"


# ── Formatters ─────────────────────────────────────────────────────────────────


class ApprovalFormatter(ABC):
    """Abstract base for channel-specific approval formatters."""

    @abstractmethod
    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> str | dict[str, Any]:
        """Format an approval request for display.

        Parameters
        ----------
        request:
            The ``ApprovalRequest`` object.
        classify_result:
            The ``RiskScore`` from the Risk Scorer (has ``.score`` and ``.reason``).
        auto_timeout:
            Seconds until auto-approve (Timeout-auto action). ``None`` = not auto-approve.
        reject_timeout:
            Seconds until auto-reject (Human action). ``None`` = wait indefinitely.

        Returns
        -------
        str | dict
            Formatted content: plain text for CLI, dict for structured channels.
        """


class CLIApprovalFormatter(ApprovalFormatter):
    """Rich text prompt for CLI with risk-coloured header and action preview."""

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> str:
        score = classify_result.score
        level, _, cli_ansi = risk_level(score)
        reset = "\033[0m"
        bold = "\033[1m"

        score_str = f"{score} / 10" if score is not None else "? / 10"
        preview = action_preview(request.tool_name, request.args)
        trigger = getattr(request, "trigger", "")
        always_allow = getattr(request, "always_allow", True)

        args_lines = "\n".join(f"    {k} = {v!r}" for k, v in list(request.args.items())[:8])

        if auto_timeout is not None:
            timeout_line = f"  Proceeding in {auto_timeout}s unless you deny..."
        elif reject_timeout is not None:
            timeout_line = f"  Waiting for your decision ({reject_timeout}s remaining)"
        else:
            timeout_line = "  Waiting for your decision"

        always_hint = "  [a]lways" if always_allow else ""
        trigger_line = f"  {trigger}\n\n" if trigger else ""

        separator = "\u2500" * 62
        return (
            f"\n{bold}\u26a0  APPROVAL REQUIRED{reset}"
            f"                              {cli_ansi}{level.upper()} {score_str}{reset}\n"
            f"{separator}\n"
            f"  {bold}{preview}{reset}\n\n"
            f"  {classify_result.reason}\n\n"
            f"{trigger_line}"
            f"  Tool:    {request.tool_name}\n"
            f"  Agent:   {request.agent_name}\n"
            f"  Args:\n{args_lines}\n\n"
            f"{timeout_line}\n\n"
            f"  [y]es  [n]o{always_hint}  > "
        )


# ── Shared Adaptive Card builder ───────────────────────────────────────────────

_AC_COLORS: dict[str, str] = {
    "unknown": "Accent",
    "low": "Good",
    "medium": "Warning",
    "elevated": "Warning",
    "high": "Attention",
    "critical": "Attention",
}


_OUTCOME_LABELS: dict[str, str] = {
    "approved": "\u2705 Approved",
    "approved_always": "\u2705 Approved (Always)",
    "approved_timeout": "\u2705 Approved (Auto)",
    "denied": "\u274c Denied",
    "denied_timeout": "\u274c Denied (Timeout)",
    "timeout": "\u274c Denied (Timeout)",  # legacy alias
    "resolved": "\u2611 Resolved",
}
_OUTCOME_AC_COLORS: dict[str, str] = {
    "approved": "Good",
    "approved_always": "Good",
    "approved_timeout": "Good",
    "denied": "Attention",
    "denied_timeout": "Warning",
    "timeout": "Warning",  # legacy alias
    "resolved": "Default",
}


def build_resolved_card(
    *,
    tool_name: str,
    action_preview: str,
    score: float | int | None = None,
    outcome: str = "approved",
    agent_name: str = "",
    reason: str = "",
) -> dict[str, Any]:
    """Public helper — build a resolved Adaptive Card for cross-channel updates."""
    return _build_resolved_card(
        {
            "tool_name": tool_name,
            "action_preview": action_preview,
            "score": score,
            "agent_name": agent_name,
            "reason": reason,
        },
        outcome,
    )


def _build_resolved_card(fields: dict[str, Any], outcome: str) -> dict[str, Any]:
    """Build a resolved Adaptive Card — read-only, no actions.

    Single source of truth for resolved card structure.  Used by:
    - Python: embedded in Action.Submit data → Gateway uses directly
    - JS client: ``_buildResolvedCard()`` mirrors this structure
    """
    label = _OUTCOME_LABELS.get(outcome, _OUTCOME_LABELS["resolved"])
    color = _OUTCOME_AC_COLORS.get(outcome, "Default")
    score = fields.get("score")
    score_str = f"{score} / 10" if score is not None else "?"

    body: list[dict[str, Any]] = [
        # Outcome header — no risk badge (decision is done, risk level is noise)
        {
            "type": "TextBlock",
            "text": f"{label} \u00b7 {fields.get('tool_name', '')}",
            "weight": "Bolder",
            "color": color,
            "wrap": True,
        },
        {
            "type": "Container",
            "style": "emphasis",
            "spacing": "Small",
            "items": [
                {
                    "type": "TextBlock",
                    "text": fields.get("action_preview") or fields.get("tool_name", ""),
                    "fontType": "Monospace",
                    "wrap": True,
                }
            ],
        },
    ]

    reason = fields.get("reason")
    if reason:
        body.append(
            {
                "type": "TextBlock",
                "text": reason,
                "wrap": True,
                "spacing": "Small",
                "isSubtle": True,
            }
        )

    trigger = fields.get("trigger")
    if trigger:
        body.append(
            {
                "type": "TextBlock",
                "text": trigger,
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )

    body.append(
        {
            "type": "FactSet",
            "spacing": "Medium",
            "facts": [
                {"title": "Tool", "value": fields.get("tool_name", "")},
                {"title": "Agent", "value": fields.get("agent_name", "")},
                {"title": "Score", "value": score_str},
            ],
        }
    )

    return {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": body,
    }


def _build_card_fields(request: Any, classify_result: Any) -> dict[str, Any]:
    """Per-request metadata for the Adaptive Card's ``Action.Submit`` buttons.

    Used **only** by ``_build_adaptive_card`` to embed a pre-built
    ``resolved_card`` JSON under each button's ``data`` payload, so the
    Cloud Gateway can PUT the resolved card directly without rebuilding
    it. SuggestedActions chips do **not** use this — they are plain
    ``imBack`` actions whose ``value`` is the slash-command string only
    (no structured payload, see ``_build_suggested_actions``).

    Changing fields here will affect Adaptive Card buttons; chip routing
    is independent and travels via the slash form + the zero-width id
    encoding in the chip ``title``.
    """
    score = classify_result.score
    level, _, _ = risk_level(score)
    return {
        "tool_name": request.tool_name,
        "action_preview": action_preview(request.tool_name, request.args),
        "reason": classify_result.reason,
        "score": score,
        "risk_level": level,
        "agent_name": request.agent_name,
        "trigger": getattr(request, "trigger", ""),
    }


def _build_suggested_actions(request: Any) -> list[dict[str, Any]]:
    """Build Bot Framework ``imBack`` actions for SuggestedActions quick replies.

    **Hard platform constraint — `imBack` is mandatory.** See
    ``design/features/approval-ux.md §11.1``. Do not switch chip type
    without re-checking the Teams platform docs first.

    Chip title carries a zero-width base-4 encoding of ``request.id``
    appended to the visible label (``"✓ Approve"`` / ``"✗ Deny"``). The
    id encoding is empirically validated to round-trip through Teams
    mobile clients that exhibit the imBack title-as-value bug — when the
    client mistakenly delivers the title as ``Activity.Text``, the bot
    recovers the id via ``extract_request_id_from_text`` and resolves
    the approval exactly. On non-buggy clients the ``value`` field
    (slash form ``/<verb> <id>``) routes normally; the ZW characters
    don't affect display.
    """
    rid = request.id
    return [
        {
            "type": "imBack",
            "title": encode_request_id_in_title(action.title, rid),
            "value": f"/{action.verb} {rid}",
        }
        for action in _APPROVAL_BASE_ACTIONS
    ]


def _build_adaptive_card(
    request: Any,
    classify_result: Any,
    auto_timeout: int | None = None,
    reject_timeout: int | None = None,
) -> dict[str, Any]:
    """Build an Adaptive Card v1.4 content dict for an approval request.

    Used by all non-CLI formatters.  Teams wraps this in a Bot Framework
    Activity; Web UI / WebChat renders via the ``adaptivecards`` JS SDK.
    """
    score = classify_result.score
    level, _, _ = risk_level(score)
    ac_color = _AC_COLORS.get(level, "Default")
    preview = action_preview(request.tool_name, request.args)
    trigger = getattr(request, "trigger", "")
    always_allow = getattr(request, "always_allow", True)
    score_str = f"{score} / 10" if score is not None else "?"

    # ── Body ──────────────────────────────────────────────────────────
    body: list[dict[str, Any]] = [
        # Header: title + risk badge
        {
            "type": "ColumnSet",
            "columns": [
                {
                    "type": "Column",
                    "width": "stretch",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": "\u26a0 Approval Required",
                            "weight": "Bolder",
                            "size": "Medium",
                            "wrap": True,
                        }
                    ],
                },
                {
                    "type": "Column",
                    "width": "auto",
                    "verticalContentAlignment": "Center",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": level.upper(),
                            "weight": "Bolder",
                            "size": "Small",
                            "color": ac_color,
                        }
                    ],
                },
            ],
        },
        # Action preview
        {
            "type": "Container",
            "style": "emphasis",
            "spacing": "Small",
            "items": [
                {
                    "type": "TextBlock",
                    "text": preview,
                    "fontType": "Monospace",
                    "wrap": True,
                    "weight": "Bolder",
                }
            ],
        },
        # Risk explanation
        {
            "type": "TextBlock",
            "text": classify_result.reason,
            "wrap": True,
            "spacing": "Small",
        },
    ]

    if trigger:
        body.append(
            {
                "type": "TextBlock",
                "text": trigger,
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )

    body.append(
        {
            "type": "FactSet",
            "spacing": "Medium",
            "facts": [
                {"title": "Tool", "value": request.tool_name},
                {"title": "Agent", "value": request.agent_name},
                {"title": "Score", "value": score_str},
            ],
        }
    )

    if auto_timeout is not None:
        body.append(
            {
                "type": "TextBlock",
                "text": f"\u23f1 Proceeding in {auto_timeout}s unless you deny...",
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )
    elif reject_timeout is not None:
        body.append(
            {
                "type": "TextBlock",
                "text": f"\u23f1 Waiting for your decision ({reject_timeout}s remaining)",
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )

    body.append(
        {
            "type": "TextBlock",
            "text": "Or reply **yes** / **no** / **always**",
            "size": "Small",
            "isSubtle": True,
            "spacing": "None",
            "wrap": True,
        }
    )

    # ── Actions ───────────────────────────────────────────────────────
    # Each button carries a pre-built resolved card JSON so the Gateway
    # can PUT it directly without building its own card. Chips do NOT
    # share this payload — they are plain `imBack` actions (see
    # ``_build_suggested_actions`` / ``_build_card_fields`` docstrings).
    card_fields = _build_card_fields(request, classify_result)

    def _submit_data(action_label: str, outcome: str) -> dict[str, Any]:
        return {
            "approval_action": action_label,
            "approval_request_id": request.id,
            "resolved_card": _build_resolved_card(card_fields, outcome),
        }

    def _ac_submit(action: _ApprovalAction) -> dict[str, Any]:
        entry: dict[str, Any] = {
            "type": "Action.Submit",
            "title": action.title,
            "data": _submit_data(action.verb, action.ac_outcome),
        }
        if action.ac_style is not None:
            entry["style"] = action.ac_style
        return entry

    # Labels / verbs shared with `_build_suggested_actions` via
    # `_APPROVAL_BASE_ACTIONS` / `_APPROVAL_ALWAYS_ACTION`.
    actions: list[dict[str, Any]] = [_ac_submit(a) for a in _APPROVAL_BASE_ACTIONS]
    if always_allow:
        actions.append(_ac_submit(_APPROVAL_ALWAYS_ACTION))

    return {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": body,
        "actions": actions,
    }


# ── Formatters (non-CLI) ──────────────────────────────────────────────────────


class CloudApprovalFormatter(ApprovalFormatter):
    """Structured JSON for Web UI / WebChat clients.

    Includes an ``adaptive_card`` field containing the Adaptive Card v1.4
    content.  Web clients render this via the ``adaptivecards`` JS SDK.
    Flat fields (``tool_name``, ``score``, etc.) are kept for backward
    compatibility and session persistence.
    """

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> dict[str, Any]:
        score = classify_result.score
        level, web_color, _ = risk_level(score)
        args_summary = {k: str(v)[:200] for k, v in list(request.args.items())[:10]}
        return {
            "type": "approval_request",
            "request_id": request.id,
            "tool_name": request.tool_name,
            "action_preview": action_preview(request.tool_name, request.args),
            "risk_level": level,
            "risk_color": web_color,
            "args": args_summary,
            "score": score,
            "reason": classify_result.reason,
            "agent_name": request.agent_name,
            "trigger": getattr(request, "trigger", ""),
            "auto_timeout": auto_timeout,
            "reject_timeout": reject_timeout,
            "always_allow": getattr(request, "always_allow", True),
            "adaptive_card": _build_adaptive_card(
                request, classify_result, auto_timeout, reject_timeout
            ),
            "suggested_actions": _build_suggested_actions(request),
        }


class TeamsApprovalFormatter(ApprovalFormatter):
    """Bot Framework Activity with Adaptive Card for Teams.

    Produces a complete ``{"type": "message", "attachments": [...]}`` dict
    that the Cloud Gateway passes through unchanged via ``TryParseActivity``
    Case 1 (``type=message`` with ``attachments`` array).
    """

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> dict[str, Any]:
        card = _build_adaptive_card(request, classify_result, auto_timeout, reject_timeout)
        return {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": card,
                }
            ],
            "suggestedActions": {
                "actions": _build_suggested_actions(request),
            },
        }


def get_approval_formatter(
    channel_name: ChannelType,
    push_target: str | None = None,
) -> ApprovalFormatter:
    """Factory — return the appropriate formatter for a channel.

    Parameters
    ----------
    channel_name:
        The target channel type.
    push_target:
        For cloud channels, ``"teams"`` selects the Teams Activity formatter.
    """
    if channel_name == ChannelType.CLI:
        return CLIApprovalFormatter()
    if push_target == "teams":
        return TeamsApprovalFormatter()
    return CloudApprovalFormatter()
