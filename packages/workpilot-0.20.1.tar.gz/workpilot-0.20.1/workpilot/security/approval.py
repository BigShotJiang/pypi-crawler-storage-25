"""
Approval workflow — gates agent actions that require human confirmation.

When the PolicyEngine resolves an autonomy level of APPROVAL (level 1),
the agent creates an ApprovalRequest here.  The request stays pending
until a human resolves it (approve / deny) or the configured timeout
elapses.

In v0.2+ the manager supports async wait/resume: the agent loop blocks
on an asyncio.Event until a human responds via CLI prompt or Cloud/Web
channel command.
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any

from loguru import logger

from workpilot.config.schema import ApprovalConfig, AutonomyLevel, ChannelType


class ApprovalInterruptedError(Exception):
    """Raised when an interrupt event fires during approval wait."""


# ── Score-aware timeout helper ───────────────────────────────────────────────
# Shared by ApprovalGate (per-tool gating) and BridgeService (bridge toggle
# gate) — same score × profile math so both surfaces produce consistent UX.

_T_BASE: dict[int, int] = {1: 45, 2: 90, 3: 120, 4: 150, 5: 180, 6: 240, 7: 300, 8: 360}
_T_FACTOR: dict[str, float] = {"open": 0.75, "standard": 1.0, "controlled": 1.25, "restricted": 1.5}
_H_FACTOR: dict[str, float] = {"open": 1.5, "standard": 1.0, "controlled": 0.75, "restricted": 0.5}


def score_aware_timeout(
    score: int | None,
    is_auto_approve: bool,
    profile: str | Any = "standard",
) -> int | None:
    """Compute score × profile aware timeout.

    Timeout-auto (auto-approve): higher score → longer timeout (more intervention time).
    Human (reject): higher score → shorter timeout (reject dangerous ops faster).
    Null score → None (wait forever for human decision).

    Returns timeout in seconds, or None for infinite wait.

    ``profile`` accepts a ``SecurityProfile`` enum (uses ``.value``) or the
    raw string key; the enum form prevents silent fallback-to-1.0 when the
    caller passes the enum without normalising.
    """
    if score is None:
        return None

    profile_key = profile.value if hasattr(profile, "value") else str(profile)

    if is_auto_approve:
        base = _T_BASE.get(score, 180)
        factor = _T_FACTOR.get(profile_key, 1.0)
        raw = base * factor
    else:
        factor = _H_FACTOR.get(profile_key, 1.0)
        raw = (10 - score) * 60 * factor

    clamped = max(30, min(600, raw))
    return round(clamped / 30) * 30


# ── Data model ──────────────────────────────────────────────────────────────


class ApprovalStatus(str, Enum):
    """Lifecycle states for an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"  # deprecated: use APPROVED or DENIED with resolver="auto-*-timeout"


@dataclass
class ApprovalRequest:
    """A single pending-approval record.

    Attributes
    ----------
    id:
        Unique request identifier — 8-char lowercase hex
        (``uuid.uuid4().hex[:8]``, 32 random bits). Short enough to keep
        slash commands readable and the chip-title zero-width id
        encoding small (16 base-4 ZW chars). See
        ``approval_format.encode_request_id_in_title``.
    tool_name:
        The tool that triggered the approval requirement.
    args:
        The arguments the tool would be called with.
    agent_name:
        The agent that requested the action.
    autonomy_level:
        The resolved autonomy level at creation time.
    channel:
        Channel through which the approval was requested.
    status:
        Current lifecycle state.
    created_at:
        UTC timestamp of request creation.
    resolved_at:
        UTC timestamp of resolution, or ``None`` if still pending.
    resolver:
        Identity of the human who resolved the request, or ``None``.
    """

    # 8-char hex (4 random bytes, 32-bit space). Short enough to keep slash
    # commands readable and zero-width chip-title encodings small (16 base-4
    # ZW chars). Collision risk is negligible — a single ApprovalManager
    # rarely has more than ~10 pending requests at once.
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    tool_name: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    agent_name: str = ""
    autonomy_level: AutonomyLevel = AutonomyLevel.APPROVAL
    channel: ChannelType = ChannelType.CLI
    channel_id: str = ""
    score: int | None = None  # v2: risk score 0-10 or None
    reason: str = ""
    always_allow: bool = True  # whether "Always Allow" is available (from policy table)
    trigger: str = ""  # e.g. "📅 Scheduled: daily-cleanup", "" for interactive
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
    resolver: str | None = None
    action: str = ""  # "approve", "deny", "always" — set on resolution
    teams_activity_id: str | None = None  # Teams card ActivityId for cross-channel updates


# ── Manager ─────────────────────────────────────────────────────────────────


class ApprovalManager:
    """Manages the lifecycle of approval requests.

    Parameters
    ----------
    config:
        Approval workflow settings (timeout, escalation channels, etc.).
    """

    def __init__(self, config: ApprovalConfig) -> None:
        self._config = config
        self._pending: dict[str, ApprovalRequest] = {}
        self._waiters: dict[str, asyncio.Event] = {}
        self._resolved: dict[str, ApprovalRequest] = {}
        # Session-scoped Always-Allow cache — keyed (canonical_session_id, tool_name).
        # In-memory only; cleared on runtime exit. Used by bridge mode (design
        # spec §6.1) and available to any caller that wants (session, tool)
        # scoping. Distinct from the per-request ``ApprovalRequest.always_allow``
        # bool, which only says whether the "always" button is shown.
        self._always_allow: dict[tuple[str, str], bool] = {}
        logger.debug(
            "ApprovalManager initialised — timeout={}s, auto_approve={}s, escalation={}",
            config.timeout_seconds,
            config.auto_approve_timeout,
            config.escalation_channels,
        )

    # ── Always-Allow cache ──────────────────────────────────────────────

    def is_always_allowed(self, session_id: str, tool_name: str) -> bool:
        """True if the user previously picked 'always' for this (session, tool)."""
        return self._always_allow.get((session_id, tool_name), False)

    def record_always_allow(self, session_id: str, tool_name: str) -> None:
        """Remember an 'always' choice for this (session, tool)."""
        self._always_allow[(session_id, tool_name)] = True
        logger.info("Always-allow recorded: session={} tool={}", session_id, tool_name)

    def clear_always_allow(self, session_id: str, tool_name: str | None = None) -> None:
        """Drop an Always-Allow entry.

        When ``tool_name`` is None, clears every tool for this session.
        """
        if tool_name is not None:
            self._always_allow.pop((session_id, tool_name), None)
            return
        to_drop = [key for key in self._always_allow if key[0] == session_id]
        for key in to_drop:
            del self._always_allow[key]

    # ── Cleanup ───────────────────────────────────────────────────────

    def _cleanup_stale_resolved(self) -> None:
        """Remove resolved entries older than 60 seconds."""
        cutoff = datetime.now(UTC) - timedelta(seconds=60)
        stale = [
            rid
            for rid, req in self._resolved.items()
            if req.resolved_at and req.resolved_at < cutoff
        ]
        for rid in stale:
            del self._resolved[rid]

    # ── Create request ──────────────────────────────────────────────────

    async def request_approval(
        self,
        tool_name: str,
        args: dict[str, Any],
        agent_name: str,
        channel: ChannelType | None,
        channel_id: str = "",
        score: int | None = None,
        reason: str = "",
        always_allow: bool = True,
        trigger: str = "",
    ) -> ApprovalRequest:
        """Create an approval request and register it as pending.

        Parameters
        ----------
        tool_name:
            The tool requiring approval.
        args:
            Proposed tool call arguments.
        agent_name:
            Agent identity requesting the action.
        channel:
            Channel the approval prompt should be sent through.

        Returns
        -------
        ApprovalRequest
            The newly created (PENDING) request.
        """
        self._cleanup_stale_resolved()

        request = ApprovalRequest(
            tool_name=tool_name,
            args=args,
            agent_name=agent_name,
            autonomy_level=AutonomyLevel.APPROVAL,
            channel=ChannelType.of(channel, self._config.default_channel),
            channel_id=channel_id,
            score=score,
            reason=reason,
            always_allow=always_allow,
            trigger=trigger,
        )
        # 8-char hex (32-bit) ids carry a small but non-zero birthday-paradox
        # collision risk under heavy concurrency. Retry id generation if a
        # pending request already holds the same id, so a fresh request never
        # silently overwrites an in-flight one.
        for _ in range(8):
            if request.id not in self._pending and request.id not in self._resolved:
                break
            request.id = uuid.uuid4().hex[:8]
        else:
            # 8-in-a-row collisions ≈ 10⁻⁷⁰ in real conditions; this branch
            # exists only to avoid the silent-overwrite footgun if a stubbed
            # uuid source is ever forced into the loop.
            raise RuntimeError(
                f"Could not allocate unique approval id after 8 attempts "
                f"(pending={len(self._pending)}, resolved={len(self._resolved)})"
            )
        self._pending[request.id] = request
        self._waiters[request.id] = asyncio.Event()
        logger.info(
            "Approval requested: id={} tool={} agent={} channel={}",
            request.id,
            tool_name,
            agent_name,
            channel,
        )
        return request

    # ── Resolve ─────────────────────────────────────────────────────────

    def resolve(self, request_id: str, approved: bool, resolver: str, *, action: str = "") -> None:
        """Resolve a pending request.

        Parameters
        ----------
        request_id:
            The 8-char hex id of the request to resolve.
        approved:
            ``True`` to approve, ``False`` to deny.
        resolver:
            Identity of the human resolving the request.
        action:
            Original action verb ("approve", "deny", "always").

        Raises
        ------
        KeyError
            If ``request_id`` is not found among pending requests.
        ValueError
            If the request has already been resolved.
        """
        if request_id not in self._pending:
            raise KeyError(f"Approval request not found: {request_id}")

        request = self._pending[request_id]
        if request.status != ApprovalStatus.PENDING:
            raise ValueError(f"Request {request_id} already resolved as {request.status.value}")

        request.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.DENIED
        request.resolved_at = datetime.now(UTC)
        request.resolver = resolver
        request.action = action or ("approve" if approved else "deny")

        logger.info(
            "Approval resolved: id={} status={} resolver={}",
            request_id,
            request.status.value,
            resolver,
        )

        # Move to resolved dict and signal the waiter
        del self._pending[request_id]
        self._resolved[request_id] = request
        waiter = self._waiters.pop(request_id, None)
        if waiter:
            waiter.set()

    # ── Async wait/resume ───────────────────────────────────────────────

    async def wait_for_resolution(
        self,
        request_id: str,
        auto_approve_timeout: int | None = None,
        reject_timeout: int | None = None,
        interrupt_event: asyncio.Event | None = None,
    ) -> ApprovalRequest:
        """Block until the request is resolved or times out.

        Parameters
        ----------
        request_id:
            The 8-char hex id of the pending request.
        auto_approve_timeout:
            If set (Timeout-auto policy action), auto-approve after this
            many seconds.  ``None`` means this is not a Timeout-auto action.
        reject_timeout:
            If set (Human policy action), reject after this many seconds.
            ``None`` means wait indefinitely (null score — always wait for human).
        interrupt_event:
            If set, race against this event.  When the interrupt fires first,
            the request is denied as "cancelled".

        Returns
        -------
        ApprovalRequest
            The resolved request (status is APPROVED, DENIED, or TIMEOUT).
        """
        waiter = self._waiters.get(request_id)
        if waiter is None:
            # Already resolved (e.g. by CLI inline prompt)
            resolved = self._resolved.pop(request_id, None)
            if resolved:
                return resolved
            raise KeyError(f"No waiter for request {request_id}")

        if auto_approve_timeout is not None:
            timeout: float | None = auto_approve_timeout
        elif reject_timeout is not None:
            timeout = reject_timeout
        else:
            timeout = None  # wait forever (null score)

        try:
            if interrupt_event is not None:
                await self._wait_with_interrupt(waiter, timeout, interrupt_event)
            else:
                await asyncio.wait_for(waiter.wait(), timeout=timeout)
        except ApprovalInterruptedError:
            # /cancel fired while waiting for approval — deny as cancelled
            request = self._pending.pop(request_id, None)
            self._waiters.pop(request_id, None)
            if request is None:
                resolved = self._resolved.pop(request_id, None)
                if resolved:
                    return resolved
                raise KeyError(f"Request {request_id} vanished during interrupt")
            request.status = ApprovalStatus.DENIED
            request.resolved_at = datetime.now(UTC)
            request.resolver = "user-cancel"
            request.action = "deny"
            self._resolved[request_id] = request
            logger.info(
                "Approval cancelled by /cancel: id={} tool={}", request_id, request.tool_name
            )
            return request
        except TimeoutError:
            # Timeout — auto-approve for Timeout-auto, reject for Human
            request = self._pending.pop(request_id, None)
            self._waiters.pop(request_id, None)
            if request is None:
                # Race: resolved between wait and timeout
                resolved = self._resolved.pop(request_id, None)
                if resolved:
                    return resolved
                raise KeyError(f"Request {request_id} vanished during timeout")

            if auto_approve_timeout is not None:
                # Timeout-auto: auto-approve on timeout
                request.status = ApprovalStatus.APPROVED
                request.resolver = "auto-approve-timeout"
                request.action = "approve"
                logger.info(
                    "Approval auto-approved on timeout: id={} tool={}",
                    request_id,
                    request.tool_name,
                )
            else:
                # Human: reject on timeout
                request.status = ApprovalStatus.DENIED
                request.resolver = "auto-deny-timeout"
                request.action = "deny"
                logger.warning(
                    "Approval timed out (rejected): id={} tool={}",
                    request_id,
                    request.tool_name,
                )
            request.resolved_at = datetime.now(UTC)
            self._resolved[request_id] = request
            return request

        # Resolved by human — pick up the result
        resolved = self._resolved.pop(request_id, None)
        self._waiters.pop(request_id, None)
        if resolved:
            return resolved
        raise KeyError(f"Resolved request {request_id} not found in results")

    # ── Partial wait (for escalation) ────────────────────────────────

    async def wait_partial(
        self,
        request_id: str,
        timeout: float,
        interrupt_event: asyncio.Event | None = None,
    ) -> bool:
        """Wait up to *timeout* seconds for resolution without auto-resolving.

        Returns ``True`` if the request was resolved within the window,
        ``False`` if the timeout elapsed while still PENDING.  Unlike
        :meth:`wait_for_resolution`, this does **not** auto-approve or reject
        on timeout — the caller decides what to do next.

        Raises ``ApprovalInterruptedError`` if *interrupt_event* fires first.
        """
        waiter = self._waiters.get(request_id)
        if waiter is None:
            # Already resolved (e.g. by CLI inline prompt) or unknown
            return request_id in self._resolved
        try:
            if interrupt_event is not None:
                await self._wait_with_interrupt(waiter, timeout, interrupt_event)
            else:
                await asyncio.wait_for(waiter.wait(), timeout=timeout)
            return True
        except ApprovalInterruptedError:
            # Clean up pending state before propagating — same as wait_for_resolution
            request = self._pending.pop(request_id, None)
            self._waiters.pop(request_id, None)
            if request is not None:
                request.status = ApprovalStatus.DENIED
                request.resolved_at = datetime.now(UTC)
                request.resolver = "user-cancel"
                request.action = "deny"
                self._resolved[request_id] = request
            raise
        except TimeoutError:
            return False

    @staticmethod
    async def _wait_with_interrupt(
        waiter: asyncio.Event,
        timeout: float | None,
        interrupt: asyncio.Event,
    ) -> None:
        """Wait for *waiter* OR *interrupt*, whichever fires first.

        Raises ``ApprovalInterruptedError`` if the interrupt fires first.
        Raises ``TimeoutError`` if *timeout* elapses.
        """
        waiter_task = asyncio.create_task(waiter.wait())
        interrupt_task = asyncio.create_task(interrupt.wait())
        try:
            done, _pending = await asyncio.wait(
                {waiter_task, interrupt_task},
                timeout=timeout,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if not done:
                raise TimeoutError
            if interrupt_task in done and waiter_task not in done:
                raise ApprovalInterruptedError
            # waiter resolved (approval arrived) — success
        finally:
            waiter_task.cancel()
            interrupt_task.cancel()
            await asyncio.gather(waiter_task, interrupt_task, return_exceptions=True)

    def is_pending(self, request_id: str) -> bool:
        """Return ``True`` if *request_id* is still awaiting resolution."""
        return request_id in self._pending

    @property
    def escalation_channels(self) -> list[ChannelType]:
        """Static fallback channels from ``ApprovalConfig``."""
        return self._config.escalation_channels

    # ── Queries ─────────────────────────────────────────────────────────

    def get_request(self, request_id: str) -> ApprovalRequest | None:
        """Get a request by ID from pending or resolved."""
        return self._pending.get(request_id) or self._resolved.get(request_id)

    def get_pending(self) -> list[ApprovalRequest]:
        """Return all currently pending approval requests.

        Requests that have timed out are automatically marked before
        being filtered out.
        """
        # Sweep timeouts first
        for req_id in list(self._pending):
            self.check_timeout(req_id)

        return [req for req in self._pending.values() if req.status == ApprovalStatus.PENDING]

    def check_timeout(self, request_id: str) -> bool:
        """Check whether a pending request has exceeded its timeout.

        If timed out the request's status is updated to ``DENIED`` and
        it is removed from the pending map.

        Parameters
        ----------
        request_id:
            The 8-char hex id of the request to check.

        Returns
        -------
        bool
            ``True`` if the request has timed out, ``False`` otherwise.
            Also returns ``False`` if the request is not found.
        """
        request = self._pending.get(request_id)
        if request is None:
            return False

        elapsed = (datetime.now(UTC) - request.created_at).total_seconds()
        if elapsed >= self._config.timeout_seconds:
            request.status = ApprovalStatus.DENIED
            request.resolver = "auto-deny-timeout"
            request.action = "deny"
            request.resolved_at = datetime.now(UTC)
            del self._pending[request_id]
            self._resolved[request_id] = request
            # Signal any waiter so wait_for_resolution unblocks
            waiter = self._waiters.pop(request_id, None)
            if waiter:
                waiter.set()
            logger.warning(
                "Approval request timed out: id={} tool={} elapsed={:.0f}s",
                request_id,
                request.tool_name,
                elapsed,
            )
            return True

        return False
