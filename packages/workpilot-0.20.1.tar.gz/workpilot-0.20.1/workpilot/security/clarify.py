"""
Clarify workflow — agent-initiated mid-task question.

See ``design/features/tool-clarify.md`` for the full design spec.

The agent's ``ClarifyTool.execute()`` registers a pending request here,
publishes the question to the bound channel, then ``await``s on
``wait_for_resolution`` until the user answers or the timeout elapses.
The resolved result becomes the tool's ``function_call_output`` — the
synchronous-await pattern from ``security/approval.py`` lifted into
the tool body.

Design constraints honoured here:

* **One pending per session** — registering a second request for the same
  ``session_id`` raises ``ConcurrentClarifyError``. The tool catches it
  and returns an ``outcome="error"`` ClarifyResult (with the reason in
  the ``error`` field) to the LLM in that case.
* **Timeout echoes the committed per-question ``default``** into
  ``answers`` (wrapped in a list for ``multi_select`` questions). The
  echoed value may be null/omitted when the LLM committed no default,
  in which case the LLM still owns the recovery decision.
* **No tool-level cancel outcome** — ``/cancel`` and E-stop are
  user-halt signals at the agent-loop level. From the LLM-dispatch
  perspective they share semantics with "tool refused": no useful
  answer was obtained, the LLM should not consume ``answers``, it
  should read the ``error`` field for context. So they map to
  ``outcome="error"`` (with a "user halted" reason in the field
  text), folded in alongside tool-refusal errors rather than getting
  a dedicated outcome. Folding them into ``timeout`` would be wrong
  — ``timeout`` echoes the LLM's committed ``default``, which would
  falsely imply the user implicitly accepted that default when in
  fact they explicitly rejected the question.

  ``wait_for_resolution`` accepts an optional ``interrupt_event``;
  when set and signalled it raises ``ClarifyInterruptedError``
  (NOT ``TimeoutError``) so ``ClarifyTool.execute`` can package an
  ``outcome="error"`` result. The PR-1 foundation slice does not
  yet plumb the per-session interrupt event from registry → tool
  kwargs → here; that's a PR-2 task (design §15). Until then,
  ``/cancel`` waits for the natural ``timeout`` (which echoes the
  default — slightly misleading, but recoverable on the LLM's
  next turn after agent halt).
* **Resolved entries kept 60 s** for stamped late arrivals (mirrors
  ``ApprovalManager._cleanup_stale_resolved``).
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

if TYPE_CHECKING:
    from workpilot.agent.tools.clarify import ClarifyQuestion


class ConcurrentClarifyError(Exception):
    """Raised when a second clarify is registered for a session that
    already has one pending. ``ClarifyTool.execute`` catches it and
    returns an ``outcome="error"`` ClarifyResult to the LLM, with the
    exception message in the ``error`` field (§8.1)."""


class ClarifyInterruptedError(Exception):
    """Raised when ``wait_for_resolution``'s ``interrupt_event`` fires
    before the user answers. ``ClarifyTool.execute`` catches it and
    returns an ``outcome="error"`` ClarifyResult with a "user halted"
    reason, distinguishing user-driven halt (``/cancel``, E-stop) from
    natural ``timeout`` (no response) and from tool refusal (invalid
    args, missing context, etc.). All three share the ``error`` outcome
    because LLM dispatch is the same — don't trust empty ``answers``,
    read the ``error`` field for context — but the field text tells
    audit / debugging which path fired."""


# ── Data model ──────────────────────────────────────────────────────────────


ClarifyOutcome = Literal["answered_card", "answered_chat", "free_chat", "timeout", "error"]


def _validate_answer_shape(
    question: ClarifyQuestion,
    value: Any,
    outcome: ClarifyOutcome,
) -> str | None:
    """Validate a stamped wire payload against the pending question's
    contract. Returns an error string if the shape is wrong, ``None`` if OK.

    Per-question validation, not per-batch. The user submits one card
    with one Send action, but each field's shape is determined by its
    own render: a multi_select option question always yields a list of
    labels when the user clicks checkboxes (regardless of whether other
    questions in the batch were typed), and a free-text input always
    yields a scalar string. The batch-level ``outcome`` only tightens
    label-membership checks for the structured-click path.

    Rules:
    - multi_select option question:
      - ``list[str]`` → values from the option label set under
        ``answered_card`` (click path); any strings under
        ``answered_chat`` (mixed batch where other Qs were typed).
      - ``str`` → only valid under ``answered_chat`` (user typed in
        the card input on this Q instead of checking boxes).
        ``answered_card`` requires the click-shape list.
    - single-select option question:
      - ``str`` → in label set under ``answered_card``; any string
        under ``answered_chat``.
    - free-text question (no options):
      - ``str`` → any text.
    """
    if question.multi_select:
        if isinstance(value, list):
            if not all(isinstance(v, str) for v in value):
                return f"list answer must contain only strings, got {value!r}"
            if outcome == "answered_card":
                labels = {opt.label for opt in question.options}
                invalid = [v for v in value if v not in labels]
                if invalid:
                    return (
                        f"answered_card list contains non-label values "
                        f"{invalid!r}; expected from {sorted(labels)}"
                    )
            return None
        if isinstance(value, str):
            if outcome == "answered_card":
                return (
                    "answered_card multi_select requires a list (clicks produce "
                    "label list); got scalar string. A scalar reply is only "
                    "valid under answered_chat."
                )
            return None  # answered_chat scalar — typed instead of clicking
        return f"unexpected answer type {type(value).__name__}"
    # single-select question (option Q with multi_select=False) or free-text Q
    if not isinstance(value, str):
        return f"question {question.question!r} requires scalar string, got {type(value).__name__}"
    if outcome == "answered_card":
        if not question.options:
            # ``answered_card`` is impossible for free-text Q (no buttons
            # to click). Inference layer is meant to map this to
            # ``answered_chat`` upstream; this is a defensive guard.
            return (
                f"answered_card outcome requires non-empty options on "
                f"question {question.question!r} (got free-text question)"
            )
        labels = {opt.label for opt in question.options}
        if value not in labels:
            return f"answered_card scalar {value!r} not in option labels {sorted(labels)}"
    return None


def _validate_resolve_invariants(
    outcome: ClarifyOutcome,
    answers: Any,
    question_count: int,
) -> None:
    """Enforce the outcome→answers contract documented on
    ``ClarifyManager.resolve``. Raises ``ValueError`` for any violation.

    Defense-in-depth: callers within this module are correct, but a future
    router/channel integration calling ``resolve`` directly with the wrong
    shape would otherwise emit malformed results to the LLM.
    """
    if outcome == "error":
        # ``error`` outcomes are in practice constructed by the tool
        # body's ``_error_result_json`` early-return path (no
        # manager-side resolve() call goes through here for errors),
        # but the ``ClarifyOutcome`` Literal includes it — accept
        # rather than special-case the API surface.
        # ``ClarifyResult._error_matches_outcome`` is the downstream
        # guard that requires a non-empty ``error`` field for
        # ``outcome="error"``, so a malformed manager-side error call
        # would still fail at result construction.
        if answers is not None:
            raise ValueError(
                f"clarify resolve: outcome={outcome!r} must have answers=None, "
                f"got {type(answers).__name__}"
            )
        return
    if outcome == "free_chat":
        if question_count != 1:
            raise ValueError(
                f"clarify resolve: free_chat requires exactly 1 question, got {question_count}"
            )
        if not isinstance(answers, str):
            raise ValueError("clarify resolve: free_chat answers must be a non-null scalar string")
        return
    # answered_card / answered_chat / timeout
    if outcome == "timeout":
        # Timeout's top-level None is legal ONLY for single-Q with a
        # null/omitted default. Multi-Q timeouts must always preserve
        # all question keys via a dict (per-Q values may be None where
        # individual defaults are null/omitted).
        if answers is None:
            if question_count == 1:
                return
            raise ValueError(
                f"clarify resolve: outcome='timeout' for {question_count} "
                f"questions must use a dict (with all question keys), not None"
            )
    elif answers is None:
        raise ValueError(f"clarify resolve: outcome={outcome!r} requires non-null answers")
    if question_count == 1 and isinstance(answers, dict):
        raise ValueError(
            f"clarify resolve: outcome={outcome!r} for a single question "
            f"must use scalar/list answers, not a dict"
        )
    if question_count > 1 and not isinstance(answers, dict):
        raise ValueError(
            f"clarify resolve: outcome={outcome!r} for {question_count} questions "
            f"must use a dict, got {type(answers).__name__}"
        )


@dataclass
class ClarifyRequest:
    """A single pending clarify-request record (one per session)."""

    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    session_id: str = ""
    channel: str = ""
    channel_id: str = ""
    questions: list[ClarifyQuestion] = field(default_factory=list)
    timeout: int = 300
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
    teams_activity_id: str | None = None  # for in-place card update on resolve
    # Resolution payload — populated by ``resolve``:
    outcome: ClarifyOutcome | None = None
    # Polymorphic answers — see ClarifyResult.answers in tools/clarify.py
    # for the full shape contract. Single-Q stores answer as scalar;
    # multi-Q as dict (every question key preserved, individual values
    # may be ``None`` when that question's default is null/omitted).
    # ``timeout`` carries echoed per-question defaults in the same
    # scalar/list/dict shape. Top-level ``None`` is reserved for the
    # ``error`` outcome and the single-Q timeout case with a
    # null/omitted default; the tool's ``exclude_none`` serialisation
    # drops only that top-level None (Pydantic v2 keeps dict-internal
    # None values intact, so multi-Q timeout dicts retain all keys).
    answers: str | list[str] | dict[str, str | list[str] | None] | None = None


# ── Manager ─────────────────────────────────────────────────────────────────


class ClarifyManager:
    """Manages the lifecycle of clarify requests.

    Mirrors ``security/approval.py:ApprovalManager`` — same waiter +
    interrupt + 60 s resolved-cache pattern, adapted for the per-session
    one-pending-at-a-time invariant.
    """

    def __init__(self) -> None:
        # session_id -> request (one pending per session, §8.1)
        self._pending: dict[str, ClarifyRequest] = {}
        # clarify_id -> session_id (secondary index for stamped routing)
        self._request_by_id: dict[str, str] = {}
        # session_id -> waiter event (signalled when resolved)
        self._waiters: dict[str, asyncio.Event] = {}
        # clarify_id -> request (60 s TTL)
        self._resolved: dict[str, ClarifyRequest] = {}
        logger.debug("ClarifyManager initialised")

    # ── Cleanup ───────────────────────────────────────────────────────

    def _cleanup_stale_resolved(self) -> None:
        """Remove resolved entries older than 60 seconds (mirrors approval)."""
        cutoff = datetime.now(UTC) - timedelta(seconds=60)
        stale = [
            cid
            for cid, req in self._resolved.items()
            if req.resolved_at and req.resolved_at < cutoff
        ]
        for cid in stale:
            del self._resolved[cid]

    # ── Register ─────────────────────────────────────────────────────

    def register(
        self,
        session_id: str,
        questions: list[ClarifyQuestion],
        timeout: int,
        channel: str = "",
        channel_id: str = "",
    ) -> ClarifyRequest:
        """Create a pending clarify request for a session.

        ``timeout`` is in seconds.

        Raises ``ConcurrentClarifyError`` if the session already has one
        pending (§8.1 — one-clarify-per-session invariant).
        """
        self._cleanup_stale_resolved()

        if session_id in self._pending:
            existing = self._pending[session_id]
            # Diagnostic detail (session_id, clarify id, age) goes to logs
            # only — the exception message is propagated to the LLM via
            # ClarifyTool's early-return path, where leaking internal IDs
            # would expose user/session details into model-visible context.
            logger.warning(
                "Concurrent clarify rejected: session={} existing_id={} age={:.0f}s",
                session_id,
                existing.id,
                (datetime.now(UTC) - existing.created_at).total_seconds(),
            )
            raise ConcurrentClarifyError("another clarify is already pending for this session")

        request = ClarifyRequest(
            session_id=session_id,
            channel=channel,
            channel_id=channel_id,
            questions=list(questions),
            timeout=timeout,
        )
        self._pending[session_id] = request
        self._request_by_id[request.id] = session_id
        self._waiters[session_id] = asyncio.Event()
        logger.info(
            "Clarify registered: id={} session={} questions={} timeout={}s",
            request.id,
            session_id,
            len(questions),
            timeout,
        )
        return request

    # ── Lookup ───────────────────────────────────────────────────────

    def discard_pending(self, session_id: str) -> None:
        """Drop a pending request without resolving it. Used by the tool
        body when it must abort before the waiter starts (e.g. outbound
        publish failed — no point waiting for an answer to a question
        the user never saw). No waiter signal: the wait_for_resolution
        call hasn't started yet, so there's nothing listening.
        """
        request = self._pending.pop(session_id, None)
        if request is not None:
            self._request_by_id.pop(request.id, None)
        self._waiters.pop(session_id, None)

    def get_pending_by_session(self, session_id: str) -> ClarifyRequest | None:
        return self._pending.get(session_id)

    def get_pending_by_id(self, clarify_id: str) -> ClarifyRequest | None:
        sid = self._request_by_id.get(clarify_id)
        if sid is None:
            return None
        return self._pending.get(sid)

    # ── Resolve ──────────────────────────────────────────────────────

    def resolve(
        self,
        session_id: str,
        outcome: ClarifyOutcome,
        *,
        answers: str | list[str] | dict[str, str | list[str] | None] | None = None,
        teams_activity_id: str | None = None,
    ) -> None:
        """Resolve a pending clarify request and signal its waiter.

        ``outcome`` is the resolution discriminator:
        - ``answered_card`` — user clicked an option button on the card.
        - ``answered_chat`` — user typed in the card's free-text input.
        - ``free_chat`` — user typed in the chat input bar (off-card).
        - ``timeout`` — no response within the deadline; per-question
          defaults are echoed.
        - ``error`` — the ``ClarifyOutcome`` Literal includes this for
          API symmetry, but in practice ``ClarifyTool.execute`` constructs
          error results via ``_error_result_json`` (invalid args, missing
          context, concurrent rejection, internal waiter error) rather
          than calling ``resolve()``.

        ``answers`` is polymorphic; the shape depends on outcome × input
        path × multi_select:
        - 1Q ``answered_card`` → scalar string (option label), or
          ``list[str]`` for multi_select (multiple labels chosen).
        - 1Q ``answered_chat`` → scalar string (typed text in the card
          input — always scalar regardless of multi_select; the input
          field is a single field).
        - 1Q ``free_chat`` → scalar string (typed off-card; always 1Q).
        - NQ ``answered_card`` → ``dict[Q, scalar | list[str]]`` per
          question's own multi_select.
        - NQ ``answered_chat`` → ``dict[Q, str]`` (chat replies are
          always scalar strings).
        - ``timeout`` → echoed per-question default(s) using the
          ``answered_card`` shape rule (scalar, or list for multi_select);
          dict for multi-question; dict values may be ``None`` where a
          question's default is null/omitted.
        - ``error`` → ``None``.

        Raises ``ValueError`` when ``outcome`` and ``answers`` violate the
        **structural** contract enforced here (e.g. ``answered_card``
        with ``answers=None``, a multi-question outcome resolved with
        a scalar payload instead of a dict, or ``error`` carrying any
        non-None answers). The check is deliberately coarse — it
        guards shape/nullability before router payloads reach the
        LLM, but does NOT recurse into per-element type validation.
        Stamped-path callers (``resolve_from_stamp``) get deeper
        checks via ``_validate_answer_shape``; internal callers
        (manager timeout branch) are trusted by construction.
        """
        # Validate BEFORE mutating state. If validation raises, the
        # pending request stays in ``_pending`` and the waiter still
        # owns the slot — caller can retry with a corrected payload, or
        # the timeout path eventually fires. Popping first would strand
        # the request (nothing left to time out, no waiter signal).
        request = self._pending.get(session_id)
        if request is None:
            raise KeyError(f"No pending clarify for session {session_id}")

        _validate_resolve_invariants(outcome, answers, len(request.questions))

        del self._pending[session_id]
        request.outcome = outcome
        request.answers = answers
        if teams_activity_id is not None:
            request.teams_activity_id = teams_activity_id
        request.resolved_at = datetime.now(UTC)

        self._request_by_id.pop(request.id, None)
        self._resolved[request.id] = request

        waiter = self._waiters.pop(session_id, None)
        if waiter is not None:
            waiter.set()

        logger.info(
            "Clarify resolved: id={} session={} outcome={}",
            request.id,
            session_id,
            outcome,
        )

    # ── Async wait/resume ───────────────────────────────────────────

    async def wait_for_resolution(
        self,
        session_id: str,
        timeout: int,
        interrupt_event: asyncio.Event | None = None,
    ) -> ClarifyRequest:
        """Block until the pending clarify for *session_id* is resolved,
        the *interrupt_event* fires, or *timeout* seconds elapse.

        On timeout (including interrupt-triggered early-timeout), echoes
        each question's pre-committed ``default`` per design §4.2 — the
        result hands back exactly what the LLM committed to, no
        improvisation.

        ``interrupt_event``: when set and signalled (``/cancel`` slash,
        E-stop), raises ``ClarifyInterruptedError`` so the caller can
        package the result as ``outcome="error"`` with a "user halted"
        reason. This distinguishes user-driven halt from natural
        timeout (no response) — important because /cancel means the
        user explicitly rejected the question, while timeout-with-
        default-echo would imply they implicitly accepted the LLM's
        committed default.

        Without ``interrupt_event`` (PR-1 default — registry plumbing
        is a PR-2 task per design §15), the wait runs to ``timeout``
        and ``/cancel`` is observable only via the agent halt at the
        next checkpoint, with whatever default the LLM committed.
        """
        waiter = self._waiters.get(session_id)
        if waiter is None:
            # Already resolved (race between register() and wait_for_resolution())
            # — ``resolve()`` pops both ``_waiters`` and ``_pending``, so the
            # answer lives in ``_resolved``. Mirror ApprovalManager's check
            # there before raising.
            request = self._find_resolved_for_session(session_id)
            if request is not None:
                return request
            raise KeyError(f"No waiter for session {session_id}")

        try:
            if interrupt_event is not None:
                await self._wait_with_interrupt(waiter, float(timeout), interrupt_event)
            else:
                await asyncio.wait_for(waiter.wait(), timeout=float(timeout))
        except ClarifyInterruptedError:
            # User halted via /cancel or E-stop. Drop the pending
            # request so a re-asked clarify after this turn doesn't
            # trip ConcurrentClarifyError, and propagate the
            # exception so the tool body can package an
            # ``outcome="error"`` result with a clear "user halted"
            # reason. We do NOT call ``resolve(outcome="error")``
            # here — the manager has no error-reason channel, and
            # the tool body's ``_error_result_json`` is the single
            # construction site for error outcomes.
            self.discard_pending(session_id)
            raise
        except TimeoutError:
            # Timeout: echo the LLM's pre-committed defaults so the result
            # is self-contained (LLM doesn't have to look back at its own
            # tool-call args). ``echo_default()`` wraps multi_select
            # defaults in a single-element list so the shape mirrors a
            # real card reply. Shape mirrors the answered case:
            #   single-Q → scalar str / list[str] / None
            #   multi-Q  → dict {Q: scalar | list | null} per question
            # exclude_none on serialisation drops a single-Q null cleanly.
            if session_id in self._pending:
                pending = self._pending[session_id]
                defaults: str | list[str] | dict[str, str | list[str] | None] | None
                if len(pending.questions) == 1:
                    defaults = pending.questions[0].echo_default()
                else:
                    defaults = {q.question: q.echo_default() for q in pending.questions}
                self.resolve(session_id, "timeout", answers=defaults)
            request = self._find_resolved_for_session(session_id)
            if request is not None:
                return request
            raise KeyError(f"Clarify for session {session_id} vanished during timeout")

        # Resolved by caller — pick up from the resolved cache
        request = self._find_resolved_for_session(session_id)
        if request is not None:
            return request
        raise KeyError(f"Resolved clarify for session {session_id} not found")

    def _find_resolved_for_session(self, session_id: str) -> ClarifyRequest | None:
        """Find the most recently resolved request for a session."""
        candidates = [r for r in self._resolved.values() if r.session_id == session_id]
        if not candidates:
            return None
        candidates.sort(
            key=lambda r: r.resolved_at or datetime.min.replace(tzinfo=UTC), reverse=True
        )
        return candidates[0]

    @staticmethod
    async def _wait_with_interrupt(
        waiter: asyncio.Event,
        timeout: float,
        interrupt: asyncio.Event,
    ) -> None:
        """Wait for *waiter* OR *interrupt*, whichever fires first.

        Raises ``TimeoutError`` if neither fires within ``timeout``.
        Raises ``ClarifyInterruptedError`` if *interrupt* fires before
        *waiter*. The two exception types let ``wait_for_resolution``
        distinguish "no response within deadline" (→ outcome=timeout
        with default echo) from "user halted via /cancel or E-stop"
        (→ outcome=error with reason).
        """
        waiter_task = asyncio.create_task(waiter.wait())
        interrupt_task = asyncio.create_task(interrupt.wait())
        try:
            done, _pending = await asyncio.wait(
                {waiter_task, interrupt_task},
                timeout=timeout,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if not done:
                raise TimeoutError
            if interrupt_task in done and waiter_task not in done:
                raise ClarifyInterruptedError
        finally:
            # Mirror ApprovalManager: cancel + AWAIT the cancelled tasks
            # so they fully process the cancellation. Without the
            # gather, asyncio emits "Task was destroyed but it is
            # pending!" warnings at shutdown / in tests.
            waiter_task.cancel()
            interrupt_task.cancel()
            await asyncio.gather(waiter_task, interrupt_task, return_exceptions=True)

    # ── Stamped resolution helper ────────────────────────────────────

    def resolve_from_stamp(
        self,
        clarify_id: str,
        *,
        channel: str | None = None,
        answer: Any = None,
        answers: dict[str, Any] | None = None,
        via_input: bool = False,
    ) -> bool:
        """Resolve via a stamped Lane 1 inbound (§6.1) — card-mediated.

        Exactly one of ``answer`` or ``answers`` should be set — these are
        the two wire shapes from the Adaptive Card / messageBack dispatch.
        Halting is not on the card; ``/cancel`` and E-stop are agent-loop
        level halt signals (see ``ClarifyTool.execute`` comment near
        ``wait_for_resolution``), not handled here.

        - Single-question wire: pass ``answer`` (the choice or pure free
          text typed in the card input).
        - Multi-question wire: pass ``answers`` as a dict keyed by question
          text, value being the choice / typed text per question.

        Both ``answer`` and ``answers`` accept ``Any`` from the wire because
        JSON-decoded payloads arrive as untyped data and the router cannot
        guarantee shape ahead of validation. ``_validate_answer_shape``
        enforces the contract (str / list[str] only, multi_select
        consistency, ``answered_card`` label-in-options); malformed values
        cause the method to return ``False`` without touching the pending
        request.

        ``via_input`` discriminates card click from card text input:
        - ``False`` (default) — user clicked an option button → outcome
          ``answered_card`` (highest trust).
        - ``True`` — user typed in the card's free-text input field
          → outcome ``answered_chat`` (medium trust, free-form but still
          on-card and focused).

        Lane 2 (chat input bar, off-card) goes through a separate matcher
        that calls ``resolve()`` directly with ``outcome="free_chat"``.

        ``channel`` enforces §9 single-surface: when set on both sides
        (request was registered with one + caller passes the inbound's
        channel) and they don't match, the response is rejected and the
        request stays pending. The check no-ops when either side is
        empty — keeps existing/synthetic paths working without forcing
        every test to thread a channel through.

        Returns True if resolved, False on unknown clarify_id OR on
        channel-binding mismatch.
        """
        sid = self._request_by_id.get(clarify_id)
        if sid is None or sid not in self._pending:
            # Idempotent late-arrival: resolved entries live in
            # ``_resolved`` for 60 s (see module docstring). A duplicate
            # stamped response after resolution should be a no-op, not a
            # "treat as fresh user message" miss — without this branch,
            # the router would fall through and the LLM would see the
            # answer text twice (once via clarify, once as a regular
            # mid-run inbound on the next turn). Return True to signal
            # "stamped — already handled, drop".
            if clarify_id in self._resolved:
                logger.debug("Clarify {} already resolved — dropping duplicate stamp", clarify_id)
                return True
            return False

        pending = self._pending[sid]
        if channel and pending.channel and channel != pending.channel:
            logger.warning(
                "Clarify {} foreign-channel rejection: got {!r}, expected {!r}",
                clarify_id,
                channel,
                pending.channel,
            )
            return False

        # Mutual exclusion: ``answer`` and ``answers`` are the two shapes;
        # passing both is a malformed payload (caller bug or over-eager
        # router merging shapes). Reject instead of silently picking one.
        provided = sum(1 for v in (answer, answers) if v is not None)
        if provided > 1:
            logger.warning(
                "resolve_from_stamp got {} fields set for clarify {} "
                "(answer/answers are mutually exclusive)",
                provided,
                clarify_id,
            )
            return False

        # Outcome inference describes the user's interaction mode for
        # the batch (the trust signal at outcome level):
        # - ``via_input=True`` → user typed in the card's text input
        #   (``answered_chat``); some values may be off-label.
        # - ``via_input=False`` (default) + every question has options →
        #   user clicked option buttons (``answered_card``); structured.
        # - ``via_input=False`` + any question is free-text → no
        #   all-click path possible (free-text Qs have no buttons), so
        #   the user must have typed at least one answer; classify as
        #   ``answered_chat``.
        # Per-question shape validation runs against ``question.options``
        # / ``question.multi_select``, not against the batch outcome —
        # so mixed batches resolve naturally without forcing the LLM to
        # split queries.
        all_questions_have_options = all(q.options for q in pending.questions)
        outcome: ClarifyOutcome = (
            "answered_chat" if via_input or not all_questions_have_options else "answered_card"
        )

        if answer is not None:
            # Single-question wire: {clarify_id, answer}.
            # Polymorphic shape — single-Q stores answer as scalar (no
            # dict wrapping).
            if len(pending.questions) != 1:
                logger.warning(
                    "Clarify {} got single-answer payload for multi-question request",
                    clarify_id,
                )
                return False
            shape_err = _validate_answer_shape(pending.questions[0], answer, outcome)
            if shape_err is not None:
                logger.warning("Clarify {} shape validation failed: {}", clarify_id, shape_err)
                return False
            self.resolve(sid, outcome, answers=answer)
            return True

        if answers is not None:
            # Symmetric to the ``answer`` branch above: a multi-answer
            # payload for a single-question pending is malformed.
            # Without this check, the dict would pass key validation
            # (the single question's text matches) and then trip
            # ``_validate_resolve_invariants`` inside ``resolve()``,
            # raising ValueError up to the caller instead of returning
            # ``False`` per the documented contract.
            if len(pending.questions) == 1:
                logger.warning(
                    "Clarify {} got multi-answer payload for single-question request",
                    clarify_id,
                )
                return False
            # Validate keys match the pending questions: a malformed /
            # malicious payload with extras or missing entries would
            # otherwise resolve the clarify with confusing data for the
            # LLM. Require exact equality with the question-text set.
            expected = {q.question: q for q in pending.questions}
            if set(answers.keys()) != set(expected.keys()):
                logger.warning(
                    "Clarify {} answers keys mismatch: got {} expected {}",
                    clarify_id,
                    sorted(answers.keys()),
                    sorted(expected.keys()),
                )
                return False
            # ``None`` values in stamped answers are not legal for the
            # ``answered_*`` outcomes this method produces — every
            # question must carry an actual reply. ``None``/missing
            # answers are reserved for the timeout path (echoed null
            # defaults) and the error outcome (whole answers is None).
            # ``_validate_answer_shape`` returns "unexpected answer type
            # NoneType" for None, which trips the rejection here.
            for qtext, value in answers.items():
                shape_err = _validate_answer_shape(expected[qtext], value, outcome)
                if shape_err is not None:
                    logger.warning(
                        "Clarify {} shape validation failed for {!r}: {}",
                        clarify_id,
                        qtext,
                        shape_err,
                    )
                    return False
            self.resolve(sid, outcome, answers=dict(answers))
            return True

        logger.warning("resolve_from_stamp called with no payload for clarify {}", clarify_id)
        return False

    # ── Snapshot for debugging / introspection ──────────────────────

    def snapshot(self) -> dict[str, Any]:
        """Return a dict snapshot of current state for debug/tests."""
        return {
            "pending_sessions": list(self._pending.keys()),
            "pending_count": len(self._pending),
            "resolved_count": len(self._resolved),
            "waiter_count": len(self._waiters),
        }
