"""Typing indicator controller for agent loop processing.

Manages periodic typing-indicator emissions with pause/resume
support for approval waits.  Each message-processing cycle creates
one controller; the controller is threaded through to hook handlers
so approval logic can pause typing while the card is displayed.

Design invariants
-----------------
* ``start()`` emits immediately, then re-emits every ``TYPING_INTERVAL``.
* ``pause()`` suppresses emissions; after at most one pending sleep the
  loop blocks at ``_active.wait()`` until ``resume()``.
* ``resume()`` fires a delayed one-shot emission (150 ms) so Teams has
  time to process the approval-card update PUT before the next typing
  activity arrives, then the periodic loop continues.
* ``stop()`` is idempotent — safe to call multiple times (e.g. from
  both the streaming path and the ``_process_message`` finally block).
* Delayed resume callbacks are tracked and cancelled by ``stop()`` /
  ``pause()`` so a stale ``TYPING_STARTED`` never fires after the final
  response has already been sent.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from workpilot.bus.queue import EventBus

from workpilot.bus.events import EventType

# Teams typing activity auto-expires after ~5 s; the indicator may flicker
# off for a beat at the margin, which is acceptable per design — streaming-
# eligible turns mask the gap with the live streaming bubble, and fallback
# / pre-content phases tolerate a brief pause better than they tolerate the
# extra API-call rate.
TYPING_INTERVAL: float = 5.0


class TypingController:
    """Manages periodic typing indicator emissions with pause/resume."""

    __slots__ = (
        "_bus",
        "_channel",
        "_channel_id",
        "_payload",
        "_task",
        "_active",
        "_stopped",
        "_resume_handle",
        "_suppressed",
    )

    def __init__(
        self,
        bus: EventBus,
        channel: Any,
        channel_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._bus = bus
        self._channel = channel
        self._channel_id = channel_id
        self._payload: dict[str, Any] = {
            "channel": channel,
            "channel_id": channel_id,
            "metadata": metadata or {},
        }
        self._task: asyncio.Task[None] | None = None
        self._active = asyncio.Event()
        self._active.set()  # starts active (not paused)
        self._stopped = False
        self._resume_handle: asyncio.TimerHandle | None = None
        # Cloud channel typing is no longer driven from the Python client:
        #   - cloud_teams: Cloud Gateway fires typing on inbound + on each
        #     buffered fallback chunk (event-driven, throttled at 4 s per
        #     channel). Streaming-eligible turns rely on dispatcher's
        #     informative frames as the indicator.
        #   - cloud_webchat: the new React frontend derives the typing UI
        #     from chunk / approval / connection state directly (see
        #     web/src/hooks/useWebSocket.ts — `case "typing": break;`),
        #     so the WSS typing frame is dead bandwidth.
        # CLI continues to emit normally.
        _src = (metadata or {}).get("source")
        self._suppressed = _src in ("cloud_teams", "cloud_webchat")

    # ── Lifecycle ──────────────────────────────────────────────────────

    def start(self) -> None:
        """Begin periodic typing emissions. Emits once immediately."""
        if self._suppressed:
            self._stopped = True  # everything else becomes a no-op
            return
        self._bus.emit(EventType.TYPING_STARTED, self._payload)

        async def _loop() -> None:
            try:
                while True:
                    # Block while paused — truly suspends, no wasted wakeups
                    await self._active.wait()
                    await asyncio.sleep(TYPING_INTERVAL)
                    # Re-check after sleep (may have been paused/stopped during it)
                    if self._active.is_set() and not self._stopped:
                        self._bus.emit(EventType.TYPING_STARTED, self._payload)
            except asyncio.CancelledError:
                pass

        self._task = asyncio.create_task(_loop(), name="typing-indicator")

    def stop(self) -> None:
        """Cancel the typing loop and emit ``TYPING_STOPPED``.  Idempotent."""
        if self._stopped:
            return
        self._stopped = True
        # Cancel any pending delayed resume callback
        if self._resume_handle is not None:
            self._resume_handle.cancel()
            self._resume_handle = None
        if self._task is not None and not self._task.done():
            self._task.cancel()
        self._bus.emit(
            EventType.TYPING_STOPPED,
            {"channel": self._channel, "channel_id": self._channel_id},
        )

    # ── Pause / resume (approval flow) ─────────────────────────────────

    def pause(self) -> None:
        """Suppress typing emissions (e.g. while an approval card is displayed).

        After at most one pending sleep completes, the loop blocks at
        ``_active.wait()`` — no further wakeups until ``resume()``.
        """
        self._active.clear()
        # Cancel any pending delayed resume callback
        if self._resume_handle is not None:
            self._resume_handle.cancel()
            self._resume_handle = None

    def resume(self) -> None:
        """Resume typing emissions after approval resolution.

        Fires a delayed one-shot emission (150 ms) so Teams has time to
        process the approval-card update PUT before the next typing
        activity arrives — without the delay they race and Teams often
        clears the typing we just sent.  The periodic loop resumes its
        normal cadence after the next ``TYPING_INTERVAL`` sleep.
        """
        if self._stopped:
            return
        self._active.set()
        # Delayed one-shot: gives Teams time to process the card-update PUT
        try:
            self._resume_handle = asyncio.get_running_loop().call_later(0.15, self._emit_typing)
        except RuntimeError:
            pass  # No running loop (test teardown edge case)

    def _emit_typing(self) -> None:
        """One-shot typing emission (used by delayed resume callback)."""
        self._resume_handle = None
        if self._active.is_set() and not self._stopped:
            self._bus.emit(EventType.TYPING_STARTED, self._payload)

    # ── Introspection ──────────────────────────────────────────────────

    @property
    def paused(self) -> bool:
        """True when typing emissions are suppressed."""
        return not self._active.is_set()

    @property
    def active(self) -> bool:
        """True if the typing loop is still running (not yet stopped)."""
        return not self._stopped and self._task is not None and not self._task.done()
