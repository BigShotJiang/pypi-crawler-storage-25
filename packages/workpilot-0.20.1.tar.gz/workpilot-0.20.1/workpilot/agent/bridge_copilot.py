"""
Copilot bridge — wraps the GitHub Copilot SDK's CopilotSession for bridge mode.

See design/features/bridge-mode.md §5.1. Reuses one CopilotSession for the
lifetime of the bridge (contrast with the delegate tool, which opens a fresh
session per task). ``send_and_wait()`` blocks until ``session.idle``, but we
also register an ``on_event`` callback so ``ASSISTANT_MESSAGE`` events arriving
before idle are rebroadcast as ``StreamingChunk`` — giving Web Chat / CLI /
Tier-2 web progressive rendering without waiting for the full turn.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.agent.bridge import DispatchResult, bridge_origin
from workpilot.bus.events import OutboundMessage, StreamingChunk
from workpilot.security.leak import redact_credentials

if TYPE_CHECKING:
    from workpilot.agent.bridge import BridgeState
    from workpilot.bus.queue import MessageBus
    from workpilot.session.manager import SessionManager


class CopilotBridge:
    """Forward a turn to a live CopilotSession; buffer and emit once."""

    def __init__(
        self,
        *,
        bus: MessageBus,
        sessions: SessionManager,
        workspace: Path | str = ".",
        cli_path: str | Path | None = None,
        github_token: str | None = None,
        model: str | None = None,
        task_timeout: int = 3600,
    ) -> None:
        # ``model`` stays as-passed (may be None). None is the pass-through
        # signal: ``create_session(model=None)`` → SDK omits the key from
        # its subprocess payload → Copilot CLI falls back to the user's
        # own ``/model`` config / ``COPILOT_MODEL`` env / built-in
        # default. Previously this constructor back-filled None with
        # ``CopilotToolConfig.default_model``, silently overriding the
        # user's Copilot config — removed as part of that config-field
        # deletion.
        self._bus = bus
        self._sessions = sessions
        self._workspace = workspace
        self._cli_path = cli_path
        self._github_token = github_token
        self._model = model
        self._task_timeout = task_timeout
        self._client: Any | None = None
        # Serialises the defensive lazy-reopen branch in dispatch (see the
        # comment there for why it shouldn't normally fire). If it ever does,
        # AgentLoop's serial dispatch makes concurrent first-open rare — but
        # a double-open would leak one CopilotSession and two live subprocesses
        # on the SDK side, so the lock is cheap insurance.
        self._session_open_lock = asyncio.Lock()
        # Serialises cold-start of the shared CopilotClient. The /bridge
        # status renderer kicks off list_supported_models and list_sessions
        # in parallel (asyncio.gather), both of which call _ensure_client.
        # Without this lock the two coroutines both see ``self._client is
        # None`` on first call, both spawn a subprocess, the later one wins
        # via ``self._client = client``, and the first subprocess leaks.
        self._client_open_lock = asyncio.Lock()

    async def list_sessions(
        self,
        *,
        cwd: str | None = None,
        limit: int = 3,
        timeout: float = 5.0,
    ) -> list[dict[str, Any]]:
        """Return recent CLI-side Copilot sessions (optionally filtered to
        ``cwd``). Each entry is normalised to
        ``{"sessionId": str, "summary": str | None, "modified_ms": int}``
        so the bridge layer stays decoupled from the Copilot SDK's exact
        dataclasses.

        Client warm-up cost is typically already paid (``list_supported_models``
        runs earlier in the same status render), so this is an RPC
        round-trip in the normal case. Any error (SDK missing, auth
        failure, timeout, empty result) returns ``[]`` — caller decides
        the empty-state UX.
        """
        try:
            from copilot.client import SessionListFilter  # type: ignore[import]

            client = await asyncio.wait_for(self._ensure_client(), timeout=timeout)
            filt = SessionListFilter(cwd=cwd) if cwd else None
            sessions = await asyncio.wait_for(client.list_sessions(filt), timeout=timeout)
        except Exception as exc:
            logger.debug("CopilotBridge.list_sessions failed: {}", exc)
            return []

        from datetime import datetime

        out: list[dict[str, Any]] = []
        for s in sessions:
            # SDK returns ISO-8601 strings for timestamps; normalise to
            # ms-since-epoch so callers can reuse the age-formatter that
            # takes Claude's int ms. Fallback to 0 on parse failure —
            # older-than-everything, sorts last, still renders.
            raw_time = getattr(s, "modifiedTime", None) or ""
            try:
                dt = datetime.fromisoformat(raw_time.replace("Z", "+00:00"))
                modified_ms = int(dt.timestamp() * 1000)
            except Exception:
                modified_ms = 0
            out.append(
                {
                    "sessionId": getattr(s, "sessionId", "") or "",
                    "summary": getattr(s, "summary", None),
                    "modified_ms": modified_ms,
                }
            )
        # SDK doesn't document ordering; sort by mtime desc so the most
        # recent session sits first regardless of server-side ordering.
        out.sort(key=lambda x: x["modified_ms"], reverse=True)
        return out[:limit]

    async def list_supported_models(self, *, timeout: float = 5.0) -> list[str]:
        """Query the live Copilot SDK for the models the user's current
        auth has access to. Returns each model's id (e.g.
        ``"claude-sonnet-4.6"``) — what you'd pass as ``model=`` on
        ``create_session``.

        Costs a subprocess spawn + network round-trip the first time
        (``_ensure_client`` starts the CLI if not already running; the
        SDK caches the result afterwards). Callers that need a fast
        path should wrap in ``asyncio.wait_for`` with a short timeout
        and fall back to a static suggestion list on failure — which
        is exactly what ``/bridge`` status does.

        Failure-safe: auth errors, missing SDK, timeouts, CLI subprocess
        start failures all return an empty list. Caller decides what
        to show.
        """
        try:
            client = await asyncio.wait_for(self._ensure_client(), timeout=timeout)
            models = await asyncio.wait_for(client.list_models(), timeout=timeout)
        except Exception as exc:
            logger.debug("CopilotBridge.list_supported_models failed: {}", exc)
            return []
        out: list[str] = []
        for m in models:
            mid = getattr(m, "id", None)
            if isinstance(mid, str) and mid:
                out.append(mid)
        return out

    async def _ensure_client(self) -> Any:
        """Lazy-start the shared CopilotClient.

        Double-checked locking: the fast path (client already up) returns
        without acquiring the lock. Cold start serialises through
        ``_client_open_lock`` so concurrent callers — e.g. the parallel
        ``list_supported_models`` + ``list_sessions`` calls from
        ``/bridge`` status — don't spawn two subprocesses.
        """
        if self._client is not None:
            return self._client
        async with self._client_open_lock:
            if self._client is not None:  # recheck under the lock
                return self._client
            try:
                from copilot import CopilotClient  # type: ignore[import]
                from copilot.client import SubprocessConfig  # type: ignore[attr-defined, import]
            except ImportError as exc:
                raise RuntimeError(
                    "github-copilot-sdk not installed. Install: pip install 'github-copilot-sdk>=0.3'"
                ) from exc

            subprocess_config = SubprocessConfig(
                cwd=str(self._workspace),
                cli_path=str(self._cli_path) if self._cli_path else None,
                github_token=self._github_token,
            )
            # Only publish self._client after ``start()`` succeeds — if startup
            # raises (missing binary, auth failure, subprocess crash) we don't
            # want a half-initialised client cached that future calls reuse.
            client = CopilotClient(subprocess_config)
            await client.start()
            self._client = client
            logger.info("CopilotBridge: client started")
            return self._client

    async def open_session(
        self,
        sid: str,
        external_id: str,
        *,
        resume: bool,
        state_ref: BridgeState | None = None,
        model: str | None = None,
    ) -> Any:
        """Open a new or resumed CopilotSession for this canonical WorkPilot session.

        Returns the live session object — BridgeState stores it in copilot_session.
        The bridge stamps ``session_id=f"wp-bridge-{sid}"`` on fresh create for
        audit disjointness with the delegate tool's ``wp-{task_id}`` convention.

        ``model`` overrides the handler's constructor-level value when
        set — this is how per-``/bridge`` invocations pin a specific
        model. None falls back to ``self._model`` (also possibly None,
        in which case the SDK omits ``model`` from its subprocess
        payload and the Copilot CLI picks up the user's own ``/model``
        config).

        If ``state_ref`` is passed, registers an ``on_event`` callback that
        rebroadcasts ``ASSISTANT_MESSAGE`` events as ``StreamingChunk`` — gives
        Web Chat / CLI / Tier-2 web progressive rendering. Teams is skipped at
        callback-invocation time (reads ``state_ref.is_teams`` dynamically).
        """
        from copilot.session import PermissionHandler  # type: ignore[import]

        client = await self._ensure_client()

        # Per-call model override wins over the handler's default.
        effective_model = model if model is not None else self._model
        session_kwargs: dict[str, Any] = {
            "model": effective_model,
            # Bridge does not gate per-tool — the user is talking to Copilot
            # directly. Auto-approve everything at this layer; WorkPilot's
            # profile-level reject already applies at toggle time.
            # PermissionHandler.approve_all is a @staticmethod that IS the
            # callback — pass the function itself, not the result of calling it.
            "on_permission_request": PermissionHandler.approve_all,
        }

        # Register streaming relay BEFORE session creation so events fired
        # during initial handshake (rare but possible) are already captured.
        if state_ref is not None:
            session_kwargs["on_event"] = self._build_on_event(state_ref)

        if resume and external_id:
            try:
                return await client.resume_session(external_id, **session_kwargs)
            except Exception as exc:
                # Stale id → spec §9 says drop registry, retry once fresh.
                logger.warning(
                    "CopilotBridge: resume_session({}) failed: {} — falling back to fresh",
                    external_id,
                    exc,
                )

        session_kwargs["session_id"] = f"wp-bridge-{sid}"
        return await client.create_session(**session_kwargs)

    def _build_on_event(self, state_ref: BridgeState) -> Any:
        """Return a sync callback that rebroadcasts ASSISTANT_MESSAGE events
        and tracks the running model from SDK-emitted events.

        Runs on the same asyncio loop (the SDK dispatches synchronously inside
        its receive-loop task), so we schedule ``publish_outbound`` as a task
        via ``asyncio.ensure_future`` rather than blocking the callback.

        Model tracking — the SDK emits the CLI-resolved model on several event
        types; we sample any of them to populate ``state_ref.active_model``
        so ``/model`` status can show the actually-running model (not just
        the user's pin). Precedence of fields (any one is enough):
        ``new_model`` (on SESSION_MODEL_CHANGE) →
        ``selected_model`` (on SESSION_START / SESSION_RESUME) →
        ``current_model`` (on SESSION_INFO) →
        ``model`` (fallback on ASSISTANT_USAGE etc.).
        """
        bus = self._bus

        def _capture_model_from_data(data: Any) -> None:
            """Update ``state_ref.active_model`` if the event carries a
            resolved-model field. Missing attrs are normal (most events
            carry nothing model-related) — getattr with None default
            handles all event payload shapes uniformly."""
            for attr in ("new_model", "selected_model", "current_model", "model"):
                value = getattr(data, attr, None)
                if isinstance(value, str) and value:
                    state_ref.active_model = value
                    return

        def handler(event: Any) -> None:
            data = getattr(event, "data", None)
            if data is not None:
                # Run on every event — cheap (bounded getattrs), catches
                # model fields regardless of which event they ride on.
                _capture_model_from_data(data)

            # Streaming relay: rebroadcast assistant messages only. All
            # other event types (idle / title / model / file / session_end
            # / ...) are noise for the user-facing channel.
            if state_ref.is_teams:
                return  # Teams can't render progressive streaming.
            # Compare against the raw wire string rather than
            # ``SessionEventType.ASSISTANT_MESSAGE`` enum — the enum moved
            # from ``copilot.session`` (SDK 0.2) into the private
            # ``copilot.generated.session_events`` module (0.3). The raw
            # string value is part of the stable JSON-RPC contract, so
            # pattern-matching on it is robust across SDK version bumps.
            # ``event.raw_type`` is the untranslated payload string;
            # ``event.type.value`` falls back to the enum's str value.
            raw_type = getattr(event, "raw_type", None)
            if raw_type is None:
                raw_type = getattr(getattr(event, "type", None), "value", None)
            if raw_type != "assistant.message":
                return
            content = getattr(data, "content", None) if data is not None else None
            if not content:
                return
            safe = redact_credentials(str(content))
            try:
                # dispatch_outbound bypasses the bounded outbound queue
                # (no consumer drains chunks — publish_outbound would
                # backpressure once the queue fills during long streams).
                asyncio.ensure_future(
                    bus.dispatch_outbound(
                        StreamingChunk(
                            channel=state_ref.channel,
                            channel_id=state_ref.channel_id,
                            content=safe,
                        )
                    )
                )
            except Exception as exc:  # pragma: no cover — defensive
                logger.warning("CopilotBridge on_event publish failed: {}", exc)

        return handler

    async def dispatch(
        self,
        *,
        prompt: str,
        state: BridgeState,
        session_id: str,
        attachments: list[dict[str, Any]] | None = None,
    ) -> DispatchResult:
        """Forward a single prompt through the live CopilotSession.

        ``attachments`` are user-uploaded files resolved to on-disk
        AttachmentRef dicts; each is converted to a ``FileAttachment``
        (``{type: "file", path: "..."}``) and passed to
        ``session.send_and_wait(prompt, attachments=...)``. The Copilot
        CLI reads the file by path — no base64 encoding, no size
        accounting beyond what the SDK enforces server-side.
        ``PermissionHandler.approve_all`` on session open already
        suppresses any file-access prompts.

        ``DispatchResult.terminal_reason`` is set when the SDK reported a
        non-recoverable condition (subprocess death, auth / quota); caller
        exits bridge on non-None. ``DispatchResult.is_error`` is True for
        any error surfaced to the user (terminal OR transient).
        """
        # Defensive guard. ``state.copilot_session`` should always be set by
        # the time dispatch runs — ``BridgeService.toggle`` opens and stores
        # it before registering the state, and nothing else nulls it back
        # out (``switch_model`` calls ``set_model`` in place; ``exit_session``
        # disconnects then pops from the registry, removing the state from
        # any future dispatch path). So in steady state this branch is
        # unreachable. We keep it as a defence-in-depth: any future flow
        # that does null the session (e.g. a hypothetical rehydration after
        # runtime restart that we don't currently implement) gets a single
        # silent reopen instead of an AttributeError. Double-checked locking
        # so concurrent first-dispatch doesn't spawn two CopilotSessions.
        if state.copilot_session is None:
            async with self._session_open_lock:
                if state.copilot_session is None:  # recheck under lock
                    session_obj = await self.open_session(
                        session_id,
                        state.external_id,
                        resume=bool(state.external_id),
                        state_ref=state,
                    )
                    sdk_id = getattr(session_obj, "session_id", None)
                    if sdk_id:
                        state.external_id = sdk_id
                    state.copilot_session = session_obj

        # Convert AttachmentRef dicts → SDK ``FileAttachment`` (path-based).
        # Filter out anything missing a usable path — malformed refs would
        # break the SDK call otherwise.
        copilot_attachments: list[dict[str, Any]] | None = None
        if attachments:
            copilot_attachments = []
            for att in attachments:
                path_str = str(att.get("path") or "").strip()
                if not path_str:
                    continue
                entry: dict[str, Any] = {"type": "file", "path": path_str}
                if att.get("name"):
                    entry["displayName"] = str(att["name"])
                copilot_attachments.append(entry)
            if not copilot_attachments:
                copilot_attachments = None

        session = state.copilot_session
        try:
            if copilot_attachments:
                reply = await session.send_and_wait(
                    prompt, attachments=copilot_attachments, timeout=self._task_timeout
                )
            else:
                reply = await session.send_and_wait(prompt, timeout=self._task_timeout)
        except Exception as exc:
            # Classify — see design spec §5.3.
            err_name = type(exc).__name__
            reply_text = redact_credentials(f"[Copilot error: {err_name}: {exc}]")
            # Close any active stream first — the on_event callback may have
            # emitted partial ASSISTANT_MESSAGE chunks before the exception;
            # without a done=True marker the CLI / WS client stays stuck in
            # "streaming" state.
            if not state.is_teams:
                await self._bus.dispatch_outbound(
                    StreamingChunk(
                        channel=state.channel,
                        channel_id=state.channel_id,
                        content="",
                        done=True,
                    )
                )
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=state.channel,
                    channel_id=state.channel_id,
                    content=reply_text,
                    metadata={
                        "source": "bridge",
                        "_origin": bridge_origin("copilot"),
                        "_error": err_name,
                    },
                )
            )
            terminal = _classify_terminal(exc)
            return DispatchResult(
                reply=reply_text,
                streamed=True,
                new_external_id=None,
                terminal_reason=terminal,
                is_error=True,
            )

        reply_text = redact_credentials(self._extract_text(reply))

        # On streaming surfaces, on_event already published the assistant
        # message content as a StreamingChunk; send a ``done=True`` marker
        # so CLI / WS handlers finalise their render.
        if not state.is_teams:
            await self._bus.dispatch_outbound(
                StreamingChunk(
                    channel=state.channel,
                    channel_id=state.channel_id,
                    content="",
                    done=True,
                )
            )

        # ALWAYS publish the full OutboundMessage. /api/chat's submit_and_wait
        # waits on the response queue; a stream-only turn would hang until
        # timeout because no stream queue is registered for that endpoint.
        # Streaming-capable channels got chunks via on_event; the final
        # OutboundMessage is the authoritative reply for everything else.
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=state.channel,
                channel_id=state.channel_id,
                content=reply_text,
                metadata={"source": "bridge", "_origin": bridge_origin("copilot")},
            )
        )

        # SDK-assigned id may differ from what we created with; mirror it back.
        new_external = getattr(session, "session_id", None)
        return DispatchResult(
            reply=reply_text,
            streamed=True,
            new_external_id=new_external,
            terminal_reason=None,
            is_error=False,
        )

    @staticmethod
    def _extract_text(reply: Any) -> str:
        """Pull user-visible text out of a SessionEvent response.

        Mirrors the pattern used by the delegate tool: ``reply.data.content``
        when present, otherwise a placeholder.
        """
        if reply is None:
            return "(no response)"
        data = getattr(reply, "data", None)
        content = getattr(data, "content", None) if data is not None else None
        if content is None:
            return "(no response)"
        return str(content)


def _classify_terminal(exc: BaseException) -> str | None:
    """Map a ``send_and_wait`` exception to a terminal reason, or None.

    ``ProcessExitedError`` → subprocess died; we can't reuse this session,
    so the whole bridge must exit. Other exceptions (e.g. ``TimeoutError``
    on a request to a healthy session, plain ``JsonRpcError``) are treated
    as transient — user stays bridged and can retry. Match by class name so
    we don't hard-import SDK-private error classes.
    """
    name = type(exc).__name__
    if name == "ProcessExitedError":
        return f"Copilot subprocess exited: {exc}"
    return None
