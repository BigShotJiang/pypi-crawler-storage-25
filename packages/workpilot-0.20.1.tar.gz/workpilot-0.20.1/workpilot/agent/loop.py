"""
AgentLoop — the core agentic execution engine.

Implements: LLM call → tool calls → LLM call → ... → final response.

Inspired by HKUDS/nanobot's loop.py but enterprise-hardened with:
- Audit logging on every tool call
- Sandbox enforcement
- Memory consolidation
- RBAC-aware tool filtering
- Prompt injection detection
- Topic-aware context compaction
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from workpilot.agent.compaction import (
    clear_old_tool_results,
    compact_fallback,
    compact_messages,
    detect_topic_switch,
    estimate_tokens,
    should_post_compact,
    should_pre_compact,
)
from workpilot.agent.consolidation import Consolidator
from workpilot.agent.context import ContextBuilder
from workpilot.agent.interrupt import InterruptController
from workpilot.agent.loop_detect import LoopDetector
from workpilot.agent.memory import AgentMemory
from workpilot.agent.output_parser import extract_outputs
from workpilot.agent.reminders import ReminderTracker
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agent.truncation import truncate_tool_output
from workpilot.bus.events import (
    NOTIFICATION_SOURCES,
    EventType,
    InboundMessage,
    OutboundMessage,
    StreamingChunk,
    frame_notification,
)
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import AgentConfig, ChannelType, SkillsConfig
from workpilot.hooks.manager import (
    HookManager,
    HookVerdict,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
    RejectCategory,
)
from workpilot.providers.base import LLMProvider, LLMResponse
from workpilot.providers.client import _supports_server_compaction
from workpilot.providers.resolver import describe_resolution_failure, resolve_model_chain
from workpilot.security.attachments import (
    load_as_text,
    render_text_attachment,
)
from workpilot.security.attachments import (
    portable_attachments as _security_portable_attachments,
)
from workpilot.security.audit import AuditLogger
from workpilot.security.leak import redact_credentials
from workpilot.security.sanitizer import Sanitizer
from workpilot.session.manager import SessionManager

if TYPE_CHECKING:
    from workpilot.agent.bridge import BridgeService
    from workpilot.agent.typing import TypingController
    from workpilot.security.allowlist import AllowlistManager
    from workpilot.security.approval import ApprovalManager
    from workpilot.skills.loader import SkillLoader


from workpilot.utils.token_errors import is_token_limit_error

# Channels that render inline image attachments. Used to gate the
# streaming-path supplementary ``OutboundMessage(content="", attachments)``
# — CLI has no image renderer, so delivering an empty-content frame there
# prints a blank ``assistant>`` line and silently drops the bytes.
_INLINE_ATTACHMENT_CHANNELS: frozenset[ChannelType] = frozenset(
    {ChannelType.WEB, ChannelType.CLOUD}
)


def _patch_raw_output(
    raw_output: list[dict[str, Any]],
    stripped: str,
    refs: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Best-effort patch of a Responses-API message item after image hoisting.

    The native-path raw_output carries ``{type:"message", role:"assistant",
    content: [{type:"output_text", text: ...}, ...]}`` items. When the
    output-parser strips ``workpilot-image://`` sentinels we want the
    persisted raw_item to reflect the cleaned text AND carry the
    ``_attachments`` sidecar so a reload re-renders the same image row as
    the chat-path entry. We patch the first ``output_text`` part with the
    full stripped text and blank the rest — imperfect when the message
    splits across multiple text parts, but phase-1-acceptable (rare in
    practice; text-only messages typically collapse to one part).
    """
    out: list[dict[str, Any]] = []
    patched = False
    for raw_item in raw_output:
        if (
            not patched
            and raw_item.get("type") == "message"
            and raw_item.get("role") == "assistant"
        ):
            new_content_parts: list[dict[str, Any]] = []
            text_seen = False
            for part in raw_item.get("content") or []:
                if part.get("type") == "output_text" and not text_seen:
                    new_content_parts.append({**part, "text": stripped})
                    text_seen = True
                elif part.get("type") == "output_text":
                    # Secondary text parts: blanked so total text matches
                    # the stripped aggregate (no duplicate sentinels).
                    new_content_parts.append({**part, "text": ""})
                else:
                    new_content_parts.append(part)
            out.append(
                {
                    **raw_item,
                    "content": new_content_parts,
                    "_attachments": refs,
                }
            )
            patched = True
        else:
            out.append(raw_item)
    return out


# ── Mid-run injection helpers ───────────────────────────────────────────────
#
# See design/features/mid-run-injection.md §5.2 (lifecycle), §5.3 (drain),
# §5.4 (sticky deferred), §5.14 (size cap). Pure functions deliberately —
# no AgentLoop state — so unit tests can call them directly.

# D14: per-message size cap. ~64KB text at 4 chars/token approximation.
MAX_MID_RUN_TOKENS = 16384

# Per-session mid-run inbox cap. Without a bound, a buggy client (or
# someone holding the Send key) can grow ``_mid_run_inbox[sid]``
# without limit during a long-running turn — independent of the bus
# inbound queue's own bound. 100 is generous for legitimate
# follow-ups during a single turn while keeping memory bounded.
# Overflow → ``MID_RUN_DROPPED reason=inbox_full``.
MAX_MID_RUN_INBOX_PER_SESSION = 100


# ``_portable_attachments`` lives in ``workpilot/security/attachments``
# (as ``portable_attachments``) — re-exported here under the old name
# so existing call sites in this module don't need to change. New
# importers should use the public name from the security module.
_portable_attachments = _security_portable_attachments


# Word-boundary-safe /next prefix. Matches `/next` followed by ≥1 whitespace
# (space / tab / newline). Does NOT match `/nexts do thing` because there's
# no whitespace between `next` and `s`. See E23, T23.
# Case-insensitive — slash commands elsewhere are lowercased before
# dispatch (``_handle_slash``), so ``/Queue do X`` / ``/QUEUE do X``
# should normalise to deferred just like the lowercase form.
_NEXT_PREFIX_RE = re.compile(r"^/next\s+", re.IGNORECASE)


def _msg_id(msg: InboundMessage) -> str:
    """Return a stable per-message identifier.

    Channel-stamped ``metadata.msg_id`` wins. Otherwise synthesise from
    **immutable** fields (channel + channel_id + sender_id + timestamp) —
    NEVER from ``content``, so the id stays stable across content mutations
    (e.g. ``/next`` prefix stripping by ``_normalize_next_prefix``). Caches
    the synthesised id back onto ``metadata.msg_id`` so all subsequent calls
    return the same value (E15, E24, T15, T24).
    """
    if msg.metadata is None:
        msg.metadata = {}
    if mid := msg.metadata.get("msg_id"):
        return str(mid)
    # When ``msg.timestamp`` is missing, the deterministic seed
    # (channel + channel_id + sender_id) would collide for any two
    # messages from the same sender/channel/channel_id — and
    # InboundMessage.timestamp IS optional. Fall back to a fresh UUID
    # in that case to guarantee uniqueness; channels that DO supply a
    # timestamp keep getting the deterministic id (which is useful for
    # cross-process / replay scenarios).
    if not msg.timestamp:
        h = uuid.uuid4().hex[:16]
    else:
        seed = f"{msg.channel}|{msg.channel_id}|{msg.sender_id}|{msg.timestamp}"
        h = hashlib.sha1(seed.encode("utf-8"), usedforsecurity=False).hexdigest()[:16]
    msg.metadata["msg_id"] = h
    return h


def _normalize_next_prefix(msg: InboundMessage) -> None:
    """Strip ``/next <payload>`` prefix and set sticky deferred flag.

    Properties (D4, §5.4):

    - **Idempotent** — already-deferred messages (re-pushed from bus) pass
      through unchanged.
    - **Liberal whitespace separator** — space, tab, newline; ``/next\\nfoo``
      is valid (T22).
    - **Word-boundary safe** — ``/nexts do thing`` is NOT this slash; routes
      through the regular slash dispatcher (T23).
    - **Empty-payload exception** — ``/next`` alone or with whitespace-only
      payload is left intact so ``_handle_slash`` shows a usage hint (T19).
    """
    if msg.metadata is None:
        msg.metadata = {}
    if msg.metadata.get("deferred"):
        return  # idempotent — already normalised on a prior pass
    content = msg.content or ""
    m = _NEXT_PREFIX_RE.match(content)
    if not m:
        return
    payload = content[m.end() :].strip()
    if not payload:
        return  # empty payload — fall through to slash dispatcher (E19)
    # Stash the literal input the user typed before stripping. The
    # frontend's locally-rendered bubble shows "/next X"; if the
    # browser refreshes mid-flight, the handshake snapshot needs the
    # raw form to rehydrate the placeholder bubble identically (the
    # design doc commits to preserving the literal /next prefix in
    # the bubble — only the LLM-facing payload gets stripped).
    msg.metadata["_raw_content"] = content
    msg.content = payload
    msg.metadata["deferred"] = True


def _is_steerable(msg: InboundMessage) -> bool:
    """Drain selection rule (D13).

    Steerable iff: (has non-trivial text content OR has at least one
    attachment) AND not starting with ``/`` AND not carrying the sticky
    ``deferred`` flag. Slashes are held for turn-end re-push so they run
    as their own turn through the regular slash dispatcher.
    """
    if (msg.metadata or {}).get("deferred"):
        return False
    text = (msg.content or "").strip()
    if text.startswith("/"):
        return False
    has_atts = bool(msg.attachments)
    return bool(text) or has_atts


def _truncate_oversized(content: str) -> str:
    """Per-message size cap (D14).

    If ``content`` exceeds ``MAX_MID_RUN_TOKENS``, truncate with a trailing
    ``[truncated: N more tokens]`` marker. The drain proceeds with the
    truncated content; the marker is what the LLM sees and what gets
    persisted to JSONL. The client's local user bubble is not updated
    in-place (MID_RUN_* events don't carry replacement content), so
    the marker only becomes visible to the user after a refresh /
    reload that re-renders from JSONL. (E29, T28.)

    Cost discipline: ``estimate_tokens`` runs the actual tokeniser, so
    calling it on a multi-MB paste is a CPU-time DoS vector. The upper
    bound keeps that case bounded:

      * ``len >= MAX_TOKENS * 8`` → 8 chars/token is a generous upper
        bound on tokeniser density; clearly over cap, go straight to
        truncate without tokenising.
      * Otherwise → run the precise tokeniser check (bounded input).

    Note: a naïve ``len <= MAX_TOKENS`` lower-bound is NOT safe — a
    single emoji or some CJK codepoints can tokenise to multiple
    tokens (1 char → 2-4 tokens for ``cl100k_base``-style BPE), so a
    short string of token-dense glyphs could otherwise bypass the cap.
    """
    # 4 chars/token is the standard approximation; keep the head, drop tail.
    keep_chars = MAX_MID_RUN_TOKENS * 4
    # Cheap upper bound — clearly oversized content (8x the cap by
    # chars) can skip the precise estimate and head straight to the
    # truncation path. 8 chars/token is conservative (real density is
    # ~3–4); anything over that is essentially guaranteed to exceed.
    if len(content) >= MAX_MID_RUN_TOKENS * 8:
        head = content[:keep_chars]
        extra_tokens = (len(content) - keep_chars + 3) // 4
        logger.warning("mid-run message truncated: ~{} tokens dropped", extra_tokens)
        return f"{head}\n\n[truncated: {extra_tokens} more tokens]"
    # Bounded input — run the precise tokeniser check.
    if estimate_tokens([{"role": "user", "content": content}]) <= MAX_MID_RUN_TOKENS:
        return content
    head = content[:keep_chars]
    tail = content[keep_chars:]
    # Use the cheap 4-chars/token approximation for the tail count
    # too — the marker is a hint to the user, factor-of-2 precision is fine.
    extra_tokens = (len(tail) + 3) // 4
    logger.warning("mid-run message truncated: ~{} tokens dropped", extra_tokens)
    return f"{head}\n\n[truncated: {extra_tokens} more tokens]"


class AgentLoop:
    """
    Main agent loop. Consumes inbound messages from the bus,
    runs the LLM+tool loop, publishes outbound responses.
    """

    def __init__(
        self,
        *,
        config: AgentConfig,
        provider: LLMProvider,
        tool_registry: ToolRegistry,
        bus: MessageBus,
        session_manager: SessionManager,
        audit: AuditLogger,
        workspace: Path,
        hooks: HookManager | None = None,
        available_agents: dict | None = None,
        prompt_mode: Literal["full", "minimal"] = "full",
        skills: list | None = None,
        skill_loader: SkillLoader | None = None,
        skills_config: SkillsConfig | None = None,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        mcp_configs: dict | None = None,
        memory: AgentMemory | None = None,
        bridge_service: BridgeService | None = None,
    ) -> None:
        self._config = config
        self._provider = provider
        self._tools = tool_registry
        self._bus = bus
        self._sessions = session_manager
        self._audit = audit
        self._workspace = workspace
        self._prompt_mode = prompt_mode
        self._skill_loader = skill_loader
        self._skills_config = skills_config or SkillsConfig()
        self._memory = memory or AgentMemory()
        self._context = ContextBuilder(
            config,
            workspace,
            available_agents=available_agents,
            tool_registry=tool_registry,
            mcp_configs=mcp_configs,
            memory=self._memory,
            skill_loader=skill_loader,
            skills_config=self._skills_config,
        )
        # Backward compat: also set _skills if passed directly
        if skills and not skill_loader:
            self._context.set_skills(skills)
        self._hooks = hooks
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._bridge_service = bridge_service
        self._running = False
        self._interrupt = InterruptController()
        # Consecutive fallback tracking — persists across run_once calls so the
        # agent can detect a persistently unavailable primary model.
        self._consecutive_fallbacks = 0
        self._effective_model = config.model
        self._FALLBACK_SWITCH_THRESHOLD = 5
        self._consolidator = Consolidator(
            provider=self._provider,
            memory=self._memory,
            sessions=self._sessions,
            config=self._config,
            input_limit_fn=self._resolve_input_limit,
        )
        # Per-session buffer for outbound persistence. Fed by
        # ``_capture_for_persist`` (registered as a bus.on_outbound handler
        # by Runtime) whenever an OutboundMessage carries
        # ``metadata.source`` in ``{"notify", "delegate", "scheduler"}``.
        # Only used for captures whose session matches a currently active
        # agent turn (``_active_sessions``) — buffering preserves OpenAI's
        # ``function_call ↔ function_call_output`` adjacency when the
        # notify lands mid-tool-batch. Cross-session captures (e.g. cron
        # retargeting to a user session while no agent turn is running
        # there, or any capture outside a turn entirely) are persisted
        # immediately in the handler — they can't break adjacency because
        # their session has no tool-call in flight.
        self._pending_persist: dict[str, list[dict[str, Any]]] = {}
        # Session IDs currently being processed (a turn is in flight).
        # Owned by ``_process_message`` (interactive path via ``start()``)
        # and ``run_once`` (programmatic path) — see D8 in
        # design/features/mid-run-injection.md §5.5. Used by
        # ``_capture_for_persist`` to decide buffer-vs-immediate-persist
        # AND by ``start()`` to decide mid-run inbox vs new-turn.
        self._active_sessions: set[str] = set()
        # Per-session mid-run inbox: messages that arrived while the
        # session was already running a turn. Drained at iteration
        # boundaries inside ``_agent_loop_inner`` (§5.3); residuals
        # re-pushed to the bus on turn-end finally (§5.6).
        self._mid_run_inbox: dict[str, list[InboundMessage]] = {}
        # Detached per-session processing tasks created by
        # ``_dispatch_inbound``'s fire-and-forget path. Tracked here
        # so ``stop()`` can cancel them; auto-pruned on completion via
        # ``add_done_callback``.
        self._inflight_tasks: set[asyncio.Task[None]] = set()

    # ── Outbound persistence ─────────────────────────────────────────────
    #
    # notify tool, delegate background completions, and cron deliveries all
    # publish via ``bus.publish_outbound``. Those messages reach the user
    # through the channel's push queue (WS for web, stdout for CLI) but
    # never land in the session JSONL — so a browser refresh loses them.
    # The handler below buffers such outbounds per-session; the agent loop
    # flushes the buffer at deterministic points so the JSONL matches what
    # the user saw, and future LLM turns are aware of prior notifications.

    async def _capture_for_persist(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Bus handler: persist notify/delegate/scheduler outbounds into
        the target session's JSONL so a browser refresh preserves them
        AND future LLM turns see them as events that already reached the
        user (not instructions to follow, not things the agent said).

        Routing keys:
        - ``metadata.target_session_id`` — explicit override, used by
          producers that publish across session boundaries (cron
          retargeting from ``scheduler_<job>`` to ``local_web``; notify
          tool retargeting by channel).
        - ``metadata.session_id`` — fallback, typically the originating
          session (delegate uses this since its target ``is`` the user's
          session; also covers cases where the producer didn't set a
          target explicitly).

        Storage shape (role=system with inline framing):
        ``content`` is prefixed so the LLM unambiguously reads the entry
        as "an event the user already received", not as an instruction.
        The ``_synthetic`` field drives UI-side special rendering (e.g.
        bell-badge pill instead of plain system message).

        Buffer vs. immediate persist:
        - Target session is in ``_active_sessions`` (a turn is running
          for it) → buffer; flush at POINT 2 (post-tool) / POINT 3
          (finally). Preserves ``function_call ↔ function_call_output``
          adjacency when a capture lands mid-tool-batch.
        - Otherwise → persist inline. No tool pair in flight, so
          adjacency can't be broken. Covers cron message/tool-mode (no
          turn), cron retargeting to an idle user session, delegate
          completions arriving after the originating turn ended.
        """
        if not isinstance(msg, OutboundMessage):
            return  # StreamingChunk — not a discrete user-visible message
        meta = getattr(msg, "metadata", None) or {}
        src = meta.get("source")
        if src not in NOTIFICATION_SOURCES:
            return
        sid = meta.get("target_session_id") or meta.get("session_id")
        if not sid:
            return
        # Normalise BEFORE the _active_sessions check and before using
        # the id as a buffer key / add_message arg. Producers may stamp
        # either raw (``web_web-user``) or canonical (``local_web``)
        # forms, and ``_agent_loop`` also adds whatever session_id it
        # received to ``_active_sessions``. Without this normalise step
        # an active-but-raw session would be treated as inactive —
        # persisting mid-tool-batch and breaking function_call ↔
        # function_call_output adjacency on the next reload.
        sid = self._sessions._normalize_id(sid)
        # Inline framing shared with WebChannel.send via
        # ``bus.events.frame_notification``. Single source of truth:
        # push-frame parser + JSONL parser see byte-identical content,
        # and the "LLM reads past-event, not new instruction" framing
        # contract can't drift between the two sites.
        #
        # Resolve ``_ts`` ONCE and pin it into the metadata we pass to
        # the framing helper. If a producer forgot to stamp ``_ts``,
        # we'd otherwise call ``datetime.now()`` twice (once for the
        # entry's ``_ts`` field, once inside ``frame_notification``)
        # and the two values could differ by a millisecond — the
        # correlation key used by the toast-click scroll handler
        # would then not match the ``data-notification-ts`` on the
        # inline card. Pinning here keeps the two in lockstep.
        ts = meta.get("_ts") or datetime.now(UTC).isoformat()
        framing_meta = {**meta, "_ts": ts}
        origin = meta.get("_origin") or src
        raw = msg.content or ""
        framed = frame_notification(raw, framing_meta)
        entry: dict[str, Any] = {
            "role": "system",
            "content": framed,
            "_synthetic": src,
            "_origin": origin,
            "_channel": str(getattr(msg, "channel", "") or ""),
            "_ts": ts,
        }
        # Persist outbound attachment refs as a sidecar so a browser reload
        # can re-render the image/file chip on the notification card.
        # Bytes never go into JSONL — too large, and they already live in the
        # content-addressed store under ``~/.workpilot/data/attachments``
        # (self-hosted: refetched via ``GET /api/attachments/<sha>``; Cloud:
        # via ``GET /chat/attachment/<sha>`` which tunnels to the client).
        #
        # Today's only producer is the markdown-hoist path (``extract_outputs``
        # populates ``msg.attachments`` with pre-resolved ref dicts before
        # ``publish_outbound``). The sha-string branch below is defensive —
        # any future producer that emits raw shas (e.g. an internal admin
        # tool) is handled the same way without bytes hitting the JSONL.
        raw_atts = getattr(msg, "attachments", None)
        if raw_atts:
            from workpilot.security.attachments import load_ref

            att_refs: list[dict[str, Any]] = []
            for a in raw_atts:
                ref_dict: dict[str, Any] | None = None
                if isinstance(a, str):
                    # Normalise case here even though ``load_ref`` does
                    # the same internally — makes the expectation
                    # explicit at the call site and consistent with
                    # other sha-handling spots (e.g. ``_on_attachment_fetch``).
                    ref = load_ref(a.lower())
                    if ref is not None:
                        ref_dict = {
                            "sha256": ref.sha256,
                            "content_type": ref.content_type,
                            "size": ref.size,
                            "kind": ref.kind,
                        }
                        if ref.name:
                            ref_dict["name"] = ref.name
                elif isinstance(a, dict) and a.get("sha256"):
                    ref_dict = {
                        k: a[k]
                        for k in ("sha256", "content_type", "size", "name", "kind")
                        if k in a and a[k] is not None
                    }
                if ref_dict:
                    att_refs.append(ref_dict)
            if att_refs:
                entry["_attachments"] = att_refs
        if sid in self._active_sessions:
            # Active turn — buffer for adjacency-safe flush at POINT 2/3.
            self._pending_persist.setdefault(sid, []).append(entry)
        else:
            # No active turn — persist directly. No tool_call/tool_result
            # pair in flight for this session, so adjacency can't be broken.
            self._sessions.add_message(sid, entry)

    def _flush_persist(
        self,
        session_id: str,
        items: list[dict[str, Any]] | None,
    ) -> None:
        """Drain pending persist buffer for ``session_id``.

        Always writes to session JSONL; also appends to ``items`` when the
        caller owns an in-memory LLM context list (post-tool flush). Pop
        semantics keep the call idempotent across multiple flush points.
        """
        entries = self._pending_persist.pop(session_id, [])
        for entry in entries:
            self._sessions.add_message(session_id, entry)
            if items is not None:
                items.append(entry)

    def _drain_mid_run(self, sid_canonical: str, items: list[dict[str, Any]]) -> bool:
        """Drain steerable mid-run inbox messages into ``items`` at an
        iteration boundary.

        Returns ``True`` if at least one message was injected — the caller
        uses this to decide whether to apply the D12 iteration-ceiling
        doubling (once per turn).

        Per-message guards (§5.3):
        - non-steerable messages (slash, deferred) stay in the inbox until
          the turn-end finally re-pushes them to bus
        - steerable messages are size-capped via ``_truncate_oversized``
          (D14) and persisted to JSONL at injection time (§5.9)
        - persist failures are logged but do NOT roll back partial state
          (D15) — the assistant persist later in the iteration would also
          fail on a session-wide IO problem

        Emits ``MID_RUN_INJECTED`` once per successful drain with the
        injected msg_ids and residual ``inbox_depth_after``.
        """
        inbox = self._mid_run_inbox.get(sid_canonical) or []
        if not inbox:
            return False
        # Single-pass classification preserves arrival order across types
        # (E21): non-steerable items that come before steerable ones still
        # stay before them in the residual inbox.
        leftover: list[InboundMessage] = []
        steerable: list[InboundMessage] = []
        for m in inbox:
            (steerable if _is_steerable(m) else leftover).append(m)
        if not steerable:
            # All inbox content was non-steerable — keep order, exit.
            self._mid_run_inbox[sid_canonical] = leftover
            return False

        injected_ids: list[str] = []
        for m in steerable:
            content = _truncate_oversized(m.content or "")
            entry: dict[str, Any] = {
                "role": "user",
                "content": content,
                "_mid_run": True,
                "_msg_id": _msg_id(m),
                "_ts": datetime.now(UTC).isoformat(),
            }
            if m.attachments:
                # Strip non-portable fields (notably absolute ``path``)
                # before writing to JSONL — see _portable_attachments
                # docstring for the security rationale.
                portable = _portable_attachments(m.attachments)
                if portable:
                    entry["_attachments"] = portable
            items.append(entry)
            # Append to injected_ids BEFORE persistence — the LLM
            # context (items) is the source of truth for "this message
            # was injected" per D15 (log-and-continue persist semantics).
            # If we appended only on persist success, a JSONL IO failure
            # would leak a model-saw-it / event-omitted-it divergence:
            # the chip would stay "queued" forever while the model
            # already responded to the message. Persist failure is
            # logged but never rolls back the injection (D15).
            injected_ids.append(_msg_id(m))
            try:
                self._sessions.add_message(sid_canonical, entry)
            except Exception as exc:  # D15: log + continue, no rollback
                logger.warning("mid-run persist failed for {}: {}", _msg_id(m), exc)

        # Update inbox to reflect what we consumed.
        self._mid_run_inbox[sid_canonical] = leftover

        if injected_ids:
            self._bus.events.emit(
                EventType.MID_RUN_INJECTED,
                {
                    "session_id": sid_canonical,
                    "msg_ids": injected_ids,
                    "count": len(injected_ids),
                    "inbox_depth_after": len(leftover),
                },
            )
        return bool(injected_ids)

    async def start(self) -> None:
        """Bus consumer for inbound messages.

        Routing fork (see design/features/mid-run-injection.md §5.1):
        - **Idle session** → claim seat synchronously, fire-and-forget
          ``_process_message`` as a background task. The task must NOT
          be awaited here; awaiting would serialise inbound consumption
          and prevent the next mid-run from being routed to inbox.
        - **Active session** → append to per-session mid-run inbox,
          emit ``MID_RUN_QUEUED``. The active turn's drain at the next
          iteration boundary will inject steerable items.

        Concurrency note: the seat-claim (``_active_sessions.add``)
        happens synchronously in this coroutine before ``create_task``,
        so a follow-up message arriving in the next ``get_inbound`` is
        guaranteed to observe the session as active (E8). No locking
        needed (D6 — single-threaded asyncio event loop).
        """
        self._running = True
        logger.info(f"Agent loop started (model={self._config.model})")
        while self._running:
            try:
                msg = await asyncio.wait_for(self._bus.get_inbound(), timeout=1.0)
            except TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error(f"Agent loop bus consume error: {exc}")
                continue

            try:
                self._dispatch_inbound(msg)
            except Exception as exc:
                logger.error(f"Agent loop dispatch error: {exc}")

    def _dispatch_inbound(self, msg: InboundMessage) -> None:
        """Route an inbound message: mid-run inbox vs fresh turn.

        Synchronous on purpose — there must be NO ``await`` between
        bus dequeue and ``_active_sessions.add`` (E8 race-free
        invariant). ``create_task`` is fire-and-forget; the task itself
        owns the seat lifecycle in its ``try/finally`` (§5.6).
        """
        # Normalise channel + ingress mutation. Idempotent on bus re-pushes.
        msg.channel = ChannelType.of(msg.channel)  # type: ignore[assignment]
        _msg_id(msg)  # ensure metadata.msg_id present (E15)
        _normalize_next_prefix(msg)  # /next strip + sticky deferred (D4)

        sid_canonical = self._sessions._normalize_id(
            msg.session_key
            or msg.session_id
            or self._sessions.get_or_create_id(msg.channel, msg.sender_id)
        )

        if sid_canonical in self._active_sessions:
            # Mid-run path — append to inbox, emit QUEUED.
            inbox = self._mid_run_inbox.setdefault(sid_canonical, [])
            if len(inbox) >= MAX_MID_RUN_INBOX_PER_SESSION:
                # Cap reached — drop the new message and tell the
                # frontend so the chip can show "canceled (inbox_full)".
                # Logged at WARNING because this implies either client
                # misuse or a genuine pathological scenario; not a
                # routine occurrence.
                logger.warning(
                    "mid-run inbox full for {} (cap={}), dropping incoming msg_id={}",
                    sid_canonical,
                    MAX_MID_RUN_INBOX_PER_SESSION,
                    _msg_id(msg),
                )
                # ``depth`` is still at cap — only the INCOMING message
                # was dropped. Other DROPPED reasons (interrupted,
                # bus_full at re-push) DO empty the inbox; the absence
                # of ``depth`` on those payloads tells consumers to
                # reset to 0. Carrying it here lets the composer status
                # strip / CLI toolbar keep an accurate count instead of
                # zeroing out under what is effectively backpressure.
                self._bus.events.emit(
                    EventType.MID_RUN_DROPPED,
                    {
                        "session_id": sid_canonical,
                        "msg_ids": [_msg_id(msg)],
                        "count": 1,
                        "reason": "inbox_full",
                        "depth": len(inbox),
                    },
                )
                return
            inbox.append(msg)
            # NOTE: deliberately NO ``preview`` field. The web gateway
            # relays MID_RUN_* events to browser WS clients, and a
            # content-derived preview would leak the user's message
            # snippet to any other connection that happened to be
            # subscribed. Frontends correlate by ``msg_id`` and render
            # from their own local user-bubble content; they don't need
            # the server to echo it back.
            self._bus.events.emit(
                EventType.MID_RUN_QUEUED,
                {
                    "session_id": sid_canonical,
                    "msg_id": _msg_id(msg),
                    "depth": len(self._mid_run_inbox[sid_canonical]),
                    # ``deferred=True`` for ``/next X`` messages so the
                    # frontend chip jumps directly to "next turn" instead
                    # of flashing "queued" briefly first. Without this,
                    # the chip transitions queued → deferred only when
                    # turn-end MID_RUN_DEFERRED fires, which is several
                    # seconds late if the agent is mid-tool-call.
                    "deferred": bool((msg.metadata or {}).get("deferred")),
                },
            )
            return

        # Idle path — claim seat synchronously, then fire-and-forget.
        self._active_sessions.add(sid_canonical)
        # Promoted: a deferred message becomes a fresh-turn primary.
        # Covers both /next ingress-deferred and regular fall-through
        # (which finally also marks deferred=True).
        if (msg.metadata or {}).get("deferred"):
            self._bus.events.emit(
                EventType.MID_RUN_PROMOTED,
                {"session_id": sid_canonical, "msg_id": _msg_id(msg)},
            )
        # Track the detached task so ``stop()`` can cancel + await it
        # on shutdown. Without this, an in-flight per-session turn
        # keeps running tools / writing JSONL / emitting outbound
        # AFTER the runtime tries to quiesce the agent.
        task = asyncio.create_task(self._process_message_safe(msg, sid_canonical))
        self._inflight_tasks.add(task)
        # Auto-prune on completion so the set doesn't grow unbounded.
        task.add_done_callback(self._inflight_tasks.discard)

    async def _process_message_safe(self, msg: InboundMessage, sid_canonical: str) -> None:
        """Wrapper guarantees seat is released even if ``_process_message``
        raises before its own finally runs (e.g. exception in the
        normalisation prelude). The seat was claimed synchronously by
        ``_dispatch_inbound`` so we own the cleanup if we crash early."""
        try:
            await self._process_message(msg)
        except Exception:
            logger.exception("agent _process_message crashed")
            # Defensive cleanup if _process_message's own finally never ran.
            self._active_sessions.discard(sid_canonical)
            self._mid_run_inbox.pop(sid_canonical, None)

    async def stop(self) -> None:
        self._running = False
        # Cancel + await any per-session processing tasks the
        # ``_dispatch_inbound`` fire-and-forget path created. Without
        # this, those tasks survive shutdown and can run tools, write
        # JSONL, and emit outbound long after the agent is supposed to
        # be quiet — manifesting as orphaned writes / surprise replies
        # to dead WS clients.
        if self._inflight_tasks:
            tasks = list(self._inflight_tasks)
            for task in tasks:
                task.cancel()
            # Brief drain — give cancelled coroutines a chance to run
            # their finally blocks (release seats, flush persists).
            # The wait_for cap keeps shutdown bounded: if a task is
            # stuck in non-cancellable I/O, we'd otherwise hang here
            # indefinitely. 5s is plenty for the normal cooperative-
            # cancel path; on timeout we log + drop the still-pending
            # tasks so the runtime can finish tearing down.
            try:
                await asyncio.wait_for(
                    asyncio.gather(*tasks, return_exceptions=True),
                    timeout=5.0,
                )
            except TimeoutError:
                pending = [t for t in tasks if not t.done()]
                logger.warning(
                    "agent.stop(): {} task(s) still pending after 5s drain — abandoning",
                    len(pending),
                )
            self._inflight_tasks.clear()

    def interrupt(self, session_id: str) -> bool:
        """Signal the agent to stop processing the current turn for a session.

        Called by channels (CLI, Web, Cloud) to request cooperative interruption.
        Returns True if the session was actively being processed.

        Bridge-aware: when the session is bridged and has an in-flight
        dispatch, cancel that task directly. Bridge doesn't poll the
        cooperative interrupt event (it wraps a blocking SDK await that
        wouldn't yield to check a flag), so the signal alone wouldn't
        abort the turn — we have to hit the task itself. The session
        stays bridged; only the current turn is cancelled, which is
        what the user wants from ``/cancel`` (``/estop`` is the escape
        hatch that exits bridge entirely).
        """
        signaled = self._interrupt.signal(session_id)
        bridge_cancelled = False
        if self._bridge_service is not None:
            state = self._bridge_service.get_state(session_id)
            if state is not None and state.current_task is not None:
                if not state.current_task.done():
                    state.current_task.cancel()
                    bridge_cancelled = True
        # §5.7 — interrupt drops the per-session mid-run inbox synchronously
        # (no re-push to bus; interrupt semantically retracts intent).
        sid_canonical = self._sessions._normalize_id(session_id)
        discarded = self._mid_run_inbox.pop(sid_canonical, [])
        if discarded:
            self._bus.events.emit(
                EventType.MID_RUN_DROPPED,
                {
                    "session_id": sid_canonical,
                    "msg_ids": [_msg_id(m) for m in discarded],
                    "count": len(discarded),
                    "reason": "interrupted",
                },
            )
        if signaled or bridge_cancelled:
            self._bus.events.emit(
                EventType.AGENT_INTERRUPTED,
                {"session_id": session_id, "reason": "user_request"},
            )
        return signaled or bridge_cancelled

    def _check_interrupt(self, session_id: str) -> bool:
        """Non-blocking check. Returns True if interrupt is pending."""
        return self._interrupt.check(session_id)

    def _finalize_interrupt(
        self,
        session_id: str,
        items: list[dict[str, Any]],
    ) -> None:
        """Clean up after an interrupt: persist marker, clear flag."""
        marker: dict[str, Any] = {
            "role": "system",
            "content": "[Interrupted by user]",
        }
        items.append(marker)
        self._sessions.add_message(session_id, marker)
        self._interrupt.clear(session_id)
        logger.info("Agent interrupted for session {}", session_id)

    async def run_once(
        self,
        prompt: str,
        session_id: str | None = None,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        reasoning_effort_override: str | None = None,
    ) -> str:
        """Run a single prompt through the agent (for CLI/API use).

        Programmatic path — manages the active-session seat itself per
        D8 (the seat lifecycle moved out of ``_agent_loop`` so the
        interactive ``_process_message`` path could own it; programmatic
        callers like this one re-acquire it locally). The mid-run inbox
        stays empty here because no ``start()`` consumer is publishing.

        ``reasoning_effort_override`` bypasses the agent's configured
        ``reasoning_effort`` for this call only (e.g. cron jobs auto-select
        medium/high/xhigh from schedule frequency × prompt length; heartbeat
        sets it dynamically from active section count).
        """
        sid = session_id or self._sessions.get_or_create_id(ChannelType.CLI, "local")
        logger.info(f"run_once: channel={channel or 'cli'} session={sid}")
        sid_canonical = self._sessions._normalize_id(sid)
        self._active_sessions.add(sid_canonical)
        try:
            response, _streamed, _refs = await self._agent_loop(
                prompt,
                sid,
                channel=channel,
                channel_id=channel_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
                reasoning_effort_override=reasoning_effort_override,
            )
            return response
        finally:
            self._active_sessions.discard(sid_canonical)
            # Defensive — inbox should be empty (no consumer feeding it),
            # but pop ensures no leak if a test calls run_once on a
            # session that had stale state.
            self._mid_run_inbox.pop(sid_canonical, None)

    # ── Typing indicators ───────────────────────────────────────────────

    def _start_typing(
        self,
        channel: ChannelType | None,
        channel_id: str | None,
        metadata: dict | None = None,
    ) -> TypingController | None:
        """Create and start a typing controller.  Returns None for CLI."""
        from workpilot.agent.typing import TypingController

        if not channel or not channel_id or channel == ChannelType.CLI:
            return None

        ctrl = TypingController(self._bus.events, channel, channel_id, metadata)
        ctrl.start()
        return ctrl

    # ── Slash commands ────────────────────────────────────────────────────

    # Slashes WorkPilot owns while bridged. Two kinds live in this set,
    # for different reasons:
    #
    #   1. Runtime controls — /bridge, /estop, /reset, /cancel — are
    #      WorkPilot semantics that have no SDK counterpart; they always
    #      belong to us.
    #
    #   2. Reinterpreted CLI slashes — /model, /new, /clear, /help — the
    #      SDK transports (claude-agent-sdk, github-copilot-sdk) don't
    #      proxy the external CLI's native slash commands. Typed as a
    #      prompt they either land silently (Claude) or produce a
    #      misleading AI-rendered reply (Copilot). WorkPilot intercepts
    #      and routes each to a dedicated handler — see the bridge-mode
    #      dispatcher block at the top of _handle_slash.
    #
    # Slashes that the SDK DOES proxy correctly (/cost, /compact on the
    # Claude SDK) are deliberately NOT in this set — they pass through
    # verbatim and the CLI handles them natively. Exit aliases
    # (/exit /quit /bye) are rewritten to /bridge off before this gate
    # runs.
    _BRIDGED_RESERVED_SLASHES: frozenset[str] = frozenset(
        {
            "/bridge",
            "/estop",
            "/reset",
            "/cancel",
            "/model",
            "/new",
            "/clear",
            "/help",
        }
    )

    # Target-verb aliases for ``/bridge <verb>``. ``cc`` short for Claude
    # Code, ``gh`` / ``github`` short for GitHub Copilot. Keys are the
    # lowercased verb the user typed; values are the canonical target
    # name accepted by ``BridgeService.toggle``.
    _BRIDGE_VERB_ALIASES_MAP: dict[str, str] = {
        "cc": "claude",
        "gh": "copilot",
        "github": "copilot",
    }

    # Manifest description suffixes (``commands[].description`` with the leading
    # ``"{title} "`` stripped). Some Teams clients send ``title + " " + description``
    # on a button tap; normalization in ``_handle_slash`` strips the suffix so both
    # shapes reach the same dispatcher path. See ``_strip_command_description``.
    _TEAMS_COMMAND_DESCRIPTIONS: dict[str, str] = {
        "/new": "Clear session and start fresh",
        "/status": "Show agent status and session info",
        "/help": "Show all available commands",
        "/estop": "Emergency stop — halt all activity",
        "/tools": "List available tools",
        "/skills": "List loaded skills",
        "/model": "Show or switch LLM model",
        "/bridge": "[target] Hand the session to Claude Code or GitHub Copilot CLI",
        "/cancel": "Interrupt the current operation",
        "/compact": "Trigger context compaction",
    }

    @classmethod
    def _strip_command_description(cls, verb: str, arg: str) -> str:
        """Strip a leading manifest ``description`` prefix from ``arg``.

        Some Teams clients send ``title + " " + description`` for a
        button tap; others send ``title`` only. If ``arg`` begins with
        the manifest description for ``verb`` (case-insensitive), peel
        it off so both client shapes converge on the same dispatcher
        path. Returns ``arg`` unchanged when no match is found.
        """
        description = cls._TEAMS_COMMAND_DESCRIPTIONS.get(verb)
        if not description:
            return arg
        stripped = arg.strip()
        # Slice the original ``stripped`` by ``len(description)`` (not the
        # casefolded length) because casefold can expand codepoints (e.g. ``ß``→``ss``).
        if not stripped.casefold().startswith(description.casefold()):
            return arg
        remainder = stripped[len(description) :]
        # Word-boundary guard: don't eat a full-description match that continues
        # immediately into another token (e.g. ``Show or switch LLM modelX``).
        if remainder and not remainder[:1].isspace():
            return arg
        return remainder.strip()

    @staticmethod
    def _parse_slash_args(arg: str) -> tuple[list[str], dict[str, str]]:
        """Parse slash command arguments into positional tokens and key=value pairs.

        Supports both forms:
          positional   — ``gpt-4o high``         → (["gpt-4o", "high"], {})
          key=value    — ``gpt-4o effort=high``   → (["gpt-4o"], {"effort": "high"})
          mixed        — ``gpt-4o effort=high``   → (["gpt-4o"], {"effort": "high"})
          quoted       — ``"o3 mini" effort=high`` → (["o3 mini"], {"effort": "high"})

        Uses ``shlex.split`` so values containing spaces can be quoted.
        ``key=value`` tokens (containing ``=``) are separated into the dict;
        everything else becomes a positional token.

        Note: model names containing ``=`` (e.g. ``base=instruct``) must be
        quoted — ``"base=instruct"`` — otherwise the ``=`` causes them to be
        routed to the kv dict instead of positional.
        """
        import shlex

        try:
            tokens = shlex.split(arg)
        except ValueError:
            tokens = arg.split()

        positional: list[str] = []
        kv: dict[str, str] = {}
        for token in tokens:
            if "=" in token:
                k, _, v = token.partition("=")
                kv[k.lower()] = v
            else:
                positional.append(token)
        return positional, kv

    async def _handle_slash(self, cmd: str, session_id: str, msg: InboundMessage) -> str | None:
        """Handle REPL slash commands. Returns reply string or None if not a known command."""

        parts = cmd.split(maxsplit=1)
        verb = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        # Cross-Teams-version normalization: collapse ``title + description``
        # button taps onto the same path as ``title``-only taps. See the
        # ``_TEAMS_COMMAND_DESCRIPTIONS`` docstring for the rationale.
        arg = self._strip_command_description(verb, arg)

        # Bridged-session slash passthrough gate. Exit aliases are rewritten
        # below (they need to run even while bridged). Everything outside
        # the reserved set falls through to the bridge target verbatim.
        if (
            self._bridge_service is not None
            and verb not in ("/exit", "/quit", "/bye")
            and verb not in self._BRIDGED_RESERVED_SLASHES
            and self._bridge_service.is_bridged(session_id)
        ):
            return None

        # Bridge-mode slash reinterpretation. The following verbs have
        # legitimate WorkPilot-native handlers further down this method,
        # but while bridged they need different semantics because the
        # SDK doesn't proxy the CLI's own slash commands (see
        # _BRIDGED_RESERVED_SLASHES comment). Intercept early so bridge
        # handlers run instead of the WorkPilot-native ones.
        if self._bridge_service is not None and self._bridge_service.is_bridged(session_id):
            if verb == "/model":
                return await self._handle_bridge_model_slash(session_id, arg)
            if verb in ("/new", "/clear"):
                return await self._handle_bridge_fresh_slash(session_id, msg)
            if verb == "/help":
                return self._handle_bridge_help_slash(session_id)

        if verb == "/cancel":
            # Fallback: /cancel reached the queue (agent was idle when sent)
            return "Nothing to interrupt."

        if verb == "/next":
            # Reached only when the payload is empty / whitespace-only —
            # `_normalize_next_prefix` strips and routes payloaded
            # `/next X` away from this dispatcher at ingress (D4, E19).
            return (
                "Usage: `/next <message>` — defer this message to run as "
                "its own turn after the current task finishes (instead of "
                "merging into the running task)."
            )

        if verb == "/new":
            # Consolidate before clearing so no knowledge is lost
            try:
                await self._consolidator.maybe_consolidate(session_id, force=True)
            except Exception as exc:
                logger.warning("Pre-clear consolidation failed: {}", exc)
            self._sessions.clear(session_id)
            return "Session cleared. Starting fresh."

        if verb == "/compact":
            # Manual compaction trigger
            history = self._sessions.get_messages(session_id, llm_only=True)
            if len(history) < 10:
                return "Not enough messages to compact."
            try:
                # Convert native items to Chat format for client-side compaction
                from workpilot.providers.client import items_to_chat_messages

                chat_history = items_to_chat_messages(history)
                # Build system prompt + history only (no user message —
                # /compact is not a turn, just a maintenance operation)
                system_prompt = self._context.build_system_prompt(mode=self._prompt_mode)
                messages: list[dict[str, Any]] = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.extend(chat_history)
                context_limit = self._resolve_input_limit()
                tokens_before = estimate_tokens(messages)
                compacted = await compact_messages(
                    messages,
                    self._provider,
                    self._config,
                    context_limit=context_limit,
                    focus=arg,
                )
                # Replace in-memory session with compacted messages, keeping
                # the compaction summary but stripping the original system prompt
                # (which is rebuilt each turn by build_messages()).
                kept = [
                    m
                    for m in compacted
                    if m.get("role") != "system"
                    or "[Conversation summary" in (m.get("content") or "")
                ]
                self._sessions.replace_messages(session_id, kept)
                tokens_after = estimate_tokens(kept)
                self._append_compaction_audit(
                    session_id,
                    trigger="manual_compact",
                    tokens_before=tokens_before,
                    tokens_after=tokens_after,
                    messages_total=len(kept),
                    action="llm_summary",
                    consolidation_triggered=True,
                )
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
                saved = tokens_before - tokens_after
                return f"Compacted {len(history)} messages to {len(kept)}. Saved ~{saved} tokens."
            except Exception as exc:
                logger.error("Manual compaction failed: {}", exc)
                return f"Compaction failed: {exc}"

        # Exit aliases while bridged rewrite to /bridge off BEFORE the
        # unbridged /exit branch below — otherwise /exit would always
        # return the REPL hint and users couldn't leave bridge mode via
        # their familiar exit slashes.
        if verb in ("/exit", "/quit", "/bye") and self._bridge_service is not None:
            if self._bridge_service.is_bridged(session_id):
                summary = await self._bridge_service.exit_session(
                    session_id,
                    reason="Bridge ended by user",
                    cancel_inflight=False,
                    audit_event="bridge_user_exit",
                    suppress_channel_notice=True,
                )
                return summary or "Bridge ended."

        if verb == "/exit":
            return "Use Ctrl+C to exit the REPL."

        if verb == "/help":
            is_cli = not msg.channel or msg.channel == ChannelType.CLI
            rows = [
                "| `/new` | Clear session, start fresh |",
                "| `/compact [focus]` | Manually trigger context compaction |",
            ]
            rows += [
                "| `/next <message>` | Defer message to run after current task (skips mid-run merge) |",
                "| `/status` | Show agent status |",
                "| `/memory` | Show MEMORY.md content |",
                "| `/tools` | List available tools |",
                "| `/skills` | List available skills |",
                "| `/history [N]` | Show last N messages (default 10) |",
                r"| `/model [name [effort=level\|level]]` | Show or switch model + effort (session-only) |",
                "| `/bridge [target]` | Hand the session to Claude Code / Copilot CLI |",
                "| `/estop [reason]` | Emergency stop — halt all agent activity |",
                "| `/reset` | Reset E-stop and resume agent activity |",
            ]
            if is_cli:
                rows.append("| `/exit` | Exit hint |")
            return (
                "**Available commands:**\n\n"
                "| Command | Description |\n|---------|-------------|\n" + "\n".join(rows) + "\n"
            )

        if verb == "/status":
            msgs = self._sessions.get_messages(session_id)
            lines = [
                f"**Agent:** {self._config.name}  ",
                f"**Model:** {self._config.model}  ",
            ]
            if self._config.reasoning_effort is not None:
                lines.append(f"**Reasoning effort:** {self._config.reasoning_effort}  ")
            lines += [
                f"**Session:** {session_id}  ",
                f"**Messages:** {len(msgs)}  ",
                f"**Max iterations:** {self._config.max_iterations}",
            ]
            return "\n".join(lines)

        if verb == "/memory":
            content = self._memory.read_memory()
            return content if content.strip() else "_MEMORY.md is empty._"

        if verb == "/tools":
            tools = self._tools.list_tools()
            lines = ["**Available tools:**"]
            for t in tools:
                lines.append(f"- `{t.name}` — {t.description[:60]}")
            return "\n".join(lines)

        if verb == "/skills":
            try:
                if self._skill_loader:
                    skills = self._skill_loader.load_all()
                else:
                    skills = getattr(self._context, "_skills", None) or []
                if not skills:
                    return "_No skills loaded._"
                lines = ["**Loaded skills:**"]
                for s in skills:
                    mode_tag = f" [{s.mode}]" if hasattr(s, "mode") else ""
                    lines.append(f"- `{s.name}`{mode_tag} — {getattr(s, 'description', '')[:60]}")
                return "\n".join(lines)
            except Exception:
                return "_Skills unavailable._"

        if verb == "/history":
            n = int(arg) if arg.isdigit() else 10
            msgs = self._sessions.get_messages(session_id)
            recent = msgs[-n:]
            if not recent:
                return "_No messages in history._"
            lines = []
            for m in recent:
                role = m.get("role", "?")
                content = m.get("content") or ""
                if isinstance(content, list):
                    content = " ".join(p.get("text", "") for p in content if isinstance(p, dict))
                snippet = str(content)[:120].replace("\n", " ")
                lines.append(f"**{role}:** {snippet}")
            return "\n".join(lines)

        if verb == "/model":
            # Bridge-mode /model handling is intercepted higher up in this
            # method (see the bridge-mode dispatcher block after the
            # passthrough gate). Anything that reaches this branch is
            # NOT bridged and switches the WorkPilot LLM model instead.
            providers_cfg = getattr(self._provider, "_providers", None)

            def _format_chain(chain: list[str]) -> str:
                if not chain:
                    return "  _(empty — no provider credentials configured)_"
                return "\n".join(f"  {i + 1}. `{m}`" for i, m in enumerate(chain))

            async def _list_available() -> str:
                from workpilot.providers.resolver import list_available_models

                parts = ["\n**Aliases:** `auto` · `fast` · `reasoning` · `coding`"]
                # list_available_models makes blocking HTTP calls — offload
                # to a worker thread so the event loop stays responsive.
                models, source = (
                    await asyncio.to_thread(list_available_models, providers_cfg)
                    if providers_cfg
                    else ([], "none")
                )
                if models:
                    header = {
                        "live": f"**GitHub Copilot models** ({len(models)} — live)",
                        "catalog": f"**GitHub models** ({len(models)} — catalog fallback)",
                    }.get(source, f"**GitHub models** ({len(models)})")
                    parts.append(f"\n{header}:")
                    parts.extend(f"  - `{m}`" for m in models)
                return "\n".join(parts)

            _EFFORT_VALUES = ("low", "medium", "high", "xhigh", "auto", "none")
            _EFFORT_WITH_NULL = (*_EFFORT_VALUES, "null")

            if not arg:
                chain = resolve_model_chain(self._config.model, providers_cfg)
                effort = self._config.reasoning_effort

                # Show supported effort values for the resolved model
                from workpilot.providers.model_catalog import get_supported_reasoning_efforts

                _resolved = chain[0] if chain else self._config.model
                _supported = get_supported_reasoning_efforts(_resolved)
                if _supported is None:
                    _supported_str = "_unknown_"
                elif not _supported:
                    _supported_str = "_not supported_"
                else:
                    _supported_str = " · ".join(f"`{e}`" for e in sorted(_supported))

                effort_line = (
                    f"\n\n**Reasoning effort:** `{effort}` "
                    "_(change with `/model <name> effort=<level>` or `/model <name> <level>`)_"
                    if effort is not None
                    else (
                        "\n\n**Reasoning effort:** _not set_ "
                        "_(set with `/model <name> effort=<level>` or `/model <name> <level>`)_"
                    )
                )
                available = await _list_available()
                return (
                    f"**Current model:** `{self._config.model}`"
                    f"{effort_line}\n"
                    f"**Supported effort levels:** {_supported_str}\n"
                    f"\n**Resolution chain:**\n{_format_chain(chain)}\n"
                    f"{available}"
                )

            # /model <name> [effort=<level>|<level>]
            # Accepts both "gpt-4o high" and "gpt-4o effort=high".
            positional, kv = self._parse_slash_args(arg)
            inline_effort: str | None = (kv.get("effort") or "").lower() or None
            # Positional form: last token is a bare effort keyword (including "null")
            if not inline_effort and positional and positional[-1].lower() in _EFFORT_WITH_NULL:
                inline_effort = positional[-1].lower()
                positional = positional[:-1]
            new_model = " ".join(positional)

            if not new_model:
                valid_e = " · ".join(f"`{e}`" for e in _EFFORT_VALUES)
                return (
                    f"Usage: `/model <name> [effort=<level>|<level>]`\n"
                    f"Valid effort levels: {valid_e}, `null` (to clear)"
                )

            if inline_effort and inline_effort != "null" and inline_effort not in _EFFORT_VALUES:
                valid_e = " · ".join(f"`{e}`" for e in _EFFORT_VALUES)
                return f"Unknown effort `{inline_effort}`. Valid: {valid_e}, `null`"

            # Validate eagerly. Delegates wording to the shared helper so
            # /model rejects bare names ("not a valid `<provider>/<name>`"),
            # aliases without credentials, and prefixed IDs without creds
            # all with the same taxonomy as the provider-level error paths.
            chain = resolve_model_chain(new_model, providers_cfg)
            if not chain:
                return f"Cannot switch to `{new_model}`: {describe_resolution_failure(new_model)}"
            old_model = self._config.model
            self._config.model = new_model
            self._effective_model = new_model
            self._consecutive_fallbacks = 0
            logger.info("Model switched: {} -> {}", old_model, new_model)
            reply = (
                f"**Model switched:** `{old_model}` → `{new_model}`\n\n"
                f"**Resolution chain:**\n{_format_chain(chain)}"
            )

            if inline_effort is not None:
                from workpilot.config.schema import ReasoningEffort

                old_effort = self._config.reasoning_effort
                if inline_effort == "null":
                    self._config.reasoning_effort = None  # type: ignore[assignment]
                    reply += f"\n\n**Reasoning effort cleared** (was `{old_effort}`)"
                else:
                    self._config.reasoning_effort = ReasoningEffort(inline_effort)  # type: ignore[assignment]
                    reply += f"\n\n**Reasoning effort:** `{old_effort}` → `{inline_effort}`"
                reply += "  _Session-only._"

            # Warn if history has tool calls from the old model — cross-model
            # call IDs can cause Responses API errors on the next message.
            history = self._sessions.get_messages(session_id)
            has_tool_history = any(
                m.get("role") == "tool"
                or (m.get("role") == "assistant" and m.get("tool_calls"))
                or m.get("type") in ("function_call", "function_call_output")
                for m in history
            )
            if has_tool_history:
                reply += (
                    "\n\n⚠ History contains tool calls from the previous model."
                    " Run `/new` to clear history and avoid cross-model errors."
                )
            return reply

        if verb == "/estop":
            from workpilot.bus.events import EventType

            reason = arg or "Manual E-stop via slash command"
            # SECURITY_ESTOP_REQUEST carries user intent. Runtime routes it
            # through estop.trigger() which emits the canonical state-change
            # SECURITY_ESTOP event (action=trigger or =retrigger). Keeping
            # the two events separate means consumers that react to
            # state changes aren't spammed with every user request.
            #
            # BridgeService subscribes to SECURITY_ESTOP (see bridge.py) and
            # calls exit_all(cancel_inflight=True) from that handler — so
            # bridge teardown rides the same estop flow as every other
            # subsystem; no direct call needed here.
            self._bus.events.emit(
                EventType.SECURITY_ESTOP_REQUEST,
                {
                    "action": "request_trigger",
                    "reason": reason,
                    "actor": f"user:{msg.sender_id or 'unknown'}",
                },
            )
            return "**E-STOP ACTIVATED.** All agent activity halted. Run `/reset` to resume."

        if verb == "/reset":
            from workpilot.bus.events import EventType

            self._bus.events.emit(
                EventType.SECURITY_ESTOP_REQUEST,
                {
                    "action": "request_reset",
                    "actor": f"user:{msg.sender_id or 'unknown'}",
                },
            )
            return (
                "**E-stop reset requested.** "
                "If E-stop is active, agent activity will resume; "
                "otherwise this is a no-op."
            )

        if verb == "/bridge":
            return await self._handle_bridge_slash(arg, session_id, msg)

        # Exit aliases /exit /quit /bye while bridged are handled earlier
        # in this function (before the unbridged /exit REPL-hint branch) —
        # that's the only placement where /exit can actually reach the
        # rewrite logic instead of being swallowed by the REPL hint.

        # Unknown slash command — don't intercept, let it go to the agent
        return None

    async def _handle_bridge_slash(self, arg: str, session_id: str, msg: InboundMessage) -> str:
        """Implement the /bridge family of slashes.

        Always returns a non-None string. Returning ``None`` would cause
        ``_inner_process_message`` to treat the slash as *unhandled* and
        continue processing the same inbound as a normal user message,
        which would forward the literal slash text into the agent loop.

        Syntax:
          /bridge                — status
          /bridge off            — exit bridge mode
          /bridge claude [args]  — toggle on → Claude
          /bridge copilot [args] — toggle on → Copilot
        """
        if self._bridge_service is None:
            return "Bridge mode is not available (no BridgeService configured)."

        if not arg:
            # Shared with BridgeTool (no-target LLM call) — see
            # workpilot/agent/bridge.py::BridgeService.render_status_message.
            return await self._bridge_service.render_status_message(session_id)

        parts = arg.split()
        verb = parts[0].lower()

        # Alias expansion — short / common names map to the canonical
        # target so ``/bridge cc``, ``/bridge gh``, ``/bridge github``
        # work the same as the full verbs. Case-insensitive (verb was
        # already lowercased above).
        verb = self._BRIDGE_VERB_ALIASES_MAP.get(verb, verb)

        if verb == "off":
            if not self._bridge_service.is_bridged(session_id):
                return "You're already chatting with WorkPilot — nothing to exit."
            # Suppress the channel-side notice in exit_session; return the
            # ack string so the slash-reply path publishes it exactly once
            # AND treats the slash as handled (returning None would cause
            # _inner_process_message to fall through into the agent loop,
            # processing the literal "/bridge off" text as a user message).
            # exit_session returns the formatted summary — single source of
            # truth with the channel-publish path so both render identically.
            summary = await self._bridge_service.exit_session(
                session_id,
                reason="Bridge ended by user",
                cancel_inflight=False,
                audit_event="bridge_user_exit",
                suppress_channel_notice=True,
            )
            return summary or "Bridge ended."

        if verb in ("claude", "copilot"):
            fresh = "--fresh" in parts
            resume_id: str | None = None
            model_override: str | None = None
            for p in parts[1:]:
                if p.startswith("resume="):
                    resume_id = p.split("=", 1)[1]
                elif p.startswith("model="):
                    model_override = p.split("=", 1)[1].strip() or None
            src = (msg.metadata or {}).get("source", "") if msg.metadata else ""
            result = await self._bridge_service.toggle(
                session_id,
                target=verb,  # type: ignore[arg-type]
                channel=msg.channel,
                channel_id=msg.channel_id,
                fresh=fresh,
                resume_session_id=resume_id,
                source=str(src) if src else "",
                model=model_override,
                # Slash path = direct user intent — bypass the approval
                # prompt. The BridgeTool path (LLM-invoked) also passes
                # ``explicit_user_intent=True`` because the tool-registry
                # ApprovalGate PreToolHook has already run ``assess_risk``
                # → policy → approval before ``execute`` runs (single
                # gate entry, per design §7.1).
                explicit_user_intent=True,
            )
            return result.message

        # Unknown subcommand — show every valid form. Both SDKs are core
        # deps so every target is always a valid form.
        from workpilot.agent.bridge import BRIDGE_TARGETS

        forms = ["`/bridge`", "`/bridge off`", *[f"`/bridge {t}`" for t in BRIDGE_TARGETS]]
        return f"Unknown /bridge form: `{arg}`. Try " + ", ".join(forms) + "."

    async def _handle_bridge_model_slash(self, session_id: str, arg: str) -> str:
        """Handle ``/model`` while bridged.

        ``/model``                 — show current model + switchable options
        ``/model <name>``          — pin a specific model for this bridge
        ``/model default|off|none`` — clear the pin (pass through to CLI config)

        Only reachable via ``_handle_slash`` when the session is bridged
        (the branch above already confirmed ``is_bridged`` and
        ``_bridge_service is not None``).
        """
        assert self._bridge_service is not None  # contract: caller checked
        svc = self._bridge_service
        state = svc.get_state(session_id)
        if state is None:
            # Racey but defensive — user may have exited bridge between
            # the dispatcher's is_bridged check and this handler.
            return "Not in bridge mode — `/model` manages the bridge target's model."

        from workpilot.agent.bridge import (
            format_bridge_model_line,
            format_model_list,
            suggested_models,
            target_label,
        )

        label = target_label(state.target)
        current_label = format_bridge_model_line(state)

        if not arg:
            # Status: current + full list of switchable models. No truncation
            # — the user asked for the complete list so every model id is
            # copyable straight from the reply. ``format_model_list``
            # picks single-line vs grouped layout based on list length.
            try:
                live = await svc.list_supported_models(state.target)
            except Exception:
                live = []
            models = live if live else list(suggested_models(state.target))

            lines = [
                f"## Bridge model — {label}",
                "",
                f"**Current:** {current_label}",
            ]
            if models:
                rendered = format_model_list(models)
                if "\n" in rendered:
                    # Grouped multi-line → newline before the list.
                    lines.extend(["", "**Available:**", rendered])
                else:
                    lines.extend(["", f"**Available:** {rendered}"])
            lines.extend(
                [
                    "",
                    "Switch with `/model <name>` · Clear override with `/model default`",
                ]
            )
            return "\n".join(lines)

        new_model: str | None = arg.strip()
        if new_model and new_model.lower() in ("default", "off", "none", "unset"):
            new_model = None

        result = await svc.switch_model(session_id, new_model)
        return result.message

    async def _handle_bridge_fresh_slash(self, session_id: str, msg: InboundMessage) -> str:
        """Handle ``/new`` / ``/clear`` while bridged — restart the bridge
        with a fresh external session on the same target.

        Rationale: Claude's SDK silently no-ops these slashes; Copilot's SDK
        generates a misleading "Ready for a new task!" AI reply but keeps
        the same session id. Neither matches user intent. Intercepting and
        re-entering with ``fresh=True`` gives the real fresh-conversation
        the user asked for.

        Equivalent to ``/bridge off`` + ``/bridge <same-target> --fresh``
        in one slash.
        """
        assert self._bridge_service is not None  # contract: caller checked
        svc = self._bridge_service
        state = svc.get_state(session_id)
        if state is None:
            return "Not in bridge mode — `/new` restarts the active bridge."

        target = state.target
        src = (msg.metadata or {}).get("source", "") if msg.metadata else ""
        # Exit current bridge cleanly but suppress the channel notice —
        # the toggle re-entry below will post its own enter ack, and we
        # don't want the user to see a confusing exit-then-enter pair.
        await svc.exit_session(
            session_id,
            reason="Restarting with /new",
            cancel_inflight=False,
            audit_event="bridge_user_exit",
            suppress_channel_notice=True,
        )
        result = await svc.toggle(
            session_id,
            target=target,
            channel=msg.channel,
            channel_id=msg.channel_id,
            fresh=True,
            source=str(src) if src else "",
            explicit_user_intent=True,
        )
        return result.message

    def _handle_bridge_help_slash(self, session_id: str) -> str:
        """Handle ``/help`` while bridged — short bridge-specific command
        list. Without interception Claude replies ``"isn't available in
        this environment."`` and Copilot's AI renders generic chatter
        that doesn't match what actually works."""
        from workpilot.agent.bridge import target_label

        assert self._bridge_service is not None  # contract: caller checked
        state = self._bridge_service.get_state(session_id)
        label = target_label(state.target) if state is not None else "external CLI"
        return (
            f"## Bridge mode — help\n\n"
            f"You're talking directly to **{label}**. Every regular message "
            "is forwarded verbatim; WorkPilot is not in the middle.\n\n"
            "**Commands available while bridged:**\n"
            "- `/bridge` — show bridge status\n"
            "- `/bridge off` — return to WorkPilot\n"
            "- `/model` — list available models · `/model <name>` — switch\n"
            "- `/new` or `/clear` — restart bridge with a fresh session\n"
            "- `/estop` — emergency stop (exits every bridge in the runtime)\n"
            "- `/reset` — reset E-stop, allow bridge entry again\n"
            "- `/exit`, `/quit`, `/bye` — aliases for `/bridge off`\n"
        )

    # ── Context limit resolution ──────────────────────────────────────────

    def _resolve_input_limit(self) -> int:
        """Resolve the effective input token limit from config or model catalog.

        Returns the max input tokens (prompt ceiling), not the total context
        window.  All compaction and overflow checks use this value.
        """
        context_limit = self._config.context_limit
        if context_limit is None:
            from workpilot.providers.model_catalog import get_max_input_tokens

            chain = resolve_model_chain(
                self._effective_model, getattr(self._provider, "_providers", None)
            )
            resolved = chain[0] if chain else self._effective_model
            context_limit = get_max_input_tokens(resolved)
        return context_limit

    # ── Internal ─────────────────────────────────────────────────────────

    async def _process_message(self, msg: InboundMessage) -> None:
        """Process a single inbound message through the agent loop.

        Owns the active-session seat lifecycle (D8): seat is added on
        entry (idempotent if ``_dispatch_inbound`` already added it for
        the interactive path) and released in the finally regardless of
        whether the inner agent loop ran. Also owns the turn-end residual
        re-push so deferred mid-runs become next-turn primaries (§5.6).
        """
        # Normalize channel at the boundary — InboundMessage accepts str for
        # external callers, but all internal code uses ChannelType.
        msg.channel = ChannelType.of(msg.channel)  # type: ignore[assignment]
        # Defensive: ensure ingress normalisation has run even for direct
        # callers (tests, programmatic dispatch). Idempotent.
        _msg_id(msg)
        _normalize_next_prefix(msg)
        session_id = (
            msg.session_key
            or msg.session_id
            or self._sessions.get_or_create_id(msg.channel, msg.sender_id)
        )
        sid_canonical = self._sessions._normalize_id(session_id)

        # Per-inbound record: keep at INFO for server-side channels where
        # operators watch the stream, demote to DEBUG on CLI where the
        # line adds noise between each user turn. audit.log_message below
        # is the authoritative record and runs regardless of level.
        _log = logger.debug if msg.channel == ChannelType.CLI else logger.info
        _log(
            "Inbound: channel={} channel_id={} session={}",
            msg.channel,
            msg.channel_id,
            session_id,
        )
        self._audit.log_message(
            channel=msg.channel,
            direction="inbound",
            actor=msg.sender_id,
            session_id=session_id,
        )

        # Register session for interrupt tracking early — before any awaits
        # so /cancel can signal even during approval/slash/hook processing.
        self._interrupt.get_or_create(session_id)
        # D8: seat ownership. Idempotent — _dispatch_inbound already added
        # it for the interactive path; this line covers programmatic
        # callers (tests, run_once forwarding, etc.).
        self._active_sessions.add(sid_canonical)

        try:
            await self._inner_process_message(msg, session_id)
        finally:
            # ── §5.6 turn-end finally — five synchronous steps in order ─
            # Step 1: snapshot inbox before any other state changes.
            leftover = self._mid_run_inbox.pop(sid_canonical, [])
            # Step 2: release seat. Critical that this happens BEFORE
            # step 4 (re-push) — otherwise the consumer could dequeue a
            # residual while the session still appears active and bounce
            # it back to the inbox indefinitely (E13).
            self._active_sessions.discard(sid_canonical)
            # Step 3: existing POINT-3 outbound-persist flush.
            self._flush_persist(sid_canonical, items=None)
            # Step 4: mark every residual deferred=True and re-push.
            # Uniform marking ensures both /next messages and regular
            # mid-runs that fell through during a no-tool turn produce
            # MID_RUN_PROMOTED on dequeue (§5.6, E33).
            self._reenqueue_residuals(sid_canonical, leftover)
            # Step 5: existing interrupt cleanup.
            self._interrupt.clear(session_id)
            self._interrupt.remove(session_id)

    def _reenqueue_residuals(self, sid_canonical: str, leftover: list[InboundMessage]) -> None:
        """§5.6 step 4. Mark each residual ``deferred=True`` and re-push to
        the bus. ``MID_RUN_DEFERRED`` carries the successful subset;
        ``MID_RUN_DROPPED reason=bus_full`` carries any that the bounded
        queue rejected.
        """
        if not leftover:
            return
        deferred_ids: list[str] = []
        dropped_ids: list[str] = []
        for m in leftover:
            if m.metadata is None:
                m.metadata = {}
            m.metadata["deferred"] = True
            if self._bus.try_publish_inbound_nowait(m):
                deferred_ids.append(_msg_id(m))
            else:
                dropped_ids.append(_msg_id(m))
        if deferred_ids:
            self._bus.events.emit(
                EventType.MID_RUN_DEFERRED,
                {
                    "session_id": sid_canonical,
                    "msg_ids": deferred_ids,
                    "count": len(deferred_ids),
                },
            )
        if dropped_ids:
            self._bus.events.emit(
                EventType.MID_RUN_DROPPED,
                {
                    "session_id": sid_canonical,
                    "msg_ids": dropped_ids,
                    "count": len(dropped_ids),
                    "reason": "bus_full",
                },
            )

    async def _inner_process_message(self, msg: InboundMessage, session_id: str) -> None:
        """Inner message processing — separated so _process_message wraps with interrupt cleanup."""
        # Narrow channel type for mypy (already normalized in _process_message,
        # but InboundMessage.channel is typed ChannelType | str)
        msg.channel = ChannelType.of(msg.channel)  # type: ignore[assignment]
        if await self._try_route_approval(msg):
            return

        # Check for slash commands
        cmd = msg.content.strip()
        if cmd.startswith("/"):
            reply = await self._handle_slash(cmd, session_id, msg)
            if reply is not None:
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        channel_id=msg.channel_id,
                        content=reply,
                        thread_id=msg.thread_id,
                    )
                )
                return

        # ── Hook: on_message_received ────────────────────────────────
        if self._hooks:
            hook_ctx = MessageHookContext(
                content=msg.content,
                channel=msg.channel,
                sender_id=msg.sender_id,
                session_id=session_id,
            )
            result = await self._hooks.dispatch_checked("on_message_received", hook_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Message rejected by hook: {}", result.reason)
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        channel_id=msg.channel_id,
                        content=f"Message blocked: {result.reason}",
                        thread_id=msg.thread_id,
                    )
                )
                return
        else:
            # Fallback: inline injection check when no hooks configured
            findings = Sanitizer.check_prompt_injection(msg.content)
            if findings:
                self._audit.log_security(
                    event="prompt_injection_detected",
                    details={"findings": findings, "sender": msg.sender_id},
                    severity="warning",
                )
                logger.warning(f"Prompt injection detected from {msg.sender_id}: {findings}")

        # Start typing indicator (Teams/Cloud channels show "typing..." to the user)
        typing_ctrl = self._start_typing(msg.channel, msg.channel_id, metadata=msg.metadata)
        try:
            # Bridge mode short-circuit — if this session is bridged to an
            # external CLI (Claude / Copilot), forward the prompt directly
            # and skip _agent_loop. All message-level surfaces above still
            # ran (injection scan, on_message_received hook, audit). Bridge
            # replies don't go through the agent's output-parser image
            # hoist path, so ``attachment_refs`` is always None for this
            # branch — any attachments the external CLI emits are handled
            # by the bridge dispatcher itself.
            # See design/features/bridge-mode.md.
            bridge_state = None
            bridge_svc = self._bridge_service
            if bridge_svc is not None:
                bridge_state = await bridge_svc.ensure_state(session_id, msg)
            if bridge_state is not None and bridge_svc is not None:
                response, streamed = await bridge_svc.dispatch(msg, session_id, bridge_state)
                attachment_refs: list[dict[str, Any]] | None = None
            else:
                response, streamed, attachment_refs = await self._agent_loop(
                    msg.content,
                    session_id,
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    metadata=msg.metadata,
                    thread_id=msg.thread_id,
                    sender_id=msg.sender_id,
                    typing_ctrl=typing_ctrl,
                    attachments=msg.attachments,
                )
        except Exception as exc:
            logger.error(f"Agent loop error: {exc}")
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=f"Error: {exc}",
                    thread_id=msg.thread_id,
                )
            )
            return
        finally:
            # Stop typing indicator when response is ready (or on error)
            if typing_ctrl:
                typing_ctrl.stop()

        # ── Hook: on_message_sent ────────────────────────────────────
        # Skip when streamed — _stream_response already ran this hook.
        if self._hooks and not streamed:
            out_ctx = MessageHookContext(
                content=response,
                channel=msg.channel,
                session_id=session_id,
            )
            result = await self._hooks.dispatch_checked("on_message_sent", out_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Outbound message blocked by hook: {}", result.reason)
                response = "[Message blocked by security policy]"
                # Drop hoisted attachments too — otherwise a leak-detection
                # REJECT swaps the text but still ships the image bytes
                # (and persists them as ``_attachments`` sidecar via the
                # streaming-but-not-streamed elif below + JSONL writers).
                attachment_refs = None
            elif result.data and isinstance(result.data, MessageHookContext):
                response = result.data.content

        # Skip the full OutboundMessage when content was already streamed —
        # channels already received every token via StreamingChunks. When
        # images were hoisted on the streaming path, fire a supplementary
        # outbound with attachments only so the live bubble gets the image
        # row alongside the streamed text. JSONL sidecar was already written
        # by ``_stream_response``; the reload path renders the same image
        # via ``<AttachmentImage>`` tier-aware GET.
        if not streamed:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=response,
                    thread_id=msg.thread_id,
                    attachments=attachment_refs,
                )
            )
        elif attachment_refs and msg.channel in _INLINE_ATTACHMENT_CHANNELS:
            # Only channels with inline-image renderers receive the
            # supplementary attachments-only frame. CLI (terminal) has
            # no image renderer — delivering ``content=""`` would print
            # an empty ``assistant>`` line and silently drop the
            # attachments anyway. Web / Cloud render images inline via
            # their attachment row / inline markdown pipeline.
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content="",
                    thread_id=msg.thread_id,
                    attachments=attachment_refs,
                )
            )

        self._audit.log_message(
            channel=msg.channel,
            direction="outbound",
            actor="agent",
            session_id=session_id,
        )

    async def _agent_loop(
        self,
        user_input: str,
        session_id: str,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        thread_id: str | None = None,
        sender_id: str | None = None,
        typing_ctrl: TypingController | None = None,
        exclude_tools: list[str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort_override: str | None = None,
    ) -> tuple[str, bool, list[dict[str, Any]] | None]:
        """Thin wrapper around :meth:`_agent_loop_inner` that guarantees
        the per-session persist buffer is drained on every exit path —
        normal return, exception, asyncio cancellation.

        POINT 3 flush (interrupt-safe). ``_flush_persist`` uses pop
        semantics, so this is a no-op when POINT 2 (post-tool) has
        already drained the buffer for this session.

        D8 (mid-run): the seat lifecycle (``_active_sessions.add/discard``)
        used to live here; it has moved to the message-processing unit
        that may or may not call this loop (``_process_message`` for the
        interactive path, ``run_once`` for the programmatic path). The
        change avoids a lifecycle leak when ``_inner_process_message``
        short-circuits on a slash / hook reject / approval reject and
        never enters this wrapper. See design/features/mid-run-injection.md
        §5.5.
        """
        # Normalise the session id (used as the POINT 3 flush key) so it
        # matches whatever form the outbound-capture handler sees —
        # producers stamp the canonical form (e.g. ``local_web``) while
        # callers may still pass the raw form (``web_web-user``).
        # Without normalising, a same-session notify would be treated
        # as cross-session and persisted inline mid-tool-batch, breaking
        # function_call ↔ function_call_output adjacency on the next
        # reload. ``_capture_for_persist`` normalises on its side too.
        active_sid = self._sessions._normalize_id(session_id)
        try:
            return await self._agent_loop_inner(
                user_input,
                session_id,
                channel=channel,
                channel_id=channel_id,
                metadata=metadata,
                thread_id=thread_id,
                sender_id=sender_id,
                typing_ctrl=typing_ctrl,
                exclude_tools=exclude_tools,
                attachments=attachments,
                reasoning_effort_override=reasoning_effort_override,
            )
        finally:
            self._flush_persist(active_sid, items=None)

    async def _agent_loop_inner(
        self,
        user_input: str,
        session_id: str,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        thread_id: str | None = None,
        sender_id: str | None = None,
        typing_ctrl: TypingController | None = None,
        exclude_tools: list[str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort_override: str | None = None,
    ) -> tuple[str, bool, list[dict[str, Any]] | None]:
        """
        Core agentic loop:
        1. Build context (system + history + user message)
        2. Call LLM with tools
        3. If tool calls → execute → append results → loop
        4. If text response → return

        All models use a unified items list (native Responses API format).
        Format conversion happens at API boundaries:
        - Responses API (gpt-5.*): items sent directly
        - Chat Completions (Claude, Gemini): items_to_chat_messages() at provider

        Compaction checks (§2 of compaction.md):
        - Server compaction (gpt-5.4): server handles via context_management
        - Client-side (others): [1] 95% emergency, [3] 80% topic-aware
        """
        # Auto-match skills to inject into user context
        injected_skills = None
        if self._skill_loader:
            injected_skills = (
                self._skill_loader.match(
                    user_input,
                    threshold=self._skills_config.inject_threshold,
                    max_results=self._skills_config.max_inject,
                )
                or None
            )

        # Resolve actual model name — use _effective_model which holds the
        # user-intended model. It diverges from config.model only on an
        # explicit `/model` switch; provider-level fallbacks are per-call
        # and never persist to _effective_model (every turn re-enters the
        # full candidate chain via resolve_model_chain).
        _providers = getattr(self._provider, "_providers", None)
        _resolved_chain = resolve_model_chain(self._effective_model, _providers)
        _resolved_model = _resolved_chain[0] if _resolved_chain else self._effective_model

        # ``_turn_model`` is what we actually pass to the provider for this
        # turn. It mirrors ``self._effective_model`` unless a per-turn
        # override (e.g. vision auto-switch) applies.  ``self._effective_model``
        # itself is preserved so the next text-only turn returns to the
        # user's preferred model.
        _turn_model = self._effective_model

        # Auto-switch to a vision-capable model for this turn only when the
        # user attached images and the current model can't see them. Text
        # attachments don't need vision — they're inlined as text.
        has_image_attachment = bool(
            attachments and any(a.get("kind") == "image" for a in attachments)
        )
        if has_image_attachment:
            from workpilot.providers.model_catalog import supports_vision
            from workpilot.providers.resolver import resolve_vision_model

            if not supports_vision(_resolved_model):
                vision_model = resolve_vision_model(_resolved_model, _providers)
                if vision_model and vision_model != _resolved_model:
                    logger.info(
                        "Auto-switching to vision model for attachment turn: {} → {}",
                        _resolved_model,
                        vision_model,
                    )
                    self._audit.log_event(
                        action="attachment:model_autoswitch",
                        data={
                            "from": _resolved_model,
                            "to": vision_model,
                            "session_id": session_id,
                            "num_attachments": len(attachments or []),
                        },
                    )
                    _resolved_model = vision_model
                    _turn_model = vision_model
                else:
                    logger.warning(
                        "No vision-capable model available; sending images to {} may fail",
                        _resolved_model,
                    )

        max_iter = self._config.max_iterations
        iteration = 0
        loop_detector = LoopDetector()
        # D12: a turn-local flag for the iteration-ceiling lift. Set on
        # the first successful mid-run inject; subsequent injects do
        # NOT extend further. Uses local var rather than instance state
        # so per-turn cleanup is automatic (S2 simplification).
        ceiling_doubled = False
        _reasoning_effort_rejected = False  # Set True if model rejects reasoning_effort
        sid_canonical_for_drain = self._sessions._normalize_id(session_id)

        # ── Reasoning effort: user turn count + elapsed time ─────────────────
        # Count prior non-mid-run user messages already in the session.
        _existing_msgs = self._sessions.get_messages(session_id)
        _user_turns = sum(
            1 for m in _existing_msgs if m.get("role") == "user" and not m.get("_mid_run")
        )
        # Elapsed seconds since last message — used for time-based floor decay.
        # Always computed when messages exist; resolver ignores it for non-auto effort.
        _elapsed_seconds: float | None = None
        if _existing_msgs:
            from datetime import UTC, datetime

            _now = datetime.now(UTC)
            for item in reversed(_existing_msgs):
                ts_str = item.get("_ts")
                if ts_str:
                    try:
                        _last_ts = datetime.fromisoformat(ts_str)
                        if _last_ts.tzinfo is None:
                            _last_ts = _last_ts.replace(tzinfo=UTC)
                        _elapsed_seconds = (_now - _last_ts).total_seconds()
                        break  # stop on first successfully parsed timestamp
                    except (ValueError, TypeError):
                        pass  # malformed ts — try next message

        # Per-turn context_limit: when the config is unset we derive it from
        # the model that will actually handle this turn (including any
        # vision auto-switch above), not from _effective_model.
        if self._config.context_limit is not None:
            context_limit = self._config.context_limit
        else:
            from workpilot.providers.model_catalog import get_max_input_tokens

            context_limit = get_max_input_tokens(_resolved_model)

        # ── Unified items path (all models) ────────────────────────
        # Build instructions first so we can reserve tokens for smart_load.
        _instructions = self._context.build_system_prompt(mode=self._prompt_mode)
        _reserved = self._context.estimate_system_prompt_tokens(mode=self._prompt_mode) + 2000
        # Copy so items (LLM working list) is decoupled from session store.
        # Session store is updated via add_message(); items gets the expanded
        # user content (with skills/runtime context) that shouldn't be persisted.
        items: list[dict[str, Any]] = list(
            self._sessions.load_session(
                session_id, _resolved_model, context_limit, reserved_tokens=_reserved
            )
        )
        user_content = self._context.build_user_content(
            user_input,
            channel=channel,
            channel_id=channel_id,
            injected_skills=injected_skills,
        )
        # Persist original user message to session JSONL (without skills/runtime context).
        user_msg_entry: dict[str, Any] = {"role": "user", "content": user_input}
        actually_injected = getattr(self._context, "_last_injected_skill_names", [])
        if actually_injected:
            user_msg_entry["_injected_skills"] = list(actually_injected)
        # Attachments are persisted as refs under _attachments (not in content)
        # so the JSONL stays grep-able; list-form content is rebuilt on replay
        # via the provider's _resolve_attachment_urls(). Persist only the
        # portable subset — ``path`` is redundant (recomputed from sha256 on
        # replay) and leaks an absolute server path into the session log.
        if attachments:
            user_msg_entry["_attachments"] = [
                {
                    k: a[k]
                    for k in ("sha256", "content_type", "size", "name", "kind")
                    if k in a and a[k] is not None
                }
                for a in attachments
            ]
        self._sessions.add_message(session_id, user_msg_entry)
        # Append expanded version to items for LLM call only.
        # The original is persisted to JSONL above; the expanded version
        # (with skills + runtime context) is ephemeral — used for this
        # turn's LLM call but not written to disk.
        if attachments:
            content_parts: list[dict[str, Any]] = [{"type": "input_text", "text": user_content}]

            def append_missing_attachment_marker(name: str) -> None:
                content_parts.append(
                    {"type": "input_text", "text": f"[attachment missing: {name}]"}
                )

            for a in attachments:
                sha = a.get("sha256")
                if not sha:
                    continue
                # The cloud channel passes through `missing=True` when an
                # inbound ref's bytes aren't on disk (rare — client restart
                # between upload and message). Surface a text marker so the
                # model can acknowledge the attachment instead of getting an
                # `input_image` with a URL that resolves to nothing — which
                # `_resolve_attachment_urls` would silently drop, leaving
                # the user's UI showing a chip the LLM never saw.
                if a.get("missing"):
                    name = a.get("name") or sha[:8]
                    append_missing_attachment_marker(name)
                    continue
                kind = a.get("kind") or "image"
                if kind == "image":
                    content_parts.append(
                        {
                            "type": "input_image",
                            "image_url": f"workpilot-attachment://{sha}",
                        }
                    )
                    continue
                # Text: inline the file content now as a fenced code block
                # via the shared renderer (handles name-sanitization and
                # backtick-escape so fences inside markdown attachments
                # don't close our wrapper early). If bytes are missing on
                # disk (session persisted then store GC'd / manual delete),
                # surface the same ``[attachment missing: NAME]`` marker as
                # the inbound missing-flag path — otherwise the browser
                # still shows a file chip while the model sees nothing.
                body = load_as_text(sha)
                if body is None:
                    name = a.get("name") or sha[:8]
                    logger.warning("Text attachment {} missing on disk", sha)
                    append_missing_attachment_marker(name)
                    continue
                content_parts.append(
                    {
                        "type": "input_text",
                        "text": render_text_attachment(a.get("name") or sha[:8], body),
                    }
                )
            items.append({"role": "user", "content": content_parts})
            self._audit.log_event(
                action="attachment:sent_to_llm",
                data={
                    "session_id": session_id,
                    "model": _turn_model,
                    "num_attachments": len(attachments),
                    "sha256s": [a.get("sha256") for a in attachments],
                    "kinds": [a.get("kind") for a in attachments],
                },
            )
        else:
            items.append({"role": "user", "content": user_content})
        # Server-side compaction threshold (None for non-server-compaction models)
        _compact_threshold: int | None = (
            max(1000, int(context_limit * 0.90))
            if _supports_server_compaction(_resolved_model)
            else None
        )
        reminder = ReminderTracker(
            interval=self._config.reminder_interval,
            agent_name=self._config.name,
            user_task=user_input,
            memory=self._memory,
        )

        # Token tracking — updated after each LLM call
        _last_prompt_tokens: int = 0
        _last_completion_tokens: int = 0
        _msgs_at_last_llm_call: int = len(items)

        while iteration < max_iter:
            iteration += 1
            logger.debug(f"Agent iteration {iteration}/{max_iter}")

            # ── §5.3 mid-run drain checkpoint — top of every iteration ─
            # Drains all steerable items from the per-session inbox into
            # ``items[]`` as ``{role: user, _mid_run: true}`` entries
            # before the next LLM call. First successful inject doubles
            # the iteration ceiling (D12, once-only).
            if self._drain_mid_run(sid_canonical_for_drain, items) and not ceiling_doubled:
                max_iter = self._config.max_iterations * 2
                ceiling_doubled = True
                logger.info(
                    "mid-run inject: doubling iteration ceiling for session {} → {}",
                    sid_canonical_for_drain,
                    max_iter,
                )

            # Refresh tool schemas each iteration (progressive loading may
            # have activated new tools since the last iteration)
            tool_schemas = self._tools.get_schemas(
                self._config.tools or None,
                exclude=exclude_tools,
            )

            # ── [1] Pre-completion check (§2.2): 95% → emergency ─────
            # Skip for server-compaction models — server handles via
            # context_management + truncation:auto (design §3.6).
            # Only clear old tool results at 80% as token cost optimization.
            if _compact_threshold:
                if _last_prompt_tokens and _last_prompt_tokens / context_limit > 0.80:
                    clear_old_tool_results(items, keep_turns=2)
                _pre_check = False
            elif _last_prompt_tokens == 0:
                _pre_check = estimate_tokens(items) / context_limit > 0.95
            else:
                new_msgs_since_last = items[_msgs_at_last_llm_call:]
                _pre_check = should_pre_compact(
                    _last_prompt_tokens,
                    _last_completion_tokens,
                    new_msgs_since_last,
                    context_limit,
                )
            if _pre_check:
                logger.warning("Pre-completion emergency compaction (>95%)")
                tokens_before = estimate_tokens(items)
                items[:] = await self._emergency_compact(
                    items,
                    session_id,
                    context_limit,
                    reminder,
                    instructions=_instructions,
                )
                self._append_compaction_audit(
                    session_id,
                    trigger="pre_completion_emergency",
                    tokens_before=tokens_before,
                    tokens_after=estimate_tokens(items),
                    messages_total=len(items),
                )

            # ── Graceful termination: Stage 1 — Nudge ────────────────
            if iteration == max_iter - 2:
                items.append(
                    {
                        "role": "system",
                        "content": (
                            "You are approaching the iteration limit. "
                            "Please wrap up your current task and provide a final answer soon."
                        ),
                    }
                )

            # ── Graceful termination: Stage 2 — Force text ───────────
            # At iteration max-1, call LLM WITHOUT tools to force a text summary
            tools_for_call = tool_schemas if (tool_schemas and iteration < max_iter - 1) else None

            # ── Reasoning effort resolution ──────────────────────────
            from workpilot.providers.model_catalog import get_supported_reasoning_efforts
            from workpilot.providers.reasoning import resolve_reasoning_effort

            _reasoning = None
            if not _reasoning_effort_rejected:
                _effort_source = (
                    reasoning_effort_override
                    if reasoning_effort_override is not None
                    else self._config.reasoning_effort
                )
                _reasoning = resolve_reasoning_effort(
                    _effort_source,
                    category=self._config.metadata.get("category", ""),
                    iteration=iteration - 1,
                    user_turns=_user_turns,
                    elapsed_seconds=_elapsed_seconds,
                    input_text=user_input,
                    has_midrun=ceiling_doubled,
                )
                # Gate against model capability table (O(1) lookup)
                # "none" bypasses capability check — it's handled by the provider
                # locally (re-enables temperature) and never sent to the API.
                if _reasoning is not None and _reasoning != "none":
                    _supported = get_supported_reasoning_efforts(_resolved_model)
                    if _supported is not None and _reasoning not in _supported:
                        from workpilot.providers.model_catalog import clamp_reasoning_effort

                        _clamped = clamp_reasoning_effort(_reasoning, _supported)
                        logger.debug(
                            "reasoning_effort={} not supported by {} → {}",
                            _reasoning,
                            _resolved_model,
                            _clamped or "dropped",
                        )
                        _reasoning = _clamped
            if _reasoning is not None:
                logger.debug(
                    "reasoning_effort={} (configured={}, iter={})",
                    _reasoning,
                    self._config.reasoning_effort,
                    iteration - 1,
                )

            # When no tools are offered, use streaming for real-time token delivery
            if tools_for_call is None and channel and channel_id:
                # Stop typing indicator before streaming starts — the user
                # will see real tokens arriving instead of "typing…".
                if typing_ctrl:
                    typing_ctrl.stop()
                    typing_ctrl = None  # clear local ref; _process_message's stop() is idempotent
                try:
                    content, stream_refs = await self._stream_response(
                        model=_turn_model,
                        items=items,
                        instructions=_instructions,
                        compact_threshold=_compact_threshold,
                        channel=channel,
                        channel_id=channel_id,
                        session_id=session_id,
                        reasoning_effort=_reasoning,
                    )
                except Exception as exc:
                    if (
                        _reasoning is not None
                        and getattr(exc, "status_code", 0) == 400
                        and "reasoning_effort" in str(exc)
                    ):
                        logger.warning(
                            "Model does not support reasoning_effort; retrying stream without"
                        )
                        _reasoning_effort_rejected = True
                        content, stream_refs = await self._stream_response(
                            model=_turn_model,
                            items=items,
                            instructions=_instructions,
                            compact_threshold=_compact_threshold,
                            channel=channel,
                            channel_id=channel_id,
                            session_id=session_id,
                        )
                    else:
                        raise
                # Persistence handled by _stream_response:
                # - Native path: raw_output items (incl. message) persisted
                # - Chat path: {role: "assistant"} persisted at end
                # - Attachment sidecar: hoisted by _stream_response internally
                # Fire-and-forget: don't block the response
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
                return content, True, stream_refs

            # ── Interrupt checkpoint 1: before LLM call ────────────
            if self._check_interrupt(session_id):
                self._finalize_interrupt(session_id, items)
                return "Interrupted.", False, None

            # ── [2] LLM Call ─────────────────────────────────────────
            try:
                _llm_kwargs: dict[str, Any] = dict(
                    model=_turn_model,
                    items=items,
                    instructions=_instructions,
                    compact_threshold=_compact_threshold,
                    tools=tools_for_call,
                )
                if _reasoning is not None:
                    _llm_kwargs["reasoning_effort"] = _reasoning
                response: LLMResponse = await self._provider.complete(**_llm_kwargs)
            except Exception as exc:
                # ── Token-limit error recovery (§2.3) ────────────────
                if is_token_limit_error(exc):
                    logger.warning("Token-limit error, attempting emergency compaction + retry")
                    if _compact_threshold:
                        # Server-compaction models: just clear tool results
                        # (truncation:auto prevents recurrence)
                        clear_old_tool_results(items, keep_turns=2)
                    else:
                        tokens_before = estimate_tokens(items)
                        items[:] = await self._emergency_compact(
                            items,
                            session_id,
                            context_limit,
                            reminder,
                            instructions=_instructions,
                        )
                        self._append_compaction_audit(
                            session_id,
                            trigger="token_limit_error",
                            tokens_before=tokens_before,
                            tokens_after=estimate_tokens(items),
                            messages_total=len(items),
                        )
                    # Retry once
                    response = await self._provider.complete(**_llm_kwargs)
                elif any(i.get("type") == "compaction" for i in items) and getattr(
                    exc, "status_code", 0
                ) in (400, 500):
                    # Blob rejection: stale or incompatible compaction blob.
                    # Strip blobs from items and clear meta. Stale compaction items
                    # may still exist in JSONL — the blob rejection handler catches
                    # them on the next turn (one retry, self-healing).
                    logger.warning("Blob possibly rejected ({}); stripping and retrying", exc)
                    items[:] = [i for i in items if i.get("type") != "compaction"]
                    self._sessions.update_meta(session_id, compaction_blob=None)
                    response = await self._provider.complete(**_llm_kwargs)
                elif (
                    "reasoning_effort" in _llm_kwargs
                    and getattr(exc, "status_code", 0) == 400
                    and "reasoning_effort" in str(exc)
                ):
                    # Model does not support reasoning_effort (e.g. claude-haiku).
                    # Strip and retry; disable for remaining iterations.
                    logger.warning(
                        "Model does not support reasoning_effort; retrying without ({})",
                        _turn_model,
                    )
                    del _llm_kwargs["reasoning_effort"]
                    _reasoning = None
                    _reasoning_effort_rejected = True
                    response = await self._provider.complete(**_llm_kwargs)
                else:
                    raise

            # Track actual token usage from provider
            _last_prompt_tokens = response.prompt_tokens
            _last_completion_tokens = response.completion_tokens
            _msgs_at_last_llm_call = len(items)

            # Recompute compact_threshold from the model that actually handled
            # this call — the provider may have fallen back to a different model
            # (e.g. gpt-5.4 → gpt-5.2) which doesn't support server compaction.
            _actual_model = response.model or _resolved_model

            # Update context_limit if the provider fell back to a model with
            # a different input limit — otherwise the 80%/95% compaction
            # thresholds use the wrong baseline (Fix 2).
            # Compare against _resolved_model (concrete ID), not
            # _effective_model which may be an alias like "auto"/"fast".
            if _actual_model != _resolved_model:
                from workpilot.providers.model_catalog import get_max_input_tokens

                self._consecutive_fallbacks += 1
                new_limit = get_max_input_tokens(_actual_model)
                if new_limit != context_limit:
                    logger.info(
                        "Model fallback {} → {}; adjusting context_limit {} → {}",
                        _resolved_model,
                        _actual_model,
                        context_limit,
                        new_limit,
                    )
                    context_limit = new_limit

                # Warn once when a persistent fallback pattern emerges.
                # Do NOT latch ``_effective_model`` — that would collapse the
                # alias chain to a single concrete ID, locking the session
                # out of further fallback candidates on subsequent turns.
                # Every turn re-resolves the full chain via
                # ``resolve_model_chain``, so provider-level fallback keeps
                # working on each call without session-level state.
                if self._consecutive_fallbacks == self._FALLBACK_SWITCH_THRESHOLD:
                    logger.warning(
                        "Primary model {} unavailable for {} consecutive calls; "
                        "per-call fallback to {} is active — check provider status.",
                        self._effective_model,
                        self._consecutive_fallbacks,
                        _actual_model,
                    )
                _resolved_model = _actual_model
            else:
                self._consecutive_fallbacks = 0

            _compact_threshold = (
                max(1000, int(context_limit * 0.90))
                if _supports_server_compaction(_actual_model)
                else None
            )

            # ── [2.5] Handle response output ──────────────────────
            # Image-hoist (markdown-hoist protocol): if this is the final
            # assistant turn (no tool calls to follow), scan for
            # ``workpilot-image://`` sentinels and strip them out of the
            # content before persistence. Refs get attached as a sidecar
            # and forwarded to the channel as OutboundMessage.attachments.
            # See workpilot/agent/output_parser.py.
            _hoisted_refs: list[dict[str, Any]] | None = None
            if not response.tool_calls and response.content:
                _stripped, _refs = extract_outputs(response.content, workspace=self._workspace)
                if _refs:
                    _hoisted_refs = _refs
                    # Native-path raw_output may carry output_text parts that
                    # repeat the same content — patch them in-place (best
                    # effort; full fidelity is a phase-2 concern).
                    if response.raw_output:
                        response.raw_output = _patch_raw_output(
                            response.raw_output, _stripped, _hoisted_refs
                        )
                    # Mutate .content so downstream persist + return uses stripped.
                    try:
                        response.content = _stripped  # type: ignore[misc]
                    except Exception:
                        # LLMResponse may be frozen — leave content raw; the
                        # raw_output patching above + caller's stripped return
                        # value are the authoritative paths.
                        pass

            if response.raw_output:
                # Responses API path: output already as native items.
                # Persist to JSONL FIRST (before tool execution).
                for raw_item in response.raw_output:
                    self._sessions.add_message(session_id, raw_item)

                if response.compaction_blobs:
                    # Server compacted: replace items with blobs + non-blob output
                    blobs = response.compaction_blobs
                    non_blob = [i for i in response.raw_output if i.get("type") != "compaction"]
                    items.clear()
                    items.extend(blobs + non_blob)
                    self._sessions.update_meta(
                        session_id,
                        compaction_blob={
                            "at": datetime.now(UTC).isoformat(),
                            "model": _actual_model,
                            "blobs": blobs,
                            "output": non_blob,
                        },
                    )
                    self._sessions.replace_messages(session_id, list(items))
                    asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
                    logger.info("Server compaction: {} blobs persisted", len(blobs))
                else:
                    # Remove old reasoning items before appending new ones —
                    # accumulated encrypted_content causes 400 on Copilot proxy.
                    # Only the latest reasoning items (from this response) are needed.
                    new_has_reasoning = any(
                        i.get("type") == "reasoning" for i in response.raw_output
                    )
                    if new_has_reasoning:
                        items[:] = [i for i in items if i.get("type") != "reasoning"]
                    items.extend(response.raw_output)
            else:
                # Chat Completions path: construct items from response fields.
                if response.content:
                    text_item: dict[str, Any] = {
                        "role": "assistant",
                        "content": response.content,
                    }
                    if _hoisted_refs:
                        text_item["_attachments"] = _hoisted_refs
                    items.append(text_item)
                    self._sessions.add_message(session_id, text_item)
                if response.tool_calls:
                    for tc in response.tool_calls:
                        fc_item: dict[str, Any] = {
                            "type": "function_call",
                            "call_id": tc.id,
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                            if isinstance(tc.arguments, dict)
                            else tc.arguments,
                        }
                        items.append(fc_item)
                        self._sessions.add_message(session_id, fc_item)

            # ── Commentary dispatch (design/features/commentary-streaming.md §5)
            # Send assistant reasoning text to channels before tool execution
            # so users see *why* the agent acts before seeing the tool pills.
            _commentary = redact_credentials(response.content or "").strip()
            if _commentary and response.tool_calls and channel and channel_id:
                await self._bus.dispatch_outbound(
                    StreamingChunk(
                        channel=channel,
                        channel_id=channel_id,
                        content=_commentary,
                        chunk_type="commentary",
                        done=True,
                    )
                )

            # No tool calls → done
            if not response.tool_calls:
                content = response.content

                # ── [3] Post-completion check (§2.1) ─────────────────
                if not _compact_threshold:
                    # Skip for server-compaction models
                    await self._post_completion_check(
                        items,
                        session_id,
                        context_limit,
                        reminder,
                        _last_prompt_tokens,
                        instructions=_instructions,
                    )

                # Fire-and-forget: don't block the response
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))

                return content, False, _hoisted_refs

            # Has tool calls → execute them
            # (assistant message + function_call items already in items above)

            # ── IronClaw 3-phase tool execution ─────────────────────
            tool_calls = response.tool_calls

            # ── Clarify fence (pre-Phase-1) ──────────────────────────
            # When ``clarify`` is in the batch, the user's answer can
            # change every other tool's args — running their
            # pre_tool_use hooks (approval prompts, risk scoring, etc.)
            # would block the turn on tools we're about to defer
            # anyway. Detect the fence BEFORE Phase 1 so deferred
            # tools skip preflight entirely. Also handles the
            # multiple-clarify-in-one-batch case (only the first runs;
            # the rest are also stale and get the same fence message).
            # NOTE: fence triggers on the tool NAME being in the batch,
            # not on whether clarify is currently registered. A
            # hallucinated ``clarify`` call (LLM emits one when the tool
            # is disabled) MUST still defer the rest of the batch — the
            # mutating tools' args were emitted assuming clarify would
            # block first; running them anyway risks the same
            # speculative-mutation hazard as a real clarify batch. The
            # hallucinated clarify call itself will fail with "unknown
            # tool" via the registry's normal path, and the LLM gets a
            # fresh turn to recover.
            tool_results: dict[str, str] = {}  # tc.id → result or error
            deferred_ids: set[str] = set()
            clarify_in_batch = any(tc.name == "clarify" for tc in tool_calls)
            if clarify_in_batch:
                ran_clarify = False
                for tc in tool_calls:
                    if tc.name == "clarify" and not ran_clarify:
                        ran_clarify = True
                        continue
                    tool_results[tc.id] = (
                        "BLOCKED — clarify was in this tool batch. The user's "
                        "answer may change this call's intended args, so it was "
                        "deferred. Read the clarify result and re-emit if still "
                        "needed."
                    )
                    deferred_ids.add(tc.id)

            # Phase 1: Preflight — pre_tool_use hooks (sequential)
            approved: list[tuple[Any, bool]] = []  # (tc, blocked)
            for tc in tool_calls:
                logger.info(f"Tool call: {tc.name}({list(tc.arguments.keys())})")
                blocked = False
                # Skip preflight entirely for clarify-fence-deferred
                # tools: their result is already a synthetic BLOCKED
                # message; running approval / risk hooks on them would
                # surface UI prompts (e.g. shell approval) that block
                # the turn before clarify ever gets to run.
                if tc.id in deferred_ids:
                    blocked = True
                    approved.append((tc, blocked))
                    continue
                # Block excluded tools even if LLM hallucinates them
                if exclude_tools and tc.name in exclude_tools:
                    blocked = True
                    tool_results[tc.id] = f"Tool '{tc.name}' is not available."
                    approved.append((tc, blocked))
                    continue
                if self._hooks:
                    _tool = self._tools.get(tc.name)
                    # Collect last 3 user messages for risk scorer context
                    _user_msgs: list[str] = []
                    if session_id and self._sessions:
                        try:
                            _all_msgs = self._sessions.get_messages(session_id)
                            _user_msgs = [
                                m["content"]
                                for m in _all_msgs
                                if m.get("role") == "user" and m.get("content")
                            ][-3:]
                        except Exception:
                            _user_msgs = []
                    if not _user_msgs and user_input:
                        _user_msgs = [user_input]
                    # Redact credentials so secrets aren't leaked to the scorer prompt
                    _user_msgs = [redact_credentials(m) for m in _user_msgs]
                    pre_ctx = PreToolHookContext(
                        tool_name=tc.name,
                        args=tc.arguments,
                        agent_name=self._config.name,
                        session_id=session_id,
                        tool_ref=_tool,
                        channel=channel,
                        channel_id=channel_id or "",
                        user_messages=_user_msgs,
                        metadata=metadata or {},
                        interrupt_event=self._interrupt.get_or_create(session_id),
                        typing_controller=typing_ctrl,
                    )
                    pre_result = await self._hooks.dispatch_checked("pre_tool_use", pre_ctx)
                    if pre_result.verdict == HookVerdict.REJECT:
                        cat = pre_result.reject_category
                        if cat == RejectCategory.ESTOP:
                            block_prefix = "blocked by emergency stop"
                            guidance = (
                                "Tool execution is temporarily disabled (E-stop). "
                                "Do NOT call any tools until the halt is cleared. "
                                "Inform the user that tool execution is paused."
                            )
                        elif cat == RejectCategory.USER:
                            block_prefix = "blocked by user"
                            guidance = (
                                "Avoid repeating the same call. "
                                "Try to accomplish the task using a different approach or tool."
                            )
                        elif cat == RejectCategory.CANCEL:
                            block_prefix = "cancelled by user"
                            guidance = (
                                "The user cancelled the current operation. "
                                "Stop and wait for new instructions."
                            )
                        elif cat == RejectCategory.TIMEOUT:
                            block_prefix = "not approved in time"
                            guidance = (
                                "No one responded to the approval request. "
                                "Try to accomplish the task using a different approach or tool."
                            )
                        else:
                            block_prefix = "blocked by security policy"
                            guidance = (
                                "Do NOT retry this tool. "
                                "Try to accomplish the task using a different approach or tool."
                            )
                        tool_results[tc.id] = (
                            f"Tool '{tc.name}' {block_prefix}: {pre_result.reason}\n{guidance}"
                        )
                        logger.warning(f"Tool '{tc.name}' blocked: {pre_result.reason}")
                        blocked = True
                approved.append((tc, blocked))

            # Phase 2: Execute — parallel for independent tools (asyncio.gather)
            # Safety: tools that share state (e.g., browser) are serialized
            # by deduplicating tool names — only one call per tool name runs concurrently.
            _STATEFUL_TOOLS = {"browser", "clarify"}

            async def _execute_tool(tc: Any) -> str:
                # Stash per-turn context so BridgeTool (and any future context-aware
                # tool) can reach session/channel info from inside execute(). Uses
                # contextvars so parallel gather()-fanned tool batches isolate cleanly.
                from workpilot.agent.bridge import BridgeTurnContext, bridge_turn_context

                src_val = (metadata or {}).get("source", "") if metadata else ""
                ctx = BridgeTurnContext(
                    session_id=session_id,
                    channel=channel or ChannelType.CLI,
                    channel_id=channel_id or "",
                    source=str(src_val) if src_val else "",
                    agent_name=self._config.name,
                )
                with bridge_turn_context(ctx):
                    return await self._tools.execute(
                        tc.name,
                        tc.arguments,
                        actor="agent",
                        session_id=session_id,
                        sender_id=sender_id,
                        bus=self._bus,
                        channel=channel,
                        channel_id=channel_id,
                        thread_id=thread_id,
                        metadata=metadata,
                        call_id=getattr(tc, "call_id", None) or tc.id,
                    )

            runnable = [(tc, blocked) for tc, blocked in approved if not blocked]

            # ── Interrupt checkpoint 2: before tool execution ────────
            if self._check_interrupt(session_id):
                for tc, _ in runnable:
                    if tc.id not in tool_results:
                        skip_item: dict[str, Any] = {
                            "type": "function_call_output",
                            "call_id": tc.id,
                            "output": "[Skipped — interrupted by user]",
                            "is_error": True,
                        }
                        items.append(skip_item)
                        self._sessions.add_message(session_id, skip_item)
                self._finalize_interrupt(session_id, items)
                return "Interrupted.", False, None

            # Split into parallelizable and serializable. Clarify fence
            # already happened pre-Phase-1 — non-clarify tools that
            # were in a clarify batch are blocked in ``approved`` and
            # filtered out of ``runnable`` above, so this split only
            # sees runnable, non-deferred calls.
            parallel_batch = []
            serial_batch = []
            seen_names: set[str] = set()
            for tc, _ in runnable:
                if tc.name in _STATEFUL_TOOLS or tc.name in seen_names:
                    serial_batch.append(tc)
                else:
                    parallel_batch.append(tc)
                    seen_names.add(tc.name)

            # Run parallel batch
            if parallel_batch:
                tasks = [_execute_tool(tc) for tc in parallel_batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for tc, result in zip(parallel_batch, results):
                    if isinstance(result, Exception):
                        tool_results[tc.id] = f"Error executing {tc.name}: {result}"
                    else:
                        tool_results[tc.id] = str(result)

            # Run serial batch (stateful or duplicate tool names)
            for tc in serial_batch:
                # ── Interrupt checkpoint 3: between serial tools ─────
                if self._check_interrupt(session_id):
                    tool_results[tc.id] = "BLOCKED — skipped due to user interruption"
                    continue
                try:
                    tool_results[tc.id] = await _execute_tool(tc)
                except Exception as exc:
                    tool_results[tc.id] = f"Error executing {tc.name}: {exc}"

            # Phase 3: Postflight — hooks see raw output, then redact (sequential)
            for tc, blocked in approved:
                result = tool_results.get(tc.id, "")

                # post_tool_use hook BEFORE redaction (LeakScanner needs raw output)
                if self._hooks and not blocked:
                    post_ctx = PostToolHookContext(
                        tool_name=tc.name,
                        args=tc.arguments,
                        result=result,
                        agent_name=self._config.name,
                        session_id=session_id,
                    )
                    hook_result = await self._hooks.dispatch_checked("post_tool_use", post_ctx)
                    # Apply hook modifications (e.g., Redactor updates ctx.result)
                    if hook_result.data and isinstance(hook_result.data, PostToolHookContext):
                        result = hook_result.data.result

                # Redact secrets AFTER hooks have inspected raw output
                result = Sanitizer.redact_env_values(result)

                # Unified truncation: per-tool metadata > global config default
                # Strategy: LLM compress first, smart_truncate fallback.
                tool_obj = self._tools.get(tc.name)
                tool_max = tool_obj.metadata.max_output_chars if tool_obj else 0
                output_cfg = self._tools.output_config
                result = await truncate_tool_output(
                    content=result,
                    tool_name=tc.name,
                    max_chars=tool_max if tool_max > 0 else output_cfg.max_chars,
                    provider=self._provider,
                    llm_enabled=output_cfg.llm_compression_enabled,
                    tool_args=tc.arguments,
                )

                is_error = blocked or result.startswith(("Error", "Failed", "BLOCKED"))

                # Always use native format — provider converts to Chat at boundary
                tool_item: dict[str, Any] = {
                    "type": "function_call_output",
                    "call_id": tc.id,
                    "output": result,
                }
                if is_error:
                    tool_item["is_error"] = True
                items.append(tool_item)
                self._sessions.add_message(session_id, tool_item)

            # ── POINT 2: flush pending notify/delegate/scheduler outbounds ─
            # Lands AFTER all function_call_output items for this batch, so
            # the tool_call ↔ tool_result adjacency required by OpenAI's
            # Chat Completions API is preserved. Next LLM iteration will
            # see the injected assistant entries in items.
            # Normalise the session id so the pop matches the key the
            # capture handler uses when buffering (``_capture_for_persist``
            # also normalises). Without this, same-session notifications
            # stamped with a canonical target_session_id (e.g. ``local_web``)
            # would sit unclaimed under ``local_web`` while the pop looked
            # for ``web_web-user`` and miss.
            self._flush_persist(self._sessions._normalize_id(session_id), items)

            # ── Loop detection (AFTER all tool messages to preserve ordering) ─
            # OpenAI requires all tool-role messages to immediately follow
            # their assistant message with tool_calls — no system messages
            # may be inserted between them.
            for tc, _blocked in approved:
                warning, should_terminate = loop_detector.check(tc.name, tc.arguments)
                if warning:
                    items.append({"role": "system", "content": warning})
                    if should_terminate:
                        return (
                            (
                                "I detected a repetitive loop and stopped to avoid wasting resources. "
                                f"Pattern: {warning}"
                            ),
                            False,
                            None,
                        )

            # ── [3] Post-completion check (§2.1) — runs after tool results too
            if not _compact_threshold:
                # Skip for server-compaction models
                await self._post_completion_check(
                    items,
                    session_id,
                    context_limit,
                    reminder,
                    _last_prompt_tokens,
                    instructions=_instructions,
                )

            # ── System reminders ──────────────────────────────────────
            # Track tool calls and inject periodic reminder if due
            reminder.record_tool_calls(len(tool_calls))
            if reminder.should_inject():
                items.append(reminder.build_reminder())

            # Post-spawn reminder: if any tool call was a 'spawn' that
            # succeeded, inject a parent-task reminder so the agent
            # re-orients after processing delegated sub-agent results.
            blocked_ids = {tc.id for tc, blocked in approved if blocked}
            spawn_calls = [tc for tc in tool_calls if tc.name == "spawn"]
            for sc in spawn_calls:
                if sc.id in blocked_ids:
                    continue
                result = tool_results.get(sc.id, "")
                is_spawn_error = result.startswith("Error") or result.startswith("BLOCKED")
                if not is_spawn_error:
                    child_name = sc.arguments.get("agent", "sub-agent")
                    items.append(reminder.build_post_spawn_reminder(child_name))

        # ── Graceful termination: Stage 3 — Hard stop ────────────────
        return (
            (
                f"I reached the maximum number of iterations ({max_iter}). "
                "You can try breaking the task into smaller steps."
            ),
            False,
            None,
        )

    # ── Compaction helpers ────────────────────────────────────────────────

    async def _emergency_compact(
        self,
        items: list[dict[str, Any]],
        session_id: str,
        context_limit: int,
        reminder: ReminderTracker,
        *,
        instructions: str | None = None,
    ) -> list[dict[str, Any]]:
        """Run emergency compaction: LLM summary + re-inject memory + trigger consolidation.

        Converts native items to Chat format at boundary (compact_messages expects Chat).
        Returns Chat-format messages (valid items for both native and Chat paths).

        Pre-shrinks via :func:`clear_old_tool_results` before attempting LLM
        summarization so the compaction prompt itself does not exceed the model
        limit (prevents the cascade failure where compaction triggers another
        token-limit error).
        """
        from workpilot.providers.client import items_to_chat_messages

        # Phase 0: shrink items *before* the LLM compaction call so the
        # compaction prompt fits within the model's input limit.
        clear_old_tool_results(items, keep_turns=2)
        estimated = estimate_tokens(items)

        chat_msgs = items_to_chat_messages(items, instructions=instructions)

        if estimated > context_limit * 0.70:
            # Still too large for an LLM compaction call — skip straight to
            # non-LLM fallback to avoid another token-limit cascade.
            logger.warning(
                "Emergency compaction: {}t still > 70% of {}t after clearing "
                "tool results; using non-LLM fallback",
                estimated,
                context_limit,
            )
            chat_msgs = compact_fallback(chat_msgs, keep_recent=3)
        else:
            try:
                chat_msgs = await compact_messages(
                    chat_msgs,
                    self._provider,
                    self._config,
                    context_limit=context_limit,
                )
            except Exception as exc:
                logger.error("Emergency compaction LLM failed: {}, using fallback", exc)
                chat_msgs = compact_fallback(chat_msgs, keep_recent=3)

        # Strip original system prompt BEFORE re-injecting reminders —
        # reminders are also role:system and would be stripped otherwise.
        # Keep compaction summaries (rebuilt instructions handles the rest).
        if instructions:
            _SUMMARY_MARKER = "[Conversation summary"
            chat_msgs = [
                m
                for m in chat_msgs
                if m.get("role") != "system" or _SUMMARY_MARKER in (m.get("content") or "")
            ]
        # Re-inject memory + task reminder (after stripping system prompt)
        chat_msgs = self._reinject_after_compaction(chat_msgs, reminder)
        # Fire consolidation in background
        asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
        return chat_msgs

    async def _post_completion_check(
        self,
        items: list[dict[str, Any]],
        session_id: str,
        context_limit: int,
        reminder: ReminderTracker,
        prompt_tokens: int,
        *,
        instructions: str | None = None,
    ) -> None:
        """Post-completion check (§2.1): topic-aware compaction at 80%.

        Converts native items to Chat format at the compaction boundary
        (compact_messages expects Chat). detect_topic_switch and
        clear_old_tool_results work on both formats.
        """
        msg_count = len(
            [
                m
                for m in items
                if m.get("role") in ("user", "assistant", "tool")
                or m.get("type") in ("message", "function_call_output")
            ]
        )
        if not should_post_compact(prompt_tokens, context_limit, msg_count):
            return

        tokens_before = estimate_tokens(items)
        if detect_topic_switch(items, self._config.compaction_topic_threshold):
            # Topic switched → full compaction (convert to Chat at boundary)
            logger.info("Post-completion: topic switch detected, running full compaction")
            try:
                from workpilot.providers.client import items_to_chat_messages

                chat_msgs = items_to_chat_messages(items, instructions=instructions)
                compacted = await compact_messages(
                    chat_msgs,
                    self._provider,
                    self._config,
                    context_limit=context_limit,
                )
                # Strip system messages except compaction summaries (rebuilt
                # via instructions each call).
                kept = [
                    m
                    for m in compacted
                    if m.get("role") != "system"
                    or "[Conversation summary" in (m.get("content") or "")
                ]
                self._sessions.replace_messages(session_id, kept)
                items.clear()
                items.extend(self._reinject_after_compaction(kept, reminder))
                self._append_compaction_audit(
                    session_id,
                    trigger="post_completion_topic_switch",
                    tokens_before=tokens_before,
                    tokens_after=estimate_tokens(kept),
                    messages_total=len(kept),
                    action="llm_summary",
                    consolidation_triggered=True,
                )
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
            except Exception as exc:
                logger.error("Post-completion compaction failed: {}", exc)
        else:
            # Same topic → clear old tool results only (no LLM, instant)
            cleared = clear_old_tool_results(items, keep_turns=3)
            if cleared:
                self._append_compaction_audit(
                    session_id,
                    trigger="post_completion_same_topic",
                    tokens_before=tokens_before,
                    tokens_after=estimate_tokens(items),
                    messages_total=len(items),
                    action="clear_tool_results",
                    tool_results_cleared=cleared,
                )

    def _reinject_after_compaction(
        self,
        messages: list[dict[str, Any]],
        reminder: ReminderTracker,
    ) -> list[dict[str, Any]]:
        """Re-inject memory + task reminder after compaction."""
        new_reminders = reminder.build_post_compaction_reminders()
        # De-duplicate
        reminder_keys = {(m.get("role"), m.get("content")) for m in new_reminders}
        messages = [m for m in messages if (m.get("role"), m.get("content")) not in reminder_keys]
        messages.extend(new_reminders)
        return messages

    def _append_compaction_audit(
        self,
        session_id: str,
        *,
        trigger: str,
        tokens_before: int,
        tokens_after: int,
        messages_total: int,
        action: str = "llm_summary",
        consolidation_triggered: bool = False,
        tool_results_cleared: int = 0,
    ) -> None:
        """Append a _compaction audit entry to the session JSONL.

        This entry is filtered out by get_messages() — it's metadata only.
        """
        entry: dict[str, Any] = {
            "_compaction": {
                "at": datetime.now(UTC).isoformat(),
                "trigger": trigger,
                "tokens_before": tokens_before,
                "tokens_after": tokens_after,
                "messages_total": messages_total,
                "action": action,
                "consolidation_triggered": consolidation_triggered,
            }
        }
        if tool_results_cleared:
            entry["_compaction"]["tool_results_cleared"] = tool_results_cleared
        self._sessions.add_message(session_id, entry)

    # ── Approval routing ──────────────────────────────────────────────────

    async def _try_route_approval(self, msg: InboundMessage) -> bool:
        """Intercept /approve, /deny, /always commands and metadata.approval_action.

        Returns ``True`` if the message was an approval response (consumed),
        ``False`` if it should proceed to the normal agent loop.
        """
        if self._approval_manager is None:
            return False

        mgr: ApprovalManager = self._approval_manager  # type: ignore[assignment]

        content = msg.content.strip()
        action: str | None = None
        request_id: str | None = None

        # Tier 0: structured metadata (Teams Adaptive Card / Cloud
        # structured response — the gateway pre-extracts these from
        # ``Activity.Value`` so we don't reparse the prompt).
        if msg.metadata.get("approval_action"):
            action = msg.metadata["approval_action"]
            request_id = msg.metadata.get("approval_request_id")
        else:
            # Tiers 1-3 (ZW-id precise / single-pending fallback / slash
            # form) all live in the shared ``match_approval_prompt`` helper
            # so the cloud, agent-loop, and web-server fast paths cannot
            # drift from each other (see approval-ux.md §11.1.2).
            from workpilot.security.approval_format import match_approval_prompt

            match = match_approval_prompt(content, mgr.get_pending())
            if match is not None:
                action, request_id = match

        if not action or not request_id:
            return False

        try:
            approved = action in ("approve", "always")
            mgr.resolve(
                request_id, approved=approved, resolver=msg.sender_id or "user", action=action
            )

            # "always" also adds to allowlist
            if action == "always" and self._allowlist is not None:
                resolved_req = mgr.get_request(request_id)
                if resolved_req:
                    self._allowlist.add(  # type: ignore[union-attr]
                        resolved_req.tool_name,
                        resolved_req.args,
                        added_by=msg.sender_id or "user",
                        note="Added via /always command",
                    )

            status = "approved" if approved else "denied"
            ch = ChannelType.of(msg.channel)
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ch,
                    channel_id=msg.channel_id,
                    content=f"Tool call {status}.",
                    thread_id=msg.thread_id,
                )
            )
        except (KeyError, ValueError) as exc:
            ch = ChannelType.of(msg.channel)
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ch,
                    channel_id=msg.channel_id,
                    content=f"Approval error: {exc}",
                    thread_id=msg.thread_id,
                )
            )
        return True

    async def _stream_response(
        self,
        *,
        model: str,
        channel: ChannelType,
        channel_id: str,
        session_id: str | None = None,
        items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, list[dict[str, Any]] | None]:
        """Stream a text-only LLM response, publishing chunks to the bus.

        Handles all persistence internally:
        - Native path (Responses API): persists raw_output items including
          the native message item (preserving id, status, annotations).
        - Chat path: persists ``{role: "assistant", content}`` at the end.

        Uses dispatch_outbound (handler-only, no queue) to avoid filling the
        bounded outbound queue with high-frequency StreamingChunks.  The done
        marker is always sent via try/finally so channels exit streaming state
        even when the provider raises mid-stream.

        Returns ``(rewritten_content, attachment_refs)``:
        - ``rewritten_content`` has ``workpilot-image://`` sentinels
          **rewritten in place** to the canonical sha form (see
          ``output_parser.extract_outputs``) for successfully hoisted
          refs so the frontend can render the image inline at the
          LLM-specified position. Failed hoists stay literal for debug.
        - ``attachment_refs`` is the list of hoisted refs (or None),
          ready to drop into ``OutboundMessage.attachments``.
        """
        parts: list[str] = []
        _has_native_output = False
        _stream_interrupted = False
        # ``done=true`` is emitted at the very end — AFTER JSONL persist —
        # so any frontend that refetches the session on done (to pick up
        # the rewritten markdown-hoist content + ``_attachments`` sidecar)
        # is guaranteed to see the persisted entry rather than racing
        # against an in-flight write. The ``finally:`` below covers the
        # exception path so channels still exit streaming state cleanly.
        done_dispatched = False
        content: str = ""
        hoisted_refs: list[dict[str, Any]] | None = None
        try:
            _stream_kwargs: dict[str, Any] = dict(
                model=model,
                items=items,
                instructions=instructions,
                compact_threshold=compact_threshold,
            )
            if reasoning_effort is not None:
                _stream_kwargs["reasoning_effort"] = reasoning_effort
            async for chunk in self._provider.stream(**_stream_kwargs):
                # ── Interrupt checkpoint 4: during streaming ─────
                if session_id and self._check_interrupt(session_id):
                    _stream_interrupted = True
                    break
                if chunk.content:
                    parts.append(chunk.content)
                    await self._bus.dispatch_outbound(
                        StreamingChunk(
                            channel=channel,
                            channel_id=channel_id,
                            content=chunk.content,
                            done=False,
                        )
                    )
                # Handle raw_output from streaming (response.completed event).
                # Persist ALL output items (including native message) for
                # cross-turn fidelity; handle compaction blobs for session resume.
                if chunk.raw_output and items is not None and session_id:
                    for raw_item in chunk.raw_output:
                        self._sessions.add_message(session_id, raw_item)
                        items.append(raw_item)
                    _has_native_output = True

                if chunk.compaction_blobs and items is not None and session_id:
                    blobs = chunk.compaction_blobs
                    # Rebuild items from blobs + current response's non-blob
                    # output only. Reusing old items would retain duplicated
                    # pre-compaction context and defeat compaction.
                    completed_output = [
                        i for i in (chunk.raw_output or []) if i.get("type") != "compaction"
                    ]
                    items[:] = list(blobs) + completed_output
                    self._sessions.update_meta(
                        session_id,
                        compaction_blob={
                            "at": datetime.now(UTC).isoformat(),
                            "model": chunk.model or self._config.model,
                            "blobs": blobs,
                            "output": completed_output,
                        },
                    )
                    self._sessions.replace_messages(session_id, list(items))
                    logger.info(
                        "Stream compaction: {} blobs persisted",
                        len(blobs),
                    )
            # ── Post-stream finalize ─────────────────────────────────
            # All run inside the try so a failure here still hits the
            # finally's ``done`` fallback.
            content = "".join(parts)
            # Image-hoist: rewrite ``workpilot-image://`` sentinels in-place
            # to canonical sha-form so the frontend renders inline images;
            # collect refs for ``OutboundMessage.attachments``. Native-path
            # raw_output items have already been persisted mid-stream; we
            # accept the residual sentinels in the native-path JSONL as a
            # phase-1 limitation. The chat-path entry below is patched
            # cleanly + carries the ``_attachments`` sidecar.
            if content:
                stripped, refs = extract_outputs(content, workspace=self._workspace)
                if refs:
                    hoisted_refs = refs
                    content = stripped
            # Run on_message_sent hook BEFORE Chat-path persist so a REJECT
            # verdict can drop the hoisted attachments + swap content to the
            # blocked placeholder, and only the redacted version reaches
            # JSONL. (Native path persisted raw_output items mid-stream
            # above and is a phase-1 limitation — the hook still sees the
            # complete content for leak-scan purposes.)
            if self._hooks:
                msg_ctx = MessageHookContext(
                    content=content, channel=channel, session_id=session_id or ""
                )
                result = await self._hooks.dispatch_checked("on_message_sent", msg_ctx)
                if result.verdict == HookVerdict.REJECT:
                    logger.warning(
                        "Streamed outbound message blocked by hook: {}",
                        result.reason,
                    )
                    content = "[Message blocked by security policy]"
                    # Drop attachments — otherwise the leak/policy that
                    # triggered the REJECT still ships the bytes via the
                    # supplementary attachments-only outbound (see
                    # ``_process_message`` elif branch) AND lands in the
                    # ``_attachments`` sidecar below.
                    hoisted_refs = None
                elif result.data and isinstance(result.data, MessageHookContext):
                    content = result.data.content
            # Persist assistant message: native path already persisted the
            # message item from raw_output; Chat path needs a Chat-format entry.
            if not _has_native_output and session_id:
                msg: dict[str, Any] = {"role": "assistant", "content": content}
                if hoisted_refs:
                    msg["_attachments"] = hoisted_refs
                self._sessions.add_message(session_id, msg)
                if items is not None:
                    items.append(msg)
            # Persist interrupt marker AFTER assistant content (correct ordering).
            if _stream_interrupted and session_id:
                self._finalize_interrupt(session_id, items or [])
            # Emit ``done`` LAST — after JSONL persist + hooks. Frontend that
            # refetches the session on done is now guaranteed to see the
            # rewritten content + sidecar.
            await self._bus.dispatch_outbound(
                StreamingChunk(
                    channel=channel,
                    channel_id=channel_id,
                    content="",
                    done=True,
                )
            )
            done_dispatched = True
        finally:
            # Exception path: ensure done is dispatched so channels exit
            # streaming state. Best-effort — if even this raises, we just
            # log and let the parent error path take over.
            if not done_dispatched:
                try:
                    await self._bus.dispatch_outbound(
                        StreamingChunk(
                            channel=channel,
                            channel_id=channel_id,
                            content="",
                            done=True,
                        )
                    )
                except Exception as exc:
                    logger.warning("Stream done-marker dispatch failed: {}", exc)

        return content, hoisted_refs
