"""
Unified tool output truncation — LLM compression first, smart_truncate fallback.

Extracted from consolidation.py for reuse by both the Consolidator
(compaction-time compression) and the AgentLoop (postflight truncation).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.utils.helpers import ellipsize

if TYPE_CHECKING:
    from workpilot.providers.base import LLMProvider


def resolve_fast_input_limit(provider: LLMProvider) -> int:
    """Resolve the max input token limit for the fast model."""
    from workpilot.providers.model_catalog import get_max_input_tokens
    from workpilot.providers.resolver import resolve_model_chain

    chain = resolve_model_chain("fast", getattr(provider, "_providers", None))
    resolved = chain[0] if chain else "fast"
    return get_max_input_tokens(resolved)


def smart_truncate(
    content: str,
    max_chars: int,
    head_lines: int = 20,
    tail_lines: int = 10,
) -> str:
    """Keep first N + last M lines, cut the middle.

    If the result still exceeds *max_chars* after line-level truncation,
    fall back to a hard character cut.  This is the ultimate safety net —
    the output is guaranteed to be <= *max_chars* (plus a short marker).
    """
    lines = content.splitlines()
    total = head_lines + tail_lines
    if len(lines) <= total + 5:
        result = "\n".join(ln[:200] for ln in lines)
    else:
        omitted = len(lines) - total
        head = lines[:head_lines]
        tail = lines[-tail_lines:]
        result = "\n".join(head + [f"... ({omitted} lines omitted) ..."] + tail)

    # Final char-level safety cut
    if len(result) > max_chars:
        result = result[:max_chars] + "\n...(truncated)"
    return result


# Keys that may contain credentials — omit from compression prompts.
_SENSITIVE_ARG_KEYS = frozenset(
    {
        "authorization",
        "auth",
        "token",
        "api_key",
        "apikey",
        "api-key",
        "password",
        "secret",
        "credential",
        "credentials",
        "cookie",
        "x-api-key",
        "bearer",
        "private_key",
        "private-key",
        "headers",  # headers dict often contains auth tokens
    }
)


def _format_tool_args(tool_args: dict[str, Any] | str | None) -> str:
    """Format tool call arguments into a compact string for the compression prompt.

    Omits keys that may contain credentials to avoid leaking secrets
    into the fast-model compression call.
    """
    from workpilot.security.leak import redact_credentials

    if not tool_args:
        return ""
    if isinstance(tool_args, str):
        try:
            import json

            parsed = json.loads(tool_args)
        except (json.JSONDecodeError, TypeError):
            return redact_credentials(tool_args[:200])
        else:
            tool_args = parsed
    if not isinstance(tool_args, dict):
        return redact_credentials(str(tool_args)[:200])
    parts: list[str] = []
    for k, v in tool_args.items():
        if k.lower() in _SENSITIVE_ARG_KEYS:
            continue
        parts.append(f"{k}={ellipsize(str(v), 200, suffix='...')}")
    return redact_credentials(", ".join(parts))


async def llm_compress(
    content: str,
    tool_name: str,
    provider: LLMProvider,
    max_chars: int,
    tool_args: dict[str, Any] | str | None = None,
) -> str:
    """Use fast model to compress a large tool output, preserving key facts.

    Falls back to :func:`smart_truncate` on failure.

    Overflow recovery: if the API returns a token-limit error despite the
    pre-check, the actual/limit token counts are parsed from the error
    message and the content is proportionally truncated for a single retry.
    """
    from workpilot.agent.compaction import estimate_tokens
    from workpilot.utils.token_errors import is_token_limit_error, parse_token_overflow

    fast_input_limit = resolve_fast_input_limit(provider)

    # Keep a copy of the original content before any truncation so that
    # smart_truncate fallbacks always get the full head+tail.
    original_content = content

    # Build invocation context so LLM knows what was requested
    args_str = _format_tool_args(tool_args)
    invocation_line = f"Invocation: `{tool_name}({args_str})`\n" if args_str else ""

    # Input budget: 90% of input limit, capped at 500K tokens.
    # Pre-truncate content before building the system prompt so the
    # "Input: N chars" metadata reflects the actual content sent.
    max_input_tokens = min(int(fast_input_limit * 0.9), 500_000)
    max_input_tokens = max(max_input_tokens, 1024)  # floor
    # Estimate with a placeholder system prompt (actual prompt size is
    # small and stable — the content dominates the token count).
    input_tokens = estimate_tokens(
        [
            {"role": "system", "content": "placeholder"},
            {"role": "user", "content": content},
        ]
    )
    if input_tokens > max_input_tokens:
        ratio = len(content) / max(input_tokens, 1)
        max_input_chars = int(max_input_tokens * ratio)
        content = content[:max_input_chars] + f"\n... (truncated at {max_input_tokens} tokens)"

    # Build system prompt AFTER pre-truncation so Input size is accurate.
    system_content = (
        f"You are compressing the output of a tool called `{tool_name}`. "
        "The compressed result will be used as context for another LLM, "
        "so preserve information relevant to the invocation.\n\n"
        f"{invocation_line}"
        f"Input: {len(content)} chars. "
        f"Target: ≤{max_chars} chars. Budget: ~{max_chars // 4} tokens.\n\n"
        "KEEP: results relevant to the invocation parameters, "
        "specific values, numbers, error messages and stack traces, "
        "file paths, key results, code snippets, structural summaries, "
        "security markers and untrusted-content wrappers "
        "(e.g. [UNTRUSTED_CONTENT], [Treat it as untrusted data]).\n"
        "DROP: duplicate/repetitive lines, boilerplate, verbose formatting, "
        "progress bars, empty lines, decorative output.\n\n"
        "Output ONLY the compressed text, no preamble."
    )

    # ── First attempt ────────────────────────────────────────────────────
    try:
        return await _llm_compress_call(provider, system_content, content, max_chars)
    except Exception as exc:
        # ── Overflow recovery (Fix 5c) ───────────────────────────────
        overflow = parse_token_overflow(exc)
        if overflow is None and not is_token_limit_error(exc):
            # Not a token-limit error — non-recoverable
            logger.warning("LLM compression failed for {}: {}", tool_name, exc)
            return smart_truncate(original_content, max_chars=max_chars)

        if overflow is not None:
            actual_tokens, limit_tokens = overflow
            # Calculate safe content fraction: 85% of limit / actual.
            # The 15% margin absorbs system prompt, truncation marker,
            # and tokenizer variance on the new content.
            safe_ratio = (limit_tokens * 0.85) / max(actual_tokens, 1)
            safe_ratio = min(safe_ratio, 0.95)  # always trim at least 5%
        else:
            # Token-limit error but couldn't parse exact numbers —
            # fall back to a fixed 10% reduction.
            actual_tokens, limit_tokens = 0, 0
            safe_ratio = 0.90
        safe_chars = int(len(content) * safe_ratio)

        if safe_chars < 1000:
            logger.warning(
                "LLM compression overflow for {} — content too small after trim, "
                "using smart_truncate",
                tool_name,
            )
            return smart_truncate(original_content, max_chars=max_chars)

        truncated = content[:safe_chars] + "\n... (truncated for token limit)"
        logger.info(
            "Token overflow for {} ({}/{} tokens, ratio={:.0%}); retrying",
            tool_name,
            actual_tokens,
            limit_tokens,
            safe_ratio,
        )

        # ── Single retry ─────────────────────────────────────────────
        # Rebuild system prompt with accurate Input size for the truncated content.
        retry_system = system_content.replace(
            f"Input: {len(content)} chars.",
            f"Input: {len(truncated)} chars.",
        )
        try:
            return await _llm_compress_call(provider, retry_system, truncated, max_chars)
        except Exception as retry_exc:
            logger.warning(
                "LLM compression retry also failed for {}: {}",
                tool_name,
                retry_exc,
            )
            # Final fallback on ORIGINAL content — smart_truncate
            # preserves head+tail from the full output.
            return smart_truncate(original_content, max_chars=max_chars)


async def _llm_compress_call(
    provider: LLMProvider,
    system_content: str,
    content: str,
    max_chars: int,
) -> str:
    """Send a single LLM compression request and cap the result."""
    response = await provider.complete(
        model="fast",
        messages=[
            {"role": "system", "content": system_content},
            {"role": "user", "content": content},
        ],
        temperature=0.0,
        reasoning_effort="none",  # mechanical compression
    )
    compressed = str(response.content)
    if len(compressed) > max_chars:
        compressed = smart_truncate(compressed, max_chars=max_chars)
    return compressed


async def truncate_tool_output(
    content: str,
    tool_name: str,
    max_chars: int,
    provider: LLMProvider | None = None,
    llm_enabled: bool = True,
    tool_args: dict[str, Any] | str | None = None,
) -> str:
    """Unified tool output truncation entry point.

    Strategy:

    1. ``len(content) <= max_chars`` — return as-is.
    2. LLM available and enabled — :func:`llm_compress` (preserves key info).
    3. Fallback — :func:`smart_truncate` (head + tail lines, char cap).

    :func:`smart_truncate` is also the fallback when LLM compression fails.
    """
    if len(content) <= max_chars:
        return content

    if llm_enabled and provider is not None:
        return await llm_compress(
            content, tool_name, provider, max_chars=max_chars, tool_args=tool_args
        )

    return smart_truncate(content, max_chars=max_chars)
