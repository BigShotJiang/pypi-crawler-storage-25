"""
Claude bridge — wraps ``claude_agent_sdk.query()`` for bridge mode.

See design/features/bridge-mode.md §5.1. Turns a user prompt into a single
call to the Claude Code SDK and streams deltas back as StreamingChunks.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.agent.bridge import DispatchResult, bridge_origin
from workpilot.agent.tools._shared import build_claude_agent_options
from workpilot.bus.events import OutboundMessage, StreamingChunk
from workpilot.security.leak import redact_credentials

if TYPE_CHECKING:
    from workpilot.agent.bridge import BridgeState
    from workpilot.bus.queue import MessageBus
    from workpilot.session.manager import SessionManager


class ClaudeBridge:
    """Forward a turn to Claude Code SDK; render deltas as StreamingChunks."""

    def __init__(
        self,
        *,
        bus: MessageBus,
        sessions: SessionManager,
        workspace: Path | str = ".",
        cli_path: str | Path | None = None,
        dangerously_skip_permissions: bool = False,
        setting_sources: list[str] | None = None,
    ) -> None:
        self._bus = bus
        self._sessions = sessions
        self._workspace = workspace
        self._cli_path = cli_path
        self._dangerously_skip_permissions = dangerously_skip_permissions
        self._setting_sources = setting_sources

    async def dispatch(
        self,
        *,
        prompt: str,
        state: BridgeState,
        session_id: str,
        attachments: list[dict[str, Any]] | None = None,
    ) -> DispatchResult:
        """Forward a single prompt to Claude.

        ``attachments`` are user-uploaded files resolved to on-disk
        AttachmentRef dicts (``{sha256, path, content_type, kind, …}``).
        Claude receives them by reference — the path is inlined into the
        prompt and the attachments directory is added to the SDK's
        ``add_dirs`` so the CLI can read the files without a permission
        prompt.

        ``DispatchResult.terminal_reason`` is set when the CLI reported a
        non-retriable condition (max-turns, auth expired, quota rejected).
        ``DispatchResult.is_error`` is True for any error condition
        surfaced to the user (terminal OR transient).
        """
        from claude_agent_sdk import (
            AssistantMessage,
            ResultMessage,
            SystemMessage,
            UserMessage,
            query,
        )

        # Version-conditional — newer SDKs emit RateLimitEvent inline in the
        # Message union.
        try:
            from claude_agent_sdk import RateLimitEvent
        except ImportError:  # pragma: no cover — older SDK without RateLimitEvent
            rate_limit_event_cls: type | None = None
        else:
            rate_limit_event_cls = RateLimitEvent

        # Fresh-session path: state.external_id is empty string; Claude SDK
        # picks its own session_id on first response.
        resume_id = state.external_id if state.external_id else None

        # Attachments → prompt prefix + ``add_dirs`` authorisation.
        # Claude Code CLI auto-inlines images from file paths mentioned
        # in the prompt (image MIME types are rendered as multimodal
        # content), and for text/code files it uses its Read tool. Both
        # paths require the directory to be readable without a prompt —
        # hence the ``add_dirs`` entry for the attachments folder.
        extra_dirs: list[str | Path] = []
        prompt_with_attachments = prompt
        if attachments:
            from workpilot.security.attachments import attachments_dir

            extra_dirs.append(attachments_dir())
            lines = []
            for att in attachments:
                path_str = str(att.get("path") or "").strip()
                if not path_str:
                    continue
                name = att.get("name") or Path(path_str).name
                lines.append(f"- `{path_str}` ({name})")
            if lines:
                prompt_with_attachments = (
                    "The user attached the following files — read them as needed:\n"
                    + "\n".join(lines)
                    + "\n\n"
                    + prompt
                )

        # ``state.model`` is None unless the caller (``/bridge`` slash or
        # ``BridgeTool``) pinned a specific model for this attempt. None
        # is the pass-through signal — with it, the SDK omits ``--model``
        # from the CLI invocation, and Claude Code falls back to the
        # user's own ``~/.claude/settings.json`` model setting.
        options = build_claude_agent_options(
            model=state.model,
            workspace=self._workspace,
            resume_session_id=resume_id,
            cli_path=self._cli_path,
            dangerously_skip_permissions=self._dangerously_skip_permissions,
            setting_sources=self._setting_sources,
            add_dirs=extra_dirs or None,
        )

        text_parts: list[str] = []
        new_session_id: str | None = None
        streamed = False
        # ``error_text`` is user-visible (always surfaced when is_error);
        # ``terminal_reason`` triggers bridge auto-exit and is set ONLY for
        # known non-retriable subtypes. Fail closed on unknown subtype:
        # stay bridged and show the error; user decides via /bridge off.
        error_text: str | None = None
        terminal_reason: str | None = None

        supports_streaming = not state.is_teams

        async for message in query(prompt=prompt_with_attachments, options=options):
            # Content blocks from full AssistantMessage — the 0.1.48/0.1.65
            # fallback path when include_partial_messages is False.
            if isinstance(message, AssistantMessage):
                # Capture the CLI-resolved model so ``/model`` and ``/bridge``
                # status can show the *actual* running model — useful when
                # ``state.model`` is None (user never pinned, CLI used its
                # own default). ``AssistantMessage.model`` is the resolved
                # model id for THIS turn; the SDK sets it on every
                # assistant response.
                msg_model = getattr(message, "model", None)
                if isinstance(msg_model, str) and msg_model:
                    state.active_model = msg_model
                for block in message.content:
                    rendered = self._render_block(block)
                    if rendered is None:
                        continue
                    # Leak-scan every user-visible fragment BEFORE it leaves
                    # the process — the external CLI may echo secrets the
                    # user pasted into an auth flow, etc.
                    safe = redact_credentials(rendered)
                    text_parts.append(safe)
                    if supports_streaming:
                        # dispatch_outbound bypasses the bounded outbound
                        # queue — StreamingChunks shouldn't consume queue
                        # capacity during long streams (no consumer drains
                        # chunks, so publish_outbound would backpressure).
                        await self._bus.dispatch_outbound(
                            StreamingChunk(
                                channel=state.channel,
                                channel_id=state.channel_id,
                                content=safe,
                            )
                        )
                        streamed = True

            elif isinstance(message, ResultMessage):
                # Capture the SDK-assigned session_id for resume next turn.
                if message.session_id:
                    new_session_id = message.session_id
                # Terminal-signal classification (§5.3). Fail closed on unknown:
                # stay bridged and surface the error text, let the user decide.
                # The error suffix is always shown to the user; only known
                # non-retriable subtypes trigger bridge auto-exit.
                if message.is_error:
                    error_text = self._format_error(message)
                    if self._is_terminal_subtype(message):
                        terminal_reason = error_text

            elif rate_limit_event_cls is not None and isinstance(message, rate_limit_event_cls):
                info = getattr(message, "rate_limit_info", None)
                status = getattr(info, "status", None) if info is not None else None
                rl_type = getattr(info, "rate_limit_type", "?") if info is not None else "?"
                if status == "rejected":
                    reason = f"Rate limit rejected ({rl_type})"
                    error_text = reason
                    terminal_reason = reason
                elif status == "allowed_warning" and supports_streaming:
                    # Soft warning — publish a notice, stay bridged. Teams
                    # skips this (would arrive as a separate activity); the
                    # final OutboundMessage carries the warning text instead.
                    await self._bus.dispatch_outbound(
                        StreamingChunk(
                            channel=state.channel,
                            channel_id=state.channel_id,
                            content=f"\n[rate limit warning: {rl_type}]",
                        )
                    )
                    streamed = True
            # SystemMessage / UserMessage — the SDK emits these for init,
            # tool invocation round-trips, and user-turn echo. Uninteresting
            # to bridge (user already saw their own prompt; tool invocations
            # are rendered via AssistantMessage content blocks). Silently skip.
            elif isinstance(message, (SystemMessage, UserMessage)):
                continue
            # case _: Message-union members introduced in a newer SDK version
            # (e.g., future event types). Log at DEBUG and keep going so a
            # bump that adds members doesn't crash bridge.
            else:
                logger.debug(
                    "ClaudeBridge: unknown SDK message type {} — skipped",
                    type(message).__name__,
                )

        # Compose final reply_text for JSONL persistence. redact_credentials
        # was already applied per-fragment during streaming; apply it to the
        # error suffix here too. Error is surfaced whenever is_error — only
        # the terminal-auto-exit decision cares about subtype classification.
        error_suffix = (
            f"[Claude error: {redact_credentials(error_text)}]" if error_text is not None else ""
        )
        if not text_parts and not error_suffix:
            reply_text = "(no response)"
        elif error_suffix:
            reply_text = ("\n".join(text_parts) + "\n\n" if text_parts else "") + error_suffix
        else:
            reply_text = "\n".join(text_parts)

        # Emit the error suffix as a final chunk on streaming surfaces so the
        # user sees it live; also include it in the buffered reply_text that
        # the final OutboundMessage carries. ``done=True`` closes the stream.
        if streamed and error_suffix:
            await self._bus.dispatch_outbound(
                StreamingChunk(
                    channel=state.channel,
                    channel_id=state.channel_id,
                    content="\n" + error_suffix,
                )
            )
        if streamed:
            await self._bus.dispatch_outbound(
                StreamingChunk(
                    channel=state.channel,
                    channel_id=state.channel_id,
                    content="",
                    done=True,
                )
            )

        # ALWAYS publish the full OutboundMessage — streaming or not. The
        # response queue (used by /api/chat's submit_and_wait, SSE handler,
        # and WS) requires a final message; if bridge only emits chunks on
        # a channel that didn't register a stream queue, the user's request
        # hangs until timeout. Streaming-capable channels render chunks
        # progressively; the final OutboundMessage is the authoritative
        # reply for persistence + non-streaming consumers.
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=state.channel,
                channel_id=state.channel_id,
                content=reply_text,
                metadata={"source": "bridge", "_origin": bridge_origin("claude")},
            )
        )
        # Tell AgentLoop to skip its own final publish — we took responsibility.
        streamed = True

        return DispatchResult(
            reply=reply_text,
            streamed=streamed,
            new_external_id=new_session_id,
            terminal_reason=terminal_reason,
            is_error=error_text is not None,
        )

    # ── Helpers ──────────────────────────────────────────────────────────

    def _render_block(self, block: Any) -> str | None:
        """Translate a ContentBlock to a text fragment. None = suppress.

        Imports SDK block classes locally so this stays safe to call even
        when the SDK is absent (callers only run after successful query()).
        """
        from claude_agent_sdk import (
            TextBlock,
            ThinkingBlock,
            ToolResultBlock,
            ToolUseBlock,
        )

        try:
            from claude_agent_sdk import ServerToolResultBlock, ServerToolUseBlock
        except ImportError:  # pragma: no cover — older SDK
            ServerToolUseBlock = None  # type: ignore[assignment, misc]
            ServerToolResultBlock = None  # type: ignore[assignment, misc]

        if isinstance(block, TextBlock):
            return block.text
        if isinstance(block, ToolUseBlock):
            return f"\n[{block.name}: {_compact(block.input)}]"
        if isinstance(block, ToolResultBlock):
            # Skip — the tool output is already reflected in subsequent TextBlocks.
            return None
        if ServerToolUseBlock is not None and isinstance(block, ServerToolUseBlock):
            return f"\n[{block.name}: {_compact(block.input)}]"
        if ServerToolResultBlock is not None and isinstance(block, ServerToolResultBlock):
            return None
        if isinstance(block, ThinkingBlock):
            # Suppressed by default — TODO: make configurable via show_reasoning.
            return None
        logger.debug("ClaudeBridge: unknown block type {} — skipped", type(block).__name__)
        return None

    # Known non-retriable ResultMessage.subtype strings produced by the
    # Claude Code CLI. Seen via live testing + claude-agent-sdk docs;
    # anything else with is_error=True is surfaced but stays bridged
    # (fail closed on unknown — spec §5.3).
    _TERMINAL_SUBTYPES: frozenset[str] = frozenset(
        {
            "error_max_turns",
        }
    )

    def _is_terminal_subtype(self, message: Any) -> bool:
        """Classify whether an is_error ResultMessage is non-retriable."""
        subtype = str(getattr(message, "subtype", "") or "")
        if subtype in self._TERMINAL_SUBTYPES:
            return True
        # Secondary signal (0.1.65+): a non-empty permission_denials list
        # with the user having exhausted retries — treat as terminal.
        denials = getattr(message, "permission_denials", None)
        if denials:
            return True
        return False

    def _format_error(self, message: Any) -> str:
        """Compose a human-readable error summary from a ResultMessage."""
        subtype = getattr(message, "subtype", "") or "error"
        stop_reason = getattr(message, "stop_reason", None)
        parts = [subtype]
        if stop_reason:
            parts.append(f"stop_reason={stop_reason}")
        # 0.1.65+: explicit error list / permission denials.
        errors = getattr(message, "errors", None)
        if errors:
            parts.append(f"errors={errors!r}")
        denials = getattr(message, "permission_denials", None)
        if denials:
            parts.append(f"permission_denials={len(denials)}")
        return " ".join(parts)


def _compact(value: Any, limit: int = 60) -> str:
    """One-line compact repr for inline tool markers."""
    text = repr(value)
    if len(text) > limit:
        return text[: limit - 1] + "…"
    return text
