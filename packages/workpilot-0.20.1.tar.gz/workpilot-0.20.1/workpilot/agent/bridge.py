"""
Bridge mode — direct pass-through to Claude Code / GitHub Copilot CLI.

See design/features/bridge-mode.md. Bridge replaces the agent loop for a
session with a thin forwarder to the external CLI. Message-level surfaces
(prompt-injection scan, on_message_received/sent, audit) still run — only
the LLM ↔ tool loop is replaced.

This module owns the only BridgeRegistry in the runtime. AgentLoop calls
``ensure_state`` on every inbound; if a state is present, control short-
circuits into ``dispatch`` instead of ``_agent_loop``.
"""

from __future__ import annotations

import asyncio
import hashlib
import time
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from workpilot.bus.events import EventType, InboundMessage, OutboundMessage
from workpilot.config.schema import ChannelType, SecurityProfile
from workpilot.security.approval import ApprovalStatus
from workpilot.security.leak import redact_credentials
from workpilot.security.risk import PolicyAction, RiskScore, lookup_policy

if TYPE_CHECKING:
    from pathlib import Path

    from workpilot.bus.queue import MessageBus
    from workpilot.config.schema import ClaudeCodeToolConfig, CopilotToolConfig
    from workpilot.security.approval import ApprovalManager
    from workpilot.security.audit import AuditLogger
    from workpilot.session.bridge_store import BridgeSessionStore
    from workpilot.session.manager import SessionManager


BridgeTarget = Literal["claude", "copilot"]

#: Valid bridge targets. Used to filter ``_bridge_target`` values read
#: from JSONL before they feed into anything with filesystem-path
#: implications (``BridgeSessionStore.get_turns``/``path_for``).
BRIDGE_TARGETS: tuple[str, ...] = ("claude", "copilot")

#: Common model aliases accepted by each target CLI — shown in the
#: ``/bridge`` status hint so users (and the LLM) have a starting set.
#: Not a complete list; the CLI accepts any model string its auth has
#: access to (the Copilot CLI exposes many more via ``/model``; Claude
#: Code accepts anthropic model slugs). Deliberately short so the hint
#: stays on one line.
_SUGGESTED_MODELS: dict[str, tuple[str, ...]] = {
    "claude": ("sonnet", "opus", "haiku"),
    "copilot": ("claude-sonnet-4.6", "claude-haiku-4.5", "gpt-5.4"),
}


def suggested_models(target: str) -> tuple[str, ...]:
    """Return a small list of model aliases to hint at in ``/bridge``
    status output. Empty tuple for unknown targets."""
    return _SUGGESTED_MODELS.get(target, ())


#: User-facing labels for each target. Source of truth for both the
#: ``/bridge`` slash reply and the BridgeTool no-target status reply.
_TARGET_LABELS: dict[str, str] = {
    "claude": "Claude Code",
    "copilot": "GitHub Copilot",
}


def target_label(target: str) -> str:
    """User-facing label for a bridge target (e.g. 'claude' → 'Claude Code').

    Falls back to the raw target name for unknown values so callers can use
    it unconditionally without defensive branching.
    """
    return _TARGET_LABELS.get(target, target)


#: Threshold at which ``format_model_list`` switches from single-line
#: ``·``-separated output to grouped multi-line. Six fits comfortably in
#: one visual line even on narrow terminals; longer lists wrap awkwardly
#: and are better organised by family prefix.
_MODEL_LIST_GROUP_THRESHOLD = 6


def format_model_list(models: list[str]) -> str:
    """Render a list of model ids for ``/bridge`` / ``/model`` output.

    * ≤ 6 models → single line, `` · `` separator. Compact, reads like a
      menu of options.
    * > 6 models → grouped by first hyphen-separated prefix
      (``claude-sonnet-4.6`` → ``claude``). Each multi-member group
      gets its own bullet with the prefix as the label; singleton
      prefixes collapse into a trailing ``other`` bullet. Prefix order
      follows first-appearance so the SDK's own ordering leaks through.

    Empty input returns ``""`` so the caller can drop the whole line
    without a stray separator.
    """
    if not models:
        return ""
    if len(models) <= _MODEL_LIST_GROUP_THRESHOLD:
        return " · ".join(f"`{m}`" for m in models)

    # Group by first-hyphen prefix. Models without a hyphen bucket under
    # their own name — they'll end up in "other" below (a list of just
    # one can't stand on its own row).
    groups: dict[str, list[str]] = {}
    for m in models:
        key = m.split("-", 1)[0] if "-" in m else m
        groups.setdefault(key, []).append(m)

    lines: list[str] = []
    singletons: list[str] = []
    for key, members in groups.items():
        if len(members) == 1:
            singletons.extend(members)
        else:
            lines.append(f"- {key}: " + " · ".join(f"`{x}`" for x in members))
    if singletons:
        lines.append("- other: " + " · ".join(f"`{x}`" for x in singletons))
    return "\n".join(lines)


def _format_age(ts_ms: int) -> str:
    """Render a past timestamp (ms since epoch) as a short relative
    age — ``just now``, ``Nm ago``, ``Nh ago``, ``Nd ago``. Clamps
    negative deltas (clock skew) to ``just now``.
    """
    now_ms = int(time.time() * 1000)
    delta_s = max(0, (now_ms - ts_ms) // 1000)
    if delta_s < 60:
        return "just now"
    mins = delta_s // 60
    if mins < 60:
        return f"{mins}m ago"
    hours = mins // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    return f"{days}d ago"


#: Max characters shown for a session summary in
#: ``format_recent_sessions_block`` — longer summaries truncate with ``…``.
#: Keeps the status line scannable in narrow channel renderers
#: (CLI ~80 col, Teams mobile ~40 col).
_SUMMARY_PREVIEW_CAP = 50

#: Default number of recent CLI-side sessions surfaced in ``/bridge`` status.
_RECENT_SESSIONS_LIMIT = 3


def _truncate_summary(summary: str | None) -> str:
    """Collapse whitespace + truncate a session summary for display."""
    text = " ".join((summary or "(no summary)").split())
    if len(text) > _SUMMARY_PREVIEW_CAP:
        return text[: _SUMMARY_PREVIEW_CAP - 1] + "…"
    return text


async def _list_recent_claude_sessions(workspace: str | Path, limit: int) -> list[dict[str, Any]]:
    """Read the N most-recent Claude sessions for ``workspace``.

    Returns normalised ``{"sessionId", "summary", "modified_ms"}`` dicts —
    same shape as ``CopilotBridge.list_sessions`` — so the caller doesn't
    branch on target. Sync SDK call is off-loaded to a worker thread
    (cold disk read can be ~1.8s for cwd-scoped lookup).

    Best-effort: any error (SDK missing, disk read failure, empty) → ``[]``.
    """
    try:
        from claude_agent_sdk import list_sessions  # type: ignore[import]

        infos = await asyncio.to_thread(list_sessions, directory=str(workspace), limit=limit)
    except Exception as exc:
        logger.debug("_list_recent_claude_sessions: {}", exc)
        return []

    out: list[dict[str, Any]] = []
    for info in infos:
        # ``custom_title`` > ``summary`` > ``first_prompt`` gives the most
        # specific non-empty display name. custom_title is user-picked;
        # summary is the CLI's auto-generated title; first_prompt is
        # the raw first user message before auto-summarisation.
        summary = info.custom_title or info.summary or info.first_prompt
        out.append(
            {
                "sessionId": info.session_id,
                "summary": summary,
                "modified_ms": info.last_modified,
            }
        )
    return out


async def format_recent_sessions_block(
    service: BridgeService,
    target: BridgeTarget,
    workspace: str | Path,
    *,
    limit: int = _RECENT_SESSIONS_LIMIT,
) -> str | None:
    """Render a block of the N most-recent CLI-side sessions for this
    workspace as copyable ``resume=<id>`` commands, or ``None`` when
    none are available.

    Layout:

    * exactly 1 session → ``**Last session:** <summary> · <age> · resume: …``
    * 2+ sessions → ``**Recent sessions:**`` header + one bullet per session.

    Empty list / SDK error / any failure → ``None``; caller drops the
    block and main status output still renders.

    Target-specific fetch:

    * **Claude** — sync disk read via ``claude_agent_sdk.list_sessions``,
      wrapped in ``asyncio.to_thread``. No subprocess cost.
    * **Copilot** — RPC via ``CopilotBridge.list_sessions``. The
      subprocess is usually already warm (``list_supported_models``
      runs earlier in the same status render), so this is a quick RPC
      in the common case.
    """
    if target == "claude":
        sessions = await _list_recent_claude_sessions(workspace, limit)
    elif target == "copilot":
        try:
            await service._ensure_bridge_handler("copilot")
            if service._copilot_bridge is None:
                return None
            sessions = await service._copilot_bridge.list_sessions(cwd=str(workspace), limit=limit)
        except Exception as exc:
            # Defensive: _ensure_bridge_handler imports the SDK and
            # constructs CopilotBridge — either step could raise if the
            # install is broken. list_sessions itself is already internally
            # try/except'd, but the ensure path isn't. A status-query
            # should never crash the render.
            logger.debug("format_recent_sessions_block copilot: {}", exc)
            return None
    else:
        return None

    if not sessions:
        return None

    def _render_one(s: dict[str, Any]) -> str:
        summary = _truncate_summary(s.get("summary"))
        age = _format_age(int(s.get("modified_ms", 0) or 0))
        sid = s.get("sessionId") or ""
        return f"{summary} · {age} · resume: `/bridge {target} resume={sid}`"

    if len(sessions) == 1:
        return f"**Last session:** {_render_one(sessions[0])}"

    return "**Recent sessions:**\n" + "\n".join(f"- {_render_one(s)}" for s in sessions)


def format_bridge_model_line(state: BridgeState) -> str:
    """Render the model line for ``/bridge`` / ``/model`` status output.

    Three cases, in priority order:

    1. ``state.model`` set — user pin, tagged ``(pinned)``
    2. ``state.active_model`` set — observed running model, tagged ``(running)``
    3. neither — pre-first-turn hint

    Tag choice: ``(running)`` — not ``(CLI default)`` — because
    ``active_model`` reflects *the model the session is currently
    using*, which may or may not equal the CLI's configured default.
    Example: after ``/model opus`` then ``/model default`` the pin
    clears but the live Copilot session keeps running ``opus`` (the
    SDK has no "reset to CLI default" API for live sessions). Calling
    that ``(CLI default)`` would lie.
    """
    if state.model:
        return f"`{state.model}` _(pinned)_"
    if state.active_model:
        return f"`{state.active_model}` _(running)_"
    return "_(pending first turn)_"


def bridge_origin(target: BridgeTarget) -> str:
    """Canonical ``_origin`` marker for bridge-produced messages.

    Single source of truth for the string audit consumers / session
    renderers match on. Used by both the handler publish paths (Claude,
    Copilot) and the assistant-entry persistence in ``BridgeService.dispatch``.
    """
    return f"{target}-bridge"


def build_synthetic_off(
    target: str,
    on_ts: str,
    bridge_store: BridgeSessionStore | None,
    canonical_sid: str,
) -> dict[str, Any]:
    """Construct a synthetic ``_bridge_toggle off`` marker for an orphan ON.

    An orphan ON happens when the process dies before ``exit_session``
    fires, leaving the JSONL with an unclosed toggle. Two call sites
    share this builder so the on-disk heal (``BridgeService._heal_orphan_ons``)
    and the response-time synthesis (``handle_session_detail``) emit
    byte-identical marker shapes:

    * turn count derived from the bridge log (entries with ``_ts > on_ts``)
    * ``_ts`` set to the latest matching turn's ts, or ``on_ts`` itself
      when the log is empty. This keeps the synthetic OFF **before**
      any post-crash activity that landed in the main session later —
      critical, otherwise a subsequent read would slurp those regular
      messages into the orphan bridge segment.
    * ``_bridge_synthetic: True`` flag for downstream differentiation.
    """
    turn_count = 0
    synthetic_ts = on_ts
    if bridge_store is not None:
        try:
            for t in bridge_store.get_turns(canonical_sid, target):  # type: ignore[arg-type]
                t_ts = str(t.get("_ts") or "")
                if t_ts > on_ts:
                    turn_count += 1
                    if t_ts > synthetic_ts:
                        synthetic_ts = t_ts
        except Exception as exc:
            logger.warning(
                "build_synthetic_off: turn count failed ({} / {}): {}",
                canonical_sid,
                target,
                exc,
            )
    return {
        "role": "system",
        "content": "Bridge mode ended: prior session did not close cleanly.",
        "_bridge_toggle": True,
        "_bridge_action": "off",
        "_bridge_target": target,
        "_bridge_turns": turn_count,
        "_bridge_synthetic": True,
        "_ts": synthetic_ts,
    }


def detect_orphan_ons(
    main_msgs: list[dict[str, Any]],
    *,
    exclude_target: str | None = None,
) -> dict[str, str]:
    """Walk ``_bridge_toggle`` markers; return still-open ONs as ``{target: on_ts}``.

    A bridge can only have one open ON per target per session (toggling
    to a different target forces an exit first), so each key maps to
    exactly one timestamp. ``exclude_target`` drops the currently-live
    bridge (registry-matched) so only true orphans remain.

    Only ``BRIDGE_TARGETS`` values are returned — an unknown target in
    the JSONL is ignored rather than trusted, since the string feeds
    into filesystem paths further down.
    """
    pending_on: dict[str, str] = {}
    for m in main_msgs:
        if not m.get("_bridge_toggle"):
            continue
        tgt = m.get("_bridge_target")
        if not isinstance(tgt, str) or tgt not in BRIDGE_TARGETS:
            continue
        action = m.get("_bridge_action")
        if action == "on":
            pending_on[tgt] = str(m.get("_ts") or "")
        elif action == "off" and tgt in pending_on:
            pending_on.pop(tgt)
    if exclude_target and exclude_target in pending_on:
        pending_on.pop(exclude_target)
    return pending_on


@dataclass
class DispatchResult:
    """What ClaudeBridge / CopilotBridge.dispatch returns to BridgeService.

    Explicit fields instead of a long tuple so the audit / auto-exit /
    persistence logic in BridgeService.dispatch can read each axis
    unambiguously. is_error is the "did the user see an error response"
    bit — it's True for BOTH transient errors (stay bridged) and
    terminal errors (auto-exit); terminal_reason is set only for the
    latter.
    """

    reply: str
    streamed: bool
    new_external_id: str | None
    terminal_reason: str | None
    is_error: bool


# ── Per-turn context for BridgeTool ──────────────────────────────────────────
#
# BridgeTool is a runtime singleton (registered once at startup), but
# ``BridgeService.toggle`` needs the concrete ``session_id`` / ``channel`` /
# ``channel_id`` of the turn the LLM was processing when it called the tool.
# AgentLoop stashes those on a ContextVar via ``bridge_turn_context``; the
# tool's ``execute`` reads them.
#
# ContextVar is chosen over a setter on the tool instance because tool calls
# in the agent's tool-batch run via ``asyncio.gather`` — a setter would race
# across concurrent invocations, whereas a ContextVar copies per-task and
# isolates the value automatically.


@dataclass
class BridgeTurnContext:
    """Per-turn context injected by AgentLoop for context-aware tools."""

    session_id: str
    channel: ChannelType | str
    channel_id: str
    # Cloud-subsurface marker — "cloud_teams", "cloud_webchat", or "".
    # Forwarded into ``BridgeState.source`` so dispatch can skip streaming
    # chunks on non-streaming surfaces.
    source: str = ""
    # Name of the agent whose LLM turn invoked the bridge tool. Flows
    # through to ``BridgeService.toggle(agent_name=...)`` so the approval
    # card + audit event attribute the toggle to the actual caller
    # (e.g. ``default``, ``explorer``) rather than a hardcoded fallback.
    agent_name: str = "default"


_BRIDGE_TURN_CONTEXT: ContextVar[BridgeTurnContext | None] = ContextVar(
    "workpilot_bridge_turn_context", default=None
)


@contextmanager
def bridge_turn_context(ctx: BridgeTurnContext):
    """Context manager that sets ``_BRIDGE_TURN_CONTEXT`` for the enclosed block.

    AgentLoop wraps each tool invocation with this; ``BridgeTool.execute``
    reads via ``get_bridge_turn_context()``.
    """
    token = _BRIDGE_TURN_CONTEXT.set(ctx)
    try:
        yield ctx
    finally:
        _BRIDGE_TURN_CONTEXT.reset(token)


def get_bridge_turn_context() -> BridgeTurnContext | None:
    """Return the active BridgeTurnContext, or None if called outside a turn."""
    return _BRIDGE_TURN_CONTEXT.get()


@dataclass
class BridgeState:
    """Per-session bridge state. Lives only in BridgeService._registry."""

    target: BridgeTarget
    external_id: str
    channel: ChannelType
    channel_id: str
    # Cloud-subsurface marker — "cloud_teams", "cloud_webchat", "" (any other).
    # Bridges suppress StreamingChunk publishes when source == "cloud_teams"
    # because Teams activities can't render progressive updates; those turns
    # get only the final OutboundMessage. Mirrors the same signal used in
    # workpilot/agent/tools/registry.py:322 to gate tool_progress streaming.
    source: str = ""
    # Live CopilotSession for Copilot target; None for Claude.
    copilot_session: Any | None = None
    # In-flight dispatch task, used by exit_session(cancel_inflight=True).
    current_task: asyncio.Task[Any] | None = None
    toggled_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    # Turns dispatched during this bridge attempt (user+assistant pair = 1 turn).
    # Used for the exit notice and off-marker so counts reflect the current
    # attempt only — not cumulative across all prior attempts in the same file.
    turn_count: int = 0
    # Model override for this bridge attempt — None means "let the external
    # CLI pick its own default" (user's ``~/.claude/settings.json`` for
    # Claude, ``/model`` command config / ``COPILOT_MODEL`` env for Copilot).
    # Non-None values come from the ``/bridge`` slash or ``BridgeTool``
    # caller and win over the target's own user-config default.
    model: str | None = None
    # Actually-running model as observed from the SDK. Populated by the
    # bridge handlers on every assistant turn (Claude: ``AssistantMessage.model``)
    # and on model-change events (Copilot: ``SESSION_START`` /
    # ``SESSION_RESUME`` / ``SESSION_INFO`` / ``SESSION_MODEL_CHANGE`` payloads).
    # Distinct from ``model`` — ``model`` is the pin we pass in; ``active_model``
    # is what the CLI actually resolved it to. The two diverge when ``model``
    # is None (unpinned → active_model reflects the CLI's own default), or
    # transiently right after a switch before the next turn confirms.
    active_model: str | None = None

    @property
    def is_teams(self) -> bool:
        """True when the bound surface cannot render progressive streaming."""
        return self.source == "cloud_teams"


@dataclass
class ToggleResult:
    """Return type for BridgeService.toggle()."""

    ok: bool
    target: BridgeTarget | None
    external_session_id: str | None
    resumed: bool
    message: str


@dataclass
class SwitchModelResult:
    """Return type for BridgeService.switch_model()."""

    ok: bool
    target: BridgeTarget | None
    old_model: str | None
    new_model: str | None
    #: True when the switch required tearing down the external session (and
    #: therefore resetting conversation context). Always ``False`` for the
    #: current Claude + Copilot SDKs — both expose live-switch APIs that
    #: preserve history. Kept as a field so future targets that lack that
    #: capability can signal it without breaking the return shape.
    context_reset: bool
    message: str


class BridgeService:
    """Owns the bridge registry. Dispatches to ClaudeBridge / CopilotBridge."""

    def __init__(
        self,
        *,
        bus: MessageBus,
        sessions: SessionManager,
        bridge_store: BridgeSessionStore,
        audit: AuditLogger,
        approval_manager: ApprovalManager | None = None,
        profile: SecurityProfile = SecurityProfile.STANDARD,
        workspace: Path | str = ".",
        claude_config: ClaudeCodeToolConfig | None = None,
        copilot_config: CopilotToolConfig | None = None,
        github_token: str | None = None,
    ) -> None:
        self._bus = bus
        self._sessions = sessions
        self._bridge_store = bridge_store
        self._audit = audit
        self._approval_manager = approval_manager
        self._profile = profile
        self._workspace = workspace
        self._claude_config = claude_config
        self._copilot_config = copilot_config
        self._github_token = github_token
        # Authoritative registry. Never mutated outside this class.
        # In-memory only — no rehydration across runtime restart. The
        # external agent (Claude Code / Copilot CLI) owns its own session
        # continuity; WorkPilot just tracks live bridges within one runtime.
        self._registry: dict[str, BridgeState] = {}
        # Lazy-loaded ClaudeBridge / CopilotBridge handlers. Imported on demand
        # to keep bridge.py usable without either SDK installed.
        self._claude_bridge: Any | None = None
        self._copilot_bridge: Any | None = None

        # Subscribe to SECURITY_ESTOP events so an estop fired from outside
        # the agent message loop (REST /security/estop, CLI, another client)
        # can cancel in-flight bridge dispatches. The same-session slash-fired
        # /estop still cannot cancel the current bridge dispatch because
        # AgentLoop.start() processes inbound messages serially — the slash
        # can't dequeue until the in-flight dispatch returns. Out-of-band
        # paths go through the event bus directly and DO reach this handler.
        self._bus.events.on(EventType.SECURITY_ESTOP, self._on_estop_event)

    async def _on_estop_event(self, event_type: EventType, payload: dict[str, Any]) -> None:
        reason = str(payload.get("reason") or "Emergency stop")
        await self.exit_all(reason=f"Bridge halted by estop: {reason}")

    # ── State lookup ─────────────────────────────────────────────────────

    async def ensure_state(self, session_id: str, msg: InboundMessage) -> BridgeState | None:
        """Return the active BridgeState for a canonical session, or ``None``.

        In-memory registry lookup only. There is NO disk rehydration — the
        ``ensure_state`` contract changed during the Option-B refactor (see
        design/features/bridge-mode.md §4) and a miss unconditionally
        returns ``None``. On a hit, we refresh ``channel`` / ``channel_id``
        / ``source`` from the current inbound so surface-hopping (same
        canonical sid, new conversation ref under Fluent cloud collapse)
        routes replies to the live channel.

        After a runtime restart the registry is empty, so the user must
        re-type ``/bridge <target>`` to re-enter — the external agent
        (Claude Code / Copilot CLI) owns its own session continuity and
        we never replayed a transcript anyway.
        """
        sid = self._sessions._normalize_id(session_id)
        if sid in self._registry:
            state = self._registry[sid]
            # Refresh surface marker AND channel/channel_id on every hit —
            # ``SessionManager._normalize_id`` collapses legacy cloud session
            # ids to constants (e.g. ``cloud_teams``), so the same canonical
            # sid can correspond to different concrete Teams conversation
            # refs / WebChat channel_ids over time. Without this refresh,
            # replies would be published to a stale channel_id and never
            # reach the current conversation.
            if msg.channel:
                state.channel = ChannelType.of(msg.channel)
            if msg.channel_id:
                state.channel_id = msg.channel_id
            src = (msg.metadata or {}).get("source", "") if msg.metadata else ""
            if src:
                state.source = src
            return state

        # No rehydration from disk — the in-memory registry is the single
        # source of truth for "is this session currently bridged". The
        # external agent (Claude Code / Copilot CLI) manages its own
        # session continuity; WorkPilot only tracks live bridges within
        # one runtime. After restart, user re-types /bridge <target> to
        # enter; explicit ``resume=<id>`` arg attaches to a prior CLI
        # session when needed.
        return None

    # ── Toggle (unified entry for slash + tool) ──────────────────────────

    async def toggle(
        self,
        session_id: str,
        *,
        target: BridgeTarget,
        channel: ChannelType | str,
        channel_id: str,
        fresh: bool = False,
        resume_session_id: str | None = None,
        agent_name: str = "default",
        source: str = "",
        explicit_user_intent: bool = False,
        model: str | None = None,
    ) -> ToggleResult:
        """Unified enter-bridge-mode path.

        ``explicit_user_intent`` distinguishes the entry path:

        * **True** — user typed ``/bridge …`` directly (slash path). Intent
          is unambiguous, no LLM in the loop, so the HUMAN/TIMEOUT_AUTO
          approval prompt is skipped. The profile gate still runs
          (``restricted`` still rejects) and audit events still fire.
        * **False** — ``BridgeTool`` invoked by the LLM (natural-language
          path). The LLM could be tricked or could misread ambiguous input,
          so the full risk gate with approval prompt applies.

        Exit path is ``exit_session`` — this function only enters.
        """
        sid = self._sessions._normalize_id(session_id)
        ch = ChannelType.of(channel)

        # 1) Profile gate — restricted is hard-rejected before scoring,
        #    regardless of who initiated the toggle.
        if self._profile == SecurityProfile.RESTRICTED:
            return ToggleResult(
                ok=False,
                target=None,
                external_session_id=None,
                resumed=False,
                message="Bridge mode is disabled in restricted profile.",
            )

        # 2) Risk gate — only for the tool path. Slash-invoked toggle is
        #    direct user intent and skips HUMAN/TIMEOUT_AUTO prompting
        #    (no LLM in the loop to be confused or injected).
        if not explicit_user_intent:
            gate_ok, gate_message = await self._run_risk_gate(
                sid, target, ch, channel_id, agent_name
            )
            if not gate_ok:
                return ToggleResult(
                    ok=False,
                    target=None,
                    external_session_id=None,
                    resumed=False,
                    message=gate_message,
                )

        # 3) Already bridged? Return idempotent OK.
        if sid in self._registry:
            state = self._registry[sid]
            if state.target == target:
                return ToggleResult(
                    ok=True,
                    target=target,
                    external_session_id=state.external_id,
                    resumed=True,
                    message=f"Already bridged to {target} (external_id={state.external_id}).",
                )
            # Different target — exit current, fall through to enter new.
            await self.exit_session(
                sid,
                reason="Switching bridge target",
                cancel_inflight=False,
                audit_event="bridge_switch",
            )

        # 4) Resolve external session id — precedence:
        #    (a) ``fresh=True`` always wins → empty id, no resume
        #    (b) explicit caller-supplied ``resume_session_id`` → pin it
        #    (c) auto-resume: last ``_external_session_id`` from the
        #        per-target bridge log. Survives WorkPilot's ``/new``
        #        (which clears main-session context only — the external
        #        CLI still has the conversation open, so re-entering
        #        bridge is expected to continue it).
        #    (d) nothing to resume → empty id, fresh external session
        if fresh:
            external_id, resumed = "", False
        elif resume_session_id:
            external_id, resumed = resume_session_id, True
        else:
            auto_id = self._auto_resume_id(sid, target)
            if auto_id:
                external_id, resumed = auto_id, True
            else:
                external_id, resumed = "", False

        # 5) Spawn target bridge (lazy).
        await self._ensure_bridge_handler(target)

        # 6) Build state up-front so the Copilot open_session() can close over
        #    a stable reference for its on_event streaming callback.
        state = BridgeState(
            target=target,
            external_id=external_id,
            channel=ch,
            channel_id=channel_id,
            source=source,
            model=model,
        )

        # 7) For Copilot we need a live CopilotSession object — bridge handler
        #    creates it and attaches an on_event relay keyed on ``state``.
        #    SDK / subprocess / auth failures surface as exceptions here —
        #    don't let them escape the slash handler; return a clean
        #    ToggleResult so the user sees the reason instead of a trace.
        if target == "copilot":
            try:
                copilot_session = await self._copilot_bridge.open_session(  # type: ignore[union-attr]
                    sid, external_id, resume=resumed, state_ref=state, model=model
                )
            except Exception as exc:
                logger.warning("BridgeService.toggle: open_session({}) failed: {}", target, exc)
                return ToggleResult(
                    ok=False,
                    target=None,
                    external_session_id=None,
                    resumed=False,
                    message=f"Bridge setup failed: {type(exc).__name__}: {redact_credentials(str(exc))}",
                )
            state.copilot_session = copilot_session
            # Mirror the SDK-owned id back into external_id for audit.
            sdk_id = getattr(copilot_session, "session_id", None)
            if sdk_id:
                state.external_id = sdk_id
                external_id = sdk_id
        self._registry[sid] = state

        # 8a) Heal orphan ON markers from prior runtimes before writing
        #     the new ON. An orphan is any ``_bridge_toggle on`` in the
        #     main JSONL without a matching off — typically happens when
        #     the process was killed mid-bridge so ``exit_session``
        #     never ran. Close them out opportunistically so the next
        #     read sees a clean ON/OFF segment instead of an
        #     open-ended one.
        self._heal_orphan_ons(sid)

        # 8b) Write an on-marker to the main session JSONL. This is the
        #    only bridge-related entry in the main log at toggle time —
        #    it serves UI timeline rendering and audit traceability.
        #    The actual turn content lives in the per-target bridge log;
        #    the off-marker carries the pointer, the on-marker doesn't
        #    need to (user's entering, no "where's my log" question yet).
        self._sessions.add_message(
            sid,
            {
                "role": "system",
                "content": f"Bridge mode enabled: target={target}",
                "_bridge_toggle": True,
                "_bridge_action": "on",
                "_bridge_target": target,
                "_ts": datetime.now(UTC).isoformat(),
            },
        )

        # 9) Audit.
        self._audit.log_security(
            event="bridge_enter",
            details={
                "target": target,
                "external_session_id": external_id,
                "resumed": resumed,
                "profile": str(self._profile),
            },
            severity="info",
        )

        # Explicit ack — users previously reported "Starting fresh claude
        # session." was ambiguous (looked like just a status line, not a
        # mode change). New format front-loads the state change, the
        # exit instruction, and a safety notice so the toggle is
        # impossible to miss.
        label = target_label(target)
        head = f"▸ Bridge mode ON → **{label}**"
        if resumed:
            head += f" (resumed session `{external_id}`)"
        ack = (
            f"{head}.\n\n"
            f"⚠️ Messages now go directly to {label}. WorkPilot's "
            f"risk scoring, allowlist, and approvals are OFF while bridged — "
            f"the external CLI runs under its own permission model. "
            f"Be deliberate with destructive or sensitive actions.\n\n"
            f"Type `/bridge off` to return to WorkPilot."
        )
        return ToggleResult(
            ok=True,
            target=target,
            external_session_id=external_id,
            resumed=resumed,
            message=ack,
        )

    def _auto_resume_id(self, sid: str, target: BridgeTarget) -> str | None:
        """Return the last ``_external_session_id`` from the per-target
        bridge log, or None if the log is empty / unreadable / has no
        non-empty id.

        Used by ``toggle`` to default ``resume_session_id`` when neither
        ``fresh`` nor an explicit id was supplied. The bridge log is
        not cleared by WorkPilot's ``/new`` — that's by design: ``/new``
        clears WorkPilot's local context, but the external CLI
        (Claude Code / Copilot) still has the session open on its
        side. Re-entering via ``/bridge <target>`` after ``/new`` is
        therefore expected to continue the external conversation.
        Failures are best-effort — any read error returns None and the
        caller falls back to a fresh external session.
        """
        try:
            turns = self._bridge_store.get_turns(sid, target)  # type: ignore[arg-type]
        except Exception as exc:
            logger.debug("_auto_resume_id: get_turns failed ({} / {}): {}", sid, target, exc)
            return None

        last_id: str | None = None
        for t in turns:
            ext_id = t.get("_external_session_id")
            if isinstance(ext_id, str) and ext_id:
                last_id = ext_id
        return last_id

    def _heal_orphan_ons(self, sid: str) -> None:
        """Close orphan ``_bridge_toggle on`` markers by appending synthetic offs.

        Orphan = toggle-on in the main JSONL with no matching toggle-off.
        Accumulates when the process dies mid-bridge (``exit_session``
        never runs; the registry is in-memory so next runtime can't
        close it). Called from ``toggle()`` right before writing the
        new ON, so a fresh bridge never starts on top of a dirty
        orphan. Shape + timestamp match ``build_synthetic_off`` so the
        response-time synthesis in ``handle_session_detail`` produces
        byte-identical markers for read-only consumers.
        """
        try:
            main_msgs = self._sessions.get_messages(sid)
        except Exception as exc:
            logger.debug("_heal_orphan_ons: get_messages failed ({}): {}", sid, exc)
            return

        orphans = detect_orphan_ons(main_msgs)
        if not orphans:
            return

        canonical_sid = self._sessions._normalize_id(sid)
        for tgt, on_ts in orphans.items():
            entry = build_synthetic_off(tgt, on_ts, self._bridge_store, canonical_sid)
            self._sessions.add_message(sid, entry)
            logger.info(
                "Healed orphan bridge ON: sid={}, target={}, turns={}",
                sid,
                tgt,
                entry["_bridge_turns"],
            )

    async def _run_risk_gate(
        self,
        sid: str,
        target: BridgeTarget,
        channel: ChannelType,
        channel_id: str,
        agent_name: str,
    ) -> tuple[bool, str]:
        """Run the §6.1 risk gate: deterministic score 7 → policy action."""
        score = RiskScore(
            score=7,
            reason=(
                f"Bridge mode forwards messages to external {target} CLI; "
                "WorkPilot per-turn risk scoring, allowlist, and tool gating do not apply "
                "(outbound fragments still run through redact_credentials)."
            ),
        )
        action, always_allow_available = lookup_policy(score.score, self._profile)

        # Auto path — no approval needed.
        if action == PolicyAction.AUTO:
            return (True, "auto")

        # Reject path — score 7 is never REJECT in the current policy table, but
        # defend against future changes.
        if action == PolicyAction.REJECT:
            return (False, "Bridge mode rejected by current security profile.")

        # Always-Allow short-circuit — if the user already said "always" for
        # this (session, target), don't re-prompt.
        if self._approval_manager is not None and always_allow_available:
            tool_key = f"_bridge_{target}"
            if self._approval_manager.is_always_allowed(sid, tool_key):
                return (True, "always-allowed")

        # Request approval.
        if self._approval_manager is None:
            # No manager wired — fail closed on non-auto.
            return (False, "Bridge mode requires approval but no ApprovalManager is configured.")

        # Score × profile aware timeouts — same public helper used by the
        # normal ApprovalGate, so bridge approval UX stays consistent with
        # per-tool approvals. The helper normalises SecurityProfile → str.
        from workpilot.security.approval import score_aware_timeout

        auto_timeout: int | None = None
        reject_timeout: int | None = None
        if action == PolicyAction.TIMEOUT_AUTO:
            auto_timeout = score_aware_timeout(
                score.score, is_auto_approve=True, profile=self._profile
            )
        elif action == PolicyAction.HUMAN:
            reject_timeout = score_aware_timeout(
                score.score, is_auto_approve=False, profile=self._profile
            )

        tool_name = f"_bridge_{target}"
        request = await self._approval_manager.request_approval(
            tool_name=tool_name,
            args={"target": target},
            agent_name=agent_name,
            channel=channel,
            channel_id=channel_id,
            score=score.score,
            reason=score.reason,
            always_allow=always_allow_available,
        )

        # Render / broadcast the request the same way ApprovalGate does for
        # per-tool approvals — without this the user sees nothing and the
        # wait hangs until timeout (STANDARD: ~180s → auto-deny).
        await self._render_approval_request(
            request=request,
            score=score,
            channel=channel,
            channel_id=channel_id,
            sid=sid,
            target=target,
            always_allow=always_allow_available,
            auto_timeout=auto_timeout,
            reject_timeout=reject_timeout,
        )

        resolved = await self._approval_manager.wait_for_resolution(
            request.id,
            auto_approve_timeout=auto_timeout,
            reject_timeout=reject_timeout,
        )
        # Gate Always-Allow recording on the same ``always_allow_available``
        # flag used when RENDERING the request. Without this check, a
        # crafted resolver (or a CLI/WS path that passes ``action="always"``
        # unsolicited) could persist Always-Allow even when the policy
        # table said it wasn't offered for this request.
        if resolved.action == "always":
            if always_allow_available:
                self._approval_manager.record_always_allow(sid, tool_name)
            else:
                logger.warning(
                    "Bridge: ignoring resolved action='always' — "
                    "Always-Allow not offered for this request (sid={}, target={})",
                    sid,
                    target,
                )
        if resolved.status == ApprovalStatus.APPROVED:
            return (True, "approved")
        return (False, f"Bridge mode declined: {resolved.action or 'denied'}.")

    async def _render_approval_request(
        self,
        *,
        request: Any,
        score: RiskScore,
        channel: ChannelType,
        channel_id: str,
        sid: str,
        target: BridgeTarget,
        always_allow: bool,
        auto_timeout: int | None,
        reject_timeout: int | None,
    ) -> None:
        """Surface the pending approval to the user's channel.

        Mirrors ``ApprovalGate._route_to_approval`` behaviour (event +
        session-JSONL card + inline CLI prompt) so bridge approvals appear
        in the same places per-tool approvals do. Without this, nothing
        renders the prompt and the wait expires on timeout.
        """
        # 1. APPROVAL_REQUESTED event — web UI toast / channel observers.
        try:
            self._bus.events.emit(
                EventType.APPROVAL_REQUESTED,
                {
                    "request_id": request.id,
                    "tool_name": request.tool_name,
                    "score": score.score,
                    "reason": score.reason,
                    "always_allow": always_allow,
                    "trigger": "",
                },
            )
        except Exception as exc:  # pragma: no cover — defensive
            logger.debug("Bridge: APPROVAL_REQUESTED emit failed: {}", exc)

        # 2. role="approval_request" session JSONL entry — renders the
        #    approval card in the web UI on session load / refresh.
        try:
            import json as _json

            from workpilot.security.approval_format import action_preview, risk_level

            _level, _color, _ = risk_level(score.score)
            self._sessions.add_message(
                sid,
                {
                    "role": "approval_request",
                    "content": _json.dumps(
                        {
                            "request_id": request.id,
                            "tool_name": request.tool_name,
                            "action_preview": action_preview(request.tool_name, {"target": target}),
                            "risk_level": _level,
                            "risk_color": _color,
                            "args": {"target": target},
                            "score": score.score,
                            "reason": score.reason,
                            "agent_name": request.agent_name,
                            "trigger": "",
                            "always_allow": always_allow,
                            "status": "pending",
                        }
                    ),
                },
            )
        except Exception as exc:  # pragma: no cover — defensive
            logger.debug("Bridge: approval_request JSONL write failed: {}", exc)

        # 3. CLI-inline prompt — run the same input()-based dialog that
        #    ApprovalGate uses for per-tool prompts. Fire-and-forget so
        #    this method returns promptly and wait_for_resolution races
        #    against the user's response and the timeout.
        if channel == ChannelType.CLI:
            asyncio.create_task(
                self._cli_prompt(request, score, always_allow, auto_timeout, reject_timeout)
            )

    async def _cli_prompt(
        self,
        request: Any,
        score: RiskScore,
        always_allow: bool,
        auto_timeout: int | None,
        reject_timeout: int | None,
    ) -> None:
        """Inline CLI approval — prompts via stdin, resolves the request.

        Fire-and-forget from ``_render_approval_request``. wait_for_resolution
        in the caller races against the user's stdin answer and the policy
        timeout (whichever fires first wins).
        """
        if self._approval_manager is None:
            return
        from workpilot.security.approval_format import CLIApprovalFormatter

        formatter = CLIApprovalFormatter()
        banner = formatter.format_request(
            request, score, auto_timeout, reject_timeout=reject_timeout
        )

        def _read() -> str:
            try:
                return input(banner).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "n"

        loop = asyncio.get_running_loop()
        try:
            answer = await loop.run_in_executor(None, _read)
        except Exception as exc:
            logger.warning("Bridge CLI prompt failed: {}", exc)
            return

        approved = answer in ("y", "yes", "always", "a")
        action = "always" if answer in ("always", "a") else ("approve" if approved else "deny")
        try:
            self._approval_manager.resolve(
                request.id, approved=approved, resolver="cli-user", action=action
            )
        except (KeyError, ValueError):
            # Already resolved (timeout / out-of-band) — nothing to do.
            pass

    async def _ensure_bridge_handler(self, target: BridgeTarget) -> None:
        """Lazy-import Claude / Copilot bridge handlers on first use.

        Keeps bridge.py usable without either SDK installed — imports happen
        only when the user actually toggles a target on. Handler options come
        straight from the corresponding delegate-tool config block so there
        is one source of truth for cli_path / model / timeouts.
        """
        if target == "claude" and self._claude_bridge is None:
            from workpilot.agent.bridge_claude import ClaudeBridge

            ccfg = self._claude_config
            # Bridge mode auto-bypasses Claude's per-tool permission prompts —
            # symmetric with ``CopilotBridge`` (hardcoded
            # ``PermissionHandler.approve_all``). Rationale: bridge is a
            # direct user↔CLI pass-through, WorkPilot's profile gate already
            # fired at ``/bridge`` toggle time, and adding a second approval
            # layer inside the external CLI turns every message into a
            # click-through. The delegate tool
            # (``tools.claude_code.dangerously_skip_permissions``) keeps its
            # conservative opt-in default — only bridge overrides.
            self._claude_bridge = ClaudeBridge(
                bus=self._bus,
                sessions=self._sessions,
                workspace=self._workspace,
                cli_path=ccfg.cli_path if ccfg else None,
                dangerously_skip_permissions=True,
                setting_sources=list(ccfg.setting_sources) if ccfg else None,
            )
        elif target == "copilot" and self._copilot_bridge is None:
            from workpilot.agent.bridge_copilot import CopilotBridge

            pcfg = self._copilot_config
            # No handler-level model. ``toggle(..., model=…)`` from the
            # slash / ``BridgeTool`` pins per-attempt; without an override
            # the SDK receives ``model=None`` → omits the key → Copilot
            # CLI uses the user's own ``/model`` / ``COPILOT_MODEL``
            # config. (Previously this read ``pcfg.default_model``, which
            # silently overrode user config — that field has been
            # removed from ``CopilotToolConfig``.)
            self._copilot_bridge = CopilotBridge(
                bus=self._bus,
                sessions=self._sessions,
                workspace=self._workspace,
                cli_path=pcfg.cli_path if pcfg else None,
                github_token=self._github_token,
                task_timeout=(pcfg.task_timeout if pcfg and pcfg.task_timeout > 0 else 3600),
            )

    # ── Target availability ──────────────────────────────────────────────

    def available_targets(self) -> list[BridgeTarget]:
        """Which bridge targets are ready to use on this runtime.

        Both ``claude-agent-sdk`` and ``github-copilot-sdk`` are core
        dependencies in ``pyproject.toml`` (not optional extras), so every
        installed WorkPilot runtime has both. A broken install with one
        missing is treated like any other broken dependency — the import
        inside ``_ensure_bridge_handler`` raises and the user gets a
        standard ImportError, rather than bridge inventing a friendlier
        message for a case that shouldn't happen.
        """
        return list(BRIDGE_TARGETS)  # type: ignore[arg-type]

    async def list_supported_models(
        self, target: BridgeTarget, *, timeout: float = 5.0
    ) -> list[str]:
        """Return model IDs the target CLI currently advertises for this
        runtime's auth. Copilot supports this via the SDK's
        ``list_models()``; Claude's Python SDK has no equivalent API, so
        Claude returns ``[]`` and the caller falls back to
        ``suggested_models()`` for a static hint list.

        Best-effort — any error (CLI missing, auth failure, timeout,
        subprocess startup failure) returns ``[]`` so the caller can
        show its hardcoded fallback instead of failing the surrounding
        operation. ``timeout`` guards the first call of each process,
        which has to spawn the CLI subprocess and hit the network.
        """
        if target == "copilot":
            await self._ensure_bridge_handler("copilot")
            if self._copilot_bridge is None:
                return []
            # ``self._copilot_bridge`` is typed as ``Any | None`` (lazy
            # import), so mypy can't see the method's return type — cast
            # once we know the value is a ``list[str]`` of model ids.
            result: list[str] = await self._copilot_bridge.list_supported_models(timeout=timeout)
            return result
        return []

    async def switch_model(self, session_id: str, model: str | None) -> SwitchModelResult:
        """Switch the model on the active bridge for this session.

        ``model=None`` clears the pin → next Copilot session create / Claude
        dispatch uses the external CLI's own default (``~/.claude/settings.json``
        for Claude; ``/model`` config / ``COPILOT_MODEL`` env for Copilot).

        Both targets support live switching with conversation history preserved:

        * **Claude** — each ``dispatch()`` rebuilds ``ClaudeAgentOptions`` with
          the current ``state.model``. Updating the field is enough; next
          assistant turn uses the new model.
        * **Copilot** — call ``CopilotSession.set_model(model)`` on the live
          session. The SDK switches the running session's model and preserves
          history; no teardown, no context reset.

        Returns ``SwitchModelResult(ok=False, ...)`` when the session isn't
        bridged, when pre-validation against the live model list rejects
        the id (Copilot only — Claude has no list API, so invalid slugs
        pass this gate and fail later at dispatch), or when the SDK itself
        refuses the switch.
        """
        sid = self._sessions._normalize_id(session_id)
        state = self._registry.get(sid)
        if state is None:
            return SwitchModelResult(
                ok=False,
                target=None,
                old_model=None,
                new_model=None,
                context_reset=False,
                message="Not in bridge mode — `/model` manages the bridge target's model.",
            )

        old_model = state.model
        # No-op short-circuit — same model on both sides means nothing to
        # change.
        if old_model == model:
            current_label = f"`{model}`" if model else "_(external CLI default)_"
            return SwitchModelResult(
                ok=True,
                target=state.target,
                old_model=old_model,
                new_model=model,
                context_reset=False,
                message=f"Already on {current_label}.",
            )

        # Soft pre-validation against the authoritative model list. We only
        # gate when ``list_supported_models`` returns a non-empty live list —
        # that's Copilot today (the SDK's ``list_models()`` reflects the
        # user's actual auth scope). For Claude the SDK has no list API so
        # the call returns ``[]``; we fall through and let the CLI validate
        # at next dispatch. This keeps users free to use newer Claude
        # slugs we haven't heard of, but catches Copilot typos before a
        # wasted SDK round-trip AND produces a nicer error than the SDK's
        # raw RPC message.
        if model is not None:
            try:
                live_models = await self.list_supported_models(state.target)
            except Exception:
                live_models = []
            if live_models and model not in live_models:
                return SwitchModelResult(
                    ok=False,
                    target=state.target,
                    old_model=old_model,
                    new_model=model,
                    context_reset=False,
                    message=(
                        f"Unknown model `{model}` for {target_label(state.target)}. "
                        "Run `/model` to see the list of models available on your current auth."
                    ),
                )

        # Copilot: call ``CopilotSession.set_model(model)`` — the SDK switches
        # the running session's model with conversation history preserved (no
        # teardown). Claude applies the change transparently at next dispatch
        # because each ``dispatch()`` rebuilds ``ClaudeAgentOptions(model=…)``
        # from ``state.model`` — nothing to do here.
        if state.target == "copilot" and state.copilot_session is not None:
            # ``set_model`` requires a string; ``None`` (pass-through) isn't
            # directly supported by the SDK, so only call the live SDK when
            # the user explicitly named a model. For ``None`` we just update
            # the pin — the next Copilot re-create (e.g. after a restart /
            # resume flow) will use the CLI default.
            if model is not None:
                try:
                    await state.copilot_session.set_model(model)
                except Exception as exc:
                    logger.warning("CopilotSession.set_model({}) failed: {}", model, exc)
                    return SwitchModelResult(
                        ok=False,
                        target=state.target,
                        old_model=old_model,
                        new_model=model,
                        context_reset=False,
                        message=(
                            f"Could not switch Copilot to `{model}`: {redact_credentials(str(exc))}"
                        ),
                    )

        state.model = model
        # Optimistically mirror into active_model — for Copilot the SDK will
        # emit SESSION_MODEL_CHANGE shortly anyway; for Claude the next
        # AssistantMessage.model will confirm. Updating now means a /model
        # or /bridge status issued *before* the next turn still shows the
        # new value instead of the stale previous one.
        if model is not None:
            state.active_model = model

        old_label = f"`{old_model}`" if old_model else "_(external CLI default)_"
        new_label = f"`{model}`" if model else "_(external CLI default)_"
        message = f"Bridge model switched: {old_label} → {new_label}"

        self._audit.log_security(
            event="bridge_model_switch",
            details={
                "session_id": sid,
                "target": state.target,
                "old_model": old_model,
                "new_model": model,
            },
            severity="info",
        )

        return SwitchModelResult(
            ok=True,
            target=state.target,
            old_model=old_model,
            new_model=model,
            context_reset=False,
            message=message,
        )

    async def render_status_message(self, session_id: str) -> str:
        """Human-readable bridge status for this session.

        Single source of truth for what both ``/bridge`` (slash command)
        and ``BridgeTool`` (no-target LLM invocation) return, so the two
        surfaces stay byte-identical. The reply is markdown — bullet lists
        are rendered as copyable inline code by every channel the runtime
        supports (Fluent web, CLI markdown mode, Teams).

        Two states:
          * bridged → "talking to <target>" summary with session + model
          * unbridged → per-target section with the full, copyable model
            list, closing tip. (SDKs are core deps so there is no
            "neither SDK installed" state to handle.)
        """
        state = self.get_state(session_id)
        if state is not None:
            return (
                f"## Bridge mode active — {target_label(state.target)}\n"
                "\n"
                f"- **Session:** `{state.external_id or '(fresh)'}`\n"
                f"- **Model:** {format_bridge_model_line(state)}\n"
                "\n"
                "**Commands while bridged**\n"
                "- `/model` — list available models · `/model <name>` — switch\n"
                "- `/bridge off` — return to WorkPilot"
            )

        available = self.available_targets()

        async def _models_for(t: BridgeTarget) -> list[str]:
            """Full, non-truncated model list for this target. Live SDK
            list first; fall back to the static ``suggested_models``
            constant on empty / error (keeps the hint usable offline or
            before Copilot auth is set up)."""
            try:
                live = await self.list_supported_models(t)
            except Exception:
                live = []
            return live if live else list(suggested_models(t))

        async def _section_for(t: BridgeTarget) -> str:
            label = target_label(t)
            # Fetch models and the recent-sessions block in parallel —
            # both are independent I/O. For Copilot, models() warms the
            # client so the subsequent sessions() call reuses it; for
            # Claude the two hit disk in different paths. Overlapping
            # keeps the status render fast on the cold path.
            ids, last = await asyncio.gather(
                _models_for(t),
                format_recent_sessions_block(self, t, self._workspace),
            )
            # H2 heading gives each target real visual hierarchy — markdown
            # renderers across channels (Fluent web, CLI markdown mode,
            # Teams) give it more weight than bold paragraph text.
            parts = [f"## {label} — enter with `/bridge {t}`"]
            if ids:
                rendered = format_model_list(ids)
                # Inline rendering fits on the same line; grouped rendering
                # already has its own leading newline via the first bullet.
                if "\n" in rendered:
                    parts.append(f"**Models:**\n{rendered}")
                else:
                    parts.append(f"**Models:** {rendered}")
            if last:
                parts.append(last)
            # Blank-line separators between label blocks inside a target —
            # keeps the render airy, matches the markdown convention of
            # "list blocks separated by blank line".
            return "\n\n".join(parts)

        sections = await asyncio.gather(*(_section_for(t) for t in available))

        return (
            "**Bridge mode** hands your conversation directly to an external "
            "CLI — every message flows through verbatim, nothing from WorkPilot "
            "in the middle.\n\n" + "\n\n".join(sections) + "\n\n---\n\n"
            "**Tips** — pin a model at entry with `/bridge <target> model=<name>` · "
            "switch while bridged with `/model <name>` · exit with `/bridge off`"
        )

    # ── Dispatch ─────────────────────────────────────────────────────────

    async def dispatch(
        self, msg: InboundMessage, session_id: str, state: BridgeState
    ) -> tuple[str, bool]:
        """Forward the user prompt to the external CLI and return (reply, streamed).

        Persists the user prompt and final reply to the per-target
        bridge log via ``BridgeSessionStore.append_turn`` — NOT the
        main session JSONL. The main session only receives
        ``_bridge_toggle`` markers from ``toggle`` / ``exit_session``
        (context isolation; see design/features/bridge-mode.md §4).
        Emits one ``_bridge_{target}`` audit event per turn and
        auto-exits bridge when the handler reports a terminal signal
        (§5.3 terminal-signal detection).
        """
        sid = self._sessions._normalize_id(session_id)
        await self._ensure_bridge_handler(state.target)

        # Attachments are forwarded to the external CLI BY PATH (spec §9
        # decision 1, v2). Both handlers read the file off disk:
        #   - ClaudeBridge inlines the path into the prompt; the Claude
        #     Code CLI auto-renders image MIME types as multimodal
        #     content and reads text/code via its Read tool. ``add_dirs``
        #     authorises the attachments folder so no permission prompt.
        #   - CopilotBridge converts each ref to a ``FileAttachment``
        #     TypedDict and passes it through ``send_and_wait``'s
        #     ``attachments=`` param. ``PermissionHandler.approve_all``
        #     on session open already suppresses any CLI-side prompts.
        # Refs whose on-disk file is missing are dropped at filter time
        # below; we don't fail the whole turn because one ref vanished.
        forward_attachments: list[dict[str, Any]] | None = None
        dropped_count = 0
        if msg.attachments:
            from pathlib import Path as _FsPath

            forward_attachments = []
            for att in msg.attachments:
                path_str = str(att.get("path") or "").strip()
                if path_str and _FsPath(path_str).exists():
                    forward_attachments.append(att)
                else:
                    dropped_count += 1
            if not forward_attachments:
                forward_attachments = None
            if dropped_count > 0:
                logger.warning(
                    "BridgeService.dispatch: {} attachment(s) dropped (path missing on disk)",
                    dropped_count,
                )

        # Write the user prompt to the bridge-specific log, NOT the main
        # session. Bridge turns stay isolated so the normal agent's LLM
        # context doesn't mistake Claude / Copilot traffic for its own
        # conversation. Per-(sid, target) file layout:
        # ~/.workpilot/sessions/bridge/<sid>.<target>.jsonl
        user_entry: dict[str, Any] = {
            "role": "user",
            "content": msg.content,
            "_ts": datetime.now(UTC).isoformat(),
            "_external_session_id": state.external_id,
        }
        if forward_attachments:
            # Persist only the fields the UI renders — sha256 is the
            # content-addressed key for AttachmentImage, the rest is
            # metadata for chip/label display. Refresh → server splices
            # bridge turns into the session detail → chat shows the
            # same attachment chips as the live echo did.
            user_entry["_attachments"] = [
                {
                    k: a[k]
                    for k in ("sha256", "content_type", "size", "name", "kind")
                    if k in a and a[k] is not None
                }
                for a in forward_attachments
            ]
        self._bridge_store.append_turn(sid, state.target, user_entry)

        handler = self._claude_bridge if state.target == "claude" else self._copilot_bridge

        # Run the handler in a child task so exit_session(cancel_inflight=True)
        # cancels ONLY the bridge dispatch — not the AgentLoop's main task.
        # Dispatch runs inline inside AgentLoop.start()'s sequential inbound
        # loop, so asyncio.current_task() here would return the agent-loop
        # task itself; cancelling that would stop message processing for
        # every session in the runtime.
        t_start = time.monotonic()
        dispatch_task = asyncio.create_task(
            handler.dispatch(  # type: ignore[union-attr]
                prompt=msg.content,
                state=state,
                session_id=sid,
                attachments=forward_attachments,
            )
        )
        state.current_task = dispatch_task
        try:
            result: DispatchResult = await dispatch_task
        except asyncio.CancelledError:
            # If OUR task was also cancelled (e.g. runtime shutdown), propagate.
            # Otherwise the cancel was targeted at the subtask only — swallow,
            # return a synthetic marker, and let the agent loop keep running.
            outer = asyncio.current_task()
            if outer is not None and outer.cancelling() > 0:
                raise
            # The subtask may have emitted partial streaming chunks before
            # the cancel fired. Close the stream on non-Teams surfaces so
            # CLI / WS clients don't stay stuck in "streaming" state.
            cancel_reply = "Bridge turn cancelled."
            if not state.is_teams:
                from workpilot.bus.events import StreamingChunk

                await self._bus.dispatch_outbound(
                    StreamingChunk(
                        channel=state.channel,
                        channel_id=state.channel_id,
                        content="",
                        done=True,
                    )
                )
            # ALWAYS publish the final OutboundMessage on cancel. The
            # response queue (``/api/chat`` submit_and_wait, SSE, WS) is
            # non-streaming and requires a terminating message — without
            # this, the user's HTTP/WS request hangs until timeout. On
            # streaming surfaces the publish is also the authoritative
            # record for persistence. Marking ``streamed=True`` tells
            # AgentLoop to skip its own final publish_outbound so we
            # don't double-send.
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=state.channel,
                    channel_id=state.channel_id,
                    content=cancel_reply,
                    metadata={
                        "source": "bridge",
                        "_origin": bridge_origin(state.target),
                        "_synthetic": "bridge_cancelled",
                    },
                )
            )
            result = DispatchResult(
                reply=cancel_reply,
                streamed=True,
                new_external_id=None,
                terminal_reason=None,
                is_error=False,
            )
        finally:
            state.current_task = None

        reply = result.reply
        streamed = result.streamed
        new_external_id = result.new_external_id
        terminal_reason = result.terminal_reason
        is_error = result.is_error

        # Update external_id if the handler advanced it (Claude yields a new
        # session_id on each ResultMessage).
        if new_external_id and new_external_id != state.external_id:
            state.external_id = new_external_id

        # Persist the bridge reply to the bridge-specific log. The main
        # session log gets only the _bridge_toggle on/off markers (written
        # by toggle() and exit_session()) — those are enough for UI
        # timeline rendering and audit traceability.
        self._bridge_store.append_turn(
            sid,
            state.target,
            {
                "role": "assistant",
                "content": reply,
                "_ts": datetime.now(UTC).isoformat(),
                "_external_session_id": state.external_id,
            },
        )
        state.turn_count += 1

        # Per-turn audit event — hashed prompt + UTF-8 byte counts + duration.
        # Prompt body is not stored; users may paste secrets into the bridged
        # CLI's auth flow. Byte counts use utf-8 encoding so non-ASCII text
        # (Chinese, emoji, etc.) is reported accurately — len(str) alone
        # would under-count.
        prompt_encoded = msg.content.encode("utf-8")
        prompt_sha = hashlib.sha256(prompt_encoded).hexdigest()[:16]
        self._audit.log_tool(
            tool=f"_bridge_{state.target}",
            actor="user",
            args={
                "prompt_sha": prompt_sha,
                "prompt_bytes": len(prompt_encoded),
                "result_bytes": len(reply.encode("utf-8")),
                "external_session_id": state.external_id,
            },
            result="",  # Body not captured — prompts / replies may contain secrets.
            # is_error covers BOTH terminal and transient errors — a user who
            # saw an error response should see is_error=True in audit even
            # if the bridge stayed up. terminal_reason only drives auto-exit.
            is_error=is_error or terminal_reason is not None,
            session_id=sid,
            duration_ms=(time.monotonic() - t_start) * 1000,
        )

        # Terminal-signal auto-exit (§5.3). Persist the reply first so the
        # user can see partial output, then tear down; the exit_session
        # helper will publish the exit notice on its own.
        if terminal_reason is not None:
            await self.exit_session(
                sid,
                reason=f"Bridge ended: {terminal_reason}",
                cancel_inflight=False,
                audit_event="bridge_auto_exit",
            )

        return (reply, streamed)

    # ── Exit ─────────────────────────────────────────────────────────────

    async def exit_session(
        self,
        session_id: str,
        *,
        reason: str,
        cancel_inflight: bool,
        audit_event: str,
        suppress_channel_notice: bool = False,
    ) -> str | None:
        """Unified exit path. Four triggers (user slash, exit alias, /estop,
        terminal signal from external CLI) all funnel through here.

        Returns the formatted exit summary (so slash handlers can surface
        the same text through their own ack path) or ``None`` when there
        was no active bridge to exit.
        """
        sid = self._sessions._normalize_id(session_id)
        state = self._registry.get(sid)
        if state is None:
            return None

        if cancel_inflight and state.current_task is not None:
            state.current_task.cancel()
            try:
                await asyncio.wait_for(state.current_task, timeout=2.0)
            except (asyncio.CancelledError, TimeoutError, Exception):
                # Task torn down; continue cleanup regardless.
                pass

        # Close target-specific resources before popping state — disconnect()
        # is the current Copilot SDK API (destroy() is deprecated).
        if state.target == "copilot" and state.copilot_session is not None:
            try:
                await state.copilot_session.disconnect()
            except Exception as exc:  # pragma: no cover — best-effort teardown
                logger.warning("CopilotSession.disconnect() failed during exit: {}", exc)
        # Claude: SDK async iterator was cancelled above. Subprocess owned by
        # SDK transport, tears down on CancelledError in runner.

        self._registry.pop(sid, None)

        # Redact before any persistence / audit / channel publish. Reason may
        # carry CLI-sourced text (auto-exit carries the terminal error string
        # from the external CLI, which could echo pasted auth tokens).
        safe_reason = redact_credentials(reason)

        # Per-attempt turn count (from state, not disk) so the exit notice
        # reflects this bridge session only — not cumulative across any
        # prior bridge attempts whose turns are also in the same file.
        turn_count = state.turn_count
        bridge_log_path = self._bridge_store.path_for(sid, state.target)

        # Write an _bridge_toggle off marker to the main session — purely
        # for UI timeline rendering and audit traceability. Includes the
        # pointer to the bridge log so later session-replay has the link.
        self._sessions.add_message(
            sid,
            {
                "role": "system",
                "content": f"Bridge mode ended: {safe_reason}",
                "_bridge_toggle": True,
                "_bridge_action": "off",
                "_bridge_target": state.target,
                "_bridge_log": str(bridge_log_path),
                "_bridge_turns": turn_count,
                "_ts": datetime.now(UTC).isoformat(),
            },
        )

        # Compose the user-facing summary once and use it for both the
        # channel publish AND the slash-path return value — single
        # formatting source means the two paths can't drift.
        summary = self._format_exit_summary(safe_reason, state.target, turn_count, bridge_log_path)

        # Publish a visible exit notice on the channel, unless the caller
        # (e.g. the /bridge off slash handler) will return the summary
        # through the normal slash-reply path — avoids double-posting.
        if not suppress_channel_notice:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=state.channel,
                    channel_id=state.channel_id,
                    content=summary,
                    metadata={
                        "source": "bridge",
                        "_synthetic": "bridge_ended",
                        "_bridge_log": str(bridge_log_path),
                        "_bridge_turns": turn_count,
                    },
                )
            )

        self._audit.log_security(
            event=audit_event,
            details={
                "target": state.target,
                "reason": safe_reason,
                "external_session_id": state.external_id,
                "bridge_log": str(bridge_log_path),
                "turns": turn_count,
            },
            severity="info",
        )
        return summary

    @staticmethod
    def _format_exit_summary(reason: str, target: BridgeTarget, turn_count: int, path: Path) -> str:
        """Compose the user-facing exit notice.

        Mirrors the enter-ack format (``▸`` marker, bold target, clear
        state-change statement) so the pair reads as a coherent
        enter/exit transcript. Includes the bridge log path so the user
        can retrieve the saved transcript — the web UI wraps it as a
        clickable link, the CLI prints it as text.
        """
        label = target_label(target)
        head = f"▸ Bridge mode OFF ← **{label}** ({reason})."
        tail = "You're back with WorkPilot — your next message goes to the agent."
        if turn_count == 0:
            return f"{head}\n\n{tail}"
        turns_word = "turn" if turn_count == 1 else "turns"
        return f"{head}\n\n{turn_count} {turns_word} with {label} saved to `{path}`. {tail}"

    async def exit_all(self, reason: str, audit_event: str = "bridge_estop") -> None:
        """Exit every bridged session. Used by global /estop."""
        session_ids = list(self._registry.keys())
        for sid in session_ids:
            await self.exit_session(
                sid,
                reason=reason,
                cancel_inflight=True,
                audit_event=audit_event,
            )

    # ── Introspection ────────────────────────────────────────────────────

    def is_bridged(self, session_id: str) -> bool:
        sid = self._sessions._normalize_id(session_id)
        return sid in self._registry

    def get_state(self, session_id: str) -> BridgeState | None:
        sid = self._sessions._normalize_id(session_id)
        return self._registry.get(sid)

    def active_sessions(self) -> list[str]:
        return list(self._registry.keys())
