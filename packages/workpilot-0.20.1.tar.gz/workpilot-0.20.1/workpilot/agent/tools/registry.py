"""
Tool registry — central registry for tool discovery and execution.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool
from workpilot.bus.events import StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import ChannelType
from workpilot.security.audit import AuditLogger
from workpilot.security.leak import redact_credentials
from workpilot.utils.helpers import ellipsize

_ERROR_HINT = "\n\n[Analyze the error above and try a different approach.]"

# Reserved kwargs the registry injects into a tool's args dict at execution
# time so tools can read runtime provenance (channel routing, audit identity,
# spawn-source metadata) without mutable state. They are NOT part of any tool's
# declared JSON schema — built-in tools read them with ``kwargs.get(...)`` and
# never echo them back. Adapters that forward arguments to an external system
# (e.g. ``MCPToolAdapter`` → MCP server's ``inputSchema`` validator) MUST strip
# these before forwarding, otherwise the remote validator rejects the call
# with errors like ``Unknown argument: '_channel'``.
RESERVED_RUNTIME_KWARGS: tuple[str, ...] = (
    "_channel",
    "_channel_id",
    "_thread_id",
    "_session_id",
    "_sender_id",
    "_metadata",
)

# Per-value cap for tool_start args + tool_end result on the cloud_webchat
# wire. Web frontend renders the args dict with `JSON.stringify(args, null, 2)`
# (ToolCallTimeline.tsx) so per-value truncation preserves the object shape;
# values longer than the cap are replaced with `prefix…`. The full payload is
# retained for CLI / local channels. Truncation goes through `ellipsize` —
# guarantees `len(result) <= cap` (suffix included).
_CLOUD_WEB_META_CHAR_CAP: int = 128
# Total budget for tool_start args values on the cloud_teams wire.
# The streaming dispatcher renders args inline (`🔧 read_file(auth.py) ⏳`)
# and only has ~900 bytes total for the informative body, so the cumulative
# value-string length across all args is bounded. Each value gets an equal
# share (``cap // N``) so a single long arg can't crowd out subsequent args:
# 1 arg → up to 64 chars; 2 args → 32 each; 3 args → 21 each; etc.
_CLOUD_TEAMS_ARG_TOTAL_CHAR_CAP: int = 64
# Cap for tool_end result on the cloud_teams wire. The dispatcher renders the
# result inline as `🔧 tool(arg) ✓ 234ms → result_summary` so this needs to be
# small enough to fit alongside the trail in the 900-byte body cap.
_CLOUD_TEAMS_RESULT_CHAR_CAP: int = 32


def _truncate_args_for_cloud_teams(args: dict[str, Any]) -> dict[str, Any]:
    """Pack arg values into the cloud_teams wire's
    ``_CLOUD_TEAMS_ARG_TOTAL_CHAR_CAP`` (64 chars total) using an equal-
    share-with-redistribution scheme over the first four args:

    * The first 4 args ("primary slots") share the full 64-char budget
      equally. Each arg's share is computed as ``remaining // slots_left``
      where ``slots_left`` decreases by 1 each iteration. Short earlier
      values automatically donate their leftover to later primary slots —
      e.g. for 4 args with values [5 chars, 5 chars, 60 chars, 60 chars],
      the split is 5+5+27+27 = 64 (full budget used, not 16+16+16+16=64
      with the long values needlessly clipped to 16).
    * For tools with > 4 args, args 5+ only get ``remaining`` chars — if
      the first 4 took the full 64, trailing args are dropped; if there's
      slack, trailing args use what's left.

    This keeps the implementation simple (single loop), the budget fully
    utilised when value lengths are uneven, and a long single-arg tool can
    use up to 64 chars while a 4-arg tool gets at least 16 per value. The
    Gateway's ``SummarizeArgs`` then comma-joins values (no trailing
    space) and re-clips to 40 chars for the inline `🔧 tool(v1,v2) ⏳`
    display.

    ``redact_credentials`` runs **before** ellipsizing each value: secret
    patterns whose detector requires the full token length (e.g. fixed-length
    GitHub PATs / API keys) would otherwise slip past the outer
    ``redact_credentials`` call when the value is already clipped.
    Redacting first then clipping the redacted form keeps the masked prefix
    safe regardless of detector length sensitivity.
    """
    if not args:
        return {}
    out: dict[str, Any] = {}
    remaining = _CLOUD_TEAMS_ARG_TOTAL_CHAR_CAP
    items = list(args.items())
    primary_slots = min(len(items), 4)
    for i, (k, v) in enumerate(items):
        if i < primary_slots:
            slots_left = primary_slots - i
            share = remaining // slots_left
        else:
            # Past the first 4: only get whatever's left of the budget.
            share = remaining
        if share <= 0:
            continue  # budget exhausted — drop trailing args
        s = redact_credentials(v if isinstance(v, str) else str(v))
        clipped = ellipsize(s, share)
        if not clipped:
            continue  # empty value after redaction — drop key
        out[k] = clipped
        remaining -= len(clipped)
    return out


def _truncate_args_for_cloud_web(args: dict[str, Any]) -> dict[str, Any]:
    """Per-value truncation of tool_start args. String values are clipped to
    ``_CLOUD_WEB_META_CHAR_CAP`` characters; non-string values are JSON-encoded
    then clipped (the Web UI is happy with either shape — its parser tolerates
    raw strings inside the args dict). Same redact-then-clip ordering as the
    cloud_teams variant — see its docstring for why."""
    import json as _json

    out: dict[str, Any] = {}
    for k, v in args.items():
        if isinstance(v, str):
            out[k] = ellipsize(redact_credentials(v), _CLOUD_WEB_META_CHAR_CAP)
        else:
            try:
                s = _json.dumps(v, ensure_ascii=False, default=str)
            except Exception:
                s = str(v)
            out[k] = ellipsize(redact_credentials(s), _CLOUD_WEB_META_CHAR_CAP)
    return out


PROTECTED_TOOLS = frozenset(
    {
        "tools",  # meta-tool: controls tool discovery/activation
        "spawn",  # creates sub-agents with scoped permissions
        "cron",  # schedules future agent/tool execution
        "notify",  # sends messages to user channels
        "config_workpilot",  # modifies runtime configuration
    }
)


class ToolRegistry:
    """Central tool registry with execution tracking and audit logging.

    Supports progressive loading: core-tier tools are always in the function
    calling schema; standard-tier tools must be activated via ``tools``
    before they appear in schemas.
    """

    def __init__(self, audit: AuditLogger | None = None) -> None:
        self._tools: dict[str, Tool] = {}
        self._audit = audit or AuditLogger()
        self._active: set[str] = set()  # names of tools in the function calling schema
        self._disabled: set[str] = set()  # explicitly disabled — won't auto-activate
        self._mcp_manager: Any = None  # set via set_mcp_manager()
        self._standard_summary_cache: str | None = None  # cached for prompt stability
        self._output_config: Any = None  # ToolOutputConfig, set via set_output_config()

    @property
    def output_config(self) -> Any:
        """Global tool output truncation config."""
        if self._output_config is not None:
            return self._output_config
        from workpilot.config.schema import ToolOutputConfig

        return ToolOutputConfig()

    def set_output_config(self, config: Any) -> None:
        """Set the global tool output truncation config."""
        self._output_config = config

    def register(self, tool: Tool) -> None:
        if tool.name in PROTECTED_TOOLS and tool.name in self._tools:
            raise ValueError(f"Cannot override protected built-in tool '{tool.name}'")
        self._tools[tool.name] = tool
        # Core-tier auto-activates; standard and MCP start inactive
        if tool.metadata.tier == "core":
            self._active.add(tool.name)
        # Invalidate cached summary when a non-MCP standard tool is added
        if tool.metadata.tier == "standard" and tool.metadata.category != "mcp":
            self._standard_summary_cache = None
        logger.debug(f"Tool registered: {tool.name} (tier={tool.metadata.tier})")

    def unregister(self, name: str) -> None:
        self._tools.pop(name, None)

    def unregister_prefix(self, prefix: str) -> list[str]:
        """Remove all tools whose names start with *prefix*. Returns removed names."""
        to_remove = [name for name in self._tools if name.startswith(prefix)]
        for name in to_remove:
            del self._tools[name]
            self._active.discard(name)
            self._disabled.discard(name)
        if to_remove:
            logger.debug(f"Unregistered {len(to_remove)} tools with prefix '{prefix}'")
        return to_remove

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    _TIER_ORDER = {"core": 0, "standard": 1, "hidden": 2}
    _CATEGORY_ORDER = {"builtin": 0, "custom": 1, "mcp": 2}

    def list_tools(self) -> list[Tool]:
        """Return all registered tools in insertion order (no sorting).

        For sorted display output, use ``list_tools_sorted()`` instead.
        """
        return list(self._tools.values())

    def list_tools_sorted(self) -> list[Tool]:
        """Return all registered tools sorted for display.

        Sort order: tier (core → standard → hidden), then category
        (builtin → custom → mcp), then name (case-insensitive).
        Use this for user/LLM-facing output. For internal iteration prefer ``list_tools()``.
        """
        return sorted(
            self._tools.values(),
            key=lambda t: (
                self._TIER_ORDER.get(t.metadata.tier, 9),
                self._CATEGORY_ORDER.get(t.metadata.category, 8),
                t.name.casefold(),
            ),
        )

    def get_schemas(
        self, names: list[str] | None = None, *, exclude: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """Get OpenAI-format tool schemas for active tools only.

        Progressive loading: only core-tier and explicitly activated tools
        are included. Standard-tier tools must be activated via ``tools``.

        Args:
            names: Optional allowlist of tool names to include (after activation).
            exclude: Denylist — remove these tools from the result.
        """
        tools: list[Tool] = [t for t in self._tools.values() if t.name in self._active]
        if names:
            name_set = set(names)
            tools = [t for t in tools if t.name in name_set]
        if exclude:
            exclude_set = set(exclude)
            tools = [t for t in tools if t.name not in exclude_set]
        return [t.to_openai_schema() for t in tools]

    # ── Progressive loading ────────────────────────────────────────────────

    def activate(self, name: str) -> bool:
        """Activate a tool so it appears in the function calling schema.

        Clears disabled state if set. Returns True if newly activated.
        """
        if name in self._active:
            return False
        if name not in self._tools:
            return False
        self._active.add(name)
        self._disabled.discard(name)
        logger.debug(f"Tool activated: {name}")
        return True

    def deactivate(self, name: str) -> bool:
        """Deactivate a standard-tier tool (core tools cannot be deactivated).

        Adds to _disabled set so auto-activate on execute won't re-enable it.
        Returns True if deactivated, False if core or unknown.
        """
        tool = self._tools.get(name)
        if not tool or tool.metadata.tier == "core":
            return False
        self._active.discard(name)
        self._disabled.add(name)
        logger.debug(f"Tool deactivated: {name}")
        return True

    def get_active_tools(self) -> list[Tool]:
        """Return tools currently in the function calling schema."""
        return [t for t in self._tools.values() if t.name in self._active]

    def get_inactive_tools(self) -> list[Tool]:
        """Return tools available but not yet activated (excludes hidden tier)."""
        return [
            t
            for t in self._tools.values()
            if t.name not in self._active and t.metadata.tier != "hidden"
        ]

    def set_mcp_manager(self, mcp_manager: Any | None) -> None:
        """Store MCP manager reference for ``is_available()`` checks."""
        self._mcp_manager = mcp_manager

    def is_available(self, name: str) -> bool:
        """Return True if a tool or MCP server with *name* is available.

        For MCP server names (``MCP_<server>``): checks via MCPManager whether
        the server is configured and enabled — does NOT require the server to
        be connected or its tools to be registered. This makes the check stable
        at startup (config-based, no runtime state dependency).
        """
        if name in self._tools:
            return True
        # MCP server check via manager: "MCP_teams" → server "teams" configured + enabled
        if name.startswith("MCP_") and self._mcp_manager is not None:
            server_name = name[len("MCP_") :]
            servers = self._mcp_manager.list_servers()
            return any(s.name == server_name and s.enabled for s in servers)
        return False

    def get_standard_tools_summary(self) -> str:
        """Summary of standard-tier non-MCP tools for system prompt.

        Lists ALL standard tools except MCP (regardless of activation state).
        Includes builtin and custom categories. Stable across enable/disable
        operations during a conversation, which preserves the LLM prompt cache.
        May change if new standard tools are registered after startup.
        """
        if self._standard_summary_cache is not None:
            return self._standard_summary_cache
        # Exclude MCP tools (own section in _list_all)
        standard = [
            t
            for t in self.list_tools_sorted()
            if t.metadata.tier == "standard" and t.metadata.category != "mcp"
        ]
        if not standard:
            self._standard_summary_cache = ""
            return ""
        lines = ["## Additional Tools\n\nUse `tools(name='<name>')` to enable if needed:\n"]
        for t in standard:
            first_line = t.description.split("\n")[0]
            brief = first_line.split(". ")[0].rstrip(".")
            lines.append(f"- {t.name}: {brief}")
        self._standard_summary_cache = "\n".join(lines)
        return self._standard_summary_cache

    def scoped_copy(
        self, tool_names: list[str], *, audit: AuditLogger | None = None
    ) -> ToolRegistry:
        """Create a new registry containing only the named tools.

        Used for sub-agent spawning — the child gets a restricted toolset.
        """
        scoped = ToolRegistry(audit=audit or self._audit)
        scoped._output_config = self._output_config
        name_set = set(tool_names)
        for name, tool in self._tools.items():
            if name in name_set:
                scoped._tools[name] = tool
                if name in self._active:
                    scoped._active.add(name)
        return scoped

    async def execute(
        self,
        name: str,
        args: dict[str, Any],
        *,
        actor: str = "agent",
        session_id: str | None = None,
        sender_id: str | None = None,
        bus: MessageBus | None = None,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        call_id: str | None = None,
    ) -> str:
        """Execute a tool by name with audit logging and optional progress streaming."""
        tool = self._tools.get(name)
        if tool is None:
            return f"Error: unknown tool '{name}'{_ERROR_HINT}"

        # Auto-activate standard tools on first use (LLM may call tools it
        # discovered from the system prompt inactive summary without explicitly
        # enabling them via tools()).  Skip if explicitly disabled or hidden.
        if name not in self._active and name not in self._disabled:
            if tool.metadata.tier != "hidden":
                self._active.add(name)
                logger.debug(f"Tool auto-activated on first use: {name}")

        # Pass channel/session context as kwargs so tools can use it without
        # mutable state. CopilotDelegateTool / ClaudeCodeTool read these for
        # follow-up re-injection routing (which must land in the *user's*
        # session, not a spoofed one).
        #
        # Work on a *copy* of args so we don't mutate the caller's dict. The
        # agent loop later re-reads the original ``tc.arguments`` for
        # post_tool_use hooks, audit logging, truncation, and loop detection
        # (which hashes arg signatures to spot repeats) — in-place pop /
        # inject would leak runtime context into those paths and shift the
        # loop-detector hash every call, defeating repeat detection.
        #
        # Runtime provenance is authoritative. Tool-call args come from the
        # LLM (or a stored cron job) and JSON-schema keys aren't enforced at
        # runtime, so a caller could otherwise pass underscore-prefixed keys
        # to pin a follow-up inbound to a victim session (cross-session
        # injection) or spoof the audit-log sender. Strip all reserved keys
        # first, then set from runtime — so args can NEVER supply them,
        # even when a given runtime value is absent (cron scheduler calls,
        # non-interactive callers, etc.).
        args = dict(args)
        for reserved in RESERVED_RUNTIME_KWARGS:
            args.pop(reserved, None)
        if channel and channel_id:
            args["_channel"] = channel
            args["_channel_id"] = channel_id
            if thread_id:
                args["_thread_id"] = thread_id
        if session_id:
            args["_session_id"] = session_id
        if sender_id:
            args["_sender_id"] = sender_id
        # Pass metadata so spawn can propagate cron/heartbeat source to child agents.
        if metadata is not None:
            args["_metadata"] = metadata

        # Determine the channel-specific tool-meta payload shape:
        #   cloud_teams   → slim `{id, name, args}` / `{id, name, error,
        #                   durationMs, args}` with per-value 32-char cap. Args
        #                   render inline in the streaming dispatcher's tool
        #                   line (`🔧 name(arg) ⏳`); tool_progress is
        #                   suppressed entirely.
        #   cloud_webchat → full shape but per-value capped at 128 chars (the
        #                   Web UI displays args/result panels but doesn't need
        #                   multi-KB blobs to do so)
        #   other (cli)   → full payload, no truncation
        _has_stream_ctx = bus is not None and bool(channel) and bool(channel_id)
        _source = (metadata or {}).get("source", "")
        _is_teams = _source == "cloud_teams"
        _is_cloud_web = _source == "cloud_webchat"

        # Wire progress callback for streaming-capable tools.
        # Skip for Teams — tool_progress chunks are intermediate updates that
        # WebChat can render incrementally but Teams cannot stream or display.
        prev_callback = tool._progress
        if tool.metadata.streaming and _has_stream_ctx and not _is_teams:

            async def _progress(text: str) -> None:
                assert bus and channel and channel_id  # mypy narrowing
                # Redact secrets before streaming to user
                sanitized = redact_credentials(text)
                await bus.dispatch_outbound(
                    StreamingChunk(
                        channel=channel,
                        channel_id=channel_id,
                        content=sanitized,
                        chunk_type="tool_progress",
                    )
                )

            tool.set_progress_callback(_progress)

        # Stable ID for tool_start + tool_end matching (generate once)
        import json as _json

        final_id = call_id or f"{name}-{time.time_ns()}"

        # Notify frontend that tool execution is starting.
        if _has_stream_ctx:
            assert bus and channel and channel_id  # mypy narrowing
            start_payload: dict[str, Any]
            user_args = {k: v for k, v in args.items() if not k.startswith("_")}
            if _is_teams:
                # Heavy 32-char per-value clip so the dispatcher's
                # `🔧 name(arg) ⏳` informative stays under the 900-byte body cap.
                start_payload = {
                    "id": final_id,
                    "name": name,
                    "args": _truncate_args_for_cloud_teams(user_args),
                }
            else:
                if _is_cloud_web:
                    user_args = _truncate_args_for_cloud_web(user_args)
                start_payload = {"id": final_id, "name": name, "args": user_args}
            await bus.dispatch_outbound(
                StreamingChunk(
                    channel=channel,
                    channel_id=channel_id,
                    content=redact_credentials(
                        _json.dumps(start_payload, ensure_ascii=False, default=str)
                    ),
                    chunk_type="tool_start",
                )
            )

        start = time.monotonic()
        tool_timeout = getattr(tool.metadata, "timeout", 600)

        async def _send_tool_end(
            tool_result: str, duration_ms: float, is_error: bool = False
        ) -> None:
            if not _has_stream_ctx:
                return
            assert bus and channel and channel_id  # mypy narrowing
            # Per-channel payload shape — see the `_is_teams` / `_is_cloud_web`
            # comment above. cloud_webchat result is capped at 128 chars to
            # match the args truncation; the Web UI's result panel doesn't
            # need the full body for status purposes.
            payload: dict[str, Any]
            if _is_teams:
                # Result is heavily clipped (32 chars) so the dispatcher's
                # `🔧 tool(arg) ✓ Nms → result` line still fits in the
                # 900-byte body cap alongside the rest of the tool trail.
                # Redact-then-ellipsize ordering matches the args path —
                # see _truncate_args_for_cloud_teams for the rationale.
                payload = {
                    "id": final_id,
                    "name": name,
                    "result": ellipsize(
                        redact_credentials(tool_result), _CLOUD_TEAMS_RESULT_CHAR_CAP
                    ),
                    "error": is_error,
                    "durationMs": round(duration_ms),
                }
            elif _is_cloud_web:
                payload = {
                    "id": final_id,
                    "name": name,
                    # Redact-then-ellipsize: a fixed-length credential at the tail
                    # of tool_result would otherwise slip the outer detector once
                    # clipped past the cap. Same reasoning as
                    # _truncate_args_for_cloud_teams's redact-first ordering.
                    "result": ellipsize(redact_credentials(tool_result), _CLOUD_WEB_META_CHAR_CAP),
                    "durationMs": round(duration_ms),
                    "error": is_error,
                }
            else:
                payload = {
                    "id": final_id,
                    "name": name,
                    "result": tool_result[:2000],
                    "durationMs": round(duration_ms),
                    "error": is_error,
                }
            await bus.dispatch_outbound(
                StreamingChunk(
                    channel=channel,
                    channel_id=channel_id,
                    content=redact_credentials(
                        _json.dumps(payload, ensure_ascii=False, default=str)
                    ),
                    chunk_type="tool_end",
                )
            )

        try:
            result = await asyncio.wait_for(tool.execute(**args), timeout=tool_timeout) or ""
            elapsed = (time.monotonic() - start) * 1000
            self._audit.log_tool(
                tool=name,
                actor=actor,
                args=args,
                result=result,
                session_id=session_id,
                duration_ms=elapsed,
            )
            await _send_tool_end(result, elapsed)
            return result
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            error_msg = f"Error executing {name}: {exc}{_ERROR_HINT}"
            logger.error(f"Error executing {name}: {exc}")
            self._audit.log_tool(
                tool=name,
                actor=actor,
                args=args,
                result=str(exc),
                is_error=True,
                session_id=session_id,
                duration_ms=elapsed,
            )
            await _send_tool_end(error_msg, elapsed, is_error=True)
            return error_msg
        finally:
            # Restore previous callback (avoid clearing another in-flight callback)
            tool.set_progress_callback(prev_callback)
