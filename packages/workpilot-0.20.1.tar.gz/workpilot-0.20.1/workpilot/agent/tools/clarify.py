"""
ClarifyTool — agent-initiated mid-task question.

The LLM calls ``clarify`` to ask the user a question and pauses the current
tool batch until the user answers or the timeout elapses. The
synchronous-await pattern preserves the ``function_call ↔
function_call_output`` adjacency contract enforced by
``providers/client.py:_prepare_items_for_api()`` (no orphans).

``/cancel`` slash and E-stop are user-halt signals; the tool maps
them to ``outcome="error"`` with a "user halted" reason in the
``error`` field — no separate ``cancel`` outcome (see ``ClarifyOutcome``
comment block below for the rationale).

See ``design/features/tool-clarify.md`` for the full design spec, including:

* §4 — schema (this file's Pydantic models)
* §5 — lifecycle & restart degradation
* §6 — inbound matching (Lane 1 / P2 shortcut / P3 prefix / Lane 2 recency)
* §13 — LLM prompt guidance (returned verbatim by ``description``)

This module is **deliberately not registered to the tool registry yet**
(foundation slice). LLMs cannot call it until a follow-up PR adds the
channel/router/render layer + registry entry. Issue #473 tracks the
overall Interactive Control milestone.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger
from pydantic import BaseModel, Field, model_validator

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.events import OutboundMessage
from workpilot.config.schema import ChannelType
from workpilot.security.clarify import (
    ClarifyInterruptedError,
    ClarifyManager,
    ClarifyRequest,
    ConcurrentClarifyError,
)
from workpilot.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from workpilot.bus.queue import MessageBus

__all__ = [
    "ClarifyArgs",
    "ClarifyOption",
    "ClarifyOutcome",
    "ClarifyQuestion",
    "ClarifyResult",
    "ClarifyTool",
]


# ── Schema (design §4.1, §4.2) ──────────────────────────────────────────────


class ClarifyOption(BaseModel):
    """One choice on a multiple-choice question."""

    label: str = Field(
        max_length=40,
        description="Button text; in `answers` when picked.",
    )
    subtitle: str | None = Field(
        default=None,
        max_length=120,
        description="Secondary line under the label.",
    )


class ClarifyQuestion(BaseModel):
    """One question. Up to 4 questions can ride on a single clarify call."""

    question: str = Field(
        max_length=200,
        description="Question text.",
    )
    default: str | None = Field(
        default=None,
        max_length=200,
        description=(
            "Echoed in `answers` on timeout (list if `multi_select`). "
            "With `options`, must match a label (case-sensitive)."
        ),
    )
    options: list[ClarifyOption] = Field(
        default_factory=list,
        max_length=4,
        description="Choices; empty for free-text.",
    )
    multi_select: bool = Field(
        default=False,
        description="Multi-select (answers becomes list). Needs options.",
    )

    @model_validator(mode="after")
    def _multi_select_requires_options(self) -> ClarifyQuestion:
        """Multi-select over free text has no UI semantics."""
        if self.multi_select and not self.options:
            raise ValueError(
                "ClarifyQuestion: multi_select=True requires non-empty options; "
                "use multi_select=False for free-text answers."
            )
        return self

    @model_validator(mode="after")
    def _option_labels_unique(self) -> ClarifyQuestion:
        """Option labels are the canonical structured answer (the LLM
        receives them in ``answers`` for ``answered_card`` outcomes, and
        ``default`` must match one of them). Duplicates would make those
        downstream paths ambiguous — reject upfront."""
        if not self.options:
            return self
        labels = [opt.label for opt in self.options]
        seen: set[str] = set()
        for label in labels:
            if label in seen:
                raise ValueError(
                    f"ClarifyQuestion: option labels must be unique within a "
                    f"question; got duplicate {label!r} in {labels}"
                )
            seen.add(label)
        return self

    @model_validator(mode="after")
    def _default_matches_option(self) -> ClarifyQuestion:
        """When options are present, ``default`` must match one of the option
        labels — otherwise the §7.2 card pre-select rule silently drops, and
        the LLM's commitment shown on the card doesn't correspond to anything
        the user can pick.

        Strict equality (case-sensitive) — matches §7.2 pre-select behaviour.
        Free-text questions (``options=[]``) accept any default.
        """
        if self.default is None or not self.options:
            return self
        labels = {opt.label for opt in self.options}
        if self.default not in labels:
            raise ValueError(
                f"ClarifyQuestion: default={self.default!r} must exactly match "
                f"one of the option labels {sorted(labels)} (case-sensitive) "
                f"or be omitted/null."
            )
        return self

    def echo_default(self) -> str | list[str] | None:
        """Resolve ``default`` to its echo shape for ``answers`` on timeout.

        Mirrors the answer-shape contract: ``multi_select`` questions
        always receive a list; single-select questions receive the
        scalar string; ``None`` passes through unchanged. Without this
        wrap, a multi_select question with a non-null default would
        produce a scalar ``answers`` on timeout while real card replies
        produce lists — breaking the type contract the LLM relies on
        for dispatch.
        """
        if self.default is None:
            return None
        if self.multi_select:
            return [self.default]
        return self.default


class ClarifyArgs(BaseModel):
    """Top-level arguments for the clarify tool call."""

    questions: list[ClarifyQuestion] = Field(
        min_length=1,
        max_length=4,
        description="Atomic batch; answer all together.",
    )
    timeout: int = Field(
        ge=10,
        le=600,
        description="Timeout in seconds.",
    )

    @model_validator(mode="after")
    def _unique_questions(self) -> ClarifyArgs:
        # ``answers`` (multi-Q dict) is keyed by ``ClarifyQuestion.question``
        # — duplicates would silently overwrite each other on resolve.
        # Reject upfront so the LLM gets a clean validation error and
        # can re-emit with disambiguated wording.
        seen: set[str] = set()
        for q in self.questions:
            if q.question in seen:
                raise ValueError(
                    f"questions[*].question must be unique within a single clarify call; "
                    f"got duplicate {q.question!r}"
                )
            seen.add(q.question)
        return self


# ── Result (design §4.2) ────────────────────────────────────────────────────


# Single outcome enum — three levels of "user gave something" plus
# the two non-answer outcomes. Trust descends through the answer-family
# as the user moves further from the card's structured affordances.
#
# - ``answered_card`` — user clicked an option button (or used the
#   keyboard shortcut equivalent). The value is necessarily one of the
#   offered option labels. **Highest trust** — the user explicitly chose.
# - ``answered_chat`` — user typed in the card's own input field (still
#   inside the card, focused on the question, but free-form rather than
#   picking an option). **Medium trust** — engaged with the card, but
#   the value may be off-label.
# - ``free_chat`` — user typed in the chat's main input bar (Lane 2),
#   bypassing the card entirely. **Lowest trust** — the text may be
#   the answer, may be a question, may be a side-comment, may be off-
#   topic. The LLM interprets in context.
# - ``timeout`` — no response within ``timeout`` (timer expiry,
#   ignored card, closed tab — natural-no-response paths). Carries
#   echoed per-question ``default``(s). User-halted-via-/cancel does
#   NOT land here (would falsely imply the user accepted the LLM's
#   default); see ``error`` below.
# - ``error`` — no useful answer was obtained. Three reasons share
#   this outcome (LLM dispatch is identical: don't trust empty
#   ``answers``, read ``error`` field for context):
#     * tool refused (invalid args / missing context / concurrent
#       rejection / internal waiter error) → LLM may fix args & retry
#     * user halted via /cancel slash or E-stop → LLM should not
#       retry; respond to the user's redirect / next message
#     * "tool refused" vs "user halted" is disambiguated by the
#       ``error`` field text.
ClarifyOutcome = Literal["answered_card", "answered_chat", "free_chat", "timeout", "error"]


class ClarifyResult(BaseModel):
    """Returned from ``ClarifyTool.execute`` — becomes the
    ``function_call_output`` content for the LLM's next turn."""

    outcome: ClarifyOutcome
    # Polymorphic answers — shape adapts to outcome + question count to
    # minimise wire/token overhead. ``exclude_none=True`` on serialisation
    # drops the top-level ``answers`` field when its value is ``None``
    # (Pydantic v2 keeps dict-internal ``None`` values intact).
    #
    # Per outcome (shape depends on input path × multi_select):
    #   answered_card (single-question)
    #     → ``"prod"`` (str) or ``["prod", "dev"]`` (list[str], multi_select)
    #   answered_chat (single-question)
    #     → ``"typed text"`` — always scalar string; the card text input
    #       is a single field, so even multi_select questions yield a
    #       scalar when the user typed instead of clicking
    #   answered_card / answered_chat (multi-question)
    #     → ``{"Q1": "prod", "Q2": "yes"}``; answered_card values may be
    #       lists per their own multi_select; answered_chat values are
    #       always scalar strings
    #   free_chat (always single-question per §6.2)
    #     → ``"wait let me think"`` (the typed text, may not be answer)
    #   timeout (single-question)
    #     → echoed ``default`` using the answered_card shape (scalar, or
    #       list[str] for multi_select); ``None`` when the LLM committed
    #       null/omitted, in which case ``exclude_none`` drops the field
    #   timeout (multi-question)
    #     → ``{Q: <default echo>}`` keyed by every question; per-Q values
    #       may be ``None`` where that question's default was null, but
    #       the dict itself is preserved (the LLM sees missing-default Qs
    #       as explicit ``null`` entries)
    #   error
    #     → ``None`` → field dropped from the wire JSON via ``exclude_none``
    #
    # The LLM dispatches on outcome + its own emitted num_questions
    # (sitting adjacent in tool_call args) to read this correctly.
    answers: str | list[str] | dict[str, str | list[str] | None] | None = None
    # Time from clarify-publish to resolution, in seconds (fractional).
    latency: float = 0.0
    # Populated only on outcome="error" (tool refused — invalid args,
    # missing context, concurrent rejection, internal). Null for all
    # other outcomes; serialised only on error.
    error: str | None = None

    @model_validator(mode="after")
    def _error_matches_outcome(self) -> ClarifyResult:
        """Enforce the documented invariant: ``error`` is populated iff
        ``outcome == "error"``. Prevents callers from emitting an
        ambiguous result (e.g. ``outcome="timeout"`` carrying an error
        message, or ``outcome="error"`` with no reason)."""
        if self.outcome == "error":
            if self.error is None or not self.error.strip():
                raise ValueError(
                    'ClarifyResult: `error` must be a non-empty string when outcome="error"'
                )
        elif self.error is not None:
            raise ValueError(
                f"ClarifyResult: `error` must be None when outcome="
                f"{self.outcome!r}; got {self.error!r}"
            )
        return self


# ── Tool (design §13 description; §11 risk; §5 lifecycle) ───────────────────


# §13 prompt block — the single source of truth for LLM behaviour. Returned
# verbatim by ``ClarifyTool.description``.  Edits here become the live
# guidance on the next process restart.
_DESCRIPTION = """\
clarify — Ask the user a blocking question. When:
- Required input you can't safely guess (free-text or implied
  alternatives).
- High-stakes irreversible choice (no approval gate).

Skip if approval handles risk, answerable by tools/code/sense, or
subjective.

Result:
- 1 Q → scalar; 2+ related → dict by question. List only on multi_select answered_card/timeout.
- outcome:
  answered_card: clicked an option.
  answered_chat: typed in card input.
  free_chat: typed off-card — JUDGE FIRST (may redirect/off-topic).
  timeout: no response; answers = default.
  error: see error.
"""


def _compact_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Strip LLM-irrelevant noise from Pydantic-generated JSON Schema.

    Drops auto-generated ``title`` keys (redundant with property names),
    class-level ``description`` (covered by ``_DESCRIPTION``), flattens
    nested ``anyOf`` (distributing parent constraints), and collapses
    ``anyOf`` of simple types into ``type:[X,Y,...]`` arrays. Saves
    ~30% schema tokens on the wire.
    """

    def _flatten_anyof(variants: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Inline a nested ``anyOf`` by distributing the wrapper's other
        constraints (e.g. ``maxLength``) into each inner variant. Pydantic
        emits this nested form for unions like ``str | int | None``."""
        out: list[dict[str, Any]] = []
        for v in variants:
            inner = v.get("anyOf")
            if isinstance(inner, list):
                extras = {k: val for k, val in v.items() if k != "anyOf"}
                for sub in inner:
                    out.append({**extras, **sub})
            else:
                out.append(v)
        return out

    def _collapse_to_type_array(node: dict[str, Any]) -> None:
        """If every ``anyOf`` variant has a simple primitive ``type`` and
        no conflicting peer constraints, hoist into ``type:[...]``."""
        variants = node.get("anyOf")
        if not isinstance(variants, list):
            return
        types: list[str] = []
        extras: dict[str, Any] = {}
        for v in variants:
            t = v.get("type")
            if not isinstance(t, str):
                return
            types.append(t)
            for k, val in v.items():
                if k == "type":
                    continue
                if k in extras and extras[k] != val:
                    return
                extras[k] = val
        node.pop("anyOf")
        node["type"] = types
        for k, val in extras.items():
            node[k] = val

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            node.pop("title", None)
            if "description" in node and "properties" in node:
                node.pop("description")
            if isinstance(node.get("anyOf"), list):
                node["anyOf"] = _flatten_anyof(node["anyOf"])
                _collapse_to_type_array(node)
            if "default" in node:
                d = node["default"]
                t = node.get("type")
                # Drop default:null for nullable unions (already implicit).
                if d is None and isinstance(t, list) and "null" in t:
                    node.pop("default")
                # Drop default:false for booleans (the trivial default).
                elif d is False and t == "boolean":
                    node.pop("default")
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(schema)
    _inline_single_use_refs(schema)
    return schema


def _inline_single_use_refs(schema: dict[str, Any]) -> None:
    """Inline ``$defs`` entries that are referenced exactly once.

    Single-use ``$ref`` indirection is pure overhead for LLM tool-calling:
    no de-duplication benefit, plus the model has to mentally resolve the
    reference. Inlining yields a linear schema. Multi-use entries are
    preserved to keep the schema compact when duplication matters.
    """
    defs = schema.get("$defs")
    if not isinstance(defs, dict) or not defs:
        return

    counts: dict[str, int] = {}

    def count(node: Any) -> None:
        if isinstance(node, dict):
            ref = node.get("$ref")
            if isinstance(ref, str):
                name = ref.rsplit("/", 1)[-1]
                counts[name] = counts.get(name, 0) + 1
            for k, v in node.items():
                if k == "$ref":
                    continue
                count(v)
        elif isinstance(node, list):
            for v in node:
                count(v)

    for k, v in schema.items():
        if k != "$defs":
            count(v)
    for d in defs.values():
        count(d)

    inlinable = {n: d for n, d in defs.items() if counts.get(n, 0) == 1}
    if not inlinable:
        return

    def replace(node: Any) -> Any:
        if isinstance(node, dict):
            ref = node.get("$ref")
            if isinstance(ref, str) and len(node) == 1:
                name = ref.rsplit("/", 1)[-1]
                if name in inlinable:
                    return replace(inlinable[name])
            return {k: replace(v) for k, v in node.items()}
        if isinstance(node, list):
            return [replace(v) for v in node]
        return node

    for k in list(schema.keys()):
        if k != "$defs":
            schema[k] = replace(schema[k])

    remaining = {n: replace(d) for n, d in defs.items() if n not in inlinable}
    if remaining:
        schema["$defs"] = remaining
    else:
        schema.pop("$defs", None)


# Static post-processed schema — the ClarifyArgs class is fixed at module
# load, so the schema is too. Computing once avoids per-iteration
# overhead in ``ToolRegistry.get_schemas()`` (called every agent turn).
_PARAMETERS_SCHEMA: dict[str, Any] = _compact_schema(ClarifyArgs.model_json_schema())


def _error_result_json(error: str) -> str:
    """Serialise an ``outcome="error"`` ClarifyResult for early-return
    paths (invalid args / missing context / concurrent rejection /
    internal errors). The ``error`` field is always set on this path."""
    return ClarifyResult(
        outcome="error",
        answers=None,
        latency=0.0,
        error=error,
    ).model_dump_json(exclude_none=True)


def _persist_text(request: ClarifyRequest) -> str:
    """Build the body that lands in session JSONL via outbound
    persistence (§10.1).

    Returns ONLY the human-facing question text — the framing prefix
    (``[Notification delivered to user at HH:MM:SS via clarify] ...``)
    is added by ``frame_notification`` in the outbound persist pipeline
    because ``"clarify"`` is in ``NOTIFICATION_SOURCES``. Returning a
    pre-prefixed body here would produce a nested
    ``[Notification ...] [Clarification ...]`` in JSONL / WS push.

    Renderer placeholder: the foundation slice does not build a real
    Adaptive Card. The agent loop is not wired to clarify yet, so this
    text is what ends up in the JSONL when (later) channels exist; for
    now it's only used by unit tests asserting outbound publication.
    """
    lines: list[str] = []
    for i, q in enumerate(request.questions, start=1):
        prefix = f"{i}. " if len(request.questions) > 1 else ""
        lines.append(f"{prefix}{q.question}")
        for opt in q.options:
            lines.append(f"  - {opt.label}" + (f" ({opt.subtitle})" if opt.subtitle else ""))
    return "\n".join(lines)


class ClarifyTool(Tool):
    """Agent-initiated mid-task question.

    Constructor takes the message bus and a ClarifyManager; the registry's
    standard ``_channel`` / ``_channel_id`` / ``_session_id`` kwargs
    injection (mirrors ``notify.py:88-90``) supplies the per-call channel
    binding at ``execute`` time.

    NOT registered to the tool registry in this slice — channel adapters,
    router refactor, and registry entry land in the follow-up PR (see the
    PR description and issue #473).
    """

    risk_range = (0, 0)  # always RiskScore(0) — never escalates

    @property
    def metadata(self) -> ToolMetadata:
        # Schema's ``timeout`` upper bound is 600 s. The framework's
        # static ``tool_timeout`` (registry.py:370) wraps the whole
        # execute() call, so it MUST exceed 600 — otherwise a user-set
        # timeout=600 races against the framework cancellation and could
        # leave a pending clarify behind with no chance for the manager's
        # timeout-default branch to run.
        # 30 s buffer covers register + publish overhead and the
        # default-application path comfortably.
        return ToolMetadata(timeout=630)

    def __init__(
        self,
        bus: MessageBus,
        manager: ClarifyManager,
    ) -> None:
        self._bus = bus
        self._manager = manager

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "clarify"

    @property
    def description(self) -> str:
        return _DESCRIPTION

    @property
    def parameters(self) -> dict[str, Any]:
        # Schema is static (Pydantic class definition is fixed at import
        # time) — compute the post-processed form once at module load
        # rather than every ``ToolRegistry.get_schemas()`` call. Callers
        # are expected to treat the returned dict as read-only; the tool
        # registry forwards it verbatim to the LLM API.
        return _PARAMETERS_SCHEMA

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="User clarification — no state mutation, no external send.")

    def validate(self, args: dict[str, Any]) -> list[str]:
        try:
            ClarifyArgs.model_validate(args)
            return []
        except Exception as exc:
            return [str(exc)]

    # ── Execute ─────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        """Register the pending clarify, publish the outbound, and await
        resolution (or timeout). Returns a JSON-serialised
        :class:`ClarifyResult` for the LLM's ``function_call_output``.
        """
        # Validate & normalise via Pydantic. Tool registry strips internal
        # ``_*`` kwargs before constructing the schema — see notify.py
        # pattern; we re-strip defensively here too.
        tool_args = {k: v for k, v in kwargs.items() if not k.startswith("_")}
        try:
            args = ClarifyArgs.model_validate(tool_args)
        except Exception as exc:
            return _error_result_json(f"clarify: invalid arguments — {exc}")

        # Channel context — injected by the registry per-call (mirror of
        # tools/notify.py:88-90). The registry passes ``_channel`` as a
        # ``ChannelType`` enum (a ``StrEnum`` subclass of ``str``);
        # normalise to a plain string explicitly so the code stays
        # robust if the injection type ever changes. Read the raw kwarg
        # directly rather than going through ``ChannelType.of`` because
        # the latter coerces unknowns to CLI silently — a missing or
        # typoed ``_channel`` would then bind this clarify to "cli"
        # (wrong for web/cloud sessions, and the §9 channel-binding
        # gate would later reject the user's real answer as
        # "foreign-channel"). Validate explicitly below.
        _channel_raw = kwargs.get("_channel")
        raw_channel: str = str(_channel_raw).strip() if _channel_raw else ""
        current_channel_id: str = kwargs.get("_channel_id", "")
        current_session_id: str = kwargs.get("_session_id", "")

        if not current_session_id:
            # Defensive: clarify needs a session to bind to. Sub-agent /
            # cron / external-MCP paths exclude clarify upstream (§12), so
            # this branch should be unreachable in production. Surface a
            # clean error instead of crashing.
            logger.warning("clarify executed without a session_id — refusing")
            return _error_result_json("clarify is unavailable in this context (no session)")

        if not raw_channel:
            logger.warning(
                "clarify executed without a _channel injection — refusing "
                "(would otherwise silently bind to cli)"
            )
            return _error_result_json("clarify is unavailable in this context (no channel)")

        # Validate against known ChannelType values. ChannelType.of
        # silently coerces unknowns to CLI — combined with the §9
        # channel-binding gate, a typoed _channel injection would
        # bind clarify to "cli" and then reject the user's real
        # answer as foreign-channel, forcing a phantom timeout.
        # Refuse explicitly so the LLM gets a clean error.
        try:
            current_channel = ChannelType(raw_channel)
        except ValueError:
            logger.warning("clarify executed with unknown _channel={!r} — refusing", raw_channel)
            return _error_result_json(
                f"clarify is unavailable in this context (unknown channel {raw_channel!r})"
            )

        # Register pending. Reject if the session already has a clarify in
        # flight (§8.1 one-clarify-per-session).
        try:
            request = self._manager.register(
                session_id=current_session_id,
                questions=list(args.questions),
                timeout=args.timeout,
                channel=str(current_channel),
                channel_id=current_channel_id,
            )
        except ConcurrentClarifyError as exc:
            logger.info("clarify rejected (concurrent): {}", exc)
            return _error_result_json(str(exc))

        started_at = datetime.now(UTC)

        # Publish the question to the bound channel. Foundation slice ships
        # a plain-text payload — channel adapters and clarify_render.py
        # land in the follow-up PR. Persistence framing is shared via
        # outbound persistence (§10.1) since ``"clarify"`` is in
        # NOTIFICATION_SOURCES.
        if current_channel:
            try:
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=current_channel,
                        channel_id=current_channel_id or str(current_channel),
                        content=_persist_text(request),
                        metadata={
                            "source": "clarify",
                            "_origin": "clarify",
                            "_ts": started_at.isoformat(),
                            "clarify_id": request.id,
                            "target_session_id": current_session_id,
                        },
                    )
                )
            except Exception as exc:
                # User never saw the question — waiting for an "answer"
                # would surface ``timeout``/default as if the user
                # ignored a prompt that never reached them, driving the
                # task down the wrong branch. Discard the pending entry
                # and return a clean ``outcome="error"`` so the LLM
                # knows the call failed at delivery, not by inaction.
                logger.exception("clarify: failed to publish outbound")
                self._manager.discard_pending(current_session_id)
                return _error_result_json(f"clarify: failed to publish outbound — {exc}")

        # Block until the user replies or the LLM-chosen timeout
        # elapses. PR-2 will plumb ``_interrupt_event`` through the
        # registry's reserved-kwargs path; passing it into
        # ``wait_for_resolution(interrupt_event=...)`` lets ``/cancel``
        # / E-stop short-circuit the wait sub-second. When that fires
        # the manager raises ``ClarifyInterruptedError``; we package
        # it here as ``outcome="error"`` with a "user halted" reason
        # rather than letting it surface as ``timeout`` (which would
        # echo the LLM's committed default and misleadingly imply
        # the user implicitly accepted it). All three "no useful
        # answer" paths (tool refused, user halted, internal failure)
        # share the ``error`` outcome — the LLM dispatches the same
        # way (don't trust empty answers, read ``error`` field for
        # context) — but the field text disambiguates for audit /
        # debugging.
        try:
            resolved = await self._manager.wait_for_resolution(
                session_id=current_session_id,
                timeout=args.timeout,
            )
        except ClarifyInterruptedError:
            return _error_result_json("clarify: user halted via /cancel or E-stop")
        except KeyError:
            logger.exception("clarify: waiter vanished")
            return _error_result_json("clarify: internal waiter error")

        latency = (datetime.now(UTC) - started_at).total_seconds()

        # Pure passthrough — no payload mutation. Whatever the manager
        # resolved with is what the LLM sees. Pydantic on ClarifyResult
        # validates the shape (outcome literal); a malformed manager call
        # surfaces as a loud construction error, not silent coercion.
        # Tool's job is to package, not interpret.
        #
        # Explicit None check rather than ``assert``: bare asserts are
        # stripped under ``python -O`` and would let a None outcome reach
        # Pydantic with a less actionable error message.
        if resolved.outcome is None:
            logger.error("clarify: wait_for_resolution returned without outcome")
            return _error_result_json("clarify: resolution missing outcome")
        result = ClarifyResult(
            outcome=resolved.outcome,
            answers=resolved.answers,
            latency=latency,
        )
        return result.model_dump_json(exclude_none=True)
