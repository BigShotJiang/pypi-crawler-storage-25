"""
Bridge tool — natural-language entry into bridge mode.

See design/features/bridge-mode.md §4.2. The default agent's own LLM call
decides to invoke this tool when the user asks to "switch to Claude Code",
"use copilot from now on", "让 Claude 接手", etc. Intent classification is
done by the LLM we already pay for — no regex side-channel.

Per-turn session/channel context is pulled from a ``ContextVar`` populated
by AgentLoop around tool dispatch — see ``workpilot.agent.bridge.bridge_turn_context``.
This keeps the Tool protocol unchanged (no new kwargs, no setter races) and
works under ``asyncio.gather``-fanned tool batches because each task gets
its own copy of the ContextVar.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workpilot.agent.bridge import get_bridge_turn_context
from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from workpilot.agent.bridge import BridgeService


class BridgeTool(Tool):
    """Enter bridge mode — forward all subsequent turns to an external CLI.

    The actual profile + risk + approval gate runs inside
    ``BridgeService.toggle()`` — ``assess_risk`` here only exists so the
    LLM-facing tool schema can render a consistent risk summary. No
    double-gating (design spec §6.1 single gate entry).
    """

    # Status-only (target omitted) is score=1; toggling on is score=7.
    # The wider range lets the approval gate differentiate "show me what
    # bridge is" from "hand the session over".
    risk_range = (1, 7)

    @property
    def metadata(self) -> ToolMetadata:
        # Long timeout — the toggle itself is cheap, but under standard /
        # controlled profiles it blocks on human approval via ApprovalManager.
        # A short default would expire the tool call while the user was still
        # deciding, orphaning the pending request.
        #
        # ``tier="standard"`` — bridge is a mode switch, not a routine
        # action. Hiding it from the default LLM schema (progressive
        # disclosure via the ``tools`` meta-tool) keeps the core schema
        # focused on frequent-use tools; the LLM activates bridge only
        # when the user actually asks to switch CLIs. The slash path
        # (``/bridge claude`` etc.) remains always-available — the tier
        # only affects LLM-invoked entry.
        return ToolMetadata(timeout=3600, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        target = args.get("target")
        if target not in ("claude", "copilot"):
            # No target = read-only status query (same payload as /bridge).
            # Score=1 keeps it out of approval gates entirely.
            return RiskScore(
                score=1,
                reason="Bridge status read-only — lists available targets and models.",
            )
        return RiskScore(
            score=7,
            reason=(
                f"Bridge mode forwards messages to external {target} CLI; "
                "WorkPilot per-turn risk scoring, allowlist, and tool gating do not apply "
                "(outbound fragments still run through redact_credentials)."
            ),
        )

    def __init__(self, bridge_service: BridgeService) -> None:
        self._bridge = bridge_service

    @property
    def name(self) -> str:
        return "bridge"

    @property
    def description(self) -> str:
        return "Hand this session to an external CLI. Omit target to list options."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "enum": ["claude", "copilot"],
                    "description": (
                        "Which external CLI to bridge to. Omit to return "
                        "current bridge status and list of available targets."
                    ),
                },
                "fresh": {
                    "type": "boolean",
                    "description": "True to start a fresh external session (ignore resume chain).",
                    "default": False,
                },
                "resume_session_id": {
                    "type": "string",
                    "description": (
                        "Pin a specific external session id to resume. "
                        "Only way to hop across WorkPilot sessions."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": (
                        "Override the model for this bridge attempt. Omit "
                        "to let the external CLI pick its own default "
                        "(Claude: ~/.claude/settings.json; Copilot: "
                        "/model config / COPILOT_MODEL env). Set only "
                        "when the user explicitly asks for a specific "
                        "model (e.g. 'use opus for this')."
                    ),
                },
            },
            # ``target`` is optional — without it the tool behaves like
            # ``/bridge`` with no args (status query, no side effects).
        }

    async def execute(self, **kwargs: Any) -> str:
        ctx = get_bridge_turn_context()
        if ctx is None:
            # Called outside a turn-managed context — usually only in tests or
            # direct programmatic calls. No valid session to bridge.
            return (
                "Bridge mode requires per-turn context. Use the /bridge slash "
                "command instead, or invoke the tool from within an agent turn."
            )

        target = kwargs.get("target")
        if target not in ("claude", "copilot"):
            # No (or invalid) target → mirror ``/bridge`` status. Shares
            # the same rendering path so the two surfaces never diverge.
            return await self._bridge.render_status_message(ctx.session_id)

        # Normalise empty / whitespace-only model override to None — the
        # LLM sometimes emits ``""`` when it chose not to override; passing
        # that to the SDK would NOT fall through to user config, it would
        # literally try to set an empty model.
        raw_model = kwargs.get("model")
        model_override = (
            raw_model.strip() if isinstance(raw_model, str) and raw_model.strip() else None
        )

        result = await self._bridge.toggle(
            ctx.session_id,
            target=target,
            channel=ctx.channel,
            channel_id=ctx.channel_id,
            fresh=bool(kwargs.get("fresh", False)),
            resume_session_id=kwargs.get("resume_session_id"),
            source=ctx.source,
            model=model_override,
            # Forward the invoking agent's name so the approval card /
            # audit event is attributed to it, not the default fallback.
            agent_name=ctx.agent_name,
            # The tool-registry PreToolHook (ApprovalGate) has already
            # run ``assess_risk`` → policy-lookup → user approval before
            # ``execute`` is called. Passing ``explicit_user_intent=True``
            # here tells ``BridgeService.toggle`` the consent gate is
            # already satisfied, so it skips its internal ``_run_risk_gate``
            # and avoids double-prompting the user (the "approved but
            # tool hangs" symptom — the second card was queued but the
            # user had already dismissed the dialog from the first one).
            # The restricted-profile hard reject still runs before this
            # (``toggle`` step 1), so restricted is unaffected.
            explicit_user_intent=True,
        )
        return result.message
