"""
Shared helpers for external-CLI integrations (Claude Code, GitHub Copilot).

Currently consumed by bridge-mode (``workpilot/agent/bridge_claude.py``).
The Claude delegate tool (``workpilot/agent/tools/claude_code.py``) still
builds ``ClaudeAgentOptions`` inline — migrating it to call this helper
is a follow-up (would need a test pass to confirm behaviour parity).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def build_claude_agent_options(
    *,
    model: str | None,
    workspace: Path | str,
    system_prompt: str | None = None,
    allowed_tools: list[str] | None = None,
    max_turns: int = 0,
    resume_session_id: str | None = None,
    cli_path: str | Path | None = None,
    dangerously_skip_permissions: bool = False,
    permission_mode: str | None = None,
    setting_sources: list[str] | None = None,
    add_dirs: list[str | Path] | None = None,
) -> Any:
    """Build a ``ClaudeAgentOptions`` from normalised inputs.

    Returns an SDK ``ClaudeAgentOptions`` instance. Import is local so this
    module is safe to import even when ``claude-agent-sdk`` is not installed.

    Permission-mode resolution (priority, highest first):
      1. Explicit ``permission_mode`` — SDK enum from caller
      2. ``dangerously_skip_permissions=True`` → ``"bypassPermissions"``
      3. Unset → SDK default (respects ``~/.claude/settings.json``)

    Bridge-friendly defaults applied unconditionally (verified live on
    0.1.68). When the Claude delegate tool eventually migrates onto
    this helper, review each for delegate-suitability — in particular
    ``continue_conversation`` is bridge-specific and should NOT carry
    over (delegate runs expect clean per-task context, not "pick up
    the user's last CLI session").

      * ``betas=["context-1m-2025-08-07"]`` — enables the 1M context
        window beta. Additive (raises ceiling; doesn't alter short-turn
        behaviour). Probably fine for delegate too.
      * ``skills="all"`` — matches what a user gets running ``claude``
        at the terminal. SDK injects the ``Skill`` tool into
        allowed_tools and, when setting_sources is unset, defaults it
        to ``["user", "project"]`` so installed skills are discoverable.
        Probably fine for delegate too.
      * ``continue_conversation=True`` when no ``resume_session_id`` is
        given — picks up the CLI's most-recent session for this cwd
        (equivalent to ``claude --continue``). Mutually exclusive with
        ``--resume``; we only set it in the else branch. **Bridge-only
        semantics — the delegate tool will need an opt-out knob here
        when it migrates.**
    """
    from claude_agent_sdk import ClaudeAgentOptions

    options_kwargs: dict[str, Any] = {
        "model": model,
        "cwd": str(workspace),
        "betas": ["context-1m-2025-08-07"],
        "skills": "all",
    }

    if system_prompt:
        # Preset + append mode keeps the SDK's built-in system prompt — which
        # auto-loads CLAUDE.md, .claude/agents/*, .claude/commands/*, and
        # .claude/skills/* from the workspace. A raw string would REPLACE the
        # preset and silently disable that auto-loading.
        options_kwargs["system_prompt"] = {
            "type": "preset",
            "preset": "claude_code",
            "append": system_prompt,
        }

    if allowed_tools:
        options_kwargs["allowed_tools"] = allowed_tools

    if max_turns > 0:
        options_kwargs["max_turns"] = max_turns

    if cli_path:
        options_kwargs["cli_path"] = str(cli_path)

    if resume_session_id:
        options_kwargs["resume"] = resume_session_id
    else:
        # No explicit resume target → tell the CLI to pick up its own
        # most-recent session for this cwd. This matches what users get
        # running ``claude`` at the terminal, and gives bridge a sensible
        # default resume target even when our own bridge log is empty
        # (fresh install, /new just cleared it, etc.). ``--continue`` and
        # ``--resume`` are mutually exclusive on the CLI side, hence the
        # else branch.
        options_kwargs["continue_conversation"] = True

    if permission_mode is not None:
        options_kwargs["permission_mode"] = permission_mode
    elif dangerously_skip_permissions:
        options_kwargs["permission_mode"] = "bypassPermissions"

    if setting_sources:
        options_kwargs["setting_sources"] = setting_sources

    if add_dirs:
        # Pre-authorise extra directories for Claude's file-read tools.
        # Bridge uses this to expose ``~/.workpilot/data/attachments`` so
        # user-uploaded images / files are readable without permission
        # prompts even when ``permission_mode`` isn't bypass.
        options_kwargs["add_dirs"] = [str(d) for d in add_dirs]

    return ClaudeAgentOptions(**options_kwargs)
