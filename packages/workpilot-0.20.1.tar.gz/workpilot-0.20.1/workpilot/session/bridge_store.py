"""
Bridge session storage — dedicated JSONL files per (canonical_sid, target).

Each bridge target writes to its own file so the main WorkPilot session
log stays clean (agent turns only, no CLI pass-through content). This
prevents downstream features (LLM context builder, MEMORY extraction,
compaction) from treating Claude / Copilot output as WorkPilot's own.

Layout::

    ~/.workpilot/sessions/bridge/<canonical_sid>.<target>.jsonl

Example paths::

    ~/.workpilot/sessions/bridge/local_cli.claude.jsonl
    ~/.workpilot/sessions/bridge/local_web.copilot.jsonl

Entries are flat JSONL, one turn per line. The file name already encodes
target + session so each entry only carries ``role``, ``content``,
``_ts``, and the external SDK session id for disambiguation when
multiple fresh bridge attempts land in the same file over time.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from workpilot.agent.bridge import BridgeTarget


class BridgeSessionStore:
    """Append-only writer for bridge turns, one file per (sid, target)."""

    def __init__(self, base_dir: Path) -> None:
        """``base_dir`` is the main sessions directory (e.g. ``~/.workpilot/sessions``).
        Bridge files live in a ``bridge/`` subdirectory beneath it, created on
        first write.
        """
        self._root = base_dir / "bridge"

    # Allowed bridge targets — mirrors ``BridgeTarget`` literal, but
    # checked at runtime because ``path_for`` receives the value as a
    # string and a corrupted / manually-edited bridge marker could
    # supply something else.
    _ALLOWED_TARGETS: frozenset[str] = frozenset({"claude", "copilot"})

    def path_for(self, sid: str, target: BridgeTarget) -> Path:
        """Return the JSONL path for a given (session, target) pair.

        Defensive hardening against path-traversal: reject unknown
        ``target`` values, strip any path-separator-looking chars from
        ``sid`` (``/``, ``\\``, ``..``), and verify the resolved path
        stays inside ``self._root``. Callers today always pass
        canonical sids already normalised by ``SessionManager._normalize_id``,
        but this is a belt-and-suspenders check so a future caller
        can't accidentally escape the bridge-log directory.
        """
        if target not in self._ALLOWED_TARGETS:
            raise ValueError(f"Unknown bridge target: {target!r}")
        safe_sid = sid.replace("/", "_").replace("\\", "_").replace("..", "__")
        candidate = (self._root / f"{safe_sid}.{target}.jsonl").resolve()
        root_resolved = self._root.resolve()
        # ``Path.is_relative_to`` is Python 3.9+; we target 3.11+ so it's fine.
        if not candidate.is_relative_to(root_resolved):
            raise ValueError(
                f"Bridge log path would escape store root: sid={sid!r} target={target!r}"
            )
        # Return the resolved candidate — not a freshly-composed Path —
        # so the validated, symlink-resolved location stays the single
        # source of truth for downstream open/stat calls.
        return candidate

    def append_turn(self, sid: str, target: BridgeTarget, entry: dict[str, Any]) -> None:
        """Append one turn as JSON-encoded line. Creates the directory on demand."""
        path = self.path_for(sid, target)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError as exc:  # pragma: no cover — disk-full / perms
            logger.warning("BridgeSessionStore append failed ({}): {}", path, exc)

    def list_logs(self) -> list[dict[str, Any]]:
        """Enumerate all bridge-log files under the store's root.

        Truly stat-only — no file reads, no line counting. ``GET /api/sessions``
        is called frequently (every 10 s polling on the Sessions view) and
        iterating every bridge JSONL just to compute a badge number would
        make the endpoint O(total bridge bytes). ``size_bytes`` from the
        stat call is cheap and "good enough" as a heft signal in the list;
        the drill-in detail view loads the full turn list via
        ``get_turns`` and can show an exact count if needed.
        """
        out: list[dict[str, Any]] = []
        if not self._root.exists():
            return out
        for path in self._root.glob("*.jsonl"):
            stem = path.stem  # "<sid>.<target>"
            if "." not in stem:
                continue
            parent_sid, _, target = stem.rpartition(".")
            if target not in ("claude", "copilot"):
                continue
            try:
                stat = path.stat()
            except OSError:
                continue
            out.append(
                {
                    "stem": stem,
                    "parent_sid": parent_sid,
                    "target": target,
                    "size_bytes": stat.st_size,
                }
            )
        return out

    def get_turns(self, sid: str, target: BridgeTarget) -> list[dict[str, Any]]:
        """Load all turns. Used by the UI renderer; NOT used by dispatch
        (dispatch is append-only and doesn't read back)."""
        path = self.path_for(sid, target)
        if not path.exists():
            return []
        out: list[dict[str, Any]] = []
        try:
            with path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        logger.warning("BridgeSessionStore: skipping malformed line in {}", path)
        except OSError as exc:  # pragma: no cover
            logger.warning("BridgeSessionStore read failed ({}): {}", path, exc)
        return out
