"""
Reasoning effort resolution — scenario-based auto-tuning.

Resolves ``reasoning_effort: "auto"`` into a concrete level via a two-axis
matrix: input complexity (token count) × conversation depth.

    depth  = max(user_turns_floor, iter_boost)
    effort = _MATRIX[depth][input_tier]

Used by the agent loop before each LLM call.
"""

from __future__ import annotations

# ── Thresholds ────────────────────────────────────────────────────────────────

# Input complexity tier boundaries (tokens).
_TOK_SIMPLE = 8  # < 8   → minimal  (greetings, "ok")
_TOK_MODERATE = 20  # < 20  → simple   (brief questions)
_TOK_COMPLEX = 50  # < 50  → moderate; ≥ 50 → complex

# user_turns floor: number of prior non-mid-run user messages.
_TURNS_FLOOR1, _TURNS_FLOOR2, _TURNS_FLOOR3 = 2, 4, 6

# Time-based floor decay (seconds since last message).
_DECAY_MILD, _DECAY_LONG, _DECAY_STALE = 1_800, 7_200, 57_600

# Iteration boost: binary — any tool call in the current turn gives +1.
_ITER_WARM = 1

# Effort levels as integers: none=0 … xhigh=4.
_LEVELS = ("none", "low", "medium", "high", "xhigh")

# 2D lookup: rows = depth (0–3), cols = input_tier (0–3, minimal→complex).
# depth=2 vs depth=3 differ only at moderate (col 2): high vs xhigh.
# depth=3 is reachable only via user_turns_floor=3 (turns ≥ 6), not iter alone.
_MATRIX = (
    (0, 1, 2, 3),  # depth=0: none   / low    / medium / high
    (1, 2, 3, 4),  # depth=1: low    / medium / high   / xhigh
    (2, 3, 3, 4),  # depth=2: medium / high   / high   / xhigh
    (2, 3, 4, 4),  # depth=3: medium / high   / xhigh  / xhigh
)


# ── Main resolver ─────────────────────────────────────────────────────────────


def resolve_reasoning_effort(
    effort: str | None,
    *,
    category: str = "",
    iteration: int = 0,
    user_turns: int = 0,
    elapsed_seconds: float | None = None,
    input_text: str = "",
    has_midrun: bool = False,
) -> str | None:
    """Resolve ``reasoning_effort`` for a given turn.

    Non-``"auto"`` values pass through unchanged.  ``"auto"`` uses:

        effort = _MATRIX[depth][input_tier]
        depth  = max(user_turns_floor, iter_boost)

    Input complexity tiers (tokens):
      minimal  — < 8 tok   greetings / "ok" / single-word commands
      simple   — 8–20 tok  brief questions
      moderate — 20–50 tok typical requests
      complex  — ≥ 50 tok  detailed multi-part requests

    user_turns floor (prior non-mid-run user messages):
      0–1 → 0 / 2–3 → +1 / 4–5 → +2 / ≥6 → +3

    Time decay on floor (elapsed_seconds since last message):
      < 30 min     → unchanged
      30 min – 2 h → floor − 1  (only when floor ≥ 2)
      2 h – 16 h   → floor capped at 1
      ≥ 16 h       → floor capped at 0  (stale)

    iter_boost: binary (+0 / +1). Any tool call started → +1.
    depth=2/3 require user_turns ≥ 4/6 — iter alone cannot reach them.

    Overrides:
      • fast agents (development/system) → ``low`` directly
      • mid-run injection → +1 level (cap xhigh)
    """
    if effort is None:
        return None
    if str(effort) != "auto":
        return str(effort)
    if category in ("development", "system"):
        return "low"

    from workpilot.agent.compaction import count_tokens

    tok = count_tokens(input_text) if input_text else 0
    input_tier = sum(tok >= t for t in (_TOK_SIMPLE, _TOK_MODERATE, _TOK_COMPLEX))

    floor = sum(user_turns >= t for t in (_TURNS_FLOOR1, _TURNS_FLOOR2, _TURNS_FLOOR3))
    if elapsed_seconds is not None:
        if elapsed_seconds >= _DECAY_STALE:
            floor = 0
        elif elapsed_seconds >= _DECAY_LONG:
            floor = min(floor, 1)
        elif elapsed_seconds >= _DECAY_MILD and floor > 1:
            floor -= 1

    depth = max(floor, 1 if iteration >= _ITER_WARM else 0)
    level = _MATRIX[depth][input_tier]

    if has_midrun:
        level = min(level + 1, len(_LEVELS) - 1)

    return _LEVELS[level]
