"""Update CLI command — workpilot update.

Detects install mode automatically:
  - Git (editable install)  → git pull + pip install -e ".[all]"
  - uv tool install         → 4-method cascade (see :func:`_uv_update`)
  - PyPI (pip install)      → pip install --upgrade workpilot

On Windows, entry-point ``.exe`` files cannot be overwritten while the
process that launched them is still running. The uv path addresses this
by verifying the upgrade via the venv python (not the wp.exe shim), and
by falling through a cascade of progressively more forceful commands
until either the venv reports the target version or the install breaks
— in which case we roll back to the pre-update baseline and surface a
text-only recovery prompt telling the user to close all wp processes
and retry from a new terminal (or re-run the install script).

The pip path still uses the older **tolerant upgrade** pattern — run pip
directly, and if it fails *only* on the entry-point copy step, verify the
package was updated in the venv and report success. The old exe shims
still launch the venv Python with a fixed entry-point module path.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import typer

from workpilot import __version__
from workpilot.cli.commands import app, console

# Markers in stderr that indicate an entry-point copy failure (not a real
# package-install failure).  Checked case-insensitively.
#
# Both lock markers (WinError 32 / OS error 32) and permission markers
# require an entrypoint/exe indicator.  WinError 32 is narrower, but can
# still occur for locked DLLs/.pyd files in site-packages, which should
# remain a real install failure rather than a tolerated entry-point issue.
_LOCK_MARKERS = ("winerror 32", "os error 32")
_ENTRYPOINT_INDICATORS = ("entrypoint", "wp.exe", "workpilot.exe", ".deleteme")
_PERMISSION_MARKERS = ("access is denied", "permission denied")


def _is_entrypoint_lock_error(stderr: str) -> bool:
    """Return True if *stderr* indicates only an entry-point copy failure.

    Both lock markers (WinError 32) and permission markers require an
    entrypoint indicator — WinError 32 can also fire for locked DLLs/.pyd
    in site-packages, which is a real install failure.
    """
    lower = stderr.lower()
    has_indicator = any(m in lower for m in _ENTRYPOINT_INDICATORS)
    if not has_indicator:
        return False
    return any(m in lower for m in _LOCK_MARKERS) or any(m in lower for m in _PERMISSION_MARKERS)


def _probe_workpilot_import() -> str | None:
    """Run a fresh subprocess that imports workpilot and reports its version.

    Counterpart to ``utils.update.probe_via_venv`` for the pip path. The
    running ``wp update`` process already has workpilot in ``sys.modules`` from
    its own startup, so an in-process import would say "yes" even when pip
    just wrote a half-installed wheel — pip can update its dist-info / RECORD
    before all package files land (kill mid-install, transient Windows file
    lock on a native binary in claude-agent-sdk / github-copilot-sdk, etc.),
    leaving ``pip show`` happy while ``import workpilot`` from a fresh shell
    fails. A subprocess sees the on-disk state pip just wrote.

    Returns the imported ``__version__`` or None when import fails.
    """
    try:
        r = subprocess.run(
            [
                sys.executable,
                "-c",
                "import workpilot, sys; sys.stdout.write(workpilot.__version__)",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
        )
        if r.returncode != 0:
            return None
        return (r.stdout or "").strip() or None
    except Exception:
        return None


def _missing_shims(scripts_dir: Path | None) -> list[str]:
    """Return ENTRY_POINTS names whose .exe is missing from *scripts_dir*.

    Windows-only — on POSIX uv/pip rewrite the console-script wrappers
    without the file-locking issues that break the Windows path, and the
    uv tool dir layout differs.

    Used to catch the "version landed but new shim was never written" case,
    which happens when upgrading from a pre-v0.15.1 install via a tool/pip
    command that does not re-scan entry_points (older ``uv tool upgrade``),
    or when a concurrently-running ``workpilot.exe`` aborts pip's wheel
    install before the new ``wp.exe`` is created.
    """
    if sys.platform != "win32" or scripts_dir is None or not scripts_dir.is_dir():
        return []
    from workpilot.utils.update import ENTRY_POINTS

    return [n for n in ENTRY_POINTS if not (scripts_dir / f"{n}.exe").exists()]


def cleanup_old_exes() -> None:
    """Remove leftover .old/.deleteme files from previous updates.

    Called from the ``update`` command before performing a new update.
    Only deletes backups when the base .exe exists (update completed);
    if the base .exe is missing, restores the backup to avoid bricking
    an install after an interrupted update.
    """
    if sys.platform != "win32":
        return
    from workpilot.utils.update import ENTRY_POINTS, scripts_dirs

    for scripts_dir in scripts_dirs():
        if not scripts_dir.is_dir():
            continue
        for name in ENTRY_POINTS:
            exe = scripts_dir / f"{name}.exe"
            stale_files = [scripts_dir / f"{name}{s}" for s in (".exe.old", ".exe.deleteme")]
            stale_files.extend(scripts_dir.glob(f"{name}.exe.old.*"))
            for stale in stale_files:
                if not stale.exists():
                    continue
                if exe.exists():
                    # Base exe present — safe to delete backup
                    try:
                        stale.unlink()
                    except OSError:
                        pass
                else:
                    # Base exe missing — restore backup to recover
                    try:
                        os.rename(stale, exe)
                    except OSError:
                        pass
                    break  # only restore one backup per entry point


def _is_git_install() -> Path | None:
    from workpilot.utils.update import is_git_install

    return is_git_install()


def _is_uv_install() -> bool:
    from workpilot.utils.update import is_uv_install

    return is_uv_install()


def _run(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
    except subprocess.TimeoutExpired:
        console.print(f"[red]Command timed out ({timeout}s):[/red] {' '.join(cmd)}")
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print(f"[red]Command not found:[/red] {cmd[0]}")
        raise typer.Exit(1)


def _git_update(repo: Path, check_only: bool) -> bool:
    """Update from git: fetch, compare, pull, reinstall deps if needed.

    Editable installs don't need exe replacement — git pull updates .py sources
    directly, and pip install -e only rewrites the launcher when entry points
    change (distlib handles locked exes via its own .deleteme logic).
    """
    # Check for dirty working tree
    status_result = _run(["git", "status", "--porcelain"], cwd=repo)
    if status_result.returncode != 0:
        console.print(f"[red]git status failed:[/red]\n{status_result.stderr.strip()}")
        raise typer.Exit(1)
    if status_result.stdout.strip():
        console.print(
            "[yellow]Working tree has uncommitted changes.[/yellow]\n"
            "  Commit or stash them before updating."
        )
        raise typer.Exit(1)

    # Fetch latest
    result = _run(["git", "fetch"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git fetch failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Check for upstream changes
    local_result = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if local_result.returncode != 0:
        console.print(f"[red]git rev-parse HEAD failed:[/red]\n{local_result.stderr.strip()}")
        raise typer.Exit(1)
    local = local_result.stdout.strip()

    remote_result = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if remote_result.returncode != 0:
        console.print(
            "[red]No upstream tracking branch set.[/red]\n"
            "  Set one with: [bold]git branch --set-upstream-to origin/<branch>[/bold]"
        )
        raise typer.Exit(1)
    remote = remote_result.stdout.strip()

    if local == remote:
        console.print("[green]Already up to date![/green]  (no new commits)")
        return False

    # Detect ahead/behind/diverged state
    count_result = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    if count_result.returncode != 0:
        console.print(f"[red]git rev-list failed:[/red]\n{count_result.stderr.strip()}")
        raise typer.Exit(1)
    parts = count_result.stdout.strip().split()
    if len(parts) != 2:
        console.print(f"[red]Unexpected git rev-list output:[/red] {count_result.stdout.strip()}")
        raise typer.Exit(1)
    ahead, behind = int(parts[0]), int(parts[1])

    if behind == 0 and ahead > 0:
        console.print(
            f"[yellow]Local branch is {ahead} commit(s) ahead of upstream.[/yellow]\n"
            "  Nothing to pull. Push your changes or reset to upstream."
        )
        return False

    if ahead > 0 and behind > 0:
        console.print(
            f"[yellow]Branch has diverged:[/yellow] {ahead} ahead, {behind} behind.\n"
            "  Resolve manually (rebase or merge) before updating."
        )
        raise typer.Exit(1)

    # Show what's new (behind > 0, ahead == 0)
    log_result = _run(["git", "log", "--oneline", f"{local}..{remote}"], cwd=repo)
    new_commits = log_result.stdout.strip()
    commit_count = len(new_commits.splitlines()) if new_commits else 0
    console.print(f"[cyan]{commit_count}[/cyan] new commit(s) available:")
    for line in new_commits.splitlines()[:10]:
        console.print(f"  {line}")
    if commit_count > 10:
        console.print(f"  [dim]... and {commit_count - 10} more[/dim]")

    if check_only:
        console.print("\n  Run [bold]wp update[/bold] to pull and install.")
        return False

    # Pull
    console.print("\n[dim]Pulling...[/dim]")
    result = _run(["git", "pull"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git pull failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)
    console.print("[green]Pull complete.[/green]")

    # For editable installs, Python sources are used directly from the repo —
    # git pull alone is sufficient for pure code changes.  Only re-run pip if
    # pyproject.toml changed in the pulled commits (new deps or entry points).
    toml_changed_result = _run(
        ["git", "diff", "--name-only", f"{local}..{remote}", "--", "pyproject.toml"],
        cwd=repo,
    )
    # If the diff command fails (e.g. SHA no longer resolvable), err on the
    # side of caution and assume pyproject.toml may have changed.
    if toml_changed_result.returncode != 0:
        needs_pip = True
    else:
        needs_pip = bool(toml_changed_result.stdout.strip())

    if needs_pip:
        console.print("[dim]pyproject.toml changed — reinstalling dependencies...[/dim]")
        pip_result = _run(
            [sys.executable, "-m", "pip", "install", "-e", ".[all]"],
            cwd=repo,
            timeout=300,
        )
        if pip_result.returncode != 0:
            console.print(f"[red]pip install failed:[/red]\n{pip_result.stderr.strip()}")
            raise typer.Exit(1)
        console.print("[green]Dependencies updated![/green]")

    return True


def _run_capture(cmd: list[str], timeout: int = 240) -> tuple[int, str]:
    """Run *cmd* and return ``(returncode, stderr)``.

    Unlike :func:`_run`, this never raises ``typer.Exit`` — a timeout or
    missing executable surfaces as a sentinel return code so the caller
    can decide whether to abort or try a different strategy.
    """
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        return r.returncode, r.stderr or ""
    except subprocess.TimeoutExpired:
        return -1, f"timeout after {timeout}s: {' '.join(cmd)}"
    except FileNotFoundError:
        # Must come before the bare OSError — FileNotFoundError is a subclass.
        return -2, f"command not found: {cmd[0]}"
    except OSError as e:
        # Everything else subprocess.run can throw (WinError 740 "requires
        # elevation", EACCES, PermissionError, fork failures, ...) — map to a
        # sentinel so the cascade continues instead of raising out of it.
        return -3, f"os error running {' '.join(cmd)}: {e}"


# Specific phrases uv emits when a command is a no-op against an already-installed
# tool. Broad substrings ("no such", "up to date") risk swallowing real errors like
# "no such file or directory" or DNS failures, so we match full uv phrases only.
_BENIGN_STDERR_MARKERS = (
    "error: tool 'workpilot' is already installed",
    'error: tool "workpilot" is already installed',
    "tool 'workpilot' is already installed",
    'tool "workpilot" is already installed',
)


def _is_benign_stderr(stderr: str) -> bool:
    """Classify a cascade step's stderr as non-informative (expected no-op).

    Only suppress uv's known already-installed messages. Genuine failures such
    as missing files, missing hosts, or corrupted caches must still propagate
    to the final ``last_err`` shown in the recovery prompt.
    """
    lower = stderr.lower()
    return any(m in lower for m in _BENIGN_STDERR_MARKERS)


def _log_attempt(method: str, rc: int, stderr: str, pre: str | None, post: str | None) -> None:
    """Append a JSONL record of one cascade step to ``~/.workpilot/update.log``.

    When users report "wp update doesn't work", this is what tells us which
    step died and what the venv version was before/after. Failing to log is
    never fatal — update continues unaffected.
    """
    try:
        from workpilot.utils.helpers import get_data_dir

        log = get_data_dir() / "update.log"
        with log.open("a", encoding="utf-8") as f:
            f.write(
                json.dumps(
                    {
                        "ts": time.time(),
                        "method": method,
                        "rc": rc,
                        "pre": pre,
                        "post": post,
                        "err": stderr[-500:] if stderr else "",
                    }
                )
                + "\n"
            )
    except OSError:
        pass


def _emergency_recover(baseline_version: str) -> str | None:
    """Attempt to restore the pre-update baseline after a cascade step
    corrupted the install. Returns the version the venv ends up at, or
    None if it is still broken.

    *baseline_version* is the version ``probe_via_venv()`` reported before
    the cascade started — not the upgrade target. The caller must pass the
    pre-update version to avoid accidentally re-running the corrupting step.

    Uses ``--force`` (not ``--reinstall``) because our cascade never deletes
    the venv or clears the package cache — a receipt rewrite is sufficient to
    make uv re-lay the files that went missing mid-install.
    """
    from workpilot.utils.update import probe_via_venv

    _run_capture(
        ["uv", "tool", "install", "--force", f"workpilot=={baseline_version}"],
        timeout=300,
    )
    return probe_via_venv()


def _print_recovery(
    target: str,
    current: str | None,
    last_err: str,
    tone: str,
) -> None:
    """Render the end-of-cascade recovery prompt.

    *tone* picks the header and whether option ④ (full uninstall) shows:
      - ``partial``       — a cascade step broke the install but baseline was restored
      - ``stuck``         — all methods ran without breaking anything, just no upgrade
      - ``shim_missing``  — version landed at target but entry-point shim(s) absent
      - ``emergency``     — a cascade step broke the install and recovery also failed
      - ``no_baseline``   — the pre-upgrade probe failed, so no cascade was attempted
    """
    from workpilot.utils.update import find_exe_holders, install_script_cmd

    console.print("")
    if tone == "partial":
        console.print(
            f"[yellow]Upgrade to v{target} did not complete; "
            f"rolled back to v{current or '?'}.[/yellow]"
        )
        console.print("[green]WorkPilot is still usable.[/green]")
    elif tone == "stuck":
        console.print(
            f"[yellow]All uv upgrade methods failed to move v{current or '?'} "
            f"to v{target}.[/yellow]"
        )
        console.print("[green]Current version is still usable.[/green]")
    elif tone == "shim_missing":
        console.print(
            f"[yellow]v{current or target} is installed, but entry-point shim(s) "
            "could not be regenerated.[/yellow]"
        )
        console.print(
            "[green]The installation is present, but command-line entry points may "
            "be unavailable until the shims are repaired.[/green]"
        )
    elif tone == "no_baseline":
        console.print(
            f"[red bold]✗ Cannot proceed with upgrade to v{target} — "
            "unable to verify the current install.[/red bold]"
        )
    else:  # emergency
        console.print(
            f"[red bold]✗ Failed to upgrade to v{target} and recovery failed; "
            "the current install may be corrupted.[/red bold]"
        )
    console.print("")

    holders = find_exe_holders()
    if holders:
        console.print("[dim]Processes currently holding wp.exe / workpilot.exe:[/dim]")
        for pid, name in holders:
            console.print(f"[dim]  • PID {pid:<6} {name}[/dim]")
        console.print("")

    console.print(
        "[bold]In a NEW terminal, try the following in order until the upgrade succeeds:[/bold]"
    )
    console.print("")
    console.print(
        "  [bold cyan]1.[/bold cyan] Close all wp processes (including backgrounded "
        "[dim]workpilot serve[/dim] / [dim]workpilot cloud[/dim] and any VS Code windows), then:"
    )
    console.print("     [bold]wp update[/bold]")
    console.print("")
    console.print(
        "  [bold cyan]2.[/bold cyan] Re-run the one-line install script "
        "(most reliable — also repairs uv / PATH):"
    )
    console.print(f"     [bold]{install_script_cmd()}[/bold]")
    console.print("")
    console.print("  [bold cyan]3.[/bold cyan] Reinstall with uv directly:")
    console.print(f"     [bold]uv tool install --force --reinstall workpilot=={target}[/bold]")
    console.print("")

    if tone in ("emergency", "no_baseline"):
        console.print("  [bold cyan]4.[/bold cyan] Full uninstall + reinstall:")
        console.print("     [bold]uv tool uninstall workpilot[/bold]")
        console.print("     [bold]uv tool install workpilot[/bold]")
        console.print("")

    if last_err:
        console.print(f"[dim]Last error:\n{last_err[-800:]}[/dim]")
        console.print("")


def _uv_update(check_only: bool) -> bool:
    """Update via a 4-method ``uv tool`` cascade with venv-probe verification.

    The cascade tries progressively less-cached / more-forceful commands.
    After each step we probe the venv (not the wp.exe shim) to see what
    version actually landed on disk; a post-probe of None signals the step
    corrupted the install and we trigger an emergency rollback to baseline.

    Guarantees: when this returns or raises, either the new version is
    installed *or* the old version still runs. The only "no usable version"
    case is an emergency + failed recovery, which surfaces as ``_print_recovery``
    with tone=``emergency`` and exit 1.
    """
    from workpilot.utils.update import (
        check_uv,
        parse_version,
        probe_via_venv,
        uv_bin_dir,
    )

    # Compute once — uv_bin_dir() shells out to `uv tool dir --bin` each call.
    bin_dir = uv_bin_dir() if sys.platform == "win32" else None

    console.print("[dim]Checking for updates...[/dim]")
    status = check_uv()

    if status.error:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Update manually: [bold]uv tool upgrade workpilot[/bold]"
        )
        raise typer.Exit(1)

    if status.up_to_date:
        # The installed version is the source of truth for any shim repair —
        # using status.latest would downgrade a pre-release/dev build whose
        # __version__ is ahead of PyPI. Fall back to __version__ only when the
        # venv probe fails (uv not on PATH, venv corrupted, etc.).
        installed = probe_via_venv() or __version__
        latest_display = str(status.latest or installed)
        missing = _missing_shims(bin_dir)
        if missing and not check_only:
            console.print(
                f"[yellow]v{installed} is current, but entry-point shim(s) missing: "
                f"{', '.join(missing)} — regenerating via --force...[/yellow]"
            )
            return _uv_repair_shims(installed)
        console.print(f"[green]Already up to date![/green]  (latest: v{latest_display})")
        return False

    latest = str(status.latest)
    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]wp update[/bold] to install it.")
        return False

    # Baseline: what the venv *currently* has, verified by actually importing.
    # None can mean the install is broken, uv is not on PATH, or the venv
    # python can't be located — we can't tell the difference here, so the
    # recovery prompt must cover both cases (re-run the install script
    # repairs uv / PATH; full uninstall+install repairs a corrupted venv).
    baseline = probe_via_venv()
    if baseline is None:
        console.print(
            "[yellow]Baseline probe via the uv tool venv failed.[/yellow]\n"
            "  [dim]This can mean the install is corrupted, uv is not on "
            "PATH, or the venv python cannot be reached.[/dim]"
        )
        _print_recovery(latest, None, "", tone="no_baseline")
        raise typer.Exit(1)

    console.print(f"[dim]Baseline: v{baseline} (working)[/dim]")

    methods: list[tuple[str, list[str]]] = [
        ("upgrade", ["uv", "tool", "upgrade", "workpilot"]),
        ("install@latest", ["uv", "tool", "install", "workpilot@latest"]),
        (
            "install --refresh ==latest",
            ["uv", "tool", "install", "--refresh", f"workpilot=={latest}"],
        ),
        (
            "install --force ==latest",
            ["uv", "tool", "install", "--force", f"workpilot=={latest}"],
        ),
    ]

    pre = baseline
    last_err = ""
    for name, cmd in methods:
        console.print(f"[dim]Method: {name} — {' '.join(cmd)}[/dim]")
        rc, stderr = _run_capture(cmd, timeout=240)
        post = probe_via_venv()
        _log_attempt(name, rc, stderr, pre, post)

        # Step corrupted the install — recover to baseline and stop.
        if post is None:
            console.print(f"[red]× {name} left install non-functional — recovering...[/red]")
            recovered = _emergency_recover(baseline)
            if recovered:
                console.print(f"[green]✓ Recovered to v{recovered}.[/green]")
                _print_recovery(latest, recovered, stderr, tone="partial")
                # Exit 1: the requested upgrade did not happen. Matches the
                # pip/git paths, keeps automation reliable.
                raise typer.Exit(1)
            console.print("[red]× Recovery failed.[/red]")
            _print_recovery(latest, None, stderr, tone="emergency")
            raise typer.Exit(1)

        # Step upgraded us to (or past) the target.  Also verify all expected
        # entry-point shims exist — older ``uv tool upgrade`` updates the
        # package code but doesn't re-scan entry_points, so a newly-added
        # console script can land without a shim. Keep cascading so the later
        # ``--force`` step regenerates them.
        if parse_version(post) >= parse_version(latest):
            missing = _missing_shims(bin_dir)
            if not missing:
                console.print(f"[green]✓ Updated to v{post} (via {name}).[/green]")
                return True
            console.print(
                f"[yellow]  → v{post} but shim(s) missing: {', '.join(missing)}"
                " — trying next method to regenerate[/yellow]"
            )
            pre = post
            continue

        # Step was a no-op / expected error — try the next method.
        console.print(f"[dim]  → still v{post}, trying next method[/dim]")
        if stderr and not _is_benign_stderr(stderr):
            last_err = stderr[-1500:]
        pre = post

    # Exhausted all methods. Differentiate: did the version never move, or
    # did it move but the shim never got written?
    final_missing = _missing_shims(bin_dir)
    if parse_version(pre) >= parse_version(latest) and final_missing:
        console.print(
            f"[red]× v{pre} installed, but shim(s) still missing after every method: "
            f"{', '.join(final_missing)}.[/red]"
        )
        _print_recovery(latest, pre, last_err, tone="shim_missing")
        raise typer.Exit(1)

    # Exit 1 because the requested upgrade did not happen; scripts that chain
    # `wp update && wp foo` should not proceed on an un-upgraded install.
    _print_recovery(latest, pre, last_err, tone="stuck")
    raise typer.Exit(1)


def _uv_repair_shims(target: str) -> bool:
    """Regenerate missing uv tool shims in-place via ``uv tool install --force``.

    Fires when the installed version is already *target* but one or more
    ``ENTRY_POINTS`` shims are missing — typically after a cross-version
    ``uv tool upgrade`` that added a new console script.

    Returns False when shims were regenerated without changing the installed
    version (callers should not treat this as an update).  Returns True when
    the unpinned fallback changed the installed version (callers should treat
    this as an update, e.g. show the restart-server reminder).  Raises
    ``typer.Exit(1)`` if the shim is still missing after all attempts.
    """
    from workpilot.utils.update import probe_via_venv, uv_bin_dir

    bin_dir = uv_bin_dir() if sys.platform == "win32" else None

    cmd = ["uv", "tool", "install", "--force", f"workpilot=={target}"]
    console.print(f"[dim]{' '.join(cmd)}[/dim]")
    rc, stderr = _run_capture(cmd, timeout=240)
    post = probe_via_venv()
    _log_attempt("shim-repair --force", rc, stderr, target, post)

    still_missing = _missing_shims(bin_dir)
    if post is not None and not still_missing:
        console.print("[green]✓ Shim(s) regenerated.[/green]")
        return False

    # Pinned install failed (e.g. local/dev version not on PyPI) — try unpinned
    if rc != 0 and still_missing:
        cmd_fallback = ["uv", "tool", "install", "--force", "workpilot"]
        console.print(f"[dim]Pinned repair failed; trying unpinned: {' '.join(cmd_fallback)}[/dim]")
        rc2, stderr2 = _run_capture(cmd_fallback, timeout=240)
        post = probe_via_venv()
        _log_attempt("shim-repair --force (unpinned)", rc2, stderr2, target, post)
        still_missing = _missing_shims(bin_dir)
        if post is not None and not still_missing:
            if post != target:
                console.print(
                    f"[yellow]⚠ Shim(s) regenerated, but version changed: "
                    f"v{target} → v{post}.[/yellow]"
                )
            else:
                console.print("[green]✓ Shim(s) regenerated.[/green]")
            return post != target  # True if version changed (treat as update)
        if stderr2 and not _is_benign_stderr(stderr2):
            stderr = stderr2

    if still_missing:
        console.print(
            f"[red]× Shim(s) still missing after --force: {', '.join(still_missing)}.[/red]"
        )
        # Version is still valid, we just couldn't rewrite the shim — tell the
        # user the install works under its full name and point them at the
        # standard remediation list.
        _print_recovery(target, post or target, stderr, tone="shim_missing")
    else:
        console.print("[red]× --force left the install non-functional.[/red]")
        _print_recovery(target, post, stderr, tone="emergency")
    raise typer.Exit(1)


def _pypi_update(check_only: bool) -> bool:
    """Update from PyPI: check latest version, pip install --upgrade.

    On Windows, pip may fail to replace locked entry-point exes.  Same
    tolerant pattern as ``_uv_update`` — verify the installed version and
    report accordingly.
    """
    from workpilot.utils.update import check_pypi, get_pip_installed_version, parse_version

    console.print("[dim]Checking PyPI...[/dim]")
    status = check_pypi()

    if status.error:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Update manually: [bold]pip install --upgrade workpilot[/bold]"
        )
        raise typer.Exit(1)

    if status.up_to_date:
        # Installed version drives the reinstall hint — status.latest is the
        # PyPI latest, which could be *older* than a locally built/dev version.
        # Using it would nudge the user to downgrade.
        installed = str(get_pip_installed_version() or __version__)
        latest_display = str(status.latest or installed)
        _pypi_warn_if_missing_shims(installed)
        console.print(f"[green]Already up to date![/green]  (latest: v{latest_display})")
        return False

    latest = status.latest
    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]wp update[/bold] to install it.")
        return False

    console.print("[dim]Upgrading...[/dim]")

    # 300s, matching the git path's pip install -e step. The old 120s was
    # below the threshold to download claude-agent-sdk (78 MB win_amd64
    # wheel with bundled Node) + github-copilot-sdk (54 MB) on every
    # meaningful workpilot bump behind a corporate proxy — and a killed pip
    # mid-uninstall/install leaves site-packages with no workpilot at all.
    pip_result = _run(
        [sys.executable, "-m", "pip", "install", "--upgrade", f"workpilot=={latest}"],
        timeout=300,
    )

    if pip_result.returncode == 0:
        actual = get_pip_installed_version()
        if actual and parse_version(actual) >= parse_version(str(latest)):
            if not _verify_pip_import(actual, str(latest)):
                raise typer.Exit(1)
            console.print(f"[green]Updated to v{actual}![/green]")
            _pypi_warn_if_missing_shims(actual)
            return True
        console.print(
            "[yellow]Upgrade finished, but the installed version could not be verified "
            f"at v{latest}.[/yellow]\n"
            f"  Detected version: [bold]{actual or 'unknown'}[/bold]\n"
            "  Please rerun [bold]wp update[/bold] or update manually with "
            "[bold]pip install --upgrade workpilot[/bold]."
        )
        raise typer.Exit(1)

    # Non-zero exit — on Windows, check if it's just a locked-exe issue
    if sys.platform == "win32" and _is_entrypoint_lock_error(pip_result.stderr):
        actual = get_pip_installed_version()
        if actual and parse_version(actual) >= parse_version(str(latest)):
            if not _verify_pip_import(actual, str(latest)):
                raise typer.Exit(1)
            console.print(
                f"[green]Updated to v{actual}![/green]\n"
                "  [dim]Entry-point exe not refreshed (locked by current process).\n"
                "  This is harmless — the update is installed and will take "
                "effect next time you run [bold]wp[/bold].[/dim]"
            )
            _pypi_warn_if_missing_shims(actual)
            return True

    console.print(f"[red]Update failed:[/red]\n{pip_result.stderr.strip()}")
    raise typer.Exit(1)


def _verify_pip_import(metadata_version: str, target: str) -> bool:
    """Check that a fresh subprocess can actually ``import workpilot``.

    Called after pip's metadata (``pip show``) confirms the upgrade. Catches
    the case where pip wrote dist-info before all package files landed — kill
    mid-install, transient lock on a native binary in claude-agent-sdk /
    github-copilot-sdk, --user / system site-packages mismatch — leaving
    ``pip show`` happy while the next ``wp`` launch hits ModuleNotFoundError.

    On failure prints a red error with a recovery one-liner and returns False;
    the caller should then ``raise typer.Exit(1)``. Returns True when the
    subprocess imports the same version reported by pip metadata
    (``metadata_version``).
    """
    probed = _probe_workpilot_import()
    if probed is not None and probed == metadata_version:
        return True

    if probed is None:
        console.print(
            f"[red]pip metadata says v{metadata_version} but "
            "`import workpilot` fails in a fresh subprocess.[/red]"
        )
        console.print(
            "  pip's install is half-applied. Recover from a fresh shell "
            "(close all running wp processes first):\n"
            f"  [bold]{sys.executable} -m pip install --upgrade --force-reinstall workpilot=={target}[/bold]"
        )
    else:
        # Import succeeds but reports a different version — a stale older
        # copy is shadowing the new install (--user vs system, multiple
        # Pythons, leftover ``__pycache__`` from another version on a
        # parallel sys.path, or a prerelease like 0.18.0rc1 that
        # parse_version's digit-extraction would misorder vs 0.18.0).
        console.print(
            f"[red]pip metadata says v{metadata_version} but "
            f"`import workpilot` reports v{probed}.[/red]"
        )
        console.print(
            "  Another workpilot install is shadowing the new one "
            "(--user vs system site-packages, multiple Pythons, etc.).\n"
            "  Recover from a fresh shell (close all running wp processes first):\n"
            f"  [bold]{sys.executable} -m pip install --upgrade --force-reinstall workpilot=={target}[/bold]"
        )
    return False


def _pypi_warn_if_missing_shims(version: str) -> None:
    """Warn when pip reported success but one of the ENTRY_POINTS shims is absent.

    Distinct from :func:`_verify_pip_import`: that one catches "package files
    missing"; this catches "package files present + import works, but the
    console-script .exe shim never landed". Happens when the wheel install
    aborted on a locked ``workpilot.exe`` after the package extracted but
    before the new ``wp.exe`` was written. ``pip show`` is satisfied,
    ``import workpilot`` works — the next ``wp <subcommand>`` is "command
    not found" instead.
    """
    import sysconfig

    from workpilot.utils.update import pip_scripts_dir

    scripts_dir = pip_scripts_dir()
    if scripts_dir is None:
        try:
            raw = sysconfig.get_path("scripts")
            scripts_dir = Path(raw) if raw else None
        except Exception:
            scripts_dir = None

    missing = _missing_shims(scripts_dir)
    if not missing:
        return
    console.print(
        f"[yellow]Note: entry-point shim(s) missing — {', '.join(missing)}.[/yellow]\n"
        "  Close all [bold]workpilot[/bold] / [bold]wp[/bold] processes and rerun.\n"
        "  Try the exact-version reinstall first:\n"
        f"  [bold]{sys.executable} -m pip install --force-reinstall workpilot=={version}[/bold]\n"
        "  If that version is not available on PyPI (for example, a local/dev build), use:\n"
        f"  [bold]{sys.executable} -m pip install --upgrade --force-reinstall workpilot[/bold]"
    )


@app.command(name="update")
def update(
    check: bool = typer.Option(False, "--check", help="Only check for updates, don't install"),
) -> None:
    """Update WorkPilot to the latest version."""

    console.print(f"Current version: [bold]v{__version__}[/bold]")

    # Clean up leftover .old/.deleteme from previous versions that used
    # the old rename-based approach.  Skip during --check to keep it read-only.
    if not check:
        cleanup_old_exes()

    repo = _is_git_install()
    if repo:
        console.print(f"Install mode:    [cyan]git[/cyan]  ({repo})")
        updated = _git_update(repo, check)
    elif _is_uv_install():
        console.print("Install mode:    [cyan]uv[/cyan]")
        updated = _uv_update(check)
    else:
        console.print("Install mode:    [cyan]pypi[/cyan]")
        updated = _pypi_update(check)

    # Remind to restart if web server is running and we actually updated
    if updated:
        from workpilot.cli.commands import _check_web_running

        running = _check_web_running()
        if running:
            pid, port = running
            console.print(
                f"\n[yellow]Web server is running (PID {pid}, port {port}).[/yellow]\n"
                "  Restart it to use the new version."
            )


# "upgrade" is a hidden alias — keeps the same convention as other aliases in commands.py
app.command("upgrade", hidden=True)(update)
