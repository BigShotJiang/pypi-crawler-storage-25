"""workpilot chat — interactive agent REPL, with web server attach support."""

from __future__ import annotations

import asyncio
from typing import Any

import typer

from workpilot.channels.cli import console
from workpilot.runtime import Runtime

# ── Approval rendering for WS-attach REPL ─────────────────────────────────────

_RISK_COLORS = {
    "low": "green",
    "medium": "yellow",
    "elevated": "yellow",
    "high": "red",
    "critical": "red",
}


def _render_ws_approval_request(data: dict) -> None:
    """Render an approval_request frame as a readable CLI prompt."""
    from rich.markup import escape as _esc

    tool = data.get("tool_name", "?")
    preview = data.get("action_preview", tool)
    level = data.get("risk_level", "unknown")
    score = data.get("score")
    reason = data.get("reason", "")
    auto = data.get("auto_timeout")
    reject = data.get("reject_timeout")
    always = data.get("always_allow", True)

    color = _RISK_COLORS.get(level, "yellow")
    score_str = f"{score}/10" if score is not None else "?/10"

    console.print()
    console.print(
        f"  [bold yellow]⚠  APPROVAL REQUIRED[/bold yellow]  [{color}]{level.upper()} {score_str}[/{color}]"
    )
    console.print(f"  [bold]{_esc(preview)}[/bold]")
    if reason:
        console.print(f"  [dim]{_esc(reason)}[/dim]")
    if auto:
        console.print(f"  [dim]Auto-approve in {auto}s unless denied[/dim]")
    elif reject:
        console.print(f"  [dim]Waiting {reject}s for your decision[/dim]")
    always_hint = "  \\[a]lways" if always else ""
    console.print(f"  → \\[y]es  \\[n]o{always_hint}")
    console.print()


def _render_ws_approval_resolved(data: dict) -> None:
    """Render an approval_resolved frame."""
    outcome = data.get("status", data.get("outcome", data.get("action", "resolved")))
    tool = data.get("tool_name", "")
    labels = {
        "approved": "✅ Approved",
        "approved_always": "✅ Approved (Always)",
        "approved_timeout": "✅ Approved (Auto)",
        "denied": "❌ Denied",
        "denied_timeout": "❌ Denied (Timeout)",
    }
    label = labels.get(outcome, f"✅ {outcome}")
    suffix = f" — {tool}" if tool else ""
    console.print(f"  {label}{suffix}")


def _approval_prompt(allow_always: bool = True) -> str:
    """Interactive approval prompt — arrow keys / tab to select, enter to confirm."""
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.completion import WordCompleter
        from prompt_toolkit.formatted_text import HTML

        choices = ["yes", "no"]
        if allow_always:
            choices.append("always")
        completer = WordCompleter(choices, sentence=True)
        session: PromptSession[str] = PromptSession(
            HTML("  <b>&gt;</b> "),
            completer=completer,
            complete_while_typing=True,
        )
        return session.prompt().strip() or "n"
    except ImportError:
        return input("  > ").strip() or "n"


# ── Web server auth resolution ────────────────────────────────────────────────


def _resolve_web_auth(rt: Runtime) -> dict[str, str]:
    """Return WebSocket headers for web server auth.

    Priority: api_key > Entra token (web server config) > empty.
    """
    web_cfg = rt.config.channels.web
    if web_cfg.api_key:
        return {"X-API-Key": web_cfg.api_key.get_secret_value()}

    # Gate on gateway's own Entra config, not cloud channel defaults
    if web_cfg.entra_tenant_id and web_cfg.entra_client_id:
        try:
            from workpilot.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id=web_cfg.entra_tenant_id,
                client_id=web_cfg.entra_client_id,
            )
            if token:
                return {"Authorization": f"Bearer {token}"}
            console.print(
                "[yellow]Entra ID login cancelled or failed — connecting without auth.[/yellow]"
            )
        except Exception as exc:
            console.print(f"[yellow]Entra ID auth failed: {exc}[/yellow]")

    return {}


# ── WebSocket REPL (attach to running web server) ────────────────────────────


async def _ws_chat_repl(port: int, *, auth_headers: dict[str, str] | None = None) -> None:
    """Connect to a running web server via WebSocket and run an interactive REPL."""
    import json as _json

    import websockets  # type: ignore[import]

    # ?sender_id=cli-user advertises this connection's identity at handshake
    # time so the server can return the right bridge state (local_cli for
    # the CLI, local_web for browsers). Matches the sender_id the CLI
    # sends on every message below (kept in sync so the server resolves
    # the SAME canonical session id in both places).
    url = f"ws://localhost:{port}/api/ws?sender_id=cli-user"
    console.print(
        f"[dim]Connected to running web server (port {port}). "
        f"Type /new to clear session, Ctrl+C to exit.[/dim]\n"
    )
    # Reuse prompt_toolkit session for history + autocomplete (fallback to input())
    try:
        import os

        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import FileHistory

        from workpilot.channels.cli import _SlashCompleter
        from workpilot.utils.helpers import get_data_dir

        _history_path = get_data_dir() / "cli_history"
        if os.name == "posix":
            try:
                if not _history_path.exists():
                    fd = os.open(_history_path, os.O_CREAT | os.O_WRONLY, 0o600)
                    os.close(fd)
                else:
                    os.chmod(_history_path, 0o600)
            except OSError:
                pass
        from prompt_toolkit.formatted_text import HTML
        from prompt_toolkit.styles import Style as PTStyle

        _prompt_html = HTML("<style fg='#5fafaf'>you&gt;</style> ")
        _input_style = PTStyle.from_dict({"": "bold #5fafaf"})
        _ws_session: PromptSession[str] = PromptSession(
            _prompt_html,
            style=_input_style,
            completer=_SlashCompleter(),
            complete_while_typing=True,
            history=FileHistory(str(_history_path)),
        )
        _get_input = lambda: _ws_session.prompt()  # noqa: E731
    except ImportError:
        console.print("[dim](basic input mode — autocomplete/history unavailable)[/dim]")
        _get_input = lambda: input("you> ")  # noqa: E731

    async with websockets.connect(url, additional_headers=auth_headers or {}) as ws:
        # Drain the connected handshake before accepting user input.
        # Server includes ``bridge_state`` here so a reconnect after a
        # /bridge toggle restores the status banner without waiting for
        # the first round-trip.
        try:
            first_raw = await asyncio.wait_for(ws.recv(), timeout=3.0)
            first = _json.loads(first_raw)
            if first.get("type") == "connected":
                my_bridge = first.get("bridge_state")
                if my_bridge:
                    target = my_bridge.get("target") or ""
                    label = {"claude": "Claude Code", "copilot": "GitHub Copilot"}.get(
                        target, target
                    )
                    console.print(
                        f"[bold yellow]▸ Bridged to {label}[/bold yellow] "
                        "[dim](type /bridge off to exit)[/dim]\n"
                    )
        except (TimeoutError, _json.JSONDecodeError):
            # No handshake or malformed — proceed. Bridge state (if any)
            # will surface once the first message round-trips.
            pass

        while True:
            try:
                prompt = await asyncio.get_running_loop().run_in_executor(None, _get_input)
            except (EOFError, KeyboardInterrupt):
                break

            if not prompt.strip():
                continue

            # Slash commands handled locally
            if prompt.strip() == "/exit":
                break

            # sender_id ``cli-user`` pairs with SessionManager._normalize_id's
            # mapping ``web_cli-user → local_cli`` so this attach-mode REPL
            # shares the same canonical session as native ``workpilot chat``
            # — history, bridge state, Always-Allow cache all carry over.
            # Browser connections still default to ``web-user`` → local_web.
            await ws.send(
                _json.dumps(
                    {"prompt": prompt, "sender_id": "cli-user"},
                    ensure_ascii=False,
                )
            )

            from workpilot.channels.cli import start_thinking, stop_thinking

            start_thinking()

            streaming = False
            first_output = True
            try:
                while True:
                    try:
                        data = _json.loads(await ws.recv())
                    except KeyboardInterrupt:
                        # Ctrl+C during agent run → send /cancel to interrupt
                        console.print("[dim]Interrupting...[/dim]")
                        await ws.send(
                            _json.dumps(
                                {"prompt": "/cancel", "sender_id": "cli-user"},
                                ensure_ascii=False,
                            )
                        )
                        continue
                    dtype = data.get("type")

                    # Stop spinner on first *final* output (token stream or response).
                    # Tool/commentary chunks render above the spinner via Rich Live,
                    # so the spinner keeps running to show the tool name label.
                    if first_output and dtype in ("response", "error", "approval_request"):
                        stop_thinking()
                        first_output = False
                    elif first_output and dtype == "chunk":
                        chunk_type = data.get("chunk_type", "token")
                        if chunk_type not in (
                            "tool_start",
                            "tool_end",
                            "tool_progress",
                            "commentary",
                            "status",
                        ):
                            stop_thinking()
                            first_output = False

                    if dtype == "response":
                        content = data.get("content", "")
                        # Approval resolution short-acks — don't break,
                        # agent continues and the real response follows.
                        if content in ("Tool call approved.", "Tool call denied."):
                            console.print(f"  [dim]{content}[/dim]")
                            if "denied" in content:
                                break  # agent won't produce more output
                            continue  # wait for the real response

                        if streaming:
                            console.print()
                            streaming = False
                        from rich.markdown import Markdown

                        bt = data.get("bridge_target")
                        if bt:
                            console.print(f"[bold cyan]{bt}>[/bold cyan]", end=" ")
                        console.print(Markdown(content))
                        break
                    elif dtype == "chunk":
                        from workpilot.channels.cli import (
                            render_commentary,
                            render_tool_end,
                            render_tool_start,
                        )

                        chunk_content = data.get("content", "")
                        chunk_type = data.get("chunk_type", "token")
                        done = bool(data.get("done"))

                        if chunk_type == "tool_start":
                            render_tool_start(chunk_content)
                        elif chunk_type == "tool_end":
                            render_tool_end(chunk_content)
                        elif chunk_type == "commentary":
                            render_commentary(chunk_content)
                        elif chunk_type in ("tool_progress", "status"):
                            pass  # suppress noise
                        elif chunk_content:
                            from rich.markup import escape as _esc

                            if not streaming:
                                console.print()
                                bt = data.get("bridge_target")
                                if bt:
                                    console.print(f"[bold cyan]{bt}>[/bold cyan] ", end="")
                                streaming = True
                            console.print(
                                f"[bold]{_esc(chunk_content)}[/bold]", end="", highlight=False
                            )

                        if done and streaming:
                            console.print()
                            streaming = False
                    elif dtype == "push":
                        console.print(f"[dim][push] {data.get('content', '')}[/dim]")
                    elif dtype == "approval_request":
                        _render_ws_approval_request(data)
                        always_allow = data.get("always_allow", True)
                        # Interactive approval prompt
                        try:
                            from functools import partial

                            answer = await asyncio.get_running_loop().run_in_executor(
                                None,
                                partial(_approval_prompt, always_allow),
                            )
                            await ws.send(
                                _json.dumps(
                                    {"prompt": answer, "sender_id": "cli-user"},
                                    ensure_ascii=False,
                                )
                            )
                            # Agent continues after approval — restart spinner
                            start_thinking()
                            first_output = True
                        except (EOFError, KeyboardInterrupt):
                            pass  # timeout / policy will resolve
                    elif dtype == "approval_resolved":
                        _render_ws_approval_resolved(data)
                    elif dtype == "error":
                        code = data.get("code", "")
                        msg = data.get("message") or data.get("content") or "(no detail)"
                        friendly = {
                            "empty_prompt": "Please enter a message.",
                            "rate_limited": "Too many requests. Please wait.",
                            "auth_expired": "Session expired. Please sign in again.",
                            "response_timeout": "Agent did not respond in time.",
                            "agent_offline": "Agent is offline. Please start WorkPilot.",
                        }.get(code, msg)
                        if streaming:
                            console.print()
                            streaming = False
                        console.print(f"[red]{friendly}[/red]")
                        break
                    elif "error" in data:
                        console.print(f"[red]{data['error']}[/red]")
                        break
            finally:
                stop_thinking()


# ── Command entry point ──────────────────────────────────────────────────────


def chat(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Start an interactive agent REPL session.

    If 'workpilot serve' is already running, connects to it directly instead
    of starting a new Runtime instance.
    """
    from workpilot.cli.commands import _check_web_running, _get_runtime

    running = _check_web_running()
    if running:
        _, port = running
        console.print(f"[dim]Web server running on port {port} — connecting...[/dim]")
        try:
            rt = _get_runtime(config, profile)
            headers = _resolve_web_auth(rt)
            asyncio.run(_ws_chat_repl(port, auth_headers=headers))
        except KeyboardInterrupt:
            pass
        except Exception as exc:
            console.print(f"[red]Web server connection failed:[/red] {exc}")
            raise typer.Exit(1)
        console.print("\nGoodbye!")
        return

    try:
        rt = _get_runtime(config, profile)
        # Direct mode: redirect logs from stderr to file so they don't
        # interleave with the REPL output. The log file is written to
        # ~/.workpilot/logs/chat.log.
        _redirect_logs_to_file(rt)
        asyncio.run(rt.run_chat())
    except KeyboardInterrupt:
        console.print("\nGoodbye!")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


def _redirect_logs_to_file(rt: Runtime) -> None:
    """Replace the stderr log sink with a file sink for direct chat.

    Preserves any user-configured file sink and respects logging.format.
    """
    from loguru import logger

    from workpilot.utils.helpers import get_data_dir

    log_path = get_data_dir() / "logs" / "chat.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    import os

    level = rt.config.logging.level.value
    use_json = rt.config.logging.format == "json"

    # Remove all sinks (including stderr set by _setup_logging)
    logger.remove()

    # Re-add the user-configured file sink if present (preserve format)
    if rt.config.logging.file:
        logger.add(
            rt.config.logging.file,
            level=level,
            rotation="10 MB",
            serialize=use_json,
        )

    # Add chat-specific file sink (respects logging.format)
    sink_kwargs: dict[str, Any] = {
        "level": level,
        "rotation": "10 MB",
        "retention": 3,
    }
    if use_json:
        sink_kwargs["serialize"] = True
    else:
        sink_kwargs["format"] = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
    logger.add(str(log_path), **sink_kwargs)

    # Restrict permissions after loguru creates the file (POSIX only)
    if os.name == "posix":
        try:
            os.chmod(log_path, 0o600)
        except OSError:
            pass
