from __future__ import annotations

from abc import abstractmethod
from typing import TYPE_CHECKING, Protocol, Self, final, runtime_checkable

from flowcean.core.named import Named
from flowcean.core.transform import Identity, Transform

if TYPE_CHECKING:
    from flowcean.core.data import Data


@runtime_checkable
class Environment(Named, Protocol):
    """Abstraction for data sources in learning and evaluation.

    An environment describes the possible data sources for the learning and
    evaluation procedure. Environments can be offline (pre-recorded datasets),
    incremental (streaming data), or active (interactive systems where the
    learner can influence the environment). All environments support applying
    transforms to observations.
    """

    transform: Transform = Identity()

    def append_transform(
        self,
        transform: Transform,
    ) -> Self:
        """Append a transform to the observation.

        Args:
            transform: Transform to append.

        Returns:
            This observable with the appended transform.
        """
        self.transform = self.transform.chain(transform)
        return self

    @abstractmethod
    def _observe(self) -> Data:
        """Observe and return the observation without applying the transform.

        This method must be implemented by subclasses.

        Returns:
            The raw observation.
        """

    def observe(self) -> Data:
        """Observe and return the observation."""
        return self.transform(self._observe())

    @final
    def __or__(
        self,
        transform: Transform,
    ) -> Self:
        """Shortcut for `with_transform`."""
        return self.append_transform(transform)
