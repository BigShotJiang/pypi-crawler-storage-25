"""``flow pricing stats`` subcommand.

Per-market price statistics: week-over-week comparison, day-of-week and
hour-of-day seasonality, peak/slow days, and volatility trend. Uses the
duration-weighted primitives in :mod:`flow.domain.pricing.insights` so the
view stays numerically consistent with the default ``flow pricing`` view.

Invocation is keyed by ``(gpu, region, gpu_count)`` — each GPU count tier
is a distinct market. Fails closed (exit 1) when no history is found for
the requested market rather than rendering empty panels.
"""

import json
from datetime import datetime, timezone
from typing import Any

import click
from rich.console import Console

from flow.cli.commands._pricing_data import (
    _fetch_instance_type_map,
    _fetch_price_history,
    _resolve_api_context,
)
from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.table_styles import (
    add_left_aligned_column,
    add_right_aligned_column,
    create_flow_table,
    wrap_table_in_panel,
)
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.telemetry import Telemetry
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.pricing.insights import (
    DayStat,
    HourStat,
    PriceTrend,
    VolatilitySummary,
    WeekdayStat,
    WeekOverWeekResult,
    bucket_by_day,
    bucket_by_hour,
    bucket_by_weekday,
    compute_price_trend,
    volatility_summary,
    week_over_week_compare,
)

# Unicode block characters for sparkline/bar rendering (lightest to heaviest).
_BAR_BLOCKS: tuple[str, ...] = (
    "\u2581",
    "\u2582",
    "\u2583",
    "\u2584",
    "\u2585",
    "\u2586",
    "\u2587",
    "\u2588",
)

# Weekday/hour buckets with fewer than this many covered hours are rendered
# as "insufficient data" — avoids misleading single-sample means.
_MIN_HOURS_FOR_DISPLAY: float = 4.0

# Number of cheapest/most-expensive calendar days to surface in the Rich panel.
_PEAK_SLOW_K: int = 3


def _format_price(value: float | None) -> str:
    """Render a USD/hr price as ``$X.XX``; ``-`` when missing."""
    if value is None or value <= 0:
        return "-"
    return f"${value:.2f}"


def _format_delta_abs(value: float | None) -> str:
    """Render an absolute price delta with an explicit sign; ``-`` when missing."""
    if value is None:
        return "-"
    sign = "+" if value >= 0 else "-"
    return f"{sign}${abs(value):.2f}"


def _format_delta_pct(value: float | None) -> str:
    """Render a percentage delta with an explicit sign; ``-`` when missing."""
    if value is None:
        return "-"
    sign = "+" if value >= 0 else "-"
    return f"{sign}{abs(value):.1f}%"


def _bar_for(value: float, max_value: float) -> str:
    """Map ``value`` to a single block-character bar proportional to ``max_value``."""
    if max_value <= 0 or value <= 0:
        return _BAR_BLOCKS[0]
    ratio = min(1.0, value / max_value)
    idx = min(len(_BAR_BLOCKS) - 1, int(ratio * (len(_BAR_BLOCKS) - 1) + 0.5))
    return _BAR_BLOCKS[idx]


def _sparkline(values: list[float], mask: list[bool]) -> str:
    """Render a sparkline of ``values``; masked-out positions render as a middle dot."""
    if not values:
        return ""
    visible = [v for v, ok in zip(values, mask, strict=True) if ok and v > 0]
    max_value = max(visible) if visible else 0.0
    chars: list[str] = []
    for value, ok in zip(values, mask, strict=True):
        if not ok or value <= 0:
            chars.append("\u00b7")
            continue
        chars.append(_bar_for(value, max_value))
    return "".join(chars)


def _render_wow_panel(result: WeekOverWeekResult, target_console: Console) -> None:
    """Render the two-row week-over-week comparison panel."""
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")
    table = create_flow_table(title=None, show_borders=True, padding=1)
    add_left_aligned_column(table, "Window", style=accent)
    add_right_aligned_column(table, "This Wk")
    add_right_aligned_column(table, "Last Wk")
    add_right_aligned_column(table, "\u0394 ($)")
    add_right_aligned_column(table, "\u0394 (%)")

    star = "*" if result.significant_overlap else ""
    table.add_row(
        "Overlapping (Mon\u2013now)",
        _format_price(result.this_wk_overlap),
        _format_price(result.last_wk_overlap),
        f"{_format_delta_abs(result.delta_overlap_abs)}{star}",
        f"{_format_delta_pct(result.delta_overlap_pct)}{star}",
    )
    table.add_row(
        "Full week (Mon\u2013Sun last)",
        _format_price(result.this_wk_full),
        _format_price(result.last_wk_full),
        _format_delta_abs(result.delta_full_abs),
        _format_delta_pct(result.delta_full_pct),
    )
    wrap_table_in_panel(table, "Week over Week", target_console)
    if result.significant_overlap:
        target_console.print(f"[{muted}]* delta exceeds 7d volatility band[/{muted}]")


def _render_weekday_panel(stats: list[WeekdayStat], target_console: Console) -> None:
    """Render the 7-row weekday seasonality panel."""
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")

    table = create_flow_table(title=None, show_borders=True, padding=1)
    add_left_aligned_column(table, "Day", style=accent)
    add_right_aligned_column(table, "Mean")
    add_left_aligned_column(table, "Bar")
    add_right_aligned_column(table, "\u0394 vs avg")

    displayable = [s for s in stats if s.hours_covered >= _MIN_HOURS_FOR_DISPLAY and s.mean > 0]
    if not displayable:
        table.add_row("\u2014", "-", "-", "[dim]insufficient data[/dim]")
        wrap_table_in_panel(table, "Day of Week (UTC)", target_console)
        return

    max_mean = max(s.mean for s in displayable)
    cheapest = min(displayable, key=lambda s: s.mean)
    peak = max(displayable, key=lambda s: s.mean)

    for stat in stats:
        has_data = stat.hours_covered >= _MIN_HOURS_FOR_DISPLAY and stat.mean > 0
        row_style = "" if has_data else "dim"
        bar_cell = _bar_for(stat.mean, max_mean) if has_data else "\u2014"
        delta_cell = _format_delta_pct(stat.relative_index * 100.0) if has_data else "-"
        if has_data and stat.weekday == cheapest.weekday:
            delta_cell = f"{delta_cell} [green]\u2190 cheapest[/green]"
        elif has_data and stat.weekday == peak.weekday:
            delta_cell = f"{delta_cell} [yellow]\u2190 peak[/yellow]"
        table.add_row(
            stat.name,
            _format_price(stat.mean) if has_data else "-",
            bar_cell,
            delta_cell,
            style=row_style,
        )

    wrap_table_in_panel(table, "Day of Week (UTC)", target_console)
    target_console.print(
        f"[{muted}]Based on duration-weighted means over the selected window.[/{muted}]"
    )


def _render_hour_panel(stats: list[HourStat], target_console: Console) -> None:
    """Render the 24-hour sparkline panel with cheapest/peak annotations."""
    muted = theme_manager.get_color("muted")
    mask = [s.hours_covered >= _MIN_HOURS_FOR_DISPLAY and s.mean > 0 for s in stats]
    values = [s.mean for s in stats]
    sparkline = _sparkline(values, mask)

    visible = [s for s, ok in zip(stats, mask, strict=True) if ok]
    if visible:
        cheapest = min(visible, key=lambda s: s.mean)
        peak = max(visible, key=lambda s: s.mean)
        spread_pct = (
            (peak.mean - cheapest.mean) / cheapest.mean * 100.0 if cheapest.mean > 0 else 0.0
        )
        summary = (
            f"Cheapest: {cheapest.hour:02d}:00 UTC ({_format_price(cheapest.mean)})"
            f" \u2022 Peak: {peak.hour:02d}:00 UTC ({_format_price(peak.mean)})"
            f" \u2022 Spread: {spread_pct:.0f}%"
        )
    else:
        summary = "[dim]insufficient data[/dim]"

    table = create_flow_table(title=None, show_borders=True, padding=1)
    add_left_aligned_column(table, "Summary")
    table.add_row(summary)
    table.add_row(sparkline or "[dim]insufficient data[/dim]")
    table.add_row(f"[{muted}]00{' ' * 18}12{' ' * 18}23[/{muted}]")
    wrap_table_in_panel(table, "Hour of Day UTC (last 14d)", target_console)


def _render_peak_slow_panel(days: list[DayStat], k: int, target_console: Console) -> None:
    """Render the two-column cheapest / most-expensive calendar-days panel."""
    accent = theme_manager.get_color("accent")
    usable = [d for d in days if d.hours_covered >= _MIN_HOURS_FOR_DISPLAY and d.mean > 0]
    cheap = sorted(usable, key=lambda d: d.mean)[:k]
    expensive = sorted(usable, key=lambda d: -d.mean)[:k]

    table = create_flow_table(title=None, show_borders=True, padding=1)
    add_left_aligned_column(table, "Cheapest", style=accent)
    add_left_aligned_column(table, "Most Expensive", style=accent)

    rows = max(len(cheap), len(expensive))
    if rows == 0:
        table.add_row("[dim]insufficient data[/dim]", "[dim]insufficient data[/dim]")
    else:
        for i in range(rows):
            left = _format_day_row(cheap[i]) if i < len(cheap) else ""
            right = _format_day_row(expensive[i]) if i < len(expensive) else ""
            table.add_row(left, right)

    wrap_table_in_panel(table, "Peak / Slow Days (last 14d UTC)", target_console)


def _format_day_row(day: DayStat) -> str:
    """Render one DayStat as ``"Sat 2026-04-04  $2.21"``."""
    weekday_name = day.date.strftime("%a")
    iso = day.date.isoformat()
    return f"{weekday_name} {iso}  {_format_price(day.mean)}"


def _render_volatility_panel(
    summary: VolatilitySummary,
    trend: PriceTrend,
    target_console: Console,
) -> None:
    """Render the 3-line volatility/momentum panel."""
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")

    delta_6h = trend.delta_6h
    delta_1h = trend.delta_1h
    if delta_6h is None and delta_1h is None:
        arrow = "\u00b7"
    elif (delta_6h or 0.0) > (delta_1h or 0.0):
        arrow = "\u2193"  # cooling (6h median above current 1h sample)
    elif (delta_6h or 0.0) < (delta_1h or 0.0):
        arrow = "\u2191"  # heating
    else:
        arrow = "\u00b7"

    cooling_heating = "cooling" if arrow == "\u2193" else "heating" if arrow == "\u2191" else "flat"
    six_h_text = f"{delta_6h:+.1f}%" if delta_6h is not None else "-"
    one_h_text = f"{delta_1h:+.1f}%" if delta_1h is not None else "-"

    table = create_flow_table(title=None, show_borders=True, padding=1)
    add_left_aligned_column(table, "Signal", style=accent)
    add_left_aligned_column(table, "Value")
    table.add_row("7d CV", f"{summary.cv_pct:.1f}% ([{muted}]{summary.label}[/{muted}])")
    table.add_row(
        f">{summary.swing_threshold_pct:.0f}% swings",
        f"{summary.swing_count_7d} in last 7d",
    )
    table.add_row(
        "Momentum",
        f"{arrow} {cooling_heating} \u2014 6h {six_h_text}, 1h {one_h_text}",
    )
    wrap_table_in_panel(table, "Volatility Trend", target_console)


def _compute_reference_time() -> datetime:
    """Return the reference "now" in UTC. Extracted for test monkeypatching."""
    return datetime.now(tz=timezone.utc)


def _lookup_history(
    history: dict[tuple[str, str, int], dict[str, Any]],
    gpu: str,
    region: str,
    gpu_count: int,
) -> dict[str, Any] | None:
    """Case-insensitive lookup of a (gpu, region, gpu_count) series."""
    target = (gpu.lower(), region, gpu_count)
    for (g, r, gc), entry in history.items():
        if (g.lower(), r, gc) == target:
            return entry
    return None


def _pick_cheapest_region(
    history: dict[tuple[str, str, int], dict[str, Any]],
    gpu: str,
    gpu_count: int,
) -> str | None:
    """Return the cheapest region for ``(gpu, gpu_count)`` by most recent price.

    Scans all ``(gpu, region, gpu_count)`` entries in ``history`` and returns
    the region whose last spot price is lowest. Entries with empty price
    series are ignored. Returns ``None`` when no matching market exists so
    callers can fail closed with an actionable error.
    """
    gpu_lower = gpu.lower()
    best_region: str | None = None
    best_price = float("inf")
    for (g, r, gc), entry in history.items():
        if g.lower() != gpu_lower or gc != gpu_count:
            continue
        prices = entry.get("spot_prices") or []
        if not prices:
            continue
        current = prices[-1]
        if current < best_price:
            best_price = current
            best_region = r
    return best_region


def _build_json_payload(
    *,
    gpu: str,
    region: str,
    gpu_count: int,
    reference_time: datetime,
    wow: WeekOverWeekResult,
    weekday_stats: list[WeekdayStat],
    hour_stats: list[HourStat],
    day_stats: list[DayStat],
    vol: VolatilitySummary,
) -> dict[str, Any]:
    """Assemble the locked JSON schema for ``flow pricing stats --json``."""
    usable_days = [d for d in day_stats if d.hours_covered >= _MIN_HOURS_FOR_DISPLAY and d.mean > 0]
    peak_days = sorted(usable_days, key=lambda d: -d.mean)[:_PEAK_SLOW_K]
    slow_days = sorted(usable_days, key=lambda d: d.mean)[:_PEAK_SLOW_K]
    return {
        "config": {"gpu": gpu, "region": region, "gpu_count": gpu_count},
        "reference_time": reference_time.isoformat(),
        "wow": {
            "this_wk_overlap": wow.this_wk_overlap,
            "last_wk_overlap": wow.last_wk_overlap,
            "this_wk_full": wow.this_wk_full,
            "last_wk_full": wow.last_wk_full,
            "delta_overlap_abs": wow.delta_overlap_abs,
            "delta_overlap_pct": wow.delta_overlap_pct,
            "delta_full_abs": wow.delta_full_abs,
            "delta_full_pct": wow.delta_full_pct,
            "significant_overlap": wow.significant_overlap,
            "hours_elapsed_this_wk": wow.hours_elapsed_this_wk,
        },
        "weekday": [
            {
                "weekday": w.weekday,
                "name": w.name,
                "mean": w.mean,
                "hours_covered": w.hours_covered,
                "relative_index": w.relative_index,
            }
            for w in weekday_stats
        ],
        "hourly": [
            {
                "hour": h.hour,
                "mean": h.mean,
                "hours_covered": h.hours_covered,
                "relative_index": h.relative_index,
            }
            for h in hour_stats
        ],
        "peak_days": [
            {
                "date": d.date.isoformat(),
                "mean": d.mean,
                "hours_covered": d.hours_covered,
            }
            for d in peak_days
        ],
        "slow_days": [
            {
                "date": d.date.isoformat(),
                "mean": d.mean,
                "hours_covered": d.hours_covered,
            }
            for d in slow_days
        ],
        "volatility": {
            "cv_pct": vol.cv_pct,
            "label": vol.label,
            "swing_count_7d": vol.swing_count_7d,
            "swing_threshold_pct": vol.swing_threshold_pct,
        },
    }


def build_command(owner: BaseCommand) -> click.Command:
    """Build the ``flow pricing stats`` Click command.

    The ``owner`` parameter is the parent :class:`PricingCommand` instance;
    ``cli_error_guard(owner)`` routes exceptions through its error handlers
    for consistent formatting with the default ``flow pricing`` view.
    """

    @click.command(name="stats", help="Per-market price statistics for one (gpu, region, size).")
    @click.option("--gpu", default="h100", show_default=True, help="Target GPU (e.g., h100)")
    @click.option(
        "--region",
        default=None,
        help="Target region (default: auto-pick cheapest region for the GPU)",
    )
    @click.option("--gpu-count", type=int, default=8, show_default=True, help="GPU count tier")
    @click.option(
        "--window-days",
        type=int,
        default=28,
        show_default=True,
        help="Window for weekday seasonality panel (hourly/WoW stay 14d)",
    )
    @click.option(
        "--swing-threshold",
        type=float,
        default=10.0,
        show_default=True,
        help="Percentage move counted as a swing in volatility summary",
    )
    @click.option("--json", "-j", "as_json", is_flag=True, help="Emit machine-readable JSON")
    @cli_error_guard(owner)
    def stats(
        gpu: str,
        region: str | None,
        gpu_count: int,
        window_days: int,
        swing_threshold: float,
        as_json: bool,
    ) -> None:
        """Render per-market price statistics."""
        reference_time = _compute_reference_time()
        api_base, api_key, _project = _resolve_api_context()
        fid_map = _fetch_instance_type_map(api_base, api_key)
        history = _fetch_price_history(
            api_base,
            api_key,
            fid_map,
            gpu_filter=gpu,
            region_filter=region,
            target_regions=[region] if region else None,
        )

        auto_region = region is None
        if auto_region:
            resolved_region = _pick_cheapest_region(history, gpu, gpu_count)
            if resolved_region is None:
                message = (
                    f"No markets found for {gpu.upper()} {gpu_count}x."
                    f" Try a different --gpu or --gpu-count,"
                    f" or run 'flow pricing --gpu {gpu}' to see what's live."
                )
                if as_json:
                    click.echo(json.dumps({"error": message}, indent=2))
                else:
                    console.print(f"[red]{message}[/red]")
                raise click.exceptions.Exit(1)
            region = resolved_region

        try:
            Telemetry().log_event(
                "pricing_stats_view_shown",
                {
                    "gpu": gpu,
                    "region": region,
                    "gpu_count": gpu_count,
                    "window_days": window_days,
                    "auto_region": auto_region,
                },
            )
        except Exception:  # noqa: BLE001
            pass

        entry = _lookup_history(history, gpu, region, gpu_count)
        if entry is None:
            message = (
                f"No price history found for {gpu.upper()} {gpu_count}x in {region}."
                f" Check the market exists via 'flow pricing --gpu {gpu}'."
            )
            if as_json:
                click.echo(json.dumps({"error": message}, indent=2))
            else:
                console.print(f"[red]{message}[/red]")
            raise click.exceptions.Exit(1)

        spot_prices: list[float] = entry["spot_prices"]
        timestamps: list[str] = entry["timestamps"]
        current_price = spot_prices[-1] if spot_prices else 0.0

        wow = week_over_week_compare(spot_prices, timestamps, reference_time)
        weekday_stats = bucket_by_weekday(
            spot_prices, timestamps, reference_time, window_days=window_days
        )
        hour_stats = bucket_by_hour(spot_prices, timestamps, reference_time, window_days=14)
        day_stats = bucket_by_day(spot_prices, timestamps, reference_time, window_days=14)
        vol = volatility_summary(
            spot_prices,
            timestamps,
            reference_time,
            swing_threshold_pct=swing_threshold,
        )
        trend = compute_price_trend(
            spot_prices, timestamps, current_price, reference_time=reference_time
        )

        if as_json:
            payload = _build_json_payload(
                gpu=gpu,
                region=region,
                gpu_count=gpu_count,
                reference_time=reference_time,
                wow=wow,
                weekday_stats=weekday_stats,
                hour_stats=hour_stats,
                day_stats=day_stats,
                vol=vol,
            )
            click.echo(json.dumps(payload, indent=2))
            return

        accent = theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")
        suffix = f" [{muted}](auto-selected cheapest region)[/{muted}]" if auto_region else ""
        console.print(
            f"[bold {accent}]Pricing stats[/bold {accent}]"
            f" \u2022 {gpu.upper()} {gpu_count}x \u2022 {region}{suffix}"
        )
        _render_wow_panel(wow, console)
        _render_weekday_panel(weekday_stats, console)
        _render_hour_panel(hour_stats, console)
        _render_peak_slow_panel(day_stats, _PEAK_SLOW_K, console)
        _render_volatility_panel(vol, trend, console)

    return stats
