# 生产化方案：Bug Repair Agent 从 PoC 到生产可用

## 现状评估

当前系统是一个概念验证（PoC），核心工作流（9 节点）可用，但面对真实生产环境存在以下问题。

### 根本问题

1. **沙箱太简单** — Docker `create + cp + exec` 无法支持依赖数据库/Redis/MQ 的服务，也跑不了复杂的 CI 构建脚本
2. **没有上下文** — Agent 只知道报错日志和文件列表，不知道服务职责、负责人、依赖关系、历史 bug
3. **数据来源单一** — 只读本地文件，无法对接 Sentry/APM/内部监控/CI 失败流水线
4. **安全与权限** — 没有权限控制、审批流程、回滚机制

---

## 目标

将 Bug Repair Agent 嵌入企业现有基础设施，使其能：
- 自动发现并响应 bug（监控/CI 触发）
- 在有足够上下文的前提下分析修复
- 在真实 CI 环境中验证补丁
- 通过审批流程后合并
- 持续评估修复质量，优化效果

---

## 技术选型：全部自研

| 能力 | 方案 | 理由 |
|------|------|------|
| CI 集成 | 自研（requests 调 GitHub REST API） | 只需两个端点，引入 PyGithub 过重 |
| Sentry 接入 | 自研（requests 调 Sentry REST API） | 官方无 Python 拉取 SDK |
| 飞书通知 | 自研（requests POST Webhook） | Webhook 就是 HTTP POST，引入 SDK 过度 |
| 测试生成 | 自研（LLM 生成） | Agent 自身能力，不需要外部工具 |
| 自动回滚 | 自研（git_ops 新增 revert） | git revert 几行代码 |
| 可观测性 | Langfuse（已有） | 已集成，不需要新增 |

---

## P0：不解决就无法使用

### 1. 接入真实 CI Runner 做构建和测试

**问题**：当前 Docker 沙箱只能做语言级别的编译检查，无法运行项目级别的构建和测试。

**方案**：

- 新增 `src/ci_runner.py`，通过 GitHub REST API 触发 CI：
  1. Agent 生成补丁后，通过 `git_ops.py` 提交到临时分支
  2. 调用 `POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches` 触发 CI
  3. 轮询 `GET /repos/{owner}/{repo}/actions/runs` 获取结果
  4. 获取日志 `GET /repos/{owner}/{repo}/actions/runs/{run_id}/logs`
  5. 结构化返回：pass / fail + 错误日志
- `src/sandbox.py` 删除，不再需要

**设计要点**：
- 定义统一接口 `CIRunner(Protocol)`：
  ```python
  class CIRunner(Protocol):
      def trigger(self, branch: str) -> str: ...
      def poll_result(self, run_id: str, timeout: int) -> CommandResult: ...
  ```
- `GitHubCIRunner`：基于 requests 调用 GitHub Actions API
- 超时 10 分钟，轮询间隔 15 秒
- 新增配置项：`GITHUB_OWNER`、`GITHUB_REPO`、`CI_WORKFLOW_ID`

### 2. 接入真实日志源

**问题**：当前只支持读取本地日报文件，无法对接线上监控系统。

**方案**：

- 新增日志接入层（`src/log_sources/`），定义统一接口：
  ```python
  class LogSource(Protocol):
      def fetch_latest_errors(self, service: str) -> list[ErrorRecord]: ...
  ```
- 第一个实现：`SentrySource`，通过 Sentry REST API 拉取未解决 issue：
  - `GET /api/0/projects/{org}/{project}/issues/?query=is:unresolved&sortBy=date`
  - `GET /api/0/issues/{issue_id}/events/latest/` 获取堆栈
- 错误记录标准化为 `ErrorRecord`：
  ```python
  @dataclass
  class ErrorRecord:
      service: str
      repo: str
      stack_trace: str
      error_type: str
      message: str
      environment: str
      occurrence_count: int
      first_seen: str
      url: str
  ```

**设计要点**：
- `src/log_parser.py` 保持不变
- 新增 `src/log_sources/__init__.py`、`src/log_sources/sentry.py`
- 新增配置项：`SENTRY_TOKEN`、`SENTRY_ORG`、`SENTRY_PROJECT`

### 3. 接入企业 IM 通知 + 人工审批

**问题**：当前修复完成后直接输出 PR，没有通知负责人、没有审批环节。

**方案**：

- 新增通知模块（`src/notifier.py`），基于飞书自定义机器人 Webhook：
  ```python
  class Notifier(Protocol):
      def notify(self, message: str) -> None: ...
  ```
- `FeishuWebhookNotifier`：POST 到飞书 Webhook URL，发送 Markdown 消息
- 通知节点嵌入工作流：
  - bug 发现时：通知服务负责人
  - 修复完成后：通知审查者，附带 PR 链接、Langfuse trace 链接
  - 修复失败：通知负责人需要人工介入
- 审批流程：Agent 创建 draft PR，通知审查者 review，审查者批准后才合并

**设计要点**：
- 通知模块独立
- `report_node` 输出中增加 `reviewers: list[str]` 字段
- 新增 `notify_node`（第 10 个节点），在 `report` 之后执行通知
- 新增配置项：`FEISHU_WEBHOOK_URL`

---

## P1：体验提升

### 4. 上下文注入

**问题**：Agent 只有错误日志和文件列表，缺少服务背景信息。

**方案**：

- 新增 `src/context_provider.py`：
  ```python
  @dataclass
  class ServiceContext:
      name: str
      description: str
      owner: str
      language: str
      dependencies: list[str]
      recent_changes: str
      related_issues: list[str]
      docs_url: str
  ```
- 上下文来源：
  1. 仓库根目录的 `SERVICE.md`（服务自描述）
  2. Git 最近 7 天的 commit message 摘要
- 在 `analyze_node` 中注入上下文

### 5. 多步骤调试能力

**问题**：当前工作流是单轮 "分析→修复"，复杂 bug 需要反复试错。

**方案**：

- 新增 `diagnose_node`：build/test 失败时，Agent 读取失败日志分析原因
- 状态新增 `fix_history: list[FixAttempt]`，记录每次修复尝试和失败原因
- LLM 可以看到失败历史，避免重复同样的错误
- 诊断次数限制 2 次，总返工次数 5

### 6. 测试用例生成

**问题**：修复了 bug 但不写回归测试，同类问题可能再次出现。

**方案**：

- 新增 `test_gen_node`：LLM 生成对应的测试用例
- 测试与补丁一起提交，在 CI 中运行

---

## P2：运营保障

### 7. 运营 Dashboard

- 基于 Langfuse 已有能力
- 新增自定义指标：修复成功率、平均耗时、按服务分布、人工介入率
- 数据落盘 SQLite，提供查询 API

### 8. 自动回滚

- `git_ops.py` 新增 `revert_commit()` 方法
- PR 合并后监控关键指标，异常时自动创建 revert PR

### 9. 多模型路由

- 根据 bug 复杂度选择模型（简单→便宜，复杂→最强）

### 10. 反馈闭环

- 审查者标记修复质量标签，记录到 Langfuse score
- 定期分析，优化 prompt 和工作流

---

## 实施路线图

### 第一阶段：P0（生产可用）

| 任务 | 产出 |
|------|------|
| 删除 sandbox.py | 移除旧沙箱 |
| 新增 ci_runner.py | CI 集成模块（GitHub Actions API） |
| 新增 log_sources/ 目录 | Sentry 接入器 |
| 新增 notifier.py | 飞书 Webhook 通知模块 |
| 工作流新增 notify_node | 10 节点工作流 |
| 配置更新 | CI、Sentry、飞书配置 |
| 测试覆盖 | ci_runner / log_sources / notifier 测试 |

### 第二阶段：P1（体验提升）

| 任务 | 产出 |
|------|------|
| 新增 context_provider.py | 上下文注入 |
| 新增 diagnose_node | 多步骤调试 |
| 状态新增 fix_history | 修复历史传递 |
| 新增 test_gen_node | 测试用例生成 |
| 工作流调整 | 12 节点工作流 |

### 第三阶段：P2（运营保障）

| 任务 | 产出 |
|------|------|
| 指标上报 + 查询 API | 运营数据 |
| 自动回滚 | revert 机制 |
| 多模型路由 | 复杂度评估 |
| 反馈收集 | 质量标签 + 数据分析 |

---

## 新增依赖

| 包 | 用途 |
|----|------|
| 无 | P0 阶段不引入任何新依赖，全部自研 |

---

## 约束原则

1. **合适优先** — 自研与开源方案对比，选择最适合当前场景的实现
2. **渐进式接入** — 先接 Sentry、GitHub Actions、飞书 Webhook，跑通后再扩展
3. **人工审批不可少** — Agent 只创建 draft PR，不自动合并
4. **安全优先** — Agent 不访问密钥文件，不推送受保护分支
