# 文档索引

- [架构文档](architecture.md) — 系统架构、数据流、模块依赖
