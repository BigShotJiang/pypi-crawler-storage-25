# docs/ — 文档

## 架构

```
docs/
├── README.md          # 文档索引
├── AGENTS.md          # 本文档
└── architecture.md    # 系统架构文档
```

## 说明

- `docs/README.md` 是文档索引，指向所有文档
- `architecture.md` 记录系统架构、设计决策、数据流
- 本文档 (AGENTS.md) 记录文档目录自身的职责
