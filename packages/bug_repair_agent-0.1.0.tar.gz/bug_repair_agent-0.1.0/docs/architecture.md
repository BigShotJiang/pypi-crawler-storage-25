# 架构文档

## 系统概述

Bug Repair Agent 是一个基于 LangGraph 的自动化代码修复系统。输入报错日志，输出 PR。
支持 Python / Go / TypeScript / JavaScript 四种语言。
集成 Langfuse 可观测性，自动记录每次修复运行的 trace。

## 架构

```
bug-repair-agent/
├── src/
│   ├── config.py              # 环境变量加载（LLM/Git/沙箱/Webhook/Langfuse/Demo 路径）
│   ├── cli.py                 # CLI 入口：run / demo / serve（含 Langfuse @observe，支持 --verbose）
│   ├── log_parser.py          # 日志解析器：多语言 stack trace 解析
│   ├── sandbox.py             # Docker 沙箱：隔离构建/测试，支持容器复用
│   ├── git_ops.py             # Git 操作：分支/提交/PR
│   ├── langfuse_ops.py        # Langfuse 操作：trace 获取/搜索/URL 生成
│   └── agent/
│       ├── state.py           # LangGraph 状态类型（25 字段，含 sandbox_container_id/rework_target）
│       ├── tools.py           # 多语言代码工具
│       ├── nodes.py           # 9 个节点（ReAct 工具循环/沙箱共享/返工路由/文件注入/容错解析）
│       └── graph.py           # 工作流组装（9 节点，返工区分 locate/fix）
├── demo/
│   ├── buggy_repo/            # 旧 demo（保留用于兼容）
│   ├── inventory_service/     # 新 demo：库存超卖场景（竞态条件 + 浮点精度 + 通知丢失）
│   └── daily_reports/         # 旧 demo 日报
├── tests/
│   ├── test_state.py          # 状态类型测试
│   ├── test_tools.py          # 工具函数测试
│   ├── test_tools_multilang.py # 多语言工具测试
│   ├── test_nodes.py          # 节点测试（含 ReAct 循环/沙箱共享/容错解析/返工路由）
│   ├── test_graph.py          # 图结构测试（含返工路由）
│   ├── test_integration.py    # 集成测试
│   ├── test_config.py         # 配置测试
│   ├── test_log_parser.py     # 日志解析测试
│   ├── test_sandbox.py        # 沙箱测试
│   ├── test_git_ops.py        # Git 操作测试
│   └── test_langfuse.py       # Langfuse 配置和操作测试
└── docs/
    ├── README.md              # 文档索引
    ├── architecture.md        # 本文档
    └── production_plan.md     # 生产化方案
```

## 数据流

```
日志文本
  → [parse]       LLM 提取 bug 信息
  → [analyze]     读取源码，LLM 根因分析（注入文件内容）
  → [locate]      ReAct 工具循环：search_code → read_file → 精确行号
  → [fix]         生成 unified diff 补丁
  → [build]       Docker 沙箱中构建（创建容器，记录 container_id）
  → [test]        复用同一沙箱容器运行测试
  → [validate]    复用同一沙箱容器跑 lint + LLM 语义验证
  → [review]      LLM 安全审查
  → [report]      生成 PR，销毁沙箱容器

并行：整个流程被 @observe 装饰，所有 LLM 调用和节点执行自动上报到 Langfuse
```

## 返工循环

build / test / validate / review 任一步骤失败：
- rework_count < 3 → 根据 `rework_target` 决定回跳目标
  - `rework_target = "fix"` → 回跳 fix（定位正确，修复不够）
  - `rework_target = "locate"` → 回跳 locate（定位错误）
  - 默认回跳 `locate`
- rework_count >= 3 → 继续到下一步（标记需要人工介入）

## 模块依赖

```
cli.py
  → config.py (配置)
  → agent/graph.py (工作流)
  → langfuse (可观测性，@observe 装饰器)
  → langchain_anthropic (LLM)

agent/graph.py
  → agent/nodes.py (节点函数)
  → agent/state.py (状态类型)

agent/nodes.py
  → agent/tools.py (工具绑定)
  → agent/state.py (状态类型)
  → src/sandbox.py (沙箱环境)
  → langchain_core.messages (AIMessage/HumanMessage/ToolMessage)
  → langchain_anthropic (LLM)

sandbox.py
  → Docker CLI (外部依赖)

git_ops.py
  → git / gh / glab CLI (外部依赖)

langfuse_ops.py
  → langfuse SDK (外部依赖)

log_parser.py
  → 标准库（re, dataclasses）

agent/tools.py
  → 标准库（pathlib, subprocess, shutil）
```

## 设计决策

- **LangGraph 而非 LangChain Chain**：需要条件分支和返工循环
- **JSON 结构化输出**：所有 LLM 调用返回 JSON，便于程序解析
- **TypedDict 而非 dataclass**：LangGraph 对 TypedDict 有原生支持
- **工具调用而非直接执行**：让 LLM 自主决定搜索什么代码
- **Docker 沙箱隔离**：build/test 在容器中运行，不污染宿主机
- **默认 draft PR**：安全起见，自动创建的 PR 默认为草稿，需人工审查后合并
- **多语言支持**：Python / Go / TypeScript / JavaScript 四种语言
- **Langfuse @observe 集成**：使用装饰器包裹 graph 执行函数，无需 langchain 依赖，自动创建 trace 记录 LLM 调用、节点耗时、Token 消耗
- **LANGFUSE_ENABLED 开关**：默认关闭，不改变现有行为；设为 true 后自动启用可观测性
- **ReAct 工具循环**：locate_node 实现最多 5 轮工具迭代，模型看到搜索结果后决定下一步
- **沙箱共享**：build/test/validate 复用同一容器，避免重复拷贝代码和应用补丁
- **返工路由区分**：validate/review 失败回跳 fix（位置正确），而非盲目回跳 locate
- **JSON 容错解析**：支持 fence 包裹、文本嵌入 JSON、解析失败自动 retry
- **文件内容注入**：analyze_node 读取源码传给 LLM，而非仅文件名列表
- **沙箱内 lint**：validate_node 在已应用补丁的沙箱中跑 lint，而非原始代码
- **CLI verbose 模式**：`--verbose` / `-v` 标志打印每个节点的详细输出
