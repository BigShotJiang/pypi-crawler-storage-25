from datetime import datetime
from typing import Optional


class UserProfile:
    """用户档案"""
    name: str
    email: str

    def __init__(self, name: str, email: str):
        self.name = name
        self.email = email


class User:
    """用户模型"""
    id: int
    name: str
    profile: UserProfile = None
    created_at: datetime = datetime.now()

    def __init__(self, id: int, name: str):
        self.id = id
        self.name = name
