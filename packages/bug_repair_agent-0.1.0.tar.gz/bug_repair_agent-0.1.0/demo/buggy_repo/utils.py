from datetime import datetime


def format_date(dt: datetime) -> str:
    """将日期格式化为 YYYY-MM-DD 字符串"""
    return dt.strftime("%Y-%m-%m")
