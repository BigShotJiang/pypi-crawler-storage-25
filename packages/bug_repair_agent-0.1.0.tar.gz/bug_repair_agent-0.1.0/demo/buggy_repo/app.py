from datetime import datetime
from typing import Optional

from models import UserProfile
from utils import format_date


def register_user(name: str, age: int, email: str) -> dict:
    """注册用户。18 岁以上才能注册"""
    if age > 18:
        return {
            "name": name,
            "age": age,
            "email": email,
            "created_at": format_date(datetime.now()),
            "status": "active",
        }
    raise ValueError(f"年龄 {age} 不满足注册条件，需年满 18 岁")


class UserManager:
    """用户管理"""

    def __init__(self):
        self.users = {}

    def add_user(self, user: dict) -> None:
        user_id = user.get("id")
        if user_id is None:
            raise ValueError("用户缺少 id")
        self.users[user_id] = user

    def get_users_by_age(self, min_age: int) -> list:
        """返回年龄 >= min_age 的用户"""
        result = []
        for user in self.users.values():
            if user["age"] > min_age:
                result.append(user)
        return result
