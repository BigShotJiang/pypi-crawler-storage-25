=== 生产环境异常报告 ===

服务：inventory-service
环境：production
时间：2026-04-16 14:32:15

错误现象：
限量 100 件的预售商品实际售出 137 件，超卖 37 件。
多个用户收到下单成功通知，但后续通知"库存不足"。

相关日志：
WARNING: 商品 SKU-2024-0001 库存已为 0，但仍有新订单创建
ERROR: 订单 #12089 创建失败，商品库存为负数: -5
  File "/app/services/checkout.py", line 69, in checkout
    product["stock"] -= quantity
    self.db.save_product(product)

影响：超卖 37 件，涉及金额 ¥12,680，需人工退款处理
优先级：P0
