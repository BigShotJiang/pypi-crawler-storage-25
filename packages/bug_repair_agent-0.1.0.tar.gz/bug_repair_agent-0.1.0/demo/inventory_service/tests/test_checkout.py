"""下单流程测试"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.checkout import CheckoutService, OutOfStockError
from services.pricing import PricingService
from utils.validators import validate_email
from utils.formatters import format_amount


class TestCheckout:
    """下单流程测试（单线程，不覆盖并发场景）"""

    def test_checkout_success(self):
        service = CheckoutService()
        order = service.checkout("SKU-2024-0001", 1)
        assert order.product_id == "SKU-2024-0001"
        assert order.quantity == 1
        assert order.status == "pending"

    def test_checkout_multiple_items(self):
        service = CheckoutService()
        order = service.checkout("SKU-2024-0001", 5)
        assert order.quantity == 5

    def test_checkout_out_of_stock(self):
        service = CheckoutService()
        try:
            service.checkout("SKU-2024-0001", 9999)
            assert False, "应该抛出 OutOfStockError"
        except OutOfStockError:
            pass  # 预期行为

    def test_checkout_product_not_found(self):
        service = CheckoutService()
        try:
            service.checkout("NOT-EXIST", 1)
            assert False, "应该抛出 ValueError"
        except ValueError:
            pass  # 预期行为


class TestPricing:
    """价格计算测试"""

    def test_simple_calculation(self):
        pricing = PricingService()
        result = pricing.calculate(100.0, 2)
        assert result == 200.0

    def test_with_discount(self):
        pricing = PricingService()
        result = pricing.calculate(100.0, 2, 0.9)
        assert result == 180.0

    def test_apply_coupon(self):
        pricing = PricingService()
        result = pricing.apply_coupon(100.0, "SAVE10")
        assert result == 90.0


class TestValidators:
    """校验器测试"""

    def test_valid_email(self):
        assert validate_email("test@example.com") is True

    def test_empty_email(self):
        assert validate_email("") is False

    def test_email_without_at(self):
        assert validate_email("invalid") is False


class TestFormatters:
    """格式化工具测试"""

    def test_format_amount(self):
        assert format_amount(342.70) == "¥342.70"

    def test_format_amount_integer(self):
        assert format_amount(100.0) == "¥100.00"
