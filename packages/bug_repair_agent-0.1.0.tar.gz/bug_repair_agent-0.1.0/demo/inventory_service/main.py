"""主入口 — HTTP 路由"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import json

from services.checkout import CheckoutService
from services.pricing import PricingService
from services.notify import NotificationService
from models.product import Product, ProductDB
from models.order import Order, OrderDB
from utils.validators import validate_email
from utils.formatters import format_amount


class Handler(BaseHTTPRequestHandler):
    checkout = CheckoutService()
    pricing = PricingService()
    notify = NotificationService()
    products = ProductDB()
    orders = OrderDB()

    def do_POST(self):
        if self.path == "/api/checkout":
            content_length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(content_length))

            product_id = body.get("product_id")
            quantity = body.get("quantity", 1)
            email = body.get("email")

            # 校验邮箱
            if not validate_email(email):
                self._json_response(400, {"error": "邮箱格式不正确"})
                return

            try:
                product = self.products.get(product_id)
                if product is None:
                    self._json_response(404, {"error": "商品不存在"})
                    return

                order = self.checkout.checkout(product_id, quantity)
                price = self.pricing.calculate(product.price, quantity)
                order.total = format_amount(price)
                self.orders.save(order)

                self.notify.send_order_confirmation(email, order)
                self._json_response(201, {"order_id": order.id, "total": order.total})

            except Exception as e:
                self._json_response(500, {"error": str(e)})

    def do_GET(self):
        if self.path.startswith("/api/products"):
            products = self.products.list_all()
            self._json_response(200, [p.to_dict() for p in products])

    def _json_response(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 8080), Handler)
    print("Server running on port 8080")
    server.serve_forever()
