"""输入校验工具"""
import re

# Bug: 邮箱正则不完整，允许 a@@b.com 这种多 @ 的非法邮箱
# 正确写法应该是 ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$
EMAIL_REGEX = re.compile(r"^[^@]+@[^@]+$")


def validate_email(email: str) -> bool:
    """校验邮箱格式

    Bug: 正则 ^[^@]+@[^@]+$ 只检查是否包含一个 @，
    但允许 a@@b.com、@b.com、a@ 等非法格式。
    """
    if not email:
        return False
    return bool(EMAIL_REGEX.match(email))


def validate_quantity(quantity: int) -> bool:
    """校验购买数量"""
    return isinstance(quantity, int) and quantity > 0


def validate_product_id(product_id: str) -> bool:
    """校验商品 ID 格式"""
    return bool(re.match(r"^SKU-\d{4}-\d{4}$", product_id))
