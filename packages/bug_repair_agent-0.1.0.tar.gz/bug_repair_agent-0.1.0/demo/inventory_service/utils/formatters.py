"""格式化工具"""


def format_amount(amount: float) -> str:
    """格式化金额显示"""
    return f"¥{amount:.2f}"


def format_order_id(order_id: str) -> str:
    """格式化订单 ID"""
    return f"订单 #{order_id}"


def format_product_name(name: str, max_length: int = 20) -> str:
    """截断过长的商品名"""
    if len(name) <= max_length:
        return name
    return name[:max_length - 3] + "..."
