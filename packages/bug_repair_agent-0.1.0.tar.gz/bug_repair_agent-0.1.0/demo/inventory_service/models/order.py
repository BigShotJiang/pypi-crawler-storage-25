"""订单模型"""
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Order:
    id: str
    product_id: str
    quantity: int
    total: float = 0.0
    status: str = "pending"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "product_id": self.product_id,
            "quantity": self.quantity,
            "total": self.total,
            "status": self.status,
            "created_at": self.created_at,
        }


class OrderDB:
    """订单数据库（内存模拟）"""

    def __init__(self):
        self._orders: list[Order] = []

    def save(self, order: Order):
        self._orders.append(order)

    def get(self, order_id: str) -> Order | None:
        for o in self._orders:
            if o.id == order_id:
                return o
        return None

    def list_all(self) -> list[Order]:
        return list(self._orders)
