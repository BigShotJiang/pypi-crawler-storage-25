"""商品模型"""
from dataclasses import dataclass


@dataclass
class Product:
    id: str
    name: str
    price: float
    stock: int

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "price": self.price,
            "stock": self.stock,
        }


class ProductDB:
    """商品数据库（内存模拟）"""

    def __init__(self):
        self._products: dict[str, Product] = {}
        self._seed()

    def _seed(self):
        self._products["SKU-2024-0001"] = Product(
            id="SKU-2024-0001", name="限量预售商品", price=342.70, stock=100
        )
        self._products["SKU-2024-0002"] = Product(
            id="SKU-2024-0002", name="普通商品", price=99.00, stock=500
        )

    def get(self, product_id: str) -> Product | None:
        return self._products.get(product_id)

    def list_all(self) -> list[Product]:
        return list(self._products.values())

    def save(self, product: Product):
        self._products[product.id] = product
