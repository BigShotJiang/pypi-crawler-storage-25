"""下单流程 — 库存检查与扣减"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class PaymentResult:
    success: bool
    transaction_id: str = ""
    error: str = ""


@dataclass
class Order:
    id: str
    product_id: str
    quantity: int
    total: float = 0.0
    status: str = "pending"
    created_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


class OutOfStockError(Exception):
    pass


class PaymentError(Exception):
    pass


class MockDB:
    """模拟数据库"""

    def __init__(self):
        self._products: dict[str, dict[str, Any]] = {}
        self._orders: list[Order] = []

    def add_product(self, product_id: str, name: str, price: float, stock: int):
        self._products[product_id] = {
            "id": product_id,
            "name": name,
            "price": price,
            "stock": stock,
        }

    def get_product(self, product_id: str) -> dict[str, Any] | None:
        return self._products.get(product_id)

    def save_product(self, product: dict[str, Any]):
        self._products[product["id"]] = product

    def save_order(self, order: Order):
        self._orders.append(order)


class CheckoutService:
    """下单服务"""

    def __init__(self):
        self.db = MockDB()
        self._init_products()

    def _init_products(self):
        self.db.add_product("SKU-2024-0001", "限量预售商品", 342.70, 100)
        self.db.add_product("SKU-2024-0002", "普通商品", 99.00, 500)

    def checkout(self, product_id: str, quantity: int) -> Order:
        product = self.db.get_product(product_id)
        if product is None:
            raise ValueError(f"商品 {product_id} 不存在")

        # Bug: 库存检查与扣减之间存在时间窗口
        # 两个并发请求可以同时读到 stock=1，都通过检查，都扣减到 -1
        if product["stock"] >= quantity:
            # 模拟支付处理
            payment_result = self._process_payment(product["price"] * quantity)
            if payment_result.success:
                # 支付成功后才扣减库存，但此时另一个请求可能已经读到了旧的 stock
                product["stock"] -= quantity
                self.db.save_product(product)

                order = Order(
                    id=f"ORD-{len(self.db._orders) + 1:05d}",
                    product_id=product_id,
                    quantity=quantity,
                    total=product["price"] * quantity,
                )
                self.db.save_order(order)
                return order
            else:
                raise PaymentError("支付失败")
        else:
            raise OutOfStockError(f"库存不足: {product['stock']} < {quantity}")

    def _process_payment(self, amount: float) -> PaymentResult:
        """模拟支付处理"""
        return PaymentResult(success=True, transaction_id="TXN-001")
