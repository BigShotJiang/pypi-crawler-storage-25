"""通知服务"""


class NotificationService:
    """通知服务

    Bug: 通知发送失败时无重试机制，导致通知丢失
    """

    def __init__(self):
        self._sent: list[dict] = []

    def send_order_confirmation(self, email: str, order) -> bool:
        """发送订单确认通知

        如果通知发送失败（网络异常、邮件服务不可用等），
        直接返回 False，没有重试队列。
        """
        try:
            # 模拟发送通知
            self._sent.append({
                "type": "order_confirmation",
                "email": email,
                "order_id": order.id,
            })
            return True
        except Exception:
            # Bug: 没有重试机制，没有失败队列，通知直接丢失
            return False

    def send_stock_alert(self, email: str, product_id: str) -> bool:
        """发送库存告警通知"""
        try:
            self._sent.append({
                "type": "stock_alert",
                "email": email,
                "product_id": product_id,
            })
            return True
        except Exception:
            return False
