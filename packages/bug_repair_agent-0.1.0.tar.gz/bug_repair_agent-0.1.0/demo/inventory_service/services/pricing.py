"""价格计算"""


class PricingService:
    """价格计算服务"""

    def calculate(self, unit_price: float, quantity: int, discount: float = 1.0) -> float:
        """计算总价

        Bug: 使用 float 进行金额计算，存在浮点精度问题
        例如: 342.70 * 3 = 1028.0999999999999 而非 1028.10
        """
        return unit_price * quantity * discount

    def apply_coupon(self, price: float, coupon_code: str) -> float:
        """应用优惠券"""
        coupons = {
            "SAVE10": 0.90,
            "SAVE20": 0.80,
            "HALF": 0.50,
        }
        discount = coupons.get(coupon_code, 1.0)
        return self.calculate(price, 1, discount)
