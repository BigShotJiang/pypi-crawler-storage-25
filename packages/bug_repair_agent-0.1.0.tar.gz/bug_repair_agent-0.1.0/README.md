# Bug Repair Agent

基于 Agent 的自动化代码修复系统。读取报错日志，分析根因，生成可编译的修复补丁并提交 PR。

## 快速开始

```bash
uv venv --python 3.9 && source .venv/bin/activate
uv pip install -e .
cp .env.example .env
# 编辑 .env，填入 ANTHROPIC_API_KEY
bug-repair demo
```

## 命令

| 命令 | 说明 |
|------|------|
| `bug-repair demo` | 用内置 demo 演示 |
| `bug-repair run -r <日报路径> [--repo <仓库路径>]` | 指定日报运行 |
| `bug-repair serve` | 启动 Webhook 服务模式 |

## 工作流

```
日志 → 解析 → 根因分析 → 定位代码 → 生成补丁 → 构建 → 测试 → 验证 → 安全审查 → 生成 PR
                                           ↑_________________________↙ (返工 ≤3)
```

- **构建** — Docker 沙箱中编译/构建补丁后的代码
- **测试** — Docker 沙箱中运行项目测试套件
- **验证** — 语法检查 + LLM 语义验证
- **安全审查** — LLM 检查 SQL 注入/XSS/路径遍历/命令注入/敏感信息泄露

验证/审查失败时自动返工（最多 3 次）。

## Webhook 服务

```bash
bug-repair serve --port 8000
```

端点：
- `POST /webhook/bug` — 接收 bug 告警（body: `{"report": "...", "repo_path": "..."}`）
- `GET /health` — 健康检查

## 支持的语言

| 语言 | 文件扫描 | 语法检查 | 构建 | 测试 |
|------|---------|---------|------|------|
| Python | ✓ | py_compile | py_compile | pytest |
| Go | ✓ | gofmt | go build | go test |
| TypeScript | ✓ | tsc | tsc | jest |
| JavaScript | ✓ | node --check | — | jest |

## 配置

详见 `.env.example`。关键配置项：

- `ANTHROPIC_API_KEY` — LLM API 密钥
- `GIT_TOKEN` — GitHub/GitLab 访问令牌（用于 PR 提交）
- `GIT_PLATFORM` — 平台类型（github / gitlab）
- `SANDBOX_TIMEOUT` — 沙箱命令超时时间（秒）

## Langfuse 可观测性

设置 `LANGFUSE_ENABLED=true` 后，每次修复运行会自动在 Langfuse 创建一个 trace，记录：
- LLM 调用详情（prompt、response、token 消耗、延迟）
- 各节点执行时间
- 完整的调用链

生成的 PR 描述中会附带 trace 链接，方便审查修复过程。

```
LANGFUSE_ENABLED=true
LANGFUSE_PUBLIC_KEY=pk-lf-xxxxxxxxxxxx
LANGFUSE_SECRET_KEY=sk-lf-xxxxxxxxxxxx
LANGFUSE_HOST=https://cloud.langfuse.com
```

## 测试

```bash
pytest tests/ -v
```

## 项目结构

详见 [docs/architecture.md](docs/architecture.md)
