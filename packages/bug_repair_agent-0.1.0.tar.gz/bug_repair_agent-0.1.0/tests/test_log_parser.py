"""日志解析器测试 — 验证 stack trace 解析能力"""

from src.log_parser import parse_log


class TestPythonStackTrace:
    """Python stack trace 解析"""

    def test_basic_traceback(self):
        log = """Traceback (most recent call last):
  File "/app/utils.py", line 15, in process
    return data["missing"]
KeyError: 'missing'"""
        result = parse_log(log)
        assert result.language == "python"
        assert result.exception_type == "KeyError"
        assert result.exception_message == "'missing'"
        assert len(result.stack) >= 1
        assert result.stack[0].file == "/app/utils.py"
        assert result.stack[0].line == 15
        assert result.stack[0].function == "process"

    def test_multi_frame_traceback(self):
        log = """Traceback (most recent call last):
  File "/app/server.py", line 10, in handle
    result = process(req)
  File "/app/utils.py", line 15, in process
    return data["missing"]
  File "/app/models.py", line 22, in lookup
    return items[idx]
IndexError: list index out of range"""
        result = parse_log(log)
        assert len(result.stack) == 3
        # 最后一个是崩溃点
        assert result.stack[-1].file == "/app/models.py"
        assert result.stack[-1].line == 22

    def test_no_traceback_plain_error(self):
        """没有 stack trace 的纯错误日志"""
        log = "ERROR: Connection refused to database host db.internal:5432"
        result = parse_log(log)
        assert result.language is None
        assert "Connection refused" in result.exception_message


class TestGoStackTrace:
    """Go stack trace 解析"""

    def test_panic_traceback(self):
        log = """panic: runtime error: index out of range [5] with length 3

goroutine 1 [running]:
main.handleRequest(0xc0000a0000)
\t/path/to/main.go:42 +0x123
main.setupRouter()
\t/path/to/router.go:15 +0x45"""
        result = parse_log(log)
        assert result.language == "go"
        assert "index out of range" in result.exception_message
        assert len(result.stack) >= 1
        assert result.stack[0].file == "/path/to/main.go"
        assert result.stack[0].line == 42

    def test_goroutine_multi(self):
        log = """panic: nil pointer dereference

goroutine 1 [running]:
pkg/handler.GetUser(...)
\t/go/src/app/handler.go:30
main.main()
\t/go/src/app/main.go:10 +0x20

goroutine 2 [running]:
pkg/worker.Run()
\t/go/src/app/worker.go:50"""
        result = parse_log(log)
        assert result.language == "go"
        # 只解析第一个 goroutine
        assert result.stack[0].file == "/go/src/app/handler.go"
        assert result.stack[0].line == 30


class TestTypeScriptStackTrace:
    """TypeScript/Node.js stack trace 解析"""

    def test_type_error(self):
        log = """TypeError: Cannot read property 'name' of undefined
    at process (/app/src/utils.ts:15:22)
    at handler (/app/src/app.ts:42:10)
    at Server.<anonymous> (/app/src/server.ts:8:12)"""
        result = parse_log(log)
        assert result.language == "typescript"
        assert result.exception_type == "TypeError"
        assert len(result.stack) == 3
        assert result.stack[0].file == "/app/src/utils.ts"
        assert result.stack[0].line == 15
        assert result.stack[0].function == "process"

    def test_javascript_stack(self):
        log = """ReferenceError: x is not defined
    at main (/app/index.js:5:3)
    at Object.<anonymous> (/app/index.js:10:1)"""
        result = parse_log(log)
        assert result.language == "javascript"
        assert result.stack[0].file == "/app/index.js"
        assert result.stack[0].line == 5


class TestEdgeCases:
    """边界情况"""

    def test_empty_log(self):
        result = parse_log("")
        assert result.exception_message == ""
        assert result.stack == []

    def test_log_with_context(self):
        """带上下文的日志 — 只提取错误部分"""
        log = """2026-04-16 10:00:00 INFO  Starting server on :8080
2026-04-16 10:00:01 INFO  Connected to database
2026-04-16 10:00:05 ERROR Request failed
Traceback (most recent call last):
  File "/app/handler.py", line 30, in get_user
    user = db.query(uid)
ValueError: invalid user id"""
        result = parse_log(log)
        assert result.exception_type == "ValueError"
        assert result.stack[0].file == "/app/handler.py"
        assert result.stack[0].line == 30

    def test_relative_path(self):
        """相对路径的 stack trace"""
        log = """Traceback (most recent call last):
  File "src/handler.py", line 30, in handle
    result = compute()
RuntimeError: compute failed"""
        result = parse_log(log)
        assert "handler.py" in result.stack[0].file
        assert result.stack[0].line == 30
