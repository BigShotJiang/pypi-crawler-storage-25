import os
from unittest.mock import patch

import pytest

from src.config import (
    get_api_key,
    get_demo_repo,
    get_demo_reports,
    get_git_platform,
    get_git_remote,
    get_git_token,
    get_model,
    get_sandbox_timeout,
    get_webhook_port,
)


def test_get_model_default():
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("ANTHROPIC_MODEL", None)
        assert get_model() == "claude-sonnet-4-20250514"


def test_get_model_custom():
    with patch.dict(os.environ, {"ANTHROPIC_MODEL": "claude-opus-4-6"}):
        assert get_model() == "claude-opus-4-6"


def test_get_api_key_missing():
    with patch.dict(os.environ, {}, clear=True):
        os.environ.pop("ANTHROPIC_API_KEY", None)
        with pytest.raises(EnvironmentError):
            get_api_key()


def test_get_demo_repo_exists():
    path = get_demo_repo()
    assert os.path.isdir(path)


def test_get_demo_reports_exists():
    path = get_demo_reports()
    assert os.path.isdir(path)


class TestGitConfig:
    """Git 相关配置"""

    def test_git_token_default(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GIT_TOKEN", None)
            token = get_git_token()
            assert token == ""

    def test_git_token_custom(self):
        with patch.dict(os.environ, {"GIT_TOKEN": "ghp_xxx"}):
            assert get_git_token() == "ghp_xxx"

    def test_git_platform_default(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GIT_PLATFORM", None)
            assert get_git_platform() == "github"

    def test_git_platform_gitlab(self):
        with patch.dict(os.environ, {"GIT_PLATFORM": "gitlab"}):
            assert get_git_platform() == "gitlab"

    def test_git_remote_default(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GIT_REMOTE", None)
            assert get_git_remote() == ""

    def test_git_remote_custom(self):
        with patch.dict(os.environ, {"GIT_REMOTE": "https://github.com/user/repo.git"}):
            assert get_git_remote() == "https://github.com/user/repo.git"


class TestSandboxConfig:
    """沙箱配置"""

    def test_sandbox_timeout_default(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("SANDBOX_TIMEOUT", None)
            assert get_sandbox_timeout() == 120

    def test_sandbox_timeout_custom(self):
        with patch.dict(os.environ, {"SANDBOX_TIMEOUT": "60"}):
            assert get_sandbox_timeout() == 60


class TestWebhookConfig:
    """Webhook 配置"""

    def test_webhook_port_default(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("WEBHOOK_PORT", None)
            assert get_webhook_port() == 8000

    def test_webhook_port_custom(self):
        with patch.dict(os.environ, {"WEBHOOK_PORT": "9000"}):
            assert get_webhook_port() == 9000
