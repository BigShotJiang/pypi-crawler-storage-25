"""Git 操作和 PR 提交测试 — 验证真实 Git 流程"""

import os
import tempfile

from src.git_ops import GitOps, PRInfo


class TestGitOpsBasic:
    """基础 Git 操作"""

    def test_init_existing_repo(self):
        """在已有 git 仓库上初始化"""
        with tempfile.TemporaryDirectory() as tmpdir:
            os.system(
                f"cd {tmpdir} && git init && git config user.email 'test@test.com' && git config user.name 'Test'"
            )
            with open(os.path.join(tmpdir, "readme.txt"), "w") as f:
                f.write("hello")
            os.system(f"cd {tmpdir} && git add . && git commit -m 'init'")

            git = GitOps(repo_path=tmpdir)
            assert git.repo_path == tmpdir

    def test_create_branch(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.system(
                f"cd {tmpdir} && git init && git config user.email 'test@test.com' && git config user.name 'Test'"
            )
            with open(os.path.join(tmpdir, "readme.txt"), "w") as f:
                f.write("hello")
            os.system(f"cd {tmpdir} && git add . && git commit -m 'init'")

            git = GitOps(repo_path=tmpdir)
            result = git.create_branch("bugfix/test-123")
            assert result.returncode == 0

    def test_commit_and_push(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.system(
                f"cd {tmpdir} && git init && git config user.email 'test@test.com' && git config user.name 'Test'"
            )
            with open(os.path.join(tmpdir, "readme.txt"), "w") as f:
                f.write("hello")
            os.system(f"cd {tmpdir} && git add . && git commit -m 'init'")

            git = GitOps(repo_path=tmpdir)
            git.create_branch("bugfix/test-456")

            # 修改文件
            with open(os.path.join(tmpdir, "readme.txt"), "w") as f:
                f.write("hello world")

            result = git.commit("fix: update readme")
            assert result.returncode == 0

    def test_get_current_branch(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.system(
                f"cd {tmpdir} && git init && git config user.email 'test@test.com' && git config user.name 'Test'"
            )
            with open(os.path.join(tmpdir, "readme.txt"), "w") as f:
                f.write("hello")
            os.system(f"cd {tmpdir} && git add . && git commit -m 'init'")

            git = GitOps(repo_path=tmpdir)
            branch = git.get_current_branch()
            assert "main" in branch or "master" in branch


class TestPRInfo:
    """PR 信息生成"""

    def test_pr_info_basic(self):
        info = PRInfo(
            title="fix: age check off-by-one",
            body="Fixed the age >= 18 check.",
            branch="bugfix/age-check",
        )
        assert "age check" in info.title
        assert "age >= 18" in info.body

    def test_pr_info_with_root_cause(self):
        info = PRInfo(
            title="fix: null pointer in handler",
            body="Added null check before accessing user.name",
            branch="bugfix/null-check",
            root_cause="user.name was accessed without null check",
            validation="PASS: All tests passed",
        )
        assert "null pointer" in info.title
        assert "根因分析" in info.to_markdown()
        assert "验证结果" in info.to_markdown()


class TestGitOpsPatch:
    """补丁相关操作"""

    def test_apply_patch_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.system(
                f"cd {tmpdir} && git init && git config user.email 'test@test.com' && git config user.name 'Test'"
            )
            app = os.path.join(tmpdir, "app.py")
            with open(app, "w") as f:
                f.write("def check(age):\n    if age > 18:\n        return True\n    return False\n")
            os.system(f"cd {tmpdir} && git add . && git commit -m 'init'")

            git = GitOps(repo_path=tmpdir)
            git.create_branch("bugfix/age")

            # 直接修改文件模拟补丁效果
            with open(app, "w") as f:
                f.write("def check(age):\n    if age >= 18:\n        return True\n    return False\n")

            result = git.commit("fix: age check >= 18")
            assert result.returncode == 0
