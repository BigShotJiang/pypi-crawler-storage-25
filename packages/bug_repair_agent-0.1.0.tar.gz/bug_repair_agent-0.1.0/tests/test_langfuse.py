"""Langfuse 配置和操作测试"""

from unittest.mock import MagicMock

from src.config import (
    get_langfuse_host,
    get_langfuse_public_key,
    get_langfuse_secret_key,
    is_langfuse_enabled,
)
from src.langfuse_ops import LangfuseOps

# ── 配置测试 ────────────────────────────────────────────────────


class TestLangfuseConfig:
    def test_langfuse_host_default(self, monkeypatch):
        monkeypatch.delenv("LANGFUSE_HOST", raising=False)
        assert get_langfuse_host() == "https://cloud.langfuse.com"

    def test_langfuse_host_custom(self, monkeypatch):
        monkeypatch.setenv("LANGFUSE_HOST", "https://my-langfuse.example.com")
        assert get_langfuse_host() == "https://my-langfuse.example.com"

    def test_langfuse_public_key_default(self, monkeypatch):
        monkeypatch.delenv("LANGFUSE_PUBLIC_KEY", raising=False)
        assert get_langfuse_public_key() == ""

    def test_langfuse_public_key_custom(self, monkeypatch):
        monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-test")
        assert get_langfuse_public_key() == "pk-lf-test"

    def test_langfuse_secret_key_default(self, monkeypatch):
        monkeypatch.delenv("LANGFUSE_SECRET_KEY", raising=False)
        assert get_langfuse_secret_key() == ""

    def test_langfuse_secret_key_custom(self, monkeypatch):
        monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-test")
        assert get_langfuse_secret_key() == "sk-lf-test"

    def test_langfuse_enabled_default(self, monkeypatch):
        monkeypatch.delenv("LANGFUSE_ENABLED", raising=False)
        assert is_langfuse_enabled() is False

    def test_langfuse_enabled_true(self, monkeypatch):
        monkeypatch.setenv("LANGFUSE_ENABLED", "true")
        assert is_langfuse_enabled() is True

    def test_langfuse_enabled_uppercase(self, monkeypatch):
        monkeypatch.setenv("LANGFUSE_ENABLED", "True")
        assert is_langfuse_enabled() is True

    def test_langfuse_enabled_false_explicit(self, monkeypatch):
        monkeypatch.setenv("LANGFUSE_ENABLED", "false")
        assert is_langfuse_enabled() is False


# ── LangfuseOps 测试 ───────────────────────────────────────────


class TestLangfuseOpsInit:
    def test_init_creates_client(self):
        ops = LangfuseOps(
            host="https://cloud.langfuse.com",
            public_key="pk-test",
            secret_key="sk-test",
        )
        assert ops.host == "https://cloud.langfuse.com"

    def test_init_strips_trailing_slash(self):
        ops = LangfuseOps(
            host="https://cloud.langfuse.com/",
            public_key="pk-test",
            secret_key="sk-test",
        )
        assert ops.host == "https://cloud.langfuse.com"


class TestLangfuseOpsGetTraceUrl:
    def test_trace_url(self):
        ops = LangfuseOps(
            host="https://cloud.langfuse.com",
            public_key="pk-test",
            secret_key="sk-test",
        )
        url = ops.get_trace_url("abc-123")
        assert url == "https://cloud.langfuse.com/trace/abc-123"


class TestLangfuseOpsGetTraceDetails:
    def test_get_trace_details_success(self):
        mock_trace = MagicMock()
        mock_trace.id = "trace-1"
        mock_trace.name = "bug-repair"
        mock_trace.input = {"bug_report": "test"}
        mock_trace.output = {"patch": "diff"}
        mock_trace.latency = 5000
        mock_trace.total_cost = 0.05
        mock_trace.usage = {"prompt_tokens": 100, "completion_tokens": 200, "total_tokens": 300}

        obs_mock = MagicMock()
        obs_mock.id = "obs-1"
        obs_mock.configure_mock(**{"name": "parse"})
        obs_mock.type = "span"
        obs_mock.latency = 1000
        obs_mock.usage = {"prompt_tokens": 50}
        mock_trace.observations = [obs_mock]

        score_mock = MagicMock()
        score_mock.configure_mock(**{"name": "accuracy"})
        score_mock.value = 0.9
        score_mock.comment = "good"
        mock_trace.scores = [score_mock]

        mock_client = MagicMock()
        mock_client.api.trace.get.return_value = mock_trace

        ops = LangfuseOps.__new__(LangfuseOps)
        ops.host = "https://cloud.langfuse.com"
        ops.client = mock_client

        result = ops.get_trace_details("trace-1")

        assert result["id"] == "trace-1"
        assert result["latency"] == 5000
        assert result["total_cost"] == 0.05
        assert result["usage"]["total_tokens"] == 300
        assert len(result["observations"]) == 1
        assert result["observations"][0]["name"] == "parse"
        assert len(result["scores"]) == 1
        assert result["scores"][0]["name"] == "accuracy"


class TestLangfuseOpsSearchTraces:
    def test_search_traces_no_filter(self):
        mock_resp = MagicMock()
        mock_resp.data = [
            MagicMock(id="t1", name="run1", timestamp="2024-01-01", latency=3000, total_cost=0.01),
            MagicMock(id="t2", name="run2", timestamp="2024-01-02", latency=4000, total_cost=0.02),
        ]

        mock_client = MagicMock()
        mock_client.api.trace.list.return_value = mock_resp

        ops = LangfuseOps.__new__(LangfuseOps)
        ops.host = "https://cloud.langfuse.com"
        ops.client = mock_client

        result = ops.search_traces(limit=5)

        assert len(result) == 2
        assert result[0]["id"] == "t1"
        mock_client.api.trace.list.assert_called_once_with(limit=5)

    def test_search_traces_with_name_filter(self):
        mock_client = MagicMock()
        mock_client.api.trace.list.return_value = MagicMock(data=[])

        ops = LangfuseOps.__new__(LangfuseOps)
        ops.host = "https://cloud.langfuse.com"
        ops.client = mock_client

        ops.search_traces(name="bug-repair", limit=3)

        mock_client.api.trace.list.assert_called_once_with(limit=3, name="bug-repair")


class TestLangfuseOpsFormatTraceSummary:
    def test_summary_success(self):
        mock_trace = MagicMock()
        mock_trace.id = "trace-1"
        mock_trace.latency = 5000
        mock_trace.total_cost = 0.05
        mock_trace.usage = {"total_tokens": 300}

        mock_client = MagicMock()
        mock_client.api.trace.get.return_value = mock_trace

        ops = LangfuseOps.__new__(LangfuseOps)
        ops.host = "https://cloud.langfuse.com"
        ops.client = mock_client

        summary = ops.format_trace_summary("trace-1")

        assert "trace-1" in summary
        assert "langfuse.com/trace/trace-1" in summary
        assert "5000" in summary

    def test_summary_failure_returns_error_msg(self):
        mock_client = MagicMock()
        mock_client.api.trace.get.side_effect = Exception("not found")

        ops = LangfuseOps.__new__(LangfuseOps)
        ops.host = "https://cloud.langfuse.com"
        ops.client = mock_client

        summary = ops.format_trace_summary("bad-id")

        assert "获取详情失败" in summary
        assert "bad-id" in summary


class TestLangfuseOpsFlushShutdown:
    def test_flush_calls_client(self):
        mock_client = MagicMock()
        ops = LangfuseOps.__new__(LangfuseOps)
        ops.client = mock_client
        ops.flush()
        mock_client.flush.assert_called_once()

    def test_shutdown_calls_client(self):
        mock_client = MagicMock()
        ops = LangfuseOps.__new__(LangfuseOps)
        ops.client = mock_client
        ops.shutdown()
        mock_client.shutdown.assert_called_once()
