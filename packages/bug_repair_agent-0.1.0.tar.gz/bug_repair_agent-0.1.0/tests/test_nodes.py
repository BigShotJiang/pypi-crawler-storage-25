from unittest.mock import MagicMock, patch

from src.agent.nodes import _call, create_nodes


def test_create_nodes():
    mock_model = MagicMock()
    nodes = create_nodes(mock_model)
    assert len(nodes) == 9
    assert "parse" in nodes
    assert "analyze" in nodes
    assert "locate" in nodes
    assert "fix" in nodes
    assert "build" in nodes
    assert "test" in nodes
    assert "validate" in nodes
    assert "review" in nodes
    assert "report" in nodes
    assert callable(nodes["parse"])


def test_call_json():
    mock_resp = MagicMock()
    mock_resp.content = '{"bug_summary": "test", "severity": "high"}'
    mock_model = MagicMock()
    mock_model.invoke.return_value = mock_resp

    result = _call(mock_model, "prompt")
    assert result["bug_summary"] == "test"
    assert result["severity"] == "high"


def test_call_code_block():
    mock_resp = MagicMock()
    mock_resp.content = '```json\n{"valid": true, "reason": "ok"}\n```'
    mock_model = MagicMock()
    mock_model.invoke.return_value = mock_resp

    result = _call(mock_model, "prompt")
    assert result["valid"] is True


def test_call_extra_text_before_json():
    """LLM 在 JSON 前加了说明文字"""
    mock_resp = MagicMock()
    mock_resp.content = '好的，这是分析结果：\n\n{"bug_summary": "age check wrong", "severity": "high"}'
    mock_model = MagicMock()
    mock_model.invoke.return_value = mock_resp

    result = _call(mock_model, "prompt")
    assert result["bug_summary"] == "age check wrong"


def test_call_extra_text_after_json():
    """LLM 在 JSON 后加了说明文字"""
    mock_resp = MagicMock()
    mock_resp.content = '{"bug_summary": "test", "severity": "low"}\n\n以上是分析结果。'
    mock_model = MagicMock()
    mock_model.invoke.return_value = mock_resp

    result = _call(mock_model, "prompt")
    assert result["bug_summary"] == "test"


def test_call_retry_on_parse_failure():
    """首次解析失败，应重试一次"""
    mock_resp1 = MagicMock()
    mock_resp1.content = '{"invalid json'
    mock_resp2 = MagicMock()
    mock_resp2.content = '{"bug_summary": "retry worked", "severity": "high"}'
    mock_model = MagicMock()
    mock_model.invoke.side_effect = [mock_resp1, mock_resp2]

    result = _call(mock_model, "prompt")
    assert result["bug_summary"] == "retry worked"
    assert mock_model.invoke.call_count == 2


def test_call_unrecoverable():
    """两次都失败，返回错误标记"""
    mock_resp1 = MagicMock()
    mock_resp1.content = "not json at all"
    mock_resp2 = MagicMock()
    mock_resp2.content = "still not json"
    mock_model = MagicMock()
    mock_model.invoke.side_effect = [mock_resp1, mock_resp2]

    result = _call(mock_model, "prompt")
    assert "error" in result


def test_parse_node():
    from src.agent.nodes import parse_node

    mock_resp = MagicMock()
    mock_resp.content = '{"bug_summary": "age check wrong", "error_logs": "", "severity": "high"}'
    mock_model = MagicMock()
    mock_model.invoke.return_value = mock_resp

    state = {
        "bug_report": "用户 18 岁无法注册",
        "repo_path": "/tmp",
        "_model": mock_model,
    }
    result = parse_node(state)
    assert result["bug_summary"] == "age check wrong"
    assert result["severity"] == "high"


def test_fix_node_no_location():
    from src.agent.nodes import fix_node

    state = {
        "target_location": None,
        "bug_summary": "test",
        "root_cause_analysis": "test",
        "_model": MagicMock(),
    }
    result = fix_node(state)
    assert result["needs_rework"] is True
    assert result["patch"] == ""


def test_validate_node_no_patch():
    from src.agent.nodes import validate_node

    state = {
        "target_location": {"file": "app.py"},
        "patch": "",
        "_model": MagicMock(),
    }
    result = validate_node(state)
    assert result["needs_rework"] is True


def test_report_node():
    from src.agent.nodes import report_node

    mock_resp = MagicMock()
    mock_resp.content = '{"pr_title": "fix age", "pr_body": "fixed age check"}'
    mock_model = MagicMock()
    mock_model.invoke.return_value = mock_resp

    state = {
        "bug_summary": "age check wrong",
        "root_cause_analysis": "off-by-one",
        "fix_explanation": "changed > to >=",
        "patch": "--- a/app.py\n+++ b/app.py\n",
        "_model": mock_model,
    }
    result = report_node(state)
    assert result["pr_title"] == "fix age"
    assert result["pr_body"] == "fixed age check"
    assert result["final_status"] == "done"


class TestBuildNode:
    """build_node 测试"""

    def test_build_node_no_patch(self):
        from src.agent.nodes import build_node

        state = {
            "patch": "",
            "target_location": None,
            "_model": MagicMock(),
        }
        result = build_node(state)
        assert result["needs_rework"] is True

    def test_build_node_skip_sandbox(self):
        from src.agent.nodes import build_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        with patch("src.agent.nodes.Sandbox") as MockSandbox:
            mock_sb = MagicMock()
            mock_sb.prepare.return_value = MagicMock(returncode=0)
            mock_sb.apply_patch.return_value = MagicMock(returncode=0)
            mock_sb.run_build.return_value = MagicMock(returncode=0, stdout="", stderr="")
            MockSandbox.return_value = mock_sb

            result = build_node(state)
            assert result["needs_rework"] is False

    def test_build_node_fail(self):
        from src.agent.nodes import build_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        with patch("src.agent.nodes.Sandbox") as MockSandbox:
            mock_sb = MagicMock()
            mock_sb.prepare.return_value = MagicMock(returncode=0)
            mock_sb.apply_patch.return_value = MagicMock(returncode=0)
            mock_sb.run_build.return_value = MagicMock(returncode=1, stdout="", stderr="syntax error")
            MockSandbox.return_value = mock_sb

            result = build_node(state)
            assert result["needs_rework"] is True
            assert "syntax error" in result.get("build_output", "")


class TestTestNode:
    """test_node 测试"""

    def test_test_node_no_patch(self):
        from src.agent.nodes import test_node

        state = {
            "patch": "",
            "target_location": None,
            "_model": MagicMock(),
        }
        result = test_node(state)
        assert result["needs_rework"] is True

    def test_test_node_skip_sandbox(self):
        from src.agent.nodes import test_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        with patch("src.agent.nodes.Sandbox") as MockSandbox:
            mock_sb = MagicMock()
            mock_sb.prepare.return_value = MagicMock(returncode=0)
            mock_sb.apply_patch.return_value = MagicMock(returncode=0)
            mock_sb.run_tests.return_value = MagicMock(returncode=0, stdout="5 passed", stderr="")
            MockSandbox.return_value = mock_sb

            result = test_node(state)
            assert result["needs_rework"] is False
            assert "5 passed" in result.get("test_output", "")


class TestSandboxSharing:
    """沙箱共享测试：build → test → validate 复用同一容器"""

    def test_build_node_stores_container_id(self):
        """build_node 成功后应将 container_id 存入 state"""
        from src.agent.nodes import build_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        with patch("src.agent.nodes.Sandbox") as MockSandbox:
            mock_sb = MagicMock()
            mock_sb.prepare.return_value = MagicMock(returncode=0)
            mock_sb.apply_patch.return_value = MagicMock(returncode=0)
            mock_sb.run_build.return_value = MagicMock(returncode=0, stdout="", stderr="")
            mock_sb.container_id = "abc123"
            MockSandbox.return_value = mock_sb

            result = build_node(state)
            assert result["needs_rework"] is False
            assert result.get("sandbox_container_id") == "abc123"

    def test_test_node_reuses_container(self):
        """test_node 如果有 sandbox_container_id，不应重新创建沙箱"""
        from src.agent.nodes import test_node
        from src.sandbox import CommandResult

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "sandbox_container_id": "abc123",
            "_model": MagicMock(),
        }

        mock_sb = MagicMock()
        mock_sb.run_tests.return_value = CommandResult(0, "3 passed", "")
        mock_sb.container_id = "abc123"

        with patch("src.agent.nodes._sandbox_from_container", return_value=mock_sb):
            result = test_node(state)
            assert result["needs_rework"] is False
            mock_sb.run_tests.assert_called_once()

    def test_test_node_creates_container_if_missing(self):
        """test_node 没有 sandbox_container_id 时应创建新沙箱"""
        from src.agent.nodes import test_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        with patch("src.agent.nodes.Sandbox") as MockSandbox:
            mock_sb = MagicMock()
            mock_sb.prepare.return_value = MagicMock(returncode=0)
            mock_sb.apply_patch.return_value = MagicMock(returncode=0)
            mock_sb.run_tests.return_value = MagicMock(returncode=0, stdout="", stderr="")
            MockSandbox.return_value = mock_sb

            result = test_node(state)
            assert result["needs_rework"] is False
            mock_sb.prepare.assert_called_once()
            mock_sb.apply_patch.assert_called_once()


class TestLocateNodeReAct:
    """locate_node ReAct 工具循环测试"""

    def _make_mock_model(self, responses: list):
        """创建 mock 模型，bind_tools 返回带 invoke 的对象"""
        mock_bound = MagicMock()
        mock_bound.invoke.side_effect = responses

        mock_model = MagicMock()
        mock_model.bind_tools.return_value = mock_bound
        return mock_model

    def test_locate_single_turn_no_tools(self):
        """LLM 直接给出位置，不需要工具调用"""
        from src.agent.nodes import locate_node

        resp1 = MagicMock()
        resp1.content = '{"file": "app.py", "line_start": 10, "line_end": 15, "surrounding_code": "def foo():..."}'
        resp1.tool_calls = []

        mock_model = self._make_mock_model([resp1])
        state = {
            "bug_summary": "test",
            "root_cause_analysis": "test",
            "repo_path": "/tmp",
            "_model": mock_model,
        }
        result = locate_node(state)
        assert result["target_location"]["file"] == "app.py"
        assert result["target_location"]["line_start"] == 10

    def test_locate_multi_turn_with_tools(self):
        """LLM 先用 search_code，再用 read_file，最后给出位置"""
        from src.agent.nodes import locate_node

        # 第一次调用：返回 search_code 工具调用
        resp1 = MagicMock()
        resp1.content = "我需要搜索 age 相关的代码"
        resp1.tool_calls = [{"name": "search_code", "args": {"pattern": "age", "repo_path": "/tmp"}, "id": "tc1"}]
        # 第二次调用：返回 read_file 工具调用
        resp2 = MagicMock()
        resp2.content = "让我读取这个文件"
        resp2.tool_calls = [
            {"name": "read_file", "args": {"file_path": "services/user.py", "repo_path": "/tmp"}, "id": "tc2"}
        ]
        # 第三次调用：不再请求工具，直接输出位置 JSON
        resp3 = MagicMock()
        resp3.content = (
            '{"file": "services/user.py", "line_start": 12, "line_end": 15, "surrounding_code": "if age > 18"}'
        )
        resp3.tool_calls = []

        mock_model = self._make_mock_model([resp1, resp2, resp3])

        state = {
            "bug_summary": "age check wrong",
            "root_cause_analysis": "off-by-one",
            "repo_path": "/tmp",
            "_model": mock_model,
        }
        result = locate_node(state)

        mock_bound = mock_model.bind_tools.return_value
        assert mock_bound.invoke.call_count == 3
        assert result["target_location"]["file"] == "services/user.py"
        assert result["target_location"]["line_start"] == 12
        assert len(result["search_results"]) >= 2

    def test_locate_max_turns(self):
        """超过最大轮次应停止并返回已有结果"""
        from src.agent.nodes import locate_node

        # 每次都返回工具调用，模拟 LLM 持续请求工具
        tool_resp = MagicMock()
        tool_resp.content = "继续搜索"
        tool_resp.tool_calls = [{"name": "search_code", "args": {"pattern": "x", "repo_path": "/tmp"}, "id": "tc1"}]

        mock_model = self._make_mock_model([tool_resp] * 10)

        state = {
            "bug_summary": "test",
            "root_cause_analysis": "test",
            "repo_path": "/tmp",
            "_model": mock_model,
        }
        result = locate_node(state)

        mock_bound = mock_model.bind_tools.return_value
        # 应该不超过 MAX_TURNS 次调用
        assert mock_bound.invoke.call_count <= 5
        # 没有精确定位时，target_location 应为 None 或包含搜索结果
        assert result.get("target_location") is None or len(result["search_results"]) > 0


class TestAnalyzeNode:
    """analyze_node 测试"""

    def test_analyze_node_injects_file_content(self):
        """analyze_node 应读取源码内容并传给 LLM"""
        from src.agent.nodes import analyze_node

        mock_resp = MagicMock()
        mock_resp.content = '{"root_cause_analysis": "age > 18 is wrong", "hypothesis": "off-by-one", "confidence": 0.9, "target_files": ["app.py"]}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "bug_report": "test",
            "bug_summary": "age check wrong",
            "error_logs": "ValueError: age 18",
            "repo_path": "/tmp/test_repo",
            "_model": mock_model,
        }
        with patch("src.agent.nodes.list_files") as mock_list, patch("src.agent.nodes.read_file") as mock_read:
            mock_list.invoke.return_value = "app.py\nmodels.py\nutils.py"
            mock_read.invoke.side_effect = lambda args: {
                "app.py": "def register(age):\n    if age > 18:\n        raise ValueError(...)",
                "models.py": "class User: pass",
                "utils.py": "def format_date(dt): return dt.strftime('%Y-%m-%d')",
            }.get(args.get("file_path", ""), "")

            result = analyze_node(state)

            assert mock_read.invoke.call_count >= 1
            assert result["root_cause_analysis"] == "age > 18 is wrong"
            assert result["target_files"] == ["app.py"]

    def test_analyze_node_handles_no_files(self):
        """仓库无源码时不应崩溃"""
        from src.agent.nodes import analyze_node

        mock_resp = MagicMock()
        mock_resp.content = (
            '{"root_cause_analysis": "unknown", "hypothesis": "no files", "confidence": 0.1, "target_files": []}'
        )
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "bug_report": "test",
            "bug_summary": "test",
            "error_logs": "",
            "repo_path": "/tmp/empty",
            "_model": mock_model,
        }
        with patch("src.agent.nodes.list_files") as mock_list, patch("src.agent.nodes.read_file") as mock_read:
            mock_list.invoke.return_value = ""
            mock_read.invoke.return_value = ""

            result = analyze_node(state)
            assert "root_cause_analysis" in result


class TestReviewNode:
    """review_node 测试"""

    def test_review_node_no_patch(self):
        from src.agent.nodes import review_node

        state = {
            "patch": "",
            "target_location": None,
            "_model": MagicMock(),
        }
        result = review_node(state)
        assert result["needs_rework"] is True

    def test_review_node_safe(self):
        from src.agent.nodes import review_node

        mock_resp = MagicMock()
        mock_resp.content = '{"safe": true, "concerns": [], "suggestion": ""}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": {"file": "app.py"},
            "bug_summary": "test bug",
            "root_cause_analysis": "test root cause",
            "_model": mock_model,
        }
        result = review_node(state)
        assert result["needs_rework"] is False
        assert result["review_result"] == "PASS"

    def test_review_node_unsafe(self):
        from src.agent.nodes import review_node

        mock_resp = MagicMock()
        mock_resp.content = '{"safe": false, "concerns": ["可能的 SQL 注入"], "suggestion": "使用参数化查询"}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "patch": '--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+query("SELECT * FROM users WHERE id=" + user_id)\n',
            "target_location": {"file": "app.py"},
            "bug_summary": "test bug",
            "root_cause_analysis": "test root cause",
            "_model": mock_model,
        }
        result = review_node(state)
        assert result["needs_rework"] is True
        assert "SQL" in result.get("review_output", "")


class TestFixNode:
    """fix_node 测试"""

    def test_fix_node_with_location(self):
        from src.agent.nodes import fix_node

        mock_resp = MagicMock()
        mock_resp.content = '{"patch": "diff content here", "fix_explanation": "fixed"}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp
        mock_model.bind_tools.return_value = mock_model

        state = {
            "bug_summary": "test",
            "root_cause_analysis": "test",
            "target_location": {"file": "app.py"},
            "repo_path": "/tmp",
            "_model": mock_model,
        }
        with patch("src.agent.nodes.read_file") as mock_read:
            mock_read.invoke.return_value = "old code"
            result = fix_node(state)
            assert result["patch"] == "diff content here"
            assert result["fix_explanation"] == "fixed"


class TestValidateNode:
    """validate_node 测试（沙箱内 lint）"""

    def test_validate_node_with_container(self):
        from src.agent.nodes import validate_node
        from src.sandbox import CommandResult

        mock_resp = MagicMock()
        mock_resp.content = '{"valid": true, "reason": "ok", "suggestion": ""}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "bug_summary": "test",
            "root_cause_analysis": "test",
            "target_location": {"file": "app.py"},
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "sandbox_container_id": "abc123",
            "repo_path": "/tmp",
            "_model": mock_model,
        }
        mock_sb = MagicMock()
        mock_sb.run_lint.return_value = CommandResult(0, "ok", "")

        with patch("src.agent.nodes._sandbox_from_container", return_value=mock_sb):
            result = validate_node(state)
            assert result["validation_result"] == "PASS"
            assert result["needs_rework"] is False

    def test_validate_node_without_container(self):
        from src.agent.nodes import validate_node

        mock_resp = MagicMock()
        mock_resp.content = '{"valid": true, "reason": "ok", "suggestion": ""}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "bug_summary": "test",
            "root_cause_analysis": "test",
            "target_location": {"file": "app.py"},
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "repo_path": "/tmp",
            "_model": mock_model,
        }
        result = validate_node(state)
        assert result["validation_result"] == "PASS"


class TestReportNodeCleanup:
    """report_node 沙箱清理测试"""

    def test_report_node_with_container_cleanup(self):
        from src.agent.nodes import report_node

        mock_resp = MagicMock()
        mock_resp.content = '{"pr_title": "test", "pr_body": "body"}'
        mock_model = MagicMock()
        mock_model.invoke.return_value = mock_resp

        state = {
            "bug_summary": "test",
            "root_cause_analysis": "test",
            "fix_explanation": "fixed",
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "sandbox_container_id": "abc123",
            "repo_path": "/tmp",
            "langfuse_trace_id": "",
            "_model": mock_model,
        }
        mock_sb = MagicMock()
        mock_sb.destroy = MagicMock()

        with patch("src.agent.nodes._sandbox_from_container", return_value=mock_sb):
            result = report_node(state)
            assert result["final_status"] == "done"
            mock_sb.destroy.assert_called_once()


class TestBuildNodeEdgeCases:
    """build_node 边界情况"""

    def test_build_node_no_location(self):
        from src.agent.nodes import build_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": None,
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        result = build_node(state)
        assert result["needs_rework"] is True
        assert result["build_result"] == "SKIP"


class TestTestNodeEdgeCases:
    """test_node 边界情况"""

    def test_test_node_no_location(self):
        from src.agent.nodes import test_node

        state = {
            "patch": "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-old\n+new\n",
            "target_location": None,
            "repo_path": "/tmp",
            "_model": MagicMock(),
        }
        result = test_node(state)
        assert result["needs_rework"] is True
        assert result["test_result"] == "SKIP"


class TestPrintStep:
    """CLI _print_step 测试"""

    def test_print_step_verbose_false(self):
        from src.cli import _step_status

        assert _step_status("parse", {"bug_summary": "test"}) == "PASS"
        assert _step_status("build", {"build_result": "PASS"}) == "PASS"
        assert _step_status("build", {"build_result": "FAIL"}) == "FAIL"
        assert _step_status("test", {"test_result": "PASS"}) == "PASS"

    def test_print_step_with_location(self):
        from src.cli import _step_status

        result = _step_status("locate", {"target_location": {"file": "app.py"}})
        assert "PASS" in result
        assert "app.py" in result
