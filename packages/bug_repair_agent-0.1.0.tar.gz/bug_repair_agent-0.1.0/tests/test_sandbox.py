"""沙箱环境测试 — 验证 Docker 隔离构建能力"""

import os
import tempfile

import pytest

from src.sandbox import Sandbox, detect_language_from_repo

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEMO_REPO = os.path.join(REPO_ROOT, "demo", "buggy_repo")


class TestSandboxLifecycle:
    """沙箱生命周期"""

    def test_sandbox_create_destroy(self):
        """创建和销毁沙箱"""
        sandbox = Sandbox(repo_path=DEMO_REPO)
        assert sandbox.container_id is None
        # 不实际跑 Docker，只测接口
        assert sandbox.repo_path == DEMO_REPO
        assert sandbox.language == "python"

    def test_sandbox_default_timeout(self):
        sandbox = Sandbox(repo_path=DEMO_REPO)
        assert sandbox.timeout == 120  # 默认 120 秒

    def test_sandbox_custom_timeout(self):
        sandbox = Sandbox(repo_path=DEMO_REPO, timeout=60)
        assert sandbox.timeout == 60


class TestLanguageDetection:
    """语言检测"""

    def test_detect_python(self):
        assert detect_language_from_repo(DEMO_REPO) == "python"

    def test_detect_go(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "main.go"), "w") as f:
                f.write("package main")
            assert detect_language_from_repo(tmpdir) == "go"

    def test_detect_typescript(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "index.ts"), "w") as f:
                f.write("const x = 1;")
            assert detect_language_from_repo(tmpdir) == "typescript"

    def test_detect_javascript(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "index.js"), "w") as f:
                f.write("const x = 1;")
            assert detect_language_from_repo(tmpdir) == "javascript"

    def test_detect_mixed_prefers_python(self):
        """混合语言时按优先级返回"""
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "main.py"), "w") as f:
                f.write("x = 1")
            with open(os.path.join(tmpdir, "index.ts"), "w") as f:
                f.write("const x = 1;")
            # Python 优先级最高
            assert detect_language_from_repo(tmpdir) == "python"

    def test_detect_unknown(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "main.rs"), "w") as f:
                f.write("fn main() {}")
            assert detect_language_from_repo(tmpdir) is None


class TestSandboxCommands:
    """沙箱命令执行（需要 Docker）"""

    @pytest.mark.skipif(not os.path.exists("/var/run/docker.sock"), reason="Docker 不可用")
    def test_sandbox_run_command(self):
        sandbox = Sandbox(repo_path=DEMO_REPO)
        try:
            sandbox.prepare()
            result = sandbox.run_command(["python3", "--version"])
            assert result.returncode == 0
            assert "Python" in result.stdout
        finally:
            sandbox.destroy()

    @pytest.mark.skipif(not os.path.exists("/var/run/docker.sock"), reason="Docker 不可用")
    def test_sandbox_apply_patch(self):
        sandbox = Sandbox(repo_path=DEMO_REPO)
        try:
            sandbox.prepare()
            # 应用一个不存在的补丁应该失败
            patch = "--- a/app.py\n+++ b/app.py\n@@ -1,3 +1,3 @@\n-old\n+new\n"
            result = sandbox.apply_patch(patch)
            # patch 命令可能返回非 0（因为行号对不上），但不应该崩溃
            assert isinstance(result.returncode, int)
        finally:
            sandbox.destroy()
