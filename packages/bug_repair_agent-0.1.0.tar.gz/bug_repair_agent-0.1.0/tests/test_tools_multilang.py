"""多语言工具测试 — 验证 Go/TypeScript 的 lint 和文件扫描能力"""

import os
import subprocess
import tempfile

import pytest

from src.agent.tools import _binary_exists, list_files, run_lint

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEMO_REPO = os.path.join(REPO_ROOT, "demo", "buggy_repo")


class TestListFiles:
    """多语言文件扫描"""

    def test_list_python_files(self):
        result = list_files.invoke({"repo_path": DEMO_REPO})
        assert "app.py" in result
        assert "models.py" in result

    def test_list_all_files(self):
        """扫描所有支持的语言文件"""
        result = list_files.invoke({"repo_path": DEMO_REPO, "extensions": [".py", ".go", ".ts", ".js"]})
        assert "app.py" in result

    def test_list_specific_extension(self):
        result = list_files.invoke({"repo_path": DEMO_REPO, "extensions": [".go"]})
        assert result == ""  # demo 仓库没有 .go 文件


class TestRunLint:
    """多语言 lint 检查"""

    def test_python_syntax_pass(self):
        result = run_lint.invoke({"file_path": "utils.py", "repo_path": DEMO_REPO})
        assert "PASS" in result

    def test_python_syntax_fail(self):
        result = run_lint.invoke({"file_path": "nonexistent.py", "repo_path": DEMO_REPO})
        assert "FAIL" in result

    @pytest.mark.skipif(not _binary_exists("gofmt") and not _binary_exists("go"), reason="gofmt 或 go 未安装")
    def test_go_lint_pass(self):
        """Go 文件有有效语法时 PASS"""
        with tempfile.TemporaryDirectory() as tmpdir:
            go_file = os.path.join(tmpdir, "hello.go")
            with open(go_file, "w") as f:
                f.write('package main\n\nfunc main() {\n\tprintln("hello")\n}\n')
            result = run_lint.invoke({"file_path": "hello.go", "repo_path": tmpdir})
            assert "PASS" in result or "SKIP" in result

    @pytest.mark.skipif(not _binary_exists("gofmt") and not _binary_exists("go"), reason="gofmt 或 go 未安装")
    def test_go_lint_fail(self):
        """Go 文件有语法错误时 FAIL"""
        with tempfile.TemporaryDirectory() as tmpdir:
            go_file = os.path.join(tmpdir, "bad.go")
            with open(go_file, "w") as f:
                f.write('package main\n\nfunc main() {\n\tprintln("hello"\n}\n')  # 缺括号
            result = run_lint.invoke({"file_path": "bad.go", "repo_path": tmpdir})
            assert "FAIL" in result or "SKIP" in result

    def test_typescript_lint_no_binary(self):
        """TypeScript 检测 — npx 不存在时 SKIP"""
        with tempfile.TemporaryDirectory() as tmpdir:
            ts_file = os.path.join(tmpdir, "hello.ts")
            with open(ts_file, "w") as f:
                f.write('const msg: string = "hello";\nconsole.log(msg);\n')
            result = run_lint.invoke({"file_path": "hello.ts", "repo_path": tmpdir})
            # npx 不存在时返回 SKIP，存在时可能返回 PASS 或 INFO
            assert "FAIL" not in result or "tsc" in result

    def test_unsupported_language(self):
        """不支持的语言返回提示"""
        with tempfile.TemporaryDirectory() as tmpdir:
            rust_file = os.path.join(tmpdir, "main.rs")
            with open(rust_file, "w") as f:
                f.write('fn main() { println!("hello"); }\n')
            result = run_lint.invoke({"file_path": "main.rs", "repo_path": tmpdir})
            assert "不支持" in result or "UNSUPPORTED" in result


class TestSearchCode:
    """多语言代码搜索"""

    def test_search_go_files(self):
        result = subprocess.run(["grep", "-rn", "--include=*.go", "test", DEMO_REPO], capture_output=True, text=True)
        # demo 仓库没有 .go 文件
        assert result.stdout.strip() == ""
