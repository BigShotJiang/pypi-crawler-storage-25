import os

from src.agent.tools import list_files, read_file, run_lint, search_code

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEMO_REPO = os.path.join(REPO_ROOT, "demo", "buggy_repo")


def test_read_file_exists():
    result = read_file.invoke({"file_path": "app.py", "repo_path": DEMO_REPO})
    assert "def register_user" in result
    assert "age" in result


def test_read_file_not_found():
    result = read_file.invoke({"file_path": "nonexistent.py", "repo_path": DEMO_REPO})
    assert "ERROR" in result


def test_search_code_finds_match():
    result = search_code.invoke({"pattern": "age", "repo_path": DEMO_REPO})
    assert "app.py" in result


def test_search_code_no_match():
    result = search_code.invoke({"pattern": "zzzznonexistent", "repo_path": DEMO_REPO})
    assert "未找到" in result


def test_list_files():
    result = list_files.invoke({"repo_path": DEMO_REPO})
    assert "app.py" in result
    assert "models.py" in result
    assert "utils.py" in result


def test_run_lint_pass():
    result = run_lint.invoke({"file_path": "utils.py", "repo_path": DEMO_REPO})
    assert "PASS" in result


def test_run_lint_fail():
    result = run_lint.invoke({"file_path": "nonexistent.py", "repo_path": DEMO_REPO})
    assert "FAIL" in result
