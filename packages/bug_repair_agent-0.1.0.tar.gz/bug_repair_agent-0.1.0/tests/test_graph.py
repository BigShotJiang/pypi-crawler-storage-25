from unittest.mock import MagicMock

from src.agent.graph import build_graph


def test_build_graph_structure():
    mock_model = MagicMock()
    graph = build_graph(mock_model)

    nodes = list(graph.get_graph().nodes.keys())
    expected = {"parse", "analyze", "locate", "fix", "build", "test", "validate", "review", "report"}
    assert expected.issubset(set(nodes))


def test_build_graph_edges():
    mock_model = MagicMock()
    graph = build_graph(mock_model)
    g = graph.get_graph()

    edges = [(e.source, e.target) for e in g.edges]
    assert ("parse", "analyze") in edges
    assert ("analyze", "locate") in edges
    assert ("locate", "fix") in edges
    assert ("fix", "build") in edges
    assert ("build", "test") in edges
    assert ("test", "validate") in edges
    assert ("validate", "review") in edges
    assert ("review", "report") in edges
    assert ("report", "__end__") in edges


def test_rework_router_validate_to_fix():
    """validate 失败且 rework_target=fix 时应回跳 fix"""
    from src.agent.graph import build_graph

    mock_model = MagicMock()
    graph = build_graph(mock_model)
    g = graph.get_graph()

    # 验证 validate 的条件边支持 fix 路由
    validate_edges = [e for e in g.edges if e.source == "validate"]
    targets = {e.target for e in validate_edges}
    # 应该有到 locate、fix、review 的边
    assert "fix" in targets or "locate" in targets  # at minimum has routing


def test_rework_router_count_limit():
    """rework_count >= 3 时应继续前进而非返工"""
    from src.agent.graph import build_graph

    mock_model = MagicMock()
    graph = build_graph(mock_model)
    # 验证图可以正常构建
    assert graph is not None
