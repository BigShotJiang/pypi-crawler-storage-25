from src.agent.state import CodeLocation, RepairAgentState


def test_code_location_defaults():
    loc: CodeLocation = {"file": "app.py"}
    assert loc["file"] == "app.py"


def test_code_location_full():
    loc: CodeLocation = {
        "file": "app.py",
        "line_start": 10,
        "line_end": 20,
        "surrounding_code": "context",
    }
    assert loc["line_start"] == 10
    assert loc["surrounding_code"] == "context"


def test_repair_agent_state_defaults():
    state: RepairAgentState = {
        "bug_report": "",
        "repo_path": "",
        "bug_summary": "",
        "root_cause_analysis": "",
        "target_files": [],
        "target_location": None,
        "search_results": [],
        "patch": "",
        "fix_explanation": "",
        "build_result": "",
        "build_output": "",
        "test_result": "",
        "test_output": "",
        "review_result": "",
        "review_output": "",
        "review_suggestion": "",
        "validation_result": "",
        "validation_output": "",
        "pr_body": "",
        "pr_title": "",
        "needs_rework": False,
        "rework_count": 0,
        "rework_target": "",
        "final_status": "",
    }
    assert state["needs_rework"] is False
    assert state["rework_count"] == 0
    assert state["target_files"] == []
    assert state["build_result"] == ""
    assert state["review_suggestion"] == ""
    assert state["rework_target"] == ""


def test_repair_agent_state_update():
    state: RepairAgentState = {
        "bug_report": "test report",
        "repo_path": "/path",
        "bug_summary": "",
        "root_cause_analysis": "",
        "target_files": [],
        "target_location": None,
        "search_results": [],
        "patch": "",
        "fix_explanation": "",
        "build_result": "",
        "build_output": "",
        "test_result": "",
        "test_output": "",
        "review_result": "",
        "review_output": "",
        "review_suggestion": "",
        "validation_result": "",
        "validation_output": "",
        "pr_body": "",
        "pr_title": "",
        "needs_rework": False,
        "rework_count": 0,
        "rework_target": "",
        "final_status": "",
    }
    state["bug_summary"] = "off-by-one"
    state["rework_count"] = 1
    state["build_result"] = "PASS"
    state["review_result"] = "PASS"
    assert state["bug_summary"] == "off-by-one"
    assert state["rework_count"] == 1
    assert state["build_result"] == "PASS"
    assert state["rework_target"] == ""


def test_repair_agent_state_rework_target():
    state: RepairAgentState = {
        "bug_report": "",
        "repo_path": "",
        "bug_summary": "",
        "root_cause_analysis": "",
        "target_files": [],
        "target_location": None,
        "search_results": [],
        "patch": "",
        "fix_explanation": "",
        "build_result": "",
        "build_output": "",
        "test_result": "",
        "test_output": "",
        "review_result": "",
        "review_output": "",
        "review_suggestion": "",
        "validation_result": "",
        "validation_output": "",
        "pr_body": "",
        "pr_title": "",
        "needs_rework": False,
        "rework_count": 0,
        "rework_target": "",
        "final_status": "",
    }
    state["needs_rework"] = True
    state["rework_target"] = "fix"
    assert state["needs_rework"] is True
    assert state["rework_target"] == "fix"
