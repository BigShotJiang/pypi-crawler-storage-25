"""集成测试：验证图结构和关键行为"""

import os
import sys
from unittest.mock import MagicMock

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO_ROOT)

from src.agent.graph import build_graph  # noqa: E402
from src.agent.state import RepairAgentState  # noqa: E402


def test_graph_has_all_nodes():
    mock_model = MagicMock()
    graph = build_graph(mock_model)
    node_names = list(graph.get_graph().nodes.keys())
    expected = {
        "parse",
        "analyze",
        "locate",
        "fix",
        "build",
        "test",
        "validate",
        "review",
        "report",
        "__start__",
        "__end__",
    }
    assert expected.issubset(set(node_names))


def test_graph_has_correct_edges():
    mock_model = MagicMock()
    graph = build_graph(mock_model)
    edges = [(e.source, e.target) for e in graph.get_graph().edges]
    assert ("parse", "analyze") in edges
    assert ("analyze", "locate") in edges
    assert ("locate", "fix") in edges
    assert ("fix", "build") in edges
    assert ("build", "test") in edges
    assert ("test", "validate") in edges
    assert ("validate", "review") in edges
    assert ("review", "report") in edges
    assert ("report", "__end__") in edges


def test_graph_conditional_edges():
    """validate 和 review 节点都有条件边：rework → locate, done → 下一步"""
    mock_model = MagicMock()
    graph = build_graph(mock_model)
    edges = graph.get_graph().edges

    # validate 可以回到 locate 或去 review
    validate_edges = [e for e in edges if e.source == "validate"]
    validate_targets = {e.target for e in validate_edges}
    assert "locate" in validate_targets
    assert "review" in validate_targets

    # review 可以回到 locate 或去 report
    review_edges = [e for e in edges if e.source == "review"]
    review_targets = {e.target for e in review_edges}
    assert "locate" in review_targets
    assert "report" in review_targets


def test_state_is_typed_dict():
    """验证状态类型包含所有必需字段"""
    required = {
        "bug_report",
        "repo_path",
        "bug_summary",
        "root_cause_analysis",
        "target_files",
        "target_location",
        "patch",
        "pr_title",
        "pr_body",
        "needs_rework",
        "rework_count",
        "final_status",
        "build_result",
        "build_output",
        "test_result",
        "test_output",
        "review_result",
        "review_output",
        "review_suggestion",
    }
    assert required.issubset(set(RepairAgentState.__annotations__.keys()))


def test_rework_count_increments():
    """验证返工计数逻辑"""
    mock_model = MagicMock()
    _graph = build_graph(mock_model)

    # 模拟 check_rework 条件边的行为
    state = {"needs_rework": True, "rework_count": 0}
    if state["needs_rework"] and state["rework_count"] < 3:
        state["rework_count"] += 1
    assert state["rework_count"] == 1
    assert state["needs_rework"] is True  # 仍为 True，会再次循环

    # 第三次返工后
    state["rework_count"] = 3
    # 此时应该走 done 分支
    should_rework = state["needs_rework"] and state["rework_count"] < 3
    assert should_rework is False
