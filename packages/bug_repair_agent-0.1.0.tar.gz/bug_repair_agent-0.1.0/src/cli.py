from pathlib import Path
from typing import Any

import typer
from langchain_anthropic import ChatAnthropic
from rich.console import Console
from rich.panel import Panel

from src.agent.graph import build_graph
from src.config import (
    get_api_key,
    get_demo_inventory,
    get_demo_repo,
    get_model,
    get_webhook_port,
    is_langfuse_enabled,
)

app = typer.Typer(help="Bug Repair Agent — 自动修复服务问题")
console = Console()


def _make_graph() -> Any:
    api_key = get_api_key()
    model_name = get_model()
    model = ChatAnthropic(model=model_name, api_key=api_key)  # type: ignore[arg-type, call-arg]
    return build_graph(model)


def _default_initial(repo_path: str, report_text: str) -> dict[str, Any]:
    """构建默认初始状态"""
    return {
        "bug_report": report_text,
        "repo_path": repo_path,
        "bug_summary": "",
        "error_logs": "",
        "severity": "",
        "root_cause_analysis": "",
        "hypothesis": "",
        "confidence": 0.0,
        "target_files": [],
        "target_location": None,
        "search_results": [],
        "patch": "",
        "fix_explanation": "",
        "build_result": "",
        "build_output": "",
        "test_result": "",
        "test_output": "",
        "review_result": "",
        "review_output": "",
        "review_suggestion": "",
        "validation_result": "",
        "validation_output": "",
        "pr_body": "",
        "pr_title": "",
        "langfuse_trace_id": "",
        "sandbox_container_id": "",
        "rework_target": "",
        "needs_rework": False,
        "rework_count": 0,
        "final_status": "",
    }


def _run_graph(
    repo_path: str,
    report_text: str,
    verbose: bool = False,
) -> dict[str, Any]:
    """运行修复流程，支持可选的 Langfuse 追踪和 verbose 输出。"""
    graph = _make_graph()
    initial = _default_initial(repo_path, report_text)

    if is_langfuse_enabled():
        from langfuse import observe

        @observe(name="bug-repair-run", as_type="agent")
        def _observed_run() -> dict[str, Any]:
            result: dict[str, Any] = {}
            for step, output in graph.stream(initial, stream_mode="updates"):
                result = output
                _print_step(step, output, verbose=verbose)
            return result

        result = _observed_run()
    else:
        fallback_result: dict[str, Any] = {}
        for step, output in graph.stream(initial, stream_mode="updates"):
            fallback_result = output
            _print_step(step, output, verbose=verbose)
        result = fallback_result

    return result


@app.command("run")
def run(
    report_path: str = typer.Option(..., "--report", "-r", help="日报文件路径"),
    repo_path: str = typer.Option(None, "--repo", help="仓库路径"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="打印每个节点的详细输出"),
) -> None:
    """指定日报运行 Agent"""
    report_text = Path(report_path).read_text()
    repo = repo_path or get_demo_repo()

    console.print(Panel(f"日报：{report_path}", title="输入", border_style="cyan"))

    result = _run_graph(repo, report_text, verbose=verbose)
    _print_result(result)


@app.command("demo")
def demo(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="打印每个节点的详细输出"),
):
    """用内置 demo 演示（库存超卖场景）"""
    demo_dir = get_demo_inventory()
    report_path = Path(demo_dir) / "reports" / "report_001.md"
    if not report_path.exists():
        console.print(f"[red]Demo 日报不存在：{report_path}[/red]")
        raise typer.Exit(1)
    run(str(report_path), demo_dir, verbose=verbose)


# ── Webhook 服务模式 ────────────────────────────────────────────


@app.command("serve")
def serve(
    host: str = typer.Option("0.0.0.0", "--host", help="监听地址"),
    port: int = typer.Option(None, "--port", "-p", help="监听端口（默认从配置读取）"),
) -> None:
    """启动 Webhook 服务，接收告警并自动修复"""
    try:
        import uvicorn
        from fastapi import FastAPI, Request
        from fastapi.responses import JSONResponse
    except ImportError:
        console.print("[red]需要安装 fastapi 和 uvicorn: pip install fastapi uvicorn[/red]")
        raise typer.Exit(1) from None

    api_port = port or get_webhook_port()

    api_app = FastAPI(title="Bug Repair Agent")

    @api_app.post("/webhook/bug")  # type: ignore[untyped-decorator]
    async def handle_bug(request: Request) -> JSONResponse:
        """接收 bug 告警"""
        body = await request.json()
        report_text = body.get("report", body.get("message", ""))
        repo_path = body.get("repo_path", get_demo_repo())

        console.print(f"[green]收到 bug 告警，仓库：{repo_path}[/green]")

        try:
            from langfuse import observe

            @observe(name="bug-repair-webhook", as_type="agent")
            def _observed_run(rp: str, rt: str) -> dict[str, Any]:
                result: dict[str, Any] = {}
                graph = _make_graph()
                initial = _default_initial(rp, rt)
                for step, output in graph.stream(initial, stream_mode="updates"):
                    result = output
                    console.print(f"  [dim]{step}[/dim]")
                return result

            result = _observed_run(repo_path, report_text)

            return JSONResponse(
                {
                    "status": result.get("final_status", "done"),
                    "pr_title": result.get("pr_title", ""),
                    "pr_body": result.get("pr_body", ""),
                    "rework_count": result.get("rework_count", 0),
                }
            )
        except Exception as e:
            console.print(f"[red]处理失败: {e}[/red]")
            return JSONResponse({"status": "error", "error": str(e)}, status_code=500)

    @api_app.get("/health")
    async def health():
        return {"status": "ok"}

    console.print(
        Panel(
            f"Webhook 服务启动\n地址：http://{host}:{api_port}\n告警端点：POST /webhook/bug\n健康检查：GET /health",
            title="服务",
            border_style="green",
        )
    )

    uvicorn.run(api_app, host=host, port=api_port)


_STEP_ORDER = ["parse", "analyze", "locate", "fix", "build", "test", "validate", "review", "report"]

_STEP_TITLES = {
    "parse": "解析日报",
    "analyze": "根因分析",
    "locate": "定位代码",
    "fix": "生成补丁",
    "build": "构建验证",
    "test": "运行测试",
    "validate": "验证修复",
    "review": "安全审查",
    "report": "生成 PR",
}


def _print_step(step: str, output: dict[str, Any], verbose: bool = False) -> None:
    """打印单步执行结果"""
    title = _STEP_TITLES.get(step, step)
    try:
        step_num = _STEP_ORDER.index(step) + 1
        header = f"[{step_num}/{len(_STEP_ORDER)}] {title}"
    except ValueError:
        header = title

    if not verbose:
        # 非 verbose 模式：简洁输出
        status = _step_status(step, output)
        console.print(f"  {header} → {status}")
        return

    # verbose 模式：详细输出
    lines = []
    for k, v in output.items():
        if k in ("_model", "langfuse_trace_id", "sandbox_container_id", "rework_target", "final_status"):
            continue
        if k.startswith("rework") and k != "rework_count":
            continue
        if v is None or v == "" or v == [] or v is False:
            continue
        if isinstance(v, dict):
            for dk, dv in v.items():
                lines.append(f"  {dk}: {dv}")
        elif isinstance(v, list):
            if v:
                lines.append(f"  {k}: {len(v)} 条结果")
                for item in v[:3]:
                    if isinstance(item, dict):
                        lines.append(f"    - {item}")
        else:
            lines.append(f"  {k}: {v}")

    status = _step_status(step, output)
    rework = output.get("rework_count", 0)
    rework_suffix = f" (返工 {rework} 次)" if rework > 0 else ""

    console.print(Panel("\n".join(lines), title=f"{header} → {status}{rework_suffix}", border_style="green"))


def _step_status(step: str, output: dict[str, Any]) -> str:
    """提取步骤状态"""
    status_keys = {
        "parse": "bug_summary",
        "analyze": "hypothesis",
        "locate": "target_location",
        "fix": "patch",
        "build": "build_result",
        "test": "test_result",
        "validate": "validation_result",
        "review": "review_result",
        "report": "pr_title",
    }
    key = status_keys.get(step)
    if key and output.get(key):
        val = output[key]
        if isinstance(val, dict):
            return f"PASS ({val.get('file', '')})"
        if isinstance(val, str) and val in ("PASS", "FAIL", "SKIP"):
            return val
        return "PASS"
    if output.get("needs_rework"):
        return "FAIL"
    return "完成"


def _print_result(output: dict[str, Any]) -> None:
    console.print("\n" + "=" * 60)
    console.print(
        Panel(
            f"标题：{output.get('pr_title', '')}\n\n{output.get('pr_body', '')}",
            title="PR 输出",
            border_style="blue",
        )
    )


def main() -> None:
    app()


if __name__ == "__main__":
    main()
