"""Langfuse 操作封装 — trace 获取、搜索、URL 生成"""

from __future__ import annotations

from typing import Any, Optional

from langfuse import Langfuse


class LangfuseOps:
    """Langfuse 操作封装。

    负责：
    - 获取 trace 详细信息
    - 搜索 trace
    - 生成 trace Dashboard URL
    """

    def __init__(self, host: str, public_key: str, secret_key: str):
        self.host = host.rstrip("/")
        self.client = Langfuse(
            public_key=public_key,
            secret_key=secret_key,
            host=self.host,
        )

    def get_trace_details(self, trace_id: str) -> dict[str, Any]:
        """获取 trace 详细信息（LLM 调用链、Token 消耗、延迟等）"""
        trace = self.client.api.trace.get(trace_id)
        return {
            "id": trace.id,
            "name": trace.name,
            "input": trace.input,
            "output": trace.output,
            "latency": trace.latency,
            "total_cost": trace.total_cost,
            "usage": {
                "prompt_tokens": getattr(trace, "usage", {}).get("prompt_tokens", 0),
                "completion_tokens": getattr(trace, "usage", {}).get("completion_tokens", 0),
                "total_tokens": getattr(trace, "usage", {}).get("total_tokens", 0),
            },
            "observations": [
                {
                    "id": obs.id,
                    "name": obs.name,
                    "type": obs.type,
                    "latency": getattr(obs, "latency", None),
                    "usage": getattr(obs, "usage", {}),
                }
                for obs in trace.observations
            ],
            "scores": [
                {
                    "name": s.name,
                    "value": s.value,
                    "comment": getattr(s, "comment", ""),
                }
                for s in trace.scores
            ],
        }

    def search_traces(
        self,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
        tags: Optional[list[str]] = None,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """按条件搜索 trace"""
        params: dict[str, Any] = {"limit": limit}
        if name:
            params["name"] = name
        if user_id:
            params["user_id"] = user_id
        if tags:
            params["tags"] = tags

        response = self.client.api.trace.list(**params)
        return [
            {
                "id": t.id,
                "name": t.name,
                "timestamp": t.timestamp,
                "latency": t.latency,
                "total_cost": t.total_cost,
            }
            for t in response.data
        ]

    def get_trace_url(self, trace_id: str) -> str:
        """获取 trace 的 Dashboard URL"""
        return f"{self.host}/trace/{trace_id}"

    def flush(self) -> None:
        """刷新缓冲区，确保所有 trace 数据已发送"""
        self.client.flush()

    def shutdown(self) -> None:
        """关闭 Langfuse 客户端"""
        self.client.shutdown()

    def format_trace_summary(self, trace_id: str) -> str:
        """获取 trace 摘要，用于附加到 PR 描述"""
        try:
            trace = self.client.api.trace.get(trace_id)
            parts = [
                f"**Langfuse Trace**: [{trace_id}]({self.get_trace_url(trace_id)})",
                f"- 延迟: {trace.latency}ms",
                f"- Token 消耗: {getattr(trace, 'usage', {}).get('total_tokens', 'N/A')}",
                f"- 成本: ${trace.total_cost:.6f}" if trace.total_cost else "- 成本: N/A",
            ]
            return "\n".join(parts)
        except Exception as e:
            return f"**Langfuse Trace**: {trace_id} (获取详情失败: {e})"
