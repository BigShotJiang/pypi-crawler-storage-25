"""日志解析器 — 解析多语言 stack trace，提取文件、行号、调用链"""

import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class StackFrame:
    """调用栈中的一帧"""

    file: str
    line: int
    function: str = ""


@dataclass
class ParsedError:
    """解析后的错误信息"""

    exception_type: str = ""
    exception_message: str = ""
    language: Optional[str] = None  # python / go / typescript / javascript / None
    stack: list[StackFrame] = field(default_factory=list)


# ── Python ──────────────────────────────────────────────────────

_PY_TRACEBACK_RE = re.compile(r"Traceback \(most recent call last\):", re.IGNORECASE)
_PY_FRAME_RE = re.compile(r'^\s+File "([^"]+)", line (\d+)(?:, in (\w+))?')
_PY_EXCEPTION_RE = re.compile(r"^(\w+(?:\.\w+)*):\s*(.*)")


def _parse_python(log: str) -> ParsedError:
    lines = log.split("\n")
    frames = []
    exc_type = ""
    exc_msg = ""
    in_traceback = False

    for line in lines:
        if _PY_TRACEBACK_RE.match(line):
            in_traceback = True
            continue

        if not in_traceback:
            continue

        m = _PY_FRAME_RE.match(line)
        if m:
            frames.append(
                StackFrame(
                    file=m.group(1),
                    line=int(m.group(2)),
                    function=m.group(3) or "",
                )
            )
            continue

        # traceback 块内非缩进行 = 异常类型行
        m = _PY_EXCEPTION_RE.match(line)
        if m and not line.startswith(" ") and not line.startswith("\t"):
            exc_type = m.group(1)
            exc_msg = m.group(2)
            break

    return ParsedError(
        exception_type=exc_type,
        exception_message=exc_msg,
        language="python",
        stack=frames,
    )


# ── Go ──────────────────────────────────────────────────────────

_GO_PANIC_RE = re.compile(r"^panic:\s*(.*)", re.IGNORECASE)
_GO_FRAME_RE = re.compile(r"^([^\(\s]+)\(([^)]*)\)$")
_GO_FILE_LINE_RE = re.compile(r"^\t(.+?):(\d+)\s*(?:\+0x[0-9a-f]+)?")


def _parse_go(log: str) -> ParsedError:
    lines = log.split("\n")
    frames = []
    exc_msg = ""

    for _i, line in enumerate(lines):
        # panic 行
        m = _GO_PANIC_RE.match(line)
        if m:
            exc_msg = m.group(1)
            continue

        # goroutine 头，跳过
        if line.startswith("goroutine"):
            continue

        # 函数行
        m = _GO_FRAME_RE.match(line.strip())
        if m:
            continue  # 函数名行，下一行是文件信息

        # 文件行（tab 缩进）
        m = _GO_FILE_LINE_RE.match(line)
        if m:
            frames.append(
                StackFrame(
                    file=m.group(1),
                    line=int(m.group(2)),
                    function="",
                )
            )

    # 从 panic 消息中提取异常类型
    exc_type = ""
    if ":" in exc_msg:
        exc_type = exc_msg.split(":")[0].strip()

    return ParsedError(
        exception_type=exc_type,
        exception_message=exc_msg,
        language="go",
        stack=frames,
    )


# ── TypeScript / JavaScript ─────────────────────────────────────

_TS_EXCEPTION_RE = re.compile(r"^(\w+Error):\s*(.*)")
_TS_FRAME_RE = re.compile(r"^\s+at\s+(?:(\S+)\s+)?\(?([^:\s]+):(\d+)(?::(\d+))?\)?")


def _parse_typescript(log: str) -> ParsedError:
    lines = log.split("\n")
    frames = []
    exc_type = ""
    exc_msg = ""
    lang: str | None = None

    for line in lines:
        m = _TS_EXCEPTION_RE.match(line.strip())
        if m:
            exc_type = m.group(1)
            exc_msg = m.group(2)
            continue

        m = _TS_FRAME_RE.match(line)
        if m:
            file_path = m.group(2)
            # 判断语言
            lang = "typescript" if file_path.endswith((".ts", ".tsx")) else "javascript"
            frames.append(
                StackFrame(
                    file=file_path,
                    line=int(m.group(3)),
                    function=m.group(1) or "",
                )
            )

    if not frames:
        lang = None
    else:
        lang = "typescript" if any(f.file.endswith((".ts", ".tsx")) for f in frames) else "javascript"

    return ParsedError(
        exception_type=exc_type,
        exception_message=exc_msg,
        language=lang,
        stack=frames,
    )


# ── 纯错误日志（无 stack trace）─────────────────────────────────

_PLAIN_ERROR_RE = re.compile(r"(?:ERROR|FATAL|CRITICAL|ERR)\s*[:\]]\s*(.*)", re.IGNORECASE)


def _parse_plain_error(log: str) -> ParsedError:
    msg = ""
    for line in log.split("\n"):
        m = _PLAIN_ERROR_RE.search(line)
        if m:
            msg = m.group(1)
            break

    return ParsedError(
        exception_message=msg,
        language=None,
        stack=[],
    )


# ── 主入口 ──────────────────────────────────────────────────────


def parse_log(log_text: str) -> ParsedError:
    """解析日志文本，返回结构化错误信息。

    支持 Python / Go / TypeScript / JavaScript stack trace，
    以及纯错误日志（无 stack trace）。
    """
    if not log_text or not log_text.strip():
        return ParsedError()

    stripped = log_text.strip()

    # 1. Python
    if _PY_TRACEBACK_RE.search(stripped):
        return _parse_python(stripped)

    # 2. Go
    if "panic:" in stripped or "goroutine" in stripped:
        return _parse_go(stripped)

    # 3. TypeScript / JavaScript
    if _TS_EXCEPTION_RE.match(stripped.split("\n")[0].strip()) or re.search(r"^\s+at\s+", stripped, re.MULTILINE):
        return _parse_typescript(stripped)

    # 4. 纯错误日志
    return _parse_plain_error(stripped)
