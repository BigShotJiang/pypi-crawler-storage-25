"""代码交互工具 — 多语言支持（Python / Go / TypeScript / JavaScript）"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Optional

from langchain_core.tools import tool

# 语言扩展名映射
LANG_EXTENSIONS = {
    "python": [".py"],
    "go": [".go"],
    "typescript": [".ts", ".tsx"],
    "javascript": [".js", ".jsx"],
}

# 所有支持的扩展名
ALL_EXTENSIONS = [ext for exts in LANG_EXTENSIONS.values() for ext in exts]


@tool
def read_file(file_path: str, repo_path: str) -> str:
    """读取仓库中的文件内容"""
    full_path = Path(repo_path) / file_path
    if not full_path.exists():
        return f"ERROR: 文件不存在: {file_path}"
    return full_path.read_text()


@tool
def search_code(pattern: str, repo_path: str, max_results: int = 20, extensions: Optional[list[str]] = None) -> str:
    """在仓库代码中搜索正则模式，返回 file:line:content

    Args:
        pattern: 搜索的正则模式
        repo_path: 仓库根路径
        max_results: 最大结果数（默认 20）
        extensions: 限制的文件扩展名列表，默认搜索所有支持的语言
    """
    if extensions is None:
        extensions = ALL_EXTENSIONS

    grep_args = ["grep", "-rn"]
    for ext in extensions:
        grep_args.append(f"--include=*{ext}")
    grep_args.extend([pattern, repo_path])

    result = subprocess.run(grep_args, capture_output=True, text=True, timeout=10)
    lines = result.stdout.strip().split("\n")
    if not lines or lines == [""]:
        return f"未找到匹配: {pattern}"
    return "\n".join(lines[:max_results])


@tool
def list_files(repo_path: str, directory: str = ".", extensions: Optional[list[str]] = None) -> str:
    """列出仓库目录下的源文件

    Args:
        repo_path: 仓库根路径
        directory: 子目录（默认 "."）
        extensions: 限制的文件扩展名列表，默认搜索所有支持的语言
    """
    if extensions is None:
        extensions = ALL_EXTENSIONS

    full_path = Path(repo_path) / directory
    if not full_path.is_dir():
        return f"ERROR: 目录不存在: {directory}"

    files = []
    for p in full_path.rglob("*"):
        if p.is_file() and p.suffix in extensions:
            files.append(str(p.relative_to(full_path)))

    return "\n".join(sorted(files))


def _detect_language(file_path: str) -> str:
    """根据文件扩展名检测语言"""
    ext = Path(file_path).suffix.lower()
    for lang, exts in LANG_EXTENSIONS.items():
        if ext in exts:
            return lang
    return "unknown"


def _binary_exists(name: str) -> bool:
    """检查二进制工具是否可用"""
    return shutil.which(name) is not None


def _lint_python(file_path: str, repo_path: str) -> str:
    """Python 语法检查"""
    result = subprocess.run(
        ["python3", "-m", "py_compile", file_path], capture_output=True, text=True, timeout=10, cwd=repo_path
    )
    if result.returncode == 0:
        return "PASS: Python 语法有效"
    return f"FAIL: {result.stderr.strip()}"


def _lint_go(file_path: str, repo_path: str) -> str:
    """Go 语法检查 — 使用 gofmt（首选）或 go build"""
    full_path = Path(repo_path) / file_path

    if _binary_exists("gofmt"):
        result = subprocess.run(["gofmt", "-e", str(full_path)], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return "PASS: Go 语法有效"
        return f"FAIL: {result.stderr.strip()}"

    if _binary_exists("go"):
        build_result = subprocess.run(
            ["go", "build", "-o", "/dev/null", file_path], capture_output=True, text=True, timeout=30, cwd=repo_path
        )
        if build_result.returncode == 0:
            return "PASS: Go 语法有效"
        if "cannot find package" in build_result.stderr or "no required module" in build_result.stderr:
            return "PASS: Go 语法有效（无 module 环境）"
        return f"FAIL: {build_result.stderr.strip()}"

    return "SKIP: 未安装 gofmt 或 go，无法检查 Go 语法"


def _lint_typescript(file_path: str, repo_path: str) -> str:
    """TypeScript 语法检查 — 使用 tsc --noEmit"""
    if not _binary_exists("npx"):
        return "SKIP: 未安装 npx，无法检查 TypeScript 语法"

    result = subprocess.run(
        ["npx", "tsc", "--noEmit", file_path], capture_output=True, text=True, timeout=30, cwd=repo_path
    )
    if result.returncode == 0:
        return "PASS: TypeScript 语法有效"
    return f"INFO: tsc 检查未通过（可能需要 tsconfig）: {result.stderr.strip()[:200]}"


def _lint_javascript(file_path: str, repo_path: str) -> str:
    """JavaScript 语法检查 — 使用 node --check"""
    if not _binary_exists("node"):
        return "SKIP: 未安装 node，无法检查 JavaScript 语法"

    result = subprocess.run(["node", "--check", file_path], capture_output=True, text=True, timeout=10, cwd=repo_path)
    if result.returncode == 0:
        return "PASS: JavaScript 语法有效"
    return f"FAIL: {result.stderr.strip()}"


@tool
def run_lint(file_path: str, repo_path: str) -> str:
    """检查源文件语法（支持 Python / Go / TypeScript / JavaScript）

    自动根据文件扩展名选择对应的检查工具：
    - .py  → py_compile
    - .go  → gofmt + go build
    - .ts  → tsc --noEmit
    - .js  → node --check
    """
    lang = _detect_language(file_path)
    full_path = Path(repo_path) / file_path

    if not full_path.exists():
        return f"FAIL: 文件不存在: {file_path}"

    linters = {
        "python": _lint_python,
        "go": _lint_go,
        "typescript": _lint_typescript,
        "javascript": _lint_javascript,
    }

    if lang not in linters:
        return f"UNSUPPORTED: 不支持的语言 {lang} (文件: {file_path})"

    return linters[lang](file_path, repo_path)
