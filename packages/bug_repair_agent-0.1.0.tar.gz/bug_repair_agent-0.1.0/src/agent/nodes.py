"""工作流节点 — 9 个节点（parse/analyze/locate/fix/build/test/validate/review/report）"""

import json
import re
from typing import Any, Optional

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from src.sandbox import CommandResult, Sandbox

from .state import RepairAgentState
from .tools import list_files, read_file, search_code


def _sandbox_from_container(container_id: str, repo_path: str) -> Sandbox:
    """从已有容器 ID 创建 Sandbox 引用（不调用 prepare）"""
    sandbox = Sandbox(repo_path=repo_path)
    sandbox.container_id = container_id
    return sandbox


def create_nodes(model: ChatAnthropic) -> dict[str, Any]:
    """创建节点集合（9 个节点）"""
    return {
        "parse": parse_node,
        "analyze": analyze_node,
        "locate": locate_node,
        "fix": fix_node,
        "build": build_node,
        "test": test_node,
        "validate": validate_node,
        "review": review_node,
        "report": report_node,
    }


def _extract_json(text: str) -> Optional[dict[str, Any]]:
    """从 LLM 响应中提取 JSON 对象"""
    text = text.strip() if isinstance(text, str) else str(text)
    if text.startswith("```json"):
        text = text[7:]
    if text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    return None


def _call(model: ChatAnthropic, prompt: str) -> dict[str, Any]:
    """调用 LLM 并解析 JSON 响应，容错重试"""
    resp = model.invoke(prompt)
    result = _extract_json(resp.content)
    if result is not None:
        return result

    # 重试一次
    retry_resp = model.invoke(prompt + "\n\n请只输出合法 JSON，不要加任何解释。")
    return _extract_json(retry_resp.content) or {"error": "LLM 未返回合法 JSON"}


# ── Node 1: Parse ──


def parse_node(state: RepairAgentState) -> dict[str, Any]:
    model: ChatAnthropic = state["_model"]  # type: ignore[typeddict-item]
    prompt = f"""你是日报分析器。从以下日报中提取 bug 信息，输出 JSON：
{{"bug_summary": "一句话总结", "error_logs": "错误日志原文，无则空字符串", "severity": "high/medium/low"}}

日报内容：
{state["bug_report"]}"""

    data = _call(model, prompt)
    return {
        "bug_summary": data.get("bug_summary", ""),
        "error_logs": data.get("error_logs", ""),
        "severity": data.get("severity", "medium"),
    }


# ── Node 2: Analyze ──


def analyze_node(state: RepairAgentState) -> dict[str, Any]:
    model: ChatAnthropic = state["_model"]  # type: ignore[typeddict-item]
    files = list_files.invoke({"repo_path": state["repo_path"]})

    # 读取源码内容，注入给 LLM
    source_files = [f.strip() for f in files.split("\n") if f.strip() and f.split(".")[-1] in ("py", "go", "ts", "js")]
    file_contents: list[str] = []
    for fp in source_files[:20]:  # 限制 20 个文件，避免 token 过多
        content = read_file.invoke({"file_path": fp, "repo_path": state["repo_path"]})
        if content:
            file_contents.append(f"--- {fp} ---\n{content}")

    files_block = "\n\n".join(file_contents) if file_contents else "（无源码文件）"

    prompt = f"""你是代码分析专家。根据以下 bug 描述和仓库源码，分析可能的根因。

Bug 摘要：{state["bug_summary"]}
错误日志：{state.get("error_logs", "")}

仓库文件内容：
{files_block}

输出 JSON：
{{"root_cause_analysis": "根因分析（详细）", "hypothesis": "假设的 bug 原因", "confidence": 0.0-1.0, "target_files": ["疑似文件1.py"]}}"""

    data = _call(model, prompt)
    return {
        "root_cause_analysis": data.get("root_cause_analysis", ""),
        "hypothesis": data.get("hypothesis", ""),
        "confidence": data.get("confidence", 0.5),
        "target_files": data.get("target_files", []),
    }


# ── Node 3: Locate ──


def locate_node(state: RepairAgentState) -> dict[str, Any]:
    """通过 ReAct 工具循环定位 bug 位置"""
    model: ChatAnthropic = state["_model"]  # type: ignore[typeddict-item]
    tools = [read_file, search_code]
    bound_model = model.bind_tools(tools)

    prompt = f"""你是代码侦探。根据以下信息，找到 bug 所在的具体文件和行号。

Bug：{state["bug_summary"]}
根因分析：{state["root_cause_analysis"]}

工具：
- search_code：在代码中搜索关键词
- read_file：读取指定文件内容

使用方法：先用 search_code 搜索关键词，再用 read_file 读取相关文件确认。
找到 bug 位置后，只输出 JSON（不要加任何解释）：
{{"file": "文件名", "line_start": 行号, "line_end": 行号, "surrounding_code": "包含 bug 的代码片段"}}"""

    messages: list[Any] = [HumanMessage(content=prompt)]
    search_results: list[dict[str, Any]] = []
    MAX_TURNS = 5

    for _ in range(MAX_TURNS):
        resp = bound_model.invoke(messages)
        messages.append(AIMessage(content=resp.content, tool_calls=resp.tool_calls or []))

        tool_calls = resp.tool_calls or []
        if not tool_calls:
            break

        for tc in tool_calls:
            tool_name = tc.get("name", "")
            args = tc.get("args", {})
            search_results.append({"tool": tool_name, "args": args})

            if tool_name == "search_code":
                result = search_code.invoke({**args, "repo_path": state["repo_path"]})
            elif tool_name == "read_file":
                result = read_file.invoke({**args, "repo_path": state["repo_path"]})
            else:
                result = f"未知工具: {tool_name}"

            messages.append(
                ToolMessage(
                    content=str(result),
                    tool_call_id=tc.get("id", ""),
                )
            )

    # 从最终响应中提取位置
    location = None
    if resp.content:
        loc = _extract_json(resp.content)
        if loc and "file" in loc:
            location = {
                "file": loc.get("file", ""),
                "line_start": loc.get("line_start", 1),
                "line_end": loc.get("line_end", 1),
                "surrounding_code": loc.get("surrounding_code", ""),
            }

    return {
        "target_location": location,
        "search_results": search_results,
    }


# ── Node 4: Fix ──


def fix_node(state: RepairAgentState) -> dict[str, Any]:
    model: ChatAnthropic = state["_model"]  # type: ignore[typeddict-item]
    loc = state.get("target_location")
    if not loc:
        return {"patch": "", "fix_explanation": "未能定位 bug 位置", "needs_rework": True}

    file_content = read_file.invoke({"file_path": loc["file"], "repo_path": state["repo_path"]})

    prompt = f"""你是修复专家。根据以下信息生成修复补丁。

Bug 摘要：{state["bug_summary"]}
根因分析：{state["root_cause_analysis"]}
文件：{loc["file"]}
当前代码：
{file_content}

生成 unified diff 格式的补丁，只修改有 bug 的部分。
输出 JSON：
{{"patch": "unified diff 内容", "fix_explanation": "修复说明"}}"""

    data = _call(model, prompt)
    return {
        "patch": data.get("patch", ""),
        "fix_explanation": data.get("fix_explanation", ""),
    }


# ── Node 5: Build ──


def build_node(state: dict[str, Any]) -> dict[str, Any]:
    """在 Docker 沙箱中构建补丁后的代码"""
    if not state.get("patch"):
        return {
            "needs_rework": True,
            "build_result": "SKIP",
            "build_output": "无补丁可构建",
        }

    loc = state.get("target_location")
    if not loc:
        return {
            "needs_rework": True,
            "build_result": "SKIP",
            "build_output": "未定位到目标文件",
        }

    sandbox = Sandbox(repo_path=state["repo_path"])
    prep = sandbox.prepare()
    if prep.returncode != 0:
        sandbox.destroy()
        return {
            "needs_rework": True,
            "build_result": "FAIL",
            "build_output": f"沙箱创建失败: {prep.stderr}",
        }

    patch_result = sandbox.apply_patch(state["patch"])
    if patch_result.returncode != 0:
        sandbox.destroy()
        return {
            "needs_rework": True,
            "build_result": "FAIL",
            "build_output": f"补丁应用失败: {patch_result.stderr}",
        }

    build_result = sandbox.run_build()
    return {
        "needs_rework": build_result.returncode != 0,
        "build_result": "PASS" if build_result.returncode == 0 else "FAIL",
        "build_output": build_result.stdout + build_result.stderr,
        "sandbox_container_id": sandbox.container_id,
    }


# ── Node 6: Test ──


def test_node(state: dict[str, Any]) -> dict[str, Any]:
    """在 Docker 沙箱中运行测试"""
    if not state.get("patch"):
        return {
            "needs_rework": True,
            "test_result": "SKIP",
            "test_output": "无补丁可测试",
        }

    loc = state.get("target_location")
    if not loc:
        return {
            "needs_rework": True,
            "test_result": "SKIP",
            "test_output": "未定位到目标文件",
        }

    container_id = state.get("sandbox_container_id")
    if container_id:
        # 复用 build_node 创建的沙箱（补丁已应用）
        sandbox = _sandbox_from_container(container_id, state["repo_path"])
        test_result = sandbox.run_tests()
        return {
            "needs_rework": test_result.returncode != 0,
            "test_result": "PASS" if test_result.returncode == 0 else "FAIL",
            "test_output": test_result.stdout + test_result.stderr,
        }

    # 没有复用容器，创建新的
    sandbox = Sandbox(repo_path=state["repo_path"])
    prep = sandbox.prepare()
    if prep.returncode != 0:
        sandbox.destroy()
        return {
            "needs_rework": True,
            "test_result": "FAIL",
            "test_output": f"沙箱创建失败: {prep.stderr}",
        }

    patch_result = sandbox.apply_patch(state["patch"])
    if patch_result.returncode != 0:
        sandbox.destroy()
        return {
            "needs_rework": True,
            "test_result": "FAIL",
            "test_output": f"补丁应用失败: {patch_result.stderr}",
        }

    test_result = sandbox.run_tests()
    return {
        "needs_rework": test_result.returncode != 0,
        "test_result": "PASS" if test_result.returncode == 0 else "FAIL",
        "test_output": test_result.stdout + test_result.stderr,
        "sandbox_container_id": sandbox.container_id,
    }


# ── Node 7: Validate ──


def validate_node(state: RepairAgentState) -> dict[str, Any]:
    """在沙箱内对补丁后代码运行 lint + LLM 语义验证"""

    loc = state.get("target_location")
    if not loc or not state.get("patch"):
        return {"validation_result": "无补丁可验证", "needs_rework": True, "validation_output": ""}

    model: ChatAnthropic = state["_model"]  # type: ignore[typeddict-item]

    # 在沙箱内跑 lint（补丁已应用）
    container_id = state.get("sandbox_container_id")
    if container_id:
        sandbox = _sandbox_from_container(container_id, state["repo_path"])
        lint_result = sandbox.run_lint()
    else:
        lint_result = CommandResult(1, "", "沙箱不可用，跳过 lint")

    prompt = f"""你是代码审查员。验证以下修复是否正确。

Bug 摘要：{state["bug_summary"]}
根因分析：{state["root_cause_analysis"]}
修复补丁：
{state["patch"]}
语法检查：{lint_result.stdout + lint_result.stderr}

输出 JSON：
{{"valid": true/false, "reason": "验证原因", "suggestion": "如需返工给出建议"}}"""

    data = _call(model, prompt)
    valid = data.get("valid", False)
    return {
        "validation_result": "PASS" if valid else "FAIL",
        "validation_output": data.get("reason", ""),
        "needs_rework": not valid,
        "rework_target": "fix" if not valid else "",
    }


# ── Node 8: Review ──


def review_node(state: dict[str, Any]) -> dict[str, Any]:
    """安全审查 — 检查补丁是否引入安全问题"""
    if not state.get("patch"):
        return {
            "needs_rework": True,
            "review_result": "SKIP",
            "review_output": "无补丁可审查",
        }

    model: ChatAnthropic = state["_model"]
    prompt = f"""你是安全审查员。审查以下代码补丁是否存在安全问题。

Bug 摘要：{state.get("bug_summary", "")}
根因分析：{state.get("root_cause_analysis", "")}
修复补丁：
{state["patch"]}

检查以下安全问题：
1. SQL 注入 — 是否有字符串拼接 SQL 查询
2. XSS — 是否有未转义的用户输入直接输出
3. 路径遍历 — 是否有未经校验的文件路径操作
4. 命令注入 — os.system/subprocess 中是否有用户输入
5. 敏感信息 — 是否引入了硬编码的密钥、密码、token

输出 JSON：
{{"safe": true/false, "concerns": ["问题列表"], "suggestion": "修复建议"}}"""

    resp = model.invoke(prompt)
    text = resp.content
    text = text.strip() if isinstance(text, str) else str(text)
    if text.startswith("```json"):
        text = text[7:]
    if text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]

    data = json.loads(text.strip())
    safe = data.get("safe", False)
    concerns = data.get("concerns", [])

    return {
        "needs_rework": not safe,
        "rework_target": "fix" if not safe else "",
        "review_result": "PASS" if safe else "FAIL",
        "review_output": "; ".join(concerns) if concerns else "无安全问题",
        "review_suggestion": data.get("suggestion", ""),
    }


# ── Node 9: Report ──


def report_node(state: RepairAgentState) -> dict[str, Any]:
    model: ChatAnthropic = state["_model"]  # type: ignore[typeddict-item]
    prompt = f"""你是 PR 撰写助手。根据以下信息生成 PR 标题和描述。

Bug 摘要：{state["bug_summary"]}
根因分析：{state["root_cause_analysis"]}
修复说明：{state.get("fix_explanation", "")}
补丁：
{state.get("patch", "")}

输出 JSON：
{{"pr_title": "PR 标题", "pr_body": "PR 描述（包含问题、根因、修复方案）"}}"""

    data = _call(model, prompt)
    pr_body = data.get("pr_body", "")

    # 附加 Langfuse trace 链接
    trace_id = state.get("langfuse_trace_id")
    if trace_id:
        pr_body += f"\n\n---\n\n## 修复过程追踪\n\n**Langfuse Trace**: [{trace_id}](https://cloud.langfuse.com/trace/{trace_id})"

    # 清理沙箱容器
    container_id = state.get("sandbox_container_id")
    if container_id:
        try:
            sandbox = _sandbox_from_container(container_id, state["repo_path"])
            sandbox.destroy()
        except Exception:
            pass

    return {
        "pr_title": data.get("pr_title", ""),
        "pr_body": pr_body,
        "final_status": "done",
    }
