"""工作流 — 9 节点（parse/analyze/locate/fix/build/test/validate/review/report）

流程：
    parse → analyze → locate → fix → build → test → validate → review → report → END
                                        ↖___________________________↗
                                                 (rework)
"""

from typing import Any

from langgraph.graph import END, StateGraph

from src.agent.nodes import create_nodes
from src.agent.state import RepairAgentState


def build_graph(model: Any) -> Any:
    """构建工作流"""
    raw_nodes = create_nodes(model)
    workflow = StateGraph(RepairAgentState)

    def _wrap(fn: Any) -> Any:
        def wrapped(state: RepairAgentState) -> dict[str, Any]:
            return fn({**state, "_model": model})

        return wrapped

    for name, node_fn in raw_nodes.items():
        workflow.add_node(name, _wrap(node_fn))

    # 线性主流程
    workflow.set_entry_point("parse")
    workflow.add_edge("parse", "analyze")
    workflow.add_edge("analyze", "locate")
    workflow.add_edge("locate", "fix")
    workflow.add_edge("fix", "build")
    workflow.add_edge("build", "test")
    workflow.add_edge("test", "validate")
    workflow.add_edge("validate", "review")
    workflow.add_edge("review", "report")
    workflow.add_edge("report", END)

    # 条件边：从 validate/review 返工，根据 rework_target 决定回跳 locate 或 fix
    def rework_router(state: dict[str, Any], fallback: str) -> str:
        """如果需返工且未超限，返回 rework_target；否则走下一步"""
        if state.get("needs_rework") and state.get("rework_count", 0) < 3:
            state["rework_count"] = state.get("rework_count", 0) + 1
            target = state.get("rework_target", "")
            return target if target in ("locate", "fix") else "locate"
        return fallback

    def validate_route(state: dict[str, Any]) -> str:
        return rework_router(state, "review")

    def review_route(state: dict[str, Any]) -> str:
        return rework_router(state, "report")

    workflow.add_conditional_edges(
        "validate",
        validate_route,
        {"locate": "locate", "fix": "fix", "review": "review"},
    )

    workflow.add_conditional_edges(
        "review",
        review_route,
        {"locate": "locate", "fix": "fix", "report": "report"},
    )

    return workflow.compile()
