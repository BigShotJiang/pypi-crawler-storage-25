from typing import Any, Optional, TypedDict


class CodeLocation(TypedDict, total=False):
    file: str
    line_start: int
    line_end: int
    surrounding_code: str


class RepairAgentState(TypedDict):
    bug_report: str
    repo_path: str
    bug_summary: str
    error_logs: Optional[str]
    severity: str
    root_cause_analysis: str
    hypothesis: str
    confidence: float
    target_files: list[str]
    target_location: Optional[CodeLocation]
    search_results: list[dict[str, Any]]
    patch: str
    fix_explanation: str
    # build / test 结果（v2 新增）
    build_result: str
    build_output: str
    test_result: str
    test_output: str
    # review 结果（v2 新增）
    review_result: str
    review_output: str
    review_suggestion: str
    # 验证结果
    validation_result: str
    validation_output: str
    # PR 信息
    pr_body: str
    pr_title: str
    # Langfuse trace 信息
    langfuse_trace_id: Optional[str]
    # 沙箱容器 ID（build/test/validate 复用同一容器）
    sandbox_container_id: Optional[str]
    # 流程控制
    needs_rework: bool
    rework_count: int
    rework_target: str  # "locate" 或 "fix"，决定返工回跳目标
    final_status: str
