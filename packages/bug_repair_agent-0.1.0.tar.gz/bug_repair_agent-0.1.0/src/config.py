import os

from dotenv import load_dotenv

load_dotenv()


def get_api_key() -> str:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        raise OSError("未设置 ANTHROPIC_API_KEY，请复制 .env.example 为 .env 并填入 key")
    return key


def get_model() -> str:
    return os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")


def get_demo_repo() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demo", "buggy_repo")


def get_demo_reports() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demo", "daily_reports")


def get_demo_inventory() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "demo", "inventory_service")


# ── Git 配置 ────────────────────────────────────────────────────


def get_git_token() -> str:
    """Git 平台访问令牌（GitHub token / GitLab token）"""
    return os.getenv("GIT_TOKEN", "")


def get_git_platform() -> str:
    """Git 平台类型：github / gitlab"""
    return os.getenv("GIT_PLATFORM", "github")


def get_git_remote() -> str:
    """仓库远端 URL（用于 push）"""
    return os.getenv("GIT_REMOTE", "")


# ── 沙箱配置 ────────────────────────────────────────────────────


def get_sandbox_timeout() -> int:
    """沙箱内命令超时时间（秒）"""
    try:
        return int(os.getenv("SANDBOX_TIMEOUT", "120"))
    except ValueError:
        return 120


# ── Webhook 配置 ────────────────────────────────────────────────


def get_webhook_port() -> int:
    """Webhook 服务端口"""
    try:
        return int(os.getenv("WEBHOOK_PORT", "8000"))
    except ValueError:
        return 8000


# ── Langfuse 配置 ───────────────────────────────────────────────


def get_langfuse_host() -> str:
    """Langfuse 服务地址"""
    return os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com")


def get_langfuse_public_key() -> str:
    """Langfuse 公钥"""
    return os.getenv("LANGFUSE_PUBLIC_KEY", "")


def get_langfuse_secret_key() -> str:
    """Langfuse 私钥"""
    return os.getenv("LANGFUSE_SECRET_KEY", "")


def is_langfuse_enabled() -> bool:
    """是否启用 Langfuse 可观测性"""
    return os.getenv("LANGFUSE_ENABLED", "false").lower() == "true"
