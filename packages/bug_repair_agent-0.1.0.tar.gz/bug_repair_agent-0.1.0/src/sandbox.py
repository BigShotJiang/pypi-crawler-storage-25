"""沙箱环境 — Docker 隔离的构建和测试执行"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# 语言 → Docker 镜像映射
LANGUAGE_IMAGES = {
    "python": "python:3.11-slim",
    "go": "golang:1.21-alpine",
    "typescript": "node:20-alpine",
    "javascript": "node:20-alpine",
}

# 语言检测优先级（混合仓库时优先检测的语言）
DETECTION_ORDER = ["python", "go", "typescript", "javascript"]

LANG_EXTENSIONS = {
    "python": [".py"],
    "go": [".go"],
    "typescript": [".ts", ".tsx"],
    "javascript": [".js", ".jsx"],
}


@dataclass
class CommandResult:
    """命令执行结果"""

    returncode: int
    stdout: str
    stderr: str


def detect_language_from_repo(repo_path: str) -> Optional[str]:
    """根据仓库中的文件检测主要语言"""
    for lang in DETECTION_ORDER:
        exts = LANG_EXTENSIONS[lang]
        for ext in exts:
            for p in Path(repo_path).rglob(f"*{ext}"):
                if p.is_file():
                    return lang
    return None


class Sandbox:
    """Docker 隔离沙箱。

    生命周期：
    1. prepare()  — 创建容器，挂载或克隆仓库
    2. run_command() / apply_patch() — 执行操作
    3. destroy() — 清理容器
    """

    def __init__(
        self,
        repo_path: str,
        image: str | None = None,
        timeout: int = 120,
        workdir: str = "/workspace",
    ):
        self.repo_path = repo_path
        self.language = detect_language_from_repo(repo_path)
        self.image = image or (
            LANGUAGE_IMAGES.get(self.language or "", "python:3.11-slim") if self.language else "python:3.11-slim"
        )
        self.timeout = timeout
        self.workdir = workdir
        self.container_id: str | None = None
        self._temp_repo: str | None = None

    def prepare(self) -> CommandResult:
        """准备沙箱环境：创建容器，复制仓库代码。

        使用 docker create + cp 而非 volume mount，确保容器内
        的修改不会污染宿主机仓库。
        """
        result = self._run_host(
            [
                "docker",
                "create",
                "-i",
                "--name",
                self._container_name(),
                "-w",
                self.workdir,
                self.image,
                "tail",
                "-f",
                "/dev/null",
            ]
        )
        if result.returncode != 0:
            return result

        self.container_id = result.stdout.strip()

        result = self._run_host(
            [
                "docker",
                "cp",
                self.repo_path + "/.",
                f"{self.container_id}:{self.workdir}",
            ]
        )
        return result

    def run_command(self, cmd: list[str], cwd: str | None = None) -> CommandResult:
        """在沙箱内执行命令。

        Args:
            cmd: 命令列表，如 ["python3", "-m", "pytest"]
            cwd: 容器内工作目录（默认 workdir）
        """
        if not self.container_id:
            return CommandResult(1, "", "沙箱未初始化，先调用 prepare()")

        exec_dir = cwd or self.workdir
        return self._run_host(
            [
                "docker",
                "exec",
                "-w",
                exec_dir,
                self.container_id,
            ]
            + cmd,
            timeout=self.timeout,
        )

    def apply_patch(self, patch_text: str) -> CommandResult:
        """在沙箱内应用补丁。

        将 patch 文本写入容器内临时文件，然后用 patch -p1 应用。
        """
        if not self.container_id:
            return CommandResult(1, "", "沙箱未初始化")

        escaped_patch = patch_text.replace("'", "'\"'\"'")
        write_cmd = f"echo '{escaped_patch}' > /tmp/fix.patch"
        result = self._run_host(
            [
                "docker",
                "exec",
                self.container_id,
                "sh",
                "-c",
                write_cmd,
            ]
        )
        if result.returncode != 0:
            return result

        return self.run_command(["patch", "-p1", "-i", "/tmp/fix.patch"])

    def run_build(self) -> CommandResult:
        """运行构建命令（按语言自动选择）"""
        build_cmds: dict[str | None, list[str]] = {
            "python": ["python3", "-m", "py_compile", "."],
            "go": ["go", "build", "./..."],
            "typescript": ["npx", "tsc", "--noEmit"],
            "javascript": ["node", "--check", "index.js"],
        }
        cmd = build_cmds.get(self.language, ["python3", "-m", "py_compile", "."])
        return self.run_command(cmd)

    def run_tests(self, test_cmd: list[str] | None = None) -> CommandResult:
        """运行测试。

        Args:
            test_cmd: 自定义测试命令，默认按语言选择
        """
        if test_cmd:
            return self.run_command(test_cmd)

        test_cmds: dict[str | None, list[str]] = {
            "python": ["python3", "-m", "pytest", "-q"],
            "go": ["go", "test", "./..."],
            "typescript": ["npx", "jest", "--passWithNoTests"],
            "javascript": ["npx", "jest", "--passWithNoTests"],
        }
        cmd = test_cmds.get(self.language, ["python3", "-m", "pytest", "-q"])
        return self.run_command(cmd)

    def run_lint(self) -> CommandResult:
        """运行 lint 检查"""
        lint_cmds: dict[str | None, list[str]] = {
            "python": ["python3", "-m", "py_compile", "."],
            "go": ["gofmt", "-e", "."],
            "typescript": ["npx", "eslint", "."],
            "javascript": ["npx", "eslint", "."],
        }
        cmd = lint_cmds.get(self.language, ["python3", "-m", "py_compile", "."])
        return self.run_command(cmd)

    def destroy(self) -> None:
        """销毁容器和临时文件"""
        if self.container_id:
            self._run_host(["docker", "rm", "-f", self.container_id])
            self.container_id = None

        if self._temp_repo:
            import shutil

            shutil.rmtree(self._temp_repo, ignore_errors=True)
            self._temp_repo = None

    def _container_name(self) -> str:
        """生成唯一容器名"""
        import hashlib

        name_hash = hashlib.md5(self.repo_path.encode()).hexdigest()[:8]
        return f"bug-repair-sandbox-{name_hash}"

    def _run_host(self, cmd: list[str], timeout: int | None = None) -> CommandResult:
        """在宿主机上执行命令"""
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout or 60,
            )
            return CommandResult(result.returncode, result.stdout, result.stderr)
        except subprocess.TimeoutExpired:
            return CommandResult(124, "", f"命令超时 ({timeout or 60}s)")
        except FileNotFoundError:
            return CommandResult(127, "", f"命令不存在: {cmd[0]}")
