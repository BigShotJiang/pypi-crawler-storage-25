"""Git 操作和 PR 提交 — 真实 Git 流程（分支、提交、PR/MR）"""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field


@dataclass
class CommandResult:
    """命令执行结果"""

    returncode: int
    stdout: str
    stderr: str


@dataclass
class PRInfo:
    """Pull Request 信息"""

    title: str
    body: str
    branch: str
    base_branch: str = "main"
    root_cause: str = ""
    validation: str = ""
    labels: list[str] = field(default_factory=list)

    def to_markdown(self) -> str:
        """生成 PR 描述 Markdown"""
        parts = [self.body]

        if self.root_cause:
            parts.append(f"\n## 根因分析\n\n{self.root_cause}")

        if self.validation:
            parts.append(f"\n## 验证结果\n\n{self.validation}")

        parts.append("\n---\n\n> 由 Bug Repair Agent 自动生成")
        return "\n".join(parts)


class GitOps:
    """真实 Git 操作封装。

    负责：
    - 创建修复分支
    - 提交补丁
    - 推送到远端
    - 创建 PR/MR（GitHub / GitLab）
    """

    def __init__(
        self,
        repo_path: str,
        remote: str | None = None,
        git_platform: str = "github",
    ):
        """
        Args:
            repo_path: 仓库路径
            remote: 远端 URL（用于 push）
            git_platform: 平台类型 — github / gitlab
        """
        self.repo_path = repo_path
        self.remote = remote
        self.git_platform = git_platform

    # ── 分支操作 ──────────────────────────────────────────────

    def create_branch(self, branch_name: str) -> CommandResult:
        """创建并切换到新分支"""
        return self._git(["checkout", "-b", branch_name])

    def get_current_branch(self) -> str:
        """获取当前分支名"""
        result = self._git(["branch", "--show-current"])
        return result.stdout.strip()

    def switch_branch(self, branch_name: str) -> CommandResult:
        """切换分支"""
        return self._git(["checkout", branch_name])

    # ── 提交操作 ──────────────────────────────────────────────

    def commit(self, message: str) -> CommandResult:
        """提交所有变更"""
        self._git(["add", "-A"])
        return self._git(["commit", "-m", message])

    def commit_patch(self, patch_text: str, message: str) -> CommandResult:
        """应用补丁并提交。

        将 unified diff 写入临时文件，用 git apply 应用后提交。
        """
        patch_path = os.path.join(self.repo_path, ".bugfix.patch")
        with open(patch_path, "w") as f:
            f.write(patch_text)

        result = self._git(["apply", "--whitespace=fix", patch_path])
        os.remove(patch_path)

        if result.returncode != 0:
            return result

        return self.commit(message)

    # ── 推送操作 ──────────────────────────────────────────────

    def push(self, branch_name: str | None = None, force: bool = False) -> CommandResult:
        """推送到远端"""
        if not self.remote:
            return CommandResult(1, "", "未配置远端地址")

        branch = branch_name or self.get_current_branch()
        cmd = ["push", "-u", self.remote, branch]
        if force:
            cmd.insert(1, "--force-with-lease")
        return self._git(cmd)

    # ── PR/MR 创建 ────────────────────────────────────────────

    def create_pr(self, pr_info: PRInfo) -> CommandResult:
        """创建 Pull Request。

        优先使用 gh CLI（GitHub），其次 glab CLI（GitLab），
        最后降级为直接 API 调用。
        """
        if self.git_platform == "github":
            return self._create_github_pr(pr_info)
        elif self.git_platform == "gitlab":
            return self._create_gitlab_mr(pr_info)
        return CommandResult(1, "", f"不支持的平台: {self.git_platform}")

    def _create_github_pr(self, pr_info: PRInfo) -> CommandResult:
        """通过 gh CLI 创建 GitHub PR"""
        import shutil

        if not shutil.which("gh"):
            return CommandResult(127, "", "gh CLI 未安装")

        body_file = os.path.join(self.repo_path, ".pr_body.md")
        with open(body_file, "w") as f:
            f.write(pr_info.to_markdown())

        cmd = [
            "gh",
            "pr",
            "create",
            "--title",
            pr_info.title,
            "--body-file",
            body_file,
            "--base",
            pr_info.base_branch,
            "--head",
            pr_info.branch,
            "--draft",
        ]
        if pr_info.labels:
            for label in pr_info.labels:
                cmd.extend(["--label", label])

        result = self._run(cmd)
        os.remove(body_file)
        return result

    def _create_gitlab_mr(self, pr_info: PRInfo) -> CommandResult:
        """通过 glab CLI 创建 GitLab MR"""
        import shutil

        if not shutil.which("glab"):
            return CommandResult(127, "", "glab CLI 未安装")

        body_file = os.path.join(self.repo_path, ".mr_body.md")
        with open(body_file, "w") as f:
            f.write(pr_info.to_markdown())

        cmd = [
            "glab",
            "mr",
            "create",
            "--title",
            pr_info.title,
            "--description-file",
            body_file,
            "--target-branch",
            pr_info.base_branch,
            "--source-branch",
            pr_info.branch,
            "--draft",
        ]
        if pr_info.labels:
            for label in pr_info.labels:
                cmd.extend(["--label", label])

        result = self._run(cmd)
        os.remove(body_file)
        return result

    # ── 内部方法 ──────────────────────────────────────────────

    def _git(self, args: list[str]) -> CommandResult:
        """执行 git 命令"""
        return self._run(["git"] + args, cwd=self.repo_path)

    def _run(self, cmd: list[str], cwd: str | None = None) -> CommandResult:
        """执行命令"""
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=cwd or self.repo_path,
            )
            return CommandResult(result.returncode, result.stdout, result.stderr)
        except subprocess.TimeoutExpired:
            return CommandResult(124, "", f"命令超时: {' '.join(cmd)}")
        except FileNotFoundError:
            return CommandResult(127, "", f"命令不存在: {cmd[0]}")
