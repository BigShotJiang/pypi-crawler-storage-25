"""Bundled OreWatch UI assets."""
