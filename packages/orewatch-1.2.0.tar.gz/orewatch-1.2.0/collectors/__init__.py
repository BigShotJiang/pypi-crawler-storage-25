"""
Collector package for OreWatch.
"""
