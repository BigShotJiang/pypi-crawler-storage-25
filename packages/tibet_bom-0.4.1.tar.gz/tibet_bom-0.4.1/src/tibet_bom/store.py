from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .builtin import phase5_fixture_dataset
from .model import normalize_dataset


def storage_root() -> Path:
    override = os.environ.get("TIBET_BOM_HOME")
    if override:
        return Path(override).expanduser()
    xdg_data_home = os.environ.get("XDG_DATA_HOME")
    candidates = []
    if xdg_data_home:
        candidates.append(Path(xdg_data_home).expanduser() / "tibet-bom")
    candidates.append(Path.home() / ".local" / "share" / "tibet-bom")
    candidates.append(Path.cwd() / ".tibet-bom")

    for candidate in candidates:
        parent = candidate.parent
        if parent.exists() and os.access(parent, os.W_OK):
            return candidate
        if not parent.exists():
            existing_ancestor = parent
            while not existing_ancestor.exists() and existing_ancestor != existing_ancestor.parent:
                existing_ancestor = existing_ancestor.parent
            if existing_ancestor.exists() and os.access(existing_ancestor, os.W_OK):
                return candidate
    return Path.cwd() / ".tibet-bom"


def datasets_dir() -> Path:
    return storage_root() / "datasets"


def registry_path() -> Path:
    return storage_root() / "registry.json"


def ensure_storage() -> None:
    datasets_dir().mkdir(parents=True, exist_ok=True)
    if not registry_path().exists():
        registry_path().write_text(
            json.dumps({"active_dataset": None}, indent=2),
            encoding="utf-8",
        )


def dataset_path(name: str) -> Path:
    return datasets_dir() / f"{name}.json"


def load_registry() -> dict[str, Any]:
    ensure_storage()
    return json.loads(registry_path().read_text(encoding="utf-8"))


def save_registry(registry: dict[str, Any]) -> None:
    ensure_storage()
    registry_path().write_text(json.dumps(registry, indent=2), encoding="utf-8")


def save_dataset(dataset: dict[str, Any], set_active: bool = False) -> Path:
    ensure_storage()
    normalized = normalize_dataset(dataset)
    name = normalized["dataset_name"]
    path = dataset_path(name)
    path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")
    if set_active:
        registry = load_registry()
        registry["active_dataset"] = name
        save_registry(registry)
    return path


def load_dataset(name: str) -> dict[str, Any]:
    path = dataset_path(name)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {name}")
    return normalize_dataset(json.loads(path.read_text(encoding="utf-8")))


def list_datasets() -> list[dict[str, Any]]:
    bootstrap_default_dataset()
    registry = load_registry()
    active = registry.get("active_dataset")
    results: list[dict[str, Any]] = []
    for path in sorted(datasets_dir().glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload = normalize_dataset(payload)
        results.append(
            {
                "name": payload["dataset_name"],
                "kind": payload["dataset_kind"],
                "active": payload["dataset_name"] == active,
                "window": payload["window"],
                "entries": len(payload["entries"]),
            }
        )
    return results


def set_active_dataset(name: str) -> None:
    if not dataset_path(name).exists():
        raise FileNotFoundError(f"Dataset not found: {name}")
    registry = load_registry()
    registry["active_dataset"] = name
    save_registry(registry)


def bootstrap_default_dataset() -> None:
    ensure_storage()
    if not dataset_path("phase5-confirmed").exists():
        save_dataset(phase5_fixture_dataset(), set_active=False)
    registry = load_registry()
    if not registry.get("active_dataset"):
        registry["active_dataset"] = "phase5-confirmed"
        save_registry(registry)


def get_active_dataset_name() -> str:
    bootstrap_default_dataset()
    registry = load_registry()
    active = registry.get("active_dataset")
    if not active:
        raise RuntimeError("No active dataset configured")
    return str(active)


def get_dataset(name: str | None = None) -> dict[str, Any]:
    if name:
        return load_dataset(name)
    return load_dataset(get_active_dataset_name())
