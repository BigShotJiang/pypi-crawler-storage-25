from __future__ import annotations

import csv
import gzip
import hashlib
import json
import re
import socket
import subprocess
from collections import Counter
from datetime import UTC, datetime
from io import StringIO
from pathlib import Path
from typing import Any

from .builtin import phase5_fixture_dataset
from .model import normalize_dataset

_NGINX_LOG_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "(?P<method>\S+) (?P<path>\S+) \S+" '
    r'(?P<status>\d{3}) (?P<size>\S+)'
)
_IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_PATH_RE = re.compile(r"(/api/[A-Za-z0-9_./-]+)")


def _now_utc() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")


def _runtime_host() -> str:
    hostname = socket.gethostname()
    try:
        host_ip = socket.gethostbyname(hostname)
    except OSError:
        host_ip = "unresolved"
    return f"{hostname} ({host_ip})"


def _load_json(path: str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _load_entries_jsonl(path: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(65536)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _parse_timestamp(value: str) -> datetime | None:
    for fmt in (
        "%Y-%m-%d %H:%M:%S UTC",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%d/%b/%Y:%H:%M:%S %z",
    ):
        try:
            parsed = datetime.strptime(value, fmt)
            if parsed.tzinfo is None:
                return parsed.replace(tzinfo=UTC)
            return parsed.astimezone(UTC)
        except ValueError:
            continue
    return None


def _format_timestamp(dt: datetime) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")


def _summarize_window(entries: list[dict[str, Any]]) -> tuple[str, str, str]:
    timestamps = [entry.get("timestamp_utc", "") for entry in entries if entry.get("timestamp_utc")]
    parsed = [(value, _parse_timestamp(str(value))) for value in timestamps]
    valid = [(raw, dt) for raw, dt in parsed if dt is not None]
    if not valid:
        return "", "", ""
    start_dt = min(dt for _, dt in valid)
    end_dt = max(dt for _, dt in valid)
    start = _format_timestamp(start_dt)
    end = _format_timestamp(end_dt)
    total_seconds = int((end_dt - start_dt).total_seconds())
    if total_seconds < 60:
        duration = f"{total_seconds} seconds"
    elif total_seconds < 3600:
        minutes, seconds = divmod(total_seconds, 60)
        duration = f"~{minutes} minutes {seconds} seconds"
    else:
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        duration = f"~{hours} hours {minutes} minutes {seconds} seconds"
    return start, end, duration


def _majority_actor(entries: list[dict[str, Any]]) -> str:
    actors = [str(entry.get("actor") or entry.get("client_ip") or "").strip() for entry in entries]
    actors = [actor for actor in actors if actor]
    if not actors:
        return ""
    return Counter(actors).most_common(1)[0][0]


def _default_time_source(evidence_host: str | None) -> dict[str, Any]:
    return {
        "evidence_server": evidence_host or _runtime_host(),
        "evidence_server_ntp_synced": None,
        "primary_ordering_model": "TIBET causal / logical ordering",
        "causal_clock_note": (
            "TIBET ordering should be treated as the primary causal lane "
            "until stronger host clock evidence is supplied."
        ),
        "advisory": (
            "This dataset was collected without a dedicated time-source "
            "adapter payload. Supply --time-source-json for drift-aware output."
        ),
        "remediation_path": (
            "Attach explicit time-source evidence or periodically emit "
            "time-anchor tokens for stronger cross-host wall-clock correlation."
        ),
    }


def _dataset(
    *,
    name: str,
    kind: str,
    entries: list[dict[str, Any]],
    evidence_host: str | None,
    actor: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    artifact_hashes: dict[str, str],
    time_source: dict[str, Any] | None,
    nis2_context: dict[str, Any] | None,
    canonical_examples: list[dict[str, Any]] | None,
    collected_at: str | None = None,
) -> dict[str, Any]:
    normalized_entries = list(entries)
    start, end, duration = _summarize_window(normalized_entries)
    return normalize_dataset(
        {
            "dataset_name": name,
            "dataset_kind": kind,
            "collected_at": collected_at or _now_utc(),
            "window": {
                "start": start,
                "end": end,
                "duration": duration,
                "evidence_host": evidence_host or _runtime_host(),
                "primary_actor": actor or _majority_actor(normalized_entries),
                "absolute_db_position_asc": db_asc or "",
                "absolute_db_position_desc": db_desc or "",
                "exclusion_note": exclusion_note or "",
                "chain_route_status": chain_route_status or "",
            },
            "surface_labels": surface_labels,
            "nis2_context": nis2_context or {},
            "time_source_status": time_source or _default_time_source(evidence_host),
            "artifact_hashes": artifact_hashes,
            "entries": normalized_entries,
            "canonical_examples": canonical_examples or [],
        }
    )


def _ensure_note(text: str, fallback: str) -> str:
    return text.strip() if text.strip() else fallback


def collect_fixture_phase5(name: str | None = None) -> dict[str, Any]:
    dataset = phase5_fixture_dataset()
    if name:
        dataset["dataset_name"] = name
    dataset["collected_at"] = _now_utc()
    return normalize_dataset(dataset)


def collect_from_json(path: str, name: str | None = None) -> dict[str, Any]:
    dataset = normalize_dataset(_load_json(path))
    if name:
        dataset["dataset_name"] = name
    if not dataset["collected_at"]:
        dataset["collected_at"] = _now_utc()
    return dataset


def collect_from_bundle_dir(path: str, name: str | None = None) -> dict[str, Any]:
    bundle = Path(path)
    metadata = _load_json(str(bundle / "metadata.json"))
    entries_path = bundle / "entries.json"
    if entries_path.exists():
        entries = _load_json(str(entries_path))
    else:
        entries = _load_entries_jsonl(str(bundle / "entries.jsonl"))

    dataset = {
        "dataset_name": name or metadata.get("dataset_name") or bundle.name,
        "dataset_kind": "bundle_dir",
        "collected_at": _now_utc(),
        "window": {
            "start": metadata.get("window_start", ""),
            "end": metadata.get("window_end", ""),
            "duration": metadata.get("duration", ""),
            "evidence_host": metadata.get("evidence_host", ""),
            "primary_actor": metadata.get("primary_actor", ""),
            "absolute_db_position_asc": metadata.get("absolute_db_position_asc", ""),
            "absolute_db_position_desc": metadata.get("absolute_db_position_desc", ""),
            "exclusion_note": metadata.get("exclusion_note", ""),
            "chain_route_status": metadata.get("chain_route_status", ""),
        },
        "surface_labels": _load_json(str(bundle / "surface_labels.json")) if (bundle / "surface_labels.json").exists() else [],
        "nis2_context": _load_json(str(bundle / "nis2_context.json")) if (bundle / "nis2_context.json").exists() else {},
        "time_source_status": _load_json(str(bundle / "time_source.json")) if (bundle / "time_source.json").exists() else {},
        "artifact_hashes": _load_json(str(bundle / "artifact_hashes.json")) if (bundle / "artifact_hashes.json").exists() else {},
        "entries": entries,
        "canonical_examples": _load_json(str(bundle / "canonical_examples.json")) if (bundle / "canonical_examples.json").exists() else [],
    }
    return normalize_dataset(dataset)


def collect_runtime_dataset(
    name: str,
    evidence_host: str | None,
    actor: str | None,
    window_start: str | None,
    window_end: str | None,
    duration: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    entry_json: str | None,
    entry_jsonl: str | None,
    artifact_paths: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    if entry_json:
        entries = list(_load_json(entry_json))
    elif entry_jsonl:
        entries = _load_entries_jsonl(entry_jsonl)

    artifact_hashes = {path: _sha256_file(path) for path in artifact_paths}
    time_source = _load_json(time_source_json) if time_source_json else _default_time_source(evidence_host)
    dataset = _dataset(
        name=name,
        kind="runtime_collect",
        entries=entries,
        evidence_host=evidence_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels,
        artifact_hashes=artifact_hashes,
        time_source=time_source,
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )
    if window_start:
        dataset["window"]["start"] = window_start
    if window_end:
        dataset["window"]["end"] = window_end
    if duration:
        dataset["window"]["duration"] = duration
    return dataset


def _read_text_lines(path: str) -> list[str]:
    if path.endswith(".gz"):
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
            return handle.read().splitlines()
    return Path(path).read_text(encoding="utf-8", errors="replace").splitlines()


def collect_from_nginx_logs(
    *,
    name: str,
    log_paths: list[str],
    evidence_host: str | None,
    actor: str | None,
    path_contains: str | None,
    status_min: int | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    artifact_hashes = {path: _sha256_file(path) for path in log_paths}
    counter = 1
    for path in log_paths:
        for line in _read_text_lines(path):
            match = _NGINX_LOG_RE.match(line.strip())
            if not match:
                continue
            request_path = match.group("path")
            status = int(match.group("status"))
            if path_contains and path_contains not in request_path:
                continue
            if status_min is not None and status < status_min:
                continue
            parsed = _parse_timestamp(match.group("ts"))
            timestamp_utc = _format_timestamp(parsed) if parsed else match.group("ts")
            method = match.group("method")
            client_ip = match.group("ip")
            entries.append(
                {
                    "bom_id": f"TIBET-BOM-{counter:03d}",
                    "view": "nginx_access",
                    "position": counter,
                    "timestamp_utc": timestamp_utc,
                    "classification": "nginx_access",
                    "endpoint": request_path,
                    "note": f"Nginx observed {method} {request_path} -> {status}",
                    "http_status": status,
                    "actor": client_ip,
                    "client_ip": client_ip,
                }
            )
            counter += 1
    return _dataset(
        name=name,
        kind="nginx_access",
        entries=entries,
        evidence_host=evidence_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels or ["nginx access surface"],
        artifact_hashes=artifact_hashes,
        time_source=_load_json(time_source_json) if time_source_json else _default_time_source(evidence_host),
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )


def _run_command(command: list[str], env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=True,
        env=env,
    )


def _run_command_allow_no_matches(
    command: list[str],
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    if result.returncode == 0:
        return result
    if result.returncode == 1 and not result.stdout.strip():
        return result
    raise subprocess.CalledProcessError(
        result.returncode,
        command,
        output=result.stdout,
        stderr=result.stderr,
    )


def _ssh_target(host: str, user: str | None) -> str:
    return f"{user}@{host}" if user else host


def _run_ssh_command(host: str, user: str | None, remote_command: str) -> subprocess.CompletedProcess[str]:
    return _run_command(["ssh", "-o", "BatchMode=yes", _ssh_target(host, user), remote_command])


def collect_from_journald(
    *,
    name: str,
    evidence_host: str | None,
    actor: str | None,
    unit: str | None,
    since: str | None,
    until: str | None,
    grep: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    command = ["journalctl", "--no-pager", "-o", "json"]
    if unit:
        command.extend(["-u", unit])
    if since:
        command.extend(["--since", since])
    if until:
        command.extend(["--until", until])
    if grep:
        command.extend(["-g", grep])
    result = _run_command_allow_no_matches(command)

    entries: list[dict[str, Any]] = []
    counter = 1
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        row = json.loads(line)
        message = str(row.get("MESSAGE", ""))
        ts_micro = row.get("__REALTIME_TIMESTAMP")
        if ts_micro:
            dt = datetime.fromtimestamp(int(ts_micro) / 1_000_000, tz=UTC)
            timestamp_utc = _format_timestamp(dt)
        else:
            timestamp_utc = ""
        endpoint_match = _PATH_RE.search(message)
        ip_match = _IP_RE.search(message)
        endpoint = endpoint_match.group(1) if endpoint_match else ""
        client_ip = ip_match.group(0) if ip_match else ""
        entries.append(
            {
                "bom_id": f"TIBET-BOM-{counter:03d}",
                "view": "journald",
                "position": counter,
                "timestamp_utc": timestamp_utc,
                "classification": "journal_event",
                "endpoint": endpoint,
                "note": _ensure_note(message, "journald event"),
                "http_status": None,
                "actor": client_ip,
                "client_ip": client_ip,
            }
        )
        counter += 1
    return _dataset(
        name=name,
        kind="journald",
        entries=entries,
        evidence_host=evidence_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels or ["journald service events"],
        artifact_hashes={},
        time_source=_load_json(time_source_json) if time_source_json else _default_time_source(evidence_host),
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )


def collect_from_ssh_journald(
    *,
    name: str,
    ssh_host: str,
    ssh_user: str | None,
    evidence_host: str | None,
    actor: str | None,
    unit: str | None,
    since: str | None,
    until: str | None,
    grep: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    command = ["journalctl", "--no-pager", "-o", "json"]
    if unit:
        command.extend(["-u", unit])
    if since:
        command.extend(["--since", since])
    if until:
        command.extend(["--until", until])
    if grep:
        command.extend(["-g", grep])
    result = _run_command_allow_no_matches(
        ["ssh", "-o", "BatchMode=yes", _ssh_target(ssh_host, ssh_user), " ".join(command)]
    )
    entries: list[dict[str, Any]] = []
    counter = 1
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        row = json.loads(line)
        message = str(row.get("MESSAGE", ""))
        ts_micro = row.get("__REALTIME_TIMESTAMP")
        if ts_micro:
            dt = datetime.fromtimestamp(int(ts_micro) / 1_000_000, tz=UTC)
            timestamp_utc = _format_timestamp(dt)
        else:
            timestamp_utc = ""
        endpoint_match = _PATH_RE.search(message)
        ip_match = _IP_RE.search(message)
        endpoint = endpoint_match.group(1) if endpoint_match else ""
        client_ip = ip_match.group(0) if ip_match else ""
        entries.append(
            {
                "bom_id": f"TIBET-BOM-{counter:03d}",
                "view": "ssh_journald",
                "position": counter,
                "timestamp_utc": timestamp_utc,
                "classification": "journal_event",
                "endpoint": endpoint,
                "note": _ensure_note(message, "ssh journald event"),
                "http_status": None,
                "actor": client_ip,
                "client_ip": client_ip,
            }
        )
        counter += 1
    return _dataset(
        name=name,
        kind="ssh_journald",
        entries=entries,
        evidence_host=evidence_host or ssh_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels or ["ssh journald service events"],
        artifact_hashes={},
        time_source=_load_json(time_source_json) if time_source_json else _default_time_source(evidence_host or ssh_host),
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )


def _load_query(query: str | None, query_file: str | None) -> str:
    if query:
        return query
    if query_file:
        return Path(query_file).read_text(encoding="utf-8")
    raise ValueError("Either query or query_file must be provided")


def _coalesce_entry_from_postgres(row: dict[str, str], index: int) -> dict[str, Any]:
    timestamp = row.get("timestamp_utc") or row.get("created_at") or ""
    parsed = _parse_timestamp(timestamp) if timestamp else None
    timestamp_utc = _format_timestamp(parsed) if parsed else timestamp
    endpoint = row.get("endpoint") or row.get("path") or row.get("what") or ""
    view = row.get("view") or row.get("token_type") or "postgres_row"
    classification = row.get("classification") or row.get("erachter") or view
    note = row.get("note") or row.get("erin") or row.get("eromheen") or f"Postgres row from {view}"
    position_value = row.get("position") or row.get("pos") or row.get("pos_asc") or index
    try:
        position = int(position_value)
    except ValueError:
        position = index
    http_status = row.get("http_status") or row.get("status")
    return {
        "bom_id": row.get("bom_id") or f"TIBET-BOM-{index:03d}",
        "view": view,
        "position": position,
        "timestamp_utc": timestamp_utc,
        "classification": classification,
        "endpoint": endpoint,
        "note": note,
        "http_status": int(http_status) if http_status not in (None, "", "null") else None,
        "actor": row.get("actor") or row.get("client_ip") or "",
        "client_ip": row.get("client_ip") or row.get("actor") or "",
    }


def collect_from_postgres(
    *,
    name: str,
    evidence_host: str | None,
    actor: str | None,
    query: str | None,
    query_file: str | None,
    dsn: str | None,
    dbname: str | None,
    user: str | None,
    host: str | None,
    port: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    sql = _load_query(query, query_file)
    command = ["psql", "--no-psqlrc", "--csv", "-c", sql]
    if dsn:
        command.append(dsn)
    else:
        if dbname:
            command.extend(["-d", dbname])
        if user:
            command.extend(["-U", user])
        if host:
            command.extend(["-h", host])
        if port:
            command.extend(["-p", port])
    result = _run_command(command)
    reader = csv.DictReader(StringIO(result.stdout))
    entries = [_coalesce_entry_from_postgres(row, index) for index, row in enumerate(reader, start=1)]
    return _dataset(
        name=name,
        kind="postgres_query",
        entries=entries,
        evidence_host=evidence_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels or ["postgres evidence rows"],
        artifact_hashes={},
        time_source=_load_json(time_source_json) if time_source_json else _default_time_source(evidence_host),
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )


def collect_from_ssh_postgres(
    *,
    name: str,
    ssh_host: str,
    ssh_user: str | None,
    evidence_host: str | None,
    actor: str | None,
    query: str | None,
    query_file: str | None,
    dbname: str | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    sql = _load_query(query, query_file)
    db_arg = f"-d {dbname}" if dbname else ""
    remote_command = f"sudo -u postgres psql --csv {db_arg} -c {json.dumps(sql)}"
    result = _run_ssh_command(ssh_host, ssh_user, remote_command)
    reader = csv.DictReader(StringIO(result.stdout))
    entries = [_coalesce_entry_from_postgres(row, index) for index, row in enumerate(reader, start=1)]
    return _dataset(
        name=name,
        kind="ssh_postgres",
        entries=entries,
        evidence_host=evidence_host or ssh_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels or ["ssh postgres evidence rows"],
        artifact_hashes={},
        time_source=_load_json(time_source_json) if time_source_json else _default_time_source(evidence_host or ssh_host),
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )


def collect_from_ssh_nginx_logs(
    *,
    name: str,
    ssh_host: str,
    ssh_user: str | None,
    log_paths: list[str],
    evidence_host: str | None,
    actor: str | None,
    path_contains: str | None,
    status_min: int | None,
    db_asc: str | None,
    db_desc: str | None,
    chain_route_status: str | None,
    exclusion_note: str | None,
    surface_labels: list[str],
    time_source_json: str | None,
    nis2_json: str | None,
    canonical_json: str | None,
) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    artifact_hashes: dict[str, str] = {}
    counter = 1
    for path in log_paths:
        remote_command = (
            f"if echo {json.dumps(path)} | grep -q '\\.gz$'; then gzip -cd {json.dumps(path)}; "
            f"else cat {json.dumps(path)}; fi"
        )
        result = _run_ssh_command(ssh_host, ssh_user, remote_command)
        hash_result = _run_ssh_command(ssh_host, ssh_user, f"sha256sum {json.dumps(path)}")
        artifact_hashes[path] = hash_result.stdout.strip().split()[0]
        for line in result.stdout.splitlines():
            match = _NGINX_LOG_RE.match(line.strip())
            if not match:
                continue
            request_path = match.group("path")
            status = int(match.group("status"))
            if path_contains and path_contains not in request_path:
                continue
            if status_min is not None and status < status_min:
                continue
            parsed = _parse_timestamp(match.group("ts"))
            timestamp_utc = _format_timestamp(parsed) if parsed else match.group("ts")
            method = match.group("method")
            client_ip = match.group("ip")
            entries.append(
                {
                    "bom_id": f"TIBET-BOM-{counter:03d}",
                    "view": "ssh_nginx_access",
                    "position": counter,
                    "timestamp_utc": timestamp_utc,
                    "classification": "nginx_access",
                    "endpoint": request_path,
                    "note": f"SSH nginx observed {method} {request_path} -> {status}",
                    "http_status": status,
                    "actor": client_ip,
                    "client_ip": client_ip,
                }
            )
            counter += 1
    return _dataset(
        name=name,
        kind="ssh_nginx_access",
        entries=entries,
        evidence_host=evidence_host or ssh_host,
        actor=actor,
        db_asc=db_asc,
        db_desc=db_desc,
        chain_route_status=chain_route_status,
        exclusion_note=exclusion_note,
        surface_labels=surface_labels or ["ssh nginx access surface"],
        artifact_hashes=artifact_hashes,
        time_source=_load_json(time_source_json) if time_source_json else _default_time_source(evidence_host or ssh_host),
        nis2_context=_load_json(nis2_json) if nis2_json else {},
        canonical_examples=_load_json(canonical_json) if canonical_json else [],
    )
