from __future__ import annotations

import argparse

from .collect import (
    collect_fixture_phase5,
    collect_from_bundle_dir,
    collect_from_json,
    collect_from_journald,
    collect_from_nginx_logs,
    collect_from_postgres,
    collect_from_ssh_journald,
    collect_from_ssh_nginx_logs,
    collect_from_ssh_postgres,
    collect_runtime_dataset,
)
from .render import (
    render_artifacts,
    render_info,
    render_json,
    render_markdown,
    render_report,
    render_table,
    render_time_source,
    render_timeline,
)
from .store import get_dataset, list_datasets, save_dataset, set_active_dataset


def _add_dataset_selector(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--dataset",
        help="Dataset name to render; defaults to active dataset",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tibet-bom",
        description="TIBET Bill Of Hack — operator-side attack inventory",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    info = sub.add_parser("info", help="Show scope and attack window summary")
    _add_dataset_selector(info)

    table = sub.add_parser("table", help="Show compact BOM table")
    _add_dataset_selector(table)

    timeline = sub.add_parser("timeline", help="Show ordered attack timeline")
    _add_dataset_selector(timeline)

    report = sub.add_parser("report", help="Show incident transparency report")
    _add_dataset_selector(report)

    artifacts = sub.add_parser("artifacts", help="Show corroborating artefact hashes")
    _add_dataset_selector(artifacts)

    time_source = sub.add_parser(
        "time-source",
        help="Show time-source status (NTP sync, drift, advisory)",
    )
    _add_dataset_selector(time_source)

    json_cmd = sub.add_parser("json", help="Emit full machine-readable payload")
    _add_dataset_selector(json_cmd)

    markdown = sub.add_parser("markdown", help="Render markdown BOM")
    _add_dataset_selector(markdown)

    datasets = sub.add_parser("datasets", help="List stored datasets")
    datasets.add_argument("--json-output", action="store_true", help="Emit dataset registry as JSON")

    use = sub.add_parser("use", help="Set the active dataset")
    use.add_argument("name", help="Dataset name to activate")

    collect = sub.add_parser("collect", help="Collect or import a dataset")
    collect_sub = collect.add_subparsers(dest="collect_kind", required=True)

    fixture = collect_sub.add_parser("fixture-phase5", help="Install the built-in confirmed Phase 5 dataset")
    fixture.add_argument("--name", help="Override dataset name")
    fixture.add_argument("--set-active", action="store_true", help="Make the stored dataset active")

    from_json = collect_sub.add_parser("json", help="Import a dataset JSON file")
    from_json.add_argument("--file", required=True, help="Path to dataset JSON")
    from_json.add_argument("--name", help="Override dataset name")
    from_json.add_argument("--set-active", action="store_true", help="Make the stored dataset active")

    from_bundle = collect_sub.add_parser("bundle", help="Import a conventional evidence bundle directory")
    from_bundle.add_argument("--path", required=True, help="Bundle directory path")
    from_bundle.add_argument("--name", help="Override dataset name")
    from_bundle.add_argument("--set-active", action="store_true", help="Make the stored dataset active")

    runtime = collect_sub.add_parser("runtime", help="Build a dataset from local files and runtime metadata")
    runtime.add_argument("--name", required=True, help="Dataset name")
    runtime.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    runtime.add_argument("--evidence-host", help="Label for the evidence host")
    runtime.add_argument("--actor", help="Primary actor IP or identity")
    runtime.add_argument("--window-start", help="Window start label")
    runtime.add_argument("--window-end", help="Window end label")
    runtime.add_argument("--duration", help="Window duration label")
    runtime.add_argument("--db-asc", help="Absolute DB ascending positions")
    runtime.add_argument("--db-desc", help="Absolute DB descending positions")
    runtime.add_argument("--chain-route-status", help="Route verification note")
    runtime.add_argument("--exclusion-note", help="Exclusion note")
    runtime.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    runtime.add_argument("--entry-json", help="JSON file containing a list of entries")
    runtime.add_argument("--entry-jsonl", help="JSONL file containing BOM entries")
    runtime.add_argument("--artifact", action="append", default=[], help="Artifact file to hash; repeatable")
    runtime.add_argument("--time-source-json", help="JSON file with time-source payload")
    runtime.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    runtime.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    nginx = collect_sub.add_parser("nginx", help="Build a dataset from nginx access logs")
    nginx.add_argument("--name", required=True, help="Dataset name")
    nginx.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    nginx.add_argument("--log", action="append", required=True, help="Access log path; repeatable")
    nginx.add_argument("--evidence-host", help="Label for the evidence host")
    nginx.add_argument("--actor", help="Primary actor override")
    nginx.add_argument("--path-contains", help="Only keep requests whose path contains this substring")
    nginx.add_argument("--status-min", type=int, help="Only keep requests with HTTP status >= this value")
    nginx.add_argument("--db-asc", help="Absolute DB ascending positions")
    nginx.add_argument("--db-desc", help="Absolute DB descending positions")
    nginx.add_argument("--chain-route-status", help="Route verification note")
    nginx.add_argument("--exclusion-note", help="Exclusion note")
    nginx.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    nginx.add_argument("--time-source-json", help="JSON file with time-source payload")
    nginx.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    nginx.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    journald = collect_sub.add_parser("journald", help="Build a dataset from systemd journal output")
    journald.add_argument("--name", required=True, help="Dataset name")
    journald.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    journald.add_argument("--evidence-host", help="Label for the evidence host")
    journald.add_argument("--actor", help="Primary actor override")
    journald.add_argument("--unit", help="systemd unit to filter on")
    journald.add_argument("--since", help="journalctl --since value")
    journald.add_argument("--until", help="journalctl --until value")
    journald.add_argument("--grep", help="journalctl -g pattern")
    journald.add_argument("--db-asc", help="Absolute DB ascending positions")
    journald.add_argument("--db-desc", help="Absolute DB descending positions")
    journald.add_argument("--chain-route-status", help="Route verification note")
    journald.add_argument("--exclusion-note", help="Exclusion note")
    journald.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    journald.add_argument("--time-source-json", help="JSON file with time-source payload")
    journald.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    journald.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    postgres = collect_sub.add_parser("postgres", help="Build a dataset from a psql CSV query")
    postgres.add_argument("--name", required=True, help="Dataset name")
    postgres.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    postgres.add_argument("--evidence-host", help="Label for the evidence host")
    postgres.add_argument("--actor", help="Primary actor override")
    postgres.add_argument("--query", help="SQL query string returning BOM-like rows")
    postgres.add_argument("--query-file", help="Path to SQL file")
    postgres.add_argument("--dsn", help="Full Postgres DSN for psql")
    postgres.add_argument("--dbname", help="Database name for psql")
    postgres.add_argument("--user", help="Database user for psql")
    postgres.add_argument("--host", help="Database host for psql")
    postgres.add_argument("--port", help="Database port for psql")
    postgres.add_argument("--db-asc", help="Absolute DB ascending positions")
    postgres.add_argument("--db-desc", help="Absolute DB descending positions")
    postgres.add_argument("--chain-route-status", help="Route verification note")
    postgres.add_argument("--exclusion-note", help="Exclusion note")
    postgres.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    postgres.add_argument("--time-source-json", help="JSON file with time-source payload")
    postgres.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    postgres.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    ssh_nginx = collect_sub.add_parser("ssh-nginx", help="Build a dataset from nginx logs over SSH")
    ssh_nginx.add_argument("--name", required=True, help="Dataset name")
    ssh_nginx.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    ssh_nginx.add_argument("--ssh-host", required=True, help="SSH target host")
    ssh_nginx.add_argument("--ssh-user", help="SSH user")
    ssh_nginx.add_argument("--log", action="append", required=True, help="Remote access log path; repeatable")
    ssh_nginx.add_argument("--evidence-host", help="Label for the evidence host")
    ssh_nginx.add_argument("--actor", help="Primary actor override")
    ssh_nginx.add_argument("--path-contains", help="Only keep requests whose path contains this substring")
    ssh_nginx.add_argument("--status-min", type=int, help="Only keep requests with HTTP status >= this value")
    ssh_nginx.add_argument("--db-asc", help="Absolute DB ascending positions")
    ssh_nginx.add_argument("--db-desc", help="Absolute DB descending positions")
    ssh_nginx.add_argument("--chain-route-status", help="Route verification note")
    ssh_nginx.add_argument("--exclusion-note", help="Exclusion note")
    ssh_nginx.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    ssh_nginx.add_argument("--time-source-json", help="JSON file with time-source payload")
    ssh_nginx.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    ssh_nginx.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    ssh_journald = collect_sub.add_parser("ssh-journald", help="Build a dataset from journald over SSH")
    ssh_journald.add_argument("--name", required=True, help="Dataset name")
    ssh_journald.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    ssh_journald.add_argument("--ssh-host", required=True, help="SSH target host")
    ssh_journald.add_argument("--ssh-user", help="SSH user")
    ssh_journald.add_argument("--evidence-host", help="Label for the evidence host")
    ssh_journald.add_argument("--actor", help="Primary actor override")
    ssh_journald.add_argument("--unit", help="systemd unit to filter on")
    ssh_journald.add_argument("--since", help="journalctl --since value")
    ssh_journald.add_argument("--until", help="journalctl --until value")
    ssh_journald.add_argument("--grep", help="journalctl -g pattern")
    ssh_journald.add_argument("--db-asc", help="Absolute DB ascending positions")
    ssh_journald.add_argument("--db-desc", help="Absolute DB descending positions")
    ssh_journald.add_argument("--chain-route-status", help="Route verification note")
    ssh_journald.add_argument("--exclusion-note", help="Exclusion note")
    ssh_journald.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    ssh_journald.add_argument("--time-source-json", help="JSON file with time-source payload")
    ssh_journald.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    ssh_journald.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    ssh_postgres = collect_sub.add_parser("ssh-postgres", help="Build a dataset from Postgres over SSH")
    ssh_postgres.add_argument("--name", required=True, help="Dataset name")
    ssh_postgres.add_argument("--set-active", action="store_true", help="Make the stored dataset active")
    ssh_postgres.add_argument("--ssh-host", required=True, help="SSH target host")
    ssh_postgres.add_argument("--ssh-user", help="SSH user")
    ssh_postgres.add_argument("--evidence-host", help="Label for the evidence host")
    ssh_postgres.add_argument("--actor", help="Primary actor override")
    ssh_postgres.add_argument("--query", help="SQL query string returning BOM-like rows")
    ssh_postgres.add_argument("--query-file", help="Path to SQL file")
    ssh_postgres.add_argument("--dbname", help="Database name for remote psql")
    ssh_postgres.add_argument("--db-asc", help="Absolute DB ascending positions")
    ssh_postgres.add_argument("--db-desc", help="Absolute DB descending positions")
    ssh_postgres.add_argument("--chain-route-status", help="Route verification note")
    ssh_postgres.add_argument("--exclusion-note", help="Exclusion note")
    ssh_postgres.add_argument("--surface-label", action="append", default=[], help="Surface label; repeatable")
    ssh_postgres.add_argument("--time-source-json", help="JSON file with time-source payload")
    ssh_postgres.add_argument("--nis2-json", help="JSON file with NIS2 context payload")
    ssh_postgres.add_argument("--canonical-json", help="JSON file with canonical examples payload")

    return parser


def _render_selected(args: argparse.Namespace) -> str:
    dataset = get_dataset(getattr(args, "dataset", None))
    if args.command == "info":
        return render_info(dataset)
    if args.command == "table":
        return render_table(dataset)
    if args.command == "timeline":
        return render_timeline(dataset)
    if args.command == "report":
        return render_report(dataset)
    if args.command == "artifacts":
        return render_artifacts(dataset)
    if args.command == "time-source":
        return render_time_source(dataset)
    if args.command == "json":
        return render_json(dataset)
    if args.command == "markdown":
        return render_markdown(dataset)
    raise ValueError(f"Unknown render command: {args.command}")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command in {"info", "table", "timeline", "report", "artifacts", "time-source", "json", "markdown"}:
        print(_render_selected(args))
        return 0

    if args.command == "datasets":
        datasets = list_datasets()
        if args.json_output:
            import json

            print(json.dumps(datasets, indent=2))
        else:
            for item in datasets:
                marker = "*" if item["active"] else " "
                window = item["window"]
                print(
                    f"{marker} {item['name']} [{item['kind']}] "
                    f"{window.get('start', '')} -> {window.get('end', '')} "
                    f"entries={item['entries']}"
                )
        return 0

    if args.command == "use":
        set_active_dataset(args.name)
        print(f"Active dataset: {args.name}")
        return 0

    if args.command == "collect":
        if args.collect_kind == "fixture-phase5":
            dataset = collect_fixture_phase5(args.name)
        elif args.collect_kind == "json":
            dataset = collect_from_json(args.file, args.name)
        elif args.collect_kind == "bundle":
            dataset = collect_from_bundle_dir(args.path, args.name)
        elif args.collect_kind == "runtime":
            dataset = collect_runtime_dataset(
                name=args.name,
                evidence_host=args.evidence_host,
                actor=args.actor,
                window_start=args.window_start,
                window_end=args.window_end,
                duration=args.duration,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                entry_json=args.entry_json,
                entry_jsonl=args.entry_jsonl,
                artifact_paths=args.artifact,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        elif args.collect_kind == "nginx":
            dataset = collect_from_nginx_logs(
                name=args.name,
                log_paths=args.log,
                evidence_host=args.evidence_host,
                actor=args.actor,
                path_contains=args.path_contains,
                status_min=args.status_min,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        elif args.collect_kind == "journald":
            dataset = collect_from_journald(
                name=args.name,
                evidence_host=args.evidence_host,
                actor=args.actor,
                unit=args.unit,
                since=args.since,
                until=args.until,
                grep=args.grep,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        elif args.collect_kind == "postgres":
            dataset = collect_from_postgres(
                name=args.name,
                evidence_host=args.evidence_host,
                actor=args.actor,
                query=args.query,
                query_file=args.query_file,
                dsn=args.dsn,
                dbname=args.dbname,
                user=args.user,
                host=args.host,
                port=args.port,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        elif args.collect_kind == "ssh-nginx":
            dataset = collect_from_ssh_nginx_logs(
                name=args.name,
                ssh_host=args.ssh_host,
                ssh_user=args.ssh_user,
                log_paths=args.log,
                evidence_host=args.evidence_host,
                actor=args.actor,
                path_contains=args.path_contains,
                status_min=args.status_min,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        elif args.collect_kind == "ssh-journald":
            dataset = collect_from_ssh_journald(
                name=args.name,
                ssh_host=args.ssh_host,
                ssh_user=args.ssh_user,
                evidence_host=args.evidence_host,
                actor=args.actor,
                unit=args.unit,
                since=args.since,
                until=args.until,
                grep=args.grep,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        elif args.collect_kind == "ssh-postgres":
            dataset = collect_from_ssh_postgres(
                name=args.name,
                ssh_host=args.ssh_host,
                ssh_user=args.ssh_user,
                evidence_host=args.evidence_host,
                actor=args.actor,
                query=args.query,
                query_file=args.query_file,
                dbname=args.dbname,
                db_asc=args.db_asc,
                db_desc=args.db_desc,
                chain_route_status=args.chain_route_status,
                exclusion_note=args.exclusion_note,
                surface_labels=args.surface_label,
                time_source_json=args.time_source_json,
                nis2_json=args.nis2_json,
                canonical_json=args.canonical_json,
            )
        else:
            parser.error(f"Unknown collect kind: {args.collect_kind}")
            return 2

        path = save_dataset(dataset, set_active=args.set_active)
        print(f"Stored dataset: {dataset['dataset_name']}")
        print(f"Path: {path}")
        if args.set_active:
            print(f"Active dataset: {dataset['dataset_name']}")
        return 0

    parser.error(f"Unknown command: {args.command}")
    return 2
