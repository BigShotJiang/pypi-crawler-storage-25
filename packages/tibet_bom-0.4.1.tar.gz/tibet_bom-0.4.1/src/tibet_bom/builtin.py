from __future__ import annotations

from datetime import UTC, datetime

from .fixtures import PHASE5_DB_BACKSOLVE
from .model import BomEntry, normalize_dataset

_SURFACE_LABELS = [
    "TIBET signing and verification endpoints",
    "TIBET chain/read surfaces",
    "AINS registry and lookup endpoints",
]

_NIS2_CONTEXT = {
    "article_23_relevance": (
        "Supports 24h/72h incident reporting by pre-structuring the "
        "forensic timeline from chain data."
    ),
    "article_21_relevance": (
        "Demonstrates risk-management evidence, access-control behavior, "
        "and incident handling traceability."
    ),
}

_TIME_SOURCE_STATUS = {
    "evidence_server": "P520 (10.0.100.2)",
    "evidence_server_ntp_synced": False,
    "evidence_server_zone": "Etc/UTC",
    "anchor_server": "jtel-stack (NTP-active)",
    "anchor_server_ntp_synced": True,
    "anchor_server_zone": "Europe/Amsterdam (CEST, +0200)",
    "drift_seconds": 14.187,
    "drift_direction": "P520 ahead of NTP-anchored truth",
    "measurement_utc": "2026-05-07 12:33:29 UTC",
    "rtc_drift_seconds": 35,
    "anchor_method": "host-to-host wall-clock comparison",
    "primary_ordering_model": "TIBET causal / logical ordering",
    "causal_clock_note": (
        "TIBET already provides a Lamport-like logical clock structure "
        "through prev_token_id, generation, parent_token_id, and the "
        "hash-linked chain. Relative ordering inside one evidence lane "
        "therefore remains valid even when wall-clock drift exists."
    ),
    "advisory": (
        "The primary truth preserved by this BOM is causal ordering, not "
        "authoritative wall-clock time. Phase 5 timestamps reflect the "
        "evidence server's local clock at engagement time, while TIBET's "
        "chain structure preserves happened-before order, sequencing, and "
        "generation relationships independently of NTP status. At "
        "measurement-time (2026-05-07 12:33:29 UTC) P520 showed +14.187s "
        "drift relative to the NTP-anchored jtel-stack reference, with no "
        "NTP service active and ~35s RTC drift observed. Cross-source "
        "absolute UTC comparison should therefore account for this drift "
        "band, while single-lane relative ordering remains trustworthy."
    ),
    "remediation_path": (
        "Three-step path: (1) preserve TIBET causal ordering as the "
        "primary forensic primitive; (2) re-enable systemd-timesyncd / "
        "chrony and emit Postgres + nginx + journald clock alignment per "
        "BOM render for better wall-clock comparison; (3) extend TIBET "
        "with periodic time-anchor tokens (RFC 3161 / Roughtime style) "
        "so absolute time is cryptographically anchored rather than only "
        "server-local."
    ),
}

_ARTIFACT_HASHES = {
    "/var/log/nginx/redbaron-nightfall.log": (
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    ),
    "/var/log/nginx/redbaron-nightfall.log.1": (
        "af10956aadb32afbb32698bca2f5b6681c8a22f27ad416532519b6288d36cade"
    ),
    "/var/log/nginx/redbaron-nightfall.log.2.gz": (
        "f2434ecfbad73f16a7755469c7cfedda230fe225d30ae6558961d2e74d2027e0"
    ),
}

_CANONICAL_EXAMPLES = [
    {
        "actor": "[redacted-ip]",
        "created_at": "2026-05-05T08:38:06.890741",
        "eraan": {
            "auth_decision": "denied",
            "client_ip": "[redacted-ip]",
            "method": "GET",
            "path": "/api/tibet/status",
            "required_level": "developer",
            "role": None,
            "user": None,
        },
        "erachter": "access_control",
        "erin": "bewaken",
        "eromheen": "fort_knox",
        "parent_id": None,
        "state": "detected",
        "token_id": "33896a9c...",
        "token_type": "security_violation",
        "trust_score": 0.9,
    },
    {
        "actor": "jis:web:ephemeral:[redacted]",
        "created_at": "2026-05-05T08:38:06.817589",
        "eraan": {
            "client_ip": "[redacted-ip]",
            "first_path": "/",
            "how": "http_request",
            "is_suspicious": False,
            "is_trusted": False,
            "jis_did": "jis:web:ephemeral:[redacted]",
            "trust_level": "unknown",
            "user_agent": "curl/8.14.1",
            "what": "first_contact",
            "when": "2026-05-05T08:38:06.817512",
            "where": "brain_api",
            "who": "jis:web:ephemeral:[redacted]",
            "why": "new_client_relationship",
        },
        "erachter": "establish_relationship",
        "erin": "New client connection from jis:web:ephemeral:[redacted]",
        "eromheen": "First contact: jis:web:ephemeral:[redacted] -> /",
        "parent_id": None,
        "state": "active",
        "token_id": "c7999688...",
        "token_type": "fira_link_token",
        "trust_score": 0.9,
    },
]

_ENTRIES = [
    BomEntry("TIBET-BOM-001", "security_violation", 92, "2026-05-04 12:27:24", "bewaken", "/api/tibet/sign", "First visible TIBET-targeted hit in confirmed window"),
    BomEntry("TIBET-BOM-002", "security_violation", 91, "2026-05-04 12:27:26", "bewaken", "/api/tibet/verify", "Verification surface probed"),
    BomEntry("TIBET-BOM-003", "security_violation", 90, "2026-05-04 12:27:28", "bewaken", "/api/tibet/chain", "Chain-read surface probed"),
    BomEntry("TIBET-BOM-004", "security_violation", 89, "2026-05-04 12:27:29", "bewaken", "/api/tibet/status", "Status surface probed"),
    BomEntry("TIBET-BOM-005", "security_violation", 88, "2026-05-04 12:27:32", "bewaken", "/api/tibet/record", "Record surface probed"),
    BomEntry("TIBET-BOM-006", "security_violation", 87, "2026-05-04 12:27:34", "bewaken", "/api/tibet/query", "Query surface probed"),
    BomEntry("TIBET-BOM-007", "security_violation", 86, "2026-05-04 12:27:35", "bewaken", "/api/tibet/list", "List surface probed"),
    BomEntry("TIBET-BOM-008", "security_violation", 85, "2026-05-04 12:29:19", "bewaken", "/api/tibet/sign", "Repeated signing attempt"),
    BomEntry("TIBET-BOM-009", "security_violation", 84, "2026-05-04 12:29:20", "bewaken", "/api/tibet/sign", "Repeated signing attempt"),
    BomEntry("TIBET-BOM-010", "security_violation", 83, "2026-05-04 12:29:22", "bewaken", "/api/tibet/sign", "Repeated signing attempt"),
    BomEntry("TIBET-BOM-011", "security_violation", 82, "2026-05-04 12:29:23", "bewaken", "/api/tibet/sign", "Repeated signing attempt"),
    BomEntry("TIBET-BOM-012", "security_violation", 81, "2026-05-04 12:29:25", "bewaken", "/api/tibet/sign", "Repeated signing attempt"),
    BomEntry("TIBET-BOM-013", "security_violation", 80, "2026-05-04 12:29:38", "bewaken", "/api/tibet/sign", "Repeated signing attempt"),
    BomEntry("TIBET-BOM-014", "security_violation", 79, "2026-05-04 12:29:39", "bewaken", "/api/tibet/sign", "Final visible signing attempt in confirmed window"),
    BomEntry("TIBET-BOM-015", "api_request", 53, "2026-05-04 12:27:37", "api_request", "GET /api/ains/lookup", "Corroborating AINS enumeration", 200),
    BomEntry("TIBET-BOM-016", "api_request", 52, "2026-05-04 12:27:40", "api_request", "GET /api/ains/registry", "Corroborating AINS enumeration", 200),
    BomEntry("TIBET-BOM-017", "api_request", 51, "2026-05-04 12:28:08", "api_request", "GET /api/ains/lookup", "Corroborating AINS enumeration", 200),
]


def phase5_fixture_dataset() -> dict:
    return normalize_dataset(
        {
            "dataset_name": "phase5-confirmed",
            "dataset_kind": "fixture_phase5",
            "collected_at": datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC"),
            "window": {
                "start": "2026-05-04 12:27:24 UTC",
                "end": "2026-05-04 12:29:39 UTC",
                "duration": "~2 minutes 15 seconds",
                "evidence_host": "P520 staging (10.0.100.2)",
                "primary_actor": "10.0.100.11",
                "absolute_db_position_asc": "407-423",
                "absolute_db_position_desc": "298-282",
                "exclusion_note": (
                    "2026-05-05 08:38:06 UTC from 192.168.4.76 is post-engagement "
                    "reachability testing, not true Phase 5 attack data."
                ),
                "chain_route_status": (
                    "Typed-view positions and absolute DB ranks are verified. "
                    "A live public api/tibet/chain/[pos] implementation could not "
                    "be verified in the current codebase."
                ),
            },
            "surface_labels": _SURFACE_LABELS,
            "nis2_context": _NIS2_CONTEXT,
            "time_source_status": _TIME_SOURCE_STATUS,
            "artifact_hashes": _ARTIFACT_HASHES,
            "entries": [entry.as_dict() for entry in _ENTRIES],
            "canonical_examples": _CANONICAL_EXAMPLES,
            "fixture": PHASE5_DB_BACKSOLVE,
        }
    )
