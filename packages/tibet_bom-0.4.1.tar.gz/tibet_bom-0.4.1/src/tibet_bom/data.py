from __future__ import annotations

from .builtin import phase5_fixture_dataset
from .model import touched_endpoints

_DEFAULT = phase5_fixture_dataset()

WINDOW_START = _DEFAULT["window"]["start"]
WINDOW_END = _DEFAULT["window"]["end"]
WINDOW_DURATION = _DEFAULT["window"]["duration"]
EVIDENCE_HOST = _DEFAULT["window"]["evidence_host"]
PRIMARY_ACTOR = _DEFAULT["window"]["primary_actor"]
ABSOLUTE_DB_POSITION_ASC = _DEFAULT["window"]["absolute_db_position_asc"]
ABSOLUTE_DB_POSITION_DESC = _DEFAULT["window"]["absolute_db_position_desc"]
CHAIN_ROUTE_STATUS = _DEFAULT["window"]["chain_route_status"]
SURFACE_LABELS = _DEFAULT["surface_labels"]
NIS2_CONTEXT = _DEFAULT["nis2_context"]
EXCLUSION_NOTE = _DEFAULT["window"]["exclusion_note"]
TIME_SOURCE_STATUS = _DEFAULT["time_source_status"]
ARTIFACT_HASHES = _DEFAULT["artifact_hashes"]
CANONICAL_EXAMPLES = _DEFAULT["canonical_examples"]
ENTRIES = _DEFAULT["entries"]


def entries_as_dicts() -> list[dict]:
    return list(ENTRIES)


def touched_endpoints_default() -> list[str]:
    return touched_endpoints(ENTRIES)
