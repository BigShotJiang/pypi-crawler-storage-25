from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class BomEntry:
    bom_id: str
    view: str
    position: int
    timestamp_utc: str
    classification: str
    endpoint: str
    note: str
    http_status: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def touched_endpoints(entries: list[dict[str, Any]]) -> list[str]:
    seen: list[str] = []
    for entry in entries:
        endpoint = str(entry.get("endpoint", "")).strip()
        if endpoint and endpoint not in seen:
            seen.append(endpoint)
    return seen


def normalize_entries(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for index, entry in enumerate(entries, start=1):
        normalized.append(
            {
                "bom_id": entry.get("bom_id", f"TIBET-BOM-{index:03d}"),
                "view": str(entry.get("view", "unknown")),
                "position": int(entry.get("position", 0)),
                "timestamp_utc": str(entry.get("timestamp_utc", "")),
                "classification": str(entry.get("classification", "unknown")),
                "endpoint": str(entry.get("endpoint", "")),
                "note": str(entry.get("note", "")),
                "http_status": entry.get("http_status"),
                "actor": str(entry.get("actor", "")),
                "client_ip": str(entry.get("client_ip", "")),
            }
        )
    return normalized


def normalize_dataset(dataset: dict[str, Any]) -> dict[str, Any]:
    window = dict(dataset.get("window", {}))
    entries = normalize_entries(list(dataset.get("entries", [])))
    normalized = {
        "dataset_name": str(dataset.get("dataset_name", "unnamed-dataset")),
        "dataset_kind": str(dataset.get("dataset_kind", "custom")),
        "collected_at": str(dataset.get("collected_at", "")),
        "window": {
            "start": str(window.get("start", "")),
            "end": str(window.get("end", "")),
            "duration": str(window.get("duration", "")),
            "evidence_host": str(window.get("evidence_host", "")),
            "primary_actor": str(window.get("primary_actor", "")),
            "absolute_db_position_asc": str(window.get("absolute_db_position_asc", "")),
            "absolute_db_position_desc": str(window.get("absolute_db_position_desc", "")),
            "exclusion_note": str(window.get("exclusion_note", "")),
            "chain_route_status": str(window.get("chain_route_status", "")),
        },
        "surface_labels": [str(item) for item in dataset.get("surface_labels", [])],
        "nis2_context": dict(dataset.get("nis2_context", {})),
        "time_source_status": dict(dataset.get("time_source_status", {})),
        "artifact_hashes": dict(dataset.get("artifact_hashes", {})),
        "entries": entries,
        "canonical_examples": list(dataset.get("canonical_examples", [])),
        "fixture": dataset.get("fixture"),
    }
    return normalized
