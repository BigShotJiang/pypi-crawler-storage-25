from __future__ import annotations

import json
import socket
from typing import Any

from .model import touched_endpoints


def runtime_host_summary() -> str:
    hostname = socket.gethostname()
    try:
        host_ip = socket.gethostbyname(hostname)
    except OSError:
        host_ip = "unresolved"
    return f"{hostname} ({host_ip})"


def _window(dataset: dict[str, Any]) -> dict[str, Any]:
    return dataset["window"]


def _time_source(dataset: dict[str, Any]) -> dict[str, Any]:
    return dataset.get("time_source_status", {})


def render_time_source(dataset: dict[str, Any]) -> str:
    time_source = _time_source(dataset)
    drift = time_source.get("drift_seconds")
    if isinstance(drift, (int, float)):
        drift_str = f"{drift:+.3f}s ({time_source.get('drift_direction', 'unknown')})"
    else:
        drift_str = "unknown"
    sync_evidence = (
        "yes" if time_source.get("evidence_server_ntp_synced") is True
        else "NO ⚠" if time_source.get("evidence_server_ntp_synced") is False
        else "unknown"
    )
    sync_anchor = (
        "yes" if time_source.get("anchor_server_ntp_synced") is True
        else "no" if time_source.get("anchor_server_ntp_synced") is False
        else "unknown"
    )
    return "\n".join(
        [
            "",
            "Time-Source Status",
            "-" * 18,
            f"Evidence server: {time_source.get('evidence_server', _window(dataset).get('evidence_host', ''))}",
            f"  NTP synced:    {sync_evidence}",
            f"  Time zone:     {time_source.get('evidence_server_zone', 'unknown')}",
            f"  RTC drift:     {time_source.get('rtc_drift_seconds', 'unknown')}",
            "",
            f"Anchor server:   {time_source.get('anchor_server', 'unknown')}",
            f"  NTP synced:    {sync_anchor}",
            f"  Time zone:     {time_source.get('anchor_server_zone', 'unknown')}",
            "",
            f"Primary model:   {time_source.get('primary_ordering_model', 'unknown')}",
            "",
            "Causal note:",
            f"  {time_source.get('causal_clock_note', 'No causal note supplied.')}",
            "",
            f"Drift:           {drift_str}",
            f"Method:          {time_source.get('anchor_method', 'unknown')}",
            f"Measured at:     {time_source.get('measurement_utc', 'unknown')}",
            "",
            "Advisory:",
            f"  {time_source.get('advisory', 'No advisory supplied.')}",
            "",
            "Remediation path:",
            f"  {time_source.get('remediation_path', 'No remediation path supplied.')}",
            "",
        ]
    )


def render_info(dataset: dict[str, Any]) -> str:
    window = _window(dataset)
    time_source = _time_source(dataset)
    drift = time_source.get("drift_seconds")
    drift_str = f"{drift:+.3f}s" if isinstance(drift, (int, float)) else "unknown"
    ntp_str = (
        "yes" if time_source.get("evidence_server_ntp_synced") is True
        else "NO ⚠" if time_source.get("evidence_server_ntp_synced") is False
        else "unknown"
    )
    return "\n".join(
        [
            "",
            "TIBET-BOM — Bill Of Hack",
            "-" * 32,
            f"Dataset:        {dataset['dataset_name']} ({dataset['dataset_kind']})",
            f"Runtime:        {runtime_host_summary()}",
            f"Evidence host:  {window.get('evidence_host', '')}",
            f"Actor:          {window.get('primary_actor', '')}",
            f"Window:         {window.get('start', '')} -> {window.get('end', '')}",
            f"Duration:       {window.get('duration', '')}",
            f"DB ASC:         {window.get('absolute_db_position_asc', '')}",
            f"DB DESC:        {window.get('absolute_db_position_desc', '')}",
            f"Entries:        {len(dataset.get('entries', []))}",
            f"Artifacts:      {len(dataset.get('artifact_hashes', {}))}",
            "",
            "Scope:",
            "  Operator-side attack inventory keyed to typed-chain positions,",
            "  timestamps, endpoint surface, and corroborating artefacts.",
            "",
            "Dataset notice:",
            "  This command renders the currently selected dataset.",
            "  It does not claim that the current machine is the evidence host.",
            "",
            "Exclusion:",
            f"  {window.get('exclusion_note', '')}",
            "",
            "Route status:",
            f"  {window.get('chain_route_status', '')}",
            "",
            "Time-source status (summary):",
            f"  Primary model:              {time_source.get('primary_ordering_model', 'unknown')}",
            f"  Evidence server NTP-synced: {ntp_str}",
            f"  Drift vs anchor:            {drift_str}",
            "  Run `tibet-bom time-source` for full advisory.",
            "",
        ]
    )


def render_timeline(dataset: dict[str, Any]) -> str:
    lines = ["", "Timeline", "-" * 8]
    for entry in sorted(dataset.get("entries", []), key=lambda item: item["timestamp_utc"]):
        lines.append(
            f"{entry['timestamp_utc']}  "
            f"[{entry['view']}:{entry['position']}]  "
            f"{entry['endpoint']}  "
            f"{entry['note']}"
        )
    lines.append("")
    return "\n".join(lines)


def render_table(dataset: dict[str, Any]) -> str:
    lines = []
    header = f"{'BOM ID':<15} {'View':<20} {'Pos':>4} {'Timestamp UTC':<19} {'Endpoint':<24} {'HTTP':>4}"
    lines.append(header)
    lines.append("-" * len(header))
    for entry in dataset.get("entries", []):
        status = "-" if entry.get("http_status") is None else str(entry.get("http_status"))
        lines.append(
            f"{entry['bom_id']:<15} {entry['view']:<20} {entry['position']:>4} "
            f"{entry['timestamp_utc']:<19} {entry['endpoint']:<24} {status:>4}"
        )
    return "\n".join(lines)


def render_artifacts(dataset: dict[str, Any]) -> str:
    lines = ["", "Artefact Hashes", "-" * 14]
    for path, digest in dataset.get("artifact_hashes", {}).items():
        lines.append(path)
        lines.append(f"  sha256 {digest}")
    lines.append("")
    return "\n".join(lines)


def render_report(dataset: dict[str, Any]) -> str:
    window = _window(dataset)
    time_source = _time_source(dataset)
    lines = [
        "",
        "TIBET Incident Transparency Report",
        "-" * 33,
        f"Dataset:        {dataset['dataset_name']} ({dataset['dataset_kind']})",
        f"Runtime:        {runtime_host_summary()}",
        f"Evidence host:  {window.get('evidence_host', '')}",
        f"Actor:          {window.get('primary_actor', '')}",
        f"Window:         {window.get('start', '')} -> {window.get('end', '')}",
        f"Duration:       {window.get('duration', '')}",
        f"DB ASC:         {window.get('absolute_db_position_asc', '')}",
        f"DB DESC:        {window.get('absolute_db_position_desc', '')}",
        "",
        "Attack Surface:",
    ]
    for label in dataset.get("surface_labels", []):
        lines.append(f"  - {label}")
    lines.extend(["", "Touched Endpoints:"])
    for endpoint in touched_endpoints(dataset.get("entries", [])):
        lines.append(f"  - {endpoint}")
    lines.extend(
        [
            "",
            "Chain Mapping Status:",
            f"  - {window.get('chain_route_status', '')}",
            "",
            "Time-Source Status:",
            f"  - Primary model: {time_source.get('primary_ordering_model', 'unknown')}",
            f"  - Causal note: {time_source.get('causal_clock_note', 'No causal note supplied.')}",
            f"  - Evidence server NTP synced: "
            f"{'yes' if time_source.get('evidence_server_ntp_synced') is True else 'NO ⚠' if time_source.get('evidence_server_ntp_synced') is False else 'unknown'}",
            f"  - Drift vs anchor: "
            f"{f'{time_source.get('drift_seconds'):+.3f}s' if isinstance(time_source.get('drift_seconds'), (int, float)) else 'unknown'} "
            f"({time_source.get('drift_direction', 'unknown')})",
            f"  - Advisory: {time_source.get('advisory', 'No advisory supplied.')}",
            "",
            "NIS2 Relevance:",
            f"  - Article 23: {dataset.get('nis2_context', {}).get('article_23_relevance', '')}",
            f"  - Article 21: {dataset.get('nis2_context', {}).get('article_21_relevance', '')}",
            "",
            "Key Claim:",
            "  - The selected incident window is bounded, chain-indexed, and",
            "    exportable as a human-readable bill of adversarial actions.",
            "",
        ]
    )
    return "\n".join(lines)


def render_json(dataset: dict[str, Any]) -> str:
    payload = dict(dataset)
    payload["runtime_host"] = runtime_host_summary()
    return json.dumps(payload, indent=2)


def _markdown_time_source_block(dataset: dict[str, Any]) -> list[str]:
    time_source = _time_source(dataset)
    return [
        "## Time-Source Status",
        "",
        f"- Evidence server: `{time_source.get('evidence_server', _window(dataset).get('evidence_host', ''))}`",
        f"- Evidence server NTP synced: "
        f"**{'yes' if time_source.get('evidence_server_ntp_synced') is True else 'NO ⚠' if time_source.get('evidence_server_ntp_synced') is False else 'unknown'}**",
        f"- Evidence server time zone: `{time_source.get('evidence_server_zone', 'unknown')}`",
        f"- Evidence server RTC drift: `{time_source.get('rtc_drift_seconds', 'unknown')}`",
        f"- Anchor server: `{time_source.get('anchor_server', 'unknown')}`",
        f"- Anchor server NTP synced: "
        f"**{'yes' if time_source.get('anchor_server_ntp_synced') is True else 'no' if time_source.get('anchor_server_ntp_synced') is False else 'unknown'}**",
        f"- Primary ordering model: `{time_source.get('primary_ordering_model', 'unknown')}`",
        f"- Drift vs anchor: `{f'{time_source.get('drift_seconds'):+.3f}s' if isinstance(time_source.get('drift_seconds'), (int, float)) else 'unknown'}` "
        f"({time_source.get('drift_direction', 'unknown')})",
        f"- Anchor method: {time_source.get('anchor_method', 'unknown')}",
        f"- Measured at: `{time_source.get('measurement_utc', 'unknown')}`",
        "",
        "**Causal note.**",
        "",
        f"> {time_source.get('causal_clock_note', 'No causal note supplied.')}",
        "",
        "**Advisory.**",
        "",
        f"> {time_source.get('advisory', 'No advisory supplied.')}",
        "",
        "**Remediation path.**",
        "",
        f"> {time_source.get('remediation_path', 'No remediation path supplied.')}",
        "",
    ]


def render_markdown(dataset: dict[str, Any]) -> str:
    window = _window(dataset)
    entry_lines = []
    for entry in dataset.get("entries", []):
        http = "-" if entry.get("http_status") is None else str(entry.get("http_status"))
        entry_lines.append(
            f"| {entry['bom_id']} | `{entry['view']}` | {entry['position']} | "
            f"{entry['timestamp_utc']} | `{entry['classification']}` | "
            f"`{entry['endpoint']}` | {http} | {entry['note']} |"
        )

    artifact_lines = []
    for path, digest in dataset.get("artifact_hashes", {}).items():
        artifact_lines.append(f"- `{path}`")
        artifact_lines.append(f"  `sha256 {digest}`")

    example_lines = []
    for example in dataset.get("canonical_examples", []):
        example_lines.append("```json")
        example_lines.append(json.dumps(example, ensure_ascii=True, sort_keys=True))
        example_lines.append("```")

    parts = [
        "# TIBET-BOM — Bill Of Hack",
        "",
        f"**Dataset:** `{dataset['dataset_name']}` ({dataset['dataset_kind']})",
        "",
        "## Window",
        "",
        f"- Evidence host: `{window.get('evidence_host', '')}`",
        f"- Runtime host: `{runtime_host_summary()}`",
        f"- Actor: `{window.get('primary_actor', '')}`",
        f"- Start: `{window.get('start', '')}`",
        f"- End: `{window.get('end', '')}`",
        f"- Duration: `{window.get('duration', '')}`",
        f"- Absolute DB positions (ASC): `{window.get('absolute_db_position_asc', '')}`",
        f"- Absolute DB positions (DESC): `{window.get('absolute_db_position_desc', '')}`",
        "",
        "## Exclusion",
        "",
        f"- {window.get('exclusion_note', '')}",
        "",
        "## Chain Mapping Status",
        "",
        f"- {window.get('chain_route_status', '')}",
        "",
        *_markdown_time_source_block(dataset),
        "## BOM Table",
        "",
        "| BOM ID | View | Pos | Timestamp UTC | Classification | Endpoint | HTTP | Note |",
        "|---|---|---:|---|---|---|---:|---|",
        *entry_lines,
        "",
        "## Attack Surface",
        "",
        *[f"- {label}" for label in dataset.get("surface_labels", [])],
        "",
        "## Touched Endpoints",
        "",
        *[f"- `{endpoint}`" for endpoint in touched_endpoints(dataset.get("entries", []))],
        "",
        "## Artefact Hashes",
        "",
        *artifact_lines,
        "",
        "## NIS2 Relevance",
        "",
        f"- Article 23: {dataset.get('nis2_context', {}).get('article_23_relevance', '')}",
        f"- Article 21: {dataset.get('nis2_context', {}).get('article_21_relevance', '')}",
        "",
        "## Canonical Examples",
        "",
        *example_lines,
        "",
    ]
    return "\n".join(parts)
