from __future__ import annotations

import json
import subprocess

from tibet_bom.collect import (
    collect_fixture_phase5,
    collect_from_journald,
    collect_from_nginx_logs,
    collect_from_postgres,
    collect_from_ssh_journald,
    collect_from_ssh_nginx_logs,
    collect_from_ssh_postgres,
    collect_runtime_dataset,
)
from tibet_bom.fixtures import PHASE5_DB_BACKSOLVE
from tibet_bom.render import render_info, render_json
from tibet_bom.store import get_dataset, list_datasets, save_dataset


def _install_fixture_dataset(monkeypatch, tmp_path):
    monkeypatch.setenv("TIBET_BOM_HOME", str(tmp_path / "tibet-bom-home"))
    dataset = collect_fixture_phase5()
    save_dataset(dataset, set_active=True)
    return get_dataset()


def test_fixture_and_runtime_window_are_synced(monkeypatch, tmp_path) -> None:
    dataset = _install_fixture_dataset(monkeypatch, tmp_path)
    payload = json.loads(render_json(dataset))

    assert payload["window"]["absolute_db_position_asc"] == "407-423"
    assert payload["fixture"]["positions"]["absolute_db"]["ascending"] == "407-423"
    assert payload["fixture"]["window"]["end_utc"] == "2026-05-04T12:29:39.537104"
    assert len(payload["fixture"]["rows"]) == 17


def test_time_source_is_causality_first(monkeypatch, tmp_path) -> None:
    dataset = _install_fixture_dataset(monkeypatch, tmp_path)
    payload = json.loads(render_json(dataset))
    time_source = payload["time_source_status"]

    assert time_source["primary_ordering_model"] == "TIBET causal / logical ordering"
    assert "Lamport-like logical clock structure" in time_source["causal_clock_note"]
    assert "causal ordering" in time_source["advisory"]


def test_info_separates_runtime_from_evidence_host(monkeypatch, tmp_path) -> None:
    dataset = _install_fixture_dataset(monkeypatch, tmp_path)
    info = render_info(dataset)

    assert "Runtime:" in info
    assert "Evidence host:  P520 staging (10.0.100.2)" in info
    assert "192.168.4.85" not in info


def test_last_fixture_row_matches_final_phase5_event() -> None:
    last = PHASE5_DB_BACKSOLVE["rows"][-1]

    assert last["token_id"] == "b206bb78-b71b-4654-91fb-6baf605f0f42"
    assert last["pos_asc"] == 423
    assert last["pos_desc"] == 282
    assert last["created_at"] == "2026-05-04T12:29:39.537104"


def test_runtime_collect_can_store_custom_dataset(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("TIBET_BOM_HOME", str(tmp_path / "tibet-bom-home"))
    entries_file = tmp_path / "entries.json"
    entries_file.write_text(
        json.dumps(
            [
                {
                    "bom_id": "TIBET-BOM-900",
                    "view": "security_violation",
                    "position": 1,
                    "timestamp_utc": "2026-05-08 12:00:00 UTC",
                    "classification": "bewaken",
                    "endpoint": "/api/test",
                    "note": "Synthetic test event",
                }
            ]
        ),
        encoding="utf-8",
    )

    dataset = collect_runtime_dataset(
        name="runtime-test",
        evidence_host="lab-host",
        actor="127.0.0.1",
        window_start="2026-05-08 12:00:00 UTC",
        window_end="2026-05-08 12:00:01 UTC",
        duration="1 second",
        db_asc="1-1",
        db_desc="1-1",
        chain_route_status="manual",
        exclusion_note="none",
        surface_labels=["test surface"],
        entry_json=str(entries_file),
        entry_jsonl=None,
        artifact_paths=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )
    save_dataset(dataset, set_active=True)
    active = get_dataset()
    names = [item["name"] for item in list_datasets()]

    assert active["dataset_name"] == "runtime-test"
    assert active["window"]["evidence_host"] == "lab-host"
    assert len(active["entries"]) == 1
    assert "runtime-test" in names


def test_nginx_collector_parses_and_hashes_logs(tmp_path) -> None:
    log_path = tmp_path / "access.log"
    log_path.write_text(
        '10.0.0.7 - - [08/May/2026:12:00:00 +0000] "GET /api/tibet/status HTTP/1.1" 401 123\n'
        '10.0.0.7 - - [08/May/2026:12:00:02 +0000] "GET /health HTTP/1.1" 200 10\n',
        encoding="utf-8",
    )
    dataset = collect_from_nginx_logs(
        name="nginx-test",
        log_paths=[str(log_path)],
        evidence_host="nginx-host",
        actor=None,
        path_contains="/api/",
        status_min=400,
        db_asc=None,
        db_desc=None,
        chain_route_status="log-only",
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_name"] == "nginx-test"
    assert dataset["window"]["primary_actor"] == "10.0.0.7"
    assert len(dataset["entries"]) == 1
    assert dataset["entries"][0]["endpoint"] == "/api/tibet/status"
    assert str(log_path) in dataset["artifact_hashes"]


def test_journald_collector_parses_json_stream(monkeypatch) -> None:
    stdout = "\n".join(
        [
            json.dumps(
                {
                    "__REALTIME_TIMESTAMP": "1778241600000000",
                    "MESSAGE": "[MUX-0x00] 151.229.231.77 -> /api/tibet/sign absorbed",
                }
            ),
            json.dumps(
                {
                    "__REALTIME_TIMESTAMP": "1778241601000000",
                    "MESSAGE": "verification probe /api/internal/nullroute/status from 10.0.0.7",
                }
            ),
        ]
    )

    def fake_run(command, capture_output, text, check, env=None):
        assert command[:3] == ["journalctl", "--no-pager", "-o"]
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_journald(
        name="journal-test",
        evidence_host="journal-host",
        actor=None,
        unit="brain.service",
        since="2026-05-08 12:00:00",
        until="2026-05-08 12:10:00",
        grep="MUX",
        db_asc=None,
        db_desc=None,
        chain_route_status="journal-only",
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "journald"
    assert len(dataset["entries"]) == 2
    assert dataset["entries"][0]["endpoint"] == "/api/tibet/sign"
    assert dataset["entries"][0]["client_ip"] == "151.229.231.77"


def test_journald_collector_allows_no_matches(monkeypatch) -> None:
    def fake_run(command, capture_output, text, check, env=None):
        return subprocess.CompletedProcess(command, 1, stdout="", stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_journald(
        name="journal-empty",
        evidence_host="journal-host",
        actor=None,
        unit=None,
        since="2026-05-08 12:00:00",
        until=None,
        grep="definitely-no-match",
        db_asc=None,
        db_desc=None,
        chain_route_status="journal-only",
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "journald"
    assert dataset["entries"] == []


def test_postgres_collector_coalesces_csv_rows(monkeypatch) -> None:
    stdout = "\n".join(
        [
            "created_at,token_type,pos_asc,path,client_ip,erin",
            "2026-05-04T12:27:24.712878,security_violation,407,/api/tibet/sign,10.0.100.11,First visible hit",
        ]
    )

    def fake_run(command, capture_output, text, check, env=None):
        assert command[0] == "psql"
        assert "--csv" in command
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_postgres(
        name="postgres-test",
        evidence_host="postgres-host",
        actor=None,
        query="select 1",
        query_file=None,
        dsn=None,
        dbname="jtel_security",
        user=None,
        host=None,
        port=None,
        db_asc="407-407",
        db_desc="298-298",
        chain_route_status="db-verified",
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "postgres_query"
    assert len(dataset["entries"]) == 1
    assert dataset["entries"][0]["view"] == "security_violation"
    assert dataset["entries"][0]["position"] == 407
    assert dataset["window"]["primary_actor"] == "10.0.100.11"


def test_ssh_journald_collector_parses_remote_json(monkeypatch) -> None:
    stdout = json.dumps(
        {
            "__REALTIME_TIMESTAMP": "1778241600000000",
            "MESSAGE": "[MUX] 10.0.0.8 hit /api/tibet/query",
        }
    )

    def fake_run(command, capture_output, text, check, env=None):
        assert command[0] == "ssh"
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_ssh_journald(
        name="ssh-journal-test",
        ssh_host="example-host",
        ssh_user="root",
        evidence_host=None,
        actor=None,
        unit=None,
        since=None,
        until=None,
        grep=None,
        db_asc=None,
        db_desc=None,
        chain_route_status=None,
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "ssh_journald"
    assert dataset["window"]["evidence_host"] == "example-host"
    assert dataset["entries"][0]["endpoint"] == "/api/tibet/query"


def test_ssh_journald_collector_allows_no_matches(monkeypatch) -> None:
    def fake_run(command, capture_output, text, check, env=None):
        assert command[0] == "ssh"
        return subprocess.CompletedProcess(command, 1, stdout="", stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_ssh_journald(
        name="ssh-journal-empty",
        ssh_host="example-host",
        ssh_user="root",
        evidence_host=None,
        actor=None,
        unit=None,
        since=None,
        until=None,
        grep="definitely-no-match",
        db_asc=None,
        db_desc=None,
        chain_route_status=None,
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "ssh_journald"
    assert dataset["entries"] == []


def test_ssh_postgres_collector_coalesces_remote_csv(monkeypatch) -> None:
    stdout = "\n".join(
        [
            "created_at,token_type,pos_asc,path,client_ip,erin",
            "2026-05-04T12:27:24.712878,security_violation,407,/api/tibet/sign,10.0.100.11,remote smoke",
        ]
    )

    def fake_run(command, capture_output, text, check, env=None):
        assert command[0] == "ssh"
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_ssh_postgres(
        name="ssh-postgres-test",
        ssh_host="p520",
        ssh_user="root",
        evidence_host=None,
        actor=None,
        query="select 1",
        query_file=None,
        dbname="jtel_security",
        db_asc=None,
        db_desc=None,
        chain_route_status=None,
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "ssh_postgres"
    assert dataset["entries"][0]["position"] == 407
    assert dataset["window"]["evidence_host"] == "p520"


def test_ssh_nginx_collector_parses_remote_logs(monkeypatch) -> None:
    log_stdout = '10.0.0.7 - - [08/May/2026:12:00:00 +0000] "GET /api/tibet/status HTTP/1.1" 401 123\n'
    hash_stdout = "abc123  /var/log/nginx/access.log\n"
    calls = {"count": 0}

    def fake_run(command, capture_output, text, check, env=None):
        assert command[0] == "ssh"
        calls["count"] += 1
        stdout = log_stdout if calls["count"] == 1 else hash_stdout
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr="")

    monkeypatch.setattr("tibet_bom.collect.subprocess.run", fake_run)
    dataset = collect_from_ssh_nginx_logs(
        name="ssh-nginx-test",
        ssh_host="edge-host",
        ssh_user=None,
        log_paths=["/var/log/nginx/access.log"],
        evidence_host=None,
        actor=None,
        path_contains="/api/",
        status_min=400,
        db_asc=None,
        db_desc=None,
        chain_route_status=None,
        exclusion_note=None,
        surface_labels=[],
        time_source_json=None,
        nis2_json=None,
        canonical_json=None,
    )

    assert dataset["dataset_kind"] == "ssh_nginx_access"
    assert dataset["entries"][0]["endpoint"] == "/api/tibet/status"
    assert dataset["artifact_hashes"]["/var/log/nginx/access.log"] == "abc123"
