"""portico CLI -- single entry point that wires the pipeline together.

Loader -> Summarizer (if oversized) -> Cache check -> Analyzer -> Renderer.
Failure classes route to exit codes per the spec failure taxonomy.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from portico import __version__
from portico.analyzer import F4MalformedJSON, analyze
from portico.cache import Cache, cache_key
from portico.config import (
    get_anthropic_api_key,
    get_default_model,
    get_default_provider,
)
from portico.loaders.base import (
    F1NetworkUnavailable,
    F1NotFound,
    F1RemoteInaccessible,
    F2NotParseable,
    F2TooLarge,
    LoadedInput,
)
from portico.loaders.dir import load_dir
from portico.loaders.file import load_file
from portico.loaders.repo import load_repo
from portico.loaders.text import load_stdin, load_text
from portico.loaders.url import load_url
from portico.providers.base import (
    LLMProvider,
    ProviderAuthError,
    ProviderTransportError,
)
from portico.providers.claude import DEFAULT_MODEL, ClaudeProvider
from portico.providers.gemini import GeminiProvider
from portico.providers.openai import OpenAIProvider
from portico.render import MAX_WIDTH, render
from portico.render.apex import generate_apex
from portico.schema import FitQuality, PorticoJSON
from portico.summarize import summarize

REFUSAL_TEMPLATE = """\
portico could not build a portico for this input.

reason: {reason}

input type detected: {theme}

what you can try:
  • run with --force to render anyway
  • narrow the input and try again
  • verify the input is what you intended
"""


# --- Exit codes ---
EXIT_OK = 0
EXIT_F1_NOT_FOUND = 2
EXIT_F1_REMOTE = 3
EXIT_F1_NETWORK = 4
EXIT_F2_NOT_PARSEABLE = 5
EXIT_F2_TOO_LARGE = 6
EXIT_F4_MALFORMED = 7
EXIT_F4_TRANSPORT = 8
EXIT_F4_AUTH = 9


@dataclass
class Args:
    input_value: str | None
    input_type: str | None
    style: str
    legend: bool
    width: int
    height: int | None
    json_out: bool
    provider: str
    model: str
    no_cache: bool
    diagnose: bool
    force: bool
    strict: bool
    reapex: bool
    reapex_seed: int | None


def make_provider(name: str) -> LLMProvider:
    if name == "claude":
        return ClaudeProvider(api_key=get_anthropic_api_key())
    if name == "openai":
        return OpenAIProvider()
    if name == "gemini":
        return GeminiProvider()
    raise ValueError(f"unknown provider: {name}")


# Bare filenames like `essay.md` look like file paths even without a slash.
# Listing common extensions stops the heuristic from misreading "Trust scales..."
# (period + word) as a file path.
_FILE_EXTENSIONS = frozenset(
    {
        ".txt", ".md", ".rst", ".log", ".csv", ".tsv", ".json", ".yaml", ".yml",
        ".toml", ".ini", ".conf", ".xml", ".html", ".htm", ".css", ".js", ".ts",
        ".tsx", ".jsx", ".py", ".rb", ".go", ".rs", ".java", ".c", ".h", ".cpp",
        ".hpp", ".cs", ".php", ".lua", ".sh", ".bash", ".zsh", ".sql", ".lock",
    }
)


def _looks_like_path(value: str) -> bool:
    if "/" in value or "\\" in value:
        return True
    if " " in value or "\n" in value:
        return False
    suffix = Path(value).suffix.lower()
    return suffix in _FILE_EXTENSIONS


def detect_input_type(value: str) -> str:
    if value.startswith(("http://", "https://")):
        return "url"
    p = Path(value)
    if p.exists():
        return "dir" if p.is_dir() else "file"
    if _looks_like_path(value):
        # Path-shaped but missing -- let the file loader surface the F1 instead
        # of silently treating the string as raw text.
        return "file"
    return "text"


def load(value: str | None, *, input_type: str | None) -> LoadedInput:
    if value is None:
        if sys.stdin.isatty():
            raise F2NotParseable(
                "no input provided. Pass a path, URL, raw text, or pipe via stdin "
                "(e.g. `echo 'hello' | portico -`). See `portico --help`."
            )
        return load_stdin()
    if value == "-":
        return load_stdin()
    t = input_type or detect_input_type(value)
    if t == "url":
        return load_url(value)
    if t == "file":
        return load_file(value)
    if t == "dir":
        return load_dir(value)
    if t == "repo":
        return load_repo(value)
    return load_text(value)


def resolve_width(arg_width: int | None) -> int:
    if arg_width is not None:
        return arg_width
    return min(shutil.get_terminal_size((MAX_WIDTH, 24)).columns, MAX_WIDTH)


def resolve_height(arg_height: int | None) -> int | None:
    if arg_height is not None:
        return arg_height
    # Auto-detect terminal height. Fallback (24) is a sensible "non-tiny" terminal;
    # callers piping to a file get None semantics via the override path.
    return shutil.get_terminal_size((MAX_WIDTH, 24)).lines


def render_refusal(data: PorticoJSON) -> str:
    return REFUSAL_TEMPLATE.format(reason=data.notes_on_fit, theme=data.theme)


def render_diagnostics(
    loaded: LoadedInput, data: PorticoJSON, *, model: str, provider_name: str
) -> str:
    return (
        f"input:        {loaded.source}\n"
        f"type:         {loaded.input_type}\n"
        f"chars:        {loaded.metadata.get('chars', len(loaded.text))}\n"
        f"summarized:   {loaded.metadata.get('summarized', False)}\n"
        f"provider:     {provider_name}\n"
        f"model:        {model}\n"
        f"fit_quality:  {data.fit_quality.value}\n"
        f"notes_on_fit: {data.notes_on_fit}\n"
    )


def run(args: Args, *, provider: LLMProvider | None = None) -> int:
    """The pipeline. `provider` injection is for tests."""
    try:
        loaded = load(args.input_value, input_type=args.input_type)
    except F1NotFound as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F1_NOT_FOUND
    except F1RemoteInaccessible as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F1_REMOTE
    except F1NetworkUnavailable as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F1_NETWORK
    except F2NotParseable as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F2_NOT_PARSEABLE

    prov = provider or make_provider(args.provider)

    try:
        loaded = summarize(loaded, provider=prov, model=args.model)
    except F2TooLarge as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F2_TOO_LARGE
    except ProviderAuthError as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F4_AUTH
    except ProviderTransportError as e:
        print(f"portico: {e}", file=sys.stderr)
        return EXIT_F4_TRANSPORT

    cache = Cache()
    key = cache_key(loaded.text, provider=args.provider, model=args.model)
    data: PorticoJSON | None = None
    if not args.no_cache:
        data = cache.get(key)

    if data is None:
        try:
            result = analyze(loaded.text, provider=prov, model=args.model)
        except F4MalformedJSON as e:
            print(f"portico: {e}", file=sys.stderr)
            return EXIT_F4_MALFORMED
        except ProviderAuthError as e:
            print(f"portico: {e}", file=sys.stderr)
            return EXIT_F4_AUTH
        except ProviderTransportError as e:
            print(f"portico: {e}", file=sys.stderr)
            return EXIT_F4_TRANSPORT
        data = result.data
        if not args.no_cache:
            cache.put(key, data)

    if args.diagnose:
        print(render_diagnostics(loaded, data, model=args.model, provider_name=args.provider))
        return EXIT_OK

    if args.json_out:
        print(json.dumps(data.model_dump(mode="json"), indent=2))
        return EXIT_OK

    # F3 routing -- abstain when fit_quality demands it.
    fq = data.fit_quality
    if fq == FitQuality.NOT_APPLICABLE:
        print(render_refusal(data))
        return EXIT_OK
    if fq == FitQuality.FORCED and not args.force:
        print(render_refusal(data))
        return EXIT_OK
    if fq == FitQuality.STRETCHED and args.strict:
        print(render_refusal(data))
        return EXIT_OK

    apex_seed_label: str | None = None
    if args.reapex:
        finial, keystone, used_seed = generate_apex(args.reapex_seed)
        apex_seed_label = f"apex seed: {used_seed}"
    else:
        finial, keystone, _ = generate_apex()
    apex_override: tuple[str, str] | None = (finial, keystone)

    print(
        render(
            data,
            width=args.width,
            height=args.height,
            legend=args.legend,
            apex_override=apex_override,
            apex_seed_label=apex_seed_label,
        ),
        end="",
    )
    return EXIT_OK


def parse_args(argv: list[str] | None = None) -> Args:
    parser = argparse.ArgumentParser(prog="portico", description="Render any input as a portico.")
    parser.add_argument("input", nargs="?", help="Path, URL, raw text, or '-' for stdin.")
    parser.add_argument("--type", dest="input_type", choices=["text", "file", "dir", "url", "repo"])
    parser.add_argument("--style", default="default")
    parser.add_argument(
        "--no-legend",
        dest="legend",
        action="store_false",
        help="suppress the per-layer summary that renders below the portico.",
    )
    parser.add_argument("--width", type=int, default=None)
    parser.add_argument(
        "--height",
        type=int,
        default=None,
        help="row budget for the rendered output; defaults to terminal height. "
        "When set, the legend collapses to one line per entry if total rows "
        "would otherwise exceed this.",
    )
    parser.add_argument("--json", dest="json_out", action="store_true")
    parser.add_argument(
        "--provider",
        choices=["claude", "openai", "gemini"],
        default=get_default_provider(),
    )
    parser.add_argument("--model", default=get_default_model() or DEFAULT_MODEL)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--diagnose", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument(
        "--reapex",
        nargs="?",
        const="__random__",
        default=None,
        help="Pin the apex to a specific seed (random by default). Pass --reapex=SEED.",
    )
    parser.add_argument("--version", action="version", version=f"portico {__version__}")
    parsed = parser.parse_args(argv)

    reapex = parsed.reapex is not None
    reapex_seed: int | None = None
    if reapex and parsed.reapex != "__random__":
        try:
            reapex_seed = int(parsed.reapex)
        except ValueError:
            parser.error(
                f"--reapex value must be an integer seed, got {parsed.reapex!r}"
            )

    return Args(
        input_value=parsed.input,
        input_type=parsed.input_type,
        style=parsed.style,
        legend=parsed.legend,
        width=resolve_width(parsed.width),
        height=resolve_height(parsed.height),
        json_out=parsed.json_out,
        provider=parsed.provider,
        model=parsed.model,
        no_cache=parsed.no_cache,
        diagnose=parsed.diagnose,
        force=parsed.force,
        strict=parsed.strict,
        reapex=reapex,
        reapex_seed=reapex_seed,
    )


def main() -> None:
    args = parse_args()
    sys.exit(run(args))
