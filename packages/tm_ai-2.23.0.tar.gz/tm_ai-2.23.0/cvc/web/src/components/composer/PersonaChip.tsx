import { useCallback, useRef, useState } from "react";
import { Check, ChevronDown, User } from "lucide-react";
import { useDismissableDropdown } from "@/lib/hooks/useDismissableDropdown";
import { cn } from "@/lib/utils";
import type { PersonaSummary } from "@/lib/types";

interface PersonaChipProps {
  active: PersonaSummary | null;
  personas: PersonaSummary[];
  onChange(personaId: string): void;
  dropUp?: boolean;
}

/**
 * Hermes-style persona chip. Yellow accent on icon + label to mark it as
 * the agent identity. Opens an upward dropdown with persona list.
 */
export function PersonaChip({ active, personas, onChange, dropUp = true }: PersonaChipProps) {
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const close = useCallback(() => setOpen(false), []);
  useDismissableDropdown(open, close, wrapperRef);

  const label = active?.name ? active.name.toLowerCase() : (active?.id ?? "persona");

  return (
    <div ref={wrapperRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "inline-flex h-8 items-center gap-1.5 rounded-full px-2.5",
          "text-[13px] font-medium text-[color:var(--color-warning)] hover:bg-[color:var(--midground-base)]/10 transition-colors",
        )}
        aria-label="Switch persona"
        aria-expanded={open}
        aria-haspopup="listbox"
        title={active?.name ? `Persona: ${active.name}` : "Choose persona"}
      >
        <User className="h-4 w-4" strokeWidth={2} />
        <span>{label}</span>
        <ChevronDown className="h-3.5 w-3.5 opacity-70" strokeWidth={2.5} />
      </button>

      {open && personas.length > 0 && (
        <div
          role="listbox"
          aria-label="Persona"
          className={cn(
            "absolute z-50 min-w-[260px] rounded-xl",
            dropUp ? "left-0 bottom-full mb-2" : "left-0 top-full mt-2",
            "border border-[color:var(--color-border)] bg-[color:var(--background-base)]/95 backdrop-blur-md",
            "shadow-[0_12px_40px_-8px_rgba(0,0,0,0.7)]",
            "py-1 overflow-hidden",
          )}
        >
          <div className="px-3 py-1.5 text-[10px] uppercase tracking-[0.15em] text-foreground/40">
            Persona
          </div>
          {personas.map((p) => {
            const isActive = active?.id === p.id;
            return (
              <button
                type="button"
                key={p.id}
                role="option"
                aria-selected={isActive}
                onClick={() => {
                  onChange(p.id);
                  close();
                }}
                className={cn(
                  "flex w-full items-center gap-2.5 px-3 py-2 text-left transition-colors",
                  "hover:bg-[color:var(--midground-base)]/10",
                  isActive && "bg-[color:var(--midground-base)]/[0.06]",
                )}
              >
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className={cn("truncate text-[13px]", isActive ? "text-[color:var(--color-warning)]" : "text-foreground/90")}>
                    {p.name}
                  </span>
                  <span className="truncate text-[11px] text-foreground/45">
                    {p.default_model} · {p.skills_count} skills
                  </span>
                </div>
                <Check
                  className={cn(
                    "h-3.5 w-3.5 shrink-0 text-[color:var(--color-warning)]",
                    isActive ? "opacity-100" : "opacity-0",
                  )}
                  strokeWidth={2.5}
                />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
