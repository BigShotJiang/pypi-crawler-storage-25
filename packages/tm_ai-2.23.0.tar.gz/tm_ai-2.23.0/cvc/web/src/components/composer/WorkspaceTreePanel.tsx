import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronRight, X, Eye, EyeOff, RefreshCw } from "lucide-react";
import { Button } from "@nous-research/ui/ui/components/button";
import { Typography } from "@/components/NouiTypography";
import { cn } from "@/lib/utils";
import { api } from "@/lib/api";
import type { WorkspaceTreeNode } from "@/lib/types";
import { useResizable, resizeHandleClass } from "@/lib/useResizable";

interface WorkspaceTreePanelProps {
  rootPath: string;
  open: boolean;
  onClose(): void;
  showHidden: boolean;
  onToggleHidden(v: boolean): void;
  onFileClick?(absPath: string): void;
}

function fmtBytes(n: number): string {
  if (!n || n < 1024) return `${n} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 10 ? 0 : 1)} ${units[i]}`;
}

function fmtMtime(ts: number): string {
  if (!ts) return "";
  try {
    return new Date(ts * 1000).toLocaleString();
  } catch {
    return "";
  }
}

interface TreeNodeProps {
  node: WorkspaceTreeNode;
  depth: number;
  showHidden: boolean;
  onFileClick?(absPath: string): void;
}

function TreeNode({ node, depth, showHidden, onFileClick }: TreeNodeProps) {
  const [expanded, setExpanded] = useState<boolean>(depth === 0);
  const [children, setChildren] = useState<WorkspaceTreeNode[] | null>(node.children ?? null);
  const [loading, setLoading] = useState(false);

  const loadChildren = useCallback(async () => {
    if (!node.is_dir) return;
    setLoading(true);
    try {
      const fresh = await api.workspaceTree(node.rel_path, 1, showHidden);
      setChildren(fresh.children ?? []);
    } catch {
      setChildren([]);
    } finally {
      setLoading(false);
    }
  }, [node.is_dir, node.rel_path, showHidden]);

  const onToggle = useCallback(async () => {
    const next = !expanded;
    setExpanded(next);
    if (next && node.is_dir && children == null) {
      await loadChildren();
    }
  }, [expanded, node.is_dir, children, loadChildren]);

  const Icon = expanded ? ChevronDown : ChevronRight;

  return (
    <div>
      <button
        type="button"
        onClick={() =>
          node.is_dir ? onToggle() : onFileClick?.(node.path)
        }
        className={cn(
          "flex w-full items-center gap-1.5 px-2 py-1 text-left",
          "hover:bg-midground/10",
        )}
        style={{ paddingLeft: `${0.5 + depth * 0.85}rem` }}
      >
        {node.is_dir ? (
          <Icon className="h-3 w-3 shrink-0 text-midground/70" />
        ) : (
          <span className="h-3 w-3 shrink-0" />
        )}
        <Typography
          mondwest
          className="truncate text-[0.7rem] tracking-wide uppercase flex-1"
        >
          {node.name}
        </Typography>
        {!node.is_dir && (
          <Typography className="shrink-0 text-[0.6rem] normal-case tracking-normal text-midground/50">
            {fmtBytes(node.size)}
          </Typography>
        )}
        <Typography
          className="hidden md:inline shrink-0 text-[0.55rem] normal-case tracking-normal text-midground/40"
          title={fmtMtime(node.mtime)}
        >
          {fmtMtime(node.mtime).split(",")[0]}
        </Typography>
      </button>
      {expanded && node.is_dir && (
        <div>
          {loading && (
            <Typography className="px-2 py-1 text-[0.6rem] normal-case text-midground/50">
              loading…
            </Typography>
          )}
          {children?.map((c) => (
            <TreeNode
              key={c.path}
              node={c}
              depth={depth + 1}
              showHidden={showHidden}
              onFileClick={onFileClick}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function WorkspaceTreePanel({
  rootPath,
  open,
  onClose,
  showHidden,
  onToggleHidden,
  onFileClick,
}: WorkspaceTreePanelProps) {
  const [root, setRoot] = useState<WorkspaceTreeNode | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const resize = useResizable({
    storageKey: "cvc.ui.tree",
    defaultWidth: 352,
    minWidth: 240,
    maxWidth: 640,
    edge: "left",
    collapsedWidth: 0,
    collapseSlack: 48,
  });

  // Snap-to-close: when the hook signals collapsed (dragged past the slack
  // threshold), fully close the panel instead of rendering a sliver.
  const closeRef = useRef(onClose);
  useEffect(() => {
    closeRef.current = onClose;
  }, [onClose]);
  useEffect(() => {
    if (resize.collapsed) {
      resize.reset();
      closeRef.current();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resize.collapsed]);

  const refresh = useCallback(async () => {
    if (!open) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.workspaceTree("", 2, showHidden);
      setRoot(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, [open, showHidden]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  if (!open) return null;

  return (
    <aside
      style={{ width: `${resize.width}px` }}
      className={cn(
        "fixed right-0 top-0 z-40 h-full max-w-[90vw]",
        "border-l border-current/20 bg-background-base/95 backdrop-blur-sm",
        "shadow-[0_12px_32px_-8px_rgba(0,0,0,0.6)]",
        "flex flex-col",
      )}
      aria-label="Workspace tree"
    >
      <div
        role="separator"
        aria-orientation="vertical"
        aria-label="Resize workspace tree"
        onMouseDown={resize.startDrag}
        onTouchStart={resize.startDrag}
        className={resizeHandleClass("left", resize.dragging)}
      />
      <div className="flex items-center gap-2 border-b border-current/20 px-3 py-2">
        <Typography
          mondwest
          className="flex-1 truncate text-[0.65rem] tracking-[0.15em] uppercase text-midground/70"
          title={rootPath}
        >
          {rootPath || "workspace"}
        </Typography>
        <Button
          ghost
          onClick={() => onToggleHidden(!showHidden)}
          className="px-1.5 py-1 normal-case tracking-normal font-normal text-xs text-muted-foreground hover:text-foreground"
          title={showHidden ? "Hide dotfiles" : "Show dotfiles"}
          aria-label={showHidden ? "Hide dotfiles" : "Show dotfiles"}
        >
          {showHidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
        </Button>
        <Button
          ghost
          onClick={() => void refresh()}
          className="px-1.5 py-1 normal-case tracking-normal font-normal text-xs text-muted-foreground hover:text-foreground"
          aria-label="Refresh tree"
          title="Refresh"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", loading && "animate-spin")} />
        </Button>
        <Button
          ghost
          onClick={onClose}
          className="px-1.5 py-1 normal-case tracking-normal font-normal text-xs text-muted-foreground hover:text-foreground"
          aria-label="Close workspace tree"
        >
          <X className="h-3.5 w-3.5" />
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {error && (
          <Typography className="px-3 py-2 text-[0.65rem] normal-case tracking-normal text-destructive">
            {error}
          </Typography>
        )}
        {root && (
          <TreeNode
            node={root}
            depth={0}
            showHidden={showHidden}
            onFileClick={onFileClick}
          />
        )}
      </div>
    </aside>
  );
}
