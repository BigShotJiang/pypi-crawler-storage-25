import { useEffect, useState } from "react";
import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import {
  Activity,
  Bot,
  Boxes,
  Brain,
  Cpu,
  Crown,
  GitBranch,
  GitCommitVertical,
  History,
  KeyRound,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Network,
  Plug,
  Server,
  Settings,
  Share2,
  Wrench,
  X,
} from "lucide-react";
import { Backdrop } from "@/components/Backdrop";
import { ThemeSwitcher } from "@/components/ThemeSwitcher";
import { Typography } from "@/components/NouiTypography";
import { useTheme } from "@/themes";
import { cn } from "@/lib/utils";
import { useGatewayStatus } from "@/lib/useGatewayStatus";
import { useDashboardWS } from "@/lib/useDashboardWS";
import { useResizable, resizeHandleClass } from "@/lib/useResizable";

import OverviewPage from "@/pages/OverviewPage";
import OperationsPage from "@/pages/OperationsPage";
import TimelinePage from "@/pages/TimelinePage";
import HomePage from "@/pages/HomePage";
import SessionsPage from "@/pages/SessionsPage";
import BranchesPage from "@/pages/BranchesPage";
import CommitsPage from "@/pages/CommitsPage";
import MemoryPage from "@/pages/MemoryPage";
import ModelsPage from "@/pages/ModelsPage";
import ConnectionsPage from "@/pages/ConnectionsPage";
import ProvidersPage from "@/pages/ProvidersPage";
import LoopPage from "@/pages/LoopPage";
import TrajectoryPage from "@/pages/TrajectoryPage";
import TeamPage from "@/pages/TeamPage";
import SettingsPage from "@/pages/SettingsPage";
import HiveMindPage from "@/pages/HiveMindPage";
import AgentsPage from "@/pages/AgentsPage";
import MCPPage from "@/pages/MCPPage";
import ProxyPage from "@/pages/ProxyPage";
import SDKPage from "@/pages/SDKPage";
import ChatPage from "@/pages/ChatPage";
import SwarmPage from "@/pages/SwarmPage";

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}
interface NavSection {
  label: string;
  items: NavItem[];
}

const NAV: NavSection[] = [
  {
    label: "Main",
    items: [
      { to: "/overview", label: "Overview", icon: LayoutDashboard },
      { to: "/chat", label: "Chat", icon: MessageSquare },
      { to: "/operations", label: "Operations", icon: Wrench },
      { to: "/timeline", label: "Timeline", icon: GitCommitVertical },
    ],
  },
  {
    label: "Subsystems",
    items: [
      { to: "/hive", label: "Hive Mind", icon: Network },
      { to: "/agents", label: "Agents", icon: Bot },
      { to: "/swarm", label: "Swarm", icon: Share2 },
      { to: "/loop", label: "Loop", icon: Activity },
      { to: "/trajectory", label: "Trajectory", icon: GitCommitVertical },
      { to: "/team", label: "Team", icon: Crown },
      { to: "/mcp", label: "MCP", icon: Boxes },
      { to: "/proxy", label: "Proxy", icon: Server },
      { to: "/sdk", label: "SDK", icon: Boxes },
    ],
  },
  {
    label: "Data",
    items: [
      { to: "/memory", label: "Memory", icon: Brain },
      { to: "/branches", label: "Branches", icon: GitBranch },
      { to: "/commits", label: "Commits", icon: History },
      { to: "/sessions", label: "Sessions", icon: Activity },
    ],
  },
  {
    label: "Config",
    items: [
      { to: "/models", label: "Models", icon: Cpu },
      { to: "/providers", label: "Providers", icon: KeyRound },
      { to: "/connections", label: "Connections", icon: Plug },
      { to: "/settings", label: "Settings", icon: Settings },
    ],
  },
];

function StatusDot({
  state,
  label,
  detail,
}: {
  state: "ok" | "down" | "unknown";
  label: string;
  detail?: string;
}) {
  const color =
    state === "ok"
      ? "bg-emerald-400"
      : state === "down"
        ? "bg-red-400"
        : "bg-midground/40";
  return (
    <div
      className="flex items-center gap-1.5 rounded-md border border-border bg-card/40 px-2 py-1 font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/70"
      title={detail ?? `${label}: ${state}`}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", color)} />
      <span>{label}</span>
    </div>
  );
}

function Sidebar({
  open,
  onClose,
  width,
  collapsed,
  dragging,
  onStartDrag,
}: {
  open: boolean;
  onClose: () => void;
  width: number;
  collapsed: boolean;
  dragging: boolean;
  onStartDrag: (e: React.MouseEvent | React.TouchEvent) => void;
}) {
  return (
    <>
      <div
        className={cn(
          "fixed inset-0 z-40 bg-background-base/60 backdrop-blur-sm transition-opacity md:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        style={{ width: `${width}px` }}
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex flex-col border-r border-border bg-background-base/85 backdrop-blur-xl md:static md:translate-x-0",
          dragging ? "" : "transition-[transform,width]",
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        )}
      >
        <div className="relative flex items-center justify-center px-3 py-4">
          <div
            className="flex h-9 w-9 items-center justify-center rounded-md font-bold text-background-base shadow-[inset_-1px_-1px_0_0_rgba(0,0,0,0.5),inset_1px_1px_0_0_rgba(255,255,255,0.5)]"
            style={{
              background:
                "linear-gradient(135deg, var(--midground-base) 0%, color-mix(in srgb, var(--midground-base) 60%, var(--background-base)) 100%)",
            }}
            title="CVC · Cognitive Version Control"
          >
            <span className="font-mono-ui text-sm">CVC</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-midground/70 hover:bg-midground/10 hover:text-midground md:hidden"
            aria-label="Close sidebar"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto overflow-x-hidden px-3 py-2">
          {NAV.map((section) => (
            <div key={section.label} className="mb-5">
              {!collapsed && (
                <div className="px-3 pb-2 font-mono-ui text-[0.6rem] uppercase tracking-[0.18em] text-midground/45">
                  {section.label}
                </div>
              )}
              <ul className="flex flex-col gap-0.5">
                {section.items.map(({ to, label, icon: Icon }) => (
                  <li key={to}>
                    <NavLink
                      to={to}
                      onClick={onClose}
                      title={collapsed ? label : undefined}
                      className={({ isActive }) =>
                        cn(
                          "group flex items-center gap-3 rounded-md py-2 text-sm transition-colors",
                          collapsed ? "justify-center px-2" : "px-3",
                          isActive
                            ? "bg-midground/15 text-midground shadow-[inset_-1px_-1px_0_0_rgba(0,0,0,0.5),inset_1px_1px_0_0_rgba(255,255,255,0.16)]"
                            : "text-midground/70 hover:bg-midground/8 hover:text-midground",
                        )
                      }
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      {!collapsed && (
                        <span className="font-medium tracking-wide uppercase font-mono-ui text-[0.78rem]">
                          {label}
                        </span>
                      )}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        {!collapsed && (
          <div className="border-t border-border px-3 py-3">
            <ThemeSwitcher dropUp />
          </div>
        )}

        {/* Drag handle (desktop only) */}
        <div
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize sidebar"
          onMouseDown={onStartDrag}
          onTouchStart={onStartDrag}
          className={cn(resizeHandleClass("right", dragging), "hidden md:block")}
        />
      </aside>
    </>
  );
}

function PageHeader({
  onOpenSidebar,
  themeLabel,
}: {
  onOpenSidebar: () => void;
  themeLabel: string;
}) {
  const status = useGatewayStatus(6000);
  return (
    <header className="flex items-center justify-between border-b border-border bg-background-base/60 px-4 py-2.5 backdrop-blur md:px-6">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onOpenSidebar}
          className="rounded-md p-1.5 text-midground/70 hover:bg-midground/10 hover:text-midground md:hidden"
          aria-label="Open sidebar"
        >
          <Menu className="h-4 w-4" />
        </button>
        <Typography
          variant="sm"
          compressed
          className="text-midground/70 uppercase"
        >
          CVC · Cognitive Version Control
        </Typography>
      </div>
      <div className="flex items-center gap-2">
        <StatusDot
          state={status.proxy}
          label="Proxy"
          detail={`Gateway ${status.proxy}`}
        />
        <StatusDot
          state={status.agent}
          label="Agent"
          detail={status.agentCount != null ? `${status.agentCount} agents` : undefined}
        />
        <StatusDot
          state={status.mcp}
          label="MCP"
          detail={status.mcpToolCount != null ? `${status.mcpToolCount} tools` : undefined}
        />
        <StatusDot state={status.sdk} label="SDK" detail="Hive Mind SDK" />
        <span className="hidden font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/55 md:inline">
          · {themeLabel}
        </span>
      </div>
    </header>
  );
}

function Footer() {
  const [now, setNow] = useState(new Date());
  const { status: wsStatus } = useDashboardWS();
  const connected = wsStatus === "open";
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const wsColor = connected ? "bg-emerald-400" : "bg-red-400";
  return (
    <footer className="flex items-center justify-between border-t border-border bg-background-base/60 px-4 py-1.5 font-mono-ui text-[0.62rem] uppercase tracking-[0.16em] text-midground/55 md:px-6">
      <div className="flex items-center gap-2">
        <span className={cn("h-1.5 w-1.5 rounded-full", wsColor)} />
        <span>WS {connected ? "live" : "offline"}</span>
      </div>
      <span>{now.toLocaleTimeString()}</span>
    </footer>
  );
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { theme } = useTheme();
  const sidebarResize = useResizable({
    storageKey: "cvc.ui.sidebar",
    defaultWidth: 220,
    minWidth: 196,
    maxWidth: 360,
    edge: "right",
    collapsedWidth: 64,
    collapseSlack: 32,
  });

  useEffect(() => {
    function onResize() {
      if (window.innerWidth >= 768) setSidebarOpen(false);
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  return (
    <div className="relative isolate flex h-full overflow-hidden">
      <Backdrop />
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        width={sidebarResize.effectiveWidth}
        collapsed={sidebarResize.collapsed}
        dragging={sidebarResize.dragging}
        onStartDrag={sidebarResize.startDrag}
      />
      <div className="relative flex min-w-0 flex-1 flex-col">
        <PageHeader
          onOpenSidebar={() => setSidebarOpen(true)}
          themeLabel={theme.label}
        />
        <main className="relative min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8 md:py-8">
          <Routes>
            <Route path="/" element={<Navigate to="/overview" replace />} />
            <Route path="/overview" element={<OverviewPage />} />
            <Route path="/home" element={<HomePage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/operations" element={<OperationsPage />} />
            <Route path="/timeline" element={<TimelinePage />} />
            <Route path="/hive" element={<HiveMindPage />} />
            <Route path="/agents" element={<AgentsPage />} />
            <Route path="/swarm" element={<SwarmPage />} />
            <Route path="/mcp" element={<MCPPage />} />
            <Route path="/proxy" element={<ProxyPage />} />
            <Route path="/sdk" element={<SDKPage />} />
            <Route path="/memory" element={<MemoryPage />} />
            <Route path="/branches" element={<BranchesPage />} />
            <Route path="/commits" element={<CommitsPage />} />
            <Route path="/sessions" element={<SessionsPage />} />
            <Route path="/models" element={<ModelsPage />} />
            <Route path="/connections" element={<ConnectionsPage />} />
            <Route path="/providers" element={<ProvidersPage />} />
            <Route path="/loop" element={<LoopPage />} />
            <Route path="/trajectory" element={<TrajectoryPage />} />
            <Route path="/team" element={<TeamPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/overview" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </div>
  );
}
