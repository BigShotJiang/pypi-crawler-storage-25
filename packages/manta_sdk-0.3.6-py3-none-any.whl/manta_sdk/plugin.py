"""
MantaPlugin — programmatic pytest plugin for result collection.

Registered by cli.py at runtime (NOT as a pytest11 entry point).
Hooks into pytest_runtest_logreport to build TestCaseResult objects
using report.duration (measured by pytest after the test body exits).
"""

from __future__ import annotations

from uuid import UUID

import pytest

from manta_sdk.models import RunResult, RunStatus, TestCaseResult


class MantaPlugin:
    """
    Pytest plugin that collects per-test results and builds a RunResult.

    Usage::

        plugin = MantaPlugin(run_id=UUID(job_id))
        pytest.main([str(tests_dir), ...], plugins=[plugin])
        result = plugin.build_result()
    """

    def __init__(self, run_id: UUID) -> None:
        self.run_id = run_id
        self._results: list[TestCaseResult] = []

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_logreport(self, report: pytest.TestReport) -> None:  # type: ignore[override]
        yield
        # Only capture the "call" phase — setup/teardown failures are separate
        if report.when != "call":
            return

        if report.passed:
            status = RunStatus.PASSED
            error_message = None
        elif report.failed:
            status = RunStatus.FAILED
            error_message = str(report.longrepr) if report.longrepr else None
        else:  # skipped
            status = RunStatus.ERROR
            error_message = str(report.longrepr) if report.longrepr else "skipped"

        # report.duration is measured by pytest after the test body exits — use it
        # directly instead of manual perf_counter which fires before setup completes.
        duration_ms = int(report.duration * 1000)

        stdout = report.capstdout or ""

        self._results.append(
            TestCaseResult(
                name=report.nodeid,
                status=status,
                duration_ms=duration_ms,
                error_message=error_message,
                stdout=stdout,
            )
        )

    def build_result(self) -> RunResult:
        """Aggregate collected test reports into a RunResult."""
        passed = sum(1 for r in self._results if r.status == RunStatus.PASSED)
        failed = sum(1 for r in self._results if r.status == RunStatus.FAILED)
        errors = sum(1 for r in self._results if r.status == RunStatus.ERROR)
        total_ms = sum(r.duration_ms for r in self._results)

        if failed > 0 or errors > 0:
            overall = RunStatus.FAILED
        elif passed > 0:
            overall = RunStatus.PASSED
        else:
            overall = RunStatus.ERROR  # no tests ran at all

        return RunResult(
            run_id=self.run_id,
            status=overall,
            duration_ms=total_ms,
            total_tests=len(self._results),
            passed=passed,
            failed=failed,
            errors=errors,
            test_cases=list(self._results),
        )
