"""
BaseRunner — the abstract base class all custom Manta runners must implement.

Extend this class to plug a custom test framework into the Manta execution
engine. The engine calls lifecycle hooks in the following order:

  setup(ctx) → execute(ctx) → teardown(ctx, result)

All hooks are async. Runners that don't need setup/teardown can skip them.
"""

from __future__ import annotations

import abc

import structlog

from manta_sdk.models import RunContext, RunResult, RunStatus

logger = structlog.get_logger(__name__)


class BaseRunner(abc.ABC):
    """
    Abstract base class for Manta test runners.

    Subclass this to implement custom test execution logic.
    Only `execute` is required; `setup` and `teardown` are optional.

    Example:
        class PytestRunner(BaseRunner):
            async def execute(self, ctx: RunContext) -> RunResult:
                # invoke pytest programmatically
                ...
    """

    async def setup(self, ctx: RunContext) -> None:
        """
        Optional pre-execution hook.
        Called once before execute(). Use for environment preparation,
        dependency checks, or warming up connections.
        """

    @abc.abstractmethod
    async def execute(self, ctx: RunContext) -> RunResult:
        """
        Run the tests described in ctx and return the aggregated result.

        This is the only method implementations are required to provide.
        Must be non-blocking; long-running work should use asyncio.

        Args:
            ctx: Execution context provided by the Manta engine.

        Returns:
            RunResult with status, counts, and per-test-case details.
        """

    async def teardown(self, ctx: RunContext, result: RunResult) -> None:
        """
        Optional post-execution hook.
        Called after execute() regardless of the run outcome.
        Use for cleanup, log flushing, or report upload.
        """

    async def run(self, ctx: RunContext) -> RunResult:
        """
        Orchestrates the full lifecycle: setup → execute → teardown.
        Called by the Manta execution engine. Do not override.
        """
        log = logger.bind(run_id=str(ctx.run_id), team_id=ctx.team_id)
        log.info("runner.start")

        await self.setup(ctx)
        try:
            result = await self.execute(ctx)
        except Exception as exc:
            log.exception("runner.execute_error", error=str(exc))
            result = RunResult(run_id=ctx.run_id, status=RunStatus.ERROR, exit_code=1)
        finally:
            await self.teardown(ctx, result)  # type: ignore[possibly-undefined]

        # Emit per-test-case log lines so `docker logs` shows the full picture.
        for tc in result.test_cases:
            log.info(
                "runner.test_case",
                name=tc.name,
                status=tc.status,
                duration_ms=tc.duration_ms,
                stdout=tc.stdout[:500] if tc.stdout else "",
                error=tc.error_message,
            )

        # Summary line: mirrors a pytest-style report
        log.info(
            "runner.complete",
            status=result.status,
            duration_ms=result.duration_ms,
            total=result.total_tests,
            passed=result.passed,
            failed=result.failed,
            errors=result.errors,
        )
        return result
