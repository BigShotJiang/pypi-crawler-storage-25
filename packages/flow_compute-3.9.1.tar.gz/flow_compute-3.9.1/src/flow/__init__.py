"""Flow SDK - GPU compute made simple.

This module exposes a small, stable facade and lazily imports heavier
submodules on first attribute access to keep cold import time low.
"""

from __future__ import annotations

from importlib import import_module
from typing import Any

# Version (single source of truth)
from flow._version import __version__

VERSION = __version__

# Provider-agnostic constants
DEFAULT_REGION = "us-central5-a"  # Default region (US B200)
DEFAULT_PROVISION_MINUTES = 20  # Typical provision time for GPU instances
# Default estimated duration shown in CLI progress for code uploads.
# Keep this central so UI estimates can be tuned in one place.
# Note: expressed in minutes; 0.333… min = 20 seconds.
DEFAULT_UPLOAD_ESTIMATED_MINUTES = 20 / 60
# Estimated time shown for instance allocation steps
DEFAULT_ALLOCATION_ESTIMATED_SECONDS = 120

_EXPORTS: dict[str, tuple[str, str]] = {
    # Main API
    "Flow": ("flow.sdk.client", "Flow"),
    "FlowApp": ("flow.sdk.decorators", "FlowApp"),
    # Models
    "TaskConfig": ("flow.sdk.models", "TaskConfig"),
    "TaskSpec": ("flow.sdk.models", "TaskSpec"),
    "Task": ("flow.sdk.models", "Task"),
    "Resources": ("flow.sdk.models", "Resources"),
    "RunParams": ("flow.sdk.models", "RunParams"),
    "Volume": ("flow.sdk.models", "Volume"),
    "VolumeSpec": ("flow.sdk.models", "VolumeSpec"),
    "TaskStatus": ("flow.sdk.models", "TaskStatus"),
    "InstanceType": ("flow.sdk.models", "InstanceType"),
    "User": ("flow.sdk.models", "User"),
    "Retries": ("flow.sdk.models", "Retries"),
    # Image builder
    "Image": ("flow.sdk.image", "Image"),
    # Decorators
    "decorators": ("flow.sdk", "decorators"),
    # Class lifecycle decorators
    "enter": ("flow.sdk.cls", "enter"),
    "exit": ("flow.sdk.cls", "exit"),
    "method": ("flow.sdk.cls", "method"),
    "build": ("flow.sdk.cls", "build"),
    "parameter": ("flow.sdk.cls", "parameter"),
    # Constraints
    "Constraints": ("flow.domain.constraints", "Constraints"),
    # Schedule types
    "Cron": ("flow.sdk.schedule", "Cron"),
    "Period": ("flow.sdk.schedule", "Period"),
    # Serverless decorators
    "concurrent": ("flow.sdk.decorators", "concurrent"),
    "batched": ("flow.sdk.decorators", "batched"),
    "web_endpoint": ("flow.sdk.decorators", "web_endpoint"),
    # Secrets
    "Secret": ("flow.sdk.secrets", "Secret"),
    # Errors
    "FlowError": ("flow.errors", "FlowError"),
    "AuthenticationError": ("flow.errors", "AuthenticationError"),
    "ResourceNotFoundError": ("flow.errors", "ResourceNotFoundError"),
    "TaskNotFoundError": ("flow.errors", "TaskNotFoundError"),
    "ValidationError": ("flow.errors", "ValidationError"),
    "APIError": ("flow.errors", "APIError"),
    "ValidationAPIError": ("flow.errors", "ValidationAPIError"),
    "InsufficientBidPriceError": ("flow.errors", "InsufficientBidPriceError"),
    "NetworkError": ("flow.errors", "NetworkError"),
    "FlowTimeoutError": ("flow.errors", "FlowTimeoutError"),
    "TimeoutError": ("flow.errors", "TimeoutError"),
    "ProviderError": ("flow.errors", "ProviderError"),
    "ConfigParserError": ("flow.errors", "ConfigParserError"),
    "ResourceNotAvailableError": ("flow.errors", "ResourceNotAvailableError"),
    "QuotaExceededError": ("flow.errors", "QuotaExceededError"),
    "VolumeError": ("flow.errors", "VolumeError"),
    "TaskExecutionError": ("flow.errors", "TaskExecutionError"),
    "RemoteExecutionError": ("flow.errors", "RemoteExecutionError"),
    "FlowOperationError": ("flow.errors", "FlowOperationError"),
    "InstanceNotReadyError": ("flow.errors", "InstanceNotReadyError"),
    "NameConflictError": ("flow.errors", "NameConflictError"),
}


def __getattr__(name: str) -> Any:
    target = _EXPORTS.get(name)
    if not target:
        raise AttributeError(name)
    module_name, attr = target
    module = import_module(module_name)
    value = getattr(module, attr)
    globals()[name] = value  # cache for future accesses
    return value


def __dir__() -> list[str]:
    return sorted(list(_EXPORTS.keys()) + [k for k in globals() if not k.startswith("_")])


# Convenience functions
def run(task_or_command, **kwargs):
    """Submit a task using a default Flow client.

    Canonical one-shot entry point. Creates a ``Flow()`` client internally; for
    multiple operations prefer ``with flow.Flow() as client: ...``.

    The primary vocabulary for the command-string shortcut is ``gpu=`` (e.g.
    ``gpu="a100"`` or ``gpu="8xh100"``). ``instance_type=`` is accepted as a
    legacy alias and maps directly to ``TaskConfig.instance_type``. When both
    are given, ``instance_type`` wins (explicit override).

    Args:
        task_or_command: TaskConfig, path to YAML file, or command string.
        **kwargs: When ``task_or_command`` is a command string:

            - ``gpu``: GPU selector resolved via the provider catalog
              (e.g. ``"a100"``, ``"a100:4"``, ``"gpu:40gb"``).
            - ``instance_type``: Explicit instance type (legacy alias; bypasses
              selection).
            - ``image``: Docker image to use.
            - ``wait``: Whether to block until the task is running.
            - ``mounts``: Data sources to mount.
            - Any other ``TaskConfig`` field.

    Returns:
        Task: The submitted task handle.

    Examples:
        >>> import flow
        >>> # Command string with GPU selector (preferred)
        >>> task = flow.run("python train.py", gpu="a100")
        >>>
        >>> # With Docker image
        >>> task = flow.run("python train.py",
        ...                 gpu="a100",
        ...                 image="pytorch/pytorch:2.2.2-cuda12.1-cudnn8")
        >>>
        >>> # Structured TaskConfig
        >>> cfg = flow.TaskConfig(name="training", instance_type="8xh100",
        ...                       command="python train.py")
        >>> task = flow.run(cfg)
    """
    from flow.sdk.client import Flow
    from flow.sdk.models import TaskConfig

    # Extract Flow.run() specific args (they are not TaskConfig fields)
    wait = kwargs.pop("wait", False)
    mounts = kwargs.pop("mounts", None)

    # Disambiguate by suffix alone: .yaml/.yml means YAML file; anything else
    # is treated as a shell command regardless of filesystem state.
    if isinstance(task_or_command, str) and not task_or_command.endswith((".yaml", ".yml")):
        with Flow() as client:
            config = _build_command_task_config(TaskConfig, client, task_or_command, kwargs)
            return client.run(config, wait=wait, mounts=mounts)

    # Otherwise, pass through as-is (TaskConfig or YAML path).
    with Flow() as client:
        return client.run(task_or_command, wait=wait, mounts=mounts)


def _build_command_task_config(task_config_cls, client, command, kwargs):
    """Resolve `gpu=` selectors and construct a TaskConfig for a command string.

    ``gpu`` is the primary vocabulary at the ``flow.run()`` surface; it is
    resolved to a concrete ``instance_type`` via the provider's GPU selection
    service. An explicit ``instance_type=`` always wins, matching the
    "explicit beats inferred" rule.
    """
    kwargs = dict(kwargs)  # avoid mutating caller's mapping
    gpu = kwargs.pop("gpu", None)
    instance_type = kwargs.get("instance_type")

    if instance_type is None and gpu is not None:
        from flow.domain.resources.gpu_selection import GPUSelectionService

        kwargs["instance_type"] = GPUSelectionService(client.provider).select_instance_type(gpu)

    return task_config_cls(command=command, **kwargs)


__all__ = sorted(  # noqa: PLE0605
    [
        *_EXPORTS.keys(),
        "run",
        "DEFAULT_REGION",
        "DEFAULT_PROVISION_MINUTES",
        "DEFAULT_UPLOAD_ESTIMATED_MINUTES",
        "DEFAULT_ALLOCATION_ESTIMATED_SECONDS",
        "__version__",
    ]
)
