"""Pricing visibility command.

Summary-first views for:
- Market stats with 7d range and trend
- Billing price estimates (P50/P90/P95 heuristics)
- Runtime estimates at various limit prices (from 7d history)

Details are opt-in via flags; default output stays concise and actionable.
"""

import dataclasses
import json
import re
import shutil
from collections import defaultdict
from collections.abc import Callable
from contextlib import nullcontext
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo

import click

from flow.cli.commands import pricing_stats
from flow.cli.commands._pricing_data import (
    _api_get_json,
    _fetch_instance_type_map,
    _fetch_price_history,
    _resolve_api_context,
    parse_gpu_spec,
)
from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.formatters.shared_gpu import GPUFormatter
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.cli.ui.presentation.table_styles import (
    add_left_aligned_column,
    add_right_aligned_column,
    create_flow_table,
    wrap_table_in_panel,
)
from flow.cli.utils.error_handling import cli_error_guard, render_auth_required_message
from flow.cli.utils.json_output import error_json, print_json
from flow.cli.utils.telemetry import Telemetry
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.domain.pricing.insights import (
    PriceTrend,
    aggregate_market_by_size,
    compute_market_summary,
    compute_price_trend,
    derive_recommendations_by_size,
    estimate_uptime,
    plan_by_budget,
    plan_by_runtime,
    suggest_limit_prices,
    week_over_week_compare,
)
from flow.errors import AuthenticationError
from flow.utils.links import DocsLinks, WebLinks

# GPUs to display by default when no --gpu filter is provided (in priority order)
PREFERRED_GPUS = ("b200", "h200", "h100", "a100")

# Week boundaries use Pacific Time (PDT/PST) for display and computation.
_WEEK_TZ = ZoneInfo("America/Los_Angeles")

# Below this terminal width the Market Stats panel drops the "7d Range" column
# so Region and price cells never wrap. 96 cols fits the full layout once the
# Rich panel border (4 cols) and per-column padding overhead are accounted for.
_WIDE_STATS_MIN_COLS = 96


def _pricing_flags(f: Callable[..., Any]) -> Callable[..., Any]:
    """Apply the shared pricing option set to a Click command or group.

    Both ``flow pricing`` (the group) and its default command need the same
    option surface so that ``ctx.forward(default_cmd)`` can pass through the
    parsed flags transparently. Defining the options once here is the single
    source of truth.
    """
    f = click.option("--region", help="Filter market by region (e.g., us-central1-b)")(f)
    f = click.option("--gpu", help="Filter to a GPU (e.g., h100, 1xb200, a100x4)")(f)
    f = click.option(
        "--gpu-count", type=int, help="Target GPU count for per-instance limit prices"
    )(f)
    f = click.option(
        "--list", "show_list", is_flag=True, help="List raw market instances (verbose)"
    )(f)
    f = click.option("--explain", is_flag=True, help="Explain recommendations (verbose)")(f)
    f = click.option("--detail", is_flag=True, help="Show all price tiers per GPU config")(f)
    f = click.option("--json", "as_json", is_flag=True, help="Output JSON for automation")(f)
    return f


class PricingCommand(BaseCommand):
    @property
    def name(self) -> str:
        return "pricing"

    @property
    def help(self) -> str:
        return "Show market prices and recommendations"

    def _build_default_command(self) -> click.Command:
        """Build the default ``flow pricing`` market-summary command.

        This is the command that runs when ``flow pricing`` is invoked without
        a subcommand. The group defined in :meth:`get_command` forwards to it
        via ``ctx.forward`` when ``ctx.invoked_subcommand is None``.
        """

        @click.command(name=self.name, help=self.help)
        @_pricing_flags
        @cli_error_guard(self)
        def pricing(
            region: str | None = None,
            gpu: str | None = None,
            gpu_count: int | None = None,
            show_list: bool = False,
            explain: bool = False,
            detail: bool = False,
            as_json: bool = False,
        ):
            """Display market summary (default)."""
            accent = theme_manager.get_color("accent")
            muted = theme_manager.get_color("muted")
            if not as_json:
                try:
                    console.print(f"[bold {accent}]Flow Pricing[/bold {accent}]")
                except Exception:  # noqa: BLE001
                    pass

            # Telemetry (best-effort)
            try:
                Telemetry().log_event(
                    "pricing_view_shown",
                    {
                        "view": "market",
                        "gpu": (gpu or ""),
                        "gpus": (gpu_count or 0),
                        "region": (region or ""),
                    },
                )
            except Exception:  # noqa: BLE001
                pass

            if gpu:
                gpu, parsed_count = parse_gpu_spec(gpu)
                if parsed_count is not None and gpu_count is None:
                    gpu_count = parsed_count

            # ---- Rendering helpers ----

            def _trend_arrow(this_wk: float, last_wk: float, threshold: float = 10.0) -> str:
                """Arrow + percentage comparing this week avg to last week avg."""
                if last_wk <= 0:
                    return "[dim]\u00b7[/dim]"
                pct_change = (this_wk - last_wk) / last_wk * 100
                pct_str = f"{abs(pct_change):.0f}%"
                if pct_change < -threshold:
                    return f"[green]\u2193 {pct_str}[/green]"
                if pct_change > threshold:
                    return f"[yellow]\u2191 {pct_str}[/yellow]"
                return f"[dim]\u2192 {pct_str}[/dim]"

            def _render_stats_panel(
                rows: list[dict[str, Any]],
                trends: dict[tuple[str, str], PriceTrend] | None = None,
                wk_avgs: dict[tuple[str, str, int], tuple[float, float]] | None = None,
            ) -> None:
                has_trends = trends and any(
                    trends.get((r.get("gpu", ""), r.get("region", ""), r.get("gpu_count", 8)))
                    for r in rows
                )

                # Drop the widest, most-redundant column ("7d Range") on narrow
                # terminals so Region and price cells never wrap. The range is
                # derivable from trend + This/Last Wk; users who want it can
                # widen their terminal or query the JSON payload.
                try:
                    terminal_cols = shutil.get_terminal_size((80, 24)).columns
                except Exception:  # noqa: BLE001
                    terminal_cols = 80
                show_range = bool(has_trends) and terminal_cols >= _WIDE_STATS_MIN_COLS

                stats_table = create_flow_table(title=None, show_borders=False, padding=1)
                add_left_aligned_column(stats_table, "GPU", style=accent, no_wrap=True)
                add_left_aligned_column(stats_table, "Region", style=muted, no_wrap=True)
                add_right_aligned_column(stats_table, "Current", no_wrap=True)
                if has_trends:
                    add_right_aligned_column(stats_table, "1d Avg", no_wrap=True)
                    add_right_aligned_column(stats_table, "This Wk", no_wrap=True)
                    add_right_aligned_column(stats_table, "Last Wk", no_wrap=True)
                    if show_range:
                        add_right_aligned_column(stats_table, "7d Range", no_wrap=True)
                    add_right_aligned_column(stats_table, "Trend", no_wrap=True)

                for r in rows:
                    row_gc = r.get("gpu_count", 8)
                    gpu_label = GPUFormatter.format_count_lowercase(
                        r.get("gpu", ""), int(row_gc)
                    )
                    row_cells = [
                        gpu_label,
                        r.get("region", ""),
                        r.get("current_fmt", "-"),
                    ]
                    if has_trends:
                        trend_key = (r.get("gpu", ""), r.get("region", ""), row_gc)
                        trend = (trends or {}).get(trend_key)
                        wk = (wk_avgs or {}).get(trend_key)
                        if trend:
                            avg_1d = f"${trend.mean_1d:.2f}"
                            this_wk = f"${wk[0]:.2f}" if wk and wk[0] > 0 else "-"
                            last_wk = f"${wk[1]:.2f}" if wk and wk[1] > 0 else "-"
                            tw = wk[0] if wk else 0.0
                            lw = wk[1] if wk else 0.0
                            extras = [avg_1d, this_wk, last_wk]
                            if show_range:
                                extras.append(f"${trend.min_7d:.2f}-${trend.max_7d:.2f}")
                            extras.append(_trend_arrow(tw, lw))
                            row_cells.extend(extras)
                        else:
                            placeholders = ["-", "-", "-", "-"]
                            if show_range:
                                placeholders.append("-")
                            row_cells.extend(placeholders)

                    stats_table.add_row(*row_cells)

                title_suffix = f" \u2022 {region}" if region else ""
                wrap_table_in_panel(stats_table, f"Market Stats{title_suffix}", console)

            def _render_uptime_panel_detail(
                estimates: list[Any],
                target_gpu_count: int,
                gpu_label: str,
            ) -> None:
                """Render full price-tier breakdown for a single GPU config (--detail mode)."""
                table = create_flow_table(title=None, show_borders=False, padding=1)
                add_left_aligned_column(table, "Limit Price", style=accent, no_wrap=True)
                add_right_aligned_column(table, "Win Rate", no_wrap=True)
                add_right_aligned_column(table, "24h Runtime", no_wrap=True)
                add_right_aligned_column(table, "48h Runtime", no_wrap=True)
                add_right_aligned_column(table, "72h Runtime", no_wrap=True)
                add_right_aligned_column(table, "48h Cost", no_wrap=True)

                for est in estimates:
                    table.add_row(
                        f"${est.limit_price:.2f}/GPU",
                        f"~{est.uptime_pct:.0f}%",
                        f"~{est.runtime_24h:.0f}h",
                        f"~{est.runtime_48h:.0f}h",
                        f"~{est.runtime_72h:.0f}h",
                        f"~${est.cost_48h:,.0f}",
                    )

                gpu_suffix = f" \u2022 {gpu_label} \u2022 {target_gpu_count} GPUs"
                wrap_table_in_panel(
                    table,
                    f"Price Eligibility Estimate (7d history{gpu_suffix})",
                    console,
                )

            def _render_uptime_consolidated(
                all_estimates: dict[tuple[str, str, int], list[Any]],
            ) -> None:
                """Render bid guide showing ~25/50/75% tiers per GPU config."""
                table = create_flow_table(title=None, show_borders=False, padding=1)
                add_left_aligned_column(table, "GPU", style=accent, no_wrap=True)
                add_right_aligned_column(table, "Limit/GPU", no_wrap=True)
                add_right_aligned_column(table, "Win Rate", no_wrap=True)
                add_right_aligned_column(table, "~Run/day", no_wrap=True)
                add_right_aligned_column(table, "~Cost/day", no_wrap=True)

                first_group = True
                for (gpu_key, _rgn, gc), ests in all_estimates.items():
                    if not ests:
                        continue
                    if not first_group:
                        table.add_row()
                    first_group = False
                    # Last tier (~75%) is the max-availability recommendation
                    rec_idx = len(ests) - 1
                    for i, est in enumerate(ests):
                        gpu_cell = (
                            GPUFormatter.format_count_lowercase(gpu_key, gc) if i == 0 else ""
                        )
                        style = f"bold {accent}" if i == rec_idx else ""
                        table.add_row(
                            gpu_cell,
                            f"${est.limit_price:.2f}",
                            f"~{est.uptime_pct:.0f}%",
                            f"~{est.runtime_24h:.0f}h",
                            f"~${est.cost_24h:,.0f}",
                            style=style,
                        )

                title_suffix = f" \u2022 {region}" if region else ""
                wrap_table_in_panel(
                    table,
                    f"Bid Guide (7d history{title_suffix})",
                    console,
                )

            # ---- Fetch current market data ----
            def _try_authenticated() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
                import flow.sdk.factory as sdk_factory

                client = sdk_factory.create_client(auto_init=True)
                req: dict[str, Any] = {}
                if region:
                    req["region"] = region
                instances = client.find_instances(req, limit=250)
                raw_rows: list[dict[str, Any]] = []
                for inst in instances:
                    gc = inst.gpu_count or 1
                    per_gpu = (
                        inst.price_per_hour / gc
                        if isinstance(inst.price_per_hour, int | float) and gc > 0
                        else inst.price_per_hour
                    )
                    raw_rows.append(
                        {
                            "region": inst.region,
                            "gpu_type": (inst.gpu_type or "")
                            or extract_gpu_info(inst.instance_type)[0],
                            "gpu_count": gc,
                            "price_per_hour": per_gpu,
                            "instance_type": inst.instance_type,
                            "available_quantity": inst.available_quantity,
                        }
                    )
                return raw_rows, raw_rows

            def _try_public() -> list[dict[str, Any]]:
                """Fetch market data via public endpoints using stdlib HTTP."""
                nonlocal cached_fid_map, cached_api_ctx
                from flow.cli.utils.parsing import parse_price as _parse_price

                api_base, api_key, project = _resolve_api_context()
                cached_api_ctx = (api_base, api_key)

                fid_map = _fetch_instance_type_map(api_base, api_key)
                cached_fid_map = fid_map
                id_to_name = {fid: info[0] for fid, info in fid_map.items()}
                id_to_gpus = {fid: info[1] for fid, info in fid_map.items()}
                id_to_gpu_type = {fid: info[2] for fid, info in fid_map.items()}

                params: dict[str, Any] = {"limit": 100}
                if region:
                    params["region"] = region
                if project:
                    params["project"] = project
                avail = _api_get_json(api_base, api_key, "/v2/spot/availability", params)
                if not isinstance(avail, list):
                    avail = []

                rows: list[dict[str, Any]] = []

                def _parse_gpus_from_name(name: str) -> int:
                    m = re.search(r"(\d+)x\b", str(name))
                    if m:
                        val = int(m.group(1))
                        return val if val > 0 else 0
                    return 0

                for a in avail:
                    try:
                        rgn = str(a.get("region", "") or "")
                        it_id = str(
                            a.get("instance_type")
                            or a.get("instanceType")
                            or a.get("instanceTypeId")
                            or ""
                        )
                        price_str = (
                            a.get("last_instance_price")
                            or a.get("current_price")
                            or a.get("price_per_hour")
                            or a.get("price")
                            or None
                        )
                        price = 0.0
                        if isinstance(price_str, int | float):
                            price = float(price_str)
                        elif isinstance(price_str, str):
                            price = _parse_price(price_str)

                        gpus = int(
                            a.get("gpu_count")
                            or a.get("gpus")
                            or id_to_gpus.get(it_id, 0)
                            or _parse_gpus_from_name(id_to_name.get(it_id, ""))
                            or _parse_gpus_from_name(it_id)
                            or 0
                        )
                        avail_count = None
                        for key in (
                            "available_quantity",
                            "available_count",
                            "capacity",
                            "quantity",
                        ):
                            v = a.get(key)
                            if isinstance(v, int | float):
                                avail_count = int(v)
                                break

                        per_gpu_price = (price / gpus) if (gpus and price) else 0.0

                        rows.append(
                            {
                                "region": rgn,
                                "gpu_type": id_to_gpu_type.get(it_id, extract_gpu_info(it_id)[0]),
                                "gpu_count": gpus or None,
                                "price_per_hour": per_gpu_price or price,
                                "instance_type": id_to_name.get(it_id, it_id),
                                "available_quantity": avail_count,
                            }
                        )
                    except Exception:  # noqa: BLE001
                        continue

                return rows

            raw_rows: list[dict[str, Any]] = []
            cached_fid_map: dict[str, tuple[str, int, str]] | None = None
            cached_api_ctx: tuple[str, str | None] | None = None
            auth_error: Exception | None = None
            public_error: Exception | None = None

            progress = (
                nullcontext()
                if as_json
                else AnimatedEllipsisProgress(
                    console, "Fetching market prices", transient=True, start_immediately=True
                )
            )
            with progress:
                try:
                    raw_rows, _ = _try_authenticated()
                except Exception as e:  # noqa: BLE001
                    auth_error = e
                    _provider = "mithril"
                    try:
                        from flow.application.config.config import Config as _Cfg

                        _provider = _Cfg.from_env(require_auth=False).provider
                    except Exception:  # noqa: BLE001
                        pass
                    if _provider == "mithril":
                        try:
                            raw_rows = _try_public()
                        except Exception as e2:  # pragma: no cover  # noqa: BLE001
                            public_error = e2

            # Resolve API base + key for supplemental history (SDK auth does not populate
            # cached_api_ctx; public path does). Needed so 7d trends load when token is in
            # ~/.flow/config.yaml but not in the environment.
            if raw_rows and cached_api_ctx is None:
                cached_api_ctx = _resolve_api_context()[:2]

            # If we have no live data, surface a clear message and exit early
            if not raw_rows:
                is_auth_error = isinstance(auth_error, AuthenticationError) or isinstance(
                    public_error, AuthenticationError
                )

                if is_auth_error:
                    render_auth_required_message(console, output_json=as_json)
                    return

                if as_json:
                    print_json(
                        error_json(
                            "Unable to fetch live pricing data",
                            hint=f"See live price charts: {WebLinks.price_chart()}",
                        )
                    )
                else:
                    console.print("")
                    console.print("[dim]Unable to fetch live pricing data.[/dim]")
                    console.print("")
                    console.print(f"See live price charts: {WebLinks.price_chart()}\n")
                return

            # Optional raw list view
            if show_list:
                gpu_req = (gpu or "").lower().strip()
                display_rows = raw_rows
                if gpu_req:
                    display_rows = [
                        r for r in raw_rows if (r.get("gpu_type") or "").lower() == gpu_req
                    ]

                table = create_flow_table(title=None, show_borders=False, padding=1)
                add_left_aligned_column(table, "Region", style=muted)
                add_left_aligned_column(table, "GPU", style=accent)
                add_right_aligned_column(table, "GPUs", style=muted)
                add_right_aligned_column(table, "Price/GPU")
                add_right_aligned_column(table, "Price/inst")
                add_right_aligned_column(table, "Avail")

                display_rows.sort(
                    key=lambda x: (x.get("region", ""), float(x.get("price_per_hour") or 0))
                )
                for r in display_rows:
                    p = float(r.get("price_per_hour") or 0)
                    g = r.get("gpu_count") or 0
                    per_inst = (p * g) if (p and g) else 0.0
                    table.add_row(
                        r.get("region", ""),
                        r.get("gpu_type", ""),
                        str(g or "-"),
                        f"${p:.2f}/hr" if p else "-",
                        f"${per_inst:.2f}/hr" if per_inst else "-",
                        str(r.get("available_quantity") or "-"),
                    )
                wrap_table_in_panel(
                    table, f"Listings{' \u2022 ' + region if region else ''}", console
                )
                return

            # Build per-(gpu, region, gpu_count) current price map.
            # Each GPU count tier is a distinct market — separate rows in display.
            avail_size_map: dict[tuple[str, str], set[int]] = defaultdict(set)
            # Keyed by (gpu_type, region, gpu_count) → lowest per-GPU price
            current_by_config: dict[tuple[str, str, int], float] = {}
            for r in raw_rows:
                gk = str(r.get("gpu_type") or "").lower().strip()
                rgn = str(r.get("region") or "").strip()
                if not gk or not rgn:
                    continue
                gc_raw = r.get("gpu_count")
                if not isinstance(gc_raw, int | float) or int(gc_raw) <= 0:
                    continue
                gc_int = int(gc_raw)
                avail_size_map[(gk, rgn)].add(gc_int)
                p = float(r.get("price_per_hour") or 0)
                if p <= 0:
                    continue
                cfg_key = (gk, rgn, gc_int)
                existing = current_by_config.get(cfg_key)
                if existing is None or p < existing:
                    current_by_config[cfg_key] = p

            market_by_size = aggregate_market_by_size(raw_rows, target_gpu=None)
            recs_by_size = derive_recommendations_by_size(market_by_size)

            # GPUs to show: requested, else preferred if available, else first two
            gpu_req = (gpu or "").lower().strip()
            if gpu_req:
                gpu_keys = [gpu_req]
            else:
                preferred = [g for g in PREFERRED_GPUS if g in market_by_size]
                gpu_keys = preferred or sorted(market_by_size.keys())[:2]

            # Build one row per (gpu, region, gpu_count) — each config is its
            # own market with distinct per-GPU pricing dynamics.
            rows: list[dict[str, Any]] = []
            for gpu_key in gpu_keys:
                # Collect all (region, gpu_count) configs for this GPU
                configs: list[tuple[str, int, float]] = []
                for (gk, rgn, gc_int), price_val in current_by_config.items():
                    if gk != gpu_key:
                        continue
                    if region and rgn != region:
                        continue
                    if gpu_count and gc_int != gpu_count:
                        continue
                    configs.append((rgn, gc_int, price_val))
                configs.sort(key=lambda t: (t[0], t[1]))

                for rgn, gc_int, price_val in configs:
                    sizes_here = avail_size_map.get((gpu_key, rgn), set())
                    cap_med_by_count: dict[int, float] = {}
                    for gc in sizes_here:
                        sized = recs_by_size.get(gpu_key, {}).get(rgn, {}).get(gc)
                        med = sized.get("med") if sized else None
                        if isinstance(med, int | float):
                            cap_med_by_count[gc] = float(med)
                    rows.append(
                        {
                            "gpu": gpu_key,
                            "gpu_count": gc_int,
                            "region": rgn,
                            "current_fmt": f"${price_val:.2f}",
                            "cap_med_by_count": cap_med_by_count,
                            "avail_counts": sorted(sizes_here),
                        }
                    )

            # ---- Fetch price history (best-effort) ----
            # Keyed by (gpu_type, region, gpu_count) — one per config
            history_data: dict[tuple[str, str, int], dict[str, Any]] = {}
            trends: dict[tuple[str, str, int], PriceTrend] = {}
            uptime_estimates: dict[tuple[str, str, int], list[Any]] = {}

            # Collect regions shown in rows for targeted history fetch
            shown_regions = list({r.get("region", "") for r in rows if r.get("region")})

            try:
                api_base, api_key = cached_api_ctx or _resolve_api_context()[:2]
                if api_key:
                    fid_map = cached_fid_map or _fetch_instance_type_map(api_base, api_key)
                    history_data = _fetch_price_history(
                        api_base,
                        api_key,
                        fid_map,
                        gpu,
                        region,
                        target_regions=shown_regions or None,
                    )

                    for r in rows:
                        gpu_key = r.get("gpu", "")
                        rgn = r.get("region", "")
                        row_gc = r.get("gpu_count", 8)
                        hist_key = (gpu_key, rgn, row_gc)
                        hist = history_data.get(hist_key)
                        if not hist or hist_key in trends:
                            continue
                        spot_prices = hist["spot_prices"]
                        current_price = current_by_config.get(hist_key, 0.0)

                        hist_ts = hist.get("timestamps", [])
                        trends[hist_key] = compute_price_trend(spot_prices, hist_ts, current_price)

                        limit_tiers = suggest_limit_prices(
                            spot_prices,
                            targets=[25, 50, 75],
                            timestamps=hist_ts,
                            window_hours=168,
                        )
                        if limit_tiers:
                            uptime_estimates[hist_key] = estimate_uptime(
                                spot_prices,
                                limit_tiers,
                                gpu_count=row_gc,
                                timestamps=hist_ts,
                                window_hours=168,
                            )
            except Exception:  # noqa: BLE001
                pass  # History is supplemental; never block the command

            # JSON output
            if as_json:
                payload: dict[str, Any] = {
                    "context": {
                        "region_filter": region,
                        "gpu_filter": gpu,
                        "target_gpus": gpu_count,
                    },
                    "raw_listings": raw_rows,
                    "market_by_size": market_by_size,
                    "recommendations_by_size": recs_by_size,
                    "top_rows": rows,
                }

                # Serialize tuple-keyed dicts with "gpu:region" string keys
                def _cfg_key(d: dict[tuple[str, str, int], Any]) -> dict[str, Any]:
                    return {f"{g}:{r}:{gc}x": v for (g, r, gc), v in d.items()}

                if history_data:
                    payload["price_history"] = _cfg_key(history_data)
                if trends:
                    payload["trends"] = {
                        f"{g}:{r}:{gc}x": dataclasses.asdict(t) for (g, r, gc), t in trends.items()
                    }
                if uptime_estimates:
                    payload["uptime_estimates"] = {
                        f"{gk}:{rgn}:{gc}x": [
                            {
                                "limit_price": e.limit_price,
                                "uptime_pct": e.uptime_pct,
                                "runtime_24h": e.runtime_24h,
                                "runtime_48h": e.runtime_48h,
                                "runtime_72h": e.runtime_72h,
                                "cost_48h": e.cost_48h,
                            }
                            for e in ests
                        ]
                        for (gk, rgn, gc), ests in uptime_estimates.items()
                    }

                # Planning intelligence for Claude / programmatic consumers
                if history_data:
                    planning: dict[str, Any] = {}
                    for (gpu_key, rgn, gc), hist in history_data.items():
                        prices = hist["spot_prices"]
                        hist_ts = hist.get("timestamps", [])

                        summary = compute_market_summary(
                            prices,
                            timestamps=hist_ts,
                        )
                        entry: dict[str, Any] = {
                            "gpu": gpu_key,
                            "region": rgn,
                            "gpu_count": gc,
                            "market_summary": {
                                "mean_price": summary.mean_price,
                                "volatility_pct": summary.volatility_pct,
                                "confidence": summary.confidence,
                            },
                        }

                        budget_scenarios: list[dict[str, Any]] = []
                        for b in [250, 500, 1000, 2500]:
                            plan = plan_by_budget(
                                prices,
                                b,
                                gpu_count=gc,
                                window_hours=48,
                                timestamps=hist_ts,
                            )
                            if plan:
                                budget_scenarios.append(
                                    {
                                        "budget": b,
                                        "limit_price": plan.limit_price,
                                        "expected_runtime_hours": plan.expected_runtime_hours,
                                        "expected_cost": plan.expected_cost,
                                        "uptime_pct": plan.uptime_pct,
                                    }
                                )
                        entry["budget_scenarios"] = budget_scenarios

                        runtime_scenarios: list[dict[str, Any]] = []
                        for target in [24, 48, 72]:
                            plan = plan_by_runtime(
                                prices,
                                target,
                                gpu_count=gc,
                                window_hours=target,
                                timestamps=hist_ts,
                            )
                            if plan:
                                runtime_scenarios.append(
                                    {
                                        "target_hours": target,
                                        "window_hours": target,
                                        "limit_price": plan.limit_price,
                                        "expected_cost": plan.expected_cost,
                                        "uptime_pct": plan.uptime_pct,
                                        "achievable": plan.achievable,
                                    }
                                )
                        entry["runtime_scenarios"] = runtime_scenarios

                        planning[f"{gpu_key}:{rgn}:{gc}x"] = entry

                    if planning:
                        payload["planning"] = planning

                click.echo(json.dumps(payload, indent=2))
                return

            # Compute week-aligned duration-weighted averages via the insights
            # primitive. Monday 00:00 UTC boundary math, LOCF, and clipping all
            # live in :func:`week_over_week_compare` — one source of truth.
            week_avgs: dict[tuple[str, str, int], tuple[float, float]] = {}
            now_utc = datetime.now(tz=timezone.utc)
            for (gpu_key, rgn, gc), hist in history_data.items():
                wow = week_over_week_compare(
                    hist["spot_prices"],
                    hist.get("timestamps", []),
                    now_utc,
                    week_boundary_tz=_WEEK_TZ,
                )
                if wow.this_wk_overlap is None and wow.last_wk_overlap is None:
                    continue
                week_avgs[(gpu_key, rgn, gc)] = (
                    wow.this_wk_overlap or 0.0,
                    wow.last_wk_overlap or 0.0,
                )

            # ---- Render ----
            _render_stats_panel(rows, trends=trends or None, wk_avgs=week_avgs or None)
            tz_label = now_utc.astimezone(_WEEK_TZ).strftime("%Z")
            console.print(
                f"[dim]Per-GPU USD/hr. Weeks start Monday 00:00 {tz_label}."
                " Trend = this week vs last week"
                " ([green]\u2193[/green] lowering,"
                " [dim]\u2192[/dim] stable,"
                " [yellow]\u2191[/yellow] rising).[/dim]"
            )

            # Bid guide (if history available)
            if uptime_estimates:
                console.print("")
                if detail:
                    for (gpu_key, rgn, gc), ests in uptime_estimates.items():
                        gpu_label = GPUFormatter.format_count_lowercase(gpu_key, gc)
                        label = f"{gpu_label} \u2022 {rgn}" if rgn else gpu_label
                        _render_uptime_panel_detail(ests, gc, label)
                else:
                    _render_uptime_consolidated(uptime_estimates)
                console.print(
                    "[dim]Win Rate = % of 7d where spot < your limit."
                    " Cost includes all GPUs in the instance."
                    " Limit is per GPU \u2014 multiply by count for --limit flag.[/dim]"
                    + ("" if detail else " [dim]Use --detail for all tiers.[/dim]")
                )

            console.print("")
            console.print(f"[dim]Docs: {DocsLinks.spot_bids()}[/dim]")

            # Telemetry (best-effort)
            try:
                Telemetry().log_event(
                    "pricing_recommendation_shown",
                    {
                        "gpu": ",".join(gpu_keys),
                        "rows": len(rows),
                        "region_filter": bool(region),
                        "gpus": gpu_count or 0,
                        "has_history": bool(history_data),
                    },
                )
            except Exception:  # noqa: BLE001
                pass

            if explain:
                console.print(
                    "[dim]Bid guide tiers target ~25%/~50%/~75% uptime from 7d"
                    " duration-weighted percentiles. You pay the clearing price"
                    " (second-price auction), not your limit.[/dim]"
                )

            console.print("")

        return pricing

    def get_command(self) -> click.Command:
        """Return the ``flow pricing`` Click group.

        The group uses ``invoke_without_command=True`` so bare ``flow pricing``
        (with or without flags) still runs the default market-summary view via
        ``ctx.forward(default_cmd)``. Subcommands added to the group (e.g.
        Phase 2's ``flow pricing stats``) take precedence when supplied.
        """
        default_cmd = self._build_default_command()

        @click.group(
            name=self.name,
            help=self.help,
            invoke_without_command=True,
        )
        @_pricing_flags
        @click.pass_context
        def pricing_group(
            ctx: click.Context,
            region: str | None,
            gpu: str | None,
            gpu_count: int | None,
            show_list: bool,
            explain: bool,
            detail: bool,
            as_json: bool,
        ) -> None:
            """Flow pricing entry point (group wrapper)."""
            if ctx.invoked_subcommand is None:
                ctx.forward(default_cmd)

        pricing_group.add_command(pricing_stats.build_command(self), name="stats")
        return pricing_group


# Export command instance
command = PricingCommand()
