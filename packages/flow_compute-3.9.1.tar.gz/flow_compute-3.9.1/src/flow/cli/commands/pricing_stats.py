"""``flow pricing stats`` subcommand.

Per-market price statistics: week-over-week comparison, day-of-week and
hour-of-day seasonality, peak/slow days, and volatility trend. Uses the
duration-weighted primitives in :mod:`flow.domain.pricing.insights` so the
view stays numerically consistent with the default ``flow pricing`` view.

Invocation is keyed by ``(gpu, region, gpu_count)`` — each GPU count tier
is a distinct market. Fails closed (exit 1) when no history is found for
the requested market rather than rendering empty panels.
"""

import json
from datetime import datetime, timedelta, timezone, tzinfo
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import click
from rich.console import Console
from rich.panel import Panel

from flow.cli.commands._pricing_data import (
    _fetch_instance_type_map,
    _fetch_price_history,
    _resolve_api_context,
    parse_gpu_spec,
)
from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.table_styles import (
    add_left_aligned_column,
    add_right_aligned_column,
    create_flow_table,
    wrap_table_in_panel,
)
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.json_output import error_json, print_json
from flow.cli.utils.telemetry import Telemetry
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.pricing.insights import (
    DayStat,
    HourStat,
    PriceTrend,
    VolatilitySummary,
    WeekdayStat,
    WeekOverWeekResult,
    bucket_by_day,
    bucket_by_hour,
    bucket_by_weekday,
    compute_price_trend,
    volatility_summary,
    week_over_week_compare,
)

# Unicode block characters for sparkline/bar rendering (lightest to heaviest).
_BAR_BLOCKS: tuple[str, ...] = (
    "\u2581",
    "\u2582",
    "\u2583",
    "\u2584",
    "\u2585",
    "\u2586",
    "\u2587",
    "\u2588",
)

# Weekday/hour buckets with fewer than this many covered hours are rendered
# as "insufficient data" — avoids misleading single-sample means.
_MIN_HOURS_FOR_DISPLAY: float = 4.0

# Number of cheapest/most-expensive calendar days to surface in the Rich panel.
_PEAK_SLOW_K: int = 3

# Max character width of the horizontal weekday bar column.
_WEEKDAY_BAR_WIDTH: int = 15

# Above this CV%, day-of-week means are dominated by noise, so suppress the
# cheapest/peak labels on the weekday panel — the volatility row already
# carries the "don't trust seasonality" signal and competing labels mislead
# agents. 30% CV is the upper edge of "moderate" per compute_market_summary.
_LABEL_NOISE_CV_PCT: float = 30.0

# Ignore momentum deltas inside this deadband to avoid arrow flicker on noise.
_MOMENTUM_FLAT_PCT: float = 0.5

# Fractional block glyphs used by the horizontal bar (1/8 .. 7/8 of a cell).
_HBAR_FRACTIONAL: tuple[str, ...] = (
    "\u258f",  # 1/8
    "\u258e",  # 2/8
    "\u258d",  # 3/8
    "\u258c",  # 4/8
    "\u258b",  # 5/8
    "\u258a",  # 6/8
    "\u2589",  # 7/8
)

# User-friendly timezone aliases resolved to IANA names. "local" is a
# sentinel value that triggers system-timezone auto-detection.
_TZ_ALIASES: dict[str, str] = {
    "utc": "UTC",
    "gmt": "UTC",
    "local": "__LOCAL__",
    "pt": "America/Los_Angeles",
    "pst": "America/Los_Angeles",
    "pdt": "America/Los_Angeles",
    "et": "America/New_York",
    "est": "America/New_York",
    "edt": "America/New_York",
    "ct": "America/Chicago",
    "cst": "America/Chicago",
    "cdt": "America/Chicago",
    "mt": "America/Denver",
    "mst": "America/Denver",
    "mdt": "America/Denver",
}


def _format_price(value: float | None) -> str:
    """Render a USD/hr price as ``$X.XX``; ``-`` when missing."""
    if value is None or value <= 0:
        return "-"
    return f"${value:.2f}"


def _format_delta_abs(value: float | None) -> str:
    """Render an absolute price delta with an explicit sign; ``-`` when missing."""
    if value is None:
        return "-"
    sign = "+" if value >= 0 else "-"
    return f"{sign}${abs(value):.2f}"


def _format_delta_pct(value: float | None) -> str:
    """Render a percentage delta with an explicit sign; ``-`` when missing."""
    if value is None:
        return "-"
    sign = "+" if value >= 0 else "-"
    return f"{sign}{abs(value):.1f}%"



def _bar_for(value: float, max_value: float) -> str:
    """Map ``value`` to a single block-character bar proportional to ``max_value``."""
    if max_value <= 0 or value <= 0:
        return _BAR_BLOCKS[0]
    ratio = min(1.0, value / max_value)
    idx = min(len(_BAR_BLOCKS) - 1, int(ratio * (len(_BAR_BLOCKS) - 1) + 0.5))
    return _BAR_BLOCKS[idx]


def _horizontal_bar(value: float, max_value: float, width: int = _WEEKDAY_BAR_WIDTH) -> str:
    """Render a horizontal bar whose length encodes ``value / max_value``.

    Uses full-block ``█`` characters for whole units and fractional-width
    glyphs (``▏▎▍▌▋▊▉``) for the trailing character. Empty when ``value`` is
    non-positive. Maximum length is ``width`` characters.
    """
    if max_value <= 0 or value <= 0:
        return ""
    ratio = min(1.0, value / max_value)
    total_eighths = round(ratio * width * 8)
    full_blocks = total_eighths // 8
    remainder = total_eighths % 8
    bar = "\u2588" * full_blocks
    if remainder > 0 and full_blocks < width:
        bar += _HBAR_FRACTIONAL[remainder - 1]
    return bar


def _sparkline(values: list[float], mask: list[bool]) -> str:
    """Render a sparkline of ``values``; masked-out positions render as a dot.

    Scales each cell to the ``[min, max]`` range of visible values so tight
    ranges still use the full 8-block contrast. When all visible values are
    equal, renders a constant mid-range line.
    """
    if not values:
        return ""
    visible = [v for v, ok in zip(values, mask, strict=True) if ok and v > 0]
    if not visible:
        return "\u00b7" * len(values)
    lo = min(visible)
    hi = max(visible)
    span = hi - lo
    chars: list[str] = []
    last_idx = len(_BAR_BLOCKS) - 1
    for value, ok in zip(values, mask, strict=True):
        if not ok or value <= 0:
            chars.append("\u00b7")
            continue
        if span <= 0:
            chars.append(_BAR_BLOCKS[last_idx // 2])
            continue
        ratio = (value - lo) / span
        idx = min(last_idx, int(ratio * last_idx + 0.5))
        chars.append(_BAR_BLOCKS[idx])
    return "".join(chars)


def _render_wow_panel(result: WeekOverWeekResult, target_console: Console) -> None:
    """Render the two-row week-over-week comparison panel."""
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")
    table = create_flow_table(title=None, show_borders=False, padding=1)
    add_left_aligned_column(table, "Window", style=accent)
    add_right_aligned_column(table, "This Wk")
    add_right_aligned_column(table, "Last Wk")
    add_right_aligned_column(table, "\u0394 ($)")
    add_right_aligned_column(table, "\u0394 (%)")

    star = "*" if result.significant_overlap else ""
    table.add_row(
        "Overlapping (Mon\u2013now)",
        _format_price(result.this_wk_overlap),
        _format_price(result.last_wk_overlap),
        f"{_format_delta_abs(result.delta_overlap_abs)}{star}",
        f"{_format_delta_pct(result.delta_overlap_pct)}{star}",
    )
    table.add_row(
        "Full week (Mon\u2013Sun last)",
        _format_price(result.this_wk_full),
        _format_price(result.last_wk_full),
        _format_delta_abs(result.delta_full_abs),
        _format_delta_pct(result.delta_full_pct),
    )
    wrap_table_in_panel(table, "Week over Week", target_console)
    if result.significant_overlap:
        target_console.print(f"[{muted}]* delta exceeds 7d volatility band[/{muted}]")


def _render_weekday_panel(
    stats: list[WeekdayStat],
    target_console: Console,
    cv_pct: float = 0.0,
) -> None:
    """Render the 7-row weekday seasonality panel with horizontal bars.

    Suppresses the cheapest/peak labels when ``cv_pct`` exceeds
    :data:`_LABEL_NOISE_CV_PCT` — in noisy markets the bucket means are
    dominated by a handful of anomalous hours and the labels mislead agents
    into treating noise as seasonality.
    """
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")

    displayable = [s for s in stats if s.hours_covered >= _MIN_HOURS_FOR_DISPLAY and s.mean > 0]

    table = create_flow_table(title=None, show_borders=False, padding=1)
    add_left_aligned_column(table, "Day", style=accent)
    add_right_aligned_column(table, "Mean")
    if displayable:
        max_mean = max(s.mean for s in displayable)
        bar_header = f"Distribution (max ${max_mean:.2f})"
    else:
        max_mean = 0.0
        bar_header = "Distribution"
    add_left_aligned_column(table, bar_header)
    add_right_aligned_column(table, "\u0394 vs avg")

    if not displayable:
        table.add_row("\u2014", "-", "-", "[dim]insufficient data[/dim]")
        wrap_table_in_panel(table, "Day of Week (UTC)", target_console)
        return

    labels_trustworthy = cv_pct <= _LABEL_NOISE_CV_PCT
    cheapest = min(displayable, key=lambda s: s.mean)
    peak = max(displayable, key=lambda s: s.mean)

    for stat in stats:
        has_data = stat.hours_covered >= _MIN_HOURS_FOR_DISPLAY and stat.mean > 0
        row_style = "" if has_data else "dim"
        bar = _horizontal_bar(stat.mean, max_mean) if has_data else "\u2014"
        delta_cell = _format_delta_pct(stat.relative_index * 100.0) if has_data else "-"

        # Visual indicators (arrow + color) always fire regardless of CV — they
        # just mark the visible min/max of what's rendered. Text labels ("←
        # cheapest"/"← peak") only fire when the market is calm enough that the
        # seasonality signal is predictive, not noise.
        is_cheapest = has_data and stat.weekday == cheapest.weekday
        is_peak = has_data and stat.weekday == peak.weekday
        if is_cheapest:
            day_cell = f"[green]\u25bc  {stat.name}[/green]"
            bar_cell = f"[green]{bar}[/green]"
            if labels_trustworthy:
                delta_cell = f"{delta_cell} [green]\u2190 cheapest[/green]"
        elif is_peak:
            day_cell = f"[yellow]\u25b2  {stat.name}[/yellow]"
            bar_cell = f"[yellow]{bar}[/yellow]"
            if labels_trustworthy:
                delta_cell = f"{delta_cell} [yellow]\u2190 peak[/yellow]"
        else:
            day_cell = f"   {stat.name}"
            bar_cell = bar

        table.add_row(
            day_cell,
            _format_price(stat.mean) if has_data else "-",
            bar_cell,
            delta_cell,
            style=row_style,
        )

    wrap_table_in_panel(table, "Day of Week (UTC)", target_console)
    if labels_trustworthy:
        footer = (
            "\u25bc cheapest  \u25b2 peak  \u2014 based on duration-weighted"
            " means over the selected window."
        )
    else:
        footer = (
            f"Market CV {cv_pct:.0f}% \u2265 {_LABEL_NOISE_CV_PCT:.0f}%"
            f" \u2014 \u25bc/\u25b2 mark visible min/max only;"
            f" seasonality not predictive at this volatility."
        )
    target_console.print(f"[{muted}]{footer}[/{muted}]")


def _render_hour_panel(
    stats: list[HourStat],
    target_console: Console,
    cv_pct: float = 0.0,
    tz_abbr: str = "UTC",
) -> None:
    """Render the 24-hour intraday profile with inline cheap/peak highlights.

    ``stats`` is expected to be indexed by display-tz hour — the caller
    rotates the UTC-bucketed hour stats before calling this helper, and
    passes ``tz_abbr`` (``PDT``, ``PST``, ``UTC``, ...) so hour labels
    and the verdict line read natively in the user's timezone.

    Layout:
      - Preamble line explaining how to read the sparkline
      - Single-row 24-cell sparkline (one cell per hour) with the
        cheapest cell coloured green and the peak cell coloured yellow
        inline
      - Axis with five tick marks (00/06/12/18/23) aligned to the
        sparkline columns
      - Two rows breaking out the cheapest and peak hours with their
        mean prices and the percent spread
      - Plain-English verdict: "launch near HH:00 {tz} to save ~$X/hr"
        — suppressed with an informational note when ``cv_pct`` exceeds
        :data:`_LABEL_NOISE_CV_PCT` because intraday seasonality is
        dominated by noise in volatile markets.
    """
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")
    border = theme_manager.get_color("table.border")

    mask = [s.hours_covered >= _MIN_HOURS_FOR_DISPLAY and s.mean > 0 for s in stats]
    values = [s.mean for s in stats]
    raw_sparkline = _sparkline(values, mask)

    visible = [s for s, ok in zip(stats, mask, strict=True) if ok]
    if not visible or not raw_sparkline:
        body = "[dim]insufficient data[/dim]"
    else:
        cheapest = min(visible, key=lambda s: s.mean)
        peak = max(visible, key=lambda s: s.mean)
        spread_abs = peak.mean - cheapest.mean
        spread_pct = (spread_abs / cheapest.mean * 100.0) if cheapest.mean > 0 else 0.0

        # Highlight cheapest (green) and peak (yellow) cells inline.
        chars = list(raw_sparkline)
        if 0 <= cheapest.hour < len(chars):
            chars[cheapest.hour] = f"[green]{chars[cheapest.hour]}[/green]"
        if 0 <= peak.hour < len(chars):
            chars[peak.hour] = f"[yellow]{chars[peak.hour]}[/yellow]"
        sparkline_line = "".join(chars)

        # Axis ticks at 00/06/12/18/23 UTC, each left-aligned on its column.
        # "00" cols 0-1 | "06" cols 6-7 | "12" cols 12-13 | "18" cols 18-19 | "23" cols 22-23
        axis_line = f"[{muted}]00{' ' * 4}06{' ' * 4}12{' ' * 4}18{' ' * 2}23[/{muted}]"

        lines: list[str] = [
            f"[{muted}]Each cell = 1 hour in {tz_abbr}. Taller = more expensive.[/{muted}]",
            "",
            sparkline_line,
            axis_line,
            "",
            (
                f"[green]cheap[/green]  {_format_price(cheapest.mean)} @"
                f" {cheapest.hour:02d}:00 {tz_abbr}"
            ),
            (
                f"[yellow] peak[/yellow]  {_format_price(peak.mean)} @"
                f" {peak.hour:02d}:00 {tz_abbr}"
                f"  [{muted}](+{spread_pct:.0f}% vs cheap)[/{muted}]"
            ),
        ]

        if cv_pct <= _LABEL_NOISE_CV_PCT:
            lines.append("")
            lines.append(
                f"\u2192 Deferrable jobs: launch near {cheapest.hour:02d}:00 {tz_abbr}"
                f" to save ~${spread_abs:.2f}/GPU-hr vs peak."
            )
        else:
            lines.append("")
            lines.append(
                f"[{muted}]\u2192 Market CV {cv_pct:.0f}% \u2265"
                f" {_LABEL_NOISE_CV_PCT:.0f}% \u2014 intraday pattern dominated"
                f" by noise; treat as informational, not a schedule.[/{muted}]"
            )

        body = "\n".join(lines)

    panel = Panel(
        body,
        title=f"[bold {accent}]Hour of Day {tz_abbr} (last 14d)[/bold {accent}]",
        title_align="left",
        border_style=border,
        padding=(0, 1),
        expand=False,
    )
    target_console.print(panel)


def _render_peak_slow_panel(days: list[DayStat], k: int, target_console: Console) -> None:
    """Render the two-column cheapest / most-expensive calendar-days panel."""
    accent = theme_manager.get_color("accent")
    usable = [d for d in days if d.hours_covered >= _MIN_HOURS_FOR_DISPLAY and d.mean > 0]
    cheap = sorted(usable, key=lambda d: d.mean)[:k]
    expensive = sorted(usable, key=lambda d: -d.mean)[:k]

    table = create_flow_table(title=None, show_borders=False, padding=1)
    add_left_aligned_column(table, "Cheapest", style=accent)
    add_left_aligned_column(table, "Most Expensive", style=accent)

    rows = max(len(cheap), len(expensive))
    if rows == 0:
        table.add_row("[dim]insufficient data[/dim]", "[dim]insufficient data[/dim]")
    else:
        for i in range(rows):
            left = _format_day_row(cheap[i]) if i < len(cheap) else ""
            right = _format_day_row(expensive[i]) if i < len(expensive) else ""
            table.add_row(left, right)

    wrap_table_in_panel(table, "Peak / Slow Days (last 14d UTC)", target_console)


def _format_day_row(day: DayStat) -> str:
    """Render one DayStat as ``"Sat 2026-04-04  $2.21"``."""
    weekday_name = day.date.strftime("%a")
    iso = day.date.isoformat()
    return f"{weekday_name} {iso}  {_format_price(day.mean)}"


def _momentum_arrow(delta_6h: float | None, delta_1h: float | None) -> tuple[str, str]:
    """Return ``(arrow, label)`` describing the recent price direction.

    Keys off the most-recent signal (``delta_1h``) first and falls back to
    ``delta_6h`` when 1h data is absent or inside the flat deadband.
    Positive deltas mean prices ROSE over the window (heating), negative
    mean they fell (cooling). A small ``_MOMENTUM_FLAT_PCT`` deadband
    prevents arrow flicker on noise.
    """
    candidates: list[float] = [d for d in (delta_1h, delta_6h) if d is not None]
    if not candidates:
        return "\u00b7", "flat"
    for delta in candidates:
        if abs(delta) < _MOMENTUM_FLAT_PCT:
            continue
        if delta > 0:
            return "\u2191", "heating"
        return "\u2193", "cooling"
    return "\u2192", "flat"


def _render_volatility_panel(
    summary: VolatilitySummary,
    trend: PriceTrend,
    target_console: Console,
) -> None:
    """Render the 3-line volatility/momentum panel."""
    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")

    delta_6h = trend.delta_6h
    delta_1h = trend.delta_1h
    arrow, cooling_heating = _momentum_arrow(delta_6h, delta_1h)
    six_h_text = f"{delta_6h:+.1f}%" if delta_6h is not None else "-"
    one_h_text = f"{delta_1h:+.1f}%" if delta_1h is not None else "-"

    table = create_flow_table(title=None, show_borders=False, padding=1)
    add_left_aligned_column(table, "Signal", style=accent)
    add_left_aligned_column(table, "Value")
    table.add_row("7d CV", f"{summary.cv_pct:.1f}% ([{muted}]{summary.label}[/{muted}])")
    table.add_row(
        f">{summary.swing_threshold_pct:.0f}% swings",
        f"{summary.swing_count_7d} in last 7d",
    )
    table.add_row(
        "Momentum",
        f"{arrow} {cooling_heating} \u2014 6h {six_h_text}, 1h {one_h_text}",
    )
    wrap_table_in_panel(table, "Volatility Trend", target_console)


def _compute_reference_time() -> datetime:
    """Return the reference "now" in UTC. Extracted for test monkeypatching."""
    return datetime.now(tz=timezone.utc)


def _detect_system_tz() -> tzinfo:
    """Best-effort system-timezone detection.

    Tries ``/etc/localtime`` symlink resolution first (works on macOS and
    most Linux distros — the symlink target includes the canonical IANA
    name after the ``zoneinfo`` path segment). Falls back to
    ``datetime.now().astimezone().tzinfo`` which on macOS returns a fixed
    ``datetime.timezone`` with a short abbreviation (e.g. ``PDT``); that's
    still usable for offset and ``%Z`` formatting even without full IANA
    DST rule data. Ultimately falls back to UTC so the command never
    crashes on an exotic configuration.
    """
    localtime = Path("/etc/localtime")
    try:
        if localtime.is_symlink():
            target = localtime.resolve()
            parts = target.parts
            if "zoneinfo" in parts:
                idx = parts.index("zoneinfo")
                iana_name = "/".join(parts[idx + 1 :])
                if iana_name:
                    return ZoneInfo(iana_name)
    except (OSError, ValueError, ZoneInfoNotFoundError):
        pass

    local_tzinfo = datetime.now().astimezone().tzinfo
    if local_tzinfo is not None:
        return local_tzinfo
    return timezone.utc


def _resolve_display_tz(spec: str) -> tzinfo:
    """Resolve a user-friendly tz spec (``pt``, ``local``, ``UTC``, IANA name).

    Returns a :class:`datetime.tzinfo` — either a :class:`zoneinfo.ZoneInfo`
    for named zones or a system-local ``tzinfo`` when ``spec='local'`` on
    a platform where we cannot recover the IANA name. Unknown specs raise
    :class:`click.BadParameter` so the CLI surfaces an actionable error
    instead of silently falling back to UTC.
    """
    normalized = (spec or "local").strip().lower()
    resolved = _TZ_ALIASES.get(normalized)
    if resolved == "__LOCAL__":
        return _detect_system_tz()
    canonical = resolved or spec
    try:
        return ZoneInfo(canonical)
    except ZoneInfoNotFoundError as exc:
        raise click.BadParameter(
            f"Unknown timezone: {spec!r}."
            f" Use 'utc', 'local', 'pt', 'et', 'ct', 'mt', or an IANA name."
        ) from exc


def _tz_offset_hours(tz: tzinfo, reference_time: datetime) -> int | None:
    """Return the integer UTC offset in hours at ``reference_time``.

    Returns ``None`` for zones whose offset is not a whole number of hours
    (e.g., ``Asia/Kolkata`` at UTC+5:30). Callers should fall back to UTC
    hour-of-day display in that case since rotating 24 UTC buckets by a
    non-integer offset would misalign every cell.
    """
    localized = reference_time.astimezone(tz)
    offset = localized.utcoffset() or timedelta(0)
    total_seconds = int(offset.total_seconds())
    if total_seconds % 3600 != 0:
        return None
    return total_seconds // 3600


def _tz_abbr(tz: tzinfo, reference_time: datetime) -> str:
    """Return the short timezone abbreviation (``PDT``, ``PST``, ``UTC``) at ``reference_time``."""
    localized = reference_time.astimezone(tz)
    return localized.strftime("%Z") or str(tz)


def _rotate_hours_to_local(
    stats: list[HourStat],
    offset_hours: int,
) -> list[HourStat]:
    """Rotate a 24-entry UTC-indexed list so index ``p`` holds local hour ``p``.

    For a tz with offset ``-7`` (PDT), local hour 0 corresponds to UTC hour
    7 — so the rotated list's entry at index 0 carries the mean from UTC
    hour 7 but with its ``hour`` field set to ``0``. This lets the renderer
    treat the list as already-local and label each cell with its local hour
    directly.
    """
    rotated: list[HourStat] = []
    for local_hour in range(24):
        utc_hour = (local_hour - offset_hours) % 24
        orig = stats[utc_hour]
        rotated.append(
            HourStat(
                hour=local_hour,
                mean=orig.mean,
                hours_covered=orig.hours_covered,
                relative_index=orig.relative_index,
            )
        )
    return rotated


def _lookup_history(
    history: dict[tuple[str, str, int], dict[str, Any]],
    gpu: str,
    region: str,
    gpu_count: int,
) -> dict[str, Any] | None:
    """Case-insensitive lookup of a (gpu, region, gpu_count) series."""
    target = (gpu.lower(), region, gpu_count)
    for (g, r, gc), entry in history.items():
        if (g.lower(), r, gc) == target:
            return entry
    return None


def _pick_cheapest_region(
    history: dict[tuple[str, str, int], dict[str, Any]],
    gpu: str,
    gpu_count: int,
) -> str | None:
    """Return the cheapest region for ``(gpu, gpu_count)`` by most recent price.

    Scans all ``(gpu, region, gpu_count)`` entries in ``history`` and returns
    the region whose last spot price is lowest. Entries with empty price
    series are ignored. Returns ``None`` when no matching market exists so
    callers can fail closed with an actionable error.
    """
    gpu_lower = gpu.lower()
    best_region: str | None = None
    best_price = float("inf")
    for (g, r, gc), entry in history.items():
        if g.lower() != gpu_lower or gc != gpu_count:
            continue
        prices = entry.get("spot_prices") or []
        if not prices:
            continue
        current = prices[-1]
        if current < best_price:
            best_price = current
            best_region = r
    return best_region


def _build_json_payload(
    *,
    gpu: str,
    region: str,
    gpu_count: int,
    reference_time: datetime,
    wow: WeekOverWeekResult,
    weekday_stats: list[WeekdayStat],
    hour_stats: list[HourStat],
    day_stats: list[DayStat],
    vol: VolatilitySummary,
    display_tz_name: str,
    display_tz_abbr: str,
    display_tz_offset_hours: int | None,
) -> dict[str, Any]:
    """Assemble the locked JSON schema for ``flow pricing stats --json``.

    ``hour_stats`` is UTC-indexed (the unrotated domain bucket output);
    each emitted ``hourly`` entry carries both the UTC ``hour`` field for
    backwards compatibility and a ``hour_local`` field derived from
    ``display_tz_offset_hours`` so consumers can read either timezone.
    """
    usable_days = [d for d in day_stats if d.hours_covered >= _MIN_HOURS_FOR_DISPLAY and d.mean > 0]
    peak_days = sorted(usable_days, key=lambda d: -d.mean)[:_PEAK_SLOW_K]
    slow_days = sorted(usable_days, key=lambda d: d.mean)[:_PEAK_SLOW_K]
    return {
        "config": {"gpu": gpu, "region": region, "gpu_count": gpu_count},
        "reference_time": reference_time.isoformat(),
        "display_tz": display_tz_name,
        "display_tz_abbr": display_tz_abbr,
        "display_tz_offset_hours": display_tz_offset_hours,
        "wow": {
            "this_wk_overlap": wow.this_wk_overlap,
            "last_wk_overlap": wow.last_wk_overlap,
            "this_wk_full": wow.this_wk_full,
            "last_wk_full": wow.last_wk_full,
            "delta_overlap_abs": wow.delta_overlap_abs,
            "delta_overlap_pct": wow.delta_overlap_pct,
            "delta_full_abs": wow.delta_full_abs,
            "delta_full_pct": wow.delta_full_pct,
            "significant_overlap": wow.significant_overlap,
            "hours_elapsed_this_wk": wow.hours_elapsed_this_wk,
        },
        "weekday": [
            {
                "weekday": w.weekday,
                "name": w.name,
                "mean": w.mean,
                "hours_covered": w.hours_covered,
                "relative_index": w.relative_index,
            }
            for w in weekday_stats
        ],
        "hourly": [
            {
                "hour": h.hour,
                "hour_local": (
                    (h.hour + display_tz_offset_hours) % 24
                    if display_tz_offset_hours is not None
                    else h.hour
                ),
                "mean": h.mean,
                "hours_covered": h.hours_covered,
                "relative_index": h.relative_index,
            }
            for h in hour_stats
        ],
        "peak_days": [
            {
                "date": d.date.isoformat(),
                "mean": d.mean,
                "hours_covered": d.hours_covered,
            }
            for d in peak_days
        ],
        "slow_days": [
            {
                "date": d.date.isoformat(),
                "mean": d.mean,
                "hours_covered": d.hours_covered,
            }
            for d in slow_days
        ],
        "volatility": {
            "cv_pct": vol.cv_pct,
            "label": vol.label,
            "swing_count_7d": vol.swing_count_7d,
            "swing_threshold_pct": vol.swing_threshold_pct,
        },
    }


def build_command(owner: BaseCommand) -> click.Command:
    """Build the ``flow pricing stats`` Click command.

    The ``owner`` parameter is the parent :class:`PricingCommand` instance;
    ``cli_error_guard(owner)`` routes exceptions through its error handlers
    for consistent formatting with the default ``flow pricing`` view.
    """

    @click.command(name="stats", help="Per-market price statistics for one (gpu, region, size).")
    @click.option("--gpu", default="h100", show_default=True, help="Target GPU (e.g., h100, 1xb200)")
    @click.option(
        "--region",
        default=None,
        help="Target region (default: auto-pick cheapest region for the GPU)",
    )
    @click.option("--gpu-count", type=int, default=8, show_default=True, help="GPU count tier")
    @click.option(
        "--window-days",
        type=int,
        default=28,
        show_default=True,
        help="Window for weekday seasonality panel (hourly/WoW stay 14d)",
    )
    @click.option(
        "--swing-threshold",
        type=float,
        default=10.0,
        show_default=True,
        help="Percentage move counted as a swing in volatility summary",
    )
    @click.option(
        "--tz",
        "tz_spec",
        default="local",
        show_default=True,
        help=(
            "Display timezone: 'local' (auto-detect), 'utc', 'pt', 'et', 'ct', 'mt',"
            " or any IANA name like 'Asia/Tokyo'"
        ),
    )
    @click.option("--json", "-j", "as_json", is_flag=True, help="Emit machine-readable JSON")
    @cli_error_guard(owner)
    def stats(
        gpu: str,
        region: str | None,
        gpu_count: int,
        window_days: int,
        swing_threshold: float,
        tz_spec: str,
        as_json: bool,
    ) -> None:
        """Render per-market price statistics."""
        gpu, parsed_count = parse_gpu_spec(gpu)
        if parsed_count is not None:
            gpu_count = parsed_count

        reference_time = _compute_reference_time()
        api_base, api_key, _project = _resolve_api_context()
        try:
            fid_map = _fetch_instance_type_map(api_base, api_key)
            history = _fetch_price_history(
                api_base,
                api_key,
                fid_map,
                gpu_filter=gpu,
                region_filter=region,
                target_regions=[region] if region else None,
            )
        except Exception as exc:  # noqa: BLE001
            message = f"Unable to fetch pricing data: {exc}"
            if as_json:
                print_json(error_json(message))
            else:
                console.print(f"\n[dim]{message}[/dim]\n")
            raise click.exceptions.Exit(1)

        auto_region = region is None
        if auto_region:
            resolved_region = _pick_cheapest_region(history, gpu, gpu_count)
            if resolved_region is None:
                message = (
                    f"No markets found for {gpu.upper()} {gpu_count}x."
                    f" Try a different --gpu or --gpu-count,"
                    f" or run 'flow pricing --gpu {gpu}' to see what's live."
                )
                if as_json:
                    print_json(error_json(message))
                else:
                    console.print(f"[red]{message}[/red]")
                raise click.exceptions.Exit(1)
            region = resolved_region

        try:
            Telemetry().log_event(
                "pricing_stats_view_shown",
                {
                    "gpu": gpu,
                    "region": region,
                    "gpu_count": gpu_count,
                    "window_days": window_days,
                    "auto_region": auto_region,
                },
            )
        except Exception:  # noqa: BLE001
            pass

        entry = _lookup_history(history, gpu, region, gpu_count)
        if entry is None:
            message = (
                f"No price history found for {gpu.upper()} {gpu_count}x in {region}."
                f" Check the market exists via 'flow pricing --gpu {gpu}'."
            )
            if as_json:
                print_json(error_json(message))
            else:
                console.print(f"[red]{message}[/red]")
            raise click.exceptions.Exit(1)

        spot_prices: list[float] = entry["spot_prices"]
        timestamps: list[str] = entry["timestamps"]
        current_price = spot_prices[-1] if spot_prices else 0.0

        wow = week_over_week_compare(spot_prices, timestamps, reference_time)
        weekday_stats = bucket_by_weekday(
            spot_prices, timestamps, reference_time, window_days=window_days
        )
        hour_stats = bucket_by_hour(spot_prices, timestamps, reference_time, window_days=14)
        day_stats = bucket_by_day(spot_prices, timestamps, reference_time, window_days=14)
        vol = volatility_summary(
            spot_prices,
            timestamps,
            reference_time,
            swing_threshold_pct=swing_threshold,
        )
        trend = compute_price_trend(
            spot_prices, timestamps, current_price, reference_time=reference_time
        )

        # Resolve the display timezone and rotate hour buckets for local-hour
        # rendering. Non-integer offsets (e.g., India UTC+5:30) fall back to
        # UTC since hour-level rotation would otherwise misalign each cell.
        display_tz = _resolve_display_tz(tz_spec)
        offset_hours = _tz_offset_hours(display_tz, reference_time)
        tz_abbr = _tz_abbr(display_tz, reference_time)
        if offset_hours is None:
            display_hour_stats = hour_stats
            tz_abbr = "UTC"
        else:
            display_hour_stats = _rotate_hours_to_local(hour_stats, offset_hours)

        if as_json:
            payload = _build_json_payload(
                gpu=gpu,
                region=region,
                gpu_count=gpu_count,
                reference_time=reference_time,
                wow=wow,
                weekday_stats=weekday_stats,
                hour_stats=hour_stats,
                day_stats=day_stats,
                vol=vol,
                display_tz_name=str(display_tz),
                display_tz_abbr=tz_abbr,
                display_tz_offset_hours=offset_hours,
            )
            click.echo(json.dumps(payload, indent=2))
            return

        accent = theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")
        suffix = f" [{muted}](auto-selected cheapest region)[/{muted}]" if auto_region else ""
        console.print(
            f"[bold {accent}]Pricing stats[/bold {accent}]"
            f" \u2022 {gpu.upper()} {gpu_count}x \u2022 {region}{suffix}"
            f" \u2022 [{muted}]{tz_abbr}[/{muted}]"
        )
        _render_wow_panel(wow, console)
        _render_weekday_panel(weekday_stats, console, cv_pct=vol.cv_pct)
        _render_hour_panel(display_hour_stats, console, cv_pct=vol.cv_pct, tz_abbr=tz_abbr)
        _render_peak_slow_panel(day_stats, _PEAK_SLOW_K, console)
        _render_volatility_panel(vol, trend, console)

    return stats
