import contextlib
import io
import os
import time
import socket
import pickle
import random
import asyncio
import fnmatch
from ftplib import FTP_TLS, error_perm

from http.client import RemoteDisconnected
from http.cookiejar import LoadError
from typing import Union, List
from urllib.error import URLError
from urllib3.exceptions import MaxRetryError, ReadTimeoutError


import requests
from playwright.sync_api import sync_playwright
from requests.exceptions import (
    ReadTimeout,
    ConnectionError as RequestsConnectionError,
    ChunkedEncodingError,
    ConnectTimeout,
)
from .logger import Logger
from .file_entry import FileEntry
from .retry import retry
from .file_cache import file_cache


exceptions = (
    URLError,
    RemoteDisconnected,
    ConnectionResetError,
    ConnectTimeout,
    MaxRetryError,
    socket.gaierror,
    socket.timeout,
    ConnectionError,
    ReadTimeout,
    ReadTimeoutError,
    RequestsConnectionError,
    ChunkedEncodingError,
    error_perm,
    LoadError,
)


def download_connection_retry():
    """decorator the define the retry logic of connections tring to download files"""

    def wrapper(func):
        @retry(
            exceptions=exceptions,
            tries=8,
            delay=2,
            backoff=2,
            max_delay=5 * 60,
            logger=Logger,
            timeout=15,
            backoff_timeout=5,
        )
        def inner(*args, **kwargs):
            socket.setdefaulttimeout(kwargs.get("timeout", 15))
            del kwargs["timeout"]  # function don't get timeout param
            return func(*args, **kwargs)

        return inner

    return wrapper


def url_connection_retry(init_timeout=15):
    """decorator the define the retry logic of connections tring to send get request"""

    def wrapper(func):
        # Store the original requested timeout in a closure variable
        # This will be set by the outer wrapper before retry processes it
        requested_timeout_ref = [init_timeout]

        def outer_wrapper(*args, **kwargs):
            # Capture the timeout from the original call before retry processes it
            original_timeout = kwargs.get("timeout", init_timeout)
            if original_timeout > requested_timeout_ref[0]:
                requested_timeout_ref[0] = original_timeout
            # Now call the retry-decorated function
            return retry_decorated_func(*args, **kwargs)

        @retry(
            exceptions=exceptions,
            tries=4,
            delay=2,
            backoff=2,
            max_delay=5 * 60,
            logger=Logger,
            timeout=init_timeout,
            backoff_timeout=10,
            max_timeout=120,  # Cap timeout at 2 minutes to prevent unbounded growth
        )
        def retry_decorated_func(*args, **kwargs):
            # Use the higher of retry's timeout or the originally requested timeout
            retry_timeout = kwargs.get("timeout", init_timeout)
            actual_timeout = max(retry_timeout, requested_timeout_ref[0])
            socket.setdefaulttimeout(actual_timeout)
            kwargs["timeout"] = actual_timeout
            return func(*args, **kwargs)

        return outer_wrapper

    return wrapper


def async_url_connection_retry(init_timeout=15):
    """Async decorator for retry logic of connections trying to send requests"""

    def wrapper(func):
        # Store the original requested timeout in a closure variable
        requested_timeout_ref = [init_timeout]

        async def outer_wrapper(*args, **kwargs):
            # Capture the timeout from the original call
            original_timeout = kwargs.get("timeout", init_timeout)
            if original_timeout > requested_timeout_ref[0]:
                requested_timeout_ref[0] = original_timeout

            # Manual retry logic for async functions
            _tries = 4
            _delay = 2
            backoff = 2
            max_delay = 5 * 60
            max_timeout = 120  # Cap timeout at 2 minutes

            while _tries:
                try:
                    retry_timeout = kwargs.get("timeout", init_timeout)
                    actual_timeout = max(retry_timeout, requested_timeout_ref[0])
                    actual_timeout = min(
                        actual_timeout, max_timeout
                    )  # Enforce max timeout
                    socket.setdefaulttimeout(actual_timeout)
                    kwargs["timeout"] = actual_timeout
                    return await func(*args, **kwargs)
                except exceptions as error:
                    _tries -= 1
                    is_final_attempt = not _tries

                    if Logger is not None:
                        error_type = type(error).__name__
                        error_msg = str(error)
                        if len(error_msg) > 200:
                            error_msg = error_msg[:200] + "..."

                        Logger.warning(
                            "%s: %s (timeout=%s, retries_left=%d, retrying in %s seconds)",
                            error_type,
                            error_msg,
                            actual_timeout,
                            _tries,
                            _delay,
                        )

                        # Only log full stack trace on final failure
                        if is_final_attempt:
                            Logger.error_execption(error)

                    if is_final_attempt:
                        raise

                    await asyncio.sleep(_delay)
                    _delay = min(_delay * backoff, max_delay)
                    requested_timeout_ref[0] = min(
                        requested_timeout_ref[0] + 10, max_timeout
                    )  # backoff_timeout with cap

            raise ValueError("shouldn't be called!")

        return outer_wrapper

    return wrapper


@file_cache(ttl=60)
def get_ip():
    """get the ip of the computer running the code"""
    response = requests.get("https://api.ipify.org?format=json", timeout=15).json()
    return response["ip"]


@file_cache(ttl=60)
def get_location():
    """get the estimated location of the computer running the code"""
    ip_address = get_ip()
    response = requests.get(f"https://ipapi.co/{ip_address}/json/", timeout=15).json()

    location_data = {
        "ip": ip_address,
        "city": response.get(
            "city",
        ),
        "region": response.get("region"),
        "country": response.get("country_name"),
    }
    return location_data


def disable_when_outside_israel(function):
    """decorator to disable tests that scrap gov.il site to run outside israel region"""

    def _decorator():
        Logger.warning(
            f"test {function.__name__ } has been disabled!"
            "can't scarper Gov.il site outside IL region."
        )

    execute = True
    try:
        estimated_location = get_location()
        execute = not (
            estimated_location["country"] is not None
            and estimated_location["country"] != "Israel"
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        Logger.warning(f"error in getting location {str(e)}")

    if execute:
        return function

    Logger.info(f"estimated location is {str(estimated_location)}")
    return _decorator


def get_random_user_agent():
    """get random user agent"""
    user_agents = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0",
        "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1)",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0",
        "Opera/9.80 (Windows NT 6.2; Win64; x64) Presto/2.12.388 Version/12.17",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 15_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Linux; Android 9; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36",  # pylint: disable=line-too-long
        "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15",  # pylint: disable=line-too-long
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36",  # pylint: disable=line-too-long
    ]

    return {"User-Agent": random.choice(user_agents)}


@url_connection_retry(
    init_timeout=60
)  # Increased default to handle slow servers like Shufersal
def session_with_cookies(
    url, timeout=15, chain_cookie_name=None, method="GET", body=None, headers=None
):
    """
    Request resource with cookies enabled.

    Parameters:
    - url: URL to request
    - timeout: Request timeout
    - chain_cookie_name: Optional, name for saving/loading cookies
    - method: HTTP method, defaults to GET
    - body: Data to be sent in the request body (for POST or PUT requests)
    - headers: Optional dict of custom headers to include in the request
    """

    session = requests.Session()
    if chain_cookie_name:

        try:
            with open(chain_cookie_name, "rb") as f:
                session.cookies.update(pickle.load(f))
            # session.cookies.load()
        except FileNotFoundError:
            Logger.debug("Didn't find cookie file")
        except Exception as e:
            # There was an issue with reading the file.
            os.remove(chain_cookie_name)
            raise e

    Logger.debug(
        f"On a new Session requesting url: method={method}, url={url}, body={body}"
    )

    if method == "POST":
        response_content = session.post(
            url, data=body, timeout=timeout, headers=headers
        )
    else:
        response_content = session.get(url, timeout=timeout, headers=headers)

    if response_content.status_code != 200:
        Logger.debug(
            f"On Session, got status code: {response_content.status_code}"
            f", body is {response_content.text} "
        )
        raise ConnectionError(
            f"Response for {url}, returned with status"
            f" {response_content.status_code}"
        )

    if chain_cookie_name and not os.path.exists(chain_cookie_name):
        with open(chain_cookie_name, "wb") as f:
            pickle.dump(session.cookies.get_dict(), f)

    return response_content


def get_from_playwrite(page, extraction_type):
    """get the content from the page with playwrite"""

    if extraction_type == "update_date":
        content = page.locator(
            '//*[@id="content"]/div[1]/div/div/div/div[2]/div[6]/div'
        ).last.inner_text()
    elif extraction_type == "links_name":
        content = page.evaluate(
            """() => {
        const links = Array.from(document.querySelectorAll('a'));
        return links.map(link => link.textContent.trim());
    }"""
        )
    elif extraction_type == "all_text":
        content = page.evaluate(
            """
        () => {
            return document.body.innerText;
        }"""
        )
    else:
        raise ValueError(f"type '{extraction_type}' is not valid.")
    return content


def _looks_like_block_page(extracted_text: Union[str, List[str], None]) -> bool:
    """True if extracted page text looks like a block/captcha page."""
    if extracted_text is None:
        return True
    block_marks = (
        "you have been blocked",
        "Please enable cookies",
        "Unable to access",
        "cloudfare",
    )
    if isinstance(extracted_text, list):
        return any(_looks_like_block_page(item) for item in extracted_text)
    #
    lower = extracted_text.lower()
    return any(mark in lower for mark in block_marks) and len(lower) > 0


def _render_webpage_impl(url, user_agent=None):
    """Render website with Playwright; real browser context to reduce blocking."""
    if user_agent is None:
        user_agent = get_random_user_agent().get("User-Agent", "")
    last_error = None
    for attempt in range(3):
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    args=["--disable-blink-features=AutomationControlled"]
                )
                context = browser.new_context(
                    user_agent=user_agent,
                    viewport={"width": 1280, "height": 720},
                    locale="he-IL",
                    timezone_id="Asia/Jerusalem",
                )
                page = context.new_page()
                page.goto(url, timeout=90000, wait_until="domcontentloaded")
                # gov.il renders main content client-side; without this, HTML is an empty shell
                page.wait_for_selector("#content", timeout=90000, state="attached")
                with contextlib.suppress(Exception):
                    page.wait_for_load_state("networkidle", timeout=30000)
                page.wait_for_load_state("domcontentloaded", timeout=60000)
                content = page.content()
                browser.close()
            if 'id="content"' in content:
                return content
        except Exception as error:  # pylint: disable=broad-exception-caught
            last_error = error
            if attempt < 2:
                time.sleep(2 * (attempt + 1))
                continue
            raise error
    if last_error:
        raise last_error
    raise RuntimeError("failed to render page with #content")


@file_cache(ttl=60)
def render_webpage(url, user_agent=None):
    """render website with playwrite"""
    return _render_webpage_impl(url, user_agent=user_agent)


def get_from_latast_webpage(url, extraction_type):
    """get the content from the page with playwrite; retries with different UA if blocked."""
    time.sleep(1)
    user_agents = [
        None,  # use default from get_random_user_agent
        get_random_user_agent().get("User-Agent", ""),
        get_random_user_agent().get("User-Agent", ""),
        get_random_user_agent().get("User-Agent", ""),
    ]
    last_result = None
    for ua in user_agents:
        content = _render_webpage_impl(url, user_agent=ua if ua else None)
        result = get_from_webpage(content, extraction_type)
        last_result = result
        if not _looks_like_block_page(result):
            return result
        time.sleep(2)
    return last_result


def get_from_webpage(cached_page, extraction_type):
    """render website with playwrite from file system cache"""

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.set_content(cached_page)
        page.wait_for_load_state("domcontentloaded", timeout=60000)
        content = get_from_playwrite(page, extraction_type)
        browser.close()
    return content


def url_retrieve_to_memory(url, timeout=30, chunk_size=8192):
    """Download URL content directly to memory (BytesIO)."""
    with contextlib.closing(
        requests.get(
            url, stream=True, timeout=timeout, headers={"Accept-Encoding": None}
        )
    ) as _request:
        _request.raise_for_status()
        size = int(_request.headers.get("Content-Length", "-1"))
        read = 0
        file_buffer = io.BytesIO()
        for chunk in _request.iter_content(chunk_size=chunk_size):
            read += len(chunk)
            file_buffer.write(chunk)

    if size >= 0 and read < size:
        msg = f"retrieval incomplete: got only {read:d} out of {size:d} bytes"
        raise ValueError(msg, (url, _request.headers))

    file_buffer.seek(0)  # Reset to beginning for reading
    return file_buffer.getvalue()  # Return bytes


async def collect_from_ftp(
    ftp_host, ftp_username, ftp_password, ftp_path, arg=None, timeout=60 * 5
):
    """Async generator: yields (filename, size) tuples from the FTP server"""
    Logger.info(
        f"Open async connection to FTP server with {ftp_host} "
        f", username: {ftp_username} , password: {ftp_password}"
    )

    def _sync_ftp_list():  # pylint: disable=too-many-branches
        """Synchronous FTP listing using FTP_TLS - returns a list"""
        ftp = FTP_TLS(ftp_host, ftp_username, ftp_password, timeout=timeout)
        ftp.trust_server_pasv_ipv4_address = True
        try:
            ftp.cwd(ftp_path)

            # Use MLSD for detailed file info if available, fall back to NLST + SIZE
            files_with_sizes = []
            try:
                # MLSD provides detailed info including size
                all_entries = list(ftp.mlsd())

                for name, facts in all_entries:
                    if facts.get("type") == "file":
                        size_str = facts.get("size")
                        try:
                            size = int(size_str) if size_str else None
                        except (ValueError, TypeError):
                            size = None

                        # Apply glob filter if arg is provided (case-insensitive)
                        if arg is None or fnmatch.fnmatch(name.lower(), arg.lower()):
                            files_with_sizes.append((name, size))
                    elif facts.get("type") in ["dir", "cdir", "pdir"]:
                        # Skip directories
                        pass
                    else:
                        # Unknown type - include if matches filter (case-insensitive)
                        if arg is None or fnmatch.fnmatch(name.lower(), arg.lower()):
                            files_with_sizes.append((name, None))
            except error_perm:
                # MLSD not supported, fall back to NLST
                if arg:
                    file_list = ftp.nlst(arg)
                else:
                    file_list = ftp.nlst()

                # Get size for each file
                for filename in file_list:
                    try:
                        ftp.voidcmd("TYPE I")  # Set binary mode
                        size = ftp.size(filename)
                    except error_perm:
                        size = None
                    files_with_sizes.append((filename, size))

            return files_with_sizes
        finally:
            try:
                ftp.quit()
            except Exception:  # pylint: disable=broad-exception-caught
                ftp.close()

    # Run synchronous FTP operations in a thread pool and get the list
    files_list = await asyncio.to_thread(_sync_ftp_list)

    # Yield each file as an async generator

    for filename, size in files_list:
        yield FileEntry(name=filename, url=None, size=size)


def _sync_ftp_download_to_memory(
    ftp_host, ftp_username, ftp_password, ftp_path, file_name, ftp_timeout
):
    """Synchronous FTP download using FTP_TLS to BytesIO"""
    socket.setdefaulttimeout(ftp_timeout)
    file_buffer = io.BytesIO()
    ftp = FTP_TLS(ftp_host, ftp_username, ftp_password, timeout=ftp_timeout)
    ftp.trust_server_pasv_ipv4_address = True
    ftp.cwd(ftp_path)
    ftp.retrbinary("RETR " + file_name, file_buffer.write)
    ftp.quit()
    file_buffer.seek(0)  # Reset to beginning for reading
    return file_buffer.getvalue()  # Return bytes


async def fetch_file_from_ftp_to_memory(  # pylint: disable=too-many-locals
    ftp_host, ftp_username, ftp_password, ftp_path, file_name, timeout=15
):
    """Download a file from FTP server directly to memory (BytesIO)."""
    Logger.info(
        f"Downloading file from FTP server to memory: {ftp_host} "
        f", username: {ftp_username} , password: {ftp_password}, file: {file_name}"
    )

    # Manual retry logic for async functions (matching download_connection_retry parameters)
    _tries = 8
    _delay = 2
    backoff = 2
    max_delay = 5 * 60
    _timeout = timeout
    backoff_timeout = 5
    max_timeout = 300  # Cap FTP timeout at 5 minutes

    while _tries:
        try:
            file_content = await asyncio.to_thread(
                _sync_ftp_download_to_memory,
                ftp_host,
                ftp_username,
                ftp_password,
                ftp_path,
                file_name,
                _timeout,
            )
            return file_content
        except exceptions as error:
            _tries -= 1
            is_final_attempt = not _tries

            if Logger is not None:
                error_type = type(error).__name__
                error_msg = str(error)
                if len(error_msg) > 200:
                    error_msg = error_msg[:200] + "..."

                Logger.warning(
                    "%s: %s (timeout=%s, retries_left=%d, retrying in %s seconds)",
                    error_type,
                    error_msg,
                    _timeout,
                    _tries,
                    _delay,
                )

                # Only log full stack trace on final failure
                if is_final_attempt:
                    Logger.error_execption(error)

            if is_final_attempt:
                raise

            await asyncio.sleep(_delay)
            _delay = min(_delay * backoff, max_delay)
            _timeout = min(_timeout + backoff_timeout, max_timeout)

    raise ValueError("shouldn't be called!")


async def wget_file_to_memory(file_link, timeout=30):
    """Download file to memory using wget (fallback when requests fails)."""
    Logger.debug(f"trying to download file {file_link} to memory (wget fallback).")

    process = await asyncio.create_subprocess_shell(
        f"wget --timeout={timeout} --output-document=- '{file_link}'",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    std_out, std_err = await process.communicate()

    std_err_text = std_err.decode("utf-8", errors="ignore")
    Logger.debug(f"Wget stderr {std_err_text}")

    if process.returncode != 0:
        Logger.error(f"wget failed with return code {process.returncode}")
        raise FileNotFoundError(f"File download failed, stderr: {std_err_text}")

    buffer = io.BytesIO(std_out)
    buffer.seek(0)
    return buffer.getvalue()
