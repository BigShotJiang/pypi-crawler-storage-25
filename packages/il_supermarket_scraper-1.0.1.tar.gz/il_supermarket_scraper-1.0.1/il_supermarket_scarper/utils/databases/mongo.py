from ..status import _now
from .base import AbstractDataBase


PYMONGO_INSTALLED = True
try:
    import pymongo
except ImportError:
    PYMONGO_INSTALLED = False


class MongoDataBase(AbstractDataBase):
    """A class that represents a MongoDB database."""

    def __init__(self, database_name, connection_url, collection_name) -> None:
        super().__init__(database_name)
        self.myclient = None
        self.store_db = None
        self.connection_url = connection_url
        self.collection_name = collection_name

    def create_connection(self):
        """Create a connection to the MongoDB database."""
        if PYMONGO_INSTALLED:
            self.myclient = pymongo.MongoClient(
                f"{self.connection_url}/{self.collection_name}"
            )
            self.store_db = self.myclient[self.database_name]

    def insert_document(self, collection_name, document):
        """Insert a document into a MongoDB collection."""
        if self.store_db is None:
            self.create_connection()
        self.store_db[collection_name].insert_one(document)
        self._update_last_modified()

    def already_downloaded(self, collection_name, query):
        """Find a document in a MongoDB collection."""
        if self.store_db is None:
            self.create_connection()
        return self.store_db[collection_name].find_one(query)

    def _update_last_modified(self):
        """Update the last modified timestamp to current time."""
        if self.store_db is None:
            self.create_connection()
        self.store_db["_metadata"].update_one(
            {}, {"$set": {"last_modified": _now()}}, upsert=True
        )

    def get_last_modified(self):
        """Get the last modified timestamp when scraper last wrote to this database."""
        if self.store_db is None:
            self.create_connection()
        metadata = self.store_db["_metadata"].find_one({})
        if metadata and "last_modified" in metadata:
            return metadata["last_modified"]
        return None
