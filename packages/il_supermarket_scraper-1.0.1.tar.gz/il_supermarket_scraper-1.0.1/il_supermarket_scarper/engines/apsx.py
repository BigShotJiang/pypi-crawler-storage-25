from abc import ABC, abstractmethod
from il_supermarket_scarper.utils import FileEntry, Logger

from .web import WebBase


class Aspx(WebBase, ABC):
    """class for aspx scapers"""

    def __init__(
        self,
        chain,
        chain_id,
        url,
        aspx_page,
        max_threads=5,
        file_output=None,
        status_database=None,
    ):
        super().__init__(
            chain,
            chain_id,
            url,
            max_threads=max_threads,
            file_output=file_output,
            status_database=status_database,
        )
        self.aspx_page = aspx_page

    async def extract_task_from_entry(self, all_trs):
        """from the trs extract the download urls, file names, and file sizes"""

        for x in all_trs:
            try:
                download_url = self.url + self.get_href_from_entry(x)
                file_name = self.get_file_name_no_ext_from_entry(download_url)
                file_size = self.get_file_size_from_entry(x)
                yield FileEntry(name=file_name, url=download_url, size=file_size)
            except (AttributeError, KeyError, IndexError, TypeError) as e:
                Logger.warning(f"Error extracting task from entry: {e}")

    @abstractmethod
    def get_file_name_no_ext_from_entry(self, entry):
        """get the file name without extensions from entey (tr)"""

    @abstractmethod
    async def _get_all_possible_query_string_params(
        self, files_types=None, store_id=None, when_date=None
    ):
        """list all param to add to the url"""

    @abstractmethod
    def get_href_from_entry(self, entry):
        """get download link for entry (tr)"""

    @abstractmethod
    async def _build_query_url(self, query_params, base_urls):
        """build the url with the query params"""

    async def get_request_url(self, files_types=None, store_id=None, when_date=None):
        """build the request given the base url and the query params"""

        async for query_params in self._get_all_possible_query_string_params(
            files_types=files_types, store_id=store_id, when_date=when_date
        ):
            async for url in self._build_query_url(query_params, [self.url]):
                yield url
