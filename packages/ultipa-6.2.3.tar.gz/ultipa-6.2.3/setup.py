from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ultipa",
    version="6.2.3",
    description="Pure Python Ultipa Driver",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Ultipa Team",
    url="https://github.com/ultipa/gqldb-drivers",
    packages=find_packages(),
    install_requires=[
        "grpcio>=1.60.0",
        "protobuf>=4.25.0",
    ],
    extras_require={
        "dev": [
            "grpcio-tools>=1.60.0",
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-asyncio>=0.23.0",
        ]
    },
    # 3.10+ is the real lower bound: `gqldb/types/__init__.py` shadows
    # stdlib `types` during the import cascade triggered by `import gqldb`
    # on Python 3.9 (see driver audit #13). The PEP 604 `X | None`
    # annotations in `gqldb/errors.py` are handled via PEP 563 lazy
    # evaluation and work on 3.9 in isolation, but the broader import
    # chain still fails — so 3.10 is the lowest version we can honestly
    # support.
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
