"""Phase 2 dual-source default-graph cache tests (T1-T6 from
SERVER_REQUEST_GqlResponse_current_graph_REVIEW.md).

Validates the driver's `session.default_graph` cache stays in sync with
the server's authoritative `current_graph` across the cases that the
older regex-only implementation could not cover.

Server requirement: `GqlResponse.current_graph` and
`LoginResponse.current_graph` populated. Old servers (no fix) skip the
parametrize cases that require server feedback.

Run:
    pytest tests/gql_new_tests/test_current_graph_phase2.py -v

Env overrides:
    GQLDB_HOST=127.0.0.1:60063
    GQLDB_USER=admin
    GQLDB_PASSWORD=admin11
"""
from __future__ import annotations

import os
import uuid

import pytest
from gqldb import GqldbClient, GqldbConfig


HOSTS = [os.environ.get("GQLDB_HOST", "127.0.0.1:60063")]
USER = os.environ.get("GQLDB_USER", "admin")
PASSWORD = os.environ.get("GQLDB_PASSWORD", "admin11")


def _new_client() -> GqldbClient:
    c = GqldbClient(GqldbConfig(hosts=HOSTS, timeout=30))
    c.login(USER, PASSWORD)
    return c


def _cache(c: GqldbClient) -> str:
    return c._sessions.get_default_graph()


@pytest.fixture
def client():
    c = _new_client()
    yield c
    try:
        c.logout()
    except Exception:
        pass
    if hasattr(c, "close"):
        try:
            c.close()
        except Exception:
            pass


@pytest.fixture
def two_graphs(client):
    """Create two unique graphs for the test, drop on teardown."""
    suffix = uuid.uuid4().hex[:8]
    g1 = f"phase2_a_{suffix}"
    g2 = f"phase2_b_{suffix}"
    client.gql(f"CREATE GRAPH {g1}")
    client.gql(f"CREATE GRAPH {g2}")
    yield g1, g2
    # switch off both before drop (workaround for open22 #3)
    try:
        client.gql("USE GRAPH default")
    except Exception:
        pass
    for g in (g1, g2):
        try:
            client.gql(f"DROP GRAPH {g}")
        except Exception:
            pass


@pytest.fixture(scope="module")
def server_supports_phase2() -> bool:
    """Probe once per module: does the server populate response.current_graph?

    Creates a throwaway graph, USE's it, inspects the Response, then drops
    the graph. New servers populate `current_graph`; old servers leave it
    empty. Tests that exercise compound-query / multi-USE behavior skip
    when this is False (since only the response-feedback path can resolve
    those cases).
    """
    c = _new_client()
    suffix = uuid.uuid4().hex[:8]
    probe_g = f"phase2_probe_{suffix}"
    try:
        c.gql(f"CREATE GRAPH {probe_g}")
        resp = c.gql(f"USE GRAPH {probe_g}")
        supports = bool(getattr(resp, "current_graph", "") or "")
        try:
            c.gql("USE GRAPH default")
        except Exception:
            pass
        try:
            c.gql(f"DROP GRAPH {probe_g}")
        except Exception:
            pass
        return supports
    finally:
        try:
            c.logout()
        except Exception:
            pass
        if hasattr(c, "close"):
            try:
                c.close()
            except Exception:
                pass


# -----------------------------------------------------------------------------
# T1 — single-statement USE GRAPH (works on all servers)
# -----------------------------------------------------------------------------

def test_t1_single_use_graph_updates_cache(client, two_graphs):
    g1, _ = two_graphs
    client.gql(f"USE GRAPH {g1}")
    assert _cache(client) == g1, (
        f"T1: single USE GRAPH should update driver cache; "
        f"got {_cache(client)!r}, expected {g1!r}"
    )


# -----------------------------------------------------------------------------
# T2 — compound with USE GRAPH first (only server-feedback path catches)
# -----------------------------------------------------------------------------

def test_t2_compound_use_first(client, two_graphs, server_supports_phase2):
    if not server_supports_phase2:
        pytest.skip("server does not populate response.current_graph")
    g1, _ = two_graphs
    client.gql(f"USE GRAPH {g1}; SHOW GRAPHS")
    assert _cache(client) == g1, (
        f"T2: compound `USE GRAPH X; <stmt>` should update cache via "
        f"response.current_graph; got {_cache(client)!r}, expected {g1!r}"
    )


# -----------------------------------------------------------------------------
# T3 — compound with USE GRAPH last (only server-feedback path catches)
# -----------------------------------------------------------------------------

def test_t3_compound_use_last(client, two_graphs, server_supports_phase2):
    if not server_supports_phase2:
        pytest.skip("server does not populate response.current_graph")
    g1, _ = two_graphs
    client.gql(f"SHOW GRAPHS; USE GRAPH {g1}")
    assert _cache(client) == g1, (
        f"T3: compound `<stmt>; USE GRAPH X` should update cache via "
        f"response.current_graph; got {_cache(client)!r}, expected {g1!r}"
    )


# -----------------------------------------------------------------------------
# T4 — multiple USE GRAPH in one compound (last-write-wins)
# -----------------------------------------------------------------------------

def test_t4_multiple_use_last_wins(client, two_graphs, server_supports_phase2):
    if not server_supports_phase2:
        pytest.skip("server does not populate response.current_graph")
    g1, g2 = two_graphs
    client.gql(f"USE GRAPH {g1}; USE GRAPH {g2}")
    assert _cache(client) == g2, (
        f"T4: `USE GRAPH a; USE GRAPH b` should leave cache at b "
        f"(last-write-wins via response.current_graph); "
        f"got {_cache(client)!r}, expected {g2!r}"
    )


# -----------------------------------------------------------------------------
# T5 — USE GRAPH inside an active transaction is rejected (6.2.4 contract:
# server forbids switching graphs during a transaction, sidesteps the
# "rollback rule" question entirely).
# -----------------------------------------------------------------------------

def test_t5_use_inside_active_tx_rejected(client, two_graphs):
    from gqldb.errors import GqldbError
    g1, _ = two_graphs
    client.gql(f"USE GRAPH {g1}")
    client.gql("START TRANSACTION")
    try:
        with pytest.raises(GqldbError, match=r"cannot switch graph"):
            client.gql(f"USE GRAPH {g1}")
    finally:
        try:
            client.gql("ROLLBACK")
        except Exception:
            pass


# -----------------------------------------------------------------------------
# T6 — per-request graph_name override does not change session cache
# (PostgreSQL SET LOCAL semantics; query runs against the override but
# session.default_graph stays at the previous value).
# -----------------------------------------------------------------------------

def test_t6_graph_name_override_does_not_change_session(client, two_graphs):
    from gqldb.client import QueryConfig
    g1, g2 = two_graphs
    # Plant a marker only in g2 so we can prove the override actually routed there.
    client.gql(f"USE GRAPH {g2}")
    client.gql("INSERT (n:Phase2Marker {tag:'in_g2'})")
    client.gql(f"USE GRAPH {g1}")
    cache_before = _cache(client)
    assert cache_before == g1

    resp = client.gql(
        "MATCH (n:Phase2Marker) RETURN n.tag",
        QueryConfig(graph_name=g2),
    )
    # Override routed the query to g2 (saw the marker)
    tags = [r.values[0].to_python() for r in resp.rows if r.values]
    assert tags == ["in_g2"], f"override did not route to {g2!r}; rows={tags}"
    # Session cache untouched
    assert _cache(client) == cache_before, (
        f"per-request graph_name should not modify session; "
        f"cache went from {cache_before!r} to {_cache(client)!r}"
    )


# -----------------------------------------------------------------------------
# Bonus — Login seeds cache from LoginResponse.current_graph
# -----------------------------------------------------------------------------

def test_login_seeds_cache_from_response(two_graphs):
    """A fresh login with default_graph=g1 should leave driver cache at g1
    via LoginResponse.current_graph (or req fallback on older servers).
    """
    g1, _ = two_graphs
    c2 = GqldbClient(GqldbConfig(hosts=HOSTS, default_graph=g1, timeout=30))
    try:
        c2.login(USER, PASSWORD)
        assert c2._sessions.get_default_graph() == g1, (
            f"Login should seed cache to default_graph={g1!r}; "
            f"got {c2._sessions.get_default_graph()!r}"
        )
    finally:
        try:
            c2.logout()
        except Exception:
            pass
        if hasattr(c2, "close"):
            try:
                c2.close()
            except Exception:
                pass


# -----------------------------------------------------------------------------
# Bonus — DROP self-graph clears cache (Round-21 #5 / open22 #3)
# -----------------------------------------------------------------------------

def test_drop_self_clears_cache(client):
    """DROP GRAPH X where X is the cached default_graph must leave the cache
    empty. New servers do this via response.current_graph='' after drop;
    old servers via the driver-side DROP GRAPH fallback.
    """
    suffix = uuid.uuid4().hex[:8]
    g = f"phase2_drop_{suffix}"
    try:
        client.gql(f"CREATE GRAPH {g}")
        client.gql(f"USE GRAPH {g}")
        assert _cache(client) == g
        client.gql(f"DROP GRAPH {g}")
        assert _cache(client) == "", (
            f"DROP self-graph should clear cache; got {_cache(client)!r}"
        )
    except Exception:
        # best-effort cleanup
        try:
            client.gql("USE GRAPH default")
            client.gql(f"DROP GRAPH {g}")
        except Exception:
            pass
        raise
