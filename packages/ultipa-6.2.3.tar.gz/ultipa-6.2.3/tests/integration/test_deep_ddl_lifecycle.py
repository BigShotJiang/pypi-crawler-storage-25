"""Deep DDL Lifecycle integration tests."""

import time
import random
import pytest

from gqldb.client import GqldbClient, QueryConfig


@pytest.mark.integration
class TestDeepDDLLifecycle:

    @pytest.fixture(scope="class")
    def prefix(self, connected_client: GqldbClient):
        p = f"test_ddl_{int(time.time() * 1000)}"
        yield p
        try:
            connected_client.use_graph("default")
        except Exception:
            pass
        for suffix in ["_open", "_closed", "_renamed", "_trunc", "_lbl", "_elbl", "_ren", "_prop", "_idx", "_eidx", "_ft", "_cst", "_uni"]:
            try:
                connected_client.drop_graph(p + suffix, if_exists=True)
            except Exception:
                pass

    def test_graph_create_open_drop(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_open"
        connected_client.create_graph(g)
        time.sleep(0.5)
        r = connected_client.gql("SHOW GRAPHS")
        found = False
        for row in r.rows:
            if str(r.get_by_name(row, "graph_name")) == g:
                found = True
                break
        assert found, "Graph should exist"
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_graph_create_closed_drop(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_closed"
        connected_client.gql(f"CREATE GRAPH {g} {{}}")
        time.sleep(0.5)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_graph_if_not_exists(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_open"
        connected_client.create_graph(g)
        time.sleep(0.5)
        connected_client.gql(f"CREATE GRAPH IF NOT EXISTS {g}")
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_graph_duplicate_error(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_open"
        connected_client.create_graph(g)
        time.sleep(0.5)
        with pytest.raises(Exception):
            connected_client.gql(f"CREATE GRAPH {g}")
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_graph_rename(self, connected_client: GqldbClient, prefix: str):
        g1 = prefix + "_open"
        g2 = prefix + "_renamed"
        try:
            connected_client.drop_graph(g2, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g1)
        time.sleep(0.5)
        connected_client.gql(f"ALTER GRAPH {g1} RENAME TO {g2}")
        r = connected_client.gql("SHOW GRAPHS")
        found_new = False
        found_old = False
        for row in r.rows:
            name = str(r.get_by_name(row, "graph_name"))
            if name == g2:
                found_new = True
            if name == g1:
                found_old = True
        assert found_new
        assert not found_old
        connected_client.use_graph("default")
        connected_client.drop_graph(g2, if_exists=True)

    def test_graph_drop_nonexistent(self, connected_client: GqldbClient):
        with pytest.raises(Exception):
            connected_client.gql("DROP GRAPH nonexistent_xyz_999")

    def test_label_create_node(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_lbl"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.gql(f"CREATE GRAPH {g} {{}}")
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql(f"ALTER GRAPH {g} ADD NODE {{ Person ({{name STRING, age INT64}}) }}", cfg)
        connected_client.gql("INSERT (:Person {name: 'test', age: 1})", cfg)
        r = connected_client.gql("SHOW NODE LABELS", cfg)
        assert r.row_count >= 1
        connected_client.gql("MATCH (n:Person) DELETE n", cfg)
        connected_client.gql(f"ALTER GRAPH {g} DROP NODE Person", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_label_rename(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_ren"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        old_lbl = f"OldLbl{random.randint(100, 999)}"
        new_lbl = f"NewLbl{random.randint(100, 999)}"
        connected_client.gql(f"INSERT (:{old_lbl} {{name: 'test'}})", cfg)
        connected_client.gql(f"ALTER NODE {old_lbl} RENAME TO {new_lbl}", cfg)
        r = connected_client.gql("SHOW NODE LABELS", cfg)
        found_new = False
        for row in r.rows:
            if new_lbl in str(r.get_by_name(row, r.columns[0])):
                found_new = True
                break
        assert found_new, f"{new_lbl} should exist after rename"
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_index_lifecycle(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_idx"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql("INSERT (:IdxTest {name: 'test', age: 30})", cfg)
        connected_client.gql("CREATE INDEX idx_name ON NODE IdxTest (name)", cfg)
        time.sleep(1.0)
        r = connected_client.gql("SHOW NODE INDEX", cfg)
        assert r.row_count >= 1
        connected_client.gql("DROP NODE INDEX idx_name", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_index_duplicate_error(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_idx"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql("INSERT (:IdxTest {name: 'test'})", cfg)
        connected_client.gql("CREATE INDEX idx_dup ON NODE IdxTest (name)", cfg)
        time.sleep(1.0)
        with pytest.raises(Exception):
            connected_client.gql("CREATE INDEX idx_dup ON NODE IdxTest (name)", cfg)
        connected_client.gql("DROP NODE INDEX idx_dup", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_fulltext_lifecycle(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_ft"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql("INSERT (:FtTest {title: 'hello world'})", cfg)
        connected_client.gql("CREATE FULLTEXT ft_title ON NODE FtTest (title)", cfg)
        time.sleep(2.0)
        r = connected_client.gql("SHOW NODE FULLTEXT", cfg)
        assert r.row_count >= 1
        connected_client.gql("DROP NODE FULLTEXT ft_title", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_constraint_not_null(self, connected_client: GqldbClient, prefix: str):
        # ALTER NODE ADD CONSTRAINT was deprecated; use CREATE CONSTRAINT.
        g = prefix + "_cst"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.gql(f"CREATE GRAPH {g} {{}}")
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql(f"ALTER GRAPH {g} ADD NODE {{ CstTest ({{name STRING, age INT64}}) }}", cfg)
        connected_client.gql("CREATE CONSTRAINT nn_node_csttest_name FOR (n:CstTest) REQUIRE n.name IS NOT NULL", cfg)
        connected_client.gql("INSERT (:CstTest {name: 'valid', age: 30})", cfg)
        with pytest.raises(Exception):
            connected_client.gql("INSERT (:CstTest {age: 25})", cfg)
        connected_client.gql("DROP CONSTRAINT nn_node_csttest_name", cfg)
        connected_client.gql("INSERT (:CstTest {age: 20})", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_constraint_unique(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_uni"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.gql(f"CREATE GRAPH {g} {{}}")
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql(f"ALTER GRAPH {g} ADD NODE {{ UniTest ({{email STRING}}) }}", cfg)
        connected_client.gql("CREATE CONSTRAINT uq_node_unitest_email FOR (n:UniTest) REQUIRE n.email IS UNIQUE", cfg)
        connected_client.gql("INSERT (:UniTest {email: 'a@test.com'})", cfg)
        with pytest.raises(Exception):
            connected_client.gql("INSERT (:UniTest {email: 'a@test.com'})", cfg)
        connected_client.gql("DROP CONSTRAINT uq_node_unitest_email", cfg)
        connected_client.gql("INSERT (:UniTest {email: 'a@test.com'})", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    # ================================================================
    # Ported from the extended deep-coverage suite (gqldb-python-test):
    # TRUNCATE GRAPH visibility, edge index lifecycle, closed-graph edge
    # label creation, ALTER property add/drop, full-type-matrix property
    # declaration.
    # ================================================================

    def test_graph_truncate(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_trunc"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql("INSERT (:T {name: 'a'}), (:T {name: 'b'})", cfg)
        r = connected_client.gql("MATCH (n:T) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "2"
        connected_client.gql(f"TRUNCATE GRAPH {g}", cfg)
        time.sleep(2)
        # Poll for up to ~5s in case TRUNCATE visibility lags.
        cnt = None
        for _ in range(10):
            r = connected_client.gql("MATCH (n:T) RETURN count(n) AS cnt", cfg)
            cnt = str(r.get_by_name(r.rows[0], "cnt"))
            if cnt == "0":
                break
            time.sleep(0.5)
        assert cnt == "0", f"TRUNCATE GRAPH did not remove data, final count={cnt}"
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_label_create_edge(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_elbl"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.gql(f"CREATE GRAPH {g} {{}}")
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql(f"ALTER GRAPH {g} ADD NODE {{ Person ({{name STRING}}) }}", cfg)
        connected_client.gql(f"ALTER GRAPH {g} ADD EDGE {{ KNOWS ()-[{{since INT64}}]->() }}", cfg)
        connected_client.gql("INSERT (:Person {_id: 'ep1', name: 'a'}), (:Person {_id: 'ep2', name: 'b'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ep1'), (b WHERE id(b)='ep2') INSERT (a)-[:KNOWS {since: 2020}]->(b)", cfg)
        r = connected_client.gql("SHOW EDGE LABELS", cfg)
        assert r.row_count >= 1
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_property_add_drop(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_prop"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql("INSERT (:PropTest {name: 'test'})", cfg)
        connected_client.gql("ALTER NODE PropTest ADD PROPERTY {email STRING}", cfg)
        r = connected_client.gql("SHOW NODE TYPES", cfg)
        assert r.row_count >= 1
        connected_client.gql("ALTER NODE PropTest DROP PROPERTY email", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_property_various_types(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_prop"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.gql(f"CREATE GRAPH {g} {{}}")
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql(
            f"""ALTER GRAPH {g} ADD NODE {{ TypeFull ({{
                str_val STRING,
                int32_val INT32,
                int64_val INT64,
                uint32_val UINT32,
                uint64_val UINT64,
                float_val FLOAT,
                double_val DOUBLE,
                bool_val BOOL,
                datetime_val DATETIME,
                timestamp_val TIMESTAMP
            }}) }}""",
            cfg,
        )
        r = connected_client.gql("SHOW NODE TYPES", cfg)
        assert r.row_count >= 1
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)

    def test_edge_index_lifecycle(self, connected_client: GqldbClient, prefix: str):
        g = prefix + "_eidx"
        try:
            connected_client.drop_graph(g, if_exists=True)
        except Exception:
            pass
        connected_client.create_graph(g)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=g)
        connected_client.gql("INSERT (:N {_id: 'a'}), (:N {_id: 'b'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='a'), (b WHERE id(b)='b') INSERT (a)-[:REL {weight: 1.0}]->(b)", cfg)
        connected_client.gql("CREATE INDEX idx_weight ON EDGE REL (weight)", cfg)
        time.sleep(1)
        r = connected_client.gql("SHOW EDGE INDEX", cfg)
        assert r.row_count >= 1
        connected_client.gql("DROP EDGE INDEX idx_weight", cfg)
        connected_client.use_graph("default")
        connected_client.drop_graph(g, if_exists=True)
