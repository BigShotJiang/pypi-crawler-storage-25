"""Deep Edge Cases integration tests."""

import time
import pytest

from gqldb.client import GqldbClient, QueryConfig
from gqldb.errors import GqldbError


@pytest.mark.integration
class TestDeepEdgeCases:

    @pytest.fixture(scope="class")
    def test_graph(self, connected_client: GqldbClient):
        graph_name = f"test_edge_case_{int(time.time() * 1000)}"
        connected_client.create_graph(graph_name)
        time.sleep(0.5)
        yield graph_name
        try:
            connected_client.use_graph("default")
        except Exception:
            pass
        try:
            connected_client.drop_graph(graph_name, if_exists=True)
        except Exception:
            pass

    @pytest.fixture(autouse=True)
    def clean_data(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        try:
            connected_client.gql("MATCH (n) DETACH DELETE n", cfg)
        except Exception:
            pass
        yield

    # Server tightened label character rules: only a-z, A-Z, 0-9, _ allowed.
    # Backtick quoting no longer bypasses the rule (was permissive before).
    # These tests now assert the rejection.
    def test_label_hyphen(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(GqldbError, match="invalid character"):
            connected_client.gql("INSERT (:`my-label` {name: 'test'})", cfg)

    def test_label_space(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(GqldbError, match="invalid character"):
            connected_client.gql("INSERT (:`My Label` {name: 'test'})", cfg)

    def test_label_dot(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(GqldbError, match="invalid character"):
            connected_client.gql("INSERT (:`my.label` {name: 'test'})", cfg)

    def test_edge_label_hyphen(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:N {_id: 'sl1'}), (:N {_id: 'sl2'})", cfg)
        with pytest.raises(GqldbError, match="invalid character"):
            connected_client.gql("MATCH (a WHERE id(a)='sl1'), (b WHERE id(b)='sl2') INSERT (a)-[:`has-relation`]->(b)", cfg)

    def test_prop_hyphen(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:PropSpec {`my-prop`: 'value'})", cfg)
        r = connected_client.gql("MATCH (n:PropSpec) RETURN n.`my-prop` AS val", cfg)
        assert str(r.get_by_name(r.rows[0], "val")) == "value"

    def test_long_string_10k(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        s = "x" * 10000
        connected_client.gql(f"INSERT (:LongStr {{_id: 'ls1', val: '{s}'}})", cfg)
        r = connected_client.gql("MATCH (n:LongStr) WHERE id(n) = 'ls1' RETURN n.val AS val", cfg)
        assert len(str(r.get_by_name(r.rows[0], "val"))) == 10000

    def test_many_properties(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        props = "_id: 'mp1'"
        for i in range(20):
            props += f", p{i}: {i}"
        connected_client.gql(f"INSERT (:ManyProps {{{props}}})", cfg)
        r = connected_client.gql("MATCH (n:ManyProps) WHERE id(n) = 'mp1' RETURN n.p0, n.p19", cfg)
        assert r.row_count == 1

    def test_batch_200_nodes(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        parts = []
        for i in range(200):
            parts.append(f"(:Batch200 {{_id: 'b200_{i}', idx: {i}}})")
        gql = "INSERT " + ", ".join(parts)
        connected_client.gql(gql, cfg)
        r = connected_client.gql("MATCH (n:Batch200) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "200"

    def test_skip_beyond(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:SkipTest {val: 1}), (:SkipTest {val: 2})", cfg)
        r = connected_client.gql("MATCH (n:SkipTest) RETURN n.val SKIP 100", cfg)
        assert r.row_count == 0

    def test_syntax_error(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(Exception):
            connected_client.gql("INVALID GQL STATEMENT", cfg)

    def test_nonexistent_label(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:NonExistentLabel999) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"

    def test_nonexistent_property(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:ErrTest {name: 'test'})", cfg)
        r = connected_client.gql("MATCH (n:ErrTest) RETURN n.nonexistent_prop AS val", cfg)
        assert r.row_count == 1

    def test_empty_gql(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(Exception):
            connected_client.gql("", cfg)

    def test_use_nonexistent_graph(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(Exception):
            connected_client.gql("USE GRAPH nonexistent_xyz_999", cfg)

    def test_rapid_insert_delete(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        for i in range(20):
            connected_client.gql(f"INSERT (:Rapid {{_id: 'r{i}', idx: {i}}})", cfg)
        r = connected_client.gql("MATCH (n:Rapid) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "20"
        connected_client.gql("MATCH (n:Rapid) DELETE n", cfg)
        r = connected_client.gql("MATCH (n:Rapid) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"

    def test_bidirectional_edge(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:N {_id: 'bi1', name: 'A'}), (:N {_id: 'bi2', name: 'B'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='bi1'), (b WHERE id(b)='bi2') INSERT (a)-[:LINK]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='bi2'), (b WHERE id(b)='bi1') INSERT (a)-[:LINK]->(b)", cfg)
        r = connected_client.gql("MATCH (a:N)-[e:LINK]->(b:N) RETURN count(e) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "2"

    def test_case_expression(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Score {_id: 'sc1', val: 95}), (:Score {_id: 'sc2', val: 70}), (:Score {_id: 'sc3', val: 40})", cfg)
        r = connected_client.gql(
            "MATCH (n:Score) RETURN n.val AS score, "
            "CASE WHEN n.val >= 90 THEN 'A' WHEN n.val >= 60 THEN 'B' ELSE 'C' END AS grade "
            "ORDER BY score DESC", cfg)
        assert r.row_count == 3

    def test_exists_subquery(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Author {_id: 'a1', name: 'Writer'}), (:Author {_id: 'a2', name: 'NoBooks'}), (:Book {_id: 'b1', title: 'Book1'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='a1'), (b WHERE id(b)='b1') INSERT (a)-[:WROTE]->(b)", cfg)
        r = connected_client.gql("MATCH (a:Author) WHERE EXISTS { MATCH (a)-[:WROTE]->(:Book) } RETURN a.name AS name", cfg)
        assert r.row_count == 1
        assert str(r.get_by_name(r.rows[0], "name")) == "Writer"

    # ================================================================
    # Ported from the extended deep-coverage suite (gqldb-python-test):
    # extra label-name / property-name edge cases, DELETE-nonexistent as
    # no-op, oversized LIMIT, whitespace-only GQL error path.
    # ================================================================

    def test_label_start_number(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(GqldbError, match="must start with a letter"):
            connected_client.gql("INSERT (:`123label` {name: 'test'})", cfg)

    def test_prop_space(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:PropSpec {`my prop`: 'value'})", cfg)
        r = connected_client.gql("MATCH (n:PropSpec) RETURN n.`my prop` AS val", cfg)
        assert str(r.get_by_name(r.rows[0], "val")) == "value"

    def test_delete_nonexistent(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        # DELETE on a non-existent id should not error (matches 0 rows).
        connected_client.gql("MATCH (n) WHERE id(n) = 'totally_nonexistent_id_xyz' DELETE n", cfg)

    def test_large_limit(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        parts = ", ".join(f"(:LargeQ {{idx: {i}}})" for i in range(50))
        connected_client.gql(f"INSERT {parts}", cfg)
        r = connected_client.gql("MATCH (n:LargeQ) RETURN n.idx LIMIT 999999", cfg)
        assert r.row_count == 50

    def test_whitespace_gql(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        with pytest.raises(Exception):
            connected_client.gql("   ", cfg)
