"""Error definitions for GQLDB Python driver."""
from __future__ import annotations  # PEP 563 — defensive: keeps the
# `X | None` annotations below lazy-evaluated. Project minimum is now
# Python 3.10 (setup.py), where PEP 604 union syntax is native, but the
# `from __future__` import costs nothing and keeps the module importable
# on older interpreters that someone might point at it in isolation.


class GqldbError(Exception):
    """Base exception for GQLDB errors."""

    def __init__(self, message: str, code: int = 0, cause: Exception | None = None):
        super().__init__(message)
        self.code = code
        self.cause = cause


# Configuration errors
class NoHostsError(GqldbError):
    """No hosts configured."""

    def __init__(self):
        super().__init__("No hosts configured")


class InvalidTimeoutError(GqldbError):
    """Invalid timeout value."""

    def __init__(self):
        super().__init__("Invalid timeout value")


# Connection errors
class NoConnectionError(GqldbError):
    """No connection available."""

    def __init__(self):
        super().__init__("No connection available")


class ConnectionClosedError(GqldbError):
    """Connection closed."""

    def __init__(self):
        super().__init__("Connection closed")


class ConnectionFailedError(GqldbError):
    """Connection failed."""

    def __init__(self, message: str = "Connection failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class AllHostsFailedError(GqldbError):
    """All hosts failed to connect."""

    def __init__(self):
        super().__init__("All hosts failed to connect")


class HealthCheckFailedError(GqldbError):
    """Health check failed."""

    def __init__(self):
        super().__init__("Health check failed")


# Session errors
class NotLoggedInError(GqldbError):
    """Not logged in."""

    def __init__(self):
        super().__init__("Not logged in")


class LoginFailedError(GqldbError):
    """Login failed."""

    def __init__(self, message: str = "Login failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class LogoutFailedError(GqldbError):
    """Logout failed."""

    def __init__(self, message: str = "Logout failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class SessionExpiredError(GqldbError):
    """Session expired."""

    def __init__(self):
        super().__init__("Session expired")


class InvalidSessionError(GqldbError):
    """Invalid session."""

    def __init__(self):
        super().__init__("Invalid session")


# Transaction errors
class NoTransactionError(GqldbError):
    """No active transaction."""

    def __init__(self):
        super().__init__("No active transaction")


class TransactionFailedError(GqldbError):
    """Transaction failed."""

    def __init__(self, message: str = "Transaction failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class TransactionNotFoundError(GqldbError):
    """Transaction not found."""

    def __init__(self):
        super().__init__("Transaction not found")


class TransactionAlreadyOpenError(GqldbError):
    """Transaction already open."""

    def __init__(self):
        super().__init__("Transaction already open")


# Query errors
class QueryFailedError(GqldbError):
    """Query failed."""

    def __init__(self, message: str = "Query failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class QueryTimeoutError(GqldbError):
    """Query timeout."""

    def __init__(self):
        super().__init__("Query timeout")


class InvalidQueryError(GqldbError):
    """Invalid query."""

    def __init__(self, message: str = "Invalid query"):
        super().__init__(message)


class EmptyQueryError(GqldbError):
    """Empty query."""

    def __init__(self):
        super().__init__("Empty query")


# Graph errors
class GraphNotFoundError(GqldbError):
    """Graph not found."""

    def __init__(self, graph_name: str = ""):
        message = f"Graph not found: {graph_name}" if graph_name else "Graph not found"
        super().__init__(message)


class GraphExistsError(GqldbError):
    """Graph already exists."""

    def __init__(self, graph_name: str = ""):
        message = f"Graph already exists: {graph_name}" if graph_name else "Graph already exists"
        super().__init__(message)


class CreateGraphFailedError(GqldbError):
    """Create graph failed."""

    def __init__(self, message: str = "Create graph failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class DropGraphFailedError(GqldbError):
    """Drop graph failed."""

    def __init__(self, message: str = "Drop graph failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


# Data errors
class InsertFailedError(GqldbError):
    """Insert failed."""

    def __init__(self, message: str = "Insert failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class DeleteFailedError(GqldbError):
    """Delete failed."""

    def __init__(self, message: str = "Delete failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


class ExportFailedError(GqldbError):
    """Export failed."""

    def __init__(self, message: str = "Export failed", cause: Exception | None = None):
        super().__init__(message, cause=cause)


# Type errors
class InvalidTypeError(GqldbError):
    """Invalid type."""

    def __init__(self, message: str = "Invalid type"):
        super().__init__(message)


class TypeConversionError(GqldbError):
    """Type conversion failed."""

    def __init__(self, message: str = "Type conversion failed"):
        super().__init__(message)


class UnsupportedTypeError(GqldbError):
    """Unsupported type."""

    def __init__(self, type_name: str = ""):
        message = f"Unsupported type: {type_name}" if type_name else "Unsupported type"
        super().__init__(message)
