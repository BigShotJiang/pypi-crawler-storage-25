"""Connection management for GQLDB Python driver."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Dict, Optional

import grpc

from .config import GqldbConfig
from .errors import AllHostsFailedError, ConnectionClosedError, NoConnectionError


@dataclass
class Connection:
    """Represents a single gRPC connection."""
    host: str
    channel: grpc.Channel
    healthy: bool = True
    last_ping: float = 0.0
    # Consecutive unhealthy ticks observed.  We only force a reconnect
    # after several in a row, so a single transient blip during a busy
    # in-flight RPC doesn't tear the channel down and cancel every
    # pending request with "Channel closed!".  See _check_health.
    consecutive_unhealthy: int = 0


# Number of consecutive unhealthy health-check ticks required before
# forcing a reconnect (which closes the existing channel and aborts
# any in-flight RPCs on it).  Three ticks gives a busy channel
# (`CONNECTING` / `TRANSIENT_FAILURE` while server is processing a
# large concurrent batch) time to recover on its own before we
# interrupt it.
_UNHEALTHY_RECONNECT_THRESHOLD = 3


class ConnectionPool:
    """Manages a pool of connections to GQLDB servers."""

    def __init__(self, config: GqldbConfig):
        """Initialize the connection pool.

        Args:
            config: Configuration for connections.

        Raises:
            AllHostsFailedError: If all hosts fail to connect.
        """
        self._config = config
        self._connections: Dict[str, Connection] = {}
        self._lock = threading.RLock()
        self._closed = False
        self._stop_event = threading.Event()
        self._health_thread: Optional[threading.Thread] = None

        # Initialize connections to all hosts
        for host in config.hosts:
            try:
                conn = self._create_connection(host)
                self._connections[host] = conn
            except Exception:
                # Log error but continue with other hosts
                continue

        if not self._connections:
            raise AllHostsFailedError()

        # Start health check thread
        if config.health_check_interval > 0:
            self._health_thread = threading.Thread(
                target=self._health_check_loop,
                daemon=True
            )
            self._health_thread.start()

    def _create_connection(self, host: str) -> Connection:
        """Create a new gRPC connection to a host.

        Args:
            host: Host address in format "host:port".

        Returns:
            New Connection object.
        """
        options = [
            ("grpc.max_receive_message_length", self._config.max_recv_size),
            ("grpc.max_send_message_length", self._config.max_recv_size),
            ("grpc.keepalive_time_ms", 30000),
            ("grpc.keepalive_timeout_ms", 10000),
            ("grpc.keepalive_permit_without_calls", 1),
        ]

        if self._config.ssl_context:
            # Create secure channel with SSL
            credentials = grpc.ssl_channel_credentials()
            channel = grpc.secure_channel(host, credentials, options=options)
        else:
            # Create insecure channel
            channel = grpc.insecure_channel(host, options=options)

        return Connection(
            host=host,
            channel=channel,
            healthy=True,
            last_ping=time.time()
        )

    def get_connection(self) -> grpc.Channel:
        """Get a healthy connection from the pool.

        Returns:
            A gRPC channel.

        Raises:
            ConnectionClosedError: If the pool is closed.
            NoConnectionError: If no healthy connection is available.
        """
        with self._lock:
            if self._closed:
                raise ConnectionClosedError()

            # Find a healthy connection
            for conn in self._connections.values():
                if conn.healthy:
                    return conn.channel

            raise NoConnectionError()

    def get_connection_for_host(self, host: str) -> grpc.Channel:
        """Get a connection for a specific host.

        Args:
            host: Host address.

        Returns:
            A gRPC channel.

        Raises:
            NoConnectionError: If no connection is available for the host.
        """
        with self._lock:
            conn = self._connections.get(host)
            if not conn or not conn.healthy:
                raise NoConnectionError()
            return conn.channel

    def _health_check_loop(self) -> None:
        """Periodically check the health of all connections."""
        while not self._stop_event.wait(self._config.health_check_interval):
            self._check_health()

    def _check_health(self) -> None:
        """Check the health of all connections.

        Connectivity-state semantics:
          * READY / IDLE       — healthy; reset the unhealthy counter.
          * CONNECTING         — transient; the channel is healing itself,
                                 don't count toward unhealthy (also don't
                                 reset, so a stuck CONNECTING channel
                                 still trips the threshold once paired
                                 with a real failure tick).
          * TRANSIENT_FAILURE  — counts as unhealthy; force reconnect
                                 only after THRESHOLD consecutive ticks.
          * SHUTDOWN           — terminal; reconnect immediately.

        Reconnect closes the existing channel, which cancels every
        in-flight RPC on it with the gRPC client-side message
        ``"Channel closed!"``.  Under high concurrent load against a
        busy server the channel can briefly report TRANSIENT_FAILURE
        even though it is functionally fine and currently servicing
        in-flight requests — those requests must not be killed by an
        overeager health-check tick.
        """
        with self._lock:
            hosts = list(self._connections.keys())

        for host in hosts:
            with self._lock:
                conn = self._connections.get(host)
                if not conn:
                    continue

            try:
                state = conn.channel._channel.check_connectivity_state(False)

                if state in (
                    grpc.ChannelConnectivity.READY,
                    grpc.ChannelConnectivity.IDLE,
                ):
                    with self._lock:
                        conn.healthy = True
                        conn.consecutive_unhealthy = 0
                        conn.last_ping = time.time()
                    continue

                if state == grpc.ChannelConnectivity.CONNECTING:
                    # Transient — leave counter alone, don't reconnect.
                    continue

                if state == grpc.ChannelConnectivity.SHUTDOWN:
                    # Terminal — recovery requires a new channel; the
                    # in-flight RPCs on this one are doomed regardless.
                    with self._lock:
                        conn.healthy = False
                        conn.consecutive_unhealthy = (
                            _UNHEALTHY_RECONNECT_THRESHOLD
                        )
                    self._reconnect(host)
                    continue

                # TRANSIENT_FAILURE or any other non-READY state.
                with self._lock:
                    conn.consecutive_unhealthy += 1
                    should_reconnect = (
                        conn.consecutive_unhealthy
                        >= _UNHEALTHY_RECONNECT_THRESHOLD
                    )
                    if should_reconnect:
                        conn.healthy = False
                if should_reconnect:
                    self._reconnect(host)

            except Exception:
                with self._lock:
                    if conn:
                        conn.consecutive_unhealthy += 1
                        if (
                            conn.consecutive_unhealthy
                            >= _UNHEALTHY_RECONNECT_THRESHOLD
                        ):
                            conn.healthy = False

    def _reconnect(self, host: str) -> None:
        """Replace the pool's channel for ``host`` with a fresh one.

        Critically, does **not** close the old channel.  In-flight RPCs
        hold their own reference to it and continue to completion on
        that channel; Python GC releases the old channel only after
        every in-flight RPC has returned, at which point gRPC's
        reference counting performs a clean close.

        Earlier versions closed the old channel synchronously here,
        which cancelled every pending RPC with the client-side message
        ``"Channel closed!"`` — a sustained workload that briefly
        flickered the health check unhealthy would lose every in-flight
        request even though the server was happy to keep serving them.
        """
        with self._lock:
            if self._closed:
                return

            try:
                new_conn = self._create_connection(host)
                # Overwrite the pool entry.  The old Connection object
                # (and its channel) is now unreferenced by the pool;
                # in-flight RPCs still hold it alive via the executor
                # stub's bound channel.  Once those RPCs complete the
                # channel becomes garbage and gRPC closes it naturally.
                self._connections[host] = new_conn
            except Exception:
                pass

    def close(self) -> None:
        """Close all connections in the pool."""
        with self._lock:
            if self._closed:
                return

            self._closed = True
            self._stop_event.set()

            # Close all connections
            for conn in self._connections.values():
                try:
                    conn.channel.close()
                except Exception:
                    pass

            self._connections.clear()

        # Wait for health check thread
        if self._health_thread:
            self._health_thread.join(timeout=5.0)

    def healthy_host_count(self) -> int:
        """Return the number of healthy hosts.

        Returns:
            Number of healthy hosts.
        """
        with self._lock:
            return sum(1 for conn in self._connections.values() if conn.healthy)

    def hosts(self) -> list[str]:
        """Return the list of configured hosts.

        Returns:
            List of host addresses.
        """
        with self._lock:
            return list(self._connections.keys())

    @property
    def is_closed(self) -> bool:
        """Check if the pool is closed."""
        with self._lock:
            return self._closed
