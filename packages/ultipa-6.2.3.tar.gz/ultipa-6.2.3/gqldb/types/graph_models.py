"""Graph entity types for GQLDB Python driver."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class GqldbNode:
    """Graph node.

    `_id` and `_uuid` semantics (gqldb 6.1.147+):

      - ``id`` is the user-facing identifier — user-provided string or
        the system auto-generated form. Use this when round-tripping
        identifiers through user code or external systems.
      - ``uuid`` is the system numeric ID (uint64) formatted as decimal.
        Stable, opaque, always available. Use this when you need a
        stable internal handle: cache keys, log correlation, dedup
        hashes. Treated as a string here to avoid uint64 precision
        loss on platforms with 53-bit float numerics.

    ``uuid`` is empty when talking to a pre-6.1.147 server (the wire
    format had no InternalID trailer). Fall back to ``id`` for
    identity in that case.
    """
    id: str = ""
    uuid: str = ""
    labels: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GqldbEdge:
    """Graph edge.

    See :class:`GqldbNode` for the ``id`` / ``uuid`` semantics.
    """
    id: str = ""
    uuid: str = ""
    label: str = ""
    from_node_id: str = ""
    to_node_id: str = ""
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GqldbPath:
    """Graph path consisting of nodes and edges."""
    nodes: List[GqldbNode] = field(default_factory=list)
    edges: List[GqldbEdge] = field(default_factory=list)


@dataclass
class GqldbError:
    """Error value from TRY/CATCH handling."""
    code: int = 0
    message: str = ""


@dataclass
class NodeData:
    """Data for a node to be inserted."""
    id: str = ""  # Optional custom node ID (if empty, auto-generated)
    labels: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EdgeData:
    """Data for an edge to be inserted."""
    id: str = ""  # Optional custom edge ID; requires EDGE_ID enabled on the target graph (if empty, auto-generated)
    label: str = ""
    from_node_id: str = ""
    to_node_id: str = ""
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GraphInfo:
    """Information about a graph."""
    name: str
    graph_type: GraphType
    node_count: int
    edge_count: int
    description: str


@dataclass
class TransactionInfo:
    """Information about a transaction."""
    transaction_id: int
    session_id: int
    graph_name: str
    read_only: bool
    created_at: int
    duration_ms: int
    internal_tx_id: str


@dataclass
class TransactionRow:
    """One row from `SHOW TRANSACTIONS`.

    Mirrors the server-side schema (5 columns) introduced by the
    transaction-branch in 6.1.x. The ``session_id`` field is empty when
    the connecting driver has not surfaced an explicit
    ``x-ultipa-session-id`` and the server has not yet auto-derived one
    from peer info — see TRANSACTIONS_DRIVER_GUIDE.md §3.1.
    """
    transaction_id: str
    status: str
    read_only: bool
    start_time: str
    session_id: str


@dataclass
class ASTCacheStats:
    """AST cache statistics."""
    hits: int
    misses: int
    evictions: int
    entries: int
    hit_rate: float


@dataclass
class PlanCacheStats:
    """Plan cache statistics."""
    size: int
    capacity: int
    hits: int
    misses: int
    hit_rate: float


@dataclass
class CacheStats:
    """Combined cache statistics."""
    ast_stats: Optional[ASTCacheStats] = None
    plan_stats: Optional[PlanCacheStats] = None


@dataclass
class Statistics:
    """Database statistics."""
    node_count: int
    edge_count: int
    label_counts: Dict[str, int] = field(default_factory=dict)
    edge_label_counts: Dict[str, int] = field(default_factory=dict)


@dataclass
class ExportedNode:
    """A node exported from the database."""
    id: str
    labels: List[str]
    properties: Dict[str, Any]


@dataclass
class ExportedEdge:
    """An edge exported from the database."""
    id: str
    label: str
    from_node_id: str
    to_node_id: str
    properties: Dict[str, Any]
