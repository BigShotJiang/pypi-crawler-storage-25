"""Specialized data types for GQLDB Python driver."""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List


@dataclass
class Point:
    """2D geographic point.

    Primary fields are ``latitude`` and ``longitude`` (WGS-84 semantics
    that match how the server validates POINT bounds:
    longitude ∈ [-180, 180], latitude ∈ [-90, 90]).

    For symmetry with ``Point3D`` and cartesian-style code, ``x`` and ``y``
    are exposed as aliases:

        x = longitude   (typically the "east-west" axis)
        y = latitude    (typically the "north-south" axis)

    Both forms read/write the same storage:

        p = Point(latitude=39.9, longitude=116.4)
        p.x          # 116.4 (= longitude)
        p.y          # 39.9  (= latitude)
    """
    latitude: float
    longitude: float

    @property
    def x(self) -> float:
        """Alias for ``longitude`` — matches the Point3D x/y/z convention."""
        return self.longitude

    @property
    def y(self) -> float:
        """Alias for ``latitude`` — matches the Point3D x/y/z convention."""
        return self.latitude


@dataclass
class Point3D:
    """3D point (Cartesian semantics — no bounds applied by the server).

    Primary fields are ``x``, ``y``, ``z``. For symmetry with the
    geographic ``Point``, the first two axes are also exposed as
    ``longitude`` (= x) and ``latitude`` (= y); the third axis is
    additionally exposed as ``height`` (= z) for geographic-3D readers.

    The server does NOT enforce geographic bounds on Point3D — `x` and
    `y` may legitimately exceed lon/lat ranges. See open23.md #20 for
    server-side handling of this divergence.
    """
    x: float
    y: float
    z: float

    @property
    def longitude(self) -> float:
        """Alias for ``x`` — for geographic-style readers. Note: unlike
        ``Point``, the server does NOT enforce [-180, 180] bounds here."""
        return self.x

    @property
    def latitude(self) -> float:
        """Alias for ``y`` — for geographic-style readers. Note: unlike
        ``Point``, the server does NOT enforce [-90, 90] bounds here."""
        return self.y

    @property
    def height(self) -> float:
        """Alias for ``z`` — for geographic-3D (lon/lat/altitude) readers."""
        return self.z


@dataclass
class GqldbDecimal:
    """High-precision decimal number."""
    value: str


@dataclass
class GqldbLocalDateTime:
    """Local date-time without timezone, stored as components."""
    year: int
    month: int  # 1-12
    day: int  # 1-31
    hour: int  # 0-23
    minute: int  # 0-59
    second: int  # 0-59
    nanosecond: int = 0  # 0-999999999

    def to_datetime(self) -> datetime:
        """Convert to a datetime (no timezone).

        The returned datetime uses the stored components directly.
        Microsecond precision only (nanoseconds are truncated to microseconds).
        """
        return datetime(
            self.year, self.month, self.day,
            self.hour, self.minute, self.second,
            self.nanosecond // 1000,
        )

    def __str__(self) -> str:
        """Return ISO 8601 format without timezone (e.g., '2024-06-15T14:30:00')."""
        dt = self.to_datetime()
        if dt.microsecond:
            return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond:06d}"
        return dt.strftime("%Y-%m-%dT%H:%M:%S")


@dataclass
class GqldbZonedDateTime:
    """Date-time with timezone offset, stored as components."""
    year: int
    month: int  # 1-12
    day: int  # 1-31
    hour: int  # 0-23
    minute: int  # 0-59
    second: int  # 0-59
    nanosecond: int = 0  # 0-999999999
    offset_minutes: int = 0  # UTC offset in minutes (signed)

    def to_datetime(self) -> datetime:
        """Convert to a timezone-aware datetime.

        The returned datetime uses the stored components with the timezone offset applied.
        Microsecond precision only (nanoseconds are truncated to microseconds).
        """
        from datetime import timedelta
        tz = timezone(timedelta(minutes=self.offset_minutes))
        return datetime(
            self.year, self.month, self.day,
            self.hour, self.minute, self.second,
            self.nanosecond // 1000,
            tzinfo=tz,
        )


@dataclass
class GqldbDate:
    """Date without time."""
    year: int
    month: int  # 1-12
    day: int  # 1-31


@dataclass
class GqldbLocalTime:
    """Local time without timezone."""
    hour: int
    minute: int
    second: int
    nanosecond: int


@dataclass
class GqldbZonedTime:
    """Time with timezone offset."""
    hour: int
    minute: int
    second: int
    nanosecond: int
    offset_minutes: int


@dataclass
class YearToMonth:
    """Year-month interval."""
    months: int  # total months (can be negative)


@dataclass
class DayToSecond:
    """Day-second interval."""
    seconds: int
    nanoseconds: int


@dataclass
class Vector:
    """Float32 vector for embeddings.

    ``len(vector)`` returns the dimension; iteration yields the float
    components in order.  The server-side functions ``size(VECTOR)`` and
    ``ai.vector_dim(VECTOR)`` return the same value over the wire — these
    Python conveniences mean the user doesn't have to round-trip a GQL
    query just to read a vector's dimension.
    """
    values: List[float] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.values)

    def __iter__(self):
        return iter(self.values)


@dataclass
class GqldbTable:
    """Table data with columns and rows."""
    columns: List[str] = field(default_factory=list)
    rows: List[List] = field(default_factory=list)
    column_types: List[int] = field(default_factory=list)


@dataclass
class ComputeTopologyResult:
    """Result of wait_for_compute_topology operation."""
    ready: bool
    message: str
