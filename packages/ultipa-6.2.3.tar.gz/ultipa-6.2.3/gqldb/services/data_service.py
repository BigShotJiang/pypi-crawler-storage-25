"""Data service handles node and edge insert/delete/export operations."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Callable, List, Optional, Tuple

import grpc

if TYPE_CHECKING:
    from ..response import (
        ExportChunk,
        ExportConfig,
        ExportEdgesResult,
        ExportNodesResult,
        InsertEdgesResult,
        InsertNodesResult,
    )
    from ..types import (
        BulkCreateEdgesOptions,
        BulkCreateNodesOptions,
        EdgeData,
        NodeData,
    )
    from .service_context import ServiceContext


# Minimum server version that supports `InsertMode.UPSERT` on the bulk-import
# RPCs. A 6.1.148 or older server silently downgrades unknown enum values to
# the zero-default (Normal), which surfaces to the user as a confusing
# "duplicate _id" error. We probe the version recorded at login time and
# fail fast with a clear message instead.
#
# See `GQLDB-6.1.149-DRIVER-AND-TEST-HANDOFF-2026-05-05.md` (Test plan section D).
_UPSERT_MIN_VERSION: Tuple[int, int, int] = (6, 1, 149)


def _parse_version(s: str) -> Tuple[int, int, int]:
    """Extract the first major.minor.patch triple from a server version string.

    Searches anywhere in the string (not anchored to start) so prefixes like
    ``gqldb-grpc `` in ``"gqldb-grpc 6.1.154 (core v1.0.206)"`` don't defeat
    the parse. Returns (0, 0, 0) when no triple is found (treated as
    "unknown / pre-6.1.149").
    """
    if not s:
        return (0, 0, 0)
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", s)
    if not m:
        return (0, 0, 0)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)))


class DataService:
    """Data service for inserting, deleting, and exporting graph data."""

    def __init__(self, ctx: ServiceContext):
        self.ctx = ctx
        self._stub = None

    def _get_stub(self):
        if self._stub is None:
            from ..proto import gqldb_pb2_grpc
            channel = self.ctx.get_channel()
            self._stub = gqldb_pb2_grpc.DataServiceStub(channel)
        return self._stub

    def _require_upsert_server_support(self, mode_value: int) -> None:
        """Raise if `mode` is UPSERT and the connected server is too old.

        InsertType.UPSERT (proto value 2) requires server >= 6.1.149.
        Older servers ignore the unknown enum value and treat it as Normal,
        producing a confusing duplicate-_id error on the very write the user
        meant to merge.

        Server >= 6.1.154 reports the real version in
        ``LoginResponse.server_version`` (e.g. ``"gqldb-grpc 6.1.154 ..."``).
        Older servers either return a placeholder ``"1.0.0"`` or leave the
        field empty — both are now treated as "definitely older than
        6.1.149" and rejected. (Earlier versions of this gate let those
        cases pass through; that workaround was removed once 6.1.154+
        started populating the field correctly.)
        """
        from ..errors import GqldbError
        from ..types.convenience import InsertType

        if mode_value != int(InsertType.UPSERT):
            return
        session = self.ctx.sessions.get_session()
        server_ver = session.server_version if session and session.server_version else ""
        parsed = _parse_version(server_ver)
        if parsed < _UPSERT_MIN_VERSION:
            required = ".".join(str(x) for x in _UPSERT_MIN_VERSION)
            raise GqldbError(
                f"InsertType.UPSERT requires server >= {required}, "
                f"connected server reports {server_ver or 'unknown'}"
            )

    def insert_nodes(
        self,
        graph_name: str,
        nodes: List[NodeData],
        options: Optional[BulkCreateNodesOptions],
        bulk_import_session_id: str
    ) -> InsertNodesResult:
        from ..errors import GqldbError
        from ..proto import gqldb_pb2
        from ..response import InsertNodesResult
        from ..types import TypedValue

        self._require_upsert_server_support(int(options.mode) if options else 0)
        try:
            pb_nodes = []
            for node in nodes:
                pb_props = {}
                for k, v in node.properties.items():
                    tv = TypedValue.from_value(v)
                    pb_props[k] = gqldb_pb2.TypedValue(
                        type=tv.type.value,
                        data=tv.data,
                        is_null=tv.is_null
                    )
                pb_nodes.append(gqldb_pb2.NodeData(
                    id=node.id if node.id else "",
                    labels=node.labels,
                    properties=pb_props
                ))

            request = gqldb_pb2.InsertNodesRequest(
                graph_name=graph_name,
                nodes=pb_nodes,
                bulk_import_session_id=bulk_import_session_id
            )
            # ALWAYS set options (even when None) to avoid deprecated bulk operations error.
            # Mode is the proto-level enum; map from InsertType (driver-level)
            # via _insert_type_to_proto_mode below — both have aligned int values.
            request.options.CopyFrom(gqldb_pb2.BulkCreateNodesOptions(
                mode=int(options.mode) if options else 0
            ))

            metadata = self.ctx.get_session_metadata()
            response = self._get_stub().InsertNodes(
                request, metadata=metadata, timeout=self.ctx.config.timeout
            )
            return InsertNodesResult(
                success=response.success,
                node_ids=list(response.node_ids),
                node_count=response.node_count,
                message=response.message
            )
        except grpc.RpcError as e:
            raise GqldbError(f"Insert nodes failed: {e.details()}", cause=e) from None

    def insert_edges(
        self,
        graph_name: str,
        edges: List[EdgeData],
        options: Optional[BulkCreateEdgesOptions],
        bulk_import_session_id: str
    ) -> InsertEdgesResult:
        from ..errors import GqldbError
        from ..proto import gqldb_pb2
        from ..response import InsertEdgesResult
        from ..types import TypedValue

        self._require_upsert_server_support(int(options.mode) if options else 0)
        try:
            pb_edges = []
            for edge in edges:
                pb_props = {}
                for k, v in edge.properties.items():
                    tv = TypedValue.from_value(v)
                    pb_props[k] = gqldb_pb2.TypedValue(
                        type=tv.type.value,
                        data=tv.data,
                        is_null=tv.is_null
                    )
                pb_edges.append(gqldb_pb2.EdgeData(
                    id=edge.id,
                    label=edge.label,
                    from_node_id=edge.from_node_id,
                    to_node_id=edge.to_node_id,
                    properties=pb_props
                ))

            request = gqldb_pb2.InsertEdgesRequest(
                graph_name=graph_name,
                edges=pb_edges,
                bulk_import_session_id=bulk_import_session_id
            )
            # ALWAYS set options (even when None) to avoid deprecated bulk operations error
            request.options.CopyFrom(gqldb_pb2.BulkCreateEdgesOptions(
                skip_invalid_nodes=options.skip_invalid_nodes if options else False,
                mode=int(options.mode) if options else 0
            ))

            metadata = self.ctx.get_session_metadata()
            response = self._get_stub().InsertEdges(
                request, metadata=metadata, timeout=self.ctx.config.timeout
            )
            return InsertEdgesResult(
                success=response.success,
                edge_ids=list(response.edge_ids),
                edge_count=response.edge_count,
                message=response.message,
                skipped_count=response.skipped_count
            )
        except grpc.RpcError as e:
            raise GqldbError(f"Insert edges failed: {e.details()}", cause=e) from None

    # delete_nodes / delete_edges no longer go through the proto-level
    # DeleteNodes / DeleteEdges RPCs (those proto methods are being
    # removed server-side). The public delete API lives on GqldbClient
    # as delete_nodes_by_ids / delete_nodes_by_condition /
    # delete_edges_by_ids / delete_edges_by_condition, which emit GQL
    # and return a full Response.

    def export(
        self,
        config: ExportConfig,
        callback: Optional[Callable[[ExportChunk], None]]
    ) -> None:
        """Export graph data in JSON Lines format (streaming).

        Args:
            config: Export configuration.
            callback: Callback for each exported chunk.

        Raises:
            GqldbError: If operation fails.
        """
        from ..errors import GqldbError
        from ..proto import gqldb_pb2
        from ..response import ExportChunk, ExportStats

        try:
            request = gqldb_pb2.ExportRequest(
                graph_name=config.graph_name,
                batch_size=config.batch_size,
                export_nodes=config.export_nodes,
                export_edges=config.export_edges,
                node_labels=config.node_labels or [],
                edge_labels=config.edge_labels or [],
                include_metadata=config.include_metadata
            )
            metadata = self.ctx.get_session_metadata()
            stream = self._get_stub().Export(
                request, metadata=metadata, timeout=self.ctx.config.timeout
            )

            for response in stream:
                stats = None
                if response.HasField('stats'):
                    stats = ExportStats(
                        nodes_exported=response.stats.nodes_exported,
                        edges_exported=response.stats.edges_exported,
                        bytes_written=response.stats.bytes_written,
                        duration_ms=response.stats.duration_ms
                    )

                chunk = ExportChunk(
                    data=response.data,
                    is_final=response.is_final,
                    stats=stats
                )

                if callback:
                    callback(chunk)

                if response.is_final:
                    break

        except grpc.RpcError as e:
            raise GqldbError(f"Export failed: {e.details()}", cause=e) from None

    def export_nodes(
        self,
        graph_name: str,
        labels: Optional[List[str]],
        limit: int,
        callback: Optional[Callable[[ExportNodesResult], None]]
    ) -> None:
        """Stream nodes from a graph.

        Deprecated: Use export() with ExportConfig instead.
        """
        import warnings
        warnings.warn(
            "export_nodes is deprecated, use export() with ExportConfig instead",
            DeprecationWarning,
            stacklevel=2
        )

        from ..errors import GqldbError
        from ..proto import gqldb_pb2
        from ..response import ExportedNode, ExportNodesResult
        from ..types import PropertyType, TypedValue

        try:
            request = gqldb_pb2.ExportNodesRequest(
                graph_name=graph_name,
                labels=labels or [],
                limit=limit
            )
            metadata = self.ctx.get_session_metadata()
            stream = self._get_stub().ExportNodes(
                request, metadata=metadata, timeout=self.ctx.config.timeout
            )

            for response in stream:
                nodes = []
                for pb_node in response.nodes:
                    props = {}
                    for k, v in pb_node.properties.items():
                        tv = TypedValue(
                            type=PropertyType(v.type),
                            data=v.data,
                            is_null=v.is_null
                        )
                        props[k] = tv.to_python()
                    nodes.append(ExportedNode(
                        id=pb_node.id,
                        labels=list(pb_node.labels),
                        properties=props
                    ))

                result = ExportNodesResult(nodes=nodes, has_more=response.has_more)
                if callback:
                    callback(result)
        except grpc.RpcError as e:
            raise GqldbError(f"Export nodes failed: {e.details()}", cause=e) from None

    def export_edges(
        self,
        graph_name: str,
        labels: Optional[List[str]],
        limit: int,
        callback: Optional[Callable[[ExportEdgesResult], None]]
    ) -> None:
        """Stream edges from a graph.

        Deprecated: Use export() with ExportConfig instead.
        """
        import warnings
        warnings.warn(
            "export_edges is deprecated, use export() with ExportConfig instead",
            DeprecationWarning,
            stacklevel=2
        )

        from ..errors import GqldbError
        from ..proto import gqldb_pb2
        from ..response import ExportedEdge, ExportEdgesResult
        from ..types import PropertyType, TypedValue

        try:
            request = gqldb_pb2.ExportEdgesRequest(
                graph_name=graph_name,
                labels=labels or [],
                limit=limit
            )
            metadata = self.ctx.get_session_metadata()
            stream = self._get_stub().ExportEdges(
                request, metadata=metadata, timeout=self.ctx.config.timeout
            )

            for response in stream:
                edges = []
                for pb_edge in response.edges:
                    props = {}
                    for k, v in pb_edge.properties.items():
                        tv = TypedValue(
                            type=PropertyType(v.type),
                            data=v.data,
                            is_null=v.is_null
                        )
                        props[k] = tv.to_python()
                    edges.append(ExportedEdge(
                        id=pb_edge.id,
                        label=pb_edge.label,
                        from_node_id=pb_edge.from_node_id,
                        to_node_id=pb_edge.to_node_id,
                        properties=props
                    ))

                result = ExportEdgesResult(edges=edges, has_more=response.has_more)
                if callback:
                    callback(result)
        except grpc.RpcError as e:
            raise GqldbError(f"Export edges failed: {e.details()}", cause=e) from None
