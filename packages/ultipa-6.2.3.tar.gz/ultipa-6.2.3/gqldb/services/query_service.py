"""Query service handles GQL query execution."""

from __future__ import annotations

import re
import time
from typing import TYPE_CHECKING, Callable, Optional

import grpc

# Match a SINGLE `USE GRAPH <ident>` statement (case-insensitive) with optional
# trailing whitespace and semicolons. Compound queries do not match.
_USE_GRAPH_RE = re.compile(r'^\s*USE\s+GRAPH\s+(\S+?)\s*;*\s*$', re.IGNORECASE)


def _encode_parameters(params):
    """Encode a ``{name: python_value}`` mapping into the proto
    ``repeated Parameter`` list. Values pass through ``TypedValue.from_value``
    so any Python type the driver already encodes for INSERT (scalars,
    bytes, lists, maps, Vector, Point/Point3D, temporals, GqldbDecimal, …)
    is accepted as a query parameter.

    Returns an empty list when params is None or empty — protobuf treats
    an empty repeated field as if it were not set.
    """
    if not params:
        return []
    from ..proto import gqldb_pb2
    from ..types import TypedValue
    out = []
    for name, value in params.items():
        tv = TypedValue.from_value(value)
        out.append(gqldb_pb2.Parameter(
            name=name,
            value=gqldb_pb2.TypedValue(
                type=tv.type.value if hasattr(tv.type, "value") else int(tv.type),
                data=tv.data,
                is_null=tv.is_null,
            ),
        ))
    return out

if TYPE_CHECKING:
    from ..client import QueryConfig
    from ..response import Response
    from .service_context import ServiceContext


class QueryService:
    """Query service for executing GQL queries."""

    def __init__(self, ctx: ServiceContext):
        """Initialize query service.

        Args:
            ctx: Service context with shared dependencies
        """
        self.ctx = ctx
        self._stub = None
        self._stub_channel = None

    def _calculate_timeout(self, config: Optional[QueryConfig] = None) -> int:
        """Calculate timeout with the following priority:
        1. QueryConfig.timeout (highest priority) - explicitly specified timeout
        2. gRPC context deadline (medium priority) - remaining time from context deadline
        3. client.config.timeout (default) - default timeout from client config

        Args:
            config: Optional query configuration

        Returns:
            Timeout in seconds
        """
        from ..client import QueryConfig as QC
        cfg = config or QC()

        # Priority 1: Use explicitly specified timeout from QueryConfig
        if cfg.timeout and cfg.timeout > 0:
            return cfg.timeout

        # Priority 2: Try to get deadline from gRPC context (if available)
        # Note: This requires the caller to pass a context with deadline
        # For now, we skip this as Python SDK doesn't expose context parameter yet

        # Priority 3: Use default timeout from client config
        return self.ctx.config.timeout

    def _get_stub(self):
        """Get or initialize query stub."""
        from ..proto import gqldb_pb2_grpc

        channel = self.ctx.get_channel()
        if self._stub is None or self._stub_channel is not channel:
            self._stub = gqldb_pb2_grpc.QueryServiceStub(channel)
            self._stub_channel = channel
        return self._stub

    def gql(self, query: str, config: Optional[QueryConfig] = None) -> Response:
        """Execute a GQL query and return the result.

        Falls back to GqlStream + client-side aggregation when the server
        rejects the result set as too large for non-streaming RPC
        (RESOURCE_EXHAUSTED with "use streaming API" detail).

        Args:
            query: GQL query string
            config: Optional query configuration

        Returns:
            Query response

        Raises:
            EmptyQueryError: If query is empty
            GqldbError: If query fails
        """
        from ..client import QueryConfig as QC
        from ..errors import EmptyQueryError, GqldbError
        from ..proto import gqldb_pb2
        from .converters import convert_gql_response

        if not query:
            raise EmptyQueryError()

        session = self.ctx.sessions.get_session()
        cfg = config or QC()
        timeout = self._calculate_timeout(config)

        try:
            # Handle graph name with priority: config > session > client config
            graph_name = cfg.graph_name
            if not graph_name:
                graph_name = self.ctx.sessions.get_default_graph()
            if not graph_name:
                graph_name = self.ctx.config.default_graph

            request = gqldb_pb2.GqlRequest(
                gql=query,
                graph_name=graph_name or '',
                session_id=session.id if session else 0,
                transaction_id=cfg.transaction_id,
                timeout=timeout,
                read_only=cfg.read_only,
                max_path_results=cfg.max_path_results,
                parameters=_encode_parameters(cfg.parameters),
            )

            metadata = self.ctx.get_session_metadata()
            proto_response = self._get_stub().Gql(
                request,
                metadata=metadata,
                timeout=timeout
            )

            self.ctx.update_activity()

            # Phase 2 dual-source cache update: prefer the server's
            # authoritative `current_graph` (covers compound queries, multiple
            # embedded `USE GRAPH`, and last-write-wins) and fall back to the
            # strict client-side regex / DROP GRAPH detection for older servers
            # that don't populate the field. The fallback paths stay until the
            # minimum-supported server version bumps to one that always
            # populates current_graph (Phase 3, fallbacks deleted at next major).
            server_current = getattr(proto_response, 'current_graph', '') or ''
            if server_current:
                self.ctx.sessions.set_default_graph(server_current)
            else:
                m = _USE_GRAPH_RE.match(query)
                if m:
                    # Compound queries that merely *start* with `USE GRAPH`
                    # (e.g. `USE GRAPH g1; SHOW EDGE_ID STATUS`) must NOT
                    # poison the default-graph state — the previous
                    # prefix-match logic captured everything after `USE GRAPH`
                    # and broke every subsequent gql() call.
                    self.ctx.sessions.set_default_graph(m.group(1))
                else:
                    stripped = query.strip()
                    upper = stripped.upper()
                    if upper.startswith('DROP GRAPH'):
                        # Round-21 #5: a successful DROP GRAPH X must clear our
                        # cached default_graph if it pointed at X. New servers
                        # handle this authoritatively via current_graph
                        # (returns "" after self-drop) — this branch only
                        # fires on older servers without the field.
                        rest = stripped[len('DROP GRAPH'):].strip()
                        if rest.upper().startswith('IF EXISTS'):
                            rest = rest[len('IF EXISTS'):].strip()
                        dropped = rest.rstrip(';').strip().strip('`"\'')
                        current = self.ctx.sessions.get_default_graph()
                        if dropped and current and dropped == current:
                            self.ctx.sessions.set_default_graph('')

            return convert_gql_response(proto_response)
        except grpc.RpcError as e:
            if (
                e.code() == grpc.StatusCode.RESOURCE_EXHAUSTED
                and "use streaming API" in (e.details() or "")
            ):
                return self._gql_stream_collect(query, config)
            raise GqldbError(f"Query failed: {e.details()}", cause=e) from None

    def _gql_stream_collect(
        self, query: str, config: Optional[QueryConfig] = None
    ) -> Response:
        """Run GqlStream and aggregate chunks into a single Response.

        Used as fallback from gql() when the server rejects the result set
        as too large for non-streaming RPC.
        """
        from ..response import Response

        chunks: list = []
        self.gql_stream(query, config, callback=chunks.append)

        if not chunks:
            return Response()

        merged = Response(
            columns=chunks[0].columns,
            rows=[],
            warnings=[],
            rows_affected=0,
        )
        for chunk in chunks:
            merged.rows.extend(chunk.rows)
            merged.warnings.extend(chunk.warnings)
            if chunk.rows_affected:
                merged.rows_affected = chunk.rows_affected
        # Server populates timing / current_graph only on the final batch.
        final = chunks[-1]
        merged.current_graph = final.current_graph
        merged.time_cost_ns = final.time_cost_ns
        merged.disk_cost_ns = final.disk_cost_ns
        merged.compute_cost_ns = final.compute_cost_ns
        merged.row_count = len(merged.rows)
        return merged

    def gql_stream(
        self,
        query: str,
        config: Optional[QueryConfig] = None,
        callback: Optional[Callable[[Response], None]] = None
    ) -> None:
        """Execute a GQL query and stream the results.

        Args:
            query: GQL query string
            config: Optional query configuration
            callback: Callback function for each response chunk

        Raises:
            EmptyQueryError: If query is empty
            GqldbError: If query fails
        """
        from ..client import QueryConfig as QC
        from ..errors import EmptyQueryError, GqldbError
        from ..proto import gqldb_pb2
        from .converters import convert_gql_response

        if not query:
            raise EmptyQueryError()

        session = self.ctx.sessions.get_session()
        cfg = config or QC()
        timeout = self._calculate_timeout(config)

        try:
            # Handle graph name with priority: config > session > client config
            graph_name = cfg.graph_name
            if not graph_name:
                graph_name = self.ctx.sessions.get_default_graph()
            if not graph_name:
                graph_name = self.ctx.config.default_graph

            request = gqldb_pb2.GqlRequest(
                gql=query,
                graph_name=graph_name or '',
                session_id=session.id if session else 0,
                transaction_id=cfg.transaction_id,
                timeout=timeout,
                read_only=cfg.read_only,
                max_path_results=cfg.max_path_results,
                parameters=_encode_parameters(cfg.parameters),
            )

            metadata = self.ctx.get_session_metadata()
            stream = self._get_stub().GqlStream(
                request,
                metadata=metadata,
                timeout=timeout
            )

            for proto_response in stream:
                self.ctx.update_activity()
                response = convert_gql_response(proto_response)
                if callback:
                    callback(response)
        except grpc.RpcError as e:
            raise GqldbError(f"Stream query failed: {e.details()}", cause=e) from None

    def explain(self, query: str, config: Optional[QueryConfig] = None) -> str:
        """Return the execution plan for a query.

        Args:
            query: GQL query string
            config: Optional query configuration

        Returns:
            Execution plan string

        Raises:
            EmptyQueryError: If query is empty
            GqldbError: If explain fails
        """
        from ..client import QueryConfig as QC
        from ..errors import EmptyQueryError, GqldbError
        from ..proto import gqldb_pb2

        if not query:
            raise EmptyQueryError()

        session = self.ctx.sessions.get_session()
        cfg = config or QC()
        timeout = self._calculate_timeout(config)

        try:
            # Handle graph name with priority: config > session > client config
            graph_name = cfg.graph_name
            if not graph_name:
                graph_name = self.ctx.sessions.get_default_graph()
            if not graph_name:
                graph_name = self.ctx.config.default_graph

            request = gqldb_pb2.GqlRequest(
                gql=query,
                graph_name=graph_name or '',
                session_id=session.id if session else 0,
                transaction_id=cfg.transaction_id,
                timeout=timeout,
                read_only=cfg.read_only,
                max_path_results=cfg.max_path_results,
                parameters=_encode_parameters(cfg.parameters),
            )

            metadata = self.ctx.get_session_metadata()
            response = self._get_stub().Explain(
                request,
                metadata=metadata,
                timeout=timeout
            )

            return response.plan
        except grpc.RpcError as e:
            raise GqldbError(f"Explain failed: {e.details()}", cause=e) from None

    def profile(self, query: str, config: Optional[QueryConfig] = None) -> str:
        """Execute a query with profiling and return statistics.

        Args:
            query: GQL query string
            config: Optional query configuration

        Returns:
            Profiling statistics string

        Raises:
            EmptyQueryError: If query is empty
            GqldbError: If profile fails
        """
        from ..client import QueryConfig as QC
        from ..errors import EmptyQueryError, GqldbError
        from ..proto import gqldb_pb2

        if not query:
            raise EmptyQueryError()

        session = self.ctx.sessions.get_session()
        cfg = config or QC()
        timeout = self._calculate_timeout(config)

        try:
            # Handle graph name with priority: config > session > client config
            graph_name = cfg.graph_name
            if not graph_name:
                graph_name = self.ctx.sessions.get_default_graph()
            if not graph_name:
                graph_name = self.ctx.config.default_graph

            request = gqldb_pb2.GqlRequest(
                gql=query,
                graph_name=graph_name or '',
                session_id=session.id if session else 0,
                transaction_id=cfg.transaction_id,
                timeout=timeout,
                read_only=cfg.read_only,
                max_path_results=cfg.max_path_results,
                parameters=_encode_parameters(cfg.parameters),
            )

            metadata = self.ctx.get_session_metadata()
            response = self._get_stub().Profile(
                request,
                metadata=metadata,
                timeout=timeout
            )

            return response.profile
        except grpc.RpcError as e:
            raise GqldbError(f"Profile failed: {e.details()}", cause=e) from None
