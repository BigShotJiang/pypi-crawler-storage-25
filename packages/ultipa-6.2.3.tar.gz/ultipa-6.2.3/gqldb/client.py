"""Main client for GQLDB Python driver."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Callable, Dict, List, Optional

import grpc

from .config import GqldbConfig
from .connection import ConnectionPool
from .errors import EmptyQueryError, GqldbError, GraphNotFoundError
from .response import (
    ExportChunk,
    ExportConfig,
    ExportedEdge,
    ExportedNode,
    ExportEdgesResult,
    ExportNodesResult,
    ExportStats,
    InsertEdgesResult,
    InsertNodesResult,
    Response,
    Row,
)
from .session import Session, SessionManager
from .transaction import Transaction, TransactionManager
from .types import (
    AbortBulkImportResult,
    ASTCacheStats,
    BulkCreateEdgesOptions,
    BulkCreateNodesOptions,
    BulkImportSession,
    BulkImportStatus,
    CacheStats,
    CacheType,
    CheckpointResult,
    CompactResult,
    EdgeData,
    EndBulkImportResult,
    GraphInfo,
    GraphType,
    HealthStatus,
    NodeData,
    PlanCacheStats,
    PropertyType,
    Statistics,
    SystemMetrics,
    TransactionInfo,
    TypedValue,
    # Convenience types
    DBType,
    InsertType,
    LabelInfo,
    ConvPropertyDef,
    NodeTypeInfo,
    EdgeTypeInfo,
    AiStage,
    AiReadResult,
    LabelDef,
    IndexProperty,
    IndexInfo,
    FulltextInfo,
    AlgoInfo,
    TaskInfo,
    ProcessInfo,
    GraphStats,
    InsertResponse,
    # ConvNode and ConvEdge removed — insert_nodes/insert_edges now use NodeData/EdgeData
)


@dataclass
class QueryConfig:
    """Configuration for a query."""
    graph_name: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    transaction_id: int = 0
    timeout: int = 0
    read_only: bool = False
    max_path_results: int = 0  # Max paths to return from path queries (0 = unlimited)


@dataclass
class InsertConfig(QueryConfig):
    """Configuration for insert_nodes / insert_edges convenience methods.

    Extends QueryConfig with insert-specific options.
    """
    insert_type: 'InsertType' = None  # Set at runtime to avoid circular import at module load; defaults to NORMAL.

    def __post_init__(self):
        # Lazy default to InsertType.NORMAL
        if self.insert_type is None:
            from gqldb.types.convenience import InsertType
            self.insert_type = InsertType.NORMAL


@dataclass
class DeleteConfig(QueryConfig):
    """Configuration for delete_nodes_by_* / delete_edges_by_* convenience methods.

    Extends QueryConfig (so per-call ``graph_name`` works the same as
    ``InsertConfig``).

    Knobs:
      * ``return_deleted`` (default True) — emit ``RETURN ...`` so the
        response carries the full deleted node/edge data. Set to False
        on large bulk deletes to save bandwidth; ``rows_affected`` still
        carries the count.
      * ``allow_delete_all`` (default False) — safety latch. With empty
        labels/ids AND empty where, the SDK would otherwise emit a
        graph-wide delete; this flag must be explicitly True to opt in.
    """
    return_deleted: bool = True
    allow_delete_all: bool = False


def _insert_keyword_for_type(insert_type: 'InsertType') -> str:
    """Map an InsertType value to the GQL keyword(s) selecting the
    matching server-side semantics.

      * ``InsertType.NORMAL``    -> ``"INSERT"`` (error on duplicate ``_id``)
      * ``InsertType.OVERWRITE`` -> ``"INSERT OVERWRITE"`` (replace on duplicate)
      * ``InsertType.UPSERT``    -> ``"UPSERT"`` (merge on duplicate)

    OVERWRITE and UPSERT are different semantics on existing rows; they
    are NOT interchangeable. See :class:`InsertType` docs.
    """
    from gqldb.types.convenience import InsertType
    if insert_type == InsertType.OVERWRITE:
        return "INSERT OVERWRITE"
    if insert_type == InsertType.UPSERT:
        return "UPSERT"
    return "INSERT"


class GqldbClient:
    """Main client for interacting with GQLDB."""

    def __init__(self, config: GqldbConfig):
        """Initialize the GQLDB client.

        Args:
            config: Configuration for the client.

        Raises:
            GqldbError: If initialization fails.
        """
        config.validate()
        self._config = config
        self._pool = ConnectionPool(config)
        self._sessions = SessionManager()
        self._tx_manager = TransactionManager()

        # Stored credentials for auto-reconnect
        self._stored_username: str = ""
        self._stored_password: str = ""
        self._stored_graph: str = ""

        # Stable per-client logical session id, surfaced under the
        # transaction-branch model. Initialized to a UUID v4 hex; users
        # can override via `config.session_id` (if set) for cross-channel
        # session continuity. See TRANSACTIONS_DRIVER_GUIDE.md §2.0–2.1.
        import uuid
        self._client_session_id: str = (
            getattr(config, "session_id", None) or uuid.uuid4().hex
        )

        # Initialize service context
        from .services import (
            ServiceContext,
            SessionService,
            QueryService,
            GraphService,
            TransactionService,
            DataService,
            HealthService,
            AdminService,
            BulkImportService,
        )

        ctx = ServiceContext(
            config, self._pool, self._sessions, self._tx_manager,
            client_session_id=self._client_session_id,
        )

        # Initialize service instances
        self._session_service = SessionService(ctx)
        self._query_service = QueryService(ctx)
        self._graph_service = GraphService(ctx)
        self._transaction_service = TransactionService(ctx)
        self._data_service = DataService(ctx)
        self._health_service = HealthService(ctx)
        self._admin_service = AdminService(ctx)
        self._bulk_import_service = BulkImportService(ctx)

    def close(self) -> None:
        """Close the client and all connections."""
        if self._sessions.is_logged_in():
            try:
                self.logout()
            except Exception:
                pass
        self._pool.close()

    def __enter__(self) -> "GqldbClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    # =========================================================================
    # Session Service
    # =========================================================================

    def login(self, username: str, password: str) -> Session:
        """Authenticate the user and create a session."""
        session = self._session_service.login(username, password, self._config.default_graph)
        # Store credentials for auto-reconnect
        self._stored_username = username
        self._stored_password = password
        return session

    def logout(self) -> None:
        """Terminate the current session."""
        return self._session_service.logout()

    def ping(self) -> int:
        """Check the connection and return the latency in nanoseconds."""
        return self._session_service.ping()

    # =========================================================================
    # Query Service
    # =========================================================================

    def _with_auto_reconnect(self, fn):
        """Execute fn and auto-reconnect on UNAUTHENTICATED error.

        If fn raises a GqldbError with 'UNAUTHENTICATED' in the message and
        stored credentials are available, re-login and retry fn once.
        """
        try:
            return fn()
        except (GqldbError, grpc.RpcError) as e:
            error_str = str(e)
            is_unauthenticated = False
            if isinstance(e, grpc.RpcError) and hasattr(e, 'code'):
                is_unauthenticated = e.code() == grpc.StatusCode.UNAUTHENTICATED
            elif "UNAUTHENTICATED" in error_str or "session not found" in error_str.lower() or "session expired" in error_str.lower():
                is_unauthenticated = True

            if is_unauthenticated and self._stored_username:
                # Re-login with stored credentials
                try:
                    # Remember current graph before re-login
                    current_graph = self._stored_graph
                    self.login(self._stored_username, self._stored_password)
                    # Restore previous graph context
                    if current_graph:
                        try:
                            self.use_graph(current_graph)
                        except Exception:
                            pass
                except Exception:
                    raise e  # Return original error if re-login fails
                # Retry once
                return fn()
            raise

    def gql(
        self,
        query: str,
        config: Optional[QueryConfig] = None,
        *,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Response:
        """Execute a GQL query and return the result.

        Args:
            query: GQL query string.
            config: Optional query configuration. If both ``config`` and
                ``parameters`` are supplied, ``parameters`` is merged into
                ``config.parameters`` (the kwarg wins on key conflicts).
            parameters: Convenience shortcut for one-off parameterised
                queries — equivalent to ``QueryConfig(parameters=...)``.
                Values pass through ``TypedValue.from_value`` so any type
                the driver encodes for INSERT (Vector, Point, temporals,
                bytes, etc.) is accepted.

        Returns:
            Query response.

        Raises:
            EmptyQueryError: If query is empty.
            GqldbError: If query fails.
        """
        if parameters:
            if config is None:
                config = QueryConfig(parameters=dict(parameters))
            else:
                merged = dict(config.parameters or {})
                merged.update(parameters)
                config = replace(config, parameters=merged)
        return self._with_auto_reconnect(lambda: self._query_service.gql(query, config))
    def gql_stream(
        self,
        query: str,
        config: Optional[QueryConfig] = None,
        callback: Optional[Callable[[Response], None]] = None
    ) -> None:
        """Execute a GQL query and stream the results.

        Args:
            query: GQL query string.
            config: Optional query configuration.
            callback: Callback function for each response chunk.

        Raises:
            EmptyQueryError: If query is empty.
            GqldbError: If query fails.
        """
        return self._with_auto_reconnect(
            lambda: self._query_service.gql_stream(query, config, callback)
        )

    def explain(self, query: str, config: Optional[QueryConfig] = None) -> str:
        """Return the execution plan for a query.

        Args:
            query: GQL query string.
            config: Optional query configuration.

        Returns:
            Execution plan string.

        Raises:
            GqldbError: If explain fails.
        """
        return self._with_auto_reconnect(lambda: self._query_service.explain(query, config))
    def profile(self, query: str, config: Optional[QueryConfig] = None) -> str:
        """Execute a query with profiling and return statistics.

        Args:
            query: GQL query string.
            config: Optional query configuration.

        Returns:
            Profile statistics string.

        Raises:
            GqldbError: If profile fails.
        """
        return self._with_auto_reconnect(lambda: self._query_service.profile(query, config))
    # =========================================================================
    # Graph Service
    # =========================================================================

    def create_graph(
        self,
        name: str,
        graph_type: GraphType = GraphType.OPEN,
        description: str = ""
    ) -> None:
        """Create a new graph.

        Args:
            name: Graph name.
            graph_type: Type of graph.
            description: Optional description.

        Raises:
            GqldbError: If creation fails.
        """
        return self._graph_service.create_graph(name, graph_type, description)
    def drop_graph(self, name: str, if_exists: bool = False) -> None:
        """Delete a graph.

        Args:
            name: Graph name.
            if_exists: If True, don't error if graph doesn't exist.

        Raises:
            GqldbError: If deletion fails.
        """
        return self._graph_service.drop_graph(name, if_exists)
    def use_graph(self, name: str) -> None:
        """Set the current graph for the session.

        Args:
            name: Graph name.

        Raises:
            GqldbError: If operation fails.
        """
        self._graph_service.use_graph(name)
        self._stored_graph = name
    def list_graphs(self) -> List[GraphInfo]:
        """Return all available graphs.

        Returns:
            List of GraphInfo objects.

        Raises:
            GqldbError: If operation fails.
        """
        return self._graph_service.list_graphs()
    def get_graph_info(self, name: str) -> GraphInfo:
        """Return information about a specific graph.

        Args:
            name: Graph name.

        Returns:
            GraphInfo object.

        Raises:
            GraphNotFoundError: If graph not found.
            GqldbError: If operation fails.
        """
        return self._graph_service.get_graph_info(name)
    # =========================================================================
    # Transaction Service
    # =========================================================================

    def begin_transaction(
        self,
        graph_name: str,
        read_only: bool = False,
        timeout: int = 0
    ) -> Transaction:
        """Start a new transaction.

        Args:
            graph_name: Graph name for the transaction.
            read_only: Whether the transaction is read-only.
            timeout: Timeout in seconds.

        Returns:
            The created Transaction.

        Raises:
            GqldbError: If operation fails.
        """
        tx = self._transaction_service.begin_transaction(graph_name, read_only, timeout)
        # Surface the per-client logical session id on the returned
        # Transaction (transaction-branch ergonomic; see
        # TRANSACTIONS_DRIVER_GUIDE.md §2.0–2.1). Empty string ``''`` here
        # means the client was constructed without a session id source —
        # should not happen in practice since __init__ always generates one.
        try:
            tx.client_session_id = self._client_session_id
        except Exception:
            pass
        return tx

    @property
    def client_session_id(self) -> str:
        """Stable per-client logical session id surfaced under the
        transaction-branch model. Same id is attached to every Transaction
        returned by ``begin_transaction()``."""
        return self._client_session_id

    def commit(self, transaction_id: int) -> bool:
        """Commit a transaction.

        Args:
            transaction_id: Transaction ID.

        Returns:
            True if successful.

        Raises:
            GqldbError: If operation fails.
        """
        return self._transaction_service.commit(transaction_id)
    def rollback(self, transaction_id: int) -> bool:
        """Rollback a transaction.

        Args:
            transaction_id: Transaction ID.

        Returns:
            True if successful.

        Raises:
            GqldbError: If operation fails.
        """
        return self._transaction_service.rollback(transaction_id)
    def list_transactions(self) -> List[TransactionInfo]:
        """Return active transactions.

        Returns:
            List of TransactionInfo objects.

        Raises:
            GqldbError: If operation fails.
        """
        return self._transaction_service.list_transactions()
    def with_transaction(
        self,
        graph_name: str,
        fn: Callable[[int], None],
        read_only: bool = False,
        timeout: Optional[int] = None
    ) -> None:
        """Execute a function within a transaction.

        Automatically commits on success or rolls back on error.

        Args:
            graph_name: Graph name for the transaction.
            fn: Function to execute with transaction ID.
            read_only: Whether the transaction is read-only.
            timeout: Optional timeout in seconds. Uses config timeout if not specified.

        Raises:
            GqldbError: If operation fails.
        """
        return self._transaction_service.with_transaction(
            graph_name, fn, read_only, timeout or self.config.timeout
        )

    # ---- Admin DDL surface (transaction-branch) -----------------------------

    def show_transactions(self) -> List["TransactionRow"]:
        """Return active transactions via the GQL admin DDL ``SHOW TRANSACTIONS``.

        Each row mirrors the 5-column server-side schema:
        ``transaction_id`` / ``status`` / ``read_only`` / ``start_time`` /
        ``session_id``. ``session_id`` is empty unless the server has
        auto-derived one from peer info or the driver explicitly surfaces
        ``x-ultipa-session-id`` metadata (see TRANSACTIONS_DRIVER_GUIDE.md).

        Distinct from ``list_transactions()`` which uses the legacy
        ``ListTransactions`` gRPC.
        """
        from .types.graph_models import TransactionRow

        resp = self.gql("SHOW TRANSACTIONS")
        rows: List[TransactionRow] = []
        # Tolerate column order changes; default to the documented schema if
        # the server doesn't echo column names.
        idx = {name: i for i, name in enumerate(resp.columns)}
        for row in resp.rows:
            def col(n, default=""):
                i = idx.get(n)
                if i is None:
                    return default
                return row.get(i)
            rows.append(TransactionRow(
                transaction_id=str(col("transaction_id", "")),
                status=str(col("status", "")),
                read_only=bool(col("read_only", False)),
                start_time=str(col("start_time", "")),
                session_id=str(col("session_id", "") or ""),
            ))
        return rows

    def kill_transaction(self, transaction_id: str) -> Response:
        """Roll back a single transaction by ID via ``KILL TRANSACTION '<id>'``.

        ``transaction_id`` here is the **string** id surfaced by
        ``show_transactions()`` (e.g. ``'tx_a396c531-...'``), distinct from
        the ``int`` id returned by ``begin_transaction()``.
        """
        # Single-quote escape: doubled '' per GQL string literal grammar.
        escaped = str(transaction_id).replace("'", "''")
        return self.gql(f"KILL TRANSACTION '{escaped}'")

    def reset_transactions(self) -> Response:
        """Roll back every active transaction via ``RESET TRANSACTIONS``.

        Admin-only; intended as an escape hatch when an orphan tx is
        blocking new BEGINs (the legacy single-tenant gate symptom).
        """
        return self.gql("RESET TRANSACTIONS")

    # =========================================================================
    # Data Service
    # =========================================================================

    def insert_nodes_batch_auto(
        self,
        graph_name: str,
        nodes: List[NodeData],
        options: Optional[BulkCreateNodesOptions] = None,
        bulk_import_session_id: str = ""
    ) -> InsertNodesResult:
        """Insert multiple nodes into a graph using gRPC bulk insert.

        Args:
            graph_name: Graph name.
            nodes: List of node data.
            options: Optional bulk creation options.
            bulk_import_session_id: Optional bulk import session ID for auto-checkpoint.

        Returns:
            InsertNodesResult.

        Raises:
            GqldbError: If operation fails.
        """
        return self._data_service.insert_nodes(graph_name, nodes, options, bulk_import_session_id)
    def insert_edges_batch_auto(
        self,
        graph_name: str,
        edges: List[EdgeData],
        options: Optional[BulkCreateEdgesOptions] = None,
        bulk_import_session_id: str = ""
    ) -> InsertEdgesResult:
        """Insert multiple edges into a graph using gRPC bulk insert.

        Args:
            graph_name: Graph name.
            edges: List of edge data.
            options: Optional bulk creation options.
            bulk_import_session_id: Optional bulk import session ID for auto-checkpoint.

        Returns:
            InsertEdgesResult.

        Raises:
            GqldbError: If operation fails.
        """
        return self._data_service.insert_edges(graph_name, edges, options, bulk_import_session_id)
    def delete_nodes_by_ids(
        self,
        node_ids: List[str],
        config: Optional[DeleteConfig] = None,
    ) -> Response:
        """Delete nodes by id list. Emits
        ``MATCH (n) WHERE id(n) IN [...] DETACH DELETE n RETURN n``.

        Empty/None ``node_ids`` short-circuits to an empty Response
        without contacting the server.

        Args:
            node_ids: list of node ids to delete
            config: optional DeleteConfig (graph_name, return_deleted, …)

        Returns:
            Response with one row per actually-deleted node, column ``n``
            holding the GqldbNode. Use ``response.alias("n").as_nodes()``.

            With ``return_deleted=False`` the response carries only
            ``rows_affected``; ``rows`` is empty.
        """
        if config is None:
            config = DeleteConfig()
        if not node_ids:
            return Response(columns=[], rows=[], row_count=0, rows_affected=0)
        gql = (
            "MATCH (n) WHERE id(n) IN ["
            + self._format_string_list(node_ids)
            + "] DETACH DELETE n"
        )
        if config.return_deleted:
            gql += " RETURN n"
        return self.gql(gql, config)

    def delete_nodes_by_condition(
        self,
        labels: Optional[List[str]] = None,
        where: str = "",
        limit: Optional[int] = None,
        config: Optional[DeleteConfig] = None,
    ) -> Response:
        """Delete nodes matching ``labels`` and/or ``where``. Emits
        ``MATCH (n:L1|L2) WHERE <where> [LIMIT N] DETACH DELETE n RETURN n``.

        Raises ValueError if both ``labels`` and ``where`` are empty
        unless ``config.allow_delete_all = True``.

        Args:
            labels: optional list of labels; ``None``/empty = any label.
            where: optional GQL WHERE clause (without the ``WHERE`` keyword).
            config: optional :class:`DeleteConfig`.
            limit: optional cap on number of nodes deleted. ``None`` / ``<= 0``
                = no cap. Emitted as ``LIMIT N`` between ``MATCH/WHERE`` and
                ``DETACH DELETE``.
        """
        if config is None:
            config = DeleteConfig()
        no_labels = not labels
        no_where = not (where and where.strip())
        if no_labels and no_where and not config.allow_delete_all:
            raise ValueError(
                "delete_nodes_by_condition with no labels and no where would "
                "delete every node in the graph. If this is intentional, set "
                "DeleteConfig.allow_delete_all = True."
            )
        gql = "MATCH (n"
        if not no_labels:
            gql += ":" + "|".join(f"`{l}`" for l in labels)
        gql += ")"
        if not no_where:
            gql += " WHERE " + where
        if limit is not None and limit > 0:
            gql += f" LIMIT {limit}"
        gql += " DETACH DELETE n"
        if config.return_deleted:
            gql += " RETURN n"
        return self.gql(gql, config)

    def delete_edges_by_ids(
        self,
        edge_ids: List[str],
        config: Optional[DeleteConfig] = None,
    ) -> Response:
        """Delete edges by id list. Emits
        ``MATCH ()-[e]->() WHERE id(e) IN [...] DELETE e
        RETURN id(e), e._from, e._to, labels(e)[0], properties(e)``.

        Uses ``id(e)`` instead of ``e._id`` so it works against graphs
        with or without EDGE_ID enabled. Empty list short-circuits.
        """
        if config is None:
            config = DeleteConfig()
        if not edge_ids:
            return Response(columns=[], rows=[], row_count=0, rows_affected=0)
        gql = (
            "MATCH ()-[e]->() WHERE id(e) IN ["
            + self._format_string_list(edge_ids)
            + "] DELETE e"
        )
        if config.return_deleted:
            gql += " RETURN id(e), e._from, e._to, labels(e)[0], properties(e)"
        raw = self.gql(gql, config)
        return raw if not config.return_deleted else self._reshape_edge_delete(raw)

    def delete_edges_by_condition(
        self,
        label: str = "",
        where: str = "",
        limit: Optional[int] = None,
        config: Optional[DeleteConfig] = None,
    ) -> Response:
        """Delete edges matching ``label`` and/or ``where``. Emits
        ``MATCH ()-[e:Label]->() WHERE <where> [LIMIT N] DELETE e
        RETURN id(e), e._from, e._to, labels(e)[0], properties(e)``.

        Raises ValueError if both ``label`` and ``where`` are empty
        unless ``config.allow_delete_all = True``.

        ``limit``: optional cap (``None`` / ``<= 0`` = no cap).
        """
        if config is None:
            config = DeleteConfig()
        no_label = not label
        no_where = not (where and where.strip())
        if no_label and no_where and not config.allow_delete_all:
            raise ValueError(
                "delete_edges_by_condition with no label and no where would "
                "delete every edge in the graph. If this is intentional, set "
                "DeleteConfig.allow_delete_all = True."
            )
        gql = "MATCH ()-[e"
        if not no_label:
            gql += f":`{label}`"
        gql += "]->()"
        if not no_where:
            gql += " WHERE " + where
        if limit is not None and limit > 0:
            gql += f" LIMIT {limit}"
        gql += " DELETE e"
        if config.return_deleted:
            gql += " RETURN id(e), e._from, e._to, labels(e)[0], properties(e)"
        raw = self.gql(gql, config)
        return raw if not config.return_deleted else self._reshape_edge_delete(raw)

    @staticmethod
    def _reshape_edge_delete(raw: Response) -> Response:
        """Reshape raw 5-column edge-delete response into single ``e``
        column holding GqldbEdge — symmetric with the node path. Rows
        with a null id are skipped (no id = no meaningful Edge)."""
        from gqldb.types.graph_models import GqldbEdge
        from gqldb.types.typed_value import TypedValue
        from gqldb.types.enums import PropertyType
        new_rows = []
        for r in raw.rows:
            edge_id = r.get(0) if len(r) > 0 else None
            if edge_id is None:
                continue
            from_id = r.get(1) if len(r) > 1 else None
            to_id   = r.get(2) if len(r) > 2 else None
            label   = r.get(3) if len(r) > 3 else None
            props   = r.get(4) if len(r) > 4 else {}
            if not isinstance(props, dict):
                props = {}
            edge = GqldbEdge(
                id=str(edge_id), uuid="", label=str(label) if label else "",
                from_node_id=str(from_id) if from_id else "",
                to_node_id=str(to_id) if to_id else "",
                properties=props)
            tv = TypedValue.from_object(PropertyType.EDGE, edge)
            new_rows.append(Row(values=[tv]))
        return Response(
            columns=["e"],
            rows=new_rows,
            row_count=len(new_rows),
            rows_affected=raw.rows_affected,
            has_more=raw.has_more,
            warnings=raw.warnings,
            current_graph=raw.current_graph)

    @staticmethod
    def _format_string_list(ids: List[str]) -> str:
        """Format a list of ids as GQL single-quoted string literals,
        escaping any embedded ``'`` and ``\\``."""
        out = []
        for s in ids:
            if s is None:
                out.append("''")
                continue
            escaped = s.replace("\\", "\\\\").replace("'", "\\'")
            out.append("'" + escaped + "'")
        return ", ".join(out)
    def export(
        self,
        config: ExportConfig,
        callback: Optional[Callable[[ExportChunk], None]] = None
    ) -> None:
        """Export graph data in JSON Lines format (streaming).

        Args:
            config: Export configuration.
            callback: Callback for each exported chunk.

        Raises:
            GqldbError: If operation fails.
        """
        return self._data_service.export(config, callback)

    def export_nodes(
        self,
        graph_name: str,
        labels: Optional[List[str]] = None,
        limit: int = 0,
        callback: Optional[Callable[[ExportNodesResult], None]] = None
    ) -> None:
        """Stream nodes from a graph.

        Deprecated: Use export() with ExportConfig instead.

        Args:
            graph_name: Graph name.
            labels: Optional list of labels to filter by.
            limit: Maximum number of nodes (0 = no limit).
            callback: Callback for each batch.

        Raises:
            GqldbError: If operation fails.
        """
        return self._data_service.export_nodes(graph_name, labels, limit, callback)

    def export_edges(
        self,
        graph_name: str,
        labels: Optional[List[str]] = None,
        limit: int = 0,
        callback: Optional[Callable[[ExportEdgesResult], None]] = None
    ) -> None:
        """Stream edges from a graph.

        Deprecated: Use export() with ExportConfig instead.

        Args:
            graph_name: Graph name.
            labels: Optional list of labels to filter by.
            limit: Maximum number of edges (0 = no limit).
            callback: Callback for each batch.

        Raises:
            GqldbError: If operation fails.
        """
        return self._data_service.export_edges(graph_name, labels, limit, callback)
    # =========================================================================
    # Health Service
    # =========================================================================

    def health_check(self, service: str = "") -> HealthStatus:
        """Check the health of a service.

        Args:
            service: Service name (empty for overall health).

        Returns:
            HealthStatus.

        Raises:
            GqldbError: If operation fails.
        """
        return self._health_service.health_check(service)
    def _proto_to_health_status(self, proto_status: int) -> HealthStatus:
        """Convert proto health status to HealthStatus enum."""
        # Proto enum values: HEALTH_STATUS_UNKNOWN=0, SERVING=1, NOT_SERVING=2, SERVICE_UNKNOWN=3
        if proto_status == 1:
            return HealthStatus.SERVING
        elif proto_status == 2:
            return HealthStatus.NOT_SERVING
        elif proto_status == 3:
            return HealthStatus.SERVICE_UNKNOWN
        return HealthStatus.UNKNOWN

    def watch(
        self,
        service: str = "",
        callback: Optional[Callable[[HealthStatus], None]] = None
    ) -> None:
        """Watch health status changes via server-side streaming.

        Args:
            service: Service name to watch (empty for overall health).
            callback: Callback function called with each HealthStatus update.

        Raises:
            GqldbError: If operation fails.

        Example:
            >>> def on_status(status: HealthStatus):
            ...     print(f"Health status: {status}")
            >>> client.watch(callback=on_status)
        """
        return self._health_service.watch(service, callback)
    def watch_iter(self, service: str = ""):
        """Watch health status changes and yield HealthStatus values.

        This is a generator version of watch() for iteration.

        Args:
            service: Service name to watch (empty for overall health).

        Yields:
            HealthStatus: Each health status update from the server.

        Example:
            >>> for status in client.watch_iter():
            ...     print(f"Health status: {status}")
            ...     if status != HealthStatus.SERVING:
            ...         break
        """
        return self._health_service.watch_iter(service)
    # =========================================================================
    # Admin Service
    # =========================================================================

    def warmup_parser(self, count: int) -> None:
        """Pre-allocate parser instances.

        Args:
            count: Number of parser instances.

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.warmup_parser(count)
    def get_cache_stats(
        self,
        cache_type: CacheType = CacheType.ALL
    ) -> CacheStats:
        """Return cache statistics.

        Args:
            cache_type: Type of cache to query.

        Returns:
            CacheStats.

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.get_cache_stats(cache_type)
    def clear_cache(self, cache_type: CacheType = CacheType.ALL) -> None:
        """Clear the specified cache.

        Args:
            cache_type: Type of cache to clear.

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.clear_cache(cache_type)
    def get_statistics(self, graph_name: str = "") -> Statistics:
        """Return database statistics.

        Args:
            graph_name: Optional graph name (empty for current graph).

        Returns:
            Statistics.

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.get_statistics(graph_name)
    def invalidate_permission_cache(self, username: str = "") -> None:
        """Invalidate the RBAC permission cache.

        Args:
            username: Optional username (empty for all users).

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.invalidate_permission_cache(username)
    def compact(self) -> CompactResult:
        """Trigger manual compaction of the database storage.

        Returns:
            CompactResult.

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.compact()

    def get_system_metrics(self) -> SystemMetrics:
        """Return system-level metrics (CPU, memory, disk I/O, storage, network).

        Returns:
            SystemMetrics.

        Raises:
            GqldbError: If operation fails.
        """
        return self._admin_service.get_system_metrics()

    # =========================================================================
    # Bulk Import Service
    # =========================================================================

    def start_bulk_import(
        self,
        graph_name: str,
        checkpoint_every: int = 0,
        estimated_nodes: int = 0,
        estimated_edges: int = 0,
        memtable_size: int = 0,
        max_memtables: int = 0
    ) -> BulkImportSession:
        """Start a bulk import session for optimized high-throughput inserts.

        Args:
            graph_name: Graph name.
            checkpoint_every: Deprecated. No longer used, server ignores this value.
            estimated_nodes: Hint for pre-allocating node ID cache.
            estimated_edges: Hint for edge batch sizing.
            memtable_size: Memtable size in bytes before flush (default: 64MB).
            max_memtables: Max immutable memtables before stall (default: 4).

        Returns:
            BulkImportSession.

        Raises:
            GqldbError: If operation fails.
        """
        return self._bulk_import_service.start_bulk_import(graph_name, checkpoint_every, estimated_nodes, estimated_edges, memtable_size, max_memtables)
    def checkpoint(self, session_id: str) -> CheckpointResult:
        """Flush all accumulated data to disk for durability.

        .. deprecated::
            Checkpoint is no longer needed. Use end_bulk_import() which performs a final flush.

        Args:
            session_id: Bulk import session ID.

        Returns:
            CheckpointResult.
        """
        import warnings
        warnings.warn(
            "checkpoint() is deprecated. Use end_bulk_import() which performs a final flush.",
            DeprecationWarning,
            stacklevel=2,
        )
        return CheckpointResult(
            success=True,
            record_count=0,
            last_checkpoint_count=0,
            message="Checkpoint has been removed; use end_bulk_import which performs a final flush",
        )
    def end_bulk_import(self, session_id: str) -> EndBulkImportResult:
        """End the bulk import session with a final checkpoint.

        Args:
            session_id: Bulk import session ID.

        Returns:
            EndBulkImportResult.

        Raises:
            GqldbError: If operation fails.
        """
        return self._bulk_import_service.end_bulk_import(session_id)
    def abort_bulk_import(self, session_id: str) -> AbortBulkImportResult:
        """Cancel the bulk import session without final sync.

        Args:
            session_id: Bulk import session ID.

        Returns:
            AbortBulkImportResult.

        Raises:
            GqldbError: If operation fails.
        """
        return self._bulk_import_service.abort_bulk_import(session_id)
    def get_bulk_import_status(self, session_id: str) -> BulkImportStatus:
        """Return the current status of a bulk import session.

        Args:
            session_id: Bulk import session ID.

        Returns:
            BulkImportStatus.

        Raises:
            GqldbError: If operation fails.
        """
        return self._bulk_import_service.get_bulk_import_status(session_id)
    # =========================================================================
    # Convenience Methods
    # =========================================================================

    def get_session(self) -> Optional[Session]:
        """Return the current session."""
        return self._sessions.get_session()

    def is_logged_in(self) -> bool:
        """Check if there is an active session."""
        return self._sessions.is_logged_in()

    @property
    def config(self) -> GqldbConfig:
        """Return the client configuration."""
        return self._config

    # =========================================================================
    # Convenience API — Schema & Admin Methods (64 methods)
    # =========================================================================

    @staticmethod
    def _quote_label(name: str) -> str:
        """Wrap a name in backticks for safe use in GQL statements.

        Label names and property names should be quoted; graph names, index names,
        and fulltext names should NOT be wrapped in backticks.
        """
        return f"`{name}`"

    @staticmethod
    def _quote_labels(names) -> str:
        """Wrap each label name in backticks and join with ', '."""
        return ", ".join(f"`{n}`" for n in names)

    @staticmethod
    def _join_names(names) -> str:
        """Join names with ', ' without backtick wrapping."""
        return ", ".join(str(n) for n in names)

    @staticmethod
    def _parse_property_string(s: str) -> List[ConvPropertyDef]:
        """Parse a property string like 'age INTEGER, name STRING' into a list of ConvPropertyDef."""
        result = []
        if not s or not s.strip():
            return result
        for part in s.split(","):
            part = part.strip()
            if not part:
                continue
            tokens = part.split()
            if len(tokens) >= 2:
                result.append(ConvPropertyDef(name=tokens[0], type=tokens[1]))
        return result

    @staticmethod
    def _format_props_for_gql(props: List[ConvPropertyDef]) -> str:
        """Format property definitions for GQL: '{p1 T1, p2 T2}'."""
        if not props:
            return ""
        parts = [f"{GqldbClient._quote_label(p.name)} {p.type}" for p in props]
        return "{" + ", ".join(parts) + "}"

    @staticmethod
    def _format_value(val: Any) -> str:
        """Format a Python value as a GQL literal."""
        if val is None:
            return "NULL"
        if isinstance(val, bool):
            return "TRUE" if val else "FALSE"
        if isinstance(val, int):
            return str(val)
        if isinstance(val, float):
            return str(val)
        if isinstance(val, str):
            # Order matters: backslash first, then everything else.
            # Server GQL parser uses C-style escapes; literal LF/CR inside
            # a `'...'` string are NOT accepted and surface as
            # "unterminated string literal" parse errors.
            escaped = (
                val.replace("\\", "\\\\")
                   .replace("'", "\\'")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
            )
            return f"'{escaped}'"
        if isinstance(val, (list, tuple)):
            items = ", ".join(GqldbClient._format_value(v) for v in val)
            return f"[{items}]"
        if isinstance(val, dict):
            pairs = ", ".join(f"{k}: {GqldbClient._format_value(v)}" for k, v in val.items())
            return "{" + pairs + "}"
        return f"'{val}'"

    @staticmethod
    def _node_edge_keyword(node_or_edge: DBType) -> str:
        """Return 'NODE' or 'EDGE' keyword for GQL."""
        return "NODE" if node_or_edge == DBType.NODE else "EDGE"

    # --- Graph (6 methods) ---

    def create_open_graph(self, name: str, config: Optional[QueryConfig] = None) -> Response:
        """Create an open (schema-less) graph.

        Args:
            name: Graph name.
            config: Optional QueryConfig for per-call options (timeout, etc.).

        Returns:
            Response from the server.
        """
        self.create_graph(name, GraphType.OPEN, "")
        return self.gql(f"SHOW GRAPHS", config)  # return a Response; create_graph returns None

    def create_closed_graph(self, name: str, config: Optional[QueryConfig] = None):
        """Create an empty closed (schema-enforced) graph.

        Use create_node_label/create_edge_label to add labels after creation.

        Args:
            name: Graph name.
            config: Optional QueryConfig for per-call options (timeout, etc.).
        """
        return self.gql(f"CREATE GRAPH {name} {{}}", config)

    def create_graph_if_not_exist(
        self,
        name: str,
        graph_type: GraphType = GraphType.OPEN,
        description: str = "",
    ) -> bool:
        """Create a graph if it does not already exist.

        Args:
            name: Graph name.
            graph_type: Type of graph.
            description: Optional description.

        Returns:
            True if created, False if already existed.
        """
        try:
            self.create_graph(name, graph_type, description)
            return True
        except GqldbError as e:
            if "already exist" in str(e).lower():
                return False
            raise

    def has_graph(self, name: str) -> bool:
        """Check if a graph exists.

        Args:
            name: Graph name.

        Returns:
            True if the graph exists.
        """
        graphs = self.list_graphs()
        for g in graphs:
            if g.name == name:
                return True
        return False

    def alter_graph(self, graph_name: str, new_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Rename a graph.

        Args:
            graph_name: Current graph name.
            new_name: New graph name.
            config: Optional QueryConfig for per-call options (timeout, etc.).

        Returns:
            Response from the server.
        """
        gql = f"ALTER GRAPH {graph_name} RENAME TO {new_name}"
        return self.gql(gql, config)

    def truncate(self, graph_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Truncate (remove all data from) a graph.

        Args:
            graph_name: Graph name to truncate (required, part of the GQL).
            config: Optional QueryConfig for per-call options (timeout, etc.).
                Note: truncate embeds graph_name in the GQL statement, so
                config.graph_name is not needed; if set, it is passed to the
                server but does not override the target graph being truncated.

        Returns:
            Response from the server.
        """
        gql = f"TRUNCATE GRAPH {graph_name}"
        return self.gql(gql, config)

    # --- Label (16 methods) ---

    @staticmethod
    def _parse_labels_value(val: Any) -> List[str]:
        """Normalize a SHOW LABELS/NODE LABELS/EDGE LABELS value to List[str].

        Server returns a list (multi-label support). Accept list/tuple of strings,
        a single string (degraded servers), or None.
        """
        if val is None:
            return []
        if isinstance(val, (list, tuple)):
            return [str(x) for x in val]
        return [str(val)]

    def show_labels(self, config: Optional[QueryConfig] = None) -> List[LabelInfo]:
        """Show all labels in the current graph.

        Args:
            config: Optional QueryConfig. Use config.graph_name to query a
                specific graph without changing session state.

        Returns:
            List of LabelInfo. Each LabelInfo.labels is a list of strings
            (multi-label groups returned as-is; single labels are length-1).
        """
        resp = self.gql("SHOW LABELS", config)
        result = []
        for row in resp.rows:
            info = LabelInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "name" or col_lower == "label":
                    info.labels = self._parse_labels_value(val)
                elif col_lower == "type" or col_lower == "element_type":
                    info.type = str(val) if val else ""
            result.append(info)
        return result

    def show_node_labels(self, config: Optional[QueryConfig] = None) -> List[LabelInfo]:
        """Show node labels in the current graph.

        Args:
            config: Optional QueryConfig. Use config.graph_name to query a
                specific graph without changing session state.

        Returns:
            List of LabelInfo (all with type='NODE'). Each .labels is a list.
        """
        resp = self.gql("SHOW NODE LABELS", config)
        result = []
        for row in resp.rows:
            info = LabelInfo(type="NODE")
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "name" or col_lower == "label":
                    info.labels = self._parse_labels_value(val)
            result.append(info)
        return result

    def show_edge_labels(self, config: Optional[QueryConfig] = None) -> List[LabelInfo]:
        """Show edge labels in the current graph.

        Args:
            config: Optional QueryConfig. Use config.graph_name to query a
                specific graph without changing session state.

        Returns:
            List of LabelInfo (all with type='EDGE'). Each .labels is a list.
        """
        resp = self.gql("SHOW EDGE LABELS", config)
        result = []
        for row in resp.rows:
            info = LabelInfo(type="EDGE")
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "name" or col_lower == "label":
                    info.labels = self._parse_labels_value(val)
            result.append(info)
        return result

    def show_node_types(self, config: Optional[QueryConfig] = None) -> List[NodeTypeInfo]:
        """Show node types with their properties.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of NodeTypeInfo.
        """
        resp = self.gql("SHOW NODE TYPES", config)
        result = []
        for row in resp.rows:
            info = NodeTypeInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "name" or col_lower == "label":
                    info.name = str(val) if val else ""
                elif col_lower == "properties" or col_lower == "property":
                    info.properties = self._parse_property_string(str(val) if val else "")
            result.append(info)
        return result

    def show_edge_types(self, config: Optional[QueryConfig] = None) -> List[EdgeTypeInfo]:
        """Show edge types with their properties.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of EdgeTypeInfo.
        """
        resp = self.gql("SHOW EDGE TYPES", config)
        result = []
        for row in resp.rows:
            info = EdgeTypeInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "name" or col_lower == "label":
                    info.name = str(val) if val else ""
                elif col_lower == "properties" or col_lower == "property":
                    info.properties = self._parse_property_string(str(val) if val else "")
            result.append(info)
        return result

    def get_label(self, name: str, config: Optional[QueryConfig] = None) -> Optional[LabelInfo]:
        """Get a specific label by name.

        Matches LabelInfo entries where `name` is one of the .labels
        (supports multi-label groups like ['Person', 'Employee']).

        Args:
            name: Label name.
            config: Optional QueryConfig.

        Returns:
            LabelInfo or None if not found.
        """
        labels = self.show_labels(config)
        for label in labels:
            if name in label.labels:
                return label
        return None

    def get_node_label(self, name: str, config: Optional[QueryConfig] = None) -> Optional[NodeTypeInfo]:
        """Get a specific node type by name.

        Args:
            name: Label name.
            config: Optional QueryConfig.

        Returns:
            NodeTypeInfo or None if not found.
        """
        types = self.show_node_types(config)
        for t in types:
            if t.name == name:
                return t
        return None

    def get_edge_label(self, name: str, config: Optional[QueryConfig] = None) -> Optional[EdgeTypeInfo]:
        """Get a specific edge type by name.

        Args:
            name: Label name.
            config: Optional QueryConfig.

        Returns:
            EdgeTypeInfo or None if not found.
        """
        types = self.show_edge_types(config)
        for t in types:
            if t.name == name:
                return t
        return None

    def create_node_label(
        self,
        name: str,
        props: Optional[List[ConvPropertyDef]] = None,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create a node label in the current graph (closed graph).

        Args:
            name: Label name.
            props: Optional property definitions.
            config: Optional QueryConfig. If config.graph_name is set, the label
                is added to that graph instead of the session current graph,
                without modifying session state (thread-safe across graphs).

        Returns:
            Response from the server.
        """
        target_graph = (
            config.graph_name
            if config and config.graph_name
            else self._sessions.get_default_graph()
        )
        prop_str = self._format_props_for_gql(props) if props else "{}"
        gql = f"ALTER GRAPH {target_graph} ADD NODE {{ {self._quote_label(name)} ({prop_str}) }}"
        return self.gql(gql, config)

    def create_edge_label(
        self,
        name: str,
        props: Optional[List[ConvPropertyDef]] = None,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create an edge label in the current graph (closed graph).

        Args:
            name: Label name.
            props: Optional property definitions.
            config: Optional QueryConfig. Use config.graph_name to target
                a specific graph without changing session state.

        Returns:
            Response from the server.
        """
        target_graph = (
            config.graph_name
            if config and config.graph_name
            else self._sessions.get_default_graph()
        )
        prop_str = self._format_props_for_gql(props) if props else "{}"
        gql = f"ALTER GRAPH {target_graph} ADD EDGE {{ {self._quote_label(name)} ()-[{prop_str}]->() }}"
        return self.gql(gql, config)

    def drop_node_label(self, name: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop a node label from the current graph (closed graph).

        Args:
            name: Label name.
            config: Optional QueryConfig. Use config.graph_name to target
                a specific graph without changing session state.

        Returns:
            Response from the server.
        """
        target_graph = (
            config.graph_name
            if config and config.graph_name
            else self._sessions.get_default_graph()
        )
        gql = f"ALTER GRAPH {target_graph} DROP NODE {self._quote_label(name)}"
        return self.gql(gql, config)

    def drop_edge_label(self, *names: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop one or more edge labels from the current graph (closed graph).

        Args:
            *names: Label name(s) to drop.
            config: Optional QueryConfig (keyword-only). Use config.graph_name
                to target a specific graph without changing session state.

        Returns:
            Response from the server.
        """
        target_graph = (
            config.graph_name
            if config and config.graph_name
            else self._sessions.get_default_graph()
        )
        names_str = self._quote_labels(names)
        gql = f"ALTER GRAPH {target_graph} DROP EDGE {names_str}"
        return self.gql(gql, config)

    def create_label_if_not_exist(
        self,
        node_or_edge: DBType,
        name: str,
        props: Optional[List[ConvPropertyDef]] = None,
        config: Optional[QueryConfig] = None,
    ) -> bool:
        """Create a label if it does not already exist.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            name: Label name.
            props: Optional property definitions.
            config: Optional QueryConfig.

        Returns:
            True if created, False if already existed.
        """
        labels = self.show_labels(config)
        for label in labels:
            if name in label.labels:
                return False
        if node_or_edge == DBType.NODE:
            self.create_node_label(name, props, config=config)
        else:
            self.create_edge_label(name, props, config=config)
        return True

    def alter_node_label(self, old_name: str, new_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Rename a node label.

        Args:
            old_name: Current label name.
            new_name: New label name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"ALTER NODE {self._quote_label(old_name)} RENAME TO {self._quote_label(new_name)}"
        return self.gql(gql, config)

    def alter_edge_label(self, old_name: str, new_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Rename an edge label.

        Args:
            old_name: Current label name.
            new_name: New label name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"ALTER EDGE {self._quote_label(old_name)} RENAME TO {self._quote_label(new_name)}"
        return self.gql(gql, config)

    def show_algos(self, config: Optional[QueryConfig] = None) -> List[AlgoInfo]:
        """Show available algorithms.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of AlgoInfo.
        """
        resp = self.gql("SHOW ALGOS", config)
        result = []
        for row in resp.rows:
            # SHOW ALGOS returns single column 'algorithm' with dict value
            algo_dict = None
            for i, col in enumerate(resp.columns):
                if col.lower() == "algorithm":
                    algo_dict = row.get(i)
                    break
            if algo_dict is None and len(resp.columns) > 0:
                algo_dict = row.get(0)
            if isinstance(algo_dict, dict):
                info = AlgoInfo(
                    name=algo_dict.get("name", ""),
                    description=algo_dict.get("description", ""),
                    version=algo_dict.get("version", ""),
                    parameters=str(algo_dict.get("parameters", "")),
                )
                result.append(info)
        return result

    # --- Property (13 methods) ---

    def show_property(
        self,
        node_or_edge: DBType,
        label_name: str,
        config: Optional[QueryConfig] = None,
    ) -> List[ConvPropertyDef]:
        """Show properties of a label.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            config: Optional QueryConfig.

        Returns:
            List of ConvPropertyDef.
        """
        if node_or_edge == DBType.NODE:
            return self.show_node_property(label_name, config)
        return self.show_edge_property(label_name, config)

    def show_node_property(self, label_name: str, config: Optional[QueryConfig] = None) -> List[ConvPropertyDef]:
        """Show properties of a node label.

        Args:
            label_name: Label name.
            config: Optional QueryConfig.

        Returns:
            List of ConvPropertyDef.
        """
        types = self.show_node_types(config)
        for t in types:
            if t.name == label_name:
                return t.properties
        return []

    def show_edge_property(self, label_name: str, config: Optional[QueryConfig] = None) -> List[ConvPropertyDef]:
        """Show properties of an edge label.

        Args:
            label_name: Label name.
            config: Optional QueryConfig.

        Returns:
            List of ConvPropertyDef.
        """
        types = self.show_edge_types(config)
        for t in types:
            if t.name == label_name:
                return t.properties
        return []

    def get_property(
        self,
        node_or_edge: DBType,
        label_name: str,
        prop_name: str,
        config: Optional[QueryConfig] = None,
    ) -> Optional[ConvPropertyDef]:
        """Get a specific property by name.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            prop_name: Property name.
            config: Optional QueryConfig.

        Returns:
            ConvPropertyDef or None if not found.
        """
        props = self.show_property(node_or_edge, label_name, config)
        for p in props:
            if p.name == prop_name:
                return p
        return None

    def get_node_property(
        self,
        label_name: str,
        prop_name: str,
        config: Optional[QueryConfig] = None,
    ) -> Optional[ConvPropertyDef]:
        """Get a specific node property by name.

        Args:
            label_name: Label name.
            prop_name: Property name.
            config: Optional QueryConfig.

        Returns:
            ConvPropertyDef or None if not found.
        """
        props = self.show_node_property(label_name, config)
        for p in props:
            if p.name == prop_name:
                return p
        return None

    def get_edge_property(
        self,
        label_name: str,
        prop_name: str,
        config: Optional[QueryConfig] = None,
    ) -> Optional[ConvPropertyDef]:
        """Get a specific edge property by name.

        Args:
            label_name: Label name.
            prop_name: Property name.
            config: Optional QueryConfig.

        Returns:
            ConvPropertyDef or None if not found.
        """
        props = self.show_edge_property(label_name, config)
        for p in props:
            if p.name == prop_name:
                return p
        return None

    def create_property(
        self,
        node_or_edge: DBType,
        label_name: str,
        props: List[ConvPropertyDef],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Add properties to a label.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            props: Property definitions to add.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        keyword = self._node_edge_keyword(node_or_edge)
        prop_str = self._format_props_for_gql(props)
        gql = f"ALTER {keyword} {self._quote_label(label_name)} ADD PROPERTY {prop_str}"
        return self.gql(gql, config)

    def create_node_property(
        self,
        label_name: str,
        props: List[ConvPropertyDef],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Add properties to a node label.

        Args:
            label_name: Label name.
            props: Property definitions to add.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        return self.create_property(DBType.NODE, label_name, props, config)

    def create_edge_property(
        self,
        label_name: str,
        props: List[ConvPropertyDef],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Add properties to an edge label.

        Args:
            label_name: Label name.
            props: Property definitions to add.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        return self.create_property(DBType.EDGE, label_name, props, config)

    def drop_property(
        self,
        node_or_edge: DBType,
        label_name: str,
        *prop_names: str,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Drop properties from a label.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            *prop_names: Property name(s) to drop.
            config: Optional QueryConfig (keyword-only).
        """
        keyword = self._node_edge_keyword(node_or_edge)
        names_str = self._quote_labels(prop_names)
        gql = f"ALTER {keyword} {self._quote_label(label_name)} DROP PROPERTY {names_str}"
        return self.gql(gql, config)

    def drop_node_property(self, label_name: str, *prop_names: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop properties from a node label."""
        return self.drop_property(DBType.NODE, label_name, *prop_names, config=config)

    def drop_edge_property(self, label_name: str, *prop_names: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop properties from an edge label."""
        return self.drop_property(DBType.EDGE, label_name, *prop_names, config=config)

    def create_property_if_not_exist(
        self,
        node_or_edge: DBType,
        label_name: str,
        props: List[ConvPropertyDef],
        config: Optional[QueryConfig] = None,
    ) -> bool:
        """Create properties if they do not already exist.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            props: Property definitions to add.
            config: Optional QueryConfig.

        Returns:
            True if any properties were created, False if all already existed.
        """
        existing = self.show_property(node_or_edge, label_name, config)
        existing_names = {p.name for p in existing}
        new_props = [p for p in props if p.name not in existing_names]
        if not new_props:
            return False
        self.create_property(node_or_edge, label_name, new_props, config)
        return True

    # --- Constraint (4 methods) ---

    def create_not_null_constraint(
        self,
        node_or_edge: DBType,
        label_name: str,
        prop_name: str,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create a NOT NULL constraint on a property.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            prop_name: Property name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        cname = self._constraint_name('nn', node_or_edge, label_name, [prop_name])
        pattern, var = self._constraint_target(node_or_edge, label_name)
        gql = f"CREATE CONSTRAINT {cname} FOR {pattern} REQUIRE {var}.{self._quote_label(prop_name)} IS NOT NULL"
        return self.gql(gql, config)

    def create_unique_constraint(
        self,
        node_or_edge: DBType,
        label_name: str,
        *prop_names: str,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create a UNIQUE constraint on one or more properties.

        Args:
            node_or_edge: Whether this is a NODE or EDGE label.
            label_name: Label name.
            *prop_names: Property name(s).
            config: Optional QueryConfig (keyword-only).
        """
        cname = self._constraint_name('uq', node_or_edge, label_name, list(prop_names))
        pattern, var = self._constraint_target(node_or_edge, label_name)
        props_list = ", ".join(f"{var}.{self._quote_label(p)}" for p in prop_names)
        require_expr = f"({props_list})" if len(prop_names) > 1 else props_list
        gql = f"CREATE CONSTRAINT {cname} FOR {pattern} REQUIRE {require_expr} IS UNIQUE"
        return self.gql(gql, config)

    def drop_not_null_constraint(
        self,
        node_or_edge: DBType,
        label_name: str,
        prop_name: str,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Drop a NOT NULL constraint from a property."""
        cname = self._constraint_name('nn', node_or_edge, label_name, [prop_name])
        return self.gql(f"DROP CONSTRAINT {cname}", config)

    def drop_unique_constraint(
        self,
        node_or_edge: DBType,
        label_name: str,
        *prop_names: str,
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Drop a UNIQUE constraint from one or more properties."""
        cname = self._constraint_name('uq', node_or_edge, label_name, list(prop_names))
        return self.gql(f"DROP CONSTRAINT {cname}", config)

    @staticmethod
    def _constraint_name(kind: str, node_or_edge: DBType, label_name: str, prop_names: list) -> str:
        """Derive a stable constraint name from kind/entity/label/props."""
        from .types import DBType as _DBType
        ent = 'node' if node_or_edge == _DBType.NODE else 'edge'
        props = "_".join(p.lower() for p in prop_names)
        return f"{kind}_{ent}_{label_name.lower()}_{props}"

    def _constraint_target(self, node_or_edge: DBType, label_name: str):
        """Build the FOR clause pattern and bound variable for CREATE CONSTRAINT."""
        from .types import DBType as _DBType
        ql = self._quote_label(label_name)
        if node_or_edge == _DBType.NODE:
            return f"(n:{ql})", "n"
        return f"()-[e:{ql}]->()", "e"

    # --- Index (7 methods) ---

    def _parse_index_response(self, resp: Response) -> List[IndexInfo]:
        """Parse a SHOW INDEX response into IndexInfo objects."""
        result = []
        for row in resp.rows:
            info = IndexInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "index_name" or col_lower == "name":
                    info.index_name = str(val) if val else ""
                elif col_lower == "entity_type" or col_lower == "type" or col_lower == "element_type":
                    info.entity_type = str(val) if val else ""
                elif col_lower == "label":
                    info.label = str(val) if val else ""
                elif col_lower == "property" or col_lower == "properties":
                    info.property = str(val) if val else ""
                elif col_lower == "prefix_length":
                    if val is not None:
                        info.prefix_length = int(val)
                elif col_lower == "status":
                    info.status = str(val) if val else ""
                elif col_lower == "progress":
                    info.progress = str(val) if val else ""
                elif col_lower == "indexed_count":
                    info.indexed_count = int(val) if val else 0
                elif col_lower == "total_count":
                    info.total_count = int(val) if val else 0
                elif col_lower == "error":
                    info.error = str(val) if val else ""
            result.append(info)
        return result

    def show_index(self, config: Optional[QueryConfig] = None) -> List[IndexInfo]:
        """Show all indexes in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of IndexInfo.
        """
        resp = self.gql("SHOW INDEX", config)
        return self._parse_index_response(resp)

    def show_node_index(self, config: Optional[QueryConfig] = None) -> List[IndexInfo]:
        """Show node indexes in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of IndexInfo.
        """
        resp = self.gql("SHOW NODE INDEX", config)
        return self._parse_index_response(resp)

    def show_edge_index(self, config: Optional[QueryConfig] = None) -> List[IndexInfo]:
        """Show edge indexes in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of IndexInfo.
        """
        resp = self.gql("SHOW EDGE INDEX", config)
        return self._parse_index_response(resp)

    def create_node_index(
        self,
        index_name: str,
        label_name: str,
        props: List[IndexProperty],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create an index on a node label.

        Args:
            index_name: Index name.
            label_name: Label name.
            props: Properties to index.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        prop_parts = []
        for p in props:
            if p.prefix_length > 0:
                prop_parts.append(f"{self._quote_label(p.name)}({p.prefix_length})")
            else:
                prop_parts.append(self._quote_label(p.name))
        props_str = ", ".join(prop_parts)
        gql = f"CREATE INDEX {index_name} ON NODE {self._quote_label(label_name)} ({props_str})"
        return self.gql(gql, config)

    def create_edge_index(
        self,
        index_name: str,
        label_name: str,
        props: List[IndexProperty],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create an index on an edge label.

        Args:
            index_name: Index name.
            label_name: Label name.
            props: Properties to index.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        prop_parts = []
        for p in props:
            if p.prefix_length > 0:
                prop_parts.append(f"{self._quote_label(p.name)}({p.prefix_length})")
            else:
                prop_parts.append(self._quote_label(p.name))
        props_str = ", ".join(prop_parts)
        gql = f"CREATE INDEX {index_name} ON EDGE {self._quote_label(label_name)} ({props_str})"
        return self.gql(gql, config)

    def drop_node_index(self, index_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop a node index.

        Args:
            index_name: Index name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"DROP NODE INDEX {index_name}"
        return self.gql(gql, config)

    def drop_edge_index(self, index_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop an edge index.

        Args:
            index_name: Index name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"DROP EDGE INDEX {index_name}"
        return self.gql(gql, config)

    # --- Fulltext (7 methods) ---

    def _parse_fulltext_response(self, resp: Response) -> List[FulltextInfo]:
        """Parse a SHOW FULLTEXT response into FulltextInfo objects."""
        result = []
        for row in resp.rows:
            info = FulltextInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "index_name" or col_lower == "name":
                    info.index_name = str(val) if val else ""
                elif col_lower == "entity_type" or col_lower == "type" or col_lower == "element_type":
                    info.entity_type = str(val) if val else ""
                elif col_lower == "schema_name" or col_lower == "label" or col_lower == "schema":
                    info.schema_name = str(val) if val else ""
                elif col_lower == "properties" or col_lower == "property":
                    info.properties = str(val) if val else ""
                elif col_lower == "analyzer":
                    info.analyzer = str(val) if val else ""
                elif col_lower == "status":
                    info.status = str(val) if val else ""
                elif col_lower == "doc_count":
                    info.doc_count = int(val) if val else 0
                elif col_lower == "progress":
                    info.progress = str(val) if val else ""
            result.append(info)
        return result

    def show_fulltext(self, config: Optional[QueryConfig] = None) -> List[FulltextInfo]:
        """Show all fulltext indexes in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of FulltextInfo.
        """
        resp = self.gql("SHOW FULLTEXT", config)
        return self._parse_fulltext_response(resp)

    def show_node_fulltext(self, config: Optional[QueryConfig] = None) -> List[FulltextInfo]:
        """Show node fulltext indexes in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of FulltextInfo.
        """
        resp = self.gql("SHOW NODE FULLTEXT", config)
        return self._parse_fulltext_response(resp)

    def show_edge_fulltext(self, config: Optional[QueryConfig] = None) -> List[FulltextInfo]:
        """Show edge fulltext indexes in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of FulltextInfo.
        """
        resp = self.gql("SHOW EDGE FULLTEXT", config)
        return self._parse_fulltext_response(resp)

    def create_node_fulltext(
        self,
        index_name: str,
        label_name: str,
        props: List[str],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create a fulltext index on a node label.

        Args:
            index_name: Index name.
            label_name: Label name.
            props: Property names to index.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        props_str = self._quote_labels(props)
        gql = f"CREATE FULLTEXT {index_name} ON NODE {self._quote_label(label_name)} ({props_str})"
        return self.gql(gql, config)

    def create_edge_fulltext(
        self,
        index_name: str,
        label_name: str,
        props: List[str],
        config: Optional[QueryConfig] = None,
    ) -> Response:
        """Create a fulltext index on an edge label.

        Args:
            index_name: Index name.
            label_name: Label name.
            props: Property names to index.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        props_str = self._quote_labels(props)
        gql = f"CREATE FULLTEXT {index_name} ON EDGE {self._quote_label(label_name)} ({props_str})"
        return self.gql(gql, config)

    def drop_node_fulltext(self, index_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop a node fulltext index.

        Args:
            index_name: Index name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"DROP NODE FULLTEXT {index_name}"
        return self.gql(gql, config)

    def drop_edge_fulltext(self, index_name: str, config: Optional[QueryConfig] = None) -> Response:
        """Drop an edge fulltext index.

        Args:
            index_name: Index name.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"DROP EDGE FULLTEXT {index_name}"
        return self.gql(gql, config)

    # --- Task (3 methods) ---

    def show_tasks(self, config: Optional[QueryConfig] = None) -> List[TaskInfo]:
        """Show all tasks in the current graph.

        Args:
            config: Optional QueryConfig.

        Returns:
            List of TaskInfo.
        """
        resp = self.gql("SHOW TASKS", config)
        result = []
        for row in resp.rows:
            info = TaskInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "task_id" or col_lower == "id":
                    info.task_id = str(val) if val else ""
                elif col_lower == "type":
                    info.type = str(val) if val else ""
                elif col_lower == "query":
                    info.query = str(val) if val else ""
                elif col_lower == "algo_name" or col_lower == "algorithm":
                    info.algo_name = str(val) if val else ""
                elif col_lower == "status":
                    info.status = str(val) if val else ""
                elif col_lower == "started_at" or col_lower == "start_time":
                    info.started_at = str(val) if val else ""
                elif col_lower == "progress":
                    info.progress = str(val) if val else ""
                elif col_lower == "parameters":
                    info.parameters = str(val) if val else ""
                elif col_lower == "nodes_written":
                    info.nodes_written = int(val) if val else 0
                elif col_lower == "compute_time_ms" or col_lower == "compute_time":
                    info.compute_time_ms = int(val) if val else 0
                elif col_lower == "write_time_ms" or col_lower == "write_time":
                    info.write_time_ms = int(val) if val else 0
            result.append(info)
        return result

    def delete_task(self, task_id: str, config: Optional[QueryConfig] = None) -> Response:
        """Delete a task.

        Args:
            task_id: Task ID.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"DELETE TASK {task_id}"
        return self.gql(gql, config)

    def stop_task(self, task_id: str, config: Optional[QueryConfig] = None) -> Response:
        """Stop a running task.

        Args:
            task_id: Task ID.
            config: Optional QueryConfig.

        Returns:
            Response from the server.
        """
        gql = f"STOP TASK {task_id}"
        return self.gql(gql, config)

    # --- AI (2 methods) ---

    _AI_YIELD_COLS = "stage, detail, elapsed_ms, tokens_input, tokens_output, tokens_cached, data"

    def ai_read(self, prompt: str, config: Optional[QueryConfig] = None) -> AiReadResult:
        """Ask the AI to generate a GQL statement and execute it.

        Wraps `CALL ai.read("<prompt>") YIELD ...` then automatically re-runs the
        synthesized GQL so :attr:`AiReadResult.data` holds the real query
        :class:`Response` (rows / columns) — matching what Manager UI displays.

        Streams stage rows from the server (start / routing / intent_extraction /
        describe_algorithm / generation / validation / execution / final / error)
        and consolidates them into a typed :class:`AiReadResult`.

        Args:
            prompt: Natural-language query for the AI agent.
            config: Optional :class:`QueryConfig` for per-call graph_name,
                timeout, etc.

        Returns:
            :class:`AiReadResult` with stages, generated_gql, data (Response), tokens.
            On failure, ``success=False`` and ``error`` is populated; ``data`` is None.
        """
        gql = f'CALL ai.read("{self._escape_ai_prompt(prompt)}") YIELD {self._AI_YIELD_COLS}'
        resp = self.gql(gql, config)
        result = self._parse_ai_result(resp)
        # Auto re-run the generated GQL so data is a proper Response (rows/columns),
        # not the execution metadata dict returned in the final stage.
        if result.success and result.generated_gql:
            try:
                result.data = self.gql(result.generated_gql, config)
            except Exception as e:
                result.success = False
                result.error = f"Generated GQL failed to execute: {e}"
                result.data = None
        else:
            result.data = None
        return result

    def ai_gql(self, prompt: str, config: Optional[QueryConfig] = None) -> AiReadResult:
        """Ask the AI to generate a GQL statement *without* executing it.

        The generated GQL is exposed via :attr:`AiReadResult.generated_gql` so the
        caller can review / edit it before running it manually via ``client.gql()``.

        :attr:`AiReadResult.data` is always None for ``ai_gql`` — no execution happens.
        """
        gql = f'CALL ai.gql("{self._escape_ai_prompt(prompt)}") YIELD {self._AI_YIELD_COLS}'
        resp = self.gql(gql, config)
        result = self._parse_ai_result(resp)
        # ai_gql is "generate only" — never auto-execute.
        result.data = None
        return result

    @staticmethod
    def _escape_ai_prompt(prompt: str) -> str:
        """Escape a prompt so it can be safely embedded in a double-quoted GQL string."""
        return prompt.replace("\\", "\\\\").replace('"', '\\"')

    def _parse_ai_result(self, resp: Response) -> AiReadResult:
        """Parse a CALL ai.read/ai.gql YIELD response into an AiReadResult."""
        result = AiReadResult()
        col_idx = {c: i for i, c in enumerate(resp.columns)}

        def _get(row, name):
            idx = col_idx.get(name)
            return None if idx is None else row.get(idx)

        for row in resp.rows:
            stage = AiStage(
                stage=str(_get(row, "stage") or ""),
                detail=str(_get(row, "detail") or ""),
                elapsed_ms=int(_get(row, "elapsed_ms") or 0),
                tokens_input=int(_get(row, "tokens_input") or 0),
                tokens_output=int(_get(row, "tokens_output") or 0),
                tokens_cached=int(_get(row, "tokens_cached") or 0),
                data=_get(row, "data"),
            )
            result.stages.append(stage)

            # Track aggregates
            if stage.elapsed_ms > result.total_elapsed_ms:
                result.total_elapsed_ms = stage.elapsed_ms
            result.total_tokens_input += stage.tokens_input
            result.total_tokens_output += stage.tokens_output
            result.total_tokens_cached += stage.tokens_cached

            # Extract generated GQL from any stage's data.gql, final's detail, etc.
            if isinstance(stage.data, dict):
                for key in ("gql", "final_gql", "candidate"):
                    val = stage.data.get(key)
                    if isinstance(val, str) and val.strip():
                        result.generated_gql = val
                        break

            if stage.stage == "error":
                result.success = False
                result.error = stage.detail or "AI stage reported error"

            if stage.stage == "final":
                # Server emits the final query result in the final stage's data.
                result.data = stage.data

        # Fallback: if generated_gql wasn't captured from data dict, try final stage's detail
        if result.generated_gql is None:
            for stage in reversed(result.stages):
                if stage.stage == "final" and stage.detail:
                    result.generated_gql = stage.detail
                    break

        return result

    # --- Data Insert (4 methods) ---

    def insert_nodes(self, *args, **kwargs):
        """Insert nodes — dispatches on first-arg type for source compat.

        Two call shapes are accepted:

        1. `insert_nodes(nodes: List[NodeData], config: Optional[InsertConfig] = None)`
           — convenience GQL emitter (added after 6.0.0). Synthesizes
           `INSERT (n0:Label {...}), (n1:Label {...}) RETURN n0, n1`,
           with `INSERT OVERWRITE` when `config.insert_type == InsertType.OVERWRITE`.
           If `NodeData.id` is set, it is emitted as the `_id` property.
           Returns a `Response`.

        2. `insert_nodes(graph_name: str, nodes: List[NodeData],
                         options: Optional[BulkCreateNodesOptions] = None,
                         bulk_import_session_id: str = "")`
           — original 6.0.0 signature, bulk-import gRPC path.
           Returns an `InsertNodesResult` with gRPC-level metadata.
           Preserves source compatibility for callers written against 6.0.0.
        """
        # Path 1: legacy bulk-gRPC signature (graph_name, nodes, options?, sid?)
        if args and isinstance(args[0], str):
            graph_name = args[0]
            nodes = args[1] if len(args) > 1 else kwargs.get("nodes")
            options = (
                args[2] if len(args) > 2
                else kwargs.get("options")
            )
            bulk_import_session_id = (
                args[3] if len(args) > 3
                else kwargs.get("bulk_import_session_id", "")
            )
            return self._data_service.insert_nodes(
                graph_name, nodes, options, bulk_import_session_id
            )

        # Path 2: convenience GQL-emitter signature (nodes, config?)
        nodes = args[0] if args else kwargs.get("nodes")
        config = (
            args[1] if len(args) > 1
            else kwargs.get("config")
        )
        if config is None:
            config = InsertConfig()
        if not nodes:
            return Response(columns=[], rows=[], row_count=0, rows_affected=0)
        for idx, node in enumerate(nodes):
            if not node.labels:
                raise GqldbError(f"Node at index {idx} has no labels. At least one label is required.")
        parts = []
        var_names = []
        for idx, node in enumerate(nodes):
            var_name = f"n{idx}"
            var_names.append(var_name)
            # GQL INSERT only supports single label per node
            label = self._quote_label(node.labels[0])
            props_parts = []
            if node.id:
                props_parts.append(f"_id: {self._format_value(node.id)}")
            if node.properties:
                for k, v in node.properties.items():
                    props_parts.append(f"{k}: {self._format_value(v)}")
            if props_parts:
                props_str = " {" + ", ".join(props_parts) + "}"
            else:
                props_str = ""
            parts.append(f"({var_name}:{label}{props_str})")
        insert_keyword = _insert_keyword_for_type(config.insert_type)
        gql = insert_keyword + " " + ", ".join(parts) + " RETURN " + ", ".join(var_names)
        return self.gql(gql, config)

    def insert_edges(self, *args, **kwargs):
        """Insert edges — dispatches on first-arg type for source compat.

        Two call shapes are accepted:

        1. `insert_edges(edges: List[EdgeData], config: Optional[InsertConfig] = None)`
           — convenience GQL emitter (added after 6.0.0). Per edge synthesizes
           `MATCH (src WHERE id(src) = 'from'), (dst WHERE id(dst) = 'to') INSERT (src)-[e0:Label {...}]->(dst) RETURN e0`,
           with `INSERT OVERWRITE` when `config.insert_type == InsertType.OVERWRITE`.
           Returns a merged `Response` with columns e0, e1, ...

        2. `insert_edges(graph_name: str, edges: List[EdgeData],
                         options: Optional[BulkCreateEdgesOptions] = None,
                         bulk_import_session_id: str = "")`
           — original 6.0.0 signature, bulk-import gRPC path.
           Returns an `InsertEdgesResult` with gRPC-level metadata.
        """
        # Path 1: legacy bulk-gRPC signature
        if args and isinstance(args[0], str):
            graph_name = args[0]
            edges = args[1] if len(args) > 1 else kwargs.get("edges")
            options = (
                args[2] if len(args) > 2
                else kwargs.get("options")
            )
            bulk_import_session_id = (
                args[3] if len(args) > 3
                else kwargs.get("bulk_import_session_id", "")
            )
            return self._data_service.insert_edges(
                graph_name, edges, options, bulk_import_session_id
            )

        # Path 2: convenience GQL-emitter signature
        edges = args[0] if args else kwargs.get("edges")
        config = (
            args[1] if len(args) > 1
            else kwargs.get("config")
        )
        if config is None:
            config = InsertConfig()
        if not edges:
            return Response(columns=[], rows=[], row_count=0, rows_affected=0)
        insert_keyword = _insert_keyword_for_type(config.insert_type)
        # Insert edges one at a time using MATCH + INSERT
        all_columns = []
        all_values = []
        total_affected = 0
        for idx, edge in enumerate(edges):
            var_name = f"e{idx}"
            # Build properties including _id if set — mirrors the node
            # emitter above.  The server's GQL parser accepts
            # `[e0:Knows {_id:'...', ...}]` and stores the edge id
            # verbatim when EDGE_ID is enabled on the graph.
            props_parts = []
            if edge.id:
                props_parts.append(f"_id: {self._format_value(edge.id)}")
            if edge.properties:
                for k, v in edge.properties.items():
                    props_parts.append(f"{k}: {self._format_value(v)}")
            if props_parts:
                props_str = " {" + ", ".join(props_parts) + "}"
            else:
                props_str = ""
            label_str = f":{self._quote_label(edge.label)}" if edge.label else ""
            gql = (
                f"MATCH (src WHERE id(src) = '{edge.from_node_id}'), "
                f"(dst WHERE id(dst) = '{edge.to_node_id}') "
                f"{insert_keyword} (src)-[{var_name}{label_str}{props_str}]->(dst) RETURN {var_name}"
            )
            resp = self.gql(gql, config)
            total_affected += resp.rows_affected
            all_columns.append(var_name)
            if resp.rows and resp.rows[0].values:
                all_values.append(resp.rows[0].values[0])
        merged_row = Row(values=all_values)
        return Response(
            columns=all_columns,
            rows=[merged_row],
            row_count=1,
            rows_affected=total_affected,
        )

    # --- System & Process (4 methods) ---

    def top(self) -> List[ProcessInfo]:
        """Show running processes/queries.

        Returns:
            List of ProcessInfo.
        """
        resp = self.gql("TOP")
        result = []
        for row in resp.rows:
            info = ProcessInfo()
            for i, col in enumerate(resp.columns):
                val = row.get(i)
                col_lower = col.lower()
                if col_lower == "query_id" or col_lower == "id":
                    info.query_id = str(val) if val else ""
                elif col_lower == "query_text" or col_lower == "query" or col_lower == "statement":
                    info.query_text = str(val) if val else ""
                elif col_lower == "start_time" or col_lower == "started_at":
                    info.start_time = str(val) if val else ""
                elif col_lower == "duration_ms" or col_lower == "duration" or col_lower == "elapsed":
                    info.duration_ms = int(val) if val else 0
                elif col_lower == "status":
                    info.status = str(val) if val else ""
            result.append(info)
        return result

    def kill(self, query_id: str) -> Response:
        """Kill a running query/process.

        Args:
            query_id: Query ID to kill.

        Returns:
            Response from the server.
        """
        gql = f"KILL {query_id}"
        return self.gql(gql)

    def stats(self) -> GraphStats:
        """Get graph statistics via db.stats().

        Returns:
            GraphStats.
        """
        current_graph = self._sessions.get_default_graph()
        resp = self.gql("RETURN db.stats() AS stats")
        result = GraphStats(graph_name=current_graph)
        if resp.rows:
            val = resp.rows[0].get(0)
            if isinstance(val, dict):
                result.node_count = int(val.get("nodeCount", val.get("node_count", 0)))
                result.edge_count = int(val.get("edgeCount", val.get("edge_count", 0)))
                if "labelCounts" in val:
                    result.label_counts = val["labelCounts"]
                elif "label_counts" in val:
                    result.label_counts = val["label_counts"]
                if "edgeLabelCounts" in val:
                    result.edge_label_counts = val["edgeLabelCounts"]
                elif "edge_label_counts" in val:
                    result.edge_label_counts = val["edge_label_counts"]
        return result

    def test(self) -> int:
        """Test connectivity by pinging the server.

        Returns:
            Latency in nanoseconds.
        """
        return self.ping()
