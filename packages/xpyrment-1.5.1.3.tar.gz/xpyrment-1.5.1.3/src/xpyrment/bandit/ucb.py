"""Upper Confidence Bound (UCB1) multi-armed bandit algorithms.

This module provides the `UCB1Bandit` class for optimistic-under-uncertainty traffic allocation.
"""

import math
from typing import List, Optional
import numpy as np


class UCB1Bandit:
    """Implements the classical UCB1 (Upper Confidence Bound) multi-armed bandit algorithm.

    # TODO: Support standard-deviation-based variance scaling (UCB1-Tuned) to adapt to reward variability.
    # TODO: Implement sliding-window UCB versions to better handle non-stationary environments.
    """

    def __init__(self, arms: List[str], c: float = 2.0):
        """Initializes the bandit.

        Args:
            arms (List[str]): List of variant names.
            c (float): Exploration variance scaling coefficient. Defaults to 2.0.
        """
        self.arms = arms
        self.c = c
        self.counts = {arm: 0 for arm in arms}
        self.values = {arm: 0.0 for arm in arms}
        self.total_steps = 0

    def select_arm(self, rng: Optional[np.random.Generator] = None) -> str:
        """Selects an arm based on the optimistic UCB1 index metric.

        Returns:
            str: The selected arm/variant name.
        """
        if rng is None:
            rng = np.random.default_rng()

        # Phase 1: Play each arm at least once to initialize statistics
        unplayed = [arm for arm in self.arms if self.counts[arm] == 0]
        if unplayed:
            return rng.choice(unplayed)

        # Phase 2: Compute UCB1 index for each arm using vectorized NumPy operations
        means = np.array([self.values[arm] for arm in self.arms])
        counts = np.array([self.counts[arm] for arm in self.arms])
        
        # Optimistic uncertainty factor
        ucb_vals = means + np.sqrt((self.c * math.log(self.total_steps)) / counts)

        # Handle potential ties randomly
        max_val = np.max(ucb_vals)
        best_indices = np.where(ucb_vals == max_val)[0]
        selected_idx = rng.choice(best_indices)
        
        return self.arms[selected_idx]

    def update(self, arm: str, reward: float):
        """Updates the count and sample average reward of the selected arm.

        Args:
            arm (str): Name of the arm being updated.
            reward (float): Observed feedback/reward scalar.
        """
        if arm not in self.counts:
            raise ValueError(f"Arm '{arm}' is not registered in this bandit.")

        self.total_steps += 1
        self.counts[arm] += 1
        n = self.counts[arm]
        # Incremental running mean formula
        self.values[arm] += (reward - self.values[arm]) / n
