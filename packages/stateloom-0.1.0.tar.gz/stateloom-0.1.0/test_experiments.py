"""Manual experiment test — A/B testing with feedback and metrics.

Requires an already-running StateLoom gate (from test_manual.py or standalone init).

Usage:
    export GOOGLE_API_KEY=your-key-here
    python test_experiments.py
"""

import google.generativeai as genai

import stateloom
from stateloom import PIIRule


DASHBOARD = "http://localhost:4781"


def header(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def pause(ui_hint=None):
    print()
    if ui_hint:
        print(f"  >> UI CHECK: {ui_hint}")
        print(f"  >> Open {DASHBOARD} and look now.")
    input("\n  Press Enter to continue...\n")


# ══════════════════════════════════════════════════════════════════════════
# Init gate with all features
# ══════════════════════════════════════════════════════════════════════════

gate = stateloom.init(
    local_model="llama3.2",
    auto_route=True,
    cache=True,
    console_output=True,
    dashboard=True,
    store_backend="sqlite",
)
print(f"  Dashboard: {DASHBOARD}")

model = genai.GenerativeModel("gemini-2.5-flash")


# ──────────────────────────────────────────────────────────────────────────
header("Create A/B experiment: concise vs detailed")
# ──────────────────────────────────────────────────────────────────────────

exp = stateloom.create_experiment(
    name="prompt-style-test",
    description="Compare concise vs detailed system prompts",
    variants=[
        {"name": "concise", "weight": 1.0, "request_overrides": {"temperature": 0.3}},
        {"name": "detailed", "weight": 1.0, "request_overrides": {"temperature": 0.9}},
    ],
    strategy="random",
)
exp = stateloom.start_experiment(exp.id)
print(f"  Experiment: {exp.name} (id: {exp.id})")
print(f"  Status:     {exp.status}")
print(f"  Variants:   concise (temp=0.3), detailed (temp=0.9)")

pause("Experiments tab: experiment should appear as 'running'.")


# ──────────────────────────────────────────────────────────────────────────
header("Run 6 sessions under the experiment")
# ──────────────────────────────────────────────────────────────────────────

for i in range(6):
    sid = f"exp-session-{i}"
    with stateloom.session(sid, name=f"Experiment run {i}") as s:
        response = model.generate_content("What is 2+2?")
        variant = s.metadata.get("variant", "?")
        print(f"  {sid}: variant={variant} → {response.text.strip()[:60]}")

    # Submit feedback — mix of success/failure
    rating = "success" if i % 3 != 2 else "failure"
    score = 0.8 if rating == "success" else 0.2
    stateloom.feedback(sid, rating=rating, score=score)
    print(f"    feedback: {rating} (score={score})")

pause(
    "Sessions tab: exp-session-* sessions should show experiment badges.\n"
    "  >> Click one to see variant assignment in detail."
)


# ──────────────────────────────────────────────────────────────────────────
header("Experiment metrics")
# ──────────────────────────────────────────────────────────────────────────

metrics = stateloom.experiment_metrics(exp.id)
print(f"  Variants: {len(metrics.get('variants', {}))}")
for vname, vm in metrics.get("variants", {}).items():
    print(f"    {vname}: sessions={vm.get('session_count', 0)}, "
          f"success_rate={vm.get('success_rate', 0):.0%}, "
          f"avg_cost=${vm.get('avg_cost', 0):.4f}")

pause("Experiments tab: click the experiment to see variant metrics.")


# ──────────────────────────────────────────────────────────────────────────
header("Leaderboard")
# ──────────────────────────────────────────────────────────────────────────

board = stateloom.leaderboard()
if board:
    print(f"  {len(board)} entries:")
    for i, entry in enumerate(board):
        print(f"    #{i+1} {entry.get('variant_name', '?')} "
              f"({entry.get('experiment_name', '?')}) "
              f"success={entry.get('success_rate', 0):.0%}")
else:
    print("  No leaderboard entries yet.")

pause("Experiments tab → Leaderboard sub-tab shows variant ranking.")


# ──────────────────────────────────────────────────────────────────────────
header("Conclude experiment")
# ──────────────────────────────────────────────────────────────────────────

result = stateloom.conclude_experiment(exp.id)
print(f"  Experiment concluded.")
print(f"  Final status: concluded")

pause("Experiments tab: experiment should now show as 'concluded'.")


# ══════════════════════════════════════════════════════════════════════════

print(f"\n  Experiment test complete! Dashboard at {DASHBOARD}")
input("\n  Press Enter to shut down...\n")

stateloom.shutdown()
print("\n  Done.\n")
