#!/usr/bin/env python3
"""Demo: Blast Radius Containment — monitor at http://localhost:4781

Real-world scenario: An AI agent starts failing repeatedly. Blast radius
containment auto-pauses the session (or agent identity) to prevent cascading
failures and runaway spending.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(
        budget=0.001,  # very tight global budget to trigger failures
        budget_on_middleware_failure="block",
        blast_radius_enabled=True,
        blast_radius_consecutive_failures=2,
        blast_radius_budget_violations_per_hour=2,
        local_model=None,  # disable local model so calls hit cloud and cost money
    )

    # --- Scenario 1: Normal session works ---
    header("Normal session — under budget")
    with stateloom.session(session_id="br-normal", name="Normal Session", budget=1.00) as s:
        r = ask(user_msg("Say hello in one word."))
        print(f"  Response: {r.content[:60]}")
        print(f"  Cost: ${s.total_cost:.6f}")

    pause("Sessions tab: 'br-normal' — successful, no blast radius issues")

    # --- Scenario 2: Repeated budget failures trigger blast radius ---
    header("Repeated budget failures — blast radius pauses session")
    with stateloom.session(
        session_id="br-failing",
        name="Failing Agent",
        budget=0.0001,  # extremely tight — will fail on second call
    ) as s:
        s.metadata["agent_name"] = "content-writer"
        for i in range(5):
            try:
                r = ask(user_msg(f"Write a paragraph about topic {i + 1}"))
                print(f"  Call {i + 1}: OK — {r.content[:50]}...")
            except stateloom.StateLoomBudgetError as e:
                print(f"  Call {i + 1}: BUDGET ERROR — {e}")
            except stateloom.StateLoomBlastRadiusError as e:
                print(f"  Call {i + 1}: BLAST RADIUS PAUSED — {e}")
                break
            except Exception as e:
                print(f"  Call {i + 1}: {type(e).__name__} — {e}")
                break

    pause(
        "Safety > Blast Radius: see paused sessions and/or agents.\n"
        "  >> 'br-failing' session or 'content-writer' agent may be paused."
    )

    # --- Scenario 3: Check blast radius status ---
    header("Blast radius status")
    status = stateloom.blast_radius_status()
    print(f"  Enabled: {status.get('enabled')}")
    print(f"  Paused sessions: {status.get('paused_sessions', [])}")
    print(f"  Paused agents:   {status.get('paused_agents', [])}")
    print(f"  Session failure counts: {status.get('session_failure_counts', {})}")
    print(f"  Agent failure counts:   {status.get('agent_failure_counts', {})}")

    # --- Scenario 4: Unpause and recover ---
    header("Unpause session and resume")
    for sid in status.get("paused_sessions", []):
        result = stateloom.unpause_session(sid)
        print(f"  Unpaused session '{sid}': {result}")

    for aid in status.get("paused_agents", []):
        result = stateloom.unpause_agent(aid)
        print(f"  Unpaused agent '{aid}': {result}")

    # Verify recovery
    with stateloom.session(session_id="br-recovered", name="Recovered Session", budget=1.00) as s:
        r = ask(user_msg("Confirm blast radius recovery."))
        print(f"  Response: {r.content[:60]}...")
        print(f"  Service restored!")

    pause(
        "Safety > Blast Radius: paused lists should now be empty.\n"
        "  >> 'br-recovered' session succeeded after unpause."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
