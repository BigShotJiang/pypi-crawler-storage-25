#!/usr/bin/env python3
"""Demo: Managed Agents (Prompts-as-an-API) — monitor at http://localhost:4781

Real-world scenario: A product manager deploys AI agents through a dashboard.
Each agent has a slug, model, system prompt, and versioned configs.
Callers hit the agent's proxy URL and the pipeline enforces the agent's rules.
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import httpx


def main():
    gate = init_gate(proxy=True, proxy_require_virtual_key=True)

    # --- Set up org and team (admin action) ---
    header("Set up organization and team")
    org = stateloom.create_organization(name="AgentCorp", budget=100.0)
    team = stateloom.create_team(org.id, name="Product Team")
    print(f"  Org:  {org.name} ({org.id})")
    print(f"  Team: {team.name} ({team.id})")

    # --- Create a managed agent (PM action via dashboard or API) ---
    header("Create managed agent: 'support-bot'")
    agent = stateloom.create_agent(
        slug="support-bot",
        team_id=team.id,
        name="Customer Support Bot",
        model=MODEL,
        system_prompt=(
            "You are a friendly customer support bot for AgentCorp. "
            "Always greet customers warmly, address their concerns, "
            "and end with 'Is there anything else I can help with?'"
        ),
        description="Handles tier-1 customer inquiries",
        request_overrides={"temperature": 0.3},
        budget_per_session=0.10,
        metadata={"owner": "pm-sarah", "category": "support"},
    )
    print(f"  Agent:   {agent.name} (slug: {agent.slug})")
    print(f"  ID:      {agent.id}")
    print(f"  Model:   {MODEL}")
    print(f"  Version: v1 ({agent.active_version_id})")

    # --- Create API key scoped to this agent (PM shares with dev team) ---
    vk = stateloom.create_virtual_key(team.id, name="agent-api-key", agent_ids=[agent.id])
    api_key = vk["key"]
    print(f"  API Key: {vk['key_preview']} (scoped to {agent.slug})")

    pause("Agents tab: see 'support-bot' agent. Click it to see details + the API key.")

    time.sleep(1)

    # --- Call the agent via proxy ---
    header("Call agent via proxy: POST /v1/agents/support-bot/chat/completions")
    resp = httpx.post(
        f"{DASHBOARD_URL}/v1/agents/support-bot/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,  # client can send any model — agent config overrides it
            "messages": [
                {"role": "user", "content": "I was charged twice for my subscription last month."},
            ],
        },
        timeout=30.0,
    )
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        print(f"  Reply: {content[:150]}...")
        print(f"  (Agent enforces model='{MODEL}' regardless of client request)")
    else:
        print(f"  Error: {resp.text[:200]}")

    pause(
        "Sessions tab: see the agent session with metadata (agent_slug, agent_version).\n"
        "  >> The agent's system prompt was prepended automatically."
    )

    # --- Create v2 with updated prompt ---
    header("Create v2 — updated system prompt")
    v2 = stateloom.create_agent_version(
        agent.id,
        model=MODEL,
        system_prompt=(
            "You are AgentCorp's premium support specialist. "
            "You have access to customer account details. "
            "Always verify the customer's identity first, then resolve their issue. "
            "Be empathetic and professional. End with a satisfaction check."
        ),
        request_overrides={"temperature": 0.2, "max_tokens": 500},
        created_by="pm-sarah",
    )
    print(f"  Version v2 created: {v2.id}")

    # Activate v2
    stateloom.activate_agent_version(agent.id, v2.id)
    print(f"  Activated v2!")

    # Call again — should use new prompt
    resp = httpx.post(
        f"{DASHBOARD_URL}/v1/agents/support-bot/chat/completions",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={
            "model": MODEL,
            "messages": [
                {"role": "user", "content": "I need to cancel my account and get a refund."},
            ],
        },
        timeout=30.0,
    )
    if resp.status_code == 200:
        content = resp.json()["choices"][0]["message"]["content"]
        print(f"  v2 Reply: {content[:150]}...")

    pause(
        "Sessions tab: compare the two agent sessions — different system prompts.\n"
        "  >> The agent version metadata shows v1 vs v2."
    )

    # --- Rollback to v1 ---
    header("Rollback to v1")
    stateloom.activate_agent_version(agent.id, agent.active_version_id)
    print(f"  Rolled back to v1!")

    # --- List agents ---
    agents = stateloom.list_agents(team_id=team.id)
    print(f"\n  Agents for {team.name}: {len(agents)}")
    for a in agents:
        print(f"    - {a.slug}: {a.name} (status: {a.status})")

    pause(
        "Compliance > Organizations: agent versions visible.\n"
        "  >> The rollback is instant — v1 is active again."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
