#!/usr/bin/env python3
"""Demo: Full Cross-Feature Workflow — monitor at http://localhost:4781

Real-world scenario: A complete AI-powered customer service platform.
Exercises every major StateLoom feature in a realistic end-to-end flow:
org setup, team hierarchy, PII protection, budget enforcement, caching,
experiments, checkpoints, parent-child sessions, tools, and monitoring.
"""

import json
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(
        pii=True,
        pii_rules=[
            PIIRule(pattern="email", mode="redact"),
            PIIRule(pattern="credit_card", mode="block", on_middleware_failure="block"),
        ],
        cache=True,
        budget=10.0,
        budget_on_middleware_failure="block",
        circuit_breaker=True,
        loop_exact_threshold=0,  # Retries send identical messages — don't flag as loops
    )

    # ══════════════════════════════════════════════════════════
    # Phase 1: Organization setup
    # ══════════════════════════════════════════════════════════
    header("Phase 1: Organization & team setup")

    org = stateloom.create_organization(
        name="Acme SaaS",
        budget=500.0,
        pii_rules=[{"pattern": "email", "mode": "redact"}],
        metadata={"industry": "saas", "plan": "enterprise"},
    )
    support_team = stateloom.create_team(org.id, name="Support", budget=200.0)
    engineering_team = stateloom.create_team(org.id, name="Engineering", budget=200.0)

    print(f"  Org: {org.name} (budget: ${org.budget})")
    print(f"  Support team:     {support_team.id}")
    print(f"  Engineering team: {engineering_team.id}")

    # Create virtual keys
    support_key = stateloom.create_virtual_key(support_team.id, name="support-prod", budget_limit=100.0)
    eng_key = stateloom.create_virtual_key(engineering_team.id, name="eng-internal", budget_limit=100.0)
    print(f"  Virtual keys created: {support_key['key_preview']}, {eng_key['key_preview']}")

    pause("Compliance > Organizations: see Acme SaaS with 2 teams")

    # ══════════════════════════════════════════════════════════
    # Phase 2: A/B Experiment
    # ══════════════════════════════════════════════════════════
    header("Phase 2: Start A/B experiment on support prompts")

    exp = stateloom.create_experiment(
        name="Support Tone Test",
        variants=[
            {"name": "professional", "weight": 50, "request_overrides": {
                "system_prompt": "You are a professional support agent. Be formal and precise.",
            }},
            {"name": "friendly", "weight": 50, "request_overrides": {
                "system_prompt": "You are a friendly support buddy. Be warm and casual.",
            }},
        ],
    )
    stateloom.start_experiment(exp.id)
    print(f"  Experiment: {exp.name} — RUNNING")

    # ══════════════════════════════════════════════════════════
    # Phase 3: Orchestrator with child sessions
    # ══════════════════════════════════════════════════════════
    header("Phase 3: Customer service orchestrator")

    # Define tools
    @stateloom.tool(name="lookup_account")
    def lookup_account(email: str) -> dict:
        time.sleep(0.05)
        return {"id": "acct-42", "name": "Jane Smith", "plan": "Enterprise", "status": "active"}

    @stateloom.tool(name="create_ticket", mutates_state=True)
    def create_ticket(title: str, priority: str) -> dict:
        time.sleep(0.05)
        return {"ticket_id": "TK-5678", "status": "open"}

    with stateloom.session(
        session_id="workflow-orchestrator",
        name="Customer Service Orchestrator",
        org_id=org.id,
        team_id=support_team.id,
        experiment=exp.id,
        budget=2.00,
    ) as parent:
        stateloom.checkpoint("workflow_start", "Customer inquiry received")

        # --- Triage ---
        r = ask([
            {"role": "user", "content": (
                "Customer says: 'I've been charged twice for my subscription this month. "
                "My email is jane@acmecorp.com and I'm really frustrated.'"
            )},
        ])
        print(f"  Triage: {r.content[:100]}...")
        stateloom.checkpoint("triage_complete", "Issue classified as billing dispute")

        # --- Tool: Account lookup ---
        account = lookup_account("jane@acmecorp.com")
        print(f"  Account: {account['name']} ({account['plan']})")

        # --- Child 1: Billing analysis ---
        with stateloom.session(
            session_id="workflow-billing",
            name="Sub: Billing Analysis",
            org_id=org.id,
            team_id=support_team.id,
        ) as billing:
            r_bill = ask([
                {"role": "system", "content": "You are a billing specialist. Be concise."},
                {"role": "user", "content": (
                    f"Customer {account['name']} (Enterprise) reports double charge. "
                    "What are the standard steps to investigate this?"
                )},
            ])
            print(f"  Billing analysis: {r_bill.content[:100]}...")

        # --- Child 2: Draft response ---
        with stateloom.session(
            session_id="workflow-response",
            name="Sub: Draft Response",
            org_id=org.id,
            team_id=support_team.id,
        ) as draft:
            r_draft = ask([
                {"role": "user", "content": (
                    f"Draft a customer response for {account['name']}:\n"
                    f"Issue: Double billing charge\n"
                    f"Analysis: {r_bill.content[:200]}\n"
                    "Be empathetic and provide next steps."
                )},
            ])
            print(f"  Draft response: {r_draft.content[:100]}...")

        # --- Tool: Create ticket ---
        ticket = create_ticket("Double charge - Enterprise customer acct-42", "high")
        print(f"  Ticket: {ticket['ticket_id']}")

        stateloom.checkpoint("workflow_complete", "Customer inquiry resolved")

        # --- Feedback ---
        stateloom.feedback(parent.id, "success", score=0.85, comment="Issue resolved promptly")
        print(f"\n  Orchestrator cost: ${parent.total_cost:.6f}")

    pause(
        "Sessions tab: click 'workflow-orchestrator'.\n"
        "  >> Waterfall: checkpoints, LLM calls, tool calls, child sessions.\n"
        "  >> PII: email was redacted before reaching the LLM.\n"
        "  >> Experiment: session was assigned to a variant."
    )

    # ══════════════════════════════════════════════════════════
    # Phase 4: Caching — FAQ bot
    # ══════════════════════════════════════════════════════════
    header("Phase 4: FAQ bot with caching")

    faqs = [
        "How do I reset my password?",
        "What are your pricing plans?",
        "How do I reset my password?",  # cache hit
        "How do I cancel my subscription?",
        "What are your pricing plans?",  # cache hit
    ]

    with stateloom.session(
        session_id="workflow-faq",
        name="FAQ Bot",
        org_id=org.id,
        team_id=support_team.id,
    ) as s:
        for q in faqs:
            r = ask(user_msg(q))
            tag = "CACHED" if r._stateloom["cached"] else "LIVE"
            print(f"  [{tag:>6}] {q[:40]} → {r.content[:50]}...")

        print(f"\n  Live calls: {s.call_count}  Cache hits: {s.cache_hits}")

    # ══════════════════════════════════════════════════════════
    # Phase 5: PII blocking
    # ══════════════════════════════════════════════════════════
    header("Phase 5: PII blocking — credit card")

    with stateloom.session(
        session_id="workflow-pii-block",
        name="PII Block Demo",
        org_id=org.id,
        team_id=support_team.id,
    ) as s:
        try:
            r = ask(user_msg("Please charge my card 4111-1111-1111-1111 for the renewal."))
        except stateloom.StateLoomPIIBlockedError:
            print("  BLOCKED: Credit card detected and blocked!")

    # ══════════════════════════════════════════════════════════
    # Phase 6: Engineering team — retry + JSON extraction
    # ══════════════════════════════════════════════════════════
    header("Phase 6: Engineering — structured data extraction with retries")

    with stateloom.session(
        session_id="workflow-extract",
        name="Data Extraction",
        org_id=org.id,
        team_id=engineering_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": (
                "Return ONLY valid JSON, no markdown. Format: "
                '{"severity": "low"|"medium"|"high", "category": string, "summary": string}'
            )},
            {"role": "user", "content": (
                "Classify this bug report: 'The export CSV feature generates corrupted files "
                "when there are unicode characters in the data. Affects 20% of Enterprise users.'"
            )},
        ])
        # Strip markdown code fences if present
        text = r.content.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
            text = text.rsplit("```", 1)[0].strip()
        result = json.loads(text)
        print(f"  Extracted: {result}")
        print(f"  Calls: {s.call_count}  Cost: ${s.total_cost:.6f}")

    # ══════════════════════════════════════════════════════════
    # Phase 7: Final stats
    # ══════════════════════════════════════════════════════════
    header("Final: Organization statistics")

    org_s = stateloom.org_stats(org.id)
    print(f"  Acme SaaS: {org_s}")

    for team, name in [(support_team, "Support"), (engineering_team, "Engineering")]:
        ts = stateloom.team_stats(team.id)
        print(f"  {name}: {ts}")

    # Experiment results
    metrics = stateloom.experiment_metrics(exp.id)
    print(f"\n  Experiment metrics: {metrics}")

    stateloom.conclude_experiment(exp.id)
    print("  Experiment concluded.")

    # Circuit breaker status
    cb = stateloom.circuit_breaker_status()
    print(f"\n  Circuit breaker: {cb}")

    pause(
        "FULL TOUR:\n"
        "  >> Overview: total cost, calls, cache hits, PII detections\n"
        "  >> Sessions: all workflow sessions with events\n"
        "  >> Experiments: Support Tone Test with metrics\n"
        "  >> Compliance > Organizations: Acme SaaS hierarchy\n"
        "  >> Compliance > PII Monitor: email redactions + credit card block\n"
        "  >> Cost Analytics: breakdown by model and team"
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
