#!/usr/bin/env python3
"""Demo: Async Jobs — monitor at http://localhost:4781

Real-world scenario: Background batch processing — submit LLM tasks to a
job queue, monitor progress, and get results when they complete. Perfect
for report generation, batch classification, or data enrichment.
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(async_jobs_enabled=True, async_jobs_max_workers=2)

    # --- Submit batch classification jobs ---
    header("Submit batch classification jobs")

    texts = [
        "The product quality is excellent and delivery was fast!",
        "Terrible customer service, waited 3 hours on hold.",
        "Average experience, nothing special but no complaints.",
        "Absolutely love this! Best purchase I've made all year.",
        "The app keeps crashing and support won't help.",
    ]

    job_ids = []
    for i, text in enumerate(texts, 1):
        job = stateloom.submit_job(
            provider=PROVIDER,
            model=MODEL,
            messages=[
                {"role": "system", "content": "Classify the sentiment as POSITIVE, NEGATIVE, or NEUTRAL. One word only."},
                {"role": "user", "content": text},
            ],
            session_id=f"batch-classify",
            metadata={"task": "sentiment", "text_id": f"review-{i}"},
        )
        job_ids.append(job.id)
        print(f"  Job {i}: {job.id} — '{text[:50]}...'")

    print(f"\n  Submitted {len(job_ids)} jobs. Waiting for processing...")

    pause("Async Jobs tab: see 5 pending/running jobs")

    # --- Wait for completion ---
    header("Monitor job progress")
    for _ in range(60):
        time.sleep(1)
        statuses = []
        for jid in job_ids:
            j = stateloom.get_job(jid)
            statuses.append(j.status)
        done = sum(1 for s in statuses if s in ("completed", "failed", "cancelled"))
        if done == len(job_ids):
            break

    # --- Show results ---
    header("Job results")
    for i, jid in enumerate(job_ids, 1):
        j = stateloom.get_job(jid)
        if j.result:
            # Extract content from result
            content = ""
            if isinstance(j.result, dict):
                choices = j.result.get("choices", [])
                if choices:
                    content = choices[0].get("message", {}).get("content", "")
            print(f"  Job {i}: [{j.status:>9}] '{texts[i-1][:40]}...' → {content[:20]}")
        else:
            print(f"  Job {i}: [{j.status:>9}] error={j.error or 'N/A'}")

    # --- Submit and cancel a job ---
    header("Submit and cancel a job")
    cancel_job = stateloom.submit_job(
        provider=PROVIDER,
        model=MODEL,
        messages=[{"role": "user", "content": "This job will be cancelled."}],
        metadata={"task": "cancel-test"},
    )
    print(f"  Submitted: {cancel_job.id} (status: {cancel_job.status})")
    cancelled = stateloom.cancel_job(cancel_job.id)
    print(f"  Cancelled: {cancelled}")
    j = stateloom.get_job(cancel_job.id)
    print(f"  Final status: {j.status}")

    # --- Agent-powered job ---
    header("Agent-powered job — let the agent choose model & prompt")

    agent = stateloom.create_agent(
        slug="sentiment-classifier",
        team_id="team-1",
        model=MODEL,
        system_prompt=(
            "You are a sentiment analysis expert. Classify the sentiment of "
            "the given text as exactly one word: POSITIVE, NEGATIVE, or NEUTRAL."
        ),
    )
    print(f"  Created agent: {agent.slug}")

    agent_job = stateloom.submit_job(
        agent="sentiment-classifier",
        messages=[{"role": "user", "content": "This product changed my life for the better!"}],
        metadata={"task": "agent-sentiment"},
    )
    print(f"  Submitted agent job: {agent_job.id}")
    print(f"  Model (from agent):  {agent_job.model}")
    print(f"  Agent metadata:      {agent_job.metadata}")

    # Wait for completion
    for _ in range(30):
        time.sleep(1)
        j = stateloom.get_job(agent_job.id)
        if j.status in ("completed", "failed"):
            break

    j = stateloom.get_job(agent_job.id)
    if j.result:
        choices = j.result.get("choices", [])
        content = choices[0].get("message", {}).get("content", "") if choices else ""
        print(f"  Result: {content}")
    else:
        print(f"  Status: {j.status}, error: {j.error or 'N/A'}")

    pause(
        "Async Jobs tab: see the agent-powered job.\n"
        "  >> The job's session shows agent_slug='sentiment-classifier'.\n"
        "  >> Model and system prompt were resolved from the agent automatically."
    )

    # --- Job statistics ---
    header("Job statistics")
    stats = stateloom.job_stats()
    print(f"  Total jobs:  {stats.get('total', 0)}")
    print(f"  By status:   {stats.get('by_status', {})}")

    pause(
        "Async Jobs tab: see all jobs with status badges.\n"
        "  >> Completed jobs (green) show result content.\n"
        "  >> Cancelled job (gray) was stopped before processing.\n"
        "  >> Agent job shows agent metadata in session detail.\n"
        "  >> Stats cards: total, completed, failed counts.\n"
        "  >> Click a completed job to see result JSON and session link."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
