#!/usr/bin/env python3
"""Demo: Durable Resumption — monitor at http://localhost:4781

Real-world scenario: A long-running report generation workflow that can
survive crashes and resume from where it left off — like Temporal, but
for LLM calls. Previously completed steps replay from cache for free.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    # Durable mode needs SQLite to persist cached responses across "restarts"
    gate = init_gate(store_backend="sqlite")

    session_id = "durable-report-gen"

    # --- First run: complete 2 of 3 steps, then "crash" ---
    header("First run — complete 2 steps then simulate crash")

    with stateloom.session(
        session_id=session_id,
        name="Durable Report",
        durable=True,
    ) as s:
        stateloom.checkpoint("run_1_start", "First execution of the pipeline")

        r1 = ask([
            {"role": "system", "content": "You are an analyst. Be concise."},
            {"role": "user", "content": "What were the top 3 tech industry trends in 2024?"},
        ])
        print(f"  Step 1 (LIVE): {r1.content[:100]}...")
        print(f"    Cost: ${s.total_cost:.6f}  Steps: {s.step_counter}")

        r2 = ask([
            {"role": "system", "content": "You are an analyst. Be concise."},
            {"role": "user", "content": "What are the key challenges in enterprise AI adoption?"},
        ])
        print(f"  Step 2 (LIVE): {r2.content[:100]}...")
        print(f"    Cost: ${s.total_cost:.6f}  Steps: {s.step_counter}")

        first_run_cost = s.total_cost
        print(f"\n  First run cost: ${first_run_cost:.6f}")
        print("  [Simulating crash — session ends here]")

    pause("Sessions tab: click the durable session — 2 LLM calls with cached responses stored")

    # --- Second run: resume — steps 1-2 are free (cached), step 3 is live ---
    header("Second run — resume from crash (steps 1-2 cached, step 3 live)")

    with stateloom.session(
        session_id=session_id,
        name="Durable Report",
        durable=True,
    ) as s:
        stateloom.checkpoint("run_2_start", "Resumed execution")

        r1 = ask([
            {"role": "system", "content": "You are an analyst. Be concise."},
            {"role": "user", "content": "What were the top 3 tech industry trends in 2024?"},
        ])
        print(f"  Step 1 (CACHED): {r1.content[:100]}...")
        print(f"    Cost: ${r1._stateloom['cost']:.6f}  (should be ~$0 — cached)")

        r2 = ask([
            {"role": "system", "content": "You are an analyst. Be concise."},
            {"role": "user", "content": "What are the key challenges in enterprise AI adoption?"},
        ])
        print(f"  Step 2 (CACHED): {r2.content[:100]}...")
        print(f"    Cost: ${r2._stateloom['cost']:.6f}  (should be ~$0 — cached)")

        r3 = ask([
            {"role": "system", "content": "You are an analyst. Be concise."},
            {"role": "user", "content": (
                "Based on these findings, write a brief recommendation:\n"
                f"Trends: {r1.content[:200]}\n"
                f"Challenges: {r2.content[:200]}"
            )},
        ])
        print(f"  Step 3 (LIVE):   {r3.content[:100]}...")
        print(f"    Cost: ${r3._stateloom['cost']:.6f}  (new call — cost increased)")

        print(f"\n  Resume total cost: ${s.total_cost:.6f}")
        print(f"  Saved by caching: ${first_run_cost:.6f} (steps 1-2 were free)")

        if r1._stateloom["cost"] < 0.0001 and r2._stateloom["cost"] < 0.0001:
            print("  PASS: Resumed steps were effectively free!")
        if r3._stateloom["cost"] > 0:
            print("  PASS: Step 3 was a live call (cost increased)")

    pause(
        "Sessions tab: click the durable session — see all events.\n"
        "  >> Steps 1-2 on resume used cached responses at zero cost.\n"
        "  >> Step 3 was a live API call.\n"
        "  >> Checkpoints show run_1 and run_2 boundaries."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
