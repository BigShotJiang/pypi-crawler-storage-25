#!/usr/bin/env python3
"""Demo: Time-Travel Debugging — Replay Sessions from Any Step

Record a multi-step durable session, then replay it from any point.
Cached steps cost $0; steps beyond the cache execute live.
Like a debugger's "step back" but for LLM calls.

Monitor at http://localhost:4781 → Sessions tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    # Replay needs SQLite to persist cached responses
    gate = init_gate(store_backend="sqlite")

    session_id = "replay-debug"

    # -----------------------------------------------------------------------
    # Scenario 1: Record a 3-step durable session
    # -----------------------------------------------------------------------
    header("Record a 3-step durable session")

    step_costs = []

    with stateloom.session(
        session_id=session_id,
        name="Replay Debug",
        durable=True,
    ) as s:
        r1 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "What is retrieval-augmented generation (RAG)?"},
        ])
        step_costs.append(s.total_cost)
        print(f"  Step 1: {r1.content[:100]}...")
        print(f"    Cumulative cost: ${s.total_cost:.6f}")

        r2 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "What are the main challenges of RAG systems?"},
        ])
        step_costs.append(s.total_cost - step_costs[0])
        print(f"  Step 2: {r2.content[:100]}...")
        print(f"    Cumulative cost: ${s.total_cost:.6f}")

        r3 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "How can RAG be improved with reranking?"},
        ])
        step_costs.append(s.total_cost - sum(step_costs))
        print(f"  Step 3: {r3.content[:100]}...")
        print(f"    Cumulative cost: ${s.total_cost:.6f}")

        total_live_cost = s.total_cost

    print(f"\n  Total recording cost: ${total_live_cost:.6f} (3 live calls)")

    pause("Sessions tab: click the durable session — 3 LLM calls with cached responses")

    # -----------------------------------------------------------------------
    # Scenario 2: Replay first 2 steps (step 3 executes live)
    # -----------------------------------------------------------------------
    header("Partial replay — steps 1-2 cached, step 3 live")

    print("  Replaying with mock_until_step=2...")
    stateloom.replay(session_id, mock_until_step=2)

    with stateloom.session(
        session_id=f"replay-{session_id}",
        name="Replay Debug (partial)",
        durable=True,
    ) as s:
        r1 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "What is retrieval-augmented generation (RAG)?"},
        ])
        print(f"  Step 1 (CACHED): {r1.content[:80]}...")

        r2 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "What are the main challenges of RAG systems?"},
        ])
        print(f"  Step 2 (CACHED): {r2.content[:80]}...")

        r3 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "How can RAG be improved with reranking?"},
        ])
        print(f"  Step 3 (LIVE):   {r3.content[:80]}...")

        print(f"\n  Replay cost: ${s.total_cost:.6f}")
        print(f"  Original cost: ${total_live_cost:.6f}")
        print(f"  Saved: steps 1-2 were free from cache")

    pause("Sessions tab: replay session — first 2 steps have $0 cost, step 3 is live")

    # -----------------------------------------------------------------------
    # Scenario 3: Full replay — all steps cached
    # -----------------------------------------------------------------------
    header("Full replay — all 3 steps cached ($0)")

    print("  Replaying with mock_until_step=3...")
    stateloom.replay(session_id, mock_until_step=3)

    with stateloom.session(
        session_id=f"replay-{session_id}",
        name="Replay Debug (full)",
        durable=True,
    ) as s:
        r1 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "What is retrieval-augmented generation (RAG)?"},
        ])
        r2 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "What are the main challenges of RAG systems?"},
        ])
        r3 = ask([
            {"role": "system", "content": "You are a research assistant. Be concise."},
            {"role": "user", "content": "How can RAG be improved with reranking?"},
        ])

        print(f"  All 3 steps replayed from cache")
        print(f"  Replay cost: ${s.total_cost:.6f} (should be ~$0)")
        print(f"  Original cost: ${total_live_cost:.6f}")

    pause(
        "Sessions tab: full replay session — all events show $0 cost.\n"
        "  >> Time-travel debugging: inspect any past session state for free."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
