#!/usr/bin/env python3
"""Demo: Cohere Integration — Zero-Config Auto-Patching

StateLoom automatically patches cohere.V2Client.chat() and
AsyncV2Client.chat() so every LLM call flows through the middleware
pipeline. Cost tracking, budgets, PII detection — all transparent.

Requires: pip install cohere
          Set CO_API_KEY or COHERE_API_KEY environment variable.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    from cohere import ClientV2
except ImportError:
    print("\n  This demo requires the Cohere SDK: pip install cohere")
    sys.exit(1)

# Check for Cohere API key
if not (os.environ.get("CO_API_KEY") or os.environ.get("COHERE_API_KEY")):
    print("\n  Set CO_API_KEY or COHERE_API_KEY environment variable.")
    print("  Get a key at: https://dashboard.cohere.com/api-keys")
    sys.exit(1)

COHERE_MODEL = "command-r-plus"


def main():
    # stateloom.init() auto-patches Cohere — zero config needed
    gate = init_gate()

    co = ClientV2()

    # -----------------------------------------------------------------------
    # Scenario 1: Basic Cohere chat — auto-tracked by StateLoom
    # -----------------------------------------------------------------------
    header("Cohere V2 chat — auto-patched, zero config")

    with stateloom.session(session_id="cohere-basic", name="Cohere Basic") as s:
        print(f"  Calling co.chat(model='{COHERE_MODEL}')...")
        response = co.chat(
            model=COHERE_MODEL,
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Be concise."},
                {"role": "user", "content": "What is Cohere's Command R model family?"},
            ],
        )
        content = ""
        if hasattr(response, "message") and response.message:
            blocks = getattr(response.message, "content", None)
            if isinstance(blocks, list) and blocks:
                content = getattr(blocks[0], "text", "")
        print(f"  Response: {content[:120]}...")
        print(f"\n  StateLoom tracked this call automatically:")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")
        print(f"    Calls:  {s.call_count}")

    pause("Sessions tab: click 'cohere-basic' — see the Cohere LLM call with cost/tokens")

    # -----------------------------------------------------------------------
    # Scenario 2: Multi-turn conversation — session tracks all calls
    # -----------------------------------------------------------------------
    header("Multi-turn Cohere conversation — costs accumulate")

    with stateloom.session(session_id="cohere-multi", name="Cohere Multi-Turn") as s:
        messages = [
            {"role": "system", "content": "You are a helpful AI tutor. Be concise."},
            {"role": "user", "content": "What is retrieval-augmented generation?"},
        ]

        r1 = co.chat(model=COHERE_MODEL, messages=messages)
        reply1 = ""
        if hasattr(r1, "message") and r1.message:
            blocks = getattr(r1.message, "content", None)
            if isinstance(blocks, list) and blocks:
                reply1 = getattr(blocks[0], "text", "")
        print(f"  Turn 1: {reply1[:100]}...")
        print(f"    Cost: ${s.total_cost:.6f}")

        messages.append({"role": "assistant", "content": reply1})
        messages.append({"role": "user", "content": "How does Cohere's Rerank help with RAG?"})

        r2 = co.chat(model=COHERE_MODEL, messages=messages)
        reply2 = ""
        if hasattr(r2, "message") and r2.message:
            blocks = getattr(r2.message, "content", None)
            if isinstance(blocks, list) and blocks:
                reply2 = getattr(blocks[0], "text", "")
        print(f"  Turn 2: {reply2[:100]}...")
        print(f"    Cost: ${s.total_cost:.6f}")

        print(f"\n  Session summary:")
        print(f"    Total calls:  {s.call_count}")
        print(f"    Total cost:   ${s.total_cost:.6f}")
        print(f"    Total tokens: {s.total_tokens}")

    pause("Sessions tab: 'cohere-multi' — 2 Cohere calls with cumulative cost tracking")

    # -----------------------------------------------------------------------
    # Scenario 3: Budget enforcement on Cohere calls
    # -----------------------------------------------------------------------
    header("Budget enforcement — works transparently with Cohere")

    with stateloom.session(
        session_id="cohere-budget",
        name="Cohere Budget",
        budget=0.001,
    ) as s:
        try:
            for i in range(5):
                co.chat(
                    model=COHERE_MODEL,
                    messages=[{"role": "user", "content": f"Write a haiku about the number {i+1}"}],
                )
                print(f"  Call {i+1}: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"\n  BLOCKED by StateLoom budget: {e}")
            print(f"  Cohere calls are budget-enforced transparently.")

    pause("Sessions tab: 'cohere-budget' — budget enforcement on Cohere calls")

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n  Cohere + StateLoom summary:")
    print("  - stateloom.init() auto-patches cohere.V2Client.chat()")
    print("  - Every call gets cost tracking, session grouping, event recording")
    print("  - Budgets, PII detection, guardrails all work transparently")
    print("  - No code changes needed in your existing Cohere calls")
    print(f"  - Tested with model: {COHERE_MODEL}")

    wait_for_exit()


if __name__ == "__main__":
    main()
