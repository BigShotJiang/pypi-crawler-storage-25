#!/usr/bin/env python3
"""Demo: Compliance Profiles — monitor at http://localhost:4781

Real-world scenario: A healthcare company needs HIPAA compliance and
a European subsidiary needs GDPR. Compliance profiles enforce PII rules,
session TTLs, audit logging, and data handling restrictions automatically.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(pii=True)

    # --- GDPR-compliant European subsidiary ---
    header("GDPR-compliant organization (European subsidiary)")
    eu_org = stateloom.create_organization(
        name="GlobalTech EU",
        budget=200.0,
        compliance_profile="gdpr",
        metadata={"region": "EU", "data_center": "eu-west-1"},
    )
    eu_team = stateloom.create_team(eu_org.id, name="EU Support", compliance_profile="gdpr")
    print(f"  Org: {eu_org.name} ({eu_org.id})")
    print(f"  Compliance: GDPR")
    if eu_org.compliance_profile:
        print(f"    Session TTL: {eu_org.compliance_profile.session_ttl_days} days")
        print(f"    Block local routing: {eu_org.compliance_profile.block_local_routing}")
        print(f"    Block shadow: {eu_org.compliance_profile.block_shadow}")
        print(f"    PII rules: {len(eu_org.compliance_profile.pii_rules)}")

    with stateloom.session(
        session_id="gdpr-session-1",
        name="EU Customer Chat",
        org_id=eu_org.id,
        team_id=eu_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a GDPR-aware support agent for EU customers. Be concise."},
            {"role": "user", "content": "I want to understand how my data is processed under GDPR Article 15."},
        ])
        print(f"  Response: {r.content[:120]}...")

    pause("Compliance > Profiles: see GDPR profile active for GlobalTech EU")

    # --- HIPAA-compliant healthcare org ---
    header("HIPAA-compliant organization (Healthcare)")
    health_org = stateloom.create_organization(
        name="MedTech Health",
        budget=300.0,
        compliance_profile="hipaa",
        metadata={"industry": "healthcare", "data_class": "PHI"},
    )
    health_team = stateloom.create_team(health_org.id, name="Clinical AI", compliance_profile="hipaa")
    print(f"  Org: {health_org.name} ({health_org.id})")
    print(f"  Compliance: HIPAA")
    if health_org.compliance_profile:
        print(f"    Zero retention logs: {health_org.compliance_profile.zero_retention_logs}")
        print(f"    Block streaming: {health_org.compliance_profile.block_streaming}")

    with stateloom.session(
        session_id="hipaa-session-1",
        name="Clinical Query",
        org_id=health_org.id,
        team_id=health_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a medical AI assistant. Do not provide diagnoses. Be informational."},
            {"role": "user", "content": "What are common symptoms of type 2 diabetes?"},
        ])
        print(f"  Response: {r.content[:120]}...")

    pause("Compliance > Profiles: see HIPAA profile for MedTech Health")

    # --- CCPA-compliant California org ---
    header("CCPA-compliant organization (California)")
    ca_org = stateloom.create_organization(
        name="CalTech Solutions",
        budget=100.0,
        compliance_profile="ccpa",
        metadata={"region": "US-CA"},
    )
    ca_team = stateloom.create_team(ca_org.id, name="CA Consumer Team")
    print(f"  Org: {ca_org.name}")
    print(f"  Compliance: CCPA")

    with stateloom.session(
        session_id="ccpa-session-1",
        name="CA Consumer Query",
        org_id=ca_org.id,
        team_id=ca_team.id,
    ) as s:
        r = ask(user_msg("What rights do I have under the California Consumer Privacy Act?"))
        print(f"  Response: {r.content[:120]}...")

    # --- Right to be forgotten (GDPR Article 17) ---
    header("Right to be forgotten — GDPR data purge")
    purge_result = stateloom.purge_user_data("gdpr-session-1", standard="gdpr")
    print(f"  Purge result: {purge_result}")

    pause(
        "Compliance > Profiles: all 3 compliance profiles visible.\n"
        "  >> Compliance > Audit Log: see the purge audit event.\n"
        "  >> GDPR, HIPAA, CCPA each enforce different data handling rules."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
