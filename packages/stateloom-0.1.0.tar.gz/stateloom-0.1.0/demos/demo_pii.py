#!/usr/bin/env python3
"""Demo: PII Detection & Redaction — monitor at http://localhost:4781

Real-world scenario: A customer service bot where users accidentally share
sensitive information. StateLoom detects and redacts PII before it reaches the LLM.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(
        pii=True,
        pii_rules=[
            PIIRule(pattern="email", mode="redact"),
            PIIRule(pattern="phone", mode="redact"),
            PIIRule(pattern="ssn", mode="block", on_middleware_failure="block"),
            PIIRule(pattern="credit_card", mode="block", on_middleware_failure="block"),
        ],
    )

    # --- Scenario 1: Email redaction ---
    header("Customer shares email — redacted before LLM sees it")
    with stateloom.session(session_id="pii-email", name="Email Redaction") as s:
        r = ask([
            {"role": "system", "content": "You are a support agent. Be concise."},
            {"role": "user", "content": "Please send the receipt to sarah.jones@acmecorp.com and cc admin@company.org"},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections}")

    pause("Sessions tab: click 'pii-email' — see PII_REDACTED event (emails replaced with placeholders)")

    # --- Scenario 2: Phone number redaction ---
    header("Customer shares phone number — redacted")
    with stateloom.session(session_id="pii-phone", name="Phone Redaction") as s:
        r = ask([
            {"role": "system", "content": "You are a support agent. Be concise."},
            {"role": "user", "content": "Call me back at 555-867-5309 or my office 415-555-0199"},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections}")

    pause("Sessions tab: click 'pii-phone' — phone numbers redacted")

    # --- Scenario 3: Credit card BLOCKED ---
    header("Customer shares credit card — request BLOCKED entirely")
    with stateloom.session(session_id="pii-cc", name="Credit Card Blocked") as s:
        try:
            r = ask([
                {"role": "system", "content": "You are a payment support agent."},
                {"role": "user", "content": "Charge my card 4111-1111-1111-1111 for $299.99 please"},
            ])
            print(f"  Response: {r.content[:80]}...")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  BLOCKED: {e}")
            print(f"  PII detections: {s.pii_detections}")

    pause("Sessions tab: click 'pii-cc' — PII_BLOCKED event. No LLM call was made.")

    # --- Scenario 4: SSN BLOCKED ---
    header("User shares SSN — request BLOCKED")
    with stateloom.session(session_id="pii-ssn", name="SSN Blocked") as s:
        try:
            r = ask([
                {"role": "system", "content": "You are an HR assistant."},
                {"role": "user", "content": "My social security number is 123-45-6789, can you update my W-2?"},
            ])
            print(f"  Response: {r.content[:80]}...")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  BLOCKED: {e}")

    pause(
        "Compliance > PII Monitor: see all 4 detection events by type.\n"
        "  >> 2 redacted (email, phone), 2 blocked (credit card, SSN).\n"
        "  >> Sessions tab shows which sessions were affected."
    )

    # --- Scenario 5: Clean message (no PII) ---
    header("Normal message — no PII detected, passes through cleanly")
    with stateloom.session(session_id="pii-clean", name="Clean Message") as s:
        r = ask(user_msg("What's the weather like in San Francisco today?"))
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections} (should be 0)")

    pause("Sessions tab: 'pii-clean' has no PII events — clean pass-through")

    wait_for_exit()


if __name__ == "__main__":
    main()
