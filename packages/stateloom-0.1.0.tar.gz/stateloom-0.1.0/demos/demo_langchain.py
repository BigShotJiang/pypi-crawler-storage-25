#!/usr/bin/env python3
"""Demo: LangChain Integration — Full Middleware Pipeline + Callback Handler

StateLoom works best with LangChain when auto_patch=True (default). The underlying
SDK calls flow through the full middleware pipeline (PII scanning, guardrails,
budget enforcement, etc.), while the callback handler adds LangChain-specific
observability (tool names, chain tracking).

Two integration modes:
  1. Recommended: auto_patch=True + StateLoomCallbackHandler (full pipeline + tools)
  2. Standalone:  auto_patch=False + StateLoomCallbackHandler(tools_only=False)
     (observability only, no middleware enforcement)

In recommended mode, the callback handler also bridges LangChain-specific metadata
(run_id, chain_name, tags) into the middleware pipeline events via a ContextVar.
This metadata appears in event.metadata["langchain"] in the dashboard.

This demo shows the recommended approach.

Requires: pip install langchain langchain-openai  (or langchain-anthropic, langchain-google-genai)
          Plus at least one of OPENAI_API_KEY, ANTHROPIC_API_KEY, or GOOGLE_API_KEY.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

# Check LangChain availability
try:
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
except ImportError:
    print("\n  This demo requires LangChain:")
    print("  pip install langchain langchain-core")
    sys.exit(1)

# Detect which LangChain provider package is available
_llm_instance = None
_llm_label = ""

try:
    if PROVIDER == "openai":
        from langchain_openai import ChatOpenAI
        _llm_instance = ChatOpenAI(model=MODEL, temperature=0)
        _llm_label = f"ChatOpenAI({MODEL})"
    elif PROVIDER == "anthropic":
        from langchain_anthropic import ChatAnthropic
        _llm_instance = ChatAnthropic(model=MODEL, temperature=0)
        _llm_label = f"ChatAnthropic({MODEL})"
    elif PROVIDER == "google":
        from langchain_google_genai import ChatGoogleGenerativeAI
        _llm_instance = ChatGoogleGenerativeAI(model=MODEL, temperature=0)
        _llm_label = f"ChatGoogleGenerativeAI({MODEL})"
except ImportError:
    pass

if _llm_instance is None:
    print(f"\n  LangChain provider package not installed for {PROVIDER}.")
    print(f"  Install one of:")
    print(f"    pip install langchain-openai       (for OpenAI)")
    print(f"    pip install langchain-anthropic     (for Anthropic)")
    print(f"    pip install langchain-google-genai  (for Google)")
    sys.exit(1)


def main():
    from stateloom.ext.langchain import StateLoomCallbackHandler

    # auto_patch=True (default) — LangChain's SDK calls flow through the full
    # middleware pipeline. The callback handler auto-detects this and only
    # records tool events to avoid double-counting LLM calls.
    gate = init_gate()

    handler = StateLoomCallbackHandler()
    print(f"  LLM: {_llm_label}")
    print(f"  Integration: auto_patch + StateLoomCallbackHandler (recommended)")
    print(f"  Middleware pipeline: PII scanning, guardrails, budget enforcement, etc.")

    # -----------------------------------------------------------------------
    # Scenario 1: Auto-patch + callback (recommended)
    # -----------------------------------------------------------------------
    header("Auto-patch + callback — full middleware pipeline")

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a concise technical writer."),
        ("user", "{question}"),
    ])
    chain = prompt | _llm_instance | StrOutputParser()

    with stateloom.session(session_id="langchain-chain", name="LangChain Chain") as s:
        result = chain.invoke(
            {"question": "Explain what a callback handler is in 2 sentences."},
            config={"callbacks": [handler]},
        )
        print(f"  Chain output: {result[:120]}...")
        print(f"\n  StateLoom tracked (via middleware pipeline):")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")
        print(f"    Calls:  {s.call_count}")

    pause(
        "Sessions tab: click 'langchain-chain' — the LLM call was recorded\n"
        "  >> via the middleware pipeline with full PII/guardrail/budget enforcement.\n"
        "  >> Click an event — metadata includes langchain.run_id, chain_name, tags."
    )

    # -----------------------------------------------------------------------
    # Scenario 2: Multi-step pipeline — each step tracked
    # -----------------------------------------------------------------------
    header("Multi-step pipeline — outline -> expand -> summarize")

    outline_prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a content strategist. Be concise."),
        ("user", "Write a 3-bullet outline about: {topic}"),
    ])
    expand_prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a writer. Keep it to 2 short paragraphs."),
        ("user", "Expand this outline into prose:\n{outline}"),
    ])
    summarize_prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an editor. One sentence only."),
        ("user", "Summarize this article in one sentence:\n{article}"),
    ])

    with stateloom.session(session_id="langchain-pipeline", name="LangChain Pipeline") as s:
        config = {"callbacks": [handler]}

        # Step 1: Outline
        outline_chain = outline_prompt | _llm_instance | StrOutputParser()
        outline = outline_chain.invoke({"topic": "AI observability"}, config=config)
        print(f"  Step 1 (outline): {outline[:100]}...")
        print(f"    Cost so far: ${s.total_cost:.6f}")

        # Step 2: Expand
        expand_chain = expand_prompt | _llm_instance | StrOutputParser()
        article = expand_chain.invoke({"outline": outline}, config=config)
        print(f"  Step 2 (expand):  {article[:100]}...")
        print(f"    Cost so far: ${s.total_cost:.6f}")

        # Step 3: Summarize
        summary_chain = summarize_prompt | _llm_instance | StrOutputParser()
        summary = summary_chain.invoke({"article": article}, config=config)
        print(f"  Step 3 (summary): {summary[:100]}...")

        print(f"\n  Pipeline complete:")
        print(f"    Total calls:  {s.call_count}")
        print(f"    Total cost:   ${s.total_cost:.6f}")
        print(f"    Total tokens: {s.total_tokens}")

    pause(
        "Sessions tab: 'langchain-pipeline' — 3 LLM call events from the pipeline.\n"
        "  >> Each step shows model, cost, and latency in the waterfall view."
    )

    # -----------------------------------------------------------------------
    # Scenario 3: Budget enforcement (works via middleware pipeline)
    # -----------------------------------------------------------------------
    header("Budget enforcement — middleware pipeline stops chains at budget limit")

    print("  With auto_patch=True, BudgetEnforcer in the middleware pipeline")
    print("  intercepts the underlying SDK call and enforces the budget.\n")

    with stateloom.session(
        session_id="langchain-budget",
        name="LangChain Budget",
        budget=0.0003,
    ) as s:
        simple_chain = (
            ChatPromptTemplate.from_messages([("user", "{q}")])
            | _llm_instance
            | StrOutputParser()
        )

        try:
            for i in range(5):
                result = simple_chain.invoke(
                    {"q": f"Write a haiku about the number {i+1}"},
                    config={"callbacks": [handler]},
                )
                print(f"  Call {i+1}: {result[:60]}...  (${s.total_cost:.6f})")
        except stateloom.StateLoomBudgetError as e:
            print(f"\n  BLOCKED: {e}")
            print(f"  BudgetEnforcer in the middleware pipeline stopped the chain.")

    pause("Sessions tab: 'langchain-budget' — budget enforcement on a LangChain chain")

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n  LangChain + StateLoom summary:")
    print("  - Recommended: auto_patch=True + StateLoomCallbackHandler()")
    print("    Full middleware pipeline (PII, guardrails, budget) + tool tracking")
    print("    LangChain metadata (run_id, chain_name, tags) flows into event.metadata")
    print("  - Standalone: auto_patch=False + StateLoomCallbackHandler(tools_only=False)")
    print("    Observability only — no middleware enforcement (use for logging/metrics)")
    print("  - Pass callbacks=[handler] to any chain.invoke() or agent.invoke()")
    print("  - Works with ChatOpenAI, ChatAnthropic, ChatGoogleGenerativeAI, etc.")

    wait_for_exit()


if __name__ == "__main__":
    main()
