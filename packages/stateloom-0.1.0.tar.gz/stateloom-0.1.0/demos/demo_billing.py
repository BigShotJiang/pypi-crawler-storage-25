#!/usr/bin/env python3
"""Demo: API vs Subscription Billing Modes

Demonstrates how StateLoom differentiates between API-billed users
(per-token pricing) and subscription users (Claude Max, ChatGPT Plus)
who pay a flat monthly fee. Both track estimated API cost for comparison.

Monitor at http://localhost:4781 → Sessions tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # -----------------------------------------------------------------------
    # Scenario 1: API billing (default) — actual cost equals estimated cost
    # -----------------------------------------------------------------------
    header("API billing (default) — per-token cost tracking")

    with stateloom.session(
        session_id="billing-api",
        name="API Billing",
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": "What is the difference between API and subscription billing?"},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"\n  Billing mode:       API (default)")
        print(f"  Actual cost:        ${s.total_cost:.6f}")
        print(f"  Estimated API cost: ${s.estimated_api_cost:.6f}")
        print(f"  Equal: {abs(s.total_cost - s.estimated_api_cost) < 0.000001}")

    pause("Sessions tab: 'billing-api' — cost and estimated_api_cost are equal")

    # -----------------------------------------------------------------------
    # Scenario 2: Subscription billing — actual cost is $0
    # -----------------------------------------------------------------------
    header("Subscription billing — flat fee, $0 actual cost")

    with stateloom.session(
        session_id="billing-subscription",
        name="Subscription Billing",
        metadata={"billing_mode": "subscription"},
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": "Explain how subscription-based AI billing works in one paragraph."},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"\n  Billing mode:       subscription")
        print(f"  Actual cost:        ${s.total_cost:.6f} (should be $0)")
        print(f"  Estimated API cost: ${s.estimated_api_cost:.6f} (what it would cost on API)")

    pause(
        "Sessions tab: 'billing-subscription' — total_cost is $0,\n"
        "  >> but estimated_api_cost shows what the call would cost on API billing."
    )

    # -----------------------------------------------------------------------
    # Scenario 3: Budget enforcement skipped for subscription
    # -----------------------------------------------------------------------
    stateloom.shutdown()
    gate = init_gate(budget=0.001)

    header("Budget skip for subscription — not blocked despite tiny budget")

    # API mode with $0.001 budget — should get blocked quickly
    print("  API mode with $0.001 budget:")
    with stateloom.session(
        session_id="billing-budget-api",
        name="Budget Test (API)",
        budget=0.001,
    ) as s:
        try:
            ask(user_msg("Write a haiku about cloud computing."))
            print(f"    First call: ${s.total_cost:.6f}")
            ask(user_msg("Write another haiku about machine learning."))
            print(f"    Second call: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError:
            print(f"    BLOCKED — budget exceeded at ${s.total_cost:.6f}")

    # Subscription mode with $0.001 budget — should NOT be blocked
    print(f"\n  Subscription mode with $0.001 budget:")
    with stateloom.session(
        session_id="billing-budget-sub",
        name="Budget Test (Subscription)",
        budget=0.001,
        metadata={"billing_mode": "subscription"},
    ) as s:
        ask(user_msg("Write a haiku about cloud computing."))
        print(f"    First call: ${s.total_cost:.6f} (actual)")
        ask(user_msg("Write another haiku about machine learning."))
        print(f"    Second call: ${s.total_cost:.6f} (actual)")
        print(f"    NOT blocked — subscription sessions skip budget enforcement")
        print(f"    Estimated API cost: ${s.estimated_api_cost:.6f}")

    pause(
        "Sessions tab: compare 'Budget Test (API)' vs 'Budget Test (Subscription)'.\n"
        "  >> API session was blocked by budget; subscription session was not."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
