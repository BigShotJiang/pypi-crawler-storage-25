#!/usr/bin/env python3
"""Demo: LangGraph Integration — Agent Workflows with Tool Observability

StateLoom tracks both LLM calls and tool invocations in LangGraph agent
workflows. Use the LangChain callback handler for LLM tracking and
patch_langgraph_tools() for automatic tool-level observability.

Every tool call, every LLM reasoning step — all visible in the dashboard
with cost tracking, latency, and session grouping.

Requires: pip install langgraph langchain-openai  (or langchain-anthropic)
          Plus at least one of OPENAI_API_KEY or ANTHROPIC_API_KEY.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import asyncio

# Check dependencies
try:
    from langgraph.prebuilt import create_react_agent
except ImportError:
    print("\n  This demo requires LangGraph:")
    print("  pip install langgraph")
    sys.exit(1)

try:
    from langchain_core.tools import tool as langchain_tool
except ImportError:
    print("\n  This demo requires langchain-core:")
    print("  pip install langchain-core")
    sys.exit(1)

# Detect LangChain LLM provider
_llm_instance = None
_llm_label = ""

try:
    if PROVIDER == "openai":
        from langchain_openai import ChatOpenAI
        _llm_instance = ChatOpenAI(model=MODEL, temperature=0)
        _llm_label = f"ChatOpenAI({MODEL})"
    elif PROVIDER == "anthropic":
        from langchain_anthropic import ChatAnthropic
        _llm_instance = ChatAnthropic(model=MODEL, temperature=0)
        _llm_label = f"ChatAnthropic({MODEL})"
    elif PROVIDER == "google":
        from langchain_google_genai import ChatGoogleGenerativeAI
        _llm_instance = ChatGoogleGenerativeAI(model=MODEL, temperature=0)
        _llm_label = f"ChatGoogleGenerativeAI({MODEL})"
except ImportError:
    pass

if _llm_instance is None:
    print(f"\n  LangChain provider package not installed for {PROVIDER}.")
    print(f"  Install one of:")
    print(f"    pip install langchain-openai       (for OpenAI)")
    print(f"    pip install langchain-anthropic     (for Anthropic)")
    print(f"    pip install langchain-google-genai  (for Google)")
    sys.exit(1)


# -----------------------------------------------------------------------
# Define tools for the agent
# -----------------------------------------------------------------------
@langchain_tool
def calculate(expression: str) -> str:
    """Evaluate a math expression and return the result."""
    try:
        # Safe eval for basic arithmetic
        allowed = set("0123456789+-*/(). ")
        if all(c in allowed for c in expression):
            return str(eval(expression))  # noqa: S307
        return "Error: only basic arithmetic is supported"
    except Exception as e:
        return f"Error: {e}"


@langchain_tool
def get_word_count(text: str) -> str:
    """Count the number of words in the given text."""
    count = len(text.split())
    return f"{count} words"


@langchain_tool
def reverse_string(text: str) -> str:
    """Reverse the given string."""
    return text[::-1]


def main():
    from stateloom.ext.langchain import StateLoomCallbackHandler
    from stateloom.ext.langgraph import patch_langgraph_tools

    # Use auto_patch=False since we use the callback handler
    gate = init_gate(auto_patch=False)

    # Patch LangGraph's ToolNode for tool-level observability
    patch_langgraph_tools(gate)

    handler = StateLoomCallbackHandler()
    print(f"  LLM: {_llm_label}")
    print(f"  Tools: calculate, get_word_count, reverse_string")
    print(f"  Integration: callback handler + patched ToolNode")

    # Create a ReAct agent with tools
    tools = [calculate, get_word_count, reverse_string]
    agent = create_react_agent(_llm_instance, tools)

    # -----------------------------------------------------------------------
    # Scenario 1: Agent uses a tool to answer a question
    # -----------------------------------------------------------------------
    header("Agent with tool use — math calculation")

    with stateloom.session(session_id="langgraph-calc", name="LangGraph Calculator") as s:
        result = asyncio.run(agent.ainvoke(
            {"messages": [("user", "What is 42 * 17 + 256? Use the calculate tool.")]},
            config={"callbacks": [handler]},
        ))
        last_msg = result["messages"][-1].content
        print(f"  Agent output: {last_msg[:120]}")
        print(f"\n  StateLoom tracked:")
        print(f"    Calls (LLM + tools): {s.call_count}")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")

    pause(
        "Sessions tab: 'langgraph-calc' — see both LLM reasoning and tool call events.\n"
        "  >> The waterfall shows the agent's think → tool → respond cycle."
    )

    # -----------------------------------------------------------------------
    # Scenario 2: Multi-tool agent workflow
    # -----------------------------------------------------------------------
    header("Multi-tool workflow — agent uses multiple tools")

    with stateloom.session(session_id="langgraph-multi", name="LangGraph Multi-Tool") as s:
        result = asyncio.run(agent.ainvoke(
            {"messages": [("user", (
                "Do these three things: "
                "1) Calculate 100 / 4, "
                "2) Count the words in 'The quick brown fox jumps over the lazy dog', "
                "3) Reverse the word 'StateLoom'. "
                "Report all results."
            ))]},
            config={"callbacks": [handler]},
        ))
        last_msg = result["messages"][-1].content
        print(f"  Agent output: {last_msg[:200]}")
        print(f"\n  StateLoom tracked:")
        print(f"    Calls (LLM + tools): {s.call_count}")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")

    pause(
        "Sessions tab: 'langgraph-multi' — multiple tool calls tracked.\n"
        "  >> Each tool shows name and latency in the waterfall view."
    )

    # -----------------------------------------------------------------------
    # Scenario 3: Agent without tools — pure reasoning
    # -----------------------------------------------------------------------
    header("Pure reasoning — no tools needed")

    with stateloom.session(session_id="langgraph-reason", name="LangGraph Reasoning") as s:
        result = asyncio.run(agent.ainvoke(
            {"messages": [("user", "What are three benefits of using an AI gateway? Be concise.")]},
            config={"callbacks": [handler]},
        ))
        last_msg = result["messages"][-1].content
        print(f"  Agent output: {last_msg[:200]}")
        print(f"\n  StateLoom tracked:")
        print(f"    Calls:  {s.call_count}")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")

    pause("Sessions tab: 'langgraph-reason' — LLM call only, no tool events")

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n  LangGraph + StateLoom summary:")
    print("  - patch_langgraph_tools() auto-wraps ToolNode for tool observability")
    print("  - StateLoomCallbackHandler tracks LLM calls in the agent loop")
    print("  - Both LLM reasoning and tool execution visible in the dashboard")
    print("  - Works with create_react_agent, StateGraph, and custom graphs")
    print("  - Cost, latency, and token tracking for the full agent workflow")

    wait_for_exit()


if __name__ == "__main__":
    main()
