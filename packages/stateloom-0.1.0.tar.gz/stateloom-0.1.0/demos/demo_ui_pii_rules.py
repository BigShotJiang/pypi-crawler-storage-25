#!/usr/bin/env python3
"""Demo: Toggle PII Rules at Runtime via Dashboard API

Starts with PII disabled, then adds/removes rules through the REST API and
verifies each change affects how the next LLM call is handled.

Endpoints exercised:
  PATCH  /api/v1/config          (pii_enabled)
  GET    /api/v1/pii/rules
  POST   /api/v1/pii/rules       (add single rule)
  PUT    /api/v1/pii/rules       (replace all rules)
  DELETE /api/v1/pii/rules/{pat} (delete one rule)
  DELETE /api/v1/pii/rules       (clear all rules)
  GET    /api/v1/pii             (detection history)
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(pii=False)  # start with PII OFF

    email_prompt = "Send the invoice to alice@example.com and copy bob@corp.org"
    phone_prompt = "Call me at 555-867-5309 or my office 415-555-0199"
    ssn_prompt   = "My social security number is 123-45-6789"

    # -----------------------------------------------------------------------
    # 1. PII disabled — everything passes through
    # -----------------------------------------------------------------------
    header("PII disabled — sensitive data passes through")
    with stateloom.session(session_id="pii-off", name="PII Off") as s:
        r = ask([
            {"role": "system", "content": "Echo back the user message verbatim."},
            {"role": "user", "content": email_prompt},
        ])
        print(f"  Response: {r.content[:100]}...")
        print(f"  PII detections: {s.pii_detections} (expected 0)")

    pause("Sessions tab: 'pii-off' — no PII events, email passed through")

    # -----------------------------------------------------------------------
    # 2. Enable PII via PATCH /config
    # -----------------------------------------------------------------------
    header("Enable PII scanning via PATCH /config")
    resp = api("PATCH", "/config", json={"pii_enabled": True})
    print(f"  PATCH pii_enabled=True → {resp.status_code}")

    # Verify
    rules_resp = api("GET", "/pii/rules")
    print(f"  Rules: {rules_resp.json()}")

    # -----------------------------------------------------------------------
    # 3. Add email redact rule
    # -----------------------------------------------------------------------
    header("POST /pii/rules — add email redaction rule")
    resp = api("POST", "/pii/rules", json={
        "pattern": "email",
        "mode": "redact",
    })
    print(f"  POST status: {resp.status_code}")

    with stateloom.session(session_id="pii-email-redact", name="Email Redacted") as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": email_prompt},
        ])
        print(f"  Response: {r.content[:100]}...")
        print(f"  PII detections: {s.pii_detections}")
        if s.pii_detections > 0:
            print(f"  ✓ Emails were redacted before reaching the LLM")

    pause("Sessions tab: 'pii-email-redact' — PII_REDACTED event for email addresses")

    # -----------------------------------------------------------------------
    # 4. Add SSN block rule
    # -----------------------------------------------------------------------
    header("POST /pii/rules — add SSN block rule")
    resp = api("POST", "/pii/rules", json={
        "pattern": "ssn",
        "mode": "block",
        "on_middleware_failure": "block",
    })
    print(f"  POST status: {resp.status_code}")

    with stateloom.session(session_id="pii-ssn-block", name="SSN Blocked") as s:
        try:
            r = ask([
                {"role": "system", "content": "You are an HR assistant."},
                {"role": "user", "content": ssn_prompt},
            ])
            print(f"  Response: {r.content[:60]}...")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  ✓ BLOCKED: {e}")

    pause("Sessions tab: 'pii-ssn-block' — PII_BLOCKED event. No LLM call was made.")

    # -----------------------------------------------------------------------
    # 5. List all current rules
    # -----------------------------------------------------------------------
    header("GET /pii/rules — list all active rules")
    resp = api("GET", "/pii/rules")
    data = resp.json()
    print(f"  PII enabled: {data.get('pii_enabled')}")
    print(f"  Rules ({len(data.get('rules', []))}):")
    for rule in data.get("rules", []):
        print(f"    - pattern={rule['pattern']}  mode={rule['mode']}")

    # -----------------------------------------------------------------------
    # 6. Replace ALL rules with just phone
    # -----------------------------------------------------------------------
    header("PUT /pii/rules — replace all with phone-only rule")
    resp = api("PUT", "/pii/rules", json={
        "rules": [
            {"pattern": "phone", "mode": "redact"},
        ],
    })
    print(f"  PUT status: {resp.status_code}")

    # Email should now pass through
    with stateloom.session(session_id="pii-email-passes", name="Email Passes") as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": email_prompt},
        ])
        print(f"  Email call: {r.content[:80]}...")
        print(f"  PII detections: {s.pii_detections}")
        if s.pii_detections == 0:
            print(f"  ✓ Email passes through (rule removed)")

    # Phone should be redacted
    with stateloom.session(session_id="pii-phone-redact", name="Phone Redacted") as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": phone_prompt},
        ])
        print(f"  Phone call: {r.content[:80]}...")
        print(f"  PII detections: {s.pii_detections}")
        if s.pii_detections > 0:
            print(f"  ✓ Phone numbers redacted")

    pause(
        "Sessions tab: 'pii-email-passes' has no PII events; 'pii-phone-redact' has redaction.\n"
        "  >> Only phone rule is active now."
    )

    # -----------------------------------------------------------------------
    # 7. Delete specific rule
    # -----------------------------------------------------------------------
    header("DELETE /pii/rules/phone — remove phone rule")
    resp = api("DELETE", "/pii/rules/phone")
    print(f"  DELETE status: {resp.status_code}")

    with stateloom.session(session_id="pii-phone-passes", name="Phone Passes") as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": phone_prompt},
        ])
        print(f"  Phone call: {r.content[:80]}...")
        print(f"  PII detections: {s.pii_detections}")
        if s.pii_detections == 0:
            print(f"  ✓ Phone passes through (rule deleted)")

    # -----------------------------------------------------------------------
    # 8. Clear all rules
    # -----------------------------------------------------------------------
    header("DELETE /pii/rules — clear all rules")
    resp = api("DELETE", "/pii/rules")
    print(f"  DELETE status: {resp.status_code}")

    rules_resp = api("GET", "/pii/rules")
    print(f"  Remaining rules: {len(rules_resp.json().get('rules', []))}")

    # -----------------------------------------------------------------------
    # 9. Disable PII entirely
    # -----------------------------------------------------------------------
    header("PATCH /config → pii_enabled=False")
    resp = api("PATCH", "/config", json={"pii_enabled": False})
    print(f"  PATCH status: {resp.status_code}")

    with stateloom.session(session_id="pii-all-off", name="PII All Off") as s:
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": f"{email_prompt}. Also {ssn_prompt}."},
        ])
        print(f"  Combined call: {r.content[:80]}...")
        print(f"  PII detections: {s.pii_detections}")
        if s.pii_detections == 0:
            print(f"  ✓ All PII passes through (scanning disabled)")

    # -----------------------------------------------------------------------
    # 10. Query historical PII detections
    # -----------------------------------------------------------------------
    header("GET /pii — historical detections")
    resp = api("GET", "/pii")
    data = resp.json()
    detections = data.get("detections", data.get("events", []))
    print(f"  Total historical detections: {len(detections) if isinstance(detections, list) else detections}")

    pause(
        "Compliance > PII Monitor: see all historical detections across the demo.\n"
        "  >> Email redactions, SSN blocks, phone redactions — all logged even after disabling."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
