#!/usr/bin/env python3
"""Demo: Budget Enforcement — monitor at http://localhost:4781

Real-world scenario: An AI writing assistant with per-session spending caps.
Demonstrates soft warnings and hard budget stops.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(budget=0.50, budget_on_middleware_failure="block")

    # --- Scenario 1: Normal usage under budget ---
    header("Writing assistant — normal usage under budget")
    with stateloom.session(session_id="writer-session-1", name="Blog Post Draft", budget=0.10) as s:
        r = ask([
            {"role": "system", "content": "You are a content writer. Keep responses under 100 words."},
            {"role": "user", "content": "Write a short intro paragraph for a blog about AI in healthcare."},
        ])
        print(f"  Draft: {r.content[:120]}...")
        print(f"  Cost: ${s.total_cost:.6f} / Budget: ${s.budget}")

    pause("Sessions tab: click 'writer-session-1' — cost bar should be green (under budget)")

    # --- Scenario 2: Tight budget gets exceeded ---
    header("Writing assistant — budget exceeded mid-conversation")
    with stateloom.session(
        session_id="writer-session-2",
        name="Budget Exceeded",
        budget=0.001,  # extremely tight budget
    ) as s:
        try:
            r1 = ask([
                {"role": "system", "content": "You are a content writer."},
                {"role": "user", "content": "Write a detailed 500-word article about renewable energy trends."},
            ])
            print(f"  Call 1 cost: ${s.total_cost:.6f}")

            r2 = ask([
                {"role": "system", "content": "You are a content writer."},
                {"role": "user", "content": "Now expand that into a 1000-word whitepaper with statistics."},
            ])
            print(f"  Call 2 cost: ${s.total_cost:.6f}")

            r3 = ask([
                {"role": "system", "content": "You are a content writer."},
                {"role": "user", "content": "Add an executive summary and conclusion."},
            ])
            print(f"  Call 3 cost: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"  BLOCKED: {e}")
            print(f"  Final cost: ${s.total_cost:.6f} / Budget: ${s.budget}")

    pause(
        "Sessions tab: click 'writer-session-2' — see LLM call(s) then a budget_enforcement event.\n"
        "  >> The budget bar should be red (exceeded)."
    )

    # --- Scenario 3: Multiple sessions tracking cost ---
    header("Multiple sessions with different budgets")
    for i, (budget, topic) in enumerate([
        (0.05, "Summarize the benefits of microservices architecture"),
        (0.05, "Explain the CAP theorem in simple terms"),
        (0.05, "What are the pros and cons of serverless computing?"),
    ], start=1):
        with stateloom.session(
            session_id=f"research-{i}",
            name=f"Research Query {i}",
            budget=budget,
        ) as s:
            r = ask(user_msg(topic))
            print(f"  Q{i}: {r.content[:80]}...")
            print(f"      Cost: ${s.total_cost:.6f} / ${budget}")

    pause(
        "Sessions tab: 5 sessions total — each with its own budget tracking.\n"
        "  >> Overview: aggregated cost across all sessions."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
