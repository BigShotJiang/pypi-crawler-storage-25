#!/usr/bin/env python3
"""Demo: Kill Switch — monitor at http://localhost:4781

Real-world scenario: Emergency shutdown during a production incident.
The kill switch blocks all LLM traffic instantly — globally or by model/provider.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # --- Scenario 1: Normal call works ---
    header("Normal operation — LLM calls go through")
    with stateloom.session(session_id="ks-normal", name="Normal Operation") as s:
        r = ask(user_msg("What is the capital of Japan?"))
        print(f"  Response: {r.content[:80]}...")
        print(f"  Call succeeded. Cost: ${s.total_cost:.6f}")

    pause("Sessions tab: 'ks-normal' shows a successful LLM call")

    # --- Scenario 2: Global kill switch ---
    header("GLOBAL KILL SWITCH — block ALL LLM traffic")
    stateloom.kill_switch(active=True, message="Emergency: billing anomaly detected")
    print("  Kill switch ACTIVATED!")

    with stateloom.session(session_id="ks-blocked-global", name="Blocked (Global)") as s:
        try:
            r = ask(user_msg("This should be blocked."))
            print(f"  Response: {r.content[:80]}...")
        except stateloom.StateLoomKillSwitchError as e:
            print(f"  BLOCKED: {e}")

    stateloom.kill_switch(active=False)
    print("  Kill switch deactivated.")

    pause(
        "Sessions tab: click 'ks-blocked-global' — see KILL_SWITCH event.\n"
        "  >> Safety > Kill Switch: toggle was activated then deactivated."
    )

    # --- Scenario 3: Granular rules (block specific models) ---
    header("Granular kill switch — block specific model patterns")
    stateloom.add_kill_switch_rule(
        model="gpt-4o",
        reason="GPT-4o cost spike — temporarily blocked",
        message="GPT-4o is temporarily unavailable due to cost controls.",
    )
    stateloom.add_kill_switch_rule(
        provider="anthropic",
        reason="Anthropic API instability reported",
        message="Anthropic models temporarily blocked.",
    )
    rules = stateloom.kill_switch_rules()
    print(f"  Active rules: {len(rules)}")
    for rule in rules:
        print(f"    - model={rule.get('model')}  provider={rule.get('provider')}  reason={rule.get('reason')}")

    # This call should still work (using the default model which may not match rules)
    with stateloom.session(session_id="ks-rules-test", name="Rules Test") as s:
        try:
            r = ask(user_msg("Does this call go through?"))
            print(f"\n  Call with {MODEL}: {'BLOCKED' if False else 'PASSED'}")
            print(f"  Response: {r.content[:60]}...")
        except stateloom.StateLoomKillSwitchError as e:
            print(f"\n  Call with {MODEL}: BLOCKED by rule")
            print(f"  Error: {e}")

    stateloom.clear_kill_switch_rules()
    print("\n  All kill switch rules cleared.")

    pause(
        "Safety > Kill Switch: see the rules that were configured.\n"
        "  >> Kill switch events show which rule matched (if any)."
    )

    # --- Scenario 4: Verify normal operation resumes ---
    header("Post-incident — verify normal operation")
    with stateloom.session(session_id="ks-recovered", name="Post-Recovery") as s:
        r = ask(user_msg("Confirm that service is restored."))
        print(f"  Response: {r.content[:80]}...")
        print(f"  Service restored! Cost: ${s.total_cost:.6f}")

    pause("Sessions tab: 'ks-recovered' shows successful call — back to normal")

    wait_for_exit()


if __name__ == "__main__":
    main()
