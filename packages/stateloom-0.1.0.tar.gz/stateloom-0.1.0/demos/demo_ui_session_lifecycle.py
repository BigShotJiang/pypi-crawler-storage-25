#!/usr/bin/env python3
"""Demo: Session Cancel, Suspend/Signal, Feedback, Export/Import, Async Jobs

Manages session lifecycle through the dashboard API — cancelling running
sessions, suspending and resuming with signals, adding feedback, exporting
and importing session bundles, and managing async jobs.

Endpoints exercised:
  GET    /api/v1/sessions
  GET    /api/v1/sessions/{id}
  GET    /api/v1/sessions/{id}/events
  GET    /api/v1/sessions/{id}/children
  POST   /api/v1/sessions/{id}/cancel
  POST   /api/v1/sessions/{id}/feedback
  GET    /api/v1/sessions/{id}/feedback
  GET    /api/v1/sessions/{id}/export
  POST   /api/v1/sessions/import
  POST   /api/v1/jobs
  GET    /api/v1/jobs
  GET    /api/v1/jobs/stats
  GET    /api/v1/jobs/{id}
  DELETE /api/v1/jobs/{id}
"""

import sys, os, threading, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(async_jobs_enabled=True)

    # -----------------------------------------------------------------------
    # 1. Create sessions with parent-child relationship
    # -----------------------------------------------------------------------
    header("Create parent + child sessions")
    with stateloom.session(session_id="sl-parent", name="Parent Session") as parent:
        r = ask(user_msg("What is Python? One sentence."))
        print(f"  Parent: {r.content[:80]}")

        with stateloom.session(
            session_id="sl-child-1",
            name="Child Session 1",
        ) as child1:
            r = ask(user_msg("What is JavaScript? One sentence."))
            print(f"  Child 1: {r.content[:80]}")

        with stateloom.session(
            session_id="sl-child-2",
            name="Child Session 2",
        ) as child2:
            r = ask(user_msg("What is Rust? One sentence."))
            print(f"  Child 2: {r.content[:80]}")

    # -----------------------------------------------------------------------
    # 2. List sessions
    # -----------------------------------------------------------------------
    header("GET /sessions — list all sessions")
    resp = api("GET", "/sessions")
    sessions = resp.json()
    sessions_list = sessions if isinstance(sessions, list) else sessions.get("sessions", [])
    print(f"  Total sessions: {len(sessions_list)}")
    for s in sessions_list[:5]:
        print(f"    - {s.get('id', '')[:20]}  name={s.get('name')}  "
              f"status={s.get('status')}")

    # -----------------------------------------------------------------------
    # 3. Get session detail + events
    # -----------------------------------------------------------------------
    header("GET /sessions/{id} and /sessions/{id}/events")
    resp = api("GET", "/sessions/sl-parent")
    detail = resp.json()
    print(f"  Session: {detail.get('name')}")
    print(f"  Status:  {detail.get('status')}")
    print(f"  Cost:    ${detail.get('total_cost', 0):.6f}")
    print(f"  Calls:   {detail.get('call_count', 0)}")

    resp = api("GET", "/sessions/sl-parent/events")
    events = resp.json()
    events_list = events if isinstance(events, list) else events.get("events", [])
    print(f"\n  Events: {len(events_list)}")
    for e in events_list[:5]:
        print(f"    - type={e.get('event_type')}  model={e.get('model', 'N/A')}")

    # -----------------------------------------------------------------------
    # 4. Get children
    # -----------------------------------------------------------------------
    header("GET /sessions/{id}/children — parent-child hierarchy")
    resp = api("GET", "/sessions/sl-parent/children")
    children = resp.json()
    children_list = children if isinstance(children, list) else children.get("children", children.get("sessions", []))
    print(f"  Children of sl-parent: {len(children_list)}")
    for c in children_list:
        print(f"    - {c.get('id', '')[:20]}  name={c.get('name')}")

    pause("Sessions tab: click sl-parent → see children listed")

    # -----------------------------------------------------------------------
    # 5. Add feedback
    # -----------------------------------------------------------------------
    header("POST /sessions/{id}/feedback — add rating & comment")
    resp = api("POST", "/sessions/sl-parent/feedback", json={
        "rating": "positive",
        "score": 0.9,
        "comment": "Great responses, fast and accurate!",
    })
    print(f"  POST feedback: {resp.status_code}")

    resp = api("GET", "/sessions/sl-parent/feedback")
    feedback = resp.json()
    print(f"  Feedback: {feedback}")

    pause("Sessions tab: sl-parent should show feedback indicator (thumbs up)")

    # -----------------------------------------------------------------------
    # 6. Cancel a session
    # -----------------------------------------------------------------------
    header("POST /sessions/{id}/cancel — cancel a session")
    # Create a session first
    with stateloom.session(session_id="sl-to-cancel", name="Will Be Cancelled") as s:
        r = ask(user_msg("This session will be cancelled. Say OK."))
        print(f"  Response: {r.content[:40]}")

    resp = api("POST", "/sessions/sl-to-cancel/cancel")
    print(f"  Cancel status: {resp.status_code}")

    # Verify it's cancelled
    resp = api("GET", "/sessions/sl-to-cancel")
    detail = resp.json()
    print(f"  Session status: {detail.get('status')}")

    pause("Sessions tab: sl-to-cancel shows CANCELLED status")

    # -----------------------------------------------------------------------
    # 7. Export session
    # -----------------------------------------------------------------------
    header("GET /sessions/{id}/export — export with children")
    resp = api("GET", "/sessions/sl-parent/export", params={
        "include_children": "true",
        "scrub_pii": "false",
    })
    print(f"  Export status: {resp.status_code}")
    if resp.status_code == 200:
        bundle = resp.json()
        print(f"  Bundle keys: {list(bundle.keys())}")
        bundle_sessions = bundle.get("sessions", [bundle.get("session", {})])
        if isinstance(bundle_sessions, list):
            print(f"  Sessions in bundle: {len(bundle_sessions)}")
        print(f"  Bundle size: {len(str(bundle))} chars")
    else:
        bundle = None
        print(f"  Export failed: {resp.text[:150]}")

    # -----------------------------------------------------------------------
    # 8. Import session
    # -----------------------------------------------------------------------
    header("POST /sessions/import — import with new session ID")
    if bundle:
        resp = api("POST", "/sessions/import", json={
            "bundle": bundle,
            "session_id_override": "sl-imported",
        })
        print(f"  Import status: {resp.status_code}")
        if resp.status_code in (200, 201):
            imported = resp.json()
            print(f"  Imported session: {imported.get('session_id', imported.get('id', 'N/A'))}")
        else:
            print(f"  Import response: {resp.text[:200]}")

        # Verify the import
        resp = api("GET", "/sessions/sl-imported")
        if resp.status_code == 200:
            detail = resp.json()
            print(f"  Verified: name={detail.get('name')}  cost=${detail.get('total_cost', 0):.6f}")
            print(f"  ✓ Session exported and re-imported successfully")
    else:
        print(f"  (Skipped — export failed)")

    pause("Sessions tab: sl-imported should appear with same data as sl-parent")

    # -----------------------------------------------------------------------
    # 9. Submit async job
    # -----------------------------------------------------------------------
    header("POST /jobs — submit async job")
    resp = api("POST", "/jobs", json={
        "model": MODEL,
        "messages": [{"role": "user", "content": "What is 7*8? Just the number."}],
        "session_id": "sl-async-job",
        "max_retries": 1,
        "ttl_seconds": 300,
        "metadata": {"source": "demo"},
    })
    print(f"  POST status: {resp.status_code}")
    job = resp.json()
    job_id = job.get("id", job.get("job_id", ""))
    print(f"  Job ID: {job_id}")
    print(f"  Status: {job.get('status', 'submitted')}")

    # Wait a moment for job to process
    time.sleep(2)

    # -----------------------------------------------------------------------
    # 10. List jobs
    # -----------------------------------------------------------------------
    header("GET /jobs — list all jobs")
    resp = api("GET", "/jobs")
    jobs = resp.json()
    jobs_list = jobs if isinstance(jobs, list) else jobs.get("jobs", [])
    print(f"  Total jobs: {len(jobs_list)}")
    for j in jobs_list[:5]:
        print(f"    - id={j.get('id', '')[:20]}  status={j.get('status')}  "
              f"model={j.get('model', 'N/A')}")

    # -----------------------------------------------------------------------
    # 11. Job stats
    # -----------------------------------------------------------------------
    header("GET /jobs/stats — aggregate statistics")
    resp = api("GET", "/jobs/stats")
    stats = resp.json()
    print(f"  Job stats: {stats}")

    # -----------------------------------------------------------------------
    # 12. Get specific job
    # -----------------------------------------------------------------------
    if job_id:
        header(f"GET /jobs/{job_id[:15]}... — job detail")
        resp = api("GET", f"/jobs/{job_id}")
        if resp.status_code == 200:
            detail = resp.json()
            print(f"  Status: {detail.get('status')}")
            print(f"  Model:  {detail.get('model')}")
            result = detail.get("result", {})
            if result:
                content = result.get("content", result.get("choices", [{}]))
                print(f"  Result: {str(content)[:80]}")
        else:
            print(f"  Job detail: {resp.status_code}")

    # -----------------------------------------------------------------------
    # 13. Submit and cancel a job
    # -----------------------------------------------------------------------
    header("Submit + cancel job")
    resp = api("POST", "/jobs", json={
        "model": MODEL,
        "messages": [{"role": "user", "content": "Write a 1000-word essay."}],
        "max_retries": 0,
        "ttl_seconds": 60,
    })
    cancel_job = resp.json()
    cancel_id = cancel_job.get("id", cancel_job.get("job_id", ""))
    print(f"  Submitted job: {cancel_id[:20]}...")

    if cancel_id:
        resp = api("DELETE", f"/jobs/{cancel_id}")
        print(f"  DELETE (cancel) status: {resp.status_code}")
        if resp.status_code in (200, 204):
            print(f"  ✓ Job cancelled")
        else:
            print(f"  Response: {resp.text[:100]} (may have already completed)")

    pause(
        "Sessions tab: see parent-child sessions, feedback, cancelled session.\n"
        "  >> Jobs tab: see submitted and cancelled jobs."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
