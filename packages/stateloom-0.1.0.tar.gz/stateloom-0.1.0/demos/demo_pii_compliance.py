#!/usr/bin/env python3
"""Demo: PII + Compliance + Teams — monitor at http://localhost:4781

Real-world scenario: An enterprise has multiple teams under different
compliance regimes. PII rules are NOT configured globally — they come
from each org's compliance profile and are auto-enforced per session.

Key point: no pii_rules= in init_gate(). Compliance profiles bring their
own PII rules, and the strictest-wins merging ensures nothing slips through.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    # NOTE: pii=True enables the scanner, but NO global pii_rules.
    # All rules come from compliance profiles attached to orgs.
    gate = init_gate(pii=True)

    # =========================================================================
    # Part 1: GDPR org — auto-blocks SSN, auto-redacts email
    # =========================================================================
    header("Create GDPR-compliant org (EU subsidiary)")
    eu_org = stateloom.create_organization(
        name="FinServ EU",
        budget=10.0,
        compliance_profile="gdpr",
        metadata={"region": "eu-west-1"},
    )
    eu_support = stateloom.create_team(eu_org.id, name="EU Support")
    print(f"  Org:  {eu_org.name} — compliance: GDPR")
    print(f"  Team: {eu_support.name}")
    print(f"  Auto-configured PII rules from GDPR profile:")
    for rule in eu_org.compliance_profile.pii_rules:
        print(f"    {rule.pattern:20s} → {rule.mode.upper()}")

    pause("Compliance > Organizations: see FinServ EU with GDPR badge")

    # --- GDPR Scenario 1: Email is auto-redacted ---
    header("GDPR — email auto-redacted (no manual rule needed)")
    with stateloom.session(
        session_id="gdpr-pii-email",
        name="EU Email Redaction",
        org_id=eu_org.id,
        team_id=eu_support.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a GDPR-aware support agent. Be concise."},
            {"role": "user", "content": "My email is hans.mueller@eurobank.de, please update my contact info."},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections}")

    pause(
        "Sessions tab: click 'gdpr-pii-email' — PII event shows email REDACTED.\n"
        "  >> The GDPR profile auto-applied 'email → REDACT' — no global rule needed."
    )

    # --- GDPR Scenario 2: SSN is auto-blocked ---
    header("GDPR — SSN auto-blocked by compliance profile")
    with stateloom.session(
        session_id="gdpr-pii-ssn",
        name="EU SSN Block",
        org_id=eu_org.id,
        team_id=eu_support.id,
    ) as s:
        try:
            r = ask([
                {"role": "system", "content": "You are a GDPR-aware support agent."},
                {"role": "user", "content": "My tax ID is 123-45-6789, can you file my return?"},
            ])
            print(f"  Response: {r.content[:80]}...")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  BLOCKED: {e}")
            print(f"  PII detections: {s.pii_detections}")

    pause("Sessions tab: 'gdpr-pii-ssn' — SSN blocked. No LLM call made.")

    # =========================================================================
    # Part 2: HIPAA org — stricter rules, blocks phone too
    # =========================================================================
    header("Create HIPAA-compliant org (US healthcare)")
    health_org = stateloom.create_organization(
        name="MedAssist Health",
        budget=10.0,
        compliance_profile="hipaa",
        metadata={"industry": "healthcare"},
    )
    clinical_team = stateloom.create_team(health_org.id, name="Clinical AI")
    print(f"  Org:  {health_org.name} — compliance: HIPAA")
    print(f"  Team: {clinical_team.name}")
    print(f"  Auto-configured PII rules from HIPAA profile:")
    for rule in health_org.compliance_profile.pii_rules:
        print(f"    {rule.pattern:25s} → {rule.mode.upper()}")

    pause("Compliance > Organizations: see MedAssist Health with HIPAA badge")

    # --- HIPAA Scenario 1: Email + phone in same message ---
    header("HIPAA — email redacted, phone redacted (both auto-configured)")
    with stateloom.session(
        session_id="hipaa-pii-mixed",
        name="HIPAA Mixed PII",
        org_id=health_org.id,
        team_id=clinical_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a medical records assistant. Be concise."},
            {"role": "user", "content": (
                "Please update patient contact info: "
                "email dr.smith@medclinic.org, phone 555-123-4567."
            )},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections} (should be 2: email + phone)")

    pause(
        "Sessions tab: click 'hipaa-pii-mixed' — 2 PII events:\n"
        "  >> email → REDACTED, phone → REDACTED.\n"
        "  >> Both rules came from the HIPAA compliance profile."
    )

    # --- HIPAA Scenario 2: SSN blocked ---
    header("HIPAA — SSN auto-blocked (same as GDPR, strictest wins)")
    with stateloom.session(
        session_id="hipaa-pii-ssn",
        name="HIPAA SSN Block",
        org_id=health_org.id,
        team_id=clinical_team.id,
    ) as s:
        try:
            r = ask([
                {"role": "user", "content": "Patient SSN is 987-65-4321, look up their records."},
            ])
            print(f"  Response: {r.content[:80]}...")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  BLOCKED: {e}")

    pause("Sessions tab: 'hipaa-pii-ssn' — SSN blocked under HIPAA rules")

    # =========================================================================
    # Part 3: CCPA org — blocks credit card, redacts email
    # =========================================================================
    header("Create CCPA-compliant org (California consumer)")
    ca_org = stateloom.create_organization(
        name="CalCommerce Inc",
        budget=10.0,
        compliance_profile="ccpa",
        metadata={"region": "US-CA"},
    )
    ca_team = stateloom.create_team(ca_org.id, name="Consumer Support")
    print(f"  Org:  {ca_org.name} — compliance: CCPA")
    print(f"  Auto-configured PII rules from CCPA profile:")
    for rule in ca_org.compliance_profile.pii_rules:
        print(f"    {rule.pattern:20s} → {rule.mode.upper()}")

    # --- CCPA Scenario: Credit card blocked, email redacted ---
    header("CCPA — credit card blocked, email redacted in same request")
    with stateloom.session(
        session_id="ccpa-pii-mixed",
        name="CCPA Mixed PII",
        org_id=ca_org.id,
        team_id=ca_team.id,
    ) as s:
        try:
            r = ask([
                {"role": "system", "content": "You are a consumer support agent."},
                {"role": "user", "content": (
                    "Process a refund to my card 4111-1111-1111-1111 "
                    "and email the confirmation to jane@example.com."
                )},
            ])
            print(f"  Response: {r.content[:80]}...")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  BLOCKED: {e}")
            print(f"  PII detections: {s.pii_detections}")

    pause(
        "Sessions tab: 'ccpa-pii-mixed' — credit card BLOCKED (strictest wins).\n"
        "  >> The email would have been redacted, but the block takes priority.\n"
        "  >> No LLM call was made."
    )

    # =========================================================================
    # Part 4: No compliance — same message passes through
    # =========================================================================
    header("No compliance org — same email passes through (PII scanner has no rules)")
    no_comp_org = stateloom.create_organization(name="StartupCo", budget=10.0)
    no_comp_team = stateloom.create_team(no_comp_org.id, name="Dev Team")
    print(f"  Org: {no_comp_org.name} — no compliance profile")

    with stateloom.session(
        session_id="no-compliance-pii",
        name="No Compliance",
        org_id=no_comp_org.id,
        team_id=no_comp_team.id,
    ) as s:
        r = ask([
            {"role": "user", "content": "Send the report to dev@startup.io and include the quarterly numbers."},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections} (should be 0 — no rules to match)")

    pause(
        "Sessions tab: 'no-compliance-pii' — NO PII events.\n"
        "  >> Same email pattern, but no compliance profile = no PII rules.\n"
        "  >> The scanner is enabled, but has nothing to enforce.\n"
        "  >> Compare with the GDPR session where the same email was redacted."
    )

    # =========================================================================
    # Part 5: Strictest-wins — org has AUDIT, compliance profile has BLOCK
    # =========================================================================
    header("Strictest-wins: org rule (AUDIT) + compliance (BLOCK) = BLOCK wins")
    strict_org = stateloom.create_organization(
        name="StrictBank",
        budget=10.0,
        compliance_profile="gdpr",
        pii_rules=[
            PIIRule(pattern="email", mode="audit"),  # org says AUDIT
        ],
        metadata={"note": "GDPR profile says REDACT for email — REDACT wins over AUDIT"},
    )
    strict_team = stateloom.create_team(strict_org.id, name="Risk Team")
    print(f"  Org rule:     email → AUDIT")
    print(f"  GDPR profile: email → REDACT")
    print(f"  Effective:    email → REDACT (strictest wins)")

    with stateloom.session(
        session_id="strict-merge",
        name="Strictest Wins",
        org_id=strict_org.id,
        team_id=strict_team.id,
    ) as s:
        r = ask([
            {"role": "user", "content": "Contact me at cfo@strictbank.com for the audit results."},
        ])
        print(f"  Response: {r.content[:120]}...")
        print(f"  PII detections: {s.pii_detections}")
        print(f"  (Email was REDACTED, not just audited — GDPR's REDACT > org's AUDIT)")

    pause(
        "Sessions tab: click 'strict-merge' — PII event shows REDACTED.\n"
        "  >> The org wanted AUDIT but GDPR profile wanted REDACT.\n"
        "  >> Strictest mode wins: BLOCK > REDACT > AUDIT.\n"
        "  >> This ensures compliance profiles can never be weakened."
    )

    # --- Final summary ---
    header("Summary: compliance-driven PII enforcement")
    print("  How it works:")
    print("    1. Create org with compliance_profile='gdpr' (or 'hipaa', 'ccpa')")
    print("    2. Compliance profile bundles PII rules (no manual config needed)")
    print("    3. Sessions scoped to org_id auto-inherit these rules")
    print("    4. PIIScannerMiddleware merges: global + org + compliance rules")
    print("    5. Strictest mode wins (BLOCK > REDACT > AUDIT)")
    print()
    print("  This demo used NO global pii_rules= in init().")
    print("  All PII enforcement came from compliance profiles on orgs.")

    pause(
        "Compliance > PII Monitor: see all detections grouped by org.\n"
        "  >> Compliance > Profiles: GDPR, HIPAA, CCPA badges on orgs.\n"
        "  >> Compare: GDPR redacts email, HIPAA redacts email+phone,\n"
        "     CCPA blocks credit card, no-compliance passes everything through."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
