#!/usr/bin/env python3
"""Demo: Named Checkpoints — monitor at http://localhost:4781

Real-world scenario: A multi-step data pipeline that marks progress
at each stage. Checkpoints appear as labeled dividers in the waterfall.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    header("Multi-step data pipeline with checkpoints")

    with stateloom.session(
        session_id="pipeline-run-42",
        name="Data Pipeline Run #42",
    ) as s:
        s.metadata["pipeline"] = "customer-insights"
        s.metadata["trigger"] = "scheduled-daily"

        # Step 1: Data extraction
        stateloom.checkpoint("extraction_start", "Beginning data extraction phase")
        r1 = ask([
            {"role": "system", "content": "You are a data engineer. Be concise and technical."},
            {"role": "user", "content": "Describe how to extract customer interaction data from a CRM API."},
        ])
        print(f"  [1] Extraction: {r1.content[:100]}...")
        stateloom.checkpoint("extraction_complete", "Data extracted: 50,000 records")

        # Step 2: Transformation
        stateloom.checkpoint("transform_start", "Beginning data transformation")
        r2 = ask([
            {"role": "system", "content": "You are a data engineer. Be concise."},
            {"role": "user", "content": "How would you normalize and clean CRM data for analytics?"},
        ])
        print(f"  [2] Transform: {r2.content[:100]}...")
        stateloom.checkpoint("transform_complete", "50,000 records cleaned and normalized")

        # Step 3: Analysis
        stateloom.checkpoint("analysis_start", "Running customer segmentation analysis")
        r3 = ask([
            {"role": "system", "content": "You are a data scientist. Be concise."},
            {"role": "user", "content": "What customer segments would you identify from CRM interaction data?"},
        ])
        print(f"  [3] Analysis: {r3.content[:100]}...")
        stateloom.checkpoint("analysis_complete", "Identified 5 customer segments")

        # Step 4: Report generation
        stateloom.checkpoint("report_start", "Generating executive report")
        r4 = ask([
            {"role": "system", "content": "You are a business analyst. Write a brief executive summary."},
            {"role": "user", "content": (
                f"Summarize these insights for the executive team:\n"
                f"- Extraction: {r1.content[:100]}\n"
                f"- Cleaning: {r2.content[:100]}\n"
                f"- Segments: {r3.content[:100]}"
            )},
        ])
        print(f"  [4] Report: {r4.content[:100]}...")
        stateloom.checkpoint("pipeline_complete", "Pipeline finished successfully")

        print(f"\n  Pipeline complete!")
        print(f"  Total cost: ${s.total_cost:.6f}")
        print(f"  Total calls: {s.call_count}")
        print(f"  Checkpoints: 8 (start/end for each phase)")

    pause(
        "Sessions tab: click 'pipeline-run-42' — see the waterfall timeline.\n"
        "  >> Checkpoints appear as labeled divider rows between LLM calls.\n"
        "  >> Each checkpoint shows its label and description.\n"
        "  >> Toggle between waterfall and flat event views."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
