#!/usr/bin/env python3
"""Demo: Runtime Config Changes — Budget, Cache, Loop Detection via Dashboard API

Demonstrates changing configuration at runtime through the dashboard REST API
and verifying the behavior changes in subsequent LLM calls.

Endpoints exercised:
  GET  /api/v1/config
  PATCH /api/v1/config  (budget_per_session, cache_ttl_seconds, loop_exact_threshold)
  GET  /api/v1/stats
  GET  /api/v1/stats/cost-by-model
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(budget=10.0, cache_enabled=True)

    # -----------------------------------------------------------------------
    # 1. Read baseline config
    # -----------------------------------------------------------------------
    header("Read baseline config via GET /config")
    resp = api("GET", "/config")
    cfg = resp.json()
    print(f"  budget_per_session : {cfg.get('budget_per_session')}")
    print(f"  cache_ttl_seconds  : {cfg.get('cache_ttl_seconds')}")
    print(f"  loop_exact_threshold: {cfg.get('loop_exact_threshold')}")
    print(f"  default_model      : {cfg.get('default_model')}")

    pause("Config tab: see all current settings")

    # -----------------------------------------------------------------------
    # 2. Baseline calls → stats
    # -----------------------------------------------------------------------
    header("Baseline LLM calls → verify in stats")
    with stateloom.session(session_id="cfg-baseline", name="Config Baseline") as s:
        r1 = ask(user_msg("What is 2+2? Reply with just the number."))
        print(f"  Call 1: {r1.content[:60]}")
        r2 = ask(user_msg("What is 3+3? Reply with just the number."))
        print(f"  Call 2: {r2.content[:60]}")
        print(f"  Total cost: ${s.total_cost:.6f}  Calls: {s.call_count}")

    resp = api("GET", "/stats")
    stats = resp.json()
    print(f"\n  GET /stats → total_cost: ${stats.get('total_cost', 0):.6f}  "
          f"total_calls: {stats.get('total_calls', 0)}")

    resp = api("GET", "/stats/cost-by-model")
    by_model = resp.json()
    print(f"  GET /stats/cost-by-model → {by_model}")

    pause("Stats tab: see cost and call counts")

    # -----------------------------------------------------------------------
    # 3. Cache hit test (baseline)
    # -----------------------------------------------------------------------
    header("Cache hit — same prompt returns cached response")
    prompt = "What color is the sky on a clear day? One word."
    with stateloom.session(session_id="cfg-cache-hit", name="Cache Hit Test") as s:
        r1 = ask(user_msg(prompt))
        cost1 = s.total_cost
        print(f"  Call 1 (miss):  {r1.content[:40]}  cost=${cost1:.6f}")

        r2 = ask(user_msg(prompt))
        cost2 = s.total_cost - cost1
        cached = getattr(r2, "_stateloom", {}).get("cached", False)
        print(f"  Call 2 (hit?):  {r2.content[:40]}  cost=${cost2:.6f}  cached={cached}")

    pause("Sessions tab: 'cfg-cache-hit' — second call should show CACHE_HIT event")

    # -----------------------------------------------------------------------
    # 4. Change cache TTL → verify cache miss
    # -----------------------------------------------------------------------
    header("PATCH /config → cache_ttl_seconds=1 → cache expires")
    resp = api("PATCH", "/config", json={"cache_ttl_seconds": 1})
    print(f"  PATCH status: {resp.status_code}")
    print(f"  Sleeping 2s for TTL expiry...")
    time.sleep(2)

    with stateloom.session(session_id="cfg-cache-expired", name="Cache Expired") as s:
        r1 = ask(user_msg(prompt))
        cost1 = s.total_cost
        r2 = ask(user_msg(prompt))
        cost2 = s.total_cost - cost1
        cached = getattr(r2, "_stateloom", {}).get("cached", False)
        print(f"  Call 1: cost=${cost1:.6f}")
        print(f"  Call 2: cost=${cost2:.6f}  cached={cached}")
        if cost2 > 0:
            print(f"  ✓ Cache expired — 2nd call was NOT cached (TTL=1s)")
        else:
            print(f"  ✓ Call was cached (may have been within TTL window)")

    # Restore TTL
    api("PATCH", "/config", json={"cache_ttl_seconds": 300})
    print(f"\n  Restored cache_ttl_seconds=300")

    pause("Sessions tab: 'cfg-cache-expired' — both calls are real LLM calls (no cache hit)")

    # -----------------------------------------------------------------------
    # 5. Tighten budget via API → verify enforcement
    # -----------------------------------------------------------------------
    header("PATCH /config → budget_per_session=0.0001 → budget blocks")
    resp = api("PATCH", "/config", json={"budget_per_session": 0.0001})
    print(f"  PATCH status: {resp.status_code}")

    # Verify the config changed
    cfg = api("GET", "/config").json()
    print(f"  Confirmed: budget_per_session={cfg.get('budget_per_session')}")

    with stateloom.session(session_id="cfg-tight-budget", name="Tight Budget") as s:
        try:
            r1 = ask(user_msg("Write a haiku about the ocean."))
            print(f"  Call 1: {r1.content[:60]}...  cost=${s.total_cost:.6f}")
            r2 = ask(user_msg("Write another haiku about mountains."))
            print(f"  Call 2: {r2.content[:60]}...  cost=${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"  ✓ BUDGET BLOCKED: {e}")
            print(f"    Final cost: ${s.total_cost:.6f}")

    # Restore budget
    api("PATCH", "/config", json={"budget_per_session": 10.0})
    print(f"\n  Restored budget_per_session=10.0")

    pause(
        "Sessions tab: 'cfg-tight-budget' — budget_enforcement event after first call.\n"
        "  >> The budget bar should be red."
    )

    # -----------------------------------------------------------------------
    # 6. Loop detection threshold
    # -----------------------------------------------------------------------
    header("PATCH /config → loop_exact_threshold=1 → loops detected faster")
    # Disable cache so loop detector sees the repeated requests
    api("PATCH", "/config", json={"loop_exact_threshold": 1, "cache_ttl_seconds": 0})
    print(f"  Set loop_exact_threshold=1, cache_ttl_seconds=0")

    loop_prompt = "Say hello."
    with stateloom.session(session_id="cfg-loop-detect", name="Loop Detection") as s:
        try:
            ask(user_msg(loop_prompt))
            print(f"  Call 1: OK")
            ask(user_msg(loop_prompt))
            print(f"  Call 2: OK (should have been blocked)")
        except stateloom.StateLoomLoopError as e:
            print(f"  ✓ LOOP DETECTED on call 2: {e}")

    # Restore
    api("PATCH", "/config", json={"loop_exact_threshold": 3, "cache_ttl_seconds": 300})
    print(f"\n  Restored loop_exact_threshold=3, cache_ttl_seconds=300")

    pause("Sessions tab: 'cfg-loop-detect' — LOOP_DETECTED event on the duplicate call")

    # -----------------------------------------------------------------------
    # 7. Final config check
    # -----------------------------------------------------------------------
    header("Verify all settings restored")
    cfg = api("GET", "/config").json()
    print(f"  budget_per_session : {cfg.get('budget_per_session')}")
    print(f"  cache_ttl_seconds  : {cfg.get('cache_ttl_seconds')}")
    print(f"  loop_exact_threshold: {cfg.get('loop_exact_threshold')}")

    with stateloom.session(session_id="cfg-restored", name="Restored") as s:
        r = ask(user_msg("Confirm everything works. Reply 'OK'."))
        print(f"  Response: {r.content[:40]}")
        print(f"  ✓ All settings restored and working")

    wait_for_exit()


if __name__ == "__main__":
    main()
