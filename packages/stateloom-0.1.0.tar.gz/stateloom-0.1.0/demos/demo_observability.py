#!/usr/bin/env python3
"""Demo: Observability — Prometheus Metrics & Dashboard API

Demonstrates StateLoom's built-in observability: Prometheus metrics
for monitoring, time-series aggregation, and latency percentiles.
Generate some traffic, then inspect the metrics.

Monitor at http://localhost:4781 → Overview tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    import prometheus_client  # noqa: F401
    HAS_PROMETHEUS = True
except ImportError:
    HAS_PROMETHEUS = False

try:
    import httpx
except ImportError:
    print("\n  This demo requires httpx: pip install httpx")
    sys.exit(1)


def main():
    if not HAS_PROMETHEUS:
        print("\n  Optional: pip install prometheus_client")
        print("  Prometheus metrics will be skipped, but dashboard API still works.\n")

    gate = init_gate(metrics_enabled=True)

    # -----------------------------------------------------------------------
    # Scenario 1: Generate traffic across multiple sessions
    # -----------------------------------------------------------------------
    header("Generate traffic — 5 LLM calls across 2 sessions")

    with stateloom.session(session_id="obs-session-1", name="Observability Test 1") as s1:
        ask(user_msg("What is observability in software systems? Be concise."))
        ask(user_msg("Name 3 observability tools. Just the names."))
        ask(user_msg("What are the 3 pillars of observability? One line each."))
        print(f"  Session 1: {s1.call_count} calls, ${s1.total_cost:.6f}")

    with stateloom.session(session_id="obs-session-2", name="Observability Test 2") as s2:
        ask(user_msg("What is Prometheus? One sentence."))
        ask(user_msg("What is OpenTelemetry? One sentence."))
        print(f"  Session 2: {s2.call_count} calls, ${s2.total_cost:.6f}")

    total_calls = s1.call_count + s2.call_count
    total_cost = s1.total_cost + s2.total_cost
    print(f"\n  Total: {total_calls} calls, ${total_cost:.6f}")

    pause("Overview tab: see live stats — total calls, cost, active sessions")

    # -----------------------------------------------------------------------
    # Scenario 2: Prometheus metrics (if available)
    # -----------------------------------------------------------------------
    header("Prometheus metrics")

    if HAS_PROMETHEUS and hasattr(gate, '_metrics_collector') and gate._metrics_collector:
        metrics_text = gate._metrics_collector.generate_metrics()
        # Show key metrics
        print("  Key Prometheus metrics:")
        for line in metrics_text.split("\n"):
            if line and not line.startswith("#"):
                # Show a subset of interesting metrics
                for keyword in ["total", "cost", "latency", "calls", "sessions"]:
                    if keyword in line.lower():
                        print(f"    {line}")
                        break
    else:
        print("  Prometheus metrics not available.")
        print("  Install prometheus_client for full metrics: pip install prometheus_client")

    # -----------------------------------------------------------------------
    # Scenario 3: Dashboard observability API
    # -----------------------------------------------------------------------
    header("Dashboard observability API — time-series and latency")

    # Time-series data
    resp = httpx.get(
        f"{DASHBOARD_URL}/api/observability/timeseries",
        headers={"X-API-Key": gate._config.dashboard_api_key or ""},
        timeout=10,
    )
    if resp.status_code == 200:
        ts_data = resp.json()
        print(f"  Time-series data points: {len(ts_data.get('data', []))}")
        if ts_data.get("data"):
            latest = ts_data["data"][-1]
            print(f"  Latest bucket:")
            for key in ["calls", "cost", "tokens"]:
                if key in latest:
                    print(f"    {key}: {latest[key]}")
    else:
        print(f"  Time-series API: {resp.status_code} (may need data to accumulate)")

    # Latency percentiles
    resp = httpx.get(
        f"{DASHBOARD_URL}/api/observability/latency",
        headers={"X-API-Key": gate._config.dashboard_api_key or ""},
        timeout=10,
    )
    if resp.status_code == 200:
        latency_data = resp.json()
        print(f"\n  Latency percentiles:")
        for key, value in latency_data.items():
            if isinstance(value, (int, float)):
                print(f"    {key}: {value:.1f}ms")
    else:
        print(f"  Latency API: {resp.status_code}")

    # Global stats
    resp = httpx.get(
        f"{DASHBOARD_URL}/api/stats",
        headers={"X-API-Key": gate._config.dashboard_api_key or ""},
        timeout=10,
    )
    if resp.status_code == 200:
        stats = resp.json()
        print(f"\n  Global stats:")
        for key in ["total_sessions", "total_events", "total_cost", "total_tokens"]:
            if key in stats:
                val = stats[key]
                if isinstance(val, float):
                    print(f"    {key}: ${val:.6f}" if "cost" in key else f"    {key}: {val:.1f}")
                else:
                    print(f"    {key}: {val}")

    pause(
        "Overview tab: live metrics, cost graph, latency chart.\n"
        "  >> Observability data is generated from real LLM call events."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
