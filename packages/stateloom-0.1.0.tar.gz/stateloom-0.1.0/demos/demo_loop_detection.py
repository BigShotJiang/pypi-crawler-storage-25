#!/usr/bin/env python3
"""Demo: Loop Detection — monitor at http://localhost:4781

Real-world scenario: An AI agent stuck in a retry loop, sending the same
request over and over. StateLoom detects the loop and stops it.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(cache=False)  # disable cache so loop detector sees repeats

    # --- Scenario 1: Agent stuck in a loop ---
    header("Agent stuck in retry loop — detected and stopped")
    with stateloom.session(session_id="loop-detect-1", name="Loop Detection") as s:
        stuck_msg = user_msg("Generate a valid JSON object with fields: name, age, email")
        call_count = 0
        try:
            for i in range(10):
                r = ask(stuck_msg)
                call_count += 1
                print(f"  Call {call_count}: {r.content[:60]}...")
        except stateloom.StateLoomLoopError as e:
            print(f"\n  LOOP DETECTED after {call_count} identical calls!")
            print(f"  Error: {e}")
        except Exception as e:
            print(f"\n  Stopped after {call_count} calls: {type(e).__name__}: {e}")

    pause(
        "Sessions tab: click 'loop-detect-1' — see repeated LLM calls then a LOOP_DETECTION event.\n"
        "  >> The loop detector prevents runaway API spending."
    )

    # --- Scenario 2: Normal varied conversation (no loop) ---
    header("Normal conversation — no loop detected")
    with stateloom.session(session_id="loop-detect-2", name="Normal Chat") as s:
        questions = [
            "What is machine learning?",
            "How does gradient descent work?",
            "Explain backpropagation in simple terms.",
            "What's the difference between CNN and RNN?",
        ]
        for q in questions:
            r = ask(user_msg(q))
            print(f"  Q: {q[:40]}  → {r.content[:60]}...")

        print(f"\n  {len(questions)} varied calls — no loop detected (expected)")

    pause(
        "Sessions tab: click 'loop-detect-2' — all LLM_CALL events, no loop detection.\n"
        "  >> Compare the two sessions: looping vs. normal conversation."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
