#!/usr/bin/env python3
"""Demo: Timeouts & Cancellation — monitor at http://localhost:4781

Real-world scenario: Long-running agent tasks with session-level timeouts
and manual cancellation support. Prevents runaway sessions.
"""

import sys, os, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # --- Scenario 1: Session with timeout ---
    header("Session with 10-second timeout")
    with stateloom.session(
        session_id="timeout-demo",
        name="Timed Session",
        timeout=10.0,
    ) as s:
        # First call — should succeed
        r1 = ask(user_msg("What are the benefits of containerization? Be brief."))
        print(f"  Call 1: {r1.content[:80]}...")
        print(f"  Elapsed: ~0s of 10s timeout")

        # Simulate processing time
        print("  Simulating 6 seconds of processing...")
        time.sleep(6)

        # Second call — may be close to timeout
        try:
            r2 = ask(user_msg("Now explain Kubernetes in one sentence."))
            print(f"  Call 2: {r2.content[:80]}...")
        except stateloom.StateLoomTimeoutError as e:
            print(f"  Call 2: TIMED OUT — {e}")

        # Third call — likely past timeout
        time.sleep(5)
        try:
            r3 = ask(user_msg("This should timeout."))
            print(f"  Call 3: {r3.content[:80]}...")
        except stateloom.StateLoomTimeoutError as e:
            print(f"  Call 3: TIMED OUT — {e}")
            print(f"  Session status: {s.status}")

    pause(
        "Sessions tab: click 'timeout-demo' — see TIMED_OUT status badge.\n"
        "  >> Timeline shows successful call(s) then timeout event."
    )

    # --- Scenario 2: Idle timeout ---
    header("Session with 5-second idle timeout")
    with stateloom.session(
        session_id="idle-timeout-demo",
        name="Idle Timeout",
        idle_timeout=5.0,
    ) as s:
        r1 = ask(user_msg("What is Docker? One sentence."))
        print(f"  Call 1: {r1.content[:80]}...")
        print(f"  Now waiting 6 seconds without activity...")
        time.sleep(6)

        try:
            r2 = ask(user_msg("This should trigger idle timeout."))
            print(f"  Call 2: {r2.content[:80]}...")
        except stateloom.StateLoomTimeoutError as e:
            print(f"  Call 2: IDLE TIMEOUT — {e}")
            print(f"  Session status: {s.status}")

    pause("Sessions tab: 'idle-timeout-demo' — TIMED_OUT due to idle timeout")

    # --- Scenario 3: Manual cancellation ---
    header("Manual session cancellation")

    # Start a session in a background thread, cancel it from main thread
    cancel_session_id = "cancel-demo"
    results = {"cancelled": False}

    def agent_work():
        with stateloom.session(
            session_id=cancel_session_id,
            name="Cancellable Task",
        ) as s:
            r1 = ask(user_msg("Start a long analysis of cloud computing trends."))
            print(f"  [Agent] Call 1: {r1.content[:60]}...")

            time.sleep(2)  # simulate processing

            try:
                r2 = ask(user_msg("Continue the analysis with cost comparisons."))
                print(f"  [Agent] Call 2: {r2.content[:60]}...")
            except stateloom.StateLoomCancellationError as e:
                print(f"  [Agent] CANCELLED: {e}")
                results["cancelled"] = True

    thread = threading.Thread(target=agent_work)
    thread.start()

    # Wait a bit then cancel
    time.sleep(3)
    print("  [Main] Cancelling session...")
    stateloom.cancel_session(cancel_session_id)
    thread.join(timeout=15)

    if results["cancelled"]:
        print("  Session was successfully cancelled!")
    else:
        print("  Session completed before cancellation took effect.")

    pause(
        "Sessions tab: 'cancel-demo' — see CANCELLED status badge.\n"
        "  >> Compare the three sessions: timeout, idle timeout, cancellation."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
