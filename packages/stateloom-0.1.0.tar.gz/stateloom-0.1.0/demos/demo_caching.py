#!/usr/bin/env python3
"""Demo: Response Caching — monitor at http://localhost:4781

Real-world scenario: A FAQ bot where many users ask the same questions.
Caching avoids redundant API calls and saves money.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(cache=True, loop_exact_threshold=0)

    # --- Scenario 1: Duplicate question hits cache ---
    header("FAQ bot — same question asked twice")
    with stateloom.session(session_id="faq-cache-1", name="FAQ Cache Demo") as s:
        q = "What are your business hours?"
        msgs = [
            {"role": "system", "content": "You are a customer service bot. Answer concisely."},
            {"role": "user", "content": q},
        ]

        r1 = ask(msgs)
        print(f"  Call 1: {r1.content[:80]}...")
        print(f"    Cost: ${s.total_cost:.6f}  Cached: {r1._stateloom['cached']}")

        r2 = ask(msgs)
        print(f"  Call 2: {r2.content[:80]}...")
        print(f"    Cost: ${s.total_cost:.6f}  Cached: {r2._stateloom['cached']}  Cache hits: {s.cache_hits}")

    pause(
        "Sessions tab: click 'faq-cache-1' — first call is LLM_CALL, second is CACHE_HIT.\n"
        "  >> Overview: cache hits count increased."
    )

    # --- Scenario 2: Different questions don't cache ---
    header("Different questions — no cache hit")
    with stateloom.session(session_id="faq-cache-2", name="Different Questions") as s:
        r1 = ask(user_msg("How do I reset my password?"))
        print(f"  Q1: {r1.content[:80]}...")
        print(f"    Cached: {r1._stateloom['cached']}")

        r2 = ask(user_msg("How do I update my billing info?"))
        print(f"  Q2: {r2.content[:80]}...")
        print(f"    Cached: {r2._stateloom['cached']}")

        print(f"\n  Cache hits: {s.cache_hits} (should be 0 — different questions)")

    pause("Sessions tab: click 'faq-cache-2' — two distinct LLM_CALL events, no cache hits")

    # --- Scenario 3: Cache saves money across multiple calls ---
    header("High-volume FAQ — cache savings add up")
    with stateloom.session(session_id="faq-cache-3", name="Volume FAQ") as s:
        questions = [
            "What's your return policy?",
            "Do you offer free shipping?",
            "What's your return policy?",      # duplicate
            "How do I track my order?",
            "Do you offer free shipping?",      # duplicate
            "What's your return policy?",      # duplicate
        ]
        for i, q in enumerate(questions, 1):
            r = ask([
                {"role": "system", "content": "Answer in one sentence."},
                {"role": "user", "content": q},
            ])
            cached = "CACHED" if r._stateloom["cached"] else "LIVE"
            print(f"  [{cached}] Q{i}: {q[:40]}  → {r.content[:60]}...")

        print(f"\n  Total calls: {len(questions)}  Live calls: {s.call_count}  Cache hits: {s.cache_hits}")
        print(f"  Cost: ${s.total_cost:.6f}  (saved by caching {s.cache_hits} calls)")

    pause(
        "Sessions tab: click 'faq-cache-3' — mix of LLM_CALL and CACHE_HIT events.\n"
        "  >> Overview: total cache hits and savings."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
