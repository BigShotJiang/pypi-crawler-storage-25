#!/usr/bin/env python3
"""Demo: Mistral Integration — Zero-Config Auto-Patching

StateLoom automatically patches Mistral's Chat.complete() and
Chat.complete_async() so every LLM call flows through the middleware
pipeline. Cost tracking, budgets, PII detection — all transparent.

Requires: pip install mistralai
          Set MISTRAL_API_KEY environment variable.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    from mistralai import Mistral
except ImportError:
    print("\n  This demo requires the Mistral SDK: pip install mistralai")
    sys.exit(1)

# Check for Mistral API key
if not os.environ.get("MISTRAL_API_KEY"):
    print("\n  Set MISTRAL_API_KEY environment variable.")
    print("  Get a key at: https://console.mistral.ai/api-keys/")
    sys.exit(1)

MISTRAL_MODEL = "mistral-small-latest"


def main():
    # stateloom.init() auto-patches Mistral — zero config needed
    gate = init_gate()

    client = Mistral()

    # -----------------------------------------------------------------------
    # Scenario 1: Basic Mistral chat — auto-tracked by StateLoom
    # -----------------------------------------------------------------------
    header("Mistral chat.complete() — auto-patched, zero config")

    with stateloom.session(session_id="mistral-basic", name="Mistral Basic") as s:
        print(f"  Calling client.chat.complete(model='{MISTRAL_MODEL}')...")
        response = client.chat.complete(
            model=MISTRAL_MODEL,
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Be concise."},
                {"role": "user", "content": "What makes Mistral AI models unique?"},
            ],
        )
        content = ""
        data = response.data if hasattr(response, "data") else response
        if hasattr(data, "choices") and data.choices:
            msg = getattr(data.choices[0], "message", None)
            if msg:
                content = getattr(msg, "content", "") or ""
        print(f"  Response: {content[:120]}...")
        print(f"\n  StateLoom tracked this call automatically:")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")
        print(f"    Calls:  {s.call_count}")

    pause("Sessions tab: click 'mistral-basic' — see the Mistral LLM call with cost/tokens")

    # -----------------------------------------------------------------------
    # Scenario 2: Multi-call session — all calls tracked together
    # -----------------------------------------------------------------------
    header("Multi-call session — costs accumulate across Mistral calls")

    with stateloom.session(session_id="mistral-multi", name="Mistral Multi-Call") as s:
        topics = [
            "What is mixture of experts (MoE)? One sentence.",
            "What is sliding window attention? One sentence.",
            "What is grouped-query attention? One sentence.",
        ]
        for i, topic in enumerate(topics, 1):
            resp = client.chat.complete(
                model=MISTRAL_MODEL,
                messages=[{"role": "user", "content": topic}],
            )
            data = resp.data if hasattr(resp, "data") else resp
            text = ""
            if hasattr(data, "choices") and data.choices:
                msg = getattr(data.choices[0], "message", None)
                if msg:
                    text = getattr(msg, "content", "") or ""
            print(f"  Call {i}: {text[:80]}...")
            print(f"    Running cost: ${s.total_cost:.6f}  Tokens: {s.total_tokens}")

        print(f"\n  Session summary:")
        print(f"    Total calls:  {s.call_count}")
        print(f"    Total cost:   ${s.total_cost:.6f}")
        print(f"    Total tokens: {s.total_tokens}")

    pause("Sessions tab: 'mistral-multi' — 3 Mistral LLM call events, cumulative cost")

    # -----------------------------------------------------------------------
    # Scenario 3: Budget enforcement on Mistral calls
    # -----------------------------------------------------------------------
    header("Budget enforcement — works transparently with Mistral")

    with stateloom.session(
        session_id="mistral-budget",
        name="Mistral Budget",
        budget=0.001,
    ) as s:
        try:
            for i in range(5):
                client.chat.complete(
                    model=MISTRAL_MODEL,
                    messages=[{"role": "user", "content": f"Write a haiku about the number {i+1}"}],
                )
                print(f"  Call {i+1}: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"\n  BLOCKED by StateLoom budget: {e}")
            print(f"  Mistral calls are budget-enforced transparently.")

    pause("Sessions tab: 'mistral-budget' — budget enforcement on Mistral calls")

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n  Mistral + StateLoom summary:")
    print("  - stateloom.init() auto-patches mistral.Chat.complete()")
    print("  - Every call gets cost tracking, session grouping, event recording")
    print("  - Budgets, PII detection, guardrails all work transparently")
    print("  - No code changes needed in your existing Mistral calls")
    print(f"  - Tested with model: {MISTRAL_MODEL}")

    wait_for_exit()


if __name__ == "__main__":
    main()
