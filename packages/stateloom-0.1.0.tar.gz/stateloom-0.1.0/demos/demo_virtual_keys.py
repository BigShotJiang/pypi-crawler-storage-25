#!/usr/bin/env python3
"""Demo: Virtual Key Management — monitor at http://localhost:4781

Real-world scenario: Admin creates API keys for different services,
each with budget limits and model restrictions. Keys can be revoked
without affecting other services.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # --- Set up org and teams ---
    header("Create org and teams for key management")
    org = stateloom.create_organization(name="KeyCorp", budget=1000.0)
    backend_team = stateloom.create_team(org.id, name="Backend Services")
    frontend_team = stateloom.create_team(org.id, name="Frontend Apps")
    analytics_team = stateloom.create_team(org.id, name="Analytics Pipeline")

    print(f"  Org: {org.name}")
    print(f"  Teams: {backend_team.name}, {frontend_team.name}, {analytics_team.name}")

    # --- Create virtual keys with different permissions ---
    header("Create virtual keys with budget and model restrictions")

    # Key 1: Backend — high budget, all models
    key1 = stateloom.create_virtual_key(
        backend_team.id,
        name="backend-prod",
        budget_limit=500.0,
        rate_limit_tps=50.0,
    )
    print(f"  backend-prod:  {key1['key_preview']}  budget=$500  TPS=50")

    # Key 2: Frontend — lower budget, restricted models
    key2 = stateloom.create_virtual_key(
        frontend_team.id,
        name="frontend-chat",
        budget_limit=100.0,
        allowed_models=["gpt-4o-mini", "gpt-3.5-turbo"],
        rate_limit_tps=10.0,
    )
    print(f"  frontend-chat: {key2['key_preview']}  budget=$100  TPS=10  models=gpt-4o-mini,gpt-3.5-turbo")

    # Key 3: Analytics — moderate budget
    key3 = stateloom.create_virtual_key(
        analytics_team.id,
        name="analytics-batch",
        budget_limit=200.0,
        rate_limit_tps=5.0,
        metadata={"use_case": "batch-processing", "environment": "production"},
    )
    print(f"  analytics-batch: {key3['key_preview']}  budget=$200  TPS=5")

    # Key 4: Temporary dev key
    key4 = stateloom.create_virtual_key(
        backend_team.id,
        name="dev-testing",
        budget_limit=10.0,
        rate_limit_tps=2.0,
    )
    print(f"  dev-testing:   {key4['key_preview']}  budget=$10  TPS=2")

    pause("Compliance > Organizations: see KeyCorp with teams and virtual keys")

    # --- List all keys ---
    header("List virtual keys")
    all_keys = stateloom.list_virtual_keys()
    print(f"  Total keys: {len(all_keys)}")
    for k in all_keys:
        status = "REVOKED" if k.get("revoked") else "ACTIVE"
        print(f"    {k['name']:>20}: {k['key_preview']}  [{status}]  team={k['team_id'][:15]}...")

    # --- Revoke the dev key ---
    header("Revoke the dev-testing key")
    revoked = stateloom.revoke_virtual_key(key4["id"])
    print(f"  Revoked dev-testing: {revoked}")

    # List again to show revoked status
    all_keys = stateloom.list_virtual_keys()
    for k in all_keys:
        status = "REVOKED" if k.get("revoked") else "ACTIVE"
        print(f"    {k['name']:>20}: {k['key_preview']}  [{status}]")

    pause(
        "The dev-testing key is now revoked.\n"
        "  >> Any proxy requests using that key will be rejected.\n"
        "  >> Other keys continue to work normally."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
