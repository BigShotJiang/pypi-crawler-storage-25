#!/usr/bin/env python3
"""Demo: Rate Limiting — monitor at http://localhost:4781

Real-world scenario: Multiple teams share the same LLM gateway. Each team
has a TPS (transactions per second) limit to ensure fair resource allocation.
"""

import sys, os, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # --- Set up org and teams with rate limits ---
    header("Create org and teams with rate limits")
    org = stateloom.create_organization(name="TechCorp", budget=100.0)
    print(f"  Org: {org.name} ({org.id})")

    team_a = stateloom.create_team(org.id, name="ML Team", budget=50.0)
    team_b = stateloom.create_team(org.id, name="Support Team", budget=50.0)

    # Set rate limits on teams
    team_a.rate_limit_tps = 2.0  # 2 requests/second
    team_a.rate_limit_priority = 10  # higher priority
    team_a.rate_limit_max_queue = 5
    team_a.rate_limit_queue_timeout = 10.0
    gate.store.save_team(team_a)

    team_b.rate_limit_tps = 1.0  # 1 request/second
    team_b.rate_limit_priority = 5  # lower priority
    team_b.rate_limit_max_queue = 5
    team_b.rate_limit_queue_timeout = 10.0
    gate.store.save_team(team_b)

    print(f"  {team_a.name}: {team_a.rate_limit_tps} TPS (priority {team_a.rate_limit_priority})")
    print(f"  {team_b.name}: {team_b.rate_limit_tps} TPS (priority {team_b.rate_limit_priority})")

    # Enable session context propagation to child threads
    stateloom.patch_threading()

    pause("Compliance > Organizations: see TechCorp with ML Team and Support Team")

    # --- Scenario: ML Team — concurrent burst in a single session ---
    header("ML Team — concurrent burst (2 TPS, max_queue=2, 5 requests)")
    print("  Sending 5 requests at once to a 2 TPS team (max_queue=2)...")
    print("  All calls share one session — see all events in one waterfall.\n")

    team_a.rate_limit_max_queue = 2
    gate.store.save_team(team_a)

    ml_results = [None] * 5

    with stateloom.session(
        session_id="rate-ml-burst",
        name="ML Team Burst",
        org_id=org.id,
        team_id=team_a.id,
    ) as ml_session:
        def ml_burst(idx):
            try:
                r = ask(user_msg(f"Classify this text as positive or negative: 'Sample text {idx+1}'"))
                ml_results[idx] = f"OK: {r.content[:50]}..."
            except stateloom.StateLoomRateLimitError as e:
                ml_results[idx] = f"RATE LIMITED: {e}"

        ml_threads = [threading.Thread(target=ml_burst, args=(i,)) for i in range(5)]
        for t in ml_threads:
            t.start()
        for t in ml_threads:
            t.join()

    for i, result in enumerate(ml_results):
        print(f"  [{i+1}] {result}")

    pause(
        "Sessions tab: click 'rate-ml-burst' — single session with all events.\n"
        "  >> Waterfall shows: 2 passed, 2 queued (waited), 1 rejected."
    )

    # --- Scenario: Support Team — concurrent burst in a single session ---
    header("Support Team — concurrent burst (1 TPS, max_queue=1, 3 requests)")
    print("  Sending 3 requests at once to a 1 TPS team (max_queue=1)...")
    print("  All calls share one session.\n")

    team_b.rate_limit_max_queue = 1
    team_b.rate_limit_queue_timeout = 5.0
    gate.store.save_team(team_b)

    results = [None] * 3

    with stateloom.session(
        session_id="rate-support-burst",
        name="Support Team Burst",
        org_id=org.id,
        team_id=team_b.id,
    ) as support_session:
        def burst_request(idx):
            try:
                r = ask(user_msg(f"Customer question {idx+1}: How do I reset my password?"))
                results[idx] = f"OK: {r.content[:50]}..."
            except stateloom.StateLoomRateLimitError as e:
                results[idx] = f"RATE LIMITED: {e}"

        threads = [threading.Thread(target=burst_request, args=(i,)) for i in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    for i, result in enumerate(results):
        print(f"  [{i+1}] {result}")

    # --- Check rate limiter status ---
    header("Rate limiter status")
    status = stateloom.rate_limiter_status()
    print(f"  Status: {status}")

    pause(
        "Overview: rate limit events in the live stream.\n"
        "  >> Rate limiter status shows per-team queue depths and token counts."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
