#!/usr/bin/env python3
"""Demo: Smart Auto-Routing — monitor at http://localhost:4781

Real-world scenario: Simple questions get routed to a free local model,
complex questions stay on the cloud. This saves money while maintaining
quality for hard tasks.

Requires: Ollama running locally (https://ollama.com)
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(
        auto_route=True,
        default_model=MODEL,
    )

    if not gate.config.auto_route_enabled:
        print("  WARNING: Auto-routing not enabled (no Ollama detected).")
        print("  Make sure Ollama is running: ollama serve")
        print("  And you have a model: ollama pull llama3.2")
        print("  Continuing with cloud-only routing...\n")

    local_model = gate.config.local_model_default or "N/A"
    print(f"  Local model: {local_model}")
    print(f"  Auto-route: {gate.config.auto_route_enabled}")
    print(f"  Semantic scoring: {gate.config.auto_route_semantic_enabled}\n")

    # --- Simple questions (should route to local) ---
    header("Simple questions — candidates for local routing")
    simple_qs = [
        "What is 2 + 2?",
        "What color is grass?",
        "Name the largest planet in our solar system.",
        "What year did World War II end?",
    ]

    with stateloom.session(session_id="route-simples", name="SimpleQuestions") as s:
        for q in simple_qs:
            r = ask(user_msg(q))
            routed = r._stateloom.get("routed_local", False)
            actual = r._stateloom.get("actual_model", MODEL)
            tag = "LOCAL" if routed else "CLOUD"
            print(f"  [{tag:>5}] {q[:40]} → {r.content[:40]}... (model: {actual})")

        print(f"\n  Cost: ${s.total_cost:.6f}  Calls: {s.call_count}")

    pause(
        "Sessions tab: click 'route-simple'.\n"
        "  >> LOCAL_ROUTING events show complexity score and routing decision.\n"
        "  >> Simple questions may route to the local model (cost ~$0)."
    )

    # --- Complex questions (should stay on cloud) ---
    header("Complex questions — should stay on cloud")
    complex_qs = [
        (
            "You are a systems architect. Design a distributed event sourcing system "
            "with CQRS, saga patterns, and exactly-once delivery guarantees. "
            "Include the data model, message broker choice, and failure recovery strategy."
        ),
        (
            "Write a comprehensive comparison of B-trees, LSM trees, and hash indexes "
            "for database storage engines. Include performance characteristics for "
            "read-heavy vs write-heavy workloads."
        ),
    ]

    with stateloom.session(session_id="route-complex", name="Complex Questions") as s:
        for q in complex_qs:
            r = ask([
                {"role": "system", "content": "You are an expert engineer. Be thorough."},
                {"role": "user", "content": q},
            ])
            routed = r._stateloom.get("routed_local", False)
            tag = "LOCAL" if routed else "CLOUD"
            print(f"  [{tag:>5}] {q[:50]}... → {r.content[:60]}...")

        print(f"\n  Cost: ${s.total_cost:.6f}  Calls: {s.call_count}")

    pause(
        "Sessions tab: click 'route-complex'.\n"
        "  >> Complex questions have higher complexity scores → stay on cloud.\n"
        "  >> Compare costs: simple (maybe $0) vs complex (real API cost)."
    )

    # --- Realtime data requests (always cloud) ---
    header("Realtime data requests — bypass local routing")
    with stateloom.session(session_id="route-realtime", name="Realtime Queries") as s:
        realtime_qs = [
            "What's the current weather in New York?",
            "What are today's stock market trends?",
        ]
        for q in realtime_qs:
            r = ask(user_msg(q))
            routed = r._stateloom.get("routed_local", False)
            tag = "LOCAL" if routed else "CLOUD"
            print(f"  [{tag:>5}] {q[:50]}... → {r.content[:60]}...")

    pause(
        "Sessions tab: 'route-realtime' — realtime queries skip local routing.\n"
        "  >> The router detects keywords like 'weather', 'stock' and routes to cloud."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
