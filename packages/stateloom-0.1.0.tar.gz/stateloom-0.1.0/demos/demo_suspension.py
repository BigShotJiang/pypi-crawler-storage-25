#!/usr/bin/env python3
"""Demo: Session Suspension — Human-in-the-Loop

Demonstrates pausing an AI session to wait for human approval, then
resuming it with a signal. Useful for high-stakes decisions that need
a human in the loop before proceeding.

Monitor at http://localhost:4781 → Sessions tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import threading
import time


def main():
    gate = init_gate()

    # -----------------------------------------------------------------------
    # Scenario 1: Suspend + signal flow (background thread)
    # -----------------------------------------------------------------------
    header("Suspend + Signal — background thread waits for approval")

    session_id = "suspension-approval"
    result_holder = {}

    def worker():
        """Run in a background thread — suspends and waits for signal."""
        with stateloom.session(session_id=session_id, name="Approval Flow") as s:
            # First call — ask the LLM what action to take
            r = ask([
                {"role": "system", "content": "You are a deployment assistant. Be concise."},
                {"role": "user", "content": "Should we deploy version 2.0 to production?"},
            ])
            print(f"  [Worker] LLM recommends: {r.content[:100]}...")

            # Suspend — wait for human approval
            print(f"  [Worker] Suspending session for human approval...")
            signal = stateloom.suspend(
                reason="Deployment needs approval",
                data={"action": "deploy", "version": "2.0"},
                timeout=30.0,
            )

            # Resume — signal received
            print(f"  [Worker] Signal received: {signal}")
            result_holder["signal"] = signal

            # Continue with the approved action
            r2 = ask(user_msg(
                f"The human approved the deployment with: {signal}. "
                "Confirm the deployment in one sentence."
            ))
            print(f"  [Worker] Post-approval: {r2.content[:100]}...")

    # Start the worker thread
    t = threading.Thread(target=worker, daemon=True)
    t.start()

    # Main thread: wait a moment, then signal approval
    time.sleep(3)
    print(f"\n  [Main] Sending approval signal...")
    stateloom.signal_session(session_id, payload={"approved": True, "approver": "admin"})

    # Wait for worker to finish
    t.join(timeout=60)

    if "signal" in result_holder:
        print(f"\n  Flow completed successfully!")
        print(f"  Signal payload: {result_holder['signal']}")
    else:
        print(f"\n  Worker timed out or failed.")

    pause(
        "Sessions tab: click 'suspension-approval'.\n"
        "  >> See the LLM call, then SUSPENDED status, then resumed with signal."
    )

    # -----------------------------------------------------------------------
    # Scenario 2: External suspend — next call raises error
    # -----------------------------------------------------------------------
    header("External suspend — next LLM call raises SuspendedError")

    with stateloom.session(session_id="suspension-external", name="External Suspend") as s:
        # First call works fine
        r = ask(user_msg("What is the capital of France? One word."))
        print(f"  First call: {r.content[:80]}")

        # Externally suspend the session
        stateloom.suspend_session(s.id, reason="Admin review required", data={"risk": "high"})
        print(f"  Session suspended externally (reason: admin review)")

        # Next call should fail
        try:
            r2 = ask(user_msg("What is the capital of Germany?"))
            print(f"  Second call: {r2.content[:80]}")
        except stateloom.StateLoomSuspendedError as e:
            print(f"  SUSPENDED: Session {e.session_id} is suspended!")
            print(f"  No LLM call was made — the session is paused.")

    pause(
        "Sessions tab: 'suspension-external' shows SUSPENDED status.\n"
        "  >> First call succeeded, then session was paused before second call."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
