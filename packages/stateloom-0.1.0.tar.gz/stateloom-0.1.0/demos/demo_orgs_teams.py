#!/usr/bin/env python3
"""Demo: Organizations & Teams — monitor at http://localhost:4781

Real-world scenario: A large enterprise with multiple teams using the
AI gateway. Each org and team has its own budget, PII rules, and cost tracking.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate(
        pii=True,
        pii_rules=[
            PIIRule(pattern="email", mode="redact"),
        ],
    )

    # --- Create organization hierarchy ---
    header("Create enterprise organization with teams")

    org = stateloom.create_organization(
        name="GlobalTech Inc",
        budget=500.0,
        pii_rules=[
            {"pattern": "email", "mode": "redact"},
            {"pattern": "phone", "mode": "redact"},
        ],
        metadata={"region": "US-West", "tier": "enterprise", "contract": "annual"},
    )
    print(f"  Org: {org.name} ({org.id})")
    print(f"    Budget: ${org.budget}  PII rules: {len(org.pii_rules)}")

    ml_team = stateloom.create_team(org.id, name="ML Engineering", budget=200.0)
    support_team = stateloom.create_team(org.id, name="Customer Support", budget=150.0)
    marketing_team = stateloom.create_team(org.id, name="Marketing", budget=100.0)

    print(f"  Teams:")
    print(f"    - {ml_team.name} ({ml_team.id}) — budget: ${ml_team.budget}")
    print(f"    - {support_team.name} ({support_team.id}) — budget: ${support_team.budget}")
    print(f"    - {marketing_team.name} ({marketing_team.id}) — budget: ${marketing_team.budget}")

    pause("Compliance > Organizations: see GlobalTech Inc with 3 teams")

    # --- ML Team sessions ---
    header("ML Team — model evaluation sessions")
    for i, task in enumerate([
        "Evaluate this model output for hallucinations: 'The Eiffel Tower is in London.'",
        "Score this summary for factual accuracy: 'Python was created in 1991 by Guido van Rossum.'",
    ], start=1):
        with stateloom.session(
            session_id=f"ml-eval-{i}",
            name=f"ML Eval {i}",
            org_id=org.id,
            team_id=ml_team.id,
        ) as s:
            r = ask([
                {"role": "system", "content": "You are an ML evaluation expert. Score 1-10 and explain briefly."},
                {"role": "user", "content": task},
            ])
            print(f"  ML Eval {i}: {r.content[:80]}...")
            print(f"    Cost: ${s.total_cost:.6f}")

    # --- Support Team sessions ---
    header("Support Team — customer interactions")
    for i, query in enumerate([
        "Customer asks: How do I upgrade my plan? Contact me at user@example.com",
        "Customer asks: I need a refund for order #12345. Call me at 555-123-4567.",
        "Customer asks: My dashboard shows wrong data. Please fix it.",
    ], start=1):
        with stateloom.session(
            session_id=f"support-query-{i}",
            name=f"Support Query {i}",
            org_id=org.id,
            team_id=support_team.id,
        ) as s:
            r = ask([
                {"role": "system", "content": "You are a support agent. Be helpful and concise."},
                {"role": "user", "content": query},
            ])
            print(f"  Support {i}: {r.content[:80]}...")
            print(f"    Cost: ${s.total_cost:.6f}  PII: {s.pii_detections}")

    # --- Marketing Team sessions ---
    header("Marketing Team — content generation")
    with stateloom.session(
        session_id="marketing-content-1",
        name="Ad Copy Generation",
        org_id=org.id,
        team_id=marketing_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a marketing copywriter. Be creative and concise."},
            {"role": "user", "content": "Write a compelling tagline for an AI-powered analytics platform."},
        ])
        print(f"  Ad copy: {r.content[:100]}...")
        print(f"    Cost: ${s.total_cost:.6f}")

    # --- Show org/team stats ---
    header("Organization and team statistics")
    org_s = stateloom.org_stats(org.id)
    print(f"  GlobalTech Inc stats:")
    print(f"    {org_s}")

    for team in [ml_team, support_team, marketing_team]:
        team_s = stateloom.team_stats(team.id)
        print(f"  {team.name}: {team_s}")

    pause(
        "Compliance > Organizations: see GlobalTech Inc.\n"
        "  >> Click the org to see team breakdown with costs.\n"
        "  >> Each team has its own session count, cost, and budget usage.\n"
        "  >> PII Monitor: support team sessions show redacted emails/phones."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
