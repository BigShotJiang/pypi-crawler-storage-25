#!/usr/bin/env python3
"""Demo: Authentication & RBAC

Demonstrates StateLoom's JWT-based authentication with role-based access
control. Shows bootstrap, login, authenticated requests, user creation,
permission enforcement, and token refresh.

Monitor at http://localhost:4781 → Users tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    import httpx
except ImportError:
    print("\n  This demo requires httpx: pip install httpx")
    sys.exit(1)


def api(method, path, token=None, **kwargs):
    """Helper to call the dashboard API."""
    url = f"{DASHBOARD_URL}{path}"
    headers = kwargs.pop("headers", {})
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = httpx.request(method, url, headers=headers, timeout=10, **kwargs)
    return r


def main():
    gate = init_gate(auth_enabled=True)

    admin_email = "admin@demo.example.com"
    admin_password = "DemoP@ssw0rd!2024"

    # -----------------------------------------------------------------------
    # Scenario 1: Bootstrap the first admin user
    # -----------------------------------------------------------------------
    header("Bootstrap — create the first admin user")

    resp = api("POST", "/api/v1/auth/bootstrap", json={
        "email": admin_email,
        "password": admin_password,
    })
    if resp.status_code == 200:
        data = resp.json()
        print(f"  Admin created: {data.get('user', {}).get('email')}")
        print(f"  Role: {data.get('user', {}).get('org_role')}")
        admin_token = data.get("access_token")
    elif resp.status_code == 409:
        print(f"  Admin already exists (bootstrap is one-time only)")
        print(f"  Logging in instead...")
        admin_token = None
    else:
        print(f"  Bootstrap failed: {resp.status_code} {resp.text[:200]}")
        admin_token = None

    pause("Users tab: see the bootstrapped admin user")

    # -----------------------------------------------------------------------
    # Scenario 2: Login with email + password
    # -----------------------------------------------------------------------
    header("Login — email + password → JWT tokens")

    resp = api("POST", "/api/v1/auth/login", json={
        "email": admin_email,
        "password": admin_password,
    })
    if resp.status_code == 200:
        data = resp.json()
        admin_token = data["access_token"]
        refresh_token = data["refresh_token"]
        print(f"  Login successful!")
        print(f"  Access token:  {admin_token[:40]}...")
        print(f"  Refresh token: {refresh_token[:40]}...")
    else:
        print(f"  Login failed: {resp.status_code} {resp.text[:200]}")
        print(f"  (If auth was already set up, credentials may differ)")
        wait_for_exit()
        return

    # -----------------------------------------------------------------------
    # Scenario 3: Authenticated request — /me endpoint
    # -----------------------------------------------------------------------
    header("Authenticated request — GET /me")

    resp = api("GET", "/api/v1/auth/me", token=admin_token)
    if resp.status_code == 200:
        me = resp.json()
        print(f"  Email:    {me.get('email')}")
        print(f"  Org ID:   {me.get('org_id')}")
        print(f"  Org role: {me.get('org_role')}")
    else:
        print(f"  Failed: {resp.status_code}")

    # -----------------------------------------------------------------------
    # Scenario 4: Create a viewer user
    # -----------------------------------------------------------------------
    header("Create a viewer user (admin-only operation)")

    resp = api("POST", "/api/v1/users", token=admin_token, json={
        "email": "viewer@demo.example.com",
        "password": "ViewerP@ss!2024",
        "org_role": "team_viewer",
    })
    if resp.status_code in (200, 201):
        viewer = resp.json()
        print(f"  Viewer created: {viewer.get('email')}")
        print(f"  Role: {viewer.get('org_role')}")
    elif resp.status_code == 409:
        print(f"  Viewer already exists")
    else:
        print(f"  Create failed: {resp.status_code} {resp.text[:200]}")

    # Login as viewer
    resp = api("POST", "/api/v1/auth/login", json={
        "email": "viewer@demo.example.com",
        "password": "ViewerP@ss!2024",
    })
    viewer_token = resp.json().get("access_token") if resp.status_code == 200 else None

    pause("Users tab: see both admin and viewer users listed")

    # -----------------------------------------------------------------------
    # Scenario 5: Permission denied — viewer on admin endpoint
    # -----------------------------------------------------------------------
    header("Permission denied — viewer can't manage users")

    if viewer_token:
        resp = api("POST", "/api/v1/users", token=viewer_token, json={
            "email": "hacker@evil.com",
            "password": "HackP@ss!",
        })
        print(f"  Viewer tried to create user:")
        print(f"    Status: {resp.status_code} (expected 403)")
        if resp.status_code == 403:
            print(f"    DENIED — viewers cannot manage users")
        else:
            print(f"    Response: {resp.text[:200]}")
    else:
        print(f"  (Skipped — viewer login failed)")

    # -----------------------------------------------------------------------
    # Scenario 6: Token refresh
    # -----------------------------------------------------------------------
    header("Token refresh — get a new access token")

    resp = api("POST", "/api/v1/auth/refresh", json={
        "refresh_token": refresh_token,
    })
    if resp.status_code == 200:
        data = resp.json()
        new_token = data["access_token"]
        print(f"  New access token: {new_token[:40]}...")
        print(f"  Token refreshed successfully!")

        # Verify the new token works
        resp = api("GET", "/api/v1/auth/me", token=new_token)
        if resp.status_code == 200:
            print(f"  Verified: new token works for /me")
    else:
        print(f"  Refresh failed: {resp.status_code} {resp.text[:200]}")

    pause(
        "Authentication demo complete.\n"
        "  >> Admin + viewer users with different permission levels.\n"
        "  >> JWT tokens with refresh rotation."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
