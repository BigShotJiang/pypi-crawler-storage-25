#!/usr/bin/env python3
"""Demo: Multi-Model Workflows with Per-Model Cost Breakdown.

Shows how StateLoom tracks cost and tokens per model when a session
orchestrates calls to multiple models — cheap models for simple tasks,
powerful models for complex reasoning.

Requires: at least one of OPENAI_API_KEY, ANTHROPIC_API_KEY, or GOOGLE_API_KEY.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

# Map each provider's cheap model to its powerful counterpart
_POWERFUL_MODELS = {
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-20250514",
    "google": "gemini-2.5-pro",
}

POWERFUL_MODEL = _POWERFUL_MODELS[PROVIDER]


def main():
    gate = init_gate()

    # ---------------------------------------------------------------------------
    # Scenario 1: Content Pipeline — single session, two models
    # ---------------------------------------------------------------------------
    header("Content Pipeline (cheap model → powerful model)")

    print(f"  Cheap model:    {MODEL}")
    print(f"  Powerful model: {POWERFUL_MODEL}\n")

    with stateloom.session(name="content-pipeline") as s:
        # Phase 1: Outline with the cheap model (default)
        print("  Phase 1: Generating outline with cheap model...")
        outline = ask(user_msg("Write a 3-bullet outline for a blog post about AI agent observability"))
        print(f"  Outline: {outline.content[:120]}...\n")

        stateloom.checkpoint("outline-complete", "Outline generated with cheap model")

        # Phase 2: Full article with the powerful model
        print("  Phase 2: Writing article with powerful model...")
        article = ask(
            user_msg(f"Expand this outline into a short blog post (2 paragraphs):\n{outline.content}"),
            model=POWERFUL_MODEL,
        )
        print(f"  Article: {article.content[:120]}...\n")

        stateloom.checkpoint("article-complete", "Article written with powerful model")

        # Phase 3: Tags with the cheap model
        print("  Phase 3: Generating tags with cheap model...")
        tags = ask(user_msg(f"List 5 SEO tags for this article:\n{article.content}"))
        print(f"  Tags: {tags.content[:120]}...\n")

        # Show breakdown
        print("  ┌─────────────────────────────────────────────────┐")
        print("  │            Per-Model Cost Breakdown              │")
        print("  ├─────────────────────────────────────────────────┤")
        for model, cost in s.cost_by_model.items():
            tokens = s.tokens_by_model.get(model, {})
            pt = tokens.get("prompt_tokens", 0)
            ct = tokens.get("completion_tokens", 0)
            tt = tokens.get("total_tokens", 0)
            print(f"  │  {model:<35} ${cost:.6f} │")
            print(f"  │    prompt={pt:>6}  completion={ct:>6}  total={tt:>6} │")
        print(f"  ├─────────────────────────────────────────────────┤")
        print(f"  │  Session total: ${s.total_cost:.6f}  ({s.call_count} calls)     │")
        print(f"  └─────────────────────────────────────────────────┘")

    pause("Open the session detail to see the per-model cost breakdown and waterfall timeline")

    # ---------------------------------------------------------------------------
    # Scenario 2: Research Orchestrator — parent + child sessions
    # ---------------------------------------------------------------------------
    header("Research Orchestrator (parent/child sessions)")

    with stateloom.session(name="research-orchestrator") as parent:
        # Child 1: gather data with cheap model
        print("  Child 1: Gathering data with cheap model...")
        with stateloom.session(name="data-gathering") as child1:
            ask(user_msg("List 3 key trends in AI agent frameworks in 2025"))
            ask(user_msg("What are the top 3 challenges in AI agent observability?"))

        # Child 2: analyze with powerful model
        print("  Child 2: Analyzing with powerful model...")
        with stateloom.session(name="deep-analysis") as child2:
            ask(
                user_msg("Compare LangSmith vs StateLoom for AI agent observability. Be concise."),
                model=POWERFUL_MODEL,
            )

        # Parent: synthesize with powerful model
        print("  Parent: Synthesizing final report...\n")
        ask(
            user_msg("Write a one-paragraph executive summary about AI agent observability trends."),
            model=POWERFUL_MODEL,
        )

        # Show breakdown for each session
        for label, sess in [("Parent", parent), ("Child 1 (data)", child1), ("Child 2 (analysis)", child2)]:
            print(f"  {label}:")
            if sess.cost_by_model:
                for model, cost in sess.cost_by_model.items():
                    tt = sess.tokens_by_model.get(model, {}).get("total_tokens", 0)
                    print(f"    {model}: ${cost:.6f} ({tt} tokens)")
            else:
                print(f"    (no per-model breakdown)")
            print(f"    Total: ${sess.total_cost:.6f}\n")

    pause("Check parent/child session hierarchy and per-model breakdowns in each")

    wait_for_exit()


if __name__ == "__main__":
    main()
