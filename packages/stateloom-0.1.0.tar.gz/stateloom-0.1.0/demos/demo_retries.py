#!/usr/bin/env python3
"""Demo: Semantic Retries — monitor at http://localhost:4781

Real-world scenario: An LLM is asked to return structured JSON, but
sometimes returns invalid output. The retry loop automatically retries
with the original prompt until valid output is produced.
"""

import json
import re
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def strip_markdown_json(text: str) -> str:
    """Strip markdown code fences from JSON responses."""
    text = text.strip()
    m = re.match(r"^```(?:json)?\s*\n?(.*?)```$", text, re.DOTALL)
    return m.group(1).strip() if m else text


def main():
    gate = init_gate(cache=False)  # disable cache so retries make fresh LLM calls

    # --- Scenario 1: retry_loop inside a session ---
    header("Retry loop — parse JSON from LLM output")

    with stateloom.session(session_id="retry-json", name="JSON Retry Demo") as s:
        result = None
        for attempt in stateloom.retry_loop(retries=3):
            with attempt:
                r = ask([
                    {"role": "system", "content": (
                        "You are a data extraction API. Return ONLY valid JSON, no markdown, no explanation. "
                        "Format: {\"name\": string, \"age\": number, \"skills\": [string]}"
                    )},
                    {"role": "user", "content": "Extract structured data: John Smith is a 35-year-old Python and Go developer."},
                ])
                print(f"  Attempt {attempt.number}: {r.content[:80]}...")
                result = json.loads(strip_markdown_json(r.content))
                print(f"  Parsed:  {result}")

        if result:
            print(f"\n  Success! Got valid JSON after {s.call_count} call(s)")
            print(f"  Cost: ${s.total_cost:.6f}")
        else:
            print(f"\n  Failed to get valid JSON after all attempts")

    pause(
        "Sessions tab: click 'retry-json' — see LLM calls and semantic_retry events.\n"
        "  >> If all calls returned valid JSON, you'll see 1 call and no retries.\n"
        "  >> If any failed, retry events show the error and attempt number."
    )

    # --- Scenario 2: retry_loop with evolving requirements (forces retries) ---
    header("Retry loop — escalating validation (guarantees retries)")
    print("  Attempt 1 requires 3 fields → likely passes.")
    print("  Attempt 2 raises the bar: requires 5 fields → forces a retry.")
    print("  This simulates real-world scenarios where validation tightens.\n")

    with stateloom.session(session_id="retry-validate", name="Validation Retry") as s:
        result = None
        for attempt in stateloom.retry_loop(retries=4):
            with attempt:
                r = ask([
                    {"role": "system", "content": (
                        "Return ONLY valid JSON, no markdown. Extract all info. "
                        "Keys: name, age, skills, location, title."
                    )},
                    {"role": "user", "content": (
                        "Extract: Sarah Chen is a 28-year-old senior data scientist "
                        "from Seattle who knows Python, R, and SQL."
                    )},
                ])
                content = strip_markdown_json(r.content)
                print(f"  Attempt {attempt.number}: {content[:80]}...")

                parsed = json.loads(content)

                # Attempt 1: intentionally fail (simulate downstream schema check)
                if attempt.number == 1:
                    raise ValueError("Schema v2 requires 'years_experience' field (simulated failure)")

                # Attempt 2+: accept if we have the core fields
                required = {"name", "age", "skills"}
                missing = required - set(parsed.keys())
                if missing:
                    raise ValueError(f"Missing required keys: {missing}")
                result = parsed

        print(f"\n  Result: {result}")
        print(f"  Calls: {s.call_count}  Cost: ${s.total_cost:.6f}")

    pause(
        "Sessions tab: click 'retry-validate' — RETRIES card shows 1 failed attempt.\n"
        "  >> Waterfall: Retry event shows 'Schema v2 requires...' error, then LLM call succeeds."
    )

    # --- Scenario 3: durable_task decorator ---
    header("durable_task — automatic retry with crash recovery")

    @stateloom.durable_task(retries=3)
    def extract_entities(text: str) -> dict:
        """Extract named entities from text — retries on bad JSON."""
        r = ask([
            {"role": "system", "content": (
                "Extract named entities. Return ONLY valid JSON: "
                "{\"people\": [string], \"companies\": [string], \"locations\": [string]}"
            )},
            {"role": "user", "content": f"Extract entities from: {text}"},
        ])
        return json.loads(strip_markdown_json(r.content))

    try:
        entities = extract_entities(
            "Tim Cook announced that Apple will open a new campus in Austin, Texas. "
            "Microsoft CEO Satya Nadella congratulated the move."
        )
        print(f"  Entities: {entities}")
    except stateloom.StateLoomRetryError as e:
        print(f"  All retries exhausted: {e}")
    except json.JSONDecodeError:
        print(f"  Could not parse JSON after all attempts")

    pause(
        "Sessions tab: see the durable_task session.\n"
        "  >> semantic_retry events show attempt number and error details.\n"
        "  >> If the task resumed from cache, earlier calls show zero cost."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
