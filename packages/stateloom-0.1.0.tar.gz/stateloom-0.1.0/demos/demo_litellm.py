#!/usr/bin/env python3
"""Demo: LiteLLM Integration — Zero-Config Auto-Patching

StateLoom automatically patches litellm.completion() and litellm.acompletion()
so every LLM call made through LiteLLM flows through the middleware pipeline.
Cost tracking, PII detection, caching, budgets — all work transparently.

LiteLLM supports 100+ providers through a unified interface. StateLoom layers
on top, giving you session-aware observability for any provider LiteLLM supports.

Requires: pip install litellm
          Plus at least one of OPENAI_API_KEY, ANTHROPIC_API_KEY, or GOOGLE_API_KEY.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    import litellm
except ImportError:
    print("\n  This demo requires LiteLLM: pip install litellm")
    print("  Then set at least one API key (OPENAI_API_KEY, etc.)")
    sys.exit(1)

# Suppress LiteLLM's verbose logging
litellm.suppress_debug_info = True
import logging
logging.getLogger("LiteLLM").setLevel(logging.WARNING)


def main():
    # stateloom.init() auto-patches litellm — zero config needed
    gate = init_gate()

    # -----------------------------------------------------------------------
    # Scenario 1: Basic litellm.completion() — auto-tracked by StateLoom
    # -----------------------------------------------------------------------
    header("litellm.completion() — auto-patched, zero config")

    with stateloom.session(session_id="litellm-basic", name="LiteLLM Basic") as s:
        print(f"  Calling litellm.completion(model='{MODEL}')...")
        response = litellm.completion(
            model=MODEL,
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Be concise."},
                {"role": "user", "content": "What is LiteLLM and why is it useful?"},
            ],
        )
        content = response.choices[0].message.content
        print(f"  Response: {content[:120]}...")
        print(f"\n  StateLoom tracked this call automatically:")
        print(f"    Cost:   ${s.total_cost:.6f}")
        print(f"    Tokens: {s.total_tokens}")
        print(f"    Calls:  {s.call_count}")

    pause("Sessions tab: click 'litellm-basic' — see the LLM call event with cost/tokens")

    # -----------------------------------------------------------------------
    # Scenario 2: Multi-call session — all calls tracked together
    # -----------------------------------------------------------------------
    header("Multi-call session — cost accumulates across calls")

    with stateloom.session(session_id="litellm-multi", name="LiteLLM Multi-Call") as s:
        topics = [
            "What is prompt engineering? One sentence.",
            "What is RAG? One sentence.",
            "What is fine-tuning? One sentence.",
        ]
        for i, topic in enumerate(topics, 1):
            r = litellm.completion(
                model=MODEL,
                messages=[{"role": "user", "content": topic}],
            )
            text = r.choices[0].message.content
            print(f"  Call {i}: {text[:80]}...")
            print(f"    Running cost: ${s.total_cost:.6f}  Tokens: {s.total_tokens}")

        print(f"\n  Session summary:")
        print(f"    Total calls:  {s.call_count}")
        print(f"    Total cost:   ${s.total_cost:.6f}")
        print(f"    Total tokens: {s.total_tokens}")

    pause("Sessions tab: 'litellm-multi' — 3 LLM call events, cumulative cost")

    # -----------------------------------------------------------------------
    # Scenario 3: Budget enforcement — works transparently with LiteLLM
    # -----------------------------------------------------------------------
    header("Budget enforcement — StateLoom stops LiteLLM calls at budget")

    with stateloom.session(
        session_id="litellm-budget",
        name="LiteLLM Budget",
        budget=0.001,
    ) as s:
        try:
            for i in range(5):
                r = litellm.completion(
                    model=MODEL,
                    messages=[{"role": "user", "content": f"Write a haiku about the number {i+1}"}],
                )
                print(f"  Call {i+1}: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"\n  BLOCKED by StateLoom budget: {e}")
            print(f"  LiteLLM didn't need any changes — StateLoom enforces budgets")
            print(f"  at the middleware level, transparently.")

    pause("Sessions tab: 'litellm-budget' — budget_enforcement event stops the session")

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    print("\n  LiteLLM + StateLoom summary:")
    print("  - stateloom.init() auto-patches litellm.completion/acompletion")
    print("  - Every call gets cost tracking, session grouping, event recording")
    print("  - Budgets, PII detection, caching, guardrails all work transparently")
    print("  - No code changes needed in your existing LiteLLM calls")
    print("  - Works with any of LiteLLM's 100+ supported providers")

    wait_for_exit()


if __name__ == "__main__":
    main()
