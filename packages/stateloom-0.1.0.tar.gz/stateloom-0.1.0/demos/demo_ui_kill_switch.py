#!/usr/bin/env python3
"""Demo: Kill Switch, Blast Radius, and Circuit Breaker via Dashboard API

Activates and deactivates the kill switch through REST calls, adds granular
rules, toggles blast radius settings, and queries circuit breaker state.

Endpoints exercised:
  GET    /api/v1/kill-switch
  POST   /api/v1/kill-switch/activate
  POST   /api/v1/kill-switch/deactivate
  POST   /api/v1/kill-switch/rules
  PUT    /api/v1/kill-switch/rules
  DELETE /api/v1/kill-switch/rules
  PATCH  /api/v1/config              (kill_switch_response_mode, blast_radius_*)
  GET    /api/v1/blast-radius
  GET    /api/v1/blast-radius/events
  POST   /api/v1/blast-radius/unpause-session/{id}
  GET    /api/v1/circuit-breaker
  POST   /api/v1/circuit-breaker/{provider}/reset
"""

import sys, os, uuid
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    init_gate()

    # -----------------------------------------------------------------------
    # 1. Baseline — normal call works
    # -----------------------------------------------------------------------
    header("Baseline — LLM call succeeds")
    with stateloom.session(session_id="ks-baseline", name="Kill Switch Baseline") as s:
        r = ask(user_msg("What is the capital of France? One word."))
        print(f"  Response: {r.content[:60]}")
        print(f"  ✓ Call succeeded, cost=${s.total_cost:.6f}")

    # -----------------------------------------------------------------------
    # 2. Check kill switch status (should be off)
    # -----------------------------------------------------------------------
    header("GET /kill-switch — should be inactive")
    resp = api("GET", "/kill-switch")
    ks = resp.json()
    print(f"  active: {ks.get('active')}")
    print(f"  message: {ks.get('message')}")
    print(f"  rules: {len(ks.get('rules', []))}")

    # -----------------------------------------------------------------------
    # 3. Activate global kill switch
    # -----------------------------------------------------------------------
    header("POST /kill-switch/activate → block ALL traffic")
    resp = api("POST", "/kill-switch/activate", json={
        "message": "Emergency maintenance — all LLM traffic halted",
    })
    print(f"  Activate status: {resp.status_code}")

    # Verify it's active
    ks = api("GET", "/kill-switch").json()
    print(f"  active: {ks.get('active')}")
    print(f"  message: {ks.get('message')}")

    with stateloom.session(session_id=f"ks-blocked-{uuid.uuid4().hex[:6]}", name="Kill Switch Blocked") as s:
        try:
            r = ask(user_msg("This should be blocked."))
            print(f"  Response: {r.content[:60]}...")
        except stateloom.StateLoomKillSwitchError as e:
            print(f"  ✓ BLOCKED: {e}")

    pause("Safety > Kill Switch: see it's ACTIVE. Sessions tab: 'ks-blocked' has kill switch event.")

    # -----------------------------------------------------------------------
    # 4. Deactivate global kill switch
    # -----------------------------------------------------------------------
    header("POST /kill-switch/deactivate → resume traffic")
    resp = api("POST", "/kill-switch/deactivate")
    print(f"  Deactivate status: {resp.status_code}")

    with stateloom.session(session_id="ks-resumed", name="Kill Switch Resumed") as s:
        r = ask(user_msg("Confirm service is back. Reply 'OK'."))
        print(f"  Response: {r.content[:40]}")
        print(f"  ✓ Traffic flowing again")

    # -----------------------------------------------------------------------
    # 5. Add granular kill switch rules
    # -----------------------------------------------------------------------
    header("POST /kill-switch/rules — block specific model pattern")
    resp = api("POST", "/kill-switch/rules", json={
        "model": "gpt-4o",
        "reason": "GPT-4o cost spike",
        "message": "GPT-4o temporarily blocked",
    })
    print(f"  Add rule (gpt-4o): {resp.status_code}")

    resp = api("POST", "/kill-switch/rules", json={
        "provider": "anthropic",
        "reason": "Anthropic maintenance",
        "message": "Anthropic models temporarily blocked",
    })
    print(f"  Add rule (anthropic): {resp.status_code}")

    # Check rules
    ks = api("GET", "/kill-switch").json()
    print(f"\n  Rules ({len(ks.get('rules', []))}):")
    for rule in ks.get("rules", []):
        print(f"    model={rule.get('model')}  provider={rule.get('provider')}  "
              f"reason={rule.get('reason')}")

    # Try a call — may pass or block depending on current provider
    with stateloom.session(session_id="ks-rules-test", name="Rules Test") as s:
        try:
            r = ask(user_msg("Does this go through?"))
            print(f"\n  Call with {MODEL}: PASSED → {r.content[:40]}")
        except stateloom.StateLoomKillSwitchError as e:
            print(f"\n  Call with {MODEL}: BLOCKED by rule → {e}")

    pause("Safety > Kill Switch: see the granular rules configured")

    # -----------------------------------------------------------------------
    # 6. Replace rules with empty list
    # -----------------------------------------------------------------------
    header("PUT /kill-switch/rules → replace with empty list")
    resp = api("PUT", "/kill-switch/rules", json={"rules": []})
    print(f"  PUT status: {resp.status_code}")

    ks = api("GET", "/kill-switch").json()
    print(f"  Rules remaining: {len(ks.get('rules', []))}")

    # -----------------------------------------------------------------------
    # 7. DELETE all rules (redundant but exercises the endpoint)
    # -----------------------------------------------------------------------
    header("DELETE /kill-switch/rules — clear all")
    resp = api("DELETE", "/kill-switch/rules")
    print(f"  DELETE status: {resp.status_code}")

    with stateloom.session(session_id="ks-clear", name="Rules Cleared") as s:
        r = ask(user_msg("All rules cleared. Reply 'OK'."))
        print(f"  Response: {r.content[:40]}")
        print(f"  ✓ No rules — call passes")

    # -----------------------------------------------------------------------
    # 8. Kill switch response mode: error (raises StateLoomKillSwitchError)
    # -----------------------------------------------------------------------
    header("PATCH /config → kill_switch_response_mode=error")
    api("PATCH", "/config", json={"kill_switch_response_mode": "error"})
    api("POST", "/kill-switch/activate", json={
        "message": "Service is temporarily unavailable. Please try again later.",
    })
    print(f"  Activated kill switch with response_mode=error")

    with stateloom.session(session_id="ks-response-mode", name="Response Mode") as s:
        try:
            r = ask(user_msg("What happens now?"))
            print(f"  Response: {r.content[:100]}")
        except stateloom.StateLoomKillSwitchError as e:
            print(f"  ✓ BLOCKED (error mode): {e}")

    # Clean up
    api("POST", "/kill-switch/deactivate")
    print(f"\n  Restored: deactivated kill switch")

    pause("Sessions tab: 'ks-response-mode' — blocked with kill switch error")

    # -----------------------------------------------------------------------
    # 9. Blast radius config
    # -----------------------------------------------------------------------
    header("Blast Radius — enable and query via API")
    api("PATCH", "/config", json={
        "blast_radius_enabled": True,
        "blast_radius_consecutive_failures": 3,
        "blast_radius_budget_violations_per_hour": 5,
    })
    print(f"  Enabled blast radius (3 failures, 5 budget violations/hr)")

    resp = api("GET", "/blast-radius")
    br = resp.json()
    print(f"  Blast radius status: {br}")

    resp = api("GET", "/blast-radius/events")
    events = resp.json()
    print(f"  Blast radius events: {len(events.get('events', []))}")

    # Try to unpause a session (will 404 if none paused, that's OK)
    resp = api("POST", "/blast-radius/unpause-session/nonexistent-id")
    print(f"  Unpause session (nonexistent): {resp.status_code} (expected 404)")

    # Clean up
    api("PATCH", "/config", json={"blast_radius_enabled": False})
    print(f"\n  Disabled blast radius")

    # -----------------------------------------------------------------------
    # 10. Circuit breaker status
    # -----------------------------------------------------------------------
    header("Circuit Breaker — query and reset")
    resp = api("GET", "/circuit-breaker")
    cb = resp.json()
    print(f"  Circuit breaker status:")
    if isinstance(cb, dict):
        for provider, state in cb.items():
            if isinstance(state, dict):
                print(f"    {provider}: state={state.get('state')}  failures={state.get('failures', 0)}")
            else:
                print(f"    {provider}: {state}")
    else:
        print(f"    {cb}")

    # Reset a provider's circuit breaker
    resp = api("POST", f"/circuit-breaker/{PROVIDER}/reset")
    print(f"\n  Reset {PROVIDER} circuit breaker: {resp.status_code}")

    pause("Safety tab: all safety controls exercised — kill switch, blast radius, circuit breaker")

    wait_for_exit()


if __name__ == "__main__":
    main()
