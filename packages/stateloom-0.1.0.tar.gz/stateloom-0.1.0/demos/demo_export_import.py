#!/usr/bin/env python3
"""Demo: Session Export/Import — portable JSON bundles

Real-world scenario: A developer finds a bug during an agent session.
They export the full trace as a JSON file, send it to a teammate, who
imports it and replays the exact same sequence — zero API calls wasted.

Also demonstrates: PII scrubbing on export, gzip compression, parent-child
session export, and dashboard export/import endpoints.
"""

import sys, os  # noqa: E401
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *  # noqa: E402, F403


def main():
    gate = init_gate()

    # ── Demo 1: Basic export ──────────────────────────────────────────────
    header("Export a session as a portable JSON bundle")

    with stateloom.session(
        session_id="debug-session-42", name="Bug Investigation",
    ) as s:
        s.metadata["ticket"] = "AGENT-1234"
        s.metadata["developer"] = "alice"

        r1 = ask([
            {"role": "system", "content": "You are a helpful coding assistant."},
            {"role": "user", "content": "What are common causes of race conditions?"},
        ])
        print(f"  [Step 1] LLM response: {r1.content[:100]}...")

        stateloom.checkpoint("analysis_done", "Root cause identified")

        r2 = ask([
            {"role": "user", "content": "How do I fix a race condition with asyncio.Lock?"},
        ])
        print(f"  [Step 2] LLM response: {r2.content[:100]}...")

        print(f"\n  Session complete — cost: ${s.total_cost:.6f}, calls: {s.call_count}")

    # Export to dict
    bundle = stateloom.export_session("debug-session-42")
    print("\n  Exported bundle:")
    print(f"    schema_version: {bundle['schema_version']}")
    print(f"    stateloom_version: {bundle['stateloom_version']}")
    print(f"    events: {len(bundle['events'])}")
    print(f"    session.total_cost: ${bundle['session']['total_cost']:.6f}")
    print(f"    session.step_counter: {bundle['session']['step_counter']}")

    # Export to file
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        json_path = f.name
    stateloom.export_session("debug-session-42", json_path)
    file_size = os.path.getsize(json_path)
    print(f"\n  Written to: {json_path} ({file_size:,} bytes)")

    # Export to gzip
    gz_path = json_path + ".gz"
    stateloom.export_session("debug-session-42", gz_path)
    gz_size = os.path.getsize(gz_path)
    ratio = f"{gz_size / file_size:.0%}" if file_size else "N/A"
    print(f"  Gzipped to: {gz_path} ({gz_size:,} bytes, {ratio} of original)")

    pause(
        "Sessions tab: click 'debug-session-42' to see the full trace.\n"
        "  >> The exported JSON contains the exact same data."
    )

    # ── Demo 2: Import with a new ID (simulating teammate) ────────────────
    header("Import the bundle with a new session ID (teammate scenario)")

    print("  Teammate received the JSON file and imports it...")
    imported = stateloom.import_session(
        json_path, session_id_override="teammate-review-001",
    )
    print(f"\n  Imported session: {imported.id}")
    print(f"    name: {imported.name}")
    print(f"    total_cost: ${imported.total_cost:.6f}")
    print(f"    step_counter: {imported.step_counter}")
    print(f"    metadata.ticket: {imported.metadata.get('ticket')}")

    # Verify events came through
    events = gate.store.get_session_events(imported.id)
    print(f"    events imported: {len(events)}")
    for e in events:
        model_info = ""
        if hasattr(e, "model") and e.model:
            model_info = f" (model={e.model})"
        print(f"      - step {e.step}: {e.event_type.value}{model_info}")

    pause(
        "Sessions tab: you should see BOTH 'debug-session-42' and\n"
        "  'teammate-review-001' — same trace data, different IDs.\n"
        "  >> Click either to see events, costs, and the waterfall."
    )

    # ── Demo 3: PII scrubbing on export ──────────────────────────────────
    header("Export with PII scrubbing")

    with stateloom.session(session_id="pii-session", name="PII Demo") as s:
        ask([
            {"role": "user", "content": "My email is alice@company.com. Help!"},
        ])

    # Export without scrubbing
    bundle_raw = stateloom.export_session("pii-session")
    preview_raw = bundle_raw["events"][0].get("prompt_preview", "")

    # Export with scrubbing
    bundle_scrubbed = stateloom.export_session("pii-session", scrub_pii=True)
    preview_scrubbed = bundle_scrubbed["events"][0].get("prompt_preview", "")

    print(f"\n  Without PII scrub: {preview_raw[:80]}...")
    print(f"  With PII scrub:    {preview_scrubbed[:80]}...")
    print(f"  pii_scrubbed flag: {bundle_scrubbed['pii_scrubbed']}")

    pause(
        "The scrubbed export replaces PII with [PII_REDACTED:pattern].\n"
        "  >> Safe to share with external collaborators."
    )

    # ── Demo 4: Parent-child export ──────────────────────────────────────
    header("Export parent session with children")

    with stateloom.session(
        session_id="parent-task", name="Parent Task",
    ):
        ask(user_msg("What is the capital of France?"))
        print(f"  [Parent] LLM call done")

        with stateloom.session(
            session_id="child-subtask", name="Child Subtask",
        ):
            ask(user_msg("What is the population of Paris?"))
            print(f"  [Child]  LLM call done")

    # Export with children
    bundle = stateloom.export_session("parent-task", include_children=True)
    print(f"\n  Parent events: {len(bundle['events'])}")
    print(f"  Children exported: {len(bundle['children'])}")
    if bundle["children"]:
        cb = bundle["children"][0]
        print(f"    Child ID: {cb['session']['id']}")
        print(f"    Child events: {len(cb['events'])}")

    # Re-import parent+children under new IDs
    reimported = stateloom.import_session(
        bundle, session_id_override="reimport-parent",
    )
    children = gate.store.list_child_sessions(reimported.id)
    print(f"\n  Re-imported parent: {reimported.id}")
    print(f"  Re-imported children: {len(children)}")

    pause(
        "Sessions tab: you now see the original parent+child AND the\n"
        "  re-imported copies. The hierarchy is preserved in the bundle.\n"
        "  >> Click 'parent-task' → Children tab to see the relationship."
    )

    # Cleanup temp files
    try:
        os.unlink(json_path)
        os.unlink(gz_path)
    except OSError:
        pass

    wait_for_exit()


if __name__ == "__main__":
    main()
