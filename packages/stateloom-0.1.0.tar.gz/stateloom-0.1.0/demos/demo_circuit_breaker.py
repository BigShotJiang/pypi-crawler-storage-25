#!/usr/bin/env python3
"""Demo: Circuit Breaker — monitor at http://localhost:4781

Real-world scenario: Provider outages happen. The circuit breaker detects
consecutive failures, trips the circuit, and blocks further requests until
the provider recovers. After a manual reset (or recovery timeout), traffic
resumes normally.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

from stateloom.core.errors import StateLoomCircuitBreakerError


def main():
    # Low threshold (3 failures) so we can trip it quickly in the demo
    gate = init_gate(
        circuit_breaker=True,
        circuit_breaker_failure_threshold=3,
        circuit_breaker_window_seconds=300,
        circuit_breaker_recovery_timeout=60,
        circuit_breaker_fallback_map={
            "gpt-4o-mini": "claude-haiku-4-5-20251001",
            "gpt-4o": "claude-sonnet-4-20250514",
            "claude-haiku-4-5-20251001": "gpt-4o-mini",
        },
    )

    # --- Scenario 1: Normal operation (circuit CLOSED) ---
    header("Normal operation — circuit breaker is CLOSED")
    with stateloom.session(session_id="cb-healthy", name="Healthy Call") as s:
        r = ask(user_msg("What is the speed of light? One sentence."))
        print(f"  Response: {r.content[:80]}...")
        print(f"  Cost: ${s.total_cost:.6f}")

    status = stateloom.circuit_breaker_status()
    providers = status.get("providers", {})
    for prov, info in providers.items():
        if isinstance(info, dict):
            print(f"  {prov}: state={info['state']}, failures={info['failure_count']}")

    pause(
        "Circuit breaker is CLOSED (healthy). One successful call recorded.\n"
        "  >> Sessions tab: 'cb-healthy' shows a normal LLM call."
    )

    # --- Scenario 2: Simulate provider failures (invalid model → API error) ---
    header("Simulating provider failures (3 calls with invalid model)")
    print("  Using model 'gpt-NONEXISTENT' to trigger OpenAI API errors...\n")

    for i in range(1, 4):
        with stateloom.session(session_id=f"cb-fail-{i}", name=f"Failure {i}") as s:
            try:
                ask(user_msg("Hello"), model="gpt-NONEXISTENT")
                print(f"  [{i}] Unexpected success")
            except StateLoomCircuitBreakerError as e:
                print(f"  [{i}] CIRCUIT OPEN! Provider '{e.provider}' blocked.")
                print(f"       Suggested fallback: {e.fallback_model or 'none'}")
            except Exception as e:
                print(f"  [{i}] Provider error: {type(e).__name__}: {str(e)[:80]}")

        # Show running failure count
        status = stateloom.circuit_breaker_status()
        providers = status.get("providers", {})
        for prov, info in providers.items():
            if isinstance(info, dict):
                print(f"       >> {prov}: state={info['state']}, failures={info['failure_count']}/{gate.config.circuit_breaker_failure_threshold}")
        print()

    pause(
        "After 3 failures, the circuit should be OPEN for 'openai'.\n"
        "  >> Sessions tab: 'cb-fail-*' sessions show provider errors.\n"
        "  >> Circuit breaker events visible in the event stream."
    )

    # --- Scenario 3: Circuit is OPEN — next call is blocked immediately ---
    header("Circuit OPEN — new requests are blocked instantly")
    with stateloom.session(session_id="cb-blocked", name="Blocked by CB") as s:
        try:
            ask(user_msg("This should be blocked"), model="gpt-4o-mini")
            print("  Unexpected success — circuit should have blocked this!")
        except StateLoomCircuitBreakerError as e:
            print(f"  BLOCKED! Circuit breaker for '{e.provider}' is OPEN.")
            print(f"  Fallback model: {e.fallback_model or 'none configured'}")
            print(f"  No API call was made — the request was rejected immediately.")
        except Exception as e:
            print(f"  Error: {type(e).__name__}: {str(e)[:80]}")

    status = stateloom.circuit_breaker_status()
    print(f"\n  Full status: {status}")

    pause(
        "The circuit is OPEN — requests are rejected without hitting the provider.\n"
        "  >> 'cb-blocked' session shows a circuit_breaker event (no LLM call).\n"
        "  >> The fallback model is suggested in the error."
    )

    # --- Scenario 4: Manual reset → circuit recovers ---
    header("Manual reset — circuit recovers")
    print("  Resetting openai circuit breaker...")
    result = stateloom.reset_circuit_breaker("openai")
    print(f"  Reset result: {result}")

    status = stateloom.circuit_breaker_status()
    providers = status.get("providers", {})
    for prov, info in providers.items():
        if isinstance(info, dict):
            print(f"  {prov}: state={info['state']}, failures={info['failure_count']}")

    # Now a real call should work again
    print("\n  Making a real call after reset...")
    with stateloom.session(session_id="cb-recovered", name="Recovered Call") as s:
        r = ask(user_msg("What is 2 + 2? One word answer."))
        print(f"  Response: {r.content[:80]}...")
        print(f"  Cost: ${s.total_cost:.6f}")
        print(f"  Circuit breaker allowed the call through!")

    pause(
        "After manual reset, the circuit is CLOSED again and calls succeed.\n"
        "  >> 'cb-recovered' session shows a normal LLM call.\n"
        "  >> In production, recovery happens automatically after the timeout."
    )

    # --- Scenario 5: Configuration summary ---
    header("Circuit breaker configuration")
    print(f"  Enabled:           {gate.config.circuit_breaker_enabled}")
    print(f"  Failure threshold: {gate.config.circuit_breaker_failure_threshold}")
    print(f"  Window (seconds):  {gate.config.circuit_breaker_window_seconds}")
    print(f"  Recovery timeout:  {gate.config.circuit_breaker_recovery_timeout}")
    print(f"  Fallback map:      {gate.config.circuit_breaker_fallback_map}")
    print()
    print("  How it works:")
    print(f"    1. Track failures per provider in a {gate.config.circuit_breaker_window_seconds}s sliding window")
    print(f"    2. After {gate.config.circuit_breaker_failure_threshold} failures → circuit OPENS (blocks all traffic)")
    print(f"    3. After {gate.config.circuit_breaker_recovery_timeout}s → circuit goes HALF_OPEN (sends probe)")
    print("    4. If probe succeeds → CLOSED (healthy); if fails → back to OPEN")
    print("    5. Manual reset via dashboard or API also recovers immediately")

    wait_for_exit()


if __name__ == "__main__":
    main()
