#!/usr/bin/env python3
"""Demo: Admin Locks, Model Switching, Provider Keys, Shadow & Local Status

Locks configuration settings so they can't be changed, switches the default
model at runtime, and queries provider key status, shadow metrics, and local
model availability.

Endpoints exercised:
  POST   /api/v1/admin/locks
  GET    /api/v1/admin/locks
  DELETE /api/v1/admin/locks/{setting}
  GET    /api/v1/provider-keys
  PATCH  /api/v1/config   (default_model, console_verbose, shadow_enabled,
                            auto_route_enabled)
  GET    /api/v1/config
  GET    /api/v1/shadow/metrics
  GET    /api/v1/local/status
  GET    /api/v1/local/models
  GET    /api/v1/local/recommend
  GET    /api/v1/local/hot-swap
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


# Pick an alternate model for the same provider
_ALT_MODELS = {
    "openai": "gpt-4o-mini",       # switch between gpt-4o-mini variants
    "anthropic": "claude-haiku-4-5-20251001",
    "google": "gemini-2.5-flash",
}


def main():
    gate = init_gate()

    # -----------------------------------------------------------------------
    # 1. Provider keys status
    # -----------------------------------------------------------------------
    header("GET /provider-keys — which providers have keys?")
    resp = api("GET", "/provider-keys")
    keys_status = resp.json()
    print(f"  Provider key status:")
    if isinstance(keys_status, dict):
        for provider, has_key in keys_status.items():
            indicator = "✓ set" if has_key else "✗ not set"
            print(f"    {provider}: {indicator}")
    else:
        print(f"    {keys_status}")

    # -----------------------------------------------------------------------
    # 2. Read current default model
    # -----------------------------------------------------------------------
    header("GET /config → current default_model")
    cfg = api("GET", "/config").json()
    original_model = cfg.get("default_model")
    print(f"  default_model: {original_model}")

    with stateloom.session(session_id="lock-model-1", name="Original Model") as s:
        r = ask(user_msg("What model are you? Reply with your model name."))
        print(f"  Response: {r.content[:80]}")

    # -----------------------------------------------------------------------
    # 3. Switch default model
    # -----------------------------------------------------------------------
    header("PATCH /config → change default_model")
    # Pick an alternate model (if OpenAI, try gpt-4o; if already gpt-4o, stay)
    alt_model = _ALT_MODELS.get(PROVIDER, MODEL)
    if alt_model == original_model:
        # If same, just demonstrate the API still works
        print(f"  (Same model as current; demonstrating the API call)")
    resp = api("PATCH", "/config", json={"default_model": alt_model})
    print(f"  PATCH default_model={alt_model} → {resp.status_code}")

    cfg = api("GET", "/config").json()
    print(f"  Confirmed: default_model={cfg.get('default_model')}")

    with stateloom.session(session_id="lock-model-2", name="Switched Model") as s:
        r = ask(user_msg("What model are you? Reply with your model name."))
        print(f"  Response: {r.content[:80]}")

    # Restore
    api("PATCH", "/config", json={"default_model": original_model})
    print(f"\n  Restored default_model={original_model}")

    pause("Sessions tab: compare 'lock-model-1' vs 'lock-model-2' model in metadata")

    # -----------------------------------------------------------------------
    # 4. Lock a setting
    # -----------------------------------------------------------------------
    header("POST /admin/locks — lock budget_per_session to $5.00")
    resp = api("POST", "/admin/locks", json={
        "setting": "budget_per_session",
        "value": 5.0,
        "reason": "Enforced by platform admin — no team can lower this",
    })
    print(f"  Lock status: {resp.status_code}")
    if resp.status_code in (200, 201):
        print(f"  ✓ budget_per_session locked at $5.00")
    else:
        print(f"  Response: {resp.text[:200]}")

    # -----------------------------------------------------------------------
    # 5. List all locks
    # -----------------------------------------------------------------------
    header("GET /admin/locks — list all locked settings")
    resp = api("GET", "/admin/locks")
    locks = resp.json()
    if isinstance(locks, list):
        print(f"  Locked settings ({len(locks)}):")
        for lock in locks:
            print(f"    {lock.get('setting')}: value={lock.get('value')}  "
                  f"reason={lock.get('reason')}")
    else:
        print(f"  {locks}")

    # -----------------------------------------------------------------------
    # 6. Try to change a locked setting → should fail
    # -----------------------------------------------------------------------
    header("PATCH /config → try to change locked setting")
    resp = api("PATCH", "/config", json={"budget_per_session": 0.001})
    print(f"  PATCH budget_per_session=0.001 → {resp.status_code}")
    if resp.status_code in (403, 409, 422):
        print(f"  ✓ REJECTED: locked setting cannot be changed")
        print(f"  Detail: {resp.json().get('detail', resp.text[:100])}")
    else:
        print(f"  Response: {resp.text[:200]}")

    # Verify the value didn't change
    cfg = api("GET", "/config").json()
    print(f"  Confirmed: budget_per_session={cfg.get('budget_per_session')} (unchanged)")

    # -----------------------------------------------------------------------
    # 7. Unlock the setting
    # -----------------------------------------------------------------------
    header("DELETE /admin/locks/budget_per_session — unlock")
    resp = api("DELETE", "/admin/locks/budget_per_session")
    print(f"  DELETE status: {resp.status_code}")

    # Now the change should work
    resp = api("PATCH", "/config", json={"budget_per_session": 0.50})
    print(f"  PATCH budget_per_session=0.50 → {resp.status_code}")
    if resp.status_code == 200:
        print(f"  ✓ Setting updated (no longer locked)")

    # Restore
    api("PATCH", "/config", json={"budget_per_session": 10.0})

    pause("Config tab: lock icon should appear/disappear on locked settings")

    # -----------------------------------------------------------------------
    # 8. Toggle console_verbose
    # -----------------------------------------------------------------------
    header("PATCH /config → console_verbose=True")
    api("PATCH", "/config", json={"console_verbose": True})
    print(f"  Enabled verbose console output")

    with stateloom.session(session_id="lock-verbose", name="Verbose Output") as s:
        r = ask(user_msg("Say hello. One word."))
        print(f"  Response: {r.content[:40]}")
        print(f"  (Check the terminal for verbose output above)")

    api("PATCH", "/config", json={"console_verbose": False})
    print(f"  Restored console_verbose=False")

    # -----------------------------------------------------------------------
    # 9. Auto-route toggle
    # -----------------------------------------------------------------------
    header("PATCH /config → auto_route_enabled toggle")
    resp = api("PATCH", "/config", json={"auto_route_enabled": True})
    print(f"  auto_route_enabled=True → {resp.status_code}")

    cfg = api("GET", "/config").json()
    print(f"  Confirmed: auto_route_enabled={cfg.get('auto_route_enabled')}")

    resp = api("PATCH", "/config", json={"auto_route_enabled": False})
    print(f"  auto_route_enabled=False → {resp.status_code}")

    # -----------------------------------------------------------------------
    # 10. Shadow metrics and local model status
    # -----------------------------------------------------------------------
    header("Shadow & local model endpoints")
    resp = api("GET", "/shadow/metrics")
    print(f"  GET /shadow/metrics → {resp.status_code}")
    if resp.status_code == 200:
        metrics = resp.json()
        print(f"    total_comparisons: {metrics.get('total_comparisons', 0)}")
        print(f"    avg_similarity: {metrics.get('avg_similarity', 'N/A')}")

    resp = api("GET", "/local/status")
    print(f"\n  GET /local/status → {resp.status_code}")
    if resp.status_code == 200:
        local = resp.json()
        print(f"    available: {local.get('available')}")
        print(f"    running_model: {local.get('running_model', 'none')}")

    resp = api("GET", "/local/models")
    print(f"\n  GET /local/models → {resp.status_code}")
    if resp.status_code == 200:
        models = resp.json()
        if isinstance(models, list):
            print(f"    Available models: {len(models)}")
            for m in models[:5]:
                name = m.get("name", m) if isinstance(m, dict) else m
                print(f"      - {name}")

    resp = api("GET", "/local/recommend")
    print(f"\n  GET /local/recommend → {resp.status_code}")

    resp = api("GET", "/local/hot-swap")
    print(f"  GET /local/hot-swap → {resp.status_code}")

    pause(
        "Config tab: see all settings including model, shadow, auto-route.\n"
        "  >> All endpoints exercised — locks, model switching, local status."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
