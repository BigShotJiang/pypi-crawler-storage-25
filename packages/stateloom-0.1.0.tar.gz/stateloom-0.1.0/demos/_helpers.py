"""Shared utilities for StateLoom interactive demo scripts.

Every demo imports from here to avoid duplicating boilerplate.
Uses real API keys from environment variables and makes real LLM calls.

Required: At least one of OPENAI_API_KEY, ANTHROPIC_API_KEY, or GOOGLE_API_KEY.
"""

from __future__ import annotations

import os
import socket
import sys

import requests as _requests

# Ensure src/ is on the path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import stateloom  # noqa: E402
from stateloom import PIIRule, KillSwitchRule  # noqa: E402, F401
from stateloom.core.errors import StateLoomError  # noqa: E402, F401
from stateloom.gate import Gate  # noqa: E402

DASHBOARD_URL = "http://localhost:4782"
DEMO_NUM = 0

# Track whether this demo started the gate or is reusing an existing one.
_demo_owns_gate = False


def _port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Check if a TCP port is already in use (i.e. a dashboard is running)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def detect_provider() -> tuple[str, str]:
    """Detect the best available provider from environment variables.

    Returns (provider_name, default_model).
    Override with STATELOOM_DEMO_PROVIDER=anthropic|google|openai.
    """
    override = os.environ.get("STATELOOM_DEMO_PROVIDER", "").lower()
    if override == "anthropic" and os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic", "claude-haiku-4-5-20251001"
    if override == "google" and os.environ.get("GOOGLE_API_KEY"):
        return "google", "gemini-3-flash-preview"
    if override == "openai" and os.environ.get("OPENAI_API_KEY"):
        return "openai", "gpt-4o-mini"

    if os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic", "claude-haiku-4-5-20251001"
    if os.environ.get("GOOGLE_API_KEY"):
        return "google", "gemini-3-flash-preview"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai", "gpt-4o-mini"
    print("\n  ERROR: No API key found.")
    print("  Set one of: OPENAI_API_KEY, ANTHROPIC_API_KEY, or GOOGLE_API_KEY")
    print("  Or override with: STATELOOM_DEMO_PROVIDER=anthropic|google|openai\n")
    sys.exit(1)


PROVIDER, MODEL = detect_provider()


def init_gate(**overrides) -> Gate:
    """Initialize StateLoom with sensible demo defaults.

    If an StateLoom dashboard is already running (same process or external),
    the demo attaches to it by using SQLite (shared storage) and skipping
    a second dashboard. Otherwise starts fresh with the given overrides.
    """
    global _demo_owns_gate, DASHBOARD_URL

    # Reuse in-process gate if one already exists
    if stateloom._gate is not None:
        gate = stateloom._gate
        print(f"\n  Reusing existing StateLoom instance (in-process)")
        print(f"  Provider: {PROVIDER} | Model: {MODEL}")
        print(f"  Dashboard: {DASHBOARD_URL}\n")
        return gate

    # Detect an external StateLoom dashboard on common ports
    dashboard_port = overrides.get("dashboard_port", 4782)
    check_ports = list(dict.fromkeys([dashboard_port, 4782, 4781]))
    external_port = None
    for port in check_ports:
        if _port_in_use(port):
            external_port = port
            break

    if external_port is not None:
        # Another StateLoom is running — use SQLite so both share the same data,
        # and skip starting a second dashboard.
        DASHBOARD_URL = f"http://localhost:{external_port}"
        overrides.setdefault("store_backend", "sqlite")
        overrides["dashboard"] = False
        print(f"\n  Detected existing StateLoom dashboard on port {external_port}")
        print(f"  Using SQLite store for shared data — sessions will appear in")
        print(f"  the running dashboard at {DASHBOARD_URL}")

    defaults = {
        "dashboard": True,
        "console_output": True,
        "store_backend": "memory",
        "default_model": MODEL,
        "auto_route": False,
        "shadow": False,
    }
    defaults.update(overrides)
    gate = stateloom.init(**defaults)
    _demo_owns_gate = True
    print(f"\n  Provider: {PROVIDER} | Model: {MODEL}")
    if defaults.get("dashboard"):
        print(f"  Dashboard: {DASHBOARD_URL}\n")
    else:
        print()
    return gate


def ask(messages: list[dict], *, model: str | None = None, **kwargs):
    """Make a real LLM call through the stateloom.Client API.

    Uses the auto-detected provider unless a specific model is given.
    When no model is passed, relies on default_model from config — this
    keeps auto-routing eligible (explicit model disables auto-routing).
    """
    chat_kwargs: dict = {"messages": messages, **kwargs}
    if model:
        chat_kwargs["model"] = model
    return stateloom.chat(**chat_kwargs)


def user_msg(text: str) -> list[dict]:
    """Shorthand to build a single-user-message list."""
    return [{"role": "user", "content": text}]


def header(title: str) -> None:
    """Print a visually distinct section header."""
    global DEMO_NUM
    DEMO_NUM += 1
    print(f"\n{'=' * 60}")
    print(f"  DEMO {DEMO_NUM}: {title}")
    print(f"{'=' * 60}\n")


def pause(ui_hint: str) -> None:
    """Pause execution and tell the user what to look at in the dashboard."""
    print()
    print(f"  >> UI CHECK: {ui_hint}")
    print(f"  >> Open {DASHBOARD_URL} and look now.")
    input("\n  Press Enter to continue...\n")


def api(method: str, path: str, *, token: str | None = None, **kwargs):
    """Call the dashboard REST API.

    *path* is relative to ``/api/v1`` (e.g. ``"/config"``, ``"/pii/rules"``).
    Returns a :class:`requests.Response`.
    """
    url = f"{DASHBOARD_URL}/api/v1{path}"
    headers = kwargs.pop("headers", {})
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return _requests.request(method, url, headers=headers, timeout=10, **kwargs)


def wait_for_exit() -> None:
    """Keep the dashboard alive until the user is done exploring.

    Only shuts down StateLoom if this demo started it. If the demo
    reused an existing gate, it leaves it running.
    """
    print(f"\n  Dashboard still running at {DASHBOARD_URL}")
    print("  Explore the UI, then come back here.\n")
    if _demo_owns_gate:
        input("  Press Enter to shut down...\n")
        stateloom.shutdown()
        print("  Shutdown complete.")
    else:
        input("  Press Enter to exit demo (StateLoom keeps running)...\n")
        print("  Demo exited. StateLoom is still running.")
