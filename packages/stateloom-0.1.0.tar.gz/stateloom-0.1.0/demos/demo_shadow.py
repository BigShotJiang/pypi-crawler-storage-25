#!/usr/bin/env python3
"""Demo: Shadow Drafting — monitor at http://localhost:4781

Real-world scenario: Every cloud LLM call runs candidate models in
parallel (fire-and-forget). Candidates can be local Ollama models
*or* smaller/cheaper cloud models (e.g. gpt-4o-mini vs gpt-4o).
Responses are compared for quality via similarity scoring.

Requires: At least one API key. Ollama optional (for local candidates).
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


# Primary (expensive) and secondary (cheap) cloud model pairs per provider.
# The demo uses the expensive model as primary and the cheap one as shadow
# candidate, so you can evaluate whether the cheaper model is "good enough".
_MODEL_PAIRS = {
    "openai": ("gpt-4o", "gpt-4o-mini"),
    "anthropic": ("claude-sonnet-4-20250514", "claude-haiku-4-5-20251001"),
    "google": ("gemini-2.5-pro-preview-05-06", "gemini-2.0-flash"),
}


def main():
    primary_model, secondary_model = _MODEL_PAIRS.get(PROVIDER, ("gpt-4o", "gpt-4o-mini"))

    # Enable shadow drafting: primary model handles traffic,
    # cheaper model runs in parallel for quality comparison
    gate = init_gate(
        shadow=True,
        default_model=primary_model,
        shadow_models=[secondary_model],
    )

    if not gate.config.shadow_enabled:
        print("  WARNING: Shadow drafting not enabled.")
        print("  Continuing without shadow drafting...\n")

    shadow_models = gate.config.shadow_models or [gate.config.shadow_model or "N/A"]
    print(f"  Primary model: {primary_model}")
    print(f"  Shadow candidate: {shadow_models}")
    print(f"  Shadow enabled: {gate.config.shadow_enabled}\n")

    # --- Scenario 1: Simple question ---
    header("Simple question — primary + shadow candidate in parallel")
    with stateloom.session(session_id="shadow-simpleq", name="Shadow: Simple Qn") as s:
        r = ask(user_msg("What is the capital of France? One word."))
        print(f"  Cloud response: {r.content[:80]}...")
        print(f"  Cost: ${s.total_cost:.6f}")

    time.sleep(2)  # let shadow complete
    pause(
        "Sessions tab: click 'shadow-simple'.\n"
        "  >> Look for a SHADOW_DRAFT event alongside the LLM_CALL.\n"
        f"  >> The shadow event shows: candidate model ({secondary_model}),\n"
        "  >> similarity score, response previews, and latency comparison."
    )

    # --- Scenario 2: Complex question ---
    header("Complex question — primary vs shadow comparison")
    with stateloom.session(session_id="shadow-complex", name="Shadow: Complex Q") as s:
        r = ask([
            {"role": "system", "content": "You are a software architect. Be detailed but concise."},
            {"role": "user", "content": (
                "Design a rate limiting system for an API gateway. "
                "Include: token bucket algorithm, distributed state, "
                "priority queues, and graceful degradation."
            )},
        ])
        print(f"  Cloud response: {r.content[:150]}...")
        print(f"  Cost: ${s.total_cost:.6f}")

    time.sleep(3)
    pause(
        "Sessions tab: click 'shadow-complex'.\n"
        "  >> Shadow similarity score for complex questions may differ.\n"
        "  >> This helps identify where cheaper models fall short."
    )

    # --- Scenario 3: Batch of varied prompts ---
    header("Batch comparison — 4 prompts across difficulty levels")
    prompts = [
        ("Easy", "What color is the sky?"),
        ("Medium", "Explain the difference between TCP and UDP."),
        ("Hard", "Write a Python function to find the longest palindromic substring."),
        ("Expert", "Explain the CAP theorem and its implications for distributed database design."),
    ]

    for level, prompt in prompts:
        with stateloom.session(session_id=f"shadow-{level.lower()}", name=f"Shadow: {level}") as s:
            r = ask(user_msg(prompt))
            print(f"  [{level:>6}] {r.content[:60]}... (cost: ${s.total_cost:.6f})")

    time.sleep(3)
    pause(
        "Sessions tab: see shadow-easy through shadow-expert.\n"
        "  >> Compare similarity scores across difficulty levels.\n"
        "  >> Easy questions should have high similarity (cheaper model is adequate).\n"
        "  >> Hard questions may show lower similarity (primary model is needed)."
    )

    # --- Scenario 4: API-based runtime configuration ---
    header("Runtime shadow configuration via API")

    # Read config via API (ungated — works without license)
    resp = api("GET", "/shadow/config")
    if resp.status_code == 200:
        cfg = resp.json()
        print(f"  Current config (GET /shadow/config):")
        print(f"    enabled:            {cfg.get('enabled')}")
        print(f"    model:              {cfg.get('model')}")
        print(f"    sample_rate:        {cfg.get('sample_rate')}")
        print(f"    max_context_tokens: {cfg.get('max_context_tokens')}")
        print(f"    middleware_active:   {cfg.get('middleware_active')}")
    else:
        print(f"  GET /shadow/config: {resp.status_code}")

    # Attempt runtime config change (gated — requires enterprise license)
    print()
    resp = api("POST", "/shadow/configure", json={"sample_rate": 0.5, "max_context_tokens": 4096})
    if resp.status_code == 200:
        cfg = resp.json()
        print(f"  Config updated (POST /shadow/configure):")
        print(f"    sample_rate:        {cfg.get('sample_rate')}")
        print(f"    max_context_tokens: {cfg.get('max_context_tokens')}")
    elif resp.status_code == 403:
        print(f"  POST /shadow/configure returned 403 (expected without license)")
        print(f"    {resp.json().get('detail', '')}")
    else:
        print(f"  POST /shadow/configure: {resp.status_code}")

    # Read metrics via API (ungated)
    print()
    resp = api("GET", "/shadow/metrics")
    if resp.status_code == 200:
        m = resp.json()
        print(f"  Shadow metrics (GET /shadow/metrics):")
        print(f"    total_calls:    {m.get('total_calls', 0)}")
        print(f"    success_rate:   {m.get('success_rate', 0):.0%}")
        print(f"    avg_similarity: {m.get('avg_similarity', 'N/A')}")
    else:
        print(f"  GET /shadow/metrics: {resp.status_code}")

    pause(
        "Testing tab > Configuration section.\n"
        "  >> If licensed: sample_rate and max_context_tokens updated.\n"
        "  >> If unlicensed: enterprise banner shown, config unchanged."
    )

    # --- Scenario 5: Python SDK equivalent ---
    header("Python SDK shadow status & configuration")

    status = stateloom.shadow_status()
    print(f"  stateloom.shadow_status():")
    for k, v in status.items():
        print(f"    {k}: {v}")

    print()
    try:
        result = stateloom.configure_shadow(sample_rate=0.75)
        print(f"  stateloom.configure_shadow(sample_rate=0.75) succeeded:")
        print(f"    sample_rate: {result.get('sample_rate')}")
    except Exception as e:
        print(f"  stateloom.configure_shadow() raised: {type(e).__name__}: {e}")
        print(f"    (Expected without enterprise license)")

    pause(
        "This demonstrates the Python SDK for shadow configuration.\n"
        "  >> shadow_status() is always available (ungated).\n"
        "  >> configure_shadow() requires an enterprise license."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
