#!/usr/bin/env python3
"""Demo: Zero-Trust Security Engine — Secret Vault

Demonstrates StateLoom's in-memory secret vault: store secrets safely,
scrub them from os.environ, and retrieve them when needed. Secrets never
appear in logs, events, or the dashboard.

Monitor at http://localhost:4781 → Security tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def _sync_vault_to_dashboard(name: str, value: str) -> None:
    """Also store the secret via the dashboard REST API.

    When the demo detects an external dashboard (separate process), the
    in-memory vault is per-process and invisible to the dashboard.  This
    helper mirrors the secret so it shows up in the Security tab.
    """
    try:
        import requests as _req
        _req.post(
            f"{DASHBOARD_URL}/api/security/vault/store",
            json={"name": name, "value": value},
            timeout=5,
        )
    except Exception:
        pass  # best-effort — dashboard may not be reachable


def main():
    # -----------------------------------------------------------------------
    # Scenario 1: Vault basics — store and retrieve a secret
    # -----------------------------------------------------------------------
    gate = init_gate(security_secret_vault_enabled=True)

    header("Vault basics — store and retrieve a secret")

    stateloom.vault_store("DEMO_SECRET", "s3cr3t-value-12345")
    _sync_vault_to_dashboard("DEMO_SECRET", "s3cr3t-value-12345")
    retrieved = stateloom.vault_retrieve("DEMO_SECRET")
    print(f"  Stored:    'DEMO_SECRET'")
    print(f"  Retrieved: '{retrieved}'")
    print(f"  Match: {retrieved == 's3cr3t-value-12345'}")

    # Show vault status (never leaks values)
    status = stateloom.security_status()
    vault_status = status.get("secret_vault", {})
    print(f"\n  Vault enabled:    {vault_status.get('enabled')}")
    print(f"  Keys in vault:    {vault_status.get('key_count', 0)}")
    print(f"  Key names:        {vault_status.get('keys', [])}")

    pause("Security tab → Secret Vault: see 'DEMO_SECRET' listed (value never shown)")

    # -----------------------------------------------------------------------
    # Scenario 2: Environment scrubbing — keys moved from env to vault
    # -----------------------------------------------------------------------
    stateloom.shutdown()

    header("Environment scrubbing — move keys from os.environ to vault")

    # Set a test env var
    os.environ["MY_TEST_API_KEY"] = "test-key-that-should-be-scrubbed"
    print(f"  Before init:")
    print(f"    os.environ['MY_TEST_API_KEY'] = '{os.environ.get('MY_TEST_API_KEY', '(not set)')}'")

    gate = init_gate(
        security_secret_vault_enabled=True,
        security_secret_vault_scrub_environ=True,
        security_secret_vault_keys=["MY_TEST_API_KEY"],
    )

    env_value = os.environ.get("MY_TEST_API_KEY", "(not set)")
    vault_value = stateloom.vault_retrieve("MY_TEST_API_KEY")

    print(f"\n  After init (with scrub_environ=True):")
    print(f"    os.environ['MY_TEST_API_KEY'] = '{env_value}'")
    print(f"    vault_retrieve('MY_TEST_API_KEY') = '{vault_value}'")
    print(f"\n  Key was moved from environment to vault!")
    print(f"  Third-party libraries can no longer see it via os.environ.")
    _sync_vault_to_dashboard("MY_TEST_API_KEY", "(scrubbed)")

    pause("Security tab → Secret Vault: see 'MY_TEST_API_KEY' in vault, scrubbed from env")

    # -----------------------------------------------------------------------
    # Scenario 3: Full security status overview
    # -----------------------------------------------------------------------
    header("Combined security status")

    status = stateloom.security_status()
    print(f"  Security engine status:")
    print(f"    Vault enabled:        {status.get('vault', {}).get('enabled')}")
    print(f"    Vault key count:      {status.get('vault', {}).get('key_count', 0)}")
    print(f"    Audit hooks enabled:  {status.get('audit_hooks', {}).get('enabled')}")

    # Make a normal LLM call to show the vault doesn't interfere
    print(f"\n  Making a normal LLM call to verify vault doesn't break anything...")
    with stateloom.session(session_id="security-test", name="Security Test") as s:
        r = ask(user_msg("What is 2 + 2? Answer in one word."))
        print(f"  Response: {r.content[:80]}")
        print(f"  Cost: ${s.total_cost:.6f}")
        print(f"  LLM calls work normally with vault active!")

    pause(
        "Security tab: full status overview.\n"
        "  >> Vault sub-tab shows stored keys (values hidden).\n"
        "  >> Sessions tab shows the test call succeeded normally."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
