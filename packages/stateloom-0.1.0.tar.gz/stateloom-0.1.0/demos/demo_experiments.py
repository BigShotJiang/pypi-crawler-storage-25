#!/usr/bin/env python3
"""Demo: A/B Experiments — monitor at http://localhost:4781

Real-world scenario: Testing whether a longer system prompt produces
better customer satisfaction. Two variants run in parallel, feedback
is collected, and a leaderboard shows the winner.

Also demonstrates: agent version experiments, experiment editing (DRAFT),
and the experiment_name metadata bug fix.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # =========================================================
    # Part 1: Classic prompt comparison experiment
    # =========================================================
    header("Create A/B experiment: system prompt comparison")

    # Create experiment with two variants
    exp = stateloom.create_experiment(
        name="Support Prompt Test",
        description="Testing concise vs. detailed system prompts for customer satisfaction",
        variants=[
            {
                "name": "concise",
                "weight": 50,
                "request_overrides": {
                    "system_prompt": "You are a helpful support agent. Be brief and direct.",
                },
            },
            {
                "name": "detailed",
                "weight": 50,
                "request_overrides": {
                    "system_prompt": (
                        "You are an expert customer support agent for a SaaS company. "
                        "Always greet the customer, acknowledge their issue, provide a "
                        "step-by-step solution, and ask if there's anything else you can help with."
                    ),
                },
            },
        ],
        strategy="random",
    )
    print(f"  Experiment: {exp.name} ({exp.id})")
    print(f"  Status: {exp.status}")
    print(f"  Variants: {[v.name for v in exp.variants]}")

    stateloom.start_experiment(exp.id)
    print(f"  Started! Now assigning sessions to variants.\n")

    pause("Experiments tab: see the 'Support Prompt Test' experiment with 2 variants")

    # --- Run sessions that get assigned to variants ---
    header("Run 6 customer conversations through the experiment")
    customer_questions = [
        ("cust-1", "I can't find the export button in the dashboard."),
        ("cust-2", "How do I invite team members to my workspace?"),
        ("cust-3", "My API calls are returning 429 errors."),
        ("cust-4", "Can I downgrade my plan mid-billing cycle?"),
        ("cust-5", "The search feature seems really slow today."),
        ("cust-6", "How do I set up two-factor authentication?"),
    ]

    for cust_id, question in customer_questions:
        with stateloom.session(
            session_id=f"exp-{cust_id}",
            name=f"Support: {cust_id}",
            experiment=exp.id,
        ) as s:
            r = ask([
                {"role": "user", "content": question},
            ])
            variant = s.metadata.get("variant", "unknown")
            exp_name = s.metadata.get("experiment_name", "")
            print(f"  [{variant:>8}] {cust_id}: {question[:40]}...")
            print(f"           Experiment: {exp_name}")
            print(f"           Response: {r.content[:80]}...")

    pause("Experiments tab: click the experiment — see session assignments per variant")

    # --- Submit feedback ---
    header("Submit customer satisfaction feedback")
    feedbacks = [
        ("exp-cust-1", "success", 0.9, "Quick and helpful"),
        ("exp-cust-2", "success", 0.7, "Got the answer but could be clearer"),
        ("exp-cust-3", "failure", 0.3, "Didn't solve my issue"),
        ("exp-cust-4", "success", 0.8, "Clear explanation"),
        ("exp-cust-5", "partial", 0.5, "Partially helpful"),
        ("exp-cust-6", "success", 0.95, "Excellent step-by-step guide"),
    ]

    for session_id, rating, score, comment in feedbacks:
        stateloom.feedback(session_id, rating, score=score, comment=comment)
        print(f"  {session_id}: {rating} ({score}) — {comment}")

    pause("Experiments tab: metrics updated — see per-variant success rates")

    # --- Show metrics and leaderboard ---
    header("Experiment metrics and leaderboard")
    metrics = stateloom.experiment_metrics(exp.id)
    print(f"  Per-variant metrics:")
    for variant_name, data in metrics.items():
        print(f"    {variant_name}: {data}")

    lb = stateloom.leaderboard()
    print(f"\n  Leaderboard (ranked by success rate):")
    for i, entry in enumerate(lb, 1):
        print(f"    #{i}: {entry}")

    # Conclude the experiment
    result = stateloom.conclude_experiment(exp.id)
    print(f"\n  Experiment concluded. Final result: {result}")

    pause(
        "Experiments tab: experiment is now CONCLUDED.\n"
        "  >> Leaderboard shows which prompt variant performed better.\n"
        "  >> Per-variant metrics: success rate, avg cost, feedback scores."
    )

    # =========================================================
    # Part 2: Agent version experiment
    # =========================================================
    header("Agent version experiment: compare two agent configs")

    # Create two agent versions to test (use the detected MODEL so it matches the provider)
    agent = stateloom.create_agent(
        slug="support-bot",
        team_id="default",
        model=MODEL,
        system_prompt="You are a concise support bot.",
        name="Support Bot",
    )
    print(f"  Created agent: {agent.slug} ({agent.id})")

    v2 = stateloom.create_agent_version(
        agent_id=agent.id,
        model=MODEL,
        system_prompt=(
            "You are an expert support bot. Always acknowledge the user's frustration, "
            "then provide a clear step-by-step solution."
        ),
    )
    print(f"  Created v2: {v2.id} (version {v2.version_number})")

    # Create experiment with agent_version_id on variants
    agent_exp = stateloom.create_experiment(
        name="Support Bot Prompt A/B",
        description="Compare v1 (concise) vs v2 (empathetic) of the support bot",
        variants=[
            {
                "name": "v1-concise",
                "weight": 1.0,
                "agent_version_id": agent.active_version_id,
            },
            {
                "name": "v2-empathetic",
                "weight": 1.0,
                "agent_version_id": v2.id,
            },
        ],
        agent_id=agent.id,  # informational — marks this experiment tests the support-bot agent
    )
    print(f"\n  Agent experiment: {agent_exp.name} ({agent_exp.id})")
    print(f"  Agent ID: {agent_exp.agent_id}")
    print(f"  Variants reference agent versions: "
          f"{[v.agent_version_id for v in agent_exp.variants]}")

    stateloom.start_experiment(agent_exp.id)
    print(f"  Started!")

    # Run a few sessions
    for i in range(4):
        with stateloom.session(
            session_id=f"agent-exp-{i}",
            experiment=agent_exp.id,
        ) as s:
            r = ask([{"role": "user", "content": "My dashboard is showing a 500 error."}])
            variant = s.metadata.get("variant", "unknown")
            print(f"  Session {i}: assigned to '{variant}', model={s.metadata.get('experiment_variant_config', {}).get('_resolved_agent_overrides', {}).get('model', 'N/A')}")

    stateloom.conclude_experiment(agent_exp.id)
    print(f"  Agent experiment concluded.\n")

    pause(
        "Experiments tab: see the agent version experiment.\n"
        "  >> Each variant inherits model + system prompt from its agent version.\n"
        "  >> Agent overrides are snapshotted at assignment time for immutability."
    )

    # =========================================================
    # Part 3: Editing a DRAFT experiment
    # =========================================================
    header("Edit a DRAFT experiment before starting")

    draft = stateloom.create_experiment(
        name="Draft Experiment",
        description="Will be edited before launch",
        variants=[{"name": "placeholder"}],
    )
    print(f"  Created DRAFT: {draft.name} ({draft.id})")
    print(f"  Variants: {[v.name for v in draft.variants]}")

    # Build provider-aware variant list for the draft experiment
    draft_variants = []
    if os.environ.get("ANTHROPIC_API_KEY"):
        draft_variants.append({"name": "haiku", "model": "claude-haiku-4-5-20251001", "weight": 1.0})
        draft_variants.append({"name": "sonnet", "model": "claude-sonnet-4-20250514", "weight": 1.0})
    if os.environ.get("GOOGLE_API_KEY"):
        draft_variants.append({"name": "gemini-flash", "model": "gemini-3-flash-preview", "weight": 1.0})
    if os.environ.get("OPENAI_API_KEY"):
        draft_variants.append({"name": "gpt4o-mini", "model": "gpt-4o-mini", "weight": 1.0})
    if not draft_variants:
        # Fallback: just use the detected model twice with different names
        draft_variants = [
            {"name": "variant-a", "model": MODEL, "weight": 1.0},
            {"name": "variant-b", "model": MODEL, "weight": 1.0},
        ]

    # Update it
    updated = stateloom.update_experiment(
        draft.id,
        name="Refined Experiment",
        description="Updated with real variants",
        variants=draft_variants,
        strategy="hash",
    )
    print(f"\n  Updated: {updated.name}")
    print(f"  Strategy: {updated.strategy}")
    print(f"  Variants: {[v.name for v in updated.variants]}")
    print(f"  Description: {updated.description}")

    # Start after editing
    stateloom.start_experiment(updated.id)
    print(f"  Now running with {len(draft_variants)} variants!")

    # Show that non-DRAFT cannot be edited
    try:
        stateloom.update_experiment(updated.id, name="should-fail")
    except ValueError as e:
        print(f"\n  Expected error when editing running experiment: {e}")

    stateloom.conclude_experiment(updated.id)

    pause(
        "Experiments tab: see the edited experiment.\n"
        "  >> DRAFT experiments can be freely edited before starting.\n"
        "  >> Once started, experiments are locked for integrity."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
