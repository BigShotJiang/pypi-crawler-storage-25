#!/usr/bin/env python3
"""Demo: Semantic Similarity Caching

Demonstrates embedding-based semantic caching: not just exact matches,
but similar questions get cache hits too. Reduces cost and latency for
rephrased queries that have the same intent.

Monitor at http://localhost:4781 → Sessions tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import time

try:
    from sentence_transformers import SentenceTransformer  # noqa: F401
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False


def main():
    if not HAS_SENTENCE_TRANSFORMERS:
        print("\n  This demo requires sentence-transformers:")
        print("  pip install sentence-transformers")
        print("\n  Exiting gracefully.")
        sys.exit(0)

    gate = init_gate(
        cache=True,
        cache_semantic=True,
        cache_similarity_threshold=0.80,
    )

    # -----------------------------------------------------------------------
    # Scenario 1: Exact cache hit — same question twice
    # -----------------------------------------------------------------------
    header("Exact cache hit — identical question")

    with stateloom.session(session_id="sem-cache-exact", name="Exact Cache") as s:
        question = "What is the capital of France?"

        print(f"  Q1: {question}")
        start = time.time()
        r1 = ask(user_msg(question))
        t1 = time.time() - start
        print(f"  A1: {r1.content[:100]}")
        print(f"  Time: {t1:.2f}s | Cost: ${s.total_cost:.6f}\n")

        cost_after_first = s.total_cost

        print(f"  Q2: {question} (identical)")
        start = time.time()
        r2 = ask(user_msg(question))
        t2 = time.time() - start
        print(f"  A2: {r2.content[:100]}")
        print(f"  Time: {t2:.4f}s | Cost: ${s.total_cost:.6f}")

        savings = cost_after_first - (s.total_cost - cost_after_first)
        print(f"\n  Second call cost: ${s.total_cost - cost_after_first:.6f} (should be $0 — cached)")
        print(f"  Speedup: {t1 / max(t2, 0.001):.0f}x faster")

    pause("Sessions tab: 'sem-cache-exact' — see CACHE_HIT event for the second call")

    # -----------------------------------------------------------------------
    # Scenario 2: Semantic cache hit — rephrased question
    # -----------------------------------------------------------------------
    header("Semantic cache hit — rephrased but same intent")

    with stateloom.session(session_id="sem-cache-semantic", name="Semantic Cache") as s:
        q1 = "Explain how photosynthesis works in simple terms"
        q2 = "How does photosynthesis work? Keep it simple"
        q3 = "Can you describe the process of photosynthesis simply?"

        print(f"  Q1: {q1}")
        r1 = ask(user_msg(q1))
        cost_live = s.total_cost
        print(f"  A1: {r1.content[:100]}...")
        print(f"  Cost: ${cost_live:.6f} (live call)\n")

        print(f"  Q2: {q2} (rephrased)")
        r2 = ask(user_msg(q2))
        cost_after_q2 = s.total_cost - cost_live
        print(f"  A2: {r2.content[:100]}...")
        print(f"  Cost: ${cost_after_q2:.6f} (should be $0 — semantic match)\n")

        print(f"  Q3: {q3} (rephrased again)")
        r3 = ask(user_msg(q3))
        cost_after_q3 = s.total_cost - cost_live - cost_after_q2
        print(f"  A3: {r3.content[:100]}...")
        print(f"  Cost: ${cost_after_q3:.6f} (should be $0 — semantic match)")

    pause(
        "Sessions tab: 'sem-cache-semantic' — see CACHE_HIT events for Q2 and Q3.\n"
        "  >> The semantic similarity matched rephrased questions to Q1's cached response."
    )

    # -----------------------------------------------------------------------
    # Scenario 3: Semantic miss — completely different question
    # -----------------------------------------------------------------------
    header("Semantic miss — different topic, no cache hit")

    with stateloom.session(session_id="sem-cache-miss", name="Semantic Miss") as s:
        q1 = "What is the speed of light in a vacuum?"
        q2 = "How do you make chocolate chip cookies?"

        print(f"  Q1: {q1}")
        r1 = ask(user_msg(q1))
        cost1 = s.total_cost
        print(f"  A1: {r1.content[:100]}...")
        print(f"  Cost: ${cost1:.6f}\n")

        print(f"  Q2: {q2} (completely different topic)")
        r2 = ask(user_msg(q2))
        cost2 = s.total_cost - cost1
        print(f"  A2: {r2.content[:100]}...")
        print(f"  Cost: ${cost2:.6f} (should be > $0 — no semantic match)")

        print(f"\n  Both calls were live — topics are too different for semantic match")

    pause("Sessions tab: 'sem-cache-miss' — two live LLM calls, no cache hits")

    # -----------------------------------------------------------------------
    # Scenario 4: Cost savings summary
    # -----------------------------------------------------------------------
    header("Cost savings summary")

    print("  Semantic caching benefits:")
    print("  - Exact matches:    100% cache hit rate (identical questions)")
    print("  - Rephrased queries: high cache hit rate (same intent, different words)")
    print("  - Different topics:  0% cache hit (correctly not cached)")
    print()
    print("  Configuration used:")
    print(f"    cache_semantic=True")
    print(f"    cache_similarity_threshold=0.80 (80% similarity required)")
    print()
    print("  Use cases:")
    print("  - Customer support: same question asked differently → instant response")
    print("  - Search queries: paraphrased searches hit the cache")
    print("  - API gateways: reduce duplicate LLM calls across users")

    wait_for_exit()


if __name__ == "__main__":
    main()
