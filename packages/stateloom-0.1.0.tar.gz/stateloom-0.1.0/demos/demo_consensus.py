#!/usr/bin/env python3
"""Demo: Multi-Agent Consensus — monitor at http://localhost:4781

Real-world scenario: Multiple LLMs debate a complex question across rounds.
The consensus framework aggregates their answers, extracts confidence scores,
and synthesizes a final answer — reducing hallucinations and improving reasoning.

Uses cross-provider consensus (Gemini + Claude) to showcase true multi-model
debate. Falls back to single-provider if only one API key is available.

Demonstrates three strategies:
  1. Vote — Gemini vs Claude answer independently in parallel (cheapest)
  2. Debate — multi-round cross-provider discussion with judge synthesis
  3. Self-consistency — multiple samples from one model
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

GEMINI_MODEL = "gemini-2.5-flash"
CLAUDE_MODEL = "claude-haiku-4-5-20251001"


def _detect_consensus_models() -> list[str]:
    """Pick one Gemini and one Claude model for cross-provider consensus.

    Falls back to duplicating the single available model if only one
    provider key is set.
    """
    has_gemini = bool(os.environ.get("GOOGLE_API_KEY"))
    has_claude = bool(os.environ.get("ANTHROPIC_API_KEY"))

    if has_gemini and has_claude:
        return [GEMINI_MODEL, CLAUDE_MODEL]

    # Fall back to single provider
    if has_gemini:
        print("  (Only GOOGLE_API_KEY found — using two Gemini instances)")
        return [GEMINI_MODEL, GEMINI_MODEL]
    if has_claude:
        print("  (Only ANTHROPIC_API_KEY found — using two Claude instances)")
        return [CLAUDE_MODEL, CLAUDE_MODEL]

    # Neither Gemini nor Claude — use whatever detect_provider() found
    print(f"  (Using single provider: {MODEL} x2)")
    return [MODEL, MODEL]


def main():
    gate = init_gate()

    consensus_models = _detect_consensus_models()
    print(f"  Consensus models: {consensus_models}\n")

    # ── Strategy 1: Vote ─────────────────────────────────────────────
    header("Vote strategy — Gemini vs Claude answer independently")

    result = stateloom.consensus_sync(
        prompt="What are the three most important principles of good API design?",
        models=consensus_models,
        strategy="vote",
        aggregation="confidence_weighted",
    )

    print(f"  Strategy:    {result.strategy}")
    print(f"  Models:      {result.models}")
    print(f"  Rounds:      {result.total_rounds}")
    print(f"  Confidence:  {result.confidence:.1%}")
    print(f"  Cost:        ${result.cost:.6f}")
    print(f"  Duration:    {result.duration_ms:.0f}ms")
    print(f"  Winner:      {result.winner_model}")
    print(f"  Answer:      {result.answer[:200]}...")

    pause(
        "Consensus tab: see the vote run with 1 round.\n"
        "  >> Click the row to see per-model responses and confidence scores.\n"
        "  >> Notice how Gemini and Claude give different perspectives."
    )

    # ── Strategy 2: Debate ───────────────────────────────────────────
    header("Debate strategy — cross-provider multi-round discussion")

    result = stateloom.consensus_sync(
        prompt=(
            "Should companies adopt AI-powered code review tools? "
            "Consider quality, developer experience, security, and cost implications."
        ),
        models=consensus_models,
        strategy="debate",
        rounds=2,
        budget=0.50,
        early_stop_enabled=True,
        early_stop_threshold=0.9,
    )

    print(f"  Strategy:      {result.strategy}")
    print(f"  Total rounds:  {result.total_rounds}")
    print(f"  Early stopped: {result.early_stopped}")
    print(f"  Confidence:    {result.confidence:.1%}")
    print(f"  Cost:          ${result.cost:.6f}")
    print(f"  Duration:      {result.duration_ms:.0f}ms")
    print(f"  Aggregation:   {result.aggregation_method}")
    print(f"  Winner:        {result.winner_model}")
    print()

    for rnd in result.rounds:
        print(f"  Round {rnd.round_number}:")
        print(f"    Agreement:  {rnd.agreement_score:.1%}")
        print(f"    Consensus:  {rnd.consensus_reached}")
        print(f"    Cost:       ${rnd.cost:.6f}")
        for resp in rnd.responses:
            print(f"    [{resp.model}] confidence={resp.confidence:.1%}: {resp.content[:80]}...")
    print()
    print(f"  Final answer: {result.answer[:200]}...")

    pause(
        "Consensus tab: see the debate run with round-by-round breakdown.\n"
        "  >> Click the row — see Gemini and Claude debating each other.\n"
        "  >> Child sessions show each debater's individual cost."
    )

    # ── Strategy 3: Self-Consistency ─────────────────────────────────
    header("Self-consistency — multiple samples from one model")

    result = stateloom.consensus_sync(
        prompt="What is the derivative of f(x) = 3x^2 + 2x - 5?",
        models=[consensus_models[0]],  # Use first model for self-consistency
        strategy="self_consistency",
        samples=3,
        temperature=0.7,
    )

    print(f"  Strategy:    {result.strategy}")
    print(f"  Model:       {result.models}")
    print(f"  Samples:     {len(result.rounds[0].responses)}")
    print(f"  Confidence:  {result.confidence:.1%}")
    print(f"  Cost:        ${result.cost:.6f}")
    print(f"  Aggregation: {result.aggregation_method}")
    print(f"  Answer:      {result.answer[:200]}...")

    pause(
        "Consensus tab: see the self-consistency run.\n"
        "  >> 3 samples from the same model, aggregated by majority vote.\n"
        "  >> Compare costs: vote < self_consistency < debate."
    )

    # ── Strategy 4: Agent-Guided Consensus ──────────────────────────
    header("Agent-guided consensus — domain expert persona for all debaters")

    # Create a managed agent to guide the consensus
    agent = stateloom.create_agent(
        slug="medical-advisor",
        team_id="team-1",
        model=consensus_models[0],
        system_prompt=(
            "You are a medical AI advisor with expertise in radiology and "
            "clinical decision support. Always cite evidence levels and consider "
            "patient safety, false positive/negative rates, and regulatory "
            "requirements when answering."
        ),
    )
    print(f"  Created agent: {agent.slug} (model: {consensus_models[0]})")
    print()

    result = stateloom.consensus_sync(
        agent="medical-advisor",
        prompt="Should hospitals use AI for initial radiology screening of chest X-rays?",
        models=consensus_models,
        strategy="vote",
        aggregation="confidence_weighted",
    )

    print(f"  Strategy:    {result.strategy}")
    print(f"  Models:      {result.models}")
    print(f"  Confidence:  {result.confidence:.1%}")
    print(f"  Cost:        ${result.cost:.6f}")
    print(f"  Answer:      {result.answer[:200]}...")

    pause(
        "Consensus tab: see the agent-guided vote run.\n"
        "  >> The parent session shows agent_slug='medical-advisor'.\n"
        "  >> Both debaters used the medical advisor's system prompt."
    )

    # ── Summary ──────────────────────────────────────────────────────
    header("Summary — all consensus runs in dashboard")
    print("  Four strategies demonstrated:")
    print("    1. Vote:             Gemini vs Claude parallel poll, lowest cost")
    print("    2. Debate:           Cross-provider multi-round, highest accuracy")
    print("    3. Self-consistency: Multiple samples, good cost/accuracy tradeoff")
    print("    4. Agent-guided:     Domain expert persona for all debaters")
    print()
    print("  Key features:")
    print("    - Cross-provider consensus (Gemini + Claude debating)")
    print("    - Budget-constrained (set budget= to cap total spend)")
    print("    - Early stopping (stop when models agree)")
    print("    - Greedy mode (auto-downgrade to cheaper models)")
    print("    - Agent-guided (managed agent system prompt for debaters)")
    print("    - Durable sessions (crash-proof, $0 resume)")
    print("    - Full middleware pipeline on every debater call")

    wait_for_exit()


if __name__ == "__main__":
    main()
