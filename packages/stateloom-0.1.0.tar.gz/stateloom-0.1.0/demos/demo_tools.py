#!/usr/bin/env python3
"""Demo: Tool Call Tracking — monitor at http://localhost:4781

Real-world scenario: An AI agent with tools (web search, database lookup,
ticket creation). StateLoom tracks every tool invocation for debugging.
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # --- Define tools ---
    @stateloom.tool(name="search_knowledge_base")
    def search_kb(query: str) -> dict:
        """Simulate searching an internal knowledge base."""
        time.sleep(0.1)  # simulate latency
        return {
            "results": [
                {"title": "Password Reset Guide", "relevance": 0.95},
                {"title": "Account Recovery Process", "relevance": 0.82},
            ],
            "query": query,
        }

    @stateloom.tool(name="lookup_customer", mutates_state=False)
    def lookup_customer(customer_id: str) -> dict:
        """Simulate looking up a customer record."""
        time.sleep(0.05)
        return {
            "id": customer_id,
            "name": "Jane Doe",
            "plan": "Enterprise",
            "status": "active",
            "since": "2023-01-15",
        }

    @stateloom.tool(name="create_ticket", mutates_state=True)
    def create_ticket(title: str, priority: str = "medium") -> dict:
        """Simulate creating a support ticket."""
        time.sleep(0.1)
        return {
            "ticket_id": "TK-2024-1234",
            "title": title,
            "priority": priority,
            "status": "open",
            "created": True,
        }

    # --- Scenario: Agent workflow with tool calls ---
    header("Support agent workflow with tool calls")

    with stateloom.session(session_id="tools-demo", name="Agent with Tools") as s:
        # Step 1: Understand the issue
        r1 = ask([
            {"role": "system", "content": "You are a support agent. Be concise."},
            {"role": "user", "content": "Customer cust-42 says they can't reset their password."},
        ])
        print(f"  [LLM] Understanding: {r1.content[:80]}...")

        # Step 2: Look up customer
        customer = lookup_customer("cust-42")
        print(f"  [Tool] lookup_customer → {customer['name']} ({customer['plan']})")

        # Step 3: Search knowledge base
        kb_results = search_kb("password reset enterprise account")
        print(f"  [Tool] search_kb → {len(kb_results['results'])} results")

        # Step 4: Generate response using context
        r2 = ask([
            {"role": "system", "content": "You are a support agent. Be concise and helpful."},
            {"role": "user", "content": (
                f"Customer: {customer['name']} (Enterprise, ID: {customer['id']})\n"
                f"Issue: Can't reset password\n"
                f"KB results: {kb_results['results']}\n"
                f"Generate a helpful response for this customer."
            )},
        ])
        print(f"  [LLM] Response: {r2.content[:120]}...")

        # Step 5: Create escalation ticket
        ticket = create_ticket(
            title="Password reset failure - Enterprise customer cust-42",
            priority="high",
        )
        print(f"  [Tool] create_ticket → {ticket['ticket_id']} ({ticket['priority']})")

        print(f"\n  Session summary:")
        print(f"    LLM calls: {s.call_count}")
        print(f"    Cost: ${s.total_cost:.6f}")
        print(f"    Steps: {s.step_counter}")

    pause(
        "Sessions tab: click 'tools-demo' — see the full agent workflow.\n"
        "  >> Timeline: LLM_CALL events interleaved with TOOL_CALL events.\n"
        "  >> Tool events show: tool name, latency, mutates_state flag.\n"
        "  >> The create_ticket tool is marked as mutates_state=True."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
