#!/usr/bin/env python3
"""Demo: VCR-Cassette Mock — Zero-Cost Testing

Demonstrates record-and-replay for LLM calls. First run makes real API
calls and records responses. Subsequent runs replay from cache instantly
at $0 cost — perfect for CI/CD and deterministic testing.

Monitor at http://localhost:4781 → Sessions tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import time


def main():
    # Mock needs SQLite to persist cassettes across invocations
    gate = init_gate(store_backend="sqlite")

    cassette_id = "demo-cassette"

    # -----------------------------------------------------------------------
    # Scenario 1: Record run — real API calls
    # -----------------------------------------------------------------------
    header("Record run — real API calls, responses cached")

    start = time.time()
    with stateloom.mock(cassette_id, force_record=True) as m:
        print(f"  Is replay: {m.is_replay}")
        r = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": "Explain what a VCR cassette is in one sentence."},
        ])
    elapsed_record = time.time() - start

    print(f"  Response:  {r.content[:120]}...")
    print(f"  Duration:  {elapsed_record:.2f}s (real API call)")

    pause("Sessions tab: see the mock session with a real LLM call recorded")

    # -----------------------------------------------------------------------
    # Scenario 2: Replay run — instant, zero cost
    # -----------------------------------------------------------------------
    header("Replay run — cached response, instant, $0 cost")

    start = time.time()
    with stateloom.mock(cassette_id) as m:
        print(f"  Is replay: {m.is_replay}")
        r2 = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": "Explain what a VCR cassette is in one sentence."},
        ])
    elapsed_replay = time.time() - start

    print(f"  Response:  {r2.content[:120]}...")
    print(f"  Duration:  {elapsed_replay:.4f}s (cached — should be near-instant)")

    speedup = elapsed_record / max(elapsed_replay, 0.001)
    print(f"\n  Speedup:   {speedup:.0f}x faster than live call")
    print(f"  Same response: {r.content[:50] == r2.content[:50]}")

    pause("Sessions tab: replay session shows cached response — no real API call")

    # -----------------------------------------------------------------------
    # Scenario 3: Force re-record — overwrites existing cassette
    # -----------------------------------------------------------------------
    header("Force re-record — overwrites the existing cassette")

    with stateloom.mock(cassette_id, force_record=True) as m:
        print(f"  Is replay: {m.is_replay} (False — force_record=True)")
        r3 = ask([
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": "Explain what a VCR cassette is in one sentence."},
        ])
        print(f"  Response:  {r3.content[:120]}...")
        print(f"  Cassette overwritten with fresh response")

    pause("Sessions tab: see the re-recorded session")

    print("\n  Mock testing summary:")
    print("  - Record once → replay forever for free")
    print("  - Deterministic: same response every time")
    print("  - Use in CI/CD: no API keys needed after recording")
    print("  - force_record=True to refresh stale cassettes")

    wait_for_exit()


if __name__ == "__main__":
    main()
