#!/usr/bin/env python3
"""Demo: Durable Streaming — monitor at http://localhost:4781

Real-world scenario: Stream LLM responses in real time (token by token)
while recording every chunk for durable replay. On resume after a crash,
the same streaming code runs but chunks replay from cache instantly —
zero API cost, same developer experience.

This builds on demo_durable.py: instead of forcing non-streaming mode,
durable sessions now support streaming natively.

Uses the SDK client directly (auto-patched by StateLoom) since streaming
is intercepted at the provider SDK level, not through stateloom.chat().
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def _create_client():
    """Create the appropriate SDK client based on the detected provider."""
    if PROVIDER == "openai":
        from openai import OpenAI
        return OpenAI(), "openai"
    elif PROVIDER == "anthropic":
        from anthropic import Anthropic
        return Anthropic(), "anthropic"
    elif PROVIDER == "google":
        import google.generativeai as genai
        return genai, "gemini"
    else:
        raise RuntimeError(f"Unsupported provider: {PROVIDER}")


def _stream_openai(client, messages: list[dict]) -> tuple[str, int]:
    """Stream via OpenAI SDK and print tokens as they arrive."""
    stream = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        stream=True,
    )
    full_text = ""
    chunk_count = 0
    for chunk in stream:
        chunk_count += 1
        delta = ""
        if chunk.choices:
            delta = chunk.choices[0].delta.content or ""
        if delta:
            print(delta, end="", flush=True)
            full_text += delta
    print()
    return full_text, chunk_count


def _stream_anthropic(client, messages: list[dict]) -> tuple[str, int]:
    """Stream via Anthropic SDK and print tokens as they arrive."""
    # Separate system from user messages (Anthropic API requires this)
    system_text = ""
    user_messages = []
    for msg in messages:
        if msg["role"] == "system":
            system_text = msg["content"]
        else:
            user_messages.append(msg)

    kwargs = {
        "model": MODEL,
        "messages": user_messages,
        "max_tokens": 256,
        "stream": True,
    }
    if system_text:
        kwargs["system"] = system_text

    stream = client.messages.create(**kwargs)
    full_text = ""
    chunk_count = 0
    for event in stream:
        chunk_count += 1
        delta = ""
        if hasattr(event, "type"):
            if event.type == "content_block_delta":
                delta = getattr(event.delta, "text", "") or ""
        if delta:
            print(delta, end="", flush=True)
            full_text += delta
    print()
    return full_text, chunk_count


def main():
    # Durable mode needs SQLite to persist cached responses across "restarts"
    gate = init_gate(store_backend="sqlite")

    client, provider_type = _create_client()

    # Pick the right streaming function
    if provider_type == "openai":
        stream_ask = lambda msgs: _stream_openai(client, msgs)
    elif provider_type == "anthropic":
        stream_ask = lambda msgs: _stream_anthropic(client, msgs)
    else:
        print("  Streaming demo requires OpenAI or Anthropic provider.")
        return

    session_id = "durable-streaming-demo"

    # --- First run: stream 2 responses, recording chunks ---
    header("First run — stream responses (chunks recorded for replay)")

    with stateloom.session(
        session_id=session_id,
        name="Durable Streaming Report",
        durable=True,
    ) as s:
        stateloom.checkpoint("run_1_start", "First execution — streaming")

        print("  Step 1 (LIVE STREAM):")
        print("  ", end="")
        text1, chunks1 = stream_ask([
            {"role": "system", "content": "You are a concise analyst. Reply in 2-3 sentences."},
            {"role": "user", "content": "What is the biggest trend in AI infrastructure in 2025?"},
        ])
        print(f"    [{chunks1} chunks streamed, cost: ${s.total_cost:.6f}]")

        print("\n  Step 2 (LIVE STREAM):")
        print("  ", end="")
        text2, chunks2 = stream_ask([
            {"role": "system", "content": "You are a concise analyst. Reply in 2-3 sentences."},
            {"role": "user", "content": "What are the key risks of over-reliance on LLM APIs?"},
        ])
        cost_after_first_run = s.total_cost
        print(f"    [{chunks2} chunks streamed, total cost: ${cost_after_first_run:.6f}]")

        print(f"\n  First run complete: {s.step_counter} steps, ${cost_after_first_run:.6f}")
        print("  [Simulating crash — session ends here]")

    pause(
        "Sessions tab: click the durable-streaming-demo session.\n"
        "  >> Both LLM call events have cached_response_json with stream chunks.\n"
        "  >> The is_streaming flag is True for both events."
    )

    # --- Second run: resume — steps 1-2 replay from cached chunks ---
    header("Second run — resume (cached stream chunks replayed instantly)")

    with stateloom.session(
        session_id=session_id,
        name="Durable Streaming Report",
        durable=True,
    ) as s:
        stateloom.checkpoint("run_2_start", "Resumed execution — replaying streams")

        print("  Step 1 (CACHED STREAM REPLAY):")
        print("  ", end="")
        text1_replay, chunks1_replay = stream_ask([
            {"role": "system", "content": "You are a concise analyst. Reply in 2-3 sentences."},
            {"role": "user", "content": "What is the biggest trend in AI infrastructure in 2025?"},
        ])
        print(f"    [{chunks1_replay} chunks replayed — same content, zero API cost]")

        print("\n  Step 2 (CACHED STREAM REPLAY):")
        print("  ", end="")
        text2_replay, chunks2_replay = stream_ask([
            {"role": "system", "content": "You are a concise analyst. Reply in 2-3 sentences."},
            {"role": "user", "content": "What are the key risks of over-reliance on LLM APIs?"},
        ])
        print(f"    [{chunks2_replay} chunks replayed — same content, zero API cost]")

        # Step 3: new live streaming call
        print("\n  Step 3 (LIVE STREAM — new call):")
        print("  ", end="")
        text3, chunks3 = stream_ask([
            {"role": "system", "content": "You are a concise analyst. Reply in 2-3 sentences."},
            {"role": "user", "content": (
                "Synthesize a recommendation based on these findings:\n"
                f"Trend: {text1_replay[:200]}\n"
                f"Risk: {text2_replay[:200]}"
            )},
        ])
        print(f"    [{chunks3} chunks streamed — new live call]")

        resume_cost = s.total_cost
        print(f"\n  Resume total cost: ${resume_cost:.6f}")
        print(f"  Saved by caching: ${cost_after_first_run:.6f} (steps 1-2 were free)")

        # Verify correctness
        if text1_replay.strip() and text2_replay.strip():
            print("\n  PASS: Cached streams produced non-empty content!")
        if chunks1_replay == chunks1:
            print(f"  PASS: Step 1 chunk count matches ({chunks1} chunks)")
        if chunks2_replay == chunks2:
            print(f"  PASS: Step 2 chunk count matches ({chunks2} chunks)")

    pause(
        "Sessions tab: click the durable-streaming-demo session.\n"
        "  >> Run 2 events show steps 1-2 replayed from cache (zero cost).\n"
        "  >> Step 3 is a new live streaming call.\n"
        "  >> Checkpoints mark run_1 and run_2 boundaries."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
