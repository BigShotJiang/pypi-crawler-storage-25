#!/usr/bin/env python3
"""Demo: Parent-Child Sessions — monitor at http://localhost:4781

Real-world scenario: An orchestrator agent that spawns sub-agents for
specialized tasks. Each sub-task runs in a child session with its own
budget and tracking, linked to the parent for traceability.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    header("Orchestrator spawns child sessions for a research task")

    # --- Parent: orchestrator session ---
    with stateloom.session(
        session_id="research-orchestrator",
        name="Research Orchestrator",
        budget=1.00,
    ) as parent:
        parent.metadata["task"] = "market-analysis"
        parent.metadata["requester"] = "vp-strategy"

        r = ask([
            {"role": "system", "content": "You are a research coordinator. Plan the research steps briefly."},
            {"role": "user", "content": (
                "I need a market analysis for AI-powered customer service tools. "
                "Break this into 3 research sub-tasks."
            )},
        ])
        print(f"  Orchestrator plan: {r.content[:150]}...")
        print(f"  Parent cost: ${parent.total_cost:.6f}")

        stateloom.checkpoint("plan_complete", "Research plan generated")
        print("  [Checkpoint: plan_complete]")

        # --- Child 1: Market size research ---
        # Parent is auto-derived from the enclosing session context
        with stateloom.session(
            session_id="research-market-size",
            name="Sub: Market Size",
            budget=0.30,
        ) as child1:
            r1 = ask([
                {"role": "system", "content": "You are a market analyst. Be concise with data."},
                {"role": "user", "content": "What is the current market size for AI customer service tools?"},
            ])
            print(f"\n  Child 1 (Market Size): {r1.content[:120]}...")
            print(f"    Cost: ${child1.total_cost:.6f}")

        # --- Child 2: Competitor analysis ---
        with stateloom.session(
            session_id="research-competitors",
            name="Sub: Competitor Analysis",
            budget=0.30,
        ) as child2:
            r2 = ask([
                {"role": "system", "content": "You are a competitive intelligence analyst. Be concise."},
                {"role": "user", "content": "Name the top 5 AI customer service platforms and their key differentiators."},
            ])
            print(f"\n  Child 2 (Competitors): {r2.content[:120]}...")
            print(f"    Cost: ${child2.total_cost:.6f}")

        # --- Child 3: Trend analysis ---
        with stateloom.session(
            session_id="research-trends",
            name="Sub: Trend Analysis",
            budget=0.30,
        ) as child3:
            r3 = ask([
                {"role": "system", "content": "You are a technology trend analyst. Be concise."},
                {"role": "user", "content": "What are the top 3 emerging trends in AI customer service for 2025-2026?"},
            ])
            print(f"\n  Child 3 (Trends): {r3.content[:120]}...")
            print(f"    Cost: ${child3.total_cost:.6f}")

        stateloom.checkpoint("research_complete", "All sub-tasks finished")

        # --- Parent synthesizes results ---
        r_final = ask([
            {"role": "system", "content": "You are a research coordinator. Synthesize findings concisely."},
            {"role": "user", "content": (
                f"Synthesize these research findings into a brief executive summary:\n"
                f"1. Market Size: {r1.content[:200]}\n"
                f"2. Competitors: {r2.content[:200]}\n"
                f"3. Trends: {r3.content[:200]}"
            )},
        ])
        print(f"\n  Executive Summary: {r_final.content[:200]}...")
        print(f"\n  Parent total cost: ${parent.total_cost:.6f}")

    pause(
        "Sessions tab: click 'research-orchestrator' to see parent session.\n"
        "  >> Click into the session detail — see child sessions linked below.\n"
        "  >> Each child has its own cost tracking and budget.\n"
        "  >> Checkpoints appear as dividers in the waterfall timeline."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
