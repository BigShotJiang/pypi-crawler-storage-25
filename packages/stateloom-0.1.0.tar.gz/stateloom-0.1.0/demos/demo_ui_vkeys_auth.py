#!/usr/bin/env python3
"""Demo: Virtual Keys, Auth, Users, and OIDC via Dashboard API

Full lifecycle: bootstrap admin → login → create virtual keys → use via proxy →
revoke → create/manage users → OIDC provider CRUD → device flow → logout.

Endpoints exercised:
  POST   /api/v1/auth/bootstrap
  POST   /api/v1/auth/login
  POST   /api/v1/auth/refresh
  POST   /api/v1/auth/logout
  GET    /api/v1/auth/me
  POST   /api/v1/auth/change-password
  GET    /api/v1/auth/oidc/providers
  POST   /api/v1/auth/device/authorize
  POST   /api/v1/auth/device/token
  POST   /api/v1/virtual-keys
  GET    /api/v1/virtual-keys
  DELETE /api/v1/virtual-keys/{id}
  PUT    /api/v1/virtual-keys/{id}/rate-limit
  GET    /api/v1/virtual-keys/{id}/rate-limit
  DELETE /api/v1/virtual-keys/{id}/rate-limit
  POST   /api/v1/users
  GET    /api/v1/users
  GET    /api/v1/users/{id}
  PATCH  /api/v1/users/{id}
  DELETE /api/v1/users/{id}
  POST   /api/v1/users/{id}/team-roles
  DELETE /api/v1/users/{id}/team-roles/{team_id}
  POST   /api/v1/oidc/providers
  GET    /api/v1/oidc/providers
  PATCH  /api/v1/oidc/providers/{id}
  DELETE /api/v1/oidc/providers/{id}
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    import httpx
except ImportError:
    print("\n  This demo requires httpx: pip install httpx")
    sys.exit(1)


ADMIN_EMAIL = "admin@vkey-demo.example.com"
ADMIN_PASSWORD = "AdminP@ss!2024"


def main():
    gate = init_gate(auth_enabled=True, proxy=True, proxy_require_virtual_key=True)

    admin_token = None
    refresh_token = None

    # -----------------------------------------------------------------------
    # 1. Bootstrap admin
    # -----------------------------------------------------------------------
    header("POST /auth/bootstrap — create first admin user")
    resp = api("POST", "/auth/bootstrap", json={
        "email": ADMIN_EMAIL,
        "password": ADMIN_PASSWORD,
    })
    if resp.status_code == 200:
        data = resp.json()
        admin_token = data.get("access_token")
        print(f"  Admin created: {data.get('user', {}).get('email')}")
    elif resp.status_code == 409:
        print(f"  Admin already exists — logging in instead")
    else:
        print(f"  Bootstrap: {resp.status_code} {resp.text[:150]}")

    # -----------------------------------------------------------------------
    # 2. Login
    # -----------------------------------------------------------------------
    header("POST /auth/login → JWT tokens")
    resp = api("POST", "/auth/login", json={
        "email": ADMIN_EMAIL,
        "password": ADMIN_PASSWORD,
    })
    if resp.status_code == 200:
        data = resp.json()
        admin_token = data["access_token"]
        refresh_token = data.get("refresh_token", "")
        print(f"  ✓ Login successful")
        print(f"  Access token:  {admin_token[:40]}...")
        print(f"  Refresh token: {refresh_token[:40]}...")
    else:
        print(f"  Login failed: {resp.status_code}")
        print(f"  (Continuing demo without auth token)")

    # -----------------------------------------------------------------------
    # 3. GET /auth/me
    # -----------------------------------------------------------------------
    header("GET /auth/me — verify identity")
    if admin_token:
        resp = api("GET", "/auth/me", token=admin_token)
        if resp.status_code == 200:
            me = resp.json()
            print(f"  Email:    {me.get('email')}")
            print(f"  Org role: {me.get('org_role')}")
            print(f"  User ID:  {me.get('id', me.get('user_id', 'N/A'))}")
    else:
        print(f"  (Skipped — no admin token)")

    pause("Users tab: see the bootstrapped admin user")

    # -----------------------------------------------------------------------
    # 4. Create org + team for VK context
    # -----------------------------------------------------------------------
    header("Create org + team (for virtual key scoping)")
    org = stateloom.create_organization(name="VKey Demo Corp", budget=100.0)
    team = stateloom.create_team(org.id, name="API Team")
    print(f"  Org:  {org.name} ({org.id[:20]}...)")
    print(f"  Team: {team.name} ({team.id[:20]}...)")

    # -----------------------------------------------------------------------
    # 5. Create virtual key via API
    # -----------------------------------------------------------------------
    header("POST /virtual-keys — create API key")
    resp = api("POST", "/virtual-keys", token=admin_token, json={
        "team_id": team.id,
        "name": "demo-api-key",
        "scopes": ["chat"],
        "metadata": {"purpose": "demo"},
    })
    print(f"  POST status: {resp.status_code}")
    vk = resp.json()
    vk_id = vk.get("id", "")
    vk_key = vk.get("key", "")
    print(f"  VK ID:      {vk_id}")
    print(f"  Key:        {vk.get('key_preview', vk_key[:15] + '...')}")

    # -----------------------------------------------------------------------
    # 6. List virtual keys
    # -----------------------------------------------------------------------
    header("GET /virtual-keys — list all keys")
    resp = api("GET", "/virtual-keys", token=admin_token)
    keys = resp.json()
    keys_list = keys if isinstance(keys, list) else keys.get("keys", [])
    print(f"  Total keys: {len(keys_list)}")
    for k in keys_list:
        status = "REVOKED" if k.get("revoked") else "ACTIVE"
        print(f"    {k.get('name', 'unnamed'):>20}: {k.get('key_preview', '***')}  [{status}]")

    # -----------------------------------------------------------------------
    # 7. Use VK for a proxy call
    # -----------------------------------------------------------------------
    header("Proxy call using virtual key")
    proxy_resp = httpx.post(
        f"{DASHBOARD_URL}/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {vk_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": "Say hello. One word."}],
        },
        timeout=30.0,
    )
    print(f"  Proxy status: {proxy_resp.status_code}")
    if proxy_resp.status_code == 200:
        content = proxy_resp.json()["choices"][0]["message"]["content"]
        print(f"  Response: {content[:60]}")
        print(f"  ✓ VK-authenticated proxy call succeeded")
    else:
        print(f"  Error: {proxy_resp.text[:150]}")

    pause("Sessions tab: see the proxy session created by the virtual key call")

    # -----------------------------------------------------------------------
    # 8. Set VK rate limit
    # -----------------------------------------------------------------------
    header("PUT /virtual-keys/{id}/rate-limit — set TPS=1")
    resp = api("PUT", f"/virtual-keys/{vk_id}/rate-limit", token=admin_token, json={
        "rate_limit_tps": 1.0,
        "rate_limit_max_queue": 5,
        "rate_limit_queue_timeout": 10.0,
    })
    print(f"  PUT status: {resp.status_code}")

    resp = api("GET", f"/virtual-keys/{vk_id}/rate-limit", token=admin_token)
    rl = resp.json()
    print(f"  Rate limit: TPS={rl.get('rate_limit_tps')}  "
          f"max_queue={rl.get('rate_limit_max_queue')}")

    # Remove VK rate limit
    resp = api("DELETE", f"/virtual-keys/{vk_id}/rate-limit", token=admin_token)
    print(f"  DELETE rate limit: {resp.status_code}")

    # -----------------------------------------------------------------------
    # 9. Revoke virtual key
    # -----------------------------------------------------------------------
    header("DELETE /virtual-keys/{id} — revoke key")
    resp = api("DELETE", f"/virtual-keys/{vk_id}", token=admin_token)
    print(f"  DELETE status: {resp.status_code}")
    print(f"  ✓ Key revoked")

    # Try to use revoked key
    proxy_resp = httpx.post(
        f"{DASHBOARD_URL}/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {vk_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": "This should fail."}],
        },
        timeout=10.0,
    )
    print(f"  Proxy with revoked key: {proxy_resp.status_code}")
    if proxy_resp.status_code in (401, 403):
        print(f"  ✓ Revoked key correctly rejected")
    else:
        print(f"  Response: {proxy_resp.text[:100]}")

    pause("Virtual Keys tab: demo-api-key shows REVOKED status")

    # -----------------------------------------------------------------------
    # 10. User management
    # -----------------------------------------------------------------------
    header("POST /users — create viewer user")
    viewer_id = None
    if admin_token:
        resp = api("POST", "/users", token=admin_token, json={
            "email": "viewer@vkey-demo.example.com",
            "password": "ViewerP@ss!2024",
            "org_role": "team_viewer",
        })
        print(f"  POST status: {resp.status_code}")
        if resp.status_code in (200, 201):
            viewer = resp.json()
            viewer_id = viewer.get("id", viewer.get("user_id", ""))
            print(f"  Viewer created: {viewer.get('email')}  id={viewer_id[:20]}...")
        elif resp.status_code == 409:
            print(f"  Viewer already exists")

    # List users
    header("GET /users — list all users")
    if admin_token:
        resp = api("GET", "/users", token=admin_token)
        users = resp.json()
        users_list = users if isinstance(users, list) else users.get("users", [])
        print(f"  Total users: {len(users_list)}")
        for u in users_list:
            print(f"    - {u.get('email')}  role={u.get('org_role')}  "
                  f"active={u.get('is_active', True)}")

    # Update user
    if viewer_id and admin_token:
        header("PATCH /users/{id} — update viewer display name")
        resp = api("PATCH", f"/users/{viewer_id}", token=admin_token, json={
            "display_name": "Demo Viewer User",
        })
        print(f"  PATCH status: {resp.status_code}")

        # Get user detail
        resp = api("GET", f"/users/{viewer_id}", token=admin_token)
        if resp.status_code == 200:
            u = resp.json()
            print(f"  Updated: {u.get('display_name')}")

    # Assign team role
    if viewer_id and admin_token:
        header("POST /users/{id}/team-roles — assign team_editor")
        resp = api("POST", f"/users/{viewer_id}/team-roles", token=admin_token, json={
            "team_id": team.id,
            "role": "team_editor",
        })
        print(f"  Assign team role: {resp.status_code}")

        # Remove team role
        resp = api("DELETE", f"/users/{viewer_id}/team-roles/{team.id}", token=admin_token)
        print(f"  Remove team role: {resp.status_code}")

    # Delete user
    if viewer_id and admin_token:
        header("DELETE /users/{id} — soft-delete viewer")
        resp = api("DELETE", f"/users/{viewer_id}", token=admin_token)
        print(f"  DELETE status: {resp.status_code}")
        print(f"  ✓ Viewer soft-deleted")

    pause("Users tab: see admin + soft-deleted viewer")

    # -----------------------------------------------------------------------
    # 11. OIDC provider CRUD
    # -----------------------------------------------------------------------
    header("OIDC provider CRUD")
    oidc_id = None
    if admin_token:
        # Create
        resp = api("POST", "/oidc/providers", token=admin_token, json={
            "issuer_url": "https://accounts.google.com",
            "client_id": "demo-client-id",
            "client_secret": "demo-client-secret",
            "scopes": "openid email profile",
        })
        print(f"  POST /oidc/providers: {resp.status_code}")
        if resp.status_code in (200, 201):
            oidc = resp.json()
            oidc_id = oidc.get("id", "")
            print(f"  OIDC provider ID: {oidc_id[:20]}...")

        # List
        resp = api("GET", "/oidc/providers", token=admin_token)
        providers = resp.json()
        providers_list = providers if isinstance(providers, list) else providers.get("providers", [])
        print(f"  OIDC providers: {len(providers_list)}")

        # Update
        if oidc_id:
            resp = api("PATCH", f"/oidc/providers/{oidc_id}", token=admin_token, json={
                "scopes": "openid email profile groups",
            })
            print(f"  PATCH OIDC provider: {resp.status_code}")

            # Delete
            resp = api("DELETE", f"/oidc/providers/{oidc_id}", token=admin_token)
            print(f"  DELETE OIDC provider: {resp.status_code}")

    # Public OIDC providers endpoint
    resp = api("GET", "/auth/oidc/providers")
    print(f"\n  GET /auth/oidc/providers: {resp.status_code}")

    # -----------------------------------------------------------------------
    # 12. Device flow
    # -----------------------------------------------------------------------
    header("Device authorization flow")
    resp = api("POST", "/auth/device/authorize")
    print(f"  POST /auth/device/authorize: {resp.status_code}")
    if resp.status_code == 200:
        device = resp.json()
        device_code = device.get("device_code", "")
        user_code = device.get("user_code", "")
        print(f"  Device code: {device_code[:20]}...")
        print(f"  User code:   {user_code}")

        # Poll for token (will be pending since we haven't verified)
        resp = api("POST", "/auth/device/token", json={
            "device_code": device_code,
        })
        print(f"  POST /auth/device/token: {resp.status_code} "
              f"(expected 400/pending)")

    # -----------------------------------------------------------------------
    # 13. Token refresh
    # -----------------------------------------------------------------------
    header("POST /auth/refresh — rotate tokens")
    if refresh_token:
        resp = api("POST", "/auth/refresh", json={
            "refresh_token": refresh_token,
        })
        if resp.status_code == 200:
            data = resp.json()
            new_token = data.get("access_token", "")
            print(f"  ✓ New access token: {new_token[:40]}...")
            admin_token = new_token
        else:
            print(f"  Refresh: {resp.status_code}")

    # -----------------------------------------------------------------------
    # 14. Change password
    # -----------------------------------------------------------------------
    header("POST /auth/change-password")
    if admin_token:
        resp = api("POST", "/auth/change-password", token=admin_token, json={
            "current_password": ADMIN_PASSWORD,
            "new_password": ADMIN_PASSWORD,  # same password for demo simplicity
        })
        print(f"  Change password: {resp.status_code}")

    # -----------------------------------------------------------------------
    # 15. Logout
    # -----------------------------------------------------------------------
    header("POST /auth/logout — revoke refresh token")
    if refresh_token:
        resp = api("POST", "/auth/logout", json={
            "refresh_token": refresh_token,
        })
        print(f"  Logout: {resp.status_code}")
        if resp.status_code == 200:
            print(f"  ✓ Refresh token revoked")

    pause(
        "Auth demo complete — all auth, VK, user, OIDC endpoints exercised.\n"
        "  >> Users tab shows admin user.\n"
        "  >> Virtual Keys tab shows the revoked key."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
