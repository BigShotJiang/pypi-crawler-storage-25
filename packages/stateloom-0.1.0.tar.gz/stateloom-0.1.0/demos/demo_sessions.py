#!/usr/bin/env python3
"""Demo: Session Lifecycle — monitor at http://localhost:4781

Real-world scenario: A support chatbot handling multiple customer conversations.
Each conversation is a session with cost tracking and metadata.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # --- Session 1: Single customer question ---
    header("Customer asks a product question")
    with stateloom.session(session_id="support-ticket-1001", name="Product Inquiry") as s:
        s.metadata["customer_id"] = "cust-42"
        s.metadata["channel"] = "web-chat"
        r = ask(user_msg("What's the difference between your Pro and Enterprise plans?"))
        print(f"  Response: {r.content[:120]}...")
        print(f"  Cost: ${s.total_cost:.6f}  Tokens: {s.total_tokens}  Calls: {s.call_count}")

    pause("Sessions tab: click 'support-ticket-1001' to see the LLM call event and metadata")

    # --- Session 2: Multi-turn troubleshooting ---
    header("Multi-turn troubleshooting conversation")
    with stateloom.session(session_id="support-ticket-1002", name="Login Troubleshoot") as s:
        s.metadata["customer_id"] = "cust-87"
        s.metadata["priority"] = "high"

        r1 = ask([
            {"role": "system", "content": "You are a helpful support agent. Be concise."},
            {"role": "user", "content": "I can't log in to my account. I keep getting 'invalid credentials'."},
        ])
        print(f"  Agent: {r1.content[:100]}...")

        r2 = ask([
            {"role": "system", "content": "You are a helpful support agent. Be concise."},
            {"role": "user", "content": "I can't log in to my account."},
            {"role": "assistant", "content": r1.content},
            {"role": "user", "content": "Yes I tried resetting my password but the email never arrives."},
        ])
        print(f"  Agent: {r2.content[:100]}...")

        r3 = ask([
            {"role": "system", "content": "You are a helpful support agent. Be concise."},
            {"role": "user", "content": "I can't log in to my account."},
            {"role": "assistant", "content": r1.content},
            {"role": "user", "content": "Yes I tried resetting my password but the email never arrives."},
            {"role": "assistant", "content": r2.content},
            {"role": "user", "content": "It's john@company.com. I checked spam too."},
        ])
        print(f"  Agent: {r3.content[:100]}...")
        print(f"\n  Total — Cost: ${s.total_cost:.6f}  Tokens: {s.total_tokens}  Calls: {s.call_count}")

    pause(
        "Sessions tab: click 'support-ticket-1002' — 3 LLM calls in the waterfall.\n"
        "  >> Overview tab: total cost across both sessions."
    )

    # --- Session 3: Different model (gpt-4o for complex analysis) ---
    header("Session with metadata and different parameters")
    with stateloom.session(session_id="analytics-run-55", name="Churn Analysis") as s:
        s.metadata["team"] = "data-science"
        s.metadata["environment"] = "production"
        s.metadata["pipeline_version"] = "v2.3"
        r = ask([
            {"role": "system", "content": "You are a data analyst. Respond concisely."},
            {"role": "user", "content": "What are the top 3 leading indicators of customer churn in SaaS?"},
        ])
        print(f"  Analysis: {r.content[:150]}...")
        print(f"  Cost: ${s.total_cost:.6f}")

    pause(
        "Sessions tab: 3 sessions visible — click each to see events.\n"
        "  >> Overview tab: aggregated cost, token count, and call metrics."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
