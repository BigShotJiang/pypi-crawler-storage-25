#!/usr/bin/env python3
"""Demo: Compliance Profiles — Global, Org-Level, and Team-Level via Dashboard API

Sets compliance profiles (GDPR, HIPAA, CCPA) at different hierarchy levels,
queries audit events, and performs a right-to-be-forgotten purge.

Endpoints exercised:
  GET    /api/v1/compliance/profiles
  GET    /api/v1/compliance/global
  PUT    /api/v1/compliance/global
  DELETE /api/v1/compliance/global
  GET    /api/v1/compliance/audit
  POST   /api/v1/compliance/purge
  GET    /api/v1/organizations/{id}/compliance
  PUT    /api/v1/organizations/{id}/compliance
  GET    /api/v1/teams/{id}/compliance
  PUT    /api/v1/teams/{id}/compliance
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # -----------------------------------------------------------------------
    # 1. List available compliance presets
    # -----------------------------------------------------------------------
    header("GET /compliance/profiles — available presets")
    resp = api("GET", "/compliance/profiles")
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        profiles = resp.json()
        if isinstance(profiles, list):
            print(f"  Available profiles ({len(profiles)}):")
            for p in profiles:
                name = p.get("standard", p.get("name", p)) if isinstance(p, dict) else p
                print(f"    - {name}")
        elif isinstance(profiles, dict):
            for name, detail in profiles.items():
                print(f"    - {name}: {detail}")
    else:
        print(f"  Response: {resp.text[:150]}")

    # -----------------------------------------------------------------------
    # 2. Check global compliance (should be empty)
    # -----------------------------------------------------------------------
    header("GET /compliance/global — no profile set yet")
    resp = api("GET", "/compliance/global")
    print(f"  Status: {resp.status_code}")
    global_compliance = resp.json()
    print(f"  Global compliance: {global_compliance}")

    # -----------------------------------------------------------------------
    # 3. Set GDPR globally
    # -----------------------------------------------------------------------
    header("PUT /compliance/global — set GDPR")
    resp = api("PUT", "/compliance/global", json={
        "standard": "gdpr",
        "region": "eu",
        "session_ttl_days": 30,
        "cache_ttl_seconds": 3600,
        "zero_retention_logs": False,
    })
    print(f"  PUT status: {resp.status_code}")
    if resp.status_code == 200:
        print(f"  ✓ GDPR compliance profile set globally")

    # Verify
    resp = api("GET", "/compliance/global")
    global_compliance = resp.json()
    print(f"  Global compliance: standard={global_compliance.get('standard')}  "
          f"region={global_compliance.get('region')}")

    # -----------------------------------------------------------------------
    # 4. Make a call under GDPR compliance
    # -----------------------------------------------------------------------
    header("LLM call under GDPR compliance")
    with stateloom.session(session_id="comp-gdpr", name="GDPR Call") as s:
        r = ask(user_msg("What are the key principles of GDPR? One sentence."))
        print(f"  Response: {r.content[:100]}")
        print(f"  Cost: ${s.total_cost:.6f}")

    pause("Sessions tab: comp-gdpr session — compliance metadata in session details")

    # -----------------------------------------------------------------------
    # 5. Query compliance audit events
    # -----------------------------------------------------------------------
    header("GET /compliance/audit — audit trail")
    resp = api("GET", "/compliance/audit")
    audit = resp.json()
    events = audit.get("events", audit.get("audit_events", []))
    if isinstance(events, list):
        print(f"  Audit events: {len(events)}")
        for e in events[:5]:
            print(f"    - type={e.get('type', e.get('event_type', 'N/A'))}  "
                  f"standard={e.get('standard', 'N/A')}")
    else:
        print(f"  Audit: {audit}")

    # -----------------------------------------------------------------------
    # 6. Create org + team for hierarchy testing
    # -----------------------------------------------------------------------
    header("Create org + team for per-level compliance")
    org = stateloom.create_organization(name="ComplianceCorp", budget=100.0)
    team = stateloom.create_team(org.id, name="Healthcare Div")
    print(f"  Org:  {org.name} ({org.id[:20]}...)")
    print(f"  Team: {team.name} ({team.id[:20]}...)")

    # -----------------------------------------------------------------------
    # 7. Set HIPAA on org
    # -----------------------------------------------------------------------
    header("PUT /organizations/{id}/compliance — HIPAA on org")
    resp = api("PUT", f"/organizations/{org.id}/compliance", json={
        "standard": "hipaa",
        "region": "us",
        "session_ttl_days": 365,
        "zero_retention_logs": True,
    })
    print(f"  PUT status: {resp.status_code}")

    # Read back
    resp = api("GET", f"/organizations/{org.id}/compliance")
    org_compliance = resp.json()
    print(f"  Org compliance: standard={org_compliance.get('standard')}  "
          f"zero_retention={org_compliance.get('zero_retention_logs')}")

    # -----------------------------------------------------------------------
    # 8. Set CCPA on team
    # -----------------------------------------------------------------------
    header("PUT /teams/{id}/compliance — CCPA on team")
    resp = api("PUT", f"/teams/{team.id}/compliance", json={
        "standard": "ccpa",
        "region": "us-ca",
        "session_ttl_days": 90,
    })
    print(f"  PUT status: {resp.status_code}")

    # Read back
    resp = api("GET", f"/teams/{team.id}/compliance")
    team_compliance = resp.json()
    print(f"  Team compliance: standard={team_compliance.get('standard')}  "
          f"region={team_compliance.get('region')}")

    # -----------------------------------------------------------------------
    # 9. Make a call in team context (team compliance applies)
    # -----------------------------------------------------------------------
    header("LLM call in team context — CCPA applies")
    with stateloom.session(
        session_id="comp-team-ccpa",
        name="CCPA Team Call",
        org_id=org.id,
        team_id=team.id,
    ) as s:
        r = ask(user_msg("What rights does CCPA give California consumers? One sentence."))
        print(f"  Response: {r.content[:100]}")
        print(f"  Cost: ${s.total_cost:.6f}")

    pause(
        "Organizations tab: ComplianceCorp shows HIPAA badge.\n"
        "  >> Healthcare Div team shows CCPA badge.\n"
        "  >> comp-team-ccpa session inherits team compliance."
    )

    # -----------------------------------------------------------------------
    # 10. Clear global compliance
    # -----------------------------------------------------------------------
    header("DELETE /compliance/global — remove global profile")
    resp = api("DELETE", "/compliance/global")
    print(f"  DELETE status: {resp.status_code}")

    resp = api("GET", "/compliance/global")
    print(f"  Global compliance after delete: {resp.json()}")
    print(f"  ✓ Global compliance cleared (org/team profiles still active)")

    # -----------------------------------------------------------------------
    # 11. Right to Be Forgotten (purge)
    # -----------------------------------------------------------------------
    header("POST /compliance/purge — right to be forgotten")
    resp = api("POST", "/compliance/purge", json={
        "user_identifier": "test-user@example.com",
        "standard": "gdpr",
    })
    print(f"  Purge status: {resp.status_code}")
    if resp.status_code == 200:
        result = resp.json()
        print(f"  Purge result: {result}")
        print(f"  ✓ User data purged per GDPR Right to Erasure")
    else:
        print(f"  Response: {resp.text[:150]}")

    # -----------------------------------------------------------------------
    # 12. Re-check audit trail after purge
    # -----------------------------------------------------------------------
    header("GET /compliance/audit — verify purge in audit trail")
    resp = api("GET", "/compliance/audit")
    audit = resp.json()
    events = audit.get("events", audit.get("audit_events", []))
    if isinstance(events, list):
        print(f"  Audit events after purge: {len(events)}")
        # Look for the purge event
        for e in events[-3:]:
            print(f"    - type={e.get('type', e.get('event_type', 'N/A'))}  "
                  f"standard={e.get('standard', 'N/A')}  "
                  f"user={e.get('user_identifier', 'N/A')}")

    pause(
        "Compliance tab: full audit trail showing GDPR/HIPAA/CCPA changes.\n"
        "  >> Purge event logged for right-to-be-forgotten request.\n"
        "  >> Hierarchy: global → org → team compliance levels."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
