#!/usr/bin/env python3
"""Demo: Agent CRUD, Versioning, Rollback, and Prompt Watcher via Dashboard API

Creates a managed agent through the REST API, publishes new versions,
activates/rollbacks between them, and verifies the LLM behavior changes
after each version switch.

Endpoints exercised:
  POST   /api/v1/agents
  GET    /api/v1/agents
  GET    /api/v1/agents/{ref}
  PATCH  /api/v1/agents/{ref}
  DELETE /api/v1/agents/{ref}
  POST   /api/v1/agents/{ref}/versions
  GET    /api/v1/agents/{ref}/versions
  PUT    /api/v1/agents/{ref}/versions/{id}/activate
  GET    /api/v1/agents/{ref}/sessions
  GET    /api/v1/prompts/status
  POST   /api/v1/prompts/rescan
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

try:
    import httpx
except ImportError:
    print("\n  This demo requires httpx: pip install httpx")
    sys.exit(1)


def main():
    gate = init_gate(proxy=True, proxy_require_virtual_key=True)

    # -----------------------------------------------------------------------
    # 1. Set up org + team
    # -----------------------------------------------------------------------
    header("Create org + team for agent")
    org = stateloom.create_organization(name="AgentDemo Corp", budget=100.0)
    team = stateloom.create_team(org.id, name="Product Team")
    print(f"  Org:  {org.name}")
    print(f"  Team: {team.name}")

    # -----------------------------------------------------------------------
    # 2. Create agent v1 via API
    # -----------------------------------------------------------------------
    header("POST /agents — create 'math-tutor' agent v1")
    resp = api("POST", "/agents", json={
        "slug": "math-tutor",
        "team_id": team.id,
        "name": "Math Tutor Bot",
        "description": "Helps students with math problems",
        "model": MODEL,
        "system_prompt": (
            "You are a friendly math tutor. Help students solve problems step by step. "
            "Be encouraging and explain clearly. Keep answers concise."
        ),
        "request_overrides": {"temperature": 0.3},
        "budget_per_session": 1.0,
        "metadata": {"subject": "math", "level": "high-school"},
    })
    print(f"  POST status: {resp.status_code}")
    agent_data = resp.json()
    agent = agent_data.get("agent", agent_data)
    agent_id = agent.get("id", "")
    v1_version = agent_data.get("version", {})
    v1_id = v1_version.get("id", "")
    print(f"  Agent ID:   {agent_id}")
    print(f"  Slug:       {agent.get('slug')}")
    print(f"  Version v1: {v1_id}")

    # -----------------------------------------------------------------------
    # 3. List agents
    # -----------------------------------------------------------------------
    header("GET /agents — list all agents")
    resp = api("GET", "/agents")
    agents = resp.json()
    agents_list = agents if isinstance(agents, list) else agents.get("agents", [])
    print(f"  Total agents: {len(agents_list)}")
    for a in agents_list:
        print(f"    - {a.get('slug')}: {a.get('name')}  status={a.get('status')}")

    # -----------------------------------------------------------------------
    # 4. Get agent detail by slug
    # -----------------------------------------------------------------------
    header(f"GET /agents/math-tutor?team_id=... — agent detail")
    resp = api("GET", f"/agents/math-tutor", params={"team_id": team.id})
    if resp.status_code == 200:
        detail = resp.json()
        print(f"  Name:   {detail.get('name')}")
        print(f"  Model:  {detail.get('model', MODEL)}")
        print(f"  Status: {detail.get('status')}")
    else:
        # Try by ID instead
        resp = api("GET", f"/agents/{agent_id}")
        detail = resp.json()
        print(f"  Name: {detail.get('name')}")

    # -----------------------------------------------------------------------
    # 5. Create VK scoped to agent → proxy call
    # -----------------------------------------------------------------------
    header("Create VK + call agent via proxy (v1 — friendly tutor)")
    vk = stateloom.create_virtual_key(team.id, name="tutor-key", agent_ids=[agent_id])
    vk_key = vk["key"]
    print(f"  VK: {vk['key_preview']} (scoped to math-tutor)")

    time.sleep(1)

    proxy_resp = httpx.post(
        f"{DASHBOARD_URL}/v1/agents/math-tutor/chat/completions",
        headers={
            "Authorization": f"Bearer {vk_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": "What is the integral of x^2?"}],
        },
        timeout=30.0,
    )
    print(f"  Proxy status: {proxy_resp.status_code}")
    if proxy_resp.status_code == 200:
        content = proxy_resp.json()["choices"][0]["message"]["content"]
        print(f"  v1 Reply: {content[:150]}...")
        print(f"  (Friendly tutor style)")
    else:
        print(f"  Error: {proxy_resp.text[:150]}")

    pause("Agents tab: see math-tutor agent. Click for details + version history.")

    # -----------------------------------------------------------------------
    # 6. Create v2 — strict teacher persona
    # -----------------------------------------------------------------------
    header("POST /agents/{ref}/versions — create v2 (strict teacher)")
    resp = api("POST", f"/agents/{agent_id}/versions", json={
        "model": MODEL,
        "system_prompt": (
            "You are a strict math teacher. You only answer math-related questions. "
            "If the question is not about math, refuse politely but firmly. "
            "For math questions, give the answer directly without lengthy explanations. "
            "Never be chatty."
        ),
        "request_overrides": {"temperature": 0.1, "max_tokens": 200},
        "created_by": "pm-demo",
    })
    print(f"  POST version status: {resp.status_code}")
    v2 = resp.json()
    v2_id = v2.get("id", "")
    print(f"  Version v2: {v2_id}")

    # -----------------------------------------------------------------------
    # 7. List versions
    # -----------------------------------------------------------------------
    header("GET /agents/{ref}/versions — version history")
    resp = api("GET", f"/agents/{agent_id}/versions")
    versions = resp.json()
    versions_list = versions if isinstance(versions, list) else versions.get("versions", [])
    print(f"  Versions ({len(versions_list)}):")
    for v in versions_list:
        active = " ← ACTIVE" if v.get("is_active") else ""
        print(f"    v{v.get('version_number', '?')}: {v.get('id', '')[:20]}...{active}")

    # -----------------------------------------------------------------------
    # 8. Activate v2
    # -----------------------------------------------------------------------
    header("PUT /agents/{ref}/versions/{id}/activate — switch to v2")
    resp = api("PUT", f"/agents/{agent_id}/versions/{v2_id}/activate")
    print(f"  Activate v2: {resp.status_code}")

    time.sleep(1)

    # Call again — should be strict teacher
    proxy_resp = httpx.post(
        f"{DASHBOARD_URL}/v1/agents/math-tutor/chat/completions",
        headers={
            "Authorization": f"Bearer {vk_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": "What is the integral of x^2?"}],
        },
        timeout=30.0,
    )
    if proxy_resp.status_code == 200:
        content = proxy_resp.json()["choices"][0]["message"]["content"]
        print(f"  v2 Reply: {content[:150]}...")
        print(f"  (Strict teacher style — more direct)")

    # Try a non-math question with v2
    proxy_resp = httpx.post(
        f"{DASHBOARD_URL}/v1/agents/math-tutor/chat/completions",
        headers={
            "Authorization": f"Bearer {vk_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": "Who won the World Cup in 2022?"}],
        },
        timeout=30.0,
    )
    if proxy_resp.status_code == 200:
        content = proxy_resp.json()["choices"][0]["message"]["content"]
        print(f"  Non-math with v2: {content[:150]}...")
        print(f"  (v2 should refuse non-math questions)")

    pause(
        "Sessions tab: compare v1 vs v2 responses.\n"
        "  >> v1 is friendly/verbose, v2 is strict/direct and refuses non-math."
    )

    # -----------------------------------------------------------------------
    # 9. Rollback to v1
    # -----------------------------------------------------------------------
    header("Rollback to v1")
    resp = api("PUT", f"/agents/{agent_id}/versions/{v1_id}/activate")
    print(f"  Activate v1: {resp.status_code}")

    time.sleep(1)

    proxy_resp = httpx.post(
        f"{DASHBOARD_URL}/v1/agents/math-tutor/chat/completions",
        headers={
            "Authorization": f"Bearer {vk_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": "What is the integral of x^2?"}],
        },
        timeout=30.0,
    )
    if proxy_resp.status_code == 200:
        content = proxy_resp.json()["choices"][0]["message"]["content"]
        print(f"  Rollback Reply: {content[:150]}...")
        print(f"  ✓ Back to friendly tutor style")

    # -----------------------------------------------------------------------
    # 10. List agent sessions
    # -----------------------------------------------------------------------
    header("GET /agents/{ref}/sessions — sessions using this agent")
    resp = api("GET", f"/agents/{agent_id}/sessions")
    sessions = resp.json()
    sessions_list = sessions if isinstance(sessions, list) else sessions.get("sessions", [])
    print(f"  Agent sessions: {len(sessions_list)}")
    for s in sessions_list[:5]:
        print(f"    - {s.get('id', '')[:25]}  version={s.get('agent_version_number', 'N/A')}")

    # -----------------------------------------------------------------------
    # 11. Update agent metadata
    # -----------------------------------------------------------------------
    header("PATCH /agents/{ref} — update name/description")
    resp = api("PATCH", f"/agents/{agent_id}", json={
        "name": "Advanced Math Tutor",
        "description": "Upgraded math tutor with versioned personalities",
    })
    print(f"  PATCH status: {resp.status_code}")
    if resp.status_code == 200:
        updated = resp.json()
        print(f"  New name: {updated.get('name')}")

    # -----------------------------------------------------------------------
    # 12. Archive agent
    # -----------------------------------------------------------------------
    header("DELETE /agents/{ref} — archive agent")
    resp = api("DELETE", f"/agents/{agent_id}")
    print(f"  DELETE status: {resp.status_code}")

    # Verify archived
    resp = api("GET", f"/agents/{agent_id}")
    if resp.status_code == 200:
        detail = resp.json()
        print(f"  Status: {detail.get('status')} (should be archived)")
        if detail.get("status") == "archived":
            print(f"  ✓ Agent archived (soft delete)")

    # -----------------------------------------------------------------------
    # 13. Prompt watcher status
    # -----------------------------------------------------------------------
    header("Prompt watcher endpoints")
    resp = api("GET", "/prompts/status")
    print(f"  GET /prompts/status: {resp.status_code}")
    if resp.status_code == 200:
        status = resp.json()
        print(f"  Watcher: {status}")

    resp = api("POST", "/prompts/rescan")
    print(f"  POST /prompts/rescan: {resp.status_code}")

    pause(
        "Agents tab: math-tutor now shows 'archived' status.\n"
        "  >> Version history shows v1 and v2 with activation timestamps.\n"
        "  >> Sessions show which version was active for each call."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
