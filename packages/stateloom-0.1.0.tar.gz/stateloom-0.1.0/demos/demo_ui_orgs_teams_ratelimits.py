#!/usr/bin/env python3
"""Demo: Org/Team CRUD, Budgets, and Rate Limits via Dashboard API

Creates organizations and teams through the REST API, configures budgets and
rate limits, then verifies enforcement on LLM calls.

Endpoints exercised:
  POST   /api/v1/organizations
  GET    /api/v1/organizations
  GET    /api/v1/organizations/{id}
  PATCH  /api/v1/organizations/{id}
  GET    /api/v1/organizations/{id}/teams
  GET    /api/v1/organizations/{id}/sessions
  POST   /api/v1/teams
  GET    /api/v1/teams
  GET    /api/v1/teams/{id}
  PATCH  /api/v1/teams/{id}
  GET    /api/v1/teams/{id}/sessions
  PUT    /api/v1/teams/{id}/rate-limit
  GET    /api/v1/teams/{id}/rate-limit
  DELETE /api/v1/teams/{id}/rate-limit
  GET    /api/v1/rate-limiter
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    gate = init_gate()

    # -----------------------------------------------------------------------
    # 1. Create organization via API
    # -----------------------------------------------------------------------
    header("POST /organizations — create org with budget")
    resp = api("POST", "/organizations", json={
        "name": "Acme Corp",
        "budget": 10.0,
        "metadata": {"industry": "tech", "tier": "enterprise"},
    })
    print(f"  POST status: {resp.status_code}")
    org = resp.json()
    org_id = org.get("id", "")
    print(f"  Org ID:   {org_id}")
    print(f"  Name:     {org.get('name')}")
    print(f"  Budget:   ${org.get('budget')}")

    # -----------------------------------------------------------------------
    # 2. List organizations
    # -----------------------------------------------------------------------
    header("GET /organizations — list all orgs")
    resp = api("GET", "/organizations")
    orgs = resp.json()
    orgs_list = orgs if isinstance(orgs, list) else orgs.get("organizations", [])
    print(f"  Total organizations: {len(orgs_list)}")
    for o in orgs_list:
        print(f"    - {o.get('name')} ({o.get('id', '')[:20]}...) budget=${o.get('budget')}")

    # -----------------------------------------------------------------------
    # 3. Get org detail
    # -----------------------------------------------------------------------
    header("GET /organizations/{id} — org detail")
    resp = api("GET", f"/organizations/{org_id}")
    detail = resp.json()
    print(f"  Name: {detail.get('name')}")
    print(f"  Budget: ${detail.get('budget')}")
    print(f"  Total cost: ${detail.get('total_cost', 0):.6f}")

    # -----------------------------------------------------------------------
    # 4. Create teams under the org
    # -----------------------------------------------------------------------
    header("POST /teams — create two teams")
    resp = api("POST", "/teams", json={
        "org_id": org_id,
        "name": "Engineering",
        "budget": 5.0,
        "metadata": {"department": "engineering"},
    })
    team_eng = resp.json()
    team_eng_id = team_eng.get("id", "")
    print(f"  Team A: {team_eng.get('name')} ({team_eng_id[:20]}...)  budget=${team_eng.get('budget')}")

    resp = api("POST", "/teams", json={
        "org_id": org_id,
        "name": "Marketing",
        "budget": 3.0,
        "metadata": {"department": "marketing"},
    })
    team_mkt = resp.json()
    team_mkt_id = team_mkt.get("id", "")
    print(f"  Team B: {team_mkt.get('name')} ({team_mkt_id[:20]}...)  budget=${team_mkt.get('budget')}")

    # -----------------------------------------------------------------------
    # 5. List teams (global and per-org)
    # -----------------------------------------------------------------------
    header("GET /teams and GET /organizations/{id}/teams")
    resp = api("GET", "/teams")
    teams = resp.json()
    teams_list = teams if isinstance(teams, list) else teams.get("teams", [])
    print(f"  All teams: {len(teams_list)}")

    resp = api("GET", f"/organizations/{org_id}/teams")
    org_teams = resp.json()
    org_teams_list = org_teams if isinstance(org_teams, list) else org_teams.get("teams", [])
    print(f"  Acme Corp teams: {len(org_teams_list)}")
    for t in org_teams_list:
        print(f"    - {t.get('name')}: budget=${t.get('budget')}")

    # -----------------------------------------------------------------------
    # 6. Get team detail
    # -----------------------------------------------------------------------
    header("GET /teams/{id} — team detail")
    resp = api("GET", f"/teams/{team_eng_id}")
    detail = resp.json()
    print(f"  Name: {detail.get('name')}")
    print(f"  Org:  {detail.get('org_id', '')[:20]}...")
    print(f"  Budget: ${detail.get('budget')}")

    # -----------------------------------------------------------------------
    # 7. Make calls in team context → verify in sessions
    # -----------------------------------------------------------------------
    header("LLM calls in Engineering team context")
    with stateloom.session(
        session_id="org-eng-1",
        name="Engineering Query",
        org_id=org_id,
        team_id=team_eng_id,
    ) as s:
        r = ask(user_msg("What is a microservice? One sentence."))
        print(f"  Response: {r.content[:80]}")
        print(f"  Cost: ${s.total_cost:.6f}")

    resp = api("GET", f"/teams/{team_eng_id}/sessions")
    sessions = resp.json()
    sessions_list = sessions if isinstance(sessions, list) else sessions.get("sessions", [])
    print(f"\n  Engineering sessions: {len(sessions_list)}")

    resp = api("GET", f"/organizations/{org_id}/sessions")
    org_sessions = resp.json()
    org_sessions_list = org_sessions if isinstance(org_sessions, list) else org_sessions.get("sessions", [])
    print(f"  Acme Corp sessions: {len(org_sessions_list)}")

    pause("Organizations tab: see Acme Corp with Engineering and Marketing teams")

    # -----------------------------------------------------------------------
    # 8. Set rate limit on Marketing team
    # -----------------------------------------------------------------------
    header("PUT /teams/{id}/rate-limit — set Marketing TPS=1.0")
    resp = api("PUT", f"/teams/{team_mkt_id}/rate-limit", json={
        "rate_limit_tps": 1.0,
        "rate_limit_priority": 5,
        "rate_limit_max_queue": 10,
        "rate_limit_queue_timeout": 10.0,
    })
    print(f"  PUT status: {resp.status_code}")

    # Read it back
    resp = api("GET", f"/teams/{team_mkt_id}/rate-limit")
    rl = resp.json()
    print(f"  Rate limit: TPS={rl.get('rate_limit_tps')}  "
          f"priority={rl.get('rate_limit_priority')}  "
          f"max_queue={rl.get('rate_limit_max_queue')}")

    # Global rate limiter status
    resp = api("GET", "/rate-limiter")
    limiter = resp.json()
    print(f"\n  Global rate limiter: {limiter}")

    pause("Teams tab: Marketing team now has a rate limit badge")

    # -----------------------------------------------------------------------
    # 9. Tighten org budget → verify enforcement
    # -----------------------------------------------------------------------
    header("PATCH /organizations/{id} — tighten budget to $0.0001")
    resp = api("PATCH", f"/organizations/{org_id}", json={"budget": 0.0001})
    print(f"  PATCH status: {resp.status_code}")

    with stateloom.session(
        session_id="org-tight-budget",
        name="Tight Org Budget",
        org_id=org_id,
        team_id=team_eng_id,
    ) as s:
        try:
            ask(user_msg("Write a haiku about code."))
            print(f"  Call 1: cost=${s.total_cost:.6f}")
            ask(user_msg("Write another haiku."))
            print(f"  Call 2: cost=${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"  ✓ ORG BUDGET BLOCKED: {e}")

    # Restore org budget
    api("PATCH", f"/organizations/{org_id}", json={"budget": 100.0})
    print(f"\n  Restored org budget=$100")

    # -----------------------------------------------------------------------
    # 10. Tighten team budget → verify enforcement
    # -----------------------------------------------------------------------
    header("PATCH /teams/{id} — tighten Engineering budget to $0.0001")
    resp = api("PATCH", f"/teams/{team_eng_id}", json={"budget": 0.0001})
    print(f"  PATCH status: {resp.status_code}")

    with stateloom.session(
        session_id="team-tight-budget",
        name="Tight Team Budget",
        org_id=org_id,
        team_id=team_eng_id,
    ) as s:
        try:
            ask(user_msg("Explain Docker in one sentence."))
            print(f"  Call cost: ${s.total_cost:.6f}")
            ask(user_msg("Explain Kubernetes too."))
        except stateloom.StateLoomBudgetError as e:
            print(f"  ✓ TEAM BUDGET BLOCKED: {e}")

    # Restore team budget
    api("PATCH", f"/teams/{team_eng_id}", json={"budget": 50.0})
    print(f"\n  Restored team budget=$50")

    pause("Sessions tab: budget enforcement events for org and team budget violations")

    # -----------------------------------------------------------------------
    # 11. Remove rate limit
    # -----------------------------------------------------------------------
    header("DELETE /teams/{id}/rate-limit — remove Marketing rate limit")
    resp = api("DELETE", f"/teams/{team_mkt_id}/rate-limit")
    print(f"  DELETE status: {resp.status_code}")

    resp = api("GET", f"/teams/{team_mkt_id}/rate-limit")
    rl = resp.json()
    print(f"  Rate limit after delete: TPS={rl.get('rate_limit_tps')} (should be null)")
    if rl.get("rate_limit_tps") is None:
        print(f"  ✓ Rate limit removed")

    pause(
        "Organizations tab: final state — Acme Corp with two teams.\n"
        "  >> Budget and rate limit changes reflected in real-time."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
