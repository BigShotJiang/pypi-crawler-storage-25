#!/usr/bin/env python3
"""Demo: Org & Team Budget Enforcement — monitor at http://localhost:4781

Real-world scenario: An enterprise with org-level and team-level spending caps.
Demonstrates budget hierarchy (session < team < org), cross-session enforcement,
and actual blocking when budgets are exceeded.

Budget enforcement is a pre-call gate: checked BEFORE each LLM call, cost
applied AFTER. One call can overshoot, but the next is blocked. Post-call
checks record a BudgetEnforcementEvent for immediate visibility on the call
that caused the crossing.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *


def main():
    init_gate(
        budget=50.0,  # generous per-session default so BudgetEnforcer is in the pipeline
        budget_on_middleware_failure="block",
    )

    # Budgets are set extremely low so a single LLM call (~$0.00003–$0.002)
    # overshoots them, and the NEXT call triggers the pre-call block.
    header("Create org with very tight budgets")

    org = stateloom.create_organization(
        name="Acme Corp",
        budget=0.0005,  # $0.0005 org-wide — a few calls will exceed this
        metadata={"plan": "startup"},
    )
    print(f"  Org: {org.name} ({org.id}) — budget: ${org.budget}")

    # $0.00001 team budget — even the cheapest LLM call exceeds this
    eng_team = stateloom.create_team(org.id, name="Engineering", budget=0.00001)
    sales_team = stateloom.create_team(org.id, name="Sales", budget=0.0005)
    print(f"  Team: {eng_team.name} — budget: ${eng_team.budget}  (tiny!)")
    print(f"  Team: {sales_team.name} — budget: ${sales_team.budget}")

    pause(
        "Compliance > Organizations: see Acme Corp with 2 teams.\n"
        "  >> Engineering has a $0.00001 budget — any call will exceed it."
    )

    # --- Scenario 1: First call succeeds but overshoots team budget ---
    header("Engineering team — call succeeds, overshoots team budget")
    with stateloom.session(
        session_id="eng-session-1",
        name="Code Review",
        org_id=org.id,
        team_id=eng_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a code reviewer. Be concise."},
            {"role": "user", "content": "Review this function:\n"
             "def fibonacci(n):\n"
             "    if n <= 1: return n\n"
             "    return fibonacci(n-1) + fibonacci(n-2)"},
        ])
        print(f"  Review: {r.content[:120]}...")
        print(f"  Session cost: ${s.total_cost:.6f}")

    eng_stats = stateloom.team_stats(eng_team.id)
    eng_cost = eng_stats.get("total_cost", 0)
    print(f"  Engineering team total: ${eng_cost:.6f} / ${eng_team.budget}")
    print(f"  Budget crossed: {eng_cost >= eng_team.budget}")

    pause(
        "Sessions tab: click 'eng-session-1' — see a budget_enforcement event\n"
        "  >> recorded by the post-call check (budget crossed on this call).\n"
        "  >> The response was still returned (already paid for)."
    )

    # --- Scenario 2: Next call is BLOCKED ---
    header("Engineering team — next call BLOCKED (pre-call check)")
    with stateloom.session(
        session_id="eng-session-2",
        name="Architecture Review",
        org_id=org.id,
        team_id=eng_team.id,
    ) as s:
        try:
            r = ask([
                {"role": "user", "content": "Design a microservices architecture."},
            ])
            print(f"  Unexpected success: {r.content[:80]}...")
        except stateloom.StateLoomBudgetError as e:
            print(f"  BLOCKED: {e}")
            eng_stats = stateloom.team_stats(eng_team.id)
            print(f"  Engineering team spent: ${eng_stats.get('total_cost', 0):.6f} / ${eng_team.budget}")

    pause(
        "Sessions tab: click 'eng-session-2' — see the budget_enforcement event.\n"
        "  >> The call was blocked BEFORE reaching the LLM because the\n"
        "     Engineering TEAM budget ($0.00001) was already exceeded."
    )

    # --- Scenario 3: Sales team still works (independent budget) ---
    header("Sales team — independent budget, still has room")
    with stateloom.session(
        session_id="sales-session-1",
        name="Sales Pitch",
        org_id=org.id,
        team_id=sales_team.id,
    ) as s:
        r = ask([
            {"role": "system", "content": "You are a sales copywriter. One sentence."},
            {"role": "user", "content": "Write a tagline for an AI analytics platform."},
        ])
        print(f"  Tagline: {r.content[:120]}...")
        print(f"  Session cost: ${s.total_cost:.6f}")

    sales_stats = stateloom.team_stats(sales_team.id)
    org_stats = stateloom.org_stats(org.id)
    print(f"  Sales team total: ${sales_stats.get('total_cost', 0):.6f} / ${sales_team.budget}")
    print(f"  Org total:        ${org_stats.get('total_cost', 0):.6f} / ${org.budget}")

    pause(
        "Compliance > Organizations > Acme Corp:\n"
        "  >> Engineering: over budget (blocked). Sales: still has room.\n"
        "  >> Each team's budget is enforced independently."
    )

    # --- Scenario 4: Org budget blocks Sales ---
    header("Org budget enforcement — blocks Sales team too")
    print("  The org budget ($0.0005) is now likely exceeded. Trying another Sales call...")
    with stateloom.session(
        session_id="sales-session-2",
        name="Campaign Copy",
        org_id=org.id,
        team_id=sales_team.id,
    ) as s:
        try:
            r = ask([
                {"role": "user", "content": "Write a marketing campaign plan."},
            ])
            print(f"  Response: {r.content[:80]}...")
            print(f"  Session cost: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"  BLOCKED: {e}")
            org_stats = stateloom.org_stats(org.id)
            print(f"  Org total spent: ${org_stats.get('total_cost', 0):.6f} / ${org.budget}")

    pause(
        "Sessions tab: see which session got blocked.\n"
        "  >> Even if Sales TEAM budget had room, the ORG budget ($0.0005)\n"
        "     was exceeded — org-level enforcement kicked in."
    )

    # --- Final summary ---
    header("Budget hierarchy summary")
    org_stats = stateloom.org_stats(org.id)
    eng_stats = stateloom.team_stats(eng_team.id)
    sales_stats = stateloom.team_stats(sales_team.id)

    eng_over = eng_stats.get("total_cost", 0) >= eng_team.budget
    sales_over = sales_stats.get("total_cost", 0) >= sales_team.budget
    org_over = org_stats.get("total_cost", 0) >= org.budget

    print(f"  Acme Corp (org):   ${org_stats.get('total_cost', 0):.6f} / ${org.budget}  "
          f"{'OVER BUDGET' if org_over else 'OK'}")
    print(f"    Engineering:     ${eng_stats.get('total_cost', 0):.6f} / ${eng_team.budget}  "
          f"{'OVER BUDGET' if eng_over else 'OK'}")
    print(f"    Sales:           ${sales_stats.get('total_cost', 0):.6f} / ${sales_team.budget}  "
          f"{'OVER BUDGET' if sales_over else 'OK'}")
    print()
    print("  How it works:")
    print("    - Pre-call:  blocks if already over budget")
    print("    - Post-call: records event if budget was just crossed")
    print("    - One call can overshoot, but the next is blocked")
    print()
    print("  Enforcement hierarchy (checked in order):")
    print("    1. Per-session budget  →  blocks this session only")
    print("    2. Team budget         →  blocks all sessions in the team")
    print("    3. Org budget          →  blocks all sessions in the org")

    pause(
        "Compliance > Organizations > Acme Corp:\n"
        "  >> See budget status for each level.\n"
        "  >> Click sessions to see budget_enforcement events in the trace."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
