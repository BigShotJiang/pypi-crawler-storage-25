#!/usr/bin/env python3
"""Demo: OpenAI-Compatible Proxy with Anthropic — monitor at http://localhost:4781

Real-world scenario: Your backend services call an internal proxy URL
instead of provider APIs directly. The proxy authenticates via virtual keys,
routes through the middleware pipeline, and returns OpenAI-format responses —
regardless of the underlying provider (here: Anthropic Claude).

Requires: ANTHROPIC_API_KEY environment variable.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import time
import httpx

ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"


def main():
    if not ANTHROPIC_KEY:
        print("\n  ERROR: ANTHROPIC_API_KEY not set.")
        print("  This demo uses Anthropic's Claude via the proxy.\n")
        sys.exit(1)

    gate = init_gate(
        proxy=True,
        proxy_require_virtual_key=True,
    )

    # --- Set up org, team, and virtual key ---
    header("Set up proxy authentication")
    org = stateloom.create_organization(name="ProxyCorp", budget=50.0)
    team = stateloom.create_team(org.id, name="Backend Team")
    vk = stateloom.create_virtual_key(team.id, name="backend-service-key")
    api_key = vk["key"]
    print(f"  Org:  {org.name}")
    print(f"  Team: {team.name}")
    print(f"  Key:  {vk['key_preview']}  (full key stored securely)")
    print(f"  Provider: Anthropic | Model: {ANTHROPIC_MODEL}")

    time.sleep(1)  # let proxy server start

    pause("The proxy is running at http://localhost:4781/v1/chat/completions")

    # --- Scenario 1: Chat completion via proxy using Anthropic (BYOK) ---
    header("POST /v1/chat/completions — Anthropic via BYOK header")
    resp = httpx.post(
        f"{DASHBOARD_URL}/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-StateLoom-Anthropic-Key": ANTHROPIC_KEY,
        },
        json={
            "model": ANTHROPIC_MODEL,
            "messages": [
                {"role": "system", "content": "You are a helpful assistant. Be concise."},
                {"role": "user", "content": "Explain what a REST API is in one sentence."},
            ],
        },
        timeout=30.0,
    )
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        usage = data.get("usage", {})
        print(f"  Model:  {data.get('model')}")
        print(f"  Reply:  {content[:100]}...")
        print(f"  Tokens: {usage.get('total_tokens', 'N/A')}")
    else:
        print(f"  Error: {resp.text[:200]}")

    pause(
        "Sessions tab: see the proxy session with LLM call event.\n"
        "  >> Model shows claude-haiku — routed through Anthropic via BYOK."
    )

    # --- Scenario 2: Multi-turn conversation via proxy ---
    header("Multi-turn conversation — Anthropic via proxy")
    resp = httpx.post(
        f"{DASHBOARD_URL}/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-StateLoom-Anthropic-Key": ANTHROPIC_KEY,
        },
        json={
            "model": ANTHROPIC_MODEL,
            "messages": [
                {"role": "system", "content": "You are a Python expert. Be concise."},
                {"role": "user", "content": "What's a list comprehension?"},
                {"role": "assistant", "content": "A concise way to create lists using a single line: [expr for item in iterable if condition]."},
                {"role": "user", "content": "Show me a real-world example with filtering."},
            ],
        },
        timeout=30.0,
    )
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        usage = data.get("usage", {})
        print(f"  Model:  {data.get('model')}")
        print(f"  Reply:  {content[:120]}...")
        print(f"  Tokens: {usage.get('total_tokens', 'N/A')}")
    else:
        print(f"  Error: {resp.text[:200]}")

    pause("Sessions tab: second proxy call — multi-turn context preserved")

    # --- Scenario 3: Invalid key rejected ---
    header("Invalid API key — rejected by proxy")
    resp = httpx.post(
        f"{DASHBOARD_URL}/v1/chat/completions",
        headers={
            "Authorization": "Bearer ag-invalid-key-12345",
            "Content-Type": "application/json",
        },
        json={
            "model": ANTHROPIC_MODEL,
            "messages": [{"role": "user", "content": "This should fail."}],
        },
        timeout=10.0,
    )
    print(f"  Status: {resp.status_code} (expected 401)")
    print(f"  Error:  {resp.text[:150]}")

    # --- Scenario 4: List available models ---
    header("GET /v1/models — list available models")
    resp = httpx.get(
        f"{DASHBOARD_URL}/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=10.0,
    )
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        models = resp.json().get("data", [])
        print(f"  Available models: {len(models)}")
        for m in models[:5]:
            print(f"    - {m.get('id')}")
        if len(models) > 5:
            print(f"    ... and {len(models) - 5} more")

    pause(
        "Sessions tab: proxy sessions show up with virtual key metadata.\n"
        "  >> The invalid key request was rejected (no session created).\n"
        "  >> All successful calls went through Anthropic (Claude Haiku)."
    )

    wait_for_exit()


if __name__ == "__main__":
    main()
