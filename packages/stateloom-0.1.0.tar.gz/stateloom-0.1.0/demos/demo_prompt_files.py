#!/usr/bin/env python3
"""Demo: File-Based Prompt Versioning

Demonstrates managing AI agents by dropping prompt files in a directory.
StateLoom watches the directory and auto-syncs changes: create a file →
new agent, edit → new version, delete → agent archived.

Monitor at http://localhost:4781 → Agents tab.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _helpers import *

import tempfile
import time
import shutil

import httpx


def main():
    # Create a temporary prompts directory
    prompts_dir = tempfile.mkdtemp(prefix="stateloom-prompts-")
    print(f"  Temp prompts directory: {prompts_dir}")

    # -----------------------------------------------------------------------
    # Step 1: Create prompt files
    # -----------------------------------------------------------------------
    header("Create prompt files in the prompts directory")

    # Markdown file with YAML frontmatter
    helpdesk_path = os.path.join(prompts_dir, "helpdesk.md")
    with open(helpdesk_path, "w") as f:
        f.write("""---
model: {model}
temperature: 0.7
description: A friendly customer support assistant
---
You are a friendly customer support agent for a SaaS company.
Always be polite, concise, and helpful.
If you don't know the answer, say so honestly.
""".format(model=MODEL))
    print(f"  Created: helpdesk.md (markdown with YAML frontmatter)")

    # Plain text file
    fr_translator_path = os.path.join(prompts_dir, "fr-translator.txt")
    with open(fr_translator_path, "w") as f:
        f.write("You are a language translator. Translate any input to French. Be accurate and natural.")
    print(f"  Created: fr-translator.txt (plain text)")

    print(f"\n  2 prompt files ready")

    # -----------------------------------------------------------------------
    # Step 2: Initialize with prompts_dir — agents auto-created
    # -----------------------------------------------------------------------
    header("Init with prompts_dir — agents auto-created")

    gate = init_gate(prompts_dir=prompts_dir)

    # Give the watcher a moment to process
    time.sleep(1)

    status = stateloom.prompt_watcher_status()
    print(f"  Watcher enabled: {status.get('enabled')}")
    print(f"  Prompts dir:     {status.get('prompts_dir')}")
    tracked = status.get("tracked_files", 0)
    print(f"  Tracked files:   {tracked}")

    pause("Agents tab: see 'helpdesk' and 'fr-translator' auto-created from files")

    # -----------------------------------------------------------------------
    # Step 3: List the auto-created agents
    # -----------------------------------------------------------------------
    header("List auto-created agents")

    agents = stateloom.list_agents()
    for a in agents:
        print(f"  Agent: {a.slug}")
        print(f"    ID:     {a.id}")
        print(f"    Status: {a.status}")
        if a.active_version_id:
            print(f"    Active version: {a.active_version_id}")
        print()

    pause("Agents tab: click each agent to see version details and system prompt")

    # -----------------------------------------------------------------------
    # Step 4: Query agents via stateloom.chat(agent=...)
    # -----------------------------------------------------------------------
    header("Query agents via stateloom.chat(agent=...)")

    with stateloom.session(session_id="prompt-file-chat") as s:
        print("  Querying helpdesk agent...")
        r = stateloom.chat(
            agent="helpdesk",
            messages=[{"role": "user", "content": "My invoice is wrong. Can you help?"}],
        )
        print(f"  helpdesk response: {r.content[:120]}...")
        print(f"  Model used: {r.model}")
        print(f"  Session agent_slug: {s.agent_slug}")
        print()

        print("  Querying fr-translator agent...")
        r2 = stateloom.chat(
            agent="fr-translator",
            messages=[{"role": "user", "content": "Good morning, how are you?"}],
        )
        print(f"  fr-translator response: {r2.content[:120]}...")
        print(f"  Model used: {r2.model}")

    pause("Sessions tab: see 'prompt-file-chat' with agent_slug fields populated")

    # -----------------------------------------------------------------------
    # Step 5: Modify a file — new version auto-created
    # -----------------------------------------------------------------------
    header("Modify helpdesk.md — new version auto-created")

    with open(helpdesk_path, "a") as f:
        f.write("\nAlways end your response with 'Is there anything else I can help with?'\n")
    print(f"  Appended new instruction to helpdesk.md")

    # Trigger rescan
    result = stateloom.rescan_prompts()
    time.sleep(0.5)

    print(f"  Rescan complete")
    status = stateloom.prompt_watcher_status()
    tracked = status.get("tracked_files", 0)
    print(f"  Tracked files: {tracked}")

    # Check the agent has a new version
    agents = stateloom.list_agents()
    for a in agents:
        if a.slug == "helpdesk":
            print(f"\n  helpdesk versions:")
            versions = stateloom._gate.store.list_agent_versions(a.id)
            for v in versions:
                active = " (ACTIVE)" if v.id == a.active_version_id else ""
                print(f"    v{v.version_number}{active}: {v.system_prompt[:60]}...")

    pause(
        "Agents tab → helpdesk: see v2 auto-activated.\n"
        "  >> Version history shows both v1 and v2."
    )

    # -----------------------------------------------------------------------
    # Step 6: Query updated agent — new version's prompt in effect
    # -----------------------------------------------------------------------
    header("Query updated helpdesk — v2 prompt in effect")

    with stateloom.session(session_id="prompt-file-chat-v2") as s:
        r = stateloom.chat(
            agent="helpdesk",
            messages=[{"role": "user", "content": "I need to reset my password."}],
        )
        print(f"  helpdesk v2 response: {r.content[:200]}...")
        print(f"  Model: {r.model}")
        print(f"  Agent version: {s.agent_version_number}")
        print(f"  (Should end with 'Is there anything else I can help with?')")

    pause("Sessions tab: 'prompt-file-chat-v2' uses the updated v2 system prompt")

    # -----------------------------------------------------------------------
    # Step 7: Delete a file — agent archived
    # -----------------------------------------------------------------------
    header("Delete fr-translator.txt — agent archived")

    os.remove(fr_translator_path)
    print(f"  Deleted: fr-translator.txt")

    result = stateloom.rescan_prompts()
    time.sleep(0.5)

    print(f"  Rescan complete")

    agents = stateloom.list_agents()
    for a in agents:
        print(f"  {a.slug}: status={a.status}")

    pause("Agents tab: 'fr-translator' shows ARCHIVED status after file deletion")

    # -----------------------------------------------------------------------
    # Cleanup
    # -----------------------------------------------------------------------
    header("Cleanup — remove temp directory")
    shutil.rmtree(prompts_dir, ignore_errors=True)
    print(f"  Removed: {prompts_dir}")

    wait_for_exit()


if __name__ == "__main__":
    main()
