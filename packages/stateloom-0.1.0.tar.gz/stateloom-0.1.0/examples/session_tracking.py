"""Session-scoped tracking with StateLoom.

Shows how to use sessions to group related LLM calls.

Run:
    export OPENAI_API_KEY=your-key
    python examples/session_tracking.py
"""

import stateloom

stateloom.init()

import openai

client = openai.OpenAI()

# Session 1: Research task
with stateloom.session("research-task", budget=1.0) as s:
    client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "What are the top 3 Python web frameworks?"}],
    )
    client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Compare Flask and FastAPI in 2 sentences."}],
    )
    print(f"\nResearch session cost: ${s.total_cost:.4f}")
    print(f"Total tokens: {s.total_tokens}")
    print(f"Calls made: {s.call_count}")

# Session 2: Writing task
with stateloom.session("writing-task", budget=0.50) as s:
    client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Write a haiku about Python programming."}],
    )
    print(f"\nWriting session cost: ${s.total_cost:.4f}")

print("\nCheck the dashboard at http://localhost:4781 for session breakdown")
input("Press Enter to exit...")
stateloom.shutdown()
