"""Basic OpenAI usage with StateLoom.

Run:
    export OPENAI_API_KEY=your-key
    python examples/basic_openai.py
"""

import stateloom

# Initialize StateLoom — auto-patches OpenAI, starts dashboard
stateloom.init()

# Use OpenAI as normal — StateLoom intercepts transparently
import openai

client = openai.OpenAI()

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "user", "content": "What is the capital of France? Answer in one word."}
    ],
)

print(f"\nResponse: {response.choices[0].message.content}")
print(f"\nOpen http://localhost:4781 to see the dashboard")

# Make a few more calls to see cost tracking
for i in range(3):
    client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "user", "content": f"Count to {i + 1} in one line."}
        ],
    )

print("\nDone! Check the dashboard for session details.")
input("Press Enter to exit...")

stateloom.shutdown()
