"""PII detection with StateLoom.

Shows how StateLoom detects PII in prompts with v4 on_middleware_failure config.

Run:
    export OPENAI_API_KEY=your-key
    python examples/pii_detection.py
"""

import stateloom
from stateloom import PIIRule, FailureAction

# Enable PII detection with explicit on_middleware_failure for block-mode rules
stateloom.init(
    pii=True,
    pii_rules=[
        PIIRule(pattern="email", mode="audit"),
        PIIRule(pattern="credit_card", mode="block", on_middleware_failure=FailureAction.PASS),
        PIIRule(pattern="ssn", mode="block", on_middleware_failure=FailureAction.BLOCK),
    ],
)

import openai

client = openai.OpenAI()

# This prompt contains PII that StateLoom will detect
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {
            "role": "user",
            "content": (
                "Please help me draft an email to john@example.com "
                "about their order. Their card ending in 4111 1111 1111 1111 "
                "was charged $99.99."
            ),
        }
    ],
)

print(f"\nResponse: {response.choices[0].message.content[:200]}...")
print("\nCheck the PII Monitor at http://localhost:4781 for detection details")
input("Press Enter to exit...")
stateloom.shutdown()
