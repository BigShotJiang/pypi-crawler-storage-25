"""Basic Anthropic usage with StateLoom.

Run:
    export ANTHROPIC_API_KEY=your-key
    python examples/basic_anthropic.py
"""

import stateloom

# Initialize StateLoom — auto-patches Anthropic, starts dashboard
stateloom.init()

import anthropic

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=100,
    messages=[
        {"role": "user", "content": "What is the capital of France? Answer in one word."}
    ],
)

print(f"\nResponse: {response.content[0].text}")
print(f"\nOpen http://localhost:4781 to see the dashboard")

input("Press Enter to exit...")
stateloom.shutdown()
