"""Budget enforcement with StateLoom.

Shows how StateLoom enforces per-session budget limits with v4 on_middleware_failure.

Run:
    export OPENAI_API_KEY=your-key
    python examples/budget_enforcement.py
"""

import stateloom
from stateloom import StateLoomBudgetError

# Budget with hard_stop requires explicit on_middleware_failure
stateloom.init(
    budget=0.001,
    budget_on_middleware_failure="block",  # If budget middleware fails, block the call
)

import openai

client = openai.OpenAI()

# Create a session with a very small budget
try:
    with stateloom.session("budget-test", budget=0.001) as s:
        # First call might succeed
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Say hello"}],
        )
        print(f"Call 1 succeeded. Cost so far: ${s.total_cost:.4f}")

        # Second call should hit budget limit
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Say hello again"}],
        )
        print(f"Call 2 succeeded. Cost so far: ${s.total_cost:.4f}")

except StateLoomBudgetError as e:
    print(f"\nBudget enforced! {e}")
    print("The agent was stopped before exceeding the budget limit.")

stateloom.shutdown()
