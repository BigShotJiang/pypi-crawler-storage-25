"""
StateLoom Multi-Agent Debate: Claude (Driver) vs Gemini (Devil's Advocate)

Claude is the primary driver — it presents the StateLoom product concept
to Gemini for peer review. Gemini researches, critiques, and challenges
with supporting arguments. Claude agrees/disagrees and responds. The debate
continues until Gemini runs out of new objections or agrees, up to MAX_ROUNDS.

At the end, Claude writes a revised StateLoom product concept incorporating
all valid feedback from the debate.

Usage:
    export ANTHROPIC_API_KEY=your-key
    export GEMINI_API_KEY=your-key
    python debate.py

Output:
    - Live debate printed to terminal
    - debate_report.md — full transcript
    - StateLoom_Product_Concept_v4.md — revised concept by Claude
"""

import os
import sys
from pathlib import Path

import anthropic
from google import genai

# ---------------------------------------------------------------------------
# CONFIG — tweak these
# ---------------------------------------------------------------------------

MAX_ROUNDS = 10  # hard cap on back-and-forth rounds

CLAUDE_MODEL = "claude-sonnet-4-6"
GEMINI_MODEL = "gemini-3.1-pro-preview"

# Paths to the documents being debated
PRODUCT_CONCEPT_PATH = Path(__file__).parent / "StateLoom_Product_Concept_v3.md"
SDK_PLAN_PATH = Path(__file__).parent / "PLAN.md"

# ---------------------------------------------------------------------------
# PROMPTS — modify these to steer the debate
# ---------------------------------------------------------------------------

CLAUDE_SYSTEM_PROMPT = """\
You are the architect and primary driver of StateLoom — an agent-aware
middleware SDK for LLM-based agent systems. You deeply understand the
product vision, the technical architecture, and the market opportunity.

The ambition: build StateLoom into a billion-dollar company. The strategy
is to start with a proof-of-concept open-source Python SDK that developers
love, build community and adoption, then layer on enterprise features.
Think Datadog's playbook — open-source agent → massive enterprise business.
The POC SDK is the wedge. It needs to be so good that developers pull it
into their stack voluntarily, creating bottom-up demand inside companies.

Your role in this debate:
- You are presenting your product concept to a tough peer reviewer for feedback.
- When the reviewer raises valid points, acknowledge them openly and explain
  how you'd revise the concept.
- When criticism is off-base, push back with concrete evidence and reasoning.
- Keep a mental ledger of what you've conceded vs defended — you'll use this
  to write a revised product concept at the end.
- Always think through the lens of: what gets us to a POC that developers
  adopt, which grows into a platform that enterprises pay for?
- Also discuss about how are you going to make it as "zero-touch" as possible
  for developers.

Rules:
- Be honest and intellectually rigorous. Don't be defensive for ego's sake.
- Concede when the critic is right. Adapt the vision in real time.
- Push back hard when you genuinely disagree — with specifics, not hand-waving.
- Be open to NEW ideas from the reviewer. If they suggest a feature, angle,
  or strategy that's better than what you have, adopt it enthusiastically.
  The goal is the best possible product, not defending your original draft.
- Talk like an engineer, not a salesperson. No filler, no corporate-speak.
- Be concise — focus on substance.
"""

GEMINI_SYSTEM_PROMPT = """\
You are a sharp, experienced technical product reviewer and devil's advocate.
You've built and shipped developer tools, SDKs, and infrastructure products.
You've seen dozens of "middleware" products come and go. You've also seen
a few become billion-dollar companies — you know what separates the two.

Context: the StateLoom team wants to build a billion-dollar company starting
with a proof-of-concept open-source Python SDK. They're following the
classic open-source wedge strategy — get developers hooked with a free SDK,
then sell enterprise features. Think Datadog, HashiCorp, Grafana playbooks.

Your role: stress-test this vision end-to-end. Not just "is the tech sound?"
but "can this actually become a massive business?"

How to operate:
- Research and think deeply before critiquing. Back every point with concrete
  reasoning, real-world examples, or references to existing tools/competitors.
- Don't make shallow criticisms — dig into specifics. If you say "this won't
  work," explain exactly why with evidence.
- When the architect makes a strong counter-argument, acknowledge it honestly.
  Don't argue for the sake of arguing.
- Raise new concerns across rounds — don't rehash resolved points.
- Don't just critique — propose NEW ideas, features, or angles you think
  would make the product stronger or more viable. If you see a better
  wedge, a missing feature that developers would kill for, or a smarter
  GTM strategy, suggest it with conviction.

Focus areas:
- Market viability: Will developers actually adopt this? What's the real switching cost?
- Technical feasibility: What hard engineering problems are being underestimated?
- Competitive moat: Can LangFuse/LiteLLM/Portkey just add these features in a sprint?
- Scope: Is this trying to do too much for a POC? What should the POC nail vs defer?
- Developer experience: Will the integration actually be as frictionless as claimed?
- Differentiation: What's the one thing that makes this genuinely unique and defensible?
- Path to $1B: Is the open-source → enterprise playbook realistic here? What's the
  wedge? What's the expansion motion? Where does pricing power come from?
- POC strategy: Is the POC SDK scoped correctly to prove the thesis and get adoption?

Rules:
- Support every criticism with a concrete argument or example.
- When you run out of genuinely new objections, or when you're convinced
  on all major points, start your message with exactly "DEBATE_CONCLUDED"
  followed by your honest final assessment — what's strong, what's still
  weak, and whether you'd bet on this product.
"""

CLAUDE_OPENING_PROMPT = """\
I want you to present the following StateLoom product concept and SDK plan
to a peer reviewer for critical feedback. Frame it as a pitch — explain
the core insight, why this matters, what exists today and why it's
insufficient, and what you're proposing to build.

Here are the source documents:

## Product Concept

{product_concept}

## SDK Implementation Plan

{sdk_plan}

Now present this to the reviewer. Lead with the problem, then the solution.
Highlight what you think is genuinely novel. Be honest about what's risky.
Ask the reviewer to poke holes.
"""

GEMINI_REVIEW_PROMPT = """\
The StateLoom architect is presenting their product concept to you for
peer review. Read their pitch carefully, then deliver your initial critique.

Do your own research and thinking — consider what exists in the market,
what's been tried before, and what real developers actually struggle with.
Be comprehensive but prioritize your most impactful concerns. Hit the
biggest issues first.

## Architect's Pitch

{claude_message}
"""

CLAUDE_RESPOND_PROMPT = """\
Your peer reviewer has responded with the following critique of StateLoom.

Read each point carefully. For each concern:
- If it's valid: acknowledge it and explain specifically how you'd revise
  the product concept to address it.
- If you disagree: push back with concrete reasoning and evidence.
- If it's partially valid: say what part you accept and what part you don't.

Be direct and specific. No hand-waving.

## Reviewer's Critique

{gemini_message}
"""

GEMINI_FOLLOWUP_PROMPT = """\
The StateLoom architect has responded to your critique. Review their
response carefully, then:

1. Push back on points where their defense is unconvincing (with NEW
   arguments or deeper analysis — don't just repeat yourself)
2. Raise any NEW concerns you haven't mentioned yet
3. Honestly acknowledge where they've made strong counter-arguments
   that changed your mind

If you have no genuinely new objections and are satisfied with their
responses on all major points, start your message with exactly
"DEBATE_CONCLUDED" and give your honest final assessment.

## Architect's Response

{claude_message}
"""

CLAUDE_REVISION_PROMPT = """\
The debate with your peer reviewer is now complete. Here is the full
transcript of the discussion:

{debate_transcript}

Now write a **revised StateLoom product concept** that incorporates all
the valid feedback from the debate. This should be a complete, standalone
document — not a diff or a list of changes.

Guidelines:
- Keep what survived the debate intact.
- Incorporate concessions you made — update the concept to reflect them.
- Cut or de-scope things the reviewer convinced you to drop.
- Strengthen areas the reviewer identified as weak.
- Add anything new that emerged from the discussion.
- Be honest about risks and open questions that remain unresolved.
- This is the document you'd share with your engineering team to start
  building. Make it crisp, specific, and actionable.

Write the full revised product concept in markdown.
"""

# ---------------------------------------------------------------------------
# DEBATE ENGINE
# ---------------------------------------------------------------------------


def load_documents() -> tuple[str, str]:
    """Load the product concept and SDK plan."""
    product_concept = PRODUCT_CONCEPT_PATH.read_text()

    if SDK_PLAN_PATH.exists():
        sdk_plan = SDK_PLAN_PATH.read_text()
    else:
        sdk_plan = "(No SDK plan document found)"

    return product_concept, sdk_plan


def call_gemini(client: genai.Client, messages: list[dict], system: str) -> str:
    """Call Gemini with conversation history."""
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=messages,
        config=genai.types.GenerateContentConfig(
            system_instruction=system,
            temperature=0.7,
        ),
    )
    return response.text


def call_claude(client: anthropic.Anthropic, messages: list[dict], system: str) -> str:
    """Call Claude with conversation history."""
    response = client.messages.create(
        model=CLAUDE_MODEL,
        max_tokens=8192,
        system=system,
        messages=messages,
    )
    return response.content[0].text


def summarize_message(message: str) -> str:
    """Extract a compact summary from a debate message."""
    lines = message.strip().splitlines()
    key_points = []
    for line in lines:
        stripped = line.strip()
        # Grab markdown headers and bullet points as key points
        if stripped.startswith(("# ", "## ", "### ", "- **", "* **", "- ", "* ")):
            # Clean up to just the text
            clean = stripped.lstrip("#-* ").strip()
            if clean and len(clean) > 10:
                key_points.append(clean)
    # If we didn't find structured points, grab the first few sentences
    if not key_points:
        sentences = message.replace("\n", " ").split(". ")
        key_points = [s.strip() + "." for s in sentences[:5] if s.strip()]
    # Cap at 8 key points
    return key_points[:8]


LIVE_OUTPUT_PATH = Path(__file__).parent / "debate_live_v4.md"


def print_round(round_num: int, speaker: str, message: str):
    """Print a compact summary to terminal and append full text to live output file."""
    separator = "=" * 70
    word_count = len(message.split())

    # Terminal: compact summary
    print(f"\n{separator}")
    print(f"  ROUND {round_num} — {speaker} ({word_count} words)")
    print(f"{separator}")
    points = summarize_message(message)
    for i, point in enumerate(points, 1):
        display = point if len(point) <= 100 else point[:97] + "..."
        print(f"  {i}. {display}")
    print(f"\n  (Full text in debate_live.md)")
    print()

    # File: append full text as it happens
    with open(LIVE_OUTPUT_PATH, "a") as f:
        f.write(f"\n{'=' * 70}\n")
        f.write(f"## Round {round_num} — {speaker}\n\n")
        f.write(message)
        f.write(f"\n\n")


def run_debate():
    """Run the multi-agent debate."""

    # --- Validate keys ---
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ERROR: Set ANTHROPIC_API_KEY environment variable")
        sys.exit(1)
    if not os.environ.get("GEMINI_API_KEY"):
        print("ERROR: Set GEMINI_API_KEY environment variable")
        sys.exit(1)

    # --- Init clients ---
    claude_client = anthropic.Anthropic()
    gemini_client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])

    # --- Load docs ---
    product_concept, sdk_plan = load_documents()

    print("\n" + "=" * 70)
    print("  STATELOOM DEBATE: Claude (Driver) vs Gemini (Devil's Advocate)")
    print(f"  Max rounds: {MAX_ROUNDS}")
    print("=" * 70)

    # Initialize live output file (fresh each run)
    with open(LIVE_OUTPUT_PATH, "w") as f:
        f.write("# StateLoom Debate — Live Output\n\n")

    # --- Track full conversation for each agent ---
    claude_messages = []
    gemini_messages = []

    # --- Track debate for the report ---
    debate_log = []
    round_num = 0
    concluded = False

    # --- Round 1: Claude presents the product concept ---
    round_num += 1
    opening = CLAUDE_OPENING_PROMPT.format(
        product_concept=product_concept,
        sdk_plan=sdk_plan,
    )
    claude_messages.append({"role": "user", "content": opening})

    print("\n  Claude is presenting the StateLoom concept...")
    claude_response = call_claude(claude_client, claude_messages, CLAUDE_SYSTEM_PROMPT)
    claude_messages.append({"role": "assistant", "content": claude_response})

    print_round(round_num, "CLAUDE (Presenting)", claude_response)
    debate_log.append(("Claude", round_num, claude_response))

    # --- Round 2: Gemini delivers initial critique ---
    round_num += 1
    review_prompt = GEMINI_REVIEW_PROMPT.format(claude_message=claude_response)
    gemini_messages.append({"role": "user", "parts": [{"text": review_prompt}]})

    print("  Gemini is researching and preparing critique...")
    gemini_response = call_gemini(gemini_client, gemini_messages, GEMINI_SYSTEM_PROMPT)
    gemini_messages.append({"role": "model", "parts": [{"text": gemini_response}]})

    print_round(round_num, "GEMINI (Devil's Advocate)", gemini_response)
    debate_log.append(("Gemini", round_num, gemini_response))

    if gemini_response.strip().startswith("DEBATE_CONCLUDED"):
        concluded = True

    # --- Subsequent rounds: Claude responds, Gemini follows up ---
    while not concluded and round_num < MAX_ROUNDS:
        round_num += 1

        # Claude responds to Gemini's critique
        respond_prompt = CLAUDE_RESPOND_PROMPT.format(gemini_message=gemini_response)
        claude_messages.append({"role": "user", "content": respond_prompt})

        print("  Claude is responding...")
        claude_response = call_claude(
            claude_client, claude_messages, CLAUDE_SYSTEM_PROMPT
        )
        claude_messages.append({"role": "assistant", "content": claude_response})

        print_round(round_num, "CLAUDE (Responding)", claude_response)
        debate_log.append(("Claude", round_num, claude_response))

        # Check if we've hit max rounds
        if round_num >= MAX_ROUNDS:
            print(f"\n  [Max rounds ({MAX_ROUNDS}) reached. Ending debate.]\n")
            break

        round_num += 1

        # Gemini follows up
        followup = GEMINI_FOLLOWUP_PROMPT.format(claude_message=claude_response)
        gemini_messages.append({"role": "user", "parts": [{"text": followup}]})

        print("  Gemini is considering the response...")
        gemini_response = call_gemini(
            gemini_client, gemini_messages, GEMINI_SYSTEM_PROMPT
        )
        gemini_messages.append({"role": "model", "parts": [{"text": gemini_response}]})

        print_round(round_num, "GEMINI (Devil's Advocate)", gemini_response)
        debate_log.append(("Gemini", round_num, gemini_response))

        if gemini_response.strip().startswith("DEBATE_CONCLUDED"):
            concluded = True

    # --- Generate debate report ---
    report = generate_report(debate_log, concluded, round_num)
    report_path = Path(__file__).parent / "debate_report_v4.md"
    report_path.write_text(report)
    print(f"\n  Debate transcript saved to: {report_path}")

    # --- Claude writes revised product concept ---
    print("\n" + "=" * 70)
    print("  Claude is writing the revised StateLoom product concept...")
    print("=" * 70)

    debate_transcript = "\n\n---\n\n".join(
        f"### Round {r} — {speaker}\n\n{msg}" for speaker, r, msg in debate_log
    )

    revision_prompt = CLAUDE_REVISION_PROMPT.format(
        debate_transcript=debate_transcript
    )
    # Fresh message list for the revision — full context in the prompt itself
    revision_messages = [{"role": "user", "content": revision_prompt}]

    revised_concept = call_claude(
        claude_client, revision_messages, CLAUDE_SYSTEM_PROMPT
    )

    revised_path = Path(__file__).parent / "StateLoom_Product_Concept_v4.md"
    revised_path.write_text(revised_concept)

    print(f"\n  Revised product concept saved to: {revised_path}")

    print("\n" + "=" * 70)
    print(f"  DEBATE COMPLETE — {round_num} rounds")
    print(f"  Outputs:")
    print(f"    - {report_path}")
    print(f"    - {revised_path}")
    print("=" * 70 + "\n")


def generate_report(
    debate_log: list[tuple[str, int, str]], concluded: bool, total_rounds: int
) -> str:
    """Generate a markdown report of the debate."""
    lines = [
        "# StateLoom Debate Report",
        "",
        f"**Rounds:** {total_rounds}",
        f"**Outcome:** {'Gemini conceded / ran out of objections' if concluded else f'Hit max rounds ({MAX_ROUNDS})'}",
        f"**Claude model:** {CLAUDE_MODEL}",
        f"**Gemini model:** {GEMINI_MODEL}",
        "",
        "---",
        "",
    ]

    for speaker, round_num, message in debate_log:
        icon = "🔴" if speaker == "Gemini" else "🔵"
        lines.append(f"## Round {round_num} — {icon} {speaker}")
        lines.append("")
        lines.append(message)
        lines.append("")
        lines.append("---")
        lines.append("")

    return "\n".join(lines)


if __name__ == "__main__":
    run_debate()
