# CLAUDE.md — StateLoom

This file provides context for AI assistants working on the StateLoom codebase.

## What is StateLoom?

A stateful AI gateway that sits between your application and LLM providers. It provides session-aware middleware for cost tracking, PII detection, guardrails (prompt injection/jailbreak detection via 32 heuristic patterns + NLI classifier + Llama-Guard, system prompt leak protection), budget enforcement, loop detection, caching (exact-match + semantic similarity), A/B experiments, time-travel debugging, durable resumption (Temporal-like checkpointing), semantic retries (self-healing), local model support (Ollama), shadow drafting, intelligent auto-routing, global kill switch, blast radius containment, priority-aware rate limiting with request queueing, managed agent definitions (Prompts-as-an-API), file-based prompt versioning (watchdog), circuit breaker (provider failover), compliance enforcement (GDPR/HIPAA/CCPA), session suspension (human-in-the-loop), async jobs with webhooks, billing mode detection (API vs subscription cost tracking), HTTP reverse proxy passthrough (transparent auth forwarding for subscription users), Anthropic-native and Gemini-native proxy endpoints, OpenAI Responses API proxy (Codex CLI support via HTTP + WebSocket), sticky sessions, proxy-level per-key rate limiting, multi-tenant hierarchy (Org/Team), OAuth2/OIDC authentication with RBAC (five-tier role hierarchy, JWT, OIDC federation, VK scope enforcement, end-user attribution), observability (Prometheus metrics, OpenTelemetry tracing, alerting), NER-based PII detection, multi-agent consensus (vote, debate, self-consistency strategies with budget-constrained multi-round debate, greedy model downgrade, and adapter-level confidence extraction), and zero-trust security engine (CPython audit hooks for interpreter-level operation interception, in-memory secret vault with environ scrubbing). It auto-patches OpenAI, Anthropic, Gemini, Cohere, Mistral, and LiteLLM SDKs with zero config.

## Repository Layout

```
src/stateloom/
  __init__.py              # Public API: init(), session(), wrap(), tool(), replay(), durable_task(), retry_loop(), experiments, create_agent(), consensus(), etc.
  _version.py              # Package version
  chat.py                  # Unified Client and chat() API — provider-agnostic interface with BYOK provider_keys support
  gate.py                  # Gate class — singleton orchestrator, owns pipeline/store/pricing/sessions
  retry.py                 # Semantic retries: RetryLoop, RetryAttempt, durable_task() decorator
  mock.py                  # VCR-cassette MockSession — record once, replay forever for zero-cost testing
  concurrency.py           # patch_threading() for session context propagation

  core/
    config.py              # StateLoomConfig (pydantic-settings), PIIRule, KillSwitchRule, GuardrailMode, nested config views (GuardrailsConfig, CacheConfig, SecurityConfig, etc.)
    session.py             # Session dataclass — typed fields (billing_mode, durable, agent_id/slug/version, agent_name, transport), accumulators for cost, tokens, steps, parent-child, timeout, cancellation, suspension, end_user, guardrail_detections
    event.py               # Event hierarchy: LLMCallEvent, ToolCallEvent, CacheHitEvent, PIIDetectionEvent, GuardrailEvent, LocalRoutingEvent, RateLimitEvent, SemanticRetryEvent, CheckpointEvent, etc.
    errors.py              # Exception hierarchy: StateLoomBudgetError, StateLoomPIIBlockedError, StateLoomGuardrailError, StateLoomRateLimitError, StateLoomRetryError, StateLoomTimeoutError, StateLoomCancellationError, StateLoomAuthError, StateLoomPermissionError, etc.
    types.py               # Enums: Provider, SessionStatus (incl. TIMED_OUT, CANCELLED), EventType (incl. CHECKPOINT, GUARDRAIL), PIIMode, BudgetAction, AgentStatus, BillingMode, GuardrailMode, Role, etc.
    context.py             # ContextVars: session, session_id, replay_engine (async/thread-safe)
    pricing.py             # (re-export from pricing/)
    job.py                 # Job dataclass for async job API (status, webhook, result, retry, TTL)
    organization.py        # Organization and Team models for multi-tenant hierarchy

  auth/
    __init__.py            # Package exports
    models.py              # User, UserTeamRole Pydantic v2 models (usr-/utr- prefixes)
    permissions.py         # Permission enum, Role→Permission mapping, check_permission(), resolve_permissions()
    password.py            # hash_password(), verify_password() — argon2 preferred, PBKDF2 stdlib fallback
    jwt.py                 # TokenPayload, create_access_token(), create_refresh_token(), decode_access_token()
    endpoints.py           # Auth endpoints: bootstrap, login, refresh, logout, me, change-password, OIDC callback/link, device flow
    dependencies.py        # require_permission() FastAPI dependency for RBAC on dashboard endpoints
    oidc_models.py         # OIDCProvider model (issuer, client_id/secret, group_claim, group_role_mapping)
    oidc.py                # OIDCClient — discovery, authorization URL (PKCE), code exchange, ID token validation

  agent/
    __init__.py            # Package exports: Agent, AgentVersion, validate_slug, resolve_agent, apply_agent_overrides, PromptFileContent, parse_prompt_file
    models.py              # Agent, AgentVersion dataclasses, slug validation, AgentStatus enum usage
    resolver.py            # resolve_agent() — lookup by slug/ID, status checks, VK scoping; apply_agent_overrides() — model override, system prompt prepend, request_overrides merge
    prompt_file.py         # Prompt file parser — .md (YAML frontmatter), .yaml/.yml, .txt → PromptFileContent
    prompt_watcher.py      # Watchdog-based file watcher — syncs prompt files to agents via gate API

  middleware/
    base.py                # MiddlewareContext dataclass, Middleware protocol
    pipeline.py            # Pipeline class — builds and executes the middleware chain
    pii_scanner.py         # PIIScannerMiddleware — scan/redact/block PII in requests, two-phase dedup (Phase 1: strip previously-blocked, Phase 2: scan new)
    budget_enforcer.py     # BudgetEnforcer — hard stop or warn on budget exceed
    cache.py               # CacheMiddleware — exact-match per-session caching
    loop_detector.py       # LoopDetector — detect repeated requests
    cost_tracker.py        # CostTracker — extract tokens, calculate cost, create LLMCallEvent, detect tool continuations
    latency_tracker.py     # LatencyTracker — record call latency
    event_recorder.py      # EventRecorder — persist events + session to store
    console_output.py      # ConsoleOutput — rich terminal one-liner per call
    experiment.py          # ExperimentMiddleware — apply variant overrides (model, params, system prompt)
    shadow.py              # ShadowMiddleware — fire-and-forget shadow drafting with local models
    auto_router.py         # AutoRouterMiddleware — intelligent auto-routing to local models
    semantic_router.py     # SemanticComplexityClassifier — zero-shot NLI complexity scoring (sentence-transformers)
    similarity.py          # SimilarityResult, compute_similarity() — cloud vs local response comparison (difflib)
    response_converter.py  # Convert OllamaResponse → provider-native SDK objects
    kill_switch.py         # KillSwitchMiddleware — global/granular emergency stop with rule matching
    blast_radius.py        # BlastRadiusMiddleware — auto-pause sessions/agents on repeated failures
    rate_limiter.py        # RateLimiterMiddleware — per-team TPS limits with priority-aware request queueing
    timeout_checker.py     # TimeoutCheckerMiddleware — session timeout, idle timeout, and cancellation checking
    circuit_breaker.py     # CircuitBreakerMiddleware — provider failover with tier-based fallback and health probes
    guardrails.py          # GuardrailMiddleware — prompt injection, jailbreak, system prompt leak detection (heuristic + Llama-Guard + output scanning)
    compliance.py          # ComplianceMiddleware — declarative GDPR/HIPAA/CCPA enforcement with audit events
    precompute.py          # PrecomputeMiddleware — parallel background semantic complexity scoring

  intercept/
    provider_adapter.py    # ProviderAdapter protocol, BaseProviderAdapter base class, PatchTarget, TokenFieldMap, _extract_tokens_from_fields(), _openai_style_to_dict(), _unwrap_client()
    provider_registry.py   # Adapter registry: register_adapter(), get_adapter(), get_all_adapters()
    generic_interceptor.py # patch_provider(), wrap_instance() — provider-agnostic interception
    auto_patch.py          # auto_patch() — detect installed SDKs and patch them
    unpatch.py             # Teardown registry for clean shutdown
    adapters/
      openai_adapter.py    # OpenAI adapter (chat.completions.create)
      anthropic_adapter.py # Anthropic adapter (messages.create)
      gemini_adapter.py    # Gemini adapter (generate_content)
      cohere_adapter.py    # Cohere adapter (V2Client.chat)
      litellm_adapter.py   # LiteLLM adapter (litellm.completion)
      mistral_adapter.py   # Mistral adapter (Chat.complete)
    openai_patch.py        # Legacy OpenAI-specific interceptor (still importable/tested)
    anthropic_patch.py     # Legacy Anthropic-specific interceptor
    gemini_patch.py        # Legacy Gemini-specific interceptor

  local/
    __init__.py            # Package exports: OllamaClient, OllamaAdapter, detect_hardware, recommend_models
    client.py              # OllamaClient — httpx-based Ollama HTTP client, RequestTranslator
    adapter.py             # OllamaAdapter — BaseProviderAdapter for local models (no SDK patching)
    hardware.py            # HardwareInfo, detect_hardware(), recommend_models() — hardware-aware suggestions
    models.py              # MODEL_CATALOG — curated list of Ollama models by tier

  consensus/
    __init__.py            # Package exports: ConsensusConfig, ConsensusResult, DebateRound, DebaterResponse, ConsensusOrchestrator
    models.py              # ConsensusConfig dataclass, DebaterResponse/DebateRound/ConsensusResult Pydantic models
    prompts.py             # Prompt templates: DEFAULT_CONFIDENCE_INSTRUCTION, VOTE_SYSTEM_PROMPT, DEBATE_ROUND_TEMPLATE, JUDGE_SYNTHESIS_TEMPLATE
    confidence.py          # Adapter-aware confidence extraction: get_confidence_instruction(), extract_confidence()
    aggregation.py         # Aggregation functions: majority_vote(), confidence_weighted(), judge_synthesis(), compute_agreement()
    orchestrator.py        # ConsensusOrchestrator — main entry point, durable parent session, event recording
    strategies/
      __init__.py          # Strategy registry: get_strategy(), ConsensusStrategyProtocol
      vote.py              # VoteStrategy — all models answer independently in parallel, aggregate
      debate.py            # DebateStrategy — multi-round debate with early stop, greedy downgrade, judge synthesis
      self_consistency.py  # SelfConsistencyStrategy — multiple samples from one model, majority vote

  experiment/
    models.py              # Experiment, VariantConfig, ExperimentAssignment, SessionFeedback
    assigner.py            # ExperimentAssigner — random/hash/manual variant assignment
    manager.py             # ExperimentManager — create/start/pause/conclude, metrics, leaderboard
    backtest.py            # BacktestRunner — replay sessions with variant configs

  replay/
    engine.py              # ReplayEngine — mock steps with cached responses, ContextVar-based; DurableReplayEngine — lightweight replay for durable session resumption
    network_blocker.py     # NetworkBlocker — patch httpx/requests/urllib3, block outbound HTTP
    schema.py              # StepRecordSchema, SessionRecord — serialization for replay
    step.py                # StepRecord dataclass — recorded step model for replay
    safety.py              # Pre-replay safety checks (side-effecting tools)

  guardrails/
    __init__.py            # Package exports
    patterns.py            # 32 heuristic regex patterns for prompt injection/jailbreak detection (GuardrailPattern, scan_text)
    nli_classifier.py      # NLIInjectionClassifier — zero-shot CrossEncoder semantic scoring (sentence-transformers, opt-in)
    local_validator.py     # LocalGuardrailValidator — Llama-Guard 3 via OllamaClient, auto-pull, fail-open
    output_scanner.py      # SystemPromptLeakScanner — sliding window substring + SequenceMatcher leak detection
    validators.py          # GuardrailResult dataclass, GuardrailValidator protocol (enterprise API stub)

  pii/
    scanner.py             # PIIScanner — regex-based fast scanning
    patterns.py            # PII_PATTERNS dict, PATTERN_GROUPS, Luhn validation for credit cards
    rehydrator.py          # PIIRehydrator — redact placeholders, rehydrate originals
    ner_detector.py        # NER-based PII detector using GLiNER for zero-shot entity recognition
    stream_buffer.py       # Stream PII buffer — hold back chunks for scanning before release

  cache/
    base.py                # CacheEntry, CacheStore protocol for pluggable backends
    normalizer.py          # Request normalization — strip dynamic elements for cache key hashing
    semantic.py            # Semantic similarity matching via sentence-transformers embeddings
    vector_backend.py      # Vector storage backend protocol (supports FAISS)
    memory_store.py        # In-memory cache store
    sqlite_store.py        # SQLite-backed cache store
    redis_store.py         # Redis-backed cache store
    redis_vector_backend.py # Redis Vector Search backend (RediSearch KNN)

  compliance/
    audit.py               # SHA-256 audit hash for tamper-proof compliance records
    legal_rules.py         # Legal rule mappings (GDPR/HIPAA/CCPA) with article citations
    profiles.py            # Compliance profile factory functions (GDPR, HIPAA, CCPA presets)
    purge.py               # Purge engine for "Right to Be Forgotten" data deletion

  security/
    __init__.py            # Package exports: AuditHookManager, SecretVault
    audit_hook.py          # CPython audit hook manager (PEP 578) — intercept open/socket/subprocess/exec at interpreter level
    vault.py               # In-memory secret vault — move API keys out of os.environ, optional scrub

  jobs/
    processor.py           # Background job processor with ThreadPoolExecutor
    queue.py               # Pluggable job queue protocol (Kafka, Redis Streams, SQS)
    webhook.py             # Webhook delivery with HMAC-SHA256 and exponential backoff
    redis_queue.py         # Redis Streams-backed job queue (XADD/XREADGROUP/XACK)

  observability/
    collector.py           # Prometheus metrics collector with dedicated registry
    aggregator.py          # Time-series aggregation from persisted events
    alerting.py            # AlertManager for webhook-based alerts
    tracing.py             # Optional OpenTelemetry distributed tracing integration

  store/
    base.py                # Store protocol (sessions, events, experiments, feedback, agents, users, team roles, refresh tokens, OIDC providers)
    memory_store.py        # In-memory store (thread-safe, good for testing)
    sqlite_store.py        # SQLite store (WAL mode, indexed, atomic operations)
    postgres_store.py      # Postgres store (asyncpg, same generic event serialization as SQLite)

  pricing/
    registry.py            # PricingRegistry — bundled prices.json + custom model registration
    data/prices.json       # Bundled model pricing data

  dashboard/
    server.py              # DashboardServer — FastAPI on background daemon thread, dual-mode auth middleware (JWT + legacy API key)
    api.py                 # REST routes: /api/sessions, /api/experiments, /api/stats, /api/kill-switch, /api/blast-radius, /api/rate-limiter, /api/agents, /api/consensus-runs, etc.
    user_api.py            # User management REST API: CRUD users, team role assignment (requires ADMIN_USERS permission)
    observability_api.py   # Observability REST API (timeseries, latency percentiles)
    ws.py                  # WebSocket real-time event streaming
    static/                # Frontend assets (if present)

  proxy/
    __init__.py            # Package exports
    passthrough.py         # HTTP reverse proxy engine — httpx-based forwarding to upstream APIs, header filtering, auth passthrough
    router.py              # FastAPI router: /chat/completions, /agents/{ref}/chat/completions, /models — dual-path: HTTP passthrough for OpenAI models, Client fallback for cross-provider and agents
    anthropic_native.py    # Anthropic-native /v1/messages endpoint — HTTP passthrough with middleware pipeline, legacy Client fallback
    gemini_native.py       # Gemini-native /v1beta/models/{model}:generateContent endpoint — HTTP passthrough with middleware pipeline, legacy Client fallback
    auth.py                # ProxyAuth, AuthResult, _StubKey, authenticate_request(), enforce_vk_policies(), strip_bearer() — unified proxy auth, VK scope enforcement, provider key resolution, end-user sanitization
    virtual_key.py         # VirtualKey dataclass (incl. agent_ids scoping, billing_mode), generate/hash/preview helpers
    billing.py             # Billing mode detection — infer API vs subscription from BYOK key format
    sticky_session.py      # StickySessionManager — client fingerprint (IP + UA hash) to session ID mapping
    rate_limiter.py        # ProxyRateLimiter — per-virtual-key TPS rate limiting for proxy gateway
    responses.py           # OpenAI Responses API proxy (/v1/responses) — HTTP POST + WebSocket, Codex CLI support, ChatGPT OAuth routing, zstd body decompression, middleware-blocked response synthesis, _WSRelayState, _strip_synthetic_ids(), _run_ws_middleware()
    stream_helpers.py      # SSE_HEADERS constant, passthrough_stream_relay() shared async streaming helper
    errors.py              # Proxy-specific error mapping (StateLoomError → OpenAI error format)
    response_format.py     # Convert provider responses to OpenAI completion format, SSE event helpers

  cli/
    main.py                # Click CLI entry point — stateloom command group
    login_command.py       # `stateloom login` — email/password prompt, saves JWT to ~/.stateloom/credentials.json
    stats_command.py       # `stateloom stats` — display gateway statistics
    tail_command.py        # `stateloom tail` — live event tail
    doctor_command.py      # `stateloom doctor` — diagnostic checks
    ollama_commands.py     # `stateloom ollama` — local model management

  ext/
    langchain.py           # StateLoomCallbackHandler for LangChain
    langgraph.py           # LangGraph callback handler

  export/
    console.py             # Console output formatting (Rich)
```

## Key Architecture Decisions

### Middleware Pipeline
Requests flow through an ordered chain of middleware. Each middleware receives a `MiddlewareContext` and a `call_next` callable. The chain order is set in `Gate._setup_middleware()`. Middleware can modify context before/after the LLM call or short-circuit (e.g., cache sets `skip_call=True`).

**Session lifecycle hooks**: Middleware may implement an optional `on_session_end(session_id: str)` method to clean up per-session in-memory state when a session exits. `Pipeline.notify_session_end(session_id)` dispatches to all middleware that implement this hook — exceptions are swallowed (cleanup must not crash). This is called automatically in `Gate.session()` and `Gate.async_session()` `finally` blocks, along with `_tool_call_counts.pop()`.

**Lock hierarchy**: Each middleware manages its own locks independently — no cross-middleware lock acquisition occurs, so no deadlock risk. Lock comments are documented inline:
- `circuit_breaker.py` — `_circuits_lock` → `_CircuitState._lock` (always this order)
- `blast_radius.py` — single `_lock` guards all tracking dicts
- `rate_limiter.py` — per-bucket lock (no cross-bucket locking)
- `loop_detector.py` — single `_lock` guards `_counts` dict
- `auto_router.py` — `_stats_lock` guards `_stats` dict only (no nesting)

**Dual event persistence**: Some middleware (`kill_switch.py`, `blast_radius.py`, `rate_limiter.py`, `pii_scanner.py`, `guardrails.py`) persist events directly via `store.save_event()` before raising exceptions. This bypasses `EventRecorder`, which only runs on successful pipeline completion. There is no duplication risk — the exception prevents `EventRecorder` from processing `ctx.events`.

### Provider Adapter Pattern
LLM providers are abstracted via `ProviderAdapter` protocol. Each adapter defines patch targets, token extraction, and streaming logic. The generic interceptor (`generic_interceptor.py`) handles the actual monkey-patching and middleware pipeline invocation in a provider-agnostic way.

**Token extraction**: Centralized via `TokenFieldMap` dataclass and `_extract_tokens_from_fields()` on `BaseProviderAdapter`. Each adapter declares a module-level `_TOKEN_FIELDS` with provider-specific field names (e.g., `input_field="input_tokens"` for Anthropic, `usage_attr="usage_metadata"` for Gemini, `nested_attr="tokens"` for Cohere). Ollama adapter is the exception — uses `isinstance` check due to structurally different response format.

**Response conversion**: `_openai_style_to_dict()` on `BaseProviderAdapter` provides shared OpenAI-style response-to-dict conversion, handling optional `.data` wrapper (Mistral). Adapters with `model_dump()` support (OpenAI) use it as a fast path and fall back to this shared method.

**Client unwrapping**: `_unwrap_client()` static method on `BaseProviderAdapter` walks the `_client` chain to reach the innermost SDK client (e.g., OpenAI's `AsyncOpenAI._client._client`). Bounded to `_MAX_UNWRAP_DEPTH = 10` to prevent infinite loops from circular references. Used by `generic_interceptor.py` (API key injection), `openai_adapter.py` (base URL extraction), and `anthropic_adapter.py` (base URL extraction).

### Provider Enum
`Provider(str, Enum)` in `core/types.py` defines `OPENAI`, `ANTHROPIC`, `GEMINI`, `LOCAL`, `UNKNOWN`. Since it extends `str`, `Provider.OPENAI == "openai"` is `True` — fully backward-compatible. Adapter `name` properties and internal comparisons use the enum. Custom providers use plain strings (not in the enum).

### Fail-Open Philosophy
Observability middleware (cost tracking, latency, console output) is fail-open by default — errors never break user LLM calls. Security middleware (PII block, budget hard-stop) requires explicit `on_middleware_failure` config to be clear about failure behavior.

**Exception handler logging guidelines**: Every `except Exception` block must log, never silently `pass`:
- **CRITICAL path** (security bypass, data loss): Use `logger.warning(message, exc_info=True)`. If the handler guards a security boundary (e.g., PII pre-scan in shadow), **fail closed** (assume the dangerous condition is true).
- **Observability path** (cost tracking, event recording, retry events): Use `logger.warning(message, exc_info=True)` — silent loss of dashboard data should be visible in logs.
- **Reconstruction fallbacks** (replay schema, SDK object reconstruction): Use `logger.debug(message)` — these fire routinely when optional SDKs aren't installed.
- **Cleanup paths** (session end, webhook fire): Use `pass` only when the exception is truly expected and harmless (e.g., closing an already-closed socket).

### Context Vars for Concurrency
Session state, session ID, and replay engine use `contextvars.ContextVar` for async/thread-safe propagation. No global mutable state.

### Shadow Drafting (Fire-and-Forget)
`ShadowMiddleware` runs a local Ollama model in parallel with every cloud call. It sits at position 1 in the chain (after ExperimentMiddleware, before PII). The shadow call is launched fire-and-forget (`asyncio.ensure_future` or `ThreadPoolExecutor.submit`) — the cloud call is never delayed. Shadow results are persisted as `ShadowDraftEvent` directly via `store.save_event()` (not through `ctx.events`, since the pipeline has flushed by the time the shadow completes). Console output for shadow events is printed directly by the middleware, not by `ConsoleOutput`.

**PII safety**: The PII pre-scan (`_has_pii_risk()`) **fails closed** — if the scan raises an exception, it assumes PII is present and skips the shadow call. This prevents accidental PII leakage to the local model. Shadow thread errors are logged at `WARNING` level with full stack traces for operational visibility.

### Local Model Support
Ollama integration lives in `local/`. The `OllamaClient` talks to Ollama's HTTP API (`/api/chat`, `/api/tags`, `/api/pull`, etc.) using httpx. `RequestTranslator` converts any provider's request kwargs to Ollama format. `OllamaAdapter` implements `BaseProviderAdapter` but returns no patch targets (no SDK to monkey-patch). Hardware detection (`detect_hardware()`) and model recommendations (`recommend_models()`) use only stdlib + optional `psutil`.

### Auto-Routing (SmartRouter)
`AutoRouterMiddleware` sits after cache/loop detection and before cost tracking. It auto-enables when `local_model` is set in `init()` (tri-state `auto_route`: `None`=auto, `True`=force on, `False`=force off). Complexity is scored via two methods: **semantic** (preferred) uses `SemanticComplexityClassifier` (zero-shot NLI via `sentence-transformers` CrossEncoder, lazy-init, thread-safe); **heuristic** (fallback) uses weighted signals (token count, conversation depth, message count, max message length, system prompt presence, model tier). Budget pressure (kicks in at 50% spend) lowers the routing threshold. Historical learning tracks success/failure rates per cloud model and adjusts thresholds (cold start: <5 data points → no adjustment). On startup, `_load_historical_stats()` queries persisted `LocalRoutingEvent`s from the store via `get_session_events("")` (cross-session query) to seed the stats, so learning persists across process restarts. When the complexity score falls in the uncertain zone (between threshold and floor), an optional probe asks the local model to self-assess confidence. On routing, `response_converter.py` converts `OllamaResponse` to provider-native SDK objects (`ChatCompletion`, `Message`, or Gemini proxy). On any failure, the middleware silently falls back to cloud. Routing events are recorded as `LocalRoutingEvent` and appended to `ctx.events` (processed by downstream EventRecorder/ConsoleOutput). Unlike ShadowMiddleware, AutoRouter is synchronous and blocking — it must complete before the pipeline continues.

**Realtime data guard**: Before complexity scoring, `_REALTIME_PATTERNS` regex checks the last user message for keywords indicating realtime/external data needs (weather, stock prices, latest news, live scores, etc.). Matching requests skip local routing entirely — no local call is attempted. **Inadequate response reroute**: After a local model responds, `_INADEQUATE_PATTERNS` regex checks the response content for refusal phrases ("I don't have access to real-time data", "my knowledge cutoff", etc.). If matched, the response is discarded and the request falls back to cloud. The routing event's `routing_reason` includes `"inadequate response, rerouting to cloud"` for UI log visibility.

**Force-local mode** (`auto_route_force_local`): Admin override that bypasses complexity analysis and routes all eligible requests to local. Still respects hard constraints (no tools, no images, no response_format/logprobs, Ollama must be available).

### Semantic Complexity Classification
`SemanticComplexityClassifier` in `middleware/semantic_router.py` uses a zero-shot NLI CrossEncoder (`cross-encoder/nli-MiniLM2-L6-H768` by default) to score prompt complexity as 0.0–1.0. Two default hypotheses: `"This requires advanced reasoning and expertise"` (complex) and `"This is a simple, straightforward task"` (simple). Lazy-initializes on first call, thread-safe via `threading.Lock`. Falls back to `None` gracefully when `sentence-transformers` is not installed. Integrated into `AutoRouterMiddleware`: if `auto_route_semantic_enabled=True` (default), semantic score is preferred over heuristic; heuristic is used as fallback.

### Shadow Similarity Scoring
`similarity.py` provides `compute_similarity()` which compares cloud and local model response text using `difflib.SequenceMatcher`, returning a `SimilarityResult` (score 0.0–1.0, method, previews, length ratio). `extract_response_text()` extracts plain text from any provider's response format (OpenAI, Anthropic, Gemini, Ollama). `ShadowMiddleware` uses a `_SimilarityBridge` to coordinate: whichever response (cloud or local) arrives second triggers the similarity computation. `ShadowDraftEvent` includes `similarity_score`, `similarity_method`, `cloud_preview`, `local_preview`, and `length_ratio`.

### Guardrails Middleware (Prompt Injection & Jailbreak Protection)
`GuardrailMiddleware` sits after PII scanner and before BudgetEnforcer in the pipeline. Four protection levels: **heuristic** (fast regex, ~0ms), **NLI classifier** (CrossEncoder semantic scoring, ~5-20ms, opt-in), **local model** (Llama-Guard 3 via Ollama, 100-500ms), and **enterprise API** (pluggable `GuardrailValidator` protocol). Plus post-call output scanning for system prompt leak detection.

**Two modes**: `GuardrailMode.AUDIT` (log violations as `GuardrailEvent`, never block) and `GuardrailMode.ENFORCE` (block high/critical severity violations by raising `StateLoomGuardrailError`).

**Heuristic patterns** (`guardrails/patterns.py`): 32 regex patterns across categories — injection (ignore_instructions, new_system_prompt, act_as_system, pretend_no_rules, instruction_delimiter, system_override, sql_injection, shell_injection, xpath_injection, extract_system_prompt, spaced_evasion, completion_manipulation, conversation_reset, indirect_injection, few_shot_poisoning, markdown_injection, payload_splitting, recursive_override), jailbreak (dan_mode, developer_mode, do_anything_now, unfiltered_mode, evil_confidant, roleplay_exploit, hypothetical_framing), encoding (base64_instruction, hex_instruction, unicode_smuggling, rot13_instruction, homograph_attack, token_smuggling), multi_turn_manipulation. `scan_text(text, disabled_rules)` returns `list[GuardrailMatch]`.

**NLI classifier** (`guardrails/nli_classifier.py`): `NLIInjectionClassifier` uses a zero-shot NLI CrossEncoder (`cross-encoder/nli-MiniLM2-L6-H768` by default) to score prompts as 0.0–1.0 injection probability. Hypotheses: `"This is a prompt injection or jailbreak attempt"` vs `"This is a normal, legitimate user request"`. Lazy-initialized with double-checked locking + `threading.Lock`. Falls back to `None` when `sentence-transformers` is not installed. Truncates to 2000 chars. Zero new dependencies — reuses `stateloom[semantic]`. Opt-in via `guardrails_nli_enabled` config or runtime toggle via `POST /security/guardrails/configure`. NLI score maps to severity: >0.9 → critical, >0.8 → high, else → medium.

**Local model** (`guardrails/local_validator.py`): `LocalGuardrailValidator` uses Llama-Guard 3 via `OllamaClient`. Lazy-initialized with double-checked locking. Auto-pulls model on first use. Parses "safe"/"unsafe\nSX" and "unsafe SX" (space-separated) output formats with S1–S13 category mapping. Fail-open: returns safe on any error (Ollama unavailable, timeout, etc.).

**Output scanning** (`guardrails/output_scanner.py`): `SystemPromptLeakScanner` detects if the LLM response contains fragments of the system prompt. Uses sliding window substring matching (window=50 chars, stride=25) + `difflib.SequenceMatcher` ratio. Skips system prompts < 20 chars. Configurable threshold (default 0.6).

**Event**: `GuardrailEvent` (type `GUARDRAIL`) with fields `rule_name`, `category`, `severity`, `score`, `action_taken`, `violation_text`, `scan_phase` ("input"/"output"), `validator_type` ("heuristic"/"nli"/"local_model"/"output_scanner"). Extra fields serialize to `extra_json` — no schema migration needed.

**Session accumulator**: `Session.guardrail_detections` (int) incremented on each violation. Persisted in `sessions` table via `guardrail_detections` column (Alembic migration `005`).

**Blocking behavior (enforce mode)**: Events are persisted directly to store before raising `StateLoomGuardrailError` (same `_save_events_directly()` pattern as PII scanner). `StateLoomGuardrailError` is in `_NON_RETRYABLE` tuple — never retried, excluded from blast radius failure counting.

**Config**: `guardrails_enabled`, `guardrails_mode` (GuardrailMode), `guardrails_heuristic_enabled`, `guardrails_nli_enabled`, `guardrails_nli_model`, `guardrails_nli_threshold`, `guardrails_local_model_enabled`, `guardrails_local_model`, `guardrails_local_model_timeout`, `guardrails_output_scanning_enabled`, `guardrails_system_prompt_leak_threshold`, `guardrails_disabled_rules`, `guardrails_webhook_url`. YAML: `guardrails:` section with flattened keys.

**Public API**: `stateloom.guardrails_status()`, `stateloom.configure_guardrails()`. **Dashboard**: `guardrail_detections` in session detail and global stats. Guardrails sub-tab in Security view with config status, NLI toggle, detection stats (total/blocked/by-category/by-severity), and recent violations table. API: `GET /security/guardrails`, `GET /security/guardrails/events`, `POST /security/guardrails/configure`.

### Kill Switch (Global Emergency Stop)
`KillSwitchMiddleware` sits at position 0 in the chain (before everything). It supports two modes: global (`kill_switch_active=True` blocks all traffic) and granular rules (`KillSwitchRule` in `config.kill_switch_rules`). Rules match on `model` (fnmatch glob, e.g. `"gpt-*"`), `provider`, `environment`, and `agent_version`. A rule must have at least one non-None filter to match; empty rules match nothing. First matching rule wins. Two response modes: `"error"` (default, raises `StateLoomKillSwitchError`) and `"response"` (sets `skip_call=True` and `cached_response` with a static dict, then continues pipeline). Events are persisted directly to the store since EventRecorder won't run when the error is raised. `KillSwitchEvent` includes `matched_rule` (dict), `blocked_model`, and `blocked_provider`.

### Blast Radius Containment
`BlastRadiusMiddleware` sits at position 1 (after kill switch, before experiment). Tracks consecutive failures and sliding-window budget violations per session **and** per agent identity. Agent identity is derived from `session.agent_name` (typed field) → `"agent:<name>"` or falls back to `"model:<model>"`. When thresholds are breached, either the session or the agent is paused (whichever hits first). Agent pause blocks **all** sessions with that identity. `StateLoomKillSwitchError`, `StateLoomBlastRadiusError`, and `StateLoomRateLimitError` are explicitly excluded from failure counting. Public methods: `unpause_session(id)`, `unpause_agent(id)`, `get_status()` — exposed via `__init__.py` and dashboard API. Webhook payload includes `agent_id`. `BlastRadiusEvent` includes `agent_id`. Budget violation timestamps older than 1 hour are pruned (sliding window). State is held in-memory under a single `threading.Lock`.

### Rate Limiting (Priority-Aware Throttling)
`RateLimiterMiddleware` sits after BlastRadius and before Experiment in the chain. It provides per-team TPS (Transactions Per Second) limits with a priority-aware virtual queue, configured entirely at runtime via the Team object or dashboard API.

**Token Bucket** (per-team, O(1) state): Capacity = TPS value. Refills lazily at `tps` tokens/second. On request: if `tokens >= 1`, decrement and proceed. Otherwise, enter queue.

**Priority Queue** (per-bucket): Each team has a `priority` field (higher number = served first, default 0). When a bucket is empty, a `_QueuedRequest` is created with a `threading.Event` for signaling. Requests are stored in per-bucket `dict[int, deque[_QueuedRequest]]` keyed by priority, FIFO within priority. Release mechanism: when a request completes → `_on_request_complete()` refills bucket → pops highest-priority waiter. Waiting requests also self-check token refill every 500ms via `event.wait(timeout)`.

**Cross-Thread Safety**: Each `_TokenBucket` has its own `threading.Lock`. Waiting uses `threading.Event.wait(timeout)` via `loop.run_in_executor()` so the async event loop is not blocked. No background threads needed — release is driven by request completion + periodic self-check.

**Hot-Reload**: TPS/priority/max_queue/timeout are re-read from the Team object on every request, so dashboard changes take effect immediately.

**Backwards-Compatible**: Sessions without `team_id` or teams without `rate_limit_tps` pass through unthrottled.

**Failure Isolation**: `StateLoomRateLimitError` is excluded from BlastRadius failure counting (same pattern as KillSwitch and BlastRadius errors).

**Data Model**: `Team` dataclass has 4 rate limit fields: `rate_limit_tps` (float|None), `rate_limit_priority` (int, default 0), `rate_limit_max_queue` (int, default 100), `rate_limit_queue_timeout` (float, default 30.0). These are persisted in the SQLite `teams` table and loaded via `_row_to_team()`.

**Dashboard API**: `PUT/GET/DELETE /teams/{id}/rate-limit` for per-team config, `GET /rate-limiter` for global status. Public API: `stateloom.rate_limiter_status()`.

**Events**: `RateLimitEvent` (type `RATE_LIMIT`) records `team_id`, `queued`, `wait_ms`, `rejected`, `timed_out` for every rate-limited request.

### HTTP Reverse Proxy (Passthrough)
`proxy/passthrough.py` provides the core HTTP reverse proxy engine using httpx. Instead of instantiating SDK clients (which require API keys), the proxy forwards raw HTTP requests to upstream provider APIs. The CLI's own authentication headers pass through transparently, enabling subscription users (Claude Max, Gemini Ultra) whose CLIs use OAuth/session tokens — no API key required from StateLoom's side.

**Architecture**: `PassthroughProxy` class uses `httpx.AsyncClient` with connection pooling (100 max, 20 keepalive). Two methods: `forward()` (non-streaming, returns `httpx.Response`) and `forward_stream()` (streaming, yields SSE lines via `aiter_lines()`). `filter_headers()` utility strips hop-by-hop headers via `REQUEST_HOP_BY_HOP_HEADERS` (request-direction) and `RESPONSE_HOP_BY_HOP_HEADERS` (response-direction, includes `content-encoding` to prevent double-decompression), StateLoom-internal headers (`x-stateloom-session-id`, BYOK headers), and `content-length` (httpx recalculates). Optionally replaces the auth header for VK mode.

**Streaming relay**: `proxy/stream_helpers.py` provides `passthrough_stream_relay()` — a shared async helper used by all three passthrough streaming handlers (`router.py`, `anthropic_native.py`, `gemini_native.py`). It handles chunk forwarding, usage tracking, error formatting (via provider-specific callback), cleanup callbacks, and rate limiter slot release. `SSE_HEADERS` constant (`Cache-Control`, `Connection`, `X-Accel-Buffering`) is also defined here and used by all proxy streaming endpoints.

**Dual-path architecture**: All three proxy endpoints (`router.py`, `anthropic_native.py`, `gemini_native.py`) accept an optional `PassthroughProxy` instance. When provided (production via `DashboardServer`), requests use HTTP forwarding with `gate.async_session()` + `gate.pipeline.execute()`. When not provided (backward compat, tests), they fall back to the legacy `Client`-based SDK flow. The agent endpoint (`/v1/agents/{ref}/chat/completions`) always uses `Client` because agents need model/prompt overrides.

**Auth passthrough**: All proxy endpoints use shared `authenticate_request()` from `proxy/auth.py`, which returns an `AuthResult(vk, byok_key, raw_token)`. In VK mode, the resolved provider key replaces the auth header. In no-auth mode, `raw_token` (the CLI's original auth) is forwarded as-is to upstream.

**Upstream error handling**: If the upstream returns a 4xx/5xx, the response is returned with an `_upstream_error` sentinel in the dict. The proxy endpoint detects this and returns the error to the client with the original status code.

**Stream usage tracking**: For streaming, each provider's SSE format is parsed inline: Anthropic `message_start`/`message_delta` events, OpenAI `usage` in final chunk, Gemini `usageMetadata` in final chunk. Token counts are set on `ctx.prompt_tokens`/`ctx.completion_tokens` for cost tracking.

**Config**: Upstream URLs are configurable via `proxy_upstream_anthropic`, `proxy_upstream_openai`, `proxy_upstream_gemini`, `proxy_upstream_chatgpt` in `StateLoomConfig`. `proxy_timeout` sets the httpx request timeout (default 600s). `proxy_upstream_chatgpt` overrides the ChatGPT OAuth upstream (default: `chatgpt.com/backend-api/codex`).

**Lifecycle**: `PassthroughProxy` is created in `DashboardServer._create_app()` and passed to all three router factories. Cleaned up in `DashboardServer.stop()` via `await self._passthrough.close()`.

### Proxy (OpenAI-Compatible Gateway)
`proxy/router.py` provides an OpenAI-compatible `/v1/chat/completions` endpoint via FastAPI. Dual-path: when `PassthroughProxy` is provided and the model is OpenAI, uses HTTP passthrough via `_handle_openai_passthrough()`. For cross-provider models (e.g., Claude model via OpenAI endpoint) or when no passthrough is available, falls back to the `Client` class in `chat.py`. The agent endpoint always uses `Client`. `proxy/response_format.py` converts provider-native responses to OpenAI format. Error mapping converts `StateLoomError` subclasses to appropriate HTTP status codes and OpenAI error format.

### BYOK (Bring Your Own Key)
The proxy supports user-supplied provider API keys via headers: `X-StateLoom-OpenAI-Key`, `X-StateLoom-Anthropic-Key`, `X-StateLoom-Google-Key`. In passthrough mode, BYOK keys are injected into the upstream request headers via `filter_headers()`. In legacy Client mode, they are passed to `Client(provider_keys=...)`.

**Key resolution priority** (highest wins):
1. BYOK header (`X-StateLoom-{Provider}-Key`)
2. Org-level secret (from store, via `ProxyAuth.get_provider_keys()`)
3. Global config (`provider_api_key_openai`, etc.)
4. Environment variable (SDK default behavior)

**Implementation path (passthrough)**: `router.py`/`anthropic_native.py`/`gemini_native.py` extract auth → resolve provider keys → `filter_headers()` replaces auth header with resolved key → `passthrough.forward()` sends to upstream.

**Implementation path (legacy Client)**: `router.py` extracts headers → merges with `proxy_auth.get_provider_keys(vk)` → passes `provider_keys` dict to `Client.__init__()` → `Client` stores as `self._provider_keys` → each `_prepare_{openai,anthropic,gemini}()` method reads from it in the inner `llm_call()` closure.

**Design notes**: The `provider_keys` dict uses lowercase provider names as keys (`"openai"`, `"anthropic"`, `"google"`). When no BYOK headers are present and no org secrets exist, the dict is empty (or `None`), and in passthrough mode the CLI's raw auth token is forwarded as-is.

### Anthropic-Native Proxy
`proxy/anthropic_native.py` provides a drop-in `/v1/messages` endpoint compatible with Claude CLI and the Anthropic Python SDK. Uses HTTP reverse proxy (passthrough) by default — forwards requests directly to `api.anthropic.com` via httpx. This enables subscription users (Claude Max) whose CLIs use OAuth/session tokens to work transparently without API keys. Falls back to legacy SDK-based `Client` flow when no `PassthroughProxy` is provided. Auth supports virtual keys (via `x-api-key: ag-...`), BYOK (pass Anthropic API key directly), and no-auth mode (CLI's own token forwarded as-is). Streaming uses real SSE forwarding from upstream. Billing mode is auto-detected from the BYOK key format (`sk-ant-*` → API, other → subscription).

**Claude CLI session ID extraction**: `_extract_claude_session_id(body)` parses the session UUID from Claude CLI's `metadata.user_id` field (format: `user_{hash}_account_{uuid}_session_{uuid}`). This takes priority over sticky session for session grouping. The regex `_CLAUDE_SESSION_RE` extracts the trailing `_session_{uuid}` component.

**CLI preflight bypass**: `_is_cli_preflight(body, request)` detects Claude CLI's startup calls (quota/count checks using a haiku model with a single short message). These are forwarded directly to upstream via `PassthroughProxy`, bypassing the middleware pipeline entirely so they don't clutter the session waterfall or accumulate tokens.

**PII block as synthetic streaming response**: When `StateLoomPIIBlockedError` is raised on a streaming request, the error is returned as a synthetic Anthropic SSE message (via `_make_anthropic_message` + `_emit_cached_as_stream`) rather than a JSON 400. This ensures Claude CLI renders the `[Content Policy]` error text visibly to the user — a plain JSON error on a streaming request is silently swallowed by most CLIs. The same approach is used when PII Phase 1 strips all messages (previously-blocked PII retry).

### Gemini-Native Proxy
`proxy/gemini_native.py` provides `/v1beta/models/{model}:generateContent` and `/v1beta/models/{model}:streamGenerateContent` endpoints. Uses HTTP reverse proxy (passthrough) by default — forwards requests directly to `generativelanguage.googleapis.com` via httpx. This enables subscription users (Gemini Ultra) to work transparently. Falls back to legacy SDK-based `Client` flow when no `PassthroughProxy` is provided. Auth via `x-goog-api-key` header (virtual key, BYOK, or CLI token passthrough). Request bodies are translated from Gemini's `contents`/`systemInstruction`/`generationConfig` format to the internal OpenAI-style messages format for the middleware pipeline, then the original body is forwarded to upstream. Gemini `functionCall` parts are translated to OpenAI assistant `tool_calls`, and `functionResponse` parts are translated to `role="tool"` messages — this enables tool-continuation detection and dashboard step collapsing for Gemini CLI's tool-use flows.

### OpenAI Responses API Proxy (Codex CLI Support)
`proxy/responses.py` provides `POST /v1/responses` (HTTP) and `ws://host/v1/responses` (WebSocket) endpoints, enabling Codex CLI to work through StateLoom with full middleware benefits. Codex CLI prefers WebSocket for multi-turn tool-heavy workflows; falls back to HTTP POST when WebSocket is unavailable.

**Dual transport**: WebSocket is the primary transport — a bidirectional relay between Codex CLI and upstream OpenAI using the `websockets` library. HTTP POST is the fallback, using `PassthroughProxy.forward()` / `forward_stream()`. Codex CLI's HTTPS fallback sends zstd-compressed request bodies (magic bytes `0x28 0xB5 0x2F 0xFD`); the HTTP handler auto-detects and decompresses via `zstandard`.

**ChatGPT OAuth routing**: Codex CLI web-login users authenticate via ChatGPT OAuth tokens, which must be routed to `chatgpt.com/backend-api/codex/responses` instead of `api.openai.com/v1/responses`. Detected heuristically via the `chatgpt-account-id` header. `_resolve_upstream()` returns the correct `(http_url, ws_url)` tuple. The ChatGPT upstream is configurable via `proxy_upstream_chatgpt` for resilience against endpoint changes.

**WebSocket relay state**: `_WSRelayState` dataclass holds mutable state shared between the `client_to_upstream` and `upstream_to_client` async tasks: `current_model`, `call_start`, `prompt_preview`, `synthetic_ids`. Both tasks run in the same asyncio event loop (cooperative concurrency, no locks needed).

**Middleware enforcement (WebSocket)**: Each `response.create` message is intercepted before forwarding. The `client_to_upstream()` loop is a 4-step dispatcher: (1) `_strip_synthetic_ids()` removes blocked-turn IDs, (2) update `_WSRelayState`, (3) `_run_ws_middleware()` executes the full middleware pipeline (handles block/cache-hit/pass-through outcomes), (4) `_rebuild_responses_body()` if middleware modified messages. `_input_to_openai_messages()` converts Responses API format to OpenAI `messages` for the pipeline. If middleware blocks (PII, budget, kill switch), a synthetic `response.completed` event with `status: incomplete` and `reason: content_filter` is sent back — this signals a non-retryable turn failure without triggering Codex CLI's 5-retry reconnection loop.

**Synthetic response ID handling**: Blocked turns produce synthetic response IDs (prefix `resp_ag_`). Codex stores these as `previous_response_id` for the next turn. On subsequent `response.create` messages, `_strip_synthetic_ids()` removes any `previous_response_id` matching the prefix (via set membership for this session's IDs + prefix match for cross-session persistence) before forwarding to upstream, preventing "previous_response_not_found" errors.

**Session tracking**: WebSocket sessions use sticky session IDs (IP + UA fingerprint hash). Each `response.completed` event from upstream creates an `LLMCallEvent` via `_record_ws_event()` (accepts `_WSRelayState`) with cost tracking, token counts, and prompt preview for dashboard visibility.

**Auth**: Same pattern as other proxy endpoints — `Bearer ag-*` → virtual key, `Bearer sk-*` → BYOK, other Bearer → passthrough. No-auth mode supported. All proxy endpoints use `strip_bearer()` from `proxy/auth.py` for case-insensitive Bearer token extraction.

### Billing Mode (API vs Subscription Cost Tracking)
Differentiates API-billed users (per-token pricing) from subscription users (Claude Max, ChatGPT Plus) who pay a flat monthly fee. `BillingMode(str, Enum)` in `core/types.py` with values `API` and `SUBSCRIPTION`.

**Detection**: `proxy/billing.py:detect_billing_mode(token, provider)` infers billing from BYOK key prefixes: `sk-ant-*` (Anthropic), `sk-*` (OpenAI), `AIzaSy*` (Google) → `api`; non-matching tokens → `subscription`; empty token → `api`. For virtual keys, billing mode is set explicitly by the admin (`VirtualKey.billing_mode` field).

**Dual cost tracking**: `LLMCallEvent` has both `cost` (actual: per-token for API, `$0` for subscription) and `estimated_api_cost` (always per-token). `Session` accumulates both via `add_cost()`. `CostTracker` computes both values. `BudgetEnforcer` skips enforcement for subscription sessions. `LLMCallEvent.is_tool_continuation` (bool, default `False`) marks calls where the **last** message contains tool results (OpenAI `role="tool"`, Anthropic `tool_result` content blocks, or Gemini `functionResponse` parts translated to `role="tool"`) — used by the dashboard to nest intermediate tool-use steps under the user prompt that triggered them.

**Propagation**: VK/detection → `Client(billing_mode=...)` → `session.billing_mode` (typed field, dual-written to metadata for backward compat) → middleware reads from typed field.

### Sticky Sessions
`proxy/sticky_session.py:StickySessionManager` maps client fingerprints (hash of IP + user-agent) to stable session IDs. Proxy clients that don't send `X-StateLoom-Session-Id` headers get automatically grouped into sessions. `resolve_session_id()` checks explicit header first, then sticky session, then generates a new UUID.

### Proxy-Level Rate Limiting
`proxy/rate_limiter.py:ProxyRateLimiter` provides per-virtual-key TPS rate limiting at the proxy gateway level (separate from middleware-level per-team rate limiting). Reuses the `_TokenBucket` pattern. VirtualKey has `rate_limit_tps` field. Checked before entering the middleware pipeline.

### Circuit Breaker (Provider Failover)
`middleware/circuit_breaker.py:CircuitBreakerMiddleware` implements the circuit breaker pattern per-provider. Three states: `closed` (normal), `open` (failing — routes to fallback), `half_open` (testing recovery with synthetic probes). Tier-based failover maps models to same-tier alternatives across providers. Health probes run automatically to detect recovery.

### Compliance Enforcement (GDPR/HIPAA/CCPA)
`middleware/compliance.py:ComplianceMiddleware` enforces declarative compliance profiles. `compliance/profiles.py` provides factory functions for GDPR, HIPAA, and CCPA presets. Features include audit trails with tamper-proof SHA-256 hashes (`compliance/audit.py`), legal rule citations (`compliance/legal_rules.py`), zero-retention modes, data region controls, and a purge engine for "Right to Be Forgotten" requests (`compliance/purge.py`).

### Multi-Tenant Hierarchy (Organizations & Teams)
`core/organization.py` defines `Organization` and `Team` dataclasses for multi-tenant isolation. Organizations contain teams; teams have per-level budgets, PII rules, compliance profiles, and rate limits. The hierarchy is loaded by `Gate._load_hierarchy()`.

### Async Jobs
`core/job.py` defines the `Job` dataclass (status, webhook URL, result, retry config, TTL). The `jobs/` package provides: `processor.py` (background ThreadPoolExecutor-based job processor), `queue.py` (pluggable queue protocol for Kafka/Redis Streams/SQS), `webhook.py` (HMAC-SHA256 signed webhook delivery with exponential backoff), `redis_queue.py` (Redis Streams implementation with consumer groups).

Public API: `stateloom.submit_job()`, `stateloom.get_job()`, `stateloom.list_jobs()`, `stateloom.cancel_job()`, `stateloom.job_stats()`. Dashboard API: `POST /jobs`, `GET /jobs`, `GET /jobs/stats`, `GET /jobs/{id}`, `DELETE /jobs/{id}`. Config: `async_jobs_enabled`, `async_jobs_max_workers`, `async_jobs_default_ttl`, `async_jobs_webhook_timeout`, `async_jobs_webhook_retries`, `async_jobs_webhook_secret`, `async_jobs_queue_backend`, `async_jobs_redis_url`.

### Observability
`observability/collector.py` provides Prometheus metrics (silent no-op if `prometheus_client` not installed). `observability/aggregator.py` computes time-series aggregation with latency percentiles. `observability/alerting.py` delivers webhook-based alerts for budget, kill switch, rate limiting, job failures, and compliance violations. `observability/tracing.py` provides optional OpenTelemetry distributed tracing integration (silent no-op if `opentelemetry-sdk` not installed). `dashboard/observability_api.py` exposes REST endpoints for timeseries and latency percentile data.

### Advanced Caching
Beyond exact-match caching (`middleware/cache.py`), the `cache/` package provides: semantic similarity matching via sentence-transformers embeddings (`cache/semantic.py`), request normalization to strip dynamic elements like UUIDs and timestamps (`cache/normalizer.py`), pluggable vector backends supporting FAISS (`cache/vector_backend.py`), and Redis-backed storage with RediSearch KNN (`cache/redis_store.py`, `cache/redis_vector_backend.py`).

**Error response exclusion**: `_is_error_response()` in `middleware/cache.py` prevents caching upstream error responses (429, 529, etc.) returned as dicts by the passthrough proxy. Detects Anthropic (`{"type": "error", ...}`), OpenAI/Gemini (`{"error": {...}}`), and internal sentinel (`{"_upstream_error": True}`) formats. SDK objects that raise exceptions on errors never reach the cache store.

### Additional Provider Adapters
Beyond OpenAI, Anthropic, and Gemini, the following adapters are available in `intercept/adapters/`: `cohere_adapter.py` (Cohere V2 SDK), `litellm_adapter.py` (LiteLLM unified interface), `mistral_adapter.py` (Mistral SDK). All follow the `BaseProviderAdapter` pattern.

### Multi-Agent Consensus (Debate Framework)
`consensus/` provides budget-constrained multi-agent debate with three strategies: **vote** (parallel independent answers, one round), **debate** (multi-round with context sharing, judge synthesis), and **self-consistency** (multiple samples from one model). Research-backed design: 3 agents, 2-3 rounds max, confidence-weighted aggregation, adaptive early stopping.

**Key files**: `consensus/models.py` (Pydantic models: `ConsensusResult`, `DebateRound`, `DebaterResponse`; `ConsensusConfig` dataclass), `consensus/orchestrator.py` (main entry point), `consensus/strategies/` (vote, debate, self_consistency), `consensus/aggregation.py` (majority_vote, confidence_weighted, judge_synthesis, compute_agreement), `consensus/confidence.py` (adapter-aware confidence extraction), `consensus/prompts.py` (prompt templates).

**Architecture**: `ConsensusOrchestrator.run(config)` creates a parent session via `gate.async_session(durable=config.ee_consensus)`, dispatches to the chosen strategy, records `DebateRoundEvent` per round and `ConsensusEvent` at completion. Each strategy creates child sessions per debater via `Client(parent=parent.id, durable=config.ee_consensus)` — every debater call flows through the full middleware pipeline. On `StateLoomBudgetError` mid-debate, returns best answer from completed rounds.

**Enterprise gating** (`consensus_advanced` feature): Core tier supports all 3 strategies with up to 3 models, majority_vote + confidence_weighted aggregation, and static early stop. Enterprise unlocks: >3 models, greedy downgrade, judge synthesis aggregation, custom judge model, and durable replay. `Gate.consensus()` checks `_feature_registry.is_available("consensus_advanced")` and sets `config.ee_consensus` before dispatching to the orchestrator. Explicit user requests (>3 models, greedy, judge_synthesis, judge_model) raise `StateLoomFeatureError` with actionable messages. Implicit behaviors (debate judge synthesis, durable sessions) silently degrade: judge → confidence_weighted, durable → False. `ConsensusResult.aggregation_method` always reflects the actual method used.

**Greedy downgrade** (`greedy=True`, enterprise): If agreement after Round 1 exceeds `greedy_agreement_threshold` (default 0.7), models are swapped to cheaper tier equivalents using `_DEFAULT_MODEL_TIERS` from `circuit_breaker.py` (e.g., gpt-4o → gpt-4o-mini, claude-sonnet → claude-haiku). `_downgrade_model()` in `debate.py` handles the mapping.

**Adapter-level confidence**: `BaseProviderAdapter` has optional `confidence_instruction()` and `extract_confidence()` methods (default implementations in `provider_adapter.py`). `consensus/confidence.py:extract_confidence(text, provider)` checks the adapter first, then falls back to regex `[Confidence: X.XX]` with default 0.5.

**Events**: `DebateRoundEvent` (type `DEBATE_ROUND`) and `ConsensusEvent` (type `CONSENSUS`) in `core/event.py`, added to `AnyEvent` discriminated union. `ConsensusStrategy` enum in `core/types.py` (VOTE, DEBATE, MOA, SELF_CONSISTENCY).

**Config**: 10 `consensus_*` fields on `StateLoomConfig` (default_models, default_strategy, default_rounds, default_budget, max_rounds, max_models, early_stop_enabled, early_stop_threshold, greedy, greedy_agreement_threshold). Frozen `ConsensusDefaultsConfig` view via `config.consensus_defaults`.

**Public API**: `stateloom.consensus(prompt, models, strategy, rounds, budget, ...)`, `stateloom.consensus_sync(...)`. Also `gate.consensus()`. Returns `ConsensusResult`.

**Dashboard**: `GET /consensus-runs` (list with optional `?strategy=` filter), `GET /consensus-runs/{session_id}` (detail with rounds, responses, children). Consensus nav section in dashboard UI with stats cards, runs table, and click-to-expand detail panel.

**Tests**: `tests/test_consensus/` (91 tests: models, confidence, aggregation, strategies, orchestrator, events, EE gating) + `tests/test_dashboard/test_consensus_api.py` (12 tests).

### Managed Agent Definitions (Prompts-as-an-API)
Enterprise users can "deploy" AI agents without writing code. A Product Manager selects a model, writes a system prompt, attaches a budget, and gets a unique URL — all through the dashboard. Updating the agent (new prompt, different model) creates a new immutable version with instant rollback.

**Data Model**: `Agent` (prefix `agt-`) and `AgentVersion` (prefix `agv-`) dataclasses in `agent/models.py`. `AgentStatus(str, Enum)` in `core/types.py` with values `ACTIVE`, `PAUSED`, `ARCHIVED`. Agents are team-scoped; slug is unique within a team. Slug validation: `^[a-z0-9](?:[a-z0-9-]{1,62}[a-z0-9])?$` (3–64 chars).

**Versioning**: Immutable versions — "update" = create new version, "rollback" = activate old version. `Agent.active_version_id` points to the live `AgentVersion`. `store.get_next_version_number(agent_id)` auto-increments.

**Resolution**: `resolver.py:resolve_agent(store, agent_ref, vk_team_id, vk_agent_ids)` resolves by slug or UUID. Checks: agent exists, status is ACTIVE (403 for paused, 410 for archived), active version exists, VK `agent_ids` scoping (empty list = no restriction). Raises `AgentResolutionError(message, status_code)`.

**Override Application**: `resolver.py:apply_agent_overrides(version, messages, body)` returns `(model, messages, extra_kwargs)`. Model: always from agent version (client model silently ignored — governance). System prompt: prepended before any client system prompt (with `\n\n` separator). Request overrides: merged into extra_kwargs (agent wins on conflicts). Follows the same pattern as `ExperimentMiddleware._apply_system_prompt()`.

**Proxy Route**: `POST /v1/agents/{agent_ref}/chat/completions` in `proxy/router.py`. Flow: VK auth → resolve agent → apply overrides → set session typed fields + metadata (`agent_id`, `agent_slug`, `agent_version_id`, `agent_version_number`) → `Client.achat()` → full middleware pipeline → OpenAI-compatible response. No new middleware needed — overrides are applied at the proxy level before entering the pipeline.

**Virtual Key Scoping**: `VirtualKey.agent_ids: list[str]` — if non-empty, the key can only access the listed agents. Persisted as `agent_ids_json` in SQLite.

**Store**: `agents` and `agent_versions` tables in SQLite. 8 protocol methods on `Store`: `save_agent`, `get_agent`, `get_agent_by_slug`, `list_agents`, `save_agent_version`, `get_agent_version`, `list_agent_versions`, `get_next_version_number`. Implemented in both `SQLiteStore` and `MemoryStore`.

**Gate**: `gate.py` has agent management methods: `create_agent()`, `get_agent()`, `get_agent_by_slug()`, `list_agents()`, `update_agent()`, `create_agent_version()`, `activate_agent_version()`, `archive_agent()`. In-memory `_agents_cache` dict is loaded from store on `_load_hierarchy()`.

**Dashboard API**: 9 endpoints under `/api/agents`: POST (create + initial version), GET (list with filters), GET by ref, PATCH (update), DELETE (archive/soft-delete), POST versions, GET versions, PUT activate (rollback), GET sessions. Agent ref resolution: `agt-` prefix → ID lookup; otherwise → slug lookup with required `team_id` query param.

**Public API**: `stateloom.create_agent()`, `stateloom.get_agent()`, `stateloom.list_agents()`, `stateloom.create_agent_version()`, `stateloom.activate_agent_version()`.

### Prompt Versioning for Individuals (File-Based Agent Management)
Individual users can manage agents by dropping `.md`, `.yaml`/`.yml`, or `.txt` files in a `prompts/` directory. StateLoom watches the directory and auto-syncs changes as agent versions — edit a file → new version auto-activated, delete a file → agent archived. Full version history and rollback available in the dashboard. Reuses the existing Agent/AgentVersion infrastructure entirely.

**File formats**: `.md` files use YAML frontmatter (between `---` delimiters) for config (model, temperature, max_tokens, budget_per_session, description, name) with the body as system_prompt. `.yaml`/`.yml` files use structured YAML with `model`, `system_prompt`, `request_overrides`, etc. `.txt` files use entire content as system_prompt with model from `config.default_model`. Filename stem → agent slug (e.g. `support-bot.md` → slug `support-bot`).

**Parser**: `agent/prompt_file.py` provides `parse_prompt_file(path, default_model)` → `PromptFileContent` dataclass, `slug_from_filename(path)` → validated slug or None, `content_hash(path)` → SHA-256 hex.

**Watcher**: `agent/prompt_watcher.py:PromptWatcher` uses `watchdog` (optional dep) for event-driven filesystem monitoring with debouncing (500ms `threading.Timer` per slug). On startup: creates `_local` org + team (idempotent), seeds hashes from existing file-sourced agents, runs initial `scan()`. Sync logic: parse file → compute content hash → skip if unchanged → create agent or new version → auto-activate. File deletion → archive agent. API-created agents with the same slug are never overwritten (checks `metadata["source"] == "file"`). Errors are accumulated in `_recent_errors` (capped at 20) for status reporting.

**Config**: `prompts_dir` (empty = disabled), `prompts_poll_interval` (seconds, default 2.0). YAML config supports `prompts: { dir: ..., poll_interval: ... }`.

**Gate integration**: `_prompt_watcher` attribute, `_start_prompt_watcher()` called at end of `_setup_middleware()`, cleanup in `shutdown()`. Falls back gracefully if `watchdog` is not installed (initial scan only).

**Public API**: `stateloom.init(prompts_dir="prompts/")`, `stateloom.prompt_watcher_status()`, `stateloom.rescan_prompts()`.

**Dashboard API**: `GET /api/prompts/status`, `POST /api/prompts/rescan`.

**Optional dependency**: `pip install stateloom[prompts]` (installs `watchdog>=3.0`).

### Store Protocol
Persistence is abstracted behind a Store protocol. SQLite (default, WAL mode), Postgres, and in-memory backends are provided. Store handles sessions, events, experiments, assignments, feedback, agents, users, team roles, refresh tokens, and OIDC providers. Both SQLite and Postgres stores use the same generic event serialization: `event.model_dump()` → direct columns + overflow `extra_json` + `TypeAdapter(AnyEvent).validate_python()` for deserialization. Column alias maps (`_COL_ALIASES`, `_DIRECT_COLS`) handle field name differences between event types and DB columns.

### Durable Resumption (Temporal-like Checkpointing)
When `durable=True` is passed to `session()` or `async_session()`, StateLoom enables crash-recovery replay. On the first run, each LLM response is serialized via `replay/schema.py:serialize_response()` and stored in the `cached_response_json` column of the events table (populated by `CostTracker` middleware when `session.durable` is `True`). On resume (same `session_id`), `DurableReplayEngine` in `replay/engine.py` loads cached steps, resets `step_counter` to 0, and returns cached responses for completed steps via the standard `_check_replay()` path in `generic_interceptor.py`. Steps beyond the cached range execute live. Unlike `ReplayEngine` (time-travel debugging), `DurableReplayEngine` uses the **same** session ID (no "replay-" prefix), has no network blocker, no safety warnings, and tools always re-execute.

**Key implementation details:**
- `LLMCallEvent.cached_response_json` (new field) stores the serialized response payload. Already existed as a column in SQLite but was previously unused for `LLMCallEvent`; now populated by `_event_to_row()` and read back by `_row_to_event()`.
- `CostTracker` serializes `ctx.response` into the event when the session is durable (fail-open: serialization errors are swallowed).
- Streaming is fully supported in durable mode. `_wrap_stream_sync` / `_wrap_stream_async` in `generic_interceptor.py` accumulate chunks as they yield to the caller. On stream completion, chunks are serialized via `serialize_stream_chunks()` into `ctx._durable_cached_json`, which `CostTracker` persists to `event.cached_response_json`. On replay, `deserialize_response()` detects the `{"_type": "stream"}` marker and returns a `CachedStreamChunks` object (supports `__iter__` and `__aiter__`). If the stream errors partway, chunks are NOT cached and the step re-executes live on resume. `durable_stream_delay_ms` config controls inter-chunk delay on replay (0 = instant).
- `gate.py:session()` and `async_session()` accept `durable: bool = False`. On resume with cached steps: loads events via `_load_durable_steps()`, resets `step_counter` to 0 (so code re-runs from step 1 and step numbers match cached responses), creates `DurableReplayEngine`, sets it in the ContextVar. The engine is stopped in the `finally` block.
- `__init__.py:session()` and `async_session()` pass through the `durable` parameter.

**Limitations:** Tool calls always re-execute (unless `durable_cache_tools=True`). Code must be deterministic (same execution path on resume). `session_id` is required (durable without an ID is a no-op).

### Semantic Retries (Self-Healing)
Builds on durable resumption to provide Temporal-like automatic retries for LLM output failures (bad JSON, hallucinated tool calls, missing fields). Two public interfaces:

**`retry_loop(retries=N)`** — iterable retry helper for use inside existing sessions. Each iteration yields a `RetryAttempt` context manager. If the code inside `with attempt:` raises, the exception is suppressed and the next iteration retries. If all attempts fail, the last exception propagates. Non-retryable errors (`StateLoomBudgetError`, `StateLoomPIIBlockedError`, `StateLoomKillSwitchError`, `StateLoomBlastRadiusError`, `StateLoomRateLimitError`, `StateLoomRetryError`) always propagate immediately.

**`durable_task(retries=N)`** — decorator combining `durable=True` session + automatic retry. Opens a **single** durable session spanning all retry attempts (step counter advances across retries, so durable replay works correctly). Supports both sync and async functions. Optional `validate` callback triggers retry when it returns `False`. Optional `on_retry` callback fires on each failed attempt.

**Key design**: One session, multiple attempts inside it. Attempt 1's LLM calls get steps 1..N, attempt 2's calls get steps N+1..M. On durable resume, cached bad responses replay → same validation failure → retry kicks in → cached good response succeeds. Zero wasted API calls on resume.

**Events**: `SemanticRetryEvent` (type `SEMANTIC_RETRY`) records `attempt`, `max_attempts`, `error_type`, `error_message`, `provider`, `model`, `resolved`. Serialized to `extra_json` column in SQLite. A resolved event (with `resolved=True`) is recorded on success after retries.

**Error**: `StateLoomRetryError` (code `RETRY_EXHAUSTED`) is raised when all attempts are exhausted. Chains the original exception via `__cause__`.

**Implementation**: `retry.py` contains `RetryLoop`, `RetryAttempt`, `durable_task()`, `retry_loop()` factory. Event recording is fail-open. Public API exposed via `__init__.py`: `stateloom.durable_task()`, `stateloom.retry_loop()`, `stateloom.StateLoomRetryError`. `Gate.durable_task()` delegates to `retry.durable_task()`.

### Named Checkpoints
`CheckpointEvent` (type `CHECKPOINT`) allows marking named milestones within a session. `Gate.checkpoint(label, description="")` reads the current session from the ContextVar, creates a `CheckpointEvent`, and persists it to the store. Public API: `stateloom.checkpoint(label, description)`. Checkpoint events appear in the dashboard waterfall timeline as divider rows with labels.

### Parent-Child Sessions
Sessions support hierarchical parent-child relationships via `Session.parent_session_id`. When creating a child session, if `parent` is not explicitly given, it auto-derives from the current active session (ContextVar). Children inherit `org_id` and `team_id` from the parent when not explicitly set (`Gate.session()` handles this inheritance). Parent and child sessions are fully isolated — budgets, timeouts, cancellation, metadata, and cost tracking are per-session and do not cascade.

**Store queries**: `Store.list_child_sessions(parent_session_id, limit=100)` returns children filtered by `parent_session_id`. SQLite uses an indexed column; MemoryStore filters in-memory.

**Dashboard API**: `GET /sessions/{id}/children` lists child sessions. Session detail includes `parent_session_id`.

**Public API**: `stateloom.session(parent="parent-id")` and `stateloom.async_session(parent="parent-id")`.

### Session Timeouts & Heartbeats
Sessions support two timeout modes: `timeout` (max total duration since `started_at`) and `idle_timeout` (max idle time since `last_heartbeat`). `Session.heartbeat()` updates the timestamp; `Session.is_timed_out()` returns a tuple `(timed_out, timeout_type, elapsed, limit)`.

`TimeoutCheckerMiddleware` sits after RateLimiter in the pipeline. Before each LLM call, it checks cancellation (first), then timeout, then idle timeout. After a successful call, it updates the heartbeat. On timeout, it sets `SessionStatus.TIMED_OUT` and raises `StateLoomTimeoutError(session_id, timeout_type, elapsed, limit)` (code `SESSION_TIMED_OUT`).

**Public API**: `stateloom.session(timeout=60.0, idle_timeout=30.0)`. Heartbeat is auto-initialized on session creation when any timeout is set.

### Session Cancellation
`Session._cancelled` (boolean flag) + `Session.cancel()` + `Session.is_cancelled` property. Cancellation is checked at the top of `TimeoutCheckerMiddleware.process()` — if cancelled, sets `SessionStatus.CANCELLED` and raises `StateLoomCancellationError(session_id)` (code `SESSION_CANCELLED`).

`Gate.cancel_session(session_id)` looks up the session and calls `cancel()`. Public API: `stateloom.cancel_session(session_id)`. Dashboard API: `POST /sessions/{id}/cancel`.

Both `StateLoomTimeoutError` and `StateLoomCancellationError` are non-retryable (in `_NON_RETRYABLE` tuple) and excluded from blast radius failure counting.

### Session Suspension (Human-in-the-Loop)
`Session._suspended` (boolean flag) + `Session.suspend(reason, data)` + `Session.signal(payload)` + `Session.wait_for_signal(timeout)`. Suspension is checked in `TimeoutCheckerMiddleware.process()` — if suspended, raises `StateLoomSuspendedError(session_id, reason, data)` (code `SESSION_SUSPENDED`). The session status is set to `SUSPENDED`.

`Gate.suspend_session(session_id, reason, data)` suspends externally. `Gate.signal_session(session_id, payload)` resumes — sets `signal_payload` on the session and clears the suspended flag. `Gate.suspend(reason, data, timeout)` suspends the *current* session and blocks (via `threading.Event.wait()`) until signaled. `Gate.async_suspend()` is the async equivalent (non-blocking via `asyncio.Event.wait()`).

Public API: `stateloom.suspend_session()`, `stateloom.signal_session()`, `stateloom.suspend()`, `stateloom.async_suspend()`. Dashboard API: `POST /sessions/{id}/suspend`, `POST /sessions/{id}/signal`.

### VCR-Cassette Mock (Zero-Cost Testing)
`mock.py` provides `MockSession` — a VCR-style record/replay mechanism for deterministic LLM testing. On first run, records all LLM responses to the store. On subsequent runs with the same session ID, replays from cache with full network blocking.

`stateloom.mock(session_id, force_record, network_block, allow_hosts)` returns a `MockSession` usable as both a decorator and a context manager. `MockSession.is_replay` indicates whether responses come from cache. `force_record=True` re-records even if cached responses exist.

Public API: `stateloom.mock()`, `stateloom.MockSession`.

### Session Export & Import
`Gate.export_session(session_id, path, include_children, scrub_pii)` serializes a session and its events as a portable JSON bundle (dict). Optionally includes child sessions recursively and scrubs PII fields. If `path` is given, writes to file (supports `.json` and `.json.gz`).

`Gate.import_session(source, session_id_override)` deserializes a bundle back into the store. `source` can be a dict or a file path. `session_id_override` replaces the original session ID to avoid collisions.

Public API: `stateloom.export_session()`, `stateloom.import_session()`. Dashboard API: `GET /sessions/{id}/export`, `POST /sessions/import`.

### Config Locking (Admin Controls)
`Gate.lock_setting(setting, value, reason)` persists a lock record to the store. `Gate.check_locked_settings(config_kwargs)` raises `StateLoomConfigLockedError` if any locked setting is overridden in `init()`. `Gate.unlock_setting(setting)` removes a lock. `Gate.list_locked_settings()` returns all active locks.

Public API: `stateloom.lock_setting()`, `stateloom.unlock_setting()`, `stateloom.list_locked_settings()`. Dashboard API: `POST /admin/locks`, `GET /admin/locks`, `DELETE /admin/locks/{setting}`.

### Virtual Key Management
Virtual keys are proxy authentication tokens scoped to teams. `VirtualKey` dataclass in `proxy/virtual_key.py` includes: `key_hash`, `key_preview`, `team_id`, `org_id`, `scopes` (enforced — see VK Scope Enforcement), `allowed_models` (glob patterns), `budget_limit`, `rate_limit_tps`, `agent_ids` (agent scoping), `billing_mode`, `revoked`.

`generate_virtual_key()` creates a random `ag-*` prefixed key and its bcrypt hash. `make_key_preview()` creates a masked preview. Keys are stored via `store.save_virtual_key()` and looked up by hash on each proxy request.

Public API: `stateloom.create_virtual_key()`, `stateloom.list_virtual_keys()`, `stateloom.revoke_virtual_key()`. Dashboard API: `POST /virtual-keys`, `GET /virtual-keys`, `DELETE /virtual-keys/{id}`, `PUT/GET/DELETE /virtual-keys/{id}/rate-limit`.

### Unified Chat API
`chat.py` provides `Client` and `ChatResponse` for provider-agnostic LLM calls without importing provider SDKs. `Client(provider_keys=...)` supports BYOK. `Client.chat()` / `Client.achat()` dispatch to the appropriate provider based on model name prefix matching. `ChatResponse` wraps the response with `.text`, `.cost`, `.tokens`, `.model` accessors.

Module-level `chat()` and `achat()` functions use a default `Client` instance. `stateloom.init(default_model="gpt-4o")` sets the fallback model.

Public API: `stateloom.chat()`, `stateloom.achat()`, `stateloom.Client`, `stateloom.ChatResponse`.

### Waterfall Trace Timeline (Dashboard)
The session detail view includes a waterfall trace timeline (inspired by Temporal's execution history UI). Events are grouped into numbered steps — primary events (`llm_call`, `cache_hit`, `tool_call`, `local_routing`, `checkpoint`, `pii_detection`, `circuit_breaker`, `blast_radius`, `kill_switch`, `budget_enforcement`) anchor each step, and related sub-events (cost, latency, etc.) are grouped under the same step. Each row shows type badge, model, duration bar (proportional to latency), cost, and status pill. Checkpoint events render as labeled divider rows. A toggle switches between waterfall and flat event views.

**Tool-continuation collapsing**: When Claude Code, Gemini CLI, or similar tool-use agents work through the proxy, each intermediate tool-use sub-call generates a separate `LLMCallEvent` with `is_tool_continuation=True`. `CostTracker` detects these by checking only the **last** message: OpenAI `role="tool"`, Anthropic `tool_result` content blocks, or Gemini `functionResponse` parts (translated to `role="tool"` during proxy message conversion). Earlier tool results in conversation history are ignored to prevent false positives in multi-turn conversations. In the dashboard, `_collapseToolSteps()` nests tool-continuation steps **under the user-prompt step that triggered them**, showing a collapsible summary row with total count, tokens, cost, and latency (e.g., "15 tool-use steps · 52,340 tokens · $0.0142 · 45.2s"). The parent step's duration bar reflects the combined time (prompt + tools). Non-continuation LLM calls sandwiched between tool-continuation runs (e.g., CLI preflight safety checks using a different model) are absorbed into the tool group — a model-mismatch guard prevents absorbing real user prompts. Session-level totals remain unaffected — all events are still persisted and accumulated server-side.

### Authentication & RBAC (OAuth2/OIDC)
StateLoom's auth system provides unified role-based access control for both individual developers and enterprise teams. It operates on two separate planes: dashboard (management) uses JWT, proxy (data) uses VK hash lookup. Auth is **optional** — `auth_enabled: false` (default) preserves existing API key behavior.

**Architecture**: Management plane / data plane separation. RBAC applies to dashboard API only. Proxy hot path stays fast (VK hash lookup, no JWT validation). When `auth_enabled=False`, existing single-key `dashboard_api_key` behavior is unchanged.

**User model**: `auth/models.py` defines `User` (prefix `usr-`) and `UserTeamRole` (prefix `utr-`) as Pydantic v2 models. Users belong to one org (`org_id`), optionally have an org-wide role (`org_role`), and can have per-team roles via `UserTeamRole` junction records.

**Role hierarchy**: `Role(str, Enum)` in `core/types.py` with `ORG_ADMIN`, `ORG_AUDITOR`, `TEAM_ADMIN`, `TEAM_EDITOR`, `TEAM_VIEWER`. `auth/permissions.py` defines `Permission(str, Enum)` (29 permissions like `SESSIONS_READ`, `AGENTS_WRITE`, `ADMIN_USERS`, etc.) and `ROLE_PERMISSIONS` mapping. `check_permission()` resolves org-wide role first, then falls back to team-specific role. `resolve_permissions()` returns the full permission set for a user in a given context.

**Password hashing**: `auth/password.py` uses argon2id (preferred, via `argon2-cffi`) with PBKDF2 stdlib fallback. Hash prefix auto-detection (`$argon2id$` or `$pbkdf2$`) in `verify_password()`.

**JWT tokens**: `auth/jwt.py` — access tokens (15min default) contain `sub`, `email`, `org_id`, `org_role` only. Team roles resolved via DB per request (keeps JWT small). Refresh tokens (7-day default) with rotation and family-based revocation. JWT secret: auto-generated and stored in the DB via `store.save_secret()`, overridable with `STATELOOM_JWT_SECRET` env var.

**Auth endpoints**: `auth/endpoints.py` — `POST /api/v1/auth/bootstrap` (first-user setup, only when 0 users), `POST /api/v1/auth/login` (email+password → JWT), `POST /api/v1/auth/refresh`, `POST /api/v1/auth/logout`, `GET /api/v1/auth/me`, `POST /api/v1/auth/change-password`. OIDC endpoints: `GET /api/v1/auth/oidc/providers`, `GET /api/v1/auth/oidc/authorize/{provider_id}`, `POST /api/v1/auth/oidc/callback`, `POST /api/v1/auth/oidc/link`. Device authorization grant: `POST /api/v1/auth/device/authorize`, `POST /api/v1/auth/device/token`, `GET /api/v1/auth/device/verify`.

**Dashboard auth middleware**: `dashboard/server.py` dual-mode middleware: tries JWT decode → `request.state.user` + `request.state.team_roles`; falls back to legacy API key → synthetic `_SystemUser` with `org_admin`; else 401. Skip list: health, login, refresh, bootstrap, OIDC callback, static.

**Permission dependency**: `auth/dependencies.py:require_permission(permission, team_id_param)` — FastAPI `Depends()` that checks `request.state.user` has the required permission. Applied to dashboard endpoints in `api.py`.

**User management**: `dashboard/user_api.py` — CRUD users, team role assignment/removal. All require `ADMIN_USERS` permission.

**OIDC federation**: `auth/oidc_models.py` defines `OIDCProvider` (prefix `oidc-`). `auth/oidc.py:OIDCClient` handles discovery (cached 5min), authorization URL with PKCE, code exchange, ID token validation, group extraction. TOFU flow: if OIDC email matches existing user with `email_verified=True`, requires local password proof before merge. JIT provisioning for new users with automatic group→role mapping.

**IaC bootstrap**: `gate.py:_bootstrap_admin()` on startup: if `STATELOOM_ADMIN_EMAIL` + `STATELOOM_ADMIN_PASSWORD_HASH` env vars are set, upsert admin user as `org_admin` of Default Organization.

**Store**: 4 new tables (`users`, `user_team_roles`, `refresh_tokens`, `oidc_providers`) + `end_user` column on `sessions`. 14 new protocol methods: `save_user`, `get_user`, `get_user_by_email`, `get_user_by_oidc`, `list_users`, `delete_user`, `save_user_team_role`, `get_user_team_roles`, `get_team_members`, `delete_user_team_role`, `save_refresh_token`, `get_refresh_token`, `revoke_refresh_token`, `revoke_all_refresh_tokens` + 5 OIDC provider methods. Alembic migration `003_add_auth_tables.py`.

**Config**: `auth_enabled` (bool, default False), `auth_jwt_algorithm` (`HS256`/`RS256`), `auth_jwt_access_ttl` (900s), `auth_jwt_refresh_ttl` (604800s).

**Optional dependency**: `pip install stateloom[auth]` adds `pyjwt>=2.8` + `argon2-cffi>=23.1`.

### VK Scope Enforcement
`proxy/auth.py:ProxyAuth.check_scope(vk, required_scope)` — if `vk.scopes` is empty, all scopes allowed (backward compatible). If non-empty, the required scope must be in the list. `PROXY_SCOPES = {"chat", "agents", "models", "responses", "messages", "generate"}`.

Enforced on all proxy endpoints: `router.py` chat=`"chat"`, agents=`"agents"`; `anthropic_native.py`=`"messages"`; `gemini_native.py`=`"generate"`; `responses.py`=`"responses"`. Returns 403 in provider-native error format (OpenAI `scope_denied`, Anthropic `{type: "error", error: {message}}`, Gemini `{error: {code: 403, message}}`).

### Zero-Trust Security Engine (CPython Audit Hooks + Secret Vault)
`security/audit_hook.py:AuditHookManager` installs a CPython audit hook (PEP 578) that intercepts dangerous interpreter operations at the C level — `open`, `socket.connect`, `subprocess.Popen`, `os.system`, `exec`, `import`, `ctypes.dlopen`, etc. This catches supply-chain attacks in third-party libraries, not just during LLM calls. The hook is **global and irreversible** (`sys.addaudithook`); it is installed once and toggled via mutable state.

**Two modes**: `GuardrailMode.AUDIT` (log violations as `SecurityAuditEvent`, never block) and `GuardrailMode.ENFORCE` (raise `RuntimeError` for denied events — CPython hooks can only propagate RuntimeError). Hook raises `RuntimeError`, not `StateLoomSecurityError` (the custom error is for public API / dashboard layer).

**Deny list**: Events in `_deny_events` set are blocked (enforce) or logged (audit). **Allow list**: Glob patterns for file paths that bypass `open` checks. **Recent events**: Bounded `deque(maxlen=100)` for dashboard status.

`security/vault.py:SecretVault` — thread-safe in-memory secret storage. `configure(enabled, scrub_environ, keys)` reads env vars into vault, optionally deletes from `os.environ`. Default keys: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GOOGLE_API_KEY`, `STATELOOM_LICENSE_KEY`, `STATELOOM_JWT_SECRET`. `restore_environ()` on shutdown restores scrubbed keys. Vault scrub is opt-in (default `False`) — scrubbing can break SDKs that read keys lazily.

**Vault in key resolution**: `proxy/auth.py:get_provider_keys()` checks vault as last resort: BYOK > org secret > config > vault > env var. Full air-gapped mode: only store keys in vault.

**Gate integration**: `Gate._setup_security()` called at top of `_setup_middleware()` — vault first (move keys before hooks monitor), then audit hooks. `Gate.security_status()` returns combined status. Shutdown disables hooks and restores environ.

**Event**: `SecurityAuditEvent` (type `SECURITY_AUDIT`) with fields `audit_event`, `action_taken`, `detail`, `source`, `severity`, `blocked`. **Error**: `StateLoomSecurityError` (code `SECURITY_BLOCKED`).

**Config**: `security_audit_hooks_enabled`, `security_audit_hooks_mode` (GuardrailMode), `security_audit_hooks_deny_events`, `security_audit_hooks_allow_paths`, `security_secret_vault_enabled`, `security_secret_vault_scrub_environ`, `security_secret_vault_keys`, `security_webhook_url`. YAML: `security:` section with flattened keys. Lockable: `security_audit_hooks_enabled`, `security_audit_hooks_mode`, `security_secret_vault_enabled`, `security_secret_vault_scrub_environ`.

**Public API**: `stateloom.security_status()`, `stateloom.vault_store()`, `stateloom.vault_retrieve()`, `stateloom.StateLoomSecurityError`. `init()` accepts `security_audit_hooks_enabled` and `security_secret_vault_enabled`.

**Dashboard**: Security tab with 4 sub-tabs (Audit Hooks, Secret Vault, Event Log, Guardrails). API: `GET /security`, `POST /security/audit-hooks/configure`, `GET /security/vault`, `POST /security/vault/store`, `GET /security/events`, `GET /security/guardrails`, `GET /security/guardrails/events`, `POST /security/guardrails/configure`.

**No new dependencies** — uses stdlib (`sys.addaudithook`, `threading`, `collections.deque`, `fnmatch`).

### End-User Attribution
Optional `X-StateLoom-End-User` header on all proxy endpoints. `proxy/auth.py:sanitize_end_user()` strips non-printable chars (regex `[^\x20-\x7E]`), truncates to 256 chars. Stored on `Session.end_user` (dedicated column, not metadata). Stripped before upstream forwarding via `_STATELOOM_HEADERS` set in `proxy/passthrough.py`. Dashboard API: `end_user` field in session list/detail, `?end_user=` filter on `GET /api/sessions` (SQL WHERE, not JSON scan). `Session.end_user: str = ""` field added to `core/session.py`.

## Development

### Running tests

```bash
pytest tests/ -v              # Full suite (1900+ tests)
pytest tests/ -v -x           # Stop on first failure
pytest tests/test_middleware/  # Just middleware tests
```

### Linting and type checking

```bash
ruff check src/               # Lint
ruff format src/               # Format
mypy src/stateloom/           # Type check (strict mode)
```

### Project config

- Build system: hatchling
- Python: 3.10+
- Lint: ruff (line-length 100, target py310)
- Types: mypy strict mode
- Tests: pytest with pytest-asyncio (asyncio_mode = "auto")

### Schema Migrations

Database schema changes are managed by Alembic (optional dependency: `pip install stateloom[migrations]`). Migrations run automatically on startup when Alembic is installed — no CLI step required. When Alembic is not installed, the legacy `_SCHEMA` + `_migrate_schema()` path still works.

**Creating a new migration:**
```bash
cd src/stateloom/store && python -m alembic revision -m "description"
```

**Conventions:**
- Use `op.execute()` with raw SQL — no SQLAlchemy ORM models
- Keep `IF NOT EXISTS` / `try-except` for idempotency (columns may already exist from legacy path)
- Additive columns should not be dropped in `downgrade()` to avoid data loss
- Migration files live in `src/stateloom/store/alembic/versions/`

**Config:**
- `store_auto_migrate: bool = True` — set to False to skip Alembic and use only the legacy path
- When Alembic detects an existing database (has `sessions` table but no `alembic_version`), it stamps at head without running DDL

## Conventions

- **Enums**: Use `(str, Enum)` pattern for all enums so they serialize as plain strings. Use enum constants (not string literals) in code — e.g., `Provider.OPENAI` not `"openai"`.
- **Imports**: Use absolute imports from `stateloom.*`. Type-only imports go in `if TYPE_CHECKING:` blocks.
- **Error handling**: Middleware should catch and log errors, not crash. Security-critical middleware uses explicit `on_middleware_failure` config. Every `except Exception` block must log — never silently `pass` (see Fail-Open Philosophy above for severity guidelines). Security pre-checks fail closed (assume dangerous condition is true).
- **Events**: All observable activity is recorded as typed Event subclasses and persisted to the store.
- **No global mutation**: Use ContextVars for session/replay state. The only mutable global is the `_gate` singleton in `__init__.py`.
- **Optional deps**: Guard with try/except ImportError at module level (see `ext/langchain.py` pattern). Provide a stub class that raises ImportError on instantiation.

## Common Tasks

### Adding a new middleware
1. Create `middleware/my_middleware.py` implementing the `Middleware` protocol
2. Add it to the chain in `Gate._setup_middleware()` in `gate.py`
3. If the middleware tracks per-session state (dicts keyed by `session_id`), implement `on_session_end(session_id: str)` to evict entries — `Pipeline.notify_session_end()` calls this automatically when sessions exit
4. Add lock hierarchy comments if using `threading.Lock` (see Middleware Pipeline section)
5. Add tests in `tests/test_middleware/`

### Adding a new provider adapter
1. Create `intercept/adapters/my_adapter.py` extending `BaseProviderAdapter`
2. Return `Provider.X` from `name` property (or a plain string for non-builtin providers)
3. Implement `get_patch_targets()`, `extract_tokens()`, `extract_stream_tokens()`
4. Register in `provider_registry.py:register_builtin_adapters()` if it's a builtin
5. Add tests in `tests/test_intercept/`

### Adding a new event type
1. Add to `EventType` enum in `core/types.py`
2. Create dataclass in `core/event.py` inheriting from `Event`
3. Handle serialization in store backends if needed

### Adding a new PII pattern
1. Add regex to `PII_PATTERNS` in `pii/patterns.py`
2. Add to `PATTERN_GROUPS` if it belongs to a group (e.g., `api_key`)
3. Add test in `tests/test_pii/`

### Adding a new guardrail pattern
1. Add tuple `(name, regex, category, severity, description)` to `_PATTERN_DEFS` in `guardrails/patterns.py`
2. Categories: `"injection"`, `"jailbreak"`, `"encoding"`. Severities: `"low"`, `"medium"`, `"high"`, `"critical"`
3. Add positive and negative match tests in `tests/test_guardrails/test_patterns.py`
4. Update the `test_pattern_count` assertion

### Adding a new managed agent
1. Use the dashboard API `POST /api/agents` or `stateloom.create_agent(slug, team_id, model=..., system_prompt=...)`
2. This creates both the Agent and its initial AgentVersion (v1)
3. The agent is accessible at `POST /v1/agents/{slug}/chat/completions` via virtual key
4. Create new versions with `POST /api/agents/{ref}/versions` or `stateloom.create_agent_version()`
5. Roll back with `PUT /api/agents/{ref}/versions/{version_id}/activate` or `stateloom.activate_agent_version()`
6. Tests in `tests/test_agent/` and `tests/test_proxy/test_agent_proxy.py` and `tests/test_dashboard/test_agent_api.py`
7. **Alternative (file-based)**: Drop a `.md` file in the `prompts_dir` folder with YAML frontmatter for config and body for system_prompt. The watcher auto-creates the agent. Tests in `tests/test_agent/test_prompt_file.py` and `tests/test_agent/test_prompt_watcher.py`.

### Adding a new local model to the catalog
1. Add entry to `MODEL_CATALOG` in `local/models.py` with `model`, `size_gb`, `description`, `tier`, `parameters`
2. Valid tiers: `ultra-light` (<2GB), `light` (2-4GB), `medium` (4-8GB), `heavy` (16GB+)
3. Add test in `tests/test_local/test_models.py`

### Running a consensus
1. Use `await stateloom.consensus(prompt="...", models=["gpt-4o", "claude-sonnet-4-20250514"], strategy="debate", rounds=2, budget=1.0)`
2. Strategies: `"vote"` (cheapest, one round), `"debate"` (multi-round with judge synthesis), `"self_consistency"` (multiple samples from one model)
3. Set `greedy=True` to auto-downgrade models after high-agreement Round 1
4. Use `consensus_sync()` for synchronous contexts
5. Dashboard: "Consensus" section shows all runs with round-by-round detail
6. Tests in `tests/test_consensus/` and `tests/test_dashboard/test_consensus_api.py`

### Working with the security engine
1. **Vault**: `stateloom.vault_store("MY_KEY", "value")` / `stateloom.vault_retrieve("MY_KEY")`
2. **Audit hooks**: Configure via `init(security_audit_hooks_enabled=True)` or YAML `security:` section
3. **Tests**: `tests/test_security/` (23 tests: vault, audit hooks, events)
