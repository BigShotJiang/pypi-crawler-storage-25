"""Manual feature test — run each StateLoom feature one by one with Gemini.

The dashboard stays alive the whole time. All sessions accumulate in one view.

Usage:
    export GOOGLE_API_KEY=your-key-here
    python test_manual.py                  # run all tests
    python test_manual.py local cloud      # run specific tests by name
    python test_manual.py litellm          # run just the litellm test
    python test_manual.py --list           # list available tests
    python test_manual.py --no-pause       # skip interactive pauses
"""

import sys
import time

import google.generativeai as genai

import stateloom
from stateloom import PIIRule

DASHBOARD = "http://localhost:4781"
TEST_NUM = 0
PAUSE_ENABLED = True


def header(title):
    global TEST_NUM
    TEST_NUM += 1
    print(f"\n{'='*60}")
    print(f"  TEST {TEST_NUM}: {title}")
    print(f"{'='*60}\n")


def pause(ui_hint=None):
    if not PAUSE_ENABLED:
        return
    print()
    if ui_hint:
        print(f"  >> UI CHECK: {ui_hint}")
        print(f"  >> Open {DASHBOARD} and look now.")
    input("\n  Press Enter to continue to next test...\n")


# ══════════════════════════════════════════════════════════════════════════
# Phase 1 tests: Quick config assertions (no dashboard, no API calls)
# ══════════════════════════════════════════════════════════════════════════

def test_autodetect(**_):
    header("Auto-detection: local model + shadow + auto-route auto-enable")
    gate = stateloom.init(
        auto_patch=False, dashboard=False, console_output=False,
        store_backend="memory",
    )
    assert gate.config.local_model_enabled is True
    assert gate.config.shadow_enabled is True
    assert gate.config.auto_route_enabled is True
    assert gate.config.local_model_default != ""
    print(f"  PASS: auto-detected model '{gate.config.local_model_default}'")
    print(f"  PASS: shadow_model='{gate.config.shadow_model}'")
    stateloom.shutdown()


def test_autoroute_off(**_):
    header("Auto-routing disabled when explicitly False")
    gate = stateloom.init(
        auto_patch=False, dashboard=False, console_output=False,
        store_backend="memory", auto_route=False,
    )
    assert gate.config.auto_route_enabled is False
    print("  PASS: auto_route=False overrides auto-detection")
    stateloom.shutdown()


def test_local_none(**_):
    header("Auto-detection disabled when local_model=None")
    gate = stateloom.init(
        auto_patch=False, dashboard=False, console_output=False,
        store_backend="memory", local_model=None,
    )
    assert gate.config.auto_route_enabled is False
    assert gate.config.local_model_enabled is False
    assert gate.config.shadow_enabled is False
    print("  PASS: local_model=None disables everything")
    stateloom.shutdown()


# ══════════════════════════════════════════════════════════════════════════
# Phase 2 tests: Need gate + model (dashboard stays alive)
# ══════════════════════════════════════════════════════════════════════════

def test_local(gate, model, **_):
    header("Simple request → routed to local Ollama")
    with stateloom.session("test-local", name="Simple → Local") as s:
        response = model.generate_content("Say hello in one word.")
        print(f"  Response: {response.text.strip()}")
        print(f"  Cost:     ${s.total_cost:.6f}  (should be ~$0)")
        print(f"  Tokens:   {s.total_tokens}")
    pause(
        "Sessions tab: click 'test-local'.\n"
        "  >> Should show ROUTED LOCAL | llama3.2 | complexity:... | was:gemini-2.0-flash.\n"
        "  >> Cost ~$0."
    )


def test_cloud(gate, model, **_):
    header("Complex request → stays on cloud")
    long_prompt = (
        "You are an expert systems architect. "
        "Design a complete microservices architecture for a banking application. "
        "Include service boundaries, data flow, authentication, "
        "event sourcing, CQRS, saga patterns, circuit breakers, "
        "service mesh, observability, and deployment strategy. "
        + "Please be very thorough and detailed. " * 500
    )
    with stateloom.session("test-cloud", name="Complex → Cloud") as s:
        response = model.generate_content(long_prompt)
        print(f"  Response: {response.text[:100].strip()}...")
        print(f"  Cost:     ${s.total_cost:.6f}  (should be >$0)")
        print(f"  Tokens:   {s.total_tokens}")
    time.sleep(3)  # let shadow complete
    pause(
        "Sessions tab: click 'test-cloud'.\n"
        "  >> Regular LLM call (gemini-2.0-flash), NOT routed local.\n"
        "  >> Also look for a SHADOW event (llama3.2 ran in parallel).\n"
        "  >> Cost >$0."
    )


def test_cache(gate, model, **_):
    header("Caching: duplicate request returns cached response")
    with stateloom.session("test-cache", name="Cache Test") as s:
        r1 = model.generate_content("What color is the sky?")
        print(f"  Call 1: {r1.text.strip()}")
        print(f"    Cost: ${s.total_cost:.6f}, Calls: {s.call_count}")

        r2 = model.generate_content("What color is the sky?")
        print(f"  Call 2 (cached): {r2.text.strip()}")
        print(f"    Cost: ${s.total_cost:.6f}, Cache hits: {s.cache_hits}")
    pause(
        "Sessions tab: click 'test-cache'.\n"
        "  >> Event timeline: LLM call (or routed local) then CACHE HIT event.\n"
        "  >> Overview: cache hits count increased."
    )


def test_budget(gate, model, **_):
    header("Budget enforcement: session-level hard stop")
    with stateloom.session("test-budget", name="Budget Test", budget=0.0001) as s:
        try:
            model.generate_content("Tell me a short joke.")
            print(f"  Call 1 cost: ${s.total_cost:.6f}")
            model.generate_content("Tell me another joke.")
            print(f"  Call 2 cost: ${s.total_cost:.6f}")
            model.generate_content("One more joke please.")
            print(f"  Call 3 cost: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"  PASS: Budget exceeded! Error: {e}")
    pause(
        "Sessions tab: click 'test-budget'.\n"
        "  >> Event timeline shows LLM call(s), then BUDGET enforcement event.\n"
        "  >> Budget bar should be red/full."
    )


def test_pii_redact(gate, model, **_):
    header("PII detection: redact email")
    with stateloom.session("test-pii-redact", name="PII Redact") as s:
        response = model.generate_content(
            "Send a summary to john@example.com about the project."
        )
        print(f"  Response: {response.text[:80].strip()}...")
        print(f"  PII detections: {s.pii_detections}")
    pause(
        "Sessions tab: click 'test-pii-redact' → PII REDACTED event.\n"
        "  >> Compliance > PII Monitor tab shows the email detection."
    )


def test_pii_block(gate, model, **_):
    header("PII detection: block credit card")
    with stateloom.session("test-pii-block", name="PII Block"):
        try:
            model.generate_content(
                "Charge this card: 4111-1111-1111-1111 for $50."
            )
            print("  Credit card — Response came through (unexpected)")
        except stateloom.StateLoomPIIBlockedError as e:
            print(f"  PASS: Credit card blocked! Error: {e}")
    pause(
        "Sessions tab: click 'test-pii-block' → PII BLOCKED event.\n"
        "  >> Compliance > PII Monitor tab shows the credit card detection."
    )


def test_mistral(gate, model, **_):
    header("Mistral: direct SDK via StateLoom pipeline")
    try:
        from mistralai.client.sdk import Mistral

        client = Mistral()
        stateloom.wrap(client)

        with stateloom.session("test-mistral", name="Mistral Integration") as s:
            response = client.chat.complete(
                model="mistral-small-latest",
                messages=[{"role": "user", "content": "Say hello in one word."}],
            )
            text = response.choices[0].message.content
            print(f"  Response: {text.strip()}")
            print(f"  Cost:     ${s.total_cost:.6f}")
            print(f"  Tokens:   {s.total_tokens}")
            print(f"  Calls:    {s.call_count}")

        pause(
            "Sessions tab: 'test-mistral'.\n"
            "  >> Provider shown as 'mistral', cost/tokens tracked."
        )

    except ImportError:
        print("  SKIP: mistralai not installed (pip install mistralai)")
        pause()
    except Exception as e:
        if "MISTRAL_API_KEY" in str(e) or "api_key" in str(e).lower():
            print("  SKIP: MISTRAL_API_KEY not set")
        else:
            raise
        pause()


def test_cohere(gate, model, **_):
    header("Cohere: V2 SDK via StateLoom pipeline")
    try:
        import cohere

        client = cohere.ClientV2()
        stateloom.wrap(client)

        with stateloom.session("test-cohere", name="Cohere Integration") as s:
            response = client.chat(
                model="command-r-plus",
                messages=[{"role": "user", "content": "Say hello in one word."}],
            )
            text = response.message.content[0].text
            print(f"  Response: {text.strip()}")
            print(f"  Cost:     ${s.total_cost:.6f}")
            print(f"  Tokens:   {s.total_tokens}")
            print(f"  Calls:    {s.call_count}")

        pause(
            "Sessions tab: 'test-cohere'.\n"
            "  >> Provider shown as 'cohere', cost/tokens tracked."
        )

    except ImportError:
        print("  SKIP: cohere not installed (pip install cohere)")
        pause()
    except Exception as e:
        if "CO_API_KEY" in str(e) or "token" in str(e).lower():
            print("  SKIP: CO_API_KEY not set")
        else:
            raise
        pause()


def test_litellm(gate, model, **_):
    header("LiteLLM: unified provider via StateLoom pipeline")
    try:
        import litellm

        with stateloom.session("test-litellm", name="LiteLLM Integration") as s:
            response = litellm.completion(
                model="gemini/gemini-2.5-flash",
                messages=[{"role": "user", "content": "Say hello in one word."}],
            )
            text = response.choices[0].message.content
            print(f"  Response: {text.strip()}")
            print(f"  Cost:     ${s.total_cost:.6f}")
            print(f"  Tokens:   {s.total_tokens}")
            print(f"  Calls:    {s.call_count}")

        with stateloom.session("test-litellm-cache", name="LiteLLM Cache") as s:
            r1 = litellm.completion(
                model="gemini/gemini-2.5-flash",
                messages=[{"role": "user", "content": "What is 2+2?"}],
            )
            print(f"  Call 1: {r1.choices[0].message.content.strip()}")
            print(f"    Cost: ${s.total_cost:.6f}")

            r2 = litellm.completion(
                model="gemini/gemini-2.5-flash",
                messages=[{"role": "user", "content": "What is 2+2?"}],
            )
            print(f"  Call 2 (cached): {r2.choices[0].message.content.strip()}")
            print(f"    Cache hits: {s.cache_hits}")

        pause(
            "Sessions tab: 'test-litellm' and 'test-litellm-cache'.\n"
            "  >> Provider shown as 'litellm', cost/tokens tracked.\n"
            "  >> Cache hit on duplicate litellm call."
        )

    except ImportError:
        print("  SKIP: litellm not installed (pip install litellm)")
        pause()


def test_unified_client(gate, model, **_):
    header("Unified Client: stateloom.Client() and stateloom.chat()")

    # 1. Client as context manager — session scoped to block
    print("  --- Client context manager ---")
    with stateloom.Client(session_id="test-unified-cm", budget=5.0) as client:
        r1 = client.chat(
            model="gemini-2.5-flash",
            messages=[{"role": "user", "content": "What is 2+2? One number only."}],
        )
        print(f"  Response:        {r1.content.strip()}")
        print(f"  Requested model: {r1.model}")
        print(f"  Requested prov:  {r1.provider}")
        print(f"  Actual model:    {r1._stateloom['actual_model']}")
        print(f"  Actual provider: {r1._stateloom['actual_provider']}")
        print(f"  Routed local:    {r1._stateloom['routed_local']}")
        print(f"  Cached:          {r1._stateloom['cached']}")
        print(f"  Latency:         {r1._stateloom['latency_ms']:.0f}ms")
        print(f"  Tokens:          {r1._stateloom['prompt_tokens']}+{r1._stateloom['completion_tokens']}")
        print(f"  Session cost:    ${client.session.total_cost:.6f}")
        print(f"  Session ID:      {r1._stateloom['session_id']}")
        print(f"  Events:          {r1._stateloom['events']}")

    # 2. Standalone client — explicit close
    print("\n  --- Standalone Client (close explicitly) ---")
    standalone = stateloom.Client(session_id="test-unified-standalone")
    r2 = standalone.chat(
        model="gemini-2.5-flash",
        messages=[{"role": "user", "content": "Say hello in one word."}],
    )
    print(f"  Response:        {r2.content.strip()}")
    print(f"  Actual model:    {r2._stateloom['actual_model']}")
    print(f"  Routed local:    {r2._stateloom['routed_local']}")
    standalone.close()

    print("\n  PASS: Unified client works with _stateloom metadata")
    pause(
        "Sessions tab: 'test-unified-cm' and 'test-unified-standalone'.\n"
        "  >> Both should show status=completed (not active).\n"
        "  >> Should show LLM call (or local routed) events.\n"
        "  >> The unified client manages its own session lifecycle."
    )


def test_cross_session(gate, model, **_):
    header("Cross-session event query")
    all_events = gate.store.get_session_events("")
    llm_events = gate.store.get_session_events("", event_type="llm_call")
    print(f"  All events (cross-session): {len(all_events)}")
    print(f"  LLM events (cross-session): {len(llm_events)}")
    assert len(all_events) > 0, "Should find events across sessions"
    print("  PASS: Cross-session query works")
    pause(
        "Cost Analytics tab: cost breakdown by model across ALL sessions.\n"
        "  >> Uses the cross-session query fix."
    )


def test_organizations(gate, model, **_):
    header("Organizations: create org + team, bind session, verify stats")

    # Create an organization with budget and PII rules
    org = stateloom.create_organization(
        name="ACME Corp",
        budget=100.0,
        pii_rules=[
            {"pattern": "email", "mode": "redact"},
        ],
        metadata={"region": "US", "tier": "enterprise"},
    )
    print(f"  Created org: {org.id} ({org.name})")
    assert org.name == "ACME Corp"
    assert org.budget == 100.0
    assert len(org.pii_rules) == 1

    # Create a team within the org
    team = stateloom.create_team(
        org_id=org.id,
        name="ML Team",
        budget=50.0,
        metadata={"project": "inference-pipeline"},
    )
    print(f"  Created team: {team.id} ({team.name}) under org {org.id}")
    assert team.org_id == org.id
    assert team.name == "ML Team"

    # Run a session bound to org + team
    with stateloom.session(
        "test-org-session",
        name="Org-bound Session",
        org_id=org.id,
        team_id=team.id,
    ) as s:
        response = model.generate_content("What is 1+1?")
        print(f"  Response: {response.text.strip()}")
        print(f"  Cost:     ${s.total_cost:.6f}")

    # Verify org/team can be retrieved
    fetched_org = stateloom.get_organization(org.id)
    assert fetched_org is not None
    print(f"  PASS: get_organization returned '{fetched_org.name}'")

    fetched_team = stateloom.get_team(team.id)
    assert fetched_team is not None
    print(f"  PASS: get_team returned '{fetched_team.name}'")

    # List orgs and teams
    all_orgs = stateloom.list_organizations()
    assert any(o.id == org.id for o in all_orgs)
    print(f"  PASS: list_organizations has {len(all_orgs)} org(s)")

    all_teams = stateloom.list_teams(org_id=org.id)
    assert any(t.id == team.id for t in all_teams)
    print(f"  PASS: list_teams has {len(all_teams)} team(s) for org")

    # Check stats
    ostats = stateloom.org_stats(org.id)
    print(f"  Org stats: {ostats}")

    tstats = stateloom.team_stats(team.id)
    print(f"  Team stats: {tstats}")

    pause(
        "Compliance > Organizations tab: should show 'ACME Corp' org.\n"
        "  >> Org has budget $100, 1 PII rule, ML Team underneath.\n"
        "  >> Sessions tab: 'test-org-session' is bound to org+team."
    )


def test_routing_stats(gate, model, **_):
    header("Persisted learning: routing stats")
    from stateloom.middleware.auto_router import AutoRouterMiddleware

    for mw in gate.pipeline.middlewares:
        if isinstance(mw, AutoRouterMiddleware):
            print(f"  Stats for {len(mw._stats)} model(s):")
            for model_name, stats in mw._stats.items():
                rate = f"{stats.success_rate:.1%}"
                print(
                    f"    {model_name}: "
                    f"{stats.successes}S / {stats.failures}F "
                    f"(rate: {rate})"
                )
            if not mw._stats:
                print("    (no stats yet)")
            break
    else:
        print("  (AutoRouterMiddleware not in pipeline)")

    print("  These stats persist to SQLite and survive restarts.")
    pause("Check Local tab and Settings tab for final review.")


def test_durable(gate, model, **_):
    header("Durable Resumption: crash recovery with cached LLM responses")

    session_id = "test-durable-resume"

    # --- First run: simulate a workflow that "crashes" after 2 calls ---
    print("  --- First run (simulating partial completion) ---")
    with stateloom.session(session_id=session_id, name="Durable Test", durable=True) as s:
        r1 = model.generate_content("What is the capital of France? One word.")
        print(f"  Call 1: {r1.text.strip()}")
        print(f"    Cost so far: ${s.total_cost:.6f}, Steps: {s.step_counter}")

        r2 = model.generate_content("What is the capital of Japan? One word.")
        print(f"  Call 2: {r2.text.strip()}")
        print(f"    Cost so far: ${s.total_cost:.6f}, Steps: {s.step_counter}")

        first_run_cost = s.total_cost
        first_run_steps = s.step_counter
        # In a real crash, the process would die here before call 3

    print(f"  First run complete: cost=${first_run_cost:.6f}, steps={first_run_steps}")

    # --- Second run: resume — calls 1-2 should be free (cached) ---
    print("\n  --- Second run (resuming — steps 1-2 should be cached) ---")
    with stateloom.session(session_id=session_id, name="Durable Test", durable=True) as s:
        r1 = model.generate_content("What is the capital of France? One word.")
        cost_after_r1 = s.total_cost
        print(f"  Call 1 (resumed): {r1.text.strip()}")
        print(f"    Cost after call 1: ${cost_after_r1:.6f}  (should be ~$0 — cached)")

        r2 = model.generate_content("What is the capital of Japan? One word.")
        cost_after_r2 = s.total_cost
        print(f"  Call 2 (resumed): {r2.text.strip()}")
        print(f"    Cost after call 2: ${cost_after_r2:.6f}  (should be ~$0 — cached)")

        r3 = model.generate_content("What is the capital of Germany? One word.")
        cost_after_r3 = s.total_cost
        print(f"  Call 3 (live):    {r3.text.strip()}")
        print(f"    Cost after call 3: ${cost_after_r3:.6f}  (should be >$0 — live call)")

        # Verify cached steps were free
        if cost_after_r2 < 0.0001:
            print("  PASS: Resumed steps 1-2 were effectively free (cached)")
        else:
            print(f"  WARN: Resumed steps cost ${cost_after_r2:.6f} (expected ~$0)")

        if cost_after_r3 > cost_after_r2:
            print("  PASS: Step 3 was a live call (cost increased)")
        else:
            print("  WARN: Step 3 did not increase cost")

    pause(
        "Sessions tab: click 'test-durable-resume'.\n"
        "  >> Event timeline should show LLM calls for steps 1-2 (first run)\n"
        "  >> and step 3 (second run, live call).\n"
        "  >> Steps 1-2 on resume returned cached responses at zero cost."
    )


def test_streaming(gate, model, **_):
    header("Streaming: middleware pipeline runs for stream=True calls")

    # 1. Basic streaming — verify events are recorded via callbacks
    print("  --- Basic streaming call ---")
    with stateloom.session("test-streaming-basic", name="Streaming Basic") as s:
        response = model.generate_content("Say hello in one word.", stream=True)
        full_text = ""
        chunk_count = 0
        for chunk in response:
            full_text += chunk.text
            chunk_count += 1
        print(f"  Response: {full_text.strip()}")
        print(f"  Chunks:   {chunk_count}")
        print(f"  Cost:     ${s.total_cost:.6f}")
        print(f"  Tokens:   {s.total_tokens}")
        print(f"  Calls:    {s.call_count}")
        if s.call_count > 0:
            print("  PASS: Streaming call tracked (events recorded via callbacks)")
        else:
            print("  WARN: No call count — events may not have been recorded")

    # 2. Streaming PII — verify PII scanning runs on streaming requests
    print("\n  --- Streaming with PII ---")
    with stateloom.session("test-streaming-pii", name="Streaming PII") as s:
        response = model.generate_content(
            "Send a note to alice@example.com about the plan.",
            stream=True,
        )
        full_text = ""
        for chunk in response:
            full_text += chunk.text
        print(f"  Response: {full_text[:80].strip()}...")
        print(f"  PII detections: {s.pii_detections}")
        if s.pii_detections > 0:
            print("  PASS: PII detected in streaming request (pre-call middleware ran)")
        else:
            print("  WARN: No PII detected — check config")

    # 3. Streaming budget — verify budget enforcement runs pre-call
    print("\n  --- Streaming with budget ---")
    with stateloom.session(
        "test-streaming-budget", name="Streaming Budget", budget=0.0001
    ) as s:
        try:
            response = model.generate_content("Tell me a short joke.", stream=True)
            for chunk in response:
                pass
            print(f"  Call 1 cost: ${s.total_cost:.6f}")

            response = model.generate_content("Tell me another joke.", stream=True)
            for chunk in response:
                pass
            print(f"  Call 2 cost: ${s.total_cost:.6f}")

            response = model.generate_content("One more joke please.", stream=True)
            for chunk in response:
                pass
            print(f"  Call 3 cost: ${s.total_cost:.6f}")
        except stateloom.StateLoomBudgetError as e:
            print(f"  PASS: Budget exceeded on streaming! Error: {e}")

    # 4. Streaming cache — verify cache works with streaming
    print("\n  --- Streaming cache ---")
    with stateloom.session("test-streaming-cache", name="Streaming Cache") as s:
        response = model.generate_content("What color is grass?", stream=True)
        text1 = ""
        for chunk in response:
            text1 += chunk.text
        print(f"  Call 1: {text1.strip()}")
        print(f"    Cost: ${s.total_cost:.6f}")

        # Second call with same content — may be cached
        response = model.generate_content("What color is grass?", stream=True)
        text2 = ""
        for chunk in response:
            text2 += chunk.text
        print(f"  Call 2: {text2.strip()}")
        print(f"    Cache hits: {s.cache_hits}")

    pause(
        "Sessions tab: check 'test-streaming-*' sessions.\n"
        "  >> 'test-streaming-basic': should show LLM call event with is_streaming=True.\n"
        "  >> 'test-streaming-pii': should show PII REDACTED event + LLM call.\n"
        "  >> 'test-streaming-budget': should show LLM call(s), then BUDGET event.\n"
        "  >> 'test-streaming-cache': should show LLM call then possibly CACHE HIT.\n"
        "  >> KEY: All middleware now runs for streaming (pre-call before, post-call via callbacks)."
    )


def test_async_jobs(gate, model, **_):
    header("Async Jobs: submit, monitor, cancel")

    # 1. Submit a job that will complete
    job1 = stateloom.submit_job(
        provider="gemini",
        model="gemini-2.5-flash",
        messages=[{"role": "user", "content": "What is the capital of France? One word."}],
        session_id="test-async-jobs",
        metadata={"test": "async-complete"},
    )
    print(f"  Submitted job 1: {job1.id} (status: {job1.status})")

    # 2. Submit a second job
    job2 = stateloom.submit_job(
        provider="gemini",
        model="gemini-2.5-flash",
        messages=[{"role": "user", "content": "What is 2+2? Just the number."}],
        session_id="test-async-jobs-2",
        metadata={"test": "async-quick"},
    )
    print(f"  Submitted job 2: {job2.id} (status: {job2.status})")

    # 3. Submit a third job and cancel it immediately
    job3 = stateloom.submit_job(
        provider="gemini",
        model="gemini-2.5-flash",
        messages=[{"role": "user", "content": "This should be cancelled."}],
        metadata={"test": "async-cancel"},
    )
    print(f"  Submitted job 3: {job3.id} (status: {job3.status})")
    cancelled = stateloom.cancel_job(job3.id)
    print(f"  Cancelled job 3: {cancelled}")

    # 4. Wait for jobs to process
    print("  Waiting for jobs to process...")
    for _ in range(30):
        time.sleep(1)
        j1 = stateloom.get_job(job1.id)
        j2 = stateloom.get_job(job2.id)
        if j1.status in ("completed", "failed") and j2.status in ("completed", "failed"):
            break

    # 5. Print results
    j1 = stateloom.get_job(job1.id)
    j2 = stateloom.get_job(job2.id)
    j3 = stateloom.get_job(job3.id)
    print(f"  Job 1 final: {j1.status}" + (f" | result keys: {list(j1.result.keys())}" if j1.result else ""))
    print(f"  Job 2 final: {j2.status}" + (f" | result keys: {list(j2.result.keys())}" if j2.result else ""))
    print(f"  Job 3 final: {j3.status} (should be cancelled)")

    # 6. Check stats
    stats = stateloom.job_stats()
    print(f"  Job stats: total={stats['total']}, by_status={stats['by_status']}")

    pause(
        "Async Jobs tab: should show 3 jobs.\n"
        "  >> Job 1 and 2 should be 'completed' (green badge).\n"
        "  >> Job 3 should be 'cancelled' (gray badge).\n"
        "  >> Stats cards: Total=3, Completed=2, Failed=0.\n"
        "  >> Click a completed job to see result JSON and session link.\n"
        "  >> Use the status filter dropdown to filter by status."
    )


# ══════════════════════════════════════════════════════════════════════════
# Test registry
# ══════════════════════════════════════════════════════════════════════════

# Phase 1: standalone tests (each does its own init/shutdown)
PHASE1_TESTS = {
    "autodetect": test_autodetect,
    "autoroute_off": test_autoroute_off,
    "local_none": test_local_none,
}

# Phase 2: tests that share a gate + model instance
PHASE2_TESTS = {
    "local": test_local,
    "cloud": test_cloud,
    "cache": test_cache,
    "budget": test_budget,
    "pii_redact": test_pii_redact,
    "pii_block": test_pii_block,
    "mistral": test_mistral,
    "cohere": test_cohere,
    "litellm": test_litellm,
    "unified_client": test_unified_client,
    "cross_session": test_cross_session,
    "organizations": test_organizations,
    "routing_stats": test_routing_stats,
    "durable": test_durable,
    "streaming": test_streaming,
    "async_jobs": test_async_jobs,
}

ALL_TESTS = {**PHASE1_TESTS, **PHASE2_TESTS}


def init_phase2():
    """Initialize gate + model for Phase 2 tests."""
    gate = stateloom.init(
        auto_route=True,
        pii=True,
        pii_rules=[
            PIIRule(pattern="email", mode="redact"),
            PIIRule(
                pattern="credit_card",
                mode="block",
                on_middleware_failure="block",
            ),
        ],
        cache=True,
        shadow=True,
        budget_on_middleware_failure="block",
        console_output=True,
        dashboard=True,
        store_backend="sqlite",
        async_jobs_enabled=True,
    )
    model = genai.GenerativeModel("gemini-2.5-flash")
    print(f"  Dashboard: {DASHBOARD}")
    return gate, model


def print_usage():
    print("\nAvailable tests:\n")
    print("  Phase 1 (config-only, no API calls):")
    for name in PHASE1_TESTS:
        print(f"    {name}")
    print("\n  Phase 2 (requires API key + dashboard):")
    for name in PHASE2_TESTS:
        print(f"    {name}")
    print("\nUsage:")
    print("  python test_manual.py                  # run all")
    print("  python test_manual.py local litellm    # run specific tests")
    print("  python test_manual.py --no-pause       # skip interactive pauses")
    print("  python test_manual.py --list           # show this list")


def main():
    global PAUSE_ENABLED

    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    flags = [a for a in sys.argv[1:] if a.startswith("-")]

    if "--list" in flags or "-l" in flags:
        print_usage()
        return

    if "--no-pause" in flags:
        PAUSE_ENABLED = False

    # Determine which tests to run
    if args:
        selected = []
        for name in args:
            if name not in ALL_TESTS:
                print(f"  Unknown test: '{name}'")
                print_usage()
                return
            selected.append(name)
    else:
        selected = list(ALL_TESTS.keys())

    phase1_selected = [n for n in selected if n in PHASE1_TESTS]
    phase2_selected = [n for n in selected if n in PHASE2_TESTS]

    # Run Phase 1 tests
    for name in phase1_selected:
        ALL_TESTS[name]()

    # Run Phase 2 tests (shared gate + model)
    if phase2_selected:
        print(f"\n{'='*60}")
        print(f"  Starting feature tests — dashboard at {DASHBOARD}")
        print(f"{'='*60}\n")

        gate, model = init_phase2()

        if not args:
            pause(
                "Dashboard should show Overview page. "
                "Settings tab shows all features enabled."
            )

        for name in phase2_selected:
            ALL_TESTS[name](gate=gate, model=model)

        if not args:
            print(
                f"\n  All {TEST_NUM} tests complete! "
                f"Dashboard still running at {DASHBOARD}"
            )
            print()
            print("  Overview tab   — total cost, calls, cache hits, PII detections")
            print("  Sessions tab   — all test sessions with event timelines")
            print("  Async Jobs tab — submitted jobs with status tracking")
            print("  Cost Analytics — cost breakdown by model")
            print("  Local Models   — Ollama status, shadow metrics")
            print("  Compliance     — PII Monitor, profiles, audit log, purge, orgs")
            print("  Settings       — all config values")
            print()
            print("  For experiments test, run: python test_experiments.py")
            input("\n  Press Enter when done exploring to shut down...\n")

        stateloom.shutdown()

    print("\n" + "=" * 60)
    print(f"  ALL {TEST_NUM} TESTS COMPLETE")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
