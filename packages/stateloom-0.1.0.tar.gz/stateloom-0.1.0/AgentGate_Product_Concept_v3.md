# StateLoom: Revised Product Concept

*Post-review revision incorporating feedback from peer debate. This is the document we build from.*

---

## The Problem

LLM agents are hitting production. The tooling hasn't caught up.

Every tool in the ecosystem — LiteLLM, Portkey, LangFuse — operates at the level of the individual API call. One request, one response, isolated. Portkey and LiteLLM are in the call path and do real things (caching, fallbacks, budget limits) — credit where it's due. But they are **stateless**. They see request N with no memory of requests 1 through N-1. They cannot detect a loop because they don't know request N is the fifteenth step in a session. They cannot attribute cost to a session because they don't model sessions — they model requests.

LangFuse understands traces with nested spans and full run capture. But LangFuse is architecturally passive — session data arrives after the call returns. It can observe; it cannot intervene.

The specific failure modes this creates, in production, today:

- An agent spins in a loop calling `web_search` with semantically equivalent queries and nobody catches it until the bill arrives
- A customer's email address rides along in a prompt to OpenAI because nobody audited what the prompt contained
- A 15-step agent fails on step 14 and the developer re-runs the entire thing — 2 minutes, $0.40 in tokens — just to test a one-line fix
- A session runs $23 before anyone realizes the budget was never enforced
- A developer hits a weird agent behavior, can't reproduce it reliably, and can't show a teammate what happened

These are not theoretical problems. They are daily friction for teams building production agents.

---

## The Core Insight

**StateLoom is the first stateful AI gateway.**

Portkey enforces per-request policies. StateLoom enforces per-session policies. Those are different problems.

The unit of value is the session. An agent isn't a call — it's a session: fifty LLM calls, thirty tool invocations, fifteen dollars of tokens, and a coherent task with a beginning and an end. Session-scoped context enables things that are physically impossible from a stateless request proxy: mid-session budget enforcement, loop detection across the full call history, cost attribution to a single task, and — the developer wedge — faithful replay of a failed session for debugging.

---

## Positioning

**Stateful AI Gateway.** Not a better tracer. Not a smarter proxy. The product that understands your agent as a session, not as a bag of API calls.

Target user: the developer building a LangGraph, CrewAI, or custom agent that runs more than five steps. They are burning time on debugging, money on wasted LLM calls, and sleep on undefined production behavior.

---

## What We're Building

### V0.1: The Developer Wedge

A Python SDK. Minimal entry point:

```python
import stateloom
stateloom.init()
```

Auto-patches OpenAI and Anthropic clients. Opens a dashboard at `localhost:4781`. **Fails open** — if StateLoom crashes, your LLM call goes through unchanged. No exceptions.

For production:

```python
gate = StateLoom.from_config("stateloom.yaml")
client = gate.wrap(openai.OpenAI())
```

**Core v0.1 capabilities:**

**1. Session-scoped observability.** Every LLM call is tagged to its session. Real-time cost per session, running total, model breakdown, latency histogram. Terminal output that's actually useful:

```
[StateLoom] ✓ gpt-4o | 847 tok | $0.013 | 1.2s | session:ticket-123
[StateLoom] ⚠ PII DETECTED (logged) | type:email | field:user_message
[StateLoom] ⚡ CACHE HIT | exact match | saved $0.013
[StateLoom] 🔁 LOOP DETECTED | tool:web_search | calls:3 | action:flagged
[StateLoom] 🛑 BUDGET ENFORCED | limit:$5.00 | spent:$5.02 | action:hard_stop
```

Nothing is silent in dev mode. Every intervention gets a console line.

**2. PII detection — detect-and-log by default.** We scan prompts for PII using a compiled regex scanner targeting high-confidence, structurally unambiguous patterns: email addresses, credit card numbers (with Luhn checksum validation), API keys with known prefixes (`sk-`, `Bearer `, `AKIA`), and similar. Default behavior: detect, log to session event stream, surface in dashboard, **do not modify the prompt**.

Why: false positives from inline redaction break agents silently. A developer who installs StateLoom and finds their agent is mysteriously failing because `[MASKED_SSN]` replaced their database ID will uninstall it. Trust comes first.

Configurable modes per PII type (opt-in, explicit warnings in docs):

```yaml
# stateloom.yaml
pii:
  default_mode: audit  # audit | redact | block
  rules:
    - pattern: email
      mode: audit       # detect and log, don't touch the prompt
    - pattern: credit_card
      mode: block       # reject the entire LLM call, raise StateLoomPIIBlockedError
    - pattern: ssn
      mode: block
    - pattern: api_key
      mode: redact      # mask PII before it reaches the LLM, rehydrate on response
  # WARNING: 'redact' mode — false positives will modify prompts and may break agent logic.
  # WARNING: 'block' mode — false positives will halt your agent entirely.
  # Test thoroughly before enabling redact/block in production.
```

When `block` is triggered:
```
[StateLoom] 🛑 PII BLOCKED | type:credit_card | session:ticket-123 | action:call_rejected
```
The SDK raises `StateLoomPIIBlockedError` with the PII type and session ID. The LLM call never fires. Developers can catch this to handle gracefully (e.g., ask the user to remove sensitive data).

Optional: install `stateloom[presidio]` to run spaCy-backed NLP detection asynchronously in the audit path. Higher confidence, higher recall, zero latency impact on the critical path.

Scope boundary, stated explicitly in docs: **We see what passes through `gate.wrap()` and `@gate.tool()`. We do not see `requests.post()` calls made directly in tool code we haven't wrapped.** This is not a bug; it's the SDK boundary. Users who need network-layer PII enforcement should combine StateLoom with a network proxy.

**3. Loop detection — split synchronous and asynchronous paths.**

- Exact-match loop detection: synchronous, hash-set membership check, <0.5ms overhead. Identical prompt in the same session triggers configurable action (warn, flag, circuit-break).
- Semantic loop detection: asynchronous. Payload is mirrored to a background worker that computes embedding similarity against session history. If a loop is detected, a `session_kill_switch` flag is set in shared session state. The next LLM call from that session checks the flag (0.1ms) and raises `StateLoomLoopError`. We miss exactly one call in a semantic loop — the one being processed while the worker is still comparing. Acceptable tradeoff.

**4. Budget enforcement.** Hard stop when a session exceeds its configured spend limit. Enforced in the critical path — synchronous check against running session cost before each LLM call is dispatched. Trivial to implement correctly, nobody has built it into an interceptor layer.

**5. Exact-match caching.** Identical prompt within a session is served from in-memory cache. Stored with session ID, returned instantly, logged as cache hit. Savings are auditable: "23% of LLM calls were cache hits, saved $2,341 this month." Passive tracers cannot produce this number because they're not in the call path.

**6. `@gate.tool()` decorator.** Enables tool execution visibility and safe replay:

```python
@gate.tool(mutates_state=True)
def create_jira_ticket(title: str) -> dict: ...

@gate.tool(mutates_state=False)
def search_docs(query: str) -> list: ...
```

Tool calls are logged to the session event stream alongside LLM calls. `mutates_state` flag controls replay behavior. This is the foundation for time-travel debugging.

**7. Time-travel debugging — the core developer wedge.**

When a 15-step agent fails on step 14, the developer currently re-runs the entire agent, waits 2 minutes, pays for 13 useless LLM calls, to test their fix for one step.

```python
gate.replay(session="ticket-123", mock_until_step=13)
```

StateLoom intercepts all LLM calls and `@gate.tool()` calls up to step 13, instantly returns the exact cached responses from the previous run, and only actually executes from step 14 onward. Fix and re-test in seconds, not minutes.

Replay safety rules:
- `@gate.tool(mutates_state=True)` calls are **never re-executed** during replay up to the mock boundary. Cached result from original run is returned.
- `@gate.tool(mutates_state=False)` calls return cached result by default; `--live-reads` flag re-executes them for freshness.
- **Undecorated tool calls will re-execute.** This is loud and explicit:

```
[StateLoom] ⚠ REPLAY WARNING: Steps 4, 7 include untracked tool executions.
  These functions will RE-EXECUTE during replay:
    step 4: create_jira_ticket (detected: HTTP POST in body)
    step 7: delete_record
  Decorate with @gate.tool(mutates_state=True) to mock during replay.
  Proceeding will take real actions. Ctrl+C to cancel. [10s timeout]
```

The warning is designed to be impossible to miss. The timeout forces a conscious decision.

**8. Distributed context propagation — v0.1 primitive.**

`ContextVar` dies at network boundaries. Multi-service agent architectures (Router Agent → Researcher Agent over HTTP) will lose session context without propagation. We architect for this now.

V0.1: When `gate.wrap()` wraps an HTTP client (httpx, requests), it automatically injects the current session ID as `x-stateloom-session-id` on all outbound requests. Session IDs use W3C TraceContext-compatible format from day one for interoperability with OTel.

Manual extraction on the receiving service (v0.1):
```python
gate.set_session_id(request.headers["x-stateloom-session-id"])
```

V0.2 ships automatic extraction middleware for FastAPI/Flask/Django and Kafka/queue transport support. The v0.1 primitive makes v0.2 a non-breaking upgrade.

**9. Local dashboard.** Opens at `localhost:4781`. Session list, session detail with step-by-step call replay, cost timeline, PII detection log. Session detail screen includes the interactive replay UI (`mock_until_step` slider). Session events stored in local SQLite; configurable retention.

**10. Self-observability.** StateLoom emits OTel spans, Prometheus metrics, and a `/health` endpoint for its own operations. It shows up in your existing Datadog or Grafana setup. This is non-negotiable for anything that wants to live in production infrastructure.

---

### The SaaS Bridge: From Single-Player to Multi-Player

The local time-travel debugging feature is what gets developers to install the SDK. The following features are what get them — and their teams — to the hosted control plane.

**`gate.share()` — Shareable Sessions.**

Developer hits a weird LLM behavior, runs:

```python
gate.share(session="ticket-123")
# → https://app.stateloom.io/s/abc123
```

Before upload: automatic PII redaction applied to the session. Console warning lists what was redacted. The shared URL shows the scrubbed version. This is not optional — we cannot allow raw prompts containing customer PII to be shared to SaaS without the developer's explicit knowledge.

Teammate clicks the URL → views the session in the hosted dashboard. Or:

```bash
stateloom replay --url https://app.stateloom.io/s/abc123
```

Instantly reproduces the exact session state locally — same LLM responses, same tool outputs. Team can collaborate on debugging without re-running anything.

This is the moment the SDK infects the rest of the team. One developer shares a link; the whole team creates accounts to click it.

**`gate.pin()` + `stateloom test` — CI/CD Regression Testing.**

Developer runs their agent, it produces a correct result, they mark it:

```python
gate.pin(session="ticket-123", name="golden-run-v1")
# Pushes session to control plane as a named regression baseline
```

In GitHub Actions:

```yaml
- name: StateLoom regression suite
  run: stateloom test --suite golden-runs --mock-llm
```

StateLoom replays each pinned session using stored LLM responses as mocks. No live LLM calls — fast, free, deterministic. Checks that the agent's final output matches the expected result. If someone changes the system prompt or tool logic, the regression catches it.

Important caveat, logged to CI output: StateLoom flags sessions with detected non-determinism — `datetime.now()` calls, `random` module usage, live database reads via undecorated tools. "Warning: this session includes 2 non-deterministic execution paths. Regression confidence is reduced." Not a blocker, but honest.

This is the lock-in feature. Once the CI pipeline depends on the control plane for golden sessions, the team's SaaS subscription is load-bearing infrastructure.

---

### Control Plane (Hosted SaaS + Self-Hosted)

The SDK creates gravity. The control plane captures the value.

**Control plane features:**
- Centralized session dashboard across all services and teams
- Per-team cost attribution and budget management
- RBAC — who can view sessions, manage policies, pin regressions
- Compliance audit trail — immutable log of PII detections, budget enforcements, loop interventions
- Policy management UI — update rules without a code deploy
- Shared session storage and replay URLs
- CI/CD regression suite storage and execution history

**Deployment:** Hosted SaaS (app.stateloom.io) for most customers. Self-hosted Docker image + Helm chart for regulated industries. The self-hosted control plane ingests SDK telemetry and serves the dashboard from inside the customer's VPC. **It does not proxy LLM traffic.** The SDK remains the enforcement point.

For customers who require a network-layer proxy (specific compliance mandates): StateLoom is SDK-first. The self-hosted control plane satisfies "software in our VPC" for most regulated customers. Teams with hard network proxy requirements can combine StateLoom (session intelligence, developer tooling) with Portkey or LiteLLM (network gateway). We coexist in that stack.

**Note on the proxy path:** A network proxy as a separate StateLoom product is explicitly deferred to Year 3, when we have the engineering capacity to build it properly. This is a deliberate decision, not an oversight. We do not compete on two architectural fronts at seed stage.

---

### Policy Sync

Policies (PII rules, budget limits, loop detection thresholds) must be updatable without a `pip install --upgrade stateloom` across the customer's fleet.

Mechanism: the control plane serves a versioned, signed JSON policy bundle. SDKs poll it on startup and on a configurable interval, apply locally, cache the last known good policy. SDK enforcement logic lives in the SDK. The bundle configures it.

```json
{
  "version": "42",
  "signed_at": "2025-01-15T10:00:00Z",
  "policies": {
    "pii": {
      "default_mode": "audit",
      "rules": [
        { "pattern": "email", "mode": "audit" },
        { "pattern": "credit_card", "mode": "block" },
        { "pattern": "ssn", "mode": "block" },
        { "pattern": "api_key", "mode": "redact" }
      ]
    },
    "budget": { "per_session_usd": 5.00, "action": "hard_stop" },
    "loop": { "exact_threshold": 3, "semantic_threshold": 0.92 }
  }
}
```

If the control plane is unreachable: SDK falls back to last cached policy bundle and logs a warning. No policy = fails open (LLM calls pass through). The control plane being down cannot break production agent calls.

OPA/WASM deferred to v2.0, with explicit criteria: implement when customer feedback demonstrates need for programmable policy logic that cannot be expressed in JSON config parameters.

---

## Architecture Summary

```
┌─────────────────────────────────────────────────────┐
│                  Agent Application                  │
│                                                     │
│   client = gate.wrap(openai.OpenAI())               │
│   @gate.tool(mutates_state=True)                    │
│   def my_tool(): ...                                │
└──────────────────┬──────────────────────────────────┘
                   │ intercepts LLM calls + tool calls
┌──────────────────▼──────────────────────────────────┐
│                 StateLoom SDK                       │
│                                                     │
│  Session Manager (ContextVar + explicit session ID) │
│  ├── Cost tracker (synchronous, per-call)           │
│  ├── Budget enforcer (synchronous, <1ms check)      │
│  ├── PII scanner (regex, synchronous, <2ms)         │
│  ├── Cache lookup (exact match, synchronous, <1ms)  │
│  ├── Loop detector — exact (synchronous, <0.5ms)    │
│  ├── Loop detector — semantic (async worker)        │
│  ├── Tool call interceptor (@gate.tool decorator)   │
│  └── Header injector (x-stateloom-session-id)       │
│                                                     │
│  Local SQLite: session event log, replay state      │
│  Local dashboard: localhost:4781                    │
│  OTel/Prometheus: self-observability                │
└──────────────────┬──────────────────────────────────┘
                   │ telemetry, shared sessions, policies
┌──────────────────▼──────────────────────────────────┐
│              Control Plane (SaaS / Self-Hosted)     │
│                                                     │
│  Session storage + replay URLs (gate.share())       │
│  CI/CD regression suite (gate.pin())                │
│  Policy bundles (JSON, versioned, signed)           │
│  Centralized dashboard, RBAC, audit trail           │
└─────────────────────────────────────────────────────┘
```

**Critical path overhead budget:** <5ms per LLM call for synchronous operations. Async operations (semantic loop detection, Presidio audit scan) have no latency impact on the critical path.

**Fail-open guarantee:** If StateLoom throws any unhandled exception, the LLM call passes through unchanged. This is enforced at the `wrap()` boundary with a broad try/except and a logged error. We never break the application.

---

## What We Explicitly Do Not Do in V0.1

- **Network proxy.** We are not a network gateway. We do not sit between your application and OpenAI at the network layer. Year 3.
- **Arbitrary outbound HTTP interception.** We cannot enforce policies on `requests.post()` calls made directly in tool code we haven't wrapped. Document this boundary clearly; don't pretend it doesn't exist.
- **Automatic extraction middleware for distributed agents.** Header injection is v0.1. Automatic extraction middleware (FastAPI/Flask middleware, Kafka consumer interceptors) is v0.2.
- **Semantic cache.** Exact-match cache is v0.1. Semantic similarity cache (embedding-based) is deferred until we have real-world data on exact-match hit rates. Embedding overhead in the critical path is only justified if the hit rate data supports it.
- **Full tool-level destination-aware PII routing.** We enforce PII policies at LLM API call boundaries. We log what we see. We are explicit that tool calls to arbitrary internal services are outside our visibility scope without `@gate.tool()` decoration.
- **WASM/OPA policy engine.** JSON policy sync is sufficient for v1.0. OPA when customers demonstrate need for programmable policy logic.

---

## GTM Strategy

### The Bottoms-Up Motion

**Stage 1: Individual developer adoption.**
Lead with time-travel debugging. The README opens with: "When your 15-step agent fails on step 14, fix and re-test in 3 seconds instead of 2 minutes." The 5-minute wow is: run your agent, it fails, use `gate.replay()` to re-run from the failure point instantly. Cost visibility and PII detection are what developers discover after they're already hooked.

Distribution: GitHub, Hacker News, agent-focused Discord/Slack communities, targeted content for LangGraph/CrewAI/AutoGen users. Developer-focused, not enterprise-focused, in year 1.

**Stage 2: Team spread.**
`gate.share()` is the viral mechanism. One developer shares a session URL with a teammate. That teammate creates an account. Repeat across the team. The sharing feature is deliberately designed to be the first thing a developer reaches for when they want to explain a weird agent behavior in Slack.

**Stage 3: Enterprise lock-in.**
CI/CD regression testing via `gate.pin()` creates a load-bearing dependency on the control plane. Once the team's regression suite lives there, the SaaS subscription is infrastructure, not a nice-to-have. Budget limits and PII compliance are the features that get the security team and VP of Engineering to approve the budget for the team's existing SaaS usage.

### Enterprise Acquisition Path

Two distinct paths — not a funnel:

1. **SDK-first (primary):** Developers adopt SDK → team adopts via sharing → company adopts via CI/CD + compliance. Enterprise upsell: SDK + hosted or self-hosted control plane. No migration, no architectural change. The SDK they already have gets a control plane behind it.

2. **Control-plane-first (secondary):** Security/FinOps team evaluates StateLoom top-down for compliance and cost governance. They push SDK adoption to their development teams. Entry point is the self-hosted control plane, not the public dashboard.

The proxy is not a GTM path. It's a Year 3 product for a different segment.

---

## Open Risks (Honest Assessment)

**High priority:**

**`@gate.tool()` adoption rate.** The safety of time-travel replay and the quality of session context both depend on developers decorating their tool functions. We cannot force this. Mitigation: the warning for undecorated tools during replay is loud and hard to miss; the feature is compelling enough that developers will add the decorator to get it. But we should measure decoration rates in telemetry and optimize the onboarding experience to drive adoption.

**Monkey-patching fragility.** Auto-patching OpenAI/Anthropic works until their SDK internals change, which they do regularly. Mitigation: `wrap()` is the recommended production path; `init()` is scoped to local dev. We maintain a test suite that runs against the latest SDK versions in CI. Upstream breakages are our highest-priority bugs. We need a process for this before we have users.

**Non-determinism in CI/CD regression.** Agents with `datetime.now()`, `random`, or live external reads via undecorated tools will produce flaky regressions. Mitigation: StateLoom detects and flags these in CI output. Long-term: a general HTTP network interceptor (VCR-style) to mock all external I/O during replay. Not v0.1, but we should design the replay architecture so this is addable without breaking the public API.

**Medium priority:**

**Semantic loop detection false positives.** The async circuit-breaker model means semantic loop detection fires one call late. More importantly, the threshold calibration is unsolved — too sensitive and we trip legitimate agents; too permissive and we miss real loops. Mitigation: start with conservative defaults, make the threshold configurable, let early adopters tune it and share data.

**Policy sync availability dependency.** If the control plane is down, SDKs fall back to cached policy. But the first startup with no cached policy and a down control plane will use defaults. This needs to be documented and tested explicitly.

**Session boundary detection in multi-threaded services.** `ContextVar` works for async; multi-threaded code sharing sessions requires explicit session IDs. This is a documentation and API design problem as much as an engineering one. The explicit `gate.set_session_id()` API is the answer; the question is whether the ergonomics are good enough that developers reach for it naturally.

**Low priority / deferred:**

- Semantic cache hit rates in practice — theoretical argument, no real-world data. Don't build until we have it.
- Integration long tail — every weird LangChain configuration will produce bug reports. We need a clear public policy on what we officially support (OpenAI, Anthropic, major frameworks) vs. best-effort.
- Pricing model — deliberately unresolved. Hypothesis: per-seat developer tier + per-session volume tier for production. Need beta usage data to know what metric customers actually optimize for.

---

## V0.1 Public API Surface

```python
# Initialization
stateloom.init()                                    # dev mode, auto-patch, localhost dashboard
gate = StateLoom.from_config("stateloom.yaml")     # production

# Wrapping
client = gate.wrap(openai.OpenAI())                # wrap LLM client
client = gate.wrap(anthropic.Anthropic())
session = gate.wrap_session("session-id")          # explicit session context manager

# Tool decoration
@gate.tool(mutates_state=True)
@gate.tool(mutates_state=False)

# Session management
gate.set_session_id("session-id")                  # explicit session ID (for distributed)
gate.get_session_id()                              # current session ID

# Replay and sharing
gate.replay(session="id", mock_until_step=N)       # time-travel debugging
gate.share(session="id")                           # push to control plane, get URL
gate.pin(session="id", name="golden-run-v1")       # mark as regression baseline

# CLI
stateloom test --suite golden-runs --mock-llm      # run CI/CD regression suite
stateloom replay --url https://...                 # local replay from shared URL
```

---

## What Success Looks Like at 6 Months

- 500+ GitHub stars, active Discord with developers reporting real usage
- 10+ teams using `gate.pin()` / `stateloom test` in CI — meaning the SaaS dependency is real
- At least 3 unprompted "we found a bug in our agent using StateLoom replay" stories from developers
- First paying enterprise customers (even if small) using the hosted control plane
- Documented monkey-patch breakage rate <5% across OpenAI/Anthropic SDK versions
- `@gate.tool()` decoration rate >40% in active sessions (tracked via telemetry)

The product has succeeded if developers are saying "I don't want to build an agent without this" — not "this is a useful compliance tool."

---

*Built to be loved by developers first. Sold to enterprises second. In that order.*