# StateLoom SDK v0.1 — Full Implementation Plan

*Based on StateLoom Product Concept v3. Zero-touch, session-aware, fail-open.*

---

## 1. Design Principles

1. **Zero-touch by default** — `stateloom.init()` auto-patches everything. No decorators required for basic value.
2. **Fail-open everywhere** — Every patch boundary wrapped in try/except. StateLoom crash never breaks LLM calls.
3. **<5ms critical path** — Synchronous middleware stays under 5ms total. Heavy work (semantic loop detection, Presidio) runs async.
4. **Session-first** — Everything is scoped to sessions. No orphan events.
5. **Protocol over ABC** — All extension points use `typing.Protocol`. Duck typing, not inheritance.

---

## 2. Public API

```python
import stateloom

# Pattern 1: Zero-config (80% of users)
stateloom.init()
# Auto-patches OpenAI, Anthropic clients
# Opens dashboard at localhost:4781
# Console output for every LLM call

# Pattern 2: Config kwargs
stateloom.init(budget=10.0, pii=True, dashboard_port=8888)

# Pattern 3: YAML config (production)
gate = stateloom.StateLoom.from_config("stateloom.yaml")

# Pattern 4: Explicit wrap (no monkey-patching)
gate = stateloom.init(auto_patch=False)
client = gate.wrap(openai.OpenAI())

# Pattern 5: Session scoping
with stateloom.session("task-123", budget=5.0) as s:
    response = client.chat.completions.create(...)
    print(s.total_cost)

# Pattern 6: Tool decoration (opt-in for replay safety)
@stateloom.tool(mutates_state=True)
def create_ticket(title: str) -> dict: ...

@stateloom.tool(mutates_state=False)
def search_docs(query: str) -> list: ...

# Pattern 7: Time-travel debugging
stateloom.replay(session="ticket-123", mock_until_step=13)

# Pattern 8: Sharing & pinning (SaaS bridge)
stateloom.share(session="ticket-123")
stateloom.pin(session="ticket-123", name="golden-run-v1")

# Pattern 9: Distributed context
stateloom.set_session_id("session-id")
stateloom.get_session_id()
```

---

## 3. Project Structure

```
stateloom/
├── pyproject.toml
├── README.md
├── LICENSE                        # Apache 2.0
│
├── src/stateloom/
│   ├── __init__.py                # Public API surface
│   ├── _version.py                # Single version source
│   ├── gate.py                    # StateLoom singleton runtime
│   │
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py              # Pydantic BaseSettings
│   │   ├── session.py             # Session model + SessionManager
│   │   ├── context.py             # ContextVar-based async-safe tracking
│   │   ├── event.py               # Event models (LLMCall, ToolCall, etc.)
│   │   ├── types.py               # Enums, type aliases
│   │   └── errors.py              # Rich errors with help URLs
│   │
│   ├── intercept/
│   │   ├── __init__.py
│   │   ├── auto_patch.py          # Detect installed clients, patch all
│   │   ├── openai_patch.py        # OpenAI sync + async + streaming
│   │   ├── anthropic_patch.py     # Anthropic sync + async + streaming
│   │   ├── http_patch.py          # requests/httpx/aiohttp patching
│   │   ├── framework_patch.py     # LangChain/CrewAI/AutoGen session detection
│   │   └── unpatch.py             # Clean teardown for testing
│   │
│   ├── middleware/
│   │   ├── __init__.py
│   │   ├── base.py                # Middleware protocol
│   │   ├── pipeline.py            # Ordered chain executor
│   │   ├── cost_tracker.py        # Token counting + cost calc
│   │   ├── pii_scanner.py         # PII middleware (uses pii/)
│   │   ├── budget_enforcer.py     # Per-session hard stop
│   │   ├── cache.py               # Exact-match dedup/cache
│   │   ├── loop_detector.py       # Exact + async semantic
│   │   ├── latency_tracker.py     # Per-call timing
│   │   ├── context_injector.py    # Optional LLM context injection
│   │   └── event_recorder.py      # Persist events to store
│   │
│   ├── pii/
│   │   ├── __init__.py
│   │   ├── scanner.py             # Compiled regex scanner
│   │   ├── patterns.py            # Regex patterns + Luhn validator
│   │   └── rehydrator.py          # Mask outbound, rehydrate inbound
│   │
│   ├── replay/
│   │   ├── __init__.py
│   │   ├── engine.py              # Replay orchestrator
│   │   ├── step.py                # Step numbering + StepRecord model
│   │   └── safety.py              # Undecorated tool warnings, timeouts
│   │
│   ├── store/
│   │   ├── __init__.py
│   │   ├── base.py                # Store protocol
│   │   ├── sqlite_store.py        # SQLite + WAL mode (default)
│   │   └── memory_store.py        # In-memory (testing)
│   │
│   ├── pricing/
│   │   ├── __init__.py
│   │   ├── registry.py            # Model → price lookup
│   │   └── data/
│   │       └── prices.json        # Bundled pricing data
│   │
│   ├── export/
│   │   ├── __init__.py
│   │   ├── console.py             # Rich terminal output
│   │   ├── json_file.py           # JSONL file export
│   │   └── webhook.py             # Generic webhook alerts
│   │
│   ├── dashboard/
│   │   ├── __init__.py
│   │   ├── server.py              # FastAPI on background daemon thread
│   │   ├── api.py                 # REST endpoints
│   │   ├── ws.py                  # WebSocket live updates
│   │   └── static/
│   │       ├── index.html
│   │       ├── app.js             # Preact SPA (tiny bundle)
│   │       └── style.css
│   │
│   └── cli/
│       ├── __init__.py
│       └── main.py                # `stateloom test`, `stateloom replay`
│
├── tests/
│   ├── conftest.py                # Shared fixtures, mock LLM server
│   ├── test_core/
│   ├── test_intercept/
│   ├── test_middleware/
│   ├── test_pii/
│   ├── test_replay/
│   ├── test_store/
│   ├── test_dashboard/
│   └── test_integration/          # E2E with mock LLM servers
│
└── examples/
    ├── basic_openai.py
    ├── basic_anthropic.py
    ├── session_tracking.py
    ├── pii_detection.py
    ├── budget_enforcement.py
    ├── replay_debugging.py
    └── custom_middleware.py
```

---

## 4. Data Models

### 4.1 Config (Pydantic BaseSettings)

```python
class StateLoomConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="STATELOOM_")

    # Core
    auto_patch: bool = True
    fail_open: bool = True
    log_level: str = "INFO"

    # Dashboard
    dashboard: bool = True
    dashboard_port: int = 4781
    dashboard_host: str = "127.0.0.1"

    # Budget
    budget_per_session: float | None = None   # USD, None = unlimited
    budget_global: float | None = None
    budget_action: Literal["warn", "hard_stop"] = "hard_stop"

    # PII
    pii_enabled: bool = False
    pii_default_mode: Literal["audit", "redact", "block"] = "audit"
    pii_rules: list[PIIRule] = []

    # Cache
    cache_enabled: bool = True
    cache_max_size: int = 1000               # per session

    # Loop detection
    loop_exact_threshold: int = 3
    loop_semantic_enabled: bool = False
    loop_semantic_threshold: float = 0.92

    # Storage
    store_backend: Literal["sqlite", "memory"] = "sqlite"
    store_path: str = ".stateloom/data.db"
    store_retention_days: int = 30

    # Console
    console_output: bool = True
    console_verbose: bool = False

    # Context injection
    context_injection: bool = False

    @classmethod
    def from_yaml(cls, path: str) -> "StateLoomConfig": ...
```

### 4.2 Session

```python
@dataclass
class Session:
    id: str                            # UUID or user-provided
    name: str | None = None
    started_at: datetime = field(default_factory=datetime.utcnow)
    ended_at: datetime | None = None
    status: SessionStatus = SessionStatus.ACTIVE

    # Accumulators (updated in real-time)
    total_cost: float = 0.0
    total_tokens: int = 0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    call_count: int = 0
    cache_hits: int = 0
    cache_savings: float = 0.0
    pii_detections: int = 0

    # Step tracking for replay
    step_counter: int = 0
    events: list[Event] = field(default_factory=list)

    def next_step(self) -> int:
        self.step_counter += 1
        return self.step_counter
```

### 4.3 Events

```python
class EventType(str, Enum):
    LLM_CALL = "llm_call"
    TOOL_CALL = "tool_call"
    HTTP_CALL = "http_call"
    CACHE_HIT = "cache_hit"
    PII_DETECTION = "pii_detection"
    BUDGET_ENFORCEMENT = "budget_enforcement"
    LOOP_DETECTION = "loop_detection"

@dataclass
class Event:
    id: str
    session_id: str
    step: int
    event_type: EventType
    timestamp: datetime
    metadata: dict = field(default_factory=dict)

@dataclass
class LLMCallEvent(Event):
    event_type: EventType = EventType.LLM_CALL
    provider: str = ""                 # "openai" | "anthropic"
    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0
    latency_ms: float = 0.0
    is_streaming: bool = False
    request_hash: str = ""             # for cache/dedup
    # We do NOT store full prompt/response by default (privacy)
    # Opt-in: store_payloads=True in config

@dataclass
class ToolCallEvent(Event):
    event_type: EventType = EventType.TOOL_CALL
    tool_name: str = ""
    mutates_state: bool = False
    args_hash: str = ""
    result_hash: str = ""
    latency_ms: float = 0.0
    # Cached result stored for replay
    cached_result: Any = None

@dataclass
class PIIDetectionEvent(Event):
    event_type: EventType = EventType.PII_DETECTION
    pii_type: str = ""                 # "email", "credit_card", etc.
    mode: str = ""                     # "audit", "redact", "block"
    field: str = ""                    # which field contained PII
    action_taken: str = ""             # "logged", "redacted", "blocked"
```

### 4.4 Middleware Protocol

```python
class MiddlewareContext:
    event: Event
    session: Session
    config: StateLoomConfig
    store: Store
    request: dict                      # raw LLM request kwargs
    response: Any | None = None        # populated after LLM call

class Middleware(Protocol):
    async def process(
        self,
        ctx: MiddlewareContext,
        call_next: Callable[[MiddlewareContext], Awaitable[Any]],
    ) -> Any: ...
```

---

## 5. Auto-Patching System

### 5.1 How It Works

```
stateloom.init()
  → auto_patch.py: detect_installed_clients()
  → For each detected client:
      → Save original method reference
      → Replace with wrapped version
      → Log: "[StateLoom] Patched openai.ChatCompletions.create (sync+async+streaming)"
  → Return Gate singleton
```

### 5.2 OpenAI Patch (the template for all patches)

```python
# intercept/openai_patch.py

def patch_openai(gate: Gate) -> list[str]:
    """Patch OpenAI client. Returns list of patched method paths."""
    try:
        import openai
    except ImportError:
        return []

    patched = []
    original_create = openai.resources.chat.completions.Completions.create
    original_acreate = openai.resources.chat.completions.AsyncCompletions.create

    def wrapped_create(self, *args, **kwargs):
        try:
            return gate.pipeline.execute_sync(
                provider="openai",
                method="chat.completions.create",
                original=original_create,
                instance=self,
                args=args,
                kwargs=kwargs,
            )
        except Exception:
            if gate.config.fail_open:
                logger.error("[StateLoom] Middleware error, failing open", exc_info=True)
                return original_create(self, *args, **kwargs)
            raise

    # Similar for async and streaming variants
    openai.resources.chat.completions.Completions.create = wrapped_create
    patched.append("openai.ChatCompletions.create")
    return patched
```

### 5.3 Supported Patches (v0.1)

| Client | What's patched | Priority |
|--------|---------------|----------|
| **OpenAI** | `chat.completions.create` (sync, async, streaming) | P0 |
| **Anthropic** | `messages.create` (sync, async, streaming) | P0 |
| **httpx** | `Client.request`, `AsyncClient.request` — for session header injection | P1 |
| **requests** | `Session.request` — for session header injection | P1 |

Framework auto-detection (session boundary detection):

| Framework | Hook point | What it does |
|-----------|-----------|-------------|
| **LangChain** | Callback handler registration | Auto-creates session per chain.invoke() |
| **CrewAI** | Crew.kickoff() | Auto-creates session per crew run |
| **AutoGen** | GroupChat runtime | Auto-creates session per chat |

Framework patches are best-effort. If detection fails, sessions still work via explicit `stateloom.session()` or the default session.

### 5.4 Unpatch (for testing)

```python
# intercept/unpatch.py
def unpatch_all():
    """Restore all original methods. Used in test teardown."""
    for record in _patch_registry:
        setattr(record.target, record.method_name, record.original)
    _patch_registry.clear()
```

---

## 6. Middleware Pipeline

### 6.1 Execution Order

```
PRE-CALL (before LLM API call):
  1. PII Scanner       — scan request for PII, apply mode (audit/redact/block)
  2. Budget Enforcer   — check session spend against limit
  3. Cache Lookup      — exact-match check, return cached if hit
  4. Loop Detector     — exact-match hash check + async semantic queue
  5. Context Injector  — optionally append session context to system prompt

  → ACTUAL LLM CALL →

POST-CALL (after LLM API call):
  6. Cost Tracker      — count tokens, calculate cost, update session
  7. PII Scanner       — scan response for PII (audit mode only on responses)
  8. Latency Tracker   — record call duration
  9. Cache Writer      — store request→response for future cache hits
  10. Event Recorder   — persist event to SQLite
  11. Console Output   — print Rich one-liner to terminal
  12. WebSocket Push   — notify dashboard of new event
```

### 6.2 Pipeline Executor

```python
class Pipeline:
    def __init__(self, middlewares: list[Middleware]):
        self.middlewares = middlewares

    async def execute(self, ctx: MiddlewareContext) -> Any:
        """Execute middleware chain. Each middleware calls call_next to continue."""
        async def build_chain(index: int):
            if index >= len(self.middlewares):
                # Terminal: make the actual LLM call
                return await self._call_llm(ctx)
            return await self.middlewares[index].process(
                ctx, lambda c: build_chain(index + 1)
            )
        return await build_chain(0)

    def execute_sync(self, **kwargs) -> Any:
        """Sync wrapper for use in monkey-patched sync methods."""
        # Uses asyncio.run() or gets/creates event loop
        ...
```

### 6.3 Streaming Support

Streaming requires special handling — tokens arrive incrementally.

```python
# For streaming responses, the pipeline:
# 1. Runs pre-call middleware synchronously (PII, budget, cache, loop)
# 2. Returns a wrapped iterator/async iterator
# 3. The wrapper accumulates chunks and runs post-call middleware on completion
# 4. If the stream is a cache hit, yields cached chunks immediately

class StreamingResponseWrapper:
    """Wraps an OpenAI/Anthropic stream to intercept chunks."""

    def __init__(self, original_stream, ctx: MiddlewareContext, pipeline: Pipeline):
        self._stream = original_stream
        self._ctx = ctx
        self._chunks = []

    def __iter__(self):
        for chunk in self._stream:
            self._chunks.append(chunk)
            yield chunk
        # Stream complete — run post-call middleware
        self._ctx.response = self._reconstruct_response()
        asyncio.run(pipeline._run_post_call(self._ctx))
```

---

## 7. PII Engine

### 7.1 Patterns (compiled regex)

```python
# pii/patterns.py

PII_PATTERNS = {
    "email": re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"),
    "credit_card": re.compile(r"\b(?:\d[ -]*?){13,19}\b"),  # + Luhn validation
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "phone_us": re.compile(r"\b(?:\+1[-.]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"),
    "api_key_openai": re.compile(r"\bsk-[a-zA-Z0-9]{20,}\b"),
    "api_key_anthropic": re.compile(r"\bsk-ant-[a-zA-Z0-9-]{20,}\b"),
    "api_key_aws": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "api_key_bearer": re.compile(r"\bBearer\s+[a-zA-Z0-9\-._~+/]+=*\b"),
    "ip_address": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}

def luhn_check(number: str) -> bool:
    """Validate credit card number using Luhn algorithm."""
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13:
        return False
    checksum = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0
```

### 7.2 Scanner

```python
# pii/scanner.py

@dataclass
class PIIMatch:
    pattern_name: str
    matched_text: str
    start: int
    end: int
    field: str                         # "messages[0].content", "system", etc.

class PIIScanner:
    def __init__(self, config: StateLoomConfig):
        self._patterns = self._compile_active_patterns(config)

    def scan(self, text: str, field: str = "") -> list[PIIMatch]:
        """Scan text for PII. Returns list of matches. <2ms for typical prompts."""
        matches = []
        for name, pattern in self._patterns.items():
            for m in pattern.finditer(text):
                # Extra validation for credit cards
                if name == "credit_card" and not luhn_check(m.group()):
                    continue
                matches.append(PIIMatch(
                    pattern_name=name,
                    matched_text=m.group(),
                    start=m.start(),
                    end=m.end(),
                    field=field,
                ))
        return matches
```

### 7.3 Rehydrator (for redact mode)

```python
# pii/rehydrator.py

class PIIRehydrator:
    """Maintains a session-scoped mapping of placeholder → original value."""

    def __init__(self):
        self._map: dict[str, str] = {}  # placeholder → original
        self._counter: int = 0

    def redact(self, text: str, matches: list[PIIMatch]) -> str:
        """Replace PII matches with placeholders. Returns redacted text."""
        # Process matches in reverse order (to preserve indices)
        for match in sorted(matches, key=lambda m: m.start, reverse=True):
            placeholder = f"[{match.pattern_name.upper()}_{self._counter}]"
            self._map[placeholder] = match.matched_text
            text = text[:match.start] + placeholder + text[match.end:]
            self._counter += 1
        return text

    def rehydrate(self, text: str) -> str:
        """Replace placeholders with original values in LLM response."""
        for placeholder, original in self._map.items():
            text = text.replace(placeholder, original)
        return text
```

---

## 8. Replay Engine

### 8.1 Step Numbering

Every intercepted call (LLM call, @gate.tool() call) gets a monotonically increasing step number within its session. Steps are assigned at interception time, before the middleware pipeline runs.

```python
# replay/step.py

@dataclass
class StepRecord:
    step: int
    event_type: EventType              # LLM_CALL or TOOL_CALL
    request_hash: str
    cached_response: Any               # stored for replay
    tool_name: str | None = None
    mutates_state: bool = False
    provider: str | None = None
    model: str | None = None
```

### 8.2 Replay Orchestrator

```python
# replay/engine.py

class ReplayEngine:
    def __init__(self, gate: Gate, session_id: str, mock_until_step: int):
        self.gate = gate
        self.session_id = session_id
        self.mock_until_step = mock_until_step
        self._steps = self._load_steps(session_id)

    def _load_steps(self, session_id: str) -> list[StepRecord]:
        """Load recorded steps from store."""
        return self.gate.store.get_session_steps(session_id)

    def should_mock(self, current_step: int) -> bool:
        return current_step <= self.mock_until_step

    def get_cached_response(self, step: int) -> Any:
        """Return cached response for a mocked step."""
        record = self._steps[step - 1]
        return record.cached_response

    def check_safety(self) -> list[SafetyWarning]:
        """Check for undecorated tool calls in the replay range."""
        warnings = []
        for step in self._steps[:self.mock_until_step]:
            if step.event_type == EventType.TOOL_CALL and step.tool_name is None:
                warnings.append(SafetyWarning(
                    step=step.step,
                    message=f"Step {step.step} is an untracked tool execution that will RE-EXECUTE during replay.",
                ))
        return warnings
```

### 8.3 Safety Warnings

When `gate.replay()` is called, the engine:
1. Loads all steps for the session
2. Checks for undecorated tool calls in the mock range
3. If any exist, prints a loud warning with 10s timeout:

```
[StateLoom] ⚠ REPLAY WARNING: Steps 4, 7 include untracked tool executions.
  These functions will RE-EXECUTE during replay:
    step 4: create_jira_ticket (detected: HTTP POST in body)
    step 7: delete_record
  Decorate with @gate.tool(mutates_state=True) to mock during replay.
  Proceeding will take real actions. Ctrl+C to cancel. [10s timeout]
```

---

## 9. SQLite Store

### 9.1 Schema

```sql
-- Sessions table
CREATE TABLE sessions (
    id TEXT PRIMARY KEY,
    name TEXT,
    started_at TEXT NOT NULL,          -- ISO 8601
    ended_at TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    total_cost REAL NOT NULL DEFAULT 0.0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    total_prompt_tokens INTEGER NOT NULL DEFAULT 0,
    total_completion_tokens INTEGER NOT NULL DEFAULT 0,
    call_count INTEGER NOT NULL DEFAULT 0,
    cache_hits INTEGER NOT NULL DEFAULT 0,
    cache_savings REAL NOT NULL DEFAULT 0.0,
    pii_detections INTEGER NOT NULL DEFAULT 0,
    metadata TEXT                       -- JSON blob
);

-- Events table (append-only log)
CREATE TABLE events (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES sessions(id),
    step INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    provider TEXT,
    model TEXT,
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    total_tokens INTEGER,
    cost REAL,
    latency_ms REAL,
    is_streaming INTEGER,
    request_hash TEXT,
    tool_name TEXT,
    mutates_state INTEGER,
    pii_type TEXT,
    pii_mode TEXT,
    pii_field TEXT,
    cached_response BLOB,              -- pickle for replay
    metadata TEXT                       -- JSON blob
);

-- Indexes for common queries
CREATE INDEX idx_events_session ON events(session_id);
CREATE INDEX idx_events_type ON events(event_type);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_sessions_status ON sessions(status);
CREATE INDEX idx_sessions_started ON sessions(started_at);

-- Step records for replay
CREATE TABLE step_records (
    session_id TEXT NOT NULL REFERENCES sessions(id),
    step INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    request_hash TEXT,
    cached_response BLOB,
    tool_name TEXT,
    mutates_state INTEGER,
    provider TEXT,
    model TEXT,
    PRIMARY KEY (session_id, step)
);
```

### 9.2 SQLite Configuration

```python
# store/sqlite_store.py

class SQLiteStore:
    def __init__(self, path: str = ".stateloom/data.db"):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")     # concurrent reads
        self.conn.execute("PRAGMA synchronous=NORMAL")   # faster writes
        self.conn.execute("PRAGMA busy_timeout=5000")    # 5s retry on lock
        self._create_tables()
        self._lock = threading.Lock()                    # serialize writes

    def save_event(self, event: Event) -> None: ...
    def get_session(self, session_id: str) -> Session | None: ...
    def get_session_events(self, session_id: str) -> list[Event]: ...
    def get_session_steps(self, session_id: str) -> list[StepRecord]: ...
    def list_sessions(self, limit: int = 100, offset: int = 0) -> list[Session]: ...
    def cleanup(self, retention_days: int = 30) -> int: ...
```

---

## 10. Dashboard

### 10.1 Server Lifecycle

```python
# dashboard/server.py

class DashboardServer:
    def __init__(self, gate: Gate):
        self.gate = gate
        self.app = self._create_app()
        self._thread: threading.Thread | None = None

    def start(self):
        """Start dashboard on background daemon thread."""
        self._thread = threading.Thread(
            target=self._run_uvicorn,
            daemon=True,
            name="stateloom-dashboard",
        )
        self._thread.start()
        logger.info(f"[StateLoom] Dashboard at http://{self.gate.config.dashboard_host}:{self.gate.config.dashboard_port}")

    def _create_app(self) -> FastAPI:
        app = FastAPI(title="StateLoom Dashboard")
        app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
        app.include_router(api_router)
        app.add_api_websocket_route("/ws", websocket_handler)
        return app
```

### 10.2 REST Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/sessions` | List sessions (paginated, filterable) |
| GET | `/api/sessions/{id}` | Session detail with summary stats |
| GET | `/api/sessions/{id}/events` | Events for a session (paginated) |
| GET | `/api/sessions/{id}/steps` | Step records for replay UI |
| GET | `/api/stats` | Global stats: total cost, calls, savings |
| GET | `/api/stats/cost-by-model` | Cost breakdown by model |
| GET | `/api/stats/cost-over-time` | Time series cost data |
| GET | `/api/pii` | PII detection log |
| GET | `/api/health` | Health check |

### 10.3 WebSocket Protocol

```python
# dashboard/ws.py

# Client connects to ws://localhost:4781/ws
# Server pushes events as they happen:

{
    "type": "new_event",
    "data": {
        "session_id": "ticket-123",
        "step": 5,
        "event_type": "llm_call",
        "model": "gpt-4o",
        "cost": 0.013,
        "latency_ms": 1234,
        "tokens": 847
    }
}

{
    "type": "session_update",
    "data": {
        "session_id": "ticket-123",
        "total_cost": 0.087,
        "call_count": 5,
        "status": "active"
    }
}

{
    "type": "alert",
    "data": {
        "level": "warning",
        "message": "Loop detected in session ticket-123",
        "session_id": "ticket-123"
    }
}
```

### 10.4 Dashboard Screens (v0.1)

| Screen | Key Elements |
|--------|-------------|
| **Live Overview** | Active sessions list, real-time cost ticker, live event stream, alert banners |
| **Session Explorer** | Sortable table: session ID, status, cost, duration, calls, PII detections. Click → detail |
| **Session Detail** | Step-by-step timeline, expandable request/response, cost graph, replay slider (mock_until_step), "Export as Markdown" button |
| **Cost Analytics** | Cost by model (pie chart), cost over time (line), savings counter, token breakdown |
| **PII Monitor** | PII detection log with type, mode, action, timestamp. Counter: "X items detected" |

**UI stack**: Preact for reactivity, minimal CSS (dark mode default), WebSocket for real-time updates. Pre-built and bundled as static files — no Node.js required for users.

---

## 11. Console Output

```python
# export/console.py

from rich.console import Console
from rich.text import Text

console = Console()

def print_event(event: Event):
    """Print a single-line summary of an event to terminal."""
    if isinstance(event, LLMCallEvent):
        line = Text()
        line.append("[StateLoom] ", style="bold cyan")
        line.append("✓ ", style="green")
        line.append(f"{event.model} ", style="bold")
        line.append(f"| {event.total_tokens} tok ", style="dim")
        line.append(f"| ${event.cost:.3f} ", style="yellow")
        line.append(f"| {event.latency_ms:.0f}ms ", style="dim")
        line.append(f"| session:{event.session_id[:20]}", style="blue")
        console.print(line)

# Output examples:
# [StateLoom] ✓ gpt-4o | 847 tok | $0.013 | 1200ms | session:ticket-123
# [StateLoom] ⚡ CACHE HIT | exact match | saved $0.013
# [StateLoom] ⚠ PII DETECTED (logged) | type:email | field:user_message
# [StateLoom] 🔁 LOOP DETECTED | tool:web_search | calls:3 | action:flagged
# [StateLoom] 🛑 BUDGET ENFORCED | limit:$5.00 | spent:$5.02 | action:hard_stop
# [StateLoom] 🛑 PII BLOCKED | type:credit_card | session:ticket-123
```

---

## 12. Context Injection (Optional)

When `context_injection=True`, the middleware appends a brief context block to the system prompt:

```python
# middleware/context_injector.py

class ContextInjector:
    async def process(self, ctx: MiddlewareContext, call_next):
        if ctx.config.context_injection:
            budget_info = ""
            if ctx.session.budget:
                remaining = ctx.session.budget - ctx.session.total_cost
                budget_info = f" Budget remaining: ${remaining:.2f}."

            context_block = (
                f"\n\n[StateLoom Context] Session: {ctx.session.id}. "
                f"Step: {ctx.session.step_counter}.{budget_info}"
            )
            # Append to system message
            self._inject_system_context(ctx.request, context_block)

        return await call_next(ctx)
```

This is **off by default**. When enabled, LLMs can see their budget remaining and session step count, which can influence their behavior (e.g., being more concise when budget is low).

---

## 13. Dependencies

```toml
# pyproject.toml

[project]
name = "stateloom"
version = "0.1.0"
requires-python = ">=3.10"
description = "The first stateful AI gateway. Session-aware middleware for LLM agents."
license = "Apache-2.0"

dependencies = [
    "pydantic>=2.0",
    "pydantic-settings>=2.0",
    "wrapt>=1.16",
    "rich>=13.0",
    "fastapi>=0.104",
    "uvicorn[standard]>=0.24",
    "websockets>=12.0",
    "tiktoken>=0.5",
    "httpx>=0.25",
    "pyyaml>=6.0",
]

[project.optional-dependencies]
presidio = ["presidio-analyzer>=2.2", "presidio-anonymizer>=2.2"]
langchain = ["langchain-core>=0.1"]
all = ["stateloom[presidio]", "stateloom[langchain]"]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
    "pytest-cov>=4.0",
    "ruff>=0.1",
    "mypy>=1.5",
    "respx>=0.20",                    # mock httpx
]

[project.scripts]
stateloom = "stateloom.cli.main:cli"

[tool.ruff]
target-version = "py310"
line-length = 100

[tool.mypy]
python_version = "3.10"
strict = true

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
```

---

## 14. Implementation Phases

### Phase 1: Skeleton + Core (Week 1)

**Goal:** Project runs, imports, has config and session tracking.

- `pyproject.toml` with all deps, ruff, mypy, pytest config
- `src/stateloom/__init__.py` — public API stubs
- `src/stateloom/gate.py` — Gate singleton
- `core/config.py` — StateLoomConfig with all settings
- `core/session.py` — Session dataclass + SessionManager
- `core/context.py` — ContextVar session tracking
- `core/event.py` — Event models
- `core/types.py` — Enums
- `core/errors.py` — StateLoomError, StateLoomPIIBlockedError, StateLoomLoopError, StateLoomBudgetError
- `store/base.py` — Store protocol
- `store/memory_store.py` — In-memory store for testing
- Unit tests for config, session, context, events

**Deliverable:** `stateloom.init()` runs without error, creates a Gate with config and session manager.

### Phase 2: Interception Layer (Week 1-2)

**Goal:** OpenAI and Anthropic calls are intercepted.

- `intercept/openai_patch.py` — sync, async, streaming
- `intercept/anthropic_patch.py` — sync, async, streaming
- `intercept/auto_patch.py` — detect and patch installed clients
- `intercept/unpatch.py` — teardown for tests
- `middleware/base.py` — Middleware protocol
- `middleware/pipeline.py` — Chain executor (sync + async)
- Streaming wrapper for both providers
- Unit tests with mock LLM responses
- Integration test: `stateloom.init()` → `openai.chat.completions.create()` → event captured

**Deliverable:** LLM calls pass through StateLoom and events are recorded. Fail-open works.

### Phase 3: Cost + Latency Tracking (Week 2)

**Goal:** Every LLM call shows cost and latency.

- `pricing/registry.py` — Model price lookup
- `pricing/data/prices.json` — Bundled pricing for OpenAI + Anthropic models
- `middleware/cost_tracker.py` — Token counting (tiktoken for OpenAI, response headers for Anthropic)
- `middleware/latency_tracker.py` — Per-call timing
- `export/console.py` — Rich terminal output
- Session cost accumulators
- Unit tests for pricing, cost calculation

**Deliverable:** Terminal shows `[StateLoom] ✓ gpt-4o | 847 tok | $0.013 | 1.2s` after every call.

### Phase 4: SQLite Store (Week 2-3)

**Goal:** Events persist across process restarts.

- `store/sqlite_store.py` — Full SQLite implementation with WAL mode
- Schema creation, indexes
- `middleware/event_recorder.py` — Persist events to store
- Retention cleanup
- Step record storage for replay
- Unit tests for store operations

**Deliverable:** Session data survives process restart. `stateloom.init()` loads previous sessions.

### Phase 5: PII Engine (Week 3)

**Goal:** PII detection with audit/redact/block modes.

- `pii/patterns.py` — Compiled regex patterns + Luhn validation
- `pii/scanner.py` — PIIScanner with <2ms scan time
- `pii/rehydrator.py` — Mask and rehydrate for redact mode
- `middleware/pii_scanner.py` — Middleware integration
- Console output for PII events
- Unit tests for each pattern, false positive testing

**Deliverable:** PII detected in prompts, console shows `[StateLoom] ⚠ PII DETECTED | type:email`. Block mode raises `StateLoomPIIBlockedError`.

### Phase 6: Budget + Cache + Loop Detection (Week 3-4)

**Goal:** Active intervention features work.

- `middleware/budget_enforcer.py` — Session budget hard stop
- `middleware/cache.py` — Exact-match request cache with savings tracking
- `middleware/loop_detector.py` — Exact-match loop detection (synchronous)
- Console output for budget/cache/loop events
- Unit tests for each middleware

**Deliverable:** Budget stops sessions at limit. Cache returns instant results for duplicate prompts. Loop detector flags repeated calls.

### Phase 7: Replay Engine (Week 4-5)

**Goal:** Time-travel debugging works end-to-end.

- `replay/step.py` — StepRecord model, step numbering
- `replay/engine.py` — ReplayEngine orchestrator
- `replay/safety.py` — Undecorated tool warnings + timeout
- `@gate.tool()` decorator implementation
- Replay integration with middleware pipeline
- Integration test: run agent → replay from step N → verify mocked steps + live steps

**Deliverable:** `gate.replay(session="id", mock_until_step=13)` works. Steps 1-13 return cached results instantly, step 14+ runs live.

### Phase 8: Dashboard (Week 5-6)

**Goal:** Local dashboard shows live session data.

- `dashboard/server.py` — FastAPI + background daemon thread
- `dashboard/api.py` — All REST endpoints
- `dashboard/ws.py` — WebSocket live event push
- Frontend: `index.html`, `app.js`, `style.css`
  - Live Overview screen
  - Session Explorer screen
  - Session Detail screen (with replay slider)
  - Cost Analytics screen
  - PII Monitor screen
- Integration test: start dashboard → make LLM calls → verify WebSocket events arrive

**Deliverable:** `stateloom.init()` opens dashboard at localhost:4781 with live data.

### Phase 9: HTTP Patching + Framework Detection (Week 6)

**Goal:** HTTP calls get session headers, frameworks get auto-sessions.

- `intercept/http_patch.py` — requests/httpx header injection
- `intercept/framework_patch.py` — LangChain/CrewAI/AutoGen session detection
- `middleware/context_injector.py` — Optional LLM context injection
- Unit tests for header injection
- Integration test with LangChain chain

**Deliverable:** Outbound HTTP calls include `x-stateloom-session-id`. LangChain chains auto-create sessions.

### Phase 10: Polish + Ship (Week 6+)

**Goal:** Ready for PyPI and public launch.

- `__init__.py` — Clean public API, `__all__` exports
- `cli/main.py` — `stateloom test` and `stateloom replay` commands
- `export/json_file.py` — JSONL export
- `export/webhook.py` — Webhook alerts
- All examples in `examples/`
- README with installation, quickstart, GIF demo
- Comprehensive integration tests
- `pip install .` smoke test in clean venv
- Publish to PyPI as `stateloom`

**Deliverable:** `pip install stateloom` works. New user goes from install to live dashboard in <5 minutes.

---

## 15. Test Strategy

### Unit Tests (per module)

```python
# tests/test_pii/test_scanner.py
def test_detects_email():
    scanner = PIIScanner(config)
    matches = scanner.scan("Contact john@example.com for details")
    assert len(matches) == 1
    assert matches[0].pattern_name == "email"

def test_credit_card_luhn_validation():
    scanner = PIIScanner(config)
    # Valid card number
    matches = scanner.scan("Card: 4111 1111 1111 1111")
    assert len(matches) == 1
    # Invalid card number (fails Luhn)
    matches = scanner.scan("ID: 1234 5678 9012 3456")
    assert len(matches) == 0

def test_scan_performance():
    """PII scan must complete in <2ms for typical prompt length."""
    scanner = PIIScanner(config)
    text = "A" * 10000  # 10KB text
    start = time.perf_counter()
    scanner.scan(text)
    elapsed = (time.perf_counter() - start) * 1000
    assert elapsed < 2.0
```

### Integration Tests

```python
# tests/test_integration/test_openai_e2e.py
def test_openai_call_intercepted(mock_openai_server):
    """Full E2E: init → make call → verify event stored."""
    stateloom.init(auto_patch=True, store_backend="memory")
    client = openai.OpenAI(base_url=mock_openai_server.url)
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )
    gate = stateloom._gate
    sessions = gate.store.list_sessions()
    assert len(sessions) == 1
    events = gate.store.get_session_events(sessions[0].id)
    assert len(events) == 1
    assert events[0].model == "gpt-4o"
    assert events[0].cost > 0

def test_fail_open(mock_openai_server):
    """If middleware throws, LLM call still succeeds."""
    class BrokenMiddleware:
        async def process(self, ctx, call_next):
            raise RuntimeError("middleware crashed")

    stateloom.init(auto_patch=True)
    # Inject broken middleware
    stateloom._gate.pipeline.middlewares.insert(0, BrokenMiddleware())
    client = openai.OpenAI(base_url=mock_openai_server.url)
    # Should not raise
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )
    assert response.choices[0].message.content is not None
```

### Replay Tests

```python
# tests/test_replay/test_engine.py
def test_replay_mocks_until_step():
    """Steps up to mock_until_step return cached, rest run live."""
    gate = setup_gate_with_recorded_session(steps=15)
    engine = ReplayEngine(gate, session_id="test", mock_until_step=13)

    for step in range(1, 14):
        assert engine.should_mock(step) is True
    for step in range(14, 16):
        assert engine.should_mock(step) is False

def test_replay_safety_warns_undecorated_tools():
    """Undecorated tool calls in replay range trigger warning."""
    gate = setup_gate_with_undecorated_tools()
    engine = ReplayEngine(gate, session_id="test", mock_until_step=10)
    warnings = engine.check_safety()
    assert len(warnings) > 0
```

### Coverage Target

- **Unit tests:** >80% line coverage
- **Integration tests:** Cover all supported LLM providers (OpenAI, Anthropic) × (sync, async, streaming)
- **Performance tests:** Verify <5ms critical path overhead
- **Fail-open tests:** Verify middleware errors never break LLM calls

---

## 16. Post-V0.1 Roadmap (not in scope, but designed for)

| Feature | Version | Why deferred |
|---------|---------|-------------|
| Semantic loop detection (async worker) | v0.2 | Needs embedding model dependency |
| Automatic framework extraction middleware | v0.2 | FastAPI/Flask/Django middleware |
| `gate.share()` + `gate.pin()` (SaaS) | v0.2 | Requires control plane backend |
| Prompt injection detection | v0.2 | Research-quality, not production-ready |
| Semantic cache | v0.3 | Need exact-match hit rate data first |
| OPA/WASM policy engine | v1.0 | JSON config sufficient for now |
| Network proxy mode | v3.0 | Different architectural bet |
