# StateLoom: Agent-Aware Middleware Layer

## The Core Insight

Existing tools like LiteLLM, Portkey, and Bifrost operate at the **LLM call level** — they proxy individual API requests. PII tools like Presidio work in isolation. Observability tools like LangFuse trace after the fact. **Nobody has built a middleware that understands agent-level semantics** — sessions, goals, tool chains, multi-step reasoning, and multi-agent coordination.

This middleware sits between **agents and everything they touch** (LLM APIs, tools, databases, external services, other agents) and operates with full awareness of the agent's session context.

---

## Detailed Feature Breakdown

### 1. Cost Management & Optimization

**The problem**: A single agentic session can silently burn $5-50 in API calls. Teams have no per-task budget controls, and agents frequently re-ask questions they already have answers to.

**What the middleware does**:

- **Session-level budgets**: Set a max spend per agent session, per user, per team, or per task type. Kill switch when budget is hit (configurable: hard stop vs. graceful degradation to cheaper model).
- **Semantic caching**: Not just exact-match caching — use embedding similarity to detect when an agent is asking a functionally equivalent question it already asked 3 turns ago. Return the cached result. Research on scaling agent systems shows multi-agent systems amplify redundancy — this directly addresses that.
- **Redundant tool-call detection**: Track the tool calls an agent has made in a session. If it calls the same API/tool with the same or near-identical parameters, intercept and return the prior result. Flag the pattern in logs.
- **Smart model routing**: Based on the complexity of the current sub-task (detected via prompt analysis), route to an appropriate model tier. Simple extraction? Use a smaller model. Complex reasoning? Use a frontier model. This is configurable via policies, not hardcoded.
- **Cost attribution & chargeback**: Tag every token spent with metadata — which agent, which user, which project, which task. Export to billing systems. Enterprises need this for internal chargeback.
- **Token waste analysis**: Post-session reports showing wasted tokens — retries that could have been avoided, overly verbose system prompts, unnecessary context stuffing.

### 2. PII & Sensitive Data Protection

**The problem**: Agents ingest and emit data constantly. A customer support agent might send a user's SSN to an LLM API. A code agent might send proprietary source code to a third-party tool.

**What the middleware does**:

- **Bi-directional PII scanning**: Inspect both inputs (what goes to the LLM/tool) and outputs (what comes back). Detect PII types: SSN, credit cards, emails, phone numbers, addresses, API keys, passwords, medical data, etc.
- **Policy-based actions**: Per PII type, configure: redact, mask (replace with placeholder that can be re-hydrated), block (kill the request), or alert-only. Different policies per environment (dev vs. prod).
- **Contextual re-hydration**: When PII is masked outbound, the middleware stores the mapping. When the LLM responds referencing `[MASKED_EMAIL_1]`, the middleware re-hydrates it before returning to the user. The LLM never sees real PII but the end-user gets a coherent response.
- **Data residency rules**: Route requests to region-specific LLM endpoints based on the data's origin. EU user data only goes to EU-hosted models.
- **Proprietary code/IP detection**: Detect when agents are about to send code snippets, internal docs, or other IP to external services. Flag or block based on policy. As agents increasingly analyze codebases (as demonstrated by recent research on agentic code reasoning), they'll handle proprietary code constantly.
- **Audit trail**: Immutable log of every piece of data that crossed the boundary, what was detected, what action was taken. Exportable for compliance (SOC2, HIPAA, GDPR).

### 3. Redundancy & Efficiency (Agent-Aware)

**The problem**: Research on scaling agent systems demonstrates that multi-agent systems amplify errors 4-17x depending on topology. Agents also frequently repeat work — re-reading files they already read, re-searching for information they already found, making circular reasoning loops.

**What the middleware does**:

- **Session-aware deduplication**: Track all LLM calls and tool invocations within an agent session. Detect exact and semantic duplicates. Configurable: auto-deduplicate, or flag + let the agent decide.
- **Cross-agent deduplication**: In multi-agent setups, detect when Agent B is about to ask the same question Agent A already resolved. Share the cached result (with configurable sharing policies).
- **Loop detection**: Detect when an agent is stuck in a retry loop or circular reasoning pattern (e.g., alternating between two approaches). Alert and optionally break the loop with a configurable strategy (inject a "step back" prompt, escalate to human, try a different model).
- **Coordination overhead monitoring**: Track the overhead ratio — how much of the total cost is coordination vs. actual task work. Alert when overhead exceeds thresholds. Recommend topology changes (research shows centralized beats independent for parallelizable tasks, but sequential reasoning degrades in all multi-agent variants).
- **Tool-call optimization**: If an agent makes 5 separate API calls that could be batched into 1, detect the pattern and suggest/apply batching.

### 4. Observability & Visibility

**The problem**: Today, debugging a failing agent session means grep-ing through logs. There's no structured way to understand what an agent did, why it made each decision, and where it went wrong.

**What the middleware does**:

- **Structured trace format**: Every agent session produces a structured trace — a DAG of decisions, LLM calls, tool invocations, and results. Each node has: timestamp, token cost, latency, input/output (redacted per policy), and the agent's stated reasoning.
- **Session replay**: Replay an agent session step-by-step in a UI. See exactly what the agent saw, what it decided, and what happened. This is the "browser DevTools" for agents.
- **Live dashboards**: Real-time view of all running agent sessions. Filter by user, team, agent type, status. See cost accumulation in real-time. Spot runaway sessions immediately.
- **Diff view for agent behavior**: Compare two sessions side-by-side. Useful for debugging regressions — "why did the agent handle this ticket differently today vs. yesterday?"
- **Quality metrics**: Track agent task success rate, average cost per task, average latency, tool error rates, human escalation rates. Trend over time.
- **Reasoning quality scoring**: Score the agent's reasoning chain — did it construct proper premises, trace execution paths, arrive at supported conclusions? Flag sessions where reasoning was sloppy (jumped to conclusions, skipped cases). Inspired by research on semi-formal reasoning for agentic code analysis.

### 5. Alerting & Integration

**The problem**: When an agent goes rogue (burns $200, leaks PII, gets stuck in a loop), nobody finds out until it's too late.

**What the middleware does**:

- **Native integrations**: Slack, PagerDuty, OpsGenie, Datadog, Grafana, Splunk, Teams, email, webhooks. Not just "we can send a webhook" — proper first-class integrations with rich alert formatting.
- **Alert rule engine**: Configurable rules with conditions:
  - Cost > $X in Y minutes
  - PII detected in outbound request
  - Agent session duration > Z minutes
  - Error rate > N% over last M requests
  - Loop detected (same tool called > K times)
  - New agent pattern never seen before (anomaly)
- **Escalation policies**: Alert → auto-pause agent → escalate to human → kill session. Configurable per severity.
- **Anomaly detection**: Baseline normal agent behavior, alert on deviations. An agent that usually costs $0.50/task suddenly costs $5? Alert. An agent that never accesses the payments database suddenly does? Alert.
- **Compliance alerts**: PII detected but policy says "alert only"? Send to compliance channel. Data residency violation? Immediate alert to DPO.

### 6. Guardrails & Policy Engine

**The problem**: Agents need boundaries, but those boundaries need to be flexible, composable, and maintainable — not hardcoded prompt instructions that the LLM can ignore.

**What the middleware does**:

- **Declarative policy language**: Define policies as code (YAML/JSON or a DSL). Example:

```
policy: production-customer-agent
rules:
  - scope: outbound_llm
    block_if: contains_pii(["ssn", "credit_card"])
  - scope: tool_call
    block_if: tool == "database.delete"
    alert: pagerduty/critical
  - scope: session
    limit: max_cost($5), max_duration(10m)
  - scope: output
    block_if: sentiment == "hostile" OR contains("competitor_name")
```

- **Input guardrails**: Validate what goes to the LLM — block prompt injections, enforce topic boundaries, check for jailbreak patterns.
- **Output guardrails**: Validate what comes back — check for hallucinated URLs/citations, enforce format requirements, block toxic/harmful content.
- **Tool-use guardrails**: Control which tools an agent can use, with what parameters, at what frequency. An agent shouldn't be able to call `rm -rf` or `DROP TABLE` without explicit policy approval.
- **Circuit breakers**: If an agent's error rate exceeds a threshold, automatically pause it. Inspired by the circuit breaker pattern from microservices — prevent cascading failures in multi-agent systems.

### 7. Multi-Agent Coordination Intelligence

**The problem**: Research shows that scaling agents is not "more agents = better." Topology matters. Coordination overhead can negate gains. Error amplification varies 4-17x by topology.

**What the middleware does**:

- **Topology-aware routing**: The middleware knows the agent graph. It can detect whether agents are independent, centralized, decentralized, or hybrid. It applies different optimization strategies per topology.
- **Coordination overhead dashboard**: Real-time measurement of what % of total cost is coordination (message passing between agents, shared state management) vs. productive work.
- **Topology recommendations**: Based on the task characteristics and scaling research findings, recommend optimal topology. Tool-intensive task? Warn against multi-agent overhead. Parallelizable task? Suggest centralized coordination. Sequential reasoning? Recommend single-agent.
- **Capability saturation detection**: Research found coordination benefits diminish once single-agent performance exceeds ~45%. Detect when adding agents is hitting diminishing returns and recommend consolidation.
- **Error amplification monitoring**: Track error rates across the agent graph. Detect when errors are being amplified (one agent's mistake cascading). Alert and recommend topology changes.

---

## Architecture: Open-Source vs. Enterprise

### Open-Source Library (SDK)

- Python SDK that wraps any LLM client (OpenAI, Anthropic, etc.) and any agent framework (LangChain, CrewAI, AutoGen, custom)
- Intercepts all LLM calls and tool invocations via lightweight decorators/middleware
- Local PII scanning (using Presidio or a built-in fast scanner)
- Local caching and dedup
- Local cost tracking with CLI dashboard
- Policy engine with YAML config
- Export traces to stdout/file/OTLP
- Pluggable architecture — bring your own PII detector, cache backend, alerting sink
- Single-agent focus to start, multi-agent support via explicit session linking

### Enterprise (Hosted / Self-Hosted)

- Centralized proxy server (deploy as a sidecar, gateway, or SaaS)
- UI: session replay, live dashboards, policy editor, cost analytics
- Team/org management with RBAC
- Native integrations (Slack, PagerDuty, Datadog, etc.)
- Advanced PII: custom entity types, ML-based detection, data residency routing
- Multi-agent coordination intelligence (topology analysis, recommendations)
- Anomaly detection (ML-based baselining)
- Compliance reporting (SOC2, HIPAA, GDPR audit exports)
- SSO, audit logs, SLAs

---

## Competitive Landscape

| Existing Tool | What it does | What it misses |
|---|---|---|
| LiteLLM / Portkey / Bifrost | LLM API proxy, model routing | No agent-level awareness, no session context, no multi-agent intelligence |
| Presidio / LLM Guard | PII detection | Standalone library, no integration with agent lifecycle, no re-hydration |
| LangFuse / Braintrust | Tracing & observability | After-the-fact, no real-time intervention, no policy enforcement |
| Guardrails AI | Output validation | Narrow scope, no cost/PII/alerting, no agent coordination |
| MCP Gateways | Tool access control | Emerging, MCP-specific, no cross-cutting concerns |

**Key differentiator**: The only middleware that is **agent-session-aware** (not just LLM-call-aware), combines **all five concerns** (cost, PII, redundancy, observability, alerting) in a single layer, and applies **coordination intelligence** from academic scaling research.

---

## Suggested Rollout

1. **v0.1 (OSS)**: Python SDK with LLM call interception, cost tracking, basic PII redaction, semantic caching, CLI dashboard. Works as a drop-in wrapper around OpenAI/Anthropic clients.
2. **v0.2 (OSS)**: Policy engine (YAML), tool-call guardrails, loop detection, OTLP trace export. Framework integrations (LangChain, CrewAI).
3. **v0.3 (OSS)**: Multi-agent session linking, cross-agent dedup, basic alerting (webhooks).
4. **v1.0 (Enterprise)**: Hosted proxy, UI (session replay + dashboards), native integrations, RBAC, anomaly detection, compliance reporting.

---

## References

- Agentic Code Reasoning (arXiv:2603.01896) — Semi-formal reasoning for structured agent code analysis
- Towards a Science of Scaling Agent Systems (arXiv:2512.08296) — Quantitative principles governing multi-agent system performance and coordination overhead
