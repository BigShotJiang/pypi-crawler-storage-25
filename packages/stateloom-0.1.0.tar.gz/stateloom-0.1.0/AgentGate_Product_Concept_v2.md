# StateLoom: Product Concept v0.2

*Revised after peer review. Incorporates all substantive feedback from review rounds.*

---

## The Problem

LLM agents are entering production, and the tooling is still thinking in terms of individual API calls. You have LiteLLM for routing, Presidio for PII detection, LangFuse for tracing — all operating on single calls, in isolation, after the fact. But an agent isn't a call. It's a session: 50 LLM calls, 30 tool invocations, $15 of tokens, maybe 3 loops where it re-asked the same question it already answered, and one moment where it almost sent a customer's SSN to a third-party API.

**None of the existing tools catch that whole picture — and none of them can intervene.**

LangFuse has "Traces" that capture full runs with nested spans, costs, and replay. That's real, and it's closer to a session model than I initially gave it credit for. But LangFuse is architecturally passive: observation → store → visualize. The session data arrives after the call returns. That means it can never enforce a budget mid-run, never redact PII before the token leaves your network, never return a cached result instead of firing a duplicate LLM call, never inject a corrective prompt when an agent is spinning.

The architecture matters. Sitting *beside* the call path enables observation. Sitting *in* the call path enables intervention.

---

## The Core Insight

**StateLoom is active middleware, not a better tracer.**

The unit of value is the session. The architectural position is the call path. The product is what you can do from that position with session-scoped context: enforce policies, intercept bad data, eliminate waste, break loops — in real time, before damage is done.

Observability is a byproduct of being in the call path. The value is what we can do from there.

---

## v0.1 Scope — Honestly Scoped

### What We're Building

A Python SDK. One entry point for local development:

```python
import stateloom
stateloom.init()
```

Auto-patches OpenAI and Anthropic clients. Opens a dashboard at `localhost:4781`. Starts tracking. Fail-open by default — if StateLoom crashes, your LLM call goes through unchanged.

For code you control and staging environments, the explicit path is preferred:

```python
from stateloom import StateLoom

gate = StateLoom.from_config("stateloom.yaml")
client = gate.wrap(openai.OpenAI())
```

The explicit `wrap()` path is the recommended integration for anything beyond local experimentation. See Deployment Models below.

### Immediately, You Get

- **Real-time cost tracking** per session, with per-model breakdowns and a running total
- **PII detection and enforcement** — regex-based scanner by default (fast, no heavy dependencies), with a pluggable interface for Presidio or custom backends
- **Loop detection** — same call pattern 3x in a session triggers a warning; configurable escalation to circuit-break
- **Exact-match deduplication** — identical prompt within a session served from cache with a "saved $X" counter
- **Session replay in the UI** — step through what the agent did, call by call
- **Budget enforcement** — configurable per-session spend limit; warn or hard-stop when exceeded

Terminal output during development:

```
[StateLoom] ✓ gpt-4o | 847 tok | $0.013 | 1.2s | session:ticket-123
[StateLoom] ⚠ PII REDACTED | type:email | field:user_message | replaced→[MASKED_EMAIL_1] | session:ticket-123
[StateLoom] ⚡ CACHE HIT | exact match | saved $0.013 | session:ticket-123
[StateLoom] 🔁 LOOP DETECTED | tool:web_search | calls:3 | action:flagged | session:ticket-123
[StateLoom] 🛑 BUDGET ENFORCED | session:ticket-123 | limit:$5.00 | spent:$5.02 | action:hard_stop
```

**Design rule:** StateLoom interventions are never silent in development mode. Every redaction, cache hit, loop flag, and budget enforcement gets a console line with what happened, why, and what the intervention was. No silent mutations. In production, verbosity is configurable via `STATELOOM_ENV=production` or the config file.

### What v0.1 Does Not Include

- Multi-agent cross-agent deduplication (v0.3)
- Coordination overhead measurement (v0.3)
- Semantic caching (available as `stateloom[semantic-cache]` optional extra — see below)
- LangChain / LlamaIndex native integrations (v0.2)
- Enterprise control plane / hosted proxy (v1.0)
- Cost Analytics, PII Monitor, Settings, Diff View dashboard screens (v0.2)

---

## Architecture

### Middleware Pipeline

Every LLM call passes through a configurable pipeline:

```
LLM Call
  → SessionContext (assign/lookup session)
  → PiiScanner (detect, route by policy, enforce)
  → BudgetEnforcer (check current spend, enforce limit)
  → CacheLayer (exact-match lookup; semantic lookup if enabled)
  → LoopDetector (pattern matching against session history)
  → [actual LLM call]
  → ResponseInterceptor (PII scan on response, rehydration for audit)
  → EventStore (async write to configured backend)
  → return to caller
```

Each middleware stage is a class implementing the `Middleware` protocol:

```python
class Middleware(Protocol):
    async def process(self, event: Event, call_next: Callable) -> Event: ...
```

This means: custom middleware is possible, stages can be reordered, individual stages can be disabled. The pipeline is not a black box.

### The Event Model

Every call produces an `Event`:

```python
@dataclass
class Event:
    session_id: str
    call_id: str
    timestamp: datetime
    model: str
    prompt_tokens: int
    completion_tokens: int
    cost_usd: float
    latency_ms: float
    destination: Destination        # NEW: internal vs external, specific endpoint
    pii_detections: list[PiiMatch]
    cache_result: CacheResult | None
    interventions: list[Intervention]
    metadata: dict[str, Any]
```

The `destination` field is new and critical for PII policy routing. It's populated by the `wrap()` layer, which knows what endpoint it's routing to.

### Session Management

Sessions are identified by ID. Three modes:

```python
# Explicit (preferred)
with gate.session(id="ticket-123", metadata={"user": "alice"}):
    response = client.chat.completions.create(...)

# Inferred from context variable (works for simple scripts and single-threaded code)
stateloom.init()  # automatically assigns session IDs per thread/asyncio task

# Injected by caller (for services that already have session/request IDs)
gate.set_session_id(request.headers["X-Session-ID"])
```

For a long-running service handling concurrent users, explicit session tagging is required. The zero-config case relies on `contextvars.ContextVar` which works correctly for async code but not for multi-threaded code sharing sessions. This is documented clearly — the inferred mode is for local dev, not for production services.

---

## PII Policy Enforcement

StateLoom is the **PII policy enforcement layer**, not a PII detection engine. The default regex scanner catches high-confidence patterns (SSN, credit cards, API keys, email addresses). For production, you plug in your detection backend.

### Detection Backends

```python
# Default: regex scanner (zero extra dependencies)
gate = StateLoom.from_config("stateloom.yaml")

# Presidio (install stateloom[presidio])
from stateloom.pii import PresidioScanner
gate = StateLoom(pii_scanner=PresidioScanner())

# Custom (any callable matching the protocol)
class MyScanner:
    def scan(self, text: str, context: ScanContext) -> list[PiiMatch]: ...

gate = StateLoom(pii_scanner=MyScanner())
```

### Destination-Aware Policy Model

PII policies can be scoped by destination. Each tool and LLM endpoint is registered with a trust classification:

```yaml
destinations:
  openai-gpt4:
    type: external_llm
  internal-crm-tool:
    type: internal_tool
  audit-log:
    type: internal_log

policies:
  - name: ssn-always-redact
    pii_type: ssn
    destinations: ["*"]
    action: mask

  - name: email-external-only
    pii_type: email
    destinations: ["external_llm", "external_tool"]
    action: mask

  - name: email-internal-passthrough
    pii_type: email
    destinations: ["internal_tool", "internal_log"]
    action: allow

  - name: pii-in-llm-response
    pii_type: ["ssn", "credit_card"]
    scope: outbound_to_user
    action: redact
    audit: true
```

If no policy is configured, the default is: mask all detected PII on all outbound calls. Simple cases require no configuration.

**What the regex scanner catches reliably:** SSNs, credit card numbers, API keys (common patterns), email addresses, US phone numbers. This covers the majority of high-severity cases. It does not reliably handle freeform medical notes, names embedded in text, or context-dependent PII. The docs are explicit about this. For anything beyond basic structured PII, configure Presidio or a custom scanner.

---

## Semantic Caching (Optional Extra)

Available as `pip install stateloom[semantic-cache]`. Not enabled by default.

**Why opt-in:** Semantic caching requires a local embedding model (~85MB), introduces 20-50ms per-call overhead for embedding generation, and has real failure modes (stale cache hits, false positives). It's a powerful feature when used appropriately; a liability when used blindly.

**What it does:** Detects when an agent is asking a functionally equivalent question it already answered in this session, returns the cached result, and saves the LLM call. Useful for agents with multi-turn conversations or repeated similar tasks.

### Embedding Model

Default: `sentence-transformers/all-MiniLM-L6-v2` — 22MB model, runs locally, no API calls, no external dependency. Configurable:

```python
from stateloom.cache import SemanticCache, CustomEmbedder

gate = StateLoom(
    cache=SemanticCache(embedder=CustomEmbedder(model="your-model"))
)
```

Not recommended for serverless/Lambda deployments — the model load on cold start adds 2-5 seconds. Document this prominently.

### Cache Invalidation

We do not attempt automatic cache invalidation based on semantic reasoning. It's too hard to get right without domain knowledge, and a wrong invalidation (or missed invalidation) is worse than no cache.

What we provide:

- **TTL-based expiry:** configurable, default off
- **Manual invalidation:** `gate.invalidate_cache(session_id=..., pattern=...)`
- **Tool-triggered invalidation:** opt-in, explicit — declare which tools mutate state, and a call to those tools invalidates related cache entries
- **Cache hit logging:** every cache hit logs the matched query, similarity score, and cached response ID — developers can audit whether hits were correct

The semantic cache is appropriate for idempotent queries. If your agent queries mutable state, configure TTLs or tool-triggered invalidation, or exclude those queries from the cache.

### Similarity Thresholds

Default: 0.92 cosine similarity, configurable. A `calibration` utility helps set this informed by actual data:

```bash
stateloom calibrate --history session-logs/ --output threshold-report.html
```

Shows the distribution of similarity scores across historical calls, lets you inspect pairs at different threshold levels, and suggests a threshold based on false positive / false negative tradeoffs. The dashboard shows cache hit rate and an estimated false-positive rate based on sampled human review.

---

## Integration Matrix

Clear upfront expectations about what's supported at what version:

| Integration | Version | Notes |
|---|---|---|
| OpenAI Python SDK | v0.1 | `gate.wrap(openai.OpenAI())` |
| Anthropic Python SDK | v0.1 | `gate.wrap(anthropic.Anthropic())` |
| `stateloom.init()` auto-patch | v0.1 | Local dev only |
| LangChain callback handler | v0.2 | Uses LangChain's native callback system |
| LlamaIndex instrumentation | v0.2 | Via LlamaIndex `CallbackManager` |
| OpenAI-compatible endpoints (Ollama, Together) | v0.3 | Same API, different base URL |
| HuggingFace `transformers` | v0.3 | Via generic callable wrapper |
| Custom / generic callable | v0.3 | `gate.wrap_callable(fn, schema=...)` |
| Enterprise proxy (all backends) | v1.0 | No SDK changes required |

Developers with LlamaIndex or Haystack stacks should know before they start that native support is v0.2. A `wrap()` call against the underlying client may partially work but won't capture framework-level calls. This is in the README, not buried in docs.

---

## Deployment Models

Three tiers with explicit requirements and tradeoffs:

### Tier 1: Local Development / Single Process

- State store: SQLite + in-memory session state via `ContextVar`
- Dashboard: runs as daemon thread in the same process
- Use `stateloom.init()` or `gate.wrap()` — both work
- Zero additional infrastructure required
- Session detection via thread/asyncio context

### Tier 2: Multi-Process, Single Machine

- State store: SQLite with WAL mode (handles multiple readers, single writer)
- Dashboard: connects to shared SQLite file
- Use explicit session IDs — required for correct session attribution across processes
- Use `gate.wrap()` — `init()` is not appropriate here
- Handles modest concurrency; degrades gracefully under high write load

### Tier 3: Distributed Service (Multiple Replicas)

- State store: pluggable backend required

```python
from stateloom.store import RedisStore

gate = StateLoom(
    store=RedisStore(url="redis://...", prefix="stateloom:")
)
```

- `RedisStore` ships as `stateloom[redis]` optional extra
- Dashboard connects to centralized store; local dashboard works if pointed at the shared backend
- Session IDs must be passed explicitly from application layer
- This is where the enterprise proxy becomes attractive: single endpoint, no Redis to manage, centralized dashboard, RBAC, compliance logging

**The `Store` protocol:**

```python
class Store(Protocol):
    async def get_session(self, session_id: str) -> Session | None: ...
    async def put_session(self, session: Session) -> None: ...
    async def list_sessions(self, filters: SessionFilter) -> list[Session]: ...
    async def append_event(self, event: Event) -> None: ...
```

Ships with: `InMemoryStore`, `SQLiteStore`. Optional extras: `RedisStore`. Enterprise: managed store in the hosted control plane.

---

## StateLoom Self-Observability

StateLoom sits in the call path. Its own performance and reliability must be observable through standard channels — not just through its own dashboard.

### OpenTelemetry Integration

Every middleware invocation produces OTel spans:

```
stateloom.pipeline (parent span)
  ├── stateloom.pii_scan
  ├── stateloom.cache_lookup
  ├── stateloom.budget_check
  ├── stateloom.loop_detect
  └── stateloom.event_write
```

These are child spans of the application's existing trace if one exists. If the app doesn't have tracing, they're standalone. StateLoom shows up in Datadog, Grafana, Honeycomb, or whatever the developer already uses.

### Prometheus Metrics

Available at `GET /metrics` on the dashboard port:

```
stateloom_call_latency_ms{stage="pii_scan|cache_lookup|budget_check|total"} (histogram)
stateloom_cache_hits_total{type="exact|semantic"}
stateloom_cache_misses_total
stateloom_pii_detections_total{pii_type="email|ssn|credit_card|..."}
stateloom_policy_enforcements_total{action="mask|block|allow"}
stateloom_loop_detections_total
stateloom_budget_enforcements_total{action="warn|hard_stop"}
stateloom_errors_total{component="pii_scanner|cache|store|..."}
stateloom_session_active_count
stateloom_latency_budget_exceeded_total
```

Scraped by Datadog, Grafana, or any Prometheus-compatible stack out of the box.

### Python Logging

Standard `logging` module, under `stateloom.*` namespaces:

```python
import logging
logging.getLogger("stateloom").setLevel(logging.DEBUG)
logging.getLogger("stateloom.pii").setLevel(logging.WARNING)
```

Silent at INFO level by default. Errors always surface. This is non-negotiable — any library that doesn't integrate with standard Python logging is hostile to production use.

### Health Endpoint

`GET /health` returns StateLoom's internal state:

```json
{
  "status": "healthy",
  "store": "connected",
  "cache_backend": "connected",
  "embedding_model": "loaded",
  "pipeline_stages": ["pii_scan", "budget_check", "cache", "loop_detect"],
  "uptime_seconds": 3842
}
```

Kubernetes readiness probe hits this endpoint.

### Latency Budget and Fail-Open

StateLoom has a configurable `max_middleware_latency_ms` (default: 50ms). If StateLoom's own processing exceeds this budget on a call, it logs a warning, increments `stateloom_latency_budget_exceeded_total`, and short-circuits to fail-open — the LLM call goes through without intervention. The developer gets a warning. Production doesn't silently degrade.

---

## Performance Targets

Per-call overhead targets for the blocking path (non-semantic):

| Stage | Target Latency | Notes |
|---|---|---|
| Middleware pipeline dispatch | <1ms | Pure Python |
| Regex PII scan (1KB prompt) | <2ms | Compiled patterns |
| Exact-match cache lookup | <2ms | Indexed hash, SQLite |
| Budget check | <0.1ms | In-memory counter |
| Loop detection | <0.5ms | Hash set membership |
| SQLite event write | ~5ms | Async, doesn't block |
| **Total blocking overhead** | **<6ms** | Against 500ms–3s LLM calls: <1% |

Semantic caching adds 20-50ms for embedding generation when enabled. Still <5% of a typical LLM call, and a cache hit eliminates the LLM call entirely.

Memory footprint:
- Core SDK: ~15-20MB resident
- With `all-MiniLM-L6-v2` embedding model: ~85-90MB additional
- SQLite store: grows with sessions, bounded by configurable retention

Commitments for v0.1:
- CI benchmark suite (`pytest tests/benchmarks/`) using mock LLM server. Fails if blocking overhead exceeds 10ms.
- Published benchmark results in README — actual measured numbers, not aspirational targets.
- `stateloom.profile()` utility runs a local benchmark and reports actual overhead on your hardware.

---

## v0.1 Dashboard

Two screens. Not five. Scope discipline is how we ship this.

**Screen 1: Live Overview**
- Active sessions with real-time cost ticker
- Event stream as calls happen (WebSocket)
- Alert banners: PII detections, loops, budget warnings
- "Saved $X today" counter (cache hits)

**Screen 2: Session Detail**
- Step-through replay of a single session
- Each step: model, tokens, cost, latency, interventions applied
- PII redaction view: what was detected, what was masked, what placeholder was used
- Full prompt/response with diff highlighting of redactions

Stack: Preact + HTMX, pre-built static assets bundled with the pip install. No Node.js, no npm required to run the dashboard.

Deferred to v0.2: Cost Analytics, PII Monitor, Settings, Policy Editor, Diff View.

---

## Enterprise Path (v1.0)

The Datadog playbook: open-source SDK → developer love → bottoms-up pull into enterprises → upsell on centralized control plane.

### What Creates the Pull

Once a few engineers use StateLoom locally, they want:
- Centralized dashboards across teams and services
- Per-team and per-product cost attribution
- RBAC: who can see what sessions, who can change policies
- Compliance audit trails: immutable log of every intervention
- Policy management UI: define and roll out PII policies without code changes
- Advanced budget controls: per-user, per-product-line, per-department

The SDK creates gravity. The control plane captures the value.

### The Enterprise Proxy

The real enterprise path is not `gate.wrap()` — it's a hosted proxy. Point your OpenAI `base_url` at the StateLoom gateway:

```python
client = openai.OpenAI(base_url="https://gateway.stateloom.io/v1")
```

No SDK changes. No monkey-patching. Works with any language, any framework. The proxy handles session tracking, PII enforcement, budget control, caching, and routes to the actual LLM endpoint.

**Self-hosted proxy is a first-class option, not a fallback.** Financial services, healthcare, government — these industries will not route prompts through a SaaS proxy. The self-hosted proxy (Docker image or Helm chart) deploys in the customer's VPC. We provide the software; they control the infrastructure. This is a primary GTM path for regulated industries, not an edge case.

Stateless proxy design from day one: all state in the configurable backend, proxy instances are interchangeable, scales horizontally.

### Data Privacy and Compliance

What we commit to:
- v0.1 SDK: no data leaves the user's machine. Nothing to certify.
- v1.0 SaaS proxy: SOC 2 Type II before we talk to enterprise security teams. Budget 6-12 months after we start processing customer data.
- HIPAA BAA and GDPR DPA available for relevant verticals — these require SOC 2 first.
- Default data handling for SaaS: TLS in transit, no prompt content stored at rest (we process and route, we don't warehouse prompts by default). Opt-in for session replay requires explicit data retention configuration.
- Customer data isolation: tenant-scoped encryption keys.
- Self-hosted proxy: customer's security team audits their own deployment. We provide architecture documentation.

### Data Egress Transparency

The double-hop (client → StateLoom proxy → LLM API) adds data transfer costs. We address this directly:
- Regional proxy deployments co-located with target LLM endpoints (AWS us-east-1 for OpenAI US, EU-west for Anthropic EU)
- The ROI dashboard accounts for StateLoom's own infrastructure cost, not just LLM savings. Net savings is what matters.
- If the math is negative for a customer's workload, we tell them — and the SDK-only path remains available.

### Unique Enterprise Metrics

These metrics are only possible because StateLoom is in the call path:

- **Prevention rate:** "847 PII items blocked from leaving your network this month"
- **Intervention cost savings:** "$2,341 saved via semantic caching" (attributable, auditable)
- **Budget enforcement:** "12 runaway sessions terminated, $340 in avoided overspend"
- **Loop aborts:** "34 agent loops broken, 2.1 hours of agent runtime saved"
- **Dedup efficiency:** "23% of LLM calls within sessions were duplicates, served from cache"

These tell a CFO a story about ROI that a passive tracer cannot tell. The enterprise ROI dashboard is built around these metrics — this is what justifies the budget conversation.

### Pricing Model

Not locking this in before we have usage data. The wrong pricing model fights your customers.

Hypothesis based on analogies: **per seat + per agent-session volume tier**. "Sessions" is the natural unit — maps to an agent run, countable, scales with customer usage, bounded enough to not feel punitive. Similar to how Datadog charges per host.

Commitment: after v0.1 beta, usage data will show what customers measure and care about. Pricing follows the value metric customers already use, not what we guess in advance.

---

## Multi-Agent Roadmap (v0.3+)

These features are cut from v0.1. Multi-agent systems are not yet mainstream in production. Shipping half-built features for a problem that's 12-18 months from being widespread pain would erode trust in the features that are relevant today.

When multi-agent is mainstream:

**Cross-agent deduplication:** Agent B is about to retrieve information Agent A already retrieved. StateLoom intercepts and shares the cached result. Requires understanding the agent graph, not just individual calls.

**Coordination overhead measurement:** Based on arXiv:2512.08296. Measures what % of total session cost is coordination overhead vs. actual work. Flags when adding agents hits diminishing returns. Gives teams a principled way to reason about multi-agent topology, not just vibes.

The multi-agent story becomes part of the enterprise/v1.0 pitch: prove value in the simple case, upsell on the complex case. Better sales motion than trying to demo infrastructure that most customers don't have yet.

---

## Risks and Open Questions

These are unresolved. Not hand-waving — actual open problems.

**Risk 1: Monkey-patching fragility (mitigated but not eliminated)**
Auto-patching OpenAI/Anthropic works today; breaks if their SDK internals change. Mitigated by: making `wrap()` the recommended production path, clear docs, `init()` explicitly scoped to local dev. Not fully eliminated: developers who use `init()` in production despite docs will have a bad time on SDK updates.

**Risk 2: Semantic cache invalidation**
TTL + tool-triggered invalidation covers the cases we can solve. Automatic semantic invalidation is an unsolved problem for us — too hard to get right without domain knowledge. A stale cache hit is actively harmful. Open question: can we use LLM-based consistency checking ("is this cached answer still valid given this new context?") without making the feature's cost exceed its benefit?

**Risk 3: Session boundary detection for long-running services**
The `ContextVar` approach works for async code, breaks for multi-threaded code sharing a session. The explicit `gate.session(id=...)` context manager solves this, but requires developers to opt in. Open question: can we make the session API ergonomic enough that developers reach for it naturally rather than hoping the inferred mode works?

**Risk 4: Integration long tail**
The tiered integration plan handles the mainstream cases. But every LangChain agent that does something unusual, every custom tool executor, every niche inference library — these will produce bug reports that consume engineering time. We need a policy for what we officially support vs. community-maintained integrations.

**Risk 5: Performance on high-frequency workloads**
The <6ms target is achievable with straightforward implementation. But a customer running 100 concurrent agent sessions, each making 10 calls/second, generates 1000 events/second through the pipeline. SQLite will not handle this at Tier 1 or 2. The 3-tier deployment model addresses this architecturally, but developers need to understand which tier they're in before they hit the wall, not after.

**Open question: pricing model**
Deferred intentionally. Need beta usage data. The sessions-based hypothesis is reasonable but unvalidated.

**Open question: semantic caching hit rate in practice**
We have theoretical arguments for why semantic caching saves money. We don't have real-world hit rate data. If the hit rate is too low to justify the embedding overhead and the operational complexity, this feature may not earn its place in the product. We'll know after beta.

---

## What We're Building First

Sequence matters. Here's the v0.1 build order:

1. **Core pipeline + `wrap()` for OpenAI/Anthropic.** Nothing else matters if this isn't solid.
2. **SQLite event store + session management.** Foundation for everything else.
3. **Exact-match cache + budget enforcer.** Immediate, zero-risk value.
4. **PII scanner + destination-aware policy engine.** High value, real complexity.
5. **Loop detection.** Relatively simple, high wow factor.
6. **Terminal output (rich).** Developer experience before dashboard.
7. **Dashboard: Session Detail screen.** Debugging value.
8. **Dashboard: Live Overview screen.** Shareability, wow factor.
9. **StateLoom self-observability.** OTel, Prometheus, health endpoint. Not optional — this is what makes us trustworthy infrastructure.
10. **`init()` auto-patch.** Last, because it's the highest-risk integration and lowest-priority path.
11. **Benchmark suite + published results.** Ships with v0.1, not after.
12. **`stateloom[semantic-cache]` optional extra.** If time allows; otherwise v0.1.1.

---

## What "Good" Looks Like for v0.1

A developer with a working OpenAI-based agent should be able to:

1. `pip install stateloom` and add three lines of code
2. See real-time cost per session in their terminal within 5 minutes
3. Catch a PII issue they didn't know they had
4. Watch the "saved $X" counter tick up from exact-match deduplication
5. Pull up the session replay and step through what their agent did
6. Share a screenshot of the dashboard in a Slack thread and have a teammate understand it without explanation

If we can't demonstrate all six in a live demo to a developer who's never heard of StateLoom, v0.1 isn't done.

The enterprise path starts here: every developer who does this becomes a vector for StateLoom entering their company's infrastructure.