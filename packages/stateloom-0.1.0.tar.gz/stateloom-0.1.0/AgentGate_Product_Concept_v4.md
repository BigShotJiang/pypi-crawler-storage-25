# StateLoom: Revised Product Concept

*Post-peer-review revision. This is the document we build from.*

---

## The Problem

Every team building production agents is hitting the same wall. They've picked a framework — LangGraph, CrewAI, AutoGen, something custom — they're making real LLM calls, and the tooling they have was built for a different problem.

**LiteLLM and Portkey** are request proxies. Good at caching, fallbacks, rate limits, spend caps. But they're stateless. They see request N with zero memory of requests 1 through N-1. They cannot detect that request N is the fifteenth step in a session because they don't model sessions. They model HTTP calls.

**LangFuse** understands traces. It gets sessions, nested spans, full run capture. But it's architecturally passive — session data arrives after the call returns. It observes. It cannot intervene.

**LangGraph's checkpointer** does persist graph state at every node and supports rewinding to a previous state. But it only works if you've built your entire application in LangGraph's graph syntax. If you're using CrewAI, AutoGen, raw OpenAI calls in a FastAPI endpoint, or a custom orchestration loop — you get nothing.

So here's the failure mode nobody's tooling catches across frameworks: an agent spins in a loop, calling `web_search` fifteen times with semantically equivalent queries, and nobody catches it until the bill arrives. Or a customer's email address rides along in a prompt to OpenAI and nobody audited what that prompt contained. Or a 15-step agent fails on step 14 and the developer re-runs the entire thing — two minutes, forty cents in tokens — to test a one-line fix. Or a production session runs $23 before anyone realizes the budget was never enforced.

These are not theoretical. These are daily friction for teams building production agents right now.

---

## The Core Insight

**StateLoom is stateful agent middleware.**

The word "stateful" is doing real work. Portkey enforces per-request policies. StateLoom enforces per-session policies. Those are fundamentally different problems.

The unit of value is the session. An agent isn't a call — it's a session: fifty LLM calls, thirty tool invocations, fifteen dollars of tokens, and a coherent task with a beginning and an end. Session-scoped context enables things that are physically impossible from a stateless request proxy: mid-session budget enforcement, loop detection across the full call history, cost attribution to a single task, and deterministic replay of a failed session for debugging.

**The competitive moat is framework agnosticism.** LangGraph gives you state management if you build in LangGraph. StateLoom gives you the same capabilities — budget enforcement, PII detection, loop detection, deterministic replay — whether you're on LangGraph, CrewAI, AutoGen, or raw OpenAI calls. We give developers LangGraph's operational superpowers without forcing them to rewrite their codebase into a DAG.

We compose with LangGraph; we don't replace it.

---

## What We're Building

### Zero-Touch Entry Point

```python
import stateloom
stateloom.init()
```

We auto-patch OpenAI and Anthropic clients. We open a dashboard at `localhost:4781`. The terminal immediately shows activity:

```
[StateLoom] ✓ gpt-4o | 847 tok | $0.013 | 1.2s | session:ticket-123
[StateLoom] ⚠ PII DETECTED (logged) | type:email | field:user_message
[StateLoom] ⚡ CACHE HIT | exact match | saved $0.013
[StateLoom] 🔁 LOOP DETECTED | tool:web_search | calls:3 | action:flagged
[StateLoom] 🛑 BUDGET ENFORCED | limit:$5.00 | spent:$5.02 | action:hard_stop
```

Nothing is silent. Every intervention gets a console line.

**`stateloom.init()` is scoped to local development and single-process use cases.** For concurrent production servers, one additional line is required at the request boundary:

```python
with stateloom.session("ticket-123"):
    await agent.run(task)
```

This is the production pattern. It's not a penalty — it's one line at the entry point of each request. The `with` block sets a `ContextVar` that every monkey-patched LLM call inherits, even across `await` boundaries. Concurrent async tasks get correct session attribution with zero cross-contamination.

**Threading note:** `ContextVar` does not propagate across `threading.Thread()`. For threaded worker pools, pass explicit session IDs. This is documented prominently.

The README leads with `stateloom.init()` for instant gratification, then immediately presents the context manager as the production pattern. Not a footnote.

### Failure Modes: Observability vs. Safety

**"Fail open" is not a blanket rule.**

Observability middleware (cost tracking, latency, loop detection, caching) fails open by default. If it crashes, the LLM call goes through, the middleware error is logged, the developer investigates later. This is correct — these features are visibility, not safety.

Security and enforcement middleware (PII blocking, budget hard stops) requires explicit configuration:

```yaml
# stateloom.yaml
pii:
  rules:
    - pattern: credit_card
      mode: block
      on_middleware_failure: block   # if scanner crashes, reject the call
    - pattern: email
      mode: audit
      on_middleware_failure: pass    # observability rule, fail open is fine

budget:
  per_session_usd: 5.00
  action: hard_stop
  on_middleware_failure: block      # or pass — developer must choose explicitly
```

If a developer configures `mode: block` without specifying `on_middleware_failure`, the SDK emits a startup warning and refuses to start silently:

```
[StateLoom] ⚠ CONFIG WARNING: PII rule 'credit_card' has mode=block but
  on_middleware_failure is not set.
  
  block  → if the PII scanner crashes, reject the LLM call (safe, may break app)
  pass   → if the PII scanner crashes, allow the LLM call (app continues, data may leak)
  
  Set on_middleware_failure explicitly. See: https://docs.stateloom.io/fail-modes
```

We do not pick a default for safety-critical behavior. We force the decision.

**Control plane availability:** If the control plane is unreachable and a cached policy exists locally, we enforce the cached policy. A stale security policy is better than no security policy. This is documented explicitly and is not configurable — it's the correct safe default.

---

## Feature Set

### 1. Session-Scoped Observability

Real-time cost per session, running total, model breakdown, latency histogram. Available in the local dashboard and the hosted control plane.

The difference from LangFuse: we're in the call path. We can act, not just observe. The savings numbers we report are verifiable because we produced them: "23% of calls were cache hits, saved $2,341 this month" is a number we generated by intercepting those calls, not inferred from logs.

### 2. Deterministic Replay

This is the primary developer wedge.

When a 15-step agent fails on step 14:

```python
gate.replay(session="ticket-123", mock_until_step=13)
```

**What actually happens:** We execute all steps 1 through 13, but every LLM call and every `@gate.tool()` call in that range is intercepted and instantly returns the cached response from the original run. Python state builds up correctly — same as it did the first time — but we're not paying for LLM calls and we're not re-executing side-effecting tools. Step 14 runs live against correctly-populated state.

This is VCR.py for agents. We do not skip Python execution. We mock I/O.

The value: fix step 14 without paying for steps 1-13. A 15-step session that took two minutes and cost $0.40 can be iterated on in seconds at zero marginal cost.

**This is what LangGraph's checkpointer cannot do.** LangGraph restores graph state. StateLoom replays LLM responses — it caches the actual request/response pairs and replays them deterministically. These are different primitives. Ours work across any framework.

#### Strict Replay Mode (Default)

The `@gate.tool()` decorator is necessary but not sufficient for replay safety. If a developer forgets to decorate a function that sends email, a replay will send duplicate emails to customers. Human perfection is not an architecture.

**Strict replay mode is on by default** during any `stateloom replay` or `stateloom test` execution. In strict mode, we intercept outbound HTTP at the network layer:

- Patch `httpx.Client.send`, `requests.Session.send`, `urllib3.HTTPConnectionPool.urlopen`
- Maintain a set of known-safe calls: those captured via `@gate.tool()` with cached responses
- Any outbound network call NOT in the known-safe set raises `StateLoomSideEffectError` *before* the connection is made

```
[StateLoom] 🛑 SIDE EFFECT BLOCKED | replay:ticket-123 | step:4
  Outbound HTTP call to smtp.gmail.com:587 was blocked during replay.
  This call was not captured in the original session recording.
  
  To fix:
    Option 1: Decorate the function making this call:
      @stateloom.tool(mutates_state=True)
      def send_email(to: str, body: str): ...
    
    Option 2: If this is a safe read-only call, use mutates_state=False
    Option 3: Allow specific hosts: stateloom.replay(..., allow_hosts=["api.internal.com"])
  
  Replay aborted. No side effects occurred.
```

No email sent. No database written. The developer gets an actionable error and knows exactly where to add the decorator.

**Replay safety hierarchy:**
1. Network blocker (automatic, catches most HTTP side effects without developer action)
2. `@gate.tool(mutates_state=True)` (explicit, for non-HTTP side effects and precise control)
3. Warning system for undecorated calls (fallback for edge cases the blocker can't see)

**Scope of network blocker:** Covers HTTP (the 90% case — email APIs, Slack, REST APIs, most ORMs). Does not cover direct file writes, native database drivers, subprocess calls. These are documented as requiring explicit `@gate.tool()` decoration.

Strict mode can be disabled with `strict_replay=False` — but only if `--i-know-what-im-doing` is also passed on the CLI. We make the footgun visible.

### 3. Budget Enforcement

Hard stop when a session exceeds its configured spend limit. Synchronous check in the critical path. Policy failure behavior is explicit (see above).

```yaml
budget:
  per_session_usd: 5.00
  action: hard_stop
  on_middleware_failure: block
```

### 4. PII Detection

Compiled regex scanner: emails, credit cards with Luhn validation, API keys with known prefixes.

**Default behavior: detect, log, surface in dashboard. Do not touch the prompt.**

False positives from inline redaction break agents silently. Trust comes first. Opt-in `redact` and `block` modes are available with explicit `on_middleware_failure` configuration required.

### 5. Loop Detection

**Exact-match detection:** synchronous, <0.5ms. Identical tool call signature seen twice in the session triggers a flag.

**Semantic detection:** async. We mirror call content to a background worker, compute embeddings against session history, set a kill-switch flag if semantic similarity exceeds threshold. The next call checks the flag in 0.1ms. We miss exactly one call in a semantic loop. Acceptable tradeoff.

Threshold is configurable and defaults to conservative. Early adopters can tune it and share calibration data.

### 6. Exact-Match Caching

Identical prompt within a session returns from in-memory cache. Savings are auditable and precise.

Semantic cache is explicitly out of scope for v0.1. Embedding overhead in the critical path is only justified once we have real-world hit rate data.

### 7. Production Incident Triage

**This is the primary GTM wedge for teams and enterprises.**

When an agent fails in production, the on-call engineer currently gets a stack trace and maybe some logs. StateLoom changes this.

A production session failure triggers an automatic share (opt-in) to the control plane. The Slack/PagerDuty/OpsGenie alert contains an StateLoom session link. The engineer clicks the link, views the scrubbed session in the hosted dashboard, and runs:

```bash
stateloom pull ticket-123
```

This pulls the exact production session — all LLM responses, all tool outputs — to their local machine. They can step through the failure deterministically, for $0 in token costs, without re-running anything.

**This changes the enterprise pitch from "better debugging experience" to "your agents fail in production and your engineers currently have no idea why. We fix that."**

#### Compliance: Server-Side Masking Before Pull

**This is non-negotiable for enterprise adoption.** If a session was recorded with `email: audit` (not blocked), the raw session in the control plane may contain customer PII. `stateloom pull` cannot download unmasked PII to a developer's local machine — that's a GDPR/SOC2 violation.

The control plane must apply server-side data masking before serving sessions to the pull endpoint. The masking rules applied are the same PII rules configured in `stateloom.yaml` for that environment. An enterprise with `credit_card: audit` in production will have credit card numbers masked in all pulled sessions, regardless of whether they were blocked in the original call path.

Session pull requests are logged in the audit trail (enterprise tier).

### 8. Viral Sharing and CI/CD Lock-In

```python
gate.share(session="ticket-123")
# → https://app.stateloom.io/s/abc123
```

Automatic PII masking before upload. Teammate clicks the link, views the scrubbed session in the hosted dashboard. One developer shares a link; the whole team creates accounts.

```bash
stateloom replay --url https://app.stateloom.io/s/abc123
```

Reproduces the exact session state locally.

**Regression testing:**

```python
gate.pin(session="ticket-123", name="golden-run-v1")
```

In GitHub Actions:

```yaml
- name: StateLoom regression suite
  run: stateloom test --suite golden-runs --mock-llm
```

StateLoom replays each pinned session using stored LLM responses as mocks. No live LLM calls — fast, free, deterministic. If someone changes the system prompt or tool logic, the regression catches it.

Once the CI pipeline depends on the control plane for golden sessions, the SaaS subscription is load-bearing infrastructure. This is the lock-in feature.

---

## The `@gate.tool()` Decorator

```python
@gate.tool(mutates_state=True)
def send_email(to: str, subject: str, body: str) -> str:
    ...

@gate.tool(mutates_state=False)
def read_database(query: str) -> list:
    ...
```

`mutates_state` is the key flag. During replay:
- `mutates_state=True` calls are mocked using cached responses (never re-executed)
- `mutates_state=False` calls are allowed to execute live (they're safe reads)

Undecorated functions that make HTTP calls will be caught by the strict replay network blocker and produce `StateLoomSideEffectError` with actionable instructions.

**The decorator is not a tax you pay upfront. It's a response to a caught problem.** Developers add it when strict mode tells them to.

### LangGraph Integration

LangGraph has its own `@tool` decorator and tool node execution model. Double-decorating is error-prone and creates risks of double-execution and ContextVar pollution.

We ship a native adapter:

```python
from stateloom.ext.langgraph import patch_langgraph_tools

patch_langgraph_tools()  # intercepts LangGraph ToolNode executions natively
```

This intercepts LangGraph's `ToolNode` executions at the framework level. Developers using LangGraph don't need `@gate.tool()` on individual functions — the adapter handles session context, tool call recording, and replay mocking by hooking into LangGraph's execution pipeline directly.

Similar adapters for CrewAI and AutoGen are in scope after LangGraph, prioritized by adoption metrics from early users.

---

## State Architecture and Distributed Deployment

**Single-process agents (v0.1 default):** State is in-memory (or local SQLite for persistence). Zero configuration required. This covers the vast majority of POC deployments, CLI agents, and many simple production deployments.

**Distributed agents (Celery workers, Lambda, horizontal scale):** In-memory SDK state cannot enforce session budgets or detect loops across workers. Worker B doesn't know what Worker A spent. This is a real architectural constraint.

The fix is a pluggable state backend:

```python
# Single process: in-memory (default, zero-config)
gate = StateLoom.from_config("stateloom.yaml")

# Distributed: control plane as state backend
gate = StateLoom.from_config("stateloom.yaml",
    state_backend="https://api.stateloom.io")

# Self-hosted: Redis in your VPC
gate = StateLoom.from_config("stateloom.yaml",
    state_backend="redis://your-redis:6379")
```

The SDK's enforcement logic stays local. Session state syncs to the shared backend. Policy checks are: read from local cache, write to shared backend, local cache invalidated on write.

**This boundary is a feature, not a limitation.** Single-process is free and zero-touch. Distributed requires the control plane, and that's the natural upsell. We document this boundary explicitly — we don't hide it.

The product concept says clearly: if you're running agents across multiple processes or workers, you need the control plane for session-scoped enforcement. We tell developers this before they hit the wall, not after.

---

## Implementation Notes

### Serialization

**Do not use `pickle` anywhere.** OpenAI's Python SDK uses Pydantic. Store all cached responses as JSON using `model_dump_json()`. Define a strict schema for the session record format and version it from day one.

If we use `pickle`, the moment a user upgrades their OpenAI SDK from v1.10 to v1.11, their entire library of pinned golden runs corrupts and crashes their CI/CD pipeline. This is a trust-destroying bug that would be entirely self-inflicted.

Schema format: `session_schema_v1.json`, versioned, with explicit migration path for breaking changes.

### Monkey-Patching Strategy

`stateloom.init()` auto-patches OpenAI and Anthropic clients. This is the convenience path for local development.

`stateloom.wrap(client)` is the explicit path and the production recommendation:

```python
openai_client = stateloom.wrap(openai.OpenAI())
```

We run CI against latest SDK versions before publishing releases. Upstream SDK breakages are our highest-priority bugs. We have zero tolerance for "works on our machine" with SDK compatibility.

### Network Blocker Sequencing

The strict replay network blocker is architecturally coupled with the replay engine. This is not a Phase 9 feature — it's a Phase 7 feature. We do not ship `stateloom replay` without the network blocker. An unsafe replay feature is worse than no replay feature.

The integration test suite for replay runs with network blocked by default. This is a design constraint on test infrastructure, not an inconvenience — it means our replay tests are clean and deterministic.

---

## What We're Explicitly Not Building (v0.1)

**Network proxy.** SDK-first. Teams with hard network proxy requirements combine us with Portkey or LiteLLM. We coexist. Network proxy is a Year 3 decision.

**Semantic cache.** Exact-match only until we have real-world hit rate data. Embedding overhead in the critical path is only justified if the data supports it.

**OPA/WASM policy engine.** JSON policy sync is sufficient. OPA when customers demonstrate need for programmable policy logic.

**Full file/subprocess replay interception.** The strict replay network blocker covers HTTP. Direct file writes, native DB drivers, subprocess calls require `@gate.tool()`. This is documented scope, not a gap we're hiding.

---

## Business Model

### Billing Metric: Synced Sessions to the Control Plane

**Why not per-seat:** CI/CD pipelines and production agents don't have seats. We'd cap out at low ACVs and create perverse incentives.

**Why not per-token-intercepted:** Makes StateLoom feel like a tax on LLM usage. Creates misaligned incentives — we profit when customers waste tokens. We lose revenue when our caching feature works.

**Why not ROI pricing ("10% of what we save you"):** Requires agreeing on a counterfactual. Procurement will dispute every number. Never build a billing model on a counterfactual.

**Why synced sessions work:**

1. **Verifiable.** The control plane receives the sync. The billing event is the sync itself. A network blip fails the sync and retries with backoff — it doesn't silently lose billing data.

2. **Aligns with value.** You only sync sessions when you need distributed state, production triage, team sharing, or CI/CD regression. These are the features that create real business value.

3. **Doesn't penalize local usage.** A developer running single-process agents locally pays nothing. Habit builds. When they hit the distributed state wall or need production triage, they upgrade.

4. **Scales with actual usage.** 100,000 session syncs a day is a meaningful number that grows with the customer's business.

### Tier Structure

**Free:** Local SDK, unlimited sessions, in-memory or local SQLite state, localhost dashboard. No control plane. No limit.

**Team ($X/month + per 10k synced sessions):** Hosted control plane. `gate.share()`, `gate.pin()`, `stateloom pull`, CI/CD regression suite. Distributed budget enforcement across workers. RBAC for dashboard access. Billing metric: synced sessions. (Exact price TBD pending beta usage data — we need to know what a "session" looks like in practice before we price it.)

**Enterprise (negotiated):** Self-hosted control plane for regulated industries. VPC deployment. RBAC, audit trail, SSO, SLA. Server-side data masking for `stateloom pull` is required here and enforced by the control plane. Flat platform fee + synced session volume tier.

**Important:** The SDK remains the enforcement point. The control plane never proxies LLM traffic. This is non-negotiable — proxying traffic is a different product with different security surface area and different compliance requirements.

---

## Risks and Open Questions

### Risk 1: `@gate.tool()` Adoption Rate

Replay safety depends on developers decorating their tools, or on the network blocker catching what they missed. The network blocker handles HTTP. Non-HTTP side effects (file writes, native DB drivers) still require `@gate.tool()`.

We track decoration rate in telemetry. We measure how often `StateLoomSideEffectError` fires in strict mode (indicating an undecorated side effect was caught). High SideEffectError rates tell us the network blocker is working; they also tell us where to invest in better automatic detection.

### Risk 2: Monkey-Patching Fragility

We run CI against latest OpenAI and Anthropic SDK versions before publishing releases. The `wrap()` path is more resilient than `init()` auto-patching because it wraps a specific client instance rather than patching the global module. Production deployments should use `wrap()`.

### Risk 3: Non-Determinism in CI/CD Regression

Agents with `datetime.now()`, `random()`, or live external reads via undecorated tools will produce flaky regressions. We detect and flag these in CI output. Long-term fix: VCR-style HTTP interceptor for all external I/O beyond what strict replay already blocks. Not v0.1, but the replay architecture is designed to add it without breaking the public API.

### Risk 4: Semantic Loop Detection Threshold

False positive rate is unsolved at launch. We start conservative, make it configurable, let early adopters tune and share data. This is acceptable uncertainty for v0.1 — exact-match loop detection covers the obvious cases, semantic loop detection is a best-effort enhancement.

### Risk 5: PII Masking Correctness for `stateloom pull`

Server-side masking before session pull is a compliance requirement, not a nice-to-have. The masking must be reliable. Regex-based PII detection has false negative rates — a credit card number formatted unusually may not be caught. We need to be explicit in enterprise contracts about what masking covers and does not cover. We are not a compliance tool; we are a best-effort data minimization layer. Enterprise customers with strict PII requirements need their own data classification on top of ours.

### Risk 6: LangGraph Adapter Maintenance Burden

LangGraph's internals change frequently. The `patch_langgraph_tools()` adapter will require active maintenance against LangGraph releases. We need the same upstream CI process we have for OpenAI/Anthropic SDKs, running against the latest LangGraph version before we publish releases.

### Open Question: Pricing Calibration

The billing metric (synced sessions) is correct. The price per 10k synced sessions is unknown until we have beta usage data. We need to know: what's the average session size, how many sessions does a typical production deployment generate per month, and what does a "team" look like in this space (5 developers? 50?). We ship free, collect data, price in Month 3.

---

## What's Genuinely Novel

1. **Session as the primitive.** Every other tool in this stack models the API call. We model the session. This is not a positioning claim — it's an architectural difference that enables features physically impossible from stateless tools.

2. **Deterministic replay for agents, framework-agnostic.** LangGraph has state rewind inside its own graph execution. Nobody has built cheap, deterministic, safe replay for arbitrary Python agent code across frameworks. This is the wedge.

3. **In-path enforcement with session context.** The combination of being in the call path (like Portkey) *and* having session state (like LangFuse) means we can enforce mid-session budget limits, detect loops across the full call history, and produce exact savings numbers. Passive tracers can't enforce. Stateless proxies can't use session context. We do both.

4. **Production incident triage.** Pulling the exact production session state — all LLM responses, all tool outputs — to a local machine for free, deterministic debugging. Nobody is doing this well across frameworks.

---

## What We'd Show a Developer in the First Five Minutes

```python
# Before StateLoom: this is your debug loop
# 1. Run agent (2 min, $0.40)
# 2. Agent fails on step 14
# 3. Add a print statement
# 4. Re-run agent (2 min, $0.40)
# 5. Repeat until fixed

# After StateLoom:
import stateloom
stateloom.init()

# First run: session recorded automatically
result = my_agent.run("summarize quarterly report")
# → [StateLoom] session:abc123 | 15 steps | $0.40 | FAILED at step 14

# Fix a bug in step 14
# Second run: replay steps 1-13 instantly from cache, run step 14 live
gate.replay(session="abc123", mock_until_step=13)
# → [StateLoom] Replaying 13 steps from cache... done (0.3s, $0.00)
# → [StateLoom] Running step 14 live...
# → Fixed.
```

That's the pitch. Everything else — budget enforcement, PII detection, loop detection, production triage, CI regression — is additive value on top of a developer who already pulled the SDK in because replay saved them two minutes and forty cents on their first use.

---

*This document reflects the state of the concept after the peer review. The open questions listed above are genuinely open — we don't have answers yet and we're not pretending we do. Build the POC, get it in front of developers, and let usage data close the gaps.*