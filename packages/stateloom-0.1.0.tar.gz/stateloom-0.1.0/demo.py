"""StateLoom Demo — Multi-step agent simulation.

Shows off: session tracking, cost tracking, PII detection, caching,
loop detection, the live dashboard, session_root auto-sessions, and async support.

Usage:
    export OPENAI_API_KEY=your-key
    python demo.py

Then open the dashboard URL printed at startup.
"""

from __future__ import annotations

import asyncio
import logging
import socket

import stateloom

logger = logging.getLogger("stateloom.demo")

DASHBOARD_PORT = 4781


def _port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


async def run_demo() -> None:
    # --- Initialize StateLoom ---
    logger.info("=" * 60)
    logger.info("  StateLoom Demo — Multi-Step Agent Simulation")
    logger.info("=" * 60)

    # Detect an existing dashboard to avoid starting a second one
    init_kwargs: dict = dict(
        pii=True,
        pii_rules=[
            {"pattern": "email", "mode": "audit"},
            {"pattern": "credit_card", "mode": "block", "on_middleware_failure": "pass"},
            {"pattern": "api_key", "mode": "block", "on_middleware_failure": "block"},
        ],
        budget=2.0,
        budget_on_middleware_failure="pass",
        dashboard_port=DASHBOARD_PORT,
    )

    dashboard_url = f"http://localhost:{DASHBOARD_PORT}"
    for port in [DASHBOARD_PORT, 4782]:
        if _port_in_use(port):
            logger.info("  Detected existing dashboard on port %d — attaching", port)
            dashboard_url = f"http://localhost:{port}"
            init_kwargs["dashboard"] = False
            init_kwargs["store_backend"] = "sqlite"
            break

    stateloom.init(**init_kwargs)

    import openai
    client = openai.AsyncOpenAI()

    logger.info("Dashboard: %s", dashboard_url)
    logger.info("Open it in your browser to see live activity!")
    await asyncio.sleep(2)

    # =========================================================
    # SESSION 1: Customer Support Agent (async + session_root)
    # =========================================================
    @stateloom.tool(session_root=True, name="customer_support_agent")
    async def customer_support_agent() -> None:
        logger.info("-" * 60)
        logger.info("  Session 1: Customer Support Agent")
        logger.info("-" * 60)

        # Step 1: Classify the ticket
        logger.info("  [Step 1] Classifying customer ticket...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a ticket classifier. Respond with one word: billing, technical, or general."},
                {"role": "user", "content": "I was charged twice for my subscription last month. My email is sarah@example.com and my card ending in 4111 1111 1111 1111 was charged $29.99 twice."},
            ],
        )

        # Step 2: Look up account info
        logger.info("  [Step 2] Generating account lookup query...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Generate a SQL query to look up this customer's billing history. Just the query, nothing else."},
                {"role": "user", "content": "Customer with email sarah@example.com, charged twice for subscription"},
            ],
        )

        # Step 3: Draft response
        logger.info("  [Step 3] Drafting customer response...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Draft a brief, empathetic customer support response about a duplicate charge. Keep it under 3 sentences."},
                {"role": "user", "content": "Customer sarah@example.com was charged $29.99 twice. Refund has been initiated."},
            ],
        )

        # Step 4: Duplicate call (triggers cache hit)
        logger.info("  [Step 4] Making duplicate call (should cache hit)...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Draft a brief, empathetic customer support response about a duplicate charge. Keep it under 3 sentences."},
                {"role": "user", "content": "Customer sarah@example.com was charged $29.99 twice. Refund has been initiated."},
            ],
        )

    await customer_support_agent()

    # =========================================================
    # SESSION 2: Research Agent (async + session_root)
    # =========================================================
    @stateloom.tool(session_root=True, name="research_agent")
    async def research_agent() -> None:
        logger.info("-" * 60)
        logger.info("  Session 2: Research Agent")
        logger.info("-" * 60)

        logger.info("  [Step 1] Researching Python web frameworks...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": "List the top 5 Python web frameworks in 2025 with one sentence about each."},
            ],
        )

        logger.info("  [Step 2] Comparing FastAPI vs Django...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": "Compare FastAPI and Django for building a REST API. 3 bullet points for each."},
            ],
        )

        logger.info("  [Step 3] Writing summary...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": "Write a 2-sentence recommendation for which Python framework to use for a new microservice."},
            ],
        )

    await research_agent()

    # =========================================================
    # SESSION 3: Code Review Agent (async + session_root)
    # =========================================================
    @stateloom.tool(session_root=True, name="code_review_agent")
    async def code_review_agent() -> None:
        logger.info("-" * 60)
        logger.info("  Session 3: Code Review Agent")
        logger.info("-" * 60)

        code_snippet = '''
def process_payment(user_email, card_number):
    # API key: sk-test1234567890abcdefghijk
    response = requests.post("https://api.stripe.com/v1/charges",
        headers={"Authorization": "Bearer sk_live_abc123def456"},
        json={"amount": 2999, "currency": "usd"})
    return response.json()
'''
        logger.info("  [Step 1] Reviewing code for security issues...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Review this code for security issues. Be brief — bullet points only."},
                {"role": "user", "content": f"Review this code:\n{code_snippet}"},
            ],
        )

        logger.info("  [Step 2] Suggesting fixes...")
        await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Rewrite this function to fix the security issues. Just the code, no explanation."},
                {"role": "user", "content": f"Fix this code:\n{code_snippet}"},
            ],
        )

    await code_review_agent()

    # =========================================================
    # Summary
    # =========================================================
    logger.info("=" * 60)
    logger.info("  Demo Complete!")
    logger.info("=" * 60)
    logger.info("  3 sessions simulated with %d LLM calls", 3 + 3 + 2 + 1)
    logger.info("  Each agent function auto-created its own session via session_root=True")
    logger.info("  Dashboard: %s", dashboard_url)
    logger.info("  Try these dashboard views:")
    logger.info("    - Live Overview  -> see all events and total cost")
    logger.info("    - Sessions       -> click a session for step-by-step detail")
    logger.info("    - Cost Analytics -> see cost breakdown by model")
    logger.info("    - PII Monitor    -> see detected emails, API keys, card numbers")
    logger.info("  Press Ctrl+C to exit.")

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        stateloom.shutdown()


if __name__ == "__main__":
    asyncio.run(run_demo())
