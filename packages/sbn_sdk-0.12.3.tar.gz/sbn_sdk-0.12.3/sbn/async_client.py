"""Canonical async facades over the SBN SDK.

These async clients intentionally mirror the sync ``SbnClient`` and
``AgentClient`` surfaces so downstream async applications can converge on one
SDK contract. The current implementation offloads the sync SDK's work onto
threads. That gives Tower and other FastAPI services a stable async shape now,
while keeping the canonical namespaces and auth model in one place.
"""

from __future__ import annotations

import asyncio
from functools import wraps
from typing import Any, Generic, TypeVar

import httpx

from sbn._http import RetryConfig, SbnError
from sbn.agent import AgentClient
from sbn.auth import SigningKey
from sbn.client import SbnClient


T = TypeVar("T")


class AsyncNamespaceProxy(Generic[T]):
    """Async wrapper over a sync SDK namespace."""

    def __init__(self, namespace: T) -> None:
        self._namespace = namespace

    @property
    def raw(self) -> T:
        return self._namespace

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._namespace, name)
        if not callable(attr):
            return attr

        @wraps(attr)
        async def _wrapped(*args: Any, **kwargs: Any) -> Any:
            return await asyncio.to_thread(attr, *args, **kwargs)

        return _wrapped


class AsyncRealityNamespaceProxy(AsyncNamespaceProxy[T]):
    """Reality compatibility wrapper for async downstream callers."""

    async def create_evidence(self, *, items: Any) -> Any:
        return await self.ingest_evidence(items=items)

    async def recompute_fact(self, fact_id: str) -> Any:
        return await self.recompute(fact_id)


class AsyncLatticeNamespaceProxy(AsyncNamespaceProxy[T]):
    """Lattice compatibility wrapper for async downstream callers."""

    async def create_workflow(self, *args: Any, **kwargs: Any) -> Any:
        if args and not kwargs and len(args) == 1 and isinstance(args[0], dict):
            return await super().__getattr__("create_workflow")(**args[0])
        return await super().__getattr__("create_workflow")(*args, **kwargs)

    async def get_workflows(self, *args: Any, **kwargs: Any) -> Any:
        return await self.list_workflows(*args, **kwargs)


class AsyncReceiptsNamespaceProxy(AsyncNamespaceProxy[T]):
    """Receipts compatibility wrapper for async downstream callers."""

    async def fetch_receipt(self, receipt_id: str) -> Any:
        return await self.get(receipt_id)

    async def get_by_hash(self, snapchore_hash: str) -> Any:
        return await self.list(hash=snapchore_hash)


class AsyncAgentClient:
    """Async facade over :class:`sbn.agent.AgentClient`."""

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8090",
        tenant_id: str | None = None,
        retry: RetryConfig | None = None,
        timeout: float = 10.0,
        user_agent: str = "sbn-agent-async/0.2",
        transport: httpx.BaseTransport | None = None,
        raw_client: AgentClient | None = None,
    ) -> None:
        self._sync = raw_client or AgentClient(
            base_url=base_url,
            tenant_id=tenant_id,
            retry=retry,
            timeout=timeout,
            user_agent=user_agent,
            transport=transport,
        )
        self._gateway = AsyncNamespaceProxy(self._sync.gateway)
        self._snapchore = AsyncNamespaceProxy(self._sync.snapchore)
        self._reality = AsyncRealityNamespaceProxy(self._sync.reality)
        self._lattice = AsyncLatticeNamespaceProxy(self._sync.lattice)
        self._governance = AsyncNamespaceProxy(self._sync.governance)
        self._numa = AsyncNamespaceProxy(self._sync.numa)
        self._receipts = AsyncReceiptsNamespaceProxy(self._sync.receipts)

    @property
    def raw(self) -> AgentClient:
        return self._sync

    def authenticate_api_key(self, api_key: str) -> None:
        self._sync.authenticate_api_key(api_key)

    def authenticate_bearer(self, token: str) -> None:
        self._sync.authenticate_bearer(token)

    def authenticate_signing_key(
        self,
        signing_key: SigningKey,
        *,
        subject: str = "sbn-agent",
        scopes: tuple[str, ...] = ("attest.write",),
        cdna: str = "agent",
        ttl_seconds: int = 300,
    ) -> None:
        self._sync.authenticate_signing_key(
            signing_key,
            subject=subject,
            scopes=scopes,
            cdna=cdna,
            ttl_seconds=ttl_seconds,
        )

    def set_tenant(self, tenant_id: str | None) -> None:
        self._sync.set_tenant(tenant_id)

    @property
    def gateway(self) -> AsyncNamespaceProxy[Any]:
        return self._gateway

    @property
    def snapchore(self) -> AsyncNamespaceProxy[Any]:
        return self._snapchore

    @property
    def reality(self) -> AsyncNamespaceProxy[Any]:
        return self._reality

    @property
    def lattice(self) -> AsyncNamespaceProxy[Any]:
        return self._lattice

    @property
    def governance(self) -> AsyncNamespaceProxy[Any]:
        return self._governance

    @property
    def numa(self) -> AsyncNamespaceProxy[Any]:
        return self._numa

    @property
    def receipts(self) -> AsyncNamespaceProxy[Any]:
        return self._receipts

    def open_slot(self, *args: Any, **kwargs: Any) -> Any:
        return self._sync.open_slot(*args, **kwargs)

    async def health_check(self) -> bool:
        for path in ("/health", "/healthz"):
            try:
                await asyncio.to_thread(self._sync._transport.get, path)
                return True
            except SbnError as exc:
                if exc.status_code == 404:
                    continue
                return False
            except Exception:
                return False
        return False

    async def close(self) -> None:
        await asyncio.to_thread(self._sync.close)

    async def __aenter__(self) -> AsyncAgentClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()


class AsyncSbnClient:
    """Async facade over :class:`sbn.client.SbnClient`.

    This gives downstream async runtimes one canonical namespace layout today:
    ``gateway``, ``snapchore``, ``reality``, ``lattice``, ``governance``,
    ``numa``, and the rest of the sync SDK surface. The transport strategy can
    evolve later without changing the async contract.
    """

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8090",
        tenant_id: str | None = None,
        retry: RetryConfig | None = None,
        timeout: float = 10.0,
        user_agent: str = "sbn-sdk-async/0.1",
        transport: httpx.BaseTransport | None = None,
        raw_client: SbnClient | None = None,
    ) -> None:
        self._sync = raw_client or SbnClient(
            base_url=base_url,
            tenant_id=tenant_id,
            retry=retry,
            timeout=timeout,
            user_agent=user_agent,
            transport=transport,
        )
        self._acp = AsyncNamespaceProxy(self._sync.acp)
        self._gateway = AsyncNamespaceProxy(self._sync.gateway)
        self._bitblocks = AsyncNamespaceProxy(self._sync.bitblocks)
        self._snapchore = AsyncNamespaceProxy(self._sync.snapchore)
        self._console = AsyncNamespaceProxy(self._sync.console)
        self._control_plane = AsyncNamespaceProxy(self._sync.control_plane)
        self._lattice = AsyncLatticeNamespaceProxy(self._sync.lattice)
        self._reality = AsyncRealityNamespaceProxy(self._sync.reality)
        self._blocks = AsyncNamespaceProxy(self._sync.blocks)
        self._atlas = AsyncNamespaceProxy(self._sync.atlas)
        self._gec = AsyncNamespaceProxy(self._sync.gec)
        self._governance = AsyncNamespaceProxy(self._sync.governance)
        self._numa = AsyncNamespaceProxy(self._sync.numa)
        self._receipts = AsyncReceiptsNamespaceProxy(self._sync.receipts)

    @property
    def raw(self) -> SbnClient:
        return self._sync

    def authenticate_api_key(self, api_key: str) -> None:
        self._sync.authenticate_api_key(api_key)

    def authenticate_bearer(self, token: str) -> None:
        self._sync.authenticate_bearer(token)

    def authenticate_signing_key(
        self,
        signing_key: SigningKey,
        *,
        subject: str = "sbn-sdk",
        scopes: tuple[str, ...] = ("attest.write",),
        cdna: str = "sdk",
        ttl_seconds: int = 300,
    ) -> None:
        self._sync.authenticate_signing_key(
            signing_key,
            subject=subject,
            scopes=scopes,
            cdna=cdna,
            ttl_seconds=ttl_seconds,
        )

    def set_tenant(self, tenant_id: str | None) -> None:
        self._sync.set_tenant(tenant_id)

    @property
    def acp(self) -> AsyncNamespaceProxy[Any]:
        return self._acp

    @property
    def gateway(self) -> AsyncNamespaceProxy[Any]:
        return self._gateway

    @property
    def bitblocks(self) -> AsyncNamespaceProxy[Any]:
        return self._bitblocks

    @property
    def snapchore(self) -> AsyncNamespaceProxy[Any]:
        return self._snapchore

    @property
    def console(self) -> AsyncNamespaceProxy[Any]:
        return self._console

    @property
    def control_plane(self) -> AsyncNamespaceProxy[Any]:
        return self._control_plane

    @property
    def lattice(self) -> AsyncNamespaceProxy[Any]:
        return self._lattice

    @property
    def reality(self) -> AsyncNamespaceProxy[Any]:
        return self._reality

    @property
    def blocks(self) -> AsyncNamespaceProxy[Any]:
        return self._blocks

    @property
    def atlas(self) -> AsyncNamespaceProxy[Any]:
        return self._atlas

    @property
    def gec(self) -> AsyncNamespaceProxy[Any]:
        return self._gec

    @property
    def governance(self) -> AsyncNamespaceProxy[Any]:
        return self._governance

    @property
    def numa(self) -> AsyncNamespaceProxy[Any]:
        return self._numa

    @property
    def receipts(self) -> AsyncNamespaceProxy[Any]:
        return self._receipts

    def open_slot(self, *args: Any, **kwargs: Any) -> Any:
        return self._sync.open_slot(*args, **kwargs)

    async def health_check(self) -> bool:
        for path in ("/health", "/healthz"):
            try:
                await asyncio.to_thread(self._sync._transport.get, path)
                return True
            except SbnError as exc:
                if exc.status_code == 404:
                    continue
                return False
            except Exception:
                return False
        return False

    async def close(self) -> None:
        await asyncio.to_thread(self._sync.close)

    async def __aenter__(self) -> AsyncSbnClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()
