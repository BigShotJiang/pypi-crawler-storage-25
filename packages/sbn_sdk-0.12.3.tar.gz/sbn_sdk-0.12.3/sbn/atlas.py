"""Atlas sub-client — app registration, token exchange, env provisioning, frontier resolution.

Provides two entry points:

1. **AtlasClient** — sub-client following the standard ``GecClient`` pattern.
   Used via ``client.atlas.resolve(...)`` when you already have an ``SbnClient``.

2. **Atlas** — standalone convenience class with auto-config.
   Used via ``Atlas.from_credentials(...)`` for zero-setup SDK usage.

Example::

    from sbn import Atlas

    # Option A: explicit credentials
    atlas = Atlas.from_credentials(
        client_id="atl_a1b2c3d4e5f6g7h8",
        client_secret="atl_sec_...",
        base_url="https://api.smartblocks.network",
    )

    # Option B: from environment variables
    atlas = Atlas.from_env()

    # Frontier info is immediately available
    print(atlas.scoring_frontier)   # "ai.assistant"
    print(atlas.regime)             # "unknown"
    print(atlas.env_vars)           # {"ATLAS_CODE_FRONTIER": "ai.assistant", ...}

    # Resolve at runtime
    result = atlas.resolve(workflow="code", event_type="frontend_generation")
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any, Mapping

from sbn._http import AuthState, HttpTransport, RetryConfig, SbnError


PREFIX = "/api/atlas"


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class AtlasBinding:
    """A single workflow → frontier binding with CSK diagnostics."""

    workflow: str
    frontier: str
    c_max: float | None = None
    regime: str = "unknown"
    metallic_label: str | None = None
    lambda_score: float | None = None
    auto_provisioned: bool = True
    env_prefix: str = ""

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AtlasBinding:
        return cls(
            workflow=str(data.get("workflow", "default")),
            frontier=str(data.get("frontier", "")),
            c_max=data.get("c_max"),
            regime=str(data.get("regime", "unknown")),
            metallic_label=data.get("metallic_label"),
            lambda_score=data.get("lambda_score"),
            auto_provisioned=bool(data.get("auto_provisioned", True)),
            env_prefix=str(data.get("env_prefix", "")),
        )


@dataclass(slots=True)
class AtlasConfig:
    """Resolved Atlas configuration for a registered app."""

    app_id: str
    client_id: str
    app_name: str = ""
    bindings: list[AtlasBinding] = field(default_factory=list)
    env_vars: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AtlasConfig:
        bindings = [
            AtlasBinding.from_dict(b) for b in data.get("bindings", [])
        ]
        return cls(
            app_id=str(data.get("app_id", "")),
            client_id=str(data.get("client_id", "")),
            app_name=str(data.get("app_name", "")),
            bindings=bindings,
            env_vars=dict(data.get("env_vars", {})),
        )


# ---------------------------------------------------------------------------
# AtlasClient — sub-client (used via SbnClient.atlas)
# ---------------------------------------------------------------------------

class AtlasClient:
    """Atlas sub-client for frontier resolution, app management, and provisioning.

    Used as ``client.atlas.resolve(...)`` when wired into ``SbnClient``.
    """

    def __init__(self, transport: HttpTransport) -> None:
        self._t = transport

    # ── Frontier Resolution ───────────────────────────────────────────

    def resolve(
        self,
        *,
        workflow: str | None = None,
        event_type: str | None = None,
        frontier_hint: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Resolve the best frontier for the given workflow context.

        Returns scoring frontier, CSK diagnostics, regime placement,
        metallic map parameters, and steering guidance.
        """
        body: dict[str, Any] = {}
        if workflow:
            body["workflow"] = workflow
        if event_type:
            body["event_type"] = event_type
        if frontier_hint:
            body["frontier_hint"] = frontier_hint
        if context:
            body["context"] = context
        return self._t.post(f"{PREFIX}/resolve", json=body).json()

    def list_frontiers(
        self,
        *,
        kind: str | None = None,
        family: str | None = None,
        regime: str | None = None,
    ) -> dict[str, Any]:
        """List all frontiers in the Atlas registry with optional filters."""
        params: dict[str, str] = {}
        if kind:
            params["kind"] = kind
        if family:
            params["family"] = family
        if regime:
            params["regime"] = regime
        return self._t.get(f"{PREFIX}/frontiers", params=params).json()

    def get_frontier_snapshot(self, frontier_id: str) -> dict[str, Any]:
        """Fetch the current Atlas snapshot for a frontier id or canonical path."""
        return self._t.get(f"{PREFIX}/frontiers/{frontier_id}/snapshot").json()

    def get_frontier_history(
        self,
        frontier_id: str,
        *,
        window_hours: int | None = None,
        bucket_minutes: int | None = None,
        include_rollup: bool | None = None,
        include_coupling: bool | None = None,
        include_instrumentation: bool | None = None,
        include_interventions: bool | None = None,
    ) -> dict[str, Any]:
        """Fetch bucketed Atlas history for a frontier id or canonical path."""
        params: dict[str, str] = {}
        if window_hours is not None:
            params["window_hours"] = str(window_hours)
        if bucket_minutes is not None:
            params["bucket_minutes"] = str(bucket_minutes)
        if include_rollup is not None:
            params["include_rollup"] = "true" if include_rollup else "false"
        if include_coupling is not None:
            params["include_coupling"] = "true" if include_coupling else "false"
        if include_instrumentation is not None:
            params["include_instrumentation"] = "true" if include_instrumentation else "false"
        if include_interventions is not None:
            params["include_interventions"] = "true" if include_interventions else "false"
        return self._t.get(f"{PREFIX}/frontiers/{frontier_id}/history", params=params).json()

    def get_frontier_history_delta(
        self,
        frontier_id: str,
        *,
        since: str,
        bucket_minutes: int | None = None,
        include_rollup: bool | None = None,
        include_coupling: bool | None = None,
        include_instrumentation: bool | None = None,
        include_interventions: bool | None = None,
    ) -> dict[str, Any]:
        """Fetch only Atlas history changes since a timestamp cursor."""
        params: dict[str, str] = {"since": since}
        if bucket_minutes is not None:
            params["bucket_minutes"] = str(bucket_minutes)
        if include_rollup is not None:
            params["include_rollup"] = "true" if include_rollup else "false"
        if include_coupling is not None:
            params["include_coupling"] = "true" if include_coupling else "false"
        if include_instrumentation is not None:
            params["include_instrumentation"] = "true" if include_instrumentation else "false"
        if include_interventions is not None:
            params["include_interventions"] = "true" if include_interventions else "false"
        return self._t.get(f"{PREFIX}/frontiers/{frontier_id}/history/delta", params=params).json()

    def get_frontier_validation(
        self,
        frontier_id: str,
        *,
        tolerance: float | None = None,
    ) -> dict[str, Any]:
        """Replay Atlas provenance for the active frontier version and validate it."""
        params: dict[str, str] = {}
        if tolerance is not None:
            params["tolerance"] = str(tolerance)
        return self._t.get(f"{PREFIX}/frontiers/{frontier_id}/validate", params=params).json()

    def get_instrumentation_report(
        self,
        *,
        family: str | None = None,
        frontier_id: str | None = None,
        event_type: str | None = None,
        source_app: str | None = None,
        window_days: int | None = None,
        only_weak: bool | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Fetch Atlas instrumentation diagnostics for frontier/event payload quality."""
        params: dict[str, str] = {}
        if family:
            params["family"] = family
        if frontier_id:
            params["frontier_id"] = frontier_id
        if event_type:
            params["event_type"] = event_type
        if source_app:
            params["source_app"] = source_app
        if window_days is not None:
            params["window_days"] = str(window_days)
        if only_weak is not None:
            params["only_weak"] = "true" if only_weak else "false"
        if limit is not None:
            params["limit"] = str(limit)
        return self._t.get(f"{PREFIX}/diagnostics/instrumentation", params=params).json()

    def get_intervention_report(
        self,
        *,
        family: str | None = None,
        frontier_id: str | None = None,
        source_app: str | None = None,
        window_days: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Fetch first-class Atlas intervention events for coupling analysis."""
        params: dict[str, str] = {}
        if family:
            params["family"] = family
        if frontier_id:
            params["frontier_id"] = frontier_id
        if source_app:
            params["source_app"] = source_app
        if window_days is not None:
            params["window_days"] = str(window_days)
        if limit is not None:
            params["limit"] = str(limit)
        return self._t.get(f"{PREFIX}/interventions", params=params).json()

    # ── App Registration ──────────────────────────────────────────────

    def register_app(
        self,
        *,
        app_name: str,
        app_family: str,
        declared_workflows: list[str],
        declared_event_types: list[str] | None = None,
        workflow_specs: list[dict[str, Any]] | None = None,
        token_ttl_seconds: int = 3600,
    ) -> dict[str, Any]:
        """Register a new Atlas app with auto-provisioned frontier bindings.

        Returns client credentials (``client_secret`` shown once only).
        """
        body: dict[str, Any] = {
            "app_name": app_name,
            "app_family": app_family,
            "declared_workflows": declared_workflows,
            "token_ttl_seconds": token_ttl_seconds,
        }
        if declared_event_types:
            body["declared_event_types"] = declared_event_types
        if workflow_specs:
            body["workflow_specs"] = workflow_specs
        return self._t.post(f"{PREFIX}/apps/register", json=body).json()

    def exchange_token(
        self,
        *,
        client_id: str,
        client_secret: str,
    ) -> dict[str, Any]:
        """Exchange client credentials for a short-lived Atlas bearer token."""
        body = {"client_id": client_id, "client_secret": client_secret}
        return self._t.post(f"{PREFIX}/token", json=body).json()

    # ── Env Provisioning ──────────────────────────────────────────────

    def get_env(
        self,
        app_id: str,
        *,
        format: str = "json",
    ) -> dict[str, Any] | str:
        """Get provisioned environment variables for a registered app.

        Pass ``format="dotenv"`` for plain-text KEY=VALUE output.
        """
        resp = self._t.get(f"{PREFIX}/apps/{app_id}/env", params={"format": format})
        if format == "dotenv":
            return resp.text
        return resp.json()

    # ── App Management ────────────────────────────────────────────────

    def list_apps(self) -> dict[str, Any]:
        """List all Atlas apps registered by the authenticated user."""
        return self._t.get(f"{PREFIX}/apps").json()

    def revoke_app(self, app_id: str) -> dict[str, Any]:
        """Revoke an Atlas app and invalidate all its tokens."""
        return self._t.delete(f"{PREFIX}/apps/{app_id}").json()

    def mint_bound_key(
        self,
        app_id: str,
        *,
        label: str | None = None,
        scopes: list[str] | None = None,
    ) -> dict[str, Any]:
        """Mint a new network API key bound to an Atlas app."""
        body: dict[str, Any] = {}
        if label:
            body["label"] = label
        if scopes is not None:
            body["scopes"] = scopes
        return self._t.post(f"{PREFIX}/apps/{app_id}/keys/mint", json=body).json()

    def bind_existing_key(
        self,
        app_id: str,
        *,
        key_id: str,
    ) -> dict[str, Any]:
        """Bind an existing network API key to an Atlas app."""
        return self._t.post(
            f"{PREFIX}/apps/{app_id}/keys/bind",
            json={"key_id": key_id},
        ).json()

    def upsert_binding(
        self,
        app_id: str,
        *,
        workflow: str,
        frontier_id: str,
        pulse_type: str | None = None,
        event_types: list[str] | None = None,
        history_action: str | None = None,
    ) -> dict[str, Any]:
        """Set or replace an Atlas workflow frontier binding."""
        body: dict[str, Any] = {"workflow": workflow, "frontier_id": frontier_id}
        if pulse_type:
            body["pulse_type"] = pulse_type
        if event_types is not None:
            body["event_types"] = event_types
        if history_action:
            body["history_action"] = history_action
        return self._t.post(
            f"{PREFIX}/apps/{app_id}/bindings/upsert",
            json=body,
        ).json()

    # ── Coupling ────────────────────────────────────────────────────────────

    def list_couplings(
        self,
        *,
        frontier_id: str | None = None,
        coupling_type: str | None = None,
        min_strength: float | None = None,
    ) -> dict[str, Any]:
        """List detected frontier couplings with optional filters."""
        params: dict[str, str] = {}
        if frontier_id:
            params["frontier_id"] = frontier_id
        if coupling_type:
            params["coupling_type"] = coupling_type
        if min_strength is not None:
            params["min_strength"] = str(min_strength)
        return self._t.get(f"{PREFIX}/couplings", params=params).json()

    def get_frontier_couplings(
        self,
        frontier_id: str,
        *,
        min_strength: float | None = None,
    ) -> dict[str, Any]:
        """Get all couplings involving a specific frontier."""
        params: dict[str, str] = {}
        if min_strength is not None:
            params["min_strength"] = str(min_strength)
        return self._t.get(f"{PREFIX}/couplings/{frontier_id}", params=params).json()

    def detect_couplings(self) -> dict[str, Any]:
        """Manually trigger coupling detection across all projects."""
        return self._t.post(f"{PREFIX}/couplings/detect").json()

    # ── Calibration ────────────────────────────────────────────────────────

    def calibrate_frontier(
        self,
        *,
        frontier_id: str,
        window_days: int = 7,
        force: bool = False,
    ) -> dict[str, Any]:
        """Trigger CSK calibration for a specific frontier."""
        body = {
            "frontier_id": frontier_id,
            "window_days": window_days,
            "force": force,
        }
        return self._t.post(f"{PREFIX}/calibrate", json=body).json()

    def calibrate_all(
        self,
        *,
        window_days: int = 7,
        force: bool = False,
    ) -> dict[str, Any]:
        """Trigger CSK calibration for all active frontiers."""
        params = {
            "window_days": str(window_days),
            "force": "true" if force else "false",
        }
        return self._t.post(f"{PREFIX}/calibrate/all", params=params).json()


# ---------------------------------------------------------------------------
# Atlas — standalone convenience class with auto-config
# ---------------------------------------------------------------------------

class Atlas:
    """Zero-setup Atlas client that auto-discovers config via token exchange.

    Usage::

        atlas = Atlas.from_credentials(
            client_id="atl_...",
            client_secret="atl_sec_...",
            base_url="https://api.smartblocks.network",
        )
        print(atlas.scoring_frontier)
        print(atlas.regime)
        result = atlas.resolve(workflow="code")

    The client:
    1. Exchanges credentials for a short-lived token
    2. Fetches env vars (frontier bindings, CSK, dynamics)
    3. Caches config and auto-refreshes token on expiry
    """

    def __init__(
        self,
        *,
        client_id: str,
        client_secret: str,
        base_url: str = "https://api.smartblocks.network",
        timeout: float = 10.0,
        retry: RetryConfig | None = None,
    ) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._base_url = base_url.rstrip("/")

        self._auth = AuthState()
        self._transport = HttpTransport(
            base_url=self._base_url,
            auth=self._auth,
            retry=retry,
            timeout=timeout,
            user_agent="sbn-atlas-sdk/0.1",
        )
        self._atlas_client = AtlasClient(self._transport)

        # Token state
        self._token: str | None = None
        self._token_expires_at: float = 0.0
        self._app_id: str | None = None

        # Resolved config (populated on first access)
        self._config: AtlasConfig | None = None

    # ── Factory methods ───────────────────────────────────────────────

    @classmethod
    def from_credentials(
        cls,
        *,
        client_id: str,
        client_secret: str,
        base_url: str = "https://api.smartblocks.network",
        timeout: float = 10.0,
        retry: RetryConfig | None = None,
        eager: bool = True,
    ) -> Atlas:
        """Create an Atlas client from explicit credentials.

        If ``eager=True`` (default), immediately exchanges credentials
        for a token and fetches the full config. Set ``eager=False``
        to defer until first use.
        """
        inst = cls(
            client_id=client_id,
            client_secret=client_secret,
            base_url=base_url,
            timeout=timeout,
            retry=retry,
        )
        if eager:
            inst._ensure_authenticated()
            inst._ensure_config()
        return inst

    @classmethod
    def from_env(
        cls,
        *,
        base_url: str = "https://api.smartblocks.network",
        timeout: float = 10.0,
        retry: RetryConfig | None = None,
        eager: bool = True,
    ) -> Atlas:
        """Create an Atlas client from ``ATLAS_CLIENT_ID`` and ``ATLAS_CLIENT_SECRET`` env vars."""
        client_id = os.environ.get("ATLAS_CLIENT_ID", "")
        client_secret = os.environ.get("ATLAS_CLIENT_SECRET", "")
        if not client_id or not client_secret:
            raise ValueError(
                "ATLAS_CLIENT_ID and ATLAS_CLIENT_SECRET must be set in environment"
            )
        return cls.from_credentials(
            client_id=client_id,
            client_secret=client_secret,
            base_url=base_url,
            timeout=timeout,
            retry=retry,
            eager=eager,
        )

    # ── Token management ──────────────────────────────────────────────

    def _ensure_authenticated(self) -> None:
        """Exchange credentials for a token if expired or missing."""
        now = time.time()
        if self._token and now < self._token_expires_at - 30:
            return  # Still valid (with 30s buffer)

        resp = self._atlas_client.exchange_token(
            client_id=self._client_id,
            client_secret=self._client_secret,
        )
        self._token = resp["access_token"]
        self._app_id = resp.get("app_id")
        expires_in = resp.get("expires_in", 3600)
        self._token_expires_at = now + expires_in

        # Update transport auth so subsequent requests use the token
        self._auth.bearer_token = self._token
        self._auth.api_key = None

    def _ensure_config(self) -> None:
        """Fetch env vars / config if not yet loaded."""
        if self._config is not None:
            return
        self._ensure_authenticated()
        if not self._app_id:
            raise SbnError("no app_id from token exchange", status_code=0)
        data = self._atlas_client.get_env(self._app_id)
        if isinstance(data, dict):
            self._config = AtlasConfig.from_dict(data)

    # ── Properties (auto-resolve on access) ───────────────────────────

    @property
    def config(self) -> AtlasConfig:
        self._ensure_config()
        assert self._config is not None
        return self._config

    @property
    def app_id(self) -> str:
        return self.config.app_id

    @property
    def bindings(self) -> list[AtlasBinding]:
        return self.config.bindings

    @property
    def env_vars(self) -> dict[str, str]:
        return self.config.env_vars

    @property
    def scoring_frontier(self) -> str | None:
        """The canonical_path of the first bound scoring frontier."""
        if self.bindings:
            return self.bindings[0].frontier
        return None

    @property
    def regime(self) -> str:
        """The regime of the first bound frontier."""
        if self.bindings:
            return self.bindings[0].regime
        return "unknown"

    @property
    def c_max(self) -> float | None:
        if self.bindings:
            return self.bindings[0].c_max
        return None

    @property
    def metallic_label(self) -> str | None:
        if self.bindings:
            return self.bindings[0].metallic_label
        return None

    # ── Delegation to AtlasClient ─────────────────────────────────────

    def resolve(
        self,
        *,
        workflow: str | None = None,
        event_type: str | None = None,
        frontier_hint: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Resolve a frontier at runtime (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.resolve(
            workflow=workflow,
            event_type=event_type,
            frontier_hint=frontier_hint,
            context=context,
        )

    def list_frontiers(self, **kwargs: Any) -> dict[str, Any]:
        self._ensure_authenticated()
        return self._atlas_client.list_frontiers(**kwargs)

    def get_frontier_snapshot(self, frontier_id: str) -> dict[str, Any]:
        """Fetch the current Atlas frontier snapshot (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_frontier_snapshot(frontier_id)

    def get_frontier_history(self, frontier_id: str, **kwargs: Any) -> dict[str, Any]:
        """Fetch bucketed Atlas frontier history (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_frontier_history(frontier_id, **kwargs)

    def get_frontier_history_delta(self, frontier_id: str, **kwargs: Any) -> dict[str, Any]:
        """Fetch only Atlas frontier changes since a cursor (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_frontier_history_delta(frontier_id, **kwargs)

    def get_frontier_validation(self, frontier_id: str, **kwargs: Any) -> dict[str, Any]:
        """Replay Atlas provenance for the active frontier version (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_frontier_validation(frontier_id, **kwargs)

    def get_instrumentation_report(self, **kwargs: Any) -> dict[str, Any]:
        """Fetch Atlas instrumentation diagnostics (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_instrumentation_report(**kwargs)

    def get_intervention_report(self, **kwargs: Any) -> dict[str, Any]:
        """Fetch first-class Atlas intervention events (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_intervention_report(**kwargs)

    def list_couplings(self, **kwargs: Any) -> dict[str, Any]:
        """List detected frontier couplings (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.list_couplings(**kwargs)

    def get_frontier_couplings(self, frontier_id: str, **kwargs: Any) -> dict[str, Any]:
        """Fetch couplings involving a specific frontier (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.get_frontier_couplings(frontier_id, **kwargs)

    def detect_couplings(self) -> dict[str, Any]:
        """Trigger coupling detection (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.detect_couplings()

    def mint_bound_key(self, app_id: str, **kwargs: Any) -> dict[str, Any]:
        """Mint a new network API key bound to this Atlas app."""
        self._ensure_authenticated()
        return self._atlas_client.mint_bound_key(app_id, **kwargs)

    def bind_existing_key(self, app_id: str, **kwargs: Any) -> dict[str, Any]:
        """Bind an existing network API key to this Atlas app."""
        self._ensure_authenticated()
        return self._atlas_client.bind_existing_key(app_id, **kwargs)

    def upsert_binding(self, app_id: str, **kwargs: Any) -> dict[str, Any]:
        """Set or replace an Atlas workflow frontier binding."""
        self._ensure_authenticated()
        return self._atlas_client.upsert_binding(app_id, **kwargs)

    def calibrate_frontier(self, **kwargs: Any) -> dict[str, Any]:
        """Trigger calibration for a specific frontier (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.calibrate_frontier(**kwargs)

    def calibrate_all(self, **kwargs: Any) -> dict[str, Any]:
        """Trigger calibration for all frontiers (auto-refreshes token if needed)."""
        self._ensure_authenticated()
        return self._atlas_client.calibrate_all(**kwargs)

    def get_env(self, format: str = "json") -> dict[str, Any] | str:
        """Fetch latest env vars (bypasses cache)."""
        self._ensure_authenticated()
        assert self._app_id
        return self._atlas_client.get_env(self._app_id, format=format)

    def dotenv(self) -> str:
        """Get env vars in .env format (KEY=VALUE lines)."""
        result = self.get_env(format="dotenv")
        return result if isinstance(result, str) else ""

    # ── Context manager ───────────────────────────────────────────────

    def __enter__(self) -> Atlas:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self._transport.close()

    def __repr__(self) -> str:
        frontier = self.scoring_frontier if self._config else "?"
        return f"<Atlas client_id={self._client_id!r} frontier={frontier!r}>"
