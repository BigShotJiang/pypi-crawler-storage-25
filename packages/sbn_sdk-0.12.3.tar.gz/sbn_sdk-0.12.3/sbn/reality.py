"""Reality Check sub-client — fact attestation, evidence, and lattice graph."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

from sbn._http import HttpTransport

PREFIX = "/api/reality"


class RealityClient:
    """Fact attestation, evidence management, and reality lattice queries.

    Example::

        client = SbnClient(base_url="https://api.smartblocks.network")
        client.authenticate_api_key("sbn_live_abc123")

        # Create a fact (claims auto-extracted if not provided)
        result = client.reality.create_fact(
            "GDP grew 3.2% in Q4 2025 and inflation fell to 2.1%."
        )

        # Ingest evidence (reliability resolved from source registry)
        client.reality.ingest_evidence([{
            "source_uri": "https://bls.gov/report/2025q4",
            "extracted_claims": ["GDP grew 3.2% in Q4 2025"],
        }])

        # Recompute scores
        client.reality.recompute(result["fact_id"])
    """

    def __init__(self, transport: HttpTransport) -> None:
        self._t = transport

    # ── Facts ──────────────────────────────────────────────────────

    def create_fact(
        self,
        text: str,
        *,
        entities: Sequence[str] | None = None,
        claims: Sequence[str] | None = None,
        citations: Sequence[str] | None = None,
        is_public: bool = False,
    ) -> dict[str, Any]:
        """Create a new fact in the reality lattice.

        If ``claims`` is empty the server will auto-extract atomic claims
        from ``text`` using its built-in claim extractor.
        """
        body: dict[str, Any] = {"text": text, "is_public": is_public}
        if entities:
            body["entities"] = list(entities)
        if claims:
            body["claims"] = list(claims)
        if citations:
            body["citations"] = list(citations)
        return self._t.post(f"{PREFIX}/facts", json=body).json()

    def get_fact(self, fact_id: str) -> dict[str, Any]:
        """Fetch a single fact with scores."""
        return self._t.get(f"{PREFIX}/facts/{fact_id}").json()

    def list_facts(
        self,
        *,
        entity: str | None = None,
        state: str | None = None,
        include_public: bool = False,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List facts with optional filters."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if entity:
            params["entity"] = entity
        if state:
            params["state"] = state
        if include_public:
            params["include_public"] = "true"
        return self._t.get(f"{PREFIX}/facts", params=params).json()

    def search_facts(
        self,
        *,
        entity: str | None = None,
        state: str | None = None,
    ) -> list[dict[str, Any]]:
        """Search facts by entity and/or state. Returns items list."""
        params: dict[str, Any] = {}
        if entity:
            params["entity"] = entity
        if state:
            params["state"] = state
        data = self._t.get(f"{PREFIX}/facts", params=params).json()
        return data.get("items", [])

    # ── Evidence ────────────────────────────────────────────────────

    def ingest_evidence(
        self,
        items: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any]:
        """Ingest a batch of evidence items into the project lattice.

        Each item should contain at minimum ``source_uri`` and
        ``extracted_claims``.  If ``reliability`` is omitted the server
        resolves it from its source reliability registry.
        """
        body = {"items": [dict(i) for i in items]}
        return self._t.post(f"{PREFIX}/evidence", json=body).json()

    def ingest_content(
        self,
        content: str,
        *,
        source_uri: str | None = None,
        source_type: str = "text",
        source_title: str | None = None,
        submitted_by: str | None = None,
        submission_channel: str = "sdk",
        gec_domain: str | None = None,
    ) -> dict[str, Any]:
        """Submit raw text/markdown content to the ingestion pipeline."""
        body: dict[str, Any] = {
            "content": content,
            "source_type": source_type,
            "submission_channel": submission_channel,
        }
        if source_uri:
            body["source_uri"] = source_uri
        if source_title:
            body["source_title"] = source_title
        if submitted_by:
            body["submitted_by"] = submitted_by
        if gec_domain:
            body["gec_domain"] = gec_domain
        return self._t.post(f"{PREFIX}/ingest", json=body).json()

    def upload_source(
        self,
        path: str | Path,
        *,
        source_type: str | None = None,
        source_title: str | None = None,
        submitted_by: str | None = None,
        submission_channel: str = "sdk_upload",
        gec_domain: str | None = None,
    ) -> dict[str, Any]:
        """Upload a txt/md/docx/pdf source artifact for ingestion."""
        file_path = Path(path)
        resolved_type = source_type or file_path.suffix.lstrip(".").lower() or "text"
        with file_path.open("rb") as handle:
            files = {
                "file": (
                    file_path.name,
                    handle.read(),
                    "application/octet-stream",
                )
            }
        data: dict[str, Any] = {
            "source_type": resolved_type,
            "submission_channel": submission_channel,
        }
        if source_title:
            data["source_title"] = source_title
        if submitted_by:
            data["submitted_by"] = submitted_by
        if gec_domain:
            data["gec_domain"] = gec_domain
        return self._t.post(f"{PREFIX}/ingest/upload", data=data, files=files).json()

    def list_ingestions(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List ingestions for the current project."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        return self._t.get(f"{PREFIX}/ingest", params=params).json()

    def get_ingestion(self, ingestion_id: str) -> dict[str, Any]:
        """Fetch a full ingestion envelope by ID."""
        return self._t.get(f"{PREFIX}/ingest/{ingestion_id}").json()

    # ── Scoring ─────────────────────────────────────────────────────

    def recompute(self, fact_id: str) -> dict[str, Any]:
        """Recompute trust/density/compression scores for a fact.

        Returns the new scores, state, and a signed receipt hash.
        """
        return self._t.post(f"{PREFIX}/facts/{fact_id}/recompute", json={}).json()

    def review_fact(
        self,
        fact_id: str,
        *,
        action: str,
        target_fact_id: str | None = None,
        note: str | None = None,
    ) -> dict[str, Any]:
        """Accept, reject, or merge an extracted fact during review."""
        body: dict[str, Any] = {"action": action}
        if target_fact_id:
            body["target_fact_id"] = target_fact_id
        if note is not None:
            body["note"] = note
        return self._t.post(f"{PREFIX}/facts/{fact_id}/review", json=body).json()

    # ── Graph ───────────────────────────────────────────────────────

    def get_lattice(self) -> dict[str, Any]:
        """Return the full lattice graph (nodes + edges) for visualization."""
        return self._t.get(f"{PREFIX}/lattice").json()

    # ── Health ──────────────────────────────────────────────────────

    def health(self) -> dict[str, Any]:
        """Check Reality Check service health."""
        return self._t.get(f"{PREFIX}/health").json()
