"""sbn ops — operator utilities wrapping existing cli/sbctl commands.

These commands require the full smartblocks_v2 repo (not just sbn-sdk).
They operate on local files and signing keys, not the remote API.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

ops_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)


def _check_repo():
    """Verify we're in the full repo, not just SDK install."""
    try:
        from cli import sbctl  # noqa: F401
    except ImportError:
        typer.echo("Operator commands require the full smartblocks_v2 repository.")
        typer.echo("These commands are not available in a standalone sbn-sdk install.")
        raise typer.Exit(1)


@ops_app.command("seed-tenant")
def seed_tenant(
    name: str = typer.Option("demo-tenant", "--name", "-n", help="Display name for the seeded tenant"),
    base_path: Optional[Path] = typer.Option(None, "--base-path", help="Override SB_DATA_ROOT"),
) -> None:
    """Register a synthetic tenant/agent and return its receipt path."""
    _check_repo()
    from cli.sbctl import seed_tenant as _seed
    _seed(name=name, base_path=base_path)


@ops_app.command("open-slot")
def open_slot(
    agent_id: str = typer.Argument(..., help="Agent identifier returned by seed-tenant"),
    base_path: Optional[Path] = typer.Option(None, "--base-path", help="Override SB_DATA_ROOT"),
) -> None:
    """Open a slot for the provided agent."""
    _check_repo()
    from cli.sbctl import open_slot as _open
    _open(agent_id=agent_id, base_path=base_path)


@ops_app.command("close-slot")
def close_slot(
    slot_id: str = typer.Argument(..., help="Slot identifier to close"),
    base_path: Optional[Path] = typer.Option(None, "--base-path", help="Override SB_DATA_ROOT"),
) -> None:
    """Close an active slot and emit the receipt path."""
    _check_repo()
    from cli.sbctl import close_slot as _close
    _close(slot_id=slot_id, base_path=base_path)


@ops_app.command("verify")
def verify(
    slot_id: str = typer.Argument(..., help="Slot identifier to verify"),
    base_path: Optional[Path] = typer.Option(None, "--base-path", help="Override SB_DATA_ROOT"),
) -> None:
    """Run registry verification for a slot."""
    _check_repo()
    from cli.sbctl import verify as _verify
    _verify(slot_id=slot_id, base_path=base_path)


@ops_app.command("init")
def init(
    name: str = typer.Option("demo-tenant", "--name", "-n", help="Display name for the seeded tenant"),
    ticks: int = typer.Option(2, "--ticks", min=2, help="Tick receipts to emit before closing"),
    base_path: Optional[Path] = typer.Option(None, "--base-path", help="Override SB_DATA_ROOT"),
) -> None:
    """Run the end-to-end smoke test: seed, open, tick, close, and verify."""
    _check_repo()
    from cli.sbctl import init as _init
    _init(name=name, ticks=ticks, base_path=base_path)


@ops_app.command("bundle-status")
def bundle_status() -> None:
    """Display active bundle metadata, fallbacks, and metrics in use."""
    _check_repo()
    from cli.sbctl import bundle_status as _status
    _status()
