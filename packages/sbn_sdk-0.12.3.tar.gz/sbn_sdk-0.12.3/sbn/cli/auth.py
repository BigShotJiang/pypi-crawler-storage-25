"""sbn auth — authentication and credential management."""
from __future__ import annotations

import os
from typing import Optional

import typer

from sbn.cli._config import load_config
from sbn.cli._output import print_kv, print_success, print_error

auth_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)


@auth_app.command("login")
def login(
    api_key: Optional[str] = typer.Option(None, "--api-key", help="SBN API key (sbn_live_... or sbn_test_...)"),
    atlas_client_id: Optional[str] = typer.Option(None, "--atlas-client-id", help="Atlas client ID"),
    atlas_client_secret: Optional[str] = typer.Option(None, "--atlas-client-secret", help="Atlas client secret"),
) -> None:
    """Configure authentication credentials.

    Prints export commands to set in your shell. No persistent config file is written.
    """
    if not api_key and not atlas_client_id:
        print_error("Provide --api-key or --atlas-client-id / --atlas-client-secret")
        raise typer.Exit(1)

    lines = []
    if api_key:
        lines.append(f"export SBN_API_KEY={api_key}")
    if atlas_client_id:
        lines.append(f"export ATLAS_CLIENT_ID={atlas_client_id}")
    if atlas_client_secret:
        lines.append(f"export ATLAS_CLIENT_SECRET={atlas_client_secret}")

    print_success("Run the following to configure your shell:\n")
    for line in lines:
        typer.echo(f"  {line}")
    typer.echo("")
    typer.echo("Or add them to your .bashrc / .zshrc for persistence.")


@auth_app.command("status")
def status(ctx: typer.Context) -> None:
    """Show current authentication state."""
    config = load_config(ctx.obj)

    pairs = {
        "Base URL": config.base_url,
        "API Key": _mask(config.api_key) if config.api_key else "(not set)",
        "Atlas Client ID": config.atlas_client_id or "(not set)",
        "Atlas Client Secret": _mask(config.atlas_client_secret) if config.atlas_client_secret else "(not set)",
        "Output Format": config.output_format,
    }

    configured = config.api_key or config.atlas_client_id
    if configured:
        print_success("Authenticated")
    else:
        print_error("Not authenticated — set SBN_API_KEY or ATLAS_CLIENT_ID")

    typer.echo("")
    print_kv(pairs, highlights={"API Key", "Atlas Client ID"})


@auth_app.command("logout")
def logout() -> None:
    """Print commands to unset credentials from your shell."""
    typer.echo("Run the following to clear credentials:\n")
    typer.echo("  unset SBN_API_KEY")
    typer.echo("  unset SBN_BASE_URL")
    typer.echo("  unset ATLAS_CLIENT_ID")
    typer.echo("  unset ATLAS_CLIENT_SECRET")


def _mask(value: str | None) -> str:
    if not value:
        return "(not set)"
    if len(value) <= 10:
        return value[:4] + "..."
    return value[:8] + "..." + value[-4:]
