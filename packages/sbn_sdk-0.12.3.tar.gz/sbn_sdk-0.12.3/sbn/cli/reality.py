"""sbn reality - facts, ingestions, lattice graph, and document filing."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_sbn_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table

reality_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
facts_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
ingestions_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
ingest_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
reality_lattice_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)

reality_app.add_typer(facts_app, name="facts", help="Fact creation, inspection, and recompute.")
reality_app.add_typer(ingestions_app, name="ingestions", help="Browse document/content ingestions.")
reality_app.add_typer(ingest_app, name="ingest", help="File content or source uploads into the lattice.")
reality_app.add_typer(reality_lattice_app, name="lattice", help="Inspect the Reality lattice graph.")


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _fact_id(item: dict[str, Any]) -> str:
    return str(item.get("fact_id") or item.get("id") or "")


def _ingestion_id(item: dict[str, Any]) -> str:
    return str(item.get("ingestion_id") or item.get("id") or "")


def _format_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def _fact_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "fact_id": _fact_id(item),
                "state": _format_value(item.get("state")),
                "trust_score": _format_value(item.get("trust_score")),
                "density_index": _format_value(item.get("density_index")),
                "compression_index": _format_value(item.get("compression_index")),
                "created_at": _format_value(item.get("created_at")),
            }
        )
    return rows


def _ingestion_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "ingestion_id": _ingestion_id(item),
                "status": _format_value(item.get("status")),
                "source_type": _format_value(item.get("source_type")),
                "source_title": _format_value(item.get("source_title") or item.get("source_uri")),
                "created_at": _format_value(item.get("created_at")),
            }
        )
    return rows


@facts_app.command("list")
def facts_list(
    ctx: typer.Context,
    entity: Optional[str] = typer.Option(None, "--entity", help="Filter by entity."),
    state: Optional[str] = typer.Option(None, "--state", help="Filter by fact state."),
    include_public: bool = typer.Option(False, "--include-public", help="Include public facts."),
    limit: int = typer.Option(100, "--limit", min=1, help="Maximum rows to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Pagination offset."),
) -> None:
    """List facts in the current project lattice."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.list_facts(
            entity=entity,
            state=state,
            include_public=include_public,
            limit=limit,
            offset=offset,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("items") or result.get("facts") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_fact_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} fact(s)")
    print_table(
        _fact_rows(items),
        ["fact_id", "state", "trust_score", "density_index", "compression_index", "created_at"],
    )


@facts_app.command("get")
def facts_get(
    ctx: typer.Context,
    fact_id: str = typer.Argument(..., help="Fact ID."),
) -> None:
    """Fetch a single fact with scoring and receipt context."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.get_fact(fact_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _fact_id(result)
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Fact {resolved_id}")
    print_kv(
        {
            "State": result.get("state", "?"),
            "Trust": _format_value(result.get("trust_score")),
            "Density": _format_value(result.get("density_index")),
            "Compression": _format_value(result.get("compression_index")),
            "Receipt": result.get("latest_receipt_hash") or result.get("receipt_hash") or "(pending)",
            "Created": result.get("created_at", ""),
        },
        highlights={"State", "Receipt"},
    )
    if result.get("text"):
        typer.echo(f"\nText:\n  {result['text']}")
    if result.get("claims"):
        typer.echo("\nClaims:")
        for claim in result["claims"]:
            typer.echo(f"  - {claim}")
    if result.get("entities"):
        typer.echo("\nEntities:")
        for entity in result["entities"]:
            typer.echo(f"  - {entity}")


@facts_app.command("recompute")
def facts_recompute(
    ctx: typer.Context,
    fact_id: str = typer.Argument(..., help="Fact ID."),
) -> None:
    """Recompute trust, density, compression, and receipt state for a fact."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.recompute(fact_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _fact_id(result) or fact_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Recomputed {resolved_id}")
    print_kv(
        {
            "State": result.get("state", "?"),
            "Trust": _format_value(result.get("trust_score")),
            "Density": _format_value(result.get("density_index")),
            "Compression": _format_value(result.get("compression_index")),
            "Receipt": result.get("receipt_hash") or result.get("latest_receipt_hash") or "(pending)",
        },
        highlights={"State", "Receipt"},
    )


@facts_app.command("review")
def facts_review(
    ctx: typer.Context,
    fact_id: str = typer.Argument(..., help="Fact ID."),
    action: str = typer.Option(..., "--action", help="Review action: accept, reject, discard, or merge."),
    target_fact_id: Optional[str] = typer.Option(None, "--target-fact-id", help="Required for merge actions."),
    note: Optional[str] = typer.Option(None, "--note", help="Optional reviewer note."),
) -> None:
    """Accept, reject, or merge a fact during review."""
    normalized_action = action.strip().lower()
    if normalized_action == "discard":
        normalized_action = "reject"
    if normalized_action not in {"accept", "reject", "merge"}:
        print_error("Action must be one of: accept, reject, discard, merge.")
        raise typer.Exit(1)
    if normalized_action == "merge" and not target_fact_id:
        print_error("--target-fact-id is required when --action merge.")
        raise typer.Exit(1)

    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.review_fact(
            fact_id,
            action=normalized_action,
            target_fact_id=target_fact_id,
            note=note,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(_fact_id(result) or fact_id)
        return

    print_success(f"Reviewed fact {_fact_id(result) or fact_id}")
    print_kv(
        {
            "Action": result.get("review", {}).get("action") or normalized_action,
            "State": result.get("state") or result.get("review_state") or "",
            "Target Fact": result.get("review", {}).get("target_fact_id") or result.get("merge_target", {}).get("fact_id") or "",
            "Reviewed By": result.get("review", {}).get("reviewed_by") or "",
            "Reviewed At": result.get("review", {}).get("reviewed_at") or "",
        },
        highlights={"Action", "State", "Target Fact"},
    )


@ingestions_app.command("list")
def ingestions_list(
    ctx: typer.Context,
    status: Optional[str] = typer.Option(None, "--status", help="Filter by ingestion status."),
    limit: int = typer.Option(50, "--limit", min=1, help="Maximum rows to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Pagination offset."),
) -> None:
    """List ingestions for the current project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.list_ingestions(status=status, limit=limit, offset=offset)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("items") or result.get("ingestions") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_ingestion_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} ingestion(s)")
    print_table(
        _ingestion_rows(items),
        ["ingestion_id", "status", "source_type", "source_title", "created_at"],
    )


@ingestions_app.command("get")
def ingestions_get(
    ctx: typer.Context,
    ingestion_id: str = typer.Argument(..., help="Ingestion ID."),
) -> None:
    """Fetch one ingestion with chunks, extracted facts, and linked evidence."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.get_ingestion(ingestion_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _ingestion_id(result) or ingestion_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Ingestion {resolved_id}")
    print_kv(
        {
            "Status": result.get("status", "?"),
            "Source Type": result.get("source_type", ""),
            "Source Title": result.get("source_title") or result.get("source_uri") or "",
            "Created": result.get("created_at", ""),
            "Chunks": len(result.get("chunks") or []),
            "Facts": len(result.get("facts") or []),
            "Evidence": len(result.get("evidence") or []),
        },
        highlights={"Status"},
    )


@ingest_app.command("text")
def ingest_text(
    ctx: typer.Context,
    content: Optional[str] = typer.Option(None, "--content", help="Raw text/markdown content."),
    file: Optional[Path] = typer.Option(None, "--file", exists=True, dir_okay=False, readable=True, help="Read content from a file."),
    source_uri: Optional[str] = typer.Option(None, "--source-uri", help="Source URI."),
    source_type: str = typer.Option("text", "--source-type", help="Source type, e.g. text or markdown."),
    source_title: Optional[str] = typer.Option(None, "--source-title", help="Source title."),
    submitted_by: Optional[str] = typer.Option(None, "--submitted-by", help="Submitter label."),
    submission_channel: str = typer.Option("cli", "--channel", help="Submission channel label."),
    gec_domain: Optional[str] = typer.Option(None, "--gec-domain", help="Optional GEC domain."),
) -> None:
    """Submit raw text or markdown into Reality ingestion."""
    if not content and not file:
        print_error("Provide --content or --file.")
        raise typer.Exit(1)

    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        body = content
        if file is not None:
            body = file.read_text(encoding="utf-8")
        result = client.reality.ingest_content(
            body or "",
            source_uri=source_uri,
            source_type=source_type,
            source_title=source_title,
            submitted_by=submitted_by,
            submission_channel=submission_channel,
            gec_domain=gec_domain,
        )
    except (OSError, UnicodeDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    ingestion_id = _ingestion_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(ingestion_id)
        return

    print_success(f"Ingested content as {ingestion_id or '(unknown id)'}")
    print_kv(
        {
            "Status": result.get("status", "?"),
            "Source Type": result.get("source_type", source_type),
            "Facts": len(result.get("facts") or []),
            "Evidence": len(result.get("evidence") or []),
        },
        highlights={"Status"},
    )


@ingest_app.command("upload")
def ingest_upload(
    ctx: typer.Context,
    path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Path to txt/md/docx/pdf file."),
    source_type: Optional[str] = typer.Option(None, "--source-type", help="Override detected source type."),
    source_title: Optional[str] = typer.Option(None, "--source-title", help="Source title."),
    submitted_by: Optional[str] = typer.Option(None, "--submitted-by", help="Submitter label."),
    submission_channel: str = typer.Option("cli_upload", "--channel", help="Submission channel label."),
    gec_domain: Optional[str] = typer.Option(None, "--gec-domain", help="Optional GEC domain."),
) -> None:
    """Upload a source file and file it through Reality ingestion."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.upload_source(
            path,
            source_type=source_type,
            source_title=source_title,
            submitted_by=submitted_by,
            submission_channel=submission_channel,
            gec_domain=gec_domain,
        )
    except (OSError, SbnError, SbnTransportError) as exc:
        _die(exc)

    ingestion_id = _ingestion_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(ingestion_id)
        return

    print_success(f"Uploaded {path.name} as {ingestion_id or '(unknown id)'}")
    print_kv(
        {
            "Status": result.get("status", "?"),
            "Source Type": result.get("source_type") or source_type or path.suffix.lstrip("."),
            "Facts": len(result.get("facts") or []),
            "Evidence": len(result.get("evidence") or []),
        },
        highlights={"Status"},
    )


@reality_lattice_app.command("get")
def lattice_get(ctx: typer.Context) -> None:
    """Fetch the full Reality lattice graph."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.reality.get_lattice()
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(str(len(result.get("nodes") or [])))
        return

    print_success("Fetched Reality lattice graph")
    print_kv(
        {
            "Nodes": len(result.get("nodes") or []),
            "Edges": len(result.get("edges") or []),
            "Supports": len([e for e in (result.get("edges") or []) if e.get("kind") == "supports"]),
            "Contradicts": len([e for e in (result.get("edges") or []) if e.get("kind") == "contradicts"]),
        },
        highlights={"Nodes", "Edges"},
    )
