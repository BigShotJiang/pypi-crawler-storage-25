"""CLI configuration — loads auth and connection settings from env vars + flags."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Optional

from sbn.agent import AgentClient
from sbn.client import SbnClient
from sbn.atlas import Atlas


@dataclass
class SbnCliConfig:
    """Resolved CLI configuration. Priority: CLI flags > env vars > defaults."""

    base_url: str = "https://api.smartblocks.network"
    api_key: Optional[str] = None
    atlas_client_id: Optional[str] = None
    atlas_client_secret: Optional[str] = None
    output_format: str = "table"  # table | json | quiet | dotenv


def load_config(ctx_obj: dict[str, Any] | None = None) -> SbnCliConfig:
    """Build config from context (CLI flags) and environment."""
    ctx = ctx_obj or {}
    return SbnCliConfig(
        base_url=(
            ctx.get("base_url")
            or os.environ.get("SBN_BASE_URL")
            or "https://api.smartblocks.network"
        ),
        api_key=(
            ctx.get("api_key")
            or os.environ.get("SBN_API_KEY")
        ),
        atlas_client_id=(
            ctx.get("atlas_client_id")
            or os.environ.get("ATLAS_CLIENT_ID")
        ),
        atlas_client_secret=(
            ctx.get("atlas_client_secret")
            or os.environ.get("ATLAS_CLIENT_SECRET")
        ),
        output_format=(
            ctx.get("format")
            or os.environ.get("SBN_OUTPUT_FORMAT")
            or "table"
        ),
    )


def get_sbn_client(config: SbnCliConfig) -> SbnClient:
    """Create an authenticated SbnClient from CLI config."""
    client = SbnClient(base_url=config.base_url)
    if config.api_key:
        client.authenticate_api_key(config.api_key)
    return client


def get_agent_client(config: SbnCliConfig) -> AgentClient:
    """Create an authenticated AgentClient from CLI config."""
    client = AgentClient(base_url=config.base_url)
    if config.api_key:
        client.authenticate_api_key(config.api_key)
    return client


def get_atlas(config: SbnCliConfig) -> Atlas:
    """Create an Atlas client from CLI config.

    Prefers Atlas credentials (client_id/secret) if available,
    otherwise falls back to SbnClient with API key.
    """
    if config.atlas_client_id and config.atlas_client_secret:
        return Atlas.from_credentials(
            client_id=config.atlas_client_id,
            client_secret=config.atlas_client_secret,
            base_url=config.base_url,
            eager=False,
        )
    # Fallback: use SbnClient's atlas sub-client (requires API key)
    raise SystemExit(
        "Atlas credentials required. Set ATLAS_CLIENT_ID and ATLAS_CLIENT_SECRET, "
        "or use --atlas-client-id and --atlas-client-secret."
    )
