"""sbn governance - proposal lifecycle commands."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_sbn_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table

governance_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
proposals_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)

governance_app.add_typer(proposals_app, name="proposals", help="Submit and manage governance proposals.")


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _proposal_id(item: dict[str, Any]) -> str:
    return str(item.get("id") or item.get("proposal_id") or "")


def _proposal_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        document = item.get("document") or {}
        rows.append(
            {
                "id": _proposal_id(item),
                "status": str(item.get("status") or ""),
                "frontier": str(document.get("frontier_id") or item.get("frontier_id") or ""),
                "submitter": str(document.get("submitter") or item.get("submitter") or ""),
                "risk_band": str(document.get("risk_band") or item.get("risk_band") or ""),
                "checksum": str(item.get("checksum") or ""),
            }
        )
    return rows


def _read_json_payload(source: str) -> dict[str, Any]:
    if source == "-":
        raw = sys.stdin.read()
    else:
        raw = Path(source).read_text(encoding="utf-8")
    payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise ValueError("Proposal payload must be a JSON object.")
    return payload


@proposals_app.command("list")
def proposals_list(
    ctx: typer.Context,
    status: Optional[str] = typer.Option(None, "--status", help="Filter by proposal status."),
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
) -> None:
    """List governance proposals for the current project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.governance.list_proposals(status=status, frontier=frontier)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("proposals") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_proposal_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} proposal(s)")
    print_table(_proposal_rows(items), ["id", "status", "frontier", "submitter", "risk_band", "checksum"])


@proposals_app.command("get")
def proposals_get(
    ctx: typer.Context,
    proposal_id: str = typer.Argument(..., help="Proposal ID."),
) -> None:
    """Fetch one proposal with its approval history."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.governance.get_proposal(proposal_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _proposal_id(result) or proposal_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    document = result.get("document") or {}
    print_success(f"Proposal {resolved_id}")
    print_kv(
        {
            "Status": result.get("status", ""),
            "Frontier": document.get("frontier_id") or result.get("frontier_id") or "",
            "Submitter": document.get("submitter") or result.get("submitter") or "",
            "Risk Band": document.get("risk_band") or result.get("risk_band") or "",
            "Checksum": result.get("checksum") or "",
            "Approvals": f"{result.get('approvals_received', '?')}/{result.get('approvals_required', '?')}",
        },
        highlights={"Status", "Checksum"},
    )
    if document.get("description"):
        typer.echo(f"\nDescription:\n  {document['description']}")


@proposals_app.command("create")
def proposals_create(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to proposal JSON, or - to read from stdin."),
) -> None:
    """Submit a governance proposal from JSON."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        payload = _read_json_payload(source)
        result = client.governance.create_proposal(payload)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    proposal_id = _proposal_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(proposal_id)
        return

    print_success(f"Created proposal {proposal_id or '(unknown id)'}")
    print_kv(
        {
            "Status": result.get("status", ""),
            "Checksum": result.get("checksum", ""),
        },
        highlights={"Status", "Checksum"},
    )


@proposals_app.command("approve")
def proposals_approve(
    ctx: typer.Context,
    proposal_id: str = typer.Argument(..., help="Proposal ID."),
    approver: str = typer.Option(..., "--approver", help="Approver identity."),
    signature: Optional[str] = typer.Option(None, "--signature", help="Optional signature."),
    note: Optional[str] = typer.Option(None, "--note", help="Approval note."),
) -> None:
    """Approve a proposal."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.governance.approve(
            proposal_id,
            approver=approver,
            signature=signature,
            note=note,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(_proposal_id(result) or proposal_id)
        return

    print_success(f"Approved proposal {_proposal_id(result) or proposal_id}")
    print_kv(
        {
            "Status": result.get("status", ""),
            "Approvals": f"{result.get('approvals_received', '?')}/{result.get('approvals_required', '?')}",
        },
        highlights={"Status"},
    )


@proposals_app.command("reject")
def proposals_reject(
    ctx: typer.Context,
    proposal_id: str = typer.Argument(..., help="Proposal ID."),
    approver: str = typer.Option(..., "--approver", help="Approver identity."),
    signature: Optional[str] = typer.Option(None, "--signature", help="Optional signature."),
    note: Optional[str] = typer.Option(None, "--note", help="Rejection note."),
) -> None:
    """Reject a proposal."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.governance.reject(
            proposal_id,
            approver=approver,
            signature=signature,
            note=note,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(_proposal_id(result) or proposal_id)
        return

    print_success(f"Rejected proposal {_proposal_id(result) or proposal_id}")
    print_kv({"Status": result.get("status", "rejected")}, highlights={"Status"})


@proposals_app.command("promote")
def proposals_promote(
    ctx: typer.Context,
    proposal_id: str = typer.Argument(..., help="Proposal ID."),
) -> None:
    """Promote an approved proposal."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.governance.promote(proposal_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(_proposal_id(result) or proposal_id)
        return

    print_success(f"Promoted proposal {_proposal_id(result) or proposal_id}")
    print_kv({"Status": result.get("status", "promoted")}, highlights={"Status"})
