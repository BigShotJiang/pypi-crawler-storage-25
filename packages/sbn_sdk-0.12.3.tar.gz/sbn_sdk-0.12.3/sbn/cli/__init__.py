"""SBN CLI — unified command-line interface for the SmartBlocks Network."""
