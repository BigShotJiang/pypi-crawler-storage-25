"""sbn acp - ACP status, lease inspection, and provider validation helpers."""
from __future__ import annotations

from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_sbn_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table

acp_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
leases_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)

acp_app.add_typer(leases_app, name="leases", help="Inspect, create, and release ACP leases.")


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _lease_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "lease_id": str(item.get("lease_id", "")),
                "provider": str(item.get("adapter_name", "")),
                "state": str(item.get("state", "")),
                "gpu": str(item.get("gpu_profile", "")),
                "region": str(item.get("region") or ""),
                "spot_price_usd_hr": f"{float(item.get('spot_price_usd_hr') or 0.0):.4f}",
                "total_cost_usd": "" if item.get("total_cost_usd") is None else f"{float(item.get('total_cost_usd') or 0.0):.4f}",
            }
        )
    return rows


@acp_app.command("status")
def status_cmd(
    ctx: typer.Context,
    project_id: str = typer.Argument(..., help="Project ID."),
) -> None:
    """Show ACP status for a project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.acp.status(project_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(result.get("project_id", project_id))
        return

    print_success(f"ACP status for {result.get('project_id', project_id)}")
    print_kv(
        {
            "Enabled": result.get("enabled", False),
            "Killed": result.get("killed", False),
            "Active Leases": result.get("active_leases", 0),
            "Total Leases": result.get("total_leases", 0),
            "Total Spend USD": f"{float(result.get('total_spend_usd') or 0.0):.4f}",
            "Total Receipts": result.get("total_receipts", 0),
        },
        highlights={"Enabled", "Killed", "Active Leases"},
    )


@leases_app.command("list")
def leases_list(
    ctx: typer.Context,
    project_id: str = typer.Argument(..., help="Project ID."),
    state: Optional[str] = typer.Option(None, "--state", help="Filter by lease state."),
    limit: int = typer.Option(20, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List ACP leases for a project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        items = client.acp.list_leases(project_id, state=state, limit=limit)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"leases": items})
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("lease_id", "")) for item in items), nl=False)
        return

    print_success(f"Fetched {len(items)} ACP lease(s)")
    print_table(
        _lease_rows(items),
        ["lease_id", "provider", "state", "gpu", "region", "spot_price_usd_hr", "total_cost_usd"],
    )


@leases_app.command("test")
def leases_test(
    ctx: typer.Context,
    project_id: str = typer.Argument(..., help="Project ID."),
    provider: str = typer.Option(..., "--provider", help="Provider name: render or gcp."),
    region: Optional[str] = typer.Option(None, "--region", help="Provider region or zone override."),
    gpu_profile: str = typer.Option("t4-16gb", "--gpu-profile", help="GPU profile for GPU-capable providers."),
    gpu_count: int = typer.Option(1, "--gpu-count", min=1, help="Number of GPUs to request."),
    vcpus: int = typer.Option(1, "--vcpus", min=1, help="Requested vCPUs."),
    ram_gb: int = typer.Option(2, "--ram-gb", min=1, help="Requested RAM in GB."),
    disk_gb: int = typer.Option(25, "--disk-gb", min=10, help="Requested disk in GB."),
    max_bid_usd_hr: float = typer.Option(1.0, "--max-bid-usd-hr", min=0.01, help="Maximum hourly price."),
    purpose: Optional[str] = typer.Option(None, "--purpose", help="Human note for the validation lease."),
) -> None:
    """Procure a manual ACP validation lease."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.acp.test_lease(
            project_id,
            provider=provider,
            region=region,
            gpu_profile=gpu_profile,
            gpu_count=gpu_count,
            vcpus=vcpus,
            ram_gb=ram_gb,
            disk_gb=disk_gb,
            max_bid_usd_hr=max_bid_usd_hr,
            purpose=purpose,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    lease = result.get("lease") or {}
    receipt = result.get("receipt") or {}
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(lease.get("lease_id", ""))
        return

    print_success(f"Provisioned test lease {lease.get('lease_id', '(unknown)')}")
    print_kv(
        {
            "Provider": lease.get("adapter_name", provider),
            "State": lease.get("state", ""),
            "Node": lease.get("node_name") or "(pending)",
            "Region": lease.get("region") or "",
            "Spot USD/hr": f"{float(lease.get('spot_price_usd_hr') or 0.0):.4f}",
            "Receipt": receipt.get("receipt_id") or "",
        },
        highlights={"Provider", "State", "Receipt"},
    )


@leases_app.command("release")
def leases_release(
    ctx: typer.Context,
    project_id: str = typer.Argument(..., help="Project ID."),
    lease_id: str = typer.Argument(..., help="Lease ID."),
    reason: str = typer.Option("manual_cli_release", "--reason", help="Release reason."),
) -> None:
    """Release an ACP lease and persist a release receipt."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.acp.release_lease(project_id, lease_id, reason=reason)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    lease = result.get("lease") or {}
    receipt = result.get("receipt") or {}
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(lease.get("lease_id", lease_id))
        return

    print_success(f"Released lease {lease.get('lease_id', lease_id)}")
    print_kv(
        {
            "Provider": lease.get("adapter_name", ""),
            "State": lease.get("state", ""),
            "Duration Seconds": f"{float(lease.get('duration_seconds') or 0.0):.2f}",
            "Total Cost USD": f"{float(lease.get('total_cost_usd') or 0.0):.6f}",
            "Receipt": receipt.get("receipt_id") or "",
        },
        highlights={"State", "Total Cost USD", "Receipt"},
    )
