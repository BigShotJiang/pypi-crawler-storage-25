"""CLI output formatters — table, JSON, quiet, dotenv, CSK bars."""
from __future__ import annotations

import json
import sys
from typing import Any, Sequence

try:
    from rich.console import Console
    from rich.table import Table
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

_console = Console(stderr=True) if HAS_RICH else None


def print_json(data: Any) -> None:
    """Pretty-print JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


def print_quiet(value: Any) -> None:
    """Print bare value — for scripting (TOKEN=$(sbn atlas token -f quiet))."""
    print(str(value), end="")


def print_kv(pairs: dict[str, Any], *, highlights: set[str] | None = None) -> None:
    """Print key-value pairs, optionally highlighting certain keys."""
    highlights = highlights or set()
    max_key = max(len(k) for k in pairs) if pairs else 0
    for k, v in pairs.items():
        label = f"{k:<{max_key}}"
        if HAS_RICH and k in highlights:
            _console.print(f"  [bold rose]{label}[/]  {v}", highlight=False)
        else:
            print(f"  {label}  {v}")


def print_table(rows: Sequence[dict[str, Any]], columns: Sequence[str]) -> None:
    """Print rows as a rich table, or fall back to tab-separated."""
    if not rows:
        print("  (no results)")
        return

    if HAS_RICH:
        table = Table(show_header=True, header_style="bold dim")
        for col in columns:
            table.add_column(col.upper())
        for row in rows:
            table.add_row(*[str(row.get(col, "")) for col in columns])
        _console.print(table)
    else:
        # Fallback: tab-separated
        print("\t".join(c.upper() for c in columns))
        for row in rows:
            print("\t".join(str(row.get(c, "")) for c in columns))


def print_csk_bars(csk: dict[str, float] | None) -> None:
    """Print CSK dimension bars with color."""
    if not csk:
        return

    labels = {"S": "Structure", "H": "Homeostasis", "D": "Diversity", "R": "Resources", "E": "Exchange"}

    for dim in ("S", "H", "D", "R", "E"):
        val = csk.get(dim, 0)
        bar_len = int(val * 10)
        bar = "#" * bar_len + "." * (10 - bar_len)

        if val < 0.45:
            color = "red" if HAS_RICH else ""
        elif val < 0.65:
            color = "yellow" if HAS_RICH else ""
        else:
            color = "green" if HAS_RICH else ""

        label = f"{labels.get(dim, dim):<13}"
        score = f"{val:.2f}"

        if HAS_RICH:
            _console.print(f"  {label} [{color}]{bar}[/] {score}")
        else:
            print(f"  {label} {bar} {score}")


def print_success(msg: str) -> None:
    if HAS_RICH:
        _console.print(f"[green bold]>[/] {msg}")
    else:
        print(f"> {msg}")


def print_error(msg: str) -> None:
    if HAS_RICH:
        _console.print(f"[red bold]![/] {msg}")
    else:
        print(f"! {msg}", file=sys.stderr)
