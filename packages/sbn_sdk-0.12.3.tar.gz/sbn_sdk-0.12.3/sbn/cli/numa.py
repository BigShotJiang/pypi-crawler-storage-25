"""sbn numa - hints, forecasts, diagnostics, and signal relay commands."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_sbn_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table

numa_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
signals_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
forecasts_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)

numa_app.add_typer(signals_app, name="signals", help="Relay, poll, acknowledge, and publish NUMA signals.")
numa_app.add_typer(forecasts_app, name="forecasts", help="Browse NUMA forecast reports.")


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _load_json_source(source: str) -> Any:
    if source == "-":
        raw = sys.stdin.read()
    else:
        raw = Path(source).read_text(encoding="utf-8")
    return json.loads(raw)


def _signal_id(item: dict[str, Any]) -> str:
    return str(item.get("signal_id") or item.get("id") or "")


def _signal_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "signal_id": _signal_id(item),
                "signal_type": str(item.get("signal_type") or ""),
                "frontier_id": str(item.get("frontier_id") or ""),
                "priority": str(item.get("priority") or ""),
                "lane": str(item.get("lane") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
        )
    return rows


def _forecast_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "frontier_id": str(item.get("frontier_id") or item.get("id") or ""),
                "generated_at": str(item.get("generated_at") or item.get("created_at") or ""),
                "status": str(item.get("status") or ""),
                "risk_band": str(item.get("risk_band") or item.get("report", {}).get("risk_band") or ""),
            }
        )
    return rows


def _lane_rows(result: dict[str, Any]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for lane_result in result.get("lanes") or []:
        rows.append(
            {
                "lane": str(lane_result.get("lane") or ""),
                "count": str(lane_result.get("count") or len(lane_result.get("signals") or [])),
                "cursor": str(lane_result.get("cursor") or ""),
            }
        )
    return rows


def _parse_cursors(values: list[str]) -> dict[str, str | None]:
    cursors: dict[str, str | None] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"Cursor must use lane=timestamp format, got: {value}")
        lane, since = value.split("=", 1)
        lane = lane.strip()
        if not lane:
            raise ValueError(f"Cursor lane cannot be empty: {value}")
        cursors[lane] = since.strip() or None
    return cursors


@numa_app.command("hints")
def hints_get(
    ctx: typer.Context,
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
) -> None:
    """Fetch distilled NUMA hints."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.numa.get_hints(frontier_id=frontier)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("hints") or result.get("items") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("hint_id") or item.get("id") or "") for item in items if item), nl=False)
        return

    print_success(f"Fetched {len(items)} hint(s)")
    print_table(
        [
            {
                "hint_id": str(item.get("hint_id") or item.get("id") or ""),
                "frontier_id": str(item.get("frontier_id") or ""),
                "kind": str(item.get("kind") or item.get("hint_type") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
            for item in items
        ],
        ["hint_id", "frontier_id", "kind", "created_at"],
    )


@numa_app.command("diagnostics")
def diagnostics_get(ctx: typer.Context) -> None:
    """Fetch NUMA diagnostics for the current project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.numa.get_diagnostics()
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(result.get("status") or result.get("summary") or "ok")
        return

    print_success("Fetched NUMA diagnostics")
    print_kv(
        {
            "Status": result.get("status") or "",
            "Summary": result.get("summary") or "",
            "Frontiers": len(result.get("frontiers") or []),
        },
        highlights={"Status"},
    )


@forecasts_app.command("list")
def forecasts_list(ctx: typer.Context) -> None:
    """List latest forecasts per frontier."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.numa.list_forecasts()
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("items") or result.get("forecasts") or result.get("reports") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("frontier_id") or item.get("id") or "") for item in items if item), nl=False)
        return

    print_success(f"Fetched {len(items)} forecast(s)")
    print_table(_forecast_rows(items), ["frontier_id", "generated_at", "status", "risk_band"])


@forecasts_app.command("get")
def forecasts_get(
    ctx: typer.Context,
    frontier_id: str = typer.Argument(..., help="Frontier ID."),
) -> None:
    """Fetch the latest forecast for one frontier."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.numa.get_forecast(frontier_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(str(result.get("frontier_id") or frontier_id))
        return

    report = result.get("report") or {}
    print_success(f"Forecast {result.get('frontier_id') or frontier_id}")
    print_kv(
        {
            "Generated": result.get("generated_at") or result.get("created_at") or "",
            "Risk Band": result.get("risk_band") or report.get("risk_band") or "",
            "Status": result.get("status") or report.get("status") or "",
            "Summary": report.get("summary") or result.get("summary") or "",
        },
        highlights={"Risk Band", "Status"},
    )


@signals_app.command("list")
def signals_list(
    ctx: typer.Context,
    signal_type: Optional[str] = typer.Option(None, "--signal-type", help="Filter by signal type."),
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
    lane: Optional[str] = typer.Option(None, "--lane", help="Filter by poll lane."),
    since: Optional[str] = typer.Option(None, "--since", help="Only signals after this ISO-8601 timestamp."),
    active_only: bool = typer.Option(True, "--active-only/--all", help="Hide expired signals by default."),
    limit: int = typer.Option(100, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List cached NUMA signals."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.numa.get_signals(
            signal_type=signal_type,
            frontier_id=frontier,
            active_only=active_only,
            since=since,
            lane=lane,
            limit=limit,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("signals") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_signal_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} signal(s)")
    print_table(_signal_rows(items), ["signal_id", "signal_type", "frontier_id", "priority", "lane", "created_at"])


@signals_app.command("poll")
def signals_poll(
    ctx: typer.Context,
    cursor: list[str] = typer.Option(None, "--cursor", help="Lane cursor in lane=ISO-8601 form. Repeat per lane."),
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
    limit_per_lane: int = typer.Option(10, "--limit-per-lane", min=1, help="Max signals per lane."),
) -> None:
    """Poll NUMA signals across lanes."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        cursors = _parse_cursors(cursor or [])
        result = client.numa.poll_signals_multilane(
            cursors=cursors,
            frontier_id=frontier,
            limit_per_lane=limit_per_lane,
        )
    except (ValueError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(sum(int(row["count"]) for row in _lane_rows(result)))
        return

    print_success(f"Polled {len(result.get('lanes') or [])} lane(s)")
    print_table(_lane_rows(result), ["lane", "count", "cursor"])


@signals_app.command("ack")
def signals_ack(
    ctx: typer.Context,
    signal_ids: list[str] = typer.Argument(..., help="One or more signal IDs."),
    agent_id: Optional[str] = typer.Option(None, "--agent-id", help="Optional agent identifier for audit."),
) -> None:
    """Acknowledge one or more signals."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.numa.ack_signals(signal_ids, agent_id=agent_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    acknowledged = int(result.get("acknowledged") or len(signal_ids))
    if fmt == "quiet":
        print_quiet(acknowledged)
        return

    print_success(f"Acknowledged {acknowledged} signal(s)")
    print_kv(
        {
            "Acknowledged": acknowledged,
            "Agent": agent_id or "",
        },
        highlights={"Acknowledged"},
    )


@signals_app.command("publish")
def signals_publish(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to signal JSON, or - to read from stdin."),
) -> None:
    """Publish one or more signals from JSON."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        payload = _load_json_source(source)
        if isinstance(payload, dict):
            signals = [payload]
        elif isinstance(payload, list):
            signals = payload
        else:
            raise ValueError("Signal payload must be a JSON object or array.")
        result = client.numa.publish_signals(signals)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    published = int(result.get("published") or len(signals))
    if fmt == "quiet":
        print_quiet(published)
        return

    print_success(f"Published {published} signal(s)")
    print_kv(
        {
            "Published": published,
            "Distilled": result.get("distilled") or "",
        },
        highlights={"Published"},
    )
