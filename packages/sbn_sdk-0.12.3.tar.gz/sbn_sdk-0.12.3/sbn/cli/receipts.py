"""sbn receipts - receipt lookup and discovery."""
from __future__ import annotations

from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_sbn_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table

receipts_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _receipt_id(item: dict[str, Any]) -> str:
    return str(item.get("receipt_id") or item.get("id") or item.get("hash") or "")


def _receipt_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "receipt_id": _receipt_id(item),
                "domain": str(item.get("domain") or item.get("frontier_id") or ""),
                "project_id": str(item.get("project_id") or ""),
                "status": str(item.get("status") or item.get("verification_status") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
        )
    return rows


@receipts_app.command("list")
def receipts_list(
    ctx: typer.Context,
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Filter by project ID."),
    hash: Optional[str] = typer.Option(None, "--hash", help="Exact receipt hash."),
    domain: Optional[str] = typer.Option(None, "--domain", help="Filter by domain/frontier."),
    since: Optional[str] = typer.Option(None, "--since", help="ISO-8601 cursor."),
    limit: int = typer.Option(20, "--limit", min=1, help="Maximum rows to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Pagination offset."),
) -> None:
    """List receipts from the discovery surface."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.receipts.list(
            project_id=project_id,
            hash=hash,
            domain=domain,
            limit=limit,
            offset=offset,
            since=since,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("receipts") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_receipt_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} receipt(s)")
    print_table(_receipt_rows(items), ["receipt_id", "domain", "project_id", "status", "created_at"])


@receipts_app.command("get")
def receipts_get(
    ctx: typer.Context,
    receipt_id: str = typer.Argument(..., help="Receipt ID or hash."),
) -> None:
    """Fetch a single receipt."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.receipts.get(receipt_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _receipt_id(result) or receipt_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Receipt {resolved_id}")
    print_kv(
        {
            "Status": result.get("status") or result.get("verification_status") or "",
            "Domain": result.get("domain") or result.get("frontier_id") or "",
            "Project": result.get("project_id") or "",
            "Created": result.get("created_at") or "",
            "Hash": result.get("hash") or result.get("receipt_hash") or resolved_id,
        },
        highlights={"Status", "Hash"},
    )
