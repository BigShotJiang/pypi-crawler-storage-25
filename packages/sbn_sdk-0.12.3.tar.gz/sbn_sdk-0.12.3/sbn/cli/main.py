"""SBN CLI — unified command-line interface for the SmartBlocks Network.

Usage:
    sbn --help
    sbn auth status
    sbn atlas resolve --workflow code
    sbn ops seed-tenant
"""
from __future__ import annotations

from typing import Optional

import typer

app = typer.Typer(
    name="sbn",
    help="SmartBlocks Network CLI — SDK-backed commands + operator utilities.",
    add_completion=False,
    pretty_exceptions_enable=False,
    no_args_is_help=True,
)


@app.callback()
def global_options(
    ctx: typer.Context,
    base_url: Optional[str] = typer.Option(
        None, "--base-url", envvar="SBN_BASE_URL",
        help="Override SBN API base URL",
    ),
    api_key: Optional[str] = typer.Option(
        None, "--api-key", envvar="SBN_API_KEY",
        help="API key for authentication",
    ),
    format: Optional[str] = typer.Option(
        None, "-f", "--format",
        help="Output format: table (default), json, quiet, dotenv",
    ),
) -> None:
    """Global options shared across all subcommands."""
    if ctx.obj is None:
        ctx.obj = {}
    if base_url:
        ctx.obj["base_url"] = base_url
    if api_key:
        ctx.obj["api_key"] = api_key
    if format:
        ctx.obj["format"] = format


# ── Mount subgroups ──────────────────────────────────────────────────

from sbn.cli.auth import auth_app
from sbn.cli.agent import agent_app, twin_app
from sbn.cli.acp import acp_app
from sbn.cli.atlas import atlas_app
from sbn.cli.governance import governance_app
from sbn.cli.lattice import lattice_app
from sbn.cli.numa import numa_app
from sbn.cli.reality import reality_app
from sbn.cli.receipts import receipts_app

app.add_typer(auth_app, name="auth", help="Authentication and credential management.")
app.add_typer(acp_app, name="acp", help="Autonomous Compute Procurement controls and validation.")
app.add_typer(agent_app, name="agent", help="Minimal operational surface for agents.")
app.add_typer(twin_app, name="twin", help="Minimal operational surface for digital twins.")
app.add_typer(atlas_app, name="atlas", help="Atlas frontier provisioning and resolution.")
app.add_typer(reality_app, name="reality", help="Reality facts, ingestions, and lattice graph.")
app.add_typer(lattice_app, name="lattice", help="Workflow DAG and cross-workflow graph operations.")
app.add_typer(numa_app, name="numa", help="NUMA hints, forecasts, diagnostics, and signals.")
app.add_typer(receipts_app, name="receipts", help="Receipt lookup and discovery.")
app.add_typer(governance_app, name="governance", help="Governance proposal lifecycle.")

# Operator commands — graceful fallback if not in full repo
try:
    from sbn.cli.ops import ops_app
    app.add_typer(ops_app, name="ops", help="Operator utilities (requires full repo install).")
except ImportError:
    pass


@app.command("version")
def version_cmd() -> None:
    """Show SBN SDK and CLI version."""
    from sbn import __version__
    typer.echo(f"sbn-sdk {__version__}")


if __name__ == "__main__":
    app()

