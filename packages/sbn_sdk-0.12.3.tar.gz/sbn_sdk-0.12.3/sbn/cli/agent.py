"""sbn agent / twin - minimal operational surface for agents and digital twins."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_agent_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table
from sbn.gateway import Receipt, SlotClosure, SlotHandle, SlotSummary

agent_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
twin_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
slots_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
snap_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_reality_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_facts_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_evidence_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_ingestions_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_reality_lattice_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_lattice_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_workflows_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_edges_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_numa_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_forecasts_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_signals_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_receipts_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_governance_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
agent_proposals_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)

agent_reality_app.add_typer(agent_facts_app, name="facts", help="Inspect and recompute facts.")
agent_reality_app.add_typer(agent_evidence_app, name="evidence", help="Ingest supporting and contradicting evidence.")
agent_reality_app.add_typer(agent_ingestions_app, name="ingestions", help="Browse ingestions.")
agent_reality_app.add_typer(agent_reality_lattice_app, name="lattice", help="Inspect the reality lattice graph.")
agent_lattice_app.add_typer(agent_workflows_app, name="workflows", help="Inspect workflow DAGs.")
agent_lattice_app.add_typer(agent_edges_app, name="edges", help="Inspect and create cross-workflow edges.")
agent_numa_app.add_typer(agent_forecasts_app, name="forecasts", help="Browse NUMA forecast reports.")
agent_numa_app.add_typer(agent_signals_app, name="signals", help="Browse NUMA signals.")
agent_governance_app.add_typer(agent_proposals_app, name="proposals", help="Inspect governance proposals.")

for app in (agent_app, twin_app):
    app.add_typer(slots_app, name="slots", help="Open, inspect, and close computation slots.")
    app.add_typer(snap_app, name="snap", help="Capture, verify, seal, and discover SnapChore artifacts.")
    app.add_typer(agent_reality_app, name="reality", help="Reality facts and ingestions.")
    app.add_typer(agent_lattice_app, name="lattice", help="Workflow inspection for agents and twins.")
    app.add_typer(agent_numa_app, name="numa", help="NUMA hints, forecasts, and signals.")
    app.add_typer(agent_receipts_app, name="receipts", help="Receipt lookup and discovery.")
    app.add_typer(agent_governance_app, name="governance", help="Governance proposal inspection.")


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _status_command(ctx: typer.Context) -> None:
    """Show local runtime posture for the governed agent surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    pairs = {
        "Base URL": config.base_url,
        "Auth Mode": "api_key" if config.api_key else "unauthenticated",
        "API Key": _mask(config.api_key),
        "Namespaces": ", ".join(row["namespace"] for row in _agent_capability_rows()),
        "Client": client.__class__.__name__,
        "Output Format": config.output_format,
    }

    if config.api_key:
        print_success("Agent runtime configured")
    else:
        print_error("Agent runtime is unauthenticated")
    print_kv(pairs, highlights={"Auth Mode", "API Key", "Namespaces"})


def _whoami_command(ctx: typer.Context) -> None:
    """Show the current local agent/twin identity posture."""
    config = load_config(ctx.obj)
    payload = {
        "client_type": "agent_runtime",
        "auth_mode": "api_key" if config.api_key else "unauthenticated",
        "api_key": _mask(config.api_key),
        "base_url": config.base_url,
        "tenant_id": None,
        "principal": None,
    }

    if config.output_format == "json":
        print_json(payload)
        return
    if config.output_format == "quiet":
        print_quiet(payload["auth_mode"])
        return

    print_success("Local agent identity posture")
    print_kv(
        {
            "Client Type": payload["client_type"],
            "Auth Mode": payload["auth_mode"],
            "API Key": payload["api_key"],
            "Base URL": payload["base_url"],
            "Tenant": "(default)",
            "Principal": "(not exposed by current SDK endpoint)",
        },
        highlights={"Auth Mode", "API Key"},
    )


def _capabilities_command(ctx: typer.Context) -> None:
    """List the governed capability surface exposed by AgentClient."""
    config = load_config(ctx.obj)
    rows = _agent_capability_rows()

    if config.output_format == "json":
        print_json({"capabilities": rows})
        return
    if config.output_format == "quiet":
        typer.echo("\n".join(row["namespace"] for row in rows), nl=False)
        return

    print_success("Governed agent capabilities")
    print_table(rows, ["namespace", "scope", "mode"])


for app in (agent_app, twin_app):
    app.command("status")(_status_command)
    app.command("whoami")(_whoami_command)
    app.command("capabilities")(_capabilities_command)


def _read_json_source(source: str) -> Any:
    if source == "-":
        raw = sys.stdin.read()
    else:
        raw = Path(source).read_text(encoding="utf-8")
    return json.loads(raw)


def _optional_json(source: str | None) -> dict[str, Any] | None:
    if not source:
        return None
    payload = _read_json_source(source)
    if not isinstance(payload, dict):
        raise ValueError("JSON payload must be an object.")
    return payload


def _slot_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "block_id": str(item.get("id") or item.get("block_id") or ""),
                "domain": str(item.get("domain") or ""),
                "type": str(item.get("block_type") or item.get("type") or ""),
                "hash": str(item.get("snapchore_hash") or item.get("hash") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
        )
    return rows


def _fact_id(item: dict[str, Any]) -> str:
    return str(item.get("fact_id") or item.get("id") or "")


def _ingestion_id(item: dict[str, Any]) -> str:
    return str(item.get("ingestion_id") or item.get("id") or "")


def _workflow_id(item: dict[str, Any]) -> str:
    return str(item.get("workflow_id") or item.get("id") or "")


def _proposal_id(item: dict[str, Any]) -> str:
    return str(item.get("id") or item.get("proposal_id") or "")


def _edge_id(item: dict[str, Any]) -> str:
    return str(item.get("id") or item.get("edge_id") or "")


def _format_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def _mask(value: str | None) -> str:
    if not value:
        return "(not set)"
    if len(value) <= 10:
        return value[:4] + "..."
    return value[:8] + "..." + value[-4:]


def _agent_capability_rows() -> list[dict[str, str]]:
    return [
        {"namespace": "gateway", "scope": "slots, attestations, receipts", "mode": "read/write"},
        {"namespace": "snapchore", "scope": "capture, verify, seal, discover", "mode": "read/write"},
        {"namespace": "reality", "scope": "facts, evidence, ingestions, lattice graph", "mode": "read/write"},
        {"namespace": "lattice", "scope": "workflow DAGs and step execution", "mode": "read/write"},
        {"namespace": "numa", "scope": "hints, forecasts, signals", "mode": "read/write"},
        {"namespace": "receipts", "scope": "receipt lookup and discovery", "mode": "read"},
        {"namespace": "governance", "scope": "proposal visibility and submission", "mode": "read/write"},
    ]


def _print_slot(slot: SlotHandle, *, prefix: str = "Slot") -> None:
    print_success(f"{prefix} {slot.id}")
    print_kv(
        {
            "Worker": slot.worker_id,
            "Task": slot.task_type,
            "State": slot.state,
            "Opened": slot.opened_at.isoformat() if slot.opened_at else "",
            "Receipt": slot.receipt_id or "",
        },
        highlights={"State", "Receipt"},
    )


def _print_closure(closure: SlotClosure) -> None:
    print_success(f"Closed slot {closure.slot_id}")
    print_kv(
        {
            "Receipt": closure.receipt_id,
            "Blocks Composed": closure.blocks_composed,
            "Blocks Attested": closure.blocks_attested,
            "Closed": closure.closed_at.isoformat() if closure.closed_at else "",
        },
        highlights={"Receipt"},
    )


def _print_receipt(receipt: Receipt) -> None:
    print_success(f"Receipt {receipt.id}")
    print_kv(
        {
            "Subject": receipt.subject_id,
            "Subject Type": receipt.subject_type,
            "Signer": receipt.signer_id or "",
            "Created": receipt.created_at.isoformat() if receipt.created_at else "",
            "Hash": receipt.snapchore_hash or "",
        },
        highlights={"Hash"},
    )


@agent_facts_app.command("list")
def facts_list(
    ctx: typer.Context,
    entity: Optional[str] = typer.Option(None, "--entity", help="Filter by entity."),
    state: Optional[str] = typer.Option(None, "--state", help="Filter by fact state."),
    include_public: bool = typer.Option(False, "--include-public", help="Include public facts."),
    limit: int = typer.Option(100, "--limit", min=1, help="Maximum rows to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Pagination offset."),
) -> None:
    """List facts through the governed agent runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.list_facts(
            entity=entity,
            state=state,
            include_public=include_public,
            limit=limit,
            offset=offset,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("items") or result.get("facts") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_fact_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} fact(s)")
    print_table(
        [
            {
                "fact_id": _fact_id(item),
                "state": _format_value(item.get("state")),
                "trust_score": _format_value(item.get("trust_score")),
                "density_index": _format_value(item.get("density_index")),
                "compression_index": _format_value(item.get("compression_index")),
                "created_at": _format_value(item.get("created_at")),
            }
            for item in items
        ],
        ["fact_id", "state", "trust_score", "density_index", "compression_index", "created_at"],
    )


@agent_facts_app.command("get")
def facts_get(
    ctx: typer.Context,
    fact_id: str = typer.Argument(..., help="Fact ID."),
) -> None:
    """Fetch one fact with scoring details."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.get_fact(fact_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _fact_id(result) or fact_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Fact {resolved_id}")
    print_kv(
        {
            "State": result.get("state", "?"),
            "Trust": _format_value(result.get("trust_score")),
            "Density": _format_value(result.get("density_index")),
            "Compression": _format_value(result.get("compression_index")),
            "Receipt": result.get("latest_receipt_hash") or result.get("receipt_hash") or "(pending)",
            "Created": result.get("created_at", ""),
        },
        highlights={"State", "Receipt"},
    )


@agent_facts_app.command("create")
def facts_create(
    ctx: typer.Context,
    text: str = typer.Argument(..., help="Fact text."),
    entities: Optional[str] = typer.Option(None, "--entities", help="Comma-separated entities."),
    claims: Optional[str] = typer.Option(None, "--claims", help="Comma-separated claims."),
    citations: Optional[str] = typer.Option(None, "--citations", help="Comma-separated citations."),
    public: bool = typer.Option(False, "--public", help="Mark fact as public."),
) -> None:
    """Create a fact through the agent runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    entities_list = [item.strip() for item in entities.split(",") if item.strip()] if entities else None
    claims_list = [item.strip() for item in claims.split(",") if item.strip()] if claims else None
    citations_list = [item.strip() for item in citations.split(",") if item.strip()] if citations else None
    try:
        result = client.reality.create_fact(
            text,
            entities=entities_list,
            claims=claims_list,
            citations=citations_list,
            is_public=public,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _fact_id(result)
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Created fact {resolved_id or '(unknown id)'}")
    print_kv(
        {
            "State": result.get("state", ""),
            "Trust": _format_value(result.get("trust_score")),
            "Receipt": result.get("receipt_hash") or result.get("latest_receipt_hash") or "(pending)",
        },
        highlights={"State", "Receipt"},
    )


@agent_facts_app.command("search")
def facts_search(
    ctx: typer.Context,
    entity: Optional[str] = typer.Option(None, "--entity", help="Filter by entity."),
    state: Optional[str] = typer.Option(None, "--state", help="Filter by fact state."),
) -> None:
    """Search facts quickly through the governed twin runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.search_facts(entity=entity, state=state)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"items": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_fact_id(item) for item in result))), nl=False)
        return

    print_success(f"Matched {len(result)} fact(s)")
    print_table(
        [
            {
                "fact_id": _fact_id(item),
                "state": _format_value(item.get("state")),
                "trust_score": _format_value(item.get("trust_score")),
                "density_index": _format_value(item.get("density_index")),
                "compression_index": _format_value(item.get("compression_index")),
                "created_at": _format_value(item.get("created_at")),
            }
            for item in result
        ],
        ["fact_id", "state", "trust_score", "density_index", "compression_index", "created_at"],
    )


@agent_facts_app.command("recompute")
def facts_recompute(
    ctx: typer.Context,
    fact_id: str = typer.Argument(..., help="Fact ID."),
) -> None:
    """Recompute scoring for one fact."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.recompute(fact_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _fact_id(result) or fact_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Recomputed {resolved_id}")
    print_kv(
        {
            "State": result.get("state", "?"),
            "Trust": _format_value(result.get("trust_score")),
            "Density": _format_value(result.get("density_index")),
            "Compression": _format_value(result.get("compression_index")),
            "Receipt": result.get("receipt_hash") or result.get("latest_receipt_hash") or "(pending)",
        },
        highlights={"State", "Receipt"},
    )


@agent_evidence_app.command("ingest")
def evidence_ingest(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to evidence JSON, or - to read from stdin."),
) -> None:
    """Ingest evidence items that support or contradict facts."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = _read_json_source(source)
        if isinstance(payload, dict) and isinstance(payload.get("items"), list):
            items = payload["items"]
        elif isinstance(payload, list):
            items = payload
        elif isinstance(payload, dict):
            items = [payload]
        else:
            raise ValueError("Evidence payload must be a JSON object, an array, or an object with an 'items' list.")
        if not all(isinstance(item, dict) for item in items):
            raise ValueError("Each evidence item must be a JSON object.")
        result = client.reality.ingest_evidence(items)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    evidence_items = result.get("evidence") or result.get("items") or items
    links_created = result.get("links_created")
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(len(evidence_items))
        return

    print_success(f"Ingested {len(evidence_items)} evidence item(s)")
    print_kv(
        {
            "Evidence": len(evidence_items),
            "Links Created": links_created if links_created is not None else "",
        },
        highlights={"Evidence"},
    )


@agent_ingestions_app.command("list")
def ingestions_list(
    ctx: typer.Context,
    status: Optional[str] = typer.Option(None, "--status", help="Filter by ingestion status."),
    limit: int = typer.Option(50, "--limit", min=1, help="Maximum rows to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Pagination offset."),
) -> None:
    """List ingestions through the agent runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.list_ingestions(status=status, limit=limit, offset=offset)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("items") or result.get("ingestions") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_ingestion_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} ingestion(s)")
    print_table(
        [
            {
                "ingestion_id": _ingestion_id(item),
                "status": _format_value(item.get("status")),
                "source_type": _format_value(item.get("source_type")),
                "source_title": _format_value(item.get("source_title") or item.get("source_uri")),
                "created_at": _format_value(item.get("created_at")),
            }
            for item in items
        ],
        ["ingestion_id", "status", "source_type", "source_title", "created_at"],
    )


@agent_ingestions_app.command("get")
def ingestions_get(
    ctx: typer.Context,
    ingestion_id: str = typer.Argument(..., help="Ingestion ID."),
) -> None:
    """Fetch one ingestion envelope."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.get_ingestion(ingestion_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _ingestion_id(result) or ingestion_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Ingestion {resolved_id}")
    print_kv(
        {
            "Status": result.get("status", "?"),
            "Source Type": result.get("source_type", ""),
            "Source Title": result.get("source_title") or result.get("source_uri") or "",
            "Created": result.get("created_at", ""),
            "Chunks": len(result.get("chunks") or []),
            "Facts": len(result.get("facts") or []),
            "Evidence": len(result.get("evidence") or []),
        },
        highlights={"Status"},
    )


@agent_ingestions_app.command("text")
def ingestions_text(
    ctx: typer.Context,
    content: Optional[str] = typer.Option(None, "--content", help="Raw text or markdown content."),
    file: Optional[Path] = typer.Option(None, "--file", exists=True, dir_okay=False, readable=True, help="Read content from a file."),
    source_uri: Optional[str] = typer.Option(None, "--source-uri", help="Source URI."),
    source_type: str = typer.Option("text", "--source-type", help="Source type, e.g. text or markdown."),
    source_title: Optional[str] = typer.Option(None, "--source-title", help="Source title."),
    submitted_by: Optional[str] = typer.Option(None, "--submitted-by", help="Submitter label."),
    submission_channel: str = typer.Option("agent_cli", "--channel", help="Submission channel label."),
    gec_domain: Optional[str] = typer.Option(None, "--gec-domain", help="Optional GEC domain."),
) -> None:
    """Submit raw text or markdown into Reality ingestion."""
    if not content and not file:
        print_error("Provide --content or --file.")
        raise typer.Exit(1)

    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        body = content
        if file is not None:
            body = file.read_text(encoding="utf-8")
        result = client.reality.ingest_content(
            body or "",
            source_uri=source_uri,
            source_type=source_type,
            source_title=source_title,
            submitted_by=submitted_by,
            submission_channel=submission_channel,
            gec_domain=gec_domain,
        )
    except (OSError, UnicodeDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    ingestion_id = _ingestion_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(ingestion_id)
        return

    print_success(f"Ingested content as {ingestion_id or '(unknown id)'}")
    print_kv(
        {
            "Status": result.get("status", "?"),
            "Source Type": result.get("source_type", source_type),
            "Facts": len(result.get("facts") or []),
            "Evidence": len(result.get("evidence") or []),
        },
        highlights={"Status"},
    )


@agent_ingestions_app.command("upload")
def ingestions_upload(
    ctx: typer.Context,
    path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Path to txt/md/docx/pdf file."),
    source_type: Optional[str] = typer.Option(None, "--source-type", help="Override detected source type."),
    source_title: Optional[str] = typer.Option(None, "--source-title", help="Source title."),
    submitted_by: Optional[str] = typer.Option(None, "--submitted-by", help="Submitter label."),
    submission_channel: str = typer.Option("agent_cli_upload", "--channel", help="Submission channel label."),
    gec_domain: Optional[str] = typer.Option(None, "--gec-domain", help="Optional GEC domain."),
) -> None:
    """Upload a source file and file it through Reality ingestion."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.upload_source(
            path,
            source_type=source_type,
            source_title=source_title,
            submitted_by=submitted_by,
            submission_channel=submission_channel,
            gec_domain=gec_domain,
        )
    except (OSError, SbnError, SbnTransportError) as exc:
        _die(exc)

    ingestion_id = _ingestion_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(ingestion_id)
        return

    print_success(f"Uploaded {path.name} as {ingestion_id or '(unknown id)'}")
    print_kv(
        {
            "Status": result.get("status", "?"),
            "Source Type": result.get("source_type") or source_type or path.suffix.lstrip("."),
            "Facts": len(result.get("facts") or []),
            "Evidence": len(result.get("evidence") or []),
        },
        highlights={"Status"},
    )


@agent_reality_lattice_app.command("get")
def reality_lattice_get(ctx: typer.Context) -> None:
    """Fetch the current reality lattice graph for the project."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.reality.get_lattice()
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    nodes = result.get("nodes") or []
    edges = result.get("edges") or []
    edge_kinds: dict[str, int] = {}
    for edge in edges:
        kind = str(edge.get("kind") or edge.get("edge_type") or "unknown")
        edge_kinds[kind] = edge_kinds.get(kind, 0) + 1

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(f"{len(nodes)}:{len(edges)}")
        return

    print_success("Reality lattice graph")
    print_kv(
        {
            "Nodes": len(nodes),
            "Edges": len(edges),
            "Supports": edge_kinds.get("supports", 0),
            "Contradicts": edge_kinds.get("contradicts", 0),
            "Same-as": edge_kinds.get("same_as", 0) or edge_kinds.get("same-as", 0),
        },
        highlights={"Nodes", "Edges"},
    )


@slots_app.command("open")
def slots_open(
    ctx: typer.Context,
    worker_id: str = typer.Option(..., "--worker-id", help="Worker or twin identifier."),
    task_type: str = typer.Option(..., "--task-type", help="Task or workflow type."),
    generation_interval: Optional[int] = typer.Option(None, "--generation-interval", help="Generation window in seconds."),
    metadata_json: Optional[str] = typer.Option(None, "--metadata-json", help="Path to metadata JSON, or - for stdin."),
) -> None:
    """Open a new computation slot."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        metadata = _optional_json(metadata_json)
        slot = client.gateway.create_slot(
            worker_id,
            task_type,
            generation_interval=generation_interval,
            metadata=metadata,
        )
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(
            {
                "id": slot.id,
                "worker_id": slot.worker_id,
                "task_type": slot.task_type,
                "state": slot.state,
                "opened_at": slot.opened_at.isoformat() if slot.opened_at else None,
                "receipt_id": slot.receipt_id,
                "metadata": dict(slot.metadata or {}),
            }
        )
        return
    if fmt == "quiet":
        print_quiet(slot.id)
        return

    _print_slot(slot, prefix="Opened slot")


@slots_app.command("blocks")
def slots_blocks(
    ctx: typer.Context,
    slot_id: str = typer.Argument(..., help="Slot ID."),
    limit: Optional[int] = typer.Option(None, "--limit", min=1, help="Maximum blocks to return."),
) -> None:
    """List SmartBlocks currently attached to a slot."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.gateway.list_slot_blocks(slot_id, limit=limit)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("blocks") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("id") or item.get("block_id") or "") for item in items if item), nl=False)
        return

    print_success(f"Fetched {len(items)} block(s) for slot {slot_id}")
    print_kv({"Slot State": result.get("slot_state") or ""}, highlights={"Slot State"})
    print_table(_slot_rows(items), ["block_id", "domain", "type", "hash", "created_at"])


@slots_app.command("close")
def slots_close(
    ctx: typer.Context,
    slot_id: str = typer.Argument(..., help="Slot ID."),
) -> None:
    """Close a slot and return composition / attestation summary."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        closure = client.gateway.close_slot(slot_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(
            {
                "slot_id": closure.slot_id,
                "receipt_id": closure.receipt_id,
                "closed_at": closure.closed_at.isoformat() if closure.closed_at else None,
                "blocks_composed": closure.blocks_composed,
                "blocks_attested": closure.blocks_attested,
                "compose_receipts": closure.compose_receipts,
            }
        )
        return
    if fmt == "quiet":
        print_quiet(closure.receipt_id)
        return

    _print_closure(closure)


@agent_app.command("attest")
@twin_app.command("attest")
def attest(
    ctx: typer.Context,
    slot_id: str = typer.Argument(..., help="Slot ID."),
    snap_hash: str = typer.Argument(..., help="SnapChore hash to attest."),
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Optional frontier ID."),
    metadata_json: Optional[str] = typer.Option(None, "--metadata-json", help="Path to metadata JSON, or - for stdin."),
    metrics_json: Optional[str] = typer.Option(None, "--metrics-json", help="Path to metrics JSON, or - for stdin."),
) -> None:
    """Request attestation for a SnapChore artifact under a slot."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        summary = SlotSummary(
            slot_id=slot_id,
            snap_hash=snap_hash,
            frontier_id=frontier,
            metadata=_optional_json(metadata_json) or {},
            metrics=_optional_json(metrics_json) or {},
        )
        result = client.gateway.request_attestation(summary)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    receipt_id = str(result.get("receipt_id") or result.get("id") or "")
    if fmt == "quiet":
        print_quiet(receipt_id)
        return

    print_success(f"Requested attestation for slot {slot_id}")
    print_kv(
        {
            "Receipt": receipt_id,
            "Frontier": frontier or (result.get("frontier_id") or ""),
            "Status": result.get("status") or "",
        },
        highlights={"Receipt", "Status"},
    )


@agent_app.command("receipt")
@twin_app.command("receipt")
def receipt_get(
    ctx: typer.Context,
    receipt_id: str = typer.Argument(..., help="Receipt ID."),
) -> None:
    """Fetch an attestation receipt through the minimal agent surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        receipt = client.gateway.fetch_receipt(receipt_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(
            {
                "id": receipt.id,
                "tenant_id": receipt.tenant_id,
                "subject_id": receipt.subject_id,
                "subject_type": receipt.subject_type,
                "signer_id": receipt.signer_id,
                "created_at": receipt.created_at.isoformat() if receipt.created_at else None,
                "payload": dict(receipt.payload or {}),
                "metadata": dict(receipt.metadata or {}),
                "snapchore_hash": receipt.snapchore_hash,
            }
        )
        return
    if fmt == "quiet":
        print_quiet(receipt.id)
        return

    _print_receipt(receipt)


@snap_app.command("capture")
def snap_capture(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to payload JSON, or - to read from stdin."),
) -> None:
    """Capture a payload into the SnapChore ledger."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = _read_json_source(source)
        if not isinstance(payload, dict):
            raise ValueError("Snap payload must be a JSON object.")
        result = client.snapchore.capture(payload)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    snap_hash = str(result.get("hash") or result.get("snapchore_hash") or "")
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(snap_hash)
        return

    print_success("Captured payload")
    print_kv(
        {
            "Hash": snap_hash,
            "Canon Version": result.get("canon_version") or "",
        },
        highlights={"Hash"},
    )


@snap_app.command("verify")
def snap_verify(
    ctx: typer.Context,
    expected_hash: str = typer.Argument(..., help="Expected SnapChore hash."),
    source: str = typer.Argument(..., help="Path to payload JSON, or - to read from stdin."),
) -> None:
    """Verify a payload against an expected SnapChore hash."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = _read_json_source(source)
        if not isinstance(payload, dict):
            raise ValueError("Snap payload must be a JSON object.")
        result = client.snapchore.verify(expected_hash, payload)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    valid = bool(result.get("valid"))
    if fmt == "quiet":
        print_quiet("true" if valid else "false")
        return

    print_success("Verified payload")
    print_kv(
        {
            "Valid": valid,
            "Expected": expected_hash,
            "Actual": result.get("hash") or result.get("actual_hash") or "",
        },
        highlights={"Valid"},
    )


@snap_app.command("seal")
def snap_seal(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to payload JSON, or - to read from stdin."),
    domain: str = typer.Option("general", "--domain", help="Target domain."),
    block_type: str = typer.Option("event", "--block-type", help="Block type."),
    metadata_json: Optional[str] = typer.Option(None, "--metadata-json", help="Path to metadata JSON, or - for stdin."),
    metrics_json: Optional[str] = typer.Option(None, "--metrics-json", help="Path to metrics JSON, or - for stdin."),
) -> None:
    """Seal a payload into the lattice via SnapChore."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = _read_json_source(source)
        if not isinstance(payload, dict):
            raise ValueError("Snap payload must be a JSON object.")
        result = client.snapchore.seal(
            payload,
            domain=domain,
            block_type=block_type,
            metadata=_optional_json(metadata_json),
            metrics=_optional_json(metrics_json),
        )
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    snap_hash = str(result.get("snapchore_hash") or result.get("hash") or "")
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(snap_hash)
        return

    print_success("Sealed payload")
    print_kv(
        {
            "Hash": snap_hash,
            "Domain": result.get("domain") or domain,
            "Block Type": result.get("block_type") or block_type,
        },
        highlights={"Hash"},
    )


@snap_app.command("discover")
def snap_discover(
    ctx: typer.Context,
    snap_hash: str = typer.Argument(..., help="SnapChore hash."),
) -> None:
    """Discover a hash in the SnapChore ledger."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.snapchore.discover(snap_hash)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    resolved_hash = str(result.get("hash") or result.get("snapchore_hash") or snap_hash)
    if fmt == "quiet":
        print_quiet(resolved_hash)
        return

    print_success(f"Ledger entry {resolved_hash}")
    print_kv(
        {
            "Hash": resolved_hash,
            "Source": result.get("source") or "",
            "Domain": result.get("domain") or "",
            "Created": result.get("created_at") or "",
        },
        highlights={"Hash"},
    )


@agent_workflows_app.command("list")
def workflows_list(
    ctx: typer.Context,
    domain: Optional[str] = typer.Option(None, "--domain", help="Filter by domain."),
    state: Optional[str] = typer.Option(None, "--state", help="Filter by workflow state."),
    scopes: Optional[str] = typer.Option(None, "--scopes", help="Comma-separated scope patterns."),
    limit: int = typer.Option(50, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List workflows through the agent runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    scope_list = [scope.strip() for scope in scopes.split(",") if scope.strip()] if scopes else None
    try:
        result = client.lattice.list_workflows(domain=domain, state=state, scopes=scope_list, limit=limit)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"workflows": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_workflow_id(item) for item in result))), nl=False)
        return

    print_success(f"Fetched {len(result)} workflow(s)")
    print_table(
        [
            {
                "workflow_id": _workflow_id(item),
                "name": str(item.get("name") or ""),
                "domain": str(item.get("domain") or ""),
                "state": str(item.get("state") or ""),
                "topology": str(item.get("topology") or ""),
                "project_id": str(item.get("project_id") or ""),
            }
            for item in result
        ],
        ["workflow_id", "name", "domain", "state", "topology", "project_id"],
    )


@agent_workflows_app.command("get")
def workflows_get(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
) -> None:
    """Fetch one workflow with node and edge detail."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.lattice.get_workflow(workflow_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _workflow_id(result) or workflow_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Workflow {resolved_id}")
    print_kv(
        {
            "Name": result.get("name", ""),
            "Domain": result.get("domain", ""),
            "State": result.get("state", ""),
            "Topology": result.get("topology", ""),
            "Nodes": len(result.get("nodes") or []),
            "Edges": len(result.get("edges") or []),
            "Project": result.get("project_id", ""),
        },
        highlights={"State"},
    )


@agent_workflows_app.command("export")
def workflows_export(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    output: Optional[Path] = typer.Option(None, "--output", "-o", dir_okay=False, help="Write JSON export to a file."),
) -> None:
    """Export a workflow as portable JSON through the twin runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.lattice.export_workflow(workflow_id)
        if output:
            output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    except (OSError, SbnError, SbnTransportError) as exc:
        _die(exc)

    if config.output_format == "quiet" and output is not None:
        print_quiet(str(output))
        return
    if config.output_format == "json" or output is None:
        print_json(result)
        return

    print_success(f"Exported workflow to {output}")


@agent_workflows_app.command("import")
def workflows_import(
    ctx: typer.Context,
    source: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Path to exported workflow JSON."),
    activate: bool = typer.Option(False, "--activate", help="Activate imported workflow after creation."),
) -> None:
    """Import a portable workflow JSON document."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Workflow import payload must be a JSON object.")
        result = client.lattice.import_workflow(payload, activate=activate)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    resolved_id = _workflow_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Imported workflow {resolved_id or '(unknown id)'}")
    print_kv(
        {
            "State": result.get("state") or ("active" if activate else ""),
            "Workflow": resolved_id,
        },
        highlights={"State"},
    )


@agent_workflows_app.command("outcome")
def workflows_outcome(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    step_id: str = typer.Argument(..., help="Step ID."),
    agent_id: Optional[str] = typer.Option(None, "--agent-id", help="Optional agent identifier."),
    outcome: str = typer.Option("completed", "--outcome", help="Outcome label."),
    duration_seconds: Optional[float] = typer.Option(None, "--duration-seconds", help="Execution duration."),
    error_message: Optional[str] = typer.Option(None, "--error-message", help="Optional failure message."),
    proof_hash: Optional[str] = typer.Option(None, "--proof-hash", help="Proof artifact hash for the step."),
    proof_stage: Optional[str] = typer.Option(None, "--proof-stage", help="Proof stage: observed, sealed, published, reduced, interrupted."),
    block_ref: Optional[str] = typer.Option(None, "--block-ref", help="SmartBlock or receipt reference for the step proof."),
    signal_hash: Optional[str] = typer.Option(None, "--signal-hash", help="Governance or interruption signal hash."),
    meta_json: Optional[str] = typer.Option(None, "--meta-json", help="Path to metadata JSON, or - for stdin."),
) -> None:
    """Record a workflow step outcome."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.lattice.record_step_outcome(
            workflow_id,
            step_id,
            agent_id=agent_id,
            outcome=outcome,
            duration_seconds=duration_seconds,
            error_message=error_message,
            proof_hash=proof_hash,
            proof_stage=proof_stage,
            block_ref=block_ref,
            signal_hash=signal_hash,
            meta=_optional_json(meta_json),
        )
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(str(result.get("step_id") or step_id))
        return

    print_success(f"Recorded outcome for {workflow_id}:{step_id}")
    print_kv(
        {
            "Outcome": result.get("outcome") or outcome,
            "Agent": result.get("agent_id") or agent_id or "",
            "Duration": result.get("duration_seconds") if result.get("duration_seconds") is not None else (duration_seconds or ""),
        },
        highlights={"Outcome"},
    )


@agent_workflows_app.command("ready")
def workflows_ready(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    completed: Optional[str] = typer.Option(None, "--completed", help="Comma-separated completed step IDs."),
) -> None:
    """Get steps ready to execute for a workflow."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    completed_steps = [item.strip() for item in completed.split(",") if item.strip()] if completed else None
    try:
        result = client.lattice.get_ready_steps(workflow_id, completed=completed_steps)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"ready_steps": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("id") or item.get("step_id") or "") for item in result), nl=False)
        return

    rows = [
        {
            "step_id": str(item.get("step_id") or item.get("id") or ""),
            "name": str(item.get("name") or ""),
            "skill": str(item.get("skill") or ""),
            "dept": str(item.get("dept") or ""),
        }
        for item in result
    ]
    print_success(f"Ready steps: {len(rows)}")
    print_table(rows, ["step_id", "name", "skill", "dept"])


@agent_workflows_app.command("complete")
def workflows_complete(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
) -> None:
    """Mark a workflow complete."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.lattice.mark_workflow_complete(workflow_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _workflow_id(result) or workflow_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Completed workflow {resolved_id}")
    print_kv(
        {
            "State": result.get("state") or "completed",
            "Workflow": resolved_id,
        },
        highlights={"State"},
    )


@agent_edges_app.command("list")
def edges_list(
    ctx: typer.Context,
    source_id: Optional[str] = typer.Option(None, "--source-id", help="Filter by source node ID."),
    target_id: Optional[str] = typer.Option(None, "--target-id", help="Filter by target node ID."),
    edge_type: Optional[str] = typer.Option(None, "--edge-type", help="Filter by edge type."),
    limit: int = typer.Option(100, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List cross-workflow lattice edges visible to the twin runtime."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.lattice.list_edges(
            source_id=source_id,
            target_id=target_id,
            edge_type=edge_type,
            limit=limit,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"edges": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_edge_id(item) for item in result))), nl=False)
        return

    print_success(f"Fetched {len(result)} edge(s)")
    print_table(
        [
            {
                "edge_id": _edge_id(item),
                "source_id": str(item.get("source_id") or ""),
                "target_id": str(item.get("target_id") or ""),
                "edge_type": str(item.get("edge_type") or item.get("kind") or ""),
                "weight": _format_value(item.get("weight")),
            }
            for item in result
        ],
        ["edge_id", "source_id", "target_id", "edge_type", "weight"],
    )


@agent_edges_app.command("create")
def edges_create(
    ctx: typer.Context,
    source_id: str = typer.Argument(..., help="Source node ID."),
    target_id: str = typer.Argument(..., help="Target node ID."),
    edge_type: str = typer.Argument(..., help="Edge type."),
    weight: float = typer.Option(1.0, "--weight", help="Edge weight."),
    meta_json: Optional[str] = typer.Option(None, "--meta-json", help="Path to metadata JSON, or - for stdin."),
) -> None:
    """Create a cross-workflow lattice edge."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.lattice.create_edge(
            source_id=source_id,
            target_id=target_id,
            edge_type=edge_type,
            weight=weight,
            meta=_optional_json(meta_json),
        )
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _edge_id(result)
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Created edge {resolved_id or '(unknown id)'}")
    print_kv(
        {
            "Type": result.get("edge_type") or edge_type,
            "Source": result.get("source_id") or source_id,
            "Target": result.get("target_id") or target_id,
            "Weight": _format_value(result.get("weight") if result.get("weight") is not None else weight),
        },
        highlights={"Type"},
    )


@agent_numa_app.command("hints")
def hints_get(
    ctx: typer.Context,
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
) -> None:
    """Fetch distilled NUMA hints."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.numa.get_hints(frontier_id=frontier)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("hints") or result.get("items") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("hint_id") or item.get("id") or "") for item in items if item), nl=False)
        return

    print_success(f"Fetched {len(items)} hint(s)")
    print_table(
        [
            {
                "hint_id": str(item.get("hint_id") or item.get("id") or ""),
                "frontier_id": str(item.get("frontier_id") or ""),
                "kind": str(item.get("kind") or item.get("hint_type") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
            for item in items
        ],
        ["hint_id", "frontier_id", "kind", "created_at"],
    )


@agent_forecasts_app.command("list")
def forecasts_list(ctx: typer.Context) -> None:
    """List latest forecasts per frontier."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.numa.list_forecasts()
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("items") or result.get("forecasts") or result.get("reports") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("frontier_id") or item.get("id") or "") for item in items if item), nl=False)
        return

    print_success(f"Fetched {len(items)} forecast(s)")
    print_table(
        [
            {
                "frontier_id": str(item.get("frontier_id") or item.get("id") or ""),
                "generated_at": str(item.get("generated_at") or item.get("created_at") or ""),
                "status": str(item.get("status") or ""),
                "risk_band": str(item.get("risk_band") or item.get("report", {}).get("risk_band") or ""),
            }
            for item in items
        ],
        ["frontier_id", "generated_at", "status", "risk_band"],
    )


@agent_signals_app.command("list")
def signals_list(
    ctx: typer.Context,
    signal_type: Optional[str] = typer.Option(None, "--signal-type", help="Filter by signal type."),
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
    lane: Optional[str] = typer.Option(None, "--lane", help="Filter by poll lane."),
    since: Optional[str] = typer.Option(None, "--since", help="Only signals after this ISO-8601 timestamp."),
    active_only: bool = typer.Option(True, "--active-only/--all", help="Hide expired signals by default."),
    limit: int = typer.Option(100, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List cached NUMA signals."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.numa.get_signals(
            signal_type=signal_type,
            frontier_id=frontier,
            active_only=active_only,
            since=since,
            lane=lane,
            limit=limit,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("signals") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (str(item.get("signal_id") or item.get("id") or "") for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} signal(s)")
    print_table(
        [
            {
                "signal_id": str(item.get("signal_id") or item.get("id") or ""),
                "signal_type": str(item.get("signal_type") or ""),
                "frontier_id": str(item.get("frontier_id") or ""),
                "priority": str(item.get("priority") or ""),
                "lane": str(item.get("lane") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
            for item in items
        ],
        ["signal_id", "signal_type", "frontier_id", "priority", "lane", "created_at"],
    )


@agent_signals_app.command("ack")
def signals_ack(
    ctx: typer.Context,
    signal_ids: list[str] = typer.Argument(..., help="One or more signal IDs."),
    agent_id: Optional[str] = typer.Option(None, "--agent-id", help="Optional agent identifier for audit."),
) -> None:
    """Acknowledge one or more signals."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.numa.ack_signals(signal_ids, agent_id=agent_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    acknowledged = int(result.get("acknowledged") or len(signal_ids))
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(acknowledged)
        return

    print_success(f"Acknowledged {acknowledged} signal(s)")
    print_kv(
        {
            "Acknowledged": acknowledged,
            "Agent": agent_id or "",
        },
        highlights={"Acknowledged"},
    )


@agent_signals_app.command("publish")
def signals_publish(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to signal JSON, or - to read from stdin."),
) -> None:
    """Publish one or more signals from JSON."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = _read_json_source(source)
        if isinstance(payload, dict):
            signals = [payload]
        elif isinstance(payload, list):
            signals = payload
        else:
            raise ValueError("Signal payload must be a JSON object or array.")
        result = client.numa.publish_signals(signals)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    published = int(result.get("published") or len(signals))
    if fmt == "quiet":
        print_quiet(published)
        return

    print_success(f"Published {published} signal(s)")
    print_kv(
        {
            "Published": published,
            "Distilled": result.get("distilled") or "",
        },
        highlights={"Published"},
    )


@agent_receipts_app.command("list")
def receipts_list(
    ctx: typer.Context,
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Filter by project ID."),
    hash: Optional[str] = typer.Option(None, "--hash", help="Exact receipt hash."),
    domain: Optional[str] = typer.Option(None, "--domain", help="Filter by domain/frontier."),
    since: Optional[str] = typer.Option(None, "--since", help="ISO-8601 cursor."),
    limit: int = typer.Option(20, "--limit", min=1, help="Maximum rows to return."),
    offset: int = typer.Option(0, "--offset", min=0, help="Pagination offset."),
) -> None:
    """List receipts through the agent runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.receipts.list(
            project_id=project_id,
            hash=hash,
            domain=domain,
            limit=limit,
            offset=offset,
            since=since,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("receipts") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (str(item.get("receipt_id") or item.get("id") or item.get("hash") or "") for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} receipt(s)")
    print_table(
        [
            {
                "receipt_id": str(item.get("receipt_id") or item.get("id") or item.get("hash") or ""),
                "domain": str(item.get("domain") or item.get("frontier_id") or ""),
                "project_id": str(item.get("project_id") or ""),
                "status": str(item.get("status") or item.get("verification_status") or ""),
                "created_at": str(item.get("created_at") or ""),
            }
            for item in items
        ],
        ["receipt_id", "domain", "project_id", "status", "created_at"],
    )


@agent_receipts_app.command("get")
def receipts_get(
    ctx: typer.Context,
    receipt_id: str = typer.Argument(..., help="Receipt ID or hash."),
) -> None:
    """Fetch a single receipt through the agent runtime surface."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.receipts.get(receipt_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = str(result.get("receipt_id") or result.get("id") or result.get("hash") or receipt_id)
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Receipt {resolved_id}")
    print_kv(
        {
            "Status": result.get("status") or result.get("verification_status") or "",
            "Domain": result.get("domain") or result.get("frontier_id") or "",
            "Project": result.get("project_id") or "",
            "Created": result.get("created_at") or "",
            "Hash": result.get("hash") or result.get("receipt_hash") or resolved_id,
        },
        highlights={"Status", "Hash"},
    )


@agent_proposals_app.command("list")
def proposals_list(
    ctx: typer.Context,
    status: Optional[str] = typer.Option(None, "--status", help="Filter by proposal status."),
    frontier: Optional[str] = typer.Option(None, "--frontier", help="Filter by frontier ID."),
) -> None:
    """List governance proposals visible to the agent runtime."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.governance.list_proposals(status=status, frontier=frontier)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    items = result.get("proposals") or []
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_proposal_id(item) for item in items))), nl=False)
        return

    print_success(f"Fetched {len(items)} proposal(s)")
    print_table(
        [
            {
                "id": _proposal_id(item),
                "status": str(item.get("status") or ""),
                "frontier": str((item.get("document") or {}).get("frontier_id") or item.get("frontier_id") or ""),
                "submitter": str((item.get("document") or {}).get("submitter") or item.get("submitter") or ""),
                "risk_band": str((item.get("document") or {}).get("risk_band") or item.get("risk_band") or ""),
                "checksum": str(item.get("checksum") or ""),
            }
            for item in items
        ],
        ["id", "status", "frontier", "submitter", "risk_band", "checksum"],
    )


@agent_proposals_app.command("get")
def proposals_get(
    ctx: typer.Context,
    proposal_id: str = typer.Argument(..., help="Proposal ID."),
) -> None:
    """Fetch one proposal with approval details."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        result = client.governance.get_proposal(proposal_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _proposal_id(result) or proposal_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    document = result.get("document") or {}
    print_success(f"Proposal {resolved_id}")
    print_kv(
        {
            "Status": result.get("status", ""),
            "Frontier": document.get("frontier_id") or result.get("frontier_id") or "",
            "Submitter": document.get("submitter") or result.get("submitter") or "",
            "Risk Band": document.get("risk_band") or result.get("risk_band") or "",
            "Checksum": result.get("checksum") or "",
            "Approvals": f"{result.get('approvals_received', '?')}/{result.get('approvals_required', '?')}",
        },
        highlights={"Status", "Checksum"},
    )


@agent_proposals_app.command("create")
def proposals_create(
    ctx: typer.Context,
    source: str = typer.Argument(..., help="Path to proposal JSON, or - to read from stdin."),
) -> None:
    """Submit a governance proposal from JSON."""
    config = load_config(ctx.obj)
    client = get_agent_client(config)
    try:
        payload = _read_json_source(source)
        if not isinstance(payload, dict):
            raise ValueError("Proposal payload must be a JSON object.")
        result = client.governance.create_proposal(payload)
    except (OSError, ValueError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    proposal_id = _proposal_id(result)
    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(proposal_id)
        return

    print_success(f"Created proposal {proposal_id or '(unknown id)'}")
    print_kv(
        {
            "Status": result.get("status", ""),
            "Checksum": result.get("checksum", ""),
        },
        highlights={"Status", "Checksum"},
    )
