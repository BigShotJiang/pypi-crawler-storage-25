"""Agent SDK - governed client for autonomous agents and digital twins on SBN.

The AgentClient exposes a narrower operational surface than ``SbnClient`` while
still giving agents and twins the artifact and workflow access they actually
need in practice.

Primary namespaces:

* ``gateway``    - slots, attestations, and receipt fetches
* ``snapchore``  - capture, verify, seal, and chain discovery
* ``reality``    - facts, evidence, ingestions, and lattice graph
* ``lattice``    - workflow DAGs and graph operations
* ``governance`` - proposal lifecycle participation
* ``numa``       - hints, forecasts, diagnostics, and signal relay
* ``receipts``   - receipt lookup and discovery

For the full platform surface (console management, control plane, ACP, Atlas,
GEC, and the rest of the operator/application APIs), use :class:`SbnClient`.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import httpx
from sbn._http import AuthState, HttpTransport, RetryConfig
from sbn.auth import MintedToken, SigningKey
from sbn.bitblocks import BitBlocksClient
from sbn.gateway import GatewayClient
from sbn.governance import GovernanceClient
from sbn.lattice import LatticeClient
from sbn.numa import NUMAClient
from sbn.reality import RealityClient
from sbn.receipts import ReceiptsClient
from sbn.snapchore import SnapChoreClient
from sbn.streaming import SlotSession


class AgentClient:
    """Governed runtime client for autonomous agents and digital twins.

    This client keeps the operator and infrastructure-heavy surfaces out of the
    default agent boundary, while exposing the core runtime capabilities twins
    and agents need to perceive, act, and produce receipts.
    """

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8090",
        tenant_id: str | None = None,
        retry: RetryConfig | None = None,
        timeout: float = 10.0,
        user_agent: str = "sbn-agent/0.4",
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._auth = AuthState(tenant_id=tenant_id)
        self._transport = HttpTransport(
            base_url=base_url,
            auth=self._auth,
            retry=retry,
            timeout=timeout,
            user_agent=user_agent,
            transport=transport,
        )
        self._gateway = GatewayClient(self._transport)
        self._snapchore = SnapChoreClient(self._transport)
        self._reality = RealityClient(self._transport)
        self._lattice = LatticeClient(self._transport)
        self._governance = GovernanceClient(self._transport)
        self._numa = NUMAClient(self._transport)
        self._receipts = ReceiptsClient(self._transport)
        self._bitblocks = BitBlocksClient(self._transport)

    def authenticate_api_key(self, api_key: str) -> None:
        """Set API key auth for all subsequent requests."""
        self._auth.api_key = api_key
        self._auth.bearer_token = None
        self._auth.token_provider = None

    def authenticate_bearer(self, token: str) -> None:
        """Set a static bearer token for all subsequent requests."""
        self._auth.bearer_token = token
        self._auth.api_key = None
        self._auth.token_provider = None

    def authenticate_signing_key(
        self,
        signing_key: SigningKey,
        *,
        subject: str = "sbn-agent",
        scopes: Sequence[str] = ("attest.write",),
        cdna: str = "agent",
        ttl_seconds: int = 300,
    ) -> None:
        """Use an Ed25519 signing key with auto-refreshing JWT tokens."""
        self._auth.api_key = None
        self._auth.bearer_token = None

        cache: dict[str, MintedToken] = {}

        def _provider() -> str:
            cached = cache.get("t")
            if cached and not cached.expired:
                return cached.token
            fresh = signing_key.issue_token(
                subject=subject,
                scopes=scopes,
                cdna=cdna,
                ttl_seconds=ttl_seconds,
                tenant_id=self._auth.tenant_id,
            )
            cache["t"] = fresh
            return fresh.token

        self._auth.token_provider = _provider

    def set_tenant(self, tenant_id: str | None) -> None:
        """Switch tenant context for multi-tenant operations."""
        self._auth.tenant_id = tenant_id

    @property
    def gateway(self) -> GatewayClient:
        """Slot lifecycle, receipts, and attestations."""
        return self._gateway

    @property
    def snapchore(self) -> SnapChoreClient:
        """Capture, verify, seal, and chain management."""
        return self._snapchore

    @property
    def reality(self) -> RealityClient:
        """Facts, evidence, ingestions, and Reality lattice access."""
        return self._reality

    @property
    def lattice(self) -> LatticeClient:
        """Workflow DAGs, graph edges, and coordination structures."""
        return self._lattice

    @property
    def governance(self) -> GovernanceClient:
        """Proposal lifecycle operations for governed mutations."""
        return self._governance

    @property
    def numa(self) -> NUMAClient:
        """NUMA hints, forecasts, diagnostics, and signal relay."""
        return self._numa

    @property
    def receipts(self) -> ReceiptsClient:
        """Receipt lookup and discovery."""
        return self._receipts

    def open_slot(
        self,
        *,
        worker_id: str,
        task_type: str,
        domain: str,
        generation_interval: int = 60,
        metadata: Mapping[str, Any] | None = None,
    ) -> SlotSession:
        """Open a streaming slot and return a ``SlotSession``.

        This mirrors the convenience available on :class:`SbnClient`, while
        staying inside the governed agent runtime boundary.
        """
        return SlotSession(
            gateway=self._gateway,
            bitblocks_client=self._bitblocks,
            worker_id=worker_id,
            task_type=task_type,
            domain=domain,
            generation_interval=generation_interval,
            metadata=metadata,
        )

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> AgentClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
