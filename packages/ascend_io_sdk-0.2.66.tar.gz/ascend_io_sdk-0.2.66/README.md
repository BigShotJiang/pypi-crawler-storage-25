# Ascend SDK

This folder contains the customer-buildable `ascend-io-sdk` Python package.
The SDK package now builds with `uv` and no longer requires Bazel, Ascend-owned GCP credentials, or the Ascend remote Bazel cache for packaging.

## Package

- Distribution name: `ascend-io-sdk`
- Import package: `ascend.sdk`
- Build tool: `uv`
- Package source: `source/ascend/sdk/src`

The `src/` tree contains the SDK Python sources plus the generated protobuf, OpenAPI, and `protoc_gen_swagger` Python artifacts that were historically produced by Bazel during packaging. These generated artifacts are checked in so customers can build the SDK package cleanly in their own environment.

## Build

From this folder:

```bash
cd source/ascend/sdk
uv build
```

This creates source and wheel distributions in `source/ascend/sdk/dist/`:

```text
source/ascend/sdk/dist/ascend_io_sdk-<version>-py3-none-any.whl
source/ascend/sdk/dist/ascend_io_sdk-<version>.tar.gz
```

## Local Install From Wheels

```bash
cd source/ascend/sdk
uv build

uv venv /tmp/ascend-sdk-venv
source /tmp/ascend-sdk-venv/bin/activate
uv pip install dist/ascend_io_sdk-*.whl

python - <<'PY'
from ascend.sdk.client import Client
print(Client)
PY
```

If your shell has `PYTHONPATH` pointing at another Ascend source checkout, unset it before testing an installed wheel:

```bash
unset PYTHONPATH
```

## Run Directly With UV

You can run the SDK directly from this folder without manually creating or activating a virtual environment:

```bash
cd source/ascend/sdk
uv run python
```

If your shell exports `PYTHONPATH` for another Ascend checkout, remove it for the command so Python imports this package instead of the other checkout:

```bash
cd source/ascend/sdk
env -u PYTHONPATH uv run python
```

Quick import check:

```bash
cd source/ascend/sdk
env -u PYTHONPATH uv run python - <<'PY'
from ascend.sdk.client import Client
print(Client)
PY
```

## Test Locally With UV

Use `uv run` for quick source-tree checks without manually creating a virtual environment:

```bash
cd source/ascend/sdk
env -u PYTHONPATH uv run python - <<'PY'
from ascend.sdk.client import Client
from ascend.sdk import definitions
from ascend.protos.api import api_pb2

print(Client.__name__)
print(definitions.DataService.__name__)
print(api_pb2.__name__)
PY
```

To test the built wheel instead of the editable source tree:

```bash
cd source/ascend/sdk
env -u PYTHONPATH uv build

SDK_WHEEL="$(ls dist/ascend_io_sdk-*-py3-none-any.whl)"

env -u PYTHONPATH uv run \
  --no-project \
  --with "$SDK_WHEEL" \
  python - <<'PY'
from ascend.sdk.client import Client
print(Client)
PY
```

If you want to test against an Ascend environment, make sure your Ascend API credentials are configured and pass the hostname to the client:

```bash
cd source/ascend/sdk
env -u PYTHONPATH uv run python - <<'PY'
from ascend.sdk.client import Client

client = Client(hostname="your-instance.ascend.io")
for data_service in client.list_data_services().data:
  print(data_service.id)
PY
```

## Publish to a Private PyPI Repository

Customers can publish this package to their own private package repository and install it from there.

```bash
cd source/ascend/sdk
uv build

export UV_PUBLISH_URL="https://pypi.customer.example/legacy/"
export UV_PUBLISH_USERNAME="__token__"
export UV_PUBLISH_PASSWORD="<private-pypi-token>"

uv publish dist/*
```

Install from the private index with:

```bash
uv venv /tmp/ascend-sdk-venv
source /tmp/ascend-sdk-venv/bin/activate
uv pip install --index-url https://pypi.customer.example/simple/ ascend-io-sdk
```

If the private index does not mirror public PyPI, add a second index or publish the SDK's third-party dependencies into the private repository.

## Updating Generated Artifacts

The package intentionally avoids Bazel for customer builds. If protobuf or OpenAPI definitions change, regenerate the Python artifacts using the historical internal Bazel pipeline, then refresh `source/ascend/sdk/src` with the generated package contents before publishing a new SDK wheel.

For the current handoff, `source/ascend/sdk/src` is the buildable source of truth for the SDK package.

## Integration Tests

The existing integration tests under `source/ascend/sdk/test` are retained for reference and require a live Ascend environment. They are not part of the packaging build.
