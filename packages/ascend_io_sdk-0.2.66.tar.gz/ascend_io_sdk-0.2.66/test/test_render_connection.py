import logging
import pytest

from ascend.sdk.definitions import Connection
from ascend.sdk.render import _inline_code_list_for_definition, InlineCode


@pytest.mark.skip(reason="Run this test manually")
def test_render_connection_example():
  logging.warning('example 1')
  conn = Connection('connection_id', 'connection_name', 'type_id', 'creds_id', {"shared_lib": {"stringValue": "import json\nimport ascend.log as log\n"}})

  result = _inline_code_list_for_definition(conn, "TEST-", ".")
  assert result
  assert len(result) == 1
  assert isinstance(result[0], InlineCode)
  code = result[0]
  assert code.code == 'import json\nimport ascend.log as log\n'
  assert code.resource_path.endswith('_shared.py')


if __name__ == "__main__":
  import sys
  import pytest

  logging.warning(f'starting test cases for {sys.argv[1:]}')
  sys.exit(pytest.main([__file__] + sys.argv[1:]))
