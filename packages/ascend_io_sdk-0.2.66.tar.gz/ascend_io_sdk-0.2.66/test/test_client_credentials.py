import os
import tempfile
import textwrap
import unittest
from unittest import mock

from ascend.sdk.client import _get_credentials


class ClientCredentialsTest(unittest.TestCase):
  def _get_credentials_from_config(self, hostname, config, verify_ssl=True):
    with tempfile.NamedTemporaryFile("w", delete=False) as f:
      f.write(textwrap.dedent(config))
      credentials_file_path = f.name
    self.addCleanup(os.unlink, credentials_file_path)

    env = {
        "ASCEND_ACCESS_KEY_ID": "",
        "ASCEND_SECRET_ACCESS_KEY": "",
        "ASCEND_CREDENTIALS_FILE": credentials_file_path,
    }
    with mock.patch.dict(os.environ, env):
      return _get_credentials(hostname, verify_ssl)

  def test_exact_hostname_profile_supports_multiple_custom_hosts(self):
    credentials = self._get_credentials_from_config(
        "alpha.example.com", """
        [alpha.example.com]
        ascend_access_key_id=alpha-access
        ascend_secret_access_key=alpha-secret
        verify_ssl=false

        [beta.example.com]
        ascend_access_key_id=beta-access
        ascend_secret_access_key=beta-secret
        """)

    self.assertEqual(("alpha-access", "alpha-secret", False), credentials)

  def test_legacy_ascend_io_short_profile_still_works(self):
    credentials = self._get_credentials_from_config(
        "trial.ascend.io", """
        [trial]
        ascend_access_key_id=trial-access
        ascend_secret_access_key=trial-secret
        """)

    self.assertEqual(("trial-access", "trial-secret", True), credentials)

  def test_default_profile_is_fallback(self):
    credentials = self._get_credentials_from_config(
        "alpha.example.com", """
        [default]
        ascend_access_key_id=default-access
        ascend_secret_access_key=default-secret
        """)

    self.assertEqual(("default-access", "default-secret", True), credentials)


if __name__ == "__main__":
  unittest.main()
