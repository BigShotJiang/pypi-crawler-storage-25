import random
import credstash
import yaml
import sys

from ascend.sdk.applier import DataServiceApplier, DataflowApplier
from ascend.sdk.client import Client
from ascend.sdk.definitions import (DataService, Dataflow, DataFeedConnector, DataFeed, ReadConnector, Transform, WriteConnector, ComponentGroup)
import ascend.protos.io.io_pb2 as io

_ascend_host = sys.argv[1]


def rand():
  r = int(random.random() * 1000000)
  return f"R{r}"


def sdk_client():
  return Client(_ascend_host, verify_ssl=False)


def data_service_credentials(rand, data_service, sdk_client):
  from ascend.protos.io.io_pb2 import Credentials as ContainerCredentials
  from ascend.protos.api.api_pb2 import Credentials
  name = f"credentials_{rand}"
  credentials = Credentials(name=name, credential=ContainerCredentials(azure=_azure_credentials()))

  credentials_response = sdk_client.create_data_service_credentials(data_service.id, credentials)
  return credentials_response.data


def read_connector(rand, credentials) -> ReadConnector:
  from google.protobuf.wrappers_pb2 import DoubleValue
  from google.protobuf.duration_pb2 import Duration
  from ascend.protos.format.format_pb2 import Xsv, Columns
  import ascend.protos.schema.schema_pb2 as schema
  from ascend.protos.pattern.pattern_pb2 import Pattern
  from ascend.protos.core.core_pb2 import Periodical
  from ascend.protos.component.component_pb2 import Source
  from ascend.protos.io.io_pb2 import Container
  from ascend.protos.component.component_pb2 import Priority
  from ascend.protos.operator.operator_pb2 import Operator
  import ascend.protos.io.io_pb2 as io

  Schema = schema.Schema
  ParsingSpecification = Columns.ParsingSpecification
  InvalidValueHandling = ParsingSpecification.InvalidValueHandling

  DefaultInvalidValueHandling = InvalidValueHandling(suppress_warn=True, use_default=InvalidValueHandling.UseDefault())

  def FloatParsingSpecification(**kwargs):
    return ParsingSpecification(float=schema.Float.Parser(decimal_separator=".", ), invalid_value_handling=DefaultInvalidValueHandling, **kwargs)

  id = f"read_connector_{rand}"
  return ReadConnector(
      id=id,
      name="rc",
      description="rc",
      assigned_priority=Priority(weight=DoubleValue(value=10000.0)),
      bytes=Source.FromBytes(parser=Operator(xsv_parser=Xsv.Parser(
          columns=Columns(parsing_specifications=[
              ParsingSpecification(
                  date=schema.Date.Parser(),
                  invalid_value_handling=DefaultInvalidValueHandling,
                  target_name="date_col",
              ),
              FloatParsingSpecification(target_name="yield_val", ),
              FloatParsingSpecification(target_name="prev_yield_val", ),
              FloatParsingSpecification(target_name="daily_diff", ),
          ], ),
          delimiter=",",
          schema=schema.Map(field=[
              schema.Field(
                  name="date_col",
                  schema=Schema(date=schema.Date()),
              ),
              schema.Field(
                  name="yield_val",
                  schema=Schema(float=schema.Float()),
              ),
              schema.Field(
                  name="prev_yield_val",
                  schema=Schema(float=schema.Float()),
              ),
              schema.Field(
                  name="daily_diff",
                  schema=Schema(float=schema.Float()),
              ),
          ], ),
      )), ),
      container=Container(
          abs=io.Azure.Abs.Container(account_name="kitchensink", container="kitchen-sink", credential_id=io.Credentials.Id(value=credentials.credential_id))),
      pattern=Pattern(exact_match="yield_curve.csv"),
      update_periodical=Periodical(
          period=Duration(seconds=134217727),
          offset=Duration(seconds=101025131),
      ))


def transform(rand, read_connector) -> Transform:
  from ascend.protos.component.component_pb2 import Priority
  from google.protobuf.wrappers_pb2 import DoubleValue
  import ascend.protos.operator.operator_pb2 as operator  # noqa: E402

  id = f"transform_{rand}"
  return Transform(id=id,
                   name="transform",
                   description="transform",
                   input_ids=[read_connector.id],
                   operator=operator.Operator(sql_query=operator.Sql.Query(sql="SELECT * FROM ${0}"), ),
                   assigned_priority=Priority(weight=DoubleValue(value=10000.0)))


def write_connector(rand, transform, credentials) -> WriteConnector:
  from google.protobuf.wrappers_pb2 import DoubleValue
  from ascend.protos.format.format_pb2 import Xsv
  from ascend.protos.component.component_pb2 import Sink
  from ascend.protos.component.component_pb2 import Priority
  import ascend.protos.io.io_pb2 as io
  import ascend.protos.operator.operator_pb2 as operator

  id = f"write_connector_{rand}"
  return WriteConnector(
      id=id,
      name="wc",
      description="wc",
      input_id=transform.id,
      assigned_priority=Priority(weight=DoubleValue(value=10000.0)),
      bytes=Sink.ToBytes(formatter=operator.Operator(xsv_formatter=Xsv.Formatter(
          delimiter=",",
          include_header=True,
      ))),
      container=io.Container(abs=io.Azure.Abs.Container(
          account_name="kitchensink", container="kitchen-sink", prefix=id, credential_id=io.Credentials.Id(value=credentials.credential_id))),
  )


def _azure_credentials() -> io.Azure.Credentials:
  value = getSecret("kitchen_sink_drd.yaml")
  creds = yaml.safe_load(value)

  if "credentials" not in creds or len(creds["credentials"]) == 0:
    raise KeyError("empty credentials")

  for cred in creds["credentials"]:
    if "azure" in cred and "servicePrincipal" in cred["azure"]:
      return io.Azure.Credentials(service_principal=io.Azure.Credentials.ServicePrincipal(client_id=cred["azure"]["servicePrincipal"]["clientId"],
                                                                                          client_secret=cred["azure"]["servicePrincipal"]["clientSecret"],
                                                                                          tenant=cred["azure"]["servicePrincipal"]["tenant"]))
  return None


__cache = dict()


def getSecret(key: str, table: str = 'eng', reload: bool = False) -> str:
  value = __cache.get((table, key)) if not reload else None
  if value is None:
    try:
      value = credstash.getSecret(key, table=table)
    except credstash.ItemNotFound as e:
      raise KeyError(f"cannot find '{key}' in table '{table}'")
    __cache[(table, key)] = value
  return value


rnd = rand()
client = sdk_client()

# this is a hack to overcome the limitation that creds can only exist after a data service
# is created, but in order to create a full dataservice with apply semantics, we need
# creds first !
ds_id = f"data_service_{rnd}"
ds = DataService(id=ds_id, name=ds_id, description=ds_id)
DataServiceApplier(client).apply(data_service=ds)

# first define components and groups
creds = data_service_credentials(rnd, ds, client)
rc = read_connector(rnd, creds)
t = transform(rnd, rc)
wc = write_connector(rnd, t, creds)
grp = ComponentGroup(id="group", name="group", description="group", component_ids=[rc.id, t.id])

# define a datafeed based on the transform
data_feed = DataFeed(id=f"data_feed_{rnd}", name=f"data_feed_{rnd}", description=f"data_feed_{rnd}", input_id=t.id, shared_with_all=True)

# define a dataflow
df1 = Dataflow(id=f"df1_{rnd}", name=f"df1_{rnd}", description=f"df1_{rnd}", components=[t, wc, rc], groups=[grp], data_feeds=[data_feed])

# this connects to the data feed in dataflow df1
data_feed_connector = DataFeedConnector(id=f"data_feed_connector_{rnd}",
                                        name=f"data_feed_connector_{rnd}",
                                        description=f"data_feed_connector_{rnd}",
                                        input_data_service_id=ds.id,
                                        input_dataflow_id=df1.id,
                                        input_data_feed_id=data_feed.id)

df2 = Dataflow(id=f"df2_{rnd}", name=f"df2_{rnd}", description=f"df2_{rnd}", components=[t, wc, rc], data_feed_connectors=[data_feed_connector])

# now redefine the data service with dataflows.
ds = DataService(id=ds_id, name=ds_id, description=ds_id, dataflows=[df1, df2])

DataflowApplier(client).apply(data_service_id=ds.id, dataflow=df1)
DataflowApplier(client).apply(data_service_id=ds.id, dataflow=df2)

DataServiceApplier(client).apply(data_service=ds)

# client.delete_data_service_credentials(data_service_id=ds.id, credential_id=creds.credential_id)
# client.delete_dataflow(data_service_id=ds.id, dataflow_id=df.id)
# client.delete_data_service(ds.id)
