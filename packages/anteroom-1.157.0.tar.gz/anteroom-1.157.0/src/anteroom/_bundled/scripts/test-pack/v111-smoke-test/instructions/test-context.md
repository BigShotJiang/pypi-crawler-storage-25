This is a test instruction from the v111-smoke-test pack.

It verifies that instruction-type artifacts load correctly from packs
and appear in the system prompt context.
