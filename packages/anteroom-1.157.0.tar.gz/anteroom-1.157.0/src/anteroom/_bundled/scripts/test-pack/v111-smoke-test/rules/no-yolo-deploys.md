---
enforce: hard
matches:
  - tool: bash
    pattern: "git push --force"
  - tool: bash
    pattern: "git push.*--force"
  - tool: bash
    pattern: "npm publish"
---
# No YOLO Deploys

Never run deployment commands without explicit user confirmation.

Blocked patterns:
- `git push --force` to main or master
- `npm publish` without version check
