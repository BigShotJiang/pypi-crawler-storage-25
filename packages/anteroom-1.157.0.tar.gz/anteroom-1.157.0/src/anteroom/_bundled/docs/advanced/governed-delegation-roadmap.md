# Governed Delegation Roadmap

This page captures the current planning direction for delegated agent work in
Anteroom.

The intent is to avoid treating "subagents" as a product category by default.
For Anteroom, the more durable framing is governed delegation:

- bounded delegated work
- explicit parent/child responsibilities
- strong auditability and policy control
- focus on research, review, and context isolation first

## Why This Track Exists

Anteroom already has subagent mechanics in the product:

- CLI and web subagent execution surfaces
- configurable `safety.subagent` limits
- event streaming for child activity
- mission and workflow planning that already references subagents as an
  execution primitive

What is still missing is the product and architecture position for how
delegated work should evolve from here.

The risk is straightforward:

- if Anteroom treats subagents as a generic implementation feature, the product
  drifts toward opaque autonomous behavior
- if Anteroom treats them as governed delegation, the feature area aligns with
  the project's strengths in policy, audit, bounded execution, and developer
  workflow

## Recommended Sequence

### 1. [#1082](https://github.com/troylar/anteroom/issues/1082) Define governed delegation in Anteroom

Establish the product position first.

Questions to answer:

- what delegated work is for
- where it fits relative to conversations, workflows, missions, and packs
- what safe/default usage looks like
- what should remain out of scope

Primary output:

- a short product decision note aligned with `VISION.md`

### 2. [#1083](https://github.com/troylar/anteroom/issues/1083) Validate governed delegation for research and review in the CLI

Choose the first proving ground before expanding the capability.

The best likely initial fit is the CLI developer workflow, with delegated work
used for:

- codebase analysis
- research
- review
- sidecar issue drafting or triage

Primary output:

- a narrow set of validated CLI-first use cases

### 3. [#1084](https://github.com/troylar/anteroom/issues/1084) Define the parent-child contract for delegated work

Define the architecture after the product position and proving surface are
clear.

Questions to answer:

- what context a child receives
- what tools and policies apply
- how outputs return to the parent
- what must be durable and auditable
- what controls must be operator-visible

Primary output:

- a shared contract for later implementation

### 4. [#1085](https://github.com/troylar/anteroom/issues/1085) Prototype governed delegation for CLI codebase analysis and review

Only after the first three questions are settled should Anteroom build a
delivery slice.

The prototype should stay narrow:

- delegated codebase analysis
- delegated review
- structured return payloads
- explicit operator visibility

Primary output:

- a real CLI proving slice that can justify broader rollout or a tighter scope

## Explicit Non-Goals For This Track

These should not be the default framing for the initial delegation work:

- parallel code-writing as the main user story
- deep hierarchical autonomous agent trees
- "subagents everywhere" positioning
- broad mission/workflow rollout before the CLI proving model is coherent

## Related Existing Issues

These issues already touch the lower-level subagent surface and should be kept
in mind when the delegation roadmap turns into implementation:

- `#858` — first-class subagent artifacts and Claude agent support
- `#910` — wrap subagent output as untrusted content before parent reuse
- `#911` — treat structured subagent errors as tool failures end-to-end
- `#912` — apply space-scoped hard rules inside nested web subagents
- `#913` — stream and bind web subagent progress to the correct `run_agent` call
- `#99` — store sub-agent tool calls in database for audit trail

These are useful implementation-adjacent signals, but they do not replace the
product and architecture decisions above.
