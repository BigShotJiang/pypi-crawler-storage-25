# Handoffs

This section is for lightweight internal handoff notes: short-lived planning notes, next-session reminders, and decision snapshots that should not be buried in chat history.

These notes are not product specs and are not the source of truth for shipped behavior. Use them to capture:

- what to do next
- why that order was chosen
- what is blocked
- which issues or branches matter

## Conventions

- Create one note per topic or decision.
- Prefer short, task-focused titles.
- Include the date, current recommendation, and next actions.
- Link to the relevant GitHub issues or docs pages.
- Archive or delete stale notes once the work is done.

## Current Notes

- [Next Focus: Spec-First Build Over Missions And Workflows](next-focus-specs-then-missions.md)
- [Handoff Template](template.md)
