# Handoff Template

Use this template for short next-step notes.

```md
# <Title>

Date: YYYY-MM-DD
Status: active | blocked | done

## Summary

<One short paragraph describing the current recommendation or state.>

## Why

- <Reason 1>
- <Reason 2>
- <Reason 3>

## Next Actions

1. <Concrete next step>
2. <Concrete next step>
3. <Concrete next step>

## References

- <Issue / PR / doc link>
- <Issue / PR / doc link>
```
