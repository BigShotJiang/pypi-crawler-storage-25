# Parallel Development Lanes: Specs + Workflows

Two independent lanes designed for simultaneous execution in separate Claude conversations. No file conflicts between lanes when sequencing guidance is followed.

## Lane A: Specs

Spec system features. Primary files: `services/spec_*.py`, `routers/specs.py`, `cli/repl.py` (spec commands).

### Sequence

```
#1015 (review inbox) ──┐
                       ├──> #1016 (portfolio dashboard)
#1031 (approval schema)┘
                                          ┌──> #1003 (spec packs)
#999 (constitution artifact) ─────────────┤
                                          └──> #1076 (docs: specs/workflows/missions)
#1019 (spec task hooks) ── WAIT for Lane B to finish workflow_engine.py work
```

### Issue Details

| Order | Issue | Title | Priority | Deps | Parallel? |
|-------|-------|-------|----------|------|-----------|
| 1a | **#1015** | Review inbox and approval queue | high | none | Yes, with 1b |
| 1b | **#1031** | Approval schema groundwork for #998 | -- | none | Yes, with 1a |
| 2 | **#1016** | Spec portfolio dashboard | medium | #1015 (shared query layer) | No |
| 3a | **#999** | Constitution artifact with policy enforcement | medium | none | Yes, with 3b |
| 3b | **#1076** | Document specs/workflows/missions | medium | none | Yes, with 3a |
| 4 | **#1003** | Spec packs for reusable standards | low | stable artifact model | No |
| 5 | **#1019** | Spec task hooks | low | Lane B done with engine.py | Last |

**Blocked (do not start):**
- #998 (multi-user approvals) -- blocked on #645 (identity) + #640 (RBAC)

### Parallel Batches

- **Batch 1**: #1015 + #1031 (different files: spec_queue/routers vs schema DDL)
- **Batch 2**: #1016 (builds on #1015 query layer)
- **Batch 3**: #999 + #1076 (different: services vs docs)
- **Batch 4**: #1003 (packs integration)
- **Batch 5**: #1019 (touches workflow_engine.py -- must coordinate with Lane B)

---

## Lane B: Workflows

Workflow engine features. Primary files: `services/workflow_engine.py`, `services/workflow_storage.py`, `cli/workflow_cli.py`, `routers/workflows.py`.

### Sequence

```
#995 (repair/resume) ──┬──> #986 (LLM fallback) ──> #987 (multi-model)
#890 (async cancel)  ──┘
                           #988 (LLM caching) ── anytime, independent
                           #985 (OpenRouter)  ── anytime, independent
#954 (workflow as artifact) ──> #960 (composition)
#952 (instance discovery) ── independent
#989 -> #990 -> #991 -> #992 (governance chain) ── filler
```

### Issue Details

| Order | Issue | Title | Priority | Deps | Parallel? |
|-------|-------|-------|----------|------|-----------|
| 1a | **#995** | Manual repair and edit-and-resume | high | none | Yes, with 1b |
| 1b | **#890** | Safe cancel/approval for async workflows | medium | none | Yes, with 1a |
| 2a | **#986** | Fallback and routing for LLM steps | medium | none | Yes, with 2b, 2c |
| 2b | **#988** | Response caching for LLM steps | medium | none | Yes, with 2a, 2c |
| 2c | **#985** | OpenRouter provider for LLM steps | low | none | Yes, with 2a, 2b |
| 3 | **#987** | Multi-model compare and judge | low | #986 | No |
| 4a | **#954** | Workflow as artifact type | low | none | Yes, with 4b |
| 4b | **#952** | Instance discovery and cross-repo | low | none | Yes, with 4a |
| 5 | **#960** | Workflow composition | low | #954 | No |
| filler | **#989-992** | Governance refinements | low | sequential chain | Between batches |

### Parallel Batches

- **Batch 1**: #995 + #890 (different concerns: repair vs cancel semantics)
- **Batch 2**: #986 + #988 + #985 (three independent LLM-step features, different files each)
- **Batch 3**: #987 (depends on #986 routing layer)
- **Batch 4**: #954 + #952 (different: artifact layer vs instance registry)
- **Batch 5**: #960 (depends on #954 artifact type)
- **Filler**: #989 -> #990 -> #991 -> #992 (tight chain, slot between batches)

---

## Cross-Lane Coordination

### File Overlap Risk

| File | Lane A | Lane B | Risk |
|------|--------|--------|------|
| `services/workflow_engine.py` | #1019 (hook emission) | #995, #890 (primary) | **Medium** |
| `services/workflow_storage.py` | #1015 (one query) | #995, #890 (primary) | **Low** |
| `services/packs.py` | #1003 | #954 | **Low** |

### Mitigation

1. **Lane A #1019** (spec task hooks) must be the LAST item in Lane A. By then, Lane B will have finished its heavy `workflow_engine.py` work (#995, #890).
2. **Lane A #1015** adds one query to `workflow_storage.py` (`list_spec_blocked_runs`). This is additive (new function, no edits to existing functions) -- safe to merge independently.
3. **Lane A #1003** and **Lane B #954** both touch packs, but #1003 adds spec-type packs while #954 adds workflow-type artifacts. Different artifact types, minimal collision.

### Recommended Start Order

1. Start **both lanes simultaneously**
2. Lane A begins with **#1015 + #1031** (parallel batch)
3. Lane B begins with **#995 + #890** (parallel batch)
4. Lane A holds **#1019** until Lane B signals `workflow_engine.py` work is done

---

## Summary

| | Lane A: Specs | Lane B: Workflows |
|---|---|---|
| **Issues** | 7 (+ 1 blocked) | 11 (+ 4 filler) |
| **High priority** | #1015 | #995 |
| **Max parallelism** | 2 at a time | 3 at a time |
| **Primary files** | spec_*.py, routers/specs.py | workflow_*.py, workflow_cli.py |
| **Cross-lane dep** | #1019 waits for Lane B | none |
