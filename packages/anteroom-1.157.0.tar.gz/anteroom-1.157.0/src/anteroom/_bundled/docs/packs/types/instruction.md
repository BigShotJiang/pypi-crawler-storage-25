# Instruction

A static block of text prepended to the system prompt. Instructions provide context the agent needs but that isn't an enforceable rule.

**Content format**: Markdown (plain text).

**How Anteroom uses it**: Instructions are injected once at the start of the system prompt, before rules and conversation context.

**Example**:

```markdown title="instructions/project-context.md"
# Project Context

This is a FastAPI application with a React frontend. The API uses SQLAlchemy
with PostgreSQL. Authentication is handled via JWT tokens with refresh rotation.

Key directories:
- `src/api/` -- FastAPI routers and services
- `src/models/` -- SQLAlchemy models
- `frontend/` -- React app (Vite + TypeScript)
```

**Directory**: `instructions/`

**Common mistakes**:

- Duplicating information already in ANTEROOM.md or CLAUDE.md
- Adding instructions that should be rules (if it's enforceable, make it a rule)
