# Artifact Types

Anteroom supports 8 artifact types. Each serves a distinct role in how the agent processes content.

| Type | Role | Directory |
|------|------|-----------|
| [**skill**](types/skill.md) | Reusable prompt template (`/skill-name`) | `skills/` |
| [**rule**](types/rule.md) | Always-on instruction injected every turn | `rules/` |
| [**instruction**](types/instruction.md) | Static system prompt context | `instructions/` |
| [**context**](types/context.md) | Dynamic reference material | `context/` |
| [**memory**](types/memory.md) | Persistent cross-session knowledge | `memories/` |
| [**mcp_server**](types/mcp-server.md) | MCP server connection config | `mcp_servers/` |
| [**config_overlay**](types/config-overlay.md) | YAML config fragment merged at runtime | `config_overlays/` |
| [**spec**](types/spec.md) | Structured specification with approval lifecycle | `specs/` |

File extensions are probed in order: `.yaml`, `.md`, `.txt`, `.json`. The first match wins.
