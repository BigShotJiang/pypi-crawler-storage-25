# MCP Server

An MCP server configuration that Anteroom connects to for additional tools.

**Content format**: YAML with MCP server connection fields.

**How Anteroom uses it**: The MCP manager reads mcp_server artifacts and establishes connections to the configured servers, making their tools available to the agent.

**Example**:

```yaml title="mcp_servers/filesystem.yaml"
command: npx
args:
  - -y
  - "@modelcontextprotocol/server-filesystem"
  - "/path/to/allowed/directory"
env:
  NODE_ENV: production
tools_include:
  - "read_file"
  - "write_file"
tools_exclude:
  - "delete_*"
trust_level: untrusted
```

**Directory**: `mcp_servers/`

**Common mistakes**:

- Hardcoding absolute paths that differ across team members' machines
- Setting `trust_level: trusted` without understanding the security implications (trusted tools skip defensive prompt envelopes)
- Forgetting `tools_include`/`tools_exclude` filters, exposing more tools than intended
