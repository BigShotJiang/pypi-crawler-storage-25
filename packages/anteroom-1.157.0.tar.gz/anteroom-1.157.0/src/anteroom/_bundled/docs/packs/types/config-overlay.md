# Config Overlay

A YAML fragment that merges into the running Anteroom configuration. Config overlays let packs adjust settings without requiring users to edit their config file.

**Content format**: YAML (must be valid YAML that maps to Anteroom config fields).

**How Anteroom uses it**: Config overlays are deep-merged into the active configuration at the appropriate precedence layer. They can set safety modes, model preferences, timeout values, or any other config field.

**Example**:

```yaml title="config_overlays/safety.yaml"
safety:
  approval_mode: ask_for_writes
  bash_sandbox:
    allow_network: false
    allow_package_install: false
```

**Directory**: `config_overlays/`

**Common mistakes**:

- Setting fields that conflict with team-enforced config (team enforcement always wins)
- Invalid YAML syntax (health check catches this as a `malformed` error)
- Overriding security settings to be less restrictive than intended
