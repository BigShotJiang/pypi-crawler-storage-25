"""
VBA execution: run_vba, run_macro, eval_vba, and dialog helpers.
"""

import ctypes
import json
import os
import tempfile
import threading
import time
from typing import Any, Optional

from .core import _Session, _get_vb_project, log


# ---------------------------------------------------------------------------
# Application.Run via InvokeTypes
# ---------------------------------------------------------------------------

def _invoke_app_run(app, procedure: str, call_args: list):
    """Call Application.Run via InvokeTypes -- proper COM optional-param protocol.

    pywin32's late-bound Dispatch uses Invoke() which passes only the provided
    args.  Access.Application.Run has 31 params (1 required + 30 optional) and
    its COM server rejects calls missing VT_ERROR markers for the optional params
    with DISP_E_BADPARAMCOUNT (-2147352562).

    InvokeTypes converts pythoncom.Missing -> VT_ERROR/DISP_E_PARAMNOTFOUND,
    matching what early-bound wrappers (EnsureDispatch / MakeDispatchFuncMethod)
    generate.
    """
    import pythoncom

    dispid = app._oleobj_.GetIDsOfNames(0, "Run")

    # Application.Run signature:
    #   Function Run(Procedure As String, [Arg1], ..., [Arg30]) As Variant
    # Arg types: (VT, PARAMFLAGS)
    #   Procedure:   VT_BSTR(8),    PARAMFLAG_FIN(1)
    #   Arg1..Arg30: VT_VARIANT(12), PARAMFLAG_FIN|PARAMFLAG_FOPT(17)
    arg_types = tuple([(8, 1)] + [(12, 17)] * 30)

    # Fill: procedure + user args + padding with Missing
    n = len(call_args)
    all_args = [procedure] + list(call_args) + [pythoncom.Missing] * (30 - n)

    return app._oleobj_.InvokeTypes(
        dispid,
        0,                           # LCID
        pythoncom.DISPATCH_METHOD,   # wFlags
        (12, 0),                     # return type: VT_VARIANT
        arg_types,
        *all_args,
    )


# ---------------------------------------------------------------------------
# Dialog dismissal helpers
# ---------------------------------------------------------------------------

# Button priority for dialog dismissal.  CANCEL is first so wizards are
# cancelled (not advanced — pressing Enter on a "Create Report Wizard"
# dialog would click "Next >" and create stray Report1 objects).
# END is kept in the list to preserve existing behaviour for VBA runtime
# error dialogs which have no Cancel button.
_BUTTON_PRIORITY = (
    "cancel", "cancelar",
    "end", "finalizar",
    "ok", "aceptar",
)


def _dismiss_dialogs_by_pid(pid: int, screenshot_holder: Optional[list] = None) -> bool:
    """Dismiss modal dialogs owned by a process ID.

    Matches any window where class == '#32770' OR the title contains
    'wizard' / 'asistente' (catches non-standard wizard windows that do
    not use the #32770 class).  Used during /decompile subprocess where
    we have a PID but no COM Application object.
    Returns True if any dialog was found and dismissed.
    """
    import win32gui
    import win32process

    found = []
    def _cb(hwnd, found):
        try:
            if not win32gui.IsWindowVisible(hwnd):
                return True
            _, wpid = win32process.GetWindowThreadProcessId(hwnd)
            if wpid != pid:
                return True
            cls = win32gui.GetClassName(hwnd)
            title = (win32gui.GetWindowText(hwnd) or "").lower()
            if cls == '#32770' or "wizard" in title or "asistente" in title:
                found.append(hwnd)
        except Exception:
            pass
        return True

    try:
        win32gui.EnumWindows(_cb, found)
    except Exception:
        return False

    if not found:
        return False

    # Capture screenshot of first dialog before dismissing
    if screenshot_holder is not None:
        try:
            # Lazy import to avoid circular dependency
            from .ui import _capture_window
            img, _, _ = _capture_window(found[0], max_width=800)
            prefix = "access_dialog"
            # Callers that hand in a holder can signal a custom prefix by
            # pre-seeding the list with a string starting with "prefix:".
            path = os.path.join(tempfile.gettempdir(),
                                f"{prefix}_{int(time.time())}.png")
            img.save(path)
            screenshot_holder.append(path)
        except Exception:
            pass  # screenshot is best-effort

    for dlg in found:
        _try_click_button(dlg)
        # Fallback: WM_CLOSE
        try:
            if win32gui.IsWindow(dlg):
                win32gui.PostMessage(dlg, 0x0010, 0, 0)  # WM_CLOSE
        except Exception:
            pass

    return True


def _dismiss_access_dialogs(hwnd_access: int, screenshot_holder: Optional[list] = None) -> bool:
    """Dismiss modal dialogs owned by the Access process.

    Thin wrapper around `_dismiss_dialogs_by_pid`: resolves the PID of the
    window and delegates.  Preserves backward compatibility with all
    existing callers (`ac_run_vba`, `_dialog_watchdog`, `_compile_dialog_watchdog`).
    """
    import win32process
    try:
        _, pid = win32process.GetWindowThreadProcessId(hwnd_access)
    except Exception:
        return False
    return _dismiss_dialogs_by_pid(pid, screenshot_holder)


def _try_click_button(dialog_hwnd: int):
    """Find and click a button in a dialog, preferring Cancel over End/OK.

    Uses a two-pass approach:
    1. EnumChildWindows to collect every Button-class child with its text.
    2. Iterate _BUTTON_PRIORITY and click the first matching button.

    Cancel-first priority makes wizards safe to dismiss (pressing their
    default button would advance the wizard and create stray objects).
    Runtime-error dialogs (no Cancel button) fall through to End, which
    preserves the existing `ac_run_vba` behaviour.
    """
    import win32gui

    buttons: list[tuple[int, str]] = []

    def _cb(hwnd, _):
        try:
            if win32gui.GetClassName(hwnd) == 'Button':
                text = (win32gui.GetWindowText(hwnd) or "").lower().strip()
                # Strip accelerator marker (&)
                text = text.lstrip('&').replace('&', '')
                buttons.append((hwnd, text))
        except Exception:
            pass
        return True

    try:
        win32gui.EnumChildWindows(dialog_hwnd, _cb, None)
    except Exception:
        pass

    # Second pass: iterate priority list, click the first match
    for target in _BUTTON_PRIORITY:
        for btn_hwnd, btn_text in buttons:
            if btn_text == target:
                try:
                    win32gui.PostMessage(btn_hwnd, 0x00F5, 0, 0)  # BM_CLICK
                except Exception:
                    pass
                return


def _dialog_watchdog(hwnd_access: int, stop_event: threading.Event,
                     dismissed: list, screenshot_holder: list,
                     interval: float = 2.0):
    """Poll for Access dialogs every *interval* seconds and dismiss them."""
    while not stop_event.is_set():
        if _dismiss_access_dialogs(hwnd_access,
                                   screenshot_holder if not dismissed else None):
            dismissed.append(True)
        stop_event.wait(interval)


# ---------------------------------------------------------------------------
# Run macro
# ---------------------------------------------------------------------------

def ac_run_macro(db_path: str, macro_name: str) -> dict:
    """Runs an Access macro."""
    app = _Session.connect(db_path)
    try:
        app.DoCmd.RunMacro(macro_name)
    except Exception as exc:
        raise RuntimeError(f"Error running macro '{macro_name}': {exc}")
    return {"macro_name": macro_name, "status": "executed"}


# ---------------------------------------------------------------------------
# Run VBA procedure
# ---------------------------------------------------------------------------

def ac_run_vba(
    db_path: str, procedure: str, args: Optional[list] = None,
    timeout: Optional[int] = None,
) -> dict:
    """Runs a VBA Sub/Function via Application.Run (or COM Forms() for form modules).

    Supports 3 syntaxes:
    - 'MyModule.MySub' or 'MySub' -> Application.Run (standard modules)
    - 'Forms.FormName.Method' -> COM Forms() access (form modules, form must be open)

    If the procedure shows MsgBox/InputBox and timeout is passed, the dialog is
    auto-dismissed after timeout seconds and a timeout error is returned.
    """
    app = _Session.connect(db_path)
    call_args = args or []
    if len(call_args) > 30:
        raise ValueError("Application.Run supports max 30 arguments.")

    # Forms.FormName.Method -> direct COM access (form modules)
    if "." in procedure:
        parts = procedure.split(".", 2)
        if parts[0] == "Forms" and len(parts) == 3:
            form_name, method_name = parts[1], parts[2]
            try:
                form = app.Forms(form_name)
                if call_args:
                    result = getattr(form, method_name)(*call_args)
                else:
                    # Try method call first, fall back to property read
                    attr = getattr(form, method_name)
                    try:
                        result = attr() if callable(attr) else attr
                    except (TypeError, AttributeError):
                        result = attr
            except Exception as exc:
                raise RuntimeError(
                    f"Error calling Forms('{form_name}').{method_name}: {exc}. "
                    f"Make sure the form is open."
                )
            if result is not None:
                try:
                    json.dumps(result)
                except (TypeError, ValueError):
                    result = str(result)
            return {"procedure": procedure, "result": result, "status": "executed"}

    # Standard Application.Run with optional watchdog timeout (polling every 2s)
    stop_event = None
    dismissed: list = []
    dialog_screenshots: list = []
    if timeout:
        # Capture hwnd on main thread (COM is apartment-threaded)
        _h = app.hWndAccessApp
        hwnd = int(_h() if callable(_h) else _h)
        stop_event = threading.Event()
        watchdog = threading.Thread(
            target=_dialog_watchdog,
            args=[hwnd, stop_event, dismissed, dialog_screenshots, 2.0],
            daemon=True,
        )
        watchdog.start()
    try:
        result = _invoke_app_run(app, procedure, call_args)
    except Exception as exc:
        if dismissed:
            detail = f"'{procedure}' -- VBA runtime error (dialog auto-dismissed)."
            if dialog_screenshots:
                detail += f" Screenshot: {dialog_screenshots[0]}"
            raise RuntimeError(detail)
        raise RuntimeError(f"Error running '{procedure}': {exc}")
    finally:
        if stop_event:
            stop_event.set()
    # COM may return non-serializable types; convert to str if needed
    if result is not None:
        try:
            json.dumps(result)
        except (TypeError, ValueError):
            result = str(result)
    return {"procedure": procedure, "result": result, "status": "executed"}


# ---------------------------------------------------------------------------
# Eval VBA expression
# ---------------------------------------------------------------------------

def _invoke_app_eval(app, expression: str):
    """Call Application.Eval via InvokeTypes -- same pattern as _invoke_app_run."""
    import pythoncom
    dispid = app._oleobj_.GetIDsOfNames(0, "Eval")
    # Eval(StringExpr As String) As Variant -- 1 required param
    return app._oleobj_.InvokeTypes(
        dispid, 0, pythoncom.DISPATCH_METHOD,
        (12, 0),       # return: VT_VARIANT
        ((8, 1),),     # 1 param: VT_BSTR, PARAMFLAG_FIN
        expression,
    )


def _eval_via_temp_module(app, expression: str, original_exc: Exception):
    """Fallback: create temp standard module with wrapper function, run it, clean up."""
    proj = _get_vb_project(app)
    comp = None
    try:
        # Create temp standard module (type 1 = vbext_ct_StdModule)
        comp = proj.VBComponents.Add(1)
        temp_name = comp.Name
        cm = comp.CodeModule

        # Insert wrapper function
        wrapper = (
            "Public Function _mcp_eval_wrapper() As Variant\r\n"
            f"    _mcp_eval_wrapper = {expression}\r\n"
            "End Function\r\n"
        )
        cm.InsertLines(1, wrapper)

        # Call via Application.Run
        result = _invoke_app_run(app, f"{temp_name}._mcp_eval_wrapper", [])
        return result

    except Exception as fallback_exc:
        raise RuntimeError(
            f"Eval failed: {original_exc}\n"
            f"Fallback (temp module) also failed: {fallback_exc}\n"
            f"Alternatives: use access_run_vba to call a public Function "
            f"in a standard module that wraps this expression."
        )
    finally:
        if comp is not None:
            try:
                proj.VBComponents.Remove(comp)
            except Exception:
                log.warning("Could not remove temp module '%s'", temp_name)


def ac_eval_vba(db_path: str, expression: str) -> dict:
    """Evaluates a VBA/Access expression via Application.Eval with auto-fallback."""
    app = _Session.connect(db_path)

    # 1. Try Application.Eval first
    try:
        result = _invoke_app_eval(app, expression)
    except Exception as eval_exc:
        # 2. Fallback: wrap in a temp standard module function
        result = _eval_via_temp_module(app, expression, eval_exc)

    # serialize result
    if result is not None:
        try:
            json.dumps(result)
        except (TypeError, ValueError):
            result = str(result)
    return {"expression": expression, "result": result, "status": "evaluated"}
