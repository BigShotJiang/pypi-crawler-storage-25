"""Community detection on NetworkX graphs.

Uses Leiden (graspologic) if available, falls back to Louvain (networkx).
Splits oversized communities. Returns cohesion scores.
"""
from __future__ import annotations
import networkx as nx


def _partition(G: nx.Graph) -> dict[str, int]:
    """Run community detection. Returns {node_id: community_id}.

    Resolution adapts to graph density:
    - Dense graphs (code): resolution=1.5 for tighter communities
    - Sparse graphs (docs): resolution=1.0 for broader grouping

    Tries Leiden (graspologic) first — best quality.
    Falls back to Louvain (built into networkx) if graspologic is not installed.
    """
    # Adaptive resolution based on graph size and density
    n = G.number_of_nodes()
    avg_degree = sum(dict(G.degree()).values()) / max(n, 1)
    if avg_degree <= 3:
        resolution = 1.0  # sparse docs: broad grouping
    elif n > 5000:
        resolution = 1.0  # large codebases: fewer, larger communities
    else:
        resolution = 1.5  # medium codebases: tight communities

    try:
        from graspologic.partition import leiden
        return leiden(G, resolution=resolution)
    except ImportError:
        pass

    # Fallback: networkx louvain (available since networkx 2.7)
    communities = nx.community.louvain_communities(G, seed=42, resolution=resolution)
    return {node: cid for cid, nodes in enumerate(communities) for node in nodes}


def build_graph(nodes: list[dict], edges: list[dict]) -> nx.Graph:
    """Build a NetworkX graph from node/edge dicts.

    Preserves original edge direction as _src/_tgt attributes so that
    display functions can show relationships in the correct direction,
    even though the graph is undirected for structural analysis.
    """
    G = nx.Graph()
    for n in nodes:
        G.add_node(n["id"], **{k: v for k, v in n.items() if k != "id"})
    for e in edges:
        attrs = {k: v for k, v in e.items() if k not in ("source", "target")}
        attrs["_src"] = e["source"]
        attrs["_tgt"] = e["target"]
        G.add_edge(e["source"], e["target"], **attrs)
    return G


_MAX_COMMUNITY_FRACTION = 0.15   # communities larger than 15% of graph get split
_MIN_SPLIT_SIZE = 10             # only split if community has at least this many nodes


def cluster(G: nx.Graph) -> dict[int, list[str]]:
    """Run community detection. Returns {community_id: [node_ids]}.

    Community IDs are stable across runs: 0 = largest community after splitting.
    Oversized communities (> 25% of graph nodes, min 10) are split by running
    a second pass on the subgraph.
    """
    if G.number_of_nodes() == 0:
        return {}
    if G.number_of_edges() == 0:
        return {i: [n] for i, n in enumerate(sorted(G.nodes))}

    # Leiden warns and drops isolates - handle them separately
    isolates = [n for n in G.nodes() if G.degree(n) == 0]
    connected_nodes = [n for n in G.nodes() if G.degree(n) > 0]
    connected = G.subgraph(connected_nodes)

    raw: dict[int, list[str]] = {}
    if connected.number_of_nodes() > 0:
        partition = _partition(connected)
        for node, cid in partition.items():
            raw.setdefault(cid, []).append(node)

    # Each isolate becomes its own single-node community
    next_cid = max(raw.keys(), default=-1) + 1
    for node in isolates:
        raw[next_cid] = [node]
        next_cid += 1

    # Split oversized communities
    max_size = max(_MIN_SPLIT_SIZE, int(G.number_of_nodes() * _MAX_COMMUNITY_FRACTION))
    final_communities: list[list[str]] = []
    for nodes in raw.values():
        if len(nodes) > max_size:
            final_communities.extend(_split_community(G, nodes))
        else:
            final_communities.append(nodes)

    # Re-index by size descending for deterministic ordering
    final_communities.sort(key=len, reverse=True)
    return {i: sorted(nodes) for i, nodes in enumerate(final_communities)}


def _split_community(G: nx.Graph, nodes: list[str]) -> list[list[str]]:
    """Run a second detection pass on a community subgraph to split it further."""
    subgraph = G.subgraph(nodes)
    if subgraph.number_of_edges() == 0:
        # No edges - split into individual nodes
        return [[n] for n in sorted(nodes)]
    try:
        sub_partition = _partition(subgraph)
        sub_communities: dict[int, list[str]] = {}
        for node, cid in sub_partition.items():
            sub_communities.setdefault(cid, []).append(node)
        if len(sub_communities) <= 1:
            return [sorted(nodes)]
        return [sorted(v) for v in sub_communities.values()]
    except Exception:
        return [sorted(nodes)]


def cohesion_score(G: nx.Graph, community_nodes: list[str]) -> float:
    """Ratio of actual intra-community edges to maximum possible."""
    n = len(community_nodes)
    if n <= 1:
        return 1.0
    subgraph = G.subgraph(community_nodes)
    actual = subgraph.number_of_edges()
    possible = n * (n - 1) / 2
    return round(actual / possible, 2) if possible > 0 else 0.0


def score_all(G: nx.Graph, communities: dict[int, list[str]]) -> dict[int, float]:
    """Compute cohesion scores for all communities."""
    return {cid: cohesion_score(G, nodes) for cid, nodes in communities.items()}
