#!/usr/bin/env python3
"""
Statistical Analysis Module - Week 3 Day 13-14
SAFE-Web Data Analysis and Statistics
"""

import sqlite3
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
import logging
from datetime import datetime
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from config import DATABASE_PATH

class StatisticalAnalyzer:
    def __init__(self, db_path=None):
        if db_path is None:
            db_path = str(DATABASE_PATH)
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
        
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)

    def calculate_basic_stats(self, values: List[float]) -> Dict:
        """Calculate mean, median, standard deviation"""
        if not values:
            return {'mean': 0, 'median': 0, 'std_dev': 0, 'count': 0}
        
        np_values = np.array(values)
        
        return {
            'mean': float(np.mean(np_values)),
            'median': float(np.median(np_values)),
            'std_dev': float(np.std(np_values)),
            'min': float(np.min(np_values)),
            'max': float(np.max(np_values)),
            'count': len(values)
        }

    def analyze_browser_performance(self) -> Dict:
        """Analyze performance metrics by browser"""
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.browser_name,
            tr.duration_seconds,
            sm.value as cpu_percent,
            sm2.value as memory_percent,
            ec.estimated_energy_wh
        FROM test_runs tr
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_percent'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_percent'
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        WHERE tr.status = 'completed'
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        browser_stats = {}
        
        for browser in df['browser_name'].unique():
            browser_data = df[df['browser_name'] == browser]
            
            browser_stats[browser] = {
                'duration': self.calculate_basic_stats(browser_data['duration_seconds'].dropna().tolist()),
                'cpu_percent': self.calculate_basic_stats(browser_data['cpu_percent'].dropna().tolist()),
                'memory_percent': self.calculate_basic_stats(browser_data['memory_percent'].dropna().tolist()),
                'estimated_energy_wh': self.calculate_basic_stats(browser_data['estimated_energy_wh'].dropna().tolist())
            }
        
        return browser_stats

    def analyze_search_engine_performance(self) -> Dict:
        """Analyze performance metrics by search engine"""
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.search_engine,
            tr.duration_seconds,
            sm.value as cpu_percent,
            sm2.value as memory_percent,
            ec.estimated_energy_wh
        FROM test_runs tr
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_percent'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_percent'
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        WHERE tr.status = 'completed'
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        engine_stats = {}
        
        for engine in df['search_engine'].unique():
            engine_data = df[df['search_engine'] == engine]
            
            engine_stats[engine] = {
                'duration': self.calculate_basic_stats(engine_data['duration_seconds'].dropna().tolist()),
                'cpu_percent': self.calculate_basic_stats(engine_data['cpu_percent'].dropna().tolist()),
                'memory_percent': self.calculate_basic_stats(engine_data['memory_percent'].dropna().tolist()),
                'estimated_energy_wh': self.calculate_basic_stats(engine_data['estimated_energy_wh'].dropna().tolist())
            }
        
        return engine_stats

    def analyze_ai_vs_regular(self) -> Dict:
        """Compare AI-enabled vs regular search performance"""
        conn = self.get_connection()
        
        query = """
        SELECT 
            CASE WHEN tr.ai_enabled = 1 THEN 'ai_enabled' ELSE 'regular' END as test_type,
            tr.duration_seconds,
            sm.value as cpu_percent,
            sm2.value as memory_percent,
            ec.estimated_energy_wh,
            ad.ai_features_detected
        FROM test_runs tr
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_percent'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_percent'
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN ai_detection ad ON tr.id = ad.test_run_id
        WHERE tr.status = 'completed'
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        comparison = {}
        
        for test_type in ['ai_enabled', 'regular']:
            type_data = df[df['test_type'] == test_type]
            
            comparison[test_type] = {
                'duration': self.calculate_basic_stats(type_data['duration_seconds'].dropna().tolist()),
                'cpu_percent': self.calculate_basic_stats(type_data['cpu_percent'].dropna().tolist()),
                'memory_percent': self.calculate_basic_stats(type_data['memory_percent'].dropna().tolist()),
                'estimated_energy_wh': self.calculate_basic_stats(type_data['estimated_energy_wh'].dropna().tolist()),
                'total_tests': len(type_data)
            }
        
        # AI detection rate
        ai_tests = df[df['test_type'] == 'ai_enabled']
        ai_detected = len(ai_tests[ai_tests['ai_enabled'] == 1])
        ai_detection_rate = (ai_detected / len(ai_tests)) * 100 if len(ai_tests) > 0 else 0
        
        comparison['ai_detection_rate'] = ai_detection_rate
        
        return comparison

    def calculate_cost_per_query(self) -> Dict:
        """Calculate cost metrics per query"""
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.browser_name,
            tr.search_engine,
            CASE WHEN tr.ai_enabled = 1 THEN 'ai_enabled' ELSE 'regular' END as test_type,
            tr.duration_seconds,
            sm.value as cpu_percent,
            sm2.value as memory_percent,
            sm3.metric_value + sm4.metric_value as total_network,
            ec.estimated_energy_wh
        FROM test_runs tr
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_percent'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_percent'
        LEFT JOIN system_metrics sm3 ON tr.id = sm3.test_run_id AND sm3.metric_type = 'network_bytes_sent'
        LEFT JOIN system_metrics sm4 ON tr.id = sm4.test_run_id AND sm4.metric_type = 'network_bytes_recv'
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        WHERE tr.status = 'completed'
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        # Cost calculations (simplified model)
        cost_analysis = {}
        
        for combination in df.groupby(['browser_name', 'search_engine', 'test_type']):
            key = f"{combination[0][0]}_{combination[0][1]}_{combination[0][2]}"
            data = combination[1]
            
            # Calculate average costs
            avg_duration = data['duration_seconds'].mean()
            avg_cpu = data['cpu_percent'].mean()
            avg_memory = data['memory_percent'].mean()
            avg_network = data['total_network'].mean()
            avg_energy = data['estimated_energy_wh'].mean()
            
            # Cost estimates (arbitrary units for comparison)
            cpu_cost = avg_cpu * 0.001  # CPU cost per percentage point
            memory_cost = avg_memory * 0.0005  # Memory cost per percentage point
            network_cost = avg_network * 0.00001  # Network cost per byte
            energy_cost = avg_energy * 0.12  # Energy cost per unit (kWh rate)
            
            total_cost = cpu_cost + memory_cost + network_cost + energy_cost
            
            cost_analysis[key] = {
                'avg_duration': avg_duration,
                'cpu_cost': cpu_cost,
                'memory_cost': memory_cost,
                'network_cost': network_cost,
                'energy_cost': energy_cost,
                'total_cost': total_cost,
                'test_count': len(data)
            }
        
        return cost_analysis

    def generate_summary_report(self) -> Dict:
        """Generate comprehensive statistical summary"""
        self.logger.info("Generating comprehensive statistical analysis")
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'browser_performance': self.analyze_browser_performance(),
            'search_engine_performance': self.analyze_search_engine_performance(),
            'ai_vs_regular_comparison': self.analyze_ai_vs_regular(),
            'cost_per_query_analysis': self.calculate_cost_per_query()
        }
        
        # Add overall statistics
        conn = self.get_connection()
        
        # Total test counts
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM test_runs WHERE status = 'completed'")
        total_successful_tests = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM test_runs WHERE status != 'completed'")
        total_failed_tests = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT browser_name) FROM test_runs")
        unique_browsers = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT search_engine) FROM test_runs")
        unique_search_engines = cursor.fetchone()[0]
        
        conn.close()
        
        report['overall_statistics'] = {
            'total_successful_tests': total_successful_tests,
            'total_failed_tests': total_failed_tests,
            'success_rate': (total_successful_tests / (total_successful_tests + total_failed_tests)) * 100,
            'unique_browsers_tested': unique_browsers,
            'unique_search_engines_tested': unique_search_engines
        }
        
        return report

    def export_statistics_table(self, metric: str = 'duration') -> pd.DataFrame:
        """Export statistics in table format for reporting"""
        browser_stats = self.analyze_browser_performance()
        
        table_data = []
        
        for browser, stats in browser_stats.items():
            if metric in stats:
                row = {
                    'Browser': browser.title(),
                    'Mean': round(stats[metric]['mean'], 3),
                    'Median': round(stats[metric]['median'], 3),
                    'Std Dev': round(stats[metric]['std_dev'], 3),
                    'Min': round(stats[metric]['min'], 3),
                    'Max': round(stats[metric]['max'], 3),
                    'Count': stats[metric]['count']
                }
                table_data.append(row)
        
        return pd.DataFrame(table_data)

    def get_all_browser_stats(self) -> List[Dict]:
        """Get browser statistics for CLI display"""
        conn = self.get_connection()

        query = """
        SELECT
            tr.browser_name,
            COUNT(*) as tests,
            AVG(ec.estimated_energy_wh) as energy,
            AVG(sm.value) as cpu,
            AVG(sm2.value) as memory,
            AVG(psm.https_enabled) as avg_https,
            AVG(psm.third_party_cookies) as avg_3p_cookies,
            AVG(psm.tracker_count) as avg_trackers,
            AVG(psm.mixed_content) as avg_mixed,
            AVG(psm.cookie_count) as avg_cookies,
            AVG(psm.secure_cookies) as avg_secure_cookies
        FROM test_runs tr
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_mean'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_mean_mb'
        LEFT JOIN privacy_security_metrics psm ON tr.id = psm.test_run_id
        GROUP BY tr.browser_name
        """

        cursor = conn.cursor()
        cursor.execute(query)

        from src.monitoring.privacy_security_monitor import PrivacySecurityMonitor
        monitor = PrivacySecurityMonitor()

        results = []
        for row in cursor.fetchall():
            avg_metrics = {
                'https_enabled': bool(round(row[5] or 1)),
                'third_party_cookies': row[6] or 0,
                'tracker_count': row[7] or 0,
                'mixed_content': row[8] or 0,
                'cookie_count': row[9] or 1,
                'secure_cookies': row[10] or 0,
            }
            results.append({
                'name': row[0].title(),
                'tests': row[1] or 0,
                'energy': row[2] or 0,
                'cpu': row[3] or 0,
                'memory': row[4] or 0,
                'privacy': monitor.calculate_privacy_score(avg_metrics),
                'security': monitor.calculate_security_score(avg_metrics),
            })

        conn.close()
        return results

    def get_browser_stats(self, browser: str) -> Dict:
        """Get statistics for a specific browser"""
        conn = self.get_connection()

        query = """
        SELECT
            COUNT(*) as tests,
            AVG(ec.estimated_energy_wh) as energy,
            AVG(sm.value) as cpu,
            AVG(sm2.value) as memory,
            AVG(tr.page_load_time) as page_load,
            AVG(psm.https_enabled) as avg_https,
            AVG(psm.third_party_cookies) as avg_3p_cookies,
            AVG(psm.tracker_count) as avg_trackers,
            AVG(psm.mixed_content) as avg_mixed,
            AVG(psm.cookie_count) as avg_cookies,
            AVG(psm.secure_cookies) as avg_secure_cookies
        FROM test_runs tr
        LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
        LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id AND sm.metric_type = 'cpu_mean'
        LEFT JOIN system_metrics sm2 ON tr.id = sm2.test_run_id AND sm2.metric_type = 'memory_mean_mb'
        LEFT JOIN privacy_security_metrics psm ON tr.id = psm.test_run_id
        WHERE LOWER(tr.browser_name) = LOWER(?)
        """

        cursor = conn.cursor()
        cursor.execute(query, (browser,))
        row = cursor.fetchone()
        conn.close()

        if row:
            from src.monitoring.privacy_security_monitor import PrivacySecurityMonitor
            monitor = PrivacySecurityMonitor()
            avg_metrics = {
                'https_enabled': bool(round(row[5] or 1)),
                'third_party_cookies': row[6] or 0,
                'tracker_count': row[7] or 0,
                'mixed_content': row[8] or 0,
                'cookie_count': row[9] or 1,
                'secure_cookies': row[10] or 0,
            }
            return {
                'tests': row[0] or 0,
                'energy': row[1] or 0,
                'cpu': row[2] or 0,
                'memory': row[3] or 0,
                'page_load': row[4] or 0,
                'privacy': monitor.calculate_privacy_score(avg_metrics),
                'security': monitor.calculate_security_score(avg_metrics),
            }
        return {}

    def compare_ai_impact(self) -> Dict:
        """Compare AI vs non-AI searches"""
        conn = self.get_connection()
        
        query = """
        SELECT 
            tr.ai_enabled,
            AVG(ec.estimated_energy_wh) as avg_energy,
            COUNT(*) as tests
        FROM test_runs tr
        JOIN energy_calculations ec ON tr.id = ec.test_run_id
        GROUP BY tr.ai_enabled
        """
        
        cursor = conn.cursor()
        cursor.execute(query)
        
        data = {'ai': {}, 'non_ai': {}}
        for row in cursor.fetchall():
            if row[0]:  # ai_enabled = 1
                data['ai'] = {'energy': row[1] or 0, 'tests': row[2] or 0}
            else:
                data['non_ai'] = {'energy': row[1] or 0, 'tests': row[2] or 0}
        
        if data['ai'] and data['non_ai'] and data['non_ai']['energy'] > 0:
            data['multiplier'] = data['ai']['energy'] / data['non_ai']['energy']
        
        conn.close()
        return data

    def generate_report(self, output_path: str, include_charts: bool = False):
        """Generate markdown report"""
        report = self.generate_summary_report()
        
        with open(output_path, 'w') as f:
            f.write("# SafeWeb Analysis Report\n\n")
            f.write(f"Generated: {report['timestamp']}\n\n")
            
            f.write("## Overall Statistics\n\n")
            stats = report['overall_statistics']
            f.write(f"- Total Tests: {stats['total_successful_tests']}\n")
            f.write(f"- Success Rate: {stats['success_rate']:.1f}%\n")
            f.write(f"- Browsers Tested: {stats['unique_browsers_tested']}\n")
            f.write(f"- Search Engines: {stats['unique_search_engines_tested']}\n\n")
            
            f.write("## Browser Performance\n\n")
            for browser, perf in report['browser_performance'].items():
                f.write(f"### {browser.title()}\n")
                f.write(f"- Energy: {perf['estimated_energy_wh']['mean']:.3f} Wh\n")
                f.write(f"- CPU: {perf['cpu_percent']['mean']:.1f}%\n")
                f.write(f"- Memory: {perf['memory_percent']['mean']:.1f}%\n\n")
        
        self.logger.info(f"Report generated: {output_path}")

def main():
    """Test the StatisticalAnalyzer module"""
    analyzer = StatisticalAnalyzer()
    
    print("📊 SAFE-Web Statistical Analysis")
    
    # Generate summary report
    report = analyzer.generate_summary_report()
    
    print(f"Overall Statistics:")
    print(f"  Successful Tests: {report['overall_statistics']['total_successful_tests']}")
    print(f"  Failed Tests: {report['overall_statistics']['total_failed_tests']}")
    print(f"  Success Rate: {report['overall_statistics']['success_rate']:.1f}%")
    
    # Show browser performance table
    duration_table = analyzer.export_statistics_table('duration')
    print(f"\nDuration Statistics by Browser:")
    print(duration_table.to_string(index=False))

if __name__ == "__main__":
    main()