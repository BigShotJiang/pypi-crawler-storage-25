"""SafeWeb CLI Tool Setup"""
from setuptools import setup, find_packages

with open("README.md", "r") as f:
    long_description = f.read()

setup(
    name="safeweb",
    version="1.0.2",
    description="Browser safety and sustainability testing tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="SafeWeb Project",
    python_requires=">=3.8",
    packages=find_packages(),
    py_modules=["safeweb", "config"],
    package_data={"": ["results/database/.gitkeep", "results/exports/.gitkeep",
                       "results/reports/.gitkeep", "results/logs/.gitkeep"]},
    install_requires=[
        "selenium>=4.15.2",
        "webdriver-manager>=4.0.1",
        "psutil>=5.9.6",
        "pandas>=2.1.4",
        "numpy>=1.25.2",
        "matplotlib>=3.8.2",
        "seaborn>=0.13.0",
        "pyyaml>=6.0.1",
        "requests>=2.31.0",
    ],
    entry_points={
        'console_scripts': [
            'safeweb=safeweb:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: MacOS",
    ],
)
