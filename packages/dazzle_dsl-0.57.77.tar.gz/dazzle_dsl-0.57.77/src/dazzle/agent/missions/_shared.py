"""
Shared utilities for discovery missions.

Contains helpers used across discovery, entity_completeness, and
workflow_coherence missions to avoid cross-module private-function
imports and code duplication.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..core import AgentTool

if TYPE_CHECKING:
    from dazzle.core.ir.appspec import AppSpec
from ..models import ActionType, AgentAction, Step

logger = logging.getLogger("dazzle.agent.missions")


# =============================================================================
# IR Access Helpers
# =============================================================================


def get_surface_entity(surface: Any) -> str | None:
    """Get the entity reference from a surface, handling both IR and test mocks."""
    return surface.entity_ref or getattr(surface, "entity", None)


def is_step_kind(step: Any, kind_name: str) -> bool:
    """
    Check if a process step matches a given kind name.

    Handles both StrEnum values (StepKind.HUMAN_TASK) and plain strings
    ("human_task") as used in test mocks.
    """
    kind = getattr(step, "kind", None)
    if kind is None:
        return False
    kind_str = str(kind)
    return kind_str == kind_name or kind_str == f"StepKind.{kind_name.upper()}"


def is_trigger_kind(trigger: Any, kind_name: str) -> bool:
    """
    Check if a process trigger matches a given kind name.

    Handles both StrEnum values and plain strings.
    """
    trigger_kind = getattr(trigger, "kind", None)
    if trigger_kind is None:
        return False
    kind_str = str(trigger_kind)
    return kind_str == kind_name or kind_str == f"ProcessTriggerKind.{kind_name.upper()}"


# =============================================================================
# Completion Criteria Factory
# =============================================================================


def make_stagnation_completion(
    window: int,
    label: str = "mission",
) -> Any:
    """
    Create a completion function that triggers on DONE or stagnation.

    Args:
        window: Number of consecutive steps without tool calls before stopping
        label: Label for log messages
    """

    def completion(action: AgentAction, history: list[Step]) -> bool:
        if action.type == ActionType.DONE:
            return True
        if len(history) >= window:
            recent = history[-window:]
            tool_calls = sum(1 for s in recent if s.action.type == ActionType.TOOL)
            if tool_calls == 0:
                logger.info("%s stagnation: no tool calls in last %s steps", label, window)
                return True
        return False

    return completion


# =============================================================================
# DSL Summary Builder
# =============================================================================


def build_dsl_summary(appspec: AppSpec) -> str:
    """
    Build a compact DSL summary for system prompts.

    Targets ~2-4k tokens. Gives the agent enough context to recognize
    what should exist without overwhelming it.
    """
    lines: list[str] = []

    # Entities with key fields
    lines.append("### Entities")
    entities = appspec.domain.entities if hasattr(appspec.domain, "entities") else []
    for entity in entities:
        field_names = [f.name for f in entity.fields][:8]
        lines.append(f"- **{entity.name}** ({entity.title}): {', '.join(field_names)}")
        sm = entity.state_machine
        if sm and sm.states:
            state_names = [s if isinstance(s, str) else s.name for s in sm.states][:6]
            lines.append(f"  States: {' → '.join(state_names)}")

    # Surfaces with mode and entity
    lines.append("\n### Surfaces")
    for surface in appspec.surfaces[:40]:
        entity_ref = get_surface_entity(surface) or ""
        if entity_ref:
            entity_ref = f" → {entity_ref}"
        lines.append(
            f"- **{surface.name}** ({surface.mode}{entity_ref}): {surface.title or surface.name}"
        )

    # Workspaces
    if appspec.workspaces:
        lines.append("\n### Workspaces")
        for ws in appspec.workspaces[:15]:
            region_names = [r.name for r in ws.regions][:5]
            lines.append(f"- **{ws.name}**: regions=[{', '.join(region_names)}]")

    # Personas
    if appspec.personas:
        lines.append("\n### Personas")
        for p in appspec.personas[:10]:
            p_name = getattr(p, "name", None) or p.id
            desc = (p.description or "")[:60]
            lines.append(f"- **{p_name}**: {desc}")

    # Processes
    if appspec.processes:
        lines.append("\n### Processes")
        for proc in appspec.processes[:10]:
            step_count = len(proc.steps)
            lines.append(f"- **{proc.name}**: {step_count} steps")

    # Experiences
    if appspec.experiences:
        lines.append("\n### Experiences")
        for exp in appspec.experiences[:10]:
            step_count = len(exp.steps)
            lines.append(f"- **{exp.name}** ({exp.title or exp.name}): {step_count} steps")

    return "\n".join(lines)


# =============================================================================
# Shared Mission Tools
# =============================================================================


def make_observe_gap_tool(kg_store: Any | None) -> AgentTool:
    """
    Tool: observe_gap — record a capability gap.

    Returns an Observation dict that the agent core will add to the transcript.
    """

    def observe_gap(
        category: str = "gap",
        severity: str = "medium",
        title: str = "",
        description: str = "",
        location: str = "",
        related_entities: list[str] | None = None,
    ) -> dict[str, Any]:
        valid_severities = {"critical", "high", "medium", "low", "info"}
        if severity not in valid_severities:
            severity = "medium"

        valid_categories = {
            "missing_crud",
            "workflow_gap",
            "navigation_gap",
            "ux_issue",
            "access_gap",
            "data_gap",
            "gap",
        }
        if category not in valid_categories:
            category = "gap"

        obs: dict[str, Any] = {
            "category": category,
            "severity": severity,
            "title": title,
            "description": description,
            "location": location,
            "related_artefacts": related_entities or [],
        }

        if kg_store and related_entities:
            adjacency_notes: list[str] = []
            for entity_id in related_entities[:3]:
                if ":" not in entity_id:
                    entity_id = f"entity:{entity_id}"
                ent = kg_store.get_entity(entity_id)
                if ent:
                    adjacency_notes.append(f"{entity_id} exists in KG")
                else:
                    adjacency_notes.append(f"{entity_id} NOT in KG")
            obs["metadata"] = {"adjacency": adjacency_notes}

        return {"observation": obs, "recorded": True}

    return AgentTool(
        name="observe_gap",
        description=(
            "Record a capability gap or finding. Categories: missing_crud, workflow_gap, "
            "navigation_gap, ux_issue, access_gap, data_gap, gap. "
            "Severities: critical, high, medium, low, info."
        ),
        schema={
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "enum": [
                        "missing_crud",
                        "workflow_gap",
                        "navigation_gap",
                        "ux_issue",
                        "access_gap",
                        "data_gap",
                        "gap",
                    ],
                },
                "severity": {
                    "type": "string",
                    "enum": ["critical", "high", "medium", "low", "info"],
                },
                "title": {"type": "string", "description": "Short title for the gap"},
                "description": {
                    "type": "string",
                    "description": "What's missing and why it matters",
                },
                "location": {
                    "type": "string",
                    "description": "URL or surface name where observed",
                },
                "related_entities": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "DSL entity/surface names related to this gap",
                },
            },
            "required": ["title", "description"],
        },
        handler=observe_gap,
    )


def make_query_dsl_tool(appspec: AppSpec) -> AgentTool:
    """
    Tool: query_dsl — ask about DSL definitions on-demand.

    Lazy context loading: the agent can pull in more DSL detail as needed
    without it all being in the system prompt.
    """

    def query_dsl(
        entity_name: str | None = None,
        surface_name: str | None = None,
        query_type: str = "fields",
    ) -> dict[str, Any]:
        if entity_name:
            for entity in appspec.domain.entities:
                if entity.name == entity_name:
                    result: dict[str, Any] = {
                        "name": entity.name,
                        "title": entity.title,
                        "fields": [],
                    }
                    for f in entity.fields:
                        field_info: dict[str, str] = {"name": f.name, "type": str(f.type)}
                        if hasattr(f, "constraints"):
                            field_info["constraints"] = str(f.constraints)
                        result["fields"].append(field_info)
                    sm = entity.state_machine
                    if sm and sm.states:
                        result["states"] = [s if isinstance(s, str) else s.name for s in sm.states]
                        result["transitions"] = [
                            {"from": t.from_state, "to": t.to_state, "event": t.event}
                            for t in sm.transitions
                        ]
                    return result
            return {"error": f"Entity '{entity_name}' not found"}

        if surface_name:
            for surface in appspec.surfaces:
                if surface.name == surface_name:
                    result = {
                        "name": surface.name,
                        "title": surface.title,
                        "mode": surface.mode,
                        "entity": get_surface_entity(surface),
                    }
                    sections = surface.sections
                    if sections:
                        result["sections"] = []
                        for sec in sections:
                            sec_info: dict[str, Any] = {"name": sec.name}
                            fields = getattr(sec, "fields", [])
                            sec_info["fields"] = [f.name for f in fields][:10]
                            result["sections"].append(sec_info)
                    return result
            return {"error": f"Surface '{surface_name}' not found"}

        return {"error": "Provide entity_name or surface_name"}

    return AgentTool(
        name="query_dsl",
        description=(
            "Look up DSL definition details for an entity or surface. "
            "Use this to get field lists, state machines, surface sections, etc."
        ),
        schema={
            "type": "object",
            "properties": {
                "entity_name": {
                    "type": "string",
                    "description": "Entity name to look up",
                },
                "surface_name": {
                    "type": "string",
                    "description": "Surface name to look up",
                },
                "query_type": {
                    "type": "string",
                    "enum": ["fields", "states", "sections"],
                    "description": "What aspect to query",
                },
            },
        },
        handler=query_dsl,
    )


# =============================================================================
# Component Contract Parser (for /ux-cycle)
# =============================================================================


@dataclass
class QualityGate:
    """A single testable behaviour from a ux-architect component contract."""

    id: str  # snake_case identifier derived from description, e.g. "drag_threshold"
    description: str  # the full gate text from the contract


@dataclass
class ComponentContract:
    """Parsed structure of a ux-architect component contract markdown file."""

    component_name: str
    quality_gates: list[QualityGate]
    anatomy: list[str] = field(default_factory=list)
    primitives: list[str] = field(default_factory=list)
    anchor: str | None = None


def _derive_gate_id(description: str) -> str:
    """Derive a snake_case id from a gate description.

    Takes the parenthesised label if present, otherwise the first few
    meaningful words. Always lowercase, always a valid identifier.
    """
    # Prefer parenthesised label: "... (drag threshold)" → "drag_threshold"
    paren_match = re.search(r"\(([^)]+)\)", description)
    if paren_match:
        label = paren_match.group(1).strip()
    else:
        # Fall back to first 3 meaningful words
        words = re.findall(r"[A-Za-z]+", description)[:3]
        label = " ".join(words)

    # Normalise to snake_case
    label = label.lower()
    label = re.sub(r"[^a-z0-9]+", "_", label)
    label = label.strip("_")
    return label or "unnamed_gate"


def _extract_section(content: str, heading: str) -> str | None:
    """Extract the text of a ## heading section from markdown content.

    Returns everything after the `## heading` line until the next `## ` heading
    or end of file. Returns None if the heading is not found.
    """
    # Match "## Heading" or "## Heading (optional suffix)"
    pattern = rf"^## {re.escape(heading)}.*?\n(.*?)(?=\n## |\Z)"
    match = re.search(pattern, content, re.MULTILINE | re.DOTALL)
    return match.group(1) if match else None


def _parse_numbered_list(section_text: str) -> list[str]:
    """Parse a numbered list from a markdown section, returning raw item text.

    Handles items that span multiple lines (continues until next number or blank line).
    """
    items: list[str] = []
    current: list[str] = []

    for line in section_text.splitlines():
        # Match "1. text" or "2. text"
        numbered_match = re.match(r"^\d+\.\s+(.+)", line)
        if numbered_match:
            if current:
                items.append(" ".join(current).strip())
                current = []
            current.append(numbered_match.group(1))
        elif current and line.strip() and not line.startswith("#"):
            # Continuation of previous item
            current.append(line.strip())
        elif not line.strip() and current:
            # Blank line ends the current item
            items.append(" ".join(current).strip())
            current = []

    if current:
        items.append(" ".join(current).strip())

    return items


def _parse_bullet_list(section_text: str) -> list[str]:
    """Parse a bullet list, extracting the first `backtick token` from each item.

    Used for anatomy (`- \\`grid-root\\` — container`) and primitives
    (`- \\`drag-and-drop\\``).
    """
    items: list[str] = []
    for line in section_text.splitlines():
        line = line.strip()
        if not line.startswith("-"):
            continue
        # Extract first `token` if present
        token_match = re.search(r"`([^`]+)`", line)
        if token_match:
            items.append(token_match.group(1))
    return items


def parse_component_contract(path: Path) -> ComponentContract:
    """Parse a ux-architect component contract markdown file.

    Extracts:
    - Component name (from filename without extension)
    - Quality gates (from ``## Quality Gates`` numbered list)
    - Anatomy parts (from ``## Anatomy`` bullet list)
    - Interaction primitives (from ``## Primitives invoked`` bullet list)

    Raises:
        FileNotFoundError: if the file does not exist
        ValueError: if the file does not contain a Quality Gates section
    """
    if not path.exists():
        raise FileNotFoundError(f"Component contract not found: {path}")

    content = path.read_text()
    component_name = path.stem

    # Quality Gates (required)
    gates_section = _extract_section(content, "Quality Gates")
    if gates_section is None:
        raise ValueError(f"Contract at {path} has no '## Quality Gates' section")
    gate_descriptions = _parse_numbered_list(gates_section)
    if not gate_descriptions:
        raise ValueError(f"Contract at {path} has a Quality Gates section but no numbered items")

    # Disambiguate duplicate ids by appending an index
    quality_gates: list[QualityGate] = []
    seen_ids: dict[str, int] = {}
    for desc in gate_descriptions:
        base_id = _derive_gate_id(desc)
        count = seen_ids.get(base_id, 0)
        seen_ids[base_id] = count + 1
        gate_id = base_id if count == 0 else f"{base_id}_{count + 1}"
        quality_gates.append(QualityGate(id=gate_id, description=desc))

    # Anatomy (optional)
    anatomy: list[str] = []
    anatomy_section = _extract_section(content, "Anatomy")
    if anatomy_section:
        anatomy = _parse_bullet_list(anatomy_section)

    # Primitives (optional — may be labelled "Primitives invoked" or just in a
    # bullet under a different heading, or as a front-matter bold line like
    # "**Primitives invoked:** Drag-and-drop, Resize")
    primitives: list[str] = []
    primitives_section = _extract_section(content, "Primitives invoked")
    if primitives_section:
        primitives = _parse_bullet_list(primitives_section)
    if not primitives:
        # Fall back to front-matter inline form: **Primitives invoked:** val1, val2
        fm_match = re.search(r"\*\*Primitives invoked:\*\*\s*(.+)", content, re.IGNORECASE)
        if fm_match:
            primitives = [p.strip() for p in fm_match.group(1).split(",") if p.strip()]

    # Anchor (optional) — v1.0.3. URL to navigate to before the contract
    # walker observes the component. When absent, the walker falls back to
    # observing whatever page is currently loaded (v1.0.2 behaviour).
    anchor: str | None = None
    anchor_section = _extract_section(content, "Anchor")
    if anchor_section:
        for line in anchor_section.splitlines():
            stripped = line.strip()
            if stripped:
                anchor = stripped
                break

    return ComponentContract(
        component_name=component_name,
        quality_gates=quality_gates,
        anatomy=anatomy,
        primitives=primitives,
        anchor=anchor,
    )
