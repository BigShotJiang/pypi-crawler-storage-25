# Process Notes

Searchable session log. Not loaded routinely—search with grep when needed.

---

## 2025-12-31

**Goal**: Fix bug where `instructions_prompt.md` failed to load when package installed via `uvx`/`pip`

**Done**:
- Moved `instructions_prompt.md` from project root into `src/mcp_dblp/`
- Changed server.py to use `importlib.resources` instead of `__file__` path lookup
- Updated test to use `importlib.resources`
- Ran code review (ULTRA), fixed linter issues, removed useless no-op test
- Released v1.2.1 to PyPI and GitHub

**Tried**:
- Original code used `Path(__file__).resolve().parents[2]` — worked in dev but failed when installed

**Notes**: `importlib.resources.files()` is the standard Python 3.9+ way to access package data files

---
