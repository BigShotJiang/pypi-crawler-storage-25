---
keywords: testing, metaclaude, mcp server, inner claude, tmux
context: how to test the mcp-dblp server end-to-end using an inner Claude session
added: 2026-04-04
---

# Testing mcp-dblp with /metaclaude

## Setup

The inner Claude needs `--mcp-config` with `--strict-mcp-config` to use only the local dev server (not PyPI version).

1. Write MCP config to temp file:
```json
{
  "mcpServers": {
    "mcp-dblp": {
      "command": "uv",
      "args": ["--directory", "/Users/szeider/git/mcp-dblp/", "run", "mcp-dblp"]
    }
  }
}
```

2. Launch inner Claude:
```bash
tmux new-session -d -s inner -x 200 -y 50
tmux send-keys -t inner "claude --dangerously-skip-permissions --model sonnet --mcp-config /tmp/mcp-dblp-test-config.json --strict-mcp-config" Enter
```

Key flags:
- `--mcp-config /tmp/mcp-dblp-test-config.json` — loads local MCP server
- `--strict-mcp-config` — ignores all other MCP configs (global, project)
- `--model sonnet` — cheaper for testing

## Important

- Do NOT modify project `.claude/settings.local.json` just for testing — use `--mcp-config` on the CLI instead
- The `--directory` flag in the MCP config ensures `uv run` uses the local source, not PyPI
- Write test instructions to a file, send via `inner_send.sh`

## Test plan template

Have inner Claude test: search → add_bibtex_entry → set_dblp_mirror → add again → export → verify file.
Inner writes results to `/tmp/mcp-dblp-test-results.md` for outer to read.
