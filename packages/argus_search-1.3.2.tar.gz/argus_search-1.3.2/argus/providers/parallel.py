"""
Parallel Web Systems search provider.

API: https://api.parallel.ai/v1beta/search
Proprietary index with token-dense excerpts.
"""

import time
from typing import List, Tuple

import httpx

from argus.config import ProviderConfig
from argus.logging import get_logger
from argus.models import (
    ProviderName,
    ProviderStatus,
    ProviderTrace,
    SearchResult,
    SearchQuery,
)
from argus.providers.base import BaseProvider

logger = get_logger("providers.parallel")

PARALLEL_API_BASE = "https://api.parallel.ai/v1beta/search"


class ParallelProvider(BaseProvider):
    def __init__(self, config: ProviderConfig):
        self._config = config

    @property
    def name(self) -> ProviderName:
        return ProviderName.PARALLEL

    def is_available(self) -> bool:
        return self._config.enabled and bool(self._config.api_key)

    def status(self) -> ProviderStatus:
        if not self._config.enabled:
            return ProviderStatus.DISABLED_BY_CONFIG
        if not self._config.api_key:
            return ProviderStatus.UNAVAILABLE_MISSING_KEY
        return ProviderStatus.ENABLED

    async def search(self, query: SearchQuery) -> Tuple[List[SearchResult], ProviderTrace]:
        start = time.monotonic()

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self._config.api_key,
            "parallel-beta": "search-extract-2025-10-10",
        }
        body = {
            "objective": query.query,
            "search_queries": [query.query],
            "max_results": query.max_results,
        }

        try:
            async with httpx.AsyncClient(timeout=self._config.timeout_seconds) as client:
                resp = await client.post(PARALLEL_API_BASE, json=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()

            raw_results = data.get("results", [])
            results = self._normalize(raw_results)
            latency_ms = int((time.monotonic() - start) * 1000)

            credit_info = {}
            for hdr in ("X-RateLimit-Remaining-Requests", "X-RateLimit-Limit-Requests", "RateLimit-Remaining"):
                if hdr in resp.headers:
                    credit_info[hdr] = resp.headers[hdr]

            trace = ProviderTrace(
                provider=self.name,
                status="success",
                results_count=len(results),
                latency_ms=latency_ms,
                credit_info=credit_info or None,
            )
            return results, trace

        except Exception as e:
            latency_ms = int((time.monotonic() - start) * 1000)
            logger.warning("Parallel search failed: %s", e)
            trace = ProviderTrace(
                provider=self.name,
                status="error",
                latency_ms=latency_ms,
                error=str(e),
            )
            return [], trace

    def _normalize(self, raw_results: list) -> List[SearchResult]:
        results = []
        for i, item in enumerate(raw_results):
            url = item.get("url") or ""
            if not url:
                continue
            results.append(SearchResult(
                url=url,
                title=item.get("title", ""),
                snippet=item.get("excerpt", "") or item.get("snippet", ""),
                domain=self._extract_domain(url),
                provider=self.name,
                score=0.0,
                raw_rank=i,
            ))
        return results

    @staticmethod
    def _extract_domain(url: str) -> str:
        try:
            from urllib.parse import urlparse
            return urlparse(url).netloc
        except Exception:
            return ""
