from setuptools import setup, find_packages

setup(
    name="DAV_prac",
    version="1.0.0",
    author="Jyotirmoy Dutta",
    description="DAV Laboratory practical codes - Sem 6",
    packages=find_packages(),
    python_requires=">=3.7",
)
