# Copyright (C) 2025, 2026  Marcel Hellkamp
# SPDX-License-Identifier: AGPL-3.0-or-later

import logging
import os
from pathlib import Path
import lxml.etree
import pytest
import pytest_asyncio
import bbblb.model
import bbblb.settings
import bbblb.services
import bbblb.services.db
import bbblb.web

from starlette.testclient import TestClient

ENV_TEST_DB = "TEST_DB"
ENV_TEST_BBB = "TEST_BBB"


def get_testdata(*names) -> Path:
    datadir = Path(__file__).resolve().parent / "testdata"
    target = datadir.joinpath(*names).resolve()
    if not target.exists():
        pytest.skip(f"Test requires test data in {target}")
    return target


@pytest.fixture(scope="session")
def db_url(tmp_path_factory):
    db = os.environ.get(ENV_TEST_DB, None)
    if not db:
        # We cannot use in-memopry DBs because migrations create their
        # own short-lived engine.
        db = f"sqlite:///{tmp_path_factory.mktemp('db') / 'test.db'}"
    yield db


@pytest.fixture(scope="function")
def config(db_url, tmp_path):
    cfg = bbblb.settings.BBBLBConfig()
    cfg.set(
        DB=db_url,
        DEBUG=True,
        SECRET="1234",
        DOMAIN="localhost",
        PATH_DATA=tmp_path,
    )
    yield cfg


@pytest_asyncio.fixture(scope="function")
async def services(config: bbblb.settings.BBBLBConfig):
    services = await bbblb.services.bootstrap(config)
    async with services:
        yield services


@pytest_asyncio.fixture(scope="function")
async def db(services: bbblb.services.ServiceRegistry):
    db = await services.use(bbblb.services.db.DBContext)
    for table in reversed(bbblb.model.Base.metadata.sorted_tables):
        async with db.session() as session, session.begin():
            await session.execute(table.delete())

    # Enable SQL logging for all tests that do something with the DB
    logging.getLogger("sqlalchemy.engine").setLevel(logging.INFO)

    yield db


@pytest_asyncio.fixture(scope="function")
async def orm(db: bbblb.services.db.DBContext):
    async with db.session() as session:
        yield session


@pytest_asyncio.fixture(scope="function")
async def test_tenant(orm: bbblb.model.AsyncSession):
    tenant = bbblb.model.Tenant(name="test", realm="bbb.example.com", secret="test")
    orm.add(tenant)
    await orm.commit()
    return tenant


class BBBTestClient(TestClient):
    def bbb_api_request(self, tenant: bbblb.model.Tenant, action: str, **query):
        import bbblb.lib.bbb

        url = f"/bigbluebutton/api/{action}"
        url += "?" + bbblb.lib.bbb.sign_query(action, query, tenant.secret)
        rs = self.get(url=url, headers={"Host": tenant.realm})
        return rs

    def bbb_api_request_xml(self, tenant: bbblb.model.Tenant, action: str, **query):
        rs = self.bbb_api_request(tenant, action, **query)
        assert "xml" in rs.headers["content-type"]
        xml = lxml.etree.fromstring(rs.content)
        assert xml.findtext("returncode") == "SUCCESS"
        return rs, xml


@pytest.fixture(scope="function")
def client(config: bbblb.settings.BBBLBConfig):
    app = bbblb.web.make_app(config, autostart=False)
    with BBBTestClient(app, base_url=f"http://{config.DOMAIN}") as client:
        yield client


@pytest_asyncio.fixture(scope="function")
async def bbb_server(db: bbblb.services.db.DBContext):
    """Register an external BBB test server if available, or skip tests
    depending on it."""
    domain = os.environ.get(ENV_TEST_BBB)
    if not domain:
        pytest.skip(f"Test requires {ENV_TEST_BBB} environment variable.")
        return
    domain, _, secret = domain.rpartition(":")
    if not domain or not secret:
        pytest.fail(f"Invalid {ENV_TEST_BBB} environment variable.")

    async with db.begin() as tx:
        server = bbblb.model.Server(
            domain=domain, secret=secret, health=bbblb.model.ServerHealth.AVAILABLE
        )
        tx.session.add(server)
    yield server
