# Changelog

All notable changes to `karon-mcp` will be documented in this file.

## [1.0.0] - 2026-04-08

### Added
- `browse` tool — Fetch any URL bypassing WAFs (Cloudflare, DataDome, Kasada, Akamai, PerimeterX). Returns markdown, text, or raw HTML.
- `crawl` tool — Fetch up to 20 URLs concurrently with configurable parallelism (1-5).
- SSRF protection — Blocks requests to internal networks (RFC 1918, loopback, link-local, IPv4-mapped IPv6).
- DNS rebinding protection — Resolves hostnames and validates against blocked ranges.
- Response size limits — 10 MB max response, 200K content truncation.
- Global concurrency semaphore — Max 5 concurrent requests to protect upstream API.
- Singleton HTTP client with connection pooling.
- Control character escaping in all output strings.
