### THIS FILE WAS AUTO-GENERATED ###
from __future__ import annotations

from xml.etree import ElementTree as ET

from typing import List

from ..utils.model import BaseModel
from ..utils.errors import SDFError
from ..utils.pose import Pose as _SDFPose
from ..utils.version import cmp_version
from ..utils.migration import apply_migrations

from .frame import Frame
from .joint import Joint
from .link import Link
from .plugin import Plugin
from .pose import Pose


import math

def _parse_int32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (-2147483648 <= v <= 2147483647):
            return SDFError(f"int32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid int32: {raw}")


def _parse_uint32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (0 <= v <= 4294967295):
            return SDFError(f"uint32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid uint32: {raw}")


def _parse_double(raw: str) -> float | SDFError:
    try:
        v = float(raw)
        if not math.isfinite(v) or abs(v) > math.inf:
            return SDFError(f"double out of range: {raw}")
        return v
    except ValueError:
        return SDFError(f"Invalid double: {raw}")



class Actor(BaseModel):
    def __init__(
        self,
        sdf_version: str,
        animation: List["Animation"] = None,
        frame: List["Frame"] = None,
        joint: List["Joint"] = None,
        link: List["Link"] = None,
        name: str = "__default__",
        origin: "Origin" = None,
        plugin: List["Plugin"] = None,
        pose: "Pose" = None,
        script: "Script" = None,
        skin: "Skin" = None,
        static: bool = False
    ):
        self.__version__ = sdf_version
        self.animation = animation or []
        self.frame = frame or []
        self.joint = joint or []
        self.link = link or []
        self.name = name
        self.origin = origin
        self.plugin = plugin or []
        self.pose = pose
        self.script = script
        self.skin = skin
        self.static = static

    def to_version(self, target_version: str) -> "Actor":
        if self.frame is not None and cmp_version(target_version, "1.5") < 0:
            raise ValueError(f"'frame' is not supported in SDF version {target_version} (added in 1.5)")
        if self.frame is not None and cmp_version(target_version, "1.7") >= 0:
            raise ValueError(f"'frame' is not supported in SDF version {target_version} (removed in 1.7)")
        if self.origin is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'origin' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.pose is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'pose' is not supported in SDF version {target_version} (added in 1.2)")
        if self.static is not None and cmp_version(target_version, "1.5") >= 0:
            raise ValueError(f"'static' is not supported in SDF version {target_version} (removed in 1.5)")
        kwargs = {"sdf_version": target_version}
        kwargs["animation"] = [c.to_version(target_version) for c in (self.animation or [])]
        kwargs["frame"] = [c.to_version(target_version) for c in (self.frame or [])]
        kwargs["joint"] = [c.to_version(target_version) for c in (self.joint or [])]
        kwargs["link"] = [c.to_version(target_version) for c in (self.link or [])]
        kwargs["name"] = self.name
        kwargs["origin"] = self.origin.to_version(target_version) if self.origin is not None else None
        kwargs["plugin"] = [c.to_version(target_version) for c in (self.plugin or [])]
        kwargs["pose"] = self.pose.to_version(target_version) if self.pose is not None else None
        kwargs["script"] = self.script.to_version(target_version) if self.script is not None else None
        kwargs["skin"] = self.skin.to_version(target_version) if self.skin is not None else None
        kwargs["static"] = self.static
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("actor")
        for item in (self.animation or []):
            el.append(item.to_sdf(version))
        for item in (self.frame or []):
            el.append(item.to_sdf(version))
        for item in (self.joint or []):
            el.append(item.to_sdf(version))
        for item in (self.link or []):
            el.append(item.to_sdf(version))
        if self.name is not None:
            el.set("name", self.name)
        if self.origin is not None:
            el.append(self.origin.to_sdf(version))
        for item in (self.plugin or []):
            el.append(item.to_sdf(version))
        if self.pose is not None:
            el.append(self.pose.to_sdf(version))
        if self.script is None:
            self.script = Script(sdf_version=version)
        if self.script is not None:
            el.append(self.script.to_sdf(version))
        if self.skin is not None:
            el.append(self.skin.to_sdf(version))
        if self.static is not None:
            el.set("static", str(self.static).lower())
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _animation = []
        for c in el.findall("animation"):
            _res = Animation._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("animation")
            _animation.append(_res)
        _frame = []
        for c in el.findall("frame"):
            _res = Frame._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("frame")
            _frame.append(_res)
        if _frame and cmp_version(version, "1.5") < 0:
            return SDFError(f"'frame' is not supported in SDF version {version} (added in 1.5)")
        _joint = []
        for c in el.findall("joint"):
            _res = Joint._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("joint")
            _joint.append(_res)
        _link = []
        for c in el.findall("link"):
            _res = Link._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("link")
            _link.append(_res)
        _name = el.get("name", "__default__")
        if isinstance(_name, SDFError):
            return _name.extend("@name")
        _c_origin = el.find("origin")
        if _c_origin is not None:
            _res = Origin._from_sdf(_c_origin, version)
            if isinstance(_res, SDFError):
                return _res.extend("origin")
            _origin = _res
        else:
            _origin = None
        _plugin = []
        for c in el.findall("plugin"):
            _res = Plugin._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("plugin")
            _plugin.append(_res)
        _c_pose = el.find("pose")
        if _c_pose is not None:
            _res = Pose._from_sdf(_c_pose, version)
            if isinstance(_res, SDFError):
                return _res.extend("pose")
            _pose = _res
        else:
            _pose = None
        if _pose is not None and cmp_version(version, "1.2") < 0:
            return SDFError(f"'pose' is not supported in SDF version {version} (added in 1.2)")
        _c_script = el.find("script")
        if _c_script is not None:
            _res = Script._from_sdf(_c_script, version)
            if isinstance(_res, SDFError):
                return _res.extend("script")
            _script = _res
        else:
            _res = Script._from_sdf(ET.Element("script"), version)
            if isinstance(_res, SDFError):
                return _res.extend("script")
            _script = _res
        _c_skin = el.find("skin")
        if _c_skin is not None:
            _res = Skin._from_sdf(_c_skin, version)
            if isinstance(_res, SDFError):
                return _res.extend("skin")
            _skin = _res
        else:
            _skin = None
        _static = str(el.get("static", False)).strip().lower() == 'true'
        if isinstance(_static, SDFError):
            return _static.extend("@static")
        return cls(sdf_version=version, animation=_animation, frame=_frame, joint=_joint, link=_link, name=_name, origin=_origin, plugin=_plugin, pose=_pose, script=_script, skin=_skin, static=_static)


class Animation(BaseModel):
    def __init__(
        self,
        sdf_version: str,
        filename: str = "__default__",
        interpolate_x: bool = False,
        name: str = "__default__",
        scale: float = 1.0
    ):
        self.__version__ = sdf_version
        self.filename = filename
        self.interpolate_x = interpolate_x
        self.name = name
        self.scale = scale

    def to_version(self, target_version: str) -> "Animation":
        if self.filename is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'filename' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.interpolate_x is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'interpolate_x' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.scale is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'scale' is not supported in SDF version {target_version} (removed in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["filename"] = self.filename
        kwargs["interpolate_x"] = self.interpolate_x
        kwargs["name"] = self.name
        kwargs["scale"] = self.scale
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("animation")
        if self.filename is not None:
            el.set("filename", self.filename)
        if self.interpolate_x is not None:
            el.set("interpolate_x", str(self.interpolate_x).lower())
        if self.name is not None:
            el.set("name", self.name)
        if self.scale is not None:
            el.set("scale", str(self.scale))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _filename = el.get("filename", "__default__")
        if isinstance(_filename, SDFError):
            return _filename.extend("@filename")
        _interpolate_x = str(el.get("interpolate_x", False)).strip().lower() == 'true'
        if isinstance(_interpolate_x, SDFError):
            return _interpolate_x.extend("@interpolate_x")
        _name = el.get("name", "__default__")
        if isinstance(_name, SDFError):
            return _name.extend("@name")
        _scale = _parse_double(el.get("scale", 1.0))
        if isinstance(_scale, SDFError):
            return _scale.extend("@scale")
        return cls(sdf_version=version, filename=_filename, interpolate_x=_interpolate_x, name=_name, scale=_scale)


class AutoStart(BaseModel):
    def __init__(self, sdf_version: str, auto_start: bool = True):
        self.__version__ = sdf_version
        self.auto_start = auto_start

    def to_version(self, target_version: str) -> "AutoStart":
        if self.auto_start is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'auto_start' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["auto_start"] = self.auto_start
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("auto_start")
        if self.auto_start is not None:
            el.text = str(self.auto_start).lower()
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or True
        _auto_start = str(_text).strip().lower() == 'true'
        if isinstance(_auto_start, SDFError):
            return _auto_start
        if _auto_start is not None and cmp_version(version, "1.2") < 0:
            if _auto_start != True:
                return SDFError(f"'auto_start' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, auto_start=_auto_start)


class DelayStart(BaseModel):
    def __init__(self, sdf_version: str, delay_start: float = 0.0):
        self.__version__ = sdf_version
        self.delay_start = delay_start

    def to_version(self, target_version: str) -> "DelayStart":
        if self.delay_start is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'delay_start' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["delay_start"] = self.delay_start
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("delay_start")
        if self.delay_start is not None:
            el.text = str(self.delay_start)
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or 0.0
        _delay_start = _parse_double(_text)
        if isinstance(_delay_start, SDFError):
            return _delay_start
        if _delay_start is not None and cmp_version(version, "1.2") < 0:
            if _delay_start != 0.0:
                return SDFError(f"'delay_start' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, delay_start=_delay_start)


class Filename(BaseModel):
    def __init__(self, sdf_version: str, filename: str = "__default__"):
        self.__version__ = sdf_version
        self.filename = filename

    def to_version(self, target_version: str) -> "Filename":
        if self.filename is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'filename' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["filename"] = self.filename
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("filename")
        if self.filename is not None:
            el.text = self.filename
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or "__default__"
        _filename = _text
        if isinstance(_filename, SDFError):
            return _filename
        if _filename is not None and cmp_version(version, "1.2") < 0:
            if _filename != "__default__":
                return SDFError(f"'filename' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, filename=_filename)


class InterpolateX(BaseModel):
    def __init__(self, sdf_version: str, interpolate_x: bool = False):
        self.__version__ = sdf_version
        self.interpolate_x = interpolate_x

    def to_version(self, target_version: str) -> "InterpolateX":
        if self.interpolate_x is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'interpolate_x' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["interpolate_x"] = self.interpolate_x
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("interpolate_x")
        if self.interpolate_x is not None:
            el.text = str(self.interpolate_x).lower()
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or False
        _interpolate_x = str(_text).strip().lower() == 'true'
        if isinstance(_interpolate_x, SDFError):
            return _interpolate_x
        if _interpolate_x is not None and cmp_version(version, "1.2") < 0:
            if _interpolate_x != False:
                return SDFError(f"'interpolate_x' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, interpolate_x=_interpolate_x)


class Loop(BaseModel):
    def __init__(self, sdf_version: str, loop: bool = True):
        self.__version__ = sdf_version
        self.loop = loop

    def to_version(self, target_version: str) -> "Loop":
        if self.loop is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'loop' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["loop"] = self.loop
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("loop")
        if self.loop is not None:
            el.text = str(self.loop).lower()
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or True
        _loop = str(_text).strip().lower() == 'true'
        if isinstance(_loop, SDFError):
            return _loop
        if _loop is not None and cmp_version(version, "1.2") < 0:
            if _loop != True:
                return SDFError(f"'loop' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, loop=_loop)


class Origin(BaseModel):
    def __init__(self, sdf_version: str, pose: _SDFPose = None):
        self.__version__ = sdf_version
        if pose is None:
            pose = _SDFPose.from_sdf("0 0 0 0 0 0")
        self.pose = pose

    def to_version(self, target_version: str) -> "Origin":
        kwargs = {"sdf_version": target_version}
        kwargs["pose"] = self.pose
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("origin")
        if self.pose is not None:
            el.set("pose", self.pose.to_sdf())
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _pose = _SDFPose._from_sdf(el.get("pose", "0 0 0 0 0 0"), version)
        if isinstance(_pose, SDFError):
            return _pose.extend("@pose")
        return cls(sdf_version=version, pose=_pose)


class Pose(BaseModel):
    _MIGRATIONS = [{"version": "1.7", "ops": [{"type": "move", "from": "frame", "to": "relative_to"}]}]

    def __init__(self, sdf_version: str, pose: _SDFPose = None):
        self.__version__ = sdf_version
        if pose is None:
            pose = _SDFPose.from_sdf("0 0 0 0 0 0")
        self.pose = pose

    def to_version(self, target_version: str) -> "Pose":
        if self.pose is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'pose' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["pose"] = self.pose
        new_obj = self.__class__(**kwargs)
        apply_migrations(new_obj, target_version)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("pose")
        if self.pose is not None:
            el.text = self.pose.to_sdf()
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or "0 0 0 0 0 0"
        _pose = _SDFPose._from_sdf(_text, version)
        if isinstance(_pose, SDFError):
            return _pose
        if _pose is not None and cmp_version(version, "1.2") < 0:
            if _pose != "0 0 0 0 0 0":
                return SDFError(f"'pose' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, pose=_pose)


class Scale(BaseModel):
    def __init__(self, sdf_version: str, scale: float = 1.0):
        self.__version__ = sdf_version
        self.scale = scale

    def to_version(self, target_version: str) -> "Scale":
        if self.scale is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'scale' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["scale"] = self.scale
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("scale")
        if self.scale is not None:
            el.text = str(self.scale)
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or 1.0
        _scale = _parse_double(_text)
        if isinstance(_scale, SDFError):
            return _scale
        if _scale is not None and cmp_version(version, "1.2") < 0:
            if _scale != 1.0:
                return SDFError(f"'scale' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, scale=_scale)


class Script(BaseModel):
    def __init__(
        self,
        sdf_version: str,
        auto_start: bool = True,
        delay_start: float = 0.0,
        loop: bool = True,
        trajectory: List["Trajectory"] = None
    ):
        self.__version__ = sdf_version
        self.auto_start = auto_start
        self.delay_start = delay_start
        self.loop = loop
        self.trajectory = trajectory or []

    def to_version(self, target_version: str) -> "Script":
        if self.auto_start is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'auto_start' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.delay_start is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'delay_start' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.loop is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'loop' is not supported in SDF version {target_version} (removed in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["auto_start"] = self.auto_start
        kwargs["delay_start"] = self.delay_start
        kwargs["loop"] = self.loop
        kwargs["trajectory"] = [c.to_version(target_version) for c in (self.trajectory or [])]
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("script")
        if self.auto_start is not None:
            el.set("auto_start", str(self.auto_start).lower())
        if self.delay_start is not None:
            el.set("delay_start", str(self.delay_start))
        if self.loop is not None:
            el.set("loop", str(self.loop).lower())
        for item in (self.trajectory or []):
            el.append(item.to_sdf(version))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _auto_start = str(el.get("auto_start", True)).strip().lower() == 'true'
        if isinstance(_auto_start, SDFError):
            return _auto_start.extend("@auto_start")
        _delay_start = _parse_double(el.get("delay_start", 0.0))
        if isinstance(_delay_start, SDFError):
            return _delay_start.extend("@delay_start")
        _loop = str(el.get("loop", True)).strip().lower() == 'true'
        if isinstance(_loop, SDFError):
            return _loop.extend("@loop")
        _trajectory = []
        for c in el.findall("trajectory"):
            _res = Trajectory._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("trajectory")
            _trajectory.append(_res)
        return cls(sdf_version=version, auto_start=_auto_start, delay_start=_delay_start, loop=_loop, trajectory=_trajectory)


class Skin(BaseModel):
    def __init__(self, sdf_version: str, filename: str = "__default__", scale: float = 1.0):
        self.__version__ = sdf_version
        self.filename = filename
        self.scale = scale

    def to_version(self, target_version: str) -> "Skin":
        if self.filename is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'filename' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.scale is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'scale' is not supported in SDF version {target_version} (removed in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["filename"] = self.filename
        kwargs["scale"] = self.scale
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("skin")
        if self.filename is not None:
            el.set("filename", self.filename)
        if self.scale is not None:
            el.set("scale", str(self.scale))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _filename = el.get("filename", "__default__")
        if isinstance(_filename, SDFError):
            return _filename.extend("@filename")
        _scale = _parse_double(el.get("scale", 1.0))
        if isinstance(_scale, SDFError):
            return _scale.extend("@scale")
        return cls(sdf_version=version, filename=_filename, scale=_scale)


class Static(BaseModel):
    def __init__(self, sdf_version: str, static: bool = True):
        self.__version__ = sdf_version
        self.static = static

    def to_version(self, target_version: str) -> "Static":
        if self.static is not None and cmp_version(target_version, "1.5") < 0:
            raise ValueError(f"'static' is not supported in SDF version {target_version} (added in 1.5)")
        if self.static is not None and cmp_version(target_version, "1.7") >= 0:
            raise ValueError(f"'static' is not supported in SDF version {target_version} (removed in 1.7)")
        kwargs = {"sdf_version": target_version}
        kwargs["static"] = self.static
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("static")
        if self.static is not None:
            el.text = str(self.static).lower()
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or True
        _static = str(_text).strip().lower() == 'true'
        if isinstance(_static, SDFError):
            return _static
        if _static is not None and cmp_version(version, "1.5") < 0:
            if _static != True:
                return SDFError(f"'static' is not supported in SDF version {version} (added in 1.5)")
        return cls(sdf_version=version, static=_static)


class Time(BaseModel):
    def __init__(self, sdf_version: str, time: float = 0.0):
        self.__version__ = sdf_version
        self.time = time

    def to_version(self, target_version: str) -> "Time":
        if self.time is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'time' is not supported in SDF version {target_version} (added in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["time"] = self.time
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("time")
        if self.time is not None:
            el.text = str(self.time)
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _text = el.text or 0.0
        _time = _parse_double(_text)
        if isinstance(_time, SDFError):
            return _time
        if _time is not None and cmp_version(version, "1.2") < 0:
            if _time != 0.0:
                return SDFError(f"'time' is not supported in SDF version {version} (added in 1.2)")
        return cls(sdf_version=version, time=_time)


class Trajectory(BaseModel):
    def __init__(
        self,
        sdf_version: str,
        id: int = 0,
        tension: float = 0.0,
        type: str = "__default__",
        waypoint: List["Waypoint"] = None
    ):
        self.__version__ = sdf_version
        self.id = id
        self.tension = tension
        self.type = type
        self.waypoint = waypoint or []

    def to_version(self, target_version: str) -> "Trajectory":
        if self.tension is not None and cmp_version(target_version, "1.6") < 0:
            raise ValueError(f"'tension' is not supported in SDF version {target_version} (added in 1.6)")
        kwargs = {"sdf_version": target_version}
        kwargs["id"] = self.id
        kwargs["tension"] = self.tension
        kwargs["type"] = self.type
        kwargs["waypoint"] = [c.to_version(target_version) for c in (self.waypoint or [])]
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("trajectory")
        if self.id is not None:
            el.set("id", str(self.id))
        if self.tension is not None:
            el.set("tension", str(self.tension))
        if self.type is not None:
            el.set("type", self.type)
        for item in (self.waypoint or []):
            el.append(item.to_sdf(version))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _id = _parse_int32(el.get("id", 0))
        if isinstance(_id, SDFError):
            return _id.extend("@id")
        _tension = _parse_double(el.get("tension", 0.0))
        if isinstance(_tension, SDFError):
            return _tension.extend("@tension")
        if _tension is not None and cmp_version(version, "1.6") < 0:
            if _tension != 0.0:
                return SDFError(f"'tension' is not supported in SDF version {version} (added in 1.6)")
        _type = el.get("type", "__default__")
        if isinstance(_type, SDFError):
            return _type.extend("@type")
        _waypoint = []
        for c in el.findall("waypoint"):
            _res = Waypoint._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("waypoint")
            _waypoint.append(_res)
        return cls(sdf_version=version, id=_id, tension=_tension, type=_type, waypoint=_waypoint)


class Waypoint(BaseModel):
    def __init__(self, sdf_version: str, pose: _SDFPose = None, time: float = 0.0):
        self.__version__ = sdf_version
        if pose is None:
            pose = _SDFPose.from_sdf("0 0 0 0 0 0")
        self.pose = pose
        self.time = time

    def to_version(self, target_version: str) -> "Waypoint":
        if self.pose is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'pose' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.time is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'time' is not supported in SDF version {target_version} (removed in 1.2)")
        kwargs = {"sdf_version": target_version}
        kwargs["pose"] = self.pose
        kwargs["time"] = self.time
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str = None) -> ET.Element:
        if version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = version or self.__version__
        el = ET.Element("waypoint")
        if self.pose is not None:
            el.set("pose", self.pose.to_sdf())
        if self.time is not None:
            el.set("time", str(self.time))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _pose = _SDFPose._from_sdf(el.get("pose", "0 0 0 0 0 0"), version)
        if isinstance(_pose, SDFError):
            return _pose.extend("@pose")
        _time = _parse_double(el.get("time", 0.0))
        if isinstance(_time, SDFError):
            return _time.extend("@time")
        return cls(sdf_version=version, pose=_pose, time=_time)
