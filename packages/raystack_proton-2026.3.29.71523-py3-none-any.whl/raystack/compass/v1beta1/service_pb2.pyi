import datetime

from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class User(_message.Message):
    __slots__ = ("id", "uuid", "email", "provider", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    UUID_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    uuid: str
    email: str
    provider: str
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., uuid: _Optional[str] = ..., email: _Optional[str] = ..., provider: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Entity(_message.Message):
    __slots__ = ("id", "urn", "type", "name", "description", "properties", "source", "valid_from", "valid_to", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    URN_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    VALID_FROM_FIELD_NUMBER: _ClassVar[int]
    VALID_TO_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    urn: str
    type: str
    name: str
    description: str
    properties: _struct_pb2.Struct
    source: str
    valid_from: _timestamp_pb2.Timestamp
    valid_to: _timestamp_pb2.Timestamp
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., urn: _Optional[str] = ..., type: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., source: _Optional[str] = ..., valid_from: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., valid_to: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Edge(_message.Message):
    __slots__ = ("id", "source_urn", "target_urn", "type", "properties", "source", "valid_from", "valid_to", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URN_FIELD_NUMBER: _ClassVar[int]
    TARGET_URN_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    VALID_FROM_FIELD_NUMBER: _ClassVar[int]
    VALID_TO_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    source_urn: str
    target_urn: str
    type: str
    properties: _struct_pb2.Struct
    source: str
    valid_from: _timestamp_pb2.Timestamp
    valid_to: _timestamp_pb2.Timestamp
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., source_urn: _Optional[str] = ..., target_urn: _Optional[str] = ..., type: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., source: _Optional[str] = ..., valid_from: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., valid_to: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Type(_message.Message):
    __slots__ = ("name", "count")
    NAME_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    name: str
    count: int
    def __init__(self, name: _Optional[str] = ..., count: _Optional[int] = ...) -> None: ...

class Namespace(_message.Message):
    __slots__ = ("id", "name", "state", "metadata")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    state: str
    metadata: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., state: _Optional[str] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class GetAllEntitiesRequest(_message.Message):
    __slots__ = ("types", "source", "q", "size", "offset")
    TYPES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    Q_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    types: str
    source: str
    q: str
    size: int
    offset: int
    def __init__(self, types: _Optional[str] = ..., source: _Optional[str] = ..., q: _Optional[str] = ..., size: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class GetAllEntitiesResponse(_message.Message):
    __slots__ = ("data", "total")
    DATA_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Entity]
    total: int
    def __init__(self, data: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ..., total: _Optional[int] = ...) -> None: ...

class GetEntityByIDRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class GetEntityByIDResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: Entity
    def __init__(self, data: _Optional[_Union[Entity, _Mapping]] = ...) -> None: ...

class UpsertEntityRequest(_message.Message):
    __slots__ = ("urn", "type", "name", "description", "properties", "source", "upstreams", "downstreams")
    URN_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    UPSTREAMS_FIELD_NUMBER: _ClassVar[int]
    DOWNSTREAMS_FIELD_NUMBER: _ClassVar[int]
    urn: str
    type: str
    name: str
    description: str
    properties: _struct_pb2.Struct
    source: str
    upstreams: _containers.RepeatedScalarFieldContainer[str]
    downstreams: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, urn: _Optional[str] = ..., type: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., source: _Optional[str] = ..., upstreams: _Optional[_Iterable[str]] = ..., downstreams: _Optional[_Iterable[str]] = ...) -> None: ...

class UpsertEntityResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteEntityRequest(_message.Message):
    __slots__ = ("urn",)
    URN_FIELD_NUMBER: _ClassVar[int]
    urn: str
    def __init__(self, urn: _Optional[str] = ...) -> None: ...

class DeleteEntityResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SearchEntitiesRequest(_message.Message):
    __slots__ = ("text", "types", "source", "mode", "size", "offset")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    TYPES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    text: str
    types: str
    source: str
    mode: str
    size: int
    offset: int
    def __init__(self, text: _Optional[str] = ..., types: _Optional[str] = ..., source: _Optional[str] = ..., mode: _Optional[str] = ..., size: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class SearchEntitiesResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Entity]
    def __init__(self, data: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ...) -> None: ...

class SuggestEntitiesRequest(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class SuggestEntitiesResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, data: _Optional[_Iterable[str]] = ...) -> None: ...

class GetEntityTypesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetEntityTypesResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Type]
    def __init__(self, data: _Optional[_Iterable[_Union[Type, _Mapping]]] = ...) -> None: ...

class GetEntityContextRequest(_message.Message):
    __slots__ = ("urn", "depth")
    URN_FIELD_NUMBER: _ClassVar[int]
    DEPTH_FIELD_NUMBER: _ClassVar[int]
    urn: str
    depth: int
    def __init__(self, urn: _Optional[str] = ..., depth: _Optional[int] = ...) -> None: ...

class GetEntityContextResponse(_message.Message):
    __slots__ = ("entity", "edges", "related")
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    EDGES_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    entity: Entity
    edges: _containers.RepeatedCompositeFieldContainer[Edge]
    related: _containers.RepeatedCompositeFieldContainer[Entity]
    def __init__(self, entity: _Optional[_Union[Entity, _Mapping]] = ..., edges: _Optional[_Iterable[_Union[Edge, _Mapping]]] = ..., related: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ...) -> None: ...

class GetEntityImpactRequest(_message.Message):
    __slots__ = ("urn", "depth")
    URN_FIELD_NUMBER: _ClassVar[int]
    DEPTH_FIELD_NUMBER: _ClassVar[int]
    urn: str
    depth: int
    def __init__(self, urn: _Optional[str] = ..., depth: _Optional[int] = ...) -> None: ...

class GetEntityImpactResponse(_message.Message):
    __slots__ = ("edges", "affected")
    EDGES_FIELD_NUMBER: _ClassVar[int]
    AFFECTED_FIELD_NUMBER: _ClassVar[int]
    edges: _containers.RepeatedCompositeFieldContainer[Edge]
    affected: _containers.RepeatedCompositeFieldContainer[Entity]
    def __init__(self, edges: _Optional[_Iterable[_Union[Edge, _Mapping]]] = ..., affected: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ...) -> None: ...

class UpsertEdgeRequest(_message.Message):
    __slots__ = ("source_urn", "target_urn", "type", "properties", "source")
    SOURCE_URN_FIELD_NUMBER: _ClassVar[int]
    TARGET_URN_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    source_urn: str
    target_urn: str
    type: str
    properties: _struct_pb2.Struct
    source: str
    def __init__(self, source_urn: _Optional[str] = ..., target_urn: _Optional[str] = ..., type: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., source: _Optional[str] = ...) -> None: ...

class UpsertEdgeResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class GetEdgesRequest(_message.Message):
    __slots__ = ("urn", "direction", "type", "current_only")
    URN_FIELD_NUMBER: _ClassVar[int]
    DIRECTION_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_ONLY_FIELD_NUMBER: _ClassVar[int]
    urn: str
    direction: str
    type: str
    current_only: bool
    def __init__(self, urn: _Optional[str] = ..., direction: _Optional[str] = ..., type: _Optional[str] = ..., current_only: _Optional[bool] = ...) -> None: ...

class GetEdgesResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Edge]
    def __init__(self, data: _Optional[_Iterable[_Union[Edge, _Mapping]]] = ...) -> None: ...

class DeleteEdgeRequest(_message.Message):
    __slots__ = ("source_urn", "target_urn", "type")
    SOURCE_URN_FIELD_NUMBER: _ClassVar[int]
    TARGET_URN_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    source_urn: str
    target_urn: str
    type: str
    def __init__(self, source_urn: _Optional[str] = ..., target_urn: _Optional[str] = ..., type: _Optional[str] = ...) -> None: ...

class DeleteEdgeResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class StarEntityRequest(_message.Message):
    __slots__ = ("entity_id",)
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    def __init__(self, entity_id: _Optional[str] = ...) -> None: ...

class StarEntityResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class UnstarEntityRequest(_message.Message):
    __slots__ = ("entity_id",)
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    def __init__(self, entity_id: _Optional[str] = ...) -> None: ...

class UnstarEntityResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetUserStarredEntitiesRequest(_message.Message):
    __slots__ = ("user_id", "size", "offset")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    size: int
    offset: int
    def __init__(self, user_id: _Optional[str] = ..., size: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class GetUserStarredEntitiesResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Entity]
    def __init__(self, data: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ...) -> None: ...

class GetMyStarredEntitiesRequest(_message.Message):
    __slots__ = ("size", "offset")
    SIZE_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    size: int
    offset: int
    def __init__(self, size: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class GetMyStarredEntitiesResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Entity]
    def __init__(self, data: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ...) -> None: ...

class GetMyStarredEntityRequest(_message.Message):
    __slots__ = ("entity_id",)
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_id: str
    def __init__(self, entity_id: _Optional[str] = ...) -> None: ...

class GetMyStarredEntityResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: Entity
    def __init__(self, data: _Optional[_Union[Entity, _Mapping]] = ...) -> None: ...

class GetEntityStargazersRequest(_message.Message):
    __slots__ = ("id", "size", "offset")
    ID_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    id: str
    size: int
    offset: int
    def __init__(self, id: _Optional[str] = ..., size: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class GetEntityStargazersResponse(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[User]
    def __init__(self, data: _Optional[_Iterable[_Union[User, _Mapping]]] = ...) -> None: ...

class CreateNamespaceRequest(_message.Message):
    __slots__ = ("id", "name", "state", "metadata")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    state: str
    metadata: _struct_pb2.Struct
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., state: _Optional[str] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class CreateNamespaceResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class GetNamespaceRequest(_message.Message):
    __slots__ = ("urn",)
    URN_FIELD_NUMBER: _ClassVar[int]
    urn: str
    def __init__(self, urn: _Optional[str] = ...) -> None: ...

class GetNamespaceResponse(_message.Message):
    __slots__ = ("namespace",)
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    namespace: Namespace
    def __init__(self, namespace: _Optional[_Union[Namespace, _Mapping]] = ...) -> None: ...

class UpdateNamespaceRequest(_message.Message):
    __slots__ = ("urn", "state", "metadata")
    URN_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    urn: str
    state: str
    metadata: _struct_pb2.Struct
    def __init__(self, urn: _Optional[str] = ..., state: _Optional[str] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class UpdateNamespaceResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListNamespacesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListNamespacesResponse(_message.Message):
    __slots__ = ("namespaces",)
    NAMESPACES_FIELD_NUMBER: _ClassVar[int]
    namespaces: _containers.RepeatedCompositeFieldContainer[Namespace]
    def __init__(self, namespaces: _Optional[_Iterable[_Union[Namespace, _Mapping]]] = ...) -> None: ...
