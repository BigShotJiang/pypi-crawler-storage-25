"""Tests for core modules: config, context, session, imports."""

import json
import os
import pathlib

import pytest

from kittycode import ALL_TOOLS, Agent, Config, LLM, __version__
from kittycode.context import ContextManager, estimate_tokens
from kittycode.session import list_sessions, load_session, save_session


def test_version():
    assert __version__ == "0.1.0"


def test_public_api_exports():
    assert Agent is not None
    assert LLM is not None
    assert Config is not None
    assert len(ALL_TOOLS) == 7


def test_config_from_file(tmp_path):
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps({
        "interface": "openai",
        "api_key": "test-key",
        "model": "test-model",
        "base_url": "https://example.com/v1",
        "max_tokens": 1234,
        "temperature": 0.5,
        "max_context": 4567,
    }))

    config = Config.from_file(config_path)

    assert config.interface == "openai"
    assert config.api_key == "test-key"
    assert config.model == "test-model"
    assert config.base_url == "https://example.com/v1"
    assert config.max_tokens == 1234
    assert config.temperature == 0.5
    assert config.max_context_tokens == 4567


def test_config_defaults_when_file_missing(tmp_path):
    config = Config.from_file(tmp_path / "missing.json")
    assert config.interface == "openai"
    assert config.model == "gpt-4o"
    assert config.max_tokens == 4096
    assert config.temperature == 0.0


def test_config_does_not_read_env(monkeypatch, tmp_path):
    monkeypatch.setenv("KITTYCODE_MODEL", "env-model")
    monkeypatch.setenv("KITTYCODE_API_KEY", "env-key")

    config = Config.from_file(tmp_path / "missing.json")

    assert config.model == "gpt-4o"
    assert config.api_key == ""


def test_config_supports_anthropic_interface(tmp_path):
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps({
        "interface": "anthropic",
        "api_key": "anthropic-key",
        "model": "claude-3-7-sonnet-latest",
        "base_url": "https://api.anthropic.com",
    }))

    config = Config.from_file(config_path)

    assert config.interface == "anthropic"
    assert config.api_key == "anthropic-key"
    assert config.model == "claude-3-7-sonnet-latest"
    assert config.base_url == "https://api.anthropic.com"


def test_config_invalid_interface(tmp_path):
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps({"interface": "invalid"}))

    with pytest.raises(ValueError, match="interface must be 'openai' or 'anthropic'"):
        Config.from_file(config_path)


def test_estimate_tokens():
    messages = [{"role": "user", "content": "hello world"}]
    tokens = estimate_tokens(messages)
    assert tokens > 0
    assert tokens < 100


def test_context_snip():
    context = ContextManager(max_tokens=3000)
    messages = [{"role": "tool", "tool_call_id": "t1", "content": "x\n" * 1000}]
    before = estimate_tokens(messages)
    context._snip_tool_outputs(messages)
    after = estimate_tokens(messages)
    assert after < before


def test_context_compress():
    context = ContextManager(max_tokens=2000)
    messages = []
    for index in range(20):
        messages.append({"role": "user", "content": f"msg {index} " + "a" * 200})
        messages.append({"role": "tool", "tool_call_id": f"t{index}", "content": "b" * 2000})
    before = estimate_tokens(messages)
    context.maybe_compress(messages, None)
    after = estimate_tokens(messages)
    assert after < before
    assert len(messages) < 40


def test_session_save_load():
    messages = [{"role": "user", "content": "test message"}]
    save_session(messages, "test-model", "pytest_test_session")
    loaded = load_session("pytest_test_session")
    assert loaded is not None
    assert loaded[0] == messages
    assert loaded[1] == "test-model"
    pathlib.Path.home().joinpath(".kittycode/sessions/pytest_test_session.json").unlink(missing_ok=True)


def test_session_not_found():
    assert load_session("nonexistent_session_id") is None


def test_list_sessions():
    sessions = list_sessions()
    assert isinstance(sessions, list)