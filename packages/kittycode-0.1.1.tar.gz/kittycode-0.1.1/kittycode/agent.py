"""Core agent loop.

This is the heart of KittyCode.

    user message -> LLM (with tools) -> tool calls? -> execute -> loop
                                      -> text reply? -> return to user

It keeps looping until the LLM responds with plain text, which means it is
done working and ready to report back.
"""

import concurrent.futures

from .context import ContextManager
from .llm import LLM
from .prompt import system_prompt
from .skills import load_skills
from .tools import ALL_TOOLS, get_tool
from .tools.agent import AgentTool
from .tools.base import Tool


class Agent:
    def __init__(
        self,
        llm: LLM,
        tools: list[Tool] | None = None,
        max_context_tokens: int = 128_000,
        max_rounds: int = 50,
    ):
        self.llm = llm
        self.tools = tools if tools is not None else ALL_TOOLS
        self.messages: list[dict] = []
        self.context = ContextManager(max_tokens=max_context_tokens)
        self.max_rounds = max_rounds
        self.skills = []
        self._system = ""
        self.refresh_skills(force_reload=True)

        for tool in self.tools:
            if isinstance(tool, AgentTool):
                tool._parent_agent = self

    def _full_messages(self) -> list[dict]:
        self.refresh_skills()
        return [{"role": "system", "content": self._system}] + self.messages

    def _tool_schemas(self) -> list[dict]:
        return [tool.schema() for tool in self.tools]

    def chat(self, user_input: str, on_token=None, on_tool=None) -> str:
        """Process one user message. May involve multiple LLM/tool rounds."""
        self.messages.append({"role": "user", "content": user_input})
        self.context.maybe_compress(self.messages, self.llm)

        for _ in range(self.max_rounds):
            response = self.llm.chat(
                messages=self._full_messages(),
                tools=self._tool_schemas(),
                on_token=on_token,
            )

            if not response.tool_calls:
                self.messages.append(response.message)
                return response.content

            self.messages.append(response.message)

            if len(response.tool_calls) == 1:
                tool_call = response.tool_calls[0]
                if on_tool:
                    on_tool(tool_call.name, tool_call.arguments)
                result = self._exec_tool(tool_call)
                self.messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": result,
                    }
                )
            else:
                results = self._exec_tools_parallel(response.tool_calls, on_tool)
                for tool_call, result in zip(response.tool_calls, results):
                    self.messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": result,
                        }
                    )

            self.context.maybe_compress(self.messages, self.llm)

        return "(reached maximum tool-call rounds)"

    def _exec_tool(self, tool_call) -> str:
        """Execute a single tool call and return the result string."""
        tool = get_tool(tool_call.name)
        if tool is None:
            return f"Error: unknown tool '{tool_call.name}'"
        try:
            return tool.execute(**tool_call.arguments)
        except TypeError as exc:
            return f"Error: bad arguments for {tool_call.name}: {exc}"
        except Exception as exc:
            return f"Error executing {tool_call.name}: {exc}"

    def _exec_tools_parallel(self, tool_calls, on_tool=None) -> list[str]:
        """Run multiple tool calls concurrently using threads."""
        for tool_call in tool_calls:
            if on_tool:
                on_tool(tool_call.name, tool_call.arguments)

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(self._exec_tool, tool_call) for tool_call in tool_calls]
            return [future.result() for future in futures]

    def reset(self):
        """Clear conversation history."""
        self.messages.clear()

    def refresh_skills(self, force_reload: bool = False):
        """Refresh cached skill metadata and rebuild the system prompt."""
        self.skills = load_skills(force_reload=force_reload)
        self._system = system_prompt(self.tools, self.skills)