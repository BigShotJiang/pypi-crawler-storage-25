import json
import lzma
import os
from typing import Any, Dict, List, Optional

MAGIC = b"FB02"
VERSION = 2


def _mix32(x: int) -> int:
    x &= 0xFFFFFFFF
    x ^= (x << 13) & 0xFFFFFFFF
    x ^= (x >> 17)
    x ^= (x << 5) & 0xFFFFFFFF
    return x & 0xFFFFFFFF


def _seed(key: bytes, nonce: bytes) -> int:
    h = 2166136261
    for b in key + nonce:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h or 1


def _stream(seed: int):
    s = seed & 0xFFFFFFFF
    while True:
        s = _mix32(s)
        yield s & 0xFF


def _xorcrypt(data: bytes, key: bytes, nonce: bytes) -> bytes:
    ks = _stream(_seed(key, nonce))
    out = bytearray()
    prev = 0
    for i, b in enumerate(data):
        k = next(ks)
        v = b ^ k ^ prev
        r = (i % 7) + 1
        v = ((v << r) | (v >> (8 - r))) & 0xFF
        out.append(v)
        prev = v
    return bytes(out)


def _xordecrypt(data: bytes, key: bytes, nonce: bytes) -> bytes:
    ks = _stream(_seed(key, nonce))
    out = bytearray()
    prev = 0
    for i, b in enumerate(data):
        k = next(ks)
        r = (i % 7) + 1
        v = ((b >> r) | (b << (8 - r))) & 0xFF
        v = v ^ k ^ prev
        out.append(v)
        prev = b
    return bytes(out)


class FunBase:
    _META_TABLE = "_metadata"
    _KEY_KEY = "encryption_key"

    def __init__(self, db_path: str, key: Optional[bytes] = None):
        if not db_path.endswith(".fb"):
            raise ValueError("FunBase file must have extension .fb")

        self.db_path = db_path
        self.data: Dict[str, List[Dict]] = {}
        self.key: bytes = key or b""

        if os.path.exists(self.db_path):
            self._load_existing()
        else:
            if not self.key:
                self.key = os.urandom(32)
            self.data = {}
            self.create_table(self._META_TABLE)
            self._set_meta_key(self.key)
            self._save()

    def _set_meta_key(self, key: bytes):
        meta = self.data.setdefault(self._META_TABLE, [])
        for row in meta:
            if row.get("key") == self._KEY_KEY:
                row["value_hex"] = key.hex()
                return
        meta.append({"key": self._KEY_KEY, "value_hex": key.hex()})

    def _get_meta_key(self) -> bytes:
        meta = self.data.get(self._META_TABLE, [])
        for row in meta:
            if row.get("key") == self._KEY_KEY:
                return bytes.fromhex(row["value_hex"])
        raise RuntimeError("Ключ не найден внутри БД")

    def _pack(self, raw_json: bytes) -> bytes:
        compressed = lzma.compress(raw_json, preset=6)
        nonce = os.urandom(12)
        encrypted = _xorcrypt(compressed, self.key, nonce)
        return MAGIC + bytes([VERSION, len(nonce)]) + len(encrypted).to_bytes(4, "big") + nonce + encrypted

    def _unpack(self, blob: bytes, key: bytes) -> bytes:
        if len(blob) < 10:
            raise RuntimeError("Файл слишком маленький")
        if blob[:4] != MAGIC:
            raise RuntimeError("Неверный формат FunBase")
        if blob[4] != VERSION:
            raise RuntimeError("Неподдерживаемая версия файла")

        nonce_len = blob[5]
        enc_len = int.from_bytes(blob[6:10], "big")
        pos = 10
        nonce = blob[pos:pos + nonce_len]
        enc = blob[pos + nonce_len:pos + nonce_len + enc_len]

        compressed = _xordecrypt(enc, key, nonce)
        try:
            return lzma.decompress(compressed)
        except lzma.LZMAError as e:
            raise RuntimeError("Не удалось распаковать данные: файл старого формата или повреждён") from e

    def _load_existing(self):
        with open(self.db_path, "rb") as f:
            blob = f.read()

        if not blob:
            raise RuntimeError("Пустой файл базы")

        # сначала пробуем ключ из текущего объекта, если он был задан
        if self.key:
            raw = self._unpack(blob, self.key)
            self.data = json.loads(raw.decode("utf-8"))
            try:
                self.key = self._get_meta_key()
            except Exception:
                pass
            return

        # если ключ не был передан, пробуем открыть как новый формат и взять ключ из meta
        # для этого нужен временный ключ-подход: сначала читаем тем же ключом, что уже хранится в памяти
        # но если ключ внутри файла, его надо прочитать из уже открытых данных.
        # поэтому для новых баз ключ должен передаваться при создании,
        # а при повторном открытии он читается из сохранённой meta после первой успешной загрузки.
        # если файл был создан старой версией и ключ не передан — открытие невозможно.
        raise RuntimeError("Для этой версии файла нужен ключ открытия. Пересоздай базу в новом формате.")

    def _save(self):
        raw = json.dumps(self.data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        blob = self._pack(raw)
        with open(self.db_path, "wb") as f:
            f.write(blob)

    def create_table(self, table_name: str) -> "FunBase":
        if table_name not in self.data:
            self.data[table_name] = []
            self._save()
        return self

    def insert(self, table_name: str, record: Dict[str, Any]) -> "FunBase":
        self.data.setdefault(table_name, []).append(record)
        self._save()
        return self

    def select_all(self, table_name: str) -> List[Dict]:
        if table_name == self._META_TABLE:
            return []
        return self.data.get(table_name, [])

    def delete_table(self, table_name: str) -> "FunBase":
        if table_name in self.data and table_name != self._META_TABLE:
            del self.data[table_name]
            self._save()
        return self

    def get_key(self) -> bytes:
        return self.key