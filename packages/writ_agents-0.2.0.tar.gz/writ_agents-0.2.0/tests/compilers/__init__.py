"""Compiler tests."""
