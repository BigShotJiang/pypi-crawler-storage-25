
#include "config/observation_features.hpp"

namespace ObservationFeature {
std::shared_ptr<ObservationFeaturesImpl> _instance;

// Define the extern variables
ObservationType Group;
ObservationType EpisodeCompletionPct;
ObservationType LastAction;
ObservationType LastReward;
ObservationType LastActionMove;
ObservationType Vibe;
ObservationType Tag;
ObservationType Goal;
ObservationType LpEast;
ObservationType LpWest;
ObservationType LpNorth;
ObservationType LpSouth;
ObservationType AgentId;
ObservationType TerritoryHere;
ObservationType TerritoryEdgeNorth;
ObservationType TerritoryEdgeSouth;
ObservationType TerritoryEdgeEast;
ObservationType TerritoryEdgeWest;

void Initialize(const std::unordered_map<std::string, ObservationType>& feature_ids) {
  _instance = std::make_shared<ObservationFeaturesImpl>(feature_ids);

  // Update the global variables with values from the instance
  Group = _instance->Group;
  EpisodeCompletionPct = _instance->EpisodeCompletionPct;
  LastAction = _instance->LastAction;
  LastReward = _instance->LastReward;
  LastActionMove = _instance->LastActionMove;
  Vibe = _instance->Vibe;
  Tag = _instance->Tag;
  Goal = _instance->Goal;
  LpEast = _instance->LpEast;
  LpWest = _instance->LpWest;
  LpNorth = _instance->LpNorth;
  LpSouth = _instance->LpSouth;
  AgentId = _instance->AgentId;
  TerritoryHere = _instance->TerritoryHere;
  TerritoryEdgeNorth = _instance->TerritoryEdgeNorth;
  TerritoryEdgeSouth = _instance->TerritoryEdgeSouth;
  TerritoryEdgeEast = _instance->TerritoryEdgeEast;
  TerritoryEdgeWest = _instance->TerritoryEdgeWest;
}
}  // namespace ObservationFeature
