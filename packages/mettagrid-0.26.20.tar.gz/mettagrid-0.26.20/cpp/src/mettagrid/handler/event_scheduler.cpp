#include "handler/event_scheduler.hpp"

#include <algorithm>
#include <utility>

namespace mettagrid {

EventScheduler::EventScheduler(const std::map<std::string, EventConfig>& event_configs) {
  // Create events and build the schedule
  for (const auto& [name, config] : event_configs) {
    auto event = std::make_unique<Event>(config);
    Event* event_ptr = event.get();

    _events[name] = std::move(event);

    // Add all timesteps for this event to the schedule
    for (int timestep : config.timesteps) {
      _schedule.emplace_back(timestep, event_ptr);
    }
  }

  // Resolve fallback event pointers (after all events are created)
  for (auto& [name, event] : _events) {
    const auto& fallback_name = event->fallback_name();
    if (!fallback_name.empty()) {
      Event* fallback = get_event(fallback_name);
      event->set_fallback_event(fallback);
    }
  }

  // Stable sort by timestep, then explicit event priority. For equal priority we
  // preserve std::map iteration order (alphabetical by event name).
  std::stable_sort(_schedule.begin(), _schedule.end(), [](const auto& a, const auto& b) {
    if (a.first != b.first) {
      return a.first < b.first;
    }
    return a.second->priority() < b.second->priority();
  });
}

int EventScheduler::process_timestep(int timestep, const HandlerContext& ctx) {
  int events_fired = 0;

  // Process all events scheduled at or before the current timestep
  while (_next_idx < _schedule.size() && _schedule[_next_idx].first <= timestep) {
    Event* event = _schedule[_next_idx].second;

    // Execute event (handles fallback internally if no targets match)
    int targets_applied = event->execute(ctx);
    if (targets_applied > 0) {
      ++events_fired;
    }

    _next_idx++;
  }

  return events_fired;
}

Event* EventScheduler::get_event(const std::string& name) {
  auto it = _events.find(name);
  if (it != _events.end()) {
    return it->second.get();
  }
  return nullptr;
}

}  // namespace mettagrid
