#include "core/grid_object_factory.hpp"

#include <cassert>
#include <memory>
#include <stdexcept>
#include <vector>

#include "core/grid.hpp"
#include "handler/handler.hpp"
#include "handler/multi_handler.hpp"
#include "objects/agent.hpp"
#include "objects/agent_config.hpp"
#include "objects/wall.hpp"
#include "systems/observation_encoder.hpp"
#include "systems/stats_tracker.hpp"

namespace mettagrid {

// Set up handlers on a GridObject from its config
static void _set_up_handlers(GridObject* obj, const GridObjectConfig* config, [[maybe_unused]] TagIndex* tag_index) {
  obj->set_on_use_handler(config->on_use_handler);
  obj->set_aoe_configs(config->aoe_configs);
  obj->set_territory_controls(config->territory_controls);

  // on_tag_add handlers
  if (!config->on_tag_add.empty()) {
    std::unordered_map<int, std::vector<std::shared_ptr<Handler>>> on_tag_add;
    for (const auto& [tag_id, handler_configs] : config->on_tag_add) {
      for (const auto& hc : handler_configs) {
        on_tag_add[tag_id].push_back(std::make_shared<Handler>(hc));
      }
    }
    obj->set_on_tag_add(std::move(on_tag_add));
  }

  // on_tag_remove handlers
  if (!config->on_tag_remove.empty()) {
    std::unordered_map<int, std::vector<std::shared_ptr<Handler>>> on_tag_remove;
    for (const auto& [tag_id, handler_configs] : config->on_tag_remove) {
      for (const auto& hc : handler_configs) {
        on_tag_remove[tag_id].push_back(std::make_shared<Handler>(hc));
      }
    }
    obj->set_on_tag_remove(std::move(on_tag_remove));
  }

  // on_tick and on_after_use handlers (agent-only)
  if (const auto* agent_config = dynamic_cast<const AgentConfig*>(config)) {
    auto* agent = dynamic_cast<Agent*>(obj);
    if (agent) {
      if (agent_config->on_tick) {
        agent->set_on_tick(agent_config->on_tick);
      }
      if (agent_config->on_after_use_handler) {
        agent->set_on_after_use(agent_config->on_after_use_handler);
      }
    }
  }
}

// Create a GridObject from config (without handlers)
static GridObject* _create_object(GridCoord r,
                                  GridCoord c,
                                  const GridObjectConfig* config,
                                  StatsTracker* stats,
                                  const std::vector<std::string>* resource_names,
                                  Grid* grid,
                                  const ObservationEncoder* obs_encoder,
                                  unsigned int* current_timestep_ptr) {
  // Try specialized config types first
  if (const auto* wall_config = dynamic_cast<const WallConfig*>(config)) {
    return new Wall(r, c, *wall_config);
  }

  if (const auto* agent_config = dynamic_cast<const AgentConfig*>(config)) {
    return new Agent(r, c, *agent_config, resource_names);
  }

  // Default: create a GridObject with inventory support
  auto* obj = new GridObject(config->inventory_config);
  obj->init(config->type_id, config->type_name, GridLocation(r, c), config->tag_ids, config->initial_vibe);
  // Set initial inventory for all configured resources (ignore limits for initial setup)
  for (const auto& [resource, amount] : config->initial_inventory) {
    if (amount > 0) {
      obj->inventory.update(resource, amount, /*ignore_limits=*/true);
    }
  }
  return obj;
}

GridObject* create_object_from_config(GridCoord r,
                                      GridCoord c,
                                      const GridObjectConfig* config,
                                      StatsTracker* stats,
                                      const std::vector<std::string>* resource_names,
                                      Grid* grid,
                                      const ObservationEncoder* obs_encoder,
                                      unsigned int* current_timestep_ptr,
                                      TagIndex* tag_index) {
  auto* obj = _create_object(r, c, config, stats, resource_names, grid, obs_encoder, current_timestep_ptr);
  obj->set_obs_encoder(obs_encoder);
  obj->blocks_vision = config->blocks_vision;
  _set_up_handlers(obj, config, tag_index);
  return obj;
}

}  // namespace mettagrid
