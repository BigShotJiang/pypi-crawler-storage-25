#ifndef PACKAGES_METTAGRID_CPP_INCLUDE_METTAGRID_CORE_GRID_OBJECT_HPP_
#define PACKAGES_METTAGRID_CPP_INCLUDE_METTAGRID_CORE_GRID_OBJECT_HPP_

#include <atomic>
#include <bitset>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <unordered_map>
#include <vector>

#include "core/types.hpp"
#include "handler/handler_config.hpp"
#include "handler/territory_config.hpp"
#include "objects/constants.hpp"
#include "objects/has_inventory.hpp"
#include "objects/has_vibe.hpp"
#include "objects/inventory_config.hpp"
#include "objects/usable.hpp"

// Forward declarations
class ObservationEncoder;

using TypeId = ObservationType;
using ObservationCoord = ObservationType;
using Vibe = ObservationType;

struct PartialObservationToken {
  ObservationType feature_id = EmptyTokenByte;
  ObservationType value = EmptyTokenByte;
};

// These may make more sense in observation_encoder.hpp, but we need to include that
// header in a lot of places, and it's nice to have these types defined in one place.
struct alignas(1) ObservationToken {
  ObservationType location = EmptyTokenByte;
  ObservationType feature_id = EmptyTokenByte;
  ObservationType value = EmptyTokenByte;
};

// The alignas should make sure of this, but let's be explicit.
// We're going to be reinterpret_casting things to this type, so
// it'll be bad if the compiler pads this type.
static_assert(sizeof(ObservationToken) == 3 * sizeof(uint8_t), "ObservationToken must be 3 bytes");

using ObservationTokens = std::span<ObservationToken>;

class GridLocation {
public:
  GridCoord r;
  GridCoord c;

  inline GridLocation(GridCoord r, GridCoord c) : r(r), c(c) {}
  inline GridLocation() : r(0), c(0) {}

  inline bool operator==(const GridLocation& other) const {
    return r == other.r && c == other.c;
  }
};

// Forward declarations for GridObjectConfig
namespace mettagrid {
class Handler;
}  // namespace mettagrid

struct GridObjectConfig {
  TypeId type_id;
  std::string type_name;
  std::string name;  // Instance name (defaults to type_name if empty)
  std::vector<int> tag_ids;
  ObservationType initial_vibe;
  InventoryConfig inventory_config;
  std::unordered_map<InventoryItem, InventoryQuantity> initial_inventory;

  // Two types of handlers on GridObject:
  // - on_use: Triggered when agent uses/activates this object (context: actor=agent, target=this)
  // - aoe: Triggered per-tick for objects within radius (context: actor=this, target=affected)
  std::shared_ptr<mettagrid::Handler> on_use_handler;  // Handler created by Python
  std::vector<mettagrid::AOEConfig> aoe_configs;
  std::vector<mettagrid::TerritoryControlConfig> territory_controls;

  // Tag lifecycle handlers: key = tag_id, value = handler configs to fire
  // Fired with actor=target=this_object when a tag is added/removed
  std::unordered_map<int, std::vector<mettagrid::HandlerConfig>> on_tag_add;
  std::unordered_map<int, std::vector<mettagrid::HandlerConfig>> on_tag_remove;

  // Whether this object blocks line of sight for observations.
  bool blocks_vision = false;

  GridObjectConfig(TypeId type_id, const std::string& type_name, ObservationType initial_vibe = 0)
      : type_id(type_id),
        type_name(type_name),
        name(""),
        tag_ids({}),
        initial_vibe(initial_vibe),
        inventory_config(),
        on_use_handler(nullptr),
        aoe_configs() {}

  virtual ~GridObjectConfig() = default;
};

// Forward declaration for GridObject
namespace mettagrid {
class TagIndex;
class HandlerContext;
}  // namespace mettagrid

class GridObject : public HasVibe, public HasInventory, public Usable {
public:
  GridObjectId id{};
  GridLocation location{};
  std::atomic<unsigned int> visited{0};
  TypeId type_id{};
  std::string type_name;  // Class type (e.g., "hub")
  std::string name;       // Instance name (e.g., "carbon_extractor"), defaults to type_name
  std::bitset<kMaxTags> tag_bits;
  bool blocks_vision{false};

  // Constructor with optional inventory config (defaults to empty)
  explicit GridObject(const InventoryConfig& inv_config = InventoryConfig());

  ~GridObject() override;

  void init(TypeId object_type_id,
            const std::string& object_type_name,
            const GridLocation& object_location,
            const std::vector<int>& tags,
            ObservationType object_vibe = 0,
            const std::string& object_name = "");

  // Set handler for on_use events (takes shared_ptr for Python interop)
  void set_on_use_handler(std::shared_ptr<mettagrid::Handler> handler);
  void set_aoe_configs(std::vector<mettagrid::AOEConfig> configs);
  void set_territory_controls(std::vector<mettagrid::TerritoryControlConfig> controls);
  void set_on_tag_add(std::unordered_map<int, std::vector<std::shared_ptr<mettagrid::Handler>>> handlers);
  void set_on_tag_remove(std::unordered_map<int, std::vector<std::shared_ptr<mettagrid::Handler>>> handlers);

  // Check if this object has an on_use handler
  bool has_on_use_handler() const;

  // Get AOE configs for AOE processing
  const std::vector<mettagrid::AOEConfig>& aoe_configs() const;
  const std::vector<mettagrid::TerritoryControlConfig>& territory_controls() const;

  // Override onUse to try on_use handlers
  bool onUse(Agent& actor, ActionArg arg, const mettagrid::HandlerContext& ctx) override;

  // Tag mutation methods
  bool has_tag(int tag_id) const;

  // Tag mutation with lifecycle handlers (fires on_tag_add/on_tag_remove handlers)
  void add_tag(int tag_id, const mettagrid::HandlerContext& ctx);
  void remove_tag(int tag_id, const mettagrid::HandlerContext& ctx);

  /** Run on_tag_add handlers for a tag that was already added. Used after recompute. */
  void apply_on_tag_add_handlers(int tag_id, const mettagrid::HandlerContext& ctx);

  /** Run on_tag_remove handlers for a tag that was already removed. Used after recompute. */
  void apply_on_tag_remove_handlers(int tag_id, const mettagrid::HandlerContext& ctx);

  // Set observation encoder for inventory token encoding
  void set_obs_encoder(const ObservationEncoder* encoder) {
    obs_encoder = encoder;
  }

  // Returns observable features for this object (tags, vibe, inventory)
  // Subclasses should call this base implementation and append their specific features
  virtual std::vector<PartialObservationToken> obs_features() const;

  // Write observable features directly into provided buffer, returns number of tokens written.
  // This avoids allocation per call - preferred for hot path in observation computation.
  // Subclasses should override and call base implementation first.
  virtual size_t write_obs_features(PartialObservationToken* out, size_t max_tokens) const;

  // Must reflect the maximum number of tokens write_obs_features can emit.
  // Update this if adding new features.
  static size_t max_obs_features(size_t max_tags, size_t num_resources, size_t tokens_per_item);

  const ObservationEncoder* obs_encoder = nullptr;

protected:
  std::shared_ptr<mettagrid::Handler> _on_use_handler;
  std::vector<mettagrid::AOEConfig> _aoe_configs;
  std::vector<mettagrid::TerritoryControlConfig> _territory_controls;

private:
  std::unordered_map<int, std::vector<std::shared_ptr<mettagrid::Handler>>> _on_tag_add;
  std::unordered_map<int, std::vector<std::shared_ptr<mettagrid::Handler>>> _on_tag_remove;
};

#endif  // PACKAGES_METTAGRID_CPP_INCLUDE_METTAGRID_CORE_GRID_OBJECT_HPP_
