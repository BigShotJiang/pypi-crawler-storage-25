#ifndef PACKAGES_METTAGRID_CPP_INCLUDE_METTAGRID_CONFIG_OBSERVATION_FEATURES_HPP_
#define PACKAGES_METTAGRID_CPP_INCLUDE_METTAGRID_CONFIG_OBSERVATION_FEATURES_HPP_

#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>

#include "core/types.hpp"

// Runtime lookup class for observation feature IDs
// This replaces the compile-time constants in ObservationFeature namespace
class ObservationFeaturesImpl {
public:
  // Initialize from feature_ids map (name -> id)
  explicit ObservationFeaturesImpl(const std::unordered_map<std::string, ObservationType>& feature_ids)
      : _name_to_id(feature_ids) {
    // Cache commonly used feature IDs
    _group = get("agent:group");
    _episode_completion_pct = get("episode_completion_pct");
    _last_action = get("last_action");
    _last_reward = get("last_reward");
    _last_action_move = has("last_action_move") ? get("last_action_move") : 0;
    _vibe = get("vibe");
    _tag = get("tag");
    _goal = get("goal");
    _lp_east = has("lp:east") ? get("lp:east") : 0;
    _lp_west = has("lp:west") ? get("lp:west") : 0;
    _lp_north = has("lp:north") ? get("lp:north") : 0;
    _lp_south = has("lp:south") ? get("lp:south") : 0;
    _agent_id = has("agent_id") ? get("agent_id") : 0;
    _territory_here = has("territory:here") ? get("territory:here") : 0;
    _territory_edge_north = has("territory:north") ? get("territory:north") : 0;
    _territory_edge_south = has("territory:south") ? get("territory:south") : 0;
    _territory_edge_east = has("territory:east") ? get("territory:east") : 0;
    _territory_edge_west = has("territory:west") ? get("territory:west") : 0;

    // Initialize public members (must be done AFTER private members are set above)
    Group = _group;
    EpisodeCompletionPct = _episode_completion_pct;
    LastAction = _last_action;
    LastReward = _last_reward;
    LastActionMove = _last_action_move;
    Vibe = _vibe;
    Tag = _tag;
    Goal = _goal;
    LpEast = _lp_east;
    LpWest = _lp_west;
    LpNorth = _lp_north;
    LpSouth = _lp_south;
    AgentId = _agent_id;
    TerritoryHere = _territory_here;
    TerritoryEdgeNorth = _territory_edge_north;
    TerritoryEdgeSouth = _territory_edge_south;
    TerritoryEdgeEast = _territory_edge_east;
    TerritoryEdgeWest = _territory_edge_west;
  }

  // Get feature ID by name (throws if not found)
  ObservationType get(const std::string& name) const {
    auto it = _name_to_id.find(name);
    if (it == _name_to_id.end()) {
      throw std::runtime_error("Unknown observation feature: " + name);
    }
    return it->second;
  }

  // Check if feature exists
  bool has(const std::string& name) const {
    return _name_to_id.find(name) != _name_to_id.end();
  }

  // Commonly used feature IDs (cached for performance)
  ObservationType Group;
  ObservationType EpisodeCompletionPct;
  ObservationType LastAction;
  ObservationType LastReward;
  ObservationType LastActionMove;
  ObservationType Vibe;
  ObservationType Tag;
  ObservationType Goal;
  ObservationType LpEast;
  ObservationType LpWest;
  ObservationType LpNorth;
  ObservationType LpSouth;
  ObservationType AgentId;
  ObservationType TerritoryHere;
  ObservationType TerritoryEdgeNorth;
  ObservationType TerritoryEdgeSouth;
  ObservationType TerritoryEdgeEast;
  ObservationType TerritoryEdgeWest;

private:
  std::unordered_map<std::string, ObservationType> _name_to_id;

  // Cached feature IDs
  ObservationType _group;
  ObservationType _episode_completion_pct;
  ObservationType _last_action;
  ObservationType _last_reward;
  ObservationType _last_action_move;
  ObservationType _vibe;
  ObservationType _tag;
  ObservationType _goal;
  ObservationType _lp_east;
  ObservationType _lp_west;
  ObservationType _lp_north;
  ObservationType _lp_south;
  ObservationType _agent_id;
  ObservationType _territory_here;
  ObservationType _territory_edge_north;
  ObservationType _territory_edge_south;
  ObservationType _territory_edge_east;
  ObservationType _territory_edge_west;
};

// Global singleton instance
// This is initialized by MettaGrid constructor and provides the same syntax as the old namespace
namespace ObservationFeature {
extern std::shared_ptr<ObservationFeaturesImpl> _instance;

// Initialize the singleton (called by MettaGrid)
void Initialize(const std::unordered_map<std::string, ObservationType>& feature_ids);

// Access feature IDs with the same syntax as before: ObservationFeature::X
// These are extern variables defined in observation_features.cpp
extern ObservationType Group;
extern ObservationType EpisodeCompletionPct;
extern ObservationType LastAction;
extern ObservationType LastReward;
extern ObservationType LastActionMove;
extern ObservationType Vibe;
extern ObservationType Tag;
extern ObservationType Goal;
extern ObservationType LpEast;
extern ObservationType LpWest;
extern ObservationType LpNorth;
extern ObservationType LpSouth;
extern ObservationType AgentId;
extern ObservationType TerritoryHere;
extern ObservationType TerritoryEdgeNorth;
extern ObservationType TerritoryEdgeSouth;
extern ObservationType TerritoryEdgeEast;
extern ObservationType TerritoryEdgeWest;
}  // namespace ObservationFeature

#endif  // PACKAGES_METTAGRID_CPP_INCLUDE_METTAGRID_CONFIG_OBSERVATION_FEATURES_HPP_
