#ifndef PACKAGES_METTAGRID_CPP_BINDINGS_METTAGRID_C_HPP_
#define PACKAGES_METTAGRID_CPP_BINDINGS_METTAGRID_C_HPP_

#define PYBIND11_DETAILED_ERROR_MESSAGES

#if defined(_WIN32)
#define METTAGRID_API __declspec(dllexport)
#else
#define METTAGRID_API __attribute__((visibility("default")))
#endif

#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <memory>
#include <optional>
#include <random>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "config/mettagrid_config.hpp"
#include "core/aoe_tracker.hpp"
#include "core/game_value_config.hpp"
#include "core/grid_object.hpp"
#include "core/query_system.hpp"
#include "core/tag_index.hpp"
#include "core/territory_tracker.hpp"
#include "core/types.hpp"
#include "core/vision.hpp"
#include "handler/event_scheduler.hpp"
#include "handler/handler.hpp"
#include "handler/handler_context.hpp"
#include "profiling.hpp"
#include "systems/encoding_utils.hpp"
#include "systems/packed_coordinate.hpp"

// Forward declarations of existing C++ classes
class Grid;
class StatsTracker;
class ActionHandler;
class Action;
class Agent;
class ObservationEncoder;
class GridObject;

struct GridObjectConfig;
struct WallConfig;
struct AgentConfig;
struct GameConfig;
struct ActionConfig;
struct AttackActionConfig;
struct ChangeVibeActionConfig;

namespace py = pybind11;

class METTAGRID_API MettaGrid {
public:
  MettaGrid(const GameConfig& cfg, py::list map, unsigned int seed);
  ~MettaGrid();

  ObservationCoord obs_width;
  ObservationCoord obs_height;

  unsigned int current_step;
  unsigned int max_steps;
  bool episode_truncates;

  std::vector<std::string> resource_names;
  std::vector<std::string> object_type_names;
  std::unordered_map<ObservationType, std::string> feature_id_to_name;

  // Python API methods
  // In general, these types need to match what puffer wants to use.
  void step();
  void set_buffers(const py::array_t<ObservationType, py::array::c_style>& observations,
                   const py::array_t<TerminalType, py::array::c_style>& terminals,
                   const py::array_t<TruncationType, py::array::c_style>& truncations,
                   const py::array_t<RewardType, py::array::c_style>& rewards,
                   const py::array_t<ActionType, py::array::c_style>& actions);
  void set_buffers(const py::array_t<ObservationType, py::array::c_style>& observations,
                   const py::array_t<TerminalType, py::array::c_style>& terminals,
                   const py::array_t<TruncationType, py::array::c_style>& truncations,
                   const py::array_t<RewardType, py::array::c_style>& rewards,
                   const py::array_t<ActionType, py::array::c_style>& actions,
                   const py::array_t<ActionType, py::array::c_style>& vibe_actions);
  void validate_buffers();
  py::dict grid_objects(py::object self_ref,
                        int min_row = -1,
                        int max_row = -1,
                        int min_col = -1,
                        int max_col = -1,
                        const py::list& ignore_types = py::list());

  py::array_t<ObservationType> observations();
  py::array_t<TerminalType> terminals();
  py::array_t<TruncationType> truncations();
  py::array_t<RewardType> rewards();
  py::array_t<MaskType> masks();
  py::array_t<ActionType> actions();
  py::array_t<ActionType> vibe_actions();

  GridCoord map_width();
  GridCoord map_height();
  py::none set_inventory(GridObjectId agent_id, const std::unordered_map<InventoryItem, InventoryQuantity>& inventory);
  py::array_t<float> get_episode_rewards();
  py::dict get_episode_stats();
  std::optional<float> get_game_stat(const std::string& key) const;
  std::optional<float> get_agent_stat(uint32_t agent_id, const std::string& key) const;
  int resolve_game_value(const GameValueConfig& game_value);
  py::dict resolve_game_values();
  py::list action_success_py();

  using Actions = py::array_t<ActionType, py::array::c_style>;
  using ActionSuccess = std::vector<bool>;

  const Grid& grid() const {
    return *_grid;
  }
  const ActionSuccess& action_success() const {
    return _action_success;
  }

  const Agent* agent(uint32_t agent_id) const {
    return _agents[agent_id];
  }

  mettagrid::TagIndex& tag_index() {
    return _tag_index;
  }

  // Performance instrumentation: time spent computing observations in last step (nanoseconds)
  double last_obs_time_ns() const {
    return _step_timing.observations_ns;
  }

  const StepTimingStats& step_timing() const {
    return _step_timing;
  }

  // Validation statistics for observations path comparison
  struct ObsValidationStats {
    uint64_t comparison_count = 0;
    uint64_t mismatch_count = 0;
    double original_time_ns = 0;
    double optimized_time_ns = 0;
  };

  const ObsValidationStats& obs_validation_stats() const {
    return _obs_validation_stats;
  }

private:
  bool _profiling_enabled = false;
  StepTimingStats _step_timing;

  // Validation configuration (read from environment variables at construction)
  bool _validation_enabled = false;
  bool _use_optimized_primary = false;
  ObsValidationStats _obs_validation_stats;

  // Shadow buffer for validation comparison (allocated if validation enabled)
  std::vector<ObservationType> _shadow_obs_buffer;
  // Member variables
  GlobalObsConfig _global_obs_config;
  GameConfig _game_config;

  std::unique_ptr<Grid> _grid;

  Actions _actions;
  Actions _vibe_actions;
  std::vector<Action> _action_handlers;  // All actions from all handlers
  std::vector<bool> _action_is_vibe;
  std::vector<std::unique_ptr<ActionHandler>> _action_handler_impl;  // Owns the ActionHandler objects
  unsigned char _max_action_priority;

  std::unique_ptr<ObservationEncoder> _obs_encoder;
  std::unique_ptr<StatsTracker> _stats;
  std::unique_ptr<ObservationTokenEncoder> _token_encoder;

  size_t _num_observation_tokens;

  // TODO: currently these are owned and destroyed by the grid, but we should
  // probably move ownership here.
  std::vector<Agent*> _agents;

  // We'd prefer to store these as more raw c-style arrays, but we need to both
  // operate on the memory directly and return them to python.
  py::array_t<uint8_t> _observations;
  py::array_t<bool> _terminals;
  py::array_t<bool> _truncations;
  py::array_t<float> _rewards;
  py::array_t<float> _episode_rewards;

  ActionSuccess _action_success;
  std::vector<ActionType> _last_executed_actions;

  std::mt19937 _rng;
  unsigned int _seed;

  // Global systems
  std::unique_ptr<mettagrid::AOETracker> _aoe_tracker;
  std::unique_ptr<mettagrid::TerritoryTracker> _territory_tracker;
  std::unique_ptr<mettagrid::EventScheduler> _event_scheduler;
  std::unique_ptr<mettagrid::QuerySystem> _query_system;

  // Tag index for efficient tag-based object lookup
  mettagrid::TagIndex _tag_index;

  // Game-level on_tick handler executed every step
  std::shared_ptr<mettagrid::Handler> _game_on_tick;

  // Base HandlerContext with all system pointers — copied and specialized per interaction
  mettagrid::HandlerContext _game_ctx;

  // Pre-computed observation pattern offsets (Manhattan distance order)
  std::vector<std::pair<int, int>> _observation_offsets;

  // Precomputed shadow masks for this env's observation window. Geometric only
  // — no grid/observer dependence — so a single read-only copy is shared
  // across the serial and parallel observation paths.
  mettagrid::ShadowTable _shadow_table;

  // Per-thread buffers for observation computation (at least 1, used by serial path too)
  struct ObsComputeBuffers {
    std::vector<PartialObservationToken> global_tokens;
    std::vector<PartialObservationToken> obs_features_scratch;
    std::vector<mettagrid::ObservedTerritory> territory_observations;
    // Line-of-sight mask over the observation rectangle (row-major, obs_height * obs_width).
    // 1 = visible from observer, 0 = hidden by a blocker.
    std::vector<uint8_t> visibility_bitmap;
    size_t tokens_written = 0;
    size_t tokens_dropped = 0;
    size_t tokens_free_space = 0;
    bool token_budget_exceeded = false;
    size_t overflow_agent_idx = 0;
    size_t overflow_attempted_tokens = 0;
    size_t overflow_buffer_capacity = 0;
    void reset_stats() {
      tokens_written = tokens_dropped = tokens_free_space = 0;
      token_budget_exceeded = false;
      overflow_agent_idx = overflow_attempted_tokens = overflow_buffer_capacity = 0;
    }
  };
  std::vector<ObsComputeBuffers> _obs_thread_buffers;

  // Previous agent locations (captured at the start of each step) for last_action_move tokens.
  std::vector<GridLocation> _prev_agent_locations;

  // Pre-resolved stat IDs for hot-path stats (avoids string hashing per agent per step)
  uint16_t _stat_tokens_written = 0;
  uint16_t _stat_tokens_dropped = 0;
  uint16_t _stat_tokens_free_space = 0;

  // Parallel observation worker pool (declared last so workers are destroyed first)
  unsigned int _obs_thread_count = 1;
  // Per-worker atomic flags: main sets to 1 to start, worker resets to 0 when done
  std::vector<std::unique_ptr<std::atomic<int>>> _obs_worker_flags;
  const std::vector<ActionType>* _obs_current_actions = nullptr;
  std::atomic<bool> _obs_workers_stop{false};
  std::vector<std::thread> _obs_workers;  // must be last: destroyed first → joins before deps

  void init_action_handlers();
  size_t _emit_obs_value_tokens(size_t agent_idx, size_t tokens_written, ObservationType global_location);
  void _prepare_territory_observations(ObservationCoord observable_width,
                                       ObservationCoord observable_height,
                                       size_t agent_idx,
                                       std::vector<PartialObservationToken>& global_tokens,
                                       std::vector<mettagrid::ObservedTerritory>& territory_observations) const;
  void _throw_observation_token_overflow(size_t agent_idx,
                                         size_t attempted_tokens_written,
                                         size_t buffer_capacity) const;
  void add_agent(Agent* agent);
  void _init_grid(const GameConfig& game_config, const py::list& map);
  void _make_buffers(unsigned int num_agents);
  void _init_buffers(unsigned int num_agents);
  // Dispatcher: routes to original or optimized based on validation config
  void _compute_observation(GridCoord observer_r,
                            GridCoord observer_c,
                            ObservationCoord obs_width,
                            ObservationCoord obs_height,
                            size_t agent_idx,
                            ActionType action);

  // Original path: matches main branch behavior (uses ObservationPattern iterator, allocates per call)
  void _compute_observation_original(GridCoord observer_r,
                                     GridCoord observer_c,
                                     ObservationCoord obs_width,
                                     ObservationCoord obs_height,
                                     size_t agent_idx,
                                     ActionType action);

  // Optimized path: pre-computed offsets, buffer reuse, direct encoding
  void _compute_observation_optimized(GridCoord observer_r,
                                      GridCoord observer_c,
                                      ObservationCoord obs_width,
                                      ObservationCoord obs_height,
                                      size_t agent_idx,
                                      ActionType action);

  // Optimized path with explicit buffer (thread-safe, used by parallel dispatch)
  void _compute_observation_optimized(GridCoord observer_r,
                                      GridCoord observer_c,
                                      ObservationCoord obs_width,
                                      ObservationCoord obs_height,
                                      size_t agent_idx,
                                      ActionType action,
                                      ObsComputeBuffers& buffers);

  // Shadow validation helper: runs secondary path, compares, logs mismatches
  void _shadow_validate_observation(GridCoord observer_r,
                                    GridCoord observer_c,
                                    ObservationCoord obs_width,
                                    ObservationCoord obs_height,
                                    size_t agent_idx,
                                    ActionType action,
                                    double primary_time_ns,
                                    bool primary_was_optimized);

  void _compute_observations(const std::vector<ActionType>& executed_actions);
  void _step();
  std::pair<ObservationCoord, ObservationCoord> _observable_window(size_t agent_idx) const;

  void _handle_invalid_action(size_t agent_idx, const std::string& stat, ActionType type);
  AgentConfig _create_agent_config(const py::dict& agent_group_cfg_py);
  WallConfig _create_wall_config(const py::dict& wall_cfg_py);
};

#endif  // PACKAGES_METTAGRID_CPP_BINDINGS_METTAGRID_C_HPP_
