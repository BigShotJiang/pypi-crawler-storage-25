#include "bindings/mettagrid_c.hpp"

#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include "actions/action_handler.hpp"
#include "actions/action_handler_factory.hpp"
#include "actions/attack.hpp"
#include "actions/change_vibe.hpp"
#include "actions/move_config.hpp"
#include "config/observation_features.hpp"
#include "core/grid.hpp"
#include "core/grid_object_factory.hpp"
#include "core/observation_shape.hpp"
#include "core/types.hpp"
#include "core/vision.hpp"
#include "handler/handler_bindings.hpp"
#include "handler/handler_context.hpp"
#include "objects/agent.hpp"
#include "objects/constants.hpp"
#include "objects/inventory_config.hpp"
#include "objects/protocol.hpp"
#include "objects/wall.hpp"
#include "systems/observation_encoder.hpp"
#include "systems/packed_coordinate.hpp"
#include "systems/stats_tracker.hpp"

namespace py = pybind11;

namespace {
bool territory_edge_features_enabled() {
  return ObservationFeature::TerritoryEdgeNorth != 0 || ObservationFeature::TerritoryEdgeSouth != 0 ||
         ObservationFeature::TerritoryEdgeEast != 0 || ObservationFeature::TerritoryEdgeWest != 0;
}

void emit_tile_territory_tokens(const std::vector<mettagrid::ObservedTerritory>& territory_observations,
                                ObservationCoord observable_width,
                                ObservationCoord observable_height,
                                uint8_t obs_row,
                                uint8_t obs_col,
                                uint8_t location,
                                ObservationToken*& obs_ptr,
                                size_t& tokens_written,
                                size_t& attempted_tokens_written,
                                size_t buffer_capacity) {
  if (territory_observations.empty()) {
    return;
  }
  constexpr ObservationType kNoTerritoryObservation = std::numeric_limits<ObservationType>::max();
  constexpr ObservationType kOtherTerritory = 2;
  size_t index = static_cast<size_t>(obs_row) * static_cast<size_t>(observable_width) + static_cast<size_t>(obs_col);
  const auto& token_tile = territory_observations[index];
  if (token_tile.label == kNoTerritoryObservation) {
    return;
  }

  // Edge values are encoded relative to the tile carrying the token: token tile -> neighbor.
  auto emit_edge = [&](ObservationType feature_id, ObservationType neighbor_territory) {
    attempted_tokens_written += 1;
    if (tokens_written >= buffer_capacity) {
      return;
    }
    obs_ptr[0].location = location;
    obs_ptr[0].feature_id = feature_id;
    obs_ptr[0].value = static_cast<ObservationType>(token_tile.label * 3 + neighbor_territory);
    obs_ptr += 1;
    tokens_written += 1;
  };

  auto territory_at = [&](int row, int col) -> mettagrid::ObservedTerritory {
    if (row < 0 || row >= observable_height || col < 0 || col >= observable_width) {
      return {.label = kNoTerritoryObservation};
    }
    return territory_observations[static_cast<size_t>(row) * static_cast<size_t>(observable_width) +
                                  static_cast<size_t>(col)];
  };

  auto emit_if_territory_changes = [&](ObservationType feature_id, int row, int col) {
    const auto neighbor = territory_at(row, col);
    bool distinct_other_boundary =
        token_tile.label == kOtherTerritory && neighbor.label == kOtherTerritory && token_tile.winning_tag >= 0 &&
        neighbor.winning_tag >= 0 && token_tile.winning_tag != neighbor.winning_tag;
    if (feature_id != 0 && neighbor.label != kNoTerritoryObservation &&
        (neighbor.label != token_tile.label || distinct_other_boundary)) {
      emit_edge(feature_id, neighbor.label);
    }
  };

  emit_if_territory_changes(ObservationFeature::TerritoryEdgeNorth, static_cast<int>(obs_row) - 1, obs_col);
  emit_if_territory_changes(ObservationFeature::TerritoryEdgeSouth, static_cast<int>(obs_row) + 1, obs_col);
  emit_if_territory_changes(ObservationFeature::TerritoryEdgeEast, obs_row, static_cast<int>(obs_col) + 1);
  emit_if_territory_changes(ObservationFeature::TerritoryEdgeWest, obs_row, static_cast<int>(obs_col) - 1);
}
}  // namespace

MettaGrid::MettaGrid(const GameConfig& game_config, const py::list map, unsigned int seed)
    : obs_width(game_config.obs_width),
      obs_height(game_config.obs_height),
      max_steps(game_config.max_steps),
      episode_truncates(game_config.episode_truncates),
      resource_names(game_config.resource_names),
      _global_obs_config(game_config.global_obs),
      _game_config(game_config),
      _num_observation_tokens(game_config.num_observation_tokens) {
  _seed = seed;
  _rng = std::mt19937(seed);

  const char* profiling_env = std::getenv("METTAGRID_PROFILING");
  _profiling_enabled = profiling_env && std::string(profiling_env) == "1";

  // `map` is a list of lists of strings, which are the map cells.

  unsigned int num_agents = static_cast<unsigned int>(game_config.num_agents);

  current_step = 0;

  bool observation_size_is_packable =
      obs_width <= PackedCoordinate::MAX_PACKABLE_COORD + 1 && obs_height <= PackedCoordinate::MAX_PACKABLE_COORD + 1;
  if (!observation_size_is_packable) {
    throw std::runtime_error("Observation window size (" + std::to_string(obs_width) + "x" +
                             std::to_string(obs_height) + ") exceeds maximum packable size");
  }

  // Pre-compute in-vision observation offsets (Manhattan distance order).
  mettagrid::compute_observation_offsets(obs_height, obs_width, _observation_offsets);

  // Precompute per-cell shadow masks for this window's geometry. Used every
  // tick by both observation paths; depends only on (obs_height, obs_width).
  _shadow_table = mettagrid::ShadowTable(obs_height, obs_width);

  // Parallel observation dispatch is opt-in until validated on production
  // EPYC hardware. Set METTAGRID_OBS_THREADS to enable:
  //   "auto" → heuristic clamp(num_agents / 4, 1, 6)
  //   "N"    → explicit thread count
  // Default (unset) → serial (1 thread).
  //
  // After EPYC validation: remove this if-block and let the heuristic
  // run unconditionally (i.e., just keep the clamp line below).
  //
  // Heuristic notes (M2 Pro benchmarks, 8-100 agents):
  // 4 threads optimal; 8 threads regresses due to shared L2 contention.
  // Cap of 6 is conservative; EPYC 7R13 (private 512KB L2 per core) may
  // justify a higher cap.
  _obs_thread_count = 1;
  if (const char* val = std::getenv("METTAGRID_OBS_THREADS")) {
    std::string s(val);
    if (s == "auto") {
      _obs_thread_count = std::clamp(num_agents / 4u, 1u, 6u);
    } else {
      unsigned int n = static_cast<unsigned int>(std::stoul(s));
      if (n > 0) _obs_thread_count = n;
    }
  }

  // Allocate per-thread observation buffers
  {
    size_t max_tags = game_config.tag_id_map.size();
    size_t num_resources = resource_names.size();
    size_t tokens_per_item = ObservationEncoder::compute_num_tokens(65535, game_config.token_value_base);
    _obs_thread_buffers.resize(_obs_thread_count);
    for (auto& buf : _obs_thread_buffers) {
      buf.global_tokens.reserve(32);
      buf.obs_features_scratch.resize(Agent::max_obs_features(max_tags, num_resources, tokens_per_item));
      buf.territory_observations.reserve(
          static_cast<size_t>(game_config.obs_width) * static_cast<size_t>(game_config.obs_height));
      buf.visibility_bitmap.resize(static_cast<size_t>(obs_width) * static_cast<size_t>(obs_height), 0);
    }
  }

  GridCoord height = static_cast<GridCoord>(py::len(map));
  GridCoord width = static_cast<GridCoord>(py::len(map[0]));

  _grid = std::make_unique<Grid>(height, width);
  _aoe_tracker = std::make_unique<mettagrid::AOETracker>(height, width);
  _territory_tracker = std::make_unique<mettagrid::TerritoryTracker>(height, width, game_config.territories);

  auto* territory_tracker = _territory_tracker.get();
  _grid->on_object_moved = [territory_tracker](GridObject& obj, const GridLocation& old_loc) {
    territory_tracker->notify_source_moved(obj, old_loc);
  };
  _obs_encoder = std::make_unique<ObservationEncoder>(
      game_config.protocol_details_obs, resource_names, game_config.feature_ids, game_config.token_value_base);

  // Initialize ObservationFeature namespace with feature IDs
  ObservationFeature::Initialize(game_config.feature_ids);

  // Initialize feature_id_to_name map from GameConfig
  for (const auto& [name, id] : game_config.feature_ids) {
    feature_id_to_name[id] = name;
  }

  _stats = std::make_unique<StatsTracker>(&resource_names);

  // Pre-resolve stat IDs for hot-path observation stats (avoids string hashing per agent per step)
  _stat_tokens_written = _stats->get_or_create_id("tokens_written");
  _stat_tokens_dropped = _stats->get_or_create_id("tokens_dropped");
  _stat_tokens_free_space = _stats->get_or_create_id("tokens_free_space");
  _token_encoder = std::make_unique<ObservationTokenEncoder>(_game_config.token_value_base);

  _action_success.resize(num_agents);
  _last_executed_actions.resize(num_agents, ActionType(0));

  init_action_handlers();

  _init_grid(game_config, map);

  _prev_agent_locations.resize(_agents.size());
  for (size_t i = 0; i < _agents.size(); ++i) {
    _prev_agent_locations[i] = _agents[i]->location;
  }

  // Set game-level on_tick handler
  _game_on_tick = game_config.on_tick;

  // Initialize QuerySystem — always created so inline queries in filters/mutations work
  _query_system = std::make_unique<mettagrid::QuerySystem>(game_config.materialized_queries);

  // Initialize base HandlerContext with all system pointers
  _game_ctx = mettagrid::HandlerContext(&_tag_index, _grid.get(), _stats.get(), _query_system.get(), &_rng);
  _game_ctx.game_config = &_game_config;
  _game_ctx.aoe_tracker = _aoe_tracker.get();

  // Compute initial query tags
  _query_system->compute_all(_game_ctx);

  // Initialize EventScheduler from config
  if (!game_config.events.empty()) {
    _event_scheduler = std::make_unique<mettagrid::EventScheduler>(game_config.events);
  }

  // Initialize reward entries (resolve stat names to IDs, get pointers)
  for (auto* agent : _agents) {
    agent->init_reward(_game_ctx);
  }

  // Validation configuration from environment variables
  if (const char* val = std::getenv("METTAGRID_OBS_VALIDATION")) {
    _validation_enabled = (std::string(val) == "1");
  }
  _use_optimized_primary = true;
  if (const char* val = std::getenv("METTAGRID_OBS_USE_OPTIMIZED")) {
    _use_optimized_primary = (std::string(val) == "1");
  }

  if (_validation_enabled) {
    std::cerr << "[METTAGRID OBS_VALIDATION] ENABLED, primary=" << (_use_optimized_primary ? "optimized" : "original")
              << std::endl;
  }

  // Create buffers
  _make_buffers(num_agents);
}

std::pair<ObservationCoord, ObservationCoord> MettaGrid::_observable_window(size_t agent_idx) const {
  if (!_game_config.observation_radius_value.has_value()) {
    return {obs_width, obs_height};
  }

  mettagrid::HandlerContext value_ctx = _game_ctx;
  value_ctx.actor = _agents[agent_idx];
  float raw_radius = value_ctx.resolve_game_value(*_game_config.observation_radius_value, mettagrid::EntityRef::actor);
  int radius = static_cast<int>(std::max(0.0f, raw_radius));

  ObservationCoord visible_height =
      static_cast<ObservationCoord>(std::min(static_cast<int>(obs_height), radius * 2 + 1));
  ObservationCoord visible_width =
      static_cast<ObservationCoord>(std::min(static_cast<int>(obs_width), radius * 2 + 1));
  return {visible_width, visible_height};
}

MettaGrid::~MettaGrid() {
  // Signal all workers to stop and wake them so they can exit
  _obs_workers_stop.store(true, std::memory_order_release);
  for (auto& f : _obs_worker_flags) f->store(1, std::memory_order_release);
  for (auto& w : _obs_workers) w.join();
}

void MettaGrid::_init_grid(const GameConfig& game_config, const py::list& map) {
  GridCoord height = static_cast<GridCoord>(py::len(map));
  GridCoord width = static_cast<GridCoord>(py::len(map[0]));

  object_type_names.resize(game_config.objects.size());

  for (const auto& [key, object_cfg] : game_config.objects) {
    TypeId type_id = object_cfg->type_id;

    if (type_id >= object_type_names.size()) {
      // Sometimes the type_ids are not contiguous, so we need to resize the vector.
      object_type_names.resize(type_id + 1);
    }

    if (object_type_names[type_id] != "" && object_type_names[type_id] != object_cfg->type_name) {
      throw std::runtime_error("Object type_id " + std::to_string(type_id) + " already exists with type_name " +
                               object_type_names[type_id] + ". Trying to add " + object_cfg->type_name + ".");
    }
    object_type_names[type_id] = object_cfg->type_name;
  }

  // Initialize objects from map
  for (GridCoord r = 0; r < height; r++) {
    for (GridCoord c = 0; c < width; c++) {
      auto py_cell = map[r].cast<py::list>()[c].cast<py::str>();
      auto cell = py_cell.cast<std::string>();

      // #HardCodedConfig
      if (cell == "empty" || cell == "." || cell == " ") {
        continue;
      }

      if (!game_config.objects.contains(cell)) {
        throw std::runtime_error("Unknown object type: " + cell);
      }

      const GridObjectConfig* object_cfg = game_config.objects.at(cell).get();

      // Create object from config using the factory
      GridObject* created_object = mettagrid::create_object_from_config(
          r, c, object_cfg, _stats.get(), &resource_names, _grid.get(), _obs_encoder.get(), &current_step, &_tag_index);

      // Add to grid and track stats
      _grid->add_object(created_object);
      _stats->incr("objects." + cell);

      // Register the object with the tag index
      _tag_index.register_object(created_object);

      // Register AOE configs for this object (possibly none)
      for (const auto& aoe_config : created_object->aoe_configs()) {
        _aoe_tracker->register_source(*created_object, aoe_config);
      }

      // Register territory controls for this object (possibly none)
      for (const auto& control : created_object->territory_controls()) {
        _territory_tracker->register_source(*created_object, control);
      }

      // Handle agent-specific setup (agent_id and registration)
      if (Agent* agent = dynamic_cast<Agent*>(created_object)) {
        if (_agents.size() > std::numeric_limits<decltype(agent->agent_id)>::max()) {
          throw std::runtime_error("Too many agents for agent_id type");
        }
        agent->agent_id = static_cast<decltype(agent->agent_id)>(_agents.size());
        add_agent(agent);
      }
    }
  }
}

void MettaGrid::_make_buffers(unsigned int num_agents) {
  // Create and set buffers
  std::vector<ssize_t> shape;
  shape = {static_cast<ssize_t>(num_agents), static_cast<ssize_t>(_num_observation_tokens), static_cast<ssize_t>(3)};
  auto observations = py::array_t<ObservationType, py::array::c_style>(shape);
  auto terminals =
      py::array_t<TerminalType, py::array::c_style>({static_cast<ssize_t>(num_agents)}, {sizeof(TerminalType)});
  auto truncations =
      py::array_t<TruncationType, py::array::c_style>({static_cast<ssize_t>(num_agents)}, {sizeof(TruncationType)});
  auto rewards = py::array_t<RewardType, py::array::c_style>({static_cast<ssize_t>(num_agents)}, {sizeof(RewardType)});
  auto actions = py::array_t<ActionType, py::array::c_style>(std::vector<ssize_t>{static_cast<ssize_t>(num_agents)});
  auto vibe_actions =
      py::array_t<ActionType, py::array::c_style>(std::vector<ssize_t>{static_cast<ssize_t>(num_agents)});
  auto action_ptr = static_cast<ActionType*>(actions.request().ptr);
  auto vibe_action_ptr = static_cast<ActionType*>(vibe_actions.request().ptr);
  std::fill(action_ptr, action_ptr + num_agents, ActionType(0));
  std::fill(vibe_action_ptr, vibe_action_ptr + num_agents, ActionType(0));
  this->_episode_rewards =
      py::array_t<float, py::array::c_style>({static_cast<ssize_t>(num_agents)}, {sizeof(RewardType)});

  set_buffers(observations, terminals, truncations, rewards, actions, vibe_actions);
}

void MettaGrid::_init_buffers(unsigned int num_agents) {
  assert(current_step == 0 && "current_step should be initialized to 0 at the start of _init_buffers");

  // Clear all buffers
  std::fill(static_cast<bool*>(_terminals.request().ptr),
            static_cast<bool*>(_terminals.request().ptr) + _terminals.size(),
            0);
  std::fill(static_cast<bool*>(_truncations.request().ptr),
            static_cast<bool*>(_truncations.request().ptr) + _truncations.size(),
            0);
  std::fill(static_cast<float*>(_episode_rewards.request().ptr),
            static_cast<float*>(_episode_rewards.request().ptr) + _episode_rewards.size(),
            0.0f);
  std::fill(
      static_cast<float*>(_rewards.request().ptr), static_cast<float*>(_rewards.request().ptr) + _rewards.size(), 0.0f);

  // Clear observations
  auto obs_ptr = static_cast<uint8_t*>(_observations.request().ptr);
  auto obs_size = _observations.size();
  std::fill(obs_ptr, obs_ptr + obs_size, EmptyTokenByte);

  // Compute initial observations. Every agent starts with a noop.
  std::vector<ActionType> executed_actions(_agents.size());
  std::fill(executed_actions.begin(), executed_actions.end(), ActionType(0));
  _compute_observations(executed_actions);
}

void MettaGrid::init_action_handlers() {
  auto result = create_action_handlers(_game_config);
  _max_action_priority = result.max_priority;
  _action_handlers = std::move(result.actions);
  _action_handler_impl = std::move(result.handlers);
  _action_is_vibe.resize(_action_handlers.size());
  for (size_t i = 0; i < _action_handlers.size(); ++i) {
    _action_is_vibe[i] = _action_handlers[i].name().rfind("change_vibe_", 0) == 0;
  }
}

void MettaGrid::add_agent(Agent* agent) {
  agent->init(&_rewards.mutable_unchecked<1>()(_agents.size()));
  _agents.push_back(agent);
}

void MettaGrid::_prepare_territory_observations(ObservationCoord observable_width,
                                                ObservationCoord observable_height,
                                                size_t agent_idx,
                                                std::vector<PartialObservationToken>& global_tokens,
                                                std::vector<mettagrid::ObservedTerritory>& territory_observations) const {
  const auto& observer = *_agents[agent_idx];

  if (ObservationFeature::TerritoryHere != 0) {
    auto observed = _territory_tracker->observed_territory_at(observer.location, observer);
    global_tokens.push_back({ObservationFeature::TerritoryHere, observed.label});
  }

  if (!territory_edge_features_enabled()) {
    territory_observations.clear();
    return;
  }

  constexpr ObservationType kNoTerritoryObservation = std::numeric_limits<ObservationType>::max();
  territory_observations.assign(static_cast<size_t>(observable_width) * static_cast<size_t>(observable_height),
                                mettagrid::ObservedTerritory{.label = kNoTerritoryObservation});

  ObservationCoord obs_width_radius = observable_width >> 1;
  ObservationCoord obs_height_radius = observable_height >> 1;
  GridCoord observer_row = observer.location.r;
  GridCoord observer_col = observer.location.c;

  for (const auto& [r_offset, c_offset] : _observation_offsets) {
    int obs_r = static_cast<int>(obs_height_radius) + r_offset;
    int obs_c = static_cast<int>(obs_width_radius) + c_offset;
    int map_r = static_cast<int>(observer_row) + r_offset;
    int map_c = static_cast<int>(observer_col) + c_offset;
    if (map_r < 0 || map_r >= static_cast<int>(_grid->height) || map_c < 0 || map_c >= static_cast<int>(_grid->width)) {
      continue;
    }

    auto observed = _territory_tracker->observed_territory_at(
        GridLocation(static_cast<GridCoord>(map_r), static_cast<GridCoord>(map_c)), observer);
    size_t index = static_cast<size_t>(obs_r) * static_cast<size_t>(observable_width) + static_cast<size_t>(obs_c);
    territory_observations[index] = observed;
  }
}

void MettaGrid::_throw_observation_token_overflow(size_t agent_idx,
                                                  size_t attempted_tokens_written,
                                                  size_t buffer_capacity) const {
  const auto& location = _agents[agent_idx]->location;
  std::string message = "Observation token budget exceeded for agent " + std::to_string(agent_idx) + " at step " +
                        std::to_string(current_step) + " (location=" + std::to_string(location.r) + "," +
                        std::to_string(location.c) + ", budget=" + std::to_string(buffer_capacity) +
                        ", attempted=" + std::to_string(attempted_tokens_written) + ", dropped=" +
                        std::to_string(attempted_tokens_written - buffer_capacity) + ")";
  std::cerr << "[MettaGrid] " << message << std::endl;
  throw std::runtime_error(message);
}

// Dispatcher: routes to original or optimized based on validation config
void MettaGrid::_compute_observation(GridCoord observer_row,
                                     GridCoord observer_col,
                                     ObservationCoord observable_width,
                                     ObservationCoord observable_height,
                                     size_t agent_idx,
                                     ActionType action) {
  if (_use_optimized_primary) {
    if (_validation_enabled) {
      auto start = std::chrono::steady_clock::now();
      _compute_observation_optimized(
          observer_row, observer_col, observable_width, observable_height, agent_idx, action);
      auto end = std::chrono::steady_clock::now();
      double elapsed_ns = std::chrono::duration<double, std::nano>(end - start).count();
      _shadow_validate_observation(
          observer_row, observer_col, observable_width, observable_height, agent_idx, action, elapsed_ns, true);
    } else {
      _compute_observation_optimized(
          observer_row, observer_col, observable_width, observable_height, agent_idx, action);
    }
  } else {
    if (_validation_enabled) {
      auto start = std::chrono::steady_clock::now();
      _compute_observation_original(observer_row, observer_col, observable_width, observable_height, agent_idx, action);
      auto end = std::chrono::steady_clock::now();
      double elapsed_ns = std::chrono::duration<double, std::nano>(end - start).count();
      _shadow_validate_observation(
          observer_row, observer_col, observable_width, observable_height, agent_idx, action, elapsed_ns, false);
    } else {
      _compute_observation_original(observer_row, observer_col, observable_width, observable_height, agent_idx, action);
    }
  }
}

// Shadow validation: runs the other path and compares outputs
void MettaGrid::_shadow_validate_observation(GridCoord observer_row,
                                             GridCoord observer_col,
                                             ObservationCoord observable_width,
                                             ObservationCoord observable_height,
                                             size_t agent_idx,
                                             ActionType action,
                                             double primary_time_ns,
                                             bool primary_was_optimized) {
  auto observation_view = _observations.mutable_unchecked<3>();
  size_t num_tokens = static_cast<size_t>(observation_view.shape(1));
  size_t token_size = static_cast<size_t>(observation_view.shape(2));
  size_t agent_obs_size = num_tokens * token_size;

  // Ensure shadow buffer is sized correctly
  if (_shadow_obs_buffer.size() < agent_obs_size) {
    _shadow_obs_buffer.resize(agent_obs_size);
  }

  // Save current observation to shadow buffer
  ObservationType* primary_obs = observation_view.mutable_data(agent_idx, 0, 0);
  std::copy(primary_obs, primary_obs + agent_obs_size, _shadow_obs_buffer.begin());

  // Clear observation buffer and run secondary path.
  // NOTE: This temporarily corrupts the agent's observation buffer. Safe only because
  // observations are computed sequentially per agent (no concurrent readers).
  std::fill(primary_obs, primary_obs + agent_obs_size, EmptyTokenByte);

  auto start = std::chrono::steady_clock::now();
  if (primary_was_optimized) {
    _compute_observation_original(observer_row, observer_col, observable_width, observable_height, agent_idx, action);
  } else {
    _compute_observation_optimized(observer_row, observer_col, observable_width, observable_height, agent_idx, action);
  }
  auto end = std::chrono::steady_clock::now();
  double secondary_time_ns = std::chrono::duration<double, std::nano>(end - start).count();

  // Compare outputs
  bool mismatch = false;
  size_t first_mismatch_idx = 0;
  for (size_t i = 0; i < agent_obs_size; ++i) {
    if (_shadow_obs_buffer[i] != primary_obs[i]) {
      mismatch = true;
      first_mismatch_idx = i;
      break;
    }
  }

  // Update stats
  _obs_validation_stats.comparison_count++;
  if (mismatch) {
    _obs_validation_stats.mismatch_count++;
    // Log first few mismatches for debugging
    if (_obs_validation_stats.mismatch_count <= 10) {
      size_t token_idx = first_mismatch_idx / token_size;
      size_t component = first_mismatch_idx % token_size;
      const char* component_names[] = {"location", "feature_id", "value"};
      std::cerr << "[METTAGRID OBS_VALIDATION] Mismatch at agent " << agent_idx << " token " << token_idx << " "
                << component_names[component]
                << ": primary=" << static_cast<int>(_shadow_obs_buffer[first_mismatch_idx])
                << " secondary=" << static_cast<int>(primary_obs[first_mismatch_idx]) << std::endl;
    }
  }

  // Accumulate timing
  if (primary_was_optimized) {
    _obs_validation_stats.optimized_time_ns += primary_time_ns;
    _obs_validation_stats.original_time_ns += secondary_time_ns;
  } else {
    _obs_validation_stats.original_time_ns += primary_time_ns;
    _obs_validation_stats.optimized_time_ns += secondary_time_ns;
  }

  // Periodic timing ratio log for production monitoring
  // Tiered reporting: early data at 1K and 10K, then every 100K
  auto count = _obs_validation_stats.comparison_count;
  if (count == 1000 || count == 10000 || (count >= 100000 && count % 100000 == 0)) {
    double ratio = _obs_validation_stats.original_time_ns / std::max(_obs_validation_stats.optimized_time_ns, 1.0);
    std::cerr << "[METTAGRID OBS_VALIDATION] " << _obs_validation_stats.comparison_count << " comparisons, "
              << _obs_validation_stats.mismatch_count << " mismatches, "
              << "timing ratio=" << std::fixed << std::setprecision(2) << ratio << "x" << std::endl;
  }

  // Restore primary observation (the one we want to keep)
  std::copy(_shadow_obs_buffer.begin(), _shadow_obs_buffer.begin() + agent_obs_size, primary_obs);
}

// Original path: matches main branch behavior exactly
void MettaGrid::_compute_observation_original(GridCoord observer_row,
                                              GridCoord observer_col,
                                              ObservationCoord observable_width,
                                              ObservationCoord observable_height,
                                              size_t agent_idx,
                                              ActionType action) {
  // Calculate observation boundaries
  ObservationCoord obs_width_radius = observable_width >> 1;
  ObservationCoord obs_height_radius = observable_height >> 1;
  bool observation_clipped = observable_width != obs_width || observable_height != obs_height;
  ObservationCoord location_width_radius = observation_clipped ? obs_width >> 1 : obs_width_radius;
  ObservationCoord location_height_radius = observation_clipped ? obs_height >> 1 : obs_height_radius;
  mettagrid::ObservationShape visible_shape;
  if (observation_clipped) {
    visible_shape = mettagrid::make_observation_shape(observable_height, observable_width);
  }

  int r_start = std::max(static_cast<int>(observer_row) - static_cast<int>(obs_height_radius), 0);
  int c_start = std::max(static_cast<int>(observer_col) - static_cast<int>(obs_width_radius), 0);

  int r_end = std::min(static_cast<int>(observer_row) + static_cast<int>(obs_height_radius) + 1,
                       static_cast<int>(_grid->height));
  int c_end =
      std::min(static_cast<int>(observer_col) + static_cast<int>(obs_width_radius) + 1, static_cast<int>(_grid->width));

  // Line-of-sight mask for the observation rectangle. Uses thread buffer 0:
  // the original path is invoked serially (validation and non-optimized primary).
  mettagrid::compute_visibility_bitmap(
      *_grid, observer_row, observer_col, _shadow_table, _obs_thread_buffers[0].visibility_bitmap);
  const auto& visibility_bitmap = _obs_thread_buffers[0].visibility_bitmap;

  // Fill in visible objects. Observations should have been cleared in _step, so
  // we don't need to do that here.
  size_t attempted_tokens_written = 0;
  size_t tokens_written = 0;
  auto observation_view = _observations.mutable_unchecked<3>();
  auto rewards_view = _rewards.unchecked<1>();
  size_t buffer_capacity = static_cast<size_t>(observation_view.shape(1));

  // Global tokens
  ObservationToken* agent_obs_ptr = reinterpret_cast<ObservationToken*>(observation_view.mutable_data(agent_idx, 0, 0));
  ObservationTokens agent_obs_tokens(agent_obs_ptr, buffer_capacity - static_cast<size_t>(tokens_written));

  _obs_thread_buffers[0].global_tokens.clear();
  auto& global_tokens = _obs_thread_buffers[0].global_tokens;

  if (_global_obs_config.episode_completion_pct) {
    ObservationType episode_completion_pct = 0;
    if (max_steps > 0) {
      if (current_step >= max_steps) {
        episode_completion_pct = std::numeric_limits<ObservationType>::max();
      } else {
        episode_completion_pct = static_cast<ObservationType>(
            (static_cast<uint32_t>(std::numeric_limits<ObservationType>::max()) + 1) * current_step / max_steps);
      }
    }
    global_tokens.push_back({ObservationFeature::EpisodeCompletionPct, episode_completion_pct});
  }

  if (_global_obs_config.last_action) {
    global_tokens.push_back({ObservationFeature::LastAction, static_cast<ObservationType>(action)});
  }

  if (_global_obs_config.last_action_move && ObservationFeature::LastActionMove != 0) {
    bool moved = !(_agents[agent_idx]->location == _prev_agent_locations[agent_idx]);
    global_tokens.push_back({ObservationFeature::LastActionMove, static_cast<ObservationType>(moved ? 1 : 0)});
  }

  if (_global_obs_config.last_reward) {
    RewardType reward = rewards_view(agent_idx);
    ObservationType reward_int = static_cast<ObservationType>(std::round(reward * 100.0f));
    global_tokens.push_back({ObservationFeature::LastReward, reward_int});
  }

  if (_global_obs_config.local_position) {
    auto& agent = *_agents[agent_idx];
    int dc = static_cast<int>(agent.location.c) - static_cast<int>(agent.spawn_location.c);
    int dr = static_cast<int>(agent.spawn_location.r) - static_cast<int>(agent.location.r);
    if (dc > 0) {
      global_tokens.push_back({ObservationFeature::LpEast, static_cast<ObservationType>(std::min(dc, 255))});
    } else if (dc < 0) {
      global_tokens.push_back({ObservationFeature::LpWest, static_cast<ObservationType>(std::min(-dc, 255))});
    }
    if (dr > 0) {
      global_tokens.push_back({ObservationFeature::LpNorth, static_cast<ObservationType>(std::min(dr, 255))});
    } else if (dr < 0) {
      global_tokens.push_back({ObservationFeature::LpSouth, static_cast<ObservationType>(std::min(-dr, 255))});
    }
  }

  _prepare_territory_observations(
      observable_width, observable_height, agent_idx, global_tokens, _obs_thread_buffers[0].territory_observations);

  // Global tokens use a dedicated location marker (0xFE) distinct from spatial coordinates.
  uint8_t global_location = PackedCoordinate::GLOBAL_LOCATION;

  attempted_tokens_written +=
      _obs_encoder->append_tokens_if_room_available(agent_obs_tokens, global_tokens, global_location);
  tokens_written = std::min(attempted_tokens_written, buffer_capacity);

  // Emit obs tokens - resolve each GameValueConfig inline
  attempted_tokens_written += _emit_obs_value_tokens(agent_idx, tokens_written, global_location);
  tokens_written = std::min(attempted_tokens_written, buffer_capacity);

  // Process locations in increasing manhattan distance order (using pre-computed offsets)
  for (const auto& [r_offset, c_offset] : _observation_offsets) {
    if (observation_clipped && !mettagrid::within_observation_shape(r_offset, c_offset, visible_shape)) {
      continue;
    }
    int r = static_cast<int>(observer_row) + r_offset;
    int c = static_cast<int>(observer_col) + c_offset;

    // Skip if outside map bounds
    if (r < r_start || r >= r_end || c < c_start || c >= c_end) {
      continue;
    }

    // Position within the observation window (agent is at the center).
    int obs_r = r_offset + static_cast<int>(location_height_radius);
    int obs_c = c_offset + static_cast<int>(location_width_radius);

    // Skip cells hidden by a vision-blocking object. This suppresses both
    // object tokens and AOE/observability tokens for hidden cells, and also
    // skips the cell.visited staleness bookkeeping.
    if (!visibility_bitmap[static_cast<size_t>(obs_r) * static_cast<size_t>(observable_width) +
                           static_cast<size_t>(obs_c)]) {
      continue;
    }

    // Process a single grid location
    GridLocation object_loc(static_cast<GridCoord>(r), static_cast<GridCoord>(c));
    auto obj = _grid->object_at(object_loc);

    uint8_t location = PackedCoordinate::pack(static_cast<uint8_t>(obs_r), static_cast<uint8_t>(obs_c));

    // Prepare observation buffer for this location
    ObservationToken* obs_ptr =
        reinterpret_cast<ObservationToken*>(observation_view.mutable_data(agent_idx, tokens_written, 0));

    emit_tile_territory_tokens(_obs_thread_buffers[0].territory_observations,
                               observable_width,
                               observable_height,
                               static_cast<uint8_t>(obs_r),
                               static_cast<uint8_t>(obs_c),
                               location,
                               obs_ptr,
                               tokens_written,
                               attempted_tokens_written,
                               buffer_capacity);

    if (!obj) {
      tokens_written = std::min(attempted_tokens_written, buffer_capacity);
      continue;
    }

    // Track cell staleness for exploration (cell.visited stat).
    // CAS ensures only one thread wins per object per step, matching serial semantics.
    unsigned int prev_visited = obj->visited.load(std::memory_order_relaxed);
    while (prev_visited < current_step) {
      if (obj->visited.compare_exchange_weak(prev_visited, current_step, std::memory_order_relaxed)) {
        unsigned int staleness = current_step - prev_visited;
        _agents[agent_idx]->stats.add("cell.visited", static_cast<float>(staleness));
        break;
      }
    }

    // Encode location and add tokens
    ObservationTokens obs_tokens(obs_ptr, buffer_capacity - static_cast<size_t>(tokens_written));
    attempted_tokens_written += _obs_encoder->encode_tokens(obj, obs_tokens, location);
    tokens_written = std::min(attempted_tokens_written, buffer_capacity);
  }

  if (attempted_tokens_written > buffer_capacity) {
    _throw_observation_token_overflow(agent_idx, attempted_tokens_written, buffer_capacity);
  }

  _stats->add("tokens_written", tokens_written);
  _stats->add("tokens_dropped", attempted_tokens_written - tokens_written);
  _stats->add("tokens_free_space", buffer_capacity - tokens_written);
}

// Optimized path: thin wrapper using thread-local buffer 0
void MettaGrid::_compute_observation_optimized(GridCoord observer_row,
                                               GridCoord observer_col,
                                               ObservationCoord observable_width,
                                               ObservationCoord observable_height,
                                               size_t agent_idx,
                                               ActionType action) {
  auto& buf = _obs_thread_buffers[0];
  buf.reset_stats();
  _compute_observation_optimized(
      observer_row, observer_col, observable_width, observable_height, agent_idx, action, buf);
  if (buf.token_budget_exceeded) {
    _throw_observation_token_overflow(buf.overflow_agent_idx, buf.overflow_attempted_tokens, buf.overflow_buffer_capacity);
  }
  *_stats->get_ptr(_stat_tokens_written) += buf.tokens_written;
  *_stats->get_ptr(_stat_tokens_dropped) += buf.tokens_dropped;
  *_stats->get_ptr(_stat_tokens_free_space) += buf.tokens_free_space;
}

// Optimized path with explicit buffer (thread-safe, used by parallel dispatch)
void MettaGrid::_compute_observation_optimized(GridCoord observer_row,
                                               GridCoord observer_col,
                                               ObservationCoord observable_width,
                                               ObservationCoord observable_height,
                                               size_t agent_idx,
                                               ActionType action,
                                               ObsComputeBuffers& buffers) {
  // Calculate observation boundaries
  ObservationCoord obs_width_radius = observable_width >> 1;
  ObservationCoord obs_height_radius = observable_height >> 1;
  bool observation_clipped = observable_width != obs_width || observable_height != obs_height;
  ObservationCoord location_width_radius = observation_clipped ? obs_width >> 1 : obs_width_radius;
  ObservationCoord location_height_radius = observation_clipped ? obs_height >> 1 : obs_height_radius;
  mettagrid::ObservationShape visible_shape;
  if (observation_clipped) {
    visible_shape = mettagrid::make_observation_shape(observable_height, observable_width);
  }

  int r_start = std::max(static_cast<int>(observer_row) - static_cast<int>(obs_height_radius), 0);
  int c_start = std::max(static_cast<int>(observer_col) - static_cast<int>(obs_width_radius), 0);

  int r_end = std::min(static_cast<int>(observer_row) + static_cast<int>(obs_height_radius) + 1,
                       static_cast<int>(_grid->height));
  int c_end =
      std::min(static_cast<int>(observer_col) + static_cast<int>(obs_width_radius) + 1, static_cast<int>(_grid->width));

  // Line-of-sight mask for the observation rectangle. The shadow table is
  // read-only after construction, so sharing it across worker threads is safe;
  // the destination bitmap lives on the thread-local buffer.
  mettagrid::compute_visibility_bitmap(
      *_grid, observer_row, observer_col, _shadow_table, buffers.visibility_bitmap);
  const auto& visibility_bitmap = buffers.visibility_bitmap;

  // Fill in visible objects. Observations should have been cleared in _step, so
  // we don't need to do that here.
  size_t attempted_tokens_written = 0;
  size_t tokens_written = 0;
  auto observation_view = _observations.mutable_unchecked<3>();
  auto rewards_view = _rewards.unchecked<1>();
  size_t buffer_capacity = static_cast<size_t>(observation_view.shape(1));

  // Global tokens
  ObservationToken* agent_obs_ptr = reinterpret_cast<ObservationToken*>(observation_view.mutable_data(agent_idx, 0, 0));
  ObservationTokens agent_obs_tokens(agent_obs_ptr, buffer_capacity - static_cast<size_t>(tokens_written));

  // Build global tokens based on configuration (reusing pre-allocated buffer)
  buffers.global_tokens.clear();
  auto& global_tokens = buffers.global_tokens;

  if (_global_obs_config.episode_completion_pct) {
    ObservationType episode_completion_pct = 0;
    if (max_steps > 0) {
      if (current_step >= max_steps) {
        episode_completion_pct = std::numeric_limits<ObservationType>::max();
      } else {
        episode_completion_pct = static_cast<ObservationType>(
            (static_cast<uint32_t>(std::numeric_limits<ObservationType>::max()) + 1) * current_step / max_steps);
      }
    }
    global_tokens.push_back({ObservationFeature::EpisodeCompletionPct, episode_completion_pct});
  }

  if (_global_obs_config.last_action) {
    global_tokens.push_back({ObservationFeature::LastAction, static_cast<ObservationType>(action)});
  }

  if (_global_obs_config.last_action_move && ObservationFeature::LastActionMove != 0) {
    bool moved = !(_agents[agent_idx]->location == _prev_agent_locations[agent_idx]);
    global_tokens.push_back({ObservationFeature::LastActionMove, static_cast<ObservationType>(moved ? 1 : 0)});
  }

  if (_global_obs_config.last_reward) {
    RewardType reward = rewards_view(agent_idx);
    ObservationType reward_int = static_cast<ObservationType>(std::round(reward * 100.0f));
    global_tokens.push_back({ObservationFeature::LastReward, reward_int});
  }

  if (_global_obs_config.local_position) {
    auto& agent = *_agents[agent_idx];
    int dc = static_cast<int>(agent.location.c) - static_cast<int>(agent.spawn_location.c);
    int dr = static_cast<int>(agent.spawn_location.r) - static_cast<int>(agent.location.r);
    if (dc > 0) {
      global_tokens.push_back({ObservationFeature::LpEast, static_cast<ObservationType>(std::min(dc, 255))});
    } else if (dc < 0) {
      global_tokens.push_back({ObservationFeature::LpWest, static_cast<ObservationType>(std::min(-dc, 255))});
    }
    if (dr > 0) {
      global_tokens.push_back({ObservationFeature::LpNorth, static_cast<ObservationType>(std::min(dr, 255))});
    } else if (dr < 0) {
      global_tokens.push_back({ObservationFeature::LpSouth, static_cast<ObservationType>(std::min(-dr, 255))});
    }
  }

  _prepare_territory_observations(
      observable_width, observable_height, agent_idx, global_tokens, buffers.territory_observations);

  // Global tokens use a dedicated location marker (0xFE) distinct from spatial coordinates.
  uint8_t global_location = PackedCoordinate::GLOBAL_LOCATION;

  attempted_tokens_written +=
      _obs_encoder->append_tokens_if_room_available(agent_obs_tokens, global_tokens, global_location);
  tokens_written = std::min(attempted_tokens_written, buffer_capacity);

  // Emit obs tokens - resolve each GameValueConfig inline
  attempted_tokens_written += _emit_obs_value_tokens(agent_idx, tokens_written, global_location);
  tokens_written = std::min(attempted_tokens_written, buffer_capacity);

  // Process locations in increasing manhattan distance order (using pre-computed offsets)
  for (const auto& [r_offset, c_offset] : _observation_offsets) {
    if (observation_clipped && !mettagrid::within_observation_shape(r_offset, c_offset, visible_shape)) {
      continue;
    }
    int r = static_cast<int>(observer_row) + r_offset;
    int c = static_cast<int>(observer_col) + c_offset;

    // Skip if outside map bounds
    if (r < r_start || r >= r_end || c < c_start || c >= c_end) {
      continue;
    }

    // Position within the observation window (agent is at the center).
    int obs_r = r_offset + static_cast<int>(location_height_radius);
    int obs_c = c_offset + static_cast<int>(location_width_radius);

    // Skip cells hidden by a vision-blocking object. This suppresses both
    // object tokens and AOE/observability tokens for hidden cells, and also
    // skips the cell.visited staleness bookkeeping.
    if (!visibility_bitmap[static_cast<size_t>(obs_r) * static_cast<size_t>(observable_width) +
                           static_cast<size_t>(obs_c)]) {
      continue;
    }

    // Process a single grid location
    GridLocation object_loc(static_cast<GridCoord>(r), static_cast<GridCoord>(c));
    auto obj = _grid->object_at(object_loc);

    uint8_t location = PackedCoordinate::pack(static_cast<uint8_t>(obs_r), static_cast<uint8_t>(obs_c));

    // Once buffer is full, we still compute features to track exact tokens_dropped.
    // Alternative: count objects only (cheaper, but tokens_dropped becomes objects_dropped).
    ObservationToken* obs_ptr =
        reinterpret_cast<ObservationToken*>(observation_view.mutable_data(agent_idx, tokens_written, 0));

    emit_tile_territory_tokens(buffers.territory_observations,
                               observable_width,
                               observable_height,
                               static_cast<uint8_t>(obs_r),
                               static_cast<uint8_t>(obs_c),
                               location,
                               obs_ptr,
                               tokens_written,
                               attempted_tokens_written,
                               buffer_capacity);

    if (!obj) {
      tokens_written = std::min(attempted_tokens_written, buffer_capacity);
      continue;
    }

    // Track cell staleness for exploration (cell.visited stat).
    // CAS ensures only one thread wins per object per step, matching serial semantics.
    unsigned int prev_visited = obj->visited.load(std::memory_order_relaxed);
    while (prev_visited < current_step) {
      if (obj->visited.compare_exchange_weak(prev_visited, current_step, std::memory_order_relaxed)) {
        unsigned int staleness = current_step - prev_visited;
        _agents[agent_idx]->stats.add("cell.visited", static_cast<float>(staleness));
        break;
      }
    }

    if (tokens_written >= buffer_capacity) {
      attempted_tokens_written +=
          obj->write_obs_features(buffers.obs_features_scratch.data(), buffers.obs_features_scratch.size());
      continue;
    }

    // Prepare observation buffer for this object
    ObservationTokens obs_tokens(obs_ptr, buffer_capacity - tokens_written);

    // Encode location and add tokens (using allocation-free path with scratch buffer)
    attempted_tokens_written += _obs_encoder->encode_tokens_direct(
        obj, obs_tokens, location, buffers.obs_features_scratch.data(), buffers.obs_features_scratch.size());
    tokens_written = std::min(attempted_tokens_written, buffer_capacity);
  }

  if (attempted_tokens_written > buffer_capacity) {
    buffers.token_budget_exceeded = true;
    buffers.overflow_agent_idx = agent_idx;
    buffers.overflow_attempted_tokens = attempted_tokens_written;
    buffers.overflow_buffer_capacity = buffer_capacity;
    return;
  }

  buffers.tokens_written += tokens_written;
  buffers.tokens_dropped += (attempted_tokens_written - tokens_written);
  buffers.tokens_free_space += (buffer_capacity - tokens_written);
}

void MettaGrid::_compute_observations(const std::vector<ActionType>& executed_actions) {
  if (_validation_enabled) {
    // Serial — shadow validation not thread-safe
    for (size_t idx = 0; idx < _agents.size(); idx++) {
      auto [observable_width, observable_height] = _observable_window(idx);
      _compute_observation(_agents[idx]->location.r,
                           _agents[idx]->location.c,
                           observable_width,
                           observable_height,
                           idx,
                           executed_actions[idx]);
    }
    return;
  }

  if (_obs_thread_count > 1 && _use_optimized_primary && _agents.size() > 1) {
    // Lazy worker spawn: deferred from constructor for fork-safety (pytest-xdist)
    if (_obs_workers.empty()) {
      _obs_worker_flags.resize(_obs_thread_count);
      _obs_workers.reserve(_obs_thread_count);
      for (unsigned int t = 0; t < _obs_thread_count; t++) {
        _obs_worker_flags[t] = std::make_unique<std::atomic<int>>(0);
        auto* my_flag = _obs_worker_flags[t].get();
        _obs_workers.emplace_back([this, t, my_flag]() {
          while (true) {
            // Spin-wait for start signal (flag set to 1 by main thread)
            while (my_flag->load(std::memory_order_acquire) == 0) {
              // Yield to avoid burning CPU while waiting
              std::this_thread::yield();
            }
            if (_obs_workers_stop.load(std::memory_order_acquire)) return;

            auto& buf = _obs_thread_buffers[t];
            buf.reset_stats();
            size_t chunk = (_agents.size() + _obs_thread_count - 1) / _obs_thread_count;
            size_t start = t * chunk;
            size_t end = std::min(start + chunk, _agents.size());

            for (size_t idx = start; idx < end; idx++) {
              auto [observable_width, observable_height] = _observable_window(idx);
              _compute_observation_optimized(_agents[idx]->location.r,
                                             _agents[idx]->location.c,
                                             observable_width,
                                             observable_height,
                                             idx,
                                             (*_obs_current_actions)[idx],
                                             buf);
              if (buf.token_budget_exceeded) {
                break;
              }
            }

            // Signal done by resetting flag to 0
            my_flag->store(0, std::memory_order_release);
          }
        });
      }
    }

    // Parallel dispatch: set all worker flags to 1
    _obs_current_actions = &executed_actions;
    for (unsigned int t = 0; t < _obs_thread_count; t++) {
      _obs_worker_flags[t]->store(1, std::memory_order_release);
    }

    // Wait for all workers to finish (flag back to 0)
    for (unsigned int t = 0; t < _obs_thread_count; t++) {
      while (_obs_worker_flags[t]->load(std::memory_order_acquire) != 0) {
        std::this_thread::yield();
      }
    }

    for (const auto& buf : _obs_thread_buffers) {
      if (buf.token_budget_exceeded) {
        _throw_observation_token_overflow(buf.overflow_agent_idx, buf.overflow_attempted_tokens, buf.overflow_buffer_capacity);
      }
    }

    // Merge per-thread stats
    for (const auto& buf : _obs_thread_buffers) {
      *_stats->get_ptr(_stat_tokens_written) += buf.tokens_written;
      *_stats->get_ptr(_stat_tokens_dropped) += buf.tokens_dropped;
      *_stats->get_ptr(_stat_tokens_free_space) += buf.tokens_free_space;
    }
    return;
  }

  // Serial fallback
  for (size_t idx = 0; idx < _agents.size(); idx++) {
    auto [observable_width, observable_height] = _observable_window(idx);
    _compute_observation(_agents[idx]->location.r,
                         _agents[idx]->location.c,
                         observable_width,
                         observable_height,
                         idx,
                         executed_actions[idx]);
  }
}

void MettaGrid::_handle_invalid_action(size_t agent_idx, const std::string& stat, ActionType type) {
  auto& agent = _agents[agent_idx];
  agent->stats.incr(stat);
  agent->stats.incr(stat + "." + std::to_string(type));
  _action_success[agent_idx] = false;
}

void MettaGrid::_step() {
  std::chrono::steady_clock::time_point step_start, phase_start, phase_end;
  if (_profiling_enabled) {
    step_start = std::chrono::steady_clock::now();
  }
  auto actions_view = _actions.unchecked<1>();
  auto vibe_actions_view = _vibe_actions.unchecked<1>();

  for (size_t i = 0; i < _agents.size(); ++i) {
    _prev_agent_locations[i] = _agents[i]->location;
  }

  // Reset rewards and observations
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  auto rewards_view = _rewards.mutable_unchecked<1>();

  std::fill(
      static_cast<float*>(_rewards.request().ptr), static_cast<float*>(_rewards.request().ptr) + _rewards.size(), 0);

  auto obs_ptr = static_cast<ObservationType*>(_observations.request().ptr);
  auto obs_size = _observations.size();
  std::fill(obs_ptr, obs_ptr + obs_size, EmptyTokenByte);

  std::fill(_action_success.begin(), _action_success.end(), false);
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.reset_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // Increment timestep
  current_step++;
  _game_ctx.timestep = current_step;

  // --- Agent actions (enacted immediately after policy decision) ---

  // Create and shuffle agent indices for randomized action order
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  std::vector<size_t> agent_indices(_agents.size());
  std::iota(agent_indices.begin(), agent_indices.end(), 0);
  std::shuffle(agent_indices.begin(), agent_indices.end(), _rng);

  std::vector<ActionType> executed_actions(_agents.size());
  // Fill with noop. Replace this with the actual action if it's successful.
  std::fill(executed_actions.begin(), executed_actions.end(), ActionType(0));
  // Process actions by priority levels (highest to lowest)
  for (unsigned char offset = 0; offset <= _max_action_priority; offset++) {
    unsigned char current_priority = _max_action_priority - offset;

    auto process_action_stream = [&](ActionType action_idx, size_t agent_idx, bool is_vibe_stream) {
      if (action_idx < 0 || static_cast<size_t>(action_idx) >= _action_handlers.size()) {
        _handle_invalid_action(agent_idx, "action.invalid_index", action_idx);
        return;
      }

      auto action_idx_usize = static_cast<size_t>(action_idx);
      if (_action_is_vibe[action_idx_usize] != is_vibe_stream) {
        return;
      }

      Action& action = _action_handlers[action_idx_usize];
      if (action.handler()->priority != current_priority) {
        return;
      }

      auto* agent = _agents[agent_idx];
      bool success = action.handle(*agent, _game_ctx);
      if (success) {
        executed_actions[agent_idx] = action_idx;
        _action_success[agent_idx] = true;
      }
    };

    for (const auto& agent_idx : agent_indices) {
      process_action_stream(actions_view(agent_idx), agent_idx, false);
    }
    for (const auto& agent_idx : agent_indices) {
      process_action_stream(vibe_actions_view(agent_idx), agent_idx, true);
    }
  }
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.actions_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // --- World update (events, on_tick, AOE, game on_tick) ---

  // Process events at current timestep
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  if (_event_scheduler) {
    _event_scheduler->process_timestep(current_step, _game_ctx);
  }
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.events_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // Apply per-agent on_tick handlers
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  for (auto* agent : _agents) {
    mettagrid::HandlerContext ctx = _game_ctx;
    ctx.actor = agent;
    ctx.target = agent;
    agent->apply_on_tick(ctx);
  }
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.on_tick_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // Apply fixed AOE effects to all agents at their current location
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  for (auto* agent : _agents) {
    _aoe_tracker->apply_fixed(*agent, _game_ctx);
    _territory_tracker->apply_effects(*agent, _game_ctx);
  }

  // Apply mobile AOE effects (sources checked against all agents)
  _aoe_tracker->apply_mobile(_agents, _game_ctx);

  // Flush any AOE registrations queued by mutations during this tick
  // (e.g. SpawnObjectMutation creating objects with AOEs).
  _aoe_tracker->flush_deferred();

  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.aoe_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // Execute game-level on_tick handler
  if (_game_on_tick) {
    _game_on_tick->try_apply(_game_ctx);
  }

  for (auto* agent : _agents) {
    agent->track_coverage();
  }

  _last_executed_actions = executed_actions;

  // Compute observations for next step
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  _compute_observations(executed_actions);
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.observations_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // Compute rewards for all agents
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  for (auto& agent : _agents) {
    agent->reward_helper.compute_entries();
  }

  // Update episode rewards
  auto episode_rewards_view = _episode_rewards.mutable_unchecked<1>();
  for (py::ssize_t i = 0; i < rewards_view.shape(0); i++) {
    episode_rewards_view(i) += rewards_view(i);
  }
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.rewards_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
  }

  // Check for truncation
  if (_profiling_enabled) phase_start = std::chrono::steady_clock::now();
  if (max_steps > 0 && current_step >= max_steps) {
    if (episode_truncates) {
      std::fill(static_cast<bool*>(_truncations.request().ptr),
                static_cast<bool*>(_truncations.request().ptr) + _truncations.size(),
                1);
    } else {
      std::fill(static_cast<bool*>(_terminals.request().ptr),
                static_cast<bool*>(_terminals.request().ptr) + _terminals.size(),
                1);
    }
  }
  if (_profiling_enabled) {
    phase_end = std::chrono::steady_clock::now();
    _step_timing.truncation_ns = std::chrono::duration<double, std::nano>(phase_end - phase_start).count();
    _step_timing.total_ns = std::chrono::duration<double, std::nano>(phase_end - step_start).count();
  }
}

void MettaGrid::validate_buffers() {
  // We should validate once buffers and agents are set.
  // data types and contiguity are handled by pybind11. We still need to check
  // shape.
  auto num_agents = _agents.size();
  auto observation_info = _observations.request();
  auto observation_shape = observation_info.shape;
  if (observation_info.ndim != 3) {
    std::stringstream ss;
    ss << "observations has " << observation_info.ndim << " dimensions but expected 3";
    throw std::runtime_error(ss.str());
  }
  if (observation_shape[0] != static_cast<ssize_t>(num_agents) || observation_shape[2] != 3) {
    std::stringstream ss;
    ss << "observations has shape [" << observation_shape[0] << ", " << observation_shape[1] << ", "
       << observation_shape[2] << "] but expected [" << num_agents << ", [something], 3]";
    throw std::runtime_error(ss.str());
  }
  {
    auto terminals_info = _terminals.request();
    auto terminals_shape = terminals_info.shape;
    if (terminals_info.ndim != 1 || terminals_shape[0] != static_cast<ssize_t>(num_agents)) {
      throw std::runtime_error("terminals has the wrong shape");
    }
  }
  {
    auto truncations_info = _truncations.request();
    auto truncations_shape = truncations_info.shape;
    if (truncations_info.ndim != 1 || truncations_shape[0] != static_cast<ssize_t>(num_agents)) {
      throw std::runtime_error("truncations has the wrong shape");
    }
  }
  {
    auto vibe_actions_info = _vibe_actions.request();
    auto vibe_actions_shape = vibe_actions_info.shape;
    if (vibe_actions_info.ndim != 1 || vibe_actions_shape[0] != static_cast<ssize_t>(num_agents)) {
      throw std::runtime_error("vibe_actions has the wrong shape");
    }
  }
  {
    auto rewards_info = _rewards.request();
    auto rewards_shape = rewards_info.shape;
    if (rewards_info.ndim != 1 || rewards_shape[0] != static_cast<ssize_t>(num_agents)) {
      throw std::runtime_error("rewards has the wrong shape");
    }
  }
}

void MettaGrid::set_buffers(const py::array_t<uint8_t, py::array::c_style>& observations,
                            const py::array_t<bool, py::array::c_style>& terminals,
                            const py::array_t<bool, py::array::c_style>& truncations,
                            const py::array_t<float, py::array::c_style>& rewards,
                            const py::array_t<ActionType, py::array::c_style>& actions) {
  // Backward-compatible wrapper: unset vibe actions as no-op by default (index 0 in each action space).
  auto vibe_actions = py::array_t<ActionType, py::array::c_style>({static_cast<ssize_t>(_agents.size())});
  std::fill(static_cast<ActionType*>(vibe_actions.request().ptr),
            static_cast<ActionType*>(vibe_actions.request().ptr) + vibe_actions.size(),
            ActionType(0));
  set_buffers(observations, terminals, truncations, rewards, actions, vibe_actions);
}

void MettaGrid::set_buffers(const py::array_t<uint8_t, py::array::c_style>& observations,
                            const py::array_t<bool, py::array::c_style>& terminals,
                            const py::array_t<bool, py::array::c_style>& truncations,
                            const py::array_t<float, py::array::c_style>& rewards,
                            const py::array_t<ActionType, py::array::c_style>& actions,
                            const py::array_t<ActionType, py::array::c_style>& vibe_actions) {
  // These are initialized in reset()
  _observations = observations;
  _terminals = terminals;
  _truncations = truncations;
  _rewards = rewards;
  _actions = actions;
  _vibe_actions = vibe_actions;
  for (size_t i = 0; i < _agents.size(); i++) {
    _agents[i]->init(&_rewards.mutable_unchecked<1>()(i));
  }

  validate_buffers();
  _init_buffers(_agents.size());
}

void MettaGrid::step() {
  auto info = _actions.request();
  auto vibe_info = _vibe_actions.request();

  // Validate that actions array has correct shape
  if (info.ndim != 1) {
    throw std::runtime_error("actions must be 1D array");
  }
  if (info.shape[0] != static_cast<ssize_t>(_agents.size())) {
    throw std::runtime_error("actions has the wrong shape");
  }
  if (vibe_info.ndim != 1) {
    throw std::runtime_error("vibe_actions must be 1D array");
  }
  if (vibe_info.shape[0] != static_cast<ssize_t>(_agents.size())) {
    throw std::runtime_error("vibe_actions has the wrong shape");
  }

  _step();
}

size_t MettaGrid::_emit_obs_value_tokens(size_t agent_idx, size_t tokens_written, ObservationType global_location) {
  auto observation_view = _observations.mutable_unchecked<3>();
  auto* agent = _agents[agent_idx];
  size_t buffer_capacity = static_cast<size_t>(observation_view.shape(1));

  // Build a HandlerContext so we can use resolve_game_value
  mettagrid::HandlerContext ctx = _game_ctx;
  ctx.actor = agent;
  ctx.target = agent;

  size_t total_written = 0;

  for (const auto& obs_cfg : _game_config.global_obs.obs) {
    const auto& gv = obs_cfg.value;
    float raw_value = ctx.resolve_game_value(gv, mettagrid::EntityRef::actor);
    uint32_t encoded_value = static_cast<uint32_t>(raw_value);
    size_t write_offset = tokens_written + total_written;

    if (write_offset >= buffer_capacity) {
      total_written += ObservationEncoder::compute_num_tokens(encoded_value, _token_encoder->token_value_base());
      continue;
    }

    auto tokens = _token_encoder->encode(obs_cfg.feature_id, encoded_value);
    ObservationToken* ptr =
        reinterpret_cast<ObservationToken*>(observation_view.mutable_data(agent_idx, write_offset, 0));
    ObservationTokens obs_tokens(ptr, buffer_capacity - write_offset);
    total_written += _obs_encoder->append_tokens_if_room_available(obs_tokens, tokens, global_location);
  }

  return total_written;
}
