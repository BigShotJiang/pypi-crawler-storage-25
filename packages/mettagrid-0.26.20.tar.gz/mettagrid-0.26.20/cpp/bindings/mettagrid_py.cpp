#include <map>

#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include "actions/attack.hpp"
#include "actions/change_vibe.hpp"
#include "actions/move_config.hpp"
#include "bindings/mettagrid_c.hpp"
#include "core/grid.hpp"
#include "core/tag_index.hpp"
#include "handler/event_bindings.hpp"
#include "handler/handler_bindings.hpp"
#include "objects/agent.hpp"
#include "objects/has_inventory.hpp"
#include "objects/protocol.hpp"
#include "objects/reward_config.hpp"
#include "objects/wall.hpp"
#include "systems/packed_coordinate.hpp"
#include "systems/reward.hpp"
#include "systems/stats_tracker.hpp"

namespace py = pybind11;

// Defined in profiling_py.cpp
void bind_profiling_properties(py::class_<MettaGrid>& cls);

py::dict MettaGrid::grid_objects(py::object self_ref,
                                 int min_row,
                                 int max_row,
                                 int min_col,
                                 int max_col,
                                 const py::list& ignore_types) {
  py::dict objects;

  // Determine if bounding box filtering is enabled
  bool use_bounds = (min_row >= 0 && max_row >= 0 && min_col >= 0 && max_col >= 0);

  // Convert ignore_types list (type names) to type IDs for O(1) integer comparison
  std::unordered_set<TypeId> ignore_type_ids;
  for (const auto& item : ignore_types) {
    std::string type_name = item.cast<std::string>();
    // Find the type_id for this type_name
    for (size_t type_id = 0; type_id < object_type_names.size(); ++type_id) {
      if (object_type_names[type_id] == type_name) {
        ignore_type_ids.insert(static_cast<TypeId>(type_id));
        break;
      }
    }
  }
  bool use_type_filter = !ignore_type_ids.empty();

  for (unsigned int obj_id = 1; obj_id < _grid->objects.size(); obj_id++) {
    auto obj = _grid->object(obj_id);
    if (!obj) continue;

    // Filter by type_id if specified (fast integer comparison)
    if (use_type_filter) {
      if (ignore_type_ids.find(obj->type_id) != ignore_type_ids.end()) {
        continue;
      }
    }

    // Filter by bounding box if specified
    if (use_bounds) {
      if (obj->location.r < min_row || obj->location.r >= max_row || obj->location.c < min_col ||
          obj->location.c >= max_col) {
        continue;
      }
    }

    py::dict obj_dict;
    obj_dict["id"] = obj_id;
    obj_dict["type_name"] = object_type_names[obj->type_id];
    // Location here is defined as XYZ coordinates specifically to be used by MettaScope.
    // We define that for location: x is column, y is row. Currently, no z for grid objects.
    // Note: it might be different for matrix computations.
    obj_dict["location"] = py::make_tuple(obj->location.c, obj->location.r);

    obj_dict["r"] = obj->location.r;  // To remove
    obj_dict["c"] = obj->location.c;  // To remove

    // Inject observation features
    auto features = obj->obs_features();
    for (const auto& feature : features) {
      auto feature_name_it = feature_id_to_name.find(feature.feature_id);
      if (feature_name_it != feature_id_to_name.end()) {
        obj_dict[py::str(feature_name_it->second)] = feature.value;
      }
    }

    if (auto* has_inventory = dynamic_cast<HasInventory*>(obj)) {
      const auto& inventory_items = has_inventory->inventory.items();
      obj_dict["inventory"] =
          py::cast(std::map<InventoryItem, InventoryQuantity>(inventory_items.begin(), inventory_items.end()));

      // Export per-resource effective limits (dynamic capacities).
      // Python will group these by capacity ID using the config's limit group definitions.
      const auto effective_limits = has_inventory->inventory.get_effective_limits();
      obj_dict["inventory_capacities"] =
          py::cast(std::map<InventoryItem, InventoryQuantity>(effective_limits.begin(), effective_limits.end()));
    }

    // Inject agent-specific info
    if (auto* agent = dynamic_cast<Agent*>(obj)) {
      obj_dict["group_id"] = agent->group;
      obj_dict["group_name"] = agent->group_name;
      obj_dict["vibe"] = agent->vibe;
      obj_dict["agent_id"] = agent->agent_id;
      obj_dict["last_action_id"] = _last_executed_actions[agent->agent_id];
      obj_dict["last_animation_id"] = agent->last_animation_id;
      obj_dict["current_stat_reward"] = agent->reward_helper.current_reward();
      obj_dict["steps_without_motion"] = agent->steps_without_motion;
    }

    // Export tag IDs as a list of integers for replay/streaming consumers.
    {
      py::list tag_id_list;
      for (size_t i = 0; i < kMaxTags; ++i) {
        if (obj->tag_bits.test(i)) {
          tag_id_list.append(static_cast<int>(i));
        }
      }
      obj_dict["tag_ids"] = tag_id_list;
    }

    // Add tag mutation methods (capture obj pointer, game_ctx, and self_ref to prevent use-after-free)
    // self_ref keeps the MettaGrid alive as long as these lambdas exist
    const auto* game_ctx = &_game_ctx;
    obj_dict["has_tag"] = py::cpp_function([obj, self_ref](int tag_id) { return obj->has_tag(tag_id); });
    obj_dict["add_tag"] = py::cpp_function([obj, game_ctx, self_ref](int tag_id) { obj->add_tag(tag_id, *game_ctx); });
    obj_dict["remove_tag"] =
        py::cpp_function([obj, game_ctx, self_ref](int tag_id) { obj->remove_tag(tag_id, *game_ctx); });

    objects[py::int_(obj_id)] = obj_dict;
  }

  return objects;
}

GridCoord MettaGrid::map_width() {
  return _grid->width;
}

GridCoord MettaGrid::map_height() {
  return _grid->height;
}

py::array_t<float> MettaGrid::get_episode_rewards() {
  return _episode_rewards;
}

py::array_t<ActionType> MettaGrid::actions() {
  return _actions;
}

py::array_t<ActionType> MettaGrid::vibe_actions() {
  return _vibe_actions;
}

py::dict MettaGrid::get_episode_stats() {
  // Returns a dictionary with the following structure:
  // {
  //   "game": dict[str, float],  // Global game statistics
  //   "agent": list[dict[str, float]],  // Per-agent statistics
  //
  // }

  py::dict stats;
  stats["game"] = py::cast(_stats->to_dict());

  py::list agent_stats;
  for (const auto& agent : _agents) {
    agent_stats.append(py::cast(agent->stats.to_dict()));
  }
  stats["agent"] = agent_stats;

  return stats;
}

std::optional<float> MettaGrid::get_game_stat(const std::string& key) const {
  if (_stats == nullptr) {
    return std::nullopt;
  }
  return _stats->get_if_present(key);
}

std::optional<float> MettaGrid::get_agent_stat(uint32_t agent_id, const std::string& key) const {
  if (agent_id >= _agents.size()) {
    return std::nullopt;
  }
  const auto* agent = _agents[agent_id];
  if (agent == nullptr) {
    return std::nullopt;
  }
  return agent->stats.get_if_present(key);
}

py::list MettaGrid::action_success_py() {
  return py::cast(_action_success);
}

py::none MettaGrid::set_inventory(GridObjectId agent_id,
                                  const std::unordered_map<InventoryItem, InventoryQuantity>& inventory) {
  if (agent_id < _agents.size()) {
    this->_agents[agent_id]->set_inventory(inventory);
  }
  return py::none();
}

py::array_t<ObservationType> MettaGrid::observations() {
  return _observations;
}

py::array_t<TerminalType> MettaGrid::terminals() {
  return _terminals;
}

py::array_t<TruncationType> MettaGrid::truncations() {
  return _truncations;
}

py::array_t<RewardType> MettaGrid::rewards() {
  return _rewards;
}

py::array_t<MaskType> MettaGrid::masks() {
  // Return action masks - currently not computed, return empty array
  // TODO: Implement proper action masking if needed
  auto result = py::array_t<MaskType>(
      {static_cast<py::ssize_t>(_agents.size()), static_cast<py::ssize_t>(_action_handlers.size())});
  auto r = result.template mutable_unchecked<2>();
  for (py::ssize_t i = 0; i < r.shape(0); i++) {
    for (py::ssize_t j = 0; j < r.shape(1); j++) {
      r(i, j) = 1;  // All actions available by default
    }
  }
  return result;
}

// Pybind11 module definition
PYBIND11_MODULE(mettagrid_c, m) {
  m.doc() = "MettaGrid environment";  // optional module docstring

  PackedCoordinate::bind_packed_coordinate(m);

  // Bind Protocol near its definition
  bind_protocol(m);

  // MettaGrid class bindings
  auto mettagrid_cls =
      py::class_<MettaGrid>(m, "MettaGrid")
          .def("set_buffers",
               static_cast<void (MettaGrid::*)(const py::array_t<uint8_t, py::array::c_style>&,
                                               const py::array_t<bool, py::array::c_style>&,
                                               const py::array_t<bool, py::array::c_style>&,
                                               const py::array_t<float, py::array::c_style>&,
                                               const py::array_t<ActionType, py::array::c_style>&,
                                               const py::array_t<ActionType, py::array::c_style>&)>(
                   &MettaGrid::set_buffers),
               py::arg("observations").noconvert(),
               py::arg("terminals").noconvert(),
               py::arg("truncations").noconvert(),
               py::arg("rewards").noconvert(),
               py::arg("actions").noconvert(),
               py::arg("vibe_actions").noconvert())
          .def(py::init<const GameConfig&, const py::list&, unsigned int>())
          .def("step", &MettaGrid::step)
          .def("set_buffers",
               static_cast<void (MettaGrid::*)(const py::array_t<uint8_t, py::array::c_style>&,
                                               const py::array_t<bool, py::array::c_style>&,
                                               const py::array_t<bool, py::array::c_style>&,
                                               const py::array_t<float, py::array::c_style>&,
                                               const py::array_t<ActionType, py::array::c_style>&)>(
                   &MettaGrid::set_buffers),
               py::arg("observations").noconvert(),
               py::arg("terminals").noconvert(),
               py::arg("truncations").noconvert(),
               py::arg("rewards").noconvert(),
               py::arg("actions").noconvert())
          .def(
              "grid_objects",
              [](MettaGrid& self, int min_row, int max_row, int min_col, int max_col, const py::list& ignore_types) {
                return self.grid_objects(py::cast(&self), min_row, max_row, min_col, max_col, ignore_types);
              },
              py::arg("min_row") = -1,
              py::arg("max_row") = -1,
              py::arg("min_col") = -1,
              py::arg("max_col") = -1,
              py::arg("ignore_types") = py::list())
          .def("observations", &MettaGrid::observations)
          .def("terminals", &MettaGrid::terminals)
          .def("truncations", &MettaGrid::truncations)
          .def("rewards", &MettaGrid::rewards)
          .def("masks", &MettaGrid::masks)
          .def("actions", &MettaGrid::actions)
          .def("vibe_actions", &MettaGrid::vibe_actions)
          .def_property_readonly("map_width", &MettaGrid::map_width)
          .def_property_readonly("map_height", &MettaGrid::map_height)
          .def("get_episode_rewards", &MettaGrid::get_episode_rewards)
          .def("get_episode_stats", &MettaGrid::get_episode_stats)
          .def("get_game_stat", &MettaGrid::get_game_stat)
          .def("get_agent_stat", &MettaGrid::get_agent_stat)
          .def("action_success", &MettaGrid::action_success_py)
          .def_readonly("obs_width", &MettaGrid::obs_width)
          .def_readonly("obs_height", &MettaGrid::obs_height)
          .def_readonly("max_steps", &MettaGrid::max_steps)
          .def_readonly("current_step", &MettaGrid::current_step)
          .def_readonly("object_type_names", &MettaGrid::object_type_names)
          .def_readonly("resource_names", &MettaGrid::resource_names)
          .def("set_inventory", &MettaGrid::set_inventory, py::arg("agent_id"), py::arg("inventory"))
          .def("tag_index", &MettaGrid::tag_index, py::return_value_policy::reference_internal);

  // Profiling bindings (defined in profiling_py.cpp)
  bind_profiling_properties(mettagrid_cls);

  // Expose this so we can cast python WallConfig / AgentConfig to a common GridConfig cpp object.
  py::class_<GridObjectConfig, std::shared_ptr<GridObjectConfig>>(m, "GridObjectConfig")
      .def(py::init<TypeId, const std::string&, ObservationType>(),
           py::arg("type_id"),
           py::arg("type_name"),
           py::arg("initial_vibe") = 0)
      .def_readwrite("type_id", &GridObjectConfig::type_id)
      .def_readwrite("type_name", &GridObjectConfig::type_name)
      .def_readwrite("name", &GridObjectConfig::name)
      .def_readwrite("tag_ids", &GridObjectConfig::tag_ids)
      .def_readwrite("initial_vibe", &GridObjectConfig::initial_vibe)
      .def_readwrite("on_use_handler", &GridObjectConfig::on_use_handler)
      .def_readwrite("aoe_configs", &GridObjectConfig::aoe_configs)
      .def_readwrite("territory_controls", &GridObjectConfig::territory_controls)
      .def_readwrite("initial_inventory", &GridObjectConfig::initial_inventory)
      .def_readwrite("inventory_config", &GridObjectConfig::inventory_config)
      .def_readwrite("blocks_vision", &GridObjectConfig::blocks_vision)
      .def(
          "add_on_tag_add_handler",
          [](GridObjectConfig& self, int tag_id, const mettagrid::HandlerConfig& hc) {
            self.on_tag_add[tag_id].push_back(hc);
          },
          py::arg("tag_id"),
          py::arg("handler"))
      .def(
          "add_on_tag_remove_handler",
          [](GridObjectConfig& self, int tag_id, const mettagrid::HandlerConfig& hc) {
            self.on_tag_remove[tag_id].push_back(hc);
          },
          py::arg("tag_id"),
          py::arg("handler"));

  bind_wall_config(m);

  // ##MettaGridConfig
  // We expose these as much as we can to Python. Defining the initializer (and the object's constructor) means
  // we can create these in Python as AgentConfig(**agent_config_dict). And then we expose the fields individually.
  // This is verbose! But it seems like it's the best way to do it.
  //
  // We use shared_ptr because we expect to effectively have multiple python objects wrapping the same C++ object.
  // This comes from us creating (e.g.) various config objects, and then storing them in GameConfig's maps.
  // We're, like 80% sure on this reasoning.

  bind_inventory_config(m);
  bind_reward_config(m);
  bind_agent_config(m);
  bind_action_config(m);
  bind_attack_action_config(m);
  bind_change_vibe_action_config(m);
  bind_move_action_config(m);
  bind_obs_value_config(m);
  bind_global_obs_config(m);
  bind_query_config(m);
  bind_game_config(m);

  // Handler bindings
  bind_handler_config(m);

  // Event bindings
  bind_event_config(m);

  // TagIndex binding
  py::class_<mettagrid::TagIndex>(m, "TagIndex")
      .def(py::init<>())
      .def("count_objects_with_tag", &mettagrid::TagIndex::count_objects_with_tag);

  // Export data types from types.hpp
  m.attr("dtype_observations") = dtype_observations();
  m.attr("dtype_terminals") = dtype_terminals();
  m.attr("dtype_truncations") = dtype_truncations();
  m.attr("dtype_rewards") = dtype_rewards();
  m.attr("dtype_actions") = dtype_actions();
  m.attr("dtype_masks") = dtype_masks();
  m.attr("dtype_success") = dtype_success();

#ifdef METTA_WITH_RAYLIB
  py::class_<HermesPy>(m, "Hermes")
      .def(py::init<>())
      .def("update", &HermesPy::update, py::arg("env"))
      .def("render", &HermesPy::render);
#endif
}
