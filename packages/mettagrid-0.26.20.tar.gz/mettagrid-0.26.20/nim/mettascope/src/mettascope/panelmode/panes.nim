# This example shows a draggable panel UI like in a large editor like VS Code or Blender.

import
  std/[strutils],
  bumpy, chroma, windy, silky,
  ../[common, configs]

type
  AreaScan* = enum
    Header
    Body
    North
    South
    East
    West

const
  AreaHeaderHeight = 32.0
  AreaMargin = 6.0

proc snapToPixels(rect: Rect): Rect =
  rect(rect.x.int.float32, rect.y.int.float32, rect.w.int.float32, rect.h.int.float32)

var
  dragArea: Area # For resizing splits
  dragPanel: Panel # For moving panels
  dropHighlight: Rect
  showDropHighlight: bool

  maybeDragStartPos: Vec2
  maybeDragPanel: Panel

proc movePanels*(area: Area, panels: seq[Panel])

proc clear*(area: Area) =
  ## Clear the area.
  for panel in area.panels:
    panel.parentArea = nil
  for subarea in area.areas:
    subarea.clear()
  area.panels.setLen(0)
  area.areas.setLen(0)

proc removeBlankAreas*(area: Area) =
  ## Remove blank areas recursively.
  if area.areas.len > 0:
    assert area.areas.len == 2
    if area.areas[0].panels.len == 0 and area.areas[0].areas.len == 0:
      if area.areas[1].panels.len > 0:
        area.movePanels(area.areas[1].panels)
        area.areas.setLen(0)
      elif area.areas[1].areas.len > 0:
        let oldAreas = area.areas
        area.areas = area.areas[1].areas
        area.split = oldAreas[1].split
        area.layout = oldAreas[1].layout
      else:
        discard
    elif area.areas[1].panels.len == 0 and area.areas[1].areas.len == 0:
      if area.areas[0].panels.len > 0:
        area.movePanels(area.areas[0].panels)
        area.areas.setLen(0)
      elif area.areas[0].areas.len > 0:
        let oldAreas = area.areas
        area.areas = area.areas[0].areas
        area.split = oldAreas[0].split
        area.layout = oldAreas[0].layout
      else:
        discard

    for subarea in area.areas:
      removeBlankAreas(subarea)

proc addPanel*(area: Area, name: string, draw: PanelDraw) =
  ## Add a panel to the area.
  let panel = Panel(name: name, parentArea: area, draw: draw)
  area.panels.add(panel)

proc movePanel*(area: Area, panel: Panel) =
  ## Move a panel to this area.
  let idx = panel.parentArea.panels.find(panel)
  if idx != -1:
    panel.parentArea.panels.delete(idx)
  area.panels.add(panel)
  panel.parentArea = area

proc insertPanel*(area: Area, panel: Panel, index: int) =
  ## Insert a panel into this area at a specific index.
  let idx = panel.parentArea.panels.find(panel)
  var finalIndex = index

  # If moving within the same area, adjust index if we're moving forward
  if panel.parentArea == area and idx != -1:
    if idx < index:
      finalIndex = index - 1

  if idx != -1:
    panel.parentArea.panels.delete(idx)

  # Clamp index to be safe
  finalIndex = clamp(finalIndex, 0, area.panels.len)

  area.panels.insert(panel, finalIndex)
  panel.parentArea = area
  # Update selected to the new panel position
  area.selectedPanelNum = finalIndex

proc getTabInsertInfo(area: Area, mousePos: Vec2): (int, Rect) =
  ## Get the insert information for a tab.
  var x = area.rect.x + 4
  let headerH = AreaHeaderHeight

  # If no panels, insert at 0
  if area.panels.len == 0:
    return (0, rect(x, area.rect.y + 2, 4, headerH - 4))

  var bestIndex = 0
  var minDist = float32.high
  var bestX = x

  # Check before first tab (index 0)
  let dist0 = abs(mousePos.x - x)
  minDist = dist0
  bestX = x
  bestIndex = 0

  for i, panel in area.panels:
    let textSize = sk.getTextSize("Default", panel.name)
    let tabW = textSize.x + 16

    # The gap after this tab (index i + 1)
    let gapX = x + tabW + 2
    let dist = abs(mousePos.x - gapX)
    if dist < minDist:
      minDist = dist
      bestIndex = i + 1
      bestX = gapX

    x += tabW + 2

  return (bestIndex, rect(bestX - 2, area.rect.y + 2, 4, headerH - 4))

proc movePanels*(area: Area, panels: seq[Panel]) =
  ## Move multiple panels to this area.
  var panelList = panels # Copy
  for panel in panelList:
    area.movePanel(panel)

proc split*(area: Area, layout: AreaLayout) =
  ## Split the area.
  let
    area1 = Area(rect: area.rect) # inherit rect initially
    area2 = Area(rect: area.rect)
  area.layout = layout
  area.split = 0.5
  area.areas.add(area1)
  area.areas.add(area2)

proc scan*(area: Area): (Area, AreaScan, Rect) =
  ## Scan the area to find the target under mouse.
  let mousePos = window.mousePos.vec2
  var
    targetArea: Area
    areaScan: AreaScan
    resRect: Rect

  proc visit(area: Area) =
    if not mousePos.overlaps(area.rect):
      return

    if area.areas.len > 0:
      for subarea in area.areas:
        visit(subarea)
    else:
      let
        headerRect = rect(
          area.rect.xy,
          vec2(area.rect.w, AreaHeaderHeight)
        )
        bodyRect = rect(
          area.rect.xy + vec2(0, AreaHeaderHeight),
          vec2(area.rect.w, area.rect.h - AreaHeaderHeight)
        )
        northRect = rect(
          area.rect.xy + vec2(0, AreaHeaderHeight),
          vec2(area.rect.w, area.rect.h * 0.2)
        )
        southRect = rect(
          area.rect.xy + vec2(0, area.rect.h * 0.8),
          vec2(area.rect.w, area.rect.h * 0.2)
        )
        eastRect = rect(
          area.rect.xy + vec2(area.rect.w * 0.8, 0) + vec2(0, AreaHeaderHeight),
          vec2(area.rect.w * 0.2, area.rect.h - AreaHeaderHeight)
        )
        westRect = rect(
          area.rect.xy + vec2(0, 0) + vec2(0, AreaHeaderHeight),
          vec2(area.rect.w * 0.2, area.rect.h - AreaHeaderHeight)
        )

      if mousePos.overlaps(headerRect):
        areaScan = Header
        resRect = headerRect
      elif mousePos.overlaps(northRect):
        areaScan = North
        resRect = northRect
      elif mousePos.overlaps(southRect):
        areaScan = South
        resRect = southRect
      elif mousePos.overlaps(eastRect):
        areaScan = East
        resRect = eastRect
      elif mousePos.overlaps(westRect):
        areaScan = West
        resRect = westRect
      elif mousePos.overlaps(bodyRect):
        areaScan = Body
        resRect = bodyRect

      targetArea = area

  visit(rootArea)
  return (targetArea, areaScan, resRect)

proc drawAreaRecursive(area: Area, r: Rect) =
  area.rect = r.snapToPixels()

  if area.areas.len > 0:
    let m = AreaMargin / 2
    if area.layout == Horizontal:
      # Top/Bottom
      let splitPos = r.h * area.split

      # Handle split resizing
      let splitRect = rect(r.x, r.y + splitPos - 2, r.w, 4)

      if dragArea == nil and window.mousePos.vec2.overlaps(splitRect):
        sk.cursor = Cursor(kind: ResizeUpDownCursor)
        if window.buttonPressed[MouseLeft]:
          dragArea = area

      let r1 = rect(r.x, r.y, r.w, splitPos - m)
      let r2 = rect(r.x, r.y + splitPos + m, r.w, r.h - splitPos - m)
      drawAreaRecursive(area.areas[0], r1)
      drawAreaRecursive(area.areas[1], r2)

    else:
      # Left/Right
      let splitPos = r.w * area.split

      let splitRect = rect(r.x + splitPos - 2, r.y, 4, r.h)

      if dragArea == nil and window.mousePos.vec2.overlaps(splitRect):
        sk.cursor = Cursor(kind: ResizeLeftRightCursor)
        if window.buttonPressed[MouseLeft]:
          dragArea = area

      let r1 = rect(r.x, r.y, splitPos - m, r.h)
      let r2 = rect(r.x + splitPos + m, r.y, r.w - splitPos - m, r.h)
      drawAreaRecursive(area.areas[0], r1)
      drawAreaRecursive(area.areas[1], r2)

  elif area.panels.len > 0:
    # Draw Panel
    if area.selectedPanelNum > area.panels.len - 1:
      area.selectedPanelNum = area.panels.len - 1

    # Draw Header
    let headerRect = rect(r.x, r.y, r.w, AreaHeaderHeight)
    sk.draw9Patch("panel.header.9patch", 3, headerRect.xy, headerRect.wh)

    # Draw Tabs
    var x = r.x + 4
    sk.pushClipRect(rect(r.x, r.y, r.w - 2, AreaHeaderHeight))
    for i, panel in area.panels:
      let textSize = sk.getTextSize("Default", panel.name)
      let tabW = textSize.x + 16
      let tabRect = rect(x, r.y + 4, tabW, AreaHeaderHeight - 4)

      let isSelected = i == area.selectedPanelNum
      let isHovered = window.mousePos.vec2.overlaps(tabRect)

      # Handle Tab Clicks and Dragging
      if isHovered:
        if window.buttonPressed[MouseLeft]:
          area.selectedPanelNum = i
          savePanelLayout()
          # Only start dragging if the mouse moves 10 pixels.
          maybeDragStartPos = window.mousePos.vec2
          maybeDragPanel = panel
        elif window.buttonDown[MouseLeft] and dragPanel == panel:
          # Dragging started
          discard

      if window.buttonDown[MouseLeft]:
        if maybeDragPanel != nil and (maybeDragStartPos - window.mousePos.vec2).length() > 10:
          dragPanel = maybeDragPanel
          maybeDragStartPos = vec2(0, 0)
          maybeDragPanel = nil
      else:
        maybeDragStartPos = vec2(0, 0)
        maybeDragPanel = nil

      if isSelected:
        sk.draw9Patch("panel.tab.selected.9patch", 3, tabRect.xy, tabRect.wh, rgbx(255, 255, 255, 255))
      elif isHovered:
        sk.draw9Patch("panel.tab.hover.9patch", 3, tabRect.xy, tabRect.wh, rgbx(255, 255, 255, 255))
      else:
        sk.draw9Patch("panel.tab.9patch", 3, tabRect.xy, tabRect.wh)

      discard sk.drawText("Default", panel.name, vec2(x + 8, r.y + 4 + 2), rgbx(255, 255, 255, 255))

      x += tabW + 2
    sk.popClipRect()

    # Draw Content
    let contentRect = rect(r.x, r.y + AreaHeaderHeight, r.w, r.h - AreaHeaderHeight)
    let activePanel = area.panels[area.selectedPanelNum]
    let frameId = "panel:" & $cast[uint](activePanel)
    let contentPos = vec2(contentRect.x, contentRect.y)
    let contentSize = vec2(contentRect.w, contentRect.h)

    activePanel.draw(activePanel, frameId, contentPos, contentSize)

proc drawPanels*() =
  # Reset cursor
  sk.cursor = Cursor(kind: ArrowCursor)

  # Update Dragging Split
  if dragArea != nil:
    if not window.buttonDown[MouseLeft]:
      dragArea = nil
      savePanelLayout()
    else:
      if dragArea.layout == Horizontal:
        sk.cursor = Cursor(kind: ResizeUpDownCursor)
        dragArea.split = (window.mousePos.vec2.y - dragArea.rect.y) / dragArea.rect.h
      else:
        sk.cursor = Cursor(kind: ResizeLeftRightCursor)
        dragArea.split = (window.mousePos.vec2.x - dragArea.rect.x) / dragArea.rect.w
      dragArea.split = clamp(dragArea.split, 0.1, 0.9)

  # Update Dragging Panel
  showDropHighlight = false
  if dragPanel != nil:
    if not window.buttonDown[MouseLeft]:
      # Drop
      let (targetArea, areaScan, _) = rootArea.scan()
      if targetArea != nil:
        case areaScan:
          of Header:
            let (idx, _) = targetArea.getTabInsertInfo(window.mousePos.vec2)
            targetArea.insertPanel(dragPanel, idx)
          of Body:
            targetArea.movePanel(dragPanel)
          of North:
            targetArea.split(Horizontal)
            targetArea.areas[0].movePanel(dragPanel)
            targetArea.areas[1].movePanels(targetArea.panels)
          of South:
            targetArea.split(Horizontal)
            targetArea.areas[1].movePanel(dragPanel)
            targetArea.areas[0].movePanels(targetArea.panels)
          of East:
            targetArea.split(Vertical)
            targetArea.areas[1].movePanel(dragPanel)
            targetArea.areas[0].movePanels(targetArea.panels)
          of West:
            targetArea.split(Vertical)
            targetArea.areas[0].movePanel(dragPanel)
            targetArea.areas[1].movePanels(targetArea.panels)

        rootArea.removeBlankAreas()
        savePanelLayout()
      dragPanel = nil
    else:
      # Dragging
      let (targetArea, areaScan, rect) = rootArea.scan()
      dropHighlight = rect
      showDropHighlight = true

      if targetArea != nil and areaScan == Header:
         let (_, highlightRect) = targetArea.getTabInsertInfo(window.mousePos.vec2)
         dropHighlight = highlightRect

  # Draw Areas
  drawAreaRecursive(rootArea, rect(0, 64, window.size.x.float32, window.size.y.float32 - 64 * 3))

  # Draw Drop Highlight
  if showDropHighlight and dragPanel != nil:
    sk.drawRect(dropHighlight.xy, dropHighlight.wh, rgbx(255, 255, 0, 100))

    # Draw dragging ghost
    let label = dragPanel.name
    let textSize = sk.getTextSize("Default", label)
    let size = textSize + vec2(16, 8)
    sk.draw9Patch("tooltip.9patch", 4, window.mousePos.vec2 + vec2(10, 10), size, rgbx(255, 255, 255, 200))
    discard sk.drawText("Default", label, window.mousePos.vec2 + vec2(18, 14), rgbx(255, 255, 255, 255))

proc drawWarningPopup*() =
  ## Draw a warning popup if popupWarning is set.
  if popupWarning.len == 0:
    return

  # Semi-transparent overlay covering entire screen
  sk.drawRect(vec2(0, 0), sk.size, rgbx(0, 0, 0, 128))

  let
    popupWidth = 400.0
    popupHeight = 150.0
    popupPos = vec2((sk.size.x - popupWidth) / 2, (sk.size.y - popupHeight) / 2)
    textPos = popupPos + vec2(8, 48)
    textWidth = popupWidth - 16.0
    textHeight = popupHeight - 56.0

  sk.draw9Patch("header.9patch", 4, popupPos, vec2(popupWidth, popupHeight), rgbx(255, 255, 255, 255))

  sk.at = popupPos + vec2(8, 4)
  h1text("Error")
  discard sk.drawText(
    "Default",
    popupWarning,
    textPos,
    rgbx(255, 255, 255, 255),
    maxWidth = textWidth,
    maxHeight = textHeight,
    wordWrap = true
  )

proc drawTutorialOverlay*() =
  ## Draw in-game tutorial guidance if present on the current replay.
  if replay.isNil:
    return

  let phaseCount = replay.tutorialOverlayPhases.len
  if phaseCount > 0:
    replay.tutorialOverlayPhase = replay.tutorialOverlayPhase.clamp(0, phaseCount - 1)
    replay.tutorialOverlay = replay.tutorialOverlayPhases[replay.tutorialOverlayPhase]

  var overlayText = replay.tutorialOverlay
  if overlayText.len == 0:
    return

  let
    overlayWidth = min(1196.0f, sk.size.x - 48.0f)
    overlayHeight = min(435.0f, sk.size.y - 96.0f)
    overlayPos = vec2((sk.size.x - overlayWidth) / 2.0f, 48.0f)
    bodyPos = overlayPos + vec2(18.0f, 88.0f)
    bodyWidth = overlayWidth - 36.0f
    bodyHeight = overlayHeight - 150.0f
    nextButtonSize = vec2(240.0f, 42.0f)
    nextButtonPos = overlayPos + vec2(overlayWidth - nextButtonSize.x - 16.0f, overlayHeight - nextButtonSize.y - 24.0f)
    nextButtonRect = rect(nextButtonPos.x, nextButtonPos.y, nextButtonSize.x, nextButtonSize.y)
    nextButtonHovered = window.mousePos.vec2.overlaps(nextButtonRect)
  let advanceOrClosePressed = window.buttonPressed[KeyEnter] or (nextButtonHovered and window.buttonPressed[MouseLeft])
  var canAdvance = phaseCount > 0 and replay.tutorialOverlayPhase < phaseCount - 1

  if advanceOrClosePressed:
    if canAdvance:
      replay.tutorialOverlayPhase = min(replay.tutorialOverlayPhase + 1, phaseCount - 1)
      replay.tutorialOverlay = replay.tutorialOverlayPhases[replay.tutorialOverlayPhase]
      overlayText = replay.tutorialOverlay
      canAdvance = replay.tutorialOverlayPhase < phaseCount - 1
    else:
      replay.tutorialOverlay = ""
      replay.tutorialOverlayPhases = @[]
      replay.tutorialOverlayPhase = 0
      return

  var
    titleText = overlayText
    bodyText = ""
  let lineBreak = overlayText.find('\n')
  if lineBreak >= 0:
    titleText = overlayText[0 ..< lineBreak]
    bodyText = overlayText[lineBreak + 1 .. ^1]

  sk.draw9Patch("header.9patch", 4, overlayPos, vec2(overlayWidth, overlayHeight), rgbx(45, 80, 45, 230))

  sk.at = overlayPos + vec2(18.0f, 8.0f)
  h1text("Tutorial")
  sk.at = overlayPos + vec2(18.0f, 38.0f)
  h1text(titleText)
  if bodyText.len > 0:
    discard sk.drawText(
      "H1",
      bodyText,
      bodyPos,
      rgbx(255, 255, 255, 255),
      maxWidth = bodyWidth,
      maxHeight = bodyHeight,
      wordWrap = true
    )

  if phaseCount > 0:
    let phaseLabel = "Phase " & $(replay.tutorialOverlayPhase + 1) & "/" & $phaseCount
    discard sk.drawText(
      "H1",
      phaseLabel,
      overlayPos + vec2(overlayWidth - 190.0f, 2.0f),
      rgbx(218, 235, 218, 255)
    )

  let buttonText = if canAdvance: "Next (Enter)" else: "Close"
  let nextButtonPatch =
    if nextButtonHovered: "panel.tab.hover.9patch"
    else: "panel.tab.selected.9patch"
  sk.draw9Patch(nextButtonPatch, 3, nextButtonPos, nextButtonSize, rgbx(255, 255, 255, 255))
  discard sk.drawText(
    "H1",
    buttonText,
    nextButtonPos + vec2(24.0f, 10.0f),
    rgbx(245, 245, 245, 255)
  )

  if canAdvance:
    discard sk.drawText(
      "H1",
      "Press Enter or click Next to continue",
      overlayPos + vec2(18.0f, overlayHeight - 46.0f),
      rgbx(218, 235, 218, 255)
    )
