import
  std/[strutils, strformat, os],
  opengl, windy, bumpy, vmath, silky, chroma,
  mettascope/[replays, common, atlas, replayloader, configs],
  mettascope/gamemode/[worldmap, minimap, gameplayer, camera, talk],
  mettascope/panelmode/[panes, footer, timeline, header,
    objectpanel, policyinfopanel, envpanel, vibespanel, scorepanel,
    monologuepanel, talkpanel]
import slappy except play

when defined(emscripten):
  import webby
  import mettascope/multiplayer
else:
  import std/parseopt

when isMainModule:
  let config = loadConfig()

  window = newWindow(
    "MettaScope",
    ivec2(config.windowWidth, config.windowHeight),
    vsync = true
  )
  makeContextCurrent(window)
  loadExtensions()

when defined(emscripten):
  proc parseUrlParams() =
    ## Parse URL parameters.
    let url = parseUrl(window.url)
    let wsParam = url.query["ws"]
    if wsParam != "":
      mpConnect(wsParam)
    else:
      commandLineReplay = url.query["replay"]

when not defined(emscripten):
  proc parseArgs() =
    ## Parse command line arguments.
    var p = initOptParser(commandLineParams())
    while true:
      p.next()
      case p.kind
      of cmdEnd:
        break
      of cmdLongOption, cmdShortOption:
        case p.key
        of "replay", "r":
          commandLineReplay = p.val
        of "game-mode", "g":
          forcedGameMode = Game
        of "editor-mode", "e":
          forcedGameMode = Editor
        of "autostart", "a":
          play = p.val == "true" or p.val == ""
        else:
          quit("Unknown option: " & p.key)
      of cmdArgument:
        quit("Unknown option: " & p.key)

proc replaySwitch(replay: string) =
  ## Load the replay.
  case common.playMode
  of Historical:
    if commandLineReplay != "":
      if commandLineReplay.startsWith("http"):
        common.replay = EmptyReplay
        echo "fetching replay from URL: ", commandLineReplay
        let req = startHttpRequest(commandLineReplay)
        req.onError = proc(msg: string) =
          echo "Failed to load replay from URL (network error): ", msg
          popupWarning = "Failed to load replay from URL.\nNetwork error: " & msg
          replayDownloadActive = false
        req.onResponse = proc(response: HttpResponse) =
          replayDownloadActive = false
          if response.code != 200:
            echo "Failed to load replay from URL (HTTP ", response.code, "): ", response.body
            case response.code:
            of 403:
              popupWarning = "Access denied (403 Forbidden).\nThe replay requires authentication or you don't have permission to access it."
            of 404:
              popupWarning = "Replay not found (404).\nThe replay URL is invalid or the file has been moved."
            of 500, 502, 503, 504:
              popupWarning = "Server error (" & $response.code & ").\nThe replay server is experiencing issues. Please try again later."
            else:
              popupWarning = "Failed to load replay (HTTP " & $response.code & ").\n" & response.body
            return
          echo "replay fetched, loading..."
          try:
            common.replay = loadReplay(response.body, commandLineReplay)
            onReplayLoaded()
          except:
            let err = getCurrentExceptionMsg()
            echo "Failed to load replay from URL (parse/load error): ", err
            popupWarning = "Failed to load replay from URL.\n" & err
            common.replay = EmptyReplay
        req.onDownloadProgress = proc(completed, total: int) =
          replayDownloadActive = true
          replayDownloadProgress =
            if total < 1: 0.5
            else: min(completed / total, 1.0)
          echo "replay download progress: ", fmt"{replayDownloadProgress * 100:.2f}%"
      else:
        echo "Loading replay from file: ", commandLineReplay
        try:
          common.replay = loadReplay(commandLineReplay)
          onReplayLoaded()
        except:
          popupWarning = "Failed to load replay file.\n" & getCurrentExceptionMsg()
          common.replay = EmptyReplay
    elif common.replay == nil:
      let defaultReplay = dataDir / "replays" / "default.json.z"
      echo "Loading replay from default file: ", defaultReplay
      try:
        common.replay = loadReplay(defaultReplay)
        onReplayLoaded()
      except:
        popupWarning = "Failed to load default replay file.\n" & getCurrentExceptionMsg()
        common.replay = EmptyReplay
  of Realtime:
    echo "Realtime mode"
    onReplayLoaded()

proc drawReplayDownloadProgress*() =
  ## Draws a dim overlay with a centered progress bar and download percentage while a replay is loading.
  if not replayDownloadActive: return
  let
    font = "Default"
    margin = 48.0
    barW = sk.size.x - margin * 2
    barH = 12.0
    barPos = vec2(margin, sk.size.y * 0.5 - barH * 0.5)
    fillW = barW * replayDownloadProgress
    labelPos = barPos + vec2(0, -30)
    progressPos = barPos + vec2(barW * 0.5, -30)
  sk.drawRect(vec2(0, 0), sk.size, rgbx(0, 0, 0, 140))
  sk.drawRect(barPos, vec2(barW, barH), rgbx(60, 60, 60, 255))
  sk.drawRect(barPos, vec2(fillW, barH), rgbx(180, 180, 180, 255))
  discard sk.drawText(font, "Downloading Replay", labelPos, rgbx(255, 255, 255, 255))
  discard sk.drawText(font, fmt"{replayDownloadProgress * 100:.2f}%", progressPos, rgbx(255, 255, 255, 255))

proc drawWorldMap(panel: Panel, frameId: string, contentPos: Vec2, contentSize: Vec2) {.measure.} =
  ## Draw the world map.
  sk.draw9Patch("panel.body.empty.9patch", 3, contentPos, contentSize)

  worldMapZoomInfo.rect = irect(contentPos.x, contentPos.y, contentSize.x, contentSize.y)
  worldMapZoomInfo.hasMouse = sk.mouseHover(window, rect(contentPos, contentSize))

  applyModeSwitchCenter(worldMapZoomInfo)

  glEnable(GL_SCISSOR_TEST)
  glScissor(contentPos.x.int32, window.size.y.int32 - contentPos.y.int32 - contentSize.y.int32, contentSize.x.int32, contentSize.y.int32)
  glClearColor(1.0f, 0.0f, 0.0f, 1.0f)

  saveTransform()
  translateTransform(contentPos)
  drawWorldMap(worldMapZoomInfo)
  restoreTransform()
  drawTalkBubbles(worldMapZoomInfo)

  glDisable(GL_SCISSOR_TEST)

proc drawMinimap(panel: Panel, frameId: string, contentPos: Vec2, contentSize: Vec2) {.measure.} =
  ## Draw the minimap.
  sk.draw9Patch("panel.body.empty.9patch", 3, contentPos, contentSize)

  glEnable(GL_SCISSOR_TEST)
  glScissor(contentPos.x.int32, window.size.y.int32 - contentPos.y.int32 - contentSize.y.int32, contentSize.x.int32, contentSize.y.int32)

  let minimapZoomInfo = ZoomInfo()
  minimapZoomInfo.rect = irect(contentPos.x, contentPos.y, contentSize.x, contentSize.y)
  # Adjust zoom info and draw the minimap.
  minimapZoomInfo.hasMouse = sk.mouseHover(window, rect(contentPos, contentSize))

  saveTransform()
  translateTransform(contentPos)
  drawMinimap(minimapZoomInfo)
  restoreTransform()

  glDisable(GL_SCISSOR_TEST)

proc createDefaultPanelLayout() =
  ## Create the default panel layout.
  rootArea = Area()
  rootArea.split(Vertical)
  rootArea.split = 0.22

  rootArea.areas[0].split(Horizontal)
  rootArea.areas[0].split = 0.7

  rootArea.areas[1].split(Vertical)
  rootArea.areas[1].split = 0.85

  rootArea.areas[0].areas[0].addPanel("Object", drawObjectInfo)
  rootArea.areas[0].areas[0].addPanel("Policy Info", drawPolicyInfo)
  rootArea.areas[0].areas[0].addPanel("Environment", drawEnvironmentInfo)

  rootArea.areas[1].areas[0].addPanel("Map", drawWorldMap)
  rootArea.areas[0].areas[1].addPanel("Minimap", drawMinimap)

  rootArea.areas[1].areas[1].addPanel("Vibes", drawVibes)
  rootArea.areas[1].areas[1].addPanel("Talk", drawTalkPanel)
  rootArea.areas[1].areas[1].addPanel("Score", drawScorePanel)
  rootArea.areas[1].areas[1].addPanel("Monologue", drawMonologuePanel)

proc findFirstLeafArea(area: Area): Area =
  ## Find the first leaf area (one that has panels) in the tree.
  if area.panels.len > 0:
    return area
  for subarea in area.areas:
    let leaf = findFirstLeafArea(subarea)
    if leaf != nil:
      return leaf
  return nil

proc insertMissingMonologuePanel(area: Area) =
  if getPanelByName(area, "Monologue") != nil:
    return

  let scorePanel = getPanelByName(area, "Score")
  if scorePanel != nil and scorePanel.parentArea != nil:
    var insertIndex = scorePanel.parentArea.panels.len
    for idx, panel in scorePanel.parentArea.panels:
      if panel == scorePanel:
        insertIndex = idx + 1
        break
    scorePanel.parentArea.panels.insert(
      Panel(name: "Monologue", parentArea: scorePanel.parentArea, draw: drawMonologuePanel),
      insertIndex
    )
    echo "Added missing panel: Monologue"
    return

  let fallbackArea = findFirstLeafArea(area)
  if fallbackArea != nil:
    fallbackArea.panels.add(Panel(name: "Monologue", parentArea: fallbackArea, draw: drawMonologuePanel))
    echo "Added missing panel: Monologue"

proc initPanels() =
  ## Initialize panels, loading layout from config if available.
  let config = loadConfig()
  applyUIState(config)
  createDefaultPanelLayout()

  # Remember the default panels before potentially overwriting with saved layout.
  let defaultArea = rootArea

  var layoutLoaded = false
  if config.panelLayout.areas.len > 0 or config.panelLayout.panelNames.len > 0:
    try:
      rootArea = deserializeArea(config.panelLayout, defaultArea)
      if validateAreaStructure(rootArea, true):
        layoutLoaded = true
      else:
        rootArea = defaultArea
    except:
      echo "Error loading panel layout from config, using default: ", getCurrentExceptionMsg()
      rootArea = defaultArea

  if layoutLoaded:
    insertMissingMonologuePanel(rootArea)


proc onFrame() =

  playControls()

  sk.beginUI(window, window.size)

  glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
  glClear(GL_COLOR_BUFFER_BIT)

  # Enable premultiplied alpha blending for all raw OpenGL shader draws.
  # Pixie textures (tilemaps, sprites, clouds, AoE overlays) are premultiplied.
  glEnable(GL_BLEND)
  glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA)

  if gameMode == Editor:
    ## Editor mode UI.
    drawHeader()
    drawTimeline(vec2(0, sk.size.y - 64 - 33), vec2(sk.size.x, 32))
    drawFooter(vec2(0, sk.size.y - 64), vec2(sk.size.x, 64))
    drawPanels()
  else:
    ## Game mode UI.
    drawGameWorld()

  drawTutorialOverlay()
  drawWarningPopup()
  drawReplayDownloadProgress()
  sk.endUi()
  window.swapBuffers()

  if window.cursor.kind != sk.cursor.kind:
    window.cursor = sk.cursor

proc initMettascope*() {.measure.} =
  window.onFrame = onFrame

  window.onResize = proc() =
    var currentConfig = loadConfig()
    currentConfig.windowWidth = window.size.x.int32
    currentConfig.windowHeight = window.size.y.int32
    saveConfig(currentConfig)

  window.onFileDrop = proc(fileName: string, fileData: string) =
    echo "File dropped: ", fileName, " (", fileData.len, " bytes)"
    if fileName.endsWith(".json.z"):
      try:
        common.replay = loadReplay(fileData, fileName)
        onReplayLoaded()
        echo "Successfully loaded replay: ", fileName
      except:
        popupWarning = "Failed to load replay file.\n" & getCurrentExceptionMsg()
    else:
      popupWarning = "Unsupported file type.\nOnly .json.z replay files are supported."

  let builder = buildSilkyAtlas()
  sk = newSilky(window, builder.atlasImage, builder.atlas)
  initPanels()
  window.onRune = proc(rune: Rune) =
    if talkComposeActive and rune.int >= 32 and rune.int <= 126:
      sk.inputRunes.add(rune)

  ## Initialize the world map zoom info.
  worldMapZoomInfo = ZoomInfo()
  worldMapZoomInfo.rect = IRect(x: 0, y: 0, w: 500, h: 500)
  worldMapZoomInfo.pos = vec2(0, 0)
  worldMapZoomInfo.zoom = 10
  worldMapZoomInfo.minZoom = 0.5
  worldMapZoomInfo.maxZoom = 50
  worldMapZoomInfo.scrollArea = Rect(x: 0, y: 0, w: 500, h: 500)
  worldMapZoomInfo.hasMouse = false

  when defined(emscripten):
    parseUrlParams()
  else:
    parseArgs()

  if playMode == Historical:
    replaySwitch(commandLineReplay)

  slappyInit()

proc tickMettascope*() =
  pollEvents()

proc closeMettascope*() =
  slappyClose()

proc main() =
  ## Main entry point.
  ##
  when defined(profileOnStart):
    # Compile with -d:profileOnStart to start tracing on startup.
    # Don't forget to press F3 soon after startup dump the trace.
    traceActive = true
    startTrace()

  initMettascope()

  while not window.closeRequested:
    tickMettascope()
    when defined(emscripten):
      if multiplayerActive:
        mpSyncControls()
        if requestPython:
          mpSendActions()

  closeMettascope()

when isMainModule:
  main()
