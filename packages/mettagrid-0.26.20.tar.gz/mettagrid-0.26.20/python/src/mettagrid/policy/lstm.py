# ruff: noqa: E402
import logging
from typing import Optional, Union

from mettagrid.optional_deps import require_train

require_train("mettagrid.policy.lstm")

import numpy as np
import torch
import torch.nn as nn
from einops import rearrange

import pufferlib.pytorch
from mettagrid.policy.policy import AgentPolicy, MultiAgentPolicy, StatefulAgentPolicy, StatefulPolicyImpl
from mettagrid.policy.policy_env_interface import PolicyEnvInterface
from mettagrid.policy.utils import LSTMState, LSTMStateDict
from mettagrid.simulator import Action as MettaGridAction
from mettagrid.simulator import AgentObservation as MettaGridObservation

logger = logging.getLogger("mettagrid.policy.lstm_policy")


class LSTMPolicyNet(torch.nn.Module):
    def __init__(self, policy_env_info: PolicyEnvInterface):
        super().__init__()
        # Public: Required by PufferLib for RNN state management
        self.hidden_size = 128
        action_names = policy_env_info.action_names

        self._net = torch.nn.Sequential(
            pufferlib.pytorch.layer_init(
                torch.nn.Linear(int(np.prod(policy_env_info.observation_space.shape)), self.hidden_size)
            ),
            torch.nn.ReLU(),
            pufferlib.pytorch.layer_init(torch.nn.Linear(self.hidden_size, self.hidden_size)),
        )

        self._rnn = torch.nn.LSTM(self.hidden_size, self.hidden_size, batch_first=True)

        self._action_head = torch.nn.Linear(self.hidden_size, len(action_names))
        self._value_head = torch.nn.Linear(self.hidden_size, 1)

    def forward_eval(
        self,
        observations: torch.Tensor,
        state: Optional[Union[LSTMState, tuple[torch.Tensor, torch.Tensor], dict[str, torch.Tensor]]] = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # Handle different input shapes:
        # - bptt_horizon=1: (batch_size, *obs_shape) e.g. (128, 7, 7, 3)
        # - bptt_horizon>1: (segments, bptt_horizon, *obs_shape) e.g. (128, 2, 7, 7, 3)
        # We need to output: (batch_size * bptt_horizon, flattened_obs_size)
        orig_shape = observations.shape

        # Figure out expected flattened obs size from self._net input size
        first_layer = self._net[0]
        assert isinstance(first_layer, nn.Linear)
        expected_obs_size = first_layer.in_features

        # Check if we have temporal dimension
        # With bptt_horizon>1, we get (segments, bptt_horizon, *obs_shape)
        # We need to detect this and reshape to (segments * bptt_horizon, obs_size)
        total_elements = observations.numel()
        batch_size = orig_shape[0]

        # If total_elements / batch_size != expected_obs_size, we have a temporal dimension
        if total_elements // batch_size != expected_obs_size:
            # We have (segments, bptt_horizon, *obs_shape)
            # Calculate bptt_horizon
            bptt_horizon = total_elements // (batch_size * expected_obs_size)
            segments = batch_size
            # Reshape to (segments * bptt_horizon, obs_size)
            observations = observations.reshape(segments * bptt_horizon, expected_obs_size).float()
        else:
            # Normal case: (batch_size, *obs_shape)
            segments = batch_size
            bptt_horizon = 1
            observations = observations.reshape(segments, expected_obs_size).float()

        # Only normalize if values are in uint8 range (0-255)
        if observations.max() > 1.0:
            observations = observations / 255.0

        hidden = self._net(observations)
        hidden = rearrange(hidden, "(b t) h -> b t h", t=bptt_horizon, b=segments)

        # Handle state being passed as either a dict (from PufferLib) or tuple (from our API)
        rnn_state = None

        if state is not None:
            if isinstance(state, dict):
                # PufferLib passes state as dict with "lstm_h" and "lstm_c" keys
                h, c = state.get("lstm_h"), state.get("lstm_c")
                # Handle None state (initial state)
                if h is not None and c is not None:
                    # PufferLib uses shape (batch_size, num_layers, hidden_size)
                    # but PyTorch LSTM expects (num_layers, batch_size, hidden_size)
                    if h.dim() == 3:
                        # Transpose from (batch, layers, hidden) to (layers, batch, hidden)
                        h = h.transpose(0, 1)
                        c = c.transpose(0, 1)
                    elif h.dim() == 2:
                        # (batch, hidden) -> (1, batch, hidden)
                        h = h.unsqueeze(0)
                        c = c.unsqueeze(0)
                    elif h.dim() == 1:
                        # (hidden,) -> (1, 1, hidden)
                        h = h.unsqueeze(0).unsqueeze(0)
                        c = c.unsqueeze(0).unsqueeze(0)
                    rnn_state = (h, c)
            else:
                # Tuple state for inference mode - assume correct shape
                if isinstance(state, LSTMState):
                    h, c = state.to_tuple()
                else:
                    h, c = state

                if h.dim() == 2:
                    h = h.unsqueeze(0)
                    c = c.unsqueeze(0)
                elif h.dim() == 1:
                    h = h.unsqueeze(0).unsqueeze(0)
                    c = c.unsqueeze(0).unsqueeze(0)
                rnn_state = (h, c)

        hidden, new_state = self._rnn(hidden, rnn_state)

        # If state was passed as a dict with LSTM keys, update it in-place with new state
        if isinstance(state, dict) and "lstm_h" in state and "lstm_c" in state:
            h, c = new_state
            # Transpose back to PufferLib format: (layers, batch, hidden) -> (batch, layers, hidden)
            if h.dim() == 3:
                h = h.transpose(0, 1)
                c = c.transpose(0, 1)
            elif h.dim() == 2:
                # (batch, hidden) -> (batch, layers=1, hidden)
                h = h.unsqueeze(1)
                c = c.unsqueeze(1)
            elif h.dim() == 1:
                # (hidden,) -> (batch=1, layers=1, hidden)
                h = h.unsqueeze(0).unsqueeze(1)
                c = c.unsqueeze(0).unsqueeze(1)
            state["lstm_h"], state["lstm_c"] = h, c

        hidden = rearrange(hidden, "b t h -> (b t) h")
        logits = self._action_head(hidden)

        values = self._value_head(hidden)
        return logits, values

    # We use this to work around a major torch perf issue
    def forward(
        self,
        observations: torch.Tensor,
        state: Optional[Union[tuple[torch.Tensor, torch.Tensor], dict[str, torch.Tensor]]] = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        return self.forward_eval(observations, state)


def obs_to_obs_tensor(obs: MettaGridObservation, obs_shape: tuple[int, ...], device: torch.device) -> torch.Tensor:
    """Get action and update state for this agent."""

    # Create observation array matching the training format
    # Training uses a fixed-size buffer of (num_tokens, token_dim) from policy_env_info
    obs_array = np.full(obs_shape, [255, 0, 0], dtype=np.uint8)

    # Fill with actual token data
    for i, token in enumerate(obs.tokens):
        if i < obs_shape[0]:
            obs_array[i] = token.raw_token

    return torch.from_numpy(obs_array).unsqueeze(0).to(device)


class LSTMAgentPolicy(StatefulPolicyImpl[LSTMState]):
    """Per-agent policy implementation that uses the shared LSTM network."""

    def __init__(self, net: LSTMPolicyNet, device: torch.device, policy_env_info: PolicyEnvInterface):
        self._net = net
        self._device = device
        self._policy_env_info = policy_env_info

    def initial_agent_state(self) -> LSTMState:
        """Get initial state for a new agent.

        For LSTM, we return a zero-initialized state with shape (num_layers, hidden_size).
        """
        num_layers = self._net._rnn.num_layers * (2 if self._net._rnn.bidirectional else 1)
        hidden_size = self._net.hidden_size
        # Create zero tensors with shape (num_layers, hidden_size) for a single agent
        hidden = torch.zeros((num_layers, hidden_size), device=self._device)
        cell = torch.zeros((num_layers, hidden_size), device=self._device)
        return LSTMState(hidden=hidden, cell=cell)

    def step_with_state(
        self,
        obs: MettaGridObservation,
        state: LSTMState,
    ) -> tuple[MettaGridAction, LSTMState]:
        obs_tensor = obs_to_obs_tensor(obs, self._policy_env_info.observation_space.shape, self._device)

        self._net.eval()
        # For inference, we pass state through a dict so forward_eval can populate it
        hidden, cell = state.to_tuple()
        state_dict: LSTMStateDict = {"lstm_h": hidden, "lstm_c": cell}

        # Debug: check observation
        if torch.isnan(obs_tensor).any():
            logger.error(f"NaN in observation! obs shape: {obs_tensor.shape}, obs: {obs_tensor}")
        if torch.isinf(obs_tensor).any():
            logger.error(f"Inf in observation! obs shape: {obs_tensor.shape}")

        logits, _ = self._net.forward_eval(obs_tensor, state_dict)

        # Debug: check logits
        if torch.isnan(logits).any():
            logger.error(
                f"NaN in logits! obs shape: {obs_tensor.shape}, obs min/max: {obs_tensor.min()}/{obs_tensor.max()}"
            )
            logger.error(f"Logits: {logits}")
            for name, param in self._net.named_parameters():
                if torch.isnan(param).any():
                    logger.error(f"NaN in parameter {name}")

        # Extract the new state from the dict
        h, c = state_dict["lstm_h"], state_dict["lstm_c"]
        tuple_state = (h.detach(), c.detach())
        layers = self._net._rnn.num_layers * (2 if self._net._rnn.bidirectional else 1)
        new_state = LSTMState.from_tuple(tuple_state, layers)

        # Sample action from the logits
        dist = torch.distributions.Categorical(logits=logits)
        sampled_action = int(dist.sample().cpu().item())
        # Convert action index to Action object
        action = MettaGridAction(name=self._policy_env_info.action_names[sampled_action])
        return action, new_state.detach()


class LSTMPolicy(MultiAgentPolicy):
    """LSTM-based policy that creates StatefulPolicy wrappers for each agent."""

    short_names = ["lstm"]

    def __init__(self, policy_env_info: PolicyEnvInterface, device: str = "cpu"):
        super().__init__(policy_env_info, device=device)
        self._device = torch.device(device)
        self._policy_env_info = policy_env_info
        self._net = LSTMPolicyNet(policy_env_info).to(self._device)
        self._agent_policy = LSTMAgentPolicy(self._net, self._device, policy_env_info)
        self._agent_policy._device = self._device

    def network(self) -> nn.Module:
        """Return the underlying LSTM network for training."""
        return self._net

    def agent_policy(self, agent_id: int) -> AgentPolicy:
        """Create a StatefulPolicy wrapper for a specific agent."""
        return StatefulAgentPolicy(self._agent_policy, self._policy_env_info, agent_id=agent_id)

    def is_recurrent(self) -> bool:
        return True

    def load_policy_data(self, checkpoint_path: str) -> None:
        """Load LSTM network weights from file."""
        self._net.load_state_dict(torch.load(checkpoint_path, map_location=self._device))
        self._net = self._net.to(self._device)
        self._agent_policy._net = self._net
        self._agent_policy._device = self._device

    def save_policy_data(self, checkpoint_path: str) -> None:
        """Save LSTM network weights to file."""
        torch.save(self._net.state_dict(), checkpoint_path)
