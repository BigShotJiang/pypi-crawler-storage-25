"""Simple tracer for timing policy-engine interactions.

Outputs Chrome Trace Format: https://docs.google.com/document/d/1CvAClvFfyA5R-PhYUmn5OOQtYMH4h6I0nSsKchNAySU

TODO (tracer work in progress):
- Clean up metadata handling: don't pass arbitrary kwargs from rollout through to JSON;
  explicitly define what fields we support
- Add type annotations to __init__ methods
- Add tests (write to real temp dir, inspect output)
- Clearer typing on calls from rollout to tracer (Span.set() kwargs)
- Multi-episode rollout: run_multi_episode_rollout doesn't wire through obs_dir yet
"""

import gc
import json
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from types import TracebackType
from typing import IO, Self


class Span:
    """A timed span that records start/end times and metadata."""

    def __init__(self, tracer: "Tracer", name: str, pid: int | None = None, **initial_metadata):
        self._tracer = tracer
        self._name = name
        self._pid = pid
        self._metadata = initial_metadata
        self._start_ns: int = 0

    def set(self, **metadata) -> None:
        """Add metadata to this span."""
        self._metadata.update(metadata)

    def __enter__(self) -> Self:
        self._start_ns = time.time_ns()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        end_ns = time.time_ns()
        self._tracer._write_span(self._name, self._start_ns, end_ns - self._start_ns, self._metadata, pid=self._pid)


class NullSpan(Span):
    """No-op span for when tracing is disabled."""

    def __init__(self):
        pass

    def set(self, **metadata) -> None:
        pass

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        pass


_NULL_SPAN = NullSpan()


class Tracer:
    """Lightweight tracer that streams spans to Chrome Trace Format JSON."""

    # Agents use pid = agent_id so Perfetto displays "Agent 0", "Agent 1", etc.
    # Environment uses a high pid to stay out of the agent range; tracing UIs
    # will break well before we have 100k agents.
    PID_ENV = 100000
    PID_EXECUTOR = 200000

    def __init__(self, output_path: Path | str):
        self._write_lock = threading.RLock()
        self._file: IO[str] = open(output_path, "w")
        self._file.write("[")
        self._first = True
        self._flushed = False
        self._writing_event = False
        self._gc_start_ns: int = 0
        self._known_pids: set[int] = set()
        gc.callbacks.append(self._gc_callback)
        self._write_process_name(self.PID_ENV, "Env", sort_index=-1)

    def _gc_callback(self, phase: str, info: dict) -> None:
        """Record GC events in the trace."""
        with self._write_lock:
            if self._flushed or self._writing_event:
                return
            if phase == "start":
                self._gc_start_ns = time.time_ns()
                return
            if self._gc_start_ns == 0:
                return
            self._write_span(
                "gc",
                self._gc_start_ns,
                time.time_ns() - self._gc_start_ns,
                {"generation": info["generation"], "collected": info["collected"]},
            )
            self._gc_start_ns = 0

    def span(self, name: str, pid: int | None = None, **metadata) -> Span:
        """Create a span context manager for timing a block of code."""
        return Span(self, name, pid=pid, **metadata)

    def record_span(self, name: str, start_ns: int, duration_ns: int, pid: int | None = None, **metadata) -> None:
        """Record a completed span with explicit timing."""
        self._write_span(name, start_ns, duration_ns, metadata, pid=pid)

    @contextmanager
    def _ignore_reentrant_gc_callbacks(self):
        self._writing_event = True
        try:
            yield
        finally:
            self._writing_event = False

    def _write_event(self, event: dict) -> None:
        """Write a single event to the trace file.

        Must be a single write() call: GC callbacks can re-enter this method
        between any two bytecodes, so multi-call writes get interleaved.
        """
        with self._write_lock:
            if self._flushed:
                return
            with self._ignore_reentrant_gc_callbacks():
                prefix = "" if self._first else ","
                self._file.write(prefix + json.dumps(event) + "\n")
            self._first = False

    def _write_process_name(self, pid: int, name: str, sort_index: int) -> None:
        """Write process name and sort index metadata events."""
        self._write_event({"name": "process_name", "ph": "M", "pid": pid, "tid": 0, "args": {"name": name}})
        self._write_event(
            {"name": "process_sort_index", "ph": "M", "pid": pid, "tid": 0, "args": {"sort_index": sort_index}}
        )

    def _write_span(self, name: str, ts_ns: int, dur_ns: int, metadata: dict, *, pid: int | None = None) -> None:
        """Write a completed span in Chrome Trace Format."""
        with self._write_lock:
            if self._flushed:
                return
            if pid is None:
                # pid = agent_id for agents, PID_ENV for env_step and gc
                pid = self.PID_ENV
                if name == "agent_step":
                    agent_id: int = metadata.get("agent", 0)
                    pid = agent_id
                    if pid not in self._known_pids:
                        self._known_pids.add(pid)
                        self._write_process_name(pid, "Agent", sort_index=agent_id)

            self._write_event(
                {
                    "name": name,
                    "ph": "X",  # Complete event
                    "ts": ts_ns // 1000,  # Chrome Trace uses microseconds
                    "dur": dur_ns // 1000,
                    "pid": pid,
                    "tid": 0,
                    "args": metadata,
                }
            )

    def flush(self) -> None:
        """Close the JSON array and ensure everything is written to disk.

        Safe to call multiple times; only the first call has effect.
        """
        with self._write_lock:
            if self._flushed:
                return
            self._flushed = True
            if self._gc_callback in gc.callbacks:
                gc.callbacks.remove(self._gc_callback)
            self._file.write("]\n")
            self._file.close()

    def __del__(self) -> None:
        """Ensure cleanup if flush() was never called."""
        self.flush()


class NullTracer(Tracer):
    """No-op tracer for when tracing is disabled."""

    def __init__(self):
        pass

    def span(self, name: str, pid: int | None = None, **metadata) -> Span:
        return _NULL_SPAN

    def record_span(self, name: str, start_ns: int, duration_ns: int, pid: int | None = None, **metadata) -> None:
        pass

    def _write_span(self, name: str, ts_ns: int, dur_ns: int, metadata: dict, *, pid: int | None = None) -> None:
        pass

    def flush(self) -> None:
        pass
