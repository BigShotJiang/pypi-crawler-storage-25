from mettagrid.mapgen.area import AreaWhere
from mettagrid.mapgen.scene import ChildrenAction, Scene, SceneConfig
from mettagrid.mapgen.scenes.random import Random
from mettagrid.mapgen.scenes.room_grid import RoomGrid


class MultiLeftAndRightConfig(SceneConfig):
    rows: int
    columns: int
    hub_ratio: float
    total_hubs: int


class MultiLeftAndRight(Scene[MultiLeftAndRightConfig]):
    """
    Produce multiple left-or-right maps in a grid, with agents assigned randomly
    to teams, and rooms all identical otherwise. hubs are placed asymmetrically
    with configurable total count and ratio between sides. The side with more hubs
    is randomly determined at the start of each episode.
    """

    def get_children(self):
        # Pregenerate seeds so that we could make rooms deterministic.
        agent_seed = int(self.rng.integers(0, int(1e9)))
        hub_seed = int(self.rng.integers(0, int(1e9)))

        # Calculate hub counts based on ratio
        more_hubs = int(self.config.total_hubs * self.config.hub_ratio)
        less_hubs = self.config.total_hubs - more_hubs

        # Randomly determine which side gets more hubs
        left_hubs = more_hubs if self.rng.random() < 0.5 else less_hubs
        right_hubs = self.config.total_hubs - left_hubs

        agent_groups = [
            "team_1",
            "team_2",
        ]

        rows = self.config.rows
        columns = self.config.columns

        return [
            ChildrenAction(
                where="full",
                scene=RoomGrid.Config(
                    rows=rows,
                    columns=columns,
                    border_width=6,
                    children=[
                        ChildrenAction(
                            scene=RoomGrid.Config(
                                border_width=0,
                                layout=[
                                    [
                                        "maybe_hubs_left",
                                        "empty",
                                        "empty",
                                        "agents",
                                        "empty",
                                        "empty",
                                        "maybe_hubs_right",
                                    ],
                                ],
                                children=[
                                    ChildrenAction(
                                        scene=Random.Config(
                                            agents={
                                                agent_group: 1,
                                            },
                                            seed=agent_seed,
                                        ),
                                        where=AreaWhere(tags=["agents"]),
                                    ),
                                    ChildrenAction(
                                        scene=Random.Config(
                                            objects={"hub": left_hubs},
                                            seed=hub_seed,
                                        ),
                                        where=AreaWhere(tags=["maybe_hubs_left"]),
                                    ),
                                    ChildrenAction(
                                        scene=Random.Config(
                                            objects={"hub": right_hubs},
                                            seed=hub_seed + 1,
                                        ),
                                        where=AreaWhere(tags=["maybe_hubs_right"]),
                                    ),
                                ],
                            ),
                            lock="rooms",
                            limit=rows * columns // len(agent_groups),
                        )
                        for agent_group in agent_groups
                    ],
                ),
            ),
        ]

    def render(self):
        pass
