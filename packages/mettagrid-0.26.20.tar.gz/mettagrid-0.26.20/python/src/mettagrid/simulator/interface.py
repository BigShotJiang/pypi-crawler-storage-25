from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, NamedTuple, Sequence

from mettagrid.config.id_map import ObservationFeatureSpec
from mettagrid.mettagrid_c import PackedCoordinate

if TYPE_CHECKING:
    from mettagrid.simulator.simulator import Simulation


class Location(NamedTuple):
    row: int
    col: int

    @property
    def x(self) -> int:
        return self.col

    @property
    def y(self) -> int:
        return self.row


@dataclass
class ObservationToken:
    feature: ObservationFeatureSpec
    value: int
    raw_token: tuple[int, int, int]

    @property
    def is_global(self) -> bool:
        """Check if this token is a global observation (non-spatial, agent-wide state).

        Global tokens use a dedicated location marker (0xFE) distinct from spatial coordinates.
        """
        return PackedCoordinate.is_global(self.raw_token[0])

    @property
    def location(self) -> Location | None:
        """Get the spatial location of this token, or None for global/empty tokens.

        PackedCoordinate.unpack returns None for 0xFF (empty) and 0xFE (global).
        """
        unpacked = PackedCoordinate.unpack(self.raw_token[0])
        if unpacked is None:
            return None
        return Location(*unpacked)

    def row(self) -> int | None:
        loc = self.location
        return loc.row if loc else None

    def col(self) -> int | None:
        loc = self.location
        return loc.col if loc else None


@dataclass(frozen=True)
class VisibleTalk:
    agent_id: int
    text: str
    location: Location
    remaining_steps: int


@dataclass
class AgentObservation:
    agent_id: int
    tokens: Sequence[ObservationToken]
    talk: Sequence[VisibleTalk] = ()


class SimulatorEventHandler:
    """Handler for Simulator events."""

    def __init__(self):
        self._sim: Simulation

    def set_simulation(self, simulation: Simulation) -> None:
        self._sim = simulation

    def on_episode_start(self) -> None:
        pass

    def on_episode_end(self) -> None:
        pass

    def on_step(self) -> None:
        pass

    def on_close(self) -> None:
        pass
