"""Action configuration classes for MettaGrid.

This module defines all action-related configurations including movement,
attacks, transfers, and vibe changes.

Framework vs. behavior: these schemas describe what a game *could* configure,
not the active behavior of any specific game. Whether a given field is
populated for a particular mission is determined by that game's variant
chain. Reading these schemas tells you mettagrid's capability surface; for
a game's actual behavior, consult the game package (e.g. ``cogsguard``) and
the mission's required variants.
"""

from __future__ import annotations

from abc import abstractmethod
from itertools import chain
from typing import Any, Literal, get_args

from pydantic import Field

from mettagrid.base_config import Config
from mettagrid.config.vibes import VIBES, Vibe
from mettagrid.types import Action

# ===== Action Name Prefixes =====

CHANGE_VIBE_PREFIX = "change_vibe_"

# ===== Direction Types =====

Direction = Literal["north", "south", "east", "west", "northeast", "northwest", "southeast", "southwest"]
Directions = list(get_args(Direction))

# Order must match C++ expectations: north, south, west, east
CardinalDirection = Literal["north", "south", "west", "east"]
CardinalDirections = list(get_args(CardinalDirection))


# ===== Action Configuration Classes =====


class ActionConfig(Config):
    """Python action configuration."""

    action_handler: str
    enabled: bool = Field(default=True)
    # required_resources defaults to consumed_resources. Otherwise, should be a superset of consumed_resources.
    required_resources: dict[str, int] = Field(default_factory=dict)
    consumed_resources: dict[str, int] = Field(default_factory=dict)

    def actions(self) -> list[Action]:
        if self.enabled:
            return self._actions()
        return []

    @abstractmethod
    def _actions(self) -> list[Action]: ...


class NoopActionConfig(ActionConfig):
    """Noop action configuration."""

    action_handler: str = Field(default="noop")

    def _actions(self) -> list[Action]:
        return [self.Noop()]

    def Noop(self) -> Action:
        return Action(name="noop")


class MoveActionConfig(ActionConfig):
    """Move action configuration.

    When handlers is non-empty, the move handler chain uses these handlers instead
    of the default (relocate-to-empty, on-use) chain.
    """

    action_handler: str = Field(default="move")
    allowed_directions: list[Direction] = Field(default_factory=lambda: CardinalDirections)
    handlers: list[Any] = Field(default_factory=list)

    def _actions(self) -> list[Action]:
        return [self.Move(direction) for direction in self.allowed_directions]

    def Move(self, direction: Direction) -> Action:
        return Action(name=f"move_{direction}")


class ChangeVibeActionConfig(ActionConfig):
    """Change vibe action configuration."""

    action_handler: str = Field(default="change_vibe")
    vibes: list[Vibe] = Field(default_factory=lambda: list(VIBES))

    def _actions(self) -> list[Action]:
        return [self.ChangeVibe(vibe) for vibe in self.vibes]

    def ChangeVibe(self, vibe: Vibe) -> Action:
        return Action(name=f"{CHANGE_VIBE_PREFIX}{vibe.name}")


class AttackOutcome(Config):
    """Outcome configuration for successful attack."""

    actor_inv_delta: dict[str, int] = Field(
        default_factory=dict,
        description="Inventory changes for attacker. Maps resource name to delta.",
    )
    target_inv_delta: dict[str, int] = Field(
        default_factory=dict,
        description="Inventory changes for target. Maps resource name to delta.",
    )
    loot: list[str] = Field(
        default_factory=list,
        description="Resources to steal from target.",
    )


class AttackActionConfig(ActionConfig):
    """Python attack action configuration.

    Framework note: this is the schema for the ``attack`` action in mettagrid.
    It is **disabled by default** (``enabled=False`` in ``ActionsConfig``) and
    is opt-in: a game must both enable it and populate ``vibes`` /
    ``vibe_bonus`` for any of the vibe-coupled behavior described below to
    occur. Games that do not enable attack (e.g. Cogs vs Clips
    ``machina_1``) do not exhibit any of the vibe coupling described here -
    in those games vibes are a pure signaling channel with no gameplay
    coupling, and role identity is determined by inventory items rather than
    by the agent's vibe attribute.

    Attack is triggered by moving onto another agent (when vibes match).
    No standalone attack actions are created.

    Enhanced attack system with armor/weapon modifiers:
    - defense_resources: Base resources needed to block an attack
    - armor_resources: Target's resources that reduce incoming damage (weighted)
    - weapon_resources: Attacker's resources that increase damage (weighted)
    - success: Outcome when attack succeeds (actor/target inventory changes)
    - vibe_bonus: Per-vibe armor bonus when vibing a matching resource

    Defense calculation:
    - weapon_power = sum(attacker_inventory[item] * weapon_weight)
    - armor_power = sum(target_inventory[item] * armor_weight) + vibe_bonus[target_vibe] if vibing
    - damage_bonus = max(weapon_power - armor_power, 0)
    - cost_to_defend = defense_resources + damage_bonus
    """

    action_handler: str = Field(default="attack")
    defense_resources: dict[str, int] = Field(default_factory=dict)
    armor_resources: dict[str, int] = Field(
        default_factory=dict,
        description="Resources on target that reduce damage. Maps resource name to weight.",
    )
    weapon_resources: dict[str, int] = Field(
        default_factory=dict,
        description="Resources on attacker that increase damage. Maps resource name to weight.",
    )
    success: AttackOutcome = Field(
        default_factory=AttackOutcome,
        description="Outcome when attack succeeds.",
    )
    vibes: list[str] = Field(
        default_factory=list,
        description=(
            "Optional. Empty by default. Vibe names that trigger attack on move when "
            "AttackActionConfig is enabled. Populated by attack-configuring variants; "
            "no effect when empty (e.g., ['weapon'])."
        ),
    )
    vibe_bonus: dict[str, int] = Field(
        default_factory=dict,
        description=(
            "Optional. Empty by default. Per-vibe armor bonus when AttackActionConfig "
            "is enabled and the target's vibe matches the key. Populated by "
            "attack-configuring variants; no effect when empty."
        ),
    )

    def _actions(self) -> list[Action]:
        # Attack only triggers via move, no standalone actions
        return []


class ActionsConfig(Config):
    """
    Actions configuration.

    Omitted actions are disabled by default.
    """

    noop: NoopActionConfig = Field(default_factory=lambda: NoopActionConfig())
    move: MoveActionConfig = Field(default_factory=lambda: MoveActionConfig())
    attack: AttackActionConfig = Field(default_factory=lambda: AttackActionConfig(enabled=False))
    change_vibe: ChangeVibeActionConfig = Field(default_factory=lambda: ChangeVibeActionConfig())

    def actions(self) -> list[Action]:
        action_configs = (self.noop, self.move, self.attack, self.change_vibe)
        return list(chain.from_iterable(action.actions() for action in action_configs))
