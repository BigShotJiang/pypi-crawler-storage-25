"""Observation configuration.

Feature IDs and names are managed by IdMap.
Changing feature IDs will break models trained on old feature IDs.
"""

from pydantic import ConfigDict, Field

from mettagrid.base_config import Config
from mettagrid.config.game_value import AnyGameValue


class GlobalObsConfig(Config):
    """Global observation configuration."""

    episode_completion_pct: bool = Field(default=True)

    # Controls whether the last_action global token is included
    last_action: bool = Field(default=True)

    # Optional movement result token: 1 if the agent's location changed in the last step, else 0.
    # This can differ from action_success when a move action "uses" an adjacent building successfully.
    last_action_move: bool = Field(default=False)

    last_reward: bool = Field(default=True)

    # Goal tokens that indicate rewarding resources
    goal_obs: bool = Field(default=False)

    # Local position: offset from spawn as directional tokens (lp:east, lp:west, lp:north, lp:south)
    local_position: bool = Field(default=False)

    # Named game values to include as global observations.
    # Keys become the observation feature name prefix.
    obs: dict[str, AnyGameValue] = Field(default_factory=dict)


class ObsConfig(Config):
    """Observation configuration."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    width: int = Field(default=13)
    height: int = Field(default=13)
    token_dim: int = Field(default=3)
    num_tokens: int = Field(default=500)
    token_value_base: int = Field(default=256)
    """Base for multi-token inventory encoding (value per token: 0 to base-1).

    Default 256 for efficient byte packing.
    """
    global_obs: GlobalObsConfig = Field(default_factory=GlobalObsConfig)
    observation_radius_value: AnyGameValue | None = Field(
        default=None,
        description=(
            "Optional per-agent game value used to clamp spatial observation radius each step. "
            "Radius 0 emits only the center tile; larger radii expand symmetrically up to the configured window."
        ),
    )

    # Optional per-tile AOE observability. When enabled, MettaGrid emits `aoe_mask` tokens
    # with collapsed territory semantics:
    # - 1: friendly territory/influence
    # - 2: enemy territory/influence
    # - 0 / no token: neutral or no influence.
    aoe_mask: bool = Field(default=False)

    # Optional sparse territory-control observations: `territory:here` plus directional boundary tokens.
    territory: bool = Field(default=False)
