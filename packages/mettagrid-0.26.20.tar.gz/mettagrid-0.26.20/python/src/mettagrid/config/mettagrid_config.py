from __future__ import annotations

from typing import Annotated, Any, Literal, Optional, Union

from pydantic import (
    ConfigDict,
    Discriminator,
    Field,
    model_validator,
)
from pydantic import (
    Tag as PydanticTag,
)

from mettagrid.base_config import Config
from mettagrid.config.action_config import (  # noqa: F401 - re-exported for backward compat
    ActionConfig,
    ActionsConfig,
    AttackActionConfig,
    AttackOutcome,
    CardinalDirection,
    CardinalDirections,
    ChangeVibeActionConfig,
    Direction,
    Directions,
    MoveActionConfig,
    NoopActionConfig,
)
from mettagrid.config.env_config import EnvConfig
from mettagrid.config.event_config import EventConfig
from mettagrid.config.game_value import (  # noqa: F401 - re-exported
    AnyGameValue,
    ConstValue,
    GameValue,
    InventoryValue,
    MaxGameValue,
    MinGameValue,
    QueryCountValue,
    QueryInventoryValue,
    RatioGameValue,
    Scope,
    StatValue,
    SumGameValue,
)
from mettagrid.config.handler_config import (
    AnyHandler,
    AOEConfig,
    Handler,
)
from mettagrid.config.id_map import IdMap
from mettagrid.config.obs_config import (  # noqa: F401 - re-exported
    GlobalObsConfig,
    ObsConfig,
)
from mettagrid.config.query import MaterializedQuery
from mettagrid.config.render_config import (  # noqa: F401 - unused here, re-exported for downstream consumers
    RenderConfig,
    RenderHudConfig,
    RenderStatusBarConfig,
)
from mettagrid.config.reward_config import AgentReward
from mettagrid.config.territory_config import TerritoryConfig, TerritoryControlConfig
from mettagrid.map_builder.ascii import AsciiMapBuilder
from mettagrid.map_builder.map_builder import AnyMapBuilderConfig
from mettagrid.map_builder.random_map import RandomMapBuilder

# ===== Python Configuration Models =====


class ResourceLimitsConfig(Config):
    """Resource limits configuration.

    Supports dynamic limits via modifiers. The effective limit is:
    min(max, max(base, sum(modifier_bonus * quantity_held)))

    Example:
        ResourceLimitsConfig(
            resources=["battery"],
            base=0,  # base capacity is 0
            max=100,  # cap at 100 even with modifiers
            modifiers={"gear": 10}  # each gear adds +10 battery capacity
        )
    """

    # Require base, since it's easy to forget to set it.
    base: int = Field(description="Base capacity (floor for effective limit, before modifiers)")
    max: int = Field(default=65535, description="Maximum limit (cap for effective limit)")
    resources: list[str]
    modifiers: dict[str, int] = Field(
        default_factory=dict,
        description="Modifiers that increase the limit. Maps item name to bonus per item held.",
    )


class InventoryConfig(Config):
    """Inventory configuration for agents and chests."""

    default_limit: int = Field(default=65535, ge=0, description="Default resource limit")
    limits: dict[str, ResourceLimitsConfig] = Field(
        default_factory=dict,
        description="Resource-specific limits",
    )
    initial: dict[str, int] = Field(default_factory=dict, description="Initial inventory")

    def get_limit(self, resource_name: str) -> int:
        """Get the base resource limit for a given resource name (without modifiers)."""
        for limit_config in self.limits.values():
            if resource_name in limit_config.resources:
                return limit_config.base
        return self.default_limit


class GridObjectConfig(Config):
    """Base configuration for all grid objects.

    Python uses only names. Numeric type_ids are an internal C++ detail and are
    computed during Python→C++ conversion; they are never part of Python config
    or observations.

    Handlers:
      - on_use_handler: Triggered when agent uses/activates this object
      - aoes: Area of effect configurations for objects that emit effects
    """

    # Discriminator for AnyGridObjectConfig union. "object" = full GridObject with
    # inventory/handlers; "wall" = minimal Wall.  Must be overridden by WallConfig.
    pydantic_type: Literal["object"] = "object"

    name: str = Field(description="Canonical type_name (human-readable)")
    map_name: str = Field(default="", description="Stable key used by maps to select this config")
    tags: list[str] = Field(default_factory=list, description="Tags for this object instance")
    vibe: int = Field(default=0, ge=0, le=255, description="Vibe value for this object instance")
    aoes: dict[str, AOEConfig] = Field(
        default_factory=dict,
        description="Named AOE configs this object emits to targets within range (name -> config)",
    )
    territory_controls: list[TerritoryControlConfig] = Field(
        default_factory=list,
        description="Territory influence controls this object emits (references game.territories keys)",
    )
    inventory: InventoryConfig = Field(default_factory=InventoryConfig)

    blocks_vision: bool = Field(
        default=False,
        description="Whether this object blocks line of sight for observations",
    )

    # Handlers - dict[name, Handler] for backwards compatibility
    handlers: dict[str, Handler] = Field(
        default_factory=dict,
        description="Handlers triggered when an agent moves onto this object (name -> handler)",
    )

    on_use_handler: AnyHandler | None = Field(
        default=None,
        description="Handler triggered when agent uses/activates this object.",
    )
    on_tag_remove: dict[str, Handler] = Field(
        default_factory=dict,
        description="Handlers triggered when a matching tag is removed from this object (tag_prefix -> handler)",
    )

    @model_validator(mode="after")
    def _defaults_from_name(self) -> "GridObjectConfig":
        if not self.map_name:
            self.map_name = self.name
        return self


class WallConfig(GridObjectConfig):
    """Python wall/block configuration."""

    # This is used to discriminate between different GridObjectConfig subclasses in Pydantic.
    # See AnyGridObjectConfig.
    # Please don't use this for anything game related.
    pydantic_type: Literal["wall"] = "wall"
    name: str = Field(default="wall")


class AgentConfig(GridObjectConfig):
    """Python agent configuration.

    Inherits from GridObjectConfig to share tags, vibe, inventory, and handler fields.
    """

    name: str = Field(default="agent")
    team_id: int = Field(default=0, ge=0, description="Team ID for grouping agents")
    rewards: dict[str, AgentReward] = Field(default_factory=dict)
    initial_stats: dict[str, float] = Field(
        default_factory=dict,
        description="Private agent stats seeded before the first observation.",
    )
    on_tick: AnyHandler | None = Field(
        default=None,
        description="Handler run every tick with actor=target=this agent",
    )
    on_after_use_handler: AnyHandler | None = Field(
        default=None,
        description="Handler fired after agent successfully uses a target (actor=agent, target=object).",
    )

    @model_validator(mode="after")
    def _reject_blocks_vision(self) -> "AgentConfig":
        if self.blocks_vision:
            raise ValueError(
                "AgentConfig.blocks_vision=True is not supported: agents do not block vision. "
                "Set blocks_vision on object types like WallConfig instead."
            )
        return self


class TalkConfig(Config):
    enabled: bool = Field(default=False, description="Whether talk mode is enabled for the game.")
    max_length: int = Field(default=140, ge=1, description="Maximum number of characters allowed in a talk message.")
    cooldown_steps: int = Field(default=50, ge=0, description="Minimum resend gap in steps. Zero disables cooldown.")
    broadcast_resource: str | None = Field(
        default=None,
        description="Optional resource name that enables full broadcast among agents currently holding it.",
    )


# Note: GridObjectConfig is included to allow direct use of the base class for simple objects
# that only need handlers/aoes without specialized features like protocols or inventory.
# Discriminated on `pydantic_type`: "wall" → WallConfig, "object" → GridObjectConfig.
# Uses a custom discriminator to default to "object" for legacy configs missing the field.


def _grid_object_discriminator(v: Any) -> str:
    if isinstance(v, dict):
        return v.get("pydantic_type", "object")
    return getattr(v, "pydantic_type", "object")


AnyGridObjectConfig = Annotated[
    Union[
        Annotated[WallConfig, PydanticTag("wall")],
        Annotated[GridObjectConfig, PydanticTag("object")],
    ],
    Discriminator(_grid_object_discriminator),
]


class GameConfig(Config):
    """Python game configuration.

    Note: Type IDs are automatically assigned during validation when the GameConfig
    is constructed. If you need to add objects after construction, create a new
    GameConfig instance rather than modifying the objects dict post-construction.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    resource_names: list[str] = Field(
        default=[
            "ore_red",
            "ore_blue",
            "ore_green",
            "battery_red",
            "battery_blue",
            "battery_green",
            "heart",
            "armor",
            "laser",
            "blueprint",
        ]
    )

    def add_resource(self, name: str) -> None:
        assert name not in self.resource_names, f"Resource '{name}' already registered"
        self.resource_names.append(name)

    vibe_names: list[str] = Field(default_factory=list)
    num_agents: int = Field(ge=1, default=24)
    # max_steps = zero means "no limit"
    max_steps: int = Field(ge=0, default=10000)
    # default is that we terminate / use "done" vs truncation
    episode_truncates: bool = Field(default=False)
    obs: ObsConfig = Field(default_factory=ObsConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    agents: list[AgentConfig] = Field(default_factory=list)
    actions: ActionsConfig = Field(default_factory=lambda: ActionsConfig())
    objects: dict[str, AnyGridObjectConfig] = Field(default_factory=dict)
    # these are not used in the C++ code, but we allow them to be set for other uses.
    # E.g., templates can use params as a place  where values are expected to be written,
    # and other parts of the template can read from there.
    params: Optional[Any] = None

    # Territories - game-level territory type definitions
    territories: dict[str, TerritoryConfig] = Field(
        default_factory=dict,
        description="Territory types with tag_prefix and handlers (name -> config)",
    )
    # Events - timestep-triggered effects that apply mutations to filtered objects
    events: dict[str, EventConfig] = Field(
        default_factory=dict,
        description="Events that fire at specific timesteps, applying mutations to filtered objects.",
    )

    render: RenderConfig = Field(default_factory=RenderConfig, description="MettaScope rendering hints")

    # Map builder configuration - accepts any MapBuilder config
    map_builder: AnyMapBuilderConfig = Field(default_factory=lambda: RandomMapBuilder.Config(agents=24))

    protocol_details_obs: bool = Field(
        default=True, description="Objects show their protocol inputs and outputs when observed"
    )

    reward_estimates: Optional[dict[str, float]] = Field(default=None)
    talk: TalkConfig = Field(default_factory=TalkConfig, description="Optional talk-mode configuration.")

    # Explicit list of tags used in the game. All tag references in filters/mutations
    # must refer to one of these, or obj.tags, or the implicit type:object_type tag.
    tags: list[str] = Field(
        default_factory=list,
        description="Explicit tag names used in the game (beyond object/agent tags and auto-generated type tags)",
    )

    materialize_queries: list[MaterializedQuery] = Field(
        default_factory=list,
        description="Queries whose results are materialized as tags, recomputed via RecomputeMaterializedQueryMutation",
    )

    on_tick: AnyHandler | None = Field(
        default=None,
        description="Handler run every tick at game level (actor=target=nullptr).",
    )
    end_episode_on_game_stats: dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Optional game-stat thresholds that force episode end when met. "
            "Format: {stat_name: min_value}. Handled in Python simulator event handlers."
        ),
    )

    @model_validator(mode="after")
    def _compute_feature_ids(self) -> "GameConfig":
        self.vibe_names = [vibe.name for vibe in self.actions.change_vibe.vibes]
        self._validate_territory_controls()
        return self

    def _validate_territory_controls(self) -> None:
        territory_keys = set(self.territories.keys())
        all_configs: list[tuple[str, list]] = []
        for obj_name, obj_cfg in self.objects.items():
            if hasattr(obj_cfg, "territory_controls") and obj_cfg.territory_controls:
                all_configs.append((f"objects.{obj_name}", obj_cfg.territory_controls))
        if self.agent.territory_controls:
            all_configs.append(("agent", self.agent.territory_controls))
        for i, agent_cfg in enumerate(self.agents):
            if agent_cfg.territory_controls:
                all_configs.append((f"agents[{i}]", agent_cfg.territory_controls))
        for source, controls in all_configs:
            for tc in controls:
                assert tc.territory in territory_keys, (
                    f"{source} territory_control references unknown territory '{tc.territory}'. "
                    f"Available: {sorted(territory_keys)}"
                )

    def id_map(self) -> "IdMap":
        """Get the observation feature ID map for this configuration."""
        return IdMap(self)


class MettaGridConfig(EnvConfig):
    """Environment configuration."""

    game_engine: Literal["mettagrid"] = "mettagrid"
    label: str = Field(default="mettagrid")
    game: GameConfig = Field(default_factory=GameConfig)
    desync_episodes: bool = Field(default=True)

    @property
    def num_agents(self) -> int:
        return self.game.num_agents

    @staticmethod
    def set_map_seed(config: dict[str, Any], seed: int) -> None:
        map_builder = config["game"]["map_builder"]
        if "seed" not in map_builder:
            raise KeyError("env_config.game.map_builder.seed is required")
        map_builder["seed"] = seed

    @staticmethod
    def set_max_steps(config: dict[str, Any], max_steps: int) -> None:
        config["game"]["max_steps"] = max_steps

    @staticmethod
    def get_max_steps(config: dict[str, Any]) -> int:
        return config["game"]["max_steps"]

    @staticmethod
    def get_num_agents(config: dict[str, Any]) -> int:
        return config["game"]["num_agents"]

    def with_ascii_map(self, map_data: list[list[str]], char_to_map_name: dict[str, str]) -> "MettaGridConfig":
        self.game.map_builder = AsciiMapBuilder.Config(
            map_data=map_data,
            char_to_map_name=char_to_map_name,
        )
        return self

    @staticmethod
    def EmptyRoom(
        num_agents: int, width: int = 10, height: int = 10, border_width: int = 1, with_walls: bool = False
    ) -> "MettaGridConfig":
        """Create an empty room environment configuration."""
        map_builder = RandomMapBuilder.Config(agents=num_agents, width=width, height=height, border_width=border_width)
        actions = ActionsConfig(move=MoveActionConfig(), change_vibe=ChangeVibeActionConfig())
        objects = {}
        render = RenderConfig()
        if border_width > 0 or with_walls:
            objects["wall"] = WallConfig()
            render.symbols["wall"] = "⬛"
        return MettaGridConfig(
            game=GameConfig(
                map_builder=map_builder,
                actions=actions,
                num_agents=num_agents,
                objects=objects,
                render=render,
            )
        )


_rebuild_ns = {
    "AnyGameValue": AnyGameValue,
    "GameValue": GameValue,
    "InventoryValue": InventoryValue,
    "StatValue": StatValue,
    "ConstValue": ConstValue,
    "QueryInventoryValue": QueryInventoryValue,
    "QueryCountValue": QueryCountValue,
    "SumGameValue": SumGameValue,
    "RatioGameValue": RatioGameValue,
    "MaxGameValue": MaxGameValue,
    "MinGameValue": MinGameValue,
}
AgentConfig.model_rebuild(_types_namespace=_rebuild_ns)
GameConfig.model_rebuild(_types_namespace=_rebuild_ns)
MettaGridConfig.model_rebuild(_types_namespace=_rebuild_ns)
