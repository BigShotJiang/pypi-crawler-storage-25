from __future__ import annotations

from enum import StrEnum
from typing import Any, NoReturn, Self, Union, get_args, get_origin

from pydantic import BaseModel, ConfigDict, GetCoreSchemaHandler, TypeAdapter, ValidationInfo, model_validator
from pydantic_core import core_schema as cs

LENIENT_CONTEXT: dict[str, bool] = {"lenient": True}


class ConfigStrEnum(StrEnum):
    """StrEnum that serializes as a plain string in Pydantic models.

    Avoids PydanticSerializationUnexpectedValue warnings from wrap-mode
    serializers by providing an explicit serialization schema.
    """

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: type, handler: GetCoreSchemaHandler):
        schema = handler(source_type)
        schema["serialization"] = cs.plain_serializer_function_ser_schema(
            lambda v: v.value,
            info_arg=False,
            return_schema=cs.str_schema(),
        )
        return schema


# Please don't move this class to mettagrid.config, it would cause circular import issues that are difficult to avoid.
class Config(BaseModel):
    """
    Common extension of Pydantic's BaseModel that:
    - rejects extra fields by default (catches typos at config authoring time)
    - allows extra fields when validated with context=LENIENT_CONTEXT (for cross-version deserialization)
    - adds `override` and `update` methods for overriding values based on `path.to.value` keys
    """

    model_config = ConfigDict(extra="forbid")

    @model_validator(mode="before")
    @classmethod
    def _strip_extra_fields_if_lenient(cls, data: Any, info: ValidationInfo) -> Any:
        if not isinstance(data, dict):
            return data
        if isinstance(info.context, dict) and info.context.get("lenient"):
            return {k: v for k, v in data.items() if k in cls.model_fields}
        return data

    def _auto_initialize_field(self, parent_obj: Config, field_name: str) -> Config | None:
        """Auto-initialize a None Config field if possible."""
        field = type(parent_obj).model_fields.get(field_name)
        if not field:
            return None

        field_type = self._unwrap_optional(field.annotation)
        if not (isinstance(field_type, type) and issubclass(field_type, Config)):
            return None

        try:
            new_instance = field_type()
            setattr(parent_obj, field_name, new_instance)
            return new_instance
        except (TypeError, ValueError):
            return None

    def _dict_value_type(self, parent_obj: Config, field_name: str) -> type[Config] | None:
        """Return the Config subtype stored in a dict field, if there is one."""
        field = type(parent_obj).model_fields.get(field_name)
        if not field:
            return None

        field_type = self._unwrap_optional(field.annotation)
        if get_origin(field_type) is not dict:
            return None

        _, value_type = get_args(field_type)
        value_type = self._unwrap_optional(value_type)
        return value_type if isinstance(value_type, type) and issubclass(value_type, Config) else None

    def _auto_initialize_dict_entry(
        self, parent_dict: dict[str, Any], value_type: type[Config] | None, key: str
    ) -> Config | None:
        """Auto-initialize a missing dict entry when the dict stores Config values."""
        if value_type is None:
            return None

        default_for_key = getattr(value_type, "default_for_key", None)
        new_value = default_for_key(key) if default_for_key else value_type()
        parent_dict[key] = new_value
        return new_value

    def _unwrap_optional(self, field_type):
        """Unwrap Optional[T] → T if applicable, else return original type."""
        if get_origin(field_type) is Union:
            non_none_types = [arg for arg in get_args(field_type) if arg is not type(None)]
            return non_none_types[0] if len(non_none_types) == 1 else field_type
        return field_type

    def override(self, key: str, value: Any) -> Self:
        """Override a value in the config.

        Supports dictionary keys with dots by checking if the remaining path (including dots)
        exists as a single key in the dict before splitting further.
        """
        key_path = key.split(".")

        def fail(error: str) -> NoReturn:
            raise ValueError(
                f"Override failed. Full config:\n {self.model_dump_json(indent=2)}\nOverride {key} failed: {error}"
            )

        inner_cfg: Config | dict[str, Any] = self
        dict_value_type: type[Config] | None = None
        traversed_path: list[str] = []
        i = 0
        while i < len(key_path) - 1:
            key_part = key_path[i]

            if isinstance(inner_cfg, dict):
                # Check if the key_part exists in the dict
                if key_part in inner_cfg:
                    inner_cfg = inner_cfg[key_part]
                    dict_value_type = None
                    traversed_path.append(key_part)
                    i += 1
                    continue

                # If key_part doesn't exist, check if remaining path (with dots) exists as a single key
                # This handles cases like stats["carbon.gained"] where the key contains dots
                remaining_path = ".".join(key_path[i:])
                if remaining_path in inner_cfg:
                    # We found the full path as a single key - set it directly
                    inner_cfg[remaining_path] = value
                    return self

                next_inner_cfg = self._auto_initialize_dict_entry(inner_cfg, dict_value_type, key_part)
                if next_inner_cfg is not None:
                    inner_cfg = next_inner_cfg
                    dict_value_type = None
                    traversed_path.append(key_part)
                    i += 1
                    continue

                # If we're at the last part before the final key, allow creating new dict keys
                # This allows creating new keys like stats["silicon.gained"]
                if i == len(key_path) - 2:
                    # We're about to set the final key, so create it with the remaining path
                    inner_cfg[remaining_path] = value
                    return self

                # Otherwise, this is an error (can't traverse further)
                fail(f"key {key} not found in dict at path {'.'.join(traversed_path)}")

            if not hasattr(inner_cfg, key_part):
                failed_path = ".".join(traversed_path + [key_part])
                fail(f"key {failed_path} not found")

            next_inner_cfg = getattr(inner_cfg, key_part)
            if next_inner_cfg is None:
                # Auto-initialize None Config fields
                next_inner_cfg = self._auto_initialize_field(inner_cfg, key_part)
                if next_inner_cfg is None:
                    failed_path = ".".join(traversed_path + [key_part])
                    fail(f"Cannot auto-initialize None field {failed_path}")

            if not isinstance(next_inner_cfg, (Config, dict)):
                failed_path = ".".join(traversed_path + [key_part])
                fail(f"key {failed_path} is not a Config object")

            if isinstance(next_inner_cfg, dict):
                dict_value_type = self._dict_value_type(inner_cfg, key_part)
            else:
                dict_value_type = None
            inner_cfg = next_inner_cfg
            traversed_path.append(key_part)
            i += 1

        if isinstance(inner_cfg, dict):
            # Final key - check if it exists, or if the full remaining path (with dots) exists
            final_key = key_path[-1]
            if final_key in inner_cfg:
                inner_cfg[final_key] = value
            else:
                # Check if remaining path (including final key) exists as a single key with dots
                remaining = ".".join(key_path[i:])
                if remaining in inner_cfg:
                    inner_cfg[remaining] = value
                else:
                    # Create new key (allows new dict keys to be added)
                    inner_cfg[final_key] = value
            return self

        cls = type(inner_cfg)
        field = cls.model_fields.get(key_path[-1])
        if field is not None:
            value = TypeAdapter(field.annotation).validate_python(value)
        setattr(inner_cfg, key_path[-1], value)

        return self

    def update(self, updates: dict[str, Any]) -> Self:
        """Applies multiple overrides to the config."""
        for key, value in updates.items():
            self.override(key, value)
        return self


__all__ = ["Config", "ConfigStrEnum", "LENIENT_CONTEXT"]
