from __future__ import annotations

from typing import Sequence

class MettascopeAction:
    action_name: str | bytes
    agent_id: int

class MettascopeResponse:
    should_close: bool
    actions: Sequence[MettascopeAction] | None

def init(data_dir: str, version: str, replay: str, autostart: bool = ...) -> MettascopeResponse: ...
def render(step: int, replay_step: str) -> MettascopeResponse: ...
def render_pending() -> MettascopeResponse: ...

class MettascopeError(Exception): ...
