"""STEP file export tests."""

from __future__ import annotations

import subprocess
import sys
from dataclasses import InitVar, dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Protocol
from unittest.mock import patch

import pytest

from bdbox.actions.export import ExportAction
from bdbox.errors import RunError
from bdbox.runner.harness import ModelHarness
from bdbox.runner.runner import ModelRunner

from .utils import Models

if TYPE_CHECKING:
    from collections.abc import Sequence


pytestmark = pytest.mark.usefixtures("mock_sys_modules")


MAIN_STUB = Models.DIR / "main_stub.py"


class Runner(Protocol):
    def __init__(
        self, model_argv: Sequence[Path | str] | Path | str = ()
    ) -> None: ...


@dataclass
class ExportModelRunner:
    file_format: str
    output_file: Path = field(init=False)
    tmp_path: InitVar[str | Path]
    monkeypatch: pytest.MonkeyPatch

    _FILE_HEADERS: ClassVar[dict] = {
        "step": "ISO-10303-21;",
        "stl": "STL Exported by Open CASCADE Technology [dev.opencascade.org]",
    }

    def __post_init__(self, tmp_path: str | Path) -> None:
        self.output_file = Path(tmp_path) / f"out.{self.file_format}"

    def __call__(
        self,
        filename: str | Path,
        argv: Sequence[Any],
        run_class: type[Runner] = ModelRunner,
    ) -> None:
        kwargs = {}
        if run_class is ModelRunner:
            kwargs["action"] = ExportAction(output=self.output_file)
        args = [filename, *[str(a) for a in argv]]
        self.monkeypatch.setattr(sys, "argv", args)
        run_class(args, **kwargs)()
        assert self.output_file.exists()
        assert self.output_file.read_text(
            encoding="utf-8", errors="ignore"
        ).startswith(self._FILE_HEADERS[self.file_format])


@dataclass
class RunClass:
    cls: type[Runner]
    exc_type: type[Exception] | None = None


@pytest.fixture(
    params=(
        pytest.param(RunClass(ModelHarness), id="harness"),
        pytest.param(RunClass(ModelRunner, RunError), id="runner"),
    )
)
def run_class_info(request: pytest.FixtureRequest) -> RunClass:
    return request.param


@pytest.fixture
def run_class(run_class_info: RunClass) -> type[Runner]:
    return run_class_info.cls


@pytest.fixture(params=(pytest.param("step"), pytest.param("stl")))
def model_runner(
    request: pytest.FixtureRequest,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> ExportModelRunner:
    return ExportModelRunner(
        file_format=request.param, tmp_path=tmp_path, monkeypatch=monkeypatch
    )


@pytest.fixture(
    params=[
        pytest.param(Models.MODEL_EXPORT, id="Model"),
        pytest.param(Models.PARAMS_EXPORT, id="Params"),
    ]
)
def model_with_params(request: pytest.FixtureRequest) -> Path:
    return request.param


@pytest.fixture(
    params=[
        pytest.param(Models.MODEL_EXPORT, id="Model"),
        pytest.param(Models.PARAMS_EXPORT, id="Params"),
        pytest.param(Models.MONO_MODEL, id="mono_model"),
        pytest.param(Models.MONO_PARAMS, id="mono_params"),
        pytest.param(Models.MONO_PLAIN, id="mono_plain"),
        pytest.param(f"{Models.MONO_PARAMS}:P", id="mono_params_class"),
        pytest.param(f"{Models.MONO_MODEL}:MyModel", id="mono_model_class"),
    ]
)
def model(request: pytest.FixtureRequest) -> Path:
    return request.param


def test_model_export(
    run_class: type[Runner], model: Path, model_runner: ExportModelRunner
) -> None:
    model_runner(
        model, ["export", model_runner.output_file], run_class=run_class
    )


def test_export_with_parameters_after(
    run_class: type[Runner],
    model_with_params: Path,
    model_runner: ExportModelRunner,
) -> None:
    model_runner(
        model_with_params,
        ["export", model_runner.output_file, "--size", "20"],
        run_class=run_class,
    )


def test_export_with_parameters_before(
    run_class: type[Runner],
    model_with_params: Path,
    model_runner: ExportModelRunner,
) -> None:
    model_runner(
        model_with_params,
        ["--size", "20", "export", model_runner.output_file],
        run_class=run_class,
    )


def test_export_no_output_arg(
    run_class_info: RunClass,
    model_with_params: Path,
    model_runner: ExportModelRunner,
) -> None:
    with pytest.raises(run_class_info.exc_type or SystemExit):
        model_runner(
            model_with_params,
            ["--size", "20", "export"],
            run_class=run_class_info.cls,
        )


@pytest.mark.parametrize(
    "model_file",
    [
        pytest.param(Models.MODEL_EXPORT, id="Model"),
        pytest.param(Models.PARAMS_EXPORT, id="Params"),
        pytest.param(Models.PLAIN_EXPORT, id="plain"),
    ],
)
def test_main_export(
    model_file: Path, model_runner: ExportModelRunner
) -> None:
    model_runner(MAIN_STUB, ["export", model_file, model_runner.output_file])


def test_main_export_with_parameters(
    model_with_params: Path, model_runner: ExportModelRunner
) -> None:
    model_runner(
        MAIN_STUB,
        [
            "export",
            model_with_params,
            model_runner.output_file,
            "--size",
            "20",
        ],
    )


def test_main_export_no_model(model_runner: ExportModelRunner) -> None:
    with pytest.raises(RunError):
        model_runner(MAIN_STUB, ["export"])


def test_export_all_embedded_execs_harness(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    argv = [
        str(Models.PARAMS_EXPORT),
        "export",
        "-a",
        str(tmp_path),
        "--format",
        "step",
    ]
    monkeypatch.setattr(sys, "argv", argv)
    with (
        patch.object(subprocess, "run") as mock_run,
        pytest.raises(RunError),
    ):
        ModelRunner(
            [
                Models.PARAMS_EXPORT,
                "export",
                "-a",
                str(tmp_path),
                "--format",
                "step",
            ]
        )()
    mock_run.assert_called_once_with([sys.executable, "-m", "bdbox", *argv])


def test_export_single_embedded_does_not_exec_harness(
    tmp_path: Path, model_runner: ExportModelRunner
) -> None:
    with patch.object(subprocess, "run") as mock_run:
        model_runner(
            Models.PARAMS_EXPORT, ["export", model_runner.output_file]
        )
    mock_run.assert_not_called()


@pytest.mark.parametrize(
    ("model_file", "expected_stems"),
    [
        pytest.param(
            Models.PARAMS_EXPORT, ["default", "mid"], id="Params-with-preset"
        ),
        pytest.param(
            Models.MODEL_EXPORT, ["default", "mid"], id="Model-with-preset"
        ),
        pytest.param(Models.PLAIN_EXPORT, ["default"], id="plain-no-presets"),
    ],
)
@pytest.mark.parametrize("file_format", ["step", "stl"])
def test_export_all_creates_preset_files(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    model_file: Path,
    expected_stems: list[str],
    file_format: str,
) -> None:
    out_dir = tmp_path / "renders"
    args = [
        str(model_file),
        "export",
        "-a",
        str(out_dir),
        "--format",
        file_format,
    ]
    monkeypatch.setattr(sys, "argv", args)
    ModelHarness(args)()
    assert out_dir.is_dir()
    assert sorted(p.stem for p in out_dir.iterdir()) == sorted(expected_stems)
    for stem in expected_stems:
        assert (out_dir / f"{stem}.{file_format}").exists()


def test_export_all_creates_output_dir(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    out_dir = tmp_path / "a" / "b" / "renders"
    assert not out_dir.exists()
    args = [
        str(Models.PLAIN_EXPORT),
        "export",
        "-a",
        str(out_dir),
        "--format",
        "step",
    ]
    monkeypatch.setattr(sys, "argv", args)
    ModelHarness(args)()
    monkeypatch.setattr(sys, "argv", args)
    assert out_dir.is_dir()
