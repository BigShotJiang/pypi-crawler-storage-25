POSITIVE_WORDS = [
    "gain", "gains", "surge", "rally", "profit", "growth",
    "strong", "record", "upgrade", "order", "deal",
    "expansion", "beat", "bullish", "jumps", "rises",
    "approves", "wins", "outperform"
]

NEGATIVE_WORDS = [
    "fall", "falls", "drop", "loss", "weak", "decline",
    "downgrade", "probe", "fraud", "penalty", "debt",
    "miss", "default", "bearish", "slips", "crashes",
    "cuts", "concerns", "underperform"
]


def sentiment_score(text: str) -> int:
    text = str(text).lower()
    positive = sum(1 for word in POSITIVE_WORDS if word in text)
    negative = sum(1 for word in NEGATIVE_WORDS if word in text)
    return positive - negative


def sentiment_label(score: int) -> str:
    if score > 0:
        return "Bullish"
    if score < 0:
        return "Bearish"
    return "Neutral"
