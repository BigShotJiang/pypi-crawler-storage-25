"""
Sitemap collector for NDTV Profit.

Walks the site's robots.txt for Sitemap: entries, then recursively expands
sitemap-index files to leaf <url><loc> entries. Falls back to a list of
common sitemap paths if robots.txt has none.

Respects robots.txt for any URL it actually fetches via fetch_public_page.
"""

from datetime import datetime
from urllib.parse import urlparse
import re

import pandas as pd
from bs4 import BeautifulSoup

from .config import BASE_URL, REQUEST_DELAY_SECONDS
from .http_client import create_session
from .robots_checker import can_fetch, ROBOTS_URL


COMMON_SITEMAP_PATHS = [
    "/sitemap.xml",
    "/sitemap_index.xml",
    "/sitemap-index.xml",
    "/news-sitemap.xml",
    "/sitemap-news.xml",
    "/sitemap_news.xml",
    "/google-news-sitemap.xml",
]


def _fetch_xml(url: str):
    """Fetch a URL and parse as XML. Returns BeautifulSoup or None."""
    if not can_fetch(url):
        print(f"Sitemap blocked by robots.txt: {url}")
        return None

    try:
        import time
        time.sleep(REQUEST_DELAY_SECONDS)
        session = create_session()
        session.headers.update({"Accept": "application/xml,text/xml,*/*"})
        response = session.get(url, timeout=20)

        if response.status_code != 200:
            print(f"Sitemap fetch failed {url}, status={response.status_code}")
            return None

        return BeautifulSoup(response.content, "xml")
    except Exception as e:
        print(f"Sitemap error for {url}: {e}")
        return None


def discover_sitemaps_from_robots() -> list:
    """Read robots.txt and return any Sitemap: URLs declared."""
    sitemaps = []
    try:
        session = create_session()
        response = session.get(ROBOTS_URL, timeout=15)
        if response.status_code != 200:
            return sitemaps

        for line in response.text.splitlines():
            match = re.match(r"\s*sitemap\s*:\s*(\S+)", line, re.IGNORECASE)
            if match:
                sitemaps.append(match.group(1).strip())
    except Exception as e:
        print(f"robots.txt read error: {e}")

    return sitemaps


def expand_sitemap(url: str, domain_filter: str = "ndtvprofit.com",
                   max_depth: int = 3, _depth: int = 0) -> list:
    """
    Expand a sitemap URL into leaf article URLs.
    Handles <sitemapindex> by recursing into child <sitemap><loc> entries.

    Domain filter is applied BEFORE fetching child sitemaps so we never
    fetch from an unrelated host without that host's robots policy.
    """
    if _depth > max_depth:
        return []

    if domain_filter and domain_filter not in urlparse(url).netloc:
        print(f"Sitemap skipped (off-domain): {url}")
        return []

    soup = _fetch_xml(url)
    if soup is None:
        return []

    leaf_urls = []

    sitemap_locs = [t.get_text(strip=True) for t in soup.select("sitemap > loc")]
    if sitemap_locs:
        for child in sitemap_locs:
            leaf_urls.extend(expand_sitemap(child, domain_filter, max_depth, _depth + 1))
        return leaf_urls

    for url_tag in soup.find_all("url"):
        loc = url_tag.find("loc")
        if not loc:
            continue
        article_url = loc.get_text(strip=True)
        lastmod = url_tag.find("lastmod")
        leaf_urls.append({
            "url": article_url,
            "lastmod": lastmod.get_text(strip=True) if lastmod else None,
        })

    return leaf_urls


def collect_sitemap_urls(extra_sitemaps: list = None,
                        domain_filter: str = "ndtvprofit.com",
                        max_urls: int = 2000) -> pd.DataFrame:
    """
    Collect article URLs from NDTV Profit sitemaps.

    Returns a DataFrame with columns: source, url, lastmod, fetched_at.
    """
    sitemap_urls = list(extra_sitemaps or [])

    declared = discover_sitemaps_from_robots()
    if declared:
        print(f"Found {len(declared)} sitemap(s) in robots.txt")
        sitemap_urls.extend(declared)
    else:
        print("No sitemaps in robots.txt; trying common paths.")
        sitemap_urls.extend(BASE_URL.rstrip("/") + p for p in COMMON_SITEMAP_PATHS)

    seen_sitemaps = set()
    rows = []

    for sm in sitemap_urls:
        if sm in seen_sitemaps:
            continue
        seen_sitemaps.add(sm)

        entries = expand_sitemap(sm, domain_filter=domain_filter)
        for e in entries:
            url = e["url"]
            if domain_filter and domain_filter not in urlparse(url).netloc:
                continue
            rows.append({
                "source": "ndtv_profit",
                "url": url,
                "lastmod": e["lastmod"],
                "fetched_at": datetime.now().isoformat(),
            })
            if len(rows) >= max_urls:
                break
        if len(rows) >= max_urls:
            break

    df = pd.DataFrame(rows).drop_duplicates(subset=["url"])
    print(f"Sitemap collected {len(df)} URLs from {len(seen_sitemaps)} sitemap(s).")
    return df
