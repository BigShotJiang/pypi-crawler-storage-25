from urllib.parse import urljoin, urlparse
import pandas as pd
from datetime import datetime

from .config import CATEGORY_URLS, BASE_URL
from .html_collector import fetch_public_page


def is_valid_article_url(url: str) -> bool:
    if not url:
        return False

    parsed = urlparse(url)

    if "ndtvprofit.com" not in parsed.netloc:
        return False

    blocked_patterns = [
        "/login",
        "/signup",
        "/subscription",
        "/account",
        "/privacy",
        "/terms",
        "javascript:",
        "#",
        "facebook.com",
        "twitter.com",
        "linkedin.com",
    ]

    return not any(pattern in url.lower() for pattern in blocked_patterns)


def collect_category_article_urls(limit_per_category: int = 50) -> pd.DataFrame:
    rows = []

    for category, category_url in CATEGORY_URLS.items():
        soup = fetch_public_page(category_url)

        if soup is None:
            continue

        links = soup.find_all("a", href=True)
        seen = set()

        for link in links:
            href = link.get("href")
            url = urljoin(BASE_URL, href)

            if not is_valid_article_url(url):
                continue

            if url in seen:
                continue

            text = link.get_text(strip=True)

            if len(text) < 15:
                continue

            rows.append({
                "source": "ndtv_profit",
                "category": category,
                "title_hint": text,
                "url": url,
                "fetched_at": datetime.now().isoformat(),
            })

            seen.add(url)

            if len(seen) >= limit_per_category:
                break

    return pd.DataFrame(rows).drop_duplicates(subset=["url"])
