import os
import sqlite3
from datetime import datetime
import pandas as pd


def save_dataframe_csv(df: pd.DataFrame, folder: str, name: str) -> str:
    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"{folder}/{name}_{timestamp}.csv"

    df.to_csv(path, index=False)
    return path


def save_to_sqlite(df: pd.DataFrame, db_path="data/ndtv_profit.db", table="news_clean"):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    df_to_save = df.copy()
    for col in df_to_save.columns:
        if df_to_save[col].apply(lambda v: isinstance(v, (list, dict, set, tuple))).any():
            df_to_save[col] = df_to_save[col].apply(
                lambda v: ",".join(map(str, v)) if isinstance(v, (list, set, tuple)) else str(v)
            )

    conn = sqlite3.connect(db_path)
    df_to_save.to_sql(table, conn, if_exists="append", index=False)
    conn.close()
