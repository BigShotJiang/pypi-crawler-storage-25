from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

ROBOTS_URL = "https://www.ndtvprofit.com/robots.txt"

_robots_cache: dict = {}


def _robots_url_for(target_url: str) -> str:
    parsed = urlparse(target_url)
    if not parsed.scheme or not parsed.netloc:
        return ROBOTS_URL
    return f"{parsed.scheme}://{parsed.netloc}/robots.txt"


def _get_parser(robots_url: str):
    if robots_url in _robots_cache:
        return _robots_cache[robots_url]
    rp = RobotFileParser()
    rp.set_url(robots_url)
    try:
        rp.read()
    except Exception:
        rp = None
    _robots_cache[robots_url] = rp
    return rp


def can_fetch(url: str, user_agent: str = "*") -> bool:
    """
    Check robots.txt for the URL's *own* host (not a hard-coded one).
    Returns False on any error so we fail safe.
    """
    try:
        rp = _get_parser(_robots_url_for(url))
        if rp is None:
            return False
        return rp.can_fetch(user_agent, url)
    except Exception:
        return False
