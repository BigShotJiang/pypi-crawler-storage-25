"""
RSS collector for NDTV Profit.

IMPORTANT: NDTV Profit's RSS feed endpoints are NOT publicly confirmed at
the time of writing. The URLs in CANDIDATE_FEEDS below are *guesses* based
on common patterns used by Indian news sites (and the legacy NDTV group).

Each candidate is probed: if it returns 200 with valid RSS/Atom XML, it's
used; otherwise it's logged and skipped. The collector NEVER bypasses
401/403/404 — it just moves on.

If you confirm a working feed URL, add it to CONFIRMED_FEEDS in config or
pass it via the `extra_feeds` argument.
"""

from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
from dateutil import parser as date_parser

from .config import REQUEST_DELAY_SECONDS
from .http_client import create_session
from .robots_checker import can_fetch


CANDIDATE_FEEDS = [
    "https://www.ndtvprofit.com/feed",
    "https://www.ndtvprofit.com/rss",
    "https://www.ndtvprofit.com/rss.xml",
    "https://www.ndtvprofit.com/feeds/latest",
    "https://www.ndtvprofit.com/markets/feed",
    "https://www.ndtvprofit.com/business/feed",
    "https://www.ndtvprofit.com/economy/feed",
    "https://feeds.feedburner.com/NdtvProfit-LatestNews",
]

CONFIRMED_FEEDS: list = [
]


def _looks_like_feed(text: str) -> bool:
    if not text:
        return False
    head = text[:2000].lower()
    return ("<rss" in head) or ("<feed" in head and "atom" in head) or ("<channel" in head)


def probe_feed(url: str) -> bool:
    """Return True if the URL responds 200 and looks like RSS/Atom."""
    if not can_fetch(url):
        print(f"RSS blocked by robots.txt: {url}")
        return False

    try:
        import time
        time.sleep(REQUEST_DELAY_SECONDS)
        session = create_session()
        session.headers.update({
            "Accept": "application/rss+xml,application/atom+xml,application/xml,text/xml,*/*",
        })
        response = session.get(url, timeout=15)
        if response.status_code != 200:
            print(f"RSS probe {url}: status={response.status_code}")
            return False
        if not _looks_like_feed(response.text):
            print(f"RSS probe {url}: 200 but not a feed")
            return False
        return True
    except Exception as e:
        print(f"RSS probe error {url}: {e}")
        return False


def confirm_feeds(candidates: list = None) -> list:
    """Probe a list of candidate URLs and return the ones that look like feeds."""
    candidates = list(candidates or (CONFIRMED_FEEDS + CANDIDATE_FEEDS))
    confirmed = []
    for url in candidates:
        if probe_feed(url):
            print(f"RSS confirmed: {url}")
            confirmed.append(url)
    return confirmed


def parse_feed(url: str) -> list:
    """Parse a single RSS/Atom feed and return list of item dicts."""
    if not can_fetch(url):
        return []

    try:
        import time
        time.sleep(REQUEST_DELAY_SECONDS)
        session = create_session()
        session.headers.update({
            "Accept": "application/rss+xml,application/atom+xml,application/xml,text/xml,*/*",
        })
        response = session.get(url, timeout=20)
        if response.status_code != 200 or not _looks_like_feed(response.text):
            return []

        soup = BeautifulSoup(response.content, "xml")
    except Exception as e:
        print(f"RSS parse error {url}: {e}")
        return []

    items = []

    for item in soup.find_all("item"):
        link = item.find("link")
        title = item.find("title")
        desc = item.find("description")
        pub = item.find("pubDate") or item.find("pubdate")
        items.append({
            "feed_url": url,
            "url": link.get_text(strip=True) if link else "",
            "title": title.get_text(strip=True) if title else "",
            "summary": desc.get_text(strip=True) if desc else "",
            "published_at": _safe_date(pub.get_text(strip=True) if pub else None),
        })

    for entry in soup.find_all("entry"):
        link_tag = entry.find("link")
        link = ""
        if link_tag:
            link = link_tag.get("href") or link_tag.get_text(strip=True)
        title = entry.find("title")
        summ = entry.find("summary") or entry.find("content")
        pub = entry.find("updated") or entry.find("published")
        items.append({
            "feed_url": url,
            "url": link,
            "title": title.get_text(strip=True) if title else "",
            "summary": summ.get_text(strip=True) if summ else "",
            "published_at": _safe_date(pub.get_text(strip=True) if pub else None),
        })

    return items


def _safe_date(value):
    if not value:
        return None
    try:
        return date_parser.parse(value).isoformat()
    except Exception:
        return None


def collect_rss_urls(extra_feeds: list = None,
                     auto_probe: bool = True) -> pd.DataFrame:
    """
    Collect items from NDTV Profit RSS feeds.

    Strategy:
      1. Always include CONFIRMED_FEEDS + extra_feeds (no probing needed).
      2. If auto_probe, probe CANDIDATE_FEEDS and add any that respond as feeds.
      3. Parse all confirmed feeds and return a deduped DataFrame.
    """
    feeds = list(CONFIRMED_FEEDS) + list(extra_feeds or [])

    if auto_probe:
        feeds.extend(confirm_feeds(CANDIDATE_FEEDS))

    feeds = list(dict.fromkeys(feeds))

    if not feeds:
        print("No working RSS feeds found. Use sitemap or category collectors instead.")
        return pd.DataFrame(columns=["source", "feed_url", "url", "title",
                                     "summary", "published_at", "fetched_at"])

    rows = []
    fetched_at = datetime.now().isoformat()
    for feed_url in feeds:
        for item in parse_feed(feed_url):
            if not item.get("url"):
                continue
            item["source"] = "ndtv_profit"
            item["fetched_at"] = fetched_at
            rows.append(item)

    df = pd.DataFrame(rows).drop_duplicates(subset=["url"])
    print(f"RSS collected {len(df)} items from {len(feeds)} feed(s).")
    return df
