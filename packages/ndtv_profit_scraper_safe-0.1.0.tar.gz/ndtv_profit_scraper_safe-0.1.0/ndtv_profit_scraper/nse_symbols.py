import os
import re
import io
import csv
from typing import Iterable

import pandas as pd

from .http_client import create_session


NSE_EQUITY_MASTER_URL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
DEFAULT_CACHE_PATH = "data/raw/nse_equity_master.csv"

GENERIC_BLOCKLIST = {
    "THE", "AND", "FOR", "WITH", "FROM", "INTO", "THIS", "THAT", "WILL",
    "HAS", "HAVE", "ARE", "WAS", "WERE", "BUT", "NOT", "ALL", "ANY",
    "CEO", "CFO", "MD", "IPO", "GST", "RBI", "SEBI", "FII", "DII",
    "NSE", "BSE", "USD", "INR", "EUR", "GDP", "EPS", "PAT", "EBITDA",
    "Q1", "Q2", "Q3", "Q4", "FY", "YOY", "QOQ", "PSU",
}


def download_nse_equity_master(cache_path: str = DEFAULT_CACHE_PATH,
                               force_refresh: bool = False) -> pd.DataFrame:
    """
    Download the NSE equity master list (public CSV) and cache it locally.
    Falls back to the cached file if the download fails.
    """
    if os.path.exists(cache_path) and not force_refresh:
        try:
            return pd.read_csv(cache_path)
        except Exception:
            pass

    os.makedirs(os.path.dirname(cache_path), exist_ok=True)

    try:
        session = create_session()
        session.headers.update({
            "Accept": "text/csv,application/csv,*/*",
            "Referer": "https://www.nseindia.com/",
        })
        response = session.get(NSE_EQUITY_MASTER_URL, timeout=30)

        if response.status_code == 200 and response.text.strip():
            df = pd.read_csv(io.StringIO(response.text))
            df.columns = [c.strip() for c in df.columns]
            df.to_csv(cache_path, index=False)
            return df

        print(f"NSE master download failed, status={response.status_code}")
    except Exception as e:
        print(f"NSE master download error: {e}")

    if os.path.exists(cache_path):
        return pd.read_csv(cache_path)

    return pd.DataFrame(columns=["SYMBOL", "NAME OF COMPANY"])


def _company_aliases(name: str) -> list:
    """
    Build searchable aliases from a company name by stripping common suffixes.
    e.g. 'Reliance Industries Limited' -> ['Reliance Industries Limited',
                                           'Reliance Industries']
    """
    if not isinstance(name, str):
        return []

    name = name.strip()
    if not name:
        return []

    aliases = {name}
    suffixes = [
        r"\s+Limited$", r"\s+Ltd\.?$", r"\s+Pvt\.?\s+Ltd\.?$",
        r"\s+Private\s+Limited$", r"\s+Corporation$", r"\s+Corp\.?$",
        r"\s+Industries$", r"\s+Company$", r"\s+Co\.?$",
    ]
    base = name
    for _ in range(3):
        for suffix in suffixes:
            base = re.sub(suffix, "", base, flags=re.IGNORECASE).strip()
        aliases.add(base)

    first_token = base.split()[0] if base.split() else ""
    if len(first_token) >= 4:
        aliases.add(first_token)

    return [a for a in aliases if len(a) >= 3]


def build_symbol_index(master_df: pd.DataFrame) -> dict:
    """
    Build a lowercase-alias -> SYMBOL lookup.
    """
    index = {}
    if master_df.empty:
        return index

    sym_col = "SYMBOL" if "SYMBOL" in master_df.columns else master_df.columns[0]
    name_col = next(
        (c for c in master_df.columns if "NAME" in c.upper()),
        master_df.columns[1] if len(master_df.columns) > 1 else sym_col,
    )

    for _, row in master_df.iterrows():
        symbol = str(row[sym_col]).strip().upper()
        company = str(row[name_col]).strip()

        if not symbol or symbol in GENERIC_BLOCKLIST:
            continue

        index[symbol.lower()] = symbol

        for alias in _company_aliases(company):
            key = alias.lower()
            if key not in index:
                index[key] = symbol

    return index


def find_symbols_in_text(text: str, symbol_index: dict) -> list:
    """
    Return a sorted, de-duplicated list of NSE symbols mentioned in `text`.
    """
    if not text or not symbol_index:
        return []

    text_lower = text.lower()
    tokens = set(re.findall(r"[a-zA-Z][a-zA-Z0-9&]{2,}", text_lower))

    found = set()

    for token in tokens:
        if token in symbol_index:
            found.add(symbol_index[token])

    for alias, symbol in symbol_index.items():
        if " " in alias and alias in text_lower:
            found.add(symbol)

    return sorted(found)


def tag_dataframe_with_symbols(df: pd.DataFrame,
                               text_columns: Iterable[str] = ("title", "summary", "article_text"),
                               cache_path: str = DEFAULT_CACHE_PATH) -> pd.DataFrame:
    """
    Add `nse_symbols` (list) and `nse_symbols_str` (comma-joined) columns to df.
    """
    master = download_nse_equity_master(cache_path=cache_path)
    index = build_symbol_index(master)

    def _row_symbols(row):
        parts = [str(row.get(col, "") or "") for col in text_columns]
        return find_symbols_in_text(" ".join(parts), index)

    df = df.copy()
    df["nse_symbols"] = df.apply(_row_symbols, axis=1)
    df["nse_symbols_str"] = df["nse_symbols"].apply(lambda xs: ",".join(xs))

    return df
