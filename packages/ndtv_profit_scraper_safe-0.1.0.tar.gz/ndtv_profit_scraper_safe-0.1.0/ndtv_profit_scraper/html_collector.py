import time
from bs4 import BeautifulSoup

from .config import REQUEST_DELAY_SECONDS
from .http_client import create_session
from .robots_checker import can_fetch


def fetch_public_page(url: str):
    if not can_fetch(url):
        print(f"Blocked by robots.txt: {url}")
        return None

    try:
        time.sleep(REQUEST_DELAY_SECONDS)
        session = create_session()
        response = session.get(url, timeout=20)

        if response.status_code != 200:
            print(f"Failed {url}, status={response.status_code}")
            return None

        return BeautifulSoup(response.text, "lxml")

    except Exception as e:
        print(f"Request error for {url}: {e}")
        return None
