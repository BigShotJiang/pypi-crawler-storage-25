import hashlib
from dateutil import parser as date_parser


def clean_text(text: str) -> str:
    return " ".join(str(text).replace("\n", " ").split())


def make_news_id(url: str) -> str:
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def extract_title(soup):
    if soup is None:
        return ""

    h1 = soup.find("h1")
    if h1:
        return clean_text(h1.get_text(strip=True))

    title = soup.find("title")
    return clean_text(title.get_text(strip=True)) if title else ""


def extract_meta_description(soup):
    if soup is None:
        return ""

    meta = soup.find("meta", attrs={"name": "description"})
    if meta and meta.get("content"):
        return clean_text(meta["content"])

    og_desc = soup.find("meta", attrs={"property": "og:description"})
    if og_desc and og_desc.get("content"):
        return clean_text(og_desc["content"])

    return ""


def extract_article_text(soup):
    if soup is None:
        return ""

    paragraphs = soup.find_all("p")
    text = " ".join(clean_text(p.get_text(strip=True)) for p in paragraphs)

    return clean_text(text)


def extract_published_date(soup):
    if soup is None:
        return None

    candidates = [
        soup.find("meta", attrs={"property": "article:published_time"}),
        soup.find("meta", attrs={"name": "publish-date"}),
        soup.find("meta", attrs={"name": "pubdate"}),
        soup.find("time"),
    ]

    for item in candidates:
        if item:
            value = item.get("content") or item.get("datetime") or item.get_text(strip=True)
            if value:
                try:
                    return date_parser.parse(value).isoformat()
                except Exception:
                    pass

    return None


def parse_article(url: str, category: str, soup):
    return {
        "news_id": make_news_id(url),
        "source": "ndtv_profit",
        "category": category,
        "title": extract_title(soup),
        "summary": extract_meta_description(soup),
        "article_text": extract_article_text(soup),
        "url": url,
        "published_at": extract_published_date(soup),
    }
