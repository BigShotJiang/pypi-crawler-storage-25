BASE_URL = "https://www.ndtvprofit.com"

CATEGORY_URLS = {
    "home": "https://www.ndtvprofit.com/",
    "markets": "https://www.ndtvprofit.com/markets",
    "stocks": "https://www.ndtvprofit.com/markets/stocks",
    "business": "https://www.ndtvprofit.com/business",
    "economy": "https://www.ndtvprofit.com/economy",
    "companies": "https://www.ndtvprofit.com/business/companies",
    "personal_finance": "https://www.ndtvprofit.com/personal-finance",
    "mutual_funds": "https://www.ndtvprofit.com/mutual-funds",
    "ipo": "https://www.ndtvprofit.com/ipos",
    "videos": "https://www.ndtvprofit.com/videos",
}

HEADERS = {
    "User-Agent": "BharatSwingAIResearchBot/1.0"
}

REQUEST_DELAY_SECONDS = 2
