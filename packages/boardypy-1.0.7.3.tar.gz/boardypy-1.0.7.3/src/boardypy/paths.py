from __future__ import annotations

from pathlib import Path

from platformdirs import user_config_dir, user_data_dir, user_log_dir

APP_NAME = "BoardyPy"
APP_AUTHOR = "BoardyPy"
APP_VERSION = "1.0.7.3"
DEFAULT_UPDATE_FEED_URL = "https://raw.githubusercontent.com/Timon2306/esp8266/main/version.json"


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def package_root() -> Path:
    return Path(__file__).resolve().parent


def resource_path(*parts: str) -> str:
    path = package_root().joinpath("resources", *parts)
    return str(path) if path.is_file() else ""


def user_config_path(filename: str = "config.json") -> Path:
    return _ensure_dir(Path(user_config_dir(APP_NAME, APP_AUTHOR))) / filename


def user_data_path(filename: str) -> Path:
    return _ensure_dir(Path(user_data_dir(APP_NAME, APP_AUTHOR))) / filename


def user_log_path(filename: str) -> Path:
    return _ensure_dir(Path(user_log_dir(APP_NAME, APP_AUTHOR))) / filename
