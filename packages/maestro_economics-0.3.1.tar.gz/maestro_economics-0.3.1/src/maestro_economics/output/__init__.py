"""Output formatters for estimation results."""
