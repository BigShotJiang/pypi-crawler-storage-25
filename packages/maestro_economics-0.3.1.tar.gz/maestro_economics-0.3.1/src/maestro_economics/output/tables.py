"""LaTeX and HTML table generation for regression results."""
from __future__ import annotations
from maestro_economics.core.config import STAR_THRESHOLDS, DECIMAL_PLACES


def format_coef(value: float, pvalue: float) -> str:
    """Format coefficient with significance stars."""
    stars = ""
    for threshold, star in sorted(STAR_THRESHOLDS.items()):
        if pvalue < threshold:
            stars = star
            break
    return f"{value:.{DECIMAL_PLACES['coef']}f}{stars}"


def generate_latex_table(results: list[dict], var_order: list[str] = None,
                         labels: dict[str, str] = None) -> str:
    """Generate publication-ready LaTeX regression table (esttab style)."""
    raise NotImplementedError("LaTeX table generator -- implementation pending")
