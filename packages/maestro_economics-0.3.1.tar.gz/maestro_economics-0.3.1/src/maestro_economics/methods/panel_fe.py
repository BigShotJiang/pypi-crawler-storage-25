"""Panel Fixed Effects estimation."""
from __future__ import annotations
from maestro_economics.registry import register


@register("fe")
class PanelFEEstimator:
    """Entity/time/two-way fixed effects via linearmodels PanelOLS."""
    name = "fe"
    description = "Panel fixed effects (entity, time, two-way) with clustered SE"
    requires = ["linearmodels"]

    def estimate(self, df, y: str, x: list[str], entity: str = None, time: str = None,
                 cluster: str | None = None, **kwargs):
        """Run panel FE estimation. Returns result dict."""
        raise NotImplementedError("Panel FE estimator -- implementation pending")
