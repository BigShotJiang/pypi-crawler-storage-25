"""Difference-in-Differences estimation."""
from __future__ import annotations
from maestro_economics.registry import register


@register("did")
class DiDEstimator:
    """Canonical and staggered DiD (Callaway-Sant'Anna)."""
    name = "did"
    description = "Difference-in-differences with pre-trend testing"
    requires = ["statsmodels"]

    def estimate(self, df, y: str, treatment: str, post: str, **kwargs):
        raise NotImplementedError("DiD estimator -- implementation pending")
