"""OLS estimation with robust standard errors."""
from __future__ import annotations
from maestro_economics.registry import register


@register("ols")
class OLSEstimator:
    """Ordinary Least Squares with HC1/HC3 robust SE."""
    name = "ols"
    description = "OLS regression with heteroskedasticity-robust standard errors"
    requires = ["statsmodels"]

    def estimate(self, df, y: str, x: list[str], cluster: str | None = None, **kwargs):
        """Run OLS estimation. Returns result dict."""
        raise NotImplementedError("OLS estimator -- implementation pending")
