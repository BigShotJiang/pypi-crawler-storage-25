"""Causal Forest / GRF estimation."""
from __future__ import annotations
from maestro_economics.registry import register


@register("causal_forest")
class CausalForestEstimator:
    """CATE estimation via econml CausalForestDML."""
    name = "causal_forest"
    description = "Heterogeneous treatment effect estimation via causal forest"
    requires = ["econml"]

    def estimate(self, df, y: str, treatment: str, x: list[str] = None, **kwargs):
        raise NotImplementedError("Causal forest estimator -- implementation pending")
