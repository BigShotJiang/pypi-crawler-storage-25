"""Instrumental Variables / 2SLS estimation."""
from __future__ import annotations
from maestro_economics.registry import register


@register("iv")
class IV2SLSEstimator:
    """IV/2SLS via linearmodels. Reports first-stage F-stat."""
    name = "iv"
    description = "Instrumental variables / two-stage least squares"
    requires = ["linearmodels"]

    def estimate(self, df, y: str, x: list[str], instruments: list[str] = None, **kwargs):
        raise NotImplementedError("IV/2SLS estimator -- implementation pending")
