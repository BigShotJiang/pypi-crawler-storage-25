"""Configuration for maestro-economics."""
from pathlib import Path

DEFAULT_OUTPUT_DIR = Path.home() / ".maestro" / "economics" / "outputs"
DEFAULT_FIGURE_SIZE = (3.5, 2.5)  # single journal column
STAR_THRESHOLDS = {0.01: "***", 0.05: "**", 0.10: "*"}
DECIMAL_PLACES = {"coef": 4, "se": 4, "r2": 3, "n": 0}
