"""Custom exceptions for maestro-economics."""


class SpecificationError(Exception):
    """Invalid econometric specification."""


class EstimationError(Exception):
    """Error during estimation."""


class DataError(Exception):
    """Data does not meet method requirements."""
