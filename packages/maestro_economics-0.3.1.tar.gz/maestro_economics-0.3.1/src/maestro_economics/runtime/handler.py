"""Execution engine for run(ctx) jobs."""

from __future__ import annotations

import importlib.util
import io
import json
import os
import platform
import signal
import sys
from pathlib import Path
from typing import Any, Callable

from .context import GpuInfo, JobContext


class _CancelledError(Exception):
    """Raised when the job receives SIGTERM."""


class _Timeout:
    """Signal-based timeout guard for Unix platforms."""

    def __init__(self, seconds: int) -> None:
        self.seconds = seconds
        self._is_unix = platform.system() != "Windows"

    def _handler(self, signum: int, frame: Any) -> None:
        raise TimeoutError(f"Job exceeded timeout of {self.seconds} seconds")

    def __enter__(self) -> "_Timeout":
        if self._is_unix and self.seconds > 0:
            signal.signal(signal.SIGALRM, self._handler)
            signal.alarm(self.seconds)
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._is_unix and self.seconds > 0:
            signal.alarm(0)


def _install_sigterm_handler() -> None:
    if platform.system() == "Windows":
        return

    def _handler(signum: int, frame: Any) -> None:
        raise _CancelledError("Job cancelled by user (SIGTERM)")

    signal.signal(signal.SIGTERM, _handler)


def execute_job(
    script_path: str,
    data_dir: str,
    output_dir: str,
    config: dict[str, Any],
    progress_cb: Callable[[float, str], None],
    gpu_type: str | None = None,
    gpu_memory_gb: float | None = None,
    timeout: int = 0,
    checkpoint_dir: str | None = None,
    log_dir: str | None = None,
) -> dict[str, Any]:
    """Execute a user script's run(ctx) function."""
    os.makedirs(output_dir, exist_ok=True)
    _install_sigterm_handler()

    gpu = GpuInfo(type=gpu_type, memory_gb=gpu_memory_gb)
    ctx = JobContext(
        data_dir=Path(data_dir),
        output_dir=Path(output_dir),
        config=config,
        progress_callback=progress_cb,
        gpu=gpu,
        checkpoint_dir=Path(checkpoint_dir) if checkpoint_dir else None,
        log_dir=Path(log_dir) if log_dir else None,
    )

    if not os.path.isfile(script_path):
        raise ValueError(f"Cannot load script: {script_path}")
    spec = importlib.util.spec_from_file_location("user_script", script_path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load script: {script_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    if not hasattr(module, "run"):
        raise ValueError("Script must define a run(ctx) function")

    log_path = os.path.join(output_dir, "job.log")
    old_stdout, old_stderr = sys.stdout, sys.stderr
    log_buffer = io.StringIO()
    cancelled = False

    try:
        sys.stdout = log_buffer
        sys.stderr = log_buffer
        with _Timeout(timeout):
            result = module.run(ctx)
    except _CancelledError:
        cancelled = True
        result = {"status": "cancelled", "message": "Job cancelled by user"}
        try:
            ctx.log("[system] Job cancelled -- flushing logs and shutting down")
        except Exception:
            pass
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        with open(log_path, "w", encoding="utf-8") as file:
            file.write(log_buffer.getvalue())

    if cancelled:
        results_path = os.path.join(output_dir, "results.json")
        with open(results_path, "w", encoding="utf-8") as file:
            json.dump(result, file, indent=2, default=str)
        raise _CancelledError("Job cancelled by user")

    if not isinstance(result, dict):
        result = {"output": result}

    results_path = os.path.join(output_dir, "results.json")
    with open(results_path, "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, default=str)

    return result

