"""Panel-aware data transformations for economic research."""

from __future__ import annotations

from typing import Any

import pandas as pd


def winsorize(df: pd.DataFrame, col: str, pct: float = 0.01) -> pd.DataFrame:
    result = df.copy()
    lo = result[col].quantile(pct)
    hi = result[col].quantile(1 - pct)
    result[col] = result[col].clip(lower=lo, upper=hi)
    return result


def lag(
    df: pd.DataFrame,
    col: str,
    periods: int = 1,
    entity: str | None = None,
    time: str | None = None,
) -> pd.DataFrame:
    result = df.copy()
    if time is not None:
        result = result.sort_values([entity, time]) if entity else result.sort_values(time)
    new_col = f"{col}_lag{periods}"
    if entity:
        result[new_col] = result.groupby(entity)[col].shift(periods)
    else:
        result[new_col] = result[col].shift(periods)
    return result


def lead(
    df: pd.DataFrame,
    col: str,
    periods: int = 1,
    entity: str | None = None,
    time: str | None = None,
) -> pd.DataFrame:
    result = df.copy()
    if time is not None:
        result = result.sort_values([entity, time]) if entity else result.sort_values(time)
    new_col = f"{col}_lead{periods}"
    if entity:
        result[new_col] = result.groupby(entity)[col].shift(-periods)
    else:
        result[new_col] = result[col].shift(-periods)
    return result


def diff(
    df: pd.DataFrame,
    col: str,
    periods: int = 1,
    entity: str | None = None,
    time: str | None = None,
) -> pd.DataFrame:
    result = df.copy()
    if time is not None:
        result = result.sort_values([entity, time]) if entity else result.sort_values(time)
    new_col = f"{col}_diff{periods}"
    if entity:
        result[new_col] = result.groupby(entity)[col].diff(periods)
    else:
        result[new_col] = result[col].diff(periods)
    return result


def balance_panel(df: pd.DataFrame, entity: str, time: str) -> pd.DataFrame:
    all_times = df[time].unique()
    max_periods = len(all_times)
    counts = df.groupby(entity)[time].nunique()
    complete = counts[counts == max_periods].index
    return df[df[entity].isin(complete)].copy()


def dummy(df: pd.DataFrame, col: str, drop_first: bool = False) -> pd.DataFrame:
    return pd.get_dummies(df, columns=[col], prefix=col, drop_first=drop_first)


def standardize(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    result = df.copy()
    for col in cols:
        mean = result[col].mean()
        std = result[col].std(ddof=0)
        if std == 0:
            result[col] = 0.0
        else:
            result[col] = (result[col] - mean) / std
    return result


def merge(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: str | list[str],
    how: str = "inner",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    result = left.merge(right, on=on, how="outer", indicator=True)

    diagnostics = {
        "matched": int((result["_merge"] == "both").sum()),
        "left_only": int((result["_merge"] == "left_only").sum()),
        "right_only": int((result["_merge"] == "right_only").sum()),
    }

    if how == "inner":
        result = result[result["_merge"] == "both"]
    elif how == "left":
        result = result[result["_merge"].isin(["both", "left_only"])]
    elif how == "right":
        result = result[result["_merge"].isin(["both", "right_only"])]

    return result.drop(columns=["_merge"]), diagnostics


def recode(df: pd.DataFrame, col: str, mapping: dict) -> pd.DataFrame:
    result = df.copy()
    result[col] = result[col].map(lambda value: mapping.get(value, value))
    return result

