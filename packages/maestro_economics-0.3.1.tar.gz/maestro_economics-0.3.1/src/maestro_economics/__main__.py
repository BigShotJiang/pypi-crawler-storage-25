from maestro_economics.cli import app

app()
