"""Deploy maestro-economics worker to Modal Cloud."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys


def cmd_deploy(args: argparse.Namespace) -> None:
    subprocess.run(
        ["modal", "deploy", "src/maestro_economics/workers/modal_worker.py"],
        check=True,
        cwd=args.project_dir,
    )
    print("Deployed maestro-economics to Modal Cloud.")


def cmd_status(args: argparse.Namespace) -> None:
    subprocess.run(["modal", "app", "list"], check=True)


def cmd_test(args: argparse.Namespace) -> None:
    try:
        import modal  # noqa: F401
    except ImportError:
        print("Error: `modal` package not installed. Run: pip install modal", file=sys.stderr)
        sys.exit(1)

    from maestro_economics.workers.modal_worker import app, dispatch

    payload = {
        "job_id": "test-001",
        "gpu_type": args.gpu,
        "timeout": 120,
        "config": {},
        "callback_url": "https://httpbin.org/post",
    }

    print(f"Submitting test job with GPU={args.gpu}")
    print(json.dumps(payload, indent=2))

    with app.run():
        result = dispatch(payload)
    print("\nResult:")
    print(json.dumps(result, indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser(description="Deploy maestro-economics to Modal")
    parser.add_argument("--project-dir", default=".", help="Path to maestro-economics project root")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("deploy", help="Deploy the Modal app")
    sub.add_parser("status", help="Show deployed app status")

    test_parser = sub.add_parser("test", help="Submit a test job")
    test_parser.add_argument("--gpu", default="L4", choices=["T4", "L4", "A10G", "L40S", "A100", "H100"])

    args = parser.parse_args()
    if args.command == "deploy":
        cmd_deploy(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "test":
        cmd_test(args)


if __name__ == "__main__":
    main()
