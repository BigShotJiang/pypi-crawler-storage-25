"""Cloud worker entrypoints for maestro-economics."""

