# Fuzzy Name Matching Reference

## 1. Tool Selection Guide

| Tool | When to Use | Speed (4Kx10K) | Handles CN/EN |
|------|-------------|-----------------|---------------|
| Exact (normalized) | Trivial variants, suffix differences | <1s | No |
| `rapidfuzz` cdist | Typos, reordering, extra words | 2-5s | Same-script only |
| SentenceTransformer | Translations, different scripts, semantic | 30-120s CPU | Yes |
| FAISS + SentenceTransformer | Same as above, >100K refs | 30-60s encode + <1s search | Yes |

Decision: start with exact -> fuzzy -> semantic. Skip semantic if all same-language.

## 2. Name Normalization

```python
import re, unicodedata

EN_SUFFIXES = re.compile(
    r'\b(inc\.?|incorporated|corp\.?|corporation|co\.?|company|'
    r'ltd\.?|limited|llc|l\.l\.c\.?|plc|gmbh|ag|sa|s\.a\.?|'
    r'n\.v\.?|b\.v\.?|s\.r\.l\.?|pty\.?|pvt\.?)\b',
    re.IGNORECASE,
)
# Strip LONGEST first to avoid partial removal
CN_SUFFIXES = re.compile(
    r'(股份有限公司|有限责任公司|有限公司|责任有限公司|集团有限公司|'
    r'集团股份|集团公司|集团|控股|实业|科技|技术|工业|电子|'
    r'新能源|能源|光伏|电力|投资)',
)
PUNCT = re.compile(r'[.,;:!?\-_/\\()（）【】\[\]{}\"\'·・&@#%]')
MULTI_SPACE = re.compile(r'\s+')

def normalize_name(name: str) -> str:
    if not name or not isinstance(name, str):
        return ""
    name = unicodedata.normalize("NFKC", name)
    name = CN_SUFFIXES.sub("", name)       # CN suffixes before lowercasing
    name = name.lower()
    name = EN_SUFFIXES.sub("", name)
    name = PUNCT.sub(" ", name)
    name = MULTI_SPACE.sub(" ", name).strip()
    return name
```

## 3. rapidfuzz Scorers

`pip install rapidfuzz` -- all return float in [0, 100].

| Scorer | Use When | Example |
|--------|----------|---------|
| `fuzz.ratio` | Minor typos | "Trina Solar" vs "Trnia Solar" -> 91 |
| `fuzz.partial_ratio` | Substring match | "Huawei" vs "Huawei Technologies Co., Ltd." -> 100 |
| `fuzz.token_sort_ratio` | Same words, different order | "Wang Li" vs "Li Wang" -> 100 |
| `fuzz.token_set_ratio` | Extra words/suffixes | "LONGi Green Energy" vs "LONGi" -> 100 |
| `fuzz.WRatio` | General purpose (default in extract) | Weighted combo of all above |

**Company names: use `token_set_ratio`** -- handles suffixes (Co., Ltd., Inc.) naturally.

All accept `score_cutoff=` for early exit optimization.

## 4. Batch Matching with cdist

```python
from rapidfuzz import fuzz
from rapidfuzz.process import cdist
import numpy as np

# Full similarity matrix -- C++ accelerated, multi-threaded
matrix = cdist(
    target_names, reference_names,
    scorer=fuzz.token_set_ratio,
    dtype=np.float32,
    workers=-1,          # all CPU cores
    score_cutoff=50,     # cells below 50 -> 0 (sparse optimization)
)
# matrix[i][j] = similarity(target[i], ref[j])

best_indices = matrix.argmax(axis=1)
best_scores = matrix.max(axis=1)
```

Single match: `process.extractOne(query, refs, scorer=fuzz.token_set_ratio, score_cutoff=70)`

## 5. SentenceTransformer Bilingual Matching

`pip install sentence-transformers`

| Model | Dims | Languages | Size | Use Case |
|-------|------|-----------|------|----------|
| `paraphrase-multilingual-MiniLM-L12-v2` | 384 | 50+ (CN+EN) | 471MB | **Default for RA pipelines** |
| `all-MiniLM-L6-v2` | 384 | EN only | 80MB | English-only, fastest |
| `paraphrase-multilingual-mpnet-base-v2` | 768 | 50+ | 1.1GB | Higher quality, slower |

```python
from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")

# ALWAYS batch encode -- never one-by-one
t_emb = model.encode(target_names, batch_size=128, show_progress_bar=True,
                     convert_to_tensor=True, normalize_embeddings=True)
r_emb = model.encode(ref_names, batch_size=128, show_progress_bar=True,
                     convert_to_tensor=True, normalize_embeddings=True)

cos_scores = util.cos_sim(t_emb, r_emb)  # (N_target, N_ref)
```

Threshold table (`paraphrase-multilingual-MiniLM-L12-v2`):

| Cosine Sim | Meaning | Action |
|------------|---------|--------|
| >= 0.90 | Near-identical | Auto-accept |
| 0.80-0.90 | High confidence | Auto-accept |
| 0.65-0.80 | Moderate | Flag for manual review |
| < 0.65 | Unlikely match | Reject |

Cross-lingual (CN/EN): lower threshold to 0.70 for auto-accept.

## 6. 3-Stage Pipeline Pattern

```
targets + references
    |
[1] Normalize -> exact match on normalized strings  -> matched_exact
    |
  unmatched
    |
[2] rapidfuzz cdist (token_set_ratio >= 80)          -> matched_fuzzy
    |
  still unmatched
    |
[3] SentenceTransformer cos_sim (>= 0.70)            -> matched_semantic
    |
  final unmatched -> output with match_method="none"
```

Output schema: `target_name, best_match, similarity_score, match_method`

## 7. Chinese Company Name Challenges

CN name structure: `[region][brand][industry][legal_form]`
Example: `深圳市华为技术有限公司` -> region=深圳市, brand=华为, industry=技术, form=有限公司

**Strip order matters:** legal forms first, then industry terms. Longest match first.

Non-obvious transliterations (fuzzy matching WILL FAIL on these):

| Chinese | English | Why |
|---------|---------|-----|
| 天合光能 | Trina Solar | Not pinyin |
| 阿特斯 | Canadian Solar | Completely different |
| 隆基绿能 | LONGi Green Energy | Capitalization varies |
| 晶科能源 | Jinko Solar | Compound form |
| 比亚迪 | BYD | Acronym |

Solution: manual lookup table applied BEFORE fuzzy/semantic stages.

```python
TRANSLITERATION_MAP = {
    "天合光能": "Trina Solar",
    "阿特斯": "Canadian Solar",
    "隆基绿能": "LONGi Green Energy",
    "晶科能源": "Jinko Solar",
    "晶澳科技": "JA Solar",
    "比亚迪": "BYD",
    "通威股份": "Tongwei",
}

def apply_transliteration(name: str, mapping: dict) -> str | None:
    for cn, en in mapping.items():
        if cn in name:
            return en
    return None
```

Language detection:
```python
def detect_lang(name: str) -> str:
    cjk = sum(1 for c in name if '\u4e00' <= c <= '\u9fff')
    alpha = sum(1 for c in name if c.isalpha())
    return "cn" if alpha > 0 and cjk / alpha > 0.3 else "en"
```

## 8. Geographic Name Matching

```python
from rapidfuzz.distance import JaroWinkler

def normalize_geo_name(name: str) -> str:
    name = name.lower().strip()
    name = re.sub(r'\b(province|state|district|county|prefecture|city|region)\b', '', name)
    return re.sub(r'\s+', ' ', name).strip()

# Jaro-Winkler: good for transliterated place names
sim = JaroWinkler.similarity("guangzhou", "guangjou")  # returns [0, 1]
```

GID code matching (GADM versions): strip version suffix, compare base.
```python
def match_gid(gid_a: str, gid_b: str) -> bool:
    return gid_a.rsplit("_", 1)[0] == gid_b.rsplit("_", 1)[0]
```

Geo names are shorter -- use `fuzz.ratio` instead of `token_set_ratio`.

## 9. Performance Tips

| Technique | When |
|-----------|------|
| Pre-filter by length (ratio=0.3) | Reduce comparison space |
| `score_cutoff=` in cdist | Sparse matrix, skip low scores |
| `workers=-1` in cdist | Multi-core C++ acceleration |
| FAISS `IndexFlatIP` | >100K references |
| Incremental CSV saving | Long-running jobs |

FAISS pattern for large-scale:
```python
import faiss, numpy as np

ref_emb = model.encode(ref_names, normalize_embeddings=True)
ref_emb = np.array(ref_emb, dtype=np.float32)

index = faiss.IndexFlatIP(ref_emb.shape[1])  # cosine sim for normalized vecs
index.add(ref_emb)

target_emb = np.array(model.encode(target_names, normalize_embeddings=True), dtype=np.float32)
scores, indices = index.search(target_emb, k=5)
```

For >1M refs, use `IndexIVFFlat` with `nlist=100, nprobe=10`.

## 10. Complete CLI Script

```python
#!/usr/bin/env python3
"""match_names.py -- 3-stage entity name matching.

Usage: python match_names.py targets.csv references.csv output.csv
Input CSVs need a 'name' column. Output: target_name,best_match,similarity_score,match_method
"""
import argparse, re, unicodedata
import numpy as np
import pandas as pd
from rapidfuzz import fuzz
from rapidfuzz.process import cdist

EN_SUFFIXES = re.compile(
    r'\b(inc\.?|incorporated|corp\.?|corporation|co\.?|company|'
    r'ltd\.?|limited|llc|l\.l\.c\.?|plc|gmbh|ag|sa|s\.a\.?|'
    r'n\.v\.?|b\.v\.?|s\.r\.l\.?|pty\.?|pvt\.?)\b', re.IGNORECASE)
CN_SUFFIXES = re.compile(
    r'(股份有限公司|有限责任公司|有限公司|责任有限公司|集团有限公司|'
    r'集团股份|集团公司|集团|控股|实业)')
PUNCT = re.compile(r'[.,;:!?\-_/\\()（）【】\[\]{}\"\'·・&@#%]')

def norm(name):
    if not name or not isinstance(name, str): return ""
    name = unicodedata.normalize("NFKC", name)
    name = CN_SUFFIXES.sub("", name).lower()
    name = EN_SUFFIXES.sub("", name)
    return re.sub(r'\s+', ' ', PUNCT.sub(" ", name)).strip()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("targets"); ap.add_argument("references"); ap.add_argument("output")
    ap.add_argument("--target-col", default="name")
    ap.add_argument("--ref-col", default="name")
    ap.add_argument("--fuzzy-threshold", type=float, default=80.0)
    ap.add_argument("--semantic-threshold", type=float, default=0.70)
    ap.add_argument("--skip-semantic", action="store_true")
    args = ap.parse_args()

    tgt = pd.read_csv(args.targets); ref = pd.read_csv(args.references)
    tc, rc = args.target_col, args.ref_col
    tgt["_n"] = tgt[tc].apply(norm); ref["_n"] = ref[rc].apply(norm)
    print(f"Targets: {len(tgt)} | Refs: {len(ref)}")

    # Stage 1: Exact
    ref_map = dict(zip(ref["_n"], ref[rc]))
    exact_mask = tgt["_n"].isin(ref_map) & (tgt["_n"] != "")
    m1 = tgt[exact_mask].assign(best_match=lambda d: d["_n"].map(ref_map),
                                 similarity_score=1.0, match_method="exact")
    m1 = m1.rename(columns={tc: "target_name"})[["target_name","best_match","similarity_score","match_method"]]
    um = tgt[~exact_mask].copy()
    print(f"[exact]    {len(m1)} matched, {len(um)} remaining")

    # Stage 2: Fuzzy
    if len(um) > 0:
        mat = cdist(um["_n"].tolist(), ref["_n"].tolist(),
                    scorer=fuzz.token_set_ratio, dtype=np.float32, workers=-1)
        bj = mat.argmax(axis=1); bs = mat.max(axis=1)
        fmask = bs >= args.fuzzy_threshold
        r_orig = ref[rc].tolist()
        m2_rows = [{"target_name": um.iloc[i][tc], "best_match": r_orig[bj[i]],
                     "similarity_score": round(bs[i]/100, 4), "match_method": "fuzzy"}
                    for i in range(len(um)) if fmask[i]]
        m2 = pd.DataFrame(m2_rows)
        um = um[~fmask].copy()
    else:
        m2 = pd.DataFrame()
    print(f"[fuzzy]    {len(m2)} matched, {len(um)} remaining")

    # Stage 3: Semantic
    m3 = pd.DataFrame()
    if not args.skip_semantic and len(um) > 0:
        from sentence_transformers import SentenceTransformer, util
        model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
        te = model.encode(um[tc].tolist(), batch_size=128, convert_to_tensor=True,
                          normalize_embeddings=True, show_progress_bar=True)
        re_ = model.encode(ref[rc].tolist(), batch_size=128, convert_to_tensor=True,
                           normalize_embeddings=True, show_progress_bar=True)
        cos = util.cos_sim(te, re_)
        s_rows = []
        keep = []
        for i in range(len(um)):
            sc, j = cos[i].max(dim=0)
            if sc.item() >= args.semantic_threshold:
                s_rows.append({"target_name": um.iloc[i][tc], "best_match": ref.iloc[j.item()][rc],
                                "similarity_score": round(sc.item(), 4), "match_method": "semantic"})
                keep.append(False)
            else:
                keep.append(True)
        m3 = pd.DataFrame(s_rows)
        um = um[keep].copy()
        print(f"[semantic] {len(m3)} matched, {len(um)} remaining")

    # Combine
    none_rows = pd.DataFrame({"target_name": um[tc].values, "best_match": "",
                               "similarity_score": 0.0, "match_method": "none"}) if len(um) else pd.DataFrame()
    result = pd.concat([m1, m2, m3, none_rows], ignore_index=True)
    result.to_csv(args.output, index=False)
    print(f"\nSaved {len(result)} rows to {args.output}")

if __name__ == "__main__":
    main()
```

## Common Pitfalls

| Pitfall | Fix |
|---------|-----|
| Encoding names one-by-one with SentenceTransformer | Always batch encode |
| Not normalizing before exact match | Normalize first, match second |
| Using `token_set_ratio` for geo names | Use `fuzz.ratio` or Jaro-Winkler (names are short) |
| CN suffix regex matches substrings wrong | Order longest-first in alternation |
| Cross-lingual fuzzy match (CN vs EN) | Fuzzy CANNOT handle this -- use semantic or lookup table |
| Not stripping suffixes before fuzzy | Suffixes inflate scores between unrelated companies |
| Threshold too high for cross-lingual | Use 0.70 not 0.80 for CN/EN semantic matching |
