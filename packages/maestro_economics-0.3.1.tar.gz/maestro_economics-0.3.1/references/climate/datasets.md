# Climate Dataset Catalog — Detailed Reference

## 1. Global Gridded Sources

### 1.1 ERA5 — ECMWF Reanalysis v5 (Gold Standard 2020+)

| Attribute | Value |
|-----------|-------|
| Variables | 200+ incl. 2m temperature, total precip, u/v wind, solar radiation, humidity, SLP |
| Resolution | 0.25° × 0.25° (~28 km), **hourly** |
| Time | 1940–present (real-time lag: 5 days) |
| Coverage | Global including ocean |
| License | Free (Copernicus) |
| Size | Full dataset: petabytes; scoped requests: manageable |

**Setup — CDS API (one-time):**
```bash
# 1. Register at https://cds.climate.copernicus.eu/how-to-api
# 2. Get UID + API key from profile page
# 3. Create credentials file:
cat > ~/.cdsapirc << 'EOF'
url: https://cds.climate.copernicus.eu/api
key: <YOUR-UID>:<YOUR-API-KEY>
EOF
pip install cdsapi
```

**Download — Python (always scope by variable + year + bbox):**
```python
import cdsapi
c = cdsapi.Client()

# Monthly 2m temperature, 1950–2023, global
c.retrieve(
    'reanalysis-era5-single-levels-monthly-means',
    {
        'product_type': 'monthly_averaged_reanalysis',
        'variable': ['2m_temperature', 'total_precipitation'],
        'year': [str(y) for y in range(1950, 2024)],
        'month': [f'{m:02d}' for m in range(1, 13)],
        'time': '00:00',
        'format': 'netcdf',
        # Optional bbox for China: [55, 70, 5, 140] = [N, W, S, E]
        # 'area': [55, 70, 5, 140],
    },
    '~/.maestro/cache/era5_monthly_t2m_precip_1950-2023.nc'
)
```

**Download — Google Earth Engine (daily aggregates, no API key needed):**
```javascript
// GEE catalog: ECMWF/ERA5/DAILY
var era5 = ee.ImageCollection('ECMWF/ERA5/DAILY')
  .filterDate('1980-01-01', '2023-12-31')
  .select(['mean_2m_air_temperature', 'total_precipitation']);
```

**Variables commonly used in econ papers:**
- `2m_temperature` → daily/monthly mean temperature (K, convert: K−273.15 = °C)
- `total_precipitation` → accumulated precip in meters (multiply ×1000 for mm)
- `2m_dewpoint_temperature` → for humidity/wet-bulb calculation
- `surface_solar_radiation_downwards` → growing degree days, crop models

---

### 1.2 CRU TS — Climate Research Unit Time-Series

| Attribute | Value |
|-----------|-------|
| Variables | tmp (mean temp), tmx (max), tmn (min), pre (precip), pet, cld, frs, vap, wet |
| Resolution | 0.5° × 0.5° (~55 km), **monthly** |
| Time | 1901–2022 (v4.07) |
| Coverage | All land except Antarctica |
| License | Free (CEDA, requires free registration) |
| Size | ~400 MB per variable (.nc.gz) |

**Download (no registration needed — direct HTTP):**
```bash
# Temperature — 163 MB compressed (full 1901–2022):
maestro-fetch "https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.07/cruts.2304141047.v4.07/tmp/cru_ts4.07.1901.2022.tmp.dat.nc.gz"

# Precipitation — 225 MB compressed (full 1901–2022):
maestro-fetch "https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.07/cruts.2304141047.v4.07/pre/cru_ts4.07.1901.2022.pre.dat.nc.gz"

# Other variables follow same pattern (replace variable code):
# var codes: tmp tmx tmn pre pet cld frs vap wet
# Base: https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.07/cruts.2304141047.v4.07/{var}/cru_ts4.07.1901.2022.{var}.dat.nc.gz
```

**Decade slices (if only partial period needed, ~14 MB each):**
```bash
# e.g. 1981–1990 only:
maestro-fetch "https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.07/cruts.2304141047.v4.07/tmp/cru_ts4.07.1981.1990.tmp.dat.nc.gz"
```

**Python read pattern:**
```python
import xarray as xr
ds = xr.open_dataset('cru_ts4.07.1901.2022.tmp.dat.nc')
# coords: time (monthly), lat (0.5° grid), lon (0.5° grid)
# variable: tmp (°C, _FillValue = 9.96921e+36)
```

**Citation:** Harris et al. (2020), *Scientific Data* 7:109.

---

### 1.3 UDEL / Willmott-Matsuura

| Attribute | Value |
|-----------|-------|
| Variables | air_temp (monthly mean °C), precip (monthly total mm) |
| Resolution | 0.5° × 0.5°, **monthly** |
| Time | 1900–2017 (v5.01) |
| Size | ~50 MB per variable |
| Famous use | Dell, Jones & Olken (2012, *AEJ:Macro*) |

**Download (258 MB + 284 MB):**
```bash
# Temperature v5.01 (258 MB):
maestro-fetch "https://climate.geog.udel.edu/html_pages/Global2017/air_temp_2017.tar.gz"

# Precipitation v5.01 (284 MB):
maestro-fetch "https://climate.geog.udel.edu/html_pages/Global2017/precip_2017.tar.gz"
```

**Note:** Site states "no future updates" — v5.01 (1900–2017) is the final release.

**File format:** ASCII grid files, one per month. Header: ncols, nrows, xllcorner, yllcorner, cellsize, NODATA_value. Grid fills lat −90→+90, lon −180→+180.

**Python read pattern:**
```python
import numpy as np

def read_udel(filepath):
    """Read UDEL monthly ASCII grid. Returns (lat, lon, data) arrays."""
    with open(filepath) as f:
        header = {f.readline().split()[0]: float(f.readline().split()[1])
                  for _ in range(6)}
        data = np.loadtxt(f)
    return data
```

---

### 1.4 CHIRPS — Climate Hazards InfraRed Precipitation with Station data

| Attribute | Value |
|-----------|-------|
| Variables | Precipitation only |
| Resolution | 0.05° (~5 km), daily / pentad / monthly |
| Time | 1981–present (lag ~3 weeks) |
| Coverage | 50°S–50°N (tropical/subtropical land) |
| License | Public domain (CC0) |
| Size | Global monthly: ~2 GB/year as GeoTIFF |
| AWS bucket | `s3://chc-global-v2/CHIRPSv2.0` |

**Best for:** Africa, South Asia, Latin America precipitation shocks. Superior to CRU TS for sparse-station regions.

**Download — monthly GeoTIFFs:**
```bash
# Single month (replace YYYY/MM):
maestro-fetch "https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/tifs/chirps-v2.0.2020.01.tif.gz"

# Annual batch via Python:
import asyncio
from maestro_fetch import batch_fetch

urls = [
    f"https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/tifs/chirps-v2.0.{y}.{m:02d}.tif.gz"
    for y in range(1981, 2024) for m in range(1, 13)
]
asyncio.run(batch_fetch(urls, concurrency=8))
```

**Download — annual NetCDF (163 MB/year, recommended):**
```bash
# Single year (replace YYYY):
maestro-fetch "https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/netcdf/byYear/chirps-v2.0.2020.monthly.nc"

# Batch 1981–2023 via Python (~7 GB total):
import asyncio
from maestro_fetch import batch_fetch

urls = [f"https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/netcdf/byYear/chirps-v2.0.{y}.monthly.nc"
        for y in range(1981, 2024)]
asyncio.run(batch_fetch(urls, concurrency=4))
```

**NOTE:** Full single NetCDF (all years) = 7.1 GB at:
`https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/netcdf/chirps-v2.0.monthly.nc`
Only download if disk space allows.

---

### 1.5 WorldClim v2.1 — Climatological Averages (NOT time series)

| Attribute | Value |
|-----------|-------|
| Variables | BIO1–BIO19 (temperature + precipitation derived indices), monthly means |
| Resolution | 10 min / 5 min / 2.5 min / 30 sec (up to ~1 km) |
| Time | **1970–2000 average** (no interannual variation) |
| License | CC BY 4.0 |

**WARNING:** WorldClim is a *climatology*, not a time series. Use only for:
- Cross-sectional baseline controls
- RDD bandwidth calibration (agro-ecological zone boundaries)
- Long-run climate exposure variables
- **DO NOT use for panel fixed effects or shock identification**

**Download:**
```bash
# BIO variables (10 arc-min, ~90 MB):
maestro-fetch "https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_10m_bio.zip"

# Monthly temperature (10 arc-min):
maestro-fetch "https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_10m_tavg.zip"

# Monthly precipitation (10 arc-min):
maestro-fetch "https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_10m_prec.zip"
```

**Key BIO variables for economics:**
| Variable | Description |
|----------|-------------|
| BIO1 | Annual Mean Temperature (°C × 10) |
| BIO4 | Temperature Seasonality (std dev × 100) |
| BIO5 | Max Temperature Warmest Month |
| BIO12 | Annual Precipitation (mm) |
| BIO15 | Precipitation Seasonality (CV) |

---

### 1.6 CHELSA v2.1 — High Resolution with Orographic Correction

| Attribute | Value |
|-----------|-------|
| Variables | Daily tas/tasmax/tasmin/pr, 12 bioclimatic vars |
| Resolution | 30 arcsec (~1 km), **daily** |
| Time | 1979–2016 (ERA-Interim based); W5E5 version: 1979–2019 |
| License | CC BY 4.0 |

**Use when:** Mountain regions, Southeast Asia, Andes, Himalayas — anywhere orographic precipitation matters.

**Download (monthly climatology, ~1 GB/variable):**
```bash
# Monthly mean temp (30 arcsec):
maestro-fetch "https://os.zhdk.cloud.switch.ch/envicloud/chelsa/chelsa_V2/GLOBAL/climatologies/1981-2010/tas/CHELSA_tas_01_1981-2010_V.2.1.tif"
# Pattern: CHELSA_tas_{MM:02d}_1981-2010_V.2.1.tif (MM = 01..12)
```

---

### 1.7 Berkeley Earth Surface Temperature

| Attribute | Value |
|-----------|-------|
| Variables | Temperature anomaly (land + ocean) |
| Resolution | 1° × 1°, monthly |
| Time | 1850–present |
| Famous use | Burke, Hsiang & Miguel (2015, *Nature*) |

**Download:**
```bash
maestro-fetch "https://berkeley-earth-temperature.s3.amazonaws.com/Global/Gridded/Land_and_Ocean_LatLong1.nc"
```

---

## 2. Country-Specific Sources

### 2.1 China — CMA / CMDC

| Attribute | Value |
|-----------|-------|
| Stations | 2,400 national stations (county-level coverage) |
| Variables | Daily Tmax/Tmin/Tmean, precip, sunshine hours, wind, RH |
| Time | 1951–present |
| Format | CSV per station per variable (daily) |
| Access | data.cma.cn — **free for academic research with registration** |

**Registration:** http://data.cma.cn/user/register.html (requires institution email + research purpose)

**Dataset IDs on CMDC:**
- `SURF_CLI_CHN_MUL_DAY` — Daily surface multi-element (V3.0)
- `SURF_CLI_CHN_MUL_MON` — Monthly aggregates

**Alternative for China:** ERA5 0.25° covers all of China; use `rasterstats.zonal_stats()` to aggregate to county/prefecture polygons. No registration required.

**County/prefecture shapefiles:** GADM v4.1 or NBS administrative boundary data (data.stats.gov.cn).

---

### 2.2 United States — NOAA

| Dataset | Resolution | Time | Variables | Use |
|---------|-----------|------|-----------|-----|
| **nClimGrid-Daily** | 5 km → county | 1951–present | Tmax/Tmin/Tavg/Prcp | County FE panels |
| **nClimGrid-Monthly** | 5 km → county | 1895–present | Same | Longer history |
| **PRISM** | 800 m, CONUS | 1895–present (monthly); 1981+ (daily) | Tmax/Tmin/Tmean/Ppt | Agriculture papers |
| **GHCN-D** | Stations (~30k in US) | 1763–present | Full suite | Station FE / validation |

**nClimGrid county-level (ready-to-use CSV):**
```bash
maestro-fetch "https://www.ncei.noaa.gov/pub/data/climgrid/nClimDiv_CONUS_Monthly.tgz"
```

**PRISM via API:**
```bash
maestro-fetch "https://services.nacse.org/prism/data/public/4km/tmean/20200101"
```

**GHCN-D — all stations, all time:**
```bash
maestro-fetch "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd_all.tar.gz"
# ~4 GB compressed; station inventory: ghcnd-stations.txt
```

---

### 2.3 India — IMD Gridded

| Dataset | Resolution | Time | Variable |
|---------|-----------|------|----------|
| **IMD Gridded Rainfall v3** | 0.25° (~28 km) | 1901–2024, **daily** | Precipitation |
| **IMD Gridded Temperature (Tmax)** | 1° (~110 km) | 1969–present, daily | Max temperature |
| **IMD Gridded Temperature (Tmin)** | 1° | 1969–present, daily | Min temperature |

**Download (binary format — use IMDLIB):**
```python
pip install imdlib

import imdlib as imd

# Rainfall 1990–2020:
data = imd.get_data('rain', 1990, 2020, fn_format='yearwise',
                     file_dir='~/.maestro/cache/imd/')
# Returns xarray Dataset; .save_nc() for NetCDF

# Temperature:
data = imd.get_data('tmax', 1990, 2020, fn_format='yearwise',
                     file_dir='~/.maestro/cache/imd/')
```

**Direct URL for 0.25° rainfall:**
```
https://imdpune.gov.in/cmpg/Griddata/Rainfall_25_Bin.html
# Binary files: RF25_ind{YYYY}_rfp25.grd (annual gridded)
```

---

### 2.4 Brazil — INMET / CLIMBra

| Dataset | Resolution | Time | Variables |
|---------|-----------|------|-----------|
| **CLIMBra** | 0.1° (~10 km) | 1980–2021, daily | Precip, Tmax, Tmin, radiation, wind, RH |
| **INMET stations API** | ~500 stations | 1961–present | Full suite |
| **MERGE (INPE)** | 0.1° | 1998–present, daily | Precipitation |

**CLIMBra download:**
```bash
maestro-fetch "https://zenodo.org/record/7124771/files/CLIMBra_v2.zip"
```

**INMET API:**
```bash
# Token required (free registration at portal.inmet.gov.br)
# Station list: GET https://apitempo.inmet.gov.br/estacoes/T
# Daily data: GET https://apitempo.inmet.gov.br/estacao/diaria/{code}/{start}/{end}
```

---

### 2.5 Indonesia — ERA5 Recommended

BMKG official data requires institutional request. For research:
- Use **ERA5 0.25°** → zonal stats to kabupaten (district) polygons
- Use **CHIRPS** for precipitation (0.05°, better resolution)
- GADM v4.1 for Indonesia administrative boundaries

---

### 2.6 Sub-Saharan Africa

**Recommended stack:**
```
Precipitation:  CHIRPS 0.05° daily (1981–present)
Temperature:    CRU TS 0.5° monthly (1901–2022)  OR  ERA5 0.25°
Admin units:    GADM v4.1  OR  IPUMS international census shapefiles
```

**GADM v4.1 download:**
```bash
# Country-level shapefiles (all admin levels):
maestro-fetch "https://geodata.ucdavis.edu/gadm/gadm4.1/gpkg/gadm41_KEN.gpkg"
# Pattern: gadm41_{ISO3}.gpkg  (ISO3 = KEN, NGA, ZAF, ETH, ...)
```
