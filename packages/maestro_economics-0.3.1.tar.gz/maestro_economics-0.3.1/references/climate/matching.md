# Admin Unit Matching & Panel Construction — Detailed Reference

## 1. Admin Unit Matching Workflow (Standard for All Sources)

### Step 1 — Prepare polygons

```python
import geopandas as gpd

# Download GADM or national shapefile
admin = gpd.read_file('gadm41_IND_2.gpkg')  # level 2 = district
admin = admin.to_crs('EPSG:4326')  # ensure WGS84
```

### Step 2 — Zonal statistics (raster → polygon)

```python
import rasterstats
import rioxarray as rxr

# Open raster
raster = rxr.open_rasterio('chirps-v2.0.2020.01.tif', masked=True)

# Compute mean/sum per polygon
stats = rasterstats.zonal_stats(
    admin,
    raster.values[0],
    affine=raster.rio.transform(),
    stats=['mean', 'sum', 'count'],
    nodata=raster.rio.nodata
)

admin['precip_mean'] = [s['mean'] for s in stats]
```

### Step 3 — NetCDF time series → panel

```python
import xarray as xr
import geopandas as gpd
from rasterstats import zonal_stats
import pandas as pd

ds = xr.open_dataset('cru_ts4.07.1901.2022.tmp.dat.nc')

records = []
for t in ds.time.values:
    arr = ds['tmp'].sel(time=t).values
    stats = zonal_stats(admin, arr,
                        affine=...,  # from ds.rio.transform()
                        stats=['mean'], nodata=9.96921e+36)
    for i, s in enumerate(stats):
        records.append({
            'admin_id': admin.iloc[i]['GID_2'],
            'time': t,
            'tmp_mean': s['mean']
        })

panel = pd.DataFrame(records)
```

### Step 4 — Population weighting (common in cross-country papers)

```python
# GPW v4 population grid: https://sedac.ciesin.columbia.edu/data/set/gpwv4-population-count
# Workflow: multiply climate raster × population raster, sum within polygon, divide by total pop
```

---

## 2. China CMA Station-to-County Matching (IDW)

```python
import geopandas as gpd
import pandas as pd
from scipy.interpolate import griddata

# Load stations with lat/lon/value
stations = pd.read_csv('cma_stations.csv')  # cols: lon, lat, value

# Load county centroids
counties = gpd.read_file('china_county_2020.shp')
counties['centroid_lon'] = counties.geometry.centroid.x
counties['centroid_lat'] = counties.geometry.centroid.y

# IDW interpolation (standard in China climate-econ papers)
counties['climate_var'] = griddata(
    points=stations[['lon', 'lat']].values,
    values=stations['value'].values,
    xi=counties[['centroid_lon', 'centroid_lat']].values,
    method='linear'  # or 'nearest' for robustness check
)
```

---

## 3. India District Matching (IMD Gridded)

```python
import rasterstats

districts = gpd.read_file('india_districts_2011.shp')
result = rasterstats.zonal_stats(
    districts,
    'imd_rainfall_2020.tif',
    stats=['mean', 'sum'],
    nodata=-999
)
```

---

## 4. Common Variables Table

| Variable | Unit | Notes |
|----------|------|-------|
| Temperature | °C or K (ERA5: K, subtract 273.15) | |
| Precipitation | mm (CRU/CHIRPS); m (ERA5: multiply ×1000) | |
| GDD (growing degree days) | °C-days | Σ max(0, Tmean − base_temp) per day |
| HDD / CDD | degree-days | Heating/Cooling Degree Days from daily data |
| SPEI | dimensionless | Standardized Precipitation-Evapotranspiration Index |
| Wet-bulb temperature | °C | From T + RH: `metpy.calc.wet_bulb_temperature()` |
| SPI | dimensionless | Standardized Precipitation Index (3/6/12 month) |

---

## 5. Frequently Cited Papers → Data Sources

| Paper | Journal | Country | Climate Data Used |
|-------|---------|---------|------------------|
| Dell, Jones, Olken (2012) | *AEJ:Macro* | Global | **UDEL** v3 (temp + precip) |
| Burke, Hsiang, Miguel (2015) | *Nature* | Global | **Berkeley Earth** temp |
| Schlenker & Roberts (2009) | *PNAS* | USA | **PRISM** daily temp |
| Deryugina (2017) | *AEJ:Policy* | USA | GHCN + NWS stations |
| Chen et al. (2013) | *PNAS* | China | **CMA stations** IDW |
| Carleton & Hsiang (2016) | *Science* | Global | **ERA5** / **CRU TS** |
| Jayachandran (2009) | *AEJ:Applied* | India | **IMD** district rainfall |
