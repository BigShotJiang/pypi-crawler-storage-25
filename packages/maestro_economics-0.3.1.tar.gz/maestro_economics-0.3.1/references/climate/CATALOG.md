# Climate Panel Datasets — Product Catalog

Research-grade climate panels matched to administrative boundaries.
Ready for econometric analysis in Stata, R, and Python.

---

## Pre-Built Panels

### Global Country Climate Panel
- **Coverage**: 258 countries, 1900-2017, monthly
- **Variables**: temperature (degC), precipitation (mm/month)
- **Source**: UDEL v5.01 (Willmott & Matsuura, 2018)
- **Boundaries**: Natural Earth 10m (ISO 3166-1 alpha-3)
- **Rows**: 365,328
- **Complexity**: L1
- **Use cases**: cross-country growth regressions, climate-GDP panels, long-run climate effects

### WorldClim Admin1 Cross-Section
- **Coverage**: 4,596 first-level administrative units (states/provinces), climatology
- **Variables**: 19 bioclimatic indices (BIO1-BIO19) + monthly temperature and precipitation
- **Source**: WorldClim v2.1 (1970-2000 average)
- **Boundaries**: Natural Earth 10m Admin 1
- **Rows**: 4,596
- **Complexity**: L1
- **Use cases**: cross-sectional controls, agro-ecological zone classification, RDD calibration

### Africa Country Climate Panel
- **Coverage**: 55 African countries, 1981-2022, monthly
- **Variables**: temperature (degC, from CRU TS), precipitation (mm, from CHIRPS)
- **Source**: CRU TS v4.07 + CHIRPS v2.0
- **Boundaries**: Natural Earth (African subset)
- **Rows**: 27,720
- **Complexity**: L1-L2
- **Use cases**: African development economics, rainfall shocks, agricultural productivity

### US County Climate Panel
- **Coverage**: 3,108 US counties, 1895-2024, monthly
- **Variables**: tavg (degC), tmax (degC), tmin (degC), precip (mm)
- **Source**: NOAA nClimGrid
- **Boundaries**: FIPS county codes
- **Rows**: 4,923,701
- **Complexity**: L2
- **Use cases**: county fixed-effects panels, agriculture, mortality, energy demand

### India District Climate Panel
- **Coverage**: ~730 districts, 1981-2022, monthly
- **Variables**: rainfall (mm), tmax (degC), tmin (degC)
- **Source**: IMD Gridded 0.25deg (rainfall) + 1deg (temperature)
- **Boundaries**: GADM v4.1 level 2
- **Rows**: TBD (in progress)
- **Complexity**: L2
- **Use cases**: monsoon shocks, agricultural output, labor supply

---

## Standard Deliverables (all panels)

```
{dataset-slug}/
  data.csv          Panel in long format (admin_id, year, month, variables)
  codebook.xlsx     Variable definitions, types, summary statistics
  README.md         Documentation with Python/Stata/R usage examples
  version.json      Provenance metadata (sources, build date, row counts)
  report.pdf        Quality audit: coverage heatmaps, distributions, time series
```

---

## Custom Panel Construction

We build climate panels for any combination of:
- **Admin level**: country, state/province, district, county, municipality
- **Time granularity**: monthly, annual, daily (ERA5 only)
- **Variables**: temperature, precipitation, GDD/HDD/CDD, SPEI/SPI, wind, humidity
- **Population weighting**: GPW v4 weights for area-population adjustment
- **Boundary crosswalks**: historical boundary harmonization across census years

### Pricing

| Tier | Scope | Price |
|------|-------|-------|
| L1 | Single source, standard admin level | $400-800 |
| L2 | Multi-source, temporal harmonization | $1,200-1,600 |
| L3 | Spatial join, boundary crosswalk, custom indices | $2,000-3,000 |
| L4 | Interpolation, uncertainty quantification | $3,000-5,000 |

### Maintenance

| Plan | Monthly | Includes |
|------|---------|----------|
| Basic | $600 | Monthly data updates |
| Standard | $1,200 | + quality monitoring, alerts |
| Premium | $2,000 | + priority SLA, custom variables |

---

## Data Sources

| Source | Resolution | Coverage | Time |
|--------|-----------|----------|------|
| UDEL v5.01 | 0.5deg | Global land | 1900-2017 |
| CRU TS v4.07 | 0.5deg | Global land | 1901-2022 |
| CHIRPS v2.0 | 0.05deg | 50S-50N | 1981-present |
| WorldClim v2.1 | 10arcmin | Global land | 1970-2000 avg |
| ERA5 | 0.25deg | Global | 1940-present |
| NOAA nClimGrid | 5km | CONUS | 1895-present |
| IMD Gridded | 0.25deg | India | 1901-present |
| PRISM | 800m | CONUS | 1895-present |

---

## Contact

Email: ding@maestro.onl
Website: https://ra.maestro.onl/data
