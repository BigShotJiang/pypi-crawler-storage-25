# Dataset Registry, Scripts & Pricing — Detailed Reference

## 1. Dataset Registry

After downloading, always register:
```bash
python3 ~/maestro/maestro-skills/datasets/scripts/maestro_datasets.py mark-downloaded \
    {id} --path ~/Dropbox/datasets/{slug}/
```

### Raw Source Data

| Slug | Source | Status | Path |
|------|--------|--------|------|
| `udel-climate-v501` | UDEL v5.01 temp+precip 1900-2017 | downloaded | `~/Dropbox/datasets/udel-climate-v501/` |
| `cru-ts-407` | CRU TS v4.07 tmp+pre 1901-2022 | downloaded | `~/Dropbox/datasets/cru-ts-407/` |
| `worldclim-v21-bio` | WorldClim v2.1 BIO+monthly 10arcmin | downloaded | `~/Dropbox/datasets/worldclim-v21-bio/` |
| `chirps-monthly-global` | CHIRPS v2 monthly NetCDF 1981-2023 | downloaded | `~/Dropbox/datasets/chirps-monthly-global/` |
| `era5-monthly-global` | ERA5 monthly (requires CDS API key) | pending | — |

### Built Panel Datasets

| Slug | Rows | Coverage | Source | Path |
|------|------|----------|--------|------|
| `global-country-climate-panel` | 365,328 | 258 countries, 1900-2017 monthly | UDEL v5.01 | `~/Dropbox/datasets/global-country-climate-panel/` |
| `worldclim-admin1-crosssection` | 4,596 | 4,596 admin1 units, climatology | WorldClim v2.1 | `~/Dropbox/datasets/worldclim-admin1-crosssection/` |
| `africa-country-climate-panel` | 27,720 | 55 countries, 1981-2022 monthly | CHIRPS+CRU TS | `~/Dropbox/datasets/africa-country-climate-panel/` |
| `us-county-climate-panel` | 4,923,701 | 3,108 counties, 1895-2024 monthly | nClimGrid | `~/Dropbox/datasets/us-county-climate-panel/` |
| `india-district-climate-panel` | TBD | ~730 districts, 1981-2022 monthly | IMD | `~/Dropbox/datasets/india-district-climate-panel/` |

Each built dataset includes 5 standard delivery files:
`data.csv` + `codebook.xlsx` + `README.md` + `version.json` + `report.pdf`

---

## 2. ERA5 Setup Checklist (First Time)

- [ ] Register at https://cds.climate.copernicus.eu/how-to-api
- [ ] Copy UID + API key to `~/.cdsapirc`
- [ ] `pip install cdsapi`
- [ ] Test: `python -c "import cdsapi; c = cdsapi.Client(); print('OK')"`
- [ ] First request: ERA5 monthly 2m_temperature, 1 year, global (~50 MB)

---

## 3. Scripts Reference

All scripts live in `~/maestro/maestro-skills/climate/scripts/`. Total: 13 scripts, 2,184 lines.

### Download Scripts

| Script | Lines | Purpose | Input | Output |
|--------|-------|---------|-------|--------|
| `download_chirps.py` | 87 | Download CHIRPS monthly NetCDF by year | Year range | `~/.maestro/cache/chirps-*.nc` |
| `download_era5.py` | 110 | Download ERA5 monthly via CDS API | Variable + year range | `~/.maestro/cache/era5_*.nc` |
| `download_imd.py` | 64 | Download IMD gridded data via imdlib | Variable + year range | IMD binary → NetCDF |
| `download_nclimgrid.py` | 88 | Download nClimGrid monthly county CSV | Year range | `~/.maestro/cache/nclimgrid/` |

### Processing Scripts

| Script | Lines | Purpose | Input | Output |
|--------|-------|---------|-------|--------|
| `udel_to_netcdf.py` | 162 | Convert UDEL ASCII tar.gz → NetCDF | `air_temp_2017.tar.gz` | `udel_tmp.nc` |
| `grid_to_admin.py` | 291 | Zonal stats: NetCDF/GeoTIFF → admin CSV | Raster + shapefile | `data_{var}.csv` |
| `fast_zonal_nc.py` | 159 | Fast zonal stats (pre-rasterized masks) | NetCDF + shapefile | `data_{var}.csv` |
| `parse_nclimgrid.py` | 203 | Parse nClimGrid county files → panel CSV | nClimGrid raw files | `data_{var}.csv` |
| `build_panel.py` | 183 | Merge variable CSVs → unified panel | Multiple CSVs | `data.csv` |

### Output Scripts

| Script | Lines | Purpose | Input | Output |
|--------|-------|---------|-------|--------|
| `validate_panel.py` | 167 | Data quality checks (missing, range, dups) | `data.csv` | PASS/FAIL report |
| `generate_codebook.py` | 227 | Variable definitions + summary stats | `data.csv` | `codebook.xlsx` |
| `generate_version_json.py` | 121 | Dataset metadata and provenance | `data.csv` | `version.json` |
| `generate_report_latex.py` | 322 | Quality audit report with charts | `data.csv` | `report.pdf` |

### Performance Notes

- `grid_to_admin.py`: uses `rasterstats.zonal_stats()` per time step. Suitable for small datasets (<500 time steps) or fine-grained admin units (districts).
- `fast_zonal_nc.py`: pre-rasterizes admin polygons once using `rasterio.features.rasterize()`, then uses numpy masking. ~100x faster for large NetCDF with many time steps. Used for global panel (1,416 months × 258 countries in 30 seconds vs estimated 24 hours).

---

## 4. Pricing Guide

### Pre-Built Climate Panels (ready to deliver)

| Dataset | Complexity | Price | Delivery |
|---------|-----------|-------|----------|
| Global Country Climate Panel (258 countries, 1900-2017) | L1 | $400 | Same day |
| WorldClim Admin1 Cross-Section (4,596 units) | L1 | $300 | Same day |
| Africa Country Climate Panel (55 countries, 1981-2022) | L1-L2 | $500 | Same day |
| US County Climate Panel (3,108 counties, 1895-2024) | L2 | $800 | Same day |
| India District Climate Panel (~730 districts, 1981-2022) | L2 | $800 | Same day |

### Custom Climate Panel Construction

| Tier | Scope | Price | Timeline |
|------|-------|-------|----------|
| L1 | Single source, single admin level, simple merge | $600-800 | 1-2 days |
| L2 | Multi-source merge, temporal harmonization | $1,200-1,600 | 3-5 days |
| L3 | Spatial join, boundary crosswalk, NLP/OCR fusion | $2,000-3,000 | 1-2 weeks |
| L4 | Interpolation with uncertainty, sensor drift correction | $3,000-5,000 | 2-4 weeks |

### Common Custom Requests

- Country-specific panel at admin2/admin3 level (district/municipality)
- Growing degree days (GDD) / heating-cooling degree days (HDD/CDD)
- Drought indices (SPEI, SPI) matched to admin units
- Population-weighted climate aggregation (GPW v4 weights)
- ERA5 hourly → daily panel with custom temporal aggregation
- Historical station data digitization + interpolation (pre-1950)

### Maintenance Subscriptions

- $600/mo: monthly incremental updates (new months appended)
- $1,200/mo: + quality monitoring (missing rate alerts, outlier detection)
- $2,000/mo: + priority SLA, custom variable additions
