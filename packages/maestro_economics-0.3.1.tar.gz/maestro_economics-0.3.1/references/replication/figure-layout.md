# Figure Layout Reference

Publication-quality figures for academic economics/statistics papers.

## Journal Sizing

Most economics journals use one of three figure widths:

| Slot | Width (inches) | figsize tuple | Min fontsize |
|------|---------------|---------------|--------------|
| Single column | 3.3–3.5 | `(3.5, 2.5)` | 7–8 pt |
| 1.5 column | 4.8–5.2 | `(5.0, 3.5)` | 8–9 pt |
| Double column | 6.5–7.2 | `(7.0, 4.5)` | 9–10 pt |
| Full page | 6.5 × 9.0 | `(6.5, 9.0)` | 10 pt |

AER/JPE/QJE use double-column text (6.5" wide). Most panel data papers
put maps and heatmaps at full double-column width.

## Matplotlib Global Settings

Apply at module level, before any plot call:

```python
import matplotlib
import matplotlib.pyplot as plt

FONTSIZE = 9   # adjust per target width

matplotlib.rcParams.update({
    'font.family':      'serif',       # matches LaTeX body font
    'font.size':        FONTSIZE,
    'axes.labelsize':   FONTSIZE,
    'axes.titlesize':   FONTSIZE,
    'xtick.labelsize':  FONTSIZE - 1,
    'ytick.labelsize':  FONTSIZE - 1,
    'legend.fontsize':  FONTSIZE - 1,
    'figure.dpi':       300,           # print quality
    'savefig.dpi':      300,
    'savefig.bbox':     'tight',
    'savefig.pad_inches': 0.05,
    'axes.linewidth':   0.6,
    'grid.linewidth':   0.4,
    'lines.linewidth':  1.0,
})
```

## Single vs Panel Mode Design

### Panel mode (2×4, 1×7, etc.)
- Use `constrained_layout=True` on `fig, axes = plt.subplots(...)`
- Shared colorbar via `ScalarMappable` on `ax=axes` (all axes)
- Title of each panel: year or decade label, fontsize = FONTSIZE, bold
- No axis frame labels repeated across panels (use `sharey=True` etc.)

### Single mode (one panel for paper)
- Use `fig, ax = plt.subplots(1, 1, figsize=FIGSIZE)`
- Add colorbar inside or to the right (not shared)
- Add full axis labels, legend if needed
- Output filename: `fig2a_temp_1990.png` (include the year/key in name)

```python
SINGLE_FIGSIZE = {
    'single_col':  (3.5, 3.0),
    'double_col':  (7.0, 5.0),
    'full_page':   (6.5, 8.0),
}

def get_figsize(mode='panel', target='double_col', nrows=2, ncols=4):
    if mode == 'single':
        return SINGLE_FIGSIZE[target]
    # panel: scale from double_col base
    w = SINGLE_FIGSIZE['double_col'][0]
    h = SINGLE_FIGSIZE['double_col'][1] * (nrows / 2)
    return (w * ncols / 4, h)
```

## Choropleth Maps (geopandas)

```python
# Single map
fig, ax = plt.subplots(1, 1, figsize=(3.5, 4.0), constrained_layout=True)
gdf.plot(column=var, cmap='coolwarm', vmin=vmin, vmax=vmax,
         ax=ax, legend=False,
         edgecolor='#888', linewidth=0.05,
         missing_kwds={'color': '#ddd', 'edgecolor': '#888', 'linewidth': 0.05})
ax.axis('off')
# colorbar
sm = mpl.cm.ScalarMappable(cmap='coolwarm', norm=mpl.colors.Normalize(vmin, vmax))
sm.set_array([])
cb = fig.colorbar(sm, ax=ax, orientation='horizontal',
                  fraction=0.05, pad=0.02, aspect=30)
cb.set_label(label, fontsize=FONTSIZE - 1)
cb.ax.tick_params(labelsize=FONTSIZE - 2)
```

Key tweaks vs default matplotlib:
- `linewidth=0.05` (thinner county borders, less ink)
- `edgecolor='#888'` (gray, not black)
- `missing_kwds color='#ddd'` (light gray, not white)

## Heatmaps (missingness, coverage)

```python
fig, ax = plt.subplots(figsize=(7.0, 1.8), constrained_layout=True)
im = ax.imshow(matrix, aspect='auto', cmap='YlOrRd', vmin=0, vmax=100,
               interpolation='nearest')
ax.set_xticks(range(ncols))
ax.set_xticklabels(col_labels, rotation=90, fontsize=6)
ax.set_yticks(range(nrows))
ax.set_yticklabels(row_labels, fontsize=FONTSIZE)
cb = fig.colorbar(im, ax=ax, orientation='vertical',
                  fraction=0.015, pad=0.01)
cb.set_label('% Missing', fontsize=FONTSIZE - 1)
cb.ax.tick_params(labelsize=FONTSIZE - 2)
```

## pgfplots Single-Panel Wrapper

Generated `.tex` files use `\begin{figure}[htbp]` and `width=0.22\textwidth`
(designed for 4-column groupplot). For single-panel use in a paper:

```latex
% In the paper's .tex file:
\begin{figure}[htbp]
\centering
\resizebox{0.45\textwidth}{!}{%    % 0.45 = single col; 0.9 = double col
  \begin{tikzpicture}
  \begin{axis}[
      width=8cm, height=6cm,
      xlabel={Temperature (\textdegree C)},
      ylabel={Frequency},
      xmin=-40, xmax=40,
      ybar interval,
      tick label style={font=\small},
      label style={font=\small},
      every axis plot/.append style={fill=blue!60, draw=black, line width=0.1pt},
  ]
  \addplot coordinates { ... };   % paste bin coords from panel .tex
  \end{axis}
  \end{tikzpicture}%
}
\caption{Daily average temperature distribution, 2000.}
\label{fig:temp_2000}
\end{figure}
```

For single-mode scripts that generate a standalone single-panel `.tex`,
structure: one `\begin{axis}...\end{axis}` (no groupplot).
Use `width=0.9\linewidth` so the figure adapts to the paper's column width.

## Color Palette (consistent across figures)

| Variable | Colormap | Notes |
|----------|----------|-------|
| Temperature | `coolwarm` | diverging, blue=cold, red=warm |
| Precipitation | `YlGnBu` | sequential, light=dry, dark=wet |
| Missingness | `YlOrRd` | sequential, yellow=0%, red=100% |
| Interpolation share | `RdYlGn_r` | green=direct, red=interpolated |
| Station/county counts | blue / red lines | dual axis, no fill |

## DPI and Format

| Use | Format | DPI |
|-----|--------|-----|
| Paper submission | PNG | 300 |
| Draft / review | PNG | 150 |
| pgfplots in LaTeX | .tex (vector) | N/A |
| Web / slides | PNG | 150 |
