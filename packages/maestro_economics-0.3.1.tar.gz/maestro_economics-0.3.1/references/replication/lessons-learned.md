# Lessons Learned: Replication Package Development

Bugs and pitfalls discovered during RAD-20260220-0004 (China weather panel).

---

## Python Compatibility

### `from __future__ import annotations` is mandatory for Python 3.9

Python 3.9 does not support PEP 604 union syntax (`int | None`) or built-in
generic aliases (`list[str]`, `dict[int, str]`) in function signatures or
variable annotations. These are only valid at runtime in 3.10+.

**Fix:** Add `from __future__ import annotations` as the first import in every
script. This makes all annotations strings (deferred evaluation), which works
on 3.9+.

**Affected patterns:**
```python
# Fails on 3.9 without __future__
def f(x: int) -> int | None: ...
counts: dict[int, int | None] = {}
years: list[tuple[str, int, int]] = []

# Works on 3.9 with __future__
from __future__ import annotations
def f(x: int) -> int | None: ...   # now OK
```

---

## pgfplots

### `bar width=Xpt` is not recognized in groupplot environment

`/pgfplots/bar width` is not propagated correctly in some pgfplots versions
when set in the outer `\begin{groupplot}[...]` options. The key is silently
ignored, producing bars with default width.

**Fix:** Use `ybar interval` instead of `ybar + bar width`. With `ybar interval`,
pgfplots computes bar width automatically from bin edge spacing:

```latex
% WRONG
ybar, bar width=1.5pt,

% CORRECT
ybar interval,
```

The `\addplot coordinates` data must be bin edges (N+1 points for N bars)
when using `ybar interval`. For pre-computed bin centers, convert:

```python
# When using ybar interval, pass (edge, count) pairs
edge_coords = " ".join(
    f"({e:.2f},{c})" for e, c in zip(edges, counts)
)
# Final edge with count=0 to close the last bar
edge_coords += f" ({edges[-1]:.2f},0)"
```

Alternatively, keep `ybar` (not interval) with:
```latex
\pgfplotsset{bar width=1.5pt}  % set globally before \begin{groupplot}
```

### `\\` in TikZ node causes "Not allowed in LR mode"

TikZ nodes default to LR (left-right) typesetting mode. In LR mode, `\\`
is not valid. This causes `! LaTeX Error: Not allowed in LR mode.`

**Fix:** Add `align=left` (or `align=center`) to the node options:

```latex
% WRONG
\node[font=\tiny, inner sep=2pt] at (rel axis cs:0.02,0.98) {
    $\mu = 15.2^\circ$C \\
    $\sigma = 8.1^\circ$C
};

% CORRECT
\node[font=\tiny, inner sep=2pt, align=left] at (rel axis cs:0.02,0.98) {
    $\mu = 15.2^\circ$C \\
    $\sigma = 8.1^\circ$C
};
```

`align=left` switches the node to paragraph mode, enabling `\\`.

### `\begin{figure}` cannot be nested inside another `\begin{figure}`

Generated `.tex` files (from Python scripts) contain a complete
`\begin{figure}[htbp]...\end{figure}` environment. When `\input`-ing these
into a LaTeX report, do NOT wrap them in another figure environment.

```latex
% WRONG
\begin{figure}[H]
\input{../output/figures/fig1a_temp_histograms.tex}   % already has \begin{figure}
\end{figure}

% CORRECT
\input{../output/figures/fig1a_temp_histograms.tex}   % direct \input in document body
```

---

## Data and Script Logic

### Dictionary covering year range must be verified against actual data

fig3 `_STATION_COUNTS_RAW` ended at `"2015-2017": 776`, but the data
extended to 2018. The DataFrame was built from `sorted(station_counts)`,
which stopped at 2017. The 2018 county count was computed but silently
discarded because there was no row in the DataFrame for year 2018.

**Prevention:** After building the year-keyed dict, assert:
```python
assert max(station_counts) == max(year for year in range(1951, 2019)
                                   if (DATA_DIR / f"{year}.csv").exists()), \
    "station_counts dict does not cover the full data range"
```

### Double CSV read per iteration (inefficient)

Checking which columns are available by reading the CSV header separately
from the data read doubles I/O:

```python
# WRONG: reads each file twice
df = pd.read_csv(path, usecols=[v for v in VARS if v in pd.read_csv(path, nrows=0).columns])

# CORRECT: read header once, reuse
available = set(pd.read_csv(path, nrows=0).columns)
df = pd.read_csv(path, usecols=[v for v in VARS if v in available])
```

### `config.py` must not contain absolute paths in delivered package

The delivered `config.py` should have placeholder strings, not absolute
paths from the development environment. If the paths are left as local
absolute paths (e.g., `~/Dropbox/weather-data-cleaning-xinming-du-20260207/`),
the client's machine will fail immediately on first run with `FileNotFoundError`.

**Correct delivered config:**
```python
DATA_DIR = Path("/path/to/your/weather-csvs")       # EDIT BEFORE RUNNING
SHAPEFILE_PATH = Path("/path/to/your/county.shp")   # EDIT BEFORE RUNNING
```

---

## LaTeX Report

### `tabularx` with long `\texttt` content overflows

`\texttt{...}` inside an `X` column of `tabularx` does not break at spaces
because monospace text disables line breaking. The entire `\texttt` span
is treated as a single non-breaking unit.

**Fix:** Use plain `tabular` (not `tabularx`) for tables with long monospace
content, or shorten the command text:

```latex
% WRONG: overflows at 201pt
\begin{tabularx}{\textwidth}{lX}
  Ubuntu & \texttt{sudo apt-get install gdal-bin libgdal-dev \&\& pip install geopandas} \\

% CORRECT: use tabular with abbreviated commands
\begin{tabular}{ll}
  Ubuntu & \texttt{apt-get install libgdal-dev \&\& pip install geopandas} \\
```

### Two-pass compilation required

Cross-references (`\ref{}`, `\label{}`), table of contents, and `lastpage`
package (`Page X of Y`) all require at least two compilation passes. The
first pass writes `.aux` files; the second pass reads them.

```bash
xelatex -interaction=nonstopmode report.tex   # pass 1
xelatex -interaction=nonstopmode report.tex   # pass 2
```

After the second pass, check for unresolved references:
```bash
grep "??" report.log   # unresolved \ref or \cite
```
