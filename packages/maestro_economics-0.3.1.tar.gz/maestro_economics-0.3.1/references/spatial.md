
# Maestro Data Spatial — Spatial Data Processing for Economic Research

## CLI Scripts (use these first — don't write boilerplate geopandas code)

All scripts live in `scripts/`. Run `python scripts/{name}.py --help` for full option list.

| Script | Purpose | Key flags |
|--------|---------|-----------|
| `spatial_join.py` | Point/polygon join, overlay, buffer | `--predicate within\|intersects\|nearest`, `--buffer-km`, `--area-weight`, `--overlay`, `--dissolve-by` |
| `spatial_interpolate.py` | IDW/Kriging/RBF from monitors to grid or polygon panel | `--method idw\|kriging\|rbf`, `--output-raster`, `--output-polygons`, `--polygons`, `--resolution-km` |
| `gee_extract.py` | GEE satellite extraction to CSV panel | `--band`, `--by-year`, `--by-month`, `--reducer`, `--merge-output`, `--no-monitor` |
| `crosswalk.py` | Area-weighted boundary reallocation | `--source-id`, `--target-id`, `--weights-in`, `--weights-out` |

### Quick examples

```bash
# 1. Point-in-polygon: assign county attributes to pollution monitors
python scripts/spatial_join.py monitors.csv counties.shp --output monitors_panel.csv

# 2. Nearest neighbor with distance cap
python scripts/spatial_join.py villages.shp districts.shp \
    --predicate nearest --max-distance 50000 --keep-cols district_id,district_name

# 3. Buffer points then join (monitors within 50km of each district)
python scripts/spatial_join.py monitors.shp districts.shp \
    --buffer-km 50 --predicate intersects

# 4. Area-weighted polygon-to-polygon
python scripts/spatial_join.py districts_old.shp districts_new.shp --area-weight

# 5. Geometric overlay (intersection)
python scripts/spatial_join.py zones.shp counties.shp \
    --overlay intersection --output zones_x_counties.geojson

# 6. Interpolate PM2.5 from 50 monitors to county panel (IDW)
python scripts/spatial_interpolate.py monitors.csv \
    --value-col pm25 --lat-col lat --lon-col lon \
    --method idw --power 2 --bandwidth-km 300 \
    --output-raster pm25_grid.tif --resolution-km 5 \
    --output-polygons counties_pm25.csv --polygons counties.shp \
    --year 2020

# 7. Kriging interpolation with raster output
python scripts/spatial_interpolate.py weather_stations.csv \
    --value-col temperature --method kriging --variogram spherical \
    --output-raster temp_grid.tif --resolution-km 10

# 8. GEE: extract ERA5 annual mean temperature, 2000-2023 panel
python scripts/gee_extract.py ECMWF/ERA5_LAND/MONTHLY counties.shp \
    --band temperature_2m --by-year 2000 2023 \
    --project my-gcp-project --output ./era5_exports/

# 9. GEE: extract VIIRS nightlights monthly panel
python scripts/gee_extract.py NOAA/VIIRS/DNB/MONTHLY_V21 districts.shp \
    --band avg_rad --by-month 2013-01 2023-12 \
    --project my-gcp-project --output ./viirs_exports/

# 10. GEE: merge downloaded CSVs into panel.csv
python scripts/gee_extract.py X X --merge-output --output ./era5_exports/

# 11. Boundary crosswalk: 1990 census -> 2010 boundaries
python scripts/crosswalk.py counties_1990.shp counties_2010.shp census_1990.csv \
    --source-id fips90 --target-id fips10 \
    --weights-out weights_90_10.csv --output census_2010_boundaries.csv
```

**References:**
- GEE pipeline patterns: [references/gee-pipeline.md](references/gee-pipeline.md)
- GeoPandas ecosystem: [references/geospatial-pipeline.md](references/geospatial-pipeline.md)
- Boundary datasets & crosswalks: [references/boundary-crosswalk.md](references/boundary-crosswalk.md)

---

## Overview

Four core operations covering most geospatial work in economics research.

| Operation | Problem | CLI |
|-----------|---------|-----|
| **Spatial Join** | Two datasets at different geographic units — how to match? | `spatial_join.py` |
| **Spatial Interpolation** | Point observations (monitors, stations) → grid or polygon panel | `spatial_interpolate.py` |
| **Raster Extraction** | Satellite/climate grid → administrative panel, multi-year | `gee_extract.py` |
| **Boundary Crosswalk** | Admin boundaries change over time — how to compare across years? | `crosswalk.py` |

**Critical pitfall across all four:** CRS mismatch. All scripts handle CRS alignment automatically.

---

## Operation 1: Spatial Join

**Problem**: Two datasets share geographic information but different spatial units. Pollution monitors (points) → counties (polygons). Villages (points) → districts (polygons). Oil wells (points) → census tracts (polygons).

### Standard Workflow

```python
import geopandas as gpd

# BOTH inputs MUST share same CRS
left_gdf = gpd.read_file("points.shp")
right_gdf = gpd.read_file("polygons.shp").to_crs(left_gdf.crs)

# Point-in-polygon (most common)
result = gpd.sjoin(left_gdf, right_gdf, how="left", predicate="within")
result = result.reset_index(drop=True)  # fix duplicate index

# Drop geometry for tabular output
panel = result.drop(columns=["geometry"])
panel.to_csv("output_panel.csv", index=False)
```

### Key Predicates

| Predicate | When to use |
|-----------|-------------|
| `within` | Points inside polygons (most common for monitors/stations) |
| `intersects` | Any overlap (roads crossing districts) |
| `sjoin_nearest` | Nearest neighbor with optional distance cap |

### Polygon-to-Polygon (Area-Weighted)

When matching two polygon datasets (e.g., historical districts → modern districts):

```python
# Intersect polygons
overlap = gpd.overlay(source_gdf, target_gdf, how="intersection")
overlap = overlap.to_crs(overlap.estimate_utm_crs())  # project for area calc

# Weight = intersection area / source area
source_gdf_proj = source_gdf.to_crs(overlap.crs)
source_gdf_proj["source_area"] = source_gdf_proj.geometry.area
overlap = overlap.merge(source_gdf_proj[["source_id", "source_area"]], on="source_id")
overlap["weight"] = overlap.geometry.area / overlap["source_area"]

# Weighted allocation
result = (overlap
    .assign(weighted_value=lambda x: x["population"] * x["weight"])
    .groupby("target_id")["weighted_value"].sum()
    .reset_index()
    .rename(columns={"weighted_value": "population_allocated"})
)
```

**Note on point-to-point nearest neighbor**: For joining point data to nearest point
(e.g., transactions to weather stations), use `geopandas.sjoin_nearest()` directly
rather than `spatial_join.py` (which is optimized for polygon joins).

```python
from geopandas import sjoin_nearest
joined = sjoin_nearest(points_gdf, stations_gdf, how="left", distance_col="distance_m")
```

Project to a metric CRS first (e.g., EPSG:3414 for Singapore) to get distances in meters.

### Performance Notes

- GeoPandas 1.0+ uses pyogrio (5-20x faster than fiona) — default, no config needed
- `use_arrow=True` for further 2-4x speedup on read
- For >1M features, use `dask-geopandas` for parallel processing
- Spatial index is automatic in sjoin/overlay; use `gdf.sindex` for custom queries

---

## Operation 2: Raster Extraction

**Problem**: Satellite or climate data comes as a spatial grid (raster). Need to extract values for each administrative unit (polygon) and build a panel dataset.

### Decision: GEE vs Local

| Factor | Use GEE | Use Local (xarray/rasterio) |
|--------|---------|----------------------------|
| Data location | Already in GEE catalog | Downloaded/proprietary |
| Area | Large (country/continent) | Small (region/city) |
| Time series | Long (decades) | Short |
| Custom algorithm | No | Yes |
| Reproducibility | Medium | High |

**GEE catalog covers most economics needs:** ERA5 (climate), MODIS (land use/NDVI), TROPOMI (air quality), CHIRPS (rainfall), VIIRS (nightlights, fires). Use GEE first.

### GEE Pipeline

```python
import ee

# Auth: service account (headless/production)
creds = ee.ServiceAccountCredentials("sa@proj.iam.gserviceaccount.com", "/path/key.json")
ee.Initialize(creds, project="my-gcp-project-id")

# Load satellite + boundaries
img = ee.ImageCollection("ECMWF/ERA5_LAND/MONTHLY") \
    .filter(ee.Filter.date("2020-01-01", "2020-12-31")) \
    .select("temperature_2m") \
    .mean()

regions = ee.FeatureCollection("FAO/GAUL/2015/level2")

# Zonal statistics
result = img.reduceRegions(
    collection=regions,
    reducer=ee.Reducer.mean().combine(ee.Reducer.stdDev(), sharedInputs=True),
    scale=9000  # match native resolution
)

# Export (avoid getInfo() on large collections → timeout)
task = ee.batch.Export.table.toDrive(
    collection=result.map(lambda f: ee.Feature(None, f.toDictionary())),  # drop geometry
    description="era5_temp_2020",
    folder="GEE_Exports",
    fileFormat="CSV"
)
task.start()
```

**Key GEE datasets for economics:**

| Dataset | ID | Resolution | Use |
|---------|----|-----------|-----|
| ERA5-Land | `ECMWF/ERA5_LAND/MONTHLY` | 9 km | Temperature, precipitation, soil moisture |
| MODIS NDVI | `MODIS/061/MOD13A3` | 1 km | Vegetation/crop yield proxy |
| MODIS Land Cover | `MODIS/061/MCD12Q1` | 500 m | Land use (IGBP 17 classes) |
| VIIRS Nightlights | `NOAA/VIIRS/DNB/MONTHLY_V21` | 500 m | Economic activity proxy |
| TROPOMI NO₂ | `COPERNICUS/S5P/NRTI_L3_NO2` | 1 km | Air quality / industrial activity |
| CHIRPS Rainfall | `UCSB-CHG/CHIRPS/DAILY` | 5 km | Precipitation |
| VIIRS FIRMS | `FIRMS` | 375 m | Fire detection |

See [references/gee-pipeline.md](references/gee-pipeline.md) for complete patterns including: batch tiling, task monitoring, throttled submission, histogram extraction (MODIS land cover), and the full MODIS pipeline template.

### Local Raster (xarray + rioxarray + exactextract)

For downloaded NetCDF/GeoTIFF files:

```python
import xarray as xr
import rioxarray  # noqa: F401 — adds .rio accessor
from exactextract import exact_extract
import geopandas as gpd

# Open NetCDF
ds = xr.open_dataset("era5_temp.nc")
ds_clipped = ds.rio.set_spatial_dims(x_dim="longitude", y_dim="latitude")
ds_clipped = ds_clipped.rio.write_crs("EPSG:4326")

# Export to GeoTIFF for exactextract
ds["t2m"].isel(time=0).rio.to_raster("temp_2020_01.tif")

# Zonal statistics (exactextract = more accurate than rasterstats)
districts = gpd.read_file("districts.shp")
result = exact_extract(
    "temp_2020_01.tif",
    districts,
    ["mean", "std", "count"],
    include_cols=["district_id"],
    output="pandas"
)
```

**exactextract vs rasterstats:**
- `exactextract`: C++ backend, handles fractional pixel coverage, production use
- `rasterstats`: Python, centroid-based, acceptable for exploration only

### Multi-Year Panel Construction

```python
from exactextract import exact_extract
import pandas as pd

panels = []
for year in range(2000, 2024):
    stats = exact_extract(
        f"nightlights_{year}.tif",
        districts,
        ["mean", "sum"],
        include_cols=["district_id"],
        output="pandas"
    )
    stats["year"] = year
    panels.append(stats)

panel = pd.concat(panels, ignore_index=True)
panel.to_csv("nightlights_panel.csv", index=False)
```

---

## Operation 3: Boundary Crosswalk

**Problem**: Administrative boundaries change between census years. Need to compare data across time when the geographic units themselves changed.

**Method**: Area-weighted interpolation — split old boundaries by new boundaries, weight each split piece by its area share, reallocate data proportionally.

### Assumption
Area-weighted crosswalk assumes uniform distribution of the variable within each source polygon. This is a simplification. For population data, use census-block-level weights (NHGIS) where available.

### Manual Python Crosswalk

```python
import geopandas as gpd
import pandas as pd

# Load source and target boundaries
source = gpd.read_file("districts_1990.shp")  # old boundaries
target = gpd.read_file("districts_2010.shp")  # new boundaries
data_1990 = pd.read_csv("census_1990.csv")    # data in old boundaries

# Project to equal-area for accurate area calculation
crs = source.estimate_utm_crs()
source_proj = source.to_crs(crs)
target_proj = target.to_crs(crs)

# Source areas
source_proj["source_area"] = source_proj.geometry.area

# Intersect
overlap = gpd.overlay(source_proj, target_proj, how="intersection")
overlap["intersection_area"] = overlap.geometry.area

# Merge source area + compute weight
overlap = overlap.merge(source_proj[["source_id", "source_area"]], on="source_id")
overlap["weight"] = overlap["intersection_area"] / overlap["source_area"]

# Merge census data
overlap = overlap.merge(data_1990, on="source_id")

# Allocate to target boundaries
result = (overlap
    .assign(population_allocated=lambda x: x["population"] * x["weight"])
    .groupby("target_id")["population_allocated"].sum()
    .reset_index()
)
```

### Boundary Datasets by Country

| Country | Dataset | Period | Notes |
|---------|---------|--------|-------|
| **China** | CHGIS (Harvard) | 221 BC–2019 | Historical dynasties + modern; shapefiles |
| **China (modern)** | GADM 4.1 | Current | Manual crosswalk for census year changes |
| **India** | SHRUG (Dev Data Lab) | 1990–2011 | Pre-built consistent village boundaries; no interpolation needed |
| **US** | NHGIS crosswalks | 1990–2020 | Pre-built area-weighted weights at block level |
| **Global** | GADM 4.1 | Current | 400k+ admin units, 5 levels, GeoPackage format |

### GADM Download Pattern

```python
from urllib.request import urlretrieve
import geopandas as gpd

# Country-specific download (IND = India, CHN = China, etc.)
url = "https://geodata.ucdavis.edu/gadm/gadm4.1/gpkg/gadm41_IND.gpkg"
urlretrieve(url, "gadm41_IND.gpkg")

gdf = gpd.read_file("gadm41_IND.gpkg", layer="ADM_ADM_2")  # district level
print(gdf.columns)  # GID_0, NAME_0, GID_1, NAME_1, GID_2, NAME_2, geometry
```

Cache in `~/dropbox/datasets/boundaries/gadm/` for reuse across projects.

### NHGIS (US Census Crosswalks)

Pre-built crosswalks available at https://www.nhgis.org/geographic-crosswalks for 1990, 2000, 2010, 2020 census years. Download CSV crosswalk tables + use population/housing weights appropriate for the variable being allocated.

---

## Common Pitfalls

### representative_point() vs centroid (CRS-Aware Centroids)

`GeoDataFrame.centroid` returns the geometric centroid, which can fall OUTSIDE the polygon
for concave or donut shapes. For geographic CRS (EPSG:4326), it also gives warnings and
inaccurate results. Always use `representative_point()` for geographic CRS:

```python
# WRONG — centroid outside polygon (concave shapes) + CRS warning for geographic CRS
gdf['lon'] = gdf.geometry.centroid.x
gdf['lat'] = gdf.geometry.centroid.y

# CORRECT — guaranteed inside polygon, CRS-aware
pt = gdf.geometry.representative_point()
gdf['lon'] = pt.x
gdf['lat'] = pt.y
```

Or reproject to UTM first if centroid accuracy matters:
```python
gdf_utm = gdf.to_crs(gdf.estimate_utm_crs())
gdf['area_km2'] = gdf_utm.geometry.area / 1e6
```

### GeoJSON Polygon vs MultiPolygon Geometry Indexing

GeoJSON has two geometry types with DIFFERENT coordinate structures. Assuming one type
when the other is present causes silent wrong values or IndexError.

```python
# GeoJSON Polygon:      coordinates[ring_idx][point_idx]
# GeoJSON MultiPolygon: coordinates[polygon_idx][ring_idx][point_idx]

# BUG: assumes MultiPolygon — crashes or gives single point for Polygon type
coords = feature["geometry"]["coordinates"][0][0]   # wrong for Polygon

# CORRECT: auto-detect by nesting depth
raw = feature["geometry"]["coordinates"][0]
coords = raw[0] if isinstance(raw[0][0], list) else raw  # Polygon or MultiPolygon outer ring
```

TypeScript equivalent:
```typescript
const rawCoords = feature.geometry.coordinates[0] ?? []
const coords = Array.isArray(rawCoords[0]?.[0]) ? rawCoords[0] : rawCoords
```

### IDW Vectorization (Never Triple Python Loop)

Triple nested Python loop for IDW is O(stations × cells × years) — extremely slow.
Use matrix-based IDW instead:

```python
# WRONG — 73s per year on 2k counties × 1k stations
for county in counties:
    for station in stations:
        weighted_sum += value[station] / dist[county, station]**2

# CORRECT — 7s per year using numpy matrix ops
# W[i, j] = 1 / dist[i, j]^2 (counties × stations)
vals_matrix = np.array([station_values])        # (1, n_stations)
valid_matrix = ~np.isnan(vals_matrix)           # mask
result = (vals_matrix @ W.T) / (valid_matrix @ W.T)  # (n_counties,)
```

---

## CRS Quick Reference

**The single most common source of silent errors in spatial work.**

| EPSG | Name | Use |
|------|------|-----|
| 4326 | WGS 84 | Storage, interchange, GPS (default) |
| 4490 | CGCS2000 | China government datasets — very similar to WGS84 but check |
| 3857 | Web Mercator | Web maps ONLY — NEVER use for area/distance |
| 6933 | EASE-Grid 2.0 | Global equal-area analysis |
| UTM (auto) | `gdf.estimate_utm_crs()` | Local area/buffer/distance |

```python
# Check CRS
print(gdf.crs)

# Reproject
gdf_wgs = gdf.to_crs("EPSG:4326")
gdf_utm = gdf.to_crs(gdf.estimate_utm_crs())  # auto UTM zone

# Declare (no transform) — use when source has no .prj
gdf = gdf.set_crs("EPSG:4326")
```

---

## Output Standard

All spatial projects deliver:
```
~/dropbox/{project}/
  raw/                        # immutable original files (shapefiles, GeoTIFF, NetCDF)
  data.csv                    # final panel (entity_id, year, [variables])
  README.md                   # source description, CRS notes, processing decisions
  codebook.xlsx               # variable definitions
  scripts/
    01_extract.py             # GEE or local extraction
    02_merge.py               # join + panel construction
    03_validate.py            # coverage checks
```

---

## Dependencies

```
# requirements-spatial.txt
geopandas>=1.1.0      # vector ops (uses pyogrio by default)
shapely>=2.0.0        # geometry operations
pyproj>=3.6.0         # CRS transformation
rasterio>=1.4.3       # raster I/O
rioxarray>=0.21.0     # raster + xarray integration
xarray>=2024.7.0      # multi-dim arrays (NetCDF/HDF5)
exactextract>=0.2.0   # accurate zonal stats (C++ backend)
earthengine-api>=1.0.0  # GEE Python API
rasterstats>=0.10.3   # simple zonal stats (exploration only)
```

Install: `pip install geopandas rasterio rioxarray xarray exactextract earthengine-api`

---

## Gotchas

- **CRS mismatch silent fail**: geopandas spatial joins with mismatched CRS return empty. Always `.to_crs(4326)` first.
- **GADM admin2 names not unique**: Use GID_2 not NAME_2 as join key.
- **exactextract requires matching CRS**: Raster and vector must share CRS or extraction silently fails.
- **CGCS2000 ≠ WGS84 for China data**: ~50m offset. Always reproject Chinese data.
