# GEE MODIS Land Cover Extraction Pipeline

## 1. Authentication

```python
# Interactive (notebook)
import ee
ee.Authenticate()  # first time: browser OAuth, cached at ~/.config/earthengine/
ee.Initialize(project='my-gcp-project-id')

# Service account (headless)
creds = ee.ServiceAccountCredentials('sa@proj.iam.gserviceaccount.com', '/path/key.json')
ee.Initialize(creds, project='my-gcp-project-id')

# Verify
print(ee.Image(1).getInfo())
```

SA requires: EE API enabled, roles `Earth Engine Resource Viewer` + `Service Usage Consumer`.

## 2. MODIS Land Cover Quick Reference

**Dataset**: `MODIS/061/MCD12Q1` | 500m | yearly 2001-2024

### Bands

| Band | Description |
|------|-------------|
| `LC_Type1` | IGBP (17 classes) -- primary choice |
| `LC_Type2` | UMD classification |
| `LC_Type3` | LAI classification |
| `LC_Prop1` | FAO-LCCS land cover |
| `LC_Prop1_Assessment` | Confidence % |
| `QC` | Quality flags |
| `LW` | Land/water mask |

### IGBP Classes (LC_Type1)

| Val | Class | Val | Class |
|-----|-------|-----|-------|
| 1 | Evergreen Needleleaf Forest | 10 | Grasslands |
| 2 | Evergreen Broadleaf Forest | 11 | Permanent Wetlands |
| 3 | Deciduous Needleleaf Forest | 12 | Croplands |
| 4 | Deciduous Broadleaf Forest | 13 | Urban/Built-up |
| 5 | Mixed Forests | 14 | Cropland/Veg Mosaic |
| 6 | Closed Shrublands | 15 | Snow/Ice |
| 7 | Open Shrublands | 16 | Barren |
| 8 | Woody Savannas | 17 | Water Bodies |
| 9 | Savannas | | |

### Load Single Year

```python
modis_lc = ee.ImageCollection('MODIS/061/MCD12Q1')
igbp_2020 = modis_lc.filter(
    ee.Filter.date('2020-01-01', '2020-12-31')
).first().select('LC_Type1')
```

## 3. Core Pattern: Polygon-Level Extraction

### frequencyHistogram (categorical data)

```python
result = igbp_2020.reduceRegions(
    collection=polygons,
    reducer=ee.Reducer.frequencyHistogram().unweighted(),
    scale=500,
    tileScale=4
)
# Output per feature: property 'LC_Type1' = {'1': 45, '5': 120, '12': 89}
```

`.unweighted()` = raw pixel counts. Without it you get area-weighted values.

### Map reduceRegion (more reliable for large FC)

```python
def extract_lc(feature):
    hist = igbp_img.reduceRegion(
        reducer=ee.Reducer.frequencyHistogram().unweighted(),
        geometry=feature.geometry(),
        scale=500,
        maxPixels=1e9,
        tileScale=4
    )
    return feature.set('lc_hist', hist.get('LC_Type1'))

results = polygons.map(extract_lc)
```

Use `map(reduceRegion)` when `reduceRegions()` hits memory errors.

### Area-based grouped reducer (alternative)

```python
pixel_area = ee.Image.pixelArea()
lc_with_area = pixel_area.addBands(igbp_img)
stats = lc_with_area.reduceRegion(
    reducer=ee.Reducer.sum().group(groupField=1, groupName='lc_class'),
    geometry=polygon, scale=500, maxPixels=1e10
)
```

## 4. Buffer Operations

```python
# Point -> circle polygon
point = ee.Geometry.Point([lon, lat])
buffered = point.buffer(100000)  # 100km radius, meters

# With accuracy control (fewer vertices = faster)
buffered = point.buffer(100000, maxError=1000)  # 1km tolerance

# Batch buffer a FeatureCollection
buffered_fc = points_fc.map(lambda f: f.buffer(100000))
```

## 5. Tile Strategy

### Split by batch index

```python
def split_fc_into_batches(fc, batch_size=500):
    total = fc.size().getInfo()
    fc_list = fc.toList(total)
    batches = []
    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)
        batches.append((start, ee.FeatureCollection(fc_list.slice(start, end))))
    return batches
```

WARNING: `toList(total)` loads all IDs into memory. For >100k features, use grid split.

### Split by spatial grid

```python
def create_grid(bounds, size_deg=10.0):
    min_lon, min_lat, max_lon, max_lat = bounds
    tiles = []
    lat = min_lat
    while lat < max_lat:
        lon = min_lon
        while lon < max_lon:
            tiles.append(ee.Geometry.Rectangle([
                lon, lat,
                min(lon + size_deg, max_lon),
                min(lat + size_deg, max_lat)
            ]))
            lon += size_deg
        lat += size_deg
    return tiles

# Filter polygons to tile
tile_polys = all_polygons.filterBounds(tile_geom)
```

### Recommended Batch Sizes

| Scenario | Batch Size | Reason |
|----------|-----------|--------|
| Simple reducer (mean/sum) | 1000-2000 | Low memory per feature |
| frequencyHistogram | 200-500 | Dict output is larger |
| Large buffers (100km) | 50-200 | Many pixels per polygon |
| Multi-band reduction | 100-500 | Memory scales with bands |

## 6. Batch Export + Task Monitoring

### Export.table.toDrive

```python
# Drop geometry for CSV (smaller files, no parsing issues)
def drop_geom(f):
    return ee.Feature(None, f.toDictionary())

task = ee.batch.Export.table.toDrive(
    collection=result.map(drop_geom),
    description=f'LC_{year}_{start}',
    folder='GEE_Exports',
    fileNamePrefix=f'lc_{year}_{start:05d}',
    fileFormat='CSV'
)
task.start()
```

Formats: `CSV`, `GeoJSON`, `KML`, `KMZ`, `SHP`, `TFRecord`.

### Task Monitor Loop

```python
import time

def monitor_tasks(tasks, interval=60):
    pending = list(tasks)
    while pending:
        still = []
        for t in pending:
            s = t.status()
            state, desc = s['state'], s.get('description', t.id)
            if state == 'COMPLETED':
                print(f'OK: {desc}')
            elif state == 'FAILED':
                print(f'FAIL: {desc} -- {s.get("error_message", "?")}')
            elif state != 'CANCELLED':
                still.append(t)
        pending = still
        if pending:
            print(f'{len(pending)} running...')
            time.sleep(interval)
    print('All done.')
```

### Throttled Submission

```python
def submit_throttled(tasks, delay=2.0, max_queued=50):
    submitted = []
    for i, task in enumerate(tasks):
        while True:
            active = [t for t in submitted if t.status()['state'] in ('READY', 'RUNNING')]
            if len(active) < max_queued:
                break
            time.sleep(30)
        task.start()
        submitted.append(task)
        time.sleep(delay)
    return submitted
```

### Task States

`UNSUBMITTED` -> `READY` -> `RUNNING` -> `COMPLETED` | `FAILED` | `CANCELLED`

## 7. Download + Merge Results

Target: `~/Dropbox/{project}/`

### Download from Google Drive

```python
# Option A: PyDrive2
from pydrive2.auth import GoogleAuth
from pydrive2.drive import GoogleDrive
gauth = GoogleAuth(); gauth.LocalWebserverAuth()
drive = GoogleDrive(gauth)
for f in drive.ListFile({'q': "title contains 'lc_'"}).GetList():
    f.GetContentFile(f'~/Dropbox/myproject/raw/{f["title"]}')

# Option B: gdown (shared folder)
# gdown --folder https://drive.google.com/drive/folders/FOLDER_ID -O ~/Dropbox/myproject/raw/

# Option C: GCS export + gsutil
# gsutil -m cp gs://bucket/exports/lc_* ~/Dropbox/myproject/raw/
```

### Merge + Parse Histograms

```python
import pandas as pd, glob, ast
from pathlib import Path

OUT = Path.home() / 'Dropbox' / 'myproject'
files = sorted(glob.glob(str(OUT / 'raw' / 'lc_*.csv')))
df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)

# Parse histogram string -> dict -> columns
df['_hist'] = df['lc_hist'].apply(lambda x: ast.literal_eval(x) if pd.notna(x) else {})
hist_df = df['_hist'].apply(pd.Series).fillna(0).astype(int)
hist_df.columns = [f'lc_class_{c}' for c in hist_df.columns]

result = pd.concat([df.drop(columns=['lc_hist', '_hist']), hist_df], axis=1)
result.to_csv(OUT / 'modis_lc_complete.csv', index=False)
print(f'Merged {len(files)} files -> {len(result)} rows, {result.shape[1]} cols')
```

## 8. Common Pitfalls

| # | Pitfall | Symptom | Fix |
|---|---------|---------|-----|
| 1 | `getInfo()` on large FC | "5000 elements" error | Export to Drive instead |
| 2 | Interactive timeout | "Computation timed out" after 5min | Use batch Export (10-day limit) |
| 3 | `reduceRegions` on large FC | "Computed value is too large" | Map `reduceRegion` per feature, or reduce batch size |
| 4 | Wrong `scale` param | Slow, memory errors, resampling | Use native resolution: 500m for MODIS |
| 5 | Python closure in loop | All results use last iteration's value | Factory function: `def make_fn(img, yr): ...` |
| 6 | Missing `.unweighted()` | Unexpected histogram values | Always chain `.unweighted()` for pixel counts |
| 7 | Too many queued tasks | "Too many pending tasks" | Cap at <3000 tasks, throttle submission |
| 8 | No `tileScale` | Memory errors on large polygons | Start `tileScale=4`, increase to 16 if needed |
| 9 | Exporting geometry in CSV | Huge files, WKT parsing pain | `ee.Feature(None, f.toDictionary())` to drop geometry |
| 10 | MODIS date filter too narrow | Empty collection, null results | Full year range: `'{y}-01-01'` to `'{y}-12-31'` |

## 9. Performance Checklist

- [ ] Filter early: spatial + temporal filters BEFORE computation
- [ ] Select only needed bands: `.select('LC_Type1')` not full image
- [ ] Scale = native resolution (500m MODIS) to avoid resampling
- [ ] `tileScale=4` minimum; increase to 8/16 on memory errors
- [ ] `map(reduceRegion)` over `reduceRegions` for >500 features
- [ ] Drop geometry in CSV exports to reduce file size
- [ ] Throttle task submission: 2s delay, max 50 queued
- [ ] Incremental saves: skip already-exported batches

## 10. Full Pipeline Template

```python
#!/usr/bin/env python3
"""
MODIS Land Cover Extraction Pipeline.
Usage: customize PROJECT, YEARS, BATCH_SIZE, ASSET_ID, then run.
Output: CSV files in ~/Dropbox/{PROJECT}/raw/, merged in parent dir.
"""
import ee, time, ast, glob
import pandas as pd
from pathlib import Path

# -- CONFIG --
PROJECT = 'my-gcp-project-id'
ASSET_ID = 'projects/my-project/assets/study_polygons'
YEARS = list(range(2001, 2023))
BATCH_SIZE = 300
BAND = 'LC_Type1'
DRIVE_FOLDER = 'GEE_Exports'
LOCAL_DIR = Path.home() / 'Dropbox' / 'myproject'

# -- INIT --
ee.Initialize(project=PROJECT)
polygons = ee.FeatureCollection(ASSET_ID)
total = polygons.size().getInfo()
fc_list = polygons.toList(total)
print(f'Polygons: {total}, Years: {len(YEARS)}, Batch: {BATCH_SIZE}')

# -- EXTRACT + EXPORT --
all_tasks = []

def make_extractor(image, band, yr):
    """Factory to avoid Python closure pitfall."""
    def fn(feature):
        hist = image.reduceRegion(
            reducer=ee.Reducer.frequencyHistogram().unweighted(),
            geometry=feature.geometry(),
            scale=500, maxPixels=1e9, tileScale=4
        )
        return ee.Feature(None, feature.toDictionary()).set(
            'lc_hist', hist.get(band)
        ).set('year', yr)
    return fn

for year in YEARS:
    img = ee.ImageCollection('MODIS/061/MCD12Q1').filter(
        ee.Filter.date(f'{year}-01-01', f'{year}-12-31')
    ).first().select(BAND)

    for start in range(0, total, BATCH_SIZE):
        end = min(start + BATCH_SIZE, total)
        batch = ee.FeatureCollection(fc_list.slice(start, end))
        result = batch.map(make_extractor(img, BAND, year))

        task = ee.batch.Export.table.toDrive(
            collection=result,
            description=f'LC_{year}_{start:05d}',
            folder=DRIVE_FOLDER,
            fileNamePrefix=f'lc_{year}_{start:05d}',
            fileFormat='CSV'
        )
        task.start()
        all_tasks.append(task)
        time.sleep(1)

    print(f'Year {year}: {len(range(0, total, BATCH_SIZE))} tasks submitted')

# -- MONITOR --
pending = list(all_tasks)
while pending:
    still = []
    for t in pending:
        s = t.status()
        state = s['state']
        if state == 'COMPLETED':
            print(f'  OK: {s["description"]}')
        elif state == 'FAILED':
            print(f'  FAIL: {s["description"]} -- {s.get("error_message", "?")}')
        elif state != 'CANCELLED':
            still.append(t)
    pending = still
    if pending:
        print(f'[{time.strftime("%H:%M")}] {len(pending)} tasks remaining...')
        time.sleep(120)
print('All export tasks finished.')

# -- MERGE (run after downloading CSVs to LOCAL_DIR/raw/) --
# raw_dir = LOCAL_DIR / 'raw'
# files = sorted(glob.glob(str(raw_dir / 'lc_*.csv')))
# df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
# df['_hist'] = df['lc_hist'].apply(lambda x: ast.literal_eval(x) if pd.notna(x) else {})
# hist_df = df['_hist'].apply(pd.Series).fillna(0).astype(int)
# hist_df.columns = [f'lc_class_{c}' for c in hist_df.columns]
# result = pd.concat([df.drop(columns=['lc_hist', '_hist']), hist_df], axis=1)
# result.to_csv(LOCAL_DIR / 'modis_lc_complete.csv', index=False)
# print(f'Merged: {len(files)} files -> {len(result)} rows')
```

### Quota Reference

| Limit | Value | Adjustable |
|-------|-------|------------|
| Concurrent batch tasks | ~2/user | Yes |
| Pending task queue | 3000/project | No |
| Interactive timeout | ~5 min | No |
| Batch task lifetime | 10 days | No |
| Max cached aggregation | 100 MiB | No |
| Request rate | 100 req/s | Yes |
