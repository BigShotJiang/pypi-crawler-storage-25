
# Maestro Urban History — Historical City Map Digitization SOP

## When to Use

- Digitizing historical city maps (paper scans) into spatial panel data for econometrics
- War damage assessment (Hiroshima/Nagasaki/Tokyo 1945-1950)
- HOLC redlining maps (1930s USA)
- Republican-era Chinese city maps (1920s-1940s)
- Colonial survey maps (Singapore, Hong Kong, Malaya)
- Sanborn fire insurance maps (USA 1867-1970)

## When NOT to Use

- Modern satellite imagery → `maestro-data-spatial`
- Already-digitized vectors (e.g., HOLC from Richmond DSL) → download directly
- Admin boundaries without map digitization → GADM / CHGIS

## Core Workflow

```
Scan → Preprocess → GCP Select → Georeference → Extract → Encode → Crosswalk → QC → Deliver
```

1. **Preprocess**: Denoise, CLAHE contrast, deskew, DPI standardize (min 300)
2. **GCP Selection** (AI-assisted, ~15 min vs 2-4 hrs manual):
   - Path A: LightGlue feature matching against modern satellite
   - Path B: VLM place-name extraction + Geocoding API
   - Merge → RANSAC → spatial uniform grid → manual confirm
3. **Georeferencing**: `gdal_translate` (GCPs) → `gdalwarp -tps` (Thin Plate Spline)
4. **Feature Extraction**: Color segmentation (HSV + morphology) or VLM tiles → vectorize
5. **Attribute Encoding**: area_m2, damage_grade (0-4), landuse_code, building_density
6. **Boundary Crosswalk**: Area-weighted or density-weighted interpolation
7. **QC**: RMS check, topology, literature cross-validation

→ See [references/preprocessing.md](references/preprocessing.md) for scan preprocessing code.
→ See [references/georeferencing.md](references/georeferencing.md) for GCP and GDAL warping.
→ See [references/extraction.md](references/extraction.md) for color segmentation and vectorization.
→ See [references/crosswalk.md](references/crosswalk.md) for boundary matching functions.
→ See [references/quality-control.md](references/quality-control.md) for QC functions and checklists.
→ See [references/data-sources.md](references/data-sources.md) for country-specific map archives.

## Key Rules

1. **Always TPS** for historical maps — affine cannot model non-uniform paper deformation
2. **Never fixed HSV** — calibrate from legend color patches on each scan
3. **GCPs spatially uniform** — force 3x3 grid, don't cluster in city center
4. **Best anchors**: river confluences > coastline corners > rail crossings > road junctions
5. **Avoid as anchors**: buildings, vegetation, straight coastlines (landfill drift)

## Gotchas

| Problem | Cause | Fix |
|---------|-------|-----|
| Japan pre-war map ~400m offset | Tokyo Datum vs WGS84 | Convert from EPSG:4301 |
| Singapore map offset | Kertau 1948 / SVY21 | Use EPSG:3414 |
| Area calculation wrong | Computing in EPSG:4326 | Project to UTM first |
| Color segmentation unstable | Scanner white balance | Calibrate from legend per scan |
| Coastline GCPs drift | Landfill | Exclude landfill coastline |
| Edge distortion | Affine used instead of TPS | Must use TPS |
| Polygon fragments | Vectorization noise | `min_area_px` + morphology |

## RMS Error Targets

| Granularity | Target | Use case |
|-------------|--------|----------|
| Block-level | < 10 m | Most urban econ research |
| Building-level | < 3 m | Sanborn, cadastral |
| Regional | < 50 m | Military maps |

## Dependencies

```
opencv-python>=4.8.0, numpy, geopandas>=1.1.0, rasterio>=1.4.3
shapely>=2.0.0, GDAL>=3.7.0, torch>=2.0.0, lightglue>=0.0.1
exactextract>=0.2.0, scikit-image>=0.21.0
```
