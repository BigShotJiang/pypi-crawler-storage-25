# Environmental Quality Composite Index -- Detailed Reference

## Multi-dimensional Synthesis

In urban economics, multiple environmental variables are often combined into a composite index or entered as a control variable group.

```python
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

def environmental_quality_index(panel_df, env_cols, method='pca'):
    """
    Build environmental quality composite index.

    Parameters:
        panel_df: panel data (zone_id x year)
        env_cols: env variable column names
            e.g.: ['ndvi_mean', 'pm25_mean', 'twi_mean', 'noise_index', 'uhi_day']
        method: 'pca' or 'equal_weight'

    Note: pm25, noise_index, twi, uhi are "bad" (higher = worse),
          ndvi is "good" (higher = better). Must unify direction.
    """
    df = panel_df[env_cols].copy()

    # Unify direction: make all "higher = better"
    bad_vars = ['pm25_mean', 'noise_index', 'twi_mean', 'uhi_day', 'uhi_night']
    for col in bad_vars:
        if col in df.columns:
            df[col] = -df[col]

    scaler = StandardScaler()
    df_scaled = pd.DataFrame(
        scaler.fit_transform(df),
        columns=df.columns,
        index=df.index
    )

    if method == 'pca':
        pca = PCA(n_components=1)
        panel_df['env_quality_index'] = pca.fit_transform(df_scaled).flatten()
        print(f"PCA explained variance: {pca.explained_variance_ratio_[0]:.3f}")
        print(f"PCA loadings: {dict(zip(env_cols, pca.components_[0].round(3)))}")
    else:
        panel_df['env_quality_index'] = df_scaled.mean(axis=1)

    return panel_df
```

## Standard Economics Panel Output

```
zone_id | year | month | ndvi_mean | pm25_mean | uhi_day | twi_mean | noise_index | env_quality_index
PZ_01   | 2020 | 06    | 0.42      | 28.4      | 3.1     | 8.4      | 67.3        | 0.34
PZ_01   | 2020 | 07    | 0.45      | 25.1      | 3.5     | 8.4      | 67.3        | 0.41
```

## References

### UHI
- Zhou, D., et al. (2019). "Satellite remote sensing of surface urban heat islands." *Remote Sensing*.
- Clinton, N., Gong, P. (2013). "MODIS detected surface urban heat islands." *Remote Sensing of Environment*.

### NDVI / Greenery
- Zheng, S., et al. (2019). "Air pollution lowers Chinese urbanites' expressed happiness on social media." *Nature Human Behaviour*.

### PM2.5
- van Donkelaar, A., et al. (2021). "Monthly Global Estimates of Fine Particulate Matter." *Environmental Science & Technology*.
- Hammer, M.S., et al. (2020). "Global annual PM2.5 grids from MODIS, MISR and SeaWiFS." *Environmental Science & Technology*.

### Flood
- Tellman, B., et al. (2021). "Satellite imaging reveals increased proportion of population exposed to floods." *Nature*.
- Bates, P.D., et al. (2021). "Combined modeling of US fluvial, pluvial, and coastal flood hazard." *Water Resources Research*.

### Environmental Premium
- Chay, K.Y., Greenstone, M. (2005). "Does air quality matter? Evidence from the housing market." *Journal of Political Economy*.
- Currie, J., et al. (2015). "Environmental health risks and housing values." *Journal of Environmental Economics and Management*.
