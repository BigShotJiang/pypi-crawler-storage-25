# Noise Exposure (Proxy Variables) -- Detailed Reference

## Data Situation

No globally consistent noise map exists. European cities have partial EEA Noise Directive data; elsewhere use proxy variables.

## Proxy Variable Construction

| Proxy | Data Source | Method |
|-------|-----------|--------|
| Road traffic noise | OSM road network | Road density x class weight (motorway=10, primary=5, secondary=3, tertiary=2, residential=1) |
| Airport noise | OSM / OurAirports | Distance to nearest airport + runway buffer |
| Railway noise | OSM railway | Distance to nearest railway |

## OSM Road Density

```python
import osmnx as ox
import geopandas as gpd
import numpy as np

def road_noise_proxy(place_name, admin_zones):
    """
    Road-class weighted noise proxy from OSM.

    Weights:
        motorway/trunk: 10, primary: 5, secondary: 3,
        tertiary: 2, residential: 1, living_street: 0.5
    """
    G = ox.graph_from_place(place_name, network_type='drive')
    edges = ox.graph_to_gdfs(G, nodes=False)

    weight_map = {
        'motorway': 10, 'motorway_link': 8, 'trunk': 10, 'trunk_link': 8,
        'primary': 5, 'primary_link': 4,
        'secondary': 3, 'secondary_link': 2,
        'tertiary': 2, 'tertiary_link': 1,
        'residential': 1, 'living_street': 0.5,
        'unclassified': 1,
    }

    def get_weight(highway):
        if isinstance(highway, list):
            highway = highway[0]
        return weight_map.get(highway, 1)

    edges['weight'] = edges['highway'].apply(get_weight)
    edges['weighted_length'] = edges['length'] * edges['weight']

    edges_proj = edges.to_crs(admin_zones.crs)
    joined = gpd.sjoin(edges_proj, admin_zones, how='inner', predicate='intersects')

    noise_proxy = (joined.groupby('zone_id')
                   .agg(
                       road_density_km=('length', lambda x: x.sum() / 1000),
                       weighted_road_density=('weighted_length', lambda x: x.sum() / 1000),
                       n_motorway_km=('length', lambda x: x[joined.loc[x.index, 'weight'] >= 8].sum() / 1000),
                   )
                   .reset_index())

    wrd = noise_proxy['weighted_road_density']
    noise_proxy['noise_index'] = ((wrd - wrd.min()) / (wrd.max() - wrd.min()) * 100).round(1)

    return noise_proxy
```

## Distance Decay

```python
from shapely.ops import nearest_points

def distance_to_infrastructure(admin_zones, infra_gdf, infra_type='airport'):
    """
    Distance from zone centroids to nearest infrastructure (airport/railway).
    Uses simplified 6 dB per doubling decay model.
    """
    centroids = admin_zones.copy()
    centroids['geometry'] = centroids.geometry.centroid

    lon = centroids.geometry.x.mean()
    utm_zone = int((lon + 180) / 6) + 1
    utm_crs = f'EPSG:326{utm_zone:02d}' if centroids.geometry.y.mean() >= 0 else f'EPSG:327{utm_zone:02d}'

    centroids_proj = centroids.to_crs(utm_crs)
    infra_proj = infra_gdf.to_crs(utm_crs)

    from shapely.ops import unary_union
    infra_union = unary_union(infra_proj.geometry)

    centroids_proj[f'dist_{infra_type}_m'] = centroids_proj.geometry.apply(
        lambda pt: pt.distance(infra_union)
    )

    centroids_proj[f'{infra_type}_noise_proxy'] = np.maximum(
        0, 80 - 20 * np.log10(centroids_proj[f'dist_{infra_type}_m'].clip(lower=100) / 100)
    )

    return centroids_proj[['zone_id', f'dist_{infra_type}_m', f'{infra_type}_noise_proxy']]
```

## European Cities: EEA Noise Map

```
# European Environment Agency (EEA) Noise Directive data
# Coverage: EU major cities (pop > 100k)
# Indicators: Lden (day-evening-night), Lnight (night)
# Resolution: building-level (some cities provide GIS layers)
# Access: https://www.eea.europa.eu/themes/human/noise/noise-2
# Format: per-country Shapefile/GeoPackage (not unified)
# Quality varies by country. Germany, Netherlands most complete. Eastern Europe low reporting.
```

## Output Panel Format

```
zone_id | road_density_km | weighted_road_density | noise_index | dist_airport_m | airport_noise_proxy
PZ_01   | 45.2            | 128.5                 | 67.3        | 3200           | 49.9
```

## Gotchas

- **OSM completeness**: Developing country road networks are incomplete. OSM road density OK for cross-section, not panel (changes).
- **Traffic volume missing**: OSM has no traffic volume. Weights are road-class only -- rough proxy.
- **Noise decay model**: 6 dB/doubling is idealized. Building obstruction/reflection makes real decay non-linear.
- **Proxy bias**: Road density != noise exposure. Papers must discuss measurement error; consider IV.
