# Urban Heat Island (UHI) — Detailed Reference

## Data Sources

| Dataset | Resolution | Time | Frequency | Access |
|---------|-----------|------|-----------|--------|
| MODIS MOD11A1 (Terra) | 1km | 2000-now | Daily | earthaccess / AppEEARS / GEE |
| MODIS MYD11A1 (Aqua) | 1km | 2002-now | Daily | earthaccess / AppEEARS / GEE |
| Landsat 8/9 TIR | 100m (resampled 30m) | 2013-now | 16-day | GEE / USGS EarthExplorer |
| ECOSTRESS | 70m | 2018-now | Irregular | earthaccess / AppEEARS |

**Preferred: MODIS MOD11A1** -- global coverage, daily, 20+ years, economics paper standard.

## Acquisition -- earthaccess (recommended)

```python
import earthaccess
import xarray as xr
from pathlib import Path

# Auth (first time needs NASA Earthdata account)
earthaccess.login(persist=True)

# Search MODIS LST
results = earthaccess.search_data(
    short_name="MOD11A1",    # Terra daily LST
    temporal=("2015-01-01", "2023-12-31"),
    bounding_box=(103.6, 1.15, 104.1, 1.47),  # Singapore
    count=5000
)

# Download to cache
cache_dir = Path("~/.maestro/cache/modis_lst_sg").expanduser()
cache_dir.mkdir(parents=True, exist_ok=True)
files = earthaccess.download(results, str(cache_dir))
```

## Acquisition -- Google Earth Engine

```python
import ee
ee.Initialize(project='your-gcp-project')

# MODIS LST daily
lst = (ee.ImageCollection('MODIS/061/MOD11A1')
       .filterDate('2015-01-01', '2023-12-31')
       .select(['LST_Day_1km', 'LST_Night_1km', 'QC_Day']))

# Convert to Celsius (raw value x 0.02 - 273.15)
def to_celsius(img):
    day = img.select('LST_Day_1km').multiply(0.02).subtract(273.15).rename('LST_day_C')
    night = img.select('LST_Night_1km').multiply(0.02).subtract(273.15).rename('LST_night_C')
    return img.addBands([day, night]).copyProperties(img, ['system:time_start'])

lst_c = lst.map(to_celsius)

# Monthly composite (median, cloud-masked)
months = ee.List.sequence(1, 12)
years = ee.List.sequence(2015, 2023)

def monthly_composite(ym):
    y = ee.Number(ym).divide(100).floor()
    m = ee.Number(ym).mod(100)
    start = ee.Date.fromYMD(y, m, 1)
    end = start.advance(1, 'month')
    return (lst_c.filterDate(start, end)
            .median()
            .set('year', y, 'month', m, 'system:time_start', start.millis()))

ym_list = years.map(lambda y: months.map(lambda m: ee.Number(y).multiply(100).add(m))).flatten()
monthly = ee.ImageCollection.fromImages(ym_list.map(monthly_composite))
```

## UHI Calculation

```python
import geopandas as gpd
import numpy as np
from rasterstats import zonal_stats

def compute_uhi(lst_raster, urban_mask, rural_buffer_shp, admin_zones):
    """
    UHI = LST_urban - LST_rural_buffer

    Parameters:
        lst_raster: GeoTIFF LST file
        urban_mask: Urban built-up mask (GHSL or MODIS MCD12Q1)
        rural_buffer_shp: Non-urban polygons within 10-30km buffer
        admin_zones: Admin boundary shapefile (for aggregation)
    """
    urban_stats = zonal_stats(
        admin_zones, lst_raster,
        stats=['mean', 'median', 'std'],
        categorical=False, all_touched=True, geojson_out=False,
    )
    rural_stats = zonal_stats(
        rural_buffer_shp, lst_raster, stats=['mean'],
    )
    return urban_stats, rural_stats
```

## Urban Built-up Masks

| Dataset | Resolution | Use Case |
|---------|-----------|----------|
| GHSL-BUILT-S R2023A | 10m/100m | Global urban, 1975-2030 |
| MODIS MCD12Q1 LC_Type1 | 500m | Match MODIS LST resolution |
| ESA WorldCover 2021 | 10m | High-precision land use |

```python
# GEE: GHSL built-up
ghsl = ee.Image('JRC/GHSL/P2023A/GHS_BUILT_S/2020').select('built_surface')
urban_mask = ghsl.gt(50)

# GEE: MODIS land use (class 13 = Urban)
lulc = ee.Image('MODIS/061/MCD12Q1/2020_01_01').select('LC_Type1')
urban_modis = lulc.eq(13)
```

## Output Panel Format

```
city_id | year | month | LST_day_mean | LST_night_mean | UHI_day | UHI_night | n_valid_pixels
SG_01   | 2020 | 07    | 34.2         | 26.8           | 3.1     | 2.4       | 892
```

## Gotchas

- **Cloud masking**: MODIS LST has strict cloud mask; tropical cities have sparse valid pixels. Fix: monthly median composite.
- **Overpass time bias**: Terra 10:30/22:30, Aqua 13:30/01:30. Day/night UHI must be computed separately.
- **Spatial mismatch**: MODIS 1km pixels mix urban/rural signal at city edges. Exclude edge zones.
- **Temperature units**: MODIS LST raw = K x 50 (need x 0.02 then - 273.15). Common error: forgetting scale factor.
- **QC filtering**: Must use QC_Day/QC_Night band to filter low-quality pixels (bit 0-1 = 00 is good quality).
