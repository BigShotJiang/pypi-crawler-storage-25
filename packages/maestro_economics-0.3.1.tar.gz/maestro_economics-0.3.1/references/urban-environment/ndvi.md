# Urban Greenery (NDVI / Tree Canopy) -- Detailed Reference

## Data Sources

| Dataset | Resolution | Time | Frequency | Use Case |
|---------|-----------|------|-----------|----------|
| Sentinel-2 L2A | 10m | 2017-now | 5-day | Block-level fine-grained greenery |
| Landsat 8/9 | 30m | 2013-now | 16-day | Long time series, postal zone level |
| MODIS MOD13Q1 | 250m | 2000-now | 16-day | Coarse trend analysis |

**Preferred: Sentinel-2** (urban research needs 10m). **Long time series: Landsat**.

## NDVI Calculation -- GEE

```python
import ee
ee.Initialize(project='your-gcp-project')

# Sentinel-2 NDVI
s2 = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
      .filterDate('2020-01-01', '2023-12-31')
      .filterBounds(ee.Geometry.Rectangle([103.6, 1.15, 104.1, 1.47]))
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)))

def add_ndvi(img):
    ndvi = img.normalizedDifference(['B8', 'B4']).rename('NDVI')
    return img.addBands(ndvi)

s2_ndvi = s2.map(add_ndvi)

# Quarterly composite
def quarterly_ndvi(year, quarter):
    start_month = (quarter - 1) * 3 + 1
    start = ee.Date.fromYMD(year, start_month, 1)
    end = start.advance(3, 'month')
    return (s2_ndvi.filterDate(start, end)
            .select('NDVI')
            .median()
            .set('year', year, 'quarter', quarter))
```

## Landsat NDVI (Long Time Series)

```python
# Landsat 8/9 Collection 2 Level-2 (Surface Reflectance)
l89 = (ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
       .merge(ee.ImageCollection('LANDSAT/LC09/C02/T1_L2'))
       .filterDate('2013-01-01', '2023-12-31')
       .filterBounds(study_area)
       .filter(ee.Filter.lt('CLOUD_COVER', 20)))

def landsat_ndvi(img):
    # Landsat C2 L2: SR bands need scaling: value * 0.0000275 - 0.2
    nir = img.select('SR_B5').multiply(0.0000275).add(-0.2)
    red = img.select('SR_B4').multiply(0.0000275).add(-0.2)
    ndvi = nir.subtract(red).divide(nir.add(red)).rename('NDVI')
    return img.addBands(ndvi)

l89_ndvi = l89.map(landsat_ndvi)
```

## Derived Indicators

```python
import numpy as np
from rasterstats import zonal_stats

def green_indicators(ndvi_raster, admin_zones, population_raster=None):
    """
    From NDVI raster compute urban greenery indicators.

    Returns per zone:
        ndvi_mean, ndvi_median
        tree_cover_pct: canopy coverage (NDVI > 0.3 pixel ratio)
        green_area_km2: green area (NDVI > 0.2 pixel area)
        green_per_capita: per-capita green area (needs population raster)
    """
    stats = zonal_stats(
        admin_zones, ndvi_raster,
        stats=['mean', 'median', 'count'],
        add_stats={
            'tree_cover_pct': lambda x: np.nanmean(x > 0.3) * 100,
            'green_pct': lambda x: np.nanmean(x > 0.2) * 100,
        }
    )
    return stats
```

## Population Data (for per-capita metrics)

| Dataset | Resolution | Use Case |
|---------|-----------|----------|
| WorldPop | 100m | Developing countries, annual |
| LandScan | 1km | Global, environmental reports |
| GPWv4 | 1km | UN standard, academic citations |

```python
# GEE: WorldPop population
pop = (ee.ImageCollection('WorldPop/GP/100m/pop')
       .filterDate('2020-01-01', '2020-12-31')
       .first())
# Per-capita green area = green_area / population
```

## Output Panel Format

```
zone_id | year | quarter | ndvi_mean | ndvi_median | tree_cover_pct | green_area_km2 | green_per_capita_m2
PZ_01   | 2021 | Q2      | 0.42      | 0.38        | 31.2           | 2.8            | 12.4
```

## Gotchas

- **Seasonality**: NDVI summer-winter difference can be 0.3+ (temperate). Cross-season comparison must use seasonal normalization or same-season only.
- **Urban shadows**: Tall buildings cast large shadows in winter, depressing NDVI. Effect worsens with latitude.
- **Bare soil vs dead grass**: NDVI 0.1-0.2 range is ambiguous. Combine with land use classification.
- **Sentinel-2 band numbers**: B8 = NIR (10m), B4 = Red (10m). B8A (20m) is different from B8 -- do not mix.
- **Landsat C2 scaling**: SR bands need `x 0.0000275 + (-0.2)`. Raw DN values yield wrong NDVI.
- **Insufficient cloud masking**: `CLOUDY_PIXEL_PERCENTAGE < 20` is scene-level only. Pixel-level: use `s2cloudless` or QA60 band.
