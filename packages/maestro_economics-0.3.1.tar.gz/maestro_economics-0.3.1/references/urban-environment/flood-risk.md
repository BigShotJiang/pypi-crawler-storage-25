# Flood Risk Indicators -- Detailed Reference

## Data Sources

| Dataset | Resolution | Use | Access |
|---------|-----------|-----|--------|
| SRTM v3 | 30m (global) | DEM for TWI | earthaccess / USGS |
| ALOS AW3D30 | 30m (global) | Alternative DEM (better in Japan/Asia) | JAXA |
| FATHOM 2.0 | 90m | Flood inundation (10/100/1000-yr) | Academic application |
| Global Flood Database | 250m | 2000-2018 historical flood events | Cloud-Optimized GeoTIFF |
| JRC Global Surface Water | 30m | Water frequency/seasonality | GEE |

## TWI (Topographic Wetness Index) Calculation

```python
import richdem as rd
import numpy as np
import rasterio

def compute_twi(dem_path, output_path):
    """
    TWI = ln(a / tan(beta))
    a = upstream specific catchment area
    beta = surface slope (radians)
    Higher TWI = more waterlogging = higher flood risk.
    """
    dem = rd.LoadGDAL(dem_path)

    slope = rd.TerrainAttribute(dem, attrib='slope_degrees')
    slope_rad = np.radians(np.array(slope))

    accum = rd.FlowAccumulation(dem, method='D8')

    with rasterio.open(dem_path) as src:
        pixel_area = abs(src.res[0] * src.res[1])
        pixel_area_m2 = pixel_area * (111000 ** 2)

    sca = (np.array(accum) + 1) * pixel_area_m2

    tan_slope = np.tan(slope_rad)
    tan_slope[tan_slope < 0.001] = 0.001

    twi = np.log(sca / tan_slope)

    with rasterio.open(dem_path) as src:
        profile = src.profile.copy()
        profile.update(dtype='float32', nodata=-9999)
        with rasterio.open(output_path, 'w', **profile) as dst:
            dst.write(twi.astype('float32'), 1)

    return output_path
```

## SRTM DEM Acquisition

```python
import earthaccess

earthaccess.login(persist=True)

results = earthaccess.search_data(
    short_name="SRTMGL1",
    bounding_box=(103.6, 1.15, 104.1, 1.47),
)
files = earthaccess.download(results, "~/.maestro/cache/srtm_sg/")
```

```python
# GEE: SRTM DEM
dem = ee.Image('USGS/SRTMGL1_003').select('elevation')
slope = ee.Terrain.slope(dem)

# GEE: TWI via MERIT Hydro (pre-computed flow accumulation)
merit_acc = ee.Image('MERIT/Hydro/v1_0_1').select('upg')
merit_slope = ee.Terrain.slope(ee.Image('MERIT/Hydro/v1_0_1').select('elv'))
twi = merit_acc.multiply(1e6).log().subtract(merit_slope.multiply(3.14159/180).tan().log())
```

## FATHOM Flood Inundation Data

```
# FATHOM 2.0 (requires academic license)
# https://www.fathom.global/product/fathom-global/
# Types: pluvial (surface water) + fluvial (river) + coastal
# Return periods: 5/10/20/50/75/100/200/250/500/1000 years
# Output: GeoTIFF, values = inundation depth (meters)
# Academic: free. Commercial: paid.
# Apply: https://www.fathom.global/product/fathom-global/academic/
```

## JRC Global Surface Water (Free Alternative)

```python
# GEE: JRC Global Surface Water (free, 30m, 1984-2021)
gsw = ee.Image('JRC/GSW1_4/GlobalSurfaceWater')

occurrence = gsw.select('occurrence')       # water frequency 0-100%
seasonality = gsw.select('seasonality')     # months with water per year

# Flood proxy: occurrence > 0 but < 50 = intermittent water = flood-prone
flood_prone = occurrence.gt(0).And(occurrence.lt(50))
```

## Aggregation to Admin Zones

```python
from rasterstats import zonal_stats

def flood_risk_panel(twi_raster, admin_zones, fathom_raster=None):
    """
    Returns: twi_mean, twi_p90, high_twi_pct (TWI>12),
             flood_depth_100yr (if FATHOM available)
    """
    twi_stats = zonal_stats(
        admin_zones, twi_raster,
        stats=['mean', 'median', 'percentile_90'],
        add_stats={'high_twi_pct': lambda x: np.nanmean(x > 12) * 100}
    )

    if fathom_raster:
        flood_stats = zonal_stats(
            admin_zones, fathom_raster,
            stats=['mean', 'max'],
            add_stats={'flooded_pct': lambda x: np.nanmean(x > 0) * 100}
        )
        for i in range(len(twi_stats)):
            twi_stats[i].update({
                'flood_depth_mean': flood_stats[i]['mean'],
                'flood_depth_max': flood_stats[i]['max'],
                'flooded_area_pct': flood_stats[i]['flooded_pct'],
            })

    return twi_stats
```

## Output Panel Format

```
zone_id | twi_mean | twi_p90 | high_twi_pct | flood_depth_100yr_mean | flooded_area_pct
PZ_01   | 8.4      | 13.2    | 18.5         | 0.32                   | 12.1
```

## Gotchas

- **DEM urban error**: SRTM is DSM (includes buildings), urban elevations biased high. Use MERIT DEM (denoised) or FABDEM (buildings+canopy removed).
- **TWI threshold**: TWI > 12 as "high flood risk" is empirical, varies by terrain. Flat cities may need lower threshold.
- **FATHOM access**: Academic free but needs application (1-2 week approval). Apply early.
- **Resolution matching**: SRTM 30m TWI vs FATHOM 90m flood extent need resampling to common grid.
- **Coastal cities**: DEM error near sea level makes TWI unreliable. Use FATHOM coastal data instead.
