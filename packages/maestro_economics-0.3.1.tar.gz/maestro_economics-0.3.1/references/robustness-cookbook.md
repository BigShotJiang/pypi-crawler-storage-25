# Robustness Check Cookbook

Seven robustness check types extracted from three professor projects.
Each entry: what it tests, when to use, Python implementation, output format.

---

## 1. Bandwidth Sensitivity (JEBO)

**What it tests**: Whether results depend on the sample selection window.
In RDD: the bandwidth around the cutoff. In matching: the caliper width.

**When to use**: Any design that restricts sample to a neighborhood around
a threshold (RDD, close-election, CEE cutoff).

**Python implementation**:

```python
import statsmodels.api as sm

def bandwidth_sensitivity(df, outcome, treatment, running_var, cutoff,
                          bandwidths=[0.05, 0.10, 0.15, 0.20],
                          controls=None):
    """Run main specification across multiple bandwidths."""
    results = []
    for bw in bandwidths:
        mask = abs(df[running_var] - cutoff) <= bw
        sub = df[mask].copy()
        X_vars = [treatment] + (controls or [])
        X = sm.add_constant(sub[X_vars].astype(float))
        y = sub[outcome].astype(float)
        res = sm.OLS(y, X, missing='drop').fit(cov_type='HC1')
        results.append({
            'bandwidth': bw,
            'coef': res.params[treatment],
            'se': res.bse[treatment],
            'pval': res.pvalues[treatment],
            'n': int(res.nobs),
            'r2': res.rsquared,
        })
    return pd.DataFrame(results)
```

**JEBO example**: Main results use 0.1 SD window around CEE cutoff.
Robustness shows results hold at 0.15 SD (larger sample, less precise).

**Output format**: Table with rows = bandwidths, columns = coefficient, SE, N.
Or coefficient plot with bandwidth on x-axis.

---

## 2. Placebo / Falsification (Data Experiment)

**What it tests**: Whether the treatment affects outcomes it should NOT affect.
A significant placebo result suggests confounding.

**When to use**: Always. Identify at least one outcome where treatment should
have zero effect.

**Python implementation**:

```python
def placebo_test(df, treatment, placebo_outcomes, controls=None, fe_vars=None):
    """Run main specification on placebo outcomes. Expect null results."""
    results = []
    for outcome in placebo_outcomes:
        X_vars = [treatment] + (controls or [])
        X = sm.add_constant(df[X_vars].astype(float))
        y = df[outcome].astype(float)
        res = sm.OLS(y, X, missing='drop').fit(cov_type='HC1')
        results.append({
            'outcome': outcome,
            'coef': res.params[treatment],
            'se': res.bse[treatment],
            'pval': res.pvalues[treatment],
            'n': int(res.nobs),
            'significant': res.pvalues[treatment] < 0.10,
        })
    return pd.DataFrame(results)
```

**JEBO example**: "Indifferent Choices" in probabilistic beliefs is the placebo.
Expected: no effect (and indeed, coef=-0.331, SE=0.379, p>0.10).
This validates that LLN and Exact Representativeness effects are real.

**Output format**: Same table format as main results. Highlight that placebo
coefficients are insignificant.

---

## 3. Causal vs Non-Causal Comparison (JEBO)

**What it tests**: Whether using the causal identification strategy matters.
Compare the treatment effect from the identified spec vs a naive OLS.

**When to use**: RDD, IV, or any design where the identification relies on
a specific source of variation.

**Python implementation**:

```python
def causal_vs_naive(df, outcome, treatment, controls_causal, controls_naive):
    """Compare identified specification vs naive OLS."""
    # Causal: use only quasi-random variation
    X_c = sm.add_constant(df[controls_causal].astype(float))
    res_causal = sm.OLS(df[outcome], X_c, missing='drop').fit(cov_type='HC1')

    # Naive: control for everything (selection on observables)
    X_n = sm.add_constant(df[controls_naive].astype(float))
    res_naive = sm.OLS(df[outcome], X_n, missing='drop').fit(cov_type='HC1')

    return {
        'causal_coef': res_causal.params[treatment],
        'causal_se': res_causal.bse[treatment],
        'naive_coef': res_naive.params[treatment],
        'naive_se': res_naive.bse[treatment],
        'selection_bias': res_naive.params[treatment] - res_causal.params[treatment],
    }
```

**JEBO example**: Full sample (no bandwidth restriction) includes students
who self-selected into econ. Comparing full-sample OLS vs bandwidth-restricted
RDD reveals selection effects. If they differ, self-selection is real.

**Output format**: Side-by-side columns: "Causal (RDD)" vs "Naive (OLS)".
Discussion of sign and magnitude of selection bias.

---

## 4. Exposure Heterogeneity / Dose-Response (JEBO)

**What it tests**: Whether the treatment effect scales with exposure intensity.
Stronger effects with more exposure = consistent with causal mechanism.

**When to use**: When treatment has variation in duration/intensity.
Education: freshman (1 year) vs senior (4 years). Medicine: dosage levels.

**Python implementation**:

```python
def exposure_heterogeneity(df, outcome, treatment, exposure_var, controls=None):
    """Interact treatment with exposure level.

    exposure_var: binary (e.g., freshman=1) or continuous (years of exposure).
    """
    df = df.copy()
    df['treat_low_exposure'] = df[treatment] * df[exposure_var]
    df['treat_high_exposure'] = df[treatment] * (1 - df[exposure_var])

    X_vars = ['treat_low_exposure', 'treat_high_exposure'] + (controls or [])
    X = sm.add_constant(df[X_vars].astype(float))
    y = df[outcome].astype(float)
    res = sm.OLS(y, X, missing='drop').fit(cov_type='HC1')

    # Test equality: beta_low == beta_high
    from scipy import stats
    b_low = res.params['treat_low_exposure']
    b_high = res.params['treat_high_exposure']
    se_low = res.bse['treat_low_exposure']
    se_high = res.bse['treat_high_exposure']
    # Approximate z-test (conservative: ignores covariance)
    z = (b_high - b_low) / np.sqrt(se_high**2 + se_low**2)
    p_equal = 2 * (1 - stats.norm.cdf(abs(z)))

    return {
        'low_exposure_coef': b_low, 'low_exposure_se': se_low,
        'high_exposure_coef': b_high, 'high_exposure_se': se_high,
        'equality_test_z': z, 'equality_test_p': p_equal,
    }
```

**JEBO example**: Freshman (less coursework) vs Post-Freshman (more coursework).
Post-freshman effects are larger and more significant for risk preferences
(0.177*** vs 0.095*) and probabilistic beliefs (1.991*** vs 0.131).
This supports economics education as the causal mechanism.

**Output format**: Side-by-side coefficient plot (errorbar) with two markers
per outcome. Light color = low exposure, dark color = high exposure.

```python
# Visualization pattern from JEBO
fig, ax = plt.subplots(figsize=(8, 5))
positions = np.arange(n_outcomes)
width = 0.35
ax.errorbar(positions - width/2, fresh_coefs, yerr=1.96*np.array(fresh_ses),
            fmt='o', color='#7FCDBB', label='Freshman', capsize=3)
ax.errorbar(positions + width/2, post_coefs, yerr=1.96*np.array(post_ses),
            fmt='s', color='#2C7FB8', label='Post-Freshman', capsize=3)
ax.axhline(0, color='gray', ls='--', lw=0.8)
```

---

## 5. Alternative Estimators (Ramadan)

**What it tests**: Whether the choice of estimator drives the result.
OLS vs reghdfe vs IV on the same outcome.

**When to use**: When the main specification uses a specialized estimator
(HDFE, IV, Tobit). Show that simpler estimators give qualitatively similar results.

**Python implementation**:

```python
def alternative_estimators(df, outcome, treatment, fe_vars, controls=None):
    """Run OLS, OLS+FE (reghdfe-style), and optionally IV."""
    results = {}

    # 1. Plain OLS
    X = sm.add_constant(df[[treatment]].astype(float))
    results['ols'] = sm.OLS(df[outcome], X, missing='drop').fit()

    # 2. OLS with robust SE
    results['ols_robust'] = sm.OLS(df[outcome], X, missing='drop').fit(cov_type='HC1')

    # 3. OLS + explicit FE dummies (reghdfe equivalent)
    results['reghdfe'] = reghdfe_ols(df, outcome, [treatment], fe_vars)

    return results
```

**Ramadan example**: Column 1 (OLS) gives T4=-1.9032, Column 2 (reghdfe)
gives T4=-2.1985. Same sign, similar magnitude. The FE model is more precise
and shows a slightly larger effect (expected: removing noise increases signal).

**Output format**: The 4-column table IS the alternative estimator comparison.
Column 1 vs 2 = OLS vs HDFE. This is the standard pattern.

---

## 6. Sample Restrictions (Ramadan)

**What it tests**: Whether results are driven by a specific subsample.
Varying inclusion criteria reveals sensitivity to outliers or subgroups.

**When to use**: When the main analysis excludes observations (e.g., group > 2).

**Python implementation**:

```python
def sample_restriction_robustness(df, outcome, treatment, restrictions, **kwargs):
    """Run main specification under different sample restrictions."""
    results = []
    for label, mask in restrictions:
        sub = df[mask].copy()
        X = sm.add_constant(sub[[treatment]].astype(float))
        y = sub[outcome].astype(float)
        res = sm.OLS(y, X, missing='drop').fit(cov_type='HC1')
        results.append({
            'restriction': label,
            'coef': res.params[treatment],
            'se': res.bse[treatment],
            'pval': res.pvalues[treatment],
            'n': int(res.nobs),
        })
    return pd.DataFrame(results)

# Usage:
restrictions = [
    ('Full sample', df.index == df.index),  # all obs
    ('group > 2', df['group'] > 2),          # main spec
    ('group > 2, female only', (df['group'] > 2) & (df['male'] == 0)),
    ('group > 2, male only', (df['group'] > 2) & (df['male'] == 1)),
]
```

**Ramadan example**: Main analysis uses `group > 2` (drops groups 1-2 which
received different treatments). Singleton removal further drops N from 277 to 274.

**Output format**: Table with rows = restrictions, columns = coef, SE, N.
Or append as additional columns in the main table.

---

## 7. Coefficient Equality Tests (Ramadan)

**What it tests**: Whether two treatment arms have significantly different effects.
In multi-arm RCTs: does T3 differ from T4?

**When to use**: Multi-arm experiments, group comparisons, cross-equation tests.

**Python implementation**:

```python
import numpy as np
from scipy import stats

def test_coef_equality(result, var1, var2):
    """Test H0: beta_var1 == beta_var2 using Wald test.

    For statsmodels OLS results. Uses the full variance-covariance matrix.
    """
    b1 = result.params[var1]
    b2 = result.params[var2]
    # Variance of (b1 - b2)
    v1 = result.cov_params().loc[var1, var1]
    v2 = result.cov_params().loc[var2, var2]
    cov12 = result.cov_params().loc[var1, var2]
    var_diff = v1 + v2 - 2 * cov12
    se_diff = np.sqrt(var_diff)

    t_stat = (b1 - b2) / se_diff
    p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df=result.df_resid))

    return {
        'diff': b1 - b2,
        'se_diff': se_diff,
        't_stat': t_stat,
        'p_value': p_value,
    }

# Stata equivalent: test _b[T3] == _b[T4]
```

**Important**: Use the full variance-covariance matrix (including the covariance
term). Ignoring the covariance gives conservative (too wide) confidence intervals
when the treatments are positively correlated, or anti-conservative intervals
when negatively correlated.

**Output format**: Report the test statistic and p-value in the table notes:
"p-value for H0: beta_T3 = beta_T4 is 0.XXX."

---

## Assembly Pattern

For a typical empirical paper, run checks in this order:

```python
# 1. Main results (4-column table)
main_table = run_specification_ladder(df, outcome, treatment, ...)

# 2. Bandwidth sensitivity (if RDD/matching)
bw_table = bandwidth_sensitivity(df, outcome, treatment, running_var, ...)

# 3. Placebo outcomes
placebo_table = placebo_test(df, treatment, placebo_outcomes, ...)

# 4. Exposure heterogeneity (if dose variation)
exposure_results = exposure_heterogeneity(df, outcome, treatment, exposure_var, ...)

# 5. Alternative estimators (already in main table columns 1 vs 2)
# No separate code needed if main table has OLS and HDFE columns

# 6. Sample restrictions
restriction_table = sample_restriction_robustness(df, outcome, treatment, ...)

# 7. Coefficient equality (if multi-arm)
equality_test = test_coef_equality(main_result, 'T3', 'T4')
```

Each check produces either a table (appendix) or a coefficient plot (figure).
The main text discusses results; the appendix presents full tables.
