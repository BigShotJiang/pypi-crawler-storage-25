# Country-Specific Gotchas — Urban Hedonic

## Singapore HDB

| Issue | Description | Solution |
|-------|-------------|----------|
| Remaining lease | 99-year leasehold; <60 years = sharp price drop | Must control `lease_remaining`, add `lease_remaining^2` nonlinear term |
| Flat type | 3-Room, 4-Room, 5-Room, Executive differ greatly | Include `flat_type` FE |
| Floor range | Data gives ranges ("04 TO 06") not exact floors | Take midpoint or use dummies |
| Mature vs non-mature | Mature estates have significant premium | Control for `town` or `planning_area` |
| Ethnic quota | Ethnic Integration Policy affects buying/selling | Cannot directly control; note in limitations |
| MOP restriction | Minimum Occupation Period (5 years) affects supply | May affect transaction timing |

## China

| Issue | Description | Solution |
|-------|-------------|----------|
| Listing != transaction price | Gap can reach 10-20% | Use transaction data only (chengjiao) |
| Online-signed price distortion | Price caps may suppress reported prices | Note data reliability during policy periods |
| Coordinate system | GCJ-02 / BD-09 != WGS-84 | Must convert before spatial analysis |
| Shared area (gontan) | Gross vs net area differs by city | Unify to one area definition |
| Purchase restrictions | Rules differ by city and period | Include policy dummy variables |
| School district | "Xuequ fang" premium high but policy changes frequently | Need precise school district boundary data |
| Pre-sale vs existing | Pre-sale prices typically lower | Analyze separately or add control variable |

## Japan

| Issue | Description | Solution |
|-------|-------------|----------|
| Land vs building | Transaction may be land-only or with building | Process separately; or use only "residential land with building" |
| Wooden depreciation | Wooden buildings: 22-year legal depreciation, 30+ years = ~zero value | Treat building age >30 years as pure land transaction |
| Area units | m² and tsubo mixed | Unify to m² (1 tsubo = 3.306 m²) |
| Anonymization | Some transaction amounts are rounded | Check price digit distribution |
| Station distance | "Walking XX min" vs "Bus XX min" | Encode separately; bus typically multiply by 3-5x |

## United States

| Issue | Description | Solution |
|-------|-------------|----------|
| MLS data | Not public; requires Realtor association access | Use Zillow/Redfin public data instead |
| Non-market transactions | Foreclosures, family transfers have abnormal prices | Exclude non-arm's-length transactions |
| Property tax assessment | Assessed value != market value | Zillow ZHVI already smoothed |
| Seasonality | Strong seasonality (spring/summer high) | Use seasonally adjusted data or add month FE |

## Universal Pitfalls

| Issue | Description |
|-------|-------------|
| Endogeneity | MRT station siting is non-random -> need IV or DID |
| Omitted variables | Neighborhood quality, crime rate, noise unobservable -> use property FE or community FE |
| Sample selection | Only transaction data visible; unlisted properties are not |
| Spatial autocorrelation | OLS SE biased downward -> cluster at spatial unit level |
| Functional form | Distance effect is nonlinear; consider piecewise linear or splines |
| Multicollinearity | dist_mrt and dist_cbd highly correlated -> VIF check |
