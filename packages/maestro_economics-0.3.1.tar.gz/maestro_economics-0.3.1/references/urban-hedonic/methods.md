# Econometric Methods — Urban Hedonic

## OLS Hedonic Regression (Baseline)

Classic hedonic price model:

```
ln(price_i) = alpha + beta * X_i + gamma * Z_i + delta * D_i + epsilon_i
```

Where:
- `X_i`: Structural characteristics (area, rooms, floor, age, decoration)
- `Z_i`: Location characteristics (dist_mrt, dist_cbd, dist_school, POI density)
- `D_i`: Time dummies (year-quarter)

```python
import statsmodels.formula.api as smf

model = smf.ols(
    "np.log(price) ~ floor_area_sqm + C(rooms) + floor_level + building_age"
    " + dist_mrt + dist_cbd + dist_school + poi_500m + ndvi_500m"
    " + C(year_quarter)",
    data=df
).fit(cov_type="HC1")  # Heteroskedasticity-robust SE

print(model.summary())
```

**Interpretation**: `dist_mrt` coefficient = percentage price change per additional meter from MRT.
Typical result: 0.5-2% price decline per 100m from MRT.

### Semi-log vs Log-log

```python
# Semi-log (recommended): ln(price) ~ dist_mrt
# Interpretation: beta = % price change per unit distance increase

# Log-log: ln(price) ~ ln(dist_mrt)
# Interpretation: elasticity — 1% distance increase -> beta% price change
# Suitable for distance variables (diminishing effect)

model_loglog = smf.ols(
    "np.log(price) ~ floor_area_sqm + np.log(dist_mrt + 1) + np.log(dist_cbd)"
    " + C(year_quarter)",
    data=df
).fit(cov_type="HC1")
```

## Spatial Lag / Spatial Error Models

Housing prices exhibit spatial correlation — neighboring house prices influence each other. OLS SEs are biased downward under spatial autocorrelation.

```python
from libpysal.weights import KNN
from spreg import ML_Lag, ML_Error
import numpy as np

w = KNN.from_dataframe(gdf_proj, k=10)
w.transform = "r"  # Row standardization

y = np.log(df["price"].values).reshape(-1, 1)
X = df[["floor_area_sqm", "dist_mrt", "dist_cbd", "building_age"]].values

# Spatial Lag: y = rho * W * y + X * beta + epsilon
lag_model = ML_Lag(y, X, w=w, name_y="ln_price",
                   name_x=["area", "dist_mrt", "dist_cbd", "age"])

# Spatial Error: y = X * beta + u, u = lambda * W * u + epsilon
error_model = ML_Error(y, X, w=w, name_y="ln_price",
                       name_x=["area", "dist_mrt", "dist_cbd", "age"])
```

**Choosing Lag vs Error**:
- Moran's I test -> confirm spatial autocorrelation exists
- LM-Lag vs LM-Error test -> choose model form
- Rule of thumb: prices influence each other -> Lag; omitted spatial variables -> Error

## TWFE (Two-Way Fixed Effects)

Panel data standard method — property FE + time FE.

```python
import pyfixest as pf

est = pf.feols(
    "np.log(price) ~ dist_mrt + dist_school + poi_500m | property_id + year_quarter",
    data=df
)
pf.etable(est)
```

**Requirements**:
- Needs panel structure (same property traded multiple times)
- Property FE absorbs time-invariant characteristics (area, floor, location)
- Only identifies time-varying variables (e.g., MRT opening -> DID)

### DID + TWFE (MRT Opening Example)

```python
# treatment: within 1km of new MRT station
# post: after station opening
# interaction: treatment * post = ATT

est_did = pf.feols(
    "np.log(price) ~ treat_post | property_id + year_quarter",
    data=df
)
# treat_post = 1 if within 1km AND after opening date
```

**Known TWFE + DID Issues**:
- Staggered DID: TWFE has negative weight problem
- Solutions: Callaway-Sant'Anna (2021), Sun-Abraham (2021), Borusyak et al. (2024)
- Python: `pip install csdid` or R `did` package

## Repeat Sales Index (Case-Shiller Method)

For constructing city/region-level price indices, controlling for housing quality differences.

**Core idea**: Use only pairs of transactions for the same property; differencing eliminates fixed characteristics.

```python
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import lsqr

def repeat_sales_index(df: pd.DataFrame, property_col: str = "property_id",
                       date_col: str = "date", price_col: str = "price",
                       freq: str = "Q") -> pd.DataFrame:
    """
    Construct repeat sales price index.

    Args:
        df: Transaction data with property_id, date, price
        freq: Time frequency ("Q" = quarterly, "M" = monthly)

    Returns:
        DataFrame: period, index_value (base=100)
    """
    # 1. Find properties with >= 2 transactions
    repeat = df.groupby(property_col).filter(lambda x: len(x) >= 2)
    repeat = repeat.sort_values([property_col, date_col])

    # 2. Build pairs
    pairs = []
    for pid, group in repeat.groupby(property_col):
        for i in range(len(group) - 1):
            row1 = group.iloc[i]
            row2 = group.iloc[i + 1]
            pairs.append({
                "property_id": pid,
                "date_buy": row1[date_col],
                "date_sell": row2[date_col],
                "log_return": np.log(row2[price_col] / row1[price_col]),
            })
    pairs_df = pd.DataFrame(pairs)

    # 3. Period encoding
    pairs_df["period_buy"] = pairs_df["date_buy"].dt.to_period(freq)
    pairs_df["period_sell"] = pairs_df["date_sell"].dt.to_period(freq)

    all_periods = sorted(set(pairs_df["period_buy"]) | set(pairs_df["period_sell"]))
    period_to_idx = {p: i for i, p in enumerate(all_periods)}
    n_periods = len(all_periods)

    # 4. Regression matrix: log_return = beta_sell - beta_buy
    n_pairs = len(pairs_df)
    rows = list(range(n_pairs)) + list(range(n_pairs))
    cols = ([period_to_idx[p] for p in pairs_df["period_sell"]] +
            [period_to_idx[p] for p in pairs_df["period_buy"]])
    data = [1.0] * n_pairs + [-1.0] * n_pairs

    X = csr_matrix((data, (rows, cols)), shape=(n_pairs, n_periods))
    y = pairs_df["log_return"].values

    # 5. WLS (Case-Shiller weighting: inverse holding period)
    hold_periods = (pairs_df["period_sell"] - pairs_df["period_buy"]).apply(lambda x: max(x.n, 1))
    weights = 1.0 / hold_periods.values

    Xw = X.multiply(np.sqrt(weights).reshape(-1, 1))
    yw = y * np.sqrt(weights)

    # 6. Solve (sparse least squares)
    result = lsqr(Xw, yw)
    betas = result[0]

    # 7. Normalize: first period = 0 (log), i.e., 100 (index)
    betas = betas - betas[0]
    index_values = np.exp(betas) * 100

    return pd.DataFrame({"period": [str(p) for p in all_periods], "index_value": index_values})

index_df = repeat_sales_index(df, freq="Q")
```

**Repeat sales caveats**:
- Exclude major renovations (quality change breaks "homogeneous" assumption)
- Usually exclude holding period < 6 months ("flip" transactions)
- Sample selection bias: only properties traded 2+ times are included
- Can combine with hedonic method (hybrid repeat sales)

## Instrumental Variable Strategies

### Saiz (2010) Terrain IV

**Idea**: Terrain slope / water body area constrains housing supply. Cities with steep slopes and more water have lower land supply elasticity; prices are more sensitive to demand shocks.

```python
# Data needed:
# 1. USGS SRTM elevation data -> compute slope
# 2. Water body coverage area
#
# Steps:
# (a) Download SRTM DEM (30m resolution)
# (b) Compute share of land with slope > 15% within 50km radius
# (c) Compute water body area share within 50km radius
# (d) "Undevelopable land share" = slope-constrained + water
#
# GEE extraction (via maestro-data-spatial):
# python scripts/gee_extract.py NASA/NASADEM_HGT/001 cities.shp \
#     --band elevation --reducer mean,stdDev --scale 30
```

**Applicable**: Cross-city regressions (cross-section), NOT for within-city analysis.

### Historical Road/Railway IV

**Idea**: Historical road networks (Qing-era roads, Republican-era railways, Roman roads) predict modern transport infrastructure location but do not directly affect contemporary house prices.

```python
# Data sources:
# - China: CHGIS historical transport networks
# - Europe: Roman Roads (McCormick et al.)
# - USA: 1898 railroad map (Atack 2015)
#
# Construct IV:
# (a) Compute property distance to nearest historical road
# (b) First stage: modern_mrt_dist ~ historical_road_dist + controls
# (c) Second stage: ln(price) ~ hat{modern_mrt_dist} + controls
```

### Bartik IV (Demand Shock IV)

```python
# Housing demand Bartik instrument:
# Uses industry structure differences x national industry employment growth
#
# Z_r = sum_k (share_rk * growth_k)
# share_rk: region r's initial employment share in industry k
# growth_k: national industry k employment growth rate (excluding local region)
#
# Applicable: housing demand shocks -> house price changes
```

## Quantile Regression

Effects may differ across the price distribution — cheap vs expensive houses may respond differently to MRT proximity.

```python
import statsmodels.formula.api as smf

for q in [0.25, 0.50, 0.75]:
    model = smf.quantreg(
        "np.log(price) ~ floor_area_sqm + dist_mrt + dist_cbd + building_age",
        data=df
    ).fit(q=q)
    print(f"\n=== Quantile {q} ===")
    print(model.summary())
```
