# Output Format & Validation — Urban Hedonic

## Standard Delivery Files

```
{project_dir}/
  raw/                              # Immutable raw data
    resale-flat-prices-raw.csv
    mrt_stations.geojson
    schools.geojson
  data.csv                          # Main panel (transaction-level)
  index.csv                         # Price index (if applicable)
  README.md                         # Data documentation
  codebook.xlsx                     # Variable definitions
  version.json                      # Version info
  report.pdf                        # Quality report (LaTeX generated)
  scripts/
    01_download.py                  # Data download
    02_geocode.py                   # Address geocoding
    03_spatial_vars.py              # Spatial variable computation
    04_panel.py                     # Panel construction
    05_index.py                     # Price index (if applicable)
    06_validate.py                  # Quality checks
```

## Stata / R Format Export

```python
# Stata .dta
df.to_stata("housing_panel.dta", write_index=False, version=119)

# R .rds (via pyreadr)
import pyreadr
pyreadr.write_rds("housing_panel.rds", df)

# Parquet (recommended for large panels)
df.to_parquet("housing_panel.parquet", index=False)
```

## Report Quality Checklist

Report (`report.pdf`) must include:

1. **Data coverage**: Time range, geographic scope, total transaction count
2. **Missing rate analysis**: Missing proportion per variable, geocoding success rate
3. **Price distribution**: Histogram + kernel density, by year
4. **Spatial distribution**: Transaction point map / heatmap
5. **Time trend**: Monthly/quarterly median price trend
6. **Outlier detection**: Price/area extreme value flagging
7. **Variable correlation**: Correlation matrix of key variables

## Data Quality Check

```python
def hedonic_data_quality_check(df: pd.DataFrame) -> dict:
    """Hedonic panel data quality check."""
    report = {}

    # 1. Sample size
    report["n_transactions"] = len(df)
    report["n_properties"] = df["property_id"].nunique()
    report["n_repeat_sales"] = df.groupby("property_id").size().gt(1).sum()

    # 2. Time coverage
    report["date_range"] = f"{df['date'].min()} to {df['date'].max()}"
    report["n_periods"] = df["year_quarter"].nunique()

    # 3. Missing rates
    key_vars = ["price", "floor_area_sqm", "lat", "lon", "dist_mrt", "dist_cbd"]
    for var in key_vars:
        if var in df.columns:
            report[f"missing_{var}"] = df[var].isna().mean()

    # 4. Outliers
    report["price_p1"] = df["price"].quantile(0.01)
    report["price_p99"] = df["price"].quantile(0.99)
    report["area_p1"] = df["floor_area_sqm"].quantile(0.01)
    report["area_p99"] = df["floor_area_sqm"].quantile(0.99)

    # 5. Price/area extremes
    price_sqm = df["price"] / df["floor_area_sqm"]
    report["price_sqm_p1"] = price_sqm.quantile(0.01)
    report["price_sqm_p99"] = price_sqm.quantile(0.99)

    return report
```

## Regression Diagnostics

```python
# 1. VIF (Multicollinearity)
from statsmodels.stats.outliers_influence import variance_inflation_factor

X = df[["floor_area_sqm", "dist_mrt", "dist_cbd", "dist_school", "building_age"]].dropna()
for i, col in enumerate(X.columns):
    vif = variance_inflation_factor(X.values, i)
    print(f"{col}: VIF = {vif:.2f}")
# VIF > 10 -> severe multicollinearity

# 2. Moran's I (Spatial Autocorrelation)
from esda.moran import Moran
from libpysal.weights import KNN

w = KNN.from_dataframe(gdf_proj, k=10)
w.transform = "r"
residuals = model.resid
mi = Moran(residuals, w)
print(f"Moran's I = {mi.I:.4f}, p-value = {mi.p_sim:.4f}")
# Significant -> OLS SE biased, consider spatial model or clustered SE

# 3. Breusch-Pagan (Heteroskedasticity)
from statsmodels.stats.diagnostic import het_breuschpagan
bp_stat, bp_p, _, _ = het_breuschpagan(model.resid, model.model.exog)
print(f"BP stat = {bp_stat:.2f}, p-value = {bp_p:.4f}")
# Significant -> use HC1/HC3 robust SE

# 4. RESET Test (Functional Form)
from statsmodels.stats.diagnostic import linear_reset
reset_result = linear_reset(model, power=3)
print(f"RESET F-stat = {reset_result.fvalue:.2f}, p-value = {reset_result.pvalue:.4f}")
```

## Robustness Check Checklist

| Check | Purpose | Method |
|-------|---------|--------|
| Distance threshold sensitivity | Whether effect depends on cutoff | Vary treatment distance: 500m, 1km, 1.5km, 2km |
| Time window sensitivity | Whether effect varies with window | Vary pre/post window: 1yr, 2yr, 3yr, 5yr |
| Sample restriction | Exclude outlier influence | Winsorize 1%/99%, exclude flip transactions |
| Placebo test | Whether effect is real | Random treatment assignment, or fake event dates |
| Stepwise controls | Omitted variable sensitivity | Baseline to full model, adding controls gradually |
| Spatial FE level | Spatial heterogeneity | District FE -> street FE -> community FE |
| Cluster level | SE robustness | Property -> community -> street -> district |
