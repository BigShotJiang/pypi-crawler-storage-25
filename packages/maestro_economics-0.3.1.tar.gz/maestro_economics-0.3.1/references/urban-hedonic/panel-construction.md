# Panel Construction — Urban Hedonic

## Address Cleaning & Geocoding

### Geocoding Strategy Selection

| Data Scale | Recommended | Cost |
|------------|------------|------|
| < 1,000 | Google Maps API | ~$5/1k requests |
| 1,000 - 100,000 | Google Maps (bulk) / Nominatim | $0-$50 |
| > 100,000 | Local Nominatim (Docker) / Photon | Free |
| Singapore | OneMap API | Free |
| China | Amap API (GCJ-02 -> WGS-84) | Free (5k/day) |
| USA | Census Geocoder | Free |

### Local Nominatim Deployment (Large-Scale Geocoding)

```bash
# Docker deployment (~64GB disk for global data, or select specific country)
docker run -it \
  -e PBF_URL=https://download.geofabrik.de/asia/singapore-latest.osm.pbf \
  -e REPLICATION_URL=https://download.geofabrik.de/asia/singapore-updates/ \
  -p 8080:8080 \
  mediagis/nominatim:4.4

curl "http://localhost:8080/search?q=123+Bishan+Street+12&format=json"
```

### Geocoding Quality Control

```python
def geocoding_quality_check(df: pd.DataFrame, lat_col: str = "lat", lon_col: str = "lon",
                            country_bounds: dict = None) -> pd.DataFrame:
    """Geocoding result quality check."""
    report = {}

    # 1. Missing rate
    missing = df[[lat_col, lon_col]].isna().any(axis=1).sum()
    report["missing_rate"] = missing / len(df)

    # 2. Boundary check
    if country_bounds:
        out_of_bounds = ~(
            (df[lat_col].between(country_bounds["lat_min"], country_bounds["lat_max"])) &
            (df[lon_col].between(country_bounds["lon_min"], country_bounds["lon_max"]))
        )
        report["out_of_bounds_rate"] = out_of_bounds.sum() / len(df)

    # 3. Duplicate coordinates (same coord mapped to many addresses -> possibly default value)
    coord_counts = df.groupby([lat_col, lon_col]).size()
    suspicious = coord_counts[coord_counts > len(df) * 0.01]
    report["suspicious_duplicates"] = len(suspicious)

    return report

# Singapore bounds
SG_BOUNDS = {"lat_min": 1.15, "lat_max": 1.47, "lon_min": 103.6, "lon_max": 104.05}
```

## Control Variables

### Distance Variables (via maestro-data-spatial)

```python
import geopandas as gpd
from shapely.geometry import Point

gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df["lon"], df["lat"]), crs="EPSG:4326")

# Project to local CRS (distance in meters)
# Singapore: EPSG:3414 | China: per-province UTM | USA: per-state State Plane
gdf_proj = gdf.to_crs("EPSG:3414")  # Singapore SVY21

# === Nearest MRT station distance ===
mrt_stations = gpd.read_file("mrt_stations.geojson").to_crs("EPSG:3414")
from geopandas import sjoin_nearest
gdf_proj = sjoin_nearest(gdf_proj, mrt_stations[["station_name", "geometry"]],
                          how="left", distance_col="dist_mrt")

# === CBD distance ===
cbd = Point(103.8515, 1.2819)
cbd_proj = gpd.GeoSeries([cbd], crs="EPSG:4326").to_crs("EPSG:3414").iloc[0]
gdf_proj["dist_cbd"] = gdf_proj.geometry.distance(cbd_proj)

# === Nearest school distance ===
schools = gpd.read_file("schools.geojson").to_crs("EPSG:3414")
gdf_proj = sjoin_nearest(gdf_proj, schools[["school_name", "geometry"]],
                          how="left", distance_col="dist_school", max_distance=5000)

# === Nearest park distance ===
parks = gpd.read_file("parks.geojson").to_crs("EPSG:3414")
gdf_proj = sjoin_nearest(gdf_proj, parks[["park_name", "geometry"]],
                          how="left", distance_col="dist_park")
```

### POI Density (OpenStreetMap)

```python
import osmnx as ox

tags = {"amenity": ["restaurant", "cafe", "hospital", "school", "bank"]}
pois = ox.features_from_place("Singapore", tags=tags)

# Fast POI count within buffer using spatial index
from shapely import STRtree

pois_proj = pois.to_crs(gdf_proj.crs)
tree = STRtree(pois_proj.geometry.values)

def count_pois_fast(point, tree, buffer_m=500):
    buffer = point.buffer(buffer_m)
    return len(tree.query(buffer, predicate="within"))

gdf_proj["poi_500m"] = gdf_proj.geometry.apply(lambda p: count_pois_fast(p, tree, 500))
```

### NDVI / Green Index (GEE)

```python
# Via maestro-data-spatial gee_extract.py
# python scripts/gee_extract.py MODIS/061/MOD13A3 transactions_buffered.shp \
#     --band NDVI --by-year 2010 2023 --reducer mean --scale 500
```

### Spatial Unit Aggregation

```python
# Singapore: Planning Area / Subzone
# China: Street Office / Community
# USA: Census Tract / ZIP Code
# Japan: Chome

planning_areas = gpd.read_file("sg_planning_areas.geojson").to_crs(gdf_proj.crs)
gdf_proj = gpd.sjoin(gdf_proj, planning_areas[["pln_area_n", "geometry"]],
                      how="left", predicate="within")
```

## Time Variables

```python
df["year"] = df["date"].dt.year
df["month"] = df["date"].dt.month
df["quarter"] = df["date"].dt.quarter
df["year_quarter"] = df["date"].dt.to_period("Q").astype(str)  # "2023Q1"

# Policy event dummies
df["post_absd_2013"] = (df["date"] >= "2013-01-12").astype(int)

# MRT opening date dummies
mrt_open_dates = pd.read_csv("mrt_opening_dates.csv")
# ... merge and compute treatment dummy
```

## Standard Output Panel

### Transaction-Level Panel (Micro)

| Field | Type | Description |
|-------|------|-------------|
| `property_id` | str | Unique property ID (address hash or official ID) |
| `date` | date | Transaction date |
| `price` | float | Transaction price (local currency) |
| `price_sqm` | float | Price per sqm |
| `floor_area_sqm` | float | Floor area |
| `rooms` | int | Number of rooms |
| `floor_level` | str/int | Floor level |
| `building_age` | int | Building age (years) |
| `lease_remaining` | float | Remaining lease years (leasehold) |
| `lat` | float | Latitude (WGS-84) |
| `lon` | float | Longitude (WGS-84) |
| `dist_mrt` | float | Distance to nearest MRT (meters) |
| `dist_cbd` | float | Distance to CBD (meters) |
| `dist_school` | float | Distance to nearest school (meters) |
| `dist_park` | float | Distance to nearest park (meters) |
| `poi_500m` | int | POI count within 500m |
| `ndvi_500m` | float | Mean NDVI within 500m |
| `planning_area` | str | Planning area |
| `year` | int | Year |
| `quarter` | int | Quarter |

### Price Index Panel (Macro)

| Field | Type | Description |
|-------|------|-------------|
| `period` | str | Period ("2023Q1" or "2023-01") |
| `region` | str | Region identifier |
| `index_value` | float | Index value (base=100) |
| `n_transactions` | int | Transaction count for period |
| `median_price_sqm` | float | Median unit price |
