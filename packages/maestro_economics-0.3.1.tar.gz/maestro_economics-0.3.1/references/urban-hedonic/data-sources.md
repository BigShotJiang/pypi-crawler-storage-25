# Data Sources — Urban Hedonic

## 1.1 Singapore

### HDB Resale Transactions (Public, Preferred)

- **Source**: data.gov.sg — Resale Flat Prices
- **URL**: `https://data.gov.sg/datasets/d_8b84c4ee58e3cfc0ece0d773c8ca6abc/view`
- **Coverage**: 1990-present, quarterly updates
- **Fields**: month, town, flat_type, block, street_name, storey_range, floor_area_sqm, flat_model, lease_commence_date, remaining_lease, resale_price
- **Format**: CSV (direct download, no API key)

```bash
# Via maestro-fetch
maestro-fetch "https://data.gov.sg/api/action/datastore_search?resource_id=d_8b84c4ee58e3cfc0ece0d773c8ca6abc&limit=999999"
```

```python
import pandas as pd

url = "https://data.gov.sg/api/action/datastore_search?resource_id=d_8b84c4ee58e3cfc0ece0d773c8ca6abc&limit=999999"
df = pd.read_json(url)
# Or download CSV locally
df = pd.read_csv("resale-flat-prices.csv")

df["date"] = pd.to_datetime(df["month"], format="%Y-%m")
df["price_sqm"] = df["resale_price"] / df["floor_area_sqm"]
df["lease_remaining"] = df["remaining_lease"].str.extract(r"(\d+)").astype(float)
```

**Key note**: HDB remaining lease (99-year leasehold) significantly affects price. Units with <50 years remaining see sharp price drops. **Must** include `lease_remaining` as control variable.

### URA Private Residential (Application Required)

- **Source**: Urban Redevelopment Authority — Private Residential Property Transactions
- **URL**: `https://www.ura.gov.sg/reis/dataDictionary`
- **Coverage**: 1995-present
- **Fields**: project_name, street, type, area_sqm, unit_price_psm, contract_date, tenure, district, floor_level
- **Access**: URA REALIS system, free for academic institutions

### OneMap Geocoding (Free API)

```python
import requests
import time

def geocode_sg(address: str) -> tuple[float, float] | None:
    """OneMap geocoding for Singapore addresses."""
    url = "https://www.onemap.gov.sg/api/common/elastic/search"
    params = {"searchVal": address, "returnGeom": "Y", "getAddrDetails": "Y"}
    resp = requests.get(url, params=params)
    results = resp.json().get("results", [])
    if results:
        return float(results[0]["LATITUDE"]), float(results[0]["LONGITUDE"])
    return None

# Batch geocoding (rate limit ~4 req/s)
for idx, row in df.iterrows():
    addr = f"{row['block']} {row['street_name']}"
    coords = geocode_sg(addr)
    if coords:
        df.at[idx, "lat"] = coords[0]
        df.at[idx, "lon"] = coords[1]
    time.sleep(0.25)
```

## 1.2 China

### Lianjia/Beike Transaction Data (Web Scraping)

- **Source**: lianjia.com / ke.com
- **Coverage**: Major cities (Tier 1 + New Tier 1), recent 5 years
- **Fields**: community, layout, area, total_price, unit_price, deal_date, floor, orientation, decoration, elevator, build_year
- **Access**: Web scraper (`maestro-fetch` + custom scraper)
- **Notes**:
  - **Listing price != transaction price**. Prefer transaction (chengjiao) data
  - Transaction data has 1-3 month delay
  - Strong anti-scraping; needs proxy pool and rate limiting
  - Limited retention period; archive regularly

```python
import pandas as pd

df = pd.read_csv("lianjia_chengjiao.csv")
df["price_sqm"] = df["unit_price"]
df["date"] = pd.to_datetime(df["deal_date"])
df["floor_level"] = df["floor"].map({"低楼层": "low", "中楼层": "mid", "高楼层": "high"})
df["has_elevator"] = df["elevator"].map({"有": 1, "无": 0})
df["decoration"] = df["decoration"].map({"精装": "refined", "简装": "simple", "毛坯": "rough", "其他": "other"})
df["building_age"] = df["date"].dt.year - df["build_year"]
```

### WIND Financial Terminal

- **Source**: Wind Information
- **Coverage**: 70-city price index, land auction data, macro indicators
- **Access**: Paid terminal (most academic institutions subscribe)
- **Data types**: 100-city price index (monthly), land transaction prices/premium rates, commercial housing sales area/amount, real estate development investment

### NBS 70-City House Price Index

- **Source**: stats.gov.cn
- **Coverage**: 70 major cities, 2005-present (monthly)
- **Categories**: New / second-hand residential; <90m² / 90-144m² / >144m²
- **Format**: MoM / YoY / base index

### Geocoding (China)

```python
import requests

def geocode_cn(address: str, city: str, api_key: str) -> tuple[float, float] | None:
    """Amap geocoding, returns (lat, lon). Note: returns GCJ-02 coordinates."""
    url = "https://restapi.amap.com/v3/geocode/geo"
    params = {"address": address, "city": city, "key": api_key, "output": "json"}
    resp = requests.get(url, params=params)
    data = resp.json()
    if data["status"] == "1" and data["geocodes"]:
        loc = data["geocodes"][0]["location"].split(",")
        return float(loc[1]), float(loc[0])  # lat, lon
    return None

# GCJ-02 to WGS-84 conversion
from coord_convert.converter import gcj02_to_wgs84
lon_wgs, lat_wgs = gcj02_to_wgs84(lon_gcj, lat_gcj)
```

**China Coordinate System Trap (Must Read)**:
- China map data uses GCJ-02 ("Mars coordinates"), not WGS-84
- Amap/Tencent APIs return GCJ-02
- Baidu Maps uses BD-09 (further offset from GCJ-02)
- International data (OSM, GEE, GADM) uses WGS-84
- **Must unify coordinate systems before distance calculations** (offset can be hundreds of meters)

## 1.3 United States

### Zillow ZHVI / ZORI (Recommended)

- **Source**: Zillow Research Data
- **URL**: `https://www.zillow.com/research/data/`
- **Coverage**: National, ZIP/city/county/metro/state levels
- **Frequency**: Monthly
- **Indicators**: ZHVI (Home Value Index), ZORI (Rent Index), Forecast
- **Format**: CSV bulk download, no API needed

```python
import pandas as pd

zhvi = pd.read_csv("Zip_zhvi_uc_sfrcondo_tier_0.33_0.67_sm_sa_month.csv")
id_cols = ["RegionID", "RegionName", "State", "City", "Metro", "CountyName"]
date_cols = [c for c in zhvi.columns if c.startswith("20")]
panel = zhvi.melt(id_vars=id_cols, value_vars=date_cols, var_name="date", value_name="zhvi")
panel["date"] = pd.to_datetime(panel["date"])
```

### FHFA House Price Index

- **Source**: Federal Housing Finance Agency
- **URL**: `https://www.fhfa.gov/data/hpi`
- **Coverage**: National MSA/state/division, 1975-present (quarterly)
- **Method**: Repeat sales (Fannie Mae + Freddie Mac mortgage data)

### American Housing Survey (AHS)

- **Source**: Census Bureau
- **Coverage**: National + selected MSA, biennial
- **Features**: Micro panel (tracks same dwelling), includes structural characteristics

### Census Geocoder

```python
import requests

def geocode_us(address: str) -> tuple[float, float] | None:
    """US Census Bureau geocoder (free, no API key)."""
    url = "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress"
    params = {"address": address, "benchmark": "Public_AR_Current", "format": "json"}
    resp = requests.get(url, params=params)
    matches = resp.json().get("result", {}).get("addressMatches", [])
    if matches:
        coords = matches[0]["coordinates"]
        return coords["y"], coords["x"]
    return None
```

## 1.4 Japan

### MLIT Real Estate Transaction Price (Public)

- **Source**: Ministry of Land, Infrastructure, Transport and Tourism
- **URL**: `https://www.land.mlit.go.jp/webland/`
- **API**: `https://www.land.mlit.go.jp/webland/api/TradeListSearch`
- **Coverage**: 2005-present, national (quarterly)
- **Fields**: transaction_price, area, nearest_station_distance, building_structure, build_year, prefecture, municipality

```python
import requests
import pandas as pd

def fetch_mlit(prefecture: str, city: str, year: int, quarter: int) -> pd.DataFrame:
    """MLIT Real Estate Transaction Price API."""
    url = "https://www.land.mlit.go.jp/webland/api/TradeListSearch"
    params = {"from": f"{year}{quarter}", "to": f"{year}{quarter}", "area": prefecture, "city": city}
    resp = requests.get(url, params=params)
    return pd.DataFrame(resp.json().get("data", []))

df = fetch_mlit("13", "", 2023, 1)  # Tokyo (area=13)
```

**Japan data notes**:
- **Land vs building**: Transactions split into "land" and "building (with land)" — different price composition
- Old buildings (wooden 30+ years) have near-zero value; transaction price ≈ pure land price
- Area units: usually m², but land price surveys sometimes use "tsubo" (1 tsubo = 3.306 m²)
- Station distance: distinguish "walking XX min" vs "bus XX min"

### Land Price Survey (Chika Koji / Chika Chosa)

- **Source**: MLIT (national) / prefectures (survey)
- **Coverage**: ~26,000 standard points nationwide, annual
- **Use**: Land price benchmarks for constructing land price indices
- **URL**: `https://www.land.mlit.go.jp/landPrice/AriaServlet`

## 1.5 Europe

### Eurostat Housing Price Index

- **Source**: Eurostat
- **Coverage**: EU27 + EFTA, 2005-present (quarterly)
- **Indicator**: House Price Index (2015=100), new/existing split
- **API**: Eurostat JSON API

```python
import eurostat  # pip install eurostat
df = eurostat.get_data_df("prc_hpi_q")
```

### National Cadastre Data

| Country | Source | Coverage | Access |
|---------|--------|----------|--------|
| UK | HM Land Registry Price Paid | 1995-present, all transactions | Public CSV |
| France | DVF (Demandes de Valeurs Foncieres) | 2014-present | Public (data.gouv.fr) |
| Germany | Gutachterausschuss | Varies by state | Application required |
| Netherlands | NVM / Kadaster | All transactions | Academic agreement |
| Australia | CoreLogic / state Valuer-General | All transactions | Paid / academic |

### UK Land Registry Example

```python
import pandas as pd

url = "http://prod.publicdata.landregistry.gov.uk.s3-website-eu-west-1.amazonaws.com/pp-complete.csv"
cols = ["txn_id", "price", "date", "postcode", "property_type", "new_build",
        "tenure", "paon", "saon", "street", "locality", "town", "district", "county", "record_status"]
df = pd.read_csv(url, names=cols, parse_dates=["date"])
# property_type: D=Detached, S=Semi-detached, T=Terraced, F=Flat, O=Other
# tenure: F=Freehold, L=Leasehold
```
