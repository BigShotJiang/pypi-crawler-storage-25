# Bibliography & Appendices — Urban Hedonic

## Classic Methodology

1. **Rosen (1974)** — "Hedonic Prices and Implicit Markets" — hedonic theory foundation
2. **Case & Shiller (1989)** — "The Efficiency of the Market for Single-Family Homes" — repeat sales index
3. **Saiz (2010)** — "The Geographic Determinants of Housing Supply" — terrain IV
4. **Gibbons & Machin (2005)** — "Valuing Rail Access Using Transport Innovations" — MRT DID
5. **Black (1999)** — "Do Better Schools Matter? Parental Valuation of Elementary Education" — school district RD

## Methodological Advances

6. **Callaway & Sant'Anna (2021)** — "Difference-in-Differences with Multiple Time Periods" — staggered DID
7. **Sun & Abraham (2021)** — "Estimating Dynamic Treatment Effects in Event Studies with Heterogeneous Treatment Effects"
8. **Borusyak, Jaravel & Spiess (2024)** — "Revisiting Event-Study Designs: Robust and Efficient Estimation"

## Data/Tool References

9. **Zillow Research**: `https://www.zillow.com/research/data/`
10. **UK Land Registry**: `https://www.gov.uk/government/collections/price-paid-data`
11. **Singapore data.gov.sg**: `https://data.gov.sg/`
12. **MLIT Japan**: `https://www.land.mlit.go.jp/webland/`

## Appendix A: Dependencies

```bash
# Python environment
pip install pandas geopandas shapely pyproj osmnx
pip install statsmodels pyfixest spreg libpysal esda
pip install pyreadr openpyxl xlsxwriter
pip install requests coord-convert  # China coordinate conversion

# Optional
pip install eurostat  # Eurostat API
pip install dask-geopandas  # Large-scale spatial operations
```

## Appendix B: Singapore HDB Quick Start

End-to-end example: from download to hedonic regression.

```python
import pandas as pd
import geopandas as gpd
import numpy as np
from geopandas import sjoin_nearest
import statsmodels.formula.api as smf
import time
import requests

# === 1. Download HDB resale data ===
df = pd.read_csv("resale-flat-prices.csv")  # From data.gov.sg
df["date"] = pd.to_datetime(df["month"], format="%Y-%m")
df["price_sqm"] = df["resale_price"] / df["floor_area_sqm"]
df["lease_remaining"] = df["remaining_lease"].str.extract(r"(\d+)").astype(float)
df["building_age"] = df["date"].dt.year - df["lease_commence_date"]
df["storey_mid"] = df["storey_range"].str.extract(r"(\d+)").astype(int)

# === 2. Geocoding ===
def geocode_sg(address):
    url = "https://www.onemap.gov.sg/api/common/elastic/search"
    resp = requests.get(url, params={"searchVal": address, "returnGeom": "Y", "getAddrDetails": "Y"})
    results = resp.json().get("results", [])
    if results:
        return float(results[0]["LATITUDE"]), float(results[0]["LONGITUDE"])
    return None, None

unique_addr = df[["block", "street_name"]].drop_duplicates()
unique_addr["address"] = unique_addr["block"] + " " + unique_addr["street_name"]
coords = {}
for _, row in unique_addr.iterrows():
    lat, lon = geocode_sg(row["address"])
    coords[row["address"]] = (lat, lon)
    time.sleep(0.25)

df["address"] = df["block"] + " " + df["street_name"]
df["lat"] = df["address"].map(lambda a: coords.get(a, (None, None))[0])
df["lon"] = df["address"].map(lambda a: coords.get(a, (None, None))[1])

# === 3. Spatial variables ===
gdf = gpd.GeoDataFrame(df.dropna(subset=["lat", "lon"]),
                        geometry=gpd.points_from_xy(df.dropna(subset=["lat","lon"])["lon"],
                                                     df.dropna(subset=["lat","lon"])["lat"]),
                        crs="EPSG:4326").to_crs("EPSG:3414")

mrt = gpd.read_file("mrt_stations.geojson").to_crs("EPSG:3414")
gdf = sjoin_nearest(gdf, mrt[["station_name","geometry"]], how="left", distance_col="dist_mrt")

from shapely.geometry import Point
cbd = gpd.GeoSeries([Point(103.8515, 1.2819)], crs="EPSG:4326").to_crs("EPSG:3414").iloc[0]
gdf["dist_cbd"] = gdf.geometry.distance(cbd)

# === 4. Hedonic regression ===
gdf["year_quarter"] = gdf["date"].dt.to_period("Q").astype(str)
gdf["ln_price"] = np.log(gdf["resale_price"])

model = smf.ols(
    "ln_price ~ floor_area_sqm + storey_mid + building_age + lease_remaining"
    " + I(lease_remaining**2) + dist_mrt + dist_cbd"
    " + C(flat_type) + C(year_quarter)",
    data=gdf
).fit(cov_type="HC1")

print(model.summary())
```

## Appendix C: City/Country Parameter Quick Reference

| City/Country | CRS (Projection) | Geocoding API | CBD Coords (WGS84) | Data Source |
|-------------|------------------|---------------|---------------------|-------------|
| Singapore | EPSG:3414 | OneMap | 103.8515, 1.2819 | data.gov.sg HDB |
| Beijing | UTM 50N (32650) | Amap (GCJ-02) | 116.4074, 39.9042 | Lianjia |
| Shanghai | UTM 51N (32651) | Amap (GCJ-02) | 121.4737, 31.2304 | Lianjia |
| Shenzhen | UTM 50N (32650) | Amap (GCJ-02) | 114.0579, 22.5431 | Lianjia |
| Tokyo | EPSG:6677 (JGD2011) | MLIT / Yahoo JP | 139.7670, 35.6814 | MLIT |
| New York | EPSG:2263 (State Plane) | Census | -74.0060, 40.7128 | Zillow |
| London | EPSG:27700 (BNG) | OS / Nominatim | -0.1276, 51.5074 | Land Registry |
| Sydney | EPSG:28356 (MGA 56) | Google / Nominatim | 151.2093, -33.8688 | CoreLogic |
