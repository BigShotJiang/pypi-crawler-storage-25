# GTFS Data Acquisition — Full Reference

## What is GTFS

General Transit Feed Specification (通用公共交通信息规范).
Google-defined standard format describing bus/metro/light rail routes, stops, and schedules.

Core files:
```
gtfs.zip/
  agency.txt        # 运营机构
  routes.txt        # 线路（编号、类型）
  trips.txt         # 班次
  stop_times.txt    # 每班次的停靠时间表
  stops.txt         # 站点（经纬度）
  calendar.txt      # 运营日期规则
  calendar_dates.txt # 例外日期
  shapes.txt        # 线路几何（可选）
```

## Data Sources

| 地区 | 数据源 | URL / 获取方式 | 备注 |
|------|--------|---------------|------|
| **全球** | Mobility Database | https://mobilitydatabase.org | 1400+ 城市，最大 GTFS 聚合库 |
| **新加坡** | LTA DataMall | https://datamall.lta.gov.sg | 需注册 API key；含 MRT + Bus |
| **日本** | 国土数値情報 | https://nlftp.mlit.go.jp/ksj/ | GTFS-JP 格式（扩展版） |
| **日本（补充）** | OpenTripPlanner JP | 各交通局官网 | JR / 新幹線单独获取 |
| **中国（深圳）** | 深圳市交通运输局 | 深圳开放数据平台 | GTFS 公开 |
| **中国（上海）** | 上海公共数据平台 | data.sh.gov.cn | 部分公交线路 GTFS |
| **中国（其他）** | 百度/高德地图 API | API 调用 | 非 GTFS；需转换或用步行距离替代 |
| **美国** | transitfeeds.com | https://transitfeeds.com | 已迁移到 Mobility Database |
| **美国（旧金山）** | 511 SF Bay | https://511.org/open-data | 实时 + 静态 GTFS |
| **欧洲** | 各国 NeTEx → GTFS | EU NAP portals | 需格式转换 |
| **欧洲（德国）** | DELFI | https://www.delfi.de | 全国公交 GTFS |
| **欧洲（英国）** | Bus Open Data Service | https://data.bus-data.dft.gov.uk | 全国公交 GTFS |

## GTFS Download & Validation

```python
import zipfile
import pandas as pd
from pathlib import Path

def validate_gtfs(gtfs_path: str) -> dict:
    """验证 GTFS zip 文件的完整性"""
    required_files = ["agency.txt", "routes.txt", "trips.txt",
                      "stop_times.txt", "stops.txt", "calendar.txt"]
    optional_files = ["calendar_dates.txt", "shapes.txt", "frequencies.txt"]

    report = {"valid": True, "errors": [], "stats": {}}

    with zipfile.ZipFile(gtfs_path, "r") as zf:
        names = zf.namelist()

        for f in required_files:
            if f not in names:
                report["valid"] = False
                report["errors"].append(f"缺少必需文件: {f}")

        # 统计
        if "stops.txt" in names:
            stops = pd.read_csv(zf.open("stops.txt"))
            report["stats"]["n_stops"] = len(stops)
            report["stats"]["bbox"] = {
                "min_lat": stops["stop_lat"].min(),
                "max_lat": stops["stop_lat"].max(),
                "min_lon": stops["stop_lon"].min(),
                "max_lon": stops["stop_lon"].max(),
            }

        if "routes.txt" in names:
            routes = pd.read_csv(zf.open("routes.txt"))
            report["stats"]["n_routes"] = len(routes)
            report["stats"]["route_types"] = routes["route_type"].value_counts().to_dict()

        if "trips.txt" in names:
            trips = pd.read_csv(zf.open("trips.txt"))
            report["stats"]["n_trips"] = len(trips)

    return report
```

## route_type Codes

| route_type | 含义 |
|-----------|------|
| 0 | 有轨电车 (Tram) |
| 1 | 地铁 (Subway/Metro) |
| 2 | 铁路 (Rail) |
| 3 | 公共汽车 (Bus) |
| 4 | 轮渡 (Ferry) |
| 5 | 有线缆车 (Cable Tram) |
| 6 | 缆车/索道 (Aerial Lift) |
| 7 | 登山铁路 (Funicular) |
| 11 | 无轨电车 (Trolleybus) |
| 12 | 单轨 (Monorail) |

## Download via maestro-fetch

```bash
# 单个 GTFS 文件
maestro-fetch "https://transitfeeds.com/p/xxx/latest/download"

# 批量获取（Python）
from maestro_fetch import batch_fetch
urls = [
    "https://datamall.lta.gov.sg/content/dam/datamall/datasets/PublicTransportRelated/GTFS.zip",
    "https://transitfeeds.com/p/mta/79/latest/download",
]
results = batch_fetch(urls, output_dir="~/.maestro/cache/gtfs/")
```

## China GTFS Workaround

中国大多数城市没有公开 GTFS 数据。替代方案：
- 百度/高德地图路线规划 API → 获取点对点出行时间
- 爬取公交线路信息 → 自建 GTFS
- 使用步行 + 地铁站缓冲区的简化可达性（非 GTFS）

```python
# 百度地图方向 API（替代 GTFS）
import requests

def baidu_transit_time(origin, destination, ak):
    """
    使用百度地图 API 获取公交出行时间

    origin, destination: "lat,lon" 格式
    ak: 百度地图开发者 key
    """
    url = "https://api.map.baidu.com/direction/v2/transit"
    params = {
        "origin": origin,
        "destination": destination,
        "ak": ak,
        "coord_type": "wgs84",
    }
    resp = requests.get(url, params=params)
    data = resp.json()

    if data["status"] == 0 and data["result"]["routes"]:
        route = data["result"]["routes"][0]
        return route["duration"] / 60  # 秒 → 分钟
    return None
```
