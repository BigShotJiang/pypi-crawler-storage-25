# Gravity Model & Cumulative Opportunities — Full Reference

## Gravity Model Definition

```
A_i = Sigma_j (O_j x f(t_ij))
```

- `A_i`: accessibility index for location i
- `O_j`: attractiveness of destination j (jobs, GDP, services, etc.)
- `t_ij`: travel time from i to j (minutes)
- `f(t)`: distance decay function

## Decay Functions

| 函数 | 公式 | 参数 | 特点 |
|------|------|------|------|
| **负指数** | `exp(-beta x t)` | beta = 0.05-0.15 | 最常用；beta=0.1 时 30 分钟衰减到 ~5% |
| **幂函数** | `t^(-alpha)` | alpha = 1.0-2.0 | 距离弹性恒定 |
| **修正高斯** | `exp(-t^2 / (2*sigma^2))` | sigma = 20-40 | 短距离衰减慢，中距离急剧下降 |
| **logistic** | `1 / (1 + exp(gamma*(t - t0)))` | gamma, t0 | 阈值效应（如 45 分钟为"可接受通勤"） |

## Implementation

```python
import numpy as np
import pandas as pd

def gravity_accessibility(
    travel_time_matrix: pd.DataFrame,
    opportunities: pd.DataFrame,
    beta: float = 0.1,
    decay: str = "exponential",
    max_time: float = 90.0,
) -> pd.DataFrame:
    """
    计算引力模型可达性指数

    Parameters
    ----------
    travel_time_matrix : DataFrame
        列: from_id, to_id, travel_time (分钟)
    opportunities : DataFrame
        列: id, jobs (或其他吸引力指标)
    beta : float
        衰减参数
    decay : str
        衰减函数类型: "exponential", "power", "gaussian"
    max_time : float
        最大出行时间（超过此值视为不可达）

    Returns
    -------
    DataFrame: origin_id, accessibility
    """
    df = travel_time_matrix.merge(
        opportunities.rename(columns={"id": "to_id"}),
        on="to_id", how="left",
    )
    df = df[df["travel_time"] <= max_time].copy()

    t = df["travel_time"].values
    if decay == "exponential":
        df["weight"] = np.exp(-beta * t)
    elif decay == "power":
        df["weight"] = np.where(t > 0, t ** (-beta), 0)
    elif decay == "gaussian":
        sigma = 1.0 / beta
        df["weight"] = np.exp(-t**2 / (2 * sigma**2))
    else:
        raise ValueError(f"未知衰减函数: {decay}")

    df["weighted_opp"] = df["jobs"] * df["weight"]
    result = (
        df.groupby("from_id")["weighted_opp"]
        .sum().reset_index()
        .rename(columns={"from_id": "origin_id", "weighted_opp": "accessibility"})
    )
    return result
```

## Beta Calibration

beta 的选择对结果影响巨大。常见做法：

1. **文献值**: 通勤可达性通常 beta in [0.05, 0.15]
2. **半衰期法**: 设定半衰期 T_half（如 30 分钟），则 beta = ln(2) / T_half
3. **行为数据标定**: 用实际通勤流数据估计 beta（gravity model regression）

```python
# 半衰期 30 分钟
beta = np.log(2) / 30  # ~ 0.023

# 半衰期 15 分钟（更陡的衰减）
beta = np.log(2) / 15  # ~ 0.046
```

---

## Cumulative Opportunities

最简单的可达性指标：T 分钟内可达的就业岗位（或其他机会）总数。

```
C_i(T) = Sigma_j O_j x I(t_ij <= T)
```

I() is an indicator function: 1 if travel time <= T, else 0.

### Implementation

```python
def cumulative_opportunities(
    travel_time_matrix: pd.DataFrame,
    opportunities: pd.DataFrame,
    thresholds: list[int] = [30, 45, 60],
) -> pd.DataFrame:
    """
    计算累积机会可达性

    Returns: origin_id, jobs_30min, jobs_45min, jobs_60min
    """
    df = travel_time_matrix.merge(
        opportunities.rename(columns={"id": "to_id"}),
        on="to_id", how="left",
    )

    result = df[["from_id"]].drop_duplicates().rename(columns={"from_id": "origin_id"})

    for T in thresholds:
        reachable = df[df["travel_time"] <= T]
        agg = (
            reachable.groupby("from_id")["jobs"]
            .sum().reset_index()
            .rename(columns={"from_id": "origin_id", "jobs": f"jobs_{T}min"})
        )
        result = result.merge(agg, on="origin_id", how="left")
        result[f"jobs_{T}min"] = result[f"jobs_{T}min"].fillna(0).astype(int)

    return result
```

### Use Cases

- **政策报告**: 最直观（"该社区居民 30 分钟内可达 50 万个就业岗位"）
- **房价研究**: 多个阈值作为解释变量
- **公平性分析**: 低收入社区 vs 高收入社区的可达性差异
- **交通规划评估**: 新线路开通前后的可达性变化

### Limitations

- 阈值选择主观（30 还是 45 分钟？）
- 不区分"刚好 29 分钟可达"和"1 分钟可达"
- 建议同时报告引力模型作为稳健性检验
