# HSR Instrumental Variable — Full Reference

## Background

中国高铁（HSR）开通对区域经济的因果效应是热门研究主题。
核心难点：高铁选线非随机（内生性）。常用工具变量策略。

## Data Requirements

| 数据 | 来源 | 格式 |
|------|------|------|
| 高铁站经纬度 | 12306 爬取 / 铁路局公告 / Wikipedia | CSV: station_name, lat, lon |
| 高铁站开通年份 | 铁路局公告 / 新闻检索 | CSV: station_name, open_year |
| 地级市质心 | GADM / 统计年鉴 | Shapefile / CSV |
| 国家规划路径 | 《中长期铁路网规划》(2004/2008/2016) | 矢量化后 Shapefile |

## HSR Distance Panel Construction

```python
import geopandas as gpd
import numpy as np
from math import radians, sin, cos, sqrt, atan2

def haversine_km(lat1, lon1, lat2, lon2):
    """Haversine formula for great-circle distance (km)"""
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    return R * 2 * atan2(sqrt(a), sqrt(1-a))

def build_hsr_distance_panel(
    cities: gpd.GeoDataFrame,
    stations: pd.DataFrame,
    years: range,
    city_id_col: str = "city_id",
) -> pd.DataFrame:
    """
    构建城市-年度高铁距离面板

    输出列：city_id, year, dist_nearest_hsr_km, has_hsr, years_since_hsr
    """
    cities_wgs = cities.to_crs("EPSG:4326")
    pt = cities_wgs.geometry.representative_point()
    cities_wgs["city_lat"] = pt.y
    cities_wgs["city_lon"] = pt.x

    rows = []
    for year in years:
        open_stations = stations[stations["open_year"] <= year]

        for _, city in cities_wgs.iterrows():
            if len(open_stations) == 0:
                dist = np.nan
                has_hsr = 0
                years_since = np.nan
            else:
                dists = open_stations.apply(
                    lambda s: haversine_km(
                        city["city_lat"], city["city_lon"],
                        s["lat"], s["lon"]
                    ), axis=1,
                )
                dist = dists.min()
                has_hsr = int(dist <= 50)  # 50km threshold

                if has_hsr:
                    nearest_idx = dists.idxmin()
                    open_year = open_stations.loc[nearest_idx, "open_year"]
                    years_since = year - open_year
                else:
                    years_since = np.nan

            rows.append({
                city_id_col: city[city_id_col],
                "year": year,
                "dist_nearest_hsr_km": round(dist, 2) if not np.isnan(dist) else np.nan,
                "has_hsr": has_hsr,
                "years_since_hsr": years_since,
            })

    return pd.DataFrame(rows)
```

## Planned Route Distance (IV)

Core idea: use **distance to nationally planned route** (not actual distance) as IV.
Planned routes are based on geographic and political factors, not economic ones (satisfying exclusion restriction).

```python
from shapely.geometry import Point
from shapely.ops import nearest_points

def distance_to_planned_route(
    cities: gpd.GeoDataFrame,
    planned_route: gpd.GeoDataFrame,
) -> pd.DataFrame:
    """
    计算每个城市质心到规划路径的最近距离
    用作工具变量：距离规划路径越近 → 越可能获得高铁站
    """
    crs = cities.estimate_utm_crs()
    cities_proj = cities.to_crs(crs)
    route_proj = planned_route.to_crs(crs)
    route_union = route_proj.geometry.unary_union

    results = []
    for _, city in cities_proj.iterrows():
        centroid = city.geometry.representative_point()
        dist_m = centroid.distance(route_union)
        results.append({
            "city_id": city["city_id"],
            "dist_planned_route_km": round(dist_m / 1000, 2),
        })

    return pd.DataFrame(results)
```

## Common IV Strategies

| IV | 论文示例 | 思路 |
|----|---------|------|
| **规划路径距离** | Zheng & Kahn (2013) | 到 2004 年规划路径的距离（排除经济因素） |
| **历史铁路网** | Faber (2014) | 清末/民国铁路网是否经过 |
| **最小生成树** | Banerjee et al. (2020) | 连接主要城市的最短路径网络 |
| **直线连接** | Ahlfeldt & Feddersen (2018) | 主要节点之间的直线距离 |
| **地形成本** | 多篇 | 基于地形的最低成本路径 |

## Stata Regression Templates

```stata
* First stage
reg has_hsr dist_planned_route i.year i.city_id, cluster(city_id)

* 2SLS
ivregress 2sls ln_gdp (has_hsr = dist_planned_route) ///
    i.year i.city_id, cluster(city_id) first

* Event study form
forval t = -5/5 {
    gen D`t' = (years_since_hsr == `t')
}
reghdfe ln_gdp D*, absorb(city_id year) cluster(city_id)
```

## Station Location Gotcha

很多高铁站建在城市边缘（"高铁荒地"），简单的 `has_hsr` 虚拟变量忽略了站点到城区的连接问题。

Improvements:
- 用**到站点距离**（连续变量）而非 0/1 虚拟变量
- 考虑站点到市中心的公路距离（via OSRM）
- 区分"真正受益"（站点 + 配套交通）vs "名义受益"（有站但无配套）
