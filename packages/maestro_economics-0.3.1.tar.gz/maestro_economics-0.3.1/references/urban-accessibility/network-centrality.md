# OSM Network Centrality — Full Reference

## Concept

道路网络的拓扑结构影响区位价值。中心性（centrality）量化节点在网络中的"重要程度"。

| 中心性指标 | 含义 | 经济学解释 |
|-----------|------|-----------|
| **Betweenness** | 经过该节点的最短路径占比 | 交通流量/商业潜力 |
| **Closeness** | 到所有节点的平均最短路径倒数 | 整体可达性 |
| **Degree** | 连接的边数 | 交叉口复杂度 |
| **PageRank** | 加权连接重要性 | 网络中的"声望" |

## osmnx Download & Computation

```python
import osmnx as ox
import networkx as nx
import geopandas as gpd
import pandas as pd

# 1. Download road network
G = ox.graph_from_place("Singapore", network_type="drive")
# Or by bbox:
G = ox.graph_from_bbox(
    bbox=(1.22, 1.47, 103.6, 104.05),
    network_type="drive",
)

# 2. Basic info
print(f"节点数: {G.number_of_nodes()}")
print(f"边数: {G.number_of_edges()}")

# 3. Project to UTM (needed for distance-based calculations)
G_proj = ox.project_graph(G)

# 4. Compute centrality
# Note: betweenness_centrality is slow for large graphs; use approximation
bc = nx.betweenness_centrality(G, normalized=True, weight="length", k=500)
cc = nx.closeness_centrality(G, distance="length")

# 5. Set as node attributes
nx.set_node_attributes(G, bc, "betweenness")
nx.set_node_attributes(G, cc, "closeness")

# 6. Convert to GeoDataFrame
nodes_gdf = ox.graph_to_gdfs(G, edges=False)
nodes_gdf = nodes_gdf[["geometry", "betweenness", "closeness"]].copy()
```

## Aggregate to Districts

```python
districts = gpd.read_file("districts.shp").to_crs(nodes_gdf.crs)
joined = gpd.sjoin(nodes_gdf, districts, how="left", predicate="within")

district_centrality = (
    joined.groupby("district_id")
    .agg(
        mean_betweenness=("betweenness", "mean"),
        max_betweenness=("betweenness", "max"),
        mean_closeness=("closeness", "mean"),
        n_intersections=("betweenness", "count"),
    )
    .reset_index()
)
district_centrality.to_csv("district_centrality.csv", index=False)
```

## Walk Score Alternative

```python
G_walk = ox.graph_from_place("Singapore", network_type="walk")

amenities = ox.features_from_place(
    "Singapore",
    tags={
        "amenity": ["restaurant", "cafe", "supermarket", "school", "hospital"],
        "shop": True,
    },
)
amenities_points = amenities[amenities.geometry.type == "Point"]

from shapely.ops import nearest_points

def avg_distance_to_nearest_k(origin, pois, k=5):
    """到最近 k 个 POI 的平均距离"""
    dists = pois.geometry.distance(origin)
    return dists.nsmallest(k).mean()
```

## Performance Notes

- `betweenness_centrality` exact algorithm O(VE); Singapore (~60k nodes) ~10 min
- With `k=500` approximation: 1-2 min
- Do NOT load China national road network at once -- split by city
- `osmnx.graph_from_place` depends on Nominatim geocoding, may timeout; `graph_from_bbox` is more stable
- OSM data quality varies by region: Japan/Europe = high quality; rural China = incomplete
