# Isochrone Accessibility & Travel Time Matrix — Full Reference

## Core Tool: r5py

r5py is the Python wrapper for the Conveyal R5 routing engine.
R5 supports multimodal trips (walk + bus + metro), respecting timetables and transfers.

**Installation:**
- Java 17+ required (R5 is a JVM application)
- Docker recommended to avoid Java version conflicts

```bash
pip install r5py
java -version  # >= 17
```

## Travel Time Matrix Computation

```python
import r5py
import geopandas as gpd
from datetime import datetime, timedelta

# 1. Build transport network (OSM + GTFS)
transport_network = r5py.TransportNetwork(
    osm_pbf="singapore.osm.pbf",
    gtfs=["singapore_gtfs.zip"],
)

# 2. Prepare origins and destinations
origins = gpd.read_file("residential_centroids.geojson")
destinations = gpd.read_file("employment_centers.geojson")
origins["id"] = origins.index
destinations["id"] = destinations.index

# 3. Compute travel time matrix
ttm_computer = r5py.TravelTimeMatrixComputer(
    transport_network,
    origins=origins,
    destinations=destinations,
    transport_modes=[r5py.TransportMode.TRANSIT, r5py.TransportMode.WALK],
    departure=datetime(2024, 3, 15, 8, 0),
    departure_time_window=timedelta(minutes=60),
    max_time=timedelta(minutes=90),
    max_walks=timedelta(minutes=20),
)
travel_time_matrix = ttm_computer.compute_travel_times()
# Output: from_id, to_id, travel_time_p50 (minutes)
```

## Isochrone Generation

```python
isochrone_computer = r5py.IsochroneComputer(
    transport_network,
    origins=origins.iloc[[0]],
    transport_modes=[r5py.TransportMode.TRANSIT, r5py.TransportMode.WALK],
    departure=datetime(2024, 3, 15, 8, 30),
    max_time=timedelta(minutes=60),
    time_intervals=[
        timedelta(minutes=15),
        timedelta(minutes=30),
        timedelta(minutes=45),
        timedelta(minutes=60),
    ],
)
isochrones = isochrone_computer.compute_isochrones()
isochrones.to_file("isochrones.geojson", driver="GeoJSON")
```

## OSM PBF Data Download

```bash
# Geofabrik — country/region extracts
maestro-fetch "https://download.geofabrik.de/asia/singapore-latest.osm.pbf"
maestro-fetch "https://download.geofabrik.de/asia/japan-latest.osm.pbf"
maestro-fetch "https://download.geofabrik.de/asia/china-latest.osm.pbf"

# BBBike — city-level extracts
maestro-fetch "https://download.bbbike.org/osm/bbbike/Singapore/Singapore.osm.pbf"
```

## r5py Key Parameters

| 参数 | 含义 | 推荐值 |
|------|------|--------|
| `departure` | 出发时间 | 工作日早高峰 8:00-9:00 |
| `departure_time_window` | 时间窗口（取中位数） | 60 分钟 |
| `max_time` | 最大出行时间 | 60-90 分钟 |
| `max_walks` | 最大步行距离 | 15-20 分钟 |
| `transport_modes` | 出行方式组合 | TRANSIT + WALK |
| `percentiles` | 出行时间百分位数 | [50]（默认中位数） |

## Time Selection Strategy

**GTFS is date-specific.** Different dates/times yield very different accessibility.

1. **Pick representative weekday** (Tue/Wed/Thu)
2. **Use AM peak** (7:00-9:00) for commute accessibility
3. **For all-day accessibility**: compute multiple periods (AM peak + midday + PM peak), average
4. **Avoid holidays/summer** (reduced service)

```python
# Multi-period average accessibility
time_slots = [
    datetime(2024, 3, 13, 7, 0),   # AM peak
    datetime(2024, 3, 13, 12, 0),  # midday
    datetime(2024, 3, 13, 18, 0),  # PM peak
]

all_ttm = []
for dep_time in time_slots:
    ttm = r5py.TravelTimeMatrixComputer(
        transport_network, origins=origins, destinations=destinations,
        transport_modes=[r5py.TransportMode.TRANSIT, r5py.TransportMode.WALK],
        departure=dep_time,
        departure_time_window=timedelta(minutes=60),
        max_time=timedelta(minutes=90),
    ).compute_travel_times()
    ttm["slot"] = dep_time.hour
    all_ttm.append(ttm)

combined = pd.concat(all_ttm)
avg_ttm = combined.groupby(["from_id", "to_id"])["travel_time_p50"].mean().reset_index()
```

## Batch Computation for Large Matrices

N origins x M destinations can be very large. 10000x10000 = 100M rows = memory explosion.

```python
import numpy as np

batch_size = 500
n_origins = len(origins)
all_results = []

for i in range(0, n_origins, batch_size):
    batch = origins.iloc[i:i+batch_size]
    ttm = r5py.TravelTimeMatrixComputer(
        transport_network,
        origins=batch,
        destinations=destinations,
        transport_modes=[r5py.TransportMode.TRANSIT, r5py.TransportMode.WALK],
        departure=datetime(2024, 3, 15, 8, 0),
        max_time=timedelta(minutes=60),
    ).compute_travel_times()
    all_results.append(ttm)
    print(f"完成 {min(i+batch_size, n_origins)}/{n_origins}")

full_ttm = pd.concat(all_results, ignore_index=True)
```
