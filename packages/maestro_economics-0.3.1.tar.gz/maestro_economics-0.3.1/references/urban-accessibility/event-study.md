# Transit Shock Event Study — Full Reference

## Research Design Template

**Scenario**: New metro station / HSR station / BRT line opening -> impact on nearby housing prices / employment / business activity.

## Step 1: Treatment & Control Group Definition

```python
import geopandas as gpd
from shapely.geometry import Point

def define_treatment_control(
    units: gpd.GeoDataFrame,
    new_stations: gpd.GeoDataFrame,
    treatment_buffer_m: float = 1000,
    control_inner_m: float = 1000,
    control_outer_m: float = 3000,
) -> gpd.GeoDataFrame:
    """
    Treatment: distance to new station <= treatment_buffer_m
    Control: distance to new station in (control_inner_m, control_outer_m]
    """
    crs = units.estimate_utm_crs()
    units_proj = units.to_crs(crs)
    stations_proj = new_stations.to_crs(crs)

    treatment_zone = stations_proj.geometry.buffer(treatment_buffer_m).unary_union
    control_inner = stations_proj.geometry.buffer(control_inner_m).unary_union
    control_outer = stations_proj.geometry.buffer(control_outer_m).unary_union

    units_proj["treated"] = units_proj.geometry.within(treatment_zone).astype(int)
    in_outer = units_proj.geometry.within(control_outer)
    in_inner = units_proj.geometry.within(control_inner)
    units_proj["control"] = ((in_outer) & (~in_inner)).astype(int)

    result = units_proj[
        (units_proj["treated"] == 1) | (units_proj["control"] == 1)
    ].copy()
    result["group"] = result["treated"].map({1: "treatment", 0: "control"})
    return result
```

## Step 2: Event Study Data Preparation

```python
def prepare_event_study_data(
    panel: pd.DataFrame,
    event_date_col: str = "station_open_date",
    time_col: str = "year_month",
    unit_col: str = "unit_id",
    treat_col: str = "treated",
) -> pd.DataFrame:
    """Generate relative time dummies for event study"""
    panel = panel.copy()

    panel["rel_time"] = (
        pd.to_datetime(panel[time_col]) - pd.to_datetime(panel[event_date_col])
    ).dt.days // 30

    panel["rel_time"] = panel["rel_time"].clip(-24, 24)

    for t in range(-24, 25):
        if t == -1:  # baseline period
            continue
        panel[f"D_{t}"] = ((panel[treat_col] == 1) & (panel["rel_time"] == t)).astype(int)

    return panel
```

## Step 3: Parallel Trends Test

```python
def test_parallel_trends(
    panel: pd.DataFrame,
    outcome_col: str,
    pre_period: tuple = (-24, -2),
) -> dict:
    """Test pre-treatment parallel trends (joint F-test on pre-period dummies)"""
    pre_dummies = [
        f"D_{t}" for t in range(pre_period[0], pre_period[1] + 1)
        if t != -1 and f"D_{t}" in panel.columns
    ]

    import statsmodels.api as sm

    X = panel[pre_dummies + ["treated"]].copy()
    X = sm.add_constant(X)
    y = panel[outcome_col]

    model = sm.OLS(y, X, missing="drop").fit(
        cov_type="cluster", cov_kwds={"groups": panel["unit_id"]}
    )

    f_test = model.f_test(" = ".join([f"{d} = 0" for d in pre_dummies]))

    return {
        "f_statistic": float(f_test.fvalue),
        "p_value": float(f_test.pvalue),
        "pre_coefficients": {d: model.params[d] for d in pre_dummies},
        "conclusion": "通过" if float(f_test.pvalue) > 0.10 else "未通过（慎重解读结果）",
    }
```

## Stata Event Study Template

```stata
* Data prep
gen rel_time = ym(year, month) - ym(open_year, open_month)
replace rel_time = -24 if rel_time < -24
replace rel_time = 24 if rel_time > 24

* Event study (baseline t=-1)
reghdfe ln_price ib(-1).rel_time#1.treated, ///
    absorb(unit_id year_month) cluster(district_id)

* Plot
coefplot, keep(*.rel_time#1.treated) ///
    vertical yline(0) xline(-0.5, lpattern(dash)) ///
    title("Event Study: Transit Station Opening") ///
    xtitle("Months Relative to Opening") ytitle("Effect on Log Price")

* For staggered adoption, use newer methods:
* did_multiplegt, csdid, eventstudyinteract
```

## Staggered DiD Methods

When different stations open at different times, traditional TWFE is biased. Use:

| 方法 | Stata 包 | Python |
|------|---------|--------|
| Callaway & Sant'Anna (2021) | `csdid` | `csdid` (Python port) |
| Sun & Abraham (2021) | `eventstudyinteract` | — |
| de Chaisemartin & D'Haultfoeuille (2020) | `did_multiplegt` | — |
| Borusyak et al. (2024) | `did_imputation` | — |

```stata
* Callaway & Sant'Anna
csdid ln_price, ivar(unit_id) time(year_month) gvar(first_treated) ///
    agg(event) notyet

* Event study plot
csdid_plot, title("CS Event Study")
```
