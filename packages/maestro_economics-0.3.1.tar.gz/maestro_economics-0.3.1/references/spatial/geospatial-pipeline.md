# Geospatial Data Pipeline Reference

## 1. CRS Quick Reference

| EPSG | Name | Units | Use Case |
|------|------|-------|----------|
| 4326 | WGS 84 | Degrees | Storage, GPS, data interchange |
| 3857 | Web Mercator | Meters | Web maps only. NEVER for area/distance |
| UTM zones | UTM | Meters | Local area/distance/buffer (auto-detect) |
| 6933 | NSIDC EASE-Grid 2.0 | Meters | Global equal-area analysis |
| 54009 | Mollweide | Meters | Global equal-area thematic maps |

## 2. CRS Decision Tree

```
What operation?
  area/buffer/length/distance -> Projected CRS required
    Regional (one country)? -> estimate_utm_crs()
    Global dataset?         -> EPSG:6933
  storage/exchange          -> EPSG:4326
  web map display           -> EPSG:3857 (display ONLY)
  sjoin/overlay             -> Same CRS for both inputs (4326 is fine for sjoin)
```

| Operation | CRS Requirement | Recommended |
|-----------|----------------|-------------|
| `gpd.read_file()` | Any | As-is from source |
| `gpd.sjoin()` | Same CRS both inputs | EPSG:4326 is fine |
| `.buffer(d)` | Projected (meters) | `estimate_utm_crs()` |
| `.area` | Projected (meters) | EPSG:6933 or UTM |
| `.length` | Projected (meters) | `estimate_utm_crs()` |
| `gpd.overlay()` | Same CRS both inputs | Projected preferred |
| `.dissolve()` | Any | As-is |
| `.to_file()` | Any | EPSG:4326 for interchange |

## 3. Reading Shapefiles

```python
import geopandas as gpd

# Basic (pyogrio engine is default in gpd >= 0.14, 10x faster)
gdf = gpd.read_file("path.shp", engine="pyogrio")

# Bbox filter -- pre-filter before loading into memory
gdf = gpd.read_file("path.shp", bbox=(xmin, ymin, xmax, ymax))

# Column + row filter
gdf = gpd.read_file("path.shp", columns=["ADM2_EN", "geometry"], rows=slice(0, 1000))

# Arrow backend for maximum read speed
gdf = gpd.read_file("large.shp", engine="pyogrio", use_arrow=True)

# GeoParquet (smaller, faster, columnar -- prefer over shapefile)
gdf = gpd.read_parquet("data.parquet")
gdf.to_parquet("data.parquet")
```

### CRS: set_crs vs to_crs

```python
# set_crs: DECLARE what the CRS is (no coordinate transformation)
gdf = gdf.set_crs(epsg=4326)

# to_crs: TRANSFORM coordinates to new CRS (actual reprojection)
gdf_proj = gdf.to_crs(epsg=3857)

# Auto-detect best UTM zone
utm_crs = gdf.estimate_utm_crs()
gdf_proj = gdf.to_crs(utm_crs)
```

## 4. Buffer Operations

MUST project to meters-based CRS first. Buffer distance unit = CRS unit.

```python
# Standard pattern: project -> buffer -> (optionally) reproject back
gdf_proj = gdf.to_crs(gdf.estimate_utm_crs())
gdf_proj["buffer_100km"] = gdf_proj.geometry.buffer(100_000)  # meters
gdf_result = gdf_proj.to_crs(epsg=4326)  # back to 4326 for storage

# Multiple distances
for d_km in [50, 100, 200]:
    gdf_proj[f"buffer_{d_km}km"] = gdf_proj.geometry.buffer(d_km * 1000)
```

## 5. Spatial Joins

### sjoin -- join by spatial relationship

```python
# BOTH inputs MUST share same CRS
result = gpd.sjoin(left_gdf, right_gdf, how="inner", predicate="intersects")
result = result.reset_index(drop=True)  # fix duplicate index
```

### Predicates

| Predicate | Meaning |
|-----------|---------|
| `intersects` | Any spatial overlap (most common, default) |
| `within` | Left entirely inside right |
| `contains` | Left entirely contains right |
| `touches` | Share boundary, no interior overlap |
| `crosses` | Geometries cross each other |

### sjoin_nearest -- join by proximity

```python
result = gpd.sjoin_nearest(
    points, polygons,
    how="inner",
    max_distance=100_000,       # meters (requires projected CRS)
    distance_col="dist_meters",
)
```

## 6. Shared Boundary Detection (Cross-Border Neighbors)

```python
def find_cross_border_neighbors(gdf_a, gdf_b, id_a, id_b):
    """Find shared boundary lengths between two admin shapefiles.
    Returns DataFrame sorted by shared_length_km descending."""
    utm = gdf_a.estimate_utm_crs()
    a, b = gdf_a.to_crs(utm), gdf_b.to_crs(utm)
    a["geometry"] = a.geometry.make_valid()
    b["geometry"] = b.geometry.make_valid()

    # Vectorized: overlay boundary lines
    a_lines = a.copy(); a_lines["geometry"] = a_lines.geometry.boundary
    b_lines = b.copy(); b_lines["geometry"] = b_lines.geometry.boundary
    shared = gpd.overlay(a_lines, b_lines, how="intersection")
    shared["shared_length_km"] = shared.geometry.length / 1000
    return shared[shared["shared_length_km"] > 0].sort_values(
        "shared_length_km", ascending=False
    )
```

Usage (India-Bangladesh style):

```python
india = gpd.read_file("india_adm2.shp")
bangladesh = gpd.read_file("bangladesh_adm2.shp")
pairs = find_cross_border_neighbors(india, bangladesh, "ADM2_EN", "ADM2_EN")

# Group by pair, sum multi-segment borders
totals = (pairs.groupby(["ADM2_EN_1", "ADM2_EN_2"])
          .agg(shared_km=("shared_length_km", "sum"))
          .reset_index().sort_values("shared_km", ascending=False))
```

## 7. Overlay Operations

```python
gpd.overlay(df1, df2, how="intersection")        # area in BOTH
gpd.overlay(df1, df2, how="union")                # all areas combined
gpd.overlay(df1, df2, how="difference")           # df1 NOT in df2
gpd.overlay(df1, df2, how="symmetric_difference") # in one but NOT both
gpd.overlay(df1, df2, how="identity")             # df1 partitioned by df2
```

### Land use within buffer (practical recipe)

```python
proj = projects.estimate_utm_crs()
buffer_gdf = projects.to_crs(proj).copy()
buffer_gdf["geometry"] = buffer_gdf.buffer(100_000)
landuse_proj = landuse.to_crs(proj)

clipped = gpd.overlay(landuse_proj, buffer_gdf, how="intersection")
clipped["area_sqkm"] = clipped.area / 1e6
summary = clipped.groupby("landuse_type")["area_sqkm"].sum().reset_index()
summary["pct"] = (summary["area_sqkm"] / summary["area_sqkm"].sum() * 100).round(2)
```

## 8. Area and Length Calculation

```python
# ALWAYS project first. Geographic CRS gives square degrees (meaningless).
gdf_proj = gdf.to_crs(gdf.estimate_utm_crs())   # local
# or gdf.to_crs(epsg=6933)                       # global equal-area

gdf_proj["area_sqm"]  = gdf_proj.area
gdf_proj["area_sqkm"] = gdf_proj.area / 1e6
gdf_proj["area_ha"]   = gdf_proj.area / 1e4
gdf_proj["length_m"]  = gdf_proj.length
```

### Percentage example: forest cover by district

```python
districts = gpd.read_file("districts.shp").to_crs(epsg=6933)
forest = gpd.read_file("forest.shp").to_crs(epsg=6933)
clipped = gpd.overlay(forest, districts, how="intersection")
clipped["forest_sqkm"] = clipped.area / 1e6
forest_sum = clipped.groupby("district_id")["forest_sqkm"].sum().reset_index()
districts["total_sqkm"] = districts.area / 1e6
result = districts.merge(forest_sum, on="district_id", how="left")
result["forest_pct"] = (result["forest_sqkm"] / result["total_sqkm"] * 100).round(2)
```

## 9. Dissolve and Aggregation

```python
# Dissolve ADM2 -> ADM1 (union geometries, aggregate attributes)
adm1 = adm2.dissolve(by="ADM1_EN", aggfunc="sum")

# Multiple aggregation functions
adm1 = adm2.dissolve(by="ADM1_EN", aggfunc={
    "population": "sum", "area_sqkm": "sum", "gdp_pc": "mean",
})

# Dissolve everything into one geometry
country = adm2.dissolve()
```

## 10. Zonal Statistics

| Tool | Backend | Fractional pixels | Speed (48k+ polygons) | Use when |
|------|---------|-------------------|-----------------------|----------|
| `rasterstats` | Python | No | Slow | Small datasets, quick prototyping |
| `exactextract` | C++ | Yes | Fast | Production, large polygon counts |

```python
# rasterstats
from rasterstats import zonal_stats
stats = zonal_stats(polygons, "raster.tif",
    stats=["count", "min", "mean", "max", "sum"])
stats_df = pd.DataFrame(stats)
result = pd.concat([polygons, stats_df], axis=1)

# exactextract (PREFERRED for 48k+ polygons)
from exactextract import exact_extract
result = exact_extract("raster.tif", polygons,
    ["mean", "sum", "count"],
    include_cols=["district_id"], output="pandas")
```

## 11. Panel Data Integration

### Spatial join -> tabular panel

```python
# Assign admin codes to point locations
projects_coded = gpd.sjoin(
    projects.to_crs(adm2.crs),
    adm2[["ADM2_CODE", "ADM2_EN", "geometry"]],
    how="left", predicate="within",
)
panel = pd.DataFrame(projects_coded.drop(columns="geometry"))
```

### Multi-year zonal stats -> panel

```python
from exactextract import exact_extract

panels = []
for year in range(2000, 2024):
    stats = exact_extract(f"nightlights_{year}.tif", adm2,
        ["mean", "sum"], include_cols=["ADM2_CODE"], output="pandas")
    stats["year"] = year
    panels.append(stats)

panel = pd.concat(panels, ignore_index=True)
# Pivot: panel.pivot(index="ADM2_CODE", columns="year", values="mean")
```

### Spatial attributes for regression

```python
adm2_proj = adm2.to_crs(adm2.estimate_utm_crs())
adm2["area_sqkm"] = adm2_proj.area / 1e6
adm2["centroid_lat"] = adm2.geometry.centroid.y
adm2["centroid_lon"] = adm2.geometry.centroid.x
tabular = pd.DataFrame(adm2.drop(columns="geometry"))
```

## 12. Performance Tips

### Spatial index (automatic in sjoin/overlay)

```python
# Manual sindex for custom queries
candidates = gdf.sindex.query(query_geom, predicate="intersects")

# Bulk query (array of geometries)
tree_idx, input_idx = gdf.sindex.query(other_gdf.geometry.values, predicate="intersects")
```

### Simplify geometries

```python
gdf["geometry"] = gdf.geometry.simplify(tolerance=100, preserve_topology=True)
# tolerance in CRS units (100m for projected). Use for joins, not final output.
```

### Chunk processing for large files

```python
offset = 0
results = []
while True:
    chunk = gpd.read_file("huge.shp", rows=slice(offset, offset + 10000))
    if len(chunk) == 0:
        break
    results.append(gpd.sjoin(chunk, small_gdf, predicate="intersects"))
    offset += 10000
result = pd.concat(results, ignore_index=True)
```

### Memory reduction

```python
gdf = gdf[["id", "name", "geometry"]]            # drop unused columns
for c in gdf.select_dtypes("float64").columns:
    if c != "geometry": gdf[c] = gdf[c].astype("float32")
gdf.to_parquet("data.parquet")                    # GeoParquet > Shapefile
```

### Shapely 2.0 vectorized ops (no Python loop)

```python
import shapely
shared = shapely.intersection(gdf_a.geometry.values, gdf_b.geometry.values)
dists = shapely.distance(gdf_a.geometry.values, gdf_b.geometry.values)
```

## 13. Common Pitfalls

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| CRS mismatch in sjoin | Silent wrong results or ValueError | `gdf_b = gdf_b.to_crs(gdf_a.crs)` before join |
| Buffer/area in EPSG:4326 | Units in degrees, planet-sized buffers | Project first: `gdf.to_crs(gdf.estimate_utm_crs())` |
| `set_crs` when you mean `to_crs` | Coordinates unchanged, labeled wrong | `set_crs` = declare; `to_crs` = transform |
| EPSG:3857 for area | Severe distortion at high latitudes | Use EPSG:6933 or UTM for area |
| Invalid geometries | Overlay/sjoin errors or silent drops | `gdf["geometry"] = gdf.geometry.make_valid()` |
| Duplicate index after sjoin | Unexpected behavior in subsequent ops | `.reset_index(drop=True)` after sjoin |
| `make_valid()` returns GeometryCollection | Mixed types break downstream ops | Filter: `gdf[gdf.geom_type.isin(["Polygon","MultiPolygon"])]` |
| No .prj file | `gdf.crs is None` | `gdf.set_crs(epsg=4326)` (verify source docs) |
| Forgetting `keep_geom_type=True` in overlay | Mixed geometry types in output | `gpd.overlay(a, b, how="intersection", keep_geom_type=True)` |
