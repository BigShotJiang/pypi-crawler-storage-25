
# Maestro Data Global

Multi-country sub-national economic data platform for economics research.

---

## 1. Output Schema (Universal)

All adapters output the same FIELDNAMES (matches fusion_pipeline.py):

```
geo_level | geo_code_raw | geo_code_ns | nbs_code | geo_name | province
year | crop_code | crop_cn | area_ha | yield_kg_ha | production_ton
source_id | priority | quality_grade
```

GDP/macro rows extend with: `country_iso | variable_code | value | unit`

---

## 2. Country Priority Tiers

**Tier 1 — County/District level (most valuable for economics research)**

| Country | Dataset | Level | Years | Status |
|---------|---------|-------|-------|--------|
| China | Gazetteer OCR (this project) | county | 1900-2005 | ✅ done |
| China | SciDB Northeast | county | 1949-2010 | ✅ integrated |
| India | ICRISAT DLD | district | 1966-2017 | ✅ adapter ready |
| Brazil | IBGE PAM | municipality | 1974-2023 | ✅ adapter ready |

**Tier 2 — Province/State level**

| Country | Dataset | Level | Years | Status |
|---------|---------|-------|-------|--------|
| 83 countries | DOSE V2.11 | region | 1953-2020 | ✅ adapter ready |
| Indonesia | BPS Kabupaten | kabupaten | 2000- | pending |
| Vietnam | GSO | province | 1995- | pending |

**Tier 3 — Future OCR targets (high value, require scanning)**

| Target | Source | Notes |
|--------|--------|-------|
| India pre-1966 | Season & Crop Reports 1884-1966 | British Library PDFs |
| British Africa | Colonial crop returns 1900-1960 | ~200-500 districts |
| China 1986-2005 | 二轮志书 (Second edition gazetteers) | hljszw.org.cn etc. |

---

## 3. Integrated Datasets

| source_id | Rows | Countries | Level | Variables |
|-----------|------|-----------|-------|-----------|
| `icrisat_dld_india` | 171k | IND | district | area+yield+production, 15 crops |
| `ibge_pam_brazil` | ~19k/yr | BRA | municipality | area+yield+production, 12 crops |
| `dose_gdp_global` | 244k | 83 | region | GDP pc + sectoral (ag/mfg/svc) + pop |
| `gazetteer_ocr` | 3,583 | CHN | county | area+yield+production, 8 crops |
| `scidb_ne_1949` | 24,400 | CHN | county | production+area+yield, 5 crops |
| `plosone_2016` | 210,425 | CHN | county | yield only, 3 crops |
| `mapspam` | 24,457 | CHN | county | area+yield, 7 crops |

---

## 4. Dataset Registry CLI

All acquisition tasks tracked in `~/.maestro/datasets.db → processing_tasks`.

```bash
# Check status of all tasks
python scripts/global/registry.py status

# Find next pending task
python scripts/global/registry.py next

# Add new task
python scripts/global/registry.py add <source_id> <task_type> --priority 1 --note "..."
# task_type: download | parse | crosswalk | integrate | qa

# Mark done / fail
python scripts/global/registry.py done <task_id>
python scripts/global/registry.py fail <task_id> --note "reason"
```

---

## 5. Running Adapters

```bash
# India (ICRISAT DLD — API, ~12MB, one-time download)
python scripts/global/adapters/india/icrisat_dld.py --output /tmp/icrisat_panel.csv

# Brazil (IBGE SIDRA API — ~19k rows/year, cached per crop×year)
python scripts/global/adapters/brazil/ibge_pam.py --years 1974-2023 --output /tmp/ibge_pam_panel.csv

# Global GDP (DOSE V2.11 — requires ~/.maestro/cache/dose_v2.csv)
python scripts/global/adapters/global/dose_gdp.py --output /tmp/dose_panel.csv
```

**ICRISAT API note:** Uses REST API at `http://data.icrisat.org/dldAPI/`.
Download endpoint: `GET /apportioned/area-production-yield` (returns all at once, ~12MB JSON, no pagination).
The old XLS file download (`/dld/src/Rice.xls`) is dead as of 2026-03.
Response layout: 16 static columns + 75 data columns (25 crops x 3 elements). Units: AREA=1000ha, PRODUCTION=1000tons, YIELD=kg/ha.

**IBGE note:** Classification code is **81** (not 82). Variable 112 = yield (kg/ha).
Per-crop requests are mandatory (all-crops request returns HTTP 500 for all municipalities).
Response structure: `series` is a **LIST** (not dict) of `{localidade:{id,nome}, serie:{year:val}}` — iterate, don't index by key.

**DOSE note:** Record ID is **16313760** (V2.11). Columns: GID_1 (GADM L1), no GID_2.
GDP is per-capita only (grp_pc_usd); total GDP requires × pop.

---

## 6. Adapter Pattern

Every adapter must output the universal FIELDNAMES and:
1. Apply yield caps per crop (see fusion skill Section 6)
2. Skip rows where area_ha ≤ 0 or all three quantity fields are NULL
3. Use `geo_code_ns` tag: `icrisat` | `ibge` | `gadm` | `bps` | `gso`
4. Set `source_id` = dataset registry ID
5. Set `priority` = 2 (medium); OCR data uses priority = 1 (highest)

```python
FIELDNAMES = [
    'geo_level', 'geo_code_raw', 'geo_code_ns', 'nbs_code',
    'geo_name', 'province', 'year', 'crop_code', 'crop_cn',
    'area_ha', 'yield_kg_ha', 'production_ton',
    'source_id', 'priority', 'quality_grade',
]
```

---

## 7. Data Gaps (Future Work)

| Gap | Impact | Approach |
|-----|--------|----------|
| India district crop 1884-1966 | 80yr pre-Green Revolution | OCR Season & Crop Reports |
| Indonesia kabupaten agriculture | 270M pop country | BPS Kabupaten API |
| Vietnam province agriculture | Doi Moi transition | GSO API or manual |
| China 1986-2005 county | Fills gap after 一轮志书 | 二轮志书 OCR |
| British Africa colony data | Colonial economics research | Archive scanning |

---

## 8. Reference Files

| File | Description |
|------|-------------|
| `scripts/global/registry.py` | Processing task state machine CLI |
| `scripts/global/adapters/india/icrisat_dld.py` | ICRISAT DLD REST API adapter |
| `scripts/global/adapters/brazil/ibge_pam.py` | IBGE SIDRA API adapter |
| `scripts/global/adapters/global/dose_gdp.py` | DOSE V2.11 CSV adapter |
| `~/.maestro/datasets.db` | Dataset registry + processing_tasks |
| `~/.maestro/cache/dose_v2.csv` | DOSE V2.11 CSV (15.9 MB) |
| `~/.maestro/cache/icrisat_dld/` | ICRISAT JSON cache (~12 MB) |
| `~/.maestro/cache/ibge_pam/` | IBGE per-crop-year JSON cache |
