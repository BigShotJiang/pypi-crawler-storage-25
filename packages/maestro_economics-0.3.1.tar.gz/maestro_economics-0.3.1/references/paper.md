
# Maestro Paper -- QJE/JPE Academic Paper Writing SOP

Produce publication-quality empirical economics papers from analysis outputs.
Standard: QJE, JPE, AEJ:Applied. Fallback: AER, REStat, JUE.

--------------------------------------------------------------------------------

## 1. When to Invoke

**Yes**:
- User has analysis results (tables, figures, estimates.csv) and wants a draft
- User wants to improve an existing draft to QJE/JPE standard
- User wants to audit paper structure, section lengths, or table formatting
- User wants to prepare for SSRN or journal submission

**No**:
- Regressions not run yet (use maestro-analysis)
- Data not cleaned (use maestro-data-analyst)
- Literature search not done (use maestro-lit-review, or run concurrently)

--------------------------------------------------------------------------------

## 2. Input Requirements

### Required

| Input | Typical Location | Description |
|-------|-----------------|-------------|
| Regression tables (.tex) | `05-analysis/results/tables/` | booktabs-formatted |
| Key estimates | `05-analysis/results/estimates.csv` | coef, se, pvalue, N per spec |
| Figures (.pdf) | `05-analysis/results/figures/` | event study, coef plot, etc. |
| Research question doc | `00-brief/` or inline | Hypotheses, ID strategy |
| Data description | `README.md` or `codebook.xlsx` | Variables, sources, coverage |

### Validation Checklist

- [ ] At least one baseline regression table is ready
- [ ] estimates.csv contains quantitative coefficients (not just significance flags)
- [ ] Sample size (N) and unit of observation are documented
- [ ] Identification assumption is stated (even informally)
- [ ] Time period and geography of data are known

--------------------------------------------------------------------------------

## 3. Paper Structure (abbreviated)

Target: 45-55 pages double-spaced + 15-25 page online appendix.

| Section | Pages | Words | Key Rule |
|---------|-------|-------|----------|
| Abstract | — | 150-200 | No citations; one sentence per beat; quantified findings |
| Introduction | 8-10 | 2,500-3,000 | Open with fact not lit; RQ by para 3; quantified findings |
| Institutional Background | 3-5 | 900-1,500 | Only details used in analysis; not a lit review |
| Data | 5-8 | 1,500-2,500 | Table 1 = summary stats ALWAYS; define every variable |
| Empirical Strategy | 5-8 | 1,500-2,500 | Displayed equation; define all symbols; ID assumption + threats |
| Results | 10-15 | 3,000-4,500 | Economic magnitude for EVERY key coefficient |
| Robustness | 4-6 | 1,200-1,800 | One paragraph per check; link each to specific threat |
| Discussion | 3-4 | 900-1,200 | Mechanism + policy + limitations |
| Conclusion | 2-3 | 600-900 | No new results; restate quantitatively |
| Appendix | 15-25 | — | Data sources, variable defs, full robustness tables |

> Full section-by-section SOP: `references/paper-structure.md`

--------------------------------------------------------------------------------

## 4. Key Rules

1. **Quantify everything**: every key coefficient needs point estimate, SE, p-value, AND economic magnitude (dollars/SDs/percent of mean)
2. **Active voice**: "We find that..." not "It was found that..."
3. **booktabs only**: `\toprule`/`\midrule`/`\bottomrule` -- never `\hline`
4. **Table notes mandatory**: DV, FE, SE clustering, star convention
5. **Null results**: never "fail to reject the null" -- interpret + bound effect size

> Full writing conventions: `references/writing-conventions.md`
> LaTeX boilerplate and conventions: `references/latex-conventions.md`

--------------------------------------------------------------------------------

## 5. Execution Protocol (10 steps)

1. **Read all inputs**: load estimates.csv, list tables and figures
2. **Audit existing draft** (if any): `python scripts/paper_audit.py paper.tex --output audit_report.txt` -- fix all FAIL items
3. **Draft Data section** first (establishes notation)
4. **Draft Empirical Strategy** (builds on data notation)
5. **Compute economic magnitudes** for all key coefficients before writing results
6. **Draft Results** (references strategy and data)
7. **Draft remaining sections**: Robustness, Discussion, Institutional Background, Introduction (write last), Abstract (distill intro), Conclusion, Appendix
8. **Run wordcount.py**: `python scripts/wordcount.py paper.tex --target qje` -- sections >30% above target: cut; >30% below: expand
9. **Run table_check.py**: `python scripts/table_check.py tables/` -- every table must pass
10. **Compile**: `pdflatex && bibtex && pdflatex && pdflatex` -- zero undefined refs, zero missing citations

--------------------------------------------------------------------------------

## 6. Gotchas / Common Failure Modes

| Failure Mode | Fix |
|---|---|
| Abstract has method but no results | Add quantitative main finding |
| Introduction too slow (RQ after para 3) | Move RQ to para 2 |
| Table notes missing | Add notes with DV, FE, SE spec |
| No economic magnitude | Compute dollar/SD effect |
| Robustness not linked to threat | State threat addressed per check |
| Null result dismissed | Interpret + bound effect size from CI |
| Conclusion has new results | Move to results section |
| Wrong citation style (`\cite{}`) | Replace with `\citet{}`/`\citep{}` |
| LaTeX booktabs + siunitx clash | Test compilation early; some journal templates conflict |
| `\input` vs `\include` for appendix | `\include` starts new page, `\input` doesn't. Use `\input` for inline appendix |
| pgfplots axis limits wrong with outliers | Set xmin/xmax/ymin/ymax explicitly |
| BibTeX accented characters | Use braces `{\'e}` not Unicode in .bib files for portability |

--------------------------------------------------------------------------------

## 7. CLI Quick Reference

```bash
# Audit paper structure
python scripts/paper_audit.py 06-paper/paper.tex --output audit_report.txt

# Check section word counts vs QJE targets
python scripts/wordcount.py 06-paper/paper.tex --target qje

# Check table formatting
python scripts/table_check.py 05-analysis/results/tables/

# Compile
cd 06-paper/ && pdflatex paper.tex && bibtex paper && pdflatex paper.tex && pdflatex paper.tex
```

--------------------------------------------------------------------------------

## 8. Cross-References

| Direction | Skill | What flows |
|---|---|---|
| Input from | maestro-analysis | Tables (.tex), figures (.pdf), estimates.csv |
| Input from | maestro-lit-review | references.bib, branch summaries |
| Input from | maestro-data-analyst | Data description, panel schema |
| Output to | maestro-data-pdf | paper.tex -> compiled PDF |

### Reference Documents

| File | Content |
|------|---------|
| `references/paper-structure.md` | Full section-by-section SOP with examples |
| `references/writing-conventions.md` | QJE/JPE style rules, phrase lists |
| `references/latex-conventions.md` | LaTeX boilerplate: tables, figures, equations, compilation |
| `references/qje_style.md` | QJE/JPE detailed writing conventions |
| `references/section_guide.md` | Section-by-section word counts and checklists |
| `references/latex_template.tex` | Complete boilerplate LaTeX paper |
| `references/referee_response.md` | How to write referee responses |
| `references/ssrn_checklist.md` | SSRN and journal submission checklist |
