
# Maestro Data Fusion

Multi-source heterogeneous panel fusion for county-level research datasets.

--------------------------------------------------------------------------------

## 1. Scope

This skill covers the full workflow from raw heterogeneous sources to a
single clean master panel CSV with consistent geo keys, crop codes, units,
and quality flags.

**Core principle:** All sources must be normalized to a single geo key
(NBS 6-digit county code) before any join or dedup operation.

**Cross-references:**
- For OCR extraction from gazetteers, use `maestro-data-ocr`.
- For spatial aggregation of raster data to county polygons, use `maestro-data-spatial`.
- For QA diagnostics on the final panel, use `maestro-data-qa`.

--------------------------------------------------------------------------------

## 2. Three-Namespace Problem

County data arrives in multiple geographic naming systems. Never mix them.

| Namespace | Example | Source |
|-----------|---------|--------|
| XFZ book code | `XFZ13200` | Gazetteer OCR pipeline |
| NBS 6-digit | `230127` | National Bureau of Statistics |
| GADM GID_3 | `CHN.8.3.2_1` | GADM administrative boundaries |

**Rule:** NBS 6-digit is the canonical dedup key. Build crosswalks from all
other namespaces to NBS **before** any fusion step.

--------------------------------------------------------------------------------

## 3. Crosswalk Construction SOP

### 3.1 XFZ → NBS Crosswalk

```python
# crosswalk_xfz_nbs.csv schema: xfz_stem, county_cn, nbs_code, match_type
# match_type: 'exact' | 'manual'
# Read with utf-8-sig (Mac pandas writes BOM)
xw = pd.read_csv("crosswalk_xfz_nbs.csv", encoding='utf-8-sig', dtype=str)
```

Build process:
1. Extract county name from XFZ stem (e.g., `XFZ13200_延寿县志` → `延寿县`)
2. Exact match against NBS county list
3. Remaining unmatched → manual CSV lookup (历史区划变更、地级市辖区)
4. Target: 100% match rate before proceeding

### 3.2 GADM → NBS Crosswalk

```python
# crosswalk_gadm_nbs.csv schema: gadm_gid3, gadm_name_cn, nbs_code, match_type
# match_type: 'exact' | 'fuzzy' | 'manual' | 'no_cn_name' | 'no_match'
xw = pd.read_csv("crosswalk_gadm_nbs.csv", encoding='utf-8-sig', dtype=str)
```

**Known gaps (China-specific):**
- `no_cn_name` (typical ~300 rows): GADM lacks Chinese name — Chongqing most affected
- `no_match` (typical ~180 rows): urban prefecture seats absent from county grain datasets
- Effective match rate: matched / (total - no_cn_name) ≈ 91%

Build process:
1. Load GADM GeoJSON, extract `GID_3` + Chinese names from `NL_NAME_3`
2. Fuzzy match against NBS county name list (rapidfuzz, score ≥ 85)
3. Manual review of remaining unmatched
4. Write with `match_type` column for audit trail

### 3.3 BOM Gotcha

```python
# ❌ 错误：encoding='utf-8' — Mac pandas 写的 CSV 带 BOM，首列会有 \ufeff 前缀 → merge 静默失败
# ✅ 正确：
pd.read_csv("crosswalk.csv", encoding='utf-8-sig')
```

--------------------------------------------------------------------------------

## 4. Per-Source Adapter Pattern

Each source needs a thin adapter outputting a standard schema:

**Standard columns:**
```
source_id, geo_code_raw, geo_code_ns, nbs_code, year, crop_code,
sown_area_ha, yield_kg_ha, production_ton
```

- `geo_code_ns`: namespace tag (`xfz` / `nbs` / `gadm`)
- `nbs_code`: unified NBS 6-digit (NULL if crosswalk failed)
- Quantity columns: NULL if source doesn't provide that field

**Adapter template:**

```python
def load_source_xyz(path: str, crosswalk: pd.DataFrame) -> pd.DataFrame:
    raw = pd.read_csv(path, dtype=str)
    # 1. Rename to standard schema
    # 2. Apply geo crosswalk
    df = raw.merge(crosswalk[['xyz_key', 'nbs_code']], on='xyz_key', how='left')
    # 3. Convert units to standard (ha, kg/ha, ton)
    # 4. Tag source
    df['source_id'] = 'xyz'
    return df[STANDARD_COLS]
```

--------------------------------------------------------------------------------

## 5. Crop Code Standardization

All sources must map to a standard vocabulary before dedup.

**Standard crop codes:** `grain_total`, `rice`, `wheat`, `corn`, `soybean`,
`sorghum`, `millet`, `potato`

```python
CROP_MAP_CN = {
    '粮食合计': 'grain_total', '总产量': 'grain_total',
    '水稻': 'rice', '稻谷': 'rice', '陆稻': 'rice',
    '小麦': 'wheat', '玉米': 'corn', '大豆': 'soybean',
    '高粱': 'sorghum', '谷子': 'millet', '土豆': 'potato', '马铃薯': 'potato',
}
```

**Critical:** Unlisted crop names are **silently dropped** before dedup. Always assert:

```python
dropped = df[~df['crop_cn'].isin(CROP_MAP_CN.keys())]
assert len(dropped) == 0, f"Unmapped crops: {dropped['crop_cn'].unique()}"
```

--------------------------------------------------------------------------------

## 6. Physical Yield Validation

Apply caps to `yield_kg_ha` to reject implausible rows before dedup:

```python
YIELD_CAPS_KG_HA = {
    'wheat': 15_000, 'rice': 15_000, 'sorghum': 15_000,
    'corn': 25_000, 'millet': 10_000, 'soybean': 6_000,
    'potato': 60_000,
    # grain_total: no cap — aggregate can legitimately exceed single-crop cap
}
df = df[df.apply(
    lambda r: r['yield_kg_ha'] <= YIELD_CAPS_KG_HA.get(r['crop_code'], 1e9), axis=1
)]
```

--------------------------------------------------------------------------------

## 7. Dedup Key Strategy

```python
# Priority: nbs_code when available; fallback to raw geo string
mask_nbs = df['nbs_code'].notna()
dedup_key = df['nbs_code'].where(mask_nbs, '_raw:' + df['geo_code_raw'])

df['_key'] = dedup_key + '|' + df['year'].astype(str) + '|' + df['crop_code']
df = df.drop_duplicates(subset='_key', keep='first').drop(columns='_key')
```

**Source priority order** (concat in this order; `keep='first'` favors earlier rows):
1. `gazetteer_ocr` — primary (actual historical records)
2. `scidb_*` — secondary (provincial yearbook)
3. Raster-derived — tertiary (model estimates)
4. Academic surveys — supplementary

--------------------------------------------------------------------------------

## 8. QA Dashboard (Mandatory)

After **every** master panel rebuild:

```bash
python scripts/build_fusion_dashboard.py
# Output: 02-production/output/fusion/fusion_dashboard.html
```

**Never skip the dashboard rebuild.** QA panels Q1-Q5 are the primary
verification artifact for each source's coverage, unit consistency, and
temporal completeness.

**Minimum checks before delivery:**
- Q1: Source row counts match expected totals
- Q2: Year coverage has no unexpected gaps
- Q3: `yield_kg_ha` within physical caps per crop
- Q4: `nbs_code` match rate ≥ 90% (warn if < 80%)
- Q5: No duplicate `(nbs_code, year, crop_code)` triples

--------------------------------------------------------------------------------

## 9. Common Pitfalls

1. **BOM in crosswalk CSVs**: Mac pandas writes BOM → `\ufeff` prefix on first column → merge fails silently. Always `encoding='utf-8-sig'`.

2. **Mixing namespaces before crosswalk**: Joining XFZ and GADM rows before normalizing to NBS creates false duplicates and missed matches.

3. **grain_total yield cap**: `grain_total` is an aggregate — don't apply per-crop caps. It will legitimately exceed any single-crop cap.

4. **Silent CROP_MAP_CN drop**: Unmapped crop names drop without warning. Always assert zero unmapped names before dedup.

5. **Raster unit mismatch**: Raster data often in kg/ha or t/ha; gazetteer data in local units (斤/亩). Standardize to kg/ha + ha + ton before merge.

6. **SEDAC 404**: NASA Earthdata CIESIN China datasets return 404 since 2025-04-30 (contract ended). Do not schedule automation against these URLs.

--------------------------------------------------------------------------------

## 10. Reference Files

| File | Description |
|------|-------------|
| `scripts/fusion_pipeline.py` | Master panel builder; loads crosswalks; dedup key = nbs_code |
| `scripts/build_fusion_dashboard.py` | Entry point for QA dashboard |
| `scripts/dashboard/` | Modular: config.py / compute_panels.py / render_html.py |
| `scripts/crosswalk_xfz_nbs.csv` | XFZ → NBS (read with utf-8-sig) |
| `scripts/crosswalk_gadm_nbs.csv` | GADM GID_3 → NBS (read with utf-8-sig) |
