# RA Compute — deep reference

Companion to SKILL.md §1 "RA Compute best practices". Each rule below has a
verified failure trace on production (https://ra.maestro.onl) as of 2026-04.

--------------------------------------------------------------------------------

## 1. Workspace file layout

The sync contract is **not** a verbatim mirror of the project tree.

| Path in project | Path on Modal worker | Preserved? |
|---|---|---|
| `run.py` (workspace root) | `/tmp/mecon_job/code/run.py` | yes |
| `my_pkg/*.py` | `/tmp/mecon_job/code/my_pkg/*.py` | yes |
| `data/*.parquet`, `data/*.csv` | `/tmp/mecon_job/code/data/...` | yes |
| `my_pkg/data/anything` | — (dropped) | **no** |
| any other non-`.py` file in a nested dir | — (dropped) | **no** |

**Rule**: only two input locations survive — `.py` anywhere, and anything
under workspace-root `data/`. Putting parquet/CSV under `my_pkg/data/`
and tracking it with `mecon add my_pkg/data/foo.parquet` will succeed
silently at `mecon sync` time, then fail at `run(ctx)` time with
`FileNotFoundError`.

If your code reads from a hardcoded path (e.g. `config.DATA_DIR = "/tmp/..."`),
patch it inside `run(ctx)` to `str(ctx.data_dir)` before any module that
consumes it is imported.

--------------------------------------------------------------------------------

## 2. ctx API quirks

`ctx.data_dir` is a `pathlib.PosixPath`. Most consumers tolerate it, but
`scipy.io.loadmat`, `np.loadtxt`, and `np.genfromtxt` require `str`:

```python
data_dir = str(ctx.data_dir)
config.DATA_DIR = data_dir  # upstream code does os.path.join(DATA_DIR, ...)
```

`ctx.output_dir` is also `PosixPath`, backed by a FUSE-mounted R2 bucket.
What works and what does not:

| Op | Works? | Notes |
|---|---|---|
| `open(path, 'w')` | ✓ | plain POSIX write |
| `json.dump(obj, open(p, 'w'))` | ✓ | |
| `np.save(path, arr)` | ✓ | single npy |
| `pickle.dump(obj, open(p, 'wb'))` | ✓ | readable after `mecon sync` |
| `pd.DataFrame.to_parquet(path)` | ✗ | pyarrow calls `open_output_stream` which returns EPERM |
| `pd.DataFrame.to_csv(path)` | ✓ | pure text write |
| `shutil.copy(local_parquet, output_path)` | ✓ | workaround for parquet |

Pattern for parquet output: write locally first, then copy.

```python
import tempfile, shutil
tmp = tempfile.NamedTemporaryFile(suffix=".parquet", delete=False).name
df.to_parquet(tmp, index=False)
shutil.copy(tmp, os.path.join(ctx.output_dir, "result.parquet"))
```

--------------------------------------------------------------------------------

## 3. Logs: `print` vs `ctx.log`

Two streams, not interchangeable.

- `print(msg, flush=True)` → stdout → `output/job.log` → sync pulls it down.
  Reliable on success and on crash. Always flush.
- `ctx.log(msg)` → streamable over `mecon logs -f <job_id>`. Useful for
  live dashboards but may not appear in `job.log`, and may be silently
  dropped if the worker crashes before flushing.

Rule: for anything you might need to debug post-mortem, use `print(..., flush=True)`.

--------------------------------------------------------------------------------

## 4. Sync is not optional before submit

`mecon submit` happily proceeds with no prior sync, emitting:

```
Warning: N unsynced files. Run 'mecon sync' first.
Continuing anyway (using last synced versions)...
```

On a brand-new workspace there are **no** last synced versions — the worker
pulls an empty tree and fails at import time. Always pair:

```bash
mecon sync && mecon submit run.py --gpu l4 --config '{"max_time": 60}' --timeout 600 --no-watch
```

Use `--no-watch` so you can monitor asynchronously via polling or `mecon watch`.

--------------------------------------------------------------------------------

## 5. Queue cold-start

`status: queued` with `updated_at` frozen for > 10 minutes means the worker
pool is saturated for that GPU tier. Do not wait indefinitely.

```bash
mecon cancel <job_id>          # full refund, no credit burn
mecon submit ... --gpu t4      # try a different tier
```

Observed capacity order (most → least available, 2026-04):
`T4 → A100 → L40S → A10G → L4 → H100`. L4 sees the highest contention.

--------------------------------------------------------------------------------

## 6. Banned input formats → in-memory loader patch

Uploads enforce a whitelist: `.py .csv .parquet .json .txt .yaml .toml .R .jl`.
Banned on upload: `.mat .h5 .hdf5 .dta .npz .pkl .sav`.

Don't rewrite upstream loaders. Convert data once, then patch the function
at runtime inside `run(ctx)`:

```python
# convert_to_parquet.py — run once, locally
import scipy.io, pandas as pd
mat = scipy.io.loadmat("raw/DataSCI.mat")
pd.DataFrame(mat["StudentDataSCI"]).to_parquet("data/StudentDataSCI.parquet", index=False)

# run.py — on Modal
def run(ctx):
    data_dir = str(ctx.data_dir)

    def _patched_load(path, *a, **kw):
        import pandas as pd
        return pd.read_parquet(path.replace(".mat", ".parquet")).to_numpy()

    import my_pkg.loaders as _ld
    _ld.load_mat = _patched_load

    import estimator
    estimator.run(...)
```

Local CPU workflow (`python3 gpu_search.py ...`) continues to read `.mat`
through the untouched upstream loader — dual-maintenance free.

--------------------------------------------------------------------------------

## 7. Checkpoints: what survives a crash

| Kind | Location | Survives worker crash? | Re-uploadable for warm restart? |
|---|---|---|---|
| `ctx.save_checkpoint(**arrays)` | R2-managed, per-workspace | yes | yes — `ctx.load_checkpoint()` |
| Raw `.pkl` under `ctx.output_dir` | R2 via FUSE | yes | no — `.pkl` fails `mecon add` whitelist |
| Raw `.npy` under `ctx.output_dir` | R2 via FUSE | yes | yes (`.npy` passes; can round-trip as x0) |

Rule: use `ctx.save_checkpoint` for anything you want to resume from on the
*next* run of the same job. Use plain file writes for artifacts you just
want to `mecon sync` back.

For multi-restart optimizers (CMA-ES, BFGS with line search), the library's
own pickled state is often the real checkpoint. Options:

- Warm-start from `best_x.npy` only (lose internal state, clean)
- Serialize opaque state to bytes, base64-encode, save inside a `.json`
  dict under `ctx.save_checkpoint` (preserves everything, ugly)

--------------------------------------------------------------------------------

## 8. Smoke-test recipe

Before committing credits to a long run, always smoke:

```bash
mecon sync
mecon submit run.py --gpu l4 --config '{"max_time": 60}' --timeout 600 --no-watch
# capture the returned job_id, then:
until s=$(mecon status $JOB_ID | jq -r '.data.status'); case "$s" in succeeded|failed|cancelled|timeout) break;; esac; sleep 10; do :; done
mecon sync
```

Verify, in order:
1. `output/job.log` tails with no traceback
2. `output/<your-state-file>` exists and parses
3. First-eval distance/loss matches a known local reference (MATLAB best,
   CPU port, prior run) — confirms the data pipeline is byte-equivalent
4. Return dict has `diagnostics.converged` field (required by contract)

Only after all four pass, relaunch at full budget and GPU tier.
