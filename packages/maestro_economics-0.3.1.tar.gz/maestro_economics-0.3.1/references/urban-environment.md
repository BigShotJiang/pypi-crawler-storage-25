
# maestro-urban-environment -- Urban Environment Indicator Extraction

## Overview

Urban environment variables are key exogenous variables in housing economics, urban economics, and environmental health economics. This skill covers intra-city (block/postal zone/grid) scale indicator extraction, outputting research-grade panel data.

**Division with maestro-climate:**
- `maestro-climate`: macro climate (ERA5, CRU, CHIRPS), country/region, 0.25-0.5deg, climate-economy causality
- `maestro-urban-environment`: **intra-city spatial heterogeneity**, 30m-1km, block/postal zone, urban economics

**Pipeline position:** `maestro-fetch -> maestro-urban-environment -> maestro-data-spatial (aggregation) -> maestro-analysis`

---

## When to Use

- Extracting urban environmental indicators at sub-city granularity (block, postal zone, grid)
- Building panel data with: LST/UHI, NDVI/greenery, PM2.5, flood risk (TWI), noise proxies
- Preparing environmental control variables for hedonic pricing or urban economics research

## When NOT to Use

- Macro climate variables (country/region level) -> use `maestro-climate`
- Spatial aggregation mechanics (zonal stats setup) -> use `maestro-data-spatial`
- Econometric analysis of environmental effects -> use `maestro-analysis` or `maestro-urban-hedonic`

---

## Core Workflow (10 steps)

1. **Define study area** -- get admin boundary shapefile/GeoJSON, confirm CRS (WGS84 default)
2. **Choose indicators** -- select from 5 domains below based on research question
3. **Acquire rasters** -- use earthaccess or GEE (see indicator reference files)
4. **Cloud/QC filter** -- apply quality masks before compositing
5. **Temporal composite** -- monthly median (LST), quarterly median (NDVI), annual (PM2.5)
6. **Compute derived variables** -- UHI difference, TWI from DEM, noise proxy from OSM
7. **Zonal aggregation** -- rasterstats to admin zones (mean, median, percentiles)
8. **Bias correction** -- ground-station calibration for PM2.5 if stations available
9. **Panel assembly** -- zone_id x year [x month/quarter], naming: `{indicator}_{statistic}`
10. **Validation** -- check pixel counts, flag zones with < 10 valid pixels

---

## Five Indicator Domains

| # | Domain | Preferred Data | Resolution | Details |
|---|--------|---------------|------------|---------|
| 1 | UHI (Urban Heat Island) | MODIS MOD11A1 | 1km, daily, 2000+ | [references/uhi.md](references/uhi.md) |
| 2 | Greenery (NDVI) | Sentinel-2 / Landsat | 10-30m, 5-16 day | [references/ndvi.md](references/ndvi.md) |
| 3 | Air Quality (PM2.5) | van Donkelaar V5.GL.04 | ~1km, annual | [references/pm25.md](references/pm25.md) |
| 4 | Flood Risk (TWI) | SRTM 30m + FATHOM | 30-90m | [references/flood-risk.md](references/flood-risk.md) |
| 5 | Noise Exposure | OSM road proxy | vector | [references/noise.md](references/noise.md) |

Composite index (PCA/equal-weight): [references/composite-index.md](references/composite-index.md)

---

## CLI Quick Reference

```bash
# Python environment
pip install earthaccess rasterio rasterstats geopandas xarray rioxarray richdem
pip install earthengine-api    # GEE
pip install osmnx              # noise proxy
pip install scikit-learn       # PCA, bias correction
pip install netCDF4            # NetCDF
```

```python
# Key one-liners
earthaccess.login(persist=True)                          # NASA Earthdata auth
earthaccess.search_data(short_name="MOD11A1", ...)       # search MODIS LST
ee.Initialize(project='your-gcp-project')                # GEE init
img.normalizedDifference(['B8', 'B4']).rename('NDVI')    # Sentinel-2 NDVI
zonal_stats(admin_zones, raster, stats=['mean','median']) # aggregate to zones
```

---

## Key Rules

1. **Always QC-filter** before compositing -- MODIS QC bands, Sentinel-2 cloud %, Landsat pixel_qa
2. **Unit conversions are mandatory** -- MODIS LST: raw x 0.02 - 273.15; Landsat SR: x 0.0000275 - 0.2
3. **Match temporal resolution to research design** -- annual for cross-section, monthly for panel with time FE
4. **Document pixel counts** -- report n_valid_pixels per zone; flag sparse zones
5. **Separate day/night for UHI** -- Terra 10:30/22:30 vs Aqua 13:30/01:30; never average across overpass times

---

## Gotchas

- MODIS 1km mixes urban/rural at city edges (mixed pixel problem) -- exclude boundary zones
- Sentinel-2 B8 (10m NIR) != B8A (20m NIR) -- never interchange
- van Donkelaar PM2.5 links on Box.com change -- always check `sites.wustl.edu/acag` for latest
- SRTM is DSM (includes buildings) -- use MERIT DEM or FABDEM for cleaner TWI in urban areas
- OSM road density is cross-section only -- not reliable for panel (temporal changes)
- FATHOM academic license takes 1-2 weeks -- apply at project start

---

## Skill Integration

```
maestro-fetch           -> data acquisition (earthaccess, GEE export)
maestro-urban-environment -> this skill (indicator extraction, raster processing)
maestro-data-spatial    -> raster aggregation to admin zones (zonal_stats)
maestro-urban-hedonic   -> hedonic regression (env variables as X)
maestro-analysis        -> causal inference, econometrics
maestro-paper           -> tables, figures -> paper
```

**Handoff specs:**
- Raster output: GeoTIFF, CRS WGS84 (EPSG:4326), nodata -9999
- Panel output: CSV, zone_id x year [x month/quarter], blanks for missing (not 0 or -999)
- Variable naming: `{indicator}_{statistic}` (e.g. `pm25_mean`, `ndvi_p50`, `uhi_day`)

---

## Pre-flight Checklist

- [ ] Study area boundary file ready (shapefile/GeoJSON)
- [ ] CRS unified (WGS84 or project projection)
- [ ] NASA Earthdata account registered (for LST, DEM)
- [ ] GEE project ID configured (if using GEE path)
- [ ] Time range aligned with research panel
- [ ] Output frequency confirmed (annual/quarterly/monthly)
- [ ] Admin zone granularity confirmed (postal zone/block/grid)
- [ ] Cloud masking strategy confirmed (monthly median/max composite)
- [ ] Variable naming aligned with downstream skills
