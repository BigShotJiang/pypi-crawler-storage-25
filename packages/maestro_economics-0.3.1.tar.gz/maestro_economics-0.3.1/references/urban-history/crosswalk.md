# Boundary Crosswalk — Historical-to-Modern Administrative Area Mapping, QC, Data Sources

## 1. Area-Weighted Interpolation

```python
import geopandas as gpd
import pandas as pd
import numpy as np


def area_weighted_crosswalk(
    historical_gdf: gpd.GeoDataFrame,
    modern_gdf: gpd.GeoDataFrame,
    value_cols: list[str],
    source_id: str = "hist_id",
    target_id: str = "modern_id",
) -> pd.DataFrame:
    """历史边界 → 现代边界，面积加权插值。

    假设: 变量在源多边形内均匀分布。
    对人口等非均匀变量，应使用更精细的权重（如建筑密度加权）。
    """
    crs_utm = historical_gdf.estimate_utm_crs()
    hist = historical_gdf.to_crs(crs_utm)
    modern = modern_gdf.to_crs(crs_utm)

    hist["_source_area"] = hist.geometry.area

    intersected = gpd.overlay(hist, modern, how="intersection")
    intersected["_intersection_area"] = intersected.geometry.area
    intersected["_weight"] = intersected["_intersection_area"] / intersected["_source_area"]

    result_rows = []
    for modern_id, group in intersected.groupby(target_id):
        row = {target_id: modern_id}
        for col in value_cols:
            row[col] = (group[col] * group["_weight"]).sum()
        row["_n_sources"] = len(group)
        result_rows.append(row)

    result = pd.DataFrame(result_rows)

    for col in value_cols:
        original_total = historical_gdf[col].sum()
        allocated_total = result[col].sum()
        deviation = abs(allocated_total - original_total) / original_total
        if deviation > 0.01:
            print(f"警告: {col} 总量偏差 {deviation:.2%}")

    return result


def density_weighted_crosswalk(
    historical_gdf: gpd.GeoDataFrame,
    modern_gdf: gpd.GeoDataFrame,
    value_cols: list[str],
    density_raster: str,
    source_id: str = "hist_id",
    target_id: str = "modern_id",
) -> pd.DataFrame:
    """建筑密度/人口密度加权的边界匹配。需要密度栅格作为权重。"""
    from exactextract import exact_extract

    crs_utm = historical_gdf.estimate_utm_crs()
    hist = historical_gdf.to_crs(crs_utm)
    modern = modern_gdf.to_crs(crs_utm)

    intersected = gpd.overlay(hist, modern, how="intersection")
    density_weights = exact_extract(density_raster, intersected, ["sum"], output="pandas")
    intersected["_density_weight"] = density_weights["sum"]

    source_totals = intersected.groupby(source_id)["_density_weight"].transform("sum")
    intersected["_norm_weight"] = intersected["_density_weight"] / source_totals

    result_rows = []
    for modern_id, group in intersected.groupby(target_id):
        row = {target_id: modern_id}
        for col in value_cols:
            row[col] = (group[col] * group["_norm_weight"]).sum()
        result_rows.append(row)

    return pd.DataFrame(result_rows)
```

## 2. Crosswalk Table Generation

```python
def generate_crosswalk_table(
    historical_gdf: gpd.GeoDataFrame,
    modern_gdf: gpd.GeoDataFrame,
    source_id: str = "hist_id",
    target_id: str = "modern_id",
    output_csv: str = "crosswalk_table.csv",
) -> pd.DataFrame:
    """生成历史-现代行政区划对照表。"""
    crs_utm = historical_gdf.estimate_utm_crs()
    hist = historical_gdf[[source_id, "geometry"]].to_crs(crs_utm)
    modern = modern_gdf[[target_id, "geometry"]].to_crs(crs_utm)

    hist["_source_area"] = hist.geometry.area
    intersected = gpd.overlay(hist, modern, how="intersection")
    intersected["_intersection_area"] = intersected.geometry.area
    intersected["weight"] = intersected["_intersection_area"] / intersected["_source_area"]

    crosswalk = intersected[[source_id, target_id, "weight"]].copy()
    crosswalk = crosswalk[crosswalk["weight"] > 0.001]
    crosswalk = crosswalk.sort_values([source_id, target_id])

    crosswalk.to_csv(output_csv, index=False)
    return crosswalk
```

## 3. Quality Control Functions

### Georeferencing QC

```python
def qc_georeferencing(georef_tif, gcps, rms_threshold_m=10.0):
    """RMS error check + worst GCP identification."""
    rms = compute_gcp_rms_error(gcps, georef_tif)
    result = {
        "rms_meters": rms["rms_meters"],
        "pass": rms["rms_meters"] < rms_threshold_m,
    }
    worst_idx = int(np.argmax(rms["per_gcp"]))
    result["worst_gcp"] = {"index": worst_idx, "error_m": rms["per_gcp"][worst_idx]}
    return result
```

### Vectorization QC

```python
def qc_vectorization(zones_gdf, georef_tif):
    """Area distribution + coverage + topology check."""
    areas = zones_gdf.to_crs(zones_gdf.estimate_utm_crs()).geometry.area
    from shapely.ops import unary_union
    union = unary_union(zones_gdf.geometry)
    overlap_ratio = 1 - union.area / zones_gdf.geometry.area.sum()
    return {
        "n_polygons": len(zones_gdf),
        "tiny_polygons": int((areas < areas.mean() * 0.01).sum()),
        "huge_polygons": int((areas > areas.mean() * 100).sum()),
        "overlap_ratio": float(overlap_ratio),
        "pass": overlap_ratio < 0.01,
    }
```

### Attribute QC

```python
def qc_attributes(zones_gdf, historical_stats=None):
    """Cross-validate against historical literature statistics."""
    result = {"checks": []}
    if historical_stats and "total_destroyed_area_km2" in historical_stats:
        destroyed = zones_gdf[zones_gdf["damage_grade"] >= 3]["area_m2"].sum() / 1e6
        ref = historical_stats["total_destroyed_area_km2"]
        deviation = abs(destroyed - ref) / ref
        status = "PASS" if deviation <= 0.2 else "WARNING"
        result["checks"].append(f"{status}: {destroyed:.1f} km² vs literature {ref:.1f} km² ({deviation:.0%})")
    return result
```

### QC Checklist

| Step | Check | Pass Criteria | Tool |
|------|-------|---------------|------|
| Preprocessing | Output resolution | >= 300 DPI | `gdalinfo` |
| Georeferencing | RMS error | < 10m (block-level) | `compute_gcp_rms_error()` |
| Georeferencing | OSM overlay | Roads/rivers aligned | QGIS |
| Vectorization | Area distribution | No tiny/huge polygons | `qc_vectorization()` |
| Vectorization | Topology | Overlap < 1% | `qc_vectorization()` |
| Attributes | Literature consistency | Deviation < 20% | `qc_attributes()` |
| Crosswalk | Total conservation | Deviation < 1% | `area_weighted_crosswalk()` |

## 4. Country-Specific Data Sources

### Japan
| Source | Content | URL |
|--------|---------|-----|
| GSI | Historical maps | https://maps.gsi.go.jp/ |
| JACAR | War damage maps | https://www.jacar.go.jp/ |
| Stanford JMMA | City maps 1:10000 | https://stanford.maps.arcgis.com/ |

**CRS**: Pre-war maps use Tokyo Datum (EPSG:4301). Convert to WGS84.

### China
| Source | Content | URL |
|--------|---------|-----|
| CHGIS (Harvard) | Historical boundaries 221BC-2019 | https://chgis.fas.harvard.edu/ |
| David Rumsey | Historical maps | https://www.davidrumsey.com/ |

### USA
| Source | Content | URL |
|--------|---------|-----|
| LOC Maps | Various historical | https://www.loc.gov/maps/ |
| HOLC (digitized) | 1930s redlining vectors | https://dsl.richmond.edu/panorama/redlining/ |
| Sanborn | 1867-1970 buildings | LOC / ProQuest |
| NHGIS | Historical census + boundaries | https://www.nhgis.org/ |

### Singapore / Hong Kong
- Singapore: SVY21 (EPSG:3414), NAS archives
- Hong Kong: HK80 (EPSG:2326), HKMS archives

## 5. Deliverables Structure

```
project_dir/
  raw/scans/, raw/reference/
  processed/preprocessed/, processed/georeferenced/, processed/masks/
  output/damage_zones.geojson, building_density.csv, crosswalk_table.csv, panel_data.csv
  docs/georef_report.pdf, codebook.xlsx
  scripts/01_preprocess.py through 06_validate.py
  gcps/gcps.csv, gcps_qgis.points
```

## 6. Dependencies

```
opencv-python>=4.8.0, numpy>=1.24.0, geopandas>=1.1.0, rasterio>=1.4.3
shapely>=2.0.0, pyproj>=3.6.0, GDAL>=3.7.0, torch>=2.0.0
lightglue>=0.0.1, exactextract>=0.2.0, scikit-image>=0.21.0
```

GDAL install: macOS `brew install gdal` then `pip install GDAL==$(gdal-config --version)`.
