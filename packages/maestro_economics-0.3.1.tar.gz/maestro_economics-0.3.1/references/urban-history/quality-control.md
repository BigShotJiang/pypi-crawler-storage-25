# Quality Control — Checkpoints and Validation

每一步完成后必须执行对应的质控检查，确认通过后方可继续下一步。

## 1. Georeferencing QC

```python
def qc_georeferencing(
    georef_tif: str,
    gcps: list[dict],
    rms_threshold_m: float = 10.0,
) -> dict:
    """配准质控：叠加现代 OSM 底图目视检查 + RMS 误差。

    检查项:
    1. RMS 误差 < 阈值
    2. 主要道路/河流是否对齐
    3. 边缘区域是否有明显形变
    """
    rms = compute_gcp_rms_error(gcps, georef_tif)

    result = {
        "rms_meters": rms["rms_meters"],
        "max_error_meters": rms["max_error_meters"],
        "pass": rms["rms_meters"] < rms_threshold_m,
        "checks": [],
    }

    if rms["rms_meters"] >= rms_threshold_m:
        result["checks"].append(
            f"FAIL: RMS {rms['rms_meters']:.1f}m > 阈值 {rms_threshold_m}m"
        )
        result["recommendation"] = "增加 GCP 数量或检查异常 GCP"
    else:
        result["checks"].append(
            f"PASS: RMS {rms['rms_meters']:.1f}m < 阈值 {rms_threshold_m}m"
        )

    # 标记误差最大的 GCP
    worst_idx = int(np.argmax(rms["per_gcp"]))
    result["worst_gcp"] = {
        "index": worst_idx,
        "error_m": rms["per_gcp"][worst_idx],
    }

    return result
```

## 2. Vectorization QC

```python
def qc_vectorization(
    zones_gdf: gpd.GeoDataFrame,
    georef_tif: str,
) -> dict:
    """矢量化质控：面积分布 + 覆盖率检查。

    检查项:
    1. 异常大/小多边形标记
    2. 区域覆盖率（vs 地图总面积）
    3. 拓扑检查（重叠/间隙）
    """
    areas = zones_gdf.to_crs(zones_gdf.estimate_utm_crs()).geometry.area

    result = {
        "n_polygons": len(zones_gdf),
        "area_stats": {
            "mean_m2": float(areas.mean()),
            "median_m2": float(areas.median()),
            "min_m2": float(areas.min()),
            "max_m2": float(areas.max()),
            "std_m2": float(areas.std()),
        },
        "checks": [],
    }

    # 异常小多边形（< 均值的 1%）
    tiny = (areas < areas.mean() * 0.01).sum()
    if tiny > 0:
        result["checks"].append(f"WARNING: {tiny} 个异常小多边形（< 均值 1%）")

    # 异常大多边形（> 均值的 100 倍）
    huge = (areas > areas.mean() * 100).sum()
    if huge > 0:
        result["checks"].append(f"WARNING: {huge} 个异常大多边形（> 均值 100 倍）")

    # 拓扑检查：多边形之间是否有重叠
    from shapely.ops import unary_union
    union = unary_union(zones_gdf.geometry)
    total_area = zones_gdf.geometry.area.sum()
    union_area = union.area
    overlap_ratio = 1 - union_area / total_area if total_area > 0 else 0
    if overlap_ratio > 0.01:
        result["checks"].append(f"WARNING: 多边形重叠率 {overlap_ratio:.1%}")

    result["pass"] = len([c for c in result["checks"] if "FAIL" in c]) == 0
    return result
```

## 3. Attribute QC

```python
def qc_attributes(
    zones_gdf: gpd.GeoDataFrame,
    historical_stats: dict = None,
) -> dict:
    """属性质控：与历史统计文献做一致性比对。

    Args:
        zones_gdf: 带属性的区域 GeoDataFrame
        historical_stats: 历史文献中的统计数据（用于交叉验证）
            例: {"total_destroyed_area_km2": 13.0, "destroyed_buildings": 60000}
    """
    result = {"checks": []}

    # 基本统计
    if "damage_grade" in zones_gdf.columns:
        damage_dist = zones_gdf["damage_grade"].value_counts().to_dict()
        result["damage_distribution"] = damage_dist

    if "area_m2" in zones_gdf.columns:
        total_area_km2 = zones_gdf["area_m2"].sum() / 1e6
        result["total_area_km2"] = total_area_km2

    # 与文献交叉验证
    if historical_stats:
        if "total_destroyed_area_km2" in historical_stats and "area_m2" in zones_gdf.columns:
            destroyed = zones_gdf[zones_gdf["damage_grade"] >= 3]["area_m2"].sum() / 1e6
            ref = historical_stats["total_destroyed_area_km2"]
            deviation = abs(destroyed - ref) / ref
            if deviation > 0.2:
                result["checks"].append(
                    f"WARNING: 重损+全毁面积 {destroyed:.1f} km2 vs 文献 {ref:.1f} km2 (偏差 {deviation:.0%})"
                )
            else:
                result["checks"].append(
                    f"PASS: 重损+全毁面积 {destroyed:.1f} km2 ~ 文献 {ref:.1f} km2 (偏差 {deviation:.0%})"
                )

    # 置信度分布
    if "confidence" in zones_gdf.columns:
        low_conf = (zones_gdf["confidence"] < 0.3).sum()
        if low_conf / len(zones_gdf) > 0.2:
            result["checks"].append(
                f"WARNING: {low_conf / len(zones_gdf):.0%} 的区域置信度 < 0.3"
            )

    result["pass"] = len([c for c in result["checks"] if "FAIL" in c]) == 0
    return result
```

## 4. QC Checklist

| 步骤 | 检查项 | 通过标准 | 工具 |
|------|--------|---------|------|
| 预处理 | 输出分辨率 | >= 300 DPI | `gdalinfo` |
| 预处理 | 颜色失真 | 图例色块可识别 | 目视 |
| 配准 | RMS 误差 | < 10m（街区级） | `compute_gcp_rms_error()` |
| 配准 | OSM 叠加 | 主要道路/河流对齐 | QGIS |
| 矢量化 | 面积分布 | 无异常大/小多边形 | `qc_vectorization()` |
| 矢量化 | 拓扑 | 重叠率 < 1% | `qc_vectorization()` |
| 属性 | 文献一致性 | 偏差 < 20% | `qc_attributes()` |
| 属性 | 置信度 | 低置信度区域 < 20% | `qc_attributes()` |
| 边界匹配 | 总量守恒 | 偏差 < 1% | `area_weighted_crosswalk()` |
