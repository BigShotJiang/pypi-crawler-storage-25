# Georeferencing — Preprocessing, GCP Selection, GDAL Warping

## 1. Scan Preprocessing

### 1.1 Basic Preprocessing Pipeline

```python
import cv2
import numpy as np
from pathlib import Path


def preprocess_historical_map(img_path: str, target_dpi: int = 300) -> np.ndarray:
    """历史地图扫描件预处理：去噪 + 对比度增强 + DPI 标准化。

    Args:
        img_path: 输入图像路径（TIFF/PNG/JPEG）
        target_dpi: 目标 DPI（最低 300，建筑级分析建议 600）

    Returns:
        预处理后的图像矩阵 (BGR)
    """
    img = cv2.imread(img_path)
    if img is None:
        raise FileNotFoundError(f"无法读取图像: {img_path}")

    # 1. 去噪（保持边缘）
    denoised = cv2.fastNlMeansDenoisingColored(img, h=10, hForColorComponents=10)

    # 2. 对比度增强（CLAHE — 自适应直方图均衡化）
    lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    return enhanced


def remove_background_stains(img: np.ndarray, threshold: int = 200) -> np.ndarray:
    """去除纸张老化导致的背景黄斑/褐斑。

    原理: 将高亮度低饱和度区域统一为白色背景。
    """
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = (hsv[:, :, 1] < 30) & (hsv[:, :, 2] > threshold)
    result = img.copy()
    result[mask] = [255, 255, 255]
    return result


def deskew(img: np.ndarray) -> np.ndarray:
    """自动校正扫描倾斜。基于 Hough 变换检测主方向，旋转至水平。"""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)

    if lines is None:
        return img

    angles = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
        if abs(angle) < 45:
            angles.append(angle)

    if not angles:
        return img

    median_angle = np.median(angles)
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), median_angle, 1.0)
    rotated = cv2.warpAffine(img, M, (w, h), borderValue=(255, 255, 255))
    return rotated
```

### 1.2 Batch Preprocessing

```python
def batch_preprocess(input_dir: str, output_dir: str, target_dpi: int = 300):
    """批量预处理目录中的所有地图扫描件。"""
    in_path = Path(input_dir)
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    extensions = {".tif", ".tiff", ".png", ".jpg", ".jpeg"}
    files = [f for f in in_path.iterdir() if f.suffix.lower() in extensions]

    for f in sorted(files):
        print(f"处理: {f.name}")
        img = preprocess_historical_map(str(f), target_dpi)
        img = deskew(img)
        out_file = out_path / f"{f.stem}_preprocessed.tif"
        cv2.imwrite(str(out_file), img)
        print(f"  → {out_file}")
```

### 1.3 DPI & Resolution Guide

| 分析粒度 | 最低 DPI | 典型分辨率 | 说明 |
|----------|---------|-----------|------|
| 街区级 | 300 | 5000×7000 px | 多数历史研究足够 |
| 建筑级 | 600 | 10000×14000 px | Sanborn、地籍图 |
| 文字识别 | 400+ | — | 配合 OCR 使用 |

**注意**: 扫描件 DPI 信息可能不准（嵌入元数据与实际分辨率不符）。以实际像素分辨率为准。

---

## 2. AI-Assisted GCP Selection (Ground Control Points)

### 2.1 Method A: SuperGlue/LightGlue Feature Matching

```python
import torch
from lightglue import LightGlue, SuperPoint
from lightglue.utils import load_image, rbd


def match_historical_to_modern(
    historical_path: str,
    modern_path: str,
    max_keypoints: int = 2048,
    device: str = "cuda" if torch.cuda.is_available() else "cpu",
) -> list[dict]:
    """用 LightGlue 匹配历史地图与现代卫星图的特征点。

    Returns:
        匹配点列表: [{"hist_px": (x, y), "modern_px": (x, y), "confidence": float}]
    """
    extractor = SuperPoint(max_num_keypoints=max_keypoints).eval().to(device)
    matcher = LightGlue(features="superpoint").eval().to(device)

    img0 = load_image(historical_path).to(device)
    img1 = load_image(modern_path).to(device)

    feats0 = extractor.extract(img0)
    feats1 = extractor.extract(img1)

    matches01 = matcher({"image0": feats0, "image1": feats1})

    feats0, feats1, matches01 = [
        rbd(x) for x in [feats0, feats1, matches01]
    ]
    kpts0 = feats0["keypoints"][matches01["matches"][..., 0]].cpu().numpy()
    kpts1 = feats1["keypoints"][matches01["matches"][..., 1]].cpu().numpy()
    scores = matches01["matching_scores"].cpu().numpy()

    results = []
    for i in range(len(kpts0)):
        results.append({
            "hist_px": (float(kpts0[i][0]), float(kpts0[i][1])),
            "modern_px": (float(kpts1[i][0]), float(kpts1[i][1])),
            "confidence": float(scores[i]),
        })

    return results
```

**Stable anchor types (by reliability):**
1. 河流交汇处 — 拓扑结构极稳定（百年不变）
2. 海岸线转角 — 注意填海区域（广岛/新加坡有大量填海，需排除）
3. 铁路交叉口 — 战后通常在原址重建
4. 主要道路交叉口 — 城市核心区通常保持
5. 桥梁位置 — 河流上的桥梁位置较稳定

**Unreliable anchors (avoid):** buildings (demolished/rebuilt), vegetation boundaries, straight coastline segments (landfill drift).

### 2.2 Method B: VLM Place Name Recognition + Geocoding

```python
import json
import urllib.request
import urllib.parse


def vlm_extract_placenames(map_image_path: str) -> list[dict]:
    """用 VLM 识别历史地图上的地名标注。

    使用 OpenRouter API 调用 Qwen3-VL。
    返回: [{"name": "地名", "pixel_x": int, "pixel_y": int}]
    """
    import base64

    with open(map_image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()

    prompt = """请识别这张历史地图上所有可见的地名标注（街道名、区域名、河流名、
建筑名等）。对每个地名，估算其在图像中的像素位置。

返回 JSON 数组，格式:
[{"name": "地名（原文）", "name_modern": "现代名称", "pixel_x": 1234, "pixel_y": 5678, "type": "street|district|river|building|other"}]

注意：
- 保留原始语言（日语/中文/英语/法语等）
- 如果能推断现代名称，填入 name_modern
- pixel_x/pixel_y 是地名标注中心点的大致像素坐标"""

    # 返回 VLM 解析结果 (具体 API 调用参考 maestro-openrouter skill)
    pass


def geocode_placenames(
    placenames: list[dict],
    country_code: str = "",
    service: str = "nominatim",
) -> list[dict]:
    """将地名列表 geocode 为经纬度坐标。"""
    results = []

    for place in placenames:
        name = place.get("name_modern") or place["name"]

        if service == "nominatim":
            params = urllib.parse.urlencode({
                "q": name,
                "format": "json",
                "limit": 1,
                "countrycodes": country_code,
            })
            url = f"https://nominatim.openstreetmap.org/search?{params}"
            req = urllib.request.Request(url, headers={"User-Agent": "maestro-urban-history/1.0"})

        elif service == "gsi":
            params = urllib.parse.urlencode({"q": name})
            url = f"https://msearch.gsi.go.jp/address-search/AddressSearch?{params}"
            req = urllib.request.Request(url)

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())

            if service == "nominatim" and data:
                results.append({
                    **place,
                    "lon": float(data[0]["lon"]),
                    "lat": float(data[0]["lat"]),
                    "geocode_confidence": "high" if float(data[0].get("importance", 0)) > 0.5 else "medium",
                })
            elif service == "gsi" and data:
                results.append({
                    **place,
                    "lon": data[0]["geometry"]["coordinates"][0],
                    "lat": data[0]["geometry"]["coordinates"][1],
                    "geocode_confidence": "medium",
                })
        except Exception:
            continue

    return results
```

### 2.3 Hybrid Strategy: Two Candidates → RANSAC → Manual Confirmation

```python
import numpy as np
from typing import Optional


def hybrid_gcp_selection(
    feature_matches: list[dict],
    geocoded_points: list[dict],
    modern_geotransform: Optional[tuple] = None,
    ransac_threshold: float = 50.0,
    min_gcps: int = 10,
) -> list[dict]:
    """混合策略筛选最优 GCP。

    1. 合并两路候选
    2. RANSAC 剔除异常点
    3. 空间均匀分布筛选
    4. 输出待人工确认列表
    """
    candidates = []

    for m in feature_matches:
        if m["confidence"] > 0.5:
            candidates.append({
                "source": "feature_match",
                "hist_px": m["hist_px"],
                "confidence": m["confidence"],
            })

    for g in geocoded_points:
        if "lon" in g and "lat" in g:
            candidates.append({
                "source": "geocoded",
                "hist_px": (g["pixel_x"], g["pixel_y"]),
                "lon": g["lon"],
                "lat": g["lat"],
                "name": g["name"],
                "confidence": 0.7 if g.get("geocode_confidence") == "high" else 0.4,
            })

    # RANSAC filtering (use skimage.transform.estimate_transform)
    if len(candidates) >= 4:
        src_pts = np.array([c["hist_px"] for c in candidates], dtype=np.float32)
        pass

    # Spatial uniform distribution: 3×3 grid, keep highest confidence per cell

    print(f"候选 GCP: {len(candidates)} 个")
    print(f"建议人工确认: {min(min_gcps, len(candidates))} 个")
    for i, c in enumerate(candidates[:min_gcps]):
        print(f"  GCP-{i+1}: pixel={c['hist_px']}, source={c['source']}, conf={c['confidence']:.2f}")

    return candidates[:min_gcps]
```

**Manual confirmation time estimate**: 10 GCPs × 1.5 min/GCP = **15 min** (vs traditional 2-4 hours fully manual)

---

## 3. GDAL Warping

### 3.1 Standard Georeferencing Pipeline

```bash
#!/bin/bash
# georef.sh — 历史地图配准脚本
# 用法: bash georef.sh input.tif gcps.csv output.tif

INPUT=$1
GCPS=$2
OUTPUT=$3
CRS=${4:-EPSG:4326}

GCP_ARGS=""
while IFS=, read -r px py lon lat; do
    GCP_ARGS="$GCP_ARGS -gcp $px $py $lon $lat"
done < "$GCPS"

gdal_translate -of GTiff $GCP_ARGS "$INPUT" "${OUTPUT%.tif}_with_gcps.tif"

gdalwarp -tps -r bilinear \
    -t_srs "$CRS" \
    -co COMPRESS=LZW \
    -co TILED=YES \
    "${OUTPUT%.tif}_with_gcps.tif" "$OUTPUT"

rm -f "${OUTPUT%.tif}_with_gcps.tif"
echo "配准完成: $OUTPUT"
```

### 3.2 Python Georeferencing Interface

```python
import subprocess
from pathlib import Path


def georef_with_gdal(
    input_tif: str,
    gcps: list[dict],
    output_tif: str,
    target_crs: str = "EPSG:4326",
    resampling: str = "bilinear",
    method: str = "tps",
) -> str:
    """用 GDAL 配准历史地图。"""
    tmp_file = output_tif.replace(".tif", "_with_gcps.tif")

    cmd_translate = ["gdal_translate", "-of", "GTiff"]
    for gcp in gcps:
        cmd_translate.extend([
            "-gcp",
            str(gcp["pixel_x"]), str(gcp["pixel_y"]),
            str(gcp["lon"]), str(gcp["lat"]),
        ])
    cmd_translate.extend([input_tif, tmp_file])
    subprocess.run(cmd_translate, check=True)

    cmd_warp = ["gdalwarp"]
    if method == "tps":
        cmd_warp.append("-tps")
    else:
        cmd_warp.extend(["-order", "3"])

    cmd_warp.extend([
        "-r", resampling,
        "-t_srs", target_crs,
        "-co", "COMPRESS=LZW",
        "-co", "TILED=YES",
        tmp_file, output_tif,
    ])
    subprocess.run(cmd_warp, check=True)
    Path(tmp_file).unlink(missing_ok=True)
    return output_tif


def compute_gcp_rms_error(gcps: list[dict], georef_tif: str) -> dict:
    """计算 GCP 配准的 RMS 误差。"""
    from osgeo import gdal
    import numpy as np

    ds = gdal.Open(georef_tif)
    gt = ds.GetGeoTransform()
    ds = None

    errors = []
    for gcp in gcps:
        pred_lon = gt[0] + gcp["pixel_x"] * gt[1] + gcp["pixel_y"] * gt[2]
        pred_lat = gt[3] + gcp["pixel_x"] * gt[4] + gcp["pixel_y"] * gt[5]
        dlat = (pred_lat - gcp["lat"]) * 111320
        dlon = (pred_lon - gcp["lon"]) * 111320 * np.cos(np.radians(gcp["lat"]))
        error_m = np.sqrt(dlat**2 + dlon**2)
        errors.append(error_m)

    return {
        "rms_meters": float(np.sqrt(np.mean(np.array(errors) ** 2))),
        "max_error_meters": float(np.max(errors)),
        "per_gcp": errors,
    }
```

### 3.3 Warp Method Selection

| 方法 | 适用场景 | GCP 数量要求 | 说明 |
|------|---------|-------------|------|
| **TPS (Thin Plate Spline)** | 历史地图（推荐） | >= 10 | 处理非均匀形变最佳 |
| Polynomial (1阶) | 现代航拍图 | >= 3 | 仅平移+旋转+缩放 |
| Polynomial (2阶) | 轻度形变 | >= 6 | |
| Polynomial (3阶) | 中度形变 | >= 10 | |

**Why TPS for historical maps**: Old paper maps have non-uniform shrinkage/expansion. Affine or low-order polynomials cannot model local deformation. TPS allows elastic deformation near each GCP.

### 3.4 RMS Error Targets

| 研究粒度 | RMS 目标 | 说明 |
|----------|---------|------|
| 街区级 | < 10 m | 多数城市经济学研究 |
| 建筑级 | < 3 m | Sanborn 地图、地籍研究 |
| 区域级 | < 50 m | 大尺度军事行动地图 |
