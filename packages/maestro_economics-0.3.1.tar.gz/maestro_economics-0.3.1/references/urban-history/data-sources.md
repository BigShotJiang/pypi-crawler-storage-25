# Data Sources & Deliverables — Country-Specific Sources, Project Structure, Dependencies

## 1. Country-Specific Data Sources

### Japan

| Source | Coverage | Access | Notes |
|--------|----------|--------|-------|
| Geospatial Information Authority of Japan (GSI) | Historical maps and topographic sheets | https://maps.gsi.go.jp/ | Many files are free to download; some require application |
| JACAR military archives | War-damage assessment maps and military map layers | https://www.jacar.go.jp/ | Often browser-only; screenshots may be required |
| Hiroshima Peace Memorial Museum | Hiroshima destruction maps and reconstruction records | Archive request | High-quality scans available by request |
| Nagasaki Atomic Bomb Museum | Nagasaki destruction maps | Archive request | Coverage varies by collection |
| Stanford JMMA | Japanese urban maps at 1:10,000 scale | https://stanford.maps.arcgis.com/ | Good online access for pilot work |

**CRS note**: Many prewar Japanese maps use Tokyo Datum (`EPSG:4301`). Reproject to
JGD2011 (`EPSG:6668`) or WGS84 (`EPSG:4326`) before downstream processing.

```python
import geopandas as gpd

gdf_tokyo = gpd.read_file("old_map.shp").set_crs("EPSG:4301")
gdf_wgs84 = gdf_tokyo.to_crs("EPSG:4326")
```

### China

| Source | Coverage | Access | Notes |
|--------|----------|--------|-------|
| CHGIS (Harvard) | Historical administrative boundaries, 221 BCE-2019 | https://chgis.fas.harvard.edu/ | Downloadable shapefiles |
| Harvard WorldMap China layers | Republican-era city maps and overlays | https://worldmap.harvard.edu/chinamap | Online browsing with partial downloads |
| National Library of China | Digitized historical maps | http://www.nlc.cn/ | Some holdings are online only |
| Shanghai Municipal Archives | Concession maps and planning maps | Archive request | Strong source for treaty-port work |
| David Rumsey Collection | Historical China maps | https://www.davidrumsey.com/ | High-resolution downloads |

**CRS note**: Republican-era maps may use obsolete local datums or no explicit CRS.
Modern Chinese administrative layers usually use CGCS2000 (`EPSG:4490`), which is close
to WGS84 but should still be handled explicitly.

### United States

| Source | Coverage | Access | Notes |
|--------|----------|--------|-------|
| Library of Congress Maps | Broad historical map catalog | https://www.loc.gov/maps/ | High-resolution public files |
| David Rumsey Map Collection | 150,000+ historical maps | https://www.davidrumsey.com/ | API and download support |
| HOLC Redlining Maps | 1930s redlining polygons and scans | https://dsl.richmond.edu/panorama/redlining/ | Already vectorized for many use cases |
| Sanborn Fire Insurance Maps | Building-level urban map coverage, 1867-1970 | LOC / ProQuest | Some sheets are public via LOC |
| NHGIS | Historical census boundaries and tabulations | https://www.nhgis.org/ | Free with registration |

**HOLC note**: If the project only needs grade polygons, use the vector data directly.
If it needs annotations written on the maps, pull the original scans and run OCR.

### Singapore / Hong Kong / Malaya

| Source | Coverage | Access | Notes |
|--------|----------|--------|-------|
| National Archives of Singapore (NAS) | Colonial survey maps and planning maps | https://www.nas.gov.sg/ | Mixed online browsing and archive request |
| National Library Board (NLB) | Historical OneMap and related holdings | https://eresources.nlb.gov.sg/ | Partial online access |
| Hong Kong Map Service (HKMS) | Historical survey maps | https://www.landsd.gov.hk/ | Often request-based |
| UK National Archives | Colonial records and maps | https://www.nationalarchives.gov.uk/ | Some items require request or on-site review |

**CRS note**: Singapore commonly uses SVY21 (`EPSG:3414`), Hong Kong commonly uses
HK80 (`EPSG:2326`), and colonial maps often follow local survey datums that require
manual georeferencing.

## 2. Deliverables Structure

```text
project_dir/
  raw/
    scans/                 # Immutable original scans (TIFF or JPEG)
    reference/             # Reference maps, basemaps, satellite imagery
  processed/
    preprocessed/          # Contrast-normalized and deskewed scans
    georeferenced/         # GeoTIFF outputs
    masks/                 # Raster masks or segmentation outputs
  output/
    damage_zones.geojson   # Vectorized damage or land-use zones
    building_density.csv   # Block-level or grid-level density panel
    crosswalk_table.csv    # Historical-to-modern administrative mapping
    panel_data.csv         # Final panel-ready output
  docs/
    georef_report.pdf      # RMS error, GCP distribution, overlay screenshots
    extraction_report.pdf  # Extraction quality, coverage, and failure modes
    codebook.xlsx          # Variable definitions and source notes
    README.md              # Project-specific handoff notes
  scripts/
    01_preprocess.py
    02_georef.py
    03_extract.py
    04_encode.py
    05_crosswalk.py
    06_validate.py
  gcps/
    gcps.csv               # Pixel-to-geographic control points
    gcps_qgis.points       # QGIS control-point export
```

### Deliverables Checklist

- [ ] `damage_zones.geojson` is valid GeoJSON with CRS `EPSG:4326`
- [ ] `building_density.csv` contains `block_id`, `year`, `density`, `area_m2`
- [ ] `crosswalk_table.csv` contains `hist_id`, `modern_id`, `weight`, with weights normalized within each `hist_id`
- [ ] `georef_report.pdf` includes RMS error, GCP distribution, and overlay screenshots
- [ ] `codebook.xlsx` documents definitions, units, source provenance, and quality flags
- [ ] `README.md` explains sources, steps, and known limitations
- [ ] All scripts can reproduce outputs from the raw inputs without hidden manual edits

## 3. Dependencies

```text
# requirements-urban-history.txt
opencv-python>=4.8.0
numpy>=1.24.0
geopandas>=1.1.0
rasterio>=1.4.3
shapely>=2.0.0
pyproj>=3.6.0
GDAL>=3.7.0
torch>=2.0.0
lightglue>=0.0.1
exactextract>=0.2.0
scikit-image>=0.21.0
```

Installation:

```bash
pip install opencv-python numpy geopandas rasterio shapely pyproj GDAL torch
pip install git+https://github.com/cvg/LightGlue.git
pip install exactextract scikit-image
```

**GDAL install note**: On macOS, run `brew install gdal`, then
`pip install GDAL==$(gdal-config --version)`. On Linux, run
`apt install gdal-bin libgdal-dev`.
