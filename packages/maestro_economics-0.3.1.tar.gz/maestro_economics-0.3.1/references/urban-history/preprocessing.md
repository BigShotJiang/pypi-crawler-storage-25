# Preprocessing — Historical Map Scan Preparation

## Basic Preprocessing Pipeline

```python
import cv2
import numpy as np
from pathlib import Path


def preprocess_historical_map(img_path: str, target_dpi: int = 300) -> np.ndarray:
    """历史地图扫描件预处理：去噪 + 对比度增强 + DPI 标准化。

    Args:
        img_path: 输入图像路径（TIFF/PNG/JPEG）
        target_dpi: 目标 DPI（最低 300，建筑级分析建议 600）

    Returns:
        预处理后的图像矩阵 (BGR)
    """
    img = cv2.imread(img_path)
    if img is None:
        raise FileNotFoundError(f"无法读取图像: {img_path}")

    # 1. 去噪（保持边缘）
    denoised = cv2.fastNlMeansDenoisingColored(img, h=10, hForColorComponents=10)

    # 2. 对比度增强（CLAHE — 自适应直方图均衡化）
    lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    return enhanced


def remove_background_stains(img: np.ndarray, threshold: int = 200) -> np.ndarray:
    """去除纸张老化导致的背景黄斑/褐斑。

    原理: 将高亮度低饱和度区域统一为白色背景。
    """
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    # 低饱和度 + 高亮度 = 纸张背景
    mask = (hsv[:, :, 1] < 30) & (hsv[:, :, 2] > threshold)
    result = img.copy()
    result[mask] = [255, 255, 255]
    return result


def deskew(img: np.ndarray) -> np.ndarray:
    """自动校正扫描倾斜。

    基于 Hough 变换检测主方向，旋转至水平。
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)

    if lines is None:
        return img

    angles = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
        if abs(angle) < 45:  # 只取近水平线
            angles.append(angle)

    if not angles:
        return img

    median_angle = np.median(angles)
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), median_angle, 1.0)
    rotated = cv2.warpAffine(img, M, (w, h), borderValue=(255, 255, 255))
    return rotated
```

## Batch Preprocessing

```python
def batch_preprocess(input_dir: str, output_dir: str, target_dpi: int = 300):
    """批量预处理目录中的所有地图扫描件。"""
    in_path = Path(input_dir)
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    extensions = {".tif", ".tiff", ".png", ".jpg", ".jpeg"}
    files = [f for f in in_path.iterdir() if f.suffix.lower() in extensions]

    for f in sorted(files):
        print(f"处理: {f.name}")
        img = preprocess_historical_map(str(f), target_dpi)
        img = deskew(img)
        out_file = out_path / f"{f.stem}_preprocessed.tif"
        cv2.imwrite(str(out_file), img)
        print(f"  → {out_file}")
```

## DPI & Resolution Guide

| 分析粒度 | 最低 DPI | 典型分辨率 | 说明 |
|----------|---------|-----------|------|
| 街区级 | 300 | 5000x7000 px | 多数历史研究足够 |
| 建筑级 | 600 | 10000x14000 px | Sanborn、地籍图 |
| 文字识别 | 400+ | — | 配合 OCR 使用 |

**注意**: 扫描件 DPI 信息可能不准（嵌入元数据与实际分辨率不符）。以实际像素分辨率为准。
