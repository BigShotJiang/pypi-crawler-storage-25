# Feature Extraction — Color Segmentation, VLM Classification, Vectorization

## 1. Color Segmentation (Damage Levels / Land Use)

Historical maps typically use color coding for categorical information.

### 1.1 Color Legend Definitions

```python
import cv2
import numpy as np
import json
from pathlib import Path

COLOR_LEGENDS = {
    "hiroshima_damage": {
        "total_destruction": {"lower": [0, 100, 100], "upper": [10, 255, 255], "label": "全毁"},
        "severe_damage": {"lower": [10, 100, 100], "upper": [25, 255, 255], "label": "重损"},
        "moderate_damage": {"lower": [25, 100, 100], "upper": [35, 255, 255], "label": "中损"},
        "light_damage": {"lower": [35, 80, 100], "upper": [85, 255, 255], "label": "轻损"},
        "undamaged": {"lower": [85, 50, 100], "upper": [130, 255, 255], "label": "完好"},
    },
    "holc_redlining": {
        "A_best": {"lower": [35, 50, 100], "upper": [85, 255, 255], "label": "A-Best (Green)"},
        "B_desirable": {"lower": [100, 50, 100], "upper": [130, 255, 255], "label": "B-Desirable (Blue)"},
        "C_declining": {"lower": [20, 50, 100], "upper": [35, 255, 255], "label": "C-Declining (Yellow)"},
        "D_hazardous": {"lower": [0, 100, 100], "upper": [10, 255, 255], "label": "D-Hazardous (Red)"},
    },
}
```

### 1.2 Zone Extraction by Color

```python
def extract_zones_by_color(
    georef_map_path: str,
    legend_name: str,
    output_dir: str,
    min_area_px: int = 500,
) -> dict[str, np.ndarray]:
    """按颜色图例提取地图区域。"""
    img = cv2.imread(georef_map_path)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    legend = COLOR_LEGENDS[legend_name]
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    masks = {}
    for zone_key, zone_def in legend.items():
        lower = np.array(zone_def["lower"])
        upper = np.array(zone_def["upper"])

        mask = cv2.inRange(hsv, lower, upper)

        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        clean_mask = np.zeros_like(mask)
        for cnt in contours:
            if cv2.contourArea(cnt) >= min_area_px:
                cv2.drawContours(clean_mask, [cnt], -1, 255, -1)

        masks[zone_key] = clean_mask
        cv2.imwrite(str(out_path / f"{zone_key}.tif"), clean_mask)

    return masks
```

### 1.3 Legend Calibration from Samples

```python
def calibrate_legend_from_sample(
    map_image: np.ndarray,
    sample_regions: list[dict],
) -> dict:
    """从地图图例区域取样校准颜色范围。

    重要: 扫描时的白平衡、色偏会影响颜色值。
    不能用固定 RGB/HSV 值，必须从当前地图的图例区域取样。

    Args:
        map_image: 地图图像 (BGR)
        sample_regions: [{"label": "全毁", "bbox": (x, y, w, h)}]
    """
    hsv = cv2.cvtColor(map_image, cv2.COLOR_BGR2HSV)
    calibrated = {}

    for sample in sample_regions:
        x, y, w, h = sample["bbox"]
        roi = hsv[y:y + h, x:x + w]

        h_med, s_med, v_med = np.median(roi, axis=(0, 1))
        h_std, s_std, v_std = np.std(roi, axis=(0, 1))

        margin = 2.0
        calibrated[sample["label"]] = {
            "lower": [
                max(0, int(h_med - margin * h_std)),
                max(0, int(s_med - margin * s_std)),
                max(0, int(v_med - margin * v_std)),
            ],
            "upper": [
                min(179, int(h_med + margin * h_std)),
                min(255, int(s_med + margin * s_std)),
                min(255, int(v_med + margin * v_std)),
            ],
        }

    return calibrated
```

**Key lesson**: NEVER use fixed HSV values for color segmentation. Different scanners, different scan times produce different color offsets. Always calibrate from legend color patches.

---

## 2. VLM-Assisted Classification (Complex Symbols)

For regions that cannot be segmented by color (symbol annotations, line type distinctions, complex patterns), use VLM tile classification.

```python
def vlm_classify_tiles(
    georef_map_path: str,
    tile_size: int = 512,
    overlap: int = 64,
    categories: list[str] = None,
) -> list[dict]:
    """将地图分块，用 VLM 分类每个块的主要用途/特征。"""
    if categories is None:
        categories = ["residential", "commercial", "industrial", "public", "open_space", "water"]

    img = cv2.imread(georef_map_path)
    h, w = img.shape[:2]

    tiles = []
    step = tile_size - overlap

    for y in range(0, h - tile_size + 1, step):
        for x in range(0, w - tile_size + 1, step):
            tile = img[y:y + tile_size, x:x + tile_size]
            tiles.append({"x": x, "y": y, "tile": tile})

    results = []
    prompt = f"""请判断这个历史地图切片的主要土地用途类别。
可选类别: {', '.join(categories)}
只返回一个类别名称和置信度（0-1），格式: {{"category": "...", "confidence": 0.8}}"""

    for batch_start in range(0, len(tiles), 16):
        batch = tiles[batch_start:batch_start + 16]
        for tile_info in batch:
            results.append({
                "tile_x": tile_info["x"],
                "tile_y": tile_info["y"],
                "category": "residential",  # placeholder
                "confidence": 0.0,
            })

    return results
```

---

## 3. Vectorization

```bash
# GDAL polygonize
gdal_polygonize.py damage_total.tif -f "GeoJSON" damage_total.geojson damage_class
```

```python
import rasterio
from rasterio.features import shapes
import geopandas as gpd
from shapely.geometry import shape


def vectorize_mask(
    mask_tif: str,
    output_geojson: str,
    label: str = "zone",
    simplify_tolerance: float = 0.0001,
) -> gpd.GeoDataFrame:
    """将二值掩码 GeoTIFF 转为矢量 GeoJSON。"""
    with rasterio.open(mask_tif) as src:
        mask = src.read(1)
        transform = src.transform
        crs = src.crs

    polygons = []
    for geom, value in shapes(mask, mask=mask > 0, transform=transform):
        poly = shape(geom)
        if simplify_tolerance > 0:
            poly = poly.simplify(simplify_tolerance)
        polygons.append({"geometry": poly, "label": label, "value": int(value)})

    gdf = gpd.GeoDataFrame(polygons, crs=crs)
    gdf.to_file(output_geojson, driver="GeoJSON")

    return gdf
```

---

## 4. Attribute Encoding

### 4.1 Standard Attribute System

```python
import geopandas as gpd
import pandas as pd
import numpy as np


def encode_attributes(
    zones_gdf: gpd.GeoDataFrame,
    blocks_gdf: gpd.GeoDataFrame = None,
    damage_legend: dict = None,
) -> gpd.GeoDataFrame:
    """为矢量化区域编码标准属性。"""
    crs_utm = zones_gdf.estimate_utm_crs()
    zones_proj = zones_gdf.to_crs(crs_utm)

    zones_proj["area_m2"] = zones_proj.geometry.area

    if blocks_gdf is not None:
        blocks_proj = blocks_gdf.to_crs(crs_utm)
        blocks_proj["block_area_m2"] = blocks_proj.geometry.area
        overlay = gpd.overlay(zones_proj, blocks_proj, how="intersection")
        overlay["zone_in_block_area"] = overlay.geometry.area
        density = (
            overlay.groupby("block_id")["zone_in_block_area"].sum()
            / overlay.groupby("block_id")["block_area_m2"].first()
        ).reset_index()
        density.columns = ["block_id", "building_density"]
        zones_proj = zones_proj.merge(density, on="block_id", how="left")

    if damage_legend:
        damage_scale = {
            "total_destruction": 4,
            "severe_damage": 3,
            "moderate_damage": 2,
            "light_damage": 1,
            "undamaged": 0,
        }
        zones_proj["damage_grade"] = zones_proj["label"].map(damage_scale)

    landuse_codes = {
        "residential": "R", "commercial": "C", "industrial": "I",
        "public": "P", "open_space": "O", "water": "W", "mixed": "M",
    }
    if "category" in zones_proj.columns:
        zones_proj["landuse_code"] = zones_proj["category"].map(landuse_codes)

    if "confidence" in zones_proj.columns:
        zones_proj["quality_flag"] = pd.cut(
            zones_proj["confidence"],
            bins=[0, 0.3, 0.7, 1.0],
            labels=["low", "medium", "high"],
        )

    return zones_proj.to_crs(zones_gdf.crs)
```

### 4.2 Attribute Field Standard

| 字段 | 类型 | 说明 |
|------|------|------|
| `zone_id` | str | 唯一区域标识 |
| `area_m2` | float | 区域面积（平方米） |
| `damage_grade` | int (0-4) | 破坏等级：0=完好, 4=全毁 |
| `landuse_code` | str | 土地用途代码 (R/C/I/P/O/W/M) |
| `landuse_label` | str | 土地用途中文标签 |
| `building_density` | float (0-1) | 建筑覆盖率 |
| `confidence` | float (0-1) | 提取置信度 |
| `quality_flag` | str | 质量标记 (high/medium/low) |
| `source_map` | str | 来源地图标识 |
| `extraction_method` | str | 提取方法 (color_seg/vlm/manual) |
