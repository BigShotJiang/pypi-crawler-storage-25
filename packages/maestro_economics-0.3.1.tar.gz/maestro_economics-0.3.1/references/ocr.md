
# Maestro Data OCR

OCR and scanned document processing pipeline for large-scale document digitization.

## When to Use

- Digitizing scanned documents (gazetteers, historical records, government reports)
- Table extraction from PDF/image pages
- Multi-path OCR validation for numeric accuracy
- DPI optimization for OCR throughput vs accuracy

## When NOT to Use

- Born-digital PDFs with selectable text (use direct text extraction)
- Simple image-to-text without tables (use basic VLM prompt)
- Data quality checks on already-extracted data (use `maestro-data-qa`)

## Cross-References

- OCR feasibility assessment: `maestro-data-assess`
- LaTeX report generation after OCR: `maestro-data-pdf`
- Data quality checks on OCR output: `maestro-data-qa`

--------------------------------------------------------------------------------

## Core Workflow (10 Steps)

1. **Render** PDF pages to PNG (`pdftoppm` or `pdf2image`)
2. **Triage** pages: `scripts/screen_pages.py` classifies table vs non-table
3. **Select tier**: CPU (PP-OCRv5) → API (Baidu/DeepInfra) → GPU (PaddleOCR-VL)
4. **Extract** tables: `scripts/vlm_extract.py` for VLM path; PaddleOCR for CPU path
5. **Cross-validate**: multi-path comparison (OCR vs embedded text vs VLM)
6. **Arithmetic check**: `scripts/arithmetic_grade.py` verifies row consistency
7. **Clean values**: dash normalization, triangle negatives, thousand-separator repair
8. **Semantic parse**: column header interpretation (2-pass: positional then semantic)
9. **External cross-val**: compare against SciDB/provincial yearbook reference data
10. **Export**: graded CSV with confidence grades and audit trail

--------------------------------------------------------------------------------

## CLI Quick Reference

### `scripts/vlm_extract.py` -- VLM table extraction via OpenRouter

```bash
python scripts/vlm_extract.py page.png                    # stdout
python scripts/vlm_extract.py page.png -o table.csv       # file output
python scripts/vlm_extract.py page.png --model qwen/qwen3-vl-30b-a3b-thinking
python scripts/vlm_extract.py page.png --raw               # debug: raw response
# Env: OPENROUTER_API_KEY, VLM_MODEL
```

Default model: `qwen/qwen3-vl-235b-a22b-thinking` (NO `:free` suffix). Provider: `alibaba`.

### `scripts/arithmetic_grade.py` -- Arithmetic cross-check

```bash
python scripts/arithmetic_grade.py extracted.csv
python scripts/arithmetic_grade.py data.csv --area-col planted_area --yield-col yield_per_mu
python scripts/arithmetic_grade.py data.csv --unit-col unit_header  # auto-detect units
```

Grades: `exact` (<0.5%), `pass` (<2%), `marginal` (<5%), `fail` (>=5%), `skip` (missing).

### `scripts/screen_pages.py` -- Fast page triage

```bash
python scripts/screen_pages.py pages/                      # image-only mode
python scripts/screen_pages.py pages/ --text-dir pages_text/  # with OCR text (recommended)
python scripts/screen_pages.py pages/ --output manifest.csv --tables-only
```

### Typical Pipeline

```bash
python scripts/screen_pages.py pdf_pages/ --output manifest.csv
# extract table pages with VLM (loop over manifest.is_table rows)
python scripts/arithmetic_grade.py extracted.csv --output graded.csv
```

--------------------------------------------------------------------------------

## OCR Tier Selection

| Tier | Model | Speed (CPU) | Accuracy | Cost |
|------|-------|-------------|----------|------|
| 1 (default) | PP-OCRv5 server | ~4.3s/page | ~94.6% | Free, local |
| 2 (API) | Baidu PaddleOCR API / DeepInfra VL | GPU-backed | Higher | Free beta / pay |
| 3 (GPU) | PaddleOCR-VL-1.5 self-hosted | ~15-30s/page | 98.2% | GPU required |

**Principle**: Start CPU (Tier 1). Escalate only if accuracy insufficient.

```python
from paddleocr import PaddleOCR
ocr = PaddleOCR(ocr_version="PP-OCRv5", device="cpu", lang="ch")
result = ocr.predict(image_path)
```

--------------------------------------------------------------------------------

## DPI Reference (A4 Page)

| DPI | Pixels | PP-OCRv5 CPU | Claude Vision |
|-----|--------|--------------|---------------|
| 100 | 698x1019 | ~21s (optimal) | OK |
| 150 | 1046x1528 | ~40s | OK (max no-resize) |
| 300 | 2092x3055 | ~180s | Internal resize, OK |

--------------------------------------------------------------------------------

## Key Rules

1. **CPU first** -- PP-OCRv5 handles 750 pages in ~1hr at zero cost
2. **Multi-path mandatory** -- never trust single OCR path for tables
3. **Claude Vision is NOT ground truth** -- 2-5% digit misread rate; tiebreaker only
4. **External cross-val before delivery** -- arithmetic check is internal only; unit errors need reference data
5. **Negative filters before positive** -- filter ordering is critical (see pipeline-patterns.md)

--------------------------------------------------------------------------------

## Gotchas

1. **Space-separated digits**: PP-OCRv5 outputs "422 460" for 422460. Fix: `re.sub(r"(\d)\s+(\d)", r"\1\2", text)`
2. **千位分隔符 breaks CSV**: LLM outputs `91,755` → DictReader splits into two columns. Fix: `_repair_row_thousands()`
3. **Unit factor 2x systematic error**: 千公斤 vs 千斤 invisible to arithmetic check. Detect via external reference ratio ≈ 0.5
4. **Full-width characters**: Always normalize before processing
5. **OpenRouter model name**: `qwen/qwen3-vl-235b-a22b-thinking` -- NO `:free` suffix (causes 404)
6. **BOM encoding**: Use `encoding='utf-8-sig'` when reading CSVs on macOS
7. **SQLite on Dropbox**: Must use `PRAGMA journal_mode=DELETE` (WAL incompatible)
8. **PaddleOCR table detection misses merged cells**: use PP-StructureV3 or VLM fallback for complex tables.
9. **DPI matters**: 300 DPI minimum for standard text, 600 for fine print or degraded scans.
10. **VLM hallucination on numbers**: always cross-validate VLM OCR results with PaddleOCR. Numbers are the most common hallucination target.
11. **PDF page rendering differs**: poppler and pymupdf produce different rasterizations. Standardize on one.

--------------------------------------------------------------------------------

## Reference Files

| File | Description |
|------|-------------|
| `references/ocr-pipeline.md` | Full PaddleOCR pipeline details, multi-path validation |
| `references/model-landscape.md` | OCR model rankings (2025-2026), VLM comparison, LAN GPU architecture |
| `references/cross-validation.md` | Multi-path validation code, unit factor taxonomy, external cross-val SOP |
| `references/pipeline-patterns.md` | Production pipeline logic, SQLite patterns, deployment checklist |
| `references/semantic-parsing.md` | Two-pass semantic column parsing, value cleaning pipeline |
