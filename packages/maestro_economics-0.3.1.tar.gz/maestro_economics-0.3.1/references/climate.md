
# maestro-climate — Climate Data for Economics Research

## Overview

Climate is among the most-used exogenous variables in empirical economics. This skill catalogs
every major source, its precise download path, variables, resolution, and the workflow for
matching gridded data to administrative units (county, district, municipality, country).

**Pipeline position:** `maestro-climate → maestro-data-analyst → maestro-data-qa → maestro-paper`

---

## 1. Source Selection Guide

```
Research design                         → Recommended source
────────────────────────────────────────────────────────────────────
Cross-country macro panel (50+ nations) → CRU TS (0.5°, monthly) or UDEL
                                         ERA5 if post-2020 or need high-freq
Single country, subnational panel
  China (county/prefecture)             → CMA/CMDC station IDW  or  ERA5 0.25°
  United States (county)                → PRISM (agriculture) or nClimGrid-Daily
  India (district)                      → IMD 0.25° rainfall; IMD 1° temperature
  Brazil (município)                    → CLIMBra 0.1°  or  INMET stations
  Indonesia / S. Asia (kabupaten)        → ERA5 0.25°  or  CHIRPS (precip)
  Africa (any admin level)              → CHIRPS (precip) + CRU TS (temp)
  Japan / Korea                         → JMA / KMA station data  or  ERA5
Mountain / high topographic variation   → CHELSA 1km (mechanistic downscaling)
Cross-sectional baseline controls       → WorldClim v2 BIO1–BIO19 (1970–2000 avg)
High-frequency (daily / hourly), global → ERA5 (only complete option)
Historical pre-1950                     → CRU TS (1901+)  or  UDEL (1900+)
Drought / SPEI index                    → CRU TS + SPEI package  or  CSIC v2.7
```

---

## 2. Core Workflow (10 Steps)

1. **Identify research design** → pick source from selection guide above
2. **Check registry** → see if panel already built (`references/registry-and-pricing.md`)
3. **Download raw data** → use `maestro-fetch` or source-specific script
4. **Prepare admin polygons** → GADM v4.1 or national shapefile, ensure EPSG:4326
5. **Run zonal statistics** → `rasterstats.zonal_stats()` or `fast_zonal_nc.py` for large jobs
6. **Build panel** → merge variable CSVs with `build_panel.py`
7. **Unit conversion** → ERA5: K→°C (−273.15), m→mm (×1000); WorldClim BIO1: ÷10
8. **Validate** → `validate_panel.py` (missing rate, range checks, duplicates)
9. **Generate deliverables** → codebook.xlsx + version.json + report.pdf
10. **Register dataset** → `maestro_datasets.py mark-downloaded`

---

## 3. CLI Quick Reference

```bash
# Download scripts (from this repo's scripts/climate/ directory)
python download_chirps.py --years 1981-2023
python download_era5.py --var 2m_temperature --years 1950-2023
python download_imd.py --var rain --years 1990-2020
python download_nclimgrid.py --years 1895-2024

# Processing
python grid_to_admin.py --raster data.nc --shapefile admin.gpkg --stats mean,sum
python fast_zonal_nc.py --nc data.nc --shapefile admin.gpkg  # 100x faster for large NC
python build_panel.py --inputs data_tmp.csv data_pre.csv --output data.csv

# Output
python validate_panel.py --input data.csv
python generate_codebook.py --input data.csv --output codebook.xlsx
python generate_report_latex.py --input data.csv --output report.pdf

# Registry
python /path/to/your/dataset-registry-tool.py mark-downloaded \
    {id} --path ~/Dropbox/datasets/{slug}/
```

---

## 4. Key Rules

1. **Always scope ERA5 requests** by variable + year + bbox — never request full archive
2. **WorldClim is a climatology** (1970–2000 avg) — never use for panel FE or shock identification
3. **Use `fast_zonal_nc.py`** for >500 time steps — 100x faster than per-step rasterstats
4. **Register every downloaded dataset** via `maestro_datasets.py mark-downloaded`
5. **Deliver 5 standard files** with every built panel: data.csv, codebook.xlsx, README.md, version.json, report.pdf

---

## 5. Pitfalls

| Pitfall | Fix |
|---------|-----|
| ERA5 precip in meters → appears near zero | Multiply ×1000 for mm |
| ERA5 temp in Kelvin | Subtract 273.15 for °C |
| CRU TS fill value 9.96921e+36 masked incorrectly | Open with `mask_and_scale=True` |
| WorldClim BIO1 is ×10 (e.g. 250 = 25.0°C) | Divide by 10 |
| CHIRPS missing tropics > 50° latitude | Known coverage limit; use ERA5/CRU for higher lat |
| UDEL uses 0.5° grid starting at −89.75 not −90 | Use `xr.interp()` not integer index |
| China CMA IDW: edge counties far from stations | Add nearest-neighbor fallback; flag distance > 100km |
| nClimGrid county FIPS code → 5-digit string | Zero-pad: `f"{fips:05d}"` |

---

## Gotchas

- **ERA5 hourly has gaps pre-1979**: use ERA5-Land or CRU TS for pre-1979 data.
- **CRU TS is monthly only**: no daily resolution. Use ERA5 or CHIRPS for daily.
- **CHIRPS starts 1981**: no data before 1981. Use CRU TS or UDEL for earlier periods.
- **Temperature unit confusion (K vs °C)**: ERA5 uses Kelvin. Subtract 273.15 for Celsius.
- **Leap year handling in daily panels**: 366 days in leap years. Many datasets skip Feb 29.

---

## 6. Detailed References

- **Dataset catalog** (all sources, download URLs, code examples): `references/datasets.md`
- **Matching methodology** (zonal stats workflow, country-specific code, variables table, cited papers): `references/matching.md`
- **Registry, scripts & pricing** (dataset inventory, script reference, pricing tiers): `references/registry-and-pricing.md`
