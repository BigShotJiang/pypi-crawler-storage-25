
# Maestro Urban Hedonic — Housing Hedonic Price Analysis SOP

## When to Use

- Building housing price panels from transaction data
- Hedonic regression (OLS, spatial lag/error, TWFE)
- Causal impact of transit/schools/parks/amenities on house prices
- Repeat-sales price index construction (Case-Shiller method)
- Housing supply elasticity estimation
- Rent capitalization analysis

## When NOT to Use

- Commercial real estate → different valuation models
- Macro housing price forecasting → time series methods
- Mortgage/credit analysis → financial skill
- Raw data acquisition → start with `maestro-fetch`

## Skill Connections

```
maestro-fetch → data acquisition
maestro-urban-hedonic → panel construction + hedonic analysis (THIS SKILL)
maestro-data-spatial → spatial variable computation (distances, buffers, raster extraction)
maestro-analysis → regression + causal inference
maestro-paper → paper writing + table output
```

## Core Workflow

1. **Acquire transaction data** (country-specific sources)
2. **Geocode addresses** → lat/lon (WGS-84)
3. **Compute spatial controls**: dist_mrt, dist_cbd, dist_school, dist_park, POI density, NDVI
4. **Construct panel**: property_id × time with all controls
5. **Run hedonic regression** (OLS → spatial → TWFE as needed)
6. **Robustness checks**: distance thresholds, time windows, placebo, VIF, Moran's I
7. **Export**: Stata .dta, R .rds, Parquet

→ See [references/data-sources.md](references/data-sources.md) for transaction data by country + geocoding APIs.
→ See [references/panel-construction.md](references/panel-construction.md) for spatial controls + panel assembly.
→ See [references/methods.md](references/methods.md) for regression methods + IV strategies.
→ See [references/output-and-validation.md](references/output-and-validation.md) for export formats + quality checks.
→ See [references/country-gotchas.md](references/country-gotchas.md) for country-specific pitfalls.
→ See [references/bibliography.md](references/bibliography.md) for key references.

## Key Rules

1. **Log price** as dependent variable: `ln(price) ~ X` (semi-log preferred)
2. **Always control lease remaining** for leasehold markets (Singapore HDB, UK)
3. **Unify CRS before distance calculations** — China GCJ-02 offset = hundreds of meters
4. **Spatial autocorrelation**: run Moran's I on OLS residuals; if significant → spatial model or cluster SE
5. **Staggered DID**: don't use naive TWFE — use Callaway-Sant'Anna or Sun-Abraham

## Standard Control Variables

| Variable | Source | Notes |
|----------|--------|-------|
| `floor_area_sqm` | Transaction data | Always include |
| `rooms` / `flat_type` | Transaction data | FE or continuous |
| `floor_level` | Transaction data | Mid-point of range for HDB |
| `building_age` | Derived | `year - build_year` |
| `lease_remaining` | Transaction data | + quadratic term for HDB |
| `dist_mrt` | `sjoin_nearest()` | Meters, project to local CRS |
| `dist_cbd` | `geometry.distance()` | Use CBD coordinates per city |
| `dist_school` | `sjoin_nearest()` | Nearest primary school |
| `poi_500m` | OSM via `osmnx` | Use STRtree for performance |
| `ndvi_500m` | GEE MODIS | Buffer extract |

## Gotchas

| Problem | Cause | Fix |
|---------|-------|-----|
| HDB lease <60yr price crash | 99-year leasehold | Control `lease_remaining` + quadratic |
| China listing ≠ transaction price | Lianjia shows both | Use chengjiao (成交) only |
| China CRS mismatch | GCJ-02 vs WGS-84 | `gcj02_to_wgs84()` before spatial ops |
| Japan building ≈ zero value | Wooden 30yr+ depreciation | Treat as land-only transaction |
| MRT endogeneity | Station siting non-random | Use IV (historical roads) or DID |
| dist_mrt ↔ dist_cbd collinear | Spatial correlation | Check VIF; drop one or use log-distance |
| Staggered treatment bias | TWFE negative weights | Use `csdid` or `eventstudyinteract` |
| POI count slow at scale | Point-in-buffer loop | Use `shapely.STRtree` spatial index |

## City Quick Reference

| City | CRS | Geocoding | CBD (WGS84) | Primary source |
|------|-----|-----------|-------------|----------------|
| Singapore | EPSG:3414 | OneMap | 103.85, 1.28 | data.gov.sg HDB |
| Beijing | UTM 50N | Amap (GCJ-02!) | 116.41, 39.90 | Lianjia |
| Tokyo | EPSG:6677 | MLIT | 139.77, 35.68 | MLIT API |
| New York | EPSG:2263 | Census | -74.01, 40.71 | Zillow |
| London | EPSG:27700 | Nominatim | -0.13, 51.51 | Land Registry |

## Dependencies

```
pandas, geopandas, shapely, osmnx, statsmodels, pyfixest
spreg, libpysal, esda, pyreadr, coord-convert
```
