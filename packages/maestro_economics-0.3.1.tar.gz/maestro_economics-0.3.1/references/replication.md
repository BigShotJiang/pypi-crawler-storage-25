
# Maestro Data Replication

**Input sources:**
- Analysis results (regression tables, figures) from `maestro-analysis`
- Cleaned panel data from `maestro-data-analyst`

**Output:**
- AEA-compliant replication package (.zip)
- Reproducible Python scripts + figures
- LaTeX report compiled via `maestro-data-pdf`

## Project Structure

```
04-delivery/
  scripts/
    config.py             # ONLY file client edits (paths + parameters)
    fig1_*.py             # one script per figure family
    run_all.sh
  output/figures/         # generated automatically on first run
  output/figures/single/  # single-figure outputs (--mode single)
  report/
    assets/
      maestro-logo.png
    report.tex
    report.pdf
  requirements.txt
  README.md
```

## Replication Package Structure (AEA/Journal Submission)

Distinct from the `04-delivery/` structure above, this is for journal submission packages:

```
replication-package/
  1-paper/                    # LaTeX source + compiled PDF
    main.tex
    tables.tex
    figures.tex
    references.bib
    journal-style.cls
    *.eps / *.png
  2-appendix/                 # Online appendix
    appendix.pdf
  3-replication/              # Data + code + docs
    analysis_code.py          # Single script that reproduces all tables/figures
    data_admin.csv
    data_survey.csv
    data_admin.dta            # Stata format (for Stata users)
    data_survey.dta
    README.pdf
    README.docx
    additional_files/
      survey_instrument.pdf
      IRB_approval.pdf
      experiment_design.pdf
```

Key rules:
- `analysis_code.py` (or `.do`) must reproduce ALL tables and figures from a clean state
- Dual-format data delivery (CSV + DTA) for cross-platform compatibility
- README in both PDF and DOCX (journal requirement varies)
- `additional_files/` for IRB, survey instruments, pre-registration, etc.

## Reverse-Engineering Mode

Generate visualizations from published papers WITHOUT raw data access.

**Workflow:**
1. Parse published LaTeX tables to extract coefficients + SEs
2. Build structured data (dict/DataFrame) from extracted values
3. Generate coefficient plots, exposure heterogeneity plots, reproduced LaTeX tables

**Implementation pattern** (ref: `analysis/jebo-education/scripts/parse_and_plot.py`):
```python
# 1. Extract from LaTeX source into structured dicts
table4 = {
    "columns": [
        {"label": "MPL1\nRisk Neutral", "coef": 0.118, "se": 0.035, "stars": "***", "n": 765},
        ...
    ],
}

# 2. Generate coefficient plot with 95% CI
ax.scatter(positions, coefs, ...)
ax.vlines(positions[i], coef - 1.96*se, coef + 1.96*se, ...)

# 3. Export: PNG (300 DPI), reproduced LaTeX table, coefficients JSON
```

**Use case:** Professor wants visualization of results from a paper they are citing or replicating, but has no access to the underlying microdata.

**Outputs:** coefficient plot PNG, reproduced LaTeX table, `extracted_coefficients.json`.

## Two Modes: Panel vs Single

Every figure script supports `--mode panel` (default) and `--mode single`.

| Mode | Use case | Output |
|------|----------|--------|
| `panel` | Delivery report, overview | Multi-panel grid (e.g. 2×4) |
| `single` | Client paper embedding | One panel, journal-sized |

```bash
python fig1_histograms.py                         # panel: 2x4 grid
python fig1_histograms.py --mode single --year 2000  # single panel for paper
python fig2_county_maps.py --mode single --year 1990 --var avg_temp
```

Single outputs go to `output/figures/single/` with filename `fig1a_2000.tex` etc.

## Script Template

```python
#!/usr/bin/env python3
"""fig1_histograms.py -- Temperature and precipitation distributions.

Modes:
  panel  (default): 2x4 grid -> fig1a_temp_histograms.tex, fig1b_precip_histograms.tex
  single:           1 panel  -> single/fig1a_YYYY.tex  (journal-sized)
"""
from __future__ import annotations  # REQUIRED for Python 3.9 compat
import argparse
from config import DATA_DIR, OUTPUT_DIR, REPRESENTATIVE_YEARS

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--mode', choices=['panel', 'single'], default='panel')
    p.add_argument('--year', type=int, default=2000,
                   help='Year to plot in single mode')
    args = p.parse_args()

    if args.mode == 'panel':
        run_panel()
    else:
        run_single(args.year)

if __name__ == '__main__':
    main()
```

## Figure Design Standards

See `references/figure-layout.md` for the full specification.

**Journal sizing (matplotlib):**

| Target | figsize inches | base fontsize |
|--------|---------------|---------------|
| Single column | 3.5 × 2.5 | 8 pt |
| 1.5 column | 5.0 × 3.5 | 9 pt |
| Double column | 7.0 × 4.5 | 10 pt |
| Full page | 6.5 × 9.0 | 10 pt |

**Always set at top of single-mode matplotlib figures:**
```python
import matplotlib
matplotlib.rcParams.update({
    'font.family': 'serif',
    'font.size': 9,
    'axes.labelsize': 9,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 8,
    'figure.dpi': 300,
})
```

**pgfplots single-panel wrapper for paper:**
```latex
\resizebox{0.45\textwidth}{!}{%   % 0.45=single col, 0.9=double col
\begin{tikzpicture}
\begin{axis}[width=7cm, height=5cm, ...]
...
\end{axis}
\end{tikzpicture}%
}
```

## Multi-Domain Coefficient Plots

For papers with results across multiple outcome domains (different y-axis scales):

**Pattern** (ref: `analysis/jebo-education/scripts/parse_and_plot.py`):
- `plt.subplots(1, N)` with `gridspec_kw={"width_ratios": [...]}` proportional to column count per domain
- Each panel has its own y-axis scale and unit label (e.g., proportion, RMB, coins)
- Zero line: `ax.hlines(0, ...)` dashed grey across all panels
- Significance stars positioned above upper CI bound
- Domain-specific color palette (blue for risk, red for social, green for probabilistic)

**Exposure heterogeneity** (Freshman vs Post-Freshman side-by-side):
```python
width = 0.35
ax.errorbar(positions - width/2, fresh_coefs, yerr=fresh_ci, fmt="o",
            color="#7FCDBB", label="Freshman")
ax.errorbar(positions + width/2, post_coefs,  yerr=post_ci,  fmt="s",
            color="#2C7FB8", label="Post-Freshman")
```

**Checklist:**
- [ ] Each domain gets its own subplot (never mix scales on one axis)
- [ ] Width ratios match number of outcomes per domain
- [ ] Stars only on significant coefficients, positioned at CI upper bound + 5% margin
- [ ] Times New Roman, 300 DPI, spines removed (top + right)

## Critical pgfplots Rules

```latex
% CORRECT: histograms
ybar interval,          % auto bar width from bin edges -- DO NOT use bar width=Xpt

% CORRECT: annotation nodes with line breaks
\node[align=left, font=\tiny, ...] at (...) {line1 \\ line2};
%          ^^^^^^^^^^^ REQUIRED or LaTeX throws "Not allowed in LR mode"

% CORRECT: include generated .tex in report -- no wrapping figure env
\input{../output/figures/fig1a_temp_histograms.tex}   % the .tex already has \begin{figure}
```

## Known Pitfalls

See `references/lessons-learned.md` for the full annotated list.

| Pitfall | Fix |
|---------|-----|
| `int \| None` fails on Python 3.9 | Add `from __future__ import annotations` |
| `bar width=Xpt` unknown pgfkeys error | Use `ybar interval` instead |
| `\\` in TikZ node causes LR mode error | Add `align=left` to node options |
| Double CSV read in loop | Read header once, reuse column list |
| Station count dict missing final year | Always verify dict spans full data range |
| `config.py` has absolute local paths | Use placeholder strings in delivered file |
| `\input` of `.tex` inside `\begin{figure}` | Remove outer figure env; .tex has its own |

## LaTeX Report

See `references/latex-report.md` for the full report structure.

```bash
cd report/
cp /Users/ding/maestro/branding/maestro-logo-512.png assets/maestro-logo.png
xelatex -interaction=nonstopmode report.tex && xelatex -interaction=nonstopmode report.tex
grep "Overfull" report.log   # fix any > 5pt
```

Embed in report:
```latex
% pgfplots .tex (already has \begin{figure})
\input{../output/figures/fig1a_temp_histograms.tex}

% PNG
\begin{figure}[H]
\centering
\includegraphics[width=\textwidth]{../output/figures/fig4_missingness_heatmap.png}
\caption{...}
\end{figure}
```

## Delivery Checklist

- [ ] `bash run_all.sh` exits 0, all 7+ output files present
- [ ] `--mode single` works for every figure script
- [ ] `config.py` contains placeholder paths, not local absolute paths
- [ ] `from __future__ import annotations` at top of every script
- [ ] Python version noted in README (require 3.9+)
- [ ] GDAL install instructions for macOS, Ubuntu, Windows in README
- [ ] `report.pdf` compiles zero errors, all figures visible
- [ ] Overfull boxes all < 5pt

## Gotchas

- **Publication-ready = vector format**: Use PDF not PNG for journal figures. PNG at 300 DPI is acceptable only for raster data.
- **Journal column width**: 3.5in for single column, 7in for double. Figures outside this get rejected.
- **pgfplots compat=1.18 breaks old axis environments**: Pin compat version in preamble.
