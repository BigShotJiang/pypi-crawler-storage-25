# Balance Tests and Summary Statistics

Standards for pre-treatment covariate balance tables and descriptive statistics.
Extracted from: Ramadan RCT (multi-arm balance), JEBO Education (quasi-experiment).

---

## 1. Balance Table Structure

```
                    Control    Treatment   Diff      Norm.Diff   p-value
                    Mean (SD)  Mean (SD)   (T-C)     (T-C)/sp    (t-test)
----------------------------------------------------------------------
Age                 18.3       18.2        -0.1       -0.03      0.784
                    (1.2)      (1.1)
Female              0.52       0.49        -0.03      -0.06      0.512
Pre-test score      72.4       73.1         0.7        0.04      0.623
                    (15.8)     (16.2)
...
----------------------------------------------------------------------
Joint F-test                                                     0.XXX
N                   XXX        XXX
```

Columns:
- Control mean (SD below, in parentheses)
- Treatment mean (SD below)
- Raw difference (T - C)
- Normalized difference: (mean_T - mean_C) / sqrt((sd_T^2 + sd_C^2) / 2)
- p-value from two-sample t-test (or rank-sum for non-normal)

Bottom row: Joint F-test from regressing treatment on all covariates.

---

## 2. Python Implementation

```python
import numpy as np
import pandas as pd
from scipy import stats

def balance_table(df, treatment_var, covariates, treatment_val=1, control_val=0):
    """Generate balance table for treatment vs control.

    Args:
        df: DataFrame
        treatment_var: name of binary treatment column
        covariates: list of covariate column names
        treatment_val: value indicating treatment group
        control_val: value indicating control group

    Returns:
        DataFrame with balance statistics
    """
    treat = df[df[treatment_var] == treatment_val]
    ctrl = df[df[treatment_var] == control_val]

    rows = []
    for cov in covariates:
        t_vals = treat[cov].dropna()
        c_vals = ctrl[cov].dropna()

        t_mean, t_sd = t_vals.mean(), t_vals.std()
        c_mean, c_sd = c_vals.mean(), c_vals.std()
        diff = t_mean - c_mean

        # Normalized difference (Imbens & Rubin 2015)
        pooled_sd = np.sqrt((t_sd**2 + c_sd**2) / 2)
        norm_diff = diff / pooled_sd if pooled_sd > 0 else 0.0

        # Two-sample t-test (Welch's, unequal variance)
        t_stat, p_val = stats.ttest_ind(t_vals, c_vals, equal_var=False)

        rows.append({
            'Variable': cov,
            'Control Mean': f'{c_mean:.3f}',
            'Control SD': f'{c_sd:.3f}',
            'Treatment Mean': f'{t_mean:.3f}',
            'Treatment SD': f'{t_sd:.3f}',
            'Difference': f'{diff:.3f}',
            'Norm. Diff': f'{norm_diff:.3f}',
            'p-value': f'{p_val:.3f}',
        })

    return pd.DataFrame(rows)
```

---

## 3. Joint F-Test

Tests whether treatment assignment is jointly predicted by all covariates.
A significant F-test suggests imbalance.

```python
def joint_f_test(df, treatment_var, covariates):
    """Regress treatment on all covariates, report F-statistic and p-value."""
    import statsmodels.api as sm

    clean = df[[treatment_var] + covariates].dropna()
    y = clean[treatment_var].astype(float)
    X = sm.add_constant(clean[covariates].astype(float))
    result = sm.OLS(y, X).fit()

    return {
        'f_stat': result.fvalue,
        'f_pval': result.f_pvalue,
        'n': int(result.nobs),
    }
```

Rule of thumb: p > 0.10 means no detectable imbalance. Report the F-statistic
and p-value at the bottom of the balance table.

---

## 4. Multi-Arm Balance (Ramadan pattern)

For multi-arm RCTs with >2 groups, use ANOVA F-test across all arms.

```python
def multi_arm_balance(df, group_var, covariates, group_labels=None):
    """Balance across multiple treatment arms using ANOVA."""
    groups = sorted(df[group_var].dropna().unique())
    if group_labels is None:
        group_labels = {g: f'Group {g}' for g in groups}

    rows = []
    for cov in covariates:
        group_data = [df.loc[df[group_var] == g, cov].dropna() for g in groups]
        means = [d.mean() for d in group_data]
        sds = [d.std() for d in group_data]

        # One-way ANOVA
        f_stat, p_val = stats.f_oneway(*group_data)

        row = {'Variable': cov}
        for i, g in enumerate(groups):
            row[f'{group_labels[g]} Mean'] = f'{means[i]:.3f}'
            row[f'{group_labels[g]} SD'] = f'{sds[i]:.3f}'
        row['F-stat'] = f'{f_stat:.3f}'
        row['p-value'] = f'{p_val:.3f}'
        rows.append(row)

    return pd.DataFrame(rows)

# Ramadan usage:
covariates = ['mock_score', 'male', 'parent_educ', 'computer',
              'internet', 'boarding', 'risk', 'stake', 'religious2']
balance = multi_arm_balance(df, 'group', covariates,
                            group_labels={1:'T1', 2:'T2', 3:'Control', 4:'T4'})
```

---

## 5. Normalized Difference Thresholds

| |Norm. Diff| | Interpretation |
|---|---|
| < 0.10 | Well balanced |
| 0.10 - 0.25 | Modest imbalance, consider controlling |
| > 0.25 | Substantial imbalance, requires discussion |

Reference: Imbens & Rubin (2015) recommend |norm diff| < 0.25 as a practical
threshold. Unlike p-values, normalized differences are not affected by sample size.

---

## 6. LaTeX Output

```python
def balance_to_latex(balance_df, title='Balance Table', label='tab:balance'):
    """Convert balance DataFrame to LaTeX."""
    n_cols = len(balance_df.columns)
    lines = [
        r'\begin{table}[H]',
        r'\centering',
        f'\\caption{{{title}}}',
        r'\begin{tabular}{l' + 'c' * (n_cols - 1) + '}',
        r'\hline\hline',
        ' & '.join(balance_df.columns) + r' \\',
        r'\hline',
    ]
    for _, row in balance_df.iterrows():
        lines.append(' & '.join(str(v) for v in row.values) + r' \\')
    lines += [
        r'\hline\hline',
        r'\end{tabular}',
        f'\\label{{{label}}}',
        r'\end{table}',
    ]
    return '\n'.join(lines)
```
