# Specification Building Strategy

Reference for progressive specification construction in empirical papers.
Extracted from: Ramadan RCT (reghdfe), JEBO Education (RDD), Data Experiment (Tobit/OLS).

---

## 1. The Specification Ladder

Standard 4-column progression. Each column adds complexity while the reader
tracks stability of the treatment coefficient.

```
Column 1: Y ~ Treatment                            (baseline, no controls)
Column 2: Y ~ Treatment + absorbed(FE)             (entity/demographic FE)
Column 3: Y ~ Treatment + Moderator + Interaction   (heterogeneous effects)
Column 4: Y ~ Treatment + Moderator + Interaction + absorbed(FE)  (full model)
```

### Ramadan Example (actual columns)

```python
# Column 1: OLS baseline
# reg gap T4 if group>2
sm.OLS(y, sm.add_constant(X[['T4']])).fit()

# Column 2: reghdfe with absorbed controls
# reghdfe gap T4 if group>2, absorb(i.class male i.parent_educ ...)
reghdfe_ols(sub, 'gap', ['T4'],
    fe_vars=['class','male','pe','computer','internet','boarding',
             'risk','stake','religious2'])

# Column 3: OLS with interaction
# reg gap T4 religious2 T4_fast if group>2, robust
sm.OLS(y, sm.add_constant(X[['T4','religious2','T4_fast']])).fit(cov_type='HC1')

# Column 4: reghdfe with interaction
# reghdfe gap T4 religious2 T4_fast if group>2, absorb(...)
reghdfe_ols(sub, 'gap', ['T4','religious2','T4_fast'],
    fe_vars=['class','male','pe','computer','internet','boarding',
             'risk','stake'])
# Note: religious2 moves from absorbed to explicit when it interacts with T4
```

Key observation: Column 2 absorbs `religious2` as FE, but Column 4 moves it
to the explicit regressors because `T4_fast = T4 * religious2` requires
the main effect to be explicit.

---

## 2. When to Use Each Column Configuration

| Column | Purpose | Use When |
|--------|---------|----------|
| 1 | Raw treatment effect | Always. Establishes baseline magnitude |
| 2 | Treatment + FE | Multiple FE groups exist (class, site, time) |
| 3 | Interactions (no FE) | Testing heterogeneity, need to show moderator main effect |
| 4 | Interactions + FE | Full model, preferred specification |

Rule: If the treatment coefficient changes substantially from Col 1 to Col 2,
discuss why (omitted variable bias direction). If it stays stable, emphasize
robustness.

---

## 3. Treatment Interactions

### Creating Interaction Terms

```python
# Ramadan pattern: T4 (exemption) x religious2 (fasting status)
df['T4_fast'] = df['T4'] * df['religious2']
```

When adding interactions:
1. Always include both main effects (T4, religious2) as explicit regressors
2. If a main effect was previously absorbed as FE, move it to explicit regressors
3. Report the interaction coefficient as the differential treatment effect
4. Compute total effect for the interacted group: beta_T4 + beta_interaction

### Interpretation Template

```
Total effect for fasting students:  beta_T4 + beta_T4_fast
Total effect for non-fasting:       beta_T4
Differential effect of fasting:     beta_T4_fast (test H0: = 0)
```

---

## 4. Subgroup / Sample Restriction Patterns

### Filter-Based Subgroups (Ramadan)

```python
# Sample restriction: group > 2 (drop groups 1 and 2)
sample = df[df['group'] > 2].copy()
```

Always document:
- Why the restriction (e.g., "Groups 1-2 received different treatments")
- How many observations dropped
- Whether main results are robust to including excluded groups

### Stratified Subgroups (JEBO)

```python
# Exposure heterogeneity: freshman vs post-freshman
# Specification: Y = kappa + beta1*econ*freshman + beta2*econ*post_freshman + theta*X + eps
df['econ_freshman'] = df['econ'] * df['freshman']
df['econ_post_freshman'] = df['econ'] * (1 - df['freshman'])
```

Pattern: Interact treatment with subgroup dummies. This is preferred over
running separate regressions because it (a) uses full sample for SE estimation,
(b) enables direct testing of beta1 == beta2.

---

## 5. Variable Labeling Conventions

Map internal variable names to publication-ready labels for tables.

```python
LABELS = {
    'T4': 'Exemption',
    'religious2': 'Fast',
    'T4_fast': r'Exemption $\times$ Fast',
    'const': 'Constant',
}

# For multi-arm RCTs:
LABELS_MULTIARM = {
    'T1': 'Treatment 1 (Information)',
    'T2': 'Treatment 2 (Incentive)',
    'T3': 'Treatment 3 (Combined)',
    'T4': 'Treatment 4 (Exemption)',
}
```

Rules:
- Use descriptive names, not variable codes, in final tables
- Interactions use $\times$ in LaTeX
- FE indicators: "Yes" / "No" (never "X" or checkmarks)
- Dependent variable label goes in the column header, not repeated per row

---

## 6. JEBO Cross-Sectional Specification

For natural experiments without panel structure:

```
y_i = alpha + gamma * treatment_i + sum(mu_k * preference_FE_k) + epsilon_i
```

```python
# JEBO: econ education treatment with major-preference FE
# Each column is a different outcome variable (not a different spec)
outcomes = ['mpl1_neutral', 'mpl1_loving', 'mpl1_averse',
            'mpl2_neutral', 'mpl2_loving', 'mpl2_averse']

for outcome in outcomes:
    y = df[outcome]
    X = df[['econ'] + [f'pref_{k}_econ' for k in range(2, 7)]]
    result = sm.OLS(y, sm.add_constant(X), missing='drop').fit(cov_type='HC1')
```

In this pattern, the "specification ladder" runs across outcome variables
rather than across control configurations. Each column = different dependent
variable, same specification.

---

## 7. Decision Checklist

Before finalizing the specification table:

- [ ] Column 1 has NO controls (establishes raw effect)
- [ ] Each subsequent column adds exactly one type of complexity
- [ ] Treatment coefficient is visible in every column
- [ ] Interaction main effects are explicit when interaction is included
- [ ] Sample size changes between columns are explained (singleton removal, missing controls)
- [ ] Control mean / SD reported for magnitude interpretation
- [ ] FE indicator rows match what is actually absorbed
- [ ] R-squared progression makes sense (should increase or stay flat, never decrease substantially)
