# Production Pipeline Patterns

Hard-won ordering and logic bugs from RAD gazetteer pipeline (RAD-20260211-0001).
Apply to any multi-filter page-triage + VLM extraction architecture.

---

## Keyword Filter Ordering (CRITICAL -- do not reorder)

```
_text_skip_reason(text):
  1. negative_chapter  -- first 80 chars: 工业/林业/渔业/水产 chapter headings (HIGHEST priority)
  2. negative_table    -- table title match: 征购/供应/良种/比重
  3. positive_crop     -- early-return if crop keyword found
```

Running `positive_crop` before `negative_chapter` causes industrial/fishery pages
to pass the crop check ("粮食征购统计表" contains "粮食"). Result: floods the VLM
with procurement tables. Always apply negative filters before positive.

## Garbled Text Layer Detection

PDFs can have visually correct crop tables but a corrupted embedded text layer
(scanning artifact or baked-in OCR). The keyword filter sees garbage → 0 candidates.

**Detection**: after full extraction run, `book_type='county' AND obs=0` = candidate.
Manually inspect one page image to confirm table exists.

**Fix**: force-insert production-table pages as candidates directly in DB, then re-run:
```sql
INSERT OR IGNORE INTO page (book_id, page_num, status) VALUES (?, ?, 'candidates_found');
```

## Multi-Page Table Merging

When a logical table is split across pages (area p1 / yield p2 / total p3), each page
extracts partial rows. Post-hoc merge required:

```python
# Find (book_id, year, crop_id) groups with exactly 1 area-only + 1 yield-only + 1 total-only
# Only merge when arithmetic check passes (<5%). Skip if unit_factor mismatch (e.g. 10x).
SELECT year, crop_id,
       SUM(area IS NOT NULL AND yield IS NULL) as area_only,
       SUM(yield IS NOT NULL AND area IS NULL) as yield_only,
       SUM(total IS NOT NULL AND area IS NULL AND yield IS NULL) as total_only
FROM observation WHERE book_id = ?
GROUP BY year, crop_id
HAVING area_only=1 AND yield_only=1 AND total_only=1;
```

## Post-QA False Observation Deletion

After client review or visual audit identifies false observations (procurement tables,
proportion tables, regional aggregates extracted as county data):

```sql
DELETE FROM observation WHERE extraction_id IN (
  SELECT e.id FROM extraction e WHERE e.page_id IN (101, 207, 354)
);
UPDATE page SET status='no_table' WHERE id IN (101, 207, 354);
UPDATE extraction SET is_active=0 WHERE page_id IN (101, 207, 354);
```

Re-run `grade` and `export` after deletion. Row count will decrease; this is expected.

## Book Status Stuck at candidates_found

After full run, books with all pages in terminal state (no_table/text_filtered/no_ag)
can get stuck at `candidates_found`. Add end-of-run sweep:

```sql
UPDATE book SET status='graded'
WHERE status='candidates_found'
  AND NOT EXISTS (
    SELECT 1 FROM page WHERE book_id=book.id
    AND status IN ('pending','layout_ok','candidates_found')
  );
```

## BOM Encoding in CSV (macOS pandas)

`pandas.read_csv()` on macOS may write BOM (U+FEFF) into CSV output. When you later
read crosswalk or reference CSVs back, always use `encoding='utf-8-sig'` to strip BOM
silently. Using `'utf-8'` leaves a BOM prefix on the first column name.

```python
df = pd.read_csv("crosswalk.csv", encoding='utf-8-sig')   # CORRECT
df = pd.read_csv("crosswalk.csv", encoding='utf-8')        # WRONG -- first col may be '\ufeffgeo_code'
```

To write without BOM: `df.to_csv(path, encoding='utf-8', index=False)`.

---

## SQLite Pipeline Patterns (Dropbox 兼容)

### 必须用 DELETE journal mode（非 WAL）

```python
conn = sqlite3.connect("data/gazetteer.db")
conn.execute("PRAGMA journal_mode=DELETE")  # WAL 在 Dropbox FS 上不兼容
```

### Status FSM

```
pending → (text filter) → no_table [text_filtered=1，原子更新]
        → (layout detect) → no_table | layout_ok
        → (LLM extract) → extracted | no_table | error | retry
retry = 有 observations 但最新 LLM 返回空（保护现有数据，不降级）
```

**关键规则：**
- `is_active=1` 每 page_id 只能有一条——插入新记录前必须先 `UPDATE extraction SET is_active=0 WHERE page_id=?`
- `status='no_table'` 与 `text_filtered=1` 必须同一 SQL 原子更新
- 有 observations 的页面不能降级到 `no_table`，必须设 `retry`

### Filter Chain 顺序（不可更改）

```python
# _text_skip_reason() 内部执行顺序——调换会导致工业/渔业页面漏入 LLM（Bug 1+9 根因）
# 1. negative_chapter（最高优先级，前 80 字符）
# 2. negative_table（表标题匹配）
# 3. positive_crop（最后检查，找到才早返回）
```

### 扫尾 sweep（每次 extract 结束后）

```python
conn.execute("""
    UPDATE book SET status='extracted'
    WHERE status='candidates_found'
      AND id NOT IN (
        SELECT DISTINCT book_id FROM page
        WHERE status IN ('pending','layout_ok') AND text_filtered=0
      )
""")
```

### 模型名记录（不能硬编码）

```python
# ❌ 错误：hardcode 'claude-sonnet-4-6'
# ✅ 正确：
def _record_model(result, extractor):
    return result.get("model") or extractor.model
```

### OpenRouter 模型名

`qwen/qwen3-vl-235b-a22b-thinking` — **不加 `:free` 后缀**（加了返回 HTTP 404）

---

## Phase 2 Deployment Checklist (3,000-book scale)

每个新省份批次部署前核查，全部通过才能导出交付文件：

### 状态机（6 项）
- [ ] Text filter 顺序：`negative_chapter` 最先执行
- [ ] `is_active` 去激活：每次插入前先 UPDATE is_active=0
- [ ] no_table 保护：有 observations 的页面 → `retry`，不降级
- [ ] Book filter 包含 `'extracted'/'graded'` 状态
- [ ] `layout_ok` 页面包含在 pass 3 筛选中
- [ ] End-of-run sweep：`candidates_found` 无剩余页面时提升状态

### 数据质量（4 项）
- [ ] 模型名：`qwen/qwen3-vl-235b-a22b-thinking`（无 `:free` 后缀）
- [ ] extraction 记录中 model_name 字段正确（非硬编码）
- [ ] 千位分隔符修复（`_repair_row_thousands()`）已启用
- [ ] Timeout 检测用 `LOWER(raw_output) LIKE '%timeout%'`

### 交叉验证（2 项）
- [ ] 已下载该省 SciDB / 省级年鉴参照数据
- [ ] 跑完 cross-val，near_half_rate > 0.60 的县已修复并重新 grade
