# Semantic Parsing & Value Cleaning

## Semantic Parsing Patterns

When raw data comes from OCR-scanned documents where:
- Column headers encode structured info (year, metric type, units, annotations)
- Column structures vary across files
- Same column position means different things in different files

### Two-Pass Pipeline

#### Pass 1: Position-Based Extraction (V1 deliverable)
- Identify the "key" column by position or content matching
- Extract all remaining columns as generic `col_1`, `col_2`, ..., `col_N`
- Clean values uniformly (see Value Cleaning below)
- Create a column mapping CSV: `(file_id, col_index, original_name)`

#### Pass 2: Semantic Parsing (V2 deliverable)
Parse `original_name` from the column mapping to extract structured metadata.

1. **Normalize**: join multiline headers, full-width to half-width digits, strip annotations
2. **Extract Structured Fields**: era year to Western year conversion, regex extraction
3. **Classify Content**: ordered keyword matching (most specific first)
4. **OCR Error Correction**: hard-coded table for known misreads
5. **Pivot to Wide Format**: long to wide with `aggfunc="mean"` for duplicate handling

---

## Value Cleaning (Universal for OCR data)

Apply in this order:
1. **Dash variants** -> NaN: `-`, fullwidth dash, katakana dash, `--`, em dash, etc.
2. **Triangle negative**: triangle + number -> negative number
3. **Parenthesized values**: `(triangle32)` -> `-32`
4. **Strip non-numeric**: commas, `%`, unit annotations
5. **Plus prefix**: strip leading plus signs
6. **Cast to float**: `float(s)`, fallback to NaN
