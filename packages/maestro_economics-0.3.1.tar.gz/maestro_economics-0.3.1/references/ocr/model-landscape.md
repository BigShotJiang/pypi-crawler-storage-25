# OCR Model Landscape (2025-2026 Update)

## OmniDocBench Table Recognition Rankings (CVPR 2025)

| Rank | Model | Params | Table TEDS | Type |
|------|-------|--------|-----------|------|
| 1 | PaddleOCR-VL | 0.9B | 94.76 | Specialized VLM |
| 2 | MinerU 2.5 | 1.2B | 92.38 | Specialized VLM |
| 3 | MonkeyOCR-pro-3B | 3B | 90.63 | Specialized VLM |
| 4 | Qwen3-VL-235B | 235B (MoE) | 90.55 | General VLM |
| 5 | Gemini 2.5 Pro | Closed | 90.29 | General VLM (Closed) |

## Recommended Models for 4090 Ti (16GB VRAM)

| Model | Params | VRAM | Table Accuracy | Chinese | Speed |
|-------|--------|------|---------------|---------|-------|
| PaddleOCR-VL 0.9B | 0.9B | ~2-4GB | Best (94.76) | 109 languages | Very fast |
| MinerU 2.5 | 1.2B | ~4-6GB | Very high (92.38) | Good | Fast |
| Qwen3-VL-8B | 8B | ~10-16GB | High | Native-level, 39 lang OCR | Medium |
| Qwen3-VL-30B-A3B (MoE) | 30B (3B active) | ~8-10GB | Very high | Native-level | Fast (sparse MoE) |
| DeepSeek-OCR 3B | 3B | ~6-8GB | 75.7 | Good | 4.65 pages/sec |

## Cheapest Closed-Source APIs

| API | Table Accuracy | Cost/Page | 53k Pages Total |
|-----|---------------|-----------|-----------------|
| Gemini 2.5 Flash Lite | Good | ~$0.001 | ~SGD 75 |
| Gemini 2.5 Flash | Very good | ~$0.003 | ~SGD 220 |
| Baidu Table OCR V2 | Good | ~$0.09 | ~SGD 900 |
| Claude Sonnet | Best tier | ~$0.01-0.03 | SGD 700-2,200 |

## Key Findings

1. **PaddleOCR-VL 0.9B is NOT the old PP-Structure** -- it's a new VLM architecture, table TEDS 94.76, beats all large models
2. **Gemini Flash Lite is absurdly cheap** -- SGD 75 for 53k pages, good for quick indexing
3. **Qwen3-VL released Oct 2025** -- 8B version runs on 4090 with INT4 quantization, expanded OCR to 39 languages
4. **PP-StructureV3 exists** -- significant upgrade from V2, uses OmniDocBench for evaluation
5. **Old PP-OCRv5 + PP-StructureV2 results (76.8% arithmetic pass) were from CPU + 100 DPI + buggy sklearn** -- not representative of current PaddleOCR capabilities

## LAN GPU Architecture

Deploy inference server on Windows 4090, call from Mac over HTTP:
- **Ollama**: `ollama run qwen3-vl:8b` -- easiest, OpenAI-compatible API
- **vLLM**: Higher throughput, supports PaddleOCR-VL and Qwen3-VL
- **FastAPI wrapper**: Custom server for PaddleOCR-VL
- Mac script calls `http://WINDOWS_IP:PORT/v1/chat/completions`
