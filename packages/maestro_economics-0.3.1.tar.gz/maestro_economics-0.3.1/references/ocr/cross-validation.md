# Cross-Validation: Multi-Path, Arithmetic, Unit Errors, External SOP

## Multi-Path Cross-Validation (Mandatory for Table Digitization)

```python
def validate_cell(ocr_value, model_value, llm_value=None):
    if ocr_value == model_value:
        return ocr_value, "confirmed"
    if llm_value:
        from collections import Counter
        votes = [ocr_value, model_value, llm_value]
        most_common = Counter(votes).most_common(1)[0]
        if most_common[1] >= 2:
            return most_common[0], "majority"
    return ocr_value, "conflict"  # flag for manual review
```

Sources: PP-OCRv5 (primary), embedded OCR text layer (cross-check),
Claude/GPT-4o Vision (tiebreaker only, never primary).

---

## Arithmetic Cross-Check

- Agricultural: `area * yield_per_mu / 10000 ~ total_output`
- Financial: row totals = sum of components
- Target: <5% manual review rate

---

## Unit Factor Error Taxonomy

### 为什么这是系统性风险

Arithmetic cross-check（area × yield ≈ total）是**内部检验**——若 area、yield、total 三列同时用了错误单位，内部检验仍通过。只有外部参照（SciDB 省级年鉴、USDA 等）才能发现系统性 2× 误差。

### 已知错误类型

| 志书单位 | Pipeline 假设 | 误差倍数 | 特征 | 修正方法 |
|---------|-------------|---------|------|---------|
| 千公斤 (1,000 kg) | 千斤 (500 kg) | 2× 低估 | 所有年份 ratio ≈ 0.5 | unit_factor × 2 |
| 万公斤 (10,000 kg) | 万斤 (5,000 kg) | 2× 低估 | 同上 | unit_factor × 2 |
| brigade 级（unit=1） | 县级 | 比例 0.003–0.02 | 极端低估 | flag=1 |
| 地区合计误提 | 县级 | 比例 10–20× | 极端高估 | flag=1 |

**Pipeline 公式：** `production_ton = total × unit_factor × 0.5 / 1000`
- unit_factor=1000，千斤表 → 500 ton ✓
- unit_factor=1000，千公斤表 → 500 ton，实际应为 1000 ton → 2× 低估
- 修正：对千公斤表设 unit_factor=2000

### 检测方法

```python
ratio = ocr_production_ton / reference_production_ton
near_half_rate = ((ratio > 0.45) & (ratio < 0.55)).mean()

# 诊断阈值（多种作物均如此）
# near_half_rate > 0.60 → 系统性单位错误 → unit_factor × 2
# ratio < 0.05 持续    → sub-county scope（大队/brigade 级）→ flag=1
# ratio > 5.0 持续     → 地区合计误提 → flag=1
```

### 修复 SOP（幂等 MARKER 模式）

```python
MARKER = "unit_fix_YYYY-MM-DD"  # 唯一标识，防重复执行

conn.execute("""
    UPDATE observation
    SET unit_factor = unit_factor * 2,
        note = COALESCE(note, '') || ' | ' || ?
    WHERE book_id IN (SELECT id FROM book WHERE stem = ?)
      AND note NOT LIKE ?
""", (MARKER, book_stem, f"%{MARKER}%"))

# 修复后必须重新 grade：python -m gazetteer grade --province <省份>
```

---

## External Cross-Validation SOP

每批新省份 OCR 完成后，**交付前必须执行**此流程。

### Step 1: 下载参照数据

优先选 SciDB 省级产量数据（中国科学数据中心，CC BY）。备选：USDA ERS China Agricultural Data（国家/省级，1949–2009）。

### Step 2: 生成交叉验证 CSV

```python
# 查询 OCR 结果（SQLite）
query = """
SELECT b.stem, b.county, c.code AS crop_code, o.year,
       ROUND(o.total * o.unit_factor * 0.5 / 1000, 2) AS ocr_ton,
       o.unit_factor, o.grade
FROM observation o
JOIN book b ON o.book_id = b.id
JOIN crop c ON o.crop_id = c.id
WHERE o.flagged = 0
  AND o.grade IN ('exact','pass','marginal')
  AND o.total IS NOT NULL
"""
# 与参照数据 JOIN：(county ≈ geo_name fuzzy, year, crop_code)
# 输出 crossval_ocr_vs_reference.csv
```

### Step 3: 诊断每县

```python
for county, grp in df.groupby('county'):
    ratio = grp['ocr_ton'] / grp['ref_ton']
    near_half_rate = ((ratio > 0.45) & (ratio < 0.55)).mean()
    if near_half_rate > 0.60:
        print(f"[UNIT ERROR] {county}: near_half={near_half_rate:.2f} → unit_factor × 2")
    elif (ratio < 0.05).mean() > 0.5:
        print(f"[SCOPE] {county}: too small → brigade-level data")
    elif (ratio > 5.0).mean() > 0.5:
        print(f"[SCOPE] {county}: too large → prefecture total extracted")
```

### Step 4: 应用修复 + 重新 grade + 验证 post-fix median ratio ≈ 1.0

见 MARKER 模式（上方）。修复后在 CLAUDE.md 记录：哪些县修复、类型、行数、post-fix median。
