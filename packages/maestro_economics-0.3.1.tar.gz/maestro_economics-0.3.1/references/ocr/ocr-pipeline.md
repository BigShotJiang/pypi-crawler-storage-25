# OCR Pipeline Reference (PaddleOCR)

For large-scale scanned document digitization (e.g., county gazetteers,
historical records), use the PaddleOCR pipeline with multi-path validation.

--------------------------------------------------------------------------------

## Model Selection Tiers

| Tier | Model | Speed (CPU) | Accuracy | Cost |
|------|-------|-------------|----------|------|
| 1 (default) | PP-OCRv5 server | ~4.3s/page | ~94.6% | Free, local |
| 1 (fast)    | PP-OCRv5 mobile | ~1.8s/page | Slightly lower | Free, local |
| 2 (API)     | Baidu PaddleOCR API (VL-1.5) | GPU-backed | Higher | Free (beta) |
| 2 (API)     | DeepInfra VL-0.9B | GPU-backed | Good | Pay-per-token |
| 3 (GPU)     | PaddleOCR-VL-1.5 self-hosted | ~15-30s/page (T4) | 98.2% | GPU required |

**Principle**: Start CPU (Tier 1). Escalate to API (Tier 2) only if accuracy
is insufficient. Self-host GPU (Tier 3) as last resort.

--------------------------------------------------------------------------------

## Multi-Path Cross-Validation (Mandatory for Table Digitization)

```python
def validate_cell(ocr_value, model_value, llm_value=None):
    if ocr_value == model_value:
        return ocr_value, "confirmed"
    if llm_value:
        from collections import Counter
        votes = [ocr_value, model_value, llm_value]
        most_common = Counter(votes).most_common(1)[0]
        if most_common[1] >= 2:
            return most_common[0], "majority"
    return ocr_value, "conflict"  # flag for manual review
```

Sources: PP-OCRv5 (primary), embedded OCR text layer (cross-check),
Claude/GPT-4o Vision (tiebreaker only, never primary).

--------------------------------------------------------------------------------

## Arithmetic Cross-Check

- Agricultural: `area * yield_per_mu / 10000 ~ total_output`
- Financial: row totals = sum of components
- Target: <5% manual review rate

--------------------------------------------------------------------------------

## DPI Reference (A4 Page)

| DPI | Pixels     | PP-OCRv5 CPU | Claude Vision       |
|-----|------------|--------------|---------------------|
| 100 | 698x1019   | ~21s (optimal) | OK                |
| 150 | 1046x1528  | ~40s           | OK (max no-resize)|
| 300 | 2092x3055  | ~180s          | Internal resize, OK|

--------------------------------------------------------------------------------

## PaddleOCR 3.4.x API

```python
from paddleocr import PaddleOCR
ocr = PaddleOCR(ocr_version="PP-OCRv5", device="cpu", lang="ch")
result = ocr.predict(image_path)
# Returns: list of dicts with rec_texts, rec_scores, rec_boxes
# Deprecated: use_angle_cls -> use_textline_orientation
# Deprecated: ocr() -> predict(), use_gpu -> device="cpu"
```

--------------------------------------------------------------------------------

## Key Lessons

- CPU first: PP-OCRv5 handles 750 pages in ~1hr at zero cost
- Baidu official API is free (Beta) -- use before self-hosting GPU
- Claude Vision is NOT ground truth (2-5% digit misread rate)
- VL-1.5 is best for Chinese historical document OCR when accuracy is critical
- Persist all OCR findings immediately to project notes (session context is ephemeral)

--------------------------------------------------------------------------------

## Semantic Parsing Patterns

When raw data comes from OCR-scanned documents where:
- Column headers encode structured info (year, metric type, units, annotations)
- Column structures vary across files (different number of columns, different header text)
- Same column position means different things in different files/months

### Two-Pass Pipeline

#### Pass 1: Position-Based Extraction (V1 deliverable)
- Identify the "key" column (e.g., prefecture, entity name) by position or content matching
- Extract all remaining columns as generic `col_1`, `col_2`, ..., `col_N`
- Clean values uniformly (see Value Cleaning below)
- Create a column mapping CSV: `(file_id, col_index, original_name)`
- This is a safe, fast first deliverable -- ship it, then iterate

#### Pass 2: Semantic Parsing (V2 deliverable)
Parse `original_name` from the column mapping to extract structured metadata.

**Step 1: Normalize**
```python
# Join multiline headers
s = original_name.replace("\n", " ").replace("\r", " ")
# Full-width -> half-width digits
s = "".join(chr(ord(c) - 0xFEE0) if "\uff10" <= c <= "\uff19" else c for c in s)
# Strip circled numbers, ratio notation, trailing embedded values
s = re.sub(r"[circled_numbers]", "", s)
s = re.sub(r"ratio_notation_pattern", "", s)
s = re.sub(r"\s+[\d,.]+%?\s*$", "", s)  # trailing "15.5" from OCR
```

**Step 2: Extract Structured Fields**
Extract via regex BEFORE stripping annotations (annotations contain useful info):

```python
# Japanese era year -> Western year
ERA_YEAR_RE = re.compile(r"(Heisei|Reiwa)\s*(\d+|first)\s*year")
SHORT_YEAR_RE = re.compile(r"(?<!\d)(\d{1,2})\s*year")

def era_to_western(era, n):
    if era == "Heisei": return 1988 + n
    if era == "Reiwa":  return 2018 + n
```

**Step 3: Classify Content**
Use ordered keyword matching (most specific first):

```python
def classify(text):
    # Order matters: check specific patterns before general ones
    if "multiyear" in text and "ratio" in text: return "multiyear_ratio"
    if "multiyear" in text:                     return "multiyear_qty"
    if "contract_ratio" in text:                return "contract_ratio"
    if "collection" in text and "contract" not in text: return "collection_qty"
    if "advance_contract" in text:              return "contract_qty"
    ...
    return "unknown"
```

Key principle: **specificity order** -- "multiyear + ratio" must match before standalone "ratio".

**Step 4: OCR Error Correction**
Hard-coded table for known misreads. Build this incrementally as you encounter errors:

```python
OCR_CORRECTIONS = {
    "misread_text_1": "correct_text_1",
    "misread_text_2": "correct_text_2",
    # Add entries as discovered during spot-checks
}
```

Apply corrections BEFORE classification.

**Step 5: Pivot to Wide Format**
```python
# Long format: year_month, entity, field_1, field_2, metric, value
# Wide format: year_month, entity, field_1, field_2, metric_A, metric_B, metric_C, ...
df_wide = df_long.pivot_table(
    index=["year_month", "entity", "field_1", "field_2"],
    columns="metric",
    values="value",
    aggfunc="mean",  # handles duplicates gracefully
).reset_index()
```

--------------------------------------------------------------------------------

## Value Cleaning (Universal for OCR data)

Apply in this order:
1. **Dash variants** -> NaN: `-`, `－` (fullwidth), `ー` (katakana), `--`, `—`, `‐`, `–`
2. **Triangle negative**: `▲ 8.7` -> `-8.7`, `△ 32` -> `-32`
3. **Parenthesized values**: `(▲32)` -> `-32`, `(+3)` -> `3`
4. **Strip non-numeric**: commas, `%`, `％`, unit annotations
5. **Plus prefix**: `+3.2`, `＋3.2` -> `3.2`
6. **Cast to float**: `float(s)`, fallback to NaN

--------------------------------------------------------------------------------

## Quality Metrics

Track and report:
- **Classification rate**: % of values with non-"unknown" metric. Target: >95%
- **Field extraction rate**: % of values with extracted structured fields (e.g., crop_year != "unknown")
- **Metric distribution**: value_counts() of metric column -- check for suspicious imbalances

--------------------------------------------------------------------------------

## Common Pitfalls

1. **Stripping too early**: Don't remove date annotations before extracting year info from them
2. **Regex greediness**: Short year patterns (`\d+年`) can match inside longer patterns (`平成\d+年`). Use non-greedy or check for era prefix first.
3. **Full-width characters**: OCR may produce full-width digits, parentheses, or dashes. Always normalize before processing.
4. **Multiline headers**: Excel cells can contain newlines. Always join with space before parsing.
5. **Format structural breaks**: Government agencies change report format periodically. Expect different column counts, different metrics, different naming conventions across time periods. This is normal, not an error.
6. **Duplicate pivots**: When the same (index, metric) combination appears twice (e.g., from OCR errors), `aggfunc="mean"` avoids crashes. Log these cases for manual review.
