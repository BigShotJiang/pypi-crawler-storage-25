
# Maestro Urban Accessibility — Transport Accessibility Index SOP

## When to Use

- Computing transit accessibility indices (gravity, cumulative opportunities, isochrone)
- Building travel time matrices from GTFS + OSM
- Road network centrality analysis (betweenness, closeness)
- HSR instrumental variable construction
- Transit shock event studies (new station DID)

## When NOT to Use

- Driving-only travel time → use OSRM directly
- Housing price analysis → `maestro-urban-hedonic` (calls this skill for spatial vars)
- General spatial data processing → `maestro-data-spatial`

## Skill Connections

```
maestro-fetch → GTFS/OSM data download
maestro-urban-accessibility → accessibility computation (THIS SKILL)
maestro-data-spatial → spatial aggregation to admin units
maestro-analysis → regression / event study
```

## CLI Script

```bash
python scripts/gtfs_accessibility_index.py \
    --gtfs singapore_gtfs.zip --osm singapore.osm.pbf \
    --districts districts.shp --opportunities jobs.csv \
    --output ./output/
```

Key modes: full pipeline | `--mode isochrones-only` | `--self-potential` | `--validate-only`

## Core Workflow

1. **Acquire GTFS + OSM PBF** data for target city
2. **Validate GTFS** (required files, date coverage, route types)
3. **Build transport network** via r5py (OSM + GTFS)
4. **Compute travel time matrix** (origins × destinations, peak hour)
5. **Calculate accessibility indices** (gravity + cumulative opportunities)
6. **Aggregate to admin units** (spatial join + district means)
7. **Optional**: network centrality, HSR IV, event study

→ See [references/gtfs.md](references/gtfs.md) for GTFS data sources, validation, and route_type codes.
→ See [references/isochrone.md](references/isochrone.md) for r5py travel time matrix and isochrone computation.
→ See [references/gravity-model.md](references/gravity-model.md) for gravity and cumulative opportunity formulas.
→ See [references/network-centrality.md](references/network-centrality.md) for osmnx centrality computation.
→ See [references/hsr-iv.md](references/hsr-iv.md) for HSR instrumental variable construction.
→ See [references/event-study.md](references/event-study.md) for transit shock DID and parallel trends.

## Key Rules

1. **GTFS is date-specific** — select representative workday (Tue-Thu), avoid holidays
2. **r5py needs Java 17+** — use Docker or Conda to manage Java version
3. **Peak hour window**: departure 8:00, window 60 min, take median travel time
4. **Beta calibration matters**: gravity model β ∈ [0.05, 0.15]; use half-life method or behavioral data
5. **Batch large TTMs**: >5k origins → split into 500-origin batches to avoid memory issues

## Output Files

| File | Description |
|------|-------------|
| `district_accessibility.csv` | District-level indices (cumulative + gravity) |
| `cumulative_opportunities.csv` | Origin-level: opp_30min, opp_45min, opp_60min |
| `gravity_index.csv` | Origin-level gravity accessibility |
| `station_isochrones.geojson` | Station service area polygons |
| `travel_time_matrix.parquet` | Full TTM (with `--save-ttm`) |
| `summary.json` | Run summary statistics |

## GTFS Data Sources

| Region | Source | Notes |
|--------|--------|-------|
| Global | Mobility Database | 1400+ cities |
| Singapore | LTA DataMall | Needs API key |
| Japan | 国土数値情報 | GTFS-JP format |
| China | Limited | Shenzhen public; others need API/scraping |
| USA | transitfeeds.com → Mobility Database | |
| UK | Bus Open Data Service | |

## Gotchas

| Problem | Cause | Fix |
|---------|-------|-----|
| Low accessibility on weekend | GTFS weekend service reduced | Check `calendar.txt`; use workday |
| r5py UnsupportedClassVersionError | Wrong Java version | Install Java 17+ |
| China no GTFS | No official open GTFS | Baidu/Amap direction API as fallback |
| OSM coverage gaps | Rural China, developing countries | Visual check with `ox.plot_graph()` |
| TTM memory explosion | 10k × 10k = 100M rows | Batch origins; use `max_time` filter |
| HSR station in suburbs | Station ≠ city center access | Use continuous distance, not 0/1 dummy |
| `osmnx` timeout | Nominatim geocoding flaky | Use `graph_from_bbox()` instead |
| `betweenness_centrality` slow | O(VE) exact algorithm | Use `k=500` approximation |

## Tested City Presets

| City | OSM source | GTFS notes |
|------|-----------|------------|
| Singapore | Geofabrik malaysia-singapore-brunei | LTA DataMall (API key) |
| Tokyo | Geofabrik kanto | MLIT GTFS-JP |
| London | Geofabrik greater-london | TfL Open Data |
| Beijing | Geofabrik china | No official GTFS; use Baidu API |

## Dependencies

```
r5py>=0.2.0, osmnx>=2.0.0, networkx>=3.0
geopandas>=1.1.0, shapely>=2.0.0, pandas>=2.0.0
numpy>=1.24.0, haversine>=2.8.0, matplotlib>=3.7.0
```

**Java 17+ required** for r5py. Recommended: `conda create -n accessibility python=3.11 openjdk=17`
