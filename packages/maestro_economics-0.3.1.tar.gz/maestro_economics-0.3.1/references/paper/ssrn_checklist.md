# SSRN Submission Checklist

Checklist for uploading a working paper to SSRN and for subsequent journal
submission (QJE, JPE, AEJ:Applied, AER).

--------------------------------------------------------------------------------

## 1. Pre-Submission Paper Audit

Run all three audit tools before uploading anything:

```bash
# Step 1: Structural audit
python ~/.claude/skills/maestro-paper/scripts/paper_audit.py \
    06-paper/paper.tex --bib 06-paper/references.bib \
    --output 06-paper/audit_report.txt
cat 06-paper/audit_report.txt
# Must have 0 FAIL items before proceeding.

# Step 2: Section word count check
python ~/.claude/skills/maestro-paper/scripts/wordcount.py \
    06-paper/paper.tex --target qje

# Step 3: Table formatting check
python ~/.claude/skills/maestro-paper/scripts/table_check.py \
    05-analysis/results/tables/
# Must have 0 FAIL items before proceeding.

# Step 4: Full compilation (must be clean)
cd 06-paper/
pdflatex paper.tex && bibtex paper && pdflatex paper.tex && pdflatex paper.tex
grep "Overfull" paper.log  # fix any > 5pt
grep "undefined" paper.log  # must be zero
```

--------------------------------------------------------------------------------

## 2. SSRN Upload Checklist

### Required Fields on SSRN Upload Form

- [ ] **Title**: Exactly as in the paper. Active, specific, evocative.
  Avoid: "An Empirical Analysis of X." Use: "Wet Signals: Rainfall Shocks
  and Housing Prices in Singapore."
- [ ] **Abstract**: Copy-paste from paper. Under 250 words for SSRN.
- [ ] **JEL Codes**: 3-4 codes. Use SSRN's dropdown picker.
- [ ] **Keywords**: 5-7 terms, comma-separated. Match paper.
- [ ] **Author(s)**: All authors in order. Affiliations and contact email for
  corresponding author.
- [ ] **Date**: Month and year of this version.
- [ ] **Paper Series / Topic**: Select relevant SSRN network (e.g., Economics,
  Finance, Urban Economics).

### Paper PDF Requirements

- [ ] PDF is compiled (pdflatex + bibtex, all passes complete)
- [ ] Zero undefined references ("??" not visible in PDF)
- [ ] Page numbers present on all pages
- [ ] Figures and tables render correctly (no missing images)
- [ ] File size under 10MB (compress figures if needed: `gs -dPDFSETTINGS=/ebook`)
- [ ] PDF is named descriptively: `authorYYYY_shortname.pdf`

### Title Page Requirements

- [ ] Paper title
- [ ] Author names and affiliations
- [ ] Corresponding author email
- [ ] "Working Paper" and date (not journal name -- not accepted yet)
- [ ] Acknowledgements (if any): funding sources, seminar participants, RAs
- [ ] Data availability statement (see template below)
- [ ] Abstract with JEL codes and keywords

### Data Availability Statement Template

```latex
\thanks{Data availability: All raw data used in this paper are publicly
available at [URL]. The replication package, including all code and
processed data, is available at [DOI / GitHub URL / upon request].}
```

Or if proprietary data:
```latex
\thanks{Data availability: The [dataset name] used in this paper is
available to researchers upon request from [institution]. All other
data sources are publicly available at [URLs]. Code for the analysis
is available upon request from the corresponding author.}
```

--------------------------------------------------------------------------------

## 3. Journal Submission Checklist

### Before Submitting to Any Journal

- [ ] Read the journal's author guidelines (updated frequently)
- [ ] Confirm the paper is within the page limit
- [ ] Confirm all figures and tables are at the end (AER/QJE/JPE require this
  for initial submission; NOT inline)
- [ ] Confirm abstract is within the journal's word limit
- [ ] Confirm reference format matches journal style (aer.bst vs chicago.bst)
- [ ] Prepare a cover letter (see template below)
- [ ] Prepare a list of 3-5 suggested referees (name, institution, email)
- [ ] Prepare a list of 2-3 opposed referees (if applicable, with brief reason)

### Journal-Specific Requirements

| Journal | Page limit | Abstract | Tables/Figs | Reference style |
|---|---|---|---|---|
| QJE | 45 pp (incl. tables/figs) | < 150 words | End of paper | aer.bst |
| JPE | 50 pp (incl. tables/figs) | < 200 words | End of paper | chicago.bst |
| AEJ:Applied | 40 pp (incl. tables/figs) | < 150 words | End of paper | aer.bst |
| AER | 50 pp (incl. tables/figs) | < 150 words | End of paper | aer.bst |
| REStat | 40 pp | < 250 words | Inline ok | aer.bst |
| JUE | 40 pp | < 200 words | Inline ok | standard |

### Cover Letter Template

```
Dear [Editor Name / Editors],

We submit [paper title] for consideration in [Journal Name].

The paper studies [one sentence: setting + question + identification].
Our main findings are [two quantitative findings].

We believe this paper is well suited for [Journal Name] because
[1-2 sentences on fit: the journal has published related work on X;
the paper's empirical setting is novel and of broad interest].

This paper has not been submitted elsewhere and is not under review
at another journal.

We suggest the following referees:
1. [Name], [Institution] ([email]) -- expertise in [area]
2. [Name], [Institution] ([email]) -- expertise in [area]
3. [Name], [Institution] ([email]) -- expertise in [area]

[Optional: "We request that [Name] not be asked to review due to [conflict]."]

We thank the editors for their consideration.

[Author 1], [Affiliation]
[Author 2], [Affiliation]
[Contact email]
```

### Replication Package Requirements (AEA standard)

For journal submission, prepare a replication package in parallel:

```
replication-package/
  1-paper/
    main.tex             # LaTeX source
    appendix.tex
    references.bib
    tables/              # all .tex table fragments
    figures/             # all .pdf figures
    main.pdf             # compiled
  2-appendix/
    appendix.pdf
  3-replication/
    analysis_code.py     # single script reproducing ALL tables and figures
    data.csv             # main dataset (or instructions to obtain if restricted)
    data.dta             # Stata format (for cross-platform compatibility)
    README.pdf
    README.docx
    requirements.txt     # Python package versions
    additional_files/
      codebook.xlsx
      survey_instrument.pdf  (if applicable)
      IRB_approval.pdf       (if applicable)
```

Key rules (AEA Data and Code Availability Policy):
- `analysis_code.py` (or `.do`) must reproduce ALL tables and figures from scratch
- If restricted data: include instructions for access + code that runs on the data
- README must include: hardware requirements, run time, dependency installation steps
- Data in CSV + Stata .dta format (for cross-platform use)

--------------------------------------------------------------------------------

## 4. Post-Submission Checklist

- [ ] Save confirmation email with submission number
- [ ] Note the editor assigned (visible in editorial system after assignment)
- [ ] Calendar reminder at 3 months to follow up if no decision
- [ ] Do NOT submit elsewhere until you receive a decision or withdraw

### Following Up on a Submission

Email to editorial office (not the editor directly, unless they initiated contact):

```
Subject: [Paper Title] -- Status Inquiry (Manuscript #XXXX)

Dear [Journal] Editorial Office,

I am writing to inquire about the status of our manuscript #XXXX,
titled "[Paper Title]," submitted on [Date].

We are eager to receive the referees' comments and would appreciate
any information you can provide about the expected timeline.

Thank you for your time.

[Author name, affiliation, contact]
```

--------------------------------------------------------------------------------

## 5. Version Control for Working Papers

After each major revision, update the SSRN upload:

```
Filename convention: authorYYYY_shortname_vN.pdf
  v1: initial upload
  v2: after seminar comments / first round of feedback
  v3: after first R&R (if rejected)
  ...
```

Update SSRN date each time you upload a new version. The date shown on
SSRN is the date of the most recent upload -- keep it current to signal
active work.

If the paper is accepted at a journal:
- Update SSRN with "Forthcoming at [Journal Name]" in the title or abstract
- Add DOI when available
- Do NOT remove the paper from SSRN (it is now a permanent working paper record)
