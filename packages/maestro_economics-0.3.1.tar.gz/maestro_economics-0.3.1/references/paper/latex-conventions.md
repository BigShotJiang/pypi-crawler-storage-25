# LaTeX Conventions for Academic Papers

> **NOTE**: Shared conventions (table/figure boilerplate, equation format, banned habits)
> are also available in the `report` skill: `~/.claude/skills/report/references/conventions.md`.
> This file remains the authority for paper-specific conventions (natbib, appendix numbering).

## Citations

```latex
% Textual: "Author (Year) show that..."
\citet{acemoglu2001colonial}

% Parenthetical: "...consistent with colonial origins theory \citep{acemoglu2001colonial}."
\citep{acemoglu2001colonial}

% Multiple: \citep{author2020, author2021}
% Year range: \citealt{author2020} for no parentheses
```

## Table Boilerplate

```latex
\begin{table}[htbp]
\centering
\caption{Effect of Rainfall Deviation on Log Resale Price}
\label{tab:baseline}
\begin{tabular}{lcccc}
\toprule
 & (1) & (2) & (3) & (4) \\
 & OLS & OLS+FE & OLS+FE & OLS+FE \\
\midrule
Rainfall Deviation ($\times 10^{-5}$) & -0.87*** & -1.06*** & -1.04*** & -1.08*** \\
 & (0.22) & (0.23) & (0.24) & (0.23) \\
[6pt]
Controls & No & No & Yes & Yes \\
Town FE & No & Yes & Yes & Yes \\
Year FE & No & Yes & Yes & Yes \\
Month FE & No & No & No & Yes \\
Observations & 685,091 & 685,091 & 685,091 & 685,091 \\
$R^2$ & 0.42 & 0.89 & 0.93 & 0.93 \\
\bottomrule
\end{tabular}
\begin{minipage}{0.95\textwidth}
\small
\textit{Notes:} Dependent variable is log resale price. Controls include floor
area (sqm), storey midpoint, remaining lease (years), and flat-type dummies.
Standard errors in parentheses, clustered at the town level.
*** $p<0.01$, ** $p<0.05$, * $p<0.1$.
\end{minipage}
\end{table}
```

## Figure Boilerplate

```latex
\begin{figure}[htbp]
\centering
\includegraphics[width=0.9\textwidth]{../05-analysis/results/figures/fig2_event_study.pdf}
\caption{Event Study: Dynamic Rainfall-Price Sensitivity}
\label{fig:event_study}
\begin{minipage}{0.9\textwidth}
\small
\textit{Notes:} Coefficients represent the differential rainfall-price
sensitivity for near-flood-zone areas, in six-month bins around the event.
Omitted category: period immediately before the event ($t = -1$). Bars show
95\% confidence intervals, clustered at the town level. Vertical dashed line
marks the event date (July 2010).
\end{minipage}
\end{figure}
```

## Equation Format

```latex
\begin{equation}
\log(\text{price}_{i,t}) = \beta \cdot \text{rainfall\_dev}_{t}
  + \gamma' X_{i} + \alpha_{\text{town}} + \delta_{\text{year}}
  + \lambda_{\text{month}} + \varepsilon_{i,t}
\label{eq:baseline}
\end{equation}
```

After every displayed equation: define all symbols in running prose.

## Appendix Setup

```latex
\clearpage
\singlespacing
\bibliographystyle{aer}
\bibliography{references}

\clearpage
\appendix
\doublespacing
\setcounter{table}{0}
\renewcommand{\thetable}{A\arabic{table}}
\setcounter{figure}{0}
\renewcommand{\thefigure}{A\arabic{figure}}
\input{appendix}
```

## Compilation Sequence

```bash
# Standard 3-pass compilation
pdflatex paper.tex
bibtex paper
pdflatex paper.tex
pdflatex paper.tex

# Check for errors
grep -i "undefined\|error\|warning" paper.log | head -30

# Overfull hbox (fix any > 5pt)
grep "Overfull" paper.log
```

## Banned LaTeX Habits

- `\hline` in tables -- use `\toprule` / `\midrule` / `\bottomrule`
- `\vspace{}` hacks -- fix layout with proper float placement or `\clearpage`
- `\textbf{}` in tables for significance (use stars)
- Hardcoded page breaks before all results are finalized
- `\begin{center}` inside float environment (use `\centering`)
