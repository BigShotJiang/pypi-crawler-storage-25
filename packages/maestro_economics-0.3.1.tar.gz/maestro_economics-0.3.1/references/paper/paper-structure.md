# QJE/JPE Paper Structure — Section-by-Section SOP

Target total length: 45-55 pages (double-spaced, 12pt, 1-inch margins).
Online appendix: 15-25 additional pages.

## Abstract (150-200 words, no citations)

**Structure (one sentence per beat)**:

1. Motivating fact or puzzle that opens the question
2. What this paper does (setting, data, identification strategy -- one sentence)
3. Main finding 1 (quantified: magnitude + significance)
4. Main finding 2 (quantified)
5. Main finding 3 (quantified, or null result with interpretation)
6. Contribution sentence (what literature this advances)

**After abstract**: JEL codes (3-4 codes) and Keywords (5-7 terms).

**Common mistakes**:
- Abstract states method but not results -> always include quantitative results
- Vague contribution ("contributes to the literature") -> name the specific paper(s) extended
- Word count over 200 -> cut to one sentence per beat
- Citations in abstract -> remove, abstracts are citation-free

**Example opening line** (from Singapore HDB paper):
> "Does weather shape housing market outcomes?"
Not: "A large literature documents that weather affects economic decisions."

## Introduction (8-10 pages, ~2,500-3,000 words)

**Mandatory paragraph sequence**:

**Para 1-2: Motivating fact / stylized fact that creates the puzzle**
- Open with one concrete, striking fact (not a broad literature claim)
- Second paragraph: why this setting/market is interesting and understudied
- DO NOT open with "This paper studies..." or "In recent years..."
- DO NOT open with "A large literature documents..."

**Para 3-4: Research question and identification strategy (in plain English)**
- State the research question in one sentence
- Describe the identification strategy in non-technical language
- Explain why the source of variation is plausibly exogenous
- Mention the data source, sample size, and time period

**Para 5-6: Main findings (quantitative, specific)**
- One sub-section per hypothesis / finding
- Each finding: coefficient magnitude + statistical significance + economic magnitude
- Economic magnitude: compare to mean, standard deviation, or published benchmark
- Do not say "significant" without specifying statistically vs economically

**Para 7-8: Contributions to literature (3-4 literatures)**
- "This paper contributes to three literatures."
- For each: "First, we contribute to X by showing Y." Be specific about what Y is.
- Cite 2-3 papers per literature
- Avoid: "related to", "builds on" -- use "extends", "provides first evidence", "reconciles"

**Para 9: Roadmap**
- "The remainder of the paper is organized as follows. Section 2 describes...
  Section 3 presents... Section 4 details... Section 5 reports... Section 6
  discusses robustness. Section 7 concludes."

**Optional: teaser figure or table**
- One key figure or summary table in the introduction dramatically increases impact
- Must be the single most compelling piece of evidence

**Common mistakes**:
- More than 2 paragraphs before stating the research question
- Findings paragraph without quantitative magnitudes
- Literature contributions paragraph that lists papers without saying what this
  paper adds that they did not
- Roadmap is last paragraph but introduction has no clear ending

## Institutional Background (3-5 pages, ~900-1,500 words)

**Purpose**: Give the reader the institutional context they need to understand
the identification strategy. This is NOT a literature review.

**Content**:
- What is the market/institution/program being studied?
- Key rules, incentives, or constraints that create the variation used for ID
- Timeline of relevant events (if DiD or event study)
- Why this setting is an ideal laboratory (bullet points acceptable)
- Maps or figures showing geographic coverage (if spatial study)

**Common mistakes**:
- Describing institutional details that are not used in the analysis
- Mixing literature citations into institutional background
- Missing the "why this is a good laboratory" subsection

## Data (5-8 pages, ~1,500-2,500 words)

**Table 1 rule**: Summary statistics is ALWAYS Table 1 in empirical economics papers.

**Mandatory subsections**:

1. **Primary data source(s)**: Name, custodian, URL or citation, years covered,
   unit of observation, total observations, how obtained
2. **Secondary data source(s)**: Same format
3. **Variable construction**: For each key variable, exact definition with formula
   if non-trivial. Include displayed equation for the main treatment/outcome
4. **Sample restrictions**: What was dropped and why (with Ns before and after)
5. **Panel construction**: How sources were merged (join key, matching rate)
6. **Summary statistics table (Table 1)**: Mean, SD, Min, Median, Max for all
   key variables. Bottom note: N, time period, unit of observation

**Table 1 formatting**:
```latex
\begin{table}[htbp]
\centering
\caption{Summary Statistics}
\label{tab:summary}
\begin{tabular}{lccccc}
\toprule
Variable & Mean & SD & Min & Median & Max \\
\midrule
...
\midrule
\multicolumn{6}{l}{\textit{Notes:} Transaction-level panel: $N = 685{,}091$; 26 towns; 2000--2026.} \\
\bottomrule
\end{tabular}
\end{table}
```

**Common mistakes**:
- Summary statistics table placed after data section (always Table 1, in Data section)
- Variable definitions are vague ("weather controls" instead of "monthly deviation
  from historical calendar-month mean rainfall, mm")
- Sample restrictions described without Ns

## Empirical Strategy (5-8 pages, ~1,500-2,500 words)

**Mandatory content**:

1. **Baseline estimating equation** (displayed, numbered):
   ```latex
   \begin{equation}
   Y_{it} = \beta \cdot X_{t} + \gamma' Z_{i} + \alpha_{\text{town}}
            + \delta_{\text{year}} + \lambda_{\text{month}} + \varepsilon_{it}
   \label{eq:baseline}
   \end{equation}
   ```
   After equation: define EVERY subscript, coefficient, and variable.

2. **Fixed effects justification**: Why each FE absorbs what confound.
   "Town fixed effects absorb all time-invariant local factors including
   proximity to amenities, school quality, and historical flood-risk ratings."

3. **Identification assumption** (in words then math):
   "Our identification assumption is that [treatment] is uncorrelated with
   unobserved determinants of [outcome] conditional on [FE and controls]."

4. **Threats to validity** (one paragraph each, in decreasing severity):
   For each threat: state the threat -> explain why it does not apply or is
   mitigated -> cite evidence. Do NOT just say "we cannot rule out X."

5. **Standard errors**: Specify clustering level and justify.
   "Standard errors are clustered at the [unit] level to account for
   [autocorrelation / heteroskedasticity within cluster]."

6. **Interaction specifications** (if applicable): separate subsection with
   displayed equation for each interaction spec.

**Identification argument template**:
```
Our identification strategy exploits [source of variation]. [Variation] is
plausibly exogenous because [reason 1] and [reason 2]. While [threat], our
[control/FE/design] mitigates this concern because [mechanism].
```

**Common mistakes**:
- Identification assumption stated but threats to validity not addressed
- Fixed effects listed without explaining what they absorb
- SE clustering level not stated

## Results (10-15 pages, ~3,000-4,500 words)

**Ordering rule**: Baseline table first, then heterogeneity, then mechanism tests.

**For each table reported in results**:

1. **Cite table first**: "Table X presents..."
2. **Coefficient walk-through**: report the point estimate, SE, significance
3. **Economic magnitude** (mandatory for every key coefficient):
   - "A one-standard-deviation increase in X reduces Y by Z%, equivalent to
     $W at the median price."
   - "This effect is 0.3 standard deviations below the sample mean."
   - "This is comparable to the effect estimated by [Author Year] for [context]."
4. **R-squared / fit**: mention if noteworthy
5. **Compare across columns**: if table has multiple specs, compare coefficients
   across them with economic interpretation

**Economic magnitude formula**:
```
dollar_effect = beta * (1 SD of X) * median_Y
pct_effect = beta * (1 SD of X)  [if outcome is log]
sd_effect = dollar_effect / SD_of_Y
```

**Null results**:
- Never say "we fail to reject the null" without economic interpretation
- State WHY the null is informative: data limitation vs true zero effect
- Give upper bound on effect size from confidence interval

**Event study subsection**:
- Reference figure directly: "Figure X plots the dynamic treatment effects."
- Discuss pre-trend pattern (are pre-period coefficients near zero?)
- Discuss post-treatment pattern (persistent? immediate? fading?)
- Flag any anomalies in pre-period (noise vs. pre-trend violation)

**Common mistakes**:
- Results section that only says "Table X shows the coefficient is significant"
- No economic magnitude for key coefficients
- Event study figure presented without discussing pre-trends
- Null results dismissed without interpretation

## Robustness Checks (4-6 pages, ~1,200-1,800 words)

**Structure**: One paragraph per check. First sentence = result of the check.

**Mandatory template for each check**:
> "[Check description] [result in first sentence, with coefficient]. [Why this
> check addresses a specific threat]. [Where full results appear]."

**Example**:
> "Excluding crisis years (2008--2009 and 2020--2021) leaves the baseline
> estimate unchanged ($\beta = -1.1 \times 10^{-5}$, $p < 0.001$), ruling out
> the concern that our results are driven by confounded recession-period behavior.
> Appendix Table A2 reports full results."

**Standard robustness menu (10 checks)**:
1. Alternative SE clustering (wider geography, two-way, Conley spatial)
2. Alternative treatment definition (alternative bins, continuous vs. binary)
3. Alternative outcome transformation (levels, IHS, winsorized)
4. Exclude crisis/unusual years
5. Placebo treatment (fake dates, irrelevant group, unrelated outcome)
6. Subsample analysis (geographic, time period, demographic subgroup)
7. Alternative fixed effect structure (more FEs, fewer FEs, interact FEs)
8. IV / 2SLS if OLS is the baseline
9. Alternative control sets (add or drop controls)
10. Long differences (annual or multi-year instead of monthly)

**Which checks to run depends on the design**:
- DiD: mandatory pre-trend test + placebo event + broader/narrower treatment window
- IV: first-stage F-stat + exclusion restriction discussion + Sargan-Hansen J-test
- RDD: bandwidth sensitivity + donut-hole + discontinuity in density (McCrary)

**Common mistakes**:
- Robustness check not connected to the specific threat it addresses
- Robustness section just says "coefficient is robust" without reporting numbers
- Only 2-3 checks (QJE expects 6-10)

## Discussion / Mechanism (3-4 pages, ~900-1,200 words)

**Structure**:

1. **Primary mechanism** (1-2 paragraphs): what economic mechanism explains
   the baseline finding? Cite theory or prior evidence.
2. **Secondary mechanism** (1 paragraph): if multiple channels, distinguish them
   using the heterogeneity results from Section 5
3. **Ruling out alternatives** (1 paragraph): what other mechanisms could explain
   the result, and why the evidence favors your interpretation
4. **Policy implications** (1-2 paragraphs): what do the results imply for
   policy? Be specific. Avoid generic "policymakers should consider..."
5. **Limitations** (1 paragraph): data limitations, identification caveats,
   generalizability concerns. Be honest; reviewers will find them anyway.
6. **Extensions** (optional, 1 paragraph): what would you do with more data?
   This is your ask for future work.

**Common mistakes**:
- Discussion just repeats results section
- Mechanism section not linked to heterogeneity results
- Policy implications are generic ("better information")

## Conclusion (2-3 pages, ~600-900 words)

**Rules**:
- No new results or evidence in the conclusion
- No new citations in the conclusion
- Restate 2-3 main findings in quantitative terms
- Policy implications: 2-3 specific implications
- Limitations: 1 paragraph (can expand from Discussion)
- Future research: 2-3 specific directions

**Common mistakes**:
- Conclusion introduces new arguments or interpretations
- Conclusion is vague ("we hope future research will build on this")
- Conclusion exceeds 4 pages (cut to the 3 essential elements above)

## Appendix

**Mandatory appendix sections**:
1. Data sources table (full list with URLs, years, custodians)
2. Variable definitions (exact formulas for all constructed variables)
3. Full robustness tables (main text cites, appendix reports in full)
4. Additional figures (secondary analysis, supporting charts)
5. Pre-trend discussion (if DiD or event study)

**Optional**:
- Simple model / theory (if paper has theoretical motivation)
- Survey instrument (if survey data)
- Additional institutional details
