# QJE/JPE Writing Style Rules

## Voice and Register

- **Active voice for claims**: "We find that prices fall..." not "It was found
  that prices fall..."
- **We vs. This paper**: QJE prefers "we"; JPE is more permissive. Default to "we."
- **Precise hedging**: "consistent with", "suggests", "implies" -- not "proves"
- **Direct assertions**: avoid "it is worth noting that", "it is important that",
  "interestingly"

## Quantification Rules (non-negotiable)

Every key empirical claim must include ALL of:
1. Point estimate with units
2. Standard error or confidence interval
3. Statistical significance (p-value or stars)
4. Economic magnitude (dollars, SDs, or percent of mean)

Bad: "We find that rainfall significantly reduces housing prices."
Good: "We find that a 100mm positive rainfall deviation reduces resale prices by
0.11% ($\beta = -1.06 \times 10^{-5}$, SE $= 2.29 \times 10^{-6}$, $p < 0.001$),
equivalent to approximately SGD 400 at the median transaction price."

## Literature Citation Discipline

- `\citet{key}` for textual: "As shown by \citet{Bordalo2012}..."
- `\citep{key}` for parenthetical: "...consistent with salience theory \citep{Bordalo2012}."
- Minimum 3-4 literature branches, each with 5-10 papers
- Seminal papers (must-cite) + recent papers (last 5 years) in each branch
- Every claim about prior literature must have a citation

## Table Discipline

Every table must have:
1. `\toprule`, `\midrule`, `\bottomrule` (never `\hline`)
2. Column headers in top row (model numbers (1), (2), (3)... second row: estimator)
3. `[6pt]` spacing after last coefficient row before fit statistics
4. Notes line: `\textit{Notes:}` specifying:
   - What is the dependent variable
   - What fixed effects are included
   - How SEs are clustered
   - Significance star convention: *** $p<0.01$, ** $p<0.05$, * $p<0.1$
5. Every table label cited in text before it appears

## Figure Discipline

Every figure must have:
- Caption that explains what the figure shows (not just a title)
- Notes block below figure (not just in caption)
- Notes must explain: what the axes are, what error bars represent, what the
  vertical dashed line marks, what the omitted category is
- All figures cited in text before they appear: "Figure \ref{fig:event_study}
  plots the dynamic treatment effects."

## Null Results

Null results require extra care. Never write "we fail to reject the null."

Instead:
1. Report the point estimate, CI, and p-value
2. Compute the maximum effect consistent with the CI: "Our estimates rule out
   effects larger than X at the 95% confidence level."
3. Explain WHY the null is informative: data limitation, policy response, or
   genuine zero
4. If data limitation: state exactly what data would be needed to test properly

## 10 Phrases to Use

1. "We find that..." (for main results)
2. "Consistent with [mechanism], we find that..." (for mechanism tests)
3. "The coefficient is $\beta = X$ ($p < 0.001$), implying..." (for results)
4. "This corresponds to approximately..." (for economic magnitude)
5. "These estimates are robust to..." (for robustness intro)
6. "We regard this as [X] rather than [Y]." (for null result interpretation)
7. "Column (N) adds [control/FE]." (for table walk-through)
8. "The effect is [N] times larger for [subgroup]..." (for heterogeneity)
9. "Our identifying assumption is that..." (for strategy section)
10. "We cannot completely rule out [threat], but [mitigation]." (for caveats)

## 10 Phrases Never to Use

1. "This paper studies X." (too weak -- state the finding instead)
2. "In recent years, X has become important." (generic opener)
3. "Many economists have..." (vague and condescending)
4. "Interestingly, we find..." (let the result speak for itself)
5. "It is worth noting that..." (either say it or cut it)
6. "The results are significant." (always specify: statistically or economically)
7. "We fail to reject the null." (say "we find no significant effect of X")
8. "The table below shows..." (always use \ref{})
9. "We improve upon / build upon [paper]." (say what you add specifically)
10. "Future research should explore X." (say what data or setting would work)
