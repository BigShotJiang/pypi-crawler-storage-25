# Section-by-Section Guide: QJE/JPE/AEJ Paper

Word count targets and paragraph-level checklists for each section.
Targets are for the body text only (excludes tables, figures, appendix).

Word count conversions (double-spaced 12pt, 1-inch margins):
- 1 page ~ 250 words (double-spaced)
- 1 page ~ 500 words (single-spaced)
- Standard QJE paper: ~8,000-12,000 words body text = 32-48 pages

--------------------------------------------------------------------------------

## Abstract

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 100 | 150 |
| JPE | 100 | 200 |
| AEJ:Applied | 100 | 150 |
| Working Paper | 150 | 250 |

### Paragraph Checklist

- [ ] Sentence 1: Motivating question or puzzle (concrete, not "Many economists...")
- [ ] Sentence 2: Setting, data, identification strategy (compressed)
- [ ] Sentences 3-5: Main findings with specific magnitudes (at least 2 quantified results)
- [ ] Sentence 6: Contribution sentence (what literature this advances)
- [ ] JEL codes follow abstract (3-4 codes, each with a reason)
- [ ] Keywords: 5-7 terms, comma-separated
- [ ] No citations in abstract
- [ ] Under word limit

### Example JEL codes for applied micro / environmental / urban

| Area | Codes |
|---|---|
| Housing markets | R31 (housing supply/demand), R21 (housing demand) |
| Weather / climate | Q54 (climate), Q51 (natural resources) |
| Behavioral | D91 (intertemporal choice), D83 (search, info) |
| Labor / wages | J31 (wage levels), J22 (labor supply) |
| Health | I10 (health), I12 (health behavior) |
| Finance | G12 (asset pricing), G11 (portfolio choice) |

--------------------------------------------------------------------------------

## Introduction

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 2,000 | 3,000 |
| JPE | 2,000 | 3,000 |
| AEJ:Applied | 1,500 | 2,500 |

### Paragraph-Level Checklist

**Paragraphs 1-2: Hook and setting**
- [ ] Para 1 opens with a specific, striking fact (NOT "This paper studies" or "In recent years")
- [ ] Para 2 explains why this market/setting is unusual or interesting
- [ ] Both paragraphs together establish the puzzle

**Paragraphs 3-4: Research question and identification**
- [ ] Research question stated in one sentence by end of paragraph 3
- [ ] Identification strategy described in plain English (no formulas)
- [ ] Data source, sample size, and time period stated
- [ ] Geographic scope stated

**Paragraphs 5-6: Main findings**
- [ ] Each major hypothesis gets a labeled paragraph (H1: ..., H2: ...)
- [ ] Every finding has: coefficient magnitude + significance + economic magnitude
- [ ] Null results are explicitly flagged as informative, not dismissed

**Paragraphs 7-8: Contributions to literature**
- [ ] "This paper makes N contributions."
- [ ] For each contribution: "First, we contribute to [specific literature] by [specific finding]."
- [ ] Each literature branch has 2-3 specific citations
- [ ] Avoid "related to" -- use "extends", "provides first evidence", "reconciles tension between"

**Paragraph 9: Roadmap**
- [ ] "The remainder of the paper is organized as follows."
- [ ] One sentence per section with brief description
- [ ] Matches actual section order

**Optional teaser figure/table**
- [ ] If included: the single most compelling result, referenced explicitly
- [ ] Caption + notes complete (same standard as body figures)

--------------------------------------------------------------------------------

## Institutional Background

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 900 | 1,500 |
| JPE | 900 | 1,500 |
| AEJ:Applied | 600 | 1,200 |

### Subsection Checklist

- [ ] Subsection 1: Core institution/market -- rules, size, participants
- [ ] Subsection 2: Key variation used for identification (what creates the shock/event)
- [ ] Subsection 3: Timeline of key events (if DiD or event study)
- [ ] Subsection 4: "Why this is an ideal laboratory" (explicit, bulleted ok)
- [ ] No literature review in this section -- save for intro contributions paragraphs
- [ ] Every institutional claim has a source (government report, data.gov, official statistics)

--------------------------------------------------------------------------------

## Data

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 1,500 | 2,500 |
| JPE | 1,500 | 2,500 |
| AEJ:Applied | 1,200 | 2,000 |

### Content Checklist

- [ ] Data section opens with brief overview paragraph (1-2 sentences listing data sources)
- [ ] Subsection for each major data source:
  - [ ] Name, custodian, URL or citation
  - [ ] Years covered
  - [ ] Unit of observation
  - [ ] Total observations (before and after restrictions)
  - [ ] Key variables used
- [ ] Variable construction: displayed equation for non-trivial transformations
- [ ] Sample restrictions table or bullet list with N before/after each cut
- [ ] Panel construction: join key, matching rate, any unmatched records
- [ ] Table 1: Summary statistics (ALWAYS the first table in the paper)

### Summary Statistics Table (Table 1) Checklist

- [ ] Columns: Mean, SD, Min, Median/P25/P75, Max
- [ ] All key variables: outcome(s), treatment(s), controls, any interaction vars
- [ ] Notes line specifies: N, unit of observation, time period, data source
- [ ] No t-statistics or significance stars (this is descriptive only)
- [ ] Continuous variables first, binary indicators second
- [ ] Variables grouped logically (outcomes, treatment, controls, fixed effect vars)

--------------------------------------------------------------------------------

## Empirical Strategy

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 1,500 | 2,500 |
| JPE | 1,500 | 2,500 |
| AEJ:Applied | 1,200 | 2,000 |

### Content Checklist

- [ ] Subsection 1: Baseline specification
  - [ ] Displayed, numbered estimating equation
  - [ ] All subscripts defined (i = unit, t = time, etc.)
  - [ ] All variables defined after equation
  - [ ] SE clustering level stated and justified
- [ ] Subsection 2: Fixed effects justification
  - [ ] Each FE type with explicit statement of what confound it absorbs
- [ ] Subsection 3: Identification assumption
  - [ ] Written in plain English, one sentence
  - [ ] Formal condition (conditional independence / exclusion restriction)
- [ ] Subsection 4: Threats to validity
  - [ ] List 2-3 main threats
  - [ ] For each: threat stated -> why it does not apply -> mitigation
- [ ] Subsection 5: Interaction/additional specifications (if applicable)
  - [ ] Separate displayed equation for each interaction
  - [ ] State what the coefficient of interest is

### DiD-specific checklist

- [ ] Parallel trends assumption explicitly stated
- [ ] Pre-trend test mentioned (event study will show it)
- [ ] Treatment and control group defined precisely
- [ ] Post period defined precisely
- [ ] Any staggered treatment? If so: use Callaway-Sant'Anna or Sun-Abraham

### IV-specific checklist

- [ ] Instrument defined with displayed equation
- [ ] Relevance: explain why instrument correlates with endogenous variable
- [ ] Exclusion restriction: explain why instrument affects outcome ONLY through endogenous variable
- [ ] First stage F-statistic target: >= 10 (stock-yogo rule), ideally >= 20
- [ ] Over-identification test planned if multiple instruments

--------------------------------------------------------------------------------

## Results

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 3,000 | 4,500 |
| JPE | 2,500 | 4,000 |
| AEJ:Applied | 2,000 | 3,500 |

### Content Checklist

- [ ] Open with one-sentence summary of what the section does
- [ ] For each hypothesis/table:
  - [ ] Cite table BEFORE describing results: "Table X presents..."
  - [ ] State point estimate + SE + significance
  - [ ] Economic magnitude: dollar effect, SD-unit effect, or % of mean
  - [ ] Compare across columns (what does adding controls/FE change?)
  - [ ] Interpret the pattern across columns (what does stability suggest?)
- [ ] Event study figure:
  - [ ] Reference figure explicitly
  - [ ] Discuss pre-trend pattern (near zero = good)
  - [ ] Discuss post-treatment pattern (immediate/persistent/fading)
  - [ ] Note any anomalies with interpretation
- [ ] Null results:
  - [ ] Report coefficient + CI
  - [ ] State upper bound consistent with CI
  - [ ] Interpret as data limitation or true null (with argument)
- [ ] Heterogeneity results:
  - [ ] Ratio: "X times larger for subgroup Y"
  - [ ] Economic interpretation of heterogeneity

### Economic Magnitude Reference Calculations

For log-linear model (outcome = log(Y)):
```
% effect = beta * delta_X * 100
dollar_effect = % effect / 100 * median_level_Y
sd_effect = dollar_effect / SD(Y_levels)
```

For linear model (outcome = Y in levels):
```
% effect = beta * delta_X / mean(Y) * 100
sd_effect = beta * delta_X / SD(Y)
```

Report: "A one-standard-deviation increase in X reduces Y by Z% (= $W at the median
price; = Q standard deviations of Y)."

--------------------------------------------------------------------------------

## Robustness Checks

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 1,200 | 1,800 |
| JPE | 1,000 | 1,600 |
| AEJ:Applied | 800 | 1,400 |

### Content Checklist

- [ ] Opening sentence: "We conduct N robustness checks to assess..."
- [ ] For each check:
  - [ ] First sentence: result of the check (with coefficient)
  - [ ] Second sentence: specific threat this addresses
  - [ ] Third sentence: where full results appear (Appendix Table A?)
- [ ] At least 6 checks for QJE/JPE submission
- [ ] Checks connect to threats raised in Empirical Strategy section
- [ ] Full results tables in appendix (not main text)

--------------------------------------------------------------------------------

## Discussion / Mechanism

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 900 | 1,200 |
| JPE | 750 | 1,200 |
| AEJ:Applied | 600 | 1,000 |

### Content Checklist

- [ ] Primary mechanism paragraph: what economic force explains the main result?
  Link to theory or prior evidence.
- [ ] Secondary mechanism paragraph: if multiple channels, how do heterogeneity
  results distinguish them?
- [ ] Alternative mechanisms ruled out: what else could explain results, and why
  the evidence favors your interpretation
- [ ] Policy implications: 2-3 specific, actionable implications (not generic)
- [ ] Limitations: data limitations, generalizability, identification caveats
- [ ] Extensions: what specific data/setting would allow testing related hypotheses

--------------------------------------------------------------------------------

## Conclusion

### Word Count Targets
| Journal | Min | Max |
|---|---|---|
| QJE | 600 | 900 |
| JPE | 500 | 900 |
| AEJ:Applied | 400 | 750 |

### Content Checklist

- [ ] Para 1: Restate main findings quantitatively (2-3 key numbers)
- [ ] Para 2: Policy implications (can be brief if Discussion covers them)
- [ ] Para 3: Limitations + future research (specific directions with specific data needs)
- [ ] NO new results, coefficients, or citations
- [ ] NO new arguments or interpretations
- [ ] Does not exceed 4 pages double-spaced

--------------------------------------------------------------------------------

## Online Appendix

### Target Length: 15-25 pages

### Required Sections

1. **Data Appendix** (~3-5 pages)
   - Full data sources table (name, custodian, URL, years, observations)
   - Exact variable definitions (formulas for all constructed variables)
   - Sample construction flowchart or table (Ns before and after each restriction)

2. **Full Robustness Tables** (~8-12 pages)
   - Appendix Table A1, A2, ... for each robustness check mentioned in main text
   - Same formatting standard as main tables (booktabs, notes, stars)

3. **Additional Figures** (~2-4 pages)
   - Maps, histograms, time series not included in main text
   - Event study coefficient plots for secondary specifications

4. **Pre-Trend Discussion** (~1-2 pages, if DiD or event study)
   - Discuss pre-period coefficient pattern in detail
   - Address any pre-trend concerns

### Optional Appendix Sections

- Simple theoretical model (if conceptual motivation is needed)
- Survey instrument (if survey data)
- IRB approval / pre-registration documentation
- Town/region classification details (for spatial studies)
- Monsoon/season classification (for climate studies)
