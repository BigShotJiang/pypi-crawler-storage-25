# How to Write Referee Responses

Guide for responding to journal referee reports at QJE, JPE, AEJ:Applied, AER.
Based on conventions for top-field journals in economics.

--------------------------------------------------------------------------------

## 1. General Principles

**Tone**: Professional, respectful, never defensive. Treat referees as
collaborative reviewers, not adversaries.

**Stance**: The referee is always right about what confused them, even if
their specific suggestion is wrong. Address the confusion, not just the
suggestion.

**Speed**: Respond within the deadline. If more time is needed, ask the
editor in advance. Missing deadlines signals poor project management.

**Format**: Cover letter to editor + separate response memo to each referee.
Number every change. Cross-reference in revision.

--------------------------------------------------------------------------------

## 2. Response Document Structure

### Cover Letter (to Editor)

```
Dear [Editor Name],

We are grateful for the opportunity to revise [paper title] for the
[Journal Name]. We thank the editor and referees for their thoughtful
and constructive comments.

The referees raised [N] main concerns, which we address through the
following major changes:

1. [Change 1: e.g., "We added a new robustness check (Section 6.3)
   addressing Referee 1's concern about X."]
2. [Change 2]
3. [Change 3]

Below, we provide detailed responses to each comment. All changes in the
revised manuscript are highlighted in blue for ease of review.

Sincerely,
[Authors]
```

### Referee Response Format

```
RESPONSE TO REFEREE [N]

We thank Referee [N] for the careful reading and constructive suggestions.
We address each comment in turn.

---
COMMENT [N].1:
[Quote or paraphrase the referee's comment verbatim or very closely.]

RESPONSE:
[Your response, starting with what you did: "We have..." or "We agree that..."
Then explain, justify, or show new results. Reference the specific location
in the revised manuscript: "We add the following paragraph on p. 12..."]

---
COMMENT [N].2:
...
```

--------------------------------------------------------------------------------

## 3. Response Templates by Situation

### When you agree and make the change

```
RESPONSE: We agree with this concern. We have [added a robustness check /
revised the specification / expanded the discussion] to address it.
[Describe the change briefly.] The relevant results appear in
Table A[N] / Section [N] / p. [N] of the revised manuscript.
```

### When you partially agree

```
RESPONSE: We agree that [aspect the referee is right about]. However, we
respectfully disagree with [specific aspect]. [Explain why, with evidence or
logic.] Nevertheless, in response to the referee's broader concern, we have
[what you actually did to address the spirit of the comment]. The result is
[describe].
```

### When you disagree (with evidence)

```
RESPONSE: We appreciate this concern. However, we believe our current
approach is appropriate for the following reasons.

First, [econometric / data / institutional reason]. Second, [additional
reason]. [Optional: cite a paper that uses the same approach in a similar
context: "This approach is also used by [Author Year] in [setting]."]

Nevertheless, to directly address the referee's concern, we have added
[robustness check / discussion] in [location]. The results [confirm /
do not change] our main finding.
```

### When the referee asks for something you cannot do (data limitation)

```
RESPONSE: We share the referee's interest in [what was asked for].
Unfortunately, [data that would be needed] is not publicly available /
does not cover our sample period / is not available at the required
geographic resolution. We have added a paragraph in Section [N] acknowledging
this as a limitation and describing what data would be needed for this extension:

"[New paragraph from revised manuscript, indented or quoted.]"
```

### When the referee misunderstood

```
RESPONSE: We thank the referee for this comment. We believe there may be
a misunderstanding about [what was misunderstood]. To clarify: [explanation].

To prevent future readers from the same confusion, we have revised [section]
to state more clearly:

"[New or revised text from manuscript]"
```

--------------------------------------------------------------------------------

## 4. Numbering Changes

Always number every change to the manuscript. Reference these numbers in
your responses:

```
[In the response:]
RESPONSE: We have added a robustness check excluding crisis years.
See Change #7 on p. 28 of the revised manuscript.

[In the manuscript margin or cover letter change log:]
Change #7 (p. 28): Added subsection 6.3 on excluding GFC and COVID periods.
Result: coefficient unchanged at beta = -1.1e-5 (p < 0.001).
```

This makes the editor's job easy: they can verify each change has been made.

--------------------------------------------------------------------------------

## 5. The "Big" Comments

### "Your identification is not convincing"

This requires a substantive response. Do NOT just say "we addressed this."

Structure:
1. Acknowledge the concern precisely
2. Present new evidence (pre-trend test, placebo, additional robustness)
3. Explain why the remaining concern does not overturn the finding
4. Be honest about residual uncertainty

### "Your paper is too long"

- Identify the top 3 candidates for cuts (often lit review, methodology details)
- Move to appendix rather than deleting (in case referee 2 wants it)
- State the new page count in your response

### "Your economic magnitude is too small to be interesting"

Structure:
1. Present the magnitude calculation carefully
2. Compare to published benchmarks (what do other papers find for related shocks?)
3. Argue for statistical precision / policy relevance even if small
4. Or: agree and reframe the paper's contribution as precision / identification,
   not magnitude

### "Add [literature X]"

If it is relevant: add 3-5 citations and 1-2 sentences positioning relative to that work.
If it is tangential: add a footnote acknowledging the connection.
Never just add a citation without connecting it to your paper.

--------------------------------------------------------------------------------

## 6. Common Mistakes in Referee Responses

| Mistake | Why it matters | Fix |
|---|---|---|
| Responding to what you wish the referee said | Referee feels ignored | Quote their exact words first |
| Being defensive | Antagonizes referee; hurts revision | Start with "We agree" even if partial |
| Saying "we addressed this" with no details | Editor cannot verify | State page/table/section of change |
| Adding 10 new robustness checks | Bloat; signals insecurity | Add only the 1-2 most critical |
| Ignoring minor comments | Referee notices; signals sloppiness | Address all comments, even brief ones |
| Missing the deadline | Signals poor organization | Ask for extension well in advance |
| Over-promising in the cover letter | Must deliver what you promise | Only list changes you actually made |

--------------------------------------------------------------------------------

## 7. Revision Checklist

- [ ] Read all referee reports twice before writing any response
- [ ] Categorize comments: major, moderate, minor
- [ ] Address major comments with new analysis or substantial new text
- [ ] Address every single comment, no matter how minor
- [ ] Number all changes in the manuscript and reference them in responses
- [ ] Highlight changes in blue (or as editor specifies)
- [ ] Cover letter to editor summarizes major changes in 3-5 bullet points
- [ ] Update abstract if main findings have changed
- [ ] Run paper_audit.py on revised draft before resubmitting
- [ ] Run wordcount.py to confirm still within page limits
- [ ] Recompile fully: pdflatex + bibtex + pdflatex x2
- [ ] Zero undefined references in final PDF
