# QJE/JPE Writing Style Guide

Detailed conventions for Quarterly Journal of Economics, Journal of Political
Economy, and AEJ:Applied submissions. Synthesized from published papers and
editorial guidance.

--------------------------------------------------------------------------------

## 1. QJE vs JPE House Style Differences

| Feature | QJE | JPE |
|---|---|---|
| Author voice | "We find" (preferred) | "We find" or "This paper" |
| Citations | natbib, aer style | natbib, chicago or aer style |
| Footnotes | Sparingly; technical details | More generous; institutional notes ok |
| Tables | End of paper for submission | End of paper for submission |
| Figures | End of paper for submission | End of paper for submission |
| Abstract length | < 150 words strict | < 200 words |
| Page limit | 45 pages incl. tables/figs | 50 pages incl. tables/figs |
| Online appendix | Required for robustness | Required for robustness |
| Referee list | 3-5 suggested referees | 3-5 suggested referees |
| Cover letter | Expected | Expected |
| JEL codes | 3-5 codes required | 3-5 codes required |
| Data availability | Statement required | Statement required |

Both journals use Chicago author-date citation style (natbib with aer.bst or
chicago.bst). The difference is minor: QJE tends to prefer tighter prose.

--------------------------------------------------------------------------------

## 2. Citation Style in Text

### Textual citations (author as subject)

```latex
\citet{acemoglu2001colonial} show that...
As \citet{dell2010mining} documents, forced labor institutions...
\citet{bordalo2012salience} develop a model in which...
```

### Parenthetical citations (at end of sentence)

```latex
...consistent with prior findings \citep{hirshleifer2003good}.
...a well-documented pattern in asset markets \citep{saunders1993stock, hirshleifer2003good}.
```

### Multiple authors

```latex
% Two authors: Author and Author (Year)
\citet{genesove2001loss}  % => Genesove and Mayer (2001)

% Three+ authors: Author et al. (Year)
\citet{bernstein2019disaster}  % => Bernstein et al. (2019)
```

### Citation placement rules

- Citation immediately follows the claim it supports (not at end of paragraph)
- One citation per factual claim; do not stack 5 citations for one fact
- Do not cite papers you have not read; paraphrase is acceptable but cite the source
- For seminal contributions: cite the original paper, then the most recent update

--------------------------------------------------------------------------------

## 3. How to Present Results by Method

### OLS / FE Results

```
The coefficient on [treatment] is [beta] (SE = [se], p < 0.001), implying
that a one-unit / one-standard-deviation increase in [X] is associated with
a [magnitude]% [dollar/SD] [increase/decrease] in [Y].

Column (2) adds [FE], leaving the point estimate largely unchanged ([new beta]),
suggesting that [confound] is not driving the baseline result.
```

### DiD Results

```
The DiD estimate -- the coefficient on [treated x post] -- is [beta]
(SE = [se], p = [p]), indicating that [treated group] experienced a
[magnitude] [larger/smaller] [outcome] relative to [control group] after
[event].

The pre-period coefficients in the event study (Figure X) are [near zero /
slightly negative], [consistent with / suggesting concern about] the parallel
trends assumption.
```

### IV / 2SLS Results

```
Column (3) reports the 2SLS estimates using [instrument] as an instrument
for [endogenous variable]. The first-stage F-statistic is [F] (> 10 threshold
for weak-instrument concerns), indicating that the instrument is relevant.
The IV estimate ([beta_iv]) is [larger/smaller/similar] to the OLS estimate
([beta_ols]), suggesting [direction of endogeneity bias].
```

### RDD Results

```
Figure X plots the raw data around the [threshold]. There is a visible
discontinuity of approximately [magnitude] at the cutoff. The RDD estimate
([beta]) uses a bandwidth of [h], selected via the mean-squared-error-optimal
bandwidth procedure of \citet{calonico2014robust}. The McCrary density test
([p]) shows no evidence of manipulation at the cutoff.
```

### Event Study Results

```
Figure X plots the event study coefficients, with the period immediately
before [event] as the omitted category. The pre-treatment coefficients
are [near zero and statistically insignificant], supporting the parallel
trends assumption. After [event], we observe [pattern: immediate jump /
gradual increase / V-shape], with the effect [persisting/fading] over
the subsequent [N] periods.
```

--------------------------------------------------------------------------------

## 4. How to Write the Identification Argument

Every empirical paper must have a clear, explicit identification argument.
Use this four-paragraph template in the Empirical Strategy section:

**Paragraph 1: Identification assumption (plain English)**
> "Our identification assumption is that [treatment/instrument] is uncorrelated
> with unobserved determinants of [outcome] conditional on [FE and controls].
> Formally, $E[\varepsilon_{it} | X_{it}, \alpha_i, \delta_t] = 0$."

**Paragraph 2: Why the assumption plausibly holds**
> "Several features of our setting support this assumption. First, [reason 1].
> Second, [reason 2]. Third, [reason 3, e.g., event study / pre-trend test]."

**Paragraph 3: Main threat to validity + mitigation**
> "The primary concern is [threat: omitted variable / reverse causality /
> selection]. This would bias our estimates [upward/downward] if [mechanism].
> We address this by [control/IV/robustness check], which [how it helps]."

**Paragraph 4: Residual caveat (honest)**
> "We cannot completely rule out [residual threat]. However, [why it is
> unlikely to overturn the main finding, or what would need to be true for it
> to matter]."

--------------------------------------------------------------------------------

## 5. How to Discuss Null Results

Never dismiss a null result with "p = 0.207, insignificant." Use this template:

**Step 1: Report the estimate with CI**
> "The triple-interaction coefficient is $\beta = -8.2 \times 10^{-5}$
> (95% CI: $[-2.1 \times 10^{-4}, 4.7 \times 10^{-5}]$, $p = 0.207$)."

**Step 2: Give economic upper bound**
> "Our estimates rule out effects larger than $2.1 \times 10^{-4}$ at the
> 95% confidence level, corresponding to approximately 2.1% per 100mm rainfall
> deviation."

**Step 3: Explain why the null is informative**
Choose one of:
- Data limitation: "Our null result likely reflects [data limitation] rather
  than a true zero. A proper test would require [what data/variation]."
- Policy response: "The null is consistent with [policy response] having offset
  the mechanism we hypothesize."
- True zero: "We interpret the null as evidence that [mechanism] does not
  operate in this setting, because [why]."

**Step 4: Bound the effect for future research**
> "Future work with [better data] should be able to detect effects as small
> as [lower bound implied by CI] with a sample of [N]."

--------------------------------------------------------------------------------

## 6. How to Write Robustness Checks

Each robustness check gets one paragraph. Use this template:

> "[Check name]: [First sentence = result of the check]. [Second sentence =
> what specific threat this check addresses]. [Third sentence = where full
> results appear]."

Example:
> "Excluding the Global Financial Crisis (2008--2009) and COVID-19 period
> (2020--2021) yields a baseline coefficient of $-1.1 \times 10^{-5}$
> ($p < 0.001$), essentially identical to our main estimate. This rules out
> the concern that our results are driven by unusual recession-period housing
> market behavior, which might correlate with weather through reduced outdoor
> activity and demand suppression. Appendix Table A2 reports full results."

**Never write**:
- "Results are robust to X." (state the coefficient)
- "We also run X and find similar results." (quantify similar)
- Long methodology descriptions in the robustness section (one sentence per check)

**10-check robustness menu**:
1. Alternative SE clustering (borough/county/state level instead of baseline)
2. Alternative treatment measure (alternative bins or normalization)
3. Alternative outcome (levels instead of logs, IHS, winsorized 99th pct)
4. Exclude crisis/outlier years
5. Placebo treatment (randomly assigned treatment, fake dates)
6. Subsample analysis (time period halves, geographic subsets)
7. Additional controls (neighborhood characteristics, macro controls)
8. IV / 2SLS (if baseline is OLS with potential endogeneity)
9. Alternative FE structure (interact FEs, add more granular FEs)
10. Long differences (5-year window, first differences)

--------------------------------------------------------------------------------

## 7. 10 Phrases to Always Use

| Phrase | When to use |
|---|---|
| "We find that..." | Stating a main result |
| "Consistent with [mechanism], we find that..." | Mechanism test |
| "The coefficient is $\beta = X$ ($p < 0.001$), implying..." | Reporting result |
| "This corresponds to approximately..." | Economic magnitude |
| "These estimates are robust to..." | Robustness introduction |
| "We regard this as [A] rather than [B]." | Null result interpretation |
| "Column (N) adds [control/FE], leaving the estimate largely unchanged." | Table walk-through |
| "The effect is [N] times larger for [subgroup]..." | Heterogeneity |
| "Our identifying assumption is that..." | Strategy section |
| "We cannot completely rule out [threat], but [mitigation]." | Honest caveat |

## 8. 10 Phrases to Never Use

| Phrase | Why banned | Alternative |
|---|---|---|
| "This paper studies X." | Weak opener; state the finding | Open with a striking fact |
| "In recent years, X has become important." | Generic filler | Delete; start with specific claim |
| "Many economists have shown..." | Vague; condescending | Cite specific papers |
| "Interestingly, we find..." | Condescending; let result speak | Delete "Interestingly" |
| "It is worth noting that..." | Filler | Delete or just say the thing |
| "The results are significant." | Ambiguous | Specify: statistically / economically |
| "We fail to reject the null." | Passive; negative framing | "We find no significant effect of X" |
| "The table below shows..." | Avoid positional references | "Table \\ref{tab:X} shows..." |
| "We improve upon / build upon [paper]." | Vague | "We extend [paper] by showing Y" |
| "Future research should explore X." | Vague | "Future work using [data/setting] can test Y" |

--------------------------------------------------------------------------------

## 9. Abstract Quality Checklist

- [ ] First sentence: motivating fact or puzzle (not "This paper studies X")
- [ ] Second sentence: what this paper does (data + method + setting)
- [ ] Sentences 3-5: main findings with quantitative magnitudes
- [ ] Last sentence: contribution (which literatures advanced)
- [ ] No citations in abstract
- [ ] No footnotes in abstract
- [ ] JEL codes follow abstract (3-4 codes)
- [ ] Keywords follow JEL codes (5-7 terms)
- [ ] Word count: QJE <= 150 strict; JPE <= 200; working paper <= 250

--------------------------------------------------------------------------------

## 10. Introduction Paragraph Map

| Para | Content | Common mistake |
|---|---|---|
| 1-2 | Motivating fact / puzzle | Opening too broad; no concrete fact |
| 3-4 | Research question + identification in plain English | Question appears after para 4 |
| 5-6 | Main findings (quantitative, one sub-para per finding) | No magnitudes; just "significant" |
| 7-8 | Contributions to 3-4 literatures (specific) | Generic "contributes to literature" |
| 9 | Roadmap | Missing or too detailed |

The introduction should take the reader through the paper's logic in 2,000-3,000 words.
The reader should know the answer before reading the paper -- the introduction is
a spoiler, not a mystery novel.
