
# Maestro Literature Review

Systematic literature search and analysis engine for academic research projects.
Runs in the project directory (cwd = ~/dropbox/{project_no}/).
Has access to: Read, Write, Edit, Bash, Grep, Glob.

## 0. Dropbox Smart Sync (IMPORTANT)

Project files live on Dropbox. Files may appear as 0-byte placeholders until
accessed. **Always use the Read tool to open files** -- this triggers Dropbox
to download them on demand. NEVER use `ls -la` to check file sizes and conclude
files are empty.

--------------------------------------------------------------------------------

## 1. Inputs

The user provides one or more of:
- Research question or hypothesis
- Key terms / concepts
- Target journals or fields
- Draft abstract or introduction
- Specific papers to start from (seed papers)
- Requirements file in `00-requirement/`

Read ALL files in `00-requirement/` first. Extract:
- Research question (RQ)
- Proposed hypothesis or contribution
- Key independent/dependent variables
- Target discipline (economics, finance, public health, etc.)
- Geographic/temporal scope
- Any cited papers (seed set)

If no `00-requirement/` exists, use the user prompt directly.

--------------------------------------------------------------------------------

## 2. Search Strategy

### 2a. Term Expansion

From the research question, generate:
1. **Primary terms**: Exact concepts from the RQ (3-5 terms)
2. **Synonyms**: Alternative phrasings for each primary term
3. **Broader terms**: Parent concepts (for context papers)
4. **Narrower terms**: Specific subtopics (for direct competitors)
5. **Methodology terms**: Statistical/empirical methods likely used

Record the search strategy in `01-lit-review/search_strategy.md`.

### 2b. API Search Execution

Use BOTH APIs for comprehensive coverage.

**API Priority**: Use OpenAlex as primary source (no auth required, generous rate limits).
Use Semantic Scholar only for citation expansion (requires SS_API_KEY env var for reliable access).
Rate limit: OpenAlex 10 req/s unauthenticated; SS 1 req/s without key, 10 req/s with key.

#### Semantic Scholar API

Base URL: `https://api.semanticscholar.org/graph/v1`

Endpoints:
- `GET /paper/search?query={q}&limit=100&fields=...`
- `GET /paper/{paperId}?fields=...`
- `GET /paper/{paperId}/citations?fields=...&limit=100`
- `GET /paper/{paperId}/references?fields=...&limit=100`

Fields to request: `paperId,title,abstract,year,citationCount,influentialCitationCount,authors,venue,publicationTypes,externalIds,tldr,fieldsOfStudy`

Rate limits: 1 request/second without API key. Use `time.sleep(1.1)` between calls.

#### OpenAlex API

Base URL: `https://api.openalex.org`

Endpoints:
- `GET /works?search={q}&per_page=100&sort=cited_by_count:desc`
- `GET /works?filter=cites:{id}&per_page=100`
- `GET /works/{id}?select=id,title,abstract_inverted_index,...`

Use `mailto` parameter for polite pool: `?mailto=ra@maestro.onl`

### 2c. Search Phases

**Phase 1: Broad search** (200-500 candidate papers)
- Run primary terms on both APIs
- Sort by citation count, take top 100 per query
- Deduplicate by DOI or title similarity

**Phase 2: Citation expansion** (seed papers)
- For each seed paper: fetch references AND citations
- For top-10 most-cited results from Phase 1: fetch references
- This captures the "citation neighborhood"

**Phase 3: Recent papers** (last 2 years)
- Re-run primary terms with year filter >= current_year - 2
- Sort by recency, take top 50
- These may have low citation counts but represent frontier work

**Phase 4: Methodology-specific search**
- Search for methodology terms + domain terms
- Example: "difference-in-differences" AND "minimum wage"
- Captures papers using similar methods on similar topics

Save all raw search results to `01-lit-review/raw_results.json`.

### 2d. Deduplication and Filtering

1. Deduplicate by DOI (exact match)
2. Deduplicate by normalized title (lowercase, strip punctuation, Jaccard > 0.9)
3. Filter: remove if no abstract AND no TLDR
4. Filter: remove if clearly off-topic (use keyword presence check)
5. Target: 80-200 unique papers after filtering

Save filtered corpus to `01-lit-review/corpus.json`.

--------------------------------------------------------------------------------

## 3. Analysis Pipeline

### 3a. Paper Classification

Classify each paper along these dimensions:

**Methodology category:**
- Theoretical / Model
- Empirical / Observational
- Experimental / RCT
- Quasi-experimental (DiD, RDD, IV, etc.)
- Machine Learning / Computational
- Meta-analysis / Review
- Qualitative / Case Study
- Mixed Methods

**Relevance to RQ:**
- Direct (same question, same context)
- Methodological (same method, different context)
- Contextual (same context, different question)
- Tangential (related but distant)

**Relationship to hypothesis:**
- Supports
- Contradicts
- Extends
- Orthogonal

Save classifications to `01-lit-review/classifications.json`.

### 3b. Methodology Grouping

Group papers by methodology. For each group:
1. Count papers
2. List key findings (supports/contradicts)
3. Note data sources used
4. Note geographic/temporal scope
5. Identify the "canonical" paper (highest citation + earliest)

### 3c. Research Gap Analysis

Identify gaps by looking for:
1. **Geographic gaps**: Methods applied in US but not EU/Asia
2. **Temporal gaps**: Studies use pre-2015 data, post-2015 unstudied
3. **Methodological gaps**: Only OLS used, no causal identification
4. **Variable gaps**: Key moderators or channels unexplored
5. **Data gaps**: Existing studies use aggregate data, micro-data unexplored
6. **Population gaps**: Studied in large firms but not SMEs

For each gap, rate:
- Importance (high/medium/low)
- Feasibility of filling (easy/moderate/hard)
- Relevance to user's RQ

### 3d. Novelty Assessment

Score the user's proposed research along:

| Dimension | Score (1-5) | Assessment |
|-----------|-------------|------------|
| Question novelty | How new is the RQ? |
| Data novelty | New data source or construction? |
| Method novelty | New method or application? |
| Context novelty | New geographic/temporal setting? |
| **Overall novelty** | Weighted average |

Provide explicit comparison: "Paper X by Author (Year) is the closest existing
work. Your contribution differs because..."

### 3e. Positioning Recommendation

Based on gap analysis and novelty assessment, recommend:
1. **Primary contribution frame**: What is the paper's main value-add?
2. **Literature streams to cite**: Which groups of papers to reference
3. **Key papers to engage with**: 5-10 must-cite papers
4. **Differentiation points**: How to distinguish from closest competitors
5. **Potential objections**: What reviewers might challenge, and pre-emptive responses

--------------------------------------------------------------------------------

## 4. Output: Literature Survey Report (LaTeX PDF)

File: `01-lit-review/lit_review_report.tex`

Use `xelatex` for compilation. Brand: "Maestro AI Research Assistant".

### Report Structure

```latex
\documentclass[11pt,a4paper]{article}
\usepackage[margin=1in]{geometry}
\usepackage{fontspec}
\setmainfont{Times New Roman}
\usepackage{hyperref}
\usepackage{booktabs}
\usepackage{longtable}
\usepackage{natbib}
\bibliographystyle{apalike}

\title{Literature Survey Report\\[0.5em]
\large [Project Title]}
\author{Maestro AI Research Assistant}
\date{\today}
```

Sections:
1. **Research Question and Scope** -- Restate the RQ, key terms, search scope
2. **Search Methodology** -- APIs used, query terms, result counts, filtering
3. **Literature Landscape** -- High-level statistics (N papers, year range, top venues, citation distribution)
4. **Methodology Groups** -- For each group: summary table, key findings, canonical papers
5. **Research Gap Analysis** -- Identified gaps with importance/feasibility ratings
6. **Novelty Assessment** -- Scoring table, closest competitors, differentiation
7. **Positioning Recommendation** -- Contribution frame, must-cite papers, strategy
8. **Full Paper Catalog** -- Complete table of all papers with metadata
9. **References** -- BibTeX bibliography

### Compilation

```bash
cd 01-lit-review
xelatex -interaction=nonstopmode lit_review_report.tex
bibtex lit_review_report
xelatex -interaction=nonstopmode lit_review_report.tex
xelatex -interaction=nonstopmode lit_review_report.tex
```

If xelatex is not available, fall back to pdflatex.

--------------------------------------------------------------------------------

## 5. Output: Structured Data Files

### lit_review_summary.json (Machine-readable output)

```json
{
  "research_question": "...",
  "search_stats": {
    "total_candidates": 450,
    "after_dedup": 320,
    "after_filter": 150,
    "seed_papers": 5,
    "date_range": "2000-2026"
  },
  "methodology_groups": [
    {
      "name": "Quasi-experimental (DiD)",
      "count": 23,
      "canonical_paper": {"title": "...", "authors": "...", "year": 2018, "doi": "..."},
      "key_finding": "...",
      "consensus": "supports | mixed | contradicts"
    }
  ],
  "research_gaps": [
    {
      "description": "...",
      "importance": "high",
      "feasibility": "moderate",
      "relevance_to_rq": "direct"
    }
  ],
  "novelty_scores": {
    "question": 3,
    "data": 4,
    "method": 2,
    "context": 5,
    "overall": 3.5
  },
  "must_cite_papers": [
    {"title": "...", "authors": "...", "year": 2020, "doi": "...", "reason": "..."}
  ],
  "positioning": {
    "primary_contribution": "...",
    "differentiation_points": ["...", "..."],
    "potential_objections": ["...", "..."]
  }
}
```

### references.bib (BibTeX)

Generate BibTeX entries for all papers in the corpus. Use Semantic Scholar
external IDs (DOI preferred) to construct citation keys: `AuthorYear` format.

### corpus.json (Full paper metadata)

All filtered papers with: title, authors, year, venue, abstract, DOI,
citation count, methodology classification, relevance rating.

--------------------------------------------------------------------------------

## 6. delivery.json (Mandatory)

```json
{
  "skill": "lit-review",
  "version": "1.0",
  "status": "completed",
  "deliverables": [
    {"path": "01-lit-review/lit_review_report.pdf", "type": "report", "description": "Literature survey PDF"},
    {"path": "01-lit-review/lit_review_report.tex", "type": "source", "description": "LaTeX source"},
    {"path": "01-lit-review/lit_review_summary.json", "type": "data", "description": "Structured summary"},
    {"path": "01-lit-review/corpus.json", "type": "data", "description": "Full paper corpus"},
    {"path": "01-lit-review/references.bib", "type": "data", "description": "BibTeX bibliography"},
    {"path": "01-lit-review/search_strategy.md", "type": "documentation", "description": "Search methodology"}
  ],
  "summary": "Literature survey of N papers across M methodology groups. N gaps identified. Novelty score: X/5."
}
```

--------------------------------------------------------------------------------

## 7. Quality Checklist

Before marking complete, verify:

- [ ] Search used BOTH Semantic Scholar AND OpenAlex
- [ ] At least 50 papers in final corpus (fewer only if niche topic with justification)
- [ ] Papers grouped by methodology (at least 3 groups)
- [ ] At least 2 research gaps identified with importance ratings
- [ ] Novelty assessment has all 4 dimension scores
- [ ] Must-cite list has 5-10 papers with reasons
- [ ] LaTeX compiles without errors
- [ ] BibTeX entries are valid
- [ ] delivery.json written to project root
- [ ] lit_review_summary.json is valid JSON

--------------------------------------------------------------------------------

## 8. Common Pitfalls

1. **Citation count bias**: High-citation papers dominate but recent work matters.
   Always include a "Recent papers" section (last 2 years).
2. **API rate limits**: Semantic Scholar: 1 req/s. OpenAlex: 10 req/s (polite pool).
   Always add sleep between calls.
3. **Incomplete abstracts**: Some papers lack abstracts. Use TLDR from Semantic Scholar
   or title-based classification as fallback.
4. **Duplicate papers across APIs**: Same paper may have different IDs. Deduplicate by DOI.
5. **Field-specific jargon**: Economics papers use "treatment effect", medical papers
   use "intervention effect" for the same concept. Include synonyms in search.
6. **Overscoping**: A lit review for "machine learning in finance" returns thousands.
   Narrow by methodology, time period, or specific application.
7. **Missing working papers**: NBER/SSRN working papers may not be indexed.
   If the user mentions specific working papers, search by title directly.

--------------------------------------------------------------------------------

## 9. Gotchas

- **Semantic Scholar rate limit**: 100 requests per 5 minutes. Add exponential backoff.
- **OpenAlex returns incomplete author lists**: Cross-check with Semantic Scholar for full author names.
- **DOI lookup fails for working papers**: Fallback to title search.
- **Abstract quality varies**: Some entries have just "forthcoming" -- filter these out.
