
# maestro-gee — GEE Raster → Admin Panel Pipeline

## Pipeline Position

```
GEE (raster)
  → ee.batch.Export.table.toDrive  (zonal stats → CSV in Google Drive)
  → download via Drive API (using EE OAuth credentials)
  → clean + rename columns
  → data.parquet (ZSTD, DuckDB-queryable)
  → maestro-dataset (README + codebook + version.json)
```

GEE's role is **computation only** — it does the zonal reduction on a planet-scale raster.
The result is a flat CSV (admin2 × year) that drops into the standard maestro-dataset structure.

---

## Setup & Authentication

### GEE Project Registration
1. Create a Google Cloud project at https://console.cloud.google.com
2. Enable Earth Engine API: https://console.cloud.google.com/apis/library/earthengine.googleapis.com
3. Register project for Earth Engine: https://console.cloud.google.com/earth-engine/configuration
4. Initialize in Python:
   ```python
   import ee
   ee.Initialize(project="your-gcp-project-id")
   ```

### Authentication
```bash
earthengine authenticate   # opens browser → saves to ~/.config/earthengine/credentials
```

### Check Authentication
```python
import ee
ee.Initialize(project="growth-foundry-seo")
img = ee.Image(1)
print(img.getInfo())  # should return {"type": "Image", ...}
```

---

## Critical: GEE Reducer Output Column Naming

**GEE names reducer outputs as `{band_name}_{reducer_name}`, NOT `{reducer_name}_{band_name}`.**

| Reducer call | Band name | GEE output column |
|---|---|---|
| `.mean()` | NDVI | `NDVI_mean` |
| `.median()` | NDVI | `NDVI_median` |
| `.stdDev()` | LST_Day_1km | `LST_Day_1km_stdDev` |
| `.percentile([90])` | avg_rad | `avg_rad_p90` |
| `.mean()` (single band, unnamed) | `stable_lights` after `.select()` | `mean` |

**Always test before batch export:**
```python
feat = result.first().getInfo()
print(feat['properties'].keys())  # check actual names before specifying selectors
```

If selectors specify non-existent columns → GEE exports null values silently with no error.

---

## Standard Boundary Collections

| Collection | Level | Units | Notes |
|---|---|---|---|
| `FAO/GAUL/2015/level2` | Admin2 | 38,258 | Preferred for global panels |
| `FAO/GAUL/2015/level1` | Admin1 | ~3,500 | |
| `USDOS/LSIB_SIMPLE/2017` | Country | 312 | |
| `TIGER/2018/Counties` | US County | 3,233 | US only |

```python
admin2 = ee.FeatureCollection("FAO/GAUL/2015/level2")
```

---

## Standard Workflow

### Step 1: Export Script (01_gee_export.py)

```python
#!/usr/bin/env python3
import ee, time
PROJECT = "growth-foundry-seo"
FOLDER  = "maestro-gee-exports"
ee.Initialize(project=PROJECT)

admin2 = ee.FeatureCollection("FAO/GAUL/2015/level2")

# --- define your raster source ---
col = ee.ImageCollection("MODIS/061/MOD13Q1").select(["NDVI","EVI","SummaryQA"])

def annual_image(year):
    y = int(year)
    def mask_quality(img):
        qa = img.select("SummaryQA")
        return img.updateMask(qa.lte(1))
    return (col.filterDate(f"{y}-01-01", f"{y}-12-31")
               .map(mask_quality)
               .select(["NDVI","EVI"])
               .mean()
               .multiply(0.0001)      # apply scale factor
               .set("year", y))

years  = list(range(2000, 2027))
images = ee.ImageCollection([annual_image(y) for y in years])

# --- ALWAYS test reducer output names on 1 feature first ---
# test_result = images.first().reduceRegions(
#     collection=admin2.limit(1),
#     reducer=ee.Reducer.mean().combine(ee.Reducer.median(), sharedInputs=True),
#     scale=250, tileScale=8
# )
# print(test_result.first().getInfo()['properties'].keys())
# Expected: NDVI_mean, NDVI_median, EVI_mean, EVI_median

def reduce_year(img):
    year = img.get("year")
    return (img.reduceRegions(
                collection=admin2,
                reducer=ee.Reducer.mean().combine(
                    ee.Reducer.median(), sharedInputs=True),
                scale=250,    # match source resolution
                tileScale=8)  # increase for 250m; use 4 for 1km
            .map(lambda f: f.set("year", year)))

results = images.map(reduce_year).flatten()

task = ee.batch.Export.table.toDrive(
    collection=results,
    description="my_panel_v1",
    folder=FOLDER,
    fileNamePrefix="my_panel_v1",
    fileFormat="CSV",
    # CRITICAL: use actual GEE output names (band_reducer order)
    selectors=["ADM0_NAME","ADM1_NAME","ADM2_NAME","ADM2_CODE","year",
               "NDVI_mean","NDVI_median","EVI_mean","EVI_median"],
)
task.start()
print(f"Task started: {task.id}")

while task.active():
    print(f"  [{task.status()['state']}]")
    time.sleep(60)
print("Export complete.")
```

### tileScale Guidelines

| Source resolution | tileScale |
|---|---|
| 500m (VIIRS) | 4 |
| 1km (MODIS LST, DMSP) | 4 |
| 250m (MODIS NDVI/EVI) | 8 |
| 30m (Landsat) | 16 |

### Empty Year Guard (for partial coverage years)

```python
def safe_annual(year, col):
    y = int(year)
    filtered = col.filterDate(f"{y}-01-01", f"{y}-12-31")
    return ee.Algorithms.If(
        filtered.size().gt(0),
        filtered.median().set("year", y),
        ee.Image(0).rename("avg_rad").set("year", y).set("empty", True)
    )
```

Use when: collection may not have data for recent/future years (e.g. 2025-2026).

---

### Step 2: Download from Drive (using EE credentials)

GEE authenticates via `~/.config/earthengine/credentials` which already has Drive scope.
Use these credentials directly — no `gcloud auth application-default login` needed.

```python
import ee, os, json
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

def get_drive_service():
    """Build Drive API client using EE OAuth credentials."""
    ee.Initialize(project="growth-foundry-seo")
    args = ee.oauth.get_credentials_arguments()
    creds = Credentials(
        token=None,
        refresh_token=args["refresh_token"],
        token_uri=args["token_uri"],
        client_id=args["client_id"],
        client_secret=args["client_secret"],
        scopes=args["scopes"],
    )
    return build("drive", "v3", credentials=creds)


def download_gee_export(filename: str, dest_path: str):
    """Download a file by name from Google Drive (GEE exports folder)."""
    if os.path.exists(dest_path) and os.path.getsize(dest_path) > 1000:
        print(f"[skip] {filename} already downloaded ({os.path.getsize(dest_path)/1e6:.1f} MB)")
        return

    service = get_drive_service()
    results = service.files().list(
        q=f"name='{filename}' and trashed=false",
        spaces="drive",
        fields="files(id,name,size)"
    ).execute()
    files = results.get("files", [])
    if not files:
        raise FileNotFoundError(f"'{filename}' not found in Drive. Is the GEE task complete?")

    fid = files[0]["id"]
    size_mb = int(files[0].get("size", 0)) / 1e6
    print(f"Downloading {filename} ({size_mb:.1f} MB) ...")

    req = service.files().get_media(fileId=fid)
    with open(dest_path, "wb") as fh:
        dl = MediaIoBaseDownload(fh, req, chunksize=16 * 1024 * 1024)
        done = False
        while not done:
            status, done = dl.next_chunk()
            if status:
                print(f"  {int(status.progress() * 100)}%", end="\r")
    print(f"[done] {dest_path}  ({os.path.getsize(dest_path)/1e6:.1f} MB)")
```

### Step 3: Process CSV → Parquet

```python
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

df = pd.read_csv("my_panel_v1.csv")

# Rename GEE columns to warehouse convention (lowercase snake_case)
df = df.rename(columns={
    "ADM0_NAME":   "adm0_name",
    "ADM1_NAME":   "adm1_name",
    "ADM2_NAME":   "adm2_name",
    "ADM2_CODE":   "adm2_code",
    "NDVI_mean":   "ndvi_mean",
    "NDVI_median": "ndvi_median",
    "EVI_mean":    "evi_mean",
    "EVI_median":  "evi_median",
})

df["year"]      = df["year"].astype(int)
df["adm2_code"] = df["adm2_code"].astype(str)
df = df.dropna(subset=["adm2_code"])

# Write Parquet (ZSTD compressed, DuckDB-ready)
tbl = pa.Table.from_pandas(df, preserve_index=False)
pq.write_table(tbl, "data.parquet", compression="zstd")
print(f"Written: {len(df):,} rows, {os.path.getsize('data.parquet')/1e6:.1f} MB")
```

---

## Task Monitoring

```python
import ee, time
ee.Initialize(project="growth-foundry-seo")

task_ids = ["TASK_ID_1", "TASK_ID_2"]

while True:
    tasks = ee.batch.Task.list()
    running = 0
    for t in tasks:
        s = t.status()
        if s["task_id"] in task_ids or s["description"] in watched_names:
            print(f"  {s['description']:45} {s['state']}")
            if s["state"] not in ("COMPLETED", "FAILED", "CANCELLED"):
                running += 1
    if running == 0:
        break
    time.sleep(60)
```

### Check latest task status (quick):
```python
import ee
ee.Initialize(project="growth-foundry-seo")
for t in ee.batch.Task.list()[:10]:
    s = t.status()
    print(f"  {s['description'][:45]:45}  {s['state']:12}  {s.get('error_message','')}")
```

---

## Common Errors and Fixes

| Error | Cause | Fix |
|---|---|---|
| `Image has no bands` | Year with no images in collection → `.median()` on empty collection | Add `ee.Algorithms.If(filtered.size().gt(0), ...)` guard |
| All reducer values are null in CSV | Selectors name columns that don't exist in GEE output | Test `result.first().getInfo()['properties'].keys()` before setting selectors |
| `403 Project not registered` | GEE project not enabled for Earth Engine | Go to https://console.cloud.google.com/earth-engine/configuration |
| `DefaultCredentialsError` | `google.auth.default()` used instead of EE credentials | Use `ee.oauth.get_credentials_arguments()` pattern (see Step 2) |
| GEE task FAILED with memory error | tileScale too low for high-resolution | Increase tileScale (250m → 8, 30m → 16) |
| Duplicate rows in export | `flatten()` issue or multiple features per admin2 | Check boundary collection for overlapping geometries |

---

## Existing GEE Panels (maestro warehouse)

| Slug | Source | Years | Variables | Status |
|---|---|---|---|---|
| `global-ntl-admin2-panel` | DMSP-OLS + VIIRS DNB | 1992-2026 | ntl_mean, ntl_median, ntl_p90 | data.parquet ✓ |
| `global-ndvi-admin2-panel` | MODIS MOD13Q1 250m | 2000-2026 | ndvi_mean, ndvi_median, evi_mean, evi_median | GEE running |
| `global-lst-admin2-panel` | MODIS MOD11A2 1km | 2000-2026 | lst_day_mean_c, lst_night_mean_c, diurnal_range | GEE running |

All panels: FAO GAUL 2015 level-2, 38,258 admin2 units, annual frequency.
GEE project: `growth-foundry-seo`
Drive folder: `maestro-gee-exports`

---

## Integration with maestro-dataset

After building data.parquet, follow the maestro-dataset SOP:

```bash
# 1. Write README.md (YAML frontmatter + body sections)
# acquisition.method: "gee"
# acquisition.steps: ["python3 scripts/01_gee_export.py", "python3 scripts/02_build.py"]

# 2. Generate codebook.xlsx
# 3. Generate version.json with sha256_parquet
# 4. Validate
maestro-warehouse validate global-ndvi-admin2-panel

# 5. Update catalog
maestro-warehouse catalog
```

Key frontmatter fields for GEE datasets:
```yaml
acquisition:
  method: "gee"
  reproducible: true
  steps:
    - "python3 scripts/01_gee_export.py  # submits GEE batch task → Google Drive"
    - "python3 scripts/02_build.py       # downloads CSV, builds parquet + metadata"
  notes: "GEE project: growth-foundry-seo. Auth: earthengine authenticate."
```

---

## Quality Control

Before finalizing a GEE panel, always verify:

```python
import pandas as pd
df = pd.read_parquet("data.parquet")

# 1. Check non-null rates
print(df.notna().mean())

# 2. Spot-check known values
sg = df[(df["adm0_name"]=="Singapore") & (df["year"]==2020)]
print(sg[["ndvi_mean","evi_mean"]])
# NDVI Singapore 2020 should be ~0.4-0.6

# 3. Check year coverage
print(df.groupby("year").size())  # should be ~38258 per year

# 4. Check value ranges
print(df[["ndvi_mean","evi_mean"]].describe())
# NDVI should be [-0.2, 1.0]; flag if outside
```

---

## Dependencies

```bash
pip install earthengine-api google-api-python-client google-auth \
            pyarrow duckdb pandas openpyxl
```

Required in `~/.config/earthengine/credentials` (created by `earthengine authenticate`).

---

## Gotchas

- **Export task quota**: 3000 concurrent tasks max. Batch exports need throttling.
- **scale parameter affects aggregation**: `ee.Reducer` results change with scale. Always set explicitly.
- **ee.Image.clip() doesn't reduce pixel count**: clip is cosmetic, use filterBounds for performance.
- **Midnight UTC boundary**: Daily composites may split across calendar days depending on timezone.
