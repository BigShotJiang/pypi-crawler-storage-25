# reghdfe Alignment Guide

Technical reference for replicating Stata's reghdfe in Python.
Verified against Ramadan replication: all coefficients exact match, SE <1% diff.

---

## 1. What reghdfe Does

reghdfe (Correia 2017) performs OLS with multiple sets of fixed effects by:
1. Iteratively demean Y and X by each FE group (Method of Alternating Projections)
2. Remove singleton observations (groups with only 1 obs in any FE)
3. Compute DOF correction using connected-component analysis of FE interactions
4. Report "within R-squared" (R2 after demeaning, not overall R2)

---

## 2. Two Approaches in Python

### Approach A: Explicit Dummies (Recommended for small-medium data)

```python
import numpy as np
import pandas as pd
import statsmodels.api as sm


def remove_singletons(data, fe_vars):
    """Iteratively remove observations where any FE group has count=1.

    Must iterate because removing singletons from one FE may create
    new singletons in another FE.
    """
    remaining = data.copy()
    total_dropped = 0
    while True:
        n_before = len(remaining)
        for fv in fe_vars:
            counts = remaining[fv].value_counts()
            singletons = counts[counts == 1].index
            remaining = remaining[~remaining[fv].isin(singletons)]
        n_dropped = n_before - len(remaining)
        total_dropped += n_dropped
        if n_dropped == 0:
            break
    return remaining, total_dropped


def reghdfe_ols(data, yvar, xvars, fe_vars, vcov='HC1'):
    """Replicate reghdfe using explicit FE dummies.

    Returns statsmodels OLS result. Coefficients on xvars will exactly
    match reghdfe. SE will differ by <1% due to DOF correction.

    Args:
        data: DataFrame
        yvar: dependent variable name
        xvars: list of regressor names (excluding FE)
        fe_vars: list of categorical variable names to absorb
        vcov: covariance type ('HC1' for robust)
    """
    all_needed = [yvar] + xvars + fe_vars
    clean = data.dropna(subset=all_needed).copy()

    # Step 1: Remove singletons
    clean, n_dropped = remove_singletons(clean, fe_vars)
    if n_dropped > 0:
        print(f'  Singleton removal: dropped {n_dropped} obs -> N={len(clean)}')

    # Step 2: Build design matrix with FE dummies
    parts = [clean[xvars].astype(float)]
    for fv in fe_vars:
        dummies = pd.get_dummies(clean[fv], prefix=fv, drop_first=True, dtype=float)
        parts.append(dummies)

    X = sm.add_constant(pd.concat(parts, axis=1))
    y = clean[yvar].astype(float)

    # Step 3: Estimate with HC1
    result = sm.OLS(y, X).fit(cov_type=vcov)
    return result
```

### Approach B: linearmodels.AbsorbingLS (Better for large FE)

```python
from linearmodels.iv import AbsorbingLS
import statsmodels.api as sm


def reghdfe_absorbing(data, yvar, xvars, fe_vars):
    """Replicate reghdfe using linearmodels.AbsorbingLS.

    Uses iterative demeaning (like reghdfe). Handles large FE efficiently.
    """
    all_needed = [yvar] + xvars + fe_vars
    clean = data.dropna(subset=all_needed).copy()
    clean, _ = remove_singletons(clean, fe_vars)

    y = clean[yvar].astype(float)
    X = sm.add_constant(clean[xvars].astype(float))

    # Build absorb DataFrame
    absorb_df = pd.DataFrame(index=clean.index)
    for fv in fe_vars:
        absorb_df[fv] = pd.Categorical(clean[fv].astype(int))

    model = AbsorbingLS(
        dependent=y,
        exog=X,
        absorb=absorb_df,
        drop_absorbed=True,
    )
    return model.fit(cov_type='robust', debiased=True)
```

---

## 3. Singleton Detection Algorithm

reghdfe removes singletons iteratively. This matters because:
- A singleton in FE group A is perfectly collinear with its group dummy
- Removing it may create new singletons in FE group B
- The process must repeat until no new singletons are found

**Ramadan example**: N goes from 277 to 274 (3 singletons removed).
These are students who are the only one in their class/parent_educ combination.

The `remove_singletons` function above implements this correctly.

---

## 4. DOF Correction (Why SE Differs)

### The Problem

reghdfe computes degrees of freedom as:
```
k_absorbed = sum(n_levels_i - 1) - redundant_FE
```

where `redundant_FE` comes from connected-component analysis of the FE
interaction graph. This accounts for FE groups that are perfectly nested
(e.g., if every class has the same male/female composition).

### Explicit Dummies Approach

With explicit dummies:
```
k_total = k_regressors + sum(n_levels_i - 1) + 1 (constant)
```

This does NOT subtract redundant FE, so the DOF is slightly different:
```
DOF_explicit = N - k_total
DOF_reghdfe  = N - k_regressors - 1 - k_absorbed
             = N - k_total + redundant_FE
```

### SE Ratio

Since HC1 SE scales as sqrt(N / DOF):
```
SE_explicit / SE_reghdfe = sqrt(DOF_reghdfe / DOF_explicit)
                         = sqrt(1 - redundant_FE / DOF_explicit)
```

For the Ramadan data (N=274, ~20 FE dummies), this ratio is ~0.99,
giving <1% SE difference.

---

## 5. R-squared: Within vs Overall

| Measure | What it is | When reghdfe reports it |
|---------|-----------|------------------------|
| Within R2 | R2 after demeaning Y and X by FE groups | Default `reghdfe` output |
| Overall R2 | R2 from the full model including FE dummies | Explicit dummies approach |
| Adjusted R2 | Overall R2 with DOF penalty | `reghdfe, a2(R2a)` option |

**Critical**: reghdfe's reported R2 is within R2. Explicit dummies give overall R2.
Overall R2 >= Within R2 always.

In the Ramadan replication, overall R2 (0.233) matches Stata's reported R2
because Stata's esttab was configured to report overall R2 via the `r2` option.

To compute within R2 in Python:

```python
def within_r2(y, X, fe_vars, data):
    """Compute within R-squared (FE-demeaned)."""
    y_demean = y.copy()
    X_demean = X.copy()
    for fv in fe_vars:
        groups = data[fv]
        y_demean = y_demean - y_demean.groupby(groups).transform('mean')
        for col in X_demean.columns:
            X_demean[col] = X_demean[col] - X_demean[col].groupby(groups).transform('mean')
    result = sm.OLS(y_demean, X_demean).fit()
    return result.rsquared
```

---

## 6. Verified Comparison (Ramadan Table 1)

```
Model 2: reghdfe gap T4 if group>2, absorb(i.class male i.parent_educ ...)

Variable    Stata coef   Python coef   Coef diff   Stata SE   Python SE   SE diff(%)
T4          -2.1985      -2.1985       0.0000      0.7451     0.7432      0.26%

Model 4: reghdfe gap T4 religious2 T4_fast, absorb(...)

Variable    Stata coef   Python coef   Coef diff   Stata SE   Python SE   SE diff(%)
T4          -0.8654      -0.8654       0.0000      1.0935     1.0916      0.17%
religious2   2.9742       2.9742       0.0000      1.0753     1.0735      0.17%
T4_fast     -2.5483      -2.5483       0.0000      1.5348     1.5323      0.16%
```

Result: Coefficients are exact (4+ decimal places). SE differs by <0.3%.

---

## 7. Decision Tree

```
Q: How many FE levels total?
  < 500:  Use Approach A (explicit dummies). Simpler, exact coefficient match.
  >= 500: Use Approach B (AbsorbingLS). Memory-efficient.

Q: Do you need exact SE match with Stata?
  No:  Either approach. <1% difference is acceptable for publication.
  Yes: Implement connected-component DOF correction (complex, rarely needed).

Q: Which R2 to report?
  Match Stata: Check what esttab option was used (r2 vs r2_within).
  New paper:   Report within R2 for HDFE columns, overall R2 for OLS columns.
               Note the difference in table footnotes.
```

---

## 8. Common Pitfalls

1. **Forgetting singleton removal**: Coefficients will be slightly wrong
   and N will not match. Always remove singletons first.

2. **Categorical encoding**: FE variables must be treated as categorical,
   not continuous. `pd.get_dummies(drop_first=True)` for explicit approach.
   `pd.Categorical()` for AbsorbingLS.

3. **Variable moved from absorb to explicit**: When a variable that was
   absorbed now interacts with treatment, it must move to the explicit
   regressors. (Ramadan: `religious2` absorbed in Col 2, explicit in Col 4.)

4. **HC1 vs default SE**: reghdfe with `, robust` uses HC1. Plain OLS in
   Stata uses homoskedastic SE. Match the SE type exactly.

5. **Constant term**: reghdfe absorbs the constant. Explicit dummies include
   it via `sm.add_constant()`. The constant is not comparable between methods.
