# Publication-Ready Table Standards

LaTeX table format matching esttab output. Verified against actual Ramadan
replication (Table 1: 4-column progressive specification).

---

## 1. Complete LaTeX Template

```latex
\begin{table}[H]
\centering
\caption{Effect of Treatment on Outcome}
\begin{tabular}{lcccc}
\hline\hline
 & (1) & (2) & (3) & (4) \\
 & Outcome & Outcome & Outcome & Outcome \\
\hline
Treatment & -1.9032*** & -2.1985*** & -0.5822 & -0.8654 \\
 & (0.7387) & (0.7451) & (1.0672) & (1.0935) \\

Moderator &  &  & 2.5805** & 2.9742*** \\
 &  &  & (1.0425) & (1.0753) \\

Treatment $\times$ Moderator &  &  & -2.6181* & -2.5483* \\
 &  &  & (1.4617) & (1.5348) \\

\hline
Mean of Control & -24.395 & -24.395 & -24.395 & -24.395 \\
Entity FE & No & Yes & No & Yes \\
Control Variables & No & Yes & No & Yes \\
N & 277 & 274 & 277 & 274 \\
R-squared & 0.024 & 0.233 & 0.045 & 0.242 \\
\hline\hline
\multicolumn{5}{l}{\footnotesize Robust standard errors in parentheses.} \\
\multicolumn{5}{l}{\footnotesize *** p$<$0.01, ** p$<$0.05, * p$<$0.1} \\
\end{tabular}
\end{table}
```

---

## 2. Formatting Rules

| Element | Format | Example |
|---------|--------|---------|
| Coefficients | 4 decimal places | `-1.9032***` |
| Standard errors | 4 decimal places, parenthesized | `(0.7387)` |
| Mean of Control | 3 decimal places | `-24.395` |
| Control SD | 3 decimal places | `12.456` |
| R-squared | 3 decimal places | `0.024` |
| N | Integer, comma-separated if >999 | `1,234` |
| FE indicators | "Yes" / "No" | `Yes` |
| Significance | Stars right-adjacent to coefficient | `-1.9032***` |

Star thresholds:
- `***` : p < 0.01
- `**`  : p < 0.05
- `*`   : p < 0.10

---

## 3. Bottom Block Structure

Order matters. This is the standard bottom block from esttab:

```
\hline
Mean of Control    &  X.XXX  &  X.XXX  &  X.XXX  &  X.XXX  \\
Control SD         &  X.XXX  &  X.XXX  &  X.XXX  &  X.XXX  \\
Entity FE          &  No     &  Yes    &  No     &  Yes     \\
Time FE            &  No     &  No     &  Yes    &  Yes     \\
Controls           &  No     &  Yes    &  No     &  Yes     \\
N                  &  X,XXX  &  X,XXX  &  X,XXX  &  X,XXX  \\
R-squared          &  X.XXX  &  X.XXX  &  X.XXX  &  X.XXX  \\
\hline\hline
```

Rules:
- Mean of Control: compute from the control group only, not full sample
- Control SD: standard deviation of outcome in control group
- FE rows: one row per type of FE (entity, time, demographic)
- N: must match the actual regression N (after dropping missing + singletons)
- R-squared: overall R2 for OLS, within R2 for reghdfe (note which is reported)

---

## 4. Python Generation Function

```python
def stars(p):
    if p < 0.01: return '***'
    if p < 0.05: return '**'
    if p < 0.10: return '*'
    return ''


def generate_esttab_latex(results, var_order, labels, bottom_stats,
                          title='', dep_var_label='Outcome', ncols=None):
    """Generate publication-ready LaTeX table from regression results.

    Args:
        results: list of statsmodels/linearmodels result objects
        var_order: list of variable names to display (in order)
        labels: dict mapping variable names to display labels
        bottom_stats: list of (label, values_list) for bottom block
        title: table caption
        dep_var_label: dependent variable label for column headers
        ncols: override number of columns
    """
    n = ncols or len(results)
    col_nums = ' & '.join(f'({i+1})' for i in range(n))
    col_labels = ' & '.join([dep_var_label] * n)

    lines = [
        r'\begin{table}[H]',
        r'\centering',
        f'\\caption{{{title}}}',
        r'\begin{tabular}{l' + 'c' * n + '}',
        r'\hline\hline',
        f' & {col_nums} \\\\',
        f' & {col_labels} \\\\',
        r'\hline',
    ]

    # Coefficient rows
    for var in var_order:
        label = labels.get(var, var)
        coef_cells = []
        se_cells = []
        for res in results:
            if _has_var(res, var):
                c, s, p = _extract(res, var)
                coef_cells.append(f'{c:.4f}{stars(p)}')
                se_cells.append(f'({s:.4f})')
            else:
                coef_cells.append('')
                se_cells.append('')
        lines.append(f'{label} & ' + ' & '.join(coef_cells) + r' \\')
        lines.append(' & ' + ' & '.join(se_cells) + r' \\')
        lines.append('')  # blank line between variables

    # Bottom block
    lines.append(r'\hline')
    for stat_label, stat_values in bottom_stats:
        cells = [str(v) for v in stat_values]
        lines.append(f'{stat_label} & ' + ' & '.join(cells) + r' \\')

    lines.append(r'\hline\hline')
    lines.append(r'\multicolumn{' + str(n+1) + r'}{l}{\footnotesize Robust standard errors in parentheses.} \\')
    lines.append(r'\multicolumn{' + str(n+1) + r'}{l}{\footnotesize *** p$<$0.01, ** p$<$0.05, * p$<$0.1} \\')
    lines.append(r'\end{tabular}')
    lines.append(r'\end{table}')

    return '\n'.join(lines)


def _has_var(res, var):
    """Check if variable exists in result."""
    if hasattr(res, 'params'):
        return var in res.params.index if hasattr(res.params, 'index') else var in res.params
    return False


def _extract(res, var):
    """Extract coef, se, pval from OLS or AbsorbingLS result."""
    if hasattr(res, 'std_errors'):
        # linearmodels AbsorbingLS
        return res.params[var], res.std_errors[var], res.pvalues[var]
    else:
        # statsmodels OLS
        return res.params[var], res.bse[var], res.pvalues[var]
```

---

## 5. Usage Example (from Ramadan replication)

```python
# Build bottom block
ctrl_mean = sample.loc[sample['group'] == 3, 'gap'].mean()
bottom = [
    ('Mean of Control', [f'{ctrl_mean:.3f}'] * 4),
    ('Class FE', ['No', 'Yes', 'No', 'Yes']),
    ('Control Variables', ['No', 'Yes', 'No', 'Yes']),
    ('N', [int(r.nobs) for r in [m1, m2, m3, m4]]),
    ('R-squared', [f'{r.rsquared:.3f}' for r in [m1, m2, m3, m4]]),
]

tex = generate_esttab_latex(
    results=[m1, m2, m3, m4],
    var_order=['T4', 'religious2', 'T4_fast'],
    labels={'T4': 'Exemption', 'religious2': 'Fast',
            'T4_fast': r'Exemption $\times$ Fast'},
    bottom_stats=bottom,
    title='Effect of Exemption on Performance Gap',
    dep_var_label='Gap',
)
Path('table1.tex').write_text(tex)
```

---

## 6. Multi-Panel Tables (JEBO style)

When outcomes span multiple domains, use grouped column headers:

```latex
\begin{tabular}{lcccccc}
\hline\hline
 & \multicolumn{3}{c}{MPL 1 (1) - (3)} & \multicolumn{3}{c}{MPL 2 (4) - (6)} \\
 & (1) & (2) & (3) & (4) & (5) & (6) \\
Dep. var. & Risk Neutral & Risk Loving & Risk Averse & Risk Neutral & Risk Loving & Risk Averse \\
\hline
```

Rule: When each column is a different outcome (not a different specification),
use `\multicolumn` headers to group related outcomes. The specification stays
constant across columns.

---

## 7. Common Mistakes to Avoid

1. Reporting overall R2 when reghdfe reports within R2 (or vice versa)
2. Using different decimal precision for coefficients vs scalars
3. Missing the control mean (reviewers will ask for it)
4. Not explaining N differences across columns (singleton removal, missing data)
5. Stars without a note defining the thresholds
6. Using `\hline` once instead of `\hline\hline` for top/bottom rules
