#!/usr/bin/env python3
"""Universal climate raster -> admin-unit panel builder.

Supports NetCDF (.nc, .nc.gz) and GeoTIFF inputs. Computes zonal mean
for each admin polygon at each time step, producing a long-format CSV.

Usage:
    # Monthly panel from CRU TS:
    python3 grid_to_admin.py \
        --raster ~/Dropbox/datasets/cru-ts-407/raw/cru_ts4.07.1901.2022.tmp.dat.nc.gz \
        --variable tmp \
        --admin ~/Dropbox/datasets/boundaries/natural-earth/ne_10m_admin_0_countries.shp \
        --admin-id ADM0_A3 --admin-name ADMIN \
        --output ~/Dropbox/datasets/global-country-climate-panel/work/data_tmp.csv

    # GeoTIFF cross-section (WorldClim):
    python3 grid_to_admin.py \
        --raster ~/Dropbox/datasets/worldclim-v21-bio/raw/wc2.1_10m_bio_1.tif \
        --variable bio1 --geotiff \
        --admin ~/Dropbox/datasets/boundaries/natural-earth/ne_10m_admin_0_countries.shp \
        --admin-id ADM0_A3 --admin-name ADMIN \
        --output ~/Dropbox/datasets/worldclim-admin1-crosssection/work/bio1.csv
"""

import argparse
import gzip
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import geopandas as gpd
import xarray as xr
import rasterio
from rasterio.transform import from_origin
from rasterstats import zonal_stats


def load_admin(path: str, id_col: str, name_col: str,
               layer: str = None) -> gpd.GeoDataFrame:
    """Load admin boundary file, reproject to WGS84, select columns."""
    kwargs = {}
    if layer is not None:
        kwargs['layer'] = layer

    gdf = gpd.read_file(path, **kwargs)

    if id_col not in gdf.columns:
        print(f"Error: column '{id_col}' not found. "
              f"Available: {list(gdf.columns)}", file=sys.stderr)
        sys.exit(1)
    if name_col not in gdf.columns:
        print(f"Error: column '{name_col}' not found. "
              f"Available: {list(gdf.columns)}", file=sys.stderr)
        sys.exit(1)

    if len(gdf) > 50000:
        print(f"Warning: {len(gdf)} features loaded. Processing may be slow.",
              file=sys.stderr)

    # Reproject to WGS84 if needed
    if gdf.crs is not None and gdf.crs.to_epsg() != 4326:
        gdf = gdf.to_crs(epsg=4326)

    gdf = gdf[[id_col, name_col, 'geometry']].copy()
    gdf = gdf.rename(columns={id_col: 'admin_id', name_col: 'admin_name'})
    return gdf


def build_transform(da):
    """Build rasterio Affine transform from xarray DataArray coords.

    Assumes lat is north-up (descending). Reorders if needed.
    Returns (arr, transform) where arr is a 2D float32 numpy array.
    """
    # Ensure north-up lat ordering
    if float(da.lat.values[0]) < float(da.lat.values[-1]):
        da = da.reindex(lat=da.lat[::-1])

    lats = da.lat.values.astype(float)
    lons = da.lon.values.astype(float)

    dlat = abs(float(lats[0] - lats[1]))
    dlon = abs(float(lons[1] - lons[0]))

    # Origin is top-left corner of the top-left pixel
    west = float(lons[0]) - dlon / 2
    north = float(lats[0]) + dlat / 2

    transform = from_origin(west, north, dlon, dlat)
    arr = da.values.astype(np.float32)

    return arr, transform


def replace_nodata(arr, ds, variable: str):
    """Replace missing/fill values with NaN."""
    da = ds[variable]
    for attr_name in ('missing_value', '_FillValue'):
        val = da.attrs.get(attr_name)
        if val is not None:
            arr[arr == float(val)] = np.nan
    return arr


def open_netcdf(raster_path: str):
    """Open NetCDF, decompressing .nc.gz to a temp file if needed.

    netCDF4 engine cannot read gzipped files directly. Returns (dataset, tmp_path)
    where tmp_path is None if no decompression was needed.
    """
    if raster_path.endswith('.nc.gz'):
        # Check if decompressed version already exists alongside
        nc_path = raster_path[:-3]  # strip .gz
        if Path(nc_path).exists():
            print(f"  Using decompressed file: {nc_path}", file=sys.stderr)
            ds = xr.open_dataset(nc_path, engine='netcdf4')
            return ds, None
        print("  Decompressing .nc.gz to temp file...", file=sys.stderr)
        tmp = tempfile.NamedTemporaryFile(suffix='.nc', delete=False)
        with gzip.open(raster_path, 'rb') as f_in:
            shutil.copyfileobj(f_in, tmp)
        tmp.close()
        ds = xr.open_dataset(tmp.name, engine='netcdf4')
        return ds, tmp.name
    else:
        ds = xr.open_dataset(raster_path, engine='netcdf4')
        return ds, None


def process_netcdf(raster_path: str, variable: str, gdf: gpd.GeoDataFrame,
                   aggregate: str, year_start: int, year_end: int) -> pd.DataFrame:
    """Process a NetCDF file, compute zonal stats per time step."""
    ds, tmp_path = open_netcdf(raster_path)

    if variable not in ds:
        print(f"Error: variable '{variable}' not found. "
              f"Available: {list(ds.data_vars)}", file=sys.stderr)
        sys.exit(1)

    times = pd.to_datetime(ds['time'].values)

    # Filter by year range
    if year_start is not None:
        mask = times.year >= year_start
        times = times[mask]
    if year_end is not None:
        mask = times.year <= year_end
        times = times[mask]

    if len(times) == 0:
        print("Error: no time steps in the specified year range.", file=sys.stderr)
        sys.exit(1)

    rows = []
    n_admin = len(gdf)

    for t in times:
        year = t.year
        month = t.month

        if month == 1:
            print(f"  Processing year {year}...", file=sys.stderr)

        da = ds[variable].sel(time=t)
        arr, transform = build_transform(da)
        arr = replace_nodata(arr, ds, variable)

        stats = zonal_stats(
            gdf.geometry, arr,
            affine=transform, stats=['mean'],
            nodata=np.nan, all_touched=False
        )

        for i in range(n_admin):
            val = stats[i]['mean']
            rows.append({
                'admin_id': gdf.iloc[i]['admin_id'],
                'admin_name': gdf.iloc[i]['admin_name'],
                'year': year,
                'month': month,
                variable: round(val, 4) if val is not None else None,
            })

    ds.close()
    if tmp_path is not None:
        Path(tmp_path).unlink(missing_ok=True)

    df = pd.DataFrame(rows)

    if aggregate == 'annual_mean':
        df = (df.groupby(['admin_id', 'admin_name', 'year'])[variable]
              .mean().reset_index())
    elif aggregate == 'annual_sum':
        df = (df.groupby(['admin_id', 'admin_name', 'year'])[variable]
              .sum().reset_index())
    # else 'monthly' — keep as-is

    return df


def process_geotiff(raster_path: str, variable: str,
                    gdf: gpd.GeoDataFrame) -> pd.DataFrame:
    """Process a single GeoTIFF, compute zonal stats (cross-section)."""
    with rasterio.open(raster_path) as src:
        arr = src.read(1).astype(np.float32)
        transform = src.transform
        nodata = src.nodata
        if nodata is not None:
            arr[arr == nodata] = np.nan

    stats = zonal_stats(
        gdf.geometry, arr,
        affine=transform, stats=['mean'],
        nodata=np.nan, all_touched=False
    )

    rows = []
    for i in range(len(gdf)):
        val = stats[i]['mean']
        rows.append({
            'admin_id': gdf.iloc[i]['admin_id'],
            'admin_name': gdf.iloc[i]['admin_name'],
            variable: round(val, 4) if val is not None else None,
        })

    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(
        description='Universal climate raster -> admin-unit panel builder'
    )
    parser.add_argument('--raster', required=True,
                        help='Path to raster file (NetCDF or GeoTIFF)')
    parser.add_argument('--variable', required=True,
                        help='Variable name (e.g. tmp, pre, bio1)')
    parser.add_argument('--admin', required=True,
                        help='Path to admin boundary file (SHP, GPKG, GeoJSON)')
    parser.add_argument('--admin-id', default='GID_0',
                        help='Column name for admin unit ID (default: GID_0)')
    parser.add_argument('--admin-name', default='NAME_0',
                        help='Column name for admin unit name (default: NAME_0)')
    parser.add_argument('--output', required=True,
                        help='Path to output CSV')
    parser.add_argument('--aggregate', default='monthly',
                        choices=['monthly', 'annual_mean', 'annual_sum'],
                        help='Temporal aggregation (default: monthly)')
    parser.add_argument('--geotiff', action='store_true',
                        help='Treat input as GeoTIFF instead of NetCDF')
    parser.add_argument('--year-start', type=int, default=None,
                        help='Start year filter (inclusive)')
    parser.add_argument('--year-end', type=int, default=None,
                        help='End year filter (inclusive)')
    parser.add_argument('--layer', default=None,
                        help='Layer name for GPKG files (e.g. gadm_410)')

    args = parser.parse_args()

    raster_path = str(Path(args.raster).expanduser())
    admin_path = str(Path(args.admin).expanduser())
    output_path = Path(args.output).expanduser()

    if not Path(raster_path).exists():
        print(f"Error: raster file not found: {raster_path}", file=sys.stderr)
        sys.exit(1)
    if not Path(admin_path).exists():
        print(f"Error: admin file not found: {admin_path}", file=sys.stderr)
        sys.exit(1)

    print(f"Loading admin boundaries from {admin_path}...", file=sys.stderr)
    gdf = load_admin(admin_path, args.admin_id, args.admin_name, args.layer)
    print(f"  {len(gdf)} admin units loaded.", file=sys.stderr)

    if args.geotiff:
        print(f"Processing GeoTIFF: {raster_path}", file=sys.stderr)
        df = process_geotiff(raster_path, args.variable, gdf)
    else:
        print(f"Processing NetCDF: {raster_path}", file=sys.stderr)
        df = process_netcdf(raster_path, args.variable, gdf,
                            args.aggregate, args.year_start, args.year_end)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(str(output_path), index=False)
    print(f"Saved {output_path} ({len(df)} rows)", file=sys.stderr)


if __name__ == '__main__':
    main()
