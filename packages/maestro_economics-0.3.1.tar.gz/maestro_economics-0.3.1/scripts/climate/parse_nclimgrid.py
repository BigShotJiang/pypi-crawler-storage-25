#!/usr/bin/env python3
"""Parse NOAA nClimDiv county-level climate data to long-format CSV.

nClimDiv distributes monthly climate data as fixed-width text files.
Each row contains a state-division code, element type, year, and 12 monthly
values plus an annual value. Temperature is in degrees F, precipitation in
inches. This script converts to metric (C, mm).

Input format (nClimDiv county-level):
    Columns: fips_code (5), element (2), year (4), then 12 space-separated
             monthly values (Jan-Dec).
    Element codes: 01=pcpn, 02=tavg, 27=tmax, 28=tmin, ...

Usage:
    python3 parse_nclimgrid.py \
        --input ~/Dropbox/datasets/us-county-climate-panel/raw/climdiv-tmpccy-v1.0.0-20260201 \
        --output ~/Dropbox/datasets/us-county-climate-panel/work/tavg.csv

    python3 parse_nclimgrid.py \
        --input ~/Dropbox/datasets/us-county-climate-panel/raw/ \
        --output ~/Dropbox/datasets/us-county-climate-panel/work/nclimgrid_all.csv
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd


# NOAA nClimDiv element codes
ELEMENT_MAP = {
    '01': 'pcpn',
    '02': 'tavg',
    '05': 'tmax',  # some files use 05
    '06': 'tmin',  # some files use 06
    '25': 'pdsi',
    '26': 'phdi',
    '27': 'tmax',
    '28': 'tmin',
    '71': 'sp01',  # SPI-1
    '72': 'sp02',
}

MONTH_NAMES = ['jan', 'feb', 'mar', 'apr', 'may', 'jun',
               'jul', 'aug', 'sep', 'oct', 'nov', 'dec']

MISSING_VALUES = {-99.99, -99.90, -9.99, 9999.0, -9999.0, 99.99}


def f_to_c(f: float) -> float:
    """Convert Fahrenheit to Celsius."""
    return (f - 32.0) * 5.0 / 9.0


def inches_to_mm(inches: float) -> float:
    """Convert inches to millimeters."""
    return inches * 25.4


def is_missing(val: float) -> bool:
    """Check if value is a missing data sentinel."""
    return any(abs(val - m) < 0.01 for m in MISSING_VALUES)


def parse_nclimgrid_line(line: str) -> dict:
    """Parse a single nClimDiv county-level fixed-width record.

    Format: FIPS(5) + element(2) + year(4) + 12 space-separated monthly values.
    FIPS = 5-digit county code (2 state + 3 county).
    """
    stripped = line.strip()
    if len(stripped) < 20:
        return None

    try:
        fips_code = stripped[0:5]
        element_code = stripped[5:7]
        year = int(stripped[7:11])
    except (ValueError, IndexError):
        return None

    element = ELEMENT_MAP.get(element_code, f'elem_{element_code}')
    state_code = fips_code[0:2]
    county_code = fips_code[2:5]

    # Monthly values are space-separated after position 11
    val_str = stripped[11:]
    parts = val_str.split()

    values = []
    for p in parts[:12]:
        try:
            values.append(float(p))
        except ValueError:
            values.append(np.nan)

    return {
        'state_code': state_code,
        'county_code': county_code,
        'fips_code': fips_code,
        'element': element,
        'year': year,
        'monthly': values,
    }


def parse_file(filepath: Path) -> list:
    """Parse a single nClimDiv file into long-format records."""
    rows = []

    with open(filepath, 'r') as f:
        for line in f:
            rec = parse_nclimgrid_line(line)
            if rec is None:
                continue

            element = rec['element']
            is_temp = element in ('tavg', 'tmax', 'tmin')
            is_precip = element == 'pcpn'

            for month_idx, raw_val in enumerate(rec['monthly']):
                if is_missing(raw_val) or np.isnan(raw_val):
                    val = np.nan
                elif is_temp:
                    val = round(f_to_c(raw_val), 2)
                elif is_precip:
                    val = round(inches_to_mm(raw_val), 2)
                else:
                    val = round(raw_val, 2)

                rows.append({
                    'fips_code': rec['fips_code'],
                    'state_code': rec['state_code'],
                    'county_code': rec['county_code'],
                    'year': rec['year'],
                    'month': month_idx + 1,
                    'variable': element,
                    'value': val,
                })

    return rows


def main():
    parser = argparse.ArgumentParser(
        description='Parse NOAA nClimDiv county climate data to long CSV'
    )
    parser.add_argument('--input', required=True,
                        help='Path to nClimDiv file or directory of files')
    parser.add_argument('--output', required=True,
                        help='Path to output CSV')
    parser.add_argument('--elements', nargs='*', default=None,
                        help='Filter to specific elements (e.g. tavg pcpn)')

    args = parser.parse_args()
    input_path = Path(args.input).expanduser()
    output_path = Path(args.output).expanduser()

    if not input_path.exists():
        print(f"Error: input not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    # Collect files to parse
    if input_path.is_dir():
        files = sorted(input_path.glob('*'))
        files = [f for f in files if f.is_file() and not f.name.startswith('.')]
    else:
        files = [input_path]

    all_rows = []
    for filepath in files:
        print(f"  Parsing {filepath.name}...", file=sys.stderr)
        rows = parse_file(filepath)
        all_rows.extend(rows)
        print(f"    {len(rows)} records", file=sys.stderr)

    if not all_rows:
        print("Error: no records parsed.", file=sys.stderr)
        sys.exit(1)

    df = pd.DataFrame(all_rows)

    # Filter elements if requested
    if args.elements:
        df = df[df['variable'].isin(args.elements)]

    # Sort for clean output
    df = df.sort_values(['fips_code', 'variable', 'year', 'month'])

    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(str(output_path), index=False)

    n_units = df['fips_code'].nunique()
    year_range = f"{df['year'].min()}-{df['year'].max()}"
    elements = df['variable'].unique().tolist()
    print(f"Saved {output_path} ({len(df)} rows, {n_units} units, "
          f"{year_range}, vars: {elements})", file=sys.stderr)


if __name__ == '__main__':
    main()
