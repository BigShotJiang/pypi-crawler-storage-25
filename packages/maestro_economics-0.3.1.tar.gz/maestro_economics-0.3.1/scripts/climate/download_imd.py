#!/usr/bin/env python3
"""Download IMD (India Meteorological Department) gridded climate data.

Uses imdlib to download and convert to NetCDF.

Usage:
    python3 download_imd.py --var rain --start 1990 --end 2020 \\
        --output-dir ~/Dropbox/datasets/india-district-climate-panel/raw/
"""

import argparse
import sys
from pathlib import Path

try:
    import imdlib
except ImportError:
    print("Error: imdlib not installed. Run: pip3 install imdlib", file=sys.stderr)
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description='Download IMD gridded climate data via imdlib'
    )
    parser.add_argument('--var', required=True, choices=['rain', 'tmax', 'tmin'],
                        help='Variable: rain, tmax, or tmin')
    parser.add_argument('--start', type=int, required=True,
                        help='Start year')
    parser.add_argument('--end', type=int, required=True,
                        help='End year (inclusive)')
    parser.add_argument('--output-dir', type=str,
                        default='~/Dropbox/datasets/india-district-climate-panel/raw/',
                        help='Output directory')
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"IMD: downloading {args.var} for {args.start}-{args.end}",
          file=sys.stderr)
    print(f"  Output dir: {output_dir}", file=sys.stderr)

    # Download raw binary files
    data = imdlib.get_data(
        args.var,
        args.start,
        args.end,
        fn_format='yearwise',
        file_dir=str(output_dir),
    )

    # Convert to xarray and save as NetCDF
    ds = data.get_xarray()
    nc_path = output_dir / f'imd_{args.var}_{args.start}_{args.end}.nc'
    ds.to_netcdf(str(nc_path))

    size_mb = nc_path.stat().st_size / 1e6
    print(f"Saved NetCDF: {nc_path} ({size_mb:.1f} MB)", file=sys.stderr)
    print("Done.", file=sys.stderr)


if __name__ == '__main__':
    main()
