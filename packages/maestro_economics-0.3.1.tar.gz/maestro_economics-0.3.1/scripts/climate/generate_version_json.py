#!/usr/bin/env python3
"""
generate_version_json.py — Generate version.json metadata for a climate dataset.

Usage:
    python3 generate_version_json.py \
        --data ~/Dropbox/datasets/global-country-climate-panel/data.csv \
        --dataset-id global-country-climate-panel \
        --dataset-name "Global Country Climate Panel" \
        --sources "CRU TS v4.07" "Natural Earth" \
        --output-dir ~/Dropbox/datasets/global-country-climate-panel/
"""

import argparse
import json
import sys
import os
from datetime import date
import pandas as pd


def main():
    parser = argparse.ArgumentParser(
        description='Generate version.json metadata for a climate dataset.'
    )
    parser.add_argument('--data', required=True, help='Path to panel CSV')
    parser.add_argument('--dataset-id', required=True, help='Dataset slug identifier')
    parser.add_argument('--dataset-name', required=True, help='Human-readable dataset name')
    parser.add_argument('--sources', nargs='+', required=True,
                        help='Data source names (e.g., "CRU TS v4.07" "Natural Earth")')
    parser.add_argument('--version', default='1.0.0', help='Semantic version (default: 1.0.0)')
    parser.add_argument('--output-dir', required=True, help='Output directory for version.json')
    args = parser.parse_args()

    data_path = os.path.expanduser(args.data)
    output_dir = os.path.expanduser(args.output_dir)

    if not os.path.exists(data_path):
        print(f"ERROR: file not found: {data_path}", file=sys.stderr)
        sys.exit(1)

    df = pd.read_csv(data_path)

    # Determine time coverage
    has_year = 'year' in df.columns
    has_month = 'month' in df.columns
    if has_year:
        start_year = int(df['year'].min())
        end_year = int(df['year'].max())
        frequency = 'monthly' if has_month else 'annual'
    else:
        start_year = None
        end_year = None
        frequency = 'cross-section'

    # Determine spatial coverage
    entity_col = None
    for candidate in ['admin_id', 'GID_0', 'GID_1', 'GID_2', 'ISO_A3', 'ADM0_A3']:
        if candidate in df.columns:
            entity_col = candidate
            break
    n_entities = df[entity_col].nunique() if entity_col else len(df)

    # Entity type inference
    if entity_col in ('GID_2',):
        entity_type = 'admin2 (district)'
    elif entity_col in ('GID_1',):
        entity_type = 'admin1 (state/province)'
    else:
        entity_type = 'admin unit'

    # Missing rates for climate columns
    key_cols = {'admin_id', 'admin_name', 'year', 'month', 'GID_0', 'GID_1',
                'GID_2', 'NAME_0', 'NAME_1', 'NAME_2', 'ISO_A3', 'ADM0_A3'}
    climate_cols = [c for c in df.columns if c not in key_cols]
    missing_rates = {}
    for col in climate_cols:
        if df[col].dtype in ['float64', 'float32', 'int64', 'int32']:
            pct = round(100.0 * df[col].isna().sum() / len(df), 2) if len(df) > 0 else 0.0
            missing_rates[col] = pct

    # Build version.json
    version_data = {
        'dataset_id': args.dataset_id,
        'dataset_name': args.dataset_name,
        'version': args.version,
        'created_date': date.today().isoformat(),
        'created_by': 'Maestro AI RA Data',
        'time_coverage': {
            'start': start_year,
            'end': end_year,
            'frequency': frequency,
        },
        'spatial_coverage': {
            'entities': n_entities,
            'entity_type': entity_type,
        },
        'observations': {
            'total': len(df),
            'columns': list(df.columns),
        },
        'data_sources': [{'name': s} for s in args.sources],
        'quality_flags': {
            'missing_rates': missing_rates,
        },
        'license': 'Derived dataset \u2014 Maestro AI. Source data licenses apply.',
    }

    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, 'version.json')
    with open(output_path, 'w') as f:
        json.dump(version_data, f, indent=2, ensure_ascii=False)

    print(f'version.json written: {output_path}', file=sys.stderr)
    print(f'  {n_entities} entities, {len(df):,} observations', file=sys.stderr)
    if start_year:
        print(f'  Time: {start_year}-{end_year} ({frequency})', file=sys.stderr)


if __name__ == '__main__':
    main()
