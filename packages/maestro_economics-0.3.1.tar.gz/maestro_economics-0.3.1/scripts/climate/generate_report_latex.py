#!/usr/bin/env python3
"""
generate_report_latex.py — Generate a XeLaTeX quality report with charts for a climate panel.

Usage:
    python3 generate_report_latex.py \
        --data ~/Dropbox/datasets/global-country-climate-panel/data.csv \
        --dataset-name "Global Country Climate Panel" \
        --dataset-id global-country-climate-panel \
        --source "CRU TS v4.07" \
        --output-dir ~/Dropbox/datasets/global-country-climate-panel/

Generates:
  - charts/coverage_heatmap_{var}.png
  - charts/trend_{var}.png
  - report.tex
  - report.pdf (compiled via xelatex or pdflatex fallback)
"""

import argparse
import os
import sys
import subprocess
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def setup_matplotlib():
    """Configure matplotlib for publication-quality figures."""
    try:
        plt.rcParams['font.family'] = 'serif'
        plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    except Exception:
        pass
    plt.rcParams['font.size'] = 10
    plt.rcParams['axes.titlesize'] = 12
    plt.rcParams['figure.dpi'] = 300
    plt.rcParams['savefig.dpi'] = 300
    plt.rcParams['savefig.bbox'] = 'tight'


def generate_coverage_heatmap(df, var, entity_col, charts_dir, max_entities=100):
    """Generate coverage heatmap: entity x year, colored by data presence."""
    if var not in df.columns or 'year' not in df.columns:
        return None

    # Aggregate: fraction of months with non-null data per entity-year
    if 'month' in df.columns:
        agg = df.groupby([entity_col, 'year'])[var].apply(
            lambda x: x.notna().sum() / len(x)
        ).reset_index()
        agg.columns = [entity_col, 'year', 'coverage']
    else:
        agg = df.groupby([entity_col, 'year'])[var].apply(
            lambda x: float(x.notna().any())
        ).reset_index()
        agg.columns = [entity_col, 'year', 'coverage']

    pivot = agg.pivot(index=entity_col, columns='year', values='coverage')

    # Sample entities if too many
    if len(pivot) > max_entities:
        pivot = pivot.sample(max_entities, random_state=42).sort_index()

    fig, ax = plt.subplots(figsize=(max(8, len(pivot.columns) * 0.15), max(4, len(pivot) * 0.12)))
    im = ax.imshow(pivot.values, aspect='auto', cmap='RdYlGn', vmin=0, vmax=1,
                   interpolation='nearest')

    # Axis labels
    years = pivot.columns.tolist()
    n_ticks = min(20, len(years))
    step = max(1, len(years) // n_ticks)
    ax.set_xticks(range(0, len(years), step))
    ax.set_xticklabels([str(years[i]) for i in range(0, len(years), step)],
                       rotation=45, ha='right', fontsize=7)
    ax.set_yticks([])
    ax.set_ylabel(f'{entity_col} ({len(pivot)} entities)', fontsize=9)
    ax.set_title(f'Data Coverage: {var}', fontsize=11)

    cbar = fig.colorbar(im, ax=ax, shrink=0.8)
    cbar.set_label('Coverage fraction', fontsize=9)

    out_path = os.path.join(charts_dir, f'coverage_heatmap_{var}.png')
    fig.savefig(out_path)
    plt.close(fig)
    return out_path


def generate_trend_plot(df, var, charts_dir):
    """Generate global annual mean time series."""
    if var not in df.columns or 'year' not in df.columns:
        return None

    annual = df.groupby('year')[var].mean()
    if annual.dropna().empty:
        return None

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(annual.index, annual.values, color='#2F5496', linewidth=1.5)
    ax.set_xlabel('Year')
    ax.set_ylabel(var)
    ax.set_title(f'Annual Mean: {var}')
    ax.grid(True, alpha=0.3)

    out_path = os.path.join(charts_dir, f'trend_{var}.png')
    fig.savefig(out_path)
    plt.close(fig)
    return out_path


def generate_latex(dataset_name, dataset_id, source, df, charts_dir, output_dir, entity_col):
    """Generate report.tex."""
    climate_cols = [c for c in df.columns
                    if c not in {entity_col, 'admin_name', 'year', 'month',
                                 'NAME_0', 'NAME_1', 'NAME_2', 'GID_0', 'GID_1', 'GID_2'}]

    n_entities = df[entity_col].nunique() if entity_col in df.columns else 0
    year_range = ''
    if 'year' in df.columns:
        year_range = f"{int(df['year'].min())}--{int(df['year'].max())}"

    # Summary stats table rows
    stats_rows = []
    for col in climate_cols:
        if df[col].dtype not in [np.float64, np.float32, np.int64, np.int32]:
            continue
        valid = df[col].dropna()
        if len(valid) == 0:
            continue
        missing_pct = 100.0 * df[col].isna().sum() / len(df)
        stats_rows.append(
            f"    {col} & {valid.mean():.2f} & {valid.std():.2f} & "
            f"{valid.min():.2f} & {valid.max():.2f} & {missing_pct:.1f}\\% \\\\"
        )

    stats_table = '\n'.join(stats_rows)

    # Figure includes
    figure_blocks = []
    for col in climate_cols:
        heatmap = os.path.join(charts_dir, f'coverage_heatmap_{col}.png')
        trend = os.path.join(charts_dir, f'trend_{col}.png')
        if os.path.exists(heatmap):
            figure_blocks.append(f"""
\\begin{{figure}}[htbp]
  \\centering
  \\includegraphics[width=0.95\\textwidth]{{charts/coverage_heatmap_{col}.png}}
  \\caption{{Data coverage heatmap for \\texttt{{{col}}}. Green indicates full monthly coverage; red indicates missing data.}}
  \\label{{fig:coverage_{col}}}
\\end{{figure}}
""")
        if os.path.exists(trend):
            figure_blocks.append(f"""
\\begin{{figure}}[htbp]
  \\centering
  \\includegraphics[width=0.85\\textwidth]{{charts/trend_{col}.png}}
  \\caption{{Annual mean trend for \\texttt{{{col}}}.}}
  \\label{{fig:trend_{col}}}
\\end{{figure}}
""")

    figures_tex = '\n'.join(figure_blocks)

    tex = f"""\\documentclass[11pt,a4paper]{{article}}

% Try fontspec (XeLaTeX); fall back gracefully for pdflatex
\\usepackage{{ifxetex}}
\\ifxetex
  \\usepackage{{fontspec}}
  \\setmainfont{{Times New Roman}}
\\else
  \\usepackage[T1]{{fontenc}}
  \\usepackage{{mathptmx}}
\\fi

\\usepackage{{graphicx}}
\\usepackage{{booktabs}}
\\usepackage{{geometry}}
\\usepackage{{hyperref}}
\\usepackage{{xcolor}}

\\geometry{{margin=1in}}
\\hypersetup{{colorlinks=true,linkcolor=blue!60!black,urlcolor=blue!60!black}}

\\title{{\\textbf{{Data Quality Report}} \\\\ \\large {dataset_name}}}
\\author{{Maestro AI RA Data}}
\\date{{\\today}}

\\begin{{document}}
\\maketitle

\\section{{Overview}}

This report documents the quality and coverage of the \\textbf{{{dataset_name}}} dataset
(ID: \\texttt{{{dataset_id}}}).

\\begin{{itemize}}
  \\item \\textbf{{Source}}: {source}
  \\item \\textbf{{Entities}}: {n_entities:,} administrative units
  \\item \\textbf{{Time coverage}}: {year_range}
  \\item \\textbf{{Observations}}: {len(df):,} rows, {len(df.columns)} columns
  \\item \\textbf{{Climate variables}}: {', '.join(climate_cols)}
\\end{{itemize}}

\\section{{Summary Statistics}}

\\begin{{table}}[htbp]
\\centering
\\caption{{Descriptive statistics for climate variables.}}
\\begin{{tabular}}{{lrrrrr}}
\\toprule
Variable & Mean & Std Dev & Min & Max & Missing \\\\
\\midrule
{stats_table}
\\bottomrule
\\end{{tabular}}
\\end{{table}}

\\section{{Coverage and Trends}}

{figures_tex}

\\section{{Notes}}

\\begin{{itemize}}
  \\item All temperatures are in degrees Celsius (\\textdegree{{C}}).
  \\item Precipitation values are in millimeters (mm).
  \\item Coverage heatmaps show the fraction of months with valid data per entity-year cell.
  \\item Missing rates below 5\\% are considered acceptable for most econometric applications.
\\end{{itemize}}

\\end{{document}}
"""

    tex_path = os.path.join(output_dir, 'report.tex')
    with open(tex_path, 'w') as f:
        f.write(tex)
    return tex_path


def compile_latex(output_dir):
    """Compile report.tex to PDF. Try xelatex first, fall back to pdflatex."""
    tex_path = os.path.join(output_dir, 'report.tex')

    for engine in ['xelatex', 'pdflatex']:
        if shutil.which(engine) is None:
            continue
        print(f'  Compiling with {engine}...', file=sys.stderr)
        for run in range(2):
            result = subprocess.run(
                [engine, '-interaction=nonstopmode', '-output-directory', output_dir, tex_path],
                capture_output=True, text=True, cwd=output_dir
            )
        pdf_path = os.path.join(output_dir, 'report.pdf')
        if os.path.exists(pdf_path):
            print(f'  PDF generated: {pdf_path}', file=sys.stderr)
            return pdf_path
        else:
            print(f'  WARNING: {engine} did not produce PDF', file=sys.stderr)

    print('  WARNING: no LaTeX engine found; report.tex written but not compiled', file=sys.stderr)
    return None


def main():
    parser = argparse.ArgumentParser(
        description='Generate a XeLaTeX quality report with charts for a climate panel.'
    )
    parser.add_argument('--data', required=True, help='Path to panel CSV')
    parser.add_argument('--dataset-name', required=True, help='Human-readable dataset name')
    parser.add_argument('--dataset-id', required=True, help='Dataset slug identifier')
    parser.add_argument('--source', required=True, help='Primary data source name')
    parser.add_argument('--output-dir', required=True, help='Output directory')
    parser.add_argument('--entity-col', default='admin_id', help='Entity column (default: admin_id)')
    args = parser.parse_args()

    data_path = os.path.expanduser(args.data)
    output_dir = os.path.expanduser(args.output_dir)

    if not os.path.exists(data_path):
        print(f"ERROR: file not found: {data_path}", file=sys.stderr)
        sys.exit(1)

    setup_matplotlib()

    print(f'Generating report: {args.dataset_name}', file=sys.stderr)
    df = pd.read_csv(data_path)

    # Create charts directory
    charts_dir = os.path.join(output_dir, 'charts')
    os.makedirs(charts_dir, exist_ok=True)

    entity_col = args.entity_col
    climate_cols = [c for c in df.columns
                    if c not in {entity_col, 'admin_name', 'year', 'month',
                                 'NAME_0', 'NAME_1', 'NAME_2', 'GID_0', 'GID_1', 'GID_2'}]

    # Generate charts
    for col in climate_cols:
        if df[col].dtype not in [np.float64, np.float32, np.int64, np.int32]:
            continue
        print(f'  Generating charts for {col}...', file=sys.stderr)
        generate_coverage_heatmap(df, col, entity_col, charts_dir)
        generate_trend_plot(df, col, charts_dir)

    # Generate LaTeX
    tex_path = generate_latex(args.dataset_name, args.dataset_id, args.source,
                              df, charts_dir, output_dir, entity_col)
    print(f'  LaTeX written: {tex_path}', file=sys.stderr)

    # Compile
    compile_latex(output_dir)

    print('Done.', file=sys.stderr)


if __name__ == '__main__':
    main()
