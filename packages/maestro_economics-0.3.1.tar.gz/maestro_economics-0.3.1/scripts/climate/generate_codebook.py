#!/usr/bin/env python3
"""
generate_codebook.py — Generate a styled codebook.xlsx from a climate panel CSV.

Usage:
    python3 generate_codebook.py \
        --data ~/Dropbox/datasets/global-country-climate-panel/data.csv \
        --dataset-name "Global Country Climate Panel" \
        --output ~/Dropbox/datasets/global-country-climate-panel/codebook.xlsx
"""

import argparse
import sys
import os
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


VARIABLE_METADATA = {
    'admin_id': {
        'type': 'String',
        'description': 'Administrative unit identifier',
        'unit': '\u2014',
        'source': 'GADM v4.1 / Natural Earth',
    },
    'admin_name': {
        'type': 'String',
        'description': 'Administrative unit name (English)',
        'unit': '\u2014',
        'source': 'GADM v4.1',
    },
    'year': {
        'type': 'Integer',
        'description': 'Calendar year',
        'unit': 'Year',
        'source': '\u2014',
    },
    'month': {
        'type': 'Integer',
        'description': 'Calendar month (1=January, 12=December)',
        'unit': 'Month',
        'source': '\u2014',
    },
    'temp_mean_c': {
        'type': 'Float',
        'description': 'Monthly mean air temperature',
        'unit': '\u00b0C',
        'source': 'CRU TS v4.07 / ERA5 / IMD',
    },
    'temp_max_c': {
        'type': 'Float',
        'description': 'Monthly mean daily maximum temperature',
        'unit': '\u00b0C',
        'source': 'CRU TS v4.07 / IMD',
    },
    'temp_min_c': {
        'type': 'Float',
        'description': 'Monthly mean daily minimum temperature',
        'unit': '\u00b0C',
        'source': 'CRU TS v4.07 / IMD',
    },
    'precip_mm': {
        'type': 'Float',
        'description': 'Total monthly precipitation',
        'unit': 'mm',
        'source': 'CRU TS v4.07 / CHIRPS / IMD / ERA5',
    },
    'pet_mm': {
        'type': 'Float',
        'description': 'Potential evapotranspiration (Penman-Monteith)',
        'unit': 'mm',
        'source': 'CRU TS v4.07',
    },
}

# WorldClim bioclimatic variable descriptions
BIOCLIM_NAMES = {
    'bio1': 'Annual Mean Temperature',
    'bio2': 'Mean Diurnal Range',
    'bio3': 'Isothermality (BIO2/BIO7 x 100)',
    'bio4': 'Temperature Seasonality (std x 100)',
    'bio5': 'Max Temperature of Warmest Month',
    'bio6': 'Min Temperature of Coldest Month',
    'bio7': 'Temperature Annual Range (BIO5-BIO6)',
    'bio8': 'Mean Temperature of Wettest Quarter',
    'bio9': 'Mean Temperature of Driest Quarter',
    'bio10': 'Mean Temperature of Warmest Quarter',
    'bio11': 'Mean Temperature of Coldest Quarter',
    'bio12': 'Annual Precipitation',
    'bio13': 'Precipitation of Wettest Month',
    'bio14': 'Precipitation of Driest Month',
    'bio15': 'Precipitation Seasonality (CV)',
    'bio16': 'Precipitation of Wettest Quarter',
    'bio17': 'Precipitation of Driest Quarter',
    'bio18': 'Precipitation of Warmest Quarter',
    'bio19': 'Precipitation of Coldest Quarter',
}

BIOCLIM_UNITS = {
    'bio1': '\u00b0C', 'bio2': '\u00b0C', 'bio3': '%', 'bio4': '\u00b0C x100',
    'bio5': '\u00b0C', 'bio6': '\u00b0C', 'bio7': '\u00b0C', 'bio8': '\u00b0C',
    'bio9': '\u00b0C', 'bio10': '\u00b0C', 'bio11': '\u00b0C',
    'bio12': 'mm', 'bio13': 'mm', 'bio14': 'mm', 'bio15': 'CV',
    'bio16': 'mm', 'bio17': 'mm', 'bio18': 'mm', 'bio19': 'mm',
}


def get_variable_info(col_name):
    """Get metadata for a column, auto-generating for bioclim vars."""
    if col_name in VARIABLE_METADATA:
        return VARIABLE_METADATA[col_name]
    if col_name in BIOCLIM_NAMES:
        return {
            'type': 'Float',
            'description': f'{BIOCLIM_NAMES[col_name]} (WorldClim {col_name.upper()})',
            'unit': BIOCLIM_UNITS.get(col_name, '\u2014'),
            'source': 'WorldClim v2.1',
        }
    return {
        'type': 'Unknown',
        'description': col_name,
        'unit': '\u2014',
        'source': '\u2014',
    }


def main():
    parser = argparse.ArgumentParser(
        description='Generate a styled codebook.xlsx from a climate panel CSV.'
    )
    parser.add_argument('--data', required=True, help='Path to panel CSV')
    parser.add_argument('--dataset-name', required=True, help='Dataset name for title row')
    parser.add_argument('--output', required=True, help='Output .xlsx path')
    args = parser.parse_args()

    data_path = os.path.expanduser(args.data)
    output_path = os.path.expanduser(args.output)

    df = pd.read_csv(data_path)

    wb = Workbook()
    ws = wb.active
    ws.title = 'Codebook'

    # Styles
    header_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
    header_font = Font(name='Calibri', bold=True, color='FFFFFF', size=11)
    title_font = Font(name='Calibri', bold=True, size=14, color='2F5496')
    alt_fill = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')
    thin_border = Border(
        left=Side(style='thin', color='B0B0B0'),
        right=Side(style='thin', color='B0B0B0'),
        top=Side(style='thin', color='B0B0B0'),
        bottom=Side(style='thin', color='B0B0B0'),
    )

    # Title row
    ws.merge_cells('A1:G1')
    title_cell = ws['A1']
    title_cell.value = f'Codebook: {args.dataset_name}'
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal='left', vertical='center')
    ws.row_dimensions[1].height = 30

    # Subtitle row
    ws.merge_cells('A2:G2')
    ws['A2'].value = f'{len(df):,} observations, {len(df.columns)} variables'
    ws['A2'].font = Font(name='Calibri', size=10, color='666666')
    ws.row_dimensions[2].height = 20

    # Header row
    headers = ['Variable', 'Type', 'Description', 'Unit', 'Range', 'Missing %', 'Source']
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=4, column=col_idx, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = thin_border
    ws.row_dimensions[4].height = 25

    # Data rows
    for i, col_name in enumerate(df.columns):
        row_idx = 5 + i
        info = get_variable_info(col_name)

        # Compute range and missing % from data
        if df[col_name].dtype in ['float64', 'float32', 'int64', 'int32']:
            valid = df[col_name].dropna()
            if len(valid) > 0:
                range_str = f'[{valid.min():.2f}, {valid.max():.2f}]'
            else:
                range_str = '\u2014'
        else:
            n_unique = df[col_name].nunique()
            range_str = f'{n_unique:,} unique'

        n_missing = df[col_name].isna().sum()
        pct_missing = 100.0 * n_missing / len(df) if len(df) > 0 else 0.0
        missing_str = f'{pct_missing:.1f}%'

        values = [col_name, info['type'], info['description'],
                  info['unit'], range_str, missing_str, info['source']]

        for col_idx, val in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.font = Font(name='Calibri', size=10)
            cell.border = thin_border
            cell.alignment = Alignment(vertical='center', wrap_text=(col_idx == 3))
            if i % 2 == 1:
                cell.fill = alt_fill

    # Column widths
    col_widths = [18, 10, 50, 12, 22, 12, 35]
    for idx, width in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    # Save
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)
    print(f'Codebook written: {output_path}', file=sys.stderr)
    print(f'  {len(df.columns)} variables documented', file=sys.stderr)


if __name__ == '__main__':
    main()
