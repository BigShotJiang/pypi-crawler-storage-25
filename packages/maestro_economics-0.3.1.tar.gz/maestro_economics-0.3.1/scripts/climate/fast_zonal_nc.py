#!/usr/bin/env python3
"""Fast zonal statistics for NetCDF -> admin-unit panel.

Pre-rasterizes admin polygons once, then uses numpy masked arrays
for O(1) lookups per time step. ~100x faster than rasterstats per-step.

Usage:
    python3 fast_zonal_nc.py \
        --raster udel_tmp.nc --variable tmp \
        --admin ne_10m_admin_0_countries.shp \
        --admin-id ADM0_A3 --admin-name ADMIN \
        --output data_tmp.csv
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import geopandas as gpd
import xarray as xr
from rasterio.transform import from_origin
from rasterio.features import rasterize


def main():
    parser = argparse.ArgumentParser(description='Fast zonal stats for NetCDF')
    parser.add_argument('--raster', required=True)
    parser.add_argument('--variable', required=True)
    parser.add_argument('--admin', required=True)
    parser.add_argument('--admin-id', default='ADM0_A3')
    parser.add_argument('--admin-name', default='NAME_0')
    parser.add_argument('--output', required=True)
    parser.add_argument('--aggregate', default='monthly',
                        choices=['monthly', 'annual_mean', 'annual_sum'])
    args = parser.parse_args()

    raster_path = str(Path(args.raster).expanduser())
    admin_path = str(Path(args.admin).expanduser())
    output_path = Path(args.output).expanduser()

    # Load admin boundaries
    print(f"Loading admin boundaries...", file=sys.stderr)
    gdf = gpd.read_file(admin_path)
    if gdf.crs is not None and gdf.crs.to_epsg() != 4326:
        gdf = gdf.to_crs(epsg=4326)
    gdf = gdf[[args.admin_id, args.admin_name, 'geometry']].copy()
    gdf = gdf.rename(columns={args.admin_id: 'admin_id', args.admin_name: 'admin_name'})
    print(f"  {len(gdf)} admin units loaded.", file=sys.stderr)

    # Open NetCDF
    print(f"Opening NetCDF: {raster_path}", file=sys.stderr)
    ds = xr.open_dataset(raster_path, engine='netcdf4')
    da = ds[args.variable]

    # Ensure north-up lat ordering
    if float(da.lat.values[0]) < float(da.lat.values[-1]):
        da = da.reindex(lat=da.lat[::-1])

    lats = da.lat.values.astype(float)
    lons = da.lon.values.astype(float)
    nrows, ncols = len(lats), len(lons)
    dlat = abs(float(lats[0] - lats[1]))
    dlon = abs(float(lons[1] - lons[0]))
    west = float(lons[0]) - dlon / 2
    north = float(lats[0]) + dlat / 2
    transform = from_origin(west, north, dlon, dlat)

    # Rasterize admin polygons: each pixel gets an admin index (0-based)
    print("Rasterizing admin polygons (one-time)...", file=sys.stderr)
    shapes = []
    admin_ids = []
    admin_names = []
    for idx, row in gdf.iterrows():
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue
        shapes.append((geom, len(admin_ids)))
        admin_ids.append(row['admin_id'])
        admin_names.append(row['admin_name'])

    n_admin = len(admin_ids)
    admin_raster = rasterize(
        shapes,
        out_shape=(nrows, ncols),
        transform=transform,
        fill=-1,
        dtype=np.int32,
        all_touched=False
    )
    print(f"  Rasterized {n_admin} polygons onto {nrows}x{ncols} grid.", file=sys.stderr)

    # Pre-compute pixel masks for each admin unit
    masks = {}
    for i in range(n_admin):
        mask = admin_raster == i
        if mask.any():
            masks[i] = mask

    print(f"  {len(masks)} admin units have raster coverage.", file=sys.stderr)

    # Process all time steps
    times = pd.to_datetime(da.time.values)
    n_times = len(times)
    print(f"Processing {n_times} time steps...", file=sys.stderr)

    rows = []
    for t_idx, t in enumerate(times):
        year = t.year
        month = t.month

        if month == 1:
            print(f"  Year {year} ({t_idx}/{n_times})...", file=sys.stderr)

        # Load one time slice as numpy array
        arr = da.isel(time=t_idx).values.astype(np.float32)

        for i in range(n_admin):
            mask = masks.get(i)
            if mask is None:
                rows.append({
                    'admin_id': admin_ids[i],
                    'admin_name': admin_names[i],
                    'year': year,
                    'month': month,
                    args.variable: None,
                })
                continue

            vals = arr[mask]
            valid = vals[~np.isnan(vals)]
            mean_val = float(np.mean(valid)) if len(valid) > 0 else None

            rows.append({
                'admin_id': admin_ids[i],
                'admin_name': admin_names[i],
                'year': year,
                'month': month,
                args.variable: round(mean_val, 4) if mean_val is not None else None,
            })

    ds.close()
    df = pd.DataFrame(rows)

    if args.aggregate == 'annual_mean':
        df = (df.groupby(['admin_id', 'admin_name', 'year'])[args.variable]
              .mean().reset_index())
    elif args.aggregate == 'annual_sum':
        df = (df.groupby(['admin_id', 'admin_name', 'year'])[args.variable]
              .sum().reset_index())

    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(str(output_path), index=False)
    print(f"Saved {output_path} ({len(df)} rows)", file=sys.stderr)


if __name__ == '__main__':
    main()
