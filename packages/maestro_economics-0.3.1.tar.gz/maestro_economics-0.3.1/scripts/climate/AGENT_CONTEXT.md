# Climate Scripts — Agent Context

## Python env
- Python 3.9.6 at /usr/bin/python3
- All packages installed: xarray, rasterio, rasterstats, rioxarray, geopandas, imdlib, cdsapi, openpyxl, tqdm, fiona, shapely
- Use: python3 (system), pip3 for installs
- urllib3 warning is harmless (NotOpenSSLWarning) — suppress with PYTHONWARNINGS=ignore

## Key Data Paths

### Boundaries
- Country level (258 countries): ~/Dropbox/datasets/boundaries/natural-earth/ne_10m_admin_0_countries.shp
  - ID col: ISO_A3 (some are -99 for disputed), NAME col: ADMIN
  - For scripts, prefer ADM0_A3 col (always 3-char, no -99 cases)
- GADM global (all levels): ~/Dropbox/datasets/boundaries/gadm/gadm_410.gpkg, layer='gadm_410'
  - Has 356508 features, cols: GID_0, NAME_0, GID_1, NAME_1, GID_2, NAME_2 etc.
  - ADM0 (country): filter where GID_1 is null/empty
  - ADM1: filter where GID_1 notnull and GID_2 is null
  - ADM2 (district): filter where GID_2 notnull
- India district: ~/Dropbox/datasets/boundaries/gadm/IND/gadm41_IND_2.shp (extracted)
  - 676 districts, cols: GID_2, GID_0, COUNTRY, GID_1, NAME_1, NL_NAME_1, NAME_2, VARNAME_2
  - Use --admin-id GID_2 --admin-name NAME_2 for grid_to_admin.py
- Natural Earth admin1: ~/Dropbox/datasets/boundaries/natural-earth/ne_10m_admin_1_states_provinces.*
  - 4,596 admin1 units, cols: adm1_code (unique, 0 nulls), name, iso_a2, iso_3166_2
  - Use --admin-id adm1_code --admin-name name for grid_to_admin.py
- Africa subset: ~/Dropbox/datasets/boundaries/africa_countries.gpkg (55 countries, admin_id/admin_name cols)

### Climate Data
- CRU TS v4.07 (gzipped NetCDF — use decompressed .nc, NOT .nc.gz):
  - tmp: ~/Dropbox/datasets/cru-ts-407/raw/cru_ts4.07.1901.2022.tmp.dat.nc (2.8GB, decompressed)
  - pre: ~/Dropbox/datasets/cru-ts-407/raw/cru_ts4.07.1901.2022.pre.dat.nc (2.8GB, decompressed)
  - xr.open_dataset(path, engine='netcdf4') — use .nc path, NOT .nc.gz
- UDEL v5.01 (tar.gz, must convert via udel_to_netcdf.py):
  - tmp: ~/Dropbox/datasets/udel-climate-v501/air_temp_2017.tar.gz (246MB)
  - pre: ~/Dropbox/datasets/udel-climate-v501/precip_2017.tar.gz (271MB)
- WorldClim v2.1 GeoTIFF (already extracted):
  - ~/Dropbox/datasets/worldclim-v21-bio/raw/wc2.1_10m_bio_1.tif ... wc2.1_10m_bio_19.tif
  - ~/Dropbox/datasets/worldclim-v21-bio/raw/wc2.1_10m_tavg_01.tif ... tavg_12.tif
  - ~/Dropbox/datasets/worldclim-v21-bio/raw/wc2.1_10m_prec_01.tif ... prec_12.tif

### Output Dirs
- ~/Dropbox/datasets/global-country-climate-panel/
- ~/Dropbox/datasets/worldclim-admin1-crosssection/
- ~/Dropbox/datasets/africa-country-climate-panel/
- ~/Dropbox/datasets/india-district-climate-panel/
- ~/Dropbox/datasets/us-county-climate-panel/
- ~/Dropbox/datasets/chirps-monthly-global/raw/ (CHIRPS downloads go here)

## Bug Fixes & Format Corrections (verified 2026-03-04)

### CRU TS .nc.gz: netCDF4 cannot read gzipped files directly
- `xr.open_dataset('...nc.gz', engine='netcdf4')` throws "Unknown file format"
- Must decompress first: `gunzip -k file.nc.gz` or use `open_netcdf()` helper in grid_to_admin.py
- Decompressed .nc files already exist alongside .nc.gz (~2.8GB each)
- CRU TS lat goes -89.75 to 89.75 (south-to-north) — grid_to_admin.py handles reordering

### nClimDiv county format (5-char FIPS, NOT 4-char divisional)
- County files (`*cy*`): FIPS(5) + element_code(2) + year(4) = 11 chars, then 12 space-separated monthly values
- FIPS: first 2 chars = state_code, next 3 chars = county division code
- Missing value sentinel = **-99.90** (NOT -9999 or -99.99). Appears for future months in current year.
- Element codes: 01=pcpn, 02=tavg, 27=tmax, 28=tmin
- Units: temperature in Fahrenheit, precipitation in inches. parse_nclimgrid.py converts to C/mm.

### WorldClim v2.1 GeoTIFF: BIO1-11 already in degrees C
- v2.1 GeoTIFF format stores temperature BIO variables directly in degrees C
- build_panel.py UNIT_CONVERSIONS has x0.1 multiplier for bio1-11 — this is WRONG for v2.1 GeoTIFF
- For WorldClim cross-sections, bypass build_panel.py and merge with direct pandas merge (no conversion needed)
- bio1 correct range: ~-37 to ~30 C (Antarctica to tropics)

### grid_to_admin.py vs fast_zonal_nc.py
- grid_to_admin.py: universal but slow for large NetCDF time series (re-reads polygons each timestep)
- fast_zonal_nc.py: pre-rasterizes polygons once, ~30 seconds vs 24+ hours for 258 countries x 1416 months
- USE fast_zonal_nc.py for large NetCDF panels (CRU TS, UDEL, ERA5, CHIRPS)
- USE grid_to_admin.py for GeoTIFF cross-sections (WorldClim) — fast enough for single-timestep files

## CRU TS xarray usage
```python
import xarray as xr
# MUST use decompressed .nc file (not .nc.gz)
ds = xr.open_dataset(
    '~/Dropbox/datasets/cru-ts-407/raw/cru_ts4.07.1901.2022.tmp.dat.nc',
    engine='netcdf4'
)
# Variable name is 'tmp' for temperature, 'pre' for precipitation
# Coords: time, lat, lon (lat goes from -89.75 to 89.75 — SOUTH to NORTH)
```

## xarray DeprecationWarning
Use `ds[var].values` not `ds[var].data` for numpy arrays in older xarray.

## rasterstats usage
```python
from rasterstats import zonal_stats
results = zonal_stats(
    gdf,           # GeoDataFrame (WGS84)
    arr,           # 2D numpy float32 array, north-up
    affine=transform,  # rasterio.transform.Affine
    stats=['mean'],
    nodata=np.nan,
    all_touched=False
)
```

## GADM ADM0 extraction
```python
import geopandas as gpd
g = gpd.read_file('/Users/ding/Dropbox/datasets/boundaries/gadm/gadm_410.gpkg', layer='gadm_410')
# Get country level only:
adm0 = g[g['GID_1'].isna()][['GID_0','NAME_0','geometry']].copy()
# OR use Natural Earth (simpler):
ne = gpd.read_file('~/Dropbox/datasets/boundaries/natural-earth/ne_10m_admin_0_countries.shp')
# Use ADM0_A3 as ID, ADMIN as name
```

## IMPORTANT: Output dir is ~/maestro/maestro-skills/climate/scripts/
All scripts go there. Check TaskList after completing each task.
