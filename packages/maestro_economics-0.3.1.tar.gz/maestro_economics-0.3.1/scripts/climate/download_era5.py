#!/usr/bin/env python3
"""Download ERA5 monthly-mean single-level reanalysis data via CDS API.

Requires ~/.cdsapirc with valid CDS credentials.

Usage:
    python3 download_era5.py --variables 2m_temperature total_precipitation \\
        --year-start 2000 --year-end 2020 \\
        --bbox 55 60 5 140 \\
        --output-dir ~/Dropbox/datasets/era5-monthly-global/raw/
"""

import argparse
import sys
from pathlib import Path

try:
    import cdsapi
except ImportError:
    print("Error: cdsapi not installed. Run: pip3 install cdsapi", file=sys.stderr)
    sys.exit(1)

VAR_SHORTNAMES = {
    '2m_temperature': 't2m',
    'total_precipitation': 'tp',
    '10m_u_component_of_wind': 'u10',
    '10m_v_component_of_wind': 'v10',
    'surface_pressure': 'sp',
    '2m_dewpoint_temperature': 'd2m',
    'surface_solar_radiation_downwards': 'ssrd',
    'total_cloud_cover': 'tcc',
}

ALL_MONTHS = [f'{m:02d}' for m in range(1, 13)]


def download_variable(client, variable: str, year: int,
                      bbox: list, output_dir: Path) -> None:
    """Download one variable for one year."""
    short = VAR_SHORTNAMES.get(variable, variable.replace(' ', '_'))
    outfile = output_dir / f'era5_{short}_{year}.nc'

    if outfile.exists():
        print(f"  Skip {outfile.name} (exists)", file=sys.stderr)
        return

    print(f"  Requesting ERA5 {variable} for {year}...", file=sys.stderr)

    request = {
        'product_type': ['monthly_averaged_reanalysis'],
        'variable': [variable],
        'year': [str(year)],
        'month': ALL_MONTHS,
        'time': ['00:00'],
        'data_format': 'netcdf',
    }

    if bbox:
        # CDS expects [N, W, S, E]
        request['area'] = bbox

    client.retrieve(
        'reanalysis-era5-single-levels-monthly-means',
        request,
        str(outfile),
    )

    size_mb = outfile.stat().st_size / 1e6
    print(f"  Saved {outfile.name} ({size_mb:.1f} MB)", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description='Download ERA5 monthly-mean single-level data via CDS API'
    )
    parser.add_argument('--variables', nargs='+', required=True,
                        help='ERA5 variable names (e.g. 2m_temperature)')
    parser.add_argument('--year-start', type=int, required=True,
                        help='Start year')
    parser.add_argument('--year-end', type=int, required=True,
                        help='End year (inclusive)')
    parser.add_argument('--bbox', nargs=4, type=float, default=None,
                        metavar=('N', 'W', 'S', 'E'),
                        help='Bounding box: North West South East')
    parser.add_argument('--output-dir', type=str,
                        default='~/Dropbox/datasets/era5-monthly-global/raw/',
                        help='Output directory')
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    client = cdsapi.Client()
    years = range(args.year_start, args.year_end + 1)

    print(f"ERA5: {len(args.variables)} variables x {len(list(years))} years",
          file=sys.stderr)

    for year in years:
        for variable in args.variables:
            try:
                download_variable(client, variable, year, args.bbox, output_dir)
            except Exception as e:
                print(f"  ERROR {variable} {year}: {e}", file=sys.stderr)

    print("Done.", file=sys.stderr)


if __name__ == '__main__':
    main()
