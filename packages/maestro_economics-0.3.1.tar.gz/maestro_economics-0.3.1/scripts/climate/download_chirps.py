#!/usr/bin/env python3
"""Batch download CHIRPS v2.0 annual NetCDF files.

Downloads monthly precipitation NetCDF files from CHC/UCSB, one file per year.
Skips files that already exist and are > 100MB.

Usage:
    python3 download_chirps.py --start 1981 --end 2023 --output-dir ~/Dropbox/datasets/chirps-monthly-global/raw/
"""

import argparse
import sys
from pathlib import Path

import requests
from tqdm import tqdm

URL_TEMPLATE = (
    'https://data.chc.ucsb.edu/products/CHIRPS-2.0/'
    'global_monthly/netcdf/byYear/chirps-v2.0.{year}.monthly.nc'
)

CHUNK_SIZE = 8 * 1024 * 1024  # 8 MB
MIN_SIZE = 100 * 1024 * 1024  # 100 MB


def download_year(year: int, output_dir: Path) -> None:
    """Download a single year's CHIRPS NetCDF file."""
    url = URL_TEMPLATE.format(year=year)
    filename = f'chirps-v2.0.{year}.monthly.nc'
    dest = output_dir / filename

    if dest.exists() and dest.stat().st_size > MIN_SIZE:
        print(f"  Skip {filename} (exists, {dest.stat().st_size / 1e6:.0f} MB)",
              file=sys.stderr)
        return

    print(f"  Downloading {filename}...", file=sys.stderr)
    resp = requests.get(url, stream=True, timeout=300)
    resp.raise_for_status()

    total = int(resp.headers.get('content-length', 0))
    with open(dest, 'wb') as f, tqdm(
        total=total, unit='B', unit_scale=True, desc=filename,
        file=sys.stderr,
    ) as pbar:
        for chunk in resp.iter_content(chunk_size=CHUNK_SIZE):
            f.write(chunk)
            pbar.update(len(chunk))

    size_mb = dest.stat().st_size / 1e6
    print(f"  Saved {filename} ({size_mb:.1f} MB)", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description='Download CHIRPS v2.0 annual monthly NetCDF files'
    )
    parser.add_argument('--start', type=int, default=1981,
                        help='Start year (default: 1981)')
    parser.add_argument('--end', type=int, default=2023,
                        help='End year inclusive (default: 2023)')
    parser.add_argument('--output-dir', type=str,
                        default='~/Dropbox/datasets/chirps-monthly-global/raw/',
                        help='Output directory')
    parser.add_argument('--concurrency', type=int, default=4,
                        help='Ignored (downloads sequentially for simplicity)')
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    years = list(range(args.start, args.end + 1))
    print(f"CHIRPS v2.0: downloading {len(years)} years "
          f"({args.start}-{args.end}) to {output_dir}", file=sys.stderr)

    for year in years:
        try:
            download_year(year, output_dir)
        except Exception as e:
            print(f"  ERROR downloading {year}: {e}", file=sys.stderr)

    print("Done.", file=sys.stderr)


if __name__ == '__main__':
    main()
