#!/usr/bin/env python3
"""
validate_panel.py — QA checks for a climate panel CSV.

Usage:
    python3 validate_panel.py \
        --data ~/Dropbox/datasets/global-country-climate-panel/data.csv \
        --entity-col admin_id \
        --time-cols year,month

Checks:
  1. Duplicate key rows
  2. Entity count
  3. Missing rates per climate column
  4. Value range sanity (temperature -70..60, precip >= 0)

Exit code 1 if any FAIL.
"""

import argparse
import sys
import os
import pandas as pd
import numpy as np


# Reasonable physical bounds for climate variables
VALUE_RANGES = {
    'temp_mean_c': (-70.0, 60.0),
    'temp_max_c': (-60.0, 65.0),
    'temp_min_c': (-80.0, 55.0),
    'precip_mm': (0.0, 6000.0),
    'pet_mm': (0.0, 500.0),
    'bio1': (-30.0, 35.0),
    'bio2': (0.0, 25.0),
    'bio3': (0.0, 100.0),
    'bio4': (0.0, 2500.0),
    'bio5': (-20.0, 55.0),
    'bio6': (-60.0, 30.0),
    'bio7': (0.0, 70.0),
    'bio8': (-30.0, 40.0),
    'bio9': (-30.0, 40.0),
    'bio10': (-20.0, 40.0),
    'bio11': (-40.0, 30.0),
    'bio12': (0.0, 12000.0),
    'bio13': (0.0, 2500.0),
    'bio14': (0.0, 1000.0),
    'bio15': (0.0, 300.0),
    'bio16': (0.0, 5000.0),
    'bio17': (0.0, 3000.0),
    'bio18': (0.0, 5000.0),
    'bio19': (0.0, 5000.0),
}


def check_result(label, passed, detail=''):
    """Print a check result line."""
    if passed is None:
        tag = 'WARN'
    elif bool(passed):
        tag = 'PASS'
    else:
        tag = 'FAIL'
    suffix = f'  ({detail})' if detail else ''
    print(f'  [{tag}] {label}{suffix}')
    return tag


def main():
    parser = argparse.ArgumentParser(
        description='Validate a climate panel CSV for quality issues.'
    )
    parser.add_argument('--data', required=True, help='Path to panel CSV')
    parser.add_argument('--entity-col', default='admin_id',
                        help='Entity identifier column (default: admin_id)')
    parser.add_argument('--time-cols', default='year,month',
                        help='Comma-separated time columns (default: year,month)')
    args = parser.parse_args()

    data_path = os.path.expanduser(args.data)
    if not os.path.exists(data_path):
        print(f"ERROR: file not found: {data_path}", file=sys.stderr)
        sys.exit(1)

    df = pd.read_csv(data_path)
    time_cols = [c.strip() for c in args.time_cols.split(',')]
    entity_col = args.entity_col

    print(f'Validating: {data_path}')
    print(f'  Shape: {df.shape[0]:,} rows x {df.shape[1]} columns')

    has_fail = False

    # --- Check 1: Duplicate keys ---
    key_cols = [entity_col] + [c for c in time_cols if c in df.columns]
    existing_keys = [c for c in key_cols if c in df.columns]
    if len(existing_keys) == len(key_cols):
        n_dups = df.duplicated(subset=key_cols).sum()
        tag = check_result('Duplicate keys', n_dups == 0,
                           f'{n_dups:,} duplicates on {key_cols}')
        if tag == 'FAIL':
            has_fail = True
    else:
        missing = [c for c in key_cols if c not in df.columns]
        check_result('Duplicate keys', None,
                     f'cannot check — missing columns: {missing}')

    # --- Check 2: Entity count ---
    if entity_col in df.columns:
        n_entities = df[entity_col].nunique()
        check_result('Entity count', True, f'{n_entities:,} unique {entity_col}')
    else:
        check_result('Entity count', None, f'column {entity_col} not found')

    # --- Check 3: Time range ---
    if 'year' in df.columns:
        yr_min, yr_max = int(df['year'].min()), int(df['year'].max())
        check_result('Time range', True, f'{yr_min}-{yr_max}')

    # --- Check 4: Missing rates per climate column ---
    climate_cols = [c for c in df.columns if c not in key_cols]
    for col in climate_cols:
        if df[col].dtype not in [np.float64, np.float32, np.int64, np.int32, float, int]:
            continue
        n_total = len(df)
        n_missing = df[col].isna().sum()
        pct = 100.0 * n_missing / n_total if n_total > 0 else 0.0
        if pct > 20.0:
            tag = check_result(f'Missing rate: {col}', False, f'{pct:.1f}%')
            has_fail = True
        elif pct > 5.0:
            check_result(f'Missing rate: {col}', None, f'{pct:.1f}%')
        else:
            check_result(f'Missing rate: {col}', True, f'{pct:.1f}%')

    # --- Check 5: Value ranges ---
    for col in climate_cols:
        if col not in VALUE_RANGES:
            continue
        lo, hi = VALUE_RANGES[col]
        valid = df[col].dropna()
        if len(valid) == 0:
            check_result(f'Range: {col}', None, 'no valid values')
            continue
        v_min, v_max = valid.min(), valid.max()
        in_range = (v_min >= lo) and (v_max <= hi)
        if not in_range:
            n_out = ((valid < lo) | (valid > hi)).sum()
            tag = check_result(f'Range: {col}', False,
                               f'[{v_min:.2f}, {v_max:.2f}] outside [{lo}, {hi}], {n_out:,} outliers')
            has_fail = True
        else:
            check_result(f'Range: {col}', True,
                         f'[{v_min:.2f}, {v_max:.2f}] within [{lo}, {hi}]')

    # --- Summary ---
    print()
    if has_fail:
        print('RESULT: FAIL — one or more checks failed')
        sys.exit(1)
    else:
        print('RESULT: PASS — all checks passed')
        sys.exit(0)


if __name__ == '__main__':
    main()
