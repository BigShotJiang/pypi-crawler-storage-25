#!/usr/bin/env bash
# Build all climate panel datasets from pre-downloaded source data.
# Prerequisites: all raw source data downloaded to ~/Dropbox/datasets/
# Usage: bash build_all_panels.sh [--skip-existing]
set -euo pipefail

SCRIPTS_DIR="$(cd "$(dirname "$0")" && pwd)"
DATASETS_DIR="$HOME/Dropbox/datasets"
BOUNDARIES_DIR="$DATASETS_DIR/boundaries"
SKIP_EXISTING=false

if [[ "${1:-}" == "--skip-existing" ]]; then
    SKIP_EXISTING=true
fi

log() { echo "[$(date +%H:%M:%S)] $*" >&2; }

should_build() {
    local dir="$1"
    if $SKIP_EXISTING && [[ -f "$dir/data.csv" && -f "$dir/report.pdf" ]]; then
        log "SKIP: $dir (already built, use without --skip-existing to rebuild)"
        return 1
    fi
    return 0
}

build_deliverables() {
    local name="$1" dir="$2" dataset_id="$3" source_desc="$4"
    log "Validating $name..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/validate_panel.py" --data "$dir/data.csv" || true

    log "Generating codebook..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/generate_codebook.py" \
        --data "$dir/data.csv" --dataset-name "$name" --output "$dir/codebook.xlsx"

    log "Generating version.json..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/generate_version_json.py" \
        --data "$dir/data.csv" --dataset-id "$dataset_id" \
        --dataset-name "$name" --sources "$source_desc" \
        --output-dir "$dir/"

    log "Generating report..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/generate_report_latex.py" \
        --data "$dir/data.csv" --dataset-name "$name" \
        --dataset-id "$dataset_id" --source "$source_desc" \
        --output-dir "$dir/"
}

# ── 1. Global Country Climate Panel (UDEL) ──────────────────────────
GLOBAL_DIR="$DATASETS_DIR/global-country-climate-panel"
if should_build "$GLOBAL_DIR"; then
    log "=== Building Global Country Climate Panel ==="
    mkdir -p "$GLOBAL_DIR/work"

    # Convert UDEL ASCII to NetCDF (if not already done)
    if [[ ! -f "$DATASETS_DIR/udel-climate-v501/udel_tmp.nc" ]]; then
        log "Converting UDEL temperature..."
        PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/udel_to_netcdf.py" \
            --var tmp --input "$DATASETS_DIR/udel-climate-v501/air_temp_2017.tar.gz" \
            --output "$DATASETS_DIR/udel-climate-v501/udel_tmp.nc"
    fi
    if [[ ! -f "$DATASETS_DIR/udel-climate-v501/udel_pre.nc" ]]; then
        log "Converting UDEL precipitation..."
        PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/udel_to_netcdf.py" \
            --var pre --input "$DATASETS_DIR/udel-climate-v501/precip_2017.tar.gz" \
            --output "$DATASETS_DIR/udel-climate-v501/udel_pre.nc"
    fi

    log "Zonal stats (temperature)..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/fast_zonal_nc.py" \
        --raster "$DATASETS_DIR/udel-climate-v501/udel_tmp.nc" --variable tmp \
        --admin "$BOUNDARIES_DIR/natural-earth/ne_10m_admin_0_countries.shp" \
        --admin-id ADM0_A3 --admin-name ADMIN \
        --output "$GLOBAL_DIR/work/data_tmp.csv"

    log "Zonal stats (precipitation)..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/fast_zonal_nc.py" \
        --raster "$DATASETS_DIR/udel-climate-v501/udel_pre.nc" --variable pre \
        --admin "$BOUNDARIES_DIR/natural-earth/ne_10m_admin_0_countries.shp" \
        --admin-id ADM0_A3 --admin-name ADMIN \
        --output "$GLOBAL_DIR/work/data_pre.csv"

    log "Merging panel..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/build_panel.py" \
        --inputs tmp:"$GLOBAL_DIR/work/data_tmp.csv" pre:"$GLOBAL_DIR/work/data_pre.csv" \
        --merge-keys admin_id,admin_name,year,month \
        --output "$GLOBAL_DIR/data.csv" --dataset-name "Global Country Climate Panel"

    build_deliverables "Global Country Climate Panel 1900-2017" "$GLOBAL_DIR" \
        "global-country-climate-panel" "UDEL v5.01 (Willmott & Matsuura, 2018)"
fi

# ── 2. WorldClim Admin1 Cross-Section ────────────────────────────────
WC_DIR="$DATASETS_DIR/worldclim-admin1-crosssection"
if should_build "$WC_DIR"; then
    log "=== Building WorldClim Admin1 Cross-Section ==="
    mkdir -p "$WC_DIR/work"

    for var in bio_1 bio_2 bio_3 bio_4 bio_5 bio_6 bio_7 bio_8 bio_9 bio_10 \
               bio_11 bio_12 bio_13 bio_14 bio_15 bio_16 bio_17 bio_18 bio_19 \
               tavg_01 tavg_02 tavg_03 tavg_04 tavg_05 tavg_06 \
               tavg_07 tavg_08 tavg_09 tavg_10 tavg_11 tavg_12 \
               prec_01 prec_02 prec_03 prec_04 prec_05 prec_06 \
               prec_07 prec_08 prec_09 prec_10 prec_11 prec_12; do
        tif="$DATASETS_DIR/worldclim-v21-bio/raw/wc2.1_10m_${var}.tif"
        if [[ -f "$tif" ]]; then
            log "Processing $var..."
            PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/grid_to_admin.py" \
                --raster "$tif" --variable "$var" --geotiff \
                --admin "$BOUNDARIES_DIR/natural-earth/ne_10m_admin_1_states_provinces.shp" \
                --admin-id adm1_code --admin-name name \
                --output "$WC_DIR/work/${var}.csv"
        fi
    done

    # Merge all variables (custom merge for cross-section)
    log "Merging cross-section..."
    PYTHONWARNINGS=ignore python3 -c "
import pandas as pd, glob
files = sorted(glob.glob('$WC_DIR/work/*.csv'))
df = None
for f in files:
    t = pd.read_csv(f)
    if df is None:
        df = t
    else:
        var_cols = [c for c in t.columns if c not in ('admin_id','admin_name')]
        df = df.merge(t[['admin_id'] + var_cols], on='admin_id', how='outer')
df.to_csv('$WC_DIR/data.csv', index=False)
print(f'Merged: {len(df)} rows, {len(df.columns)} columns')
"
    build_deliverables "WorldClim Admin1 Cross-Section (1970-2000)" "$WC_DIR" \
        "worldclim-admin1-crosssection" "WorldClim v2.1 (Fick & Hijmans, 2017)"
fi

# ── 3. Africa Country Climate Panel (CHIRPS + CRU TS) ───────────────
AFRICA_DIR="$DATASETS_DIR/africa-country-climate-panel"
if should_build "$AFRICA_DIR"; then
    log "=== Building Africa Country Climate Panel ==="
    mkdir -p "$AFRICA_DIR/work"

    # CRU TS temperature
    CRU_TMP="$DATASETS_DIR/cru-ts-407/raw/cru_ts4.07.1901.2022.tmp.dat.nc"
    if [[ -f "$CRU_TMP" ]]; then
        log "CRU TS temperature zonal stats..."
        PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/fast_zonal_nc.py" \
            --raster "$CRU_TMP" --variable tmp \
            --admin "$BOUNDARIES_DIR/africa_countries.gpkg" \
            --admin-id admin_id --admin-name admin_name \
            --output "$AFRICA_DIR/work/data_tmp.csv" \
            --aggregate monthly
    fi

    # CHIRPS precipitation (concatenate yearly NetCDFs)
    log "CHIRPS precipitation zonal stats..."
    # Process each year file individually and concatenate
    for nc in "$DATASETS_DIR/chirps-monthly-global/raw/"*.nc; do
        year=$(basename "$nc" | grep -o '[0-9]\{4\}')
        if [[ ! -f "$AFRICA_DIR/work/chirps_${year}.csv" ]]; then
            PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/fast_zonal_nc.py" \
                --raster "$nc" --variable precip \
                --admin "$BOUNDARIES_DIR/africa_countries.gpkg" \
                --admin-id admin_id --admin-name admin_name \
                --output "$AFRICA_DIR/work/chirps_${year}.csv" \
                --aggregate monthly 2>/dev/null || true
        fi
    done

    log "Merging panel..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/build_panel.py" \
        --inputs tmp:"$AFRICA_DIR/work/data_tmp.csv" pre:"$AFRICA_DIR/work/data_pre.csv" \
        --merge-keys admin_id,admin_name,year,month \
        --output "$AFRICA_DIR/data.csv" --dataset-name "Africa Country Climate Panel"

    build_deliverables "Africa Country Climate Panel 1981-2022" "$AFRICA_DIR" \
        "africa-country-climate-panel" "CRU TS v4.07 + CHIRPS v2.0"
fi

# ── 4. US County Climate Panel (nClimGrid) ───────────────────────────
US_DIR="$DATASETS_DIR/us-county-climate-panel"
if should_build "$US_DIR"; then
    log "=== Building US County Climate Panel ==="
    mkdir -p "$US_DIR/work"

    log "Parsing nClimGrid county data..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/parse_nclimgrid.py" \
        --input "$DATASETS_DIR/us-county-climate-panel/raw" \
        --output "$US_DIR/data.csv"

    build_deliverables "US County Climate Panel 1895-2024" "$US_DIR" \
        "us-county-climate-panel" "NOAA nClimGrid Monthly"
fi

# ── 5. India District Climate Panel (IMD) ────────────────────────────
INDIA_DIR="$DATASETS_DIR/india-district-climate-panel"
if should_build "$INDIA_DIR"; then
    log "=== Building India District Climate Panel ==="
    mkdir -p "$INDIA_DIR/work"

    for var in rain tmax tmin; do
        nc="$INDIA_DIR/raw/imd_${var}_*_monthly.nc"
        nc_file=$(ls $nc 2>/dev/null | head -1)
        if [[ -n "$nc_file" ]]; then
            log "IMD $var zonal stats..."
            PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/fast_zonal_nc.py" \
                --raster "$nc_file" --variable "$var" \
                --admin "$BOUNDARIES_DIR/gadm/IND/gadm41_IND_2.shp" \
                --admin-id GID_2 --admin-name NAME_2 \
                --output "$INDIA_DIR/work/data_${var}.csv" \
                --aggregate monthly
        fi
    done

    log "Merging panel..."
    PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/build_panel.py" \
        --inputs rain:"$INDIA_DIR/work/data_rain.csv" \
                 tmax:"$INDIA_DIR/work/data_tmax.csv" \
                 tmin:"$INDIA_DIR/work/data_tmin.csv" \
        --merge-keys admin_id,admin_name,year,month \
        --output "$INDIA_DIR/data.csv" --dataset-name "India District Climate Panel"

    build_deliverables "India District Climate Panel 1981-2022" "$INDIA_DIR" \
        "india-district-climate-panel" "IMD Gridded (Pai et al., 2014)"
fi

log "=== All panels built ==="
for d in global-country-climate-panel worldclim-admin1-crosssection \
         africa-country-climate-panel us-county-climate-panel india-district-climate-panel; do
    if [[ -f "$DATASETS_DIR/$d/data.csv" ]]; then
        rows=$(wc -l < "$DATASETS_DIR/$d/data.csv")
        log "  $d: $((rows - 1)) rows"
    else
        log "  $d: NOT BUILT"
    fi
done
