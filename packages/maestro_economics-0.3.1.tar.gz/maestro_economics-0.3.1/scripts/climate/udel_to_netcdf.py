#!/usr/bin/env python3
"""Convert UDEL v5.01 ASCII tar.gz archives to NetCDF.

UDEL distributes monthly temperature and precipitation as tar.gz archives
containing one ASCII file per year. Each row is one land grid cell:
  lon  lat  jan  feb  mar  apr  may  jun  jul  aug  sep  oct  nov  dec  annual

Grid: 0.5 deg, lon -179.75 to 179.75 (720 cols), lat varies (land cells only).
Ocean cells are absent from files.

Usage:
    python3 udel_to_netcdf.py --var tmp --input air_temp_2017.tar.gz --output udel_tmp.nc
    python3 udel_to_netcdf.py --var pre --input precip_2017.tar.gz --output udel_pre.nc
"""

import argparse
import tarfile
import re
import sys
from pathlib import Path

import numpy as np
import xarray as xr
import pandas as pd


NROWS = 360
NCOLS = 720
MISSING = -999.0

# Grid coordinates (cell centres)
LAT = np.linspace(89.75, -89.75, NROWS)   # north-to-south
LON = np.linspace(-179.75, 179.75, NCOLS)  # west-to-east

# Build lookup indices for fast placement
LAT_IDX = {round(v, 2): i for i, v in enumerate(LAT)}
LON_IDX = {round(v, 2): i for i, v in enumerate(LON)}


def parse_ascii_file(text: str) -> np.ndarray:
    """Parse a UDEL yearly ASCII file into (12, 360, 720) array.

    Each row: lon lat jan feb ... dec annual (15 columns).
    Only land cells present; ocean cells -> NaN.
    """
    grids = np.full((12, NROWS, NCOLS), np.nan, dtype=np.float32)
    lines = text.strip().split('\n')

    for line in lines:
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) < 14:
            continue

        lon = round(float(parts[0]), 2)
        lat = round(float(parts[1]), 2)

        li = LAT_IDX.get(lat)
        lj = LON_IDX.get(lon)
        if li is None or lj is None:
            continue

        for m in range(12):
            val = float(parts[2 + m])
            if val == MISSING:
                grids[m, li, lj] = np.nan
            else:
                grids[m, li, lj] = val

    return grids


def extract_year(filename: str) -> int:
    """Extract 4-digit year from a filename like 'air_temp.1900'."""
    m = re.search(r'(\d{4})', filename)
    if not m:
        raise ValueError(f"Cannot extract year from filename: {filename}")
    return int(m.group(1))


def convert(var: str, input_path: Path, output_path: Path) -> None:
    """Read tar.gz, parse all yearly ASCII files, build xarray Dataset, save."""
    all_data = []
    all_times = []

    with tarfile.open(input_path, 'r:gz') as tar:
        members = sorted(tar.getmembers(), key=lambda m: m.name)
        members = [m for m in members if m.isfile()]
        total = len(members)

        for i, member in enumerate(members):
            year = extract_year(member.name)
            f = tar.extractfile(member)
            if f is None:
                continue
            text = f.read().decode('utf-8')
            arr = parse_ascii_file(text)  # (12, 360, 720)
            all_data.append(arr)

            for month in range(1, 13):
                all_times.append(pd.Timestamp(year=year, month=month, day=1))

            if (i + 1) % 10 == 0 or (i + 1) == total:
                print(f"  Processed {i + 1}/{total} years (latest: {year})",
                      file=sys.stderr)

    data = np.concatenate(all_data, axis=0)  # (N_months, 360, 720)
    times = pd.DatetimeIndex(all_times)

    long_names = {'tmp': 'Near-Surface Air Temperature', 'pre': 'Precipitation'}
    units = {'tmp': 'degC', 'pre': 'mm/month'}

    ds = xr.Dataset(
        {
            var: xr.DataArray(
                data,
                dims=['time', 'lat', 'lon'],
                coords={'time': times, 'lat': LAT, 'lon': LON},
                attrs={
                    'long_name': long_names.get(var, var),
                    'units': units.get(var, ''),
                },
            )
        },
        attrs={
            'source': 'UDEL v5.01 (Willmott & Matsuura)',
            'resolution': '0.5 degree',
            'created_by': 'udel_to_netcdf.py',
        },
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    ds.to_netcdf(str(output_path))
    print(f"Saved {output_path} ({data.shape[0]} months, "
          f"{data.shape[1]}x{data.shape[2]} grid)", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description='Convert UDEL v5.01 ASCII tar.gz to NetCDF'
    )
    parser.add_argument('--var', required=True, choices=['tmp', 'pre'],
                        help='Variable: tmp (temperature) or pre (precipitation)')
    parser.add_argument('--input', required=True, type=str,
                        help='Path to input tar.gz file')
    parser.add_argument('--output', required=True, type=str,
                        help='Path to output NetCDF file')
    args = parser.parse_args()

    input_path = Path(args.input).expanduser()
    output_path = Path(args.output).expanduser()

    if not input_path.exists():
        print(f"Error: input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    convert(args.var, input_path, output_path)


if __name__ == '__main__':
    main()
