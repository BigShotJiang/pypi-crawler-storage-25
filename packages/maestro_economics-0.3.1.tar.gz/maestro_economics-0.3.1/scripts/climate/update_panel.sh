#!/usr/bin/env bash
# Update a single climate panel dataset (re-run pipeline from source data).
# Usage: bash update_panel.sh <dataset-slug>
# Example: bash update_panel.sh global-country-climate-panel
set -euo pipefail

SCRIPTS_DIR="$(cd "$(dirname "$0")" && pwd)"
DATASETS_DIR="$HOME/Dropbox/datasets"
SLUG="${1:?Usage: update_panel.sh <dataset-slug>}"
DIR="$DATASETS_DIR/$SLUG"

if [[ ! -d "$DIR" ]]; then
    echo "Error: dataset directory not found: $DIR" >&2
    exit 1
fi

if [[ ! -f "$DIR/data.csv" ]]; then
    echo "Error: no data.csv found in $DIR. Run build_all_panels.sh first." >&2
    exit 1
fi

log() { echo "[$(date +%H:%M:%S)] $*" >&2; }

# Detect dataset and set parameters
case "$SLUG" in
    global-country-climate-panel)
        NAME="Global Country Climate Panel 1900-2017"
        DATASET_ID="global-country-climate-panel"
        SOURCE="UDEL v5.01 (Willmott & Matsuura, 2018)"
        ;;
    worldclim-admin1-crosssection)
        NAME="WorldClim Admin1 Cross-Section (1970-2000)"
        DATASET_ID="worldclim-admin1-crosssection"
        SOURCE="WorldClim v2.1 (Fick & Hijmans, 2017)"
        ;;
    africa-country-climate-panel)
        NAME="Africa Country Climate Panel 1981-2022"
        DATASET_ID="africa-country-climate-panel"
        SOURCE="CRU TS v4.07 + CHIRPS v2.0"
        ;;
    us-county-climate-panel)
        NAME="US County Climate Panel 1895-2024"
        DATASET_ID="us-county-climate-panel"
        SOURCE="NOAA nClimGrid Monthly"
        ;;
    india-district-climate-panel)
        NAME="India District Climate Panel 1981-2022"
        DATASET_ID="india-district-climate-panel"
        SOURCE="IMD Gridded (Pai et al., 2014)"
        ;;
    *)
        echo "Error: unknown dataset slug: $SLUG" >&2
        echo "Valid slugs: global-country-climate-panel, worldclim-admin1-crosssection," >&2
        echo "  africa-country-climate-panel, us-county-climate-panel, india-district-climate-panel" >&2
        exit 1
        ;;
esac

log "Updating: $NAME"

log "Validating..."
PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/validate_panel.py" --data "$DIR/data.csv" || true

log "Regenerating codebook..."
PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/generate_codebook.py" \
    --data "$DIR/data.csv" --dataset-name "$NAME" --output "$DIR/codebook.xlsx"

log "Regenerating version.json..."
PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/generate_version_json.py" \
    --data "$DIR/data.csv" --dataset-id "$DATASET_ID" \
    --dataset-name "$NAME" --sources "$SOURCE" \
    --output-dir "$DIR/"

log "Regenerating report..."
PYTHONWARNINGS=ignore python3 "$SCRIPTS_DIR/generate_report_latex.py" \
    --data "$DIR/data.csv" --dataset-name "$NAME" \
    --dataset-id "$DATASET_ID" --source "$SOURCE" \
    --output-dir "$DIR/"

log "Done. Deliverables:"
ls -lh "$DIR/data.csv" "$DIR/codebook.xlsx" "$DIR/README.md" "$DIR/version.json" "$DIR/report.pdf" 2>/dev/null
