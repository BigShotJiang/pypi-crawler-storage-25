#!/usr/bin/env python3
"""
build_panel.py — Merge multiple climate variables into one standardized panel.

Usage:
    python3 build_panel.py \
        --inputs tmp:data_tmp.csv pre:data_pre.csv \
        --merge-keys admin_id,admin_name,year,month \
        --output ~/Dropbox/datasets/global-country-climate-panel/data.csv

Each --inputs entry is var:filepath. The variable name determines unit conversion
and standard column renaming.
"""

import argparse
import sys
import os
import pandas as pd


UNIT_CONVERSIONS = {
    'tmp': (1.0, 0.0),       # CRU TS already degC
    'pre': (1.0, 0.0),       # CRU TS already mm/month
    'tmx': (1.0, 0.0),       # CRU TS already degC
    'tmn': (1.0, 0.0),       # CRU TS already degC
    'pet': (1.0, 0.0),       # CRU TS already mm
    't2m': (1.0, -273.15),   # ERA5 K -> degC
    'tp':  (1000.0, 0.0),    # ERA5 m -> mm
    'precip': (1.0, 0.0),    # CHIRPS already mm
    'rain': (1.0, 0.0),      # IMD already mm
    'tmax': (1.0, 0.0),      # IMD already degC
    'tmin': (1.0, 0.0),      # IMD already degC
    'bio1': (1.0, 0.0),      # WorldClim v2.1 GeoTIFF: already degC
    'bio2': (1.0, 0.0),
    'bio3': (1.0, 0.0),      # ratio, no conversion
    'bio4': (1.0, 0.0),      # WorldClim v2.1 GeoTIFF: already degC*100 stored as float
    'bio5': (1.0, 0.0),
    'bio6': (1.0, 0.0),
    'bio7': (1.0, 0.0),
    'bio8': (1.0, 0.0),
    'bio9': (1.0, 0.0),
    'bio10': (1.0, 0.0),
    'bio11': (1.0, 0.0),
    'bio12': (1.0, 0.0),     # mm, no conversion
    'bio13': (1.0, 0.0),
    'bio14': (1.0, 0.0),
    'bio15': (1.0, 0.0),     # CV, no conversion
    'bio16': (1.0, 0.0),
    'bio17': (1.0, 0.0),
    'bio18': (1.0, 0.0),
    'bio19': (1.0, 0.0),
}

STANDARD_RENAME = {
    'tmp': 'temp_mean_c',
    'tmx': 'temp_max_c',
    'tmn': 'temp_min_c',
    'pre': 'precip_mm',
    'pet': 'pet_mm',
    't2m': 'temp_mean_c',
    'tp':  'precip_mm',
    'precip': 'precip_mm',
    'rain': 'precip_mm',
    'tmax': 'temp_max_c',
    'tmin': 'temp_min_c',
}
# bio1..bio19 keep their names


def parse_inputs(input_list):
    """Parse var:filepath pairs from --inputs."""
    pairs = []
    for item in input_list:
        if ':' not in item:
            print(f"ERROR: input '{item}' must be var:filepath format", file=sys.stderr)
            sys.exit(1)
        var, filepath = item.split(':', 1)
        filepath = os.path.expanduser(filepath)
        if not os.path.exists(filepath):
            print(f"ERROR: file not found: {filepath}", file=sys.stderr)
            sys.exit(1)
        pairs.append((var, filepath))
    return pairs


def apply_conversion(series, var):
    """Apply unit conversion for a variable."""
    scale, offset = UNIT_CONVERSIONS.get(var, (1.0, 0.0))
    if scale != 1.0 or offset != 0.0:
        return series * scale + offset
    return series


def get_standard_name(var):
    """Get standardized column name for a variable."""
    if var in STANDARD_RENAME:
        return STANDARD_RENAME[var]
    return var


def main():
    parser = argparse.ArgumentParser(
        description='Merge multiple climate variable CSVs into one standardized panel.'
    )
    parser.add_argument('--inputs', nargs='+', required=True,
                        help='Variable:filepath pairs (e.g., tmp:data_tmp.csv pre:data_pre.csv)')
    parser.add_argument('--merge-keys', required=True,
                        help='Comma-separated merge key columns (e.g., admin_id,admin_name,year,month)')
    parser.add_argument('--output', required=True,
                        help='Output CSV path')
    parser.add_argument('--dataset-name', default='climate-panel',
                        help='Dataset name for logging')
    args = parser.parse_args()

    merge_keys = [k.strip() for k in args.merge_keys.split(',')]
    pairs = parse_inputs(args.inputs)

    print(f"Building panel: {args.dataset_name}", file=sys.stderr)
    print(f"  Merge keys: {merge_keys}", file=sys.stderr)
    print(f"  Inputs: {len(pairs)} variable files", file=sys.stderr)

    merged = None

    for var, filepath in pairs:
        print(f"  Loading {var} from {filepath}...", file=sys.stderr)
        df = pd.read_csv(filepath)

        # Identify the value column (not a merge key)
        value_cols = [c for c in df.columns if c not in merge_keys]
        if len(value_cols) == 0:
            print(f"  WARNING: no value columns in {filepath}, skipping", file=sys.stderr)
            continue

        # If there's a 'mean' column, use that as the variable value
        if 'mean' in value_cols:
            val_col = 'mean'
        elif var in value_cols:
            val_col = var
        else:
            val_col = value_cols[0]

        # Apply unit conversion
        df[val_col] = apply_conversion(df[val_col].astype(float), var)

        # Rename to standard name
        std_name = get_standard_name(var)
        if val_col != std_name:
            df = df.rename(columns={val_col: std_name})

        # Keep only merge keys + standardized value column
        keep_cols = [c for c in merge_keys if c in df.columns] + [std_name]
        df = df[keep_cols]

        if merged is None:
            merged = df
        else:
            # Outer merge to preserve all observations
            merged = merged.merge(df, on=[c for c in merge_keys if c in df.columns], how='outer')

        print(f"    -> {std_name}: {len(df)} rows, "
              f"non-null: {df[std_name].notna().sum()}", file=sys.stderr)

    if merged is None:
        print("ERROR: no data loaded", file=sys.stderr)
        sys.exit(1)

    # Sort by merge keys
    sort_cols = [c for c in merge_keys if c in merged.columns]
    merged = merged.sort_values(sort_cols).reset_index(drop=True)

    # Write output
    output_path = os.path.expanduser(args.output)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    merged.to_csv(output_path, index=False)

    print(f"\nPanel written: {output_path}", file=sys.stderr)
    print(f"  Rows: {len(merged):,}", file=sys.stderr)
    print(f"  Columns: {list(merged.columns)}", file=sys.stderr)
    print(f"  Climate vars: {[c for c in merged.columns if c not in merge_keys]}", file=sys.stderr)


if __name__ == '__main__':
    main()
