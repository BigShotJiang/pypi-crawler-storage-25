#!/usr/bin/env python3
"""Download NOAA nClimDiv county-level monthly climate data.

Downloads county-level (cy) files for precipitation, tmax, tmin, and tavg
from NCEI's nclimdiv-monthly access directory.

Data format: fixed-width text, one row per county-year.
  Col 1: FIPS(5) + element(2) + year(4) = 11 chars
  Cols 2-13: monthly values (Jan-Dec)

Usage:
    python3 download_nclimgrid.py --output-dir ~/Dropbox/datasets/us-county-climate-panel/raw/
"""

import argparse
import sys
from pathlib import Path

import requests
from tqdm import tqdm

BASE_URL = 'https://www.ncei.noaa.gov/data/nclimdiv-monthly/access/'

# County-level files (suffix 'cy') — ~40MB each
FILES = {
    'pcpn': 'climdiv-pcpncy-v1.0.0-20260205',  # precipitation (inches)
    'tmax': 'climdiv-tmaxcy-v1.0.0-20260205',   # max temperature (F)
    'tmin': 'climdiv-tmincy-v1.0.0-20260205',   # min temperature (F)
    'tmpc': 'climdiv-tmpccy-v1.0.0-20260205',   # avg temperature (F)
}

CHUNK_SIZE = 1024 * 1024  # 1 MB


def download_file(url: str, dest: Path) -> None:
    """Download a single file with progress bar."""
    if dest.exists() and dest.stat().st_size > 1_000_000:
        print(f"  Skip {dest.name} (exists, {dest.stat().st_size / 1e6:.1f} MB)",
              file=sys.stderr)
        return

    resp = requests.get(url, stream=True, timeout=300)
    resp.raise_for_status()

    total = int(resp.headers.get('content-length', 0))
    with open(dest, 'wb') as f, tqdm(
        total=total, unit='B', unit_scale=True, desc=dest.name,
        file=sys.stderr,
    ) as pbar:
        for chunk in resp.iter_content(chunk_size=CHUNK_SIZE):
            f.write(chunk)
            pbar.update(len(chunk))

    size_mb = dest.stat().st_size / 1e6
    print(f"  Saved {dest.name} ({size_mb:.1f} MB)", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description='Download NOAA nClimDiv county monthly climate data'
    )
    parser.add_argument('--output-dir', type=str,
                        default='~/Dropbox/datasets/us-county-climate-panel/raw/',
                        help='Output directory')
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser()
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"nClimDiv: downloading {len(FILES)} county files to {output_dir}",
          file=sys.stderr)

    for var, filename in FILES.items():
        url = BASE_URL + filename
        dest = output_dir / filename
        print(f"Downloading {var}: {filename}", file=sys.stderr)
        try:
            download_file(url, dest)
        except Exception as e:
            print(f"  ERROR downloading {var}: {e}", file=sys.stderr)

    print("Done.", file=sys.stderr)
    print(f"\nData format: fixed-width, col1 = FIPS(5)+element(2)+year(4), "
          f"cols 2-13 = Jan-Dec monthly values", file=sys.stderr)


if __name__ == '__main__':
    main()
