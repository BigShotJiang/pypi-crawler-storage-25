#!/usr/bin/env python3
"""
search.py -- Search academic literature via OpenAlex and Semantic Scholar.

Outputs structured markdown and BibTeX for a given query.

Usage:
    python search.py "rainfall housing prices salience" --max 20 --output branch1.md
    python search.py "narrative economics" --bib refs.bib --max 15
    python search.py "climate risk real estate" --format bibtex --output refs.bib

Dependencies:
    pip install requests
"""
from __future__ import annotations
import argparse
import sys
import time
import json
import re
import requests
from pathlib import Path


OPENALEX_BASE = "https://api.openalex.org"
SS_BASE = "https://api.semanticscholar.org/graph/v1"


def search_openalex(query: str, max_results: int = 20) -> list[dict]:
    """Search OpenAlex for papers matching query."""
    params = {
        "search": query,
        "per-page": min(max_results, 50),
        "sort": "cited_by_count:desc",
        "select": "id,title,authorships,publication_year,primary_location,cited_by_count,abstract_inverted_index,doi"
    }
    r = requests.get(f"{OPENALEX_BASE}/works", params=params, timeout=30)
    r.raise_for_status()
    results = r.json().get("results", [])
    print(f"[OpenAlex] Found {len(results)} papers for: {query[:50]}", file=sys.stderr)
    return results


def openalex_to_dict(work: dict) -> dict:
    """Normalize OpenAlex work to standard dict."""
    authors = [a["author"]["display_name"] for a in work.get("authorships", [])[:5]]
    venue = ""
    year = work.get("publication_year", "")
    doi = work.get("doi", "")
    loc = work.get("primary_location") or {}
    source = loc.get("source") or {}
    venue = source.get("display_name", "")

    # Reconstruct abstract
    abstract = ""
    inv = work.get("abstract_inverted_index") or {}
    if inv:
        words = sorted([(pos, word) for word, positions in inv.items()
                        for pos in positions])
        abstract = " ".join(w for _, w in words[:100])

    return {
        "title": work.get("title", ""),
        "authors": authors,
        "year": year,
        "venue": venue,
        "doi": doi.replace("https://doi.org/", "") if doi else "",
        "citations": work.get("cited_by_count", 0),
        "abstract": abstract[:300],
        "source": "openalex"
    }


def to_bibtex(paper: dict, key: str) -> str:
    """Convert paper dict to BibTeX entry."""
    authors_str = " and ".join(paper["authors"]) if paper["authors"] else "Unknown"
    venue = paper.get("venue", "")
    year = paper.get("year", "")
    doi = paper.get("doi", "")
    title = paper.get("title", "").replace("{", "").replace("}", "")

    entry_type = "book" if not venue else "article"
    lines = [
        f"@{entry_type}{{{key},",
        f"  author = {{{authors_str}}},",
        f"  title = {{{{{title}}}}},",
        f"  year = {{{year}}},",
    ]
    if venue:
        lines.append(f"  journal = {{{venue}}},")
    if doi:
        lines.append(f"  doi = {{{doi}}},")
    lines.append("}")
    return "\n".join(lines)


def make_key(paper: dict) -> str:
    """Generate BibTeX key: FirstAuthorLastNameYearFirstWord"""
    authors = paper.get("authors", [])
    last_name = authors[0].split()[-1] if authors else "Unknown"
    year = str(paper.get("year", "0000"))
    title_words = re.sub(r"[^a-zA-Z ]", "", paper.get("title", "")).split()
    first_word = title_words[0] if title_words else "Untitled"
    return f"{last_name}{year}{first_word}"


def format_markdown(papers: list[dict], query: str) -> str:
    """Format papers as structured markdown."""
    lines = [
        f"# Literature: {query}",
        f"",
        f"*{len(papers)} papers, sorted by citation count*",
        f"",
    ]
    for i, p in enumerate(papers, 1):
        authors_str = ", ".join(p["authors"][:3])
        if len(p["authors"]) > 3:
            authors_str += " et al."
        doi_link = f" [DOI](https://doi.org/{p['doi']})" if p["doi"] else ""
        lines += [
            f"## {i}. {p['title']}",
            f"**{authors_str} ({p['year']})** — {p['venue']} — {p['citations']:,} citations{doi_link}",
            f"",
            f"{p['abstract']}",
            f"",
            f"---",
            f"",
        ]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Search academic literature via OpenAlex")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--max", type=int, default=20, help="Max results (default: 20)")
    parser.add_argument("--output", "-o", help="Output file (.md or .bib)")
    parser.add_argument("--bib", help="Append BibTeX entries to this .bib file")
    parser.add_argument("--format", choices=["markdown", "bibtex", "json"], default="markdown")
    args = parser.parse_args()

    papers_raw = search_openalex(args.query, args.max)
    papers = [openalex_to_dict(p) for p in papers_raw]

    if args.format == "bibtex" or args.bib:
        bib_entries = [to_bibtex(p, make_key(p)) for p in papers]
        bib_text = "\n\n".join(bib_entries)
        if args.bib:
            Path(args.bib).parent.mkdir(parents=True, exist_ok=True)
            with open(args.bib, "a") as f:
                f.write("\n\n" + bib_text)
            print(f"Appended {len(bib_entries)} entries to {args.bib}", file=sys.stderr)
        if args.format == "bibtex":
            if args.output:
                Path(args.output).write_text(bib_text)
            else:
                print(bib_text)
            return

    md = format_markdown(papers, args.query)
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(md)
        print(f"Saved {len(papers)} papers -> {args.output}", file=sys.stderr)
    else:
        print(md)


if __name__ == "__main__":
    main()
