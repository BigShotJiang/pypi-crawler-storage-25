#!/usr/bin/env python3
"""wordcount.py -- Section-by-section word count for LaTeX papers.

Strips LaTeX commands, counts words per section, and compares to
QJE/JPE/AEJ:Applied section length targets.

Usage:
    python wordcount.py paper.tex [--target qje|jpe|aej] [--output report.txt]

Output:
    Table: section_name | word_count | target_range | status (over/under/ok)
    Summary: total words, total pages (estimated at 250 words/page double-spaced)
"""
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


################################################################################
# Target word counts by journal style
################################################################################

# Each entry: (min_words, max_words, note)
TARGETS: dict[str, dict[str, tuple[int, int, str]]] = {
    "qje": {
        "abstract":            (150,  200,  "QJE requires < 150 words; allow 200 for WP"),
        "introduction":        (2000, 3000, "8-10 pages at 300 words/page"),
        "institutional background": (900, 1500, "3-5 pages"),
        "background":          (900, 1500, "3-5 pages (alternate heading)"),
        "data":                (1500, 2500, "5-8 pages"),
        "empirical strategy":  (1500, 2500, "5-8 pages"),
        "identification":      (1500, 2500, "5-8 pages (alternate heading)"),
        "methodology":         (1500, 2500, "5-8 pages (alternate heading)"),
        "results":             (3000, 4500, "10-15 pages"),
        "robustness":          (1200, 1800, "4-6 pages"),
        "discussion":          (900,  1200, "3-4 pages"),
        "conclusion":          (600,   900, "2-3 pages"),
    },
    "jpe": {
        "abstract":            (150,  200,  "JPE allows up to 200 words"),
        "introduction":        (2000, 3000, "Similar to QJE"),
        "institutional background": (900, 1500, "3-5 pages"),
        "background":          (900, 1500, "3-5 pages"),
        "data":                (1500, 2500, "5-8 pages"),
        "empirical strategy":  (1500, 2500, "5-8 pages"),
        "identification":      (1500, 2500, "5-8 pages"),
        "methodology":         (1500, 2500, "5-8 pages"),
        "results":             (2500, 4000, "Slightly tighter than QJE"),
        "robustness":          (1000, 1600, "3-5 pages"),
        "discussion":          (750,  1200, "2-4 pages"),
        "conclusion":          (500,   900, "1.5-3 pages"),
    },
    "aej": {
        "abstract":            (100,  150,  "AEJ:Applied requires <= 150 words"),
        "introduction":        (1500, 2500, "5-8 pages (tighter than QJE)"),
        "institutional background": (600, 1200, "2-4 pages"),
        "background":          (600, 1200, "2-4 pages"),
        "data":                (1200, 2000, "4-6 pages"),
        "empirical strategy":  (1200, 2000, "4-6 pages"),
        "identification":      (1200, 2000, "4-6 pages"),
        "methodology":         (1200, 2000, "4-6 pages"),
        "results":             (2000, 3500, "7-12 pages"),
        "robustness":          (800,  1400, "3-5 pages"),
        "discussion":          (600,  1000, "2-3 pages"),
        "conclusion":          (400,   750, "1.5-2.5 pages"),
    },
}


################################################################################
# LaTeX text cleaning
################################################################################

LATEX_COMMAND_RE = re.compile(r'\\[a-zA-Z]+\*?')
MATH_INLINE_RE = re.compile(r'\$[^$]*\$')
MATH_DISPLAY_RE = re.compile(r'\$\$.*?\$\$', re.DOTALL)
BRACES_RE = re.compile(r'[{}]')
EXTRA_SPACE_RE = re.compile(r'\s+')

# Environments to remove entirely (no word credit)
SKIP_ENVIRONMENTS = [
    "tabular", "tabularx", "equation", "align", "eqnarray",
    "tikzpicture", "lstlisting", "verbatim",
]


def remove_skip_environments(tex: str) -> str:
    for env in SKIP_ENVIRONMENTS:
        pattern = rf'\\begin\{{{env}\*?}}.*?\\end\{{{env}\*?\}}'
        tex = re.sub(pattern, ' ', tex, flags=re.DOTALL)
    return tex


def clean_latex(tex: str) -> str:
    """Strip LaTeX markup, return plain text suitable for word counting."""
    # Remove comments
    tex = re.sub(r'(?<!\\)%.*$', '', tex, flags=re.MULTILINE)
    # Remove skipped environments (tables, equations, code)
    tex = remove_skip_environments(tex)
    # Remove display math
    tex = MATH_DISPLAY_RE.sub(' MATH ', tex)
    # Remove inline math
    tex = MATH_INLINE_RE.sub(' MATH ', tex)
    # Remove LaTeX commands but keep their arguments
    tex = re.sub(r'\\(?:textit|textbf|emph|text|mbox)\{([^}]*)\}', r'\1', tex)
    tex = re.sub(r'\\(?:citet|citep|citealt|citeauthor|cite)\{[^}]*\}', 'CITATION', tex)
    tex = re.sub(r'\\(?:ref|label|cref|autoref)\{[^}]*\}', 'REF', tex)
    tex = LATEX_COMMAND_RE.sub(' ', tex)
    tex = BRACES_RE.sub(' ', tex)
    tex = EXTRA_SPACE_RE.sub(' ', tex)
    return tex.strip()


def count_words(text: str) -> int:
    return len(text.split())


################################################################################
# Section extraction
################################################################################

@dataclass
class Section:
    heading: str          # original heading text (lowercased for matching)
    raw_text: str         # raw LaTeX content of this section
    word_count: int


def split_into_sections(tex: str) -> list[Section]:
    """
    Split LaTeX document into sections. Returns list of Section objects.
    The first pseudo-section captures text before the first \\section{}.
    """
    # Match \\section{...} and \\section*{...}
    pattern = re.compile(r'(\\section\*?\{[^}]+\})', re.DOTALL)
    parts = pattern.split(tex)

    sections: list[Section] = []
    # parts alternates: [preamble, header1, body1, header2, body2, ...]
    i = 0
    if parts and not parts[0].strip().startswith('\\section'):
        # preamble -- look for abstract
        preamble = parts[0]
        abs_match = re.search(
            r'\\begin\{abstract\}(.*?)\\end\{abstract\}', preamble, re.DOTALL
        )
        if abs_match:
            abstract_text = abs_match.group(1)
            cleaned = clean_latex(abstract_text)
            sections.append(Section("abstract", abstract_text, count_words(cleaned)))
        i = 1

    while i < len(parts) - 1:
        header_tex = parts[i]
        body_tex = parts[i + 1] if i + 1 < len(parts) else ""
        # Extract heading text
        heading_match = re.search(r'\\section\*?\{([^}]+)\}', header_tex)
        heading = heading_match.group(1).lower().strip() if heading_match else header_tex.lower()
        cleaned_body = clean_latex(body_tex)
        wc = count_words(cleaned_body)
        sections.append(Section(heading, body_tex, wc))
        i += 2

    return sections


################################################################################
# Matching section heading to target keys
################################################################################

def match_target(heading: str, targets: dict[str, tuple[int, int, str]]) -> Optional[tuple[int, int, str]]:
    """Return target (min, max, note) if heading matches a known section, else None."""
    heading_lower = heading.lower()
    # Exact match first
    for key, val in targets.items():
        if key == heading_lower:
            return val
    # Substring match
    for key, val in targets.items():
        if key in heading_lower or heading_lower in key:
            return val
    return None


################################################################################
# Report
################################################################################

def format_status(wc: int, lo: int, hi: int) -> str:
    if wc < lo:
        pct = round((lo - wc) / lo * 100)
        return f"UNDER  ({pct}% below target)"
    if wc > hi:
        pct = round((wc - hi) / hi * 100)
        return f"OVER   ({pct}% above target)"
    return "OK"


def format_report(sections: list[Section], journal: str,
                  targets: dict[str, tuple[int, int, str]]) -> str:
    lines = [
        "=" * 72,
        f"WORD COUNT REPORT  (journal target: {journal.upper()})",
        "=" * 72,
        "",
        f"  {'Section':<35} {'Words':>6}  {'Target':>12}  Status",
        "  " + "-" * 68,
    ]

    total_words = 0
    for sec in sections:
        total_words += sec.word_count
        target_info = match_target(sec.heading, targets)
        if target_info:
            lo, hi, _ = target_info
            target_str = f"{lo}-{hi}"
            status = format_status(sec.word_count, lo, hi)
        else:
            target_str = "no target"
            status = "---"
        heading_display = sec.heading[:33] + ".." if len(sec.heading) > 35 else sec.heading
        lines.append(
            f"  {heading_display:<35} {sec.word_count:>6}  {target_str:>12}  {status}"
        )

    total_pages_est = total_words / 250  # double-spaced 12pt approx
    lines += [
        "",
        "  " + "-" * 68,
        f"  {'TOTAL (body text)':<35} {total_words:>6}",
        f"  {'Estimated pages (250 w/page)':<35} {total_pages_est:>6.1f}",
        "=" * 72,
    ]
    return "\n".join(lines)


################################################################################
# Entry point
################################################################################

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Section word count for LaTeX papers vs QJE/JPE/AEJ targets."
    )
    parser.add_argument("tex_path", help="Path to the main .tex file.")
    parser.add_argument("--target", choices=["qje", "jpe", "aej"], default="qje",
                        help="Journal target for section length comparison (default: qje).")
    parser.add_argument("--output", "-o", default=None,
                        help="Write report to this file (default: stdout).")
    args = parser.parse_args()

    if not Path(args.tex_path).exists():
        print(f"ERROR: File not found: {args.tex_path}", file=sys.stderr)
        sys.exit(1)

    tex = Path(args.tex_path).read_text(encoding='utf-8', errors='replace')
    sections = split_into_sections(tex)
    targets = TARGETS[args.target]
    output = format_report(sections, args.target, targets)

    if args.output:
        Path(args.output).write_text(output, encoding='utf-8')
        print(f"Report written to: {args.output}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
