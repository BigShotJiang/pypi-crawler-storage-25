"""maestro-paper CLI — unified entry point for paper skill scripts.

Usage:
    python -m maestro_paper audit <paper.tex> [options]
    python -m maestro_paper wordcount <paper.tex>
    python -m maestro_paper tables <paper.tex>
"""

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent.parent  # paper/scripts/


def cmd_audit(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "paper_audit.py"), args.paper]
    if args.output:
        cmd.extend(["--output", args.output])
    if args.bib:
        cmd.extend(["--bib", args.bib])
    return subprocess.call(cmd)


def cmd_wordcount(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "wordcount.py"), args.paper]
    return subprocess.call(cmd)


def cmd_tables(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "table_check.py"), args.paper]
    return subprocess.call(cmd)


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="maestro-paper",
        description="Maestro Paper skill CLI",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # audit
    p_audit = sub.add_parser("audit", help="Audit a LaTeX paper for common issues")
    p_audit.add_argument("paper", help="Path to paper.tex")
    p_audit.add_argument("--output", default=None, help="Output report path (default: report.txt)")
    p_audit.add_argument("--bib", default=None, help="Path to references.bib")
    p_audit.set_defaults(func=cmd_audit)

    # wordcount
    p_wc = sub.add_parser("wordcount", help="Count words in a LaTeX paper")
    p_wc.add_argument("paper", help="Path to paper.tex")
    p_wc.set_defaults(func=cmd_wordcount)

    # tables
    p_tables = sub.add_parser("tables", help="Check tables in a LaTeX paper")
    p_tables.add_argument("paper", help="Path to paper.tex")
    p_tables.set_defaults(func=cmd_tables)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
