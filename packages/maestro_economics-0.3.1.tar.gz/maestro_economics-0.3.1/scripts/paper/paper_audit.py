#!/usr/bin/env python3
"""paper_audit.py -- Audit a LaTeX paper against QJE/JPE structural checklist.

Usage:
    python paper_audit.py paper.tex [--output report.txt] [--bib references.bib]

Checks:
    - Section presence (abstract, intro, data, strategy, results, robustness, conclusion)
    - Abstract word count (target: 150-200)
    - JEL codes present
    - Table/figure citation: every \\label{} has a matching \\ref{} or \\cref{}
    - Notes line present in every table environment
    - booktabs usage (\\toprule present; no naked \\hline in tables)
    - Appendix section present
    - Economic magnitude discussion (checks for "standard deviation" or "$\\times$" in results)
    - Undefined references check (looks for "??" in aux file if present)
    - BibTeX undefined references (if .bib provided)

Output:
    Formatted text report with PASS / WARN / FAIL per check.
    Exit code 0 if no FAIL items, 1 if any FAIL.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


################################################################################
# Result model
################################################################################

@dataclass
class CheckResult:
    name: str
    status: str  # PASS | WARN | FAIL
    detail: str


@dataclass
class AuditReport:
    tex_path: str
    checks: list[CheckResult] = field(default_factory=list)

    def add(self, name: str, status: str, detail: str) -> None:
        self.checks.append(CheckResult(name, status, detail))

    @property
    def n_fail(self) -> int:
        return sum(1 for c in self.checks if c.status == "FAIL")

    @property
    def n_warn(self) -> int:
        return sum(1 for c in self.checks if c.status == "WARN")

    @property
    def n_pass(self) -> int:
        return sum(1 for c in self.checks if c.status == "PASS")


################################################################################
# LaTeX parsing helpers
################################################################################

def strip_comments(tex: str) -> str:
    """Remove LaTeX comment lines (% ...) preserving newlines."""
    lines = []
    for line in tex.splitlines():
        # Remove inline comments but keep the line
        stripped = re.sub(r'(?<!\\)%.*$', '', line)
        lines.append(stripped)
    return "\n".join(lines)


def extract_abstract(tex: str) -> str:
    """Return text inside \\begin{abstract}...\\end{abstract}."""
    m = re.search(r'\\begin\{abstract\}(.*?)\\end\{abstract\}', tex, re.DOTALL)
    return m.group(1).strip() if m else ""


def count_words(text: str) -> int:
    """Rough word count: split on whitespace after stripping LaTeX commands."""
    # Remove common LaTeX commands but keep their text arguments
    cleaned = re.sub(r'\\[a-zA-Z]+\{([^}]*)\}', r'\1', text)
    cleaned = re.sub(r'\\[a-zA-Z]+\*?', ' ', cleaned)
    cleaned = re.sub(r'[{}]', ' ', cleaned)
    cleaned = re.sub(r'\$[^$]*\$', 'MATH', cleaned)
    return len(cleaned.split())


def find_section_names(tex: str) -> list[str]:
    """Return lowercase section titles found in the document."""
    pattern = r'\\(?:section|subsection)\*?\{([^}]+)\}'
    return [m.lower() for m in re.findall(pattern, tex)]


def find_labels(tex: str) -> set[str]:
    """Return set of all \\label{key} keys."""
    return set(re.findall(r'\\label\{([^}]+)\}', tex))


def find_refs(tex: str) -> set[str]:
    """Return set of all \\ref{key} and \\cref{key} keys."""
    keys: set[str] = set()
    for pattern in [r'\\ref\{([^}]+)\}', r'\\cref\{([^}]+)\}',
                    r'\\autoref\{([^}]+)\}', r'\\pageref\{([^}]+)\}']:
        keys.update(re.findall(pattern, tex))
    return keys


def find_table_blocks(tex: str) -> list[str]:
    """Return list of \\begin{table}...\\end{table} blocks."""
    pattern = r'\\begin\{table[*]?\}(.*?)\\end\{table[*]?\}'
    return re.findall(pattern, tex, re.DOTALL)


def find_cites(tex: str) -> set[str]:
    """Return set of all citation keys used in the document."""
    keys: set[str] = set()
    for pattern in [r'\\citet\{([^}]+)\}', r'\\citep\{([^}]+)\}',
                    r'\\cite\{([^}]+)\}', r'\\citealt\{([^}]+)\}',
                    r'\\citeauthor\{([^}]+)\}']:
        for match in re.findall(pattern, tex):
            # Handle multiple keys: \citep{a,b,c}
            keys.update(k.strip() for k in match.split(','))
    return keys


def find_bib_keys(bib_path: str) -> set[str]:
    """Return set of all @entry{key, ...} keys in a .bib file."""
    text = Path(bib_path).read_text(encoding='utf-8', errors='replace')
    return set(re.findall(r'@\w+\{([^,]+),', text))


################################################################################
# Individual checks
################################################################################

def check_sections(tex: str, report: AuditReport) -> None:
    sections = find_section_names(tex)
    joined = " ".join(sections)

    required = {
        "abstract": ["abstract"],
        "introduction": ["introduction"],
        "data": ["data", "dataset"],
        "empirical strategy": ["empirical strategy", "identification", "methodology"],
        "results": ["results", "findings"],
        "robustness": ["robustness", "sensitivity"],
        "conclusion": ["conclusion"],
    }
    for canon, variants in required.items():
        # Abstract is special: it lives in \begin{abstract} env, not \section{}
        if canon == "abstract":
            found = bool(re.search(r'\\begin\{abstract\}', tex)) or any(v in joined for v in variants)
        else:
            found = any(v in joined for v in variants)
        if found:
            report.add(f"Section: {canon}", "PASS", "Found.")
        else:
            report.add(f"Section: {canon}", "FAIL",
                       f"No section matching {variants} found.")

    # Check for appendix
    has_appendix = "\\appendix" in tex or "appendix" in joined
    report.add("Section: appendix", "PASS" if has_appendix else "WARN",
               "Found." if has_appendix else "No appendix section detected.")


def check_abstract_length(tex: str, report: AuditReport) -> None:
    abstract = extract_abstract(tex)
    if not abstract:
        report.add("Abstract: word count", "FAIL", "No abstract environment found.")
        return
    wc = count_words(abstract)
    if 150 <= wc <= 200:
        status, detail = "PASS", f"{wc} words (target: 150-200)."
    elif wc < 150:
        status, detail = "WARN", f"{wc} words -- below 150-word target."
    else:
        status, detail = "WARN", f"{wc} words -- above 200-word target. Cut."
    report.add("Abstract: word count", status, detail)


def check_jel_codes(tex: str, report: AuditReport) -> None:
    has_jel = bool(re.search(r'JEL\s*[Cc]odes?', tex, re.IGNORECASE))
    report.add("Abstract: JEL codes", "PASS" if has_jel else "FAIL",
               "JEL codes found." if has_jel else
               "No JEL codes detected. Add \\textbf{JEL Codes:} after abstract.")


def check_label_ref_coverage(tex: str, report: AuditReport) -> None:
    labels = find_labels(tex)
    refs = find_refs(tex)

    unreferenced = labels - refs
    # Filter out section labels (sec:*) -- these are often not \\ref'd explicitly
    unreferenced_nontrivial = {l for l in unreferenced
                                if not l.startswith('sec:') and not l.startswith('app:')}

    if not unreferenced_nontrivial:
        report.add("Cross-references: all labels cited", "PASS",
                   f"{len(labels)} labels, all referenced.")
    else:
        items = ", ".join(sorted(unreferenced_nontrivial)[:8])
        report.add("Cross-references: all labels cited", "WARN",
                   f"{len(unreferenced_nontrivial)} label(s) never \\ref'd: {items}")


def check_table_notes(tex: str, report: AuditReport) -> None:
    blocks = find_table_blocks(tex)
    if not blocks:
        report.add("Tables: notes lines present", "WARN", "No table environments found.")
        return

    missing = 0
    for i, block in enumerate(blocks):
        has_note = bool(
            re.search(r'\\textit\{Notes?\}|\\textit\{Note:\}|\\note\{|'
                      r'\\begin\{tablenotes\}|minipage', block, re.IGNORECASE)
        )
        if not has_note:
            missing += 1

    if missing == 0:
        report.add("Tables: notes lines present", "PASS",
                   f"All {len(blocks)} table(s) have notes.")
    else:
        report.add("Tables: notes lines present", "FAIL",
                   f"{missing}/{len(blocks)} table(s) missing notes line. "
                   "Every table needs \\textit{Notes:} specifying DV, FE, SE clustering.")


def check_booktabs(tex: str, report: AuditReport) -> None:
    blocks = find_table_blocks(tex)
    if not blocks:
        report.add("Tables: booktabs formatting", "WARN", "No table environments found.")
        return

    bad_hline = 0
    missing_toprule = 0
    for block in blocks:
        if "\\toprule" not in block:
            missing_toprule += 1
        # \\hline that is NOT inside a comment
        cleaned = strip_comments(block)
        hlines = re.findall(r'\\hline', cleaned)
        if hlines:
            bad_hline += 1

    issues = []
    if missing_toprule:
        issues.append(f"{missing_toprule} table(s) missing \\toprule")
    if bad_hline:
        issues.append(f"{bad_hline} table(s) use \\hline (use booktabs instead)")

    if not issues:
        report.add("Tables: booktabs formatting", "PASS",
                   "All tables use booktabs commands.")
    else:
        report.add("Tables: booktabs formatting", "FAIL", "; ".join(issues))


def check_economic_magnitude(tex: str, report: AuditReport) -> None:
    """Check that results section discusses economic magnitudes."""
    # Find results section content
    m = re.search(r'\\section\{Results?(.*?)(?=\\section|\Z)', tex, re.DOTALL | re.IGNORECASE)
    if not m:
        report.add("Results: economic magnitude", "WARN",
                   "Results section not found; cannot check economic magnitude.")
        return

    results_text = m.group(0)
    magnitude_indicators = [
        "standard deviation", "\\times",
        "equivalent to", "corresponds to",
        "percent of", "% of the mean", "% of the sample",
        "SGD", "USD", "EUR", "\\$",
        "median", "p-value", "\\beta",
    ]
    found = sum(1 for ind in magnitude_indicators if ind.lower() in results_text.lower())
    if found >= 3:
        report.add("Results: economic magnitude", "PASS",
                   f"Economic magnitude indicators found ({found} instances).")
    elif found >= 1:
        report.add("Results: economic magnitude", "WARN",
                   f"Only {found} economic magnitude indicator(s) in results. "
                   "Every key coefficient needs magnitude: dollar effect, SD units, or % of mean.")
    else:
        report.add("Results: economic magnitude", "FAIL",
                   "No economic magnitude discussion detected in results section. "
                   "Add: 'This corresponds to approximately X% / $Y / Z standard deviations.'")


def check_cite_style(tex: str, report: AuditReport) -> None:
    """Warn if bare \\cite{} is used (should be \\citet or \\citep)."""
    bare_cites = re.findall(r'(?<!\\cite[tp])\\cite\{', tex)
    if not bare_cites:
        report.add("Citations: \\citet/\\citep style", "PASS",
                   "No bare \\cite{} found.")
    else:
        report.add("Citations: \\citet/\\citep style", "WARN",
                   f"{len(bare_cites)} bare \\cite{{}} usage(s). "
                   "Replace with \\citet{{}} (textual) or \\citep{{}} (parenthetical).")


def check_undefined_refs(tex_path: str, report: AuditReport) -> None:
    """Check .aux file for '??' indicating undefined references."""
    aux_path = tex_path.replace('.tex', '.aux')
    if not os.path.exists(aux_path):
        report.add("Compilation: undefined references", "WARN",
                   "No .aux file found -- compile the paper first.")
        return
    aux_text = Path(aux_path).read_text(encoding='utf-8', errors='replace')
    # Check for actual undefined cross-references: '??' in output text
    # or 'undefined' as a LaTeX warning word (not \@undefined which is a
    # standard internal macro used by the caption package and others).
    has_qq = '??' in aux_text
    # Only flag 'undefined' if it appears as a standalone word in a warning
    # context, not as part of \@undefined (a standard internal command).
    import re as _re
    has_undef_warn = bool(_re.search(
        r'(?<![\\@])\bundefined\b', aux_text, _re.IGNORECASE
    ))
    if has_qq or has_undef_warn:
        report.add("Compilation: undefined references", "FAIL",
                   "Found '??' or 'undefined' in .aux file. "
                   "Run: bibtex + pdflatex x2 to resolve.")
    else:
        report.add("Compilation: undefined references", "PASS",
                   "No undefined references in .aux file.")


def check_bib_coverage(tex: str, bib_path: Optional[str], report: AuditReport) -> None:
    if not bib_path:
        report.add("Bibliography: key coverage", "WARN",
                   "No .bib file provided; skipping bibliography check. "
                   "Pass --bib references.bib to enable.")
        return
    if not os.path.exists(bib_path):
        report.add("Bibliography: key coverage", "FAIL",
                   f"Bib file not found: {bib_path}")
        return

    cited = find_cites(tex)
    bib_keys = find_bib_keys(bib_path)
    missing = cited - bib_keys
    orphan = bib_keys - cited

    issues = []
    if missing:
        items = ", ".join(sorted(missing)[:6])
        issues.append(f"Cited but not in .bib: {items}")
    if len(orphan) > 10:
        issues.append(f"{len(orphan)} entries in .bib never cited (consider cleanup)")

    if not issues:
        report.add("Bibliography: key coverage", "PASS",
                   f"{len(cited)} cited, {len(bib_keys)} in .bib, all matched.")
    else:
        status = "FAIL" if missing else "WARN"
        report.add("Bibliography: key coverage", status, "; ".join(issues))


def check_forbidden_phrases(tex: str, report: AuditReport) -> None:
    """Warn on common QJE-banned phrases."""
    forbidden = [
        ("This paper studies", "Too weak -- state the finding instead."),
        ("In recent years", "Generic opener -- delete."),
        ("Many economists", "Vague -- cite specific papers."),
        ("Interestingly, we", "Let the result speak -- delete 'Interestingly'."),
        ("it is worth noting", "Delete filler phrase."),
        ("the table below", "Use \\ref{} instead of 'table below'."),
        ("the figure below", "Use \\ref{} instead of 'figure below'."),
        ("fail to reject", "Say 'find no significant effect' instead."),
        ("build upon", "Say what specifically you add over the prior paper."),
    ]
    found_issues = []
    for phrase, advice in forbidden:
        if phrase.lower() in tex.lower():
            found_issues.append(f"'{phrase}': {advice}")

    if not found_issues:
        report.add("Writing: forbidden phrases", "PASS", "No banned phrases found.")
    else:
        report.add("Writing: forbidden phrases", "WARN",
                   f"{len(found_issues)} banned phrase(s): " +
                   " | ".join(found_issues[:4]))


def check_conclusion_no_new_results(tex: str, report: AuditReport) -> None:
    """Warn if conclusion introduces equation or table references not in earlier sections."""
    m = re.search(r'\\section\{Conclusion(.*?)(?=\\clearpage|\\appendix|\Z)',
                  tex, re.DOTALL | re.IGNORECASE)
    if not m:
        report.add("Conclusion: no new results", "WARN",
                   "Conclusion section not found.")
        return

    conclusion_text = m.group(0)
    # New equations in conclusion are a red flag
    new_eqs = re.findall(r'\\begin\{equation\}', conclusion_text)
    if new_eqs:
        report.add("Conclusion: no new results", "FAIL",
                   f"{len(new_eqs)} new equation(s) in conclusion. "
                   "Conclusions should not introduce new results or derivations.")
    else:
        report.add("Conclusion: no new results", "PASS",
                   "No new equations in conclusion.")


################################################################################
# Report formatting
################################################################################

STATUS_ICON = {"PASS": "[PASS]", "WARN": "[WARN]", "FAIL": "[FAIL]"}

def format_report(report: AuditReport) -> str:
    lines = [
        "=" * 72,
        f"PAPER AUDIT REPORT: {report.tex_path}",
        "=" * 72,
        "",
    ]
    for c in report.checks:
        icon = STATUS_ICON[c.status]
        lines.append(f"  {icon:<7} {c.name}")
        lines.append(f"          {c.detail}")
        lines.append("")

    lines += [
        "-" * 72,
        f"  PASS: {report.n_pass}   WARN: {report.n_warn}   FAIL: {report.n_fail}",
        "-" * 72,
    ]
    if report.n_fail == 0 and report.n_warn == 0:
        lines.append("  All checks passed. Paper is audit-clean.")
    elif report.n_fail == 0:
        lines.append("  No FAIL items. Review WARN items before submission.")
    else:
        lines.append(f"  {report.n_fail} FAIL item(s) must be fixed before submission.")
    lines.append("=" * 72)
    return "\n".join(lines)


################################################################################
# Entry point
################################################################################

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Audit a LaTeX paper against QJE/JPE structural checklist."
    )
    parser.add_argument("tex_path", help="Path to the main .tex file.")
    parser.add_argument("--output", "-o", default=None,
                        help="Write report to this file (default: stdout).")
    parser.add_argument("--bib", default=None,
                        help="Path to .bib file for citation coverage check.")
    args = parser.parse_args()

    if not os.path.exists(args.tex_path):
        print(f"ERROR: File not found: {args.tex_path}", file=sys.stderr)
        sys.exit(1)

    tex = Path(args.tex_path).read_text(encoding='utf-8', errors='replace')
    tex_clean = strip_comments(tex)

    report = AuditReport(tex_path=args.tex_path)

    # Run all checks
    check_sections(tex_clean, report)
    check_abstract_length(tex_clean, report)
    check_jel_codes(tex_clean, report)
    check_label_ref_coverage(tex_clean, report)
    check_table_notes(tex_clean, report)
    check_booktabs(tex_clean, report)
    check_economic_magnitude(tex_clean, report)
    check_cite_style(tex_clean, report)
    check_undefined_refs(args.tex_path, report)
    check_bib_coverage(tex_clean, args.bib, report)
    check_forbidden_phrases(tex_clean, report)
    check_conclusion_no_new_results(tex_clean, report)

    output = format_report(report)

    if args.output:
        Path(args.output).write_text(output, encoding='utf-8')
        print(f"Report written to: {args.output}", file=sys.stderr)
    else:
        print(output)

    sys.exit(1 if report.n_fail > 0 else 0)


if __name__ == "__main__":
    main()
