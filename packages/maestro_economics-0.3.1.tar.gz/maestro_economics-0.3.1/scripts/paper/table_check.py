#!/usr/bin/env python3
"""table_check.py -- Check LaTeX table formatting against QJE/JPE standards.

For each .tex file in a directory (or a single .tex file):
    - Checks: \\toprule present
    - Checks: \\bottomrule present
    - Checks: \\midrule present
    - Checks: Note line present (\\textit{Notes} or \\begin{tablenotes} or minipage)
    - Checks: No naked \\hline (should use booktabs)
    - Checks: Column alignment specified in tabular env
    - Checks: Significance stars convention line present (* p<0.1 or similar)
    - Checks: Table has \\label{} for cross-referencing

Usage:
    python table_check.py tables_dir/
    python table_check.py 05-analysis/results/tables/
    python table_check.py single_table.tex [--output report.txt]

Output:
    table_name | checks_passed | status
    Exit code 0 if all tables PASS, 1 if any FAIL.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path


################################################################################
# Check definitions
################################################################################

@dataclass
class TableCheck:
    name: str
    status: str   # PASS | WARN | FAIL
    detail: str


@dataclass
class TableReport:
    filename: str
    checks: list[TableCheck] = field(default_factory=list)

    @property
    def status(self) -> str:
        if any(c.status == "FAIL" for c in self.checks):
            return "FAIL"
        if any(c.status == "WARN" for c in self.checks):
            return "WARN"
        return "PASS"


def find_table_blocks(tex: str) -> list[str]:
    """Extract \\begin{table}...\\end{table} blocks."""
    pattern = r'\\begin\{table[*]?\}(.*?)\\end\{table[*]?\}'
    return re.findall(pattern, tex, re.DOTALL)


def find_tabular_blocks(tex: str) -> list[str]:
    """Extract \\begin{tabular}...\\end{tabular} blocks."""
    pattern = r'\\begin\{tabular[x]?\}(\{[^}]+\})(.*?)\\end\{tabular[x]?\}'
    return re.findall(pattern, tex, re.DOTALL)


def check_single_table_tex(filepath: str) -> TableReport:
    """Check one .tex file that contains one or more table environments."""
    tex = Path(filepath).read_text(encoding='utf-8', errors='replace')
    # Strip comments
    tex_clean = re.sub(r'(?<!\\)%.*$', '', tex, flags=re.MULTILINE)

    filename = os.path.basename(filepath)
    report = TableReport(filename=filename)

    # Determine if this file wraps its own table environment or is a fragment
    table_blocks = find_table_blocks(tex_clean)
    tabular_blocks = find_tabular_blocks(tex_clean)

    if not table_blocks and not tabular_blocks:
        # Treat whole file as one table fragment
        report.checks.append(TableCheck(
            "table environment", "WARN",
            "No \\begin{table} or \\begin{tabular} found -- treating file as fragment."
        ))
        table_blocks = [tex_clean]

    # Check each table block
    all_pass = True
    for i, block in enumerate(table_blocks):
        suffix = f" (table {i+1})" if len(table_blocks) > 1 else ""

        # --- booktabs checks ---
        has_toprule = "\\toprule" in block
        has_bottomrule = "\\bottomrule" in block
        has_midrule = "\\midrule" in block
        has_hline = bool(re.search(r'\\hline', block))
        has_label = bool(re.search(r'\\label\{', block))
        has_note = bool(re.search(
            r'\\textit\{Notes?\}|\\textit\{Note:\}|\\note\{|'
            r'\\begin\{tablenotes\}|minipage|\\small\n.*Notes',
            block, re.IGNORECASE | re.DOTALL
        ))
        has_stars = bool(re.search(
            r'p\s*[<>]\s*0\.\d+|\\ast|\*\*\*|\$p\s*<\s*0',
            block
        ))

        # tabular alignment
        tab_match = re.search(r'\\begin\{tabular[x]?\}\{([^}]+)\}', block)
        has_alignment = tab_match is not None

        checks_and_results = [
            ("\\toprule", has_toprule, "FAIL",
             "Missing \\toprule -- add at start of tabular body."),
            ("\\bottomrule", has_bottomrule, "FAIL",
             "Missing \\bottomrule -- add at end of tabular body."),
            ("\\midrule", has_midrule, "WARN",
             "No \\midrule found -- add between header row and data rows."),
            ("no \\hline", not has_hline, "FAIL",
             "\\hline found -- replace with booktabs commands (\\toprule, \\midrule, \\bottomrule)."),
            ("\\label{}", has_label, "WARN",
             "No \\label{} -- table cannot be \\ref'd from text."),
            ("notes line", has_note, "FAIL",
             "No notes line (\\textit{Notes:} or tablenotes). "
             "Add: DV, FE, SE clustering, significance stars."),
            ("significance stars key", has_stars, "WARN",
             "No significance star key found. "
             "Add: *** $p<0.01$, ** $p<0.05$, * $p<0.1$ in notes."),
            ("tabular alignment", has_alignment, "WARN",
             "Could not verify column alignment specification."),
        ]

        for check_name, passed, fail_level, fail_msg in checks_and_results:
            if passed:
                status = "PASS"
                detail = "OK"
            else:
                status = fail_level
                detail = fail_msg
                if status == "FAIL":
                    all_pass = False
            report.checks.append(TableCheck(f"{check_name}{suffix}", status, detail))

    return report


################################################################################
# Report formatting
################################################################################

STATUS_ICON = {"PASS": "[PASS]", "WARN": "[WARN]", "FAIL": "[FAIL]"}


def format_reports(reports: list[TableReport]) -> str:
    lines = [
        "=" * 72,
        "TABLE FORMAT CHECK REPORT",
        "=" * 72,
        "",
    ]

    n_pass = n_warn = n_fail = 0
    for rep in reports:
        icon = STATUS_ICON[rep.status]
        lines.append(f"  {icon}  {rep.filename}")
        for chk in rep.checks:
            if chk.status != "PASS":
                chk_icon = STATUS_ICON[chk.status]
                lines.append(f"         {chk_icon:<7} {chk.name}: {chk.detail}")
        if rep.status == "PASS":
            lines.append("         All checks passed.")
            n_pass += 1
        elif rep.status == "WARN":
            n_warn += 1
        else:
            n_fail += 1
        lines.append("")

    lines += [
        "-" * 72,
        f"  Files PASS: {n_pass}   WARN: {n_warn}   FAIL: {n_fail}",
        "-" * 72,
    ]
    if n_fail == 0 and n_warn == 0:
        lines.append("  All tables format-clean.")
    elif n_fail == 0:
        lines.append("  No FAIL items. Review WARN items.")
    else:
        lines.append(f"  {n_fail} table file(s) have FAIL items -- fix before submission.")
    lines.append("=" * 72)
    return "\n".join(lines)


################################################################################
# Entry point
################################################################################

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Check LaTeX table formatting against QJE/JPE standards."
    )
    parser.add_argument("path",
                        help="Directory of .tex table files, or a single .tex file.")
    parser.add_argument("--output", "-o", default=None,
                        help="Write report to this file (default: stdout).")
    args = parser.parse_args()

    target_path = Path(args.path)

    if target_path.is_dir():
        tex_files = sorted(target_path.glob("*.tex"))
        if not tex_files:
            print(f"ERROR: No .tex files found in {args.path}", file=sys.stderr)
            sys.exit(1)
    elif target_path.is_file():
        tex_files = [target_path]
    else:
        print(f"ERROR: Path not found: {args.path}", file=sys.stderr)
        sys.exit(1)

    reports = [check_single_table_tex(str(f)) for f in tex_files]
    output = format_reports(reports)

    if args.output:
        Path(args.output).write_text(output, encoding='utf-8')
        print(f"Report written to: {args.output}", file=sys.stderr)
    else:
        print(output)

    any_fail = any(r.status == "FAIL" for r in reports)
    sys.exit(1 if any_fail else 0)


if __name__ == "__main__":
    main()
