#!/usr/bin/env python3
"""
fetch_gazetteer_pdfs.py -- Download county gazetteer PDFs from provincial websites.

PURPOSE:
    Enumerate and download county gazetteer (县志) PDFs from Chinese provincial
    gazetteer portals for use in the gazetteer OCR pipeline.

    Supported portals:
    - hljszw (Heilongjiang): https://www.hljszw.org.cn/booklist/42/1.html
      Mainly 二轮志书 (second-edition gazetteers, 1986-2005 coverage).

    Use --list to preview before downloading.

USAGE:
    # List all available gazetteers without downloading
    python fetch_gazetteer_pdfs.py hljszw --list

    # Download all Heilongjiang gazetteers to ./pdfs/
    python fetch_gazetteer_pdfs.py hljszw --output-dir ./pdfs/

    # Dry-run with verbose logging
    python fetch_gazetteer_pdfs.py hljszw --list --verbose

    # Skip already-downloaded files
    python fetch_gazetteer_pdfs.py hljszw --output-dir ./pdfs/ --skip-existing

    # Limit to N books (for testing)
    python fetch_gazetteer_pdfs.py hljszw --output-dir ./pdfs/ --limit 5

    # Custom delay between requests (default 2.0s)
    python fetch_gazetteer_pdfs.py hljszw --output-dir ./pdfs/ --delay 3.0

OUTPUT:
    Each downloaded PDF is saved as: {output_dir}/{stem}.pdf
    stem = sanitized book title (spaces/slashes replaced with underscores)

    A manifest CSV is written to: {output_dir}/manifest.csv
    Columns: stem, title, url, size_bytes, status

DEPENDENCIES:
    stdlib only (urllib, html.parser, re, csv, time, pathlib)

PORTALS:
    Portal configs live in _PORTALS dict. Each portal must provide:
        booklist_url_tpl: URL template with {page} placeholder
        max_pages:        upper bound on paginated listing pages
        parse_booklist:   callable(html) -> list[dict(title, detail_url)]
        parse_detail:     callable(html) -> str|None (pdf_url or None)
"""
from __future__ import annotations

import argparse
import csv
import io
import re
import sys
import time
from html.parser import HTMLParser
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
_TIMEOUT = 30


def _get(url: str, timeout: int = _TIMEOUT) -> Optional[str]:
    """Fetch URL and return decoded HTML, or None on failure."""
    req = Request(url, headers={"User-Agent": _UA})
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            # try UTF-8 first, fall back to gbk (common on .cn sites)
            for enc in ("utf-8", "gbk", "gb2312"):
                try:
                    return raw.decode(enc)
                except UnicodeDecodeError:
                    continue
            return raw.decode("utf-8", errors="replace")
    except (HTTPError, URLError, OSError) as exc:
        print(f"[WARN] GET failed: {url} -- {exc}", file=sys.stderr)
        return None


def _download(url: str, dest: Path, timeout: int = 120) -> Optional[int]:
    """Download binary to dest. Returns file size in bytes, or None on failure."""
    req = Request(url, headers={"User-Agent": _UA})
    try:
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read()
        dest.write_bytes(data)
        return len(data)
    except (HTTPError, URLError, OSError) as exc:
        print(f"[WARN] download failed: {url} -- {exc}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# HTML parser helpers
# ---------------------------------------------------------------------------

class _LinkParser(HTMLParser):
    """Extract (href, text) pairs from anchor tags."""

    def __init__(self) -> None:
        super().__init__()
        self.links: list[tuple[str, str]] = []
        self._in_a = False
        self._href: str = ""
        self._buf: list[str] = []

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag == "a":
            self._in_a = True
            self._buf = []
            self._href = dict(attrs).get("href", "")

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._in_a:
            self._in_a = False
            text = "".join(self._buf).strip()
            if self._href and text:
                self.links.append((self._href, text))

    def handle_data(self, data: str) -> None:
        if self._in_a:
            self._buf.append(data)


def _extract_links(html: str, base_url: str) -> list[tuple[str, str]]:
    """Return list of (absolute_url, link_text) from html."""
    p = _LinkParser()
    p.feed(html)
    return [(urljoin(base_url, href), text) for href, text in p.links]


def _sanitize(name: str) -> str:
    """Convert to safe filename stem."""
    name = re.sub(r"[/\\:*?\"<>|]", "_", name)
    name = re.sub(r"\s+", "_", name.strip())
    return name[:128]


# ---------------------------------------------------------------------------
# Portal: hljszw.org.cn (Heilongjiang Provincial Chronicles Office)
# ---------------------------------------------------------------------------
# Structure (observed 2026-02-28):
#   Booklist:  https://www.hljszw.org.cn/booklist/42/{page}.html
#   Detail:    https://www.hljszw.org.cn/bookinfo/{id}.html
#   PDF link:  present on detail page as <a href="...pdf...">
# ---------------------------------------------------------------------------

_HLJSZW_BASE = "https://www.hljszw.org.cn"


def _hljszw_parse_booklist(html: str, page_url: str) -> list[dict]:
    """Extract book records from a booklist page."""
    books = []
    links = _extract_links(html, page_url)
    for url, text in links:
        # detail pages match /bookinfo/\d+
        if re.search(r"/bookinfo/\d+", url):
            title = text.strip()
            if title and len(title) > 2:
                books.append({"title": title, "detail_url": url})
    return books


def _hljszw_parse_detail(html: str, detail_url: str) -> Optional[str]:
    """Extract PDF download URL from a bookinfo detail page."""
    links = _extract_links(html, detail_url)
    for url, text in links:
        if url.lower().endswith(".pdf"):
            return url
    # fallback: scan raw HTML for .pdf URLs
    m = re.search(r'href=["\']([^"\']*\.pdf)["\']', html, re.IGNORECASE)
    if m:
        return urljoin(detail_url, m.group(1))
    return None


_PORTALS: dict[str, dict] = {
    "hljszw": {
        "label": "Heilongjiang Provincial Chronicles (hljszw.org.cn)",
        "booklist_url_tpl": f"{_HLJSZW_BASE}/booklist/42/{{page}}.html",
        "max_pages": 20,
        "parse_booklist": _hljszw_parse_booklist,
        "parse_detail": _hljszw_parse_detail,
    },
}


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

def enumerate_books(portal_key: str, delay: float, verbose: bool) -> list[dict]:
    """Crawl the booklist pages and return list of book dicts."""
    cfg = _PORTALS[portal_key]
    all_books: list[dict] = []
    seen_titles: set[str] = set()

    for page in range(1, cfg["max_pages"] + 1):
        url = cfg["booklist_url_tpl"].format(page=page)
        if verbose:
            print(f"[INFO] booklist page {page}: {url}", file=sys.stderr)
        html = _get(url)
        if html is None:
            print(f"[INFO] page {page} unreachable, stopping pagination", file=sys.stderr)
            break

        books = cfg["parse_booklist"](html, url)
        new = [b for b in books if b["title"] not in seen_titles]
        if not new:
            if verbose:
                print(f"[INFO] page {page}: no new books, stopping", file=sys.stderr)
            break

        for b in new:
            seen_titles.add(b["title"])
        all_books.extend(new)
        print(f"[INFO] page {page}: +{len(new)} books (total {len(all_books)})", file=sys.stderr)

        if page < cfg["max_pages"]:
            time.sleep(delay)

    return all_books


def resolve_pdfs(books: list[dict], portal_key: str, delay: float, verbose: bool) -> list[dict]:
    """For each book, fetch detail page and resolve PDF URL."""
    cfg = _PORTALS[portal_key]
    for i, book in enumerate(books):
        if verbose:
            print(f"[INFO] resolving {i+1}/{len(books)}: {book['title']}", file=sys.stderr)
        html = _get(book["detail_url"])
        pdf_url = cfg["parse_detail"](html, book["detail_url"]) if html else None
        book["pdf_url"] = pdf_url
        if pdf_url is None:
            print(f"[WARN] no PDF found for: {book['title']}", file=sys.stderr)
        if i < len(books) - 1:
            time.sleep(delay)
    return books


def download_all(
    books: list[dict],
    output_dir: Path,
    skip_existing: bool,
    delay: float,
    verbose: bool,
) -> list[dict]:
    """Download PDFs and write manifest.csv."""
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / "manifest.csv"
    results = []

    for i, book in enumerate(books):
        stem = _sanitize(book["title"])
        dest = output_dir / f"{stem}.pdf"
        pdf_url = book.get("pdf_url")

        row = {"stem": stem, "title": book["title"], "url": pdf_url or "", "size_bytes": 0, "status": ""}

        if pdf_url is None:
            row["status"] = "no_pdf_url"
        elif skip_existing and dest.exists():
            row["status"] = "skipped"
            row["size_bytes"] = dest.stat().st_size
        else:
            if verbose:
                print(f"[INFO] downloading {i+1}/{len(books)}: {stem}", file=sys.stderr)
            size = _download(pdf_url, dest)
            if size is not None:
                row["status"] = "ok"
                row["size_bytes"] = size
            else:
                row["status"] = "download_failed"

        results.append(row)
        print(f"[{'OK' if row['status'] == 'ok' else row['status'].upper()}] {stem}", file=sys.stderr)
        if i < len(books) - 1:
            time.sleep(delay)

    # write manifest
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["stem", "title", "url", "size_bytes", "status"])
        w.writeheader()
        w.writerows(results)
    print(f"\n[INFO] manifest written to {manifest_path}", file=sys.stderr)
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Download county gazetteer PDFs from provincial portals.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "portal",
        choices=list(_PORTALS.keys()),
        help="Portal key. Currently supported: " + ", ".join(_PORTALS.keys()),
    )
    parser.add_argument("--output-dir", metavar="DIR", help="Directory to save PDFs + manifest")
    parser.add_argument("--list", action="store_true", help="Print book list without downloading")
    parser.add_argument("--skip-existing", action="store_true", help="Skip already-downloaded PDFs")
    parser.add_argument("--limit", type=int, metavar="N", help="Process only first N books")
    parser.add_argument("--delay", type=float, default=2.0, metavar="SEC", help="Delay between requests (default 2.0)")
    parser.add_argument("--verbose", action="store_true", help="Verbose logging")
    args = parser.parse_args()

    if not args.list and not args.output_dir:
        parser.error("--output-dir is required unless --list is specified")

    cfg = _PORTALS[args.portal]
    print(f"[INFO] portal: {cfg['label']}", file=sys.stderr)

    # Phase 1: enumerate
    books = enumerate_books(args.portal, args.delay, args.verbose)
    if args.limit:
        books = books[: args.limit]

    # Phase 2: resolve PDF URLs
    if not args.list:
        books = resolve_pdfs(books, args.portal, args.delay, args.verbose)

    # Output / download
    if args.list:
        writer = csv.DictWriter(sys.stdout, fieldnames=["title", "detail_url"])
        writer.writeheader()
        for b in books:
            writer.writerow({"title": b["title"], "detail_url": b["detail_url"]})
        print(f"\n# Total: {len(books)} books", file=sys.stderr)
    else:
        output_dir = Path(args.output_dir)
        results = download_all(books, output_dir, args.skip_existing, args.delay, args.verbose)
        ok = sum(1 for r in results if r["status"] == "ok")
        print(f"\n[DONE] {ok}/{len(results)} PDFs downloaded to {output_dir}", file=sys.stderr)


if __name__ == "__main__":
    main()
