#!/usr/bin/env python3
"""
vlm_extract.py -- VLM-based table extraction via OpenRouter.

PURPOSE:
    Extract tabular data from a single image (PNG/JPG) using a vision-language
    model via OpenRouter. Default model is Qwen3-VL-235B-thinking (free tier).
    Also supports batch processing of a directory of images.

USAGE:
    Single image:
    python vlm_extract.py INPUT_IMAGE [OPTIONS]

    python vlm_extract.py page.png
    python vlm_extract.py page.png --output table.csv
    python vlm_extract.py page.png --model qwen/qwen3-vl-30b-a3b-thinking
    python vlm_extract.py page.png --prompt my_prompt.txt

    Batch mode:
    python vlm_extract.py --input-dir ./pages --output-dir ./csvs
    python vlm_extract.py --input-dir ./pages --output-dir ./csvs --workers 8
    python vlm_extract.py --input-dir ./pages --output-dir ./csvs --skip-existing

ENVIRONMENT:
    OPENROUTER_API_KEY   OpenRouter API key (optional; uses free anonymous
                         tier if absent, but rate limits are much stricter)
    VLM_MODEL            Override default model (same as --model flag)

MODEL NOTES (2026-02-27):
    Free:  qwen/qwen3-vl-235b-a22b-thinking   (DEFAULT -- 235B, Alibaba provider)
    Fast:  qwen/qwen3-vl-30b-a3b-thinking     (30B, still free)
    Paid:  qwen/qwen3-vl-235b-a22b-instruct   ($0.20/$0.88 per M tokens)
    NOTE: Do NOT add :free suffix -- it returns 404 on OpenRouter.
    Provider is pinned to "alibaba" to avoid silent rerouting to SiliconFlow.

ALGORITHM:
    1. Read image file as bytes (PNG/JPG both accepted).
    2. Base64-encode and embed as data URI in the OpenRouter API payload.
    3. POST to https://openrouter.ai/api/v1/chat/completions.
    4. Strip <think>...</think> blocks from response (reasoning-mode artefact).
    5. Strip ```csv ... ``` code fence wrappers if present.
    6. Validate that response contains CSV-like content (comma or newline).
    7. Write result to --output file or stdout.

DEPENDENCIES:
    Pillow   (pip install Pillow)   -- image loading + PNG conversion
    requests NOT required; uses stdlib urllib only
"""
from __future__ import annotations

import argparse
import base64
import concurrent.futures
import io
import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "qwen/qwen3-vl-235b-a22b-thinking"

DEFAULT_PROMPT = (
    "Extract all data from the table in this image into CSV format.\n"
    "Rules:\n"
    "- Output ONLY the CSV, no explanation, no markdown fences.\n"
    "- First row is the header.\n"
    "- Preserve all numeric values exactly as shown.\n"
    "- Use comma as delimiter.\n"
    "- If a cell is empty, leave it blank (two consecutive commas).\n"
    "- Do not merge or skip rows."
)

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

# Regex to strip <think>...</think> blocks (reasoning-model artefact).
_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)

# ---------------------------------------------------------------------------
# Core functions (importable as a module)
# ---------------------------------------------------------------------------


def strip_thinking(text: str) -> str:
    """Remove <think>...</think> blocks emitted by reasoning-mode VLMs."""
    return _THINK_RE.sub("", text).strip()


def strip_code_fence(text: str) -> str:
    """Remove ```csv ... ``` or ``` ... ``` wrappers from model output."""
    text = (text or "").strip()
    if text.startswith("```"):
        lines = text.split("\n")[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text


def image_to_png_bytes(image_path: str) -> bytes:
    """Load any image format and return PNG bytes.

    Converts JPEG/TIFF/etc to PNG so the API always receives a consistent
    format regardless of source file extension.

    Args:
        image_path: Path to input image file.

    Returns:
        PNG-encoded bytes.

    Raises:
        ImportError: If Pillow is not installed.
        FileNotFoundError: If the image file does not exist.
    """
    try:
        from PIL import Image
    except ImportError:
        raise ImportError(
            "Pillow is required: pip install Pillow"
        )

    path = Path(image_path)
    if not path.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    with Image.open(path) as img:
        # Convert to RGB if necessary (e.g. RGBA, palette-mode images)
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()


def call_openrouter_vision(
    png_bytes: bytes,
    prompt: str,
    model: str = DEFAULT_MODEL,
    api_key: str = "",
    timeout: int = 120,
    pin_provider: str = "alibaba",
) -> str:
    """Call an OpenRouter vision model and return the raw text response.

    Args:
        png_bytes: PNG image bytes (will be base64-encoded).
        prompt: Instruction text sent to the model.
        model: OpenRouter model identifier string.
        api_key: Bearer token for OpenRouter (empty = anonymous free tier).
        timeout: HTTP request timeout in seconds.
        pin_provider: Provider slug to pin (avoids silent rerouting).
                      Set to "" to allow fallbacks.

    Returns:
        Raw model response text (thinking tokens NOT yet stripped).

    Raises:
        urllib.error.HTTPError: On HTTP errors (rate limit, auth, etc).
        urllib.error.URLError: On network errors.
        ValueError: If the API response has no 'choices'.
    """
    image_b64 = base64.b64encode(png_bytes).decode("utf-8")
    data_uri = f"data:image/png;base64,{image_b64}"

    payload: dict = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": data_uri}},
                ],
            }
        ],
    }

    # Pin provider to avoid silent rerouting (e.g. Alibaba -> SiliconFlow).
    if pin_provider:
        payload["provider"] = {
            "order": [pin_provider],
            "allow_fallbacks": False,
        }

    headers: dict = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    req = urllib.request.Request(
        OPENROUTER_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    if "choices" not in data or not data["choices"]:
        raise ValueError(f"No choices in OpenRouter response: {data}")

    return (data["choices"][0]["message"]["content"] or "").strip()


def extract_table(
    image_path: str,
    prompt: str = DEFAULT_PROMPT,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout: int = 120,
    pin_provider: str = "alibaba",
) -> dict:
    """Extract tabular data from an image using a VLM via OpenRouter.

    This is the primary programmatic entry point when using vlm_extract as
    a module.

    Args:
        image_path: Path to input image (PNG, JPG, TIFF, etc).
        prompt: Extraction instruction to send with the image.
        model: OpenRouter model ID; defaults to DEFAULT_MODEL or VLM_MODEL env.
        api_key: OpenRouter API key; defaults to OPENROUTER_API_KEY env.
        timeout: HTTP timeout in seconds.
        pin_provider: Provider slug to pin (use "" to allow fallbacks).

    Returns:
        Dict with keys:
            success (bool): True if valid CSV was extracted.
            csv_text (str): Extracted CSV content (empty on failure).
            raw_output (str): Full raw model response.
            error (str | None): Error description on failure.
            model (str): Model used.
    """
    resolved_model = model or os.environ.get("VLM_MODEL", DEFAULT_MODEL)
    resolved_key = api_key if api_key is not None else os.environ.get("OPENROUTER_API_KEY", "")

    try:
        png_bytes = image_to_png_bytes(image_path)
    except (ImportError, FileNotFoundError, OSError) as e:
        return {
            "success": False,
            "csv_text": "",
            "raw_output": "",
            "error": str(e),
            "model": resolved_model,
        }

    try:
        raw = call_openrouter_vision(
            png_bytes=png_bytes,
            prompt=prompt,
            model=resolved_model,
            api_key=resolved_key,
            timeout=timeout,
            pin_provider=pin_provider,
        )
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = str(e)
        return {
            "success": False,
            "csv_text": "",
            "raw_output": "",
            "error": f"HTTP {e.code}: {body[:500]}",
            "model": resolved_model,
        }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "csv_text": "",
            "raw_output": "",
            "error": f"Network error: {e}",
            "model": resolved_model,
        }
    except Exception as e:
        return {
            "success": False,
            "csv_text": "",
            "raw_output": "",
            "error": f"Unexpected: {e}",
            "model": resolved_model,
        }

    # Post-process: strip thinking tokens then code fence wrappers.
    cleaned = strip_thinking(raw)
    csv_text = strip_code_fence(cleaned)

    # Validate: must contain comma or newline to be plausible CSV.
    if not csv_text or ("," not in csv_text and "\n" not in csv_text):
        return {
            "success": False,
            "csv_text": "",
            "raw_output": raw,
            "error": "Response does not appear to be CSV",
            "model": resolved_model,
        }

    return {
        "success": True,
        "csv_text": csv_text,
        "raw_output": raw,
        "error": None,
        "model": resolved_model,
    }


# ---------------------------------------------------------------------------
# Batch processing
# ---------------------------------------------------------------------------


def process_batch(
    input_dir: str,
    output_dir: str,
    prompt: str = DEFAULT_PROMPT,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout: int = 120,
    pin_provider: str = "alibaba",
    workers: int = 4,
    skip_existing: bool = False,
) -> dict:
    """Process all PNG/JPG images in input_dir and write one CSV per image to output_dir.

    Args:
        input_dir: Directory containing input images (PNG/JPG/JPEG).
        output_dir: Directory to write output CSV files. Created if absent.
        prompt: Extraction instruction passed to the VLM.
        model: OpenRouter model ID; defaults to DEFAULT_MODEL or VLM_MODEL env.
        api_key: OpenRouter API key; defaults to OPENROUTER_API_KEY env.
        timeout: HTTP timeout in seconds per image.
        pin_provider: Provider slug to pin (use "" to allow fallbacks).
        workers: Number of parallel threads.
        skip_existing: If True, skip images that already have a .csv in output_dir.

    Returns:
        Dict with keys:
            ok (int): Number of images successfully processed.
            fail (int): Number of images that failed.
            skipped (int): Number of images skipped (skip_existing).
            total (int): Total images found.
    """
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    images = (
        sorted(input_path.glob("*.png"))
        + sorted(input_path.glob("*.jpg"))
        + sorted(input_path.glob("*.jpeg"))
        + sorted(input_path.glob("*.PNG"))
        + sorted(input_path.glob("*.JPG"))
        + sorted(input_path.glob("*.JPEG"))
    )
    # Deduplicate (case-insensitive glob may produce duplicates on some systems)
    seen: set = set()
    unique_images = []
    for img in images:
        key = img.resolve()
        if key not in seen:
            seen.add(key)
            unique_images.append(img)
    images = unique_images

    total = len(images)
    skipped = 0

    if skip_existing:
        remaining = [img for img in images if not (output_path / f"{img.stem}.csv").exists()]
        skipped = total - len(remaining)
        images = remaining

    print(
        f"Processing {len(images)} images with {workers} workers"
        + (f" ({skipped} skipped)" if skipped else "")
        + "...",
        file=sys.stderr,
    )

    results = {"ok": 0, "fail": 0}

    def process_one(img_path: Path) -> str:
        out_path = output_path / f"{img_path.stem}.csv"
        result = extract_table(
            image_path=str(img_path),
            prompt=prompt,
            model=model,
            api_key=api_key,
            timeout=timeout,
            pin_provider=pin_provider,
        )
        if result["success"]:
            out_path.write_text(result["csv_text"], encoding="utf-8")
            return "ok"
        else:
            print(f"FAIL {img_path.name}: {result['error']}", file=sys.stderr)
            return "fail"

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        for r in executor.map(process_one, images):
            results[r] += 1

    print(f"Done: {results['ok']} ok, {results['fail']} fail", file=sys.stderr)

    return {
        "ok": results["ok"],
        "fail": results["fail"],
        "skipped": skipped,
        "total": total,
    }


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vlm_extract",
        description=(
            "Extract tabular data from an image using a vision-language model "
            "via OpenRouter (default: Qwen3-VL-235B-thinking, free tier). "
            "Supports single-image mode (positional INPUT_IMAGE) and batch mode "
            "(--input-dir / --output-dir)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # Single-image positional argument (optional so batch mode works without it).
    parser.add_argument(
        "image",
        metavar="INPUT_IMAGE",
        nargs="?",
        default=None,
        help=(
            "Path to input image file (PNG, JPG, TIFF, etc). "
            "Mutually exclusive with --input-dir."
        ),
    )
    parser.add_argument(
        "--output", "-o",
        metavar="OUTPUT.csv",
        help="Write CSV to this file instead of stdout (single-image mode only).",
    )

    # Batch mode arguments.
    batch_group = parser.add_argument_group("batch mode (--input-dir / --output-dir)")
    batch_group.add_argument(
        "--input-dir",
        metavar="DIR",
        help=(
            "Process all PNG/JPG images in DIR. "
            "Mutually exclusive with positional INPUT_IMAGE."
        ),
    )
    batch_group.add_argument(
        "--output-dir",
        metavar="DIR",
        help=(
            "Write one CSV per image to this directory (filename: {stem}.csv). "
            "Required when --input-dir is used."
        ),
    )
    batch_group.add_argument(
        "--workers",
        type=int,
        default=4,
        metavar="N",
        help="Number of parallel threads for batch mode (default: 4).",
    )
    batch_group.add_argument(
        "--skip-existing",
        action="store_true",
        help=(
            "Skip images that already have a .csv in --output-dir. "
            "Useful for resumable batch runs."
        ),
    )
    parser.add_argument(
        "--model", "-m",
        default=None,
        metavar="MODEL",
        help=(
            f"OpenRouter model ID (default: {DEFAULT_MODEL}). "
            "Can also be set via VLM_MODEL env var."
        ),
    )
    parser.add_argument(
        "--prompt", "-p",
        metavar="PROMPT_FILE",
        help=(
            "Path to a plain-text file containing the extraction prompt. "
            "If omitted, uses the built-in default CSV extraction prompt."
        ),
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        metavar="SECONDS",
        help="HTTP request timeout in seconds (default: 120).",
    )
    parser.add_argument(
        "--no-pin-provider",
        action="store_true",
        help=(
            "Allow OpenRouter to route to any provider. Default pins to "
            "'alibaba' to ensure Qwen3-VL runs on the correct backend."
        ),
    )
    parser.add_argument(
        "--raw",
        action="store_true",
        help="Print the full raw model response to stderr (for debugging).",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Validate: exactly one of (image, --input-dir) must be provided.
    if args.image and args.input_dir:
        parser.error("INPUT_IMAGE and --input-dir are mutually exclusive.")
    if not args.image and not args.input_dir:
        parser.error("Provide either INPUT_IMAGE (single mode) or --input-dir (batch mode).")
    if args.input_dir and not args.output_dir:
        parser.error("--output-dir is required when --input-dir is used.")

    # Resolve prompt.
    if args.prompt:
        prompt_path = Path(args.prompt)
        if not prompt_path.exists():
            print(f"ERROR: Prompt file not found: {args.prompt}", file=sys.stderr)
            sys.exit(1)
        prompt = prompt_path.read_text(encoding="utf-8").strip()
    else:
        prompt = DEFAULT_PROMPT

    pin_provider = "" if args.no_pin_provider else "alibaba"

    # -----------------------------------------------------------------------
    # Batch mode
    # -----------------------------------------------------------------------
    if args.input_dir:
        summary = process_batch(
            input_dir=args.input_dir,
            output_dir=args.output_dir,
            prompt=prompt,
            model=args.model,
            timeout=args.timeout,
            pin_provider=pin_provider,
            workers=args.workers,
            skip_existing=args.skip_existing,
        )
        if summary["fail"] > 0:
            sys.exit(1)
        return

    # -----------------------------------------------------------------------
    # Single-image mode
    # -----------------------------------------------------------------------
    result = extract_table(
        image_path=args.image,
        prompt=prompt,
        model=args.model,
        timeout=args.timeout,
        pin_provider=pin_provider,
    )

    if args.raw:
        print("[RAW OUTPUT]", file=sys.stderr)
        print(result["raw_output"], file=sys.stderr)
        print("[END RAW]", file=sys.stderr)

    if not result["success"]:
        print(f"ERROR: {result['error']}", file=sys.stderr)
        print(f"Model: {result['model']}", file=sys.stderr)
        sys.exit(1)

    csv_text = result["csv_text"]
    if args.output:
        out_path = Path(args.output)
        out_path.write_text(csv_text, encoding="utf-8")
        print(f"Wrote {len(csv_text.splitlines())} rows to {out_path}", file=sys.stderr)
    else:
        sys.stdout.write(csv_text)
        if not csv_text.endswith("\n"):
            sys.stdout.write("\n")


if __name__ == "__main__":
    main()
