#!/usr/bin/env python3
"""
arithmetic_grade.py -- Arithmetic cross-validation for numeric data tables.

PURPOSE:
    Verify that extracted tabular data satisfies row-level arithmetic constraints.
    Designed for agricultural/statistical tables where: area * yield / unit = total.
    Assigns each row a quality grade based on how close the computed value is to
    the reported total.

USAGE:
    python arithmetic_grade.py INPUT.csv [OPTIONS]

    python arithmetic_grade.py extracted.csv
    python arithmetic_grade.py extracted.csv --output graded.csv
    python arithmetic_grade.py data.csv --area-col planted_area --yield-col yield_per_mu --total-col total_output
    python arithmetic_grade.py data.csv --unit-factor 10000
    python arithmetic_grade.py data.csv --unit-col unit_header

GRADE SYSTEM (4 levels):
    exact    error < 0.5%  -- within rounding tolerance
    pass     error < 2.0%  -- acceptable (original-source rounding)
    marginal error < 5.0%  -- needs human confirmation
    fail     error >= 5.0% -- likely OCR error or wrong column mapping
    skip     any required value is missing or zero

UNIT FACTOR AUTO-DETECTION:
    Searches column names and header text for Chinese unit keywords:
      万斤 -> 10000,  担 -> 100,  吨 -> 2000 (1 ton = 2000 jin),
      千斤 -> 1000,   百斤 -> 100, 公斤 -> 2, 斤 -> 1
    Default unit factor: 10000 (万斤) if no keyword found.

OUTPUT:
    Original CSV with two appended columns: grade, error_pct.
    Summary statistics printed to stderr.

DEPENDENCIES:
    pandas   (pip install pandas)
    numpy    (pip install numpy)

ALGORITHM:
    For each row:
        expected = area * yield / unit_factor
        error_pct = |expected - total| / total * 100
        grade based on error_pct thresholds above.
    Rows with null/zero values in any of area, yield, total are graded 'skip'.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Grade constants
# ---------------------------------------------------------------------------

# Chinese unit keywords used in table headers mapped to jin (斤) equivalents.
UNIT_KEYWORDS: dict[str, int] = {
    "万公斤": 10000000,   # 10M jin (万公斤 = 10k kg = 10M 斤)
    "万斤": 10000,        # 10k jin
    "千斤": 1000,         # 1k jin
    "百斤": 100,
    "公斤": 2,            # 1 kg = 2 jin
    "吨": 2000,           # 1 ton = 2000 jin
    "担": 100,            # 1 dan = 100 jin
    "斤": 1,
}

# Grade thresholds (error percentage, exclusive upper bound).
GRADE_THRESHOLDS: list[tuple[str, float]] = [
    ("exact",    0.5),
    ("pass",     2.0),
    ("marginal", 5.0),
]
# Anything >= 5.0% is 'fail'.

GRADE_ORDER = ["exact", "pass", "marginal", "fail", "skip"]

# ---------------------------------------------------------------------------
# Core functions (importable as a module)
# ---------------------------------------------------------------------------


def detect_unit_factor(header_text: str) -> int:
    """Detect unit factor from a header or column name string.

    Searches for known Chinese unit keywords (longest match first to avoid
    partial matches, e.g. 万斤 before 斤).

    Args:
        header_text: Column name or table header text (may be Chinese).

    Returns:
        Integer unit factor. Default 10000 (万斤) if no keyword found.
    """
    for keyword in sorted(UNIT_KEYWORDS, key=len, reverse=True):
        if keyword in header_text:
            return UNIT_KEYWORDS[keyword]
    return 10000


def arithmetic_grade_row(
    area: Optional[float],
    yield_val: Optional[float],
    total: Optional[float],
    unit_factor: int = 10000,
) -> tuple[str, Optional[float], Optional[float]]:
    """Compute arithmetic grade for a single row.

    Formula: area * yield_val / unit_factor ~= total

    Args:
        area: First multiplicand (e.g. planted area in mu).
        yield_val: Second multiplicand (e.g. yield per mu in jin/mu).
        total: Reported total (in units defined by unit_factor).
        unit_factor: Denominator that converts area*yield to total units.

    Returns:
        Tuple of (grade, error_pct, expected_total):
            grade (str): 'exact' | 'pass' | 'marginal' | 'fail' | 'skip'
            error_pct (float | None): Absolute percentage error, or None if skip.
            expected_total (float | None): Computed expected total, or None if skip.
    """
    if area is None or yield_val is None or total is None:
        return ("skip", None, None)
    try:
        area_f = float(area)
        yield_f = float(yield_val)
        total_f = float(total)
    except (ValueError, TypeError):
        return ("skip", None, None)

    if area_f == 0 or yield_f == 0 or total_f == 0:
        return ("skip", None, None)

    expected = area_f * yield_f / unit_factor
    error_pct = abs(expected - total_f) / total_f * 100

    grade = "fail"
    for name, threshold in GRADE_THRESHOLDS:
        if error_pct < threshold:
            grade = name
            break

    return (grade, round(error_pct, 2), round(expected, 2))


def grade_dataframe(
    df,
    area_col: str,
    yield_col: str,
    total_col: str,
    unit_factor: int = 10000,
    unit_col: Optional[str] = None,
) -> tuple:
    """Apply arithmetic grading to every row of a DataFrame.

    Args:
        df: pandas DataFrame with numeric data.
        area_col: Column name for area values.
        yield_col: Column name for yield-per-unit values.
        total_col: Column name for reported total values.
        unit_factor: Default unit factor (used when unit_col is None or
                     the column value has no recognisable keyword).
        unit_col: Optional column whose values contain unit keywords to
                  auto-detect per-row unit factors.

    Returns:
        Tuple of (graded_df, summary_dict):
            graded_df: DataFrame with 'grade' and 'error_pct' columns appended.
            summary_dict: Grade counts + overall statistics.
    """
    import numpy as np

    grades = []
    errors = []

    for _, row in df.iterrows():
        uf = unit_factor
        if unit_col and unit_col in df.columns:
            cell = str(row.get(unit_col, "") or "")
            detected = detect_unit_factor(cell)
            if detected != 10000 or cell:
                uf = detected

        area = row.get(area_col)
        yield_v = row.get(yield_col)
        total = row.get(total_col)

        # Convert to float, treating empty strings / non-numeric as None.
        def _to_float(v):
            if v is None:
                return None
            try:
                f = float(v)
                return None if np.isnan(f) else f
            except (ValueError, TypeError):
                return None

        grade, err, _ = arithmetic_grade_row(
            _to_float(area), _to_float(yield_v), _to_float(total), uf
        )
        grades.append(grade)
        errors.append(err)

    graded = df.copy()
    graded["grade"] = grades
    graded["error_pct"] = errors

    # Build summary.
    from collections import Counter
    counts = Counter(grades)
    gradeable = sum(counts.get(g, 0) for g in ["exact", "pass", "marginal", "fail"])
    passing = counts.get("exact", 0) + counts.get("pass", 0)
    pass_rate = passing / gradeable * 100 if gradeable > 0 else 0.0

    summary = {
        "total_rows": len(df),
        "gradeable": gradeable,
        "skipped": counts.get("skip", 0),
        "exact": counts.get("exact", 0),
        "pass": counts.get("pass", 0),
        "marginal": counts.get("marginal", 0),
        "fail": counts.get("fail", 0),
        "pass_rate_pct": round(pass_rate, 1),
    }

    return graded, summary


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="arithmetic_grade",
        description=(
            "Arithmetic cross-check for numeric tables. Verifies that "
            "area * yield / unit_factor ≈ total for each row, assigning "
            "a 4-level grade: exact / pass / marginal / fail."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "input",
        metavar="INPUT.csv",
        help="Input CSV file to validate.",
    )
    parser.add_argument(
        "--output", "-o",
        metavar="GRADED.csv",
        help=(
            "Write graded CSV to this file. "
            "If omitted, writes to stdout."
        ),
    )
    parser.add_argument(
        "--area-col",
        default="area",
        metavar="COL",
        help="Column name for area values (default: 'area').",
    )
    parser.add_argument(
        "--yield-col",
        default="yield_per_mu",
        metavar="COL",
        help="Column name for yield values (default: 'yield_per_mu').",
    )
    parser.add_argument(
        "--total-col",
        default="total",
        metavar="COL",
        help="Column name for reported total values (default: 'total').",
    )
    parser.add_argument(
        "--unit-factor",
        type=int,
        default=10000,
        metavar="N",
        help=(
            "Unit conversion factor: area * yield / unit_factor = total. "
            "Default: 10000 (万斤). Overridden per-row by --unit-col if set."
        ),
    )
    parser.add_argument(
        "--unit-col",
        default=None,
        metavar="COL",
        help=(
            "Column whose values contain unit keywords (e.g. '万斤', '担'). "
            "If set, the unit factor is auto-detected per row from this column."
        ),
    )
    parser.add_argument(
        "--no-summary",
        action="store_true",
        help="Suppress the grade summary printed to stderr.",
    )
    return parser


def main() -> None:
    try:
        import pandas as pd
    except ImportError:
        print("ERROR: pandas is required: pip install pandas numpy", file=sys.stderr)
        sys.exit(1)

    parser = build_parser()
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    try:
        df = pd.read_csv(input_path, dtype=str)
    except Exception as e:
        print(f"ERROR: Could not read CSV: {e}", file=sys.stderr)
        sys.exit(1)

    # Validate column presence.
    missing = []
    for col_arg, col_name in [
        ("--area-col", args.area_col),
        ("--yield-col", args.yield_col),
        ("--total-col", args.total_col),
    ]:
        if col_name not in df.columns:
            missing.append(f"{col_arg} '{col_name}'")
    if args.unit_col and args.unit_col not in df.columns:
        missing.append(f"--unit-col '{args.unit_col}'")

    if missing:
        print(
            f"ERROR: Columns not found in CSV: {', '.join(missing)}\n"
            f"Available columns: {list(df.columns)}",
            file=sys.stderr,
        )
        sys.exit(1)

    graded, summary = grade_dataframe(
        df=df,
        area_col=args.area_col,
        yield_col=args.yield_col,
        total_col=args.total_col,
        unit_factor=args.unit_factor,
        unit_col=args.unit_col,
    )

    # Output CSV.
    csv_str = graded.to_csv(index=False)
    if args.output:
        Path(args.output).write_text(csv_str, encoding="utf-8")
        print(f"Wrote {len(graded)} rows to {args.output}", file=sys.stderr)
    else:
        sys.stdout.write(csv_str)

    # Summary.
    if not args.no_summary:
        print("\n--- Grade Summary ---", file=sys.stderr)
        print(f"Total rows   : {summary['total_rows']}", file=sys.stderr)
        print(f"Gradeable    : {summary['gradeable']}", file=sys.stderr)
        print(f"Skipped      : {summary['skipped']}", file=sys.stderr)
        print(f"  exact      : {summary['exact']}", file=sys.stderr)
        print(f"  pass       : {summary['pass']}", file=sys.stderr)
        print(f"  marginal   : {summary['marginal']}", file=sys.stderr)
        print(f"  fail       : {summary['fail']}", file=sys.stderr)
        print(f"Pass rate    : {summary['pass_rate_pct']}%  (exact+pass / gradeable)", file=sys.stderr)


if __name__ == "__main__":
    main()
