#!/usr/bin/env python3
"""
audit_html.py — Self-contained SVG chart generators for document extraction audits.

PURPOSE:
    Reusable building blocks for generating per-document audit HTML pages.
    Extracted from RAD-20260211-0001 county gazetteer OCR pipeline.

    Provides:
      - grade_color(grade)            → CSS class name for 4-grade system
      - grade_heatmap_color(grade)    → hex color for SVG heatmap cells
      - generate_heatmap_svg(...)     → crop × year coverage heatmap SVG
      - generate_line_chart_svg(...)  → time-series line chart SVG
      - AUDIT_CSS                     → baseline CSS for audit HTML pages

GRADE SYSTEM (4-level, matches arithmetic_grade.py):
    exact    < 0.5% error  → green  (#4CAF50)
    pass     < 2.0% error  → green
    marginal < 5.0% error  → orange (#FF9800)
    fail     ≥ 5.0% error  → red    (#f44336)
    skip     missing data  → gray   (#E0E0E0)

TYPICAL USAGE:
    from audit_html import generate_heatmap_svg, generate_line_chart_svg, AUDIT_CSS

    svg = generate_heatmap_svg(
        crops=["wheat", "corn"],
        years=[1970, 1971, 1972],
        matrix={("wheat", 1970): "exact", ("corn", 1971): "fail"},
    )

    chart = generate_line_chart_svg(
        crop_year_data={"wheat": {1970: 120.5, 1971: 118.2}},
    )

    html = f"<html><head><style>{AUDIT_CSS}</style></head><body>{svg}{chart}</body></html>"

    # With custom crop label translation:
    cn_names = {"wheat": "小麦", "corn": "玉米"}
    svg_cn = generate_heatmap_svg(
        crops=["wheat", "corn"],
        years=list(range(1970, 1986)),
        matrix=data_matrix,
        label_fn=lambda crop: cn_names.get(crop, crop),
    )

DEPENDENCIES:
    None (pure Python stdlib + string formatting only).
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Grade → color mappings
# ---------------------------------------------------------------------------

def grade_color(grade: str) -> str:
    """Return CSS class name for a 4-level arithmetic grade."""
    g = grade.lower()
    if g in ("exact", "pass"):  return "grade-pass"
    if g == "marginal":         return "grade-marginal"
    if g == "fail":             return "grade-fail"
    return "grade-skip"


def grade_heatmap_color(grade: str) -> str:
    """Return SVG fill hex color for a 4-level arithmetic grade."""
    g = grade.lower()
    if g in ("exact", "pass"):  return "#4CAF50"
    if g == "marginal":         return "#FF9800"
    if g == "fail":             return "#f44336"
    return "#E0E0E0"


# ---------------------------------------------------------------------------
# Heatmap SVG: crop × year coverage
# ---------------------------------------------------------------------------

def generate_heatmap_svg(
    crops: List[str],
    years: List[int],
    matrix: Dict[Tuple[str, int], str],
    label_fn: Optional[Callable[[str], str]] = None,
    cell_width: int = 20,
    cell_height: int = 20,
    label_width: int = 100,
) -> str:
    """
    Generate an inline SVG heatmap showing extraction grade by crop × year.

    Args:
        crops:       List of crop identifiers (any string — used as row keys).
        years:       List of years (int) — used as column keys.
        matrix:      Dict keyed by (crop, year) → grade string.
                     Missing keys are treated as 'skip'.
        label_fn:    Optional function(crop) → display label.
                     Defaults to identity (crop name as-is).
        cell_width:  Width in px of each matrix cell (default 20).
        cell_height: Height in px of each matrix cell (default 20).
        label_width: Width in px reserved for row labels (default 100).

    Returns:
        SVG string (no <html> wrapper — embed directly in HTML body).
    """
    if not crops or not years:
        return "<p>No data</p>"

    _label = label_fn or (lambda x: x)

    width  = label_width + len(years) * cell_width + 40
    height = len(crops) * cell_height + 60

    parts = [
        f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">',
        f'<rect width="{width}" height="{height}" fill="#f9f9f9"/>',
    ]

    # Cells
    for i, crop in enumerate(crops):
        for j, year in enumerate(years):
            x     = label_width + j * cell_width
            y     = 40 + i * cell_height
            grade = matrix.get((crop, year), "skip")
            color = grade_heatmap_color(grade)
            parts.append(
                f'<rect x="{x}" y="{y}" width="{cell_width}" height="{cell_height}" '
                f'fill="{color}" stroke="#fff" stroke-width="1"/>'
            )

    # Y-axis labels
    for i, crop in enumerate(crops):
        y    = 40 + i * cell_height + cell_height / 2 + 5
        text = _label(crop)
        parts.append(
            f'<text x="{label_width - 5}" y="{y}" text-anchor="end" '
            f'font-size="12" font-family="sans-serif" fill="#333">{text}</text>'
        )

    # X-axis labels (every 5th year)
    for j, year in enumerate(years):
        if j % 5 == 0 or j == len(years) - 1:
            x = label_width + j * cell_width + cell_width / 2
            parts.append(
                f'<text x="{x}" y="30" text-anchor="middle" '
                f'font-size="11" font-family="sans-serif" fill="#555">{year}</text>'
            )

    # Legend
    legend_y = height - 20
    legend_items = [
        ("exact/pass", "#4CAF50"),
        ("marginal",   "#FF9800"),
        ("fail",       "#f44336"),
        ("skip",       "#E0E0E0"),
    ]
    for idx, (lbl, color) in enumerate(legend_items):
        lx = label_width + idx * 90
        parts.append(f'<rect x="{lx}" y="{legend_y}" width="15" height="15" fill="{color}"/>')
        parts.append(
            f'<text x="{lx + 20}" y="{legend_y + 12}" font-size="11" '
            f'font-family="sans-serif" fill="#555">{lbl}</text>'
        )

    parts.append("</svg>")
    return "".join(parts)


# ---------------------------------------------------------------------------
# Line chart SVG: production / value time series by entity
# ---------------------------------------------------------------------------

# 15 distinct colors for up to 15 series lines
LINE_COLORS = [
    "#2196F3", "#F44336", "#4CAF50", "#FF9800", "#9C27B0",
    "#00BCD4", "#795548", "#E91E63", "#3F51B5", "#009688",
    "#FF5722", "#607D8B", "#CDDC39", "#FFC107", "#8BC34A",
]


def generate_line_chart_svg(
    crop_year_data: Dict[str, Dict[int, float]],
    label_fn: Optional[Callable[[str], str]] = None,
    title: str = "Annual production by crop",
    chart_width: int = 900,
    chart_height: int = 400,
    margin_left: int = 80,
    margin_right: int = 150,
    margin_top: int = 40,
    margin_bottom: int = 50,
) -> str:
    """
    Generate an inline SVG line chart: one line per entity over years.

    Args:
        crop_year_data: Dict[entity_key -> Dict[year -> value]].
                        e.g. {"wheat": {1970: 120.5, 1971: 118.2}, ...}
        label_fn:       Optional function(entity_key) → display label.
                        Defaults to identity.
        title:          Chart title text.
        chart_width / chart_height / margin_*: Layout dimensions in px.

    Returns:
        SVG string (no <html> wrapper).
    """
    if not crop_year_data:
        return "<p>No data to chart</p>"

    _label = label_fn or (lambda x: x)

    all_years: set[int] = set()
    all_vals:  list[float] = []
    for yt in crop_year_data.values():
        all_years.update(yt.keys())
        all_vals.extend(yt.values())

    if not all_years or not all_vals:
        return "<p>No data to chart</p>"

    years_sorted = sorted(all_years)
    year_min = years_sorted[0]
    year_max = years_sorted[-1]
    total_max = max(all_vals) * 1.1 or 1.0

    plot_w = chart_width - margin_left - margin_right
    plot_h = chart_height - margin_top - margin_bottom
    year_span = max(year_max - year_min, 1)

    def x_pos(yr: int) -> float:
        return margin_left + (yr - year_min) / year_span * plot_w

    def y_pos(val: float) -> float:
        return margin_top + plot_h - (val / total_max) * plot_h

    parts = [
        f'<svg width="{chart_width}" height="{chart_height}" xmlns="http://www.w3.org/2000/svg">',
        f'<rect width="{chart_width}" height="{chart_height}" fill="#fafafa"/>',
        f'<text x="{chart_width / 2}" y="20" text-anchor="middle" font-size="14" '
        f'font-weight="bold" font-family="sans-serif" fill="#333">{title}</text>',
    ]

    # Y-axis grid + labels
    for i in range(6):
        val = total_max * i / 5
        y   = y_pos(val)
        parts.append(
            f'<line x1="{margin_left}" y1="{y}" x2="{margin_left + plot_w}" y2="{y}" '
            f'stroke="#e0e0e0" stroke-width="1"/>'
        )
        lbl = f"{val:.0f}" if total_max >= 100 else f"{val:.1f}"
        parts.append(
            f'<text x="{margin_left - 8}" y="{y + 4}" text-anchor="end" '
            f'font-size="10" font-family="sans-serif" fill="#666">{lbl}</text>'
        )

    # X-axis labels
    step = max(1, len(years_sorted) // 10)
    for idx, yr in enumerate(years_sorted):
        if idx % step == 0 or idx == len(years_sorted) - 1:
            x = x_pos(yr)
            parts.append(
                f'<line x1="{x}" y1="{margin_top}" x2="{x}" y2="{margin_top + plot_h}" '
                f'stroke="#eeeeee" stroke-width="1"/>'
            )
            parts.append(
                f'<text x="{x}" y="{margin_top + plot_h + 18}" text-anchor="middle" '
                f'font-size="10" font-family="sans-serif" fill="#666">{yr}</text>'
            )

    # Axes
    parts.append(
        f'<line x1="{margin_left}" y1="{margin_top}" '
        f'x2="{margin_left}" y2="{margin_top + plot_h}" stroke="#999" stroke-width="1"/>'
    )
    parts.append(
        f'<line x1="{margin_left}" y1="{margin_top + plot_h}" '
        f'x2="{margin_left + plot_w}" y2="{margin_top + plot_h}" stroke="#999" stroke-width="1"/>'
    )

    # Lines per entity
    for ci, entity in enumerate(sorted(crop_year_data.keys())):
        color  = LINE_COLORS[ci % len(LINE_COLORS)]
        points = sorted(crop_year_data[entity].items())
        if not points:
            continue

        polyline = " ".join(f"{x_pos(yr):.1f},{y_pos(val):.1f}" for yr, val in points)
        parts.append(
            f'<polyline points="{polyline}" fill="none" stroke="{color}" '
            f'stroke-width="2" stroke-linejoin="round"/>'
        )
        for yr, val in points:
            parts.append(
                f'<circle cx="{x_pos(yr):.1f}" cy="{y_pos(val):.1f}" r="2.5" '
                f'fill="{color}" stroke="white" stroke-width="0.5"/>'
            )

        # Legend (right side)
        legend_x = margin_left + plot_w + 15
        ly = margin_top + 10 + ci * 18
        if ly > chart_height - 20:
            parts.append(
                f'<text x="{legend_x + 20}" y="{ly + 10}" font-size="10" '
                f'font-family="sans-serif" fill="#999">...</text>'
            )
            break
        display = _label(entity)
        parts.append(
            f'<line x1="{legend_x}" y1="{ly}" x2="{legend_x + 15}" y2="{ly}" '
            f'stroke="{color}" stroke-width="2"/>'
        )
        parts.append(
            f'<text x="{legend_x + 20}" y="{ly + 4}" font-size="11" '
            f'font-family="sans-serif" fill="#333">{display}</text>'
        )

    parts.append("</svg>")
    return "".join(parts)


# ---------------------------------------------------------------------------
# Baseline CSS for audit HTML pages
# ---------------------------------------------------------------------------

AUDIT_CSS = """\
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    background: #f3f4f6;
    color: #1f2937;
    line-height: 1.5;
    padding: 1rem;
}
.container { max-width: 1600px; margin: 0 auto; }
h1 { font-size: 1.8rem; font-weight: 700; color: #111; margin-bottom: 0.5rem; }
h2 { font-size: 1.2rem; font-weight: 600; color: #374151; margin: 1.5rem 0 0.5rem; }
table { border-collapse: collapse; width: 100%; font-size: 0.85rem; }
th { background: #374151; color: #fff; padding: 6px 10px; text-align: left; }
td { padding: 5px 10px; border-bottom: 1px solid #e5e7eb; }
tr:hover td { background: #f9fafb; }
.grade-pass     { background: #d1fae5; color: #065f46; padding: 2px 6px; border-radius: 4px; }
.grade-marginal { background: #fef3c7; color: #92400e; padding: 2px 6px; border-radius: 4px; }
.grade-fail     { background: #fee2e2; color: #991b1b; padding: 2px 6px; border-radius: 4px; }
.grade-skip     { background: #f3f4f6; color: #6b7280; padding: 2px 6px; border-radius: 4px; }
.section { background: #fff; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem;
           box-shadow: 0 1px 3px rgba(0,0,0,0.07); }
"""
