"""maestro-ocr CLI — unified entry point for OCR skill scripts.

Usage:
    python -m maestro_ocr screen <input_dir> [options]
    python -m maestro_ocr extract <input_dir> [options]
    python -m maestro_ocr audit <html_dir> [options]
    python -m maestro_ocr grade <extraction_dir> [options]
"""

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent.parent  # data-ocr/scripts/


def cmd_screen(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "screen_pages.py"), args.input_dir]
    if args.output:
        cmd.extend(["--output", args.output])
    if args.min_digit_ratio is not None:
        cmd.extend(["--min-digit-ratio", str(args.min_digit_ratio)])
    if args.verbose:
        cmd.append("--verbose")
    return subprocess.call(cmd)


def cmd_extract(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "vlm_extract.py"), args.input_dir]
    if args.output:
        cmd.extend(["--output", args.output])
    if args.provider:
        cmd.extend(["--provider", args.provider])
    if args.model:
        cmd.extend(["--model", args.model])
    return subprocess.call(cmd)


def cmd_audit(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "audit_html.py"), args.html_dir]
    if args.output:
        cmd.extend(["--output", args.output])
    return subprocess.call(cmd)


def cmd_grade(args: argparse.Namespace) -> int:
    cmd = [sys.executable, str(SCRIPTS_DIR / "arithmetic_grade.py"), args.extraction_dir]
    if args.output:
        cmd.extend(["--output", args.output])
    return subprocess.call(cmd)


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="maestro-ocr",
        description="Maestro OCR skill CLI",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # screen
    p_screen = sub.add_parser("screen", help="Screen pages for digit content")
    p_screen.add_argument("input_dir", help="Directory of page images")
    p_screen.add_argument("--output", default=None, help="Output manifest CSV (default: manifest.csv)")
    p_screen.add_argument("--min-digit-ratio", type=float, default=None, help="Minimum digit ratio threshold (default: 0.15)")
    p_screen.add_argument("--verbose", action="store_true", help="Enable verbose output")
    p_screen.set_defaults(func=cmd_screen)

    # extract
    p_extract = sub.add_parser("extract", help="Extract data from pages via VLM")
    p_extract.add_argument("input_dir", help="Directory of page images")
    p_extract.add_argument("--output", default=None, help="Output directory")
    p_extract.add_argument("--provider", default=None, help="VLM provider (default: anthropic)")
    p_extract.add_argument("--model", default=None, help="Model name")
    p_extract.set_defaults(func=cmd_extract)

    # audit
    p_audit = sub.add_parser("audit", help="Audit extracted HTML tables")
    p_audit.add_argument("html_dir", help="Directory of HTML files")
    p_audit.add_argument("--output", default=None, help="Output report JSON")
    p_audit.set_defaults(func=cmd_audit)

    # grade
    p_grade = sub.add_parser("grade", help="Grade arithmetic accuracy of extractions")
    p_grade.add_argument("extraction_dir", help="Directory of extraction results")
    p_grade.add_argument("--output", default=None, help="Output grades JSON")
    p_grade.set_defaults(func=cmd_grade)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
