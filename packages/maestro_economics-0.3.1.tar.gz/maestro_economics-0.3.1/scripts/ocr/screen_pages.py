#!/usr/bin/env python3
"""
screen_pages.py -- Fast triage of PNG pages for table detection.

PURPOSE:
    Classify a directory of PNG images as likely-table vs non-table using
    lightweight visual heuristics. No model inference required.
    Designed for first-pass triage of scanned PDF pages before expensive
    VLM extraction calls.

USAGE:
    python screen_pages.py INPUT_DIR [OPTIONS]

    python screen_pages.py pages/
    python screen_pages.py pages/ --output manifest.csv
    python screen_pages.py pages/ --min-digit-ratio 0.15 --min-years 5
    python screen_pages.py pages/ --verbose

OUTPUT:
    CSV manifest with columns:
        page_path    -- absolute path to PNG file
        is_table     -- True or False
        reason       -- detection signal: landscape | high_digit_ratio+years |
                        very_high_digit_ratio | many_years+moderate_digits | none
        landscape    -- True if width > height * landscape_ratio
        digit_ratio  -- fraction of non-space characters that are digits
        unique_years -- count of distinct year strings found (1900-2099)
        score        -- composite score (higher = more table-like, for ranking)

HEURISTICS (in priority order):
    1. Landscape orientation: width > height * 1.1
       Wide pages almost always contain wide statistical tables.
    2. High digit ratio + years present: digit_ratio >= 0.40 AND unique_years >= 5
       Dense numeric content with temporal structure = time-series table.
    3. Very high digit ratio: digit_ratio >= 0.50
       Overwhelming numeric content regardless of year structure.
    4. Many years + moderate digits: unique_years >= 8 AND digit_ratio >= 0.15
       Year-indexed tables with mixed text/numeric cells.

NOTE:
    This script uses Pillow to read images. It does NOT use PaddleOCR or any
    text extraction -- digit counting is done by pixel analysis (dark pixel
    density) per column strip for landscape detection, and by Pillow metadata
    for dimensions. Year detection requires either embedded text or OCR output
    (if --text-dir is provided).

    For PDF pages that have embedded text layers, use PyMuPDF (fitz) instead,
    which gives exact character-level text for digit counting. This script
    operates purely on image files to remain dependency-light.

DEPENDENCIES:
    Pillow   (pip install Pillow)
    pandas   (pip install pandas)

LIMITATIONS:
    Without embedded text, digit_ratio and unique_years are estimated from
    image darkness patterns (fast but less accurate than text-based analysis).
    Pass --text-dir to provide pre-extracted text files (.txt, one per PNG).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Detection thresholds (match source project values, all overridable via CLI)
# ---------------------------------------------------------------------------

LANDSCAPE_RATIO = 1.1         # width / height threshold for landscape detection
DIGIT_RATIO_HIGH = 0.40       # high-density numeric pages
DIGIT_RATIO_VERY_HIGH = 0.50  # extremely dense numeric (no year check needed)
DIGIT_RATIO_MED = 0.15        # moderate numeric, needs year support
MIN_YEARS_STRONG = 8          # many years signal (medium digits ok)
MIN_YEARS_WEAK = 5            # few years signal (needs high digits)

# Year regex: matches 19xx, 20[0-2]x (covers 1900-2029 range).
_YEAR_RE = re.compile(r"19[0-9]\d|20[0-2]\d")

# ---------------------------------------------------------------------------
# Core functions (importable as a module)
# ---------------------------------------------------------------------------


def get_image_dimensions(image_path: str) -> tuple[int, int]:
    """Return (width, height) of an image without loading all pixels.

    Args:
        image_path: Path to image file.

    Returns:
        Tuple (width, height) in pixels.

    Raises:
        ImportError: If Pillow is not installed.
        OSError: If file cannot be opened as image.
    """
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("Pillow is required: pip install Pillow")

    with Image.open(image_path) as img:
        return img.size  # (width, height)


def estimate_digit_ratio_from_image(image_path: str, sample_width: int = 50) -> float:
    """Estimate the fraction of dark pixels in horizontal column strips.

    This is a proxy for digit density when embedded text is not available.
    Converts image to grayscale, samples vertical strips, counts dark pixels.
    Dark pixel density correlates (imperfectly) with text/digit density.

    Args:
        image_path: Path to image file.
        sample_width: Width of each sampled column strip in pixels.

    Returns:
        Estimated dark pixel ratio (0.0 to 1.0). Not equivalent to a true
        digit ratio from text extraction.
    """
    try:
        from PIL import Image
        import statistics
    except ImportError:
        raise ImportError("Pillow is required: pip install Pillow")

    with Image.open(image_path) as img:
        gray = img.convert("L")
        width, height = gray.size

        # Sample a few column strips across the image.
        pixels = list(gray.getdata())
        dark_count = sum(1 for p in pixels if p < 128)
        total = len(pixels)
        return dark_count / max(total, 1)


def extract_years_from_text(text: str) -> set[str]:
    """Find all distinct year strings in a block of text.

    Args:
        text: OCR or embedded text from a document page.

    Returns:
        Set of year strings found (e.g. {'1985', '1990', '1995'}).
    """
    return set(_YEAR_RE.findall(text))


def count_digit_ratio_from_text(text: str) -> float:
    """Compute the fraction of non-whitespace characters that are digits.

    Args:
        text: OCR or embedded text string.

    Returns:
        Digit ratio (0.0 to 1.0).
    """
    clean = text.replace(" ", "").replace("\n", "").replace("\t", "")
    if not clean:
        return 0.0
    digits = sum(1 for c in clean if c.isdigit())
    return digits / len(clean)


def detect_table_from_features(
    width: int,
    height: int,
    digit_ratio: float,
    unique_years: int,
    landscape_ratio: float = LANDSCAPE_RATIO,
    digit_ratio_high: float = DIGIT_RATIO_HIGH,
    digit_ratio_very_high: float = DIGIT_RATIO_VERY_HIGH,
    digit_ratio_med: float = DIGIT_RATIO_MED,
    min_years_strong: int = MIN_YEARS_STRONG,
    min_years_weak: int = MIN_YEARS_WEAK,
) -> tuple[bool, str, float]:
    """Classify a page as table/non-table from pre-computed features.

    Args:
        width: Page width in pixels.
        height: Page height in pixels.
        digit_ratio: Fraction of characters/pixels that are digits.
        unique_years: Count of distinct year strings on the page.
        landscape_ratio: Width/height ratio threshold for landscape detection.
        digit_ratio_high: Digit ratio threshold for high-density detection.
        digit_ratio_very_high: Digit ratio for very-high-density detection.
        digit_ratio_med: Digit ratio for moderate-density + year signal.
        min_years_strong: Year count for strong-year signal.
        min_years_weak: Year count for weak-year signal (needs high digits).

    Returns:
        Tuple (is_table, reason, score):
            is_table (bool): True if page is classified as containing a table.
            reason (str): Signal that triggered detection, or 'none'.
            score (float): Composite score for ranking (higher = more table-like).
    """
    is_landscape = width > height * landscape_ratio

    reason = "none"
    is_table = False

    if is_landscape:
        is_table = True
        reason = "landscape"
    elif digit_ratio >= digit_ratio_high and unique_years >= min_years_weak:
        is_table = True
        reason = "high_digit_ratio+years"
    elif digit_ratio >= digit_ratio_very_high:
        is_table = True
        reason = "very_high_digit_ratio"
    elif unique_years >= min_years_strong and digit_ratio >= digit_ratio_med:
        is_table = True
        reason = "many_years+moderate_digits"

    # Composite score: landscape contributes most, then digit_ratio, then years.
    score = (
        (2.0 if is_landscape else 0.0)
        + digit_ratio * 2.0
        + min(unique_years, 20) / 20.0
    )

    return is_table, reason, round(score, 3)


def screen_directory(
    input_dir: str,
    text_dir: Optional[str] = None,
    landscape_ratio: float = LANDSCAPE_RATIO,
    digit_ratio_high: float = DIGIT_RATIO_HIGH,
    digit_ratio_very_high: float = DIGIT_RATIO_VERY_HIGH,
    digit_ratio_med: float = DIGIT_RATIO_MED,
    min_years_strong: int = MIN_YEARS_STRONG,
    min_years_weak: int = MIN_YEARS_WEAK,
    verbose: bool = False,
) -> list[dict]:
    """Screen all PNG files in a directory for table content.

    Args:
        input_dir: Directory containing PNG files.
        text_dir: Optional directory containing pre-extracted .txt files
                  (one per PNG, same stem). If provided, digit_ratio and
                  unique_years are computed from text instead of image pixels.
        landscape_ratio: Width/height threshold for landscape detection.
        digit_ratio_high: See detect_table_from_features.
        digit_ratio_very_high: See detect_table_from_features.
        digit_ratio_med: See detect_table_from_features.
        min_years_strong: See detect_table_from_features.
        min_years_weak: See detect_table_from_features.
        verbose: Print per-page results to stderr.

    Returns:
        List of dicts, one per PNG file, with keys:
            page_path, is_table, reason, landscape, digit_ratio,
            unique_years, score.
    """
    dir_path = Path(input_dir)
    if not dir_path.is_dir():
        raise NotADirectoryError(f"Not a directory: {input_dir}")

    png_files = sorted(dir_path.glob("*.png")) + sorted(dir_path.glob("*.PNG"))
    if not png_files:
        return []

    text_path = Path(text_dir) if text_dir else None
    results = []

    for png_path in png_files:
        try:
            width, height = get_image_dimensions(str(png_path))
        except Exception as e:
            print(f"WARNING: Could not read {png_path.name}: {e}", file=sys.stderr)
            continue

        # Text-based features (more accurate) if text files are available.
        if text_path:
            txt_file = text_path / (png_path.stem + ".txt")
            if txt_file.exists():
                text = txt_file.read_text(encoding="utf-8", errors="replace")
                digit_ratio = count_digit_ratio_from_text(text)
                unique_years = len(extract_years_from_text(text))
            else:
                # Fall back to image-based proxy.
                digit_ratio = estimate_digit_ratio_from_image(str(png_path))
                unique_years = 0
        else:
            # Pure image-based: digit_ratio is a dark-pixel proxy, years = 0.
            # This is the lightweight path -- no year detection without text.
            digit_ratio = estimate_digit_ratio_from_image(str(png_path))
            unique_years = 0

        is_table, reason, score = detect_table_from_features(
            width=width,
            height=height,
            digit_ratio=digit_ratio,
            unique_years=unique_years,
            landscape_ratio=landscape_ratio,
            digit_ratio_high=digit_ratio_high,
            digit_ratio_very_high=digit_ratio_very_high,
            digit_ratio_med=digit_ratio_med,
            min_years_strong=min_years_strong,
            min_years_weak=min_years_weak,
        )

        record = {
            "page_path": str(png_path.resolve()),
            "is_table": is_table,
            "reason": reason,
            "landscape": width > height * landscape_ratio,
            "digit_ratio": round(digit_ratio, 4),
            "unique_years": unique_years,
            "score": score,
        }
        results.append(record)

        if verbose:
            tag = "TABLE" if is_table else "     "
            print(
                f"  [{tag}] {png_path.name}: "
                f"landscape={record['landscape']}, "
                f"digit_ratio={record['digit_ratio']:.3f}, "
                f"years={unique_years}, "
                f"reason={reason}",
                file=sys.stderr,
            )

    return results


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="screen_pages",
        description=(
            "Classify PNG pages as table/non-table using lightweight heuristics. "
            "Outputs a CSV manifest with detection results for each page."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "input_dir",
        metavar="INPUT_DIR",
        help="Directory containing PNG files to screen.",
    )
    parser.add_argument(
        "--output", "-o",
        metavar="MANIFEST.csv",
        help="Write manifest CSV to this file (default: stdout).",
    )
    parser.add_argument(
        "--text-dir",
        metavar="TEXT_DIR",
        help=(
            "Directory containing pre-extracted .txt files (same stem as PNGs). "
            "When provided, digit_ratio and year_count are computed from text "
            "for much higher accuracy. Otherwise, image pixel density is used."
        ),
    )
    parser.add_argument(
        "--min-digit-ratio",
        type=float,
        default=DIGIT_RATIO_HIGH,
        metavar="RATIO",
        help=f"Digit ratio threshold for high-density detection (default: {DIGIT_RATIO_HIGH}).",
    )
    parser.add_argument(
        "--min-digit-ratio-very-high",
        type=float,
        default=DIGIT_RATIO_VERY_HIGH,
        metavar="RATIO",
        help=f"Digit ratio for very-high-density (no year check) (default: {DIGIT_RATIO_VERY_HIGH}).",
    )
    parser.add_argument(
        "--min-digit-ratio-med",
        type=float,
        default=DIGIT_RATIO_MED,
        metavar="RATIO",
        help=f"Moderate digit ratio (used with --min-years) (default: {DIGIT_RATIO_MED}).",
    )
    parser.add_argument(
        "--min-years",
        type=int,
        default=MIN_YEARS_STRONG,
        metavar="N",
        help=f"Year count for strong-year signal (default: {MIN_YEARS_STRONG}).",
    )
    parser.add_argument(
        "--min-years-weak",
        type=int,
        default=MIN_YEARS_WEAK,
        metavar="N",
        help=f"Year count for weak-year signal (default: {MIN_YEARS_WEAK}).",
    )
    parser.add_argument(
        "--landscape-ratio",
        type=float,
        default=LANDSCAPE_RATIO,
        metavar="RATIO",
        help=f"Width/height ratio threshold for landscape detection (default: {LANDSCAPE_RATIO}).",
    )
    parser.add_argument(
        "--tables-only",
        action="store_true",
        help="Output manifest rows only for pages classified as tables.",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print per-page results to stderr.",
    )
    return parser


def main() -> None:
    try:
        import pandas as pd
    except ImportError:
        print("ERROR: pandas is required: pip install pandas Pillow", file=sys.stderr)
        sys.exit(1)

    parser = build_parser()
    args = parser.parse_args()

    if not Path(args.input_dir).is_dir():
        print(f"ERROR: Not a directory: {args.input_dir}", file=sys.stderr)
        sys.exit(1)

    if args.verbose:
        print(f"Screening PNGs in: {args.input_dir}", file=sys.stderr)
        if args.text_dir:
            print(f"Text files from : {args.text_dir}", file=sys.stderr)
        else:
            print(
                "NOTE: No --text-dir provided. Using image pixel density "
                "(less accurate; year detection disabled).",
                file=sys.stderr,
            )

    try:
        results = screen_directory(
            input_dir=args.input_dir,
            text_dir=args.text_dir,
            landscape_ratio=args.landscape_ratio,
            digit_ratio_high=args.min_digit_ratio,
            digit_ratio_very_high=args.min_digit_ratio_very_high,
            digit_ratio_med=args.min_digit_ratio_med,
            min_years_strong=args.min_years,
            min_years_weak=args.min_years_weak,
            verbose=args.verbose,
        )
    except NotADirectoryError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
    except ImportError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if not results:
        print("WARNING: No PNG files found.", file=sys.stderr)
        sys.exit(0)

    if args.tables_only:
        results = [r for r in results if r["is_table"]]

    df = pd.DataFrame(results)
    csv_str = df.to_csv(index=False)

    if args.output:
        Path(args.output).write_text(csv_str, encoding="utf-8")
        n_total = len(results)
        n_tables = sum(1 for r in results if r["is_table"])
        print(
            f"Screened {n_total} pages: {n_tables} classified as table "
            f"({n_total - n_tables} non-table). Manifest -> {args.output}",
            file=sys.stderr,
        )
    else:
        sys.stdout.write(csv_str)
        if not csv_str.endswith("\n"):
            sys.stdout.write("\n")

    # Print summary to stderr.
    n_total = len(results)
    n_tables = sum(1 for r in results if r["is_table"])
    print(
        f"\nSummary: {n_tables} / {n_total} pages classified as table "
        f"({100*n_tables/max(n_total,1):.1f}%)",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
