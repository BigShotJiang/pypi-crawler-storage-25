# maestro-data-ocr/scripts -- generic CLI tools for OCR pipelines.
# See vlm_extract.py, arithmetic_grade.py, screen_pages.py
