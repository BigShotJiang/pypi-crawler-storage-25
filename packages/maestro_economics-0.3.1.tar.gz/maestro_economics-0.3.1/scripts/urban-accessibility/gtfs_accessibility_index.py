#!/usr/bin/env python3
"""
gtfs_accessibility_index.py — Universal GTFS accessibility index calculator

Accepts any city's GTFS files + OSM PBF + boundaries + opportunities,
computes per-district public transit accessibility indices and per-station
service area polygons.

Three accessibility metrics computed:
  1. Cumulative opportunities (jobs/amenities reachable within N minutes)
  2. Gravity-based index (distance-decay weighted sum of opportunities)
  3. Isochrone service area polygons per station

Backend: r5py (Python wrapper for Conveyal R5 routing engine).
Requires: Java 17+, r5py, geopandas, pandas, numpy, shapely.

Supported cities (tested): Singapore, Tokyo, Beijing, London.
Works with any city that has GTFS + OSM PBF data.

Usage:
    python gtfs_accessibility_index.py \\
        --gtfs singapore_gtfs.zip \\
        --osm singapore.osm.pbf \\
        --districts districts.shp \\
        --opportunities jobs.csv \\
        --output ./output/

    # Multiple GTFS feeds (e.g., bus + rail)
    python gtfs_accessibility_index.py \\
        --gtfs bus.zip rail.zip \\
        --osm tokyo.osm.pbf \\
        --districts wards.geojson \\
        --opportunities employment_centers.csv \\
        --output ./output/ \\
        --thresholds 30 45 60 \\
        --departure "2024-03-13 08:00"

    # Station service areas only (no opportunities needed)
    python gtfs_accessibility_index.py \\
        --gtfs gtfs.zip \\
        --osm city.osm.pbf \\
        --mode isochrones-only \\
        --output ./output/

    # Use district centroids as both origins and destinations
    python gtfs_accessibility_index.py \\
        --gtfs gtfs.zip \\
        --osm city.osm.pbf \\
        --districts districts.shp \\
        --output ./output/ \\
        --self-potential

Dependencies:
    r5py>=0.2.0
    geopandas>=1.1.0
    pandas>=2.0.0
    numpy>=1.24.0
    shapely>=2.0.0
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import geopandas as gpd
import numpy as np
import pandas as pd

try:
    import r5py
except ImportError:
    print(
        "[ERROR] r5py not installed. Install with: pip install r5py\n"
        "        Also requires Java 17+: java -version",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------


def log(msg: str) -> None:
    """Print progress message to stderr."""
    print(f"[accessibility] {msg}", file=sys.stderr)


def read_spatial(path: str, label: str = "file") -> gpd.GeoDataFrame:
    """Read shapefile / GeoJSON / GeoParquet / GPKG."""
    log(f"Reading {label}: {path}")
    p = Path(path)
    if p.suffix == ".parquet":
        gdf = gpd.read_parquet(path)
    else:
        gdf = gpd.read_file(path, engine="pyogrio")
    log(f"  -> {len(gdf):,} features, CRS={gdf.crs}")
    return gdf


def read_opportunities(path: str, lat_col: str, lon_col: str, value_col: str) -> gpd.GeoDataFrame:
    """Read CSV/Excel opportunities file and convert to GeoDataFrame."""
    log(f"Reading opportunities: {path}")
    p = Path(path)
    if p.suffix in (".csv", ".tsv"):
        df = pd.read_csv(path)
    elif p.suffix in (".xlsx", ".xls"):
        df = pd.read_excel(path)
    elif p.suffix in (".shp", ".geojson", ".gpkg", ".parquet"):
        gdf = read_spatial(path, "opportunities")
        if value_col not in gdf.columns:
            log(f"  WARNING: value column '{value_col}' not found, using 1.0")
            gdf[value_col] = 1.0
        return gdf
    else:
        df = pd.read_csv(path)

    if lat_col not in df.columns or lon_col not in df.columns:
        print(
            f"[ERROR] Columns '{lat_col}' and/or '{lon_col}' not found in {path}.\n"
            f"  Available columns: {list(df.columns)}",
            file=sys.stderr,
        )
        sys.exit(1)

    if value_col not in df.columns:
        log(f"  WARNING: value column '{value_col}' not found, using 1.0 (count mode)")
        df[value_col] = 1.0

    gdf = gpd.GeoDataFrame(
        df,
        geometry=gpd.points_from_xy(df[lon_col], df[lat_col]),
        crs="EPSG:4326",
    )
    log(f"  -> {len(gdf):,} opportunity points")
    return gdf


# ---------------------------------------------------------------------------
# GTFS validation
# ---------------------------------------------------------------------------


def validate_gtfs(gtfs_path: str) -> dict:
    """Quick validation of GTFS zip contents."""
    import zipfile

    required = ["agency.txt", "routes.txt", "trips.txt", "stop_times.txt", "stops.txt"]
    report = {"path": gtfs_path, "valid": True, "errors": [], "stats": {}}

    try:
        with zipfile.ZipFile(gtfs_path, "r") as zf:
            names = zf.namelist()
            for f in required:
                if f not in names:
                    report["valid"] = False
                    report["errors"].append(f"Missing required file: {f}")

            if "stops.txt" in names:
                stops = pd.read_csv(zf.open("stops.txt"))
                report["stats"]["n_stops"] = len(stops)
            if "routes.txt" in names:
                routes = pd.read_csv(zf.open("routes.txt"))
                report["stats"]["n_routes"] = len(routes)
                report["stats"]["route_types"] = routes["route_type"].value_counts().to_dict()
            if "trips.txt" in names:
                trips = pd.read_csv(zf.open("trips.txt"))
                report["stats"]["n_trips"] = len(trips)
    except zipfile.BadZipFile:
        report["valid"] = False
        report["errors"].append("Not a valid zip file")

    return report


# ---------------------------------------------------------------------------
# Core: transport network + travel time matrix
# ---------------------------------------------------------------------------


def build_network(osm_pbf: str, gtfs_files: list[str]) -> r5py.TransportNetwork:
    """Build r5py TransportNetwork from OSM PBF + GTFS feeds."""
    log(f"Building transport network: OSM={osm_pbf}, GTFS={gtfs_files}")
    network = r5py.TransportNetwork(osm_pbf, gtfs_files)
    log("  -> Network built successfully")
    return network


def compute_travel_time_matrix(
    network: r5py.TransportNetwork,
    origins: gpd.GeoDataFrame,
    destinations: gpd.GeoDataFrame,
    departure: datetime,
    departure_window_min: int = 60,
    max_time_min: int = 90,
    max_walk_min: int = 20,
    modes: Optional[list] = None,
    batch_size: int = 500,
) -> pd.DataFrame:
    """
    Compute origin-destination travel time matrix in batches.

    Returns DataFrame with columns: from_id, to_id, travel_time_p50
    """
    if modes is None:
        modes = [r5py.TransportMode.TRANSIT, r5py.TransportMode.WALK]

    # Ensure id columns
    if "id" not in origins.columns:
        origins = origins.copy()
        origins["id"] = range(len(origins))
    if "id" not in destinations.columns:
        destinations = destinations.copy()
        destinations["id"] = range(len(destinations))

    n_origins = len(origins)
    log(f"Computing travel time matrix: {n_origins} origins x {len(destinations)} destinations")

    all_results = []
    for i in range(0, n_origins, batch_size):
        batch = origins.iloc[i : i + batch_size]
        batch_end = min(i + batch_size, n_origins)

        ttm = r5py.TravelTimeMatrixComputer(
            network,
            origins=batch,
            destinations=destinations,
            transport_modes=modes,
            departure=departure,
            departure_time_window=timedelta(minutes=departure_window_min),
            max_time=timedelta(minutes=max_time_min),
            max_walks=timedelta(minutes=max_walk_min),
        ).compute_travel_times()

        all_results.append(ttm)
        log(f"  -> Batch {batch_end}/{n_origins} complete ({len(ttm):,} OD pairs)")

    result = pd.concat(all_results, ignore_index=True)
    log(f"  -> Total: {len(result):,} OD pairs with valid travel times")
    return result


# ---------------------------------------------------------------------------
# Accessibility indices
# ---------------------------------------------------------------------------


def cumulative_opportunities(
    ttm: pd.DataFrame,
    opportunities: gpd.GeoDataFrame,
    value_col: str = "jobs",
    thresholds: list[int] = None,
) -> pd.DataFrame:
    """
    Cumulative opportunities: count of reachable opportunities within T minutes.

    Output columns: origin_id, opp_30min, opp_45min, opp_60min, ...
    """
    if thresholds is None:
        thresholds = [30, 45, 60]

    log(f"Computing cumulative opportunities (thresholds={thresholds})")

    # Map destination id -> opportunity value
    opp_map = opportunities.set_index("id")[value_col].to_dict() if "id" in opportunities.columns else {}
    if not opp_map:
        # Fall back: use index
        opp_map = dict(zip(range(len(opportunities)), opportunities[value_col]))

    ttm = ttm.copy()
    ttm["opp_value"] = ttm["to_id"].map(opp_map).fillna(0)

    result = ttm[["from_id"]].drop_duplicates().rename(columns={"from_id": "origin_id"})

    for T in thresholds:
        reachable = ttm[ttm["travel_time_p50"] <= T]
        agg = (
            reachable.groupby("from_id")["opp_value"]
            .sum()
            .reset_index()
            .rename(columns={"from_id": "origin_id", "opp_value": f"opp_{T}min"})
        )
        result = result.merge(agg, on="origin_id", how="left")
        result[f"opp_{T}min"] = result[f"opp_{T}min"].fillna(0)

    log(f"  -> {len(result)} origins with cumulative opportunity indices")
    return result


def gravity_accessibility(
    ttm: pd.DataFrame,
    opportunities: gpd.GeoDataFrame,
    value_col: str = "jobs",
    beta: float = 0.1,
    decay: str = "exponential",
    max_time: float = 90.0,
) -> pd.DataFrame:
    """
    Gravity-based accessibility: A_i = sum_j(O_j * f(t_ij))

    Decay functions: exponential (default), power, gaussian.
    Output columns: origin_id, gravity_index
    """
    log(f"Computing gravity accessibility (beta={beta}, decay={decay})")

    opp_map = opportunities.set_index("id")[value_col].to_dict() if "id" in opportunities.columns else {}
    if not opp_map:
        opp_map = dict(zip(range(len(opportunities)), opportunities[value_col]))

    df = ttm.copy()
    df["opp_value"] = df["to_id"].map(opp_map).fillna(0)
    df = df[df["travel_time_p50"] <= max_time].copy()

    t = df["travel_time_p50"].values.astype(float)
    if decay == "exponential":
        df["weight"] = np.exp(-beta * t)
    elif decay == "power":
        df["weight"] = np.where(t > 0, np.power(t, -beta), 0.0)
    elif decay == "gaussian":
        sigma = 1.0 / beta
        df["weight"] = np.exp(-(t ** 2) / (2 * sigma ** 2))
    else:
        log(f"  ERROR: Unknown decay function '{decay}', using exponential")
        df["weight"] = np.exp(-beta * t)

    df["weighted_opp"] = df["opp_value"] * df["weight"]
    result = (
        df.groupby("from_id")["weighted_opp"]
        .sum()
        .reset_index()
        .rename(columns={"from_id": "origin_id", "weighted_opp": "gravity_index"})
    )

    log(f"  -> {len(result)} origins with gravity index")
    return result


# ---------------------------------------------------------------------------
# Isochrone service areas
# ---------------------------------------------------------------------------


def compute_station_isochrones(
    network: r5py.TransportNetwork,
    stations: gpd.GeoDataFrame,
    departure: datetime,
    intervals_min: list[int] = None,
    max_walk_min: int = 20,
) -> gpd.GeoDataFrame:
    """
    Compute isochrone polygons for each transit station.

    Returns GeoDataFrame: station_id, travel_time_min, geometry (polygon)
    """
    if intervals_min is None:
        intervals_min = [15, 30, 45, 60]

    log(f"Computing station isochrones for {len(stations)} stations (intervals={intervals_min})")

    if "id" not in stations.columns:
        stations = stations.copy()
        stations["id"] = range(len(stations))

    all_isochrones = []

    for idx, station in stations.iterrows():
        station_gdf = gpd.GeoDataFrame(
            [{"id": station["id"], "geometry": station.geometry}],
            crs=stations.crs,
        )

        try:
            iso_computer = r5py.IsochroneComputer(
                network,
                origins=station_gdf,
                transport_modes=[r5py.TransportMode.TRANSIT, r5py.TransportMode.WALK],
                departure=departure,
                max_time=timedelta(minutes=max(intervals_min)),
                time_intervals=[timedelta(minutes=m) for m in intervals_min],
            )
            iso = iso_computer.compute_isochrones()
            iso["station_id"] = station["id"]
            all_isochrones.append(iso)
        except Exception as exc:
            log(f"  WARNING: Failed for station {station['id']}: {exc}")
            continue

        if (idx + 1) % 50 == 0:
            log(f"  -> {idx + 1}/{len(stations)} stations processed")

    if not all_isochrones:
        log("  ERROR: No isochrones computed")
        return gpd.GeoDataFrame(columns=["station_id", "travel_time", "geometry"])

    result = pd.concat(all_isochrones, ignore_index=True)
    log(f"  -> {len(result)} isochrone polygons for {len(all_isochrones)} stations")
    return result


# ---------------------------------------------------------------------------
# District aggregation
# ---------------------------------------------------------------------------


def aggregate_to_districts(
    accessibility: pd.DataFrame,
    origins: gpd.GeoDataFrame,
    districts: gpd.GeoDataFrame,
    district_id_col: str = "district_id",
) -> pd.DataFrame:
    """
    Spatially aggregate origin-level accessibility to district level.

    Joins origin points to districts, then averages accessibility columns.
    """
    log("Aggregating accessibility indices to districts")

    # Ensure matching CRS
    origins_crs = origins.to_crs(districts.crs)

    # Spatial join: origins -> districts
    joined = gpd.sjoin(origins_crs, districts[[district_id_col, "geometry"]], how="left", predicate="within")

    # Merge accessibility scores
    if "id" in origins.columns:
        joined = joined.merge(accessibility, left_on="id", right_on="origin_id", how="left")
    else:
        joined["origin_id"] = joined.index
        joined = joined.merge(accessibility, on="origin_id", how="left")

    # Aggregate: mean per district
    acc_cols = [c for c in accessibility.columns if c != "origin_id"]
    agg_dict = {c: "mean" for c in acc_cols if c in joined.columns}
    agg_dict["origin_id"] = "count"  # number of origins per district

    district_acc = (
        joined.groupby(district_id_col)
        .agg(agg_dict)
        .rename(columns={"origin_id": "n_origins"})
        .reset_index()
    )

    log(f"  -> {len(district_acc)} districts with aggregated accessibility")
    return district_acc


# ---------------------------------------------------------------------------
# Extract GTFS stops as station points
# ---------------------------------------------------------------------------


def extract_gtfs_stops(gtfs_path: str, route_types: Optional[list[int]] = None) -> gpd.GeoDataFrame:
    """
    Extract station/stop locations from GTFS zip.

    Args:
        gtfs_path: Path to GTFS zip file
        route_types: Filter by route type (1=subway, 2=rail, etc.).
                     None = all stops.
    """
    import zipfile

    log(f"Extracting stops from GTFS: {gtfs_path}")

    with zipfile.ZipFile(gtfs_path, "r") as zf:
        stops = pd.read_csv(zf.open("stops.txt"))

        if route_types is not None:
            routes = pd.read_csv(zf.open("routes.txt"))
            trips = pd.read_csv(zf.open("trips.txt"))
            stop_times = pd.read_csv(zf.open("stop_times.txt"), usecols=["trip_id", "stop_id"])

            # Filter routes by type
            filtered_routes = routes[routes["route_type"].isin(route_types)]
            filtered_trips = trips[trips["route_id"].isin(filtered_routes["route_id"])]
            filtered_stop_ids = stop_times[
                stop_times["trip_id"].isin(filtered_trips["trip_id"])
            ]["stop_id"].unique()

            stops = stops[stops["stop_id"].isin(filtered_stop_ids)]
            log(f"  -> Filtered to route_types {route_types}: {len(stops)} stops")

    # Remove parent stations (location_type == 1) if present
    if "location_type" in stops.columns:
        stops = stops[(stops["location_type"].isna()) | (stops["location_type"] == 0)]

    gdf = gpd.GeoDataFrame(
        stops,
        geometry=gpd.points_from_xy(stops["stop_lon"], stops["stop_lat"]),
        crs="EPSG:4326",
    )

    # Use stop_id as id
    gdf["id"] = gdf["stop_id"].astype(str)
    log(f"  -> {len(gdf)} stops extracted")
    return gdf


# ---------------------------------------------------------------------------
# Self-potential mode (district centroids as both origins & destinations)
# ---------------------------------------------------------------------------


def district_centroids(districts: gpd.GeoDataFrame, district_id_col: str) -> gpd.GeoDataFrame:
    """Generate representative points for each district."""
    districts_wgs = districts.to_crs("EPSG:4326")
    pts = districts_wgs.geometry.representative_point()
    centroids = gpd.GeoDataFrame(
        {
            "id": range(len(districts)),
            district_id_col: districts[district_id_col],
            "geometry": pts,
        },
        crs="EPSG:4326",
    )
    return centroids


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------


def write_outputs(
    output_dir: Path,
    district_acc: Optional[pd.DataFrame],
    isochrones: Optional[gpd.GeoDataFrame],
    ttm: Optional[pd.DataFrame],
    validation: Optional[dict],
    cum_opp: Optional[pd.DataFrame],
    grav: Optional[pd.DataFrame],
) -> None:
    """Write all outputs to output directory."""
    output_dir.mkdir(parents=True, exist_ok=True)

    if district_acc is not None:
        p = output_dir / "district_accessibility.csv"
        district_acc.to_csv(p, index=False)
        log(f"  -> District accessibility: {p}")

    if cum_opp is not None:
        p = output_dir / "cumulative_opportunities.csv"
        cum_opp.to_csv(p, index=False)
        log(f"  -> Cumulative opportunities: {p}")

    if grav is not None:
        p = output_dir / "gravity_index.csv"
        grav.to_csv(p, index=False)
        log(f"  -> Gravity index: {p}")

    if isochrones is not None and len(isochrones) > 0:
        p = output_dir / "station_isochrones.geojson"
        isochrones.to_file(p, driver="GeoJSON")
        log(f"  -> Station isochrones: {p}")

    if ttm is not None:
        p = output_dir / "travel_time_matrix.parquet"
        ttm.to_parquet(p, index=False)
        log(f"  -> Travel time matrix: {p}")

    if validation is not None:
        p = output_dir / "gtfs_validation.json"
        with open(p, "w") as f:
            json.dump(validation, f, indent=2, default=str)
        log(f"  -> GTFS validation: {p}")

    # Summary stats
    summary = {
        "generated_at": datetime.now().isoformat(),
        "districts": len(district_acc) if district_acc is not None else 0,
        "isochrone_polygons": len(isochrones) if isochrones is not None else 0,
        "od_pairs": len(ttm) if ttm is not None else 0,
    }
    p = output_dir / "summary.json"
    with open(p, "w") as f:
        json.dump(summary, f, indent=2)
    log(f"  -> Summary: {p}")


# ---------------------------------------------------------------------------
# City presets
# ---------------------------------------------------------------------------

CITY_PRESETS = {
    "singapore": {
        "osm_url": "https://download.geofabrik.de/asia/malaysia-singapore-brunei-latest.osm.pbf",
        "gtfs_note": "LTA DataMall (requires API key): https://datamall.lta.gov.sg",
        "crs_local": "EPSG:3414",
        "bbox": (1.22, 1.47, 103.6, 104.05),
    },
    "tokyo": {
        "osm_url": "https://download.geofabrik.de/asia/japan/kanto-latest.osm.pbf",
        "gtfs_note": "MLIT GTFS-JP: https://nlftp.mlit.go.jp/ksj/",
        "crs_local": "EPSG:6677",
        "bbox": (35.5, 35.9, 139.4, 140.0),
    },
    "beijing": {
        "osm_url": "https://download.geofabrik.de/asia/china-latest.osm.pbf",
        "gtfs_note": "No official GTFS; use Baidu Maps API or manual construction",
        "crs_local": "EPSG:4547",
        "bbox": (39.4, 41.1, 115.4, 117.5),
    },
    "london": {
        "osm_url": "https://download.geofabrik.de/europe/great-britain/england/greater-london-latest.osm.pbf",
        "gtfs_note": "TfL: https://tfl.gov.uk/info-for/open-data-users/",
        "crs_local": "EPSG:27700",
        "bbox": (51.28, 51.70, -0.51, 0.33),
    },
}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="gtfs_accessibility_index",
        description="Universal GTFS accessibility index calculator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full pipeline with opportunities
  python gtfs_accessibility_index.py \\
      --gtfs singapore.zip --osm singapore.osm.pbf \\
      --districts districts.shp --opportunities jobs.csv \\
      --output ./output/

  # Station isochrones only
  python gtfs_accessibility_index.py \\
      --gtfs gtfs.zip --osm city.osm.pbf \\
      --mode isochrones-only --output ./output/

  # Self-potential (district-to-district)
  python gtfs_accessibility_index.py \\
      --gtfs gtfs.zip --osm city.osm.pbf \\
      --districts districts.shp --self-potential --output ./output/

  # Show city preset info
  python gtfs_accessibility_index.py --city-info singapore
        """,
    )

    p.add_argument("--gtfs", nargs="+", help="GTFS zip file(s)")
    p.add_argument("--osm", help="OSM PBF file path")
    p.add_argument("--districts", help="District boundaries (SHP/GeoJSON/GPKG)")
    p.add_argument("--district-id", default="district_id", help="District ID column name (default: district_id)")
    p.add_argument("--opportunities", help="Opportunities file (CSV/SHP/GeoJSON)")
    p.add_argument("--opp-lat", default="lat", help="Latitude column in opportunities CSV (default: lat)")
    p.add_argument("--opp-lon", default="lon", help="Longitude column in opportunities CSV (default: lon)")
    p.add_argument("--opp-value", default="jobs", help="Value column in opportunities (default: jobs)")
    p.add_argument("--output", required=True, help="Output directory")

    p.add_argument(
        "--mode",
        choices=["full", "isochrones-only", "ttm-only"],
        default="full",
        help="Computation mode (default: full)",
    )
    p.add_argument("--self-potential", action="store_true", help="Use district centroids as origins AND destinations")
    p.add_argument("--thresholds", nargs="+", type=int, default=[30, 45, 60], help="Time thresholds in minutes (default: 30 45 60)")
    p.add_argument("--departure", default=None, help="Departure datetime (default: 2024-03-13 08:00)")
    p.add_argument("--departure-window", type=int, default=60, help="Departure time window in minutes (default: 60)")
    p.add_argument("--max-time", type=int, default=90, help="Max travel time in minutes (default: 90)")
    p.add_argument("--max-walk", type=int, default=20, help="Max walking time in minutes (default: 20)")
    p.add_argument("--beta", type=float, default=0.1, help="Gravity decay parameter (default: 0.1)")
    p.add_argument("--decay", choices=["exponential", "power", "gaussian"], default="exponential", help="Gravity decay function (default: exponential)")
    p.add_argument("--batch-size", type=int, default=500, help="TTM batch size (default: 500)")
    p.add_argument("--station-types", nargs="+", type=int, default=None, help="GTFS route_types for station isochrones (e.g., 1 2 for subway+rail)")
    p.add_argument("--isochrone-intervals", nargs="+", type=int, default=[15, 30, 45, 60], help="Isochrone intervals in minutes (default: 15 30 45 60)")
    p.add_argument("--save-ttm", action="store_true", help="Save full travel time matrix as parquet")

    p.add_argument("--city-info", choices=list(CITY_PRESETS.keys()), help="Show city preset info and exit")
    p.add_argument("--validate-only", action="store_true", help="Only validate GTFS and exit")

    return p.parse_args(argv)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(argv: Optional[list[str]] = None) -> None:
    args = parse_args(argv)

    # City info mode
    if args.city_info:
        preset = CITY_PRESETS[args.city_info]
        print(json.dumps(preset, indent=2))
        return

    # Validate inputs
    if not args.gtfs:
        print("[ERROR] --gtfs is required", file=sys.stderr)
        sys.exit(1)
    if not args.osm and not args.validate_only:
        print("[ERROR] --osm is required (unless --validate-only)", file=sys.stderr)
        sys.exit(1)

    # Parse departure time
    if args.departure:
        departure = datetime.fromisoformat(args.departure)
    else:
        departure = datetime(2024, 3, 13, 8, 0)  # Default: Wed morning rush

    # Step 1: Validate GTFS
    log("=" * 60)
    log("Step 1: GTFS Validation")
    log("=" * 60)
    validations = {}
    for gtfs_path in args.gtfs:
        report = validate_gtfs(gtfs_path)
        validations[gtfs_path] = report
        status = "PASS" if report["valid"] else "FAIL"
        log(f"  {gtfs_path}: {status}")
        if report["stats"]:
            log(f"    Stops: {report['stats'].get('n_stops', '?')}, "
                f"Routes: {report['stats'].get('n_routes', '?')}, "
                f"Trips: {report['stats'].get('n_trips', '?')}")
        if not report["valid"]:
            for err in report["errors"]:
                log(f"    ERROR: {err}")

    if args.validate_only:
        print(json.dumps(validations, indent=2, default=str))
        return

    any_invalid = any(not v["valid"] for v in validations.values())
    if any_invalid:
        log("WARNING: Some GTFS feeds have validation errors. Proceeding anyway.")

    # Step 2: Build transport network
    log("")
    log("=" * 60)
    log("Step 2: Build Transport Network")
    log("=" * 60)
    network = build_network(args.osm, args.gtfs)

    # Step 3: Prepare origins and destinations
    log("")
    log("=" * 60)
    log("Step 3: Prepare Origins & Destinations")
    log("=" * 60)

    origins = None
    destinations = None
    districts = None
    cum_opp = None
    grav = None
    district_acc = None
    isochrones = None
    ttm = None

    if args.mode == "isochrones-only":
        # Only compute station isochrones
        log("Mode: isochrones-only")
    else:
        if args.districts:
            districts = read_spatial(args.districts, "districts")
            if args.district_id not in districts.columns:
                # Try common column names
                for candidate in ["NAME_2", "NAME_1", "name", "NAME", "id", "ID", "GID_2", "GID_1"]:
                    if candidate in districts.columns:
                        args.district_id = candidate
                        log(f"  -> Using '{candidate}' as district ID column")
                        break
                else:
                    log(f"  WARNING: '{args.district_id}' not found, using index")
                    districts[args.district_id] = range(len(districts))

        if args.self_potential:
            if districts is None:
                print("[ERROR] --districts required for --self-potential mode", file=sys.stderr)
                sys.exit(1)
            origins = district_centroids(districts, args.district_id)
            destinations = origins.copy()
            log(f"  -> Self-potential mode: {len(origins)} district centroids as origins & destinations")
        elif args.opportunities:
            opp = read_opportunities(args.opportunities, args.opp_lat, args.opp_lon, args.opp_value)
            destinations = opp
            if districts is not None:
                origins = district_centroids(districts, args.district_id)
            else:
                print("[ERROR] --districts required when using --opportunities", file=sys.stderr)
                sys.exit(1)
        elif args.mode != "isochrones-only":
            print("[ERROR] Provide --opportunities or --self-potential (or use --mode isochrones-only)", file=sys.stderr)
            sys.exit(1)

    # Step 4: Compute travel time matrix
    if origins is not None and destinations is not None:
        log("")
        log("=" * 60)
        log("Step 4: Compute Travel Time Matrix")
        log("=" * 60)
        ttm = compute_travel_time_matrix(
            network,
            origins,
            destinations,
            departure=departure,
            departure_window_min=args.departure_window,
            max_time_min=args.max_time,
            max_walk_min=args.max_walk,
            batch_size=args.batch_size,
        )

        # Step 5: Compute accessibility indices
        log("")
        log("=" * 60)
        log("Step 5: Compute Accessibility Indices")
        log("=" * 60)

        value_col = args.opp_value if not args.self_potential else args.opp_value

        # Cumulative opportunities
        cum_opp = cumulative_opportunities(
            ttm, destinations, value_col=value_col, thresholds=args.thresholds,
        )

        # Gravity index
        grav = gravity_accessibility(
            ttm, destinations, value_col=value_col,
            beta=args.beta, decay=args.decay, max_time=args.max_time,
        )

        # Merge indices
        merged = cum_opp.merge(grav, on="origin_id", how="outer")

        # Aggregate to districts
        if districts is not None:
            district_acc = aggregate_to_districts(
                merged, origins, districts, args.district_id,
            )

    # Step 6: Station isochrones
    if args.mode in ("full", "isochrones-only"):
        log("")
        log("=" * 60)
        log("Step 6: Station Service Area Isochrones")
        log("=" * 60)

        stations = extract_gtfs_stops(args.gtfs[0], route_types=args.station_types)

        if len(stations) > 200:
            log(f"  -> {len(stations)} stations found; sampling 200 for isochrone computation")
            stations = stations.sample(n=200, random_state=42).reset_index(drop=True)

        isochrones = compute_station_isochrones(
            network, stations, departure,
            intervals_min=args.isochrone_intervals,
            max_walk_min=args.max_walk,
        )

    # Step 7: Write outputs
    log("")
    log("=" * 60)
    log("Step 7: Write Outputs")
    log("=" * 60)

    write_outputs(
        output_dir=Path(args.output),
        district_acc=district_acc,
        isochrones=isochrones,
        ttm=ttm if args.save_ttm else None,
        validation=validations,
        cum_opp=cum_opp,
        grav=grav,
    )

    log("")
    log("Done.")


if __name__ == "__main__":
    main()
