#!/usr/bin/env python3
"""
zonal_stats.py — Zonal-mean aggregation of crop yield rasters to county level.

PURPOSE:
    Aggregate crop yield raster TIFs (e.g. ChinaCYWP, 30m wheat, NE China 10m)
    to China county level using GADM 4.1 level-3 boundaries and rasterstats.

INPUTS:
    --raster-root  Root directory containing dataset subdirectories.
                   Each subdirectory matches a key in the dataset registry below.
    --boundaries   GADM level-3 GeoJSON for China counties.
                   Default: ~/.maestro/cache/gadm41_CHN_3.json
    --output-dir   Directory to write per-dataset CSVs + consolidated panel.
    --dataset      Which dataset to process: chinacywp | chinawheat | ne10m | all

OUTPUT:
    {output_dir}/{dataset}_county_yield.csv  per dataset
    {output_dir}/county_yield_panel.csv      consolidated all-dataset panel

    Columns: geo_code, geo_name, geo_name_cn, year, crop, yield_kg_ha, pixel_count

EXTENDING TO NEW DATASETS:
    Add an entry to _DATASETS:
      key: (subdir_name, glob_pattern, crop_name_fn, year_fn)
    Then pass --dataset key to process it.

USAGE:
    python zonal_stats.py --raster-root ~/Dropbox/datasets/china-crop-yield-rasters \\
        --output-dir /tmp/yield_output --dataset all

    python zonal_stats.py --raster-root ~/data/rasters --dataset chinacywp --force

DEPENDENCIES:
    rasterio, rasterstats, geopandas  (pip install rasterio rasterstats geopandas)
"""

# stdlib
import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Iterator

# ---------------------------------------------------------------------------
# Dependency check -- emit actionable message before any import error
# ---------------------------------------------------------------------------
_MISSING: list[str] = []
try:
    import rasterio  # noqa: F401
except ImportError:
    _MISSING.append("rasterio")
try:
    import rasterstats  # noqa: F401
except ImportError:
    _MISSING.append("rasterstats")
try:
    import geopandas  # noqa: F401
except ImportError:
    _MISSING.append("geopandas")

if _MISSING:
    pkgs = " ".join(_MISSING)
    print(
        f"ERROR: missing libraries: {pkgs}\n"
        f"Install with:\n"
        f"  pip install {pkgs}\n",
        file=sys.stderr,
    )
    sys.exit(1)

import geopandas as gpd  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import rasterio  # noqa: E402 F811
from rasterstats import zonal_stats  # noqa: E402

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
_GADM_PATH = Path("~/.maestro/cache/gadm41_CHN_3.json").expanduser()


# ---------------------------------------------------------------------------
# Dataset definitions
# ---------------------------------------------------------------------------
# Each entry: (subdir, glob_pattern, crop_name_fn, year_fn)

def _year_from_digits(name: str) -> int:
    """Extract first 4-digit year found in filename."""
    m = re.search(r"(20\d{2})", name)
    if not m:
        raise ValueError(f"Cannot parse year from filename: {name}")
    return int(m.group(1))


def _chinacywp_crop(name: str) -> str:
    lower = name.lower()
    if lower.startswith("wheat_yield"):  return "wheat_yield"
    if lower.startswith("maize_yield"):  return "maize_yield"
    if lower.startswith("wheatcwp"):     return "wheat_cwp"
    if lower.startswith("maizecwp"):     return "maize_cwp"
    raise ValueError(f"Unrecognized ChinaCYWP filename: {name}")


def _chinawheat30m_crop(_name: str) -> str:
    return "wheat30m"


def _ne10m_crop(name: str) -> str:
    lower = name.lower()
    if "maize"   in lower: return "maize10m"
    if "rice"    in lower: return "rice10m"
    if "soybean" in lower or "soy" in lower: return "soybean10m"
    raise ValueError(f"Unrecognized NE10m filename: {name}")


# Dataset registry: key -> (subdir, glob_pattern, crop_fn, year_fn)
_DATASETS: dict[str, tuple] = {
    "chinacywp": (
        "ChinaCYWP",
        "*.tif.tif",
        _chinacywp_crop,
        _year_from_digits,
    ),
    "chinawheat": (
        "ChinaWheatYield30m",
        "*.tif",
        _chinawheat30m_crop,
        _year_from_digits,
    ),
    "ne10m": (
        "NE_China_10m",
        "*.tif",
        _ne10m_crop,
        _year_from_digits,
    ),
}


# ---------------------------------------------------------------------------
# Boundary loading
# ---------------------------------------------------------------------------
def load_boundaries(gadm_path: Path) -> gpd.GeoDataFrame:
    """Load GADM level-3 China boundaries; returns WGS84 GeoDataFrame."""
    print(f"Loading boundaries from {gadm_path} ...", file=sys.stderr)
    gdf = gpd.read_file(str(gadm_path))

    def _first_col(candidates: list[str], required: bool = True) -> str | None:
        for c in candidates:
            if c in gdf.columns:
                return c
        if required:
            raise KeyError(f"None of {candidates} found in boundary file.")
        return None

    code_col = _first_col(["GID_3", "GID3"])
    name_col = _first_col(["NAME_3", "NAME3"])
    cn_col   = _first_col(["VARNAME_3", "VARNAME3", "NL_NAME_3"], required=False)

    out = gpd.GeoDataFrame(
        {
            "geo_code":    gdf[code_col],
            "geo_name":    gdf[name_col],
            "geo_name_cn": gdf[cn_col] if cn_col else "",
        },
        geometry=gdf.geometry,
        crs=gdf.crs,
    )
    if out.crs and out.crs.to_epsg() != 4326:
        out = out.to_crs(epsg=4326)
    print(f"  {len(out)} counties loaded", file=sys.stderr)
    return out


# ---------------------------------------------------------------------------
# Raster enumeration
# ---------------------------------------------------------------------------
def iter_rasters(dataset_key: str, raster_root: Path) -> Iterator[tuple[str, int, Path]]:
    """Yield (crop, year, tif_path) for each raster file in the dataset directory."""
    subdir, glob_pat, crop_fn, year_fn = _DATASETS[dataset_key]
    raster_dir = raster_root / subdir
    if not raster_dir.exists():
        print(f"WARNING: {raster_dir} does not exist -- skipping", file=sys.stderr)
        return

    files = sorted(raster_dir.glob(glob_pat))
    if not files:
        print(f"WARNING: no files matching {glob_pat} in {raster_dir}", file=sys.stderr)
        return

    for tif_path in files:
        try:
            crop = crop_fn(tif_path.name)
            year = year_fn(tif_path.name)
        except ValueError as e:
            print(f"  WARN: skip {tif_path.name} -- {e}", file=sys.stderr)
            continue
        yield crop, year, tif_path


# ---------------------------------------------------------------------------
# Per-raster aggregation
# ---------------------------------------------------------------------------
def aggregate_one_raster(tif_path: Path, boundaries: gpd.GeoDataFrame) -> pd.DataFrame:
    """Compute zonal mean yield per county for a single raster."""
    with rasterio.open(str(tif_path)) as src:
        nodata = src.nodata
        raster_crs = src.crs
        if boundaries.crs and raster_crs and boundaries.crs.to_epsg() != raster_crs.to_epsg():
            bounds_repr = boundaries.to_crs(raster_crs)
        else:
            bounds_repr = boundaries

    stats = zonal_stats(
        bounds_repr,
        str(tif_path),
        stats=["mean", "count"],
        nodata=nodata,
        all_touched=False,
    )

    rows = []
    for i, s in enumerate(stats):
        mean_val  = s.get("mean")
        count_val = s.get("count") or 0
        if mean_val is None or np.isnan(mean_val):
            mean_val = float("nan")
        rows.append({
            "geo_code":    boundaries.iloc[i]["geo_code"],
            "geo_name":    boundaries.iloc[i]["geo_name"],
            "geo_name_cn": boundaries.iloc[i]["geo_name_cn"],
            "yield_kg_ha": round(mean_val, 4) if not np.isnan(mean_val) else None,
            "pixel_count": int(count_val),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Main aggregation loop
# ---------------------------------------------------------------------------
def run_dataset(
    dataset_key: str,
    boundaries: gpd.GeoDataFrame,
    raster_root: Path,
    output_dir: Path,
    force: bool,
) -> list[dict]:
    out_csv = output_dir / f"{dataset_key}_county_yield.csv"

    if out_csv.exists() and not force:
        print(f"  SKIP {dataset_key}: exists at {out_csv} (--force to overwrite)", file=sys.stderr)
        return [{"dataset": dataset_key, "status": "SKIP", "rasters": 0, "rows": 0}]

    all_frames: list[pd.DataFrame] = []
    results = []

    for crop, year, tif_path in iter_rasters(dataset_key, raster_root):
        print(f"  {dataset_key}: {tif_path.name} -> crop={crop} year={year}", file=sys.stderr)
        try:
            df = aggregate_one_raster(tif_path, boundaries)
        except Exception as e:
            print(f"  ERROR: {tif_path.name} -- {e}", file=sys.stderr)
            results.append({"dataset": dataset_key, "status": "ERROR", "file": tif_path.name, "error": str(e)})
            continue
        df["year"] = year
        df["crop"] = crop
        all_frames.append(df)

    if not all_frames:
        print(f"  WARNING: no rasters processed for {dataset_key}", file=sys.stderr)
        return [{"dataset": dataset_key, "status": "EMPTY", "rasters": 0, "rows": 0}]

    combined = pd.concat(all_frames, ignore_index=True)
    combined = combined[["geo_code", "geo_name", "geo_name_cn", "year", "crop", "yield_kg_ha", "pixel_count"]]
    output_dir.mkdir(parents=True, exist_ok=True)
    combined.to_csv(str(out_csv), index=False)
    print(f"  Saved {len(combined)} rows to {out_csv}", file=sys.stderr)
    return [{"dataset": dataset_key, "status": "OK", "rasters": len(all_frames),
             "rows": len(combined), "output": str(out_csv)}]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Aggregate crop yield rasters to China county level using GADM boundaries.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument(
        "--dataset",
        choices=list(_DATASETS.keys()) + ["all"],
        default="all",
        help="Which dataset to process (default: all)",
    )
    p.add_argument(
        "--raster-root", type=Path, required=True,
        help="Root directory containing dataset subdirectories (ChinaCYWP/, etc.)",
    )
    p.add_argument(
        "--boundaries", type=Path, default=_GADM_PATH,
        help=f"GADM level-3 boundary file (default: {_GADM_PATH})",
    )
    p.add_argument(
        "--output-dir", type=Path, required=True,
        help="Output directory for per-dataset CSVs and consolidated panel",
    )
    p.add_argument(
        "--force", action="store_true",
        help="Overwrite existing output files",
    )
    return p


def main() -> None:
    args = _build_parser().parse_args()

    if not args.boundaries.exists():
        print(
            f"ERROR: boundary file not found: {args.boundaries}\n"
            "Download GADM 4.1 level 3 from https://gadm.org/download_country.html\n"
            "and place at ~/.maestro/cache/gadm41_CHN_3.json",
            file=sys.stderr,
        )
        sys.exit(1)

    boundaries = load_boundaries(args.boundaries)
    datasets   = list(_DATASETS.keys()) if args.dataset == "all" else [args.dataset]
    all_results: list[dict] = []

    for ds_key in datasets:
        print(f"\n--- Processing: {ds_key} ---", file=sys.stderr)
        all_results.extend(run_dataset(ds_key, boundaries, args.raster_root, args.output_dir, args.force))

    # Merge all per-dataset CSVs into a consolidated panel
    csv_parts = [args.output_dir / f"{ds}_county_yield.csv" for ds in datasets
                 if (args.output_dir / f"{ds}_county_yield.csv").exists()]
    if csv_parts:
        panel = pd.concat([pd.read_csv(p) for p in csv_parts], ignore_index=True)
        panel_path = args.output_dir / "county_yield_panel.csv"
        panel.to_csv(str(panel_path), index=False)
        print(f"\nConsolidated panel: {panel_path}  ({len(panel)} rows)", file=sys.stderr)

    print("\n=== Summary ===")
    for r in all_results:
        status = r.get("status", "?")
        ds     = r.get("dataset", "?")
        if status == "OK":
            print(f"  OK      {ds:20s}  {r['rasters']} rasters  {r['rows']} rows  -> {r.get('output', '')}")
        elif status == "SKIP":
            print(f"  SKIP    {ds:20s}  (output exists, use --force to overwrite)")
        elif status == "ERROR":
            print(f"  ERROR   {ds:20s}  {r.get('file', '')}: {r.get('error', '')}")
        elif status == "EMPTY":
            print(f"  EMPTY   {ds:20s}  (no rasters found)")


if __name__ == "__main__":
    main()
