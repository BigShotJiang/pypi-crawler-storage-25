#!/usr/bin/env python3
"""
gee_extract.py — Google Earth Engine zonal statistics export

Extract raster statistics (mean, sum, max, min, stdDev) from a GEE
ImageCollection for a polygon layer and export to CSV files on Google Drive.

Supports both local polygon files (auto-uploaded to a GEE temp asset) and
existing GEE FeatureCollection assets.

Usage:
    python gee_extract.py DATASET_ID POLYGONS [options]

Examples:
    # Extract ERA5 monthly mean temperature for counties, 2019-2023
    python gee_extract.py ECMWF/ERA5_LAND/MONTHLY counties.shp \\
        --band temperature_2m --start 2019-01-01 --end 2023-12-31 \\
        --project my-gcp-project --output ./era5_exports/

    # Use a GEE asset as the polygon layer
    python gee_extract.py NOAA/VIIRS/DNB/MONTHLY_V21 \\
        projects/my-proj/assets/study_districts \\
        --band avg_rad --start 2020-01-01 --end 2022-12-31 \\
        --reducer mean --scale 500

    # Annual nightlights panel 2000-2023
    python gee_extract.py NOAA/VIIRS/DNB/MONTHLY_V21 districts.shp \\
        --band avg_rad --by-year 2000 2023 \\
        --output ./viirs_exports/ --project my-gcp-project

    # Monthly panel Jan 2018 - Dec 2022
    python gee_extract.py ECMWF/ERA5_LAND/MONTHLY counties.shp \\
        --band temperature_2m --by-month 2018-01 2022-12 \\
        --output ./era5_monthly/ --project my-gcp-project

    # Submit all tasks then merge downloaded CSVs later
    python gee_extract.py NOAA/VIIRS/DNB/MONTHLY_V21 districts.shp \\
        --band avg_rad --by-year 2010 2023 --no-monitor \\
        --output ./viirs/ --project my-gcp-project
    # ... after downloading CSVs from Drive ...
    python gee_extract.py NOAA/VIIRS/DNB/MONTHLY_V21 districts.shp \\
        --band avg_rad --merge-output --output ./viirs/

    # Service account auth (headless / production)
    GEE_SA_KEY_FILE=/path/to/key.json \\
    GEE_PROJECT=my-gcp-project \\
    python gee_extract.py ECMWF/ERA5_LAND/MONTHLY counties.shp \\
        --band total_precipitation_sum --start 2015-01-01 --end 2020-12-31

Environment variables:
    GEE_PROJECT       GEE project ID (overridden by --project flag)
    GEE_SA_KEY_FILE   Path to service account JSON key (optional)

Dependencies:
    earthengine-api>=1.0.0
    geopandas>=1.1.0
    pandas>=2.0.0
    python-dateutil>=2.8.0  (for --by-month; falls back to manual iteration)
"""

from __future__ import annotations

import os
import sys
import time
import json
import glob
import argparse
import calendar
from pathlib import Path
from typing import Optional

import pandas as pd
import geopandas as gpd


# ---------------------------------------------------------------------------
# GEE authentication
# ---------------------------------------------------------------------------

def init_gee(project: str | None, sa_key_file: str | None = None) -> None:
    """Initialize GEE with service account or interactive auth.

    Preference order:
      1. Service account via sa_key_file argument
      2. Service account via GEE_SA_KEY_FILE env var
      3. Interactive/cached OAuth (for local development)

    Args:
        project: GEE project ID. Also reads GEE_PROJECT env var as fallback.
        sa_key_file: Path to service account JSON key file.

    Raises:
        SystemExit: If ee cannot be imported or initialization fails.
    """
    try:
        import ee  # type: ignore
    except ImportError:
        print(
            "[gee_extract] ERROR: earthengine-api not installed. "
            "Run: pip install earthengine-api",
            file=sys.stderr,
        )
        sys.exit(1)

    gee_project = project or os.environ.get("GEE_PROJECT")
    key_file = sa_key_file or os.environ.get("GEE_SA_KEY_FILE")

    try:
        if key_file:
            print(
                f"[gee_extract] Auth: service account key {key_file}",
                file=sys.stderr,
            )
            # Read service account email from key file
            with open(key_file) as f:
                key_data = json.load(f)
            sa_email = key_data.get("client_email", "")
            creds = ee.ServiceAccountCredentials(sa_email, key_file)
            ee.Initialize(creds, project=gee_project)
        else:
            print(
                "[gee_extract] Auth: interactive / cached OAuth",
                file=sys.stderr,
            )
            ee.Initialize(project=gee_project)

        # Quick sanity check
        _ = ee.Number(1).getInfo()
        print(
            f"[gee_extract] GEE initialized (project={gee_project})",
            file=sys.stderr,
        )
    except Exception as exc:
        print(f"[gee_extract] ERROR initializing GEE: {exc}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Polygon loading
# ---------------------------------------------------------------------------

def load_polygons_as_fc(polygons_path: str, id_col: str | None) -> "ee.FeatureCollection":  # noqa: F821
    """Load polygons as a GEE FeatureCollection.

    If the path starts with 'projects/' or 'users/', treats it as a GEE
    asset ID. Otherwise reads a local file, reprojects to WGS 84, and
    uploads to a temporary GEE asset.

    Args:
        polygons_path: Local file path or GEE asset ID.
        id_col: Column to use as feature ID property.

    Returns:
        ee.FeatureCollection ready for GEE computation.
    """
    import ee  # type: ignore

    # GEE asset path
    if polygons_path.startswith("projects/") or polygons_path.startswith("users/"):
        print(
            f"[gee_extract] Using GEE asset: {polygons_path}",
            file=sys.stderr,
        )
        return ee.FeatureCollection(polygons_path)

    # Local file — convert to GeoJSON and upload as temp asset
    print(
        f"[gee_extract] Reading local polygons: {polygons_path}",
        file=sys.stderr,
    )
    try:
        if polygons_path.endswith(".parquet"):
            gdf = gpd.read_parquet(polygons_path)
        else:
            gdf = gpd.read_file(polygons_path, engine="pyogrio")
    except Exception as exc:
        print(f"[gee_extract] ERROR reading polygon file: {exc}", file=sys.stderr)
        sys.exit(1)

    # Reproject to WGS 84 (GEE native)
    if gdf.crs is None:
        print(
            "[gee_extract] WARNING: polygons have no CRS — assuming EPSG:4326",
            file=sys.stderr,
        )
        gdf = gdf.set_crs("EPSG:4326")
    elif gdf.crs.to_epsg() != 4326:
        gdf = gdf.to_crs("EPSG:4326")

    # Fix invalid geometries
    n_invalid = (~gdf.geometry.is_valid).sum()
    if n_invalid:
        print(
            f"[gee_extract] Fixing {n_invalid} invalid geometries",
            file=sys.stderr,
        )
        gdf["geometry"] = gdf.geometry.make_valid()
        gdf = gdf[gdf.geom_type.isin(["Polygon", "MultiPolygon"])]

    print(
        f"[gee_extract]   -> {len(gdf):,} polygons loaded",
        file=sys.stderr,
    )

    # Determine ID column
    non_geom_cols = [c for c in gdf.columns if c != "geometry"]
    if id_col and id_col in gdf.columns:
        use_id_col = id_col
    elif non_geom_cols:
        use_id_col = non_geom_cols[0]
        if id_col:
            print(
                f"[gee_extract] WARNING: id_col '{id_col}' not found, using '{use_id_col}'",
                file=sys.stderr,
            )
        else:
            print(
                f"[gee_extract] Using '{use_id_col}' as feature ID column",
                file=sys.stderr,
            )
    else:
        use_id_col = None
        print(
            "[gee_extract] WARNING: no non-geometry columns found; features will have no ID",
            file=sys.stderr,
        )

    # Convert to GEE features
    features = []
    for _, row in gdf.iterrows():
        geom = ee.Geometry(row.geometry.__geo_interface__)
        props = {}
        if use_id_col:
            props[use_id_col] = str(row[use_id_col])
        # Include all non-geometry columns as properties
        for col in non_geom_cols:
            val = row[col]
            if pd.isna(val):
                props[col] = None
            elif isinstance(val, (int, float)):
                props[col] = float(val)
            else:
                props[col] = str(val)
        features.append(ee.Feature(geom, props))

    fc = ee.FeatureCollection(features)
    print(
        f"[gee_extract] Converted {len(features):,} features to GEE FeatureCollection",
        file=sys.stderr,
    )
    return fc


# ---------------------------------------------------------------------------
# Reducer factory
# ---------------------------------------------------------------------------

def make_reducer(reducer_name: str) -> "ee.Reducer":  # noqa: F821
    """Build an ee.Reducer from a string name.

    Args:
        reducer_name: One of mean, sum, max, min, stdDev, frequencyHistogram.

    Returns:
        Configured ee.Reducer.

    Raises:
        SystemExit: If reducer_name is not recognized.
    """
    import ee  # type: ignore

    reducer_map = {
        "mean": ee.Reducer.mean(),
        "sum": ee.Reducer.sum(),
        "max": ee.Reducer.max(),
        "min": ee.Reducer.min(),
        "stdDev": ee.Reducer.stdDev(),
        "frequencyHistogram": ee.Reducer.frequencyHistogram().unweighted(),
    }
    if reducer_name not in reducer_map:
        print(
            f"[gee_extract] ERROR: unknown reducer '{reducer_name}'. "
            f"Choose from: {list(reducer_map.keys())}",
            file=sys.stderr,
        )
        sys.exit(1)
    return reducer_map[reducer_name]


# ---------------------------------------------------------------------------
# Auto-detect native scale for common datasets
# ---------------------------------------------------------------------------

NATIVE_SCALES: dict[str, int] = {
    "ECMWF/ERA5_LAND/MONTHLY": 9000,
    "ECMWF/ERA5_LAND/DAILY_AGGR": 9000,
    "ECMWF/ERA5/MONTHLY": 27830,
    "MODIS/061/MOD13A3": 1000,
    "MODIS/061/MCD12Q1": 500,
    "MODIS/061/MOD11A2": 1000,
    "NOAA/VIIRS/DNB/MONTHLY_V21": 500,
    "COPERNICUS/S5P/NRTI_L3_NO2": 1000,
    "UCSB-CHG/CHIRPS/DAILY": 5566,
    "UCSB-CHG/CHIRPS/PENTAD": 5566,
    "FIRMS": 375,
}


def get_scale(dataset_id: str, user_scale: int | None) -> int:
    """Determine pixel resolution for reduceRegion calls.

    Args:
        dataset_id: GEE ImageCollection ID.
        user_scale: User-specified scale, or None to auto-detect.

    Returns:
        Scale in meters.
    """
    if user_scale is not None:
        return user_scale

    # Match on prefix in case of versioned IDs
    for key, scale in NATIVE_SCALES.items():
        if dataset_id.startswith(key):
            print(
                f"[gee_extract] Auto-detected scale={scale}m for {key}",
                file=sys.stderr,
            )
            return scale

    default = 1000
    print(
        f"[gee_extract] WARNING: unknown dataset, defaulting scale={default}m. "
        "Use --scale to override.",
        file=sys.stderr,
    )
    return default


# ---------------------------------------------------------------------------
# Batch splitting
# ---------------------------------------------------------------------------

def split_into_batches(
    fc: "ee.FeatureCollection",  # noqa: F821
    batch_size: int,
) -> list[tuple[int, "ee.FeatureCollection"]]:  # noqa: F821
    """Split a FeatureCollection into sequential batches.

    Uses toList() which loads feature IDs into GEE memory — suitable for
    up to ~50k features. For larger collections prefer spatial grid splits.

    Args:
        fc: GEE FeatureCollection to split.
        batch_size: Number of features per batch.

    Returns:
        List of (start_index, batch_FeatureCollection) tuples.
    """
    import ee  # type: ignore

    total = fc.size().getInfo()
    print(
        f"[gee_extract] Total features: {total:,}, batch_size: {batch_size}",
        file=sys.stderr,
    )
    fc_list = fc.toList(total)
    batches = []
    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)
        batch = ee.FeatureCollection(fc_list.slice(start, end))
        batches.append((start, batch))
    print(
        f"[gee_extract] Split into {len(batches)} batches",
        file=sys.stderr,
    )
    return batches


# ---------------------------------------------------------------------------
# Per-feature extraction (map reduceRegion — more reliable than reduceRegions)
# ---------------------------------------------------------------------------

def make_extractor(image: "ee.Image", band: str, scale: int, tile_scale: int):  # noqa: F821
    """Factory function to avoid Python closure pitfall in GEE map() calls.

    Args:
        image: GEE Image to extract from.
        band: Band name for the result property.
        scale: Pixel resolution in meters.
        tile_scale: GEE computation tile scale (1-16).

    Returns:
        A function suitable for FeatureCollection.map().
    """
    import ee  # type: ignore

    def fn(feature: "ee.Feature") -> "ee.Feature":  # noqa: F821
        stats = image.reduceRegion(
            reducer=ee.Reducer.mean(),  # overridden externally via caller
            geometry=feature.geometry(),
            scale=scale,
            maxPixels=1e9,
            tileScale=tile_scale,
        )
        return ee.Feature(None, feature.toDictionary()).set(
            band + "_value", stats.get(band)
        )

    return fn


def make_reducer_extractor(
    image: "ee.Image",  # noqa: F821
    band: str,
    reducer: "ee.Reducer",  # noqa: F821
    scale: int,
    tile_scale: int,
):
    """Factory: extract with arbitrary reducer, adding result as property.

    Args:
        image: Single-band GEE Image.
        band: Band name (used for result property key).
        reducer: ee.Reducer to apply.
        scale: Pixel resolution in meters.
        tile_scale: GEE computation tile scale.

    Returns:
        A function suitable for FeatureCollection.map().
    """
    import ee  # type: ignore

    def fn(feature: "ee.Feature") -> "ee.Feature":  # noqa: F821
        stats = image.reduceRegion(
            reducer=reducer,
            geometry=feature.geometry(),
            scale=scale,
            maxPixels=1e9,
            tileScale=tile_scale,
        )
        # For histograms the result is a dict; for scalars a single value
        result_props = feature.toDictionary()
        for key in stats.keys().getInfo():
            result_props = result_props.set(key, stats.get(key))
        return ee.Feature(None, result_props)

    return fn


# ---------------------------------------------------------------------------
# Task monitoring
# ---------------------------------------------------------------------------

def monitor_tasks(
    tasks: list,
    interval_seconds: int = 60,
) -> dict[str, list]:
    """Poll GEE tasks until all are terminal.

    Args:
        tasks: List of ee.batch.Task objects.
        interval_seconds: Polling interval in seconds.

    Returns:
        Dict with 'completed' and 'failed' lists of task descriptions.
    """
    pending = list(tasks)
    completed: list[str] = []
    failed: list[str] = []

    while pending:
        still_running = []
        for task in pending:
            status = task.status()
            state = status["state"]
            desc = status.get("description", getattr(task, "id", str(task)))

            if state == "COMPLETED":
                print(f"[gee_extract]   DONE: {desc}", file=sys.stderr)
                completed.append(desc)
            elif state == "FAILED":
                err = status.get("error_message", "unknown error")
                print(f"[gee_extract]   FAIL: {desc} — {err}", file=sys.stderr)
                failed.append(desc)
            elif state == "CANCELLED":
                print(f"[gee_extract]   CANCELLED: {desc}", file=sys.stderr)
            else:
                still_running.append(task)

        pending = still_running
        if pending:
            ts = time.strftime("%H:%M:%S")
            print(
                f"[gee_extract] [{ts}] {len(pending)} tasks still running...",
                file=sys.stderr,
            )
            time.sleep(interval_seconds)

    print(
        f"[gee_extract] All tasks finished: "
        f"{len(completed)} completed, {len(failed)} failed.",
        file=sys.stderr,
    )
    return {"completed": completed, "failed": failed}


# ---------------------------------------------------------------------------
# Throttled task submission
# ---------------------------------------------------------------------------

def submit_throttled(
    tasks: list,
    delay_seconds: float = 2.0,
    max_queued: int = 50,
) -> list:
    """Submit GEE export tasks with throttling to avoid quota errors.

    Waits when the active queue reaches max_queued before submitting more.

    Args:
        tasks: List of ee.batch.Task objects (not yet started).
        delay_seconds: Sleep between submissions.
        max_queued: Maximum number of READY/RUNNING tasks allowed.

    Returns:
        List of submitted tasks.
    """
    submitted: list = []
    for i, task in enumerate(tasks):
        while True:
            active = [
                t for t in submitted
                if t.status()["state"] in ("READY", "RUNNING")
            ]
            if len(active) < max_queued:
                break
            print(
                f"[gee_extract] Queue full ({len(active)}/{max_queued}), "
                "waiting 30s...",
                file=sys.stderr,
            )
            time.sleep(30)

        task.start()
        submitted.append(task)
        print(
            f"[gee_extract] Submitted task {i + 1}/{len(tasks)}: "
            f"{task.status().get('description', '')}",
            file=sys.stderr,
        )
        time.sleep(delay_seconds)

    return submitted


# ---------------------------------------------------------------------------
# Period helpers (for --by-year and --by-month)
# ---------------------------------------------------------------------------

def build_year_periods(start_yr: int, end_yr: int) -> list[tuple[str, str, str]]:
    """Build (period_start, period_end, period_label) tuples for annual panel.

    Args:
        start_yr: First year (inclusive).
        end_yr: Last year (inclusive).

    Returns:
        List of (YYYY-01-01, YYYY-12-31, YYYY) tuples.
    """
    periods = []
    for year in range(start_yr, end_yr + 1):
        periods.append((f"{year}-01-01", f"{year}-12-31", str(year)))
    print(
        f"[gee_extract] Annual panel: {start_yr}-{end_yr} ({len(periods)} periods)",
        file=sys.stderr,
    )
    return periods


def build_month_periods(start_str: str, end_str: str) -> list[tuple[str, str, str]]:
    """Build (period_start, period_end, period_label) tuples for monthly panel.

    Yields one tuple per calendar month between start_str and end_str
    (both inclusive). Uses python-dateutil if available; falls back to
    manual month arithmetic.

    Args:
        start_str: Start month as YYYY-MM (e.g., "2018-01").
        end_str: End month as YYYY-MM (e.g., "2022-12").

    Returns:
        List of (YYYY-MM-01, YYYY-MM-DD, YYYY-MM) tuples where DD is last
        day of the month.
    """
    def parse_ym(s: str) -> tuple[int, int]:
        parts = s.split("-")
        if len(parts) != 2:
            print(
                f"[gee_extract] ERROR: invalid YYYY-MM format: '{s}'",
                file=sys.stderr,
            )
            sys.exit(1)
        return int(parts[0]), int(parts[1])

    start_y, start_m = parse_ym(start_str)
    end_y, end_m = parse_ym(end_str)

    periods = []
    y, m = start_y, start_m
    while (y, m) <= (end_y, end_m):
        last_day = calendar.monthrange(y, m)[1]
        label = f"{y}-{m:02d}"
        periods.append((
            f"{y}-{m:02d}-01",
            f"{y}-{m:02d}-{last_day:02d}",
            label,
        ))
        # Advance one month
        m += 1
        if m > 12:
            m = 1
            y += 1

    print(
        f"[gee_extract] Monthly panel: {start_str} to {end_str} ({len(periods)} periods)",
        file=sys.stderr,
    )
    return periods


# ---------------------------------------------------------------------------
# Merge output CSVs into panel
# ---------------------------------------------------------------------------

def merge_output_csvs(output_dir: str) -> None:
    """Merge all batch CSVs in output_dir into a single panel.csv.

    Scans output_dir for all *.csv files (excluding panel.csv itself),
    concatenates them, and writes panel.csv.

    Args:
        output_dir: Directory containing batch CSV files.
    """
    files = sorted(glob.glob(os.path.join(output_dir, "*.csv")))
    # Exclude any existing panel.csv to avoid double-counting on re-runs
    files = [f for f in files if os.path.basename(f) != "panel.csv"]

    if not files:
        print(
            f"[gee_extract] No CSV files found in {output_dir}",
            file=sys.stderr,
        )
        return

    dfs = []
    for f in files:
        try:
            dfs.append(pd.read_csv(f))
        except Exception as e:
            print(
                f"[gee_extract] WARNING: could not read {f}: {e}",
                file=sys.stderr,
            )

    if not dfs:
        print(
            "[gee_extract] ERROR: no files could be read; panel.csv not written.",
            file=sys.stderr,
        )
        return

    panel = pd.concat(dfs, ignore_index=True)
    out = os.path.join(output_dir, "panel.csv")
    panel.to_csv(out, index=False)
    print(
        f"[gee_extract] Merged {len(files)} files -> {len(panel):,} rows -> {out}",
        file=sys.stderr,
    )


# ---------------------------------------------------------------------------
# Core pipeline
# ---------------------------------------------------------------------------

def run_gee_extract(
    dataset_id: str,
    polygons_path: str,
    band: str,
    start_date: str | None,
    end_date: str | None,
    reducer_name: str = "mean",
    scale: int | None = None,
    tile_scale: int = 4,
    batch_size: int = 500,
    output_dir: str = "./gee_exports/",
    project: str | None = None,
    id_col: str | None = None,
    sa_key_file: str | None = None,
    by_year: tuple[int, int] | None = None,
    by_month: tuple[str, str] | None = None,
    no_monitor: bool = False,
    merge_output: bool = False,
) -> list[str]:
    """Full GEE extraction pipeline.

    1. Initialize GEE
    2. Load ImageCollection, optionally filter by date, select band
    3. Build period list (single period, annual, or monthly)
    4. Load polygons (local file or GEE asset)
    5. For each period: split into batches, build export tasks
    6. Submit all tasks (throttled)
    7. Optionally monitor tasks to completion
    8. Optionally merge downloaded CSVs into panel.csv
    9. Return list of Drive export descriptions

    Args:
        dataset_id: GEE ImageCollection ID.
        polygons_path: Local file path or GEE asset ID.
        band: Band name to extract.
        start_date: Start date (YYYY-MM-DD). Used only in single-period mode.
        end_date: End date (YYYY-MM-DD). Used only in single-period mode.
        reducer_name: Reducer type — mean/sum/max/min/stdDev/frequencyHistogram.
        scale: Pixel resolution in meters. None = auto-detect.
        tile_scale: GEE tile scale 1-16.
        batch_size: Features per batch export task.
        output_dir: Local directory for status tracking (not download).
        project: GEE project ID.
        id_col: Column name to use as feature ID.
        sa_key_file: Path to service account key JSON.
        by_year: (start_year, end_year) for annual panel mode.
        by_month: (start_YYYY-MM, end_YYYY-MM) for monthly panel mode.
        no_monitor: If True, skip blocking monitor loop after submission.
        merge_output: If True, merge CSVs in output_dir into panel.csv and exit.

    Returns:
        List of submitted task description strings.
    """
    import ee  # type: ignore

    # Handle --merge-output standalone mode (no GEE needed)
    if merge_output:
        merge_output_csvs(output_dir)
        return []

    # 1. Init
    init_gee(project, sa_key_file)

    # 2. Load ImageCollection (no date filter here — applied per period)
    print(f"[gee_extract] Loading ImageCollection: {dataset_id}", file=sys.stderr)
    collection = ee.ImageCollection(dataset_id)

    # 3. Build period list
    if by_year:
        periods = build_year_periods(by_year[0], by_year[1])
    elif by_month:
        periods = build_month_periods(by_month[0], by_month[1])
    else:
        # Single period (original behaviour)
        periods = [(start_date, end_date, "all")]

    # 4. Load polygons (once, shared across all periods)
    fc = load_polygons_as_fc(polygons_path, id_col)

    # 5. Determine scale and reducer
    actual_scale = get_scale(dataset_id, scale)
    reducer = make_reducer(reducer_name)

    # 6. Pre-split batches (once; all periods share same polygon set)
    batches = split_into_batches(fc, batch_size)

    # 7. Build export tasks for all periods
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    drive_folder = "GEE_Exports"
    dataset_slug = dataset_id.replace("/", "_")

    all_tasks = []
    for period_start, period_end, period_label in periods:
        # Filter collection to this period
        period_collection = collection
        if period_start:
            period_end_filter = period_end or "2099-01-01"
            period_collection = period_collection.filter(
                ee.Filter.date(period_start, period_end_filter)
            )

        n_images = period_collection.size().getInfo()
        if n_images == 0:
            print(
                f"[gee_extract] WARNING: empty collection for period {period_label} "
                f"({period_start} to {period_end}) — skipping",
                file=sys.stderr,
            )
            continue

        print(
            f"[gee_extract] Period {period_label}: {n_images} images, "
            f"computing {reducer_name} composite",
            file=sys.stderr,
        )

        image = period_collection.select(band).mean()

        def make_extract_fn(img, rdcr, sc, ts):
            """Closure factory — captures img/rdcr/sc/ts per period."""
            def fn(feature):
                stats = img.reduceRegion(
                    reducer=rdcr,
                    geometry=feature.geometry(),
                    scale=sc,
                    maxPixels=1e9,
                    tileScale=ts,
                )
                props = feature.toDictionary()
                for k in stats.keys().getInfo():
                    props = props.set(k, stats.get(k))
                return ee.Feature(None, props)
            return fn

        extract_fn = make_extract_fn(image, reducer, actual_scale, tile_scale)

        for start_idx, batch in batches:
            # Add period property to each feature so the CSV carries it
            def add_period(feature, lbl=period_label):
                return feature.set("period", lbl)

            batch_with_period = batch.map(add_period)
            result = batch_with_period.map(extract_fn)

            # File name encodes both period and batch index
            file_prefix = f"{dataset_slug}_{period_label}_{start_idx:06d}"
            task = ee.batch.Export.table.toDrive(
                collection=result,
                description=file_prefix,
                folder=drive_folder,
                fileNamePrefix=file_prefix,
                fileFormat="CSV",
            )
            all_tasks.append(task)

    if not all_tasks:
        print(
            "[gee_extract] ERROR: no tasks were created (all periods empty?).",
            file=sys.stderr,
        )
        sys.exit(1)

    print(
        f"[gee_extract] Submitting {len(all_tasks)} export tasks to Google Drive "
        f"folder '{drive_folder}'...",
        file=sys.stderr,
    )

    # 8. Submit (throttled)
    submitted = submit_throttled(all_tasks, delay_seconds=2.0, max_queued=50)

    if no_monitor:
        print(
            f"[gee_extract] --no-monitor set: skipping task monitoring.\n"
            f"  {len(submitted)} tasks submitted to Google Drive folder '{drive_folder}'.\n"
            f"  Check status at: https://code.earthengine.google.com/tasks\n"
            f"  After downloading CSVs, rerun with --merge-output to build panel.csv.",
            file=sys.stderr,
        )
        return [t.status().get("description", "") for t in submitted]

    # 9. Monitor
    results = monitor_tasks(submitted, interval_seconds=60)

    print(
        f"\n[gee_extract] Export complete.\n"
        f"  Completed: {len(results['completed'])} tasks\n"
        f"  Failed:    {len(results['failed'])} tasks\n"
        f"  Drive folder: '{drive_folder}'\n"
        f"  Download from: https://drive.google.com",
        file=sys.stderr,
    )

    if results["failed"]:
        print(
            "[gee_extract] WARNING: some tasks failed. "
            "Rerun with smaller --batch-size or larger --tile-scale.",
            file=sys.stderr,
        )

    return results["completed"] + results["failed"]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract GEE ImageCollection zonal statistics for polygon boundaries.\n\n"
            "Exports one CSV per batch to Google Drive folder 'GEE_Exports'.\n"
            "After tasks complete, download CSVs from https://drive.google.com\n"
            "and merge with --merge-output.\n\n"
            "Panel modes:\n"
            "  --by-year START END   One composite per year (annual panel)\n"
            "  --by-month START END  One composite per month (monthly panel)\n\n"
            "Authentication: set GEE_SA_KEY_FILE for headless service-account auth,\n"
            "or run 'earthengine authenticate' once for interactive OAuth."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "dataset_id",
        metavar="DATASET_ID",
        nargs="?",
        default=None,
        help="GEE ImageCollection ID (e.g., ECMWF/ERA5_LAND/MONTHLY)",
    )
    parser.add_argument(
        "polygons",
        metavar="POLYGONS",
        nargs="?",
        default=None,
        help=(
            "Path to polygon shapefile/GeoJSON/GeoParquet, "
            "OR GEE asset ID starting with 'projects/' or 'users/'"
        ),
    )
    parser.add_argument(
        "--band",
        metavar="BAND",
        default=None,
        help="Band name to extract (e.g., temperature_2m, avg_rad)",
    )
    parser.add_argument(
        "--start",
        metavar="DATE",
        default=None,
        help="Start date YYYY-MM-DD (inclusive). Single-period mode only.",
    )
    parser.add_argument(
        "--end",
        metavar="DATE",
        default=None,
        help="End date YYYY-MM-DD (inclusive). Single-period mode only.",
    )

    # --- Panel period flags ---
    period_group = parser.add_argument_group("Panel period options (mutually exclusive with --start/--end)")
    period_group.add_argument(
        "--by-year",
        nargs=2,
        type=int,
        metavar=("START_YEAR", "END_YEAR"),
        default=None,
        help=(
            "Annual panel: start year and end year (inclusive). "
            "Creates one composite per year. Example: --by-year 2000 2023"
        ),
    )
    period_group.add_argument(
        "--by-month",
        nargs=2,
        metavar=("START_YYYY_MM", "END_YYYY_MM"),
        default=None,
        help=(
            "Monthly panel: start and end months as YYYY-MM (inclusive). "
            "Creates one composite per month. Example: --by-month 2018-01 2022-12"
        ),
    )

    parser.add_argument(
        "--reducer",
        choices=["mean", "sum", "max", "min", "stdDev", "frequencyHistogram"],
        default="mean",
        help="Aggregation reducer. Default: mean.",
    )
    parser.add_argument(
        "--scale",
        type=int,
        default=None,
        metavar="INT",
        help="Pixel resolution in meters. Default: auto-detect from dataset ID.",
    )
    parser.add_argument(
        "--tile-scale",
        type=int,
        default=4,
        metavar="INT",
        help="GEE tile scale 1-16 (increase on memory errors). Default: 4.",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=500,
        metavar="INT",
        help="Features per export batch. Default: 500.",
    )
    parser.add_argument(
        "--output",
        metavar="DIR",
        default="./gee_exports/",
        help="Local directory for status files and panel.csv. Default: ./gee_exports/",
    )
    parser.add_argument(
        "--project",
        metavar="ID",
        default=None,
        help="GEE project ID. Also reads GEE_PROJECT env var.",
    )
    parser.add_argument(
        "--id-col",
        metavar="COL",
        default=None,
        help="Column to use as feature ID (default: first non-geometry column)",
    )

    # --- Output control flags ---
    output_group = parser.add_argument_group("Output control")
    output_group.add_argument(
        "--no-monitor",
        action="store_true",
        default=False,
        help=(
            "Submit all tasks to GEE and exit immediately without waiting for "
            "completion. Useful for large multi-year jobs. Check task status at "
            "https://code.earthengine.google.com/tasks"
        ),
    )
    output_group.add_argument(
        "--merge-output",
        action="store_true",
        default=False,
        help=(
            "Merge all *.csv files in --output dir into a single panel.csv. "
            "Can be run standalone after downloading CSVs from Google Drive. "
            "Does not require GEE authentication."
        ),
    )

    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # --merge-output can run standalone (no DATASET_ID / POLYGONS / --band required)
    if args.merge_output:
        merge_output_csvs(args.output)
        return

    # Validate required positional args for normal run
    if not args.dataset_id:
        print(
            "[gee_extract] ERROR: DATASET_ID is required (unless using --merge-output).",
            file=sys.stderr,
        )
        sys.exit(1)
    if not args.polygons:
        print(
            "[gee_extract] ERROR: POLYGONS is required (unless using --merge-output).",
            file=sys.stderr,
        )
        sys.exit(1)
    if not args.band:
        print(
            "[gee_extract] ERROR: --band is required (unless using --merge-output).",
            file=sys.stderr,
        )
        sys.exit(1)

    # Validate mutually exclusive period modes
    if args.by_year and args.by_month:
        print(
            "[gee_extract] ERROR: --by-year and --by-month are mutually exclusive.",
            file=sys.stderr,
        )
        sys.exit(1)
    if (args.by_year or args.by_month) and (args.start or args.end):
        print(
            "[gee_extract] WARNING: --start/--end are ignored when --by-year or "
            "--by-month is specified.",
            file=sys.stderr,
        )

    run_gee_extract(
        dataset_id=args.dataset_id,
        polygons_path=args.polygons,
        band=args.band,
        start_date=args.start,
        end_date=args.end,
        reducer_name=args.reducer,
        scale=args.scale,
        tile_scale=args.tile_scale,
        batch_size=args.batch_size,
        output_dir=args.output,
        project=args.project,
        id_col=args.id_col,
        by_year=tuple(args.by_year) if args.by_year else None,
        by_month=tuple(args.by_month) if args.by_month else None,
        no_monitor=args.no_monitor,
        merge_output=args.merge_output,
    )


if __name__ == "__main__":
    main()
