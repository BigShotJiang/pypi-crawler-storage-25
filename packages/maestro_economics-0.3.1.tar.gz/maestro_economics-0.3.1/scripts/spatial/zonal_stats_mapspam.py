#!/usr/bin/env python3
"""
aggregate_mapspam.py -- Zonal statistics of MapSPAM rasters at China county level.

Inputs:
  --mapspam-dir  Directory containing unpacked MapSPAM GeoTIFF files.
                 Expected naming pattern (any mix of 2010/2020 styles):
                   spam{year}*_{crop}_{tech}_A.tif   (harvested area, ha)
                   spam{year}*_{crop}_{tech}_Y.tif   (yield, kg/ha)
                   spam{year}*_{crop}_{tech}_P.tif   (production, tonnes)
  --boundaries   Path to China county-level GeoJSON or GPKG.
                 Default: ~/.maestro/cache/gadm41_CHN_3.json
  --output       Output CSV path.
                 Default: ~/Dropbox/datasets/china-crop-stats/mapspam/china_county_mapspam.csv
  --crops        Comma-separated crop codes to process.
                 Default: WHEA,RICE,MAIZ,SOYB,SORG,PMIL,POTA
  --years        Comma-separated years to process (matched against filename).
                 Default: all found
  --tech         Aggregation technology filter: A (all), I (irrigated), H (high input),
                 L (low input), S (subsistence), R (rainfed). Default: A.
  --china-only   Clip to China bounding box before zonal stats (faster). Default: True.
  --workers      Parallel workers for zonal stats. Default: 4.

Output columns:
  geo_code       GADM GID_3 code (county)
  geo_name       County name (English)
  geo_name_cn    County name (Chinese, NAME_3 field if present)
  province_code  GADM GID_1 code
  province_name  Province name
  year           Year (integer)
  crop_code      SPAM crop code (WHEA, RICE, etc.)
  crop_name      English crop name
  tech           Technology class (A/I/H/L/S/R)
  area_ha        Harvested area (hectares), zonal sum
  yield_kg_ha    Yield (kg/ha), zonal mean weighted by area
  production_ton Production (tonnes), zonal sum

Usage:
  # After unzipping spam2020V2r0_global_harvested_area.geotiff.zip etc. to a dir:
  python scripts/aggregate_mapspam.py --mapspam-dir ~/Dropbox/datasets/china-crop-stats/mapspam/tif

  # Specific crops and year:
  python scripts/aggregate_mapspam.py \\
      --mapspam-dir ~/path/to/tifs \\
      --crops WHEA,RICE,MAIZ,SOYB \\
      --years 2010,2020
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Iterator

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CROP_MAP: dict[str, str] = {
    "WHEA": "wheat",
    "RICE": "rice",
    "MAIZ": "corn",
    "SOYB": "soybean",
    "SORG": "sorghum",
    "PMIL": "millet",
    "POTA": "potato",
    "CASS": "cassava",
    "SUGC": "sugarcane",
    "COTT": "cotton",
    "RAPE": "rapeseed",
    "SUNF": "sunflower",
    "GROU": "groundnut",
    "BANA": "banana",
    "PLNT": "plantain",
    "TOBA": "tobacco",
    "COCO": "coconut",
    "SESA": "sesame",
    "BEAN": "drybeans",
    "LENT": "lentils",
    "CHIC": "chickpea",
    "COWP": "cowpea",
    "PIGE": "pigeonpea",
    "SMIL": "smallmillet",
    "OILP": "oilpalm",
    "ACOF": "arabica_coffee",
    "RCOF": "robusta_coffee",
    "COCO2": "cocoa",
    "TEAS": "tea",
    "SUGB": "sugarbeet",
    "YAMS": "yams",
    "SWPO": "sweetpotato",
    "ORTS": "othroots",
    "BEET": "beetroot",
    "CABI": "cabbage",
    "CARI": "carrot",
    "ONIO": "onion",
    "TOMA": "tomato",
    "VEGE": "vegetables",
    "OFIB": "otherfiber",
    "OILC": "otheroilcrops",
    "OPUL": "otherpulses",
    "OCRL": "othercereal",
}

# China bounding box (loose, includes Taiwan + disputed areas)
CHINA_BBOX = (72.0, 15.0, 137.0, 55.0)  # (west, south, east, north)

DEFAULT_CROPS = ["WHEA", "RICE", "MAIZ", "SOYB", "SORG", "PMIL", "POTA"]


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------

def _parse_tif_filename(path: Path) -> dict | None:
    """
    Parse a MapSPAM TIF filename into metadata.

    Naming conventions observed:
      spam2020V2r0_global_H_WHEA_A.tif  (2020 style: var=H=harvested_area)
      spam2010v2r0_global_H_WHEA_A.tif
      spam2020V2r0_global_Y_WHEA_A.tif
      spam2020V2r0_global_P_WHEA_A.tif
      spam2010v2r0_global_harv_area_WHEA_A.tif  (older naming)

    Returns dict with keys: year, var_code, crop_code, tech, path
    or None if the file does not match any known pattern.
    """
    import re
    name = path.stem.upper()

    # Extract year (2000, 2005, 2010, 2017, 2020, etc.)
    year_match = re.search(r"SPAM(\d{4})", name)
    if not year_match:
        return None
    year = int(year_match.group(1))

    # Variable code: H/HARV/HARVESTED_AREA -> area; Y/YIELD -> yield; P/PROD -> production
    # Tech code: A, I, H, L, S, R (last segment before .tif)
    parts = name.split("_")
    if len(parts) < 2:
        return None

    tech = parts[-1]  # last part is tech (A, I, H, L, S, R)
    crop = parts[-2]  # second-to-last is crop code

    if crop not in CROP_MAP:
        return None
    if tech not in {"A", "I", "H", "L", "S", "R"}:
        return None

    # Determine variable type.
    # Strategy: check the segment immediately after GLOBAL (index 3 in typical 6-part names)
    # which is the single-letter variable code (H/Y/P) in all known SPAM versions.
    # Also handle multi-word variable names (HARV_AREA, PHYS_AREA, etc.) as fallback.
    middle = "_".join(parts[2:-2])  # e.g. "GLOBAL_H", "GLOBAL_Y", "GLOBAL_P"

    # Find the single-letter var code: look for _H_, _Y_, _P_ patterns in the full middle,
    # or check if middle ends with _H, _Y, _P (no trailing underscore at end of zip).
    import re as _re
    _var_letter_match = _re.search(r"(?:^|_)(H|Y|P)(?:_|$)", middle)

    if _var_letter_match:
        letter = _var_letter_match.group(1)
        if letter == "H":
            var_code = "area"
        elif letter == "Y":
            var_code = "yield"
        else:
            var_code = "production"
    elif "HARV" in middle or "HARVESTED" in middle:
        var_code = "area"
    elif "PHYS" in middle or "PHYSICAL" in middle:
        var_code = "phys_area"
    elif "YIELD" in middle:
        var_code = "yield"
    elif "PROD" in middle:
        var_code = "production"
    else:
        return None

    return {
        "year": year,
        "var_code": var_code,
        "crop_code": crop,
        "tech": tech,
        "path": path,
    }


def discover_tifs(
    mapspam_dir: Path,
    crops: list[str],
    tech_filter: str,
    years: list[int] | None,
) -> list[dict]:
    """
    Walk mapspam_dir recursively and collect TIF files matching criteria.
    Returns list of metadata dicts from _parse_tif_filename.
    """
    results = []
    for tif in mapspam_dir.rglob("*.tif"):
        meta = _parse_tif_filename(tif)
        if meta is None:
            continue
        if meta["crop_code"] not in crops:
            continue
        if meta["tech"] != tech_filter:
            continue
        if years and meta["year"] not in years:
            continue
        results.append(meta)

    results.sort(key=lambda m: (m["year"], m["crop_code"], m["var_code"]))
    return results


# ---------------------------------------------------------------------------
# Boundary loading
# ---------------------------------------------------------------------------

def load_china_counties(boundaries_path: Path) -> "geopandas.GeoDataFrame":
    """
    Load China county-level (ADM3) boundaries from GeoJSON or GPKG.
    Returns GeoDataFrame with columns: geo_code, geo_name, geo_name_cn,
    province_code, province_name, geometry.
    """
    import geopandas as gpd

    logger.info("Loading boundaries from %s", boundaries_path)
    if not boundaries_path.exists():
        raise FileNotFoundError(
            f"Boundaries file not found: {boundaries_path}\n"
            "Download GADM China L3 from https://gadm.org/download_country.html\n"
            "or: python -c \"import urllib.request; urllib.request.urlretrieve(\n"
            "  'https://geodata.ucdavis.edu/gadm/gadm4.1/json/gadm41_CHN_3.json.zip',\n"
            "  '~/.maestro/cache/gadm41_CHN_3.json.zip')\""
        )

    gdf = gpd.read_file(str(boundaries_path))

    # Normalize column names (GADM 4.1 naming)
    col_map = {}
    for col in gdf.columns:
        cu = col.upper()
        if cu in ("GID_3",):
            col_map[col] = "geo_code"
        elif cu == "NAME_3":
            col_map[col] = "geo_name"
        elif cu == "NL_NAME_3":
            col_map[col] = "geo_name_cn"
        elif cu in ("GID_1",):
            col_map[col] = "province_code"
        elif cu == "NAME_1":
            col_map[col] = "province_name"
    gdf = gdf.rename(columns=col_map)

    # Ensure required columns exist
    for required in ("geo_code", "geo_name", "province_code", "province_name"):
        if required not in gdf.columns:
            gdf[required] = ""

    if "geo_name_cn" not in gdf.columns:
        gdf["geo_name_cn"] = ""

    # Reproject to WGS84 (EPSG:4326) -- required for MapSPAM which is geographic
    if gdf.crs is None or gdf.crs.to_epsg() != 4326:
        gdf = gdf.to_crs(epsg=4326)

    logger.info("Loaded %d county polygons", len(gdf))
    return gdf[["geo_code", "geo_name", "geo_name_cn", "province_code", "province_name", "geometry"]]


# ---------------------------------------------------------------------------
# Raster clipping (China bbox)
# ---------------------------------------------------------------------------

def clip_to_china_bbox(src_path: Path, dst_path: Path) -> None:
    """
    Clip a global raster to the China bounding box and write to dst_path.
    Uses rasterio windowed read (no in-memory copy of the full global raster).
    """
    import rasterio
    from rasterio.windows import from_bounds
    from rasterio.transform import from_bounds as transform_from_bounds

    west, south, east, north = CHINA_BBOX

    with rasterio.open(src_path) as src:
        window = from_bounds(west, south, east, north, src.transform)
        window = window.round_lengths().round_offsets()

        # Clamp to valid pixel range
        col_off = max(0, int(window.col_off))
        row_off = max(0, int(window.row_off))
        width = min(int(window.width), src.width - col_off)
        height = min(int(window.height), src.height - row_off)
        window = rasterio.windows.Window(col_off, row_off, width, height)

        data = src.read(1, window=window)
        new_transform = src.window_transform(window)
        profile = src.profile.copy()
        profile.update(width=width, height=height, transform=new_transform)

    with rasterio.open(dst_path, "w", **profile) as dst:
        dst.write(data, 1)


# ---------------------------------------------------------------------------
# Zonal statistics
# ---------------------------------------------------------------------------

def _zonal_sum(raster_path: Path, gdf: "geopandas.GeoDataFrame") -> np.ndarray:
    """Compute zonal sum of raster per polygon. Returns array of shape (len(gdf),)."""
    from rasterstats import zonal_stats
    stats = zonal_stats(
        gdf.__geo_interface__,
        str(raster_path),
        stats=["sum"],
        nodata=-9999,
        all_touched=False,
    )
    return np.array([s["sum"] if s["sum"] is not None else np.nan for s in stats])


def _zonal_mean(raster_path: Path, gdf: "geopandas.GeoDataFrame") -> np.ndarray:
    """Compute zonal mean of raster per polygon. Returns array of shape (len(gdf),)."""
    from rasterstats import zonal_stats
    stats = zonal_stats(
        gdf.__geo_interface__,
        str(raster_path),
        stats=["mean"],
        nodata=-9999,
        all_touched=False,
    )
    return np.array([s["mean"] if s["mean"] is not None else np.nan for s in stats])


# ---------------------------------------------------------------------------
# Main aggregation logic
# ---------------------------------------------------------------------------

def _process_one(
    meta_group: dict,
    gdf: "geopandas.GeoDataFrame",
    clip_dir: Path,
) -> pd.DataFrame:
    """
    Process a (year, crop, tech) group containing area/yield/production paths.
    Returns a DataFrame with one row per county.
    """
    year = meta_group["year"]
    crop_code = meta_group["crop_code"]
    tech = meta_group["tech"]

    area_path = meta_group.get("area")
    yield_path = meta_group.get("yield")
    prod_path = meta_group.get("production")

    label = f"{year} {crop_code} {tech}"
    logger.info("Processing %s", label)

    # Clip rasters to China bbox
    def _clip(src: Path | None) -> Path | None:
        if src is None:
            return None
        clipped = clip_dir / f"clip_{src.name}"
        if not clipped.exists():
            clip_to_china_bbox(src, clipped)
        return clipped

    area_clip = _clip(area_path)
    yield_clip = _clip(yield_path)
    prod_clip = _clip(prod_path)

    # Compute zonal stats
    area_vals = _zonal_sum(area_clip, gdf) if area_clip else np.full(len(gdf), np.nan)
    prod_vals = _zonal_sum(prod_clip, gdf) if prod_clip else np.full(len(gdf), np.nan)

    # Yield: area-weighted mean from production/area to avoid nodata bias,
    # fall back to direct mean if only yield raster is available.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if area_clip and prod_clip:
            # yield = total_production / total_area (both in matching units)
            # area in ha, production in tonnes -- yield in tonnes/ha * 1000 = kg/ha
            yield_vals = np.where(
                area_vals > 0,
                prod_vals / area_vals * 1000.0,  # t/ha -> kg/ha
                np.nan,
            )
        elif yield_clip:
            yield_vals = _zonal_mean(yield_clip, gdf)
        else:
            yield_vals = np.full(len(gdf), np.nan)

    rows = pd.DataFrame(
        {
            "geo_code": gdf["geo_code"].values,
            "geo_name": gdf["geo_name"].values,
            "geo_name_cn": gdf["geo_name_cn"].values,
            "province_code": gdf["province_code"].values,
            "province_name": gdf["province_name"].values,
            "year": year,
            "crop_code": crop_code,
            "crop_name": CROP_MAP.get(crop_code, crop_code.lower()),
            "tech": tech,
            "area_ha": area_vals,
            "yield_kg_ha": yield_vals,
            "production_ton": prod_vals,
        }
    )

    # Drop rows where all three values are NaN or effectively zero
    mask = (
        rows["area_ha"].notna() | rows["yield_kg_ha"].notna() | rows["production_ton"].notna()
    )
    rows = rows[mask].reset_index(drop=True)

    # Zero-area rows are not useful for research; keep them but flag via NaN yield
    logger.info("  %s: %d county-rows (non-null)", label, len(rows))
    return rows


def aggregate(
    mapspam_dir: Path,
    boundaries_path: Path,
    output_path: Path,
    crops: list[str],
    tech_filter: str,
    years: list[int] | None,
    china_only: bool,
    workers: int,
) -> None:
    """Full pipeline: discover TIFs -> load boundaries -> zonal stats -> write CSV."""
    import geopandas as gpd  # noqa: F401 (imported here to produce clear error if missing)

    # 1. Discover TIF files
    tif_metas = discover_tifs(mapspam_dir, crops, tech_filter, years)
    if not tif_metas:
        logger.error(
            "No matching TIF files found in %s for crops=%s tech=%s years=%s",
            mapspam_dir, crops, tech_filter, years,
        )
        logger.error(
            "Make sure you have unzipped the downloaded .zip files into --mapspam-dir."
        )
        sys.exit(1)

    logger.info("Found %d TIF files to process", len(tif_metas))

    # 2. Group by (year, crop, tech)
    from collections import defaultdict
    groups: dict[tuple, dict] = defaultdict(dict)
    for m in tif_metas:
        key = (m["year"], m["crop_code"], m["tech"])
        groups[key]["year"] = m["year"]
        groups[key]["crop_code"] = m["crop_code"]
        groups[key]["tech"] = m["tech"]
        groups[key][m["var_code"]] = m["path"]

    logger.info("Grouped into %d (year, crop, tech) combinations", len(groups))

    # 3. Load boundaries
    gdf = load_china_counties(boundaries_path)

    # 4. Prepare clip directory
    clip_dir = mapspam_dir / "_clips"
    clip_dir.mkdir(exist_ok=True)

    # 5. Run zonal stats (parallel by group)
    all_frames: list[pd.DataFrame] = []

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_process_one, grp, gdf, clip_dir): key
            for key, grp in groups.items()
        }
        for fut in as_completed(futures):
            key = futures[fut]
            try:
                df = fut.result()
                all_frames.append(df)
            except Exception as exc:
                logger.error("Failed %s: %s", key, exc)

    if not all_frames:
        logger.error("No results produced; check errors above.")
        sys.exit(1)

    # 6. Concatenate and write
    result = pd.concat(all_frames, ignore_index=True)
    result = result.sort_values(["province_code", "geo_code", "year", "crop_code"]).reset_index(drop=True)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False, float_format="%.4f")

    logger.info(
        "Wrote %d rows to %s", len(result), output_path
    )
    print(f"Output: {output_path} ({len(result):,} rows)")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Aggregate MapSPAM rasters to China county level.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument(
        "--mapspam-dir",
        type=Path,
        required=True,
        help="Directory containing unpacked MapSPAM GeoTIFF files.",
    )
    p.add_argument(
        "--boundaries",
        type=Path,
        default=Path.home() / ".maestro/cache/gadm41_CHN_3.json",
        help="China county-level boundaries GeoJSON or GPKG. Default: ~/.maestro/cache/gadm41_CHN_3.json",
    )
    p.add_argument(
        "--output",
        type=Path,
        default=Path("china_county_mapspam.csv"),
        help="Output CSV path.",
    )
    p.add_argument(
        "--crops",
        default=",".join(DEFAULT_CROPS),
        help=f"Comma-separated crop codes. Default: {','.join(DEFAULT_CROPS)}",
    )
    p.add_argument(
        "--years",
        default="",
        help="Comma-separated years to include (e.g. 2010,2020). Default: all found.",
    )
    p.add_argument(
        "--tech",
        default="A",
        choices=["A", "I", "H", "L", "S", "R"],
        help="Technology class to aggregate. A=all (default), I=irrigated, H=high-input, "
             "L=low-input, S=subsistence, R=rainfed.",
    )
    p.add_argument(
        "--no-china-clip",
        action="store_true",
        default=False,
        help="Skip clipping rasters to China bounding box (slower but complete).",
    )
    p.add_argument(
        "--workers",
        type=int,
        default=4,
        help="Parallel workers for zonal stats. Default: 4.",
    )
    p.add_argument(
        "--verbose", "-v",
        action="store_true",
        default=False,
        help="Enable debug logging.",
    )
    p.add_argument(
        "--list-files",
        action="store_true",
        default=False,
        help="Discover and list matching TIF files then exit (no processing).",
    )
    return p.parse_args()


def main() -> None:
    args = _parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
    )

    crops = [c.strip().upper() for c in args.crops.split(",") if c.strip()]
    years = [int(y.strip()) for y in args.years.split(",") if y.strip()]

    if args.list_files:
        tifs = discover_tifs(args.mapspam_dir, crops, args.tech, years or None)
        print(f"Found {len(tifs)} matching TIF files in {args.mapspam_dir}:")
        for m in tifs:
            print(f"  {m['year']} {m['crop_code']} {m['var_code']} tech={m['tech']}: {m['path'].name}")
        return

    # Verify libraries
    missing = []
    for lib in ("rasterio", "rasterstats", "geopandas"):
        try:
            __import__(lib)
        except ImportError:
            missing.append(lib)
    if missing:
        print(
            f"ERROR: Missing libraries: {', '.join(missing)}\n"
            f"Install with: pip install {' '.join(missing)}",
            file=sys.stderr,
        )
        sys.exit(1)

    aggregate(
        mapspam_dir=args.mapspam_dir,
        boundaries_path=args.boundaries,
        output_path=args.output,
        crops=crops,
        tech_filter=args.tech,
        years=years or None,
        china_only=not args.no_china_clip,
        workers=args.workers,
    )


if __name__ == "__main__":
    main()
