#!/usr/bin/env python3
"""
spatial_join.py — Point/polygon spatial join

Assign attributes from a polygon layer to points (or polygon-to-polygon
with area weighting). Outputs a CSV or GeoJSON panel ready for regression.

Usage:
    python spatial_join.py POINTS POLYGONS [options]

Examples:
    # Assign county attributes to pollution monitors
    python spatial_join.py monitors.shp counties.shp --output monitors_with_county.csv

    # Keep only specific columns from polygons
    python spatial_join.py wells.geojson counties.shp --keep-cols county_fips,county_name

    # Nearest-neighbor join (e.g., assign closest district to each village)
    python spatial_join.py villages.shp districts.shp --predicate nearest --max-distance 50000

    # Buffer monitors by 50 km before joining to districts
    python spatial_join.py monitors.shp districts.shp --buffer-km 50 --output buffered.csv

    # Area-weighted aggregation: assign population-weighted GDP to new boundaries
    python spatial_join.py new_bounds.shp old_districts.shp --area-weight --output wavg.csv

    # Dissolve output to region level after point-in-polygon join
    python spatial_join.py plants.shp states.shp --dissolve-by state_fips --output states_agg.csv

    # Overlay intersection (outputs geometry)
    python spatial_join.py layer_a.shp layer_b.shp --overlay intersection --output out.geojson

Dependencies:
    geopandas>=1.1.0
    pandas>=2.0.0
    shapely>=2.0.0
"""

from __future__ import annotations

import sys
import argparse
from typing import Optional

import pandas as pd
import geopandas as gpd


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def read_spatial_file(path: str, label: str = "file") -> gpd.GeoDataFrame:
    """Read a shapefile, GeoJSON, or GeoParquet into a GeoDataFrame.

    Tries GeoParquet first (fast columnar read), then falls back to
    vector formats via pyogrio (geopandas >= 0.14 default).

    Args:
        path: File path to read.
        label: Human-readable label used in error messages.

    Returns:
        GeoDataFrame with valid CRS (or CRS=None if source has no .prj).
    """
    print(f"[spatial_join] Reading {label}: {path}", file=sys.stderr)
    try:
        if path.endswith(".parquet"):
            gdf = gpd.read_parquet(path)
        else:
            gdf = gpd.read_file(path, engine="pyogrio")
    except Exception as exc:
        print(f"[spatial_join] ERROR reading {label} '{path}': {exc}", file=sys.stderr)
        sys.exit(1)

    print(
        f"[spatial_join]   -> {len(gdf):,} features, CRS={gdf.crs}",
        file=sys.stderr,
    )
    return gdf


def fix_invalid_geometries(gdf: gpd.GeoDataFrame, label: str = "") -> gpd.GeoDataFrame:
    """Apply make_valid() to all geometries and log how many were fixed.

    Args:
        gdf: Input GeoDataFrame.
        label: Human-readable label for logging.

    Returns:
        GeoDataFrame with valid geometries.
    """
    n_invalid = (~gdf.geometry.is_valid).sum()
    if n_invalid > 0:
        print(
            f"[spatial_join] Fixing {n_invalid} invalid geometries in {label}",
            file=sys.stderr,
        )
        gdf = gdf.copy()
        gdf["geometry"] = gdf.geometry.make_valid()
        # make_valid can produce GeometryCollections — keep only Polygon/MultiPolygon
        before = len(gdf)
        gdf = gdf[gdf.geom_type.isin(["Point", "MultiPoint", "Polygon", "MultiPolygon", "LineString", "MultiLineString"])]
        dropped = before - len(gdf)
        if dropped:
            print(
                f"[spatial_join]   Dropped {dropped} non-standard geometry types after make_valid",
                file=sys.stderr,
            )
    return gdf


def align_crs(
    left: gpd.GeoDataFrame,
    right: gpd.GeoDataFrame,
    label_left: str = "left",
    label_right: str = "right",
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """Ensure both GeoDataFrames share the same CRS.

    Reprojects `right` to match `left`. If either has no CRS, assumes
    WGS 84 (EPSG:4326) and warns.

    Args:
        left: Primary GeoDataFrame (CRS is authoritative).
        right: GeoDataFrame to reproject if needed.
        label_left: Human-readable label for left layer.
        label_right: Human-readable label for right layer.

    Returns:
        Tuple (left, right) sharing the same CRS.
    """
    if left.crs is None:
        print(
            f"[spatial_join] WARNING: {label_left} has no CRS — assuming EPSG:4326",
            file=sys.stderr,
        )
        left = left.set_crs("EPSG:4326")

    if right.crs is None:
        print(
            f"[spatial_join] WARNING: {label_right} has no CRS — assuming EPSG:4326",
            file=sys.stderr,
        )
        right = right.set_crs("EPSG:4326")

    if left.crs != right.crs:
        print(
            f"[spatial_join] CRS mismatch: reprojecting {label_right} "
            f"({right.crs}) -> {left.crs}",
            file=sys.stderr,
        )
        right = right.to_crs(left.crs)

    return left, right


# ---------------------------------------------------------------------------
# Buffer helper
# ---------------------------------------------------------------------------

def buffer_geodataframe(gdf: gpd.GeoDataFrame, buffer_km: float) -> gpd.GeoDataFrame:
    """Buffer all geometries by buffer_km kilometers using UTM projection.

    Projects to the auto-detected UTM CRS (meter-accurate), applies a
    buffer in meters, then reprojects back to the original CRS.

    Args:
        gdf: Input GeoDataFrame (any CRS).
        buffer_km: Buffer distance in kilometers.

    Returns:
        GeoDataFrame with buffered geometries in the original CRS.
    """
    original_crs = gdf.crs
    utm_crs = gdf.estimate_utm_crs()
    print(
        f"[spatial_join] Buffering by {buffer_km} km using UTM CRS {utm_crs}",
        file=sys.stderr,
    )
    gdf_proj = gdf.to_crs(utm_crs).copy()
    gdf_proj["geometry"] = gdf_proj.geometry.buffer(buffer_km * 1000)
    result = gdf_proj.to_crs(original_crs)
    print(
        f"[spatial_join]   -> {len(result):,} features buffered",
        file=sys.stderr,
    )
    return result


# ---------------------------------------------------------------------------
# Area-weighted polygon aggregation
# ---------------------------------------------------------------------------

def area_weighted_join(
    left: gpd.GeoDataFrame,
    right: gpd.GeoDataFrame,
) -> pd.DataFrame:
    """Area-weighted aggregation of right polygon attributes to left polygons.

    For each left polygon, computes the area-weighted mean of all numeric
    columns in the right layer based on intersection areas. The weight for
    each right polygon contributing to a left polygon is:

        weight = intersection_area / right_polygon_area

    (i.e., the fraction of the right polygon that falls inside the left polygon)

    This correctly handles partial overlaps: a right polygon 80% inside a
    left polygon contributes 80% of its value.

    Args:
        left: Left polygon GeoDataFrame (target boundaries).
        right: Right polygon GeoDataFrame (source of values to aggregate).

    Returns:
        DataFrame with left polygon index and {col}_wavg columns for each
        numeric column in right. Also includes a _coverage column (sum of
        weights, i.e., total fractional area covered).
    """
    utm_crs = left.estimate_utm_crs()
    print(
        f"[spatial_join] Area-weighted join using UTM CRS {utm_crs}",
        file=sys.stderr,
    )
    left_proj = left.to_crs(utm_crs).copy()
    right_proj = right.to_crs(utm_crs).copy()

    # Compute right polygon areas before intersection
    right_proj = right_proj.copy()
    right_proj["_rarea"] = right_proj.geometry.area

    # Identify numeric columns in right (excluding geometry, _rarea)
    numeric_cols = [
        c for c in right_proj.select_dtypes("number").columns.tolist()
        if c != "_rarea"
    ]
    if not numeric_cols:
        print(
            "[spatial_join] WARNING: no numeric columns found in right layer "
            "for area-weighted aggregation.",
            file=sys.stderr,
        )

    print(
        f"[spatial_join] Computing intersection for area-weighted join "
        f"({len(left_proj):,} left x {len(right_proj):,} right polygons)...",
        file=sys.stderr,
    )

    # Compute intersection
    intersection = gpd.overlay(
        left_proj.reset_index().rename(columns={"index": "_left_idx"}),
        right_proj.reset_index().rename(columns={"index": "_right_idx"}),
        how="intersection",
        keep_geom_type=False,
    )

    if intersection.empty:
        print(
            "[spatial_join] WARNING: intersection is empty — no overlapping polygons.",
            file=sys.stderr,
        )
        return pd.DataFrame()

    intersection["_iarea"] = intersection.geometry.area

    # Weight = intersection_area / right_polygon_area
    # (fraction of right polygon covered by intersection)
    intersection["_weight"] = intersection["_iarea"] / intersection["_rarea"]

    # Compute weighted mean per left polygon
    records = []
    for left_idx, grp in intersection.groupby("_left_idx"):
        row: dict = {"_left_idx": left_idx}
        total_weight = grp["_weight"].sum()
        row["_coverage"] = total_weight
        for col in numeric_cols:
            if col in grp.columns:
                wavg = (grp[col] * grp["_weight"]).sum() / total_weight if total_weight > 0 else float("nan")
                row[f"{col}_wavg"] = wavg
        records.append(row)

    result_df = pd.DataFrame(records).set_index("_left_idx")
    print(
        f"[spatial_join] Area-weighted join: {len(result_df):,} left polygons with values",
        file=sys.stderr,
    )
    return result_df


# ---------------------------------------------------------------------------
# Dissolve helper
# ---------------------------------------------------------------------------

def dissolve_result(
    result: gpd.GeoDataFrame,
    dissolve_by: str,
) -> gpd.GeoDataFrame:
    """Dissolve/aggregate result GeoDataFrame by a column.

    Numeric columns are summed; the geometry is unioned.

    Args:
        result: GeoDataFrame to dissolve.
        dissolve_by: Column name to group by.

    Returns:
        Dissolved GeoDataFrame.
    """
    if dissolve_by not in result.columns:
        print(
            f"[spatial_join] ERROR: --dissolve-by column '{dissolve_by}' not found in output. "
            f"Available columns: {list(result.columns)}",
            file=sys.stderr,
        )
        import sys as _sys
        _sys.exit(1)

    print(
        f"[spatial_join] Dissolving by '{dissolve_by}' "
        f"({result[dissolve_by].nunique():,} unique values)...",
        file=sys.stderr,
    )

    # Build aggfunc: sum for numeric cols, first for others (excluding geometry and key)
    numeric_cols = result.select_dtypes("number").columns.tolist()
    aggfunc = {col: "sum" for col in numeric_cols if col != dissolve_by}

    dissolved = result.dissolve(by=dissolve_by, aggfunc=aggfunc).reset_index()
    print(
        f"[spatial_join] Dissolved: {len(dissolved):,} groups",
        file=sys.stderr,
    )
    return dissolved


# ---------------------------------------------------------------------------
# Core join functions
# ---------------------------------------------------------------------------

def run_within_or_intersects(
    points: gpd.GeoDataFrame,
    polygons: gpd.GeoDataFrame,
    predicate: str,
    how: str,
    keep_cols: list[str] | None,
) -> gpd.GeoDataFrame:
    """Execute gpd.sjoin with within or intersects predicate.

    Args:
        points: Left GeoDataFrame (points or any geometry).
        polygons: Right GeoDataFrame (polygons).
        predicate: "within" or "intersects".
        how: Join type — "left", "inner", or "right".
        keep_cols: Columns to retain from polygons (None = all).

    Returns:
        Joined GeoDataFrame with reset index.
    """
    right = polygons.copy()
    if keep_cols:
        missing = [c for c in keep_cols if c not in right.columns]
        if missing:
            print(
                f"[spatial_join] WARNING: columns not found in polygons and will be skipped: {missing}",
                file=sys.stderr,
            )
        valid_keep = [c for c in keep_cols if c in right.columns]
        right = right[valid_keep + ["geometry"]]

    print(
        f"[spatial_join] Running sjoin: predicate={predicate}, how={how}",
        file=sys.stderr,
    )
    result = gpd.sjoin(points, right, how=how, predicate=predicate)
    result = result.reset_index(drop=True)

    # Drop the sjoin-generated index_right column
    if "index_right" in result.columns:
        result = result.drop(columns=["index_right"])
    if "index_left" in result.columns:
        result = result.drop(columns=["index_left"])

    return result


def run_nearest(
    points: gpd.GeoDataFrame,
    polygons: gpd.GeoDataFrame,
    how: str,
    keep_cols: list[str] | None,
    max_distance: float | None,
) -> gpd.GeoDataFrame:
    """Execute gpd.sjoin_nearest.

    For nearest joins the distance argument requires a projected CRS
    (meters). The function reprojects to the auto-detected UTM zone,
    performs the join, then returns results in the original CRS.

    Args:
        points: Left GeoDataFrame.
        polygons: Right GeoDataFrame.
        how: Join type — "left", "inner", or "right".
        keep_cols: Columns to retain from polygons (None = all).
        max_distance: Maximum search distance in meters (None = unlimited).

    Returns:
        Joined GeoDataFrame with reset index and distance_m column.
    """
    right = polygons.copy()
    if keep_cols:
        missing = [c for c in keep_cols if c not in right.columns]
        if missing:
            print(
                f"[spatial_join] WARNING: columns not in polygons, skipping: {missing}",
                file=sys.stderr,
            )
        valid_keep = [c for c in keep_cols if c in right.columns]
        right = right[valid_keep + ["geometry"]]

    # Project to UTM for meter-accurate distance
    utm_crs = points.estimate_utm_crs()
    print(
        f"[spatial_join] Projecting to {utm_crs} for nearest join (max_distance={max_distance}m)",
        file=sys.stderr,
    )
    points_proj = points.to_crs(utm_crs)
    right_proj = right.to_crs(utm_crs)

    kwargs: dict = {"how": how, "distance_col": "distance_m"}
    if max_distance is not None:
        kwargs["max_distance"] = max_distance

    result = gpd.sjoin_nearest(points_proj, right_proj, **kwargs)
    result = result.reset_index(drop=True)

    # Reproject geometry back to original CRS
    result = result.set_crs(utm_crs).to_crs(points.crs)

    if "index_right" in result.columns:
        result = result.drop(columns=["index_right"])
    if "index_left" in result.columns:
        result = result.drop(columns=["index_left"])

    return result


def run_overlay(
    left: gpd.GeoDataFrame,
    right: gpd.GeoDataFrame,
    how: str,
    keep_cols: list[str] | None,
) -> gpd.GeoDataFrame:
    """Execute gpd.overlay with the specified set operation.

    Args:
        left: Left GeoDataFrame.
        right: Right GeoDataFrame.
        how: Overlay type — intersection, union, difference,
             symmetric_difference, or identity.
        keep_cols: Columns to retain from right layer (None = all).

    Returns:
        Result GeoDataFrame with geometry.
    """
    right = right.copy()
    if keep_cols:
        missing = [c for c in keep_cols if c not in right.columns]
        if missing:
            print(
                f"[spatial_join] WARNING: columns not found in right layer and will be skipped: {missing}",
                file=sys.stderr,
            )
        valid_keep = [c for c in keep_cols if c in right.columns]
        right = right[valid_keep + ["geometry"]]

    valid_how = {"intersection", "union", "difference", "symmetric_difference", "identity"}
    if how not in valid_how:
        print(
            f"[spatial_join] ERROR: --overlay must be one of {sorted(valid_how)}, got '{how}'.",
            file=sys.stderr,
        )
        import sys as _sys
        _sys.exit(1)

    print(
        f"[spatial_join] Running gpd.overlay: how={how}",
        file=sys.stderr,
    )
    result = gpd.overlay(left, right, how=how, keep_geom_type=False)
    result = result.reset_index(drop=True)
    return result


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

def write_output(
    result: gpd.GeoDataFrame,
    output_path: str | None,
    drop_geometry: bool,
) -> None:
    """Write join result to CSV (stdout or file) or GeoJSON.

    Args:
        result: Joined GeoDataFrame.
        output_path: Destination path. None = stdout. .geojson/.gpkg = spatial.
        drop_geometry: If True, drop geometry column before CSV output.
    """
    if output_path and (
        output_path.endswith(".geojson") or output_path.endswith(".gpkg")
    ):
        print(f"[spatial_join] Writing spatial output: {output_path}", file=sys.stderr)
        result.to_file(output_path)
        return

    # Tabular output
    if drop_geometry and "geometry" in result.columns:
        df: pd.DataFrame = result.drop(columns=["geometry"])
    else:
        df = pd.DataFrame(result)

    if output_path:
        print(
            f"[spatial_join] Writing CSV: {output_path} ({len(df):,} rows)",
            file=sys.stderr,
        )
        df.to_csv(output_path, index=False)
    else:
        print(f"[spatial_join] Writing CSV to stdout ({len(df):,} rows)", file=sys.stderr)
        df.to_csv(sys.stdout, index=False)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_spatial_join(
    points_path: str,
    polygons_path: str,
    output_path: str | None = None,
    predicate: str = "within",
    keep_cols: list[str] | None = None,
    how: str = "left",
    max_distance: float | None = None,
    drop_geometry: bool = True,
    buffer_km: float | None = None,
    area_weight: bool = False,
    dissolve_by: str | None = None,
    overlay: str | None = None,
) -> gpd.GeoDataFrame:
    """Execute a full spatial join pipeline.

    Reads both files, aligns CRS, fixes invalid geometries, optionally
    buffers left layer, then performs the requested join/overlay, and
    returns the result GeoDataFrame.

    Args:
        points_path: Path to points/left shapefile/GeoJSON/GeoParquet.
        polygons_path: Path to polygons/right shapefile/GeoJSON/GeoParquet.
        output_path: Output file path. None = no file written (return only).
        predicate: Spatial predicate — "within", "intersects", or "nearest".
        keep_cols: List of columns to retain from polygons. None = all.
        how: Join type — "left", "inner", or "right".
        max_distance: Max search distance in meters (nearest only).
        drop_geometry: Drop geometry column before CSV output.
        buffer_km: Buffer left layer by this many km before joining.
        area_weight: Compute area-weighted mean instead of sjoin.
        dissolve_by: Dissolve output by this column after join.
        overlay: Run gpd.overlay with this operation instead of sjoin.

    Returns:
        Joined GeoDataFrame.
    """
    # 1. Read inputs
    points = read_spatial_file(points_path, "left/points")
    polygons = read_spatial_file(polygons_path, "right/polygons")

    # 2. Align CRS (reproject polygons to match points)
    points, polygons = align_crs(points, polygons, "points", "polygons")

    # 3. Fix invalid geometries
    points = fix_invalid_geometries(points, "points")
    polygons = fix_invalid_geometries(polygons, "polygons")

    # 4. Optional buffer
    if buffer_km is not None:
        points = buffer_geodataframe(points, buffer_km)

    # 5. Run join / overlay / area-weight
    if overlay:
        result = run_overlay(points, polygons, overlay, keep_cols)
    elif area_weight:
        # Area-weighted join: merge wavg columns back onto left GeoDataFrame
        wavg_df = area_weighted_join(points, polygons)
        if wavg_df.empty:
            result = points.copy()
        else:
            result = points.copy().reset_index()
            result = result.merge(wavg_df, left_on="index", right_index=True, how="left")
            if "index" in result.columns:
                result = result.drop(columns=["index"])
        result = gpd.GeoDataFrame(result, geometry="geometry", crs=points.crs)
    elif predicate == "nearest":
        result = run_nearest(points, polygons, how, keep_cols, max_distance)
    else:
        result = run_within_or_intersects(points, polygons, predicate, how, keep_cols)

    n_matched = result["geometry"].notna().sum() if "geometry" in result.columns else len(result)
    print(
        f"[spatial_join] Join complete: {len(result):,} output rows "
        f"({n_matched:,} matched)",
        file=sys.stderr,
    )

    # 6. Optional dissolve
    if dissolve_by:
        result = dissolve_result(result, dissolve_by)

    # 7. Write output
    if output_path is not None:
        write_output(result, output_path, drop_geometry)

    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Spatial join: assign polygon attributes to points (or polygons).\n\n"
            "Both input files can be shapefiles (.shp), GeoJSON (.geojson), "
            "or GeoParquet (.parquet). CRS mismatch is handled automatically "
            "(polygons are reprojected to match points CRS).\n\n"
            "Output is a CSV written to --output (or stdout if omitted). "
            "Pass a .geojson or .gpkg path to --output for spatial output."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("points", metavar="POINTS", help="Path to left/points file")
    parser.add_argument("polygons", metavar="POLYGONS", help="Path to right/polygons file")
    parser.add_argument(
        "--output",
        metavar="PATH",
        default=None,
        help="Output CSV path. Default: stdout. Use .geojson/.gpkg for spatial output.",
    )
    parser.add_argument(
        "--predicate",
        choices=["within", "intersects", "nearest"],
        default="within",
        help="Spatial predicate for the join. Default: within.",
    )
    parser.add_argument(
        "--keep-cols",
        metavar="COLS",
        default=None,
        help="Comma-separated column names to keep from right layer. Default: all.",
    )
    parser.add_argument(
        "--how",
        choices=["left", "inner", "right"],
        default="left",
        help="Join type. Default: left (keep all points, NaN where no match).",
    )
    parser.add_argument(
        "--max-distance",
        metavar="M",
        type=float,
        default=None,
        help=(
            "Maximum search distance in meters for nearest join. "
            "Points farther than this distance will have NaN for polygon attributes. "
            "Only used with --predicate nearest."
        ),
    )
    parser.add_argument(
        "--drop-geometry",
        action="store_true",
        default=True,
        help="Drop geometry column from CSV output (default: True).",
    )
    parser.add_argument(
        "--keep-geometry",
        dest="drop_geometry",
        action="store_false",
        help="Keep geometry column in output.",
    )

    # --- New enhancement flags ---
    enhance_group = parser.add_argument_group("Enhancement options")
    enhance_group.add_argument(
        "--buffer-km",
        metavar="FLOAT",
        type=float,
        default=None,
        help=(
            "Buffer left layer (points/polygons) by this distance in kilometers "
            "before performing the join. Projects to UTM for accurate buffering, "
            "then reprojects back. Example: --buffer-km 50"
        ),
    )
    enhance_group.add_argument(
        "--area-weight",
        action="store_true",
        default=False,
        help=(
            "Polygon-to-polygon area-weighted aggregation. Instead of a simple sjoin, "
            "compute area-weighted mean of all numeric columns in right layer and "
            "attach as {col}_wavg columns on left layer. Useful for boundary "
            "harmonization (e.g., assign district-level GDP to new administrative "
            "boundaries). Ignores --predicate."
        ),
    )
    enhance_group.add_argument(
        "--dissolve-by",
        metavar="COL",
        default=None,
        help=(
            "Dissolve/aggregate output by this column after join. Unions geometries "
            "and sums numeric columns within each group. Useful for: after "
            "point-in-polygon join, aggregate statistics to region level. "
            "Example: --dissolve-by state_fips"
        ),
    )
    enhance_group.add_argument(
        "--overlay",
        metavar="HOW",
        default=None,
        choices=["intersection", "union", "difference", "symmetric_difference", "identity"],
        help=(
            "Run gpd.overlay instead of sjoin. Outputs a GeoDataFrame with geometry "
            "intact. Use --output .geojson or .gpkg for spatial output. "
            "HOW options: intersection | union | difference | symmetric_difference | identity"
        ),
    )

    return parser.parse_args()


def main() -> None:
    args = parse_args()

    keep_cols: list[str] | None = None
    if args.keep_cols:
        keep_cols = [c.strip() for c in args.keep_cols.split(",") if c.strip()]

    run_spatial_join(
        points_path=args.points,
        polygons_path=args.polygons,
        output_path=args.output,
        predicate=args.predicate,
        keep_cols=keep_cols,
        how=args.how,
        max_distance=args.max_distance,
        drop_geometry=args.drop_geometry,
        buffer_km=args.buffer_km,
        area_weight=args.area_weight,
        dissolve_by=args.dissolve_by,
        overlay=args.overlay,
    )


if __name__ == "__main__":
    main()
