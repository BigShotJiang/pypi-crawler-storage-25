#!/usr/bin/env python3
"""
crosswalk.py — Boundary crosswalk / area-weighted interpolation

Reallocate data from source boundaries to target boundaries using
area-weighted interpolation. Handles administrative boundary changes
across census years (e.g., 1990 counties -> 2010 counties).

Methodology:
    1. Intersect source and target polygons
    2. weight = intersection_area / source_area  (for each piece)
    3. target_value = sum(source_value * weight) for each target polygon

Assumption: the variable is uniformly distributed within each source
polygon. For population data, use census-block weights (NHGIS) instead.

Usage:
    python crosswalk.py SOURCE_SHP TARGET_SHP DATA_CSV [options]

Examples:
    # Reallocate 1990 census data to 2010 county boundaries
    python crosswalk.py counties_1990.shp counties_2010.shp census_1990.csv \\
        --source-id county_code_1990 --target-id county_code_2010 \\
        --value-cols population,income,employment

    # Save the crosswalk weights for reuse (avoid recomputing)
    python crosswalk.py districts_old.shp districts_new.shp data_old.csv \\
        --source-id dist_id --target-id dist_id_new \\
        --weights-out crosswalk_weights.csv

    # Reuse pre-computed weights
    python crosswalk.py districts_old.shp districts_new.shp data_new_year.csv \\
        --source-id dist_id --target-id dist_id_new \\
        --weights-in crosswalk_weights.csv

Dependencies:
    geopandas>=1.1.0
    pandas>=2.0.0
    shapely>=2.0.0
"""

from __future__ import annotations

import sys
import argparse
from typing import Optional

import pandas as pd
import geopandas as gpd


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def read_shapefile(path: str, label: str = "shapefile") -> gpd.GeoDataFrame:
    """Read a shapefile, GeoJSON, or GeoParquet into a GeoDataFrame.

    Args:
        path: File path to read.
        label: Human-readable label for log messages.

    Returns:
        GeoDataFrame.

    Raises:
        SystemExit: On read failure.
    """
    print(f"[crosswalk] Reading {label}: {path}", file=sys.stderr)
    try:
        if path.endswith(".parquet"):
            gdf = gpd.read_parquet(path)
        else:
            gdf = gpd.read_file(path, engine="pyogrio")
    except Exception as exc:
        print(f"[crosswalk] ERROR reading {label} '{path}': {exc}", file=sys.stderr)
        sys.exit(1)

    print(
        f"[crosswalk]   -> {len(gdf):,} features, CRS={gdf.crs}",
        file=sys.stderr,
    )
    return gdf


def read_data_csv(path: str, source_id_col: str) -> pd.DataFrame:
    """Read the data CSV and validate the source ID column exists.

    Args:
        path: CSV file path.
        source_id_col: Required ID column name.

    Returns:
        DataFrame.

    Raises:
        SystemExit: If file is missing or source_id_col not found.
    """
    print(f"[crosswalk] Reading data CSV: {path}", file=sys.stderr)
    try:
        df = pd.read_csv(path)
    except Exception as exc:
        print(f"[crosswalk] ERROR reading data CSV '{path}': {exc}", file=sys.stderr)
        sys.exit(1)

    if source_id_col not in df.columns:
        print(
            f"[crosswalk] ERROR: --source-id column '{source_id_col}' not found in CSV.\n"
            f"  Available columns: {list(df.columns)}",
            file=sys.stderr,
        )
        sys.exit(1)

    print(
        f"[crosswalk]   -> {len(df):,} rows, {len(df.columns)} columns",
        file=sys.stderr,
    )
    return df


# ---------------------------------------------------------------------------
# CRS alignment
# ---------------------------------------------------------------------------

def align_crs_for_area(
    source: gpd.GeoDataFrame,
    target: gpd.GeoDataFrame,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, object]:
    """Project both layers to an equal-area CRS for accurate area computation.

    Uses auto-detected UTM CRS based on source centroid. For global
    datasets, UTM may introduce edge distortion; in that case, the caller
    can override by projecting to EPSG:6933 before calling this function.

    Args:
        source: Source boundary GeoDataFrame.
        target: Target boundary GeoDataFrame.

    Returns:
        Tuple (source_projected, target_projected, utm_crs).
    """
    # Ensure both have a declared CRS
    if source.crs is None:
        print("[crosswalk] WARNING: source has no CRS — assuming EPSG:4326", file=sys.stderr)
        source = source.set_crs("EPSG:4326")
    if target.crs is None:
        print("[crosswalk] WARNING: target has no CRS — assuming EPSG:4326", file=sys.stderr)
        target = target.set_crs("EPSG:4326")

    # Project source to WGS84 for UTM estimation (works even if source is in another CRS)
    source_wgs = source.to_crs("EPSG:4326")
    utm_crs = source_wgs.estimate_utm_crs()
    print(
        f"[crosswalk] Projecting to equal-area CRS: {utm_crs} for area calculation",
        file=sys.stderr,
    )

    source_proj = source.to_crs(utm_crs)
    target_proj = target.to_crs(utm_crs)

    return source_proj, target_proj, utm_crs


# ---------------------------------------------------------------------------
# Geometry validation
# ---------------------------------------------------------------------------

def fix_invalid_geometries(
    gdf: gpd.GeoDataFrame, label: str = ""
) -> gpd.GeoDataFrame:
    """Apply make_valid() and filter to Polygon/MultiPolygon.

    Args:
        gdf: Input GeoDataFrame.
        label: Human-readable label for logging.

    Returns:
        GeoDataFrame with valid polygon geometries only.
    """
    n_invalid = (~gdf.geometry.is_valid).sum()
    if n_invalid > 0:
        print(
            f"[crosswalk] Fixing {n_invalid} invalid geometries in {label}",
            file=sys.stderr,
        )
        gdf = gdf.copy()
        gdf["geometry"] = gdf.geometry.make_valid()

    before = len(gdf)
    gdf = gdf[gdf.geom_type.isin(["Polygon", "MultiPolygon"])].copy()
    dropped = before - len(gdf)
    if dropped:
        print(
            f"[crosswalk]   Dropped {dropped} non-polygon geometries in {label}",
            file=sys.stderr,
        )
    return gdf


# ---------------------------------------------------------------------------
# Crosswalk weight computation
# ---------------------------------------------------------------------------

def compute_crosswalk_weights(
    source_proj: gpd.GeoDataFrame,
    target_proj: gpd.GeoDataFrame,
    source_id_col: str,
    target_id_col: str,
) -> pd.DataFrame:
    """Compute area-weighted crosswalk weights.

    For each (source, target) pair that overlaps, computes:
        weight = intersection_area / source_area

    Weights for each source polygon sum to <= 1.0 (exactly 1.0 if the
    target layer fully covers the source layer).

    Args:
        source_proj: Source polygons projected to equal-area CRS.
        target_proj: Target polygons projected to equal-area CRS.
        source_id_col: Column name for source boundary ID.
        target_id_col: Column name for target boundary ID.

    Returns:
        DataFrame with columns: [source_id_col, target_id_col, 'source_area',
        'intersection_area', 'weight'].

    Raises:
        SystemExit: If required ID columns are missing.
    """
    # Validate ID columns
    for col, label, gdf in [
        (source_id_col, "source", source_proj),
        (target_id_col, "target", target_proj),
    ]:
        if col not in gdf.columns:
            print(
                f"[crosswalk] ERROR: ID column '{col}' not found in {label} shapefile.\n"
                f"  Available columns: {[c for c in gdf.columns if c != 'geometry']}",
                file=sys.stderr,
            )
            sys.exit(1)

    print("[crosswalk] Computing source areas...", file=sys.stderr)
    source_work = source_proj[[source_id_col, "geometry"]].copy()
    source_work["source_area"] = source_work.geometry.area

    print("[crosswalk] Computing intersection overlay...", file=sys.stderr)
    target_work = target_proj[[target_id_col, "geometry"]].copy()

    # Rename target_id_col if it clashes with source_id_col
    if target_id_col == source_id_col:
        target_work = target_work.rename(columns={target_id_col: target_id_col + "_target"})
        effective_target_col = target_id_col + "_target"
        print(
            f"[crosswalk] WARNING: source-id and target-id are both '{source_id_col}'. "
            f"Target column renamed to '{effective_target_col}' during computation.",
            file=sys.stderr,
        )
    else:
        effective_target_col = target_id_col

    try:
        intersection = gpd.overlay(
            source_work,
            target_work,
            how="intersection",
            keep_geom_type=True,
        )
    except Exception as exc:
        print(
            f"[crosswalk] ERROR during overlay: {exc}\n"
            "Try running make_valid() on both shapefiles first.",
            file=sys.stderr,
        )
        sys.exit(1)

    if len(intersection) == 0:
        print(
            "[crosswalk] ERROR: intersection returned 0 features. "
            "Check that source and target boundaries overlap spatially and share a CRS.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(
        f"[crosswalk]   Intersection: {len(intersection):,} pieces",
        file=sys.stderr,
    )

    intersection["intersection_area"] = intersection.geometry.area

    # Merge source areas
    source_areas = source_work[[source_id_col, "source_area"]].drop_duplicates(
        subset=[source_id_col]
    )
    weights_df = intersection.merge(source_areas, on=source_id_col, how="left")
    weights_df["weight"] = weights_df["intersection_area"] / weights_df["source_area"]

    # Rename back if we used a temp column
    if effective_target_col != target_id_col:
        weights_df = weights_df.rename(columns={effective_target_col: target_id_col})

    # Keep only weight columns (drop geometry)
    keep_cols = [source_id_col, target_id_col, "source_area", "intersection_area", "weight"]
    weights_df = weights_df[[c for c in keep_cols if c in weights_df.columns]].copy()

    # Diagnostics
    weight_sums = weights_df.groupby(source_id_col)["weight"].sum()
    n_full = (weight_sums > 0.99).sum()
    n_partial = (weight_sums <= 0.99).sum()
    print(
        f"[crosswalk] Weight diagnostics: "
        f"{n_full} source polygons fully covered, "
        f"{n_partial} partially covered (weight sum < 0.99).",
        file=sys.stderr,
    )
    if n_partial > 0:
        print(
            "[crosswalk]   Partially covered polygons indicate source extends beyond "
            "target layer. Those areas will be unallocated.",
            file=sys.stderr,
        )

    return weights_df


# ---------------------------------------------------------------------------
# Data reallocation
# ---------------------------------------------------------------------------

def select_value_columns(
    df: pd.DataFrame,
    value_cols_arg: list[str] | None,
    source_id_col: str,
) -> list[str]:
    """Determine which data columns to interpolate.

    Args:
        df: Input data DataFrame.
        value_cols_arg: User-specified column names, or None = all numeric.
        source_id_col: ID column to exclude from candidate list.

    Returns:
        List of column names to interpolate.

    Raises:
        SystemExit: If specified columns are not found.
    """
    if value_cols_arg:
        missing = [c for c in value_cols_arg if c not in df.columns]
        if missing:
            print(
                f"[crosswalk] ERROR: --value-cols not found in data CSV: {missing}\n"
                f"  Available: {[c for c in df.columns if c != source_id_col]}",
                file=sys.stderr,
            )
            sys.exit(1)
        return value_cols_arg

    # Auto-select numeric columns (exclude ID column)
    numeric_cols = [
        c for c in df.select_dtypes(include="number").columns
        if c != source_id_col
    ]
    if not numeric_cols:
        print(
            "[crosswalk] ERROR: no numeric columns found in data CSV "
            "(excluding the source ID column). Use --value-cols to specify columns.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(
        f"[crosswalk] Auto-selected {len(numeric_cols)} numeric columns: "
        f"{numeric_cols}",
        file=sys.stderr,
    )
    return numeric_cols


def reallocate_data(
    weights_df: pd.DataFrame,
    data_df: pd.DataFrame,
    source_id_col: str,
    target_id_col: str,
    value_cols: list[str],
) -> pd.DataFrame:
    """Apply area weights to reallocate data from source to target boundaries.

    For each value column:
        target_value = sum(source_value * weight)  grouped by target_id

    Args:
        weights_df: Crosswalk weights from compute_crosswalk_weights().
        data_df: Data in source boundaries.
        source_id_col: Source boundary ID column name.
        target_id_col: Target boundary ID column name.
        value_cols: Columns to interpolate.

    Returns:
        DataFrame indexed by target_id with reallocated values.
    """
    print(
        f"[crosswalk] Merging data with weights ({len(value_cols)} columns)...",
        file=sys.stderr,
    )

    # Convert source ID to string for safe merge
    data_df = data_df.copy()
    data_df[source_id_col] = data_df[source_id_col].astype(str)
    weights_df = weights_df.copy()
    weights_df[source_id_col] = weights_df[source_id_col].astype(str)

    merged = weights_df.merge(
        data_df[[source_id_col] + value_cols],
        on=source_id_col,
        how="left",
    )

    # Check coverage
    n_unmatched = merged[value_cols[0]].isna().sum()
    if n_unmatched > 0:
        pct = n_unmatched / len(merged) * 100
        print(
            f"[crosswalk] WARNING: {n_unmatched:,} weight rows ({pct:.1f}%) "
            f"have no matching data in CSV (source ID not found in data). "
            "These intersections will contribute 0 to target values.",
            file=sys.stderr,
        )

    # Weighted values
    for col in value_cols:
        merged[f"_w_{col}"] = merged[col] * merged["weight"]

    # Aggregate to target boundaries
    agg_dict = {f"_w_{col}": "sum" for col in value_cols}
    result = merged.groupby(target_id_col).agg(agg_dict).reset_index()

    # Rename weighted columns back to original names
    rename_map = {f"_w_{col}": col for col in value_cols}
    result = result.rename(columns=rename_map)

    print(
        f"[crosswalk] Reallocated to {len(result):,} target boundaries.",
        file=sys.stderr,
    )
    return result


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def run_crosswalk(
    source_shp: str,
    target_shp: str,
    data_csv: str,
    source_id_col: str,
    target_id_col: str,
    value_cols_arg: list[str] | None = None,
    output_path: str = "crosswalk_output.csv",
    weights_out: str | None = None,
    weights_in: str | None = None,
) -> pd.DataFrame:
    """Execute the full boundary crosswalk pipeline.

    Args:
        source_shp: Shapefile for source boundaries.
        target_shp: Shapefile for target boundaries.
        data_csv: CSV file with data in source boundaries.
        source_id_col: Source boundary ID column name.
        target_id_col: Target boundary ID column name.
        value_cols_arg: Columns to interpolate (None = all numeric).
        output_path: Output CSV path.
        weights_out: Save crosswalk weights to this path.
        weights_in: Load pre-computed weights from this path.

    Returns:
        DataFrame with reallocated data in target boundaries.
    """
    # 1. Read inputs
    source = read_shapefile(source_shp, "source boundaries")
    target = read_shapefile(target_shp, "target boundaries")
    data = read_data_csv(data_csv, source_id_col)

    # 2. Select value columns
    value_cols = select_value_columns(data, value_cols_arg, source_id_col)

    # 3. Compute or load weights
    if weights_in:
        print(f"[crosswalk] Loading pre-computed weights: {weights_in}", file=sys.stderr)
        try:
            weights_df = pd.read_csv(weights_in)
        except Exception as exc:
            print(
                f"[crosswalk] ERROR reading weights file '{weights_in}': {exc}",
                file=sys.stderr,
            )
            sys.exit(1)
        print(
            f"[crosswalk]   -> {len(weights_df):,} weight rows loaded",
            file=sys.stderr,
        )
    else:
        # Fix geometries, project, compute weights
        source = fix_invalid_geometries(source, "source")
        target = fix_invalid_geometries(target, "target")
        source_proj, target_proj, _utm = align_crs_for_area(source, target)
        weights_df = compute_crosswalk_weights(
            source_proj, target_proj, source_id_col, target_id_col
        )

        # Save weights if requested
        if weights_out:
            print(
                f"[crosswalk] Saving weights table: {weights_out}",
                file=sys.stderr,
            )
            weights_df.to_csv(weights_out, index=False)

    # 4. Reallocate data
    result = reallocate_data(
        weights_df, data, source_id_col, target_id_col, value_cols
    )

    # 5. Write output
    print(
        f"[crosswalk] Writing output: {output_path} "
        f"({len(result):,} rows, {len(result.columns)} columns)",
        file=sys.stderr,
    )
    result.to_csv(output_path, index=False)

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Boundary crosswalk: reallocate data across changing administrative\n"
            "boundaries using area-weighted interpolation.\n\n"
            "Typical use case: census data in 1990 county boundaries needs to\n"
            "be compared with 2010 county data. This script computes intersection\n"
            "weights and reallocates each source polygon's data proportionally\n"
            "to the target polygons that overlap it.\n\n"
            "Assumption: uniform distribution within each source polygon.\n"
            "For population data, prefer census-block weights (NHGIS)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "source_shp",
        metavar="SOURCE_SHP",
        help="Shapefile for source boundaries (the ones the data is in)",
    )
    parser.add_argument(
        "target_shp",
        metavar="TARGET_SHP",
        help="Shapefile for target boundaries (the ones you want data in)",
    )
    parser.add_argument(
        "data_csv",
        metavar="DATA_CSV",
        help="CSV file with data in source boundaries",
    )
    parser.add_argument(
        "--source-id",
        required=True,
        metavar="COL",
        help="Column name for source boundary ID (must exist in both SOURCE_SHP and DATA_CSV)",
    )
    parser.add_argument(
        "--target-id",
        required=True,
        metavar="COL",
        help="Column name for target boundary ID (must exist in TARGET_SHP)",
    )
    parser.add_argument(
        "--value-cols",
        metavar="COLS",
        default=None,
        help=(
            "Comma-separated column names to interpolate (must be numeric). "
            "Default: all numeric columns in DATA_CSV (excluding source ID)."
        ),
    )
    parser.add_argument(
        "--output",
        metavar="PATH",
        default="crosswalk_output.csv",
        help="Output CSV path. Default: crosswalk_output.csv",
    )
    parser.add_argument(
        "--weights-out",
        metavar="PATH",
        default=None,
        help=(
            "Save the crosswalk weight table to this CSV path for reuse. "
            "Recommended for large datasets where recomputing the overlay is slow."
        ),
    )
    parser.add_argument(
        "--weights-in",
        metavar="PATH",
        default=None,
        help=(
            "Load pre-computed crosswalk weights from this CSV path instead of "
            "recomputing the overlay. Skips the shapefile geometry operations."
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    value_cols_arg: list[str] | None = None
    if args.value_cols:
        value_cols_arg = [c.strip() for c in args.value_cols.split(",") if c.strip()]

    run_crosswalk(
        source_shp=args.source_shp,
        target_shp=args.target_shp,
        data_csv=args.data_csv,
        source_id_col=args.source_id,
        target_id_col=args.target_id,
        value_cols_arg=value_cols_arg,
        output_path=args.output,
        weights_out=args.weights_out,
        weights_in=args.weights_in,
    )


if __name__ == "__main__":
    main()
