"""
crosswalk_china_admin.py — Build GADM GID_3 to NBS 6-digit county code crosswalk.

PURPOSE:
    Match China county polygons from GADM 4.1 level-3 boundaries to the official
    NBS (National Bureau of Statistics) 6-digit administrative codes.
    Handles the common mismatch problems: ethnic minority suffixes, traditional
    character variants, simplified/full-name pairs.

INPUTS:
    --gadm   GADM GeoJSON (county level, China):
             Download from https://gadm.org/download_country.html (CHN, level 3)
             Default: ~/.maestro/cache/gadm41_CHN_3.json

    --nbs    NBS county reference Excel file.
             Required columns:
               行政区划代码  -- 6-digit NBS code (or coercible to str)
               地区          -- county Chinese name
               所属城市      -- prefecture Chinese name
               所属省份      -- province Chinese name
             Any Excel with these columns works (e.g. makesense county grain,
             NBS yearbook county index, custom crosswalk sheet).

OUTPUT:
    CSV with columns:
      gadm_gid3, nbs_code, county_name_cn, prefecture_name_cn, province_name_cn,
      gadm_name3_en, gadm_nl_name3, match_method

    match_method values:
      exact_cn    -- exact Chinese name match
      strip_cn    -- match after stripping trailing admin suffix (县市区旗...)
      prefix_cn   -- prefix containment match (handles ethnic minority names)
      no_cn_name  -- GADM NL_NAME_3 is 'NA' (no Chinese name in GADM)
      no_match    -- Chinese name present but not in NBS reference
      no_prov_map -- GADM province not in GADM→NBS province code map

MATCHING STRATEGY (in priority order, per province):
    1. exact_cn:   GADM NL_NAME_3 (first pipe segment) == NBS county_cn
    2. strip_cn:   strip trailing [县市区旗盟镇乡族]+ from both, exact match
    3. prefix_cn:  one stripped name is a prefix of the other, min length ≥ 3,
                   extension ≤ 8 chars (handles '杜尔伯特' ↔ '杜尔伯特蒙古族自治县')
    4. trad_cn:    try second pipe segment (traditional char variant, e.g. Hunan gazetteers)

USAGE:
    python crosswalk_china_admin.py --nbs path/to/nbs_reference.xlsx --output crosswalk.csv
    python crosswalk_china_admin.py --gadm ~/.maestro/cache/gadm41_CHN_3.json \\
        --nbs ~/data/nbs_counties.xlsx --output scripts/crosswalk_gadm_nbs.csv

DEPENDENCIES:
    pandas, openpyxl (for .xlsx reading)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import pandas as pd

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_GADM = Path.home() / ".maestro/cache/gadm41_CHN_3.json"

# Map GADM English province names to NBS 2-digit province codes
GADM_PROV_TO_CODE: dict[str, str] = {
    "Anhui":         "34",
    "Beijing":       "11",
    "Chongqing":     "50",
    "Fujian":        "35",
    "Gansu":         "62",
    "Guangdong":     "44",
    "Guangxi":       "45",
    "Guizhou":       "52",
    "Hainan":        "46",
    "Hebei":         "13",
    "Heilongjiang":  "23",
    "Henan":         "41",
    "Hubei":         "42",
    "Hunan":         "43",
    "Inner Mongol":  "15",
    "NeiMongol":     "15",
    "Jiangsu":       "32",
    "Jiangxi":       "36",
    "Jilin":         "22",
    "Liaoning":      "21",
    "Ningxia":       "64",
    "NingxiaHui":    "64",
    "Qinghai":       "63",
    "Shaanxi":       "61",
    "Shandong":      "37",
    "Shanghai":      "31",
    "Shanxi":        "14",
    "Sichuan":       "51",
    "Tianjin":       "12",
    "Tibet":         "54",
    "Xizang":        "54",
    "Xinjiang":      "65",
    "XinjiangUygur": "65",
    "Yunnan":        "53",
    "Zhejiang":      "33",
    # Macau: no NBS mainland code; filtered before reaching this map
}

# Suffix characters at end of admin unit names (stripped for matching)
SUFFIX_RE = re.compile(r"[县市区旗盟镇乡族]+$")

# Prefix match constraints
_MIN_PREFIX_LEN = 3       # prevent single-char prefix false positives
_MAX_PREFIX_EXTENSION = 8 # prevent cross-province false positives


def strip_suffix(name: str) -> str:
    """Remove trailing administrative type suffixes for comparison."""
    return SUFFIX_RE.sub("", name)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_gadm(path: Path) -> list[dict]:
    """Load GADM GeoJSON; return list of feature property dicts."""
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    return [f["properties"] for f in data.get("features", [])]


def load_nbs(path: Path) -> pd.DataFrame:
    """
    Load NBS county reference Excel file.

    Expected columns: 行政区划代码, 地区, 所属城市, 所属省份
    Returns DataFrame with normalized columns:
      nbs_code, county_cn, prefecture_cn, province_cn, prov_code, county_stripped
    """
    df = pd.read_excel(path)
    uniq = (
        df[["行政区划代码", "地区", "所属城市", "所属省份"]]
        .drop_duplicates(subset="行政区划代码")
        .copy()
    )
    uniq["nbs_code"]        = uniq["行政区划代码"].astype(str).str.zfill(6)
    uniq["prov_code"]       = uniq["nbs_code"].str[:2]
    uniq["county_cn"]       = uniq["地区"].fillna("")
    uniq["prefecture_cn"]   = uniq["所属城市"].fillna("")
    uniq["province_cn"]     = uniq["所属省份"].fillna("")
    uniq["county_stripped"] = uniq["county_cn"].apply(strip_suffix)
    return uniq[
        ["nbs_code", "county_cn", "prefecture_cn", "province_cn",
         "prov_code", "county_stripped"]
    ].reset_index(drop=True)


# ---------------------------------------------------------------------------
# Lookup index
# ---------------------------------------------------------------------------

def build_lookup(nbs_df: pd.DataFrame) -> dict[str, dict[str, str]]:
    """Build: prov_code -> {county_stripped -> nbs_code}."""
    lookup: dict[str, dict[str, str]] = {}
    for _, row in nbs_df.iterrows():
        prov     = row["prov_code"]
        stripped = row["county_stripped"]
        if not stripped:
            continue
        lookup.setdefault(prov, {})
        if stripped not in lookup[prov]:          # first occurrence wins on collision
            lookup[prov][stripped] = row["nbs_code"]
    return lookup


# ---------------------------------------------------------------------------
# Name extraction helpers
# ---------------------------------------------------------------------------

def _pipe_segments(nl_name3: str) -> list[str]:
    """Split NL_NAME_3 on pipe; return non-empty segments. 'NA' -> []."""
    if not nl_name3 or nl_name3 == "NA":
        return []
    return [s for s in nl_name3.split("|") if s]


def _candidate_names(nl_name3: str) -> list[str]:
    """
    Return ordered candidate Chinese names from NL_NAME_3.

    Priority:
      first segment, joined segments (for split ethnic names), each segment
    Duplicates removed, order preserved.
    """
    segs = _pipe_segments(nl_name3)
    if not segs:
        return []
    seen: set[str] = set()
    result: list[str] = []
    for candidate in [segs[0], "".join(segs)] + segs[1:]:
        if candidate and candidate not in seen:
            seen.add(candidate)
            result.append(candidate)
    return result


# ---------------------------------------------------------------------------
# Matching logic
# ---------------------------------------------------------------------------

def _prefix_match(gadm_stripped: str, prov_lookup: dict[str, str]) -> str | None:
    """Return nbs_code if prefix containment rule satisfied, else None."""
    if len(gadm_stripped) < _MIN_PREFIX_LEN:
        return None
    for nbs_stripped, nbs_code in prov_lookup.items():
        if len(nbs_stripped) < _MIN_PREFIX_LEN:
            continue
        shorter, longer = sorted([gadm_stripped, nbs_stripped], key=len)
        if not longer.startswith(shorter):
            continue
        if len(longer) - len(shorter) <= _MAX_PREFIX_EXTENSION:
            return nbs_code
    return None


def match_feature(
    props: dict,
    prov_lookup: dict[str, str],
    nbs_df_prov: pd.DataFrame,
) -> tuple[str | None, str]:
    """Match one GADM feature to an NBS code within the same province."""
    nl3 = props.get("NL_NAME_3", "NA")
    candidates = _candidate_names(nl3)
    if not candidates:
        return None, "no_cn_name"

    for candidate in candidates:
        match = nbs_df_prov[nbs_df_prov["county_cn"] == candidate]
        if len(match) == 1:
            return match.iloc[0]["nbs_code"], "exact_cn"

        stripped = strip_suffix(candidate)
        if stripped and stripped in prov_lookup:
            return prov_lookup[stripped], "strip_cn"

    first_stripped = strip_suffix(candidates[0])
    nbs_code = _prefix_match(first_stripped, prov_lookup)
    if nbs_code:
        return nbs_code, "prefix_cn"

    return None, "no_match"


# ---------------------------------------------------------------------------
# Crosswalk builder
# ---------------------------------------------------------------------------

def build_crosswalk(gadm_path: Path, nbs_path: Path) -> pd.DataFrame:
    print(f"Loading GADM from {gadm_path} ...", file=sys.stderr)
    props_list = load_gadm(gadm_path)
    print(f"  {len(props_list)} features loaded", file=sys.stderr)

    print(f"Loading NBS reference from {nbs_path} ...", file=sys.stderr)
    nbs_df = load_nbs(nbs_path)
    print(f"  {len(nbs_df)} unique NBS county codes loaded", file=sys.stderr)

    lookup      = build_lookup(nbs_df)
    prov_cn_map = nbs_df.groupby("prov_code")["province_cn"].first().to_dict()

    rows = []
    for props in props_list:
        gid3 = props.get("GID_3", "NA")
        if gid3 == "NA" or gid3.startswith("MAC."):
            continue

        prov_en   = props.get("NAME_1", "")
        prov_code = GADM_PROV_TO_CODE.get(prov_en)
        nl3       = props.get("NL_NAME_3", "NA")
        nl2       = props.get("NL_NAME_2", "NA")

        if prov_code is None:
            rows.append({
                "gadm_gid3":          gid3,
                "nbs_code":           "",
                "county_name_cn":     nl3,
                "prefecture_name_cn": nl2,
                "province_name_cn":   "",
                "gadm_name3_en":      props.get("NAME_3", ""),
                "gadm_nl_name3":      nl3,
                "match_method":       "no_prov_map",
            })
            continue

        prov_lookup = lookup.get(prov_code, {})
        nbs_df_prov = nbs_df[nbs_df["prov_code"] == prov_code]
        nbs_code, method = match_feature(props, prov_lookup, nbs_df_prov)

        county_name_cn = _pipe_segments(nl3)[0] if _pipe_segments(nl3) else ""
        pref_cn        = nl2
        prov_cn        = prov_cn_map.get(prov_code, "")
        if nbs_code:
            nbs_row = nbs_df[nbs_df["nbs_code"] == nbs_code]
            if len(nbs_row) > 0:
                county_name_cn = nbs_row.iloc[0]["county_cn"]
                pref_cn        = nbs_row.iloc[0]["prefecture_cn"] or nl2

        rows.append({
            "gadm_gid3":          gid3,
            "nbs_code":           nbs_code or "",
            "county_name_cn":     county_name_cn,
            "prefecture_name_cn": pref_cn,
            "province_name_cn":   prov_cn,
            "gadm_name3_en":      props.get("NAME_3", ""),
            "gadm_nl_name3":      nl3,
            "match_method":       method,
        })

    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def report_stats(df: pd.DataFrame) -> None:
    total   = len(df)
    matched = (df["nbs_code"].notna() & (df["nbs_code"] != "")).sum()
    rate    = matched / total * 100 if total > 0 else 0.0

    print(f"\n=== Crosswalk stats ===")
    print(f"  Total GADM features (excl. Macau/NA): {total}")
    print(f"  Matched:   {matched} ({rate:.1f}%)")
    print(f"  Unmatched: {total - matched} ({100 - rate:.1f}%)")
    print("\nMatch method breakdown:")
    print(df["match_method"].value_counts().to_string())
    print("\nUnmatched sample (first 30):")
    cols = ["gadm_gid3", "gadm_name3_en", "gadm_nl_name3",
            "prefecture_name_cn", "province_name_cn", "match_method"]
    print(df[df["nbs_code"] == ""][cols].head(30).to_string(index=False))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build GADM GID_3 to NBS 6-digit county code crosswalk.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--gadm", type=Path, default=_DEFAULT_GADM,
        help=f"GADM level-3 GeoJSON (default: {_DEFAULT_GADM})",
    )
    parser.add_argument(
        "--nbs", type=Path, required=True,
        help="NBS county reference Excel with columns: 行政区划代码, 地区, 所属城市, 所属省份",
    )
    parser.add_argument(
        "--output", type=Path, default=Path("crosswalk_gadm_nbs.csv"),
        help="Output CSV path (default: crosswalk_gadm_nbs.csv in CWD)",
    )
    args = parser.parse_args()

    df = build_crosswalk(args.gadm, args.nbs)
    report_stats(df)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"\nSaved: {args.output} ({len(df)} rows)")


if __name__ == "__main__":
    main()
