"""
spatial_interpolate.py -- Continuous spatial interpolation of point observations.

Interpolates point observations (e.g., air quality monitors, weather stations) to:
  - a regular raster grid (GeoTIFF)
  - target point locations (CSV)
  - polygon admin units via zonal aggregation (CSV)

Supported methods: IDW (no extra deps), Kriging (pykrige), RBF (scipy).

Real-world example:
    # Interpolate PM2.5 from 50 monitors to county panel
    python spatial_interpolate.py monitors.csv \\
        --value-col pm25 --lat-col lat --lon-col lon \\
        --method idw --power 2 --bandwidth-km 300 \\
        --output-raster pm25_grid.tif --resolution-km 5 \\
        --output-polygons counties_pm25.csv --polygons counties.shp \\
        --year 2020

Usage:
    python spatial_interpolate.py POINTS [options]

    POINTS: CSV with lat/lon/value columns, OR shapefile/GeoJSON with point geometry + value column.

All functions are importable. Main CLI logic in main(). Progress to stderr. Output to --output-* files.
"""

from __future__ import annotations

import argparse
import sys
import os
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Logging helpers (stderr only)
# ---------------------------------------------------------------------------

def log(msg: str) -> None:
    """Print progress message to stderr."""
    print(msg, file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_points(
    path: str,
    value_col: str,
    lat_col: str = "lat",
    lon_col: str = "lon",
    id_col: Optional[str] = None,
) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """
    Load point observations from CSV or spatial file (shapefile / GeoJSON).

    Returns
    -------
    xy : ndarray, shape (N, 2)
        Longitude, latitude coordinates of observations.
    values : ndarray, shape (N,)
        Observed values (NaN rows dropped).
    ids : ndarray or None
        ID column values aligned to xy/values, or None if not requested.
    """
    import geopandas as gpd

    ext = Path(path).suffix.lower()
    spatial_exts = {".shp", ".geojson", ".gpkg", ".json"}

    if ext in spatial_exts:
        log(f"[load] Reading spatial file: {path}")
        gdf = gpd.read_file(path)
        if gdf.crs is None:
            log("[warn] Input has no CRS; assuming EPSG:4326")
        else:
            gdf = gdf.to_crs("EPSG:4326")
        lons = gdf.geometry.x.to_numpy()
        lats = gdf.geometry.y.to_numpy()
        values_raw = gdf[value_col].to_numpy(dtype=float)
        ids_raw = gdf[id_col].to_numpy() if id_col and id_col in gdf.columns else None
    else:
        log(f"[load] Reading CSV: {path}")
        df = pd.read_csv(path)
        _check_col(df, value_col, path)
        _check_col(df, lat_col, path)
        _check_col(df, lon_col, path)
        lons = df[lon_col].to_numpy(dtype=float)
        lats = df[lat_col].to_numpy(dtype=float)
        values_raw = df[value_col].to_numpy(dtype=float)
        ids_raw = df[id_col].to_numpy() if id_col and id_col in df.columns else None

    # Drop NaN in values or coordinates
    mask = np.isfinite(values_raw) & np.isfinite(lons) & np.isfinite(lats)
    n_dropped = (~mask).sum()
    if n_dropped > 0:
        log(f"[load] Dropped {n_dropped} rows with NaN/inf values or coordinates")

    xy = np.column_stack([lons[mask], lats[mask]])
    values = values_raw[mask]
    ids = ids_raw[mask] if ids_raw is not None else None

    log(f"[load] {len(values)} valid observation points loaded")
    return xy, values, ids


def _check_col(df: pd.DataFrame, col: str, path: str) -> None:
    if col not in df.columns:
        raise ValueError(f"Column '{col}' not found in {path}. Available: {list(df.columns)}")


# ---------------------------------------------------------------------------
# Coordinate helpers
# ---------------------------------------------------------------------------

def deg_to_km_scale(lat_center: float) -> Tuple[float, float]:
    """
    Approximate km-per-degree for lon and lat at a given latitude.
    Used to convert bandwidth_km -> degrees for cKDTree queries.
    """
    km_per_lat = 111.32
    km_per_lon = 111.32 * np.cos(np.radians(lat_center))
    return km_per_lon, km_per_lat


def lonlat_to_metric(xy: np.ndarray, lat_center: float) -> np.ndarray:
    """
    Approximate projection: stretch lon by cos(lat_center) so distances are
    roughly isotropic in km. Used internally for IDW/RBF distance calculations.
    """
    km_per_lon, km_per_lat = deg_to_km_scale(lat_center)
    scale = np.array([km_per_lon, km_per_lat])
    return xy * scale


# ---------------------------------------------------------------------------
# IDW interpolation
# ---------------------------------------------------------------------------

def idw_interpolate(
    obs_xy: np.ndarray,
    obs_values: np.ndarray,
    target_xy: np.ndarray,
    power: float = 2.0,
    bandwidth_km: Optional[float] = None,
) -> np.ndarray:
    """
    Inverse Distance Weighting interpolation.

    Parameters
    ----------
    obs_xy : ndarray, shape (N, 2) -- lon/lat of observations
    obs_values : ndarray, shape (N,) -- observed values
    target_xy : ndarray, shape (M, 2) -- lon/lat of target locations
    power : float -- distance decay exponent (default 2.0)
    bandwidth_km : float or None -- max search radius in km; points beyond get no weight

    Returns
    -------
    values : ndarray, shape (M,) -- interpolated values (NaN where no neighbors in bandwidth)
    """
    from scipy.spatial import cKDTree

    lat_center = float(np.mean(obs_xy[:, 1]))
    obs_metric = lonlat_to_metric(obs_xy, lat_center)
    target_metric = lonlat_to_metric(target_xy, lat_center)

    tree = cKDTree(obs_metric)

    k = min(len(obs_xy), 20)

    if bandwidth_km is not None:
        dists, idxs = tree.query(target_metric, k=k, distance_upper_bound=bandwidth_km)
    else:
        dists, idxs = tree.query(target_metric, k=k)

    eps = 1e-10
    weights = 1.0 / (dists + eps) ** power
    # Mask entries beyond bandwidth (cKDTree returns inf distance for those)
    weights[dists == np.inf] = 0.0
    # Clamp index overflow (cKDTree returns len(tree) for out-of-range)
    idxs = np.clip(idxs, 0, len(obs_values) - 1)

    weight_sums = weights.sum(axis=1)
    valid = weight_sums > 0

    values = np.full(len(target_xy), np.nan)
    values[valid] = (
        (weights[valid] * obs_values[idxs[valid]]).sum(axis=1) / weight_sums[valid]
    )

    n_nan = (~np.isfinite(values)).sum()
    if n_nan > 0:
        log(f"[idw] {n_nan} target points outside bandwidth (NaN)")

    return values


# ---------------------------------------------------------------------------
# Kriging interpolation
# ---------------------------------------------------------------------------

def kriging_interpolate(
    obs_xy: np.ndarray,
    obs_values: np.ndarray,
    target_xy: np.ndarray,
    variogram_model: str = "spherical",
    nugget: Optional[float] = None,
) -> np.ndarray:
    """
    Ordinary Kriging via pykrige.

    Parameters
    ----------
    obs_xy : ndarray, shape (N, 2) -- lon/lat of observations
    obs_values : ndarray, shape (N,) -- observed values
    target_xy : ndarray, shape (M, 2) -- lon/lat of target locations
    variogram_model : str -- spherical | exponential | gaussian | linear
    nugget : float or None -- nugget parameter; None = auto-fit

    Returns
    -------
    values : ndarray, shape (M,)
    """
    try:
        from pykrige.ok import OrdinaryKriging
    except ImportError:
        raise ImportError(
            "pykrige is required for Kriging. Install with: pip install pykrige>=1.7.0"
        )

    variogram_parameters: Optional[dict] = None
    if nugget is not None:
        variogram_parameters = {"nugget": nugget}

    ok = OrdinaryKriging(
        obs_xy[:, 0],
        obs_xy[:, 1],
        obs_values,
        variogram_model=variogram_model,
        variogram_parameters=variogram_parameters,
        verbose=False,
        enable_plotting=False,
    )

    z_pred, _z_var = ok.execute("points", target_xy[:, 0], target_xy[:, 1])
    return np.asarray(z_pred)


# ---------------------------------------------------------------------------
# RBF interpolation
# ---------------------------------------------------------------------------

def rbf_interpolate(
    obs_xy: np.ndarray,
    obs_values: np.ndarray,
    target_xy: np.ndarray,
) -> np.ndarray:
    """
    Radial Basis Function interpolation via scipy.interpolate.RBFInterpolator.

    Uses thin_plate_spline kernel. Coordinates are projected to approximate
    metric space before interpolation.

    Parameters
    ----------
    obs_xy : ndarray, shape (N, 2)
    obs_values : ndarray, shape (N,)
    target_xy : ndarray, shape (M, 2)

    Returns
    -------
    values : ndarray, shape (M,)
    """
    from scipy.interpolate import RBFInterpolator

    lat_center = float(np.mean(obs_xy[:, 1]))
    obs_metric = lonlat_to_metric(obs_xy, lat_center)
    target_metric = lonlat_to_metric(target_xy, lat_center)

    rbf = RBFInterpolator(obs_metric, obs_values, kernel="thin_plate_spline")
    return rbf(target_metric)


# ---------------------------------------------------------------------------
# Grid construction
# ---------------------------------------------------------------------------

def build_grid(
    xmin: float,
    ymin: float,
    xmax: float,
    ymax: float,
    resolution_km: float = 1.0,
    epsg: int = 4326,
) -> Tuple[np.ndarray, np.ndarray, int, int]:
    """
    Build a regular lon/lat grid.

    Returns
    -------
    grid_xy : ndarray, shape (M, 2) -- flattened lon/lat of all grid cells
    (nrows, ncols) : grid dimensions
    xx, yy : meshgrid arrays (for reference)
    """
    lat_center = (ymin + ymax) / 2.0
    _, km_per_lat = deg_to_km_scale(lat_center)
    km_per_lon, _ = deg_to_km_scale(lat_center)

    res_lat = resolution_km / km_per_lat
    res_lon = resolution_km / km_per_lon

    lons = np.arange(xmin, xmax, res_lon)
    lats = np.arange(ymax, ymin, -res_lat)  # top-to-bottom for rasterio

    ncols = len(lons)
    nrows = len(lats)

    log(f"[grid] {nrows} rows x {ncols} cols ({nrows * ncols:,} cells) at {resolution_km} km resolution")

    xx, yy = np.meshgrid(lons, lats)
    grid_xy = np.column_stack([xx.ravel(), yy.ravel()])

    return grid_xy, nrows, ncols, xx, yy


def auto_bbox(obs_xy: np.ndarray, pad_frac: float = 0.10) -> Tuple[float, float, float, float]:
    """Compute bounding box from observations with percentage padding."""
    xmin, ymin = obs_xy.min(axis=0)
    xmax, ymax = obs_xy.max(axis=0)
    dx = (xmax - xmin) * pad_frac
    dy = (ymax - ymin) * pad_frac
    return xmin - dx, ymin - dy, xmax + dx, ymax + dy


# ---------------------------------------------------------------------------
# Raster output
# ---------------------------------------------------------------------------

def write_raster(
    output_path: str,
    grid_values: np.ndarray,
    nrows: int,
    ncols: int,
    xmin: float,
    ymin: float,
    xmax: float,
    ymax: float,
    epsg: int = 4326,
    nodata: float = -9999.0,
) -> None:
    """
    Write interpolated grid values to a GeoTIFF.

    Parameters
    ----------
    grid_values : ndarray, shape (nrows * ncols,) -- flattened, row-major order
    """
    try:
        import rasterio
        from rasterio.transform import from_bounds
    except ImportError:
        raise ImportError(
            "rasterio is required for raster output. Install with: pip install rasterio>=1.4.3"
        )

    arr = grid_values.reshape(nrows, ncols).astype("float32")
    arr = np.where(np.isfinite(arr), arr, nodata)

    transform = from_bounds(xmin, ymin, xmax, ymax, ncols, nrows)
    crs_str = f"EPSG:{epsg}"

    with rasterio.open(
        output_path,
        "w",
        driver="GTiff",
        height=nrows,
        width=ncols,
        count=1,
        dtype="float32",
        crs=crs_str,
        transform=transform,
        nodata=nodata,
    ) as dst:
        dst.write(arr, 1)

    log(f"[raster] Written: {output_path} ({nrows}x{ncols}, EPSG:{epsg})")


# ---------------------------------------------------------------------------
# Target-point output
# ---------------------------------------------------------------------------

def interpolate_to_csv_points(
    obs_xy: np.ndarray,
    obs_values: np.ndarray,
    target_csv: str,
    value_col: str,
    method: str,
    lat_col: str = "lat",
    lon_col: str = "lon",
    power: float = 2.0,
    bandwidth_km: Optional[float] = None,
    variogram_model: str = "spherical",
    nugget: Optional[float] = None,
    year: Optional[int] = None,
    date: Optional[str] = None,
) -> pd.DataFrame:
    """
    Load target points from CSV and interpolate observation values to them.

    Returns the enriched DataFrame (also written to target_csv path as output).
    """
    log(f"[points] Reading target points: {target_csv}")
    df = pd.read_csv(target_csv)
    _check_col(df, lat_col, target_csv)
    _check_col(df, lon_col, target_csv)

    target_xy = np.column_stack([
        df[lon_col].to_numpy(dtype=float),
        df[lat_col].to_numpy(dtype=float),
    ])

    interp_values = _dispatch_interpolation(
        obs_xy, obs_values, target_xy, method, power, bandwidth_km, variogram_model, nugget
    )

    df[value_col] = interp_values
    if year is not None:
        df["year"] = year
    if date is not None:
        df["date"] = date

    return df


# ---------------------------------------------------------------------------
# Polygon aggregation
# ---------------------------------------------------------------------------

def aggregate_raster_to_polygons(
    raster_path: str,
    polygons_path: str,
    value_col: str,
    year: Optional[int] = None,
    date: Optional[str] = None,
) -> pd.DataFrame:
    """
    Aggregate interpolated raster to polygon admin units via zonal mean.

    Tries exactextract first, falls back to rasterstats.

    Parameters
    ----------
    raster_path : str -- path to GeoTIFF written by write_raster()
    polygons_path : str -- path to polygon shapefile/GeoJSON
    value_col : str -- name for the aggregated value column

    Returns
    -------
    DataFrame with one row per polygon + zonal mean value.
    """
    import geopandas as gpd

    log(f"[polygons] Loading admin polygons: {polygons_path}")
    gdf = gpd.read_file(polygons_path)
    if gdf.crs is None:
        log("[warn] Polygon file has no CRS; assuming EPSG:4326")
    else:
        gdf = gdf.to_crs("EPSG:4326")

    # Try exactextract first
    try:
        return _aggregate_exactextract(raster_path, gdf, value_col, year, date)
    except ImportError:
        log("[polygons] exactextract not available; trying rasterstats")

    # Fallback to rasterstats
    try:
        return _aggregate_rasterstats(raster_path, gdf, value_col, year, date)
    except ImportError:
        raise ImportError(
            "Polygon aggregation requires exactextract or rasterstats.\n"
            "Install one with: pip install exactextract  OR  pip install rasterstats"
        )


def _aggregate_exactextract(
    raster_path: str,
    gdf,
    value_col: str,
    year: Optional[int],
    date: Optional[str],
) -> pd.DataFrame:
    from exactextract import exact_extract  # type: ignore

    log("[polygons] Using exactextract for zonal aggregation")
    result = exact_extract(raster_path, gdf, ["mean"], output="pandas")
    out = gdf.drop(columns="geometry").copy()
    out[value_col] = result["band_1_mean"].to_numpy()

    if year is not None:
        out["year"] = year
    if date is not None:
        out["date"] = date

    log(f"[polygons] Aggregated {len(out)} polygons via exactextract")
    return out.reset_index(drop=True)


def _aggregate_rasterstats(
    raster_path: str,
    gdf,
    value_col: str,
    year: Optional[int],
    date: Optional[str],
) -> pd.DataFrame:
    from rasterstats import zonal_stats  # type: ignore

    log("[polygons] Using rasterstats for zonal aggregation")
    stats = zonal_stats(gdf, raster_path, stats=["mean"])
    out = gdf.drop(columns="geometry").copy()
    out[value_col] = [s["mean"] for s in stats]

    if year is not None:
        out["year"] = year
    if date is not None:
        out["date"] = date

    log(f"[polygons] Aggregated {len(out)} polygons via rasterstats")
    return out.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def _dispatch_interpolation(
    obs_xy: np.ndarray,
    obs_values: np.ndarray,
    target_xy: np.ndarray,
    method: str,
    power: float,
    bandwidth_km: Optional[float],
    variogram_model: str,
    nugget: Optional[float],
) -> np.ndarray:
    """Route to the correct interpolation backend."""
    method = method.lower()
    log(f"[interp] Method: {method} | N_obs={len(obs_values)} | N_targets={len(target_xy)}")

    if method == "idw":
        return idw_interpolate(obs_xy, obs_values, target_xy, power=power, bandwidth_km=bandwidth_km)
    elif method == "kriging":
        return kriging_interpolate(obs_xy, obs_values, target_xy, variogram_model=variogram_model, nugget=nugget)
    elif method == "rbf":
        return rbf_interpolate(obs_xy, obs_values, target_xy)
    else:
        raise ValueError(f"Unknown method: '{method}'. Choose from: idw, kriging, rbf")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="spatial_interpolate.py",
        description=(
            "Interpolate point observations (e.g., air quality monitors, weather stations) "
            "to a raster grid, target CSV points, or polygon admin units."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # IDW interpolation to raster + county panel
  python spatial_interpolate.py monitors.csv \\
      --value-col pm25 --lat-col lat --lon-col lon \\
      --method idw --power 2 --bandwidth-km 300 \\
      --output-raster pm25_grid.tif --resolution-km 5 \\
      --output-polygons counties_pm25.csv --polygons counties.shp \\
      --year 2020

  # Kriging to raster from shapefile input
  python spatial_interpolate.py stations.shp \\
      --value-col temperature --method kriging --variogram spherical \\
      --output-raster temp_grid.tif --resolution-km 2

  # RBF to target points
  python spatial_interpolate.py obs.csv \\
      --value-col ndvi --method rbf \\
      --output-points villages_ndvi.csv
""",
    )

    # Positional
    p.add_argument("points", metavar="POINTS", help="CSV or shapefile/GeoJSON of observation points")

    # Required value column
    p.add_argument("--value-col", required=True, help="Column to interpolate (e.g., pm25, temperature)")
    p.add_argument("--lat-col", default="lat", help="Latitude column (default: lat; ignored for shapefiles)")
    p.add_argument("--lon-col", default="lon", help="Longitude column (default: lon; ignored for shapefiles)")

    # Method
    p.add_argument("--method", default="idw", choices=["idw", "kriging", "rbf"], help="Interpolation method (default: idw)")
    p.add_argument("--power", type=float, default=2.0, help="IDW power parameter (default: 2.0)")
    p.add_argument("--bandwidth-km", type=float, default=None, help="IDW max search radius in km (default: unlimited)")
    p.add_argument("--variogram", default="spherical", choices=["spherical", "exponential", "gaussian", "linear"],
                   help="Kriging variogram model (default: spherical)")
    p.add_argument("--nugget", type=float, default=None, help="Kriging nugget parameter (default: auto)")

    # Output modes
    p.add_argument("--output-raster", metavar="PATH.tif", help="Write interpolated raster GeoTIFF")
    p.add_argument("--output-points", metavar="TARGET.csv",
                   help="CSV with lat/lon columns to interpolate values at those locations")
    p.add_argument("--output-polygons", metavar="PATH.csv", help="Output polygon-aggregated CSV")
    p.add_argument("--polygons", metavar="ADMIN.shp", help="Polygon shapefile for --output-polygons aggregation")

    # Grid options
    p.add_argument("--resolution-km", type=float, default=1.0, help="Grid cell size in km (default: 1.0)")
    p.add_argument("--bbox", metavar='"xmin,ymin,xmax,ymax"', help="Bounding box (default: auto from input + 10%% padding)")
    p.add_argument("--epsg", type=int, default=4326, help="Output CRS EPSG code (default: 4326)")

    # Metadata passthrough
    p.add_argument("--id-col", help="ID column to pass through from input points")
    p.add_argument("--year", type=int, help="Year label added to output")
    p.add_argument("--date", help="Date label added to output")

    return p.parse_args(argv)


def main(argv=None) -> None:
    """
    Entry point for CLI usage. All progress is written to stderr.
    Output CSVs are written to --output-* file paths.
    """
    args = parse_args(argv)

    # Validate: at least one output required
    if not any([args.output_raster, args.output_points, args.output_polygons]):
        log("[error] At least one output option is required: --output-raster, --output-points, or --output-polygons")
        sys.exit(1)

    if args.output_polygons and not args.polygons:
        log("[error] --polygons ADMIN.shp is required when using --output-polygons")
        sys.exit(1)

    if (args.output_polygons or args.output_raster) and args.method in ("kriging", "rbf") and not args.output_raster:
        # For polygon aggregation we need to write a raster first if method is kriging/rbf
        pass

    # Load observations
    obs_xy, obs_values, obs_ids = load_points(
        args.points,
        value_col=args.value_col,
        lat_col=args.lat_col,
        lon_col=args.lon_col,
        id_col=args.id_col,
    )

    if len(obs_values) < 3:
        log("[error] Need at least 3 valid observation points for interpolation")
        sys.exit(1)

    # Determine bounding box
    if args.bbox:
        try:
            parts = [float(v.strip()) for v in args.bbox.split(",")]
            if len(parts) != 4:
                raise ValueError
            xmin, ymin, xmax, ymax = parts
        except ValueError:
            log("[error] --bbox must be 'xmin,ymin,xmax,ymax' (4 floats)")
            sys.exit(1)
    else:
        xmin, ymin, xmax, ymax = auto_bbox(obs_xy, pad_frac=0.10)
        log(f"[bbox] Auto: xmin={xmin:.4f} ymin={ymin:.4f} xmax={xmax:.4f} ymax={ymax:.4f}")

    # -------------------------------------------------------------------
    # Raster output
    # -------------------------------------------------------------------
    raster_path_used: Optional[str] = None

    need_raster = bool(args.output_raster) or bool(args.output_polygons)

    if need_raster:
        # If polygon aggregation requested but no raster path, write to temp file
        if args.output_raster:
            raster_out = args.output_raster
        else:
            import tempfile
            _tmp = tempfile.NamedTemporaryFile(suffix=".tif", delete=False)
            raster_out = _tmp.name
            _tmp.close()
            log(f"[raster] Temp raster for polygon aggregation: {raster_out}")

        raster_path_used = raster_out

        grid_xy, nrows, ncols, xx, yy = build_grid(
            xmin, ymin, xmax, ymax,
            resolution_km=args.resolution_km,
            epsg=args.epsg,
        )

        grid_values = _dispatch_interpolation(
            obs_xy, obs_values, grid_xy,
            method=args.method,
            power=args.power,
            bandwidth_km=args.bandwidth_km,
            variogram_model=args.variogram,
            nugget=args.nugget,
        )

        write_raster(
            raster_out, grid_values, nrows, ncols,
            xmin, ymin, xmax, ymax,
            epsg=args.epsg,
        )

    # -------------------------------------------------------------------
    # Target-points output
    # -------------------------------------------------------------------
    if args.output_points:
        df_points = interpolate_to_csv_points(
            obs_xy, obs_values,
            target_csv=args.output_points,
            value_col=args.value_col,
            method=args.method,
            lat_col=args.lat_col,
            lon_col=args.lon_col,
            power=args.power,
            bandwidth_km=args.bandwidth_km,
            variogram_model=args.variogram,
            nugget=args.nugget,
            year=args.year,
            date=args.date,
        )
        # Write results back to the same path (enriched with interpolated column)
        df_points.to_csv(args.output_points, index=False)
        log(f"[points] Written: {args.output_points} ({len(df_points)} rows)")

    # -------------------------------------------------------------------
    # Polygon aggregation output
    # -------------------------------------------------------------------
    if args.output_polygons and raster_path_used:
        df_poly = aggregate_raster_to_polygons(
            raster_path=raster_path_used,
            polygons_path=args.polygons,
            value_col=args.value_col,
            year=args.year,
            date=args.date,
        )
        df_poly.to_csv(args.output_polygons, index=False)
        log(f"[polygons] Written: {args.output_polygons} ({len(df_poly)} rows)")

        # Clean up temp raster if we created one
        if not args.output_raster and raster_path_used and os.path.exists(raster_path_used):
            os.unlink(raster_path_used)
            log(f"[raster] Temp raster removed: {raster_path_used}")

    log("[done] Spatial interpolation complete.")


if __name__ == "__main__":
    main()
