#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_DIR="${HOME}/.mecon"
CONFIG_FILE="${CONFIG_DIR}/config.toml"
CLAUDE_PLUGIN_ROOT="${HOME}/.claude/plugins"
CLAUDE_MARKETPLACE_DIR="${CLAUDE_PLUGIN_ROOT}/marketplaces/maestro-economics"
CLAUDE_CACHE_DIR="${CLAUDE_PLUGIN_ROOT}/cache/maestro-economics"
CLAUDE_SKILL_COPY="${HOME}/.claude/skills/.agents/skills/maestro-economics"

echo "[1/7] Uninstall existing maestro-economics package if present"
python3 -m pip uninstall -y maestro-economics >/dev/null 2>&1 || true

echo "[2/7] Remove local mecon config"
rm -f "${CONFIG_FILE}"
rmdir "${CONFIG_DIR}" >/dev/null 2>&1 || true

echo "[3/7] Remove local Claude marketplace/plugin/skill cache for maestro-economics"
rm -rf "${CLAUDE_MARKETPLACE_DIR}"
rm -rf "${CLAUDE_CACHE_DIR}"
rm -rf "${CLAUDE_SKILL_COPY}"

echo "[4/7] Reinstall from repo in editable mode"
python3 -m pip install -e "${REPO_ROOT}"

echo "[5/7] Verify installed package"
python3 -m pip show maestro-economics

echo "[6/7] Verify CLI entrypoint"
command -v mecon
mecon --version

echo "[7/7] Show mecon config and host cache state"
if [[ -f "${CONFIG_FILE}" ]]; then
  echo "Unexpected config file still exists: ${CONFIG_FILE}"
  exit 1
fi
echo "Config is clean: ${CONFIG_FILE} does not exist"
if [[ -d "${CLAUDE_MARKETPLACE_DIR}" || -d "${CLAUDE_CACHE_DIR}" || -d "${CLAUDE_SKILL_COPY}" ]]; then
  echo "Unexpected Claude cache still exists for maestro-economics"
  exit 1
fi
echo "Claude cache is clean for maestro-economics"

echo
echo "Local test environment reset complete."
echo "Next expected flow:"
echo "  1. Reinstall or refresh the host plugin/skill for maestro-economics"
echo "  2. mecon setup"
echo "  3. mecon doctor"
echo "  4. workspace init -> add -> sync -> submit -> watch/logs -> sync"
