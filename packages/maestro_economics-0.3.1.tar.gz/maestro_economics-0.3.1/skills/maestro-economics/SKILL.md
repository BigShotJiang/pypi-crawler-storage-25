---
name: maestro-economics
description: |
  Use when: an agent is helping a professor or research team with economics work, compute jobs, regression analysis, causal inference, spatial/climate/OCR pipelines, literature review, or paper support.
  Triggers: regression, OLS, FE, IV, DiD, RDD, event study, GEE, Earth Engine, ERA5, climate, spatial join, zonal statistics, OCR, crosswalk, fuzzy match, lit review, Semantic Scholar, paper, LaTeX, urban, hedonic, GTFS, historical map, replication.
  Do NOT use for: data cleaning (→ maestro-data-analyst), publication packaging (→ maestro-data-replication), knowledge persistence (→ maestro-nerve).
---

# Maestro Economics

Canonical economics runtime skill for Maestro. This skill should carry the professor from landing to execution, not just run isolated statistical methods.

--------------------------------------------------------------------------------

## 1. Operational Contract

This skill is the only operational source of truth after installation. The website
bootstrap page may tell the agent to install or refresh this skill, but it must
not redefine the runtime flow.

When the task needs RA Compute, use this exact sequence:

1. Refresh or install the host plugin or skill for `maestro-economics`.
2. Upgrade the runtime package with `python3 -m pip install --upgrade maestro-economics`.
3. Run `mecon doctor`.
4. If the doctor reports a missing API key, run `mecon login` for the human (default).
   This opens the browser to the consent page; the human just clicks Approve. The CLI
   stores the issued key locally — the human never copies/pastes anything. Fall back to
   `mecon setup --api-key <key>` only if the human explicitly prefers manual entry or
   the device has no browser (then suggest `mecon login --no-browser` and offer to
   open the URL on their phone).
5. If the doctor reports a missing or incomplete workspace, run:
   `mecon workspace init` -> `mecon add ...` -> `mecon sync` -> `mecon doctor`.
6. Only submit once `mecon doctor` reports readiness.
7. Run the job with `mecon submit run.py --gpu <type>`.
8. Monitor with `mecon watch` and `mecon logs -f`.
9. Pull artifacts back locally with `mecon sync`.

### When the human needs to act in their browser

Use `mecon open <target>` rather than dictating navigation in chat. It opens
the right page on the configured API base:

| Goal | Command |
|---|---|
| Add credits / change plan | `mecon open billing` |
| Manage / revoke API keys | `mecon open keys` |
| See job history | `mecon open jobs` |
| Inspect a specific job | `mecon open job <job_id>` |
| Top-level dashboard | `mecon open dashboard` |

If a job fails because of insufficient credits, run `mecon open billing` and
tell the human "I've opened the billing page, top up there and re-run." Do
not paste the URL and ask them to click — open it.

The worker contract is `run(ctx)`, not `run(progress_cb)`.

### Non-negotiable rules

- API auth is OAuth-style by default: `mecon login` opens the browser, the human
  clicks Approve, the CLI stores the issued key. Manual API-key paste is the
  fallback path only.
- Use workspace mode only. Do not guide users through the legacy zip-upload path unless you are debugging a broken environment.
- The agent owns installation checks, runtime upgrade, local setup, submission, monitoring, and result pullback.
- A compute task is not complete at submit time. It is complete only after artifacts are available locally for inspection.
- Do not skip `mecon doctor`. It is the readiness gate for both humans and automation.

### Environment check sequence

Before the first submission, the agent should rely on `mecon doctor` to verify:

1. `mecon` resolves on `PATH`
2. API configuration exists and the endpoint is reachable
3. The project folder contains a valid `run(ctx)` entrypoint
4. Required data and code files are tracked in workspace mode
5. `mecon sync` succeeds before `submit`

Use `mecon doctor --json` when a host needs machine-readable results.

### RA Compute best practices

Hard-won rules. Each one traces to a concrete failure mode. Full recipes in `references/compute.md`.

| # | Rule | Why |
|---|---|---|
| 1 | Data files live at workspace-root `data/`, never in a project subdir. | Non-`.py` files outside `data/` are silently stripped during upload. |
| 2 | `ctx.data_dir` always resolves to `<root>/data/`. Cast with `str(ctx.data_dir)` before `scipy.io.loadmat` / `np.loadtxt`. | It is a `PosixPath`, not a string. |
| 3 | Do not `pd.to_parquet` or `pyarrow` into `ctx.output_dir`. | `output/` is a R2 FUSE mount; pyarrow's `open_output_stream` fails with `PermissionError: Operation not permitted`. Use `json.dump`, `np.save`, plain `open(..., 'w')`, or write locally and `shutil.copy`. |
| 4 | Use `print(..., flush=True)` for debug output. | `print` lands in `output/job.log` after sync. `ctx.log()` is streamable via `mecon logs -f` but may not flush on error paths. |
| 5 | Always `mecon sync` before `mecon submit`. | A submit with no prior sync warns `Continuing anyway (using last synced versions)` and silently runs against an empty workspace. |
| 6 | If `status=queued` for > 10 min with no `updated_at` movement, `mecon cancel <id>` (full refund) and retry on a different GPU tier. | Rare but real capacity stalls on L4. |
| 7 | Banned input formats (`.mat .h5 .pkl .npz .dta`) → convert to parquet locally, monkey-patch the loader inside `run(ctx)`. | Keeps the local CPU / validation workflow intact; no upstream code changes. |
| 8 | Prefer `ctx.save_checkpoint(**arrays) / ctx.load_checkpoint()` for in-flight resume, not raw `.pkl` under `ckpt_dir`. | `.pkl` is banned for workspace uploads, so raw-pickle ckpts can be written but cannot be re-uploaded for a warm restart. |

## 2. Overview

**Purpose**:
- guide professor-facing onboarding when the task starts from a vague research ask
- choose the right path: standard analysis vs RA Compute job
- execute econometric specifications on cleaned panel data
- produce publication-ready output (tables, figures, estimates)

**Boundary**:
- Input: cleaned panel data from `maestro-data-analyst`
- Output: estimates, tables, figures consumed by `maestro-data-replication`
- NOT included: data cleaning, replication package assembly, LaTeX compilation

**Agent responsibility**:
1. Understand the professor's research goal in non-technical language.
2. Run `mecon login` (default) or `mecon setup` (manual fallback) only when the workflow actually requires authentication.
3. If compute is needed, install or refresh the runtime, initialize a workspace, sync files, and launch the job.
4. Translate technical progress back into researcher-friendly status updates.
5. When the human must act in their browser (top up credits, rotate a key, inspect a job), call `mecon open <target>` so the right page opens automatically — do not paste URLs and ask them to navigate.

### Completion criteria

For this skill, an RA Compute flow is complete only when all of the following are true:

1. Plugin/runtime installed
2. API key configured successfully
3. Workspace initialized
4. Required files tracked
5. Workspace synced
6. Job submitted
7. Logs or watch confirm execution state
8. Output artifacts pulled back to the local project folder

--------------------------------------------------------------------------------

## Sub-domains

This skill covers the full economics research pipeline. Sub-domain reference files are loaded on demand.

| Domain | Reference | Triggers |
|--------|-----------|----------|
| Satellite data | `references/gee.md` | GEE, Earth Engine, MODIS, NDVI |
| Climate data | `references/climate.md` | ERA5, CRU TS, CHIRPS, precipitation |
| Spatial processing | `references/spatial.md` | spatial join, zonal statistics, shapefile |
| Global datasets | `references/global-data.md` | ICRISAT, IBGE, DOSE, sub-national |
| OCR & digitization | `references/ocr.md` | OCR, PaddleOCR, table extraction |
| Data fusion | `references/data-fusion.md` | crosswalk, fuzzy match, geo-code |
| Replication packages | `references/replication.md` | replication, publication figure |
| Literature review | `references/lit-review.md` | Semantic Scholar, OpenAlex, survey |
| Academic writing | `references/paper.md` | paper draft, LaTeX, QJE, JPE |
| Urban: accessibility | `references/urban-accessibility.md` | GTFS, isochrone, HSR |
| Urban: environment | `references/urban-environment.md` | UHI, PM2.5, flood risk |
| Urban: hedonic | `references/urban-hedonic.md` | house price, HDB, amenity |
| Urban: history | `references/urban-history.md` | historical map, georeferencing |

--------------------------------------------------------------------------------

**Cross-references:**
- Input data from: `maestro-data-analyst`
- Output consumed by: `maestro-data-replication`
- LaTeX compilation: `maestro-data-pdf`
- Data quality checks: `maestro-data-qa`

--------------------------------------------------------------------------------

## 2. Supported Methods

| Method | Python Package | Key Function | Notes |
|--------|---------------|--------------|-------|
| OLS | statsmodels | `OLS().fit()` | HC1/HC3 robust SE |
| Fixed Effects (entity, time, two-way) | linearmodels | `PanelOLS()` | Entity/time demean |
| IV / 2SLS | linearmodels | `IV2SLS()` | First-stage F-stat reported |
| GMM | linearmodels | `IVGMM()` | Efficient GMM, J-stat |
| DiD (canonical) | statsmodels | Manual interaction | Pre-trend test |
| DiD (staggered, Callaway-Sant'Anna) | did | `ATTgt()` | Heterogeneous treatment timing |
| RDD | rdrobust | `rdrobust()` | Bandwidth selection, local polynomial |
| Event Study | linearmodels | Manual leads/lags | Dynamic treatment effects |
| Causal Forest / GRF | econml | `CausalForestDML()` | CATE estimation |
| Double/Debiased ML | doubleml | `DoubleMLPLR()` | Nuisance parameter estimation |
| Bootstrap SE | Custom | `scipy.stats` | Block/cluster bootstrap |

--------------------------------------------------------------------------------

## 3. Execution Modes

**Non-interactive execution**: For production pipelines, analysis can be run via
standalone Python scripts using pyfixest or statsmodels, bypassing the interactive skill.

Note: pyfixest requires Python 3.10+ (numba dependency). For Python 3.9, use statsmodels:
```python
import statsmodels.formula.api as smf
from statsmodels.stats.sandwich_covariance import cov_cluster
```

### Mode A: Acceleration (User-Specified Spec)

User provides a complete specification. Engine executes and returns results.

Flow: `spec JSON -> validate columns -> estimate -> format output -> save`

Use case: "Run this exact regression with these controls and fixed effects."

### Mode B: Search (AI-Generated Candidate Specs)

AI generates a battery of candidate specifications based on:
- Outcome variable + treatment variable
- Available controls and fixed effects
- Domain knowledge (economics, health, environment)

Flow: `{outcome, treatment, data} -> generate N specs -> batch parallel execute -> search report`

Output: ranked table of specifications with coefficients, SE, significance, diagnostics.

Use case: "Find the best specification for the effect of X on Y."

### 3.5 Academic Analysis Workflow

Six-step standard workflow extracted from professor projects. Each step has a
dedicated reference doc with templates and checklists.

1. **Data exploration**: Load `.dta`/`.csv`, run descriptive stats (mean, sd,
   min, max, p25/p50/p75), build variable inventory with missingness rates.
2. **Specification design**: Progressive model building --
   base -> +FE -> +controls -> +interactions. See `references/spec-building.md`.
3. **Estimation**: Dispatch to appropriate method (OLS, reghdfe/AbsorbingLS,
   IV/2SLS, RDD). Match Stata output when possible (Section 3.6).
4. **Robustness**: Bandwidth sensitivity, placebo tests, subsample analysis,
   alternative control sets. See `references/robustness-cookbook.md`.
5. **Output generation**: `esttab`-style LaTeX tables + coefficient plots.
   Format must match `references/table-standards.md`.
6. **Replication assembly**: Hand off estimates + scripts to
   `maestro-data-replication` for DDL packaging.

### 3.6 Stata-Python Alignment Notes

When replicating Stata results in Python, small numerical differences are
expected from DOF corrections and SE estimators. The table below documents
known equivalences and discrepancies.

| Stata Command | Python Equivalent | Known Differences |
|---------------|-------------------|-------------------|
| `reg Y X` | `sm.OLS().fit()` | Exact match (default SE) |
| `reg Y X, robust` | `sm.OLS().fit(cov_type='HC1')` | HC1: exact match |
| `reghdfe Y X, absorb(FE)` | `AbsorbingLS(absorb=df)` | SE <1% diff from DOF correction |
| `ivreg2 Y X (=Z)` | `linearmodels.IV2SLS()` | Small SE diff from DOF adjustments |
| `esttab` | Custom LaTeX generator | Must match format (see `references/table-standards.md`) |
| `coefplot` | matplotlib errorbar | Match: vertical zero line, CI caps, serif font |

For detailed alignment methodology and edge cases, see
`references/reghdfe-alignment.md`.

--------------------------------------------------------------------------------

## 4. Input Contract

```json
{
  "dataset_path": "/path/to/panel.csv",
  "specification": {
    "method": "panel_ols",
    "outcome": "log_gdp",
    "treatment": "policy_dummy",
    "controls": ["population", "trade_share"],
    "entity_effects": true,
    "time_effects": true,
    "cluster": "entity_id",
    "sample_filter": "year >= 2000"
  }
}
```

Required fields: `dataset_path`, `specification.method`, `specification.outcome`.
Optional: `controls`, `entity_effects`, `time_effects`, `cluster`, `sample_filter`.

--------------------------------------------------------------------------------

## 5. Output Formats

### Regression Table (LaTeX, stargazer-style)

```latex
\begin{table}[H]
\centering
\caption{Effect of Policy on GDP}
\begin{tabular}{lcccc}
\hline\hline
 & (1) & (2) & (3) & (4) \\
\hline
Policy & 0.045*** & 0.038** & 0.041*** & 0.039** \\
 & (0.012) & (0.015) & (0.013) & (0.016) \\
Controls & No & Yes & Yes & Yes \\
Entity FE & No & No & Yes & Yes \\
Time FE & No & No & No & Yes \\
\hline
N & 5,420 & 5,420 & 5,420 & 5,420 \\
R-squared & 0.12 & 0.28 & 0.65 & 0.71 \\
\hline\hline
\end{tabular}
\end{table}
```

### Coefficient Plot

Horizontal dot-and-whisker plot. 95% CI bars. Vertical dashed line at zero.

### Event Study Plot

Time on x-axis, coefficient on y-axis. Pre-treatment coefficients near zero (parallel trends).
95% CI shaded band. Vertical dashed line at treatment date.

### Balance Table

Pre-treatment means by treatment/control group. Normalized difference column.

### Robustness Matrix

Rows = specifications (varying controls, FE, sample). Columns = coefficient, SE, p-value, N.

--------------------------------------------------------------------------------

## 6. Workflow

### Step 1: Load Data, Validate Columns

```python
import pandas as pd

df = pd.read_csv(spec["dataset_path"])
for col in required_columns:
    assert col in df.columns, f"Missing column: {col}"
```

### Step 2: Construct Estimation

Dispatch by method:
- `panel_ols` -> `linearmodels.PanelOLS`
- `iv_2sls` -> `linearmodels.IV2SLS`
- `did` -> manual interaction or `did.ATTgt`
- `rdd` -> `rdrobust.rdrobust`
- `causal_forest` -> `econml.CausalForestDML`
- `double_ml` -> `doubleml.DoubleMLPLR`

### Step 3: Run Estimation (with timing)

```python
import time
t0 = time.time()
result = model.fit(cov_type="clustered", cluster_entity=True)
elapsed = time.time() - t0
```

### Step 4: Format Output

- LaTeX table: stargazer-style with significance stars
- Coefficient plot: matplotlib horizontal dot-and-whisker
- Event study plot: matplotlib time series with CI band
- JSON estimates: machine-readable for downstream consumption

### Step 5: Save Results

```
output/
  estimates.json       # coefficients, SE, p-values, diagnostics
  table1.tex           # regression table
  fig_coefplot.pdf     # coefficient plot
  fig_eventstudy.pdf   # event study plot (if applicable)
```

--------------------------------------------------------------------------------

## 7. Python Package Reference

| Package | Version | Purpose | Install |
|---------|---------|---------|---------|
| linearmodels | >=6.0 | Panel OLS, IV, GMM | `pip install linearmodels` |
| statsmodels | >=0.14 | OLS, diagnostics | `pip install statsmodels` |
| doubleml | >=0.8 | Double/debiased ML | `pip install doubleml` |
| econml | >=0.15 | Causal forest, CATE | `pip install econml` |
| rdrobust | >=2.2 | RDD estimation | `pip install rdrobust` |
| did | >=0.1 | Callaway-Sant'Anna DiD | `pip install did` |
| scipy | >=1.11 | Bootstrap, statistics | `pip install scipy` |
| matplotlib | >=3.8 | Figures | `pip install matplotlib` |

--------------------------------------------------------------------------------

## 8. Figure Standards

matplotlib rcParams for all figures:

```python
import matplotlib
matplotlib.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'font.size': 9,
    'axes.labelsize': 9,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 8,
    'figure.dpi': 300,
})
```

Single-column sizing: 3.5 x 2.5 inches (default for journal embedding).
1.5-column sizing: 5.0 x 3.5 inches.
Double-column sizing: 7.0 x 4.5 inches.

Color palette: professional, colorblind-safe. No rainbow.

--------------------------------------------------------------------------------

## 9. FE Specification Pitfalls

### 9.1 Year-Month FE Collinearity (CRITICAL)

**Rule**: NEVER use year-month combined FE when the treatment variable varies only by
calendar month (city-wide policy, seasonal effect). Year-month FE absorbs any regressor
that is constant across entities within the same calendar month.

```python
# WRONG -- year-month FE kills city-wide monthly regressors
model = AbsorbingLS(y, X, absorb=df[['entity_id', 'year_month']]).fit()

# CORRECT -- use year FE + month FE separately
df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month
model = AbsorbingLS(y, X, absorb=df[['entity_id', 'year', 'month']]).fit()
```

Root cause: any calendar-month variable (e.g. monthly rainfall, CPI, seasonal dummy)
is perfectly collinear with year-month FE -> coefficient = 0 by construction.

Diagnostic: if H1 coefficient is 0.0 with p-value = 1.0 exactly, check FE specification.

### 9.2 Coefficient Readability -- Rescaling

If OLS returns coefficients like `-0.0000***`, the variable is on the wrong scale.
Rescale to produce economically interpretable magnitudes.

```python
# Rainfall: express in per-100mm units (raw mm gives -0.0000***)
df['rainfall_100mm'] = df['rainfall_mm'] / 100

# Trade value: express in millions (raw dollars give -0.0000)
df['trade_M'] = df['trade_USD'] / 1e6

# Population: express in thousands
df['pop_K'] = df['population'] / 1000
```

Rescaling is cosmetic -- it does NOT change t-statistics, p-values, or model fit.

### 9.3 Solar Term / Seasonal Collinearity

When event dates (solar terms, holidays) are correlated with specific calendar months,
month FE partially absorbs the event effect. Fix: use **quarter FE** instead of month FE,
or include the event as a binary regressor alongside month FE and check for collinearity.

--------------------------------------------------------------------------------

## 10. Cross-References

| Direction | Skill | What flows |
|-----------|-------|------------|
| Input from | `maestro-data-analyst` | Cleaned panel CSV |
| Input from | `maestro-data-qa` | Quality diagnostics |
| Output to | `maestro-data-replication` | Estimates, tables, figures |
| Compilation | `maestro-data-pdf` | LaTeX table/figure compilation |
| Pricing | `maestro-data-sales` | Analysis service pricing |

### Reference Documents

| File | Content |
|------|---------|
| `references/spec-building.md` | Progressive specification design templates |
| `references/robustness-cookbook.md` | Standard robustness checks and placebo tests |
| `references/table-standards.md` | `esttab`-compatible LaTeX table format spec |
| `references/balance-tests.md` | Pre-treatment balance table methodology |
| `references/reghdfe-alignment.md` | Stata `reghdfe` vs Python `AbsorbingLS` alignment notes |
