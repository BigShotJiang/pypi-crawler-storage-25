"""Test method registry."""
from maestro_economics.registry import list_methods, get_method


def test_methods_registered():
    # Force import of all method modules to trigger @register decorators
    import maestro_economics.methods.ols  # noqa: F401
    import maestro_economics.methods.panel_fe  # noqa: F401
    import maestro_economics.methods.iv_2sls  # noqa: F401
    import maestro_economics.methods.did  # noqa: F401

    methods = list_methods()
    assert "ols" in methods
    assert "fe" in methods
    assert "iv" in methods
    assert "did" in methods


def test_get_method():
    import maestro_economics.methods.ols  # noqa: F401

    cls = get_method("ols")
    assert cls.name == "ols"
