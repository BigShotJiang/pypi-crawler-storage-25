"""Tests for runtime.handler."""

from __future__ import annotations

import json

import pytest

from maestro_economics.runtime.handler import execute_job


def test_execute_job_runs_run_ctx(tmp_path):
    script = tmp_path / "script.py"
    script.write_text('def run(ctx):\n    return {"answer": 42}\n')
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    result = execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "output"),
        config={},
        progress_cb=lambda p, m: None,
    )

    assert result["answer"] == 42


def test_execute_job_captures_progress_and_logs(tmp_path):
    calls: list[tuple[float, str]] = []
    script = tmp_path / "script.py"
    script.write_text(
        'def run(ctx):\n'
        '    ctx.progress(0.5, "half")\n'
        '    print("hello from job")\n'
        '    return {}\n'
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    output_dir = tmp_path / "output"

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(output_dir),
        config={},
        progress_cb=lambda p, m: calls.append((p, m)),
    )

    assert (0.5, "half") in calls
    assert "hello from job" in (output_dir / "job.log").read_text()


def test_execute_job_requires_run(tmp_path):
    script = tmp_path / "script.py"
    script.write_text("x = 1\n")
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    with pytest.raises(ValueError, match="must define a run"):
        execute_job(
            script_path=str(script),
            data_dir=str(data_dir),
            output_dir=str(tmp_path / "output"),
            config={},
            progress_cb=lambda p, m: None,
        )


def test_execute_job_writes_results_json(tmp_path):
    script = tmp_path / "script.py"
    script.write_text('def run(ctx):\n    return {"beta": 1.5}\n')
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    output_dir = tmp_path / "output"

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(output_dir),
        config={},
        progress_cb=lambda p, m: None,
    )

    saved = json.loads((output_dir / "results.json").read_text())
    assert saved["beta"] == 1.5

