"""Tests for runtime.context."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from maestro_economics.runtime.context import DataLoader, GpuInfo, JobContext


def test_gpu_info_defaults():
    gpu = GpuInfo()
    assert gpu.type is None
    assert gpu.memory_gb is None


def test_data_loader_loads_csv(tmp_path):
    csv_file = tmp_path / "data.csv"
    csv_file.write_text("id,year,x\nA,2000,1\nA,2001,2\n")
    loader = DataLoader(tmp_path)

    df = loader.load("data.csv", entity="id", time="year")

    assert len(df) == 2
    assert df.attrs["entity"] == "id"
    assert df.attrs["time"] == "year"


def test_data_loader_loads_parquet(tmp_path):
    parquet_file = tmp_path / "data.parquet"
    pd.DataFrame({"id": [1, 2], "v": [10, 20]}).to_parquet(parquet_file)
    loader = DataLoader(tmp_path)

    df = loader.load("data.parquet", entity="id")

    assert len(df) == 2
    assert df.attrs["entity"] == "id"
    assert df.attrs.get("time") is None


def test_data_loader_unsupported_format_raises(tmp_path):
    (tmp_path / "data.xlsx").write_text("fake")
    loader = DataLoader(tmp_path)

    with pytest.raises(ValueError, match="Unsupported"):
        loader.load("data.xlsx")


def test_job_context_progress_checkpoint_and_logs(tmp_path):
    calls: list[tuple[float, str]] = []

    def on_progress(pct, msg):
        calls.append((pct, msg))

    ctx = JobContext(
        data_dir=tmp_path / "data",
        output_dir=tmp_path / "output",
        config={"k": 3},
        progress_callback=on_progress,
        gpu=GpuInfo(type="L4", memory_gb=24.0),
    )
    ctx.progress(0.5, "half")
    ctx.save_checkpoint(step=3)
    ctx.log("hello")

    assert ctx.config["k"] == 3
    assert ctx.gpu.type == "L4"
    assert calls == [(0.5, "half")]
    assert ctx.has_checkpoint is True
    assert int(ctx.load_checkpoint()["step"]) == 3
    assert (tmp_path / "output" / "logs" / "log_0000.txt").read_text() == "hello\n"

