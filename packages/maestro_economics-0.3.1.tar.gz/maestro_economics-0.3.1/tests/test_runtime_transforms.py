"""Tests for runtime.transforms."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from maestro_economics.runtime.transforms import balance_panel, diff, dummy, lag, lead, merge, recode, standardize, winsorize


@pytest.fixture
def panel_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "id": ["A"] * 4 + ["B"] * 4,
            "year": [2000, 2001, 2002, 2003] * 2,
            "x": [1.0, 2.0, 3.0, 4.0, 10.0, 20.0, 30.0, 40.0],
            "y": [100, 200, 300, 400, 500, 600, 700, 800],
        }
    )


def test_winsorize_does_not_mutate_original():
    df = pd.DataFrame({"v": [1, 50, 100]})
    _ = winsorize(df, "v", pct=0.1)
    assert df["v"].tolist() == [1, 50, 100]


def test_lag_lead_diff(panel_df):
    lagged = lag(panel_df, "x", periods=1, entity="id", time="year")
    leaded = lead(panel_df, "x", periods=1, entity="id", time="year")
    differenced = diff(panel_df, "x", periods=1, entity="id", time="year")

    assert np.isnan(lagged.loc[lagged["id"] == "A", "x_lag1"].iloc[0])
    assert leaded.loc[leaded["id"] == "A", "x_lead1"].iloc[0] == 2.0
    assert differenced.loc[differenced["id"] == "A", "x_diff1"].iloc[1] == 1.0


def test_balance_panel_filters_incomplete_entities():
    df = pd.DataFrame({"id": ["A", "A", "B"], "year": [2000, 2001, 2000], "x": [1, 2, 3]})

    result = balance_panel(df, entity="id", time="year")

    assert set(result["id"].unique()) == {"A"}


def test_dummy_standardize_merge_recode():
    dummies = dummy(pd.DataFrame({"region": ["east", "west", "east"]}), "region")
    standardized = standardize(pd.DataFrame({"a": [10.0, 20.0, 30.0]}), ["a"])
    merged, diagnostics = merge(
        pd.DataFrame({"id": [1, 2], "v": [10, 20]}),
        pd.DataFrame({"id": [2, 3], "w": [30, 40]}),
        on="id",
        how="left",
    )
    recoded = recode(pd.DataFrame({"status": [1, 2, 99]}), "status", {1: "low", 2: "mid"})

    assert "region_east" in dummies.columns
    assert abs(standardized["a"].mean()) < 1e-10
    assert diagnostics["matched"] == 1
    assert len(merged) == 2
    assert recoded["status"].tolist() == ["low", "mid", 99]
