"""Tests for the mecon CLI."""

from __future__ import annotations

import json
import os
from pathlib import Path

from click.testing import CliRunner

import maestro_economics.cli as cli


def test_get_config_defaults(monkeypatch):
    monkeypatch.setattr(cli, "CONFIG_FILE", "/nonexistent/config.toml")
    monkeypatch.delenv("MECON_API_KEY", raising=False)
    monkeypatch.delenv("MECON_API_BASE", raising=False)

    cfg = cli.get_config()

    assert cfg["api_key"] == ""
    assert cfg["api_base"] == "https://ra.maestro.onl"


def test_env_var_takes_precedence(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text('[default]\napi_key = "file-key"\napi_base = "https://file.example"\n')
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))
    monkeypatch.setenv("MECON_API_KEY", "env-key")
    monkeypatch.setenv("MECON_API_BASE", "https://env.example")

    cfg = cli.get_config()

    assert cfg["api_key"] == "env-key"
    assert cfg["api_base"] == "https://env.example"


def test_setup_saves_profile(monkeypatch, tmp_path):
    runner = CliRunner()
    config_dir = tmp_path / ".mecon"
    config_file = config_dir / "config.toml"
    monkeypatch.setattr(cli, "CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))

    result = runner.invoke(cli.main, ["setup"], input="test-key\nhttps://api.example\n")

    assert result.exit_code == 0
    saved = config_file.read_text()
    assert 'api_key = "test-key"' in saved
    assert 'api_base = "https://api.example"' in saved


def test_setup_supports_noninteractive_flags(monkeypatch, tmp_path):
    runner = CliRunner()
    config_dir = tmp_path / ".mecon"
    config_file = config_dir / "config.toml"
    monkeypatch.setattr(cli, "CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))

    result = runner.invoke(
        cli.main,
        [
            "setup",
            "--api-key",
            "flag-key",
            "--api-base",
            "https://flag.example",
        ],
    )

    assert result.exit_code == 0
    saved = config_file.read_text()
    assert 'api_key = "flag-key"' in saved
    assert 'api_base = "https://flag.example"' in saved


def test_setup_api_key_only_uses_default_api_base_noninteractively(monkeypatch, tmp_path):
    runner = CliRunner()
    config_dir = tmp_path / ".mecon"
    config_file = config_dir / "config.toml"
    monkeypatch.setattr(cli, "CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))

    result = runner.invoke(
        cli.main,
        [
            "setup",
            "--api-key",
            "flag-key",
        ],
    )

    assert result.exit_code == 0
    saved = config_file.read_text()
    assert 'api_key = "flag-key"' in saved
    assert 'api_base = "https://ra.maestro.onl"' in saved


def test_main_help():
    runner = CliRunner()

    result = runner.invoke(cli.main, ["--help"])

    assert result.exit_code == 0
    assert "RA Compute CLI" in result.output
    assert "workspace" in result.output
    assert "doctor" in result.output


def test_workspace_init_creates_manifest(monkeypatch, tmp_path):
    runner = CliRunner()
    manifest_path = tmp_path / ".mecon" / "manifest.json"
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")

    def fake_api(method, path, json_data=None, timeout=30, raw=False):
        assert method == "POST"
        assert path == "/workspace"
        return {"data": {"workspace_id": "ws_123", "r2_prefix": "workspace/ws_123"}}

    monkeypatch.setattr(cli, "api", fake_api)

    with runner.isolated_filesystem(temp_dir=tmp_path):
        os.chdir(tmp_path)
        result = runner.invoke(cli.main, ["workspace", "init"])

    assert result.exit_code == 0
    assert manifest_path.exists()
    assert '"workspace_id": "ws_123"' in manifest_path.read_text()


def test_add_tracks_files(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mecon").mkdir()
    (tmp_path / ".mecon" / "manifest.json").write_text(
        '{"project":"demo","workspace_id":"ws_123","files":{},"entry":"run.py"}'
    )
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")

    result = runner.invoke(cli.main, ["add", "run.py"])

    assert result.exit_code == 0
    manifest = (tmp_path / ".mecon" / "manifest.json").read_text()
    assert '"run.py"' in manifest


def test_doctor_reports_missing_prereqs(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli, "CONFIG_FILE", str(tmp_path / "missing-config.toml"))
    monkeypatch.delenv("MECON_API_KEY", raising=False)
    monkeypatch.delenv("MECON_API_BASE", raising=False)

    result = runner.invoke(cli.main, ["doctor"])

    assert result.exit_code == 0
    assert "API key configured" in result.output
    assert "workspace manifest" in result.output
    assert "Doctor result:" in result.output


def test_doctor_supports_json_output(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli, "CONFIG_FILE", str(tmp_path / "missing-config.toml"))
    monkeypatch.delenv("MECON_API_KEY", raising=False)
    monkeypatch.delenv("MECON_API_BASE", raising=False)

    result = runner.invoke(cli.main, ["doctor", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["ready"] is False
    assert payload["failed_checks"] >= 1
    assert any(check["name"] == "API key configured" for check in payload["checks"])
    assert any("mecon setup" in fix for fix in payload["fixes"])


def test_submit_workspace_fails_when_tracked_files_are_unsynced(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mecon").mkdir()
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")
    (tmp_path / ".mecon" / "manifest.json").write_text(
        json.dumps(
            {
                "project": "demo",
                "workspace_id": "ws_123",
                "entry": "run.py",
                "files": {
                    "run.py": {
                        "sha256": "abc",
                        "size": 24,
                        "synced_at": None,
                    }
                },
            }
        )
    )

    api_calls: list[tuple[str, str]] = []

    def fake_api(method, path, json_data=None, timeout=30, raw=False):
        api_calls.append((method, path))
        return {"data": {"job_id": "job_123"}}

    monkeypatch.setattr(cli, "api", fake_api)

    result = runner.invoke(cli.main, ["submit", "--no-watch"])

    assert result.exit_code == 1
    assert "Run 'mecon sync' before submit." in result.output
    assert api_calls == []
