from __future__ import annotations

from unittest.mock import Mock

import pytest

from maestro_economics.workers import modal_worker


def test_report_status_retries_and_succeeds(monkeypatch):
    calls = {"count": 0}

    def fake_post(url, json, timeout):  # noqa: ANN001
        calls["count"] += 1
        if calls["count"] < 3:
            raise RuntimeError("temporary network failure")
        response = Mock()
        response.raise_for_status.return_value = None
        return response

    monkeypatch.setattr("httpx.post", fake_post)
    monkeypatch.setattr(modal_worker.time, "sleep", lambda *_args, **_kwargs: None)

    modal_worker._report_status(
        "https://callback.example",
        "job_123",
        "running",
        0.5,
        "Working",
    )

    assert calls["count"] == 3


def test_report_status_raises_after_terminal_callback_exhausts_retries(monkeypatch):
    def fake_post(url, json, timeout):  # noqa: ANN001
        raise RuntimeError("callback unavailable")

    monkeypatch.setattr("httpx.post", fake_post)
    monkeypatch.setattr(modal_worker.time, "sleep", lambda *_args, **_kwargs: None)

    with pytest.raises(RuntimeError, match="Callback delivery failed"):
        modal_worker._report_status(
            "https://callback.example",
            "job_terminal",
            "completed",
            1.0,
            "Done",
            gpu_seconds=5.0,
        )
