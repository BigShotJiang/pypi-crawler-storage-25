# AGENTS.md

## Repository Role

This repository is the single source of truth for `maestro-economics`.

- Do not split runtime, skill, and packaging across multiple repos again.
- PyPI releases, skill guidance, CLI entrypoints, and worker code must all come from this repo.
- The old legacy repo is migration reference only and should not receive new feature work.

## Engineering Rules

- Prefer mature frameworks over hand-rolled infrastructure when the fit is good.
- Keep one real CLI surface. Do not keep placeholder or duplicate command trees for "future" compatibility.
- Workspace-first compute is the canonical flow. Legacy zip-upload mode is fallback only.
- Docs must describe commands that are actually implemented and covered by tests.
- If a workflow appears in `/help/compute` or `SKILL.md`, it must be reproducible from this repo.
- Do not overload one callback endpoint with two protocols. Platform webhooks and worker-originated progress callbacks must use separate URLs and separate verification rules.
- `/help/compute`, `SKILL.md`, and `README.md` must all follow the same doctor-first contract:
  install or refresh host plugin/skill -> upgrade runtime -> `mecon doctor` ->
  `mecon setup` if needed -> `mecon doctor` -> workspace flow -> `mecon doctor` -> submit.
- User-facing and agent-facing contract docs in this repo must be written in English.
- Use `python3`, not `python`, unless the environment explicitly guarantees `python`.

## Release Gate

Before shipping changes that affect compute/runtime:

1. `pytest -q`
2. `python3 -m compileall src/maestro_economics`
3. Verify `mecon --help`
4. Verify workspace flow assumptions still hold:
   `workspace init -> add -> sync -> submit -> watch/logs -> sync/download`

## Local Test Reset

Before rerunning agent-led local compute tests from a clean machine state, use:

`scripts/reset_local_test_env.sh`

This script is the standard reset entrypoint. It:

- uninstalls any existing `maestro-economics`
- deletes `~/.mecon/config.toml`
- deletes local Claude marketplace/plugin/skill cache for `maestro-economics`
- reinstalls the repo in editable mode
- verifies `mecon` is on `PATH`
- verifies the local config is clean before a fresh onboarding flow

After reset, the expected sequence is:

1. refresh or reinstall the host plugin or skill
2. `python3 -m pip install --upgrade maestro-economics`
3. `mecon doctor`
4. `mecon setup` if needed, then `mecon doctor`
5. `workspace init -> add -> sync -> mecon doctor -> submit -> watch/logs -> sync`

## Product Principles

- Professors should not need to understand infra details.
- Agents should carry onboarding, setup, and job execution end to end.
- Do not allow frontend or docs to drift away from the actual runtime contract.
- Favor portability and decoupling at the database and service boundaries.
