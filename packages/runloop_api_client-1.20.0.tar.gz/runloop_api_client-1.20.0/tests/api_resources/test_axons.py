# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from runloop_api_client import Runloop, AsyncRunloop
from runloop_api_client.types import (
    AxonView,
    PublishResultView,
)
from runloop_api_client.pagination import SyncAxonsCursorIDPage, AsyncAxonsCursorIDPage

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAxons:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Runloop) -> None:
        axon = client.axons.create()
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Runloop) -> None:
        axon = client.axons.create(
            name="name",
        )
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Runloop) -> None:
        response = client.axons.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = response.parse()
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Runloop) -> None:
        with client.axons.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = response.parse()
            assert_matches_type(AxonView, axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Runloop) -> None:
        axon = client.axons.retrieve(
            "id",
        )
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Runloop) -> None:
        response = client.axons.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = response.parse()
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Runloop) -> None:
        with client.axons.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = response.parse()
            assert_matches_type(AxonView, axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Runloop) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.axons.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_list(self, client: Runloop) -> None:
        axon = client.axons.list()
        assert_matches_type(SyncAxonsCursorIDPage[AxonView], axon, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Runloop) -> None:
        axon = client.axons.list(
            id="id",
            include_total_count=True,
            limit=0,
            name="name",
            starting_after="starting_after",
        )
        assert_matches_type(SyncAxonsCursorIDPage[AxonView], axon, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Runloop) -> None:
        response = client.axons.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = response.parse()
        assert_matches_type(SyncAxonsCursorIDPage[AxonView], axon, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Runloop) -> None:
        with client.axons.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = response.parse()
            assert_matches_type(SyncAxonsCursorIDPage[AxonView], axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_publish(self, client: Runloop) -> None:
        axon = client.axons.publish(
            id="id",
            event_type="event_type",
            origin="EXTERNAL_EVENT",
            payload="payload",
            source="source",
        )
        assert_matches_type(PublishResultView, axon, path=["response"])

    @parametrize
    def test_raw_response_publish(self, client: Runloop) -> None:
        response = client.axons.with_raw_response.publish(
            id="id",
            event_type="event_type",
            origin="EXTERNAL_EVENT",
            payload="payload",
            source="source",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = response.parse()
        assert_matches_type(PublishResultView, axon, path=["response"])

    @parametrize
    def test_streaming_response_publish(self, client: Runloop) -> None:
        with client.axons.with_streaming_response.publish(
            id="id",
            event_type="event_type",
            origin="EXTERNAL_EVENT",
            payload="payload",
            source="source",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = response.parse()
            assert_matches_type(PublishResultView, axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_publish(self, client: Runloop) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.axons.with_raw_response.publish(
                id="",
                event_type="event_type",
                origin="EXTERNAL_EVENT",
                payload="payload",
                source="source",
            )

    @parametrize
    def test_method_subscribe_sse(self, client: Runloop) -> None:
        axon_stream = client.axons.subscribe_sse(
            id="id",
        )
        axon_stream.response.close()

    @parametrize
    def test_method_subscribe_sse_with_all_params(self, client: Runloop) -> None:
        axon_stream = client.axons.subscribe_sse(
            id="id",
            after_sequence=0,
        )
        axon_stream.response.close()

    @parametrize
    def test_raw_response_subscribe_sse(self, client: Runloop) -> None:
        response = client.axons.with_raw_response.subscribe_sse(
            id="id",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        stream.close()

    @parametrize
    def test_streaming_response_subscribe_sse(self, client: Runloop) -> None:
        with client.axons.with_streaming_response.subscribe_sse(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_subscribe_sse(self, client: Runloop) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.axons.with_raw_response.subscribe_sse(
                id="",
            )


class TestAsyncAxons:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncRunloop) -> None:
        axon = await async_client.axons.create()
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncRunloop) -> None:
        axon = await async_client.axons.create(
            name="name",
        )
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncRunloop) -> None:
        response = await async_client.axons.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = await response.parse()
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncRunloop) -> None:
        async with async_client.axons.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = await response.parse()
            assert_matches_type(AxonView, axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncRunloop) -> None:
        axon = await async_client.axons.retrieve(
            "id",
        )
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncRunloop) -> None:
        response = await async_client.axons.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = await response.parse()
        assert_matches_type(AxonView, axon, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncRunloop) -> None:
        async with async_client.axons.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = await response.parse()
            assert_matches_type(AxonView, axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncRunloop) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.axons.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncRunloop) -> None:
        axon = await async_client.axons.list()
        assert_matches_type(AsyncAxonsCursorIDPage[AxonView], axon, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncRunloop) -> None:
        axon = await async_client.axons.list(
            id="id",
            include_total_count=True,
            limit=0,
            name="name",
            starting_after="starting_after",
        )
        assert_matches_type(AsyncAxonsCursorIDPage[AxonView], axon, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncRunloop) -> None:
        response = await async_client.axons.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = await response.parse()
        assert_matches_type(AsyncAxonsCursorIDPage[AxonView], axon, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncRunloop) -> None:
        async with async_client.axons.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = await response.parse()
            assert_matches_type(AsyncAxonsCursorIDPage[AxonView], axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_publish(self, async_client: AsyncRunloop) -> None:
        axon = await async_client.axons.publish(
            id="id",
            event_type="event_type",
            origin="EXTERNAL_EVENT",
            payload="payload",
            source="source",
        )
        assert_matches_type(PublishResultView, axon, path=["response"])

    @parametrize
    async def test_raw_response_publish(self, async_client: AsyncRunloop) -> None:
        response = await async_client.axons.with_raw_response.publish(
            id="id",
            event_type="event_type",
            origin="EXTERNAL_EVENT",
            payload="payload",
            source="source",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        axon = await response.parse()
        assert_matches_type(PublishResultView, axon, path=["response"])

    @parametrize
    async def test_streaming_response_publish(self, async_client: AsyncRunloop) -> None:
        async with async_client.axons.with_streaming_response.publish(
            id="id",
            event_type="event_type",
            origin="EXTERNAL_EVENT",
            payload="payload",
            source="source",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            axon = await response.parse()
            assert_matches_type(PublishResultView, axon, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_publish(self, async_client: AsyncRunloop) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.axons.with_raw_response.publish(
                id="",
                event_type="event_type",
                origin="EXTERNAL_EVENT",
                payload="payload",
                source="source",
            )

    @parametrize
    async def test_method_subscribe_sse(self, async_client: AsyncRunloop) -> None:
        axon_stream = await async_client.axons.subscribe_sse(
            id="id",
        )
        await axon_stream.response.aclose()

    @parametrize
    async def test_method_subscribe_sse_with_all_params(self, async_client: AsyncRunloop) -> None:
        axon_stream = await async_client.axons.subscribe_sse(
            id="id",
            after_sequence=0,
        )
        await axon_stream.response.aclose()

    @parametrize
    async def test_raw_response_subscribe_sse(self, async_client: AsyncRunloop) -> None:
        response = await async_client.axons.with_raw_response.subscribe_sse(
            id="id",
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        await stream.close()

    @parametrize
    async def test_streaming_response_subscribe_sse(self, async_client: AsyncRunloop) -> None:
        async with async_client.axons.with_streaming_response.subscribe_sse(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            await stream.close()

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_subscribe_sse(self, async_client: AsyncRunloop) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.axons.with_raw_response.subscribe_sse(
                id="",
            )
