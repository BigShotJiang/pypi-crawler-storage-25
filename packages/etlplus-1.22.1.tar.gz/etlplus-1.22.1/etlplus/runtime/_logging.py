"""
:mod:`etlplus.runtime._logging` module.

Shared runtime logging policy helpers.

Notes
-----
- CLI-facing commands should keep user payloads on STDOUT and diagnostics on
  STDERR.
- Library/runtime modules should use :mod:`logging` rather than ad-hoc prints
  for diagnostic events.
- The CLI configures logging centrally so future modules share one baseline
  policy instead of each module inventing its own defaults.
"""

from __future__ import annotations

import logging
import os
import sys
from collections.abc import Mapping
from typing import IO
from typing import Final

# SECTION: EXPORTS ========================================================== #


__all__ = [
    # Classes
    'RuntimeLoggingPolicy',
]


# SECTION: CONSTANTS ======================================================== #


_LOG_LEVELS: Final[dict[str, int]] = {
    'CRITICAL': logging.CRITICAL,
    'ERROR': logging.ERROR,
    'WARNING': logging.WARNING,
    'INFO': logging.INFO,
    'DEBUG': logging.DEBUG,
}
_LOG_FORMAT: Final[str] = '%(levelname)s %(name)s: %(message)s'


# SECTION: CLASSES ========================================================== #


class RuntimeLoggingPolicy:
    """Resolve and install the shared runtime logging baseline."""

    # -- Class Methods -- #

    @classmethod
    def configure(
        cls,
        *,
        quiet: bool = False,
        verbose: bool = False,
        stream: IO[str] | None = None,
        force: bool = False,
        env: Mapping[str, str] | None = None,
    ) -> int:
        """
        Configure the process-wide logging baseline for ETLPlus runtime code.

        Parameters
        ----------
        quiet : bool, optional
            Whether quiet mode is enabled. Default is ``False``.
        verbose : bool, optional
            Whether verbose mode is enabled. Default is ``False``.
        stream : IO[str] | None, optional
            Stream to receive log records. Defaults to :data:`sys.stderr`.
        force : bool, optional
            Whether to override any existing root logging handlers. Default is
            ``False``.
        env : Mapping[str, str] | None, optional
            Optional environment mapping used instead of :data:`os.environ`.

        Returns
        -------
        int
            The effective logging level that was configured.
        """
        level = cls.resolve_level(quiet=quiet, verbose=verbose, env=env)
        logging.basicConfig(
            level=level,
            stream=sys.stderr if stream is None else stream,
            format=_LOG_FORMAT,
            force=force,
        )
        logging.captureWarnings(True)
        return level

    @classmethod
    def resolve_level(
        cls,
        *,
        quiet: bool = False,
        verbose: bool = False,
        env: Mapping[str, str] | None = None,
    ) -> int:
        """
        Resolve the effective logging level for the current runtime invocation.

        Parameters
        ----------
        quiet : bool, optional
            Whether quiet mode is enabled. Quiet mode takes precedence over
            verbose mode. Default is ``False``.
        verbose : bool, optional
            Whether verbose mode is enabled. Default is ``False``.
        env : Mapping[str, str] | None, optional
            Optional environment mapping used instead of :data:`os.environ`.

        Returns
        -------
        int
            A :mod:`logging` level constant.
        """
        env_map = os.environ if env is None else env
        explicit = (env_map.get('ETLPLUS_LOG_LEVEL') or '').strip().upper()
        if (explicit_level := _LOG_LEVELS.get(explicit)) is not None:
            return explicit_level
        if quiet:
            return logging.ERROR
        if verbose:
            return logging.INFO
        return logging.WARNING
