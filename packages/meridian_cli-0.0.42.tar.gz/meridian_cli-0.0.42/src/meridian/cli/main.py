"""Cyclopts CLI entry point for meridian."""

import os
import subprocess
import sys
from collections.abc import Sequence
from contextvars import ContextVar
from pathlib import Path
from typing import Annotated, cast

from cyclopts import Parameter
from pydantic import BaseModel, ConfigDict

import meridian.cli.mars_passthrough as mars_passthrough
import meridian.cli.primary_launch as primary_launch
from meridian.cli.app_tree import (
    AGENT_ROOT_HELP as _AGENT_ROOT_HELP,
)
from meridian.cli.app_tree import (
    app,
    completion_app,
    config_app,
    hooks_app,
    models_app,
    report_app,
    session_app,
    spawn_app,
    streaming_app,
    work_app,
    workspace_app,
)
from meridian.cli.bootstrap import (
    extract_global_options as _bootstrap_extract_global_options,
)
from meridian.cli.bootstrap import (
    first_positional_token as _bootstrap_first_positional_token,
)
from meridian.cli.bootstrap import (
    first_positional_token_with_index as _bootstrap_first_positional_token_with_index,
)
from meridian.cli.bootstrap import (
    is_root_help_request as _bootstrap_is_root_help_request,
)
from meridian.cli.bootstrap import (
    maybe_bootstrap_runtime_state,
    temporary_config_env,
)
from meridian.cli.bootstrap import (
    should_startup_bootstrap as _bootstrap_should_startup_bootstrap,
)
from meridian.cli.bootstrap import (
    split_passthrough_args as _bootstrap_split_passthrough_args,
)
from meridian.cli.bootstrap import (
    validate_top_level_command as _bootstrap_validate_top_level_command,
)
from meridian.cli.config_cmd import register_config_commands
from meridian.cli.doctor_cmd import register_doctor_command
from meridian.cli.hooks_commands import register_hooks_commands
from meridian.cli.misc_commands import register_misc_commands
from meridian.cli.models_cmd import register_models_commands
from meridian.cli.output import (
    OutputConfig,
    OutputFormat,
    create_sink,
    flush_sink,
    normalize_output_format,
)
from meridian.cli.output import emit as emit_output
from meridian.cli.report_cmd import register_report_commands
from meridian.cli.session_cmd import register_session_commands
from meridian.cli.workspace_cmd import register_workspace_commands
from meridian.lib.core.sink import OutputSink
from meridian.lib.ops.mars import check_upgrade_availability, format_upgrade_availability
from meridian.lib.ops.spawn.api import SpawnActionOutput
from meridian.server.main import run_server


class GlobalOptions(BaseModel):
    """Top-level options that apply to all commands."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    output: OutputConfig
    config_file: str | None = None
    harness: str | None = None
    yes: bool = False
    no_input: bool = False
    # Future cleanup: `output_explicit` may be removable now that
    # `explicit_format` carries the resolved explicit output selection.
    output_explicit: bool = False
    force_human: bool = False
    passthrough_args: tuple[str, ...] = ()
    sink: OutputSink | None = None
    explicit_format: OutputFormat | None = None


_GLOBAL_OPTIONS: ContextVar[GlobalOptions | None] = ContextVar("_GLOBAL_OPTIONS", default=None)

PrimaryLaunchOutput = primary_launch.PrimaryLaunchOutput
_ResolvedSessionTarget = primary_launch._ResolvedSessionTarget


def get_global_options() -> GlobalOptions:
    """Return parsed global options for current command."""

    default = GlobalOptions(output=OutputConfig(format="text"))
    return _GLOBAL_OPTIONS.get() or default


def _resolve_sink(opts: GlobalOptions | None) -> tuple[OutputSink, bool]:
    if opts is not None and opts.sink is not None:
        return opts.sink, False
    if opts is None:
        return create_sink(OutputConfig(format="text")), True
    return create_sink(opts.output), True


def current_output_sink() -> OutputSink:
    sink, _ = _resolve_sink(_GLOBAL_OPTIONS.get())
    return sink


def emit(payload: object) -> None:
    """Write command output using current output format settings."""

    options = get_global_options()
    sink, flush_after = _resolve_sink(options)
    if isinstance(payload, SpawnActionOutput):
        if options.output.format == "json":
            emit_output(payload.to_wire(), sink=sink)
        else:
            emit_output(payload, sink=sink)
    else:
        emit_output(payload, sink=sink)
    if flush_after:
        flush_sink(sink)


def _extract_global_options(argv: Sequence[str]) -> tuple[list[str], GlobalOptions]:
    cleaned, parsed = _bootstrap_extract_global_options(
        argv,
        normalize_output_format=lambda requested, json_mode: normalize_output_format(
            requested=requested,
            json_mode=json_mode,
        ),
    )
    explicit_format: OutputFormat | None = None
    if parsed.output_explicit:
        explicit_format = cast("OutputFormat", parsed.output_format)

    return cleaned, GlobalOptions(
        output=OutputConfig(format=cast("OutputFormat", parsed.output_format)),
        config_file=parsed.config_file,
        harness=parsed.harness,
        yes=parsed.yes,
        no_input=parsed.no_input,
        output_explicit=parsed.output_explicit,
        force_human=parsed.force_human,
        explicit_format=explicit_format,
    )


def _split_passthrough_args(argv: Sequence[str]) -> tuple[list[str], tuple[str, ...]]:
    """Split args at ``--`` so cyclopts never sees passthrough tokens.

    Workaround for a cyclopts bug: tokens after ``--`` are supposed to be
    positional-only, but cyclopts still assigns them to unfilled named
    parameters (e.g. ``--prompt`` absorbs ``--add-dir``).  We strip ``--``
    and everything after it before cyclopts parses, stash the passthrough
    tokens on ``GlobalOptions.passthrough_args``, and have handlers read
    them from there instead of from a ``*passthrough`` function parameter.
    """

    return _bootstrap_split_passthrough_args(argv)


def agent_mode_enabled() -> bool:
    return int(os.getenv("MERIDIAN_DEPTH", "0")) > 0


def _resolve_command_path(argv: Sequence[str]) -> tuple[str | None, str | None]:
    """Resolve CLI command path (group, subcommand) from argv.

    Returns (group, subcommand) where either may be None.
    Special handling for spawn default routes which are not in the manifest.
    """
    # Future cleanup: if command-specific output policy keeps expanding, move
    # command-path resolution out of main.py into a dedicated routing helper.
    resolved_group = _bootstrap_first_positional_token_with_index(argv)
    if resolved_group is None:
        return None, None
    group_index, group = resolved_group

    from meridian.lib.ops.manifest import get_operation_by_cli

    # Spawn has a default handler. Only the immediate token after "spawn" can
    # select a real subcommand. Later non-flag tokens can be option values.
    if group == "spawn":
        spawn_subcommands = {
            name for name in spawn_app.resolved_commands() if not name.startswith("-")
        }
        next_token = argv[group_index + 1] if group_index + 1 < len(argv) else None
        if (
            next_token is not None
            and not next_token.startswith("-")
            and next_token in spawn_subcommands
        ):
            return "spawn", next_token
        if "--continue" in argv or any(token.startswith("--continue=") for token in argv):
            return "spawn", "continue"
        return "spawn", "create"

    # Get non-flag tokens after the group.
    remaining = [a for a in argv[group_index:] if not a.startswith("-")]
    subcommand = remaining[1] if len(remaining) > 1 else None

    # Check for single-command groups (cli_name == cli_group)
    if (
        (subcommand is None or get_operation_by_cli(group, subcommand) is None)
        and get_operation_by_cli(group, group) is not None
    ):
        return group, group

    return group, subcommand


def _resolve_output_format_for_command(
    *,
    argv: Sequence[str],
    explicit_format: OutputFormat | None,
    agent_mode: bool,
) -> OutputFormat:
    """Resolve effective output format based on command and context."""
    from typing import Literal

    from meridian.cli.output import resolve_effective_format
    from meridian.lib.ops.manifest import get_operation_by_cli

    group, subcommand = _resolve_command_path(argv)

    agent_default_format: Literal["text", "json"] | None = None
    if group is not None and subcommand is not None:
        op = get_operation_by_cli(group, subcommand)
        if op is not None:
            agent_default_format = op.agent_default_format

    return resolve_effective_format(
        explicit_format=explicit_format,
        agent_mode=agent_mode,
        agent_default_format=agent_default_format,
    )


def _interactive_terminal_attached() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


@app.default
def root(
    json_mode: Annotated[
        bool,
        Parameter(name="--json", help="Emit command output as JSON.", show=False),
    ] = False,
    output_format: Annotated[
        str | None,
        Parameter(name="--format", help="Set output format: text or json."),
    ] = None,
    config_file: Annotated[
        str | None,
        Parameter(name="--config", help="Path to a user config TOML overlay."),
    ] = None,
    yes: Annotated[
        bool,
        Parameter(name="--yes", help="Auto-approve prompts when supported.", show=False),
    ] = False,
    no_input: Annotated[
        bool,
        Parameter(
            name="--no-input",
            help="Disable interactive prompts and fail if input is needed.",
            show=False,
        ),
    ] = False,
    continue_ref: Annotated[
        str | None,
        Parameter(
            name="--continue",
            help=(
                "Continue from a session ref: chat id (c123), spawn id (p123), "
                "or raw harness session id."
            ),
        ),
    ] = None,
    fork_ref: Annotated[
        str | None,
        Parameter(
            name="--fork",
            help=(
                "Fork from a session ref: chat id (c123), spawn id (p123), "
                "or raw harness session id."
            ),
        ),
    ] = None,
    model: Annotated[
        str,
        Parameter(name=["--model", "-m"], help="Model id or alias for primary harness."),
    ] = "",
    harness: Annotated[
        str | None,
        Parameter(name="--harness", help="Force harness id (claude, codex, or opencode)."),
    ] = None,
    agent: Annotated[
        str | None,
        Parameter(name=["--agent", "-a"], help="Agent profile name for the primary agent."),
    ] = None,
    work: Annotated[
        str,
        Parameter(name="--work", help="Attach the primary session to a work item id."),
    ] = "",
    yolo: Annotated[
        bool,
        Parameter(
            name="--yolo",
            help="Skip all harness safety prompts and sandboxing.",
        ),
    ] = False,
    autocompact: Annotated[
        int | None,
        Parameter(
            name="--autocompact",
            help="Autocompact threshold percentage (1-100). Overrides agent profile.",
        ),
    ] = None,
    effort: Annotated[
        str | None,
        Parameter(name="--effort", help="Effort level: low, medium, high, xhigh."),
    ] = None,
    sandbox: Annotated[
        str | None,
        Parameter(
            name="--sandbox",
            help=("Sandbox mode: default, read-only, workspace-write, danger-full-access."),
        ),
    ] = None,
    approval: Annotated[
        str | None,
        Parameter(
            name="--approval",
            help="Approval mode: default, confirm, auto, yolo. Overrides agent profile.",
        ),
    ] = None,
    timeout: Annotated[
        float | None,
        Parameter(name="--timeout", help="Maximum runtime in minutes."),
    ] = None,
    dry_run: Annotated[
        bool,
        Parameter(name="--dry-run", help="Preview launch command without starting harness."),
    ] = False,
) -> None:
    """Launch or resume the primary harness."""

    if yolo and approval is not None:
        raise ValueError("Cannot combine --yolo with --approval.")

    if _GLOBAL_OPTIONS.get() is None:
        resolved = normalize_output_format(requested=output_format, json_mode=json_mode)
        _GLOBAL_OPTIONS.set(
            GlobalOptions(
                output=OutputConfig(format=resolved),
                config_file=config_file,
                harness=harness,
                yes=yes,
                no_input=no_input,
            )
        )

    global_harness = get_global_options().harness
    explicit_harness = harness.strip() if harness is not None and harness.strip() else None
    if global_harness and explicit_harness and global_harness != explicit_harness:
        raise ValueError(
            f"Conflicting harness selections: '{global_harness}' and '{explicit_harness}'."
        )

    _run_primary_launch(
        continue_ref=continue_ref,
        fork_ref=fork_ref,
        model=model,
        harness=global_harness or explicit_harness,
        agent=agent,
        work=work,
        yolo=yolo,
        approval=approval,
        autocompact=autocompact,
        effort=effort,
        sandbox=sandbox,
        timeout=timeout,
        dry_run=dry_run,
        # See _split_passthrough_args() for why this reads from GlobalOptions.
        passthrough=get_global_options().passthrough_args,
    )


@app.command(name="serve")
def serve() -> None:
    """Start FastMCP server on stdio."""

    run_server()


_MarsPassthroughRequest = mars_passthrough.MarsPassthroughRequest
_MarsPassthroughResult = mars_passthrough.MarsPassthroughResult
_resolve_mars_executable = mars_passthrough.resolve_mars_executable
_mars_requested_json = mars_passthrough.mars_requested_json
_mars_requested_root = mars_passthrough.mars_requested_root
_mars_subcommand = mars_passthrough.mars_subcommand
_inject_upgrade_hint_into_sync_json = mars_passthrough.inject_upgrade_hint_into_sync_json
_decode_json_values = mars_passthrough.decode_json_values
_parse_mars_passthrough = mars_passthrough.parse_mars_passthrough


def _execute_mars_passthrough(request: _MarsPassthroughRequest) -> _MarsPassthroughResult:
    return mars_passthrough.execute_mars_passthrough(request, run=subprocess.run, stderr=sys.stderr)


def _augment_sync_result(
    result: _MarsPassthroughResult,
    *,
    output_format: str | None = None,
) -> None:
    return mars_passthrough.augment_sync_result(
        result,
        output_format=output_format,
        check_upgrades=check_upgrade_availability,
        format_upgrades=lambda upgrades: format_upgrade_availability(upgrades, style="hint"),
        stdout=sys.stdout,
        stderr=sys.stderr,
    )


def _run_mars_passthrough(
    args: Sequence[str],
    *,
    output_format: str | None = None,
) -> None:
    return mars_passthrough.run_mars_passthrough(
        args,
        output_format=output_format,
        resolve_executable=_resolve_mars_executable,
        parse_request=_parse_mars_passthrough,
        execute_request=_execute_mars_passthrough,
        augment_result=lambda result: _augment_sync_result(result, output_format=output_format),
        stdout=sys.stdout,
        stderr=sys.stderr,
    )


@app.command(name="mars")
def mars(
    *args: Annotated[
        str,
        Parameter(
            help="Arguments forwarded to mars.",
            show=False,
        ),
    ],
) -> None:
    """Forward all arguments to the bundled mars CLI."""

    _run_mars_passthrough(args, output_format=get_global_options().output.format)


def _run_primary_launch(
    *,
    continue_ref: str | None,
    fork_ref: str | None,
    model: str,
    harness: str | None,
    agent: str | None,
    work: str,
    yolo: bool,
    approval: str | None,
    autocompact: int | None,
    effort: str | None,
    sandbox: str | None,
    timeout: float | None,
    dry_run: bool,
    passthrough: tuple[str, ...],
) -> None:
    emit(
        primary_launch.run_primary_launch(
            continue_ref=continue_ref,
            fork_ref=fork_ref,
            model=model,
            harness=harness,
            agent=agent,
            work=work,
            yolo=yolo,
            approval=approval,
            autocompact=autocompact,
            effort=effort,
            sandbox=sandbox,
            timeout=timeout,
            dry_run=dry_run,
            passthrough=passthrough,
        )
    )


def _resolve_session_target(
    *,
    project_root: Path,
    continue_ref: str,
) -> _ResolvedSessionTarget:
    return primary_launch.resolve_session_target(
        project_root=project_root, continue_ref=continue_ref
    )


_resolve_init_project_root = mars_passthrough.resolve_init_project_root
_resolve_init_link_mars_command = mars_passthrough.resolve_init_link_mars_command


def _run_init_link_flow_json(
    *,
    executable: str,
    mars_mode: str,
    mars_args: Sequence[str],
    link: str,
    config_result: BaseModel,
) -> None:
    return mars_passthrough.run_init_link_flow_json(
        executable=executable,
        mars_mode=mars_mode,
        mars_args=mars_args,
        link=link,
        config_result=config_result,
        emit=emit,
        parse_request=_parse_mars_passthrough,
        execute_request=_execute_mars_passthrough,
        decode_values=_decode_json_values,
    )


@app.command(name="init")
def init_alias(
    path: Annotated[
        str | None,
        Parameter(name="path", help="Optional project path to initialize."),
    ] = None,
    link: Annotated[
        str | None,
        Parameter(
            name="--link",
            help="Link .agents/ into tool directory after config bootstrap (for example .claude).",
        ),
    ] = None,
) -> None:
    """Initialize meridian in the current project or provided path."""

    from meridian.lib.ops.config import ConfigInitInput, config_init_sync

    project_root = _resolve_init_project_root(path)
    result = config_init_sync(ConfigInitInput(project_root=project_root.as_posix()))
    if link is None:
        emit(result)
        return

    mars_mode, mars_args = _resolve_init_link_mars_command(project_root, link)
    output_format = get_global_options().output.format
    if output_format == "json":
        executable = _resolve_mars_executable()
        if executable is None:
            print(
                "error: Failed to execute 'mars'. Install meridian with dependencies and retry.",
                file=sys.stderr,
            )
            raise SystemExit(1)
        _run_init_link_flow_json(
            executable=executable,
            mars_mode=mars_mode,
            mars_args=mars_args,
            link=link,
            config_result=result,
        )
        return
    _run_mars_passthrough(mars_args, output_format=output_format)


register_misc_commands(
    app=app,
    completion_app=completion_app,
    streaming_app=streaming_app,
    emit=emit,
    get_global_options=get_global_options,
)


def _register_group_commands() -> None:
    from meridian.cli.spawn import register_spawn_commands
    from meridian.cli.work_cmd import register_work_commands

    register_spawn_commands(spawn_app, emit)
    register_report_commands(report_app, emit)
    register_session_commands(session_app, emit)
    register_work_commands(work_app, emit)
    register_hooks_commands(hooks_app, emit)
    register_models_commands(models_app, emit)
    register_config_commands(config_app, emit)
    register_workspace_commands(workspace_app, emit)
    register_doctor_command(app, emit)


def _operation_error_message(exc: Exception) -> str:
    if isinstance(exc, KeyError) and exc.args:
        return str(exc.args[0])
    message = str(exc).strip()
    if message:
        return message
    return exc.__class__.__name__


def _emit_error(message: str, *, exit_code: int = 1) -> None:
    """Emit an error via the active sink and exit."""

    sink, flush_after = _resolve_sink(_GLOBAL_OPTIONS.get())
    sink.error(message, exit_code=exit_code)
    if flush_after:
        flush_sink(sink)
    raise SystemExit(exit_code)


def _top_level_command_names() -> set[str]:
    return {name for name in app.resolved_commands() if not name.startswith("-")}


def _validate_top_level_command(argv: Sequence[str], *, global_harness: str | None = None) -> None:
    if _bootstrap_first_positional_token(argv) is None:
        return
    _bootstrap_validate_top_level_command(
        argv,
        known_commands=_top_level_command_names(),
        global_harness=global_harness,
    )


def _is_root_help_request(argv: Sequence[str]) -> bool:
    return _bootstrap_is_root_help_request(argv)


def _should_startup_bootstrap(argv: Sequence[str]) -> bool:
    return _bootstrap_should_startup_bootstrap(argv)


def _print_agent_root_help() -> None:
    print(_AGENT_ROOT_HELP, end="")


def main(argv: Sequence[str] | None = None) -> None:
    """CLI entry point used by `meridian` and `python -m meridian`."""

    from meridian.lib.core.logging import configure_logging

    args = list(sys.argv[1:] if argv is None else argv)

    json_mode = "--json" in args
    if not json_mode and "--format" in args:
        try:
            fmt_idx = args.index("--format")
            fmt_val = args[fmt_idx + 1] if fmt_idx + 1 < len(args) else ""
            json_mode = fmt_val.lower() == "json"
        except (IndexError, ValueError):
            pass
    verbose_count = args.count("--verbose") + args.count("-v")
    configure_logging(json_mode=json_mode, verbosity=verbose_count)

    cleaned_args, options = _extract_global_options(args)
    if not (cleaned_args and cleaned_args[0] == "mars"):
        cleaned_args, passthrough_args = _split_passthrough_args(cleaned_args)
        options = options.model_copy(update={"passthrough_args": passthrough_args})
    effective_agent_mode = (
        agent_mode_enabled() and not options.force_human and not _interactive_terminal_attached()
    )

    # Resolve output format based on command and agent mode
    resolved_format = _resolve_output_format_for_command(
        argv=cleaned_args,
        explicit_format=options.explicit_format,
        agent_mode=effective_agent_mode,
    )
    options = options.model_copy(update={"output": OutputConfig(format=resolved_format)})

    if cleaned_args and cleaned_args[0] == "mars":
        _run_mars_passthrough(cleaned_args[1:], output_format=options.output.format)

    if effective_agent_mode and (not cleaned_args or _is_root_help_request(cleaned_args)):
        _print_agent_root_help()
        return

    _validate_top_level_command(cleaned_args, global_harness=options.harness)

    maybe_bootstrap_runtime_state(cleaned_args, agent_mode=agent_mode_enabled())

    active_sink = create_sink(options.output)
    options = options.model_copy(update={"sink": active_sink})
    token = _GLOBAL_OPTIONS.set(options)
    try:
        with temporary_config_env(options.config_file):
            try:
                app(cleaned_args)
            except SystemExit:
                raise
            except TimeoutError as exc:
                _emit_error(_operation_error_message(exc), exit_code=124)
            except (KeyError, ValueError, FileNotFoundError, OSError) as exc:
                _emit_error(_operation_error_message(exc))
    finally:
        flush_sink(active_sink)
        _GLOBAL_OPTIONS.reset(token)


_register_group_commands()
