import json
import subprocess
from pathlib import Path

from nacl.signing import SigningKey

from transient_trace.atp.canonicalization import canonicalizeForSigning
from transient_trace.atp.signer import signUnsignedReceipt
from transient_trace.atp.validator import verifyActionReceipt

_TEST_DIR = Path(__file__).parent
_SDK = _TEST_DIR.parent.parent / "sdk-src"


def _node_eval(js: str) -> str:
    proc = subprocess.run(
        ["node", "--input-type=module", "-e", js],
        capture_output=True,
        text=True,
        cwd=str(_SDK),
        check=True,
    )
    return proc.stdout.strip()


def test_rfc8785_canonicalization_matches_ts() -> None:
    payload = {
        "z": [3, {"b": 2, "a": 1.23}],
        "a": {"m": "x", "k": [True, False, None]},
        "unicode": "é",
    }
    py_canon = canonicalizeForSigning(payload).decode("utf-8")
    js = f"""
      import canonicalize from 'json-canon';
      const obj = {json.dumps(payload, ensure_ascii=False)};
      process.stdout.write(canonicalize(obj));
    """
    ts_canon = _node_eval(js)
    assert py_canon == ts_canon


def test_ed25519_signature_matches_ts_for_same_seed_and_payload() -> None:
    unsigned = {
        "receipt_id": "TR-1",
        "intent_id": "TI-1",
        "decision_id": "TD-1",
        "execution_status": "executed",
        "captured_at": "2026-01-01T00:00:00.002Z",
        "schemaVersion": "1.0.0",
        "occurred_at": "2026-01-01T00:00:00.000Z",
        "received_at": "2026-01-01T00:00:00.001Z",
        "sealed_at": "2026-01-01T00:00:00.002Z",
        "event_snapshot": {"action": "executeAction", "input_digest": "00" * 32, "output_digest": "11" * 32, "intent_id": "TI-1", "action_class": "read", "target": "x"},
        "event_snapshot_hash": "22" * 32,
        "correlation_id": "sess_test:TI-1",
    }
    seed_hex = "1f" * 32
    sk = SigningKey(bytes.fromhex(seed_hex))
    py_receipt = signUnsignedReceipt(unsigned, {"sign": lambda m: sk.sign(m).signature, "kid": "kid-1"})

    js = f"""
      import {{ ed25519 }} from '@noble/curves/ed25519.js';
      import canonicalize from 'json-canon';
      const unsigned = {json.dumps(unsigned)};
      const canonical = canonicalize(unsigned);
      const msg = new TextEncoder().encode(canonical);
      const sk = Buffer.from('{seed_hex}', 'hex');
      const sig = ed25519.sign(msg, sk);
      process.stdout.write(Buffer.from(sig).toString('base64url'));
    """
    ts_sig = _node_eval(js)
    assert py_receipt["signature"]["sig"] == ts_sig
    assert verifyActionReceipt(py_receipt, bytes(sk.verify_key))
