from transient_trace.Client import Client_init
from transient_trace.atp.id_generator import (
    generateDecisionId,
    generateIntentId,
    generateReceiptId,
    resetIdCountersForTesting,
)
from transient_trace.atp.rfc3339 import parseRfc3339Ms
from transient_trace.atp.snapshot import computeSnapshotHash, createEventSnapshot


def test_id_formats() -> None:
    import re

    resetIdCountersForTesting()
    iid = generateIntentId()
    did = generateDecisionId()
    rid = generateReceiptId()
    assert re.match(r"^TI-[0-9A-HJKMNP-TV-Z]{26}$", iid)
    assert re.match(r"^TD-[0-9A-HJKMNP-TV-Z]{26}$", did)
    assert re.match(r"^TR-[0-9A-HJKMNP-TV-Z]{26}$", rid)


def test_snapshot_hash_is_deterministic_hex() -> None:
    snap = createEventSnapshot("run", {"a": 1}, {"b": 2})
    h1 = computeSnapshotHash(snap)
    h2 = computeSnapshotHash(snap)
    assert h1 == h2
    assert len(h1) == 64
    int(h1, 16)


def test_action_receipt_timestamps_ordered() -> None:
    client = Client_init({"agentId": "t-time", "policy": {"version": 1, "defaultAction": "allow", "rules": [{"id": "allow_all", "action": "allow"}]}})
    result = client.executeActionWithReceipt(lambda: {"ok": True}, {"target": "x"})
    receipt = result["receipt"]
    assert parseRfc3339Ms(receipt["occurred_at"]) <= parseRfc3339Ms(receipt["received_at"]) <= parseRfc3339Ms(receipt["sealed_at"])
