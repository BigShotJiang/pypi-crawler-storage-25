"""
test_builtin_package_enforcement.py — End-to-end enforcement tests for the four
built-in governance packages.

These tests verify that the actual rule conditions (regexes, field matchers) fire
correctly for real command strings, going through the full Client → PEP pipeline.
Structure tests live in test_builtin_packages.py; these test outcomes.

Coverage:
  - code package:       git push deny, dry-run exception, pip/npm install deny,
                        requirements-file exception, lockfile exception
  - filesystem package: recursive delete deny, sensitive path challenge,
                        delete outside cwd challenge
  - web package:        SSRF deny (private ranges), external mutation challenge,
                        safe external GET allowed
  - messaging package:  external delivery challenge, bulk delivery deny,
                        unknown recipient challenge
"""

import pytest
import transient_trace

# ── helpers ───────────────────────────────────────────────────────────────────

_ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}


def _client(package_name: str, mode: str = "audit"):
    return transient_trace.Client({
        "pepPolicy": _ALLOW_ALL,
        "packages": [package_name],
        "mode": mode,
    })


def _exec(client, command: str, action_class: str = "write_low", **extra):
    return client.executeActionWithReceipt(
        lambda: "ok",
        {"action": command.split()[0], "action_class": action_class,
         "target": {"command": command, **extra}},
    )


def _was_blocked(reason_code: str) -> bool:
    """True if the audit-mode reason_code indicates the action would have been blocked."""
    return "would_be_deny" in reason_code or "would_be_approval_required" in reason_code


def _network(client, host: str, method: str = "GET", path: str = "/",
             delivery_mode: str = "", recipient_topology: str = ""):
    meta = {}
    if delivery_mode:
        meta["deliveryMode"] = delivery_mode
    if recipient_topology:
        meta["recipientTopology"] = recipient_topology
    return client.executeActionWithReceipt(
        lambda: "ok",
        {
            "action": "httpRequest",
            "action_type": "network",
            "action_class": "network",
            "target": {"host": host, "method": method, "path": path},
            "metadata": meta,
        },
    )


# ── code package ──────────────────────────────────────────────────────────────

class TestCodePackageEnforcement:
    """code package — OWASP ASI-03 / ASI-06."""

    def test_git_push_origin_is_denied(self):
        c = _client("code")
        r = _exec(c, "git push origin main")
        assert r["decision"]["outcome"] == "allow"           # audit mode
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "code-git-push-remote-deny"

    def test_git_push_upstream_is_denied(self):
        c = _client("code")
        r = _exec(c, "git push upstream feature-branch")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "code-git-push-remote-deny"

    def test_git_push_dry_run_is_allowed(self):
        c = _client("code")
        r = _exec(c, "git push --dry-run origin main")
        assert r["decision"]["outcome"] == "allow"
        assert "would_be_deny" not in r["decision"]["reason_code"]

    def test_git_status_is_allowed(self):
        c = _client("code")
        r = _exec(c, "git status", action_class="read")
        assert r["decision"]["outcome"] == "allow"
        assert "would_be_deny" not in r["decision"]["reason_code"]

    def test_pip_install_bare_is_denied(self):
        c = _client("code")
        r = _exec(c, "pip install requests")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "code-package-install-no-lockfile-deny"

    def test_pip_install_with_requirements_is_allowed(self):
        c = _client("code")
        r = _exec(c, "pip install -r requirements.txt")
        assert r["decision"]["outcome"] == "allow"
        assert "would_be_deny" not in r["decision"]["reason_code"]

    def test_pip_install_requirement_long_flag_is_allowed(self):
        c = _client("code")
        r = _exec(c, "pip install --requirement requirements.txt")
        assert r["decision"]["outcome"] == "allow"
        assert "would_be_deny" not in r["decision"]["reason_code"]

    def test_npm_install_bare_is_denied(self):
        c = _client("code")
        r = _exec(c, "npm install")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "code-package-install-no-lockfile-deny"

    def test_npm_install_with_package_lock_is_allowed(self):
        c = _client("code")
        r = _exec(c, "npm install --package-lock")
        assert r["decision"]["outcome"] == "allow"
        assert "would_be_deny" not in r["decision"]["reason_code"]

    def test_yarn_add_is_denied(self):
        c = _client("code")
        r = _exec(c, "yarn add lodash")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "code-package-install-no-lockfile-deny"

    def test_cargo_add_without_locked_is_denied(self):
        c = _client("code")
        r = _exec(c, "cargo add serde")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "code-package-install-no-lockfile-deny"

    def test_cargo_add_with_locked_is_allowed(self):
        c = _client("code")
        r = _exec(c, "cargo add --locked serde")
        assert r["decision"]["outcome"] == "allow"
        assert "would_be_deny" not in r["decision"]["reason_code"]

    def test_strict_mode_git_push_raises(self):
        c = _client("code", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _exec(c, "git push origin main")

    def test_strict_mode_git_push_dry_run_does_not_raise(self):
        c = _client("code", mode="strict")
        r = _exec(c, "git push --dry-run origin main")
        assert r["output"] == "ok"


# ── filesystem package ────────────────────────────────────────────────────────

class TestFilesystemPackageEnforcement:
    """filesystem package — OWASP ASI-07."""

    def test_rm_rf_is_denied(self):
        c = _client("filesystem")
        r = _exec(c, "rm -rf /tmp/build", action_class="delete")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "filesystem-bulk-delete-deny"

    def test_rm_recursive_long_is_denied(self):
        c = _client("filesystem")
        r = _exec(c, "rm -r /home/user/old", action_class="delete")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "filesystem-bulk-delete-deny"

    def test_find_delete_is_denied(self):
        c = _client("filesystem")
        r = _exec(c, "find . -name '*.tmp' -delete", action_class="delete")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "filesystem-bulk-delete-deny"

    def test_rm_single_file_is_not_bulk_delete(self):
        c = _client("filesystem")
        import os
        # Non-recursive rm with explicit cwd so outside_cwd check can resolve
        r = c.executeActionWithReceipt(
            lambda: "ok",
            {"action": "rm", "action_class": "delete",
             "target": {"command": "rm ./output.txt", "cwd": os.getcwd(),
                        "path": os.path.join(os.getcwd(), "output.txt")}},
        )
        assert not _was_blocked(r["decision"]["reason_code"])

    def test_cat_ssh_key_is_challenged(self):
        c = _client("filesystem")
        r = _exec(c, "cat ~/.ssh/id_rsa", action_class="read")
        assert _was_blocked(r["decision"]["reason_code"])
        assert r["decision"]["matched_rule_id"] == "filesystem-sensitive-path-challenge"

    def test_cat_aws_credentials_is_challenged(self):
        c = _client("filesystem")
        r = _exec(c, "cat ~/.aws/credentials", action_class="read")
        assert _was_blocked(r["decision"]["reason_code"])
        assert r["decision"]["matched_rule_id"] == "filesystem-sensitive-path-challenge"

    def test_cat_etc_passwd_is_challenged(self):
        c = _client("filesystem")
        r = _exec(c, "cat /etc/passwd", action_class="read")
        assert _was_blocked(r["decision"]["reason_code"])
        assert r["decision"]["matched_rule_id"] == "filesystem-sensitive-path-challenge"

    def test_cat_normal_file_is_allowed(self):
        c = _client("filesystem")
        r = _exec(c, "cat ./README.md", action_class="read")
        assert r["decision"]["outcome"] == "allow"
        assert not _was_blocked(r["decision"]["reason_code"])

    def test_strict_mode_rm_rf_raises(self):
        c = _client("filesystem", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _exec(c, "rm -rf /tmp/build", action_class="delete")


# ── web package ───────────────────────────────────────────────────────────────

class TestWebPackageEnforcement:
    """web package — OWASP ASI-08."""

    @pytest.mark.parametrize("host", [
        "10.0.0.1",
        "10.255.255.255",
        "192.168.1.1",
        "192.168.0.100",
        "172.16.0.1",
        "172.31.255.255",
        "169.254.1.1",
        "127.0.0.1",
        "localhost",
    ])
    def test_ssrf_internal_hosts_are_denied(self, host):
        c = _client("web")
        r = _network(c, host, method="GET")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "web-ssrf-internal-deny"

    @pytest.mark.parametrize("method", ["POST", "PUT", "PATCH"])
    def test_external_mutation_is_challenged(self, method):
        c = _client("web")
        r = _network(c, "api.example.com", method=method, path="/v1/data")
        assert _was_blocked(r["decision"]["reason_code"])
        assert r["decision"]["matched_rule_id"] == "web-external-mutation-challenge"

    def test_external_get_is_allowed(self):
        c = _client("web")
        r = _network(c, "api.example.com", method="GET")
        assert r["decision"]["outcome"] == "allow"
        assert not _was_blocked(r["decision"]["reason_code"])

    def test_public_ip_get_is_allowed(self):
        c = _client("web")
        r = _network(c, "1.1.1.1", method="GET")
        assert r["decision"]["outcome"] == "allow"
        assert not _was_blocked(r["decision"]["reason_code"])

    def test_strict_mode_ssrf_raises(self):
        c = _client("web", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _network(c, "192.168.1.1", method="GET")

    def test_ssrf_takes_precedence_over_mutation_for_internal_post(self):
        c = _client("web")
        r = _network(c, "10.0.0.5", method="POST")
        # SSRF deny fires before mutation challenge because internal host
        assert r["decision"]["matched_rule_id"] == "web-ssrf-internal-deny"


# ── messaging package ─────────────────────────────────────────────────────────

class TestMessagingPackageEnforcement:
    """messaging package — OWASP ASI-05."""

    def test_external_delivery_mode_is_challenged(self):
        c = _client("messaging")
        r = _network(c, "mail.example.com", delivery_mode="external")
        assert _was_blocked(r["decision"]["reason_code"])
        assert r["decision"]["matched_rule_id"] == "messaging-ext-egress-challenge"

    def test_bulk_delivery_mode_is_denied(self):
        c = _client("messaging")
        r = _network(c, "smtp.example.com", delivery_mode="bulk")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert r["decision"]["matched_rule_id"] == "messaging-bulk-egress-deny"

    def test_unknown_recipient_topology_is_challenged(self):
        c = _client("messaging")
        r = _network(c, "api.example.com", recipient_topology="unknown")
        assert _was_blocked(r["decision"]["reason_code"])
        assert r["decision"]["matched_rule_id"] == "messaging-unknown-recipient-challenge"

    def test_known_internal_delivery_is_allowed(self):
        c = _client("messaging")
        r = _network(c, "internal-relay.corp", delivery_mode="internal")
        assert r["decision"]["outcome"] == "allow"
        assert not _was_blocked(r["decision"]["reason_code"])

    def test_strict_mode_bulk_raises(self):
        c = _client("messaging", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _network(c, "smtp.example.com", delivery_mode="bulk")


# ── cross-package combinations ────────────────────────────────────────────────

class TestMultiplePackagesCombined:
    """Loading multiple packages together — rules from both must fire."""

    def test_code_and_filesystem_both_active(self):
        c = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": ["code", "filesystem"],
            "mode": "audit",
        })
        # code rule fires
        r1 = _exec(c, "git push origin main")
        assert "would_be_deny" in r1["decision"]["reason_code"]
        assert r1["decision"]["matched_rule_id"] == "code-git-push-remote-deny"

        # filesystem rule fires
        r2 = _exec(c, "rm -rf /tmp/junk", action_class="delete")
        assert _was_blocked(r2["decision"]["reason_code"])
        assert r2["decision"]["matched_rule_id"] == "filesystem-bulk-delete-deny"

    def test_web_and_messaging_both_active(self):
        c = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": ["web", "messaging"],
            "mode": "audit",
        })
        # web SSRF fires
        r1 = _network(c, "192.168.1.1", method="GET")
        assert "would_be_deny" in r1["decision"]["reason_code"]
        assert r1["decision"]["matched_rule_id"] == "web-ssrf-internal-deny"

        # messaging bulk fires
        r2 = _network(c, "smtp.example.com", delivery_mode="bulk")
        assert _was_blocked(r2["decision"]["reason_code"])
        assert r2["decision"]["matched_rule_id"] == "messaging-bulk-egress-deny"

    def test_operator_policy_deny_takes_precedence_over_package_allow(self):
        """Operator policy rules always evaluated alongside packages; deny wins."""
        deny_network = {
            "version": 1,
            "defaultAction": "allow",
            "rules": [{"id": "deny-all-network", "action": "deny",
                        "actionClasses": ["network"]}],
        }
        c = transient_trace.Client({
            "pepPolicy": deny_network,
            "packages": ["web"],
            "mode": "audit",
        })
        r = _network(c, "api.example.com", method="GET")
        # Policy deny fires, not the package (GET to external is allowed by web package)
        assert "would_be_deny" in r["decision"]["reason_code"]
