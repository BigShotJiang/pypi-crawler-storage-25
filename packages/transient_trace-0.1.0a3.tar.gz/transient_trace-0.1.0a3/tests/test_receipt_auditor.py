"""
test_receipt_auditor.py — Tests for ReceiptAuditor

Covers: time-range queries, incident reports, export bundles,
manifest hash integrity, and tamper detection.
"""

import json
import time
import pytest
from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def store(tmp_path):
    from transient_trace.receipt_engine.store import ReceiptStore
    s = ReceiptStore(db_path=tmp_path / "receipts.db")
    yield s
    s.close()


@pytest.fixture
def auditor(store):
    from transient_trace.receipt_engine.audit import ReceiptAuditor
    return ReceiptAuditor(store)


def make_receipt(i, action_class="filesystem", tool_name="write_file",
                 outcome="deny", rule_id="ASI-07",
                 rule_reason="protected system path", ts=None):
    return {
        "receipt_id":          f"receipt-{i:04d}",
        "action_class":        action_class,
        "tool_name":           tool_name,
        "outcome":             outcome,
        "matched_rule_id":     rule_id,
        "matched_rule_reason": rule_reason,
        "matched_package":     "filesystem",
        "ts":                  ts or time.time(),
        "signature":           {"alg": "Ed25519", "kid": "test", "sig": f"sig{i}"},
    }


# ---------------------------------------------------------------------------
# ReceiptAuditor.query
# ---------------------------------------------------------------------------

class TestAuditorQuery:

    def test_query_all(self, store, auditor):
        for i in range(5):
            store.write(make_receipt(i))
        results = auditor.query()
        assert len(results) == 5

    def test_query_time_range(self, store, auditor):
        now = time.time()
        # 3 receipts yesterday, 2 today
        for i in range(3):
            store.write(make_receipt(i, ts=now - 86400))
        for i in range(3, 5):
            store.write(make_receipt(i, ts=now))

        yesterday = now - 86400
        results = auditor.query(from_ts=yesterday - 10, to_ts=yesterday + 10)
        assert len(results) == 3

    def test_query_iso_date_string(self, store, auditor):
        from datetime import datetime, timezone
        # Write receipts with known timestamps
        apr6 = datetime(2026, 4, 6, 12, 0, 0, tzinfo=timezone.utc).timestamp()
        apr8 = datetime(2026, 4, 8, 12, 0, 0, tzinfo=timezone.utc).timestamp()
        store.write(make_receipt(1, ts=apr6))
        store.write(make_receipt(2, ts=apr8))

        results = auditor.query(from_ts="2026-04-06", to_ts="2026-04-06")
        assert len(results) == 1
        assert results[0]["receipt_id"] == "receipt-0001"

    def test_query_by_outcome(self, store, auditor):
        store.write(make_receipt(1, outcome="deny"))
        store.write(make_receipt(2, outcome="allow"))
        store.write(make_receipt(3, outcome="allow"))
        denies = auditor.query(outcome="deny")
        allows = auditor.query(outcome="allow")
        assert len(denies) == 1
        assert len(allows) == 2

    def test_query_by_action_class(self, store, auditor):
        store.write(make_receipt(1, action_class="filesystem"))
        store.write(make_receipt(2, action_class="web", tool_name="http_request"))
        results = auditor.query(action_class="filesystem")
        assert len(results) == 1

    def test_query_returns_ascending_order(self, store, auditor):
        now = time.time()
        for i in range(5):
            store.write(make_receipt(i, ts=now + i))
        results = auditor.query()
        timestamps = [r["ts"] for r in results]
        assert timestamps == sorted(timestamps)

    def test_query_empty_window(self, store, auditor):
        store.write(make_receipt(1, ts=time.time()))
        results = auditor.query(from_ts=time.time() + 9999, to_ts=time.time() + 99999)
        assert results == []


# ---------------------------------------------------------------------------
# ReceiptAuditor.explain
# ---------------------------------------------------------------------------

class TestAuditorExplain:

    def test_explain_empty_window(self, auditor):
        report = auditor.explain(from_ts=time.time() + 9999)
        assert report["summary"]["total"] == 0
        assert "no receipts found" in report["summary"]["message"]

    def test_explain_summary_counts(self, store, auditor):
        for i in range(7):
            store.write(make_receipt(i, outcome="deny"))
        for i in range(7, 10):
            store.write(make_receipt(i, outcome="allow"))
        report = auditor.explain()
        assert report["summary"]["total"] == 10
        assert report["summary"]["outcomes"]["deny"] == 7
        assert report["summary"]["outcomes"]["allow"] == 3
        assert abs(report["summary"]["deny_rate"] - 0.7) < 0.01

    def test_explain_lists_deny_events(self, store, auditor):
        store.write(make_receipt(1, outcome="deny", rule_id="ASI-07"))
        store.write(make_receipt(2, outcome="allow"))
        report = auditor.explain()
        assert len(report["denies"]) == 1
        assert report["denies"][0]["rule_id"] == "ASI-07"
        assert report["denies"][0]["receipt_id"] == "receipt-0001"

    def test_explain_top_rules(self, store, auditor):
        for i in range(5):
            store.write(make_receipt(i, outcome="deny", rule_id="ASI-07"))
        for i in range(5, 8):
            store.write(make_receipt(i, outcome="deny", rule_id="ASI-05"))
        report = auditor.explain()
        assert report["top_rules"][0]["rule_id"] == "ASI-07"
        assert report["top_rules"][0]["count"] == 5
        assert report["top_rules"][1]["rule_id"] == "ASI-05"

    def test_explain_pattern_shifts(self, store, auditor):
        # filesystem has both deny and allow — should flag as pattern shift
        store.write(make_receipt(1, action_class="filesystem", outcome="deny"))
        store.write(make_receipt(2, action_class="filesystem", outcome="allow"))
        store.write(make_receipt(3, action_class="web", outcome="deny"))
        report = auditor.explain()
        assert "filesystem" in report["pattern_shifts"]
        assert "web" not in report["pattern_shifts"]  # only deny, no allow

    def test_explain_includes_manifest_hash(self, store, auditor):
        store.write(make_receipt(1))
        report = auditor.explain()
        assert "verification" in report
        assert "manifest_hash" in report["verification"]
        assert len(report["verification"]["manifest_hash"]) == 64  # SHA-256 hex

    def test_explain_manifest_hash_changes_with_receipts(self, store, auditor):
        store.write(make_receipt(1))
        report1 = auditor.explain()
        store.write(make_receipt(2))
        report2 = auditor.explain()
        assert report1["verification"]["manifest_hash"] != report2["verification"]["manifest_hash"]


# ---------------------------------------------------------------------------
# ReceiptAuditor.export_bundle
# ---------------------------------------------------------------------------

class TestAuditorExportBundle:

    def test_export_creates_file(self, store, auditor, tmp_path):
        for i in range(5):
            store.write(make_receipt(i))
        out = tmp_path / "bundle.json"
        result = auditor.export_bundle(path=out)
        assert out.exists()
        assert result["receipt_count"] == 5

    def test_export_bundle_structure(self, store, auditor, tmp_path):
        for i in range(3):
            store.write(make_receipt(i))
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out)
        bundle = json.loads(out.read_text())
        assert "bundle_version" in bundle
        assert "manifest" in bundle
        assert "receipts" in bundle
        assert "report" in bundle
        assert len(bundle["receipts"]) == 3

    def test_export_receipts_are_independently_verifiable(self, store, auditor, tmp_path):
        store.write(make_receipt(1))
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out)
        bundle = json.loads(out.read_text())
        # Every receipt has a signature
        for r in bundle["receipts"]:
            assert "signature" in r
            assert r["signature"]["alg"] == "Ed25519"

    def test_export_manifest_hash_matches_receipts(self, store, auditor, tmp_path):
        for i in range(5):
            store.write(make_receipt(i))
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out)
        bundle = json.loads(out.read_text())

        # Recompute manifest hash from bundle receipts
        from transient_trace.receipt_engine.audit import _hash_receipt_set
        recomputed = _hash_receipt_set(bundle["receipts"])
        assert recomputed == bundle["manifest"]["hash"]

    def test_export_tamper_detection_add_receipt(self, store, auditor, tmp_path):
        """Adding a receipt to the bundle breaks the manifest hash."""
        store.write(make_receipt(1))
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out)
        bundle = json.loads(out.read_text())
        original_hash = bundle["manifest"]["hash"]

        # Tamper: add a fake receipt
        bundle["receipts"].append(make_receipt(99))
        from transient_trace.receipt_engine.audit import _hash_receipt_set
        tampered_hash = _hash_receipt_set(bundle["receipts"])
        assert tampered_hash != original_hash

    def test_export_tamper_detection_remove_receipt(self, store, auditor, tmp_path):
        """Removing a receipt from the bundle breaks the manifest hash."""
        for i in range(3):
            store.write(make_receipt(i))
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out)
        bundle = json.loads(out.read_text())
        original_hash = bundle["manifest"]["hash"]

        # Tamper: remove a receipt
        bundle["receipts"].pop(0)
        from transient_trace.receipt_engine.audit import _hash_receipt_set
        tampered_hash = _hash_receipt_set(bundle["receipts"])
        assert tampered_hash != original_hash

    def test_export_without_report(self, store, auditor, tmp_path):
        store.write(make_receipt(1))
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out, include_report=False)
        bundle = json.loads(out.read_text())
        assert "report" not in bundle

    def test_export_time_window(self, store, auditor, tmp_path):
        now = time.time()
        store.write(make_receipt(1, ts=now - 86400))  # yesterday
        store.write(make_receipt(2, ts=now))          # today
        out = tmp_path / "bundle.json"
        result = auditor.export_bundle(
            path=out,
            from_ts=now - 10,
            to_ts=now + 10,
        )
        assert result["receipt_count"] == 1
        bundle = json.loads(out.read_text())
        assert len(bundle["receipts"]) == 1
        assert bundle["receipts"][0]["receipt_id"] == "receipt-0002"


# ---------------------------------------------------------------------------
# ReceiptEngine facade
# ---------------------------------------------------------------------------

class TestReceiptEngineFacade:

    def test_engine_query(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine
        engine = ReceiptEngine(db_path=tmp_path / "r.db")
        engine.store(make_receipt(1, outcome="deny"))
        engine.store(make_receipt(2, outcome="allow"))
        results = engine.query(outcome="deny")
        assert len(results) == 1

    def test_engine_explain(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine
        engine = ReceiptEngine(db_path=tmp_path / "r.db")
        for i in range(5):
            engine.store(make_receipt(i, outcome="deny"))
        report = engine.explain()
        assert report["summary"]["total"] == 5
        assert report["summary"]["outcomes"]["deny"] == 5

    def test_engine_export_bundle(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine
        engine = ReceiptEngine(db_path=tmp_path / "r.db")
        for i in range(3):
            engine.store(make_receipt(i))
        out = tmp_path / "audit.json"
        result = engine.export_bundle(path=out)
        assert out.exists()
        assert result["receipt_count"] == 3
