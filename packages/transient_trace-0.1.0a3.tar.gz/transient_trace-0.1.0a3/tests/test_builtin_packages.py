"""
test_builtin_packages.py — Tests for built-in governance packages.

Verifies:
  - list_builtin_packages returns the expected four package names
  - get_builtin_package returns a full definition for each
  - all four built-ins pass validate_package without error
  - all four built-ins load into PackageRegistry without error
  - each package description references its OWASP coverage
  - messaging rules are NOT present in governed_action_normalize.py
    (they live solely in the builtin package)
"""

import inspect

import pytest

import transient_trace.atp.governed_action_normalize as gan_module

from transient_trace.atp.builtin_packages import (
    get_builtin_package,
    list_builtin_packages,
)
from transient_trace.atp.governance_package import validate_package
from transient_trace.atp.package_registry import PackageRegistry


# ------------------------------------------------------------------
# list_builtin_packages
# ------------------------------------------------------------------

class TestListBuiltinPackages:
    def test_returns_six_names(self):
        names = list_builtin_packages()
        assert len(names) == 6

    def test_returns_expected_names(self):
        names = list_builtin_packages()
        assert set(names) == {"messaging", "filesystem", "web", "code", "privilege", "shell"}

    def test_returns_list(self):
        assert isinstance(list_builtin_packages(), list)

    def test_order_is_stable(self):
        # Deterministic ordering for tooling/docs
        assert list_builtin_packages() == list_builtin_packages()


# ------------------------------------------------------------------
# get_builtin_package
# ------------------------------------------------------------------

class TestGetBuiltinPackage:
    def test_returns_dict_for_messaging(self):
        pkg = get_builtin_package("messaging")
        assert isinstance(pkg, dict)
        assert pkg["name"] == "messaging"

    def test_returns_dict_for_filesystem(self):
        pkg = get_builtin_package("filesystem")
        assert isinstance(pkg, dict)
        assert pkg["name"] == "filesystem"

    def test_returns_dict_for_web(self):
        pkg = get_builtin_package("web")
        assert isinstance(pkg, dict)
        assert pkg["name"] == "web"

    def test_returns_dict_for_code(self):
        pkg = get_builtin_package("code")
        assert isinstance(pkg, dict)
        assert pkg["name"] == "code"

    def test_unknown_name_raises_value_error(self):
        with pytest.raises(ValueError, match="no built-in"):
            get_builtin_package("nonexistent")

    def test_unknown_name_error_lists_available(self):
        with pytest.raises(ValueError, match="messaging"):
            get_builtin_package("nonexistent")


# ------------------------------------------------------------------
# validate_package — all four pass schema validation
# ------------------------------------------------------------------

class TestBuiltinPackagesValidate:
    @pytest.mark.parametrize("name", ["messaging", "filesystem", "web", "code"])
    def test_passes_validate_package(self, name):
        pkg = get_builtin_package(name)
        # Should not raise
        validate_package(pkg)

    @pytest.mark.parametrize("name", ["messaging", "filesystem", "web", "code"])
    def test_has_required_fields(self, name):
        pkg = get_builtin_package(name)
        assert "name" in pkg
        assert "version" in pkg
        assert "rules" in pkg
        assert isinstance(pkg["rules"], list)

    @pytest.mark.parametrize("name", ["messaging", "filesystem", "web", "code"])
    def test_rules_are_non_empty(self, name):
        pkg = get_builtin_package(name)
        assert len(pkg["rules"]) > 0, f"{name} package must have at least one rule"

    @pytest.mark.parametrize("name", ["messaging", "filesystem", "web", "code"])
    def test_all_rules_have_ids(self, name):
        pkg = get_builtin_package(name)
        for rule in pkg["rules"]:
            assert "id" in rule, f"rule in {name} package missing 'id'"
            assert rule["id"], f"rule 'id' in {name} package must be non-empty"


# ------------------------------------------------------------------
# PackageRegistry — load by string name
# ------------------------------------------------------------------

class TestPackageRegistryBuiltins:
    @pytest.mark.parametrize("name", ["messaging", "filesystem", "web", "code"])
    def test_load_builtin_by_string_name(self, name):
        reg = PackageRegistry()
        reg.load(name)
        names = {p["name"] for p in reg.list_packages()}
        assert name in names

    def test_load_all_four_builtins(self):
        reg = PackageRegistry()
        for name in ["messaging", "filesystem", "web", "code"]:
            reg.load(name)
        assert len(reg.list_packages()) == 4

    def test_load_all_builtins_via_load_all(self):
        reg = PackageRegistry()
        reg.load_all(["messaging", "filesystem", "web", "code"])
        assert len(reg.list_packages()) == 4

    def test_describe_returns_full_definition(self):
        reg = PackageRegistry()
        reg.load("messaging")
        pkg = reg.describe("messaging")
        assert pkg["name"] == "messaging"
        assert "rules" in pkg
        assert len(pkg["rules"]) > 0

    def test_unknown_builtin_raises_value_error(self):
        reg = PackageRegistry()
        with pytest.raises(ValueError, match="no built-in"):
            reg.load("nonexistent-package")


# ------------------------------------------------------------------
# OWASP coverage in descriptions
# ------------------------------------------------------------------

class TestOwaspCoverage:
    def test_messaging_description_references_asi05(self):
        pkg = get_builtin_package("messaging")
        assert "ASI-05" in pkg["description"]

    def test_filesystem_description_references_asi02(self):
        pkg = get_builtin_package("filesystem")
        assert "ASI-02" in pkg["description"]

    def test_web_description_references_asi02(self):
        pkg = get_builtin_package("web")
        assert "ASI-02" in pkg["description"]

    def test_code_description_references_asi04(self):
        pkg = get_builtin_package("code")
        assert "ASI-04" in pkg["description"]

    def test_privilege_description_references_asi03(self):
        pkg = get_builtin_package("privilege")
        assert "ASI-03" in pkg["description"]

    def test_shell_description_references_asi04(self):
        pkg = get_builtin_package("shell")
        assert "ASI-04" in pkg["description"]


# ------------------------------------------------------------------
# Messaging rules not duplicated in governed_action_normalize.py
# ------------------------------------------------------------------

class TestMessagingRulesNotInNormalize:
    def test_governed_action_normalize_has_no_policy_rules(self):
        """
        governed_action_normalize.py contains normalization profiles (tool-to-action
        mapping), not policy rules. The policy enforcement rules for messaging live
        solely in builtin_packages.py (the 'messaging' package).
        """
        source = inspect.getsource(gan_module)
        # Policy rule keywords should not appear in the normalizer
        assert "deliveryMode.*external" not in source or "challenge" not in source
        # The normalizer should NOT define outcome fields (those belong in packages)
        assert '"outcome"' not in source
        assert "'outcome'" not in source

    def test_governed_action_normalize_has_no_challenge_deny_outcomes(self):
        source = inspect.getsource(gan_module)
        # outcome values are package territory, not normalization territory
        assert '"challenge"' not in source
        assert '"deny"' not in source
        assert '"allow"' not in source


# ------------------------------------------------------------------
# Messaging package rule smoke tests
# ------------------------------------------------------------------

class TestMessagingPackageRules:
    def setup_method(self):
        self.pkg = get_builtin_package("messaging")
        self.rules = self.pkg["rules"]

    def test_has_external_deliverymode_challenge(self):
        matches = [r for r in self.rules if r.get("condition", {}).get("deliveryMode") == "external"]
        assert len(matches) == 1
        assert matches[0]["outcome"] == "challenge"

    def test_has_bulk_deliverymode_deny(self):
        matches = [r for r in self.rules if r.get("condition", {}).get("deliveryMode") == "bulk"]
        assert len(matches) == 1
        assert matches[0]["outcome"] == "deny"

    def test_has_unknown_recipient_topology_challenge(self):
        matches = [r for r in self.rules if r.get("condition", {}).get("recipientTopology") == "unknown"]
        assert len(matches) == 1
        assert matches[0]["outcome"] == "challenge"

    def test_all_rules_are_egress_profile(self):
        for rule in self.rules:
            assert rule["profile"] == "egress", f"messaging rule '{rule.get('id')}' must be egress profile"


# ------------------------------------------------------------------
# Filesystem package rule smoke tests
# ------------------------------------------------------------------

class TestFilesystemPackageRules:
    def setup_method(self):
        self.pkg = get_builtin_package("filesystem")
        self.rules = self.pkg["rules"]

    def test_has_delete_outside_cwd_challenge(self):
        matches = [
            r for r in self.rules
            if r.get("condition", {}).get("action_class") == "delete"
            and r.get("outcome") == "challenge"
        ]
        assert len(matches) >= 1

    def test_has_bulk_delete_deny(self):
        matches = [
            r for r in self.rules
            if "commandPattern" in r.get("condition", {})
            and r.get("outcome") == "deny"
        ]
        assert len(matches) >= 1

    def test_has_sensitive_path_challenge(self):
        matches = [
            r for r in self.rules
            if "pathPattern" in r.get("condition", {})
            and r.get("outcome") == "challenge"
            and r.get("condition", {}).get("action_class") != "delete"
        ]
        assert len(matches) >= 1

    def test_all_rules_are_exec_profile(self):
        for rule in self.rules:
            assert rule["profile"] == "exec"


# ------------------------------------------------------------------
# Web package rule smoke tests
# ------------------------------------------------------------------

class TestWebPackageRules:
    def setup_method(self):
        self.pkg = get_builtin_package("web")
        self.rules = self.pkg["rules"]

    def test_has_external_mutation_challenge(self):
        matches = [
            r for r in self.rules
            if r.get("condition", {}).get("host") == "external"
            and r.get("outcome") == "challenge"
        ]
        assert len(matches) >= 1

    def test_has_ssrf_internal_deny(self):
        matches = [
            r for r in self.rules
            if r.get("outcome") == "deny"
        ]
        assert len(matches) >= 1

    def test_all_rules_are_egress_profile(self):
        for rule in self.rules:
            assert rule["profile"] == "egress"


# ------------------------------------------------------------------
# Code package rule smoke tests
# ------------------------------------------------------------------

class TestCodePackageRules:
    def setup_method(self):
        self.pkg = get_builtin_package("code")
        self.rules = self.pkg["rules"]

    def test_has_git_push_deny(self):
        matches = [
            r for r in self.rules
            if "git" in r.get("condition", {}).get("commandPattern", "")
            and r.get("outcome") == "deny"
        ]
        assert len(matches) >= 1

    def test_has_unknown_binary_challenge(self):
        matches = [
            r for r in self.rules
            if r.get("condition", {}).get("toolName") == "bash"
            and r.get("outcome") == "challenge"
        ]
        assert len(matches) >= 1

    def test_has_package_install_deny(self):
        matches = [
            r for r in self.rules
            if "commandPattern" in r.get("condition", {})
            and r.get("outcome") == "deny"
            and "git" not in r.get("condition", {}).get("commandPattern", "")
        ]
        assert len(matches) >= 1

    def test_all_rules_are_exec_profile(self):
        for rule in self.rules:
            assert rule["profile"] == "exec"
