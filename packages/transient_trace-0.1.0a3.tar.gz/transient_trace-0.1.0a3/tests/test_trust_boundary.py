"""
test_trust_boundary.py — Security invariant tests for transient-trace.

Verifies that the operator's governance policy cannot be subverted by the
agent being governed. The trust hierarchy is:
  operator env vars  >  cfg dict  >  agent runtime mutations

Key invariants:
  1. TRANSIENT_TRACE_MODE and TRANSIENT_TRACE_POLICY_JSON override cfg at init.
  2. Once a Client is initialised, post-init env mutations have no effect.
  3. Deny events are always written to the JSON audit trail before raising.
  4. Allow receipts are signed (Ed25519); deny events are intentionally unsigned.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from transient_trace.Client import Client


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DENY_POLICY = {
    "version": 1,
    "defaultAction": "deny",
    "rules": [],
}

_ALLOW_POLICY = {
    "version": 1,
    "defaultAction": "allow",
    "rules": [{"id": "allow_all", "action": "allow"}],
}

_EXEC_INPUT_WRITE = {
    "action": "write_file",
    "action_class": "write_low",
    "target": {"id": "/tmp/test.txt"},
}

_EXEC_INPUT_READ = {
    "action": "read_file",
    "action_class": "read",
    "target": {"id": "/tmp/test.txt"},
}


def _make_client(state_dir: str, mode: str = "strict", policy: dict = None) -> object:
    policy = policy if policy is not None else _DENY_POLICY
    return Client({
        "mode": mode,
        "pepPolicy": policy,
        "state_dir": state_dir,
    })


def _receipts(state_dir: str) -> list[dict]:
    receipts_path = Path(state_dir) / "receipts"
    if not receipts_path.exists():
        return []
    result = []
    for f in receipts_path.glob("TR-*.json"):
        result.append(json.loads(f.read_text(encoding="utf-8")))
    return result


def _deny_receipts(state_dir: str) -> list[dict]:
    return [r for r in _receipts(state_dir) if r.get("type") == "GovernanceDenyEvent"]


def _allow_receipts(state_dir: str) -> list[dict]:
    return [r for r in _receipts(state_dir) if r.get("type") == "SignedActionReceipt"]


# ---------------------------------------------------------------------------
# TestOperatorEnvOverridesConfig
# ---------------------------------------------------------------------------

class TestOperatorEnvOverridesConfig:
    """Env vars set by the operator override agent-supplied config values."""

    def test_env_mode_overrides_cfg_mode(self, monkeypatch):
        """cfg says 'permissive' but TRANSIENT_TRACE_MODE='strict' → strict enforced."""
        with tempfile.TemporaryDirectory() as state_dir:
            monkeypatch.setenv("TRANSIENT_TRACE_MODE", "strict")
            # cfg.mode=permissive would allow; strict+deny-policy must block
            client = Client({
                "mode": "permissive",
                "pepPolicy": _DENY_POLICY,
                "state_dir": state_dir,
            })
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)

    def test_env_policy_overrides_cfg_policy(self, monkeypatch):
        """cfg has allow policy but TRANSIENT_TRACE_POLICY_JSON has deny policy → deny enforced."""
        with tempfile.TemporaryDirectory() as state_dir:
            monkeypatch.setenv("TRANSIENT_TRACE_POLICY_JSON", json.dumps(_DENY_POLICY))
            client = Client({
                "mode": "strict",
                "pepPolicy": _ALLOW_POLICY,  # agent would allow
                "state_dir": state_dir,
            })
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)

    def test_env_mode_case_insensitive(self, monkeypatch):
        """TRANSIENT_TRACE_MODE='STRICT' or 'Strict' should be accepted or fall back gracefully."""
        for value in ("STRICT", "Strict"):
            with tempfile.TemporaryDirectory() as state_dir:
                monkeypatch.setenv("TRANSIENT_TRACE_MODE", value)
                # Should not raise ValueError — either parsed correctly or falls back
                try:
                    client = Client({
                        "mode": "permissive",
                        "pepPolicy": _DENY_POLICY,
                        "state_dir": state_dir,
                    })
                    # If init succeeded, the mode must be a valid recognised value
                    assert client is not None
                except ValueError as exc:
                    pytest.fail(
                        f"Client raised ValueError for TRANSIENT_TRACE_MODE={value!r}: {exc}"
                    )

    def test_env_policy_invalid_json_falls_back(self, monkeypatch):
        """TRANSIENT_TRACE_POLICY_JSON='garbage{' must not crash — uses config policy or deny-all."""
        with tempfile.TemporaryDirectory() as state_dir:
            monkeypatch.setenv("TRANSIENT_TRACE_POLICY_JSON", "garbage{not valid json")
            # Should not raise during init
            client = Client({
                "mode": "strict",
                "pepPolicy": _ALLOW_POLICY,
                "state_dir": state_dir,
            })
            assert client is not None
            # After malformed JSON is ignored, config policy (allow) is used — no RuntimeError
            result = client.executeActionWithReceipt(lambda: {"ok": True}, _EXEC_INPUT_READ)
            assert result is not None


# ---------------------------------------------------------------------------
# TestAgentCannotEscapePolicy
# ---------------------------------------------------------------------------

class TestAgentCannotEscapePolicy:
    """Post-init env mutations by the agent must not affect an existing Client."""

    def test_agent_cannot_override_mode_after_init(self):
        """
        Client in strict+deny, agent changes TRANSIENT_TRACE_MODE='permissive'
        post-init → existing instance still denies.
        """
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir, mode="strict", policy=_DENY_POLICY)
            # Simulate agent trying to relax mode after init
            os.environ["TRANSIENT_TRACE_MODE"] = "permissive"
            try:
                with pytest.raises(RuntimeError):
                    client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            finally:
                os.environ.pop("TRANSIENT_TRACE_MODE", None)

    def test_agent_cannot_override_policy_after_init(self):
        """
        Client in strict+deny, agent sets TRANSIENT_TRACE_POLICY_JSON to allow policy
        post-init → existing instance still denies.
        """
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir, mode="strict", policy=_DENY_POLICY)
            os.environ["TRANSIENT_TRACE_POLICY_JSON"] = json.dumps(_ALLOW_POLICY)
            try:
                with pytest.raises(RuntimeError):
                    client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            finally:
                os.environ.pop("TRANSIENT_TRACE_POLICY_JSON", None)

    def test_strict_mode_cannot_be_unlocked_by_agent(self):
        """
        Once Client is initialised in strict mode, no in-process env change can
        flip it to audit or permissive.
        """
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir, mode="strict", policy=_DENY_POLICY)
            for relaxed in ("audit", "permissive", "PERMISSIVE", "Audit"):
                os.environ["TRANSIENT_TRACE_MODE"] = relaxed
                try:
                    with pytest.raises(RuntimeError, match="Denied"):
                        client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
                finally:
                    os.environ.pop("TRANSIENT_TRACE_MODE", None)


# ---------------------------------------------------------------------------
# TestDenyReceiptAlwaysWritten
# ---------------------------------------------------------------------------

class TestDenyReceiptAlwaysWritten:
    """GovernanceDenyEvent files must be written to the audit trail on every deny."""

    def test_deny_event_written_to_json_trail(self):
        """strict + deny policy → RuntimeError raised + GovernanceDenyEvent file exists."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            denials = _deny_receipts(state_dir)
            assert len(denials) == 1, f"Expected 1 deny event, got {len(denials)}"

    def test_deny_event_has_correct_outcome(self):
        """Read the written JSON and verify decision.outcome == 'deny'."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            denials = _deny_receipts(state_dir)
            assert denials, "No deny events found"
            event = denials[0]
            assert event["decision"]["outcome"] == "deny"

    def test_deny_event_has_action_and_class(self):
        """Deny event intent must include action and action_class fields."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            event = _deny_receipts(state_dir)[0]
            intent = event["intent"]
            assert intent.get("action") == "write_file"
            assert intent.get("action_class") == "write_low"

    def test_deny_event_has_run_id(self):
        """Deny event intent.context.runId must be present and non-empty."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            event = _deny_receipts(state_dir)[0]
            run_id = event["intent"].get("context", {}).get("runId")
            assert run_id and isinstance(run_id, str) and len(run_id) > 0

    def test_deny_event_written_before_exception(self):
        """The deny file must exist even after catching the RuntimeError."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            try:
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            except RuntimeError:
                pass  # exception caught — now verify file is already on disk
            denials = _deny_receipts(state_dir)
            assert len(denials) == 1, "Deny event file must exist after catching RuntimeError"

    def test_allow_receipt_not_written_on_deny(self):
        """When denied, no SignedActionReceipt is written — only GovernanceDenyEvent."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            allows = _allow_receipts(state_dir)
            assert len(allows) == 0, f"No SignedActionReceipt should be written on deny; got {len(allows)}"


# ---------------------------------------------------------------------------
# TestReceiptTamperDetection
# ---------------------------------------------------------------------------

class TestReceiptTamperDetection:
    """Signature properties of allow and deny receipts."""

    def test_allow_receipt_has_signature(self):
        """After an allow action, receipt file has signature.alg != 'none'."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir, mode="strict", policy=_ALLOW_POLICY)
            client.executeActionWithReceipt(lambda: {"ok": True}, _EXEC_INPUT_READ)
            allows = _allow_receipts(state_dir)
            assert allows, "Expected a SignedActionReceipt"
            sig = allows[0]["receipt"].get("signature", {})
            alg = sig.get("alg", "none")
            assert alg != "none", f"Allow receipt must have a real signing alg, got {alg!r}"
            assert alg == "Ed25519"

    def test_deny_event_is_unsigned(self):
        """GovernanceDenyEvent receipt.signature.alg must be 'none' (intentional)."""
        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir)
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(lambda: {}, _EXEC_INPUT_WRITE)
            denials = _deny_receipts(state_dir)
            assert denials, "Expected a GovernanceDenyEvent"
            sig = denials[0]["receipt"].get("signature", {})
            assert sig.get("alg") == "none", (
                f"Deny event must be unsigned (alg='none'), got {sig.get('alg')!r}"
            )

    def test_tampered_allow_receipt_detectable(self):
        """
        Flip the outcome in a SignedActionReceipt JSON file, reload it, and verify
        that the signature check returns '✗' (invalid).
        """
        from transient_trace.atp.validator import verifyActionReceipt
        from transient_trace.cli import _load_session_key_cache, _verify_receipt

        with tempfile.TemporaryDirectory() as state_dir:
            client = _make_client(state_dir, mode="strict", policy=_ALLOW_POLICY)
            client.executeActionWithReceipt(lambda: {"ok": True}, _EXEC_INPUT_READ)

            allows = _allow_receipts(state_dir)
            assert allows, "Need at least one allow receipt to tamper with"

            # Find the file on disk for the first allow receipt
            receipts_path = Path(state_dir) / "receipts"
            receipt_files = list(receipts_path.glob("TR-*.json"))
            allow_files = [
                f for f in receipt_files
                if json.loads(f.read_text())["type"] == "SignedActionReceipt"
            ]
            assert allow_files, "No allow receipt file found on disk"
            target_file = allow_files[0]

            # Tamper: inject a forged outcome into the receipt body
            data = json.loads(target_file.read_text(encoding="utf-8"))
            # Mutate the decision outcome — receipt signature will no longer match
            data["decision"]["outcome"] = "allow_forged"
            # Also corrupt the inner receipt execution_status
            data["receipt"]["execution_status"] = "forged"
            target_file.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

            # Build key cache from session files
            sessions_dir = Path(state_dir) / "sessions"
            key_cache = _load_session_key_cache(sessions_dir)

            # Reload the tampered file and verify
            tampered_data = json.loads(target_file.read_text(encoding="utf-8"))
            status = _verify_receipt(tampered_data, key_cache)
            assert status == "✗", (
                f"Tampered receipt should fail verification ('✗'), got {status!r}"
            )
