"""
test_learning_wiring.py — Integration tests for Client ↔ ReceiptEngine wiring.

Verifies that the receipt engine is correctly threaded through the SDK:
  - receipts are written to the engine after every governed action
  - receipt fields carry the right governance metadata
  - inject string lands in intent metadata once patterns form
  - prior_pattern appears on decision responses after receipts accumulate
  - engine is disabled by default (no learning overhead unless opted in)
  - denied actions still produce receipts (even though they raise)

These tests reveal cracks in the plumbing between Client.py, PepPolicyEngine,
and ReceiptEngine — they must pass before any benchmark claims are made.
"""

import pytest
import transient_trace

_ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}
_DENY_ALL  = {"version": 1, "defaultAction": "deny",  "rules": []}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _learning_client(tmp_path, policy=None, mode="audit", **extra):
    """Build a Client with learning enabled, isolated db in tmp_path."""
    return transient_trace.Client({
        "pepPolicy": policy or _ALLOW_ALL,
        "mode": mode,
        "state_dir": str(tmp_path),
        "learning": {
            "enabled": True,
            "distill_trigger_count": 3,   # low threshold so tests don't need 10 receipts
        },
        **extra,
    })


def _exec_input(action="write_file", action_class="filesystem", target="x"):
    return {"action": action, "action_class": action_class, "target": target}


# ---------------------------------------------------------------------------
# Engine lifecycle
# ---------------------------------------------------------------------------

class TestEngineLifecycle:

    def test_engine_disabled_by_default(self, tmp_path):
        """No receipt_engine attribute when learning not configured."""
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "state_dir": str(tmp_path),
        })
        assert client._receipt_engine is None

    def test_engine_enabled_when_configured(self, tmp_path):
        client = _learning_client(tmp_path)
        assert client._receipt_engine is not None

    def test_engine_has_zero_receipts_at_start(self, tmp_path):
        client = _learning_client(tmp_path)
        assert client._receipt_engine.stats()["total_receipts"] == 0

    def test_engine_db_created_in_state_dir(self, tmp_path):
        _learning_client(tmp_path)
        assert (tmp_path / "receipt_engine.db").exists()


# ---------------------------------------------------------------------------
# Receipt persistence — did governed actions actually write to the engine?
# ---------------------------------------------------------------------------

class TestReceiptPersistence:

    def test_single_action_writes_one_receipt(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input())
        assert client._receipt_engine.stats()["total_receipts"] == 1

    def test_multiple_actions_write_multiple_receipts(self, tmp_path):
        client = _learning_client(tmp_path)
        for _ in range(5):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        assert client._receipt_engine.stats()["total_receipts"] == 5

    def test_receipt_has_action_class(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input(action_class="filesystem"))
        receipts = client._receipt_engine.query()
        assert receipts[0]["action_class"] == "filesystem"

    def test_receipt_has_tool_name(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input(action="write_file"))
        receipts = client._receipt_engine.query()
        assert receipts[0]["tool_name"] == "write_file"

    def test_receipt_has_outcome(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input())
        receipts = client._receipt_engine.query()
        assert receipts[0]["outcome"] in ("allow", "deny", "approve", "challenge")

    def test_receipt_has_receipt_id(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input())
        receipts = client._receipt_engine.query()
        assert receipts[0].get("receipt_id") is not None

    def test_receipt_has_signature(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input())
        receipts = client._receipt_engine.query()
        assert "signature" in receipts[0]

    def test_receipt_has_timestamp(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input())
        receipts = client._receipt_engine.query()
        ts = receipts[0].get("ts")
        assert ts is not None
        assert ts > 0


# ---------------------------------------------------------------------------
# Denied actions — receipts still generated before the raise
# ---------------------------------------------------------------------------

class TestDeniedActionReceipts:

    def test_deny_in_audit_mode_still_writes_receipt(self, tmp_path):
        """In audit mode, deny outcome is recorded but action is not blocked."""
        pkg = {
            "name": "test-deny-pkg",
            "version": "1.0.0",
            "rules": [{
                "id": "deny-fs",
                "profile": "exec",
                "condition": {"action_class": "filesystem"},
                "outcome": "deny",
                "reason": "filesystem denied",
            }],
        }
        client = _learning_client(tmp_path, packages=[pkg], mode="audit")
        client.executeActionWithReceipt(lambda: "ok", _exec_input(action_class="filesystem"))
        receipts = client._receipt_engine.query()
        assert len(receipts) == 1
        # In audit mode the decision outcome is always allow, but engine stores whatever decision says
        assert receipts[0].get("action_class") == "filesystem"

    def test_deny_in_strict_mode_still_writes_receipt(self, tmp_path):
        """Even when action is blocked, receipt must be written to engine."""
        pkg = {
            "name": "test-deny-strict",
            "version": "1.0.0",
            "rules": [{
                "profile": "exec",
                "condition": {"action_class": "filesystem"},
                "outcome": "deny",
                "reason": "filesystem denied",
            }],
        }
        client = _learning_client(tmp_path, packages=[pkg], mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            client.executeActionWithReceipt(lambda: "ok", _exec_input(action_class="filesystem"))
        # Receipt MUST still be written — denial is a governance event
        receipts = client._receipt_engine.query()
        assert len(receipts) == 1
        assert receipts[0]["outcome"] == "deny"

    def test_denied_receipt_carries_rule_metadata(self, tmp_path):
        pkg = {
            "name": "rule-meta-test",
            "version": "1.0.0",
            "rules": [{
                "id": "deny-fs-rule",
                "profile": "exec",
                "condition": {"action_class": "filesystem"},
                "outcome": "deny",
                "reason": "protected path",
            }],
        }
        client = _learning_client(tmp_path, packages=[pkg], mode="audit")
        client.executeActionWithReceipt(lambda: "ok", _exec_input(action_class="filesystem"))
        receipts = client._receipt_engine.query()
        r = receipts[0]
        assert r.get("matched_rule_id") == "deny-fs-rule"
        assert r.get("matched_rule_reason") == "protected path"
        assert r.get("matched_package") == "rule-meta-test"


# ---------------------------------------------------------------------------
# prior_pattern on decision response
# ---------------------------------------------------------------------------

class TestPriorPatternOnDecision:

    def test_no_prior_pattern_on_first_action(self, tmp_path):
        """Before any receipts, prior_pattern must be absent from decision."""
        client = _learning_client(tmp_path)
        result = client.executeActionWithReceipt(lambda: "ok", _exec_input())
        assert "prior_pattern" not in result["decision"]

    def test_prior_pattern_absent_when_engine_disabled(self, tmp_path):
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "state_dir": str(tmp_path),
        })
        result = client.executeActionWithReceipt(lambda: "ok", _exec_input())
        assert "prior_pattern" not in result["decision"]

    def test_prior_pattern_appears_after_enough_receipts(self, tmp_path):
        """After distillation threshold receipts, prior_pattern appears on subsequent decisions."""
        client = _learning_client(tmp_path)
        # Write enough receipts to trigger distillation (threshold=3) and meet min_count=3
        for _ in range(5):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        # Force distillation sync
        client._receipt_engine.distill()
        # Next action should have prior_pattern
        result = client.executeActionWithReceipt(lambda: "ok", _exec_input())
        assert "prior_pattern" in result["decision"]

    def test_prior_pattern_schema(self, tmp_path):
        """prior_pattern must have all required fields."""
        client = _learning_client(tmp_path)
        for _ in range(5):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        client._receipt_engine.distill()
        result = client.executeActionWithReceipt(lambda: "ok", _exec_input())
        pp = result["decision"].get("prior_pattern")
        if pp is None:
            pytest.skip("prior_pattern not populated — distillation threshold not met")
        assert "attempts" in pp
        assert "deny_rate" in pp
        assert "confidence" in pp
        assert "recommendation" in pp
        assert "top_outcome" in pp

    def test_prior_pattern_deny_rate_reflects_outcomes(self, tmp_path):
        """deny_rate in prior_pattern must match actual deny fraction in receipts."""
        pkg = {
            "name": "deny-test",
            "version": "1.0.0",
            "rules": [{
                "profile": "exec",
                "condition": {"action_class": "filesystem"},
                "outcome": "deny",
                "reason": "test",
            }],
        }
        client = _learning_client(tmp_path, packages=[pkg], mode="audit")
        # 5 filesystem (deny recorded) + 0 other
        for _ in range(5):
            client.executeActionWithReceipt(
                lambda: "ok",
                _exec_input(action_class="filesystem"),
            )
        client._receipt_engine.distill()
        result = client.executeActionWithReceipt(
            lambda: "ok",
            _exec_input(action_class="filesystem"),
        )
        pp = result["decision"].get("prior_pattern")
        if pp is None:
            pytest.skip("prior_pattern not populated")
        # In audit mode outcome is "allow" — all receipts will show allow
        # but rule match is still recorded. Confirm deny_rate is sane float.
        assert 0.0 <= pp["deny_rate"] <= 1.0
        assert pp["attempts"] >= 5


# ---------------------------------------------------------------------------
# Inject in intent metadata
# ---------------------------------------------------------------------------

class TestInjectInIntent:

    def test_no_inject_before_patterns_form(self, tmp_path):
        """On first call with empty engine, no governance_context in intent metadata."""
        client = _learning_client(tmp_path)
        result = client.executeActionWithReceipt(lambda: "ok", _exec_input())
        metadata = result["intent"].get("metadata") or {}
        assert "governance_context" not in metadata

    def test_inject_appears_after_patterns_form(self, tmp_path):
        """After distillation, governance_context appears in intent metadata."""
        client = _learning_client(tmp_path)
        # Build up enough deny receipts to form a pattern
        pkg = {
            "name": "inject-test-pkg",
            "version": "1.0.0",
            "rules": [{
                "profile": "exec",
                "condition": {"action_class": "filesystem"},
                "outcome": "deny",
                "reason": "blocked",
            }],
        }
        client2 = _learning_client(tmp_path, packages=[pkg], mode="audit")
        for _ in range(5):
            client2.executeActionWithReceipt(
                lambda: "ok",
                _exec_input(action_class="filesystem"),
            )
        client2._receipt_engine.distill()
        result = client2.executeActionWithReceipt(
            lambda: "ok",
            _exec_input(action_class="filesystem"),
        )
        metadata = result["intent"].get("metadata") or {}
        # governance_context should now be present as inject string
        gc = metadata.get("governance_context", "")
        # If patterns formed with sufficient confidence, inject is non-empty
        # (may be empty if confidence < 0.7 threshold — that's valid)
        assert isinstance(gc, str)

    def test_inject_string_is_within_token_budget(self, tmp_path):
        """Inject string must never exceed 320 chars (~80 tokens)."""
        pkg = {
            "name": "token-budget-pkg",
            "version": "1.0.0",
            "rules": [{
                "profile": "exec",
                "condition": {"action_class": "filesystem"},
                "outcome": "deny",
                "reason": "blocked",
            }],
        }
        client = _learning_client(tmp_path, packages=[pkg], mode="audit")
        for _ in range(5):
            client.executeActionWithReceipt(
                lambda: "ok",
                _exec_input(action_class="filesystem"),
            )
        client._receipt_engine.distill()
        result = client.executeActionWithReceipt(
            lambda: "ok",
            _exec_input(action_class="filesystem"),
        )
        metadata = result["intent"].get("metadata") or {}
        gc = metadata.get("governance_context", "")
        assert len(gc) <= 320, f"Inject string too long ({len(gc)} chars): {gc!r}"


# ---------------------------------------------------------------------------
# Query from real governed actions
# ---------------------------------------------------------------------------

class TestQueryFromRealActions:

    def test_query_all_returns_stored_receipts(self, tmp_path):
        client = _learning_client(tmp_path)
        for _ in range(4):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        results = client._receipt_engine.query()
        assert len(results) == 4

    def test_query_by_outcome_allow(self, tmp_path):
        client = _learning_client(tmp_path)
        for _ in range(3):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        results = client._receipt_engine.query(outcome="allow")
        assert len(results) == 3

    def test_query_by_action_class(self, tmp_path):
        client = _learning_client(tmp_path)
        client.executeActionWithReceipt(lambda: "ok", _exec_input(action_class="filesystem"))
        client.executeActionWithReceipt(lambda: "ok", _exec_input(action_class="web"))
        fs = client._receipt_engine.query(action_class="filesystem")
        web = client._receipt_engine.query(action_class="web")
        assert len(fs) == 1
        assert len(web) == 1

    def test_explain_on_real_receipts(self, tmp_path):
        client = _learning_client(tmp_path)
        for _ in range(3):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        report = client._receipt_engine.explain()
        assert report["summary"]["total"] == 3
        assert "deny_rate" in report["summary"]
        assert "verification" in report
        assert len(report["verification"]["manifest_hash"]) == 64

    def test_export_bundle_from_real_actions(self, tmp_path):
        client = _learning_client(tmp_path)
        for _ in range(3):
            client.executeActionWithReceipt(lambda: "ok", _exec_input())
        out = tmp_path / "bundle.json"
        result = client._receipt_engine.export_bundle(path=out)
        assert out.exists()
        assert result["receipt_count"] == 3
