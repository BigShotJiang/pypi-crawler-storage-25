"""
test_governance_enforcement.py — pytest tests for the transient-trace SDK
policy enforcement layer (PEP + Client mode dispatch).

Coverage:
  - TestStrictModeEnforcement
  - TestAuditModeNeverBlocks
  - TestPermissiveModeNeverBlocks
  - TestNetworkPolicyRules
  - TestRulePrecedence
  - TestMalformedPolicy
"""
import json
import os
import tempfile

import pytest

from transient_trace.Client import Client
from transient_trace.atp.pep_policy_engine import PepPolicyEngine


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_handler(container=None):
    """Return a handler that records calls and returns {"status": "ok"}."""
    calls = container if container is not None else []

    def handler():
        calls.append(1)
        return {"status": "ok"}

    handler.calls = calls
    return handler


def _network_input(host="example.com", method="GET", path="/"):
    return {
        "action": "curl",
        "action_class": "network",
        "target": {
            "binaryPath": "/usr/bin/curl",
            "command": f"curl https://{host}{path}",
            "cwd": "/tmp",
            "host": host,
            "url": f"https://{host}{path}",
            "method": method,
            "path": path,
        },
        "metadata": {},
    }


def _exec_input(action_class="write_low"):
    return {
        "action": "write_file",
        "action_class": action_class,
        "target": {
            "binaryPath": "/usr/bin/python3",
            "command": "write_file /tmp/out.txt",
            "cwd": "/tmp",
        },
        "metadata": {},
    }


def _allow_policy(rules=None):
    return {"version": 1, "defaultAction": "allow", "rules": rules or []}


def _deny_policy(rules=None):
    return {"version": 1, "defaultAction": "deny", "rules": rules or []}


def _client(mode, policy, tmp_dir):
    return Client({"mode": mode, "pepPolicy": policy, "state_dir": tmp_dir})


# ---------------------------------------------------------------------------
# TestStrictModeEnforcement
# ---------------------------------------------------------------------------

class TestStrictModeEnforcement:

    def test_strict_blocks_when_policy_denies(self):
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("strict", _deny_policy(), tmp)
            handler = _make_handler()
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(handler, _exec_input())
            assert handler.calls == [], "handler must not be called when denied"

    def test_strict_allows_when_policy_allows(self):
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("strict", _allow_policy(), tmp)
            handler = _make_handler()
            result = client.executeActionWithReceipt(handler, _exec_input())
            assert handler.calls, "handler must be called when allowed"
            assert result["output"] == {"status": "ok"}

    def test_strict_default_deny_blocks_all_unmatched(self):
        """defaultAction:deny with no rules matches nothing — all requests blocked."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {"version": 1, "defaultAction": "deny", "rules": []}
            client = _client("strict", policy, tmp)
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(_make_handler(), _exec_input())

    def test_strict_default_allow_permits_unmatched(self):
        """defaultAction:allow with no rules — everything permitted."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {"version": 1, "defaultAction": "allow", "rules": []}
            client = _client("strict", policy, tmp)
            handler = _make_handler()
            result = client.executeActionWithReceipt(handler, _exec_input())
            assert handler.calls
            assert result["output"] == {"status": "ok"}

    def test_strict_explicit_deny_rule_overrides_default_allow(self):
        """An explicit deny rule wins even when defaultAction is allow."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "allow",
                "rules": [
                    {
                        "id": "deny-network",
                        "action": "deny",
                        "actionClasses": ["network"],
                    }
                ],
            }
            client = _client("strict", policy, tmp)
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(_make_handler(), _network_input())


# ---------------------------------------------------------------------------
# TestAuditModeNeverBlocks
# ---------------------------------------------------------------------------

class TestAuditModeNeverBlocks:

    def test_audit_never_blocks_even_with_deny_policy(self):
        """In audit mode, even a full deny policy must not raise RuntimeError."""
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("audit", _deny_policy(), tmp)
            handler = _make_handler()
            result = client.executeActionWithReceipt(handler, _exec_input())
            assert handler.calls, "handler must be called in audit mode"
            assert result["output"] == {"status": "ok"}

    def test_audit_records_would_be_deny(self):
        """In audit mode, reason_code must signal the governance intent."""
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("audit", _deny_policy(), tmp)
            result = client.executeActionWithReceipt(_make_handler(), _exec_input())
            reason_code = result["decision"]["reason_code"]
            assert "would_be_deny" in reason_code, (
                f"audit mode should record would_be_deny in reason_code, got: {reason_code!r}"
            )
            assert "audit:" in reason_code, (
                f"reason_code should be prefixed with 'audit:', got: {reason_code!r}"
            )

    def test_audit_is_default_mode(self):
        """When no mode is specified the SDK defaults to strict (Client default is 'strict').
        Verify that passing mode=audit explicitly behaves as audit — handler always called."""
        with tempfile.TemporaryDirectory() as tmp:
            # Omitting mode key should default to "strict" per Client_init source,
            # but audit mode must never block — this test verifies audit contract.
            client = _client("audit", _deny_policy(), tmp)
            handler = _make_handler()
            # Must not raise
            client.executeActionWithReceipt(handler, _exec_input())
            assert handler.calls


# ---------------------------------------------------------------------------
# TestPermissiveModeNeverBlocks
# ---------------------------------------------------------------------------

class TestPermissiveModeNeverBlocks:

    def test_permissive_never_blocks(self):
        """permissive mode: deny policy must not raise RuntimeError."""
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("permissive", _deny_policy(), tmp)
            handler = _make_handler()
            result = client.executeActionWithReceipt(handler, _exec_input())
            assert handler.calls
            assert result["output"] == {"status": "ok"}

    def test_permissive_reason_code_signals_governance_intent(self):
        """permissive mode reason_code should contain would_be_deny when policy denies."""
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("permissive", _deny_policy(), tmp)
            result = client.executeActionWithReceipt(_make_handler(), _exec_input())
            rc = result["decision"]["reason_code"]
            assert "would_be_deny" in rc, f"expected would_be_deny in reason_code, got: {rc!r}"


# ---------------------------------------------------------------------------
# TestNetworkPolicyRules
# ---------------------------------------------------------------------------

class TestNetworkPolicyRules:

    def test_network_action_class_routes_to_egress_pep(self):
        """action_class=network must be evaluated by the egress PEP.

        Confirmed by reason_code containing 'policy_rule' or 'policy_default'
        (egress PEP returns these) rather than 'non_governed'.
        """
        with tempfile.TemporaryDirectory() as tmp:
            policy = _allow_policy()
            client = _client("strict", policy, tmp)
            result = client.executeActionWithReceipt(_make_handler(), _network_input())
            rc = result["decision"]["reason_code"]
            assert rc in ("policy_rule:allow-all", "policy_default") or rc.startswith("policy_"), (
                f"network action should route to egress PEP, got reason_code: {rc!r}"
            )

    def test_host_allowlist_allows_matching_host(self):
        """An allow rule matching the exact host permits the request."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "deny",
                "rules": [
                    {
                        "id": "allow-anthropic",
                        "action": "allow",
                        "actionClasses": ["network"],
                        "hosts": ["api.anthropic.com"],
                    }
                ],
            }
            client = _client("strict", policy, tmp)
            handler = _make_handler()
            result = client.executeActionWithReceipt(
                handler, _network_input(host="api.anthropic.com")
            )
            assert handler.calls
            assert result["output"] == {"status": "ok"}

    def test_host_allowlist_blocks_non_matching_host(self):
        """A deny-default policy with an allowlist for one host blocks other hosts."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "deny",
                "rules": [
                    {
                        "id": "allow-anthropic",
                        "action": "allow",
                        "actionClasses": ["network"],
                        "hosts": ["api.anthropic.com"],
                    }
                ],
            }
            client = _client("strict", policy, tmp)
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="example.com")
                )

    def test_host_wildcard_matches(self):
        """Wildcard hosts: *.anthropic.com should allow api.anthropic.com but block evil.com."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "deny",
                "rules": [
                    {
                        "id": "allow-anthropic-wildcard",
                        "action": "allow",
                        "actionClasses": ["network"],
                        "hosts": ["*.anthropic.com"],
                    }
                ],
            }
            client = _client("strict", policy, tmp)

            # Matching wildcard — allowed
            handler = _make_handler()
            result = client.executeActionWithReceipt(
                handler, _network_input(host="api.anthropic.com")
            )
            assert handler.calls
            assert result["output"] == {"status": "ok"}

            # Non-matching — blocked
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="evil.com")
                )

    def test_network_block_all_with_deny_default(self):
        """defaultAction:deny with no rules blocks every network request."""
        with tempfile.TemporaryDirectory() as tmp:
            client = _client("strict", _deny_policy(), tmp)
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="localhost")
                )

    def test_network_allow_only_specific_host(self):
        """Complex policy: only one specific host allowed, all others blocked."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "deny",
                "rules": [
                    {
                        "id": "allow-git",
                        "action": "allow",
                        "actionClasses": ["network"],
                        "hosts": ["github.com"],
                    }
                ],
            }
            client = _client("strict", policy, tmp)

            # github.com allowed
            handler = _make_handler()
            client.executeActionWithReceipt(handler, _network_input(host="github.com"))
            assert handler.calls

            # other hosts blocked
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="evil.example.com")
                )


# ---------------------------------------------------------------------------
# TestRulePrecedence
# ---------------------------------------------------------------------------

class TestRulePrecedence:

    def test_most_specific_rule_wins(self):
        """When two rules match the same request, the one with higher priority action wins.

        Rule ordering: allow rule listed first, deny rule second.
        policy_evaluator breaks on first deny (priority 3) it encounters so
        a deny rule that matches should beat a preceding allow rule.
        """
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "allow",
                "rules": [
                    {
                        "id": "allow-network",
                        "action": "allow",
                        "actionClasses": ["network"],
                    },
                    {
                        "id": "deny-evil",
                        "action": "deny",
                        "actionClasses": ["network"],
                        "hosts": ["evil.com"],
                    },
                ],
            }
            client = _client("strict", policy, tmp)

            # evil.com matches both rules; deny (priority 3) must win
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="evil.com")
                )

            # safe.com only matches the allow rule
            handler = _make_handler()
            result = client.executeActionWithReceipt(
                handler, _network_input(host="safe.com")
            )
            assert handler.calls

    def test_deny_beats_allow_same_specificity(self):
        """Deny always beats allow at equal specificity (priority dict: deny=3, allow=1)."""
        with tempfile.TemporaryDirectory() as tmp:
            policy = {
                "version": 1,
                "defaultAction": "allow",
                "rules": [
                    # Both rules match action_class=network with same host.
                    # Deny should win due to higher priority.
                    {"id": "allow-rule", "action": "allow", "hosts": ["contested.example.com"]},
                    {"id": "deny-rule", "action": "deny", "hosts": ["contested.example.com"]},
                ],
            }
            client = _client("strict", policy, tmp)
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="contested.example.com")
                )


# ---------------------------------------------------------------------------
# TestMalformedPolicy
# ---------------------------------------------------------------------------

class TestMalformedPolicy:

    def test_empty_policy_dict_fails_closed(self):
        """An empty dict as policy is falsy, so _load_policy falls back to the project
        .atp/policy.json (or deny-all if absent).  The engine must not crash.

        This test verifies the no-crash contract and that a well-formed deny policy
        passed directly is honoured.  It also verifies that passing policy={} does not
        produce an exception — the SDK safely falls back to the ambient policy file.
        """
        # {} is falsy → _load_policy picks up .atp/policy.json or deny-all; must not crash.
        engine = PepPolicyEngine(config={}, policy={}, mode="strict")
        intent_net = {
            "intent_id": "test-intent-001",
            "actor_id": "agent-test",
            "connector": "transient-trace-sdk",
            "action": "curl",
            "action_class": "network",
            "target": {"host": "example.com", "method": "GET", "path": "/"},
            "context": {"sessionId": "s1", "runId": "r1"},
            "governance_profile": "sandbox_autonomous",
            "requested_at": "2026-04-13T00:00:00Z",
            "metadata": {"action_type": "network"},
        }
        # Must not raise — any outcome (allow or deny) is acceptable here;
        # the important contract is that no exception is thrown.
        decision = engine.requestDecision(intent_net)
        assert decision["outcome"] in ("allow", "deny"), (
            f"empty policy must not crash, outcome must be allow or deny, got: {decision}"
        )

        # Separately verify: when an explicit deny policy is provided (non-falsy),
        # the engine must use it and deny the network request.
        deny_engine = PepPolicyEngine(
            config={},
            policy={"version": 1, "defaultAction": "deny", "rules": []},
            mode="strict",
        )
        deny_decision = deny_engine.requestDecision(intent_net)
        assert deny_decision["outcome"] == "deny", (
            f"explicit deny policy must block network request, got: {deny_decision}"
        )

    def test_missing_version_field(self):
        """Policy without 'version' should still evaluate (shape validator flags it,
        but the engine must not crash and must apply defaultAction)."""
        with tempfile.TemporaryDirectory() as tmp:
            policy_no_version = {"defaultAction": "allow", "rules": []}
            engine = PepPolicyEngine(config={}, policy=policy_no_version, mode="strict")
            intent = {
                "intent_id": "test-intent-002",
                "actor_id": "agent-test",
                "connector": "transient-trace-sdk",
                "action": "read_file",
                "action_class": "read",
                "target": {"id": "/tmp/data.txt"},
                "context": {"sessionId": "s2", "runId": "r2"},
                "governance_profile": "sandbox_autonomous",
                "requested_at": "2026-04-13T00:00:00Z",
            }
            # Must not raise; defaultAction:allow → allow outcome
            decision = engine.requestDecision(intent)
            assert decision["outcome"] == "allow", (
                f"policy without version but defaultAction=allow should allow, got: {decision}"
            )

    def test_invalid_json_policy_env_var(self, monkeypatch):
        """TRANSIENT_TRACE_POLICY_JSON=not-json must not crash the Client.

        The SDK logs a warning and falls back to the config-supplied policy (pepPolicy key).
        When pepPolicy is explicitly set to a deny policy in the config, that policy is
        used after the malformed env override is discarded.
        """
        with tempfile.TemporaryDirectory() as tmp:
            monkeypatch.setenv("TRANSIENT_TRACE_POLICY_JSON", "not-json")
            # Provide an explicit deny policy in config so behaviour is deterministic
            # regardless of any ambient .atp/policy.json.
            client = Client({
                "mode": "strict",
                "pepPolicy": {"version": 1, "defaultAction": "deny", "rules": []},
                "state_dir": tmp,
            })
            # After discarding the malformed env var, the config deny policy is used.
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="example.com")
                )

    def test_none_policy_uses_deny_all_default(self):
        """When pepPolicy is explicitly set to a deny-all dict, requests are blocked.

        _load_policy treats a falsy policy arg (None / {}) as "not provided" and falls back
        to .atp/policy.json or deny-all.  To test deny-all behaviour deterministically, we
        pass the deny-all dict directly — it is truthy so _load_policy uses it as-is.
        """
        with tempfile.TemporaryDirectory() as tmp:
            # Pass deny-all dict explicitly — truthy, so used directly by _load_policy.
            client = Client({
                "mode": "strict",
                "pepPolicy": {"version": 1, "defaultAction": "deny", "rules": []},
                "state_dir": tmp,
            })
            with pytest.raises(RuntimeError, match="Denied"):
                client.executeActionWithReceipt(
                    _make_handler(), _network_input(host="example.com")
                )
