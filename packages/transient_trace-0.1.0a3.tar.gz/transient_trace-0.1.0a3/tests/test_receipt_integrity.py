"""
test_receipt_integrity.py — Tests for receipt storage, filtering, and CLI summary functions.

Covers:
  - _load_receipt_files: reading TR-*.json files from state_dir/receipts/
  - _parse_receipt_ts: timestamp extraction from receipt dicts
  - _verify_receipt: Ed25519 signature verification
  - _load_session_key_cache: public key loading from session receipts
  - cmd_receipts_summary: aggregate stats computed from JSON files
"""
from __future__ import annotations

import json
import time
import tempfile
from pathlib import Path

import pytest

from transient_trace import Client
from transient_trace.atp.id_generator import generateReceiptId
from transient_trace.cli import (
    _load_receipt_files,
    _load_session_key_cache,
    _parse_receipt_ts,
    _verify_receipt,
)

# ── Policies ──────────────────────────────────────────────────────────────────

ALLOW_POLICY = {"version": 1, "defaultAction": "allow", "rules": []}
DENY_POLICY  = {"version": 1, "defaultAction": "deny",  "rules": []}


def _allow_client(state_dir: Path):
    return Client({"pepPolicy": ALLOW_POLICY, "mode": "strict", "state_dir": str(state_dir)})


def _deny_client(state_dir: Path):
    return Client({"pepPolicy": DENY_POLICY, "mode": "strict", "state_dir": str(state_dir)})


def _run_allow_action(client, action_class: str = "write_low", action: str = "executeAction"):
    """Execute a trivial allowed action and return the result dict."""
    return client.executeActionWithReceipt(
        lambda: {"ok": True},
        {"action": action, "action_class": action_class, "target": "test-target"},
    )


def _run_deny_action(client, action_class: str = "write_low", action: str = "executeAction"):
    """Attempt an action expected to be denied; swallow the RuntimeError."""
    with pytest.raises(RuntimeError, match="Denied"):
        client.executeActionWithReceipt(
            lambda: {},
            {"action": action, "action_class": action_class, "target": "test-target"},
        )


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestReceiptFileLoading
# ═══════════════════════════════════════════════════════════════════════════════

class TestReceiptFileLoading:

    def test_allow_receipt_appears_in_load(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            client = _allow_client(state_dir)
            _run_allow_action(client)

            receipts = _load_receipt_files(state_dir, limit=100)
            assert len(receipts) >= 1
            types = [r.get("type") for r in receipts]
            assert "SignedActionReceipt" in types

    def test_deny_event_appears_in_load(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            client = _deny_client(state_dir)
            _run_deny_action(client)

            receipts = _load_receipt_files(state_dir, limit=100)
            assert len(receipts) >= 1
            types = [r.get("type") for r in receipts]
            assert "GovernanceDenyEvent" in types

    def test_outcome_filter_allow(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)

            # one allow
            allow_client = _allow_client(state_dir)
            _run_allow_action(allow_client)

            # one deny
            deny_client = _deny_client(state_dir)
            _run_deny_action(deny_client)

            results = _load_receipt_files(state_dir, limit=100, outcome="allow")
            assert len(results) >= 1
            for r in results:
                assert r.get("decision", {}).get("outcome") == "allow"

    def test_outcome_filter_deny(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)

            # one allow
            allow_client = _allow_client(state_dir)
            _run_allow_action(allow_client)

            # one deny
            deny_client = _deny_client(state_dir)
            _run_deny_action(deny_client)

            results = _load_receipt_files(state_dir, limit=100, outcome="deny")
            assert len(results) >= 1
            for r in results:
                assert r.get("decision", {}).get("outcome") == "deny"

    def test_action_class_filter(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            client = _allow_client(state_dir)

            _run_allow_action(client, action_class="network", action="curl")
            _run_allow_action(client, action_class="write_low", action="git")

            network_results = _load_receipt_files(state_dir, limit=100, action_class="network")
            assert len(network_results) >= 1
            for r in network_results:
                assert r.get("intent", {}).get("action_class") == "network"

    def test_run_id_filter(self, monkeypatch):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)

            # Client A in run_alpha
            monkeypatch.setenv("TRANSIENT_TRACE_RUN_ID", "run_alpha")
            client_a = _allow_client(state_dir)
            _run_allow_action(client_a, action="alpha_action")

            # Client B in run_beta
            monkeypatch.setenv("TRANSIENT_TRACE_RUN_ID", "run_beta")
            client_b = _allow_client(state_dir)
            _run_allow_action(client_b, action="beta_action")

            alpha_receipts = _load_receipt_files(state_dir, limit=100, run_id="run_alpha")
            beta_receipts  = _load_receipt_files(state_dir, limit=100, run_id="run_beta")

            assert len(alpha_receipts) >= 1
            assert len(beta_receipts) >= 1

            for r in alpha_receipts:
                ctx = r.get("intent", {}).get("context", {})
                assert ctx.get("runId") == "run_alpha" or ctx.get("parentRunId") == "run_alpha"

            for r in beta_receipts:
                ctx = r.get("intent", {}).get("context", {})
                assert ctx.get("runId") == "run_beta" or ctx.get("parentRunId") == "run_beta"

    def test_limit_respected(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            client = _allow_client(state_dir)

            for i in range(5):
                _run_allow_action(client, action=f"action_{i}")

            results = _load_receipt_files(state_dir, limit=2)
            assert len(results) == 2

    def test_since_ts_filter(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            client = _allow_client(state_dir)
            _run_allow_action(client)

            # since_ts set to far future — nothing should match
            future_ts = time.time() + 3600
            results = _load_receipt_files(state_dir, limit=100, since_ts=future_ts)
            assert results == []

    def test_empty_dir_returns_empty_list(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td) / "nonexistent_subdir"
            results = _load_receipt_files(state_dir, limit=100)
            assert results == []


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestReceiptTimestampParsing
# ═══════════════════════════════════════════════════════════════════════════════

class TestReceiptTimestampParsing:

    def test_parse_ts_from_captured_at(self):
        receipt_dict = {
            "type": "SignedActionReceipt",
            "receipt": {
                "captured_at": "2026-04-13T12:00:00Z",
            },
        }
        ts = _parse_receipt_ts(receipt_dict)
        assert isinstance(ts, float)
        assert ts > 0
        # 2026-04-13T12:00:00Z → 1776254400.0
        assert abs(ts - 1776081600.0) < 2

    def test_parse_ts_from_created_at(self):
        # GovernanceDenyEvent stores timestamp at top level as created_at
        receipt_dict = {
            "type": "GovernanceDenyEvent",
            "created_at": "2026-04-13T12:00:00Z",
            "receipt": {
                "receipt_id": "TR-fake",
                "outcome": "deny",
            },
        }
        ts = _parse_receipt_ts(receipt_dict)
        assert isinstance(ts, float)
        assert ts > 0
        assert abs(ts - 1776081600.0) < 2

    def test_parse_ts_returns_zero_for_missing(self):
        receipt_dict = {
            "type": "SignedActionReceipt",
            "receipt": {},
        }
        ts = _parse_receipt_ts(receipt_dict)
        assert ts == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestReceiptSummaryLogic
# ═══════════════════════════════════════════════════════════════════════════════

class TestReceiptSummaryLogic:
    """
    Tests for the aggregate statistics computed by cmd_receipts_summary.

    We drive the logic directly through _load_receipt_files + manual aggregation
    rather than calling cmd_receipts_summary (which requires argparse Namespace
    and writes to stdout). This way we validate the underlying data pipeline.
    """

    def _summary_from_items(self, items: list[dict]) -> dict:
        """Replicate the core aggregation logic from cmd_receipts_summary."""
        from collections import Counter
        outcomes = Counter()
        denied_actions = []

        for item in items:
            intent   = item.get("intent", {})
            decision = item.get("decision", {})
            receipt  = item.get("receipt", {})
            outcome  = decision.get("outcome", "unknown")
            outcomes[outcome] += 1
            if outcome == "deny":
                denied_actions.append({
                    "receipt_id":   receipt.get("receipt_id"),
                    "action":       intent.get("action"),
                    "action_class": intent.get("action_class"),
                    "rule_id":      decision.get("matched_rule_id"),
                    "reason":       decision.get("reason_code"),
                })

        total      = len(items)
        deny_count = outcomes.get("deny", 0)
        deny_rate  = deny_count / total if total else 0.0
        return {
            "total":          total,
            "outcomes":       dict(outcomes),
            "deny_rate":      deny_rate,
            "denied_actions": denied_actions,
        }

    def test_summary_counts_correctly(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)

            allow_client = _allow_client(state_dir)
            for _ in range(3):
                _run_allow_action(allow_client)

            deny_client = _deny_client(state_dir)
            _run_deny_action(deny_client)

            items = _load_receipt_files(state_dir, limit=1000)
            summary = self._summary_from_items(items)

            assert summary["total"] == 4
            assert summary["outcomes"].get("allow", 0) == 3
            assert summary["outcomes"].get("deny",  0) == 1
            assert abs(summary["deny_rate"] - 0.25) < 1e-9

    def test_summary_denied_actions_populated(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            deny_client = _deny_client(state_dir)
            _run_deny_action(deny_client, action="blocked_tool")

            items   = _load_receipt_files(state_dir, limit=1000)
            summary = self._summary_from_items(items)

            assert len(summary["denied_actions"]) >= 1
            denied = summary["denied_actions"][0]
            assert denied["action"] == "blocked_tool"
            # reason_code should be populated by the deny decision
            assert denied["reason"] is not None

    def test_summary_run_id_scoping(self, monkeypatch):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)

            monkeypatch.setenv("TRANSIENT_TRACE_RUN_ID", "run_scoped")
            scoped_client = _allow_client(state_dir)
            _run_allow_action(scoped_client, action="scoped_action")

            monkeypatch.setenv("TRANSIENT_TRACE_RUN_ID", "run_other")
            other_client = _allow_client(state_dir)
            for _ in range(2):
                _run_allow_action(other_client, action="other_action")

            scoped_items = _load_receipt_files(state_dir, limit=1000, run_id="run_scoped")
            summary = self._summary_from_items(scoped_items)

            # Only the 1 scoped action should be counted
            assert summary["total"] == 1
            assert summary["outcomes"].get("allow", 0) == 1
