from transient_trace.context import detectEnvironment


def test_detect_environment_required_fields() -> None:
    ctx = detectEnvironment()
    for key in (
        "framework",
        "runtime",
        "sessionId",
        "runId",
        "agentId",
        "sessionStartedAt",
        "sdkVersion",
        "containerized",
    ):
        assert key in ctx


def test_session_and_run_id_prefixes() -> None:
    ctx = detectEnvironment()
    assert ctx["sessionId"].startswith("sess_")
    assert ctx["runId"].startswith("run_")
