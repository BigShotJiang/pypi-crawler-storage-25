import hashlib
import json

from nacl.signing import VerifyKey

from transient_trace.Client import Client_init
from transient_trace.canonical import canonicalizeDeep


def _verify_receipt(receipt: dict) -> bool:
    env = receipt["environment"]
    env_data = json.dumps(
        {
            "sessionId": env["sessionId"],
            "runId": env["runId"],
            "framework": env["framework"],
            "runtime": env["runtime"],
            "agentId": env["agentId"],
            "sessionStartedAt": env["sessionStartedAt"],
            "sdkVersion": env["sdkVersion"],
            "containerized": env["containerized"],
        },
        separators=(",", ":"),
    )
    expected_fingerprint = hashlib.sha256(env_data.encode("utf-8")).hexdigest()
    if receipt["environmentFingerprint"] != expected_fingerprint:
        return False

    payload = {
        "version": receipt["version"],
        "project": receipt["project"],
        "protocol": receipt["protocol"],
        "environment": receipt["environment"],
        "challengeState": receipt.get("challengeState", ""),
        "constructedAt": receipt["constructedAt"],
        "environmentFingerprint": receipt["environmentFingerprint"],
    }
    canonical = json.dumps(canonicalizeDeep(payload), separators=(",", ":"), ensure_ascii=False)
    VerifyKey(bytes.fromhex(receipt["signingPublicKey"])).verify(
        canonical.encode("utf-8"), bytes.fromhex(receipt["signature"])
    )
    return True


def test_client_receipt_verifies() -> None:
    client = Client_init({"agentId": "test-agent"})
    assert _verify_receipt(client.getSignedReceipt()) is True


def test_rebuild_rotates_signature() -> None:
    client = Client_init({"agentId": "test-agent"})
    r1 = client.getSignedReceipt()
    r2 = client.rebuild({"challengeState": "new-state"})
    assert r1["environment"]["sessionId"] == r2["environment"]["sessionId"]
    assert r1["signature"] != r2["signature"]
    assert _verify_receipt(r1) is True
    assert _verify_receipt(r2) is True
