import time

from nacl.signing import VerifyKey

from transient_trace.keys import KeyManager


def test_key_manager_ttl_behavior() -> None:
    km = KeyManager({"keyTtlSeconds": 1})
    assert km.hasValidKey is False
    key = km.generateKey()
    assert km.hasValidKey is True
    assert key["publicKey"]
    time.sleep(1.1)
    assert km.hasValidKey is False


def test_key_manager_signature_is_ed25519_verifiable() -> None:
    km = KeyManager({"keyTtlSeconds": 5})
    key = km.generateKey()
    message = b"hello-atp"
    sig1 = km.sign(message)
    sig2 = km.sign(message)
    assert len(sig1) == 64
    assert sig1 == sig2
    VerifyKey(key["publicKey"]).verify(message, sig1)


def test_key_manager_cache_isolation_between_instances() -> None:
    km1 = KeyManager({"keyTtlSeconds": 10})
    km2 = KeyManager({"keyTtlSeconds": 10})
    k1 = km1.generateKey()
    k2 = km2.generateKey()
    assert k1["publicKey"] != k2["publicKey"]
    km1.clear()
    assert km1.hasValidKey is False
    assert km2.hasValidKey is True
