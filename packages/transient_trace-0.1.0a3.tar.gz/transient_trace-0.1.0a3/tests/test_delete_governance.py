"""
Tests for delete operation governance — the full chain from Client intent
creation through PEP exec decision, policy matching, and receipt generation.

ATP alignment notes:
- action_class is a free string per intent.schema.json (no enum constraint)
- target must be an object per intent.schema.json "type": "object"
- metadata is optional, max 20 properties
- delete is treated as action_class="delete" with automatic riskTier="critical"
"""
import pytest
from transient_trace import Client_init
from transient_trace.atp.pep_exec import createExecPep
from transient_trace.atp.policy_evaluator import evaluatePolicy

ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}
DENY_ALL  = {"version": 1, "defaultAction": "deny",  "rules": []}

ALLOW_ALL_POLICY = {
    "version": 1,
    "defaultAction": "allow",
    "rules": [{"id": "allow-all", "action": "allow"}],
}


# ── Intent creation ───────────────────────────────────────────────────────────

class TestDeleteIntent:
    """Client._create_intent() behaviour for delete action_class."""

    def _client(self):
        return Client_init({"agentId": "test-agent", "policy": ALLOW_ALL_POLICY})

    def test_target_string_normalised_to_object(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: {"ok": True},
            {"target": "/tmp/file.txt", "action_class": "delete"},
        )
        intent = result["intent"]
        assert isinstance(intent["target"], dict), "target must be an object per ATP spec"
        assert intent["target"]["id"] == "/tmp/file.txt"

    def test_target_object_preserved(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: {"ok": True},
            {"target": {"id": "/tmp/dir", "type": "directory"}, "action_class": "delete"},
        )
        assert result["intent"]["target"]["id"] == "/tmp/dir"
        assert result["intent"]["target"]["type"] == "directory"

    def test_delete_sets_operation_in_target(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: None,
            {"target": "/tmp/x", "action_class": "delete"},
        )
        assert result["intent"]["target"].get("operation") == "delete"

    def test_delete_metadata_populated(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: None,
            {"target": "/tmp/x", "action_class": "delete", "paths": ["/tmp/x", "/tmp/y"], "recursive": True},
        )
        meta = result["intent"].get("metadata", {})
        assert meta.get("action_class") == "delete"
        assert "/tmp/x" in meta.get("paths", [])
        assert "/tmp/y" in meta.get("paths", [])
        assert meta.get("recursive") is True

    def test_non_delete_has_no_metadata(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: {"data": "x"},
            {"target": "resource-1", "action_class": "write_low"},
        )
        assert "metadata" not in result["intent"]

    def test_delete_receipt_signed_and_valid(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: {"deleted": True},
            {"target": "/tmp/old-file.txt", "action_class": "delete"},
        )
        receipt = result["receipt"]
        sig = receipt["signature"]
        assert sig["alg"] == "Ed25519"
        assert sig["canonicalization"] == "RFC8785-JCS"
        assert receipt["execution_status"] == "executed"

    def test_delete_action_class_in_intent(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: None,
            {"target": "/var/data", "action_class": "delete"},
        )
        assert result["intent"]["action_class"] == "delete"


# ── PEP exec: delete risk elevation ──────────────────────────────────────────

class TestDeletePepExec:
    """delete action_class must never bypass the token gate in strict mode."""

    def _mint(self, secret, tool, run="run-1", session="sess-1"):
        from transient_trace.atp.decision_token_engine import createDecisionTokenEngine
        engine = createDecisionTokenEngine({"secret": secret})
        return engine["mintToken"]({"runId": run, "sessionId": session, "toolName": tool, "scope": "exec_command"})

    def test_delete_always_critical_risk_in_strict_mode(self):
        """action_class=delete must block in strict mode without a token."""
        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "strict", "decisionTokenSecret": "s3cr3t"},
        })
        # No criticalToolNames, but action_class=delete should still block
        result = pep["evaluate"]({
            "runId": "r1", "sessionId": "s1", "toolName": "bash",
            "riskTier": "read",       # caller says read — should be overridden to critical
            "action_class": "delete",
            "command": "rm -rf /tmp/old",
        })
        assert result["ok"] is False
        assert "token" in result["reason"]

    def test_delete_with_valid_token_allowed(self):
        secret = "s3cr3t"
        token = self._mint(secret, "bash")
        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "strict", "decisionTokenSecret": secret},
        })
        result = pep["evaluate"]({
            "runId": "run-1", "sessionId": "sess-1", "toolName": "bash",
            "action_class": "delete", "command": "rm /tmp/x", "decisionToken": token,
        })
        assert result["ok"] is True

    def test_delete_in_observe_mode_allowed_without_token(self):
        """Observe mode still lets non-strict deletes through (monitoring only)."""
        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "observe"},
        })
        result = pep["evaluate"]({
            "runId": "r1", "sessionId": "s1", "toolName": "bash",
            "action_class": "delete", "command": "rm -rf /tmp/stale",
        })
        assert result["ok"] is True

    def test_delete_denied_by_deny_all_policy(self):
        pep = createExecPep({"policy": DENY_ALL})
        result = pep["evaluate"]({
            "runId": "r1", "sessionId": "s1", "toolName": "bash",
            "action_class": "delete", "command": "rm /var/x",
        })
        assert result["ok"] is False

    def test_non_delete_still_bypasses_token_when_non_governed_default_allow(self):
        """Regression: non-delete, non-critical-tool still uses allow_default_non_governed path."""
        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "strict", "decisionTokenSecret": "s3cr3t"},
        })
        result = pep["evaluate"]({
            "runId": "r1", "sessionId": "s1", "toolName": "bash",
            "riskTier": "read", "action_class": "read", "command": "ls /tmp",
        })
        assert result["ok"] is True  # allow_default_non_governed applies here


# ── Policy evaluator: actionClasses dimension ─────────────────────────────────

class TestDeletePolicyDimension:
    """Policy rules can target delete operations via actionClasses field."""

    def test_deny_delete_by_action_class(self):
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "no-delete", "action": "deny", "actionClasses": ["delete"]}],
        }
        result = evaluatePolicy(policy, {"action_class": "delete", "toolName": "bash"})
        assert result["action"] == "deny"
        assert result["matchedRuleId"] == "no-delete"

    def test_allow_read_not_affected_by_delete_rule(self):
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "no-delete", "action": "deny", "actionClasses": ["delete"]}],
        }
        result = evaluatePolicy(policy, {"action_class": "read", "toolName": "bash"})
        assert result["action"] == "allow"

    def test_challenge_delete_with_wildcard(self):
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "ch-delete", "action": "challenge", "actionClasses": ["delete", "bulk_export"]}],
        }
        result = evaluatePolicy(policy, {"action_class": "bulk_export", "toolName": "python"})
        assert result["action"] == "challenge"

    def test_delete_combined_with_tool_filter(self):
        """Only block rm (not bash) from deleting."""
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "rm-delete-block", "action": "deny", "toolNames": ["rm"], "actionClasses": ["delete"]}],
        }
        blocked = evaluatePolicy(policy, {"action_class": "delete", "toolName": "rm"})
        allowed = evaluatePolicy(policy, {"action_class": "delete", "toolName": "bash"})
        assert blocked["action"] == "deny"
        assert allowed["action"] == "allow"

    def test_no_action_class_filter_matches_all(self):
        """A rule with no actionClasses constraint matches any action_class."""
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "deny-all-actions", "action": "deny", "toolNames": ["rm"]}],
        }
        result = evaluatePolicy(policy, {"action_class": "delete", "toolName": "rm"})
        assert result["action"] == "deny"

    def test_all_action_class_values_are_distinct(self):
        """Verify the ActionClass taxonomy is internally consistent."""
        from transient_trace.types_atp import ActionClass
        # ActionClass is a Literal — accessing __args__ gives the values
        import typing
        args = typing.get_args(ActionClass)
        assert "read" in args
        assert "write_low" in args
        assert "write_high" in args
        assert "delete" in args
        assert "bulk_export" in args
        # No duplicates
        assert len(args) == len(set(args))
