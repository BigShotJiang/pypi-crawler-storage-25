"""
Tests for the approval queue — enqueue, grant, deny, state guards,
event emission, and ID isolation between instances.
"""
import pytest
from transient_trace.atp.approval_queue import createApprovalQueue, APPROVAL_QUEUE_EVENTS

BASE = {"runId": "r1", "sessionId": "s1", "toolName": "bash", "args": {"host": "api.example.com"}}


class TestEnqueue:
    def test_returns_entry_with_id(self):
        q = createApprovalQueue()
        entry = q["enqueue"](BASE)
        assert entry["id"] == "aq-1"
        assert entry["status"] == "pending"
        assert entry["toolName"] == "bash"

    def test_ids_increment(self):
        q = createApprovalQueue()
        e1 = q["enqueue"](BASE)
        e2 = q["enqueue"](BASE)
        assert e1["id"] == "aq-1"
        assert e2["id"] == "aq-2"

    def test_args_hash_is_deterministic(self):
        q = createApprovalQueue()
        e1 = q["enqueue"]({**BASE, "args": {"port": 443, "host": "a.com"}})
        e2 = q["enqueue"]({**BASE, "args": {"host": "a.com", "port": 443}})  # different key order
        assert e1["argsHash"] == e2["argsHash"]

    def test_returns_copy_not_reference(self):
        q = createApprovalQueue()
        entry = q["enqueue"](BASE)
        entry["status"] = "MUTATED"
        # Internal state should not be affected
        internal = q["getById"]("aq-1")
        assert internal["status"] == "pending"

    def test_emits_pending_event(self):
        events = []
        q = createApprovalQueue({"persistEvent": events.append})
        q["enqueue"](BASE)
        assert len(events) == 1
        assert events[0]["eventType"] == APPROVAL_QUEUE_EVENTS["PENDING"]
        assert events[0]["approvalQueueId"] == "aq-1"


class TestGrant:
    def test_grant_pending_entry(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        result = q["grant"]("aq-1")
        assert result["decision"] == "granted"
        assert result["status"] == "granted"

    def test_grant_unknown_id(self):
        q = createApprovalQueue()
        result = q["grant"]("aq-999")
        assert result["decision"] == "denied"
        assert result["reason"] == "unknown_id"

    def test_grant_already_granted(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        q["grant"]("aq-1")
        result = q["grant"]("aq-1")
        assert result["decision"] == "denied"
        assert "already_granted" in result["reason"]

    def test_grant_emits_event(self):
        events = []
        q = createApprovalQueue({"persistEvent": events.append})
        q["enqueue"](BASE)
        q["grant"]("aq-1")
        granted_events = [e for e in events if e["eventType"] == APPROVAL_QUEUE_EVENTS["GRANTED"]]
        assert len(granted_events) == 1

    def test_granted_entry_removed_from_pending(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        q["grant"]("aq-1")
        assert q["getPending"]() == []


class TestDeny:
    def test_deny_pending_entry(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        result = q["deny"]("aq-1")
        assert result["decision"] == "denied"
        assert result["status"] == "denied"

    def test_deny_with_reason(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        result = q["deny"]("aq-1", {"reason": "policy_violation"})
        assert result["denyReason"] == "policy_violation"

    def test_deny_default_reason(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        result = q["deny"]("aq-1")
        assert result["denyReason"] == "operator_denied"

    def test_deny_unknown_id(self):
        q = createApprovalQueue()
        result = q["deny"]("aq-999")
        assert result["decision"] == "denied"
        assert result["reason"] == "unknown_id"

    def test_deny_already_denied(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        q["deny"]("aq-1")
        result = q["deny"]("aq-1")
        assert "already_denied" in result["reason"]

    def test_deny_emits_event(self):
        events = []
        q = createApprovalQueue({"persistEvent": events.append})
        q["enqueue"](BASE)
        q["deny"]("aq-1")
        denied_events = [e for e in events if e["eventType"] == APPROVAL_QUEUE_EVENTS["DENIED"]]
        assert len(denied_events) == 1


class TestGetPending:
    def test_empty_initially(self):
        q = createApprovalQueue()
        assert q["getPending"]() == []

    def test_pending_after_enqueue(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        assert len(q["getPending"]()) == 1

    def test_resolved_entries_not_pending(self):
        q = createApprovalQueue()
        q["enqueue"](BASE)
        q["enqueue"]({**BASE, "toolName": "python"})
        q["grant"]("aq-1")
        pending = q["getPending"]()
        assert len(pending) == 1
        assert pending[0]["toolName"] == "python"


class TestIsolation:
    def test_two_queues_are_independent(self):
        q1 = createApprovalQueue()
        q2 = createApprovalQueue()
        q1["enqueue"](BASE)
        assert q2["getPending"]() == []
        assert q2["getById"]("aq-1") is None
