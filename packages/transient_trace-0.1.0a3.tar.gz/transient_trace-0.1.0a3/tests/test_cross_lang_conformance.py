import json
import os
import re
import subprocess
from pathlib import Path

from nacl.signing import SigningKey

from transient_trace.atp.canonicalization import canonicalizeForSigning
from transient_trace.atp.id_generator import generateDecisionId, generateIntentId, generateReceiptId
from transient_trace.atp.signer import signUnsignedReceipt
from transient_trace.atp.validator import verifyActionReceipt

# Portable path resolution
_TEST_DIR = Path(__file__).parent
_SDK = _TEST_DIR.parent.parent / 'sdk-src'

# Allow override via env var for CI/CD
SDK = Path(os.environ.get('TRANSIENT_TRACE_SDK_PATH', str(_SDK)))


def _node_eval(js: str) -> str:
    proc = subprocess.run(['node', '--input-type=module', '-e', js], capture_output=True, text=True, cwd=str(SDK), check=True)
    return proc.stdout.strip()


def test_rfc8785_canonicalization_matches_ts():
    payload = {
        "z": [3, {"b": 2, "a": 1.23}],
        "a": {"m": "x", "k": [True, False, None]},
        "unicode": "é",
    }
    py_canon = canonicalizeForSigning(payload).decode('utf-8')
    js = f"""
      import canonicalize from 'json-canon';
      const obj = {json.dumps(payload, ensure_ascii=False)};
      process.stdout.write(canonicalize(obj));
    """
    ts_canon = _node_eval(js)
    assert py_canon == ts_canon


def test_ed25519_signature_matches_ts_for_same_seed_and_payload():
    unsigned = {
        "receipt_id": "TR-1",
        "intent_id": "TI-1",
        "decision_id": "TD-1",
        "execution_status": "executed",
        "captured_at": "2026-01-01T00:00:00.002Z",
        "schemaVersion": "1.0.0",
        "occurred_at": "2026-01-01T00:00:00.000Z",
        "received_at": "2026-01-01T00:00:00.001Z",
        "sealed_at": "2026-01-01T00:00:00.002Z",
        "event_snapshot": {"action": "executeAction", "input_digest": "00"*32, "output_digest": "11"*32, "intent_id": "TI-1", "action_class": "read", "target": "x"},
        "event_snapshot_hash": "22" * 32,
        "correlation_id": "sess_test:TI-1",
    }
    seed_hex = '1f' * 32
    seed = bytes.fromhex(seed_hex)
    sk = SigningKey(seed)
    py_receipt = signUnsignedReceipt(unsigned, {"sign": lambda m: sk.sign(m).signature, "kid": "kid-1"})

    js = f"""
      import {{ ed25519 }} from '@noble/curves/ed25519.js';
      import canonicalize from 'json-canon';
      const unsigned = {json.dumps(unsigned)};
      const canonical = canonicalize(unsigned);
      const msg = new TextEncoder().encode(canonical);
      const sk = Buffer.from('{seed_hex}', 'hex');
      const sig = ed25519.sign(msg, sk);
      const b64u = Buffer.from(sig).toString('base64url');
      process.stdout.write(b64u);
    """
    ts_sig = _node_eval(js)
    assert py_receipt['signature']['sig'] == ts_sig
    assert verifyActionReceipt(py_receipt, bytes(sk.verify_key))


def test_ulid_id_generation_format():
    iid = generateIntentId()
    did = generateDecisionId()
    rid = generateReceiptId()

    assert re.match(r"^TI-[0-9A-HJKMNP-TV-Z]{26}$", iid)
    assert re.match(r"^TD-[0-9A-HJKMNP-TV-Z]{26}$", did)
    assert re.match(r"^TR-[0-9A-HJKMNP-TV-Z]{26}$", rid)


def test_python_receipt_verifies_in_ts_orchestrator_logic():
    seed = bytes.fromhex('2a' * 32)
    sk = SigningKey(seed)
    unsigned = {
        "receipt_id": "TR-9",
        "intent_id": "TI-9",
        "decision_id": "TD-9",
        "execution_status": "executed",
        "captured_at": "2026-01-01T00:00:00.002Z",
        "schemaVersion": "1.0.0",
        "occurred_at": "2026-01-01T00:00:00.000Z",
        "received_at": "2026-01-01T00:00:00.001Z",
        "sealed_at": "2026-01-01T00:00:00.002Z",
        "event_snapshot": {"action": "x", "input_digest": "00"*32, "output_digest": "11"*32, "intent_id": "TI-9", "action_class": "read", "target": "z"},
        "event_snapshot_hash": "33" * 32,
        "correlation_id": "sess_test:TI-9",
    }
    py_receipt = signUnsignedReceipt(unsigned, {"sign": lambda m: sk.sign(m).signature, "kid": "kid-1"})
    js = f"""
      import {{ verifyActionReceipt }} from './dist/atp/validator.js';
      const receipt = {json.dumps(py_receipt)};
      const pk = Buffer.from('{bytes(sk.verify_key).hex()}', 'hex');
      const ok = await verifyActionReceipt(receipt, pk);
      process.stdout.write(ok ? 'true' : 'false');
    """
    out = _node_eval(js)
    assert out == 'true'
