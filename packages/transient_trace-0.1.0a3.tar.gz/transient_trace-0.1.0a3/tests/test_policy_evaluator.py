"""
Tests for the policy evaluator — rule matching, priority, wildcards,
port matching, cwd prefix matching, and fallback behaviour.
"""
import pytest
from transient_trace.atp.policy_evaluator import evaluatePolicy, createDefaultPolicy


ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}
DENY_ALL  = {"version": 1, "defaultAction": "deny",  "rules": []}

BASE_REQ = {
    "kind": "exec",
    "toolName": "bash",
    "binaryPath": "/usr/bin/bash",
    "riskTier": "read",
    "host": "api.example.com",
    "port": 443,
    "method": "GET",
    "path": "/v1/data",
    "command": "ls /tmp",
    "cwd": "/home/user/project",
}


class TestDefaults:
    def test_no_policy_returns_deny(self):
        result = evaluatePolicy(None, BASE_REQ)
        assert result["action"] == "deny"
        assert result["matchedRuleId"] is None
        assert result["reason"] == "policy_default"

    def test_allow_all_default(self):
        result = evaluatePolicy(ALLOW_ALL, BASE_REQ)
        assert result["action"] == "allow"
        assert result["matchedRuleId"] is None

    def test_deny_all_default(self):
        result = evaluatePolicy(DENY_ALL, BASE_REQ)
        assert result["action"] == "deny"

    def test_invalid_default_action_falls_back_to_deny(self):
        result = evaluatePolicy({"version": 1, "defaultAction": "BOGUS", "rules": []}, BASE_REQ)
        assert result["action"] == "deny"

    def test_create_default_policy_is_deny_all(self):
        policy = createDefaultPolicy()
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"

    def test_no_request_uses_empty_values(self):
        result = evaluatePolicy(ALLOW_ALL, None)
        assert result["action"] == "allow"


class TestRuleMatching:
    def test_match_by_tool_name(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "r1", "action": "allow", "toolNames": ["bash"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "allow"
        assert result["matchedRuleId"] == "r1"

    def test_no_match_uses_default(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "r1", "action": "allow", "toolNames": ["python"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"
        assert result["matchedRuleId"] is None

    def test_match_by_risk_tier(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "allow-read", "action": "allow", "riskTiers": ["read"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "allow"

    def test_kind_filter_exec_vs_egress(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "egress-only", "action": "allow", "kind": "egress"}],
        }
        # Base request is kind=exec — rule doesn't match
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"
        # Egress request matches
        result2 = evaluatePolicy(policy, {**BASE_REQ, "kind": "egress"})
        assert result2["action"] == "allow"

    def test_match_by_host(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "allow-api", "action": "allow", "hosts": ["api.example.com"]}],
        }
        result = evaluatePolicy(policy, {**BASE_REQ, "kind": "egress"})
        assert result["action"] == "allow"

    def test_match_by_port(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "allow-443", "action": "allow", "ports": [443]}],
        }
        result = evaluatePolicy(policy, {**BASE_REQ, "kind": "egress"})
        assert result["action"] == "allow"

    def test_port_no_match(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "allow-8080", "action": "allow", "ports": [8080]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"

    def test_cwd_prefix_match(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "cwd-r", "action": "allow", "cwdPrefixes": ["/home/user"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "allow"

    def test_cwd_prefix_no_match(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "cwd-r", "action": "allow", "cwdPrefixes": ["/root"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"


class TestWildcards:
    def test_wildcard_tool_name(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "wc", "action": "allow", "toolNames": ["ba*"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "allow"

    def test_wildcard_host(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "wc-host", "action": "allow", "hosts": ["*.example.com"], "kind": "egress"}],
        }
        result = evaluatePolicy(policy, {**BASE_REQ, "kind": "egress"})
        assert result["action"] == "allow"

    def test_wildcard_no_match(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "wc", "action": "allow", "toolNames": ["py*"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"

    def test_case_insensitive_match(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "ci", "action": "allow", "toolNames": ["BASH"]}],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "allow"


class TestPriority:
    def test_deny_beats_allow_when_both_match(self):
        # Both rules match; deny has higher priority
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [
                {"id": "allow-r", "action": "allow", "toolNames": ["bash"]},
                {"id": "deny-r",  "action": "deny",  "toolNames": ["bash"]},
            ],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "deny"
        assert result["matchedRuleId"] == "deny-r"

    def test_challenge_between_allow_and_deny(self):
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [
                {"id": "allow-r",     "action": "allow",     "toolNames": ["bash"]},
                {"id": "challenge-r", "action": "challenge", "toolNames": ["bash"]},
            ],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["action"] == "challenge"

    def test_deny_stops_rule_scan_early(self):
        # deny rule is first; subsequent allow rule should not be evaluated
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [
                {"id": "deny-first",  "action": "deny",  "toolNames": ["bash"]},
                {"id": "allow-later", "action": "allow", "toolNames": ["bash"]},
            ],
        }
        result = evaluatePolicy(policy, BASE_REQ)
        assert result["matchedRuleId"] == "deny-first"
