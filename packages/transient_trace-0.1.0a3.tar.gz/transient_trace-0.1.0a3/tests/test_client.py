from transient_trace import init


def test_client_init_returns_trace_client() -> None:
    trace = init()
    assert trace is not None
    assert hasattr(trace, "getSignedReceipt")
    assert isinstance(trace.version, str)


def test_client_get_signed_receipt_shape() -> None:
    trace = init()
    receipt = trace.getSignedReceipt()
    assert isinstance(receipt["signature"], str)
    assert len(receipt["signature"]) > 0
    int(receipt["signature"], 16)
