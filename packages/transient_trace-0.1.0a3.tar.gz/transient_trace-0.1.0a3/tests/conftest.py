"""
conftest.py — shared pytest fixtures for the transient-trace test suite.

Autouse fixtures here apply to every test in the suite.
"""
import pytest


@pytest.fixture(autouse=True)
def _clear_operator_env_vars(monkeypatch):
    """
    Clear operator env-var overrides for every test.

    TRANSIENT_TRACE_MODE and TRANSIENT_TRACE_POLICY_JSON are designed to be
    set by operators at runtime to override agent-supplied config. When these
    are present in the shell environment they cause tests that configure mode
    or policy directly on the Client to behave unexpectedly.

    Clearing them here ensures config-level values are authoritative in tests,
    which is the correct behaviour for unit and integration tests.
    """
    monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
    monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
