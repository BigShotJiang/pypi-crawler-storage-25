"""
test_failure_modes.py — Tests for degraded, adversarial, and edge-case conditions.

Covers:
  - Invalid / empty / case-variant mode strings in Client / PepPolicyEngine
  - _load_receipt_files behaviour when state_dir or receipts/ subdir doesn't exist
  - Client auto-creation of state_dir and receipts/ on first action
  - Graceful skipping of corrupt or incomplete receipt JSON files
  - _parse_ts_arg: relative shorthand (h/m/d) and ISO datetime parsing
  - Shim fail-open behaviour and exit-126 on deny
"""
from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from transient_trace import Client
from transient_trace.atp.id_generator import generateReceiptId
from transient_trace.cli import _load_receipt_files, _parse_ts_arg

# ── Helpers ───────────────────────────────────────────────────────────────────

ALLOW_POLICY = {"version": 1, "defaultAction": "allow", "rules": []}
DENY_POLICY  = {"version": 1, "defaultAction": "deny",  "rules": []}


def _run_action(client, action: str = "executeAction"):
    return client.executeActionWithReceipt(
        lambda: {"ok": True},
        {"action": action, "action_class": "write_low", "target": "t"},
    )


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestInvalidModeHandling
# ═══════════════════════════════════════════════════════════════════════════════

class TestInvalidModeHandling:

    def test_invalid_mode_raises_value_error(self):
        with tempfile.TemporaryDirectory() as td:
            with pytest.raises(ValueError) as exc_info:
                Client({"mode": "invalid_mode", "state_dir": td})
            msg = str(exc_info.value).lower()
            # Error should mention the bad mode or list valid options
            assert "invalid_mode" in msg or "strict" in msg or "audit" in msg

    def test_empty_mode_string_raises(self):
        with tempfile.TemporaryDirectory() as td:
            # Empty string normalises to "" which is not in _VALID_MODES
            with pytest.raises(ValueError):
                Client({"mode": "", "state_dir": td})

    def test_mode_case_normalization(self):
        """
        Mode values are lower-cased internally before validation.
        "STRICT" and "Strict" should either be accepted (normalised to "strict")
        or raise a clean ValueError — never cause an unexpected crash.
        """
        with tempfile.TemporaryDirectory() as td:
            for variant in ("STRICT", "Strict", "AUDIT", "Audit"):
                try:
                    c = Client({"mode": variant, "state_dir": td})
                    # If it didn't raise, the client must be functional
                    assert hasattr(c, "executeActionWithReceipt")
                except ValueError:
                    # Clean rejection is also acceptable
                    pass
                except Exception as exc:
                    pytest.fail(
                        f"mode={variant!r} raised unexpected {type(exc).__name__}: {exc}"
                    )

    def test_valid_modes_all_accepted(self):
        with tempfile.TemporaryDirectory() as td:
            for mode in ("strict", "audit", "permissive"):
                client = Client({"mode": mode, "state_dir": td, "pepPolicy": ALLOW_POLICY})
                assert client is not None
                assert hasattr(client, "executeActionWithReceipt")


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestMissingStateDir
# ═══════════════════════════════════════════════════════════════════════════════

class TestMissingStateDir:

    def test_load_receipts_nonexistent_dir_returns_empty(self):
        with tempfile.TemporaryDirectory() as td:
            nonexistent = Path(td) / "does" / "not" / "exist"
            results = _load_receipt_files(nonexistent, limit=100)
            assert results == []

    def test_client_creates_state_dir_if_missing(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td) / "new_state_dir"
            assert not state_dir.exists()

            client = Client({"mode": "audit", "pepPolicy": ALLOW_POLICY, "state_dir": str(state_dir)})
            _run_action(client)

            # After at least one action, state_dir must exist
            assert state_dir.exists()

    def test_receipts_written_to_db_on_first_action(self):
        from transient_trace.receipt_engine.store import ReceiptStore
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td) / "fresh_state"
            client = Client({"mode": "audit", "pepPolicy": ALLOW_POLICY, "state_dir": str(state_dir)})
            _run_action(client)

            db_path = state_dir / "receipt_engine.db"
            assert db_path.exists()
            s = ReceiptStore(db_path)
            assert s.count() >= 1
            s.close()


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestCorruptReceiptHandling
# ═══════════════════════════════════════════════════════════════════════════════

class TestCorruptReceiptHandling:

    def _receipts_dir(self, state_dir: Path) -> Path:
        d = state_dir / "receipts"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def test_corrupt_json_file_skipped(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            receipts_dir = self._receipts_dir(state_dir)

            # Write one valid receipt
            valid_id = generateReceiptId()
            valid_receipt = {
                "type": "SignedActionReceipt",
                "created_at": "2026-04-13T10:00:00Z",
                "intent":   {"action": "valid_action", "action_class": "write_low", "context": {}},
                "decision": {"outcome": "allow", "reason_code": "policy_default", "decision_id": "TD-test"},
                "receipt":  {"receipt_id": valid_id, "captured_at": "2026-04-13T10:00:00Z"},
            }
            (receipts_dir / f"{valid_id}.json").write_text(
                json.dumps(valid_receipt), encoding="utf-8"
            )

            # Write one corrupt file
            corrupt_id = generateReceiptId()
            (receipts_dir / f"{corrupt_id}.json").write_text(
                "{ this is not valid json !!!!", encoding="utf-8"
            )

            # _load_receipt_files must not raise and must return the valid one
            results = _load_receipt_files(state_dir, limit=100)
            assert len(results) == 1
            assert results[0]["receipt"]["receipt_id"] == valid_id

    def test_partial_receipt_missing_decision(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            receipts_dir = self._receipts_dir(state_dir)

            rid = generateReceiptId()
            partial = {
                "type": "SignedActionReceipt",
                "created_at": "2026-04-13T10:00:00Z",
                "intent": {"action": "some_action", "action_class": "write_low", "context": {}},
                # "decision" key intentionally absent
                "receipt": {"receipt_id": rid, "captured_at": "2026-04-13T10:00:00Z"},
            }
            (receipts_dir / f"{rid}.json").write_text(json.dumps(partial), encoding="utf-8")

            results = _load_receipt_files(state_dir, limit=100)
            assert len(results) == 1
            # decision defaults to empty dict — no crash
            assert results[0].get("decision", {}) == {}

    def test_partial_receipt_missing_intent(self):
        with tempfile.TemporaryDirectory() as td:
            state_dir = Path(td)
            receipts_dir = self._receipts_dir(state_dir)

            rid = generateReceiptId()
            partial = {
                "type": "SignedActionReceipt",
                "created_at": "2026-04-13T10:00:00Z",
                # "intent" key intentionally absent
                "decision": {"outcome": "allow", "reason_code": "policy_default", "decision_id": "TD-x"},
                "receipt": {"receipt_id": rid, "captured_at": "2026-04-13T10:00:00Z"},
            }
            (receipts_dir / f"{rid}.json").write_text(json.dumps(partial), encoding="utf-8")

            # Must not crash
            results = _load_receipt_files(state_dir, limit=100)
            assert len(results) == 1
            assert results[0].get("intent", {}) == {}


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestTimestampArgParsing
# ═══════════════════════════════════════════════════════════════════════════════

class TestTimestampArgParsing:

    _TOLERANCE = 5.0  # seconds

    def test_parse_minutes(self):
        before = time.time()
        result = _parse_ts_arg("30m")
        after  = time.time()
        expected = before - 1800
        assert abs(result - expected) <= self._TOLERANCE

    def test_parse_hours(self):
        before = time.time()
        result = _parse_ts_arg("2h")
        expected = before - 7200
        assert abs(result - expected) <= self._TOLERANCE

    def test_parse_days(self):
        before = time.time()
        result = _parse_ts_arg("7d")
        expected = before - 604800
        assert abs(result - expected) <= self._TOLERANCE

    def test_parse_iso_timestamp(self):
        result = _parse_ts_arg("2026-01-01T00:00:00Z")
        # 2026-01-01T00:00:00Z
        expected = 1767225600.0
        assert abs(result - expected) < 2

    def test_parse_invalid_raises(self):
        with pytest.raises(ValueError):
            _parse_ts_arg("banana")


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS: TestShimFailOpen
# ═══════════════════════════════════════════════════════════════════════════════

class TestShimFailOpen:
    """
    Tests for the shim's fail-open safety net and exit-126 deny path.

    run_shim() wraps _run() in a try/except: if _run() raises for any reason
    (including ImportError) the shim calls _exec_real() as a fail-open path.

    _run() raises RuntimeError("Denied: …") for policy denials, which is caught
    inside _run itself and converted to sys.exit(126).
    """

    def test_shim_run_fails_open_on_import_error(self, monkeypatch, tmp_path):
        """
        If Client cannot be imported inside _run, run_shim catches the exception
        and calls _exec_real (fail-open). We patch _exec_real to avoid actually
        exec-ing anything and verify it was called.
        """
        import transient_trace._shim as _shim_mod

        exec_real_calls: list[tuple] = []

        def fake_exec_real(real_bin, argv):
            exec_real_calls.append((real_bin, argv))

        monkeypatch.setattr(_shim_mod, "_exec_real", fake_exec_real)

        # Patch Client at the package level so the import inside _run fails
        import transient_trace as _tt_pkg

        def boom(_cfg):
            raise ImportError("simulated import failure")

        monkeypatch.setattr(_tt_pkg, "Client", boom)

        # run_shim should catch the error and invoke _exec_real (fail-open)
        monkeypatch.setenv("TRANSIENT_TRACE_STATE_DIR", str(tmp_path))
        monkeypatch.setenv("TRANSIENT_TRACE_MODE", "audit")

        _shim_mod.run_shim("/usr/bin/git")

        assert len(exec_real_calls) == 1
        assert exec_real_calls[0][0] == "/usr/bin/git"

    def test_shim_exit_126_on_deny(self, monkeypatch, tmp_path):
        """
        When the Client raises RuntimeError("Denied: policy_default"),
        _run() should call sys.exit(126).
        """
        import transient_trace._shim as _shim_mod
        import transient_trace as _tt_pkg

        class DenyingClient:
            def __init__(self, cfg):
                pass

            def executeActionWithReceipt(self, handler, exec_input):
                raise RuntimeError("Denied: policy_default")

        monkeypatch.setattr(_tt_pkg, "Client", DenyingClient)
        monkeypatch.setenv("TRANSIENT_TRACE_STATE_DIR", str(tmp_path))
        monkeypatch.setenv("TRANSIENT_TRACE_MODE", "strict")

        with pytest.raises(SystemExit) as exc_info:
            _shim_mod._run("git", "/usr/bin/git", ["status"])

        assert exc_info.value.code == 126
