from nacl.signing import VerifyKey

from transient_trace.SessionReceipt import SessionReceipt
from transient_trace.canonical import canonicalizeDeep


def test_build_returns_signed_session_receipt() -> None:
    receipt = SessionReceipt()
    signed = receipt.build()
    assert isinstance(signed["signature"], str)
    assert isinstance(signed["signingPublicKey"], str)
    assert len(signed["signature"]) > 0
    assert len(signed["signingPublicKey"]) > 0


def test_signature_verifies_against_public_key() -> None:
    receipt = SessionReceipt()
    signed = receipt.build()

    payload = {
        "version": signed["version"],
        "project": signed["project"],
        "protocol": signed["protocol"],
        "environment": signed["environment"],
        "challengeState": signed.get("challengeState", ""),
        "constructedAt": signed["constructedAt"],
        "environmentFingerprint": signed["environmentFingerprint"],
    }
    canonical = canonicalizeDeep(payload)
    message = __import__("json").dumps(canonical, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    verify_key = VerifyKey(bytes.fromhex(signed["signingPublicKey"]))
    verify_key.verify(message, bytes.fromhex(signed["signature"]))
