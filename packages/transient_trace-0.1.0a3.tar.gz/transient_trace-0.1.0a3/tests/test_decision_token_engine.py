"""
Tests for the decision token engine — mint, verify, expiry,
scope/run/session/tool matching, and replay protection.
"""
import pytest
from transient_trace.atp.decision_token_engine import createDecisionTokenEngine, DecisionTokenScopes

SECRET = "test-secret-xyz"


def _engine(secret=SECRET, now_fn=None):
    cfg = {"secret": secret}
    if now_fn:
        cfg["now"] = now_fn
    return createDecisionTokenEngine(cfg)


class TestInit:
    def test_requires_secret(self):
        with pytest.raises(ValueError, match="secret"):
            createDecisionTokenEngine({"secret": ""})

    def test_requires_non_whitespace_secret(self):
        with pytest.raises(ValueError):
            createDecisionTokenEngine({"secret": "   "})


class TestMintAndVerify:
    def test_roundtrip_valid_token(self):
        engine = _engine()
        token = engine["mintToken"]({"runId": "r1", "sessionId": "s1", "toolName": "bash", "scope": "exec_command"})
        result = engine["verifyToken"](token, {"runId": "r1", "sessionId": "s1", "toolName": "bash", "scope": "exec_command"})
        assert result["ok"] is True
        assert result["code"] == "ok"
        assert result["payload"]["toolName"] == "bash"

    def test_token_has_three_parts(self):
        engine = _engine()
        token = engine["mintToken"]({"runId": "r1", "sessionId": "s1", "toolName": "bash"})
        assert token.count(".") == 2

    def test_nonce_makes_tokens_unique(self):
        engine = _engine()
        params = {"runId": "r1", "sessionId": "s1", "toolName": "bash"}
        t1 = engine["mintToken"](params)
        t2 = engine["mintToken"](params)
        assert t1 != t2

    def test_default_scope_is_critical_tool_execute(self):
        engine = _engine()
        token = engine["mintToken"]({"runId": "r1", "sessionId": "s1", "toolName": "bash"})
        result = engine["verifyToken"](token, {"scope": DecisionTokenScopes["CRITICAL_TOOL_EXECUTE"]})
        assert result["ok"] is True


class TestVerifyEdgeCases:
    def test_empty_token_rejected(self):
        engine = _engine()
        result = engine["verifyToken"]("", {})
        assert result["ok"] is False
        assert result["code"] == "token_missing"

    def test_malformed_token_rejected(self):
        engine = _engine()
        result = engine["verifyToken"]("not.a.valid", {})
        # signature won't match
        assert result["ok"] is False

    def test_wrong_signature_rejected(self):
        engine = _engine()
        token = engine["mintToken"]({"runId": "r1", "sessionId": "s1", "toolName": "bash"})
        tampered = token[:-4] + "XXXX"
        result = engine["verifyToken"](tampered, {})
        assert result["ok"] is False
        assert result["code"] == "token_signature_invalid"

    def test_wrong_secret_rejected(self):
        engine_a = _engine(secret="secret-a")
        engine_b = _engine(secret="secret-b")
        token = engine_a["mintToken"]({"runId": "r", "sessionId": "s", "toolName": "bash"})
        result = engine_b["verifyToken"](token, {})
        assert result["ok"] is False
        assert result["code"] == "token_signature_invalid"

    def test_one_extra_dot_malformed(self):
        engine = _engine()
        token = engine["mintToken"]({"runId": "r", "sessionId": "s", "toolName": "bash"})
        result = engine["verifyToken"](token + ".extra", {})
        assert result["ok"] is False


class TestExpiry:
    def test_expired_token_rejected(self):
        now_ms = [1_000_000_000_000]
        engine = _engine(now_fn=lambda: now_ms[0])
        token = engine["mintToken"]({"runId": "r", "sessionId": "s", "toolName": "t", "ttlMs": 100})
        now_ms[0] += 200   # advance past expiry
        result = engine["verifyToken"](token, {})
        assert result["ok"] is False
        assert result["code"] == "token_expired"

    def test_fresh_token_accepted(self):
        now_ms = [1_000_000_000_000]
        engine = _engine(now_fn=lambda: now_ms[0])
        token = engine["mintToken"]({"runId": "r", "sessionId": "s", "toolName": "t", "ttlMs": 60_000})
        now_ms[0] += 1_000  # 1 second later — still valid
        result = engine["verifyToken"](token, {})
        assert result["ok"] is True

    def test_exactly_expired_at_boundary(self):
        now_ms = [1_000_000_000_000]
        engine = _engine(now_fn=lambda: now_ms[0])
        token = engine["mintToken"]({"runId": "r", "sessionId": "s", "toolName": "t", "ttlMs": 100})
        now_ms[0] += 100  # exactly at expiry (>= exp)
        result = engine["verifyToken"](token, {})
        assert result["ok"] is False


class TestFieldMatching:
    def _token(self, **kwargs):
        engine = _engine()
        token = engine["mintToken"]({"runId": "run-1", "sessionId": "sess-1", "toolName": "bash", "scope": "exec_command", **kwargs})
        return engine, token

    def test_scope_mismatch(self):
        engine, token = self._token()
        result = engine["verifyToken"](token, {"scope": "egress_request"})
        assert result["ok"] is False
        assert result["code"] == "token_scope_mismatch"

    def test_run_id_mismatch(self):
        engine, token = self._token()
        result = engine["verifyToken"](token, {"runId": "WRONG"})
        assert result["ok"] is False
        assert result["code"] == "token_run_mismatch"

    def test_session_id_mismatch(self):
        engine, token = self._token()
        result = engine["verifyToken"](token, {"sessionId": "WRONG"})
        assert result["ok"] is False
        assert result["code"] == "token_session_mismatch"

    def test_tool_name_mismatch(self):
        engine, token = self._token()
        result = engine["verifyToken"](token, {"toolName": "python"})
        assert result["ok"] is False
        assert result["code"] == "token_tool_mismatch"

    def test_no_expected_fields_skips_field_checks(self):
        engine, token = self._token()
        # Empty expected — only signature and expiry checked
        result = engine["verifyToken"](token, {})
        assert result["ok"] is True
