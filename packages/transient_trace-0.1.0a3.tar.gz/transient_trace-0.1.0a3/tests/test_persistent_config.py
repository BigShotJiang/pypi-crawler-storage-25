"""
test_persistent_config.py — Tests for _config.py persistent config loader
and the security properties that depend on it.

Covers:
  - load_shim_config() with no config file (mode-derived defaults)
  - load_shim_config() reading persistent config
  - Mode-derived defaultAction (strict=deny, audit=allow)
  - Env var override blocked in strict mode when config is persistent
  - Env var override allowed in audit mode
  - OWASP packages auto-detected when not configured
  - Packages loaded from persistent config
  - _env_override_resolved flag preventing Client from re-applying env vars
  - Fail-closed behaviour: governance errors block in strict, pass in audit
  - .pth file content includes correct transient_trace path
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


# ── Helpers ───────────────────────────────────────────────────────────────────

def _write_config(tmp_path: Path, data: dict) -> Path:
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(data), encoding="utf-8")
    return cfg_path


# ── Mode-derived defaultAction ────────────────────────────────────────────────

class TestModeDefaultAction:
    """strict→deny, audit→allow, no config→audit→allow."""

    def test_no_config_no_env_defaults_to_audit_allow(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        # Point config path at empty dir so no file is found
        from transient_trace import _config as cfg_mod
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", tmp_path / "config.json")

        cfg = cfg_mod.load_shim_config()
        assert cfg["mode"] == "audit"
        assert cfg["pepPolicy"]["defaultAction"] == "allow"

    def test_strict_mode_from_env_derives_deny(self, monkeypatch, tmp_path):
        monkeypatch.setenv("TRANSIENT_TRACE_MODE", "strict")
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", tmp_path / "config.json")

        cfg = cfg_mod.load_shim_config()
        assert cfg["mode"] == "strict"
        assert cfg["pepPolicy"]["defaultAction"] == "deny"

    def test_strict_mode_from_config_file_derives_deny(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"mode": "strict"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        assert cfg["mode"] == "strict"
        assert cfg["pepPolicy"]["defaultAction"] == "deny"

    def test_audit_mode_from_config_file_derives_allow(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"mode": "audit"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        assert cfg["pepPolicy"]["defaultAction"] == "allow"

    def test_explicit_default_action_in_config_overrides_mode(self, monkeypatch, tmp_path):
        """User can explicitly set defaultAction to override the mode-derived value."""
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {
            "mode": "strict",
            "policy": {"version": 1, "defaultAction": "allow", "rules": []}
        })
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        # Explicit defaultAction=allow wins over strict-derived deny
        assert cfg["pepPolicy"]["defaultAction"] == "allow"

    def test_env_mode_overrides_config_file_mode(self, monkeypatch, tmp_path):
        monkeypatch.setenv("TRANSIENT_TRACE_MODE", "audit")
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"mode": "strict"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        # Env var wins over file
        assert cfg["mode"] == "audit"
        assert cfg["pepPolicy"]["defaultAction"] == "allow"


# ── Env var override in strict mode ──────────────────────────────────────────

class TestEnvVarOverrideInStrictMode:
    """
    TRANSIENT_TRACE_POLICY_JSON must not weaken policy when mode=strict
    and the config comes from the persistent config file (permanent shim path).
    """

    def test_allow_all_env_var_rejected_in_strict_from_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.setenv(
            "TRANSIENT_TRACE_POLICY_JSON",
            json.dumps({"version": 1, "defaultAction": "allow", "rules": []}),
        )
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"mode": "strict"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        # Env var allow-all must not override persistent strict deny
        assert cfg["pepPolicy"]["defaultAction"] == "deny"

    def test_allow_all_env_var_accepted_in_audit_from_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.setenv(
            "TRANSIENT_TRACE_POLICY_JSON",
            json.dumps({"version": 1, "defaultAction": "deny", "rules": []}),
        )
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"mode": "audit"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        # In audit mode env var IS applied (operator session override)
        assert cfg["pepPolicy"]["defaultAction"] == "deny"

    def test_env_override_resolved_flag_set(self, monkeypatch, tmp_path):
        """load_shim_config must set _env_override_resolved so Client skips re-processing."""
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", tmp_path / "config.json")

        cfg = cfg_mod.load_shim_config()
        assert cfg.get("_env_override_resolved") is True

    def test_client_skips_env_var_when_flag_set(self, monkeypatch, tmp_path):
        """
        Client must not re-apply TRANSIENT_TRACE_POLICY_JSON when
        _env_override_resolved=True, even in strict mode.
        """
        monkeypatch.setenv(
            "TRANSIENT_TRACE_POLICY_JSON",
            json.dumps({"version": 1, "defaultAction": "allow", "rules": []}),
        )
        from transient_trace.Client import Client

        with tempfile.TemporaryDirectory() as state_dir:
            client = Client({
                "mode": "strict",
                "pepPolicy": {"version": 1, "defaultAction": "deny", "rules": []},
                "state_dir": state_dir,
                "_env_override_resolved": True,  # flag set by load_shim_config
            })
            # Env var allow-all must not override — action should be blocked
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(
                    lambda: {},
                    {"action": "git", "action_class": "exec",
                     "target": {"command": "git push"}},
                )

    def test_client_applies_env_var_when_flag_absent(self, monkeypatch, tmp_path):
        """
        Without the flag (direct Client construction, transient-trace run),
        env vars are applied normally — operator session policy is honoured.
        """
        monkeypatch.setenv(
            "TRANSIENT_TRACE_POLICY_JSON",
            json.dumps({"version": 1, "defaultAction": "deny", "rules": []}),
        )
        from transient_trace.Client import Client

        with tempfile.TemporaryDirectory() as state_dir:
            client = Client({
                "mode": "strict",
                "pepPolicy": {"version": 1, "defaultAction": "allow", "rules": []},
                "state_dir": state_dir,
                # No _env_override_resolved — env var should be applied
            })
            with pytest.raises(RuntimeError):
                client.executeActionWithReceipt(
                    lambda: {},
                    {"action": "git", "action_class": "exec",
                     "target": {"command": "git push"}},
                )


# ── Package auto-detection ────────────────────────────────────────────────────

class TestPackageAutoDetection:

    def test_packages_auto_detected_when_not_in_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_PACKAGES", raising=False)
        from transient_trace import _config as cfg_mod
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", tmp_path / "config.json")

        cfg = cfg_mod.load_shim_config()
        # Should have auto-detected builtin packages
        assert "packages" in cfg
        assert len(cfg["packages"]) > 0

    def test_packages_loaded_from_config_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("TRANSIENT_TRACE_MODE", raising=False)
        monkeypatch.delenv("TRANSIENT_TRACE_PACKAGES", raising=False)
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"packages": "code,filesystem"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        assert cfg["packages"] == ["code", "filesystem"]

    def test_packages_env_var_overrides_config(self, monkeypatch, tmp_path):
        monkeypatch.setenv("TRANSIENT_TRACE_PACKAGES", "shell")
        from transient_trace import _config as cfg_mod
        cfg_file = _write_config(tmp_path, {"packages": "code,filesystem"})
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", cfg_file)

        cfg = cfg_mod.load_shim_config()
        assert cfg["packages"] == ["shell"]


# ── Fail-closed behaviour ─────────────────────────────────────────────────────

class TestFailClosed:
    """In strict mode, governance errors must block. In audit, they pass through."""

    def test_shim_fail_closed_in_strict_mode(self, monkeypatch, tmp_path):
        """
        If _run() raises an unexpected exception in strict mode, run_shim()
        must exit 126, not exec the real binary.
        """
        monkeypatch.setenv("TRANSIENT_TRACE_MODE", "strict")
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", tmp_path / "config.json")

        import transient_trace._shim as shim_mod

        def _raise(*args, **kwargs):
            raise RuntimeError("simulated governance failure")

        monkeypatch.setattr(shim_mod, "_run", _raise)

        with pytest.raises(SystemExit) as exc_info:
            shim_mod.run_shim.__wrapped__ if hasattr(shim_mod.run_shim, "__wrapped__") \
                else shim_mod.run_shim
            # Simulate calling run_shim internals directly
            import sys as _sys
            argv_backup = _sys.argv[:]
            _sys.argv = ["/usr/local/bin/git"] + ["push"]
            try:
                shim_mod.run_shim("/usr/bin/git")
            finally:
                _sys.argv = argv_backup

        assert exc_info.value.code == 126

    def test_shim_fail_open_in_audit_mode(self, monkeypatch, tmp_path):
        """In audit mode, governance errors must exec the real binary (fail-open)."""
        monkeypatch.setenv("TRANSIENT_TRACE_MODE", "audit")
        monkeypatch.delenv("TRANSIENT_TRACE_POLICY_JSON", raising=False)
        from transient_trace import _config as cfg_mod
        monkeypatch.setattr(cfg_mod, "_CONFIG_PATH", tmp_path / "config.json")

        import transient_trace._shim as shim_mod

        def _raise(*args, **kwargs):
            raise RuntimeError("simulated governance failure")

        monkeypatch.setattr(shim_mod, "_run", _raise)

        exec_called = []

        def _fake_exec(real_bin, argv):
            exec_called.append((real_bin, argv))
            raise SystemExit(0)  # simulate successful exec

        monkeypatch.setattr(shim_mod, "_exec_real", _fake_exec)

        import sys as _sys
        argv_backup = _sys.argv[:]
        _sys.argv = ["/usr/local/bin/git", "status"]
        try:
            with pytest.raises(SystemExit):
                shim_mod.run_shim("/usr/bin/git")
        finally:
            _sys.argv = argv_backup

        assert len(exec_called) == 1, "fail-open: _exec_real must be called in audit mode"


# ── .pth file content ─────────────────────────────────────────────────────────

class TestPthFileContent:

    def test_pth_includes_transient_trace_path(self):
        """_build_pth_content() must add transient_trace's site-packages to the .pth."""
        from transient_trace.cli import _build_pth_content
        import transient_trace as tt
        expected_path = str(Path(tt.__file__).parent.parent)

        content = _build_pth_content()
        assert expected_path in content

    def test_pth_imports_and_installs_hook(self):
        """The second line of the .pth must install the Popen hook."""
        from transient_trace.cli import _build_pth_content
        content = _build_pth_content()
        assert "install_hook" in content
        assert "transient_trace._popen_hook" in content

    def test_pth_has_two_lines(self):
        """Path entry first, then import — exactly two non-empty lines."""
        from transient_trace.cli import _build_pth_content
        lines = [l for l in _build_pth_content().splitlines() if l.strip()]
        assert len(lines) == 2
