"""
test_receipt_engine.py — Tests for the receipt engine self-learning loop.

Tests the four components individually and the full loop end-to-end.

Critical tests (must pass before shipping):
  - Correctness: distillation compresses correctly
  - Safety: ambiguous patterns never promote; corrupt receipts rejected
  - Token cap: inject never exceeds 80 tokens regardless of corpus size
  - Scale: O(1) inject with large pattern set
  - Loop: 50 receipts → distill → promote → rule in registry
"""

import time
import pytest
from pathlib import Path
from unittest.mock import MagicMock


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_store(tmp_path):
    from transient_trace.receipt_engine.store import ReceiptStore
    store = ReceiptStore(db_path=tmp_path / "receipts.db")
    yield store
    store.close()


@pytest.fixture
def mock_receipt():
    """Minimal valid signed receipt."""
    return {
        "receipt_id":    "test-001",
        "action_class":  "filesystem",
        "tool_name":     "write_file",
        "outcome":       "deny",
        "path":          "/etc/passwd",
        "matched_rule_id":     "ASI-07",
        "matched_rule_reason": "protected system path",
        "matched_package":     "filesystem",
        "ts":            time.time(),
        "signature":     {"alg": "Ed25519", "kid": "test", "sig": "fakesig"},
    }


def make_receipt(i: int, action_class="filesystem", tool_name="write_file",
                 outcome="deny", path="/etc/passwd") -> dict:
    return {
        "receipt_id":    f"test-{i:04d}",
        "action_class":  action_class,
        "tool_name":     tool_name,
        "outcome":       outcome,
        "path":          path,
        "matched_rule_id":     "ASI-07",
        "matched_rule_reason": "protected system path",
        "matched_package":     "filesystem",
        "ts":            time.time(),
        "signature":     {"alg": "Ed25519", "kid": "test", "sig": f"sig{i}"},
    }


# ---------------------------------------------------------------------------
# ReceiptStore
# ---------------------------------------------------------------------------

class TestReceiptStore:

    def test_write_and_query(self, tmp_store, mock_receipt):
        tmp_store.write(mock_receipt)
        results = tmp_store.query(action_class="filesystem")
        assert len(results) == 1
        assert results[0]["receipt_id"] == "test-001"

    def test_append_only_no_duplicates(self, tmp_store, mock_receipt):
        tmp_store.write(mock_receipt)
        tmp_store.write(mock_receipt)  # same receipt_id — should be ignored
        assert tmp_store.count() == 1

    def test_query_by_outcome(self, tmp_store):
        tmp_store.write(make_receipt(1, outcome="deny"))
        tmp_store.write(make_receipt(2, outcome="allow"))
        denies = tmp_store.query(outcome="deny")
        allows = tmp_store.query(outcome="allow")
        assert len(denies) == 1
        assert len(allows) == 1

    def test_query_by_tool_name(self, tmp_store):
        tmp_store.write(make_receipt(1, tool_name="write_file"))
        tmp_store.write(make_receipt(2, tool_name="read_file"))
        results = tmp_store.query(tool_name="write_file")
        assert len(results) == 1

    def test_rejects_receipt_without_signature(self, tmp_store):
        bad = {"receipt_id": "bad", "action_class": "filesystem"}
        with pytest.raises(ValueError, match="signature"):
            tmp_store.write(bad)

    def test_stats_returns_counts(self, tmp_store):
        for i in range(5):
            tmp_store.write(make_receipt(i, outcome="deny"))
        for i in range(5, 8):
            tmp_store.write(make_receipt(i, outcome="allow"))
        stats = tmp_store.stats(action_class="filesystem")
        outcomes = {s["outcome"]: s["count"] for s in stats}
        assert outcomes["deny"] == 5
        assert outcomes["allow"] == 3

    def test_count(self, tmp_store):
        for i in range(10):
            tmp_store.write(make_receipt(i))
        assert tmp_store.count() == 10

    def test_on_write_callback_fires(self, tmp_store, mock_receipt):
        fired = []
        tmp_store.on_write(lambda r: fired.append(r))
        tmp_store.write(mock_receipt)
        assert len(fired) == 1
        assert fired[0]["receipt_id"] == "test-001"


# ---------------------------------------------------------------------------
# PatternDistiller
# ---------------------------------------------------------------------------

class TestPatternDistiller:

    def test_distills_receipts_to_single_pattern(self, tmp_store):
        from transient_trace.receipt_engine.distiller import PatternDistiller
        # 10 receipts, same pattern
        for i in range(10):
            tmp_store.write(make_receipt(i, outcome="deny"))
        distiller = PatternDistiller(tmp_store)
        distiller.run()
        patterns = distiller.get_patterns()
        assert len(patterns) == 1
        assert patterns[0]["action_class"] == "filesystem"
        assert patterns[0]["outcome"] == "deny"
        assert patterns[0]["count"] == 10

    def test_confidence_is_fraction_of_total(self, tmp_store):
        from transient_trace.receipt_engine.distiller import PatternDistiller
        # 7 deny, 3 allow — both above min_count=3
        for i in range(7):
            tmp_store.write(make_receipt(i, outcome="deny"))
        for i in range(7, 10):
            tmp_store.write(make_receipt(i, outcome="allow"))
        distiller = PatternDistiller(tmp_store)
        distiller.run()
        patterns = distiller.get_patterns()
        by_outcome = {p["outcome"]: p for p in patterns}
        assert "deny" in by_outcome
        assert "allow" in by_outcome
        assert abs(by_outcome["deny"]["confidence"] - 0.7) < 0.01
        assert abs(by_outcome["allow"]["confidence"] - 0.3) < 0.01

    def test_ambiguous_pattern_flagged(self, tmp_store):
        from transient_trace.receipt_engine.distiller import PatternDistiller
        # Same action+tool+rule_id but both deny and allow outcomes
        for i in range(5):
            r = make_receipt(i, outcome="deny")
            r["matched_rule_id"] = "TEST-01"
            tmp_store.write(r)
        for i in range(5, 8):
            r = make_receipt(i, outcome="allow")
            r["matched_rule_id"] = "TEST-01"
            tmp_store.write(r)
        distiller = PatternDistiller(tmp_store)
        distiller.run()
        patterns = distiller.get_patterns()
        assert all(p["ambiguous"] for p in patterns)

    def test_below_min_count_not_included(self, tmp_store):
        from transient_trace.receipt_engine.distiller import PatternDistiller
        # Only 2 receipts — below _MIN_COUNT_FOR_PATTERN=3
        for i in range(2):
            tmp_store.write(make_receipt(i))
        distiller = PatternDistiller(tmp_store)
        distiller.run()
        patterns = distiller.get_patterns()
        assert len(patterns) == 0

    def test_multiple_action_classes_distilled_separately(self, tmp_store):
        from transient_trace.receipt_engine.distiller import PatternDistiller
        for i in range(5):
            tmp_store.write(make_receipt(i, action_class="filesystem", outcome="deny"))
        for i in range(5, 10):
            tmp_store.write(make_receipt(
                i, action_class="web", tool_name="http_request", outcome="challenge"
            ))
        distiller = PatternDistiller(tmp_store)
        distiller.run()
        patterns = distiller.get_patterns()
        classes = {p["action_class"] for p in patterns}
        assert "filesystem" in classes
        assert "web" in classes


# ---------------------------------------------------------------------------
# RulePromoter
# ---------------------------------------------------------------------------

class TestRulePromoter:

    def _make_pattern(self, confidence=0.99, count=50, outcome="deny",
                      ambiguous=False, promoted=False):
        return {
            "action_class": "filesystem",
            "tool_name":    "write_file",
            "outcome":      outcome,
            "rule_id":      "ASI-07",
            "rule_reason":  "protected system path",
            "package_name": "filesystem",
            "count":        count,
            "confidence":   confidence,
            "last_seen":    time.time(),
            "ambiguous":    ambiguous,
            "promoted":     promoted,
        }

    def test_promotes_high_confidence_deny(self):
        from transient_trace.receipt_engine.promoter import RulePromoter
        from transient_trace.receipt_engine.distiller import PatternDistiller

        distiller = MagicMock(spec=PatternDistiller)
        distiller.get_patterns.return_value = [self._make_pattern()]

        registry = MagicMock()
        registry.describe.side_effect = KeyError("not found")

        promoter = RulePromoter(distiller, registry, min_confidence=0.95, min_count=50)
        promoter.run()

        assert promoter.promoted_count() == 1
        registry.load.assert_called_once()

    def test_does_not_promote_ambiguous(self):
        from transient_trace.receipt_engine.promoter import RulePromoter
        from transient_trace.receipt_engine.distiller import PatternDistiller

        distiller = MagicMock(spec=PatternDistiller)
        distiller.get_patterns.return_value = [
            self._make_pattern(ambiguous=True)
        ]
        registry = MagicMock()
        promoter = RulePromoter(distiller, registry)
        promoter.run()

        assert promoter.promoted_count() == 0
        registry.load.assert_not_called()

    def test_does_not_promote_below_confidence(self):
        from transient_trace.receipt_engine.promoter import RulePromoter
        from transient_trace.receipt_engine.distiller import PatternDistiller

        # Realistic scenario: 100 deny + 25 allow = 125 total → deny confidence 0.80.
        # The promoter aggregates from all patterns in the list to compute the real
        # confidence (deny_count / total_for_pair). We must include the allow pattern
        # so the denominator is correct; otherwise total = deny count = 100 → 1.0.
        distiller = MagicMock(spec=PatternDistiller)
        distiller.get_patterns.return_value = [
            self._make_pattern(confidence=0.80, count=100, outcome="deny"),
            self._make_pattern(confidence=0.20, count=25,  outcome="allow"),
        ]
        registry = MagicMock()
        promoter = RulePromoter(distiller, registry)  # default min_confidence=0.95
        promoter.run()

        assert promoter.promoted_count() == 0

    def test_does_not_promote_below_count(self):
        from transient_trace.receipt_engine.promoter import RulePromoter
        from transient_trace.receipt_engine.distiller import PatternDistiller

        distiller = MagicMock(spec=PatternDistiller)
        distiller.get_patterns.return_value = [
            self._make_pattern(confidence=0.99, count=10)
        ]
        registry = MagicMock()
        promoter = RulePromoter(distiller, registry)
        promoter.run()

        assert promoter.promoted_count() == 0

    def test_does_not_promote_allow_outcome(self):
        from transient_trace.receipt_engine.promoter import RulePromoter
        from transient_trace.receipt_engine.distiller import PatternDistiller

        distiller = MagicMock(spec=PatternDistiller)
        distiller.get_patterns.return_value = [
            self._make_pattern(outcome="allow", confidence=0.99, count=500)
        ]
        registry = MagicMock()
        promoter = RulePromoter(distiller, registry)
        promoter.run()

        assert promoter.promoted_count() == 0

    def test_does_not_promote_already_promoted(self):
        from transient_trace.receipt_engine.promoter import RulePromoter
        from transient_trace.receipt_engine.distiller import PatternDistiller

        distiller = MagicMock(spec=PatternDistiller)
        distiller.get_patterns.return_value = [
            self._make_pattern(promoted=True)
        ]
        registry = MagicMock()
        promoter = RulePromoter(distiller, registry)
        promoter.run()

        assert promoter.promoted_count() == 0


# ---------------------------------------------------------------------------
# Injector
# ---------------------------------------------------------------------------

class TestInjector:

    def _make_pattern(self, action_class="filesystem", tool_name="write_file",
                      outcome="deny", confidence=0.99, count=50,
                      promoted=False, ambiguous=False):
        return {
            "action_class": action_class,
            "tool_name":    tool_name,
            "outcome":      outcome,
            "rule_id":      "ASI-07",
            "rule_reason":  "protected system path",
            "package_name": "filesystem",
            "count":        count,
            "confidence":   confidence,
            "last_seen":    time.time(),
            "promoted":     promoted,
            "ambiguous":    ambiguous,
        }

    def test_returns_empty_when_no_patterns(self):
        from transient_trace.receipt_engine.injector import Injector
        distiller = MagicMock()
        distiller.get_patterns.return_value = []
        injector = Injector(distiller)
        assert injector.inject(action_class="filesystem") == ""

    def test_returns_relevant_pattern(self):
        from transient_trace.receipt_engine.injector import Injector
        distiller = MagicMock()
        distiller.get_patterns.return_value = [self._make_pattern()]
        injector = Injector(distiller)
        result = injector.inject(action_class="filesystem", tool_name="write_file")
        assert "GOVERNANCE_CONTEXT" in result
        assert "DENY" in result
        assert "filesystem" in result

    def test_skips_promoted_patterns(self):
        from transient_trace.receipt_engine.injector import Injector
        distiller = MagicMock()
        distiller.get_patterns.return_value = [self._make_pattern(promoted=True)]
        injector = Injector(distiller)
        result = injector.inject(action_class="filesystem")
        assert result == ""

    def test_skips_low_confidence_patterns(self):
        from transient_trace.receipt_engine.injector import Injector
        distiller = MagicMock()
        distiller.get_patterns.return_value = [self._make_pattern(confidence=0.5)]
        injector = Injector(distiller)
        result = injector.inject(action_class="filesystem")
        assert result == ""

    def test_token_cap_never_exceeded(self):
        from transient_trace.receipt_engine.injector import Injector, _MAX_CHARS
        distiller = MagicMock()
        # 100 patterns — should still fit within cap
        patterns = [
            self._make_pattern(
                action_class=f"class_{i}",
                tool_name=f"tool_{i}",
                outcome="deny",
            )
            for i in range(100)
        ]
        distiller.get_patterns.return_value = patterns
        injector = Injector(distiller)
        result = injector.inject()
        assert len(result) <= _MAX_CHARS

    def test_deny_prioritised_over_allow(self):
        from transient_trace.receipt_engine.injector import Injector
        distiller = MagicMock()
        distiller.get_patterns.return_value = [
            self._make_pattern(outcome="allow", confidence=0.99, count=200),
            self._make_pattern(outcome="deny",  confidence=0.80, count=50),
        ]
        injector = Injector(distiller)
        result = injector.inject(action_class="filesystem", tool_name="write_file")
        # DENY should appear first
        deny_pos  = result.find("DENY")
        allow_pos = result.find("ALLOW")
        if deny_pos >= 0 and allow_pos >= 0:
            assert deny_pos < allow_pos

    def test_filters_by_action_class(self):
        from transient_trace.receipt_engine.injector import Injector
        distiller = MagicMock()
        distiller.get_patterns.return_value = [
            self._make_pattern(action_class="filesystem"),
            self._make_pattern(action_class="web", tool_name="http_request"),
        ]
        injector = Injector(distiller)
        result = injector.inject(action_class="filesystem")
        assert "filesystem" in result
        assert "web" not in result


# ---------------------------------------------------------------------------
# ReceiptEngine — full loop
# ---------------------------------------------------------------------------

class TestReceiptEngineFullLoop:

    def test_store_distill_inject_cycle(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine

        engine = ReceiptEngine(db_path=tmp_path / "receipts.db")

        # Write 10 deny receipts
        for i in range(10):
            engine.store(make_receipt(i, outcome="deny"))

        # Force distillation
        engine.distill()

        # Inject should return governance context
        result = engine.inject(action_class="filesystem", tool_name="write_file")
        assert "GOVERNANCE_CONTEXT" in result
        assert "DENY" in result

    def test_full_loop_promotes_at_threshold(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine

        registry = MagicMock()
        registry.describe.side_effect = KeyError("not found")

        engine = ReceiptEngine(
            db_path=tmp_path / "receipts.db",
            registry=registry,
            promote_min_confidence=0.95,
            promote_min_count=50,
        )

        # Write 50 deny receipts — meets promotion threshold
        for i in range(50):
            engine.store(make_receipt(i, outcome="deny"))

        engine.distill()

        stats = engine.stats()
        assert stats["total_receipts"] == 50
        assert stats["patterns"] >= 1
        assert stats["promoted_rules"] == 1
        registry.load.assert_called_once()

    def test_inject_empty_when_no_receipts(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine
        engine = ReceiptEngine(db_path=tmp_path / "receipts.db")
        result = engine.inject(action_class="filesystem")
        assert result == ""

    def test_promoted_patterns_produce_zero_inject_tokens(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine

        registry = MagicMock()
        registry.describe.side_effect = KeyError("not found")

        engine = ReceiptEngine(
            db_path=tmp_path / "receipts.db",
            registry=registry,
            promote_min_confidence=0.50,  # low threshold for test
            promote_min_count=5,
        )

        for i in range(10):
            engine.store(make_receipt(i, outcome="deny"))

        engine.distill()

        # After promotion, inject should return empty (PEP handles it)
        result = engine.inject(action_class="filesystem", tool_name="write_file")
        assert result == ""

    def test_stats_reflects_state(self, tmp_path):
        from transient_trace.receipt_engine import ReceiptEngine
        engine = ReceiptEngine(db_path=tmp_path / "receipts.db")

        assert engine.stats()["total_receipts"] == 0

        for i in range(5):
            engine.store(make_receipt(i))

        assert engine.stats()["total_receipts"] == 5

        engine.distill()
        assert engine.stats()["patterns"] >= 1
