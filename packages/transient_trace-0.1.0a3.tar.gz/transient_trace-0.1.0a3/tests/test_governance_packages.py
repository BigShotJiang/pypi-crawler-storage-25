"""
test_governance_packages.py — Tests for governance package schema and PackageRegistry.
"""

import logging

import pytest

import transient_trace
from transient_trace.atp.governance_package import validate_package
from transient_trace.atp.package_registry import PackageRegistry
from transient_trace.atp.snapshot import computeSnapshotHash


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _make_pkg(name="test-pkg", version="1.0.0", rules=None, **kwargs) -> dict:
    if rules is None:
        rules = [
            {
                "profile": "exec",
                "condition": {"action_class": "write_low"},
                "outcome": "deny",
                "reason": "deny all writes by default",
            }
        ]
    pkg = {"name": name, "version": version, "rules": rules}
    pkg.update(kwargs)
    return pkg


def _make_rule(profile="exec", outcome="deny", reason="test rule", **kwargs) -> dict:
    rule = {
        "profile": profile,
        "condition": {},
        "outcome": outcome,
        "reason": reason,
    }
    rule.update(kwargs)
    return rule


# ------------------------------------------------------------------
# validate_package — valid cases
# ------------------------------------------------------------------

class TestValidatePackageValid:
    def test_valid_package_no_error(self):
        validate_package(_make_pkg())

    def test_valid_package_full_fields(self):
        pkg = _make_pkg(
            description="A full package",
            fail_closed=True,
            requires=[],
        )
        validate_package(pkg)

    def test_valid_package_with_optional_rule_id(self):
        rule = _make_rule()
        rule["id"] = "rule-001"
        validate_package(_make_pkg(rules=[rule]))

    def test_valid_package_multiple_profiles(self):
        rules = [
            _make_rule(profile="exec"),
            _make_rule(profile="egress"),
            _make_rule(profile="any"),
        ]
        validate_package(_make_pkg(rules=rules))

    def test_valid_package_all_outcomes(self):
        for outcome in ("allow", "deny", "challenge"):
            validate_package(_make_pkg(rules=[_make_rule(outcome=outcome)]))

    def test_valid_package_empty_rules_list(self):
        validate_package(_make_pkg(rules=[]))

    def test_valid_package_requires_list(self):
        pkg = _make_pkg(requires=["base-pkg"])
        validate_package(pkg)


# ------------------------------------------------------------------
# validate_package — invalid cases
# ------------------------------------------------------------------

class TestValidatePackageInvalid:
    def test_missing_name_raises(self):
        pkg = {"version": "1.0.0", "rules": []}
        with pytest.raises(ValueError, match="name"):
            validate_package(pkg)

    def test_empty_name_raises(self):
        pkg = {"name": "", "version": "1.0.0", "rules": []}
        with pytest.raises(ValueError, match="name"):
            validate_package(pkg)

    def test_missing_version_raises(self):
        pkg = {"name": "test", "rules": []}
        with pytest.raises(ValueError, match="version"):
            validate_package(pkg)

    def test_empty_version_raises(self):
        pkg = {"name": "test", "version": "", "rules": []}
        with pytest.raises(ValueError, match="version"):
            validate_package(pkg)

    def test_missing_rules_raises(self):
        pkg = {"name": "test", "version": "1.0.0"}
        with pytest.raises(ValueError, match="rules"):
            validate_package(pkg)

    def test_rule_missing_profile_raises(self):
        rule = {"condition": {}, "outcome": "deny", "reason": "test"}
        with pytest.raises(ValueError, match="profile"):
            validate_package(_make_pkg(rules=[rule]))

    def test_rule_missing_outcome_raises(self):
        rule = {"profile": "exec", "condition": {}, "reason": "test"}
        with pytest.raises(ValueError, match="outcome"):
            validate_package(_make_pkg(rules=[rule]))

    def test_rule_missing_reason_raises(self):
        rule = {"profile": "exec", "condition": {}, "outcome": "deny"}
        with pytest.raises(ValueError, match="reason"):
            validate_package(_make_pkg(rules=[rule]))

    def test_invalid_outcome_raises(self):
        rule = _make_rule(outcome="permit")
        with pytest.raises(ValueError, match="outcome"):
            validate_package(_make_pkg(rules=[rule]))

    def test_invalid_profile_raises(self):
        rule = _make_rule(profile="network")
        with pytest.raises(ValueError, match="profile"):
            validate_package(_make_pkg(rules=[rule]))

    def test_not_a_dict_raises(self):
        with pytest.raises(ValueError):
            validate_package("not-a-dict")

    def test_fail_closed_not_bool_raises(self):
        pkg = _make_pkg(fail_closed="yes")
        with pytest.raises(ValueError, match="fail_closed"):
            validate_package(pkg)

    def test_requires_not_list_raises(self):
        pkg = _make_pkg(requires="other-pkg")
        with pytest.raises(ValueError, match="requires"):
            validate_package(pkg)

    def test_rule_missing_condition_raises(self):
        rule = {"profile": "exec", "outcome": "deny", "reason": "test"}
        with pytest.raises(ValueError, match="condition"):
            validate_package(_make_pkg(rules=[rule]))


# ------------------------------------------------------------------
# PackageRegistry — load
# ------------------------------------------------------------------

class TestPackageRegistryLoad:
    def test_load_valid_package(self):
        reg = PackageRegistry()
        reg.load(_make_pkg())

    def test_duplicate_name_raises(self):
        reg = PackageRegistry()
        reg.load(_make_pkg(name="pkg-a"))
        with pytest.raises(ValueError, match="already loaded"):
            reg.load(_make_pkg(name="pkg-a"))

    def test_load_invalid_schema_raises(self):
        reg = PackageRegistry()
        with pytest.raises(ValueError):
            reg.load({"name": "bad", "rules": []})  # missing version

    def test_load_non_dict_non_str_raises(self):
        reg = PackageRegistry()
        with pytest.raises(ValueError):
            reg.load(42)


# ------------------------------------------------------------------
# PackageRegistry — circular requires
# ------------------------------------------------------------------

class TestPackageRegistryCircular:
    def test_circular_requires_raises(self):
        pkg_a = _make_pkg(name="pkg-a", requires=["pkg-b"])
        pkg_b = _make_pkg(name="pkg-b", requires=["pkg-a"])
        reg = PackageRegistry()
        with pytest.raises(ValueError, match="circular"):
            reg.load_all([pkg_a, pkg_b])

    def test_self_referential_requires_raises(self):
        pkg_a = _make_pkg(name="pkg-a", requires=["pkg-a"])
        reg = PackageRegistry()
        with pytest.raises(ValueError, match="circular"):
            reg.load_all([pkg_a])

    def test_three_way_circular_raises(self):
        pkg_a = _make_pkg(name="pkg-a", requires=["pkg-c"])
        pkg_b = _make_pkg(name="pkg-b", requires=["pkg-a"])
        pkg_c = _make_pkg(name="pkg-c", requires=["pkg-b"])
        reg = PackageRegistry()
        with pytest.raises(ValueError, match="circular"):
            reg.load_all([pkg_a, pkg_b, pkg_c])

    def test_non_circular_chain_loads_fine(self):
        pkg_a = _make_pkg(name="pkg-a")
        pkg_b = _make_pkg(name="pkg-b", requires=["pkg-a"])
        pkg_c = _make_pkg(name="pkg-c", requires=["pkg-b"])
        reg = PackageRegistry()
        reg.load_all([pkg_a, pkg_b, pkg_c])
        assert len(reg.list_packages()) == 3


# ------------------------------------------------------------------
# PackageRegistry — get_rules
# ------------------------------------------------------------------

class TestPackageRegistryGetRules:
    def _make_registry(self):
        reg = PackageRegistry()
        exec_rule = _make_rule(profile="exec", reason="exec only")
        egress_rule = _make_rule(profile="egress", reason="egress only")
        any_rule = _make_rule(profile="any", reason="any profile")

        pkg = _make_pkg(name="multi-pkg", rules=[exec_rule, egress_rule, any_rule])
        reg.load(pkg)
        return reg

    def test_get_rules_exec_includes_exec_and_any(self):
        reg = self._make_registry()
        rules = reg.get_rules("exec")
        profiles = {r["profile"] for r in rules}
        assert "exec" in profiles
        assert "any" in profiles
        assert "egress" not in profiles

    def test_get_rules_egress_includes_egress_and_any(self):
        reg = self._make_registry()
        rules = reg.get_rules("egress")
        profiles = {r["profile"] for r in rules}
        assert "egress" in profiles
        assert "any" in profiles
        assert "exec" not in profiles

    def test_get_rules_any_returns_all(self):
        reg = self._make_registry()
        rules = reg.get_rules("any")
        profiles = {r["profile"] for r in rules}
        assert profiles == {"exec", "egress", "any"}

    def test_get_rules_empty_registry(self):
        reg = PackageRegistry()
        assert reg.get_rules("exec") == []

    def test_get_rules_across_multiple_packages(self):
        reg = PackageRegistry()
        pkg1 = _make_pkg(name="pkg-1", rules=[_make_rule(profile="exec", reason="r1")])
        pkg2 = _make_pkg(name="pkg-2", rules=[_make_rule(profile="exec", reason="r2")])
        reg.load(pkg1)
        reg.load(pkg2)
        rules = reg.get_rules("exec")
        assert len(rules) == 2


# ------------------------------------------------------------------
# PackageRegistry — summary
# ------------------------------------------------------------------

class TestPackageRegistrySummary:
    def test_summary_no_packages(self):
        reg = PackageRegistry()
        s = reg.summary()
        assert "0" in s

    def test_summary_single_package(self):
        reg = PackageRegistry()
        reg.load(_make_pkg(name="messaging", version="1.0"))
        s = reg.summary()
        assert "messaging" in s
        assert "1.0" in s

    def test_summary_multiple_packages_contains_names(self):
        reg = PackageRegistry()
        reg.load(_make_pkg(name="messaging", version="1.0"))
        reg.load(_make_pkg(name="filesystem", version="2.1"))
        reg.load(_make_pkg(name="my-app", version="0.3"))
        s = reg.summary()
        assert "messaging" in s
        assert "filesystem" in s
        assert "my-app" in s
        assert "3" in s

    def test_summary_returns_string(self):
        reg = PackageRegistry()
        assert isinstance(reg.summary(), str)


# ------------------------------------------------------------------
# PackageRegistry — describe
# ------------------------------------------------------------------

class TestPackageRegistryDescribe:
    def test_describe_returns_full_definition(self):
        reg = PackageRegistry()
        pkg = _make_pkg(name="my-pkg", version="2.0.0", description="A test package")
        reg.load(pkg)
        result = reg.describe("my-pkg")
        assert result["name"] == "my-pkg"
        assert result["version"] == "2.0.0"
        assert result["description"] == "A test package"
        assert "rules" in result

    def test_describe_unknown_raises_key_error(self):
        reg = PackageRegistry()
        with pytest.raises(KeyError, match="not-loaded"):
            reg.describe("not-loaded")

    def test_describe_after_load_all(self):
        reg = PackageRegistry()
        pkg_a = _make_pkg(name="pkg-a")
        pkg_b = _make_pkg(name="pkg-b", requires=["pkg-a"])
        reg.load_all([pkg_a, pkg_b])
        result = reg.describe("pkg-b")
        assert result["name"] == "pkg-b"


# ------------------------------------------------------------------
# PackageRegistry — list_packages
# ------------------------------------------------------------------

class TestPackageRegistryListPackages:
    def test_list_packages_empty(self):
        reg = PackageRegistry()
        assert reg.list_packages() == []

    def test_list_packages_returns_name_and_version(self):
        reg = PackageRegistry()
        reg.load(_make_pkg(name="alpha", version="1.0.0"))
        reg.load(_make_pkg(name="beta", version="2.3.1"))
        pkgs = reg.list_packages()
        assert len(pkgs) == 2
        names = {p["name"] for p in pkgs}
        assert names == {"alpha", "beta"}
        for p in pkgs:
            assert "name" in p
            assert "version" in p


# ------------------------------------------------------------------
# Client integration — package init and mode behaviour
# ------------------------------------------------------------------

class TestClientPackageInit:
    def test_client_with_builtin_package_initialises(self):
        client = transient_trace.Client({"packages": ["messaging"]})
        assert client is not None

    def test_client_with_filesystem_package_initialises(self):
        client = transient_trace.Client({"packages": ["filesystem"]})
        assert client is not None

    def test_client_with_multiple_builtins_initialises(self):
        client = transient_trace.Client({"packages": ["messaging", "filesystem"]})
        assert client is not None

    def test_client_with_inline_package_initialises(self):
        pkg = {
            "name": "my-app",
            "version": "1.0.0",
            "rules": [
                {
                    "profile": "exec",
                    "condition": {"action_class": "delete"},
                    "outcome": "deny",
                    "reason": "deny all deletes",
                }
            ],
        }
        client = transient_trace.Client({"packages": [pkg]})
        assert client is not None

    def test_client_empty_packages_initialises(self):
        client = transient_trace.Client({"packages": []})
        assert client is not None

    def test_client_no_packages_key_initialises(self):
        client = transient_trace.Client({})
        assert client is not None

    def test_client_packages_logs_summary(self, caplog):
        with caplog.at_level(logging.INFO, logger="transient_trace.Client"):
            transient_trace.Client({"packages": ["messaging"]})
        assert any("governance" in r.message for r in caplog.records)

    def test_client_invalid_builtin_name_raises_at_init(self):
        with pytest.raises(ValueError, match="no built-in"):
            transient_trace.Client({"packages": ["nonexistent-package"]})

    def test_client_invalid_inline_package_raises_at_init(self):
        bad_pkg = {"name": "broken", "rules": []}  # missing version
        with pytest.raises(ValueError, match="version"):
            transient_trace.Client({"packages": [bad_pkg]})


class TestClientModeAudit:
    def test_mode_audit_never_blocks(self):
        # Build a policy that would deny everything in strict mode
        deny_policy = {"version": 1, "defaultAction": "deny", "rules": []}
        client = transient_trace.Client({
            "mode": "audit",
            "pepPolicy": deny_policy,
        })
        # Should not raise even though underlying policy would deny
        result = client.executeActionWithReceipt(
            lambda: "ok",
            {"action": "test", "action_class": "write_low", "target": "test-target"},
        )
        assert result["output"] == "ok"
        assert result["decision"]["outcome"] == "allow"
        assert "audit" in result["decision"]["reason_code"]

    def test_mode_permissive_never_blocks(self):
        deny_policy = {"version": 1, "defaultAction": "deny", "rules": []}
        client = transient_trace.Client({
            "mode": "permissive",
            "pepPolicy": deny_policy,
        })
        result = client.executeActionWithReceipt(
            lambda: "ok",
            {"action": "test", "action_class": "write_low", "target": "test-target"},
        )
        assert result["output"] == "ok"
        assert result["decision"]["outcome"] == "allow"
        assert "permissive" in result["decision"]["reason_code"]


class TestClientModeStrict:
    def test_mode_strict_blocks_on_deny(self):
        deny_policy = {"version": 1, "defaultAction": "deny", "rules": []}
        client = transient_trace.Client({
            "mode": "strict",
            "pepPolicy": deny_policy,
        })
        with pytest.raises(RuntimeError, match="Denied"):
            client.executeActionWithReceipt(
                lambda: "ok",
                {"action": "test", "action_class": "write_low", "target": "test-target"},
            )

    def test_mode_default_is_strict(self):
        deny_policy = {"version": 1, "defaultAction": "deny", "rules": []}
        client = transient_trace.Client({"pepPolicy": deny_policy})
        with pytest.raises(RuntimeError, match="Denied"):
            client.executeActionWithReceipt(
                lambda: "ok",
                {"action": "test", "action_class": "write_low", "target": "test-target"},
            )

    def test_invalid_mode_raises_at_init(self):
        with pytest.raises(ValueError, match="invalid governance mode"):
            transient_trace.Client({"mode": "observe"})


# ------------------------------------------------------------------
# PAP (Client packages → PEP) — end-to-end policy + matched_* on decisions
# ------------------------------------------------------------------

_ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}


class TestPapClientPackageWiring:
    """Governance packages from Client config must reach exec/egress PEPs and affect decisions."""

    def test_exec_package_deny_surfaces_matched_fields_in_audit_mode(self):
        pkg = {
            "name": "pap-exec-block",
            "version": "1.0.0",
            "rules": [
                {
                    "id": "deny-writes",
                    "profile": "exec",
                    "condition": {"action_class": "write_low"},
                    "outcome": "deny",
                    "reason": "package blocks write_low",
                }
            ],
        }
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": [pkg],
            "mode": "audit",
        })
        result = client.executeActionWithReceipt(
            lambda: "done",
            {"action": "executeAction", "action_class": "write_low", "target": "x"},
        )
        assert result["output"] == "done"
        assert result["decision"]["outcome"] == "allow"
        assert "would_be_deny" in result["decision"]["reason_code"]
        assert result["decision"]["matched_package"] == "pap-exec-block"
        assert result["decision"]["matched_rule_id"] == "deny-writes"
        assert "package blocks write_low" in result["decision"]["matched_rule_reason"]
        snap = result["receipt"]["event_snapshot"]
        assert snap["matched_package"] == "pap-exec-block"
        assert snap["matched_rule_id"] == "deny-writes"
        assert computeSnapshotHash(snap) == result["receipt"]["event_snapshot_hash"]

    def test_exec_package_deny_blocks_in_strict_mode(self):
        pkg = {
            "name": "pap-exec-strict",
            "version": "1.0.0",
            "rules": [
                {
                    "profile": "exec",
                    "condition": {"action_class": "write_low"},
                    "outcome": "deny",
                    "reason": "no writes",
                }
            ],
        }
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": [pkg],
            "mode": "strict",
        })
        with pytest.raises(RuntimeError, match="Denied"):
            client.executeActionWithReceipt(
                lambda: "done",
                {"action": "executeAction", "action_class": "write_low", "target": "x"},
            )

    def test_egress_package_deny_surfaces_matched_fields_in_audit_mode(self):
        pkg = {
            "name": "pap-egress-block",
            "version": "1.0.0",
            "rules": [
                {
                    "id": "block-external",
                    "profile": "egress",
                    "condition": {"host": "external"},
                    "outcome": "deny",
                    "reason": "egress package blocks external hosts",
                }
            ],
        }
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": [pkg],
            "mode": "audit",
        })
        result = client.executeActionWithReceipt(
            lambda: {"ok": True},
            {
                "action": "sendRequest",
                "action_type": "network",
                "action_class": "write_high",
                "target": {
                    "host": "api.example.com",
                    "port": 443,
                    "method": "POST",
                    "path": "/v1/x",
                },
            },
        )
        assert result["decision"]["outcome"] == "allow"
        assert "would_be_deny" in result["decision"]["reason_code"]
        assert result["decision"]["matched_package"] == "pap-egress-block"
        assert result["decision"]["matched_rule_id"] == "block-external"
        es = result["receipt"]["event_snapshot"]
        assert es["matched_package"] == "pap-egress-block"
        assert es["matched_rule_id"] == "block-external"
        assert computeSnapshotHash(es) == result["receipt"]["event_snapshot_hash"]
