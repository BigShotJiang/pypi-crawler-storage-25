"""
Tests for PEP exec and egress engines.
Both engines are factory functions returning {"evaluate": fn, ...} dicts.
Call via pep["evaluate"](...), not pep.evaluate(...).
"""
import pytest
from transient_trace.atp.pep_exec import createExecPep
from transient_trace.atp.pep_egress import createEgressPep


ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}
DENY_ALL  = {"version": 1, "defaultAction": "deny",  "rules": []}

BASE_EXEC = {
    "runId": "run-1", "sessionId": "sess-1",
    "toolName": "bash", "riskTier": "read", "command": "ls /tmp",
}
BASE_EGRESS = {
    "runId": "run-1", "sessionId": "sess-1",
    "toolName": "http_request", "riskTier": "read",
    "host": "api.example.com", "port": 443, "method": "GET", "path": "/v1/data",
}


# ── Exec PEP ─────────────────────────────────────────────────────────────────

class TestExecPepObserveMode:
    def _pep(self, policy=None):
        return createExecPep({"policy": policy or ALLOW_ALL, "config": {"governanceMode": "observe"}})

    def test_allow_all_policy(self):
        result = self._pep()["evaluate"](BASE_EXEC)
        assert result["ok"] is True
        assert result["decision"] == "allow"

    def test_deny_all_policy(self):
        result = createExecPep({"policy": DENY_ALL})["evaluate"](BASE_EXEC)
        assert result["ok"] is False
        assert result["decision"] == "deny"
        assert result["policy"]["reason"] == "policy_default"

    def test_no_token_required_in_observe_mode_even_for_critical(self):
        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {
                "governanceMode": "observe",
                "decisionTokenSecret": "s3cr3t",
                "criticalToolNames": ["bash"],
            },
        })
        result = pep["evaluate"](BASE_EXEC)
        assert result["ok"] is True

    def test_empty_input_uses_defaults(self):
        result = self._pep()["evaluate"]({})
        assert result["ok"] is True
        assert result["decision"] == "allow"

    def test_none_input_uses_defaults(self):
        result = self._pep()["evaluate"](None)
        assert result["ok"] is True

    def test_policy_rule_allow_by_tool_name(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "r1", "action": "allow", "toolNames": ["bash"]}],
        }
        result = createExecPep({"policy": policy})["evaluate"](BASE_EXEC)
        assert result["ok"] is True
        assert result["policy"]["matchedRuleId"] == "r1"

    def test_policy_rule_deny_by_tool_name(self):
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "r-deny", "action": "deny", "toolNames": ["rm"]}],
        }
        result = createExecPep({"policy": policy})["evaluate"]({**BASE_EXEC, "toolName": "rm"})
        assert result["ok"] is False
        assert result["policy"]["matchedRuleId"] == "r-deny"

    def test_governance_control_plane_mutation_blocked(self):
        result = self._pep()["evaluate"]({
            **BASE_EXEC,
            "toolArgs": {"governance": {"package": "governance", "action": "set_policy"}},
        })
        assert result["ok"] is False
        assert result["reason"] == "governance_control_plane_mutation_blocked"

    def test_events_emitted_on_block(self):
        events = []
        pep = createExecPep({"policy": DENY_ALL, "emitEvent": events.append})
        pep["evaluate"](BASE_EXEC)
        assert len(events) == 1
        assert events[0]["eventType"] == "exec_request_blocked"

    def test_events_emitted_on_allow(self):
        events = []
        pep = createExecPep({"policy": ALLOW_ALL, "emitEvent": events.append})
        pep["evaluate"](BASE_EXEC)
        assert len(events) == 1
        assert events[0]["eventType"] == "exec_request_allowed"


class TestExecPepStrictMode:
    def _pep(self, secret="test-secret", extra_cfg=None):
        cfg = {"governanceMode": "strict", "decisionTokenSecret": secret, **(extra_cfg or {})}
        return createExecPep({"policy": ALLOW_ALL, "config": cfg})

    def _mint_token(self, secret, tool, run, session, scope="exec_command"):
        from transient_trace.atp.decision_token_engine import createDecisionTokenEngine
        engine = createDecisionTokenEngine({"secret": secret})
        return engine["mintToken"]({"runId": run, "sessionId": session, "toolName": tool, "scope": scope})

    def test_non_critical_tool_allowed_without_token(self):
        result = self._pep()["evaluate"](BASE_EXEC)
        assert result["ok"] is True

    def test_critical_risk_tier_alone_does_not_require_token(self):
        # riskTier="critical" is not enough on its own to gate a token — the tool
        # must also be in criticalToolNames. A non-governed default-allow tool with
        # critical risk tier passes through via allow_default_non_governed logic.
        result = self._pep()["evaluate"]({**BASE_EXEC, "riskTier": "critical"})
        assert result["ok"] is True

    def test_critical_tool_name_AND_risk_tier_requires_token(self):
        # When the tool is in criticalToolNames, token IS required regardless of policy
        pep = self._pep(extra_cfg={"criticalToolNames": ["bash"]})
        result = pep["evaluate"]({**BASE_EXEC, "riskTier": "critical"})
        assert result["ok"] is False
        assert "token" in result["reason"]

    def test_critical_tool_name_requires_token(self):
        pep = self._pep(extra_cfg={"criticalToolNames": ["bash"]})
        result = pep["evaluate"](BASE_EXEC)
        assert result["ok"] is False
        assert "token" in result["reason"]

    def test_valid_token_allows_critical_tool(self):
        secret = "test-secret"
        token = self._mint_token(secret, "bash", "run-1", "sess-1")
        pep = self._pep(secret=secret, extra_cfg={"criticalToolNames": ["bash"]})
        result = pep["evaluate"]({**BASE_EXEC, "decisionToken": token})
        assert result["ok"] is True

    def test_expired_token_blocks(self):
        secret = "test-secret"
        now_ms = [1_000_000_000_000]
        from transient_trace.atp.decision_token_engine import createDecisionTokenEngine
        engine = createDecisionTokenEngine({"secret": secret, "now": lambda: now_ms[0]})
        token = engine["mintToken"]({"runId": "run-1", "sessionId": "sess-1", "toolName": "bash", "scope": "exec_command", "ttlMs": 100})
        now_ms[0] += 200  # past TTL

        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "strict", "decisionTokenSecret": secret, "criticalToolNames": ["bash"]},
            "now": lambda: now_ms[0],
        })
        result = pep["evaluate"]({**BASE_EXEC, "decisionToken": token})
        assert result["ok"] is False

    def test_wrong_tool_token_blocks(self):
        secret = "test-secret"
        token = self._mint_token(secret, "python", "run-1", "sess-1")
        pep = self._pep(secret=secret, extra_cfg={"criticalToolNames": ["bash"]})
        result = pep["evaluate"]({**BASE_EXEC, "decisionToken": token})
        assert result["ok"] is False

    def test_no_secret_configured_blocks_explicit_critical_tool(self):
        # criticalToolNames set but no decisionTokenSecret → token engine absent → blocked
        pep = createExecPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "strict", "criticalToolNames": ["bash"]},
        })
        result = pep["evaluate"](BASE_EXEC)
        assert result["ok"] is False
        assert "missing_decision_token_secret" in result["reason"]


# ── Egress PEP ───────────────────────────────────────────────────────────────

class TestEgressPepObserveMode:
    def _pep(self, policy=None):
        return createEgressPep({"policy": policy or ALLOW_ALL, "config": {"governanceMode": "observe"}})

    def test_allow_all_policy(self):
        result = self._pep()["evaluate"](BASE_EGRESS)
        assert result["ok"] is True
        assert result["decision"] == "allow"

    def test_deny_all_policy(self):
        result = createEgressPep({"policy": DENY_ALL})["evaluate"](BASE_EGRESS)
        assert result["ok"] is False
        assert result["decision"] == "deny"

    def test_none_input_uses_defaults(self):
        result = self._pep()["evaluate"](None)
        assert result["ok"] is True

    def test_port_string_numeric_accepted(self):
        result = self._pep()["evaluate"]({**BASE_EGRESS, "port": "8080"})
        assert result["ok"] is True

    def test_port_bad_string_falls_back_to_443(self):
        result = self._pep()["evaluate"]({**BASE_EGRESS, "port": "bad-port"})
        assert result["ok"] is True  # ALLOW_ALL; port normalized to 443

    def test_port_none_falls_back_to_443(self):
        result = self._pep()["evaluate"]({**BASE_EGRESS, "port": None})
        assert result["ok"] is True

    def test_host_based_rule(self):
        policy = {
            "version": 1, "defaultAction": "allow",
            "rules": [{"id": "block-evil", "action": "deny", "hosts": ["evil.example.com"]}],
        }
        pep = createEgressPep({"policy": policy})
        blocked = pep["evaluate"]({**BASE_EGRESS, "host": "evil.example.com"})
        allowed = pep["evaluate"]({**BASE_EGRESS, "host": "api.example.com"})
        assert blocked["ok"] is False
        assert allowed["ok"] is True

    def test_governance_control_plane_mutation_blocked(self):
        result = self._pep()["evaluate"]({
            **BASE_EGRESS,
            "toolArgs": {"governance": {"package": "governance", "action": "set_policy"}},
        })
        assert result["ok"] is False
        assert result["reason"] == "governance_control_plane_mutation_blocked"

    def test_ti_claim_gate_blocks_critical_when_missing(self):
        pep = createEgressPep({
            "policy": ALLOW_ALL,
            "config": {
                "governanceMode": "observe",
                "traceTiClaimGateEnabled": True,
                "traceTiFailClosedCritical": True,
            },
        })
        result = pep["evaluate"]({**BASE_EGRESS, "riskTier": "critical"})
        assert result["ok"] is False
        assert result["reason"] == "ti_claim_missing"

    def test_ti_claim_gate_blocks_contradicted(self):
        pep = createEgressPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "observe", "traceTiClaimGateEnabled": True},
        })
        result = pep["evaluate"]({
            **BASE_EGRESS,
            "riskTier": "critical",
            "tiClaimVerification": {"state": "contradicted"},
        })
        assert result["ok"] is False
        assert result["reason"] == "ti_claim_contradicted"

    def test_ti_claim_supported_allows_critical(self):
        pep = createEgressPep({
            "policy": ALLOW_ALL,
            "config": {"governanceMode": "observe", "traceTiClaimGateEnabled": True},
        })
        result = pep["evaluate"]({
            **BASE_EGRESS,
            "riskTier": "critical",
            "tiClaimVerification": {"state": "supported"},
        })
        assert result["ok"] is True

    def test_challenge_triggers_approval_queue(self):
        policy = {
            "version": 1, "defaultAction": "deny",
            "rules": [{"id": "challenge-r", "action": "challenge", "hosts": ["api.example.com"]}],
        }
        pep = createEgressPep({"policy": policy})
        result = pep["evaluate"](BASE_EGRESS)
        assert result["decision"] == "approval_required"
        assert "approvalQueueId" in result

    def test_events_emitted(self):
        events = []
        pep = createEgressPep({"policy": DENY_ALL, "emitEvent": events.append})
        pep["evaluate"](BASE_EGRESS)
        assert any(e["eventType"] == "egress_request_blocked" for e in events)
