"""
Tests for egress action routing — network intents routed through
PepPolicyEngine.requestDecision to the egress PEP, plus intent-to-egress
translation in _intent_to_egress_input.
"""
import pytest

from transient_trace.atp.pep_policy_engine import (
    PepPolicyEngine,
    _intent_to_egress_input,
    _intent_to_exec_input,
)
from transient_trace.Client import Client_init

ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}
DENY_ALL  = {"version": 1, "defaultAction": "deny",  "rules": []}


def _make_network_intent(host="api.example.com", port=443, method="POST", path="/v1/send",
                          action_class="write_high", action="sendRequest",
                          extra_meta=None):
    meta = {"action_type": "network"}
    if extra_meta:
        meta.update(extra_meta)
    return {
        "intent_id": "TI-test-egress",
        "actor_id": "agent-1",
        "connector": "transient-trace-sdk",
        "action": action,
        "action_class": action_class,
        "target": {"host": host, "port": port, "method": method, "path": path},
        "context": {"sessionId": "sess-test", "runId": "run-test"},
        "governance_profile": "sandbox_autonomous",
        "requested_at": "2026-01-01T00:00:00Z",
        "metadata": meta,
    }


def _make_exec_intent(action="executeAction", action_class="write_low",
                       command="ls /tmp", extra_meta=None):
    meta = {}
    if extra_meta:
        meta.update(extra_meta)
    return {
        "intent_id": "TI-test-exec",
        "actor_id": "agent-1",
        "connector": "transient-trace-sdk",
        "action": action,
        "action_class": action_class,
        "target": {"id": "resource-1", "command": command},
        "context": {"sessionId": "sess-test", "runId": "run-test"},
        "governance_profile": "sandbox_autonomous",
        "requested_at": "2026-01-01T00:00:00Z",
        **({"metadata": meta} if meta else {}),
    }


# ── _intent_to_egress_input translation ──────────────────────────────────────

class TestIntentToEgressInput:
    def test_host_port_method_path_extracted(self):
        intent = _make_network_intent(host="api.test.com", port=8080, method="GET", path="/v2/data")
        result = _intent_to_egress_input(intent)
        assert result["host"] == "api.test.com"
        assert result["port"] == 8080
        assert result["method"] == "GET"
        assert result["path"] == "/v2/data"

    def test_run_and_session_from_context(self):
        intent = _make_network_intent()
        result = _intent_to_egress_input(intent)
        assert result["runId"] == "run-test"
        assert result["sessionId"] == "sess-test"

    def test_tool_name_from_action(self):
        intent = _make_network_intent(action="httpPost")
        result = _intent_to_egress_input(intent)
        assert result["toolName"] == "httpPost"

    def test_action_class_write_high_maps_to_risk_tier(self):
        intent = _make_network_intent(action_class="write_high")
        result = _intent_to_egress_input(intent)
        assert result["riskTier"] == "write_high"

    def test_action_class_read_maps_to_read(self):
        intent = _make_network_intent(action_class="read")
        result = _intent_to_egress_input(intent)
        assert result["riskTier"] == "read"

    def test_port_string_coerced_to_int(self):
        intent = _make_network_intent()
        intent["target"]["port"] = "9090"
        result = _intent_to_egress_input(intent)
        assert result["port"] == 9090

    def test_port_bad_string_falls_back_to_443(self):
        intent = _make_network_intent()
        intent["target"]["port"] = "bad"
        result = _intent_to_egress_input(intent)
        assert result["port"] == 443

    def test_decision_token_passed_through(self):
        intent = _make_network_intent(extra_meta={"decisionToken": "tok-abc"})
        result = _intent_to_egress_input(intent)
        assert result["decisionToken"] == "tok-abc"

    def test_ti_claim_verification_passed_through(self):
        claim = {"state": "supported"}
        intent = _make_network_intent(extra_meta={"tiClaimVerification": claim})
        result = _intent_to_egress_input(intent)
        assert result["tiClaimVerification"] == claim

    def test_no_governance_meta_produces_no_tool_args(self):
        intent = _make_network_intent()
        result = _intent_to_egress_input(intent)
        assert "toolArgs" not in result

    def test_governance_meta_in_metadata_produces_tool_args(self):
        intent = _make_network_intent(extra_meta={
            "policyPackage": "messaging",
            "governedAction": "message.send",
            "deliveryMode": "send",
            "recipientTopology": "external",
            "messageClass": "human",
        })
        result = _intent_to_egress_input(intent)
        assert "toolArgs" in result
        gov = result["toolArgs"]["governance"]
        assert gov["package"] == "messaging"
        assert gov["action"] == "message.send"
        assert gov["deliveryMode"] == "send"

    def test_method_uppercased(self):
        intent = _make_network_intent(method="post")
        result = _intent_to_egress_input(intent)
        assert result["method"] == "POST"

    def test_host_lowercased(self):
        intent = _make_network_intent(host="API.EXAMPLE.COM")
        result = _intent_to_egress_input(intent)
        assert result["host"] == "api.example.com"

    def test_path_defaults_to_slash_when_empty(self):
        intent = _make_network_intent(path="")
        result = _intent_to_egress_input(intent)
        assert result["path"] == "/"

    def test_missing_context_falls_back_to_defaults(self):
        intent = _make_network_intent()
        del intent["context"]
        result = _intent_to_egress_input(intent)
        assert result["runId"]  # non-empty fallback
        assert result["sessionId"]  # non-empty fallback


# ── _intent_to_exec_input translation ────────────────────────────────────────

class TestIntentToExecInput:
    def test_action_class_propagated(self):
        intent = _make_exec_intent(action_class="write_low")
        result = _intent_to_exec_input(intent)
        assert result["action_class"] == "write_low"
        assert result["riskTier"] == "write_low"

    def test_delete_action_class_maps_to_critical(self):
        intent = _make_exec_intent(action_class="delete")
        result = _intent_to_exec_input(intent)
        assert result["riskTier"] == "critical"
        assert result["action_class"] == "delete"

    def test_command_extracted_from_target(self):
        intent = _make_exec_intent(command="cat /etc/hosts")
        result = _intent_to_exec_input(intent)
        assert result["command"] == "cat /etc/hosts"

    def test_run_session_from_context(self):
        intent = _make_exec_intent()
        result = _intent_to_exec_input(intent)
        assert result["runId"] == "run-test"
        assert result["sessionId"] == "sess-test"

    def test_decision_token_passed_through(self):
        intent = _make_exec_intent(extra_meta={"decisionToken": "tk-xyz"})
        result = _intent_to_exec_input(intent)
        assert result["decisionToken"] == "tk-xyz"

    def test_no_governance_produces_no_tool_args(self):
        intent = _make_exec_intent()
        result = _intent_to_exec_input(intent)
        assert "toolArgs" not in result

    def test_governance_metadata_produces_tool_args(self):
        intent = _make_exec_intent(extra_meta={
            "policyPackage": "messaging",
            "governedAction": "message.send",
            "deliveryMode": "send",
            "recipientTopology": "external",
            "messageClass": "human",
        })
        result = _intent_to_exec_input(intent)
        assert "toolArgs" in result
        gov = result["toolArgs"]["governance"]
        assert gov["package"] == "messaging"


# ── PepPolicyEngine routing ───────────────────────────────────────────────────

class TestPepPolicyEngineEgressRouting:
    def test_network_intent_routes_to_egress_and_is_allowed(self):
        engine = PepPolicyEngine(policy=ALLOW_ALL)
        intent = _make_network_intent()
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "allow"
        assert decision["intent_id"] == "TI-test-egress"

    def test_network_intent_routes_to_egress_and_is_denied(self):
        engine = PepPolicyEngine(policy=DENY_ALL)
        intent = _make_network_intent()
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "deny"

    def test_exec_intent_routes_to_exec_pep_and_is_allowed(self):
        engine = PepPolicyEngine(policy=ALLOW_ALL)
        intent = _make_exec_intent()
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "allow"
        assert decision["intent_id"] == "TI-test-exec"

    def test_exec_intent_routes_to_exec_pep_and_is_denied(self):
        engine = PepPolicyEngine(policy=DENY_ALL)
        intent = _make_exec_intent()
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "deny"

    def test_decision_has_required_atp_fields(self):
        engine = PepPolicyEngine(policy=ALLOW_ALL)
        intent = _make_network_intent()
        decision = engine.requestDecision(intent)
        for field in ("decision_id", "intent_id", "outcome", "reason_code", "decided_at"):
            assert field in decision

    def test_host_deny_rule_blocks_matching_network_intent(self):
        policy = {
            "version": 1,
            "defaultAction": "allow",
            "rules": [{"id": "block-evil", "action": "deny", "kind": "egress", "hosts": ["evil.example.com"]}],
        }
        engine = PepPolicyEngine(policy=policy)
        intent = _make_network_intent(host="evil.example.com")
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "deny"
        assert decision.get("rule_id") == "block-evil"

    def test_host_deny_rule_does_not_block_other_hosts(self):
        policy = {
            "version": 1,
            "defaultAction": "allow",
            "rules": [{"id": "block-evil", "action": "deny", "kind": "egress", "hosts": ["evil.example.com"]}],
        }
        engine = PepPolicyEngine(policy=policy)
        intent = _make_network_intent(host="safe.example.com")
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "allow"

    def test_approval_required_outcome_for_challenge_rule(self):
        policy = {
            "version": 1,
            "defaultAction": "allow",
            "rules": [{"id": "challenge-api", "action": "challenge", "kind": "egress", "hosts": ["api.example.com"]}],
        }
        engine = PepPolicyEngine(policy=policy)
        intent = _make_network_intent(host="api.example.com")
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "approve"

    def test_matched_rule_id_propagated_to_decision(self):
        policy = {
            "version": 1,
            "defaultAction": "deny",
            "rules": [{"id": "allow-api", "action": "allow", "kind": "egress", "hosts": ["api.example.com"]}],
        }
        engine = PepPolicyEngine(policy=policy)
        intent = _make_network_intent(host="api.example.com")
        decision = engine.requestDecision(intent)
        assert decision["outcome"] == "allow"
        assert decision.get("rule_id") == "allow-api"


# ── Full Client integration with network action ───────────────────────────────

class TestClientNetworkIntegration:
    def _client(self, policy=ALLOW_ALL):
        return Client_init({
            "agentId": "test-agent-egress",
            "policy": policy,
        })

    def test_network_action_allowed_and_receipt_signed(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: {"status": 200},
            {
                "action": "sendRequest",
                "action_type": "network",
                "action_class": "write_high",
                "target": {"host": "api.example.com", "port": 443, "method": "POST", "path": "/v1/data"},
            },
        )
        assert result["output"] == {"status": 200}
        assert result["receipt"]["execution_status"] == "executed"
        sig = result["receipt"]["signature"]
        assert sig["alg"] == "Ed25519"

    def test_network_action_denied_raises(self):
        client = self._client(policy=DENY_ALL)
        with pytest.raises(RuntimeError, match="Denied"):
            client.executeActionWithReceipt(
                lambda: {"status": 200},
                {
                    "action": "sendRequest",
                    "action_type": "network",
                    "action_class": "write_high",
                    "target": {"host": "api.example.com", "port": 443, "method": "POST", "path": "/v1/data"},
                },
            )

    def test_network_intent_id_in_receipt(self):
        client = self._client()
        result = client.executeActionWithReceipt(
            lambda: None,
            {
                "action": "getResource",
                "action_type": "network",
                "action_class": "read",
                "target": {"host": "api.example.com", "port": 443, "method": "GET", "path": "/v1/resource"},
            },
        )
        assert result["intent"]["action_class"] == "read"
        assert result["decision"]["outcome"] == "allow"
