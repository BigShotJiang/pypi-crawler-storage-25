"""
test_edge_cases.py — Edge cases, boundary conditions, and adversarial inputs.

Covers angles not exercised by the happy-path tests:
  - Concurrency: simultaneous writes, distill-while-write, mark_promoted races
  - Persistence: promoted state lost on engine restart
  - Malformed inputs: empty strings, None fields, bad timestamps, handler exceptions
  - Pattern lifecycle: confidence drops after promotion, exact thresholds
  - Audit: zero-receipt bundles, deny-event-only reports, query limit
  - Client: missing state_dir, handler returns None, target as string, no action_class
  - Internal field hygiene: _pattern_key must never leak into inject output
"""

import json
import time
import threading
import pytest
import transient_trace
from transient_trace.receipt_engine import ReceiptEngine
from transient_trace.receipt_engine.store import ReceiptStore
from transient_trace.receipt_engine.distiller import PatternDistiller
from transient_trace.receipt_engine.audit import ReceiptAuditor
from transient_trace.atp.package_registry import PackageRegistry

_ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}

_DENY_PKG = {
    "name": "edge-deny",
    "version": "1.0.0",
    "rules": [{"id": "deny-write", "profile": "exec",
               "condition": {"action_class": "write_low"},
               "outcome": "deny", "reason": "test"}],
}


def _receipt(rid, action_class="filesystem", tool_name="write_file",
             outcome="deny", ts=None):
    return {
        "receipt_id": rid,
        "action_class": action_class,
        "tool_name": tool_name,
        "outcome": outcome,
        "matched_rule_id": "rule-1",
        "matched_rule_reason": "test reason",
        "matched_package": "test-pkg",
        # Explicit None check — 0.0 (Unix epoch) is a valid timestamp but falsy
        "ts": time.time() if ts is None else ts,
        "signature": {"alg": "Ed25519", "kid": "k", "sig": f"sig-{rid}"},
    }


def _client(tmp_path, packages=None, mode="audit", trigger=3):
    cfg = {
        "pepPolicy": _ALLOW_ALL,
        "mode": mode,
        "state_dir": str(tmp_path),
        "learning": {"enabled": True, "distill_trigger_count": trigger},
    }
    if packages:
        cfg["packages"] = packages
    return transient_trace.Client(cfg)


# ---------------------------------------------------------------------------
# Concurrency
# ---------------------------------------------------------------------------

class TestConcurrentWrites:

    def test_simultaneous_writes_all_land(self, tmp_path):
        """10 threads writing simultaneously — all 10 receipts must be stored."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        errors = []

        def write_one(i):
            try:
                store.write(_receipt(f"r-{i:04d}"))
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=write_one, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Concurrent write errors: {errors}"
        assert store.count() == 10

    def test_concurrent_writes_no_duplicate_ids(self, tmp_path):
        """Concurrent writes with same receipt_id — INSERT OR IGNORE, count stays 1."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        results = []

        def write_same(i):
            try:
                store.write(_receipt("fixed-id"))
                results.append("ok")
            except Exception as exc:
                results.append(f"err:{exc}")

        threads = [threading.Thread(target=write_same, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert store.count() == 1, "Duplicate IDs should be de-duped by INSERT OR IGNORE"

    def test_distill_while_concurrent_writes(self, tmp_path):
        """Distiller running on background thread while writes arrive — no crash, count consistent."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        distiller = PatternDistiller(store, trigger_count=3)
        distiller.start()
        errors = []

        def write_batch(batch):
            for r in batch:
                try:
                    store.write(r)
                except Exception as exc:
                    errors.append(exc)

        batches = [
            [_receipt(f"b{b}-{i}") for i in range(5)]
            for b in range(4)
        ]
        threads = [threading.Thread(target=write_batch, args=(b,)) for b in batches]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        distiller.stop()

        assert errors == [], f"Errors during concurrent write+distill: {errors}"
        assert store.count() == 20

    def test_concurrent_client_calls(self, tmp_path):
        """executeActionWithReceipt from 8 threads simultaneously — all receipts stored."""
        client = _client(tmp_path)
        errors = []

        def call_one(i):
            try:
                client.executeActionWithReceipt(
                    lambda: f"output-{i}",
                    {"action": f"tool_{i}", "action_class": "read", "target": "x"},
                )
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=call_one, args=(i,)) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Concurrent client call errors: {errors}"
        assert client._receipt_engine.stats()["total_receipts"] == 8


# ---------------------------------------------------------------------------
# Persistence: engine restart
# ---------------------------------------------------------------------------

class TestPersistenceAfterRestart:

    def test_receipts_survive_engine_restart(self, tmp_path):
        """Receipts written to SQLite persist across ReceiptEngine instances."""
        db = tmp_path / "r.db"
        e1 = ReceiptEngine(db_path=db)
        for i in range(5):
            e1.store(_receipt(f"r-{i}"))
        e1.stop()

        e2 = ReceiptEngine(db_path=db)
        assert e2.stats()["total_receipts"] == 5

    def test_query_works_after_restart(self, tmp_path):
        """Receipts from before restart are fully queryable after restart."""
        db = tmp_path / "r.db"
        e1 = ReceiptEngine(db_path=db)
        for i in range(3):
            e1.store(_receipt(f"r-{i}", action_class="web", outcome="allow"))
        e1.stop()

        e2 = ReceiptEngine(db_path=db)
        results = e2.query(action_class="web")
        assert len(results) == 3

    def test_promotion_re_fires_on_restart_with_same_receipts(self, tmp_path):
        """
        After restart, distill() re-promotes eligible patterns from the persisted receipts.

        The promoter's _promoted_rule_ids set is in-memory only — it is empty after restart.
        But the receipt data in SQLite survives, so distill() re-distills the same patterns
        and the promoter fires again, writing the rule to the new (empty) registry and
        calling mark_promoted() so patterns show promoted=True.

        Consequence: if the same application restarts with a fresh PackageRegistry,
        learned rules are re-promoted automatically from historical receipts.
        This is the correct self-healing behaviour for stateless runtime restarts.
        """
        db = tmp_path / "r.db"
        registry = PackageRegistry()
        e1 = ReceiptEngine(
            db_path=db, registry=registry,
            distill_trigger_count=50, promote_min_confidence=0.95, promote_min_count=50,
        )
        for i in range(50):
            e1.store(_receipt(f"r-{i:04d}"))
        e1.distill()
        assert "learned" in registry._packages, "Promotion should have fired on first engine"
        e1.stop()

        # Reopen on same DB — fresh registry, but receipts still in SQLite
        registry2 = PackageRegistry()
        e2 = ReceiptEngine(
            db_path=db, registry=registry2,
            distill_trigger_count=50, promote_min_confidence=0.95, promote_min_count=50,
        )
        e2.distill()

        # Receipts survive restart
        assert e2.stats()["total_receipts"] == 50

        # Promoter re-fires from historical receipts — patterns marked promoted=True
        patterns = e2.distiller.get_patterns()
        promoted = [p for p in patterns if p.get("promoted")]
        assert len(promoted) >= 1, (
            "After restart with same receipts, distill() should re-promote eligible patterns"
        )
        # Learned package re-created in fresh registry
        assert "learned" in registry2._packages

    def test_inject_works_before_first_distill_after_restart(self, tmp_path):
        """After restart, inject() returns '' until distill() is called — correct cold-start."""
        db = tmp_path / "r.db"
        e1 = ReceiptEngine(db_path=db, distill_trigger_count=3)
        for i in range(5):
            e1.store(_receipt(f"r-{i}"))
        e1.distill()
        assert e1.inject(action_class="filesystem") != ""  # patterns exist in e1
        e1.stop()

        e2 = ReceiptEngine(db_path=db, distill_trigger_count=3)
        # Before distill: in-memory patterns are empty
        assert e2.inject(action_class="filesystem") == "", \
            "Before first distill after restart inject should be empty"
        # After distill: patterns reload from DB
        e2.distill()
        assert e2.inject(action_class="filesystem") != "", \
            "After distill inject should produce output"


# ---------------------------------------------------------------------------
# Malformed and boundary inputs
# ---------------------------------------------------------------------------

class TestMalformedInputs:

    def test_receipt_with_none_action_class(self, tmp_path):
        """Receipt with action_class=None is stored; distiller skips it (no indexable context)."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        store.write({
            "receipt_id": "no-ac",
            "action_class": None,
            "tool_name": None,
            "outcome": "allow",
            "ts": time.time(),
            "signature": {"alg": "Ed25519", "kid": "k", "sig": "s"},
        })
        assert store.count() == 1
        distiller = PatternDistiller(store, trigger_count=1)
        distiller.run()
        # No indexable context — pattern should not appear
        assert distiller.get_patterns() == []

    def test_receipt_with_empty_string_action_class(self, tmp_path):
        """Empty string action_class is treated same as None by distiller."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        store.write({
            "receipt_id": "empty-ac",
            "action_class": "",
            "tool_name": "",
            "outcome": "deny",
            "ts": time.time(),
            "signature": {"alg": "Ed25519", "kid": "k", "sig": "s"},
        })
        distiller = PatternDistiller(store, trigger_count=1)
        distiller.run()
        assert distiller.get_patterns() == [], \
            "Empty string action_class should not produce patterns (no indexable context)"

    def test_receipt_missing_signature_raises(self, tmp_path):
        """Store rejects receipts without a signature field."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        with pytest.raises(ValueError, match="signature"):
            store.write({"receipt_id": "no-sig", "action_class": "fs",
                         "tool_name": "write", "outcome": "deny", "ts": time.time()})

    def test_receipt_with_empty_signature_dict_accepted(self, tmp_path):
        """Store accepts receipts with an empty signature dict — validation is external."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        store.write({
            "receipt_id": "empty-sig",
            "action_class": "filesystem",
            "tool_name": "write_file",
            "outcome": "deny",
            "ts": time.time(),
            "signature": {},  # empty but present
        })
        assert store.count() == 1

    def test_receipt_with_past_timestamp(self, tmp_path):
        """Receipts with very old timestamps (Unix epoch) are stored and queryable."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        store.write(_receipt("old", ts=0.0))  # Unix epoch
        auditor = ReceiptAuditor(store)
        results = auditor.query(from_ts=0.0, to_ts=1.0)
        assert len(results) == 1

    def test_receipt_with_future_timestamp(self, tmp_path):
        """Receipts with far-future timestamps are stored without error."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        store.write(_receipt("future", ts=9_999_999_999.0))  # year 2286
        assert store.count() == 1

    def test_receipt_with_very_long_strings(self, tmp_path):
        """Very long action_class / tool_name strings are stored without truncation."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        long_ac = "x" * 1000
        long_tool = "y" * 1000
        store.write({
            "receipt_id": "long",
            "action_class": long_ac,
            "tool_name": long_tool,
            "outcome": "allow",
            "ts": time.time(),
            "signature": {"alg": "Ed25519", "kid": "k", "sig": "s"},
        })
        results = store.query(action_class=long_ac)
        assert len(results) == 1
        assert results[0]["action_class"] == long_ac

    def test_handler_exception_still_writes_receipt(self, tmp_path):
        """When handler raises, the action receipt is still stored in the engine."""
        client = _client(tmp_path)

        def boom():
            raise ValueError("handler exploded")

        with pytest.raises(ValueError, match="handler exploded"):
            client.executeActionWithReceipt(
                boom,
                {"action": "write_file", "action_class": "filesystem", "target": "x"},
            )

        receipts = client._receipt_engine.query()
        assert len(receipts) == 1, "Receipt must be stored even when handler raises"
        assert receipts[0].get("action_class") == "filesystem"

    def test_handler_returns_none(self, tmp_path):
        """Handler returning None produces a valid receipt."""
        client = _client(tmp_path)
        result = client.executeActionWithReceipt(
            lambda: None,
            {"action": "read_file", "action_class": "read", "target": "x"},
        )
        assert result["output"] is None
        assert client._receipt_engine.stats()["total_receipts"] == 1

    def test_target_as_string_not_dict(self, tmp_path):
        """Target provided as a string (not dict) — no crash, receipt stored correctly."""
        client = _client(tmp_path)
        result = client.executeActionWithReceipt(
            lambda: "ok",
            {"action": "read_file", "action_class": "read", "target": "/some/path"},
        )
        assert result["output"] == "ok"
        receipts = client._receipt_engine.query()
        assert len(receipts) == 1

    def test_exec_input_missing_action_class(self, tmp_path):
        """exec_input with no action_class defaults gracefully — receipt stored."""
        client = _client(tmp_path)
        result = client.executeActionWithReceipt(
            lambda: "ok",
            {"action": "some_tool", "target": "x"},  # no action_class
        )
        assert result["output"] == "ok"
        assert client._receipt_engine.stats()["total_receipts"] == 1

    def test_missing_state_dir_created_on_init(self, tmp_path):
        """Learning enabled with non-existent state_dir — dir and db are created."""
        new_dir = tmp_path / "deep" / "nested" / "state"
        assert not new_dir.exists()
        client = _client(new_dir)
        assert new_dir.exists()
        assert (new_dir / "receipt_engine.db").exists()


# ---------------------------------------------------------------------------
# Pattern lifecycle edge cases
# ---------------------------------------------------------------------------

class TestPatternLifecycle:

    def test_confidence_exactly_at_inject_threshold(self, tmp_path):
        """Pattern with confidence exactly 0.7 is included in inject (>= 0.7).

        Use distinct rule_ids for deny vs allow so they don't mark each other
        ambiguous (ambiguous = both outcomes for same action+tool+rule_id tuple).
        """
        engine = ReceiptEngine(db_path=tmp_path / "r.db", distill_trigger_count=3)
        for i in range(7):
            engine.store({
                "receipt_id": f"d-{i}", "action_class": "filesystem",
                "tool_name": "write_file", "outcome": "deny",
                "matched_rule_id": "deny-rule", "matched_rule_reason": "blocked",
                "matched_package": "pkg", "ts": time.time(),
                "signature": {"alg": "Ed25519", "kid": "k", "sig": f"sd{i}"},
            })
        for i in range(3):
            engine.store({
                "receipt_id": f"a-{i}", "action_class": "filesystem",
                "tool_name": "write_file", "outcome": "allow",
                "matched_rule_id": None, "matched_rule_reason": None,
                "matched_package": None, "ts": time.time(),
                "signature": {"alg": "Ed25519", "kid": "k", "sig": f"sa{i}"},
            })
        engine.distill()
        patterns = engine.distiller.get_patterns()
        deny_p = next((p for p in patterns if p["outcome"] == "deny"), None)
        assert deny_p is not None
        assert deny_p["confidence"] == 0.7
        assert not deny_p["ambiguous"], "deny pattern must not be ambiguous (different rule_ids)"
        inject = engine.inject(action_class="filesystem")
        assert inject != "", "Pattern at exactly 0.7 confidence should appear in inject"

    def test_confidence_just_below_inject_threshold_excluded(self, tmp_path):
        """Pattern with confidence 0.69 is excluded from inject (< 0.7)."""
        engine = ReceiptEngine(db_path=tmp_path / "r.db", distill_trigger_count=3)
        # 69 deny + 31 allow = 69% deny
        for i in range(69):
            engine.store(_receipt(f"d-{i:04d}", outcome="deny"))
        for i in range(31):
            engine.store(_receipt(f"a-{i:04d}", outcome="allow"))
        engine.distill()
        inject = engine.inject(action_class="filesystem", tool_name="write_file")
        # deny pattern confidence = 0.69 — below threshold
        # allow pattern confidence = 0.31 — also below threshold
        assert inject == "", f"Pattern at 0.69 confidence should be excluded, got: {inject!r}"

    def test_confidence_exactly_at_promotion_threshold(self, tmp_path):
        """Pattern at exactly 0.95 confidence must promote.

        95 deny + 5 allow = 100 total.
        deny pattern: count=95, confidence=0.95 exactly.
        promote_min_count=95 so count check also passes.
        """
        registry = PackageRegistry()
        engine = ReceiptEngine(
            db_path=tmp_path / "r.db", registry=registry,
            distill_trigger_count=100, promote_min_confidence=0.95, promote_min_count=95,
        )
        # 95 deny + 5 allow = exactly 0.95 confidence on deny pattern.
        # Use distinct rule_ids so allow receipts don't mark the deny pattern ambiguous.
        for i in range(95):
            engine.store({
                "receipt_id": f"d-{i:04d}", "action_class": "filesystem",
                "tool_name": "write_file", "outcome": "deny",
                "matched_rule_id": "deny-rule", "matched_rule_reason": "blocked",
                "matched_package": "pkg", "ts": time.time(),
                "signature": {"alg": "Ed25519", "kid": "k", "sig": f"sd{i}"},
            })
        for i in range(5):
            engine.store({
                "receipt_id": f"a-{i:04d}", "action_class": "filesystem",
                "tool_name": "write_file", "outcome": "allow",
                "matched_rule_id": None, "matched_rule_reason": None,
                "matched_package": None, "ts": time.time(),
                "signature": {"alg": "Ed25519", "kid": "k", "sig": f"sa{i}"},
            })
        engine.distill()
        assert "learned" in registry._packages, \
            "Pattern at exactly 0.95 confidence should promote (>= threshold)"

    def test_pattern_stays_promoted_when_confidence_drops(self, tmp_path):
        """Once promoted, pattern stays promoted even if confidence drops below threshold."""
        registry = PackageRegistry()
        engine = ReceiptEngine(
            db_path=tmp_path / "r.db", registry=registry,
            distill_trigger_count=50, promote_min_confidence=0.95, promote_min_count=50,
        )
        # 50 denies → promote
        for i in range(50):
            engine.store(_receipt(f"d-{i:04d}", outcome="deny"))
        engine.distill()
        assert "learned" in registry._packages

        # Now flood with 200 allows — deny confidence drops to 50/250 = 0.2
        for i in range(200):
            engine.store(_receipt(f"a-{i:04d}", outcome="allow"))
        engine.distill()

        patterns = engine.distiller.get_patterns()
        deny_p = next((p for p in patterns if p["outcome"] == "deny"), None)
        assert deny_p is not None
        assert deny_p["promoted"] is True, \
            "Promoted pattern must stay promoted even after confidence drops"
        # Injector must still skip it
        inject = engine.inject(action_class="filesystem", tool_name="write_file")
        assert inject == "", "Promoted pattern must still produce zero inject tokens"

    def test_pattern_key_does_not_leak_into_inject_string(self, tmp_path):
        """Internal _pattern_key field must never appear in the inject output string."""
        engine = ReceiptEngine(db_path=tmp_path / "r.db", distill_trigger_count=3)
        for i in range(5):
            engine.store(_receipt(f"r-{i}"))
        engine.distill()
        inject = engine.inject(action_class="filesystem")
        assert "_pattern_key" not in inject, \
            f"Internal _pattern_key leaked into inject output: {inject!r}"

    def test_pattern_key_present_in_get_patterns_but_internal(self, tmp_path):
        """_pattern_key is present in pattern dicts (for internal use) but callers must ignore it."""
        engine = ReceiptEngine(db_path=tmp_path / "r.db", distill_trigger_count=3)
        for i in range(5):
            engine.store(_receipt(f"r-{i}"))
        engine.distill()
        patterns = engine.distiller.get_patterns()
        assert len(patterns) >= 1
        for p in patterns:
            # _pattern_key exists (used internally for mark_promoted lookup)
            assert "_pattern_key" in p
            # But it must be a string, not empty
            assert isinstance(p["_pattern_key"], str)
            assert len(p["_pattern_key"]) > 0

    def test_multiple_patterns_same_action_class_different_rules(self, tmp_path):
        """Two rules firing on same action_class produce separate patterns."""
        engine = ReceiptEngine(db_path=tmp_path / "r.db", distill_trigger_count=3)
        for i in range(4):
            engine.store({
                "receipt_id": f"r1-{i}", "action_class": "filesystem",
                "tool_name": "write_file", "outcome": "deny",
                "matched_rule_id": "rule-A", "matched_rule_reason": "reason A",
                "matched_package": "pkg", "ts": time.time(),
                "signature": {"alg": "Ed25519", "kid": "k", "sig": f"s{i}"},
            })
        for i in range(4):
            engine.store({
                "receipt_id": f"r2-{i}", "action_class": "filesystem",
                "tool_name": "write_file", "outcome": "deny",
                "matched_rule_id": "rule-B", "matched_rule_reason": "reason B",
                "matched_package": "pkg", "ts": time.time(),
                "signature": {"alg": "Ed25519", "kid": "k", "sig": f"t{i}"},
            })
        engine.distill()
        patterns = engine.distiller.get_patterns()
        rule_ids = {p["rule_id"] for p in patterns if p.get("action_class") == "filesystem"}
        assert "rule-A" in rule_ids
        assert "rule-B" in rule_ids


# ---------------------------------------------------------------------------
# Audit edge cases
# ---------------------------------------------------------------------------

class TestAuditEdgeCases:

    def test_export_bundle_with_zero_receipts(self, tmp_path):
        """export_bundle on empty store produces valid JSON with empty receipts list."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        auditor = ReceiptAuditor(store)
        out = tmp_path / "empty.json"
        result = auditor.export_bundle(path=out)
        assert out.exists()
        bundle = json.loads(out.read_text())
        assert bundle["receipts"] == []
        assert bundle["manifest"]["receipt_count"] == 0
        assert result["receipt_count"] == 0

    def test_explain_with_only_governance_deny_events(self, tmp_path):
        """explain() on a store containing only governance-deny-event receipts works correctly."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        for i in range(5):
            store.write({
                "receipt_id": f"de-{i}",
                "receipt_type": "governance-deny-event",
                "action_class": "filesystem",
                "tool_name": "write_file",
                "outcome": "deny",
                "matched_rule_id": "deny-fs",
                "matched_rule_reason": "blocked",
                "matched_package": "test",
                "ts": time.time(),
                "signature": {"alg": "none", "kid": "governance-pep", "decision_id": f"d-{i}"},
            })
        auditor = ReceiptAuditor(store)
        report = auditor.explain()
        assert report["summary"]["total"] == 5
        assert report["summary"]["outcomes"]["deny"] == 5
        assert report["summary"]["deny_rate"] == 1.0
        assert len(report["denies"]) == 5
        assert report["top_rules"][0]["rule_id"] == "deny-fs"

    def test_query_limit_respected(self, tmp_path):
        """query(limit=3) returns exactly 3 when 10 receipts exist."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        for i in range(10):
            store.write(_receipt(f"r-{i:04d}"))
        auditor = ReceiptAuditor(store)
        results = auditor.query(limit=3)
        assert len(results) == 3

    def test_explain_deny_rate_calculation(self, tmp_path):
        """deny_rate = denies / total, not denies / allows."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        for i in range(3):
            store.write(_receipt(f"d-{i}", outcome="deny"))
        for i in range(7):
            store.write(_receipt(f"a-{i}", outcome="allow"))
        auditor = ReceiptAuditor(store)
        report = auditor.explain()
        assert report["summary"]["total"] == 10
        assert abs(report["summary"]["deny_rate"] - 0.3) < 0.001

    def test_export_bundle_report_consistent_with_explain(self, tmp_path):
        """Bundle report and standalone explain() must have same total and manifest hash."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        for i in range(5):
            store.write(_receipt(f"r-{i}"))
        auditor = ReceiptAuditor(store)
        out = tmp_path / "bundle.json"
        auditor.export_bundle(path=out)
        bundle = json.loads(out.read_text())
        standalone = auditor.explain()
        assert bundle["report"]["summary"]["total"] == standalone["summary"]["total"]
        assert bundle["report"]["verification"]["manifest_hash"] == \
               standalone["verification"]["manifest_hash"]

    def test_query_outcome_filter_exact_match(self, tmp_path):
        """query(outcome="deny") must not return "allow" receipts."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        for i in range(5):
            store.write(_receipt(f"d-{i}", outcome="deny"))
        for i in range(5):
            store.write(_receipt(f"a-{i}", outcome="allow"))
        auditor = ReceiptAuditor(store)
        denies = auditor.query(outcome="deny")
        allows = auditor.query(outcome="allow")
        assert len(denies) == 5
        assert len(allows) == 5
        assert all(r["outcome"] == "deny" for r in denies)
        assert all(r["outcome"] == "allow" for r in allows)

    def test_explain_empty_window_returns_no_summary_error(self, tmp_path):
        """explain() on time window with no receipts returns graceful empty summary."""
        store = ReceiptStore(db_path=tmp_path / "r.db")
        for i in range(5):
            store.write(_receipt(f"r-{i}", ts=1_000_000.0))  # old receipts
        auditor = ReceiptAuditor(store)
        report = auditor.explain(from_ts=time.time(), to_ts=time.time() + 1)
        assert report["summary"]["total"] == 0
        assert "message" in report["summary"]


# ---------------------------------------------------------------------------
# Client edge cases
# ---------------------------------------------------------------------------

class TestClientEdgeCases:

    def test_permissive_mode_would_be_deny_still_captured(self, tmp_path):
        """In permissive mode, would-be denials are stored as 'deny' in the engine."""
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": [_DENY_PKG],
            "mode": "permissive",
            "state_dir": str(tmp_path),
            "learning": {"enabled": True, "distill_trigger_count": 3},
        })
        result = client.executeActionWithReceipt(
            lambda: "ok",
            {"action": "write_file", "action_class": "write_low", "target": "x"},
        )
        assert result["output"] == "ok"  # permissive — never blocked
        receipts = client._receipt_engine.query()
        assert len(receipts) == 1
        # Engine must have captured the governance signal (deny), not the execution outcome (allow)
        assert receipts[0]["outcome"] == "deny", (
            f"Permissive mode: engine should record governance intent 'deny', "
            f"got '{receipts[0]['outcome']}'"
        )

    def test_strict_deny_receipt_type_is_governance_event(self, tmp_path):
        """In strict mode, the deny receipt has receipt_type='governance-deny-event'."""
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "packages": [_DENY_PKG],
            "mode": "strict",
            "state_dir": str(tmp_path),
            "learning": {"enabled": True, "distill_trigger_count": 3},
        })
        with pytest.raises(RuntimeError, match="Denied"):
            client.executeActionWithReceipt(
                lambda: "ok",
                {"action": "write_file", "action_class": "write_low", "target": "x"},
            )
        receipts = client._receipt_engine.query()
        assert len(receipts) == 1
        r = receipts[0]
        assert r.get("receipt_type") == "governance-deny-event"
        assert r["outcome"] == "deny"
        assert r["signature"]["alg"] == "none"

    def test_learning_disabled_no_receipt_engine(self, tmp_path):
        """Client without learning config has no receipt engine — zero overhead."""
        client = transient_trace.Client({
            "pepPolicy": _ALLOW_ALL,
            "state_dir": str(tmp_path),
        })
        assert client._receipt_engine is None
        # Must not raise
        result = client.executeActionWithReceipt(
            lambda: "ok",
            {"action": "read_file", "action_class": "read", "target": "x"},
        )
        assert result["output"] == "ok"

    def test_receipt_engine_attribute_accessible(self, tmp_path):
        """_receipt_engine is accessible on Client for test and integration use."""
        client = _client(tmp_path)
        engine = client._receipt_engine
        assert engine is not None
        assert hasattr(engine, "store")
        assert hasattr(engine, "query")
        assert hasattr(engine, "explain")

    def test_multiple_actions_different_classes_all_stored(self, tmp_path):
        """Actions across different action classes all produce separate receipts."""
        client = _client(tmp_path)
        classes = ["read", "write_low", "exec", "filesystem", "web"]
        for ac in classes:
            client.executeActionWithReceipt(
                lambda: "ok",
                {"action": f"tool_{ac}", "action_class": ac, "target": "x"},
            )
        receipts = client._receipt_engine.query()
        stored_classes = {r["action_class"] for r in receipts}
        assert stored_classes == set(classes)
