"""
Tests for governed_action_normalize and connector_governance_adapters.
"""
import pytest
from transient_trace.atp.governed_action_normalize import normalizeGovernanceFromToolArgs
from transient_trace.atp.connector_governance_adapters import (
    inferGovernedHistoryToolCall,
    isLikelyMessagingExecCommand,
)


class TestNormalizeGovernance:
    def test_no_governance_field_returns_not_governed(self):
        result = normalizeGovernanceFromToolArgs({}, {"toolName": "bash"})
        assert result["isGovernedTool"] is False
        assert result["controlPlaneMutationAttempt"] is False
        assert result["missingRequiredDimensions"] == []
        assert result["mismatchedCanonicalFields"] == []

    def test_known_tool_message_send(self):
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "messaging", "action": "message.send",
                            "deliveryMode": "send", "recipientTopology": "direct", "messageClass": "notification"}},
            {"toolName": "message_send"},
        )
        assert result["isGovernedTool"] is True
        assert result["policyPackage"] == "messaging"
        assert result["governedAction"] == "message.send"
        assert result["missingRequiredDimensions"] == []

    def test_known_tool_missing_required_dimensions(self):
        # message_send requires recipientTopology and messageClass — omit both
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "messaging", "action": "message.send", "deliveryMode": "send"}},
            {"toolName": "message_send"},
        )
        assert result["isGovernedTool"] is True
        missing = result["missingRequiredDimensions"]
        assert "recipientTopology" in missing
        assert "messageClass" in missing

    def test_known_tool_mismatched_canonical_field(self):
        # deliveryMode "draft" doesn't match profile's "send"
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "messaging", "action": "message.send",
                            "deliveryMode": "draft",  # wrong
                            "recipientTopology": "direct", "messageClass": "notification"}},
            {"toolName": "message_send"},
        )
        assert "deliveryMode" in result["mismatchedCanonicalFields"]

    def test_control_plane_package_blocked(self):
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "governance", "action": "anything"}},
            {"toolName": "bash"},
        )
        assert result["controlPlaneMutationAttempt"] is True

    def test_control_plane_action_pattern_blocked(self):
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "messaging", "action": "set_policy"}},
            {"toolName": "bash"},
        )
        assert result["controlPlaneMutationAttempt"] is True

    def test_none_args_treated_as_empty(self):
        result = normalizeGovernanceFromToolArgs(None, {"toolName": "bash"})
        assert result["isGovernedTool"] is False

    def test_non_dict_args_treated_as_empty(self):
        result = normalizeGovernanceFromToolArgs("not-a-dict", {"toolName": "bash"})
        assert result["isGovernedTool"] is False

    def test_message_draft_no_required_dimensions(self):
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "messaging", "action": "message.draft", "deliveryMode": "draft"}},
            {"toolName": "message_draft"},
        )
        assert result["isGovernedTool"] is True
        assert result["missingRequiredDimensions"] == []

    def test_unknown_tool_name_not_governed(self):
        result = normalizeGovernanceFromToolArgs(
            {"governance": {"package": "custom", "action": "do_thing"}},
            {"toolName": "my_custom_tool"},
        )
        assert result["isGovernedTool"] is False


class TestConnectorGovernanceAdapters:
    def test_infer_returns_none_for_unknown_tool(self):
        result = inferGovernedHistoryToolCall({
            "rawToolName": "unknown_tool_xyz",
            "rawArgs": {},
            "command": "",
        })
        assert result is None

    def test_likely_messaging_command_detected(self):
        # noun + verb with word boundaries (space-separated)
        assert isLikelyMessagingExecCommand({"command": "himalaya send", "toolName": ""}) is True
        assert isLikelyMessagingExecCommand({"command": "send email to team", "toolName": ""}) is True
        assert isLikelyMessagingExecCommand({"command": "draft message to alice", "toolName": ""}) is True
        # header shape triggers detection
        assert isLikelyMessagingExecCommand({"command": "To: alice@example.com\nSubject: hi", "toolName": ""}) is True
        # tool name alone triggers detection
        assert isLikelyMessagingExecCommand({"command": "", "toolName": "email"}) is True
        assert isLikelyMessagingExecCommand({"command": "", "toolName": "smtp"}) is True  # exact word boundary

    def test_non_messaging_command_not_detected(self):
        assert isLikelyMessagingExecCommand({"command": "ls /tmp", "toolName": ""}) is False
        assert isLikelyMessagingExecCommand({"command": "git status", "toolName": ""}) is False
        assert isLikelyMessagingExecCommand({"command": "", "toolName": "bash"}) is False
        # "send" alone without a messaging noun does not trigger
        assert isLikelyMessagingExecCommand({"command": "send file /tmp/x", "toolName": ""}) is False

    def test_empty_input_not_messaging(self):
        assert isLikelyMessagingExecCommand({}) is False
        assert isLikelyMessagingExecCommand(None) is False
