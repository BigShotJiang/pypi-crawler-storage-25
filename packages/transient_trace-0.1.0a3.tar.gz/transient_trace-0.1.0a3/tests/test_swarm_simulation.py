"""
test_swarm_simulation.py — SDK integration test using swarm-realistic workloads.

Simulates the action patterns a real swarm run generates:
  - engineer profile: filesystem reads/writes, code execution, test runs
  - architect profile: read-heavy, occasional write decisions
  - qa profile: read + validation + reporting
  - infra profile: write_high, delete operations, network calls

Each "run" exercises a component lifecycle: plan → implement → test → handoff.
The test verifies that the receipt engine accumulates signal across runs and
that the self-learning loop produces measurable, verifiable outcomes.

These are the benchmarks. If these pass on a real swarm workload the SDK
is ready to be adopted by any runtime.
"""

import time
import pytest
import transient_trace

# ---------------------------------------------------------------------------
# Swarm-realistic governance packages
# (mirrors the kinds of rules a real swarm deployment would configure)
# ---------------------------------------------------------------------------

_INFRA_PACKAGE = {
    "name": "swarm-infra",
    "version": "1.0.0",
    "description": "Governance rules for infra profile — destructive ops require approval",
    "rules": [
        {
            "id":        "no-prod-delete",
            "profile":   "exec",
            "condition": {"action_class": "delete"},
            "outcome":   "deny",
            "reason":    "delete operations require explicit approval in swarm context",
        },
        {
            "id":        "no-bulk-export",
            "profile":   "exec",
            "condition": {"action_class": "bulk_export"},
            "outcome":   "deny",
            "reason":    "bulk exports blocked — use targeted queries",
        },
    ],
}

_NETWORK_PACKAGE = {
    "name": "swarm-network",
    "version": "1.0.0",
    "description": "Egress governance for swarm agents",
    "rules": [
        {
            "id":        "block-external-egress",
            "profile":   "egress",
            "condition": {"host": "external"},
            "outcome":   "deny",
            "reason":    "external egress requires review",
        },
    ],
}

_ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _swarm_client(tmp_path, packages=None, mode="audit", trigger=5):
    cfg = {
        "pepPolicy": _ALLOW_ALL,
        "mode": mode,
        "state_dir": str(tmp_path),
        "learning": {
            "enabled": True,
            "distill_trigger_count": trigger,
        },
    }
    if packages:
        cfg["packages"] = packages
    return transient_trace.Client(cfg)


def _action(action, action_class, target="./src"):
    return {"action": action, "action_class": action_class, "target": target}


def _run_engineer_component(client, cid: str):
    """Simulate one engineer component lifecycle."""
    try:
        client.executeActionWithReceipt(
            lambda: {"files": ["main.py", "utils.py"]},
            _action("read_files", "read", f"./components/{cid}"),
        )
    except RuntimeError:
        pass

    try:
        client.executeActionWithReceipt(
            lambda: {"written": True},
            _action("write_file", "write_low", f"./components/{cid}/main.py"),
        )
    except RuntimeError:
        pass

    try:
        client.executeActionWithReceipt(
            lambda: {"exit_code": 0},
            _action("run_tests", "exec", f"./components/{cid}"),
        )
    except RuntimeError:
        pass


def _run_architect_component(client, cid: str):
    """Simulate architect reviewing and making decisions."""
    try:
        client.executeActionWithReceipt(
            lambda: {"schema": {}},
            _action("read_schema", "read", f"./arch/{cid}"),
        )
    except RuntimeError:
        pass

    try:
        client.executeActionWithReceipt(
            lambda: {"decision": "approved"},
            _action("write_decision", "write_low", f"./arch/{cid}/decision.md"),
        )
    except RuntimeError:
        pass


def _run_infra_component(client, cid: str):
    """Simulate infra attempting destructive operations (should be denied)."""
    try:
        client.executeActionWithReceipt(
            lambda: {"cleaned": True},
            _action("delete_artifacts", "delete", f"./dist/{cid}"),
        )
    except RuntimeError:
        pass  # expected deny in strict mode

    try:
        client.executeActionWithReceipt(
            lambda: {"exported": True},
            _action("export_logs", "bulk_export", f"./logs/{cid}"),
        )
    except RuntimeError:
        pass  # expected deny in strict mode


def _run_qa_component(client, cid: str):
    """Simulate QA validation pass."""
    try:
        client.executeActionWithReceipt(
            lambda: {"results": []},
            _action("read_test_results", "read", f"./qa/{cid}"),
        )
    except RuntimeError:
        pass

    try:
        client.executeActionWithReceipt(
            lambda: {"report": "pass"},
            _action("write_report", "write_low", f"./qa/{cid}/report.json"),
        )
    except RuntimeError:
        pass


# ---------------------------------------------------------------------------
# Test 1 — Receipts accumulate across a realistic multi-component run
# ---------------------------------------------------------------------------

class TestSwarmReceiptAccumulation:

    def test_multi_profile_run_generates_receipts(self, tmp_path):
        """A realistic swarm run with 4 profiles generates receipts for all action types."""
        client = _swarm_client(tmp_path)
        components = ["auth-service", "api-gateway", "data-pipeline"]
        for cid in components:
            _run_engineer_component(client, cid)
            _run_architect_component(client, cid)
            _run_qa_component(client, cid)
        stats = client._receipt_engine.stats()
        assert stats["total_receipts"] >= len(components) * 3 * 2, (
            f"Expected at least {len(components) * 3 * 2} receipts, got {stats['total_receipts']}"
        )

    def test_receipts_cover_multiple_action_classes(self, tmp_path):
        """Receipts span read, write_low, exec — not just one action class."""
        client = _swarm_client(tmp_path)
        for i in range(3):
            _run_engineer_component(client, f"cid-{i}")
        action_classes = {r["action_class"] for r in client._receipt_engine.query()}
        assert "read" in action_classes
        assert "write_low" in action_classes
        assert "exec" in action_classes

    def test_receipts_have_correct_tool_names(self, tmp_path):
        """Tool names in receipts match the actions dispatched."""
        client = _swarm_client(tmp_path)
        _run_engineer_component(client, "test-cid")
        tool_names = {r["tool_name"] for r in client._receipt_engine.query()}
        assert "read_files" in tool_names
        assert "write_file" in tool_names
        assert "run_tests" in tool_names

    def test_all_receipts_have_timestamps(self, tmp_path):
        """Every receipt must have a valid unix timestamp for time-range queries."""
        client = _swarm_client(tmp_path)
        for i in range(3):
            _run_engineer_component(client, f"cid-{i}")
        receipts = client._receipt_engine.query()
        for r in receipts:
            ts = r.get("ts")
            assert ts is not None, f"Receipt missing ts: {r.get('receipt_id')}"
            assert isinstance(ts, float), f"ts is not float: {type(ts)}"
            assert ts > 1_700_000_000, f"ts looks wrong: {ts}"


# ---------------------------------------------------------------------------
# Test 2 — Governance denials captured and reflected in learning
# ---------------------------------------------------------------------------

class TestSwarmDenialLearning:

    def test_infra_denials_captured_as_receipts(self, tmp_path):
        """Denied infra actions (delete, bulk_export) are stored as deny receipts."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit")
        for i in range(3):
            _run_infra_component(client, f"cid-{i}")
        deny_receipts = client._receipt_engine.query(outcome="deny")
        # 3 components × 2 denied actions (delete + bulk_export) = 6 deny receipts
        assert len(deny_receipts) >= 6, (
            f"Expected ≥6 deny receipts from infra ops, got {len(deny_receipts)}"
        )

    def test_denied_receipts_carry_rule_metadata(self, tmp_path):
        """Deny receipts from package rules must carry rule_id and reason."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit")
        _run_infra_component(client, "test-cid")
        deny_receipts = client._receipt_engine.query(outcome="deny")
        for r in deny_receipts:
            assert r.get("matched_rule_id") is not None, (
                f"Deny receipt missing rule_id: {r.get('receipt_id')}"
            )
            assert r.get("matched_rule_reason") is not None

    def test_deny_rate_builds_in_patterns_after_repeated_runs(self, tmp_path):
        """After multiple infra runs, distilled patterns reflect the deny rate accurately."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit", trigger=3)
        for i in range(6):
            _run_infra_component(client, f"cid-{i}")
        client._receipt_engine.distill()
        pp = client._receipt_engine.get_prior_pattern(
            action_class="delete",
            tool_name="delete_artifacts",
        )
        assert pp is not None, "Expected prior_pattern for delete after 6 infra runs"
        # All delete attempts are denied — deny_rate should be 1.0
        assert pp["deny_rate"] == 1.0, f"Expected 100% deny rate for delete, got {pp['deny_rate']}"
        assert pp["attempts"] >= 6

    def test_prior_pattern_recommendation_is_actionable(self, tmp_path):
        """prior_pattern recommendation for a consistently denied action must say 'consistently fails'."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit", trigger=3)
        for i in range(6):
            _run_infra_component(client, f"cid-{i}")
        client._receipt_engine.distill()
        pp = client._receipt_engine.get_prior_pattern(
            action_class="delete",
            tool_name="delete_artifacts",
        )
        if pp is None:
            pytest.skip("prior_pattern not yet formed")
        assert "consistently fails" in pp["recommendation"]


# ---------------------------------------------------------------------------
# Test 3 — Prior pattern appears on decision responses
# ---------------------------------------------------------------------------

class TestSwarmPriorPatternOnDecision:

    def test_prior_pattern_absent_on_fresh_client(self, tmp_path):
        """No prior_pattern on first run — engine has no history."""
        client = _swarm_client(tmp_path)
        result = client.executeActionWithReceipt(
            lambda: "ok",
            _action("read_files", "read"),
        )
        assert "prior_pattern" not in result["decision"]

    def test_prior_pattern_present_after_enough_engineer_runs(self, tmp_path):
        """After several engineer runs, prior_pattern appears on subsequent decisions."""
        client = _swarm_client(tmp_path, trigger=3)
        for i in range(5):
            _run_engineer_component(client, f"cid-{i}")
        client._receipt_engine.distill()
        result = client.executeActionWithReceipt(
            lambda: "ok",
            _action("read_files", "read"),
        )
        assert "prior_pattern" in result["decision"], (
            "Expected prior_pattern in decision after 5 engineer runs with distillation"
        )

    def test_prior_pattern_influences_deny_signal(self, tmp_path):
        """After repeated infra denials, prior_pattern on delete decision shows high deny_rate."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit", trigger=3)
        for i in range(6):
            _run_infra_component(client, f"cid-{i}")
        client._receipt_engine.distill()
        result = client.executeActionWithReceipt(
            lambda: "ok",
            _action("delete_artifacts", "delete"),
        )
        pp = result["decision"].get("prior_pattern")
        if pp is None:
            pytest.skip("prior_pattern not populated — min_count threshold not met")
        assert pp["deny_rate"] > 0.5, (
            f"Expected high deny_rate for delete after repeated infra denials, got {pp['deny_rate']}"
        )


# ---------------------------------------------------------------------------
# Test 4 — Audit layer on swarm receipts
# ---------------------------------------------------------------------------

class TestSwarmAudit:

    def test_explain_on_swarm_run(self, tmp_path):
        """explain() produces a coherent incident report from a swarm-like run."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit")
        components = ["auth", "api", "db"]
        for cid in components:
            _run_engineer_component(client, cid)
            _run_infra_component(client, cid)
        report = client._receipt_engine.explain()
        assert report["summary"]["total"] >= 9  # 3 components × (3 eng + 2 infra) actions
        assert "deny" in report["summary"]["outcomes"]
        assert report["summary"]["outcomes"]["deny"] >= 6
        assert len(report["denies"]) >= 6
        assert len(report["verification"]["manifest_hash"]) == 64

    def test_explain_denies_have_rule_ids(self, tmp_path):
        """Every deny in the explain report must reference the rule that fired."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit")
        for i in range(2):
            _run_infra_component(client, f"cid-{i}")
        report = client._receipt_engine.explain()
        for deny in report["denies"]:
            assert deny.get("rule_id") is not None, (
                f"Deny event missing rule_id in explain report: {deny}"
            )

    def test_top_rules_reflects_most_fired_governance_rule(self, tmp_path):
        """top_rules in explain() correctly identifies which rule fired most."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit")
        for i in range(5):
            _run_infra_component(client, f"cid-{i}")
        report = client._receipt_engine.explain()
        assert len(report["top_rules"]) >= 1
        top_rule = report["top_rules"][0]
        assert top_rule["rule_id"] in ("no-prod-delete", "no-bulk-export")
        assert top_rule["count"] >= 5

    def test_export_bundle_from_swarm_run(self, tmp_path):
        """export_bundle on swarm receipts produces a verifiable, self-contained file."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit")
        for i in range(3):
            _run_engineer_component(client, f"eng-{i}")
            _run_infra_component(client, f"inf-{i}")
        bundle_path = tmp_path / "swarm-audit-bundle.json"
        result = client._receipt_engine.export_bundle(path=bundle_path)
        assert bundle_path.exists()
        assert result["receipt_count"] >= 15  # 3 × (3 eng + 2 infra × 2 ops)
        # Manifest hash is 64-char sha256
        import json
        bundle = json.loads(bundle_path.read_text())
        assert len(bundle["manifest"]["hash"]) == 64
        assert "report" in bundle
        assert bundle["report"]["summary"]["total"] >= 15

    def test_time_range_query_scopes_to_run(self, tmp_path):
        """Time-range queries correctly scope receipts to a specific run window."""
        client = _swarm_client(tmp_path)
        # Subtract 1ms so receipts created at the very start of the loop are included.
        # Receipt ts = int(time.time()*1000)/1000 truncates to millisecond precision;
        # a mid-millisecond t_before capture can land just after the first receipt's ts.
        # Buffer receipts by 1s either side.
        # Client.py uses max(int(t*1000), prev+1) to force monotonic ms timestamps;
        # on fast hardware, 9 rapid receipts can accumulate 18ms of artificial skew
        # beyond wall clock. 1s comfortably exceeds that while still being a tight window.
        t_before = time.time() - 1.0
        for i in range(3):
            _run_engineer_component(client, f"cid-{i}")
        t_after = time.time() + 1.0
        receipts_in_window = client._receipt_engine.query(
            from_ts=t_before,
            to_ts=t_after,
        )
        receipts_all = client._receipt_engine.query()
        # All receipts were in the window
        assert len(receipts_in_window) == len(receipts_all)
        # Nothing well before the window
        receipts_before = client._receipt_engine.query(to_ts=t_before - 60)
        assert len(receipts_before) == 0


# ---------------------------------------------------------------------------
# Test 5 — Multi-run learning convergence
# (the benchmark test: does the system learn and improve across runs?)
# ---------------------------------------------------------------------------

class TestSwarmLearningConvergence:

    def test_deny_rate_stable_across_runs(self, tmp_path):
        """Deny rate for a consistently blocked action stays at 1.0 across more runs."""
        client = _swarm_client(tmp_path, packages=[_INFRA_PACKAGE], mode="audit", trigger=3)
        # Run 1-5
        for i in range(5):
            _run_infra_component(client, f"run1-{i}")
        client._receipt_engine.distill()
        pp_early = client._receipt_engine.get_prior_pattern(
            action_class="delete",
            tool_name="delete_artifacts",
        )
        # Run 6-10
        for i in range(5):
            _run_infra_component(client, f"run2-{i}")
        client._receipt_engine.distill()
        pp_late = client._receipt_engine.get_prior_pattern(
            action_class="delete",
            tool_name="delete_artifacts",
        )
        assert pp_early is not None
        assert pp_late is not None
        # Deny rate should remain 1.0 — consistent governance signal
        assert pp_late["deny_rate"] == 1.0
        # Attempts count increases across runs
        assert pp_late["attempts"] > pp_early["attempts"]

    def test_allow_pattern_stable_for_safe_actions(self, tmp_path):
        """Read operations that always pass maintain a 0% deny rate across runs."""
        client = _swarm_client(tmp_path, trigger=3)
        for i in range(8):
            _run_architect_component(client, f"cid-{i}")
        client._receipt_engine.distill()
        pp = client._receipt_engine.get_prior_pattern(
            action_class="read",
            tool_name="read_schema",
        )
        assert pp is not None
        assert pp["deny_rate"] == 0.0, (
            f"Read actions should never be denied, got deny_rate={pp['deny_rate']}"
        )

    def test_pattern_shifts_detected_when_governance_changes(self, tmp_path):
        """
        If the same action class gets both allow and deny in different runs
        (e.g., write_low first allowed, then a stricter package is loaded),
        explain() reports it as a pattern shift.
        """
        # Run 1 — no deny packages, write_low allowed
        client = _swarm_client(tmp_path, trigger=3)
        for i in range(3):
            _run_engineer_component(client, f"pre-{i}")

        # Add a package that now denies write_low (simulate governance tightening)
        write_deny_pkg = {
            "name": "write-lockdown",
            "version": "1.0.0",
            "rules": [{
                "id":        "deny-write-low",
                "profile":   "exec",
                "condition": {"action_class": "write_low"},
                "outcome":   "deny",
                "reason":    "write operations locked down after incident",
            }],
        }
        client2 = _swarm_client(tmp_path / "phase2", packages=[write_deny_pkg], mode="audit", trigger=3)
        for i in range(3):
            _run_engineer_component(client2, f"post-{i}")

        # Check each client's audit independently
        report1 = client._receipt_engine.explain()
        report2 = client2._receipt_engine.explain()

        # Phase 1: write_low was allowed
        assert "allow" in report1["summary"]["outcomes"]

        # Phase 2: write_low is denied (in audit mode, recorded as would_be_deny)
        # Receipts still show outcome="allow" (audit mode) but rule match is recorded
        assert report2["summary"]["total"] >= 6

    def test_stats_progression_across_runs(self, tmp_path):
        """stats() counters increase monotonically across runs."""
        client = _swarm_client(tmp_path, trigger=3)
        counts = []
        for run in range(4):
            _run_engineer_component(client, f"run-{run}")
            counts.append(client._receipt_engine.stats()["total_receipts"])
        # Each run adds receipts — counts must be strictly increasing
        for i in range(1, len(counts)):
            assert counts[i] > counts[i - 1], (
                f"Receipt count did not increase after run {i}: {counts}"
            )
