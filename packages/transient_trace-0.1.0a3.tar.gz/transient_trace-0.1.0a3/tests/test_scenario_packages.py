"""
test_scenario_packages.py — Real-world agent scenario tests for governance packages.

Each scenario represents a plausible agent use case. Tests use the same exec_input
shape that the PATH shim and Popen hook produce at runtime — so these tests validate
real interception behaviour, not just the policy evaluator in isolation.

Scenarios:
  HimalayaEmailAgent   — terminal email client, internal send allowed, external challenged
  DevOpsAgent          — git/npm automation, push denied, dry-run allowed
  LogCleanupAgent      — reads logs allowed, recursive delete denied
  DependencyAuditAgent — lockfile installs allowed, bare installs denied
  WebRequestAgent      — GET allowed, POST external challenged, SSRF internal denied
"""

import os
import pytest
import transient_trace

# ── helpers ───────────────────────────────────────────────────────────────────

_ALLOW_ALL = {"version": 1, "defaultAction": "allow", "rules": []}


def _client(*package_names: str, mode: str = "audit"):
    return transient_trace.Client({
        "pepPolicy": _ALLOW_ALL,
        "packages": list(package_names),
        "mode": mode,
    })


def _shim_exec(client, binary: str, argv: list, action_class: str, cwd: str = None):
    """Simulate the exec_input shape produced by the PATH shim."""
    full_argv = [binary] + argv
    target = {
        "binaryPath": f"/usr/bin/{binary}",
        "command": " ".join(full_argv),
        "cwd": cwd or os.getcwd(),
    }
    return client.executeActionWithReceipt(
        lambda: {"exit_code": 0},
        {
            "action": binary,
            "action_class": action_class,
            "target": target,
            "metadata": {"sense_maker_method": "command_pattern"},
        },
    )


def _shim_network(client, binary: str, url: str, method: str = "GET",
                  delivery_mode: str = "", recipient_topology: str = ""):
    """Simulate the exec_input shape for a network call (curl, wget, etc.)."""
    from urllib.parse import urlparse
    parsed = urlparse(url)
    host = parsed.netloc.lower() or parsed.path.lower()
    target = {
        "binaryPath": f"/usr/bin/{binary}",
        "command": f"{binary} {url}",
        "cwd": os.getcwd(),
        "host": host,
        "url": url,
        "method": method,
        "path": parsed.path or "/",
    }
    meta = {"sense_maker_method": "command_pattern"}
    if delivery_mode:
        meta["deliveryMode"] = delivery_mode
    if recipient_topology:
        meta["recipientTopology"] = recipient_topology
    return client.executeActionWithReceipt(
        lambda: {"exit_code": 0},
        {
            "action": binary,
            "action_class": "network",
            "action_type": "network",
            "target": target,
            "metadata": meta,
        },
    )


def _was_blocked(r: dict) -> bool:
    return "would_be_deny" in r["decision"]["reason_code"] or \
           "would_be_approval_required" in r["decision"]["reason_code"]


def _rule(r: dict) -> str:
    return r["decision"].get("matched_rule_id") or ""


# ── Scenario 1: Himalaya email agent ─────────────────────────────────────────

class TestHimalayaEmailAgent:
    """
    An agent uses Himalaya (terminal email client) to manage email.
    Internal relay sends are fine. External delivery and bulk sends are not.

    Packages: messaging
    """

    def setup_method(self):
        self.c = _client("messaging")

    def test_send_to_internal_relay_is_allowed(self):
        # Sending via an internal mail relay — no deliveryMode or recipient flags
        r = _shim_network(self.c, "himalaya", "http://mail.internal.corp/send", method="POST")
        # No deliveryMode set — internal host, no package rule triggered
        assert not _was_blocked(r)

    def test_send_external_delivery_is_challenged(self):
        # Agent marks the send as external delivery — requires operator approval
        r = _shim_network(self.c, "himalaya", "http://smtp.sendgrid.com/v3/mail/send",
                          method="POST", delivery_mode="external")
        assert _was_blocked(r)
        assert _rule(r) == "messaging-ext-egress-challenge"

    def test_bulk_newsletter_is_denied(self):
        # Agent tries to send a newsletter blast — bulk sends are denied outright
        r = _shim_network(self.c, "himalaya", "http://smtp.mailchimp.com/messages/send",
                          method="POST", delivery_mode="bulk")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert _rule(r) == "messaging-bulk-egress-deny"

    def test_unknown_recipient_topology_is_challenged(self):
        # Agent sends to an address without confirming who the recipient is
        r = _shim_network(self.c, "himalaya", "http://smtp.example.com/send",
                          method="POST", recipient_topology="unknown")
        assert _was_blocked(r)
        assert _rule(r) == "messaging-unknown-recipient-challenge"

    def test_strict_mode_blocks_bulk(self):
        c = _client("messaging", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _shim_network(c, "himalaya", "http://smtp.mailchimp.com/messages/send",
                          method="POST", delivery_mode="bulk")

    def test_strict_mode_allows_internal(self):
        c = _client("messaging", mode="strict")
        r = _shim_network(c, "himalaya", "http://mail.internal.corp/send", method="POST")
        assert r["output"] == {"exit_code": 0}


# ── Scenario 2: DevOps automation agent ──────────────────────────────────────

class TestDevOpsAgent:
    """
    An agent automates git operations and dependency management.
    Read-only git is fine. Pushing to remotes and bare installs are not.

    Packages: code
    """

    def setup_method(self):
        self.c = _client("code")

    # git read operations — all allowed
    @pytest.mark.parametrize("argv", [
        ["status"],
        ["log", "--oneline", "-10"],
        ["diff", "HEAD~1"],
        ["fetch", "--dry-run"],
        ["branch", "-a"],
    ])
    def test_git_read_operations_are_allowed(self, argv):
        r = _shim_exec(self.c, "git", argv, action_class="read")
        assert not _was_blocked(r), f"git {' '.join(argv)} should be allowed"

    # git push to remote — denied
    @pytest.mark.parametrize("argv", [
        ["push", "origin", "main"],
        ["push", "upstream", "feature/my-branch"],
        ["push", "origin", "--tags"],
        ["push", "https://github.com/org/repo.git", "main"],
        ["push", "git@github.com:org/repo.git", "main"],
    ])
    def test_git_push_to_remote_is_denied(self, argv):
        r = _shim_exec(self.c, "git", argv, action_class="write_low")
        assert _was_blocked(r), f"git {' '.join(argv)} should be blocked"
        assert _rule(r) == "code-git-push-remote-deny"

    # dry-run push — allowed (safe preview)
    def test_git_push_dry_run_is_allowed(self):
        r = _shim_exec(self.c, "git", ["push", "--dry-run", "origin", "main"],
                       action_class="write_low")
        assert not _was_blocked(r)

    # package installs without lockfile — denied
    @pytest.mark.parametrize("binary,argv", [
        ("npm",   ["install"]),
        ("npm",   ["install", "lodash"]),
        ("yarn",  ["add", "axios"]),
        ("pnpm",  ["add", "typescript"]),
        ("pip",   ["install", "requests"]),
        ("pip",   ["install", "flask", "sqlalchemy"]),
        ("cargo", ["add", "serde"]),
    ])
    def test_bare_package_install_is_denied(self, binary, argv):
        r = _shim_exec(self.c, binary, argv, action_class="write_low")
        assert _was_blocked(r), f"{binary} {' '.join(argv)} should be blocked"
        assert _rule(r) == "code-package-install-no-lockfile-deny"

    # locked installs — allowed
    @pytest.mark.parametrize("binary,argv", [
        ("npm",   ["install", "--package-lock"]),
        ("pip",   ["install", "-r", "requirements.txt"]),
        ("pip",   ["install", "--requirement", "requirements.txt"]),
        ("cargo", ["add", "--locked", "serde"]),
    ])
    def test_lockfile_install_is_allowed(self, binary, argv):
        r = _shim_exec(self.c, binary, argv, action_class="write_low")
        assert not _was_blocked(r), f"{binary} {' '.join(argv)} should be allowed"

    def test_strict_mode_blocks_git_push(self):
        c = _client("code", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _shim_exec(c, "git", ["push", "origin", "main"], action_class="write_low")


# ── Scenario 3: Log cleanup agent ────────────────────────────────────────────

class TestLogCleanupAgent:
    """
    An agent reads application logs and prunes old ones.
    Reading logs is fine. Recursive deletes are not. Credential paths are challenged.

    Packages: filesystem
    """

    def setup_method(self):
        self.c = _client("filesystem")

    def test_reading_app_log_is_allowed(self):
        r = _shim_exec(self.c, "cat", ["./logs/app.log"], action_class="read")
        assert not _was_blocked(r)

    def test_reading_recent_log_is_allowed(self):
        r = _shim_exec(self.c, "tail", ["-n", "100", "./logs/app.log"], action_class="read")
        assert not _was_blocked(r)

    @pytest.mark.parametrize("argv,ac", [
        (["./logs/app.log"],          "delete"),
        (["./output/report.csv"],     "delete"),
    ])
    def test_single_file_delete_in_cwd_is_allowed(self, argv, ac):
        # Non-recursive delete of a file in cwd — should be allowed
        cwd = os.getcwd()
        full_argv = ["rm"] + argv
        r = self.c.executeActionWithReceipt(
            lambda: {"exit_code": 0},
            {
                "action": "rm",
                "action_class": ac,
                "target": {
                    "command": " ".join(full_argv),
                    "cwd": cwd,
                    "path": os.path.join(cwd, argv[0].lstrip("./")),
                    "binaryPath": "/bin/rm",
                },
            },
        )
        assert not _was_blocked(r)

    @pytest.mark.parametrize("argv", [
        ["-rf", "./logs/old/"],
        ["-rf", "/var/log/archive"],
        ["-r", "./logs/2024/"],
        ["-rf", "."],
    ])
    def test_recursive_delete_is_denied(self, argv):
        r = _shim_exec(self.c, "rm", argv, action_class="delete")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert _rule(r) == "filesystem-bulk-delete-deny"

    @pytest.mark.parametrize("argv", [
        [".", "-name", "*.log", "-delete"],
        ["./logs", "-mtime", "+30", "-delete"],
        ["./logs", "-name", "*.tmp", "-exec", "rm", "{}", ";"],
    ])
    def test_find_delete_is_denied(self, argv):
        r = _shim_exec(self.c, "find", argv, action_class="delete")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert _rule(r) == "filesystem-bulk-delete-deny"

    @pytest.mark.parametrize("path", [
        "~/.aws/credentials",
        "~/.ssh/id_rsa",
        "~/.ssh/config",
        "/etc/passwd",
        "/etc/shadow",
        "~/.config/gcloud/credentials",
        "~/.gnupg/private-keys-v1.d/",
    ])
    def test_sensitive_credential_paths_are_challenged(self, path):
        r = _shim_exec(self.c, "cat", [path], action_class="read")
        assert _was_blocked(r), f"cat {path} should be challenged"
        assert _rule(r) == "filesystem-sensitive-path-challenge"

    def test_strict_mode_blocks_recursive_delete(self):
        c = _client("filesystem", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _shim_exec(c, "rm", ["-rf", "./logs/old/"], action_class="delete")


# ── Scenario 4: Dependency audit agent ───────────────────────────────────────

class TestDependencyAuditAgent:
    """
    An agent audits and updates project dependencies.
    Locked / requirements-based installs are fine. Bare installs are not.
    Git push to publish new versions is blocked.

    Packages: code
    """

    def setup_method(self):
        self.c = _client("code")

    def test_pip_audit_check_is_allowed(self):
        r = _shim_exec(self.c, "pip", ["list", "--outdated"], action_class="read")
        assert not _was_blocked(r)

    def test_pip_install_requirements_is_allowed(self):
        r = _shim_exec(self.c, "pip", ["install", "-r", "requirements.txt"],
                       action_class="write_low")
        assert not _was_blocked(r)

    def test_pip_install_bare_is_denied(self):
        r = _shim_exec(self.c, "pip", ["install", "requests==2.31.0"],
                       action_class="write_low")
        assert _was_blocked(r)
        assert _rule(r) == "code-package-install-no-lockfile-deny"

    def test_npm_ci_is_allowed(self):
        # npm ci uses package-lock.json — treated as safe
        r = _shim_exec(self.c, "npm", ["ci"], action_class="write_low")
        assert not _was_blocked(r)

    def test_npm_audit_is_allowed(self):
        r = _shim_exec(self.c, "npm", ["audit"], action_class="read")
        assert not _was_blocked(r)

    def test_npm_add_is_denied(self):
        r = _shim_exec(self.c, "npm", ["install", "express"], action_class="write_low")
        assert _was_blocked(r)
        assert _rule(r) == "code-package-install-no-lockfile-deny"

    def test_cannot_publish_via_git_push(self):
        # Agent tries to push a version bump commit — denied
        r = _shim_exec(self.c, "git", ["push", "origin", "main", "--tags"],
                       action_class="write_low")
        assert _was_blocked(r)
        assert _rule(r) == "code-git-push-remote-deny"


# ── Scenario 5: Web request agent ────────────────────────────────────────────

class TestWebRequestAgent:
    """
    An agent makes HTTP requests to external APIs and internal services.
    GET to public endpoints is fine. POST to external is challenged.
    Any request to internal ranges is denied (SSRF protection).

    Packages: web
    """

    def setup_method(self):
        self.c = _client("web")

    # Safe public GETs — all allowed
    @pytest.mark.parametrize("url", [
        "https://api.anthropic.com/v1/messages",
        "https://api.github.com/repos/owner/repo",
        "https://registry.npmjs.org/lodash",
        "https://pypi.org/pypi/requests/json",
        "https://1.1.1.1/dns-query",
    ])
    def test_get_to_public_endpoints_is_allowed(self, url):
        r = _shim_network(self.c, "curl", url, method="GET")
        assert not _was_blocked(r), f"GET {url} should be allowed"

    # SSRF — cloud metadata and internal ranges denied
    @pytest.mark.parametrize("url", [
        "http://169.254.169.254/latest/meta-data/",           # AWS IMDS
        "http://169.254.169.254/latest/meta-data/iam/",       # AWS IAM creds
        "http://169.254.170.2/v2/credentials",                 # ECS metadata
        "http://10.0.0.1/admin",                               # internal network
        "http://10.96.0.1/api/v1/namespaces/",                 # k8s API server
        "http://192.168.1.1/",                                 # local router
        "http://172.16.0.10/metrics",                          # private range
        "http://127.0.0.1:8080/internal-api",                  # loopback
        "http://localhost:9200/_cat/indices",                   # elasticsearch
    ])
    def test_ssrf_to_internal_ranges_is_denied(self, url):
        r = _shim_network(self.c, "curl", url, method="GET")
        assert "would_be_deny" in r["decision"]["reason_code"], \
            f"SSRF to {url} should be denied"
        assert _rule(r) == "web-ssrf-internal-deny"

    # State-mutating requests to external hosts — challenged
    @pytest.mark.parametrize("url,method", [
        ("https://api.stripe.com/v1/charges",           "POST"),
        ("https://api.github.com/repos/owner/repo",     "PATCH"),
        ("https://api.slack.com/api/chat.postMessage",  "POST"),
        ("https://hooks.zapier.com/hooks/catch/123/",   "POST"),
        ("https://httpbin.org/put",                     "PUT"),
    ])
    def test_external_mutation_is_challenged(self, url, method):
        r = _shim_network(self.c, "curl", url, method=method)
        assert _was_blocked(r), f"{method} {url} should be challenged"
        assert _rule(r) == "web-external-mutation-challenge"

    def test_strict_mode_blocks_ssrf(self):
        c = _client("web", mode="strict")
        with pytest.raises(RuntimeError, match="Denied"):
            _shim_network(c, "curl", "http://169.254.169.254/latest/meta-data/")

    def test_strict_mode_allows_public_get(self):
        c = _client("web", mode="strict")
        r = _shim_network(c, "curl", "https://api.anthropic.com/v1/messages")
        assert r["output"] == {"exit_code": 0}


# ── Scenario 6: Combined — autonomous coding agent ───────────────────────────

class TestAutonomousCodingAgent:
    """
    A general-purpose coding agent. Combines code + filesystem + web packages.
    Models what a Claude Code session would look like under full package governance.

    Packages: code, filesystem, web
    """

    def setup_method(self):
        self.c = _client("code", "filesystem", "web")

    def test_read_source_files_is_allowed(self):
        r = _shim_exec(self.c, "cat", ["./src/main.py"], action_class="read")
        assert not _was_blocked(r)

    def test_git_status_is_allowed(self):
        r = _shim_exec(self.c, "git", ["status"], action_class="read")
        assert not _was_blocked(r)

    def test_git_push_is_denied(self):
        r = _shim_exec(self.c, "git", ["push", "origin", "main"], action_class="write_low")
        assert _was_blocked(r)
        assert _rule(r) == "code-git-push-remote-deny"

    def test_rm_rf_is_denied(self):
        r = _shim_exec(self.c, "rm", ["-rf", "./dist/"], action_class="delete")
        assert _was_blocked(r)
        assert _rule(r) == "filesystem-bulk-delete-deny"

    def test_reading_aws_credentials_is_challenged(self):
        r = _shim_exec(self.c, "cat", ["~/.aws/credentials"], action_class="read")
        assert _was_blocked(r)
        assert _rule(r) == "filesystem-sensitive-path-challenge"

    def test_curl_to_aws_metadata_is_denied(self):
        # Classic exfiltration attempt via IMDS
        r = _shim_network(self.c, "curl",
                          "http://169.254.169.254/latest/meta-data/iam/security-credentials/")
        assert "would_be_deny" in r["decision"]["reason_code"]
        assert _rule(r) == "web-ssrf-internal-deny"

    def test_pip_install_bare_is_denied(self):
        r = _shim_exec(self.c, "pip", ["install", "malicious-package"],
                       action_class="write_low")
        assert _was_blocked(r)
        assert _rule(r) == "code-package-install-no-lockfile-deny"

    def test_curl_public_api_get_is_allowed(self):
        r = _shim_network(self.c, "curl", "https://api.anthropic.com/v1/models")
        assert not _was_blocked(r)

    def test_full_audit_trail_captured(self):
        """Every governed action produces a receipt, regardless of outcome."""
        actions = [
            (_shim_exec, (self.c, "git", ["status"], "read"), {}),
            (_shim_exec, (self.c, "git", ["push", "origin", "main"], "write_low"), {}),
            (_shim_exec, (self.c, "rm", ["-rf", "./dist/"], "delete"), {}),
        ]
        for fn, args, kwargs in actions:
            r = fn(*args, **kwargs)
            assert "receipt" in r
            assert r["receipt"].get("receipt_id", "").startswith("TR-")
