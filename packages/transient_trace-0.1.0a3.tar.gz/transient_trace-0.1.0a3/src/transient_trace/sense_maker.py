"""
sense_maker.py — Maps intercepted subprocess calls to governance action_class.

The sense-maker is the bridge between raw process invocations and the semantic
labels the PEP and receipt engine need. It uses heuristic pattern matching —
not exact function names — so it stays resilient to version bumps.

Two entry points:
  classify_hermes(argv)     → action_class for a hermes -p <profile> call
  classify_command(argv)    → action_class for any generic subprocess call

Both return a SenseMakerResult with action_class, confidence, and reasoning.
Unknown calls are classified as "generic_action" with low confidence rather
than failing — fail-open by default, configurable to fail-closed.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


# ── Hermes profile → action_class table ──────────────────────────────────────
# Based on SOUL.md role descriptions in transient-swarm/profiles/
# Overridable via TRANSIENT_TRACE_PROFILE_MAP env var (JSON)

_HERMES_PROFILE_MAP: dict[str, str] = {
    "engineer":  "write_low",   # writes code, no git, no planning
    "qa":        "write_low",   # writes tests, acceptance checks
    "docs":      "write_low",   # writes documentation
    "infra":     "exec",        # system operations, deployment
    "auditor":   "audit",       # code review, commit gating
    "sec-ops":   "audit",       # security verification
    "architect": "read",        # design decisions, read-only outputs
    "reviewer":  "read",        # code review, read-only
    "default":   "read",        # PM, routes tasks, never writes
    "evals":     "read",        # evaluation runs
}

# ── Generic command patterns ──────────────────────────────────────────────────
# (pattern, action_class, description)
# Evaluated in order — first match wins.

_COMMAND_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    # Destructive ops — highest priority
    (re.compile(r"\brm\s+-[a-z]*r[a-z]*\b|\brm\s+-rf\b"), "delete",     "recursive delete"),
    (re.compile(r"\brmdir\b|\bshred\b|\btruncate\b"),       "delete",     "delete/wipe"),
    (re.compile(r"\bgit\s+push\b"),                          "exec",       "git push to remote"),
    (re.compile(r"\bgit\s+commit\b"),                        "write_low",  "git commit"),
    (re.compile(r"\bgit\s+(add|stage)\b"),                   "write_low",  "git stage"),
    (re.compile(r"\bgit\s+(clone|fetch|pull)\b"),            "read",       "git read"),
    (re.compile(r"\bgit\s+(status|diff|log|show|blame|shortlog|describe|ls-files|ls-tree|rev-parse|rev-list|cat-file|for-each-ref|stash list|branch\s*$|tag\s*$|remote\s*-v|remote\s*show)\b"), "read", "git read-only"),
    (re.compile(r"\bnpm\s+(publish|deploy)\b"),              "exec",       "npm publish/deploy"),
    (re.compile(r"\bnpm\s+(install|i|ci)\b"),                "write_low",  "npm install"),
    (re.compile(r"\bpip\s+install\b"),                       "write_low",  "pip install"),
    (re.compile(r"\bcurl\b|\bwget\b|\bhttpie\b"),            "network",    "http client"),
    (re.compile(r"\bssh\b|\bscp\b|\brsync\b"),              "exec",       "remote exec/copy"),
    (re.compile(r"\bdocker\s+(run|exec)\b"),                 "exec",       "docker exec"),
    (re.compile(r"\bdocker\s+build\b"),                      "write_low",  "docker build"),
    (re.compile(r"\bpython\b|\bpython3\b|\bnode\b"),         "exec",       "script execution"),
    (re.compile(r"\bcat\b|\bless\b|\bhead\b|\btail\b|\bgrep\b|\bfind\b"), "read", "read/search"),
    (re.compile(r"\bcp\b|\bmv\b"),                           "write_low",  "copy/move"),
    (re.compile(r"\bmkdir\b|\btouch\b"),                     "write_low",  "create file/dir"),
    (re.compile(r"\becho\b.*>\b|\btee\b"),                   "write_low",  "write to file"),
    (re.compile(r"\bchmod\b|\bchown\b"),                     "exec",       "permission change"),
    (re.compile(r"\bsystemctl\b|\bservice\b"),               "exec",       "service control"),
]

# ── Hermes-specific patterns (for -q message content) ────────────────────────
# When a profile alone is ambiguous, message content can refine classification.

_MESSAGE_OVERRIDE_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\bsecret[s]?\b|\bcredential[s]?\b|\bapi[_\s]?key\b|\btoken\b", re.I), "secrets"),
    (re.compile(r"\bdeploy\b|\brelease\b|\bpublish\b", re.I),                            "exec"),
    (re.compile(r"\bdelete\b|\bremove\b|\bclean\b|\bpurge\b", re.I),                     "delete"),
    (re.compile(r"\bread\b|\bcheck\b|\breview\b|\baudit\b|\bverif", re.I),               "read"),
]


@dataclass
class SenseMakerResult:
    action_class: str
    confidence: float        # 1.0 = certain, 0.5 = heuristic, 0.3 = fallback
    method: str              # how the classification was made
    detail: str              # human-readable reasoning


def classify_hermes(argv: list[str]) -> SenseMakerResult:
    """
    Classify a hermes invocation from its argv.

    Expected shape: hermes -p <profile> chat -q <message> [...]
    Falls back gracefully if shape is unexpected.
    """
    profile = _extract_flag(argv, "-p") or _extract_flag(argv, "--profile")
    message = _extract_flag(argv, "-q") or _extract_flag(argv, "--query") or ""

    if profile and profile in _HERMES_PROFILE_MAP:
        base_class = _HERMES_PROFILE_MAP[profile]

        # Check if message content overrides the profile classification
        for pattern, override_class in _MESSAGE_OVERRIDE_PATTERNS:
            if pattern.search(message):
                # Only override upward in risk (don't downgrade exec → read)
                if _risk_rank(override_class) > _risk_rank(base_class):
                    return SenseMakerResult(
                        action_class=override_class,
                        confidence=0.7,
                        method="hermes_profile+message_override",
                        detail=f"profile={profile} overridden by message content → {override_class}",
                    )

        return SenseMakerResult(
            action_class=base_class,
            confidence=1.0,
            method="hermes_profile_table",
            detail=f"profile={profile} → {base_class}",
        )

    # Unknown profile — try message content alone
    if message:
        for pattern, action_class in _MESSAGE_OVERRIDE_PATTERNS:
            if pattern.search(message):
                return SenseMakerResult(
                    action_class=action_class,
                    confidence=0.5,
                    method="hermes_message_heuristic",
                    detail=f"unknown profile={profile!r}, classified from message content",
                )

    return SenseMakerResult(
        action_class="generic_action",
        confidence=0.3,
        method="fallback",
        detail=f"unknown hermes profile={profile!r}, no message signal",
    )


def classify_command(argv: list[str]) -> SenseMakerResult:
    """
    Classify any generic subprocess invocation from its argv.

    Uses command patterns — resilient to version bumps because it matches
    on argument shape and data flow, not exact function names.
    """
    if not argv:
        return SenseMakerResult(
            action_class="generic_action",
            confidence=0.3,
            method="fallback",
            detail="empty argv",
        )

    binary = Path(argv[0]).name.lower()
    full_command = " ".join(str(a) for a in argv)

    # Check if this is a hermes call
    if binary == "hermes":
        return classify_hermes(argv[1:] if len(argv) > 1 else [])

    # Try command patterns
    for pattern, action_class, description in _COMMAND_PATTERNS:
        if pattern.search(full_command):
            return SenseMakerResult(
                action_class=action_class,
                confidence=0.8,
                method="command_pattern",
                detail=f"matched '{description}' → {action_class}",
            )

    # Binary name heuristics
    binary_map = {
        "git":      "write_low",
        "npm":      "write_low",
        "pip":      "write_low",
        "poetry":   "write_low",
        "cargo":    "write_low",
        "make":     "exec",
        "bash":     "exec",
        "sh":       "exec",
        "zsh":      "exec",
        "curl":     "network",
        "wget":     "network",
        "ssh":      "exec",
        "rsync":    "exec",
        "cat":      "read",
        "ls":       "read",
        "find":     "read",
        "grep":     "read",
    }
    if binary in binary_map:
        return SenseMakerResult(
            action_class=binary_map[binary],
            confidence=0.6,
            method="binary_name",
            detail=f"binary={binary!r} → {binary_map[binary]}",
        )

    return SenseMakerResult(
        action_class="generic_action",
        confidence=0.3,
        method="fallback",
        detail=f"unrecognised binary={binary!r}",
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_flag(argv: list[str], flag: str) -> Optional[str]:
    """Extract value after a flag from argv list."""
    for i, arg in enumerate(argv):
        if arg == flag and i + 1 < len(argv):
            return argv[i + 1]
        if arg.startswith(f"{flag}="):
            return arg.split("=", 1)[1]
    return None


_RISK_RANK = {
    "read":           0,
    "generic_action": 1,
    "audit":          1,
    "write_low":      2,
    "network":        3,
    "exec":           4,
    "delete":         5,
    "secrets":        6,
}

def _risk_rank(action_class: str) -> int:
    return _RISK_RANK.get(action_class, 1)
