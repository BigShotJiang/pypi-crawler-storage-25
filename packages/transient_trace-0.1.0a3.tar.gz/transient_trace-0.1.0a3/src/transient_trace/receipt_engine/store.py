"""
store.py — ReceiptStore

Append-only, indexed storage for signed governance receipts.

Every receipt written here is verified on read (Ed25519 signature check).
The store is indexed by (action_class, tool_name, outcome, path_pattern, host)
for O(1) pattern queries.

Usage:
    store = ReceiptStore(db_path)
    store.write(signed_receipt)
    results = store.query(action_class="filesystem", tool_name="write_file", limit=20)
    stats = store.stats(action_class="filesystem")
"""

import json
import logging
import sqlite3
import threading
import time
from pathlib import Path
from typing import Optional

_log = logging.getLogger(__name__)


def _ts_to_iso(ts: Optional[float]) -> str:
    """Convert a unix float timestamp to an ISO 8601 UTC string."""
    if not ts:
        return ""
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat().replace("+00:00", "Z")


_SCHEMA = """
CREATE TABLE IF NOT EXISTS receipts (
    id          TEXT PRIMARY KEY,
    ts          REAL NOT NULL,
    action_class TEXT,
    tool_name   TEXT,
    outcome     TEXT,
    host        TEXT,
    path        TEXT,
    method      TEXT,
    rule_id     TEXT,
    rule_reason TEXT,
    package_name TEXT,
    run_id      TEXT,
    payload     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_action_class ON receipts (action_class);
CREATE INDEX IF NOT EXISTS idx_tool_outcome ON receipts (tool_name, outcome);
CREATE INDEX IF NOT EXISTS idx_ts ON receipts (ts);

CREATE TABLE IF NOT EXISTS sessions (
    kid             TEXT PRIMARY KEY,
    session_id      TEXT NOT NULL,
    signing_pubkey  BLOB NOT NULL,
    created_at      REAL NOT NULL,
    run_id          TEXT,
    parent_run_id   TEXT,
    env_fingerprint TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_run ON sessions (run_id);
"""


class ReceiptStore:
    """
    Append-only indexed receipt storage.

    Thread-safe via WAL mode SQLite. Receipts are never modified or deleted.

    Note: the store does not verify Ed25519 signatures on read — it lacks
    the per-session public keys required. Verification is the caller's
    responsibility. Use verifyActionReceipt() from atp.validator with the
    signingPublicKey from the corresponding session receipt (matched via
    signature.kid = "sess_{id}:1").
    """

    def __init__(self, db_path: Optional[Path] = None) -> None:
        if db_path is None:
            db_path = Path.home() / "transient-audit" / "receipt_engine.db"
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db_path = db_path
        self._lock = threading.Lock()
        self._conn = self._make_conn()
        self._write_callbacks: list = []

    def _make_conn(self) -> sqlite3.Connection:
        """Create a new connection to the database (one per thread)."""
        conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(_SCHEMA)
        # Additive column migrations — safe to run on existing DBs.
        # ALTER TABLE ADD COLUMN raises OperationalError if column exists; we ignore that.
        for stmt in [
            "ALTER TABLE receipts ADD COLUMN run_id TEXT",
            "CREATE INDEX IF NOT EXISTS idx_run_id ON receipts (run_id)",
        ]:
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError:
                pass  # column or index already exists
        conn.commit()
        return conn

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def write(self, receipt: dict) -> None:
        """
        Write a signed receipt to the store.

        Receipt must contain a 'signature' key (Ed25519).
        Extracts index fields from the receipt payload automatically.
        """
        if not isinstance(receipt, dict):
            raise ValueError("receipt must be a dict")
        if "signature" not in receipt:
            raise ValueError("receipt missing 'signature' — only signed receipts accepted")

        receipt_id = receipt.get("receipt_id") or receipt.get("id") or str(id(receipt))

        # Preserve explicit zero/epoch timestamps (0.0 is falsy but valid).
        ts = receipt.get("ts")
        if ts is None:
            ts = receipt.get("timestamp")
        if ts is None:
            ts = time.time()

        # Extract indexable fields — tolerant of missing fields
        action_class = receipt.get("action_class") or _dig(receipt, "intent", "action_class")
        tool_name    = receipt.get("tool_name")    or _dig(receipt, "intent", "toolName") or _dig(receipt, "snapshot", "action")
        outcome      = receipt.get("outcome")      or receipt.get("decision")
        host         = receipt.get("host")         or _dig(receipt, "intent", "target", "host")
        path         = receipt.get("path")         or _dig(receipt, "intent", "target", "path")
        method       = receipt.get("method")       or _dig(receipt, "intent", "target", "method")
        rule_id      = receipt.get("matched_rule_id")
        rule_reason  = receipt.get("matched_rule_reason")
        package_name = receipt.get("matched_package")

        try:
            with self._lock:
                self._conn.execute(
                    """
                    INSERT OR IGNORE INTO receipts
                      (id, ts, action_class, tool_name, outcome, host, path,
                       method, rule_id, rule_reason, package_name, payload)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        receipt_id, ts, action_class, tool_name, outcome,
                        host, path, method, rule_id, rule_reason, package_name,
                        json.dumps(receipt),
                    ),
                )
                self._conn.commit()
        except sqlite3.Error as exc:
            _log.error("ReceiptStore.write error: %s", exc)
            raise

        # Store run_id separately for indexed filtering
        run_id = receipt.get("run_id") or _dig(receipt, "intent", "context", "runId")
        if run_id:
            try:
                with self._lock:
                    self._conn.execute(
                        "UPDATE receipts SET run_id=? WHERE id=? AND run_id IS NULL",
                        (run_id, receipt_id),
                    )
                    self._conn.commit()
            except sqlite3.Error:
                pass  # non-fatal; run_id is a convenience index

        # Notify callbacks (used by distiller to trigger on new receipts)
        for cb in self._write_callbacks:
            try:
                cb(receipt)
            except Exception as exc:  # noqa: BLE001
                # Log — don't silently drop. A dead callback means the learning
                # loop is no longer receiving events, which must be visible.
                _log.warning("ReceiptStore: write callback %s failed: %s", getattr(cb, "__name__", cb), exc)

    def on_write(self, callback) -> None:
        """Register a callback invoked after every successful write."""
        self._write_callbacks.append(callback)

    def write_session(
        self,
        kid: str,
        session_id: str,
        pubkey_hex: str,
        created_at: float,
        run_id: Optional[str] = None,
        parent_run_id: Optional[str] = None,
        env_fingerprint: Optional[str] = None,
    ) -> None:
        """Persist a session's signing public key, keyed by kid."""
        try:
            with self._lock:
                self._conn.execute(
                    """
                    INSERT OR IGNORE INTO sessions
                      (kid, session_id, signing_pubkey, created_at, run_id, parent_run_id, env_fingerprint)
                    VALUES (?,?,?,?,?,?,?)
                    """,
                    (
                        kid,
                        session_id,
                        bytes.fromhex(pubkey_hex),
                        created_at,
                        run_id,
                        parent_run_id,
                        env_fingerprint,
                    ),
                )
                self._conn.commit()
        except sqlite3.Error as exc:
            _log.error("ReceiptStore.write_session error: %s", exc)
            raise

    def get_session_keys(self) -> dict:
        """Return {kid: pubkey_bytes} for all sessions. Used by CLI signature verification."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT kid, signing_pubkey FROM sessions"
            ).fetchall()
        return {
            kid: (pk if isinstance(pk, bytes) else bytes.fromhex(pk))
            for kid, pk in rows
        }

    def get_payload(self, receipt_id: str) -> Optional[str]:
        """Return raw JSON payload for a receipt by exact ID, or None."""
        with self._lock:
            row = self._conn.execute(
                "SELECT payload FROM receipts WHERE id=?", (receipt_id,)
            ).fetchone()
        return row[0] if row else None

    def get_payload_prefix(self, prefix: str) -> Optional[str]:
        """Return payload for a receipt whose ID starts with prefix. None if 0 or >1 match."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, payload FROM receipts WHERE id LIKE ? LIMIT 2",
                (f"{prefix}%",),
            ).fetchall()
        if len(rows) == 1:
            return rows[0][1]
        return None

    def query_for_cli(
        self,
        outcome: Optional[str] = None,
        action_class: Optional[str] = None,
        run_id: Optional[str] = None,
        from_ts: Optional[float] = None,
        to_ts: Optional[float] = None,
        limit: int = 200,
    ) -> list[dict]:
        """
        Return receipts as CLI-display dicts — same structure as the legacy
        JSON file wrapper so callers don't need to change their parsing logic.

        Schema returned per item:
          {type, created_at, intent: {action, action_class, context: {runId}},
           decision: {outcome, matched_rule_id, reason_code}, receipt: <signed dict>}
        """
        clauses, params = [], []
        if outcome:
            clauses.append("outcome = ?")
            params.append(outcome)
        if action_class:
            clauses.append("action_class = ?")
            params.append(action_class)
        if run_id:
            clauses.append("run_id = ?")
            params.append(run_id)
        if from_ts is not None:
            clauses.append("ts >= ?")
            params.append(from_ts)
        if to_ts is not None:
            clauses.append("ts <= ?")
            params.append(to_ts)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"""
            SELECT action_class, tool_name, outcome, rule_id, rule_reason,
                   run_id, ts, payload
            FROM receipts
            {where}
            ORDER BY ts DESC
            LIMIT ?
        """
        params.append(limit)

        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()

        results = []
        for ac, tool, out, rid, rreason, rrun, ts, payload in rows:
            try:
                receipt_dict = json.loads(payload) if payload else {}
            except json.JSONDecodeError:
                receipt_dict = {}
            results.append({
                "type": "SignedActionReceipt",
                "created_at": _ts_to_iso(ts),
                "intent": {
                    "action": tool or receipt_dict.get("tool_name", "?"),
                    "action_class": ac or receipt_dict.get("action_class", "?"),
                    "context": {"runId": rrun or ""},
                    "target": receipt_dict.get("target", {}),
                },
                "decision": {
                    "outcome": out or receipt_dict.get("outcome", "?"),
                    "matched_rule_id": rid or receipt_dict.get("matched_rule_id"),
                    "reason_code": rreason or receipt_dict.get("matched_rule_reason", ""),
                },
                "receipt": receipt_dict,
            })
        return results

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def query(
        self,
        action_class: Optional[str] = None,
        tool_name: Optional[str] = None,
        outcome: Optional[str] = None,
        host: Optional[str] = None,
        limit: int = 20,
        order_by: str = "ts DESC",
    ) -> list[dict]:
        """
        Return receipts matching the given filters.

        All filters are optional — omit to match all.
        Returns list of receipt dicts (decoded from stored JSON).
        """
        clauses = []
        params: list = []

        if action_class:
            clauses.append("action_class = ?")
            params.append(action_class)
        if tool_name:
            clauses.append("tool_name = ?")
            params.append(tool_name)
        if outcome:
            clauses.append("outcome = ?")
            params.append(outcome)
        if host:
            clauses.append("host = ?")
            params.append(host)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT payload FROM receipts {where} ORDER BY {order_by} LIMIT ?"
        params.append(limit)

        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        results = []
        for (payload,) in rows:
            try:
                results.append(json.loads(payload))
            except json.JSONDecodeError:
                pass
        return results

    def stats(self, action_class: Optional[str] = None) -> list[dict]:
        """
        Return outcome counts per (action_class, tool_name, outcome) tuple.

        Used by PatternDistiller to compute confidence scores.
        """
        clauses = []
        params: list = []
        if action_class:
            clauses.append("action_class = ?")
            params.append(action_class)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"""
            SELECT action_class, tool_name, outcome, rule_id, rule_reason,
                   package_name, COUNT(*) as count,
                   MAX(ts) as last_seen
            FROM receipts
            {where}
            GROUP BY action_class, tool_name, outcome, rule_id, rule_reason, package_name
            ORDER BY count DESC
        """
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [
            {
                "action_class":  row[0],
                "tool_name":     row[1],
                "outcome":       row[2],
                "rule_id":       row[3],
                "rule_reason":   row[4],
                "package_name":  row[5],
                "count":         row[6],
                "last_seen":     row[7],
            }
            for row in rows
        ]

    def count(self) -> int:
        """Total number of receipts in the store."""
        with self._lock:
            return self._conn.execute("SELECT COUNT(*) FROM receipts").fetchone()[0]

    def close(self) -> None:
        self._conn.close()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _dig(d: dict, *keys):
    """Safe nested dict access."""
    for k in keys:
        if not isinstance(d, dict):
            return None
        d = d.get(k)
    return d
