"""
receipt_engine — Self-learning governance loop for transient-trace.

The engine turns governance receipts into compressed agent context (injects)
and promotes high-confidence patterns into policy rules — automatically,
without human labelling, backed by cryptographic receipts.

Components:
    ReceiptStore     — append-only indexed receipt storage
    PatternDistiller — receipts → compressed patterns (background)
    RulePromoter     — patterns → governance rules at confidence threshold
    Injector         — action context → compressed inject string (O(1))

Usage:
    from transient_trace.receipt_engine import ReceiptEngine

    engine = ReceiptEngine(db_path=Path("~/transient-audit/receipt_engine.db"),
                           registry=package_registry)
    engine.start()

    # Before action dispatch:
    inject = engine.inject(action_class="filesystem", tool_name="write_file")

    # After action + receipt generated:
    engine.store(signed_receipt)
"""

import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .store import ReceiptStore
from .distiller import PatternDistiller
from .promoter import RulePromoter
from .injector import Injector
from .audit import ReceiptAuditor

_log = logging.getLogger(__name__)


def _parse_iso_ts(s: str) -> float:
    """Parse an ISO 8601 timestamp string to a unix float. Returns 0.0 on failure."""
    if not s:
        return 0.0
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


class ReceiptEngine:
    """
    Facade over the four receipt engine components.

    Drop-in for any runtime using transient-trace — call store() after every
    governed action, inject() before every dispatch.
    """

    def __init__(
        self,
        db_path: Optional[Path] = None,
        registry=None,  # PackageRegistry — optional, required for promotion
        distill_trigger_count: int = 10,
        promote_min_confidence: float = 0.95,
        promote_min_count: int = 50,
        events_dir: Optional[Path] = None,  # if set, write promotion events here
    ) -> None:
        self.store_backend = ReceiptStore(db_path)
        self.auditor = ReceiptAuditor(self.store_backend)
        self.distiller = PatternDistiller(
            self.store_backend,
            trigger_count=distill_trigger_count,
        )
        self._events_dir = events_dir
        self.promoter = RulePromoter(
            self.distiller,
            registry,
            min_confidence=promote_min_confidence,
            min_count=promote_min_count,
            on_promote=self._on_promote,
        ) if registry else None
        self.injector = Injector(self.distiller)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start background distillation and promotion threads."""
        self.distiller.start()
        if self.promoter:
            self.promoter.start()

    def stop(self) -> None:
        """Stop background threads cleanly."""
        self.distiller.stop()
        if self.promoter:
            self.promoter.stop()

    def store(self, receipt: dict) -> None:
        """Write a signed receipt. Triggers distillation at threshold."""
        self.store_backend.write(receipt)

    def inject(
        self,
        action_class: Optional[str] = None,
        tool_name: Optional[str] = None,
        host: Optional[str] = None,
        path: Optional[str] = None,
    ) -> str:
        """
        Return compressed governance context string.
        Hard cap: 80 tokens. O(1) — cache lookup only.
        """
        return self.injector.inject(
            action_class=action_class,
            tool_name=tool_name,
            host=host,
            path=path,
        )

    def get_prior_pattern(
        self,
        action_class: Optional[str] = None,
        tool_name: Optional[str] = None,
        host: Optional[str] = None,
        path: Optional[str] = None,
    ) -> Optional[dict]:
        """
        Return structured prior pattern data for the current action context.

        Attached to every requestDecision() response so agents automatically
        receive verified institutional memory — no prompt injection needed,
        no optional tool call. The governance decision already carries it.

        Returns None if no relevant patterns exist (new action type, cold start).

        Schema:
        {
            "attempts":       int,    # total receipts for this pattern
            "deny_rate":      float,  # fraction that were denied
            "confidence":     float,  # pattern confidence
            "recommendation": str,    # human-readable hint
            "top_outcome":    str,    # "deny" | "allow" | "challenge"
            "rule_id":        str,    # matched rule if any
            "rule_reason":    str,    # why it fired
        }
        """
        patterns = self.distiller.get_patterns()
        if not patterns:
            return None

        # Filter to relevant patterns for this action context
        relevant = [
            p for p in patterns
            if (not action_class or p.get("action_class") == action_class)
            and (not tool_name or p.get("tool_name") == tool_name)
            and p["count"] >= 3
        ]

        if not relevant:
            return None

        # Aggregate across outcomes
        total = sum(p["count"] for p in relevant)
        deny_count = sum(p["count"] for p in relevant if p["outcome"] == "deny")
        challenge_count = sum(p["count"] for p in relevant if p["outcome"] == "challenge")
        deny_rate = deny_count / total if total > 0 else 0.0

        # Top pattern by count
        top = max(relevant, key=lambda p: p["count"])

        # Recommendation
        if deny_rate >= 0.9:
            rec = f"high deny rate ({deny_rate:.0%}) — this approach consistently fails"
        elif deny_rate >= 0.5:
            rec = f"mixed outcomes ({deny_rate:.0%} denied) — consider alternative approach"
        elif challenge_count > 0:
            rec = "requires approval — build in challenge handling"
        else:
            rec = f"generally safe ({(1-deny_rate):.0%} success rate)"

        return {
            "attempts":       total,
            "deny_rate":      round(deny_rate, 4),
            "confidence":     top["confidence"],
            "recommendation": rec,
            "top_outcome":    top["outcome"],
            "rule_id":        top.get("rule_id"),
            "rule_reason":    top.get("rule_reason"),
        }

    def distill(self) -> None:
        """Force a synchronous distillation pass (useful for testing)."""
        self.distiller.run()
        if self.promoter:
            self.promoter.run()

    def query(self, from_ts=None, to_ts=None, action_class=None,
              tool_name=None, outcome=None, limit=500) -> list:
        """Query receipts by time range and filters. Returns list of signed receipt dicts."""
        return self.auditor.query(
            from_ts=from_ts, to_ts=to_ts, action_class=action_class,
            tool_name=tool_name, outcome=outcome, limit=limit,
        )

    def explain(self, from_ts=None, to_ts=None, action_class=None) -> dict:
        """
        Human-readable incident report for a time window.
        Returns summary, deny events, top rules, pattern shifts, manifest hash.
        """
        return self.auditor.explain(from_ts=from_ts, to_ts=to_ts, action_class=action_class)

    def export_bundle(self, path, from_ts=None, to_ts=None,
                      action_class=None, include_report=True) -> dict:
        """
        Export tamper-evident audit bundle to JSON.
        Each receipt is independently verifiable via Ed25519 signature.
        Manifest hash detects any addition, removal, or reordering.
        """
        from pathlib import Path as _Path
        return self.auditor.export_bundle(
            path=_Path(path), from_ts=from_ts, to_ts=to_ts,
            action_class=action_class, include_report=include_report,
        )

    def index_from_json_dir(self, receipts_dir: Path) -> int:
        """
        Backfill the engine DB from JSON receipt files in receipts_dir.

        Reads every TR-*.json file in the directory and writes any receipts
        not yet in the DB (INSERT OR IGNORE — safe to call repeatedly).
        Returns the count of newly indexed receipts.

        This is the bridge between the always-on JSON audit trail and the
        engine's queryable SQLite index. Call it before explain/query to
        guarantee the engine sees the full receipt history.
        """
        receipts_dir = Path(receipts_dir)
        if not receipts_dir.exists():
            return 0

        count = 0
        for f in sorted(receipts_dir.glob("TR-*.json"), key=lambda p: p.stat().st_mtime):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except Exception as exc:
                _log.debug("index_from_json_dir: skip unreadable %s: %s", f.name, exc)
                continue

            raw_receipt = data.get("receipt", data)
            if not isinstance(raw_receipt, dict) or "signature" not in raw_receipt:
                continue

            intent   = data.get("intent", {})
            decision = data.get("decision", {})
            target   = intent.get("target", {}) if isinstance(intent.get("target"), dict) else {}

            # Reconstruct the engine_receipt shape expected by store.write()
            ts_str = raw_receipt.get("captured_at") or raw_receipt.get("sealed_at")
            ts     = _parse_iso_ts(ts_str) if ts_str else f.stat().st_mtime

            reason_code = decision.get("reason_code", "")
            raw_outcome = decision.get("outcome", "allow")
            outcome = (
                "deny"
                if "would_be_deny" in reason_code and decision.get("matched_rule_id")
                else raw_outcome
            )

            engine_receipt = {
                **raw_receipt,
                "action_class":        intent.get("action_class"),
                "tool_name":           intent.get("action"),
                "outcome":             outcome,
                "host":                target.get("host"),
                "path":                target.get("path"),
                "matched_rule_id":     decision.get("matched_rule_id"),
                "matched_rule_reason": decision.get("matched_rule_reason"),
                "matched_package":     decision.get("matched_package"),
                "ts":                  ts,
            }

            try:
                self.store_backend.write(engine_receipt)
                count += 1
            except Exception as exc:
                _log.debug("index_from_json_dir: skip %s: %s", f.name, exc)

        if count:
            _log.info("[receipt-engine] indexed %d new receipts from %s", count, receipts_dir)

        return count

    def index_sessions_from_json_dir(self, sessions_dir: Path) -> int:
        """
        Backfill the sessions table from legacy session-*.json files.

        Reads every session-*.json and inserts the signing public key into
        the sessions table (INSERT OR IGNORE — safe to call repeatedly).
        Returns count of newly indexed sessions.
        """
        sessions_dir = Path(sessions_dir)
        if not sessions_dir.exists():
            return 0

        count = 0
        for f in sessions_dir.glob("session-*.json"):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except Exception as exc:
                _log.debug("index_sessions_from_json_dir: skip unreadable %s: %s", f.name, exc)
                continue

            r       = data.get("receipt", {})
            pk_hex  = r.get("signingPublicKey")
            env     = r.get("environment", {})
            sid     = env.get("sessionId")
            run_id  = env.get("runId")
            env_fp  = r.get("environmentFingerprint")

            if not (pk_hex and sid):
                continue

            kid = f"{sid}:1"
            ts_str = data.get("created_at") or r.get("sessionStartedAt", "")
            try:
                ts = _parse_iso_ts(ts_str) if ts_str else f.stat().st_mtime
            except Exception:
                ts = f.stat().st_mtime

            try:
                self.store_backend.write_session(
                    kid=kid,
                    session_id=sid,
                    pubkey_hex=pk_hex,
                    created_at=ts,
                    run_id=run_id,
                    env_fingerprint=env_fp,
                )
                count += 1
            except Exception as exc:
                _log.debug("index_sessions_from_json_dir: skip %s: %s", f.name, exc)

        if count:
            _log.info("[receipt-engine] indexed %d sessions from %s", count, sessions_dir)

        return count

    def migrate_legacy_json(self, state_dir: Path) -> dict:
        """
        One-shot migration: backfill receipts and sessions from legacy JSON dirs.

        Safe to call on every startup — INSERT OR IGNORE means it's a no-op
        once the DB is populated. Returns counts of newly indexed records.
        """
        state_dir = Path(state_dir)
        receipts_indexed = self.index_from_json_dir(state_dir / "receipts")
        sessions_indexed = self.index_sessions_from_json_dir(state_dir / "sessions")
        # Also drain spill dir if present
        spill_dir = state_dir / "receipts" / ".spill"
        spill_indexed = self.index_from_json_dir(spill_dir) if spill_dir.exists() else 0
        if spill_indexed:
            _log.info("[receipt-engine] drained %d receipts from spill dir", spill_indexed)
        return {
            "receipts": receipts_indexed,
            "sessions": sessions_indexed,
            "spill":    spill_indexed,
        }

    def stats(self) -> dict:
        """Return engine health stats."""
        return {
            "total_receipts": self.store_backend.count(),
            "patterns":       len(self.distiller.get_patterns()),
            "promoted_rules": self.promoter.promoted_count() if self.promoter else 0,
            "promoted_list":  self.promoter.list_promoted() if self.promoter else [],
        }

    def _on_promote(self, rule_id: str, pattern: dict) -> None:
        """Called by RulePromoter when a pattern is promoted to a governance rule."""
        _log.info("Learning: promoted rule %s (confidence=%.2f, count=%d)",
                  rule_id, pattern.get("confidence", 0), pattern.get("count", 0))
        if not self._events_dir:
            return
        try:
            self._events_dir.mkdir(parents=True, exist_ok=True)
            from transient_trace.atp.id_generator import generate_id
            event_id = generate_id("lrn")
            event = {
                "type": "learning_promoted",
                "id": event_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "rule_id": rule_id,
                "action_class": pattern.get("action_class"),
                "tool_name": pattern.get("tool_name"),
                "outcome": pattern.get("outcome"),
                "confidence": pattern.get("confidence"),
                "count": pattern.get("count"),
            }
            event_file = self._events_dir / f"{event_id}.json"
            event_file.write_text(json.dumps(event), encoding="utf-8")
        except Exception as exc:
            _log.warning("Could not write promotion event: %s", exc)


__all__ = [
    "ReceiptEngine",
    "ReceiptStore",
    "PatternDistiller",
    "RulePromoter",
    "Injector",
]
