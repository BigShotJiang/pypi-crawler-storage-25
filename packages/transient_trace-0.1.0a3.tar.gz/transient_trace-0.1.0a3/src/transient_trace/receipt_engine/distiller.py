"""
distiller.py — PatternDistiller

Reads the ReceiptStore, computes patterns, writes a hint cache.

Runs in the background whenever N new receipts arrive (default N=10).
Output is a set of compressed pattern entries — one entry per
(action_class, tool_name, outcome, rule_id) tuple — with confidence scores.

Ambiguous patterns (same action + tool but conflicting outcomes) are flagged
and never auto-promoted — both outcomes are surfaced in the inject.

Usage:
    distiller = PatternDistiller(store)
    distiller.run()          # blocking — call from background thread
    patterns = distiller.get_patterns()
    distiller.start()        # non-blocking background thread
"""

import logging
import threading
import time
from typing import Optional

from .store import ReceiptStore

_log = logging.getLogger(__name__)

# How many new receipts trigger a distillation pass
_DEFAULT_TRIGGER_COUNT = 10

# Minimum receipts before a pattern is considered stable
_MIN_COUNT_FOR_PATTERN = 3


class PatternDistiller:
    """
    Background process: receipts → compressed patterns → hint cache.

    Pattern entry schema:
    {
        "action_class":  str,
        "tool_name":     str,
        "outcome":       str,      # "allow" | "deny" | "challenge"
        "rule_id":       str | None,
        "rule_reason":   str | None,
        "package_name":  str | None,
        "count":         int,
        "confidence":    float,    # count / total_for_this_action+tool
        "last_seen":     float,    # unix ts
        "ambiguous":     bool,     # True if conflicting outcomes exist for same pattern
        "promoted":      bool,     # True if promoted to governance rule
    }
    """

    def __init__(
        self,
        store: ReceiptStore,
        trigger_count: int = _DEFAULT_TRIGGER_COUNT,
    ) -> None:
        self._store = store
        self._trigger_count = trigger_count
        self._patterns: list[dict] = []
        self._lock = threading.Lock()
        self._new_since_last_run = 0
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        # Persists across re-distillation — promoter registers rule IDs here
        # so re-distilled patterns can be marked promoted: True correctly.
        self._promoted_pattern_keys: set[str] = set()

        # Register for new-receipt callbacks
        store.on_write(self._on_new_receipt)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_patterns(self) -> list[dict]:
        """Return the current distilled pattern list (thread-safe deep copy).

        Returns independent copies of pattern dicts so callers cannot
        accidentally mutate the distiller's internal state.
        """
        with self._lock:
            return [dict(p) for p in self._patterns]

    def mark_promoted(self, pattern_key: str) -> None:
        """
        Permanently mark a pattern key as promoted.

        Called by RulePromoter after a rule is written to the registry.
        Does two things atomically under the lock:
        1. Adds key to _promoted_pattern_keys — persists across re-distillation
        2. Updates current _patterns in place — injector sees promoted=True
           immediately in the same cycle, without waiting for next distill pass.
        """
        with self._lock:
            self._promoted_pattern_keys.add(pattern_key)
            # Immediately flip promoted=True on current in-memory patterns
            # so the injector suppresses them in the current cycle.
            # get_patterns() returns deep copies, so external callers see the
            # update on their next call — no stale promoted=False copies linger.
            for p in self._patterns:
                if p.get("_pattern_key") == pattern_key:
                    p["promoted"] = True

    def run(self) -> None:
        """Run a distillation pass synchronously. Blocks until complete."""
        self._distill()

    def start(self) -> None:
        """Start the background distillation thread."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._background_loop,
            name="receipt-engine-distiller",
            daemon=True,
        )
        self._thread.start()
        _log.debug("PatternDistiller background thread started")

    def stop(self) -> None:
        """Signal the background thread to stop."""
        self._stop_event.set()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _on_new_receipt(self, receipt: dict) -> None:
        self._new_since_last_run += 1
        if self._new_since_last_run >= self._trigger_count:
            self._new_since_last_run = 0
            # Run in background — don't block the write path
            threading.Thread(
                target=self._distill,
                name="receipt-engine-distill-trigger",
                daemon=True,
            ).start()

    def _background_loop(self) -> None:
        """Periodically run distillation even without write triggers."""
        while not self._stop_event.is_set():
            try:
                self._distill()
            except Exception as exc:  # noqa: BLE001
                _log.error("PatternDistiller error: %s", exc)
            # Sleep between periodic runs — wake early if stop signalled
            self._stop_event.wait(timeout=300)  # 5-minute periodic sweep

    def _distill(self) -> None:
        """Core distillation logic."""
        try:
            raw_stats = self._store.stats()
        except Exception as exc:  # noqa: BLE001
            _log.error("PatternDistiller: store.stats() failed: %s", exc)
            return

        # Group by (action_class, tool_name) to compute totals for confidence
        totals: dict[tuple, int] = {}
        for row in raw_stats:
            key = (row["action_class"], row["tool_name"])
            totals[key] = totals.get(key, 0) + row["count"]

        # Detect ambiguous patterns — same (action_class, tool_name, rule_id)
        # but multiple different outcomes
        outcome_groups: dict[tuple, set] = {}
        for row in raw_stats:
            key = (row["action_class"], row["tool_name"], row["rule_id"])
            if key not in outcome_groups:
                outcome_groups[key] = set()
            outcome_groups[key].add(row["outcome"])

        patterns: list[dict] = []
        with self._lock:
            promoted_keys = set(self._promoted_pattern_keys)

        for row in raw_stats:
            if not row["action_class"] and not row["tool_name"]:
                continue  # skip rows with no indexable context
            if row["count"] < _MIN_COUNT_FOR_PATTERN:
                continue  # not enough evidence yet

            total = totals.get((row["action_class"], row["tool_name"]), 1)
            confidence = row["count"] / total if total > 0 else 0.0

            ambig_key = (row["action_class"], row["tool_name"], row["rule_id"])
            ambiguous = len(outcome_groups.get(ambig_key, set())) > 1

            # Build the same key the promoter uses so promoted flag survives re-distillation
            from .promoter import RulePromoter  # local import to avoid circular dep at module level
            pattern_key = RulePromoter._make_rule_id({
                "action_class": row["action_class"],
                "tool_name":    row["tool_name"],
                "outcome":      row["outcome"],
            })

            patterns.append({
                "action_class":  row["action_class"],
                "tool_name":     row["tool_name"],
                "outcome":       row["outcome"],
                "rule_id":       row["rule_id"],
                "rule_reason":   row["rule_reason"],
                "package_name":  row["package_name"],
                "count":         row["count"],
                "confidence":    round(confidence, 4),
                "last_seen":     row["last_seen"],
                "ambiguous":     ambiguous,
                # Promoted status persists across re-distillation via _promoted_pattern_keys
                "promoted":      pattern_key in promoted_keys,
                # Internal key used by mark_promoted() for O(n) in-place update.
                # Prefixed with _ to signal it's internal — injector/promoter ignore it.
                "_pattern_key":  pattern_key,
            })

        with self._lock:
            self._patterns = patterns

        _log.debug(
            "PatternDistiller: distilled %d stats → %d patterns",
            len(raw_stats),
            len(patterns),
        )
