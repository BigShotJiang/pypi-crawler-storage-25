"""
audit.py — ReceiptAuditor

Queryable audit layer over the ReceiptStore.

Turns receipt noise into meaningful incident reports and exportable audit
bundles for internal review, external stakeholders, and regulatory examination.

Usage:
    auditor = ReceiptAuditor(store)

    # Query receipts in a time window
    receipts = auditor.query(from_ts="2026-04-06", to_ts="2026-04-07")

    # Explain what happened in a window — human-readable incident summary
    report = auditor.explain(from_ts="2026-04-06", to_ts="2026-04-07")

    # Export tamper-evident audit bundle for external review
    auditor.export_bundle(
        from_ts="2026-04-06",
        to_ts="2026-04-07",
        path=Path("incident-apr6.json")
    )
"""

import hashlib
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union

from .store import ReceiptStore

_log = logging.getLogger(__name__)

# ISO date string or unix timestamp
Timestamp = Union[str, float, int]


def _to_unix(ts: Timestamp) -> float:
    """Convert ISO date string or unix timestamp to float."""
    if isinstance(ts, (int, float)):
        return float(ts)
    # Try ISO format: "2026-04-06" or "2026-04-06T14:00:00Z"
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(ts, fmt).replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue
    raise ValueError(f"Cannot parse timestamp: {ts!r}")


def _fmt_ts(unix_ts: Optional[float]) -> str:
    if not unix_ts:
        return "unknown"
    return datetime.fromtimestamp(unix_ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


class ReceiptAuditor:
    """
    Queryable audit layer over ReceiptStore.

    Provides time-range queries, incident reports, and exportable bundles
    for external verification.
    """

    def __init__(self, store: ReceiptStore) -> None:
        self._store = store

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def query(
        self,
        from_ts: Optional[Timestamp] = None,
        to_ts: Optional[Timestamp] = None,
        action_class: Optional[str] = None,
        tool_name: Optional[str] = None,
        outcome: Optional[str] = None,
        limit: int = 500,
    ) -> list[dict]:
        """
        Query receipts with optional time range and filters.

        from_ts / to_ts accept:
          - Unix timestamp (float)
          - ISO date string: "2026-04-06" or "2026-04-06T14:00:00Z"

        Returns list of signed receipt dicts, ordered by time ascending.
        """
        # Use explicit None check — 0.0 (Unix epoch) is a valid timestamp but is falsy
        from_unix = _to_unix(from_ts) if from_ts is not None else None
        to_unix   = _to_unix(to_ts)   if to_ts   is not None else None

        clauses = []
        params: list = []

        if from_unix is not None:
            clauses.append("ts >= ?")
            params.append(from_unix)
        if to_unix is not None:
            # to_ts is end of day if date-only string
            if isinstance(to_ts, str) and len(to_ts) == 10:
                to_unix += 86400  # include full day
            clauses.append("ts <= ?")
            params.append(to_unix)
        if action_class:
            clauses.append("action_class = ?")
            params.append(action_class)
        if tool_name:
            clauses.append("tool_name = ?")
            params.append(tool_name)
        if outcome:
            clauses.append("outcome = ?")
            params.append(outcome)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT payload FROM receipts {where} ORDER BY ts ASC LIMIT ?"
        params.append(limit)

        with self._store._lock:
            rows = self._store._conn.execute(sql, params).fetchall()

        results = []
        for (payload,) in rows:
            try:
                results.append(json.loads(payload))
            except json.JSONDecodeError:
                pass
        return results

    # ------------------------------------------------------------------
    # Explain — incident report
    # ------------------------------------------------------------------

    def explain(
        self,
        from_ts: Optional[Timestamp] = None,
        to_ts: Optional[Timestamp] = None,
        action_class: Optional[str] = None,
    ) -> dict:
        """
        Generate a human-readable incident report for a time window.

        Returns a structured report dict with:
          - summary: counts, outcome breakdown, time range
          - denies: list of deny events with reason and timestamp
          - pattern_shifts: action classes where outcome changed in window
          - top_rules: most-fired governance rules
          - verification: receipt count + manifest hash
        """
        receipts = self.query(
            from_ts=from_ts,
            to_ts=to_ts,
            action_class=action_class,
            limit=10000,
        )
        return self._report_from_receipts(receipts, from_ts=from_ts, to_ts=to_ts)

    def _report_from_receipts(
        self,
        receipts: list[dict],
        from_ts: Optional[Timestamp] = None,
        to_ts: Optional[Timestamp] = None,
    ) -> dict:
        """
        Build an incident report from a pre-fetched receipts list.

        Used internally by both explain() and export_bundle() to avoid
        querying the database twice for the same time window.
        """
        if not receipts:
            return {
                "summary": {
                    "total":      0,
                    "from":       _fmt_ts(_to_unix(from_ts) if from_ts else None),
                    "to":         _fmt_ts(_to_unix(to_ts) if to_ts else None),
                    "message":    "no receipts found in this window",
                },
            }

        # Outcome counts — governance-deny-events counted separately so they
        # don't distort the deny_rate of properly executed actions
        outcome_counts: dict[str, int] = {}
        for r in receipts:
            o = r.get("outcome", "unknown")
            outcome_counts[o] = outcome_counts.get(o, 0) + 1

        # Deny events — include deny-events (pre-execution denials) and
        # executed denials; exclude those with no rule metadata (policy default)
        denies = [
            {
                "ts":           _fmt_ts(r.get("ts")),
                "action":       f"{r.get('action_class', '?')}/{r.get('tool_name', '?')}",
                "rule_id":      r.get("matched_rule_id"),
                "reason":       r.get("matched_rule_reason"),
                "receipt_id":   r.get("receipt_id"),
                "receipt_type": r.get("receipt_type", "action"),
            }
            for r in receipts if r.get("outcome") == "deny"
        ]

        # Top rules fired — only count named rules, not default-policy denials
        rule_counts: dict[str, int] = {}
        for r in receipts:
            rid = r.get("matched_rule_id")
            if rid:
                rule_counts[rid] = rule_counts.get(rid, 0) + 1
        top_rules = sorted(rule_counts.items(), key=lambda x: -x[1])[:5]

        # Pattern shifts — action classes where both allow and deny appear
        ac_outcomes: dict[str, set] = {}
        for r in receipts:
            ac = r.get("action_class", "unknown")
            if ac not in ac_outcomes:
                ac_outcomes[ac] = set()
            ac_outcomes[ac].add(r.get("outcome", "unknown"))
        pattern_shifts = [
            ac for ac, outcomes in ac_outcomes.items()
            if "deny" in outcomes and "allow" in outcomes
        ]

        # Timestamps
        ts_values = [r.get("ts") for r in receipts if r.get("ts")]
        earliest = min(ts_values) if ts_values else None
        latest   = max(ts_values) if ts_values else None

        # Manifest hash — proves the set of receipts hasn't been tampered with
        manifest_hash = _hash_receipt_set(receipts)

        return {
            "summary": {
                "total":          len(receipts),
                "from":           _fmt_ts(earliest),
                "to":             _fmt_ts(latest),
                "outcomes":       outcome_counts,
                "deny_rate":      round(outcome_counts.get("deny", 0) / len(receipts), 4),
            },
            "denies":         denies[:50],  # cap at 50 for readability
            "top_rules":      [{"rule_id": r, "count": c} for r, c in top_rules],
            "pattern_shifts": pattern_shifts,
            "verification": {
                "receipt_count":  len(receipts),
                "manifest_hash":  manifest_hash,
                "note":           "verify individual receipts via Ed25519 signature on each receipt",
            },
        }

    # ------------------------------------------------------------------
    # Export — tamper-evident audit bundle
    # ------------------------------------------------------------------

    def export_bundle(
        self,
        path: Path,
        from_ts: Optional[Timestamp] = None,
        to_ts: Optional[Timestamp] = None,
        action_class: Optional[str] = None,
        include_report: bool = True,
    ) -> dict:
        """
        Export a tamper-evident audit bundle to a JSON file.

        The bundle contains:
          - receipts: all signed receipts in the window (independently verifiable)
          - report: human-readable incident summary
          - manifest: hash of all receipt IDs — detects additions or removals
          - exported_at: timestamp of export

        External reviewers can:
          1. Verify each receipt's Ed25519 signature independently
          2. Verify the manifest hash matches the receipt set
          3. Check timestamps are within the declared window

        Any tampering — adding, removing, or modifying a receipt — breaks
        either the individual signature or the manifest hash.
        """
        receipts = self.query(
            from_ts=from_ts,
            to_ts=to_ts,
            action_class=action_class,
            limit=100000,
        )

        manifest_hash = _hash_receipt_set(receipts)
        exported_at = datetime.now(tz=timezone.utc).isoformat().replace("+00:00", "Z")

        bundle: dict = {
            "bundle_version": "1.0.0",
            "exported_at":    exported_at,
            "window": {
                "from": str(from_ts) if from_ts else None,
                "to":   str(to_ts)   if to_ts   else None,
            },
            "manifest": {
                "receipt_count": len(receipts),
                "hash":          manifest_hash,
                "algorithm":     "sha256",
                "note":          "hash of sorted receipt_ids — detects additions or removals",
            },
            "receipts": receipts,
        }

        if include_report:
            # Use pre-fetched receipts — avoids a second DB query for the same window
            bundle["report"] = self._report_from_receipts(receipts, from_ts=from_ts, to_ts=to_ts)

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")

        _log.info(
            "ReceiptAuditor: exported %d receipts to %s (manifest=%s…)",
            len(receipts),
            path,
            manifest_hash[:12],
        )

        return {
            "path":           str(path),
            "receipt_count":  len(receipts),
            "manifest_hash":  manifest_hash,
            "exported_at":    exported_at,
        }


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _hash_receipt_set(receipts: list[dict]) -> str:
    """
    SHA-256 hash of sorted receipt IDs.

    Detects any addition, removal, or reordering of receipts in the set.
    Does not detect modification of individual receipts — that's the
    job of each receipt's Ed25519 signature.
    """
    ids = sorted(
        str(r.get("receipt_id", r.get("id", "")))
        for r in receipts
    )
    payload = "\n".join(ids).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
