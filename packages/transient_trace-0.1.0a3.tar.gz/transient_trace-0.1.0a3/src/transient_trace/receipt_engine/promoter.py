"""
promoter.py — RulePromoter

Reads PatternDistiller output. When a pattern's confidence crosses the
promotion threshold, writes a governance rule into the PackageRegistry
as a 'learned/*' package.

Promotion thresholds (defaults):
    confidence >= 0.95 AND count >= 50

Ambiguous patterns are NEVER promoted — both outcomes surfaced in inject only.

Promoted rules live in a separate 'learned' package so they can be:
    - Inspected independently from authored packages
    - Rolled back without affecting receipt history
    - Overridden by authored rules (authored takes precedence)

Usage:
    promoter = RulePromoter(distiller, registry)
    promoter.run()     # check distiller patterns → promote eligible ones
    promoter.start()   # background thread, runs after every distillation
"""

import logging
import threading
import time
from typing import Optional

from .distiller import PatternDistiller

_log = logging.getLogger(__name__)

# Promotion thresholds
_MIN_CONFIDENCE = 0.95
_MIN_COUNT = 50

# Name for the auto-generated learned package
_LEARNED_PACKAGE_NAME = "learned"


class RulePromoter:
    """
    Promotes high-confidence patterns into the PackageRegistry as a
    'learned' package.

    After promotion, the pattern is marked promoted=True in the distiller.
    The injector skips promoted patterns (zero tokens — PEP enforces directly).
    """

    def __init__(
        self,
        distiller: PatternDistiller,
        registry,  # PackageRegistry — typed loosely to avoid circular import
        min_confidence: float = _MIN_CONFIDENCE,
        min_count: int = _MIN_COUNT,
        on_promote=None,  # Optional[Callable[[str, dict], None]]
    ) -> None:
        self._distiller = distiller
        self._registry = registry
        self._min_confidence = min_confidence
        self._min_count = min_count
        self._on_promote = on_promote  # called with (rule_id, pattern) on each new promotion
        self._promoted_rule_ids: set[str] = set()
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Run a promotion pass synchronously."""
        self._promote()

    def start(self) -> None:
        """Start background promotion thread."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._background_loop,
            name="receipt-engine-promoter",
            daemon=True,
        )
        self._thread.start()
        _log.debug("RulePromoter background thread started")

    def stop(self) -> None:
        self._stop_event.set()

    def promoted_count(self) -> int:
        with self._lock:
            return len(self._promoted_rule_ids)

    def list_promoted(self) -> list[str]:
        with self._lock:
            return list(self._promoted_rule_ids)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _background_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._promote()
            except Exception as exc:  # noqa: BLE001
                _log.error("RulePromoter error: %s", exc)
            self._stop_event.wait(timeout=60)

    def _promote(self) -> None:
        patterns = self._distiller.get_patterns()
        newly_promoted = []

        # Aggregate same-outcome patterns for the same (action_class, tool_name) group.
        # The distiller keeps one row per (action_class, tool_name, outcome, rule_id),
        # so a "network/curl/deny" signal may be split across multiple rule_id rows.
        # We must sum them before checking thresholds — otherwise the confidence for
        # each sub-row is diluted and promotion never fires.
        aggregated: dict[tuple, dict] = {}
        total_by_key: dict[tuple, int] = {}
        for p in patterns:
            key = (p.get("action_class"), p.get("tool_name"))
            total_by_key[key] = total_by_key.get(key, 0) + p["count"]
        for p in patterns:
            if p["outcome"] not in ("deny", "challenge"):
                continue
            if p.get("ambiguous") or p.get("promoted"):
                continue
            agg_key = (p.get("action_class"), p.get("tool_name"), p["outcome"])
            if agg_key not in aggregated:
                aggregated[agg_key] = dict(p)  # copy, take first row's metadata
            else:
                aggregated[agg_key]["count"] += p["count"]
            # Recompute confidence from the aggregated count
            total = total_by_key.get((p.get("action_class"), p.get("tool_name")), 1)
            aggregated[agg_key]["confidence"] = round(aggregated[agg_key]["count"] / total, 4)

        for pattern in aggregated.values():
            if (
                pattern["confidence"] >= self._min_confidence
                and pattern["count"] >= self._min_count
            ):
                rule_id = self._make_rule_id(pattern)
                if rule_id not in self._promoted_rule_ids:
                    self._write_learned_rule(pattern, rule_id)
                    with self._lock:
                        self._promoted_rule_ids.add(rule_id)
                    # Persist promotion via distiller so re-distillation
                    # rebuilds patterns with promoted=True. Never mutate
                    # the pattern dict directly — it's a copy, but it also
                    # signals to the distiller's internal state through mark_promoted().
                    self._distiller.mark_promoted(rule_id)
                    newly_promoted.append((rule_id, pattern))

        if newly_promoted:
            _log.info(
                "RulePromoter: promoted %d new rules → %s",
                len(newly_promoted),
                [r for r, _ in newly_promoted],
            )
            if self._on_promote:
                for rule_id, pattern in newly_promoted:
                    try:
                        self._on_promote(rule_id, pattern)
                    except Exception as exc:
                        _log.warning("on_promote callback failed: %s", exc)

    @staticmethod
    def _infer_profile(pattern: dict) -> str:
        """
        Infer the PEP profile (exec vs egress) from the pattern.

        Egress rules apply to network/web outbound actions.
        Everything else is exec (filesystem, process, database, etc.).
        """
        ac = str(pattern.get("action_class") or "").lower()
        tool = str(pattern.get("tool_name") or "").lower()
        egress_signals = ("web", "network", "egress", "http", "https", "outbound")
        if any(s in ac for s in egress_signals) or any(s in tool for s in ("http", "https", "request", "fetch")):
            return "egress"
        # A pattern with a host field is egress
        if pattern.get("host"):
            return "egress"
        return "exec"

    def _write_learned_rule(self, pattern: dict, rule_id: str) -> None:
        """Write or update the 'learned' package with the new rule."""
        rule = {
            "id":      rule_id,
            "profile": self._infer_profile(pattern),  # required by PackageRegistry schema
            "source":  "receipt-engine",
            "condition": self._build_condition(pattern),
            "outcome":   pattern["outcome"],
            "reason":    (
                f"{pattern.get('rule_reason') or 'learned pattern'} "
                f"(evidence: {pattern['count']} receipts, "
                f"confidence: {pattern['confidence']:.0%})"
            ),
            "evidence_count": pattern["count"],
            "confidence":     pattern["confidence"],
            "promoted_at":    time.time(),
        }

        # Try to add to existing learned package, or create a new one
        try:
            existing = self._registry.describe(_LEARNED_PACKAGE_NAME)
            existing["rules"].append(rule)
            # Re-load to update registry (registry validates on load)
            # We directly update the internal dict here since PackageRegistry
            # doesn't have an update API — the learned package is mutable by design
            self._registry._packages[_LEARNED_PACKAGE_NAME] = existing
            _log.debug("RulePromoter: appended rule %s to learned package", rule_id)
        except (KeyError, Exception):
            # Create learned package fresh
            learned_pkg = {
                "name":        _LEARNED_PACKAGE_NAME,
                "version":     "1.0.0",
                "description": "Auto-promoted governance rules from verified receipt patterns",
                "source":      "receipt-engine",
                "rules":       [rule],
            }
            try:
                self._registry.load(learned_pkg)
                _log.info("RulePromoter: created 'learned' package with rule %s", rule_id)
            except ValueError as exc:
                # Package already exists with that name — shouldn't happen but handle gracefully
                _log.warning("RulePromoter: could not load learned package: %s", exc)

    def _build_condition(self, pattern: dict) -> dict:
        """Build a governance rule condition from a distilled pattern."""
        condition: dict = {}
        if pattern.get("action_class"):
            condition["action_class"] = pattern["action_class"]
        if pattern.get("tool_name"):
            condition["toolName"] = pattern["tool_name"]
        # Note: path/host patterns require receipt-level extraction in future
        # For now, condition matches action_class + toolName combination
        return condition

    @staticmethod
    def _make_rule_id(pattern: dict) -> str:
        parts = [
            "learned",
            pattern.get("action_class") or "any",
            pattern.get("tool_name") or "any",
            pattern.get("outcome") or "deny",
        ]
        return "-".join(p.replace("/", "_").replace(" ", "_") for p in parts if p)
