"""
injector.py — Injector

At action time, queries the PatternDistiller hint cache for the current
action context and returns a compressed governance context string.

Hard cap: 80 tokens (≈320 chars). If patterns exceed the cap, prioritise:
    1. DENY outcomes (failures teach more)
    2. High confidence
    3. Most recent

The inject is a pre-computed cache lookup — O(1), no LLM call, no receipt scan.

Usage:
    injector = Injector(distiller)
    context_str = injector.inject(action_class="filesystem", tool_name="write_file")

    # Returns something like:
    # "GOVERNANCE_CONTEXT:\n  filesystem/write_file: /etc/* → DENY(99%, ASI-07, 47 runs)\n"
    # or "" if no relevant patterns exist
"""

import logging
from typing import Optional

from .distiller import PatternDistiller

_log = logging.getLogger(__name__)

# Hard cap in characters (≈80 tokens at ~4 chars/token)
_MAX_CHARS = 320

# Minimum confidence to surface a pattern in the inject
_MIN_INJECT_CONFIDENCE = 0.7

# Minimum count before a pattern appears in inject
_MIN_INJECT_COUNT = 3


class Injector:
    """
    Converts distilled patterns into a compressed governance context string.

    Called at action dispatch time — must be fast (cache lookup only).
    """

    def __init__(self, distiller: PatternDistiller) -> None:
        self._distiller = distiller

    def inject(
        self,
        action_class: Optional[str] = None,
        tool_name: Optional[str] = None,
        host: Optional[str] = None,
        path: Optional[str] = None,
    ) -> str:
        """
        Return a compressed governance context string for the current action.

        Returns empty string if no relevant patterns exist or all are promoted
        (promoted patterns are enforced by PEP — no tokens needed).

        The returned string is safe to prepend to an agent prompt.
        """
        patterns = self._distiller.get_patterns()

        if not patterns:
            return ""

        # Filter to relevant patterns
        relevant = self._filter(patterns, action_class, tool_name, host, path)

        if not relevant:
            return ""

        # Prioritise: DENY first, then by confidence desc, then recency desc
        relevant.sort(
            key=lambda p: (
                0 if p["outcome"] == "deny" else (1 if p["outcome"] == "challenge" else 2),
                -p["confidence"],
                -(p["last_seen"] or 0),
            )
        )

        lines = ["GOVERNANCE_CONTEXT:"]
        chars_used = len(lines[0]) + 1

        for pattern in relevant:
            line = self._format_pattern(pattern)
            if chars_used + len(line) + 1 > _MAX_CHARS:
                break
            lines.append(f"  {line}")
            chars_used += len(line) + 3  # "  " prefix + newline

        if len(lines) == 1:
            return ""  # only header, nothing fit

        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _filter(
        self,
        patterns: list[dict],
        action_class: Optional[str],
        tool_name: Optional[str],
        host: Optional[str],
        path: Optional[str],
    ) -> list[dict]:
        results = []
        for p in patterns:
            # Skip promoted — PEP handles these, no tokens needed
            if p.get("promoted"):
                continue

            # Skip ambiguous — contradictory signal is worse than no signal.
            # Ambiguous patterns are surfaced by explain() for human review, not injected.
            if p.get("ambiguous"):
                continue

            # Skip low-confidence or low-count patterns
            if p["confidence"] < _MIN_INJECT_CONFIDENCE:
                continue
            if p["count"] < _MIN_INJECT_COUNT:
                continue

            # Match on action_class if provided
            if action_class and p.get("action_class"):
                if p["action_class"].lower() != action_class.lower():
                    continue

            # Match on tool_name if provided
            if tool_name and p.get("tool_name"):
                if p["tool_name"].lower() != tool_name.lower():
                    continue

            results.append(p)

        return results

    @staticmethod
    def _format_pattern(pattern: dict) -> str:
        """
        Format a pattern as a compact single-line string.

        Examples:
            filesystem/write_file: DENY(99%, ASI-07, 47 runs)
            web/http_request[external]: CHALLENGE(85%, ASI-05, 12 runs)
            code/execute_code: ALLOW(100%, 203 runs)
        """
        action = pattern.get("action_class") or "any"
        tool   = pattern.get("tool_name") or "any"
        outcome = (pattern.get("outcome") or "?").upper()
        confidence = f"{pattern['confidence']:.0%}"
        count = pattern["count"]

        label = f"{action}/{tool}"

        reason_parts = []
        if pattern.get("rule_id") and "learned" not in str(pattern.get("rule_id", "")):
            reason_parts.append(str(pattern["rule_id"]))
        if pattern.get("ambiguous"):
            reason_parts.append("ambiguous")

        reason_str = ", ".join(reason_parts)
        if reason_str:
            return f"{label}: {outcome}({confidence}, {reason_str}, {count} runs)"
        return f"{label}: {outcome}({confidence}, {count} runs)"
