from typing import Any, Literal, TypedDict
from typing_extensions import NotRequired


ActionClass = Literal["read", "write_low", "write_high", "delete", "bulk_export"]


class Intent(TypedDict):
    intent_id: str
    actor_id: str
    connector: str
    action: str
    action_class: ActionClass
    target: dict[str, Any]   # ATP spec: intent.schema.json target is "type": "object"
    context: dict[str, Any]
    governance_profile: str
    requested_at: str
    metadata: NotRequired[dict[str, Any]]   # ATP spec: optional, max 20 properties


class Decision(TypedDict):
    decision_id: str
    intent_id: str
    outcome: Literal["allow", "approve", "deny"]
    reason_code: str
    decided_at: str
    rule_id: NotRequired[str]
    expires_at: NotRequired[str]


class SignatureObject(TypedDict):
    alg: Literal["Ed25519"]
    kid: str
    sig: str
    canonicalization: Literal["RFC8785-JCS"]
    version: NotRequired[str]


class CostObject(TypedDict):
    amount: str
    currency: str
    unit: NotRequired[str]
    payer: NotRequired[str]


class UnsignedReceipt(TypedDict):
    receipt_id: str
    intent_id: str
    decision_id: str
    execution_status: Literal["executed", "blocked", "expired", "error"]
    captured_at: str
    schemaVersion: Literal["1.0.0"]
    occurred_at: str
    received_at: str
    sealed_at: str
    event_snapshot: dict[str, Any]
    event_snapshot_hash: str
    correlation_id: str
    input_hash: NotRequired[str]
    output_hash: NotRequired[str]
    cost: NotRequired[CostObject]
    rule_id: NotRequired[str]
    governance_trace: NotRequired[Any]


class Receipt(UnsignedReceipt):
    signature: SignatureObject
