"""
_popen_hook.py — Monkey-patches subprocess.Popen to intercept all subprocess calls.

Installed via sitecustomize.py written by `transient-trace run` into a temp dir
that's prepended to PYTHONPATH. Python auto-imports sitecustomize.py before any
user code — so this fires even when the agent runtime calls binaries by absolute
path (bypassing PATH shimming).

Interception model:
  - Pre-execution governance check (allow/deny decision + receipt)
  - If allowed: Popen proceeds normally, real output goes to the process
  - If denied:  sys.exit(126) before the process is launched
  - On error:   fail-open (log warning, let Popen proceed)

Only intercepts binaries listed in TRANSIENT_TRACE_SHIM_TARGETS env var
(comma-separated names). This keeps the scope tight and avoids intercepting
internal Python machinery.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Optional

_log = logging.getLogger("transient_trace.popen_hook")

_lock = threading.Lock()
_client = None          # one Client per Python process, lazy-init
_active = threading.local()  # re-entrancy guard per thread


def _cfg_from_env() -> dict:
    from transient_trace._config import load_shim_config
    return load_shim_config()


def _get_client():
    """Return the shared Client, creating it once per process."""
    global _client
    if _client is not None:
        return _client
    with _lock:
        if _client is None:
            from transient_trace import Client
            _client = Client(_cfg_from_env())
    return _client


def _shim_targets() -> set[str]:
    # Env var set by `transient-trace run` takes precedence (session scope)
    env = os.environ.get("TRANSIENT_TRACE_SHIM_TARGETS", "")
    if env:
        return {s.strip().lower() for s in env.split(",") if s.strip()}
    # Fall back to installed permanent shims directory
    shims_dir = Path.home() / ".transient-trace" / "shims"
    if shims_dir.is_dir():
        return {p.name.lower() for p in shims_dir.iterdir() if p.is_file()}
    return set()


def _extract_url_from_argv(argv: list) -> Optional[str]:
    """
    Extract the first URL-looking argument from a command argv list.
    Used to populate target.host for network commands (curl, wget, etc.).
    """
    for arg in argv[1:]:  # skip binary name
        s = str(arg)
        if s.startswith(("http://", "https://", "ftp://")):
            return s
    return None


def _intercept(binary_name: str, binary_path: str, args) -> None:
    """
    Run governance check for a binary call.
    Raises SystemExit(126) if blocked, returns normally if allowed.
    """
    from transient_trace.sense_maker import classify_command

    argv = list(args) if isinstance(args, (list, tuple)) else args.split()
    result = classify_command([binary_name] + (argv[1:] if len(argv) > 1 else []))

    target: dict = {
        "binaryPath": binary_path,
        "command":    " ".join(str(a) for a in argv),
        "cwd":        os.getcwd(),
    }

    # For network commands, extract host from URL so egress PEP rules can match on it.
    if result.action_class == "network":
        url = _extract_url_from_argv(argv)
        if url:
            try:
                from urllib.parse import urlparse as _urlparse
                parsed = _urlparse(url)
                target["host"]   = parsed.netloc.lower() or parsed.path.lower()
                target["url"]    = url
                target["method"] = "GET"  # conservative default for CLI tools
                target["path"]   = parsed.path or "/"
            except Exception:
                pass

    exec_input = {
        "action":       binary_name,
        "action_class": result.action_class,
        "target":       target,
        "metadata": {
            "sense_maker_method":     result.method,
            "sense_maker_confidence": result.confidence,
            "hook":                   "popen_hook",
        },
    }

    # Pre-execution receipt — handler returns immediately (no output capture).
    # Governance signal is what matters; output belongs to the real process.
    def _noop_handler() -> dict:
        return {"hook": "pre-execution-check-only"}

    client = _get_client()
    try:
        client.executeActionWithReceipt(_noop_handler, exec_input)
    except RuntimeError as exc:
        # PEP denied the action
        print(
            f"[transient-trace] BLOCKED: {binary_name} — {exc}",
            file=sys.stderr,
        )
        sys.exit(126)


def install_hook() -> None:
    """
    Patch subprocess.Popen.__init__ to intercept governance-controlled binaries.
    Safe to call multiple times (idempotent).

    The Client is initialised EAGERLY here — before any agent code runs —
    so that the operator's policy (TRANSIENT_TRACE_POLICY_JSON) is locked in
    at import time. If the Client were created lazily on first use, a
    sophisticated agent could modify os.environ between startup and the first
    governed action and substitute its own permissive policy.
    """
    if getattr(subprocess.Popen, "_tt_hooked", False):
        return  # already installed

    # Client is initialised lazily on first interception, not here.
    # Eager init caused every Python subprocess to pay the full keypair
    # generation + session receipt write + thread startup cost at import
    # time — multiplied across all subprocesses spawned by an agent runtime
    # this caused RAM exhaustion.

    original_init = subprocess.Popen.__init__

    def _patched_init(self, args, *pargs, **kwargs):
        # Re-entrancy guard — governance layer itself uses subprocess
        if getattr(_active, "in_hook", False):
            return original_init(self, args, *pargs, **kwargs)

        # Extract binary path/name from args
        if isinstance(args, (list, tuple)) and args:
            binary_path = str(args[0])
        elif isinstance(args, str) and not kwargs.get("shell"):
            binary_path = args.split()[0] if args.strip() else ""
        else:
            # shell=True commands — don't try to parse
            return original_init(self, args, *pargs, **kwargs)

        binary_name = Path(binary_path).name.lower()

        # Only intercept binaries we're asked to watch
        if binary_name not in _shim_targets():
            return original_init(self, args, *pargs, **kwargs)

        _active.in_hook = True
        try:
            _intercept(binary_name, binary_path, args)
        except SystemExit:
            raise
        except Exception as exc:
            # Fail-open: log and allow
            _log.warning(
                "[transient-trace] popen_hook error for %s (fail-open): %s",
                binary_name, exc,
            )
        finally:
            _active.in_hook = False

        return original_init(self, args, *pargs, **kwargs)

    _patched_init.__wrapped__ = original_init
    subprocess.Popen.__init__ = _patched_init
    subprocess.Popen._tt_hooked = True
    _log.debug("[transient-trace] popen hook installed")
    install_network_hook()


def install_network_hook() -> None:
    """
    Patch urllib.request.urlopen to intercept direct network calls.

    Agents that call APIs via urllib/requests/httpx bypass subprocess.Popen
    entirely. This hook catches urllib calls (the stdlib primitive underlying
    most HTTP libraries) and applies governance to external destinations.

    Localhost calls (127.0.0.1, localhost, ::1) are passed through without
    a governance check — internal MCP/webhook traffic is not a concern.
    """
    try:
        import urllib.request as _urllib_req
    except ImportError:
        return

    if getattr(_urllib_req, "_tt_hooked", False):
        return

    _original_urlopen = _urllib_req.urlopen

    def _patched_urlopen(url, *args, **kwargs):
        if getattr(_active, "in_hook", False):
            return _original_urlopen(url, *args, **kwargs)

        # Extract URL string from Request object or plain string
        url_str = url.full_url if hasattr(url, "full_url") else str(url)

        # Pass through localhost traffic
        _local = ("localhost", "127.0.0.1", "::1", "0.0.0.0")
        if any(h in url_str for h in _local):
            return _original_urlopen(url, *args, **kwargs)

        # Govern external network call
        _active.in_hook = True
        try:
            _intercept_network(url_str, url)
        except SystemExit:
            raise
        except Exception as exc:
            _log.warning("[transient-trace] network hook error for %s (fail-open): %s", url_str, exc)
        finally:
            _active.in_hook = False

        return _original_urlopen(url, *args, **kwargs)

    _patched_urlopen.__wrapped__ = _original_urlopen
    _urllib_req.urlopen = _patched_urlopen
    _urllib_req._tt_hooked = True
    _log.debug("[transient-trace] urllib network hook installed")


def _intercept_network(url_str: str, request_obj) -> None:
    """Governance check for an outbound network call."""
    from urllib.parse import urlparse
    parsed = urlparse(url_str)
    method = getattr(request_obj, "get_method", lambda: "GET")()

    exec_input = {
        "action":       "network",
        "action_class": "network",
        "target": {
            "host":    parsed.netloc or parsed.path,
            "url":     url_str,
            "method":  method,
        },
        "metadata": {"hook": "urllib_hook"},
    }

    def _noop_handler() -> dict:
        return {"hook": "pre-network-check-only"}

    client = _get_client()
    try:
        client.executeActionWithReceipt(_noop_handler, exec_input)
    except RuntimeError as exc:
        print(f"[transient-trace] BLOCKED: network → {url_str} — {exc}", file=__import__("sys").stderr)
        __import__("sys").exit(126)
