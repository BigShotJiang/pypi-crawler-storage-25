import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .SessionReceipt import SessionReceipt
from .types import SignedSessionReceipt
from .receipt_engine.store import ReceiptStore
from .atp.id_generator import generateIntentId, generateReceiptId
from .atp.package_registry import PackageRegistry
from .atp.pep_policy_engine import PepPolicyEngine
from .receipt_engine import ReceiptEngine
from .atp.rfc3339 import rfc3339Now
from .atp.signer import signUnsignedReceipt
from .atp.snapshot import (
    computeSnapshotHash,
    createEventSnapshot,
    enrichSnapshotWithIntent,
    enrichSnapshotWithPackageMatch,
)
from .atp.validator import validateActionReceipt

_log = logging.getLogger(__name__)

# Default state directory — portable across machines.
# Override with TRANSIENT_TRACE_STATE_DIR env var or the state_dir config key.
_env_state_dir = os.environ.get("TRANSIENT_TRACE_STATE_DIR", "").strip()
DEFAULT_SWARM_STATE_DIR = Path(_env_state_dir) if _env_state_dir else Path.home() / "transient-audit"


def _write_json_append_only(path: Path, value: Dict[str, Any]) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def _resolve_state_dir(config: Optional[dict]) -> Path:
    cfg = config or {}
    raw = cfg.get("state_dir", DEFAULT_SWARM_STATE_DIR)
    return Path(raw).expanduser()


def _persist_session_receipt(receipt: SignedSessionReceipt, state_dir: Path):
    """Legacy: write session receipt to JSON file. Kept for backfill/compat only — no longer called on the hot path."""
    sessions_dir = state_dir / 'sessions'
    sessions_dir.mkdir(parents=True, exist_ok=True)
    filename = f"session-{int(time.time() * 1000)}-{receipt['environment']['sessionId']}.json"
    path = sessions_dir / filename
    if path.exists():
        return
    _write_json_append_only(path, {"type": "SignedSessionReceipt", "created_at": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'), "receipt": receipt})


def _persist_action_receipt(receipt: dict, intent: dict, decision: dict, state_dir: Path):
    """Legacy: write action receipt to JSON file. Kept for backfill/compat only — no longer called on the hot path."""
    receipts_dir = state_dir / 'receipts'
    receipts_dir.mkdir(parents=True, exist_ok=True)
    path = receipts_dir / f"{receipt['receipt_id']}.json"
    if path.exists():
        return
    _write_json_append_only(path, {"type": "SignedActionReceipt", "created_at": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'), "intent": intent, "decision": decision, "receipt": receipt})


def _persist_deny_event(receipt_id: str, intent: dict, decision: dict, state_dir: Path):
    """Legacy: write deny event to JSON file. Kept for backfill/compat only — no longer called on the hot path."""
    receipts_dir = state_dir / 'receipts'
    receipts_dir.mkdir(parents=True, exist_ok=True)
    path = receipts_dir / f"{receipt_id}.json"
    if path.exists():
        return
    _write_json_append_only(path, {
        "type": "GovernanceDenyEvent",
        "created_at": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
        "intent": intent,
        "decision": decision,
        "receipt": {
            "receipt_id": receipt_id,
            "execution_status": "blocked",
            "outcome": "deny",
            "signature": {"alg": "none", "kid": "governance-pep"},
        },
    })


def _spill(state_dir: Path, filename: str, data: dict) -> None:
    """
    Emergency fallback: write a receipt to the spill dir when the DB write fails.

    The spill dir is drained back into the DB by index_from_json_dir on next
    startup. A non-empty spill dir signals an operational problem.
    """
    try:
        spill_dir = state_dir / "receipts" / ".spill"
        spill_dir.mkdir(parents=True, exist_ok=True)
        spill_path = spill_dir / filename
        if not spill_path.exists():
            spill_path.write_text(json.dumps(data) + "\n", encoding="utf-8")
    except Exception as exc:
        _log.error(
            "[transient-trace] CRITICAL: receipt spill also failed — receipt may be lost: %s", exc
        )


def _safe_persist(op) -> None:
    try:
        op()
    except FileExistsError:
        return
    except FileNotFoundError:
        return
    except IsADirectoryError:
        return


class _TraceClientImpl:
    version = "0.1.0-phase2"

    def __init__(self, receipt: SessionReceipt, atp_engine, state_dir: Path,
                 receipt_engine: Optional[ReceiptEngine] = None,
                 store: Optional[ReceiptStore] = None):
        self._receipt = receipt
        self._atp = atp_engine
        self._state_dir = state_dir
        self._receipt_engine = receipt_engine
        self._store = store  # always-available DB store (independent of learning engine)

    @property
    def receipt(self):
        return self._receipt.getSignedReceipt()

    def getSignedReceipt(self):
        return self._receipt.getSignedReceipt()

    def rebuild(self, options: Optional[dict] = None):
        return self._receipt.rebuild(options or {})

    def _create_intent(self, exec_input: dict):
        env = self._receipt.environment
        action_class = exec_input.get("action_class", "write_low")
        action_type = str(exec_input.get("action_type", "exec")).strip().lower() or "exec"

        # action_class="network" is authoritative — the sense_maker classifies curl/wget/etc.
        # as "network" via action_class even when action_type isn't explicitly set (e.g. from
        # the popen_hook). Derive action_type from action_class so network actions always route
        # to the egress PEP and get evaluated against network rules.
        if action_class == "network" and action_type != "network":
            action_type = "network"

        # Normalise target: ATP spec requires an object (intent.schema.json "target": {"type": "object"})
        raw_target = exec_input.get("target", "")
        if isinstance(raw_target, str):
            target: dict = {"id": raw_target}
        else:
            target = dict(raw_target) if raw_target else {}

        # Merge any caller-provided metadata first — specific fields below may override.
        caller_meta = exec_input.get("metadata")
        metadata: dict = dict(caller_meta) if isinstance(caller_meta, dict) else {}

        if action_type == "network":
            metadata["action_type"] = "network"
        if "decisionToken" in exec_input:
            metadata["decisionToken"] = exec_input.get("decisionToken")
        if "tiClaimVerification" in exec_input:
            metadata["tiClaimVerification"] = exec_input.get("tiClaimVerification")

        if action_type == "network":
            target.setdefault("host", str(target.get("host", target.get("domain", ""))).strip().lower())
            target.setdefault("method", str(target.get("method", "POST")).strip().upper())
            target.setdefault("path", str(target.get("path", "/")).strip() or "/")
            target.setdefault("port", target.get("port", 443))
        elif action_class == "delete":
            target.setdefault("operation", "delete")
            metadata.update({
                "action_class": "delete",
                "paths": exec_input.get("paths", [target.get("id", "")]),
                "recursive": exec_input.get("recursive", False),
            })

        intent: dict = {
            "intent_id": generateIntentId(),
            "actor_id": env["agentId"],
            "connector": "transient-trace-sdk",
            "action": exec_input.get("action", "executeAction"),
            "action_class": action_class,
            "target": target,
            "context": {
                "sessionId": env["sessionId"],
                "runId": os.environ.get("TRANSIENT_TRACE_RUN_ID", env["runId"]),
                **({"parentRunId": os.environ.get("TRANSIENT_TRACE_PARENT_RUN_ID")}
                   if os.environ.get("TRANSIENT_TRACE_PARENT_RUN_ID") else {}),
            },
            "governance_profile": "sandbox_autonomous",
            "requested_at": rfc3339Now(),
        }
        if metadata:
            intent["metadata"] = metadata
        return intent

    def executeActionWithReceipt(self, handler, exec_input: dict):
        intent = self._create_intent(exec_input)

        # Receipt engine: inject verified governance context before decision
        if self._receipt_engine:
            inject = self._receipt_engine.inject(
                action_class=exec_input.get("action_class"),
                tool_name=exec_input.get("action") or exec_input.get("tool_name"),
                host=exec_input.get("target", {}).get("host") if isinstance(exec_input.get("target"), dict) else None,
                path=exec_input.get("target", {}).get("path") if isinstance(exec_input.get("target"), dict) else None,
            )
            if inject:
                intent.setdefault("metadata", {})["governance_context"] = inject

        decision = self._atp.requestDecision(intent)
        if decision["outcome"] == "deny":
            deny_receipt_id = generateReceiptId()

            # Build the deny receipt dict used for both DB write and engine store.
            _deny_run_id = os.environ.get("TRANSIENT_TRACE_RUN_ID", "")
            deny_receipt_for_store = {
                "receipt_id":          deny_receipt_id,
                "receipt_type":        "governance-deny-event",
                "action_class":        intent.get("action_class"),
                "tool_name":           intent.get("action"),
                "outcome":             "deny",
                "host":                intent.get("target", {}).get("host") if isinstance(intent.get("target"), dict) else None,
                "path":                intent.get("target", {}).get("path") if isinstance(intent.get("target"), dict) else None,
                "matched_rule_id":     decision.get("matched_rule_id"),
                "matched_rule_reason": decision.get("matched_rule_reason"),
                "matched_package":     decision.get("matched_package"),
                "run_id":              _deny_run_id or None,
                "ts":                  time.time(),
                "signature":           {"alg": "none", "kid": "governance-pep", "decision_id": decision.get("decision_id", "")},
            }

            # Write to DB — always, independent of the learning engine.
            if self._store:
                try:
                    self._store.write(deny_receipt_for_store)
                except Exception as exc:
                    _log.warning("[transient-trace] deny DB write failed, spilling: %s", exc)
                    _spill(self._state_dir, f"{deny_receipt_id}.json", {
                        "type": "GovernanceDenyEvent",
                        "intent": intent, "decision": decision,
                        "receipt": deny_receipt_for_store,
                    })

            # Also feed into engine learning loop if running (INSERT OR IGNORE — idempotent).
            if self._receipt_engine:
                try:
                    self._receipt_engine.store(deny_receipt_for_store)
                except Exception as exc:  # noqa: BLE001
                    _log.warning("[receipt-engine] deny store failed (non-fatal): %s", exc)
            raise RuntimeError(f"Denied: {decision['reason_code']}")

        t0 = int(time.time() * 1000)
        occurred_at = datetime.fromtimestamp(t0 / 1000, tz=timezone.utc).isoformat().replace('+00:00', 'Z')
        status = "executed"
        handler_error: Optional[Exception] = None
        output = None
        try:
            output = handler()
        except Exception as err:
            status = "error"
            handler_error = err
            output = {"error": str(err)}

        t1 = max(int(time.time() * 1000), t0 + 1)
        received_at = datetime.fromtimestamp(t1 / 1000, tz=timezone.utc).isoformat().replace('+00:00', 'Z')
        base_snap = createEventSnapshot(exec_input.get("action", "executeAction"), intent, output)
        event_snapshot = enrichSnapshotWithIntent(base_snap, intent)
        if any(
            decision.get(k) is not None
            for k in ("matched_package", "matched_rule_id", "matched_rule_reason")
        ):
            event_snapshot = enrichSnapshotWithPackageMatch(
                event_snapshot,
                {
                    "matched_package": decision.get("matched_package"),
                    "matched_rule_id": decision.get("matched_rule_id"),
                    "matched_rule_reason": decision.get("matched_rule_reason"),
                },
            )
        event_snapshot_hash = computeSnapshotHash(event_snapshot)
        t2 = max(int(time.time() * 1000), t1 + 1)
        sealed_at = datetime.fromtimestamp(t2 / 1000, tz=timezone.utc).isoformat().replace('+00:00', 'Z')
        captured_at = sealed_at
        correlation_id = f"{self._receipt.environment['sessionId']}:{intent['intent_id']}"

        unsigned = {
            "receipt_id": generateReceiptId(),
            "intent_id": intent["intent_id"],
            "decision_id": decision["decision_id"],
            "execution_status": status,
            "captured_at": captured_at,
            "schemaVersion": "1.0.0",
            "occurred_at": occurred_at,
            "received_at": received_at,
            "sealed_at": sealed_at,
            "event_snapshot": event_snapshot,
            "event_snapshot_hash": event_snapshot_hash,
            "correlation_id": correlation_id,
        }

        kid = f"{self._receipt.environment['sessionId']}:1"
        receipt = signUnsignedReceipt(unsigned, {"sign": self._receipt.keyManager.sign, "kid": kid})
        validation = validateActionReceipt(receipt)
        if not validation["valid"]:
            raise RuntimeError("Receipt validation failed: " + "; ".join(validation["errors"]))

        # Calculate governance outcome signal once — used by both _store and _receipt_engine.
        # In permissive mode the PEP overrides the execution outcome to "allow" but records
        # governance intent in reason_code ("would_be_deny_<package>").  We want the
        # governance signal in the receipt corpus so the learning loop sees what the policy
        # *would* have blocked, not just what was executed.
        _raw_outcome    = decision.get("outcome", "allow")
        _reason_code    = decision.get("reason_code", "")
        engine_outcome  = (
            "deny"
            if "would_be_deny" in _reason_code and decision.get("matched_rule_id")
            else _raw_outcome
        )
        _target         = intent.get("target") if isinstance(intent.get("target"), dict) else {}
        _action_run_id  = os.environ.get("TRANSIENT_TRACE_RUN_ID", "") or intent.get("context", {}).get("runId")
        _receipt_fields = {
            **receipt,
            "action_class":        intent.get("action_class"),
            "tool_name":           intent.get("action"),
            "outcome":             engine_outcome,
            "host":                _target.get("host"),
            "path":                _target.get("path"),
            "matched_rule_id":     decision.get("matched_rule_id"),
            "matched_rule_reason": decision.get("matched_rule_reason"),
            "matched_package":     decision.get("matched_package"),
            "run_id":              _action_run_id or None,
            # unix float timestamp — the store indexes on this for time-range queries.
            # The signed receipt uses ISO strings (captured_at etc.) which the store
            # cannot use directly.
            "ts":                  t2 / 1000,
        }

        # Write to DB — always, independent of the learning engine.
        if self._store:
            try:
                self._store.write(_receipt_fields)
            except Exception as exc:
                _log.warning("[transient-trace] receipt DB write failed, spilling: %s", exc)
                _spill(self._state_dir, f"{receipt['receipt_id']}.json", {
                    "type": "SignedActionReceipt",
                    "intent": intent, "decision": decision, "receipt": receipt,
                })

        # Receipt engine: feed signed receipt back into the learning loop.
        if self._receipt_engine:
            try:
                self._receipt_engine.store(_receipt_fields)
            except Exception as exc:  # noqa: BLE001
                _log.warning("[receipt-engine] store failed (non-fatal): %s", exc)

        if handler_error is not None:
            raise handler_error
        return {"output": output, "receipt": receipt, "intent": intent, "decision": decision}


_VALID_MODES = frozenset({"audit", "permissive", "strict"})


def _build_registry(packages: List[Union[str, dict]]) -> PackageRegistry:
    """
    Build a PackageRegistry from a packages config list.

    Each item is a str (built-in name) or a dict (inline package definition).
    Raises ValueError at init time for invalid or unknown packages.
    """
    registry = PackageRegistry()
    for item in packages:
        registry.load(item)
    return registry


def Client_init(config: Optional[dict] = None):
    cfg: Dict[str, Any] = config or {}
    pep_cfg = cfg.get("pepPolicyConfig", cfg)
    _config_policy_raw = cfg.get("pepPolicy", cfg.get("policy"))
    pep_policy = _config_policy_raw
    packages: List[Union[str, dict]] = list(cfg.get("packages") or [])
    _config_mode_raw = cfg.get("mode")
    mode: str = str(_config_mode_raw if _config_mode_raw is not None else "strict").strip().lower()

    # Operator override — when running under `transient-trace run`, the operator's
    # policy and mode are ALWAYS authoritative. An agent that configures its own
    # Client with an internal allow-all or permissive policy cannot override the
    # operator's intent. This is the trust boundary: operators set policy,
    # agents run inside it.
    _env_policy_json = os.environ.get("TRANSIENT_TRACE_POLICY_JSON", "").strip()
    _env_mode = os.environ.get("TRANSIENT_TRACE_MODE", "").strip().lower()
    # When load_shim_config() built this cfg dict, it already resolved env vars
    # against the persistent policy (blocking overrides in strict mode).
    # Skip re-applying them here so an agent cannot manipulate env vars to
    # escape the policy that load_shim_config() locked in.
    # When cfg comes directly from a constructor (transient-trace run, agent
    # SDK, tests), _env_override_resolved is absent — env vars apply normally
    # so the operator's session policy is honoured.
    if not cfg.get("_env_override_resolved"):
        if _env_policy_json:
            try:
                pep_policy = json.loads(_env_policy_json)
                _log.debug("[transient-trace] operator policy override active (env takes precedence over config)")
            except json.JSONDecodeError:
                _log.warning("[transient-trace] TRANSIENT_TRACE_POLICY_JSON is malformed — using config policy")
        if _env_mode and _env_mode in _VALID_MODES:
            mode = _env_mode

    if mode not in _VALID_MODES:
        raise ValueError(
            f"invalid governance mode '{mode}'; must be one of: "
            + ", ".join(sorted(_VALID_MODES))
        )
    state_dir = _resolve_state_dir(cfg)

    # Build and wire governance package registry if packages configured
    registry: Optional[PackageRegistry] = None
    if packages:
        registry = _build_registry(packages)
        _log.info("[transient-trace] governance: %s", registry.summary())

    # Receipt engine — self-learning loop (built first, passed into PepPolicyEngine)
    # Opt-in only. Enable via:
    #   - config: {'learning': {'enabled': True}}
    #   - CLI flag: transient-trace run --learning  (sets TRANSIENT_TRACE_LEARNING=1)
    _learning_env = os.environ.get("TRANSIENT_TRACE_LEARNING", "").strip().lower()
    receipt_engine: Optional[ReceiptEngine] = None
    learning_cfg = cfg.get("learning") or {}
    if learning_cfg.get("enabled", False) or _learning_env in ("1", "true", "yes"):
        engine_db = state_dir / "receipt_engine.db"
        # Write promotion events to the receipt store dir so `transient start`
        # picks them up in the next poll — zero extra plumbing needed.
        receipts_dir = state_dir / "receipts"
        receipt_engine = ReceiptEngine(
            db_path=engine_db,
            registry=registry,
            distill_trigger_count=learning_cfg.get("distill_trigger_count", 10),
            promote_min_confidence=learning_cfg.get("promote_min_confidence", 0.95),
            promote_min_count=learning_cfg.get("promote_min_count", 50),
            events_dir=receipts_dir,
        )
        receipt_engine.start()
        _log.info("[transient-trace] receipt engine started — db=%s", engine_db)

    atp_engine = cfg.get("atpEngine") or PepPolicyEngine(
        pep_cfg, pep_policy, registry=registry, mode=mode,
        receipt_engine=receipt_engine,
    )

    # Always-available receipt store — independent of the optional learning engine.
    # If the learning engine is also active it shares the same DB file; SQLite WAL
    # handles concurrent writers correctly.
    store = ReceiptStore(state_dir / "receipt_engine.db")

    receipt = SessionReceipt(cfg)
    signed = receipt.build(cfg)

    # Write session to DB instead of sessions/*.json
    env = signed.get("environment", {})
    sid = env.get("sessionId", "")
    kid = f"{sid}:1"
    pubkey_hex = signed.get("signingPublicKey", "")
    run_id = os.environ.get("TRANSIENT_TRACE_RUN_ID") or env.get("runId")
    parent_run_id = os.environ.get("TRANSIENT_TRACE_PARENT_RUN_ID")
    env_fingerprint = signed.get("environmentFingerprint")
    if pubkey_hex and sid:
        try:
            store.write_session(
                kid=kid,
                session_id=sid,
                pubkey_hex=pubkey_hex,
                created_at=time.time(),
                run_id=run_id,
                parent_run_id=parent_run_id,
                env_fingerprint=env_fingerprint,
            )
        except Exception as exc:
            _log.warning("[transient-trace] session DB write failed, falling back to file: %s", exc)
            _safe_persist(lambda: _persist_session_receipt(signed, state_dir))

    return _TraceClientImpl(receipt, atp_engine, state_dir, receipt_engine=receipt_engine, store=store)


def init(config: Optional[dict] = None):
    return Client_init(config)


def Client(config: Optional[dict] = None):
    return Client_init(config)
