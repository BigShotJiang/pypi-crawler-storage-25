import base64
import hashlib
import json
from typing import Any

import rfc8785


def utf8(data: str) -> bytes:
    return data.encode("utf-8")


def hex_encode(b: bytes) -> str:
    return b.hex()


def b64_encode(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def b64url_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def b64url_decode(s: str) -> bytes:
    pad = "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii"))


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonicalize_deep(obj: Any) -> Any:
    if isinstance(obj, list):
        return [canonicalize_deep(x) for x in obj]
    if isinstance(obj, dict):
        out = {}
        for k in sorted(obj.keys()):
            out[k] = canonicalize_deep(obj[k])
        return out
    return obj


def json_stringify_compact(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def rfc8785_bytes(value: Any) -> bytes:
    c = rfc8785.dumps(value)
    if isinstance(c, str):
        return c.encode("utf-8")
    return c
