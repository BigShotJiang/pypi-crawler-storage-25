"""
_config.py — Shared runtime config loader for shims and hooks.

Single source of truth for how permanent shims and the Popen hook resolve
their operating config. Priority order for every setting:

  1. TRANSIENT_TRACE_* env vars  (set by `transient-trace run` for sessions)
  2. ~/.config/transient-trace/config.json  (persistent user config)
  3. Mode-derived defaults  (strict → deny, others → allow)
  4. Built-in package auto-detection  (all available packages when none set)

Nothing is hardcoded — paths are discovered at runtime so this works on any
machine regardless of install location or Python version.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

_CONFIG_PATH = Path.home() / ".config" / "transient-trace" / "config.json"


def _read_persistent() -> dict:
    """Load persistent config. Returns {} on missing or malformed file."""
    try:
        if _CONFIG_PATH.exists():
            return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _all_builtin_packages() -> list[str]:
    """Return all available builtin package names. Empty list on import error."""
    try:
        from transient_trace.atp.builtin_packages import list_builtin_packages
        return list_builtin_packages()
    except Exception:
        return []


def load_shim_config() -> dict:
    """
    Build the Client config dict for a shim or hook invocation.

    Returns a dict ready to pass to Client().
    """
    persistent = _read_persistent()

    # ── mode ──────────────────────────────────────────────────────────────────
    # env var > persistent config > default "audit"
    mode = os.environ.get("TRANSIENT_TRACE_MODE") or persistent.get("mode", "audit")

    # ── policy ────────────────────────────────────────────────────────────────
    # TRANSIENT_TRACE_POLICY_JSON > persistent config.policy > mode-derived default
    #
    # Mode semantics:
    #   strict      → defaultAction=deny  (allowlist — commands must be permitted)
    #   audit       → defaultAction=allow (blocklist — log everything, block by rule)
    #   permissive  → defaultAction=allow (minimal receipts)
    #
    # Security note: in strict mode the persistent config takes precedence over
    # the env var override. An agent cannot weaken policy by setting
    # TRANSIENT_TRACE_POLICY_JSON when the user has locked down strict mode.
    policy_json = os.environ.get("TRANSIENT_TRACE_POLICY_JSON", "")
    if policy_json and mode != "strict":
        policy = json.loads(policy_json)
    elif "policy" in persistent:
        policy = persistent["policy"]
        # Apply mode-derived defaultAction only when not explicitly set
        if "defaultAction" not in policy:
            policy = dict(policy)
            policy["defaultAction"] = "deny" if mode == "strict" else "allow"
    else:
        default_action = "deny" if mode == "strict" else "allow"
        policy = {"version": 1, "defaultAction": default_action, "rules": []}

    # ── state_dir ─────────────────────────────────────────────────────────────
    state_dir = os.environ.get("TRANSIENT_TRACE_STATE_DIR") or persistent.get("state_dir", "")

    # ── packages ──────────────────────────────────────────────────────────────
    # env var > persistent config > all available builtin packages
    packages_env = os.environ.get("TRANSIENT_TRACE_PACKAGES", "")
    if packages_env:
        packages = [p.strip() for p in packages_env.split(",") if p.strip()]
    elif "packages" in persistent:
        raw = persistent["packages"]
        packages = [p.strip() for p in raw.split(",") if p.strip()] if isinstance(raw, str) else list(raw)
    else:
        packages = _all_builtin_packages()

    # ── assemble ──────────────────────────────────────────────────────────────
    cfg: dict = {
        "pepPolicy": policy,
        "mode":      mode,
        "learning":  {"enabled": True, "distill_trigger_count": 10},
        # Signal to Client that env vars were already resolved here.
        # Client will skip its own env var processing so agents cannot
        # manipulate TRANSIENT_TRACE_POLICY_JSON to escape strict policy.
        "_env_override_resolved": True,
    }
    if state_dir:
        cfg["state_dir"] = state_dir
    if packages:
        cfg["packages"] = packages

    return cfg
