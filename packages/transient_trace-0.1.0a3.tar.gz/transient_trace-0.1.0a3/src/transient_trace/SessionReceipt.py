import hashlib
import json
import time
from typing import Any, Dict, Optional

from .canonical import canonicalizeDeep
from .context import detectEnvironment
from .keys import KeyManager
from .types import EnvironmentContext, SessionReceiptPayload, SignedSessionReceipt


def _fingerprint_environment(env: EnvironmentContext) -> str:
    data = json.dumps({
        "sessionId": env["sessionId"],
        "runId": env["runId"],
        "framework": env["framework"],
        "runtime": env["runtime"],
        "agentId": env["agentId"],
        "sessionStartedAt": env["sessionStartedAt"],
        "sdkVersion": env["sdkVersion"],
        "containerized": env["containerized"],
    }, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


class SessionReceipt:
    sdkVersion = "0.1.0-phase1"

    def __init__(self, config: Optional[dict] = None):
        self._config: Dict[str, Any] = config or {}
        self.keyManager = KeyManager((self._config.get("keyManager") or {}))
        self.environment: EnvironmentContext = detectEnvironment(self._config.get("agentId"))
        self.payload: Optional[SessionReceiptPayload] = None
        self.signed: Optional[SignedSessionReceipt] = None
        self._built = False

    def build(self, options: Optional[dict] = None) -> SignedSessionReceipt:
        if self._built:
            if self.signed is None:
                raise RuntimeError("SessionReceipt: internal signed payload missing")
            return self.signed
        opts = options or {}
        self.keyManager.generateKey()
        signing_public_key = self.keyManager.publicKey.hex()
        environment_fingerprint = _fingerprint_environment(self.environment)

        payload: SessionReceiptPayload = {
            "version": "1.0",
            "project": "transient-suite",
            "protocol": "ATP/1.0",
            "environment": self.environment,
            "challengeState": opts.get("challengeState", ""),
            "constructedAt": int(time.time()),
            "environmentFingerprint": environment_fingerprint,
        }
        canonical = json.dumps(canonicalizeDeep(payload), separators=(",", ":"), ensure_ascii=False)
        signature = self.keyManager.sign(canonical.encode("utf-8")).hex()
        signed: SignedSessionReceipt = {**payload, "signature": signature, "signingPublicKey": signing_public_key}

        self.payload = payload
        self.signed = signed
        self._built = True
        return signed

    def rebuild(self, options: Optional[dict] = None) -> SignedSessionReceipt:
        next_sr = SessionReceipt(self._config)
        next_sr.environment = self.environment
        next_sr.keyManager.rotate()
        return next_sr.build(options or {})

    def getSignedReceipt(self) -> SignedSessionReceipt:
        if not self._built:
            raise RuntimeError("SessionReceipt: call build() before getSignedReceipt()")
        if self.signed is None:
            raise RuntimeError("SessionReceipt: internal signed payload missing")
        return self.signed

    def toJSON(self) -> SignedSessionReceipt:
        return self.getSignedReceipt()
