import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from nacl.signing import SigningKey

from .._util import b64_encode


class KeyManager:
    def __init__(self, config: Optional[dict] = None):
        cfg = config or {}
        self._ttl_ms = int(cfg.get("keyTtlSeconds", 300)) * 1000
        self._force_regen = bool(cfg.get("forceRegenerate", False))
        self._cache: Optional[Dict[str, Any]] = None

    @property
    def hasValidKey(self) -> bool:
        return self._cache is not None and int(time.time() * 1000) < self._cache["expiresAtMs"]

    @property
    def publicKey(self) -> bytes:
        if not self.hasValidKey or self._cache is None:
            raise RuntimeError("KeyManager: no valid key — call generateKey() first")
        return self._cache["keyPair"]["publicKey"]

    def generateKey(self):
        if not self._force_regen and self.hasValidKey:
            kp = self._cache["keyPair"]
            return {
                "publicKey": kp["publicKey"],
                "publicKeyB64": kp["publicKeyB64"],
                "generatedAt": kp["generatedAt"],
                "ttlSeconds": kp["ttlSeconds"],
            }
        seed = os.urandom(32)
        signing = SigningKey(seed)
        pub = bytes(signing.verify_key)
        keypair = {
            "publicKey": pub,
            "privateKey": seed,
            "publicKeyB64": b64_encode(pub),
            "generatedAt": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
            "ttlSeconds": round(self._ttl_ms / 1000),
        }
        self._cache = {"keyPair": keypair, "expiresAtMs": int(time.time() * 1000) + self._ttl_ms}
        return {k: v for k, v in keypair.items() if k != "privateKey"}

    def sign(self, message: bytes) -> bytes:
        if not self.hasValidKey:
            self.generateKey()
        if self._cache is None:
            raise RuntimeError("KeyManager: no key material available for signing")
        seed = self._cache["keyPair"]["privateKey"]
        signing = SigningKey(seed)
        sig = signing.sign(message).signature
        return bytes(sig)

    def rotate(self):
        self._cache = None
        return self.generateKey()

    def clear(self):
        self._cache = None
