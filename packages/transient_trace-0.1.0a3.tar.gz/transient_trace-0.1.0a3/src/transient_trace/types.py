from typing import Any, Dict, List, Literal, Optional, Protocol, TypedDict, Union
from typing_extensions import NotRequired

from .types_atp import Decision, Intent, Receipt

FrameworkId = Literal["claude-code", "openai-codex", "opencode", "hermes", "custom", "unknown"]
RuntimeId = Literal["node", "deno", "bun", "browser", "unknown"]


class EnvironmentContext(TypedDict):
    framework: FrameworkId
    runtime: RuntimeId
    sessionId: str
    runId: str
    agentId: str
    sessionStartedAt: str
    sdkVersion: str
    containerized: bool


class KeyPairData(TypedDict):
    publicKey: bytes
    privateKey: bytes
    publicKeyB64: str
    generatedAt: str
    ttlSeconds: int


class EphemeralKeyPair(TypedDict):
    publicKey: bytes
    publicKeyB64: str
    generatedAt: str
    ttlSeconds: int


class KeyManagerConfig(TypedDict):
    keyTtlSeconds: NotRequired[int]
    forceRegenerate: NotRequired[bool]


class SessionReceiptPayload(TypedDict):
    version: Literal["1.0"]
    project: Literal["transient-suite"]
    protocol: Literal["ATP/1.0"]
    environment: EnvironmentContext
    challengeState: NotRequired[str]
    constructedAt: int
    environmentFingerprint: str


class SignedSessionReceipt(SessionReceiptPayload):
    signature: str
    signingPublicKey: str


class ActionExecutionInput(TypedDict):
    target: Union[str, dict[str, Any]]
    action: NotRequired[str]
    action_type: NotRequired[Literal["exec", "network"]]
    action_class: NotRequired[Literal["read", "write_low", "write_high", "delete", "bulk_export"]]
    input: NotRequired[Any]


class ActionResult(TypedDict):
    output: Any
    receipt: Receipt
    intent: Intent
    decision: Decision


class ATPEngineLike(Protocol):
    def requestDecision(self, intent: Intent) -> Decision: ...


class TraceSDKConfig(TypedDict):
    agentId: NotRequired[str]
    keyManager: NotRequired[KeyManagerConfig]
    atpEngine: NotRequired[ATPEngineLike]
    policy: NotRequired[dict[str, Any]]
    pepPolicy: NotRequired[dict[str, Any]]
    pepPolicyConfig: NotRequired[dict[str, Any]]
    governanceMode: NotRequired[Literal["observe", "strict"]]
    criticalToolNames: NotRequired[list[str]]
    decisionTokenSecret: NotRequired[str]
    traceTiClaimGateEnabled: NotRequired[bool]
    traceTiFailClosedCritical: NotRequired[bool]
    packages: NotRequired[List[Union[str, Dict[str, Any]]]]
    mode: NotRequired[Literal["audit", "permissive", "strict"]]
    state_dir: NotRequired[Union[str, "Path"]]


class TraceClient(Protocol):
    @property
    def receipt(self) -> SignedSessionReceipt: ...
    def getSignedReceipt(self) -> SignedSessionReceipt: ...
    def rebuild(self, options: Optional[dict[str, str]] = None) -> SignedSessionReceipt: ...
    @property
    def version(self) -> str: ...
    def executeActionWithReceipt(self, handler, input: ActionExecutionInput) -> ActionResult: ...
