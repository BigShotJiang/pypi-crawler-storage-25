"""
package_registry.py — PackageRegistry: load, resolve, and query governance packages.

Supports:
  - load(package): load a single package dict or built-in by string name
  - load_all(packages): batch load with requires-ordering and circular dep detection
  - get_rules(profile): return rules for a given profile ('exec', 'egress', 'any')
  - list_packages(): [{name, version}, ...]
  - summary(): human-readable summary string
  - describe(name): full package definition
"""

from typing import Union

from .governance_package import validate_package, VALID_PROFILES
from .builtin_packages import get_builtin_package, list_builtin_packages


class PackageRegistry:
    def __init__(self) -> None:
        # Ordered dict preserving insertion order (Python 3.7+)
        self._packages: dict[str, dict] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self, package: Union[dict, str]) -> None:
        """
        Load a package dict or built-in by string name.

        Calls validate_package() — raises ValueError on invalid schema.
        Raises ValueError on duplicate package names.
        """
        if isinstance(package, str):
            pkg = self._resolve_builtin(package)
        elif isinstance(package, dict):
            pkg = package
        else:
            raise ValueError(
                f"package must be a dict or built-in name string, got {type(package).__name__}"
            )

        validate_package(pkg)

        name: str = pkg["name"]
        if name in self._packages:
            raise ValueError(
                f"governance package '{name}' is already loaded; duplicate package names are not allowed"
            )

        self._packages[name] = pkg

    def load_all(self, packages: list) -> None:
        """
        Batch load from a config list (mix of dicts and strings).

        Resolves requires ordering automatically.
        Detects circular requires chains — raises ValueError.
        """
        if not packages:
            return

        # Normalise all entries to dicts first so we can inspect requires
        normalised: list[dict] = []
        for item in packages:
            if isinstance(item, str):
                normalised.append(self._resolve_builtin(item))
            elif isinstance(item, dict):
                normalised.append(item)
            else:
                raise ValueError(
                    f"package list entry must be a dict or built-in name string, "
                    f"got {type(item).__name__}"
                )

        # Validate all before touching registry state
        for pkg in normalised:
            validate_package(pkg)

        # Build name -> pkg map
        pkg_map: dict[str, dict] = {pkg["name"]: pkg for pkg in normalised}

        # Check for circular requires among the batch
        self._check_circular(pkg_map)

        # Topological sort (Kahn's algorithm)
        sorted_pkgs = self._topological_sort(normalised, pkg_map)

        for pkg in sorted_pkgs:
            name = pkg["name"]
            if name not in self._packages:
                self._packages[name] = pkg

    def get_rules(self, profile: str) -> list:
        """
        Return all rules across loaded packages for the given profile.

        profile: 'exec' | 'egress' | 'any'
          - 'exec'   returns rules with profile 'exec' or 'any'
          - 'egress' returns rules with profile 'egress' or 'any'
          - 'any'    returns all rules regardless of profile
        """
        results: list[dict] = []
        for pkg in self._packages.values():
            for rule in pkg.get("rules", []):
                rule_profile = rule.get("profile", "")
                if profile == "any":
                    results.append(rule)
                elif rule_profile == profile or rule_profile == "any":
                    results.append(rule)
        return results

    def list_packages(self) -> list[dict]:
        """Return [{'name': str, 'version': str}, ...] for all loaded packages."""
        return [
            {"name": pkg["name"], "version": pkg["version"]}
            for pkg in self._packages.values()
        ]

    def summary(self) -> str:
        """Human-readable summary: 'Loaded 3 packages: messaging v1.0, filesystem v1.0, my-app v1.0'"""
        count = len(self._packages)
        if count == 0:
            return "Loaded 0 packages"
        names = ", ".join(
            f"{pkg['name']} v{pkg['version']}" for pkg in self._packages.values()
        )
        return f"Loaded {count} package{'s' if count != 1 else ''}: {names}"

    def describe(self, name: str) -> dict:
        """
        Return full package definition by name.
        Raises KeyError if not found.
        """
        if name not in self._packages:
            raise KeyError(f"governance package '{name}' not found in registry")
        return self._packages[name]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_builtin(self, name: str) -> dict:
        """
        Resolve a built-in package by string name.
        Raises ValueError if no built-in with that name exists.
        """
        builtins = _get_builtin_packages()
        if name not in builtins:
            raise ValueError(
                f"no built-in governance package named '{name}'; "
                f"available: {', '.join(sorted(builtins.keys())) or 'none'}"
            )
        return builtins[name]

    def _check_circular(self, pkg_map: dict[str, dict]) -> None:
        """
        Detect circular requires chains within pkg_map.
        Raises ValueError with descriptive path if a cycle is found.
        """
        # DFS-based cycle detection
        WHITE, GRAY, BLACK = 0, 1, 2
        color: dict[str, int] = {name: WHITE for name in pkg_map}

        def dfs(name: str, path: list[str]) -> None:
            color[name] = GRAY
            pkg = pkg_map.get(name)
            if pkg is None:
                color[name] = BLACK
                return
            for dep in pkg.get("requires", []) or []:
                if dep not in pkg_map:
                    # External dependency — not our problem to check here
                    continue
                if color[dep] == GRAY:
                    cycle = " -> ".join(path + [name, dep])
                    raise ValueError(
                        f"circular requires detected in governance packages: {cycle}"
                    )
                if color[dep] == WHITE:
                    dfs(dep, path + [name])
            color[name] = BLACK

        for name in list(pkg_map.keys()):
            if color[name] == WHITE:
                dfs(name, [])

    def _topological_sort(
        self, packages: list[dict], pkg_map: dict[str, dict]
    ) -> list[dict]:
        """
        Kahn's topological sort respecting requires ordering.
        Packages with no requires (or already-loaded requires) come first.
        """
        in_degree: dict[str, int] = {pkg["name"]: 0 for pkg in packages}
        dependents: dict[str, list[str]] = {pkg["name"]: [] for pkg in packages}

        for pkg in packages:
            name = pkg["name"]
            for dep in pkg.get("requires", []) or []:
                if dep in pkg_map:
                    in_degree[name] += 1
                    dependents[dep].append(name)

        queue: list[str] = [n for n, d in in_degree.items() if d == 0]
        result: list[dict] = []

        while queue:
            # Sort for deterministic ordering
            queue.sort()
            name = queue.pop(0)
            result.append(pkg_map[name])
            for dependent in dependents.get(name, []):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        return result


# ------------------------------------------------------------------
# Built-in package catalogue
# ------------------------------------------------------------------

def _get_builtin_packages() -> dict[str, dict]:
    """
    Return catalogue of built-in governance packages by name.
    Built-ins are defined in builtin_packages.py.
    """
    return {name: get_builtin_package(name) for name in list_builtin_packages()}
