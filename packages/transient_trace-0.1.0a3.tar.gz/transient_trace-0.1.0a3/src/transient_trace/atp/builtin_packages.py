"""
builtin_packages.py — Built-in governance packages for common developer use cases.

Six packages mapped to OWASP Agentic Security Initiative (ASI) threat categories
(Microsoft/OWASP ASI-01 through ASI-10 numbering):

  messaging   — ASI-05  Insecure Output Handling — outbound message delivery control
  filesystem  — ASI-02  Excessive Capabilities   — destructive filesystem operation safety
  web         — ASI-02  Excessive Capabilities   — outbound HTTP/network control + SSRF
  code        — ASI-04  Uncontrolled Code Exec   — git push, supply chain, package installs
  privilege   — ASI-03  Identity & Privilege Abuse — sudo, su, chmod escalation
  shell       — ASI-04  Uncontrolled Code Exec   — inline shell/interpreter execution

Usage:
    from transient_trace.atp.builtin_packages import list_builtin_packages, get_builtin_package

    names = list_builtin_packages()  # ['messaging', 'filesystem', 'web', 'code', 'privilege', 'shell']
    pkg   = get_builtin_package('privilege')

Or load directly via PackageRegistry:
    registry.load('privilege')
"""

from typing import Any


# ------------------------------------------------------------------
# Messaging package — OWASP ASI-05 (Insecure Output Handling)
# ------------------------------------------------------------------

_MESSAGING_PACKAGE: dict[str, Any] = {
    "name": "messaging",
    "version": "1.0.0",
    "description": (
        "OWASP ASI-05 (Insecure Output Handling): Controls outbound message "
        "delivery to prevent unintended external communication, bulk-send "
        "abuse, and messages to unknown or unverified recipients."
    ),
    "fail_closed": True,
    "rules": [
        {
            "id": "messaging-ext-egress-challenge",
            "profile": "egress",
            "condition": {"deliveryMode": "external"},
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-05: Outbound message with external delivery mode "
                "requires explicit operator approval before sending."
            ),
        },
        {
            "id": "messaging-bulk-egress-deny",
            "profile": "egress",
            "condition": {"deliveryMode": "bulk"},
            "outcome": "deny",
            "reason": (
                "OWASP ASI-05: Bulk message delivery is denied by default. "
                "Bulk-send patterns are a primary vector for agent-driven spam and data exfiltration."
            ),
        },
        {
            "id": "messaging-unknown-recipient-challenge",
            "profile": "egress",
            "condition": {"recipientTopology": "unknown"},
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-05: Message recipient topology is unknown. "
                "Operator must confirm the intended recipient before delivery."
            ),
        },
    ],
}


# ------------------------------------------------------------------
# Filesystem package — OWASP ASI-02 (Excessive Capabilities)
# ------------------------------------------------------------------

_FILESYSTEM_PACKAGE: dict[str, Any] = {
    "name": "filesystem",
    "version": "1.0.0",
    "description": (
        "OWASP ASI-02 (Excessive Capabilities): Prevents destructive "
        "filesystem operations outside the working directory, blocks "
        "recursive/bulk delete patterns, and challenges access to sensitive "
        "credential and config paths."
    ),
    "fail_closed": True,
    "rules": [
        # Deny rules first — they take priority over challenge rules below.
        {
            "id": "filesystem-bulk-delete-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": r"(rm\s+-[a-z]*r[a-z]*[\s$]|find\s+.*-delete|find\s+.*-exec\s+rm|rimraf\s+/|del\s+/[sS])"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-02: Command matches recursive or bulk delete pattern. "
                "Recursive/bulk filesystem deletion is denied by default."
            ),
        },
        {
            "id": "filesystem-sensitive-path-challenge",
            "profile": "exec",
            "condition": {
                # Match both tilde-form (~/.ssh/) and expanded form (/.ssh/) so the
                # rule fires regardless of whether the shell has expanded ~ already.
                "pathPattern": r"(/\.ssh/|/etc/|/\.aws/|/\.config/|/\.gnupg/)"
            },
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-02: Operation targets a sensitive path "
                "(~/.ssh/, /etc/, ~/.aws/, ~/.config/, ~/.gnupg/). "
                "Operator approval required before proceeding."
            ),
        },
        {
            "id": "filesystem-delete-outside-cwd-challenge",
            "profile": "exec",
            "condition": {"action_class": "delete", "pathPattern": "outside_cwd"},
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-02: Delete operation targets a path outside the current "
                "working directory. Operator approval required."
            ),
        },
    ],
}


# ------------------------------------------------------------------
# Web package — OWASP ASI-02 (Excessive Capabilities)
# ------------------------------------------------------------------

_WEB_PACKAGE: dict[str, Any] = {
    "name": "web",
    "version": "1.0.0",
    "description": (
        "OWASP ASI-02 (Excessive Capabilities): Governs outbound HTTP "
        "requests to prevent unintended data exfiltration via state-mutating "
        "methods to external hosts, and blocks SSRF attacks by denying "
        "requests to internal network ranges."
    ),
    "fail_closed": True,
    "rules": [
        # SSRF deny first — internal-host requests must be blocked regardless of method.
        {
            "id": "web-ssrf-internal-deny",
            "profile": "egress",
            "condition": {
                "host": r"(^10\.|^192\.168\.|^172\.(1[6-9]|2[0-9]|3[0-1])\.|^169\.254\.|^127\.|^localhost(:\d+)?$)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-02: Request targets an internal network range "
                "(10.0.0.0/8, 192.168.0.0/16, 172.16.0.0/12, 169.254.0.0/16, "
                "127.0.0.0/8, localhost). Denied to prevent SSRF attacks."
            ),
        },
        {
            "id": "web-external-mutation-challenge",
            "profile": "egress",
            "condition": {"method": "POST|PUT|PATCH", "host": "external"},
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-02: State-mutating HTTP method (POST/PUT/PATCH) targeting "
                "an external host. Operator approval required to prevent unintended "
                "data exfiltration or side effects."
            ),
        },
    ],
}


# ------------------------------------------------------------------
# Code package — OWASP ASI-04 (Uncontrolled Code Execution)
# ------------------------------------------------------------------

_CODE_PACKAGE: dict[str, Any] = {
    "name": "code",
    "version": "1.0.0",
    "description": (
        "OWASP ASI-04 (Uncontrolled Code Execution): Prevents unreviewed "
        "code and dependency changes from reaching production. Blocks "
        "unprompted git pushes to remotes, challenges unknown binary "
        "execution, and denies package manager installs without a lockfile "
        "or requirements flag."
    ),
    "fail_closed": True,
    "rules": [
        {
            "id": "code-git-push-remote-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": r"git\s+push\s+(?!.*--dry-run)(?:.*\s)?(?:origin|upstream|remote|https?://|git@)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-04: git push to a remote without explicit operator approval "
                "is denied. Prevents unreviewed code from reaching production repositories."
            ),
        },
        {
            "id": "code-unknown-binary-challenge",
            "profile": "exec",
            "condition": {
                "toolName": "bash",
                "commandPattern": r"(?<!\w)(\.\/[^\s]+|\/(?!usr\/bin|usr\/local\/bin|bin\/)[^\s]+)"
            },
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-04: bash execution targeting an unknown or non-standard binary path. "
                "Operator approval required before running unrecognised executables."
            ),
        },
        {
            "id": "code-package-install-no-lockfile-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": (
                    r"(npm\s+install(?!\s+--package-lock)|"
                    r"pip\s+install(?!\s+-r\s)(?!\s+--requirement)|"
                    r"yarn\s+add|"
                    r"pnpm\s+add|"
                    r"poetry\s+add|"
                    r"cargo\s+add(?!\s+--locked))"
                )
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-04: Package manager install command detected without a "
                "requirements file or lockfile flag. Denied to prevent supply-chain "
                "attacks via unpinned dependency installation."
            ),
        },
    ],
}


# ------------------------------------------------------------------
# Privilege package — OWASP ASI-03 (Identity & Privilege Abuse)
# ------------------------------------------------------------------

_PRIVILEGE_PACKAGE: dict[str, Any] = {
    "name": "privilege",
    "version": "1.0.0",
    "description": (
        "OWASP ASI-03 (Identity & Privilege Abuse): Blocks privilege "
        "escalation attempts — sudo/su execution, world-writable chmod, "
        "setuid/setgid bits, chown to root, and user/group management "
        "commands. Prevents an agent from acquiring elevated OS permissions."
    ),
    "fail_closed": True,
    "rules": [
        {
            "id": "privilege-sudo-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": r"^sudo(\s+|$)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-03: sudo execution is denied. Agents must not "
                "acquire elevated privileges without explicit operator consent."
            ),
        },
        {
            "id": "privilege-su-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": r"^su(\s+|$)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-03: su execution is denied. Switching to another "
                "user identity is a privilege escalation vector."
            ),
        },
        {
            "id": "privilege-chmod-escalation-deny",
            "profile": "exec",
            "condition": {
                # Matches world-writable (o+w, a+w), setuid/setgid (+s),
                # or octal modes with world-write bit (e.g. 777, 666, 757).
                "commandPattern": r"chmod\s+.*(\+s|[0-7][0-7][2367]\b|o\+w|a\+w)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-03: chmod with world-writable or setuid/setgid "
                "bits is denied. These modes create privilege escalation paths."
            ),
        },
        {
            "id": "privilege-chown-root-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": r"chown\s+(-\S+\s+)*(root|0)([\s:/]|$)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-03: chown to root is denied. Transferring file "
                "ownership to root is a privilege escalation vector."
            ),
        },
        {
            "id": "privilege-user-management-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": (
                    r"^(useradd|userdel|usermod|groupadd|groupdel|groupmod"
                    r"|visudo|passwd|chpasswd|gpasswd)(\s+|$)"
                )
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-03: User and group management commands are denied. "
                "Agents must not create, modify, or delete OS user accounts."
            ),
        },
    ],
}


# ------------------------------------------------------------------
# Shell package — OWASP ASI-04 (Uncontrolled Code Execution)
# ------------------------------------------------------------------

_SHELL_PACKAGE: dict[str, Any] = {
    "name": "shell",
    "version": "1.0.0",
    "description": (
        "OWASP ASI-04 (Uncontrolled Code Execution): Blocks inline shell "
        "interpreter execution and pipe-to-shell patterns that allow agents "
        "to run arbitrary unreviewed code. Covers curl|bash supply chain "
        "attacks, bash -c, python -c, eval, and equivalent patterns across "
        "common scripting runtimes."
    ),
    "fail_closed": True,
    "rules": [
        # Pipe-to-shell is the highest-risk pattern — deny unconditionally.
        {
            "id": "shell-pipe-to-interpreter-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": (
                    r"(curl|wget|fetch|cat|echo)\s+.*"
                    r"\|\s*(ba?sh|dash|zsh|fish|ksh|csh|tcsh|ash|sh)\b"
                )
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-04: Command pipes network or dynamic content "
                "directly to a shell interpreter (e.g. curl | bash). "
                "This is a primary supply-chain attack vector and is denied."
            ),
        },
        # eval/exec with dynamic input — also deny.
        {
            "id": "shell-eval-deny",
            "profile": "exec",
            "condition": {
                "commandPattern": r"(^|\s)(eval|exec)\s+([\"\']|\$\(|`|\$\{)"
            },
            "outcome": "deny",
            "reason": (
                "OWASP ASI-04: eval or exec with dynamic/substituted input "
                "is denied. These constructs execute arbitrary code at runtime "
                "without static review."
            ),
        },
        # Inline shell execution — challenge (operator may have legitimate use).
        {
            "id": "shell-inline-shell-challenge",
            "profile": "exec",
            "condition": {
                "commandPattern": r"^(ba?sh|sh|zsh|ksh|csh|dash)\s+(-c|-s)\s+"
            },
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-04: Inline shell execution (bash -c / sh -c) "
                "requires operator approval. Inline scripts bypass static "
                "code review."
            ),
        },
        # Inline interpreter execution — challenge.
        {
            "id": "shell-inline-interpreter-challenge",
            "profile": "exec",
            "condition": {
                "commandPattern": (
                    r"^(python[23]?|node|perl|ruby|php|lua|Rscript|deno)"
                    r"\s+(-[cer])\s+"
                )
            },
            "outcome": "challenge",
            "reason": (
                "OWASP ASI-04: Inline interpreter execution "
                "(python -c / node -e / perl -e etc.) requires operator "
                "approval. Inline code bypasses file-level review."
            ),
        },
    ],
}


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------

_BUILTIN_CATALOGUE: dict[str, dict] = {
    "messaging":  _MESSAGING_PACKAGE,
    "filesystem": _FILESYSTEM_PACKAGE,
    "web":        _WEB_PACKAGE,
    "code":       _CODE_PACKAGE,
    "privilege":  _PRIVILEGE_PACKAGE,
    "shell":      _SHELL_PACKAGE,
}


def list_builtin_packages() -> list[str]:
    """Return the names of all available built-in governance packages."""
    return list(_BUILTIN_CATALOGUE.keys())


def get_builtin_package(name: str) -> dict:
    """
    Return the full package definition for a built-in package by name.

    Raises ValueError if no built-in with that name exists.
    """
    if name not in _BUILTIN_CATALOGUE:
        raise ValueError(
            f"no built-in governance package named '{name}'; "
            f"available: {', '.join(sorted(_BUILTIN_CATALOGUE.keys()))}"
        )
    return _BUILTIN_CATALOGUE[name]
