import re
from typing import Optional

GOVERNED_TOOL_PROFILES = {
    "message_send": {"policyPackage": "messaging", "governedAction": "message.send", "deliveryMode": "send", "requiredDimensions": ["recipientTopology", "messageClass"]},
    "message.send": {"policyPackage": "messaging", "governedAction": "message.send", "deliveryMode": "send", "requiredDimensions": ["recipientTopology", "messageClass"]},
    "message_draft": {"policyPackage": "messaging", "governedAction": "message.draft", "deliveryMode": "draft", "requiredDimensions": []},
    "message.draft": {"policyPackage": "messaging", "governedAction": "message.draft", "deliveryMode": "draft", "requiredDimensions": []},
}
GOVERNED_ACTION_PROFILES = {
    "messaging:message.send": {"policyPackage": "messaging", "governedAction": "message.send", "deliveryMode": "send", "requiredDimensions": ["recipientTopology", "messageClass"]},
    "messaging:message.draft": {"policyPackage": "messaging", "governedAction": "message.draft", "deliveryMode": "draft", "requiredDimensions": []},
}
CONTROL_PLANE_PACKAGES = {"governance", "policy", "control-plane", "control_plane"}
CONTROL_PLANE_MUTATION_PATTERN = re.compile(r"(governance|policy|guardrail|pep|decision[-_.]?token|critical[-_.]?tool|autonomy[-_.]?mode).*(set|update|patch|delete|create|write|mutate|override|disable|enable|bypass)|^(set|update|patch|delete|create|write|mutate|override|disable|enable|bypass).*(governance|policy|guardrail|pep|decision[-_.]?token|critical[-_.]?tool|autonomy[-_.]?mode)")


def normalizeGovernanceFromToolArgs(args: Optional[dict] = None, options: Optional[dict] = None) -> dict:
    a = args if isinstance(args, dict) else {}
    governance_value = a.get("governance")
    g = governance_value if isinstance(governance_value, dict) else {}
    base = {
        "policyPackage": str(g.get("package", "")).strip().lower(),
        "governedAction": str(g.get("action", g.get("governedAction", ""))).strip().lower(),
        "deliveryMode": str(g.get("deliveryMode", "")).strip().lower(),
        "recipientTopology": str(g.get("recipientTopology", "")).strip().lower(),
        "messageClass": str(g.get("messageClass", "")).strip().lower(),
    }
    control = (base["policyPackage"] in CONTROL_PLANE_PACKAGES) or bool(CONTROL_PLANE_MUTATION_PATTERN.search(base["governedAction"]))
    tool_name = str((options or {}).get("toolName", "")).strip().lower()
    profile = GOVERNED_TOOL_PROFILES.get(tool_name) or GOVERNED_ACTION_PROFILES.get(f"{base['policyPackage']}:{base['governedAction']}")
    if not profile:
        return {**base, "isGovernedTool": False, "governedToolName": "", "missingRequiredDimensions": [], "mismatchedCanonicalFields": [], "controlPlaneMutationAttempt": control}

    mismatched = []
    if base["policyPackage"] and base["policyPackage"] != profile["policyPackage"]: mismatched.append("policyPackage")
    if base["governedAction"] and base["governedAction"] != profile["governedAction"]: mismatched.append("governedAction")
    if base["deliveryMode"] and base["deliveryMode"] != profile["deliveryMode"]: mismatched.append("deliveryMode")
    normalized = {**base, "policyPackage": profile["policyPackage"], "governedAction": profile["governedAction"], "deliveryMode": profile["deliveryMode"]}
    missing = [k for k in profile["requiredDimensions"] if not str(normalized.get(k, "")).strip()]
    return {**normalized, "isGovernedTool": True, "governedToolName": tool_name or f"{profile['policyPackage']}:{profile['governedAction']}", "missingRequiredDimensions": missing, "mismatchedCanonicalFields": mismatched, "controlPlaneMutationAttempt": control}
