import json
from pathlib import Path
from typing import Optional

from .pep_policy_contract import PepPolicySchemaVersion, validatePepPolicyShape


def buildDefaultPepPolicy() -> dict:
    return {
        "version": PepPolicySchemaVersion,
        "defaultAction": "deny",
        "rules": [
            {"id": "allow-local-loopback", "kind": "egress", "action": "allow", "hosts": ["127.0.0.1", "localhost"], "ports": [80, 443, 3030, 3031, 3032, 3040, 8080, 8090]},
            {"id": "allow-localhost-domain", "kind": "egress", "action": "allow", "hosts": ["*.local", "*.lan"], "ports": [80, 443, 3030, 3031, 3032, 3040]},
            {"id": "challenge-critical-exec", "kind": "exec", "action": "challenge", "riskTiers": ["critical"]},
        ],
    }


def loadPepPolicy(input: Optional[dict] = None) -> dict:
    data = input or {}
    fallback = data.get("fallbackPolicy") or buildDefaultPepPolicy()
    p = str(data.get("path", "")).strip()
    if not p:
        return fallback
    try:
        parsed = json.loads(Path(p).read_text())
        check = validatePepPolicyShape(parsed)
        return parsed if check["ok"] else fallback
    except Exception:
        return fallback