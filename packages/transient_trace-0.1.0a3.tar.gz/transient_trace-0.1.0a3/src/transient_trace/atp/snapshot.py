import hashlib
from typing import Any

from .canonicalization import canonicalizeForHashing


def _digest_hex(payload: Any) -> str:
    return hashlib.sha256(canonicalizeForHashing(payload)).hexdigest()


def hashPayload(payload: Any) -> str:
    return _digest_hex(payload)


def createEventSnapshot(action: str, input: Any, output: Any) -> dict:
    return {
        "action": action,
        "input_digest": hashPayload(input if input is not None else None),
        "output_digest": hashPayload(output if output is not None else None),
    }


def enrichSnapshotWithIntent(snapshot: dict, intent: dict) -> dict:
    return {
        **snapshot,
        "intent_id": intent["intent_id"],
        "action_class": intent["action_class"],
        "target": intent["target"],
    }


def enrichSnapshotWithPackageMatch(snapshot: dict, package_match: dict) -> dict:
    """Bind a governance package rule match to a receipt snapshot.

    When a package rule fires, the receipt records which package and rule
    produced the governance decision — making it independently auditable.

    package_match: {matched_package, matched_rule_id, matched_rule_reason}
    """
    if not package_match:
        return snapshot
    return {
        **snapshot,
        "matched_package":     package_match.get("matched_package"),
        "matched_rule_id":     package_match.get("matched_rule_id"),
        "matched_rule_reason": package_match.get("matched_rule_reason"),
    }


def computeSnapshotHash(snapshot: dict) -> str:
    return _digest_hex(snapshot)
