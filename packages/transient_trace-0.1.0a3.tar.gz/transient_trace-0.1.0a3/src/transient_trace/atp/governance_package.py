"""
governance_package.py — Governance package schema definition and validation.

A governance package is a named, versioned bundle of policy rules that a
developer drops into their Client config to govern agent actions.

Schema:
{
  'name': str,          # required — unique identifier
  'version': str,       # required — semver string e.g. '1.0.0'
  'description': str,   # optional
  'rules': [
    {
      'id': str,              # optional — for logging/receipts
      'profile': str,         # required — 'exec' | 'egress' | 'any'
      'condition': dict,      # required — fields to match against action intent
      'outcome': str,         # required — 'allow' | 'deny' | 'challenge'
      'reason': str           # required — human-readable, appears in receipt
    }
  ],
  'fail_closed': bool,  # optional, default True
  'requires': list[str] # optional — other package names that must be loaded first
}

Supported condition fields (matched against action intent):
  action_class, kind, profile, toolName, host, method, deliveryMode,
  recipientTopology, pathPattern, commandPattern
"""

from typing import Any

VALID_PROFILES = frozenset({"exec", "egress", "any"})
VALID_OUTCOMES = frozenset({"allow", "deny", "challenge"})
SUPPORTED_CONDITION_FIELDS = frozenset({
    "action_class",
    "kind",
    "profile",
    "toolName",
    "host",
    "method",
    "deliveryMode",
    "recipientTopology",
    "pathPattern",
    "commandPattern",
})


def validate_package(pkg: Any) -> None:
    """
    Validate a governance package dict against the schema.

    Raises ValueError with a descriptive message if the schema is invalid.
    Called at load time — fail fast at init, not at evaluation.
    """
    if not isinstance(pkg, dict):
        raise ValueError(
            f"governance package must be a dict, got {type(pkg).__name__}"
        )

    # Required top-level fields
    name = pkg.get("name")
    if not name or not isinstance(name, str) or not name.strip():
        raise ValueError(
            "governance package missing required field 'name' (non-empty string)"
        )

    version = pkg.get("version")
    if not version or not isinstance(version, str) or not version.strip():
        raise ValueError(
            f"governance package '{name}' missing required field 'version' (non-empty string)"
        )

    if "rules" not in pkg:
        raise ValueError(
            f"governance package '{name}' missing required field 'rules'"
        )

    rules = pkg["rules"]
    if not isinstance(rules, list):
        raise ValueError(
            f"governance package '{name}': 'rules' must be a list, got {type(rules).__name__}"
        )

    for i, rule in enumerate(rules):
        rule_label = f"package '{name}' rule[{i}]"
        if not isinstance(rule, dict):
            raise ValueError(
                f"{rule_label} must be a dict, got {type(rule).__name__}"
            )

        profile = rule.get("profile")
        if not profile or not isinstance(profile, str):
            raise ValueError(
                f"{rule_label} missing required field 'profile'"
            )
        if profile not in VALID_PROFILES:
            raise ValueError(
                f"{rule_label} has invalid 'profile' value '{profile}'; "
                f"must be one of: {', '.join(sorted(VALID_PROFILES))}"
            )

        if "condition" not in rule:
            raise ValueError(
                f"{rule_label} missing required field 'condition'"
            )
        condition = rule["condition"]
        if not isinstance(condition, dict):
            raise ValueError(
                f"{rule_label} 'condition' must be a dict, got {type(condition).__name__}"
            )

        outcome = rule.get("outcome")
        if not outcome or not isinstance(outcome, str):
            raise ValueError(
                f"{rule_label} missing required field 'outcome'"
            )
        if outcome not in VALID_OUTCOMES:
            raise ValueError(
                f"{rule_label} has invalid 'outcome' value '{outcome}'; "
                f"must be one of: {', '.join(sorted(VALID_OUTCOMES))}"
            )

        reason = rule.get("reason")
        if not reason or not isinstance(reason, str) or not reason.strip():
            raise ValueError(
                f"{rule_label} missing required field 'reason' (non-empty string)"
            )

    # Optional fail_closed — must be bool if present
    if "fail_closed" in pkg and not isinstance(pkg["fail_closed"], bool):
        raise ValueError(
            f"governance package '{name}': 'fail_closed' must be a bool, "
            f"got {type(pkg['fail_closed']).__name__}"
        )

    # Optional requires — must be list of strings if present
    if "requires" in pkg:
        requires = pkg["requires"]
        if not isinstance(requires, list):
            raise ValueError(
                f"governance package '{name}': 'requires' must be a list, "
                f"got {type(requires).__name__}"
            )
        for j, req in enumerate(requires):
            if not isinstance(req, str) or not req.strip():
                raise ValueError(
                    f"governance package '{name}': 'requires[{j}]' must be a non-empty string"
                )
