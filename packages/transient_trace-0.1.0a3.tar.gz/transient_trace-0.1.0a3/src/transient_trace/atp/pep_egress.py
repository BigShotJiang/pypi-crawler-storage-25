from .approval_queue import createApprovalQueue
from .decision_token_engine import DecisionTokenScopes, createDecisionTokenEngine
from .governed_action_normalize import normalizeGovernanceFromToolArgs
from .package_rule_evaluator import evaluate_package_rules
from .policy_evaluator import evaluatePolicy
from typing import Optional

EgressPepDecision = {"ALLOW": "allow", "DENY": "deny", "APPROVAL_REQUIRED": "approval_required"}


def createEgressPep(options: Optional[dict] = None):
    opts = options or {}
    config = opts.get("config", {})
    policy = opts.get("policy")
    # package_rules_with_meta: list of {rule, package, fail_closed} dicts
    # Pre-built by pep_policy_engine via build_package_rules_with_meta(registry)
    # filtered to egress-applicable rules (profile == 'egress' or 'any')
    package_rules_with_meta: list = opts.get("package_rules_with_meta") or []
    approval_queue = opts.get("approvalQueue") or createApprovalQueue()
    emit_event = opts.get("emitEvent", lambda event: None)
    now = opts.get("now", lambda: __import__('time').time() * 1000)

    strict_mode = str(config.get("governanceMode", "observe")) == "strict"
    token_secret = str(config.get("decisionTokenSecret", "")).strip()
    token_engine = createDecisionTokenEngine({"secret": token_secret, "now": now}) if token_secret else None

    def emit(name, request, payload=None):
        p = payload or {}
        emit_event({
            "runId": request.get("runId"), "sessionId": request.get("sessionId"), "eventType": name,
            "toolName": request.get("toolName"), "outcome": p.get("outcome", "success"),
            "detail": p.get("detail"), "meta": p.get("meta", {}),
        })

    def verify_decision_token(request):
        if not strict_mode:
            return {"ok": True, "code": "observe_mode"}
        if not (isinstance(config.get("criticalToolNames"), list) and request["toolName"] in config.get("criticalToolNames")):
            return {"ok": True, "code": "non_critical_tool"}
        if not token_engine:
            return {"ok": False, "code": "missing_decision_token_secret"}
        token = str(request.get("decisionToken", "")).strip()
        if not token:
            return {"ok": False, "code": "token_missing"}
        scoped = token_engine["verifyToken"](token, {"scope": DecisionTokenScopes.get("EGRESS_REQUEST", DecisionTokenScopes["CRITICAL_TOOL_EXECUTE"]), "runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"]})
        if scoped.get("ok") or scoped.get("code") != "token_scope_mismatch":
            return scoped
        return token_engine["verifyToken"](token, {"scope": DecisionTokenScopes["CRITICAL_TOOL_EXECUTE"], "runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"]})

    def evaluate(request_input=None):
        ri = request_input or {}
        request = {
            "runId": str(ri.get("runId", "")).strip() or f"pep-egress-{int(now())}",
            "sessionId": str(ri.get("sessionId", "")).strip() or "pep-egress-session",
            "toolName": str(ri.get("toolName", "")).strip() or "unknown",
            "binaryPath": str(ri.get("binaryPath", "")).strip() or "unknown",
            "riskTier": str(ri.get("riskTier", "")).strip().lower() or "read",
            "method": str(ri.get("method", "POST")).strip().upper(),
            "host": str(ri.get("host", "")).strip().lower(),
            "port": (lambda v: int(v) if str(v).isdigit() else 443)(ri.get("port", 443)),
            "path": str(ri.get("path", "/")).strip() or "/",
            "decisionToken": str(ri.get("decisionToken", "")).strip(),
        }
        ti_claim = ri.get("tiClaimVerification", {}) if isinstance(ri.get("tiClaimVerification", {}), dict) else {}
        ti_state = str(ti_claim.get("state", "")).strip().lower()
        if ti_state not in {"supported", "contradicted", "unresolved"}:
            ti_state = ""
        unresolved_reasons = [str(x) for x in ti_claim.get("unresolved_reasons", [])] if isinstance(ti_claim.get("unresolved_reasons", []), list) else []

        # --- Package rule evaluation (runs before base policy) ---
        _pkg_ctx = {
            "host":               request["host"],
            "method":             request["method"],
            "path":               request["path"],
            "toolName":           request["toolName"],
            "riskTier":           request["riskTier"],
            # Messaging / delivery fields — required for messaging package rules
            "deliveryMode":       str(ri.get("deliveryMode", "")).strip().lower(),
            "recipientTopology":  str(ri.get("recipientTopology", "")).strip().lower(),
            "messageClass":       str(ri.get("messageClass", "")).strip().lower(),
        }
        egress_pkg_rules = [
            e for e in package_rules_with_meta
            if e["rule"].get("profile") in ("egress", "any")
        ]
        pkg_match = evaluate_package_rules(egress_pkg_rules, _pkg_ctx)
        # --- End package rule evaluation ---

        gov = normalizeGovernanceFromToolArgs(ri.get("toolArgs") if isinstance(ri.get("toolArgs"), dict) else {"governance": ri.get("governance")}, {"toolName": request["toolName"]})

        if gov.get("controlPlaneMutationAttempt"):
            governance_reason = "governance_control_plane_mutation_blocked"
        elif len(gov.get("mismatchedCanonicalFields", [])) > 0:
            governance_reason = "governance_metadata_mismatch"
        elif gov.get("isGovernedTool") and len(gov.get("missingRequiredDimensions", [])) > 0:
            governance_reason = "governance_metadata_missing"
        else:
            governance_reason = ""

        if governance_reason:
            emit("egress_request_blocked", request, {"outcome": "error", "detail": governance_reason, "meta": {"policyPackage": gov.get("policyPackage"), "governedAction": gov.get("governedAction"), "missingDimensions": gov.get("missingRequiredDimensions"), "mismatchedCanonicalFields": gov.get("mismatchedCanonicalFields")}})
            return {"ok": False, "decision": EgressPepDecision["DENY"], "reason": governance_reason, "policy": {"action": "deny", "matchedRuleId": None, "reason": governance_reason}}

        policy_decision = evaluatePolicy(policy, {
            "kind": "egress", "toolName": request["toolName"], "binaryPath": request["binaryPath"], "riskTier": request["riskTier"],
            "action_class": str(ri.get("action_class", "")).strip().lower(),
            "host": request["host"], "port": request["port"], "method": request["method"], "tiClaimState": ti_state,
            "path": request["path"], "policyPackage": gov.get("policyPackage"), "governedAction": gov.get("governedAction"),
            "deliveryMode": gov.get("deliveryMode"), "recipientTopology": gov.get("recipientTopology"), "messageClass": gov.get("messageClass"),
        })

        token_check = verify_decision_token(request)
        if not token_check.get("ok"):
            emit("egress_request_blocked", request, {"outcome": "error", "detail": f"token_invalid:{token_check.get('code')}"})
            return {"ok": False, "decision": EgressPepDecision["DENY"], "reason": f"token_invalid:{token_check.get('code')}", "policy": policy_decision}

        if config.get("traceTiClaimGateEnabled") and request["riskTier"] == "critical":
            if not ti_state and config.get("traceTiFailClosedCritical", True):
                emit("egress_request_blocked", request, {"outcome": "error", "detail": "ti_claim_missing", "meta": {"ti_claim_state": "missing"}})
                return {"ok": False, "decision": EgressPepDecision["DENY"], "reason": "ti_claim_missing", "policy": policy_decision}
            if ti_state == "contradicted":
                emit("egress_request_blocked", request, {"outcome": "error", "detail": "ti_claim_contradicted", "meta": {"ti_claim_state": ti_state}})
                return {"ok": False, "decision": EgressPepDecision["DENY"], "reason": "ti_claim_contradicted", "policy": policy_decision}
            if ti_state == "unresolved":
                approval = approval_queue["enqueue"]({"runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"], "args": {"host": request["host"], "method": request["method"], "path": request["path"], "port": request["port"], "ti_claim_state": ti_state, "ti_unresolved_reasons": unresolved_reasons}})
                emit("egress_request_challenged", request, {"outcome": "error", "detail": f"ti_claim_unresolved:{approval['id']}", "meta": {"approvalQueueId": approval["id"], "ti_claim_state": ti_state}})
                return {"ok": False, "decision": EgressPepDecision["APPROVAL_REQUIRED"], "reason": "ti_claim_unresolved", "approvalQueueId": approval["id"], "policy": policy_decision}

        # Package rule match takes precedence over base policy (but not governance metadata blocks)
        if pkg_match is not None:
            pkg_outcome = pkg_match["outcome"]
            pkg_meta = {
                "matched_package":    pkg_match["matched_package"],
                "matched_rule_id":    pkg_match["matched_rule_id"],
                "matched_rule_reason": pkg_match["matched_rule_reason"],
            }
            if pkg_outcome == "deny":
                emit("egress_request_blocked", request, {"outcome": "error", "detail": pkg_match["matched_rule_reason"], "meta": pkg_meta})
                return {"ok": False, "decision": EgressPepDecision["DENY"], "reason": pkg_match["matched_rule_reason"], "policy": policy_decision, "package_match": pkg_meta}
            if pkg_outcome == "challenge":
                approval = approval_queue["enqueue"]({"runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"], "args": {"host": request["host"], "method": request["method"], "path": request["path"], "port": request["port"]}})
                emit("egress_request_challenged", request, {"outcome": "error", "detail": f"package_challenge:{approval['id']}", "meta": {**pkg_meta, "approvalQueueId": approval["id"]}})
                return {"ok": False, "decision": EgressPepDecision["APPROVAL_REQUIRED"], "reason": "package_challenge", "approvalQueueId": approval["id"], "policy": policy_decision, "package_match": pkg_meta}
            if pkg_outcome == "allow":
                emit("egress_request_allowed", request, {"detail": f"package_allow:{pkg_match['matched_rule_id']}", "meta": pkg_meta})
                return {"ok": True, "decision": EgressPepDecision["ALLOW"], "reason": f"package_allow:{pkg_match['matched_rule_id']}", "policy": policy_decision, "package_match": pkg_meta}

        if policy_decision.get("action") == "allow":
            emit("egress_request_allowed", request, {"detail": policy_decision.get("reason")})
            return {"ok": True, "decision": EgressPepDecision["ALLOW"], "reason": policy_decision.get("reason"), "policy": policy_decision}

        if policy_decision.get("action") == "challenge":
            approval = approval_queue["enqueue"]({"runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"], "args": {"host": request["host"], "method": request["method"], "path": request["path"], "port": request["port"]}})
            emit("egress_request_challenged", request, {"outcome": "error", "detail": f"approval_required:{approval['id']}", "meta": {"approvalQueueId": approval["id"]}})
            return {"ok": False, "decision": EgressPepDecision["APPROVAL_REQUIRED"], "reason": "approval_required", "approvalQueueId": approval["id"], "policy": policy_decision}

        emit("egress_request_blocked", request, {"outcome": "error", "detail": policy_decision.get("reason")})
        return {"ok": False, "decision": EgressPepDecision["DENY"], "reason": policy_decision.get("reason"), "policy": policy_decision}

    return {"evaluate": evaluate, "approvalQueue": approval_queue}
