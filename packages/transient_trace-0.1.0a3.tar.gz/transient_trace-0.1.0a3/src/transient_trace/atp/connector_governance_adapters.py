import re
from typing import Optional


def extract_domains_from_text(value: str) -> list[str]:
    return [m.group(1).lower() for m in re.finditer(r"[A-Z0-9._%+-]+@([A-Z0-9.-]+\.[A-Z]{2,})", value or "", flags=re.I)]


def inferMessagingRecipientTopology(commandInput: str, options: Optional[dict] = None):
    cmd = f"{commandInput or ''}\n{(options or {}).get('stdinHint', '')}"
    domains = extract_domains_from_text(cmd)
    if not domains:
        return ''
    kinds = {"internal" if d == "transientintelligence.com" else "external" for d in domains}
    if len(kinds) > 1:
        return "mixed"
    return "internal" if "internal" in kinds else "external"


def summarizeConnectorCommand(commandInput: str):
    normalized = re.sub(r"\s+", " ", commandInput or "").strip()
    if not normalized:
        return "tool_request"
    if re.search(r"\bhimalaya\b", normalized, re.I) and re.search(r"\btemplate\s+save\b", normalized, re.I):
        return "himalaya template save"
    if re.search(r"\bhimalaya\b", normalized, re.I) and re.search(r"\btemplate\s+send\b", normalized, re.I):
        return "himalaya template send"
    if re.search(r"\b(sendmail|msmtp)\b", normalized, re.I):
        return "sendmail send"
    return normalized if len(normalized) <= 120 else normalized[:117] + "..."


def isLikelyMessagingExecCommand(inp: Optional[dict] = None):
    d = inp or {}
    cmd = str(d.get("command", "")).strip()
    tool = str(d.get("toolName", "")).strip()
    if not cmd and not tool:
        return False
    has_header_shape = bool(re.search(r"\b(to|cc|bcc|subject):", cmd, re.I))
    has_messaging_noun = bool(re.search(r"(mail|email|message|smtp|gmail|outlook|himalaya|imap)", cmd, re.I))
    has_messaging_verb = bool(re.search(r"\b(send|draft|compose|reply|forward)\b|\btemplate\s+send\b|\btemplate\s+save\b|\bmessage\s+write\b", cmd, re.I))
    tool_looks_messaging = bool(re.search(r"\b(mail|email|message|smtp)\b", tool, re.I))
    return has_header_shape or (has_messaging_noun and has_messaging_verb) or tool_looks_messaging


def inferGovernedHistoryToolCall(inp: Optional[dict] = None):
    d = inp or {}
    raw_tool_name = str(d.get("rawToolName", ""))
    raw_args = d.get("rawArgs", {}) if isinstance(d.get("rawArgs", {}), dict) else {}
    command = str(d.get("command", "")).strip()
    if not isLikelyMessagingExecCommand({"command": command, "toolName": raw_tool_name.strip().lower()}):
        return None
    delivery_mode = "draft" if re.search(r"\bdraft\b", command, re.I) else "send"
    recipient_topology = inferMessagingRecipientTopology(command) or "external" if delivery_mode == "send" else ""
    return {
        "toolName": "message_send",
        "rawToolName": raw_tool_name or "exec",
        "args": {
            **raw_args,
            "governance": {
                "package": "messaging",
                "action": "message.draft" if delivery_mode == "draft" else "message.send",
                "deliveryMode": delivery_mode,
                **({"recipientTopology": recipient_topology} if recipient_topology else {}),
                "messageClass": "human",
            },
        },
        "command": command,
        "detail": summarizeConnectorCommand(command),
    }
