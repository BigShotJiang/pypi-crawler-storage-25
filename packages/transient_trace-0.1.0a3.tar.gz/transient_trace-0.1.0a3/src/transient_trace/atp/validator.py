import re

from nacl.signing import VerifyKey
from nacl.exceptions import BadSignatureError

from .._util import b64url_decode
from .canonicalization import canonicalizeForSigning
from .rfc3339 import parseRfc3339Ms
from .snapshot import computeSnapshotHash

_ID = re.compile(r"^(TI|TD|TR)-[0-9A-HJKMNP-TV-Z]{26}$")


def validateActionReceipt(receipt: dict) -> dict:
    errors: list[str] = []

    def push(cond: bool, msg: str):
        if not cond:
            errors.append(msg)

    push(bool(_ID.match(receipt.get("receipt_id", ""))), "receipt_id must match TR-<ULID>")
    push(bool(_ID.match(receipt.get("intent_id", ""))), "intent_id must match TI-<ULID>")
    push(bool(_ID.match(receipt.get("decision_id", ""))), "decision_id must match TD-<ULID>")

    push(receipt.get("execution_status") in ["executed", "blocked", "expired", "error"], "execution_status invalid")
    push(receipt.get("schemaVersion") == "1.0.0", "schemaVersion must be 1.0.0")
    push(len(str(receipt.get("correlation_id", ""))) > 0, "correlation_id must be non-empty")

    for field in ["occurred_at", "received_at", "sealed_at", "captured_at"]:
        try:
            parseRfc3339Ms(receipt[field])
        except Exception:
            errors.append(f"{field} must be valid RFC3339")

    try:
        o = parseRfc3339Ms(receipt["occurred_at"])
        r = parseRfc3339Ms(receipt["received_at"])
        s = parseRfc3339Ms(receipt["sealed_at"])
        push(o <= r <= s, "timestamp invariant failed: occurred_at <= received_at <= sealed_at")
    except Exception:
        pass

    snap = receipt.get("event_snapshot")
    push(isinstance(snap, dict), "event_snapshot must be object")
    h = receipt.get("event_snapshot_hash", "")
    push(isinstance(h, str) and bool(re.match(r"^[a-f0-9]{64}$", h)), "event_snapshot_hash must be 64-char hex string (SHA-256)")
    if isinstance(snap, dict):
        push(computeSnapshotHash(snap) == h, "event_snapshot_hash mismatch (forged or corrupted)")

    sig = receipt.get("signature", {})
    push(sig.get("alg") == "Ed25519", "signature.alg must be Ed25519")
    push(sig.get("canonicalization") == "RFC8785-JCS", "signature.canonicalization must be RFC8785-JCS")
    push(isinstance(sig.get("kid"), str) and len(sig.get("kid")) > 0, "signature.kid required")
    push(isinstance(sig.get("sig"), str) and len(sig.get("sig")) > 0, "signature.sig required")
    try:
        raw = b64url_decode(sig.get("sig", ""))
        push(len(raw) == 64, "signature.sig must decode to 64-byte Ed25519 signature")
    except Exception:
        errors.append("signature.sig must be valid base64url")

    return {"valid": len(errors) == 0, "errors": errors}


def verifyActionReceipt(receipt: dict, publicKey: bytes) -> bool:
    try:
        unsigned = {k: v for k, v in receipt.items() if k != "signature"}
        msg = canonicalizeForSigning(unsigned)
        sig = b64url_decode(receipt["signature"]["sig"])
        VerifyKey(publicKey).verify(msg, sig)
        return True
    except (BadSignatureError, Exception):
        return False
