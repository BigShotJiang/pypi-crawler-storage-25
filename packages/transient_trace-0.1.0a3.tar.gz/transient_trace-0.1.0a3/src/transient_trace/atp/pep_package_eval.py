"""
pep_package_eval.py — Package rule condition evaluation for PEP enforcement engines.

Package rules use a 'condition' dict (governance_package.py schema) which differs
from the policy_evaluator rule shape.  This module bridges between them.

Condition fields supported:
    action_class      — exact string match (e.g. 'delete')
    deliveryMode      — exact string match (e.g. 'external', 'bulk')
    recipientTopology — exact string match (e.g. 'unknown')
    commandPattern    — regex match against request['command']
    pathPattern       — regex match against request['cwd'] OR request['command']
    method            — pipe-separated methods e.g. 'POST|PUT|PATCH'
    host              — regex OR the keywords 'external' / 'internal'
    toolName          — exact string match
    profile           — 'exec' | 'egress' | 'any'  (filtered before reaching here)

Returns (matched: bool, reason: str | None).
"""

import re
from typing import Optional, Tuple

# Simple private IP/loopback pattern for 'internal' host keyword
_INTERNAL_HOST_RE = re.compile(
    r"(^10\.|^192\.168\.|^172\.(1[6-9]|2[0-9]|3[0-1])\.|^169\.254\.|^127\.|^localhost$)",
    re.IGNORECASE,
)


def _matches_condition_field(condition_value: str, request_value: str) -> bool:
    """
    Match a single condition field value against a request value.

    condition_value may be:
      - A plain string (exact case-insensitive match)
      - A regex string (tested if exact match fails)
    """
    cv = str(condition_value).strip()
    rv = str(request_value or "").strip()
    # Exact case-insensitive first
    if cv.lower() == rv.lower():
        return True
    # Try regex
    try:
        if re.search(cv, rv, re.IGNORECASE):
            return True
    except re.error:
        pass
    return False


def _matches_host_condition(condition_value: str, host: str) -> bool:
    """
    Match host condition with support for 'external' / 'internal' keywords.

    'external' — matches any host that is NOT internal
    'internal' — matches hosts in private/loopback ranges
    Otherwise — regex or exact match
    """
    cv = str(condition_value).strip().lower()
    h = str(host or "").strip().lower()

    if cv == "external":
        return bool(h) and not bool(_INTERNAL_HOST_RE.match(h))
    if cv == "internal":
        return bool(_INTERNAL_HOST_RE.match(h))

    # Pipe-separated alternatives e.g. 'POST|PUT|PATCH' (re-used for host too)
    if "|" in cv:
        return any(_matches_condition_field(part.strip(), h) for part in cv.split("|"))

    return _matches_condition_field(cv, h)


def _matches_method_condition(condition_value: str, method: str) -> bool:
    """
    Match method condition — supports pipe-separated e.g. 'POST|PUT|PATCH'.
    """
    cv = str(condition_value).strip()
    if "|" in cv:
        return any(
            part.strip().upper() == str(method or "").strip().upper()
            for part in cv.split("|")
        )
    return cv.upper() == str(method or "").strip().upper()


def eval_package_rule_condition(
    condition: dict,
    request_ctx: dict,
) -> bool:
    """
    Evaluate a package rule condition dict against a normalised request context.

    request_ctx keys used:
        action_class, command, cwd, host, method, deliveryMode,
        recipientTopology, toolName

    Returns True if ALL specified condition fields match (AND logic).
    An empty condition matches everything.
    """
    if not condition:
        return True

    for field, value in condition.items():
        if value is None:
            continue

        if field == "action_class":
            if not _matches_condition_field(str(value), request_ctx.get("action_class", "")):
                return False

        elif field == "deliveryMode":
            if not _matches_condition_field(str(value), request_ctx.get("deliveryMode", "")):
                return False

        elif field == "recipientTopology":
            if not _matches_condition_field(str(value), request_ctx.get("recipientTopology", "")):
                return False

        elif field == "commandPattern":
            cmd = str(request_ctx.get("command", "")).strip()
            try:
                if not re.search(str(value), cmd, re.IGNORECASE):
                    return False
            except re.error:
                return False

        elif field == "pathPattern":
            # Match against cwd first, then command (some path context is in command)
            cwd = str(request_ctx.get("cwd", "")).strip()
            cmd = str(request_ctx.get("command", "")).strip()
            target = cwd or cmd
            # Expand ~ in path
            target = target.replace("~", str(__import__("pathlib").Path.home()))
            try:
                pat = str(value)
                # Also try matching with expanded ~ in the pattern
                if not re.search(pat, target, re.IGNORECASE):
                    # Try matching against the raw command too
                    if not re.search(pat, cmd, re.IGNORECASE):
                        return False
            except re.error:
                return False

        elif field == "method":
            if not _matches_method_condition(str(value), request_ctx.get("method", "")):
                return False

        elif field == "host":
            if not _matches_host_condition(str(value), request_ctx.get("host", "")):
                return False

        elif field == "toolName":
            if not _matches_condition_field(str(value), request_ctx.get("toolName", "")):
                return False

        # Unknown condition fields are ignored (forward-compat)

    return True


def evaluate_package_rules(
    package_rules_with_meta: list,
    request_ctx: dict,
) -> Optional[dict]:
    """
    Evaluate a list of (rule, package_name, fail_closed) tuples against request_ctx.

    Returns the first matching rule's context dict, or None if no match.

    Return shape when matched:
        {
            'matched_package':     str,
            'matched_rule_id':     str,
            'matched_rule_reason': str,
            'outcome':             'allow' | 'deny' | 'challenge',
        }

    package_rules_with_meta items are dicts:
        {
            'rule':        dict,   # governance package rule
            'package':     str,    # package name
            'fail_closed': bool,   # package fail_closed flag
        }
    """
    for entry in package_rules_with_meta:
        rule = entry["rule"]
        package_name = entry["package"]
        fail_closed = entry.get("fail_closed", True)

        try:
            condition = rule.get("condition", {}) or {}
            if eval_package_rule_condition(condition, request_ctx):
                return {
                    "matched_package": package_name,
                    "matched_rule_id": rule.get("id", ""),
                    "matched_rule_reason": rule.get("reason", ""),
                    "outcome": str(rule.get("outcome", "deny")).lower(),
                }
        except Exception:
            # Exception during package rule evaluation
            if fail_closed:
                return {
                    "matched_package": package_name,
                    "matched_rule_id": rule.get("id", ""),
                    "matched_rule_reason": f"package_eval_error:fail_closed:{package_name}",
                    "outcome": "deny",
                }
            # fail_closed=False: swallow exception, skip rule
            continue

    return None


def build_package_rules_with_meta(registry) -> list:
    """
    Build a flat list of (rule, package_name, fail_closed) dicts from a PackageRegistry.

    Returns [] if registry is None.
    """
    if registry is None:
        return []

    result = []
    # Access internal _packages dict to get fail_closed per package
    for pkg in registry._packages.values():
        fail_closed = bool(pkg.get("fail_closed", True))
        for rule in pkg.get("rules", []):
            result.append({
                "rule": rule,
                "package": pkg["name"],
                "fail_closed": fail_closed,
            })
    return result
