PepPolicySchemaVersion = 1


def validatePepPolicyShape(policy_input) -> dict:
    issues: list[str] = []
    if not isinstance(policy_input, dict):
        return {"ok": False, "issues": ["policy must be an object"]}
    if not isinstance(policy_input.get("version"), (int, float)):
        issues.append("policy.version must be a number")
    if str(policy_input.get("defaultAction", "")).lower() not in {"allow", "challenge", "deny"}:
        issues.append("policy.defaultAction must be one of allow|challenge|deny")
    rules = policy_input.get("rules")
    if not isinstance(rules, list):
        issues.append("policy.rules must be an array")
    else:
        for i, r in enumerate(rules):
            if not isinstance(r, dict):
                issues.append(f"policy.rules[{i}] must be an object")
                continue
            if str(r.get("action", "")).lower() not in {"allow", "challenge", "deny"}:
                issues.append(f"policy.rules[{i}].action must be one of allow|challenge|deny")
            kind = str(r.get("kind", "")).lower()
            if kind and kind not in {"exec", "egress"}:
                issues.append(f"policy.rules[{i}].kind must be exec|egress when provided")
    return {"ok": len(issues) == 0, "issues": issues}
