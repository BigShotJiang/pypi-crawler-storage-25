from .._util import b64url_encode
from .canonicalization import canonicalizeForSigning


def receiptBytesFromUnsigned(payload: dict) -> bytes:
    return canonicalizeForSigning(payload)


def signUnsignedReceipt(payload: dict, opts: dict) -> dict:
    bytes_to_sign = receiptBytesFromUnsigned(payload)
    sig_bytes = opts["sign"](bytes_to_sign)
    sig = b64url_encode(sig_bytes)
    signature = {
        "alg": "Ed25519",
        "kid": opts["kid"],
        "sig": sig,
        "canonicalization": "RFC8785-JCS",
    }
    if opts.get("version") is not None:
        signature["version"] = opts["version"]
    return {**payload, "signature": signature}


def signActionReceipt(payload: dict, opts: dict) -> dict:
    return signUnsignedReceipt(payload, opts)
