from .approval_queue import createApprovalQueue
from .connector_governance_adapters import inferGovernedHistoryToolCall, isLikelyMessagingExecCommand
from .decision_token_engine import DecisionTokenScopes, createDecisionTokenEngine
from .governed_action_normalize import normalizeGovernanceFromToolArgs
from .package_rule_evaluator import evaluate_package_rules
from .policy_evaluator import evaluatePolicy
from typing import Optional

ExecPepDecision = {"ALLOW": "allow", "DENY": "deny", "APPROVAL_REQUIRED": "approval_required"}


def createExecPep(options: Optional[dict] = None):
    opts = options or {}
    config = opts.get("config", {})
    policy = opts.get("policy")
    # package_rules_with_meta: list of {rule, package, fail_closed} dicts
    # Pre-built by pep_policy_engine via build_package_rules_with_meta(registry)
    # filtered to exec-applicable rules (profile == 'exec' or 'any')
    package_rules_with_meta: list = opts.get("package_rules_with_meta") or []
    approval_queue = opts.get("approvalQueue") or createApprovalQueue()
    emit_event = opts.get("emitEvent", lambda event: None)
    now = opts.get("now", lambda: __import__('time').time() * 1000)

    strict_mode = str(config.get("governanceMode", "observe")) == "strict"
    token_secret = str(config.get("decisionTokenSecret", "")).strip()
    token_engine = createDecisionTokenEngine({"secret": token_secret, "now": now}) if token_secret else None

    def emit(name, request, payload=None):
        p = payload or {}
        emit_event({
            "runId": request.get("runId"), "sessionId": request.get("sessionId"), "eventType": name,
            "toolName": request.get("toolName"), "outcome": p.get("outcome", "success"),
            "detail": p.get("detail"), "meta": p.get("meta", {}),
        })

    def is_critical_tool(tool_name, risk_tier):
        return risk_tier == "critical" or (isinstance(config.get("criticalToolNames"), list) and tool_name in config.get("criticalToolNames"))

    def verify_token(request):
        if not strict_mode:
            return {"ok": True, "code": "observe_mode"}
        if not is_critical_tool(request["toolName"], request["riskTier"]):
            return {"ok": True, "code": "non_critical_tool"}
        if not token_engine:
            return {"ok": False, "code": "missing_decision_token_secret"}
        token = str(request.get("decisionToken", "")).strip()
        if not token:
            return {"ok": False, "code": "token_missing"}
        scoped = token_engine["verifyToken"](token, {"scope": DecisionTokenScopes.get("EXEC_COMMAND", DecisionTokenScopes["CRITICAL_TOOL_EXECUTE"]), "runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"]})
        if scoped.get("ok") or scoped.get("code") != "token_scope_mismatch":
            return scoped
        return token_engine["verifyToken"](token, {"scope": DecisionTokenScopes["CRITICAL_TOOL_EXECUTE"], "runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"]})

    def evaluate(request_input=None):
        ri = request_input or {}
        action_class = str(ri.get("action_class", "")).strip().lower()
        is_delete = action_class == "delete"
        # Delete operations are always treated as critical risk regardless of caller-supplied riskTier
        effective_risk_tier = "critical" if is_delete else str(ri.get("riskTier", "read")).strip().lower()
        request = {
            "runId": str(ri.get("runId", "")).strip() or f"pep-exec-{int(now())}",
            "sessionId": str(ri.get("sessionId", "")).strip() or "pep-exec-session",
            "toolName": str(ri.get("toolName", "")).strip() or "unknown",
            "riskTier": effective_risk_tier,
            "action_class": action_class,
            "binaryPath": str(ri.get("binaryPath", "trace-runtime")).strip(),
            "command": str(ri.get("command", ri.get("toolName", ""))).strip(),
            "cwd": str(ri.get("cwd", "")).strip(),
            "decisionToken": str(ri.get("decisionToken", "")).strip(),
        }
        ti_claim = ri.get("tiClaimVerification", {}) if isinstance(ri.get("tiClaimVerification", {}), dict) else {}
        ti_state = str(ti_claim.get("state", "")).strip().lower()
        if ti_state not in {"supported", "contradicted", "unresolved"}:
            ti_state = ""
        unresolved_reasons = [str(x) for x in ti_claim.get("unresolved_reasons", [])] if isinstance(ti_claim.get("unresolved_reasons", []), list) else []

        # --- Package rule evaluation (runs before base policy) ---
        # Build request context for package condition matching
        _pkg_ctx = {
            "action_class": request["action_class"],
            "command": request["command"],
            "cwd": request["cwd"],
            "toolName": request["toolName"],
            "riskTier": request["riskTier"],
        }
        # Filter to exec-applicable rules only (profile == 'exec' or 'any')
        exec_pkg_rules = [
            e for e in package_rules_with_meta
            if e["rule"].get("profile") in ("exec", "any")
        ]
        pkg_match = evaluate_package_rules(exec_pkg_rules, _pkg_ctx)
        # pkg_match stored for later use in return values
        # --- End package rule evaluation ---

        gov = normalizeGovernanceFromToolArgs(ri.get("toolArgs") if isinstance(ri.get("toolArgs"), dict) else {"governance": ri.get("governance")}, {"toolName": request["toolName"]})
        inferred = inferGovernedHistoryToolCall({"rawToolName": request["toolName"], "rawArgs": ri.get("toolArgs", {}) if isinstance(ri.get("toolArgs", {}), dict) else {}, "command": request["command"]})
        inferred_gov = ((inferred or {}).get("args", {}) if isinstance((inferred or {}).get("args", {}), dict) else {}).get("governance", {})
        policy_package = gov.get("policyPackage") or str(inferred_gov.get("package", "")).strip().lower()
        governed_action = gov.get("governedAction") or str(inferred_gov.get("action", "")).strip().lower()
        delivery_mode = gov.get("deliveryMode") or str(inferred_gov.get("deliveryMode", "")).strip().lower()
        recipient_topology = gov.get("recipientTopology") or str(inferred_gov.get("recipientTopology", "")).strip().lower()
        message_class = gov.get("messageClass") or str(inferred_gov.get("messageClass", "")).strip().lower()

        governed_by_metadata = bool(policy_package and governed_action and delivery_mode and message_class)
        governed_tool_for_policy = bool(gov.get("isGovernedTool") or governed_by_metadata)

        if gov.get("controlPlaneMutationAttempt"):
            governance_reason = "governance_control_plane_mutation_blocked"
        elif len(gov.get("mismatchedCanonicalFields", [])) > 0:
            governance_reason = "governance_metadata_mismatch"
        elif gov.get("isGovernedTool") and len(gov.get("missingRequiredDimensions", [])) > 0:
            governance_reason = "governance_metadata_missing"
        else:
            governance_reason = ""

        if governance_reason:
            emit("exec_request_blocked", request, {"outcome": "error", "detail": governance_reason, "meta": {"policyPackage": gov.get("policyPackage"), "governedAction": gov.get("governedAction"), "missingDimensions": gov.get("missingRequiredDimensions"), "mismatchedCanonicalFields": gov.get("mismatchedCanonicalFields")}})
            return {"ok": False, "decision": ExecPepDecision["DENY"], "reason": governance_reason, "message": "Blocked by governance policy: Invalid or missing governance metadata.", "policy": {"action": "deny", "matchedRuleId": None, "reason": governance_reason}}

        policy_decision = evaluatePolicy(policy, {
            "kind": "exec", "toolName": request["toolName"], "riskTier": request["riskTier"],
            "action_class": request["action_class"],
            "binaryPath": request["binaryPath"], "tiClaimState": ti_state,
            "command": request["command"], "cwd": request["cwd"],
            "policyPackage": policy_package, "governedAction": governed_action,
            "deliveryMode": delivery_mode, "recipientTopology": recipient_topology, "messageClass": message_class,
        })

        # Governance package outcomes (must run before allow_default_non_governed pass-through)
        if pkg_match is not None:
            pkg_outcome = str(pkg_match.get("outcome", "deny")).lower()
            pkg_meta = {
                "matched_package": pkg_match["matched_package"],
                "matched_rule_id": pkg_match["matched_rule_id"],
                "matched_rule_reason": pkg_match["matched_rule_reason"],
            }
            if pkg_outcome == "deny":
                emit("exec_request_blocked", request, {"outcome": "error", "detail": pkg_match["matched_rule_reason"], "meta": pkg_meta})
                return {"ok": False, "decision": ExecPepDecision["DENY"], "reason": pkg_match["matched_rule_reason"], "message": "Blocked by governance package.", "policy": policy_decision, "package_match": pkg_meta}
            if pkg_outcome == "challenge":
                approval = approval_queue["enqueue"]({"runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"], "args": {"command": request["command"], "cwd": request["cwd"]}})
                emit("exec_request_challenged", request, {"outcome": "error", "detail": f"package_challenge:{approval['id']}", "meta": {**pkg_meta, "approvalQueueId": approval["id"]}})
                return {"ok": False, "decision": ExecPepDecision["APPROVAL_REQUIRED"], "reason": "package_challenge", "message": "Action paused: package rule requires approval.", "approvalQueueId": approval["id"], "policy": policy_decision, "package_match": pkg_meta}
            if pkg_outcome == "allow":
                emit("exec_request_allowed", request, {"detail": f"package_allow:{pkg_match['matched_rule_id']}", "meta": pkg_meta})
                return {"ok": True, "decision": ExecPepDecision["ALLOW"], "reason": f"package_allow:{pkg_match['matched_rule_id']}", "policy": policy_decision, "package_match": pkg_meta}

        strict_unmapped = strict_mode and (not governed_tool_for_policy) and isLikelyMessagingExecCommand({"command": request["command"], "toolName": request["toolName"]})
        # Delete operations are explicitly critical — they cannot bypass the token gate
        # even if the tool is not in criticalToolNames and the policy is default-allow.
        explicit_critical = is_delete or (isinstance(config.get("criticalToolNames"), list) and request["toolName"] in config.get("criticalToolNames"))
        allow_default_non_governed = (not governed_tool_for_policy) and (not explicit_critical) and (not strict_unmapped) and policy_decision.get("reason") == "policy_default" and policy_decision.get("action") == "allow"

        if config.get("traceTiClaimGateEnabled") and request["riskTier"] == "critical":
            if not ti_state and config.get("traceTiFailClosedCritical", True):
                emit("exec_request_blocked", request, {"outcome": "error", "detail": "ti_claim_missing", "meta": {"ti_claim_state": "missing"}})
                return {"ok": False, "decision": ExecPepDecision["DENY"], "reason": "ti_claim_missing", "message": "Blocked by governance policy: Action requires verified evidence.", "policy": policy_decision}
            if ti_state == "contradicted":
                emit("exec_request_blocked", request, {"outcome": "error", "detail": "ti_claim_contradicted", "meta": {"ti_claim_state": ti_state}})
                return {"ok": False, "decision": ExecPepDecision["DENY"], "reason": "ti_claim_contradicted", "message": "Blocked by governance policy: Action requires verified evidence.", "policy": policy_decision}
            if ti_state == "unresolved":
                approval = approval_queue["enqueue"]({"runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"], "args": {"command": request["command"], "cwd": request["cwd"], "ti_claim_state": ti_state, "ti_unresolved_reasons": unresolved_reasons}})
                emit("exec_request_challenged", request, {"outcome": "error", "detail": f"ti_claim_unresolved:{approval['id']}", "meta": {"approvalQueueId": approval["id"], "ti_claim_state": ti_state}})
                return {"ok": False, "decision": ExecPepDecision["APPROVAL_REQUIRED"], "reason": "ti_claim_unresolved", "message": "Action paused: unresolved claim requires approval.", "approvalQueueId": approval["id"], "policy": policy_decision}

        if allow_default_non_governed:
            emit("exec_request_allowed", request, {"detail": "policy_default_non_governed_pass_through"})
            return {"ok": True, "decision": ExecPepDecision["ALLOW"], "reason": "policy_default_non_governed_pass_through", "policy": policy_decision}

        token_check = verify_token(request)
        if not token_check.get("ok"):
            emit("exec_request_blocked", request, {"outcome": "error", "detail": f"token_invalid:{token_check.get('code')}"})
            return {"ok": False, "decision": ExecPepDecision["DENY"], "reason": f"token_invalid:{token_check.get('code')}", "message": "Blocked by governance policy: Invalid decision token.", "policy": policy_decision}

        if policy_decision.get("action") == "allow":
            emit("exec_request_allowed", request, {"detail": policy_decision.get("reason")})
            return {"ok": True, "decision": ExecPepDecision["ALLOW"], "reason": policy_decision.get("reason"), "policy": policy_decision}

        if policy_decision.get("action") == "challenge":
            approval = approval_queue["enqueue"]({"runId": request["runId"], "sessionId": request["sessionId"], "toolName": request["toolName"], "args": {"command": request["command"], "cwd": request["cwd"]}})
            emit("exec_request_challenged", request, {"outcome": "error", "detail": f"approval_required:{approval['id']}", "meta": {"approvalQueueId": approval["id"]}})
            return {"ok": False, "decision": ExecPepDecision["APPROVAL_REQUIRED"], "reason": "approval_required", "message": "Action paused: human approval required.", "approvalQueueId": approval["id"], "policy": policy_decision}

        emit("exec_request_blocked", request, {"outcome": "error", "detail": policy_decision.get("reason")})
        return {"ok": False, "decision": ExecPepDecision["DENY"], "reason": policy_decision.get("reason"), "message": "Blocked by governance policy.", "policy": policy_decision}

    return {"evaluate": evaluate, "approvalQueue": approval_queue}
