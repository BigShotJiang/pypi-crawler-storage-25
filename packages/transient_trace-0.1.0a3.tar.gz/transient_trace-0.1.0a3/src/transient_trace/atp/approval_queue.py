import hashlib
import json
from datetime import datetime, timezone
from typing import Optional


APPROVAL_QUEUE_EVENTS = {
    "PENDING": "approval_queue_pending",
    "GRANTED": "approval_queue_granted",
    "DENIED": "approval_queue_denied",
}


def _stable(value):
    if isinstance(value, dict):
        return {k: _stable(value[k]) for k in sorted(value.keys()) if value[k] is not None}
    if isinstance(value, list):
        return [_stable(v) for v in value]
    if isinstance(value, int) and abs(value) > (1 << 53):
        return str(value)
    return value


def _hash_args(args: dict) -> str:
    stable = json.dumps(_stable(args), separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(stable.encode("utf-8")).hexdigest()[:16]


def createApprovalQueue(options: Optional[dict] = None):
    persist = (options or {}).get("persistEvent")
    pending: dict[str, dict] = {}
    next_id = {"v": 1}

    def emit(event: dict):
        if persist:
            persist(event)

    def enqueue(input: dict):
        i = f"aq-{next_id['v']}"
        next_id["v"] += 1
        entry = {
            "id": i,
            "runId": input["runId"],
            "sessionId": input["sessionId"],
            "toolName": input["toolName"],
            "argsHash": _hash_args(input.get("args", {})),
            "status": "pending",
            "createdAt": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
        }
        pending[i] = entry
        emit({
            "runId": entry["runId"], "sessionId": entry["sessionId"], "toolName": entry["toolName"],
            "eventType": APPROVAL_QUEUE_EVENTS["PENDING"], "detail": f"approval_queued:{i}",
            "approvalQueueId": i, "argsHash": entry["argsHash"],
            "capturedAt": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
        })
        return dict(entry)

    def grant(i: str, ctx: Optional[dict] = None):
        e = pending.get(i)
        if not e:
            return {"decision": "denied", "reason": "unknown_id"}
        if e["status"] != "pending":
            return {"decision": "denied", "reason": f"already_{e['status']}", **e}
        e["status"] = "granted"
        e["resolvedAt"] = datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z')
        c = ctx or {}
        emit({
            "runId": c.get("runId", e["runId"]), "sessionId": c.get("sessionId", e["sessionId"]), "toolName": c.get("toolName", e["toolName"]),
            "eventType": APPROVAL_QUEUE_EVENTS["GRANTED"], "detail": f"approval_granted:{i}", "approvalQueueId": i,
            "capturedAt": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
        })
        return {"decision": "granted", **e}

    def deny(i: str, ctx: Optional[dict] = None):
        e = pending.get(i)
        if not e:
            return {"decision": "denied", "reason": "unknown_id"}
        if e["status"] != "pending":
            return {"decision": "denied", "reason": f"already_{e['status']}", **e}
        c = ctx or {}
        reason = str(c.get("reason", "")).strip() or "operator_denied"
        e["status"] = "denied"
        e["resolvedAt"] = datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z')
        e["denyReason"] = reason
        emit({
            "runId": c.get("runId", e["runId"]), "sessionId": c.get("sessionId", e["sessionId"]), "toolName": c.get("toolName", e["toolName"]),
            "eventType": APPROVAL_QUEUE_EVENTS["DENIED"], "detail": f"approval_denied:{i}:{reason}", "approvalQueueId": i, "outcome": "error",
            "capturedAt": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
        })
        return {"decision": "denied", "reason": reason, **e}

    return {
        "enqueue": enqueue,
        "grant": grant,
        "deny": deny,
        "getPending": lambda: [dict(v) for v in pending.values() if v["status"] == "pending"],
        "getById": lambda i: dict(pending[i]) if i in pending else None,
        "APPROVAL_QUEUE_EVENTS": APPROVAL_QUEUE_EVENTS,
    }
