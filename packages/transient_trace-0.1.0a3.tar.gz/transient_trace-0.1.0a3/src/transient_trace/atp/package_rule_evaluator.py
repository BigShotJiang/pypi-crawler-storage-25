"""
package_rule_evaluator.py — Evaluate governance package rules against a PEP request context.

Package rules use a condition dict with different field names than the base policy_evaluator.
This module provides:

  evaluate_package_rules(pkg_rule_entries, context) -> dict | None

Where pkg_rule_entries is a list of:
  {
    "rule": {condition, outcome, reason, id, profile},
    "package_name": str,
    "fail_closed": bool,
  }

And context is a flat dict with keys drawn from the request (command, cwd, riskTier, action_class,
host, method, deliveryMode, recipientTopology, toolName, path, policyPackage, governedAction).

Returns the first matching entry's result dict, or None if no rule matches:
  {
    "outcome": "allow" | "deny" | "challenge",
    "matched_package": str,
    "matched_rule_id": str,
    "matched_rule_reason": str,
  }

If a package raises an exception during evaluation:
  - fail_closed=True  -> treated as deny
  - fail_closed=False -> rule is skipped (pass through)
"""

import logging
import re
from typing import Optional

_log = logging.getLogger(__name__)


def _match_condition(condition: dict, context: dict) -> bool:
    """
    Match a package rule condition dict against a flat request context.

    Condition fields (all optional — omitted field means match-all):
      action_class   str   exact match against context["action_class"]
      toolName       str   exact match against context["toolName"]
      host           str   regex or exact match against context["host"]
      method         str   pipe-separated alternatives e.g. "POST|PUT" or exact
      deliveryMode   str   exact match against context["deliveryMode"]
      recipientTopology str exact match against context["recipientTopology"]
      messageClass   str   exact match against context["messageClass"]
      commandPattern str   regex search against context["command"]
      pathPattern    str   regex search against context["path"] or context["cwd"]
    """
    for field, pattern in condition.items():
        pattern_str = str(pattern)

        if field == "action_class":
            if str(context.get("action_class", "")).lower() != pattern_str.lower():
                return False

        elif field == "toolName":
            if str(context.get("toolName", "")).lower() != pattern_str.lower():
                return False

        elif field == "host":
            host_val = str(context.get("host", "")).lower()
            # Special sentinel values
            if pattern_str == "external":
                # Non-empty host that is not localhost/loopback counts as external
                if not host_val or host_val in ("localhost", "127.0.0.1", "::1"):
                    return False
            else:
                try:
                    if not re.search(pattern_str, host_val, re.IGNORECASE):
                        return False
                except re.error:
                    if host_val != pattern_str.lower():
                        return False

        elif field == "method":
            method_val = str(context.get("method", "")).upper()
            # Support pipe-separated alternatives e.g. "POST|PUT|PATCH"
            alternatives = [m.strip().upper() for m in pattern_str.split("|") if m.strip()]
            if alternatives and method_val not in alternatives:
                return False

        elif field == "deliveryMode":
            if str(context.get("deliveryMode", "")).lower() != pattern_str.lower():
                return False

        elif field == "recipientTopology":
            if str(context.get("recipientTopology", "")).lower() != pattern_str.lower():
                return False

        elif field == "messageClass":
            if str(context.get("messageClass", "")).lower() != pattern_str.lower():
                return False

        elif field == "commandPattern":
            command_val = str(context.get("command", ""))
            try:
                if not re.search(pattern_str, command_val):
                    return False
            except re.error:
                # Invalid regex — treat as no match
                return False

        elif field == "pathPattern":
            # Check cwd, path, paths list, and the full command string.
            # Command is included so patterns like /\.ssh/ fire on
            # "cat ~/.ssh/id_rsa" even when an explicit path isn't extracted.
            cwd_val  = str(context.get("cwd", ""))
            path_val = str(context.get("path", ""))
            paths_val = " ".join(str(p) for p in context.get("paths", []))
            cmd_val  = str(context.get("command", ""))
            # Expand ~ in command for home-dir path patterns
            import pathlib as _pl
            cmd_expanded = cmd_val.replace("~", str(_pl.Path.home()))
            target_str = " ".join(filter(None, [cwd_val, path_val, paths_val, cmd_expanded]))

            # Special sentinel
            if pattern_str == "outside_cwd":
                # Match if cwd is unknown or any path argument is outside cwd.
                if not cwd_val:
                    # No cwd to compare — treat as outside (conservative)
                    pass  # falls through to match
                else:
                    # Paths that start with cwd are inside
                    for p in [path_val] + list(context.get("paths", [])):
                        p_str = str(p)
                        if p_str and not p_str.startswith(cwd_val):
                            break  # at least one path is outside — continue matching
                    else:
                        return False  # all paths are inside cwd — does NOT match
            else:
                try:
                    if not re.search(pattern_str, target_str):
                        return False
                except re.error:
                    return False

        # Unknown condition fields are ignored (forward-compat)

    return True


def evaluate_package_rules(
    pkg_rule_entries: list,
    context: dict,
) -> Optional[dict]:
    """
    Evaluate a list of package rule entries against the given request context.

    Returns the first match result dict, or None if no rule fires.

    pkg_rule_entries: list of {rule, package_name, fail_closed}
    context: flat dict — action_class, command, cwd, path, host, method,
             deliveryMode, recipientTopology, messageClass, toolName, paths

    On exception:
      fail_closed=True  -> deny
      fail_closed=False -> skip this rule
    """
    for entry in pkg_rule_entries:
        rule = entry.get("rule", {})
        package_name = str(entry.get("package_name", "unknown"))
        fail_closed = bool(entry.get("fail_closed", True))

        try:
            condition = rule.get("condition", {})
            if not isinstance(condition, dict):
                continue
            if not _match_condition(condition, context):
                continue

            # Rule matched
            return {
                "outcome": str(rule.get("outcome", "deny")),
                "matched_package": package_name,
                "matched_rule_id": str(rule.get("id", "")) or f"{package_name}:unnamed",
                "matched_rule_reason": str(rule.get("reason", "")),
            }

        except Exception as exc:  # noqa: BLE001
            _log.warning(
                "package rule evaluation error in package '%s': %s",
                package_name,
                exc,
            )
            if fail_closed:
                return {
                    "outcome": "deny",
                    "matched_package": package_name,
                    "matched_rule_id": str(rule.get("id", "")) or f"{package_name}:exception",
                    "matched_rule_reason": f"Package evaluation error (fail_closed): {exc}",
                }
            # fail_closed=False — skip, continue to next rule

    return None
