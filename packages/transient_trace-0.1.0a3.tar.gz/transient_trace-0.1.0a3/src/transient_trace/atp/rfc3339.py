from datetime import datetime, timezone, timedelta


def rfc3339Now() -> str:
    return datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z')


def orderedProofTimestamps() -> dict:
    base = datetime.now(tz=timezone.utc)
    return {
        "occurred_at": base.isoformat().replace('+00:00', 'Z'),
        "received_at": (base + timedelta(milliseconds=1)).isoformat().replace('+00:00', 'Z'),
        "sealed_at": (base + timedelta(milliseconds=2)).isoformat().replace('+00:00', 'Z'),
    }


def parseRfc3339Ms(iso: str) -> int:
    try:
        dt = datetime.fromisoformat(iso.replace('Z', '+00:00'))
    except Exception as e:
        raise ValueError(f"Invalid RFC3339 timestamp: {iso}") from e
    return int(dt.timestamp() * 1000)
