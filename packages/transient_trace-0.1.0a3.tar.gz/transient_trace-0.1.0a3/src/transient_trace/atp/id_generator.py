import ulid


def _new_ulid() -> str:
    return str(ulid.ULID())


def resetIdCountersForTesting():
    # Kept for backward compatibility with existing tests.
    # ULID generation is stateless and does not use local counters.
    return None


def generateIntentId() -> str:
    return f"TI-{_new_ulid()}"


def generateDecisionId() -> str:
    return f"TD-{_new_ulid()}"


def generateReceiptId() -> str:
    return f"TR-{_new_ulid()}"
