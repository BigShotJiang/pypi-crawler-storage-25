import json

from .._util import rfc8785_bytes


def canonicalizeForSigning(obj) -> bytes:
    clone = json.loads(json.dumps(obj))
    if isinstance(clone, dict) and "signature" in clone:
        del clone["signature"]
    return rfc8785_bytes(clone)


def canonicalizeForHashing(obj) -> bytes:
    clone = json.loads(json.dumps(obj))
    return rfc8785_bytes(clone)
