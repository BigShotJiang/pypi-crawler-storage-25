import json
import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Literal, Optional

from .id_generator import generateDecisionId
from .pep_egress import createEgressPep
from .pep_exec import createExecPep
from .pep_policy_contract import validatePepPolicyShape
from .rfc3339 import rfc3339Now

_log = logging.getLogger(__name__)

GovernanceMode = Literal["audit", "permissive", "strict"]
_VALID_MODES = frozenset({"audit", "permissive", "strict"})


def _deny_all_policy():
    return {"version": 1, "defaultAction": "deny", "rules": []}


def _parse_policy_file(path: str):
    try:
        parsed = json.loads(Path(path).read_text())
        chk = validatePepPolicyShape(parsed)
        return parsed if chk["ok"] else None
    except Exception:
        return None


def _load_policy(policy_arg=None):
    if policy_arg:
        return policy_arg
    env_path = str(os.getenv("ATP_POLICY_PATH", "")).strip()
    if env_path:
        p = _parse_policy_file(str(Path(env_path).resolve()))
        if p:
            return p
    pwd_policy = Path.cwd() / '.atp' / 'policy.json'
    if pwd_policy.exists():
        p = _parse_policy_file(str(pwd_policy))
        if p:
            return p
    return _deny_all_policy()


# Map ATP action_class to PEP riskTier.
# delete is intentionally left as-is so pep_exec can apply its own
# critical elevation logic for delete operations.
_ACTION_CLASS_TO_RISK_TIER: dict = {
    "read": "read",
    "write_low": "write_low",
    "write_high": "write_high",
    "delete": "critical",
    "bulk_export": "high",
}


def _intent_to_exec_input(intent: dict) -> dict:
    """
    Translate an ATP intent dict into the flat evaluation request shape
    expected by createExecPep's evaluate() function.
    """
    ctx = intent.get("context", {}) if isinstance(intent.get("context"), dict) else {}
    metadata = intent.get("metadata", {}) if isinstance(intent.get("metadata"), dict) else {}
    target = intent.get("target", {}) if isinstance(intent.get("target"), dict) else {}
    action_class = str(intent.get("action_class", "write_low")).strip().lower()
    risk_tier = _ACTION_CLASS_TO_RISK_TIER.get(action_class, "write_low")

    # Reconstruct toolArgs with governance block if governance metadata is present
    tool_args: Optional[dict] = None
    gov_package = str(metadata.get("policyPackage", metadata.get("package", ""))).strip().lower()
    gov_action = str(metadata.get("governedAction", metadata.get("action", ""))).strip().lower()
    if gov_package or gov_action:
        tool_args = {
            "governance": {
                "package": gov_package,
                "action": gov_action,
                "deliveryMode": str(metadata.get("deliveryMode", "")).strip().lower(),
                "recipientTopology": str(metadata.get("recipientTopology", "")).strip().lower(),
                "messageClass": str(metadata.get("messageClass", "")).strip().lower(),
            }
        }

    return {
        "runId": str(ctx.get("runId", intent.get("intent_id", ""))).strip() or "pep-run",
        "sessionId": str(ctx.get("sessionId", "")).strip() or "pep-session",
        "toolName": str(intent.get("action", intent.get("connector", ""))).strip() or "unknown",
        "riskTier": risk_tier,
        "action_class": action_class,
        "binaryPath": str(target.get("binaryPath", "trace-runtime")).strip(),
        "command": str(
            target.get("command", intent.get("action", ""))
        ).strip(),
        "cwd": str(target.get("cwd", "")).strip(),
        "path": str(target.get("path", target.get("id", ""))).strip(),
        "paths": list(metadata.get("paths", [])) if isinstance(metadata.get("paths"), list) else [],
        "decisionToken": str(metadata.get("decisionToken", "")).strip(),
        "tiClaimVerification": metadata.get("tiClaimVerification"),
        **({("toolArgs"): tool_args} if tool_args is not None else {}),
    }


def _intent_to_egress_input(intent: dict) -> dict:
    """
    Translate an ATP intent dict into the flat evaluation request shape
    expected by createEgressPep's evaluate() function.
    """
    ctx = intent.get("context", {}) if isinstance(intent.get("context"), dict) else {}
    metadata = intent.get("metadata", {}) if isinstance(intent.get("metadata"), dict) else {}
    target = intent.get("target", {}) if isinstance(intent.get("target"), dict) else {}
    action_class = str(intent.get("action_class", "write_low")).strip().lower()
    risk_tier = _ACTION_CLASS_TO_RISK_TIER.get(action_class, "write_low")

    host = str(target.get("host", target.get("domain", ""))).strip().lower()
    method = str(target.get("method", "POST")).strip().upper()
    path = str(target.get("path", "/")).strip() or "/"
    port_raw = target.get("port", 443)
    try:
        port = int(port_raw)
    except (TypeError, ValueError):
        port = 443

    # Reconstruct toolArgs with governance block if present
    tool_args: Optional[dict] = None
    gov_package = str(metadata.get("policyPackage", metadata.get("package", ""))).strip().lower()
    gov_action = str(metadata.get("governedAction", metadata.get("action", ""))).strip().lower()
    if gov_package or gov_action:
        tool_args = {
            "governance": {
                "package": gov_package,
                "action": gov_action,
                "deliveryMode": str(metadata.get("deliveryMode", "")).strip().lower(),
                "recipientTopology": str(metadata.get("recipientTopology", "")).strip().lower(),
                "messageClass": str(metadata.get("messageClass", "")).strip().lower(),
            }
        }

    return {
        "runId": str(ctx.get("runId", intent.get("intent_id", ""))).strip() or "pep-run",
        "sessionId": str(ctx.get("sessionId", "")).strip() or "pep-session",
        "toolName": str(intent.get("action", intent.get("connector", ""))).strip() or "unknown",
        "binaryPath": str(target.get("binaryPath", "")).strip() or "unknown",
        "action_class": action_class,
        "riskTier": risk_tier,
        "method": method,
        "host": host,
        "port": port,
        "path": path,
        "deliveryMode": str(metadata.get("deliveryMode", "")).strip().lower(),
        "recipientTopology": str(metadata.get("recipientTopology", "")).strip().lower(),
        "messageClass": str(metadata.get("messageClass", "")).strip().lower(),
        "decisionToken": str(metadata.get("decisionToken", "")).strip(),
        "tiClaimVerification": metadata.get("tiClaimVerification"),
        **({("toolArgs"): tool_args} if tool_args is not None else {}),
    }


def _build_pkg_rule_entries(registry, profile: str) -> list:
    """
    Build the list of {rule, package_name, fail_closed} entries for a given profile.
    Rules from each package are annotated with the package name and fail_closed flag.
    """
    if registry is None:
        return []
    entries = []
    # Iterate packages in load order
    for pkg in registry._packages.values():
        fail_closed = bool(pkg.get("fail_closed", True))
        pkg_name = str(pkg.get("name", "unknown"))
        for rule in pkg.get("rules", []):
            rule_profile = rule.get("profile", "")
            if profile == "any" or rule_profile == profile or rule_profile == "any":
                entries.append({
                    "rule": rule,
                    "package_name": pkg_name,
                    "fail_closed": fail_closed,
                })
    return entries


class PepPolicyEngine:
    def __init__(
        self,
        config: Optional[dict] = None,
        policy: Optional[dict] = None,
        packages: Optional[list] = None,
        registry=None,
        mode: Optional[str] = None,
        receipt_engine=None,
    ):
        self.config = config or {}
        self._registry = registry  # PackageRegistry or None
        self._receipt_engine = receipt_engine  # ReceiptEngine or None
        self._mode: str = str(mode).strip().lower() if mode else "strict"
        if self._mode not in _VALID_MODES:
            raise ValueError(
                f"invalid governance mode '{self._mode}'; must be one of: "
                + ", ".join(sorted(_VALID_MODES))
            )

        base_policy = _load_policy(policy or self.config.get("policy"))

        # Package rules are evaluated separately by the PEP engines (not merged into base policy).
        # Explicit policy rules always win on conflict — packages are additive only.
        # We build per-profile annotated entry lists for the PEP engines.
        self._exec_pkg_entries = _build_pkg_rule_entries(registry, "exec")
        self._egress_pkg_entries = _build_pkg_rule_entries(registry, "egress")

        self.policy = base_policy
        self.exec_pep = createExecPep({
            "config": self.config,
            "policy": self.policy,
            "package_rules_with_meta": self._exec_pkg_entries,
        })

        self.egress_pep = createEgressPep({
            "config": self.config,
            "policy": self.policy,
            "package_rules_with_meta": self._egress_pkg_entries,
        })

    def requestDecision(self, intent: dict):
        metadata = intent.get("metadata", {}) if isinstance(intent.get("metadata", {}), dict) else {}
        action_type = str(metadata.get("action_type", "exec")).strip().lower()

        # Translate ATP intent to PEP engine evaluation input shape
        if action_type == "network":
            pep_input = _intent_to_egress_input(intent)
            evaluated = self.egress_pep["evaluate"](pep_input)
        else:
            pep_input = _intent_to_exec_input(intent)
            evaluated = self.exec_pep["evaluate"](pep_input)

        # Receipt engine: get prior pattern for this action context
        # Attached to every decision response — agent reads this as part of
        # the decision it already has to read. No prompt injection. Not optional.
        prior_pattern = None
        if self._receipt_engine:
            try:
                prior_pattern = self._receipt_engine.get_prior_pattern(
                    action_class=intent.get("action_class"),
                    tool_name=intent.get("action"),
                    host=intent.get("target", {}).get("host") if isinstance(intent.get("target"), dict) else None,
                    path=intent.get("target", {}).get("path") if isinstance(intent.get("target"), dict) else None,
                )
            except Exception as exc:  # noqa: BLE001
                _log.warning("[receipt-engine] get_prior_pattern failed (non-fatal): %s", exc)

        raw_decision = evaluated["decision"]

        # Mode: audit/permissive — never block, always allow
        # audit: evaluate rules, record what would fire, never block
        # permissive: evaluate rules, log violations, never block
        # strict (default): evaluate rules, block on deny outcome
        if self._mode in ("audit", "permissive"):
            d = {
                "decision_id": generateDecisionId(),
                "intent_id": intent["intent_id"],
                "outcome": "allow",
                "reason_code": f"{self._mode}:would_be_{raw_decision}:{evaluated['reason']}",
                "decided_at": rfc3339Now(),
                "governance_mode": self._mode,
            }
            if evaluated["policy"].get("matchedRuleId"):
                d["rule_id"] = evaluated["policy"]["matchedRuleId"]
            _attach_pkg_match(d, evaluated)
            _attach_prior_pattern(d, prior_pattern)
            return d

        # strict mode — normal enforcement
        if raw_decision == "allow":
            d = {
                "decision_id": generateDecisionId(),
                "intent_id": intent["intent_id"],
                "outcome": "allow",
                "reason_code": evaluated["reason"],
                "decided_at": rfc3339Now(),
            }
            if evaluated["policy"].get("matchedRuleId"):
                d["rule_id"] = evaluated["policy"]["matchedRuleId"]
            _attach_pkg_match(d, evaluated)
            _attach_prior_pattern(d, prior_pattern)
            return d
        if raw_decision == "approval_required":
            d = {
                "decision_id": generateDecisionId(),
                "intent_id": intent["intent_id"],
                "outcome": "approve",
                "reason_code": evaluated["reason"],
                "decided_at": rfc3339Now(),
                "expires_at": (datetime.now(tz=timezone.utc) + timedelta(seconds=60)).isoformat().replace('+00:00', 'Z'),
            }
            if evaluated["policy"].get("matchedRuleId"):
                d["rule_id"] = evaluated["policy"]["matchedRuleId"]
            _attach_pkg_match(d, evaluated)
            _attach_prior_pattern(d, prior_pattern)
            return d
        d = {
            "decision_id": generateDecisionId(),
            "intent_id": intent["intent_id"],
            "outcome": "deny",
            "reason_code": evaluated["reason"],
            "decided_at": rfc3339Now(),
        }
        if evaluated["policy"].get("matchedRuleId"):
            d["rule_id"] = evaluated["policy"]["matchedRuleId"]
        _attach_pkg_match(d, evaluated)
        _attach_prior_pattern(d, prior_pattern)
        return d


def _attach_pkg_match(decision: dict, evaluated: dict) -> None:
    """Copy package match fields from evaluated result into decision dict if present."""
    pkg_match = evaluated.get("package_match")
    if pkg_match:
        decision["matched_package"] = pkg_match.get("matched_package")
        decision["matched_rule_id"] = pkg_match.get("matched_rule_id")
        decision["matched_rule_reason"] = pkg_match.get("matched_rule_reason")


def _attach_prior_pattern(decision: dict, prior_pattern: Optional[dict]) -> None:
    """Attach receipt engine prior pattern to decision if available."""
    if prior_pattern:
        decision["prior_pattern"] = prior_pattern
