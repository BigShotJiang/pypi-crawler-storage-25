import re
from typing import Optional


def createDefaultPolicy() -> dict:
    return {"version": 1, "defaultAction": "deny", "rules": []}


# Governance self-protection rules — always evaluated first, cannot be removed
# or overridden by operator policy, CLI flags, or environment variables.
# These block an agent from uninstalling transient-trace or removing its shims
# to create an ungoverned window.
_GOVERNANCE_INTEGRITY_RULES: list[dict] = [
    {
        "id": "protect:no-uninstall-governance",
        "action": "deny",
        "commandPatterns": [
            "pip uninstall*transient*",
            "pip3 uninstall*transient*",
            "python* -m pip uninstall*transient*",
            "python3* -m pip uninstall*transient*",
            "uv* uninstall*transient*",
            "uv pip uninstall*transient*",
        ],
    },
    {
        "id": "protect:no-wrap-uninstall",
        "action": "deny",
        "commandPatterns": [
            "transient-trace wrap uninstall*",
            "transient-trace wrap*uninstall*",
        ],
    },
]


def _wildcard(pattern: str) -> re.Pattern:
    escaped = re.escape(pattern).replace(r"\*", ".*")
    return re.compile(f"^{escaped}$", re.IGNORECASE)


def _matches_any(value, patterns):
    if not patterns:
        return True
    s = str(value or "")
    return any(_wildcard(str(p)).match(s) for p in patterns)


def _matches_number(value, allowed):
    if not allowed:
        return True
    try:
        n = int(value)
    except Exception:
        return False
    return any(int(x) == n for x in allowed)


def evaluatePolicy(policy_input: Optional[dict], request_input: Optional[dict] = None) -> dict:
    policy = policy_input or createDefaultPolicy()
    req = {
        "kind": str((request_input or {}).get("kind", "")).strip().lower(),
        "toolName": str((request_input or {}).get("toolName", "")).strip(),
        "binaryPath": str((request_input or {}).get("binaryPath", "")).strip(),
        "riskTier": str((request_input or {}).get("riskTier", "")).strip().lower(),
        "action_class": str((request_input or {}).get("action_class", "")).strip().lower(),
        "host": str((request_input or {}).get("host", "")).strip().lower(),
        "port": (request_input or {}).get("port"),
        "method": str((request_input or {}).get("method", "")).strip().upper(),
        "tiClaimState": str((request_input or {}).get("tiClaimState", "")).strip().lower(),
        "path": str((request_input or {}).get("path", "")).strip(),
        "command": str((request_input or {}).get("command", "")).strip(),
        "cwd": str((request_input or {}).get("cwd", "")).strip(),
        "policyPackage": str((request_input or {}).get("policyPackage", "")).strip().lower(),
        "governedAction": str((request_input or {}).get("governedAction", "")).strip().lower(),
        "deliveryMode": str((request_input or {}).get("deliveryMode", "")).strip().lower(),
        "recipientTopology": str((request_input or {}).get("recipientTopology", "")).strip().lower(),
        "messageClass": str((request_input or {}).get("messageClass", "")).strip().lower(),
    }

    priority = {"allow": 1, "challenge": 2, "deny": 3}
    selected = None
    best = 0
    # Governance integrity rules are always prepended — they cannot be removed
    # by the operator policy.
    effective_rules = _GOVERNANCE_INTEGRITY_RULES + list(policy.get("rules", []))
    for i, rr in enumerate(effective_rules):
        r = rr or {}

        # Support shorthand `conditions` dict as alias for individual match fields.
        # e.g. {"conditions": {"action_class": "exec"}} expands to {"actionClasses": ["exec"]}
        # This makes operator-authored policies readable without knowing the internal field names.
        _cond = r.get("conditions")
        if isinstance(_cond, dict):
            r = dict(r)
            _MAP = {
                "action_class": "actionClasses", "risk_tier": "riskTiers",
                "host": "hosts", "method": "methods", "path": "pathPatterns",
                "command": "commandPatterns", "binary": "binaries", "tool": "toolNames",
            }
            for ck, fk in _MAP.items():
                if ck in _cond and fk not in r:
                    v = _cond[ck]
                    r[fk] = [v] if isinstance(v, str) else list(v)

        kind = str(r.get("kind", "")).strip().lower()
        if kind and kind != req["kind"]:
            continue
        if not _matches_any(req["toolName"], r.get("toolNames", [])): continue
        if not _matches_any(req["binaryPath"], r.get("binaries", [])): continue
        if not _matches_any(req["riskTier"], r.get("riskTiers", [])): continue
        if not _matches_any(req["action_class"], r.get("actionClasses", [])): continue
        if not _matches_any(req["host"], r.get("hosts", [])): continue
        if not _matches_number(req["port"], r.get("ports", [])): continue
        if not _matches_any(req["method"], r.get("methods", [])): continue
        if not _matches_any(req["tiClaimState"], r.get("tiClaimStates", [])): continue
        if not _matches_any(req["path"], r.get("pathPatterns", [])): continue
        if not _matches_any(req["command"], r.get("commandPatterns", [])): continue
        if not _matches_any(req["policyPackage"], r.get("packages", [])): continue
        if not _matches_any(req["governedAction"], r.get("governedActions", [])): continue
        if not _matches_any(req["deliveryMode"], r.get("deliveryModes", [])): continue
        if not _matches_any(req["recipientTopology"], r.get("recipientTopologies", [])): continue
        if not _matches_any(req["messageClass"], r.get("messageClasses", [])): continue
        cwd_prefixes = r.get("cwdPrefixes", [])
        cwd = str(req["cwd"])
        if cwd_prefixes and not any(cwd.startswith(str(p)) for p in cwd_prefixes):
            continue

        action = str(r.get("action", "deny")).lower()
        p = priority.get(action, 3)
        if p > best:
            selected = {"action": action, "id": str(r.get("id", f"rule-{i+1}"))}
            best = p
            if p == 3:
                break

    if selected:
        return {"action": selected["action"], "matchedRuleId": selected["id"], "reason": f"policy_rule:{selected['id']}"}

    fallback = str(policy.get("defaultAction", "deny")).lower()
    if fallback not in {"allow", "challenge", "deny"}:
        fallback = "deny"
    return {"action": fallback, "matchedRuleId": None, "reason": "policy_default"}