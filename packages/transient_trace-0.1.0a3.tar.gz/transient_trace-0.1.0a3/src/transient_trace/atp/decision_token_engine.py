import base64
import hashlib
import hmac
import json
import time
import uuid
from typing import Optional


DecisionTokenScopes = {
    "CRITICAL_TOOL_EXECUTE": "critical_tool_execute",
    "EGRESS_REQUEST": "egress_request",
    "EXEC_COMMAND": "exec_command",
}


def _b64u(s: str) -> str:
    return base64.urlsafe_b64encode(s.encode("utf-8")).decode("ascii").rstrip("=")


def _from_b64u(s: str) -> str:
    pad = "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii")).decode("utf-8")


def _sign(secret: str, h: str, p: str) -> str:
    return base64.urlsafe_b64encode(
        hmac.new(secret.encode("utf-8"), f"{h}.{p}".encode("utf-8"), hashlib.sha256).digest()
    ).decode("ascii").rstrip("=")


def _safe_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def createDecisionTokenEngine(cfg: dict):
    secret = str(cfg.get("secret", "")).strip()
    if not secret:
        raise ValueError("Decision token engine requires a non-empty secret.")

    issuer = cfg.get("issuer", "transient-governance")
    default_ttl = int(cfg.get("defaultTtlMs", 60_000))
    now = cfg.get("now", lambda: int(time.time() * 1000))

    def mintToken(input: dict) -> str:
        iat = int(now())
        exp = iat + max(1, int(input.get("ttlMs", default_ttl) or default_ttl))
        header = {"alg": "HS256", "typ": "DTT", "iss": issuer}
        payload = {
            "runId": str(input.get("runId", "")),
            "sessionId": str(input.get("sessionId", "")),
            "toolName": str(input.get("toolName", "")),
            "scope": input.get("scope", DecisionTokenScopes["CRITICAL_TOOL_EXECUTE"]),
            "iat": iat,
            "exp": exp,
            "nonce": str(uuid.uuid4()),
        }
        eh = _b64u(json.dumps(header, separators=(",", ":")))
        ep = _b64u(json.dumps(payload, separators=(",", ":")))
        sig = _sign(secret, eh, ep)
        return f"{eh}.{ep}.{sig}"

    def verifyToken(token: str, expected: Optional[dict] = None) -> dict:
        expd = expected or {}
        value = str(token or "").strip()
        if not value:
            return {"ok": False, "code": "token_missing"}

        parts = value.split(".")
        if len(parts) != 3:
            return {"ok": False, "code": "token_malformed"}

        eh, ep, sig = parts
        expected_sig = _sign(secret, eh, ep)
        if not _safe_eq(sig, expected_sig):
            return {"ok": False, "code": "token_signature_invalid"}

        try:
            payload = json.loads(_from_b64u(ep))
        except Exception:
            return {"ok": False, "code": "token_payload_invalid"}

        now_ms = int(now())
        if not isinstance(payload.get("exp"), (int, float)) or now_ms >= int(payload["exp"]):
            return {"ok": False, "code": "token_expired", "payload": payload}
        if expd.get("scope") and payload.get("scope") != expd["scope"]:
            return {"ok": False, "code": "token_scope_mismatch", "payload": payload}
        if expd.get("runId") and payload.get("runId") != expd["runId"]:
            return {"ok": False, "code": "token_run_mismatch", "payload": payload}
        if expd.get("sessionId") and payload.get("sessionId") != expd["sessionId"]:
            return {"ok": False, "code": "token_session_mismatch", "payload": payload}
        if expd.get("toolName") and payload.get("toolName") != expd["toolName"]:
            return {"ok": False, "code": "token_tool_mismatch", "payload": payload}

        return {"ok": True, "code": "ok", "payload": payload}

    return {"mintToken": mintToken, "verifyToken": verifyToken}
