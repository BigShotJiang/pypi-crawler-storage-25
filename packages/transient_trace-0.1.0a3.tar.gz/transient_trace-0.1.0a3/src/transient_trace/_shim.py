"""
_shim.py — Universal process shim for transient-trace run.

This module is invoked by shim executables placed in PATH by `transient-trace run`.
Each shim is a tiny Python script:

    #!/usr/bin/env python3
    import sys
    sys.path.insert(0, "<sdk_path>")
    from transient_trace._shim import run_shim
    run_shim("<real_binary_path>")

When orchestrate.py calls subprocess.run(["hermes", ...]), it hits the shim
instead of the real binary. The shim:
  1. Classifies the call via sense_maker
  2. Runs PEP decision via transient-trace Client
  3. If allowed  — executes real binary, receipts the result
  4. If blocked  — exits 126 (same as connector-guard.mjs)
  5. If error    — fail-open by default (runs real binary, logs warning)

Environment variables (all set by `transient-trace run`):
  TRANSIENT_TRACE_STATE_DIR   — where receipts and DB are written
  TRANSIENT_TRACE_MODE        — strict | audit | permissive (default: audit)
  TRANSIENT_TRACE_POLICY_JSON — inline JSON policy (optional)
  TRANSIENT_TRACE_PACKAGES    — comma-separated builtin package names (optional)
  TRANSIENT_TRACE_REAL_<BIN>  — override real binary path for <BIN>
                                 e.g. TRANSIENT_TRACE_REAL_HERMES=/usr/local/bin/hermes
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

_log = logging.getLogger("transient_trace.shim")


def run_shim(real_bin: str) -> None:
    """
    Entry point called by each shim script.
    real_bin: path to the actual binary this shim shadows.
    """
    # Use argv[0] basename as the canonical binary name so the command string
    # is always "git push origin main" not "/tmp/tt-shims-xxx/git push origin main".
    # argv[0] is the shim path as the kernel executed it; its basename is the name
    # the caller used, which is what policy rules match against.
    binary_name = Path(sys.argv[0]).name if sys.argv else Path(real_bin).name
    argv = sys.argv[1:]  # args passed to the shim (same as what runtime passed)

    # Allow env override of real binary path
    env_key = f"TRANSIENT_TRACE_REAL_{binary_name.upper().replace('-', '_')}"
    real_bin = os.environ.get(env_key, real_bin)

    # The popen hook is opt-in (TRANSIENT_TRACE_HOOK=1). Shim processes do NOT
    # set this — governance for the real binary is already handled by the shim
    # itself. Child processes of the real binary should not load the hook either,
    # preventing the .pth fork bomb where every Python subprocess spawns more.
    os.environ.pop("TRANSIENT_TRACE_HOOK", None)

    try:
        _run(binary_name, real_bin, argv)
    except Exception as exc:
        import traceback as _tb
        msg = f"[transient-trace] shim error for {binary_name}: {exc}"
        _log.warning(msg)
        print(msg, file=sys.stderr)
        debug_log = os.environ.get("TRANSIENT_TRACE_DEBUG_LOG", "")
        if debug_log:
            try:
                with open(debug_log, "a") as _f:
                    _f.write(f"{msg}\n{_tb.format_exc()}\n")
            except Exception:
                pass
        # In strict mode, governance errors are treated as blocks — fail-closed.
        # In audit/permissive, fail-open so a broken shim doesn't halt the machine.
        from transient_trace._config import _read_persistent
        mode = os.environ.get("TRANSIENT_TRACE_MODE") or _read_persistent().get("mode", "audit")
        if mode == "strict":
            print(f"[transient-trace] BLOCKED: {binary_name} — governance error in strict mode", file=sys.stderr)
            sys.exit(126)
        _exec_real(real_bin, argv)


def _run(binary_name: str, real_bin: str, argv: list[str]) -> None:
    from transient_trace import Client
    from transient_trace._config import load_shim_config
    from transient_trace.sense_maker import classify_command

    cfg    = load_shim_config()
    mode   = cfg["mode"]
    client = Client(cfg)

    # Classify the call
    full_argv = [binary_name] + argv
    result = classify_command(full_argv)

    # Skip receipt for pure read operations — no governance value, reduces noise.
    # Read-only ops cannot leak data or cause side effects worth auditing.
    if result.action_class == "read":
        _exec_real(real_bin, argv)
        return

    # Interactive apps (like Claude Code CLI) require a TTY to launch their UI.
    # If stdin is a TTY and the app is interactive, pass through directly to preserve terminal.
    interactive_binaries = {"claude", "node", "python", "python3", "bash", "zsh", "sh"}
    if binary_name in interactive_binaries and sys.stdin.isatty():
        _exec_real(real_bin, argv)
        return

    target: dict = {
        "binaryPath": real_bin,
        "command":    " ".join(full_argv),
        "cwd":        os.getcwd(),
    }

    # For network commands (curl, wget, etc.), extract the destination host so
    # egress PEP rules with hosts/actionClasses filters can match correctly.
    if result.action_class == "network":
        for arg in argv:
            s = str(arg)
            if s.startswith(("http://", "https://", "ftp://")):
                try:
                    from urllib.parse import urlparse as _urlparse
                    parsed = _urlparse(s)
                    target["host"]   = parsed.netloc.lower() or parsed.path.lower()
                    target["url"]    = s
                    target["method"] = "GET"
                    target["path"]   = parsed.path or "/"
                except Exception:
                    pass
                break

    exec_input = {
        "action":       binary_name,
        "action_class": result.action_class,
        "target":       target,
        "metadata": {
            "sense_maker_method":     result.method,
            "sense_maker_confidence": result.confidence,
            "sense_maker_detail":     result.detail,
        },
    }

    def handler() -> dict:
        proc = subprocess.run(
            [real_bin] + argv,
            # stdin/stdout/stderr pass through directly — no buffering.
            # capture_output=True caused memory exhaustion for long-running
            # or streaming processes whose output is unbounded.
        )
        return {
            "exit_code":  proc.returncode,
            "stdout_len": 0,
            "stderr_len": 0,
        }

    try:
        res = client.executeActionWithReceipt(handler, exec_input)
        exit_code = (res.get("output") or {}).get("exit_code", 0)
        sys.exit(exit_code)
    except RuntimeError as e:
        # PEP blocked the action
        reason = str(e)
        print(
            f"[transient-trace] BLOCKED: {binary_name} — {reason}",
            file=sys.stderr,
        )
        sys.exit(126)


def _exec_real(real_bin: str, argv: list[str]) -> None:
    """Replace this process with the real binary (fail-open path)."""
    os.execv(real_bin, [real_bin] + argv)


# ── Shim script template ──────────────────────────────────────────────────────
# Written by `transient-trace run` into a temp shim directory.

SHIM_TEMPLATE = """\
#!{python_executable}
# transient-trace shim — {binary_name}
# Auto-generated by transient-trace run. Do not edit.
# Uses the same Python that runs the CLI so all dependencies are available
# without any sys.path manipulation.
from transient_trace._shim import run_shim
run_shim({real_bin!r})
"""


def write_shim(shim_dir: Path, binary_name: str, real_bin: str, sdk_path: str) -> Path:
    """Write a shim script for binary_name into shim_dir. Returns the shim path."""
    import sys as _sys
    shim_path = shim_dir / binary_name
    shim_path.write_text(
        SHIM_TEMPLATE.format(
            binary_name=binary_name,
            real_bin=real_bin,
            python_executable=_sys.executable,
        )
    )
    shim_path.chmod(0o755)
    return shim_path
