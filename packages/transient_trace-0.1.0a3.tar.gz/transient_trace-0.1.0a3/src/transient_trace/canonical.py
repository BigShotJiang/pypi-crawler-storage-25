from typing import Any

from ._util import canonicalize_deep


def canonicalizeDeep(obj: Any) -> Any:
    return canonicalize_deep(obj)
