import os
import random
import sys
from datetime import datetime, timezone
from typing import cast, Optional

from ..types import EnvironmentContext, FrameworkId, RuntimeId


def _fnv1a(data: str) -> str:
    h = 2166136261
    for c in data:
        h ^= ord(c)
        h = (h * 16777619) & 0xFFFFFFFF
    return f"{h:08x}"


def _generate_session_id() -> str:
    raw = "-".join([
        format(int(datetime.now(tz=timezone.utc).timestamp() * 1000), 'x'),
        format(os.getpid(), 'x'),
        os.getenv("PROCESSOR_REVISION", "cpu"),
        ''.join(random.choice('abcdefghijklmnopqrstuvwxyz0123456789') for _ in range(5)),
    ])
    return f"sess_{_fnv1a(raw)[:12]}"


def _generate_run_id() -> str:
    raw = "-".join([
        format(int(datetime.now(tz=timezone.utc).timestamp() * 1000), 'x'),
        ''.join(random.choice('abcdefghijklmnopqrstuvwxyz0123456789') for _ in range(5)),
        os.getenv("npm_config_user_agent", "ua"),
    ])
    return f"run_{_fnv1a(raw)[:10]}"


def _detect_framework() -> str:
    if os.getenv("CLAUDE_AGENT_TYPE"):
        return "claude-code"
    if os.getenv("OPENAI_API_TYPE"):
        return "openai-codex"
    if os.getenv("HERMES_PROFILE"):
        return "hermes"
    ua = os.getenv("npm_config_user_agent", "")
    if "claude" in ua:
        return "claude-code"
    if "opencode" in ua:
        return "opencode"
    if "codex" in ua:
        return "openai-codex"
    args = " ".join(sys.argv).lower()
    if "claude" in args:
        return "claude-code"
    if "opencode" in args:
        return "opencode"
    if "codex" in args:
        return "openai-codex"
    if "hermes" in args:
        return "hermes"
    return "unknown"


def _detect_runtime() -> str:
    return "python"


def _detect_containerized() -> bool:
    if os.getenv("DOCKER_CONTAINER") or os.getenv("container") or os.getenv("KUBERNETES_SERVICE_HOST") or os.getenv("DYNO"):
        return True
    return os.path.exists('/.dockerenv')


def detectEnvironment(agentId: Optional[str] = None) -> EnvironmentContext:
    framework = cast(FrameworkId, _detect_framework())
    runtime = cast(RuntimeId, _detect_runtime())
    resolved_agent = agentId or os.getenv("ATP_AGENT_ID") or os.getenv("HERMES_PROFILE") or os.getenv("npm_package_name") or f"agent:{framework}"
    return {
        "framework": framework,
        "runtime": runtime,
        "sessionId": _generate_session_id(),
        "runId": _generate_run_id(),
        "agentId": resolved_agent,
        "sessionStartedAt": datetime.now(tz=timezone.utc).isoformat().replace('+00:00', 'Z'),
        "sdkVersion": "0.1.0-phase1",
        "containerized": _detect_containerized(),
    }
