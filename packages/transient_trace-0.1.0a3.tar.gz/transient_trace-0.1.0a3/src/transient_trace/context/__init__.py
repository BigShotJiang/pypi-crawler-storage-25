from .ContextAwareness import detectEnvironment
