"""
cli.py — transient-trace command line interface.

Commands:
  transient-trace run <cmd> [args...]   — run any command with governance
  transient-trace receipts list         — list recent receipts (human-readable)
  transient-trace receipts show <id>    — show a single receipt
  transient-trace explain               — audit report from state dir
  transient-trace query                 — query receipts (engine)
  transient-trace export                — export tamper-evident bundle
  transient-trace config                — show / set persistent config

USAGE EXAMPLES:
  # Wrap the transient-swarm
  transient-trace run python orchestrate.py --component mock-atp

  # Wrap any command
  transient-trace run bash deploy.sh

  # With options
  transient-trace --mode strict --state-dir ~/transient-audit \\
      run python orchestrate.py

  # Review what happened
  transient-trace receipts list
  transient-trace receipts list --outcome deny --limit 50
  transient-trace explain
  transient-trace export --out ./bundle.json

  # Set state-dir once so you never need --state-dir again
  transient-trace config set state_dir ~/my-audit
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


# ── Persistent config ─────────────────────────────────────────────────────────
# Stored at ~/.config/transient-trace/config.json (XDG-style).
# Values here are the lowest-precedence defaults; env vars and CLI flags win.

_CONFIG_PATH = Path.home() / ".config" / "transient-trace" / "config.json"


def _load_config() -> dict:
    """Load persistent config from ~/.config/transient-trace/config.json."""
    try:
        if _CONFIG_PATH.exists():
            return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save_config(cfg: dict) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")


# ── Timestamp utilities ───────────────────────────────────────────────────────

def _parse_ts_arg(s: str) -> float:
    """
    Parse a user-supplied timestamp into a unix float.

    Accepted formats:
      2026-04-13              date only (interpreted as midnight UTC)
      2026-04-13T09:00        ISO datetime (local tz assumed if no tz info)
      2026-04-13 09:00:00     same with space separator
      1h  30m  7d             relative: N hours/minutes/days ago
    """
    import re
    from datetime import datetime, timezone, timedelta

    s = s.strip()

    # Relative shorthand: 1h, 30m, 7d
    m = re.fullmatch(r"(\d+)([hmd])", s, re.IGNORECASE)
    if m:
        n, unit = int(m.group(1)), m.group(2).lower()
        delta = {"h": timedelta(hours=n), "m": timedelta(minutes=n), "d": timedelta(days=n)}[unit]
        return (datetime.now(tz=timezone.utc) - delta).timestamp()

    # ISO date or datetime
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(s, fmt)
            # Assume UTC if no tz info
            return dt.replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue

    # Try fromisoformat (handles +00:00 / Z)
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except Exception:
        raise ValueError(
            f"Cannot parse timestamp '{s}'. "
            "Use ISO date (2026-04-13), datetime (2026-04-13T09:00), "
            "or relative (1h, 30m, 7d)."
        )


def _parse_receipt_ts(receipt_dict: dict) -> float:
    """Extract unix timestamp from a receipt JSON wrapper dict."""
    from datetime import datetime, timezone
    r = receipt_dict.get("receipt", {})
    ts_str = r.get("captured_at") or r.get("sealed_at") or receipt_dict.get("created_at")
    if not ts_str:
        return 0.0
    try:
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


# ── Signature verification ────────────────────────────────────────────────────

def _load_session_key_cache(state_dir: Path) -> dict[str, bytes]:
    """
    Build a {kid: public_key_bytes} cache for receipt signature verification.

    Reads from the sessions table in receipt_engine.db first (fast, indexed).
    Falls back to scanning legacy session-*.json files if the DB has no rows —
    covers installs that haven't run the migration yet.

    kid format: "sess_{id}:1"
    """
    db_path = state_dir / "receipt_engine.db"
    if db_path.exists():
        try:
            from transient_trace.receipt_engine.store import ReceiptStore
            _s = ReceiptStore(db_path)
            keys = _s.get_session_keys()
            _s.close()
            if keys:
                return keys
        except Exception:
            pass

    # Legacy fallback: scan sessions/*.json
    cache: dict[str, bytes] = {}
    sessions_dir = state_dir / "sessions"
    if not sessions_dir.exists():
        return cache
    for f in sessions_dir.glob("session-*.json"):
        try:
            data   = json.loads(f.read_text(encoding="utf-8"))
            r      = data.get("receipt", {})
            pk_hex = r.get("signingPublicKey")
            sid    = r.get("environment", {}).get("sessionId")
            if pk_hex and sid:
                cache[f"{sid}:1"] = bytes.fromhex(pk_hex)
        except Exception:
            continue
    return cache


def _verify_receipt(receipt_dict: dict, key_cache: dict[str, bytes]) -> str:
    """
    Verify the Ed25519 signature on a receipt.

    Returns:
      "✓"  — signature valid
      "✗"  — signature INVALID (tampered or corrupted)
      "?"  — cannot verify (session key not in cache, or non-standard receipt)
    """
    from transient_trace.atp.validator import verifyActionReceipt

    r   = receipt_dict.get("receipt", receipt_dict)
    sig = r.get("signature", {})

    # governance-deny-event receipts are intentionally unsigned
    if r.get("receipt_type") == "governance-deny-event" or sig.get("alg") == "none":
        return "?"

    kid = sig.get("kid")
    if not kid or kid not in key_cache:
        return "?"

    try:
        ok = verifyActionReceipt(r, key_cache[kid])
        return "✓" if ok else "✗"
    except Exception:
        return "✗"


# ── Binaries to shim by default ───────────────────────────────────────────────
# Maps binary name → where to find the real binary.
# Extended at runtime if TRANSIENT_TRACE_SHIM_BINS env var is set.

_DEFAULT_SHIM_TARGETS = {
    "git":    shutil.which("git") or "git",
    "curl":   shutil.which("curl") or "curl",
    # Package managers — intercepted to enforce governance self-protection rules.
    # An agent cannot uninstall transient-trace while governance is active.
    "pip":    shutil.which("pip") or shutil.which("pip3") or "pip",
    "pip3":   shutil.which("pip3") or "pip3",
    "uv":     shutil.which("uv") or "uv",
    # Privilege escalation — shimmed so the privilege package can intercept
    # sudo/su calls at the PATH level in addition to the Popen hook.
    "sudo":   shutil.which("sudo") or "sudo",
    "su":     shutil.which("su") or "su",
}


def main(argv: list[str] | None = None) -> None:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(0)

    args.func(args)


def _build_parser() -> argparse.ArgumentParser:
    _cfg = _load_config()
    _default_state_dir = (
        os.environ.get("TRANSIENT_TRACE_STATE_DIR")
        or _cfg.get("state_dir")
        or str(Path.home() / "transient-audit")
    )
    _default_mode = (
        os.environ.get("TRANSIENT_TRACE_MODE")
        or _cfg.get("mode")
        or "audit"
    )

    p = argparse.ArgumentParser(
        prog="transient-trace",
        description="Zero-touch governance for any agent runtime.",
    )
    p.add_argument(
        "--mode",
        choices=["strict", "audit", "permissive"],
        default=_default_mode,
        help=f"Governance mode (default: {_default_mode})",
    )
    p.add_argument(
        "--state-dir",
        default=_default_state_dir,
        help=f"Where receipts and DB are stored (default: {_default_state_dir})",
    )
    _default_packages = (
        os.environ.get("TRANSIENT_TRACE_PACKAGES")
        or _cfg.get("packages")
        or ""
    )
    p.add_argument(
        "--packages",
        default=_default_packages,
        help=f"Comma-separated built-in governance package names (default: {_default_packages or 'none'})",
    )
    p.add_argument(
        "--policy",
        default="",
        help="Inline JSON governance policy (overrides default allow-all)",
    )

    sub = p.add_subparsers(title="commands")

    # ── run ───────────────────────────────────────────────────────────────────
    run_p = sub.add_parser("run", help="Run a command under governance")
    run_p.add_argument("command", nargs=argparse.REMAINDER,
                       help="Command and arguments to run")
    run_p.add_argument(
        "--shim", action="append", default=[],
        metavar="NAME:PATH",
        help="Additional binary to shim (e.g. --shim mybin:/usr/bin/mybin)",
    )
    run_p.add_argument(
        "--learning", action="store_true", default=False,
        help="Enable the self-learning receipt engine (opt-in)",
    )
    run_p.set_defaults(func=cmd_run)

    # ── receipts ──────────────────────────────────────────────────────────────
    rec_p = sub.add_parser("receipts", help="Browse and inspect receipts")
    rec_sub = rec_p.add_subparsers(title="receipts commands")

    rec_list_p = rec_sub.add_parser("list", help="List recent receipts")
    rec_list_p.add_argument("--outcome", default=None, choices=["allow", "deny"])
    rec_list_p.add_argument("--action-class", default=None)
    rec_list_p.add_argument("--run-id", default=None, help="Filter by run ID")
    rec_list_p.add_argument("--since", default=None,
                            metavar="WHEN",
                            help="Show receipts after this time. Accepts ISO datetime "
                                 "(2026-04-13T09:00), date (2026-04-13), or relative (1h, 30m, 7d)")
    rec_list_p.add_argument("--until", default=None, metavar="WHEN",
                            help="Show receipts before this time (same formats as --since)")
    rec_list_p.add_argument("--limit", type=int, default=100)
    rec_list_p.add_argument("--json", action="store_true", dest="as_json")
    rec_list_p.set_defaults(func=cmd_receipts_list)

    rec_show_p = rec_sub.add_parser("show", help="Show a single receipt by ID")
    rec_show_p.add_argument("receipt_id", help="Receipt ID (TR-... or partial prefix)")
    rec_show_p.set_defaults(func=cmd_receipts_show)

    rec_sum_p = rec_sub.add_parser("summary", help="Quick stats from JSON receipt files")
    rec_sum_p.add_argument("--since", default=None, metavar="WHEN")
    rec_sum_p.add_argument("--until", default=None, metavar="WHEN")
    rec_sum_p.add_argument("--run-id", default=None,
                           help="Scope summary to a single run (use $TRANSIENT_TRACE_RUN_ID)")
    rec_sum_p.add_argument("--json", action="store_true", dest="as_json")
    rec_sum_p.set_defaults(func=cmd_receipts_summary)

    rec_idx_p = rec_sub.add_parser("index", help="Sync JSON receipt files into the engine DB")
    rec_idx_p.set_defaults(func=cmd_receipts_index)

    rec_compact_p = rec_sub.add_parser(
        "compact",
        help="Delete legacy JSON receipt/session files after confirming they are in the DB",
    )
    rec_compact_p.add_argument(
        "--yes", action="store_true",
        help="Skip confirmation prompt",
    )
    rec_compact_p.set_defaults(func=cmd_receipts_compact)

    rec_learn_p = rec_sub.add_parser("learning", help="Show self-learning engine status")
    rec_learn_p.set_defaults(func=cmd_receipts_learning)

    rec_p.set_defaults(func=lambda a: (rec_p.print_help(), sys.exit(0)))

    # ── explain ───────────────────────────────────────────────────────────────
    exp_p = sub.add_parser("explain", help="Print audit report from state dir")
    exp_p.add_argument("--action-class", default=None)
    exp_p.add_argument("--json", action="store_true", dest="as_json")
    exp_p.set_defaults(func=cmd_explain)

    # ── query ─────────────────────────────────────────────────────────────────
    qry_p = sub.add_parser("query", help="Query receipts (engine DB)")
    qry_p.add_argument("--outcome", default=None, choices=["allow", "deny"])
    qry_p.add_argument("--action-class", default=None)
    qry_p.add_argument("--limit", type=int, default=20)
    qry_p.set_defaults(func=cmd_query)

    # ── export ────────────────────────────────────────────────────────────────
    exp2_p = sub.add_parser("export", help="Export tamper-evident audit bundle")
    exp2_p.add_argument("--out", default="./trace-bundle.json")
    exp2_p.set_defaults(func=cmd_export)

    # ── config ────────────────────────────────────────────────────────────────
    cfg_p = sub.add_parser("config", help="Show or set persistent configuration")
    cfg_sub = cfg_p.add_subparsers(title="config commands")

    cfg_show_p = cfg_sub.add_parser("show", help="Print current config")
    cfg_show_p.set_defaults(func=cmd_config_show)

    cfg_set_p = cfg_sub.add_parser("set", help="Set a config value (key value)")
    cfg_set_p.add_argument("key", help="Config key (e.g. state_dir, mode)")
    cfg_set_p.add_argument("value", help="Value to set")
    cfg_set_p.set_defaults(func=cmd_config_set)

    cfg_p.set_defaults(func=lambda a: (cfg_p.print_help(), sys.exit(0)))

    # ── uninstall ─────────────────────────────────────────────────────────────
    uninstall_p = sub.add_parser(
        "uninstall",
        help="Cleanly remove all shims, PATH entry, and Popen hook",
    )
    uninstall_p.add_argument(
        "--purge-data", action="store_true", default=False,
        help="Also remove config and receipt store (irreversible)",
    )
    uninstall_p.set_defaults(func=cmd_uninstall)

    # ── wrap ──────────────────────────────────────────────────────────────────
    wrap_p = sub.add_parser(
        "wrap",
        help="Install/manage persistent governance wrappers for binaries",
    )
    wrap_sub = wrap_p.add_subparsers(title="wrap commands")

    wrap_install_p = wrap_sub.add_parser(
        "install",
        help="Install a governance shim for a binary (e.g. claude)",
    )
    wrap_install_p.add_argument("binary", nargs="+", help="Binary name(s) to wrap (e.g. claude git curl)")
    wrap_install_p.add_argument(
        "--real", default=None,
        metavar="PATH",
        help="Path to real binary (auto-detected if omitted)",
    )
    wrap_install_p.add_argument(
        "--auto-rc", action="store_true", default=False,
        help="Automatically add shims dir to shell RC file (~/.zshrc or ~/.bashrc)",
    )
    wrap_install_p.add_argument(
        "--lock", action="store_true", default=False,
        help="Set OS-level immutability on the shim file (chflags uchg / chattr +i). "
             "Prevents direct file deletion even outside governance. "
             "Use 'wrap uninstall' to remove — it clears the flag automatically.",
    )
    wrap_install_p.set_defaults(func=cmd_wrap_install)

    wrap_uninstall_p = wrap_sub.add_parser(
        "uninstall",
        help="Remove a governance shim",
    )
    wrap_uninstall_p.add_argument("binary", help="Binary name to unwrap")
    wrap_uninstall_p.set_defaults(func=cmd_wrap_uninstall)

    wrap_status_p = wrap_sub.add_parser(
        "status",
        help="Show wrap status for all managed binaries",
    )
    wrap_status_p.set_defaults(func=cmd_wrap_status)

    hook_p = wrap_sub.add_parser(
        "install-hook",
        help="Install permanent Popen hook so absolute-path subprocess calls are governed",
    )
    hook_p.add_argument(
        "--uninstall", action="store_true", default=False,
        help="Remove the hook instead of installing it",
    )
    hook_p.set_defaults(func=cmd_wrap_install_hook)

    wrap_p.set_defaults(func=lambda a: (wrap_p.print_help(), sys.exit(0)))

    # ── policy ────────────────────────────────────────────────────────────────
    pol_p = sub.add_parser(
        "policy",
        help="Manage persistent governance policy for permanent shims",
    )
    pol_sub = pol_p.add_subparsers(title="policy commands")

    pol_show_p = pol_sub.add_parser("show", help="Show current persistent policy")
    pol_show_p.set_defaults(func=cmd_policy_show)

    pol_mode_p = pol_sub.add_parser("set-mode", help="Set governance mode (audit|strict|permissive)")
    pol_mode_p.add_argument("mode", choices=["audit", "strict", "permissive"])
    pol_mode_p.set_defaults(func=cmd_policy_set_mode)

    pol_default_p = pol_sub.add_parser("set-default", help="Set default action (allow|deny)")
    pol_default_p.add_argument("action", choices=["allow", "deny"])
    pol_default_p.set_defaults(func=cmd_policy_set_default)

    pol_rule_p = pol_sub.add_parser(
        "add-rule",
        help="Add a rule (e.g. --action git --action-class exec --decision deny)",
    )
    pol_rule_p.add_argument("--action",       default=None, help="Binary name to match (e.g. git)")
    pol_rule_p.add_argument("--action-class", default=None, dest="action_class",
                            help="Action class to match (exec|write_low|network|delete|secrets)")
    pol_rule_p.add_argument("--decision",     required=True, choices=["allow", "deny"])
    pol_rule_p.add_argument("--reason",       default="", help="Human-readable reason")
    pol_rule_p.set_defaults(func=cmd_policy_add_rule)

    pol_clear_p = pol_sub.add_parser("clear-rules", help="Remove all rules (keep mode and default)")
    pol_clear_p.set_defaults(func=cmd_policy_clear_rules)

    pol_lock_p = pol_sub.add_parser(
        "lock",
        help="Set OS-level immutability on the config file so agents cannot modify it",
    )
    pol_lock_p.set_defaults(func=cmd_policy_lock)

    pol_unlock_p = pol_sub.add_parser("unlock", help="Remove immutability from the config file")
    pol_unlock_p.set_defaults(func=cmd_policy_unlock)

    pol_p.set_defaults(func=lambda a: (pol_p.print_help(), sys.exit(0)))

    return p


# ── run ───────────────────────────────────────────────────────────────────────

def cmd_run(args: argparse.Namespace) -> None:
    command = args.command
    # Strip leading '--' separator if present
    if command and command[0] == "--":
        command = command[1:]

    if not command:
        print("transient-trace run: no command specified", file=sys.stderr)
        sys.exit(1)

    state_dir = Path(args.state_dir)
    state_dir.mkdir(parents=True, exist_ok=True)

    # Find SDK source path for shim scripts
    sdk_path = str(Path(__file__).parent.parent)

    # Build shim targets — defaults + any --shim overrides
    shim_targets = dict(_DEFAULT_SHIM_TARGETS)
    for spec in (args.shim or []):
        if ":" in spec:
            name, path = spec.split(":", 1)
            shim_targets[name.strip()] = path.strip()

    # Additional shims from env
    extra = os.environ.get("TRANSIENT_TRACE_SHIM_BINS", "")
    for spec in extra.split(","):
        spec = spec.strip()
        if ":" in spec:
            name, path = spec.split(":", 1)
            shim_targets[name.strip()] = path.strip()

    with tempfile.TemporaryDirectory(prefix="tt-shims-") as shim_dir:
        shim_dir_path = Path(shim_dir)
        _write_shims(shim_dir_path, shim_targets, sdk_path)
        _write_sitecustomize(shim_dir_path, sdk_path)

        # Build child environment
        env = os.environ.copy()
        env["PATH"] = f"{shim_dir}:{env.get('PATH', '')}"
        env["TRANSIENT_TRACE_STATE_DIR"]  = str(state_dir)
        env["TRANSIENT_TRACE_MODE"]       = args.mode
        env["TRANSIENT_TRACE_PACKAGES"]   = args.packages or ""
        if args.policy:
            env["TRANSIENT_TRACE_POLICY_JSON"] = args.policy
        if args.learning:
            env["TRANSIENT_TRACE_LEARNING"] = "1"
        else:
            # Ensure a parent env's learning flag doesn't leak into child runs
            env.pop("TRANSIENT_TRACE_LEARNING", None)

        # Inject Popen hook for Python runtimes (catches absolute-path calls)
        # sitecustomize.py in shim_dir is auto-imported by any Python subprocess
        existing_pypath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = f"{shim_dir}:{existing_pypath}" if existing_pypath else shim_dir
        # Tell the hook which binary names to intercept
        env["TRANSIENT_TRACE_SHIM_TARGETS"] = ",".join(shim_targets.keys())

        # Causal threading — if we're already inside a governed process, promote
        # the current run ID to parent so child receipts carry the lineage.
        import secrets
        run_id = f"run_{secrets.token_hex(4)}"
        if "TRANSIENT_TRACE_RUN_ID" in env:
            env["TRANSIENT_TRACE_PARENT_RUN_ID"] = env["TRANSIENT_TRACE_RUN_ID"]
        env["TRANSIENT_TRACE_RUN_ID"] = run_id

        # Pass real binary paths so shims can find them
        for name, real_path in shim_targets.items():
            env_key = f"TRANSIENT_TRACE_REAL_{name.upper().replace('-', '_')}"
            env[env_key] = real_path

        print(
            f"[transient-trace] activated — mode={args.mode} "
            f"state={state_dir} shims={list(shim_targets.keys())}",
            file=sys.stderr,
        )

        # If the command starts with an absolute path (e.g. /usr/bin/git),
        # rewrite it to use just the binary name so it routes through the
        # temp shim and gets a receipt written. Without this, absolute-path
        # invocations bypass all shims and no receipt is written.
        run_command = list(command)
        if run_command and os.path.isabs(run_command[0]):
            binary_name = Path(run_command[0]).name
            if binary_name in shim_targets:
                run_command = [binary_name] + run_command[1:]

        result = subprocess.run(run_command, env=env)
        sys.exit(result.returncode)


def _write_shims(
    shim_dir: Path,
    targets: dict[str, str],
    sdk_path: str,
) -> None:
    from transient_trace._shim import write_shim

    # Build a PATH that excludes ALL shim directories so shutil.which resolves
    # to the real system binary, not a governance shim wrapping another shim.
    # Without this, "git" resolves to ~/.transient-trace/shims/git (the persistent
    # shim), producing a double-governance chain and corrupting the command string.
    shim_dirs_to_skip = {str(shim_dir), str(_SHIMS_DIR)}
    clean_path = ":".join(
        d for d in os.environ.get("PATH", "").split(":")
        if d not in shim_dirs_to_skip
    )

    for binary_name, real_bin in targets.items():
        # Resolve against clean PATH so we always wrap the real binary
        real_resolved = shutil.which(real_bin, path=clean_path) or real_bin
        write_shim(shim_dir, binary_name, real_resolved, sdk_path)


# Template for the sitecustomize.py injected via PYTHONPATH.
# Python auto-imports sitecustomize.py at startup (before any user code),
# so this fires even when the runtime calls binaries by absolute path.
_SITECUSTOMIZE_TEMPLATE = """\
# transient-trace sitecustomize — auto-generated, do not edit.
import sys
sys.path.insert(0, {sdk_src_path!r})
try:
    from transient_trace._popen_hook import install_hook
    install_hook()
except Exception as _exc:
    import warnings
    warnings.warn(f"[transient-trace] popen hook failed to install: {{_exc}}")
"""


def _write_sitecustomize(shim_dir: Path, sdk_path: str) -> Path:
    """Write sitecustomize.py into shim_dir so it's auto-imported by Python subprocesses."""
    # sdk_path = .../transient-trace-py/src  (two levels up from cli.py)
    # That's already the importable root — `import transient_trace` works directly.
    sc_path = shim_dir / "sitecustomize.py"
    sc_path.write_text(_SITECUSTOMIZE_TEMPLATE.format(sdk_src_path=sdk_path))
    return sc_path


# ── receipts ──────────────────────────────────────────────────────────────────

def _load_receipt_files(
    state_dir: Path,
    limit: int,
    outcome: str | None = None,
    action_class: str | None = None,
    run_id: str | None = None,
    since_ts: float | None = None,
    until_ts: float | None = None,
) -> list[dict]:
    """
    Load receipts for CLI display, DB-first with JSON fallback.

    Primary path: query receipt_engine.db via ReceiptStore.query_for_cli().
    Fallback: scan legacy receipts/*.json files (covers pre-migration installs).
    """
    # ── DB path (primary) ────────────────────────────────────────────────────
    db_path = state_dir / "receipt_engine.db"
    if db_path.exists():
        try:
            from transient_trace.receipt_engine.store import ReceiptStore
            _s = ReceiptStore(db_path)
            results = _s.query_for_cli(
                outcome=outcome,
                action_class=action_class,
                run_id=run_id,
                from_ts=since_ts,
                to_ts=until_ts,
                limit=limit,
            )
            _s.close()
            if results:
                return results
        except Exception:
            pass  # fall through to legacy scan

    # ── Legacy JSON fallback ─────────────────────────────────────────────────
    receipts_dir = state_dir / "receipts"
    if not receipts_dir.exists():
        return []

    files = sorted(receipts_dir.glob("TR-*.json"),
                   key=lambda p: p.stat().st_mtime, reverse=True)

    results = []
    for f in files:
        if len(results) >= limit:
            break
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue

        intent   = data.get("intent", {})
        decision = data.get("decision", {})
        ctx      = intent.get("context", {})

        if outcome and decision.get("outcome") != outcome:
            continue
        if action_class and intent.get("action_class") != action_class:
            continue
        if run_id and ctx.get("runId") != run_id and ctx.get("parentRunId") != run_id:
            continue

        if since_ts is not None or until_ts is not None:
            ts = _parse_receipt_ts(data)
            if since_ts is not None and ts < since_ts:
                continue
            if until_ts is not None and ts > until_ts:
                continue

        results.append(data)

    return results


def cmd_receipts_list(args: argparse.Namespace) -> None:
    state_dir = Path(args.state_dir)

    since_ts = until_ts = None
    try:
        if getattr(args, "since", None):
            since_ts = _parse_ts_arg(args.since)
        if getattr(args, "until", None):
            until_ts = _parse_ts_arg(args.until)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    items = _load_receipt_files(
        state_dir,
        limit=args.limit,
        outcome=args.outcome,
        action_class=getattr(args, "action_class", None),
        run_id=getattr(args, "run_id", None),
        since_ts=since_ts,
        until_ts=until_ts,
    )

    receipts_dir = state_dir / "receipts"
    if not receipts_dir.exists():
        print(f"No receipts directory found at {receipts_dir}")
        print("  Run an agent with: transient-trace run <command>")
        return
    if not items:
        print("No receipts match the given filters.")
        return

    if args.as_json:
        print(json.dumps(items, indent=2))
        return

    # Verify signatures — build session key cache once for all receipts
    key_cache = _load_session_key_cache(state_dir)

    # Human-readable table
    col = {"time": 19, "action": 22, "class": 13, "outcome": 8, "run": 14, "rule": 0}
    hdr = f"  {'Time':{col['time']}}  {'Action':{col['action']}}  {'Class':{col['class']}}  {'Outcome':{col['outcome']}}  {'Run ID':{col['run']}}  Rule"
    print(hdr)
    print("─" * (len(hdr) + 10))

    tampered = 0
    for item in items:
        receipt  = item.get("receipt", {})
        intent   = item.get("intent", {})
        decision = item.get("decision", {})
        ctx      = intent.get("context", {})

        sig_status  = _verify_receipt(item, key_cache)
        ts          = (receipt.get("captured_at") or item.get("created_at") or "?")[:19].replace("T", " ")
        action      = str(intent.get("action") or "?")[:col["action"]]
        ac          = str(intent.get("action_class") or "?")[:col["class"]]
        out         = str(decision.get("outcome") or "?")[:col["outcome"]]
        run         = str(ctx.get("runId") or "?")[:col["run"]]
        rule        = str(decision.get("matched_rule_id") or decision.get("reason_code") or "-")

        if sig_status == "✗":
            tampered += 1

        print(f"{sig_status} {ts:{col['time']}}  {action:{col['action']}}  {ac:{col['class']}}  {out:{col['outcome']}}  {run:{col['run']}}  {rule}")

    footer = f"\n{len(items)} receipt(s) — state dir: {state_dir}"
    if tampered:
        footer += f"\n⚠  {tampered} receipt(s) failed signature verification — possible tampering"
    print(footer)


def cmd_receipts_show(args: argparse.Namespace) -> None:
    state_dir    = Path(args.state_dir)
    receipts_dir = state_dir / "receipts"
    rid          = args.receipt_id.strip()

    content = None

    # ── DB path (primary) ────────────────────────────────────────────────────
    db_path = state_dir / "receipt_engine.db"
    if db_path.exists():
        try:
            from transient_trace.receipt_engine.store import ReceiptStore
            _s = ReceiptStore(db_path)
            payload = _s.get_payload(rid) or _s.get_payload_prefix(rid)
            _s.close()
            if payload:
                # Wrap in display envelope consistent with legacy JSON format
                content = json.dumps({"type": "SignedActionReceipt", "receipt": json.loads(payload)}, indent=2)
        except Exception:
            pass

    # ── Legacy JSON fallback ─────────────────────────────────────────────────
    if content is None:
        exact = receipts_dir / f"{rid}.json"
        if exact.exists():
            content = exact.read_text(encoding="utf-8")
        else:
            matches = list(receipts_dir.glob(f"{rid}*.json")) if receipts_dir.exists() else []
            if not matches:
                print(f"Receipt '{rid}' not found", file=sys.stderr)
                sys.exit(1)
            if len(matches) > 1:
                print(f"Ambiguous prefix '{rid}' — matches:", file=sys.stderr)
                for m in matches[:10]:
                    print(f"  {m.name}", file=sys.stderr)
                sys.exit(1)
            content = matches[0].read_text(encoding="utf-8")

    print(content)

    # Always verify signature and report status
    try:
        data      = json.loads(content)
        key_cache = _load_session_key_cache(state_dir)
        status    = _verify_receipt(data, key_cache)
        labels    = {"✓": "Signature valid", "✗": "SIGNATURE INVALID — receipt may be tampered", "?": "Signature unverifiable (session key not found)"}
        print(f"\n[transient-trace] {labels[status]}", file=sys.stderr)
    except Exception:
        pass


def cmd_receipts_summary(args: argparse.Namespace) -> None:
    """Quick stats computed from JSON files — no engine needed."""
    state_dir = Path(args.state_dir)
    run_id    = getattr(args, "run_id", None)

    since_ts = until_ts = None
    try:
        if getattr(args, "since", None):
            since_ts = _parse_ts_arg(args.since)
        if getattr(args, "until", None):
            until_ts = _parse_ts_arg(args.until)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    items = _load_receipt_files(state_dir, limit=10_000,
                                run_id=run_id,
                                since_ts=since_ts, until_ts=until_ts)

    receipts_dir = state_dir / "receipts"
    if not receipts_dir.exists() or not items:
        label = f"run {run_id}" if run_id else str(receipts_dir)
        print(f"No receipts found for {label}")
        return

    from collections import Counter
    outcomes       = Counter()
    action_classes = Counter()
    actions        = Counter()
    run_ids        = set()
    rule_ids       = Counter()
    timestamps     = []
    denied_actions = []   # full detail for agent self-check

    for item in items:
        intent   = item.get("intent", {})
        decision = item.get("decision", {})
        ctx      = intent.get("context", {})
        receipt  = item.get("receipt", {})

        outcome = decision.get("outcome", "unknown")
        outcomes[outcome] += 1
        action_classes[intent.get("action_class", "unknown")] += 1
        actions[intent.get("action", "unknown")] += 1
        if ctx.get("runId"):
            run_ids.add(ctx["runId"])
        if decision.get("matched_rule_id"):
            rule_ids[decision["matched_rule_id"]] += 1
        ts = _parse_receipt_ts(item)
        if ts:
            timestamps.append(ts)

        if outcome == "deny":
            denied_actions.append({
                "receipt_id":   receipt.get("receipt_id"),
                "action":       intent.get("action"),
                "action_class": intent.get("action_class"),
                "rule_id":      decision.get("matched_rule_id"),
                "reason":       decision.get("reason_code"),
                "ts":           _fmt_ts(ts) if ts else None,
            })

    total      = len(items)
    deny_count = outcomes.get("deny", 0)
    deny_rate  = deny_count / total if total else 0.0

    if args.as_json:
        print(json.dumps({
            "run_id":         run_id,
            "total":          total,
            "outcomes":       dict(outcomes),
            "deny_rate":      round(deny_rate, 4),
            "action_classes": dict(action_classes),
            "top_actions":    dict(actions.most_common(10)),
            "runs":           sorted(run_ids),
            "top_rules":      dict(rule_ids.most_common(5)),
            "denied_actions": denied_actions,
            "from":           _fmt_ts(min(timestamps)) if timestamps else None,
            "to":             _fmt_ts(max(timestamps)) if timestamps else None,
        }, indent=2))
        return

    w = "─" * 56
    print(f"\n{w}")
    print(f"  Transient Trace — Receipt Summary")
    if run_id:
        print(f"  Run       : {run_id}")
    else:
        print(f"  State dir : {state_dir}")
    if timestamps:
        print(f"  Window    : {_fmt_ts(min(timestamps))}  →  {_fmt_ts(max(timestamps))}")
    print(w)
    print(f"  Total receipts : {total}")
    if not run_id:
        print(f"  Runs captured  : {len(run_ids)}")
    print(f"  Deny rate      : {deny_rate:.1%}  ({deny_count} denied)")
    print(f"\n  Outcomes:")
    for k, v in sorted(outcomes.items(), key=lambda x: -x[1]):
        bar = "█" * min(v, 30)
        print(f"    {k:<10} {v:>5}  {bar}")
    print(f"\n  Top action classes:")
    for k, v in action_classes.most_common(6):
        print(f"    {k:<20} {v:>5}")
    print(f"\n  Top actions:")
    for k, v in actions.most_common(8):
        print(f"    {k:<24} {v:>5}")
    if rule_ids:
        print(f"\n  Top rules fired:")
        for k, v in rule_ids.most_common(5):
            print(f"    {k:<40} ×{v}")
    if denied_actions:
        print(f"\n  Denied actions ({len(denied_actions)}):")
        for d in denied_actions[:10]:
            print(f"    {d['ts']}  {d['action']:<20}  [{d['rule_id'] or d['reason']}]")
    print()


def _fmt_ts(ts: float) -> str:
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def cmd_receipts_learning(args: argparse.Namespace) -> None:
    """Show self-learning engine status — receipt counts, patterns, promoted rules."""
    from transient_trace.receipt_engine import ReceiptEngine

    state_dir = Path(args.state_dir)
    db_path   = state_dir / "receipt_engine.db"

    if not db_path.exists():
        print("\n  Learning engine not yet initialised.")
        print("  Run with learning enabled:")
        print("    transient-trace run --learning <command>")
        print("  Or add to persistent config:")
        print('    transient-trace config set learning \'{"enabled": true}\'')
        print()
        return

    engine = ReceiptEngine(db_path=db_path)
    s = engine.stats()
    promoted = s.get("promoted_list", [])

    print()
    print("  Transient Trace — Learning Engine Status")
    print(f"  DB: {db_path}")
    print()
    print(f"  Receipts indexed   : {s['total_receipts']}")
    print(f"  Patterns distilled : {s['patterns']}")
    print(f"  Rules promoted     : {s['promoted_rules']}")

    if promoted:
        print()
        print("  Promoted rules:")
        for rule_id in promoted:
            print(f"    ◆ {rule_id}")
    elif s['total_receipts'] > 0:
        trigger = 50  # default promote_min_count
        remaining = max(0, trigger - s['total_receipts'])
        if remaining > 0:
            print(f"\n  Next promotion threshold: {trigger} receipts at 95% confidence")
            print(f"  ({remaining} more receipts needed to be eligible)")
        else:
            print(f"\n  No patterns have reached promotion threshold yet")
            print(f"  (need 95% confidence across {trigger}+ consistent observations)")
    print()


def cmd_receipts_index(args: argparse.Namespace) -> None:
    """Sync JSON receipt and session files into the engine DB (backfill)."""
    from transient_trace.receipt_engine import ReceiptEngine

    state_dir    = Path(args.state_dir)
    receipts_dir = state_dir / "receipts"
    sessions_dir = state_dir / "sessions"
    db_path      = state_dir / "receipt_engine.db"

    engine = ReceiptEngine(db_path=db_path)
    counts = engine.migrate_legacy_json(state_dir)

    json_count = len(list(receipts_dir.glob("TR-*.json"))) if receipts_dir.exists() else 0
    sess_count = sum(1 for _ in sessions_dir.glob("session-*.json")) if sessions_dir.exists() else 0

    print(f"[transient-trace] legacy migration → {db_path}")
    print(f"  JSON receipts found : {json_count}  newly indexed: {counts['receipts']}")
    print(f"  JSON sessions found : {sess_count}  newly indexed: {counts['sessions']}")
    if counts["spill"]:
        print(f"  Spill receipts drained: {counts['spill']}")
    print(f"  Total receipts in DB : {engine.store_backend.count()}")
    print()
    print("  Run 'transient-trace receipts compact' to remove legacy JSON files")
    print("  once you have confirmed the DB has everything you need.")


def cmd_receipts_compact(args: argparse.Namespace) -> None:
    """
    Delete legacy sessions/*.json and receipts/*.json after verifying the DB
    holds at least as many records as there are files on disk.

    This is a one-way operation. Run 'receipts index' first if in doubt.
    """
    import shutil

    state_dir    = Path(args.state_dir)
    receipts_dir = state_dir / "receipts"
    sessions_dir = state_dir / "sessions"
    db_path      = state_dir / "receipt_engine.db"

    if not db_path.exists():
        print("No receipt_engine.db found. Run 'receipts index' first.", file=sys.stderr)
        sys.exit(1)

    from transient_trace.receipt_engine.store import ReceiptStore
    store = ReceiptStore(db_path)
    db_receipts = store.store_backend.count() if hasattr(store, "store_backend") else store.count()
    db_sessions = len(store.get_session_keys())
    store.close()

    json_receipts = len(list(receipts_dir.glob("TR-*.json"))) if receipts_dir.exists() else 0
    json_sessions = sum(1 for _ in sessions_dir.glob("session-*.json")) if sessions_dir.exists() else 0

    print(f"  DB receipts : {db_receipts}   JSON receipts : {json_receipts}")
    print(f"  DB sessions : {db_sessions}   JSON sessions : {json_sessions}")

    if db_receipts < json_receipts:
        print(
            f"\n  ✗ DB has fewer receipts ({db_receipts}) than JSON files ({json_receipts}).",
            file=sys.stderr,
        )
        print("  Run 'receipts index' to backfill, then retry.", file=sys.stderr)
        sys.exit(1)

    disk_mb = sum(
        f.stat().st_size for d in [receipts_dir, sessions_dir] if d and d.exists()
        for f in d.rglob("*.json")
    ) / (1024 * 1024)

    if not args.yes:
        ans = input(
            f"\n  Delete {json_receipts} receipt files and {json_sessions} session files"
            f" ({disk_mb:.1f} MB)? [y/N] "
        )
        if ans.strip().lower() != "y":
            print("  Aborted.")
            return

    removed = 0
    for d in [receipts_dir, sessions_dir]:
        if d and d.exists():
            for f in list(d.glob("*.json")):
                f.unlink(missing_ok=True)
                removed += 1
            # Remove empty dir (ignores if non-empty, e.g. .spill still present)
            try:
                d.rmdir()
            except OSError:
                pass

    print(f"\n  ✓ Removed {removed} legacy JSON files ({disk_mb:.1f} MB reclaimed)")


# ── config ─────────────────────────────────────────────────────────────────────

_VALID_CONFIG_KEYS = {"state_dir", "mode", "packages"}


def cmd_config_show(args: argparse.Namespace) -> None:
    cfg = _load_config()
    if not cfg:
        print(f"No config file at {_CONFIG_PATH}")
        print("  Use: transient-trace config set state_dir <path>")
        return
    print(f"Config file: {_CONFIG_PATH}")
    for k, v in cfg.items():
        print(f"  {k} = {v}")


def cmd_config_set(args: argparse.Namespace) -> None:
    key   = args.key.strip()
    value = args.value.strip()
    if key not in _VALID_CONFIG_KEYS:
        print(f"Unknown config key '{key}'. Valid keys: {', '.join(sorted(_VALID_CONFIG_KEYS))}", file=sys.stderr)
        sys.exit(1)
    if key == "state_dir":
        value = str(Path(value).expanduser())
    if key == "packages":
        from transient_trace.atp.builtin_packages import list_builtin_packages  # noqa: PLC0415
        valid = set(list_builtin_packages())
        requested = {p.strip() for p in value.split(",") if p.strip()}
        unknown = requested - valid
        if unknown:
            print(f"Unknown package(s): {', '.join(sorted(unknown))}. Valid: {', '.join(sorted(valid))}", file=sys.stderr)
            sys.exit(1)
    cfg = _load_config()
    cfg[key] = value
    _save_config(cfg)
    print(f"Set {key} = {value}  (saved to {_CONFIG_PATH})")


# ── policy ───────────────────────────────────────────────────────────────────

def _get_policy_cfg() -> dict:
    """Return the persistent config, initialising a bare policy section if missing."""
    cfg = _load_config()
    if "policy" not in cfg:
        # No defaultAction here — let mode drive it (strict=deny, others=allow)
        cfg["policy"] = {"version": 1, "rules": []}
    return cfg


def cmd_policy_show(args: argparse.Namespace) -> None:
    cfg = _load_config()
    mode = cfg.get("mode", "audit")
    policy = cfg.get("policy", {})

    # Effective defaultAction: explicit config wins, otherwise derived from mode
    if "defaultAction" in policy:
        effective_default = policy["defaultAction"]
        default_source = "explicit"
    else:
        effective_default = "deny" if mode == "strict" else "allow"
        default_source = f"derived from mode={mode}"

    print(f"Config:  {_CONFIG_PATH}")
    print(f"Mode:    {mode}")
    print(f"Default: {effective_default}  ({default_source})")
    rules = policy.get("rules", [])
    if rules:
        print(f"Rules ({len(rules)}):")
        for i, r in enumerate(rules):
            parts = []
            if r.get("action"):        parts.append(f"action={r['action']}")
            if r.get("actionClass"):   parts.append(f"class={r['actionClass']}")
            if r.get("actionClasses"): parts.append(f"classes={r['actionClasses']}")
            print(f"  [{i}] {r.get('decision','?')}  {' '.join(parts)}  {r.get('reason','')}")
    else:
        print("Rules:   (none — all commands will be", "DENIED)" if effective_default == "deny" else "allowed)")


def cmd_policy_set_mode(args: argparse.Namespace) -> None:
    _unlock_shim(_CONFIG_PATH)  # must unlock to write, re-lock after if strict
    cfg = _load_config()
    cfg["mode"] = args.mode
    _save_config(cfg)
    print(f"✓ Mode set to '{args.mode}'  (saved to {_CONFIG_PATH})")
    if args.mode == "strict":
        _lock_shim(_CONFIG_PATH)
        print(f"✓ Config locked  (agents cannot modify policy while in strict mode)")
        print(f"  To change policy: transient-trace policy unlock, edit, then lock again")


def cmd_policy_set_default(args: argparse.Namespace) -> None:
    _unlock_shim(_CONFIG_PATH)
    cfg = _get_policy_cfg()
    cfg["policy"]["defaultAction"] = args.action
    _save_config(cfg)
    print(f"✓ Default action set to '{args.action}'  (saved to {_CONFIG_PATH})")


def cmd_policy_add_rule(args: argparse.Namespace) -> None:
    if not args.action and not args.action_class:
        print("error: at least one of --action or --action-class is required", file=sys.stderr)
        sys.exit(1)
    _unlock_shim(_CONFIG_PATH)
    cfg = _get_policy_cfg()
    rule: dict = {"decision": args.decision}
    if args.action:       rule["action"]      = args.action
    if args.action_class: rule["actionClass"] = args.action_class
    if args.reason:       rule["reason"]      = args.reason
    cfg["policy"]["rules"].append(rule)
    _save_config(cfg)
    print(f"✓ Rule added: {rule}  (saved to {_CONFIG_PATH})")


def cmd_policy_lock(args: argparse.Namespace) -> None:
    if not _CONFIG_PATH.exists():
        print(f"No config file at {_CONFIG_PATH} — nothing to lock", file=sys.stderr)
        sys.exit(1)
    _lock_shim(_CONFIG_PATH)
    print(f"✓ Config locked: {_CONFIG_PATH}")
    print(f"  Agents cannot modify policy. To unlock: transient-trace policy unlock")


def cmd_policy_unlock(args: argparse.Namespace) -> None:
    _unlock_shim(_CONFIG_PATH)
    print(f"✓ Config unlocked: {_CONFIG_PATH}")


def cmd_policy_clear_rules(args: argparse.Namespace) -> None:
    cfg = _get_policy_cfg()
    count = len(cfg["policy"].get("rules", []))
    cfg["policy"]["rules"] = []
    _save_config(cfg)
    print(f"✓ Cleared {count} rule(s)  (saved to {_CONFIG_PATH})")


# ── wrap ──────────────────────────────────────────────────────────────────────

_SHIMS_DIR = Path.home() / ".transient-trace" / "shims"

_SHIM_SCRIPT_TEMPLATE = """\
#!{python_executable}
# transient-trace governance wrapper for {binary}
# Managed by: transient-trace wrap install
# Real binary: {real_bin}
# To remove: transient-trace wrap uninstall {binary}
#
# This shim calls run_shim() directly — one Python process per command,
# no temp shim directory, no transient-trace run overhead.
from transient_trace._shim import run_shim
run_shim({real_bin_repr})
"""

_RC_COMMENT         = "# transient-trace shims — added by `transient-trace wrap install`"
_RC_COMMENT_NONINT  = "# transient-trace shims — active for all shells including non-interactive (e.g. Claude Code)"
_RC_LINE            = 'export PATH="$HOME/.transient-trace/shims:$PATH"'


def _shim_path(binary: str) -> Path:
    return _SHIMS_DIR / binary


def _find_real_binary(binary: str) -> str | None:
    """
    Find the real binary, skipping any path inside our own shims dir.
    Walks PATH entries in order, skipping the shims dir.
    """
    path_dirs = os.environ.get("PATH", "").split(":")
    shims_str  = str(_SHIMS_DIR)
    for d in path_dirs:
        if not d or d == shims_str:
            continue
        candidate = Path(d) / binary
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def _rc_files() -> list[Path]:
    """Return candidate shell RC files in preference order."""
    shell = os.environ.get("SHELL", "")
    home  = Path.home()
    if "zsh" in shell:
        return [home / ".zshrc", home / ".zprofile", home / ".zshenv"]
    if "bash" in shell:
        return [home / ".bashrc", home / ".bash_profile"]
    return [home / ".zshrc", home / ".bashrc", home / ".zshenv"]


def _lock_shim(path: Path) -> None:
    """Set OS-level immutability on a shim file."""
    import platform
    try:
        if platform.system() == "Darwin":
            import subprocess as _sp
            _sp.run(["chflags", "uchg", str(path)], check=True)
        else:
            import subprocess as _sp
            _sp.run(["chattr", "+i", str(path)], check=True)
    except Exception as exc:
        print(f"  warning: could not lock shim ({exc})", file=sys.stderr)


def _unlock_shim(path: Path) -> None:
    """Clear OS-level immutability on a shim file so it can be removed."""
    import platform
    try:
        if platform.system() == "Darwin":
            import subprocess as _sp
            _sp.run(["chflags", "nouchg", str(path)], check=True)
        else:
            import subprocess as _sp
            _sp.run(["chattr", "-i", str(path)], check=True)
    except Exception:
        pass  # best-effort — unlink will fail with a clear error if still locked


def _shim_is_locked(path: Path) -> bool:
    """Return True if the shim file has the immutable flag set."""
    import platform
    try:
        if platform.system() == "Darwin":
            import stat as _stat
            # UF_IMMUTABLE = 0x00000002
            return bool(path.stat().st_flags & 0x00000002)
        else:
            import subprocess as _sp
            out = _sp.run(["lsattr", str(path)], capture_output=True, text=True)
            return "i" in (out.stdout.split()[0] if out.stdout.split() else "")
    except Exception:
        return False


def _shims_in_path() -> bool:
    """Return True if our shims dir appears in PATH before the real binary would."""
    shims_str = str(_SHIMS_DIR)
    for d in os.environ.get("PATH", "").split(":"):
        if d == shims_str:
            return True
        # If we hit the real binary dir first, shims aren't active
    return False


def cmd_wrap_install(args: argparse.Namespace) -> None:
    binaries = [b.strip() for b in args.binary]
    rc_written = False

    for binary in binaries:
        real = args.real if len(binaries) == 1 else None

        if not real:
            real = _find_real_binary(binary)
            if not real:
                print(f"error: could not find '{binary}' in PATH", file=sys.stderr)
                print(f"  Specify explicitly with: transient-trace wrap install {binary} --real /path/to/{binary}", file=sys.stderr)
                continue

        # Safety: don't wrap something that's already our shim
        shim = _shim_path(binary)
        if Path(real).resolve() == shim.resolve():
            print(f"error: '{real}' is already the transient-trace shim — nothing to wrap", file=sys.stderr)
            continue

        _SHIMS_DIR.mkdir(parents=True, exist_ok=True)
        shim.write_text(_SHIM_SCRIPT_TEMPLATE.format(
            binary=binary,
            real_bin=real,
            real_bin_repr=repr(real),
            python_executable=sys.executable,
        ))
        shim.chmod(0o755)

        if args.lock:
            _lock_shim(shim)

        print(f"✓ Shim installed: {shim}")
        print(f"  Wraps:          {real}")
        if args.lock:
            print(f"  Locked:         OS-level immutability set (chflags uchg / chattr +i)")

    # Check PATH status and write RC once after all installs
    in_path = _shims_in_path()
    if in_path:
        print(f"✓ Shims dir is active in PATH")
    elif not rc_written:
        print()
        print(f"  Shims dir not yet in PATH: {_SHIMS_DIR}")
        if args.auto_rc:
            _add_to_rc()
        else:
            print()
            print("  Add to your shell RC file to make it permanent:")
            print(f"    {_RC_LINE}")
            print()
            print("  Or run with --auto-rc to add it automatically:")
            print(f"    transient-trace wrap install git claude curl ... --auto-rc")


def _add_to_rc() -> None:
    """Append the PATH export to the interactive RC file and to .zshenv/.bashenv.

    Two files are written:
    - The interactive RC (.zshrc / .bashrc) — for terminal sessions
    - .zshenv (zsh) — for non-interactive shells such as Claude Code subprocesses
      that source .zshenv but not .zshrc
    """
    home = Path.home()
    shell = os.environ.get("SHELL", "")

    # Determine interactive RC and non-interactive env file
    if "zsh" in shell:
        interactive_rcs = [home / ".zshrc", home / ".zprofile"]
        env_file = home / ".zshenv"
    elif "bash" in shell:
        interactive_rcs = [home / ".bashrc", home / ".bash_profile"]
        env_file = None  # bash uses .bashrc for both interactive and non-interactive
    else:
        interactive_rcs = [home / ".zshrc", home / ".bashrc"]
        env_file = home / ".zshenv"

    # Write to interactive RC
    wrote_interactive = False
    for rc in interactive_rcs:
        try:
            existing = rc.read_text() if rc.exists() else ""
            if _RC_LINE in existing:
                print(f"✓ Already in {rc} — no changes needed")
                wrote_interactive = True
                break
            with rc.open("a") as f:
                f.write(f"\n{_RC_COMMENT}\n{_RC_LINE}\n")
            print(f"✓ Added to {rc}")
            print(f"  Restart your shell or run:  source {rc}")
            wrote_interactive = True
            break
        except OSError:
            continue

    if not wrote_interactive:
        print("  warning: could not write to any interactive RC file — add manually:", file=sys.stderr)
        print(f"    {_RC_LINE}", file=sys.stderr)

    # Write to non-interactive env file so subprocesses (e.g. Claude Code) get shims
    if env_file:
        try:
            existing = env_file.read_text() if env_file.exists() else ""
            if _RC_LINE in existing:
                print(f"✓ Already in {env_file} — no changes needed")
            else:
                with env_file.open("a") as f:
                    f.write(f"\n{_RC_COMMENT_NONINT}\n{_RC_LINE}\n")
                print(f"✓ Added to {env_file} (non-interactive shells)")
        except OSError as e:
            print(f"  warning: could not write to {env_file}: {e}", file=sys.stderr)


def _remove_from_rc() -> None:
    """Remove the PATH export lines added by transient-trace from shell RC files.

    Matches on content patterns rather than exact strings so that old comment
    variants and combined PATH lines (e.g. with .local/bin merged in) are all
    caught regardless of which version of the installer wrote them.
    """
    import re
    removed_from = []
    for rc in _rc_files():
        if not rc.exists():
            continue
        try:
            original = rc.read_text()
            lines = original.splitlines(keepends=True)
            filtered = [
                line for line in lines
                if not (
                    # Any comment line referencing transient-trace shims
                    re.search(r"#.*transient-trace shims", line)
                    # Any PATH export that includes the shims dir
                    or re.search(r"export PATH=.*\.transient-trace/shims", line)
                )
            ]
            # Strip any trailing blank lines left behind by removal
            cleaned = "".join(filtered).rstrip("\n") + "\n" if filtered else ""
            if cleaned != original:
                rc.write_text(cleaned)
                removed_from.append(str(rc))
        except OSError:
            continue
    if removed_from:
        for rc in removed_from:
            print(f"  ✓ Removed PATH entry from {rc}")
        print(f"  Restart your shell or run:  source {removed_from[0]}")
    else:
        print("  – No PATH entry found in shell RC files — nothing to remove")


def cmd_wrap_uninstall(args: argparse.Namespace) -> None:
    binary = args.binary.strip()
    shim   = _shim_path(binary)

    if not shim.exists():
        print(f"No shim found for '{binary}' at {shim}")
        sys.exit(1)

    if _shim_is_locked(shim):
        _unlock_shim(shim)

    shim.unlink()
    print(f"✓ Removed shim: {shim}")

    # Clean up empty shims dir
    try:
        _SHIMS_DIR.rmdir()   # only succeeds if now empty
        print(f"  (shims dir removed — it was empty)")
    except OSError:
        pass


def cmd_uninstall(args: argparse.Namespace) -> None:
    """
    Full clean uninstall — removes all shims, PATH entry, and Popen hook.
    Config and receipts are preserved by default (they belong to the user).
    Pass --purge-data to also remove config and receipts.
    """
    print("\nUninstalling Transient Trace...\n")
    removed_anything = False

    # ── 1. Remove all shims ───────────────────────────────────────────────────
    if _SHIMS_DIR.exists():
        shims = [p for p in _SHIMS_DIR.iterdir() if p.is_file()]
        if shims:
            for shim in shims:
                try:
                    if _shim_is_locked(shim):
                        _unlock_shim(shim)
                    shim.unlink()
                    print(f"  ✓ Removed shim: {shim.name}")
                    removed_anything = True
                except OSError as e:
                    print(f"  ✗ Could not remove shim {shim.name}: {e}", file=sys.stderr)
        try:
            _SHIMS_DIR.rmdir()
            print(f"  ✓ Removed shims directory: {_SHIMS_DIR}")
        except OSError:
            pass
    else:
        print("  – No shims directory found")

    # ── 2. Remove stale binary remnants from known pip install locations ─────
    _STALE_BIN_DIRS = [
        Path("/opt/homebrew/bin"),
        Path("/usr/local/bin"),
        Path.home() / ".local" / "bin",
    ]
    for bin_dir in _STALE_BIN_DIRS:
        stale = bin_dir / "transient-trace"
        if stale.exists():
            # Only remove if it's a script (not a real binary installed by pipx/the
            # current install), i.e. it references transient_trace but is NOT the
            # active binary that just ran this command.
            try:
                active = Path(sys.argv[0]).resolve()
                if stale.resolve() != active:
                    stale.unlink()
                    print(f"  ✓ Removed stale binary: {stale}")
                    removed_anything = True
            except OSError as e:
                print(f"  ✗ Could not remove stale binary {stale}: {e}", file=sys.stderr)

    # ── 3. Remove PATH entry from shell RC files ──────────────────────────────
    print()
    _remove_from_rc()

    # ── 4. Remove Popen hook (.pth file) ─────────────────────────────────────
    print()
    pth_removed = False
    for sp in _find_site_packages():
        pth = sp / _PTH_FILENAME
        if pth.exists():
            try:
                pth.unlink()
                print(f"  ✓ Removed Popen hook: {pth}")
                pth_removed = True
                removed_anything = True
            except OSError as e:
                print(f"  ✗ Could not remove hook {pth}: {e}", file=sys.stderr)
    if not pth_removed:
        print("  – No Popen hook found")

    # ── 5. Optionally remove config and receipts ──────────────────────────────
    print()
    if args.purge_data:
        for path, label in [
            (_CONFIG_PATH.parent, "config directory"),
            (Path.home() / "transient-audit", "receipt store"),
        ]:
            if path.exists():
                import shutil as _shutil
                try:
                    _shutil.rmtree(path)
                    print(f"  ✓ Removed {label}: {path}")
                    removed_anything = True
                except OSError as e:
                    print(f"  ✗ Could not remove {label} {path}: {e}", file=sys.stderr)
    else:
        if _CONFIG_PATH.parent.exists():
            print(f"  – Config preserved: {_CONFIG_PATH.parent}")
            print(f"    (remove manually or rerun with --purge-data)")
        receipt_dir = Path.home() / "transient-audit"
        if receipt_dir.exists():
            print(f"  – Receipts preserved: {receipt_dir}")
            print(f"    (remove manually or rerun with --purge-data)")

    print()
    if removed_anything:
        print("Transient Trace uninstalled cleanly.")
        print("Restart your shell to complete PATH removal.")
    else:
        print("Nothing to uninstall — Transient Trace was not installed.")
    print()


def cmd_wrap_status(args: argparse.Namespace) -> None:
    in_path = _shims_in_path()

    print()
    print("  Transient Trace — Wrap Status")
    print(f"  Shims dir : {_SHIMS_DIR}")
    path_status = "active in PATH" if in_path else "NOT in PATH — shims will not intercept"
    print(f"  PATH      : {path_status}")
    print()

    if not _SHIMS_DIR.exists() or not any(_SHIMS_DIR.iterdir()):
        print("  No shims installed.")
        print("  Install one with: transient-trace wrap install <binary>")
        print()
        return

    print(f"  {'Binary':<16}  {'Shim':<8}  {'Real binary':<45}  Status")
    print("  " + "─" * 85)
    for shim in sorted(_SHIMS_DIR.iterdir()):
        if not shim.is_file():
            continue
        # Parse metadata from shim script comments
        real = "unknown"
        try:
            for line in shim.read_text().splitlines():
                if line.startswith("# Real binary:"):
                    real = line.split(":", 1)[1].strip()
                    break
        except OSError:
            pass

        real_exists = Path(real).exists() if real != "unknown" else False
        # Is this binary resolving to our shim in the current PATH?
        current = shutil.which(shim.name) or ""
        active   = Path(current).resolve() == shim.resolve() if current else False

        status = "✓ active" if active else ("✗ shadowed by other PATH entry" if not in_path else "✗ not resolving to shim")
        real_ok = "✓" if real_exists else "✗ not found"
        locked = "🔒 locked" if _shim_is_locked(shim) else ""

        print(f"  {shim.name:<16}  {'ok':<8}  {real:<45}  {status}  (real: {real_ok})  {locked}")

    if not in_path:
        print()
        print(f"  To activate, add to your shell RC:")
        print(f"    {_RC_LINE}")
    print()


# ── explain ───────────────────────────────────────────────────────────────────

def cmd_explain(args: argparse.Namespace) -> None:
    engine = _make_receipt_engine(args)
    # Auto-sync JSON files into the engine DB so explain always reflects
    # the full audit trail, not just what was written during a learning-enabled run.
    engine.index_from_json_dir(Path(args.state_dir) / "receipts")
    report = engine.explain(action_class=args.action_class)

    if args.as_json:
        print(json.dumps(report, indent=2))
        return

    summary = report.get("summary", {})
    print(f"\n{'─'*60}")
    print(f"  Transient Trace — Audit Report")
    print(f"  State dir: {args.state_dir}")
    print(f"{'─'*60}")
    print(f"  Total receipts : {summary.get('total', 0)}")
    print(f"  Deny rate      : {summary.get('deny_rate', 0.0):.1%}")
    print(f"  Outcomes       : {summary.get('outcomes', {})}")
    print(f"  Window         : {summary.get('from', '?')} → {summary.get('to', '?')}")

    top_rules = report.get("top_rules", [])
    if top_rules:
        print(f"\n  Top rules fired:")
        for r in top_rules:
            print(f"    {r['rule_id']:40s} ×{r['count']}")

    denies = report.get("denies", [])
    if denies:
        print(f"\n  Recent denials ({len(denies)}):")
        for d in denies[:5]:
            print(f"    {d.get('ts','?')}  {d.get('action','?')}  [{d.get('rule_id','?')}]")

    shifts = report.get("pattern_shifts", [])
    if shifts:
        print(f"\n  Pattern shifts (mixed allow+deny): {shifts}")
    print()


# ── query ─────────────────────────────────────────────────────────────────────

def cmd_query(args: argparse.Namespace) -> None:
    engine = _make_receipt_engine(args)
    receipts = engine.query(
        outcome=args.outcome,
        action_class=args.action_class,
        limit=args.limit,
    )
    print(json.dumps(receipts, indent=2))


# ── wrap install-hook ─────────────────────────────────────────────────────────

_PTH_FILENAME = "transient_trace_hook.pth"


def _build_pth_content() -> str:
    """
    Build .pth file content that adds transient_trace's install location to
    sys.path before activating the hook. The path is discovered at install
    time so the .pth works on any machine regardless of Python version or
    install method (pipx, pip, uv, venv, etc.).

    The hook is opt-in: it only activates when TRANSIENT_TRACE_HOOK=1 is set
    in the environment. Without this guard, every Python subprocess on the
    machine loads the hook — including children of children — creating a
    classic .pth fork bomb that exhausts RAM.
    """
    import transient_trace as _tt
    tt_site_packages = str(Path(_tt.__file__).parent.parent)
    return (
        f"{tt_site_packages}\n"
        "import os; os.environ.get('TRANSIENT_TRACE_HOOK') == '1' and "
        "__import__('transient_trace._popen_hook', fromlist=['install_hook']).install_hook()\n"
    )


def _find_site_packages() -> list[Path]:
    """
    Discover writable site-packages directories for the current Python.
    Prefers user site-packages so no sudo is required.
    Returns list in preference order.
    """
    import site
    candidates = []
    # User site-packages first (no sudo needed)
    try:
        user_site = site.getusersitepackages()
        if user_site:
            candidates.append(Path(user_site))
    except AttributeError:
        pass
    # Then system site-packages
    try:
        for p in site.getsitepackages():
            candidates.append(Path(p))
    except AttributeError:
        pass
    return candidates


def cmd_wrap_install_hook(args: argparse.Namespace) -> None:
    candidates = _find_site_packages()
    if not candidates:
        print("error: could not locate site-packages directory", file=sys.stderr)
        sys.exit(1)

    if args.uninstall:
        removed = []
        for sp in candidates:
            pth = sp / _PTH_FILENAME
            if pth.exists():
                pth.unlink()
                removed.append(str(pth))
        if removed:
            for p in removed:
                print(f"✓ Removed: {p}")
        else:
            print("No hook installed — nothing to remove")
        return

    # Install into the first writable site-packages
    installed = None
    errors = []
    for sp in candidates:
        pth = sp / _PTH_FILENAME
        try:
            sp.mkdir(parents=True, exist_ok=True)
            pth.write_text(_build_pth_content(), encoding="utf-8")
            installed = pth
            break
        except OSError as e:
            errors.append(f"  {sp}: {e}")

    if not installed:
        print("error: could not write hook to any site-packages directory:", file=sys.stderr)
        for e in errors:
            print(e, file=sys.stderr)
        print("  Try running with sudo, or check permissions.", file=sys.stderr)
        sys.exit(1)

    print(f"✓ Hook installed: {installed}")
    print(f"  Any Python process on this machine will now have subprocess.Popen")
    print(f"  governed — including absolute-path calls like /usr/bin/git.")
    print(f"  To remove: transient-trace wrap install-hook --uninstall")


# ── export ────────────────────────────────────────────────────────────────────

def cmd_export(args: argparse.Namespace) -> None:
    engine = _make_receipt_engine(args)
    out = Path(args.out)
    bundle = engine.export_bundle(path=out)
    print(f"[transient-trace] bundle exported → {out}")
    print(f"  receipts : {bundle['receipt_count']}")
    print(f"  hash     : {bundle['manifest_hash']}")


# ── shared helpers ────────────────────────────────────────────────────────────

def _make_receipt_engine(args: argparse.Namespace):
    """
    Open the receipt engine DB directly — without creating a new Client or
    writing a new session receipt. Used by explain/query/export which are
    read-oriented and shouldn't pollute the sessions directory.
    """
    from transient_trace.receipt_engine import ReceiptEngine

    state_dir = Path(args.state_dir)
    db_path   = state_dir / "receipt_engine.db"
    return ReceiptEngine(db_path=db_path)


if __name__ == "__main__":
    main()
