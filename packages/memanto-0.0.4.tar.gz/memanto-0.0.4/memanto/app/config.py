"""
MEMANTO Configuration

Server-side settings (loaded from .env via pydantic-settings).
CLI config models have been moved to cli/config/manager.py.
"""

from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict

# Load project .env first, then ~/.memanto/.env for the API key
load_dotenv()
_memanto_env = Path.home() / ".memanto" / ".env"
if _memanto_env.exists():
    load_dotenv(_memanto_env, override=True)


# CLI & YAML Format Models (kept for backward compat with config.yaml structure)
class ServerConfig(BaseModel):
    """Server configuration"""

    url: str = "localhost"
    port: int = 8000
    auto_start: bool = False


class SessionConfig(BaseModel):
    """Session management configuration"""

    default_duration_hours: int = 6
    auto_extend: bool = True
    extend_threshold_minutes: int = 30
    warn_before_expiry_minutes: int = 15
    auto_renew_enabled: bool = True
    auto_renew_interval_hours: int = 6


class CLIConfig(BaseModel):
    """CLI behavior configuration"""

    interactive_mode: bool = True
    smart_parse: bool = True
    auto_title: bool = True
    color_output: bool = True


class Settings(BaseSettings):
    """Unified Settings: sourced from environment / .env files"""

    # Moorcheh Configuration
    MOORCHEH_API_KEY: str = ""

    # Server Configuration
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG: bool = False

    # CORS Configuration
    ALLOWED_ORIGINS: list[str] = ["*"]

    # Session Configuration
    MEMANTO_SECRET_KEY: str = "memanto-default-secret-change-in-production"
    SESSION_DEFAULT_DURATION_HOURS: int = 6
    SESSION_AUTO_EXTEND: bool = True
    SESSION_EXTEND_THRESHOLD_MINUTES: int = 30
    SESSION_AUTO_RENEW_ENABLED: bool = True
    SESSION_AUTO_RENEW_INTERVAL_HOURS: int = 6

    # Memory Configuration
    DEFAULT_TTL_SECONDS: int = 3600  # 1 hour
    MAX_MEMORY_SIZE: int = 500  # characters
    MAX_TITLE_SIZE: int = 100  # characters

    # Answer Configuration
    ANSWER_MODEL: str = "anthropic.claude-sonnet-4-6"
    ANSWER_TEMPERATURE: float = 0.7
    ANSWER_LIMIT: int = 15  # number of context memories to retrieve
    ANSWER_THRESHOLD: float = 0.01  # confidence threshold for memory relevance

    # Recall / Search Configuration
    RECALL_LIMIT: int = 10  # default top-N results for recall/search

    # Validation Configuration
    REQUIRE_VALIDATION_FOR: list[str] = ["fact", "preference"]
    PROVISIONAL_TTL_SECONDS: int = 3600  # 1 hour
    PROVISIONAL_MAX_CONFIDENCE: float = 0.5

    # Schedule Configuration
    MEMANTO_SCHEDULE_TIME: str = "23:55"

    model_config = SettingsConfigDict(
        env_file=".env", case_sensitive=True, extra="ignore"
    )


# Global settings instance
settings = Settings()
