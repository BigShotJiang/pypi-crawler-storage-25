from enum import Enum


class Mode(Enum):
    CLI = "cli"
    SERVICE = "service"


DEFAULT_BOOTSTRAP_SERVER = "localhost:9092"
# Default only: /tmp is world-writable (symlink/TOCTOU risk in hostile
# multi-user hosts). Use COLLECTOR_CAPTURE_DIR or -c to a private path in
# production. Sonar: python:S5443.
DEFAULT_CAPTURE_DIR = "/tmp/kafka-collector"  # NOSONAR
DEFAULT_PORT = 8080
DEFAULT_MODE = Mode.CLI

ENV_TOPICS = "KAFKA_TOPICS"
ENV_BOOTSTRAP_SERVER = "KAFKA_BOOTSTRAP_SERVER"
ENV_GROUP = "KAFKA_GROUP"
ENV_CAPTURE_DIR = "COLLECTOR_CAPTURE_DIR"
ENV_MODE = "COLLECTOR_MODE"
ENV_SERVICE_PORT = "COLLECTOR_SERVICE_PORT"

KAFKA_AUTO_OFFSET_RESET = "latest"
KAFKA_ENABLE_AUTO_COMMIT = True
KAFKA_POLL_TIMEOUT_MS = 100

FLASK_HOST = "0.0.0.0"

# Service-mode rolling capture files (UTC; see FileManager._generate_filepath)
CAPTURE_FILENAME_PREFIX = "kafka-collector_"
CAPTURE_FILENAME_EXTENSION = ".jsonl"
CAPTURE_FILENAME_TIMESTAMP_FORMAT = "%Y%m%d_%H%M%S_%f"

# HTTP download (service mode)
DOWNLOAD_KIND_JSONL = "jsonl"
DOWNLOAD_KIND_ZIP = "zip"
DEFAULT_DOWNLOAD_KIND = DOWNLOAD_KIND_JSONL
DOWNLOAD_KINDS: frozenset[str] = frozenset(
    {DOWNLOAD_KIND_JSONL, DOWNLOAD_KIND_ZIP},
)
MIME_TYPE_JSONL = "application/jsonl"
MIME_TYPE_ZIP = "application/zip"

# HTTP JSON API (service mode)
API_JSON_ERROR_KEY = "error"
API_ERROR_CAPTURE_FILE_MISSING = (
    "capture file is missing or inaccessible"
)
