"""Utility helpers for BorgStore."""
