"""
BorgStore HTTP REST server.
"""
