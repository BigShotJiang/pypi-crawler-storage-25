# BetterGuiSpark ⚡

BetterGuiSpark is a simple and powerful GUI framework built on top of PyQt6.

## Features

- Easy widget creation
- Event handling (keyboard + mouse)
- Built-in themes
- File handling
- Validation system

## Example

```python
from BetterGuiSpark import GuiSpark

app = GuiSpark("Test")

btn = app.add_widget("button", text="Click me", command=lambda: print("Clicked!"))

app.run()