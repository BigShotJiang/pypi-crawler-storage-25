from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pttb-lang",
    version="2.13.1",
    author="BaHost01",
    description="PTTB (Português Técnico do Brasil) - A Brazilian-themed programming language",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/BaHost01/PTTBR",
    packages=find_packages(exclude=["tests*"]),
    include_package_data=True,
    package_data={
        "pttb": ["pttb-vscode/**/*"],
    },
    entry_points={
        "console_scripts": [
            "pttb=pttb.cli:run",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Interpreters",
    ],
    python_requires=">=3.8",
)
