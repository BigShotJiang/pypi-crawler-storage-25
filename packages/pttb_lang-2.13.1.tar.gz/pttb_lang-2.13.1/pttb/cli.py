import argparse
import sys
import os
import json
import time
import base64
import zlib
import shutil
import platform
import subprocess
from .lexer import tokenize
from .parser import Parser
from .interpreter import Interpreter

VERSION = "2.13.1"

class MiniYAML:
    @staticmethod
    def dump(data):
        lines = []
        for k, v in data.items():
            if isinstance(v, dict):
                lines.append(f"{k}:")
                for sk, sv in v.items():
                    if isinstance(sv, dict):
                        lines.append(f"  {sk}:")
                        for ssk, ssv in sv.items(): lines.append(f"    {ssk}: {ssv}")
                    else: lines.append(f"  {sk}: {sv}")
            else: lines.append(f"{k}: {v}")
        return "\n".join(lines)

    @staticmethod
    def load(content):
        data = {}
        for line in content.splitlines():
            if ":" in line and not line.strip().startswith("-"):
                parts = line.split(":", 1)
                data[parts[0].strip()] = parts[1].strip()
        return data

def pack_data(data):
    return base64.b64encode(zlib.compress(json.dumps(data).encode('utf-8'))).decode('utf-8')

def unpack_data(blob):
    return json.loads(zlib.decompress(base64.b64decode(blob)).decode('utf-8'))

def pack_code(code):
    clean = code.replace("\n", " ")
    return base64.b64encode(zlib.compress(clean.encode('utf-8'))).decode('utf-8')

def unpack_code(blob):
    if isinstance(blob, dict): blob = blob["ptpc"]
    return zlib.decompress(base64.b64decode(blob)).decode('utf-8')

PACKAGE_REGISTRY = {
    "pttb-lexer": {"desc": "Analisador léxico.", "ptpc": pack_code('funcaoCLT analisar(t){mandaMsg("[PTTBLIB] Lexing: "+t)}')},
    "pttb-vmcore": {"desc": "Info da VM.", "ptpc": pack_code('funcaoCLT status(){mandaMsg("VM Ativa v2.13")}')},
    "pttb-anticheat": {"desc": "Módulo de Segurança e AntiCheat.", "ptpc": pack_code('funcaoCLT vigiarHackers(){ sePixAceitou(detectaDebugger()){mandaMsg("[AntiCheat] Banido! Debugger detectado.") retornar falso} mandaMsg("[AntiCheat] O sistema esta seguro por agora...") bloqueiaInjecao() retornar verdadeiro }')}
}

class PTTBLogger:
    @staticmethod
    def splash():
        # Using raw string to avoid invalid escape sequence warnings
        print(rf"""
\033[1;36m   ____  _________________ \033[1;34m  ____  _____ 
\033[1;36m  / __ \/_  __/_  __/ __ ) \033[1;34m / __ \/ ___/ 
\033[1;36m / /_/ / / /   / / / __  | \033[1;34m/ /_/ /\__ \  
\033[1;36m/ ____/ / /   / / / /_/ / \033[1;34m/ _, _/___/ /  
\033[1;36m/_/     /_/   /_/ /_____/ \033[1;34m/_/ |_|/____/   \033[0;90mv{VERSION}
\033[0;37m  "Documentação impecável, código inabalável."\033[0m
""")
    @staticmethod
    def header(task): print(f"\n\033[1;36m► TASK :{task.ljust(45, '─')}\033[0m")
    @staticmethod
    def info(text): print(f"  \033[0;34mℹ\033[0m {text}")
    @staticmethod
    def error(text): print(f"  \033[1;31m✖\033[0m {text}")
    @staticmethod
    def success(text, duration):
        print(f"\n  \033[1;32m✔\033[0m {text} \033[0;90m({duration}s)\033[0m")

def init_project():
    PTTBLogger.header("init")
    with open("pttjam.yaml", "w") as f: 
        f.write(f"projeto: MeuAppPTTB\nversao: 1.0.0\nengine: {VERSION}\n")
    auth_data = {"auth_token": "pttb-auth-verified", "scan_cache": {}, "last_fingerprint": ""}
    with open("ProjectAuthMark.ptmn", "w") as f: f.write(pack_data(auth_data))
    ts = {"external_support": {"lua": {"enabled": "false"}}}
    with open("ThirdSoftWare.yaml", "w") as f: f.write(MiniYAML.dump(ts))
    readme_content = f"# Projeto PTTB 🇧🇷\n\nGerado pelo motor v{VERSION}.\n\nRodar: `pttb run`"
    with open("LEIAME.md", "w", encoding="utf-8") as f: f.write(readme_content)
    os.makedirs("libs", exist_ok=True)
    if not os.path.exists("main.pttb"):
        with open("main.pttb", "w") as f: f.write('mandaMsg("Alô Brasil! Motor v2.13.1 rodando.")\n')
    PTTBLogger.success("PROJETO INICIALIZADO", 0.05)

def install_extension():
    PTTBLogger.header("ide-setup")
    base_dir = os.path.dirname(os.path.abspath(__file__))
    ext_path = os.path.join(base_dir, "pttb-vscode")
    if not os.path.exists(ext_path):
        PTTBLogger.error("Extensão não encontrada no pacote.")
        return
    try:
        cmd = ["code", "--install-extension", ext_path, "--force"]
        subprocess.run(cmd, shell=(platform.system() == "Windows"))
        PTTBLogger.success("EXTENSÃO INSTALADA", 0.5)
    except Exception as e: PTTBLogger.error(f"Erro: {e}")

def run_project(file_path=None):
    start_time = time.time()
    target = file_path or "main.pttb"
    module_name = os.path.basename(target)
    PTTBLogger.header("pre-scan")
    # Lógica de cache simplificada
    PTTBLogger.header("compile")
    try:
        with open(target, "r", encoding="utf-8") as f: code = f.read()
        it = Interpreter(module=module_name)
        if os.path.exists("./libs"):
            for f in os.listdir("./libs"):
                if f.endswith(".pttblib"):
                    with open(os.path.join("./libs", f), "r") as lf:
                        it.interpret(Parser(tokenize(lf.read(), module=f), module=f).parse())
        PTTBLogger.header("execute")
        it.interpret(Parser(tokenize(code, module=module_name), module=module_name).parse())
        PTTBLogger.success("FINALIZADO", round(time.time() - start_time, 3))
    except Exception as e:
        if not isinstance(e, SystemExit): print(f"✖ Erro: {e}")
        sys.exit(1)

def search_pkgs(query=None):
    PTTBLogger.header("search")
    for name, data in PACKAGE_REGISTRY.items():
        if not query or query.lower() in name.lower():
            print(f"  \033[1;36m{name.ljust(20)}\033[0m │ {data['desc']}")
    PTTBLogger.success("PESQUISA CONCLUÍDA", 0.01)

def install_pkg(pkg_name):
    PTTBLogger.header("install")
    if pkg_name not in PACKAGE_REGISTRY:
        PTTBLogger.error(f"Pacote {pkg_name} não encontrado.")
        return
    os.makedirs("./libs", exist_ok=True)
    with open(f"./libs/{pkg_name}.pttblib", "w") as f:
        f.write(unpack_code(PACKAGE_REGISTRY[pkg_name]))
    PTTBLogger.success("INSTALADO", 0.1)

def build_project():
    PTTBLogger.header("build")
    # Gerando stub básico
    os.makedirs("build", exist_ok=True)
    with open("build/app.bin", "w") as f: f.write("#!/usr/bin/env pttb\n")
    PTTBLogger.success("ARTEFATO GERADO", 0.01)

def run():
    parser = argparse.ArgumentParser(description="PTTB CLI")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("init")
    subparsers.add_parser("run").add_argument("file", nargs="?")
    subparsers.add_parser("build")
    subparsers.add_parser("search").add_argument("query", nargs="?")
    subparsers.add_parser("install").add_argument("package")
    subparsers.add_parser("ide")
    subparsers.add_parser("version")
    PTTBLogger.splash()
    args = parser.parse_args()
    if args.command == "init": init_project()
    elif args.command == "run": run_project(args.file)
    elif args.command == "build": build_project()
    elif args.command == "search": search_pkgs(args.query)
    elif args.command == "install": install_pkg(args.package)
    elif args.command == "ide": install_extension()
    elif args.command == "version": print(f"PTTB v{VERSION}")
    else: parser.print_help()

if __name__ == "__main__":
    run()
