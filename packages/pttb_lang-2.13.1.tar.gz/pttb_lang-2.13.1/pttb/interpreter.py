from .ast import *
from .runtime import Environment, Function, BuiltinFunction
from .errors import signal_error
import platform
import time
import math

# Exceção customizada para o "retornar"
class PTTBReturn(Exception):
    def __init__(self, value):
        self.value = value

try: import tkinter as tk
except ImportError: tk = None
try: import pymem
except ImportError: pymem = None

class Interpreter:
    def __init__(self, debug=False, module="Principal"):
        self.globals = Environment()
        self.debug = debug
        self.module = module
        self.os = platform.system().upper()
        self.keys_pressed = {}
        self.setup_builtins()

    def setup_builtins(self):
        # ---- VETOR & MATRIZ ----
        def b_vetor3(interp, args): return {"x": args[0], "y": args[1], "z": args[2], "tipo": "vetor3"}
        self.globals.define("criaVetor3", BuiltinFunction("criaVetor3", b_vetor3))

        def b_cria_matriz(interp, args):
            import random
            r, c = args[0], args[1]
            return [[random.random() for _ in range(c)] for _ in range(r)]
        self.globals.define("criaMatriz", BuiltinFunction("criaMatriz", b_cria_matriz))

        # ---- SISTEMA E REDE ----
        def b_faz_req(interp, args):
            import urllib.request
            try:
                with urllib.request.urlopen(args[0]) as r: return r.read().decode('utf-8')
            except Exception as e: return f"Erro: {e}"
        self.globals.define("fazRequisicao", BuiltinFunction("fazRequisicao", b_faz_req))

        def b_exec_cmd(interp, args):
            import subprocess
            try: return subprocess.check_output(args[0], shell=True, text=True)
            except: return "Erro"
        self.globals.define("executaComando", BuiltinFunction("executaComando", b_exec_cmd))

        def b_ler_env(interp, args):
            import os as pyos
            return dict(pyos.environ)
        self.globals.define("lerEnv", BuiltinFunction("lerEnv", b_ler_env))

        # Built-ins anteriores mantidas
        def b_timestamp(interp, args): return time.time()
        self.globals.define("tempoAtual", BuiltinFunction("tempoAtual", b_timestamp))

        # ---- ANTICHEAT E SEGURANÇA (NOVOS v2.10) ----
        def b_detecta_debugger(interp, args):
            import sys as pysys
            # Se a função gettrace existir e retornar algo, tem debugger acoplado
            tem_debugger = hasattr(pysys, 'gettrace') and pysys.gettrace() is not None
            return tem_debugger
        self.globals.define("detectaDebugger", BuiltinFunction("detectaDebugger", b_detecta_debugger))

        def b_scan_memoria(interp, args):
            # Mock de scanner de assinaturas em memória
            assinatura = args[0]
            print(f"[AntiCheat] Escaneando memória por assinatura suspeita: {assinatura}...")
            time.sleep(0.2)
            # Falso positivo de vez em quando pra dar emoção
            import random
            return random.choice([False, False, False, False, True])
        self.globals.define("scanMemoria", BuiltinFunction("scanMemoria", b_scan_memoria))

        def b_bloqueia_injecao(interp, args):
            print("[AntiCheat] Hooking LoadLibraryA e bloqueando injeção de DLLs (Stub)...")
            return True
        self.globals.define("bloqueiaInjecao", BuiltinFunction("bloqueiaInjecao", b_bloqueia_injecao))

    def interpret(self, program):
        try:
            for statement in program.statements:
                self.evaluate(statement, self.globals)
        except PTTBReturn:
            pass # Return global (fora de função) é ignorado ou encerra
        except Exception as e:
            if not isinstance(e, SystemExit):
                signal_error("PTTB-999", f"Erro fatal: {str(e)}", module=self.module)

    def evaluate(self, node, env):
        t = type(node)
        
        if t == Literal: return node.value
        if t == Identifier: return env.get(node.name)
        
        if t == BinaryOp:
            left = self.evaluate(node.left, env)
            right = self.evaluate(node.right, env)
            op = node.op
            if op == 'PLUS': return left + right if not isinstance(left, str) and not isinstance(right, str) else str(left) + str(right)
            if op == 'MINUS': return left - right
            if op == 'MUL': return left * right
            if op == 'DIV': return left / right
            if op == 'LT': return left < right
            if op == 'GT': return left > right
            if op == 'EQ': return left == right
            if op == 'LE': return left <= right
            if op == 'GE': return left >= right
            if op == 'NE': return left != right

        if t == VarDeclaration:
            val = self.evaluate(node.value, env)
            env.define(node.name, val)
            return val

        if t == VarAssignment:
            val = self.evaluate(node.value, env)
            env.assign(node.name, val)
            return val

        if t == FunctionDeclaration:
            f = Function(node, env)
            env.define(node.name, f)
            return f

        if t == ReturnStatement:
            val = self.evaluate(node.expr, env)
            raise PTTBReturn(val)

        if t == TryCatchStatement:
            try:
                for s in node.try_block: self.evaluate(s, env)
            except Exception:
                for s in node.catch_block: self.evaluate(s, env)
            return None

        if t == FunctionCall:
            func = env.get(node.name) if isinstance(node.name, str) else self.evaluate(node.name, env)
            args = [self.evaluate(arg, env) for arg in node.args]
            # No runtime.py alterado ou aqui mesmo
            if isinstance(func, BuiltinFunction):
                return func.call(self, args)
            
            # Execução de função PTTB com suporte a retornar
            new_env = Environment(func.closure)
            for i, p in enumerate(func.declaration.params):
                new_env.define(p, args[i])
            try:
                res = None
                for s in func.declaration.body:
                    res = self.evaluate(s, new_env)
                return res
            except PTTBReturn as r:
                return r.value

        if t == IfStatement:
            if self.evaluate(node.condition, env):
                for s in node.then_branch: self.evaluate(s, env)
            elif node.else_branch:
                for s in node.else_branch: self.evaluate(s, env)
            return None

        if t == WhileLoop:
            while self.evaluate(node.condition, env):
                for s in node.body: self.evaluate(s, env)
            return None

        if t == IndexAccess: return self.evaluate(node.obj, env)[self.evaluate(node.index, env)]
        if t == MemberAccess:
            target = self.evaluate(node.obj, env)
            if isinstance(target, dict): return target.get(node.property_name)
            return getattr(target, node.property_name, None)

        if t == PrintStatement:
            print(self.evaluate(node.expr, env))
            return None

        if t == ListLiteral: return [self.evaluate(e, env) for e in node.elements]
        if t == MapLiteral: return {self.evaluate(k, env): self.evaluate(v, env) for k, v in node.pairs}

        return None
