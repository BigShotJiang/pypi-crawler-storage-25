import re
from .errors import signal_error

TOKEN_TYPES = [
    ('NUMBER',   r'\d+(\.\d+)?'),
    ('STRING',   r'("[^"]*"|\'[^\']*\')'),
    ('BOOLEAN',  r'\b(verdadeiro|falso)\b'),
    ('DEFINIR',  r'\bdefinir\b'),
    ('RETORNAR', r'\bretornar\b'),
    ('TENTA',    r'\btentaA_Sorte\b'),
    ('SE_DEU_RUIM', r'\bseDeuRuim\b'),
    ('FUNCAO',   r'\bfuncaoCLT\b'),
    ('SE',       r'\bsePixAceitou\b'),
    ('SENAO',    r'\bsePixNegou\b'),
    ('CASO_RUIM', r'\bsePixDeuRuim\b'),
    ('ENQUANTO', r'\benquantoFilaNaoAnda\b'),
    ('PARA_CADA', r'\bpraCadaDesgraca\b'),
    ('ATE_QUE',  r'\bateoPixCair\b'),
    ('EM',       r'\bem\b'),
    ('MANDA_MSG', r'\bmandaMsg\b'),
    ('PEDE_INPUT', r'\bpedeInputNoZap\b'),
    ('ESPERA',   r'\besperaFilaDoCaixa\b'),
    ('LISTA',    r'\bcaixaDePaesDeQueijo\b'),
    ('MAPA',     r'\binventarioDoZAP\b'),
    ('ID',       r'[a-zA-Z_][a-zA-Z0-9_]*'),
    ('ASSIGN',   r'='),
    ('PLUS',     r'\+'),
    ('MINUS',    r'-'),
    ('MUL',      r'\*'),
    ('DIV',      r'/'),
    ('LPAREN',   r'\('),
    ('RPAREN',   r'\)'),
    ('LBRACE',   r'\{'),
    ('RBRACE',   r'\}'),
    ('LBRACKET', r'\['),
    ('RBRACKET', r'\]'),
    ('COMMA',    r','),
    ('DOT',      r'\.'),
    ('COLON',    r':'),
    ('LE',       r'<='),
    ('GE',       r'>='),
    ('LT',       r'<'),
    ('GT',       r'>'),
    ('EQ',       r'=='),
    ('NE',       r'!='),
    ('NEWLINE',  r'\n'),
    ('SKIP',     r'[ \t]+'),
    ('MISMATCH', r'.'),
]

class Token:
    def __init__(self, type, value, line, column):
        self.type = type
        self.value = value
        self.line = line
        self.column = column

    def __repr__(self):
        return f'Token({self.type}, {self.value}, {self.line}, {self.column})'

def tokenize(code, module="Principal"):
    # Pré-processamento: Comentários multi-linha /* ... */
    code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
    # Pré-processamento: Comentários de linha //
    code = re.sub(r'//.*', '', code)
    
    tokens = []
    line_num = 1
    line_start = 0
    token_regex = '|'.join('(?P<%s>%s)' % pair for pair in TOKEN_TYPES)
    
    for mo in re.finditer(token_regex, code):
        kind = mo.lastgroup
        value = mo.group()
        column = mo.start() - line_start
        
        if kind == 'NUMBER':
            value = float(value) if '.' in value else int(value)
        elif kind == 'STRING':
            value = value[1:-1]
        elif kind == 'NEWLINE':
            line_start = mo.end()
            line_num += 1
            continue
        elif kind == 'SKIP':
            continue
        elif kind == 'MISMATCH':
            signal_error("PTTB-002", f"Token perdido no meio da confusão: '{value}'", line_num, module)
            
        tokens.append(Token(kind, value, line_num, column))
    return tokens
