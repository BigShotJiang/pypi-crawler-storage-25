"""v0.2/v0.4/v0.6 catalogue: T-C1 + T-A2 + T-M1 + T-F1 + T-R1 — shape and contract tests.

These tests pin the public catalogue shape and key contract details that
plan-29/plan-31 commit to. They do not exercise the proposer or rerun tools
(those have their own modules); the goal here is to lock the templates'
identity and structural invariants so accidental drift on a factory
function trips loudly.
"""

from __future__ import annotations

from dataclasses import replace

import pytest

from ml4t.agent.schemas import (
    DeltaCriterion,
    EvidencePack,
    IterationCategory,
    PlanValidationError,
    Severity,
    TemplateMaturity,
)
from ml4t.agent.tools import (
    build_ta2_template,
    build_tc1_template,
    build_tf1_template,
    build_tm1_template,
    build_tr1_template,
    default_templates,
)


def test_default_catalogue_v06_returns_five_templates() -> None:
    cat = default_templates()
    assert tuple(t.template_id for t in cat) == ("T-C1", "T-A2", "T-M1", "T-F1", "T-R1")


def test_default_catalogue_parametrizes_ta2_from_evidence(sample_pack: EvidencePack) -> None:
    """When an EvidencePack is supplied, T-A2's absolute thresholds are
    computed from the parent's `signal.best_mean_ic`."""

    cat = default_templates(evidence=sample_pack)
    ta2 = next(t for t in cat if t.template_id == "T-A2")
    best_ic = sample_pack.validation.signal.best_mean_ic
    assert ta2.delta_criterion_template.support_threshold == pytest.approx(best_ic - 0.002)
    assert ta2.delta_criterion_template.reject_threshold == pytest.approx(best_ic - 0.010)


def test_ta2_template_is_pure_rerun() -> None:
    ta2 = build_ta2_template()
    assert ta2.maturity is TemplateMaturity.CONCRETE
    assert ta2.category is IterationCategory.AUDIT
    # Pure rerun: no overrides, no forbidden paths, audit runs regardless of severity.
    assert ta2.allowed_overrides == ()
    assert ta2.forbidden_paths == ()
    assert ta2.forbidden_when == ()
    # Cites the lineage predicate (T29-A).
    assert "methodology_warning_cites_lineage" in ta2.preconditions


def test_ta2_template_family_pipeline() -> None:
    """Family parametrizes the pipeline (07_gbm vs 06_linear)."""

    gbm = build_ta2_template(family="gbm")
    linear = build_ta2_template(family="linear")
    assert gbm.stage_invocations[0].script == "07_gbm.py"
    assert linear.stage_invocations[0].script == "06_linear.py"
    # Other stages are common (analysis / backtest / strategy_analysis).
    for tpl in (gbm, linear):
        scripts = [s.script for s in tpl.stage_invocations]
        assert "13_model_analysis.py" in scripts
        assert "14_backtest.py" in scripts
        assert "18_strategy_analysis.py" in scripts


def test_ta2_delta_criterion_is_absolute_ic() -> None:
    ta2 = build_ta2_template(best_mean_ic_prior=0.024)
    crit = ta2.delta_criterion_template
    assert isinstance(crit, DeltaCriterion)
    assert crit.primary_metric == "mean_fold_ic"
    assert crit.metric_kind == "absolute"
    assert crit.direction == "higher_is_better"
    assert crit.noise_floor_method == "simple_bootstrap"
    assert crit.support_threshold == pytest.approx(0.022)
    assert crit.reject_threshold == pytest.approx(0.014)


def test_tm1_template_overrides_gbm_list() -> None:
    tm1 = build_tm1_template()
    assert tm1.maturity is TemplateMaturity.CONCRETE
    assert tm1.category is IterationCategory.MODEL
    assert "gbm_dispersion_large" in tm1.preconditions
    assert Severity.BLOCKING in tm1.forbidden_when
    assert Severity.MATERIAL in tm1.forbidden_when

    assert len(tm1.allowed_overrides) == 1
    spec = tm1.allowed_overrides[0]
    assert spec.path_template == "config/training/{label}.yaml"
    assert spec.yaml_path == ("gbm",)
    assert spec.value_type == "list[str]"

    forbidden = set(tm1.forbidden_paths)
    for guard in (("evaluation",), ("costs",), ("labels",), ("universe",)):
        assert guard in forbidden


def test_tm1_delta_criterion_is_within_family_delta() -> None:
    tm1 = build_tm1_template()
    crit = tm1.delta_criterion_template
    assert crit.primary_metric == "mean_fold_ic_within_family"
    assert crit.metric_kind == "delta"
    assert crit.direction == "higher_is_better"
    assert crit.noise_floor_method == "hac_newey_west_21d"
    assert crit.support_threshold == pytest.approx(0.005)
    assert crit.reject_threshold == pytest.approx(-0.003)


def test_tm1_overridespec_validates_list_str(sample_pack: EvidencePack) -> None:
    """The OverrideSpec accepts a list of preset name strings and rejects
    other shapes — mirrors the T-C1 pattern."""

    spec = build_tm1_template().allowed_overrides[0]
    spec.validate_value(["gbm_shallow", "gbm_balanced"])
    with pytest.raises(PlanValidationError, match="list\\[str\\]"):
        spec.validate_value([1, 2])
    with pytest.raises(PlanValidationError, match="list\\[str\\]"):
        spec.validate_value("gbm_shallow")


def test_tc1_unchanged_in_v02_catalogue() -> None:
    """The T-C1 template factory is unchanged by v0.2 catalogue work."""

    tc1 = build_tc1_template()
    assert tc1.template_id == "T-C1"
    assert tc1.delta_criterion_template.primary_metric == "edge_to_cost_ratio_after"
    # T-C1 still pinned to a single override on the cost range tuple.
    assert len(tc1.allowed_overrides) == 1
    assert tc1.allowed_overrides[0].yaml_path == ("costs", "per_leg_cost_bps_range")


def test_default_catalogue_with_evidence_does_not_mutate_template_ids(
    sample_pack: EvidencePack,
) -> None:
    cat = default_templates(evidence=replace(sample_pack))
    assert tuple(t.template_id for t in cat) == ("T-C1", "T-A2", "T-M1", "T-F1", "T-R1")


# --- T-F1 (drop_stop_features) ----------------------------------------------


def test_tf1_template_overrides_feature_exclude() -> None:
    tf1 = build_tf1_template()
    assert tf1.maturity is TemplateMaturity.CONCRETE
    assert tf1.category is IterationCategory.FEATURE
    assert "feature_triage_has_stop" in tf1.preconditions
    assert "has_clean_validity" in tf1.preconditions
    assert Severity.BLOCKING in tf1.forbidden_when

    assert len(tf1.allowed_overrides) == 1
    spec = tf1.allowed_overrides[0]
    assert spec.path_template == "config/training/{label}.yaml"
    assert spec.yaml_path == ("features", "exclude")
    assert spec.value_type == "list[str]"

    forbidden = set(tf1.forbidden_paths)
    for guard in (("evaluation",), ("costs",), ("labels",), ("universe",)):
        assert guard in forbidden


def test_tf1_template_family_pipeline() -> None:
    """Family parametrizes the retrain script (07_gbm vs 06_linear)."""

    gbm = build_tf1_template(family="gbm")
    linear = build_tf1_template(family="linear")
    assert gbm.stage_invocations[0].script == "07_gbm.py"
    assert linear.stage_invocations[0].script == "06_linear.py"
    for tpl in (gbm, linear):
        scripts = [s.script for s in tpl.stage_invocations]
        assert "13_model_analysis.py" in scripts
        assert "14_backtest.py" in scripts
        assert "18_strategy_analysis.py" in scripts


def test_tf1_template_unknown_family_falls_back_to_gbm() -> None:
    """Mirrors T-A2 contract: unknown family falls back to the GBM pipeline."""

    tpl = build_tf1_template(family="unknown_family")
    assert tpl.stage_invocations[0].script == "07_gbm.py"


def test_tf1_delta_criterion_is_within_family_delta() -> None:
    tf1 = build_tf1_template()
    crit = tf1.delta_criterion_template
    assert crit.primary_metric == "mean_fold_ic_within_family"
    assert crit.metric_kind == "delta"
    assert crit.direction == "higher_is_better"
    assert crit.noise_floor_method == "hac_newey_west_21d"
    assert crit.support_threshold == pytest.approx(0.005)
    assert crit.reject_threshold == pytest.approx(-0.003)


def test_tf1_overridespec_validates_list_str() -> None:
    """The OverrideSpec accepts a list of feature-name strings and rejects
    other shapes — mirrors the T-M1 pattern."""

    spec = build_tf1_template().allowed_overrides[0]
    spec.validate_value(["regime_x", "lookahead_pe"])
    with pytest.raises(PlanValidationError, match="list\\[str\\]"):
        spec.validate_value([1, 2])
    with pytest.raises(PlanValidationError, match="list\\[str\\]"):
        spec.validate_value("regime_x")


# --- T-R1 (tighter_top_n) ---------------------------------------------------


def test_tr1_template_overrides_top_n() -> None:
    tr1 = build_tr1_template()
    assert tr1.template_id == "T-R1"
    assert tr1.maturity is TemplateMaturity.CONCRETE
    assert tr1.category is IterationCategory.RISK
    assert "signal_positive_net_weak" in tr1.preconditions
    assert "has_clean_validity" in tr1.preconditions
    assert Severity.BLOCKING in tr1.forbidden_when
    assert Severity.MATERIAL in tr1.forbidden_when

    assert len(tr1.allowed_overrides) == 1
    spec = tr1.allowed_overrides[0]
    assert spec.path_template == "config/setup.yaml"
    assert spec.yaml_path == ("mapping", "tunable_params", "top_n")
    assert spec.value_type == "int"
    assert spec.allowed_values == (5, 10, 15, 20)
    assert spec.direction == "narrower_only"

    forbidden = set(tr1.forbidden_paths)
    for guard in (("evaluation",), ("costs",), ("labels",), ("universe",)):
        assert guard in forbidden


def test_tr1_template_stages_skip_retrain() -> None:
    """T-R1 changes only the portfolio-construction step; predictions are
    reused, so no retrain (06/07) and no model_analysis (13) — just 15 → 14
    → 18."""

    tr1 = build_tr1_template()
    scripts = [s.script for s in tr1.stage_invocations]
    assert scripts == [
        "15_portfolio_management.py",
        "14_backtest.py",
        "18_strategy_analysis.py",
    ]


def test_tr1_delta_criterion_is_net_sharpe_delta() -> None:
    tr1 = build_tr1_template()
    crit = tr1.delta_criterion_template
    assert crit.primary_metric == "net_sharpe"
    assert crit.metric_kind == "delta"
    assert crit.direction == "higher_is_better"
    assert crit.noise_floor_method == "hac_newey_west_21d"
    assert crit.support_threshold == pytest.approx(0.10)
    assert crit.reject_threshold == pytest.approx(-0.10)


def test_tr1_overridespec_validates_int_range_and_allowed_values() -> None:
    """The OverrideSpec accepts only the allowed integer top_n values; floats,
    out-of-range, and non-integer values are rejected."""

    spec = build_tr1_template().allowed_overrides[0]
    for v in (5, 10, 15, 20):
        spec.validate_value(v)
    # Non-allowed integer.
    with pytest.raises(PlanValidationError, match="not in"):
        spec.validate_value(7)
    # Non-int.
    with pytest.raises(PlanValidationError, match="expected int"):
        spec.validate_value(10.0)
    with pytest.raises(PlanValidationError, match="expected int"):
        spec.validate_value("10")
    # Bool is explicitly excluded from int.
    with pytest.raises(PlanValidationError, match="expected int"):
        spec.validate_value(True)
    # Below min — covered by allowed_values check, but range is also pinned.
    with pytest.raises(PlanValidationError):
        spec.validate_value(3)
    with pytest.raises(PlanValidationError):
        spec.validate_value(25)
