"""v0.6 proposer tests — T-R1 (tighter_top_n).

Mirrors the v0.4 (T-F1) and v0.2 (T-M1) test patterns: wire a
`MockLLMClient` to return a hand-written T-R1 proposal, confirm the
eligible-set arithmetic on a tailored EvidencePack where
`signal_positive_net_weak` fires (significant in-sample IC, but
strategy net Sharpe at-or-below benchmark), and assert the proposer
constructs a valid plan that round-trips through `validate_plan`.

The book-repo seam (`15_portfolio_management.py` reading
`mapping.tunable_params.top_n`) is the cross-repo half of this
milestone; the library contract is "if you accept the override, the
runner reads it."
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any

import pytest

from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    BacktestSummary,
    EvidencePack,
    LineState,
    PlanValidationError,
    validate_plan,
)
from ml4t.agent.tools.proposals import (
    build_tr1_template,
    default_templates,
    propose_experiments,
)


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def _make_responder(proposals: list[dict[str, Any]]):
    def responder(_messages: Sequence[Message], _schema: Mapping[str, Any]) -> LLMResponse:
        payload = {"proposals": proposals}
        return LLMResponse(data=payload, raw=str(payload))

    return responder


# --- T-R1 fixtures ----------------------------------------------------------


def _tr1_proposal(
    *,
    experiment_id: str = "E-tr1-1",
    top_n: int = 10,
) -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-R1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": (
            "tightening top_n from 20 to 10 concentrates weight on the "
            "highest-conviction names and recovers a net edge over the benchmark"
        ),
        "rationale": (
            "ic_t_stat=2.6 indicates a real signal; benchmark net_sharpe (0.30) "
            "exceeds strategy net_sharpe (0.25), suggesting portfolio dilution"
        ),
        "config_patches": [
            {
                "path_template": "config/setup.yaml",
                "path_variables": {},
                "yaml_path": ["mapping", "tunable_params", "top_n"],
                "new_value": top_n,
            }
        ],
    }


@pytest.fixture
def tr1_pack(sample_pack: EvidencePack) -> EvidencePack:
    """Clean validity + signal-positive-net-weak: ic_t_stat is already 2.6
    in sample_pack; flip the strat-gbm net_sharpe so it falls at-or-below
    the benchmark (0.30)."""

    new_backtests = tuple(
        BacktestSummary(
            config_id=b.config_id,
            family=b.family,
            gross_sharpe=b.gross_sharpe,
            net_sharpe=(0.25 if b.family == "gbm" else b.net_sharpe),
            max_drawdown=b.max_drawdown,
            mean_monthly_turnover=b.mean_monthly_turnover,
            edge_to_cost_ratio=b.edge_to_cost_ratio,
        )
        for b in sample_pack.validation.backtests
    )
    new_validation = replace(sample_pack.validation, backtests=new_backtests)
    return replace(sample_pack, warnings=(), validation=new_validation)


# --- eligibility / proposer ------------------------------------------------


def test_tr1_eligible_when_signal_positive_net_weak(
    tr1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_tr1_proposal()]))
    plans = propose_experiments(tr1_pack, llm=llm, line_state=line_state)
    assert [p.template_id for p in plans] == ["T-R1"]
    plan = plans[0]
    assert plan.config_patches[0].yaml_path == ("mapping", "tunable_params", "top_n")
    assert plan.config_patches[0].new_value == 10
    assert plan.delta_criterion.primary_metric == "net_sharpe"
    assert plan.delta_criterion.metric_kind == "delta"


def test_tr1_plan_round_trips_validation(
    tr1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_tr1_proposal()]))
    plans = propose_experiments(tr1_pack, llm=llm, line_state=line_state)
    plan = plans[0]
    validate_plan(plan, build_tr1_template(), tr1_pack, line_state)


def test_tr1_ineligible_on_default_pack(
    sample_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """Default `sample_pack` has strategy net_sharpe (0.60) > benchmark
    (0.30), so `signal_positive_net_weak` returns False → T-R1 ineligible.
    sample_pack also carries a MATERIAL warning, which independently makes
    T-R1 ineligible via has_clean_validity. With no eligible templates the
    LLM is never called and `propose_experiments` returns []."""

    plans = propose_experiments(
        sample_pack,
        llm=MockLLMClient(responder=_make_responder([_tr1_proposal()])),
        line_state=line_state,
    )
    assert plans == []


def test_tr1_invalid_top_n_value_rejected(
    tr1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """LLM returns top_n=7 — outside the allowed_values set (5/10/15/20).
    The proposer should reject the plan rather than silently accepting it."""

    bad = _tr1_proposal(top_n=7)
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError):
        propose_experiments(tr1_pack, llm=llm, line_state=line_state)


def test_tr1_invalid_value_type_rejected(
    tr1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """LLM returns top_n as a string — value_type='int' should reject it."""

    bad = _tr1_proposal()
    bad["config_patches"][0]["new_value"] = "10"
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError):
        propose_experiments(tr1_pack, llm=llm, line_state=line_state)


def test_default_catalogue_includes_tr1(tr1_pack: EvidencePack) -> None:
    """When given a tr1-eligible pack, `default_templates` includes T-R1."""

    catalogue = default_templates(evidence=tr1_pack)
    tr1 = next(t for t in catalogue if t.template_id == "T-R1")
    # Stages don't depend on family for T-R1 — predictions are reused.
    assert [s.script for s in tr1.stage_invocations] == [
        "15_portfolio_management.py",
        "14_backtest.py",
        "18_strategy_analysis.py",
    ]
