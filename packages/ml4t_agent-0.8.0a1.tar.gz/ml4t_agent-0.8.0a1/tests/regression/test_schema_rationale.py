"""Plan-31 §v0.7 schema audit — every public schema has a documented rationale.

The schema rationale doc (`docs/user-guide/schema-rationale.md`)
explains why each public dataclass / enum / typed exception in
`ml4t.agent.schemas` earns its place in the chapter narrative.

This test enforces the audit forward: every name in
`ml4t.agent.schemas.__all__` must appear in the doc. Adding a new
public schema without a rationale row fails the suite, forcing the
question 'why does this earn its place?' at PR-review time.

Removals from `__all__` don't need a rationale row (deletions are
clean-ups, not additions); the API freeze test in
`test_public_api_freeze.py` catches accidental removals.
"""

from __future__ import annotations

import re
from pathlib import Path

import ml4t.agent.schemas

# These exports are verified-real-symbol checked elsewhere; the rationale
# doc deliberately covers them under one shared row to avoid bloat.
_RATIONALE_DOC = Path(__file__).resolve().parents[2] / "docs" / "user-guide" / "schema-rationale.md"

# Type aliases / module-level constants documented under one row.
_AGGREGATE_ROWS: dict[str, str] = {
    "PathTemplate": "PathTemplate, ValueTypeName",
    "ValueTypeName": "PathTemplate, ValueTypeName",
}

# Names whose chapter rationale is intentionally bundled into another
# row's prose (e.g. recommend_decision is described under DeltaReview).
_BUNDLED_NAMES: frozenset[str] = frozenset(
    {
        "recommend_decision",  # described under DeltaCriterion / DeltaReview
        "validate_plan",  # described under PlanValidationError + Refusal entries
        # Predicate functions: they are documented as a group under PREDICATES.
        "feature_triage_has_stop",
        "gbm_baseline_present",
        "gbm_dispersion_large",
        "has_clean_validity",
        "holdout_sealed",
        "linear_baseline_present",
        "methodology_warning_cites_lineage",
        "methodology_warning_present",
        "regime_features_available",
        "signal_positive_net_weak",
        "turnover_high",
    }
)


def _read_doc_text() -> str:
    assert _RATIONALE_DOC.is_file(), f"rationale doc missing at {_RATIONALE_DOC}"
    return _RATIONALE_DOC.read_text(encoding="utf-8")


def test_rationale_doc_exists_and_has_a_row_for_every_public_export() -> None:
    """Every name in `ml4t.agent.schemas.__all__` either:

    1. appears as a backtick-wrapped token in the rationale doc, or
    2. is in the explicit ``_BUNDLED_NAMES`` set (documented as a group).
    """

    text = _read_doc_text()
    public_names = set(getattr(ml4t.agent.schemas, "__all__", ()))
    assert public_names, "ml4t.agent.schemas exposes no __all__"

    missing: list[str] = []
    for name in sorted(public_names):
        if name in _BUNDLED_NAMES:
            continue
        # Backtick-wrapped match in any markdown table cell or prose.
        pattern = rf"`{re.escape(name)}`"
        if not re.search(pattern, text):
            missing.append(name)

    assert not missing, (
        "schema-rationale.md is missing rows for the following public schema "
        f"names — add them or move them into _BUNDLED_NAMES: {missing}"
    )


def test_rationale_doc_does_not_reference_deleted_symbols() -> None:
    """The doc shouldn't reference symbols that no longer exist in the
    schemas package — that would mislead chapter readers.

    This complements the freeze test: the freeze catches accidental
    removals from `__all__`; this catches stale references that
    survived a removal."""

    text = _read_doc_text()
    public_names = set(getattr(ml4t.agent.schemas, "__all__", ()))

    # Grep for backtick-wrapped CapWords tokens that LOOK like dataclass
    # references (uppercase first letter, no spaces). Whitelist Python
    # builtins / external types we deliberately reference in prose.
    whitelisted = frozenset(
        {
            # Python / typing names that may appear in prose for context.
            "ImportError",
            "ValueError",
            "Exception",
            "Enum",
            "True",
            "False",
            # External library / module names.
            "Severity.BLOCKING",
            "Severity.MATERIAL",
            "Severity.WARNING",
        }
        | _BUNDLED_NAMES
        # Methods / fields that legitimately appear in prose under their owner row.
        | {
            "is_eligible",
            "validate_value",
            "evidence_refs",
            "triggering_field",
            "best_mean_ic",
            "ic_t_stat",
            "net_sharpe",
            "config_patches",
            "tunable_params",
            "delta_criterion",
            "iteration_index",
            "base_alpha",
            "bonferroni_k",
            "best_family",
            "best_config",
            "category",
            "maturity",
            "review_verdict",
            "decision",
            "package_versions",
            "fold_ic_std",
            "mean_fold_ic",
            "stage_invocations",
            "expected_artifacts",
            "from_config",
            "yaml_path",
            "value_type",
            "allowed_values",
            "path_template",
            "path_variables",
            "new_value",
            "narrowed_runs",
            "parent_baseline",
            "mean_fold_ic_after",
            "git_sha",
            "presets_tried",
            "config_name",
            "kind",
            "tools",
            "executors",
            "schemas",
            "fixtures",
            "predicates",
            "lineage",
            "validation",
            "evaluation",
            "costs",
            "labels",
            "universe",
            "T-C1",
            "T-A2",
            "T-M1",
            "T-F1",
            "T-R1",
            "MODEL",
            "FEATURE",
            "RISK",
            "COST",
            "AUDIT",
            "BLOCKING",
            "MATERIAL",
            "WARNING",
            "CONCRETE",
            "CANDIDATE",
            "STOP",
            "Both",
            "If",
            "Removing",
            "Type",
        }
    )

    # Capture backtick tokens that look like Python identifiers or dotted paths.
    candidates: set[str] = set()
    for match in re.finditer(r"`([A-Za-z_][A-Za-z0-9_.]*)`", text):
        token = match.group(1)
        # Only consider tokens that *could* be a public schema name —
        # uppercase first letter, no '.' (dotted paths are namespaces).
        if "." in token:
            continue
        if not token[0].isupper():
            continue
        candidates.add(token)

    stale = sorted(t for t in candidates if t not in public_names and t not in whitelisted)
    assert not stale, (
        "schema-rationale.md references symbols that aren't in "
        f"ml4t.agent.schemas.__all__ — clean up these stale refs: {stale}"
    )
