"""Held-out fixture — futures momentum panel.

A hand-built `EvidencePack` representing a *different* strategy on a
*different* universe than the v0.1–v0.6 fixtures (which were ETF
rotation). Plan-31 §v0.7 calls this the non-circularity check: if the
predicates fire correctly on a fixture they were not co-developed
against, they're doing real gating work.

See `README.md` in this directory for the contrast with the existing
fixtures and the expected agent behaviour.
"""

from __future__ import annotations

from ml4t.agent.schemas import (
    BacktestSummary,
    CostSummary,
    Determinism,
    EvidencePack,
    LineageSummary,
    MethodologyWarning,
    ModelRunSummary,
    RobustnessSummary,
    Severity,
    SignalSummary,
    ValidationDesign,
    ValidationMetrics,
)


def build_futures_momentum_pack() -> EvidencePack:
    """Daily long/short on 12 CME futures contracts."""

    return EvidencePack(
        case_study="cme_futures_momentum",
        objective="daily long/short on liquid CME futures (12 contracts)",
        primary_label="ret_1d",
        horizon="1d",
        cadence="daily",
        parent_run_id="P-FUT-1",
        line_id="L-FUT-1",
        validation_design=ValidationDesign(
            n_splits=12,
            train_size="48m",
            val_size="2m",
            holdout_start="2023-01-01",
            holdout_end="2024-12-31",
            embargo_days=2,
            purge_days=1,
            fold_calendar_id="cal:cme",
        ),
        validation=ValidationMetrics(
            model_runs=(
                ModelRunSummary(
                    family="linear",
                    config_name="ridge_l2",
                    label="ret_1d",
                    mean_fold_ic=0.005,
                    fold_ic_std=0.011,
                    fold_sharpe_mean=0.10,
                    fold_sharpe_std=0.22,
                    n_folds=12,
                ),
                ModelRunSummary(
                    family="gbm",
                    config_name="lgb_d4",
                    label="ret_1d",
                    mean_fold_ic=0.009,
                    fold_ic_std=0.014,
                    fold_sharpe_mean=0.18,
                    fold_sharpe_std=0.21,
                    n_folds=12,
                ),
                ModelRunSummary(
                    family="dl",
                    config_name="mlp_d3",
                    label="ret_1d",
                    mean_fold_ic=0.008,
                    fold_ic_std=0.018,
                    fold_sharpe_mean=0.13,
                    fold_sharpe_std=0.25,
                    n_folds=12,
                ),
            ),
            signal=SignalSummary(
                # Significantly weaker signal than the ETF fixtures' 2.6:
                # this is "do we even have a signal?" territory, which
                # gates T-R1 from firing.
                best_family="gbm",
                best_config="lgb_d4",
                best_mean_ic=0.009,
                ic_t_stat=1.4,
                horizons_tested=("1d", "5d"),
            ),
            backtests=(
                BacktestSummary(
                    config_id="bench-buyhold",
                    family="benchmark",
                    gross_sharpe=0.42,
                    net_sharpe=0.32,
                    max_drawdown=-0.22,
                    mean_monthly_turnover=0.00,
                    edge_to_cost_ratio=float("inf"),
                ),
                BacktestSummary(
                    config_id="strat-gbm",
                    family="gbm",
                    gross_sharpe=0.55,
                    net_sharpe=0.18,
                    max_drawdown=-0.27,
                    mean_monthly_turnover=0.85,
                    edge_to_cost_ratio=0.55,
                ),
            ),
            robustness=RobustnessSummary(
                fold_sharpe_dispersion=0.21,
                regime_breakdown_available=False,
                seed_variance_estimate=0.05,
            ),
        ),
        holdout=None,
        costs=CostSummary(
            per_leg_bps_low=0.5,
            per_leg_bps_high=2.5,
            cost_class="futures_with_funding",
            components=("commission", "spread", "funding"),
        ),
        lineage=LineageSummary(
            git_sha="def5678",
            data_snapshot_id="snap-2024-12-31-cme",
            config_hash="cfg-fut-3a",
            package_versions={"ml4t-data": "0.1.0a4", "ml4t-engineer": "0.1.0a5"},
        ),
        warnings=(
            # Lineage-citing warning: triggers T-A2's eligibility.
            MethodologyWarning(
                code="LINEAGE_GAP",
                message=(
                    "package_versions at parent run differ from current head; "
                    "ml4t-engineer 0.1.0a5 → 0.1.0b1 includes feature-eng changes; "
                    "lineage rerun recommended"
                ),
                severity=Severity.MATERIAL,
                determinism=Determinism.RUNNER_CONTRACT,
                triggering_artifact="lineage/package_versions.json",
                triggering_field="lineage.package_versions",
            ),
        ),
        diagnostics=(),
        # `triage` and `preset_registry` deliberately left as None: this
        # fixture exercises the "runner contract pending" path for
        # T-F1's predicate.
    )
