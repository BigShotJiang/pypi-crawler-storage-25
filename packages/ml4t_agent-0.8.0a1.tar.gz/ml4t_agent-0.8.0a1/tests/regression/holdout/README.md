# Held-out fixture — non-circularity check

Plan-31 §v0.7's required artefact. The eligibility predicates and the
catalogue templates were co-developed against the `sample_pack` /
`clean_pack` / `tr1_pack` / `tf1_pack` fixtures in
`tests/conftest.py` and `tests/tools/test_proposals_v0*.py`. Without a
held-out fixture, every "the agent proposes the right templates"
assertion is potentially circular: the templates were shaped to fire
on the fixtures.

This directory ships **`futures_momentum_pack.py`**, a hand-built
`EvidencePack` for a *different strategy on a different universe*:

| Attribute | ETF fixtures (existing) | Held-out futures fixture |
|-----------|-------------------------|--------------------------|
| Case study ID | `etfs` | `cme_futures_momentum` |
| Universe | 100 US sector ETFs | 12 liquid CME futures contracts |
| Cadence | weekly | daily |
| Primary label | `ret_5d` | `ret_1d` |
| Model families present | linear, gbm | linear, gbm, **dl** |
| Signal IC t-stat | 2.6 (positive) | 1.4 (weak) |
| Strategy net Sharpe vs benchmark | strategy > benchmark (0.60 vs 0.30) | strategy < benchmark (0.18 vs 0.32) |
| Cost class | `liquid_etf_blend` | `futures_with_funding` |
| Methodology warnings | one MATERIAL leak-risk on `regime_x` | one MATERIAL lineage gap (cites `package_versions` mismatch) |
| Triage exposure | `None` | `None` (runner contract still pending in this fixture) |

## What was *not* tuned for this fixture

- **No predicate was adjusted** to match the held-out pack's metrics.
  The existing predicates (`has_clean_validity`,
  `signal_positive_net_weak`, `methodology_warning_cites_lineage`,
  `gbm_baseline_present`, `gbm_dispersion_large`,
  `feature_triage_has_stop`, etc.) were frozen at v0.6.0a2.
- **No threshold was adjusted.** The IC t-stat threshold (2.0) and
  the net-Sharpe-vs-benchmark comparison are unchanged.
- **No template factory was adjusted.** The five
  `build_t*_template()` factories are byte-identical to v0.6.0a2.

## Expected agent behaviour on this fixture

The pack carries:
- A MATERIAL methodology warning citing `lineage` ⇒ `methodology_warning_cites_lineage` fires ⇒ **T-A2 eligible**.
- `ic_t_stat = 1.4` (< 2.0) ⇒ `signal_positive_net_weak` returns False ⇒ **T-R1 ineligible** even though strategy net < benchmark.
- A MATERIAL warning is present ⇒ `has_clean_validity` returns False ⇒ **T-C1, T-M1, T-F1 all ineligible** (their `forbidden_when`/preconditions exclude MATERIAL severity).
- `triage` is `None` ⇒ `feature_triage_has_stop` raises `PredicateUnavailable` ⇒ **T-F1 ineligible** for a separate reason (runner contract pending).

So on the held-out fixture, the agent should propose **T-A2 only**.
That is the predicate-discriminating behaviour the held-out test
asserts.

## Why this is non-circular

- The held-out pack was constructed **after** v0.6.0a2 shipped; no
  predicate was retuned to make it eligible-for-T-A2.
- The pack's metrics are *different shapes* from any existing
  fixture (different families, different cadence, different IC
  magnitude).
- The expected behaviour above falls out of the predicate logic
  applied to the pack's metrics — no test author could "cheat"
  this without modifying the predicate code, which the freeze
  test in `test_public_api_freeze.py` would catch.

## Drift detector

If the held-out test starts failing (e.g. T-A2 stops firing, or T-M1
starts firing), it means either:
1. A predicate was changed in a way that broke generalization.
2. A template's preconditions were re-shuffled.
3. A `Severity` enum entry was renamed.

Each of those is a real signal worth investigating before merging.
