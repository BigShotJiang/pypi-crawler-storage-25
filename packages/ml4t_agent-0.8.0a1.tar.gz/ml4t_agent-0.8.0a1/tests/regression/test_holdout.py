"""Plan-31 §v0.7 held-out regression — non-circularity check.

The eligibility predicates and the catalogue templates were
co-developed against the ETF fixtures in `tests/conftest.py` and
`tests/tools/test_proposals_v0*.py`. This test exercises them against
a *different* fixture (futures momentum panel — see
`tests/regression/holdout/futures_momentum_pack.py`) that was
constructed **after** v0.6.0a2 shipped and has not driven any
predicate adjustments.

The expected behaviour falls out of the predicate logic applied to the
held-out pack's metrics; see `tests/regression/holdout/README.md` for
the predicate-by-predicate walk-through.

Plan-31 acceptance bar 3:
    "Held-out fixture works: v0.7's held-out scenario produces
     reasonable proposals without predicate retuning."
"""

from __future__ import annotations

# The held-out fixture lives next to its README. Resolve it via path
# rather than a relative import so the file is importable when pytest
# discovers tests as a flat namespace (no `tests/__init__.py`).
import importlib.util as _ilu
import sys as _sys
from pathlib import Path as _Path

import pytest

from ml4t.agent.llm import LLMResponse, MockLLMClient
from ml4t.agent.schemas import (
    EvidencePack,
    LineState,
    PredicateUnavailable,
    Severity,
)
from ml4t.agent.schemas.evidence import (
    feature_triage_has_stop,
    has_clean_validity,
    methodology_warning_cites_lineage,
    signal_positive_net_weak,
)
from ml4t.agent.tools import default_templates, propose_experiments

_HOLDOUT_PATH = _Path(__file__).parent / "holdout" / "futures_momentum_pack.py"
_spec = _ilu.spec_from_file_location("_holdout_futures_momentum_pack", _HOLDOUT_PATH)
assert _spec is not None and _spec.loader is not None
_holdout_mod = _ilu.module_from_spec(_spec)
_sys.modules[_spec.name] = _holdout_mod
_spec.loader.exec_module(_holdout_mod)
build_futures_momentum_pack = _holdout_mod.build_futures_momentum_pack


@pytest.fixture
def holdout_pack() -> EvidencePack:
    return build_futures_momentum_pack()


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-FUT-1", iteration_index=1, base_alpha=0.05)


# --- Predicate-level non-circularity checks ---------------------------------


def test_holdout_has_clean_validity_returns_false_due_to_material_warning(
    holdout_pack: EvidencePack,
) -> None:
    """The fixture carries one MATERIAL methodology warning; predicate gates T-C1/T-M1/T-F1/T-R1."""

    assert has_clean_validity(holdout_pack) is False


def test_holdout_methodology_warning_cites_lineage_returns_true(
    holdout_pack: EvidencePack,
) -> None:
    """The fixture's MATERIAL warning cites a lineage gap; predicate fires for T-A2."""

    assert methodology_warning_cites_lineage(holdout_pack) is True


def test_holdout_signal_positive_net_weak_returns_false_due_to_low_t_stat(
    holdout_pack: EvidencePack,
) -> None:
    """ic_t_stat=1.4 (< 2.0) ⇒ predicate returns False even though
    strategy net_sharpe (0.18) < benchmark (0.32). T-R1 should not fire
    on a fixture where the signal isn't statistically significant."""

    assert signal_positive_net_weak(holdout_pack) is False


def test_holdout_feature_triage_unavailable_when_triage_is_none(
    holdout_pack: EvidencePack,
) -> None:
    """Runner contract for triage is not exposed on this fixture;
    predicate raises `PredicateUnavailable` rather than silently
    returning False."""

    assert holdout_pack.triage is None
    with pytest.raises(PredicateUnavailable):
        feature_triage_has_stop(holdout_pack)


# --- Catalogue eligibility on the held-out pack -----------------------------


def test_default_catalogue_eligible_set_on_holdout_is_T_A2_only(
    holdout_pack: EvidencePack,
) -> None:
    """The composite predicate logic on the held-out pack should
    leave **only T-A2** eligible:

    - T-C1: forbidden by MATERIAL warning + has_clean_validity False.
    - T-A2: eligible (lineage warning).
    - T-M1: forbidden by MATERIAL warning.
    - T-F1: forbidden by MATERIAL warning + triage unavailable.
    - T-R1: forbidden by MATERIAL warning + ic_t_stat < 2.

    If this set drifts (e.g. T-R1 starts firing), some predicate or
    template was retuned in a way that broke generalization — the
    held-out test catches that before merge.
    """

    catalogue = default_templates(evidence=holdout_pack)
    eligibility = {t.template_id: t.is_eligible(holdout_pack)[0] for t in catalogue}
    assert eligibility == {
        "T-C1": False,
        "T-A2": True,
        "T-M1": False,
        "T-F1": False,
        "T-R1": False,
    }


def test_holdout_t_a2_predicate_chain_traces_to_concrete_warning(
    holdout_pack: EvidencePack,
) -> None:
    """T-A2's eligibility on the held-out pack must be traceable to a
    specific MethodologyWarning citing lineage — not a generic
    'something looked off'. Plan-31 §v0.7 acceptance bar: 'a reader
    can trace the reviewer's reasoning to a specific field in the
    EvidencePack.'"""

    lineage_warnings = [
        w
        for w in holdout_pack.warnings
        if w.severity == Severity.MATERIAL
        and (
            "lineage" in (w.triggering_field or "").lower()
            or "lineage" in (w.code or "").lower()
            or "lineage" in (w.message or "").lower()
        )
    ]
    assert len(lineage_warnings) == 1, (
        "T-A2 eligibility on the holdout pack must trace to exactly one "
        "lineage-citing MATERIAL warning"
    )


# --- Proposer-loop behaviour on the held-out pack ---------------------------


def test_holdout_proposer_returns_only_T_A2_or_empty(
    holdout_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """Wire the held-out pack through `propose_experiments` with a
    MockLLMClient that returns a T-A2 proposal — assert the proposer
    accepts it (no false-refusal from `validate_plan`).

    This is the load-bearing assertion: the agent's full plan→validate
    chain works on a fixture it was not co-developed against. If a
    drift caused `validate_plan` to falsely refuse the T-A2 plan on
    this pack, this test fires.
    """

    def responder(_messages, _schema):
        payload = {
            "proposals": [
                {
                    "experiment_id": "E-holdout-A2",
                    "template_id": "T-A2",
                    "comparison_target_id": "strat-gbm",
                    "hypothesis": (
                        "lineage warning cites a package_versions diff against "
                        "the parent run; rerunning the GBM baseline at HEAD "
                        "should reproduce within 0.002 of the prior IC if no "
                        "lineage gap exists"
                    ),
                    "rationale": (
                        "the methodology warning at "
                        "lineage.package_versions is MATERIAL severity; T-A2 "
                        "is the audit template that addresses this directly"
                    ),
                    "config_patches": [],  # T-A2 is a pure rerun
                }
            ]
        }
        return LLMResponse(data=payload, raw=str(payload))

    llm = MockLLMClient(responder=responder)
    plans = propose_experiments(holdout_pack, llm=llm, line_state=line_state)

    assert [p.template_id for p in plans] == ["T-A2"]
    plan = plans[0]
    assert plan.parent_run_id == holdout_pack.parent_run_id
    assert plan.config_patches == ()  # pure rerun
    # The delta_criterion's absolute thresholds derive from the parent's
    # best_mean_ic (0.009 in this fixture); assert the parametrization works
    # without retuning.
    crit = plan.delta_criterion
    assert crit.primary_metric == "mean_fold_ic"
    assert crit.metric_kind == "absolute"
    assert crit.support_threshold == pytest.approx(0.009 - 0.002)
    assert crit.reject_threshold == pytest.approx(0.009 - 0.010)


def test_holdout_proposer_returns_empty_when_no_eligible_templates(
    holdout_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """If the LLM hallucinates a T-R1 proposal on the held-out pack,
    `propose_experiments` should return [] (T-R1 is ineligible) rather
    than constructing a malformed plan. The eligibility filter is the
    safety net."""

    def responder(_messages, _schema):
        # Hand the proposer a T-R1 proposal it should never accept on this pack.
        payload = {
            "proposals": [
                {
                    "experiment_id": "E-holdout-R1-bad",
                    "template_id": "T-R1",
                    "comparison_target_id": "strat-gbm",
                    "hypothesis": "tighten top_n",
                    "rationale": "x",
                    "config_patches": [
                        {
                            "path_template": "config/setup.yaml",
                            "path_variables": {},
                            "yaml_path": ["mapping", "tunable_params", "top_n"],
                            "new_value": 5,
                        }
                    ],
                }
            ]
        }
        return LLMResponse(data=payload, raw=str(payload))

    # Restrict the catalogue to JUST T-R1 so the eligible set is empty.
    from ml4t.agent.tools.proposals import build_tr1_template

    llm = MockLLMClient(responder=responder)
    plans = propose_experiments(
        holdout_pack,
        llm=llm,
        line_state=line_state,
        templates=(build_tr1_template(),),
    )
    assert plans == [], "T-R1 must be filtered out before the LLM is even called"
