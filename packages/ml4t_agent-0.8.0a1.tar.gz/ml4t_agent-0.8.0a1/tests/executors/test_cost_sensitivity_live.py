"""Live executor regression: real `ml4t.backtest` invocation under T-C1.

Plan-31 §v0.6 acceptance bar:
    "one full agent loop on a real backtest, end-to-end, in CI, without
     ``MockLLMClient`` for the executor side."

This test is the runner-side half. The proposer is mocked elsewhere
(`tests/tools/test_proposals.py`); here the executor side runs with
real ``ml4t.backtest.run_backtest`` against a deterministic synthetic
fixture.

The fixture is generated in-test (250 bars × 1 asset) rather than
checked in as a parquet binary — keeps the repo lean and the data
semantics obvious.

Marked ``@pytest.mark.live_executor`` so the live-executor CI job is
the one that pays the wall-clock cost (~5 s); the rest of the suite is
unaffected.
"""

from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
import polars as pl
import pytest

pytestmark = pytest.mark.live_executor

# --- Fixture builder --------------------------------------------------------


def _make_prices(n_bars: int = 250, *, seed: int = 7) -> pl.DataFrame:
    """Deterministic OHLCV + signal frame.

    The signal flips every 10 bars (long-only entry on positive signal,
    exit on negative). Forces a steady cadence of trades so the cost
    differential at varying commission rates is observable.
    """

    rng = np.random.default_rng(seed)
    base_date = datetime(2024, 1, 2)
    rows = []
    close = 100.0
    for i in range(n_bars):
        # Random walk with mild drift; deterministic via seed.
        close = max(close * (1 + rng.normal(loc=0.0001, scale=0.012)), 1.0)
        open_ = close * (1 + rng.normal(scale=0.002))
        high = max(open_, close) * (1 + abs(rng.normal(scale=0.003)))
        low = min(open_, close) * (1 - abs(rng.normal(scale=0.003)))
        signal = 1.0 if (i // 10) % 2 == 0 else -1.0
        rows.append(
            {
                "timestamp": base_date + timedelta(days=i),
                "asset": "TC1",
                "open": float(open_),
                "high": float(high),
                "low": float(low),
                "close": float(close),
                "volume": 1_000_000,
                "signal": signal,
            }
        )
    return pl.DataFrame(rows)


def _build_tc1_plan(low_bps: float, high_bps: float):
    """Construct a minimal valid T-C1 plan with the cost-range patch."""

    from ml4t.agent.schemas import (
        ArtifactContract,
        ConfigPatch,
        DeltaCriterion,
        ExperimentPlan,
        StageInvocation,
    )

    crit = DeltaCriterion(
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        support_threshold=1.0,
        reject_threshold=1.0,
        direction="higher_is_better",
        noise_floor_method="simple_bootstrap",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    return ExperimentPlan(
        experiment_id="E-tc1-live",
        template_id="T-C1",
        parent_run_id="P-1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=("costs", "per_leg_cost_bps_range"),
                new_value=(float(low_bps), float(high_bps)),
            ),
        ),
        stage_invocations=(
            StageInvocation(script="16_costs.py"),
            StageInvocation(script="14_backtest.py"),
            StageInvocation(script="18_strategy_analysis.py"),
        ),
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion=crit,
        question="Does net edge survive cost realism at the upper bound?",
        hypothesis="cost stress",
        rationale="run T-C1 against real backtest",
    )


# --- Tests ------------------------------------------------------------------


def test_run_cost_sensitivity_live_returns_costsummary_and_realized_metrics() -> None:
    """The executor returns a structurally valid `CostSummary` AND a
    populated `realized_metrics` dict — the boundary contract for what
    the agent's reviewer downstream consumes."""

    from ml4t.agent.executors import LiveCostResult, run_cost_sensitivity_live
    from ml4t.agent.schemas import CostSummary

    plan = _build_tc1_plan(low_bps=5.0, high_bps=20.0)
    prices = _make_prices()

    result = run_cost_sensitivity_live(plan, prices)

    assert isinstance(result, LiveCostResult)
    assert isinstance(result.cost_summary, CostSummary)
    # Structural fields populated from the plan.
    assert result.cost_summary.per_leg_bps_low == pytest.approx(5.0)
    assert result.cost_summary.per_leg_bps_high == pytest.approx(20.0)
    assert result.cost_summary.cost_class == "material"
    assert "commission" in result.cost_summary.components
    # Realized metrics dict has the documented stable keys (NaN ok where
    # the engine omits a metric — boundary-tolerant by design).
    for key in ("sharpe", "max_drawdown", "total_return"):
        assert key in result.realized_metrics
    assert result.bars_simulated == prices.height
    # The fixture is set up to force trading; assert the backtest moved.
    assert result.n_trades > 0


def test_run_cost_sensitivity_live_is_deterministic() -> None:
    """Running the same plan against the same prices twice produces
    byte-identical realized_metrics — catches non-deterministic seeds in
    the engine."""

    from ml4t.agent.executors import run_cost_sensitivity_live

    plan = _build_tc1_plan(low_bps=5.0, high_bps=15.0)
    prices = _make_prices()

    a = run_cost_sensitivity_live(plan, prices)
    b = run_cost_sensitivity_live(plan, prices)

    assert a.cost_summary == b.cost_summary
    assert a.n_trades == b.n_trades
    # NaN-tolerant equality: same keys, same finite values, NaN ↔ NaN.
    assert a.realized_metrics.keys() == b.realized_metrics.keys()
    for key in a.realized_metrics:
        av, bv = a.realized_metrics[key], b.realized_metrics[key]
        if av != av and bv != bv:  # both NaN
            continue
        assert av == bv, f"non-deterministic metric {key}: {av} vs {bv}"


def test_higher_cost_strict_dominates_lower_in_realized_pnl() -> None:
    """Sanity: at the same trades, higher commission must produce lower
    realized total_return. If this assertion ever flips, either the
    engine's commission model is broken or the executor isn't routing
    the override through.

    Drift detector for the boundary contract: catches a future
    `commission_rate` rename in `ml4t.backtest.BacktestConfig`."""

    from ml4t.agent.executors import run_cost_sensitivity_live

    prices = _make_prices()
    cheap = run_cost_sensitivity_live(_build_tc1_plan(1.0, 1.0), prices)
    expensive = run_cost_sensitivity_live(_build_tc1_plan(50.0, 50.0), prices)

    # Both runs should have produced some trades.
    assert cheap.n_trades > 0
    assert expensive.n_trades > 0

    # And the cheap version's realized total_return must be strictly
    # higher than the expensive one's — the override has to bite.
    cheap_ret = cheap.realized_metrics["total_return"]
    expensive_ret = expensive.realized_metrics["total_return"]
    assert cheap_ret > expensive_ret, (
        f"commission override didn't bite: cheap={cheap_ret} vs expensive={expensive_ret}"
    )


def test_executor_rejects_non_tc1_plan() -> None:
    """The executor refuses plans whose template_id isn't T-C1.

    Catches a future call-site bug where someone plumbs (say) a T-M1
    plan into the cost-sensitivity executor."""

    from ml4t.agent.executors import run_cost_sensitivity_live
    from ml4t.agent.schemas import (
        ConfigPatch,
        DeltaCriterion,
        ExperimentPlan,
    )

    bad_plan = ExperimentPlan(
        experiment_id="E-not-tc1",
        template_id="T-R1",
        parent_run_id="P-1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=("mapping", "tunable_params", "top_n"),
                new_value=10,
            ),
        ),
        stage_invocations=(),
        expected_artifacts=(),
        delta_criterion=DeltaCriterion(
            primary_metric="net_sharpe",
            metric_kind="delta",
            support_threshold=0.1,
            reject_threshold=-0.1,
            direction="higher_is_better",
            noise_floor_method="hac_newey_west_21d",
            base_alpha=0.05,
            bonferroni_k=1,
        ),
        question="x",
        hypothesis="x",
        rationale="x",
    )

    prices = _make_prices(n_bars=50)
    with pytest.raises(ValueError, match="T-C1"):
        run_cost_sensitivity_live(bad_plan, prices)


def test_executor_rejects_plan_without_cost_patch() -> None:
    """A T-C1 plan that lacks the ('costs', 'per_leg_cost_bps_range')
    patch is malformed; the executor surfaces a clear error rather than
    silently using defaults."""

    from ml4t.agent.executors import run_cost_sensitivity_live
    from ml4t.agent.schemas import (
        ConfigPatch,
        DeltaCriterion,
        ExperimentPlan,
    )

    plan = ExperimentPlan(
        experiment_id="E-tc1-malformed",
        template_id="T-C1",
        parent_run_id="P-1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                # Wrong yaml_path — not the cost-range patch.
                yaml_path=("costs", "something_else"),
                new_value=(1.0, 2.0),
            ),
        ),
        stage_invocations=(),
        expected_artifacts=(),
        delta_criterion=DeltaCriterion(
            primary_metric="edge_to_cost_ratio_after",
            metric_kind="absolute",
            support_threshold=1.0,
            reject_threshold=1.0,
            direction="higher_is_better",
            noise_floor_method="simple_bootstrap",
            base_alpha=0.05,
            bonferroni_k=1,
        ),
        question="x",
        hypothesis="x",
        rationale="x",
    )

    prices = _make_prices(n_bars=50)
    with pytest.raises(ValueError, match="per_leg_cost_bps_range"):
        run_cost_sensitivity_live(plan, prices)
