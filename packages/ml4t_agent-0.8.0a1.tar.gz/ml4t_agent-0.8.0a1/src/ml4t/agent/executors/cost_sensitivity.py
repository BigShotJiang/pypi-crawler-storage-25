"""Live executor for T-C1 (`cost_realism_audit`).

Materialises the proposer's plan into a real `ml4t.backtest` invocation
and returns the realized backtest summary alongside the structural
:class:`ml4t.agent.schemas.CostSummary` contract.

The agent loop's reviewer reads the `CostSummary`'s structural fields
(`per_leg_bps_low`, `per_leg_bps_high`, `cost_class`, `components`)
unchanged from the fixture-mode tool in
:mod:`ml4t.agent.tools.reruns`. The live executor additionally returns
:class:`LiveCostResult` so calling code (and tests) can assert against
realized metrics — this is what plan-31 §v0.6 calls "fully real" for
T-C1.

Plan-31 §v0.6 acceptance: "one full agent loop on a real backtest,
end-to-end, in CI, without ``MockLLMClient`` for the executor side."
That bar is met by `run_cost_sensitivity_live` plus the
`@pytest.mark.live_executor`-tagged regression test in
``tests/executors/test_cost_sensitivity_live.py``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ml4t.agent.schemas import CostSummary, ExperimentPlan

if TYPE_CHECKING:
    import polars as pl

__all__ = [
    "LiveCostResult",
    "run_cost_sensitivity_live",
]


_INSTALL_HINT = (
    "ml4t.agent.executors requires the 'executor' extra; "
    'install with `pip install "ml4t-agent[executor]"` or add '
    "`ml4t-backtest` to your dev environment."
)


@dataclass(frozen=True)
class LiveCostResult:
    """Output of a live T-C1 backtest invocation.

    `cost_summary` is the structural contract the agent's reviewer
    consumes. `realized_metrics` carries the realized scalar metrics
    from the backtest (net Sharpe, gross Sharpe, max drawdown, total
    commissions paid) — these power the chapter-narrative claim
    "tightening costs reduced realized net Sharpe by X" without the
    reviewer having to re-derive metrics from a trade ledger.
    """

    cost_summary: CostSummary
    realized_metrics: dict[str, float]
    n_trades: int
    bars_simulated: int


def run_cost_sensitivity_live(
    plan: ExperimentPlan,
    prices: pl.DataFrame,
    *,
    signal_column: str = "signal",
    long_threshold: float = 0.0,
    exit_threshold: float = 0.0,
    initial_cash: float = 100_000.0,
    cost_class: str = "material",
    components: tuple[str, ...] = ("commission",),
) -> LiveCostResult:
    """Run a real `ml4t.backtest` invocation under the plan's cost override.

    The plan must carry exactly one `ConfigPatch` whose `yaml_path` is
    ``("costs", "per_leg_cost_bps_range")`` (the T-C1 contract). The
    high end of the range is the stress level — that's what the
    backtest commission rate is set to for the run, since T-C1's
    semantic is "does the apparent net edge survive cost realism *at
    the upper bound*?"

    Parameters
    ----------
    plan
        Validated T-C1 plan from the proposer.
    prices
        Polars DataFrame with columns ``[timestamp, symbol, open, high,
        low, close, volume]`` and a `signal_column`. The fixture data
        slice for the v0.6 acceptance test ships in
        ``tests/executors/fixtures/``; production callers supply their
        own.
    signal_column
        Name of the prediction column that drives the strategy.
    long_threshold / exit_threshold
        Trivial entry / exit thresholds for the
        :class:`~ml4t.backtest.strategies.templates.SignalFollowingStrategy`
        used by the executor. Defaults work for zero-centred signals.
    initial_cash, cost_class, components
        Backtest cash and CostSummary structural fields. The
        components tuple records which cost components were modelled;
        the v0.6 executor models commission only, so the default is
        appropriate.

    Returns
    -------
    LiveCostResult
        Structural `CostSummary` plus realized scalar metrics.

    Raises
    ------
    ImportError
        If the `executor` extra is not installed (`ml4t.backtest`
        unavailable).
    ValueError
        If the plan does not carry a single
        ``("costs", "per_leg_cost_bps_range")`` patch with a valid
        ``(low, high)`` tuple.
    """

    try:
        import polars as pl

        from ml4t.backtest import BacktestConfig, run_backtest
        from ml4t.backtest.strategies.templates import SignalFollowingStrategy
    except ImportError as exc:  # pragma: no cover - install hint
        raise ImportError(_INSTALL_HINT) from exc

    if plan.template_id != "T-C1":
        raise ValueError(f"run_cost_sensitivity_live expects a T-C1 plan, got {plan.template_id!r}")

    low, high = _extract_cost_range(plan)

    # The backtest commission_rate is a fraction (0.001 = 10 bps); the
    # plan's range is in bps. Use the high end for the stress test.
    commission_rate = high / 10_000.0

    config = BacktestConfig(
        commission_rate=commission_rate,
        slippage_rate=0.0,  # commission-only stress; isolates the override
        initial_cash=initial_cash,
    )

    # Trivial signal-following strategy: enter long when signal exceeds
    # `long_threshold`; exit when it crosses below `exit_threshold`. The
    # specific strategy is incidental — what we care about for T-C1 is
    # the **cost differential** at varying commission rates, given the
    # same signal-driven trades.
    class _TC1SignalStrategy(SignalFollowingStrategy):
        signal_column = "signal"  # ml4t.backtest convention
        position_size = 0.5
        allow_shorts = False

        def should_enter_long(self, signal: float) -> bool:
            return signal > long_threshold

        def should_exit(self, signal: float) -> bool:
            return signal < exit_threshold

    strategy = _TC1SignalStrategy()

    if signal_column not in prices.columns:
        raise ValueError(
            f"prices DataFrame must contain signal_column={signal_column!r}; "
            f"got columns {prices.columns}"
        )

    # ml4t.backtest expects an asset/timestamp identifier pair on prices
    # and a separate signals DataFrame keyed by timestamp+asset. Detect
    # the asset column (`asset` is the canonical name in fixtures; some
    # callers use `symbol`).
    asset_col = "asset" if "asset" in prices.columns else "symbol"
    if asset_col not in prices.columns:
        raise ValueError(
            f"prices DataFrame must include an 'asset' or 'symbol' column; got {prices.columns}"
        )

    signals_df = prices.select(
        [
            "timestamp",
            pl.col(asset_col).alias("asset"),
            pl.col(signal_column).alias("signal"),
        ]
    )
    # Strip the signal column from prices to keep schemas tidy.
    prices_df = prices.drop(signal_column)
    if asset_col == "symbol":
        prices_df = prices_df.rename({"symbol": "asset"})

    result = run_backtest(
        prices=prices_df,
        strategy=strategy,
        signals=signals_df,
        config=config,
    )

    realized: dict[str, float] = _summarize_metrics(result)
    n_trades = _count_trades(result)
    bars_simulated = prices.height

    cost_summary = CostSummary(
        per_leg_bps_low=float(low),
        per_leg_bps_high=float(high),
        cost_class=cost_class,
        components=tuple(components),
    )

    return LiveCostResult(
        cost_summary=cost_summary,
        realized_metrics=realized,
        n_trades=n_trades,
        bars_simulated=bars_simulated,
    )


def _extract_cost_range(plan: ExperimentPlan) -> tuple[float, float]:
    """Find the T-C1 cost-range patch and validate its shape."""

    patches = [
        p for p in plan.config_patches if tuple(p.yaml_path) == ("costs", "per_leg_cost_bps_range")
    ]
    if len(patches) != 1:
        raise ValueError(
            "T-C1 plan must carry exactly one config_patch with "
            f"yaml_path=('costs', 'per_leg_cost_bps_range'); got {len(patches)}"
        )
    value = patches[0].new_value
    if not (isinstance(value, (list, tuple)) and len(value) == 2):
        raise ValueError(f"cost-range patch new_value must be (low, high); got {value!r}")
    low_raw, high_raw = value
    if not (isinstance(low_raw, (int, float)) and isinstance(high_raw, (int, float))):
        raise ValueError(f"cost-range bounds must be numeric; got ({low_raw!r}, {high_raw!r})")
    low, high = float(low_raw), float(high_raw)
    if low < 0 or high < 0 or low > high:
        raise ValueError(f"invalid cost range: ({low}, {high})")
    return low, high


def _summarize_metrics(result: Any) -> dict[str, float]:
    """Pluck a small set of realized metrics from the BacktestResult.

    `BacktestResult.metrics` is a dict keyed by metric name. We forward
    a stable subset; missing keys map to NaN so downstream consumers
    don't crash on engine-level metric drift.
    """

    metrics = getattr(result, "metrics", None) or {}
    keys = (
        "sharpe",
        "sortino",
        "total_return",
        "annualized_return",
        "max_drawdown",
        "total_commissions",
        "n_trades",
    )
    out: dict[str, float] = {}
    for key in keys:
        raw = metrics.get(key)
        try:
            out[key] = float(raw) if raw is not None else float("nan")
        except (TypeError, ValueError):
            out[key] = float("nan")
    return out


def _count_trades(result: Any) -> int:
    """Best-effort trade count from a BacktestResult."""

    trades = getattr(result, "trades", None)
    if trades is None:
        return 0
    if hasattr(trades, "height"):
        return int(trades.height)
    try:
        return len(trades)
    except TypeError:
        return 0
