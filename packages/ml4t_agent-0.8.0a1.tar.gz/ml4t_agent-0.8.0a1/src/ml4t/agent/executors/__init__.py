"""Live executors that materialise an `ExperimentPlan`'s overrides into
real backtest invocations.

v0.6 ships **T-C1 only** (cost-realism stress test). Other catalogue
templates remain fixture-mode through the existing `run_*` helpers in
`ml4t.agent.tools.reruns`. Each promotion to a live executor is an
independent release scoped to a single template.

The runtime dependency on `ml4t.backtest` is opt-in via the `executor`
extra:

.. code-block:: bash

    pip install "ml4t-agent[executor]"

Importing :mod:`ml4t.agent.executors.cost_sensitivity` without the
extra raises a clear `ImportError` pointing at the install hint.
"""

from __future__ import annotations

from .cost_sensitivity import LiveCostResult, run_cost_sensitivity_live

__all__ = [
    "LiveCostResult",
    "run_cost_sensitivity_live",
]
