# executors/ — Live backtest invocations

The closed surface that materialises an `ExperimentPlan`'s overrides
into real backtest invocations. v0.6 ships **T-C1 only**; the other
catalogue templates (T-A2, T-M1, T-F1, T-R1) remain fixture-mode
through `ml4t.agent.tools.reruns` until subsequent releases promote
each one independently.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `__init__.py` | 25 | Re-exports `run_cost_sensitivity_live`, `LiveCostResult`, install-hint docstring |
| `cost_sensitivity.py` | 230 | T-C1 live executor — takes a plan + prices DataFrame, runs `ml4t.backtest.run_backtest`, returns `LiveCostResult(cost_summary, realized_metrics, n_trades, bars_simulated)` |

## Runtime dependency

The `executors` package depends on `ml4t-backtest`, which is **not**
in the default install. Users opt in via:

```bash
pip install "ml4t-agent[executor]"
```

Importing `ml4t.agent.executors.cost_sensitivity` without the extra
raises a clear `ImportError` referencing the install command.

## Contract

A live executor returns a `LiveCost*Result` dataclass with:
- A structural schema record matching the existing fixture-mode tool's
  output (e.g. `CostSummary` for T-C1) — the agent's reviewer reads
  this unchanged.
- `realized_metrics: dict[str, float]` with realized scalar metrics
  from the backtest. Keys are stable; missing values map to NaN so the
  reviewer survives engine-level metric drift.
- Auxiliary counts (`n_trades`, `bars_simulated`) for chapter
  narration of "we ran the backtest end-to-end".

## Testing

Each executor ships with:
- A `@pytest.mark.live_executor`-tagged regression test in
  `tests/executors/` that runs the real backtest against a
  fixture-data slice (no LLM, no network).
- A boundary-contract test asserting the executor's output schema
  matches what the agent's reviewer consumes (catches `ml4t.backtest`
  schema drift).

The fixture data is **generated** in the test rather than checked in
as a parquet binary — keeps the repo lean and the data semantics
documented inline.

## Adding an executor

1. Confirm the corresponding catalogue template is `CONCRETE` (not
   `CANDIDATE`) and the runner contract for its outputs is
   accepted.
2. Add a new module here mirroring `cost_sensitivity.py`'s shape:
   `run_<template>_live(plan, ...) -> Live<Template>Result`.
3. Import gate via the same `_INSTALL_HINT` pattern.
4. Add a `live_executor` test under `tests/executors/`.
5. Update this `AGENTS.md` and the top-level `AGENTS.md`.
6. Bump the catalogue's per-template "live" status in
   `docs/user-guide/research-loop.md`.
