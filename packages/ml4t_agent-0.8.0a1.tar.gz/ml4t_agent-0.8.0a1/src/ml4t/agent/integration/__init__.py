"""Integration / capture utilities for end-to-end agent runs.

Plan-31 §v0.8 PR1: provides a typed `CapturedRun` record and the
`capture_run` / `serialize_run` / `deserialize_run` helpers for
recording a full agent loop transcript (EvidencePack → proposer →
validate_plan → MultiAgentResult) as a JSON cassette.

The cassette format is the canonical end-to-end regression artefact
for v0.8: PR2 fills it with real captured runs (open-source +
flagship LLMs) so the chapter prose cites real numbers.
"""

from __future__ import annotations

from .capture import (
    CapturedRun,
    capture_run,
    deserialize_run,
    replay_proposer,
    serialize_run,
)

__all__ = [
    "CapturedRun",
    "capture_run",
    "deserialize_run",
    "replay_proposer",
    "serialize_run",
]
