"""Captured-run cassettes — end-to-end agent transcript serialization.

Plan-31 §v0.8 PR1. Provides :class:`CapturedRun`, a typed record
bundling EvidencePack input + LLM raw response + accepted plans +
refusals + per-step timing, plus :func:`capture_run` /
:func:`serialize_run` / :func:`deserialize_run` helpers and a
deterministic-replay path via :func:`replay_proposer`.

The cassette format is the canonical end-to-end regression artefact
for v0.8: PR2 fills it with real captured runs (open-source +
flagship LLMs) so the chapter prose cites real numbers. The format
is JSON; cassette files round-trip byte-for-byte through
``serialize_run`` → ``deserialize_run``.

Design notes
------------

- ``timing_ms`` carries optional per-stage wall-clock readings. They
  are *not* in the equality contract (replays may run on a different
  machine); the replay test asserts the *post-LLM* invariants
  (accepted/refused arity, refusal kinds) instead of the timings.
- ``llm_raw`` carries the LLM's raw response string from the proposer
  step. PR2 fills this with real provider responses; PR1 ships only
  the synthetic cassette where ``llm_raw`` is the MockLLMClient's
  echo. This is what enables deterministic replay against a captured
  cassette without touching the network.
- ``CapturedRun`` is intentionally a dataclass (not a Pydantic model)
  to match the rest of the schema surface; serialization uses
  :func:`dataclasses.asdict` + a small post-processing step for
  non-JSON-native types (frozenset, tuple).
"""

from __future__ import annotations

import json
import time
from collections.abc import Sequence
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ml4t.agent.agents import MultiAgentResult, run_proposer_with_validation
from ml4t.agent.llm import LLMClient, LLMResponse, MockLLMClient
from ml4t.agent.schemas import EvidencePack, ExperimentTemplate, LineState

__all__ = [
    "CapturedRun",
    "capture_run",
    "deserialize_run",
    "replay_proposer",
    "serialize_run",
]


@dataclass(frozen=True)
class CapturedRun:
    """Serialised end-to-end agent transcript.

    Round-trips byte-for-byte through ``serialize_run`` →
    ``deserialize_run`` provided the LLM responses are deterministic.
    PR1 ships a synthetic cassette via :class:`MockLLMClient`; PR2
    fills additional cassettes from real-LLM runs.
    """

    schema_version: str
    run_id: str
    label: str
    evidence_pack: dict[str, Any]
    line_state: dict[str, Any]
    llm_raw: str
    accepted_plans: tuple[dict[str, Any], ...]
    refusals: tuple[dict[str, Any], ...]
    cost_usd: dict[str, float] = field(default_factory=dict)
    tokens: dict[str, int] = field(default_factory=dict)
    timing_ms: dict[str, float] = field(default_factory=dict)
    notes: str = ""


_SCHEMA_VERSION = "1"


class _RecordingLLMClient:
    """Thin LLMClient wrapper that records every (request, response).

    Lets `capture_run` work with any LLMClient (Mock, Anthropic, OpenAI,
    Google) by tracking raw responses in a uniform place — independent
    of whether the underlying client exposes `.calls` or `last_response`.
    """

    def __init__(self, inner: LLMClient) -> None:
        self._inner = inner
        self.responses: list[LLMResponse] = []

    def complete_with_schema(
        self, messages, json_schema, *, max_tokens: int = 1024, temperature=0.0
    ) -> LLMResponse:
        response = self._inner.complete_with_schema(
            messages, json_schema, max_tokens=max_tokens, temperature=temperature
        )
        self.responses.append(response)
        return response


def capture_run(
    *,
    evidence_pack: EvidencePack,
    llm: LLMClient,
    line_state: LineState,
    templates: Sequence[ExperimentTemplate] | None = None,
    run_id: str = "captured-run",
    label: str = "happy_path",
    cost_usd: dict[str, float] | None = None,
    tokens: dict[str, int] | None = None,
    notes: str = "",
) -> CapturedRun:
    """Run the agent loop and return a `CapturedRun` for serialization.

    Wraps the supplied `llm` in a `_RecordingLLMClient` so the raw LLM
    response is captured regardless of which provider client is used.
    """

    recording = _RecordingLLMClient(llm)

    started = time.perf_counter()
    result: MultiAgentResult = run_proposer_with_validation(
        evidence_pack,
        llm=recording,
        line_state=line_state,
        templates=templates,
    )
    elapsed_ms = (time.perf_counter() - started) * 1000.0

    last_raw = recording.responses[-1].raw if recording.responses else ""
    aggregated_tokens: dict[str, int] = dict(tokens or {})
    for resp in recording.responses:
        for k, v in (resp.usage or {}).items():
            aggregated_tokens[k] = aggregated_tokens.get(k, 0) + int(v)

    return CapturedRun(
        schema_version=_SCHEMA_VERSION,
        run_id=run_id,
        label=label,
        evidence_pack=_pack_to_dict(evidence_pack),
        line_state={
            "line_id": line_state.line_id,
            "iteration_index": line_state.iteration_index,
            "base_alpha": line_state.base_alpha,
        },
        llm_raw=last_raw,
        accepted_plans=tuple(_plan_to_dict(p) for p in result.accepted),
        refusals=tuple(_refusal_record_to_dict(rec) for rec in result.refusals),
        cost_usd=dict(cost_usd or {}),
        tokens=aggregated_tokens,
        timing_ms={"agent_loop_total": elapsed_ms},
        notes=notes,
    )


def serialize_run(run: CapturedRun, path: Path | str) -> None:
    """Write a `CapturedRun` to disk as JSON."""

    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(run)
    out.write_text(json.dumps(payload, sort_keys=True, indent=2, default=_json_default))


def deserialize_run(path: Path | str) -> CapturedRun:
    """Read a `CapturedRun` cassette from disk."""

    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"cassette {path}: expected JSON object at top level")
    if raw.get("schema_version") != _SCHEMA_VERSION:
        raise ValueError(
            f"cassette {path}: schema_version {raw.get('schema_version')!r} != {_SCHEMA_VERSION!r}"
        )
    return CapturedRun(
        schema_version=str(raw["schema_version"]),
        run_id=str(raw["run_id"]),
        label=str(raw["label"]),
        evidence_pack=dict(raw["evidence_pack"]),
        line_state=dict(raw["line_state"]),
        llm_raw=str(raw.get("llm_raw", "")),
        accepted_plans=tuple(dict(p) for p in raw.get("accepted_plans", [])),
        refusals=tuple(dict(r) for r in raw.get("refusals", [])),
        cost_usd={str(k): float(v) for k, v in raw.get("cost_usd", {}).items()},
        tokens={str(k): int(v) for k, v in raw.get("tokens", {}).items()},
        timing_ms={str(k): float(v) for k, v in raw.get("timing_ms", {}).items()},
        notes=str(raw.get("notes", "")),
    )


def replay_proposer(captured: CapturedRun) -> dict[str, Any]:
    """Build a `MockLLMClient` whose responder replays the cassette's
    `llm_raw` proposer payload, then drive the agent loop and return
    a structural summary suitable for byte-equality assertions.

    The replay summary includes:
    - `accepted_template_ids`: tuple of template IDs in `result.accepted`
    - `refused_template_ids`: tuple of template IDs in `result.refusals`
    - `refusal_kinds`: tuple of `RefusalKind.value` strings, ordered
      by (plan_index, refusal_index)

    These are the cassette's *behavioural* invariants — what the
    chapter narrative cites — so a replay test failing means the
    library's observable behaviour drifted from the cassette.
    """

    payload = json.loads(captured.llm_raw) if captured.llm_raw else {}

    def responder(_messages, _schema):
        return LLMResponse(data=payload, raw=captured.llm_raw)

    llm = MockLLMClient(responder=responder)
    pack = _pack_from_dict(captured.evidence_pack)
    ls = LineState(
        line_id=str(captured.line_state["line_id"]),
        iteration_index=int(captured.line_state["iteration_index"]),
        base_alpha=float(captured.line_state["base_alpha"]),
    )
    result = run_proposer_with_validation(pack, llm=llm, line_state=ls)
    return {
        "accepted_template_ids": tuple(p.template_id for p in result.accepted),
        "refused_template_ids": tuple(p.template_id for p, _ in result.refusals),
        "refusal_kinds": tuple(r.kind.value for _, refusals in result.refusals for r in refusals),
    }


# --- internals --------------------------------------------------------------


def _json_default(obj: Any) -> Any:
    if isinstance(obj, frozenset | set):
        return sorted(obj)
    if isinstance(obj, tuple):
        return list(obj)
    raise TypeError(f"object of type {type(obj).__name__} is not JSON-serializable")


def _pack_to_dict(pack: EvidencePack) -> dict[str, Any]:
    return _to_jsonable(asdict(pack))


def _plan_to_dict(plan: Any) -> dict[str, Any]:
    return _to_jsonable(asdict(plan))


def _refusal_record_to_dict(record: tuple) -> dict[str, Any]:
    plan, refusals = record
    return {
        "plan": _plan_to_dict(plan),
        "refusals": [_to_jsonable(asdict(r)) for r in refusals],
    }


def _to_jsonable(obj: Any) -> Any:
    """Recursively convert a dataclass-asdict'd payload into JSON-safe
    primitives (lists, dicts, strings, numbers, bools, None)."""

    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list | tuple):
        return [_to_jsonable(v) for v in obj]
    if isinstance(obj, frozenset | set):
        return sorted(_to_jsonable(v) for v in obj)
    if hasattr(obj, "value") and hasattr(obj, "name"):  # Enum
        return obj.value
    return obj


def _pack_from_dict(payload: dict[str, Any]) -> EvidencePack:
    """Round-trip-friendly EvidencePack reconstruction.

    Reuses the existing JSON loader in `ml4t.agent.tools.evidence` —
    that has been the canonical pack→JSON deserializer since v0.6 PR1
    and handles `triage` / `preset_registry` / nested summary dataclass
    rebuilding. We delegate to it via a temp-file round-trip so the
    cassette format stays in lock-step with the runner contract.
    """

    import tempfile

    from ml4t.agent.tools.evidence import read_case_study_evidence

    with tempfile.TemporaryDirectory() as tmp:
        run_dir = Path(tmp)
        (run_dir / "evidence_pack.json").write_text(
            json.dumps(payload, sort_keys=True, default=_json_default)
        )
        return read_case_study_evidence(run_dir)
