"""LLM-bounded experiment proposer.

``propose_experiments`` is the only tool in v0.1 that calls the LLM
adapter. The LLM picks among *eligible* templates and supplies the
patch values + free-text question/hypothesis/rationale; the tool
mechanically fills in the parts the template owns (stage invocations,
artifact contracts, delta criterion, bonferroni_k from line state).

Each returned plan validates via :func:`ml4t.agent.schemas.validate_plan`
against its template. The tool raises :class:`PlanValidationError`
rather than silently dropping a malformed proposal — that surfaces a
prompt or schema bug instead of hiding it.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import replace
from typing import Any

from ml4t.agent.llm import LLMClient, Message
from ml4t.agent.schemas import (
    ArtifactContract,
    ConfigPatch,
    DeltaCriterion,
    EvidencePack,
    ExperimentPlan,
    ExperimentTemplate,
    IterationCategory,
    LineState,
    OverrideSpec,
    PlanValidationError,
    Severity,
    StageInvocation,
    TemplateMaturity,
    validate_plan,
)
from ml4t.agent.tools.evidence import summarize_run

__all__ = [
    "propose_experiments",
    "default_templates",
    "build_tc1_template",
    "build_ta2_template",
    "build_tm1_template",
    "build_tf1_template",
    "build_tr1_template",
]


def propose_experiments(
    evidence: EvidencePack,
    *,
    llm: LLMClient,
    line_state: LineState,
    templates: Sequence[ExperimentTemplate] | None = None,
    parent_run_id: str | None = None,
    max_proposals: int = 4,
    temperature: float | None = 0.0,
) -> list[ExperimentPlan]:
    """Ask the LLM to propose experiments and return validated plans.

    Parameters
    ----------
    evidence
        Frozen view of the parent run. Drives template eligibility and is
        cited in the prompt.
    llm
        Provider-agnostic adapter. Tests pass a ``MockLLMClient``.
    line_state
        Current research-line state. ``bonferroni_k`` on every returned
        plan equals ``line_state.iteration_index``.
    templates
        Catalogue to consider. Defaults to :func:`default_templates`,
        which is T-C1 only in v0.1.
    parent_run_id
        Override for the comparison parent. Defaults to
        ``evidence.parent_run_id``.
    max_proposals
        Upper bound passed to the LLM. The schema accepts up to this
        many; the model may return fewer.
    temperature
        Sampling temperature. Tests pin 0.0 for replay determinism.
        Pass ``None`` to omit the parameter (required for extended-thinking
        models such as Opus 4.7 that reject ``temperature``).

    Raises
    ------
    PlanValidationError
        If any constructed plan fails ``validate_plan`` against its
        template (malformed LLM output, unknown template_id, etc.).
    """

    catalogue = tuple(templates) if templates is not None else default_templates(evidence)
    eligible = tuple(t for t in catalogue if t.is_eligible(evidence)[0])
    if not eligible:
        return []

    parent = parent_run_id if parent_run_id is not None else evidence.parent_run_id
    schema = _build_response_schema(eligible, max_proposals=max_proposals)
    messages = _build_messages(evidence, eligible, max_proposals=max_proposals)

    response = llm.complete_with_schema(
        messages,
        schema,
        max_tokens=8192,
        temperature=temperature,
    )
    raw_proposals = response.data.get("proposals")
    if not isinstance(raw_proposals, list):
        raise PlanValidationError(
            f"LLM response missing required 'proposals' list; got {type(raw_proposals).__name__}"
        )

    by_id = {t.template_id: t for t in eligible}
    plans: list[ExperimentPlan] = []
    for entry in raw_proposals:
        plan, template = _proposal_to_plan(entry, by_id, parent, line_state)
        validate_plan(plan, template, evidence, line_state)
        plans.append(plan)
    return plans


# --- default catalogue ------------------------------------------------------


def default_templates(
    evidence: EvidencePack | None = None,
) -> tuple[ExperimentTemplate, ...]:
    """v0.6 catalogue: T-C1 (cost survival), T-A2 (lineage recheck),
    T-M1 (narrow GBM search), T-F1 (drop stop features), T-R1
    (tighter top-N).

    T-A2's delta thresholds and stage list depend on the parent run's
    best baseline (`signal.best_mean_ic`, `signal.best_family`). T-F1's
    stage list also depends on `signal.best_family` (linear → 06, gbm →
    07). When an EvidencePack is supplied, both templates are built from
    those values; otherwise placeholder defaults are used (zero IC anchor,
    GBM pipeline) — useful for tests that exercise the catalogue surface
    without needing a representative pack.
    """

    if evidence is not None:
        ta2 = build_ta2_template(
            best_mean_ic_prior=evidence.validation.signal.best_mean_ic,
            family=evidence.validation.signal.best_family,
        )
        tf1 = build_tf1_template(family=evidence.validation.signal.best_family)
    else:
        ta2 = build_ta2_template()
        tf1 = build_tf1_template()
    return (build_tc1_template(), ta2, build_tm1_template(), tf1, build_tr1_template())


def build_tc1_template() -> ExperimentTemplate:
    """T-C1 — does the apparent net edge survive cost realism?

    Same shape as the round-2 schema fixture; centralised here so the
    proposer does not need a separate template registry yet.
    """

    spec = OverrideSpec(
        path_template="config/setup.yaml",
        yaml_path=("costs", "per_leg_cost_bps_range"),
        value_type="tuple[float, float]",
        min_value=0.0,
        max_value=100.0,
        description="upper bound for stricter cost rerun",
    )
    criterion = DeltaCriterion(
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        support_threshold=1.0,
        reject_threshold=1.0,
        direction="higher_is_better",
        noise_floor_method="simple_bootstrap",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    return ExperimentTemplate(
        template_id="T-C1",
        category=IterationCategory.COST,
        maturity=TemplateMaturity.CONCRETE,
        question=("Does the apparent net edge survive cost realism at the upper bound?"),
        preconditions=("has_clean_validity",),
        forbidden_when=(Severity.BLOCKING,),
        allowed_overrides=(spec,),
        forbidden_paths=(("evaluation", "holdout_start"), ("labels",)),
        stage_invocations=(
            StageInvocation(script="16_costs.py"),
            StageInvocation(script="14_backtest.py"),
            StageInvocation(script="18_strategy_analysis.py"),
        ),
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion_template=criterion,
        expected_information_value=0.6,
        relative_cost=0.1,
    )


_T_A2_FAMILY_PIPELINES: dict[str, tuple[StageInvocation, ...]] = {
    "gbm": (
        StageInvocation(script="07_gbm.py"),
        StageInvocation(script="13_model_analysis.py"),
        StageInvocation(script="14_backtest.py"),
        StageInvocation(script="18_strategy_analysis.py"),
    ),
    "linear": (
        StageInvocation(script="06_linear.py"),
        StageInvocation(script="13_model_analysis.py"),
        StageInvocation(script="14_backtest.py"),
        StageInvocation(script="18_strategy_analysis.py"),
    ),
}


def build_ta2_template(
    *,
    best_mean_ic_prior: float = 0.0,
    family: str = "gbm",
) -> ExperimentTemplate:
    """T-A2 — does the strongest baseline reproduce at HEAD?

    Pure rerun: empty `allowed_overrides`, empty `forbidden_paths`. The
    LLM provides `experiment_id`, `comparison_target_id`, and free-text
    `hypothesis` / `rationale` only.

    `best_mean_ic_prior` parametrizes the absolute-level thresholds:
    ``support_threshold = best_mean_ic_prior - 0.002`` (the new run must
    clear the prior level minus tolerance), ``reject_threshold =
    best_mean_ic_prior - 0.010`` (drop materially below the prior level →
    contradicted; lineage gap likely).

    `family` selects the pipeline: ``"gbm"`` → 07/13/14/18; ``"linear"``
    → 06/13/14/18. Other families fall back to the GBM pipeline so the
    template still validates, with a warning expected at construction
    time of the parent EvidencePack.
    """

    stages = _T_A2_FAMILY_PIPELINES.get(family, _T_A2_FAMILY_PIPELINES["gbm"])
    criterion = DeltaCriterion(
        primary_metric="mean_fold_ic",
        metric_kind="absolute",
        support_threshold=best_mean_ic_prior - 0.002,
        reject_threshold=best_mean_ic_prior - 0.010,
        direction="higher_is_better",
        noise_floor_method="simple_bootstrap",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    return ExperimentTemplate(
        template_id="T-A2",
        category=IterationCategory.AUDIT,
        maturity=TemplateMaturity.CONCRETE,
        question=(
            "Does rerunning the strongest baseline at HEAD (same protocol, "
            "same configs) reproduce the cited result, or is there a "
            "lineage gap?"
        ),
        preconditions=("methodology_warning_cites_lineage",),
        forbidden_when=(),  # audits run regardless of severity
        allowed_overrides=(),
        forbidden_paths=(),
        stage_invocations=stages,
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion_template=criterion,
        expected_information_value=0.7,
        relative_cost=0.5,
    )


def build_tm1_template() -> ExperimentTemplate:
    """T-M1 — does a tighter GBM neighborhood improve robustness?

    One `OverrideSpec` against ``config/training/{label}.yaml`` ::
    ``("gbm",)``, ``value_type="list[str]"`` (a narrowed list of existing
    preset config_names — no new preset files). Stages cover the GBM
    retrain and downstream evaluation: 07 → 13 → 14 → 18.
    """

    spec = OverrideSpec(
        path_template="config/training/{label}.yaml",
        yaml_path=("gbm",),
        value_type="list[str]",
        description=("narrowed list of existing GBM preset config_names; no new preset files"),
    )
    criterion = DeltaCriterion(
        primary_metric="mean_fold_ic_within_family",
        metric_kind="delta",
        support_threshold=0.005,
        reject_threshold=-0.003,
        direction="higher_is_better",
        noise_floor_method="hac_newey_west_21d",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    return ExperimentTemplate(
        template_id="T-M1",
        category=IterationCategory.MODEL,
        maturity=TemplateMaturity.CONCRETE,
        question=(
            "Within the GBM family that already looks strongest on signal, "
            "does a tighter neighborhood improve robustness?"
        ),
        preconditions=(
            "has_clean_validity",
            "gbm_baseline_present",
            "gbm_dispersion_large",
        ),
        forbidden_when=(Severity.BLOCKING, Severity.MATERIAL),
        allowed_overrides=(spec,),
        forbidden_paths=(("evaluation",), ("costs",), ("labels",), ("universe",)),
        stage_invocations=(
            StageInvocation(script="07_gbm.py"),
            StageInvocation(script="13_model_analysis.py"),
            StageInvocation(script="14_backtest.py"),
            StageInvocation(script="18_strategy_analysis.py"),
        ),
        expected_artifacts=(
            ArtifactContract(
                relative_path="evaluation/triage_ledger.parquet",
                schema_id="triage_ledger_v1",
            ),
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion_template=criterion,
        expected_information_value=0.7,
        relative_cost=0.5,
    )


_T_F1_FAMILY_PIPELINES: dict[str, tuple[StageInvocation, ...]] = {
    "gbm": (
        StageInvocation(script="07_gbm.py"),
        StageInvocation(script="13_model_analysis.py"),
        StageInvocation(script="14_backtest.py"),
        StageInvocation(script="18_strategy_analysis.py"),
    ),
    "linear": (
        StageInvocation(script="06_linear.py"),
        StageInvocation(script="13_model_analysis.py"),
        StageInvocation(script="14_backtest.py"),
        StageInvocation(script="18_strategy_analysis.py"),
    ),
}


def build_tf1_template(*, family: str = "gbm") -> ExperimentTemplate:
    """T-F1 — does excluding upstream-flagged STOP features tighten signal?

    The runner's feature-audit stage emits a triage ledger; entries marked
    ``status="STOP"`` with BLOCKING/MATERIAL severity are features the
    audit said not to use (look-ahead, leakage, persistent instability).
    T-F1 derives a feature-exclusion preset that drops those features and
    reruns the strongest baseline.

    Single `OverrideSpec` against ``config/training/{label}.yaml`` ::
    ``("features", "exclude")``, ``value_type="list[str]"`` — the LLM
    supplies a list of feature names from the triage ledger; the runner
    constructs the derived preset.

    Stages cover one model retrain + downstream evaluation: 06 or 07
    (linear or gbm, picked by `family`) → 13 → 14 → 18. The eligibility
    predicate `feature_triage_has_stop` raises `PredicateUnavailable` on
    real fixtures until the v0.6 runner contract populates `pack.triage`;
    fixture-mode tests construct EvidencePacks with `triage` set
    directly.
    """

    stages = _T_F1_FAMILY_PIPELINES.get(family, _T_F1_FAMILY_PIPELINES["gbm"])
    spec = OverrideSpec(
        path_template="config/training/{label}.yaml",
        yaml_path=("features", "exclude"),
        value_type="list[str]",
        description=(
            "list of feature names to exclude from the rerun; LLM should pick from "
            "triage entries with status='STOP'"
        ),
    )
    criterion = DeltaCriterion(
        primary_metric="mean_fold_ic_within_family",
        metric_kind="delta",
        support_threshold=0.005,
        reject_threshold=-0.003,
        direction="higher_is_better",
        noise_floor_method="hac_newey_west_21d",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    return ExperimentTemplate(
        template_id="T-F1",
        category=IterationCategory.FEATURE,
        maturity=TemplateMaturity.CONCRETE,
        question=(
            "Does excluding the features the upstream audit flagged as broken "
            "(STOP-grade triage entries) tighten fold-IC dispersion or improve "
            "the within-family signal?"
        ),
        preconditions=("has_clean_validity", "feature_triage_has_stop"),
        forbidden_when=(Severity.BLOCKING,),
        allowed_overrides=(spec,),
        forbidden_paths=(("evaluation",), ("costs",), ("labels",), ("universe",)),
        stage_invocations=stages,
        expected_artifacts=(
            ArtifactContract(
                relative_path="evaluation/triage_ledger.parquet",
                schema_id="triage_ledger_v1",
            ),
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion_template=criterion,
        expected_information_value=0.65,
        relative_cost=0.5,
    )


_T_R1_ALLOWED_TOP_N: tuple[int, ...] = (5, 10, 15, 20)


def build_tr1_template() -> ExperimentTemplate:
    """T-R1 — does tightening top-N recover net edge over the benchmark?

    Eligibility: ``signal_positive_net_weak`` — in-sample IC is significant
    (``ic_t_stat > 2``) but the strongest strategy backtest's ``net_sharpe``
    is at-or-below the benchmark's. The hypothesis is that portfolio
    construction is diluting a real edge by holding too many low-conviction
    names; tightening ``top_n`` should concentrate weight on the high-
    conviction tail.

    Single ``OverrideSpec`` against ``config/setup.yaml`` ::
    ``("mapping", "tunable_params", "top_n")``, ``value_type="int"``,
    ``allowed_values=(5, 10, 15, 20)``, ``direction="narrower_only"``. The
    library does not enforce that the proposer narrows below the parent's
    current ``top_n`` — the runner reads the override and the agent's
    rationale must explain the choice.

    Stages cover portfolio construction + downstream evaluation: 15 → 14 →
    18 (no retrain — predictions are reused).
    """

    spec = OverrideSpec(
        path_template="config/setup.yaml",
        yaml_path=("mapping", "tunable_params", "top_n"),
        value_type="int",
        allowed_values=_T_R1_ALLOWED_TOP_N,
        min_value=5,
        max_value=20,
        direction="narrower_only",
        description=(
            "narrowed top_n for the long-short portfolio; one of 5/10/15/20 (tightening only)"
        ),
    )
    criterion = DeltaCriterion(
        primary_metric="net_sharpe",
        metric_kind="delta",
        support_threshold=0.10,
        reject_threshold=-0.10,
        direction="higher_is_better",
        noise_floor_method="hac_newey_west_21d",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    return ExperimentTemplate(
        template_id="T-R1",
        category=IterationCategory.RISK,
        maturity=TemplateMaturity.CONCRETE,
        question=(
            "When the signal is significant but the strategy's net Sharpe is "
            "at or below the benchmark's, does tightening top-N restore a net "
            "edge?"
        ),
        preconditions=("has_clean_validity", "signal_positive_net_weak"),
        forbidden_when=(Severity.BLOCKING, Severity.MATERIAL),
        allowed_overrides=(spec,),
        forbidden_paths=(("evaluation",), ("costs",), ("labels",), ("universe",)),
        stage_invocations=(
            StageInvocation(script="15_portfolio_management.py"),
            StageInvocation(script="14_backtest.py"),
            StageInvocation(script="18_strategy_analysis.py"),
        ),
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion_template=criterion,
        expected_information_value=0.55,
        relative_cost=0.2,
    )


# --- internals --------------------------------------------------------------


def _build_messages(
    evidence: EvidencePack,
    templates: Sequence[ExperimentTemplate],
    *,
    max_proposals: int,
) -> list[Message]:
    system = (
        "You are a systematic-strategy research planner. Propose at most "
        f"{max_proposals} bounded experiments to run next. Each proposal must "
        "select a template from the supplied catalogue and supply concrete "
        "config-patch values within the template's allowed override spec. "
        "Cite specific evidence-pack fields in 'rationale'. Do not invent new "
        "templates, paths, or stages."
    )
    user_lines = [
        "EVIDENCE PACK SUMMARY:",
        summarize_run(evidence),
        "",
        "TEMPLATE CATALOGUE:",
    ]
    for t in templates:
        user_lines.append(_render_template(t))
    user = "\n".join(user_lines)
    return [
        Message(role="system", content=system, cacheable=True),
        Message(role="user", content=user),
    ]


def _render_template(t: ExperimentTemplate) -> str:
    overrides = "\n".join(
        f"    - path_template={s.path_template!r} "
        f"yaml_path={list(s.yaml_path)} "
        f"value_type={s.value_type}"
        + (f" min={s.min_value}" if s.min_value is not None else "")
        + (f" max={s.max_value}" if s.max_value is not None else "")
        + (f" len={s.length}" if s.length is not None else "")
        + (f" allowed={list(s.allowed_values)}" if s.allowed_values else "")
        + (f" — {s.description}" if s.description else "")
        for s in t.allowed_overrides
    )
    return (
        f"  template_id={t.template_id!r} category={t.category.value} "
        f"maturity={t.maturity.value}\n"
        f"    question: {t.question}\n"
        f"    allowed_overrides:\n{overrides}"
    )


def _build_response_schema(
    templates: Sequence[ExperimentTemplate], *, max_proposals: int
) -> dict[str, Any]:
    template_ids = [t.template_id for t in templates]
    return {
        "type": "object",
        "properties": {
            "proposals": {
                "type": "array",
                "maxItems": max_proposals,
                "items": {
                    "type": "object",
                    "properties": {
                        "experiment_id": {"type": "string"},
                        "template_id": {"type": "string", "enum": template_ids},
                        "comparison_target_id": {"type": "string"},
                        "hypothesis": {"type": "string"},
                        "rationale": {"type": "string"},
                        "config_patches": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "path_template": {"type": "string"},
                                    "path_variables": {
                                        "type": "object",
                                        "additionalProperties": {"type": "string"},
                                    },
                                    "yaml_path": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                    "new_value": {},
                                },
                                "required": [
                                    "path_template",
                                    "yaml_path",
                                    "new_value",
                                ],
                            },
                        },
                    },
                    "required": [
                        "experiment_id",
                        "template_id",
                        "comparison_target_id",
                        "hypothesis",
                        "rationale",
                        "config_patches",
                    ],
                },
            }
        },
        "required": ["proposals"],
    }


def _proposal_to_plan(
    entry: Any,
    templates_by_id: dict[str, ExperimentTemplate],
    parent_run_id: str,
    line_state: LineState,
) -> tuple[ExperimentPlan, ExperimentTemplate]:
    if not isinstance(entry, dict):
        raise PlanValidationError(f"proposal must be an object, got {type(entry).__name__}")
    try:
        template_id = str(entry["template_id"])
        experiment_id = str(entry["experiment_id"])
        comparison_target_id = str(entry["comparison_target_id"])
        hypothesis = str(entry["hypothesis"])
        rationale = str(entry["rationale"])
        raw_patches = entry["config_patches"]
    except KeyError as exc:
        raise PlanValidationError(f"proposal missing field: {exc}") from exc

    template = templates_by_id.get(template_id)
    if template is None:
        raise PlanValidationError(f"proposal references unknown template_id={template_id!r}")
    if not isinstance(raw_patches, list):
        raise PlanValidationError(
            f"proposal.config_patches must be a list, got {type(raw_patches).__name__}"
        )

    patches = tuple(_dict_to_patch(p) for p in raw_patches)
    delta = replace(template.delta_criterion_template, bonferroni_k=line_state.iteration_index)
    plan = ExperimentPlan(
        experiment_id=experiment_id,
        template_id=template_id,
        parent_run_id=parent_run_id,
        comparison_target_id=comparison_target_id,
        config_patches=patches,
        stage_invocations=template.stage_invocations,
        expected_artifacts=template.expected_artifacts,
        delta_criterion=delta,
        question=template.question,
        hypothesis=hypothesis,
        rationale=rationale,
    )
    return plan, template


def _dict_to_patch(payload: Any) -> ConfigPatch:
    if not isinstance(payload, dict):
        raise PlanValidationError(f"config_patch must be an object, got {type(payload).__name__}")
    try:
        path_template = payload["path_template"]
        yaml_path = payload["yaml_path"]
        new_value = payload["new_value"]
    except KeyError as exc:
        raise PlanValidationError(f"config_patch missing field: {exc}") from exc
    raw_vars = payload.get("path_variables") or {}
    if not isinstance(raw_vars, dict):
        raise PlanValidationError(
            f"config_patch.path_variables must be an object, got {type(raw_vars).__name__}"
        )
    if not isinstance(yaml_path, list) or not all(isinstance(s, str) for s in yaml_path):
        raise PlanValidationError("config_patch.yaml_path must be list[str]")
    return ConfigPatch(
        path_template=path_template,  # ty: type narrowed by validate_plan downstream
        path_variables=tuple((str(k), str(v)) for k, v in raw_vars.items()),
        yaml_path=tuple(yaml_path),
        new_value=new_value,
    )
