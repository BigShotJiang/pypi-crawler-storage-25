import polars as pl

from .base_filter import BaseFilter


class PathwaysFilter(BaseFilter):
    CASE_ATTR = {
        k: f"case:{v}"
        for k, v in {
            "PNR": "PNR",
            "DW_EK_BORGER": "patientId",
            "DW_EK_HELBREDSFORLOEB": "caseId",
            "HELBREDSFORL_STARTTIDSPUNKT": "pathStartTime",
            "HELBREDSFORL_SLUTTIDSPUNKT": "pathEndTime",
        }.items()
    }

    EVENT_ATTR = {
        "DW_EK_FORLOEB": "forlId",
        "FORL_AFSLUT_MAADE_TEKST": "endReason",
        "FORL_HENV_AARSAG": "diagnosis",
        "FORL_HENV_MAADE_TEKST": "referralReason",
        "FORL_LABEL": "label",
        "FORL_LABEL_TEKST": "labelText",
        "FORL_ANS": "ans",
        "FORL_ANS_INST": "ansInst",
        "FORL_STARTTIDSPUNKT": "startTime",
        "FORL_SLUTTIDSPUNKT": "endTime",
    }

    def apply(self, lf: pl.LazyFrame) -> pl.LazyFrame:

        return lf.select(list((self.CASE_ATTR | self.EVENT_ATTR).keys())).rename(
            self.CASE_ATTR | self.EVENT_ATTR
        )
