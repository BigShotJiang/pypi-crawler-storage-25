import json

import pytest

from ringglabs.stt import AsyncClient, Client


def test_ws_factory_public_surface():
    client = Client(ws_endpoint="wss://example.com/parrot-stt/v1/stream")
    async_client = AsyncClient(ws_endpoint="wss://example.com/parrot-stt/v1/stream")

    assert hasattr(client, "stream")
    assert hasattr(client, "_open_stream")
    assert not hasattr(client, "open_stream")

    assert hasattr(async_client, "stream")
    assert hasattr(async_client, "_open_stream")
    assert not hasattr(async_client, "open_stream")


class _FakeSyncWs:
    def __init__(self, responses):
        self._responses = list(responses)
        self.sent = []
        self.closed = False

    def send(self, payload):
        self.sent.append(payload)

    def recv(self, timeout=None):
        if not self._responses:
            raise RuntimeError("no more messages")
        return self._responses.pop(0)

    def close(self):
        self.closed = True


class _FakeAsyncWs:
    def __init__(self, responses):
        self._responses = list(responses)
        self.sent = []
        self.closed = False

    async def send(self, payload):
        self.sent.append(payload)

    async def recv(self):
        if not self._responses:
            raise RuntimeError("no more messages")
        return self._responses.pop(0)

    async def close(self):
        self.closed = True


def test_sync_stream_handshake(monkeypatch):
    ready = json.dumps(
        {
            "type": "ready",
            "request_id": "r1",
            "sample_rate": 16000,
            "language": "en",
            "mode": "stream",
            "enable_cap_punc": True,
            "vad_tail_sil_ms": 200,
            "vad_confidence": 0.55,
            "accept_client_vad_events": False,
        }
    )
    fake = _FakeSyncWs([ready])

    import ringglabs.stt._ws_sync as ws_sync

    monkeypatch.setattr(ws_sync, "ws_connect", lambda *a, **k: fake, raising=True)
    client = Client(ws_endpoint="wss://example.com/parrot-stt/v1/stream", api_key="k")
    with client.stream(
        language="en",
        mode="stream",
        vad_tail_sil_ms=350,
        vad_confidence=0.61,
    ) as session:
        assert session.ready_event is not None
        session.send_audio(b"123")
        session.end()
    start_payload = json.loads(fake.sent[0])
    assert start_payload["vad_tail_sil_ms"] == 350
    assert start_payload["vad_confidence"] == 0.61
    assert fake.closed is True


@pytest.mark.asyncio
async def test_async_stream_handshake(monkeypatch):
    ready = json.dumps(
        {
            "type": "ready",
            "request_id": "r1",
            "sample_rate": 16000,
            "language": "en",
            "mode": "on_final",
            "enable_cap_punc": True,
            "vad_tail_sil_ms": 200,
            "vad_confidence": 0.55,
            "accept_client_vad_events": True,
        }
    )
    fake = _FakeAsyncWs([ready])

    import ringglabs.stt._ws_async as ws_async

    async def fake_connect(*args, **kwargs):
        return fake

    monkeypatch.setattr(ws_async, "ws_connect", fake_connect, raising=True)
    client = AsyncClient(ws_endpoint="wss://example.com/parrot-stt/v1/stream", api_key="k")
    async with client.stream(
        language="en",
        mode="on_final",
        vad_tail_sil_ms=420,
        vad_confidence=0.68,
        accept_client_vad_events=True,
    ) as session:
        assert session.ready_event is not None
        await session.start_speaking()
        await session.send_audio(b"456")
        await session.stop_speaking()
        await session.end()
    start_payload = json.loads(fake.sent[0])
    assert start_payload["vad_tail_sil_ms"] == 420
    assert start_payload["vad_confidence"] == 0.68
    assert fake.closed is True
