from ringglabs.stt.config import ClientConfig


def test_client_config_uses_full_endpoints():
    cfg = ClientConfig(
        rest_endpoint="https://api.example.com/custom/rest",
        ws_endpoint="wss://api.example.com/custom/ws",
    )
    assert cfg.rest_url == "https://api.example.com/custom/rest"
    assert cfg.ws_url == "wss://api.example.com/custom/ws"


def test_client_config_builds_urls_from_base():
    cfg = ClientConfig(base_url="http://localhost:7860")
    assert cfg.rest_url == "http://localhost:7860/parrot-stt/v1/transcriptions"
    assert cfg.ws_url == "ws://localhost:7860/parrot-stt/v1/stream"
    assert cfg.health_url == "http://localhost:7860/health"


def test_client_config_builds_health_from_rest_endpoint():
    cfg = ClientConfig(rest_endpoint="https://api.example.com/parrot-stt/v1/transcriptions")
    assert cfg.health_url == "https://api.example.com/health"


def test_client_config_builds_health_from_ws_endpoint():
    cfg = ClientConfig(ws_endpoint="wss://api.example.com/parrot-stt/v1/stream")
    assert cfg.health_url == "https://api.example.com/health"
