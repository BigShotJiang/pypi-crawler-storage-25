"""Sync STT client."""

from __future__ import annotations

from pathlib import Path
from typing import BinaryIO

from ._http import SyncHttpTransport
from ._io import read_audio_source
from ._ws_sync import StreamSession
from .config import ClientConfig, TimeoutConfig
from .models import (
    FileSource,
    RestTranscriptionResult,
    StreamOptions,
    TranscriptionOptions,
)


class Client:
    """Sync RinggLabs STT client."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        rest_endpoint: str | None = None,
        ws_endpoint: str | None = None,
        api_key: str | None = None,
        timeout: TimeoutConfig | None = None,
        rest_path: str = "/parrot-stt/v1/transcriptions",
        ws_path: str = "/parrot-stt/v1/stream",
        default_headers: dict[str, str] | None = None,
    ):
        self.config = ClientConfig(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout or TimeoutConfig(),
            rest_endpoint=rest_endpoint,
            ws_endpoint=ws_endpoint,
            rest_path=rest_path,
            ws_path=ws_path,
            default_headers=default_headers,
        )
        self._http = SyncHttpTransport(self.config)

    def __enter__(self) -> "Client":
        self._http.open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    def health(self, *, api_key: str | None = None) -> dict:
        return self._http.health_check(api_key_override=api_key)

    def transcribe(
        self,
        source: FileSource,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        filename: str | None = None,
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        audio, detected_name = read_audio_source(source, fallback_filename=filename or "audio.wav")
        options = TranscriptionOptions(
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            filename=filename or detected_name,
            content_type=content_type,
        )
        return self._http.transcribe_bytes(audio, options, api_key_override=api_key)

    def _transcribe_file(
        self,
        file_path: str | Path,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        return self.transcribe(
            file_path,
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            content_type=content_type,
        )

    def _transcribe_bytes(
        self,
        audio: bytes | bytearray,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        filename: str = "audio.wav",
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        return self.transcribe(
            bytes(audio),
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            filename=filename,
            content_type=content_type,
        )

    def _transcribe_fileobj(
        self,
        fileobj: BinaryIO,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        filename: str | None = None,
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        return self.transcribe(
            fileobj,
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            filename=filename,
            content_type=content_type,
        )

    def _open_stream(self, options: StreamOptions, *, api_key: str | None = None) -> StreamSession:
        start_config = options.to_start_config()
        return StreamSession(
            client_config=self.config,
            start_config=start_config,
            api_key_override=api_key,
        )

    def stream(
        self,
        *,
        sample_rate: int = 16000,
        encoding: str = "int16",
        language: str = "hi",
        mode: str = "stream",
        vad_tail_sil_ms: int = 200,
        vad_confidence: float = 0.55,
        enable_cap_punc: bool = True,
        accept_client_vad_events: bool = False,
        api_key: str | None = None,
    ) -> StreamSession:
        """Create a stream session with high-level options."""
        return self._open_stream(
            StreamOptions(
                sample_rate=sample_rate,
                encoding=encoding,
                language=language,
                mode=mode,
                vad_tail_sil_ms=vad_tail_sil_ms,
                vad_confidence=vad_confidence,
                enable_cap_punc=enable_cap_punc,
                accept_client_vad_events=accept_client_vad_events,
                api_key=api_key,
            ),
            api_key=api_key,
        )
