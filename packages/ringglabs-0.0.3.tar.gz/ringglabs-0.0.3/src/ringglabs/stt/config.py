"""Configuration objects for SDK clients."""

from dataclasses import dataclass, field
from typing import Mapping
from urllib.parse import urljoin, urlparse, urlunparse

import httpx


def _normalize_base_url(base_url: str) -> str:
    parsed = urlparse(base_url)
    if parsed.scheme not in {"http", "https", "ws", "wss"}:
        raise ValueError(f"Unsupported base_url scheme: {parsed.scheme!r}")
    if not parsed.netloc:
        raise ValueError("base_url must include host, e.g. http://localhost:7860")
    return urlunparse((parsed.scheme, parsed.netloc, "", "", "", ""))


def _to_ws_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https", "ws", "wss"}:
        raise ValueError(f"Unsupported ws URL scheme: {parsed.scheme!r}")
    if parsed.scheme in {"http", "ws"}:
        scheme = "ws"
    else:
        scheme = "wss"
    path = parsed.path or "/"
    return urlunparse((scheme, parsed.netloc, path, parsed.params, parsed.query, parsed.fragment))


def _to_http_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https", "ws", "wss"}:
        raise ValueError(f"Unsupported http URL scheme: {parsed.scheme!r}")
    if parsed.scheme in {"ws", "http"}:
        scheme = "http"
    else:
        scheme = "https"
    path = parsed.path or "/"
    return urlunparse((scheme, parsed.netloc, path, parsed.params, parsed.query, parsed.fragment))


def _to_http_origin(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https", "ws", "wss"}:
        raise ValueError(f"Unsupported http URL scheme: {parsed.scheme!r}")
    if parsed.scheme in {"ws", "http"}:
        scheme = "http"
    else:
        scheme = "https"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


@dataclass(slots=True)
class TimeoutConfig:
    """Timeouts used by REST and WebSocket operations."""

    connect: float = 10.0
    read: float = 10.0
    write: float = 10.0
    pool: float = 10.0
    ws_open: float = 10.0
    ws_recv: float = 30.0
    ws_close: float = 10.0

    def as_httpx_timeout(self) -> httpx.Timeout:
        return httpx.Timeout(
            timeout=None,
            connect=self.connect,
            read=self.read,
            write=self.write,
            pool=self.pool,
        )


@dataclass(slots=True)
class ClientConfig:
    """Client-level configuration and defaults."""

    base_url: str | None = None
    api_key: str | None = None
    timeout: TimeoutConfig = field(default_factory=TimeoutConfig)
    rest_endpoint: str | None = None
    ws_endpoint: str | None = None
    rest_path: str = "/parrot-stt/v1/transcriptions"
    ws_path: str = "/parrot-stt/v1/stream"
    default_headers: Mapping[str, str] | None = None

    def __post_init__(self) -> None:
        if self.base_url is None and self.rest_endpoint is None and self.ws_endpoint is None:
            raise ValueError(
                "Provide at least one of: base_url, rest_endpoint, ws_endpoint"
            )
        if self.base_url is not None:
            self.base_url = _normalize_base_url(self.base_url)
        if self.rest_endpoint is not None:
            self.rest_endpoint = _to_http_url(self.rest_endpoint)
        if self.ws_endpoint is not None:
            self.ws_endpoint = _to_ws_url(self.ws_endpoint)

    @staticmethod
    def _join(base: str, path: str) -> str:
        root = base if base.endswith("/") else f"{base}/"
        rel = path[1:] if path.startswith("/") else path
        return urljoin(root, rel)

    @property
    def rest_url(self) -> str:
        if self.rest_endpoint is not None:
            return self.rest_endpoint
        assert self.base_url is not None
        return _to_http_url(self._join(self.base_url, self.rest_path))

    @property
    def ws_url(self) -> str:
        if self.ws_endpoint is not None:
            return self.ws_endpoint
        assert self.base_url is not None
        return _to_ws_url(self._join(self.base_url, self.ws_path))

    @property
    def health_url(self) -> str:
        if self.base_url is not None:
            return _to_http_url(self._join(self.base_url, "/health"))
        if self.rest_endpoint is not None:
            return _to_http_url(self._join(_to_http_origin(self.rest_endpoint), "/health"))
        assert self.ws_endpoint is not None
        return _to_http_url(self._join(_to_http_origin(self.ws_endpoint), "/health"))

    def resolve_api_key(self, override: str | None = None) -> str | None:
        return override if override is not None else self.api_key
