from typing import Optional, Dict


class TelegramError(Exception):
    """Bazowa klasa dla wszystkich błędów Telegram"""

    pass


class TelegramAPIError(TelegramError):
    """Błąd zwrócony przez Telegram API"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}" if code else message)


class NetworkError(TelegramError):
    """Błąd połączenia sieciowego"""

    def __init__(self, message: str = "Network connection failed"):
        self.message = message
        super().__init__(message)


class RateLimitError(TelegramAPIError):
    """Przekroczono limit zapytań (429 Too Many Requests)"""

    def __init__(self, retry_after: int, message: str = "Too Many Requests"):
        self.retry_after = retry_after
        super().__init__(message, 429)


class ForbiddenError(TelegramAPIError):
    """Bot został zablokowany lub nie ma uprawnień (403 Forbidden)"""

    def __init__(self, message: str = "Forbidden: bot was blocked or has no rights"):
        super().__init__(message, 403)


class NotFoundError(TelegramAPIError):
    """Zasób nie istnieje (404 Not Found)"""

    def __init__(self, message: str = "Not Found"):
        super().__init__(message, 404)


class BadRequestError(TelegramAPIError):
    """Nieprawidłowe parametry zapytania (400 Bad Request)"""

    def __init__(self, message: str):
        super().__init__(message, 400)


class ConflictError(TelegramAPIError):
    """Konflikt webhooka (409 Conflict)"""

    def __init__(self, message: str = "Conflict: webhook already set"):
        super().__init__(message, 409)


class UnauthorizedError(TelegramAPIError):
    """Nieautoryzowany dostęp (401 Unauthorized)"""

    def __init__(self, message: str = "Unauthorized: invalid token"):
        super().__init__(message, 401)


class TimeoutError(TelegramError):
    """Przekroczono czas oczekiwania na odpowiedź"""

    def __init__(self, message: str = "Request timeout"):
        self.message = message
        super().__init__(message)


class SkipHandler(Exception):
    """Wyjatek do pominięcia bieżącego handlera"""

    pass


class CancelHandler(Exception):
    """Wyjatek do anulowania całego przetwarzania"""

    pass


class ValidationError(TelegramError):
    """Błąd walidacji danych"""

    def __init__(self, message: str, field: Optional[str] = None):
        self.field = field
        self.message = message
        super().__init__(
            f"Validation error{f' in field {field}' if field else ''}: {message}"
        )


class WebhookError(TelegramError):
    """Błąd związany z webhookiem"""

    def __init__(self, message: str):
        self.message = message
        super().__init__(f"Webhook error: {message}")


class FSMError(TelegramError):
    """Błąd związany z Finite State Machine"""

    def __init__(self, message: str):
        self.message = message
        super().__init__(f"FSM error: {message}")


class MiddlewareError(TelegramError):
    """Błąd w middleware"""

    def __init__(self, message: str, middleware_name: Optional[str] = None):
        self.middleware_name = middleware_name
        self.message = message
        prefix = (
            f"Middleware '{middleware_name}' error: "
            if middleware_name
            else "Middleware error: "
        )
        super().__init__(f"{prefix}{message}")


class MessageError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z wiadomościami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class MessageNotModifiedError(MessageError):
    """Wiadomość nie została zmodyfikowana (treść jest taka sama)"""

    def __init__(self, message: str = "Message is not modified"):
        super().__init__(message, 400)


class MessageNotFoundError(MessageError):
    """Wiadomość nie została znaleziona"""

    def __init__(self, message: str = "Message not found"):
        super().__init__(message, 404)


class MessageToDeleteError(MessageError):
    """Nie można usunąć wiadomości (np. zbyt stara)"""

    def __init__(self, message: str = "Message can't be deleted"):
        super().__init__(message, 400)


class MessageToForwardError(MessageError):
    """Nie można przekazać wiadomości"""

    def __init__(self, message: str = "Message can't be forwarded"):
        super().__init__(message, 400)


class MessageToReplyError(MessageError):
    """Nie można odpowiedzieć na wiadomość"""

    def __init__(self, message: str = "Message can't be replied"):
        super().__init__(message, 400)


class MessageCaptionTooLongError(MessageError):
    """Podpis wiadomości jest zbyt długi"""

    def __init__(self, message: str = "Message caption is too long"):
        super().__init__(message, 400)


class MessageEntitiesTooLongError(MessageError):
    """Encje wiadomości są zbyt długie"""

    def __init__(self, message: str = "Message entities are too long"):
        super().__init__(message, 400)


class ReplyMarkupError(TelegramAPIError):
    """Błąd związana z klawiaturą/reply markup"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ReplyMarkupTooLongError(ReplyMarkupError):
    """Reply markup jest zbyt długi"""

    def __init__(self, message: str = "Reply markup is too long"):
        super().__init__(message, 400)


class ReplyMarkupInvalidError(ReplyMarkupError):
    """Nieprawidłowy reply markup"""

    def __init__(self, message: str = "Reply markup is invalid"):
        super().__init__(message, 400)


class ButtonDataInvalidError(ReplyMarkupError):
    """Nieprawidłowe dane przycisku"""

    def __init__(self, message: str = "Button data is invalid"):
        super().__init__(message, 400)


class ChatError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z czatem"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ChatNotFoundError(ChatError):
    """Czat nie został znaleziony"""

    def __init__(self, message: str = "Chat not found"):
        super().__init__(message, 404)


class ChatRestrictedError(ChatError):
    """Dostęp do czatu jest ograniczony"""

    def __init__(self, message: str = "Chat access restricted"):
        super().__init__(message, 403)


class CantInitiateConversationError(ChatError):
    """Nie można zainicjować rozmowy"""

    def __init__(self, message: str = "Can't initiate conversation with user"):
        super().__init__(message, 403)


class CantTalkWithBotsError(ChatError):
    """Bot nie może rozmawiać z innymi botami"""

    def __init__(self, message: str = "Can't talk with other bots"):
        super().__init__(message, 400)


class UserError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z użytkownikami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class UserNotFoundError(UserError):
    """Użytkownik nie został znaleziony"""

    def __init__(self, message: str = "User not found"):
        super().__init__(message, 404)


class UserIsBotError(UserError):
    """Docelowy użytkownik jest botem"""

    def __init__(self, message: str = "Target user is a bot"):
        super().__init__(message, 400)


class AdminRequiredError(UserError):
    """Wymagane są uprawnienia administratora"""

    def __init__(self, message: str = "Admin rights required"):
        super().__init__(message, 403)


class UserIsDeactivatedError(UserError):
    """Użytkownik został dezaktywowany"""

    def __init__(self, message: str = "User is deactivated"):
        super().__init__(message, 403)


class UserIsKickedError(UserError):
    """Użytkownik został usunięty z grupy"""

    def __init__(self, message: str = "User is kicked from the group"):
        super().__init__(message, 403)


class UserIsRestrictedError(UserError):
    """Użytkownik ma nałożone ograniczenia"""

    def __init__(self, message: str = "User is restricted"):
        super().__init__(message, 403)


class UserAlreadyParticipantError(UserError):
    """Użytkownik jest już uczestnikiem czatu"""

    def __init__(self, message: str = "User is already a participant"):
        super().__init__(message, 400)


class UserNotParticipantError(UserError):
    """Użytkownik nie jest uczestnikiem czatu"""

    def __init__(self, message: str = "User is not a participant"):
        super().__init__(message, 400)


class BotAlreadyUsedError(UserError):
    """Bot był już używany/użyty"""

    def __init__(self, message: str = "Bot has already been used"):
        super().__init__(message, 400)


# ==================== Group/Supergroup Management Errors ====================


class GroupError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z grupami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class GroupMigratedError(GroupError):
    """Grupa została zaktualizowana do supergrupy"""

    def __init__(self, message: str = "Group migrated to supergroup"):
        super().__init__(message, 400)


class ChatTitleInvalidError(GroupError):
    """Nieprawidłowy tytuł czatu"""

    def __init__(self, message: str = "Invalid chat title"):
        super().__init__(message, 400)


class ChatDescriptionInvalidError(GroupError):
    """Nieprawidłowy opis czatu"""

    def __init__(self, message: str = "Invalid chat description"):
        super().__init__(message, 400)


class ChatPhotoInvalidError(GroupError):
    """Nieprawidłowe zdjęcie czatu"""

    def __init__(self, message: str = "Invalid chat photo"):
        super().__init__(message, 400)


class ChatInviteLinkInvalidError(GroupError):
    """Nieprawidłowy link zaproszenia"""

    def __init__(self, message: str = "Invalid chat invite link"):
        super().__init__(message, 400)


class ChatAdministratorsRequiredError(GroupError):
    """Wymagane uprawnienia administratora"""

    def __init__(self, message: str = "Chat administrators required"):
        super().__init__(message, 403)


class UserIsAdministratorError(GroupError):
    """Użytkownik jest już administratorem"""

    def __init__(self, message: str = "User is already an administrator"):
        super().__init__(message, 400)


# ==================== Media/File Errors ====================


class MediaError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z mediami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class FileTooLargeError(MediaError):
    """Plik przekracza limit rozmiaru"""

    def __init__(self, message: str = "File is too large"):
        super().__init__(message, 400)


class FileInvalidError(MediaError):
    """Nieprawidłowy plik"""

    def __init__(self, message: str = "File is invalid"):
        super().__init__(message, 400)


class FileTypeNotSupportedError(MediaError):
    """Typ pliku nie jest obsługiwany"""

    def __init__(self, message: str = "File type is not supported"):
        super().__init__(message, 400)


class PhotoDimensionsInvalidError(MediaError):
    """Nieprawidłowe wymiary zdjęcia"""

    def __init__(self, message: str = "Invalid photo dimensions"):
        super().__init__(message, 400)


class VideoDurationTooLongError(MediaError):
    """Czas trwania wideo jest zbyt długi"""

    def __init__(self, message: str = "Video duration is too long"):
        super().__init__(message, 400)


class AudioDurationInvalidError(MediaError):
    """Nieprawidłowy czas trwania audio"""

    def __init__(self, message: str = "Invalid audio duration"):
        super().__init__(message, 400)


class DocumentMimeTypeInvalidError(MediaError):
    """Nieprawidłowy typ MIME dokumentu"""

    def __init__(self, message: str = "Invalid document MIME type"):
        super().__init__(message, 400)


# ==================== Sticker/Animation Errors ====================


class StickerError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych ze stickerami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class StickerSetInvalidError(StickerError):
    """Nieprawidłowy zestaw stickerów"""

    def __init__(self, message: str = "Invalid sticker set"):
        super().__init__(message, 400)


class StickerEmojiInvalidError(StickerError):
    """Nieprawidłowy emoji stickera"""

    def __init__(self, message: str = "Invalid sticker emoji"):
        super().__init__(message, 400)


class StickerPngDimensionsInvalidError(StickerError):
    """Nieprawidłowe wymiary PNG stickera"""

    def __init__(self, message: str = "Invalid sticker PNG dimensions"):
        super().__init__(message, 400)


class StickerTgsInvalidError(StickerError):
    """Nieprawidłowy sticker animowany (TGS)"""

    def __init__(self, message: str = "Invalid TGS animated sticker"):
        super().__init__(message, 400)


class AnimationInvalidError(StickerError):
    """Nieprawidłowa animacja/GIF"""

    def __init__(self, message: str = "Invalid animation/GIF"):
        super().__init__(message, 400)


# ==================== Location/Venue Errors ====================


class LocationError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z lokalizacją"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class LocationInvalidError(LocationError):
    """Nieprawidłowe dane lokalizacji"""

    def __init__(self, message: str = "Invalid location data"):
        super().__init__(message, 400)


class VenueInvalidError(LocationError):
    """Nieprawidłowe dane miejsca"""

    def __init__(self, message: str = "Invalid venue data"):
        super().__init__(message, 400)


class LiveLocationPeriodExpiredError(LocationError):
    """Okres lokalizacji na żywo wygasł"""

    def __init__(self, message: str = "Live location period expired"):
        super().__init__(message, 400)


class LiveLocationAlreadyStoppedError(LocationError):
    """Lokalizacja na żywo już zatrzymana"""

    def __init__(self, message: str = "Live location already stopped"):
        super().__init__(message, 400)


# ==================== Contact/Poll Errors ====================


class ContactError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z kontaktami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ContactUserIdInvalidError(ContactError):
    """Nieprawidłowe ID użytkownika kontaktu"""

    def __init__(self, message: str = "Invalid contact user ID"):
        super().__init__(message, 400)


class ContactPhoneNumberInvalidError(ContactError):
    """Nieprawidłowy numer telefonu kontaktu"""

    def __init__(self, message: str = "Invalid contact phone number"):
        super().__init__(message, 400)


class PollError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z ankietami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class PollAlreadyClosedError(PollError):
    """Ankieta jest już zamknięta"""

    def __init__(self, message: str = "Poll is already closed"):
        super().__init__(message, 400)


class PollAlreadyExistsError(PollError):
    """Ankieta już istnieje w wiadomości"""

    def __init__(self, message: str = "Poll already exists in message"):
        super().__init__(message, 400)


class PollQuestionInvalidError(PollError):
    """Nieprawidłowe pytanie ankiety"""

    def __init__(self, message: str = "Invalid poll question"):
        super().__init__(message, 400)


class PollOptionsInvalidError(PollError):
    """Nieprawidłowe opcje ankiety (za mało/za dużo)"""

    def __init__(self, message: str = "Invalid poll options"):
        super().__init__(message, 400)


class PollOptionsTypeInvalidError(PollError):
    """Nieprawidłowy typ opcji ankiety"""

    def __init__(self, message: str = "Invalid poll options type"):
        super().__init__(message, 400)


# ==================== Inline Query Errors ====================


class InlineQueryError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z inline query"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class InlineQueryIdInvalidError(InlineQueryError):
    """Nieprawidłowe ID inline query"""

    def __init__(self, message: str = "Invalid inline query ID"):
        super().__init__(message, 400)


class InlineQueryResultInvalidError(InlineQueryError):
    """Nieprawidłowy wynik inline query"""

    def __init__(self, message: str = "Invalid inline query result"):
        super().__init__(message, 400)


class InlineQueryResultsTooManyError(InlineQueryError):
    """Za dużo wyników inline query"""

    def __init__(self, message: str = "Too many inline query results"):
        super().__init__(message, 400)


class SwitchPmTextInvalidError(InlineQueryError):
    """Nieprawidłowy tekst switch PM"""

    def __init__(self, message: str = "Invalid switch PM text"):
        super().__init__(message, 400)


class SwitchPmParameterInvalidError(InlineQueryError):
    """Nieprawidłowy parametr switch PM"""

    def __init__(self, message: str = "Invalid switch PM parameter"):
        super().__init__(message, 400)


# ==================== Callback Query Errors ====================


class CallbackQueryError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z callback query"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class CallbackQueryIdInvalidError(CallbackQueryError):
    """Nieprawidłowe ID callback query"""

    def __init__(self, message: str = "Invalid callback query ID"):
        super().__init__(message, 400)


class CallbackQueryDataTooLongError(CallbackQueryError):
    """Dane callback query są zbyt długie"""

    def __init__(self, message: str = "Callback query data is too long"):
        super().__init__(message, 400)


class CallbackQueryAnswerExpiredError(CallbackQueryError):
    """Odpowiedź callback query wygasła"""

    def __init__(self, message: str = "Callback query answer expired"):
        super().__init__(message, 400)


# ==================== Shipping/Order Errors ====================


class ShippingError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z wysyłką"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ShippingAddressInvalidError(ShippingError):
    """Nieprawidłowy adres wysyłki"""

    def __init__(self, message: str = "Invalid shipping address"):
        super().__init__(message, 400)


class ShippingQueryIdInvalidError(ShippingError):
    """Nieprawidłowe ID shipping query"""

    def __init__(self, message: str = "Invalid shipping query ID"):
        super().__init__(message, 400)


class ShippingOptionInvalidError(ShippingError):
    """Nieprawidłowa opcja wysyłki"""

    def __init__(self, message: str = "Invalid shipping option"):
        super().__init__(message, 400)


class ShippingOptionsRequiredError(ShippingError):
    """Wymagane opcje wysyłki"""

    def __init__(self, message: str = "Shipping options are required"):
        super().__init__(message, 400)


class PreCheckoutQueryIdInvalidError(ShippingError):
    """Nieprawidłowe ID pre-checkout query"""

    def __init__(self, message: str = "Invalid pre-checkout query ID"):
        super().__init__(message, 400)


class OrderInfoInvalidError(ShippingError):
    """Nieprawidłowe informacje o zamówieniu"""

    def __init__(self, message: str = "Invalid order information"):
        super().__init__(message, 400)


class PaymentError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z płatnościami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class PaymentRequiredError(PaymentError):
    """Wymagana płatność"""

    def __init__(self, message: str = "Payment required"):
        super().__init__(message, 402)


class PaymentFailedError(PaymentError):
    """Płatność nie powiodła się"""

    def __init__(self, message: str = "Payment failed"):
        super().__init__(message, 400)


class InvalidInvoiceError(PaymentError):
    """Nieprawidłowy faktura/rachunek"""

    def __init__(self, message: str = "Invalid invoice"):
        super().__init__(message, 400)


class InvoiceExpiredError(PaymentError):
    """Faktura wygasła"""

    def __init__(self, message: str = "Invoice expired"):
        super().__init__(message, 400)


class CantSendInvoiceError(PaymentError):
    """Nie można wysłać faktury"""

    def __init__(self, message: str = "Can't send invoice"):
        super().__init__(message, 400)


class PaymentProviderUnavailableError(PaymentError):
    """Dostawca płatności jest niedostępny"""

    def __init__(self, message: str = "Payment provider unavailable"):
        super().__init__(message, 503)


class PaymentCurrencyNotSupportedError(PaymentError):
    """Waluta nie jest obsługiwana"""

    def __init__(self, message: str = "Currency not supported"):
        super().__init__(message, 400)


class PaymentAmountInvalidError(PaymentError):
    """Kwota płatności jest nieprawidłowa"""

    def __init__(self, message: str = "Payment amount is invalid"):
        super().__init__(message, 400)


# ==================== Broadcast/Channel Errors ====================


class ChannelError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z kanałami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ChannelPrivateError(ChannelError):
    """Kanał jest prywatny"""

    def __init__(self, message: str = "Channel is private"):
        super().__init__(message, 403)


class ChannelNotCreatedError(ChannelError):
    """Kanał nie istnieje"""

    def __init__(self, message: str = "Channel does not exist"):
        super().__init__(message, 404)


class BroadcastRequiredError(ChannelError):
    """Musi być kanałem broadcast"""

    def __init__(self, message: str = "Must be a broadcast channel"):
        super().__init__(message, 400)


class ChannelTooManyError(ChannelError):
    """Za dużo kanałów utworzonych"""

    def __init__(self, message: str = "Too many channels created"):
        super().__init__(message, 400)


# ==================== Rate Limiting Extended ====================


class FloodControlError(TelegramAPIError):
    """Ogólny błąd kontroli flood"""

    def __init__(self, message: str = "Flood control exceeded"):
        super().__init__(message, 420)


class SlowModeEnabledError(TelegramAPIError):
    """Tryb powolny jest włączony"""

    def __init__(self, message: str = "Slow mode is enabled"):
        super().__init__(message, 400)


class SlowModeDelayActiveError(TelegramAPIError):
    """Opóźnienie trybu powolnego jest aktywne"""

    def __init__(self, message: str = "Slow mode delay is active"):
        super().__init__(message, 400)


# ==================== Permissions Errors ====================


class PermissionError(TelegramAPIError):
    """Bazowa klasa dla błędów uprawnień"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class SendMessageNotAllowedError(PermissionError):
    """Nie można wysyłać wiadomości na tym czacie"""

    def __init__(self, message: str = "Can't send messages in this chat"):
        super().__init__(message, 403)


class SendMediaNotAllowedError(PermissionError):
    """Nie można wysyłać mediów na tym czacie"""

    def __init__(self, message: str = "Can't send media in this chat"):
        super().__init__(message, 403)


class SendPollNotAllowedError(PermissionError):
    """Nie można wysyłać ankiet na tym czacie"""

    def __init__(self, message: str = "Can't send polls in this chat"):
        super().__init__(message, 403)


class SendOtherNotAllowedError(PermissionError):
    """Nie można wysyłać innych wiadomości na tym czacie"""

    def __init__(self, message: str = "Can't send other messages in this chat"):
        super().__init__(message, 403)


class ChangeInfoNotAllowedError(PermissionError):
    """Nie można zmieniać informacji o czacie"""

    def __init__(self, message: str = "Can't change chat info"):
        super().__init__(message, 403)


class InviteUserNotAllowedError(PermissionError):
    """Nie można zapraszać użytkowników na czat"""

    def __init__(self, message: str = "Can't invite users to chat"):
        super().__init__(message, 403)


class PinMessageNotAllowedError(PermissionError):
    """Nie można przypinać wiadomości"""

    def __init__(self, message: str = "Can't pin messages"):
        super().__init__(message, 403)


# ==================== Miscellaneous Errors ====================


class MethodNotAvailableInChannelError(TelegramAPIError):
    """Metoda nie jest dostępna na kanałach"""

    def __init__(self, message: str = "Method not available in channels"):
        super().__init__(message, 400)


class MethodNotAvailableInGroupError(TelegramAPIError):
    """Metoda nie jest dostępna w grupach"""

    def __init__(self, message: str = "Method not available in groups"):
        super().__init__(message, 400)


class PeerFloodError(TelegramAPIError):
    """Za dużo zapytań do tego samego peera"""

    def __init__(self, message: str = "Too many requests to same peer"):
        super().__init__(message, 420)


class PhoneNumberInvalidError(TelegramAPIError):
    """Nieprawidłowy format numeru telefonu"""

    def __init__(self, message: str = "Invalid phone number format"):
        super().__init__(message, 400)


class PhoneCodeInvalidError(TelegramAPIError):
    """Nieprawidłowy kod weryfikacyjny telefonu"""

    def __init__(self, message: str = "Invalid phone verification code"):
        super().__init__(message, 400)


class SessionExpiredError(TelegramAPIError):
    """Sesja wygasła"""

    def __init__(self, message: str = "Session has expired"):
        super().__init__(message, 401)


class AccessTokenExpiredError(TelegramAPIError):
    """Token dostępu wygasł"""

    def __init__(self, message: str = "Access token has expired"):
        super().__init__(message, 401)


class DatabaseError(TelegramAPIError):
    """Wewnętrzny błąd bazy danych"""

    def __init__(self, message: str = "Internal database error"):
        super().__init__(message, 500)


class ServerMaintenanceError(TelegramAPIError):
    """Serwer w trakcie konserwacji"""

    def __init__(self, message: str = "Server under maintenance"):
        super().__init__(message, 503)


# ==================== Story/Status Errors (API 6.2+) ====================


class StoryError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych ze story"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class StoryNotFoundError(StoryError):
    """Story nie została znaleziona"""

    def __init__(self, message: str = "Story not found"):
        super().__init__(message, 404)


class StoryNotModifiedError(StoryError):
    """Story nie została zmodyfikowana"""

    def __init__(self, message: str = "Story is not modified"):
        super().__init__(message, 400)


class StoryExpiredError(StoryError):
    """Story wygasła"""

    def __init__(self, message: str = "Story has expired"):
        super().__init__(message, 400)


class StoryHasNoMediaError(StoryError):
    """Story nie zawiera mediów"""

    def __init__(self, message: str = "Story has no media"):
        super().__init__(message, 400)


class StoryMediaInvalidError(StoryError):
    """Nieprawidłowe media story"""

    def __init__(self, message: str = "Story media is invalid"):
        super().__init__(message, 400)


class StoryTooManyError(StoryError):
    """Za dużo story"""

    def __init__(self, message: str = "Too many stories"):
        super().__init__(message, 400)


# ==================== Chat Boost Errors ====================


class ChatBoostError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z boostami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ChatBoostNotFoundError(ChatBoostError):
    """Chat boost nie został znaleziony"""

    def __init__(self, message: str = "Chat boost not found"):
        super().__init__(message, 404)


class ChatBoostExpiredError(ChatBoostError):
    """Chat boost wygasł"""

    def __init__(self, message: str = "Chat boost has expired"):
        super().__init__(message, 400)


class ChatBoostAlreadyAppliedError(ChatBoostError):
    """Chat boost już zastosowany"""

    def __init__(self, message: str = "Chat boost already applied"):
        super().__init__(message, 400)


class ChatBoostSourceInvalidError(ChatBoostError):
    """Nieprawidłowe źródło boost"""

    def __init__(self, message: str = "Chat boost source is invalid"):
        super().__init__(message, 400)


# ==================== Reaction Errors (API 6.0+) ====================


class ReactionError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z reakcjami"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ReactionTooManyError(ReactionError):
    """Za dużo reakcji"""

    def __init__(self, message: str = "Too many reactions"):
        super().__init__(message, 400)


class ReactionInvalidError(ReactionError):
    """Nieprawidłowa reakcja"""

    def __init__(self, message: str = "Invalid reaction"):
        super().__init__(message, 400)


class ReactionNotAllowedError(ReactionError):
    """Reakcje niedozwolone"""

    def __init__(self, message: str = "Reactions are not allowed"):
        super().__init__(message, 400)


class ReactionCountInvalidError(ReactionError):
    """Nieprawidłowa liczba reakcji"""

    def __init__(self, message: str = "Invalid reaction count"):
        super().__init__(message, 400)


class EmojiInvalidError(ReactionError):
    """Nieprawidłowy emoji"""

    def __init__(self, message: str = "Invalid emoji"):
        super().__init__(message, 400)


# ==================== Quote/Reply Errors ====================


class QuoteError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z cytowaniem"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class QuoteInvalidError(QuoteError):
    """Nieprawidłowe cytowanie"""

    def __init__(self, message: str = "Quote is invalid"):
        super().__init__(message, 400)


class QuoteTooOldError(QuoteError):
    """Wiadomość do cytowania jest zbyt stara"""

    def __init__(self, message: str = "Message quote is too old"):
        super().__init__(message, 400)


class QuoteNotFoundError(QuoteError):
    """Wiadomość do cytowania nie znaleziono"""

    def __init__(self, message: str = "Message quote not found"):
        super().__init__(message, 400)


# ==================== Business Errors (API 6.7+) ====================


class BusinessError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z biznesem"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class BusinessConnectionNotFoundError(BusinessError):
    """Połączenie biznesowe nie znaleziono"""

    def __init__(self, message: str = "Business connection not found"):
        super().__init__(message, 404)


class BusinessConnectionInvalidError(BusinessError):
    """Nieprawidłowe połączenie biznesowe"""

    def __init__(self, message: str = "Business connection is invalid"):
        super().__init__(message, 400)


class BusinessAccountNotFoundError(BusinessError):
    """Konto biznesowe nie znaleziono"""

    def __init__(self, message: str = "Business account not found"):
        super().__init__(message, 404)


class BusinessAccountInvalidError(BusinessError):
    """Nieprawidłowe konto biznesowe"""

    def __init__(self, message: str = "Business account is invalid"):
        super().__init__(message, 400)


class BusinessMessageNotFoundError(BusinessError):
    """Wiadomość biznesowa nie znaleziono"""

    def __init__(self, message: str = "Business message not found"):
        super().__init__(message, 404)


class BusinessGreetingNotFoundError(BusinessError):
    """Powitanie biznesowe nie znaleziono"""

    def __init__(self, message: str = "Business greeting not found"):
        super().__init__(message, 404)


class BusinessGreetingAlreadyExistsError(BusinessError):
    """Powitanie biznesowe już istnieje"""

    def __init__(self, message: str = "Business greeting already exists"):
        super().__init__(message, 400)


class BusinessAwayMessageNotFoundError(BusinessError):
    """Wiadomość away nie znaleziono"""

    def __init__(self, message: str = "Business away message not found"):
        super().__init__(message, 404)


class BusinessAwayMessageAlreadyExistsError(BusinessError):
    """Wiadomość away już istnieje"""

    def __init__(self, message: str = "Business away message already exists"):
        super().__init__(message, 400)


class BusinessOwnershipTransferredError(BusinessError):
    """Własność biznesowa przeniesiona"""

    def __init__(self, message: str = "Business ownership transferred"):
        super().__init__(message, 400)


# ==================== Collectible Errors ====================


class CollectibleError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z collectible"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class CollectibleNotFoundError(CollectibleError):
    """Collectible nie znaleziono"""

    def __init__(self, message: str = "Collectible not found"):
        super().__init__(message, 404)


class CollectibleSoldOutError(CollectibleError):
    """Collectible wyprzedane"""

    def __init__(self, message: str = "Collectible is sold out"):
        super().__init__(message, 400)


class CollectibleInvalidError(CollectibleError):
    """Nieprawidłowe collectible"""

    def __init__(self, message: str = "Collectible is invalid"):
        super().__init__(message, 400)


class GiveawayNotFoundError(CollectibleError):
    """Giveaway nie znaleziono"""

    def __init__(self, message: str = "Giveaway not found"):
        super().__init__(message, 404)


class GiveawayInvalidError(CollectibleError):
    """Nieprawidłowy giveaway"""

    def __init__(self, message: str = "Giveaway is invalid"):
        super().__init__(message, 400)


class GiveawayCompletedError(CollectibleError):
    """Giveaway zakończony"""

    def __init__(self, message: str = "Giveaway is completed"):
        super().__init__(message, 400)


class GiveawayWinnerNotFoundError(CollectibleError):
    """Zwycięzca giveaway nie znaleziono"""

    def __init__(self, message: str = "Giveaway winner not found"):
        super().__init__(message, 404)


# ==================== Share URL Errors ====================


class ShareUrlError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z share URL"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ShareUrlNotFoundError(ShareUrlError):
    """Share URL nie znaleziono"""

    def __init__(self, message: str = "Share URL not found"):
        super().__init__(message, 404)


class ShareUrlInvalidError(ShareUrlError):
    """Nieprawidłowy share URL"""

    def __init__(self, message: str = "Share URL is invalid"):
        super().__init__(message, 400)


class ShareUrlOccupiedError(ShareUrlError):
    """Share URL zajęty"""

    def __init__(self, message: str = "Share URL is already occupied"):
        super().__init__(message, 400)


# ==================== Forum/Topic Errors ====================


class ForumError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z forum/topic"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class TopicNotFoundError(ForumError):
    """Topic nie znaleziono"""

    def __init__(self, message: str = "Topic not found"):
        super().__init__(message, 404)


class TopicClosedError(ForumError):
    """Topic zamknięty"""

    def __init__(self, message: str = "Topic is closed"):
        super().__init__(message, 400)


class TopicAlreadyClosedError(ForumError):
    """Topic już zamknięty"""

    def __init__(self, message: str = "Topic is already closed"):
        super().__init__(message, 400)


class TopicAlreadyOpenedError(ForumError):
    """Topic już otwarty"""

    def __init__(self, message: str = "Topic is already opened"):
        super().__init__(message, 400)


class ForumGeneralNotSupportedError(ForumError):
    """Forum nie wspierane"""

    def __init__(self, message: str = "Forum is not supported"):
        super().__init__(message, 400)


class ForumRequiresUpgradeError(ForumError):
    """Forum wymaga aktualizacji"""

    def __init__(self, message: str = "Forum requires upgrade"):
        super().__init__(message, 400)


# ==================== Webhook/WebSocket Errors ====================


class WebhookUpdateError(WebhookError):
    """Błąd podczas przetwarzania webhooka"""

    def __init__(self, message: str):
        super().__init__(message)


class WebhookConnectionError(WebhookError):
    """Błąd połączenia webhooka"""

    def __init__(self, message: str):
        super().__init__(message)


class WebhooksslError(WebhookError):
    """Błąd SSL webhooka"""

    def __init__(self, message: str):
        super().__init__(message)


# ==================== Video Chat / Group Call Errors ====================


class VideoChatError(TelegramAPIError):
    """Bazowa klasa dla błędów związanych z video chat"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class VideoChatNotFoundError(VideoChatError):
    """Video chat nie znaleziono"""

    def __init__(self, message: str = "Video chat not found"):
        super().__init__(message, 404)


class VideoChatDisabledError(VideoChatError):
    """Video chat wyłączony"""

    def __init__(self, message: str = "Video chat is disabled"):
        super().__init__(message, 400)


class VideoChatAlreadyStartedError(VideoChatError):
    """Video chat już rozpoczęty"""

    def __init__(self, message: str = "Video chat already started"):
        super().__init__(message, 400)


class VideoChatNotStartedError(VideoChatError):
    """Video chat nie rozpoczęty"""

    def __init__(self, message: str = "Video chat not started"):
        super().__init__(message, 400)


class GroupCallNotFoundError(VideoChatError):
    """Group call nie znaleziono"""

    def __init__(self, message: str = "Group call not found"):
        super().__init__(message, 404)


class GroupCallAlreadyEndedError(VideoChatError):
    """Group call już zakończony"""

    def __init__(self, message: str = "Group call already ended"):
        super().__init__(message, 400)


class GroupCallInvalidError(VideoChatError):
    """Nieprawidłowy group call"""

    def __init__(self, message: str = "Group call is invalid"):
        super().__init__(message, 400)


# ==================== Chat Permissions Errors ====================


class ChatPermissionsError(TelegramAPIError):
    """Bazowa klasa dla błędów uprawnień czatu"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ChatPermissionsNotModifiedError(ChatPermissionsError):
    """Uprawnienia czatu nie zmodyfikowane"""

    def __init__(self, message: str = "Chat permissions not modified"):
        super().__init__(message, 400)


class ChatPermissionsNotEnoughError(ChatPermissionsError):
    """Niewystarczające uprawnienia czatu"""

    def __init__(self, message: str = "Not enough chat permissions"):
        super().__init__(message, 400)


# ==================== Menu Button Errors ====================


class MenuButtonError(TelegramAPIError):
    """Bazowa klasa dla błędów menu button"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class MenuButtonNotFoundError(MenuButtonError):
    """Menu button nie znaleziono"""

    def __init__(self, message: str = "Menu button not found"):
        super().__init__(message, 404)


class MenuButtonInvalidError(MenuButtonError):
    """Nieprawidłowy menu button"""

    def __init__(self, message: str = "Menu button is invalid"):
        super().__init__(message, 400)


class MenuButtonAlreadyExistsError(MenuButtonError):
    """Menu button już istnieje"""

    def __init__(self, message: str = "Menu button already exists"):
        super().__init__(message, 400)


# ==================== USSD Errors ====================


class UssdError(TelegramAPIError):
    """Bazowa klasa dla błędów USSD"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class UssdRequestError(UssdError):
    """Błąd zapytania USSD"""

    def __init__(self, message: str = "USSD request failed"):
        super().__init__(message, 400)


class UssdTimedOutError(UssdError):
    """USSD timed out"""

    def __init__(self, message: str = "USSD request timed out"):
        super().__init__(message, 400)


# ==================== Transfer Ownership Errors ====================


class TransferError(TelegramAPIError):
    """Bazowa klasa dla błędów transferu"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class TransferChatOwnershipError(TransferError):
    """Błąd transferu własności czatu"""

    def __init__(self, message: str = "Chat ownership transfer failed"):
        super().__init__(message, 400)


class TransferChannelOwnershipError(TransferError):
    """Błąd transferu własności kanału"""

    def __init__(self, message: str = "Channel ownership transfer failed"):
        super().__init__(message, 400)


class TransferNotAllowedError(TransferError):
    """Transfer niedozwolony"""

    def __init__(self, message: str = "Transfer not allowed"):
        super().__init__(message, 400)


class TransferToPvtChatError(TransferError):
    """Nie można transferować do prywatnego czatu"""

    def __init__(self, message: str = "Can't transfer to private chat"):
        super().__init__(message, 400)


# ==================== Telegram Stars / Gift Errors ====================


class StarsError(TelegramAPIError):
    """Bazowa klasa dla błędów Telegram Stars"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class StarsNotFoundError(StarsError):
    """Stars nie znaleziono"""

    def __init__(self, message: str = "Stars not found"):
        super().__init__(message, 404)


class StarsInsufficientError(StarsError):
    """Niewystarczające środki w Stars"""

    def __init__(self, message: str = "Insufficient stars balance"):
        super().__init__(message, 400)


class StarsInvalidError(StarsError):
    """Nieprawidłowe Stars"""

    def __init__(self, message: str = "Stars are invalid"):
        super().__init__(message, 400)


class GiftError(StarsError):
    """Bazowa klasa dla błędów prezentów"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class GiftNotFoundError(GiftError):
    """Prezent nie znaleziono"""

    def __init__(self, message: str = "Gift not found"):
        super().__init__(message, 404)


class GiftExpiredError(GiftError):
    """Prezent wygasł"""

    def __init__(self, message: str = "Gift has expired"):
        super().__init__(message, 400)


class GiftAlreadyRedeemedError(GiftError):
    """Prezent już wykorzystany"""

    def __init__(self, message: str = "Gift already redeemed"):
        super().__init__(message, 400)


class GiftInvalidError(GiftError):
    """Nieprawidłowy prezent"""

    def __init__(self, message: str = "Gift is invalid"):
        super().__init__(message, 400)


class GiftLimitedError(GiftError):
    """Prezent ograniczony"""

    def __init__(self, message: str = "Gift is limited"):
        super().__init__(message, 400)


# ==================== Premium Errors ====================


class PremiumError(TelegramAPIError):
    """Bazowa klasa dla błędów Premium"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class PremiumNotFoundError(PremiumError):
    """Premium nie znaleziono"""

    def __init__(self, message: str = "Premium subscription not found"):
        super().__init__(message, 404)


class PremiumExpiredError(PremiumError):
    """Premium wygasł"""

    def __init__(self, message: str = "Premium subscription expired"):
        super().__init__(message, 400)


class PremiumNotAllowedError(PremiumError):
    """Premium niedozwolony"""

    def __init__(self, message: str = "Premium not allowed"):
        super().__init__(message, 400)


class PremiumPurchaseFailedError(PremiumError):
    """Zakup Premium nie powiódł się"""

    def __init__(self, message: str = "Premium purchase failed"):
        super().__init__(message, 400)


# ==================== Deep Link Errors ====================


class DeepLinkError(TelegramAPIError):
    """Bazowa klasa dla błędów deep link"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class DeepLinkNotFoundError(DeepLinkError):
    """Deep link nie znaleziono"""

    def __init__(self, message: str = "Deep link not found"):
        super().__init__(message, 404)


class DeepLinkInvalidError(DeepLinkError):
    """Nieprawidłowy deep link"""

    def __init__(self, message: str = "Deep link is invalid"):
        super().__init__(message, 400)


class DeepLinkExpiredError(DeepLinkError):
    """Deep link wygasł"""

    def __init__(self, message: str = "Deep link has expired"):
        super().__init__(message, 400)


# ==================== Attachment Menu Errors ====================


class AttachmentMenuError(TelegramAPIError):
    """Bazowa klasa dla błędów menu załącznika"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class AttachmentMenuNotFoundError(AttachmentMenuError):
    """Menu załącznika nie znaleziono"""

    def __init__(self, message: str = "Attachment menu not found"):
        super().__init__(message, 404)


class AttachmentMenuInvalidError(AttachmentMenuError):
    """Nieprawidłowe menu załącznika"""

    def __init__(self, message: str = "Attachment menu is invalid"):
        super().__init__(message, 400)


# ==================== Main Web App Errors ====================


class WebAppError(TelegramAPIError):
    """Bazowa klasa dla błędów Web App"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class WebAppNotFoundError(WebAppError):
    """Web App nie znaleziono"""

    def __init__(self, message: str = "Web App not found"):
        super().__init__(message, 404)


class WebAppInvalidError(WebAppError):
    """Nieprawidłowy Web App"""

    def __init__(self, message: str = "Web App is invalid"):
        super().__init__(message, 400)


class WebAppCantInitError(WebAppError):
    """Nie można zainicjować Web App"""

    def __init__(self, message: str = "Can't initialize Web App"):
        super().__init__(message, 400)


class WebAppTimeoutError(WebAppError):
    """Web App timeout"""

    def __init__(self, message: str = "Web App timed out"):
        super().__init__(message, 400)


# ==================== Telegram Vault Errors ====================


class VaultError(TelegramAPIError):
    """Bazowa klasa dla błędów Vault"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class VaultTokenNotFoundError(VaultError):
    """Vault token nie znaleziono"""

    def __init__(self, message: str = "Vault token not found"):
        super().__init__(message, 404)


class VaultTokenInvalidError(VaultError):
    """Nieprawidłowy Vault token"""

    def __init__(self, message: str = "Vault token is invalid"):
        super().__init__(message, 400)


class VaultTooManyRequestsError(VaultError):
    """Za dużo requestów do Vault"""

    def __init__(self, message: str = "Too many vault requests"):
        super().__init__(message, 400)


# ==================== Saved Funds Errors ====================


class SavedFundsError(TelegramAPIError):
    """Bazowa klasa dla błędów Saved Funds"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class SavedFundsNotFoundError(SavedFundsError):
    """Saved funds nie znaleziono"""

    def __init__(self, message: str = "Saved funds not found"):
        super().__init__(message, 404)


class SavedFundsInsufficientError(SavedFundsError):
    """Niewystarczające środki"""

    def __init__(self, message: str = "Insufficient saved funds"):
        super().__init__(message, 400)


# ==================== Transaction Errors ====================


class TransactionError(TelegramAPIError):
    """Bazowa klasa dla błędów transakcji"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class TransactionNotFoundError(TransactionError):
    """Transakcja nie znaleziona"""

    def __init__(self, message: str = "Transaction not found"):
        super().__init__(message, 404)


class TransactionFailedError(TransactionError):
    """Transakcja nie powiodła się"""

    def __init__(self, message: str = "Transaction failed"):
        super().__init__(message, 400)


class TransactionPendingError(TransactionError):
    """Transakcja w toku"""

    def __init__(self, message: str = "Transaction is pending"):
        super().__init__(message, 400)


class TransactionCancelledError(TransactionError):
    """Transakcja anulowana"""

    def __init__(self, message: str = "Transaction cancelled"):
        super().__init__(message, 400)


# ==================== Quiz/Poll Quiz Mode Errors ====================


class QuizError(TelegramAPIError):
    """Bazowa klasa dla błędów quiz"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class PollOptionCorrectIdInvalidError(QuizError):
    """Nieprawidłowy correct_option_id dla quiz"""

    def __init__(self, message: str = "Poll correct_option_id is invalid"):
        super().__init__(message, 400)


class PollAnswersTooMuchError(QuizError):
    """Za dużo odpowiedzi w quiz (ponad 12)"""

    def __init__(self, message: str = "Poll has too many answers"):
        super().__init__(message, 400)


class QuizCorrectAnswerMissingError(QuizError):
    """Quiz bez poprawnej odpowiedzi"""

    def __init__(self, message: str = "Quiz correct answer is missing"):
        super().__init__(message, 400)


class QuizExplanationInvalidError(QuizError):
    """Nieprawidłowe wyjaśnienie quiz"""

    def __init__(self, message: str = "Quiz explanation is invalid"):
        super().__init__(message, 400)


class CannotSendQuizToChannelError(QuizError):
    """Nie można wysłać quiz do kanału"""

    def __init__(self, message: str = "Can't send quiz to channel"):
        super().__init__(message, 400)


# ==================== Paid Reactions / Star Reactions Errors ====================


class PaidReactionError(TelegramAPIError):
    """Bazowa klasa dla błędów płatnych reakcji"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class StarsBalanceTooLowError(PaidReactionError):
    """Niewystarczające środki w Stars"""

    def __init__(self, message: str = "Stars balance is too low"):
        super().__init__(message, 400)


class PaidReactionDisabledError(PaidReactionError):
    """Płatne reakcje wyłączone"""

    def __init__(self, message: str = "Paid reactions are disabled"):
        super().__init__(message, 400)


class PaidReactionCountInvalidError(PaidReactionError):
    """Nieprawidłowa liczba płatnych reakcji"""

    def __init__(self, message: str = "Paid reaction count is invalid"):
        super().__init__(message, 400)


class RandomIdExpiredError(PaidReactionError):
    """Random ID wygasł"""

    def __init__(self, message: str = "Random ID has expired"):
        super().__init__(message, 400)


class RandomIdEmptyError(PaidReactionError):
    """Random ID jest puste"""

    def __init__(self, message: str = "Random ID is empty"):
        super().__init__(message, 400)


# ==================== Paid Messages / Star Messages Errors ====================


class PaidMessageError(TelegramAPIError):
    """Bazowa klasa dla błędów płatnych wiadomości"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class PaidMessageNotEnabledError(PaidMessageError):
    """Płatne wiadomości wyłączone"""

    def __init__(self, message: str = "Paid messages are not enabled"):
        super().__init__(message, 403)


class PaidMessageTooManyError(PaidMessageError):
    """Za dużo płatnych wiadomości"""

    def __init__(self, message: str = "Too many paid messages"):
        super().__init__(message, 400)


class PaidMessagePaymentFailedError(PaidMessageError):
    """Płatność nie powiodła się"""

    def __init__(self, message: str = "Paid message payment failed"):
        super().__init__(message, 400)


class PaidMessageMinReactionNotMetError(PaidMessageError):
    """Minimalne reakcje nie spełnione"""

    def __init__(self, message: str = "Paid message min reaction not met"):
        super().__init__(message, 400)


# ==================== Rate Limit Scope Errors (API 7.8+) ====================


class RateLimitScopeError(RateLimitError):
    """Rate limit z określonym scope"""

    def __init__(
        self,
        retry_after: int,
        scope: str = "global",
        message: str = "Too Many Requests",
    ):
        self.scope = scope
        super().__init__(retry_after, message)


class FloodPremiumWaitError(RateLimitError):
    """Oczekiwanie premium przed ponowieniem"""

    def __init__(self, retry_after: int, message: str = "Flood premium wait"):
        super().__init__(retry_after, message)


# ==================== Voice/Video Messages Privacy Errors ====================


class VoiceMessagesForbiddenError(TelegramAPIError):
    """Wiadomości głosowe zablokowane przez użytkownika"""

    def __init__(self, message: str = "Voice messages are forbidden"):
        super().__init__(message, 400)


class VideoMessagesForbiddenError(TelegramAPIError):
    """Wiadomości wideo zablokowane przez użytkownika"""

    def __init__(self, message: str = "Video messages are forbidden"):
        super().__init__(message, 400)


# ==================== Chat Folder / Chatlist Errors ====================


class ChatFolderError(TelegramAPIError):
    """Bazowa klasa dla błędów folderu czatu"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class ChatlistInviteInvalidError(ChatFolderError):
    """Nieprawidłowy invite folderu czatu"""

    def __init__(self, message: str = "Chat folder invite is invalid"):
        super().__init__(message, 400)


class ChatlistInviteAlreadyExistsError(ChatFolderError):
    """Invite folderu czatu już istnieje"""

    def __init__(self, message: str = "Chat folder invite already exists"):
        super().__init__(message, 400)


class ChatlistTooManyChatsError(ChatFolderError):
    """Za dużo czatów w folderze"""

    def __init__(self, message: str = "Too many chats in folder"):
        super().__init__(message, 400)


class ChatlistNoPublicChatsError(ChatFolderError):
    """Brak publicznych czatów do udostępnienia"""

    def __init__(self, message: str = "No public chats to share"):
        super().__init__(message, 400)


class ChatlistJoinFailedError(ChatFolderError):
    """Nie udało się dołączyć do folderu czatu"""

    def __init__(self, message: str = "Failed to join chat folder"):
        super().__init__(message, 400)


# ==================== Peer/Chat ID Errors ====================


class PeerError(TelegramAPIError):
    """Bazowa klasa dla błędów peer ID"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class PeerIdInvalidError(PeerError):
    """Nieprawidłowy peer ID"""

    def __init__(self, message: str = "Peer ID is invalid"):
        super().__init__(message, 400)


class ChatTooManyMembersError(PeerError):
    """Za dużo członków do dodania"""

    def __init__(self, message: str = "Too many members to add"):
        super().__init__(message, 400)


class MemberNotInChatError(PeerError):
    """Użytkownik nie jest członkiem czatu"""

    def __init__(self, message: str = "Member not in chat"):
        super().__init__(message, 400)


# ==================== Auth/Key Errors ====================


class AuthKeyError(TelegramAPIError):
    """Bazowa klasa dla błędów auth key"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class AuthKeyUnregisteredError(AuthKeyError):
    """Auth key nie zarejestrowany"""

    def __init__(self, message: str = "Auth key is unregistered"):
        super().__init__(message, 401)


class AuthKeyInvalidError(AuthKeyError):
    """Nieprawidłowy auth key"""

    def __init__(self, message: str = "Auth key is invalid"):
        super().__init__(message, 401)


class AuthKeyDuplicatedError(AuthKeyError):
    """Auth key już w użyciu gdzie indziej"""

    def __init__(self, message: str = "Auth key is duplicated"):
        super().__init__(message, 406)


class AuthKeyPermEmptyError(AuthKeyError):
    """Tymczasowy klucz nie powiązany z stałym"""

    def __init__(self, message: str = "Auth key not bound to permanent"):
        super().__init__(message, 401)


# ==================== Content/Message Errors ====================


class ContentError(TelegramAPIError):
    """Bazowa klasa dla błędów treści"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class MessageTextEmptyError(ContentError):
    """Pusty tekst wiadomości"""

    def __init__(self, message: str = "Message text is empty"):
        super().__init__(message, 400)


class MessageIdInvalidError(ContentError):
    """Nieprawidłowy ID wiadomości"""

    def __init__(self, message: str = "Message ID is invalid"):
        super().__init__(message, 400)


class MediaEmptyError(ContentError):
    """Pusty plik mediów"""

    def __init__(self, message: str = "Media file is empty"):
        super().__init__(message, 400)


class PhotoCropProcessFailedError(ContentError):
    """Błąd przetwarzania zdjęcia"""

    def __init__(self, message: str = "Photo crop process failed"):
        super().__init__(message, 400)


class MessageDurationTooLongError(ContentError):
    """Zbyt długi czas trwania wiadomości"""

    def __init__(self, message: str = "Message duration is too long"):
        super().__init__(message, 400)


# ==================== Bot/Token Errors ====================


class BotInactiveError(UnauthorizedError):
    """Bot token nieaktywny"""

    def __init__(self, message: str = "Bot is inactive"):
        super().__init__(message, 401)


class AnonymousAdminRequiredError(BadRequestError):
    """Wymagany anonimowy admin"""

    def __init__(self, message: str = "Anonymous admin required"):
        super().__init__(message)


class UserBotRequiredError(BadRequestError):
    """Wymagane konto bot"""

    def __init__(self, message: str = "Bot account required"):
        super().__init__(message)


class APIErrorNotFoundError(NotFoundError):
    """Nieznana metoda API"""

    def __init__(self, message: str = "Method not found"):
        super().__init__(message, 404)


class APIMethodDeprecatedError(TelegramAPIError):
    """Metoda API przestarzała"""

    def __init__(self, message: str = "API method is deprecated"):
        super().__init__(message, 426)


# ==================== Chat Not Modified Errors ====================


class NotModifiedError(BadRequestError):
    """Brak zmian do zastosowania"""

    def __init__(self, message: str = "Chat not modified"):
        super().__init__(message)


class UsernameNotModifiedError(NotModifiedError):
    """Nazwa użytkownika bez zmian"""

    def __init__(self, message: str = "Username not modified"):
        super().__init__(message)


class AboutNotModifiedError(NotModifiedError):
    """Informacja o czacie bez zmian"""

    def __init__(self, message: str = "About not modified"):
        super().__init__(message)


# ==================== File Reference Errors ====================


class FileReferenceError(MediaError):
    """Bazowa klasa dla błędów referencji pliku"""

    def __init__(self, message: str, code: Optional[int] = None):
        self.message = message
        super().__init__(message, code)


class FileReferenceEmptyError(FileReferenceError):
    """Referencja pliku wygasła"""

    def __init__(self, message: str = "File reference is empty"):
        super().__init__(message, 400)


class FileDownloadUnavailableError(FileReferenceError):
    """Plik niedostępny do pobrania"""

    def __init__(self, message: str = "File download unavailable"):
        super().__init__(message, 400)


class FileMigratedError(FileReferenceError):
    """Plik przeniesiony do innego DC"""

    def __init__(self, message: str = "File migrated to another DC"):
        super().__init__(message, 303)


# ==================== Chat Slow Mode / Deutonomy Errors ====================


class DeutonomyActiveError(TelegramAPIError):
    """Tryb deuteronomii aktywny"""

    def __init__(self, message: str = "Deutonomy mode is active"):
        super().__init__(message, 400)


# ==================== Webhook IP/Cert Errors ====================


class WebhookIpForbiddenError(WebhookError):
    """IP niedozwolone dla webhooka"""

    def __init__(self, message: str = "Webhook IP is forbidden"):
        super().__init__(message)


class WebhookPortConflictError(WebhookError):
    """Port webhooka zajęty"""

    def __init__(self, message: str = "Webhook port conflict"):
        super().__init__(message)


class WebhookInvalidCertError(WebhookError):
    """Nieprawidłowy certyfikat SSL"""

    def __init__(self, message: str = "Webhook SSL certificate is invalid"):
        super().__init__(message)


# ==================== Inline Modal/Theme Errors ====================


class InlineModalTimeoutError(TelegramAPIError):
    """Timeout inline modala"""

    def __init__(self, message: str = "Inline modal timed out"):
        super().__init__(message, 400)


class WallpaperInvalidError(TelegramAPIError):
    """Nieprawidłowa tapeta"""

    def __init__(self, message: str = "Wallpaper is invalid"):
        super().__init__(message, 400)


class ThemeInvalidError(TelegramAPIError):
    """Nieprawidłowy motyw"""

    def __init__(self, message: str = "Theme is invalid"):
        super().__init__(message, 400)


def handle_telegram_error(error_data: Dict) -> TelegramAPIError:
    """
    Konwertuje odpowiedź błędu z Telegram API na odpowiedni wyjątek

    Args:
        error_data: Słownik z błędem z Telegram API

    Returns:
        Odpowiedni wyjątek TelegramAPIError
    """
    error_code = error_data.get("error_code")
    description = error_data.get("description", "Unknown error")
    parameters = error_data.get("parameters", {})

    desc_lower = description.lower()

    if error_code == 400:
        # Check for specific message-related errors
        if "not modified" in desc_lower:
            return MessageNotModifiedError(description)
        elif "message" in desc_lower and (
            "delete" in desc_lower or "can't be deleted" in desc_lower
        ):
            return MessageToDeleteError(description)
        elif "message" in desc_lower and (
            "forward" in desc_lower or "can't be forwarded" in desc_lower
        ):
            return MessageToForwardError(description)
        elif "message" in desc_lower and (
            "reply" in desc_lower or "can't be replied" in desc_lower
        ):
            return MessageToReplyError(description)
        elif "caption" in desc_lower and "too long" in desc_lower:
            return MessageCaptionTooLongError(description)
        elif "entities" in desc_lower and "too long" in desc_lower:
            return MessageEntitiesTooLongError(description)
        elif "reply markup" in desc_lower and "too long" in desc_lower:
            return ReplyMarkupTooLongError(description)
        elif "reply markup" in desc_lower and "invalid" in desc_lower:
            return ReplyMarkupInvalidError(description)
        elif "button" in desc_lower and "invalid" in desc_lower:
            return ButtonDataInvalidError(description)
        elif "bot" in desc_lower and "talk" in desc_lower:
            return CantTalkWithBotsError(description)
        # Check for user-related errors
        elif "user" in desc_lower and "bot" in desc_lower:
            return UserIsBotError(description)
        elif "user" in desc_lower and (
            "already" in desc_lower or "participant" in desc_lower
        ):
            return UserAlreadyParticipantError(description)
        elif (
            "user" in desc_lower and "not" in desc_lower and "participant" in desc_lower
        ):
            return UserNotParticipantError(description)
        elif "bot" in desc_lower and ("already" in desc_lower or "used" in desc_lower):
            return BotAlreadyUsedError(description)
        # Check for group/chat errors
        elif "migrat" in desc_lower and (
            "group" in desc_lower or "supergroup" in desc_lower
        ):
            return GroupMigratedError(description)
        elif "chat" in desc_lower and "title" in desc_lower and "invalid" in desc_lower:
            return ChatTitleInvalidError(description)
        elif (
            "chat" in desc_lower
            and "description" in desc_lower
            and "invalid" in desc_lower
        ):
            return ChatDescriptionInvalidError(description)
        elif "chat" in desc_lower and "photo" in desc_lower and "invalid" in desc_lower:
            return ChatPhotoInvalidError(description)
        elif (
            "invite" in desc_lower and "link" in desc_lower and "invalid" in desc_lower
        ):
            return ChatInviteLinkInvalidError(description)
        elif "admin" in desc_lower and "already" in desc_lower:
            return UserIsAdministratorError(description)
        # Check for media/file errors
        elif "file" in desc_lower and (
            "too large" in desc_lower or "size" in desc_lower
        ):
            return FileTooLargeError(description)
        elif "file" in desc_lower and "invalid" in desc_lower:
            return FileInvalidError(description)
        elif "file type" in desc_lower and "not supported" in desc_lower:
            return FileTypeNotSupportedError(description)
        elif (
            "photo" in desc_lower
            and "dimension" in desc_lower
            and "invalid" in desc_lower
        ):
            return PhotoDimensionsInvalidError(description)
        elif "video" in desc_lower and (
            "too long" in desc_lower or "duration" in desc_lower
        ):
            return VideoDurationTooLongError(description)
        elif (
            "audio" in desc_lower
            and "duration" in desc_lower
            and "invalid" in desc_lower
        ):
            return AudioDurationInvalidError(description)
        elif "mime" in desc_lower and "invalid" in desc_lower:
            return DocumentMimeTypeInvalidError(description)
        # Check for sticker errors
        elif (
            "sticker" in desc_lower and "set" in desc_lower and "invalid" in desc_lower
        ):
            return StickerSetInvalidError(description)
        elif (
            "sticker" in desc_lower
            and "emoji" in desc_lower
            and "invalid" in desc_lower
        ):
            return StickerEmojiInvalidError(description)
        elif (
            "sticker" in desc_lower
            and "png" in desc_lower
            and "dimension" in desc_lower
        ):
            return StickerPngDimensionsInvalidError(description)
        elif "tgs" in desc_lower or "animated" in desc_lower:
            return StickerTgsInvalidError(description)
        elif "animation" in desc_lower or "gif" in desc_lower:
            return AnimationInvalidError(description)
        # Check for location errors
        elif "location" in desc_lower and "invalid" in desc_lower:
            return LocationInvalidError(description)
        elif "venue" in desc_lower and "invalid" in desc_lower:
            return VenueInvalidError(description)
        elif "live location" in desc_lower and "expir" in desc_lower:
            return LiveLocationPeriodExpiredError(description)
        elif (
            "live location" in desc_lower
            and "already" in desc_lower
            and "stopped" in desc_lower
        ):
            return LiveLocationAlreadyStoppedError(description)
        # Check for contact errors
        elif "contact" in desc_lower and "user" in desc_lower and "id" in desc_lower:
            return ContactUserIdInvalidError(description)
        elif "contact" in desc_lower and "phone" in desc_lower:
            return ContactPhoneNumberInvalidError(description)
        # Check for poll errors
        elif (
            "poll" in desc_lower and "already" in desc_lower and "closed" in desc_lower
        ):
            return PollAlreadyClosedError(description)
        elif "poll" in desc_lower and "already" in desc_lower and "exist" in desc_lower:
            return PollAlreadyExistsError(description)
        elif (
            "poll" in desc_lower
            and "question" in desc_lower
            and "invalid" in desc_lower
        ):
            return PollQuestionInvalidError(description)
        elif (
            "poll" in desc_lower and "option" in desc_lower and "invalid" in desc_lower
        ):
            return PollOptionsInvalidError(description)
        elif "poll" in desc_lower and "option" in desc_lower and "type" in desc_lower:
            return PollOptionsTypeInvalidError(description)
        # Check for inline query errors
        elif (
            "inline" in desc_lower
            and "query" in desc_lower
            and "id" in desc_lower
            and "invalid" in desc_lower
        ):
            return InlineQueryIdInvalidError(description)
        elif (
            "inline" in desc_lower
            and "result" in desc_lower
            and "invalid" in desc_lower
        ):
            return InlineQueryResultInvalidError(description)
        elif "inline" in desc_lower and (
            "too many" in desc_lower or "results" in desc_lower
        ):
            return InlineQueryResultsTooManyError(description)
        elif "switch" in desc_lower and "pm" in desc_lower and "text" in desc_lower:
            return SwitchPmTextInvalidError(description)
        elif (
            "switch" in desc_lower and "pm" in desc_lower and "parameter" in desc_lower
        ):
            return SwitchPmParameterInvalidError(description)
        # Check for callback query errors
        elif (
            "callback" in desc_lower
            and "query" in desc_lower
            and "id" in desc_lower
            and "invalid" in desc_lower
        ):
            return CallbackQueryIdInvalidError(description)
        elif (
            "callback" in desc_lower
            and "data" in desc_lower
            and "too long" in desc_lower
        ):
            return CallbackQueryDataTooLongError(description)
        elif (
            "callback" in desc_lower
            and "answer" in desc_lower
            and "expir" in desc_lower
        ):
            return CallbackQueryAnswerExpiredError(description)
        # Check for shipping errors
        elif (
            "shipping" in desc_lower
            and "address" in desc_lower
            and "invalid" in desc_lower
        ):
            return ShippingAddressInvalidError(description)
        elif "shipping" in desc_lower and "query" in desc_lower and "id" in desc_lower:
            return ShippingQueryIdInvalidError(description)
        elif (
            "shipping" in desc_lower
            and "option" in desc_lower
            and "invalid" in desc_lower
        ):
            return ShippingOptionInvalidError(description)
        elif "shipping" in desc_lower and "required" in desc_lower:
            return ShippingOptionsRequiredError(description)
        elif "pre-checkout" in desc_lower or "pre checkout" in desc_lower:
            return PreCheckoutQueryIdInvalidError(description)
        elif "order" in desc_lower and "info" in desc_lower and "invalid" in desc_lower:
            return OrderInfoInvalidError(description)
        # Check for channel errors
        elif "channel" in desc_lower and "private" in desc_lower:
            return ChannelPrivateError(description)
        elif "channel" in desc_lower and "not" in desc_lower and "exist" in desc_lower:
            return ChannelNotCreatedError(description)
        elif "broadcast" in desc_lower and "required" in desc_lower:
            return BroadcastRequiredError(description)
        elif "too many" in desc_lower and "channel" in desc_lower:
            return ChannelTooManyError(description)
        # Check for slow mode errors
        elif "slow" in desc_lower and "mode" in desc_lower and "enabled" in desc_lower:
            return SlowModeEnabledError(description)
        elif "slow" in desc_lower and "mode" in desc_lower and "delay" in desc_lower:
            return SlowModeDelayActiveError(description)
        # Check for permission errors
        elif "send" in desc_lower and "message" in desc_lower and "not" in desc_lower:
            return SendMessageNotAllowedError(description)
        elif "send" in desc_lower and "media" in desc_lower and "not" in desc_lower:
            return SendMediaNotAllowedError(description)
        elif "send" in desc_lower and "poll" in desc_lower and "not" in desc_lower:
            return SendPollNotAllowedError(description)
        elif "change" in desc_lower and "info" in desc_lower and "not" in desc_lower:
            return ChangeInfoNotAllowedError(description)
        elif "invite" in desc_lower and "user" in desc_lower and "not" in desc_lower:
            return InviteUserNotAllowedError(description)
        elif "pin" in desc_lower and "message" in desc_lower and "not" in desc_lower:
            return PinMessageNotAllowedError(description)
        # Check for method availability errors
        elif (
            "method" in desc_lower
            and "not" in desc_lower
            and "available" in desc_lower
            and "channel" in desc_lower
        ):
            return MethodNotAvailableInChannelError(description)
        elif (
            "method" in desc_lower
            and "not" in desc_lower
            and "available" in desc_lower
            and "group" in desc_lower
        ):
            return MethodNotAvailableInGroupError(description)
        # Check for phone errors
        elif (
            "phone" in desc_lower and "number" in desc_lower and "invalid" in desc_lower
        ):
            return PhoneNumberInvalidError(description)
        elif "phone" in desc_lower and "code" in desc_lower and "invalid" in desc_lower:
            return PhoneCodeInvalidError(description)
        # Check for payment-related errors
        elif "invoice" in desc_lower and "invalid" in desc_lower:
            return InvalidInvoiceError(description)
        elif "invoice" in desc_lower and "expired" in desc_lower:
            return InvoiceExpiredError(description)
        elif "can't send invoice" in desc_lower:
            return CantSendInvoiceError(description)
        elif "payment" in desc_lower and "failed" in desc_lower:
            return PaymentFailedError(description)
        elif "currency" in desc_lower and (
            "not supported" in desc_lower or "unsupported" in desc_lower
        ):
            return PaymentCurrencyNotSupportedError(description)
        elif "amount" in desc_lower and (
            "invalid" in desc_lower or "incorrect" in desc_lower
        ):
            return PaymentAmountInvalidError(description)
        # Check for story errors
        elif "story" in desc_lower and "not modified" in desc_lower:
            return StoryNotModifiedError(description)
        elif "story" in desc_lower and "expired" in desc_lower:
            return StoryExpiredError(description)
        elif "story" in desc_lower and "no media" in desc_lower:
            return StoryHasNoMediaError(description)
        elif (
            "story" in desc_lower and "media" in desc_lower and "invalid" in desc_lower
        ):
            return StoryMediaInvalidError(description)
        elif "story" in desc_lower and (
            "too many" in desc_lower or "limit" in desc_lower
        ):
            return StoryTooManyError(description)
        # Check for reaction errors
        elif "reaction" in desc_lower and "too many" in desc_lower:
            return ReactionTooManyError(description)
        elif "reaction" in desc_lower and (
            "invalid" in desc_lower or "not supported" in desc_lower
        ):
            return ReactionInvalidError(description)
        elif "reaction" in desc_lower and "not allowed" in desc_lower:
            return ReactionNotAllowedError(description)
        elif "emoji" in desc_lower and "invalid" in desc_lower:
            return EmojiInvalidError(description)
        # Check for quote errors
        elif "quote" in desc_lower and (
            "invalid" in desc_lower or "not found" in desc_lower
        ):
            return QuoteInvalidError(description)
        elif "quote" in desc_lower and "too old" in desc_lower:
            return QuoteTooOldError(description)
        # Check for business errors
        elif (
            "business" in desc_lower
            and "connection" in desc_lower
            and ("invalid" in desc_lower or "not found" in desc_lower)
        ):
            return BusinessConnectionInvalidError(description)
        elif "business" in desc_lower and (
            "account" in desc_lower and "not found" in desc_lower
        ):
            return BusinessAccountNotFoundError(description)
        elif (
            "business" in desc_lower
            and "ownership" in desc_lower
            and "transferred" in desc_lower
        ):
            return BusinessOwnershipTransferredError(description)
        elif "greeting" in desc_lower and "already exists" in desc_lower:
            return BusinessGreetingAlreadyExistsError(description)
        elif "away message" in desc_lower and "already exists" in desc_lower:
            return BusinessAwayMessageAlreadyExistsError(description)
        # Check for collectible errors
        elif "collectible" in desc_lower and (
            "not found" in desc_lower or "invalid" in desc_lower
        ):
            return CollectibleInvalidError(description)
        elif "collectible" in desc_lower and "sold out" in desc_lower:
            return CollectibleSoldOutError(description)
        elif "giveaway" in desc_lower and (
            "not found" in desc_lower or "invalid" in desc_lower
        ):
            return GiveawayInvalidError(description)
        elif "giveaway" in desc_lower and "completed" in desc_lower:
            return GiveawayCompletedError(description)
        # Check for share URL errors
        elif "share" in desc_lower and "url" in desc_lower and "invalid" in desc_lower:
            return ShareUrlInvalidError(description)
        elif "share" in desc_lower and "url" in desc_lower and "occupied" in desc_lower:
            return ShareUrlOccupiedError(description)
        # Check for forum/topic errors
        elif "topic" in desc_lower and "not found" in desc_lower:
            return TopicNotFoundError(description)
        elif "topic" in desc_lower and "closed" in desc_lower:
            return TopicClosedError(description)
        elif "topic" in desc_lower and "already closed" in desc_lower:
            return TopicAlreadyClosedError(description)
        elif "topic" in desc_lower and "already opened" in desc_lower:
            return TopicAlreadyOpenedError(description)
        elif "forum" in desc_lower and "not supported" in desc_lower:
            return ForumGeneralNotSupportedError(description)
        # Check for chat boost errors
        elif "boost" in desc_lower and "not found" in desc_lower:
            return ChatBoostNotFoundError(description)
        elif "boost" in desc_lower and "expired" in desc_lower:
            return ChatBoostExpiredError(description)
        elif "boost" in desc_lower and "already applied" in desc_lower:
            return ChatBoostAlreadyAppliedError(description)
        elif (
            "boost" in desc_lower and "source" in desc_lower and "invalid" in desc_lower
        ):
            return ChatBoostSourceInvalidError(description)
        # Check for video chat / group call errors
        elif "video chat" in desc_lower and "not found" in desc_lower:
            return VideoChatNotFoundError(description)
        elif "video chat" in desc_lower and "disabled" in desc_lower:
            return VideoChatDisabledError(description)
        elif "video chat" in desc_lower and "already started" in desc_lower:
            return VideoChatAlreadyStartedError(description)
        elif "video chat" in desc_lower and "not started" in desc_lower:
            return VideoChatNotStartedError(description)
        elif "group call" in desc_lower and "not found" in desc_lower:
            return GroupCallNotFoundError(description)
        elif "group call" in desc_lower and "already ended" in desc_lower:
            return GroupCallAlreadyEndedError(description)
        elif "group call" in desc_lower and "invalid" in desc_lower:
            return GroupCallInvalidError(description)
        # Check for menu button errors
        elif "menu button" in desc_lower and "not found" in desc_lower:
            return MenuButtonNotFoundError(description)
        elif "menu button" in desc_lower and "invalid" in desc_lower:
            return MenuButtonInvalidError(description)
        elif "menu button" in desc_lower and "already exists" in desc_lower:
            return MenuButtonAlreadyExistsError(description)
        # Check for USSD errors
        elif "ussd" in desc_lower and "failed" in desc_lower:
            return UssdRequestError(description)
        elif "ussd" in desc_lower and "timed out" in desc_lower:
            return UssdTimedOutError(description)
        # Check for transfer errors
        elif "transfer" in desc_lower and "chat ownership" in desc_lower:
            return TransferChatOwnershipError(description)
        elif "transfer" in desc_lower and "channel ownership" in desc_lower:
            return TransferChannelOwnershipError(description)
        elif "transfer" in desc_lower and "not allowed" in desc_lower:
            return TransferNotAllowedError(description)
        # Check for Stars / Gift errors
        elif "stars" in desc_lower and "not found" in desc_lower:
            return StarsNotFoundError(description)
        elif "stars" in desc_lower and "insufficient" in desc_lower:
            return StarsInsufficientError(description)
        elif "gift" in desc_lower and "not found" in desc_lower:
            return GiftNotFoundError(description)
        elif "gift" in desc_lower and "expired" in desc_lower:
            return GiftExpiredError(description)
        elif "gift" in desc_lower and "already redeemed" in desc_lower:
            return GiftAlreadyRedeemedError(description)
        elif "gift" in desc_lower and "invalid" in desc_lower:
            return GiftInvalidError(description)
        elif "gift" in desc_lower and "limited" in desc_lower:
            return GiftLimitedError(description)
        # Check for Premium errors
        elif "premium" in desc_lower and "not found" in desc_lower:
            return PremiumNotFoundError(description)
        elif "premium" in desc_lower and "expired" in desc_lower:
            return PremiumExpiredError(description)
        elif "premium" in desc_lower and "not allowed" in desc_lower:
            return PremiumNotAllowedError(description)
        elif "premium" in desc_lower and "failed" in desc_lower:
            return PremiumPurchaseFailedError(description)
        # Check for Deep Link errors
        elif "deep link" in desc_lower and "not found" in desc_lower:
            return DeepLinkNotFoundError(description)
        elif "deep link" in desc_lower and "invalid" in desc_lower:
            return DeepLinkInvalidError(description)
        elif "deep link" in desc_lower and "expired" in desc_lower:
            return DeepLinkExpiredError(description)
        # Check for Web App errors
        elif "web app" in desc_lower and "not found" in desc_lower:
            return WebAppNotFoundError(description)
        elif "web app" in desc_lower and "invalid" in desc_lower:
            return WebAppInvalidError(description)
        elif "web app" in desc_lower and "cant init" in desc_lower:
            return WebAppCantInitError(description)
        elif "web app" in desc_lower and "timed out" in desc_lower:
            return WebAppTimeoutError(description)
        # Check for Vault errors
        elif (
            "vault" in desc_lower
            and "token" in desc_lower
            and "not found" in desc_lower
        ):
            return VaultTokenNotFoundError(description)
        elif (
            "vault" in desc_lower and "token" in desc_lower and "invalid" in desc_lower
        ):
            return VaultTokenInvalidError(description)
        elif "vault" in desc_lower and "too many" in desc_lower:
            return VaultTooManyRequestsError(description)
        # Check for Saved Funds / Transaction errors
        elif "saved funds" in desc_lower and "not found" in desc_lower:
            return SavedFundsNotFoundError(description)
        elif "saved funds" in desc_lower and "insufficient" in desc_lower:
            return SavedFundsInsufficientError(description)
        elif "transaction" in desc_lower and "not found" in desc_lower:
            return TransactionNotFoundError(description)
        elif "transaction" in desc_lower and "failed" in desc_lower:
            return TransactionFailedError(description)
        elif "transaction" in desc_lower and "pending" in desc_lower:
            return TransactionPendingError(description)
        elif "transaction" in desc_lower and "cancelled" in desc_lower:
            return TransactionCancelledError(description)
        elif "chat permissions" in desc_lower and "not modified" in desc_lower:
            return ChatPermissionsNotModifiedError(description)
        elif "chat permissions" in desc_lower and "not enough" in desc_lower:
            return ChatPermissionsNotEnoughError(description)
        # Check for poll/quiz errors
        elif "poll" in desc_lower and "correct_option_id" in desc_lower:
            return PollOptionCorrectIdInvalidError(description)
        elif "poll" in desc_lower and "too many answers" in desc_lower:
            return PollAnswersTooMuchError(description)
        elif (
            "quiz" in desc_lower
            and "correct answer" in desc_lower
            and "missing" in desc_lower
        ):
            return QuizCorrectAnswerMissingError(description)
        elif (
            "quiz" in desc_lower
            and "explanation" in desc_lower
            and "invalid" in desc_lower
        ):
            return QuizExplanationInvalidError(description)
        elif "quiz" in desc_lower and "to channel" in desc_lower:
            return CannotSendQuizToChannelError(description)
        # Check for paid reactions/stars errors
        elif "balance" in desc_lower and "too low" in desc_lower:
            return StarsBalanceTooLowError(description)
        elif "paid reaction" in desc_lower and (
            "disabled" in desc_lower or "not allowed" in desc_lower
        ):
            return PaidReactionDisabledError(description)
        elif (
            "paid reaction" in desc_lower
            and "count" in desc_lower
            and "invalid" in desc_lower
        ):
            return PaidReactionCountInvalidError(description)
        elif "random" in desc_lower and "id" in desc_lower and "expired" in desc_lower:
            return RandomIdExpiredError(description)
        elif "random" in desc_lower and "id" in desc_lower and "empty" in desc_lower:
            return RandomIdEmptyError(description)
        # Check for paid messages errors
        elif "paid message" in desc_lower and "not enabled" in desc_lower:
            return PaidMessageNotEnabledError(description)
        elif "paid message" in desc_lower and "too many" in desc_lower:
            return PaidMessageTooManyError(description)
        elif (
            "paid message" in desc_lower
            and "payment" in desc_lower
            and "failed" in desc_lower
        ):
            return PaidMessagePaymentFailedError(description)
        elif "paid message" in desc_lower and "min reaction" in desc_lower:
            return PaidMessageMinReactionNotMetError(description)
        # Check for voice/video messages errors
        elif "voice message" in desc_lower and (
            "forbidden" in desc_lower or "not allowed" in desc_lower
        ):
            return VoiceMessagesForbiddenError(description)
        elif "video message" in desc_lower and (
            "forbidden" in desc_lower or "not allowed" in desc_lower
        ):
            return VideoMessagesForbiddenError(description)
        # Check for chat folder errors
        elif (
            "chat folder" in desc_lower
            and "invite" in desc_lower
            and "invalid" in desc_lower
        ):
            return ChatlistInviteInvalidError(description)
        elif (
            "chat folder" in desc_lower
            and "invite" in desc_lower
            and "already" in desc_lower
        ):
            return ChatlistInviteAlreadyExistsError(description)
        elif "chat folder" in desc_lower and "too many" in desc_lower:
            return ChatlistTooManyChatsError(description)
        elif "chat folder" in desc_lower and "no public" in desc_lower:
            return ChatlistNoPublicChatsError(description)
        elif "chat folder" in desc_lower and "failed" in desc_lower:
            return ChatlistJoinFailedError(description)
        # Check for peer errors
        elif "peer" in desc_lower and "id" in desc_lower and "invalid" in desc_lower:
            return PeerIdInvalidError(description)
        elif "too many" in desc_lower and "members" in desc_lower:
            return ChatTooManyMembersError(description)
        elif "member" in desc_lower and "not in chat" in desc_lower:
            return MemberNotInChatError(description)
        # Check for auth/key errors
        elif "auth key" in desc_lower and "unregistered" in desc_lower:
            return AuthKeyUnregisteredError(description)
        elif "auth key" in desc_lower and "invalid" in desc_lower:
            return AuthKeyInvalidError(description)
        elif "auth key" in desc_lower and "duplicated" in desc_lower:
            return AuthKeyDuplicatedError(description)
        elif "auth key" in desc_lower and "not bound" in desc_lower:
            return AuthKeyPermEmptyError(description)
        # Check for content errors
        elif "message" in desc_lower and "text" in desc_lower and "empty" in desc_lower:
            return MessageTextEmptyError(description)
        elif "message" in desc_lower and "id" in desc_lower and "invalid" in desc_lower:
            return MessageIdInvalidError(description)
        elif "media" in desc_lower and "empty" in desc_lower:
            return MediaEmptyError(description)
        elif "photo" in desc_lower and "crop" in desc_lower and "failed" in desc_lower:
            return PhotoCropProcessFailedError(description)
        elif "duration" in desc_lower and "too long" in desc_lower:
            return MessageDurationTooLongError(description)
        # Check for bot/token errors
        elif "bot" in desc_lower and "inactive" in desc_lower:
            return BotInactiveError(description)
        elif (
            "anonymous" in desc_lower
            and "admin" in desc_lower
            and "required" in desc_lower
        ):
            return AnonymousAdminRequiredError(description)
        elif "userbot required" in desc_lower or (
            "bot" in desc_lower and "required" in desc_lower
        ):
            return UserBotRequiredError(description)
        # Check for not modified errors
        elif "username" in desc_lower and "not modified" in desc_lower:
            return UsernameNotModifiedError(description)
        elif "about" in desc_lower and "not modified" in desc_lower:
            return AboutNotModifiedError(description)
        elif "not modified" in desc_lower:
            return NotModifiedError(description)
        # Check for file reference errors
        elif "file reference" in desc_lower and "empty" in desc_lower:
            return FileReferenceEmptyError(description)
        elif "file download" in desc_lower and "unavailable" in desc_lower:
            return FileDownloadUnavailableError(description)
        # Check for deutonomy errors
        elif "deutonomy" in desc_lower and "active" in desc_lower:
            return DeutonomyActiveError(description)
        # Check for webhook errors
        elif (
            "webhook" in desc_lower and "ip" in desc_lower and "forbidden" in desc_lower
        ):
            return WebhookIpForbiddenError(description)
        elif "webhook" in desc_lower and "port" in desc_lower:
            return WebhookPortConflictError(description)
        elif (
            "webhook" in desc_lower and "cert" in desc_lower and "invalid" in desc_lower
        ):
            return WebhookInvalidCertError(description)
        # Check for inline modal/theme errors
        elif "inline modal" in desc_lower and "timed out" in desc_lower:
            return InlineModalTimeoutError(description)
        elif "wallpaper" in desc_lower and "invalid" in desc_lower:
            return WallpaperInvalidError(description)
        elif "theme" in desc_lower and "invalid" in desc_lower:
            return ThemeInvalidError(description)
        else:
            return BadRequestError(description)
    elif error_code == 401:
        if "session" in desc_lower and "expir" in desc_lower:
            return SessionExpiredError(description)
        elif "access" in desc_lower and "token" in desc_lower and "expir" in desc_lower:
            return AccessTokenExpiredError(description)
        else:
            return UnauthorizedError(description)
    elif error_code == 402:
        return PaymentRequiredError(description)
    elif error_code == 403:
        # Check for specific chat-related errors
        if "initiate" in desc_lower and "conversation" in desc_lower:
            return CantInitiateConversationError(description)
        elif "chat" in desc_lower and (
            "restrict" in desc_lower or "forbidden" in desc_lower
        ):
            return ChatRestrictedError(description)
        # Check for user-related errors
        elif "admin" in desc_lower and (
            "required" in desc_lower or "rights" in desc_lower
        ):
            return AdminRequiredError(description)
        elif "user" in desc_lower and (
            "deactivat" in desc_lower or "banned" in desc_lower
        ):
            return UserIsDeactivatedError(description)
        elif "user" in desc_lower and "kicked" in desc_lower:
            return UserIsKickedError(description)
        elif "user" in desc_lower and "restrict" in desc_lower:
            return UserIsRestrictedError(description)
        # Check for permission errors
        elif "send" in desc_lower and "message" in desc_lower and "not" in desc_lower:
            return SendMessageNotAllowedError(description)
        elif "send" in desc_lower and "media" in desc_lower and "not" in desc_lower:
            return SendMediaNotAllowedError(description)
        elif "send" in desc_lower and "poll" in desc_lower and "not" in desc_lower:
            return SendPollNotAllowedError(description)
        elif "change" in desc_lower and "info" in desc_lower and "not" in desc_lower:
            return ChangeInfoNotAllowedError(description)
        elif "invite" in desc_lower and "user" in desc_lower and "not" in desc_lower:
            return InviteUserNotAllowedError(description)
        elif "pin" in desc_lower and "message" in desc_lower and "not" in desc_lower:
            return PinMessageNotAllowedError(description)
        # Check for channel errors
        elif "channel" in desc_lower and "private" in desc_lower:
            return ChannelPrivateError(description)
        # Check for admin errors
        elif "admin" in desc_lower and "required" in desc_lower:
            return ChatAdministratorsRequiredError(description)
        else:
            return ForbiddenError(description)
    elif error_code == 404:
        # Check for specific not found errors
        if "message" in desc_lower and "not found" in desc_lower:
            return MessageNotFoundError(description)
        elif "chat" in desc_lower and "not found" in desc_lower:
            return ChatNotFoundError(description)
        elif "user" in desc_lower and "not found" in desc_lower:
            return UserNotFoundError(description)
        elif "channel" in desc_lower and "not" in desc_lower and "exist" in desc_lower:
            return ChannelNotCreatedError(description)
        else:
            return NotFoundError(description)
    elif error_code == 409:
        return ConflictError(description)
    elif error_code == 420:
        if "flood" in desc_lower or "peer" in desc_lower:
            return PeerFloodError(description)
        else:
            return FloodControlError(description)
    elif error_code == 429:
        retry_after = parameters.get("retry_after", 5)
        scope = parameters.get("scope", "global")
        if scope != "global" and scope != "chat":
            return RateLimitError(retry_after, description)
        return RateLimitScopeError(retry_after, scope, description)
    elif error_code == 500:
        return DatabaseError(description)
    elif error_code == 503:
        if "maintenance" in desc_lower:
            return ServerMaintenanceError(description)
        else:
            return PaymentProviderUnavailableError(description)
    else:
        return TelegramAPIError(description, error_code)
