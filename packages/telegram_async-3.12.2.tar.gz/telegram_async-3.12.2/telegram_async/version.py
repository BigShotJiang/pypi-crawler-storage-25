"""
Version information for telegram_async package.
"""

__version__ = '3.12.2'
