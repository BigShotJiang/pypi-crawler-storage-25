#!/usr/bin/env python3
"""
supero-server v1.0.0

Supero Platform — Reusable UI Server (CORS proxy + auth enrichment)

Replaces the ~240-line server.py that every generated app duplicates.
The LLM no longer generates server.py — it's a one-liner:

    from supero_server import serve
    serve(port=5648)

Or with customization:

    from supero_server import SuperoServer
    server = SuperoServer(port=5648, public_schemas=['unit', 'course'])
    server.serve()

Install: pip install supero-server
    Or:  copy this file to your project as supero_server.py

Features:
  - CORS proxy for /api/* and /ai/* to Supero backend
  - Login enrichment (merges access-policy into login response)
  - Signup handler (/api/signup) with policy fetch
  - Public schema proxy (/api/public/*) using API key auth
  - Service account init (API key from env or login)
  - Static file serving (index.html, app.js, config.js)
  - Graceful error handling with structured responses

Env vars read:
  SUPERO_URL          — Backend API (default: https://api.supero.dev)
  SUPERO_DOMAIN       — Domain name
  SUPERO_PROJECT      — Project name
  SUPERO_ADMIN_EMAIL  — Admin email (for service account login)
  SUPERO_PASSWORD     — Admin password
  SUPERO_API_KEY      — API key (if set, skips login)
  SUPERO_DEFAULT_TENANT — Default tenant (default: default-tenant)
  PUBLIC_SCHEMAS      — Comma-separated public schema names
  UI_PORT             — Server port
"""

import os
import sys
import json
import time
import http.server
import socketserver
import urllib.request
import urllib.error
import ssl

__version__ = '1.0.0'

# ─────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────

# Load .env from current dir or parent dir (ui/ → project root)
for _env_path in ['.env', '../.env', os.path.join(os.path.dirname(os.path.abspath('.')), '.env')]:
    if os.path.exists(_env_path):
        with open(_env_path) as _f:
            for _line in _f:
                _line = _line.strip()
                if _line and not _line.startswith('#') and '=' in _line:
                    _k, _, _v = _line.partition('=')
                    _k, _v = _k.strip(), _v.strip()
                    if not os.getenv(_k):  # don't override existing env
                        os.environ[_k] = _v
        break

API_URL = os.getenv('SUPERO_URL', 'https://api.supero.dev').rstrip('/')
BROWSER_UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# SSL verification — disable for dev (self-signed certs), enable for production
if os.getenv('SUPERO_VERIFY_SSL', '').lower() not in ('true', '1', 'yes'):
    ssl._create_default_https_context = ssl._create_unverified_context

# Module-level state
_SERVICE_API_KEY = ''
_PUBLIC_SCHEMAS = []


# ─────────────────────────────────────────────────────────
# Service Account
# ─────────────────────────────────────────────────────────

def init_service_account():
    """Initialize service account — gets API key from env or login."""
    global _SERVICE_API_KEY

    # Try env first
    _SERVICE_API_KEY = os.getenv('SUPERO_API_KEY', '')
    if _SERVICE_API_KEY:
        print(f'  ✅ API key from env: ...{_SERVICE_API_KEY[-4:]}')
        return True

    # Login to get API key
    domain = os.getenv('SUPERO_DOMAIN')
    email = os.getenv('SUPERO_ADMIN_EMAIL')
    password = os.getenv('SUPERO_PASSWORD')
    project = os.getenv('SUPERO_PROJECT', 'default-project')

    if not all([domain, email, password]):
        print('  ⚠️  No credentials — service account disabled')
        return False

    # ⚠️ Use domain_name (not domain) — platform field name
    payload = json.dumps({
        'domain_name': domain,
        'email': email,
        'password': password,
        'project': project,
    }).encode()

    req = urllib.request.Request(f'{API_URL}/api/v1/auth/login', data=payload, method='POST')
    req.add_header('Content-Type', 'application/json')
    req.add_header('User-Agent', BROWSER_UA)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            _SERVICE_API_KEY = result['auth']['api_key']
            print(f'  ✅ API key obtained: ...{_SERVICE_API_KEY[-4:]}')
            return True
    except Exception as e:
        print(f'  ❌ Service login failed: {e}')

    # Fallback — try without project (some platform versions)
    try:
        fallback = json.dumps({
            'domain_name': domain,
            'email': email,
            'password': password,
        }).encode()
        req2 = urllib.request.Request(f'{API_URL}/api/v1/auth/login', data=fallback, method='POST')
        req2.add_header('Content-Type', 'application/json')
        req2.add_header('User-Agent', BROWSER_UA)
        with urllib.request.urlopen(req2, timeout=30) as resp2:
            result2 = json.loads(resp2.read().decode())
            _SERVICE_API_KEY = result2['auth']['api_key']
            print(f'  ✅ API key obtained (fallback): ...{_SERVICE_API_KEY[-4:]}')
            return True
    except Exception as e2:
        print(f'  ❌ Service login fallback also failed: {e2}')
        return False


# ─────────────────────────────────────────────────────────
# Policy Fetch — used by login + signup enrichment
# ─────────────────────────────────────────────────────────

def _fetch_policy(token, domain=None, tenant=None):
    """Fetch access policy for the authenticated user. Returns None on failure."""
    domain = domain or os.getenv('SUPERO_DOMAIN', '')
    tenant = tenant or os.getenv('SUPERO_DEFAULT_TENANT', 'default-tenant')
    try:
        req = urllib.request.Request(
            f'{API_URL}/api/v1/crud/{domain}/access-policy/me', method='GET')
        req.add_header('Authorization', f'Bearer {token}')
        req.add_header('X-Domain', domain)
        req.add_header('X-Tenant', tenant)
        req.add_header('User-Agent', BROWSER_UA)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode()).get('policy')
    except Exception:
        return None  # Non-fatal — new user gets null policy, falls back to role check


# ─────────────────────────────────────────────────────────
# Request Handler
# ─────────────────────────────────────────────────────────

class SuperoRequestHandler(http.server.SimpleHTTPRequestHandler):
    """CORS-enabled handler with proxy, login enrichment, signup."""

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept, X-Domain, X-Tenant')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if self.path == '/health':
            self._send_json(200, {'status': 'ok', 'version': __version__})
        elif self.path.startswith('/api/public/'):
            self._handle_public_read()
        elif self.path.startswith('/api/') or self.path.startswith('/ai/'):
            self._proxy_request('GET')
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == '/api/signup':
            self._handle_signup()
        elif self.path == '/api/v1/auth/login':
            self._handle_login()
        elif self.path.startswith('/api/') or self.path.startswith('/ai/'):
            self._proxy_request('POST')
        else:
            self._send_json(404, {'error': 'Not found'})

    def do_PUT(self):
        if self.path.startswith('/api/'):
            self._proxy_request('PUT')
        else:
            self._send_json(404, {'error': 'Not found'})

    def do_DELETE(self):
        if self.path.startswith('/api/'):
            self._proxy_request('DELETE')
        else:
            self._send_json(404, {'error': 'Not found'})

    # ── Proxy ──

    def _proxy_request(self, method):
        """Proxy request to Supero backend, forwarding all headers."""
        url = f'{API_URL}{self.path}'
        cl = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(cl) if cl > 0 else None

        req = urllib.request.Request(url, data=body, method=method)
        # Forward relevant headers
        for h in ['Authorization', 'Content-Type', 'Accept', 'X-Domain', 'X-Tenant', 'X-API-Key']:
            val = self.headers.get(h)
            if val:
                req.add_header(h, val)
        req.add_header('User-Agent', BROWSER_UA)

        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = resp.read()
                content_type = resp.headers.get('Content-Type', 'application/json')

                # SSE passthrough
                if 'text/event-stream' in content_type:
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/event-stream')
                    self.send_header('Cache-Control', 'no-cache')
                    self.end_headers()
                    self.wfile.write(data)
                    return

                self.send_response(resp.status)
                self.send_header('Content-Type', content_type)
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._send_json(502, {'error': f'Proxy error: {str(e)}'})

    # ── Login Enrichment ──

    def _handle_login(self):
        """
        Proxy login to backend, then enrich response with access policy.
        One round trip from browser — server.py fetches policy server-side.
        """
        cl = int(self.headers.get('Content-Length', 0))
        body_bytes = self.rfile.read(cl)

        # Proxy login to backend
        req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
            data=body_bytes, method='POST')
        req.add_header('Content-Type', 'application/json')
        req.add_header('User-Agent', BROWSER_UA)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                login_result = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(data)
            return
        except Exception as e:
            return self._send_json(502, {'error': f'Login proxy failed: {e}'})

        # Enrich with access policy
        token = login_result.get('auth', {}).get('access_token')
        domain = login_result.get('context', {}).get('domain') or os.getenv('SUPERO_DOMAIN', '')
        tenant = login_result.get('context', {}).get('tenant', 'default-tenant')

        policy = _fetch_policy(token, domain, tenant) if token else None
        login_result['policy'] = policy

        self._send_json(200, login_result)

    # ── Signup ──

    def _handle_signup(self):
        """Create user account via API key, then auto-login with policy."""
        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})

        email = body.get('email', '').strip().lower()
        password = body.get('password', '')
        full_name = body.get('full_name', email.split('@')[0])
        signup_domain = body.get('domain') or os.getenv('SUPERO_DOMAIN')

        # Validation
        if not email or '@' not in email:
            return self._send_json(400, {'error': 'Valid email required'})
        if len(password) < 8:
            return self._send_json(400, {'error': 'Password must be 8+ characters'})
        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Signup unavailable — no service account'})

        domain = signup_domain
        project = os.getenv('SUPERO_PROJECT', 'default-project')
        tenant = os.getenv('SUPERO_DEFAULT_TENANT', 'default-tenant')

        # Create user account via CRUD
        user_data = {
            'name': email,
            'username': email.split('@')[0],
            'email': email,
            'full_name': full_name,
            'password': password,  # ⚠️ plaintext — platform hashes automatically
            'parent_type': 'tenant',
            'role': 'tenant_user',
            'enabled': True,
        }
        headers = {
            'X-API-Key': _SERVICE_API_KEY,
            'Content-Type': 'application/json',
            'User-Agent': BROWSER_UA,
        }
        create_url = f'{API_URL}/api/v1/crud/{domain}/user-account'

        try:
            req = urllib.request.Request(create_url,
                data=json.dumps(user_data).encode(), method='POST', headers=headers)
            with urllib.request.urlopen(req, timeout=30):
                pass
        except urllib.error.HTTPError as e:
            if e.code == 409:
                return self._send_json(409, {'error': 'Account exists. Please login.'})
            return self._send_json(e.code, {'error': 'Account creation failed'})

        # Auto-login after signup (omit tenant — let auth search)
        login_data = {
            'domain_name': domain,
            'email': email,
            'password': password,
            'project': project,
        }

        try:
            req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
                data=json.dumps(login_data).encode(), method='POST',
                headers={'Content-Type': 'application/json', 'User-Agent': BROWSER_UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
                token = result['auth']['access_token']
                policy = _fetch_policy(token, domain, tenant)

                return self._send_json(200, {
                    'auth': {'access_token': token},
                    'user': {'email': email, 'full_name': full_name, 'role': 'tenant_user'},
                    'context': {'domain': domain, 'project': project, 'tenant': tenant},
                    'policy': policy,
                })
        except Exception as e:
            return self._send_json(500, {'error': f'Login after signup failed: {e}'})

    # ── Public Schema Proxy ──

    def _handle_public_read(self):
        """Proxy public schema reads using API key (no user auth needed)."""
        # /api/public/unit → /api/v1/crud/{domain}/unit
        parts = self.path.split('/')
        if len(parts) < 4:
            return self._send_json(400, {'error': 'Invalid public endpoint'})

        schema = parts[3].split('?')[0]
        domain = os.getenv('SUPERO_DOMAIN', '')

        # Validate against allowed public schemas
        if schema not in _PUBLIC_SCHEMAS:
            return self._send_json(403, {'error': f"Schema '{schema}' is not public"})

        if not _SERVICE_API_KEY:
            return self._send_json(503, {'error': 'Public data unavailable'})

        url = f'{API_URL}/api/v1/crud/{domain}/{schema}'
        # Forward query params
        if '?' in self.path:
            url += '?' + self.path.split('?', 1)[1]

        req = urllib.request.Request(url, method='GET')
        req.add_header('X-API-Key', _SERVICE_API_KEY)
        req.add_header('Content-Type', 'application/json')
        req.add_header('User-Agent', BROWSER_UA)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = json.loads(resp.read().decode())
                # Normalize: CRUD returns {results:[...]}, frontend expects {data:[...]}
                records = raw.get('results') or raw.get('data') or []
                if not isinstance(records, list):
                    records = []
                # Return raw array — supero-ui.js LandingPage calls
                # items.slice() directly on the response body.
                self._send_json(200, records)
        except Exception:
            # Empty data, not error — landing page degrades gracefully
            self._send_json(200, [])

    # ── Helpers ──

    def _send_json(self, status, data):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        # Quieter logging — skip static file requests
        path = args[0] if args else ''
        if isinstance(path, str) and (path.endswith('.js') or path.endswith('.css') or path.endswith('.html')):
            return
        super().log_message(format, *args)


# ─────────────────────────────────────────────────────────
# Services — typed wrappers for all platform services
#
# Usage in setup.py:
#   from supero_server import Services
#   svc = Services(session, base_url, domain)
#   svc.email.send('user@app.com', 'Welcome!', '<p>Hi</p>')
#   svc.workflow.run('enrollment_confirmed', enrollment_uuid='...', amount=99)
#
# Maps friendly method calls to exact service_id + operation_id + field names.
# setup.py no longer needs to know the raw execute API.
# ─────────────────────────────────────────────────────────

class _ServiceGroup:
    """Base for a service group — handles the execute call."""
    def __init__(self, session, base, domain, service_id):
        self._s = session
        self._base = base
        self._domain = domain
        self._service_id = service_id

    def _exec(self, operation_id, input_data):
        return self._s.post(
            f'{self._base}/api/v1/services/execute',
            json={'service_id': self._service_id, 'operation_id': operation_id, 'input': input_data},
            timeout=30,
        )


class _EmailService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'email')
    def send(self, to, subject, body_html=None, body_text=None, from_name=None):
        inp = {'to_email': to, 'subject': subject}
        if body_html: inp['body_html'] = body_html
        elif body_text: inp['body_text'] = body_text
        if from_name: inp['from_name'] = from_name
        return self._exec('send_email', inp)


class _SmsService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'sms')
    def send(self, to, body):
        return self._exec('send_sms', {'to_number': to, 'body': body})


class _WhatsAppService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'whatsapp')
    def send(self, to, body):
        return self._exec('send_message', {'to_number': to, 'body': body})
    def send_template(self, to, template_name, template_params=None):
        return self._exec('send_template', {
            'to_number': to, 'template_name': template_name, 'template_params': template_params or {}})


class _PushService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'push_notification')
    def notify(self, device_token, title, body):
        return self._exec('send_notification', {'device_token': device_token, 'title': title, 'body': body})
    def broadcast(self, topic, title, body):
        return self._exec('send_topic_broadcast', {'topic': topic, 'title': title, 'body': body})


class _SlackService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'slack')
    def message(self, channel, text):
        return self._exec('send_message', {'channel': channel, 'text': text})
    def create_channel(self, name, topic=None):
        return self._exec('create_channel', {'channel_name': name, 'topic': topic or ''})


class _StripeService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'stripe_checkout')
    def checkout(self, amount, product_name, success_url):
        return self._exec('create_checkout_session', {
            'amount': amount, 'product_name': product_name, 'success_url': success_url})
    def payment_link(self, price_id):
        return self._exec('create_payment_link', {'price_id': price_id})


class _BillingService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'billing')
    def create_customer(self, email, company_name):
        return self._exec('create_customer', {'email': email, 'company_name': company_name})
    def create_invoice(self, customer_uuid, amount, currency='USD', due_date=None):
        inp = {'customer_uuid': customer_uuid, 'amount': amount, 'currency': currency}
        if due_date: inp['due_date'] = due_date
        return self._exec('create_invoice', inp)


class _SalesforceService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'salesforce')
    def create_lead(self, last_name, company, email):
        return self._exec('create_lead', {'last_name': last_name, 'company': company, 'email': email})
    def create_case(self, subject, priority='Medium', case_origin='Web'):
        return self._exec('create_case', {'subject': subject, 'priority': priority, 'case_origin': case_origin})


class _S3Service(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'amazon_s3')
    def upload_url(self, key, content_type='application/octet-stream'):
        return self._exec('generate_upload_url', {'key': key, 'content_type': content_type})


class _DriveService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'google_drive')
    def create_folder(self, name, description=''):
        return self._exec('create_folder', {'file_name': name, 'description': description})


class _CalendarService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'google_calendar')
    def create_event(self, title, start_time, end_time, add_meet=False):
        return self._exec('create_event', {
            'summary': title, 'start_time': start_time, 'end_time': end_time, 'add_meet': add_meet})


class _ServiceNowService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'servicenow')
    def create_incident(self, description, urgency='2', impact='2'):
        return self._exec('create_incident', {
            'short_description': description, 'urgency': urgency, 'impact': impact})


class _AIService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'ai')
    def complete(self, prompt, model='claude-sonnet', max_tokens=1000):
        return self._exec('simple_completion', {'prompt': prompt, 'model': model, 'max_tokens': max_tokens})
    def chat(self, messages, model='claude-sonnet'):
        return self._exec('chat_completion', {'messages': messages, 'model': model})


class _OtpService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'auth_otp')
    def send(self, channel, recipient, purpose='login'):
        return self._exec('send_otp', {'channel': channel, 'recipient': recipient, 'purpose': purpose})


class _WorkflowService(_ServiceGroup):
    def __init__(self, s, b, d): super().__init__(s, b, d, 'workflows')
    def run(self, workflow_id, **input_data):
        return self._exec('execute_workflow', {'workflow_id': workflow_id, **input_data})
    def validate(self, workflow_id):
        return self._exec('validate_workflow', {'workflow_id': workflow_id})


class Services:
    """
    Typed service client for all platform services.

    Usage:
        svc = Services(session, base_url, domain)
        svc.email.send('user@example.com', 'Welcome!', '<p>Hello</p>')
        svc.stripe.checkout(amount=99, product_name='Course', success_url='/success')
        svc.workflow.run('enrollment_confirmed', enrollment_uuid='abc', amount=99)
    """
    def __init__(self, session, base_url, domain):
        args = (session, base_url, domain)
        self.email = _EmailService(*args)
        self.sms = _SmsService(*args)
        self.whatsapp = _WhatsAppService(*args)
        self.push = _PushService(*args)
        self.slack = _SlackService(*args)
        self.stripe = _StripeService(*args)
        self.billing = _BillingService(*args)
        self.salesforce = _SalesforceService(*args)
        self.s3 = _S3Service(*args)
        self.drive = _DriveService(*args)
        self.calendar = _CalendarService(*args)
        self.servicenow = _ServiceNowService(*args)
        self.ai = _AIService(*args)
        self.otp = _OtpService(*args)
        self.workflow = _WorkflowService(*args)


# ─────────────────────────────────────────────────────────
# Services Client — typed wrappers for all 26 platform services
#
# Usage in setup.py:
#   from supero_server import Services
#   svc = Services(session, base_url, domain)
#   svc.email.send(to='user@app.com', subject='Welcome', body_html='<p>Hi</p>')
#   svc.workflow.run('enrollment_confirmed', enrollment_uuid='...', amount=99)
# ─────────────────────────────────────────────────────────

class _ServiceGroup:
    """Base for a service group with execute helper."""
    def __init__(self, session, base, domain, service_id):
        self._s = session
        self._base = base
        self._domain = domain
        self._service_id = service_id

    def _exec(self, operation_id, input_data):
        return self._s.post(f'{self._base}/api/v1/services/execute',
            json={'service_id': self._service_id, 'operation_id': operation_id, 'input': input_data},
            timeout=60)


class _EmailSvc(_ServiceGroup):
    def send(self, to, subject, body_html=None, body_text=None, from_name=None):
        inp = {'to_email': to, 'subject': subject}
        if body_html: inp['body_html'] = body_html
        if body_text: inp['body_text'] = body_text
        if from_name: inp['from_name'] = from_name
        return self._exec('send_email', inp)

class _SmsSvc(_ServiceGroup):
    def send(self, to, body):
        return self._exec('send_sms', {'to_number': to, 'body': body})

class _WhatsappSvc(_ServiceGroup):
    def send(self, to, body):
        return self._exec('send_message', {'to_number': to, 'body': body})
    def send_template(self, to, template_name, template_params=None):
        return self._exec('send_template', {'to_number': to, 'template_name': template_name, 'template_params': template_params or {}})

class _PushSvc(_ServiceGroup):
    def notify(self, token, title, body):
        return self._exec('send_notification', {'device_token': token, 'title': title, 'body': body})
    def broadcast(self, topic, title, body):
        return self._exec('send_topic_broadcast', {'topic': topic, 'title': title, 'body': body})

class _SlackSvc(_ServiceGroup):
    def message(self, channel, text):
        return self._exec('send_message', {'channel': channel, 'text': text})
    def create_channel(self, name, topic=''):
        return self._exec('create_channel', {'channel_name': name, 'topic': topic})

class _StripeSvc(_ServiceGroup):
    def checkout(self, amount, product, success_url):
        return self._exec('create_checkout_session', {'amount': amount, 'product_name': product, 'success_url': success_url})
    def payment_link(self, price_id):
        return self._exec('create_payment_link', {'price_id': price_id})

class _BillingSvc(_ServiceGroup):
    def create_customer(self, email, company):
        return self._exec('create_customer', {'email': email, 'company_name': company})
    def create_invoice(self, customer_uuid, amount, currency='USD', due_date=None):
        return self._exec('create_invoice', {'customer_uuid': customer_uuid, 'amount': amount, 'currency': currency, 'due_date': due_date})

class _SalesforceSvc(_ServiceGroup):
    def create_lead(self, last_name, company, email):
        return self._exec('create_lead', {'last_name': last_name, 'company': company, 'email': email})
    def create_case(self, subject, priority='Medium', origin='Web'):
        return self._exec('create_case', {'subject': subject, 'priority': priority, 'case_origin': origin})

class _AiSvc(_ServiceGroup):
    def complete(self, prompt, model='claude-sonnet', max_tokens=1000):
        return self._exec('simple_completion', {'prompt': prompt, 'model': model, 'max_tokens': max_tokens})
    def chat(self, messages, model='claude-sonnet'):
        return self._exec('chat_completion', {'messages': messages, 'model': model})

class _WorkflowSvc(_ServiceGroup):
    def run(self, workflow_id, **input_data):
        return self._exec('execute_workflow', {'workflow_id': workflow_id, **input_data})
    def validate(self, workflow_id):
        return self._exec('validate_workflow', {'workflow_id': workflow_id})

class _S3Svc(_ServiceGroup):
    def upload_url(self, key, content_type):
        return self._exec('generate_upload_url', {'key': key, 'content_type': content_type})

class _CalendarSvc(_ServiceGroup):
    def create_event(self, title, start, end, add_meet=False):
        return self._exec('create_event', {'summary': title, 'start_time': start, 'end_time': end, 'add_meet': add_meet})

class _OtpSvc(_ServiceGroup):
    def send(self, to, channel='sms', purpose='login'):
        return self._exec('send_otp', {'channel': channel, 'recipient': to, 'purpose': purpose})

class _SearchSvc(_ServiceGroup):
    def web(self, query, num=5):
        return self._exec('web_search', {'query': query, 'num': num})


class _QuickBooksSvc(_ServiceGroup):
    def create_customer(self, display_name, email='', phone='', company=''):
        return self._exec('create_customer', {'display_name': display_name, 'email': email, 'phone': phone, 'company': company})
    def create_invoice(self, customer_ref, line_items=None, due_date='', currency='USD', notes=''):
        return self._exec('create_invoice', {'customer_ref': customer_ref, 'line_items': line_items or [], 'due_date': due_date, 'currency': currency, 'notes': notes})
    def record_payment(self, customer_ref, amount, payment_method='', invoice_ref=''):
        return self._exec('record_payment', {'customer_ref': customer_ref, 'amount': amount, 'payment_method': payment_method, 'invoice_ref': invoice_ref})
    def create_expense(self, account_ref, amount, description='', vendor=''):
        return self._exec('create_expense', {'account_ref': account_ref, 'amount': amount, 'description': description, 'vendor': vendor})
    def create_bill(self, vendor_ref, line_items=None, due_date=''):
        return self._exec('create_bill', {'vendor_ref': vendor_ref, 'line_items': line_items or [], 'due_date': due_date})
    def create_vendor(self, display_name, email='', phone=''):
        return self._exec('create_vendor', {'display_name': display_name, 'email': email, 'phone': phone})
    def sync_invoice(self, invoice_uuid):
        return self._exec('sync_invoice', {'invoice_uuid': invoice_uuid})
    def get_report(self, report_type, start_date='', end_date=''):
        return self._exec('get_report', {'report_type': report_type, 'start_date': start_date, 'end_date': end_date})


class _McpServerSvc(_ServiceGroup):
    def register_tools(self):
        return self._exec('register_tools', {})
    def handle_tool_call(self, tool_name, arguments=None):
        return self._exec('handle_tool_call', {'tool_name': tool_name, 'arguments': arguments or {}})
    def list_resources(self):
        return self._exec('list_resources', {})
    def get_endpoint(self):
        return self._exec('get_endpoint', {})


class _McpClientSvc(_ServiceGroup):
    def call_tool(self, server_url='', tool_name='', arguments=None, server_name=''):
        return self._exec('call_tool', {'server_url': server_url, 'server_name': server_name, 'tool_name': tool_name, 'arguments': arguments or {}})
    def list_tools(self, server_url='', server_name=''):
        return self._exec('list_tools', {'server_url': server_url, 'server_name': server_name})
    def connect_server(self, server_url, name='', auth_type='none', auth_token=''):
        return self._exec('connect_server', {'server_url': server_url, 'name': name, 'auth_type': auth_type, 'auth_token': auth_token})


class _GoogleAuthSvc(_ServiceGroup):
    def login(self, auth_code, redirect_uri=''):
        return self._exec('google_login', {'auth_code': auth_code, 'redirect_uri': redirect_uri})
    def signup(self, auth_code, redirect_uri=''):
        return self._exec('google_signup', {'auth_code': auth_code, 'redirect_uri': redirect_uri, 'signup': True})
    def link_account(self, auth_code, redirect_uri=''):
        return self._exec('link_account', {'auth_code': auth_code, 'redirect_uri': redirect_uri, 'link_account': True})
    def get_config(self):
        return self._exec('get_google_config', {})


class _GoogleAdsSvc(_ServiceGroup):
    def create_campaign(self, campaign_name, budget_amount=50, channel_type='SEARCH', bidding_strategy='MAXIMIZE_CLICKS'):
        return self._exec('create_campaign', {'campaign_name': campaign_name, 'budget_amount': budget_amount, 'channel_type': channel_type, 'bidding_strategy': bidding_strategy})
    def create_ad_group(self, campaign_id, ad_group_name, cpc_bid=1.0):
        return self._exec('create_ad_group', {'campaign_id': campaign_id, 'ad_group_name': ad_group_name, 'cpc_bid': cpc_bid})
    def create_ad(self, ad_group_id, headlines, descriptions=None, final_url=''):
        import json as _json
        return self._exec('create_ad', {'ad_group_id': ad_group_id, 'headlines': _json.dumps(headlines), 'descriptions': _json.dumps(descriptions or []), 'final_url': final_url})
    def add_keywords(self, ad_group_id, keywords, match_type='BROAD'):
        import json as _json
        return self._exec('add_keywords', {'ad_group_id': ad_group_id, 'keywords': _json.dumps(keywords), 'match_type': match_type})
    def get_performance(self, query=''):
        return self._exec('get_performance', {'query': query} if query else {})
    def pause_campaign(self, campaign_id):
        return self._exec('pause_campaign', {'campaign_id': campaign_id, 'new_status': 'PAUSED'})
    def enable_campaign(self, campaign_id):
        return self._exec('enable_campaign', {'campaign_id': campaign_id, 'new_status': 'ENABLED'})
    def list_campaigns(self):
        return self._exec('list_campaigns', {'list_campaigns': True})


class _GoogleReviewsSvc(_ServiceGroup):
    def list_reviews(self, location_id='', page_size=50, page_token=''):
        return self._exec('list_reviews', {'location_id': location_id, 'page_size': page_size, 'page_token': page_token})
    def get_review(self, review_id, location_id=''):
        return self._exec('get_review', {'review_id': review_id, 'location_id': location_id})
    def reply_review(self, review_id, reply_comment, location_id=''):
        return self._exec('reply_review', {'review_id': review_id, 'reply_comment': reply_comment, 'location_id': location_id})
    def delete_reply(self, review_id, location_id=''):
        return self._exec('delete_reply', {'review_id': review_id, 'delete_reply': True, 'location_id': location_id})
    def get_rating(self, location_id=''):
        return self._exec('get_rating', {'get_rating': True, 'location_id': location_id})
    def list_locations(self):
        return self._exec('list_locations', {'list_locations': True})


class Services:
    """All 26 platform services with typed methods.

    Usage:
        svc = Services(session, 'https://api.supero.dev', 'my-domain')
        svc.email.send(to='user@app.com', subject='Hi', body_html='<p>Hello</p>')
        svc.slack.message(channel='#ops', text='Alert!')
        svc.workflow.run('order_confirmed', order_uuid='abc-123', customer_email='x@y.com')
    """
    def __init__(self, session, base_url, domain):
        self.email     = _EmailSvc(session, base_url, domain, 'email')
        self.email_smtp= _EmailSvc(session, base_url, domain, 'email_smtp')
        self.sms       = _SmsSvc(session, base_url, domain, 'sms')
        self.whatsapp  = _WhatsappSvc(session, base_url, domain, 'whatsapp')
        self.push      = _PushSvc(session, base_url, domain, 'push_notification')
        self.slack     = _SlackSvc(session, base_url, domain, 'slack')
        self.stripe    = _StripeSvc(session, base_url, domain, 'stripe_checkout')
        self.billing   = _BillingSvc(session, base_url, domain, 'billing')
        self.salesforce= _SalesforceSvc(session, base_url, domain, 'salesforce')
        self.ai        = _AiSvc(session, base_url, domain, 'ai')
        self.workflow  = _WorkflowSvc(session, base_url, domain, 'workflows')
        self.s3        = _S3Svc(session, base_url, domain, 'amazon_s3')
        self.drive     = _ServiceGroup(session, base_url, domain, 'google_drive')
        self.calendar  = _CalendarSvc(session, base_url, domain, 'google_calendar')
        self.servicenow= _ServiceGroup(session, base_url, domain, 'servicenow')
        self.otp       = _OtpSvc(session, base_url, domain, 'auth_otp')
        self.search    = _SearchSvc(session, base_url, domain, 'google_search')
        # Social / DevOps — use _exec directly
        self.github    = _ServiceGroup(session, base_url, domain, 'github')
        self.bitbucket = _ServiceGroup(session, base_url, domain, 'bitbucket')
        self.instagram = _ServiceGroup(session, base_url, domain, 'instagram')
        self.twitter   = _ServiceGroup(session, base_url, domain, 'x_social')
        self.linkedin  = _ServiceGroup(session, base_url, domain, 'linkedin')
        self.youtube   = _ServiceGroup(session, base_url, domain, 'youtube')
        self.paypal    = _ServiceGroup(session, base_url, domain, 'billing_paypal')
        self.razorpay  = _ServiceGroup(session, base_url, domain, 'billing_razorpay')
        self.plaid     = _ServiceGroup(session, base_url, domain, 'plaid')
        # QuickBooks
        self.quickbooks = _QuickBooksSvc(session, base_url, domain, 'quickbooks')
        # MCP
        self.mcp_server = _McpServerSvc(session, base_url, domain, 'mcp_server')
        self.mcp_client = _McpClientSvc(session, base_url, domain, 'mcp_client')
        # Google OAuth
        self.google_auth = _GoogleAuthSvc(session, base_url, domain, 'google_oauth')
        # Google Ads
        self.google_ads = _GoogleAdsSvc(session, base_url, domain, 'google_ads')
        # Google Reviews
        self.google_reviews = _GoogleReviewsSvc(session, base_url, domain, 'google_reviews')


# ─────────────────────────────────────────────────────────
# Server Entry Point
# ─────────────────────────────────────────────────────────

class SuperoServer:
    """Configurable Supero UI server."""

    def __init__(self, port=None, public_schemas=None, handler_class=None):
        self.port = port or int(os.getenv('UI_PORT', '5648'))
        self.handler_class = handler_class or SuperoRequestHandler

        global _PUBLIC_SCHEMAS
        if public_schemas is not None:
            _PUBLIC_SCHEMAS = public_schemas
        else:
            _PUBLIC_SCHEMAS = [s.strip() for s in os.getenv('PUBLIC_SCHEMAS', '').split(',') if s.strip()]

    def serve(self):
        """Start the server. Blocks until killed."""
        print(f'  🌐 Starting server on port {self.port}...')
        init_service_account()

        if _PUBLIC_SCHEMAS:
            print(f'  📋 Public schemas: {", ".join(_PUBLIC_SCHEMAS)}')

        # ThreadingTCPServer so slow proxy requests don't block everything
        # allow_reuse_address must be set BEFORE __init__ calls server_bind()
        class _Server(socketserver.ThreadingTCPServer):
            allow_reuse_address = True
            daemon_threads = True

        with _Server(('', self.port), self.handler_class) as httpd:
            print(f'  ✅ Serving on http://0.0.0.0:{self.port}')
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print('\n  Server stopped.')


def serve(port=None, public_schemas=None):
    """Quick-start: one-line server."""
    SuperoServer(port=port, public_schemas=public_schemas).serve()


# ─────────────────────────────────────────────────────────
# Standalone execution
# ─────────────────────────────────────────────────────────

if __name__ == '__main__':
    serve()
