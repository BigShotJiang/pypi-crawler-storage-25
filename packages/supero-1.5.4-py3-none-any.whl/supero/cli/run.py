"""
supero.cli.run — Main orchestrator for Supero App Runner

Entry point: python3 -m supero.cli

Lean orchestrator — 5 steps:
  1. Validate project files exist (schemas.py, config.py, setup.py)
  2. Interactive .env setup (if not configured)
  3. CDN downloads (supero-ui.js, index.html, server.py, config.js)
  4. Run setup.py (handles ALL platform interaction via AppSetup)
  5. Start server (or mobile, or docker)

The CLI does NOT duplicate platform logic — setup.py's AppSetup.run()
handles domain bootstrap, schema upload, services, workflows, policies,
and seed data. The CLI only ensures .env + infrastructure files exist.
"""

import os
import sys
import time
import socket
import subprocess
import argparse

from supero.cli.env_manager import EnvManager
from supero.cli.interactive import interactive_setup
from supero.cli.cdn_downloader import CdnDownloader

__version__ = "1.0.0"

# ── ANSI colors for terminal output ──
class _C:
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

def _ok(msg):     print(f"  {_C.GREEN}✓{_C.RESET} {msg}")
def _warn(msg):   print(f"  {_C.YELLOW}⚠{_C.RESET} {msg}")
def _fail(msg):   print(f"  {_C.RED}✗{_C.RESET} {msg}")
def _info(msg):   print(f"  {_C.DIM}{msg}{_C.RESET}")
def _header(msg): print(f"\n{_C.BOLD}── {msg} ──{_C.RESET}\n")


def _step(num, title, desc):
    """Print a step header with description."""
    print(f"\n{_C.BOLD}── Step {num} · {title} ──{_C.RESET}")
    print(f"  {_C.DIM}{desc}{_C.RESET}\n")

def _prompt_launch_mode() -> str:
    """
    Ask user how they want to run: standalone, docker, or setup-only.
    Returns 'standalone', 'docker', or 'setup'.
    """
    print()
    print(f"  How would you like to run this app?")
    print()
    print(f"  {_C.BOLD}1){_C.RESET} {_C.GREEN}Standalone{_C.RESET}    Run directly on this machine")
    print(f"     {_C.DIM}Best for: development, quick testing, single-server deploy{_C.RESET}")
    print()
    print(f"  {_C.BOLD}2){_C.RESET} {_C.CYAN}Docker{_C.RESET}        Build and run in a container")
    print(f"     {_C.DIM}Best for: production, reproducible deploys, isolation{_C.RESET}")
    print()
    print(f"  {_C.BOLD}3){_C.RESET} {_C.DIM}Setup only{_C.RESET}    Configure without starting server")
    print(f"     {_C.DIM}Best for: CI/CD, preparing deploy, testing config{_C.RESET}")
    print()
    try:
        choice = input("  Choose [1/2/3] (default: 1): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        choice = "1"
    if choice == "2":
        print(f"\n  {_C.CYAN}→ Docker mode{_C.RESET}\n")
        return "docker"
    elif choice == "3":
        print(f"\n  {_C.DIM}→ Setup only{_C.RESET}\n")
        return "setup"
    else:
        print(f"\n  {_C.GREEN}→ Standalone mode{_C.RESET}\n")
        return "standalone"


def parse_args():
    parser = argparse.ArgumentParser(
        prog="supero-run",
        description="Supero App Runner — interactive setup + server launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ./run.sh                    Interactive setup + start server
  ./run.sh --setup-only       Run setup without starting server
  ./run.sh --server-only      Start server (skip setup)
  ./run.sh --mobile           Also set up mobile app
  ./run.sh --docker           Build and run with Docker Compose
  ./run.sh --no-interactive   Use .env values without prompting
  ./run.sh --reset            Re-upload schemas and re-run setup
        """
    )
    parser.add_argument("--setup-only", action="store_true",
                        help="Run setup without starting server")
    parser.add_argument("--server-only", action="store_true",
                        help="Start server without running setup")
    parser.add_argument("--mobile", action="store_true",
                        help="Also set up the mobile app (Expo)")
    parser.add_argument("--docker", action="store_true",
                        help="Build and run with Docker Compose")
    parser.add_argument("--port", type=int,
                        help="Override server port (default: from .env or 5648)")
    parser.add_argument("--no-interactive", action="store_true",
                        help="Use .env values without prompting")
    parser.add_argument("--reset", action="store_true",
                        help="Re-upload schemas and re-run setup")
    parser.add_argument("--verbose", action="store_true",
                        help="Show detailed logs from setup and server")
    parser.add_argument("--no-seed", action="store_true",
                        help="Skip seeding test data (seed runs by default)")
    parser.add_argument("--seed", action="store_true", default=True,
                        help=argparse.SUPPRESS)  # kept for backwards compat
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__version__}")
    return parser.parse_args()


def validate_project(path: str) -> dict:
    """
    Validate that required project files exist.
    Returns dict with has_web and has_mobile flags.
    """
    required = [
        ("schemas.py", "Schema definitions"),
        ("config.py",  "App configuration"),
        ("setup.py",   "Setup script"),
    ]

    missing = []
    for filename, desc in required:
        filepath = os.path.join(path, filename)
        if os.path.exists(filepath):
            _ok(f"Found {filename}")
        else:
            _fail(f"Missing {filename} ({desc})")
            missing.append(filename)

    # Check for ui/app.js in both app_dir and project root (CWD)
    has_web = (
        os.path.exists(os.path.join(path, "ui", "app.js"))
        or os.path.exists(os.path.join(os.getcwd(), "ui", "app.js"))
    )

    # Mobile dir can be inside the app package OR at the project root
    has_mobile = (
        os.path.exists(os.path.join(path, "mobile", "src", "appConfig.ts"))
        or os.path.exists(os.path.join(os.getcwd(), "mobile", "src", "appConfig.ts"))
    )

    if has_web:
        _ok("Found ui/app.js (Web UI)")
    if has_mobile:
        _ok("Found mobile/src/appConfig.ts (Mobile)")

    if not has_web and not has_mobile:
        _warn("No ui/app.js or mobile/src/appConfig.ts found")

    if missing:
        print()
        _fail(f"Missing required files: {', '.join(missing)}")
        print(f"  {_C.DIM}Make sure you're in the app root directory.{_C.RESET}")
        sys.exit(1)

    return {"has_web": has_web, "has_mobile": has_mobile}


def _find_app_dir() -> str:
    """
    Find the app package directory (contains setup.py at top level
    and ui/ subdirectory).

    Generated apps have this layout:
      project_root/
      ├── run.sh
      ├── package_name/
      │   ├── setup.py
      │   ├── config.py
      │   ├── schemas.py
      │   └── ui/
      │       └── app.js
      └── ...

    OR flat layout (setup.py at CWD level):
      project_root/
      ├── run.sh
      ├── setup.py
      ├── config.py
      ├── schemas.py
      └── ui/
          └── app.js

    Returns the directory containing setup.py.
    """
    cwd = os.getcwd()

    # Flat layout: setup.py in CWD
    if os.path.exists(os.path.join(cwd, "setup.py")):
        return cwd

    # Package layout: look for a subdirectory with setup.py
    for entry in os.listdir(cwd):
        candidate = os.path.join(cwd, entry)
        if (os.path.isdir(candidate)
                and not entry.startswith(".")
                and entry not in ("mobile", "e2e-tests", ".venv", "__pycache__")
                and os.path.exists(os.path.join(candidate, "setup.py"))):
            return candidate

    # Fallback: CWD
    return cwd


def _get_lan_ip() -> str:
    """Get LAN IP address for the network URL display."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "0.0.0.0"


def _read_app_meta(app_dir: str) -> dict:
    """
    Extract app metadata from config.py.

    Looks for app_name, app_emoji, app_description attributes
    in the config class or as module-level variables.

    Returns dict with keys: name, emoji, description (all strings, may be empty).
    """
    config_path = os.path.join(app_dir, "config.py")
    result = {"name": "", "emoji": "", "description": "", "public_schemas": []}
    if not os.path.exists(config_path):
        return result

    # Map config.py attribute names to our result keys
    # Use specific prefixed names to avoid matching unrelated attributes
    # like workflow descriptions or policy descriptions
    attr_map = {
        "app_name": "name",
        "display_name": "name",
        "app_emoji": "emoji",
        "app_description": "description",
    }

    try:
        import re as _re
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                for attr, key in attr_map.items():
                    if line.startswith(f"{attr}") and "=" in line:
                        val = line.split("=", 1)[1].strip().strip("'\"")
                        if val and not result[key]:  # first match wins
                            result[key] = val
                # Parse: public_schemas = ["trip", "listing"]
                if line.startswith("public_schemas") and "=" in line:
                    val_part = line.split("=", 1)[1].strip()
                    schemas = _re.findall(r"""["\']([\w-]+)["']""", val_part)
                    if schemas:
                        result["public_schemas"] = schemas
    except Exception:
        pass
    return result




def _ensure_docker_files(app_dir: str, env: 'EnvManager', app_name: str = "supero-app"):
    """
    Generate Dockerfile and docker-compose.yml if they don't exist.
    These are minimal production-ready templates.
    """
    project_root = os.getcwd()

    # ── Dockerfile ──
    dockerfile_path = os.path.join(project_root, "Dockerfile")
    if not os.path.exists(dockerfile_path):
        # Detect the package directory name
        pkg_name = os.path.basename(app_dir) if app_dir != project_root else "."

        dockerfile = f"""# Auto-generated by Supero CLI
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt* ./
RUN pip install --no-cache-dir supero>=1.2.0 requests>=2.28.0 2>/dev/null || true
RUN test -f requirements.txt && pip install --no-cache-dir -r requirements.txt || true

# Copy app files
COPY . .

# Expose port
ENV PORT=5648
EXPOSE 5648

# Run: setup + server
CMD ["python3", "-m", "supero.cli", "--no-interactive"]
"""
        with open(dockerfile_path, "w") as f:
            f.write(dockerfile)
        _ok("Generated Dockerfile")
    else:
        _ok("Found existing Dockerfile")

    # ── docker-compose.yml ──
    compose_path = os.path.join(project_root, "docker-compose.yml")
    if not os.path.exists(compose_path):
        port = env.get("PORT", env.get("UI_PORT", "5648"))
        slug = app_name.lower().replace(" ", "-").replace("_", "-")

        compose = f"""# Auto-generated by Supero CLI
version: '3.8'

services:
  {slug}:
    build: .
    ports:
      - "{port}:{port}"
    env_file:
      - .env
    environment:
      - PORT={port}
      - UI_PORT={port}
    restart: unless-stopped
"""
        with open(compose_path, "w") as f:
            f.write(compose)
        _ok("Generated docker-compose.yml")
    else:
        _ok("Found existing docker-compose.yml")

    return dockerfile_path, compose_path

def main():
    args = parse_args()

    # ── Banner ──
    print()
    print(f"{_C.BOLD}🚀 Supero App Runner v{__version__}{_C.RESET}")
    print("━" * 40)
    print()

    # ── Step 1: Find app directory and validate files ──
    _header("Step 1 · Checking project files")
    app_dir = _find_app_dir()

    if app_dir != os.getcwd():
        _info(f"App directory: {os.path.basename(app_dir)}/")

    project = validate_project(app_dir)

    # Resolve ui_dir — may be in app_dir or project root
    if os.path.exists(os.path.join(app_dir, "ui", "app.js")):
        ui_base = app_dir
    elif os.path.exists(os.path.join(os.getcwd(), "ui", "app.js")):
        ui_base = os.getcwd()
    else:
        ui_base = app_dir

    # ── Step 2: Environment setup ──
    # Resolve .env relative to project dir (where setup.py lives), not cwd
    _project_dir = os.path.dirname(os.path.abspath(sys.argv[0])) or os.getcwd()
    env = EnvManager(env_path=os.path.join(_project_dir, ".env"))

    if not args.server_only:
        if args.reset:
            _header("Step 2 · Resetting configuration")
            env.clear()
            _ok("Configuration cleared")
            print()

        if not env.is_configured() or args.reset:
            _header("Step 2 · Domain configuration")
            if args.no_interactive:
                _fail(".env not configured. Run without --no-interactive first.")
                sys.exit(1)
            interactive_setup(env)
        else:
            _header("Step 2 · Using saved configuration")
            _ok(f"Domain:  {env.get('SUPERO_DOMAIN')}")
            _ok(f"Project: {env.get('SUPERO_PROJECT', 'default-project')}")
            _ok(f"Email:   {env.get('SUPERO_ADMIN_EMAIL')}")
    else:
        if not env.is_configured():
            _fail("No .env configuration found. Run without --server-only first.")
            sys.exit(1)
        _header("Step 2 · Skipped (--server-only)")
        _ok(f"Domain: {env.get('SUPERO_DOMAIN')}")

    # ── Derive SDK env vars from SUPERO_URL ──
    env.derive_sdk_vars()

    # ── Step 3: CDN downloads + generate infrastructure files ──
    if project["has_web"]:
        _header("Step 3 · Preparing web UI files")
        ui_dir = os.path.join(ui_base, "ui")

        # Read app metadata from config.py (name, emoji, description)
        meta = _read_app_meta(app_dir)
        app_name = env.get("APP_NAME") or meta["name"] or env.get(
            "SUPERO_DOMAIN", "Supero App"
        ).replace("-", " ").title()
        app_emoji = env.get("APP_EMOJI") or meta["emoji"]
        app_description = env.get("APP_DESCRIPTION") or meta["description"]

        cdn = CdnDownloader(verbose=args.verbose)
        cdn.ensure_files(ui_dir, app_name=app_name)
        env.generate_config_js(
            ui_dir,
            app_name=app_name,
            app_emoji=app_emoji,
            app_description=app_description,
        )
        # Write public_schemas from config.py into .env so SuperoServer
        # can populate _PUBLIC_SCHEMAS for /api/public/* requests.
        # Without this, every landing page data request returns 403.
        _public = meta.get("public_schemas", [])
        if _public:
            _schemas_csv = ",".join(_public)
            env.set("PUBLIC_SCHEMAS", _schemas_csv)
            _ok(f"Public schemas: {_schemas_csv}")
    else:
        _header("Step 3 · Skipped (no web UI)")
        _info("No ui/app.js found, skipping CDN downloads")

    # ── Step 4: Run setup.py ──
    if not args.server_only:
        _header("Step 4 · Running platform setup")
        _info("This registers the domain, uploads schemas, configures services...")
        print()

        setup_cmd = [sys.executable, "setup.py"]

        # Credentials are passed via env vars (already set by env.set() + derive_sdk_vars())
        # NOT as CLI args — setup.py may not accept --domain/--admin-email/--password.
        # config.py reads from os.getenv("SUPERO_DOMAIN"), etc.

        # Only pass --no-seed if user explicitly opted out
        if args.no_seed:
            setup_cmd.append("--no-seed")

        if args.verbose:
            result = subprocess.run(setup_cmd, cwd=app_dir)
        else:
            result = subprocess.run(
                setup_cmd, cwd=app_dir,
                capture_output=True, text=True
            )
            # Show summary lines from setup output
            if result.stdout:
                for line in result.stdout.splitlines():
                    # Surface meaningful status lines
                    if any(k in line for k in ("✅", "✓", "⚠", "❌", "Error",
                                                "created", "skipped", "failed",
                                                "uploaded", "registered", "logged")):
                        print(f"  {line.strip()}")

        if result.returncode != 0:
            print()
            _fail("Setup failed")
            if not args.verbose:
                if result.stderr:
                    print(f"\n{_C.DIM}Error output:{_C.RESET}")
                    # Show last 20 lines of stderr
                    for line in result.stderr.strip().splitlines()[-20:]:
                        print(f"  {line}")
                print()
                _info("Tip: run with --verbose for full output")
                _info("Tip: run with --reset to clear config and retry")
            sys.exit(1)

        print()
        _ok("Platform setup complete")
    else:
        _header("Step 4 · Skipped (--server-only)")

    # ── Reload .env after setup (bootstrap may have written api_key) ──
    env.reload()

    # Sync ALL .env values into os.environ so the server subprocess
    # inherits SUPERO_API_KEY, SUPERO_DOMAIN, SUPERO_ADMIN_EMAIL etc.
    # env.reload() only updates self.values — not os.environ.
    # Without this, init_service_account() finds no credentials -> 503.
    for _k, _v in env.values.items():
        if _k and _v and _k not in os.environ:
            os.environ[_k] = _v

    # ── Regenerate config.js after setup (may have new api_key/tenant) ──
    if project["has_web"]:
        ui_dir = os.path.join(ui_base, "ui")
        meta = _read_app_meta(app_dir)
        env.generate_config_js(
            ui_dir,
            app_name=meta["name"],
            app_emoji=meta["emoji"],
            app_description=meta["description"],
        )
        # Sync PUBLIC_SCHEMAS into os.environ so server subprocess inherits it.
        # env.reload() repopulates self.values but subprocess reads os.environ.
        _ps = env.get("PUBLIC_SCHEMAS", "")
        if _ps:
            os.environ["PUBLIC_SCHEMAS"] = _ps
        # Sync PUBLIC_SCHEMAS into os.environ so server subprocess inherits it.
        # env.reload() repopulates self.values but subprocess reads os.environ.
        _ps = env.get("PUBLIC_SCHEMAS", "")
        if _ps:
            os.environ["PUBLIC_SCHEMAS"] = _ps

    # ── Step 5: Start server / mobile / docker ──
    if not args.setup_only:
        port = args.port or int(env.get("PORT", env.get("UI_PORT", "5648")))

        # If no explicit mode flag, ask the user
        if not args.docker and not args.server_only and not args.no_interactive:
            launch_mode = _prompt_launch_mode()
            if launch_mode == "docker":
                args.docker = True
            elif launch_mode == "setup":
                args.setup_only = True
                # Jump to setup-only handling
                _ok("Setup complete! Run ./run.sh to start the server.")
                sys.exit(0)

        if args.docker:
            _step(5, "Starting with Docker",
                  "Building Docker image and launching container...")

            # Generate Dockerfile + docker-compose.yml if missing
            meta = _read_app_meta(app_dir)
            _ensure_docker_files(app_dir, env, app_name=meta.get("name", "supero-app"))

            # Ensure .env exists for docker-compose env_file
            if not os.path.exists(os.path.join(os.getcwd(), ".env")):
                env.save()
                _ok("Created .env for Docker")

            print()
            _info("Building and starting container...")
            _info("This may take a few minutes on first build.")
            print()

            try:
                result = subprocess.run(
                    ["docker", "compose", "up", "--build", "-d"],
                    capture_output=not args.verbose, text=True
                )
                if result.returncode == 0:
                    print()
                    lan_ip = _get_lan_ip()
                    print(f"  {_C.GREEN}{_C.BOLD}✅ CONTAINER RUNNING{_C.RESET}")
                    print()
                    print(f"  {_C.CYAN}Local:{_C.RESET}    http://localhost:{port}")
                    if lan_ip != "0.0.0.0":
                        print(f"  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{port}")
                    print()
                    print(f"  {_C.DIM}View logs:   docker compose logs -f{_C.RESET}")
                    print(f"  {_C.DIM}Stop:        docker compose down{_C.RESET}")
                    print(f"  {_C.DIM}Restart:     docker compose restart{_C.RESET}")
                    print()
                else:
                    _fail("Docker build failed")
                    if not args.verbose and result.stderr:
                        for line in result.stderr.strip().splitlines()[-10:]:
                            print(f"  {line}")
                    _info("Try: docker compose up --build (without -d) to see full output")
            except FileNotFoundError:
                _fail("Docker not found. Install Docker: https://docs.docker.com/get-docker/")
                sys.exit(1)

        elif project["has_web"]:
            _header("Step 5 · Starting web server")

            ui_dir = os.path.join(ui_base, "ui")
            server_py = os.path.join(ui_dir, "server.py")

            if not os.path.exists(server_py):
                _fail(f"server.py not found in {ui_dir}")
                sys.exit(1)

            # Kill any existing process on this port
            try:
                result = subprocess.run(
                    ["lsof", "-ti", f"tcp:{port}"],
                    capture_output=True, text=True
                )
                if result.stdout.strip():
                    pids = result.stdout.strip()
                    _info(f"Stopping existing process on port {port}...")
                    subprocess.run(
                        ["kill", "-9"] + pids.split(),
                        capture_output=True
                    )
                    time.sleep(1)
            except FileNotFoundError:
                pass  # lsof not available on this platform

            lan_ip = _get_lan_ip()
            admin_email = env.get("SUPERO_ADMIN_EMAIL", "admin@example.com")

            print()
            print(f"  {_C.GREEN}{_C.BOLD}✅ READY{_C.RESET}")
            print()
            print(f"  {_C.CYAN}Local:{_C.RESET}    http://localhost:{port}")
            if lan_ip != "0.0.0.0":
                print(f"  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{port}")
            print()
            print(f"  {_C.CYAN}Login:{_C.RESET}    {admin_email}")
            print()
            print(f"  {_C.DIM}Press Ctrl+C to stop{_C.RESET}")
            print()

            # Set PORT env var for server.py
            os.environ["PORT"] = str(port)
            os.environ["UI_PORT"] = str(port)

            try:
                subprocess.run(
                    [sys.executable, "server.py"],
                    cwd=ui_dir
                )
            except KeyboardInterrupt:
                print(f"\n  {_C.DIM}Server stopped.{_C.RESET}")

        else:
            _ok("Setup complete (no web UI to start)")

    else:
        _header("Step 5 · Skipped (--setup-only)")
        _ok("Setup complete. Run without --setup-only to start the server.")

    # ── Mobile setup (optional, after web server) ──
    if args.mobile:
        if project["has_mobile"]:
            _header("Mobile · Setting up Expo app")
            mobile_dir = os.path.join(os.getcwd(), "mobile")
            expo_sh = os.path.join(mobile_dir, "expo.sh")

            if os.path.exists(expo_sh):
                subprocess.run(["bash", expo_sh, "setup"], cwd=mobile_dir)
                _ok("Mobile app ready")
                _info("Start with: cd mobile && ./expo.sh start")
            else:
                _warn("mobile/expo.sh not found — download it from CDN first")
                _info("curl -sL https://cdn.supero.dev/mobile/1.0.0/expo.sh -o mobile/expo.sh")
        else:
            _warn("No mobile/src/appConfig.ts found — skipping mobile setup")


if __name__ == "__main__":
    main()
