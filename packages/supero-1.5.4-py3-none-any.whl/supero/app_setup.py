"""
supero.setup — Reusable setup helpers for Supero-generated apps.

Consolidates all the boilerplate that every generated app duplicates:
  - Connection helpers (_host_port, _base, _session)
  - Response parsing (_ok, _extract_uuid, _extract_error)
  - UUID lookups (_fetch_project_uuid, _fetch_tenant_uuid)
  - Progress reporting (_step, _ok_msg, _warn_msg, _fail_msg)
  - SDK build + install (build_and_install_sdk)
  - Service import + config check (ensure_services)
  - Access policy creation (ensure_access_policies)
  - Generic seed helpers (create_with_children)

Usage in generated setup.py (shrinks from ~400 lines to ~50):

    from supero.setup import AppSetup
    from config import MyAppConfig
    from schemas import ALL_SCHEMAS

    setup = AppSetup(MyAppConfig(), ALL_SCHEMAS)
    setup.run()                      # Full bootstrap + services + policies
    setup.seed(my_seed_function)     # App-specific seed data

Or granular:

    setup = AppSetup(config, schemas)
    result = setup.bootstrap()       # Phase 1: domain, schemas, tenants, users
    setup.build_sdk()                # Phase 2: SDK
    setup.import_services()          # Phase 3: services
    setup.create_policies()          # Phase 4: access policies
    setup.create_workflows()         # Phase 5: workflows (if defined)
    setup.seed(my_seed_fn)           # Phase 6: app-specific data

Install: pip install supero>=1.2.0
"""

import sys
import os
import time
import argparse
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

__version__ = '1.0.0'


# ─────────────────────────────────────────────────────────
# Connection Helpers
# ─────────────────────────────────────────────────────────

def parse_host_port(url: str = None) -> tuple:
    """Parse SUPERO_URL into (host, port)."""
    url = (url or os.getenv("SUPERO_URL", "https://api.supero.dev")).strip().rstrip("/")
    scheme, rest = (url.split("://", 1) if "://" in url else ("https", url))
    if ":" in rest:
        host, port_str = rest.rsplit(":", 1)
        try:
            return host, int(port_str)
        except ValueError:
            pass
    return rest, 443 if scheme == "https" else 8083


def build_base_url(url: str = None) -> str:
    """Build base URL from SUPERO_URL env var."""
    host, port = parse_host_port(url)
    proto = "https" if port == 443 else "http"
    return f"{proto}://{host}:{port}"


def create_session(token: str = None, api_key: str = None, app_name: str = "Supero-App") -> requests.Session:
    """Create authenticated requests.Session."""
    s = requests.Session()
    s.verify = False
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    elif api_key:
        s.headers["X-API-Key"] = api_key
    s.headers["Content-Type"] = "application/json"
    s.headers["User-Agent"] = f"{app_name}/1.0"
    return s


# ─────────────────────────────────────────────────────────
# Response Parsing
# ─────────────────────────────────────────────────────────

def is_ok(r) -> bool:
    """Check if response is successful (200 or 201)."""
    return r.status_code in (200, 201)


def extract_uuid(r) -> Optional[str]:
    """Extract UUID from CRUD create response.

    Handles all platform response shapes:
      {'uuid': '...'}                                      ← v3.6 mirrored
      {'data': {'uuid': '...'}}
      {'success': true, 'data': {'property': {'uuid': '...'}}}  ← type-wrapped
    """
    try:
        body = r.json() if r.text else {}
    except Exception:
        return None

    # v3.6: Top-level mirror (most reliable)
    if body.get("uuid"):
        return body["uuid"]

    # Under 'data'
    data = body.get("data", {})
    if isinstance(data, dict):
        if data.get("uuid"):
            return data["uuid"]
        # Type-wrapped: data.{type_name}.uuid
        for val in data.values():
            if isinstance(val, dict) and val.get("uuid"):
                return val["uuid"]

    return None


def extract_error(r) -> str:
    """Extract error message from failed API response."""
    try:
        body = r.json() if r.text else {}
        return body.get("error") or body.get("message") or f"HTTP {r.status_code}"
    except Exception:
        return f"HTTP {r.status_code}"


def is_already_exists(r) -> bool:
    """Check if error is a duplicate/conflict (safe to skip)."""
    if r.status_code == 409:
        return True
    try:
        body = r.json() if r.text else {}
        code = body.get("error_code", "")
        if code == "ALREADY_EXISTS":
            return True
        msg = (body.get("error") or body.get("message") or "").lower()
        return "already exist" in msg
    except Exception:
        return False


# ─────────────────────────────────────────────────────────
# UUID Lookups
# ─────────────────────────────────────────────────────────

def fetch_project_uuid(s, base: str, domain: str, project_name: str) -> Optional[str]:
    """Fetch project UUID by name."""
    r = s.get(f"{base}/api/v1/crud/{domain}/project", timeout=15)
    if is_ok(r):
        for p in r.json().get("results", []):
            if p.get("name") == project_name:
                return p["uuid"]
    return None


def fetch_tenant_uuid(s, base: str, domain: str, tenant_name: str) -> Optional[str]:
    """Fetch tenant UUID by name."""
    r = s.get(f"{base}/api/v1/crud/{domain}/tenant", timeout=15)
    if is_ok(r):
        for t in r.json().get("results", []):
            if t.get("name") == tenant_name:
                return t["uuid"]
    return None


# ─────────────────────────────────────────────────────────
# Progress Reporting
# ─────────────────────────────────────────────────────────

class Progress:
    """Step-by-step progress reporting."""

    def __init__(self, total_steps: int = 12):
        self.total = total_steps

    def step(self, num: int, msg: str):
        print(f"  [{num:>2}/{self.total}] {msg}")
        sys.stdout.flush()

    @staticmethod
    def ok(msg: str):
        print(f"         ✅ {msg}")
        sys.stdout.flush()

    @staticmethod
    def warn(msg: str):
        print(f"         ⚠️  {msg}")
        sys.stdout.flush()

    @staticmethod
    def fail(msg: str):
        print(f"         ❌ {msg}")
        sys.stdout.flush()


# ─────────────────────────────────────────────────────────
# SDK Build + Install
# ─────────────────────────────────────────────────────────

def build_and_install_sdk(org, domain: str, progress: Progress = None):
    """Build and install the domain SDK. Polls until complete."""
    p = progress or Progress()

    if not org:
        p.warn("Skipped — no org instance")
        return

    try:
        gen_result = org.generate_sdk(language="python", output_format="wheel")
        request_id = (
            gen_result.get("request_id")
            or gen_result.get("build_request_uuid")
            or gen_result.get("uuid")
            or gen_result.get("sdk_uuid")
        )
        sdk_status = gen_result.get("status", "unknown")

        if not request_id:
            p.fail(f"No request_id in response: {str(gen_result)[:150]}")
            return
        p.ok(f"Build triggered (request={request_id[:12]}...)")
    except Exception as e:
        p.fail(f"Generate failed: {e}")
        return

    sdk_uuid = None
    if sdk_status == "completed":
        p.ok("Already built (cached)")
        sdk_uuid = _extract_sdk_uuid_from_status(gen_result)
    else:
        timeout_sec, poll_interval = 300, 5
        deadline = time.time() + timeout_sec
        last_msg = ""
        while time.time() < deadline:
            try:
                resp = org.get(f"/sdks/status/{request_id}")
                sdk_status = resp.get("status", "unknown")
                progress_pct = resp.get("progress_percentage", 0)
                step_name = resp.get("current_step", "")

                if sdk_status == "completed":
                    sdk_uuid = _extract_sdk_uuid_from_status(resp)
                    p.ok("Build complete")
                    break
                elif sdk_status == "failed":
                    p.fail(f"Build failed: {resp.get('error_details', 'unknown')}")
                    return
                else:
                    msg = f"{progress_pct}% {step_name}" if progress_pct else sdk_status
                    if msg != last_msg:
                        print(f"         ⏳ {msg}")
                        sys.stdout.flush()
                        last_msg = msg
            except Exception as e:
                p.warn(f"Poll error: {e}")
            time.sleep(poll_interval)
        else:
            p.fail(f"Timed out ({timeout_sec}s)")
            return

    if not sdk_uuid:
        p.fail("No sdk_uuid in completed response")
        return

    try:
        installed = org.sdks.install_python_sdk(sdk_uuid=sdk_uuid)
        if installed:
            p.ok(f"Installed ({sdk_uuid[:12]}...)")
        else:
            p.fail("Install returned False")
    except Exception as e:
        p.fail(f"Install failed: {e}")


def _extract_sdk_uuid_from_status(resp: dict) -> Optional[str]:
    sdks = resp.get("sdks", [])
    if sdks:
        u = sdks[0].get("sdk_uuid")
        if u:
            return u
    uuids = resp.get("generated_sdk_uuids", [])
    return uuids[0] if uuids else None


# ─────────────────────────────────────────────────────────
# Service Import
# ─────────────────────────────────────────────────────────

DEFAULT_SERVICE_HINTS = {
    "email": "SendGrid API key",
    "sms": "Twilio Account SID + Auth Token",
    "stripe_checkout": "Stripe API key (sk_live_...)",
    "google_calendar": "Google Service Account JSON",
    "amazon_s3": "AWS Access Key + Secret + Bucket",
    "slack": "Slack Bot Token (xoxb-...)",
    "ai": "OpenAI and/or Anthropic API key",
    "quickbooks": "QuickBooks OAuth Client ID + Secret + Refresh Token",
    "billing": "Stripe API key",
    "push_notification": "FCM Service Account JSON",
    "whatsapp": "Twilio Account SID + Auth Token + WhatsApp number",
    "salesforce": "Salesforce Client ID + Secret + Username",
    "github": "GitHub Personal Access Token",
    "mcp_server": "No config needed (auto-generates from schemas)",
    "mcp_client": "MCP server URLs to connect to",
    "google_oauth": "Google OAuth Client ID + Secret + Redirect URI",
    "google_ads": "Google Ads Customer ID + Developer Token + OAuth credentials",
    "google_reviews": "Google My Business Account ID + OAuth credentials",
}


def ensure_services(
    s, base: str, domain: str, project_uuid: str,
    services: List[str], progress: Progress = None,
    service_hints: Dict[str, str] = None,
):
    """Import services and show config status summary."""
    p = progress or Progress()
    hints = {**DEFAULT_SERVICE_HINTS, **(service_hints or {})}

    if not services:
        p.ok("None requested")
        return
    if not project_uuid:
        p.fail("No project_uuid — skipping")
        return

    ok = skip = fail = 0
    failed_services = []

    for svc_id in services:
        try:
            r = s.post(f"{base}/api/v1/services/import", json={
                "service_id": svc_id, "domain": domain, "project_uuid": project_uuid,
            }, timeout=30)
            body = r.json() if r.text else {}
            if is_ok(r) and body.get("success"):
                if body.get("details", {}).get("already_imported"):
                    skip += 1
                else:
                    ok += 1
            else:
                fail += 1
                failed_services.append(svc_id)
                p.fail(f"'{svc_id}': {extract_error(r)}")
        except Exception as e:
            fail += 1
            failed_services.append(svc_id)
            p.fail(f"'{svc_id}': {e}")

    p.ok(f"{ok} imported, {skip} existing, {fail} failed")

    # Config status check
    needs_config = []
    configured = []
    for svc_id in services:
        if svc_id in failed_services:
            continue
        try:
            cr = s.get(f"{base}/api/v1/services/{svc_id}/config", timeout=10)
            if is_ok(cr):
                cb = cr.json() if cr.text else {}
                status = cb.get("config_status") or cb.get("status", "")
                if status in ("active", "configured"):
                    configured.append(svc_id)
                else:
                    needs_config.append(svc_id)
            else:
                needs_config.append(svc_id)
        except Exception:
            needs_config.append(svc_id)

    # Summary
    print()
    print("  ┌─ Service Status ──────────────────────────────────────┐")
    for svc_id in services:
        hint = hints.get(svc_id, "API credentials")
        if svc_id in failed_services:
            print(f"  │  ❌ {svc_id:<20s} Import failed")
        elif svc_id in configured:
            print(f"  │  ✅ {svc_id:<20s} Ready")
        elif svc_id in needs_config:
            print(f"  │  ⚠️  {svc_id:<20s} Needs: {hint}")
        else:
            print(f"  │  ✅ {svc_id:<20s} Imported")
    if needs_config:
        print("  │")
        print(f"  │  Configure: Supero Admin → {domain} → Services")
    print("  └──────────────────────────────────────────────────────┘")
    print()


# ─────────────────────────────────────────────────────────
# Access Policies
# ─────────────────────────────────────────────────────────

@dataclass
class PolicyRule:
    entity: str
    can_create: bool = False
    can_read: bool = True
    can_update: bool = False
    can_delete: bool = False


@dataclass
class PolicyDef:
    role: str
    default_access: str = "none"
    description: str = ""
    rules: List[PolicyRule] = field(default_factory=list)


def ensure_access_policies(
    s, base: str, domain: str, project_uuid: str,
    policies: List[PolicyDef], progress: Progress = None,
):
    """Create access policies and rules from config."""
    p = progress or Progress()

    if not project_uuid:
        p.fail("No project_uuid — skipping")
        return

    r = s.get(f"{base}/api/v1/crud/{domain}/access-policy", timeout=15)
    if not is_ok(r):
        p.fail(f"List failed: {extract_error(r)}")
        return

    existing_roles = {
        pol.get("role") for pol in r.json().get("results", [])
        if pol.get("parent_uuid") == project_uuid
    }

    created = skipped = 0
    for policy in policies:
        if policy.role in existing_roles:
            skipped += 1
            continue
        if not policy.rules and policy.default_access == "full":
            skipped += 1  # full access roles don't need explicit rules
            continue

        pr = s.post(f"{base}/api/v1/crud/{domain}/access-policy", json={
            "name": f"{policy.role}-policy",
            "parent_type": "project",
            "parent_uuid": project_uuid,
            "role": policy.role,
            "default_access": policy.default_access,
            "description": policy.description,
            "is_active": True,
            "priority": 0,
        }, timeout=30)

        if not is_ok(pr):
            if is_already_exists(pr):
                skipped += 1
                continue
            p.fail(f"Policy '{policy.role}': {extract_error(pr)}")
            continue

        policy_uuid = extract_uuid(pr)
        if not policy_uuid:
            p.fail(f"Policy '{policy.role}' — no UUID")
            continue

        for rule in policy.rules:
            rr = s.post(f"{base}/api/v1/crud/{domain}/access-rule", json={
                "name": f"{policy.role}-{rule.entity}-rule",
                "parent_type": "access-policy",
                "parent_uuid": policy_uuid,
                "entity": rule.entity,
                "can_create": rule.can_create,
                "can_read": rule.can_read,
                "can_update": rule.can_update,
                "can_delete": rule.can_delete,
            }, timeout=30)
            if not is_ok(rr) and not is_already_exists(rr):
                p.fail(f"Rule '{policy.role}/{rule.entity}': {extract_error(rr)}")

        created += 1

    p.ok(f"{created} created, {skipped} existing")


# ─────────────────────────────────────────────────────────
# Workflow Definitions
# ─────────────────────────────────────────────────────────

def ensure_workflows(
    s, base: str, domain: str, project_uuid: str,
    workflow_definitions: List[Dict], progress: Progress = None,
):
    """Create workflow definitions as CRUD records. Idempotent."""
    p = progress or Progress()

    if not workflow_definitions:
        p.ok("No workflows defined")
        return
    if not project_uuid:
        p.fail("No project_uuid — skipping workflows")
        return

    # Check existing
    r = s.get(f"{base}/api/v1/crud/{domain}/wf:workflow_definition", timeout=15)
    existing_ids = set()
    if is_ok(r):
        for wf in r.json().get("results", []):
            existing_ids.add(wf.get("workflow_id"))

    created = skipped = failed = 0
    for wf_def in workflow_definitions:
        wf_id = wf_def.get("workflow_id", "")
        if wf_id in existing_ids:
            skipped += 1
            continue
        payload = {"name": wf_id, "parent_type": "tenant", **wf_def}
        try:
            r = s.post(f"{base}/api/v1/crud/{domain}/wf:workflow_definition",
                       json=payload, timeout=30)
            if is_ok(r):
                created += 1
            elif is_already_exists(r):
                skipped += 1
            else:
                failed += 1
                p.fail(f"Workflow '{wf_id}': {extract_error(r)}")
        except Exception as e:
            failed += 1
            p.fail(f"Workflow '{wf_id}': {e}")

    p.ok(f"{created} created, {skipped} existing, {failed} failed")


# ─────────────────────────────────────────────────────────
# Generic Seed Helpers
# ─────────────────────────────────────────────────────────

def create_with_children(
    s, base: str, domain: str,
    parent_schema: str, parent_data: dict, parent_uuid_override: str = None,
    child_schema: str = None, children: List[dict] = None,
    progress: Progress = None,
) -> Optional[str]:
    """Create a parent record and optionally its children. Returns parent UUID."""
    p = progress or Progress()

    # Create parent
    if parent_uuid_override:
        parent_uuid = parent_uuid_override
    else:
        r = s.post(f"{base}/api/v1/crud/{domain}/{parent_schema}",
                   json=parent_data, timeout=30)
        if not is_ok(r):
            if is_already_exists(r):
                # Try to find existing
                lr = s.get(f"{base}/api/v1/crud/{domain}/{parent_schema}", timeout=15)
                if is_ok(lr):
                    for item in lr.json().get("results", []):
                        if item.get("name") == parent_data.get("name"):
                            return item.get("uuid")
                return None
            p.fail(f"{parent_schema}: {extract_error(r)}")
            return None
        parent_uuid = extract_uuid(r)
        if not parent_uuid:
            p.fail(f"{parent_schema} created but no UUID")
            return None

    # Create children
    if child_schema and children:
        ok = 0
        for child in children:
            child["parent_type"] = parent_schema
            child["parent_uuid"] = parent_uuid
            cr = s.post(f"{base}/api/v1/crud/{domain}/{child_schema}",
                       json=child, timeout=30)
            if is_ok(cr):
                ok += 1
            elif not is_already_exists(cr):
                p.fail(f"{child_schema} '{child.get('name', '?')}': {extract_error(cr)}")
        p.ok(f"{parent_schema} + {ok}/{len(children)} {child_schema}s")

    return parent_uuid


# ─────────────────────────────────────────────────────────
# AppSetup — Orchestrator
# ─────────────────────────────────────────────────────────

class AppSetup:
    """
    Main orchestrator for Supero app setup.

    Generated setup.py becomes:
        from supero.setup import AppSetup
        setup = AppSetup(config, schemas)
        setup.run()
    """

    def __init__(self, config, schemas: list, public_schemas: list = None):
        """
        Args:
            config: Dataclass with domain_name, admin_email, admin_password,
                    project_name, tenants, users, services
            schemas: ALL_SCHEMAS list
            public_schemas: PUBLIC_SCHEMAS list (for landing page)
        """
        self.config = config
        self.schemas = schemas
        self.public_schemas = public_schemas or []
        self.progress = Progress(total_steps=12)
        self.base = build_base_url()
        self.host, self.port = parse_host_port()

        # Set after bootstrap
        self.result = None
        self.session = None
        self.domain = config.domain_name
        self.project_uuid = None
        self.tenant_uuid = None

    def run(self, seed_fn: Callable = None, policies: List[PolicyDef] = None,
            workflow_definitions: List[Dict] = None):
        """Full setup: bootstrap → SDK → services → policies → workflows → seed."""
        self.bootstrap()
        self.build_sdk()
        self.import_services()
        if policies:
            self.create_policies(policies)
        if workflow_definitions:
            self.create_workflows(workflow_definitions)
        if seed_fn:
            self.seed(seed_fn)
        self._print_summary()

    def bootstrap(self):
        """Phase 1: Register domain, upload schemas, create tenants/users."""
        from supero import bootstrap as supero_bootstrap

        cfg = self.config
        p = self.progress

        print()
        print(f"  🏗️  {cfg.domain_name} Setup")
        print(f"  ─────────────────────────────────────────────")
        print(f"  Backend: {self.base}")
        print()

        p.step(1, f"Registering domain '{cfg.domain_name}'...")

        self.result = supero_bootstrap(
            domain_name=cfg.domain_name,
            admin_email=cfg.admin_email,
            admin_password=cfg.admin_password,
            project_name=cfg.project_name,
            schemas=self.schemas,
            tenants=cfg.tenants,
            users=cfg.users,
            idempotent=True,
            fail_fast=False,
            platform_core_host=self.host,
            platform_core_port=self.port,
        )

        result = self.result
        if result.domain_uuid:
            p.ok(f"Domain ready ({result.domain_uuid[:12]}...)")
        else:
            p.fail("Domain registration failed")
            for e in result.errors:
                p.fail(f"  {e}")
            sys.exit(1)

        p.step(2, f"Login as '{cfg.admin_email}'...")
        if result.org:
            p.ok("Authenticated")
        else:
            p.fail("Login failed")
            sys.exit(1)

        p.step(3, "Retrieving API key...")
        if result.api_key:
            _update_env("SUPERO_API_KEY", result.api_key)
            os.environ["SUPERO_API_KEY"] = result.api_key
            p.ok(f"API key: ...{result.api_key[-4:]}")
        else:
            p.warn("No API key returned")

        p.step(4, f"Project '{cfg.project_name}'...")
        if result.project_uuid:
            p.ok(f"Project ready ({result.project_uuid[:12]}...)")
        else:
            p.warn("Project UUID not available")

        p.step(5, f"Uploading {len(self.schemas)} schemas...")
        if result.schemas_failed > 0:
            p.warn(f"{result.schemas_uploaded} uploaded, {result.schemas_skipped} skipped, {result.schemas_failed} FAILED")
        else:
            p.ok(f"{result.schemas_uploaded} uploaded, {result.schemas_updated} updated, {result.schemas_skipped} skipped")

        p.step(7, "Creating tenants...")
        if result.tenants_failed > 0:
            p.fail(f"{result.tenants_failed} FAILED")
        else:
            p.ok(f"{result.tenants_created} created, {result.tenants_skipped} skipped")

        p.step(8, "Creating users...")
        if result.users_failed > 0:
            p.fail(f"{result.users_failed} FAILED")
        else:
            p.ok(f"{result.users_created} created, {result.users_skipped} skipped")

        # Setup session for remaining steps
        org = result.org
        jwt = getattr(org, '_jwt_token', None) if org else None
        self.session = create_session(token=jwt, api_key=result.api_key, app_name=cfg.domain_name)
        self.project_uuid = result.project_uuid or fetch_project_uuid(
            self.session, self.base, self.domain, cfg.project_name)
        tenant_name = cfg.tenants[0]["name"] if cfg.tenants else "default-tenant"
        self.tenant_uuid = fetch_tenant_uuid(self.session, self.base, self.domain, tenant_name)

    def build_sdk(self):
        """Phase 2: Build and install domain SDK."""
        self.progress.step(6, "Building domain SDK (may take 30-60s)...")
        build_and_install_sdk(
            self.result.org if self.result else None,
            self.domain,
            self.progress,
        )

    def import_services(self):
        """Phase 3: Import tenant services."""
        self.progress.step(9, "Importing services...")
        ensure_services(
            self.session, self.base, self.domain, self.project_uuid,
            self.config.services, self.progress,
        )

    def create_policies(self, policies: List[PolicyDef]):
        """Phase 4: Create access policies."""
        self.progress.step(10, "Setting up access policies...")
        ensure_access_policies(
            self.session, self.base, self.domain, self.project_uuid,
            policies, self.progress,
        )

    def create_workflows(self, workflow_definitions: List[Dict]):
        """Phase 5: Create workflow definitions."""
        self.progress.step(11, "Creating workflow definitions...")
        ensure_workflows(
            self.session, self.base, self.domain, self.project_uuid,
            workflow_definitions, self.progress,
        )

    def seed(self, seed_fn: Callable):
        """Phase 6: Run app-specific seed function."""
        self.progress.step(12, "Seeding data...")
        seed_fn(
            self.session, self.base, self.domain,
            self.tenant_uuid, self.progress,
        )

    def _print_summary(self):
        cfg = self.config
        print()
        print(f"  ✅ {cfg.domain_name} ready!")
        print(f"  ─────────────────────────────────────────────")
        print(f"  Admin: {cfg.admin_email}")
        print()


# ─────────────────────────────────────────────────────────
# Env file helper
# ─────────────────────────────────────────────────────────

def _update_env(key: str, value: str):
    """Update or add a key in .env file."""
    env_path = os.path.join(os.getcwd(), ".env")
    # Walk up to find .env
    for _ in range(3):
        if os.path.exists(env_path):
            break
        env_path = os.path.join(os.path.dirname(os.path.dirname(env_path)), ".env")

    lines = open(env_path).readlines() if os.path.exists(env_path) else []
    found = False
    for i, line in enumerate(lines):
        if line.startswith(f"{key}="):
            lines[i] = f"{key}={value}\n"
            found = True
            break
    if not found:
        lines.append(f"{key}={value}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)
