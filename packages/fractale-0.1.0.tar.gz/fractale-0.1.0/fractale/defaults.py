fractale_dir = ".fractale"
