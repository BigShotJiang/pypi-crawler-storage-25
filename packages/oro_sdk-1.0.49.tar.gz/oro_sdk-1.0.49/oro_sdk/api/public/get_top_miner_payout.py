from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.top_miner_payout_response import TopMinerPayoutResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/top-miner-payout",
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> TopMinerPayoutResponse | None:
    if response.status_code == 200:
        response_200 = TopMinerPayoutResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[TopMinerPayoutResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[TopMinerPayoutResponse]:
    """Get top miner payout rate

     Get the current top miner's estimated emission payout rate in TAO/day and USD/day. Uses the cached
    metagraph and a periodically refreshed TAO/USD price.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TopMinerPayoutResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> TopMinerPayoutResponse | None:
    """Get top miner payout rate

     Get the current top miner's estimated emission payout rate in TAO/day and USD/day. Uses the cached
    metagraph and a periodically refreshed TAO/USD price.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TopMinerPayoutResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[TopMinerPayoutResponse]:
    """Get top miner payout rate

     Get the current top miner's estimated emission payout rate in TAO/day and USD/day. Uses the cached
    metagraph and a periodically refreshed TAO/USD price.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TopMinerPayoutResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> TopMinerPayoutResponse | None:
    """Get top miner payout rate

     Get the current top miner's estimated emission payout rate in TAO/day and USD/day. Uses the cached
    metagraph and a periodically refreshed TAO/USD price.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TopMinerPayoutResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
