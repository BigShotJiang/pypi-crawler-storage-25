from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.race_history_response import RaceHistoryResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_suite_id: int | None | Unset
    if isinstance(suite_id, Unset):
        json_suite_id = UNSET
    else:
        json_suite_id = suite_id
    params["suite_id"] = json_suite_id

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/races/history",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | RaceHistoryResponse | None:
    if response.status_code == 200:
        response_200 = RaceHistoryResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | RaceHistoryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | RaceHistoryResponse]:
    """Get race history

     Get completed and cancelled races, most recent first.

    Args:
        suite_id (int | None | Unset): Filter by suite ID
        limit (int | Unset): Page size Default: 20.
        offset (int | Unset): Page offset Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RaceHistoryResponse]
    """

    kwargs = _get_kwargs(
        suite_id=suite_id,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> HTTPValidationError | RaceHistoryResponse | None:
    """Get race history

     Get completed and cancelled races, most recent first.

    Args:
        suite_id (int | None | Unset): Filter by suite ID
        limit (int | Unset): Page size Default: 20.
        offset (int | Unset): Page offset Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RaceHistoryResponse
    """

    return sync_detailed(
        client=client,
        suite_id=suite_id,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | RaceHistoryResponse]:
    """Get race history

     Get completed and cancelled races, most recent first.

    Args:
        suite_id (int | None | Unset): Filter by suite ID
        limit (int | Unset): Page size Default: 20.
        offset (int | Unset): Page offset Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RaceHistoryResponse]
    """

    kwargs = _get_kwargs(
        suite_id=suite_id,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> HTTPValidationError | RaceHistoryResponse | None:
    """Get race history

     Get completed and cancelled races, most recent first.

    Args:
        suite_id (int | None | Unset): Filter by suite ID
        limit (int | Unset): Page size Default: 20.
        offset (int | Unset): Page offset Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RaceHistoryResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            suite_id=suite_id,
            limit=limit,
            offset=offset,
        )
    ).parsed
