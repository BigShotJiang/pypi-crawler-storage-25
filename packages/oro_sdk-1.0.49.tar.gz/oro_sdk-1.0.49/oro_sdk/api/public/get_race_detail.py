from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.race_detail_response import RaceDetailResponse
from ...models.race_not_found_error import RaceNotFoundError
from ...types import Response


def _get_kwargs(
    race_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/races/{race_id}".format(
            race_id=quote(str(race_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | RaceDetailResponse | RaceNotFoundError | None:
    if response.status_code == 200:
        response_200 = RaceDetailResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = RaceNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | RaceDetailResponse | RaceNotFoundError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | RaceDetailResponse | RaceNotFoundError]:
    """Get race details

     Get details for a specific race including qualifiers and results.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RaceDetailResponse | RaceNotFoundError]
    """

    kwargs = _get_kwargs(
        race_id=race_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | RaceDetailResponse | RaceNotFoundError | None:
    """Get race details

     Get details for a specific race including qualifiers and results.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RaceDetailResponse | RaceNotFoundError
    """

    return sync_detailed(
        race_id=race_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | RaceDetailResponse | RaceNotFoundError]:
    """Get race details

     Get details for a specific race including qualifiers and results.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RaceDetailResponse | RaceNotFoundError]
    """

    kwargs = _get_kwargs(
        race_id=race_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | RaceDetailResponse | RaceNotFoundError | None:
    """Get race details

     Get details for a specific race including qualifiers and results.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RaceDetailResponse | RaceNotFoundError
    """

    return (
        await asyncio_detailed(
            race_id=race_id,
            client=client,
        )
    ).parsed
