from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.suite_not_found_error import SuiteNotFoundError
from ...models.suite_with_problems_response import SuiteWithProblemsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    suite_id: int,
    *,
    include_embeddings: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["include_embeddings"] = include_embeddings

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/suites/{suite_id}/problems".format(
            suite_id=quote(str(suite_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse | None:
    if response.status_code == 200:
        response_200 = SuiteWithProblemsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = SuiteNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    suite_id: int,
    *,
    client: AuthenticatedClient | Client,
    include_embeddings: bool | Unset = False,
) -> Response[HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse]:
    """Get suite problems

     Get the list of problems for a specific suite.

    Args:
        suite_id (int): Suite ID/version
        include_embeddings (bool | Unset): Include precomputed reward_title_embeddings in
            metadata. Off by default to keep responses small (~50 KB vs ~1.5 MB). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse]
    """

    kwargs = _get_kwargs(
        suite_id=suite_id,
        include_embeddings=include_embeddings,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    suite_id: int,
    *,
    client: AuthenticatedClient | Client,
    include_embeddings: bool | Unset = False,
) -> HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse | None:
    """Get suite problems

     Get the list of problems for a specific suite.

    Args:
        suite_id (int): Suite ID/version
        include_embeddings (bool | Unset): Include precomputed reward_title_embeddings in
            metadata. Off by default to keep responses small (~50 KB vs ~1.5 MB). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse
    """

    return sync_detailed(
        suite_id=suite_id,
        client=client,
        include_embeddings=include_embeddings,
    ).parsed


async def asyncio_detailed(
    suite_id: int,
    *,
    client: AuthenticatedClient | Client,
    include_embeddings: bool | Unset = False,
) -> Response[HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse]:
    """Get suite problems

     Get the list of problems for a specific suite.

    Args:
        suite_id (int): Suite ID/version
        include_embeddings (bool | Unset): Include precomputed reward_title_embeddings in
            metadata. Off by default to keep responses small (~50 KB vs ~1.5 MB). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse]
    """

    kwargs = _get_kwargs(
        suite_id=suite_id,
        include_embeddings=include_embeddings,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    suite_id: int,
    *,
    client: AuthenticatedClient | Client,
    include_embeddings: bool | Unset = False,
) -> HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse | None:
    """Get suite problems

     Get the list of problems for a specific suite.

    Args:
        suite_id (int): Suite ID/version
        include_embeddings (bool | Unset): Include precomputed reward_title_embeddings in
            metadata. Off by default to keep responses small (~50 KB vs ~1.5 MB). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SuiteNotFoundError | SuiteWithProblemsResponse
    """

    return (
        await asyncio_detailed(
            suite_id=suite_id,
            client=client,
            include_embeddings=include_embeddings,
        )
    ).parsed
