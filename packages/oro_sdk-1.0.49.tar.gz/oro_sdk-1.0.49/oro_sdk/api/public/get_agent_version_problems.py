from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_version_not_found_error import AgentVersionNotFoundError
from ...models.agent_version_problems_response import AgentVersionProblemsResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    agent_version_id: UUID,
    *,
    phase: None | str | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_phase: None | str | Unset
    if isinstance(phase, Unset):
        json_phase = UNSET
    else:
        json_phase = phase
    params["phase"] = json_phase

    json_race_id: None | str | Unset
    if isinstance(race_id, Unset):
        json_race_id = UNSET
    elif isinstance(race_id, UUID):
        json_race_id = str(race_id)
    else:
        json_race_id = race_id
    params["race_id"] = json_race_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/agent-versions/{agent_version_id}/problems".format(
            agent_version_id=quote(str(agent_version_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AgentVersionProblemsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = AgentVersionNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    phase: None | str | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
) -> Response[AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError]:
    """Get agent version problem progress

     Get per-problem progress matrix across validators.

    Args:
        agent_version_id (UUID): Agent version ID
        phase (None | str | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter to a specific race (implies phase=RACE)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        phase=phase,
        race_id=race_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    phase: None | str | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
) -> AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError | None:
    """Get agent version problem progress

     Get per-problem progress matrix across validators.

    Args:
        agent_version_id (UUID): Agent version ID
        phase (None | str | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter to a specific race (implies phase=RACE)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError
    """

    return sync_detailed(
        agent_version_id=agent_version_id,
        client=client,
        phase=phase,
        race_id=race_id,
    ).parsed


async def asyncio_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    phase: None | str | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
) -> Response[AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError]:
    """Get agent version problem progress

     Get per-problem progress matrix across validators.

    Args:
        agent_version_id (UUID): Agent version ID
        phase (None | str | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter to a specific race (implies phase=RACE)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        phase=phase,
        race_id=race_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    phase: None | str | Unset = UNSET,
    race_id: None | Unset | UUID = UNSET,
) -> AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError | None:
    """Get agent version problem progress

     Get per-problem progress matrix across validators.

    Args:
        agent_version_id (UUID): Agent version ID
        phase (None | str | Unset): Filter by evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Filter to a specific race (implies phase=RACE)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | AgentVersionProblemsResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            agent_version_id=agent_version_id,
            client=client,
            phase=phase,
            race_id=race_id,
        )
    ).parsed
