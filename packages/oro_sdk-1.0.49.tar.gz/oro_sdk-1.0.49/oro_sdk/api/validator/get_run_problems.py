from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.eval_run_not_found_error import EvalRunNotFoundError
from ...models.http_validation_error import HTTPValidationError
from ...models.run_problems_response import RunProblemsResponse
from ...types import Response


def _get_kwargs(
    eval_run_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/validator/evaluation-runs/{eval_run_id}/problems".format(
            eval_run_id=quote(str(eval_run_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse | None:
    if response.status_code == 200:
        response_200 = RunProblemsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = EvalRunNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse]:
    """Get problems for an evaluation run

     Returns the problems that should be evaluated for a given run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse | None:
    """Get problems for an evaluation run

     Returns the problems that should be evaluated for a given run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse
    """

    return sync_detailed(
        eval_run_id=eval_run_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse]:
    """Get problems for an evaluation run

     Returns the problems that should be evaluated for a given run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse | None:
    """Get problems for an evaluation run

     Returns the problems that should be evaluated for a given run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EvalRunNotFoundError | HTTPValidationError | RunProblemsResponse
    """

    return (
        await asyncio_detailed(
            eval_run_id=eval_run_id,
            client=client,
        )
    ).parsed
