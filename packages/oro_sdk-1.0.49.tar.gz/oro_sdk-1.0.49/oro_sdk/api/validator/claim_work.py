from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.at_capacity_error import AtCapacityError
from ...models.claim_work_response import ClaimWorkResponse
from ...models.heartbeat_request import HeartbeatRequest
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: HeartbeatRequest | None | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/validator/work/claim",
    }

    if isinstance(body, HeartbeatRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ClaimWorkResponse.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 409:
        response_409 = AtCapacityError.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: HeartbeatRequest | None | Unset = UNSET,
) -> Response[Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError]:
    """Claim evaluation work

     FIFO claim of next available evaluation work item.

    Args:
        body (HeartbeatRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: HeartbeatRequest | None | Unset = UNSET,
) -> Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError | None:
    """Claim evaluation work

     FIFO claim of next available evaluation work item.

    Args:
        body (HeartbeatRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: HeartbeatRequest | None | Unset = UNSET,
) -> Response[Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError]:
    """Claim evaluation work

     FIFO claim of next available evaluation work item.

    Args:
        body (HeartbeatRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: HeartbeatRequest | None | Unset = UNSET,
) -> Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError | None:
    """Claim evaluation work

     FIFO claim of next available evaluation work item.

    Args:
        body (HeartbeatRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AtCapacityError | ClaimWorkResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
