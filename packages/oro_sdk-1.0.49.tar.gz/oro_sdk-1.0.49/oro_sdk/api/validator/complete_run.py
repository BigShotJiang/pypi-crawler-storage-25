from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.complete_run_request import CompleteRunRequest
from ...models.complete_run_response import CompleteRunResponse
from ...models.eval_run_not_found_error import EvalRunNotFoundError
from ...models.http_validation_error import HTTPValidationError
from ...models.missing_score_error import MissingScoreError
from ...models.not_run_owner_error import NotRunOwnerError
from ...models.run_already_complete_error import RunAlreadyCompleteError
from ...models.validation_error_error import ValidationErrorError
from ...types import Response


def _get_kwargs(
    eval_run_id: UUID,
    *,
    body: CompleteRunRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/validator/evaluation-runs/{eval_run_id}/complete".format(
            eval_run_id=quote(str(eval_run_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    CompleteRunResponse
    | EvalRunNotFoundError
    | HTTPValidationError
    | MissingScoreError
    | ValidationErrorError
    | NotRunOwnerError
    | RunAlreadyCompleteError
    | None
):
    if response.status_code == 200:
        response_200 = CompleteRunResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:

        def _parse_response_400(data: object) -> MissingScoreError | ValidationErrorError:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_400_type_0 = MissingScoreError.from_dict(data)

                return response_400_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_400_type_1 = ValidationErrorError.from_dict(data)

            return response_400_type_1

        response_400 = _parse_response_400(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = EvalRunNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 409:

        def _parse_response_409(data: object) -> NotRunOwnerError | RunAlreadyCompleteError:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_409_type_0 = NotRunOwnerError.from_dict(data)

                return response_409_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_409_type_1 = RunAlreadyCompleteError.from_dict(data)

            return response_409_type_1

        response_409 = _parse_response_409(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    CompleteRunResponse
    | EvalRunNotFoundError
    | HTTPValidationError
    | MissingScoreError
    | ValidationErrorError
    | NotRunOwnerError
    | RunAlreadyCompleteError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CompleteRunRequest,
) -> Response[
    CompleteRunResponse
    | EvalRunNotFoundError
    | HTTPValidationError
    | MissingScoreError
    | ValidationErrorError
    | NotRunOwnerError
    | RunAlreadyCompleteError
]:
    """Complete evaluation run

     Finalize an evaluation run with terminal status and score.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (CompleteRunRequest): Sent by the validator when an evaluation run finishes.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CompleteRunResponse | EvalRunNotFoundError | HTTPValidationError | MissingScoreError | ValidationErrorError | NotRunOwnerError | RunAlreadyCompleteError]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CompleteRunRequest,
) -> (
    CompleteRunResponse
    | EvalRunNotFoundError
    | HTTPValidationError
    | MissingScoreError
    | ValidationErrorError
    | NotRunOwnerError
    | RunAlreadyCompleteError
    | None
):
    """Complete evaluation run

     Finalize an evaluation run with terminal status and score.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (CompleteRunRequest): Sent by the validator when an evaluation run finishes.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CompleteRunResponse | EvalRunNotFoundError | HTTPValidationError | MissingScoreError | ValidationErrorError | NotRunOwnerError | RunAlreadyCompleteError
    """

    return sync_detailed(
        eval_run_id=eval_run_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CompleteRunRequest,
) -> Response[
    CompleteRunResponse
    | EvalRunNotFoundError
    | HTTPValidationError
    | MissingScoreError
    | ValidationErrorError
    | NotRunOwnerError
    | RunAlreadyCompleteError
]:
    """Complete evaluation run

     Finalize an evaluation run with terminal status and score.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (CompleteRunRequest): Sent by the validator when an evaluation run finishes.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CompleteRunResponse | EvalRunNotFoundError | HTTPValidationError | MissingScoreError | ValidationErrorError | NotRunOwnerError | RunAlreadyCompleteError]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CompleteRunRequest,
) -> (
    CompleteRunResponse
    | EvalRunNotFoundError
    | HTTPValidationError
    | MissingScoreError
    | ValidationErrorError
    | NotRunOwnerError
    | RunAlreadyCompleteError
    | None
):
    """Complete evaluation run

     Finalize an evaluation run with terminal status and score.

    Args:
        eval_run_id (UUID): Evaluation run ID
        body (CompleteRunRequest): Sent by the validator when an evaluation run finishes.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CompleteRunResponse | EvalRunNotFoundError | HTTPValidationError | MissingScoreError | ValidationErrorError | NotRunOwnerError | RunAlreadyCompleteError
    """

    return (
        await asyncio_detailed(
            eval_run_id=eval_run_id,
            client=client,
            body=body,
        )
    ).parsed
