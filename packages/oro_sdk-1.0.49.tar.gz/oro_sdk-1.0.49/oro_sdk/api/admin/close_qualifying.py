from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.close_qualifying_response import CloseQualifyingResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/races/close-qualifying",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CloseQualifyingResponse | None:
    if response.status_code == 200:
        response_200 = CloseQualifyingResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CloseQualifyingResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[CloseQualifyingResponse]:
    """Close qualifying and start race

     Close the current qualifying window immediately.

    Sets qualifying_closes_at to now so the orchestrator picks it up
    on its next cycle and transitions to RACE_RUNNING (or CANCELLED
    if no qualifiers meet the threshold).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CloseQualifyingResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> CloseQualifyingResponse | None:
    """Close qualifying and start race

     Close the current qualifying window immediately.

    Sets qualifying_closes_at to now so the orchestrator picks it up
    on its next cycle and transitions to RACE_RUNNING (or CANCELLED
    if no qualifiers meet the threshold).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CloseQualifyingResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[CloseQualifyingResponse]:
    """Close qualifying and start race

     Close the current qualifying window immediately.

    Sets qualifying_closes_at to now so the orchestrator picks it up
    on its next cycle and transitions to RACE_RUNNING (or CANCELLED
    if no qualifiers meet the threshold).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CloseQualifyingResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> CloseQualifyingResponse | None:
    """Close qualifying and start race

     Close the current qualifying window immediately.

    Sets qualifying_closes_at to now so the orchestrator picks it up
    on its next cycle and transitions to RACE_RUNNING (or CANCELLED
    if no qualifiers meet the threshold).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CloseQualifyingResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
