import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.admin_agent_versions_response import AdminAgentVersionsResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    is_eligible: bool | None | Unset = UNSET,
    is_discarded: bool | None | Unset = UNSET,
    miner_hotkey: None | str | Unset = UNSET,
    suite_id: int | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_is_eligible: bool | None | Unset
    if isinstance(is_eligible, Unset):
        json_is_eligible = UNSET
    else:
        json_is_eligible = is_eligible
    params["is_eligible"] = json_is_eligible

    json_is_discarded: bool | None | Unset
    if isinstance(is_discarded, Unset):
        json_is_discarded = UNSET
    else:
        json_is_discarded = is_discarded
    params["is_discarded"] = json_is_discarded

    json_miner_hotkey: None | str | Unset
    if isinstance(miner_hotkey, Unset):
        json_miner_hotkey = UNSET
    else:
        json_miner_hotkey = miner_hotkey
    params["miner_hotkey"] = json_miner_hotkey

    json_suite_id: int | None | Unset
    if isinstance(suite_id, Unset):
        json_suite_id = UNSET
    else:
        json_suite_id = suite_id
    params["suite_id"] = json_suite_id

    json_since: None | str | Unset
    if isinstance(since, Unset):
        json_since = UNSET
    elif isinstance(since, datetime.datetime):
        json_since = since.isoformat()
    else:
        json_since = since
    params["since"] = json_since

    json_until: None | str | Unset
    if isinstance(until, Unset):
        json_until = UNSET
    elif isinstance(until, datetime.datetime):
        json_until = until.isoformat()
    else:
        json_until = until
    params["until"] = json_until

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/agent-versions",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AdminAgentVersionsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AdminAgentVersionsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AdminAgentVersionsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    is_eligible: bool | None | Unset = UNSET,
    is_discarded: bool | None | Unset = UNSET,
    miner_hotkey: None | str | Unset = UNSET,
    suite_id: int | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[AdminAgentVersionsResponse | HTTPValidationError]:
    """List agent versions with work item state

     List agent versions with aggregate and work item state for a specific suite.

    Args:
        is_eligible (bool | None | Unset): Filter by eligibility
        is_discarded (bool | None | Unset): Filter by discard status
        miner_hotkey (None | str | Unset): Filter by miner hotkey
        suite_id (int | None | Unset): Suite ID (defaults to active suite)
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of versions to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AdminAgentVersionsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        is_eligible=is_eligible,
        is_discarded=is_discarded,
        miner_hotkey=miner_hotkey,
        suite_id=suite_id,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    is_eligible: bool | None | Unset = UNSET,
    is_discarded: bool | None | Unset = UNSET,
    miner_hotkey: None | str | Unset = UNSET,
    suite_id: int | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> AdminAgentVersionsResponse | HTTPValidationError | None:
    """List agent versions with work item state

     List agent versions with aggregate and work item state for a specific suite.

    Args:
        is_eligible (bool | None | Unset): Filter by eligibility
        is_discarded (bool | None | Unset): Filter by discard status
        miner_hotkey (None | str | Unset): Filter by miner hotkey
        suite_id (int | None | Unset): Suite ID (defaults to active suite)
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of versions to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AdminAgentVersionsResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        is_eligible=is_eligible,
        is_discarded=is_discarded,
        miner_hotkey=miner_hotkey,
        suite_id=suite_id,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    is_eligible: bool | None | Unset = UNSET,
    is_discarded: bool | None | Unset = UNSET,
    miner_hotkey: None | str | Unset = UNSET,
    suite_id: int | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[AdminAgentVersionsResponse | HTTPValidationError]:
    """List agent versions with work item state

     List agent versions with aggregate and work item state for a specific suite.

    Args:
        is_eligible (bool | None | Unset): Filter by eligibility
        is_discarded (bool | None | Unset): Filter by discard status
        miner_hotkey (None | str | Unset): Filter by miner hotkey
        suite_id (int | None | Unset): Suite ID (defaults to active suite)
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of versions to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AdminAgentVersionsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        is_eligible=is_eligible,
        is_discarded=is_discarded,
        miner_hotkey=miner_hotkey,
        suite_id=suite_id,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    is_eligible: bool | None | Unset = UNSET,
    is_discarded: bool | None | Unset = UNSET,
    miner_hotkey: None | str | Unset = UNSET,
    suite_id: int | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> AdminAgentVersionsResponse | HTTPValidationError | None:
    """List agent versions with work item state

     List agent versions with aggregate and work item state for a specific suite.

    Args:
        is_eligible (bool | None | Unset): Filter by eligibility
        is_discarded (bool | None | Unset): Filter by discard status
        miner_hotkey (None | str | Unset): Filter by miner hotkey
        suite_id (int | None | Unset): Suite ID (defaults to active suite)
        since (datetime.datetime | None | Unset): Filter: created at or after (ISO 8601)
        until (datetime.datetime | None | Unset): Filter: created at or before (ISO 8601)
        limit (int | Unset): Number of versions to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AdminAgentVersionsResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            is_eligible=is_eligible,
            is_discarded=is_discarded,
            miner_hotkey=miner_hotkey,
            suite_id=suite_id,
            since=since,
            until=until,
            limit=limit,
            offset=offset,
        )
    ).parsed
