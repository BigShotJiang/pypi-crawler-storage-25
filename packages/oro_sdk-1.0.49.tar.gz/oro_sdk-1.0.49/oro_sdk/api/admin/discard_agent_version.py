from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_version_not_found_error import AgentVersionNotFoundError
from ...models.discard_request import DiscardRequest
from ...models.discard_response import DiscardResponse
from ...models.http_validation_error import HTTPValidationError
from ...models.no_active_suite_error import NoActiveSuiteError
from ...types import Response


def _get_kwargs(
    agent_version_id: UUID,
    *,
    body: DiscardRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/agent-versions/{agent_version_id}/discard".format(
            agent_version_id=quote(str(agent_version_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError | None:
    if response.status_code == 200:
        response_200 = DiscardResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = AgentVersionNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 503:
        response_503 = NoActiveSuiteError.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DiscardRequest,
) -> Response[AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError]:
    """Discard an agent version from leaderboard

     Discard an agent version from the leaderboard (reversible tombstone).

    Also cancels any active evaluation runs and closes the work item
    to prevent the validator from claiming new work for this version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (DiscardRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DiscardRequest,
) -> AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError | None:
    """Discard an agent version from leaderboard

     Discard an agent version from the leaderboard (reversible tombstone).

    Also cancels any active evaluation runs and closes the work item
    to prevent the validator from claiming new work for this version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (DiscardRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError
    """

    return sync_detailed(
        agent_version_id=agent_version_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DiscardRequest,
) -> Response[AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError]:
    """Discard an agent version from leaderboard

     Discard an agent version from the leaderboard (reversible tombstone).

    Also cancels any active evaluation runs and closes the work item
    to prevent the validator from claiming new work for this version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (DiscardRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: DiscardRequest,
) -> AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError | None:
    """Discard an agent version from leaderboard

     Discard an agent version from the leaderboard (reversible tombstone).

    Also cancels any active evaluation runs and closes the work item
    to prevent the validator from claiming new work for this version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (DiscardRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | DiscardResponse | HTTPValidationError | NoActiveSuiteError
    """

    return (
        await asyncio_detailed(
            agent_version_id=agent_version_id,
            client=client,
            body=body,
        )
    ).parsed
