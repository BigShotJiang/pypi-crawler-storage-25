import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.admin_miners_response import AdminMinersResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    is_banned: bool | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_is_banned: bool | None | Unset
    if isinstance(is_banned, Unset):
        json_is_banned = UNSET
    else:
        json_is_banned = is_banned
    params["is_banned"] = json_is_banned

    json_since: None | str | Unset
    if isinstance(since, Unset):
        json_since = UNSET
    elif isinstance(since, datetime.datetime):
        json_since = since.isoformat()
    else:
        json_since = since
    params["since"] = json_since

    json_until: None | str | Unset
    if isinstance(until, Unset):
        json_until = UNSET
    elif isinstance(until, datetime.datetime):
        json_until = until.isoformat()
    else:
        json_until = until
    params["until"] = json_until

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/miners",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AdminMinersResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AdminMinersResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AdminMinersResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    is_banned: bool | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[AdminMinersResponse | HTTPValidationError]:
    """List miners with ban status and agent count

     List all miners with their ban status, agent count, and last submission time.

    Args:
        is_banned (bool | None | Unset): Filter by ban status
        since (datetime.datetime | None | Unset): Last submitted at or after
        until (datetime.datetime | None | Unset): Last submitted at or before
        limit (int | Unset): Number of miners to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AdminMinersResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        is_banned=is_banned,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    is_banned: bool | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> AdminMinersResponse | HTTPValidationError | None:
    """List miners with ban status and agent count

     List all miners with their ban status, agent count, and last submission time.

    Args:
        is_banned (bool | None | Unset): Filter by ban status
        since (datetime.datetime | None | Unset): Last submitted at or after
        until (datetime.datetime | None | Unset): Last submitted at or before
        limit (int | Unset): Number of miners to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AdminMinersResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        is_banned=is_banned,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    is_banned: bool | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[AdminMinersResponse | HTTPValidationError]:
    """List miners with ban status and agent count

     List all miners with their ban status, agent count, and last submission time.

    Args:
        is_banned (bool | None | Unset): Filter by ban status
        since (datetime.datetime | None | Unset): Last submitted at or after
        until (datetime.datetime | None | Unset): Last submitted at or before
        limit (int | Unset): Number of miners to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AdminMinersResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        is_banned=is_banned,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    is_banned: bool | None | Unset = UNSET,
    since: datetime.datetime | None | Unset = UNSET,
    until: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> AdminMinersResponse | HTTPValidationError | None:
    """List miners with ban status and agent count

     List all miners with their ban status, agent count, and last submission time.

    Args:
        is_banned (bool | None | Unset): Filter by ban status
        since (datetime.datetime | None | Unset): Last submitted at or after
        until (datetime.datetime | None | Unset): Last submitted at or before
        limit (int | Unset): Number of miners to return Default: 50.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AdminMinersResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            is_banned=is_banned,
            since=since,
            until=until,
            limit=limit,
            offset=offset,
        )
    ).parsed
