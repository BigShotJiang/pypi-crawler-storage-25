from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.ban_request import BanRequest
from ...models.ban_response import BanResponse
from ...models.http_validation_error import HTTPValidationError
from ...models.miner_not_found_error import MinerNotFoundError
from ...types import Response


def _get_kwargs(
    miner_hotkey: str,
    *,
    body: BanRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/miners/{miner_hotkey}/ban".format(
            miner_hotkey=quote(str(miner_hotkey), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BanResponse | HTTPValidationError | MinerNotFoundError | None:
    if response.status_code == 200:
        response_200 = BanResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = MinerNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BanResponse | HTTPValidationError | MinerNotFoundError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    miner_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    body: BanRequest,
) -> Response[BanResponse | HTTPValidationError | MinerNotFoundError]:
    """Ban a miner

     Ban a miner from submitting agents.

    Args:
        miner_hotkey (str): Miner hotkey to ban
        body (BanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BanResponse | HTTPValidationError | MinerNotFoundError]
    """

    kwargs = _get_kwargs(
        miner_hotkey=miner_hotkey,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    miner_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    body: BanRequest,
) -> BanResponse | HTTPValidationError | MinerNotFoundError | None:
    """Ban a miner

     Ban a miner from submitting agents.

    Args:
        miner_hotkey (str): Miner hotkey to ban
        body (BanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BanResponse | HTTPValidationError | MinerNotFoundError
    """

    return sync_detailed(
        miner_hotkey=miner_hotkey,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    miner_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    body: BanRequest,
) -> Response[BanResponse | HTTPValidationError | MinerNotFoundError]:
    """Ban a miner

     Ban a miner from submitting agents.

    Args:
        miner_hotkey (str): Miner hotkey to ban
        body (BanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BanResponse | HTTPValidationError | MinerNotFoundError]
    """

    kwargs = _get_kwargs(
        miner_hotkey=miner_hotkey,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    miner_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    body: BanRequest,
) -> BanResponse | HTTPValidationError | MinerNotFoundError | None:
    """Ban a miner

     Ban a miner from submitting agents.

    Args:
        miner_hotkey (str): Miner hotkey to ban
        body (BanRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BanResponse | HTTPValidationError | MinerNotFoundError
    """

    return (
        await asyncio_detailed(
            miner_hotkey=miner_hotkey,
            client=client,
            body=body,
        )
    ).parsed
