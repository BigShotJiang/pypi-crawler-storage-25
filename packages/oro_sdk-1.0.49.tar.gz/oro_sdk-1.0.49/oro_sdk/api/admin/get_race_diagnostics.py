from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.race_diagnostics_response import RaceDiagnosticsResponse
from ...types import Response


def _get_kwargs(
    race_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/races/{race_id}/diagnostics".format(
            race_id=quote(str(race_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | RaceDiagnosticsResponse | None:
    if response.status_code == 200:
        response_200 = RaceDiagnosticsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | RaceDiagnosticsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | RaceDiagnosticsResponse]:
    """Get race diagnostics

     Get detailed diagnostics for a specific race.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RaceDiagnosticsResponse]
    """

    kwargs = _get_kwargs(
        race_id=race_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | RaceDiagnosticsResponse | None:
    """Get race diagnostics

     Get detailed diagnostics for a specific race.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RaceDiagnosticsResponse
    """

    return sync_detailed(
        race_id=race_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | RaceDiagnosticsResponse]:
    """Get race diagnostics

     Get detailed diagnostics for a specific race.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RaceDiagnosticsResponse]
    """

    kwargs = _get_kwargs(
        race_id=race_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    race_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | RaceDiagnosticsResponse | None:
    """Get race diagnostics

     Get detailed diagnostics for a specific race.

    Args:
        race_id (UUID): Race ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RaceDiagnosticsResponse
    """

    return (
        await asyncio_detailed(
            race_id=race_id,
            client=client,
        )
    ).parsed
