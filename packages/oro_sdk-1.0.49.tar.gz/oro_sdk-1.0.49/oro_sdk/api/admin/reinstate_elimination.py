from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_version_not_found_error import AgentVersionNotFoundError
from ...models.http_validation_error import HTTPValidationError
from ...models.no_active_suite_error import NoActiveSuiteError
from ...models.reinstate_elimination_request import ReinstateEliminationRequest
from ...models.reinstate_elimination_response import ReinstateEliminationResponse
from ...types import Response


def _get_kwargs(
    agent_version_id: UUID,
    *,
    body: ReinstateEliminationRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/agent-versions/{agent_version_id}/reinstate-elimination".format(
            agent_version_id=quote(str(agent_version_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse | None:
    if response.status_code == 200:
        response_200 = ReinstateEliminationResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = AgentVersionNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 503:
        response_503 = NoActiveSuiteError.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ReinstateEliminationRequest,
) -> Response[AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse]:
    """Reinstate an agent version that was eliminated after a race

     Clear `eliminated_at` and `eliminated_in_race_id` on the aggregate.

    Use when an agent was eliminated due to a mis-evaluation, scoring bug, or
    operational incident rather than genuine poor performance. The agent will
    re-appear in `_find_scored_qualifiers` on the next qualifying evaluation.

    Idempotent: succeeds even if the aggregate is not currently eliminated.

    Args:
        agent_version_id (UUID): Agent version ID
        body (ReinstateEliminationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ReinstateEliminationRequest,
) -> AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse | None:
    """Reinstate an agent version that was eliminated after a race

     Clear `eliminated_at` and `eliminated_in_race_id` on the aggregate.

    Use when an agent was eliminated due to a mis-evaluation, scoring bug, or
    operational incident rather than genuine poor performance. The agent will
    re-appear in `_find_scored_qualifiers` on the next qualifying evaluation.

    Idempotent: succeeds even if the aggregate is not currently eliminated.

    Args:
        agent_version_id (UUID): Agent version ID
        body (ReinstateEliminationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse
    """

    return sync_detailed(
        agent_version_id=agent_version_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ReinstateEliminationRequest,
) -> Response[AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse]:
    """Reinstate an agent version that was eliminated after a race

     Clear `eliminated_at` and `eliminated_in_race_id` on the aggregate.

    Use when an agent was eliminated due to a mis-evaluation, scoring bug, or
    operational incident rather than genuine poor performance. The agent will
    re-appear in `_find_scored_qualifiers` on the next qualifying evaluation.

    Idempotent: succeeds even if the aggregate is not currently eliminated.

    Args:
        agent_version_id (UUID): Agent version ID
        body (ReinstateEliminationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ReinstateEliminationRequest,
) -> AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse | None:
    """Reinstate an agent version that was eliminated after a race

     Clear `eliminated_at` and `eliminated_in_race_id` on the aggregate.

    Use when an agent was eliminated due to a mis-evaluation, scoring bug, or
    operational incident rather than genuine poor performance. The agent will
    re-appear in `_find_scored_qualifiers` on the next qualifying evaluation.

    Idempotent: succeeds even if the aggregate is not currently eliminated.

    Args:
        agent_version_id (UUID): Agent version ID
        body (ReinstateEliminationRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | HTTPValidationError | NoActiveSuiteError | ReinstateEliminationResponse
    """

    return (
        await asyncio_detailed(
            agent_version_id=agent_version_id,
            client=client,
            body=body,
        )
    ).parsed
