from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.problem_progress_entry import ProblemProgressEntry


T = TypeVar("T", bound="AgentVersionProblemsResponse")


@_attrs_define
class AgentVersionProblemsResponse:
    """
    Attributes:
        agent_version_id (UUID): Agent version ID
        problems (list[ProblemProgressEntry]): Problem progress list
        suite_id (int | None | Unset): Suite ID
    """

    agent_version_id: UUID
    problems: list[ProblemProgressEntry]
    suite_id: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        problems = []
        for problems_item_data in self.problems:
            problems_item = problems_item_data.to_dict()
            problems.append(problems_item)

        suite_id: int | None | Unset
        if isinstance(self.suite_id, Unset):
            suite_id = UNSET
        else:
            suite_id = self.suite_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "problems": problems,
            }
        )
        if suite_id is not UNSET:
            field_dict["suite_id"] = suite_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.problem_progress_entry import ProblemProgressEntry

        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        problems = []
        _problems = d.pop("problems")
        for problems_item_data in _problems:
            problems_item = ProblemProgressEntry.from_dict(problems_item_data)

            problems.append(problems_item)

        def _parse_suite_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        suite_id = _parse_suite_id(d.pop("suite_id", UNSET))

        agent_version_problems_response = cls(
            agent_version_id=agent_version_id,
            problems=problems,
            suite_id=suite_id,
        )

        agent_version_problems_response.additional_properties = d
        return agent_version_problems_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
