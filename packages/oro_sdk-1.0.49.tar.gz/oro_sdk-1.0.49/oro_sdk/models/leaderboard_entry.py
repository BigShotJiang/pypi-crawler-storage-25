from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="LeaderboardEntry")


@_attrs_define
class LeaderboardEntry:
    """
    Attributes:
        rank (int): Leaderboard rank
        agent_version_id (UUID): Agent version ID
        agent_name (str): Agent name
        miner_hotkey (str): Miner hotkey
        version_number (int): Version number within this agent (v1, v2, etc.)
        final_score (float): Final score
        race_score (float | None | Unset): Competitive evaluation score
        eligible_at (datetime.datetime | None | Unset): When eligibility was reached
        is_discarded (bool | Unset): Whether discarded by admin Default: False.
        is_miner_banned (bool | Unset): Whether miner is banned Default: False.
        is_current_top (bool | Unset): Current top agent for emissions Default: False.
        was_top (bool | Unset): Previously held top agent status Default: False.
        top_at (datetime.datetime | None | Unset): When this agent became top
        is_active_qualifier (bool | Unset): True when this version is the active qualifier on its hotkey for the open
            race (covers both the incumbent and the scored qualifier). Default: False.
        outranked_by_agent_version_id (None | Unset | UUID): Set when this version's score qualifies but a higher-
            scoring sibling on the same hotkey is the active qualifier instead.
    """

    rank: int
    agent_version_id: UUID
    agent_name: str
    miner_hotkey: str
    version_number: int
    final_score: float
    race_score: float | None | Unset = UNSET
    eligible_at: datetime.datetime | None | Unset = UNSET
    is_discarded: bool | Unset = False
    is_miner_banned: bool | Unset = False
    is_current_top: bool | Unset = False
    was_top: bool | Unset = False
    top_at: datetime.datetime | None | Unset = UNSET
    is_active_qualifier: bool | Unset = False
    outranked_by_agent_version_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        rank = self.rank

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        version_number = self.version_number

        final_score = self.final_score

        race_score: float | None | Unset
        if isinstance(self.race_score, Unset):
            race_score = UNSET
        else:
            race_score = self.race_score

        eligible_at: None | str | Unset
        if isinstance(self.eligible_at, Unset):
            eligible_at = UNSET
        elif isinstance(self.eligible_at, datetime.datetime):
            eligible_at = self.eligible_at.isoformat()
        else:
            eligible_at = self.eligible_at

        is_discarded = self.is_discarded

        is_miner_banned = self.is_miner_banned

        is_current_top = self.is_current_top

        was_top = self.was_top

        top_at: None | str | Unset
        if isinstance(self.top_at, Unset):
            top_at = UNSET
        elif isinstance(self.top_at, datetime.datetime):
            top_at = self.top_at.isoformat()
        else:
            top_at = self.top_at

        is_active_qualifier = self.is_active_qualifier

        outranked_by_agent_version_id: None | str | Unset
        if isinstance(self.outranked_by_agent_version_id, Unset):
            outranked_by_agent_version_id = UNSET
        elif isinstance(self.outranked_by_agent_version_id, UUID):
            outranked_by_agent_version_id = str(self.outranked_by_agent_version_id)
        else:
            outranked_by_agent_version_id = self.outranked_by_agent_version_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "rank": rank,
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "version_number": version_number,
                "final_score": final_score,
            }
        )
        if race_score is not UNSET:
            field_dict["race_score"] = race_score
        if eligible_at is not UNSET:
            field_dict["eligible_at"] = eligible_at
        if is_discarded is not UNSET:
            field_dict["is_discarded"] = is_discarded
        if is_miner_banned is not UNSET:
            field_dict["is_miner_banned"] = is_miner_banned
        if is_current_top is not UNSET:
            field_dict["is_current_top"] = is_current_top
        if was_top is not UNSET:
            field_dict["was_top"] = was_top
        if top_at is not UNSET:
            field_dict["top_at"] = top_at
        if is_active_qualifier is not UNSET:
            field_dict["is_active_qualifier"] = is_active_qualifier
        if outranked_by_agent_version_id is not UNSET:
            field_dict["outranked_by_agent_version_id"] = outranked_by_agent_version_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        rank = d.pop("rank")

        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        version_number = d.pop("version_number")

        final_score = d.pop("final_score")

        def _parse_race_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        race_score = _parse_race_score(d.pop("race_score", UNSET))

        def _parse_eligible_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                eligible_at_type_0 = isoparse(data)

                return eligible_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        eligible_at = _parse_eligible_at(d.pop("eligible_at", UNSET))

        is_discarded = d.pop("is_discarded", UNSET)

        is_miner_banned = d.pop("is_miner_banned", UNSET)

        is_current_top = d.pop("is_current_top", UNSET)

        was_top = d.pop("was_top", UNSET)

        def _parse_top_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                top_at_type_0 = isoparse(data)

                return top_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        top_at = _parse_top_at(d.pop("top_at", UNSET))

        is_active_qualifier = d.pop("is_active_qualifier", UNSET)

        def _parse_outranked_by_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                outranked_by_agent_version_id_type_0 = UUID(data)

                return outranked_by_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        outranked_by_agent_version_id = _parse_outranked_by_agent_version_id(
            d.pop("outranked_by_agent_version_id", UNSET)
        )

        leaderboard_entry = cls(
            rank=rank,
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            version_number=version_number,
            final_score=final_score,
            race_score=race_score,
            eligible_at=eligible_at,
            is_discarded=is_discarded,
            is_miner_banned=is_miner_banned,
            is_current_top=is_current_top,
            was_top=was_top,
            top_at=top_at,
            is_active_qualifier=is_active_qualifier,
            outranked_by_agent_version_id=outranked_by_agent_version_id,
        )

        leaderboard_entry.additional_properties = d
        return leaderboard_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
