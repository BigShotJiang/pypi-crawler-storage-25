from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="WorkItemStatus")


@_attrs_define
class WorkItemStatus:
    """
    Attributes:
        included_success_count (int): Number of successful runs included so far
        required_successes (int): Number of successful runs required to close the work item
        is_closed (bool): Whether the work item is closed
    """

    included_success_count: int
    required_successes: int
    is_closed: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        included_success_count = self.included_success_count

        required_successes = self.required_successes

        is_closed = self.is_closed

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "included_success_count": included_success_count,
                "required_successes": required_successes,
                "is_closed": is_closed,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        included_success_count = d.pop("included_success_count")

        required_successes = d.pop("required_successes")

        is_closed = d.pop("is_closed")

        work_item_status = cls(
            included_success_count=included_success_count,
            required_successes=required_successes,
            is_closed=is_closed,
        )

        work_item_status.additional_properties = d
        return work_item_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
