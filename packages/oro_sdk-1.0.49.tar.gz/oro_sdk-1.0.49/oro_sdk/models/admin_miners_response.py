from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.admin_miner_entry import AdminMinerEntry


T = TypeVar("T", bound="AdminMinersResponse")


@_attrs_define
class AdminMinersResponse:
    """
    Attributes:
        total (int): Total entries matching filter
        limit (int): Page size
        offset (int): Page offset
        miners (list[AdminMinerEntry]): Miner entries
    """

    total: int
    limit: int
    offset: int
    miners: list[AdminMinerEntry]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        limit = self.limit

        offset = self.offset

        miners = []
        for miners_item_data in self.miners:
            miners_item = miners_item_data.to_dict()
            miners.append(miners_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "limit": limit,
                "offset": offset,
                "miners": miners,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.admin_miner_entry import AdminMinerEntry

        d = dict(src_dict)
        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        miners = []
        _miners = d.pop("miners")
        for miners_item_data in _miners:
            miners_item = AdminMinerEntry.from_dict(miners_item_data)

            miners.append(miners_item)

        admin_miners_response = cls(
            total=total,
            limit=limit,
            offset=offset,
            miners=miners,
        )

        admin_miners_response.additional_properties = d
        return admin_miners_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
