from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="TopHistoryEntry")


@_attrs_define
class TopHistoryEntry:
    """
    Attributes:
        agent_version_id (UUID): Agent version ID
        agent_name (str): Agent name
        miner_hotkey (str): Miner hotkey
        version_number (int): Version number
        final_score (float): Final score
        top_at (datetime.datetime): When this agent became top
        is_current_top (bool): Currently the top agent
        was_top (bool): Previously held top agent status
        suite_id (int): Suite this top status was earned on
    """

    agent_version_id: UUID
    agent_name: str
    miner_hotkey: str
    version_number: int
    final_score: float
    top_at: datetime.datetime
    is_current_top: bool
    was_top: bool
    suite_id: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        version_number = self.version_number

        final_score = self.final_score

        top_at = self.top_at.isoformat()

        is_current_top = self.is_current_top

        was_top = self.was_top

        suite_id = self.suite_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "version_number": version_number,
                "final_score": final_score,
                "top_at": top_at,
                "is_current_top": is_current_top,
                "was_top": was_top,
                "suite_id": suite_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        version_number = d.pop("version_number")

        final_score = d.pop("final_score")

        top_at = isoparse(d.pop("top_at"))

        is_current_top = d.pop("is_current_top")

        was_top = d.pop("was_top")

        suite_id = d.pop("suite_id")

        top_history_entry = cls(
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            version_number=version_number,
            final_score=final_score,
            top_at=top_at,
            is_current_top=is_current_top,
            was_top=was_top,
            suite_id=suite_id,
        )

        top_history_entry.additional_properties = d
        return top_history_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
