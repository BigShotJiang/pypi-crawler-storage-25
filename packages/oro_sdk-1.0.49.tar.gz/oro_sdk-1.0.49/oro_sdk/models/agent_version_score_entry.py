from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AgentVersionScoreEntry")


@_attrs_define
class AgentVersionScoreEntry:
    """
    Attributes:
        validator_hotkey (str): Validator's SS58 hotkey
        score (float): Score assigned by this validator
        run_id (UUID): Evaluation run ID
    """

    validator_hotkey: str
    score: float
    run_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        validator_hotkey = self.validator_hotkey

        score = self.score

        run_id = str(self.run_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validator_hotkey": validator_hotkey,
                "score": score,
                "run_id": run_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        validator_hotkey = d.pop("validator_hotkey")

        score = d.pop("score")

        run_id = UUID(d.pop("run_id"))

        agent_version_score_entry = cls(
            validator_hotkey=validator_hotkey,
            score=score,
            run_id=run_id,
        )

        agent_version_score_entry.additional_properties = d
        return agent_version_score_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
