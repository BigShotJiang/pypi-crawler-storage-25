from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="TopMinerPayoutResponse")


@_attrs_define
class TopMinerPayoutResponse:
    """
    Attributes:
        as_of (datetime.datetime): When this payout estimate was computed
        miner_hotkey (None | str | Unset): Top miner's hotkey
        agent_name (None | str | Unset): Top miner's agent name
        tao_per_day (float | None | Unset): Estimated TAO emitted per day
        usd_per_day (float | None | Unset): Estimated USD equivalent per day
        tao_price_usd (float | None | Unset): TAO/USD price used for USD estimate
    """

    as_of: datetime.datetime
    miner_hotkey: None | str | Unset = UNSET
    agent_name: None | str | Unset = UNSET
    tao_per_day: float | None | Unset = UNSET
    usd_per_day: float | None | Unset = UNSET
    tao_price_usd: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        as_of = self.as_of.isoformat()

        miner_hotkey: None | str | Unset
        if isinstance(self.miner_hotkey, Unset):
            miner_hotkey = UNSET
        else:
            miner_hotkey = self.miner_hotkey

        agent_name: None | str | Unset
        if isinstance(self.agent_name, Unset):
            agent_name = UNSET
        else:
            agent_name = self.agent_name

        tao_per_day: float | None | Unset
        if isinstance(self.tao_per_day, Unset):
            tao_per_day = UNSET
        else:
            tao_per_day = self.tao_per_day

        usd_per_day: float | None | Unset
        if isinstance(self.usd_per_day, Unset):
            usd_per_day = UNSET
        else:
            usd_per_day = self.usd_per_day

        tao_price_usd: float | None | Unset
        if isinstance(self.tao_price_usd, Unset):
            tao_price_usd = UNSET
        else:
            tao_price_usd = self.tao_price_usd

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "as_of": as_of,
            }
        )
        if miner_hotkey is not UNSET:
            field_dict["miner_hotkey"] = miner_hotkey
        if agent_name is not UNSET:
            field_dict["agent_name"] = agent_name
        if tao_per_day is not UNSET:
            field_dict["tao_per_day"] = tao_per_day
        if usd_per_day is not UNSET:
            field_dict["usd_per_day"] = usd_per_day
        if tao_price_usd is not UNSET:
            field_dict["tao_price_usd"] = tao_price_usd

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        as_of = isoparse(d.pop("as_of"))

        def _parse_miner_hotkey(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        miner_hotkey = _parse_miner_hotkey(d.pop("miner_hotkey", UNSET))

        def _parse_agent_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_name = _parse_agent_name(d.pop("agent_name", UNSET))

        def _parse_tao_per_day(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        tao_per_day = _parse_tao_per_day(d.pop("tao_per_day", UNSET))

        def _parse_usd_per_day(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        usd_per_day = _parse_usd_per_day(d.pop("usd_per_day", UNSET))

        def _parse_tao_price_usd(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        tao_price_usd = _parse_tao_price_usd(d.pop("tao_price_usd", UNSET))

        top_miner_payout_response = cls(
            as_of=as_of,
            miner_hotkey=miner_hotkey,
            agent_name=agent_name,
            tao_per_day=tao_per_day,
            usd_per_day=usd_per_day,
            tao_price_usd=tao_price_usd,
        )

        top_miner_payout_response.additional_properties = d
        return top_miner_payout_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
