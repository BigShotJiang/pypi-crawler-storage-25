from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.leaderboard_entry import LeaderboardEntry
    from ..models.suite_public import SuitePublic


T = TypeVar("T", bound="LeaderboardResponse")


@_attrs_define
class LeaderboardResponse:
    """
    Attributes:
        total (int): Total entries matching filter
        limit (int): Page size
        offset (int): Page offset
        suite (SuitePublic):
        entries (list[LeaderboardEntry]): Leaderboard entries
        unique_miners (int): Distinct miner hotkeys on leaderboard
        challenge_threshold (float | None | Unset): Score required to dethrone current top
    """

    total: int
    limit: int
    offset: int
    suite: SuitePublic
    entries: list[LeaderboardEntry]
    unique_miners: int
    challenge_threshold: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        limit = self.limit

        offset = self.offset

        suite = self.suite.to_dict()

        entries = []
        for entries_item_data in self.entries:
            entries_item = entries_item_data.to_dict()
            entries.append(entries_item)

        unique_miners = self.unique_miners

        challenge_threshold: float | None | Unset
        if isinstance(self.challenge_threshold, Unset):
            challenge_threshold = UNSET
        else:
            challenge_threshold = self.challenge_threshold

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "limit": limit,
                "offset": offset,
                "suite": suite,
                "entries": entries,
                "unique_miners": unique_miners,
            }
        )
        if challenge_threshold is not UNSET:
            field_dict["challenge_threshold"] = challenge_threshold

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.leaderboard_entry import LeaderboardEntry
        from ..models.suite_public import SuitePublic

        d = dict(src_dict)
        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        suite = SuitePublic.from_dict(d.pop("suite"))

        entries = []
        _entries = d.pop("entries")
        for entries_item_data in _entries:
            entries_item = LeaderboardEntry.from_dict(entries_item_data)

            entries.append(entries_item)

        unique_miners = d.pop("unique_miners")

        def _parse_challenge_threshold(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        challenge_threshold = _parse_challenge_threshold(d.pop("challenge_threshold", UNSET))

        leaderboard_response = cls(
            total=total,
            limit=limit,
            offset=offset,
            suite=suite,
            entries=entries,
            unique_miners=unique_miners,
            challenge_threshold=challenge_threshold,
        )

        leaderboard_response.additional_properties = d
        return leaderboard_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
