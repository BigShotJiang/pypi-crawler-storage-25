from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_version_score_entry import AgentVersionScoreEntry


T = TypeVar("T", bound="AgentVersionVariance")


@_attrs_define
class AgentVersionVariance:
    """
    Attributes:
        agent_version_id (UUID): Agent version ID
        agent_name (str): Agent name
        miner_hotkey (str): Owner's hotkey
        validator_count (int): Number of validators that scored this version
        avg_score (float): Average score across validators
        min_score (float): Minimum validator score
        max_score (float): Maximum validator score
        spread (float): Spread between min and max scores
        is_high_variance (bool): Whether the variance exceeds the threshold
        eval_work_item_id (None | Unset | UUID): Work item this variance row is computed for
        phase (None | str | Unset): Evaluation phase (QUALIFYING or RACE)
        race_number (int | None | Unset): Race number for RACE-phase work items
        per_validator (list[AgentVersionScoreEntry] | Unset): Per-validator score breakdown
    """

    agent_version_id: UUID
    agent_name: str
    miner_hotkey: str
    validator_count: int
    avg_score: float
    min_score: float
    max_score: float
    spread: float
    is_high_variance: bool
    eval_work_item_id: None | Unset | UUID = UNSET
    phase: None | str | Unset = UNSET
    race_number: int | None | Unset = UNSET
    per_validator: list[AgentVersionScoreEntry] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        validator_count = self.validator_count

        avg_score = self.avg_score

        min_score = self.min_score

        max_score = self.max_score

        spread = self.spread

        is_high_variance = self.is_high_variance

        eval_work_item_id: None | str | Unset
        if isinstance(self.eval_work_item_id, Unset):
            eval_work_item_id = UNSET
        elif isinstance(self.eval_work_item_id, UUID):
            eval_work_item_id = str(self.eval_work_item_id)
        else:
            eval_work_item_id = self.eval_work_item_id

        phase: None | str | Unset
        if isinstance(self.phase, Unset):
            phase = UNSET
        else:
            phase = self.phase

        race_number: int | None | Unset
        if isinstance(self.race_number, Unset):
            race_number = UNSET
        else:
            race_number = self.race_number

        per_validator: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.per_validator, Unset):
            per_validator = []
            for per_validator_item_data in self.per_validator:
                per_validator_item = per_validator_item_data.to_dict()
                per_validator.append(per_validator_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "validator_count": validator_count,
                "avg_score": avg_score,
                "min_score": min_score,
                "max_score": max_score,
                "spread": spread,
                "is_high_variance": is_high_variance,
            }
        )
        if eval_work_item_id is not UNSET:
            field_dict["eval_work_item_id"] = eval_work_item_id
        if phase is not UNSET:
            field_dict["phase"] = phase
        if race_number is not UNSET:
            field_dict["race_number"] = race_number
        if per_validator is not UNSET:
            field_dict["per_validator"] = per_validator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_version_score_entry import AgentVersionScoreEntry

        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        validator_count = d.pop("validator_count")

        avg_score = d.pop("avg_score")

        min_score = d.pop("min_score")

        max_score = d.pop("max_score")

        spread = d.pop("spread")

        is_high_variance = d.pop("is_high_variance")

        def _parse_eval_work_item_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                eval_work_item_id_type_0 = UUID(data)

                return eval_work_item_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        eval_work_item_id = _parse_eval_work_item_id(d.pop("eval_work_item_id", UNSET))

        def _parse_phase(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        phase = _parse_phase(d.pop("phase", UNSET))

        def _parse_race_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        race_number = _parse_race_number(d.pop("race_number", UNSET))

        _per_validator = d.pop("per_validator", UNSET)
        per_validator: list[AgentVersionScoreEntry] | Unset = UNSET
        if _per_validator is not UNSET:
            per_validator = []
            for per_validator_item_data in _per_validator:
                per_validator_item = AgentVersionScoreEntry.from_dict(per_validator_item_data)

                per_validator.append(per_validator_item)

        agent_version_variance = cls(
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            validator_count=validator_count,
            avg_score=avg_score,
            min_score=min_score,
            max_score=max_score,
            spread=spread,
            is_high_variance=is_high_variance,
            eval_work_item_id=eval_work_item_id,
            phase=phase,
            race_number=race_number,
            per_validator=per_validator,
        )

        agent_version_variance.additional_properties = d
        return agent_version_variance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
