from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.agent_version_variance import AgentVersionVariance


T = TypeVar("T", bound="AgentVersionVarianceResponse")


@_attrs_define
class AgentVersionVarianceResponse:
    """
    Attributes:
        agent_versions (list[AgentVersionVariance]): Per-version variance entries
        variance_threshold (float): Threshold used to flag high-variance versions
    """

    agent_versions: list[AgentVersionVariance]
    variance_threshold: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_versions = []
        for agent_versions_item_data in self.agent_versions:
            agent_versions_item = agent_versions_item_data.to_dict()
            agent_versions.append(agent_versions_item)

        variance_threshold = self.variance_threshold

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_versions": agent_versions,
                "variance_threshold": variance_threshold,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_version_variance import AgentVersionVariance

        d = dict(src_dict)
        agent_versions = []
        _agent_versions = d.pop("agent_versions")
        for agent_versions_item_data in _agent_versions:
            agent_versions_item = AgentVersionVariance.from_dict(agent_versions_item_data)

            agent_versions.append(agent_versions_item)

        variance_threshold = d.pop("variance_threshold")

        agent_version_variance_response = cls(
            agent_versions=agent_versions,
            variance_threshold=variance_threshold,
        )

        agent_version_variance_response.additional_properties = d
        return agent_version_variance_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
