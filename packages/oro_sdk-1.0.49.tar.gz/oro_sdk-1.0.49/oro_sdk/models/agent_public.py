from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_latest_version import AgentLatestVersion


T = TypeVar("T", bound="AgentPublic")


@_attrs_define
class AgentPublic:
    """
    Attributes:
        agent_id (UUID): Unique identifier for the agent
        miner_hotkey (str): Owner's hotkey
        agent_name (str): Human-readable name for the agent
        created_at (datetime.datetime): When the agent was created
        latest_version (AgentLatestVersion | None | Unset): Latest version with state and score
    """

    agent_id: UUID
    miner_hotkey: str
    agent_name: str
    created_at: datetime.datetime
    latest_version: AgentLatestVersion | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.agent_latest_version import AgentLatestVersion

        agent_id = str(self.agent_id)

        miner_hotkey = self.miner_hotkey

        agent_name = self.agent_name

        created_at = self.created_at.isoformat()

        latest_version: dict[str, Any] | None | Unset
        if isinstance(self.latest_version, Unset):
            latest_version = UNSET
        elif isinstance(self.latest_version, AgentLatestVersion):
            latest_version = self.latest_version.to_dict()
        else:
            latest_version = self.latest_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_id": agent_id,
                "miner_hotkey": miner_hotkey,
                "agent_name": agent_name,
                "created_at": created_at,
            }
        )
        if latest_version is not UNSET:
            field_dict["latest_version"] = latest_version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_latest_version import AgentLatestVersion

        d = dict(src_dict)
        agent_id = UUID(d.pop("agent_id"))

        miner_hotkey = d.pop("miner_hotkey")

        agent_name = d.pop("agent_name")

        created_at = isoparse(d.pop("created_at"))

        def _parse_latest_version(data: object) -> AgentLatestVersion | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                latest_version_type_0 = AgentLatestVersion.from_dict(data)

                return latest_version_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentLatestVersion | None | Unset, data)

        latest_version = _parse_latest_version(d.pop("latest_version", UNSET))

        agent_public = cls(
            agent_id=agent_id,
            miner_hotkey=miner_hotkey,
            agent_name=agent_name,
            created_at=created_at,
            latest_version=latest_version,
        )

        agent_public.additional_properties = d
        return agent_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
