from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.admin_agent_version_entry import AdminAgentVersionEntry


T = TypeVar("T", bound="AdminAgentVersionsResponse")


@_attrs_define
class AdminAgentVersionsResponse:
    """
    Attributes:
        total (int): Total entries matching filter
        limit (int): Page size
        offset (int): Page offset
        agent_versions (list[AdminAgentVersionEntry]): Agent version entries
    """

    total: int
    limit: int
    offset: int
    agent_versions: list[AdminAgentVersionEntry]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        limit = self.limit

        offset = self.offset

        agent_versions = []
        for agent_versions_item_data in self.agent_versions:
            agent_versions_item = agent_versions_item_data.to_dict()
            agent_versions.append(agent_versions_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "limit": limit,
                "offset": offset,
                "agent_versions": agent_versions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.admin_agent_version_entry import AdminAgentVersionEntry

        d = dict(src_dict)
        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        agent_versions = []
        _agent_versions = d.pop("agent_versions")
        for agent_versions_item_data in _agent_versions:
            agent_versions_item = AdminAgentVersionEntry.from_dict(agent_versions_item_data)

            agent_versions.append(agent_versions_item)

        admin_agent_versions_response = cls(
            total=total,
            limit=limit,
            offset=offset,
            agent_versions=agent_versions,
        )

        admin_agent_versions_response.additional_properties = d
        return admin_agent_versions_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
