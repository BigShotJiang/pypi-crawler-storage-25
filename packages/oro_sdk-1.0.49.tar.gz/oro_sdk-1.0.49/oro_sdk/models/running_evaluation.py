from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.evaluation_run_status import EvaluationRunStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="RunningEvaluation")


@_attrs_define
class RunningEvaluation:
    """
    Attributes:
        eval_run_id (UUID): Unique identifier for this run
        agent_version_id (UUID): Agent version being evaluated
        agent_name (str): Name of the agent
        version_number (int): Version number within this agent (v1, v2, etc.)
        miner_hotkey (str): Miner who owns the agent
        validator_hotkey (str): Validator performing evaluation
        status (EvaluationRunStatus): Status of an evaluation run through its lifecycle.
        started_at (datetime.datetime): When evaluation started
        progress_percent (float | Unset): Percentage of problems completed (0-100) Default: 0.0.
        phase (None | str | Unset): Evaluation phase (QUALIFYING or RACE)
        race_id (None | Unset | UUID): Race ID when phase is RACE
    """

    eval_run_id: UUID
    agent_version_id: UUID
    agent_name: str
    version_number: int
    miner_hotkey: str
    validator_hotkey: str
    status: EvaluationRunStatus
    started_at: datetime.datetime
    progress_percent: float | Unset = 0.0
    phase: None | str | Unset = UNSET
    race_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        eval_run_id = str(self.eval_run_id)

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        version_number = self.version_number

        miner_hotkey = self.miner_hotkey

        validator_hotkey = self.validator_hotkey

        status = self.status.value

        started_at = self.started_at.isoformat()

        progress_percent = self.progress_percent

        phase: None | str | Unset
        if isinstance(self.phase, Unset):
            phase = UNSET
        else:
            phase = self.phase

        race_id: None | str | Unset
        if isinstance(self.race_id, Unset):
            race_id = UNSET
        elif isinstance(self.race_id, UUID):
            race_id = str(self.race_id)
        else:
            race_id = self.race_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "version_number": version_number,
                "miner_hotkey": miner_hotkey,
                "validator_hotkey": validator_hotkey,
                "status": status,
                "started_at": started_at,
            }
        )
        if progress_percent is not UNSET:
            field_dict["progress_percent"] = progress_percent
        if phase is not UNSET:
            field_dict["phase"] = phase
        if race_id is not UNSET:
            field_dict["race_id"] = race_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        version_number = d.pop("version_number")

        miner_hotkey = d.pop("miner_hotkey")

        validator_hotkey = d.pop("validator_hotkey")

        status = EvaluationRunStatus(d.pop("status"))

        started_at = isoparse(d.pop("started_at"))

        progress_percent = d.pop("progress_percent", UNSET)

        def _parse_phase(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        phase = _parse_phase(d.pop("phase", UNSET))

        def _parse_race_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_id_type_0 = UUID(data)

                return race_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        race_id = _parse_race_id(d.pop("race_id", UNSET))

        running_evaluation = cls(
            eval_run_id=eval_run_id,
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            version_number=version_number,
            miner_hotkey=miner_hotkey,
            validator_hotkey=validator_hotkey,
            status=status,
            started_at=started_at,
            progress_percent=progress_percent,
            phase=phase,
            race_id=race_id,
        )

        running_evaluation.additional_properties = d
        return running_evaluation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
