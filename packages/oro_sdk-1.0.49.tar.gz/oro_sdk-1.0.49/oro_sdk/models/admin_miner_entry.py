from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AdminMinerEntry")


@_attrs_define
class AdminMinerEntry:
    """
    Attributes:
        miner_hotkey (str): Miner's SS58 hotkey
        is_banned (bool): Whether the miner is banned
        agent_count (int): Number of agents submitted by this miner
        ban_reason (None | str | Unset): Reason for the ban
        banned_at (datetime.datetime | None | Unset): When the miner was banned
        last_submitted_at (datetime.datetime | None | Unset): When the miner last submitted an agent
        registered_at (datetime.datetime | None | Unset): When the miner registered on-chain
    """

    miner_hotkey: str
    is_banned: bool
    agent_count: int
    ban_reason: None | str | Unset = UNSET
    banned_at: datetime.datetime | None | Unset = UNSET
    last_submitted_at: datetime.datetime | None | Unset = UNSET
    registered_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        miner_hotkey = self.miner_hotkey

        is_banned = self.is_banned

        agent_count = self.agent_count

        ban_reason: None | str | Unset
        if isinstance(self.ban_reason, Unset):
            ban_reason = UNSET
        else:
            ban_reason = self.ban_reason

        banned_at: None | str | Unset
        if isinstance(self.banned_at, Unset):
            banned_at = UNSET
        elif isinstance(self.banned_at, datetime.datetime):
            banned_at = self.banned_at.isoformat()
        else:
            banned_at = self.banned_at

        last_submitted_at: None | str | Unset
        if isinstance(self.last_submitted_at, Unset):
            last_submitted_at = UNSET
        elif isinstance(self.last_submitted_at, datetime.datetime):
            last_submitted_at = self.last_submitted_at.isoformat()
        else:
            last_submitted_at = self.last_submitted_at

        registered_at: None | str | Unset
        if isinstance(self.registered_at, Unset):
            registered_at = UNSET
        elif isinstance(self.registered_at, datetime.datetime):
            registered_at = self.registered_at.isoformat()
        else:
            registered_at = self.registered_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "miner_hotkey": miner_hotkey,
                "is_banned": is_banned,
                "agent_count": agent_count,
            }
        )
        if ban_reason is not UNSET:
            field_dict["ban_reason"] = ban_reason
        if banned_at is not UNSET:
            field_dict["banned_at"] = banned_at
        if last_submitted_at is not UNSET:
            field_dict["last_submitted_at"] = last_submitted_at
        if registered_at is not UNSET:
            field_dict["registered_at"] = registered_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        miner_hotkey = d.pop("miner_hotkey")

        is_banned = d.pop("is_banned")

        agent_count = d.pop("agent_count")

        def _parse_ban_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ban_reason = _parse_ban_reason(d.pop("ban_reason", UNSET))

        def _parse_banned_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                banned_at_type_0 = isoparse(data)

                return banned_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        banned_at = _parse_banned_at(d.pop("banned_at", UNSET))

        def _parse_last_submitted_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_submitted_at_type_0 = isoparse(data)

                return last_submitted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_submitted_at = _parse_last_submitted_at(d.pop("last_submitted_at", UNSET))

        def _parse_registered_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                registered_at_type_0 = isoparse(data)

                return registered_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        registered_at = _parse_registered_at(d.pop("registered_at", UNSET))

        admin_miner_entry = cls(
            miner_hotkey=miner_hotkey,
            is_banned=is_banned,
            agent_count=agent_count,
            ban_reason=ban_reason,
            banned_at=banned_at,
            last_submitted_at=last_submitted_at,
            registered_at=registered_at,
        )

        admin_miner_entry.additional_properties = d
        return admin_miner_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
