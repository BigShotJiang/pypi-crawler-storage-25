from enum import Enum


class EvaluationPhase(str, Enum):
    QUALIFYING = "QUALIFYING"
    RACE = "RACE"

    def __str__(self) -> str:
        return str(self.value)
