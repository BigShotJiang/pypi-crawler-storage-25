from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RaceQualifierPublic")


@_attrs_define
class RaceQualifierPublic:
    """
    Attributes:
        agent_version_id (UUID): Agent version ID
        qualification_type (str): How agent qualified (INCUMBENT or SCORED)
        agent_name (None | str | Unset): Agent name
        miner_hotkey (None | str | Unset): Miner hotkey
        version_number (int | Unset): Version number within this agent Default: 0.
        qualifying_score (float | None | Unset): Score from qualifying
        race_score (float | None | Unset): Score from race phase
        race_rank (int | None | Unset): Rank within the race
    """

    agent_version_id: UUID
    qualification_type: str
    agent_name: None | str | Unset = UNSET
    miner_hotkey: None | str | Unset = UNSET
    version_number: int | Unset = 0
    qualifying_score: float | None | Unset = UNSET
    race_score: float | None | Unset = UNSET
    race_rank: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        qualification_type = self.qualification_type

        agent_name: None | str | Unset
        if isinstance(self.agent_name, Unset):
            agent_name = UNSET
        else:
            agent_name = self.agent_name

        miner_hotkey: None | str | Unset
        if isinstance(self.miner_hotkey, Unset):
            miner_hotkey = UNSET
        else:
            miner_hotkey = self.miner_hotkey

        version_number = self.version_number

        qualifying_score: float | None | Unset
        if isinstance(self.qualifying_score, Unset):
            qualifying_score = UNSET
        else:
            qualifying_score = self.qualifying_score

        race_score: float | None | Unset
        if isinstance(self.race_score, Unset):
            race_score = UNSET
        else:
            race_score = self.race_score

        race_rank: int | None | Unset
        if isinstance(self.race_rank, Unset):
            race_rank = UNSET
        else:
            race_rank = self.race_rank

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "qualification_type": qualification_type,
            }
        )
        if agent_name is not UNSET:
            field_dict["agent_name"] = agent_name
        if miner_hotkey is not UNSET:
            field_dict["miner_hotkey"] = miner_hotkey
        if version_number is not UNSET:
            field_dict["version_number"] = version_number
        if qualifying_score is not UNSET:
            field_dict["qualifying_score"] = qualifying_score
        if race_score is not UNSET:
            field_dict["race_score"] = race_score
        if race_rank is not UNSET:
            field_dict["race_rank"] = race_rank

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        qualification_type = d.pop("qualification_type")

        def _parse_agent_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_name = _parse_agent_name(d.pop("agent_name", UNSET))

        def _parse_miner_hotkey(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        miner_hotkey = _parse_miner_hotkey(d.pop("miner_hotkey", UNSET))

        version_number = d.pop("version_number", UNSET)

        def _parse_qualifying_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        qualifying_score = _parse_qualifying_score(d.pop("qualifying_score", UNSET))

        def _parse_race_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        race_score = _parse_race_score(d.pop("race_score", UNSET))

        def _parse_race_rank(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        race_rank = _parse_race_rank(d.pop("race_rank", UNSET))

        race_qualifier_public = cls(
            agent_version_id=agent_version_id,
            qualification_type=qualification_type,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            version_number=version_number,
            qualifying_score=qualifying_score,
            race_score=race_score,
            race_rank=race_rank,
        )

        race_qualifier_public.additional_properties = d
        return race_qualifier_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
