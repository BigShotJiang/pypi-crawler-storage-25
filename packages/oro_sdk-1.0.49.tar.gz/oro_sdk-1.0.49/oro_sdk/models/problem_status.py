from enum import Enum


class ProblemStatus(str, Enum):
    FAILED = "FAILED"
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SKIPPED = "SKIPPED"
    SUCCESS = "SUCCESS"
    TIMED_OUT = "TIMED_OUT"

    def __str__(self) -> str:
        return str(self.value)
