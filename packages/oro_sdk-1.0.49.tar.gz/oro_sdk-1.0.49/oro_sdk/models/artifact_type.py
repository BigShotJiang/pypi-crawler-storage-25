from enum import Enum


class ArtifactType(str, Enum):
    AGENT_CODE = "AGENT_CODE"
    EVAL_LOGS_BUNDLE = "EVAL_LOGS_BUNDLE"
    EVAL_PROBLEM_LOGS = "EVAL_PROBLEM_LOGS"
    REASONING_DETAILS = "REASONING_DETAILS"

    def __str__(self) -> str:
        return str(self.value)
