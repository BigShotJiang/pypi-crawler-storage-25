from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.admission_reason import AdmissionReason
from ..models.admission_status import AdmissionStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="SubmitAgentResponse")


@_attrs_define
class SubmitAgentResponse:
    """
    Attributes:
        admission_status (AdmissionStatus):
        hotkey (str): Hotkey of the miner who submitted the agent
        agent_id (None | Unset | UUID): Unique identifier for the created agent
        agent_version_id (None | Unset | UUID): Unique identifier for the created agent version
        admission_reason (AdmissionReason | None | Unset): Reason for rejection, if the submission was rejected
        next_allowed_at (datetime.datetime | None | Unset): Earliest time the miner may submit again after cooldown
        message (str | Unset): Human-readable status message Default: 'Agent submitted successfully'.
    """

    admission_status: AdmissionStatus
    hotkey: str
    agent_id: None | Unset | UUID = UNSET
    agent_version_id: None | Unset | UUID = UNSET
    admission_reason: AdmissionReason | None | Unset = UNSET
    next_allowed_at: datetime.datetime | None | Unset = UNSET
    message: str | Unset = "Agent submitted successfully"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        admission_status = self.admission_status.value

        hotkey = self.hotkey

        agent_id: None | str | Unset
        if isinstance(self.agent_id, Unset):
            agent_id = UNSET
        elif isinstance(self.agent_id, UUID):
            agent_id = str(self.agent_id)
        else:
            agent_id = self.agent_id

        agent_version_id: None | str | Unset
        if isinstance(self.agent_version_id, Unset):
            agent_version_id = UNSET
        elif isinstance(self.agent_version_id, UUID):
            agent_version_id = str(self.agent_version_id)
        else:
            agent_version_id = self.agent_version_id

        admission_reason: None | str | Unset
        if isinstance(self.admission_reason, Unset):
            admission_reason = UNSET
        elif isinstance(self.admission_reason, AdmissionReason):
            admission_reason = self.admission_reason.value
        else:
            admission_reason = self.admission_reason

        next_allowed_at: None | str | Unset
        if isinstance(self.next_allowed_at, Unset):
            next_allowed_at = UNSET
        elif isinstance(self.next_allowed_at, datetime.datetime):
            next_allowed_at = self.next_allowed_at.isoformat()
        else:
            next_allowed_at = self.next_allowed_at

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "admission_status": admission_status,
                "hotkey": hotkey,
            }
        )
        if agent_id is not UNSET:
            field_dict["agent_id"] = agent_id
        if agent_version_id is not UNSET:
            field_dict["agent_version_id"] = agent_version_id
        if admission_reason is not UNSET:
            field_dict["admission_reason"] = admission_reason
        if next_allowed_at is not UNSET:
            field_dict["next_allowed_at"] = next_allowed_at
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        admission_status = AdmissionStatus(d.pop("admission_status"))

        hotkey = d.pop("hotkey")

        def _parse_agent_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                agent_id_type_0 = UUID(data)

                return agent_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        agent_id = _parse_agent_id(d.pop("agent_id", UNSET))

        def _parse_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                agent_version_id_type_0 = UUID(data)

                return agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        agent_version_id = _parse_agent_version_id(d.pop("agent_version_id", UNSET))

        def _parse_admission_reason(data: object) -> AdmissionReason | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                admission_reason_type_0 = AdmissionReason(data)

                return admission_reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AdmissionReason | None | Unset, data)

        admission_reason = _parse_admission_reason(d.pop("admission_reason", UNSET))

        def _parse_next_allowed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                next_allowed_at_type_0 = isoparse(data)

                return next_allowed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        next_allowed_at = _parse_next_allowed_at(d.pop("next_allowed_at", UNSET))

        message = d.pop("message", UNSET)

        submit_agent_response = cls(
            admission_status=admission_status,
            hotkey=hotkey,
            agent_id=agent_id,
            agent_version_id=agent_version_id,
            admission_reason=admission_reason,
            next_allowed_at=next_allowed_at,
            message=message,
        )

        submit_agent_response.additional_properties = d
        return submit_agent_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
