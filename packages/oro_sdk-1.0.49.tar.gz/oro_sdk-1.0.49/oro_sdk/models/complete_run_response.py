from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.work_item_status import WorkItemStatus


T = TypeVar("T", bound="CompleteRunResponse")


@_attrs_define
class CompleteRunResponse:
    """
    Attributes:
        eval_run_id (UUID): Evaluation run that was completed
        status (str): Recorded terminal status
        work_item (WorkItemStatus):
        agent_version_became_eligible (bool): Whether this run caused the agent version to become eligible
        final_score (float | None | Unset): Final qualifying score if the version became eligible
    """

    eval_run_id: UUID
    status: str
    work_item: WorkItemStatus
    agent_version_became_eligible: bool
    final_score: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        eval_run_id = str(self.eval_run_id)

        status = self.status

        work_item = self.work_item.to_dict()

        agent_version_became_eligible = self.agent_version_became_eligible

        final_score: float | None | Unset
        if isinstance(self.final_score, Unset):
            final_score = UNSET
        else:
            final_score = self.final_score

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "status": status,
                "work_item": work_item,
                "agent_version_became_eligible": agent_version_became_eligible,
            }
        )
        if final_score is not UNSET:
            field_dict["final_score"] = final_score

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.work_item_status import WorkItemStatus

        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        status = d.pop("status")

        work_item = WorkItemStatus.from_dict(d.pop("work_item"))

        agent_version_became_eligible = d.pop("agent_version_became_eligible")

        def _parse_final_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        final_score = _parse_final_score(d.pop("final_score", UNSET))

        complete_run_response = cls(
            eval_run_id=eval_run_id,
            status=status,
            work_item=work_item,
            agent_version_became_eligible=agent_version_became_eligible,
            final_score=final_score,
        )

        complete_run_response.additional_properties = d
        return complete_run_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
