from enum import Enum


class AgentVersionState(str, Enum):
    CANCELLED = "CANCELLED"
    DISCARDED = "DISCARDED"
    ELIGIBLE = "ELIGIBLE"
    QUEUED = "QUEUED"
    RECEIVED = "RECEIVED"
    RUNNING = "RUNNING"

    def __str__(self) -> str:
        return str(self.value)
