from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ReaperStatsResponse")


@_attrs_define
class ReaperStatsResponse:
    """
    Attributes:
        enabled (bool): Whether the reaper is enabled
        is_running (bool): Whether the reaper is currently running
        runs_reaped_total (int): Total number of runs reaped since startup
        runs_reaped_last_cycle (int): Number of runs reaped in the last cycle
        last_cycle_duration_ms (float): Duration of the last reaper cycle in milliseconds
        error_count (int): Total number of reaper errors
        redis_error_count (int): Total number of Redis-related reaper errors
        interval_seconds (int): Reaper cycle interval in seconds
        last_run_at (datetime.datetime | None | Unset): When the reaper last ran
    """

    enabled: bool
    is_running: bool
    runs_reaped_total: int
    runs_reaped_last_cycle: int
    last_cycle_duration_ms: float
    error_count: int
    redis_error_count: int
    interval_seconds: int
    last_run_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        enabled = self.enabled

        is_running = self.is_running

        runs_reaped_total = self.runs_reaped_total

        runs_reaped_last_cycle = self.runs_reaped_last_cycle

        last_cycle_duration_ms = self.last_cycle_duration_ms

        error_count = self.error_count

        redis_error_count = self.redis_error_count

        interval_seconds = self.interval_seconds

        last_run_at: None | str | Unset
        if isinstance(self.last_run_at, Unset):
            last_run_at = UNSET
        elif isinstance(self.last_run_at, datetime.datetime):
            last_run_at = self.last_run_at.isoformat()
        else:
            last_run_at = self.last_run_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "enabled": enabled,
                "is_running": is_running,
                "runs_reaped_total": runs_reaped_total,
                "runs_reaped_last_cycle": runs_reaped_last_cycle,
                "last_cycle_duration_ms": last_cycle_duration_ms,
                "error_count": error_count,
                "redis_error_count": redis_error_count,
                "interval_seconds": interval_seconds,
            }
        )
        if last_run_at is not UNSET:
            field_dict["last_run_at"] = last_run_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        enabled = d.pop("enabled")

        is_running = d.pop("is_running")

        runs_reaped_total = d.pop("runs_reaped_total")

        runs_reaped_last_cycle = d.pop("runs_reaped_last_cycle")

        last_cycle_duration_ms = d.pop("last_cycle_duration_ms")

        error_count = d.pop("error_count")

        redis_error_count = d.pop("redis_error_count")

        interval_seconds = d.pop("interval_seconds")

        def _parse_last_run_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_run_at_type_0 = isoparse(data)

                return last_run_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_run_at = _parse_last_run_at(d.pop("last_run_at", UNSET))

        reaper_stats_response = cls(
            enabled=enabled,
            is_running=is_running,
            runs_reaped_total=runs_reaped_total,
            runs_reaped_last_cycle=runs_reaped_last_cycle,
            last_cycle_duration_ms=last_cycle_duration_ms,
            error_count=error_count,
            redis_error_count=redis_error_count,
            interval_seconds=interval_seconds,
            last_run_at=last_run_at,
        )

        reaper_stats_response.additional_properties = d
        return reaper_stats_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
