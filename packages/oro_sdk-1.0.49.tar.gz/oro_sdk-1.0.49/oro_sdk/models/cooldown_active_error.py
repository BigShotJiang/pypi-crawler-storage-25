from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CooldownActiveError")


@_attrs_define
class CooldownActiveError:
    """429 - Cooldown period is active.

    Attributes:
        detail (str): Error message describing what went wrong
        remaining_seconds (int): Seconds remaining until cooldown expires
        error_code (Literal['COOLDOWN_ACTIVE'] | Unset): Error code for programmatic handling Default:
            'COOLDOWN_ACTIVE'.
    """

    detail: str
    remaining_seconds: int
    error_code: Literal["COOLDOWN_ACTIVE"] | Unset = "COOLDOWN_ACTIVE"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        detail = self.detail

        remaining_seconds = self.remaining_seconds

        error_code = self.error_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "detail": detail,
                "remaining_seconds": remaining_seconds,
            }
        )
        if error_code is not UNSET:
            field_dict["error_code"] = error_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        detail = d.pop("detail")

        remaining_seconds = d.pop("remaining_seconds")

        error_code = cast(Literal["COOLDOWN_ACTIVE"] | Unset, d.pop("error_code", UNSET))
        if error_code != "COOLDOWN_ACTIVE" and not isinstance(error_code, Unset):
            raise ValueError(f"error_code must match const 'COOLDOWN_ACTIVE', got '{error_code}'")

        cooldown_active_error = cls(
            detail=detail,
            remaining_seconds=remaining_seconds,
            error_code=error_code,
        )

        cooldown_active_error.additional_properties = d
        return cooldown_active_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
