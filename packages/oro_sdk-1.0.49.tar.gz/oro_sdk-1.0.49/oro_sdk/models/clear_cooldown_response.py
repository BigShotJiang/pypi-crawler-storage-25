from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ClearCooldownResponse")


@_attrs_define
class ClearCooldownResponse:
    """
    Attributes:
        cleared (bool): Whether the cooldown was cleared
        hotkey (None | str | Unset): Hotkey whose cooldown was cleared
        seconds_remaining_was (int | None | Unset): Seconds remaining on the cooldown before clearing
        message (None | str | Unset): Human-readable status message
    """

    cleared: bool
    hotkey: None | str | Unset = UNSET
    seconds_remaining_was: int | None | Unset = UNSET
    message: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        cleared = self.cleared

        hotkey: None | str | Unset
        if isinstance(self.hotkey, Unset):
            hotkey = UNSET
        else:
            hotkey = self.hotkey

        seconds_remaining_was: int | None | Unset
        if isinstance(self.seconds_remaining_was, Unset):
            seconds_remaining_was = UNSET
        else:
            seconds_remaining_was = self.seconds_remaining_was

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "cleared": cleared,
            }
        )
        if hotkey is not UNSET:
            field_dict["hotkey"] = hotkey
        if seconds_remaining_was is not UNSET:
            field_dict["seconds_remaining_was"] = seconds_remaining_was
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        cleared = d.pop("cleared")

        def _parse_hotkey(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hotkey = _parse_hotkey(d.pop("hotkey", UNSET))

        def _parse_seconds_remaining_was(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        seconds_remaining_was = _parse_seconds_remaining_was(d.pop("seconds_remaining_was", UNSET))

        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))

        clear_cooldown_response = cls(
            cleared=cleared,
            hotkey=hotkey,
            seconds_remaining_was=seconds_remaining_was,
            message=message,
        )

        clear_cooldown_response.additional_properties = d
        return clear_cooldown_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
