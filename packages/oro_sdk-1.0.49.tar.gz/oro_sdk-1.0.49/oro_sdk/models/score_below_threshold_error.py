from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ScoreBelowThresholdError")


@_attrs_define
class ScoreBelowThresholdError:
    """400 - Candidate score does not exceed the challenge threshold.

    Attributes:
        detail (str): Error message describing what went wrong
        candidate_score (float): Score of the candidate agent
        required_score (float): Minimum score required to dethrone the current top
        current_top_score (float): Score of the current top agent
        margin (float): Current challenge margin fraction
        error_code (Literal['SCORE_BELOW_THRESHOLD'] | Unset): Error code for programmatic handling Default:
            'SCORE_BELOW_THRESHOLD'.
    """

    detail: str
    candidate_score: float
    required_score: float
    current_top_score: float
    margin: float
    error_code: Literal["SCORE_BELOW_THRESHOLD"] | Unset = "SCORE_BELOW_THRESHOLD"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        detail = self.detail

        candidate_score = self.candidate_score

        required_score = self.required_score

        current_top_score = self.current_top_score

        margin = self.margin

        error_code = self.error_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "detail": detail,
                "candidate_score": candidate_score,
                "required_score": required_score,
                "current_top_score": current_top_score,
                "margin": margin,
            }
        )
        if error_code is not UNSET:
            field_dict["error_code"] = error_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        detail = d.pop("detail")

        candidate_score = d.pop("candidate_score")

        required_score = d.pop("required_score")

        current_top_score = d.pop("current_top_score")

        margin = d.pop("margin")

        error_code = cast(Literal["SCORE_BELOW_THRESHOLD"] | Unset, d.pop("error_code", UNSET))
        if error_code != "SCORE_BELOW_THRESHOLD" and not isinstance(error_code, Unset):
            raise ValueError(f"error_code must match const 'SCORE_BELOW_THRESHOLD', got '{error_code}'")

        score_below_threshold_error = cls(
            detail=detail,
            candidate_score=candidate_score,
            required_score=required_score,
            current_top_score=current_top_score,
            margin=margin,
            error_code=error_code,
        )

        score_below_threshold_error.additional_properties = d
        return score_below_threshold_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
