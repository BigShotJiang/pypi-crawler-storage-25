from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_problem_result import ValidatorProblemResult


T = TypeVar("T", bound="ProblemProgressEntry")


@_attrs_define
class ProblemProgressEntry:
    """
    Attributes:
        problem_id (UUID): Problem ID
        category (None | str | Unset): Problem category
        phase (None | str | Unset): Evaluation phase: QUALIFYING or RACE
        race_id (None | Unset | UUID): Race ID when phase is RACE
        validator_results (list[ValidatorProblemResult] | Unset): Results from each validator that evaluated this
            problem
    """

    problem_id: UUID
    category: None | str | Unset = UNSET
    phase: None | str | Unset = UNSET
    race_id: None | Unset | UUID = UNSET
    validator_results: list[ValidatorProblemResult] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        problem_id = str(self.problem_id)

        category: None | str | Unset
        if isinstance(self.category, Unset):
            category = UNSET
        else:
            category = self.category

        phase: None | str | Unset
        if isinstance(self.phase, Unset):
            phase = UNSET
        else:
            phase = self.phase

        race_id: None | str | Unset
        if isinstance(self.race_id, Unset):
            race_id = UNSET
        elif isinstance(self.race_id, UUID):
            race_id = str(self.race_id)
        else:
            race_id = self.race_id

        validator_results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.validator_results, Unset):
            validator_results = []
            for validator_results_item_data in self.validator_results:
                validator_results_item = validator_results_item_data.to_dict()
                validator_results.append(validator_results_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "problem_id": problem_id,
            }
        )
        if category is not UNSET:
            field_dict["category"] = category
        if phase is not UNSET:
            field_dict["phase"] = phase
        if race_id is not UNSET:
            field_dict["race_id"] = race_id
        if validator_results is not UNSET:
            field_dict["validator_results"] = validator_results

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_problem_result import ValidatorProblemResult

        d = dict(src_dict)
        problem_id = UUID(d.pop("problem_id"))

        def _parse_category(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        category = _parse_category(d.pop("category", UNSET))

        def _parse_phase(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        phase = _parse_phase(d.pop("phase", UNSET))

        def _parse_race_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_id_type_0 = UUID(data)

                return race_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        race_id = _parse_race_id(d.pop("race_id", UNSET))

        _validator_results = d.pop("validator_results", UNSET)
        validator_results: list[ValidatorProblemResult] | Unset = UNSET
        if _validator_results is not UNSET:
            validator_results = []
            for validator_results_item_data in _validator_results:
                validator_results_item = ValidatorProblemResult.from_dict(validator_results_item_data)

                validator_results.append(validator_results_item)

        problem_progress_entry = cls(
            problem_id=problem_id,
            category=category,
            phase=phase,
            race_id=race_id,
            validator_results=validator_results,
        )

        problem_progress_entry.additional_properties = d
        return problem_progress_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
