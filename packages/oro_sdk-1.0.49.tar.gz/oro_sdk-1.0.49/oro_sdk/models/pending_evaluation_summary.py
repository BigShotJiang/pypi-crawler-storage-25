from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="PendingEvaluationSummary")


@_attrs_define
class PendingEvaluationSummary:
    """
    Attributes:
        total_pending (int): Number of open work items
        total_runs_needed (int): Sum of remaining runs across all items
        total_runs_active (int): Sum of active runs across all items
        projected_completion_at (datetime.datetime | None | Unset): Projected UTC timestamp when the queue will fully
            drain. Null when the queue is empty, no validators are currently active, or there is insufficient evaluation
            history to project.
    """

    total_pending: int
    total_runs_needed: int
    total_runs_active: int
    projected_completion_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_pending = self.total_pending

        total_runs_needed = self.total_runs_needed

        total_runs_active = self.total_runs_active

        projected_completion_at: None | str | Unset
        if isinstance(self.projected_completion_at, Unset):
            projected_completion_at = UNSET
        elif isinstance(self.projected_completion_at, datetime.datetime):
            projected_completion_at = self.projected_completion_at.isoformat()
        else:
            projected_completion_at = self.projected_completion_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total_pending": total_pending,
                "total_runs_needed": total_runs_needed,
                "total_runs_active": total_runs_active,
            }
        )
        if projected_completion_at is not UNSET:
            field_dict["projected_completion_at"] = projected_completion_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_pending = d.pop("total_pending")

        total_runs_needed = d.pop("total_runs_needed")

        total_runs_active = d.pop("total_runs_active")

        def _parse_projected_completion_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                projected_completion_at_type_0 = isoparse(data)

                return projected_completion_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        projected_completion_at = _parse_projected_completion_at(d.pop("projected_completion_at", UNSET))

        pending_evaluation_summary = cls(
            total_pending=total_pending,
            total_runs_needed=total_runs_needed,
            total_runs_active=total_runs_active,
            projected_completion_at=projected_completion_at,
        )

        pending_evaluation_summary.additional_properties = d
        return pending_evaluation_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
