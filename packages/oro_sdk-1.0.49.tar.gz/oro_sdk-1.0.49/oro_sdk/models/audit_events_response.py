from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.audit_event_entry import AuditEventEntry


T = TypeVar("T", bound="AuditEventsResponse")


@_attrs_define
class AuditEventsResponse:
    """
    Attributes:
        total (int): Total entries matching filter
        limit (int): Page size
        offset (int): Page offset
        events (list[AuditEventEntry]): Audit event entries
    """

    total: int
    limit: int
    offset: int
    events: list[AuditEventEntry]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        limit = self.limit

        offset = self.offset

        events = []
        for events_item_data in self.events:
            events_item = events_item_data.to_dict()
            events.append(events_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "limit": limit,
                "offset": offset,
                "events": events,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_event_entry import AuditEventEntry

        d = dict(src_dict)
        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        events = []
        _events = d.pop("events")
        for events_item_data in _events:
            events_item = AuditEventEntry.from_dict(events_item_data)

            events.append(events_item)

        audit_events_response = cls(
            total=total,
            limit=limit,
            offset=offset,
            events=events,
        )

        audit_events_response.additional_properties = d
        return audit_events_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
