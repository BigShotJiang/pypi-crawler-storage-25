from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="CloseQualifyingResponse")


@_attrs_define
class CloseQualifyingResponse:
    """
    Attributes:
        race_id (UUID): Race ID
        previous_closes_at (datetime.datetime): Original qualifying close time
        new_closes_at (datetime.datetime): New qualifying close time
        status (str): Race status after closing qualifying
    """

    race_id: UUID
    previous_closes_at: datetime.datetime
    new_closes_at: datetime.datetime
    status: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        race_id = str(self.race_id)

        previous_closes_at = self.previous_closes_at.isoformat()

        new_closes_at = self.new_closes_at.isoformat()

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "race_id": race_id,
                "previous_closes_at": previous_closes_at,
                "new_closes_at": new_closes_at,
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        race_id = UUID(d.pop("race_id"))

        previous_closes_at = isoparse(d.pop("previous_closes_at"))

        new_closes_at = isoparse(d.pop("new_closes_at"))

        status = d.pop("status")

        close_qualifying_response = cls(
            race_id=race_id,
            previous_closes_at=previous_closes_at,
            new_closes_at=new_closes_at,
            status=status,
        )

        close_qualifying_response.additional_properties = d
        return close_qualifying_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
