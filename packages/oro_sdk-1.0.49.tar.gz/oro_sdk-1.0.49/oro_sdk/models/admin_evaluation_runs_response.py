from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.admin_evaluation_run_entry import AdminEvaluationRunEntry


T = TypeVar("T", bound="AdminEvaluationRunsResponse")


@_attrs_define
class AdminEvaluationRunsResponse:
    """
    Attributes:
        total (int): Total entries matching filter
        limit (int): Page size
        offset (int): Page offset
        evaluation_runs (list[AdminEvaluationRunEntry]): Evaluation run entries
    """

    total: int
    limit: int
    offset: int
    evaluation_runs: list[AdminEvaluationRunEntry]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        limit = self.limit

        offset = self.offset

        evaluation_runs = []
        for evaluation_runs_item_data in self.evaluation_runs:
            evaluation_runs_item = evaluation_runs_item_data.to_dict()
            evaluation_runs.append(evaluation_runs_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "limit": limit,
                "offset": offset,
                "evaluation_runs": evaluation_runs,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.admin_evaluation_run_entry import AdminEvaluationRunEntry

        d = dict(src_dict)
        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        evaluation_runs = []
        _evaluation_runs = d.pop("evaluation_runs")
        for evaluation_runs_item_data in _evaluation_runs:
            evaluation_runs_item = AdminEvaluationRunEntry.from_dict(evaluation_runs_item_data)

            evaluation_runs.append(evaluation_runs_item)

        admin_evaluation_runs_response = cls(
            total=total,
            limit=limit,
            offset=offset,
            evaluation_runs=evaluation_runs,
        )

        admin_evaluation_runs_response.additional_properties = d
        return admin_evaluation_runs_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
