from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.problem_progress_update import ProblemProgressUpdate


T = TypeVar("T", bound="ProgressUpdateRequest")


@_attrs_define
class ProgressUpdateRequest:
    """
    Attributes:
        problems (list[ProblemProgressUpdate]): Per-problem progress updates
    """

    problems: list[ProblemProgressUpdate]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        problems = []
        for problems_item_data in self.problems:
            problems_item = problems_item_data.to_dict()
            problems.append(problems_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "problems": problems,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.problem_progress_update import ProblemProgressUpdate

        d = dict(src_dict)
        problems = []
        _problems = d.pop("problems")
        for problems_item_data in _problems:
            problems_item = ProblemProgressUpdate.from_dict(problems_item_data)

            problems.append(problems_item)

        progress_update_request = cls(
            problems=problems,
        )

        progress_update_request.additional_properties = d
        return progress_update_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
