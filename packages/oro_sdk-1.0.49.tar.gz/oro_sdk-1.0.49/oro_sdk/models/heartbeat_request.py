from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.heartbeat_request_service_versions_type_0 import HeartbeatRequestServiceVersionsType0


T = TypeVar("T", bound="HeartbeatRequest")


@_attrs_define
class HeartbeatRequest:
    """
    Attributes:
        service_versions (HeartbeatRequestServiceVersionsType0 | None | Unset): Docker image digests for validator stack
            services
    """

    service_versions: HeartbeatRequestServiceVersionsType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.heartbeat_request_service_versions_type_0 import HeartbeatRequestServiceVersionsType0

        service_versions: dict[str, Any] | None | Unset
        if isinstance(self.service_versions, Unset):
            service_versions = UNSET
        elif isinstance(self.service_versions, HeartbeatRequestServiceVersionsType0):
            service_versions = self.service_versions.to_dict()
        else:
            service_versions = self.service_versions

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if service_versions is not UNSET:
            field_dict["service_versions"] = service_versions

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.heartbeat_request_service_versions_type_0 import HeartbeatRequestServiceVersionsType0

        d = dict(src_dict)

        def _parse_service_versions(data: object) -> HeartbeatRequestServiceVersionsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                service_versions_type_0 = HeartbeatRequestServiceVersionsType0.from_dict(data)

                return service_versions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(HeartbeatRequestServiceVersionsType0 | None | Unset, data)

        service_versions = _parse_service_versions(d.pop("service_versions", UNSET))

        heartbeat_request = cls(
            service_versions=service_versions,
        )

        heartbeat_request.additional_properties = d
        return heartbeat_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
