from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.top_history_entry import TopHistoryEntry


T = TypeVar("T", bound="TopHistoryResponse")


@_attrs_define
class TopHistoryResponse:
    """
    Attributes:
        suite_id (int): Suite ID
        entries (list[TopHistoryEntry]): Top agent history entries
    """

    suite_id: int
    entries: list[TopHistoryEntry]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        suite_id = self.suite_id

        entries = []
        for entries_item_data in self.entries:
            entries_item = entries_item_data.to_dict()
            entries.append(entries_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "suite_id": suite_id,
                "entries": entries,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.top_history_entry import TopHistoryEntry

        d = dict(src_dict)
        suite_id = d.pop("suite_id")

        entries = []
        _entries = d.pop("entries")
        for entries_item_data in _entries:
            entries_item = TopHistoryEntry.from_dict(entries_item_data)

            entries.append(entries_item)

        top_history_response = cls(
            suite_id=suite_id,
            entries=entries,
        )

        top_history_response.additional_properties = d
        return top_history_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
