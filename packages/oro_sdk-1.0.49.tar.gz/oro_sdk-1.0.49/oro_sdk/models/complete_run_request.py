from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.terminal_status import TerminalStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.complete_run_request_sandbox_metadata_type_0 import CompleteRunRequestSandboxMetadataType0
    from ..models.complete_run_request_score_components_type_0 import CompleteRunRequestScoreComponentsType0


T = TypeVar("T", bound="CompleteRunRequest")


@_attrs_define
class CompleteRunRequest:
    """Sent by the validator when an evaluation run finishes.

    Attributes:
        terminal_status (TerminalStatus):
        validator_score (float | None | Unset): Aggregate score computed by the validator
        score_components (CompleteRunRequestScoreComponentsType0 | None | Unset): Detailed score component breakdown
        results_s3_key (None | str | Unset): S3 key for the uploaded results bundle
        failure_reason (None | str | Unset): Human-readable failure reason
        sandbox_metadata (CompleteRunRequestSandboxMetadataType0 | None | Unset): Metadata about the sandbox environment
            used
    """

    terminal_status: TerminalStatus
    validator_score: float | None | Unset = UNSET
    score_components: CompleteRunRequestScoreComponentsType0 | None | Unset = UNSET
    results_s3_key: None | str | Unset = UNSET
    failure_reason: None | str | Unset = UNSET
    sandbox_metadata: CompleteRunRequestSandboxMetadataType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.complete_run_request_sandbox_metadata_type_0 import CompleteRunRequestSandboxMetadataType0
        from ..models.complete_run_request_score_components_type_0 import CompleteRunRequestScoreComponentsType0

        terminal_status = self.terminal_status.value

        validator_score: float | None | Unset
        if isinstance(self.validator_score, Unset):
            validator_score = UNSET
        else:
            validator_score = self.validator_score

        score_components: dict[str, Any] | None | Unset
        if isinstance(self.score_components, Unset):
            score_components = UNSET
        elif isinstance(self.score_components, CompleteRunRequestScoreComponentsType0):
            score_components = self.score_components.to_dict()
        else:
            score_components = self.score_components

        results_s3_key: None | str | Unset
        if isinstance(self.results_s3_key, Unset):
            results_s3_key = UNSET
        else:
            results_s3_key = self.results_s3_key

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        sandbox_metadata: dict[str, Any] | None | Unset
        if isinstance(self.sandbox_metadata, Unset):
            sandbox_metadata = UNSET
        elif isinstance(self.sandbox_metadata, CompleteRunRequestSandboxMetadataType0):
            sandbox_metadata = self.sandbox_metadata.to_dict()
        else:
            sandbox_metadata = self.sandbox_metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "terminal_status": terminal_status,
            }
        )
        if validator_score is not UNSET:
            field_dict["validator_score"] = validator_score
        if score_components is not UNSET:
            field_dict["score_components"] = score_components
        if results_s3_key is not UNSET:
            field_dict["results_s3_key"] = results_s3_key
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if sandbox_metadata is not UNSET:
            field_dict["sandbox_metadata"] = sandbox_metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.complete_run_request_sandbox_metadata_type_0 import CompleteRunRequestSandboxMetadataType0
        from ..models.complete_run_request_score_components_type_0 import CompleteRunRequestScoreComponentsType0

        d = dict(src_dict)
        terminal_status = TerminalStatus(d.pop("terminal_status"))

        def _parse_validator_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        validator_score = _parse_validator_score(d.pop("validator_score", UNSET))

        def _parse_score_components(data: object) -> CompleteRunRequestScoreComponentsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                score_components_type_0 = CompleteRunRequestScoreComponentsType0.from_dict(data)

                return score_components_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CompleteRunRequestScoreComponentsType0 | None | Unset, data)

        score_components = _parse_score_components(d.pop("score_components", UNSET))

        def _parse_results_s3_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        results_s3_key = _parse_results_s3_key(d.pop("results_s3_key", UNSET))

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))

        def _parse_sandbox_metadata(data: object) -> CompleteRunRequestSandboxMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                sandbox_metadata_type_0 = CompleteRunRequestSandboxMetadataType0.from_dict(data)

                return sandbox_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CompleteRunRequestSandboxMetadataType0 | None | Unset, data)

        sandbox_metadata = _parse_sandbox_metadata(d.pop("sandbox_metadata", UNSET))

        complete_run_request = cls(
            terminal_status=terminal_status,
            validator_score=validator_score,
            score_components=score_components,
            results_s3_key=results_s3_key,
            failure_reason=failure_reason,
            sandbox_metadata=sandbox_metadata,
        )

        complete_run_request.additional_properties = d
        return complete_run_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
