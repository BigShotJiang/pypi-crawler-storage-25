from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_public import AgentPublic


T = TypeVar("T", bound="MinerAgentsResponse")


@_attrs_define
class MinerAgentsResponse:
    """
    Attributes:
        agents (list[AgentPublic]): List of agents owned by the miner
        can_submit (bool): Whether the miner is currently allowed to submit a new agent
        next_allowed_at (datetime.datetime | None | Unset): Earliest time the miner may submit again, if on cooldown
    """

    agents: list[AgentPublic]
    can_submit: bool
    next_allowed_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agents = []
        for agents_item_data in self.agents:
            agents_item = agents_item_data.to_dict()
            agents.append(agents_item)

        can_submit = self.can_submit

        next_allowed_at: None | str | Unset
        if isinstance(self.next_allowed_at, Unset):
            next_allowed_at = UNSET
        elif isinstance(self.next_allowed_at, datetime.datetime):
            next_allowed_at = self.next_allowed_at.isoformat()
        else:
            next_allowed_at = self.next_allowed_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agents": agents,
                "can_submit": can_submit,
            }
        )
        if next_allowed_at is not UNSET:
            field_dict["next_allowed_at"] = next_allowed_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_public import AgentPublic

        d = dict(src_dict)
        agents = []
        _agents = d.pop("agents")
        for agents_item_data in _agents:
            agents_item = AgentPublic.from_dict(agents_item_data)

            agents.append(agents_item)

        can_submit = d.pop("can_submit")

        def _parse_next_allowed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                next_allowed_at_type_0 = isoparse(data)

                return next_allowed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        next_allowed_at = _parse_next_allowed_at(d.pop("next_allowed_at", UNSET))

        miner_agents_response = cls(
            agents=agents,
            can_submit=can_submit,
            next_allowed_at=next_allowed_at,
        )

        miner_agents_response.additional_properties = d
        return miner_agents_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
