from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.evaluation_run_status import EvaluationRunStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.evaluation_run_detail_sandbox_metadata_type_0 import EvaluationRunDetailSandboxMetadataType0
    from ..models.evaluation_run_detail_score_components_summary_type_0 import (
        EvaluationRunDetailScoreComponentsSummaryType0,
    )


T = TypeVar("T", bound="EvaluationRunDetail")


@_attrs_define
class EvaluationRunDetail:
    """
    Attributes:
        eval_run_id (UUID): Unique identifier for this run
        agent_version_id (UUID): Agent version being evaluated
        agent_name (str): Name of the agent
        validator_hotkey (str): Validator performing evaluation
        status (EvaluationRunStatus): Status of an evaluation run through its lifecycle.
        version_number (int): Version number within this agent (v1, v2, etc.)
        claimed_at (datetime.datetime): When the run was claimed
        score (float | None | Unset): Score if completed successfully
        completed_at (datetime.datetime | None | Unset): When the run completed
        failure_reason (None | str | Unset): Validator-reported failure reason
        is_included (bool | Unset): Whether run is included in aggregate scoring Default: True.
        invalidated_at (datetime.datetime | None | Unset): When run was invalidated
        invalidation_reason (None | str | Unset): Reason for invalidation
        sandbox_metadata (EvaluationRunDetailSandboxMetadataType0 | None | Unset): Sandbox execution details
        score_components_summary (EvaluationRunDetailScoreComponentsSummaryType0 | None | Unset): Score breakdown
            including reasoning details
    """

    eval_run_id: UUID
    agent_version_id: UUID
    agent_name: str
    validator_hotkey: str
    status: EvaluationRunStatus
    version_number: int
    claimed_at: datetime.datetime
    score: float | None | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    failure_reason: None | str | Unset = UNSET
    is_included: bool | Unset = True
    invalidated_at: datetime.datetime | None | Unset = UNSET
    invalidation_reason: None | str | Unset = UNSET
    sandbox_metadata: EvaluationRunDetailSandboxMetadataType0 | None | Unset = UNSET
    score_components_summary: EvaluationRunDetailScoreComponentsSummaryType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.evaluation_run_detail_sandbox_metadata_type_0 import EvaluationRunDetailSandboxMetadataType0
        from ..models.evaluation_run_detail_score_components_summary_type_0 import (
            EvaluationRunDetailScoreComponentsSummaryType0,
        )

        eval_run_id = str(self.eval_run_id)

        agent_version_id = str(self.agent_version_id)

        agent_name = self.agent_name

        validator_hotkey = self.validator_hotkey

        status = self.status.value

        version_number = self.version_number

        claimed_at = self.claimed_at.isoformat()

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        is_included = self.is_included

        invalidated_at: None | str | Unset
        if isinstance(self.invalidated_at, Unset):
            invalidated_at = UNSET
        elif isinstance(self.invalidated_at, datetime.datetime):
            invalidated_at = self.invalidated_at.isoformat()
        else:
            invalidated_at = self.invalidated_at

        invalidation_reason: None | str | Unset
        if isinstance(self.invalidation_reason, Unset):
            invalidation_reason = UNSET
        else:
            invalidation_reason = self.invalidation_reason

        sandbox_metadata: dict[str, Any] | None | Unset
        if isinstance(self.sandbox_metadata, Unset):
            sandbox_metadata = UNSET
        elif isinstance(self.sandbox_metadata, EvaluationRunDetailSandboxMetadataType0):
            sandbox_metadata = self.sandbox_metadata.to_dict()
        else:
            sandbox_metadata = self.sandbox_metadata

        score_components_summary: dict[str, Any] | None | Unset
        if isinstance(self.score_components_summary, Unset):
            score_components_summary = UNSET
        elif isinstance(self.score_components_summary, EvaluationRunDetailScoreComponentsSummaryType0):
            score_components_summary = self.score_components_summary.to_dict()
        else:
            score_components_summary = self.score_components_summary

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "agent_version_id": agent_version_id,
                "agent_name": agent_name,
                "validator_hotkey": validator_hotkey,
                "status": status,
                "version_number": version_number,
                "claimed_at": claimed_at,
            }
        )
        if score is not UNSET:
            field_dict["score"] = score
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if is_included is not UNSET:
            field_dict["is_included"] = is_included
        if invalidated_at is not UNSET:
            field_dict["invalidated_at"] = invalidated_at
        if invalidation_reason is not UNSET:
            field_dict["invalidation_reason"] = invalidation_reason
        if sandbox_metadata is not UNSET:
            field_dict["sandbox_metadata"] = sandbox_metadata
        if score_components_summary is not UNSET:
            field_dict["score_components_summary"] = score_components_summary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.evaluation_run_detail_sandbox_metadata_type_0 import EvaluationRunDetailSandboxMetadataType0
        from ..models.evaluation_run_detail_score_components_summary_type_0 import (
            EvaluationRunDetailScoreComponentsSummaryType0,
        )

        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_name = d.pop("agent_name")

        validator_hotkey = d.pop("validator_hotkey")

        status = EvaluationRunStatus(d.pop("status"))

        version_number = d.pop("version_number")

        claimed_at = isoparse(d.pop("claimed_at"))

        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))

        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))

        is_included = d.pop("is_included", UNSET)

        def _parse_invalidated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                invalidated_at_type_0 = isoparse(data)

                return invalidated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        invalidated_at = _parse_invalidated_at(d.pop("invalidated_at", UNSET))

        def _parse_invalidation_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        invalidation_reason = _parse_invalidation_reason(d.pop("invalidation_reason", UNSET))

        def _parse_sandbox_metadata(data: object) -> EvaluationRunDetailSandboxMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                sandbox_metadata_type_0 = EvaluationRunDetailSandboxMetadataType0.from_dict(data)

                return sandbox_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EvaluationRunDetailSandboxMetadataType0 | None | Unset, data)

        sandbox_metadata = _parse_sandbox_metadata(d.pop("sandbox_metadata", UNSET))

        def _parse_score_components_summary(
            data: object,
        ) -> EvaluationRunDetailScoreComponentsSummaryType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                score_components_summary_type_0 = EvaluationRunDetailScoreComponentsSummaryType0.from_dict(data)

                return score_components_summary_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EvaluationRunDetailScoreComponentsSummaryType0 | None | Unset, data)

        score_components_summary = _parse_score_components_summary(d.pop("score_components_summary", UNSET))

        evaluation_run_detail = cls(
            eval_run_id=eval_run_id,
            agent_version_id=agent_version_id,
            agent_name=agent_name,
            validator_hotkey=validator_hotkey,
            status=status,
            version_number=version_number,
            claimed_at=claimed_at,
            score=score,
            completed_at=completed_at,
            failure_reason=failure_reason,
            is_included=is_included,
            invalidated_at=invalidated_at,
            invalidation_reason=invalidation_reason,
            sandbox_metadata=sandbox_metadata,
            score_components_summary=score_components_summary,
        )

        evaluation_run_detail.additional_properties = d
        return evaluation_run_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
