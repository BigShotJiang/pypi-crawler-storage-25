from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="BanResponse")


@_attrs_define
class BanResponse:
    """
    Attributes:
        hotkey (str): Hotkey of the banned/unbanned entity
        is_banned (bool): Current ban status after the operation
    """

    hotkey: str
    is_banned: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        hotkey = self.hotkey

        is_banned = self.is_banned

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hotkey": hotkey,
                "is_banned": is_banned,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        hotkey = d.pop("hotkey")

        is_banned = d.pop("is_banned")

        ban_response = cls(
            hotkey=hotkey,
            is_banned=is_banned,
        )

        ban_response.additional_properties = d
        return ban_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
