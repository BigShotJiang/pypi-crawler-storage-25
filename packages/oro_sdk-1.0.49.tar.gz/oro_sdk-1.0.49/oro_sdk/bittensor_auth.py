"""Bittensor wallet authentication for ORO SDK.

Delegates SR25519 signing to the ``bittensor-auth`` package and wraps
with ORO-specific public-endpoint detection and retry transports.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import httpx
from attrs import define, field

from bittensor_auth import (
    generate_auth_headers as _pkg_generate_auth_headers,
)
from bittensor_auth.signing import MessageBuilder

from .retry import AsyncRetryTransport, RetryConfig, RetryTransport

if TYPE_CHECKING:
    from bittensor_wallet import Wallet


def is_public_endpoint(url: str | None) -> bool:
    """Check if a URL path is an unauthenticated ORO endpoint.

    Uses exact prefix matching (not substring) to avoid false positives
    on paths that happen to contain ``/v1/public/`` as a segment.
    """
    if not url:
        return False
    try:
        pathname = urlparse(url).path or url
    except Exception:
        pathname = url

    return (
        pathname.startswith("/v1/public/")
        or pathname.startswith("/v1/auth/")
        or pathname == "/health"
        or pathname.endswith("/health")
    )


def generate_auth_headers(
    wallet: Wallet,
    nonce: str | None = None,
    *,
    message_builder: MessageBuilder | None = None,
) -> dict[str, str]:
    """Generate authentication headers for a Bittensor wallet.

    Delegates to ``bittensor_auth.generate_auth_headers`` with the
    wallet's hotkey as the signer.
    """
    return _pkg_generate_auth_headers(
        wallet,
        nonce,
        message_builder=message_builder,
    )


class SigningTransport(httpx.BaseTransport):
    """httpx transport that signs non-public requests with a Bittensor wallet."""

    def __init__(
        self,
        wallet: Wallet,
        wrapped: httpx.BaseTransport | None = None,
        *,
        message_builder: MessageBuilder | None = None,
    ):
        self._wallet = wallet
        self._wrapped = wrapped or httpx.HTTPTransport(
            http2=False,
            retries=1,
            limits=httpx.Limits(
                max_connections=10,
                max_keepalive_connections=5,
                keepalive_expiry=30,
            ),
        )
        self._message_builder = message_builder

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        if not is_public_endpoint(str(request.url)):
            headers = _pkg_generate_auth_headers(
                self._wallet, message_builder=self._message_builder,
            )
            for key, value in headers.items():
                request.headers[key] = value
        return self._wrapped.handle_request(request)


class AsyncSigningTransport(httpx.AsyncBaseTransport):
    """Async httpx transport that signs non-public requests with a Bittensor wallet."""

    def __init__(
        self,
        wallet: Wallet,
        wrapped: httpx.AsyncBaseTransport | None = None,
        *,
        message_builder: MessageBuilder | None = None,
    ):
        self._wallet = wallet
        self._wrapped = wrapped or httpx.AsyncHTTPTransport(
            http2=False,
            retries=1,
            limits=httpx.Limits(
                max_connections=10,
                max_keepalive_connections=5,
                keepalive_expiry=30,
            ),
        )
        self._message_builder = message_builder

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        if not is_public_endpoint(str(request.url)):
            headers = _pkg_generate_auth_headers(
                self._wallet, message_builder=self._message_builder,
            )
            for key, value in headers.items():
                request.headers[key] = value
        return await self._wrapped.handle_async_request(request)


@define
class BittensorAuthClient:
    """HTTP client that signs requests with a Bittensor wallet.

    Compatible with the generated API functions. Wraps signing transports
    with retry logic.

    Example:
        >>> from bittensor_wallet import Wallet
        >>> from oro_sdk import BittensorAuthClient
        >>> from oro_sdk.api.validator import claim_work
        >>>
        >>> wallet = Wallet(name="validator", hotkey="default")
        >>> client = BittensorAuthClient(
        ...     base_url="https://api.oro.ai",
        ...     wallet=wallet,
        ... )
        >>> work = claim_work.sync(client=client)
    """

    _base_url: str = field(alias="base_url")
    _wallet: Wallet = field(alias="wallet")
    _timeout: httpx.Timeout | None = field(default=None, kw_only=True, alias="timeout")
    _verify_ssl: bool = field(default=True, kw_only=True, alias="verify_ssl")
    _headers: dict[str, str] = field(factory=dict, kw_only=True, alias="headers")
    _retry_config: RetryConfig = field(factory=RetryConfig, kw_only=True, alias="retry_config")
    _message_builder: MessageBuilder | None = field(default=None, kw_only=True, alias="message_builder")
    _client: httpx.Client | None = field(default=None, init=False)
    _async_client: httpx.AsyncClient | None = field(default=None, init=False)

    raise_on_unexpected_status: bool = field(default=False, kw_only=True)

    def get_httpx_client(self) -> httpx.Client:
        if self._client is None:
            signing = SigningTransport(
                self._wallet, message_builder=self._message_builder,
            )
            transport = RetryTransport(self._retry_config, wrapped=signing)
            self._client = httpx.Client(
                base_url=self._base_url,
                timeout=self._timeout,
                verify=self._verify_ssl,
                headers=self._headers,
                transport=transport,
            )
        return self._client

    def get_async_httpx_client(self) -> httpx.AsyncClient:
        if self._async_client is None:
            signing = AsyncSigningTransport(
                self._wallet, message_builder=self._message_builder,
            )
            transport = AsyncRetryTransport(self._retry_config, wrapped=signing)
            self._async_client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=self._timeout,
                verify=self._verify_ssl,
                headers=self._headers,
                transport=transport,
            )
        return self._async_client

    def __enter__(self) -> BittensorAuthClient:
        self.get_httpx_client().__enter__()
        return self

    def __exit__(self, *args: Any, **kwargs: Any) -> None:
        self.get_httpx_client().__exit__(*args, **kwargs)

    async def __aenter__(self) -> BittensorAuthClient:
        await self.get_async_httpx_client().__aenter__()
        return self

    async def __aexit__(self, *args: Any, **kwargs: Any) -> None:
        await self.get_async_httpx_client().__aexit__(*args, **kwargs)
