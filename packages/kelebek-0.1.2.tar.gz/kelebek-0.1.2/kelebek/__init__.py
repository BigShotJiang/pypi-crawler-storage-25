def merhaba():
    print("Kütüphane başarıyla yüklendi! Merhaba!")

# Paket import edildiğinde bu fonksiyonun otomatik çalışmasını istersen:
merhaba()
