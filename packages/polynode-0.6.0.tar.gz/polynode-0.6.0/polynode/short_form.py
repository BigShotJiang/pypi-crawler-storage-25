"""Auto-rotating stream for Polymarket short-form crypto markets."""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime
from typing import Any, Callable
from zoneinfo import ZoneInfo

import httpx

from .types.events import PolyNodeEvent
from .types.short_form import (
    RotationEvent,
    ShortFormCoin,
    ShortFormInterval,
    ShortFormMarket,
)

ALL_COINS: list[ShortFormCoin] = ["btc", "eth", "sol", "xrp", "doge", "hype", "bnb"]

COIN_FULL_NAMES: dict[ShortFormCoin, str] = {
    "btc": "bitcoin",
    "eth": "ethereum",
    "sol": "solana",
    "xrp": "xrp",
    "doge": "dogecoin",
    "hype": "hype",
    "bnb": "bnb",
}

COIN_SYMBOLS: dict[ShortFormCoin, str] = {
    "btc": "BTC", "eth": "ETH", "sol": "SOL", "xrp": "XRP",
    "doge": "DOGE", "hype": "HYPE", "bnb": "BNB",
}

INTERVAL_VARIANT: dict[ShortFormInterval, str] = {
    "5m": "five", "15m": "fifteen", "1h": "sixty",
}

WINDOW_SECONDS: dict[ShortFormInterval, int] = {
    "5m": 300, "15m": 900, "1h": 3600,
}

DEFAULT_API_BASE = "https://api.polynode.dev"
DEFAULT_ROTATION_BUFFER = 3
DISCOVERY_RETRIES = 3
DISCOVERY_RETRY_DELAY = 2.0


class ShortFormStream:
    """Auto-rotating stream for Polymarket short-form crypto markets."""

    def __init__(
        self,
        ws: Any,
        interval: ShortFormInterval,
        *,
        coins: list[ShortFormCoin] | None = None,
        api_base_url: str | None = None,
        rotation_buffer: int = DEFAULT_ROTATION_BUFFER,
    ) -> None:
        self._ws = ws
        self.interval = interval
        self.coins: list[ShortFormCoin] = coins or list(ALL_COINS)
        self._api_base = (api_base_url or DEFAULT_API_BASE).rstrip("/")
        self._rotation_buffer = rotation_buffer
        self._handlers: dict[str, set[Callable]] = {}
        self._sub = None
        self._markets: list[ShortFormMarket] = []
        self._rotation_task: asyncio.Task | None = None
        self._rotating = False
        self._stopped = False

    def on(self, type: str, handler: Callable) -> ShortFormStream:
        if type not in self._handlers:
            self._handlers[type] = set()
        self._handlers[type].add(handler)
        return self

    def off(self, type: str, handler: Callable) -> ShortFormStream:
        if type in self._handlers:
            self._handlers[type].discard(handler)
        return self

    @property
    def markets(self) -> list[ShortFormMarket]:
        return self._markets

    @property
    def time_remaining(self) -> int:
        if not self._markets:
            return 0
        window_end = max(m.window_end for m in self._markets)
        return max(0, window_end - int(time.time()))

    async def start(self) -> None:
        if self._stopped:
            return
        self._ws.on_reconnect(lambda _: asyncio.ensure_future(self._rotate()) if not self._stopped else None)
        await self._rotate()

    def stop(self) -> None:
        self._stopped = True
        if self._rotation_task and not self._rotation_task.done():
            self._rotation_task.cancel()
        if self._sub:
            self._sub.unsubscribe()
            self._sub = None

    async def _rotate(self) -> None:
        if self._stopped or self._rotating:
            return
        self._rotating = True

        try:
            if self._sub:
                self._sub.unsubscribe()
                self._sub = None

            markets = await self._discover_markets()
            if self._stopped:
                return

            self._markets = markets

            if not markets:
                self._emit("error", Exception(f"No markets found for {self.interval}"))
                self._schedule_rotation()
                return

            slugs = [m.slug for m in markets]
            sub = await self._ws.subscribe("settlements").slugs(slugs).status("all").send()

            if self._stopped:
                sub.unsubscribe()
                return

            self._sub = sub
            sub.on("*", lambda event: (self._emit(event.event_type, event), self._emit("*", event)))

            window_end = max(m.window_end for m in markets)
            window_start = min(m.window_start for m in markets)
            self._emit("rotation", RotationEvent(
                interval=self.interval,
                markets=markets,
                window_start=window_start,
                window_end=window_end,
                time_remaining=max(0, window_end - int(time.time())),
            ))

            self._schedule_rotation(window_end)
        except Exception as e:
            self._emit("error", e)
            if not self._stopped:
                self._rotation_task = asyncio.ensure_future(self._delayed_rotate(self._rotation_buffer))
        finally:
            self._rotating = False

    async def _delayed_rotate(self, delay: float) -> None:
        await asyncio.sleep(delay)
        await self._rotate()

    def _schedule_rotation(self, window_end: int | None = None) -> None:
        if self._rotation_task and not self._rotation_task.done():
            self._rotation_task.cancel()
        end = window_end or self._compute_window_end()
        delay = max((end - int(time.time()) + self._rotation_buffer), 1)
        self._rotation_task = asyncio.ensure_future(self._delayed_rotate(delay))

    def _compute_window_end(self) -> int:
        now = int(time.time())
        w = WINDOW_SECONDS[self.interval]
        return (now // w) * w + w

    async def _discover_markets(self) -> list[ShortFormMarket]:
        results: list[ShortFormMarket] = []
        async with httpx.AsyncClient(timeout=5.0) as http:
            tasks = [self._discover_coin(http, coin) for coin in self.coins]
            for coro in asyncio.as_completed(tasks):
                market = await coro
                if market:
                    results.append(market)
            # Fetch price-to-beat in parallel
            ptb_tasks = [self._fetch_price_to_beat(http, m) for m in results]
            prices = await asyncio.gather(*ptb_tasks, return_exceptions=True)
            for m, p in zip(results, prices):
                if isinstance(p, (int, float)):
                    m.price_to_beat = p
        return results

    async def _discover_coin(self, http: httpx.AsyncClient, coin: ShortFormCoin) -> ShortFormMarket | None:
        for attempt in range(DISCOVERY_RETRIES):
            try:
                url = self._build_discovery_url(coin)
                resp = await http.get(url)
                if not resp.is_success:
                    if attempt < DISCOVERY_RETRIES - 1:
                        await asyncio.sleep(DISCOVERY_RETRY_DELAY)
                        continue
                    return None
                data = resp.json()
                if not data:
                    if attempt < DISCOVERY_RETRIES - 1:
                        await asyncio.sleep(DISCOVERY_RETRY_DELAY)
                        continue
                    return None
                return self._parse_gamma_event(coin, data[0])
            except Exception:
                if attempt < DISCOVERY_RETRIES - 1:
                    await asyncio.sleep(DISCOVERY_RETRY_DELAY)
        return None

    def _build_discovery_url(self, coin: ShortFormCoin) -> str:
        if self.interval == "1h":
            slug = _build_hourly_slug(coin)
            return f"{self._api_base}/proxy/gamma/events?slug={slug}"
        w = WINDOW_SECONDS[self.interval]
        now = int(time.time())
        ts = (now // w) * w
        slug = f"{coin}-updown-{self.interval}-{ts}"
        return f"{self._api_base}/proxy/gamma/events?slug={slug}"

    async def _fetch_price_to_beat(self, http: httpx.AsyncClient, market: ShortFormMarket) -> float | None:
        try:
            symbol = COIN_SYMBOLS[market.coin]
            variant = INTERVAL_VARIANT[self.interval]
            start_time = datetime.fromtimestamp(market.window_start).isoformat() + "Z"
            end_date = datetime.fromtimestamp(market.window_end).isoformat() + "Z"
            url = (
                f"{self._api_base}/proxy/polymarket/api/crypto/crypto-price"
                f"?symbol={symbol}&eventStartTime={start_time}&variant={variant}&endDate={end_date}"
            )
            resp = await http.get(url)
            if not resp.is_success:
                return None
            data = resp.json()
            return data.get("openPrice")
        except Exception:
            return None

    def _parse_gamma_event(self, coin: ShortFormCoin, event: dict) -> ShortFormMarket | None:
        market = (event.get("markets") or [{}])[0] if event.get("markets") else None
        if not market:
            return None

        outcomes = _safe_json_parse(market.get("outcomes"), [])
        raw_prices = [float(p) for p in _safe_json_parse(market.get("outcomePrices"), [])]
        clob_token_ids = _safe_json_parse(market.get("clobTokenIds"), [])

        up_odds = 0.5
        down_odds = 0.5
        for i, label in enumerate(outcomes):
            price = raw_prices[i] if i < len(raw_prices) else 0
            if "up" in label.lower():
                up_odds = price
            if "down" in label.lower():
                down_odds = price

        slug = event.get("slug", "")
        if self.interval == "1h":
            now = int(time.time())
            window_start = (now // 3600) * 3600
            window_end = window_start + 3600
            if event.get("endDate"):
                window_end = int(datetime.fromisoformat(event["endDate"].replace("Z", "+00:00")).timestamp())
                window_start = window_end - 3600
        else:
            w = WINDOW_SECONDS[self.interval]
            parts = slug.split("-")
            slug_ts = int(parts[-1]) if parts and parts[-1].isdigit() else 0
            window_start = slug_ts or (int(time.time()) // w) * w
            window_end = window_start + w

        return ShortFormMarket(
            coin=coin,
            slug=slug,
            title=event.get("title", ""),
            condition_id=market.get("conditionId", ""),
            window_start=window_start,
            window_end=window_end,
            outcomes=outcomes,
            outcome_prices=raw_prices,
            clob_token_ids=clob_token_ids,
            up_odds=up_odds,
            down_odds=down_odds,
            liquidity=float(market.get("liquidity", 0)),
            volume_24h=float(market.get("volume24hr") or market.get("volume") or 0),
            price_to_beat=None,
        )

    def _emit(self, type: str, data: Any) -> None:
        handlers = self._handlers.get(type)
        if handlers:
            for h in handlers:
                h(data)


def _build_hourly_slug(coin: ShortFormCoin) -> str:
    et = ZoneInfo("America/New_York")
    now = datetime.now(et)
    month = now.strftime("%B").lower()
    day = str(now.day)
    year = str(now.year)
    hour = now.strftime("%I").lstrip("0") or "12"
    ampm = now.strftime("%p").lower()
    coin_name = COIN_FULL_NAMES[coin]
    return f"{coin_name}-up-or-down-{month}-{day}-{year}-{hour}{ampm}-et"


def _safe_json_parse(value: Any, fallback: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return fallback
    if isinstance(value, list):
        return value
    return fallback
