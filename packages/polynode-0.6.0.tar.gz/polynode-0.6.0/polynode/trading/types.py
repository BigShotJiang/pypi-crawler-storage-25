"""Trading module type definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Literal, Protocol, runtime_checkable


class SignatureType(IntEnum):
    EOA = 0
    POLY_PROXY = 1
    POLY_GNOSIS_SAFE = 2


@runtime_checkable
class RouterSigner(Protocol):
    async def get_address(self) -> str: ...
    async def sign_typed_data(self, payload: Eip712Payload) -> str: ...


@dataclass
class Eip712Payload:
    domain: dict[str, Any]
    types: dict[str, Any]
    primary_type: str
    message: dict[str, Any]


@dataclass
class GeneratedWallet:
    private_key: str
    address: str


@dataclass
class TraderConfig:
    polynode_key: str = ""
    db_path: str = "./polynode-trading.db"
    cosigner_url: str = "https://trade.polynode.dev"
    fallback_direct: bool = True
    default_signature_type: SignatureType = SignatureType.POLY_GNOSIS_SAFE
    rpc_url: str = "https://polygon-bor-rpc.publicnode.com"


@dataclass
class ReadyStatus:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    safe_deployed: bool
    approvals_set: bool
    credentials_stored: bool
    credentials: dict[str, str]
    actions: list[str]


@dataclass
class LinkResult:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    credentials: dict[str, str]


@dataclass
class WalletInfo:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    credentials: dict[str, str]
    created_at: float


@dataclass
class WalletExport:
    wallet: str
    funder_address: str
    signature_type: SignatureType
    credentials: dict[str, str]
    safe_deployed: bool
    approvals_set: bool
    created_at: float


@dataclass
class ApprovalStatus:
    funder_address: str
    usdc: dict[str, bool]
    ctf: dict[str, bool]
    all_approved: bool


@dataclass
class BalanceInfo:
    funder_address: str
    usdc: str
    usdc_raw: str
    matic: str


OrderSide = Literal["BUY", "SELL"]
OrderType = Literal["GTC", "GTD", "FOK", "FAK"]


@dataclass
class OrderParams:
    token_id: str
    side: OrderSide
    price: float
    size: float
    type: OrderType = "GTC"
    expiration: int | None = None
    post_only: bool = False


@dataclass
class OrderResult:
    success: bool
    order_id: str | None = None
    status: str | None = None
    error: str | None = None
    making_amount: str | None = None
    taking_amount: str | None = None


@dataclass
class CancelResult:
    canceled: list[str] = field(default_factory=list)
    not_canceled: dict[str, str] = field(default_factory=dict)


@dataclass
class OpenOrder:
    id: str
    market: str
    asset_id: str
    side: str
    price: str
    original_size: str
    size_matched: str
    status: str
    created_at: str
    order_type: str


@dataclass
class MarketMeta:
    token_id: str
    tick_size: str
    fee_rate_bps: int
    neg_risk: bool
    fetched_at: float


@dataclass
class OrderHistoryRow:
    id: int
    wallet_address: str
    order_id: str | None
    token_id: str
    side: str
    price: float
    size: float
    order_type: str
    status: str
    error_msg: str | None
    response_json: str | None
    created_at: float


@dataclass
class HistoryParams:
    limit: int | None = None
    offset: int | None = None
    token_id: str | None = None
    side: OrderSide | None = None


@dataclass
class StoredCredentials:
    wallet_address: str
    funder_address: str | None
    api_key: str
    api_secret: str
    api_passphrase: str
    signature_type: SignatureType
    safe_deployed: bool
    approvals_set: bool
    created_at: float
    updated_at: float
