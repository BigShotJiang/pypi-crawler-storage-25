"""Onboarding logic for Safe deployment, wallet type detection, approvals, and CLOB credentials."""

from __future__ import annotations

from typing import Any

import httpx

from .constants import (
    CHAIN_ID,
    CLOB_HOST,
    CTF,
    CTF_EXCHANGE,
    NEG_RISK_ADAPTER,
    NEG_RISK_CTF_EXCHANGE,
    PROXY_FACTORY,
    PROXY_INIT_CODE_HASH,
    RELAYER_HOST,
    SAFE_FACTORY,
    SAFE_INIT_CODE_HASH,
    SPENDERS,
    USDC,
)
from .types import ApprovalStatus, BalanceInfo, SignatureType


def derive_safe_address(eoa: str) -> str:
    """Derive the CREATE2 Safe address for an EOA."""
    try:
        from eth_abi import encode
        from eth_utils import keccak, to_checksum_address
    except ImportError:
        raise ImportError("eth-account/web3 required. Install with: pip install polynode[trading]")

    eoa_lower = eoa.lower()
    if eoa_lower.startswith("0x"):
        eoa_lower = eoa_lower[2:]

    # Salt = keccak256(abi.encode(["address"], [eoa]))
    encoded = encode(["address"], [eoa])
    salt = keccak(encoded)

    factory_bytes = bytes.fromhex(SAFE_FACTORY[2:])
    init_code_hash = bytes.fromhex(SAFE_INIT_CODE_HASH[2:])

    addr_bytes = keccak(b"\xff" + factory_bytes + salt + init_code_hash)
    return to_checksum_address("0x" + addr_bytes[-20:].hex())


def derive_proxy_address(eoa: str) -> str:
    """Derive the CREATE2 Proxy address for an EOA."""
    try:
        from eth_abi.packed import encode_packed
        from eth_utils import keccak, to_checksum_address
    except ImportError:
        raise ImportError("eth-account/web3 required. Install with: pip install polynode[trading]")

    # Salt = keccak256(encodePacked(["address"], [eoa]))
    packed = encode_packed(["address"], [eoa])
    salt = keccak(packed)

    factory_bytes = bytes.fromhex(PROXY_FACTORY[2:])
    init_code_hash = bytes.fromhex(PROXY_INIT_CODE_HASH[2:])

    addr_bytes = keccak(b"\xff" + factory_bytes + salt + init_code_hash)
    return to_checksum_address("0x" + addr_bytes[-20:].hex())


async def derive_funder_address(eoa: str, sig_type: SignatureType) -> str:
    """Derive the funder address based on signature type."""
    if sig_type == SignatureType.POLY_GNOSIS_SAFE:
        return derive_safe_address(eoa)
    elif sig_type == SignatureType.POLY_PROXY:
        return derive_proxy_address(eoa)
    return eoa


async def detect_wallet_type(eoa: str) -> dict:
    """Auto-detect if a Safe or Proxy is deployed for this EOA."""
    safe_addr = derive_safe_address(eoa)
    proxy_addr = derive_proxy_address(eoa)

    async with httpx.AsyncClient(timeout=10.0) as http:
        # Check Safe first (most common)
        try:
            resp = await http.get(f"{RELAYER_HOST}/deployed?owner={eoa}&salt={eoa}")
            if resp.is_success:
                data = resp.json()
                if data.get("deployed"):
                    return {
                        "signature_type": SignatureType.POLY_GNOSIS_SAFE,
                        "funder_address": safe_addr,
                    }
        except Exception:
            pass

        # Check Proxy
        try:
            resp = await http.get(f"{RELAYER_HOST}/deployed?owner={eoa}&salt={eoa}&type=proxy")
            if resp.is_success:
                data = resp.json()
                if data.get("deployed"):
                    return {
                        "signature_type": SignatureType.POLY_PROXY,
                        "funder_address": proxy_addr,
                    }
        except Exception:
            pass

    # Neither deployed — default to Safe
    return {
        "signature_type": SignatureType.POLY_GNOSIS_SAFE,
        "funder_address": safe_addr,
    }


async def is_safe_deployed(funder_address: str) -> bool:
    """Check if a Safe/Proxy is deployed at the given address."""
    async with httpx.AsyncClient(timeout=10.0) as http:
        try:
            resp = await http.get(f"{RELAYER_HOST}/deployed?address={funder_address}")
            if resp.is_success:
                return resp.json().get("deployed", False)
        except Exception:
            pass
    return False


async def check_approvals(funder_address: str, rpc_url: str) -> ApprovalStatus:
    """Check token approvals for all spender contracts."""
    try:
        from web3 import Web3
    except ImportError:
        raise ImportError("web3 required. Install with: pip install polynode[trading]")

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    erc20_abi = [{"inputs": [{"name": "owner", "type": "address"}, {"name": "spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"}]
    erc1155_abi = [{"inputs": [{"name": "account", "type": "address"}, {"name": "operator", "type": "address"}], "name": "isApprovedForAll", "outputs": [{"name": "", "type": "bool"}], "stateMutability": "view", "type": "function"}]

    usdc_contract = w3.eth.contract(address=Web3.to_checksum_address(USDC), abi=erc20_abi)
    ctf_contract = w3.eth.contract(address=Web3.to_checksum_address(CTF), abi=erc1155_abi)

    funder = Web3.to_checksum_address(funder_address)
    max_uint = 2**256 - 1
    threshold = max_uint // 2

    usdc_status = {}
    ctf_status = {}
    for spender, name in [(CTF_EXCHANGE, "ctf_exchange"), (NEG_RISK_CTF_EXCHANGE, "neg_risk_ctf_exchange"), (NEG_RISK_ADAPTER, "neg_risk_adapter")]:
        spender_addr = Web3.to_checksum_address(spender)
        allowance = usdc_contract.functions.allowance(funder, spender_addr).call()
        usdc_status[name] = allowance >= threshold
        approved = ctf_contract.functions.isApprovedForAll(funder, spender_addr).call()
        ctf_status[name] = approved

    all_approved = all(usdc_status.values()) and all(ctf_status.values())

    return ApprovalStatus(
        funder_address=funder_address,
        usdc=usdc_status,
        ctf=ctf_status,
        all_approved=all_approved,
    )


async def check_balance(funder_address: str, rpc_url: str) -> BalanceInfo:
    """Check USDC and MATIC balance."""
    try:
        from web3 import Web3
    except ImportError:
        raise ImportError("web3 required. Install with: pip install polynode[trading]")

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    erc20_abi = [{"inputs": [{"name": "account", "type": "address"}], "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"}]

    usdc_contract = w3.eth.contract(address=Web3.to_checksum_address(USDC), abi=erc20_abi)
    funder = Web3.to_checksum_address(funder_address)

    usdc_raw = usdc_contract.functions.balanceOf(funder).call()
    matic_raw = w3.eth.get_balance(funder)

    return BalanceInfo(
        funder_address=funder_address,
        usdc=f"{usdc_raw / 1_000_000:.2f}",
        usdc_raw=str(usdc_raw),
        matic=f"{matic_raw / 10**18:.4f}",
    )


async def _build_l1_headers(signer: Any, _funder_address: str) -> dict[str, str]:
    """Build L1 auth headers for the Polymarket CLOB API.

    Uses the signer's EOA address (not Safe/Proxy funder) for both POLY_ADDRESS
    and the EIP-712 message, matching the official py-clob-client and TS SDK.
    """
    from .types import Eip712Payload

    timestamp = str(int(__import__("time").time()))
    nonce = 0
    eoa_address = signer.address  # EOA, not funder

    payload = Eip712Payload(
        domain={
            "name": "ClobAuthDomain",
            "version": "1",
            "chainId": CHAIN_ID,
        },
        types={
            "ClobAuth": [
                {"name": "address", "type": "address"},
                {"name": "timestamp", "type": "string"},
                {"name": "nonce", "type": "uint256"},
                {"name": "message", "type": "string"},
            ],
        },
        primary_type="ClobAuth",
        message={
            "address": eoa_address,
            "timestamp": timestamp,
            "nonce": nonce,
            "message": "This message attests that I control the given wallet",
        },
    )

    signature = await signer.sign_typed_data(payload)
    if not signature.startswith("0x"):
        signature = f"0x{signature}"

    return {
        "POLY_ADDRESS": eoa_address,
        "POLY_SIGNATURE": signature,
        "POLY_TIMESTAMP": timestamp,
        "POLY_NONCE": str(nonce),
    }


def _parse_clob_credentials(data: dict) -> dict[str, str]:
    """Parse CLOB credential response (handles both 'apiKey'/'key' variants)."""
    return {
        "apiKey": data.get("apiKey") or data.get("key", ""),
        "apiSecret": data["secret"],
        "apiPassphrase": data["passphrase"],
    }


async def create_clob_credentials(signer: Any, funder_address: str) -> dict[str, str]:
    """Create or derive CLOB API credentials via the Polymarket CLOB API.

    Tries POST /auth/api-key first (create new), falls back to
    GET /auth/derive-api-key (derive existing). Matches Rust SDK flow.
    """
    async with httpx.AsyncClient(timeout=10.0) as http:
        # Step 1: Try creating a new API key
        headers = await _build_l1_headers(signer, funder_address)
        resp = await http.post(
            f"{CLOB_HOST}/auth/api-key",
            headers={**headers, "Accept": "*/*", "Content-Type": "application/json"},
        )
        if resp.is_success:
            data = resp.json()
            creds = _parse_clob_credentials(data)
            if creds["apiKey"]:
                return creds

        # Step 2: Fall back to deriving existing key
        headers = await _build_l1_headers(signer, funder_address)
        resp = await http.get(
            f"{CLOB_HOST}/auth/derive-api-key",
            headers={**headers, "Accept": "*/*", "Content-Type": "application/json"},
        )
        if not resp.is_success:
            raise RuntimeError(f"Failed to create CLOB credentials: {resp.status_code} {resp.text}")

        return _parse_clob_credentials(resp.json())
