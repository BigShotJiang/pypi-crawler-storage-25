"""PolyNodeTrader — place orders on Polymarket with local credential custody."""

from __future__ import annotations

import json
import time
from typing import Any

from .clob_api import (
    cancel_all_orders,
    cancel_order as clob_cancel_order,
    fetch_neg_risk,
    fetch_tick_size,
    get_open_orders as clob_get_open_orders,
    post_order,
)
from .constants import DEFAULT_COSIGNER
from .cosigner import build_l2_headers, send_via_cosigner
from .eip712 import create_signed_order
from .onboarding import (
    check_approvals as check_approvals_onchain,
    check_balance as check_balance_onchain,
    create_clob_credentials,
    derive_funder_address,
    detect_wallet_type,
    is_safe_deployed,
)
from .signer import NormalizedSigner, normalize_signer
from .sqlite_backend import TradingSqliteBackend
from .types import (
    ApprovalStatus,
    BalanceInfo,
    CancelResult,
    GeneratedWallet,
    HistoryParams,
    LinkResult,
    MarketMeta,
    OpenOrder,
    OrderHistoryRow,
    OrderParams,
    OrderResult,
    ReadyStatus,
    RouterSigner,
    SignatureType,
    StoredCredentials,
    TraderConfig,
    WalletExport,
    WalletInfo,
)


class PolyNodeTrader:
    """Place orders on Polymarket with local credential custody and builder attribution."""

    def __init__(self, config: TraderConfig | None = None) -> None:
        c = config or TraderConfig()
        self._polynode_key = c.polynode_key
        self._db_path = c.db_path
        self._cosigner_url = c.cosigner_url
        self._fallback_direct = c.fallback_direct
        self._default_sig_type = c.default_signature_type
        self._rpc_url = c.rpc_url

        self._db: TradingSqliteBackend | None = None
        self._active_signer: NormalizedSigner | None = None
        self._active_wallet: str | None = None

    @staticmethod
    async def generate_wallet() -> GeneratedWallet:
        """Generate a fresh EOA wallet. User MUST back up the private key."""
        try:
            from eth_account import Account
        except ImportError:
            raise ImportError("eth-account required. Install with: pip install polynode[trading]")
        account = Account.create()
        return GeneratedWallet(private_key=account.key.hex(), address=account.address)

    def _get_db(self) -> TradingSqliteBackend:
        if not self._db:
            self._db = TradingSqliteBackend(self._db_path)
        return self._db

    # ── Onboarding ──

    async def ensure_ready(
        self,
        signer: str | RouterSigner,
        *,
        type: SignatureType | None = None,
    ) -> ReadyStatus:
        """One-call onboarding: detect wallet type, deploy Safe, set approvals, create CLOB creds."""
        temp = await normalize_signer(signer, type or SignatureType.POLY_GNOSIS_SAFE)
        actions: list[str] = []

        if type is not None:
            sig_type = type
            funder = temp.funder_address or await derive_funder_address(temp.address, sig_type)
        else:
            detected = await detect_wallet_type(temp.address)
            sig_type = detected["signature_type"]
            funder = detected["funder_address"]
            actions.append(f"auto_detected_type_{int(sig_type)}")

        normalized = await normalize_signer(signer, sig_type)
        normalized.funder_address = funder
        normalized.signature_type = sig_type

        db = self._get_db()
        stored = db.get_credentials(normalized.address)
        safe_deployed = stored.safe_deployed if stored else False
        approvals_set = stored.approvals_set if stored else False

        # Deploy Safe if needed
        if sig_type == SignatureType.POLY_GNOSIS_SAFE and not safe_deployed:
            deployed = await is_safe_deployed(funder)
            if deployed:
                safe_deployed = True
                actions.append("safe_already_deployed")
            else:
                actions.append("safe_deploy_needed")

        # Check approvals
        if sig_type in (SignatureType.POLY_GNOSIS_SAFE, SignatureType.EOA) and not approvals_set:
            try:
                approval_status = await check_approvals_onchain(funder, self._rpc_url)
                if approval_status.all_approved:
                    approvals_set = True
                    actions.append("approvals_already_set")
                else:
                    actions.append("approvals_needed")
            except Exception:
                actions.append("approval_check_failed")

        # Create CLOB credentials
        if not stored:
            creds = await create_clob_credentials(normalized, funder)
            stored = StoredCredentials(
                wallet_address=normalized.address,
                funder_address=funder,
                api_key=creds["apiKey"],
                api_secret=creds["apiSecret"],
                api_passphrase=creds["apiPassphrase"],
                signature_type=sig_type,
                safe_deployed=safe_deployed,
                approvals_set=approvals_set,
                created_at=time.time(),
                updated_at=time.time(),
            )
            db.upsert_credentials(stored)
            actions.append("credentials_created")
        else:
            stored.safe_deployed = safe_deployed
            stored.approvals_set = approvals_set
            stored.updated_at = time.time()
            db.upsert_credentials(stored)
            actions.append("credentials_loaded")

        self._active_signer = normalized
        self._active_wallet = normalized.address

        return ReadyStatus(
            wallet=normalized.address,
            funder_address=funder,
            signature_type=sig_type,
            safe_deployed=safe_deployed,
            approvals_set=approvals_set,
            credentials_stored=True,
            credentials={
                "apiKey": stored.api_key,
                "apiSecret": stored.api_secret,
                "apiPassphrase": stored.api_passphrase,
            },
            actions=actions,
        )

    async def link_wallet(
        self,
        signer: str | RouterSigner,
        *,
        type: SignatureType | None = None,
    ) -> LinkResult:
        """Link a wallet manually (derive credentials, store locally)."""
        sig_type = type or self._default_sig_type
        normalized = await normalize_signer(signer, sig_type)
        funder = normalized.funder_address or await derive_funder_address(normalized.address, sig_type)

        db = self._get_db()
        existing = db.get_credentials(normalized.address)

        if existing:
            creds_dict = {
                "apiKey": existing.api_key,
                "apiSecret": existing.api_secret,
                "apiPassphrase": existing.api_passphrase,
            }
        else:
            creds_dict = await create_clob_credentials(normalized, funder)

        db.upsert_credentials(StoredCredentials(
            wallet_address=normalized.address,
            funder_address=funder,
            api_key=creds_dict["apiKey"],
            api_secret=creds_dict["apiSecret"],
            api_passphrase=creds_dict["apiPassphrase"],
            signature_type=sig_type,
            safe_deployed=existing.safe_deployed if existing else False,
            approvals_set=existing.approvals_set if existing else False,
            created_at=existing.created_at if existing else time.time(),
            updated_at=time.time(),
        ))

        self._active_signer = normalized
        self._active_wallet = normalized.address

        return LinkResult(
            wallet=normalized.address,
            funder_address=funder,
            signature_type=sig_type,
            credentials=creds_dict,
        )

    def link_credentials(
        self,
        *,
        wallet: str,
        api_key: str,
        api_secret: str,
        api_passphrase: str,
        signature_type: SignatureType = SignatureType.EOA,
        funder_address: str | None = None,
    ) -> None:
        """Import existing CLOB credentials directly."""
        db = self._get_db()
        db.upsert_credentials(StoredCredentials(
            wallet_address=wallet,
            funder_address=funder_address,
            api_key=api_key,
            api_secret=api_secret,
            api_passphrase=api_passphrase,
            signature_type=signature_type,
            safe_deployed=True,
            approvals_set=True,
            created_at=time.time(),
            updated_at=time.time(),
        ))
        self._active_wallet = wallet

    def unlink_wallet(self, address: str | None = None) -> None:
        wallet = address or self._active_wallet
        if not wallet:
            return
        self._get_db().delete_credentials(wallet)
        if self._active_wallet == wallet:
            self._active_wallet = None
            self._active_signer = None

    def get_linked_wallets(self) -> list[WalletInfo]:
        return [
            WalletInfo(
                wallet=c.wallet_address,
                funder_address=c.funder_address or c.wallet_address,
                signature_type=c.signature_type,
                credentials={
                    "apiKey": c.api_key,
                    "apiSecret": c.api_secret,
                    "apiPassphrase": c.api_passphrase,
                },
                created_at=c.created_at,
            )
            for c in self._get_db().get_all_credentials()
        ]

    # ── Export / Backup ──

    def export_wallet(self, wallet: str | None = None) -> WalletExport | None:
        addr = wallet or self._active_wallet
        if not addr:
            return None
        creds = self._get_db().get_credentials(addr)
        if not creds:
            return None
        return WalletExport(
            wallet=creds.wallet_address,
            funder_address=creds.funder_address or creds.wallet_address,
            signature_type=creds.signature_type,
            credentials={
                "apiKey": creds.api_key,
                "apiSecret": creds.api_secret,
                "apiPassphrase": creds.api_passphrase,
            },
            safe_deployed=creds.safe_deployed,
            approvals_set=creds.approvals_set,
            created_at=creds.created_at,
        )

    def export_all(self) -> list[WalletExport]:
        return [
            WalletExport(
                wallet=c.wallet_address,
                funder_address=c.funder_address or c.wallet_address,
                signature_type=c.signature_type,
                credentials={"apiKey": c.api_key, "apiSecret": c.api_secret, "apiPassphrase": c.api_passphrase},
                safe_deployed=c.safe_deployed,
                approvals_set=c.approvals_set,
                created_at=c.created_at,
            )
            for c in self._get_db().get_all_credentials()
        ]

    def import_wallet(self, exported: WalletExport) -> None:
        self._get_db().upsert_credentials(StoredCredentials(
            wallet_address=exported.wallet,
            funder_address=exported.funder_address,
            api_key=exported.credentials["apiKey"],
            api_secret=exported.credentials["apiSecret"],
            api_passphrase=exported.credentials["apiPassphrase"],
            signature_type=exported.signature_type,
            safe_deployed=exported.safe_deployed,
            approvals_set=exported.approvals_set,
            created_at=exported.created_at,
            updated_at=time.time(),
        ))

    # ── Pre-Trade Checks ──

    async def check_approvals(self, wallet: str | None = None) -> ApprovalStatus:
        creds = self._get_stored_creds(wallet)
        return await check_approvals_onchain(creds.funder_address or creds.wallet_address, self._rpc_url)

    async def check_balance(self, wallet: str | None = None) -> BalanceInfo:
        creds = self._get_stored_creds(wallet)
        return await check_balance_onchain(creds.funder_address or creds.wallet_address, self._rpc_url)

    # ── Trading ──

    async def order(self, params: OrderParams) -> OrderResult:
        """Place an order on Polymarket."""
        creds = self._get_stored_creds()
        signer = self._require_signer()
        meta = await self._fetch_meta(params.token_id)

        signed_order = await create_signed_order(
            signer.sign_typed_data,
            signer_address=signer.address,
            funder_address=creds.funder_address or creds.wallet_address,
            token_id=params.token_id,
            price=params.price,
            size=params.size,
            side=params.side,
            signature_type=creds.signature_type,
            tick_size=meta.tick_size,
            neg_risk=meta.neg_risk,
            fee_rate_bps=meta.fee_rate_bps,
            expiration=params.expiration or 0,
        )

        payload = {
            "order": signed_order,
            "owner": creds.api_key,
            "orderType": params.type,
        }
        if params.post_only:
            payload["postOnly"] = True

        body_str = json.dumps(payload, separators=(",", ":"))
        headers = build_l2_headers(
            creds.api_key, creds.api_secret, creds.api_passphrase,
            creds.wallet_address, "POST", "/order", body_str,
        )

        db = self._get_db()
        local_id = db.insert_order({
            "wallet_address": creds.wallet_address,
            "token_id": params.token_id,
            "side": params.side,
            "price": params.price,
            "size": params.size,
            "order_type": params.type,
            "status": "submitting",
        })

        result = await send_via_cosigner(
            self._cosigner_url, self._polynode_key, self._fallback_direct,
            {"method": "POST", "path": "/order", "body": body_str, "headers": headers},
        )

        order_id = result.get("orderID") or result.get("orderId")
        success = bool(result.get("success") or order_id)
        error = result.get("error") or result.get("errorMsg")

        db.update_order_status(
            local_id,
            "submitted" if success else "failed",
            order_id, error, json.dumps(result),
        )

        return OrderResult(
            success=success,
            order_id=order_id,
            status=result.get("status"),
            error=error,
            making_amount=result.get("makingAmount"),
            taking_amount=result.get("takingAmount"),
        )

    async def cancel_order(self, order_id: str) -> CancelResult:
        creds = self._get_stored_creds()
        result = await clob_cancel_order(
            self._cosigner_url, self._polynode_key, self._fallback_direct,
            {"apiKey": creds.api_key, "apiSecret": creds.api_secret, "apiPassphrase": creds.api_passphrase},
            creds.wallet_address, order_id,
        )
        return CancelResult(
            canceled=result.get("canceled", []),
            not_canceled=result.get("not_canceled", {}),
        )

    async def cancel_all(self, market: str | None = None) -> CancelResult:
        creds = self._get_stored_creds()
        result = await cancel_all_orders(
            self._cosigner_url, self._polynode_key, self._fallback_direct,
            {"apiKey": creds.api_key, "apiSecret": creds.api_secret, "apiPassphrase": creds.api_passphrase},
            creds.wallet_address, market,
        )
        return CancelResult(
            canceled=result.get("canceled", []),
            not_canceled=result.get("not_canceled", {}),
        )

    async def get_open_orders(
        self, *, market: str | None = None, asset_id: str | None = None
    ) -> list[OpenOrder]:
        creds = self._get_stored_creds()
        result = await clob_get_open_orders(
            self._cosigner_url, self._polynode_key, self._fallback_direct,
            {"apiKey": creds.api_key, "apiSecret": creds.api_secret, "apiPassphrase": creds.api_passphrase},
            creds.wallet_address, market, asset_id,
        )
        return [
            OpenOrder(
                id=o.get("id", ""), market=o.get("market", ""),
                asset_id=o.get("assetId") or o.get("asset_id", ""),
                side=o.get("side", ""), price=o.get("price", ""),
                original_size=o.get("originalSize") or o.get("original_size", ""),
                size_matched=o.get("sizeMatched") or o.get("size_matched", ""),
                status=o.get("status", ""), created_at=o.get("createdAt") or o.get("created_at", ""),
                order_type=o.get("orderType") or o.get("order_type", ""),
            )
            for o in result
        ]

    # ── Metadata ──

    async def prefetch_meta(self, token_ids: list[str]) -> None:
        import asyncio
        await asyncio.gather(*(self._fetch_meta(tid) for tid in token_ids))

    async def _fetch_meta(self, token_id: str) -> MarketMeta:
        db = self._get_db()
        cached = db.get_market_meta(token_id)
        if cached:
            return cached

        import asyncio
        tick, neg = await asyncio.gather(fetch_tick_size(token_id), fetch_neg_risk(token_id))
        meta = MarketMeta(
            token_id=token_id,
            tick_size=tick,
            fee_rate_bps=0,
            neg_risk=neg,
            fetched_at=time.time(),
        )
        db.upsert_market_meta(meta)
        return meta

    # ── History ──

    def get_order_history(self, params: HistoryParams | None = None) -> list[OrderHistoryRow]:
        if not self._active_wallet:
            return []
        return self._get_db().get_order_history(self._active_wallet, params)

    # ── Lifecycle ──

    def close(self) -> None:
        if self._db:
            self._db.close()
            self._db = None
        self._active_signer = None
        self._active_wallet = None

    # ── Internal ──

    def _get_stored_creds(self, wallet: str | None = None) -> StoredCredentials:
        addr = wallet or self._active_wallet
        if not addr:
            raise RuntimeError("No active wallet. Call ensure_ready() or link_wallet() first.")
        creds = self._get_db().get_credentials(addr)
        if not creds:
            raise RuntimeError(f"No credentials found for {addr}. Call ensure_ready() first.")
        return creds

    def _require_signer(self) -> NormalizedSigner:
        if not self._active_signer:
            raise RuntimeError("No active signer. Call ensure_ready() or link_wallet() first.")
        return self._active_signer
