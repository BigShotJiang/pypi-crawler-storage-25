"""Pure Python EIP-712 order signing for Polymarket exchange contracts."""

from __future__ import annotations

import math
from typing import Any

from .constants import CTF_EXCHANGE, NEG_RISK_CTF_EXCHANGE
from .types import Eip712Payload, SignatureType


# EIP-712 domain for Polymarket Exchange
EXCHANGE_DOMAIN = {
    "name": "Polymarket CTF Exchange",
    "version": "1",
    "chainId": 137,
    "verifyingContract": CTF_EXCHANGE,
}

NEG_RISK_DOMAIN = {
    "name": "Polymarket CTF Exchange",
    "version": "1",
    "chainId": 137,
    "verifyingContract": NEG_RISK_CTF_EXCHANGE,
}

ORDER_TYPES = {
    "Order": [
        {"name": "salt", "type": "uint256"},
        {"name": "maker", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "taker", "type": "address"},
        {"name": "tokenId", "type": "uint256"},
        {"name": "makerAmount", "type": "uint256"},
        {"name": "takerAmount", "type": "uint256"},
        {"name": "expiration", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
        {"name": "feeRateBps", "type": "uint256"},
        {"name": "side", "type": "uint8"},
        {"name": "signatureType", "type": "uint8"},
    ],
}


def compute_amounts(
    price: float,
    size: float,
    side: str,
    tick_size: str,
) -> tuple[int, int]:
    """Compute maker_amount and taker_amount from price/size/tick_size."""
    decimals = len(tick_size.rstrip("0").split(".")[-1]) if "." in tick_size else 0
    raw_price = round(price * (10 ** decimals))
    raw_size = round(size * 1_000_000)  # USDC has 6 decimals
    price_denom = 10 ** decimals

    if side == "BUY":
        maker_amount = raw_size * raw_price // price_denom
        taker_amount = raw_size
    else:
        maker_amount = raw_size
        taker_amount = raw_size * raw_price // price_denom

    return maker_amount, taker_amount


def build_order_payload(
    *,
    maker: str,
    signer: str,
    token_id: str,
    maker_amount: int,
    taker_amount: int,
    side: str,
    signature_type: SignatureType,
    fee_rate_bps: int = 0,
    nonce: int = 0,
    expiration: int = 0,
    neg_risk: bool = False,
) -> Eip712Payload:
    """Build an EIP-712 typed data payload for a Polymarket order."""
    import secrets

    salt = secrets.randbelow(2**32)
    side_int = 0 if side == "BUY" else 1

    domain = NEG_RISK_DOMAIN if neg_risk else EXCHANGE_DOMAIN

    message = {
        "salt": salt,
        "maker": maker,
        "signer": signer,
        "taker": "0x0000000000000000000000000000000000000000",
        "tokenId": int(token_id),
        "makerAmount": maker_amount,
        "takerAmount": taker_amount,
        "expiration": expiration,
        "nonce": nonce,
        "feeRateBps": fee_rate_bps,
        "side": side_int,
        "signatureType": int(signature_type),
    }

    return Eip712Payload(
        domain=domain,
        types=ORDER_TYPES,
        primary_type="Order",
        message=message,
    )


async def create_signed_order(
    sign_typed_data: Any,
    *,
    signer_address: str,
    funder_address: str,
    token_id: str,
    price: float,
    size: float,
    side: str,
    signature_type: SignatureType,
    tick_size: str = "0.01",
    neg_risk: bool = False,
    fee_rate_bps: int = 0,
    expiration: int = 0,
    nonce: int = 0,
) -> dict[str, Any]:
    """Create and sign a Polymarket order. Returns the order dict ready for CLOB submission."""
    maker_amount, taker_amount = compute_amounts(price, size, side, tick_size)

    payload = build_order_payload(
        maker=funder_address,
        signer=signer_address,
        token_id=token_id,
        maker_amount=maker_amount,
        taker_amount=taker_amount,
        side=side,
        signature_type=signature_type,
        fee_rate_bps=fee_rate_bps,
        nonce=nonce,
        expiration=expiration,
        neg_risk=neg_risk,
    )

    signature = await sign_typed_data(payload)
    if not signature.startswith("0x"):
        signature = f"0x{signature}"

    # Normalize v to raw recovery id (0/1): CLOB expects v=0/1 for order signatures
    sig_bytes = bytearray(bytes.fromhex(signature[2:]))
    if len(sig_bytes) == 65 and sig_bytes[-1] >= 27:
        sig_bytes[-1] -= 27
    signature = "0x" + sig_bytes.hex()

    return {
        "salt": payload.message["salt"],
        "maker": funder_address,
        "signer": signer_address,
        "taker": "0x0000000000000000000000000000000000000000",
        "tokenId": token_id,
        "makerAmount": str(maker_amount),
        "takerAmount": str(taker_amount),
        "expiration": str(expiration),
        "nonce": str(nonce),
        "feeRateBps": str(fee_rate_bps),
        "side": side,
        "signatureType": int(signature_type),
        "signature": signature,
    }
