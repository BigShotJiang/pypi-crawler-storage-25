"""Co-signer client — routes orders through the PolyNode builder attribution proxy."""

from __future__ import annotations

import base64
import hashlib
import hmac
import time
from typing import Any

import httpx

from .constants import CLOB_HOST


def build_l2_headers(
    api_key: str,
    api_secret: str,
    api_passphrase: str,
    wallet_address: str,
    method: str,
    path: str,
    body: str | None = None,
) -> dict[str, str]:
    """Build L2 HMAC headers for Polymarket CLOB authentication."""
    timestamp = str(int(time.time()))
    message = f"{timestamp}{method}{path}"
    if body:
        message += body

    secret_bytes = base64.urlsafe_b64decode(api_secret)
    sig = base64.b64encode(
        hmac.new(secret_bytes, message.encode(), hashlib.sha256).digest()
    ).decode()
    sig = sig.replace("+", "-").replace("/", "_")

    return {
        "POLY_ADDRESS": wallet_address,
        "POLY_SIGNATURE": sig,
        "POLY_TIMESTAMP": timestamp,
        "POLY_API_KEY": api_key,
        "POLY_PASSPHRASE": api_passphrase,
    }


async def send_via_cosigner(
    cosigner_url: str,
    polynode_key: str,
    fallback_direct: bool,
    request: dict[str, Any],
) -> Any:
    """Send a request through the co-signer with optional fallback to direct CLOB."""
    if cosigner_url:
        try:
            async with httpx.AsyncClient(timeout=10.0) as http:
                resp = await http.post(
                    f"{cosigner_url}/submit",
                    headers={
                        "Content-Type": "application/json",
                        "X-PolyNode-Key": polynode_key,
                    },
                    json=request,
                )
                data = resp.json()
                if resp.status_code >= 500 and fallback_direct:
                    return await _send_direct(request)
                return data
        except Exception as e:
            if fallback_direct:
                return await _send_direct(request)
            raise RuntimeError(f"Co-signer unreachable: {e}")

    return await _send_direct(request)


async def _send_direct(request: dict[str, Any]) -> Any:
    """Send directly to Polymarket CLOB (no builder attribution)."""
    url = f"{CLOB_HOST}{request['path']}"
    async with httpx.AsyncClient(timeout=10.0) as http:
        resp = await http.request(
            request["method"],
            url,
            headers={**request.get("headers", {}), "Content-Type": "application/json"},
            content=request.get("body"),
        )
        return resp.json()
