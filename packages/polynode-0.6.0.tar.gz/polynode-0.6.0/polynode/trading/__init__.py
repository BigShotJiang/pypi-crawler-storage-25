"""Trading module — place orders on Polymarket with local credential custody."""

from .types import *  # noqa: F401, F403
from .constants import *  # noqa: F401, F403
from .signer import NormalizedSigner, normalize_signer
from .cosigner import build_l2_headers, send_via_cosigner
from .onboarding import derive_safe_address, derive_proxy_address, detect_wallet_type
from .trader import PolyNodeTrader
from .privy import PrivySigner, PrivyConfig

__all__ = [
    "PolyNodeTrader",
    "PrivySigner",
    "PrivyConfig",
    "NormalizedSigner",
    "normalize_signer",
    "build_l2_headers",
    "send_via_cosigner",
    "derive_safe_address",
    "derive_proxy_address",
    "detect_wallet_type",
]
