"""Tests for trading module — EIP-712 signing, HMAC headers."""

import base64

from polynode.trading.cosigner import build_l2_headers
from polynode.trading.eip712 import compute_amounts
from polynode.trading.types import SignatureType


def test_compute_amounts_buy():
    maker, taker = compute_amounts(0.55, 100, "BUY", "0.01")
    # BUY: maker pays USDC (price * size), taker gets tokens (size)
    assert maker == 55_000_000  # 0.55 * 100 * 1e6
    assert taker == 100_000_000  # 100 * 1e6


def test_compute_amounts_sell():
    maker, taker = compute_amounts(0.55, 100, "SELL", "0.01")
    # SELL: maker provides tokens (size), taker pays USDC
    assert maker == 100_000_000
    assert taker == 55_000_000


def test_build_l2_headers():
    headers = build_l2_headers(
        api_key="test_key",
        api_secret=base64.b64encode(b"test_secret").decode(),
        api_passphrase="test_pass",
        wallet_address="0x1234",
        method="POST",
        path="/order",
        body='{"test": true}',
    )
    assert headers["POLY_ADDRESS"] == "0x1234"
    assert headers["POLY_API_KEY"] == "test_key"
    assert headers["POLY_PASSPHRASE"] == "test_pass"
    assert "POLY_SIGNATURE" in headers
    assert "POLY_TIMESTAMP" in headers


def test_safe_address_derivation():
    """Verify Safe address derivation matches known addresses."""
    try:
        from polynode.trading.onboarding import derive_safe_address
        # This requires eth-account/web3 — skip if not installed
        addr = derive_safe_address("0x0000000000000000000000000000000000000001")
        assert addr.startswith("0x")
        assert len(addr) == 42
    except ImportError:
        pass  # Skip if trading deps not installed
