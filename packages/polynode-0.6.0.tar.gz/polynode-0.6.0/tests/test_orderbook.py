"""Tests for LocalOrderbook state management."""

from polynode.orderbook_state import LocalOrderbook
from polynode.types.orderbook import BookSnapshot, BookUpdate, OrderbookLevel


def test_apply_snapshot():
    ob = LocalOrderbook()
    snap = BookSnapshot(
        asset_id="token1",
        market="market1",
        bids=[OrderbookLevel(price="0.55", size="100"), OrderbookLevel(price="0.50", size="200")],
        asks=[OrderbookLevel(price="0.60", size="150"), OrderbookLevel(price="0.65", size="50")],
    )
    ob.apply_snapshot(snap)

    book = ob.get_book("token1")
    assert book is not None
    bids, asks = book
    assert bids[0].price == "0.55"  # highest first
    assert asks[0].price == "0.60"  # lowest first


def test_apply_update():
    ob = LocalOrderbook()
    snap = BookSnapshot(
        asset_id="t1",
        market="m1",
        bids=[OrderbookLevel(price="0.50", size="100")],
        asks=[OrderbookLevel(price="0.60", size="100")],
    )
    ob.apply_snapshot(snap)

    update = BookUpdate(
        asset_id="t1",
        market="m1",
        bids=[OrderbookLevel(price="0.55", size="50")],
        asks=[OrderbookLevel(price="0.60", size="0")],
    )
    ob.apply_update(update)

    bids, asks = ob.get_book("t1")  # type: ignore
    assert len(bids) == 2
    assert bids[0].price == "0.55"
    assert len(asks) == 0  # removed


def test_spread():
    ob = LocalOrderbook()
    snap = BookSnapshot(
        asset_id="t1",
        market="m1",
        bids=[OrderbookLevel(price="0.50", size="100")],
        asks=[OrderbookLevel(price="0.60", size="100")],
    )
    ob.apply_snapshot(snap)
    spread = ob.get_spread("t1")
    assert spread is not None
    assert abs(spread - 0.10) < 0.001
