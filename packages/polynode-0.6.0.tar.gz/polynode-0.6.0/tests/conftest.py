"""Shared test fixtures."""

import pytest

TEST_KEY = "pn_live_test_session_tracking_51eca107e9b347b589f5b0a04f98eb1d"
BASE_URL = "https://api.polynode.dev"
WS_URL = "wss://ws.polynode.dev/ws"
OB_URL = "wss://ob.polynode.dev/ws"


@pytest.fixture
def api_key():
    return TEST_KEY


@pytest.fixture
def client():
    from polynode import PolyNode
    pn = PolyNode(api_key=TEST_KEY)
    yield pn
    pn.close()


@pytest.fixture
async def async_client():
    from polynode import AsyncPolyNode
    pn = AsyncPolyNode(api_key=TEST_KEY)
    yield pn
    await pn.close()
