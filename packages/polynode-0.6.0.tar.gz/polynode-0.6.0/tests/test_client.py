"""Tests for the sync REST client."""

import pytest
from polynode import PolyNode
from polynode.types.rest import StatusResponse, MarketsResponse, SettlementsResponse

TEST_KEY = "pn_live_test_session_tracking_51eca107e9b347b589f5b0a04f98eb1d"


@pytest.fixture
def pn():
    client = PolyNode(api_key=TEST_KEY)
    yield client
    client.close()


def test_healthz(pn):
    result = pn.healthz()
    assert result == "ok" or "ok" in str(result).lower()


def test_status(pn):
    result = pn.status()
    assert isinstance(result, StatusResponse)
    assert result.uptime_seconds > 0
    assert result.state.market_count > 0


def test_markets(pn):
    result = pn.markets(count=3)
    assert isinstance(result, MarketsResponse)
    assert result.count > 0
    assert len(result.markets) <= 3


def test_recent_settlements(pn):
    result = pn.recent_settlements(count=1)
    assert isinstance(result, SettlementsResponse)
    assert result.count >= 0


def test_search(pn):
    result = pn.search("election", limit=3)
    assert result.query == "election"
    assert result.count >= 0
