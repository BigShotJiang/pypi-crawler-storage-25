"""Tests for Pydantic type models."""

from pydantic import TypeAdapter

from polynode.types.events import (
    BlockEvent,
    PolyNodeEvent,
    SettlementEvent,
    TradeEvent,
)


def test_settlement_event_parse():
    data = {
        "event_type": "settlement",
        "tx_hash": "0xabc",
        "status": "pending",
        "detected_at": 1234567890.0,
        "taker_wallet": "0x123",
        "taker_token": "0x456",
        "taker_side": "BUY",
        "taker_price": 0.55,
        "taker_size": 100.0,
        "trades": [],
        "market_title": "Test Market",
    }
    event = SettlementEvent.model_validate(data)
    assert event.event_type == "settlement"
    assert event.market_title == "Test Market"
    assert event.taker_price == 0.55


def test_block_event_parse():
    data = {
        "event_type": "block",
        "block_number": 12345,
        "block_hash": "0xhash",
        "timestamp": 1234567890.0,
        "parent_hash": "0xparent",
        "tx_count": 10,
        "polymarket_tx_count": 3,
        "settlement_count": 1,
        "trade_volume_usd": 50000.0,
    }
    event = BlockEvent.model_validate(data)
    assert event.block_number == 12345
    assert event.trade_volume_usd == 50000.0


def test_discriminated_union():
    adapter = TypeAdapter(PolyNodeEvent)

    settlement_data = {
        "event_type": "settlement",
        "tx_hash": "0x1",
        "status": "confirmed",
        "detected_at": 0,
        "taker_wallet": "0x",
        "taker_token": "0x",
        "taker_side": "BUY",
        "taker_price": 0.5,
        "taker_size": 10,
        "trades": [],
    }
    event = adapter.validate_python(settlement_data)
    assert isinstance(event, SettlementEvent)

    block_data = {
        "event_type": "block",
        "block_number": 1,
        "block_hash": "0x",
        "timestamp": 0,
        "parent_hash": "0x",
        "tx_count": 0,
        "polymarket_tx_count": 0,
        "settlement_count": 0,
        "trade_volume_usd": 0,
    }
    event = adapter.validate_python(block_data)
    assert isinstance(event, BlockEvent)
