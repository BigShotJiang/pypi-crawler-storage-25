# polynode

Python SDK for the [PolyNode](https://polynode.dev) real-time prediction market data platform.

## Install

```bash
pip install polynode
```

For trading support:
```bash
pip install polynode[trading]
```

## Quick Start

### REST API

```python
from polynode import PolyNode

with PolyNode(api_key="pn_live_...") as pn:
    status = pn.status()
    markets = pn.markets(count=10)
    settlements = pn.recent_settlements(count=5)
```

### Async REST

```python
import asyncio
from polynode import AsyncPolyNode

async def main():
    async with AsyncPolyNode(api_key="pn_live_...") as pn:
        status = await pn.status()
        markets = await pn.markets(count=10)

asyncio.run(main())
```

### WebSocket Streaming

```python
import asyncio
from polynode import AsyncPolyNode

async def main():
    async with AsyncPolyNode(api_key="pn_live_...") as pn:
        sub = await pn.ws.subscribe("settlements").min_size(1000).send()

        async for event in sub:
            print(event.event_type, event.market_title, event.taker_price)

asyncio.run(main())
```

### Orderbook

```python
import asyncio
from polynode import OrderbookEngine

async def main():
    engine = OrderbookEngine(api_key="pn_live_...")
    await engine.subscribe(["token_id_1", "token_id_2"])

    engine.on("ready", lambda: print(f"Tracking {engine.size} books"))
    engine.on("update", lambda u: print(f"{u.asset_id}: {engine.midpoint(u.asset_id)}"))

asyncio.run(main())
```

### Trading

```python
import asyncio
from polynode.trading import PolyNodeTrader, TraderConfig, OrderParams

async def main():
    trader = PolyNodeTrader(TraderConfig(polynode_key="pn_live_..."))
    status = await trader.ensure_ready("0xYourPrivateKey...")

    result = await trader.order(OrderParams(
        token_id="...",
        side="BUY",
        price=0.55,
        size=100,
    ))
    print(result)

    trader.close()

asyncio.run(main())
```

## Documentation

Full docs at [docs.polynode.dev](https://docs.polynode.dev)
