"""EgoVault frontend layer."""
