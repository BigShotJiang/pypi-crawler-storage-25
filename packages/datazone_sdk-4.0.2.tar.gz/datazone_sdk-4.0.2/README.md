# Datazone SDK

Database and Delta storage client library for working with Delta Lake tables.

## Overview

This package provides functionality for interacting with Delta Lake tables, including:

- **Database Client**: High-level client for querying Delta Lake tables with support for time intervals, time travel, and filtering.
- **Delta Storage**: Low-level components for working with Delta tables, schemas, and data types.

## Installation

```bash
pip install datazone-sdk
```

## Usage

```python
import datazone as dz

# Create a client from a storage account name
client = dz.DatabaseClient.from_resource_name(
    storage_account="<storage-account>",
    container_name="<container-name>",
    sub_path="<sub-path>",
)

# Query a table
df = client.query(
    table_name="my_table",
    filters={"column": "value"},
)
```

## Development
Create a virtual environment, install `poetry` and run `poetry install`.

This can be done by running the following in a terminal:
```bash
pyenv virtualenv 3.13.11 datazone-sdk
pyenv local datazone-sdk
pip install poetry
poetry install
```
