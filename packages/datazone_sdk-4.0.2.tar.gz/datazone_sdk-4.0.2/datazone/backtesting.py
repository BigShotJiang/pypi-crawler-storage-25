from typing import Callable, Sequence, Union

import pandas as pd

from datazone.db.snapshot import SnapshotDatabaseClient
from datazone.db.standard import DatabaseClient


def backtest(
    func: Callable[[SnapshotDatabaseClient, pd.Timestamp], pd.DataFrame],
    db: DatabaseClient,
    calculation_times: Union[pd.DatetimeIndex, Sequence[pd.Timestamp]],
) -> pd.DataFrame:
    """Run ``func`` over consecutive calculation-time snapshots.

    The result is then annotated with the validity period of that snapshot:

    - ``valid_from_time_utc = t[i]``
    - ``valid_to_time_utc   = t[i+1]``

    All per-snapshot results are concatenated into a single DataFrame.

    Args:
        func: User-defined function that accepts a
            :class:`SnapshotDatabaseClient` and a ``trigger_time`` keyword
            argument, and returns a :class:`pd.DataFrame`.

        calculation_times: Ordered sequence of timestamps. ``N`` timestamps produce
            ``N - 1`` snapshot evaluations. Fewer than 2 timestamps returns an
            empty DataFrame.

    Returns:
        Concatenated DataFrame of all snapshot results, with
        ``valid_from_time_utc`` and ``valid_to_time_utc`` columns added.

    Example:
        >>> def my_func(db, calculation_time):
        ...     df = snapshot_db.query("my_table")
        ...     # ... transform df ...
        ...     return df
        ...
        >>> calculation_times = pd.date_range("2024-01-01", "2024-01-10", freq="D")
        >>> result = backtest(my_func, db, calculation_times)
    """
    results = []
    calculation_times = pd.DatetimeIndex(calculation_times)

    for i in range(len(calculation_times) - 1):
        calculation_time = calculation_times[i]
        snapshot_db = db.snapshot_at(calculation_time)
        result = func(snapshot_db, calculation_time)

        result["valid_from_time_utc"] = calculation_time
        result["valid_to_time_utc"] = calculation_times[i + 1]
        results.append(result)

    if not results:
        return pd.DataFrame()

    return pd.concat(results, ignore_index=True)
