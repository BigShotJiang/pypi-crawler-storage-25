from typing import Any, Optional

import deltalake as dl
import polars as pl
import pyarrow as pa

from .schema import Schema
from .slicing import HyperSlice


def _dnf_to_sql(dnf: list[tuple]) -> str:
    """Convert DNF expression to SQL expression."""
    if len(dnf) == 0:
        return "1=1"

    sql_parts = []
    for col, op, val in dnf:
        if op == "in":
            assert isinstance(val, list)
            lst = ", ".join([f"'{item}'" for item in val])
            sql_parts.append(f"{col} IN ({lst})")
        elif op in [">=", "<=", ">", "<", "="]:
            sql_parts.append(f"{col} {op} '{val}'")
        else:
            raise ValueError(f"Unsupported operation: {op}")

    return " AND ".join(sql_parts)


class Table:
    def __init__(
        self,
        url: str,
        storage_options: dict[str, str] | None = None,
    ):
        """Class representing a dataset

        Args:
            url (str): URL to the Delta table
            storage_options (dict[str, str] | None, optional): Storage options used for
                remote cloud storage. For more information on available options,
                go to https://delta-io.github.io/delta-rs/integrations/object-storage/.
                Defaults to None, corresponding to the local file system.
        """
        self.url = url
        self.storage_options = storage_options

        self.table_name = self.url.split("/")[-1]
        self._delta_table = None

    def __repr__(self):
        return f"Table('{self.table_name}')"

    @property
    def delta_table(self) -> dl.DeltaTable:
        """Get the Delta table object.
        As the `Table`-class is lazily initialized,
        the `delta_table`-property is initialized when needed.
        We do not cache it, which creates a little overhead, but reduces
        the risk of false transaction issues when doing concurrent reads/writes.
        This is important because using the same instance can lead to transaction
        issues in delta as DeltaTable uses metadata (transaction id) from
        the first time the object is instantiated.

        The risk disappears when this instance is created within a lock.
        """
        return dl.DeltaTable(self.url, storage_options=self.storage_options)

    def partition_cols(self) -> list[str]:
        """Get the partition columns of the table"""
        return self.delta_table.metadata().partition_columns

    def schema(self) -> Schema:
        """Get the schema of the table"""
        pa_schema = pa.schema(self.delta_table.schema())
        return Schema.from_arrow(pa_schema)

    def read(
        self, hyper_slice: Optional[HyperSlice] = None, columns=None
    ) -> pl.DataFrame:
        """Read from Delta table

        Args:
            hyper_slice (HyperSlice): Hyper sliced used to filter data
        """
        if hyper_slice is None:
            hyper_slice = []

        # add generated filters to hyperslice
        hyper_slice = self.schema().add_generated_filters(hyper_slice)

        delta_table = self.delta_table
        partition_cols = delta_table.metadata().partition_columns

        if len(hyper_slice) == 0:
            file_filters = None
            partition_filters = None
        else:
            file_filters = hyper_slice
            partition_filters = [f for f in hyper_slice if f[0] in partition_cols]

        pyarrow_table_existing_data = delta_table.to_pyarrow_table(
            columns=columns,
            partitions=partition_filters,
            filters=file_filters,
        )

        return pl.from_arrow(pyarrow_table_existing_data)

    def _to_writable_pyarrow_table(self, df: pl.DataFrame, schema: Schema) -> pa.Table:
        """Convert Polars dataframe to pyarrow table with casted schema.
        The conversion will include generated columns.

        Args:
            df (pl.DataFrame): Dataframe to convert
            schema (Schema): Schema to cast the dataframe to

        Returns:
            pa.Table: PyArrow table with the casted schema
        """
        df = schema.add_generated_columns(df)
        pyarrow_table = df.to_arrow()

        # we need to cast the incoming data to the
        # table schema. In theory, this should automatically
        # be casted, but it seems that metadata on fields
        # gets removed otherwise.
        pa_schema = schema.to_arrow()
        return pyarrow_table.select(pa_schema.names).cast(pa_schema)

    def _write_deltalake(
        self, data: pa.Table, mode: str, predicate: Optional[str]
    ) -> None:
        """Write data to Delta Lake using deltalake-python.

        Args:
            data (pa.Table): PyArrow table to write to Delta Lake
            mode (str): Write mode, either "overwrite" or "append"
            predicate (Optional[str]): SQL predicate to filter rows for update or
                delete operations. If None, the operation will apply to all rows.
        """
        dl.write_deltalake(
            table_or_uri=self.delta_table,
            data=data,
            mode=mode,
            predicate=predicate,
            schema_mode="merge",
        )

    def update(self, df: pl.DataFrame, hyper_slice: HyperSlice) -> None:
        """Update rows in Delta Lake based on a HyperSlice. This will overwrite data
        in the Delta Lake specified by the HyperSlice.

        Args:
            df (pl.DataFrame): DataFrame containing the rows to update.
            hyper_slice (HyperSlice): HyperSlice used to define rows to update.
                If None, all rows will be updated.
        """
        schema = self.schema()
        data = self._to_writable_pyarrow_table(df=df, schema=schema)

        hyper_slice = schema.add_generated_filters(hyper_slice)
        if len(hyper_slice) == 0:
            predicate = None
        else:
            predicate = _dnf_to_sql(hyper_slice)

        self._write_deltalake(data=data, mode="overwrite", predicate=predicate)

    def append(self, df: pl.DataFrame) -> None:
        """Append rows to Delta Lake. This will write data to the Delta Lake.

        Args:
            df (pl.DataFrame): DataFrame containing the rows to append.
        """
        schema = self.schema()
        data = self._to_writable_pyarrow_table(df=df, schema=schema)
        self._write_deltalake(data=data, mode="append", predicate=None)

    def optimize(self) -> list[str]:
        """Optimize Delta table by compacting and vacuuming

        Returns:
            list[str]: List of removed files
        """
        delta_table = self.delta_table
        metrics = delta_table.optimize.compact()

        vacuumed_files = delta_table.vacuum(
            dry_run=False,
        )

        metrics["numFilesVacuumed"] = len(vacuumed_files)

        return metrics

    def delete(self, hyper_slice: HyperSlice) -> dict[str, Any]:
        """Delete data from Delta table

        Args:
            hyper_slice (HyperSlice): Hyper slice to delete.
            If None, all data will be deleted.

        Returns:
            dict[str, any]: Delete metrics.

            https://docs.databricks.com/gcp/en/delta/history#operation-metrics-keys
        """
        if hyper_slice is None or hyper_slice == [()]:
            predicate = None
        else:
            predicate = _dnf_to_sql(hyper_slice)

        return self.delta_table.delete(predicate)
