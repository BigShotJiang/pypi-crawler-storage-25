from pathlib import Path
from typing import TYPE_CHECKING

import datamazing.pandas as pdz
import pandas as pd

if TYPE_CHECKING:
    from datazone.db.snapshot import SnapshotDatabaseClient

from datazone.db.base import BaseDatabaseClient
from datazone.db.standard import DatabaseClient
from datazone.deltastorage import HyperSlice


class LocalCopyDatabaseClient(BaseDatabaseClient):
    """Database client that copies  data to a local directory and queries from there.
    Tables are copied on demand when they are queried for the first time.
    """

    def __init__(self, db: "DatabaseClient", copy_dir: str | Path):
        self.db = db

        copy_dir = Path(copy_dir).resolve()
        copy_dir.mkdir(parents=True, exist_ok=True)

        self.local_db = DatabaseClient(
            url=Path(copy_dir).resolve().as_uri(),
            table_prefix=db.table_prefix,
        )

    def snapshot_at(self, snapshot_time: pd.Timestamp) -> "SnapshotDatabaseClient":
        from datazone.db.snapshot import SnapshotDatabaseClient

        return SnapshotDatabaseClient(self, snapshot_time)

    def query(
        self,
        table_name: str,
        time_interval: pdz.TimeInterval | None = None,
        time_travel: pdz.TimeTravel | None = None,
        filters: HyperSlice | None = None,
        columns: list[str] | None = None,
        include_generated_columns: bool = False,
    ) -> pd.DataFrame:
        if table_name not in self.local_db.list_tables():
            self.db.copy(
                target=self.local_db,
                subset=[table_name],
                overwrite=True,
            )

        return self.local_db.query(
            table_name,
            time_interval,
            time_travel,
            filters,
            columns,
            include_generated_columns,
        )

    def list_tables(self):
        return self.db.list_tables()
