from abc import ABC, abstractmethod

import datamazing.pandas as pdz
import pandas as pd

from datazone.deltastorage.slicing import HyperSlice


class BaseDatabaseClient(ABC):
    @abstractmethod
    def query(
        self,
        table_name: str,
        time_interval: pdz.TimeInterval | None = None,
        time_travel: pdz.TimeTravel | None = None,
        filters: HyperSlice | None = None,
        columns: list[str] | None = None,
        include_generated_columns: bool = False,
    ) -> pd.DataFrame:
        ...

    @abstractmethod
    def list_tables(self) -> list[str]:
        ...
