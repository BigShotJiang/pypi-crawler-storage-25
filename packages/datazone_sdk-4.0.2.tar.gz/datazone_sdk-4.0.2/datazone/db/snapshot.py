import datamazing.pandas as pdz
import pandas as pd

from datazone.db.base import BaseDatabaseClient
from datazone.db.standard import DatabaseClient
from datazone.deltastorage.slicing import HyperSlice


class SnapshotDatabaseClient(BaseDatabaseClient):
    """Simulation of data prior to a specific point in time.

    Note: This is not the same as time travelling using an as-of-time. The latter
    returns how the real-world looked at specific point in time (i.e. removing the
    valid-time dimension from the data). Here, we return how the data state looked at a
    specific point in time (i.e. keep the valid-time dimension, but remove all data
    happened after the given point in time).
    """

    def __init__(self, db: "DatabaseClient", snapshot_time: pd.Timestamp):
        self.db = db
        self.snapshot_time = snapshot_time

    def query(
        self,
        table_name: str,
        time_interval: pdz.TimeInterval | None = None,
        time_travel: pdz.TimeTravel | None = None,
        filters: HyperSlice | None = None,
        columns: list[str] | None = None,
        include_generated_columns: bool = False,
    ) -> pd.DataFrame:

        # only keep rows that were valid prior to the snapshot time
        filters = filters or []
        filters.append(("valid_from_time_utc", "<=", self.snapshot_time))

        df = self.db.query(
            table_name,
            time_interval,
            time_travel,
            filters,
            columns,
            include_generated_columns,
        )

        # at the snapshot time, all latest rows were valid until the end-of-time,
        # so we need to simulate this here
        df["valid_to_time_utc"] = df["valid_to_time_utc"].where(
            df["valid_to_time_utc"] <= self.snapshot_time,
            pdz.END_OF_TIME,
        )

        return df

    def list_tables(self):
        return self.db.list_tables()
