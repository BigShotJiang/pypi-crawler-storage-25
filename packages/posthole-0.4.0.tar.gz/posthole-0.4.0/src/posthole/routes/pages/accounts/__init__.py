"""Accounts page: ``/accounts``."""
