"""Settings page: ``/settings``."""
