"""Scenarios page: ``/scenarios``."""
