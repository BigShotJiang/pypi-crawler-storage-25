"""Tests for Google settings and managers using .env.dev configuration."""

import pytest

from project_toolkit.settings.base import get_settings
from project_toolkit.settings.google import GoogleSettings


class TestGoogleSettings:
    """Test GoogleSettings loading from .env.dev."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_loads_service_account_json(self):
        """GOOGLE_SERVICE_ACCOUNT_JSON should be loaded from .env.dev."""
        settings = get_settings()
        assert settings.google.google_service_account_json is not None
        print(f"Service Account JSON: {settings.google.google_service_account_json}")

    def test_loads_test_google_sheet_id(self):
        """TEST_GOOGLE_SHEET_ID should be loaded from .env.dev."""
        settings = get_settings()
        assert settings.google.test_google_sheet_id is not None
        assert len(settings.google.test_google_sheet_id) > 0
        print(f"Test Sheet ID: {settings.google.test_google_sheet_id}")

    def test_google_sheets_manager_from_settings(self):
        """GoogleSheetsManager should be creatable from settings."""
        try:
            from project_toolkit.google.sheet import GoogleSheetsManager

            settings = get_settings()
            manager = GoogleSheetsManager.from_settings(settings.google)
            assert manager.gc is not None
            print("GoogleSheetsManager created from settings OK")
        except (FileNotFoundError, ValueError) as e:
            # Expected if the JSON key file is not present
            print(f"Expected error (credentials file): {e}")
            pytest.skip(f"Skipping: {e}")

    def test_google_sheets_read_test_sheet(self):
        """Read the test Google Sheet using TEST_GOOGLE_SHEET_ID."""
        try:
            from project_toolkit.google.sheet import GoogleSheetsManager

            settings = get_settings()
            sheet_id = settings.google.test_google_sheet_id
            assert sheet_id is not None, "TEST_GOOGLE_SHEET_ID not set"

            manager = GoogleSheetsManager.from_settings(settings.google)
            df = manager.sheet_df(sheet_id=sheet_id)
            print(f"Test sheet has {len(df)} rows and {len(df.columns)} columns")
            print(f"Columns: {list(df.columns)}")
            assert df is not None
        except (FileNotFoundError, ValueError) as e:
            print(f"Expected error (credentials file): {e}")
            pytest.skip(f"Skipping: {e}")
        except Exception as e:
            print(f"Error reading sheet: {e}")
            pytest.skip(f"Skipping: {e}")

    def test_google_drive_manager_from_settings(self):
        """GoogleDriveManager should be creatable from settings."""
        try:
            from project_toolkit.google.drive import GoogleDriveManager

            settings = get_settings()
            manager = GoogleDriveManager.from_settings(settings.google)
            assert manager.service is not None
            print("GoogleDriveManager created from settings OK")
        except (FileNotFoundError, ValueError) as e:
            print(f"Expected error (credentials file): {e}")
            pytest.skip(f"Skipping: {e}")
