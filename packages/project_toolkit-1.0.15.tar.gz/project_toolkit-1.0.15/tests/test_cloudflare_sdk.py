"""Tests for CloudflareSdkClient using the official cloudflare-python SDK.

These tests require valid credentials. Set either:
  - CLOUDFLARE_API_TOKEN + CLOUDFLARE_ACCOUNT_ID  (recommended)
  - R2_ACCESS_TOKEN + R2_ACCOUNT_ID               (legacy)
or place them in config/.env.dev.
"""

import os
import time

import pytest

from project_toolkit.cloudflare.sdk_client import CloudflareSdkClient
from project_toolkit.settings.base import get_settings
from project_toolkit.settings.cloudflare import CloudflareSettings


# ---------------------------------------------------------------------------
# Settings integration
# ---------------------------------------------------------------------------


class TestCloudflareSettingsIntegration:
    """Verify the updated settings load both standard and legacy env vars."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_api_token_property_prefers_standard(self):
        """api_token property returns cloudflare_api_token over r2_access_token."""
        settings = CloudflareSettings(
            cloudflare_api_token="standard-token",
            r2_access_token="legacy-token",
        )
        assert settings.api_token == "standard-token"

    def test_api_token_property_falls_back_to_legacy(self):
        """api_token property falls back to r2_access_token."""
        settings = CloudflareSettings(
            cloudflare_api_token=None,
            r2_access_token="legacy-token",
        )
        assert settings.api_token == "legacy-token"

    def test_account_id_property_prefers_standard(self):
        settings = CloudflareSettings(
            cloudflare_account_id="standard-id",
            r2_account_id="legacy-id",
        )
        assert settings.account_id == "standard-id"

    def test_account_id_property_falls_back_to_legacy(self):
        settings = CloudflareSettings(
            cloudflare_account_id=None,
            r2_account_id="legacy-id",
        )
        assert settings.account_id == "legacy-id"


# ---------------------------------------------------------------------------
# SDK Client construction
# ---------------------------------------------------------------------------


class TestSdkClientConstruction:
    """Test various ways to construct the SDK client."""

    def test_from_settings(self):
        """Client can be created via from_settings()."""
        get_settings.cache_clear()
        settings = get_settings()
        cf_settings = settings.cloudflare
        # Only run if credentials are configured
        if not cf_settings.api_token:
            pytest.skip("No Cloudflare API token configured")
        client = CloudflareSdkClient.from_settings(cf_settings)
        assert client.account_id == cf_settings.account_id

    def test_repr(self):
        """__repr__ doesn't leak full account_id."""
        get_settings.cache_clear()
        settings = get_settings()
        if not settings.cloudflare.api_token:
            pytest.skip("No Cloudflare API token configured")
        client = CloudflareSdkClient.from_settings(settings.cloudflare)
        r = repr(client)
        assert "CloudflareSdkClient" in r
        # Full account_id should NOT appear
        if client.account_id:
            assert client.account_id not in r


# ---------------------------------------------------------------------------
# Live API tests (require credentials)
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def sdk_client():
    """Module-scoped SDK client, skips if no credentials."""
    get_settings.cache_clear()
    settings = get_settings()
    if not settings.cloudflare.api_token:
        pytest.skip("No Cloudflare API token configured")
    return CloudflareSdkClient.from_settings(settings.cloudflare)


class TestSdkClientLive:
    """Live API tests — only run when valid credentials are available."""

    def test_verify_token(self, sdk_client):
        result = sdk_client.verify_token()
        assert result is not None
        print(f"Token verify: {result}")

    def test_list_accounts(self, sdk_client):
        accounts = sdk_client.list_accounts()
        assert isinstance(accounts, list)
        assert len(accounts) > 0
        print(f"Accounts: {accounts[0].get('name', 'N/A')}")

    def test_get_account_id(self, sdk_client):
        account_id = sdk_client.get_account_id()
        assert account_id is not None
        assert len(account_id) > 0
        print(f"Account ID: {account_id[:8]}...")

    def test_list_zones(self, sdk_client):
        zones = sdk_client.list_zones()
        assert isinstance(zones, list)
        if zones:
            print(f"First zone: {zones[0].get('name', 'N/A')}")
        else:
            print("No zones found (OK)")

    def test_list_r2_buckets(self, sdk_client):
        buckets = sdk_client.list_r2_buckets()
        assert isinstance(buckets, list)
        if buckets:
            print(f"Buckets: {[b.get('name', 'N/A') for b in buckets]}")
        else:
            print("No R2 buckets found (OK)")

    def test_r2_bucket_lifecycle(self, sdk_client):
        """Create, get, and delete an R2 bucket."""
        bucket_name = f"test-sdk-{int(time.time())}"
        try:
            # Create
            created = sdk_client.create_r2_bucket(bucket_name)
            print(f"Created bucket: {created}")

            # Get
            bucket_info = sdk_client.get_r2_bucket(bucket_name)
            assert bucket_info.get("name") == bucket_name
            print(f"Got bucket: {bucket_info}")

            # Verify in list
            buckets = sdk_client.list_r2_buckets()
            names = [b.get("name") for b in buckets]
            assert bucket_name in names

        finally:
            # Clean up
            try:
                sdk_client.delete_r2_bucket(bucket_name)
                print(f"Deleted bucket: {bucket_name}")
            except Exception as e:
                print(f"Cleanup failed (may already be deleted): {e}")
