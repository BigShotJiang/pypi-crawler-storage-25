"""Tests for Vault integration: reading secrets from HashiCorp Vault."""

import pytest

from project_toolkit.settings.base import get_settings
from project_toolkit.settings.vault import VaultSettings


class TestVaultSettings:

    def setup_method(self):
        get_settings.cache_clear()

    def test_vault_settings_loaded(self):
        """VAULT_ADDR and VAULT_TOKEN should load from .env.dev."""
        settings = get_settings()
        assert settings.vault.vault_addr is not None, "VAULT_ADDR not loaded"
        assert settings.vault.vault_token is not None, "VAULT_TOKEN not loaded"
        assert settings.vault.is_configured
        print(f"VAULT_ADDR: {settings.vault.vault_addr}")
        print(f"VAULT_TOKEN: {settings.vault.vault_token[:10]}...")

    def test_vault_client_authenticated(self):
        """Should create an authenticated Vault client."""
        settings = get_settings()
        client = settings.vault.get_vault_client()
        assert client is not None, (
            "Vault client is None — is the Vault server running at "
            f"{settings.vault.vault_addr}?"
        )
        assert client.is_authenticated()
        print("Vault client authenticated ✓")

    def test_read_secret_my_credentials(self):
        """Read 'my-credentials' secret (like: vault kv get secret/my-credentials)."""
        settings = get_settings()
        secret = settings.vault.read_secret("secret/my-credentials")
        assert secret is not None, (
            "Secret is None — is the Vault server running and the secret stored?"
        )
        assert "username" in secret, f"Expected 'username', got: {list(secret.keys())}"
        assert "password" in secret, f"Expected 'password', got: {list(secret.keys())}"
        print(f"Secret keys: {list(secret.keys())}")
        print(f"Username: {secret['username']}")
        print(f"Password: {'*' * len(secret['password'])}")

    def test_read_secret_gcp_credentials(self):
        """Read GCP credentials (like: vault kv get secret/gcp/credentials)."""
        settings = get_settings()
        secret = settings.vault.read_secret("secret/gcp/credentials")
        if secret is None:
            pytest.skip("secret/gcp/credentials not found in Vault — skipping")
        print(f"GCP secret keys: {list(secret.keys())}")

    def test_read_secret_with_data_prefix(self):
        """Passing 'secret/data/my-credentials' should also work (strips /data/)."""
        settings = get_settings()
        secret = settings.vault.read_secret("secret/data/my-credentials")
        assert secret is not None
        assert "username" in secret
        print(f"With /data/ prefix: {list(secret.keys())}")

    def test_read_secret_not_configured(self):
        """Should return None when Vault is not configured."""
        vs = VaultSettings(vault_addr=None, vault_token=None)
        assert not vs.is_configured
        assert vs.read_secret("secret/anything") is None
        print("Not configured → None ✓")


class TestVaultReadField:
    """Test read_field() — like: vault kv get -field=KEY path."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_read_field_username(self):
        """Read username field from my-credentials."""
        settings = get_settings()
        username = settings.vault.read_field("secret/my-credentials", "username")
        assert username is not None
        assert username == "admin"
        print(f"read_field username: {username}")

    def test_read_field_password(self):
        """Read password field from my-credentials."""
        settings = get_settings()
        password = settings.vault.read_field("secret/my-credentials", "password")
        assert password is not None
        assert len(password) > 0
        print(f"read_field password: {'*' * len(password)}")

    def test_read_field_nonexistent_returns_default(self):
        """Missing field should return default value."""
        settings = get_settings()
        result = settings.vault.read_field("secret/my-credentials", "nonexistent_field")
        assert result is None
        result = settings.vault.read_field("secret/my-credentials", "nonexistent_field", "fallback")
        assert result == "fallback"
        print("Missing field → default ✓")

    def test_read_field_not_configured(self):
        """Should return default when Vault is not configured."""
        vs = VaultSettings(vault_addr=None, vault_token=None)
        result = vs.read_field("secret/anything", "key", "default")
        assert result == "default"
        print("Not configured → default ✓")
