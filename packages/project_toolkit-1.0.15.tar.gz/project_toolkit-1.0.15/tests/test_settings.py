"""Tests for the centralized settings system."""

import os
import pytest

from project_toolkit.settings.base import AppSettings, get_settings
from project_toolkit.settings.cloudflare import CloudflareSettings
from project_toolkit.settings.google import GoogleSettings
from project_toolkit.settings.path import PathSettings
from project_toolkit.settings.vault import VaultSettings
from project_toolkit.settings.wan_ip import WanIpSettings


class TestSettingsLoading:
    """Test that settings load correctly from .env.dev."""

    def setup_method(self):
        """Clear cached settings before each test."""
        get_settings.cache_clear()

    def test_settings_loads_from_env_dev(self):
        """Settings should load values from config/.env.dev."""
        settings = get_settings()
        assert isinstance(settings, AppSettings)
        # Verify R2 values loaded from .env.dev
        assert settings.cloudflare.r2_access_token is not None
        assert settings.cloudflare.r2_account_id is not None
        print(f"R2 Access Token loaded: {settings.cloudflare.r2_access_token[:8]}...")
        print(f"R2 Account ID loaded: {settings.cloudflare.r2_account_id[:8]}...")

    def test_settings_loads_google_config(self):
        """Google settings should load from .env.dev."""
        settings = get_settings()
        assert settings.google.google_service_account_json is not None
        assert settings.google.test_google_sheet_id is not None
        print(f"Google SA JSON: {settings.google.google_service_account_json}")
        print(f"Test Sheet ID: {settings.google.test_google_sheet_id}")

    def test_settings_loads_vault_config(self):
        """Vault settings should load from .env.dev."""
        settings = get_settings()
        assert settings.vault.vault_addr is not None
        assert settings.vault.vault_token is not None
        assert settings.vault.is_configured is True
        print(f"Vault ADDR: {settings.vault.vault_addr}")

    def test_settings_loads_wan_ip_config(self):
        """WAN IP settings should load from .env.dev."""
        settings = get_settings()
        assert settings.wan_ip.wan_ip_log_dir is not None
        assert len(settings.wan_ip.wan_ip_services_v4) > 0
        assert len(settings.wan_ip.wan_ip_services_v6) > 0
        print(f"WAN IP Log Dir: {settings.wan_ip.wan_ip_log_dir}")

    def test_settings_caching(self):
        """get_settings() should return the same cached instance."""
        settings1 = get_settings()
        settings2 = get_settings()
        assert settings1 is settings2

    def test_settings_cache_clear(self):
        """After cache_clear(), a new instance should be created."""
        settings1 = get_settings()
        get_settings.cache_clear()
        settings2 = get_settings()
        assert settings1 is not settings2


class TestSettingsModels:
    """Test individual settings model defaults and validation."""

    def test_path_settings_defaults(self):
        """PathSettings should have sensible defaults."""
        ps = PathSettings()
        assert ps.default_root_dir == "~/"
        assert ps.root_dir is None
        assert ps.data_dir is None
        assert ps.project_name is None
        assert ps.subproject is None

    def test_cloudflare_settings_defaults(self):
        """CloudflareSettings should default to None."""
        cs = CloudflareSettings()
        assert cs.r2_access_token is None
        assert cs.r2_account_id is None
        assert cs.r2_domain is None

    def test_google_settings_defaults(self):
        """GoogleSettings should default to None."""
        gs = GoogleSettings()
        assert gs.google_service_account_json is None
        assert gs.test_google_sheet_id is None

    def test_vault_settings_defaults(self):
        """VaultSettings should default to unconfigured."""
        vs = VaultSettings()
        assert vs.vault_addr is None
        assert vs.vault_token is None
        assert vs.is_configured is False

    def test_vault_settings_configured(self):
        """VaultSettings should be configured when both addr and token are set."""
        vs = VaultSettings(
            vault_addr="http://vault:8200",
            vault_token="test-token",
        )
        assert vs.is_configured is True

    def test_wan_ip_settings_defaults(self):
        """WanIpSettings should have default services."""
        ws = WanIpSettings()
        assert ws.wan_ip_log_dir == "/tmp/ip-logs"
        assert len(ws.wan_ip_services_v4) == 3
        assert len(ws.wan_ip_services_v6) == 3
        assert ws.wan_ip_timeout == 10


class TestEnvironmentDetection:
    """Test environment-aware config loading."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_non_airflow_environment(self):
        """Without AIRFLOW_HOME, airflow_home should be None."""
        # Ensure AIRFLOW_HOME is not set
        old = os.environ.pop("AIRFLOW_HOME", None)
        try:
            get_settings.cache_clear()
            settings = get_settings()
            assert settings.airflow_home is None
        finally:
            if old is not None:
                os.environ["AIRFLOW_HOME"] = old

    def test_airflow_environment_sets_defaults(self):
        """With AIRFLOW_HOME set, path defaults should be overridden."""
        old = os.environ.get("AIRFLOW_HOME")
        os.environ["AIRFLOW_HOME"] = "/opt/airflow"
        try:
            get_settings.cache_clear()
            settings = get_settings()
            assert settings.airflow_home == "/opt/airflow"
            # Airflow validator should set path defaults
            assert settings.path_config.root_dir == "/opt/airflow"
            assert settings.path_config.data_dir == "/opt/airflow/data"
        finally:
            get_settings.cache_clear()
            if old is not None:
                os.environ["AIRFLOW_HOME"] = old
            else:
                os.environ.pop("AIRFLOW_HOME", None)


class TestSettingsOverride:
    """Test that environment variables override .env file values."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_env_var_overrides_dotenv(self):
        """Environment variables should take priority over .env file."""
        override_token = "TEST_OVERRIDE_TOKEN_12345"
        old = os.environ.get("R2_ACCESS_TOKEN")
        os.environ["R2_ACCESS_TOKEN"] = override_token
        try:
            get_settings.cache_clear()
            settings = get_settings()
            assert settings.cloudflare.r2_access_token == override_token
        finally:
            get_settings.cache_clear()
            if old is not None:
                os.environ["R2_ACCESS_TOKEN"] = old
            else:
                os.environ.pop("R2_ACCESS_TOKEN", None)


class TestDynamicEnv:
    """Test the settings.env() method for dynamic env var access."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_env_reads_from_dotenv(self):
        """env() should read values from .env.dev file."""
        settings = get_settings()
        token = settings.env("R2_ACCESS_TOKEN")
        assert token is not None
        assert len(token) > 0
        print(f"env('R2_ACCESS_TOKEN'): {token[:8]}...")

    def test_env_reads_vault_addr(self):
        """env() should read VAULT_ADDR from .env.dev."""
        settings = get_settings()
        addr = settings.env("VAULT_ADDR")
        assert addr is not None
        assert "8200" in addr
        print(f"env('VAULT_ADDR'): {addr}")

    def test_env_returns_default_for_missing(self):
        """env() should return default for non-existent keys."""
        settings = get_settings()
        result = settings.env("TOTALLY_NONEXISTENT_KEY_12345")
        assert result is None
        result = settings.env("TOTALLY_NONEXISTENT_KEY_12345", "fallback")
        assert result == "fallback"
        print("Missing key → default ✓")

    def test_env_var_overrides_dotenv(self):
        """Real env var should take priority over .env value."""
        os.environ["R2_ACCESS_TOKEN"] = "OVERRIDE_VALUE"
        try:
            get_settings.cache_clear()
            settings = get_settings()
            assert settings.env("R2_ACCESS_TOKEN") == "OVERRIDE_VALUE"
        finally:
            os.environ.pop("R2_ACCESS_TOKEN", None)
            get_settings.cache_clear()
        print("Env var override ✓")

    def test_env_works_for_undefined_keys(self):
        """env() should read keys not defined as pydantic fields."""
        os.environ["OPENAI_API_KEY"] = "sk-test-123"
        try:
            get_settings.cache_clear()
            settings = get_settings()
            assert settings.env("OPENAI_API_KEY") == "sk-test-123"
        finally:
            os.environ.pop("OPENAI_API_KEY", None)
            get_settings.cache_clear()
        print("Undefined key via env var ✓")

