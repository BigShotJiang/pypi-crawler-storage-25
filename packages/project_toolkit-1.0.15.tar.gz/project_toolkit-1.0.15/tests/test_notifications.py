"""Tests for the notifications module — context, discord notifier, and adapters."""

from datetime import datetime
from unittest.mock import patch, MagicMock

import pytest

from project_toolkit.notifications.context import NotificationContext
from project_toolkit.notifications.discord import DiscordNotifier, STATUS_COLORS, STATUS_EMOJI
from project_toolkit.notifications.adapters.prefect import PrefectAdapter
from project_toolkit.notifications.adapters.airflow import AirflowAdapter


class TestNotificationContext:
    """Test the shared NotificationContext dataclass."""

    def test_minimal_context(self):
        """Context should only require status, flow_name, and run_name."""
        ctx = NotificationContext(
            status="failure",
            flow_name="etl_pipeline",
            run_name="run-001",
        )
        assert ctx.status == "failure"
        assert ctx.flow_name == "etl_pipeline"
        assert ctx.run_name == "run-001"
        assert ctx.error_message is None
        assert ctx.run_id is None
        assert ctx.start_time is None
        assert ctx.extra_fields == []

    def test_full_context(self):
        """Context should accept all optional fields."""
        now = datetime(2026, 3, 8, 14, 0, 0)
        ctx = NotificationContext(
            status="success",
            flow_name="daily_sync",
            run_name="run-xyz",
            error_message="All good",
            run_id="abc-123",
            start_time=now,
            extra_fields=[{"name": "Env", "value": "prod", "inline": True}],
        )
        assert ctx.status == "success"
        assert ctx.run_id == "abc-123"
        assert ctx.start_time == now
        assert len(ctx.extra_fields) == 1
        assert ctx.extra_fields[0]["name"] == "Env"


class TestDiscordNotifier:
    """Test DiscordNotifier embed construction and send logic."""

    def test_init_requires_webhook_url(self):
        """Empty or None webhook_url should raise ValueError."""
        with pytest.raises(ValueError, match="webhook_url must be provided"):
            DiscordNotifier(webhook_url="")
        with pytest.raises(ValueError, match="webhook_url must be provided"):
            DiscordNotifier(webhook_url=None)

    def test_build_embed_failure(self):
        """Failure embed should have red colour and correct fields."""
        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        ctx = NotificationContext(
            status="failure",
            flow_name="etl",
            run_name="run-1",
            error_message="Connection refused",
        )
        embed = notifier._build_embed(ctx)

        assert embed["color"] == STATUS_COLORS["failure"]
        assert "🔴" in embed["title"]
        assert "FAILURE" in embed["title"]

        field_names = [f["name"] for f in embed["fields"]]
        assert "Flow / DAG" in field_names
        assert "Run" in field_names
        assert "Status" in field_names
        assert "Message" in field_names

        message_field = next(f for f in embed["fields"] if f["name"] == "Message")
        assert message_field["value"] == "Connection refused"

    def test_build_embed_success_with_extras(self):
        """Success embed should have green colour and include extra fields."""
        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        now = datetime(2026, 3, 8, 14, 0, 0)
        ctx = NotificationContext(
            status="success",
            flow_name="sync",
            run_name="run-2",
            run_id="id-456",
            start_time=now,
            extra_fields=[
                {"name": "Env", "value": "staging", "inline": True},
            ],
        )
        embed = notifier._build_embed(ctx)

        assert embed["color"] == STATUS_COLORS["success"]
        assert "🟢" in embed["title"]

        field_names = [f["name"] for f in embed["fields"]]
        assert "Run ID" in field_names
        assert "Started" in field_names
        assert "Env" in field_names

    @patch("project_toolkit.notifications.discord.requests")
    def test_notify_sends_post(self, mock_requests):
        """notify() should POST the embed payload to the webhook URL."""
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_requests.post.return_value = mock_response

        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        ctx = NotificationContext(
            status="failure",
            flow_name="pipeline",
            run_name="run-99",
        )
        result = notifier.notify(ctx)

        assert result is True
        mock_requests.post.assert_called_once()
        call_kwargs = mock_requests.post.call_args
        assert call_kwargs[0][0] == "https://example.com/webhook"
        payload = call_kwargs[1]["json"]
        assert payload["username"] == "Pipeline Bot"
        assert len(payload["embeds"]) == 1

    @patch("project_toolkit.notifications.discord.requests")
    def test_notify_handles_http_error(self, mock_requests):
        """notify() should return False on non-2xx status."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        mock_requests.post.return_value = mock_response

        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        ctx = NotificationContext(status="success", flow_name="f", run_name="r")
        result = notifier.notify(ctx)

        assert result is False

    @patch("project_toolkit.notifications.discord.requests")
    def test_notify_handles_request_exception(self, mock_requests):
        """notify() should return False when requests raises."""
        import requests as real_requests
        mock_requests.post.side_effect = real_requests.exceptions.ConnectionError("fail")
        mock_requests.RequestException = real_requests.RequestException

        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        ctx = NotificationContext(status="failure", flow_name="f", run_name="r")
        result = notifier.notify(ctx)

        assert result is False


class TestPrefectAdapter:
    """Test PrefectAdapter translates Prefect hook args correctly."""

    def _make_mocks(self):
        flow = MagicMock()
        flow.name = "my_prefect_flow"
        flow_run = MagicMock()
        flow_run.name = "crimson-fox"
        flow_run.id = "abc-123-def"
        flow_run.start_time = datetime(2026, 3, 8, 12, 0, 0)
        state = MagicMock()
        state.message = "Flow run crashed!"
        return flow, flow_run, state

    def test_build_context(self):
        """_build_context should map Prefect objects to NotificationContext."""
        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        adapter = PrefectAdapter(notifier)
        flow, flow_run, state = self._make_mocks()

        ctx = adapter._build_context("failure", flow, flow_run, state)

        assert ctx.status == "failure"
        assert ctx.flow_name == "my_prefect_flow"
        assert ctx.run_name == "crimson-fox"
        assert ctx.run_id == "abc-123-def"
        assert ctx.error_message == "Flow run crashed!"
        assert ctx.start_time == datetime(2026, 3, 8, 12, 0, 0)
        assert len(ctx.extra_fields) == 1
        assert ctx.extra_fields[0]["name"] == "Environment"

    @patch("project_toolkit.notifications.discord.requests")
    def test_on_failure_calls_notify(self, mock_requests):
        """on_failure should send a notification with status='failure'."""
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_requests.post.return_value = mock_response

        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        adapter = PrefectAdapter(notifier)
        flow, flow_run, state = self._make_mocks()

        adapter.on_failure(flow, flow_run, state)

        mock_requests.post.assert_called_once()
        payload = mock_requests.post.call_args[1]["json"]
        assert "FAILURE" in payload["embeds"][0]["title"]

    @patch("project_toolkit.notifications.discord.requests")
    def test_on_success_calls_notify(self, mock_requests):
        """on_success should send a notification with status='success'."""
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_requests.post.return_value = mock_response

        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        adapter = PrefectAdapter(notifier)
        flow, flow_run, state = self._make_mocks()

        adapter.on_success(flow, flow_run, state)

        mock_requests.post.assert_called_once()
        payload = mock_requests.post.call_args[1]["json"]
        assert "SUCCESS" in payload["embeds"][0]["title"]


class TestAirflowAdapter:
    """Test AirflowAdapter translates Airflow context dict correctly."""

    def _make_context(self):
        ti = MagicMock()
        ti.task_id = "extract_data"
        ti.operator = "PythonOperator"
        ti.try_number = 2
        ti.start_date = datetime(2026, 3, 8, 10, 30, 0)

        dag = MagicMock()
        dag.dag_id = "daily_etl"

        dag_run = MagicMock()
        dag_run.run_id = "manual__2026-03-08T10:30:00"

        return {
            "task_instance": ti,
            "dag": dag,
            "dag_run": dag_run,
            "exception": ValueError("Data validation failed"),
            "reason": "task_failure",
        }

    def test_build_context(self):
        """_build_context should map Airflow context to NotificationContext."""
        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        adapter = AirflowAdapter(notifier)
        context = self._make_context()

        ctx = adapter._build_context("failure", context)

        assert ctx.status == "failure"
        assert ctx.flow_name == "daily_etl"
        assert ctx.run_name == "extract_data"
        assert ctx.run_id == "manual__2026-03-08T10:30:00"
        assert "Data validation failed" in ctx.error_message
        assert ctx.start_time == datetime(2026, 3, 8, 10, 30, 0)
        assert len(ctx.extra_fields) == 3

        field_names = [f["name"] for f in ctx.extra_fields]
        assert "Operator" in field_names
        assert "Try #" in field_names
        assert "Reason" in field_names

    @patch("project_toolkit.notifications.discord.requests")
    def test_on_failure_calls_notify(self, mock_requests):
        """on_failure should send a notification with status='failure'."""
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_requests.post.return_value = mock_response

        notifier = DiscordNotifier(webhook_url="https://example.com/webhook")
        adapter = AirflowAdapter(notifier)
        context = self._make_context()

        adapter.on_failure(context)

        mock_requests.post.assert_called_once()
        payload = mock_requests.post.call_args[1]["json"]
        assert "FAILURE" in payload["embeds"][0]["title"]

        # Verify embed fields contain Airflow-specific info
        fields = payload["embeds"][0]["fields"]
        field_names = [f["name"] for f in fields]
        assert "Flow / DAG" in field_names
        assert "Operator" in field_names
