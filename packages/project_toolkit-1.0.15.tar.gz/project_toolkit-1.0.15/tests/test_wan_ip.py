"""Tests for the IP Tool module (WanIP + IPChangeDetector)."""

import json
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from project_toolkit.ip_tool.wan_ip import WanIP
from project_toolkit.ip_tool.detector import IPChangeDetector
from project_toolkit.settings.wan_ip import WanIpSettings


TEST_DATA_DIR = "/tmp/ip-tool-test-data"
TEST_PROJECT = "test-ip-logs"
TEST_SUBPROJECT = "unit"


@pytest.fixture(autouse=True)
def cleanup():
    """Clean up test data directory before and after each test."""
    shutil.rmtree(TEST_DATA_DIR, ignore_errors=True)
    yield
    shutil.rmtree(TEST_DATA_DIR, ignore_errors=True)


# ======================================================================
# WanIP Fetcher
# ======================================================================

class TestWanIP:
    """Test WanIP with mocked subprocess."""

    def _make_wan_ip(self, has_h3=False):
        """Return a WanIP instance with curl detection stubbed out."""
        with patch.object(WanIP, "_find_curl", return_value="/usr/bin/curl"):
            with patch.object(WanIP, "_check_h3_support", return_value=has_h3):
                return WanIP()

    @patch("project_toolkit.ip_tool.wan_ip.subprocess.check_output")
    def test_ipv4(self, mock_check_output):
        mock_check_output.return_value = "1.2.3.4\n"
        wan_ip_inst = self._make_wan_ip()
        assert wan_ip_inst.ipv4() == "1.2.3.4"

    @patch("project_toolkit.ip_tool.wan_ip.subprocess.check_output")
    def test_ipv6(self, mock_check_output):
        mock_check_output.return_value = "2001:db8::1\n"
        wan_ip_inst = self._make_wan_ip()
        assert wan_ip_inst.ipv6() == "2001:db8::1"

    @patch("project_toolkit.ip_tool.wan_ip.subprocess.check_output")
    def test_ipv6_returns_unreachable_for_v4_response(self, mock_check_output):
        """When curl -6 returns an IPv4 address, ipv6() should return UNREACHABLE."""
        mock_check_output.return_value = "1.2.3.4\n"
        wan_ip_inst = self._make_wan_ip()
        assert wan_ip_inst.ipv6() == WanIP.UNREACHABLE

    @patch("project_toolkit.ip_tool.wan_ip.subprocess.check_output")
    def test_fetch_all_sequence(self, mock_check_output):
        """fetch_all should run v4 checks before v6 checks."""
        mock_check_output.side_effect = [
            "1.2.3.4\n",       # h2v4
            "1.2.3.4\n",       # h3v4
            "2001:db8::1\n",   # h2v6
            "2001:db8::1\n",   # h3v6
        ]
        wan_ip_inst = self._make_wan_ip(has_h3=True)
        result = wan_ip_inst.fetch_all()
        # Verify sequence indirectly through the side_effect usage
        assert result["h2v4"] == "1.2.3.4"
        assert result["h3v4"] == "1.2.3.4"
        assert result["h2v6"] == "2001:db8::1"
        assert result["h3v6"] == "2001:db8::1"


# ======================================================================
# IPChangeDetector
# ======================================================================

class TestIPChangeDetector:
    """Test IPChangeDetector with a mock WanIP instance."""

    def _make_detector(self, fetch_all_return=None, report_parts=None):
        """Create a detector with a mock WanIP, storing in TEST_DATA_DIR."""
        mock_wan_ip = MagicMock(spec=WanIP)
        mock_wan_ip.fetch_all.return_value = fetch_all_return or {"h2v4": "1.2.3.4"}
        mock_wan_ip.get_report_parts.return_value = report_parts or ["v4: 1.2.3.4"]
        mock_wan_ip.get_report_string.return_value = "v4: 1.2.3.4"

        return IPChangeDetector(
            project_name=TEST_PROJECT,
            subproject=TEST_SUBPROJECT,
            data_dir=TEST_DATA_DIR,
            wan_ip=mock_wan_ip,
        )

    def test_storage_dir(self):
        detector = self._make_detector()
        expected = (Path(TEST_DATA_DIR) / TEST_PROJECT / TEST_SUBPROJECT).resolve()
        assert detector.storage_dir == expected

    def test_no_project_saves_to_cwd(self, tmp_path, monkeypatch):
        """When no project_name is given, files go in the current directory."""
        monkeypatch.chdir(tmp_path)
        detector = IPChangeDetector(
            wan_ip=MagicMock(
                spec=WanIP,
                fetch_all=MagicMock(return_value={"h2v4": "1.1.1.1"}),
                get_report_parts=MagicMock(return_value=["v4: 1.1.1.1"]),
                get_report_string=MagicMock(return_value="v4: 1.1.1.1"),
            ),
        )
        assert detector.storage_dir == tmp_path.resolve()
        changed, _ = detector.check_and_record()
        assert changed is True
        assert (tmp_path / "current.json").exists()
        assert (tmp_path / "history.txt").exists()

    def test_get_history_line(self):
        detector = self._make_detector()
        line = detector.get_history_line(timestamp="2024-01-01 12:00:00")
        assert line == "2024-01-01 12:00:00 | v4: 1.2.3.4"


# ======================================================================
# Lazy wan_ip Instance
# ======================================================================

class TestWanIpLazyObject:
    """Test the 'wan_ip' lazy object in ip_tool.__init__."""

    @patch("project_toolkit.ip_tool.wan_ip.subprocess.check_output")
    @patch.object(WanIP, "_find_curl", return_value="/usr/bin/curl")
    def test_wan_ip_attributes(self, _curl, mock_check_output):
        from project_toolkit.ip_tool import wan_ip
        mock_check_output.return_value = "8.8.8.8\n"
        
        # Test property-style access (no parens)
        assert wan_ip.ipv4 == "8.8.8.8"
        assert wan_ip.ipv6 == WanIP.UNREACHABLE
        
        # Test delegating method calls (like .get_report_string())
        # because the proxy also uses __getattr__ for method lookup
        with patch.object(WanIP, "get_report_string", return_value="v4: 8.8.8.8"):
            assert wan_ip.get_report_string() == "v4: 8.8.8.8"
