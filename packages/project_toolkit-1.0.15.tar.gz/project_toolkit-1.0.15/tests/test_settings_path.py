"""Tests for PathSettings and DataPathConfig using settings."""

import os
import pathlib
import shutil
import pytest

from project_toolkit.settings.base import get_settings
from project_toolkit.settings.path import PathSettings
from project_toolkit.project_path import DataPathConfig


class TestPathSettings:
    """Test PathSettings model."""

    def test_defaults(self):
        """PathSettings should have sensible defaults."""
        ps = PathSettings()
        assert ps.default_root_dir == "~/"
        assert ps.root_dir is None
        assert ps.data_dir is None

    def test_custom_values(self):
        """PathSettings should accept custom values."""
        ps = PathSettings(
            root_dir="/custom/root",
            data_dir="/custom/data",
            project_name="test-proj",
            subproject="sub",
        )
        assert ps.root_dir == "/custom/root"
        assert ps.data_dir == "/custom/data"
        assert ps.project_name == "test-proj"
        assert ps.subproject == "sub"


class TestDataPathConfigFromSettings:
    """Test DataPathConfig.from_settings() factory method."""

    def test_from_settings_basic(self):
        """Create DataPathConfig from PathSettings."""
        ps = PathSettings(
            root_dir="/tmp",
            data_dir="/tmp/data",
            project_name="test-from-settings",
        )
        # Ensure data dir exists
        pathlib.Path("/tmp/data").mkdir(parents=True, exist_ok=True)

        dpc = DataPathConfig.from_settings(ps, project_name="test-from-settings")
        assert dpc.project_name == "test-from-settings"
        assert dpc.data_dir() == pathlib.Path("/tmp/data").resolve()

        # Cleanup
        shutil.rmtree("/tmp/data/test-from-settings", ignore_errors=True)

    def test_from_settings_with_subproject(self):
        """Create DataPathConfig from PathSettings with subproject."""
        ps = PathSettings(
            data_dir="/tmp/data",
            project_name="proj-settings",
            subproject="sub-settings",
        )
        pathlib.Path("/tmp/data").mkdir(parents=True, exist_ok=True)

        dpc = DataPathConfig.from_settings(ps)
        assert dpc.project_name == "proj-settings"
        assert dpc.subproject == "sub-settings"
        sub_dir = dpc.sub_project_dir()
        assert sub_dir == (pathlib.Path("/tmp/data") / "proj-settings" / "sub-settings").resolve()

        # Cleanup
        shutil.rmtree("/tmp/data/proj-settings", ignore_errors=True)

    def test_from_settings_override_project_name(self):
        """project_name argument should override PathSettings.project_name."""
        ps = PathSettings(
            data_dir="/tmp/data",
            project_name="original",
        )
        pathlib.Path("/tmp/data").mkdir(parents=True, exist_ok=True)

        dpc = DataPathConfig.from_settings(ps, project_name="overridden")
        assert dpc.project_name == "overridden"

        # Cleanup
        shutil.rmtree("/tmp/data/overridden", ignore_errors=True)

    def test_from_settings_requires_project_name(self):
        """Should raise ValueError if no project_name anywhere."""
        ps = PathSettings(data_dir="/tmp/data")
        with pytest.raises(ValueError, match="project_name must be provided"):
            DataPathConfig.from_settings(ps)

    def test_backward_compat_direct_init(self):
        """Direct init should still work (backward compatibility)."""
        data_root = pathlib.Path("/tmp/data")
        data_root.mkdir(parents=True, exist_ok=True)

        dpc = DataPathConfig(
            project_name="compat-test",
            data_dir=str(data_root),
            subproject="sub",
        )
        assert dpc.data_dir() == data_root.resolve()
        assert dpc.project_dir() == (data_root / "compat-test").resolve()
        assert dpc.sub_project_dir() == (data_root / "compat-test" / "sub").resolve()

        # Cleanup
        shutil.rmtree(data_root / "compat-test", ignore_errors=True)

    def test_from_settings_get_settings_integration(self):
        """Test using get_settings() to create DataPathConfig."""
        get_settings.cache_clear()
        settings = get_settings()
        ps = settings.path_config

        # Override project_name since .env.dev doesn't set one
        data_root = pathlib.Path("/tmp/data-integration")
        data_root.mkdir(parents=True, exist_ok=True)

        ps_custom = PathSettings(
            root_dir=ps.root_dir,
            data_dir=str(data_root),
            project_name="integration-test",
        )
        dpc = DataPathConfig.from_settings(ps_custom)
        assert dpc.project_name == "integration-test"
        proj_dir = dpc.project_dir()
        assert proj_dir.exists()

        # Cleanup
        shutil.rmtree(data_root, ignore_errors=True)
