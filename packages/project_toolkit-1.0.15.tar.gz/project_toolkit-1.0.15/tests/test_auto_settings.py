"""Tests for auto-initialized settings singleton."""

import os
import pytest

from project_toolkit.settings.base import get_settings


class TestAutoSettings:
    """Test that `from project_toolkit import settings` auto-initializes."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_auto_settings_import(self):
        """Importing settings should work without explicit setup."""
        from project_toolkit import settings

        settings._reset()
        assert settings.cloudflare is not None
        assert settings.google is not None
        assert settings.vault is not None
        print("Auto-init settings ✓")

    def test_auto_settings_env(self):
        """settings.env() should work on the auto-initialized singleton."""
        from project_toolkit import settings

        settings._reset()
        token = settings.env("R2_ACCESS_TOKEN")
        assert token is not None
        print(f"Auto settings.env(): {token[:8]}...")

    def test_auto_settings_vault(self):
        """settings.vault should be accessible from the singleton."""
        from project_toolkit import settings

        settings._reset()
        assert settings.vault.is_configured
        print(f"Vault configured: {settings.vault.vault_addr}")

    def test_auto_settings_dynamic_key(self):
        """settings.env() should read undefined keys from env vars."""
        os.environ["GEMINI_API_KEY"] = "gemini-test-key"
        try:
            from project_toolkit import settings

            settings._reset()
            assert settings.env("GEMINI_API_KEY") == "gemini-test-key"
        finally:
            os.environ.pop("GEMINI_API_KEY", None)
        print("Dynamic key via auto-settings ✓")

    def test_manual_override(self):
        """Manual construction should still work for custom settings."""
        from project_toolkit import settings
        from project_toolkit.settings.base import AppSettings
        from project_toolkit.settings.cloudflare import CloudflareSettings
        from project_toolkit.settings.google import GoogleSettings
        from project_toolkit.settings.path import PathSettings
        from project_toolkit.settings.vault import VaultSettings
        from project_toolkit.settings.wan_ip import WanIpSettings

        # Build with custom cloudflare settings
        custom = AppSettings(
            path_config=PathSettings(),
            cloudflare=CloudflareSettings(
                r2_access_token="custom-token",
                r2_account_id="custom-id",
            ),
            google=GoogleSettings(),
            vault=VaultSettings(),
            wan_ip=WanIpSettings(),
        )
        assert custom.cloudflare.r2_access_token == "custom-token"
        assert custom.cloudflare.r2_account_id == "custom-id"
        print("Manual override ✓")

        # Reset for other tests
        get_settings.cache_clear()
        settings._reset()
