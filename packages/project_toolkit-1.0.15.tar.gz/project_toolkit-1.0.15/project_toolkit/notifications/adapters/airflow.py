"""
Airflow adapter — translates Airflow callback context into NotificationContext.

Airflow callbacks receive a single ``context`` dict with keys like
``task_instance``, ``dag_run``, ``dag``, ``exception``, etc. This adapter
extracts the relevant fields and produces a :class:`NotificationContext`.

Usage::

    # Zero-config — reads DISCORD_AIRFLOW_WEBHOOK_URL from env / .env
    from project_toolkit.notifications.adapters.airflow import AirflowAdapter

    hooks = AirflowAdapter()

    # Or pass an explicit notifier
    from project_toolkit.notifications.discord import DiscordNotifier

    notifier = DiscordNotifier(webhook_url="...")
    hooks = AirflowAdapter(notifier)

    with DAG(
        dag_id="my_dag",
        on_failure_callback=hooks.on_failure,
        on_success_callback=hooks.on_success,
    ) as dag:
        ...
"""

from __future__ import annotations

import logging
from typing import Optional

from project_toolkit.notifications.context import NotificationContext
from project_toolkit.notifications.discord import DiscordNotifier

logger = logging.getLogger(__name__)

_DEFAULT_ENV_KEY = "DISCORD_AIRFLOW_WEBHOOK_URL"


class AirflowAdapter:
    """Thin adapter from Airflow callback context to :class:`DiscordNotifier`.

    When *notifier* is omitted the adapter auto-creates a
    :class:`DiscordNotifier` using the ``DISCORD_AIRFLOW_WEBHOOK_URL``
    environment variable (or ``.env`` value).

    Args:
        notifier: A configured :class:`DiscordNotifier` instance.
            If ``None``, one is created from
            ``DISCORD_AIRFLOW_WEBHOOK_URL``.
    """

    def __init__(self, notifier: Optional[DiscordNotifier] = None):
        if notifier is None:
            from project_toolkit.settings import get_settings
            settings = get_settings()
            webhook_url = settings.env(_DEFAULT_ENV_KEY, "")
            notifier = DiscordNotifier(webhook_url=webhook_url)
        self.notifier = notifier

    def _build_context(self, status: str, context: dict) -> NotificationContext:
        """Map Airflow context dict to a framework-agnostic context."""
        ti = context.get("task_instance")
        dag_run = context.get("dag_run")
        dag = context.get("dag")

        return NotificationContext(
            status=status,
            flow_name=getattr(dag, "dag_id", "unknown"),
            run_name=getattr(ti, "task_id", "unknown"),
            run_id=getattr(dag_run, "run_id", None),
            error_message=str(context.get("exception", "")) or None,
            start_time=getattr(ti, "start_date", None),
            extra_fields=[
                {"name": "Operator", "value": getattr(ti, "operator", "N/A"), "inline": True},
                {"name": "Try #", "value": str(getattr(ti, "try_number", 1)), "inline": True},
                {"name": "Reason", "value": str(context.get("reason", "N/A")), "inline": False},
            ],
        )

    # ------------------------------------------------------------------
    # Airflow callbacks — signature: fn(context)
    # ------------------------------------------------------------------

    def on_failure(self, context: dict) -> None:
        """Callback for ``on_failure_callback``."""
        logger.info("Airflow on_failure callback triggered")
        self.notifier.notify(self._build_context("failure", context))

    def on_success(self, context: dict) -> None:
        """Callback for ``on_success_callback``."""
        logger.info("Airflow on_success callback triggered")
        self.notifier.notify(self._build_context("success", context))
