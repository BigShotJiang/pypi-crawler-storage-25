"""
Normalized notification context — framework-agnostic data contract.

Both framework adapters (Prefect, Airflow, etc.) produce a
``NotificationContext`` and the notifier consumes it, keeping the
two sides fully decoupled.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional


@dataclass
class NotificationContext:
    """Framework-agnostic notification payload.

    Attributes:
        status: One of ``"failure"``, ``"success"``, or ``"warning"``.
        flow_name: DAG name or Prefect flow name.
        run_name: Run ID, task instance ID, or human-readable run name.
        error_message: Optional error/state message.
        run_id: Optional unique run identifier.
        start_time: Optional run start timestamp.
        extra_fields: Additional embed fields ``[{"name": …, "value": …, "inline": …}]``.
    """

    status: str
    flow_name: str
    run_name: str
    error_message: Optional[str] = None
    run_id: Optional[str] = None
    start_time: Optional[datetime] = None
    extra_fields: List[Dict] = field(default_factory=list)
