"""
Discord webhook notifier — sends rich embeds built from NotificationContext.

Usage::

    from project_toolkit.notifications.discord import DiscordNotifier
    from project_toolkit.notifications.context import NotificationContext

    notifier = DiscordNotifier(webhook_url="https://discord.com/api/webhooks/...")
    notifier.notify(NotificationContext(
        status="failure",
        flow_name="etl_pipeline",
        run_name="run-abc-123",
        error_message="Task timed out",
    ))
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests

from project_toolkit.notifications.context import NotificationContext

logger = logging.getLogger(__name__)

# Status → Discord embed colour (decimal)
STATUS_COLORS = {
    "failure": 0xE74C3C,   # red
    "success": 0x2ECC71,   # green
    "warning": 0xF39C12,   # amber
}

STATUS_EMOJI = {
    "failure": "🔴",
    "success": "🟢",
    "warning": "🟡",
}


class DiscordNotifier:
    """Sends Discord webhook messages built from a :class:`NotificationContext`.

    Can be initialized with an explicit webhook URL or via the project's
    settings helpers::

        from project_toolkit import settings
        from project_toolkit.notifications.discord import DiscordNotifier

        notifier = DiscordNotifier(
            webhook_url=settings.env("DISCORD_PREFECT_WEBHOOK_URL"),
        )

    Args:
        webhook_url: Full Discord webhook URL.
        username: Bot display name shown in Discord.  Defaults to
            ``"Pipeline Bot"``.
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        webhook_url: str,
        username: str = "Pipeline Bot",
        timeout: int = 10,
    ):
        if not webhook_url:
            raise ValueError(
                "webhook_url must be provided. "
                "Set DISCORD_PREFECT_WEBHOOK_URL or DISCORD_AIRFLOW_WEBHOOK_URL "
                "in your environment or config/.env.dev file."
            )
        self.webhook_url = webhook_url
        self.username = username
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def notify(self, ctx_or_message) -> bool:
        """Send a Discord notification as a plain string message or NotificationContext embed.

        Args:
            ctx_or_message: NotificationContext or string message.

        Returns:
            True if the webhook accepted the message, False otherwise.
        """
        if isinstance(ctx_or_message, str):
            # Send plain content as bare message, not embed
            return self.send({"content": ctx_or_message})
        if isinstance(ctx_or_message, NotificationContext):
            ctx = ctx_or_message
        else:
            raise TypeError("notify() expects a NotificationContext or a string message")
        embed = self._build_embed(ctx)
        payload = self._build_payload(embeds=[embed])
        return self.send(payload)

    def send(self, payload: Dict[str, Any]) -> bool:
        """Low-level POST to the Discord webhook.

        Args:
            payload: JSON-serializable dict matching the Discord
                webhook schema.

        Returns:
            ``True`` on HTTP 2xx, ``False`` otherwise.
        """
        try:
            response = requests.post(
                self.webhook_url,
                json=payload,
                timeout=self.timeout,
            )
            if response.status_code in (200, 204):
                logger.info("Discord notification sent successfully")
                return True
            else:
                logger.warning(
                    "Discord webhook returned %s: %s",
                    response.status_code,
                    response.text,
                )
                return False
        except requests.RequestException as exc:
            logger.error("Failed to send Discord notification: %s", exc)
            return False

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _build_embed(self, ctx: NotificationContext) -> Dict[str, Any]:
        """Translate a :class:`NotificationContext` into a Discord embed dict."""
        emoji = STATUS_EMOJI.get(ctx.status, "ℹ️")
        color = STATUS_COLORS.get(ctx.status, 0x95A5A6)

        fields: List[Dict[str, Any]] = [
            {"name": "Flow / DAG", "value": ctx.flow_name, "inline": True},
            {"name": "Run", "value": ctx.run_name, "inline": True},
            {"name": "Status", "value": ctx.status.upper(), "inline": True},
        ]

        if ctx.run_id:
            fields.append({"name": "Run ID", "value": ctx.run_id, "inline": False})

        if ctx.error_message:
            # Truncate long messages to stay within Discord embed limits (1024 chars)
            message = ctx.error_message[:1024]
            fields.append({"name": "Message", "value": message, "inline": False})

        if ctx.start_time:
            fields.append({
                "name": "Started",
                "value": ctx.start_time.isoformat(),
                "inline": True,
            })

        # Append any adapter-provided extra fields
        for ef in ctx.extra_fields:
            fields.append({
                "name": ef.get("name", "Extra"),
                "value": str(ef.get("value", "")),
                "inline": ef.get("inline", True),
            })

        embed: Dict[str, Any] = {
            "title": f"{emoji} Pipeline Notification — {ctx.status.upper()}",
            "color": color,
            "fields": fields,
        }

        return embed

    def _build_payload(
        self,
        embeds: List[Dict[str, Any]],
        content: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Wrap embeds into a full webhook payload."""
        payload: Dict[str, Any] = {
            "username": self.username,
            "embeds": embeds,
        }
        if content:
            payload["content"] = content
        return payload
