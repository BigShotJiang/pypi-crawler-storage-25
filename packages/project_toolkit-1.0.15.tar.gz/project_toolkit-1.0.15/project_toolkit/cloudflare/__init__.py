"""Cloudflare API clients.

Three client implementations are available:

- :class:`CloudflareSdkClient` — **recommended**, uses the official
  ``cloudflare`` Python SDK.  Provides typed access to Zones, DNS, R2,
  KV, D1, and more.
- :class:`CloudflareRequestsClient` — lightweight HTTP client using
  ``requests`` for the v4 REST API.
- :class:`CloudflareBoto3Client` — S3-compatible R2 client using
  ``boto3``.
"""

# Lazy imports so optional dependencies don't break the package
# when only a subset is installed.

def __getattr__(name: str):
    if name == "CloudflareSdkClient":
        from project_toolkit.cloudflare.sdk_client import CloudflareSdkClient
        return CloudflareSdkClient
    if name == "CloudflareRequestsClient":
        from project_toolkit.cloudflare.requests_client import CloudflareRequestsClient
        return CloudflareRequestsClient
    if name == "CloudflareBoto3Client":
        from project_toolkit.cloudflare.boto3_client import CloudflareBoto3Client
        return CloudflareBoto3Client
    if name == "CloudflareTokenManager":
        from project_toolkit.cloudflare.tokens import CloudflareTokenManager
        return CloudflareTokenManager
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "CloudflareSdkClient",
    "CloudflareRequestsClient",
    "CloudflareBoto3Client",
    "CloudflareTokenManager",
]
