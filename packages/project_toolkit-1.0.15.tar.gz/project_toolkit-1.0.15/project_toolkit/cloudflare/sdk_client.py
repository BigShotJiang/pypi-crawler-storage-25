"""Cloudflare API client using the official cloudflare-python SDK.

This client wraps the official ``cloudflare`` package and provides a
convenience layer that automatically loads credentials from:
  1. Explicit constructor arguments
  2. CloudflareSettings (pydantic-settings)
  3. Environment variables: CLOUDFLARE_API_TOKEN, CLOUDFLARE_ACCOUNT_ID

The official SDK already reads CLOUDFLARE_API_TOKEN by default, so
zero-config usage is supported out of the box.

Example usage::

    # Zero-config (reads CLOUDFLARE_API_TOKEN & CLOUDFLARE_ACCOUNT_ID from env)
    client = CloudflareSdkClient()

    # Explicit
    client = CloudflareSdkClient(api_token="...", account_id="...")

    # From settings
    from project_toolkit.settings import get_settings
    client = CloudflareSdkClient.from_settings(get_settings().cloudflare)
"""

import logging
import os
from typing import Any, Optional

from cloudflare import Cloudflare

logger = logging.getLogger(__name__)


class CloudflareSdkClient:
    """High-level Cloudflare API client backed by the official SDK.

    Wraps ``cloudflare.Cloudflare`` and stores the ``account_id`` so
    callers don't have to pass it with every request.
    """

    def __init__(
        self,
        api_token: Optional[str] = None,
        account_id: Optional[str] = None,
        zone_id: Optional[str] = None,
    ):
        """Initialise the client.

        Resolution order for each parameter:

        1. Explicit argument
        2. CloudflareSettings env-var mapping
           (``CLOUDFLARE_API_TOKEN`` / ``CLOUDFLARE_ACCOUNT_ID``)
        3. Legacy env vars (``R2_ACCESS_TOKEN`` / ``R2_ACCOUNT_ID``)

        For ``zone_id``, the default is read from ``CLOUDFLARE_ZONE_ID``.
        You can also use domain-specific env vars (e.g.
        ``LGNAT_ZONE_ID``) via :meth:`resolve_zone_id`.

        The official SDK **also** reads ``CLOUDFLARE_API_TOKEN``
        automatically, so passing ``api_token=None`` is fine when the
        env var is set.
        """
        # --- Resolve api_token ---
        if api_token is None:
            api_token = os.environ.get("CLOUDFLARE_API_TOKEN")
        if api_token is None:
            api_token = os.environ.get("R2_ACCESS_TOKEN")
        if api_token is None:
            try:
                from project_toolkit.settings import get_settings

                _settings = get_settings().cloudflare
                api_token = _settings.cloudflare_api_token or _settings.r2_access_token
            except Exception:
                pass

        # --- Resolve account_id ---
        if account_id is None:
            account_id = os.environ.get("CLOUDFLARE_ACCOUNT_ID")
        if account_id is None:
            account_id = os.environ.get("R2_ACCOUNT_ID")
        if account_id is None:
            try:
                from project_toolkit.settings import get_settings

                _settings = get_settings().cloudflare
                account_id = (
                    _settings.cloudflare_account_id or _settings.r2_account_id
                )
            except Exception:
                pass

        # --- Resolve zone_id ---
        if zone_id is None:
            zone_id = os.environ.get("CLOUDFLARE_ZONE_ID")
        if zone_id is None:
            try:
                from project_toolkit.settings import get_settings

                _settings = get_settings().cloudflare
                zone_id = _settings.cloudflare_zone_id
            except Exception:
                pass

        # The SDK will raise its own error if api_token is still None
        self._cf = Cloudflare(api_token=api_token)
        self.account_id = account_id
        self.zone_id = zone_id
        logger.debug(
            "CloudflareSdkClient initialised (account_id=%s, zone_id=%s)",
            account_id[:8] + "..." if account_id else None,
            zone_id[:8] + "..." if zone_id else None,
        )

    @classmethod
    def from_settings(cls, cloudflare_settings) -> "CloudflareSdkClient":
        """Create client from a CloudflareSettings instance.

        Args:
            cloudflare_settings: A CloudflareSettings instance.

        Returns:
            Configured CloudflareSdkClient.
        """
        api_token = (
            cloudflare_settings.cloudflare_api_token
            or cloudflare_settings.r2_access_token
        )
        account_id = (
            cloudflare_settings.cloudflare_account_id
            or cloudflare_settings.r2_account_id
        )
        zone_id = getattr(cloudflare_settings, "cloudflare_zone_id", None)
        return cls(api_token=api_token, account_id=account_id, zone_id=zone_id)

    # -- Raw SDK access ------------------------------------------------

    @property
    def client(self) -> Cloudflare:
        """Return the underlying ``cloudflare.Cloudflare`` instance.

        Use this for any API call not surfaced by a helper method::

            cf = CloudflareSdkClient()
            zones = list(cf.client.zones.list())
        """
        return self._cf

    # -- Zone ID resolution ---------------------------------------------

    def resolve_zone_id(
        self,
        zone_id: Optional[str] = None,
        zone_key: Optional[str] = None,
    ) -> str:
        """Resolve a zone ID from arguments, env vars, or the default.

        Resolution order:

        1. Explicit ``zone_id`` argument.
        2. ``{zone_key}_ZONE_ID`` env var (e.g. ``LGNAT_ZONE_ID``).
        3. Default ``self.zone_id`` (from ``CLOUDFLARE_ZONE_ID``).

        Args:
            zone_id: Explicit zone ID (highest priority).
            zone_key: A short key to look up ``{KEY}_ZONE_ID`` from env.
                      For example, ``zone_key="LGNAT"`` reads
                      ``LGNAT_ZONE_ID``.

        Returns:
            The resolved zone ID string.

        Raises:
            ValueError: If no zone ID can be resolved.
        """
        if zone_id:
            return zone_id
        if zone_key:
            env_name = f"{zone_key.upper()}_ZONE_ID"
            from_env = os.environ.get(env_name)
            if from_env:
                return from_env
            # Also try settings
            try:
                from project_toolkit.settings.base import get_settings

                val = get_settings().env(env_name)
                if val:
                    return val
            except Exception:
                pass
        if self.zone_id:
            return self.zone_id
        raise ValueError(
            "zone_id is required. Pass it explicitly, set CLOUDFLARE_ZONE_ID, "
            "or use zone_key (e.g. zone_key='LGNAT' reads LGNAT_ZONE_ID)."
        )

    # -- Token / Account helpers ----------------------------------------

    def verify_token(self) -> dict:
        """Verify the current API token.

        Returns:
            Token verify result dict.

        Raises:
            cloudflare.APIError: on failure.
        """
        result = self._cf.user.tokens.verify()
        return result

    def list_accounts(self) -> list[dict]:
        """List all accounts the token has access to.

        Returns:
            List of account dicts with ``id`` and ``name`` keys.
        """
        accounts = []
        for account in self._cf.accounts.list():
            accounts.append(
                account.to_dict() if hasattr(account, "to_dict") else account
            )
        return accounts

    def get_account_id(self) -> Optional[str]:
        """Return the configured account_id, or discover it.

        If ``account_id`` was not provided at init, the first account
        returned by the API is used and cached.
        """
        if self.account_id:
            return self.account_id
        accounts = self.list_accounts()
        if accounts:
            self.account_id = accounts[0]["id"]
            return self.account_id
        return None

    # -- Zones ----------------------------------------------------------

    def list_zones(self, **params) -> list[dict]:
        """List all zones.

        Args:
            **params: Optional filter params (name, status, etc.)

        Returns:
            List of zone dicts.
        """
        zones = []
        for zone in self._cf.zones.list(**params):
            zones.append(
                zone.to_dict() if hasattr(zone, "to_dict") else zone
            )
        return zones

    def get_zone(self, zone_id: str) -> dict:
        """Get details for a single zone.

        Args:
            zone_id: The zone identifier.

        Returns:
            Zone dict.
        """
        zone = self._cf.zones.get(zone_id=zone_id)
        return zone.to_dict() if hasattr(zone, "to_dict") else zone

    # -- DNS Records ----------------------------------------------------

    def list_dns_records(
        self,
        zone_id: Optional[str] = None,
        *,
        zone_key: Optional[str] = None,
        **params,
    ) -> list[dict]:
        """List DNS records for a zone.

        Args:
            zone_id: The zone identifier. If ``None``, resolved via
                ``zone_key`` or ``CLOUDFLARE_ZONE_ID``.
            zone_key: Short key to look up ``{KEY}_ZONE_ID`` from env.
            **params: Optional filter params (type, name, etc.)

        Returns:
            List of DNS record dicts.
        """
        zone_id = self.resolve_zone_id(zone_id, zone_key)
        records = []
        for record in self._cf.dns.records.list(zone_id=zone_id, **params):
            records.append(
                record.to_dict() if hasattr(record, "to_dict") else record
            )
        return records

    def create_dns_record(
        self,
        zone_id: Optional[str] = None,
        *,
        name: str,
        type: str,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
        zone_key: Optional[str] = None,
        **params,
    ) -> dict:
        """Create a DNS record.

        Args:
            zone_id: The zone identifier. If ``None``, resolved via
                ``zone_key`` or ``CLOUDFLARE_ZONE_ID``.
            name: DNS record name (e.g. ``example.com``).
            type: Record type (A, AAAA, CNAME, TXT, etc.).
            content: Record content / value.
            proxied: Whether the record is proxied through Cloudflare.
            ttl: Time to live (1 = automatic).
            zone_key: Short key to look up ``{KEY}_ZONE_ID`` from env.
            **params: Additional params.

        Returns:
            Created DNS record dict.
        """
        zone_id = self.resolve_zone_id(zone_id, zone_key)
        record = self._cf.dns.records.create(
            zone_id=zone_id,
            name=name,
            type=type,
            content=content,
            proxied=proxied,
            ttl=ttl,
            **params,
        )
        return record.to_dict() if hasattr(record, "to_dict") else record

    def update_dns_record(
        self,
        zone_id: Optional[str] = None,
        dns_record_id: str = "",
        *,
        name: str,
        type: str,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
        zone_key: Optional[str] = None,
        **params,
    ) -> dict:
        """Update a DNS record.

        Args:
            zone_id: The zone identifier. If ``None``, resolved via
                ``zone_key`` or ``CLOUDFLARE_ZONE_ID``.
            dns_record_id: The DNS record identifier.
            name: DNS record name.
            type: Record type.
            content: Record content / value.
            proxied: Whether the record is proxied.
            ttl: Time to live (1 = automatic).
            zone_key: Short key to look up ``{KEY}_ZONE_ID`` from env.
            **params: Additional params.

        Returns:
            Updated DNS record dict.
        """
        zone_id = self.resolve_zone_id(zone_id, zone_key)
        record = self._cf.dns.records.update(
            dns_record_id=dns_record_id,
            zone_id=zone_id,
            name=name,
            type=type,
            content=content,
            proxied=proxied,
            ttl=ttl,
            **params,
        )
        return record.to_dict() if hasattr(record, "to_dict") else record

    def delete_dns_record(
        self,
        zone_id: Optional[str] = None,
        dns_record_id: str = "",
        *,
        zone_key: Optional[str] = None,
    ) -> dict:
        """Delete a DNS record.

        Args:
            zone_id: The zone identifier. If ``None``, resolved via
                ``zone_key`` or ``CLOUDFLARE_ZONE_ID``.
            dns_record_id: The DNS record identifier.
            zone_key: Short key to look up ``{KEY}_ZONE_ID`` from env.

        Returns:
            Deletion result dict.
        """
        zone_id = self.resolve_zone_id(zone_id, zone_key)
        result = self._cf.dns.records.delete(
            dns_record_id=dns_record_id,
            zone_id=zone_id,
        )
        return result.to_dict() if hasattr(result, "to_dict") else result

    def add_github_pages_record(
        self,
        name: str,
        zone_id: Optional[str] = None,
        *,
        zone_key: Optional[str] = None,
    ) -> dict:
        """Add an A record pointing to GitHub Pages.

        Adds an A record pointing to GitHub Pages IP (185.199.108.153)
        with proxied=True (orange cloud).

        Args:
            name: DNS record name (e.g. ``@`` or ``example.com``).
            zone_id: The zone identifier. If ``None``, resolved via
                ``zone_key`` or ``CLOUDFLARE_ZONE_ID``.
            zone_key: Short key to look up ``{KEY}_ZONE_ID`` from env.

        Returns:
            Created DNS record dict.
        """
        return self.create_dns_record(
            zone_id=zone_id,
            name=name,
            type="A",
            content="185.199.108.153",
            proxied=True,
            zone_key=zone_key,
        )

    # -- R2 Buckets -----------------------------------------------------

    def _require_account_id(self) -> str:
        """Return account_id or raise ValueError."""
        account_id = self.get_account_id()
        if not account_id:
            raise ValueError(
                "account_id is required. Set CLOUDFLARE_ACCOUNT_ID env var "
                "or pass account_id to the constructor."
            )
        return account_id

    def list_r2_buckets(self) -> list[dict]:
        """List R2 buckets for the configured account.

        Returns:
            List of bucket dicts.
        """
        account_id = self._require_account_id()
        result = self._cf.r2.buckets.list(account_id=account_id)
        buckets = result.buckets if hasattr(result, "buckets") else result
        if buckets is None:
            return []
        return [
            b.to_dict() if hasattr(b, "to_dict") else b for b in buckets
        ]

    def create_r2_bucket(self, name: str, **params) -> dict:
        """Create an R2 bucket.

        Args:
            name: Bucket name.
            **params: Additional params (e.g. location_hint).

        Returns:
            Created bucket dict.
        """
        account_id = self._require_account_id()
        bucket = self._cf.r2.buckets.create(
            account_id=account_id,
            name=name,
            **params,
        )
        return bucket.to_dict() if hasattr(bucket, "to_dict") else bucket

    def delete_r2_bucket(self, bucket_name: str) -> None:
        """Delete an R2 bucket.

        Args:
            bucket_name: Bucket name.
        """
        account_id = self._require_account_id()
        self._cf.r2.buckets.delete(
            bucket_name=bucket_name,
            account_id=account_id,
        )

    def get_r2_bucket(self, bucket_name: str) -> dict:
        """Get details about an R2 bucket.

        Args:
            bucket_name: Bucket name.

        Returns:
            Bucket details dict.
        """
        account_id = self._require_account_id()
        bucket = self._cf.r2.buckets.get(
            bucket_name=bucket_name,
            account_id=account_id,
        )
        return bucket.to_dict() if hasattr(bucket, "to_dict") else bucket

    # -- KV Namespaces --------------------------------------------------

    def list_kv_namespaces(self) -> list[dict]:
        """List Workers KV namespaces.

        Returns:
            List of namespace dicts with ``id`` and ``title`` keys.
        """
        account_id = self._require_account_id()
        namespaces = []
        for ns in self._cf.kv.namespaces.list(account_id=account_id):
            namespaces.append(
                ns.to_dict() if hasattr(ns, "to_dict") else ns
            )
        return namespaces

    def kv_get(self, namespace_id: str, key_name: str) -> str:
        """Read a value from Workers KV.

        Args:
            namespace_id: The KV namespace identifier.
            key_name: The key to read.

        Returns:
            The value as a string.
        """
        account_id = self._require_account_id()
        return self._cf.kv.namespaces.values.get(
            key_name=key_name,
            account_id=account_id,
            namespace_id=namespace_id,
        )

    def kv_put(
        self,
        namespace_id: str,
        key_name: str,
        value: str,
        **params,
    ) -> None:
        """Write a value to Workers KV.

        Args:
            namespace_id: The KV namespace identifier.
            key_name: The key to write.
            value: The value to store.
            **params: Additional params (metadata, expiration, etc.).
        """
        account_id = self._require_account_id()
        self._cf.kv.namespaces.values.update(
            key_name=key_name,
            account_id=account_id,
            namespace_id=namespace_id,
            value=value,
            metadata="",
            **params,
        )

    def kv_delete(self, namespace_id: str, key_name: str) -> None:
        """Delete a key from Workers KV.

        Args:
            namespace_id: The KV namespace identifier.
            key_name: The key to delete.
        """
        account_id = self._require_account_id()
        self._cf.kv.namespaces.values.delete(
            key_name=key_name,
            account_id=account_id,
            namespace_id=namespace_id,
        )

    # -- D1 Databases ---------------------------------------------------

    def list_d1_databases(self) -> list[dict]:
        """List D1 databases.

        Returns:
            List of database dicts.
        """
        account_id = self._require_account_id()
        databases = []
        for db in self._cf.d1.database.list(account_id=account_id):
            databases.append(
                db.to_dict() if hasattr(db, "to_dict") else db
            )
        return databases

    def d1_query(
        self, database_id: str, sql: str, params: Optional[list] = None
    ) -> list[dict]:
        """Execute a SQL query against a D1 database.

        Args:
            database_id: The D1 database identifier.
            sql: The SQL statement.
            params: Optional list of bind parameters.

        Returns:
            List of result dicts.
        """
        account_id = self._require_account_id()
        kwargs: dict[str, Any] = {
            "account_id": account_id,
            "database_id": database_id,
            "sql": sql,
        }
        if params is not None:
            kwargs["params"] = params
        result = self._cf.d1.database.query(**kwargs)
        if isinstance(result, list):
            return [
                r.to_dict() if hasattr(r, "to_dict") else r for r in result
            ]
        return result.to_dict() if hasattr(result, "to_dict") else result

    def __repr__(self) -> str:
        acct = self.account_id[:8] + "..." if self.account_id else "None"
        return f"<CloudflareSdkClient account_id={acct}>"
