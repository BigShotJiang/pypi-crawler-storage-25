from typing import Optional, List, Dict, Any
from project_toolkit.cloudflare.sdk_client import CloudflareSdkClient

class CloudflareTokenManager:
    """Manages Cloudflare Tokens and extracts key information."""
    
    def __init__(self, client: Optional[CloudflareSdkClient] = None):
        """Initialize the Token Manager.
        
        Args:
            client: An existing CloudflareSdkClient instance. If not provided, a new one is created.
        """
        self.cf_client = client or CloudflareSdkClient()

    def token_json_short(self, token: Any) -> Dict[str, Any]:
        """Format token into a short JSON dictionary with extracted permissions."""
        tk = token.to_dict() if hasattr(token, "to_dict") else token
        
        # Extract permissions from policies
        permissions = []
        if "policies" in tk:
            for policy in tk["policies"]:
                if "permission_groups" in policy:
                    for group in policy["permission_groups"]:
                        if "name" in group:
                            permissions.append(group["name"])
        
        # Append extracted permissions to the full json
        tk["permissions"] = list(set(permissions))
        
        # Remove policies key as requested
        if "policies" in tk:
            del tk["policies"]
        
        # Helper to convert datetimes to strings
        def serialize_short(val):
            if isinstance(val, dict):
                return {k: serialize_short(v) for k, v in val.items()}
            if isinstance(val, list):
                return [serialize_short(v) for v in val]
            if hasattr(val, "isoformat"):
                return str(val)
            return val
            
        return serialize_short(tk)

    def list_user_tokens(self) -> List[Dict[str, Any]]:
        """List all user tokens.
        
        Returns:
            List of dictionaries containing fully sorted JSON data of tokens.
        """
        # We need to make sure we iterate properly as it returns an iterable or pagination object
        tokens = self.cf_client.client.user.tokens.list()
        return [self.token_json_short(tk) for tk in tokens]

    def list_account_tokens(self, account_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all account tokens for a given account.
        
        Args:
            account_id: The Cloudflare account ID. Assumes default if not provided.
            
        Returns:
            List of dictionaries containing fully sorted JSON data of tokens.
        """
        account_id = account_id or self.cf_client.get_account_id()
        if not account_id:
            raise ValueError("account_id is required to list account tokens.")
        
        tokens = self.cf_client.client.accounts.tokens.list(account_id=account_id)
        return [self.token_json_short(tk) for tk in tokens]
