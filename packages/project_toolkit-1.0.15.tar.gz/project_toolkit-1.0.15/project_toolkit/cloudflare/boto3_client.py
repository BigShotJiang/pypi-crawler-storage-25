import boto3
import hashlib
import mimetypes
import os
import logging
from typing import Optional

import requests

logger = logging.getLogger(__name__)


class CloudflareBoto3Client:
    """Cloudflare R2 client using boto3 S3-compatible API.

    Can be initialized with explicit args or from CloudflareSettings:

        # Zero-config (reads R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY & CLOUDFLARE_ACCOUNT_ID)
        client = CloudflareBoto3Client()

        # Explicit
        client = CloudflareBoto3Client(aws_access_key_id="...", aws_secret_access_key="...", account_id="...")

        # From settings
        from project_toolkit.settings import get_settings
        client = CloudflareBoto3Client.from_settings(get_settings().cloudflare)
    """

    def __init__(
        self,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        account_id: Optional[str] = None,
    ):
        if aws_access_key_id is None or aws_secret_access_key is None or account_id is None:
            from project_toolkit.settings import get_settings
            _settings = get_settings().cloudflare
            
            if aws_access_key_id is None:
                aws_access_key_id = _settings.r2_access_key_id
            if aws_secret_access_key is None:
                aws_secret_access_key = _settings.r2_secret_access_key
            if account_id is None:
                account_id = _settings.account_id

        if not aws_access_key_id or not aws_secret_access_key or not account_id:
            raise ValueError(
                "aws_access_key_id, aws_secret_access_key, and account_id must be provided or set via "
                "R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, and R2_ACCOUNT_ID (or CLOUDFLARE_ACCOUNT_ID)"
            )

        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.account_id = account_id
        self.s3_client = None
        self._setup_s3_client()

    @classmethod
    def from_settings(cls, cloudflare_settings) -> "CloudflareBoto3Client":
        """Create client from a CloudflareSettings instance.

        Args:
            cloudflare_settings: A CloudflareSettings instance.

        Returns:
            Configured CloudflareBoto3Client.
        """
        return cls(
            aws_access_key_id=getattr(cloudflare_settings, "r2_access_key_id", None),
            aws_secret_access_key=getattr(cloudflare_settings, "r2_secret_access_key", None),
            account_id=cloudflare_settings.account_id,
        )

    def _setup_s3_client(self):
        if self.aws_access_key_id and self.aws_secret_access_key and self.account_id:
            self.s3_client = boto3.client(
                "s3",
                endpoint_url=f"https://{self.account_id}.r2.cloudflarestorage.com",
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key,
            )

    def list_buckets(self):
        if self.s3_client:
            buckets = self.s3_client.list_buckets()
            return buckets["Buckets"]
        return None

    def upload_file(self, bucket_name, key, content, content_type=None):
        if self.s3_client:
            if content_type is None:
                content_type = mimetypes.guess_type(key)[0]
            kwargs = {"Bucket": bucket_name, "Key": key, "Body": content}
            if content_type:
                kwargs["ContentType"] = content_type
            self.s3_client.put_object(**kwargs)
            return True
        return False

    def delete_file(self, bucket_name, key):
        if self.s3_client:
            self.s3_client.delete_object(Bucket=bucket_name, Key=key)
            return True
        return False

    def create_bucket(self, bucket_name):
        if self.s3_client:
            self.s3_client.create_bucket(Bucket=bucket_name)
            return True
        return False

    def delete_bucket(self, bucket_name):
        if self.s3_client:
            self.s3_client.delete_bucket(Bucket=bucket_name)
            return True
        return False