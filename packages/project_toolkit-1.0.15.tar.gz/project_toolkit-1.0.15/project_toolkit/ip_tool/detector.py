"""
IPChangeDetector — detect and record WAN IP address changes.

Uses :class:`~project_toolkit.project_path.DataPathConfig` to manage
the ``current.json`` and ``history.txt`` files under the configured
subproject directory.  When no ``project_name`` is given, files are
saved in the current working directory.

Usage::

    from project_toolkit.ip_tool.detector import IPChangeDetector

    # With project / subproject (uses DataPathConfig)
    detector = IPChangeDetector(project_name="ip-logs", subproject="office")
    changed, results = detector.check_and_record()

    # Without project — saves to current directory
    detector = IPChangeDetector()
    changed, results = detector.check_and_record()
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from project_toolkit.project_path import DataPathConfig
from project_toolkit.ip_tool.wan_ip import WanIP

logger = logging.getLogger(__name__)


class IPChangeDetector:
    """Detect WAN IP changes and persist results to disk.

    Stores a ``current.json`` snapshot and appends to ``history.txt``
    whenever the IP changes.

    Args:
        project_name: Name used by :class:`DataPathConfig` for the data directory.
            If ``None``, files are saved in the current working directory.
        subproject: Optional subproject name for nested storage.
        data_dir: Explicit base data directory (passed through to DataPathConfig).
        root_dir: Explicit root directory (passed through to DataPathConfig).
        wan_ip: A :class:`WanIP` instance.  One is created automatically
                 if not provided.
        create_dirs: Whether to auto-create directories (default ``True``).
    """

    CURRENT_FILE = "current.json"
    HISTORY_FILE = "history.txt"

    def __init__(
        self,
        project_name: Optional[str] = None,
        subproject: Optional[str] = None,
        data_dir: Optional[str] = None,
        root_dir: Optional[str] = None,
        wan_ip: Optional[WanIP] = None,
        create_dirs: bool = True,
    ):
        self.wan_ip = wan_ip or WanIP()
        self._subproject = subproject

        # No project → save in the current working directory
        if project_name is None:
            self._dpc = None
            self._direct_dir = Path.cwd().resolve()
            return

        # Build the DataPathConfig for storage
        dpc_kwargs: dict = dict(
            project_name=project_name,
            create_dirs=create_dirs,
        )
        if subproject:
            dpc_kwargs["subproject"] = subproject
        if data_dir:
            dpc_kwargs["data_dir"] = data_dir
        if root_dir:
            dpc_kwargs["root_dir"] = root_dir

        self._dpc = DataPathConfig(**dpc_kwargs)
        self._direct_dir = None

    # ------------------------------------------------------------------
    # Storage paths
    # ------------------------------------------------------------------

    @property
    def storage_dir(self) -> Path:
        """Return the directory where IP data is stored."""
        if self._direct_dir is not None:
            return self._direct_dir
        if self._subproject:
            return self._dpc.sub_project_dir()
        return self._dpc.project_dir()

    @property
    def current_file(self) -> Path:
        return self.storage_dir / self.CURRENT_FILE

    @property
    def history_file(self) -> Path:
        return self.storage_dir / self.HISTORY_FILE

    # ------------------------------------------------------------------
    # Read / Write helpers
    # ------------------------------------------------------------------

    def load_current(self) -> Optional[dict]:
        """Load the last-saved IP snapshot from ``current.json``.

        Returns ``None`` if the file does not exist or is malformed.
        """
        if not self.current_file.exists():
            return None
        try:
            with open(self.current_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as exc:
            logger.warning("Failed to read %s: %s", self.current_file, exc)
            return None

    def save_current(self, results: dict) -> None:
        """Write *results* to ``current.json``."""
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        with open(self.current_file, "w") as f:
            json.dump(results, f, indent=2)
        logger.debug("Saved current IPs to %s", self.current_file)

    def get_history_line(self, timestamp: Optional[str] = None) -> str:
        """Return the single-line string that would be appended to history.txt."""
        ts = timestamp or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report_str = self.wan_ip.get_report_string()
        return f"{ts} | {report_str}"

    def append_history(self, timestamp: str, report_lines: list[str]) -> None:
        """Append a timestamped entry to ``history.txt``."""
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        # Using '\t'.join to maintain backward-compatible separator for file entries
        report_str = "\t".join(report_lines)
        line = f"{timestamp} | {report_str}\n"
        with open(self.history_file, "a") as f:
            f.write(line)
        logger.debug("Appended to %s", self.history_file)

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    def has_changed(self, new_results: dict) -> bool:
        """Return *True* if *new_results* differ from the stored snapshot."""
        old = self.load_current()
        if old is None:
            return True
        return old != new_results

    def check_and_record(self) -> tuple[bool, dict]:
        """Fetch current IPs, compare with stored, and persist if changed.

        Returns:
            A ``(changed, results)`` tuple.  ``changed`` is *True* when
            the IP snapshot was updated.
        """
        results = self.wan_ip.fetch_all()
        report_lines = self.wan_ip.get_report_parts()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        changed = self.has_changed(results)
        if changed:
            self.save_current(results)
            if report_lines:
                self.append_history(timestamp, report_lines)
            logger.info("IP change detected at %s: %s", timestamp, results)
        else:
            logger.info("IPs unchanged (%s)", timestamp)

        return changed, results

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"IPChangeDetector(storage_dir={self.storage_dir!r}, "
            f"wan_ip={self.wan_ip!r})"
        )
