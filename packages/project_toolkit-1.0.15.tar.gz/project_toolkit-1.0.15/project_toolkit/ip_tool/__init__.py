"""
IP Tool module — fetch and track public WAN IP addresses.

Provides easy access to current IPs via the ``wan_ip`` object.

Quick access::

    from project_toolkit.ip_tool import wan_ip

    wan_ip.ipv4        # Fetches HTTP/2 IPv4
    wan_ip.h3ipv4      # Fetches HTTP/3 IPv4
    wan_ip.get_report_string()

Programmatic usage::

    from project_toolkit.ip_tool import WanIP, IPChangeDetector

    fetcher = WanIP()
    detector = IPChangeDetector(project_name="ip-logs")
"""

from typing import Optional
from project_toolkit.ip_tool.wan_ip import WanIP
from project_toolkit.ip_tool.detector import IPChangeDetector

__all__ = ["WanIP", "IPChangeDetector", "wan_ip"]


class _WanIPProxy:
    """Proxy providing both attribute and method access to WAN IPs."""

    def __init__(self):
        self._instance: Optional[WanIP] = None

    def _get_instance(self) -> WanIP:
        if self._instance is None:
            self._instance = WanIP()
        return self._instance

    def __getattr__(self, name: str):
        # Delegate all other attributes to the WanIP instance
        # Supports: .ipv4(), .fetch_all(), .get_report_string(), etc.
        return getattr(self._get_instance(), name)

    # To support wan_ip.ipv4 as a property (without parens):
    @property
    def ipv4(self) -> str:
        """Fetch IPv4 (attribute access)."""
        return self._get_instance().ipv4()

    @property
    def ipv6(self) -> str:
        """Fetch IPv6 (attribute access)."""
        return self._get_instance().ipv6()

    @property
    def h3ipv4(self) -> str:
        """Fetch HTTP/3 IPv4 (attribute access)."""
        return self._get_instance().h3ipv4()

    @property
    def h3ipv6(self) -> str:
        """Fetch HTTP/3 IPv6 (attribute access)."""
        return self._get_instance().h3ipv6()


# Singleton instance for easy import
wan_ip = _WanIPProxy()
