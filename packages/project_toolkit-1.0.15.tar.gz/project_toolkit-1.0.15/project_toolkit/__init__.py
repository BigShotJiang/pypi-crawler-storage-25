"""
project-toolkit: Modular configuration and utility library.

Quick start — settings auto-initialize, no setup needed::

    from project_toolkit import settings

    # Access any module setting
    print(settings.cloudflare.r2_access_token)

    # Read any env var or .env value dynamically
    print(settings.env("OPENAI_API_KEY"))

    # Read from Vault
    print(settings.vault.read_secret("secret/my-credentials"))
    print(settings.vault.read_field("secret/api", "OPENAI_API_KEY"))

Manual override (e.g., for testing)::

    from project_toolkit import get_settings
    get_settings.cache_clear()
    settings = get_settings()

Explicit env file (when auto-detection fails)::

    from project_toolkit import settings
    settings.configure(env_file="/path/to/your/.env.dev")
"""

from project_toolkit.project_path import DataPathConfig
from project_toolkit.settings import get_settings, AppSettings


class _LazySettings:
    """Proxy that auto-initializes settings on first attribute access.

    This allows ``from project_toolkit import settings`` to work without
    any explicit setup. Settings are created lazily on first use and
    cached via ``get_settings()``.
    """

    __slots__ = ("_settings", "_env_file")

    def __init__(self):
        object.__setattr__(self, "_settings", None)
        object.__setattr__(self, "_env_file", None)

    def _load(self) -> AppSettings:
        s = object.__getattribute__(self, "_settings")
        if s is None:
            env_file = object.__getattribute__(self, "_env_file")
            s = get_settings(env_file=env_file)
            object.__setattr__(self, "_settings", s)
        return s

    def __getattr__(self, name: str):
        return getattr(self._load(), name)

    def __repr__(self) -> str:
        return repr(self._load())

    def __str__(self) -> str:
        return str(self._load())

    def configure(self, env_file: str) -> None:
        """Set an explicit ``.env`` file path and reload settings.

        Use this when auto-detection cannot find your ``config/.env.dev``
        file — for example, when running from a Jupyter notebook or a
        script in a different directory.

        Args:
            env_file: Absolute or relative path to your ``.env`` file.

        Example::

            from project_toolkit import settings

            settings.configure(env_file="/path/to/your/.env.dev")
            print(settings.env("OPENAI_API_KEY"))
        """
        get_settings.cache_clear()
        object.__setattr__(self, "_env_file", env_file)
        object.__setattr__(self, "_settings", None)

    def _reset(self):
        """Reset the lazy proxy (useful for testing)."""
        get_settings.cache_clear()
        object.__setattr__(self, "_settings", None)
        object.__setattr__(self, "_env_file", None)


# Module-level auto-initialized settings singleton
settings = _LazySettings()

# Backward compatibility alias
dpc = DataPathConfig

__all__ = [
    "DataPathConfig",
    "dpc",
    "get_settings",
    "AppSettings",
    "settings",
]