import os
import pathlib

from typing import Optional
from datetime import date


class DataPathConfig:
    """
    A class to manage data directory paths for projects and subprojects.

    Can be initialized with explicit arguments or from pydantic-settings:

        # Explicit
        dpc = DataPathConfig(project_name="my-project", data_dir="/data")

        # From settings
        from project_toolkit.settings import get_settings
        settings = get_settings()
        dpc = DataPathConfig.from_settings(settings.path, project_name="my-project")
    """

    def __init__(
        self,
        project_name: str,
        subproject: Optional[str] = None,
        root_dir: Optional[str] = None,
        data_dir: Optional[str] = None,
        default_root_dir: str = "~/",
        create_dirs: bool = True,
    ):
        """
        Initialize PathConfig with project details and path settings.

        Args:
            project_name: Name of the project (used in path construction).
            subproject: Subproject name for nested folder structure.
            root_dir: Root directory path for data.
            data_dir: Direct data directory path.
            default_root_dir: Fallback root directory if not specified.
            create_dirs: Whether to create project/subproject directories if they don't exist.
        """
        self.project_name = project_name
        self.subproject = subproject
        self.root_dir_arg = root_dir
        self.data_dir_arg = data_dir
        self.default_root_dir = default_root_dir
        self.default_data_dir = os.path.join(self.default_root_dir, "data")

        if self.root_dir_arg is not None:
            self.default_data_dir = os.path.join(self.root_dir_arg, "data")

        self.create_dirs = create_dirs

        # Check if running in an Airflow environment
        if "AIRFLOW_HOME" in os.environ:
            airflow_root_dir = "/opt/airflow"
            self.default_root_dir = airflow_root_dir
            self.default_data_dir = os.path.join(self.default_root_dir, "data")
            if self.root_dir_arg is None:
                self.root_dir_arg = airflow_root_dir
            if self.data_dir_arg is None:
                self.data_dir_arg = os.path.join(airflow_root_dir, "data")

    @classmethod
    def from_settings(
        cls,
        path_settings,
        project_name: Optional[str] = None,
        subproject: Optional[str] = None,
        create_dirs: bool = True,
    ) -> "DataPathConfig":
        """Create a DataPathConfig from a PathSettings instance.

        Args:
            path_settings: A PathSettings instance from pydantic-settings.
            project_name: Override project name (falls back to path_settings.project_name).
            subproject: Override subproject (falls back to path_settings.subproject).
            create_dirs: Whether to create directories.

        Returns:
            A configured DataPathConfig instance.
        """
        name = project_name or path_settings.project_name
        if not name:
            raise ValueError("project_name must be provided either as argument or in PathSettings")

        return cls(
            project_name=name,
            subproject=subproject or path_settings.subproject,
            root_dir=path_settings.root_dir,
            data_dir=path_settings.data_dir,
            default_root_dir=path_settings.default_root_dir,
            create_dirs=create_dirs,
        )

    def _resolve_path(
        self,
        path_source: Optional[str],
        default_path: str,
        base_only: bool = False,
        include_subproject: bool = True,
    ) -> pathlib.Path:
        """
        Resolve a path from a provided path or default.

        Args:
            path_source: Direct path provided.
            default_path: Default path if path_source is not set.
            base_only: If True, return the base path without project/subproject.
            include_subproject: If False, exclude subproject from path.

        Returns:
            Resolved absolute path.

        Raises:
            FileNotFoundError: If the base path does not exist.
            NotADirectoryError: If the resolved path is not a directory.
            RuntimeError: For other path resolution errors.
        """
        path_str = path_source if path_source is not None else default_path

        try:
            path_str = os.path.expanduser(os.path.expandvars(path_str))
            path = pathlib.Path(path_str)

            if base_only:
                if not path.exists():
                    raise FileNotFoundError(f"Base path {path} does not exist")
                if not path.is_dir():
                    raise NotADirectoryError(f"Base path {path} is not a directory")
                return path.resolve()

            if self.project_name:
                path = path / self.project_name
            if include_subproject and self.subproject:
                path = path / self.subproject

            path = path.resolve()

            if self.create_dirs and not path.exists():
                try:
                    path.mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    raise RuntimeError(f"Cannot create directory {path}: {e}")

            if not path.is_dir():
                raise NotADirectoryError(f"Path {path} is not a directory")

            return path
        except Exception as e:
            raise RuntimeError(f"Failed to resolve path for {path_str}: {e}")

    def get_root_dir(self) -> pathlib.Path:
        """Return the base root directory path."""
        root_default = os.path.join(self.default_root_dir, "")
        return self._resolve_path(self.root_dir_arg, root_default, base_only=True)

    def data_dir(self) -> pathlib.Path:
        """Return the base data directory path (without project or subproject)."""
        default_data = self.default_data_dir
        return self._resolve_path(self.data_dir_arg, default_data, base_only=True)

    def project_dir(self) -> pathlib.Path:
        """Return the data directory path for the project (excludes subproject)."""
        default_data = self.default_data_dir
        return self._resolve_path(
            self.data_dir_arg, default_data, base_only=False, include_subproject=False
        )

    def sub_project_dir(self) -> pathlib.Path:
        """Return the data directory path for the subproject.

        Raises:
            ValueError: If no subproject is specified.
        """
        if not self.subproject:
            raise ValueError("No subproject specified")
        default_data = self.default_data_dir
        return self._resolve_path(
            self.data_dir_arg, default_data, base_only=False, include_subproject=True
        )

    def get_project_today_file_name(self, filetype: str = "json") -> pathlib.Path:
        """Generate a filename with today's date in the project directory.

        Args:
            filetype: File extension (default: "json").

        Returns:
            Full path to the date-stamped file.
        """
        if self.subproject:
            file_path = (
                self.sub_project_dir()
                / f"{self.project_name}_{self.subproject}_{date.today()}.{filetype}"
            )
        else:
            file_path = (
                self.project_dir()
                / f"{self.project_name}_{date.today()}.{filetype}"
            )
        return file_path