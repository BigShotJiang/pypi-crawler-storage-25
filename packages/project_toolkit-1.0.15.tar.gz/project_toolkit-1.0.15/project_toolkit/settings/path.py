"""Path configuration settings module."""

from __future__ import annotations

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PathSettings(BaseSettings):
    """Settings for data path configuration.

    These settings control the directory structure used by DataPathConfig.
    In Airflow environments, root_dir and data_dir are automatically set
    to /opt/airflow and /opt/airflow/data respectively.
    """

    model_config = SettingsConfigDict(extra="ignore")

    root_dir: Optional[str] = Field(
        default=None,
        description="Root directory path. Defaults to ~/ or /opt/airflow in Airflow.",
    )
    data_dir: Optional[str] = Field(
        default=None,
        description="Data directory path. Derived from root_dir/data if not set.",
    )
    default_root_dir: str = Field(
        default="~/",
        description="Fallback root directory when root_dir is not specified.",
    )
    project_name: Optional[str] = Field(
        default=None,
        description="Default project name for path construction.",
    )
    subproject: Optional[str] = Field(
        default=None,
        description="Default subproject name for nested folder structure.",
    )
