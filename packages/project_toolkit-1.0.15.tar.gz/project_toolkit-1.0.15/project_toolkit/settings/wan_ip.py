"""WAN IP configuration settings module."""

from __future__ import annotations

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class WanIpSettings(BaseSettings):
    """Settings for the WAN IP module.

    Configures curl options, the URL to query, and storage paths.
    Env vars are loaded automatically (prefix-free):

    - ``WAN_IP_URL`` — URL that returns the caller's public IP.
    - ``WAN_IP_CURL_PATH`` — explicit path to a curl binary.
    - ``WAN_IP_TIMEOUT`` — seconds to wait for each curl fetch.
    - ``WAN_IP_PROJECT_NAME`` — project name for DataPathConfig.
    - ``WAN_IP_SUBPROJECT`` — subproject name for DataPathConfig.
    """

    model_config = SettingsConfigDict(extra="ignore")

    wan_ip_url: str = Field(
        default="https://ifconfig.me/ip",
        description="URL that returns the caller's public IP address.",
    )
    wan_ip_curl_path: Optional[str] = Field(
        default=None,
        description="Explicit path to a curl binary (auto-detected if omitted).",
    )
    wan_ip_timeout: int = Field(
        default=5,
        description="Max seconds to wait for each curl fetch.",
    )
    wan_ip_project_name: str = Field(
        default="ip-logs",
        description="Project name for DataPathConfig storage.",
    )
    wan_ip_subproject: Optional[str] = Field(
        default=None,
        description="Subproject name for DataPathConfig storage.",
    )
