"""
Base application settings with environment-aware .env file layering.

Priority (highest wins):
  1. Environment variables
  2. .env.dev (local) or .env.airflow (Airflow)
  3. Vault secrets (when configured)
  4. Field defaults
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from project_toolkit.settings.cloudflare import CloudflareSettings
from project_toolkit.settings.google import GoogleSettings
from project_toolkit.settings.path import PathSettings
from project_toolkit.settings.vault import VaultSettings
from project_toolkit.settings.wan_ip import WanIpSettings


def _find_config_dir() -> Optional[Path]:
    """Locate the config/ directory by searching likely locations.

    Search order:
      1. ``config/`` relative to ``Path.cwd()`` (caller's project)
      2. Walk up from ``Path.cwd()`` (up to 5 levels) to find a ``config/`` dir
      3. Walk up from ``Path(__file__)`` (the package location, up to 5 levels)

    Returns the first ``config/`` directory found, or ``None``.
    """
    # 1. Current working directory (most common for projects)
    cwd_config = Path.cwd() / "config"
    if cwd_config.is_dir():
        return cwd_config

    # 2. Walk up from cwd
    current = Path.cwd().resolve()
    for _ in range(5):
        current = current.parent
        candidate = current / "config"
        if candidate.is_dir():
            return candidate

    # 3. Walk up from this file (works for editable installs / monorepo)
    current = Path(__file__).resolve().parent
    for _ in range(5):
        candidate = current / "config"
        if candidate.is_dir():
            return candidate
        current = current.parent

    return None


def _detect_env_files(env_file: Optional[str] = None) -> tuple[str, ...]:
    """Detect which .env files to load based on the current environment.

    Args:
        env_file: Optional explicit path to a ``.env`` file. When provided,
            this file is used directly and auto-detection is skipped.

    Returns a tuple of env file paths to load, in order of increasing priority.
    """
    # If an explicit path was provided, use it directly
    if env_file is not None:
        env_path = Path(env_file).expanduser().resolve()
        if env_path.is_file():
            return (str(env_path),)
        raise FileNotFoundError(
            f"Specified env_file not found: {env_file} "
            f"(resolved to {env_path})"
        )

    env_files: list[str] = []
    config_dir = _find_config_dir()

    if config_dir is not None:
        if os.environ.get("AIRFLOW_HOME"):
            airflow_env = config_dir / ".env.airflow"
            if airflow_env.is_file():
                env_files.append(str(airflow_env))
        else:
            dev_env = config_dir / ".env.dev"
            if dev_env.is_file():
                env_files.append(str(dev_env))

        # Fallback: try plain .env if the environment-specific file wasn't found
        if not env_files:
            plain_env = config_dir / ".env"
            if plain_env.is_file():
                env_files.append(str(plain_env))

    # Also check cwd for a plain .env if config_dir search found nothing
    if not env_files:
        cwd_env = Path.cwd() / ".env"
        if cwd_env.is_file():
            env_files.append(str(cwd_env))

    if not env_files:
        print(
            "project-toolkit: No .env file loaded. "
            "Looked for config/.env.dev, config/.env.airflow, config/.env, "
            "and .env in the current directory. "
            "Use settings.configure(env_file='...') to set the path explicitly."
        )

    return tuple(env_files)


def _parse_env_files(env_files: tuple[str, ...]) -> dict[str, str]:
    """Parse .env files into a flat dict for dynamic env() lookups.

    Handles quoted values and comments. Later files override earlier ones.
    """
    parsed: dict[str, str] = {}
    for filepath in env_files:
        try:
            with open(filepath) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip()
                    # Strip surrounding quotes
                    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                        value = value[1:-1]
                    parsed[key] = value
        except OSError:
            continue
    return parsed


# Share env file config across all sub-models
_ENV_FILES = _detect_env_files()
_ENV_PARSED = _parse_env_files(_ENV_FILES)
_SHARED_CONFIG = dict(
    env_file=_ENV_FILES,
    env_file_encoding="utf-8",
    case_sensitive=False,
    extra="ignore",
)


class AppSettings(BaseSettings):
    """Root application settings that composes all module settings.

    Settings are loaded from environment variables and .env files.
    Airflow environment is auto-detected via AIRFLOW_HOME.

    Each sub-settings model loads its OWN env vars directly (flat naming),
    so R2_ACCESS_TOKEN maps to cloudflare.r2_access_token without needing
    a nested delimiter prefix.

    Use ``settings.env("KEY")`` to access any env var or .env value
    dynamically, even if it's not defined as a field.
    """

    model_config = SettingsConfigDict(**_SHARED_CONFIG)

    # --- Composed module settings (loaded independently) ---
    path_config: PathSettings
    cloudflare: CloudflareSettings
    google: GoogleSettings
    vault: VaultSettings
    wan_ip: WanIpSettings

    # --- Environment detection ---
    airflow_home: Optional[str] = None

    def __init__(self, _env_parsed_override: Optional[dict[str, str]] = None, **data):
        super().__init__(**data)
        # Store the parsed env dict for dynamic env() lookups.
        # When an explicit env_file is provided via get_settings(),
        # this ensures env() reads from the correct parsed data.
        object.__setattr__(
            self,
            "_env_parsed",
            _env_parsed_override if _env_parsed_override is not None else _ENV_PARSED,
        )

    @model_validator(mode="after")
    def _apply_airflow_defaults(self) -> "AppSettings":
        """When running in Airflow, override path defaults."""
        if self.airflow_home:
            airflow_root = "/opt/airflow"
            if self.path_config.root_dir is None:
                self.path_config.root_dir = airflow_root
            if self.path_config.data_dir is None:
                self.path_config.data_dir = f"{airflow_root}/data"
        return self

    def env(self, key: str, default: Any = None) -> Any:
        """Read any environment variable or .env value dynamically.

        This lets you access keys like OPENAI_API_KEY, GEMINI_API_KEY, etc.
        without defining them as pydantic fields first.

        Priority: environment variable > .env file value > default.

        Args:
            key: Environment variable name (e.g., "OPENAI_API_KEY").
            default: Fallback value if not found. Defaults to None.

        Returns:
            The value as a string, or the default if not found.

        Examples::

            settings.env("OPENAI_API_KEY")
            settings.env("MY_CUSTOM_VAR", "fallback")
        """
        env_parsed = object.__getattribute__(self, "_env_parsed")

        # 1. Check actual environment variables first
        value = os.environ.get(key)
        if value is not None:
            return value

        # 2. Check parsed .env file (case-sensitive match first)
        if key in env_parsed:
            return env_parsed[key]

        # 3. Case-insensitive fallback
        key_upper = key.upper()
        for k, v in env_parsed.items():
            if k.upper() == key_upper:
                return v

        return default


@lru_cache(maxsize=1)
def get_settings(env_file: Optional[str] = None, **overrides) -> AppSettings:
    """Factory function to get cached application settings.

    Each sub-settings model is instantiated independently so that
    flat environment variables (e.g. R2_ACCESS_TOKEN) are picked up
    directly, without needing a nested delimiter prefix.

    The detected env file(s) are passed to each sub-model so all
    settings load from the same .env.dev or .env.airflow file.

    Args:
        env_file: Optional explicit path to a ``.env`` file. When
            auto-detection fails (e.g. running from a notebook or a
            different working directory), pass the path to your
            ``.env`` file here.

    Call with overrides for testing::

        get_settings.cache_clear()
        settings = get_settings()

    Explicit env file::

        get_settings.cache_clear()
        settings = get_settings(env_file="/path/to/my/.env.dev")
    """
    if env_file is not None:
        env_files = _detect_env_files(env_file=env_file)
    else:
        env_files = _ENV_FILES

    env_parsed = _parse_env_files(env_files)

    # Each sub-model inherits BaseSettings and reads its own env vars + .env files
    return AppSettings(
        path_config=PathSettings(_env_file=env_files),
        cloudflare=CloudflareSettings(_env_file=env_files),
        google=GoogleSettings(_env_file=env_files),
        vault=VaultSettings(_env_file=env_files),
        wan_ip=WanIpSettings(_env_file=env_files),
        _env_parsed_override=env_parsed,
        **overrides,
    )
