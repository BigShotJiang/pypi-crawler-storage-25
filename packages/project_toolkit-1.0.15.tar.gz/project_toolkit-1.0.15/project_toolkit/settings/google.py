"""Google services configuration settings module."""

from __future__ import annotations

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class GoogleSettings(BaseSettings):
    """Settings for Google Cloud services (Sheets, Drive, BigQuery).

    Env vars loaded automatically: GOOGLE_SERVICE_ACCOUNT_JSON, TEST_GOOGLE_SHEET_ID
    """

    model_config = SettingsConfigDict(extra="ignore")

    google_service_account_json: Optional[str] = Field(
        default=None,
        description="Path to the Google service account JSON key file.",
    )
    test_google_sheet_id: Optional[str] = Field(
        default=None,
        description="Google Sheet ID used for testing (never use production sheets).",
    )
