"""
Centralized settings module using pydantic-settings.

Usage:
    from project_toolkit.settings import get_settings

    settings = get_settings()
    print(settings.cloudflare.r2_access_token)
    print(settings.google.service_account_json)
"""

from project_toolkit.settings.base import AppSettings, get_settings
from project_toolkit.settings.cloudflare import CloudflareSettings
from project_toolkit.settings.google import GoogleSettings
from project_toolkit.settings.path import PathSettings
from project_toolkit.settings.vault import VaultSettings
from project_toolkit.settings.wan_ip import WanIpSettings

__all__ = [
    "AppSettings",
    "get_settings",
    "CloudflareSettings",
    "GoogleSettings",
    "PathSettings",
    "VaultSettings",
    "WanIpSettings",
]
