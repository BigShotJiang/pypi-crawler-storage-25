raise RuntimeError("elasti is not yet available. Coming soon — https://elasti.com")
