# Elasti

E2E encrypted AI inference and vector embeddings SDK

**Coming Soon**

Requests are encrypted on your machine and processed inside secure hardware enclaves. Your prompts, responses, and embeddings remain private. Not even we can see your data.

```python
import os
from elasti import Elasti

client = Elasti(
    api_key=os.environ["ELASTI_API_KEY"],
)

response = client.inference.create(
    model="elasti-genesis",
    mode="ephemeral",
    messages=[{"role": "user", "content": "Explain 1984 in one sentence."}],
)

print(response.output_text)
```

## Features

* **Fully encrypted inference**
Prompts and responses are encrypted locally before they leave your machine.

* **Homomorphic vector search**
Search encrypted embeddings without ever decrypting them. Your cloud context remains invisible to the infrastructure.

* **Zero plaintext on the wire**
Encryption occurs within the SDK before any network transmission begins.

* **Flexible session modes**
Support for persistent sessions and ephemeral modes that generate unique keys per request.

## Install

```bash
pip install elasti
```

[elasti.com](https://elasti.com)
