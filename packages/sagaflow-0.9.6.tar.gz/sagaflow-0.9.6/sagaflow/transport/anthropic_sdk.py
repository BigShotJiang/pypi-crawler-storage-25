"""Anthropic-SDK transport. Default subagent backend."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass
from enum import Enum

import anthropic
from anthropic import AsyncAnthropic

logger = logging.getLogger(__name__)

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 529}
_BASE_DELAY_S = 3.0
_MAX_DELAY_S = 120.0
_DEFAULT_MAX_ELAPSED_S = 3600.0  # 1hr safety ceiling; Temporal activity timeout provides defense-in-depth


def _fix_schema(schema: dict) -> dict:
    """Recursively add ``additionalProperties: false`` to all object types."""
    if not isinstance(schema, dict):
        return schema
    schema = dict(schema)
    if schema.get("type") == "object" and "additionalProperties" not in schema:
        schema["additionalProperties"] = False
    if "properties" in schema and isinstance(schema["properties"], dict):
        schema["properties"] = {k: _fix_schema(v) for k, v in schema["properties"].items()}
    if "items" in schema and isinstance(schema["items"], dict):
        schema["items"] = _fix_schema(schema["items"])
    for key in ("anyOf", "oneOf", "allOf"):
        val = schema.get(key)
        if isinstance(val, list):
            schema[key] = [_fix_schema(v) for v in val]
    return schema


_MAX_OUTPUT_TOKENS: dict[str, int] = {
    "claude-haiku-4-5-20251001": 64_000,
    "claude-sonnet-4-6": 128_000,
    "claude-opus-4-7": 128_000,
}


class ModelTier(Enum):
    HAIKU = "claude-haiku-4-5-20251001"
    SONNET = "claude-sonnet-4-6"
    OPUS = "claude-opus-4-7"

    @property
    def model_id(self) -> str:
        return self.value

    @property
    def max_output_tokens(self) -> int:
        return _MAX_OUTPUT_TOKENS.get(self.value, 64_000)


@dataclass
class TransportResult:
    text: str
    input_tokens: int
    output_tokens: int


class AnthropicSdkTransport:
    """Call the Anthropic API. Honors ANTHROPIC_BASE_URL override (e.g., model gateway)."""

    def __init__(self, client: AsyncAnthropic | None = None) -> None:
        if client is None:
            base_url = os.environ.get("ANTHROPIC_BASE_URL")
            api_key = os.environ.get("ANTHROPIC_API_KEY", "sk-dummy")
            client = AsyncAnthropic(base_url=base_url, api_key=api_key)
        self._client = client

    async def call(
        self,
        *,
        tier: ModelTier,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        max_elapsed_s: float = _DEFAULT_MAX_ELAPSED_S,
        output_schema: dict | None = None,
    ) -> TransportResult:
        started = time.monotonic()
        attempt = 0
        while True:
            try:
                stream_kwargs: dict = {
                    "model": tier.model_id,
                    "max_tokens": min(max_tokens, tier.max_output_tokens),
                    "system": system_prompt,
                    "messages": [{"role": "user", "content": user_prompt}],
                }
                if output_schema is not None:
                    stream_kwargs["output_config"] = {
                        "format": {"type": "json_schema", "schema": _fix_schema(output_schema)},
                    }
                async with self._client.messages.stream(**stream_kwargs) as stream:
                    response = await stream.get_final_message()
                text_parts = [
                    block.text for block in response.content if block.type == "text"
                ]
                if response.stop_reason == "max_tokens":
                    logger.warning(
                        "Response truncated (stop_reason=max_tokens, output_tokens=%d, limit=%d, model=%s)",
                        response.usage.output_tokens,
                        max_tokens,
                        tier.model_id,
                    )
                return TransportResult(
                    text="".join(text_parts),
                    input_tokens=response.usage.input_tokens,
                    output_tokens=response.usage.output_tokens,
                )
            except anthropic.APIStatusError as exc:
                elapsed = time.monotonic() - started
                if exc.status_code not in _RETRYABLE_STATUS_CODES or elapsed >= max_elapsed_s:
                    raise
                delay = min(_BASE_DELAY_S * (2 ** attempt), _MAX_DELAY_S)
                logger.warning(
                    "Anthropic API %d (attempt %d, %.0fs/%.0fs elapsed), retrying in %.0fs",
                    exc.status_code,
                    attempt + 1,
                    elapsed,
                    max_elapsed_s,
                    delay,
                )
                await asyncio.sleep(delay)
                attempt += 1
