"""Data models for cve-dedup-checker."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class TargetType(str, Enum):
    WP_PLUGIN = "wp-plugin"
    WP_THEME = "wp-theme"
    NPM = "npm"
    PYPI = "pypi"
    GITHUB = "github"
    CPE = "cpe"
    KEYWORD = "keyword"


class Severity(str, Enum):
    UNKNOWN = "unknown"
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class MatchConfidence(str, Enum):
    CLEAN = "clean"
    POSSIBLE = "possible"
    CONFIRMED = "confirmed"


class Target(BaseModel):
    type: TargetType
    identifier: str
    vuln_class: str | None = None
    affected_version: str | None = None


class Advisory(BaseModel):
    source: str
    cve_id: str | None = None
    title: str
    url: str
    severity: Severity = Severity.UNKNOWN
    cvss_score: float | None = None
    affected_product: str | None = None
    affected_versions: str | None = None
    published: str | None = None
    summary: str | None = None
    raw: dict = Field(default_factory=dict)


class SourceResult(BaseModel):
    source: str
    ok: bool = True
    queried_url: str | None = None
    error: str | None = None
    advisories: list[Advisory] = Field(default_factory=list)
    elapsed_ms: int = 0

    @property
    def count(self) -> int:
        return len(self.advisories)


class DedupReport(BaseModel):
    target: Target
    results: list[SourceResult]
    confidence: MatchConfidence
    possible_matches: list[Advisory] = Field(default_factory=list)
    confirmed_matches: list[Advisory] = Field(default_factory=list)
    queried_sources: int = 0
    successful_sources: int = 0

    @property
    def total_advisories(self) -> int:
        return sum(r.count for r in self.results)

    @property
    def any_failed(self) -> bool:
        return any(not r.ok for r in self.results)
