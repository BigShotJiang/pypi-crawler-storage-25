"""JSON-only disk cache for source responses. Deliberately no pickle.

Stores each entry as a small JSON file at a SHA256-keyed path under the user's
XDG cache directory. Values must be JSON-serialisable (dict / list / str / int
/ float / bool / None), which is what all our source calls produce.

Why not diskcache? diskcache pickles by default (CVE-2025-69872): an attacker
with write access to the cache directory can cause arbitrary code execution
when the victim app reads from the cache. Writing our own JSON-only layer
removes that class entirely and drops a dependency.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import time
from pathlib import Path
from typing import Any

from platformdirs import user_cache_dir

_DEFAULT_TTL = 6 * 60 * 60  # 6 hours


def _cache_dir() -> Path:
    d = Path(user_cache_dir("cve-dedup-checker"))
    d.mkdir(parents=True, exist_ok=True)
    # Restrict to owner. Idempotent on existing dirs.
    with contextlib.suppress(OSError):
        d.chmod(0o700)
    return d


def _file_for(key: str) -> Path:
    return _cache_dir() / f"{key}.json"


def make_key(source: str, *parts: str) -> str:
    blob = "|".join([source, *parts]).encode()
    return hashlib.sha256(blob).hexdigest()


def get(key: str) -> Any | None:
    p = _file_for(key)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or "expires_at" not in data:
        return None
    if float(data.get("expires_at", 0)) < time.time():
        return None
    return data.get("value")


def put(key: str, value: Any, ttl: int = _DEFAULT_TTL) -> None:
    p = _file_for(key)
    payload = {"expires_at": time.time() + ttl, "value": value}
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload))
    tmp.replace(p)


def clear_all() -> int:
    d = _cache_dir()
    n = 0
    for p in d.glob("*.json"):
        try:
            p.unlink()
            n += 1
        except OSError:
            continue
    return n
