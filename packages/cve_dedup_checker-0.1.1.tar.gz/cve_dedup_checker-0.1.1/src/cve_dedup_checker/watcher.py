"""Watch mode: periodically re-run a dedup check and notify when new matches appear.

State is keyed by (target type, identifier, vuln class) and stored next to the cache.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import re
import signal
from datetime import datetime, timezone
from pathlib import Path

from platformdirs import user_state_dir
from rich.console import Console

from cve_dedup_checker.config import Config
from cve_dedup_checker.models import Advisory, DedupReport, Target
from cve_dedup_checker.runner import run as run_once

_INTERVAL_RE = re.compile(r"^(\d+)\s*([smhd])?$", re.IGNORECASE)


def parse_interval(value: str) -> int:
    """Parse a human interval string like '30m', '6h', '1d' into seconds.

    Bare numbers are treated as seconds. Minimum value is 60 seconds to stay polite
    to free upstream APIs.
    """
    match = _INTERVAL_RE.match(value.strip())
    if not match:
        raise ValueError(f"invalid interval {value!r}; use forms like '30s', '10m', '2h', '1d'")
    n = int(match.group(1))
    unit = (match.group(2) or "s").lower()
    seconds = n * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
    if seconds < 60:
        raise ValueError("interval must be at least 60 seconds to stay polite to free APIs")
    return seconds


def _state_path(target: Target) -> Path:
    d = Path(user_state_dir("cve-dedup-checker")) / "watch"
    d.mkdir(parents=True, exist_ok=True)
    safe_id = re.sub(r"[^A-Za-z0-9._-]+", "_", target.identifier)
    safe_class = re.sub(r"[^A-Za-z0-9._-]+", "_", target.vuln_class or "any")
    return d / f"{target.type.value}__{safe_id}__{safe_class}.json"


def _seen_urls(path: Path) -> set[str]:
    if not path.exists():
        return set()
    try:
        return set(json.loads(path.read_text()).get("seen_urls", []))
    except (OSError, json.JSONDecodeError):
        return set()


def _save_seen_urls(path: Path, urls: set[str]) -> None:
    payload = {
        "updated_at": datetime.now(tz=timezone.utc).isoformat(),
        "seen_urls": sorted(urls),
    }
    path.write_text(json.dumps(payload, indent=2))


def _collect_urls(report: DedupReport) -> list[Advisory]:
    return report.confirmed_matches + report.possible_matches


async def watch(target: Target, cfg: Config, interval_seconds: int, console: Console | None = None) -> int:
    c = console or Console()
    state_file = _state_path(target)
    seen = _seen_urls(state_file)

    c.print(
        f"[bold]watch mode[/bold]  target=[cyan]{target.type.value}[/cyan] "
        f"id=[cyan]{target.identifier}[/cyan] "
        f"class=[cyan]{target.vuln_class or '-'}[/cyan]  "
        f"interval=[yellow]{interval_seconds}s[/yellow]  "
        f"state=[dim]{state_file}[/dim]"
    )
    c.print("Press Ctrl+C to stop.\n")

    stop = asyncio.Event()

    def _handler(*_):
        stop.set()

    with contextlib.suppress(RuntimeError):
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            with contextlib.suppress(NotImplementedError):
                loop.add_signal_handler(sig, _handler)

    runs = 0
    while not stop.is_set():
        runs += 1
        ts = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        c.print(f"[dim]{ts}[/dim]  run #{runs}...")
        try:
            report = await run_once(target, cfg)
        except Exception as e:  # noqa: BLE001
            c.print(f"  [red]error:[/red] {e}")
            await _sleep_or_stop(stop, interval_seconds)
            continue

        advisories = _collect_urls(report)
        current_urls = {a.url for a in advisories}
        new_urls = current_urls - seen
        gone_urls = seen - current_urls

        if runs == 1 and not seen:
            c.print(f"  baseline: {len(current_urls)} advisory URLs recorded.")
        else:
            if new_urls:
                c.print(f"  [bold red]{len(new_urls)} NEW match(es):[/bold red]")
                for a in advisories:
                    if a.url in new_urls:
                        c.print(f"    - [{a.source}] {a.title[:120]}")
                        c.print(f"      [dim]{a.url}[/dim]")
            if gone_urls:
                c.print(f"  [green]{len(gone_urls)} resolved / removed:[/green]")
                for url in sorted(gone_urls):
                    c.print(f"    - [dim]{url}[/dim]")
            if not new_urls and not gone_urls:
                c.print(f"  no change ({len(current_urls)} total matches)")

        seen = current_urls
        _save_seen_urls(state_file, seen)

        await _sleep_or_stop(stop, interval_seconds)

    c.print("\nstopped.")
    return 0


async def _sleep_or_stop(stop: asyncio.Event, seconds: int) -> None:
    try:
        await asyncio.wait_for(stop.wait(), timeout=seconds)
    except asyncio.TimeoutError:
        return
