"""cve-dedup-checker CLI entrypoint."""

from __future__ import annotations

import asyncio
import sys
from enum import Enum

import typer
from rich.console import Console

from cve_dedup_checker import __version__, output, runner, watcher
from cve_dedup_checker import cache as cache_mod
from cve_dedup_checker import config as config_mod
from cve_dedup_checker.models import MatchConfidence, Target, TargetType

app = typer.Typer(
    name="cve-dedup-checker",
    help=(
        "Parallel duplicate-check across free CVE and vulnerability databases "
        "(NVD, OSV, GitHub Advisories, WPScan, Patchstack, CISA KEV, Exploit-DB)."
    ),
    no_args_is_help=True,
    add_completion=False,
    rich_markup_mode="rich",
)


class OutputFormat(str, Enum):
    human = "human"
    json = "json"
    markdown = "markdown"


def _version_cb(value: bool) -> None:
    if value:
        typer.echo(f"cve-dedup-checker {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: bool | None = typer.Option(
        None, "--version", callback=_version_cb, is_eager=True, help="Show version and exit."
    ),
) -> None:
    """Root."""


def _run(
    kind: TargetType,
    identifier: str,
    vuln_class: str | None,
    affected_version: str | None,
    output_format: OutputFormat,
    watch_interval: str | None,
) -> None:
    cfg = config_mod.load()
    target = Target(
        type=kind,
        identifier=identifier,
        vuln_class=vuln_class,
        affected_version=affected_version,
    )

    console = Console()

    if watch_interval:
        try:
            seconds = watcher.parse_interval(watch_interval)
        except ValueError as e:
            typer.echo(f"error: {e}", err=True)
            raise typer.Exit(code=2) from e
        raise typer.Exit(code=asyncio.run(watcher.watch(target, cfg, seconds, console)))

    if output_format == OutputFormat.human:
        console.print(f"[dim]Querying vulnerability databases for {kind.value} '{identifier}'...[/dim]")

    report = asyncio.run(runner.run(target, cfg))

    if output_format == OutputFormat.json:
        typer.echo(output.render_json(report))
    elif output_format == OutputFormat.markdown:
        typer.echo(output.render_markdown(report))
    else:
        output.render_human(report, console)

    if report.successful_sources == 0:
        # No sources responded; don't claim anything.
        raise typer.Exit(code=3)
    if report.confidence == MatchConfidence.CLEAN:
        raise typer.Exit(code=0)
    if report.confidence == MatchConfidence.POSSIBLE:
        raise typer.Exit(code=1)
    raise typer.Exit(code=2)


_watch_option = typer.Option(
    None,
    "--watch",
    help="Re-run on an interval (e.g. '30m', '6h', '1d'). Prints only new matches after the baseline run. Min 60s.",
)


@app.command("wp-plugin")
def wp_plugin(
    slug: str = typer.Argument(..., help="WordPress plugin slug."),
    vuln_class: str | None = typer.Option(None, "--class", help="Vulnerability class (xss, sqli, broken-access-control, ...)."),
    version: str | None = typer.Option(None, "--version", help="Affected version range."),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output", help="Output format."),
    watch: str | None = _watch_option,
) -> None:
    """Check a WordPress plugin slug."""
    _run(TargetType.WP_PLUGIN, slug, vuln_class, version, output_format, watch)


@app.command("wp-theme")
def wp_theme(
    slug: str = typer.Argument(..., help="WordPress theme slug."),
    vuln_class: str | None = typer.Option(None, "--class"),
    version: str | None = typer.Option(None, "--version"),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output"),
    watch: str | None = _watch_option,
) -> None:
    """Check a WordPress theme slug."""
    _run(TargetType.WP_THEME, slug, vuln_class, version, output_format, watch)


@app.command("npm")
def npm(
    package: str = typer.Argument(..., help="npm package name."),
    vuln_class: str | None = typer.Option(None, "--class"),
    version: str | None = typer.Option(None, "--version"),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output"),
    watch: str | None = _watch_option,
) -> None:
    """Check an npm package."""
    _run(TargetType.NPM, package, vuln_class, version, output_format, watch)


@app.command("pypi")
def pypi(
    package: str = typer.Argument(..., help="PyPI package name."),
    vuln_class: str | None = typer.Option(None, "--class"),
    version: str | None = typer.Option(None, "--version"),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output"),
    watch: str | None = _watch_option,
) -> None:
    """Check a PyPI package."""
    _run(TargetType.PYPI, package, vuln_class, version, output_format, watch)


@app.command("github")
def github(
    owner_repo: str = typer.Argument(..., help="GitHub owner/repo (e.g. 'vercel/next.js')."),
    vuln_class: str | None = typer.Option(None, "--class"),
    version: str | None = typer.Option(None, "--version"),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output"),
    watch: str | None = _watch_option,
) -> None:
    """Check a GitHub repo."""
    _run(TargetType.GITHUB, owner_repo, vuln_class, version, output_format, watch)


@app.command("cpe")
def cpe(
    cpe_string: str = typer.Argument(..., help="CPE 2.3 string."),
    vuln_class: str | None = typer.Option(None, "--class"),
    version: str | None = typer.Option(None, "--version"),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output"),
    watch: str | None = _watch_option,
) -> None:
    """Check a CPE 2.3 identifier (NVD only)."""
    _run(TargetType.CPE, cpe_string, vuln_class, version, output_format, watch)


@app.command("keyword")
def keyword(
    term: str = typer.Argument(..., help="Free-text keyword."),
    vuln_class: str | None = typer.Option(None, "--class"),
    version: str | None = typer.Option(None, "--version"),
    output_format: OutputFormat = typer.Option(OutputFormat.human, "--output"),
    watch: str | None = _watch_option,
) -> None:
    """Check by free-text keyword."""
    _run(TargetType.KEYWORD, term, vuln_class, version, output_format, watch)


@app.command("cache-clear")
def cache_clear() -> None:
    """Delete the local response cache."""
    n = cache_mod.clear_all()
    typer.echo(f"Cleared {n} cached entries.")


@app.command("config-sample")
def config_sample() -> None:
    """Print a sample config file you can write to ~/.config/cve-dedup-checker/config.toml."""
    typer.echo(config_mod.sample_config_text())


def main() -> None:
    try:
        app()
    except KeyboardInterrupt:
        typer.echo("\ninterrupted", err=True)
        sys.exit(130)


if __name__ == "__main__":
    main()
