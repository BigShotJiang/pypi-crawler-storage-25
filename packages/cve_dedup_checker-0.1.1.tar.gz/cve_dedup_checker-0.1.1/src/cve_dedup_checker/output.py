"""Render a DedupReport to a terminal table, JSON, or Markdown."""

from __future__ import annotations

import json
from io import StringIO

from rich.console import Console
from rich.table import Table

from cve_dedup_checker.models import DedupReport, MatchConfidence


def render_human(report: DedupReport, console: Console | None = None) -> None:
    c = console or Console()
    target = report.target

    header = Table.grid(padding=(0, 2))
    header.add_row("Target:", f"[bold]{target.type.value}[/bold]  {target.identifier}")
    if target.vuln_class:
        header.add_row("Class:", target.vuln_class)
    if target.affected_version:
        header.add_row("Version:", target.affected_version)
    header.add_row("Sources:", f"{report.successful_sources}/{report.queried_sources} responded")
    c.print(header)
    c.print()

    table = Table(show_lines=False, header_style="bold")
    table.add_column("Source", style="cyan", no_wrap=True)
    table.add_column("Status", no_wrap=True)
    table.add_column("Hits", justify="right")
    table.add_column("Time", justify="right")
    table.add_column("URL", overflow="fold")
    for r in sorted(report.results, key=lambda x: x.source):
        if not r.ok:
            status = "[red]error[/red]"
        elif r.count == 0:
            status = "[green]clean[/green]"
        else:
            status = "[yellow]hits[/yellow]"
        table.add_row(
            r.source,
            status,
            str(r.count),
            f"{r.elapsed_ms} ms",
            r.queried_url or "",
        )
    c.print(table)

    if report.confirmed_matches:
        c.print()
        c.print("[bold red]Confirmed matches[/bold red]")
        _print_advisories(c, report.confirmed_matches)

    if report.possible_matches:
        c.print()
        c.print("[bold yellow]Possible matches[/bold yellow] (review)")
        _print_advisories(c, report.possible_matches[:20])
        if len(report.possible_matches) > 20:
            c.print(f"  ... and {len(report.possible_matches) - 20} more, pass --output json for full list")

    failed = report.queried_sources - report.successful_sources
    if failed:
        c.print()
        c.print(
            f"[yellow]![/yellow] {failed}/{report.queried_sources} source(s) errored "
            "(network, rate-limit, or transient). Re-run to re-check those sources; results below are based on the {ok} that succeeded.".format(
                ok=report.successful_sources
            )
        )

    c.print()
    c.print(_banner(report.confidence, report.successful_sources, report.queried_sources))


def render_json(report: DedupReport) -> str:
    return report.model_dump_json(indent=2)


def render_markdown(report: DedupReport) -> str:
    buf = StringIO()
    target = report.target
    buf.write(f"# cve-dedup-checker report: `{target.type.value}` `{target.identifier}`\n\n")
    if target.vuln_class:
        buf.write(f"- Vulnerability class: `{target.vuln_class}`\n")
    if target.affected_version:
        buf.write(f"- Affected version: `{target.affected_version}`\n")
    buf.write(f"- Sources queried: {report.queried_sources}\n")
    buf.write(f"- Sources succeeded: {report.successful_sources}\n")
    buf.write(f"- Status: **{report.confidence.value.upper()}**\n\n")

    buf.write("## Source results\n\n")
    buf.write("| Source | Status | Hits | Time | URL |\n")
    buf.write("|---|---|---:|---:|---|\n")
    for r in sorted(report.results, key=lambda x: x.source):
        status = "error" if not r.ok else ("clean" if r.count == 0 else "hits")
        url = r.queried_url or ""
        buf.write(f"| {r.source} | {status} | {r.count} | {r.elapsed_ms} ms | {url} |\n")

    if report.confirmed_matches:
        buf.write("\n## Confirmed matches\n\n")
        for a in report.confirmed_matches:
            buf.write(f"- [{a.cve_id or a.source}]({a.url}) - {a.title}\n")

    if report.possible_matches:
        buf.write("\n## Possible matches (manual review)\n\n")
        for a in report.possible_matches:
            buf.write(f"- [{a.cve_id or a.source}]({a.url}) - {a.title}\n")

    buf.write("\n")
    return buf.getvalue()


def _print_advisories(c: Console, advisories) -> None:
    t = Table(show_lines=False)
    t.add_column("Source", style="cyan")
    t.add_column("CVE")
    t.add_column("Severity")
    t.add_column("Title", overflow="fold")
    t.add_column("URL", overflow="fold")
    for a in advisories:
        t.add_row(
            a.source,
            a.cve_id or "-",
            a.severity.value if a.severity else "unknown",
            a.title[:120],
            a.url,
        )
    c.print(t)


def _banner(confidence: MatchConfidence, ok: int, total: int) -> str:
    partial = f" (partial data: {ok}/{total} sources succeeded)" if ok < total else ""
    if confidence == MatchConfidence.CLEAN:
        if ok == 0:
            return "[bold red]>>> STATUS: INCONCLUSIVE (no sources responded - check network)[/bold red]"
        color = "yellow" if partial else "green"
        return f"[bold {color}]>>> STATUS: CLEAN (no prior disclosures matched){partial}[/bold {color}]"
    if confidence == MatchConfidence.POSSIBLE:
        return f"[bold yellow]>>> STATUS: POSSIBLE MATCH (review required){partial}[/bold yellow]"
    return f"[bold red]>>> STATUS: CONFIRMED DUPLICATE{partial}[/bold red]"


def dumps_dict(report: DedupReport) -> dict:
    return json.loads(report.model_dump_json())
