"""All source plugins. Each must implement the Source protocol from base."""

from __future__ import annotations

from cve_dedup_checker.sources.base import Source
from cve_dedup_checker.sources.cisa_kev import CisaKevSource
from cve_dedup_checker.sources.exploit_db import ExploitDbSource
from cve_dedup_checker.sources.github_advisories import GithubAdvisoriesSource
from cve_dedup_checker.sources.nvd import NvdSource
from cve_dedup_checker.sources.osv import OsvSource
from cve_dedup_checker.sources.patchstack import PatchstackSource
from cve_dedup_checker.sources.wpscan import WpscanSource

ALL_SOURCES: list[type[Source]] = [
    NvdSource,
    OsvSource,
    GithubAdvisoriesSource,
    WpscanSource,
    PatchstackSource,
    CisaKevSource,
    ExploitDbSource,
]


__all__ = [
    "ALL_SOURCES",
    "Source",
    "CisaKevSource",
    "ExploitDbSource",
    "GithubAdvisoriesSource",
    "NvdSource",
    "OsvSource",
    "PatchstackSource",
    "WpscanSource",
]
