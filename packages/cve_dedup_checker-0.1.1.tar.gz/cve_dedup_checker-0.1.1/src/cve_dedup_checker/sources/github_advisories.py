"""GitHub Security Advisories public REST API.

Docs: https://docs.github.com/en/rest/security-advisories/global-advisories
Free. Unauthenticated rate limit is 60/hr; a GITHUB_TOKEN lifts it to 5000/hr.
"""

from __future__ import annotations

from cve_dedup_checker.models import Advisory, Severity, SourceResult, Target
from cve_dedup_checker.sources.base import Source, empty_result, error_result

GHSA_URL = "https://api.github.com/advisories"


_ECOSYSTEM_MAP = {
    "npm": "npm",
    "pypi": "pip",
}


class GithubAdvisoriesSource(Source):
    id = "github-advisories"
    human_name = "GitHub Security Advisories"
    supported_targets = {"npm", "pypi", "github", "keyword"}

    async def query(self, target: Target) -> SourceResult:
        t = self._timed()
        params = self._params(target)
        if not params:
            return empty_result(self.id, GHSA_URL)
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if self.config.github_token:
            headers["Authorization"] = f"Bearer {self.config.github_token}"
        try:
            data = await self._get_json(GHSA_URL, params=params, headers=headers)
        except Exception as e:  # noqa: BLE001
            result = error_result(self.id, GHSA_URL, str(e))
            result.elapsed_ms = t.ms()
            return result

        advisories = []
        for item in data or []:
            ghsa_id = item.get("ghsa_id")
            cve_id = item.get("cve_id")
            sev = (item.get("severity") or "unknown").lower()
            cvss_obj = item.get("cvss") or {}
            score = cvss_obj.get("score")
            advisories.append(
                Advisory(
                    source=self.id,
                    cve_id=cve_id,
                    title=item.get("summary") or ghsa_id or "(unknown)",
                    url=item.get("html_url") or f"https://github.com/advisories/{ghsa_id}",
                    severity=_severity(sev),
                    cvss_score=float(score) if score is not None else None,
                    summary=(item.get("description") or "")[:600],
                    published=item.get("published_at"),
                    raw={},
                )
            )
        result = SourceResult(source=self.id, queried_url=GHSA_URL, advisories=advisories)
        result.elapsed_ms = t.ms()
        return result

    def _params(self, target: Target) -> dict | None:
        kind = target.type.value
        if kind in _ECOSYSTEM_MAP:
            return {"ecosystem": _ECOSYSTEM_MAP[kind], "affects": target.identifier, "per_page": 50}
        if kind == "github":
            # GitHub API doesn't support per-repo search on this endpoint; fall back to keyword.
            return {"query": target.identifier.replace("/", " "), "per_page": 50}
        if kind == "keyword":
            return {"query": target.identifier, "per_page": 50}
        return None


def _severity(label: str) -> Severity:
    if label in {"low", "medium", "high", "critical", "none"}:
        return Severity(label)
    return Severity.UNKNOWN
