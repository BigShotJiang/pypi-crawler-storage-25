"""WPScan public plugin/theme page scraper.

No paid API tier required. We read the public HTML of:
  https://wpscan.com/plugin/<slug>
  https://wpscan.com/theme/<slug>
"""

from __future__ import annotations

import re
from urllib.parse import quote

from bs4 import BeautifulSoup

from cve_dedup_checker.models import Advisory, Severity, SourceResult, Target
from cve_dedup_checker.sources.base import Source, error_result

BASE = "https://wpscan.com"


class WpscanSource(Source):
    id = "wpscan"
    human_name = "WPScan"
    supported_targets = {"wp-plugin", "wp-theme"}

    async def query(self, target: Target) -> SourceResult:
        t = self._timed()
        kind = "plugin" if target.type.value == "wp-plugin" else "theme"
        # URL-encode the slug so special characters (e.g. '/', '..') stay within the path segment
        # and can't restructure the request.
        safe_slug = quote(target.identifier, safe="")
        url = f"{BASE}/{kind}/{safe_slug}"
        try:
            html = await self._get_text(url)
        except Exception as e:  # noqa: BLE001
            result = error_result(self.id, url, str(e))
            result.elapsed_ms = t.ms()
            return result

        soup = BeautifulSoup(html, "lxml")
        advisories: list[Advisory] = []

        for link in soup.find_all("a", href=re.compile(r"/vulnerability/")):
            href = link.get("href") or ""
            title = link.get_text(strip=True) or "(untitled)"
            if not title:
                continue
            if not href.startswith("http"):
                href = BASE + href
            advisories.append(
                Advisory(
                    source=self.id,
                    cve_id=None,
                    title=title[:300],
                    url=href,
                    severity=Severity.UNKNOWN,
                    affected_product=f"{kind}:{target.identifier}",
                )
            )

        # Dedup by URL.
        seen = set()
        unique: list[Advisory] = []
        for a in advisories:
            if a.url in seen:
                continue
            seen.add(a.url)
            unique.append(a)

        result = SourceResult(source=self.id, queried_url=url, advisories=unique)
        result.elapsed_ms = t.ms()
        return result
