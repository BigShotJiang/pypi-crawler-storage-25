"""CISA Known Exploited Vulnerabilities (KEV) catalog.

Docs: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
Free, no auth. We pull the JSON feed once and cache it - then match locally.
"""

from __future__ import annotations

from cve_dedup_checker.models import Advisory, Severity, SourceResult, Target
from cve_dedup_checker.sources.base import Source, empty_result, error_result

KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"


class CisaKevSource(Source):
    id = "cisa-kev"
    human_name = "CISA Known Exploited Vulnerabilities"
    supported_targets = {"wp-plugin", "wp-theme", "npm", "pypi", "github", "cpe", "keyword"}

    async def query(self, target: Target) -> SourceResult:
        t = self._timed()
        try:
            data = await self._get_json(KEV_URL)
        except Exception as e:  # noqa: BLE001
            result = error_result(self.id, KEV_URL, str(e))
            result.elapsed_ms = t.ms()
            return result

        term = target.identifier.lower()
        advisories: list[Advisory] = []
        for v in (data or {}).get("vulnerabilities", []) or []:
            hay = " ".join(
                [
                    v.get("vendorProject") or "",
                    v.get("product") or "",
                    v.get("vulnerabilityName") or "",
                    v.get("shortDescription") or "",
                ]
            ).lower()
            if term in hay:
                cve_id = v.get("cveID")
                advisories.append(
                    Advisory(
                        source=self.id,
                        cve_id=cve_id,
                        title=v.get("vulnerabilityName") or cve_id or "(unknown)",
                        url=f"https://nvd.nist.gov/vuln/detail/{cve_id}" if cve_id else KEV_URL,
                        severity=Severity.CRITICAL,
                        summary=(v.get("shortDescription") or "")[:600],
                        affected_product=(v.get("vendorProject") or "") + "/" + (v.get("product") or ""),
                        published=v.get("dateAdded"),
                    )
                )
        if not advisories:
            result = empty_result(self.id, KEV_URL)
            result.elapsed_ms = t.ms()
            return result
        result = SourceResult(source=self.id, queried_url=KEV_URL, advisories=advisories)
        result.elapsed_ms = t.ms()
        return result
