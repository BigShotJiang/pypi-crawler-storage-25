"""Base class for vulnerability data sources."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod

import httpx

from cve_dedup_checker import cache
from cve_dedup_checker.config import Config
from cve_dedup_checker.models import SourceResult, Target


class Source(ABC):
    id: str = ""
    human_name: str = ""

    #: Which target types this source knows how to answer for.
    supported_targets: set[str] = set()

    def __init__(self, client: httpx.AsyncClient, config: Config):
        self.client = client
        self.config = config

    def supports(self, target: Target) -> bool:
        return target.type.value in self.supported_targets

    @abstractmethod
    async def query(self, target: Target) -> SourceResult:
        """Return a SourceResult for the given target."""

    async def _get_json(self, url: str, *, headers: dict | None = None, params: dict | None = None) -> dict | list:
        key = cache.make_key(self.id, "json", url, repr(params or {}))
        cached = cache.get(key)
        if cached is not None:
            return cached
        r = await self.client.get(url, headers=headers, params=params, timeout=self.config.timeout)
        r.raise_for_status()
        data = r.json()
        cache.put(key, data, ttl=self.config.cache_ttl)
        return data

    async def _get_text(self, url: str, *, headers: dict | None = None, params: dict | None = None) -> str:
        key = cache.make_key(self.id, "text", url, repr(params or {}))
        cached = cache.get(key)
        if cached is not None:
            return cached
        r = await self.client.get(url, headers=headers, params=params, timeout=self.config.timeout)
        r.raise_for_status()
        text = r.text
        cache.put(key, text, ttl=self.config.cache_ttl)
        return text

    def _timed(self) -> _Timer:
        return _Timer()


class _Timer:
    def __init__(self):
        self.start = time.time()

    def ms(self) -> int:
        return int((time.time() - self.start) * 1000)


def empty_result(source_id: str, url: str | None = None) -> SourceResult:
    return SourceResult(source=source_id, queried_url=url)


def error_result(source_id: str, url: str | None, error: str) -> SourceResult:
    return SourceResult(source=source_id, queried_url=url, ok=False, error=error)
