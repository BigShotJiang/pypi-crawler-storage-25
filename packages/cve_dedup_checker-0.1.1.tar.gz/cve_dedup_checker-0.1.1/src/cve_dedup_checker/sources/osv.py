"""OSV (Open Source Vulnerabilities) — Google aggregator across GHSA, PyPA, RustSec, OSS-Fuzz, etc.

Docs: https://google.github.io/osv.dev/api/
Free, no auth required.
"""

from __future__ import annotations

from cve_dedup_checker.models import Advisory, Severity, SourceResult, Target
from cve_dedup_checker.sources.base import Source, empty_result, error_result

OSV_URL = "https://api.osv.dev/v1/query"


_ECOSYSTEM_MAP = {
    "npm": "npm",
    "pypi": "PyPI",
    "github": None,  # We use package manager inputs; GitHub repo lookup via ghsa is handled by GH source.
}


class OsvSource(Source):
    id = "osv"
    human_name = "OSV (Google)"
    supported_targets = {"npm", "pypi", "github", "keyword"}

    async def query(self, target: Target) -> SourceResult:
        t = self._timed()
        payload = self._payload(target)
        if payload is None:
            return empty_result(self.id, OSV_URL)
        try:
            r = await self.client.post(
                OSV_URL, json=payload, timeout=self.config.timeout
            )
            r.raise_for_status()
            data = r.json()
        except Exception as e:  # noqa: BLE001
            result = error_result(self.id, OSV_URL, str(e))
            result.elapsed_ms = t.ms()
            return result

        advisories = []
        for vuln in (data or {}).get("vulns", []) or []:
            aliases = vuln.get("aliases") or []
            cve_id = next((a for a in aliases if a.startswith("CVE-")), None)
            osv_id = vuln.get("id")
            severity_list = vuln.get("severity") or []
            score, sev = _severity(severity_list, vuln.get("database_specific") or {})
            advisories.append(
                Advisory(
                    source=self.id,
                    cve_id=cve_id,
                    title=vuln.get("summary") or osv_id or "(unknown)",
                    url=f"https://osv.dev/vulnerability/{osv_id}",
                    severity=sev,
                    cvss_score=score,
                    summary=(vuln.get("details") or "")[:600],
                    published=vuln.get("published"),
                    raw={},
                )
            )
        result = SourceResult(source=self.id, queried_url=OSV_URL, advisories=advisories)
        result.elapsed_ms = t.ms()
        return result

    def _payload(self, target: Target) -> dict | None:
        kind = target.type.value
        if kind in _ECOSYSTEM_MAP and _ECOSYSTEM_MAP[kind]:
            return {"package": {"name": target.identifier, "ecosystem": _ECOSYSTEM_MAP[kind]}}
        if kind == "github":
            # OSV covers GHSA via ecosystem queries only (npm, PyPI, Go, Maven...). For a pure
            # GitHub repo we instead let the GitHub Advisories source handle it.
            return None
        if kind == "keyword":
            # OSV doesn't have a free-text endpoint; skip.
            return None
        return None


def _severity(entries: list, database_specific: dict) -> tuple[float | None, Severity]:
    # OSV severity entries are CVSS vectors. Pull score from the database_specific.severity label too.
    sev_label = (database_specific.get("severity") or "").lower()
    if sev_label in {"low", "medium", "high", "critical", "none"}:
        return None, Severity(sev_label)
    return None, Severity.UNKNOWN
