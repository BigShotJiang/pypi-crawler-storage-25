"""NVD (NIST National Vulnerability Database) — public REST API 2.0.

Docs: https://nvd.nist.gov/developers/vulnerabilities
Free, no auth required. Conservative rate limit without an API key (~5 req / 30s).
"""

from __future__ import annotations

from cve_dedup_checker.models import Advisory, Severity, SourceResult, Target
from cve_dedup_checker.sources.base import Source, empty_result, error_result

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"


class NvdSource(Source):
    id = "nvd"
    human_name = "NVD"
    supported_targets = {"wp-plugin", "wp-theme", "npm", "pypi", "github", "cpe", "keyword"}

    async def query(self, target: Target) -> SourceResult:
        t = self._timed()
        params = self._params_for(target)
        if not params:
            return empty_result(self.id, NVD_URL)
        try:
            data = await self._get_json(NVD_URL, params=params)
        except Exception as e:  # noqa: BLE001
            result = error_result(self.id, NVD_URL, str(e))
            result.elapsed_ms = t.ms()
            return result

        advisories: list[Advisory] = []
        for item in (data or {}).get("vulnerabilities", []) or []:
            cve = item.get("cve", {})
            cve_id = cve.get("id")
            descriptions = cve.get("descriptions", []) or []
            summary = next((d.get("value", "") for d in descriptions if d.get("lang") == "en"), "")
            metrics = cve.get("metrics", {}) or {}
            score, severity = _cvss(metrics)
            published = cve.get("published")
            advisories.append(
                Advisory(
                    source=self.id,
                    cve_id=cve_id,
                    title=cve_id or "(unknown)",
                    url=f"https://nvd.nist.gov/vuln/detail/{cve_id}" if cve_id else NVD_URL,
                    severity=severity,
                    cvss_score=score,
                    summary=summary[:600],
                    published=published,
                    raw={},
                )
            )
        result = SourceResult(
            source=self.id,
            queried_url=NVD_URL,
            advisories=advisories,
        )
        result.elapsed_ms = t.ms()
        return result

    def _params_for(self, target: Target) -> dict | None:
        # CPE search for explicit CPE; keyword search for everything else.
        if target.type.value == "cpe":
            return {"cpeName": target.identifier, "resultsPerPage": 50}
        kw = _keyword_for(target)
        if not kw:
            return None
        return {"keywordSearch": kw, "resultsPerPage": 50}


def _keyword_for(target: Target) -> str:
    return target.identifier


def _cvss(metrics: dict) -> tuple[float | None, Severity]:
    # Prefer CVSS v3.1 > v3.0 > v2 > unknown.
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        entries = metrics.get(key) or []
        for entry in entries:
            cvss = entry.get("cvssData", {}) or {}
            score = cvss.get("baseScore")
            sev = (cvss.get("baseSeverity") or entry.get("baseSeverity") or "").lower()
            if score is not None:
                return float(score), _severity_from(sev, float(score))
    return None, Severity.UNKNOWN


def _severity_from(label: str, score: float) -> Severity:
    if label in {"low", "medium", "high", "critical", "none"}:
        return Severity(label)
    if score >= 9.0:
        return Severity.CRITICAL
    if score >= 7.0:
        return Severity.HIGH
    if score >= 4.0:
        return Severity.MEDIUM
    if score > 0:
        return Severity.LOW
    return Severity.NONE
