"""Patchstack public database scraper.

No paid API tier required. We read the public HTML of:
  https://patchstack.com/database/wordpress/plugin/<slug>/vulnerabilities
  https://patchstack.com/database/wordpress/theme/<slug>/vulnerabilities
"""

from __future__ import annotations

import re
from urllib.parse import quote

from bs4 import BeautifulSoup

from cve_dedup_checker.models import Advisory, Severity, SourceResult, Target
from cve_dedup_checker.sources.base import Source, empty_result, error_result

BASE = "https://patchstack.com"


class PatchstackSource(Source):
    id = "patchstack"
    human_name = "Patchstack"
    supported_targets = {"wp-plugin", "wp-theme"}

    async def query(self, target: Target) -> SourceResult:
        t = self._timed()
        kind = "plugin" if target.type.value == "wp-plugin" else "theme"
        safe_slug = quote(target.identifier, safe="")
        url = f"{BASE}/database/wordpress/{kind}/{safe_slug}/vulnerabilities"
        try:
            html = await self._get_text(url)
        except Exception as e:  # noqa: BLE001
            # Patchstack returns 404 when the slug isn't in their DB - treat as clean.
            msg = str(e)
            if "404" in msg:
                result = empty_result(self.id, url)
                result.elapsed_ms = t.ms()
                return result
            result = error_result(self.id, url, msg)
            result.elapsed_ms = t.ms()
            return result

        soup = BeautifulSoup(html, "lxml")
        advisories: list[Advisory] = []

        for link in soup.find_all("a", href=re.compile(r"/vulnerability/")):
            href = link.get("href") or ""
            title = link.get_text(strip=True) or ""
            if not title:
                continue
            if not href.startswith("http"):
                href = BASE + href
            advisories.append(
                Advisory(
                    source=self.id,
                    cve_id=None,
                    title=title[:300],
                    url=href,
                    severity=Severity.UNKNOWN,
                    affected_product=f"{kind}:{target.identifier}",
                )
            )

        seen = set()
        unique: list[Advisory] = []
        for a in advisories:
            if a.url in seen:
                continue
            seen.add(a.url)
            unique.append(a)

        result = SourceResult(source=self.id, queried_url=url, advisories=unique)
        result.elapsed_ms = t.ms()
        return result
