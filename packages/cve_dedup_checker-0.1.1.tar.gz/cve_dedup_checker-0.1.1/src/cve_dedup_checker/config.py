"""Optional user config loader. All features work without a config file."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

from platformdirs import user_config_dir

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover
    import tomli as tomllib


@dataclass
class Config:
    # Optional: provides a higher GitHub API rate limit. Not required.
    github_token: str | None = None

    # Optional: WPScan API token. Not required - we scrape the public plugin page instead.
    wpscan_token: str | None = None

    # Request timeouts in seconds.
    timeout: float = 15.0

    # Default cache TTL in seconds.
    cache_ttl: int = 6 * 60 * 60

    # Disable specific sources by ID.
    disabled_sources: list[str] = field(default_factory=list)


def config_path() -> Path:
    return Path(user_config_dir("cve-dedup-checker")) / "config.toml"


def load() -> Config:
    cfg = Config()

    path = config_path()
    if path.exists():
        with path.open("rb") as f:
            data = tomllib.load(f)
        cfg.github_token = data.get("github_token") or cfg.github_token
        cfg.wpscan_token = data.get("wpscan_token") or cfg.wpscan_token
        cfg.timeout = float(data.get("timeout", cfg.timeout))
        cfg.cache_ttl = int(data.get("cache_ttl", cfg.cache_ttl))
        cfg.disabled_sources = list(data.get("disabled_sources", cfg.disabled_sources))

    # Environment variables override file config.
    cfg.github_token = os.environ.get("GITHUB_TOKEN") or cfg.github_token
    cfg.wpscan_token = os.environ.get("WPSCAN_TOKEN") or cfg.wpscan_token

    return cfg


def sample_config_text() -> str:
    return (
        "# cve-dedup-checker config.\n"
        "# All fields are optional. Tool works without any config.\n"
        "\n"
        "# Increases GitHub API rate limit from 60/hr to 5000/hr.\n"
        '# github_token = "ghp_xxxxxxxxxxxxxxxxxxxx"\n'
        "\n"
        "# Request timeout in seconds.\n"
        "timeout = 15.0\n"
        "\n"
        "# Cache TTL in seconds (default: 6 hours).\n"
        "cache_ttl = 21600\n"
        "\n"
        '# disabled_sources = ["exploit-db"]\n'
    )
