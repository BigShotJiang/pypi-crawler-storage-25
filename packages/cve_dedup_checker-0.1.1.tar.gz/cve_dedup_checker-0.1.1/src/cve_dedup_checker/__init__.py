"""cve-dedup-checker: parallel duplicate-check for CVE and vulnerability databases."""

__version__ = "0.1.1"
