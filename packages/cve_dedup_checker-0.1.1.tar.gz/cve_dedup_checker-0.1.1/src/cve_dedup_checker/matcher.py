"""Classify aggregated source results into clean / possible / confirmed."""

from __future__ import annotations

import re

from cve_dedup_checker.models import Advisory, DedupReport, MatchConfidence, SourceResult, Target

# Reasonably common vulnerability-class synonyms for fuzzy comparison.
_CLASS_SYNONYMS = {
    "xss": ["xss", "cross-site scripting", "cross site scripting"],
    "sqli": ["sqli", "sql injection", "blind sql"],
    "csrf": ["csrf", "cross-site request forgery"],
    "ssrf": ["ssrf", "server-side request forgery"],
    "rce": ["rce", "remote code execution", "command injection"],
    "lfi": ["lfi", "local file inclusion", "path traversal", "directory traversal"],
    "broken-access-control": [
        "broken access control",
        "access control",
        "missing authorization",
        "idor",
        "insecure direct object reference",
        "authorization bypass",
        "privilege escalation",
    ],
    "info-disclosure": [
        "information disclosure",
        "info disclosure",
        "sensitive data exposure",
        "information leak",
    ],
    "file-upload": [
        "arbitrary file upload",
        "unrestricted file upload",
        "file upload",
    ],
    "deserialization": [
        "deserialization",
        "unserialize",
    ],
    "open-redirect": [
        "open redirect",
    ],
    "auth-bypass": [
        "authentication bypass",
        "auth bypass",
    ],
}


def classify(target: Target, results: list[SourceResult]) -> DedupReport:
    possible: list[Advisory] = []
    confirmed: list[Advisory] = []

    vuln_terms = _class_terms(target.vuln_class)

    # Match identifier terms loosely (slug vs product name variations).
    id_terms = _identifier_terms(target.identifier)

    for r in results:
        for adv in r.advisories:
            blob = _advisory_blob(adv)
            if vuln_terms and not _any_match(vuln_terms, blob):
                # Source returned a hit for this product but for a different vuln class.
                possible.append(adv)
                continue

            if _any_match(id_terms, blob):
                # Strong match: identifier + vuln class both present in the advisory text.
                confirmed.append(adv)
            else:
                possible.append(adv)

    if confirmed:
        confidence = MatchConfidence.CONFIRMED
    elif possible:
        confidence = MatchConfidence.POSSIBLE
    else:
        confidence = MatchConfidence.CLEAN

    return DedupReport(
        target=target,
        results=results,
        confidence=confidence,
        possible_matches=possible,
        confirmed_matches=confirmed,
        queried_sources=len(results),
        successful_sources=sum(1 for r in results if r.ok),
    )


def _advisory_blob(adv: Advisory) -> str:
    return " ".join(
        [
            adv.title or "",
            adv.summary or "",
            adv.affected_product or "",
            adv.affected_versions or "",
            adv.source,
        ]
    ).lower()


def _class_terms(raw: str | None) -> list[str]:
    if not raw:
        return []
    k = raw.strip().lower()
    # Direct synonyms.
    if k in _CLASS_SYNONYMS:
        return _CLASS_SYNONYMS[k]
    # Fuzzy: try matching the user input to any canonical synonym group.
    for canonical, synonyms in _CLASS_SYNONYMS.items():
        for syn in synonyms:
            if syn in k or k in syn or k == canonical:
                return synonyms
    # Otherwise, use the raw input as-is.
    return [k]


def _identifier_terms(identifier: str) -> list[str]:
    # Split on common separators so both "ele-custom-skin" and "ele custom skin" match.
    base = identifier.lower()
    parts = [base]
    parts.extend(re.split(r"[-_/\s]+", base))
    return [p for p in parts if len(p) >= 3]


def _any_match(terms: list[str], blob: str) -> bool:
    if not terms:
        return False
    return any(term in blob for term in terms)
