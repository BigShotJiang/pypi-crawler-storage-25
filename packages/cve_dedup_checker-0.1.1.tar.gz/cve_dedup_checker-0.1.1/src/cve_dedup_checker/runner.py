"""Orchestrates parallel source queries and returns the classified DedupReport."""

from __future__ import annotations

import asyncio

import httpx

from cve_dedup_checker.config import Config
from cve_dedup_checker.matcher import classify
from cve_dedup_checker.models import DedupReport, SourceResult, Target
from cve_dedup_checker.sources import ALL_SOURCES
from cve_dedup_checker.sources.base import Source

USER_AGENT = "cve-dedup-checker/0.1 (+https://github.com/jashidsany/cve-dedup-checker)"


async def run(target: Target, config: Config | None = None) -> DedupReport:
    cfg = config or Config()

    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/html;q=0.9"}
    async with httpx.AsyncClient(
        headers=headers,
        timeout=cfg.timeout,
        follow_redirects=True,
        http2=True,
    ) as client:
        sources: list[Source] = [cls(client, cfg) for cls in ALL_SOURCES]
        active = [s for s in sources if s.id not in cfg.disabled_sources and s.supports(target)]
        tasks = [asyncio.create_task(_safe_query(s, target)) for s in active]
        results: list[SourceResult] = await asyncio.gather(*tasks)

    return classify(target, results)


async def _safe_query(source: Source, target: Target) -> SourceResult:
    try:
        return await source.query(target)
    except Exception as e:  # noqa: BLE001
        return SourceResult(source=source.id, ok=False, error=f"unhandled: {e}")
