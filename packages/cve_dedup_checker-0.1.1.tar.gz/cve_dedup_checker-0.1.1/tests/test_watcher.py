"""Unit tests for watcher interval parser (pure function, no network, no state)."""

from __future__ import annotations

import pytest

from cve_dedup_checker.watcher import parse_interval


def test_seconds() -> None:
    assert parse_interval("90") == 90
    assert parse_interval("90s") == 90
    assert parse_interval("120s") == 120


def test_minutes() -> None:
    assert parse_interval("1m") == 60
    assert parse_interval("10m") == 600
    assert parse_interval("30m") == 1800


def test_hours() -> None:
    assert parse_interval("1h") == 3600
    assert parse_interval("6h") == 21600


def test_days() -> None:
    assert parse_interval("1d") == 86400
    assert parse_interval("7d") == 604800


def test_min_interval_enforced() -> None:
    with pytest.raises(ValueError, match="at least 60"):
        parse_interval("30s")
    with pytest.raises(ValueError, match="at least 60"):
        parse_interval("10")


def test_invalid_format() -> None:
    with pytest.raises(ValueError, match="invalid interval"):
        parse_interval("abc")
    with pytest.raises(ValueError, match="invalid interval"):
        parse_interval("")
