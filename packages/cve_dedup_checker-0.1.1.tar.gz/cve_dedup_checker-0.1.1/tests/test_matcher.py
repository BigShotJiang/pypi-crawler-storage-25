"""Unit tests for matcher classification logic (offline, no network)."""

from __future__ import annotations

from cve_dedup_checker.matcher import classify
from cve_dedup_checker.models import (
    Advisory,
    MatchConfidence,
    Severity,
    SourceResult,
    Target,
    TargetType,
)


def _adv(source: str, title: str, summary: str = "") -> Advisory:
    return Advisory(source=source, title=title, url=f"https://example.com/{source}", summary=summary, severity=Severity.UNKNOWN)


def test_clean_when_no_advisories() -> None:
    target = Target(type=TargetType.WP_PLUGIN, identifier="never-heard-of-it")
    results = [SourceResult(source="nvd"), SourceResult(source="osv")]
    report = classify(target, results)
    assert report.confidence == MatchConfidence.CLEAN
    assert report.confirmed_matches == []
    assert report.possible_matches == []


def test_confirmed_when_identifier_and_class_match() -> None:
    target = Target(
        type=TargetType.WP_PLUGIN,
        identifier="ele-custom-skin",
        vuln_class="broken-access-control",
    )
    hit = _adv(
        "nvd",
        "ele-custom-skin plugin broken access control allows unauthenticated read",
    )
    results = [SourceResult(source="nvd", advisories=[hit])]
    report = classify(target, results)
    assert report.confidence == MatchConfidence.CONFIRMED
    assert hit in report.confirmed_matches


def test_possible_when_identifier_matches_but_class_does_not() -> None:
    target = Target(
        type=TargetType.WP_PLUGIN,
        identifier="ele-custom-skin",
        vuln_class="xss",
    )
    hit = _adv(
        "nvd",
        "ele-custom-skin plugin SQL injection via WP_Query",
    )
    results = [SourceResult(source="nvd", advisories=[hit])]
    report = classify(target, results)
    assert report.confidence == MatchConfidence.POSSIBLE
    assert hit in report.possible_matches


def test_synonym_folding_xss() -> None:
    target = Target(type=TargetType.NPM, identifier="example-lib", vuln_class="xss")
    hit = _adv("ghsa", "example-lib cross-site scripting via innerHTML")
    report = classify(target, [SourceResult(source="ghsa", advisories=[hit])])
    assert report.confidence == MatchConfidence.CONFIRMED


def test_identifier_fuzz_matches_slug_variations() -> None:
    target = Target(type=TargetType.WP_PLUGIN, identifier="ele-custom-skin", vuln_class="info-disclosure")
    # Advisory text uses the product's human name with spaces rather than the slug.
    hit = _adv("wpscan", "ele custom skin information disclosure")
    report = classify(target, [SourceResult(source="wpscan", advisories=[hit])])
    assert report.confidence == MatchConfidence.CONFIRMED
