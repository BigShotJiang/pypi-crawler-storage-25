# Reference inventory: removed agents, credits, revenue

**Repo:** Venda  
**Updated:** 2026-04-10  

This document lists **every file** in the tree that still mentions **removed agents** (and related symbols), the **credits** billing system, or **revenue** (creator/script earnings). Use it for cleanup, refactors, or doc audits.

**Note:** `knowledge owl` / `knowledge_owl` / `knowledge-owl` — **no matches** anywhere in this repository.

**Note:** `vending_machine_mcp/` (published MCP package) has **no** `credit` / `credits` references; it still surfaces script **`revenue`** in `info()` output and in `scripts.py` (marketplace metadata).

---

## 1. Removed agent IDs (canonical kebab-case)

These IDs appear in code, docs, or guardrails even though product/MCP listings treat them as removed:

| Agent ID        | Python module (still on disk)   |
|----------------|----------------------------------|
| `research-owl` | `backend/agents/research_owl.py` |
| `info-scout`   | `backend/agents/info_scout.py`   |
| `fridge-chef`  | `backend/agents/fridge_chef.py`  |
| `spreadsheet-sage` | `backend/agents/spreadsheet_sage.py` |
| `web-weaver`   | `backend/agents/web_weaver.py`   |
| `ceo-agent`    | `backend/agents/ceo_agent.py` (+ `backend/ceo_runner.py`) |

**Symbol variants to search** when purging: `research_owl`, `research-owl`, `Research Owl`; same pattern for other agents (`info_scout` / `info-scout`, etc.).

---

## 2. Files mentioning removed agents (any pattern)

Sorted paths:

- `backend/agents/ceo_agent.py` — tool/registry strings for removed agents + `ceo-agent` job metadata  
- `backend/agents/fridge_chef.py`  
- `backend/agents/info_scout.py` — text references to Research Owl  
- `backend/agents/llm.py` — `MODELS` / upload tiers for removed IDs; `RESEARCH_OWL_MODELS`; direct-OpenAI helpers for Research Owl  
- `backend/agents/registry.py` — imports graphs + `AGENT_GRAPHS` / display names for removed IDs  
- `backend/agents/research_owl.py`  
- `backend/agents/spreadsheet_sage.py`  
- `backend/agents/web_weaver.py`  
- `backend/ceo_runner.py` — `ceo-agent` job execution  
- `backend/credits.py` — `_AGENT_MODEL_TIER` entries for `research-owl`, `info-scout`, `fridge-chef`, `spreadsheet-sage`, `web-weaver`  
- `backend/guards/gate_keeper.py` — `web-weaver` policy  
- `backend/guards/qa_auditor.py` — QA agent allowlist includes removed IDs  
- `backend/main.py` — `ceo-agent` routes/jobs; lists of agent IDs; `removed = { ... }` filter for public agent APIs  
- `docs/AGENTS.md` — Research Owl, job queue, API keys; `fridge_chef.py` in file listing  
- `docs/CLAUDE.md` — same as `AGENTS.md`  
- `docs/reference-inventory-removed-agents.txt` — stub pointer to this file  

**Portal (`portal/`):** no matches for these agent IDs in TS/TSX (as of inventory date).

---

## 3. Research Owl–specific references

Files that mention Research Owl / `research-owl` / `research_owl` / `RESEARCH_OWL_*` / `build_research_owl`:

- `backend/agents/research_owl.py`  
- `backend/agents/registry.py`  
- `backend/agents/llm.py`  
- `backend/agents/info_scout.py` (prompt copy compares to Research Owl)  
- `backend/agents/ceo_agent.py`  
- `backend/credits.py`  
- `backend/guards/qa_auditor.py`  
- `backend/main.py` (module docstring / comments)  
- `docs/AGENTS.md`  
- `docs/CLAUDE.md`  
- `docs/reference-inventory-removed-agents.txt` (pointer only)  

---

## 4. Credits system — all files (substring `credit`, case-insensitive)

Billing, ledger, webhooks, UI copy, tests, and MCP server (backend copy):

- `backend/credits.py` — core implementation  
- `backend/job_runner.py` — deduct on job completion  
- `backend/main.py` — balance checks, `/api/credits/me`, API key generation, engagements  
- `backend/mcp_server.py` — insufficient-credit errors + deduct (if still deployed from `backend/`)  
- `backend/supabase/migrations/001_initial_schema.sql`  
- `backend/supabase/migrations/002_user_profiles.sql`  
- `backend/tests/test_supabase.py`  
- `backend/webhook_service.py` — `EventType.CREDIT_LOW`  
- `backend/webhook_service/API.md`  
- `backend/webhooks/events.py` — `cost_credits`, `notify_credit_low`  
- `backend/webhooks/models.py` — `CREDIT_LOW`  
- `backend/webhooks/router.py` — `cost_credits` in payloads  
- `docs/PRODUCTION_READINESS_CHECKLIST.md`  
- `docs/reference-inventory-removed-agents.txt` (pointer only)  
- `portal/src/components/engagements/PackageCard.tsx`  
- `portal/src/pages/NewEngagementPage.tsx`  
- `portal/src/types/engagement.ts`  

---

## 5. Revenue — all files (`revenue` word boundary, case-insensitive)

Script/creator earnings, graph DB, MCP `info` tool, portal dashboard:

- `backend/graph.py`  
- `backend/main.py` — creator/dashboard style aggregations  
- `backend/mcp_server.py` — `info` output line  
- `backend/scripts.py` — script model + `record_run`  
- `backend/supabase/migrations/001_initial_schema.sql`  
- `backend/tests/test_api.py`  
- `backend/tests/test_integration.py`  
- `backend/tests/test_supabase.py`  
- `backend/tests/test_unit.py`  
- `docs/reference-inventory-removed-agents.txt` (pointer only)  
- `portal/src/data/creator-dashboard.ts`  
- `portal/src/pages/CatalogPage.tsx`  
- `portal/src/pages/CreatorDashboardPage.tsx`  
- `portal/src/pages/ScriptDetailPage.tsx`  
- `portal/src/stores/useCreatorDashboardStore.ts`  
- `portal/src/types/creator-dashboard.ts`  
- `portal/src/types/script.ts`  
- `vending_machine_mcp/mcp_server.py`  
- `vending_machine_mcp/scripts.py`  

---

## 6. Regenerating line-level references

From the repo root (requires [ripgrep](https://github.com/BurntSushi/ripgrep)):

```bash
rg -n -i 'research.?owl|research_owl|research-owl' .
rg -n -i 'knowledge.?owl|knowledge_owl|knowledge-owl' .   # expect no hits
rg -n -i '\bcredit' .
rg -n -i '\brevenue\b' .
rg -n 'info-scout|info_scout|fridge-chef|fridge_chef|spreadsheet-sage|spreadsheet_sage|web-weaver|web_weaver|ceo-agent|ceo_agent' .
```

---

## 7. Legacy filename

`docs/reference-inventory-removed-agents.txt` now contains only a pointer to this document (the old line-by-line dump was removed to avoid stale duplicates).
