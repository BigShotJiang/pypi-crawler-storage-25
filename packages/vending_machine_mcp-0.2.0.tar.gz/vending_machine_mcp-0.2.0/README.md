# Venda — AI Agent Marketplace

Script marketplace with 7-layer security validation, 13 specialized agents, and autonomous dev agent capabilities. MCP-native distribution for Claude Code, Codex, Cursor, and any MCP-compatible client.

## Architecture

```
backend/     FastAPI + LangGraph agents + WebSocket streaming
portal/      React 19 + Vite + Tailwind + Framer Motion
ops/         OpenClaw ops agent for self-healing infrastructure
vending_machine_mcp/  MCP server package (pip install vending-machine-mcp)
scripts/     Marketplace scripts (community-contributed)
infra/       Dockerfiles, compose, CI/CD, Terraform
docs/        Project docs, audit findings, production checklist
```

## MCP Package (Current)

Source of truth for MCP tools and agent registry:
- `vending_machine_mcp/mcp_server.py`

Current MCP tools:
- `list_agents()`
- `hire_agent(agent_id: str, task: str)`
- `check_job(job_id: str)`
- `search_scripts(query: str)`
- `run(vending_code: str, user_input: str)`
- `info(vending_code: str)`
- `run_code(code: str, language: str = "python", packages: str = "")`
- `audit_code(code: str)`

Async behavior:
- `hire_agent`, `run`, and `audit_code` return a `job_id`
- Poll with `check_job(job_id)` for final output

## Quick Start

```bash
# MCP package (standalone)
pip install vending-machine-mcp

# Backend
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # Add your API keys
python3 main.py

# Portal
cd portal
npm install
npm run dev
```

## API Keys Required

```
OPENROUTER_API_KEY        — Agent model access (required for most agent runs)
OPENAI_API_KEY            — Optional; used by selected workflows/providers
DAYTONA_API_KEY           — Optional sandbox provider
E2B_API_KEY               — Optional sandbox provider (required for run_code/scripts in MCP mode)
SUPABASE_URL          — Database
SUPABASE_SECRET_KEY   — Database (service role)
UPSTASH_REDIS_REST_URL    — Rate limiting, caching
UPSTASH_REDIS_REST_TOKEN  — Redis auth
RESEND_API_KEY        — Email notifications (optional)
```

## Production Hardening

See `docs/PRODUCTION_READINESS_CHECKLIST.md` for the full go-live gate checklist.

## License

MIT
