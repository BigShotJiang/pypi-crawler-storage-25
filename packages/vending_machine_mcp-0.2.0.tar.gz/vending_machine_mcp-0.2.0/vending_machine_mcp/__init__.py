"""Vending Machine MCP Server — AI agent marketplace."""

__version__ = "0.2.0"
