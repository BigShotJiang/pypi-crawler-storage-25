# agent-track — PyPI Publishing Plan

## What This Is

`agent-track` (working name) is a **zero-dependency**, **single-file** Python CLI tool for lightweight ticketing and multi-agent coordination. It was built to orchestrate multiple Claude Code sessions working on the same codebase in parallel.

All state lives in a `.track/` directory as markdown files (tickets) and JSON files (agents). No database, no external services.

## Current State

### Single source file: `track.py` (~1370 lines)

Contains everything:
- **CLI** (argparse, 17 subcommands)
- **Web dashboard** (stdlib `http.server`, dark/light theme, auto-refresh)
- **Concurrency** (`fcntl.flock` advisory locks, atomic writes)
- **Frontmatter parser** (stdlib-only YAML-like frontmatter for ticket files)

### Dependencies: **None** (Python stdlib only)

### Python version: **3.10+** (tested on 3.10.16)

### Known Python 3.10 constraint
No backslashes inside f-string expressions. This was already fixed in the current code, but keep it in mind for future changes.

### Platform: **macOS/Linux only** (uses `fcntl.flock` and `os.fork`)
Windows support would require replacing `fcntl` with `msvcrt` or a cross-platform lock, and replacing `os.fork()` with `subprocess` or `multiprocessing` for the `serve -d` daemon mode.

---

## Architecture

### Directory Structure (created by `track init`)

```
project-root/
└── .track/
    ├── CONVENTIONS.md      # Agent onboarding doc (auto-generated)
    ├── BOARD.md             # Append-only inter-agent message board
    ├── .gitignore           # Ignores locks/
    ├── tickets/             # T-0001.md, T-0002.md, ...
    ├── agents/              # agent-alpha.json, agent-bravo.json, ...
    ├── locks/               # Transient fcntl lock files (gitignored)
    └── archive/             # Completed tickets moved here (future)
```

### Ticket Format

YAML frontmatter + markdown body. Example:

```markdown
---
id: T-0001
title: Fix authentication bug
status: in-progress
priority: high
created: 2026-03-29T10:32:54Z
created_by: human
claimed_by: agent-alpha
claimed_at: 2026-03-29T10:34:24Z
labels:
  - python
  - auth
branch: null
files:
  - server/auth.py
depends_on: []
---

## Description

Auth tokens expire silently...

## Acceptance Criteria

- [ ] Tokens refresh automatically

## Work Log

### [2026-03-29T10:35:00Z] agent-alpha
Investigating token refresh logic in auth.py
```

### Agent Format (JSON)

```json
{
  "id": "agent-alpha",
  "registered_at": "2026-03-29T10:32:54Z",
  "last_heartbeat": "2026-03-29T10:34:26Z",
  "status": "active",
  "current_ticket": "T-0001",
  "capabilities": ["python", "server"],
  "session_id": null,
  "worktree": null,
  "files_modified": [
    {"path": "server/auth.py", "ticket": "T-0001", "timestamp": "..."}
  ],
  "history": [
    {"ticket": "T-0001", "action": "claimed", "timestamp": "..."}
  ]
}
```

### Board Format (BOARD.md)

Append-only markdown. New entries are prepended after a marker comment:

```markdown
# .track Board

<!-- New messages are prepended below this line -->
---
**[2026-03-29T10:34:34Z] agent-alpha** | T-0001 | note
Found the root cause in token_refresh().

---
**[2026-03-29T10:34:24Z] agent-alpha** | T-0001 | claimed
Claiming T-0001: Fix authentication bug
```

### Concurrency Model

- **Per-ticket locks**: `fcntl.flock` on `.track/locks/{ticket_id}.lock`
- **Board lock**: `fcntl.flock` on `.track/locks/_board.lock`
- **Create lock**: `fcntl.flock` on `.track/locks/_create.lock` (prevents duplicate IDs)
- **Claim uses non-blocking lock** (`LOCK_NB`): fails fast if another agent is claiming simultaneously
- **Atomic writes**: write to `.tmp` file then `rename()` (prevents partial reads)

### Dashboard

- `http.server` on port 7777 (configurable)
- Serves HTML with inline CSS (Qargo design system: Inter + IBM Plex Mono fonts, beige light theme, dark theme via `prefers-color-scheme`)
- Auto-refreshes every 5s (pauses when tab is hidden)
- Routes: `/` (kanban dashboard), `/ticket?id=T-0001` (detail page)
- JSON API: `/api/tickets`, `/api/agents`, `/api/board`, `/api/files`
- Daemon mode: `os.fork()` + `os.setsid()` + PID file at `.track/locks/server.pid`

---

## CLI Commands

| Command | Description |
|---------|-------------|
| `track init` | Create `.track/` structure with CONVENTIONS.md and BOARD.md |
| `track create --title "..." [-p priority] [-l labels] [--depends-on T-0001] [--body "..."] [--by human]` | Create ticket |
| `track list [--status X] [--agent X] [--label X] [--priority X] [-a/--all]` | List tickets (excludes done by default) |
| `track show T-0001` | Print full ticket markdown |
| `track claim T-0001 --agent X [--force]` | Claim ticket (checks deps, uses non-blocking lock) |
| `track update T-0001 --status X [--agent X] [--branch X] [--add-label X] [--title X] [--force]` | Update ticket (enforces valid status transitions) |
| `track log T-0001 --agent X -m "message"` | Append to ticket work log |
| `track board --agent X [--ticket T-0001] [--tag note] -m "message"` | Post to board |
| `track board --last 10` | Read last N board entries |
| `track register [--agent X] [--capabilities python,ui] [--session-id X] [--worktree X]` | Register agent (auto-generates NATO alphabet ID if omitted) |
| `track deregister --agent X [--release-tickets]` | Mark agent inactive, optionally release tickets to backlog |
| `track files --add path --agent X --ticket T-0001` | Track file ownership |
| `track files --check path` | Check who owns a file |
| `track files --list` | List all tracked files (flags conflicts) |
| `track heartbeat --agent X` | Update heartbeat timestamp |
| `track stale [--reclaim] [--threshold 30]` | Detect/reclaim stale agents |
| `track serve [--port 7777] [-d]` | Start web dashboard (`-d` = daemonize) |
| `track stop` | Stop background dashboard (reads PID file, sends SIGTERM) |

### Status Lifecycle

```
backlog → claimed → in-progress → review → done
```

Valid transitions are enforced. Use `--force` to override.

### Agent ID Auto-Generation

If `--agent` is omitted during `register`, the tool picks the next available NATO alphabet name: `agent-alpha`, `agent-bravo`, `agent-charlie`, etc.

---

## PyPI Publishing Plan

### 1. Package Name

`track` is taken on PyPI. Candidates:
- `agent-track` — clear, matches the repo name
- `dot-track` — references the `.track/` directory
- `trackr` — short

Check availability: `pip index versions agent-track`

### 2. Package Structure

```
agent-track/
├── pyproject.toml          # Package metadata + build config
├── README.md               # PyPI description (from this plan + polish)
├── LICENSE                  # MIT
├── src/
│   └── agent_track/
│       ├── __init__.py     # __version__ = "0.1.0"
│       ├── cli.py          # All CLI logic (moved from track.py)
│       ├── dashboard.py    # Dashboard HTML/CSS/JS + HTTP server
│       ├── models.py       # Ticket/Agent I/O, frontmatter parser
│       └── lock.py         # fcntl locking, atomic writes
└── tests/
    ├── test_cli.py
    ├── test_models.py
    └── test_lock.py
```

**Why split?** A single 1370-line file is fine for a vendored script but awkward for a published package. Splitting into 4 modules (~300 lines each) makes it maintainable. All modules remain stdlib-only.

**Alternative:** Keep it as a single module `src/agent_track/cli.py` with `__init__.py` re-exporting `main`. This is simpler and preserves the "single-file" spirit. Either approach works.

### 3. pyproject.toml

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "agent-track"
version = "0.1.0"
description = "Lightweight ticketing & agent coordination for multi-agent coding workflows"
readme = "README.md"
license = "MIT"
requires-python = ">=3.10"
authors = [
    { name = "Enes Kaya" }
]
keywords = ["cli", "ticketing", "agents", "coordination", "kanban"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Environment :: Console",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Operating System :: MacOS",
    "Operating System :: POSIX :: Linux",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Software Development :: Bug Tracking",
]

[project.scripts]
track = "agent_track.cli:main"

[project.urls]
Homepage = "https://github.com/yourusername/agent-track"
Repository = "https://github.com/yourusername/agent-track"
```

### 4. How the CLI Symlink Works (No Sudo)

When a user runs:

```bash
# Option A: pipx (recommended for CLI tools)
pipx install agent-track
# Creates isolated venv + symlinks `track` to ~/.local/bin/track

# Option B: pip --user
pip install --user agent-track
# Installs to ~/.local/lib/python3.x/site-packages/
# Creates wrapper script at ~/.local/bin/track

# Option C: pip in a venv
pip install agent-track
# Installs to venv's site-packages/
# Creates wrapper script at venv/bin/track
```

All three approaches create a small shell wrapper script (not a symlink) that looks like:

```python
#!/path/to/python
from agent_track.cli import main
main()
```

**No sudo required** because `~/.local/bin/` is a user-writable directory. Most systems already have it on PATH. If not, the user adds `export PATH="$HOME/.local/bin:$PATH"` to their shell profile.

### 5. Build & Publish Steps

```bash
# Install build tools
pipx install hatch   # or: pip install --user build twine

# Build
hatch build          # or: python3 -m build
# Creates dist/agent_track-0.1.0.tar.gz and dist/agent_track-0.1.0-py3-none-any.whl

# Test on TestPyPI first
hatch publish -r test
# or: twine upload --repository testpypi dist/*

# Install from TestPyPI to verify
pipx install --index-url https://test.pypi.org/simple/ agent-track

# Publish to real PyPI
hatch publish
# or: twine upload dist/*
```

### 6. PyPI Account Setup

1. Create account at https://pypi.org/account/register/
2. Enable 2FA
3. Create API token at https://pypi.org/manage/account/token/
4. Store token: `~/.pypirc` or use `HATCH_INDEX_USER=__token__` + `HATCH_INDEX_AUTH=pypi-...`

---

## TODO Before Publishing

### Must-have
- [ ] Copy `track.py` into `src/agent_track/cli.py` structure
- [ ] Add `__init__.py` with version
- [ ] Create `pyproject.toml` (above)
- [ ] Add `LICENSE` (MIT)
- [ ] Write `README.md` with usage examples, screenshots
- [ ] Remove hardcoded `.track/` path — make it configurable via `TRACK_DIR` env var or auto-discover (walk up to find `.track/` or use CWD)
- [ ] Test `pip install -e .` locally
- [ ] Test `pipx install .` locally
- [ ] Verify `track init && track create --title test && track list` works after install

### Should-have
- [ ] Add `--version` flag
- [ ] Add `track archive` command (move done tickets to archive/)
- [ ] Basic tests (at least CLI smoke tests with `subprocess.run`)
- [ ] GitHub Actions CI (test on 3.10, 3.11, 3.12, 3.13)
- [ ] GitHub Actions publish workflow (on tag push)

### Nice-to-have
- [ ] Windows support (replace `fcntl` with cross-platform lock)
- [ ] `track init --here` vs `track init --global` (per-project vs user-wide)
- [ ] Tab completion (argcomplete or custom)
- [ ] Color output for terminal (using ANSI codes, stdlib only)
- [ ] `track import` / `track export` for backup/migration
- [ ] `track gc` to clean up stale locks
- [ ] Configurable dashboard port via `.track/config.json`
