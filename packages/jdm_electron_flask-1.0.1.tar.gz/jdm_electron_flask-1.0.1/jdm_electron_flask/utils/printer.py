import os
import logging
from datetime import datetime


class Printer:
    """
    Environment-aware logger.

    - development: prints to console with icons
    - production / deployed: writes to logs/<date>.log
    """

    _logger = None
    _env: str = None

    @classmethod
    def init(cls, env: str):
        cls._env = env

        if env != "development":
            log_dir = os.path.join(os.getcwd(), "logs")
            os.makedirs(log_dir, exist_ok=True)

            log_filename = datetime.now().strftime("%Y-%m-%d") + ".log"
            log_path = os.path.join(log_dir, log_filename)

            logging.basicConfig(
                filename=log_path,
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(message)s",
                datefmt="%H:%M:%S",
            )
            cls._logger = logging.getLogger("jdm")

    @classmethod
    def log(cls, message: str):
        if cls._env == "development":
            print(message)
        else:
            cls._logger.info(message)

    @classmethod
    def success(cls, message: str):
        if cls._env == "development":
            print(f"  ✔  {message}")
        else:
            cls._logger.info(f"[SUCCESS] {message}")

    @classmethod
    def warn(cls, message: str):
        if cls._env == "development":
            print(f"  ⚠  {message}")
        else:
            cls._logger.warning(f"[WARN] {message}")

    @classmethod
    def error(cls, message: str):
        if cls._env == "development":
            print(f"  ✖  {message}")
        else:
            cls._logger.error(f"[ERROR] {message}")

    @classmethod
    def info(cls, message: str):
        if cls._env == "development":
            print(f"  ℹ  {message}")
        else:
            cls._logger.info(f"[INFO] {message}")