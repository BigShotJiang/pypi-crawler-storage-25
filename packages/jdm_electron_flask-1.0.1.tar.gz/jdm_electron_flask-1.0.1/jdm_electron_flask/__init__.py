"""
jdm-electron-flask-py
~~~~~~~~~~~~~~~~~~~~~
The Python backbone for jdm-electron-flask projects.

Provides app factory, dynamic API registration, SocketIO setup,
and environment-aware logging — so you build features, not boilerplate.
"""

__version__ = "1.0.0"
__author__ = "JDM-Github"

from jdm_electron_flask.core.app import create_app, get_socketio
from jdm_electron_flask.core.blueprint import JDMBlueprint
from jdm_electron_flask.core.event import JDMEvent
from jdm_electron_flask.utils.printer import Printer
from jdm_electron_flask.utils.responses import success, error
from jdm_electron_flask.utils.validators import require_access, validate_json
from jdm_electron_flask.core.config import JDMConfig, JDMDevelopmentConfig, JDMProductionConfig, JDMDeployedConfig

__all__ = [
    "create_app",
    "get_socketio",
    "JDMBlueprint",
    "JDMEvent",
    "Printer",
    "success",
    "error",
    "require_access",
    "validate_json",
    "JDMConfig",
    "JDMDevelopmentConfig",
    "JDMProductionConfig",
    "JDMDeployedConfig"
]