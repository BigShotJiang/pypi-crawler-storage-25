# jdm_electron_flask/event.py
from flask_socketio import emit
from jdm_electron_flask import get_socketio

class JDMEvent:
    """
    Base class for SocketIO event handlers.

    Usage:
        from jdm_electron_flask import JDMEvent

        class ConnectEvent(JDMEvent):
            def on_connect(self):
                self.emit("connected", {"message": "Socket connected"})

            def on_disconnect(self):
                pass

            def on_ping_server(self, data):
                self.emit("pong_client", {"echo": data})
    """

    def __init__(self):
        self._socketio = get_socketio()
        self._register()

    def emit(self, event: str, data=None, **kwargs):
        """Shorthand emit."""
        emit(event, data, **kwargs)

    def _register(self):
        """
        Auto-register methods named on_<event> as SocketIO event handlers.
        on_connect     → "connect"
        on_disconnect  → "disconnect"
        on_ping_server → "ping_server"
        """
        for attr in dir(self):
            if not attr.startswith("on_"):
                continue
            handler = getattr(self, attr)
            if not callable(handler):
                continue
            event_name = attr[3:]
            self._socketio.on_event(event_name, handler)
