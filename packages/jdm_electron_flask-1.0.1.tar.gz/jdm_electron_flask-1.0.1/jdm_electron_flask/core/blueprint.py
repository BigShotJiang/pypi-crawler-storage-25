import functools
import inspect
from flask import Blueprint, request
from jdm_electron_flask.utils.responses import success, error
from jdm_electron_flask.utils.validators import validate_json, require_access
from typing import Callable, List, Union


class JDMBlueprint(Blueprint):

    def __init__(self, name: str, import_name: str, **kwargs):
        super().__init__(name, import_name, **kwargs)
        self.success = success
        self.error   = error
        self.register_error_handler(404, self._handle_404)
        self.register_error_handler(500, self._handle_500)
        self._bind_all()

    def _bind_all(self):
        for _, func in inspect.getmembers(self.__class__, predicate=inspect.isfunction):
            if hasattr(func, "_jdm_route"):
                self._bind(func._jdm_route, func)

    def _bind(self, definition: dict, func: Callable):
        path     = definition["path"]
        methods  = definition["methods"]
        auth     = definition.get("auth", False)
        validate = definition.get("validate")

        wrapped = func
        if validate:
            fields  = validate if isinstance(validate, list) else [validate]
            wrapped = validate_json(*fields)(wrapped)
        if auth:
            wrapped = require_access(wrapped)

        if inspect.iscoroutinefunction(func) and not inspect.iscoroutinefunction(wrapped):
            inner = wrapped
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await inner(*args, **kwargs)
            wrapped = async_wrapper

        self.add_url_rule(path, func.__name__, wrapped, methods=methods)

    # ── Route decorators ──────────────────────────────────────

    @staticmethod
    def get(path: str, auth: bool = False):
        def decorator(func: Callable):
            func._jdm_route = {"path": path, "methods": ["GET"], "auth": auth}
            return func
        return decorator

    @staticmethod
    def post(path: str, auth: bool = True, validate: Union[str, List[str], None] = None):
        def decorator(func: Callable):
            func._jdm_route = {"path": path, "methods": ["POST"], "auth": auth, "validate": validate}
            return func
        return decorator

    @staticmethod
    def put(path: str, auth: bool = True, validate: Union[str, List[str], None] = None):
        def decorator(func: Callable):
            func._jdm_route = {"path": path, "methods": ["PUT"], "auth": auth, "validate": validate}
            return func
        return decorator

    @staticmethod
    def delete(path: str, auth: bool = True):
        def decorator(func: Callable):
            func._jdm_route = {"path": path, "methods": ["DELETE"], "auth": auth}
            return func
        return decorator

    def _handle_404(self, e):
        return error(f"Route not found: {request.path}", status=404)

    def _handle_500(self, e):
        return error("Internal server error", status=500)