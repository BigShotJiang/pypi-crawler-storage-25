import os
import sys
from dotenv import load_dotenv

def _load_env():
    """Load .env from PyInstaller bundle first, then CWD."""
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        load_dotenv(os.path.join(meipass, ".env"))
    load_dotenv(os.path.join(os.path.abspath("."), ".env"), override=False)

_load_env()

class JDMConfig:
    """Base config. Inherit this to add your own shared fields."""
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")


class JDMDevelopmentConfig(JDMConfig):
    FLASK_ENV = "development"
    DEBUG     = True


class JDMProductionConfig(JDMConfig):
    FLASK_ENV = "production"
    DEBUG     = False


class JDMDeployedConfig(JDMConfig):
    FLASK_ENV = "deployed"
    DEBUG     = False