from flask import Flask, send_from_directory
from flask_cors import CORS
from flask_socketio import SocketIO
import importlib
import json
import os
import sys
import inspect
from jdm_electron_flask.utils.printer import Printer

_socketio = SocketIO()


def get_socketio() -> SocketIO:
    """Return the shared SocketIO instance."""
    return _socketio


def _get_base_dir() -> str:
    """Get the base directory whether running as exe or normal Python."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.getcwd()


def _load_config(config_name: str, app: Flask):
    """Load Flask config based on environment name."""
    try:
        if config_name == "production":
            from app.config import ProductionConfig  # type: ignore
            app.config.from_object(ProductionConfig)
        elif config_name == "deployed":
            from app.config import DeployedConfig  # type: ignore
            app.config.from_object(DeployedConfig)
        else:
            from app.config import DevelopmentConfig  # type: ignore
            app.config.from_object(DevelopmentConfig)
    except ImportError:
        Printer.warn(f"Config class for '{config_name}' not found — using Flask defaults")


def _load_blueprints(app: Flask, env: str):
    from jdm_electron_flask import JDMBlueprint

    base = _get_base_dir()
    api_config_path = os.path.join(base, "config", "api.json")
    if not os.path.exists(api_config_path):
        Printer.warn("config/api.json not found — no blueprints registered")
        return

    with open(api_config_path, "r") as f:
        api_config = json.load(f)

    for name, config in api_config.items():
        if not config.get("masterEnabled", True):
            Printer.warn(f"[{name}] skipped (masterEnabled: false)")
            continue
        if env == "production" and config.get("disabledOnProduction", False):
            Printer.warn(f"[{name}] skipped (disabledOnProduction: true)")
            continue
        if env == "deployed" and config.get("disabledOnDeployed", False):
            Printer.warn(f"[{name}] skipped (disabledOnDeployed: true)")
            continue

        try:
            module = importlib.import_module(f"app.api.{name}")
            blueprint = None
            for _, obj in inspect.getmembers(module, inspect.isclass):
                if issubclass(obj, JDMBlueprint) and obj is not JDMBlueprint:
                    blueprint = obj()
                    break
            if blueprint is None:
                blueprint = getattr(module, f"{name}_bp", None)

            if blueprint is None:
                Printer.error(f"[{name}] no JDMBlueprint subclass or '{name}_bp' found — skipped")
                continue

            app.register_blueprint(blueprint, url_prefix=config["link"])
            Printer.success(f"[{name}] registered at {config['link']}")

        except ModuleNotFoundError as e:
            if f"app.api.{name}" in str(e):
                Printer.error(f"[{name}] module app/api/{name}.py not found — skipped")
            else:
                Printer.error(f"[{name}] failed to import — missing dependency: {e}")
        except Exception as e:
            Printer.error(f"[{name}] unexpected error — {e}")


def _load_events():
    from jdm_electron_flask import JDMEvent

    base = _get_base_dir()
    event_dir = os.path.join(base, "app", "event")
    if not os.path.exists(event_dir):
        return

    for filename in os.listdir(event_dir):
        if filename.endswith(".py") and not filename.startswith("_"):
            module_name = filename[:-3]
            try:
                module = importlib.import_module(f"app.event.{module_name}")
                for _, obj in inspect.getmembers(module, inspect.isclass):
                    if issubclass(obj, JDMEvent) and obj is not JDMEvent:
                        obj()
                Printer.success(f"[event/{module_name}] loaded")
            except Exception as e:
                Printer.error(f"[event/{module_name}] failed to load — {e}")


def create_app(config_name: str = None, static_folder: str = "static") -> Flask:
    """
    Create and configure the Flask application.

    Args:
        config_name: One of 'development', 'production', 'deployed'.
                     Defaults to FLASK_ENV env var, then 'development'.
        static_folder: Path to the static folder (React build output).

    Returns:
        Configured Flask app instance.
    """
    base = _get_base_dir()
    resolved_static = os.path.join(base, static_folder)

    app = Flask(__name__, static_folder=resolved_static, static_url_path="/static")
    CORS(app, origins="*")

    if config_name is None:
        config_name = os.getenv("FLASK_ENV", "development")

    _load_config(config_name, app)

    Printer.init(config_name)
    Printer.info(f"Environment: {config_name}")
    Printer.info(f"jdm-electron-flask-py v{_get_version()}")

    # ── SocketIO ──────────────────────────────────────────────
    _socketio.init_app(
        app,
        cors_allowed_origins="*",
        logger=config_name == "development",
        engineio_logger=config_name == "development",
    )
    # ─────────────────────────────────────────────────────────
    Printer.log("\n  Registering blueprints...")
    _load_blueprints(app, config_name)

    Printer.log("\n  Loading socket events...")
    _load_events()

    # ── React SPA catch-all ───────────────────────────────────
    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve_react(path):
        if path and os.path.exists(os.path.join(app.static_folder, path)):
            return send_from_directory(app.static_folder, path)
        return send_from_directory(app.static_folder, "index.html")
    # ─────────────────────────────────────────────────────────

    return app


def _get_version() -> str:
    try:
        from jdm_electron_flask import __version__
        return __version__
    except Exception:
        return "unknown"