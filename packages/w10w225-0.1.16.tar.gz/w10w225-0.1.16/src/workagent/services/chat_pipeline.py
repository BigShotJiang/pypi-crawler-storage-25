from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workagent.sync.models import AgentPendingItemRecord

if TYPE_CHECKING:
    from workagent.services.file_memory import FileMemoryStore
    from workagent.services.local_agent_store import LocalAgentStore


class ChatPipeline:
    def __init__(self, *, executor, transport, action_parser, action_executor, agent_store: LocalAgentStore | None = None, memory_store: FileMemoryStore | None = None) -> None:  # noqa: ANN001
        self.executor = executor
        self.transport = transport
        self.action_parser = action_parser
        self.action_executor = action_executor
        self.agent_store = agent_store
        self.memory_store = memory_store

    async def handle_new_request(self, pending_item: AgentPendingItemRecord) -> None:
        request_text = str(pending_item.payload.get("requestText") or "").strip()
        await self._run_and_publish(pending_item, request_text=request_text)

    async def handle_reply(self, pending_item: AgentPendingItemRecord) -> None:
        reply_text = str(pending_item.payload.get("replyText") or "").strip()
        await self._run_and_publish(pending_item, request_text=reply_text)

    async def handle_decision(self, pending_item: AgentPendingItemRecord) -> None:
        payload = pending_item.payload
        draft_id = str(payload.get("writeDraftId") or "").strip()
        decision_type = str(payload.get("decisionType") or "").strip().lower()

        if decision_type == "reject":
            if draft_id:
                await self.transport.update_write_draft_status(draft_id=draft_id, status="rejected")
            return
        if decision_type == "request_followup":
            return

        action_payload = self._resolve_action_payload_safe(payload, draft_id=draft_id)
        if action_payload is None:
            if draft_id:
                await self.transport.update_write_draft_status(draft_id=draft_id, status="failed")
            return
        execution_result = await self.action_executor.execute(action_payload)
        if draft_id:
            await self.transport.update_write_draft_status(
                draft_id=draft_id,
                status="executed" if execution_result.success else "failed",
                execution_result=execution_result.to_dict(),
            )

    async def _run_and_publish(self, pending_item: AgentPendingItemRecord, *, request_text: str) -> None:
        payload = pending_item.payload
        agent_id = payload.get("agent_id") or payload.get("agentId")
        agent_prompt = None
        skill_contents: list[str] = []
        if agent_id and self.agent_store:
            agent_prompt = self.agent_store.load_agent_prompt(str(agent_id))
            skill_contents = self.agent_store.load_skills(str(agent_id))

        # Read long-term memory for context
        memory_context = ""
        if self.memory_store:
            memory_context = self.memory_store.read_recent(max_chars=20_000)

        prompt = self.build_chat_prompt(
            conversation_turns=list(payload.get("conversationTurns") or []),
            request_text=request_text,
            agent_prompt=agent_prompt,
            skill_contents=skill_contents,
            memory_context=memory_context,
        )
        result = await self.executor.run(prompt)
        action, clean_text = self.action_parser.parse(result.text)
        session_id = pending_item.session_id or pending_item.id

        # Write to long-term memory
        if self.memory_store and request_text and result.text:
            self.memory_store.append(
                summary=f"Q: {request_text[:200]}\nA: {result.text[:500]}",
                source="chat",
                session_id=str(session_id),
                agent_id=str(agent_id) if agent_id else None,
            )

        if action is None:
            await self.transport.post_session_message(
                session_id=session_id,
                message_type="result",
                text=result.text,
                metadata={},
            )
            return

        draft_id = await self.transport.create_write_draft(
            session_id=session_id,
            draft_kind=action.kind,
            target_ref=action.target_ref,
            draft_text=action.content,
            draft_payload=action.payload,
        )
        await self.transport.post_session_message(
            session_id=session_id,
            message_type="draft_proposal",
            text=clean_text,
            metadata={"writeDraftId": draft_id},
        )

    @staticmethod
    def build_chat_prompt(
        *,
        conversation_turns: list[dict[str, Any]],
        request_text: str,
        agent_prompt: str | None = None,
        skill_contents: list[str] | None = None,
        memory_context: str | None = None,
    ) -> str:
        from pathlib import Path

        preamble: list[str] = []

        # System instruction: home directory structure and available resources
        pwa_home = Path.home() / ".personal-work-agent"
        skills_dir = pwa_home / "skills" / "external"
        agents_dir = pwa_home / "agents"

        # Discover available external skills
        available_skills: list[str] = []
        if skills_dir.exists():
            available_skills = sorted(
                d.name for d in skills_dir.iterdir()
                if d.is_dir() and (d / "SKILL.md").exists()
            )

        # Discover available project agents
        available_agents: list[str] = []
        if agents_dir.exists():
            available_agents = sorted(
                d.name for d in agents_dir.iterdir()
                if d.is_dir() and (d / "agent.md").exists()
            )

        system_instructions = [
            "You are a personal work agent running locally via the w10w225 CLI tool.",
            "",
            f"Home directory: {pwa_home}",
            "Directory structure:",
            f"  {pwa_home}/skills/external/{{platform}}/SKILL.md  — External system integration skills",
            f"  {pwa_home}/agents/{{agent_id}}/agent.md            — Project sub-agent definitions",
            f"  {pwa_home}/agents/{{agent_id}}/skills/{{skill}}.md — Project agent skills",
            f"  {pwa_home}/memory/MEMORY.md                        — Long-term conversation memory",
            f"  {pwa_home}/data/app.db                             — Local database (credentials, queue)",
        ]

        if available_skills:
            system_instructions.append(f"\nConnected external systems: {', '.join(available_skills)}")
            system_instructions.append(
                "Before using an external system, read the SKILL.md at "
                f"{skills_dir}/{{platform}}/SKILL.md to learn available w10w225 CLI commands."
            )

        if available_agents:
            system_instructions.append(f"\nAvailable project agents: {', '.join(available_agents)}")
            system_instructions.append(
                "Each agent has agent.md (role/prompt) and skills/ directory. "
                f"Read {agents_dir}/{{agent_id}}/agent.md for the agent's instructions."
            )

        system_instructions.append(
            "\nYou can execute w10w225 CLI commands via bash to interact with external systems. "
            "Always read the relevant SKILL.md first to understand available commands and parameters."
        )

        # Action proposal rules for external write operations
        system_instructions.append(
            "\n## External Action Rules (CRITICAL)"
            "\nWhen you need to SEND, WRITE, CREATE, UPDATE, or DELETE anything on an external system "
            "(e.g. send a Slack message, create a Jira issue, post a comment), you MUST NOT execute it directly."
            "\nInstead, output your proposal in the following format so the user can approve or reject it:"
            "\n"
            "\n---ACTION_PROPOSAL---"
            "\nkind: slack_send_message"
            "\ntarget: {\"channelId\": \"C123\", \"channelName\": \"#general\"}"
            "\ncontent: |"
            "\n  The actual message text to send"
            "\nreason: Why this action is needed"
            "\n---END_ACTION_PROPOSAL---"
            "\n"
            "\nSupported action kinds: slack_send_message, slack_thread_reply, "
            "jira_comment_create, gitlab_note_create, confluence_comment_create, generic_external_action"
            "\n"
            "\nIMPORTANT:"
            "\n- READ operations (list, get, search, read) can be executed directly without proposal."
            "\n- WRITE operations (send, create, update, delete, reply, comment) MUST use ACTION_PROPOSAL."
            "\n- Never ask the user 'should I send this?' in text. Always use the ACTION_PROPOSAL format."
            "\n- The user will see an approve/reject button in their chat interface."
        )
        preamble.append("System:\n" + "\n".join(system_instructions))

        if agent_prompt:
            preamble.append(f"Agent Prompt:\n{agent_prompt.strip()}")
        if skill_contents:
            for i, skill in enumerate(skill_contents, 1):
                preamble.append(f"Skill {i}:\n{skill.strip()}")
        if memory_context and memory_context.strip():
            preamble.append(f"Previous Interactions (Long-term Memory):\n{memory_context.strip()}")

        turn_lines = [
            f"{str(turn.get('role') or '').strip()}: {str(turn.get('text') or '').strip()}"
            for turn in conversation_turns
            if isinstance(turn, dict) and str(turn.get("role") or "").strip() and str(turn.get("text") or "").strip()
        ]
        sections = [*preamble, "Conversation:", *turn_lines, "", "Latest request:", request_text.strip()]
        return "\n".join(section for section in sections if section is not None).strip()

    def _resolve_action_payload_safe(self, payload: dict[str, object], *, draft_id: str) -> dict[str, object] | None:
        """Resolve action payload from decision payload, falling back to local DB draft."""
        # Try from decision payload first
        for key in ("originalPayload", "originalPayloadJson", "editedPayload", "editedPayloadJson"):
            value = payload.get(key)
            if isinstance(value, dict):
                return dict(value)

        # Fall back: load draft_payload from local DB
        if draft_id and self.agent_store:
            try:
                from pathlib import Path

                from sqlalchemy import create_engine, text

                db_path = Path.home() / ".personal-work-agent" / "data" / "app.db"
                if db_path.exists():
                    engine = create_engine(f"sqlite:///{db_path}")
                    with engine.connect() as conn:
                        row = conn.execute(
                            text("SELECT draft_payload_json, draft_kind, target_ref_json, draft_text FROM agent_write_drafts WHERE id = :id"),
                            {"id": draft_id},
                        ).fetchone()
                        if row:
                            draft_payload = row[0]
                            if isinstance(draft_payload, str):
                                import json
                                draft_payload = json.loads(draft_payload)
                            if isinstance(draft_payload, dict) and draft_payload:
                                return dict(draft_payload)
                            # Build from draft fields
                            import json
                            return {
                                "kind": row[1] or "",
                                "targetRef": json.loads(row[2]) if isinstance(row[2], str) else (row[2] or {}),
                                "content": row[3] or "",
                            }
                    engine.dispose()
            except Exception:
                pass

        return None
