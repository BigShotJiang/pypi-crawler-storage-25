"""
The batch module has been removed in cardiac-shared v1.0.0.

BatchProcessor and BatchConfig had no active users and were removed
during the v1.0.0 IP protection refactoring.

For batch processing, consider using:
  - cardiac_private.data.batch_manager.BatchManager (for manifest-tracked batches)
  - Standard Python concurrent.futures (for simple parallel processing)
"""


def __getattr__(name):
    raise ImportError(
        f"cardiac_shared.batch.{name} has been removed in v1.0.0.\n"
        f"  This module had no active users and was removed.\n"
        f"  For batch processing, use cardiac_private.data.batch_manager "
        f"or concurrent.futures."
    )
