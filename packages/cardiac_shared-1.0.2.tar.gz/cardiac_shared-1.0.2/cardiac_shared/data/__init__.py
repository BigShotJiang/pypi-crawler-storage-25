"""
Data module — External dataset catalog for cardiac imaging research.

Provides standardized metadata, directory structures, access URLs, and
usage notes for commonly used public cardiac CT datasets.

Quick start:
    >>> from cardiac_shared.data import list_datasets, get_dataset_info
    >>> list_datasets()
    ['COCA', 'NLST', 'TotalSegmentator']

    >>> nlst = get_dataset_info('nlst')
    >>> print(nlst.access_url)
    https://cdas.cancer.gov/nlst/
    >>> print(nlst.paired_selection_criteria)

    >>> from cardiac_shared.data import print_dataset_catalog
    >>> print_dataset_catalog()

Register your own datasets:
    >>> from cardiac_shared.data import DatasetInfo, register_dataset
    >>> register_dataset(DatasetInfo(name="My Data", short_name="MD", ...))
"""

from cardiac_shared.data.external_datasets import (
    DatasetInfo,
    get_dataset_info,
    list_datasets,
    print_dataset_catalog,
    register_dataset,
    # Pre-defined dataset constants
    NLST,
    COCA,
    TOTALSEGMENTATOR,
)

__all__ = [
    'DatasetInfo',
    'get_dataset_info',
    'list_datasets',
    'print_dataset_catalog',
    'register_dataset',
    'NLST',
    'COCA',
    'TOTALSEGMENTATOR',
]


# Migration guidance for classes that moved to cardiac-private
_MOVED = {
    'BatchManager': 'cardiac_private.data.batch_manager',
    'BatchManifest': 'cardiac_private.data.batch_manager',
    'PatientEntry': 'cardiac_private.data.batch_manager',
    'IntermediateResultsRegistry': 'cardiac_private.data.registry',
    'get_registry': 'cardiac_private.data.registry',
    'PairedSample': 'cardiac_private.data.paired_dataset',
    'PairedDatasetConfig': 'cardiac_private.data.paired_dataset',
    'PairedDatasetLoader': 'cardiac_private.data.paired_dataset',
    'DatasetRegistry': 'cardiac_private.data.datasets',
    'BatchDiscovery': 'cardiac_private.data.batch_discovery',
}


def __getattr__(name):
    if name in _MOVED:
        new_loc = _MOVED[name]
        raise ImportError(
            f"{name} has moved to {new_loc} in v1.0.0.\n"
            f"  New: from {new_loc} import {name}\n"
            f"  Install: cd ~/projects/cardiac-private && pip install -e ."
        )
    raise AttributeError(f"module 'cardiac_shared.data' has no attribute '{name}'")
