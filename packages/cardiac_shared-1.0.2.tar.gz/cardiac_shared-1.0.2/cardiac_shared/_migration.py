"""
Migration helpers for cardiac-shared v1.0.0.

Provides clear error messages when users try to import modules
that have moved to cardiac-private.
"""

# Mapping: old module path -> (new module path, list of names)
MOVED_MODULES = {
    'cardiac_shared.tissue': {
        'new_module': 'cardiac_private.tissue',
        'names': ['TissueClassifier', 'TissueMetrics', 'FilterStats',
                  'TISSUE_HU_RANGES', 'filter_tissue', 'get_tissue_hu_range'],
    },
    'cardiac_shared.vertebra': {
        'new_module': 'cardiac_private.vertebra',
        'names': ['VertebraDetector', 'VertebraInfo', 'VertebraROI',
                  'parse_vertebrae', 'sort_vertebrae', 'VERTEBRAE_ORDER'],
    },
    'cardiac_shared.parallel': {
        'new_module': 'cardiac_private.parallel',
        'names': ['ParallelProcessor', 'ProcessingResult', 'Checkpoint',
                  'parallel_map', 'parallel_map_with_checkpoint'],
    },
    'cardiac_shared.cache': {
        'new_module': 'cardiac_private.cache',
        'names': ['CacheManager'],
    },
    'cardiac_shared.batch': {
        'new_module': None,
        'names': ['BatchProcessor', 'BatchConfig'],
        'message': 'The batch module has been removed in v1.0.0 (no active users).',
    },
    'cardiac_shared.config': {
        'new_module': None,
        'names': ['ConfigManager', 'load_config'],
        'message': 'The config module has been removed in v1.0.0 (no active users).',
    },
}


def make_migration_init(old_module: str) -> str:
    """Generate __init__.py content for a migration stub module."""
    info = MOVED_MODULES.get(old_module, {})
    new_mod = info.get('new_module')
    names = info.get('names', [])
    custom_msg = info.get('message')

    if custom_msg:
        return f'"""\n{custom_msg}\n"""\n\nraise ImportError("{custom_msg}")\n'

    lines = [
        f'"""',
        f'This module has moved to cardiac-private in v1.0.0.',
        f'',
        f'Migration guide:',
        f'  Old: from {old_module} import ...',
        f'  New: from {new_mod} import ...',
        f'',
        f'Install cardiac-private:',
        f'  cd ~/projects/cardiac-private && pip install -e .',
        f'"""',
        f'',
        f'',
        f'def __getattr__(name):',
        f'    raise ImportError(',
        f'        f"{{name}} has moved to {new_mod} in cardiac-shared v1.0.0.\\n"',
        f'        f"  Old: from {old_module} import {{name}}\\n"',
        f'        f"  New: from {new_mod} import {{name}}\\n"',
        f'        f"  Install: cd ~/projects/cardiac-private && pip install -e ."',
        f'    )',
    ]
    return '\n'.join(lines) + '\n'
