"""
This module has moved to cardiac-private in v1.0.0.

Migration guide:
  Old: from cardiac_shared.cache import CacheManager
  New: from cardiac_private.cache import CacheManager

Install cardiac-private:
  cd ~/projects/cardiac-private && pip install -e .
"""


def __getattr__(name):
    raise ImportError(
        f"{name} has moved to cardiac_private.cache in cardiac-shared v1.0.0.\n"
        f"  Old: from cardiac_shared.cache import {name}\n"
        f"  New: from cardiac_private.cache import {name}\n"
        f"  Install: cd ~/projects/cardiac-private && pip install -e ."
    )
