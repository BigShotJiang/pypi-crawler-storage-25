"""
The config module has been removed in cardiac-shared v1.0.0.

ConfigManager and load_config had no active users and were removed
during the v1.0.0 IP protection refactoring.

For configuration management, use:
  - PyYAML directly: yaml.safe_load() / yaml.safe_dump()
  - Standard library: json, configparser
"""


def __getattr__(name):
    raise ImportError(
        f"cardiac_shared.config.{name} has been removed in v1.0.0.\n"
        f"  This module had no active users and was removed.\n"
        f"  For config management, use PyYAML or standard library directly."
    )
