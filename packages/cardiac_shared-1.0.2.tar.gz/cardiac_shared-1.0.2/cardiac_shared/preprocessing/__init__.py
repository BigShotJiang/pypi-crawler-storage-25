"""
Preprocessing utilities for cardiac imaging pipelines

Provides:
- DicomConverter: Unified DICOM to NIfTI conversion
- ThicknessDetector: Automatic CT slice thickness detection

For SharedPreprocessingPipeline, see cardiac-private.
"""

from .dicom_converter import (
    DicomConverter,
    ConversionResult,
    convert_dicom_to_nifti,
)

from .thickness import (
    ThicknessSource,
    ThicknessCategory,
    ThicknessInfo,
    ThicknessDetector,
    detect_thickness,
)

__all__ = [
    'DicomConverter',
    'ConversionResult',
    'convert_dicom_to_nifti',
    'ThicknessSource',
    'ThicknessCategory',
    'ThicknessInfo',
    'ThicknessDetector',
    'detect_thickness',
]
