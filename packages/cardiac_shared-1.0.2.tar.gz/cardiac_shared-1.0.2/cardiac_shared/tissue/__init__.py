"""
This module has moved to cardiac-private in v1.0.0.

Migration guide:
  Old: from cardiac_shared.tissue import TissueClassifier, ...
  New: from cardiac_private.tissue import TissueClassifier, ...

Install cardiac-private:
  cd ~/projects/cardiac-private && pip install -e .
"""


def __getattr__(name):
    raise ImportError(
        f"{name} has moved to cardiac_private.tissue in cardiac-shared v1.0.0.\n"
        f"  Old: from cardiac_shared.tissue import {name}\n"
        f"  New: from cardiac_private.tissue import {name}\n"
        f"  Install: cd ~/projects/cardiac-private && pip install -e ."
    )
