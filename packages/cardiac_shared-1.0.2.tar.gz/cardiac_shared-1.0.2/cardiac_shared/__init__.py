"""
Cardiac Shared - Common utilities for cardiac imaging projects

Public foundational package providing shared IO, hardware detection,
environment detection, progress tracking, data source management,
and basic preprocessing for cardiac imaging analysis.

Modules:
- io: DICOM, NIfTI, and ZIP file handling
- hardware: Hardware detection, GPU/CPU optimization
- environment: Runtime environment detection (WSL, Colab, etc.)
- progress: Multi-level progress tracking
- data_sources: Multi-source data management
- preprocessing: DICOM conversion, thickness detection

For proprietary extensions (tissue classification, vertebra detection,
paired datasets, batch management), see cardiac-private (internal only).
"""

__version__ = "1.0.2"

# IO modules
from cardiac_shared.io.dicom import read_dicom_series, get_dicom_metadata
from cardiac_shared.io.nifti import load_nifti, save_nifti
from cardiac_shared.io.zip_handler import extract_zip, find_dicom_root
from cardiac_shared.io.preloader import AsyncNiftiPreloader, preload_nifti_batch

# Hardware detection
from cardiac_shared.hardware import (
    detect_hardware,
    HardwareInfo,
    GPUInfo,
    CPUInfo,
    RAMInfo,
    print_hardware_summary,
    get_optimal_config,
    CPUOptimizer,
    get_cpu_optimizer,
    apply_cpu_optimizations,
    get_recommended_gpu_stabilization_time,
    get_gpu_performance_tier,
)

# Environment detection
from cardiac_shared.environment import (
    detect_runtime,
    RuntimeEnvironment,
    detect_colab,
    detect_wsl,
    print_environment_summary,
)

# Progress tracking
from cardiac_shared.progress import (
    ProgressTracker,
    ProgressLevel,
    create_tracker,
)

# Data sources management
from cardiac_shared.data_sources import (
    DataSourceManager,
    DataSource,
    DataSourceStatus,
    get_source,
    list_sources,
)

# Data — external dataset catalog
from cardiac_shared.data import (
    DatasetInfo,
    get_dataset_info,
    list_datasets,
    print_dataset_catalog,
    register_dataset,
    NLST,
    COCA,
    TOTALSEGMENTATOR,
)

# Preprocessing (DICOM conversion + thickness detection)
from cardiac_shared.preprocessing import (
    DicomConverter,
    ConversionResult,
    convert_dicom_to_nifti,
    ThicknessSource,
    ThicknessCategory,
    ThicknessInfo,
    ThicknessDetector,
    detect_thickness,
)

__all__ = [
    '__version__',
    # IO
    'read_dicom_series', 'get_dicom_metadata',
    'load_nifti', 'save_nifti',
    'extract_zip', 'find_dicom_root',
    'AsyncNiftiPreloader', 'preload_nifti_batch',
    # Hardware
    'detect_hardware', 'HardwareInfo', 'GPUInfo', 'CPUInfo', 'RAMInfo',
    'print_hardware_summary', 'get_optimal_config',
    'CPUOptimizer', 'get_cpu_optimizer', 'apply_cpu_optimizations',
    'get_recommended_gpu_stabilization_time', 'get_gpu_performance_tier',
    # Environment
    'detect_runtime', 'RuntimeEnvironment', 'detect_colab', 'detect_wsl',
    'print_environment_summary',
    # Progress
    'ProgressTracker', 'ProgressLevel', 'create_tracker',
    # Data — external dataset catalog
    'DatasetInfo', 'get_dataset_info', 'list_datasets',
    'print_dataset_catalog', 'register_dataset',
    'NLST', 'COCA', 'TOTALSEGMENTATOR',
    # Data sources
    'DataSourceManager', 'DataSource', 'DataSourceStatus',
    'get_source', 'list_sources',
    # Preprocessing
    'DicomConverter', 'ConversionResult', 'convert_dicom_to_nifti',
    'ThicknessSource', 'ThicknessCategory', 'ThicknessInfo',
    'ThicknessDetector', 'detect_thickness',
]


# Migration guidance for top-level imports of moved classes
_MOVED_TO_PRIVATE = {
    # tissue
    'TissueClassifier': 'cardiac_private.tissue',
    'TissueMetrics': 'cardiac_private.tissue',
    'TISSUE_HU_RANGES': 'cardiac_private.tissue',
    'filter_tissue': 'cardiac_private.tissue',
    'get_tissue_hu_range': 'cardiac_private.tissue',
    # vertebra
    'VertebraDetector': 'cardiac_private.vertebra',
    'VertebraInfo': 'cardiac_private.vertebra',
    'VertebraROI': 'cardiac_private.vertebra',
    'parse_vertebrae': 'cardiac_private.vertebra',
    'sort_vertebrae': 'cardiac_private.vertebra',
    'VERTEBRAE_ORDER': 'cardiac_private.vertebra',
    # parallel
    'ParallelProcessor': 'cardiac_private.parallel',
    'Checkpoint': 'cardiac_private.parallel',
    'parallel_map': 'cardiac_private.parallel',
    'parallel_map_with_checkpoint': 'cardiac_private.parallel',
    # cache
    'CacheManager': 'cardiac_private.cache',
    # data
    'BatchManager': 'cardiac_private.data',
    'BatchManifest': 'cardiac_private.data',
    'IntermediateResultsRegistry': 'cardiac_private.data',
    'get_registry': 'cardiac_private.data',
    'PairedSample': 'cardiac_private.data',
    'PairedDatasetLoader': 'cardiac_private.data',
    # preprocessing
    'SharedPreprocessingPipeline': 'cardiac_private.preprocessing',
    'PreprocessingConfig': 'cardiac_private.preprocessing',
    'create_pipeline': 'cardiac_private.preprocessing',
}


def __getattr__(name):
    if name in _MOVED_TO_PRIVATE:
        new_loc = _MOVED_TO_PRIVATE[name]
        raise ImportError(
            f"{name} has moved to {new_loc} in cardiac-shared v1.0.0.\n"
            f"  Old: from cardiac_shared import {name}\n"
            f"  New: from {new_loc} import {name}\n"
            f"  Install: cd ~/projects/cardiac-private && pip install -e ."
        )
    raise AttributeError(f"module 'cardiac_shared' has no attribute '{name}'")
