"""
This module has moved to cardiac-private in v1.0.0.

Migration guide:
  Old: from cardiac_shared.parallel import ParallelProcessor, ...
  New: from cardiac_private.parallel import ParallelProcessor, ...

Install cardiac-private:
  cd ~/projects/cardiac-private && pip install -e .
"""


def __getattr__(name):
    raise ImportError(
        f"{name} has moved to cardiac_private.parallel in cardiac-shared v1.0.0.\n"
        f"  Old: from cardiac_shared.parallel import {name}\n"
        f"  New: from cardiac_private.parallel import {name}\n"
        f"  Install: cd ~/projects/cardiac-private && pip install -e ."
    )
