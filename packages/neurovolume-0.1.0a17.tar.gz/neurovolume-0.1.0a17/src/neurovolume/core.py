from neurovolume._internal import (
    _hello,
    _init_three_dim,
    _save_three_dim,
    _deinit_three_dim,
    _init_four_dim,
    _save_four_dim,
    _deinit_four_dim,
)
import os
import sys
import numpy as np  # DEPENDENCY: really the only one we should have!
from pathlib import Path


def hello():
    """Prints 'hello neurovolume' from the c_root.zig"""
    _hello()


def prep_ndarray(
    arr: np.ndarray,
    transpose: tuple,
) -> np.ndarray:
    """
    Returns an ndarray that is useable by neurovolume
    """
    # order matters here:
    arr = np.transpose(arr, transpose)
    arr = np.array(arr, order="C", dtype=np.float32)

    max_val = arr.max()

    # LLM: had this in the test suite
    # completes 0-1 f32 normalization
    if max_val > 0:
        arr = arr / max_val
    return arr


def _verify_and_copy_affine(affine: np.ndarray) -> np.ndarray:
    if len(affine) != 4:
        sys.exit(
            f"Invalid affine len, must be 4 (3D plus homogonized coordinate): {len(affine)}"
        )
    return affine.copy()


def scale(affine: np.ndarray, scale: float) -> np.ndarray:
    """
    modifies the affine matrix's scale
    usage: scale is the percentage to scale by
            0.5 is 50% etc
    """
    o = _verify_and_copy_affine(affine)
    # LLM: scale full 3x3 submatrix (not just diagonal) to preserve oblique orientation
    o[:3, :3] *= scale  # scale+rotation columns
    o[:3, 3] *= scale  # translation
    return o


def translate(affine: np.ndarray, x: float, y: float, z: float) -> np.ndarray:
    """
    modifies the affine matrix's translation
    usage: x y and z inputs are added to the translation column
    """
    # o for output
    o = _verify_and_copy_affine(affine)
    o[0][3] += x
    o[1][3] += y
    o[2][3] += z
    return o


def rotate(affine: np.ndarray, x: float, y: float, z: float) -> np.ndarray:
    """
    modifies the affine matrix's rotation
    usage: x y and z are respective theta in the 3D rotation
    (i think its radians...)
    """
    o = _verify_and_copy_affine(affine)
    # LLM: all below (I am way too lazy)
    Rx = np.array(
        [
            [1, 0, 0],
            [0, np.cos(x), -np.sin(x)],
            [0, np.sin(x), np.cos(x)],
        ]
    )

    Ry = np.array(
        [
            [np.cos(y), 0, np.sin(y)],
            [0, 1, 0],
            [-np.sin(y), 0, np.cos(y)],
        ]
    )

    Rz = np.array(
        [
            [np.cos(z), -np.sin(z), 0],
            [np.sin(z), np.cos(z), 0],
            [0, 0, 1],
        ]
    )

    # Combined rotation: R = Rz @ Ry @ Rx (applied right-to-left)
    R = Rz @ Ry @ Rx

    o[:3, :3] = R @ o[:3, :3]

    return o


def ndarray_to_vdb(
    arr: np.ndarray,  # dont for get to prep this!
    basename: str,
    source_fps=1,  # static default
    output_dir:Path=Path("../../output/"),
    overwrite=True,  # presently the only option
    transform=np.eye(4),
    playback_fps=24.0,
    speed=1.0,
    interpolation_flag=0,  # default to direct, chose 1 for cross
    # Robbie's reccomended default prune amount
    # very specfici but it works quite well
    # translated from zig to Python with Claude
    prune: np.float32 | None = 4 * np.finfo(np.float32).eps,
) -> Path:
    """
    returns path to VDB
    if VDB sequence, returns path to folder
    """
    dims = arr.shape
    if arr.ndim == 3:
        vol = _init_three_dim(
            basename=basename,
            save_folder=output_dir,
            overwrite=True,
            data=arr,
            transform=transform,  # 4x4 affine float64
            dims=dims,  # (x, y, z)
            prune = prune,
        )
        _save_three_dim(vol)
        _deinit_three_dim(vol)
        # kinda hacky tbh
        # this happens way down on the zig level and it would be
        # cooler to have the path percolate back up
        return output_dir / f"{basename}.vdb"

    elif arr.ndim == 4:
        seq_out = output_dir / basename 
        os.makedirs(seq_out, exist_ok=True)
        vol = _init_four_dim(
            basename=basename,
            save_folder=seq_out,
            overwrite=True,
            data=arr,
            transform=transform,
            source_fps=source_fps,
            playback_fps=playback_fps,
            speed=speed,
            dims=dims,
            prune=prune,
            
        )
        _save_four_dim(vol, interpolation_flag)
        _deinit_four_dim(vol)
        # should return the folder containing the seq
        # see above comment at end of .ndim == 3
        return Path(f"{output_dir}/{basename}")
    else:
        raise ValueError(f"{arr.ndim}D not supported")
