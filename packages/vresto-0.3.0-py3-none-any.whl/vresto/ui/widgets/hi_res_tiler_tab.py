"""Hi-Res Tiler tab widget for high-resolution product inspection."""

import asyncio
import os
from pathlib import Path
from typing import Dict, List, Optional, Set

from nicegui import ui

from vresto.services.lcm import lcm_service
from vresto.services.tiles import TileManager
from vresto.services.worldcover import worldcover_service
from vresto.ui.widgets.map_widget import MapWidget
from vresto.ui.widgets.resource_monitor import ResourceMonitor


class HiResTilerTab:
    """Encapsulates the Hi-Res Tiler tab for high-resolution visualization."""

    def __init__(self):
        self.map_widget_obj = None
        self.map_container = None
        self.products_column = None
        self.product_search_input = None
        self.selected_product_name: Optional[str] = None
        self.resolution_selector = None
        self.bands_container = None
        self.scanned_products: Dict[str, str] = {}
        self.current_img_root: Optional[str] = None
        self.available_bands: Dict[str, Set[int]] = {}
        self.selected_bands: List[str] = []
        self.worldcover_enabled = False
        self.worldcover_opacity = 0.65
        self.worldcover_year = "2021"
        self.lcm_enabled = False
        self.lcm_opacity = 0.65
        self.lcm_year = "2020"
        self.worldcover_tile_manager = TileManager()
        self.lcm_tile_manager = TileManager()
        self._worldcover_layer_signature: Optional[tuple] = None
        self._worldcover_layer_url: Optional[str] = None
        self._lcm_layer_signature: Optional[tuple] = None
        self._lcm_layer_url: Optional[str] = None
        self.base_tile_port = int(os.getenv("VRESTO_BASE_TILE_PORT", "8611"))
        self.worldcover_tile_port = int(os.getenv("VRESTO_WORLDCOVER_TILE_PORT", "8612"))
        self.lcm_tile_port = int(os.getenv("VRESTO_LCM_TILE_PORT", "8613"))
        self._worldcover_refresh_in_progress = False
        self._lcm_refresh_in_progress = False
        self.worldcover_checkbox = None
        self.lcm_checkbox = None
        self.overlay_year_selector = None
        self.wc_opacity_slider = None
        self.lcm_opacity_slider = None
        self.resolution_hint_label = None
        self.resource_monitor = None
        self._cleanup_registered = False

    def create(self):
        """Create and return the Hi-Res Tiler tab UI."""
        with ui.column().classes("w-full h-full gap-4") as self.map_container:
            with ui.row().classes("w-full gap-4"):
                # Left side: Map
                with ui.column().classes("flex-1 h-[700px]"):
                    self.map_widget_obj = MapWidget(center=(50.0, 10.0), zoom=5, title="High-Resolution Map View", draw_control=False)
                    self.map_widget_obj.create()

                # Right side: Controls
                with ui.column().classes("w-96 gap-4"):
                    self._create_controls_card()

            # Setup JavaScript event listener to receive tile URLs from ProductAnalysisTab
            ui.add_body_html(
                """
                <script>
                window.addEventListener("vresto:show_tiles", (event) => {
                    // This is a bridge between the global custom event and NiceGUI
                    const detail = event.detail;
                    console.log("vresto:show_tiles event received", detail);
                    // We call a NiceGUI function defined in the component
                    if (window.vresto_update_map) {
                        window.vresto_update_map(detail.url, detail.name, detail.bounds, detail.attribution);
                    }
                });
                </script>
            """
            )

            def update_map(url, name, bounds, attribution):
                if self.map_widget_obj:
                    self.map_widget_obj.clear_tile_layers()
                    self.map_widget_obj.add_tile_layer(url, name=name, attribution=attribution)
                    if bounds:
                        self.map_widget_obj.fit_bounds(bounds)

            # Expose the update function to JavaScript
            def _setup_js():
                ui.run_javascript(
                    f'''
                    window.vresto_update_map = (url, name, bounds, attribution) => {{
                        const container = document.getElementById("{self.map_container.id}");
                        if (container) {{
                            container.dispatchEvent(new CustomEvent("update_map", {{
                                detail: {{url, name, bounds, attribution}}
                            }}));
                        }}
                    }};
                '''
                )

            ui.context.client.on_connect(_setup_js)

            self.map_container.on(
                "update_map",
                lambda e: update_map(
                    e.args["detail"]["url"],
                    e.args["detail"]["name"],
                    e.args["detail"]["bounds"],
                    e.args["detail"]["attribution"],
                ),
            )

            # Initial scan of downloads folder
            ui.timer(1.0, self._scan_downloads, once=True)

            # Register cleanup on client disconnect to prevent stale timers
            if not self._cleanup_registered:
                self._cleanup_registered = True
                ui.context.client.on_disconnect(self._on_disconnect)

        return self.map_container

    def _on_disconnect(self):
        """Clean up tile servers and timers when the client disconnects."""
        if self.resource_monitor:
            self.resource_monitor.stop()
        self.worldcover_tile_manager.shutdown()
        self.lcm_tile_manager.shutdown()

    def _create_controls_card(self):
        """Create the control card for product, resolution and bands."""
        with ui.card().classes("w-full"):
            with ui.row().classes("w-full items-center justify-between mb-3"):
                ui.label("Tile Server Controls").classes("text-lg font-semibold")
                ui.button(icon="refresh", on_click=self._scan_downloads).props("flat dense color=deep-orange")

            self.product_search_input = ui.input(
                placeholder="Search products...",
                on_change=self._filter_products,
            ).classes("w-full mb-1")

            ui.label("Products").classes("text-sm text-gray-600 mt-2")
            with ui.scroll_area().classes("w-full h-48 border rounded p-2 mb-2"):
                self.products_column = ui.column().classes("w-full gap-2")

            ui.label("Land Cover overlay").classes("text-sm text-gray-600 mt-3")
            with ui.column().classes("w-full gap-1"):
                with ui.row().classes("w-full items-center gap-2"):
                    self.worldcover_checkbox = ui.checkbox("WorldCover", value=False, on_change=lambda e: self._on_worldcover_toggle(e.value))
                    self.wc_opacity_slider = ui.slider(min=0.0, max=1.0, step=0.05, value=0.65, on_change=lambda e: self._on_worldcover_opacity_change(e.value)).classes("flex-1").props("label")
                with ui.row().classes("w-full items-center gap-2"):
                    self.lcm_checkbox = ui.checkbox("LCM (CDSE, 2020)", value=False, on_change=lambda e: self._on_lcm_toggle(e.value))
                    self.lcm_opacity_slider = ui.slider(min=0.0, max=1.0, step=0.05, value=0.65, on_change=lambda e: self._on_lcm_opacity_change(e.value)).classes("flex-1").props("label")
            self.overlay_year_selector = ui.select(options=["2021", "2020"], value="2021", label="WorldCover year", on_change=lambda e: self._on_worldcover_year_change(e.value)).classes("w-full mb-1")

            self.resolution_selector = ui.select(
                options={"10": "10m (High)", "20": "20m (Med)", "60": "60m (Low)"},
                value="10",
                label="Preferred Resolution",
                on_change=self._on_resolution_change,
            ).classes("w-full mb-2")

            self.resolution_hint_label = ui.label("").classes("text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded px-2 py-1")
            self._update_resolution_hint("10")

            with ui.expansion("Live resource monitor", icon="monitor_heart").classes("w-full mt-1"):
                ui.label("Live CPU and memory usage for this Vresto process. Use this to compare 10m vs 20m/60m workloads.").classes("text-xs text-gray-600")
                self.resource_monitor = ResourceMonitor(sample_interval_s=2.0, history_points=30)
                self.resource_monitor.create()
                self.resource_monitor.start()

            ui.label("Bands to display").classes("text-sm text-gray-600 mt-2")
            self.bands_container = ui.column().classes("w-full gap-1")

            with ui.row().classes("w-full gap-2 mt-4"):
                ui.button("Clear Map", on_click=self._clear_map).classes("flex-1").props("outline color=warning")
                ui.button("Zoom to Product", on_click=self._zoom_to_product).classes("flex-1").props("outline color=deep-orange")

    def _zoom_to_product(self):
        """Manually zoom the map to the currently selected product."""
        bounds = getattr(self, "_product_bounds", None)
        if bounds:
            self._apply_zoom_to_bounds(bounds)
            ui.notify("Zooming to product", type="info")
        else:
            ui.notify("No product selected or bounds unknown", type="warning")

    def _get_public_tile_host(self) -> Optional[str]:
        """Resolve the host to embed in tile URLs for browser reachability."""
        configured = os.getenv("VRESTO_TILE_SERVER_HOST", "").strip()
        if configured and configured.lower() != "auto":
            return configured

        try:
            host_header = (ui.context.client.request.headers.get("host") or "").strip()
            if host_header:
                return host_header.split(":")[0]
        except Exception:
            pass

        return configured or None

    def _apply_zoom_to_bounds(self, bounds):
        """Apply zoom and center to the map based on bounds."""
        from loguru import logger

        if not self.map_widget_obj or not self.map_widget_obj._map:
            return

        try:
            min_lat, min_lon, max_lat, max_lon = bounds
            center_lat = (min_lat + max_lat) / 2
            center_lon = (min_lon + max_lon) / 2

            logger.info(f"Setting map center to: {center_lat}, {center_lon}")
            self.map_widget_obj._map.set_center((center_lat, center_lon))
            # Set a zoom level that ensures the whole Sentinel-2 tile fits (approx 100km x 100km)
            self.map_widget_obj._map.set_zoom(9)

            # Try fit_bounds as well for precision if supported
            self.map_widget_obj.fit_bounds(bounds)
        except Exception as e:
            logger.error(f"Error applying zoom to bounds: {e}")

    def _scan_downloads(self):
        """Scan the default download folder for products."""
        root = str(Path.home() / "vresto_downloads")
        if not os.path.exists(root):
            return

        found_set = set()
        for dirpath, dirnames, _ in os.walk(root):
            for d in list(dirnames):
                if d.endswith(".SAFE"):
                    found_set.add(os.path.join(dirpath, d))

        self.scanned_products = {os.path.basename(p).replace(".SAFE", ""): p for p in found_set}
        self._filter_products()

    def _filter_products(self):
        """Filter products based on search input and update the list."""
        search_text = (self.product_search_input.value or "").strip().lower()
        self.products_column.clear()

        if search_text:
            filtered_names = [name for name in self.scanned_products.keys() if search_text in name.lower()]
        else:
            filtered_names = list(self.scanned_products.keys())

        for name in sorted(filtered_names):
            is_selected = name == self.selected_product_name
            with self.products_column:
                with ui.card().classes(f"w-full p-2 {'bg-blue-50 border-blue-200' if is_selected else 'bg-gray-50'}"):
                    ui.label(name).classes("text-xs font-mono break-all")
                    with ui.row().classes("w-full justify-end mt-1"):

                        async def _on_select(n=name):
                            await self._select_product(n)

                        ui.button("Select", on_click=_on_select).classes("text-xs").props(("unelevated" if is_selected else "outline") + " size=sm")

    async def _select_product(self, product_name: str):
        """Handle product selection."""
        from vresto.ui.widgets.product_analysis_tab import ProductAnalysisTab

        self.selected_product_name = product_name
        # Note: We don't call self._filter_products() here immediately to avoid losing NiceGUI context
        # during subsequent async calls, which can cause "parent element deleted" errors.

        product_path = self.scanned_products.get(product_name)
        if not product_path:
            self._filter_products()
            return

        temp_tab = ProductAnalysisTab()
        self.current_img_root = temp_tab._find_img_data(product_path)

        # Calculate bounds explicitly to ensure map centers even if tile server is slow
        try:
            import rasterio

            if self.current_img_root:
                representative_band = "TCI"
                band_file = temp_tab._find_band_file(representative_band, self.current_img_root)
                if not band_file:
                    band_file = temp_tab._find_band_file("B04", self.current_img_root)

                if band_file:
                    with rasterio.open(band_file) as src:
                        from rasterio.warp import transform_bounds

                        left, bottom, right, top = transform_bounds(src.crs, "EPSG:4326", *src.bounds)
                        # Store bounds to be used when updating map
                        self._product_bounds = (bottom, left, top, right)
                else:
                    self._product_bounds = None
        except Exception as e:
            from loguru import logger

            logger.error(f"Failed to calculate product bounds: {e}")
            self._product_bounds = None

        if self.current_img_root:
            self.available_bands = temp_tab._list_available_bands(self.current_img_root)

            # Auto-load TCI or first available band
            if self.available_bands:
                target_band = "TCI" if "TCI" in self.available_bands else sorted(self.available_bands.keys())[0]
                self.selected_bands = [target_band]

                # If TCI is not available at the current preferred resolution, switch resolution if possible
                target_res = int(self.resolution_selector.value)
                if target_res not in self.available_bands[target_band]:
                    # Find first resolution that supports the target band
                    new_res = sorted(list(self.available_bands[target_band]))[0]
                    self.resolution_selector.value = str(new_res)

            self._update_bands_ui()

            if self.selected_bands:
                # Sequential execution ensured by await
                await self._refresh_tile_layer()
        else:
            ui.notify("No bands found for this product", type="warning")
            self.bands_container.clear()

        # Refresh UI to show selection at the end
        self._filter_products()

    async def _on_resolution_change(self):
        """Handle resolution selection change."""
        self._update_resolution_hint(self.resolution_selector.value)
        self._update_bands_ui()
        if self.selected_bands:
            await self._refresh_tile_layer()
        if self.worldcover_enabled:
            await self._refresh_worldcover_overlay()
        if self.lcm_enabled:
            await self._refresh_lcm_overlay()

    def _update_resolution_hint(self, resolution: str):
        """Show an estimate of relative computational load by selected resolution."""
        if not self.resolution_hint_label:
            return

        pixel_counts = {
            "10": 10980 * 10980,
            "20": 5490 * 5490,
            "60": 1830 * 1830,
        }
        selected_pixels = pixel_counts.get(str(resolution), pixel_counts["10"])
        relative_to_60 = selected_pixels / pixel_counts["60"]
        relative_to_20 = selected_pixels / pixel_counts["20"]

        if str(resolution) == "10":
            message = f"10m can be compute-heavy: ~{relative_to_20:.1f}x the pixels of 20m and ~{relative_to_60:.1f}x of 60m per tile."
        elif str(resolution) == "20":
            message = f"20m is a balanced mode: ~{(selected_pixels / pixel_counts['10']):.2f}x of 10m load and ~{relative_to_60:.1f}x of 60m."
        else:
            message = f"60m is the lightest mode: ~{(selected_pixels / pixel_counts['10']):.2f}x of 10m pixel load (faster rendering, less memory)."

        self.resolution_hint_label.text = message

    def _on_worldcover_toggle(self, enabled: bool):
        """Toggle WorldCover overlay layer."""
        self.worldcover_enabled = bool(enabled)

        if not self.map_widget_obj:
            return
        if not self.worldcover_enabled:
            self.map_widget_obj.remove_tile_layer("WorldCover")
            self._worldcover_layer_signature = None
            self._worldcover_layer_url = None
            return

        # Capture client for use in detached async task
        client = ui.context.client

        async def _do_refresh():
            # Re-acquire slot context using the container element
            with client:
                await self._refresh_worldcover_overlay()

        asyncio.ensure_future(_do_refresh())

    def _on_lcm_toggle(self, enabled: bool):
        """Toggle LCM overlay layer."""
        self.lcm_enabled = bool(enabled)

        if not self.map_widget_obj:
            return
        if not self.lcm_enabled:
            self.map_widget_obj.remove_tile_layer("LCM")
            self._lcm_layer_signature = None
            self._lcm_layer_url = None
            return

        # Capture client for use in detached async task
        client = ui.context.client

        async def _do_refresh():
            # Re-acquire slot context using the container element
            with client:
                await self._refresh_lcm_overlay()

        asyncio.ensure_future(_do_refresh())

    def _on_worldcover_opacity_change(self, value: float):
        """Update WorldCover overlay opacity."""
        self.worldcover_opacity = float(value or 0.0)
        if self.worldcover_enabled and self._worldcover_layer_url and self.map_widget_obj:
            self.map_widget_obj.remove_tile_layer("WorldCover")
            self.map_widget_obj.add_tile_layer(self._worldcover_layer_url, name="WorldCover", opacity=self.worldcover_opacity)

    def _on_lcm_opacity_change(self, value: float):
        """Update LCM overlay opacity."""
        self.lcm_opacity = float(value or 0.0)
        if self.lcm_enabled and self._lcm_layer_url and self.map_widget_obj:
            self.map_widget_obj.remove_tile_layer("LCM")
            self.map_widget_obj.add_tile_layer(self._lcm_layer_url, name="LCM", opacity=self.lcm_opacity)

    def _on_worldcover_year_change(self, value: str):
        """Update WorldCover overlay year and refresh if enabled."""
        self.worldcover_year = str(value or "2021")
        self._worldcover_layer_signature = None
        self._worldcover_layer_url = None
        if self.worldcover_enabled:
            # Capture client for use in detached async task
            client = ui.context.client

            async def _do_refresh():
                # Re-acquire slot context using the container element
                with client:
                    await self._refresh_worldcover_overlay()

            asyncio.ensure_future(_do_refresh())

    def _set_overlay_year_options(self, mode: str):
        """Adjust year selector based on selected overlay source."""
        if not self.overlay_year_selector:
            return
        self.overlay_year_selector.options = ["2021", "2020"]
        if str(self.overlay_year_selector.value) not in {"2021", "2020"}:
            self.overlay_year_selector.value = "2021"
        self.overlay_year_selector.enable()

    def _update_bands_ui(self):
        """Update the bands list UI based on available bands and selected resolution."""
        if not self.current_img_root:
            return

        self.bands_container.clear()
        target_res = int(self.resolution_selector.value)

        with self.bands_container:
            for band, res_set in sorted(self.available_bands.items()):
                # Only show bands that support the selected resolution (or close to it)
                # Some products (L1C) might not have resolution folders, res_set will be {10} (defaulted)
                # or empty if not found.
                is_available = target_res in res_set or not res_set

                with ui.row().classes("w-full items-center justify-between"):
                    # Use a checkbox but track it manually to avoid lambda issues in loops
                    label = f"{band} ({min(res_set)}m native)" if res_set else band
                    ui.checkbox(
                        text=label,
                        value=band in self.selected_bands,
                        on_change=lambda e, b=band: self._on_band_toggle(b, e.value),
                    ).props(f"{'disabled' if not is_available else ''}")

                    if not is_available:
                        # Show all available resolutions to help the user
                        res_list = ",".join(str(r) for r in sorted(res_set))
                        ui.label(f"N/A ({res_list}m only)").classes("text-xs text-gray-400")

    async def _on_band_toggle(self, band: str, enabled: bool):
        """Handle band selection toggle (enforcing single selection)."""
        if enabled:
            self.selected_bands = [band]
            self._update_bands_ui()
            await self._refresh_tile_layer()
        else:
            if band in self.selected_bands:
                self.selected_bands.remove(band)
                await self._refresh_tile_layer()

    async def _refresh_tile_layer(self):
        """Refresh the tile layer on the map based on selected bands."""
        from loguru import logger

        if not self.selected_bands or not self.current_img_root:
            logger.info(f"Nothing to refresh: selected_bands={self.selected_bands}, current_img_root={self.current_img_root}")
            self.map_widget_obj.clear_tile_layers()
            return

        from vresto.services.tiles import tile_manager
        from vresto.ui.visualization.helpers import SCL_PALETTE
        from vresto.ui.widgets.product_analysis_tab import ProductAnalysisTab

        if not tile_manager.is_available():
            ui.notify("localtileserver is not installed", type="warning")
            return

        temp_tab = ProductAnalysisTab()
        band_files = []
        resolution = self.resolution_selector.value

        # We need to sort selected bands to ensure consistent VRT generation if needed
        for b in sorted(self.selected_bands):
            bf = temp_tab._find_band_file(b, self.current_img_root, preferred_resolution=resolution)
            if bf:
                band_files.append(bf)
            else:
                logger.warning(f"Band file not found for band {b} at resolution {resolution} in {self.current_img_root}")

        if not band_files:
            ui.notify(f"Could not find files for bands: {', '.join(self.selected_bands)}", type="warning")
            return

        ui.notify(f"🚀 Updating map with {len(band_files)} bands...", position="bottom-right", type="info")
        if resolution == "10":
            ui.notify("⏳ 10m resolution selected. Loading high-res tiles may take a few seconds...", position="bottom-right", type="warning", duration=5)

        # Handle SCL palette
        palette = None
        min_val, max_val, nodata = None, None, None
        if len(self.selected_bands) == 1 and self.selected_bands[0].upper() == "SCL":
            # Convert SCL_PALETTE to localtileserver expected format (list of colors)
            palette = [f"#{r:02x}{g:02x}{b:02x}" for i, (r, g, b) in sorted(SCL_PALETTE.items())]
            min_val, max_val, nodata = 0, 11, 0

        # Start tile server
        url = tile_manager.get_tile_url(
            band_files[0] if len(band_files) == 1 else band_files,
            port=self.base_tile_port,
            palette=palette,
            min_val=min_val,
            max_val=max_val,
            nodata=nodata,
            external_host=self._get_public_tile_host(),
        )

        if url:
            name = ", ".join(sorted(self.selected_bands))
            self.map_widget_obj.clear_tile_layers()
            self.map_widget_obj.add_tile_layer(url, name=name)
            if self.worldcover_enabled:
                await self._refresh_worldcover_overlay()
            if self.lcm_enabled:
                await self._refresh_lcm_overlay()

            # Important: Leaflet and the tile server need a moment to settle
            # especially for sequential selections.
            await asyncio.sleep(0.2)

            # Try to get bounds and zoom - prefer explicitly calculated bounds if available
            bounds = getattr(self, "_product_bounds", None)
            if not bounds:
                bounds = tile_manager.get_bounds()

            logger.info(f"Map fit bounds: {bounds}")
            if bounds:
                self._apply_zoom_to_bounds(bounds)
            else:
                # Fallback: notify that bounds couldn't be determined for auto-zoom
                logger.warning("Could not determine bounds for auto-zoom")
        else:
            ui.notify("❌ Failed to update tile server", type="negative")

    async def _refresh_worldcover_overlay(self):
        """Refresh WorldCover overlay while keeping base Sentinel layer visible."""
        try:
            await self.__refresh_worldcover_overlay_impl()
        except RuntimeError:
            pass  # parent slot deleted (tab navigated away)

    async def __refresh_worldcover_overlay_impl(self):
        from loguru import logger

        if not self.current_img_root or not self.map_widget_obj:
            logger.warning("WorldCover refresh skipped: no current_img_root or map_widget_obj")
            return
        if self._worldcover_refresh_in_progress:
            logger.debug("WorldCover refresh already in progress, skipping")
            return
        self._worldcover_refresh_in_progress = True

        try:
            from vresto.ui.widgets.product_analysis_tab import ProductAnalysisTab

            temp_tab = ProductAnalysisTab()
            reference_band = None
            if self.selected_bands:
                reference_band = self.selected_bands[0]
            elif self.available_bands:
                reference_band = "TCI" if "TCI" in self.available_bands else sorted(self.available_bands.keys())[0]

            if not reference_band:
                logger.warning("WorldCover refresh skipped: no reference band found")
                ui.notify("⚠️ WorldCover needs a band selected first", type="warning")
                return

            band_file = temp_tab._find_band_file(reference_band, self.current_img_root, preferred_resolution=self.resolution_selector.value)
            if not band_file:
                logger.warning(f"WorldCover refresh skipped: band file not found for {reference_band}")
                ui.notify(f"⚠️ Band file not found for {reference_band}", type="warning")
                return

            target_res = int(self.resolution_selector.value)
            signature = (os.path.abspath(band_file), target_res, self.worldcover_year)

            if self._worldcover_layer_signature == signature and self._worldcover_layer_url:
                logger.info("Reusing cached WorldCover layer")
                self.map_widget_obj.remove_tile_layer("WorldCover")
                self.map_widget_obj.add_tile_layer(self._worldcover_layer_url, name="WorldCover", opacity=self.worldcover_opacity)
                return

            logger.info(f"Generating WorldCover colorized overlay for {band_file} at {target_res}m, year={self.worldcover_year}")

            # Notify BEFORE background thread (safe in UI context)
            ui.notify("🌍 Generating WorldCover overlay...", position="bottom-right", type="info", duration=3)

            # Run heavy computation in background thread
            colorized = await asyncio.to_thread(worldcover_service.get_colorized_worldcover_path, band_file, target_res, year=self.worldcover_year)

            # All UI operations below run AFTER the thread completes, back in async context
            if not colorized:
                logger.warning("WorldCover colorized path is None - no tiles in extent or error occurred")
                ui.notify("⚠️ WorldCover overlay unavailable for this extent", type="warning")
                return

            logger.info(f"WorldCover colorized file: {colorized}")

            external_host = self._get_public_tile_host()
            logger.info(f"Starting WorldCover tile server on port {self.worldcover_tile_port} with external_host={external_host}")

            wc_url = self.worldcover_tile_manager.get_tile_url(colorized, port=self.worldcover_tile_port, external_host=external_host)
            if not wc_url:
                logger.error("WorldCover tile manager returned None URL")
                ui.notify("❌ WorldCover tile server failed to start", type="negative")
                return

            logger.info(f"WorldCover tile URL: {wc_url}")
            self._worldcover_layer_signature = signature
            self._worldcover_layer_url = wc_url
            self.map_widget_obj.remove_tile_layer("WorldCover")
            self.map_widget_obj.add_tile_layer(wc_url, name="WorldCover", opacity=self.worldcover_opacity)
            ui.notify("✅ WorldCover overlay loaded", type="positive")
        except Exception as e:
            logger.exception(f"WorldCover overlay failed: {e}")
            ui.notify(f"❌ WorldCover overlay failed: {e}", type="negative")
        finally:
            self._worldcover_refresh_in_progress = False

    async def _refresh_lcm_overlay(self):
        """Refresh LCM overlay while keeping base Sentinel layer visible."""
        try:
            await self.__refresh_lcm_overlay_impl()
        except RuntimeError:
            pass  # parent slot deleted (tab navigated away)

    async def __refresh_lcm_overlay_impl(self):
        from loguru import logger

        if not self.current_img_root or not self.map_widget_obj:
            logger.warning("LCM refresh skipped: no current_img_root or map_widget_obj")
            return
        if self._lcm_refresh_in_progress:
            logger.debug("LCM refresh already in progress, skipping")
            return
        self._lcm_refresh_in_progress = True

        try:
            from vresto.ui.widgets.product_analysis_tab import ProductAnalysisTab

            temp_tab = ProductAnalysisTab()
            reference_band = None
            if self.selected_bands:
                reference_band = self.selected_bands[0]
            elif self.available_bands:
                reference_band = "TCI" if "TCI" in self.available_bands else sorted(self.available_bands.keys())[0]

            if not reference_band:
                logger.warning("LCM refresh skipped: no reference band found")
                ui.notify("⚠️ LCM needs a band selected first", type="warning")
                return

            band_file = temp_tab._find_band_file(reference_band, self.current_img_root, preferred_resolution=self.resolution_selector.value)
            if not band_file:
                logger.warning(f"LCM refresh skipped: band file not found for {reference_band}")
                ui.notify(f"⚠️ Band file not found for {reference_band}", type="warning")
                return

            target_res = int(self.resolution_selector.value)
            year = "2020"
            signature = (os.path.abspath(band_file), target_res, year)

            if self._lcm_layer_signature == signature and self._lcm_layer_url:
                logger.info("Reusing cached LCM layer")
                self.map_widget_obj.remove_tile_layer("LCM")
                self.map_widget_obj.add_tile_layer(self._lcm_layer_url, name="LCM", opacity=self.lcm_opacity)
                return

            logger.info(f"Generating LCM colorized overlay for {band_file} at {target_res}m, year={year}")
            ui.notify("🗺️ Generating LCM overlay...", position="bottom-right", type="info", duration=3)

            colorized = await asyncio.to_thread(lcm_service.get_colorized_lcm_path, band_file, target_res, year=year)
            if not colorized:
                logger.warning("LCM colorized path is None - no tiles in extent or error occurred")
                ui.notify("⚠️ LCM overlay unavailable for this extent", type="warning")
                return

            logger.info(f"LCM colorized file: {colorized}")

            external_host = self._get_public_tile_host()
            logger.info(f"Starting LCM tile server on port {self.lcm_tile_port} with external_host={external_host}")

            lcm_url = self.lcm_tile_manager.get_tile_url(colorized, port=self.lcm_tile_port, external_host=external_host)
            if not lcm_url:
                logger.error("LCM tile manager returned None URL")
                ui.notify("❌ LCM tile server failed to start", type="negative")
                return

            logger.info(f"LCM tile URL: {lcm_url}")
            self._lcm_layer_signature = signature
            self._lcm_layer_url = lcm_url
            self.map_widget_obj.remove_tile_layer("LCM")
            self.map_widget_obj.add_tile_layer(lcm_url, name="LCM", opacity=self.lcm_opacity)
            ui.notify("✅ LCM overlay loaded", type="positive")
        except Exception as e:
            logger.exception(f"LCM overlay failed: {e}")
            ui.notify(f"❌ LCM overlay failed: {e}", type="negative")
        finally:
            self._lcm_refresh_in_progress = False

    def _clear_map(self):
        """Clear all tile layers from the map."""
        if self.map_widget_obj:
            self.map_widget_obj.clear_tile_layers()
        self.worldcover_tile_manager.shutdown()
        self.lcm_tile_manager.shutdown()
        self._worldcover_layer_signature = None
        self._worldcover_layer_url = None
        self._lcm_layer_signature = None
        self._lcm_layer_url = None
        self.selected_bands = []
        self._update_bands_ui()
