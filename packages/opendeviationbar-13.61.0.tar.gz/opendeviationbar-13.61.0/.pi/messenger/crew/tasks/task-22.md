# Compare config defaults vs registry, propose wiring strategy

## Task: Compare config defaults vs registry and propose wiring strategy

### Background
Config modules have hardcoded threshold defaults that should come from registry:
- config/algorithm.py: default_threshold_decimal_bps = 250
- config/population.py: crypto_min_threshold = 250  
- config/cli_models.py: threshold = 250
- config/sidecar.py: Already uses registry ✓

Registry provides:
- get_thresholds_for_symbol(symbol) - returns thresholds tuple
- SymbolEntry.min_threshold - optional per-symbol minimum
- SymbolEntry.thresholds - explicit threshold list per symbol

Missing: Asset-class default thresholds and helper functions.

### Subtask Steps
1. Document current config defaults vs what registry can provide
2. Propose symbols.toml additions for [meta.default_thresholds]
3. Design helper functions: get_default_threshold_for_asset_class(), get_effective_default_threshold()
4. Specify how each config file should be updated

### Output
Write wiring strategy to /tmp/crew-perspective-4/wiring_strategy.md
