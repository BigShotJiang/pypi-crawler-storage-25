# Audit config files for registry integration

Audit config/algorithm.py default_threshold_decimal_bps, threshold.py _FALLBACK_DEFAULTS. Propose registry-based solution: add [meta] section to symbols.toml with asset-class defaults. Add helper functions to symbol_registry.py.
