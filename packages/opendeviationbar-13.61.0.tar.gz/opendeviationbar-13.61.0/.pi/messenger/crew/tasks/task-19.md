# Add asset-class default thresholds to registry

Propose adding asset-class default threshold fields to symbols.toml. Add get_default_threshold_for_asset_class() function to symbol_registry.py. Update constants.py DEFAULT_THRESHOLD to use registry.
