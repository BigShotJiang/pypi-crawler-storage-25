# checkpoint/sidecar.py integration

Document hardcoded thresholds in checkpoint.py default threshold param and sidecar.py docstring examples; propose registry defaults
