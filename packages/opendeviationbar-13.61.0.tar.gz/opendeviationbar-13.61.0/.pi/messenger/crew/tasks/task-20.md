# Document hardcoded threshold locations needing updates

Identify all hardcoded threshold=250 locations in scripts and examples. Document each as needing registry integration. Create follow-up task to update each file to use get_thresholds_for_symbol() or config lookup.
