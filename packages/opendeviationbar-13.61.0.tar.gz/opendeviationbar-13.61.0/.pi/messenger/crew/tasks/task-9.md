# Task 9: Public API vs Documentation Parity

Perform final comprehensive check comparing documented API to actual code exports. Create scaffolding directory at `/tmp/crew-api/`. Compare Python `__all__` exports to documented functions; check Rust types exported via PyO3 match CLAUDE.md listings; verify CLI commands in docs match actual entry points; run documented code examples to confirm they work. This is the final audit task - depends on Tasks 1-8. Use Dynamic Task Creation: for each parity gap, create sub-task to update code or docs. Broadcast final comprehensive findings to all peers.
