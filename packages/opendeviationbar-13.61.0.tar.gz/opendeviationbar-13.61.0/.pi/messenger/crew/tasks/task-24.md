# population.py registry integration

Document hardcoded thresholds in population.py PHASES dict and default threshold param; propose configurable phase thresholds from registry
