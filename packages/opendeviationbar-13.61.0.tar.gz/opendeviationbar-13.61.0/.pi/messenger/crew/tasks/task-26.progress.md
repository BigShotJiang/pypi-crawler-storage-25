[2026-03-12T21:02:01.531Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:04:04.138Z] (system) Assigned to worker HappyMoon (attempt 1)
[2026-03-12T21:04:14.583Z] (system) Lobby worker HappyMoon exited (code 0), reset to todo
[2026-03-12T21:04:14.790Z] (system) Assigned to worker HappyZenith (attempt 2)
[2026-03-12T21:05:03.204Z] (system) Lobby worker HappyZenith exited (code 0), reset to todo
[2026-03-12T21:05:03.236Z] (system) Assigned to worker ZenQuartz (attempt 3)
[2026-03-12T21:05:21.208Z] (system) Lobby worker ZenQuartz exited (code 0), reset to todo
[2026-03-12T21:05:21.340Z] (system) Assigned to worker DarkYak (attempt 4)
[2026-03-12T21:05:57.223Z] (system) Lobby worker DarkYak exited (code 0), reset to todo
[2026-03-12T21:06:14.343Z] (system) Assigned to worker DarkBear (attempt 5)
[2026-03-12T21:20:24.366Z] (system) Auto-blocked after 5 attempts (max: 5)
