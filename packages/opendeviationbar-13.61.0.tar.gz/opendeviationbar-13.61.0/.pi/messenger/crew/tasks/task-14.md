# Task 5: Scripts Directory Audit

Investigate scripts/ for hardcoded symbols and thresholds. Create scaffolding directory at /tmp/crew-perspective-5/. Search all .py scripts for hardcoded threshold values (250, 500, 750, 1000); check for hardcoded BTCUSDT or other symbol names; audit populate_full_cache.py, backfill_watcher.py, kintsugi.py; review validation scripts (validate_*.py) for hardcoded test values. Use Dynamic Task Creation: create sub-tasks for each script category to document hardcoded values. Broadcast key findings to all peers.
