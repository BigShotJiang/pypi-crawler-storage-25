# Audit opendeviationbar-core tests

Investigate crates/opendeviationbar-core/ for hardcoded threshold values in tests. Search for threshold_decimal_bps = 250 patterns, check processor.rs for default threshold handling.
