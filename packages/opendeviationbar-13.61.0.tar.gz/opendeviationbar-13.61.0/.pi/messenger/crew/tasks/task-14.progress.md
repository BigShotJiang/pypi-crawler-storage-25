[2026-03-12T20:42:57.817Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:48:03.016Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:57:03.712Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:02:01.531Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:04:02.743Z] (system) Assigned to worker KeenMoon (attempt 1)
[2026-03-12T21:04:04.020Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T21:04:04.120Z] (system) Assigned to worker ZenOwl (attempt 2)
[2026-03-12T21:04:14.279Z] (system) Lobby worker ZenOwl exited (code 0), reset to todo
[2026-03-12T21:04:14.390Z] (system) Assigned to worker ZenLion (attempt 3)
[2026-03-12T21:05:07.754Z] (system) Lobby worker ZenLion exited (code 0), reset to todo
[2026-03-12T21:05:07.791Z] (system) Assigned to worker FastEagle (attempt 4)
[2026-03-12T21:05:58.385Z] (system) Lobby worker FastEagle exited (code 0), reset to todo
[2026-03-12T21:05:58.415Z] (system) Assigned to worker FastOwl (attempt 5)
[2026-03-12T21:20:24.366Z] (system) Auto-blocked after 5 attempts (max: 5)
