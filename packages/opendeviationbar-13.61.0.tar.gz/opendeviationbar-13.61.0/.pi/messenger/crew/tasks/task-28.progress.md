# task-28 Progress Log

## Audit Findings: CLI tools and PyO3 bindings

### 1. spot_tier1_processor.rs (crates/opendeviationbar-cli/src/bin/)

Hardcoded defaults found:
- `start_date`: "2024-07-01" (default_value)
- `end_date`: "2024-10-31" (default_value)
- `threshold_decimal_bps`: 250 (default_value = "250")
- `output_dir`: "./output/spot_tier1_batch" (default_value)
- `workers`: 8 (default_value_t = 8)

**Issue**: The threshold default value of 250 should potentially come from the Symbol Registry (symbols.toml) which has per-symbol thresholds.

### 2. chart tool (tools/chart/src/main.rs)

Hardcoded defaults found:
- `symbol`: "BTCUSDT" (default_value = "BTCUSDT")
- `threshold`: 250 (default_value_t = 250)

**Issue**: Both symbol (BTCUSDT) and threshold (250) are hardcoded. The symbol should ideally be configurable via CLI or have a sensible default from the Symbol Registry (e.g., first enabled Tier-1 symbol).

### 3. PyO3 bindings (src/core_bindings.rs)

- The `PyOpenDeviationBarProcessor::new()` method takes `threshold_decimal_bps` as a **required parameter** from Python
- The threshold is properly passed from Python to Rust
- No hardcoded threshold in the Rust bindings themselves

**Status**: ✅ The PyO3 bindings properly accept threshold as a parameter from Python. The hardcoding happens at the Python level (in constants.py: DEFAULT_THRESHOLD = 250) or in the CLI tools.

### Summary

| File | Hardcoded Defaults | Should Use Symbol Registry? |
|------|-------------------|---------------------------|
| spot_tier1_processor.rs | threshold=250, dates, output_dir | threshold: yes |
| chart tool (main.rs) | symbol=BTCUSDT, threshold=250 | both: yes |
| core_bindings.rs | none (parameterized) | n/a - already correct |
