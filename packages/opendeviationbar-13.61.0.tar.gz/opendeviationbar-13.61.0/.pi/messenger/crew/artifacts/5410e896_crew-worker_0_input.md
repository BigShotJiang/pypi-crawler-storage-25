# Task for crew-worker

# Task Assignment

**Task ID:** task-32
**Task Title:** Identify quick-win fixes
**PRD:** /Users/terryli/eon/opendeviationbar-py/PRD.md


## Your Mission

Implement this task following the crew-worker protocol:
1. Join the mesh
2. Read task spec to understand requirements
3. Start task and reserve files
4. Implement the feature
5. Commit your changes
6. Release reservations and mark complete

## Dependency Status

Your task has dependencies on other tasks. Some may not be complete yet — this is expected. Use the coordination system to work through it.

- ○ task-10 (Task 1: Python Constants Module Audit) — not yet started
- ○ task-11 (Task 2: CLI/Tool Entry Points Audit) — not yet started
- ○ task-12 (Task 3: ClickHouse Cache Layer Audit) — not yet started
- ✓ task-13 (Task 4: Configuration Modules Audit) — done. Audited config modules for hardcoded defaults: Found 3 files with hardcoded threshold=250 (algorithm.py, population.py, cli_models.py). sidecar.py already uses registry properly. Created sub-task task-22 to propose wiring strategy. Broadcast findings to peers.
- ○ task-14 (Task 5: Scripts Directory Audit) — not yet started
- ✓ task-19 (Add asset-class default thresholds to registry) — done. Created proposal for adding asset-class default thresholds to symbols.toml. Proposed adding [meta.default_thresholds] section, get_default_threshold_for_asset_class() and get_effective_default_threshold() functions to symbol_registry.py. Documented update path for constants.py and threshold.py.
- ✓ task-20 (Document hardcoded threshold locations needing updates) — done. Documented 76+ files with hardcoded threshold=250 values across core library, examples, scripts, and tests. Categorized by priority based on impact. Created detailed migration strategy and recommended helper functions needed.
- ✓ task-21 (Audit config files for registry integration) — done. Audited config files (algorithm.py, threshold.py, population.py, cli_models.py). Proposed registry integration: add [meta.default_thresholds] to symbols.toml, add get_default_threshold_for_asset_class() helper, update config classes with computed properties.
- ✓ task-23 (backfill.py registry integration) — done. Documented hardcoded _PRIORITY_SYMBOLS and default threshold=250 in backfill.py. Proposed adding priority field to SymbolEntry, get_priority_symbols() and get_default_threshold() functions to symbol_registry.py.
- ✓ task-24 (population.py registry integration) — done. Documented hardcoded PHASES dict with thresholds [1000], [250], [500, 750], [100] and default threshold=250 in population.py. Proposed adding phase definitions to symbols.toml metadata and get_phase_thresholds() function.
- ✓ task-25 (checkpoint/sidecar.py integration) — done. Documented hardcoded threshold=250 default in checkpoint.py and docstring examples in sidecar.py. Proposed using get_default_threshold() and get_min_threshold_for_symbol() for validation.
- ○ task-26 (config files registry integration) — not yet started
- ○ task-27 (Audit opendeviationbar-core tests) — not yet started
- ✓ task-28 (Audit CLI tools and PyO3 bindings) — done. Audited CLI tools and PyO3 bindings for hardcoded defaults. Found: (1) spot_tier1_processor has hardcoded threshold=250 and date range defaults, (2) chart tool has hardcoded symbol=BTCUSDT and threshold=250, (3) PyO3 bindings properly accept threshold as parameter from Python - no hardcoding. Findings documented in task-28.progress.md.
- ✓ task-29 (Document findings and propose solutions) — done. Created comprehensive report at docs/symbol-registry-rust-integration.md documenting 45+ hardcoded threshold locations and proposing three solution approaches for wiring Rust to Symbol Registry: (1) Environment variables for tools, (2) Build-time generated constants for core library, (3) PyO3 bindings for Python interop. Included implementation roadmap with 4 phases and verification commands.

**Working with pending dependencies:**
- Check if the dependency's output files exist. If yes, import and use them.
- If not, define what you need locally based on your task spec. Your spec describes the interfaces.
- DM in-progress workers for API details they're building.
- Reserve your files before editing to prevent conflicts.
- Do NOT block yourself because a dependency isn't done. Work around it.
- Log any local definitions in your progress for later reconciliation.

## Recent Activity

14:23 ZenXenon started task-30 — Create comprehensive findings matrix
14:23 EpicJaguar started task-31 — Draft implementation plan
14:23 IronMoon ✦ Completed task-18: Created cross-cutting synthesis at docs/symbol-registry-synthesis.md with 4-phase implementation plan. Created subtasks task-30 (findings matrix), task-31 (implementation plan), ...
14:23 ZenXenon ✦ Starting task-30 (Create comprehensive findings matrix) — will aggregate findings from completed audit tasks"
14:24 EpicJaguar reset task-31 — worker exited
14:24 SwiftGrove started task-31 — Draft implementation plan
14:24 ZenXenon reset task-30 — worker exited
14:24 LoudLion started task-30 — Create comprehensive findings matrix

## Task Specification

# Identify quick-win fixes

Identify and prioritize the easiest fixes that can be implemented immediately without registry changes


## Plan Context

Now I have a complete picture. Let me produce the task breakdown.

## 1. PRD Understanding Summary

The PRD requires auditing the codebase to identify all hardcoded values that should come from the Symbol Registry (symbols.toml). Key findings:

- **Symbol Registry**: Exists at `python/opendeviationbar/data/symbols.toml` with threshold fields, listing dates, asset class, exchange, enabled status
- **Hardcoded Values Found**:
  - Python: `constants.py` has `THRESHOLD_PRESETS` (250, 500, 750, 1000), multiple config files with `default_threshold_decimal_bps = 250`
  - Rust: `tools/chart/src/main.rs` has `default_value_t = 250`, test files with hardcoded thresholds
  - ClickHouse: `cache.py` has hardcoded "BTCUSDT" and threshold values in queries
  - Scripts: Many scripts with hardcoded threshold values

## 2. Relevant Code/Docs/Resources Reviewed

- **PRD.md**: Full specification with 9 investigative perspectives
- **Symbol Registry**: `python/opendeviationbar/symbol_registry.py` - exposes `get_thresholds_for_symbol()`, `get_symbol_entries()`, etc.
- **Constants**: `python/opendeviationbar/constants.py` - `THRESHOLD_PRESETS`, `TIER1_SYMBOLS`
- **CLI**: `tools/chart/src/main.rs` - default threshold 250
- **Config**: Multiple files in `python/opendeviationbar/config/` with hardcoded defaults
- **ClickHouse**: `python/opendeviationbar/clickhouse/cache.py` - hardcoded BTCUSDT and thresholds
- **Crates**: `crates/opendeviationbar-core/tests/` - hardcoded thresholds in tests

## 3. Sequential Implementation Steps

1. **Tasks 1-8 (Parallel)**: Each worker investigates their assigned code area
   - Create scaffolding directory `/tmp/crew-perspective-<N>/`
   - Systematically search for hardcoded thresholds, symbol names, dates
   - Use grep/ripgrep for empirical validation
   - Broadcast findings to peers

2. **Task 9**: Cross-Cutting Synthesis (after Tasks 1-8 complete)
   - Aggregate all hardcoded values found
   - Categorize by type: thresholds, symbols, dates
   - Propose r

[Spec truncated - read full spec from .pi/messenger/crew/plan.md]
## Coordination

**Message budget: 10 messages this session.** The system enforces this — sends are rejected after the limit.

**Broadcasts go to the team feed — only the user sees them live.** Other workers see your broadcasts in their initial context only. Use DMs for time-sensitive peer coordination.

### Announce yourself
After joining the mesh and starting your task, announce what you're working on:

```typescript
pi_messenger({ action: "broadcast", message: "Starting <task-id> (<title>) — will create <files>" })
```

### Coordinate with peers
If a concurrent task involves files or interfaces related to yours, send a brief DM. Only message when there's a concrete coordination need — shared files, interfaces, or blocking questions.

```typescript
pi_messenger({ action: "send", to: "<peer-name>", message: "I'm exporting FormatOptions from types.ts — will you need it?" })
```

### Responding to messages
If a peer asks you a direct question, reply briefly. Ignore messages that don't require a response. Do NOT start casual conversations.

### On completion
Announce what you built:

```typescript
pi_messenger({ action: "broadcast", message: "Completed <task-id>: <file> exports <symbols>" })
```

### Reservations
Before editing files, check if another worker has reserved them via `pi_messenger({ action: "list" })`. If a file you need is reserved, message the owner to coordinate. Do NOT edit reserved files without coordinating first.

### Questions about dependencies
If your task depends on a completed task and something about its implementation is unclear, read the code and the task's progress log at `.pi/messenger/crew/tasks/<task-id>.progress.md`. Dependency authors are from previous waves and are no longer in the mesh.

### Claim next task
After completing your assigned task, check if there are ready tasks you can pick up:

```typescript
pi_messenger({ action: "task.ready" })
```

If a task is ready, claim and implement it. If `task.start` fails (another worker claimed it first), check for other ready tasks. Only claim if your current task completed cleanly and quickly.

## Available Skills

Read any skill that matches what you're implementing.

  ralph-loop — Use ralph_loop tool to run agent tasks in a persistent loop until a goal or condition is met. Load this skill whenever the user mentions "ralph loop", "keep trying", "retry until", "loop until", "run until done", or wants something to keep going across sessions.
    /Users/terryli/.pi/agent/skills/ralph-loop/SKILL.md

To load a skill: read({ path: "<skill-path>" })
