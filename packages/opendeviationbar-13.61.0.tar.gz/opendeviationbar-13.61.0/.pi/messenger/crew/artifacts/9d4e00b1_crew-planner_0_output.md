Now I have a comprehensive understanding of the project. Let me produce the task breakdown.

## 1. PRD Understanding Summary

The PRD requires auditing and aligning 7 CLAUDE.md files (1 root + 6 nested) to reflect the current code state in a Rust/Python hybrid project (`opendeviationbar-py`) that generates open deviation bars — a novel financial data type.

**Key Requirements:**
- Audit each CLAUDE.md for accuracy against current code
- Fix discrepancies between documentation and implementation
- Ensure cross-reference consistency between CLAUDE.md files
- Verify public API documentation matches actual exports
- Validate code examples in docs are runnable

**Project Structure Verified:**
- 9 Rust crates in workspace (opendeviationbar, opendeviationbar-core, opendeviationbar-providers, opendeviationbar-config, opendeviationbar-io, opendeviationbar-streaming, opendeviationbar-batch, opendeviationbar-cli, opendeviationbar-hurst)
- Python module at `python/opendeviationbar/` with submodules (clickhouse, config, plugins)
- Scripts directory with 150+ Python and shell scripts

## 2. Relevant Code/Docs/Resources Reviewed

- **PRD.md**: Full specification with 9 investigative perspectives
- **Cargo.toml**: Workspace configuration with 9 crates
- **CLAUDE.md files**: All 7 files identified and located
- **Directory structures**: Verified crates/, python/, scripts/ contents
- **Python __init__.py**: Confirmed API exports via `__all__`

## 3. Sequential Implementation Steps

1. **Tasks 1-7 (Parallel)**: Each worker investigates their assigned CLAUDE.md file
   - Create scaffolding directory `/tmp/crew-<perspective>/`
   - Audit documentation against actual code
   - Use bash/uvx for empirical validation
   - Broadcast findings to peers

2. **Task 8**: Cross-Reference Consistency Audit (after Tasks 1-7)
   - Verify links between CLAUDE.md files
   - Fix broken references

3. **Task 9**: Public API vs Documentation Parity (after Task 8)
   - Final comprehensive check
   - Run documented code examples

## 4. Parallelized Task Graph

---

## Tasks

### Task 1: Root CLAUDE.md Alignment

Investigate and verify that the root `/CLAUDE.md` (21KB) accurately reflects the project structure, architecture, and entry points. Create scaffolding directory at `/tmp/crew-root/`. Check: crate list in "Architecture" section matches actual `crates/` directory (9 crates verified: opendeviationbar, opendeviationbar-core, opendeviationbar-providers, opendeviationbar-config, opendeviationbar-io, opendeviationbar-streaming, opendeviationbar-batch, opendeviationbar-cli, opendeviationbar-hurst); PyO3 bindings in `src/` match documented exports; API entry points in "Python API" section exist in actual code; mise commands in "Development Commands" are valid. Use Dynamic Task Creation: after finding specific mismatches, create sub-tasks to fix each category of issues. Broadcast key findings to all peers via pi_messenger.

Dependencies: none

### Task 2: Rust Crates CLAUDE.md Alignment

Investigate and verify that `/crates/CLAUDE.md` (15KB) accurately documents the Rust crate structure, types, and algorithms. Create scaffolding directory at `/tmp/crew-rust/`. Verify 9-crate workspace matches actual `Cargo.toml` and directory structure; check microstructure feature formulas match implementation in `processor.rs`; validate inter-bar feature list in `interbar.rs`; confirm key types (`OpenDeviationBarProcessor`, `FixedPoint`, etc.) exist in actual code. Use Dynamic Task Creation: after finding specific mismatches, spawn sub-tasks to update formulas, add missing features, or correct type references. Broadcast key findings to all peers.

Dependencies: none

### Task 3: Python Core API CLAUDE.md Alignment

Investigate and verify that `/python/opendeviationbar/CLAUDE.md` (18KB) matches Python API exports. Create scaffolding directory at `/tmp/crew-python/`. Check all functions in "Key Files > __init__.py" exist in actual `__init__.py` (verify `__all__` exports); validate `TIER1_SYMBOLS`, `THRESHOLD_PRESETS` constants match code; verify validation modules exist (`validation/tier1.py`, `tier2.py`); confirm storage classes (`TickStorage`) exist. Use Dynamic Task Creation: for each missing function or incorrect reference, create a sub-task to either add to code or update docs. Broadcast key findings to all peers.

Dependencies: none

### Task 4: ClickHouse CLAUDE.md Alignment

Investigate and verify that `/python/opendeviationbar/clickhouse/CLAUDE.md` (14KB) matches actual cache implementation. Create scaffolding directory at `/tmp/crew-clickhouse/`. Check `schema.sql` matches documented columns; verify `populate_cache_resumable()` signature and behavior; validate ClickHouse connection code matches documented approach; confirm dedup hardening procedures are documented. Use Dynamic Task Creation: if schema or API mismatches found, create sub-task to reconcile. Broadcast key findings to all peers.

Dependencies: none

### Task 5: Configuration CLAUDE.md Alignment

Investigate and verify that `/python/opendeviationbar/config/CLAUDE.md` (2.6KB) matches actual config modules. Create scaffolding directory at `/tmp/crew-config/`. List all files in `config/` directory and compare to "File Map" table (verified: `__init__.py`, `algorithm.py`, `cli_models.py`, `clickhouse.py`, `monitoring.py`, `population.py`, `settings.py`, `sidecar.py`, `streaming.py`); verify Settings singleton pattern works as documented; check environment variable prefixes match; validate pydantic models exist with documented fields. Use Dynamic Task Creation: for missing config files or wrong env var names, create sub-tasks. Broadcast key findings to all peers.

Dependencies: none

### Task 6: Plugin System CLAUDE.md Alignment

Investigate and verify that `/python/opendeviationbar/plugins/CLAUDE.md` (4.4KB) matches actual plugin implementation. Create scaffolding directory at `/tmp/crew-plugins/`. Check `protocol.py` defines `FeatureProvider` Protocol as documented; verify entry-point discovery works in `loader.py`; validate plugin example code is runnable; confirm migration helpers exist. Use Dynamic Task Creation: if protocol or loader mismatches, create sub-tasks to fix. Broadcast key findings to all peers.

Dependencies: none

### Task 7: Scripts CLAUDE.md Alignment

Investigate and verify that `/scripts/CLAUDE.md` (15KB) matches actual scripts in `scripts/` directory. Create scaffolding directory at `/tmp/crew-scripts/`. List all `.py` and `.sh` scripts and compare to documented ones (verified 150+ scripts exist); verify mise commands exist in `.mise.toml`; check pueue orchestration scripts are documented; validate cache population scripts exist. Use Dynamic Task Creation: for missing scripts or wrong commands, create sub-tasks. Broadcast key findings to all peers.

Dependencies: none

### Task 8: Cross-Reference Consistency Audit

Investigate and verify consistency of cross-references between all CLAUDE.md files. Create scaffolding directory at `/tmp/crew-crossref/`. Check links from root CLAUDE.md to nested files are valid; verify parent/child relationships documented correctly; validate "Related" sections reference existing files; confirm hub-and-spoke CLAUDE.md network is accurate. This task depends on all individual file tasks (1-7) being complete. Use Dynamic Task Creation: create sub-tasks to fix broken links or inconsistent references. Broadcast key findings to all peers.

Dependencies: Task 1, Task 2, Task 3, Task 4, Task 5, Task 6, Task 7

### Task 9: Public API vs Documentation Parity

Perform final comprehensive check comparing documented API to actual code exports. Create scaffolding directory at `/tmp/crew-api/`. Compare Python `__all__` exports to documented functions; check Rust types exported via PyO3 match CLAUDE.md listings; verify CLI commands in docs match actual entry points; run documented code examples to confirm they work. This is the final audit task - depends on Tasks 1-8. Use Dynamic Task Creation: for each parity gap, create sub-task to update code or docs. Broadcast final comprehensive findings to all peers.

Dependencies: Task 1, Task 2, Task 3, Task 4, Task 5, Task 6, Task 7, Task 8

---

```tasks-json
[
  {
    "title": "Task 1: Root CLAUDE.md Alignment",
    "description": "Investigate and verify that the root `/CLAUDE.md` (21KB) accurately reflects the project structure, architecture, and entry points. Create scaffolding directory at `/tmp/crew-root/`. Check: crate list in \"Architecture\" section matches actual `crates/` directory (9 crates verified: opendeviationbar, opendeviationbar-core, opendeviationbar-providers, opendeviationbar-config, opendeviationbar-io, opendeviationbar-streaming, opendeviationbar-batch, opendeviationbar-cli, opendeviationbar-hurst); PyO3 bindings in `src/` match documented exports; API entry points in \"Python API\" section exist in actual code; mise commands in \"Development Commands\" are valid. Use Dynamic Task Creation: after finding specific mismatches, create sub-tasks to fix each category of issues. Broadcast key findings to all peers via pi_messenger.",
    "dependsOn": []
  },
  {
    "title": "Task 2: Rust Crates CLAUDE.md Alignment",
    "description": "Investigate and verify that `/crates/CLAUDE.md` (15KB) accurately documents the Rust crate structure, types, and algorithms. Create scaffolding directory at `/tmp/crew-rust/`. Verify 9-crate workspace matches actual `Cargo.toml` and directory structure; check microstructure feature formulas match implementation in `processor.rs`; validate inter-bar feature list in `interbar.rs`; confirm key types (`OpenDeviationBarProcessor`, `FixedPoint`, etc.) exist in actual code. Use Dynamic Task Creation: after finding specific mismatches, spawn sub-tasks to update formulas, add missing features, or correct type references. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 3: Python Core API CLAUDE.md Alignment",
    "description": "Investigate and verify that `/python/opendeviationbar/CLAUDE.md` (18KB) matches Python API exports. Create scaffolding directory at `/tmp/crew-python/`. Check all functions in \"Key Files > __init__.py\" exist in actual `__init__.py` (verify `__all__` exports); validate `TIER1_SYMBOLS`, `THRESHOLD_PRESETS` constants match code; verify validation modules exist (`validation/tier1.py`, `tier2.py`); confirm storage classes (`TickStorage`) exist. Use Dynamic Task Creation: for each missing function or incorrect reference, create a sub-task to either add to code or update docs. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 4: ClickHouse CLAUDE.md Alignment",
    "description": "Investigate and verify that `/python/opendeviationbar/clickhouse/CLAUDE.md` (14KB) matches actual cache implementation. Create scaffolding directory at `/tmp/crew-clickhouse/`. Check `schema.sql` matches documented columns; verify `populate_cache_resumable()` signature and behavior; validate ClickHouse connection code matches documented approach; confirm dedup hardening procedures are documented. Use Dynamic Task Creation: if schema or API mismatches found, create sub-task to reconcile. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 5: Configuration CLAUDE.md Alignment",
    "description": "Investigate and verify that `/python/opendeviationbar/config/CLAUDE.md` (2.6KB) matches actual config modules. Create scaffolding directory at `/tmp/crew-config/`. List all files in `config/` directory and compare to \"File Map\" table (verified: `__init__.py`, `algorithm.py`, `cli_models.py`, `clickhouse.py`, `monitoring.py`, `population.py`, `settings.py`, `sidecar.py`, `streaming.py`); verify Settings singleton pattern works as documented; check environment variable prefixes match; validate pydantic models exist with documented fields. Use Dynamic Task Creation: for missing config files or wrong env var names, create sub-tasks. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 6: Plugin System CLAUDE.md Alignment",
    "description": "Investigate and verify that `/python/opendeviationbar/plugins/CLAUDE.md` (4.4KB) matches actual plugin implementation. Create scaffolding directory at `/tmp/crew-plugins/`. Check `protocol.py` defines `FeatureProvider` Protocol as documented; verify entry-point discovery works in `loader.py`; validate plugin example code is runnable; confirm migration helpers exist. Use Dynamic Task Creation: if protocol or loader mismatches, create sub-tasks to fix. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 7: Scripts CLAUDE.md Alignment",
    "description": "Investigate and verify that `/scripts/CLAUDE.md` (15KB) matches actual scripts in `scripts/` directory. Create scaffolding directory at `/tmp/crew-scripts/`. List all `.py` and `.sh` scripts and compare to documented ones (verified 150+ scripts exist); verify mise commands exist in `.mise.toml`; check pueue orchestration scripts are documented; validate cache population scripts exist. Use Dynamic Task Creation: for missing scripts or wrong commands, create sub-tasks. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 8: Cross-Reference Consistency Audit",
    "description": "Investigate and verify consistency of cross-references between all CLAUDE.md files. Create scaffolding directory at `/tmp/crew-crossref/`. Check links from root CLAUDE.md to nested files are valid; verify parent/child relationships documented correctly; validate \"Related\" sections reference existing files; confirm hub-and-spoke CLAUDE.md network is accurate. This task depends on all individual file tasks (1-7) being complete. Use Dynamic Task Creation: create sub-tasks to fix broken links or inconsistent references. Broadcast key findings to all peers.",
    "dependsOn": ["Task 1: Root CLAUDE.md Alignment", "Task 2: Rust Crates CLAUDE.md Alignment", "Task 3: Python Core API CLAUDE.md Alignment", "Task 4: ClickHouse CLAUDE.md Alignment", "Task 5: Configuration CLAUDE.md Alignment", "Task 6: Plugin System CLAUDE.md Alignment", "Task 7: Scripts CLAUDE.md Alignment"]
  },
  {
    "title": "Task 9: Public API vs Documentation Parity",
    "description": "Perform final comprehensive check comparing documented API to actual code exports. Create scaffolding directory at `/tmp/crew-api/`. Compare Python `__all__` exports to documented functions; check Rust types exported via PyO3 match CLAUDE.md listings; verify CLI commands in docs match actual entry points; run documented code examples to confirm they work. This is the final audit task - depends on Tasks 1-8. Use Dynamic Task Creation: for each parity gap, create sub-task to update code or docs. Broadcast final comprehensive findings to all peers.",
    "dependsOn": ["Task 1: Root CLAUDE.md Alignment", "Task 2: Rust Crates CLAUDE.md Alignment", "Task 3: Python Core API CLAUDE.md Alignment", "Task 4: ClickHouse CLAUDE.md Alignment", "Task 5: Configuration CLAUDE.md Alignment", "Task 6: Plugin System CLAUDE.md Alignment", "Task 7: Scripts CLAUDE.md Alignment", "Task 8: Cross-Reference Consistency Audit"]
  }
]
```