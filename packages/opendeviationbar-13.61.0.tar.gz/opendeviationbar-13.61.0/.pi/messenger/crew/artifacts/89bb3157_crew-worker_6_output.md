## Summary

I've completed **Task 9: Cross-Cutting Synthesis and Resolution Strategy** (task-18).

### What I Did

1. **Audited the codebase** to identify hardcoded values that should come from the Symbol Registry
2. **Created comprehensive synthesis documents**:
   - `hardcoded_values_synthesis.md` - Full analysis with findings matrix
   - `quick_win_implementation_plan.md` - Immediate action items
   - `findings_matrix.json` - Structured data for tooling

### Key Findings

| Category | Count | Ready for Wiring |
|----------|-------|-----------------|
| Threshold defaults (250, 500, 1000) | 40+ locations | 35 |
| Symbol lists (TIER1_SYMBOLS) | 1 location | 1 |
| Min thresholds | 3 locations | 0 |

### Missing Registry Helper Functions

1. `get_default_threshold()` - Returns 250
2. `get_tier1_symbols()` - Returns tier=1 symbols
3. `get_default_thresholds()` - Returns [250, 500, 750, 1000]
4. `get_min_threshold_for_symbol(symbol)` - Per-symbol min with fallback

### Proposed Implementation Phases

1. **Quick Wins**: Add helper functions, update constants.py, config/algorithm.py
2. **CLI Integration**: Wire tools/chart to env vars
3. **Script Migration**: Audit 15+ scripts with hardcoded thresholds
4. **Test Fixtures**: Centralize test data from registry

### Commit

```
19e70d0 feat(audit): Task 9 cross-cutting synthesis - hardcoded values resolution strategy
```