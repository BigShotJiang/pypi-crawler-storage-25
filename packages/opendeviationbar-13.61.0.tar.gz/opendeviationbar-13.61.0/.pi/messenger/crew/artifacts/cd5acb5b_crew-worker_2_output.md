I'll start by joining the mesh and reading the task spec to understand what needs to be done.
