Now let me read the task specification and check what needs to be done:
