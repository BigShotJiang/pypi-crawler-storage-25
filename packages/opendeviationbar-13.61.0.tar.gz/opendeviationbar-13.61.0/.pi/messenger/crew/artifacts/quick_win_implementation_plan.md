# Quick Win Implementation Plan

## Immediate Actions (Do First)

### 1. Add Missing Registry Helper Functions

**File:** `python/opendeviationbar/symbol_registry.py`

```python
def get_default_threshold() -> int:
    """Return universal default threshold (250 dbps = 0.25%)."""
    return 250

def get_tier1_symbols() -> tuple[str, ...]:
    """Return all tier=1 symbols from registry."""
    entries = get_symbol_entries()
    return tuple(
        symbol for symbol, entry in entries.items()
        if entry.tier == 1 and entry.enabled
    )

def get_default_thresholds() -> tuple[int, ...]:
    """Return default threshold list [250, 500, 750, 1000]."""
    return (250, 500, 750, 1000)

def get_min_threshold_for_symbol(symbol: str) -> int:
    """Return per-symbol min_threshold with asset-class fallback.
    
    Falls back to:
    - 1000 dbps for crypto (OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD)
    - 50 dbps for forex (OPENDEVIATIONBAR_FOREX_MIN_THRESHOLD)
    - 250 dbps as universal fallback
    """
    symbol = normalize_symbol(symbol)
    entries = get_symbol_entries()
    
    if symbol in entries:
        entry = entries[symbol]
        if entry.min_threshold is not None:
            return entry.min_threshold
    
    # Fallback to asset-class defaults
    if symbol in entries:
        asset_class = entries[symbol].asset_class
        if asset_class == "crypto":
            return 1000  # OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD
        elif asset_class == "forex":
            return 50  # OPENDEVIATIONBAR_FOREX_MIN_THRESHOLD
    
    return 250  # Universal fallback
```

### 2. Update constants.py to Use Registry

**File:** `python/opendeviationbar/constants.py`

```python
# Add imports
from opendeviationbar.symbol_registry import (
    get_default_threshold,
    get_tier1_symbols,
    get_default_thresholds,
)

# Replace hardcoded values
# Before: DEFAULT_THRESHOLD: int = 250
DEFAULT_THRESHOLD: int = get_default_threshold()

# Before: TIER1_SYMBOLS = ("AAVE", "ADA", ...)
TIER1_SYMBOLS: tuple[str, ...] = get_tier1_symbols()

# Keep THRESHOLD_PRESETS as-is (user-facing presets, not registry)
# But consider adding:
# THRESHOLD_PRESETS["registry"] = get_default_thresholds()
```

### 3. Update config/algorithm.py

**File:** `python/opendeviationbar/config/algorithm.py`

```python
from opendeviationbar.symbol_registry import get_default_threshold

# Before: default_threshold_decimal_bps: int = 250
default_threshold_decimal_bps: int = get_default_threshold()
```

### 4. Update tools/chart/src/main.rs

**File:** `tools/chart/src/main.rs`

```rust
// Add environment variable support
std::env::var("OPENDEVIATIONBAR_DEFAULT_THRESHOLD")
    .ok()
    .and_then(|v| v.parse().ok())
    .unwrap_or(250)
```

---

## Implementation Order

1. **Add helper functions to symbol_registry.py** - Enables all other changes
2. **Update constants.py** - Central Python usage
3. **Update config/algorithm.py** - Configuration layer
4. **Update tools/chart** - Rust CLI tool
5. **Audit and update scripts** - Batch process remaining 15+ files

---

## Verification

After implementation, run:

```bash
# Verify constants delegate correctly
python -c "
from opendeviationbar.constants import DEFAULT_THRESHOLD, TIER1_SYMBOLS
from opendeviationbar.symbol_registry import get_default_threshold, get_tier1_symbols

assert DEFAULT_THRESHOLD == get_default_threshold(), 'DEFAULT_THRESHOLD mismatch'
assert TIER1_SYMBOLS == get_tier1_symbols(), 'TIER1_SYMBOLS mismatch'
print('✓ Registry integration verified')
"

# Verify config uses registry
python -c "
from opendeviationbar.config.algorithm import AlgorithmConfig
config = AlgorithmConfig()
print(f'default_threshold: {config.default_threshold_decimal_bps}')
"
```
