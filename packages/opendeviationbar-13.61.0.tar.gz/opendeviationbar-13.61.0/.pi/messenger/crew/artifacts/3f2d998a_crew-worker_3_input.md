# Task for crew-worker

# Task Assignment

**Task ID:** task-6
**Task Title:** Task 6: Backfill & Population Pipeline Audit
**PRD:** PRD.md


## Your Mission

Implement this task following the crew-worker protocol:
1. Join the mesh
2. Read task spec to understand requirements
3. Start task and reserve files
4. Implement the feature
5. Commit your changes
6. Release reservations and mark complete

## Concurrent Tasks

These tasks are being worked on by other workers in this wave. Discover their agent names after joining the mesh via `pi_messenger({ action: "list" })`.

- task-3: Task 3: ClickHouse Cache Layer Audit
- task-4: Task 4: Configuration Modules Audit
- task-5: Task 5: Scripts Directory Audit
- task-7: Task 7: Rust Crates Audit
- task-8: Task 8: Symbol Registry Integration Points Audit
- task-9: Task 9: Cross-Cutting Synthesis & Resolution Strategy

## Recent Activity

13:28 FastYak ✦ ✅ Task-8 Registry Audit: Found 5 files with hardcoded values that should use registry: kintsugi.py (_PRIORITY_SYMBOLS), backfill.py (_PRIORITY_SYMBOLS), constants.py, algorithm.py, population.py. P...
13:28 FastYak completed task-8 — Audited Symbol Registry integration points. Found 5 files with hardcoded values that should use registry: kintsugi.py (_PRIORITY_SYMBOLS), backfill.py (_PRIORITY_SYMBOLS), constants.py, algorithm.py, population.py. Proposed adding get_default_threshold() and get_priority_symbol() helper functions. Full findings in /tmp/crew-registry/registry_audit.md
13:28 FastYak started task-7 — Task 7: Rust Crates Audit
13:28 FastYak ✦ Starting task-7 (Rust Crates Audit) — will search for hardcoded thresholds in crates/
13:29 FastYak ✦ ✅ Task-7 Rust Audit: Found hardcoded thresholds in opendeviationbar-config (Rust) and processors/api.py (Python). Primary issue: Python API defaults to 250 instead of querying registry. Fix: Pass t...
13:29 FastYak completed task-7 — Audited Rust crates for hardcoded thresholds. Found issues in opendeviationbar-config (Rust) and processors/api.py (Python). Primary fix needed: Python API should query registry when threshold is not provided. Full findings in /tmp/crew-rust/rust_audit.md
13:34 ZenZenith started task-1 — Task 1: Python Constants Module Audit
13:34 SagePhoenix started task-2 — Task 2: CLI/Tool Entry Points Audit

## Task Specification

# Task 6: Backfill & Population Pipeline Audit

Investigate and verify that data pipeline code uses the symbol registry. Create scaffolding directory at `/tmp/crew-pipeline/`. Check `python/opendeviationbar/backfill.py` for hardcoded thresholds; audit `python/opendeviationbar/population.py` for hardcoded values; review `checkpoint.py` for threshold handling vs registry; check `sidecar.py` for threshold validation. Use Dynamic Task Creation: create sub-tasks to document pipeline touchpoints needing registry integration. Broadcast key findings to all peers.


## Plan Context

Now I have a comprehensive understanding of the project. Let me create the task breakdown.

## 1. PRD Understanding Summary

The PRD requires auditing the codebase for **hardcoded symbol parameters** (thresholds, symbols, dates) that should instead query the **Symbol Registry** (SSoT at `symbols.toml`). The project has a well-structured registry with `min_threshold`, `thresholds`, `listing_date`, `effective_start`, `asset_class`, `exchange`, `market`, and `enabled` fields, but many parts of the codebase have hardcoded values creating data drift and inconsistency.

**Key Touchpoints Identified:**
- Python `constants.py`: DEFAULT_THRESHOLD=250, THRESHOLD_PRESETS, TIER1_SYMBOLS
- CLI tools: `tools/chart/src/main.rs` default_value_t = 250
- ClickHouse cache: Hardcoded "BTCUSDT" in examples
- Config modules: Multiple 250, 500, 750, 1000 defaults in algorithm.py, sidecar.py, population.py
- Scripts: Many with hardcoded thresholds and symbols
- Rust crates: Documentation examples with hardcoded values

## 2. Relevant Code/Docs/Resources Reviewed

- **Symbol Registry**: `python/opendeviationbar/data/symbols.toml` - SSoT with threshold/date fields
- **Registry module**: `symbol_registry.py` - provides `get_thresholds_for_symbol()`, `get_symbol_entries()`, etc.
- **Constants**: `constants.py` - DEFAULT_THRESHOLD=250, THRESHOLD_PRESETS
- **Config**: `config/algorithm.py`, `sidecar.py`, `population.py`, `cli_models.py`
- **ClickHouse**: `clickhouse/cache.py`, `bulk_operations.py`, `maintenance.py`
- **Scripts**: 150+ Python scripts in `scripts/`
- **Rust**: `crates/opendeviationbar-core/src/processor.rs` with hardcoded docs

## 3. Sequential Implementation Steps

1. **Tasks 1-8 (Parallel)**: Each worker investigates their assigned code area
   - Create scaffolding directory `/tmp/crew-<perspective>/`
   - Systematically audit for hardcoded thresholds/symbols/dates
   - Use bash + grep/ripgrep for search patterns
   - Broadcast findings to peers
   - Spawn sub-tasks for specific

[Spec truncated - read full spec from .pi/messenger/crew/plan.md]
## Coordination

**Message budget: 10 messages this session.** The system enforces this — sends are rejected after the limit.

**Broadcasts go to the team feed — only the user sees them live.** Other workers see your broadcasts in their initial context only. Use DMs for time-sensitive peer coordination.

### Announce yourself
After joining the mesh and starting your task, announce what you're working on:

```typescript
pi_messenger({ action: "broadcast", message: "Starting <task-id> (<title>) — will create <files>" })
```

### Coordinate with peers
If a concurrent task involves files or interfaces related to yours, send a brief DM. Only message when there's a concrete coordination need — shared files, interfaces, or blocking questions.

```typescript
pi_messenger({ action: "send", to: "<peer-name>", message: "I'm exporting FormatOptions from types.ts — will you need it?" })
```

### Responding to messages
If a peer asks you a direct question, reply briefly. Ignore messages that don't require a response. Do NOT start casual conversations.

### On completion
Announce what you built:

```typescript
pi_messenger({ action: "broadcast", message: "Completed <task-id>: <file> exports <symbols>" })
```

### Reservations
Before editing files, check if another worker has reserved them via `pi_messenger({ action: "list" })`. If a file you need is reserved, message the owner to coordinate. Do NOT edit reserved files without coordinating first.

### Questions about dependencies
If your task depends on a completed task and something about its implementation is unclear, read the code and the task's progress log at `.pi/messenger/crew/tasks/<task-id>.progress.md`. Dependency authors are from previous waves and are no longer in the mesh.

### Claim next task
After completing your assigned task, check if there are ready tasks you can pick up:

```typescript
pi_messenger({ action: "task.ready" })
```

If a task is ready, claim and implement it. If `task.start` fails (another worker claimed it first), check for other ready tasks. Only claim if your current task completed cleanly and quickly.

## Available Skills

Read any skill that matches what you're implementing.

  ralph-loop — Use ralph_loop tool to run agent tasks in a persistent loop until a goal or condition is met. Load this skill whenever the user mentions "ralph loop", "keep trying", "retry until", "loop until", "run until done", or wants something to keep going across sessions.
    /Users/terryli/.pi/agent/skills/ralph-loop/SKILL.md

To load a skill: read({ path: "<skill-path>" })
