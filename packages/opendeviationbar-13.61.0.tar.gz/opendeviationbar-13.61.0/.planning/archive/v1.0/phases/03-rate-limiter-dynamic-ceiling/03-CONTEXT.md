# Phase 3: Rate Limiter Dynamic Ceiling - Context

**Gathered:** 2026-03-19
**Status:** Ready for planning

<domain>
## Phase Boundary

Convert `AdaptiveRateLimiter`'s `ceiling: u32` field to `ceiling: AtomicU32` and add a `set_ceiling()` method. This enables Phase 4 (parallel fill_from_rest) to dynamically adjust the rate limit budget: 4800 weight/min during fill, 3000 after start (reserves headroom for Puck + kintsugi).

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase (~10 lines).

Key constraints from research:

- Change `ceiling: u32` to `ceiling: AtomicU32` in `AdaptiveRateLimiter`
- Add `pub fn set_ceiling(&self, new_ceiling: u32)` method
- Existing `X-MBX-USED-WEIGHT-1m` server feedback integration must remain unchanged
- `AtomicU32` is safe for concurrent access from `JoinSet` tasks (Phase 4)
- No new crate dependencies needed

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `AdaptiveRateLimiter` in `crates/opendeviationbar-providers/src/binance/rate_limiter.rs`
- Already uses `Arc` for sharing across tasks

### Integration Points

- `fill_from_rest()` in `live_engine.rs` — will call `set_ceiling(4800)` before fill, `set_ceiling(3000)` after

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase

</specifics>

<deferred>
## Deferred Ideas

None

</deferred>
