---
plan: 07-01
status: complete
completed: "2026-03-19"
commits:
  - 9f8505f # feat(combined-ws): add proactive overlapping reconnection at 23h
  - 24b22e5 # test(combined-ws): unit tests for proactive reconnection
---

# Summary: Plan 07-01 — Overlapping Reconnection

## What Changed

### Task 1: Proactive reconnection timer (9f8505f)

Modified `run_with_reconnect()` in `combined_ws.rs` to proactively spawn an overlapping connection at the 23h mark, before Binance's 24h forced disconnect:

- Added `PROACTIVE_RECONNECT_SECS` constant (82800 = 23 \* 3600)
- Added `oneshot` import for first-trade signaling between old and new connections
- Extended `connect_and_demux()` with optional `first_trade_signal: Option<oneshot::Sender<()>>` parameter — fires after the first trade is successfully delivered, confirming the new connection is live
- Modified `run_with_reconnect()` to use `tokio::select!` between the current connection, the 23h proactive timer, and the shutdown token
- When the timer fires: spawns a new `connect_and_demux` task on the same channels, waits up to 30s for the first-trade signal, then cancels the old connection
- Trade-ID dedup at the processor level handles any duplicates during the brief overlap window
- Error paths (handoff timeout, task panic) fall through to existing Antaeus backoff logic

### Task 2: Unit tests (24b22e5)

- `test_proactive_reconnect_constant`: verifies value is 82800 and within the 22h-24h safety range
- `test_proactive_reconnect_oneshot_signal`: verifies oneshot channel mechanics used for handoff signaling

## Requirement Coverage

| Requirement | Status   | Evidence                                                          |
| ----------- | -------- | ----------------------------------------------------------------- |
| COMB-05     | Complete | Overlapping reconnection at 23h with first-trade-confirmed switch |

## Files Modified

- `crates/opendeviationbar-providers/src/binance/combined_ws.rs` (+157 lines)
