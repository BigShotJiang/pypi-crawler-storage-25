# Phase 7: Overlapping Reconnection - Context

**Gathered:** 2026-03-19
**Status:** Ready for planning

<domain>
## Phase Boundary

Add proactive overlapping reconnection to `CombinedWebSocketStream` at 23h mark. Open new connection while old still active, switch after first trade received on new connection, close old. Trade-ID dedup at processor level handles overlap window. Eliminates the Binance 24h forced-disconnect gap.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — infrastructure phase.

Key constraints from research:

- At 23h connection age, spawn new connection task alongside existing one
- New connection sends trades to same per-symbol channels (demux handles routing)
- After new connection receives first trade, signal old connection to gracefully close
- Trade-ID dedup already exists in processor — overlapping trades are silently dropped
- With 1x18 topology (single connection), there's no staggering needed (was for 2x9)
- Connection age tracked via `Instant::now()` at connection establishment
- Timer can use `tokio::time::sleep(Duration::from_secs(23 * 3600))`

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `CombinedWebSocketStream::run_with_reconnect()` in `combined_ws.rs` — reconnection loop
- `connect_and_demux()` — single connection handler
- Processor monotonicity guard (Phase 1) — drops trades with tid <= last processed

### Integration Points

- Inside `run_with_reconnect()` loop — add timer check for connection age
- `connect_and_demux()` returns when connection drops — use `tokio::select!` with timer

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase

</specifics>

<deferred>
## Deferred Ideas

None

</deferred>
