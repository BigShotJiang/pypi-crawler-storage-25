# Phase 2: Junction Telemetry + Audit Items - Context

**Gathered:** 2026-03-19
**Status:** Ready for planning

<domain>
## Phase Boundary

Add structured tracing instrumentation to the junction fill block (Phase 1) and `fill_from_rest()` in `live_engine.rs`. Covers 5 telemetry fields (junction gap tid delta, forming bar trades, WS buffer depth, Puck event type, per-symbol fill summary) plus 5 audit items (ring buffer capacity, per-symbol timing, buffer depth logging, Puck junction vs normal differentiation, forming bar preservation metric).

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase. Key guidance from research:

- Use existing `tracing` crate spans and structured fields (no new dependencies needed for this phase)
- Junction telemetry goes in the junction fill block added by Phase 1 (lines ~1284-1347 of `live_engine.rs`)
- `fill_from_rest` summary telemetry wraps the existing per-symbol fill logic
- Ring buffer capacity analysis: document whether 10K is sufficient for 18 symbols × 4 thresholds during full-day fill
- Puck events need `event_type` field: `"junction_suppressed"` vs `"normal_gap_fill"`
- Per-symbol REST fill timing: `{symbol, duration_ms, trade_count, bars_produced}` as structured tracing event

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `tracing::info!` / `tracing::warn!` already used throughout `live_engine.rs`
- Junction fill block (Phase 1) at lines ~1284-1347 — add telemetry around existing logic
- `fill_from_rest()` already has per-symbol loop — wrap with timing
- `pre_buffered_rx` channel — can query `.len()` for buffer depth (mpsc bounded channel)

### Established Patterns

- Structured tracing: `tracing::info!(%symbol, threshold = %threshold, "message")`
- Existing Puck logging at gap detection sites

### Integration Points

- Junction fill block in `symbol_task()`
- `fill_from_rest()` per-symbol loop
- Puck gap detection sites (main loop + junction)

</code_context>

<specifics>
## Specific Ideas

TELE-01 through TELE-05 and AUDT-01 through AUDT-05 overlap significantly — the telemetry fields satisfy most audit items. The ring buffer analysis (AUDT-01) is a documentation task, not a code change.

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>
