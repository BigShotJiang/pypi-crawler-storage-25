# Phase 5: Combined WS Spike Test - Context

**Gathered:** 2026-03-19
**Status:** Ready for planning

<domain>
## Phase Boundary

Data-driven selection of optimal combined WebSocket stream configuration. Spike test compares 3 configs (1×18, 2×9 even, 2×9 volume-tiered) against live Binance aggTrade streams on bigblack. Script deployed and running.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Spike script written (`scripts/spike_combined_ws.py`) and deployed to bigblack. Running via `uv run --python 3.13`. Measures: messages/sec, max inter-message latency per symbol, trade-ID gaps, errors. 5 min per configuration.

Winner selection criteria:

1. Zero trade-ID gaps (primary)
2. Highest messages/sec (secondary)
3. Lowest max inter-message gap (tertiary)

Results will be analyzed and winner documented in PROJECT.md key decisions.

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `scripts/spike_combined_ws.py` — stdlib + websockets spike test
- Binance combined stream URL: `wss://stream.binance.com:9443/stream?streams=...`
- Combined message format: `{"stream":"btcusdt@aggTrade","data":{...}}`

### Integration Points

- Winner config feeds into Phase 6 (CombinedWebSocketStream implementation)

</code_context>

<specifics>
## Specific Ideas

No specific requirements — spike test is running autonomously

</specifics>

<deferred>
## Deferred Ideas

None

</deferred>
