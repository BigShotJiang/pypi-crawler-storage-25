# Spike Test Results: Combined WebSocket Stream Configurations

**Date:** 2026-03-19
**Duration:** 300s per config
**Host:** bigblack (Linux, 1Gbps Ethernet)

## Results

| Config     | Conns | Total msgs | msg/s    | Max Inter-Message Gap | TID Gaps | Errors |
| ---------- | ----- | ---------- | -------- | --------------------- | -------- | ------ |
| **1x18**   | 1     | **16,260** | **52.5** | 69s (SHIBUSDT)        | **0**    | 0      |
| 2x9_even   | 2     | 12,128     | 39.2     | 48s (UNIUSDT)         | 0        | 0      |
| 2x9_tiered | 2     | 5,106      | 16.4     | 103s (AVAXUSDT)       | 0        | 0      |

## Winner: 1x18

Single connection with all 18 symbols delivers the highest throughput (52.5 msg/s) with zero trade-ID gaps. The 2x9 split provides no fault isolation benefit — all configs had zero errors over 5 minutes.

## Key Observations

1. **Zero TID gaps across all configs** — Binance combined streams deliver perfect trade-ID continuity
2. **1x18 throughput is 3.2x tiered** — single connection avoids duplicate TLS handshake + keepalive overhead
3. **MATICUSDT: 0 messages** — likely delisted or extremely low volume. Investigate before production.
4. **Max gap is misleading** — high values are for low-volume symbols (SHIBUSDT, AVAXUSDT) where trades are naturally infrequent. BTCUSDT max gap was 3.5-3.9s across all configs.
5. **2x9 tiered underperformed** — possibly due to connection timing or server-side load balancing

## Risk: Single Point of Failure

1x18 has one connection — if it drops, all 18 symbols lose data simultaneously. Mitigations:

- Puck gap fill handles reconnection gaps (sub-3s for small gaps)
- Overlapping reconnection at 23h (Phase 7) prevents the 24h forced disconnect
- Antaeus exponential backoff with jitter ensures rapid reconnection

## Decision

**Use 1x18 for Phase 6 implementation.** The throughput advantage outweighs the single-connection risk given existing Puck + Antaeus mitigations.

If production data shows reconnection-induced gaps affecting multiple symbols simultaneously, we can fall back to 2x9_even (second-best performer) without changing the `CombinedWebSocketStream` architecture — only the connection count and symbol grouping change.
