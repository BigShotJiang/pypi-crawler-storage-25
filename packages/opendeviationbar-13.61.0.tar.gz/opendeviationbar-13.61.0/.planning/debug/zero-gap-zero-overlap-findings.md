# Zero-Gap Zero-Overlap Findings (2026-03-21)

## Bug 1: committed_floors initialization (WLDUSDT 4-trade gap)

**Location**: `crates/opendeviationbar-streaming/src/live_engine.rs:1379`
**Root cause**: `committed_floors` set from `processor.last_agg_trade_id()` which returns forming bar tail, not last completed bar.
**Fix**: Track `last_completed_bar_tid` separately or use CH seed for floor.
**Evidence**: WLDUSDT@250 bar [113843149, 113843152] suppressed because 113843152 <= floor 113843341 (forming bar tail).

## Bug 2: Midnight boundary multi-processor seam (17 gaps)

**Root cause**: Kintsugi repairs yesterday with fresh processor, sidecar streams today with different processor. No trade-ID handoff anchor.
**Evidence**: BTCUSDT gap of 6,680 trades between kintsugi's 23:59:59 orphan and sidecar's 00:16:27 first bar.
**Key insight**: `maybe_reset_at_midnight()` is gap-free within a single processor. BTCUSDT/ETHUSDT (streamed) have ZERO midnight gaps.

## User's Solution Architecture

**Preflight verification**: Use Binance REST API `startTime=midnight_ms&limit=1` to get the exact midnight crossover trade ID. Verify yesterday's orphan bar `last_agg_trade_id` matches this. If not, yesterday is incomplete — defer or repair.

**Sidecar anchoring**: `fill_from_rest` anchors from the verified yesterday crossover trade ID, not from CH seed. This ensures today's first trade continues exactly from yesterday's last trade.

## Phases (proposed)

1. **Rust fix**: committed_floors uses last completed bar, not forming bar tail
2. **Midnight preflight**: REST API crossover verification + yesterday completion check
3. **Sidecar anchoring**: fill_from_rest anchors from verified crossover trade ID
4. **Heartbeat overhaul**: per-symbol continuity, yesterday completion, junction telemetry, regression alerts
