---
phase: 01
slug: mutation-safety
status: draft
nyquist_compliant: true
wave_0_complete: true
created: 2026-03-24
---

# Phase 01 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property               | Value                                                   |
| ---------------------- | ------------------------------------------------------- |
| **Framework**          | pytest 7.x + cargo nextest                              |
| **Config file**        | `pyproject.toml` / `Cargo.toml`                         |
| **Quick run command**  | `mise run test-py -- -k "overlap_strategy or kintsugi"` |
| **Full suite command** | `mise run check-full`                                   |
| **Estimated runtime**  | ~60 seconds                                             |

---

## Sampling Rate

- **After every task commit:** Run `mise run test-py -- -k "overlap_strategy or kintsugi"`
- **After every plan wave:** Run `mise run check-full`
- **Before `/gsd:verify-work`:** Full suite must be green
- **Max feedback latency:** 60 seconds

---

## Per-Task Verification Map

| Task ID  | Plan | Wave | Requirement    | Test Type   | Automated Command                                                                                | File Exists | Status     |
| -------- | ---- | ---- | -------------- | ----------- | ------------------------------------------------------------------------------------------------ | ----------- | ---------- |
| 01-01-01 | 01   | 1    | MUT-01, MUT-02 | unit + grep | `uv run --python 3.13 pytest tests/test_mutation_safety.py -x -v`                                | ✅          | ⬜ pending |
| 01-01-02 | 01   | 1    | MUT-01         | grep        | `grep -r "DELETE IN PARTITION" python/opendeviationbar/sidecar/__init__.py`                      | ✅          | ⬜ pending |
| 01-02-01 | 02   | 1    | MUT-01         | grep        | `grep -r "DELETE IN PARTITION" python/opendeviationbar/rectify.py scripts/`                      | ✅          | ⬜ pending |
| 01-02-02 | 02   | 1    | MUT-01         | grep        | `grep -rn "ALTER TABLE.*open_deviation_bars.*DELETE" python/ scripts/ \| grep -v "IN PARTITION"` | ✅          | ⬜ pending |

_Status: ⬜ pending · ✅ green · ❌ red · ⚠️ flaky_

---

## Wave 0 Requirements

Existing infrastructure covers all phase requirements. No new test files needed beyond `tests/test_mutation_safety.py` (created in Plan 01 Task 1). Validation is via pytest (MUT-02 lock concurrency) and grep (MUT-01 DELETE audit).

---

## Manual-Only Verifications

| Behavior                                     | Requirement | Why Manual                                       | Test Instructions                                                                                                                                                   |
| -------------------------------------------- | ----------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 24-worker kintsugi pass without 300s timeout | MUT-02      | Requires production ClickHouse + real shard data | SSH to bigblack, run `mise run kintsugi:catchup`, query `SELECT * FROM system.mutations WHERE database='opendeviationbar_cache' ORDER BY create_time DESC LIMIT 50` |

---

## Validation Sign-Off

- [x] All tasks have `<automated>` verify or Wave 0 dependencies
- [x] Sampling continuity: no 3 consecutive tasks without automated verify
- [x] Wave 0 covers all MISSING references
- [x] No watch-mode flags
- [x] Feedback latency < 60s
- [x] `nyquist_compliant: true` set in frontmatter

**Approval:** pending
