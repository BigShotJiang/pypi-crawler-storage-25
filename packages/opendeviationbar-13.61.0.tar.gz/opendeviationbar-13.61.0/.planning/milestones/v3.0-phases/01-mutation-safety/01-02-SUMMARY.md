---
phase: 01-mutation-safety
plan: 02
subsystem: database
tags: [clickhouse, delete-in-partition, mutation-safety, kintsugi]

requires:
  - phase: 01-mutation-safety/01
    provides: per-partition lock and _do_replace() migration in maintenance.py
provides:
  - "All open_deviation_bars DELETE call sites use DELETE IN PARTITION"
  - "kintsugi_log exception documented (no PARTITION BY clause)"
  - "All DELETEs include SETTINGS mutations_sync = 1"
affects: [02-sidecar-fill-pipeline, kintsugi, sidecar]

tech-stack:
  added: []
  patterns:
    [
      "DELETE IN PARTITION ('{symbol}', {threshold}) with mutations_sync=1",
      "query-then-loop for symbol-only DELETEs",
    ]

key-files:
  created: []
  modified:
    - python/opendeviationbar/rectify.py
    - python/opendeviationbar/kintsugi/discovery.py
    - scripts/cache_clear.py
    - scripts/validate_dedup_hardening.py
    - scripts/validate_microstructure_roundtrip.py
    - scripts/cleanup_oversized_bars.py
    - scripts/purge_crypto_low_threshold.py
    - scripts/cleanup_extra_symbols.py
    - scripts/validate_kintsugi_fixes.py

key-decisions:
  - "Symbol-only DELETEs (cache_clear.py) query distinct thresholds first, then loop DELETE IN PARTITION per partition"
  - "cleanup_oversized_bars.py queries affected (symbol, threshold) pairs before DELETE loop"
  - "kintsugi_log DELETEs remain ALTER TABLE DELETE -- table has no PARTITION BY clause (documented exception)"

patterns-established:
  - "DELETE IN PARTITION pattern: f-string for partition tuple, parameterized WHERE, always mutations_sync=1"
  - "Query-then-loop pattern for symbol-only DELETEs without known threshold"

requirements-completed: [MUT-01]

duration: 2min
completed: 2026-03-24
---

# Phase 01 Plan 02: DELETE IN PARTITION Migration Summary

**Migrated all remaining open_deviation_bars DELETE call sites to partition-scoped DELETE IN PARTITION across 8 files, with kintsugi_log exception documented**

## Performance

- **Duration:** 2 min
- **Started:** 2026-03-24T19:16:14Z
- **Completed:** 2026-03-24T19:19:01Z
- **Tasks:** 2
- **Files modified:** 9

## Accomplishments

- Zero unscoped ALTER TABLE DELETE on open_deviation_bars anywhere in the codebase
- All kintsugi_log exception sites (discovery.py, validate_kintsugi_fixes.py) documented with comments explaining no PARTITION BY
- All DELETEs include SETTINGS mutations_sync = 1
- MUT-01 fully satisfied across entire codebase

## Task Commits

Each task was committed atomically:

1. **Task 1: Migrate rectify.py and kintsugi/discovery.py** - `b6641c0` (feat)
2. **Task 2: Migrate 6 scripts to DELETE IN PARTITION** - `a34f035` (feat)

## Files Created/Modified

- `python/opendeviationbar/rectify.py` - Ghost bar DELETE now uses DELETE IN PARTITION
- `python/opendeviationbar/kintsugi/discovery.py` - kintsugi_log exception documented, mutations_sync=1 added
- `scripts/cache_clear.py` - Query thresholds per symbol, loop DELETE IN PARTITION
- `scripts/validate_dedup_hardening.py` - Use test threshold 99999 in DELETE IN PARTITION
- `scripts/validate_microstructure_roundtrip.py` - Use test threshold 250 in DELETE IN PARTITION
- `scripts/cleanup_oversized_bars.py` - Query affected partitions, loop DELETE IN PARTITION
- `scripts/purge_crypto_low_threshold.py` - Use existing symbol+threshold in DELETE IN PARTITION
- `scripts/cleanup_extra_symbols.py` - Use existing symbol+threshold in DELETE IN PARTITION
- `scripts/validate_kintsugi_fixes.py` - Document kintsugi_log exception, add mutations_sync=1

## Decisions Made

- Symbol-only DELETEs (cache_clear.py) query distinct thresholds from the table first, then loop. This avoids system.parts queries.
- cleanup_oversized_bars.py queries affected (symbol, threshold) pairs dynamically since both parameters are optional.
- kintsugi_log DELETEs remain as ALTER TABLE DELETE because the table has no PARTITION BY clause -- this is a documented intentional exception.

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- MUT-01 complete: all open_deviation_bars DELETE sites use DELETE IN PARTITION
- Combined with Plan 01 (per-partition lock), Phase 01 Mutation Safety is fully complete
- Ready for Phase 02 (Sidecar Fill Pipeline) or production verification on bigblack

## Self-Check: PASSED

All 9 modified files exist. Both task commits (b6641c0, a34f035) verified in git log.

---

_Phase: 01-mutation-safety_
_Completed: 2026-03-24_
