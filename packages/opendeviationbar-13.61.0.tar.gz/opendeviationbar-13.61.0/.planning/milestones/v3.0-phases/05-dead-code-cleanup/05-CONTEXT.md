# Phase 5: Dead Code Cleanup - Context

**Gathered:** 2026-03-24
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — smart discuss skipped)

<domain>
## Phase Boundary

Remove 37 stale scripts and 800+ LOC dead Python code identified in the adversarial audit (#298). Every removal verified unreachable before deletion. `mise run check-full` passes after all removals.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase. Use ROADMAP phase goal, success criteria, and codebase conventions to guide decisions.

Key constraints:

- Every removal must be verified unreachable before deletion (no import references, no dynamic loading, no CLI entry points)
- `mise run check-full` must pass after all removals (no broken imports, no test failures)
- Adversarial audit (#298) is the source of truth for what to remove

</decisions>

<canonical_refs>

## Canonical References

**Downstream agents MUST read these before planning or implementing.**

### Audit source

- GitHub Issue #298 — adversarial audit identifying stale scripts and dead code

### Project structure

- `scripts/CLAUDE.md` — scripts directory documentation
- `python/opendeviationbar/CLAUDE.md` — Python layer file-to-responsibility mapping

</canonical_refs>

<code_context>

## Existing Code Insights

### Integration Points

- `scripts/` directory — 37 stale scripts to remove
- Various Python modules — 800+ LOC dead code to remove
- `mise.toml` — task definitions may reference removed scripts
- `pyproject.toml` — entry points may reference removed code

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase.

</specifics>

<deferred>
## Deferred Ideas

None — infrastructure phase.

</deferred>

---

_Phase: 05-dead-code-cleanup_
_Context gathered: 2026-03-24_
