---
phase: 05-dead-code-cleanup
plan: 02
subsystem: infra
tags: [rust, dead-code, cargo, streaming, todo-cleanup]

requires:
  - phase: none
    provides: standalone cleanup plan
provides:
  - "Removed ~1094 LOC dead Rust modules (indicators.rs, stats.rs) from streaming crate"
  - "Removed unused workspace dependencies (rolling-stats, tdigests)"
  - "Cleaned stale TODOs referencing closed issues #59 and #197"
affects: []

tech-stack:
  added: []
  patterns: []

key-files:
  created: []
  modified:
    - crates/opendeviationbar-streaming/src/lib.rs
    - crates/opendeviationbar-streaming/Cargo.toml
    - Cargo.toml
    - python/opendeviationbar/orchestration/helpers.py
    - crates/opendeviationbar-core/src/normalization_lut.rs

key-decisions:
  - "Kept CLI crate deps (polars, batch, streaming) since bins are disabled but preserved as reference code"
  - "Kept WsControlRateLimiter #[allow(dead_code)] since it is intentionally pre-built for Phase 4 (WS combined streams)"
  - "Kept serde_json in core [dependencies] since doc examples compile against main deps, not dev-deps"

patterns-established: []

requirements-completed: [CLEAN-02, CLEAN-03]

duration: 5min
completed: 2026-03-24
---

# Phase 5 Plan 2: Dead Rust Code and Stale TODO Cleanup Summary

**Removed ~1094 LOC dead streaming modules (indicators, stats), unused workspace deps (rolling-stats, tdigests), and stale TODOs referencing closed issues #59/#197**

## Performance

- **Duration:** 5 min
- **Started:** 2026-03-24T21:11:32Z
- **Completed:** 2026-03-24T21:16:37Z
- **Tasks:** 2
- **Files modified:** 7 (5 modified, 2 deleted)

## Accomplishments

- Removed indicators.rs (~460 LOC: SMA, EMA, MACD, RSI, CCI) and stats.rs (~600 LOC: StreamingStatsEngine) from streaming crate -- verified no external references
- Removed stats/indicators feature gates and rolling-stats/tdigests workspace dependencies
- Cleaned TODO(Issue #59) and TODO Task #197 from Python and Rust code after confirming both issues are closed

## Task Commits

Each task was committed atomically:

1. **Task 1: Remove dead Rust code and unused dependencies** - `1b8ab7a` (refactor)
2. **Task 2: Clean stale TODOs and minor Python dead code** - `d6ecda8` (chore)

## Files Created/Modified

- `crates/opendeviationbar-streaming/src/indicators.rs` - Deleted (dead SMA/EMA/MACD/RSI/CCI indicators)
- `crates/opendeviationbar-streaming/src/stats.rs` - Deleted (dead StreamingStatsEngine)
- `crates/opendeviationbar-streaming/src/lib.rs` - Removed pub mod/use for indicators and stats
- `crates/opendeviationbar-streaming/Cargo.toml` - Removed stats/indicators features and deps
- `Cargo.toml` - Removed rolling-stats and tdigests from workspace dependencies
- `python/opendeviationbar/orchestration/helpers.py` - Removed TODO(Issue #59) stale reference
- `crates/opendeviationbar-core/src/normalization_lut.rs` - Removed TODO Task #197 stale references

## Decisions Made

- Kept CLI crate dependencies (polars, opendeviationbar-batch, opendeviationbar-streaming) despite being unused at compile time -- bins are disabled but preserved as reference code, removing deps would break source if re-enabled
- Kept `#[allow(dead_code)]` on WsControlRateLimiter -- intentionally pre-built for Phase 4 (WS-01/02/03 combined streams)
- Kept serde_json in opendeviationbar-core [dependencies] -- used in doc examples which compile against main deps
- Confirmed sidecar.py `env_settings` parameter is NOT dead code -- required by pydantic-settings protocol signature

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 2 - Missing] Also removed workspace-level rolling-stats/tdigests dependencies**

- **Found during:** Task 1
- **Issue:** Plan mentioned removing deps from crate Cargo.toml but not workspace root
- **Fix:** Removed rolling-stats and tdigests from workspace [workspace.dependencies] since no other crate uses them
- **Files modified:** Cargo.toml (workspace root)
- **Verification:** cargo check --workspace passes
- **Committed in:** 1b8ab7a (Task 1 commit)

---

**Total deviations:** 1 auto-fixed (1 missing critical)
**Impact on plan:** Necessary to complete the dep cleanup. No scope creep.

## Issues Encountered

None

## Known Stubs

None

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Dead Rust code removed, workspace compiles cleanly
- Plan 05-01 (stale scripts removal) can proceed independently

---

_Phase: 05-dead-code-cleanup_
_Completed: 2026-03-24_
