---
phase: 05-dead-code-cleanup
plan: "01"
subsystem: scripts
tags: [cleanup, dead-code, research, benchmarks]

# Dependency graph
requires: []
provides:
  - "79 stale scripts removed from scripts/ directory"
  - "35,476 LOC dead code eliminated"
  - "Research doc references updated to note removals"
affects: []

# Tech tracking
tech-stack:
  added: []
  patterns:
    - "Research conclusions preserved in docs/research/ when scripts removed"

key-files:
  created: []
  modified:
    - docs/research/adversarial-audit-methodology.md
    - docs/research/pattern-research-summary.md
    - docs/analysis/2025-10-10-flash-crash.md

key-decisions:
  - "Keep validate/verify scripts -- referenced in CLAUDE.md docs and useful for ongoing maintenance"
  - "Keep Exness download/process/upload scripts -- referenced in research docs as historical pipeline"
  - "Keep run_length_momentum_{multi_symbol,wfo}.py -- still in mise research tasks"
  - "Remove all invalidated pattern research scripts -- conclusions preserved in docs/research/"

patterns-established:
  - "Cross-reference audit before deletion: mise tasks, systemd units, CLAUDE.md, Python imports"

requirements-completed: [CLEAN-01, CLEAN-03]

# Metrics
duration: 8min
completed: 2026-03-24
---

# Phase 5 Plan 1: Remove Stale Scripts Summary

**79 stale scripts removed (35,476 LOC) -- research patterns, one-off benchmarks, superseded maintenance -- verified unreachable via cross-reference audit against mise tasks, systemd units, and Python imports**

## Performance

- **Duration:** 8 min
- **Started:** 2026-03-24T21:13:40Z
- **Completed:** 2026-03-24T21:22:00Z
- **Tasks:** 3
- **Files modified:** 82 (79 deleted, 3 docs updated)

## Accomplishments

- Removed 70 invalidated research pattern scripts (34,003 LOC) -- TDA, regime analysis, pattern correlation, Hurst research, multi-factor, duration analysis, position sizing
- Removed 9 stale benchmark and one-off scripts (1,473 LOC)
- Updated 3 research/analysis docs to note script removals while preserving historical references
- Scripts directory reduced from 126 to 47 Python files (63% reduction)

## Task Commits

Each task was committed atomically:

1. **Task 1: Remove invalidated research pattern scripts** - `6f76725` (chore)
2. **Task 2: Remove stale benchmark and one-off scripts** - `dc7897a` (chore)
3. **Task 3: Update docs and verify no broken references** - `467bcaf` (docs)

## Files Created/Modified

- 70 research scripts deleted (see commit 6f76725 for full list)
- 9 benchmark/one-off scripts deleted (see commit dc7897a for full list)
- `docs/research/adversarial-audit-methodology.md` - Note scripts removed
- `docs/research/pattern-research-summary.md` - Mark script tables as removed
- `docs/analysis/2025-10-10-flash-crash.md` - Note analyze_flash_crash.py removed

## Decisions Made

- **Kept all validate/verify scripts** -- referenced in CLAUDE.md docs and mise tasks; useful for ongoing maintenance and verification
- **Kept Exness pipeline scripts** (download_exness_eurusd.py, process_exness_eurusd_to_cache.py, upload_eurusd_to_clickhouse.py) -- still referenced in research docs as historical pipeline
- **Kept run*length_momentum*{multi_symbol,wfo}.py** -- still referenced in mise research.toml tasks
- **CLEAN-02 partially addressed** -- 35K LOC of scripts removed; remaining dead Python package code (if any) to be addressed in future plan

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None.

## User Setup Required

None - no external service configuration required.

## Known Stubs

None.

## Next Phase Readiness

- CLEAN-01 (37 stale scripts) exceeded: 79 scripts removed
- CLEAN-03 (verified unreachable) complete: cross-reference audit against mise, systemd, CLAUDE.md, Python imports
- CLEAN-02 (800+ LOC dead Python code in subsystems) partially addressed by script removals; may need a follow-up plan for dead code within the Python package itself

---

_Phase: 05-dead-code-cleanup_
_Completed: 2026-03-24_
