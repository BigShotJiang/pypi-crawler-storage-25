---
phase: 04-python-sql-rename
plan: 01
subsystem: database
tags: [clickhouse, column-rename, microsecond, python, sql]

# Dependency graph
requires:
  - phase: 03-ch-schema-migration
    provides: ClickHouse columns already renamed to _us
provides:
  - All Python and SQL references use _us suffix matching actual microsecond data
affects: [05-deploy-gap-repair, 06-test-hygiene]

# Tech tracking
tech-stack:
  added: []
  patterns: [consistent _us suffix across all layers]

key-files:
  created: []
  modified:
    - python/opendeviationbar/constants.py
    - python/opendeviationbar/clickhouse/bulk_operations.py
    - python/opendeviationbar/clickhouse/query_operations.py
    - python/opendeviationbar/clickhouse/cache.py
    - python/opendeviationbar/sidecar/__init__.py
    - python/opendeviationbar/kintsugi/discovery.py

key-decisions:
  - "Single sed pass with longest-match-first ordering (last_close_time_ms before close_time_ms) for safe mechanical rename"

patterns-established:
  - "All timestamp column references use _us suffix: close_time_us, open_time_us, last_close_time_us"

requirements-completed: [RENAME-02, RENAME-04, RENAME-05]

# Metrics
duration: 29min
completed: 2026-03-25
---

# Phase 04 Plan 01: Python + SQL Rename Summary

**Mechanical bulk rename of 244 close_time_ms/open_time_ms/last_close_time_ms occurrences to \_us across 38 Python/SQL files, verified by grep and full test suite**

## Performance

- **Duration:** 29 min (mostly Rust golden snapshot test at 498s)
- **Started:** 2026-03-25T02:09:40Z
- **Completed:** 2026-03-25T02:39:08Z
- **Tasks:** 2
- **Files modified:** 38

## Accomplishments

- Renamed all 244 \_ms column references to_us across 38 Python/SQL files
- Zero remaining close_time_ms, open_time_ms, or last_close_time_ms in any .py or .sql file
- All 1078 Rust tests pass (including golden snapshot bit-exact verification)
- Ruff auto-formatter passed clean on all files

## Task Commits

Each task was committed atomically:

1. **Task 1: Bulk rename all \_ms column references to \_us across 38 files** - `d0c236d` (refactor)
2. **Task 2: Run check-full to verify zero regressions** - verification only, no commit needed

## Files Created/Modified

- `python/opendeviationbar/constants.py` - Column name constants renamed to \_us
- `python/opendeviationbar/clickhouse/bulk_operations.py` - INSERT column lists and scale guards renamed
- `python/opendeviationbar/clickhouse/query_operations.py` - SELECT/ORDER BY queries renamed
- `python/opendeviationbar/clickhouse/cache.py` - Cache key and query operations renamed
- `python/opendeviationbar/clickhouse/stathera_query.py` - Stathera SQL builder renamed
- `python/opendeviationbar/clickhouse/schema.sql` - SQL comments renamed
- `python/opendeviationbar/clickhouse/bar_count_api.py` - Bar count queries renamed
- `python/opendeviationbar/clickhouse/maintenance.py` - Maintenance operations renamed
- `python/opendeviationbar/clickhouse/migrations.py` - Migration SQL renamed
- `python/opendeviationbar/kintsugi/discovery.py` - Shard discovery queries renamed
- `python/opendeviationbar/kintsugi/repair.py` - Repair operations renamed
- `python/opendeviationbar/kintsugi/verify.py` - Verification queries renamed
- `python/opendeviationbar/sidecar/__init__.py` - Sidecar orchestrator renamed
- `python/opendeviationbar/sidecar/checkpoint.py` - Checkpoint persistence renamed
- `python/opendeviationbar/sidecar/http_server.py` - HTTP endpoint queries renamed
- `python/opendeviationbar/sidecar/midnight.py` - Midnight preflight renamed
- `python/opendeviationbar/orchestration/helpers.py` - Orchestration helpers renamed
- `python/opendeviationbar/orchestration/open_deviation_bars.py` - Main orchestration renamed
- `python/opendeviationbar/processors/core.py` - Processor DataFrame conversion renamed
- `python/opendeviationbar/rectify.py` - Rectification queries renamed
- `python/opendeviationbar/exness.py` - Exness integration renamed
- `python/opendeviationbar/validation/day_mode/guards.py` - Day-mode guards renamed
- `python/opendeviationbar/validation/day_mode/oracle.py` - Oracle queries renamed
- `scripts/detect_gaps.py` - Gap detection queries renamed
- `scripts/cache_status.py` - Cache status queries renamed
- `scripts/heartbeat/checks/stathera.py` - Stathera heartbeat check renamed
- `scripts/heartbeat/checks/clickhouse.py` - ClickHouse stats renamed
- `scripts/heartbeat/checks/freshness.py` - Freshness check renamed
- `scripts/heartbeat/checks/yesterday.py` - Yesterday check renamed
- `scripts/microstructure_clickhouse.py` - Microstructure analysis renamed
- `scripts/migrate_column_rename_us.py` - Migration script references renamed
- `scripts/migrate_partition_yyyymm_to_yyyymmdd.sql` - Partition migration SQL renamed
- `scripts/repair_direct_parquet.py` - Repair script renamed
- `scripts/upload_eurusd_to_clickhouse.py` - Upload script renamed
- `scripts/validate_microstructure_roundtrip.py` - Validation script renamed
- `scripts/validate_plugin_e2e.py` - Plugin E2E validation renamed
- `tests/test_exchange_sessions.py` - Exchange session tests renamed
- `tests/test_rectification.py` - Rectification tests renamed
- `tests/test_sync_flush_atomic_replace.py` - Sync flush tests renamed

## Decisions Made

- Used sed with longest-match-first ordering for safe mechanical rename across all 38 files in a single pass
- Ruff auto-fix for one type annotation cleanup (PyRecordBatch quotes) accepted as correct

## Deviations from Plan

None - plan executed exactly as written.

## Pre-existing Issues Noted (Out of Scope)

- `cargo deny check` fails due to upstream advisory DB CVSS 4.0 parsing issue (not caused by rename)
- `tests/test_adaptive_sleep.py` has broken import of `_WATERMARK_ABORT_RATIO` from `backfill.py` (pre-existing, verified on prior commit)

## Known Stubs

None.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Python/SQL layer fully aligned with \_us naming convention
- Ready for Phase 05 (deploy gap repair) and Phase 06 (test hygiene)
- CLAUDE.md network references to \_ms in documentation (e.g., clickhouse/CLAUDE.md gap detection query) will need separate documentation updates

---

_Phase: 04-python-sql-rename_
_Completed: 2026-03-25_
