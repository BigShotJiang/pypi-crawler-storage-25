# Phase 4: Python + SQL Rename - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase)

<domain>
## Phase Boundary

Bulk rename all `close_time_ms`/`open_time_ms` references to `close_time_us`/`open_time_us` across ~232 Python files and ~60 SQL query strings. After this phase, `mise run check-full` must pass with zero regressions.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Key constraints:

- Phase 2 already changed Rust dict export keys to `_us`
- Phase 3 updated schema.sql and \_ensure_schema() DDL
- This phase handles ALL remaining Python + SQL references
- Constants, column name lists, query strings, DataFrame column access, test fixtures
- `TRADE_ID_RANGE_COLUMNS` and similar constants may reference these
- Sidecar, kintsugi, heartbeat, backfill, validation, orchestration all affected
- `mise run check-full` (fmt + lint + test) MUST pass after all changes
- Use `replace_all` on Edit tool where safe for mechanical renames

</decisions>

<canonical_refs>

## Canonical References

- `python/opendeviationbar/clickhouse/constants.py` — column name constants
- `python/opendeviationbar/clickhouse/bulk_operations.py` — INSERT column lists
- `python/opendeviationbar/clickhouse/query_operations.py` — SELECT queries
- `python/opendeviationbar/clickhouse/stathera_query.py` — Stathera SQL builder
- `python/opendeviationbar/clickhouse/maintenance.py` — DELETE queries
- `python/opendeviationbar/sidecar/` — streaming pipeline references
- `scripts/heartbeat/` — health check queries
- `tests/` — test fixtures and assertions
  </canonical_refs>

<code_context>

## Existing Code Insights

- This is a mechanical find-and-replace across the codebase
- The rename is safe because Phase 2 already changed the source (Rust export)
- Python tests will fail until the column names match the new Rust output
- SQL queries will fail until they match the new CH column names (Phase 3)
  </code_context>

<specifics>
No specific requirements.
</specifics>

<deferred>
None.
</deferred>

---

_Phase: 04-python-sql-rename_
_Context gathered: 2026-03-25_
