# Phase 3: Kintsugi Parquet Trust - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase)

<domain>
## Phase Boundary

Before using a Parquet file for day-recompute, kintsugi verifies `max(agg_trade_id) >= crossover_tid - 1` using the shared crossover utility. Falls back to Vision/REST if Parquet is incomplete. Also fix orphan bar `is_orphan=True` flag for Parquet/Vision paths.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Key facts:

- Kintsugi repair paths: `_try_parquet_day_replace()`, `_try_vision_day_replace()`, REST fallback
- Parquet path uses `include_incomplete=True` + `get_incomplete_bar()` — does NOT set `is_orphan=True`
- Vision path: same pattern
- REST path uses `reset_at_ouroboros()` — correctly sets `is_orphan=True`
- Fix: after `get_incomplete_bar()`, set `is_orphan=True` on the resulting bar dict
- Completeness check: before processing Parquet, read max TID and compare against `get_crossover_tid(symbol, date + 1 day)` — the crossover for the NEXT day gives the boundary for the current day
- If incomplete, log warning and return failure so kintsugi falls back to Vision/REST

</decisions>

<canonical_refs>

## Canonical References

- `python/opendeviationbar/kintsugi/repair.py` — `_try_parquet_day_replace()` (line ~412), `_try_vision_day_replace()` (line ~517)
- `python/opendeviationbar/crossover.py` — shared `get_crossover_tid()` (Phase 1)
- `python/opendeviationbar/orchestration/pipeline.py` — `_stream_bars_with_processor()` (include_incomplete handling)
  </canonical_refs>

<code_context>

## Existing Code Insights

- `get_incomplete_bar()` returns a dict but doesn't set `is_orphan` key
- The Parquet completeness check needs `get_crossover_tid(symbol, next_day)` to know what the LAST trade of the current day should be
- For "today" there IS no next-day crossover yet — kintsugi only repairs yesterday+older, so this is always available
  </code_context>

<specifics>
No specific requirements.
</specifics>

<deferred>
None.
</deferred>

---

_Phase: 03-kintsugi-parquet-trust_
_Context gathered: 2026-03-25_
