# Phase 5: Documentation - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase)

<domain>
## Phase Boundary

Update CLAUDE.md network files to document the root cause (seeder day-boundary gap), the fixes (Phases 1-4), and the architectural decisions. Four CLAUDE.md files need updates: scripts/, kintsugi/, heartbeat/, and root.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Files to update:

- `scripts/CLAUDE.md` — document seeder day-boundary backfill, `_backfill_yesterday_boundary()`, state markers
- `python/opendeviationbar/kintsugi/CLAUDE.md` — document Parquet trust gate, `is_orphan` fix, crossover verification
- `scripts/heartbeat/CLAUDE.md` — document dynamic symbol list, removal of hardcoded `HEARTBEAT_PRIORITY_SYMBOLS`
- `CLAUDE.md` (root) — update terminology for crossover utility, update key subsystems table

Also update:

- `python/opendeviationbar/CLAUDE.md` — add `crossover.py` to the module map

</decisions>

<canonical_refs>

## Canonical References

- `CLAUDE.md` — root hub
- `scripts/CLAUDE.md` — scripts spoke
- `python/opendeviationbar/kintsugi/CLAUDE.md` — kintsugi spoke
- `scripts/heartbeat/CLAUDE.md` — heartbeat spoke
- `python/opendeviationbar/CLAUDE.md` — Python layer spoke
  </canonical_refs>

<code_context>

## Existing Code Insights

- CLAUDE.md files follow hub-and-spoke pattern
- Each spoke is SSoT for its directory
- Changes from Phases 1-4 need to be reflected in the documentation
  </code_context>

<specifics>
No specific requirements.
</specifics>

<deferred>
None.
</deferred>

---

_Phase: 05-documentation_
_Context gathered: 2026-03-25_
