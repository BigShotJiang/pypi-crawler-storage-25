---
phase: 01-dedup-floor-fix
plan: 02
subsystem: streaming-engine
tags: [rust, live-engine, pyo3, committed-floors, dedup, checkpoint]

# Dependency graph
requires:
  - phase: 01-dedup-floor-fix plan 01
    provides: "last_completed_bar_tid field and accessor on OpenDeviationBarProcessor"
provides:
  - "committed_floors uses last_completed_bar_tid instead of last_agg_trade_id (THE fix)"
  - "PyO3 binding for last_completed_bar_tid() accessible from Python"
  - "checkpoint dict round-trip for last_completed_bar_tid"
affects: [sidecar, heartbeat-telemetry, midnight-preflight]

# Tech tracking
tech-stack:
  added: []
  patterns: ["completed bar tid for dedup floor instead of forming bar tail"]

key-files:
  created: []
  modified:
    - "crates/opendeviationbar-streaming/src/live_engine.rs"
    - "src/core_bindings.rs"
    - "src/helpers.rs"

key-decisions:
  - "committed_floors reads last_completed_bar_tid (not last_agg_trade_id) to avoid suppressing junction bars"
  - "Old checkpoints without last_completed_bar_tid default to None (backward compatible)"

patterns-established:
  - "v1.4 annotation in tracing logs for dedup floor changes"

requirements-completed: [RUST-01, RUST-02]

# Metrics
duration: 7min
completed: 2026-03-21
---

# Phase 01 Plan 02: Wire last_completed_bar_tid into committed_floors and PyO3 Bindings Summary

**Fixed committed_floors dedup floor to use last_completed_bar_tid instead of last_agg_trade_id, eliminating junction bar suppression at REST-to-WS transition**

## Performance

- **Duration:** 7 min
- **Started:** 2026-03-21T06:49:12Z
- **Completed:** 2026-03-21T06:56:00Z
- **Tasks:** 2
- **Files modified:** 3

## Accomplishments

- Fixed THE root cause: committed_floors in live_engine.rs now reads from last_completed_bar_tid() instead of last_agg_trade_id(), preventing dedup floor from being set too high by forming bar tail trades
- Added PyO3 binding for last_completed_bar_tid() on PyOpenDeviationBarProcessor, accessible from Python via_core module
- Added checkpoint dict serialization/deserialization for last_completed_bar_tid with backward-compatible None default
- Full Rust test suite: 1077/1077 passed, 2 skipped
- Python test suite: 233+ tests passed across core, binding, checkpoint, streaming, and edge case modules

## Task Commits

Each task was committed atomically:

1. **Task 1: Wire last_completed_bar_tid into committed_floors and add bindings** - `416b0c6` (fix)
2. **Task 2: Full regression -- cargo nextest + pytest** - verification only, no commit needed

## Files Created/Modified

- `crates/opendeviationbar-streaming/src/live_engine.rs` - ONE line fix: committed_floors init from last_completed_bar_tid(), updated comments with v1.4 annotation, updated tracing log field name
- `src/core_bindings.rs` - PyO3 method `last_completed_bar_tid()` on PyOpenDeviationBarProcessor
- `src/helpers.rs` - checkpoint_to_dict() serializes last_completed_bar_tid, dict_to_checkpoint() deserializes with None default

## Decisions Made

- committed_floors reads last_completed_bar_tid (not last_agg_trade_id) to produce a LOWER floor that is PERMISSIVE -- allows junction bars through instead of suppressing them
- Old checkpoints without last_completed_bar_tid default to None (backward compatible with existing production checkpoints)

## Deviations from Plan

None - plan executed exactly as written. Task 1 changes were already committed from a prior execution attempt.

## Issues Encountered

- Full pytest suite exceeds available memory when run in a single process (signal 9 / OOM kill). Verified by running test files in batches: all pass. Not caused by this change.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- RUST-01 (floor reads from completed bar) and RUST-02 (no bars suppressed at junction) are satisfied
- Ready for Phase 02 (midnight preflight verification) which depends on correct dedup behavior
- Production deployment: maturin develop --release already built; deploy to bigblack when ready

---

_Phase: 01-dedup-floor-fix_
_Completed: 2026-03-21_
