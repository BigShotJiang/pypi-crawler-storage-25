# Phase 3: Sub-Minute Startup Validation - Context

**Gathered:** 2026-03-23
**Status:** Ready for planning
**Mode:** From session discussion (milestone v1.5 planning)

<domain>
## Phase Boundary

Deploy Phase 1+2 changes to bigblack via hotfix path, measure end-to-end startup time, verify < 60s from systemctl start to first WS trade processed.

Requirements: STARTUP-04

</domain>

<decisions>
## Implementation Decisions

### Deployment

**Decision:** Use /odb-ship hotfix path (Python-only, no Rust rebuild needed):

1. git sync on bigblack
2. rsync Python files to site-packages
3. Restart sidecar + kintsugi with standard orchestration

### Timing Measurement

**Decision:** Measure startup time by parsing sidecar journal logs:

- Start timestamp: systemd `Started` log line
- End timestamp: first `sync_flush: drained and wrote` or first WS trade log line
- Calculate delta, must be < 60s

### Yesterday Clean Path Verification

**Decision:** After deploy, verify:

1. Sidecar logs show "yesterday clean, skipping repair" (if yesterday is actually clean)
2. OR sidecar logs show "writing yesterday repair signal for N symbols" + kintsugi picks it up
3. No `_repair_yesterday_if_needed` anywhere in the startup logs

### Dead Code Cleanup

**Decision:** Remove `_repair_yesterday_if_needed()` function body from midnight.py entirely (was kept as dead code in Phase 1).

### Claude's Discretion

- Whether to add startup timing to heartbeat telemetry
- Exact log parsing approach for timing measurement

</decisions>

<code_context>

## Existing Code Insights

- Hotfix path documented in odb-ship SKILL.md
- sidecar/midnight.py has \_repair_yesterday_if_needed (dead code to remove)
- sidecar/**init**.py already calls \_check_yesterday_integrity (Phase 1 wiring)
- kintsugi/orchestrator.py already has \_load_yesterday_priority_shards (Phase 2 wiring)

</code_context>

<specifics>
## Specific Ideas

- Push all changes first, then do a single sidecar restart and time it
- Check the heartbeat after 2 cycles to confirm healthy

</specifics>

<deferred>
## Deferred Ideas

None.

</deferred>
