---
phase: 03-rust-hot-path
plan: 02
subsystem: streaming
tags: [rust, websocket, allocation, hot-path, vec-reuse]

requires:
  - phase: none
    provides: n/a
provides:
  - "Zero per-iteration heap allocation in WS select loop burst frame"
affects: []

tech-stack:
  added: []
  patterns: ["Vec::clear() reuse pattern for hot-path allocation elimination"]

key-files:
  created: []
  modified:
    - crates/opendeviationbar-streaming/src/live_engine.rs

key-decisions:
  - "Reuse Vec via clear() instead of drop+realloc — O(1) reset for Copy types like AggTrade"

patterns-established:
  - "Hot-path allocation reuse: declare mutable containers outside loop, clear() inside"

requirements-completed: [RUST-03]

duration: 1min
completed: 2026-03-20
---

# Phase 3 Plan 2: Burst Frame Vec Reuse Summary

**Eliminate per-iteration Vec::with_capacity(32) allocation in WS select loop via clear()+reuse pattern (RUST-03)**

## Performance

- **Duration:** 55 seconds
- **Started:** 2026-03-20T08:41:51Z
- **Completed:** 2026-03-20T08:42:46Z
- **Tasks:** 1
- **Files modified:** 1

## Accomplishments

- Moved burst frame Vec allocation before the select loop, reusing via clear() on each iteration
- Eliminates ~4000 heap allocations/sec on the WS hot path (18 symbols x ~220 trades/sec)
- All 30 streaming tests pass, build succeeds with no warnings

## Task Commits

Each task was committed atomically:

1. **Task 1: Move burst frame Vec outside select loop and reuse via clear()** - `065edba` (feat)

## Files Created/Modified

- `crates/opendeviationbar-streaming/src/live_engine.rs` - Burst frame Vec moved before loop, clear()+push replaces with_capacity()+push per iteration

## Decisions Made

- Used clear() reuse pattern (safe because AggTrade is trivially droppable, clear() is effectively O(1))
- Vec capacity grows to accommodate largest burst seen and stays there (typical 1-50 trades)

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- RUST-03 complete, all Phase 3 Rust hot-path optimizations done
- Phase 4 (Python Efficiency) has no dependencies on Phase 3

---

_Phase: 03-rust-hot-path_
_Completed: 2026-03-20_
