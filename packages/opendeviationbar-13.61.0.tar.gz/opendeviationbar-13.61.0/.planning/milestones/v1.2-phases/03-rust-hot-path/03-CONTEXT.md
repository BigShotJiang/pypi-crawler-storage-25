# Phase 3: Rust Hot Path Optimization (P3-P5) - Context

**Gathered:** 2026-03-20
**Status:** Ready for planning

<domain>
## Phase Boundary

Eliminate unnecessary heap allocations in three Rust hot paths: CSV→FixedPoint conversion, ZIP chunk iteration, and WebSocket burst frame processing.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase.

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `crates/opendeviationbar-providers/src/binance/historical.rs:211-212` — `FixedPoint::from_str(&csv_trade.1.to_string())` (the f64→String→FixedPoint path to fix)
- `crates/opendeviationbar-providers/src/binance/historical.rs:245-246` — same pattern in alternate conversion path
- `crates/opendeviationbar-streaming/src/live_engine.rs:1036-1044` — burst-atomic frame constant and doc (DRAIN_BURST_LIMIT=1024)
- `crates/opendeviationbar-streaming/src/live_engine.rs:1511` — `tokio::select!` loop location
- `crates/opendeviationbar-providers/src/binance/historical.rs:555` — `IntraDayChunkIterator` implementation

### Established Patterns

- `FixedPoint` is an `i128` wrapper with fixed-decimal semantics — `from_str()` parses decimal strings
- `CsvAggTrade` uses `f64` fields deserialized by csv crate — the double conversion (f64→String→FixedPoint) is the allocation waste
- `IntraDayChunkIterator` re-opens ZIP per chunk yielding O(N²) behavior
- Burst frame `Vec<AggTrade>` is allocated fresh each select loop iteration

### Integration Points

- `FixedPoint::from_f64()` — needs to be added or verified in `crates/opendeviationbar/src/lib.rs`
- `cargo nextest run -p opendeviationbar-streaming --lib` — streaming tests
- `cargo nextest run -p opendeviationbar-providers --lib` — provider tests

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase.

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>
