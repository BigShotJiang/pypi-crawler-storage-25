# Phase 5: Microsecond ClickHouse Rebuild - Context

**Gathered:** 2026-03-24
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — discuss skipped)

<domain>
## Phase Boundary

Migrate ClickHouse schema and all Python timestamp arithmetic from milliseconds to microseconds. All timestamp columns in open_deviation_bars switch from ms to us values. Python constants (DAY_MS, HOUR_MS, etc.) become DAY_US, HOUR_US. Sidecar, kintsugi, and heartbeat updated end-to-end. Full 35M+ bar rebuild via repair_direct_parquet.py to populate the new us-precision schema.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase. Use ROADMAP phase goal, success criteria, and codebase conventions to guide decisions.

Key constraints from ROADMAP success criteria:

- USEC-03: ClickHouse timestamp columns store microsecond values with updated COMMENTs
- USEC-05: All Python timestamp arithmetic uses microseconds (no ms constants in active code)
- USEC-06: Full ClickHouse rebuild with 48 workers, Stathera validation across entire dataset

</decisions>

<canonical_refs>

## Canonical References

### ClickHouse schema

- `python/opendeviationbar/clickhouse/schema.sql` — DDL for open_deviation_bars
- `python/opendeviationbar/clickhouse/CLAUDE.md` — Schema documentation SSoT

### Python timestamp constants

- grep -rn "DAY_MS\|HOUR_MS\|\_ms\b" python/ scripts/ — all ms references to migrate
- `python/opendeviationbar/sidecar/` — streaming sidecar (L1-L8 layers)
- `python/opendeviationbar/kintsugi/` — gap reconciliation
- `scripts/heartbeat/` — health monitoring

### Rebuild tooling

- `scripts/repair_direct_parquet.py` — bar rebuild engine (already us-native from Phase 4)

</canonical_refs>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase.

</specifics>

<deferred>
## Deferred Ideas

None.

</deferred>
