# Phase 8: Checksum Spike - Validation

**Created:** 2026-03-25
**Source:** 08-RESEARCH.md Validation Architecture section

## Test Framework

| Property           | Value                                      |
| ------------------ | ------------------------------------------ |
| Framework          | pytest (in pyproject.toml) + cargo nextest |
| Config file        | `pyproject.toml [tool.pytest.ini_options]` |
| Quick run command  | `uv run --python 3.13 pytest tests/ -x -q` |
| Full suite command | `mise run check-full`                      |

## Phase Requirements -> Test Map

| Req ID   | Behavior                                            | Test Type             | Automated Command                                                                                  | File Exists? |
| -------- | --------------------------------------------------- | --------------------- | -------------------------------------------------------------------------------------------------- | ------------ |
| SPIKE-01 | Rust checksum callable from Python, correct results | integration (network) | `uv run --python 3.13 python scripts/spike_checksum_validation.py`                                 | No -- Wave 0 |
| SPIKE-02 | Performance overhead < 10%                          | integration (network) | Same script, benchmark section                                                                     | No -- Wave 0 |
| SPIKE-03 | Edge cases: 404, timeout, mismatch, format error    | unit + integration    | `uv run --python 3.13 pytest tests/test_checksum_spike.py -x` (unit) + validation script (network) | No -- Wave 0 |

## Sampling Rate

- **Per task commit:** `uv run --python 3.13 pytest tests/ -x -q`
- **Per wave merge:** `mise run check-full`
- **Phase gate:** Full suite green + spike validation script passes

## Wave 0 Gaps

- [ ] `tests/test_checksum_spike.py` -- unit tests for new PyO3 bindings (offline, no network)
- [ ] `scripts/spike_checksum_validation.py` -- integration test with real Binance data (SPIKE-01, SPIKE-02, SPIKE-03)
- [ ] New PyO3 bindings in `src/binance_bindings.rs`: `compute_sha256_hex()`, `verify_checksum_hex()`, `parse_checksum_file_content()`
- [ ] Register new functions in `src/lib.rs`
- [ ] `maturin develop` rebuild

## Edge Case Coverage Matrix (SPIKE-03)

| Case | Scenario           | Expected Behavior            | Tested In                      |
| ---- | ------------------ | ---------------------------- | ------------------------------ |
| 3a   | 404 CHECKSUM (old) | `skipped=True`, no exception | `spike_checksum_validation.py` |
| 3b   | Mismatch hash      | `RuntimeError("mismatch")`   | unit test + validation script  |
| 3c   | Invalid format     | `ValueError`                 | unit test + validation script  |
| 3d   | Network timeout    | `skipped=True`, no exception | `spike_checksum_validation.py` |
