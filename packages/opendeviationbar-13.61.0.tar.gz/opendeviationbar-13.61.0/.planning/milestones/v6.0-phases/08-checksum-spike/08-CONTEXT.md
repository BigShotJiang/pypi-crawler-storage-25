# Phase 8: Checksum Spike - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — discuss skipped)

<domain>
## Phase Boundary

Rust checksum.rs SHA-256 fetch+verify is proven callable from Python with correct results, acceptable performance, and graceful edge case handling. This is a validation spike — no production integration, just proof the mechanism works end-to-end against real Vision data.

Requirements: SPIKE-01, SPIKE-02, SPIKE-03

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure/spike phase. Use ROADMAP phase goal, success criteria, and codebase conventions to guide decisions.

Key context from earlier research:

- `crates/opendeviationbar-providers/src/binance/checksum.rs` (402 lines) has full SHA-256 implementation with 13 unit tests
- Functions: `compute_sha256()`, `fetch_checksum()`, `verify_checksum()`, `fetch_and_verify()`
- Python seeder currently downloads Vision ZIPs via raw `requests.get()` — no checksum verification
- The spike needs to prove the Rust module works from Python, either via existing PyO3 bindings or new thin binding

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `crates/opendeviationbar-providers/src/binance/checksum.rs` — Full SHA-256 checksum module
- `crates/opendeviationbar-providers/src/binance/historical.rs` — Uses `fetch_and_verify()` for Vision downloads
- `src/binance_bindings.rs` — Existing PyO3 bindings for Binance provider functions

### Established Patterns

- PyO3 bindings in `src/` domain modules expose Rust functions to Python
- Binance Vision URL pattern: `https://data.binance.vision/data/spot/daily/aggTrades/{SYMBOL}/{SYMBOL}-aggTrades-{DATE}.zip`
- CHECKSUM URL: append `.CHECKSUM` to the ZIP URL

### Integration Points

- `scripts/tick_cache_seeder.py` — Primary consumer once spike validates
- `python/opendeviationbar/storage/parquet.py` — Where verified data lands

</code_context>

<specifics>
## Specific Ideas

User explicitly requested empirical validation against real data — not just unit tests. The spike must download a real Vision ZIP and its CHECKSUM file, compute SHA-256, and verify the match.

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>
