# Phase 11: Integrity Sweep - Context

**Gathered:** 2026-03-26
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — discuss skipped)

<domain>
## Phase Boundary

A script audits all existing Parquet cache files by re-downloading Vision CHECKSUM files and comparing against stored originals. Incremental mode skips already-verified files via ChecksumRegistry. Produces summary report with pass/fail/skip counts per symbol and date range.

Requirements: SWEEP-01, SWEEP-02, SWEEP-03

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — infrastructure phase.

Key context:

- ChecksumRegistry (Phase 9) provides `has_verified()` for incremental skip
- Parquet tick cache at `~/.cache/opendeviationbar/ticks/{SYMBOL}/` with daily `.parquet` files
- Vision CHECKSUM URL: `https://data.binance.vision/data/spot/daily/aggTrades/{SYMBOL}/{SYMBOL}-aggTrades-{DATE}.zip.CHECKSUM`
- The sweep needs the original ZIP bytes to compute SHA-256 — must re-download ZIP or use stored hash
- Alternative: compute SHA-256 during seeder download and store in registry, then sweep just verifies registry entries exist
- `compute_sha256_hex` from Phase 8 available for hashing
- `parse_checksum_file_content` parses .CHECKSUM files
- Script should be in `scripts/` following existing patterns

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `python/opendeviationbar/checksum_registry.py` — ChecksumRegistry (Phase 9)
- `opendeviationbar._core.compute_sha256_hex` — SHA-256 computation
- `opendeviationbar._core.parse_checksum_file_content` — CHECKSUM parsing
- `python/opendeviationbar/storage/parquet.py` — TickStorage for cache file discovery

### Established Patterns

- Scripts in `scripts/` with argparse CLI
- Progress reporting via tqdm
- Telegram summary at completion

### Integration Points

- Reads ChecksumRegistry for incremental mode
- Writes failed entries to ChecksumRegistry
- Uses Vision CHECKSUM URLs for verification

</code_context>

<specifics>
## Specific Ideas

No specific requirements beyond ROADMAP.

</specifics>

<deferred>
## Deferred Ideas

None.

</deferred>
