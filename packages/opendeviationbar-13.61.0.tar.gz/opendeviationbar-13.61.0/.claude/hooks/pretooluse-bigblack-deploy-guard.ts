#!/usr/bin/env bun
/**
 * PreToolUse:Bash — Bigblack deploy safety guard
 *
 * Prevents the two root causes of .pth shadowing on production:
 * 1. `maturin develop` on bigblack — creates editable .pth with hard links
 * 2. `uv pip install` from inside the repo dir — creates editable .pth
 *
 * Learned 2026-03-28: 3 incidents in one session, 1100+ overlaps, 13/16
 * junction gaps — all from stale .pth loading v13.56.1 instead of v13.59.0.
 *
 * @see memory/feedback-pth-shadowing-deploy-hazard.md
 */

interface PreToolUseInput {
  tool_name: string;
  tool_input: {
    command?: string;
    [key: string]: unknown;
  };
  cwd?: string;
}

function deny(reason: string): string {
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision: "deny",
      permissionDecisionReason: reason,
    },
  });
}

async function main(): Promise<void> {
  const stdin = await Bun.stdin.text();
  if (!stdin.trim()) return process.exit(0);

  let input: PreToolUseInput;
  try {
    input = JSON.parse(stdin);
  } catch {
    return process.exit(0); // Fail open
  }

  if (input.tool_name !== "Bash") return process.exit(0);
  const cmd = input.tool_input?.command || "";

  // Skip git commands (commit messages may contain blocked keywords)
  if (/^\s*git\s+(commit|log|diff|show|tag)/m.test(cmd)) return process.exit(0);

  // Guard 1: Block `maturin develop` on bigblack
  // Root cause: creates opendeviationbar.pth with hard links that survive venv swaps
  if (/ssh\s+bigblack.*maturin\s+develop/i.test(cmd) ||
      /maturin\s+develop.*bigblack/i.test(cmd)) {
    console.log(deny(
      "[DEPLOY-GUARD] BLOCKED: `maturin develop` on bigblack creates .pth files " +
      "with hard links that survive venv swaps, causing version drift.\n\n" +
      "Use `scp wheel.whl bigblack:/tmp/ && ssh bigblack 'uv pip install /tmp/wheel.whl'` instead.\n" +
      "See: memory/feedback-pth-shadowing-deploy-hazard.md"
    ));
    return process.exit(0);
  }

  // Guard 2: Block `uv pip install` from inside the repo directory on bigblack
  // Anti-pattern: uv detects pyproject.toml and creates editable .pth
  const sshBigblackInstall = cmd.match(
    /ssh\s+bigblack\s+['"](.*uv\s+pip\s+install.*)['"]/s
  );
  if (sshBigblackInstall) {
    const innerCmd = sshBigblackInstall[1];
    // Check if installing from repo dir (not from /tmp/)
    if (
      /cd\s+~\/opendeviationbar-py.*uv\s+pip\s+install\s+\./.test(innerCmd) ||
      /uv\s+pip\s+install\s+~\/opendeviationbar-py\/(?!\.venv)/.test(innerCmd) ||
      /uv\s+pip\s+install\s+\.\//.test(innerCmd)
    ) {
      console.log(deny(
        "[DEPLOY-GUARD] BLOCKED: `uv pip install` from inside the repo directory " +
        "on bigblack creates editable .pth files that shadow the wheel.\n\n" +
        "Install from /tmp/ instead:\n" +
        "  scp dist/wheel.whl bigblack:/tmp/\n" +
        "  ssh bigblack 'uv pip install --python .venv/bin/python3 /tmp/wheel.whl'\n\n" +
        "See: .claude/skills/odb-ship/SKILL.md Phase 3.3"
      ));
      return process.exit(0);
    }
  }

  // Guard 3: Block bare `pip install -e .` or `pip install --editable` on bigblack
  if (/ssh\s+bigblack.*pip\s+install\s+(-e\s+\.|--editable)/i.test(cmd)) {
    console.log(deny(
      "[DEPLOY-GUARD] BLOCKED: Editable pip install on bigblack creates .pth files.\n" +
      "Use wheel install from /tmp/ instead."
    ));
    return process.exit(0);
  }

  return process.exit(0);
}

void main();
