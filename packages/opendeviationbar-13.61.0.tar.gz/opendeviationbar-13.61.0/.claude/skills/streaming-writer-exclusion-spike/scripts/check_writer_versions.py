#!/usr/bin/env python3
"""Check which writer versions produced bars for today.

Shows +backfill vs +sidecar breakdown to verify kintsugi is not writing
bars for streaming symbols.

Run on bigblack:
    ~/opendeviationbar-py/.venv/bin/python3 \
        .claude/skills/streaming-writer-exclusion-spike/scripts/check_writer_versions.py
"""
import os
import sys

sys.path.insert(0, os.path.expanduser("~/opendeviationbar-py/python"))

from opendeviationbar.clickhouse.cache import OpenDeviationBarCache


def main():
    cache = OpenDeviationBarCache()

    print("=== Writer versions for streaming symbols today ===\n")
    result = cache.client.query("""
        SELECT symbol, threshold_decimal_bps, opendeviationbar_version,
               count() AS bars,
               min(toDateTime64(open_time_ms/1000, 0)) AS earliest,
               max(toDateTime64(close_time_ms/1000, 0)) AS latest
        FROM opendeviationbar_cache.open_deviation_bars FINAL
        WHERE symbol IN ('BTCUSDT', 'ETHUSDT')
          AND toDate(close_time_ms/1000) = today()
        GROUP BY symbol, threshold_decimal_bps, opendeviationbar_version
        ORDER BY symbol, threshold_decimal_bps, opendeviationbar_version
    """)

    backfill_count = 0
    for row in result.result_rows:
        sym, thr, ver, bars, earliest, latest = row
        tag = "!!!" if "+backfill" in ver else "   "
        print(f"{tag} {sym}@{thr}: {ver} — {bars} bars ({earliest} → {latest})")
        if "+backfill" in ver:
            backfill_count += bars

    print(f"\n{'=' * 60}")
    if backfill_count > 0:
        print(f"WARNING: {backfill_count} +backfill bars for streaming symbols today")
        print("Kintsugi trailing-edge fill is writing to sidecar-owned symbols!")
        return 1
    else:
        print("CLEAN: No +backfill bars for streaming symbols today")
        return 0


if __name__ == "__main__":
    sys.exit(main())
