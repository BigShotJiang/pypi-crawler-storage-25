# Evolution Log

Reverse chronological change history for the benchmark-fairness skill.

---

## 2026-02-16 - Initial creation

**Origin**: Memory efficiency audit (Issue #95) benchmark comparison revealed 2 of 3 runtime optimizations (R3 conditional clone, R5 volume moments fold) were not covered by any benchmark. The A/B comparison was rated MOSTLY FAIR instead of FAIR due to coverage gaps.

**Lessons captured**:

- Coverage mapping table is the single most important pre-flight check
- Sub-nanosecond "regressions" on untouched code paths are always noise
- `[dev-dependencies]` additions are safe for benchmark compilation (no library codegen impact)
- Threshold + volatility parameters control bar close rate in synthetic data
- Running baseline FIRST avoids thermal throttling bias
- `git stash` approach requires re-applying non-functional fixes after stash
