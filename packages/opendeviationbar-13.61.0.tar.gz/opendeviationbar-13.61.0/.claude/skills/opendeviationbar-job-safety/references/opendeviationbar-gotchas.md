# opendeviationbar-py Environment Gotchas

Project-specific gotchas. For universal gotchas, see `devops-tools:distributed-job-safety` environment-gotchas.md.

## RG-1: mise SSoT Defaults vs. Production Overrides

**Symptom**: Production jobs use wrong threshold (1000 instead of 250).

**Root cause**: `.mise.toml` sets `OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD=1000` as a local dev safety guard. This default applies to ALL commands unless overridden.

**Fix**: Override at pueue enqueue time (not by editing `.mise.toml`):

```bash
pueue add -- env OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD=250 uv run python script.py
```

**Why not .mise.local.toml**: Works locally but doesn't transfer to remote hosts via git.

## RG-2: ClickHouse Connection Refused on Remote Hosts

**Symptom**: `ConnectionError: Connection refused` when running on a remote host.

**Root cause**: `.mise.toml` hardcodes `OPENDEVIATIONBAR_CH_HOSTS=bigblack`. On littleblack or local Docker, the hostname doesn't resolve.

**Fix**: Override before running:

```bash
export OPENDEVIATIONBAR_CH_HOSTS=localhost
uv run python script.py
```

## Quick Reference

| Gotcha | Symptom            | One-Line Fix                                    |
| ------ | ------------------ | ----------------------------------------------- |
| RG-1   | Wrong threshold    | `env OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD=250` per-job |
| RG-2   | Connection refused | `export OPENDEVIATIONBAR_CH_HOSTS=localhost`            |
