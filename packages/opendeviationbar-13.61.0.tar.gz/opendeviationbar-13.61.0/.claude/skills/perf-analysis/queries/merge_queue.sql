-- Active merge operations for open_deviation_bars
-- Healthy: <3 pending | Yellow: >5 | Red: >10
-- When merges fall behind, parts accumulate toward delay/throw thresholds.

SELECT
    table,
    round(progress * 100, 1) AS progress_pct,
    num_parts AS merging_parts,
    formatReadableSize(total_size_bytes_compressed) AS compressed_size,
    formatReadableSize(bytes_read_uncompressed) AS bytes_read,
    formatReadableTimeDelta(elapsed) AS elapsed,
    formatReadableTimeDelta(
        elapsed / nullIf(progress, 0) * (1 - progress)
    ) AS estimated_remaining
FROM system.merges
WHERE database = 'opendeviationbar_cache'
ORDER BY elapsed DESC
FORMAT PrettyCompact
