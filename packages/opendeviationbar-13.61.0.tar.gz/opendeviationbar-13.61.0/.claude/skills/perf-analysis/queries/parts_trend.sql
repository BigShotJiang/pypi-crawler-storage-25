-- Parts creation trend over the last hour (1-minute buckets)
-- Use to determine if parts are accumulating (growing trend) or stable.
-- Accumulating parts = merges falling behind inserts = reduce workers.

SELECT
    toStartOfMinute(modification_time) AS minute,
    count() AS parts_created
FROM system.parts
WHERE database = 'opendeviationbar_cache'
  AND table = 'open_deviation_bars'
  AND active
  AND modification_time > now() - INTERVAL 1 HOUR
GROUP BY minute
ORDER BY minute DESC
LIMIT 30
FORMAT PrettyCompact
