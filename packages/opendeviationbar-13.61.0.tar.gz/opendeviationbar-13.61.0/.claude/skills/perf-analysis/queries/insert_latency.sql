-- Insert latency over the last 10 minutes
-- Healthy: <10ms avg | Yellow: >10ms avg | Red: >50ms avg
-- Rising insert latency indicates ClickHouse is under merge pressure.

SELECT
    count() AS insert_count,
    round(avg(query_duration_ms), 1) AS avg_latency_ms,
    round(quantile(0.95)(query_duration_ms), 1) AS p95_latency_ms,
    max(query_duration_ms) AS max_latency_ms,
    round(avg(written_rows), 0) AS avg_rows_per_insert,
    formatReadableSize(avg(written_bytes)) AS avg_bytes_per_insert
FROM system.query_log
WHERE type = 'QueryFinish'
  AND query_kind = 'Insert'
  AND event_time > now() - INTERVAL 10 MINUTE
  AND databases = ['opendeviationbar_cache']
FORMAT PrettyCompact
