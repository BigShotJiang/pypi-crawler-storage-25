"""
Walidacja refaktoryzacji — testy przed/po zmianie i wykrywanie regresji.

Moduły:
- test_runner — uruchamianie testów i walidacja zmian
"""

from __future__ import annotations

from .test_runner import TestResult, TestRunner, discover_test_command, run_tests, validate_refactor

__all__ = [
    "TestResult",
    "TestRunner",
    "discover_test_command",
    "run_tests",
    "validate_refactor",
]
