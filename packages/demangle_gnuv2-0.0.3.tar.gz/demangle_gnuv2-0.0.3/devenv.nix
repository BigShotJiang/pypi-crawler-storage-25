{
  pkgs,
  lib,
  config,
  inputs,
  ...
}: let
  checkPanicReasonsScript = pkgs.writeShellScriptBin "panic-reasons" ''
    jq="${pkgs.jq}/bin/jq"
    sort="${pkgs.coreutils}/bin/sort"
    uniq="${pkgs.coreutils}/bin/uniq"

    [ -f "results-netbabel.json" ] && "$jq" '.results[] | select(.success == false) | select(.fail_reason == "PANIC") | select(.exc_info | test("^not yet implemented")) | .exc_info' < results-netbabel.json | $sort | $uniq -c
    [ -f "results-libc2e.json" ] && "$jq" '.results[] | select(.success == false) | select(.fail_reason == "PANIC") | select(.exc_info | test("^not yet implemented")) | .exc_info' < results-libc2e.json | $sort | $uniq -c
  '';
  checkFailuresScript = pkgs.writeShellScriptBin "failed-syms" ''
    jq="${pkgs.jq}/bin/jq"
    sort="${pkgs.coreutils}/bin/sort"
    uniq="${pkgs.coreutils}/bin/uniq"

    [ -f "results-netbabel.json" ] && "$jq" '.results[] | select(.success == false)' < results-netbabel.json
    [ -f "results-libc2e.json" ] && "$jq" '.results[] | select(.success == false)' < results-libc2e.json
  '';
in {
  env.JJ_PRE_PUSH_CHECKER = "prek";

  packages = [pkgs.git pkgs.gh pkgs.alejandra pkgs.rustup checkPanicReasonsScript checkFailuresScript pkgs.ruff];

  languages.rust.enable = true;
  languages.rust.channel = "stable";
  languages.python.enable = true;
  languages.python.package = pkgs.python312;
  languages.python.venv.enable = true;
  languages.python.venv.requirements = ''
    maturin==1.13.1
  '';

  scripts.demangle.exec = ''
    exec cargo run -p demangle-gnuv2 --bin demangle "$@"
  '';

  tasks = {
    "workspace:build".exec = "cargo build --workspace";
    "workspace:lint".exec = "cargo clippy --workspace --keep-going -- -D warnings";
    "workspace:fix-lints".exec = "cargo clippy --workspace --keep-going --fix";
    "workspace:fmt".exec = "cargo fmt";
    "pyext:develop" = {
      before = ["test:nb-symbols" "test:lc2e-symbols"];
      after = ["devenv:python:virtualenv"];
      exec = "cd \"$DEVENV_ROOT/demangle-gnuv2-py\" && maturin develop";
    };
    "test:nb-symbols" = {
      exec = ''
        set -euo pipefail
        python test/test_demangle.py -i test/c2e-netbabel-syms.json -Cj -o results-netbabel.json | tee "$DEVENV_TASK_OUTPUT_FILE"
      '';
      before = ["devenv:enterTest"];
    };
    "test:lc2e-symbols" = {
      exec = ''
        set -euo pipefail
        python test/test_demangle.py -Cj -i test/c2e-libc2e-syms.json -o results-libc2e.json | tee "$DEVENV_TASK_OUTPUT_FILE"
      '';
      before = ["devenv:enterTest"];
    };
  };

  enterTest = ''
  '';

  git-hooks.hooks.alejandra.enable = true;
  git-hooks.hooks.rustfmt.enable = true;
  git-hooks.hooks.clippy.enable = true;
}
