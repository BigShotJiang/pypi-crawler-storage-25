"""
    QApp Platform Project language.py Copyright © CITYNOW Co. Ltd. All rights reserved.
"""

#  Quapp Platform Project
#  language.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.

from ..enum.base_enum import BaseEnum


class Language(BaseEnum):
  PYTHON = 'python'
  JAVASCRIPT = 'javascript'

  @staticmethod
  def resolve(language: str):
    for element in Language:
      if element.value == language:
        return element

    raise ValueError(f"Language '{language}' is not supported!")
