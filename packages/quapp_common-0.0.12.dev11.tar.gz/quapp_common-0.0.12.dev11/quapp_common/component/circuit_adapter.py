"""
    QApp Platform Project circuit_adapter.py Copyright © CITYNOW Co. Ltd. All rights reserved.
"""
#  Quapp Platform Project
#  circuit_adapter.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.

from ..config.logging_config import logger
from ..enum.sdk import Sdk

logger = logger.bind(context=__name__)


class CircuitAdapter:
    """Convert JS subprocess circuit output to native SDK circuit objects.

    Supported interchange formats:
      - openqasm: OpenQASM 2.0 string -> SDK-specific QuantumCircuit
      - qubo: QUBO dict -> dimod.BinaryQuadraticModel
      - json: Arbitrary JSON pass-through
    """

    @staticmethod
    def adapt(sdk: Sdk, result: dict):
        """Route to the appropriate adapter based on the 'format' field."""
        fmt = result.get("format")
        logger.debug(f"adapt() called | sdk={sdk} | format={fmt}")
        if fmt == "openqasm":
            circuit = result.get("circuit")
            if circuit is None:
                raise ValueError("Missing 'circuit' field in openqasm response")
            return CircuitAdapter._adapt_openqasm(sdk, circuit)
        elif fmt == "qubo":
            qubo = result.get("qubo")
            if qubo is None:
                raise ValueError("Missing 'qubo' field in qubo response")
            return CircuitAdapter._adapt_qubo(sdk, qubo)
        elif fmt == "json":
            logger.debug("Returning raw JSON data pass-through")
            return result.get("data")
        raise ValueError(f"Unsupported circuit interchange format: {fmt}")

    @staticmethod
    def _adapt_openqasm(sdk, qasm_str):
        """Convert an OpenQASM 2.0 string to a native SDK circuit object."""
        logger.debug(f"Adapting OpenQASM circuit for SDK: {sdk} | qasm_length={len(qasm_str)}")

        if sdk == Sdk.QISKIT:
            logger.debug("Converting OpenQASM via Qiskit QuantumCircuit.from_qasm_str")
            from qiskit import QuantumCircuit
            return QuantumCircuit.from_qasm_str(qasm_str)

        elif sdk == Sdk.BRAKET:
            logger.debug("Converting OpenQASM via pytket -> tk_to_braket")
            import importlib
            from pytket.qasm import circuit_from_qasm_str
            tk_to_braket = importlib.import_module("pytket.extensions.braket").tk_to_braket
            result = tk_to_braket(circuit_from_qasm_str(qasm_str))
            # tk_to_braket returns (Circuit, n_shots) in pytket-braket >= 0.35
            is_tuple = isinstance(result, tuple)
            logger.debug(f"tk_to_braket returned tuple={is_tuple}; unpacking index 0" if is_tuple else "tk_to_braket returned Circuit directly")
            return result[0] if is_tuple else result

        elif sdk == Sdk.PENNYLANE:
            logger.debug("Converting OpenQASM via PennyLane qml.from_qasm wrapper")
            import pennylane as qml
            # PennyLane >=0.37 treats QASM `measure` statements as mid-circuit
            # measurements returning MeasurementValue, which fails QNode
            # validation. Override with a terminal `qml.probs` over all qubits
            # so the QNode produces valid output and downstream histogram
            # logic (which already looks for ProbabilityMP) keeps working.
            #
            # NOTE: `qml.from_qasm(..., measurements=[...])` attaches those
            # measurements via `make_qscript` internally, which means they are
            # NOT queued into an active `QuantumTape()` context. Downstream
            # code uses `with QuantumTape() as tape: circuit()` to discover
            # the circuit's wires, which would then miss the measurement
            # wires and cause `WireError` at device execution. We therefore
            # return a wrapper that runs the QASM ops (measurements=[] to
            # drop QASM's terminal measures) and then explicitly queue a
            # fresh `qml.probs` over all qubits, so the wires are visible in
            # both `QuantumTape` capture and full QNode execution.
            num_wires = CircuitAdapter._count_qasm_qubits(qasm_str)
            logger.debug(f"PennyLane: detected {num_wires} qubits; wrapping with qml.probs over all wires")
            base_fn = qml.from_qasm(qasm_str, measurements=[])

            def _circuit():
                base_fn()
                if num_wires > 0:
                    return qml.probs(wires=list(range(num_wires)))
                return None

            return _circuit

        elif sdk == Sdk.PYQUIL:
            logger.debug("Converting OpenQASM via pytket -> tk_to_pyquil")
            import importlib
            from pytket.qasm import circuit_from_qasm_str
            tk_to_pyquil = importlib.import_module("pytket.extensions.pyquil").tk_to_pyquil
            return tk_to_pyquil(circuit_from_qasm_str(qasm_str))

        elif sdk == Sdk.QIBO:
            logger.debug("Converting OpenQASM via Qibo Circuit.from_qasm")
            from qibo.models import Circuit
            return Circuit.from_qasm(qasm_str)

        elif sdk == Sdk.QULACS:
            logger.debug("Converting OpenQASM for Qulacs via Qiskit bridge")
            # Try the Qiskit bridge first; fall back to raw pass-through if
            # qiskit is not installed or the conversion fails.
            try:
                from qiskit import QuantumCircuit as QiskitCircuit
                qiskit_circ = QiskitCircuit.from_qasm_str(qasm_str)
                logger.debug(f"Qiskit parsed circuit: num_qubits={qiskit_circ.num_qubits} num_gates={len(qiskit_circ.data)}")
                return CircuitAdapter._qiskit_to_qulacs(qiskit_circ)
            except Exception as e:
                logger.warning(f"Qiskit bridge failed for Qulacs ({e}); falling back to raw OpenQASM pass-through")
                return qasm_str

        elif sdk == Sdk.CUDA_QUANTUM:
            logger.debug("CUDA-Q: passing OpenQASM string through directly")
            # CUDA-Q accepts OpenQASM directly via kernel builder
            return qasm_str

        raise ValueError(f"OpenQASM adaptation not supported for SDK: {sdk}")

    @staticmethod
    def _count_qasm_qubits(qasm_str):
        """Sum qubit counts across all `qreg <name>[<n>];` declarations."""
        import re
        return sum(int(m) for m in re.findall(r'qreg\s+\w+\[(\d+)\]', qasm_str))

    @staticmethod
    def _adapt_qubo(sdk, qubo_raw):
        """Convert a QUBO dict with string keys ('x0,x1') to a BinaryQuadraticModel.

        JS returns keys like "x0,x1" as strings. We parse them into tuple keys
        for dimod's from_qubo() method.
        """
        logger.debug(f"Adapting QUBO for SDK: {sdk} | num_entries={len(qubo_raw)}")

        qubo_dict = {}
        for key, val in qubo_raw.items():
            if isinstance(key, str) and "," in key:
                parts = tuple(k.strip() for k in key.split(",", 1))
                qubo_dict[parts] = val
            else:
                qubo_dict[(key, key)] = val

        logger.debug(f"QUBO parsed: {len(qubo_dict)} entries -> BinaryQuadraticModel")
        from dimod import BinaryQuadraticModel
        return BinaryQuadraticModel.from_qubo(qubo_dict)

    @staticmethod
    def _qiskit_to_qulacs(qiskit_circ):
        """Convert a Qiskit QuantumCircuit to a qulacs QuantumCircuit.

        Fixed gates are mapped via named qulacs methods; parametric and
        unrecognized gates fall back to DenseMatrix (unitary passthrough).
        Measurement, barrier, reset, and identity instructions are skipped.
        """
        from qulacs import QuantumCircuit as QulacsCirucit
        from qulacs.gate import DenseMatrix

        n = qiskit_circ.num_qubits
        logger.debug(f"_qiskit_to_qulacs: num_qubits={n} num_instructions={len(qiskit_circ.data)}")
        qulacs_circ = QulacsCirucit(n)
        qubit_map = {bit: idx for idx, bit in enumerate(qiskit_circ.qubits)}

        _SINGLE = {
            'h': 'add_H_gate', 'x': 'add_X_gate',
            'y': 'add_Y_gate', 'z': 'add_Z_gate',
            's': 'add_S_gate', 'sdg': 'add_Sdag_gate',
            't': 'add_T_gate', 'tdg': 'add_Tdag_gate',
        }
        _TWO = {
            'cx': 'add_CNOT_gate',
            'cz': 'add_CZ_gate',
            'swap': 'add_SWAP_gate',
        }
        _SKIP = {'measure', 'barrier', 'reset', 'id'}

        for inst in qiskit_circ.data:
            gate = inst.operation
            qubits = [qubit_map[q] for q in inst.qubits]
            name = gate.name

            if name in _SKIP:
                continue
            elif name in _SINGLE:
                getattr(qulacs_circ, _SINGLE[name])(qubits[0])
            elif name in _TWO:
                getattr(qulacs_circ, _TWO[name])(qubits[0], qubits[1])
            else:
                # Parametric gates (rx, ry, rz, u*, p, ...) and any
                # unrecognized gate: extract the unitary and apply it
                # as a DenseMatrix. Single-qubit gates have no ordering
                # ambiguity; multi-qubit gates are passed with qulacs'
                # index order matching Qiskit's instruction qubit order.
                logger.debug(f"Gate '{name}' not in named map; converting via DenseMatrix on qubits={qubits}")
                qulacs_circ.add_gate(DenseMatrix(qubits, gate.to_matrix()))

        logger.debug(f"_qiskit_to_qulacs: conversion complete")
        return qulacs_circ
