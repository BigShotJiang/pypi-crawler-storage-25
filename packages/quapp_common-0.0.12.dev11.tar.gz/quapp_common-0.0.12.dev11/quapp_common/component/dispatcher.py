"""
    QApp Platform Project dispatcher.py Copyright © CITYNOW Co. Ltd. All rights reserved.
"""

#  Quapp Platform Project
#  dispatcher.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.

import json
import os
import subprocess

from ..config.logging_config import logger
from ..enum.language import Language

logger = logger.bind(context=__name__)


class SubprocessDispatcher:
    """Dispatch handler execution to non-Python runtimes via subprocess."""

    # Override this at application startup to set a stable working directory
    # for subprocess runners (e.g., the project root containing function/).
    # Defaults to os.getcwd() at dispatch time if not set.
    WORKING_DIR: str = None

    RUNNER_MAP = {
        Language.JAVASCRIPT: {
            'command': ['node', 'handler_runner.js'],
            'timeout': 300,
        }
    }

    @staticmethod
    def dispatch(language: Language, request_data: dict,
            timeout: int = None) -> dict:
        """Dispatch request_data to a subprocess runner.

        Args:
            language: The target language runtime.
            request_data: Dict to serialize as JSON and pipe to stdin.
            timeout: Optional timeout in seconds. Overrides the runner by default.

        Returns:
            Parsed JSON dict from the subprocess stdout.
        """
        runner = SubprocessDispatcher.RUNNER_MAP.get(language)
        if runner is None:
            raise ValueError(f"No runner configured for language: {language}")

        effective_timeout = timeout if timeout is not None else runner[
            'timeout']
        action = request_data.get('action', 'handle')
        logger.info(f"Dispatching to {language.value} runner, action={action}, "
                    f"timeout={effective_timeout}s")

        payload = json.dumps(request_data)
        cwd = SubprocessDispatcher.WORKING_DIR or os.getcwd()
        result = subprocess.run(runner['command'], input=payload,
                                capture_output=True, text=True,
                                timeout=effective_timeout, cwd=cwd)

        if result.stderr:
            logger.debug(f"Subprocess stderr: {result.stderr[:500]}")

        if result.returncode != 0:
            error_message = SubprocessDispatcher._extract_error_message(result)
            logger.error(
                    f"Handler runner failed (exit={result.returncode}): {error_message[:500]}")
            raise RuntimeError(f"Handler runner failed: {error_message}")

        if not result.stdout:
            raise RuntimeError("Handler runner produced no output")

        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                    f"Handler runner returned invalid JSON: {exc}") from exc

    @staticmethod
    def _extract_error_message(result) -> str:
        """Extract the most meaningful error message from a failed subprocess.

        Priority order:
          1. Structured JSON on stdout  – {"status":"error","error":"..."}
          2. Raw stderr text
          3. Generic exit-code string
        """
        if result.stdout:
            try:
                parsed = json.loads(result.stdout)
                if parsed.get('status') == 'error':
                    return (parsed.get('error') or parsed.get(
                        'stack') or 'Unknown JS error')
            except (json.JSONDecodeError, AttributeError):
                pass
        if result.stderr:
            return result.stderr.strip()
        return f"exit code {result.returncode}"

    @staticmethod
    def is_subprocess_language(language_str: str) -> bool:
        try:
            lang = Language.resolve(language_str)
            return lang != Language.PYTHON
        except Exception:
            return False
