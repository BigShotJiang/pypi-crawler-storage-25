"""
    QApp Platform Project result_serializer.py Copyright © CITYNOW Co. Ltd. All rights reserved.
"""
from ..util.json_parser_utils import parse


class ResultSerializer:
    """Serialize Python job results into JSON-safe dicts for subprocess communication."""

    @staticmethod
    def serialize(job_result):
        """
        Convert a job result (which may contain numpy arrays, complex numbers,
        Qiskit/Braket objects, etc.) into a plain JSON-serializable dict.

        Reuses the existing parse() utility that handles numpy, complex, datetime,
        Enum, and custom objects with to_dict()/__dict__.
        """
        try:
            return parse(job_result)
        except Exception as e:
            raise RuntimeError(f"Failed to serialize job result: {e}") from e
