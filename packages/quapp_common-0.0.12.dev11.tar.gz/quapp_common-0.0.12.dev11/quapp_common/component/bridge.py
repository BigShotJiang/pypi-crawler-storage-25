"""
    QApp Platform Project
    bridge.py
    Copyright © CITYNOW Co. Ltd. All rights reserved.
"""
#  Quapp Platform Project
#  bridge.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.

from .circuit_adapter import CircuitAdapter
from .dispatcher import SubprocessDispatcher
from .result_serializer import ResultSerializer
from ..config.logging_config import logger
from ..enum.language import Language
from ..enum.sdk import Sdk

logger = logger.bind(context=__name__)


class SubprocessBridge:
    """Bridge between the Python invocation chain and JS subprocess handlers.

    Provides processing() and post_processing() callables that can be passed
    to AsyncInvocationTask in place of Python handler functions. Internally,
    each call dispatches to the JS subprocess with the appropriate action,
    then converts the result (circuit or post-processed data) back to
    Python-native objects.
    """

    def __init__(self, language: Language, sdk: Sdk):
        self.language = language
        self.sdk = sdk
        logger.debug(f"SubprocessBridge initialized | language={language.value} | sdk={sdk}")

    def processing(self, invocation_input: dict):
        """Call JS handler's processing() and convert a result to a native circuit.

        Args:
            invocation_input: The input dict from the invocation request.

        Returns:
            A native SDK circuit object (QuantumCircuit, BQM, etc.)

        Raises:
            RuntimeError: If the JS subprocess returns an error status.
        """
        logger.info(f"SubprocessBridge.processing: dispatching to {self.language.value} | sdk={self.sdk}")
        logger.debug(f"SubprocessBridge.processing: input_keys={list(invocation_input.keys())}")

        result = SubprocessDispatcher.dispatch(self.language, {
            "action": "processing",
            "input" : invocation_input
        })

        status = result.get("status")
        logger.debug(f"SubprocessBridge.processing: JS status={status}")

        if status == "error":
            logger.error(f"SubprocessBridge.processing: JS error={result.get('error')}")
            raise RuntimeError(f"JS processing failed: {result.get('error')}")

        payload = result.get("result")
        if payload is None:
            raise RuntimeError("JS processing returned no 'result' field")

        fmt = payload.get("format")
        logger.debug(f"SubprocessBridge.processing: JS returned format={fmt}; adapting for sdk={self.sdk}")

        circuit = CircuitAdapter.adapt(self.sdk, payload)
        logger.info(f"SubprocessBridge.processing: circuit adapted successfully | type={type(circuit).__name__}")
        return circuit

    def post_processing(self, job_result):
        """Serialize a job result, send to JS handler's postProcessing(), return a result.

        Args:
            job_result: The raw job results from the quantum device execution.

        Returns:
            The post-processed result from the JS handler.

        Raises:
            RuntimeError: If the JS subprocess returns an error status.
        """
        logger.info(f"SubprocessBridge.post_processing: dispatching to {self.language.value}")
        logger.debug(f"SubprocessBridge.post_processing: job_result type={type(job_result).__name__}")

        serialized = ResultSerializer.serialize(job_result)
        logger.debug(f"SubprocessBridge.post_processing: serialized result keys={list(serialized.keys()) if isinstance(serialized, dict) else type(serialized).__name__}")

        result = SubprocessDispatcher.dispatch(self.language, {
            "action"    : "post_processing",
            "job_result": serialized
        })

        status = result.get("status")
        logger.debug(f"SubprocessBridge.post_processing: JS status={status}")

        if status == "error":
            logger.error(f"SubprocessBridge.post_processing: JS error={result.get('error')}")
            raise RuntimeError(f"JS post_processing failed: {result.get('error')}")

        payload = result.get("result")
        if payload is None:
            raise RuntimeError("JS post_processing returned no 'result' field")

        logger.info(f"SubprocessBridge.post_processing: completed successfully | result type={type(payload).__name__}")
        return payload
