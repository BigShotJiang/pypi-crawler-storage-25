"""Comprehensive coverage tests for logs router to achieve 90%+ code coverage."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from api.models import LogLevel, LogsResponse
from api.routers.logs import (
    DEFAULT_LOG_LIMIT,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_POLL_INTERVAL,
    LogStreamerConfig,
    create_storage_provider,
    generate_log_sse_stream,
    get_execution_logs,
    get_project_log_file,
    get_project_logs,
    parse_log_entries,
    read_log_file,
    stream_logs,
    validate_project_name,
)


class TestDefaultConstants:
    """Tests for default constants."""

    def test_default_poll_interval(self):
        """Test DEFAULT_POLL_INTERVAL value."""
        assert DEFAULT_POLL_INTERVAL == 2

    def test_default_max_iterations(self):
        """Test DEFAULT_MAX_ITERATIONS value."""
        assert DEFAULT_MAX_ITERATIONS == 1000

    def test_default_log_limit(self):
        """Test DEFAULT_LOG_LIMIT value."""
        assert DEFAULT_LOG_LIMIT == 100


class TestCreateStorageProvider:
    """Tests for create_storage_provider factory function."""

    def test_returns_storage_instance(self):
        """Test factory returns storage instance."""
        result = create_storage_provider()
        assert result is not None
        assert hasattr(result, "list_projects")
        assert hasattr(result, "project_dir")


class TestReadLogFileEdgeCases:
    """Additional edge case tests for read_log_file."""

    def test_file_with_only_newlines(self, tmp_path):
        """Test file with only newline characters."""
        log_file = tmp_path / "execution.log"
        log_file.write_text("\n\n\n\n")

        result = read_log_file(log_file)
        assert result == []

    def test_file_with_tabs_and_spaces(self, tmp_path):
        """Test file with tabs and spaces."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('\t\t{"level": "INFO"}\n')

        result = read_log_file(log_file)
        assert len(result) == 1

    def test_file_with_unicode(self, tmp_path):
        """Test file with unicode characters."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Hello \\u4e16\\u754c"}\n')

        result = read_log_file(log_file)
        assert len(result) == 1
        assert result[0]["message"] == "Hello \u4e16\u754c"


class TestParseLogEntriesEdgeCases:
    """Additional edge case tests for parse_log_entries."""

    def test_parse_with_all_fields(self):
        """Test parsing entry with all fields."""
        log_data = [
            {
                "level": "INFO",
                "message": "Test",
                "timestamp": "2024-01-15T10:00:00",
                "source": "test_source",
                "execution_id": "exec1",
                "chapter": 5,
                "metadata": {"key": "value"},
            }
        ]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        entry = result[0]
        assert entry.source == "test_source"
        assert entry.execution_id == "exec1"
        assert entry.chapter == 5
        assert entry.metadata == {"key": "value"}

    def test_parse_skips_entries_with_invalid_level(self):
        """Test that invalid level entries are skipped."""
        log_data = [
            {"level": "INVALID_LEVEL", "message": "Invalid"},
            {"level": "INFO", "message": "Valid"},
        ]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].message == "Valid"

    def test_parse_with_missing_message(self):
        """Test parsing entry without message field."""
        log_data = [{"level": "INFO"}]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].message == ""


class TestValidateProjectNameEdgeCases:
    """Additional edge case tests for validate_project_name."""

    def test_project_name_with_slash_raises(self):
        """Test that project name with slash raises exception."""
        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("a/b")
        assert exc_info.value.status_code == 400

    def test_project_name_with_backslash_raises(self):
        """Test that project name with backslash raises exception."""
        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("a\\b")
        assert exc_info.value.status_code == 400


class TestGetProjectLogFileEdgeCases:
    """Additional edge case tests for get_project_log_file."""

    def test_special_characters_in_name(self, tmp_path):
        """Test log file path with special characters."""
        project_dir = tmp_path / "base"
        result = get_project_log_file(project_dir, "my_project_123")

        assert "my_project_123" in str(result)
        assert result.name == "execution.log"

    def test_long_project_name(self, tmp_path):
        """Test log file path with long project name."""
        project_dir = tmp_path / "base"
        long_name = "a" * 100
        result = get_project_log_file(project_dir, long_name)

        assert long_name in str(result)


class TestGetProjectLogsEndpointEdgeCases:
    """Additional edge case tests for get_project_logs endpoint."""

    async def test_get_logs_with_level_filter(self, tmp_path):
        """Test get_project_logs with level filter."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Test"}\n{"level": "ERROR", "message": "Error"}\n'
        )

        response = await get_project_logs(
            "test_project",
            level=LogLevel.ERROR,
            storage_provider=lambda: mock_provider,
        )

        assert isinstance(response, LogsResponse)
        assert len(response.logs) == 1
        assert response.logs[0].level == LogLevel.ERROR

    async def test_get_logs_pagination(self, tmp_path):
        """Test get_project_logs with pagination."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Log 1"}\n{"level": "INFO", "message": "Log 2"}\n'
        )

        response = await get_project_logs(
            "test_project",
            limit=1,
            offset=0,
            storage_provider=lambda: mock_provider,
        )

        assert response.limit == 1
        assert response.offset == 0

    async def test_get_logs_server_error_handling(self):
        """Test server error handling in get_project_logs."""
        mock_provider = MagicMock()
        mock_provider.list_projects.side_effect = RuntimeError("Database error")

        with pytest.raises(HTTPException) as exc_info:
            await get_project_logs(
                "test_project",
                storage_provider=lambda: mock_provider,
            )

        assert exc_info.value.status_code == 500


class TestGetExecutionLogsEndpointEdgeCases:
    """Additional edge case tests for get_execution_logs endpoint."""

    async def test_execution_not_found_returns_empty(self, tmp_path):
        """Test that non-existent execution returns empty logs."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text('{"level": "INFO", "execution_id": "exec1", "message": "Test"}\n')

        response = await get_execution_logs(
            "test_project",
            "nonexistent_exec",
            storage_provider=lambda: mock_provider,
        )

        assert response.logs == []
        assert response.total == 0

    async def test_execution_logs_invalid_name(self):
        """Test execution logs with invalid project name."""
        mock_provider = MagicMock()

        with pytest.raises(HTTPException) as exc_info:
            await get_execution_logs(
                "invalid/name",
                "exec1",
                storage_provider=lambda: mock_provider,
            )

        assert exc_info.value.status_code == 400

    async def test_execution_logs_server_error(self):
        """Test server error handling in get_execution_logs."""
        mock_provider = MagicMock()
        mock_provider.list_projects.side_effect = RuntimeError("Storage error")

        with pytest.raises(HTTPException) as exc_info:
            await get_execution_logs(
                "test_project",
                "exec1",
                storage_provider=lambda: mock_provider,
            )

        assert exc_info.value.status_code == 500


class TestStreamLogsEndpointEdgeCases:
    """Additional edge case tests for stream_logs endpoint."""

    async def test_stream_with_execution_id_filter(self, tmp_path):
        """Test streaming with execution ID filter."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "execution_id": "exec1", "message": "Test1"}\n'
            '{"level": "INFO", "execution_id": "exec2", "message": "Test2"}\n'
        )

        response = await stream_logs(
            "test_project",
            execution_id="exec1",
            storage_provider=lambda: mock_provider,
        )

        assert isinstance(response, StreamingResponse)
        assert response.media_type == "text/event-stream"

    async def test_stream_response_headers(self, tmp_path):
        """Test streaming response has correct headers."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        response = await stream_logs(
            "test_project",
            storage_provider=lambda: mock_provider,
        )

        assert "Cache-Control" in response.headers
        assert response.headers["Cache-Control"] == "no-cache"


class TestGenerateLogSSEStreamEdgeCases:
    """Additional edge case tests for generate_log_sse_stream."""

    async def test_generator_with_config_none(self, tmp_path):
        """Test generator handles None config."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        generator = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=None,
        )

        events = []
        async for event in generator:
            events.append(event)
            if len(events) >= 3:
                break

        assert len(events) >= 1

    async def test_generator_max_iterations_reached(self, tmp_path):
        """Test generator stops at max iterations."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        config = LogStreamerConfig(poll_interval=0.001, max_iterations=3)

        events = []
        async for event in generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=config,
        ):
            events.append(event)

        heartbeat_count = sum(1 for e in events if "heartbeat" in e)
        assert heartbeat_count <= 3

    async def test_generator_handles_execution_id_none(self, tmp_path):
        """Test generator handles None execution_id."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "Test1", "execution_id": "exec1"}\n'
            '{"level": "INFO", "message": "Test2", "execution_id": "exec2"}\n'
        )

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        events = []
        async for event in generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            execution_id=None,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1


class TestLogStreamerConfigEdgeCases:
    """Additional edge case tests for LogStreamerConfig."""

    def test_config_with_zero_values(self):
        """Test config with zero values."""
        config = LogStreamerConfig(poll_interval=0, max_iterations=0, limit=0)
        assert config.poll_interval == 0
        assert config.max_iterations == 0
        assert config.limit == 0

    def test_config_with_large_values(self):
        """Test config with large values."""
        config = LogStreamerConfig(
            poll_interval=1000,
            max_iterations=100000,
            limit=100000,
        )
        assert config.poll_interval == 1000
        assert config.max_iterations == 100000
        assert config.limit == 100000

    def test_config_with_negative_values(self):
        """Test config with negative values."""
        config = LogStreamerConfig(poll_interval=-1, max_iterations=-1)
        assert config.poll_interval == -1
        assert config.max_iterations == -1


class TestPaginationEdgeCases:
    """Additional edge case tests for pagination."""

    async def test_offset_beyond_total(self, tmp_path):
        """Test pagination with offset beyond total entries."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Log 1"}\n{"level": "INFO", "message": "Log 2"}\n'
        )

        response = await get_project_logs(
            "test_project",
            limit=10,
            offset=100,
            storage_provider=lambda: mock_provider,
        )

        assert len(response.logs) == 0
        assert response.total == 2
        assert response.has_more is False

    async def test_limit_exceeds_total(self, tmp_path):
        """Test pagination with limit exceeding total entries."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = tmp_path

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Log 1"}\n{"level": "INFO", "message": "Log 2"}\n'
        )

        response = await get_project_logs(
            "test_project",
            limit=1000,
            offset=0,
            storage_provider=lambda: mock_provider,
        )

        assert len(response.logs) == 2
        assert response.has_more is False


class TestErrorHandlingEdgeCases:
    """Additional error handling edge case tests."""

    async def test_storage_error_during_list_projects(self):
        """Test handling storage error during list_projects."""
        mock_provider = MagicMock()
        mock_provider.list_projects.side_effect = Exception("Storage error")

        with pytest.raises(HTTPException) as exc_info:
            await get_project_logs(
                "test_project",
                storage_provider=lambda: mock_provider,
            )

        assert exc_info.value.status_code == 500

    async def test_storage_error_during_file_read(self, tmp_path):
        """Test handling storage error during file read (invalid path returns empty logs)."""
        mock_provider = MagicMock()
        mock_provider.list_projects.return_value = ["test_project"]
        mock_provider.project_dir = Path("/nonexistent/path")

        response = await get_project_logs(
            "test_project",
            storage_provider=lambda: mock_provider,
        )

        assert len(response.logs) == 0
        assert response.total == 0


class TestAsyncEdgeCases:
    """Async edge case tests."""

    @pytest.mark.asyncio
    async def test_generator_cancellation(self, tmp_path):
        """Test generator handles cancellation gracefully."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        def storage_factory():
            return mock_storage

        generator = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=10),
        )

        count = 0
        try:
            async for event in generator:
                count += 1
                if count >= 2:
                    break
        finally:
            await generator.aclose()

        assert count == 2

    @pytest.mark.asyncio
    async def test_generator_handles_storage_exception(self, tmp_path):
        """Test generator handles storage exception gracefully."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path
        mock_storage.list_projects.side_effect = Exception("Storage error")

        def storage_factory():
            return mock_storage

        generator = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        )

        events = []
        async for event in generator:
            events.append(event)
            if len(events) >= 10:
                break

        await generator.aclose()

        assert any("error" in event for event in events)

    async def test_multiple_storage_factories(self, tmp_path):
        """Test using multiple storage factories."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage1 = MagicMock()
        mock_storage1.list_projects.return_value = ["test_project"]
        mock_storage1.project_dir = tmp_path

        mock_storage2 = MagicMock()
        mock_storage2.list_projects.return_value = ["test_project"]
        mock_storage2.project_dir = tmp_path

        async def storage_factory1():
            return mock_storage1

        async def storage_factory2():
            return mock_storage2

        generator1 = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory1,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        )

        generator2 = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory2,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        )

        events1 = []
        events2 = []

        async for event in generator1:
            events1.append(event)
            if len(events1) >= 3:
                break

        async for event in generator2:
            events2.append(event)
            if len(events2) >= 3:
                break

        assert len(events1) >= 1
        assert len(events2) >= 1
