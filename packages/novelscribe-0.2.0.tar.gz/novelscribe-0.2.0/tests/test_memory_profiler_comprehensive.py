"""Comprehensive tests for memory profiler coverage improvement."""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

from core.memory_profiler import (
    MemoryProfiler,
    MemoryProfilerConfig,
    MemorySnapshot,
)


class TestMemorySnapshot:
    """Test MemorySnapshot dataclass."""

    def test_initialization(self):
        """Test creating a memory snapshot."""
        timestamp = datetime.now(timezone.utc)
        snapshot = MemorySnapshot(
            timestamp=timestamp,
            total_memory_mb=100.0,
            component_usage={"test": 10.0},
            object_counts={"TestClass": 5},
            gc_stats={"gen_0": 100},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        assert snapshot.total_memory_mb == 100.0
        assert snapshot.component_usage["test"] == 10.0
        assert snapshot.object_counts["TestClass"] == 5

    def test_subtract_snapshots(self):
        """Test subtracting two snapshots."""
        timestamp1 = datetime.now(timezone.utc)
        timestamp2 = timestamp1 + timedelta(seconds=10)

        snapshot1 = MemorySnapshot(
            timestamp=timestamp1,
            total_memory_mb=100.0,
            component_usage={"test": 10.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        snapshot2 = MemorySnapshot(
            timestamp=timestamp2,
            total_memory_mb=150.0,
            component_usage={"test": 20.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )

        delta = snapshot2 - snapshot1
        assert delta["total_delta_mb"] == 50.0
        assert delta["component_delta_mb"]["test"] == 10.0
        assert delta["time_delta_seconds"] == 10.0

    def test_subtract_with_missing_component(self):
        """Test subtracting snapshots with missing components."""
        timestamp1 = datetime.now(timezone.utc)
        timestamp2 = timestamp1 + timedelta(seconds=10)

        snapshot1 = MemorySnapshot(
            timestamp=timestamp1,
            total_memory_mb=100.0,
            component_usage={"a": 10.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        snapshot2 = MemorySnapshot(
            timestamp=timestamp2,
            total_memory_mb=100.0,
            component_usage={"b": 20.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )

        delta = snapshot2 - snapshot1
        assert "a" in delta["component_delta_mb"]
        assert "b" in delta["component_delta_mb"]


class TestMemoryProfilerConfig:
    """Test MemoryProfilerConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = MemoryProfilerConfig()
        assert config.enabled is True
        assert config.snapshot_interval_seconds == 60
        assert config.max_snapshots == 1000
        assert config.track_object_counts is True
        assert config.track_gc_stats is True
        assert config.auto_cleanup is True

    def test_custom_config(self):
        """Test custom configuration."""
        config = MemoryProfilerConfig(
            enabled=False,
            snapshot_interval_seconds=30,
            max_snapshots=500,
            track_object_counts=False,
            component_filter=["test"],
        )
        assert config.enabled is False
        assert config.snapshot_interval_seconds == 30
        assert config.max_snapshots == 500
        assert config.track_object_counts is False
        assert config.component_filter == ["test"]


class TestMemoryProfiler:
    """Test MemoryProfiler class."""

    def test_initialization(self):
        """Test profiler initialization."""
        profiler = MemoryProfiler()
        assert profiler.config is not None
        assert profiler.snapshots == []
        assert profiler.profiling is False

    def test_initialization_with_config(self):
        """Test profiler initialization with custom config."""
        config = MemoryProfilerConfig(snapshot_interval_seconds=30)
        profiler = MemoryProfiler(config)
        assert profiler.config.snapshot_interval_seconds == 30

    def test_initialize_tracking(self):
        """Test tracking initialization."""
        profiler = MemoryProfiler()
        assert "context_manager" in profiler.component_trackers
        assert "chapter_cache" in profiler.component_trackers
        assert "llm_client" in profiler.component_trackers

    def test_take_snapshot_direct(self):
        """Test taking a memory snapshot by directly manipulating."""
        profiler = MemoryProfiler()
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        profiler.snapshots.append(snapshot)
        assert len(profiler.snapshots) == 1

    def test_take_multiple_snapshots_direct(self):
        """Test taking multiple snapshots directly."""
        profiler = MemoryProfiler()
        for _ in range(3):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)
        assert len(profiler.snapshots) == 3

    def test_auto_cleanup(self):
        """Test automatic snapshot cleanup."""
        config = MemoryProfilerConfig(max_snapshots=5, auto_cleanup=True)
        profiler = MemoryProfiler(config)
        for i in range(10):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0 + i,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)
        assert len(profiler.snapshots) == 10

    def test_start_profiling_sets_flag(self):
        """Test starting profiling sets flag."""
        profiler = MemoryProfiler()
        profiler.start_profiling(interval_seconds=1)
        assert profiler.profiling is True
        profiler.stop_profiling()

    def test_stop_profiling(self):
        """Test stopping profiling."""
        profiler = MemoryProfiler()
        profiler.profiling = True
        profiler.stop_event = MagicMock()
        profiler.stop_event.is_set.return_value = False

        profiler.stop_profiling()

        assert profiler.profiling is False
        profiler.stop_event.set.assert_called_once()

    def test_stop_profiling_not_started(self):
        """Test stopping profiling when not started."""
        profiler = MemoryProfiler()
        profiler.profiling = False

        profiler.stop_profiling()

        assert profiler.profiling is False

    def test_get_memory_report_no_snapshots(self):
        """Test memory report with no snapshots."""
        profiler = MemoryProfiler()
        report = profiler.get_memory_report()

        assert "error" in report

    def test_get_memory_report_with_snapshots(self):
        """Test memory report with snapshots."""
        profiler = MemoryProfiler()
        for _ in range(2):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        report = profiler.get_memory_report()

        assert "summary" in report
        assert "current_memory_mb" in report["summary"]
        assert "average_memory_mb" in report["summary"]

    def test_identify_leaks_no_snapshots(self):
        """Test leak detection with no snapshots."""
        profiler = MemoryProfiler()
        leaks = profiler.identify_leaks()

        assert leaks == []

    def test_identify_leaks_few_snapshots(self):
        """Test leak detection with insufficient snapshots."""
        profiler = MemoryProfiler()
        for _ in range(2):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        leaks = profiler.identify_leaks()

        assert leaks == []

    def test_identify_leaks_component_increasing(self):
        """Test leak detection with increasing component."""
        profiler = MemoryProfiler()

        for i in range(10):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0 + i,
                component_usage={"test_component": 10.0 + i},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        leaks = profiler.identify_leaks()

        assert len(leaks) > 0

    def test_identify_leaks_total_memory_increasing(self):
        """Test leak detection with total memory increasing."""
        profiler = MemoryProfiler()

        for i in range(10):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0 + i * 2,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        leaks = profiler.identify_leaks()

        assert len(leaks) > 0

    def test_get_component_stats(self):
        """Test getting component statistics."""
        profiler = MemoryProfiler()
        profiler.snapshots.append(
            MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0,
                component_usage={"test": 10.0},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
        )

        stats = profiler.get_component_stats()

        assert "test" in stats
        assert "current_mb" in stats["test"]
        assert "average_mb" in stats["test"]

    def test_get_component_stats_no_snapshots(self):
        """Test getting component stats with no snapshots."""
        profiler = MemoryProfiler()
        stats = profiler.get_component_stats()

        assert stats == {}

    def test_calculate_std_dev(self):
        """Test standard deviation calculation."""
        profiler = MemoryProfiler()
        values = [1.0, 2.0, 3.0, 4.0, 5.0]
        std_dev = profiler._calculate_std_dev(values)

        assert std_dev > 0

    def test_calculate_std_dev_single_value(self):
        """Test standard deviation with single value."""
        profiler = MemoryProfiler()
        std_dev = profiler._calculate_std_dev([1.0])

        assert std_dev == 0.0

    def test_calculate_std_dev_empty(self):
        """Test standard deviation with empty list."""
        profiler = MemoryProfiler()
        std_dev = profiler._calculate_std_dev([])

        assert std_dev == 0.0

    def test_compare_snapshots(self):
        """Test comparing two snapshots."""
        profiler = MemoryProfiler()
        for _ in range(2):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        comparison = profiler.compare_snapshots(0, 1)

        assert "memory_delta_mb" in comparison
        assert "time_delta_seconds" in comparison

    def test_compare_snapshots_invalid_index(self):
        """Test comparing with invalid indices."""
        profiler = MemoryProfiler()
        comparison = profiler.compare_snapshots(0, 1)

        assert "error" in comparison

    def test_clear_snapshots(self):
        """Test clearing snapshots."""
        profiler = MemoryProfiler()
        for _ in range(2):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        assert len(profiler.snapshots) == 2

        profiler.clear_snapshots()

        assert len(profiler.snapshots) == 0

    def test_export_snapshots(self, tmp_path):
        """Test exporting snapshots."""
        profiler = MemoryProfiler()
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        profiler.snapshots.append(snapshot)

        output_path = tmp_path / "snapshots.json"
        profiler.export_snapshots(output_path)

        assert output_path.exists()

        import json

        with open(output_path) as f:
            data = json.load(f)

        assert "snapshots" in data
        assert len(data["snapshots"]) == 1

    def test_track_component(self):
        """Test tracking a component."""
        profiler = MemoryProfiler()
        profiler.track_component("custom_component", 25.0)

        assert profiler.component_trackers["custom_component"] == 25.0

    def test_get_current_usage_with_snapshots(self):
        """Test getting current usage with snapshots."""
        profiler = MemoryProfiler()
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        profiler.snapshots.append(snapshot)

        usage = profiler.get_current_usage()

        assert usage == 100.0

    def test_get_current_usage_no_snapshots(self):
        """Test getting current usage with no snapshots."""
        profiler = MemoryProfiler()
        usage = profiler.get_current_usage()

        assert usage == 0.0

    def test_get_gc_stats(self):
        """Test getting GC statistics."""
        profiler = MemoryProfiler()
        stats = profiler._get_gc_stats()

        assert "collections" in stats
        assert "collected" in stats
        assert "uncollectable" in stats

    def test_estimate_module_size(self):
        """Test estimating module size."""
        profiler = MemoryProfiler()
        test_dict = {"key": "value", "nested": {"inner": "data"}}
        size = profiler._estimate_module_size(test_dict)

        assert size > 0

    def test_estimate_module_size_list(self):
        """Test estimating module size for list."""
        profiler = MemoryProfiler()
        test_list = [1, 2, 3, "string", {"dict": "value"}]
        size = profiler._estimate_module_size(test_list)

        assert size > 0

    def test_get_component_usage(self):
        """Test getting component usage."""
        profiler = MemoryProfiler()
        profiler.component_trackers["test_component"] = 10.0

        usage = profiler._get_component_usage()

        assert isinstance(usage, dict)

    def test_get_memory_report_with_component_trends(self):
        """Test memory report with component trends."""
        profiler = MemoryProfiler()

        for i in range(5):
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=100.0 + i,
                component_usage={"test_component": 10.0 + i},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        report = profiler.get_memory_report()

        assert "components" in report
        assert "test_component" in report["components"]

    def test_get_memory_report_system_info(self):
        """Test memory report includes system info."""
        profiler = MemoryProfiler()
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        profiler.snapshots.append(snapshot)

        report = profiler.get_memory_report()

        assert "system" in report
        assert "usage_percent" in report["system"]

    def test_compare_snapshots_different_memory(self):
        """Test comparing snapshots with different memory."""
        profiler = MemoryProfiler()

        timestamp1 = datetime.now(timezone.utc)
        timestamp2 = timestamp1 + timedelta(seconds=60)

        snapshot1 = MemorySnapshot(
            timestamp=timestamp1,
            total_memory_mb=100.0,
            component_usage={"a": 10.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        snapshot2 = MemorySnapshot(
            timestamp=timestamp2,
            total_memory_mb=200.0,
            component_usage={"a": 20.0, "b": 30.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=900.0,
            system_memory_mb=8000.0,
        )
        profiler.snapshots.append(snapshot1)
        profiler.snapshots.append(snapshot2)

        comparison = profiler.compare_snapshots(0, 1)

        assert comparison["memory_delta_mb"] == 100.0
        assert comparison["component_deltas_mb"]["a"] == 10.0
        assert comparison["component_deltas_mb"]["b"] == 30.0

    def test_identify_leaks_no_increasing_trend(self):
        """Test leak detection with no increasing trend."""
        profiler = MemoryProfiler()

        for i in range(10):
            value = 100.0 + (i % 3) * 2
            snapshot = MemorySnapshot(
                timestamp=datetime.now(timezone.utc),
                total_memory_mb=value,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        leaks = profiler.identify_leaks()

        assert len(leaks) == 0

    def test_profiling_loop_already_running(self):
        """Test starting profiling when already running."""
        profiler = MemoryProfiler()
        profiler.profiling = True

        profiler.start_profiling(interval_seconds=1)

        assert profiler.profiling is True

        profiler.stop_profiling()


class TestMemoryProfilerInternalMethods:
    """Test internal methods of MemoryProfiler."""

    def test_get_component_usage_with_module(self):
        """Test _get_component_usage with module in sys.modules."""
        import sys

        profiler = MemoryProfiler()
        profiler.component_trackers["test_component"] = 10.0

        sys.modules["test_component"] = type("MockModule", (), {"__name__": "test_component"})()

        try:
            result = profiler._get_component_usage()
            assert "test_component" in result
        finally:
            if "test_component" in sys.modules:
                del sys.modules["test_component"]

    def test_get_component_usage_without_module(self):
        """Test _get_component_usage without module returns empty dict."""
        profiler = MemoryProfiler()
        profiler.component_trackers["nonexistent_component"] = 10.0

        result = profiler._get_component_usage()
        assert "nonexistent_component" not in result

    def test_estimate_module_size_simple_object(self):
        """Test _estimate_module_size with simple object."""
        profiler = MemoryProfiler()

        size = profiler._estimate_module_size("test_string")
        assert size > 0

    def test_estimate_module_size_dict(self):
        """Test _estimate_module_size with dict."""
        profiler = MemoryProfiler()

        size = profiler._estimate_module_size({"key": "value"})
        assert size > 0

    def test_estimate_module_size_list(self):
        """Test _estimate_module_size with list."""
        profiler = MemoryProfiler()

        size = profiler._estimate_module_size([1, 2, 3])
        assert size > 0

    def test_estimate_module_size_object_with_dict(self):
        """Test _estimate_module_size with object containing __dict__."""
        profiler = MemoryProfiler()

        class MockObj:
            def __init__(self):
                self.attr1 = "value1"
                self.attr2 = {"nested": "dict"}

        obj = MockObj()
        size = profiler._estimate_module_size(obj)
        assert size > 0

    def test_get_object_counts(self):
        """Test _get_object_counts."""
        import sys

        profiler = MemoryProfiler()
        profiler.object_trackers["test_type"] = 10

        class MockModule:
            pass

        sys.modules["test_type"] = MockModule()

        try:
            profiler._get_object_counts()
        finally:
            if "test_type" in sys.modules:
                del sys.modules["test_type"]

    def test_get_object_counts_without_module(self):
        """Test _get_object_counts without module."""
        profiler = MemoryProfiler()
        profiler.object_trackers["nonexistent_type"] = 10

        result = profiler._get_object_counts()
        assert result == {}

    def test_get_gc_stats(self):
        """Test _get_gc_stats."""
        profiler = MemoryProfiler()

        stats = profiler._get_gc_stats()

        assert "collections" in stats
        assert "collected" in stats
        assert "uncollectable" in stats

    def test_get_memory_trend_no_snapshots(self):
        """Test get_memory_trend with no snapshots."""
        profiler = MemoryProfiler()

        trend = profiler.get_memory_trend()

        assert trend == "stable"

    def test_get_memory_trend_single_snapshot(self):
        """Test get_memory_trend with single snapshot."""
        profiler = MemoryProfiler()
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=1000.0,
            system_memory_mb=8000.0,
        )
        profiler.snapshots.append(snapshot)

        trend = profiler.get_memory_trend()

        assert trend == "stable"

    def test_get_memory_trend_increasing(self):
        """Test get_memory_trend with increasing memory."""
        profiler = MemoryProfiler()

        base_time = datetime.now(timezone.utc)
        for i in range(5):
            snapshot = MemorySnapshot(
                timestamp=base_time + timedelta(seconds=i * 10),
                total_memory_mb=100.0 + i * 10,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        trend = profiler.get_memory_trend()

        assert trend == "increasing"

    def test_get_memory_trend_decreasing(self):
        """Test get_memory_trend with decreasing memory."""
        profiler = MemoryProfiler()

        base_time = datetime.now(timezone.utc)
        for i in range(5):
            snapshot = MemorySnapshot(
                timestamp=base_time + timedelta(seconds=i * 10),
                total_memory_mb=140.0 - i * 10,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        trend = profiler.get_memory_trend()

        assert trend == "decreasing"

    def test_get_memory_trend_stable(self):
        """Test get_memory_trend with stable memory."""
        profiler = MemoryProfiler()

        base_time = datetime.now(timezone.utc)
        for i in range(5):
            snapshot = MemorySnapshot(
                timestamp=base_time + timedelta(seconds=i * 10),
                total_memory_mb=100.0 + (i % 2) * 5,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        trend = profiler.get_memory_trend()

        assert trend == "stable"

    def test_get_memory_trend_with_window(self):
        """Test get_memory_trend with time window."""
        profiler = MemoryProfiler()

        base_time = datetime.now(timezone.utc)
        for i in range(10):
            snapshot = MemorySnapshot(
                timestamp=base_time + timedelta(seconds=i * 10),
                total_memory_mb=100.0 + i * 10,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=1000.0,
                system_memory_mb=8000.0,
            )
            profiler.snapshots.append(snapshot)

        trend = profiler.get_memory_trend(window_seconds=5)

        assert trend in ["increasing", "stable"]
