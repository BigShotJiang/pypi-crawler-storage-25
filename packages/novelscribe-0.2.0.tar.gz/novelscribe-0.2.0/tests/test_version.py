"""Tests for version management system."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

from core.version import VersionManager, check_updates, get_version, notify_if_update_available


class TestVersionManager:
    """Test VersionManager class."""

    def test_version_manager_initialization(self):
        """Test VersionManager can be initialized."""
        manager = VersionManager()
        assert manager is not None
        assert hasattr(manager, "current_version")
        assert hasattr(manager, "package_name")
        assert manager.package_name == "novelscribe"

    def test_get_version_info(self):
        """Test getting version info."""
        manager = VersionManager()
        info = manager.get_version_info()
        assert isinstance(info, dict)
        assert "current" in info
        assert "package" in info
        assert info["package"] == "novelscribe"

    def test_is_newer_version_greater(self):
        """Test version comparison with greater version."""
        manager = VersionManager()
        assert manager._is_newer_version("99.0.0") is True

    def test_is_newer_version_equal(self):
        """Test version comparison with equal version."""
        manager = VersionManager()
        assert manager._is_newer_version(manager.current_version) is False

    def test_is_newer_version_smaller(self):
        """Test version comparison with smaller version."""
        manager = VersionManager()
        assert manager._is_newer_version("0.0.1") is False

    def test_get_upgrade_command(self):
        """Test getting upgrade command."""
        manager = VersionManager()
        cmd = manager._get_upgrade_command()
        assert isinstance(cmd, str)
        assert "upgrade" in cmd.lower() or "--upgrade" in cmd.lower()
        assert "novelscribe" in cmd

    @patch("requests.get")
    def test_check_for_updates_success(self, mock_get):
        """Test successful update check."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "99.0.0", "summary": "Test package"},
            "releases": {"99.0.0": [{"upload_time": "2024-01-01"}]},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        result = manager.check_for_updates(verbose=False, force=True)

        if result:
            assert result["update_available"] is True
            assert result["latest"] == "99.0.0"

    @patch("requests.get")
    def test_check_for_updates_no_update(self, mock_get):
        """Test when no update available."""
        manager = VersionManager()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": manager.current_version, "summary": "Test package"}
        }
        mock_get.return_value = mock_response

        result = manager.check_for_updates(verbose=False, force=True)

        if result:
            assert result["update_available"] is False

    @patch("requests.get")
    def test_check_for_updates_network_error(self, mock_get):
        """Test update check with network error."""
        import requests

        mock_get.side_effect = requests.RequestException("Network error")

        manager = VersionManager()
        result = manager.check_for_updates(verbose=False, force=True)

        assert result is None

    def test_cache_write_and_read(self, tmp_path):
        """Test update cache write and read cycle."""
        manager = VersionManager()
        cache_file = tmp_path / "update_cache.json"

        test_data = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }

        with patch.object(VersionManager, "__init__", lambda self: None):
            manager._write_cache = lambda d: cache_file.write_text(json.dumps(d, indent=2))
            manager._read_cache = lambda: (
                json.loads(cache_file.read_text()) if cache_file.exists() else None
            )
            manager._write_cache(test_data)

            cached = manager._read_cache()
            assert cached is not None
            assert cached["latest"] == "0.3.0"

    @patch.object(VersionManager, "check_for_updates")
    @patch("subprocess.run")
    def test_perform_self_update_success(self, mock_run, mock_check):
        """Test successful self-update."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }
        mock_run.return_value = MagicMock(returncode=0)

        manager = VersionManager()
        result = manager.perform_self_update()
        assert result is True

    @patch.object(VersionManager, "check_for_updates")
    def test_perform_self_update_already_latest(self, mock_check):
        """Test self-update when already on latest."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.2.0",
            "update_available": False,
        }

        manager = VersionManager()
        result = manager.perform_self_update()
        assert result is True

    @patch.object(VersionManager, "check_for_updates")
    def test_perform_self_update_check_fails(self, mock_check):
        """Test self-update when check fails."""
        mock_check.return_value = None

        manager = VersionManager()
        result = manager.perform_self_update()
        assert result is False


class TestVersionFunctions:
    """Test version module functions."""

    def test_get_version(self):
        """Test get_version function."""
        ver = get_version()
        assert isinstance(ver, str)
        assert len(ver) > 0

    def test_check_updates(self):
        """Test check_updates function."""
        result = check_updates()
        assert result is None or isinstance(result, dict)

    @patch.object(VersionManager, "check_for_updates")
    def test_notify_if_update_available_with_update(self, mock_check):
        """Test update notification shows when update available."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
            "upgrade_command": "pip install --upgrade novelscribe",
        }
        notify_if_update_available()

    @patch.object(VersionManager, "check_for_updates")
    def test_notify_if_update_available_no_update(self, mock_check):
        """Test update notification silent when no update."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.2.0",
            "update_available": False,
        }
        notify_if_update_available()
