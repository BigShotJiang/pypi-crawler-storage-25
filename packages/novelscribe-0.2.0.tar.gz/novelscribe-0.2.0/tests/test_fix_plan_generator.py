from datetime import datetime

import pytest

from core.continuity_parser import ContinuityIssue, ContinuityReport, IssueType, Severity
from core.fix_plan_generator import AgentType, FixInstruction, FixPlan, FixPlanGenerator


@pytest.fixture
def sample_report():
    issues = [
        ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Character acts out of personality",
            location="Chapter 5",
            suggestion="Review character traits",
        ),
        ContinuityIssue(
            issue_type=IssueType.PLOT,
            severity=Severity.MAJOR,
            description="Plot hole in chapter 10",
            location="Chapter 10",
            suggestion="Add explanation",
        ),
        ContinuityIssue(
            issue_type=IssueType.WORLD,
            severity=Severity.MINOR,
            description="Inconsistent magic system",
            location=None,
            suggestion="Clarify rules",
        ),
    ]

    return ContinuityReport(
        project_name="test_novel",
        timestamp=datetime.now(),
        total_issues=3,
        critical_count=1,
        major_count=1,
        minor_count=1,
        issues=issues,
        status="FAIL",
    )


class TestFixPlanGenerator:
    def test_initialization(self):
        generator = FixPlanGenerator()
        assert len(generator.agent_routing) == 5
        assert IssueType.CHARACTER in generator.agent_routing

    def test_generate_fix_plan(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        assert plan.project_name == "test_novel"
        assert plan.total_fixes == 3
        assert plan.critical_fixes == 1
        assert plan.major_fixes == 1
        assert plan.minor_fixes == 1
        assert len(plan.instructions) == 3

    def test_route_issue_to_agent(self):
        generator = FixPlanGenerator()

        character_issue = ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Test",
            location=None,
            suggestion=None,
        )

        agent = generator._route_issue_to_agent(character_issue)
        assert agent == AgentType.CHARACTER

    def test_calculate_priority_critical(self):
        generator = FixPlanGenerator()

        issue = ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Test",
            location=None,
            suggestion=None,
        )

        priority = generator._calculate_priority(issue, 0)
        assert 1 <= priority <= 20

    def test_calculate_priority_major(self):
        generator = FixPlanGenerator()

        issue = ContinuityIssue(
            issue_type=IssueType.PLOT,
            severity=Severity.MAJOR,
            description="Test",
            location=None,
            suggestion=None,
        )

        priority = generator._calculate_priority(issue, 0)
        assert 21 <= priority <= 40

    def test_calculate_priority_minor(self):
        generator = FixPlanGenerator()

        issue = ContinuityIssue(
            issue_type=IssueType.WORLD,
            severity=Severity.MINOR,
            description="Test",
            location=None,
            suggestion=None,
        )

        priority = generator._calculate_priority(issue, 0)
        assert 61 <= priority <= 100

    def test_create_fix_instruction(self):
        generator = FixPlanGenerator()

        issue = ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Character inconsistency",
            location="Chapter 5",
            suggestion="Fix character",
        )

        instruction = generator._create_fix_instruction(issue, 0, AgentType.CHARACTER, 10)

        assert instruction.issue_id == "issue_000"
        assert instruction.issue_type == IssueType.CHARACTER
        assert instruction.severity == Severity.CRITICAL
        assert instruction.agent == AgentType.CHARACTER
        assert instruction.priority == 10
        assert "Character inconsistency" in instruction.instructions

    def test_generate_agent_instructions(self):
        generator = FixPlanGenerator()

        issue = ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Test issue",
            location="Chapter 1",
            suggestion="Test suggestion",
        )

        instructions = generator._generate_agent_instructions(issue, AgentType.CHARACTER)

        assert "Test issue" in instructions
        assert "Test suggestion" in instructions
        assert "Chapter 1" in instructions
        assert "character consistency" in instructions.lower()

    def test_estimate_iterations(self):
        generator = FixPlanGenerator()

        estimate = generator._estimate_iterations(critical_fixes=3, major_fixes=5, minor_fixes=8)

        assert 1 <= estimate <= 5

    def test_filter_by_agent(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        character_fixes = generator.filter_by_agent(plan, AgentType.CHARACTER)

        assert len(character_fixes) == 1
        assert character_fixes[0].agent == AgentType.CHARACTER

    def test_filter_by_severity(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        critical_fixes = generator.filter_by_severity(plan, Severity.CRITICAL)

        assert len(critical_fixes) == 1
        assert critical_fixes[0].severity == Severity.CRITICAL

    def test_get_critical_fixes(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        critical = generator.get_critical_fixes(plan)

        assert len(critical) == 1
        assert all(f.severity == Severity.CRITICAL for f in critical)

    def test_get_major_fixes(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        major = generator.get_major_fixes(plan)

        assert len(major) == 1
        assert all(f.severity == Severity.MAJOR for f in major)

    def test_get_minor_fixes(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        minor = generator.get_minor_fixes(plan)

        assert len(minor) == 1
        assert all(f.severity == Severity.MINOR for f in minor)

    def test_create_batch_plan(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        batches = generator.create_batch_plan(plan, batch_size=2)

        assert len(batches) == 2
        assert len(batches[0]) == 2
        assert len(batches[1]) == 1

    def test_create_batch_plan_single_batch(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        batches = generator.create_batch_plan(plan, batch_size=10)

        assert len(batches) == 1
        assert len(batches[0]) == 3

    def test_instructions_sorted_by_priority(self, sample_report):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        priorities = [inst.priority for inst in plan.instructions]

        assert priorities == sorted(priorities)

    def test_save_fix_plan(self, sample_report, tmp_path):
        generator = FixPlanGenerator()
        plan = generator.generate_fix_plan(sample_report)

        output_path = tmp_path / "fix_plan.md"
        generator.save_fix_plan(plan, str(output_path))

        assert output_path.exists()

        content = output_path.read_text()
        assert "# Fix Plan" in content
        assert "test_novel" in content
        assert "Total Fixes: 3" in content


class TestFixInstruction:
    def test_instruction_creation(self):
        instruction = FixInstruction(
            issue_id="issue_001",
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            agent=AgentType.CHARACTER,
            instructions="Fix this issue",
            context={"location": "Chapter 1"},
            priority=10,
        )

        assert instruction.issue_id == "issue_001"
        assert instruction.priority == 10
        assert instruction.context["location"] == "Chapter 1"

    def test_instruction_default_context(self):
        instruction = FixInstruction(
            issue_id="issue_001",
            issue_type=IssueType.PLOT,
            severity=Severity.MAJOR,
            agent=AgentType.PLOT,
            instructions="Fix plot",
        )

        assert instruction.context == {}


class TestFixPlan:
    def test_plan_creation(self):
        instructions = [
            FixInstruction(
                issue_id=f"issue_{i:03d}",
                issue_type=IssueType.CHARACTER,
                severity=Severity.CRITICAL,
                agent=AgentType.CHARACTER,
                instructions="Fix",
            )
            for i in range(3)
        ]

        plan = FixPlan(
            project_name="test",
            timestamp=datetime.now(),
            total_fixes=3,
            critical_fixes=3,
            major_fixes=0,
            minor_fixes=0,
            estimated_iterations=2,
            instructions=instructions,
        )

        assert plan.total_fixes == 3
        assert plan.critical_fixes == 3
        assert len(plan.instructions) == 3
