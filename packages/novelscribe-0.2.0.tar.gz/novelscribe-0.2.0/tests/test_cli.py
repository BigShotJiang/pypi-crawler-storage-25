"""
Tests for main CLI module
"""

from unittest.mock import MagicMock

import pytest
from click.testing import CliRunner

from cli import ScribeCLI, cli, configure_logging


class TestScribeCLI:
    """Test cases for ScribeCLI class"""

    def test_get_command_existing(self):
        """Test getting an existing command"""
        group = ScribeCLI()
        group.commands["test_cmd"] = MagicMock()

        result = group.get_command(None, "test_cmd")

        assert result is not None
        assert result == group.commands["test_cmd"]

    def test_get_command_nonexistent_with_suggestions(self):
        """Test getting non-existent command with suggestions"""
        group = ScribeCLI()
        group.commands = {
            "run": MagicMock(),
            "agents": MagicMock(),
            "config": MagicMock(),
        }

        ctx = MagicMock()
        ctx.fail = MagicMock(side_effect=SystemExit(1))

        try:
            group.get_command(ctx, "ru")
            assert False, "Should have raised SystemExit"
        except SystemExit:
            pass

        ctx.fail.assert_called_once()

    def test_get_command_nonexistent_no_suggestions(self):
        """Test getting non-existent command without suggestions"""
        group = ScribeCLI()
        group.commands = {}

        ctx = MagicMock()
        ctx.fail = MagicMock(side_effect=SystemExit(1))

        try:
            group.get_command(ctx, "xyz")
            assert False, "Should have raised SystemExit"
        except SystemExit:
            pass

        ctx.fail.assert_called_once()


class TestConfigureLogging:
    """Test cases for configure_logging function"""

    def test_configure_logging_verbose_0(self):
        """Test logging with verbose=0"""
        # Should not raise exception
        configure_logging(verbose=0, debug=False)

    def test_configure_logging_verbose_1(self):
        """Test logging with verbose=1"""
        # Should not raise exception
        configure_logging(verbose=1, debug=False)

    def test_configure_logging_verbose_2(self):
        """Test logging with verbose=2"""
        # Should not raise exception
        configure_logging(verbose=2, debug=False)

    def test_configure_logging_debug(self):
        """Test logging with debug=True"""
        # Should not raise exception
        configure_logging(verbose=0, debug=True)


class TestCli:
    """Test cases for main CLI command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_cli_help(self, runner):
        """Test CLI --help"""
        result = runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        assert "Novel Writing Harness" in result.output
        assert "--help" in result.output or "help" in result.output

    def test_cli_version(self, runner):
        """Test CLI --version"""
        result = runner.invoke(cli, ["--version"])

        assert result.exit_code == 0

    def test_cli_with_verbose_flag(self, runner):
        """Test CLI with verbose flag"""
        result = runner.invoke(cli, ["-v", "--help"])

        assert result.exit_code == 0

    def test_cli_with_debug_flag(self, runner):
        """Test CLI with debug flag"""
        result = runner.invoke(cli, ["--debug", "--help"])

        assert result.exit_code == 0

    def test_cli_with_lang_option(self, runner):
        """Test CLI with language option"""
        result = runner.invoke(cli, ["--lang", "zh-CN", "--help"])

        assert result.exit_code == 0

    def test_cli_with_invalid_lang(self, runner):
        """Test CLI with invalid language option"""
        result = runner.invoke(cli, ["--lang", "invalid", "--help"])

        # Click will validate the choice and show an error
        assert result.exit_code in [0, 2]  # Either succeeds with help or fails with usage error

    def test_cli_nonexistent_command(self, runner):
        """Test CLI with non-existent command"""
        result = runner.invoke(cli, ["nonexistent_command"])

        assert result.exit_code != 0

    def test_cli_with_typo_command(self, runner):
        """Test CLI with typo in command name"""
        result = runner.invoke(cli, ["confg"])

        assert result.exit_code != 0
        assert "Did you mean" in result.output or "No such command" in result.output

    def test_cli_context_preservation(self, runner):
        """Test that CLI context is properly preserved"""
        result = runner.invoke(cli, ["--help"], catch_exceptions=False)

        assert result.exit_code == 0

    def test_cli_subcommands_exist(self, runner):
        """Test that all expected subcommands are available"""
        result = runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        # Check that help shows available commands
        output = result.output.lower()

        # Should have help available
        assert "--help" in output or "help" in output


class TestCliContext:
    """Test cases for CLI context management"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_verbose_context(self, runner):
        """Test that verbose flag is properly set in context"""
        result = runner.invoke(cli, ["-v", "--help"])

        assert result.exit_code == 0

    def test_debug_context(self, runner):
        """Test that debug flag is properly set in context"""
        result = runner.invoke(cli, ["--debug", "--help"])

        assert result.exit_code == 0

    def test_lang_context(self, runner):
        """Test that lang option is properly set in context"""
        result = runner.invoke(cli, ["--lang", "en", "--help"])

        assert result.exit_code == 0

    def test_multiple_options(self, runner):
        """Test CLI with multiple options"""
        result = runner.invoke(cli, ["-v", "--debug", "--help"])

        assert result.exit_code == 0
