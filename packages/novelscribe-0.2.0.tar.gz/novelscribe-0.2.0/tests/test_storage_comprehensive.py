"""Comprehensive tests for storage coverage improvement."""

from unittest.mock import patch

import pytest

from core.storage import (
    AgentDefinition,
    FileNotFoundError,
    FileParseError,
    FileStorage,
    FileWriteError,
    ProjectData,
    Storage,
    StorageBackend,
    StorageConfig,
    StorageError,
    StorageFactory,
    WorkflowDefinition,
)


class TestStorageExceptions:
    """Test storage exceptions."""

    def test_storage_error(self):
        """Test StorageError exception."""
        error = StorageError("Test error")
        assert str(error) == "Test error"
        assert isinstance(error, Exception)

    def test_file_not_found_error(self):
        """Test FileNotFoundError exception."""
        error = FileNotFoundError("/path/to/file", "File not found")
        assert "/path/to/file" in str(error)
        assert isinstance(error, StorageError)

    def test_file_parse_error(self):
        """Test FileParseError exception."""
        error = FileParseError("/path/to/file", "Invalid format")
        assert "/path/to/file" in str(error)
        assert isinstance(error, StorageError)

    def test_file_write_error(self):
        """Test FileWriteError exception."""
        error = FileWriteError("/path/to/file", "Permission denied")
        assert "/path/to/file" in str(error)
        assert isinstance(error, StorageError)


class TestStorageConfig:
    """Test StorageConfig model."""

    def test_config_creation(self):
        """Test creating storage config."""
        config = StorageConfig(base_path="/test/path")
        assert config.base_path == "/test/path"
        assert config.backend == "file"

    def test_config_defaults(self):
        """Test config with defaults."""
        config = StorageConfig(base_path="/test/path")
        assert config.backend == "file"
        assert config.cache_enabled is True

    def test_config_with_custom_backend(self):
        """Test config with custom backend."""
        config = StorageConfig(base_path="/test/path", backend="custom")
        assert config.backend == "custom"


class TestAgentDefinition:
    """Test AgentDefinition model."""

    def test_agent_creation(self):
        """Test creating agent definition."""
        agent = AgentDefinition(
            name="test_agent",
            description="Test description",
            model="gpt-4",
            system_prompt="Test prompt",
        )
        assert agent.name == "test_agent"
        assert agent.description == "Test description"
        assert agent.system_prompt == "Test prompt"

    def test_agent_with_defaults(self):
        """Test agent with default values."""
        agent = AgentDefinition(
            name="test_agent",
            description="Test description",
            model="gpt-4",
            system_prompt="Test prompt",
        )
        assert agent.temperature == 0.7
        assert agent.max_tokens == 4096
        assert agent.metadata == {}

    def test_agent_with_custom_fields(self):
        """Test agent with custom fields."""
        agent = AgentDefinition(
            name="test_agent",
            description="Test description",
            model="gpt-4",
            system_prompt="Test prompt",
            temperature=0.5,
            max_tokens=2048,
            metadata={"key": "value"},
        )
        assert agent.temperature == 0.5
        assert agent.max_tokens == 2048
        assert agent.metadata == {"key": "value"}


class TestWorkflowDefinition:
    """Test WorkflowDefinition model."""

    def test_workflow_creation(self):
        """Test creating workflow definition."""
        workflow = WorkflowDefinition(
            name="test_workflow",
            description="Test workflow",
            steps=[{"agent": "agent1"}],
        )
        assert workflow.name == "test_workflow"
        assert len(workflow.steps) == 1

    def test_workflow_with_description(self):
        """Test workflow with description."""
        workflow = WorkflowDefinition(
            name="test_workflow",
            description="Test description",
            steps=[],
        )
        assert workflow.description == "Test description"

    def test_workflow_with_metadata(self):
        """Test workflow with metadata."""
        workflow = WorkflowDefinition(
            name="test_workflow",
            description="Test workflow",
            steps=[],
            metadata={"version": "1.0"},
        )
        assert workflow.metadata == {"version": "1.0"}


class TestProjectData:
    """Test ProjectData class."""

    def test_project_data_creation(self):
        """Test creating project data."""
        project = ProjectData(name="test_project")
        assert project.name == "test_project"
        assert project.meta == {}
        assert project.chapters == []

    def test_project_data_with_fields(self):
        """Test project data with all fields."""
        project = ProjectData(
            name="test_project",
            meta={"key": "value"},
            chapters=["chapter1"],
        )
        assert project.meta == {"key": "value"}
        assert project.chapters == ["chapter1"]


class TestFileStorage:
    """Test FileStorage class."""

    def test_initialization(self, tmp_path):
        """Test file storage initialization."""
        config = StorageConfig(base_path=str(tmp_path / "storage"))
        storage = FileStorage(config)
        assert storage.config.base_path == str(tmp_path / "storage")
        assert storage.base_path == tmp_path / "storage"

    def test_read_markdown(self, tmp_path):
        """Test reading markdown file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        test_file = tmp_path / "test.md"
        test_file.write_text("# Test Content\n\nSome content")

        content = storage.read_markdown("test.md")
        assert "# Test Content" in content

    def test_read_markdown_not_found(self, tmp_path):
        """Test reading non-existent markdown file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        with pytest.raises(FileNotFoundError):
            storage.read_markdown("missing.md")

    def test_write_markdown(self, tmp_path):
        """Test writing markdown file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        storage.write_markdown("test.md", "# Test\n\nContent")

        test_file = tmp_path / "test.md"
        assert test_file.exists()
        content = test_file.read_text()
        assert "# Test" in content

    def test_write_markdown_creates_directories(self, tmp_path):
        """Test writing creates directories if needed."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        storage.write_markdown("subdir/test.md", "# Test")

        test_file = tmp_path / "subdir" / "test.md"
        assert test_file.exists()

    def test_write_markdown_failure(self, tmp_path):
        """Test write failure with mocked error."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        with patch("builtins.open") as mock_open:
            mock_open.side_effect = PermissionError("Denied")

            with pytest.raises(FileWriteError):
                storage.write_markdown("test.md", "# Test")

    def test_read_yaml(self, tmp_path):
        """Test reading YAML file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        test_file = tmp_path / "test.yaml"
        test_file.write_text("key: value\nlist:\n  - item1\n  - item2")

        data = storage.read_yaml("test.yaml")
        assert data["key"] == "value"
        assert data["list"] == ["item1", "item2"]

    def test_read_yaml_not_found(self, tmp_path):
        """Test reading non-existent YAML file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        with pytest.raises(FileNotFoundError):
            storage.read_yaml("missing.yaml")

    def test_read_yaml_invalid(self, tmp_path):
        """Test reading invalid YAML file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        test_file = tmp_path / "invalid.yaml"
        test_file.write_text("invalid: yaml: content:")

        with pytest.raises(FileParseError):
            storage.read_yaml("invalid.yaml")

    def test_write_yaml(self, tmp_path):
        """Test writing YAML file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        data = {"key": "value", "list": [1, 2, 3]}
        storage.write_yaml("test.yaml", data)

        test_file = tmp_path / "test.yaml"
        assert test_file.exists()

        read_data = storage.read_yaml("test.yaml")
        assert read_data == data

    def test_write_yaml_failure(self, tmp_path):
        """Test YAML write failure."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        with patch("builtins.open") as mock_open:
            mock_open.side_effect = PermissionError("Denied")

            with pytest.raises(FileWriteError):
                storage.write_yaml("test.yaml", {"key": "value"})

    def test_read_agent(self, tmp_path):
        """Test reading agent definition."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        agent_file = tmp_path / "agent.md"
        agent_file.write_text(
            "---\nname: test_agent\ndescription: Test agent description\n"
            "model: gpt-4\n---\n\nSystem prompt here"
        )

        agent = storage.read_agent("agent.md")
        assert agent.name == "test_agent"
        assert agent.description == "Test agent description"
        assert agent.system_prompt == "System prompt here"

    def test_read_agent_no_frontmatter(self, tmp_path):
        """Test reading agent without frontmatter."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        agent_file = tmp_path / "agent.md"
        agent_file.write_text("Simple instructions")

        with pytest.raises(FileParseError):
            storage.read_agent("agent.md")

    def test_read_agent_invalid_yaml(self, tmp_path):
        """Test reading agent with invalid YAML."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        agent_file = tmp_path / "agent.md"
        agent_file.write_text("---\ninvalid yaml\n---\nInstructions")

        with pytest.raises(FileParseError):
            storage.read_agent("agent.md")

    def test_read_agent_with_extended_fields(self, tmp_path):
        """Test reading agent with extended fields."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        agent_file = tmp_path / "agent.md"
        agent_file.write_text(
            "---\nname: test_agent\ndescription: Test agent\n"
            "model: gpt-4\ntemperature: 0.5\nmax_tokens: 2048\n---\n\n"
            "System prompt"
        )

        agent = storage.read_agent("agent.md")
        assert agent.model == "gpt-4"
        assert agent.temperature == 0.5
        assert agent.max_tokens == 2048

    def test_read_workflow(self, tmp_path):
        """Test reading workflow definition."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        workflow_file = tmp_path / "workflow.yaml"
        workflow_file.write_text(
            "name: test_workflow\ndescription: Test workflow\n"
            "description: Test\nsteps:\n  - agent: agent1\n  - agent: agent2"
        )

        workflow = storage.read_workflow("workflow.yaml")
        assert workflow.name == "test_workflow"
        assert len(workflow.steps) == 2

    def test_read_workflow_invalid_yaml(self, tmp_path):
        """Test reading workflow with invalid YAML."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        workflow_file = tmp_path / "workflow.yaml"
        workflow_file.write_text("invalid: yaml: content:")

        with pytest.raises(FileParseError):
            storage.read_workflow("workflow.yaml")

    def test_exists(self, tmp_path):
        """Test checking file existence."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        (tmp_path / "existing.txt").write_text("content")

        assert storage.exists("existing.txt") is True
        assert storage.exists("missing.txt") is False

    def test_delete(self, tmp_path):
        """Test deleting a file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        test_file = tmp_path / "test.txt"
        test_file.write_text("content")

        assert test_file.exists()
        storage.delete("test.txt")
        assert not test_file.exists()

    def test_delete_not_found(self, tmp_path):
        """Test deleting non-existent file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        storage.delete("missing.txt")

    def test_list_files(self, tmp_path):
        """Test listing files."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        (tmp_path / "file1.txt").write_text("content1")
        (tmp_path / "file2.txt").write_text("content2")
        (tmp_path / "file3.md").write_text("content3")

        txt_files = storage.list_files("", "*.txt")
        assert len(txt_files) == 2
        assert all(f.endswith(".txt") for f in txt_files)

    def test_list_files_subdirectory(self, tmp_path):
        """Test listing files in subdirectory."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        subdir = tmp_path / "subdir"
        subdir.mkdir()
        (subdir / "file1.txt").write_text("content")
        (subdir / "file2.txt").write_text("content")

        files = storage.list_files("subdir", "*.txt")
        assert len(files) == 2

    def test_list_files_nonexistent_directory(self, tmp_path):
        """Test listing files in non-existent directory."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        files = storage.list_files("subdir", "*.txt")
        assert len(files) == 0


class TestStorageFactory:
    """Test StorageFactory class."""

    def test_create_file_storage(self, tmp_path):
        """Test creating file storage."""
        config = StorageConfig(base_path=str(tmp_path / "storage"), backend="file")
        storage = StorageFactory.create(config)
        assert isinstance(storage, FileStorage)

    def test_register_backend(self):
        """Test registering custom backend."""

        class CustomBackend(StorageBackend):
            pass

        StorageFactory.register_backend("custom", CustomBackend)

        assert "custom" in StorageFactory._backends
        assert StorageFactory._backends["custom"] == CustomBackend

    def test_create_with_unsupported_backend(self, tmp_path):
        """Test creating storage with unsupported backend."""
        config = StorageConfig(base_path=str(tmp_path / "storage"), backend="unsupported")

        with pytest.raises(StorageError):
            StorageFactory.create(config)


class TestStorage:
    """Test Storage class."""

    def test_initialization(self):
        """Test storage initialization."""
        storage = Storage()
        assert storage._config is not None
        assert storage._backend is not None

    def test_list_projects(self, tmp_path):
        """Test listing projects."""
        projects_dir = tmp_path / ".novels"
        projects_dir.mkdir()

        (projects_dir / "project1").mkdir()
        (projects_dir / "project2").mkdir()

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        projects = storage.list_projects()

        assert len(projects) == 2
        assert "project1" in projects
        assert "project2" in projects

    def test_list_projects_empty(self, tmp_path):
        """Test listing projects when none exist."""
        projects_dir = tmp_path / ".novels"
        projects_dir.mkdir()

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        projects = storage.list_projects()

        assert projects == []

    def test_load_project(self, tmp_path):
        """Test loading a project."""
        projects_dir = tmp_path / ".novels"
        projects_dir.mkdir()

        project_dir = projects_dir / "test_project"
        project_dir.mkdir()

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        project = storage.load_project("test_project")

        assert project.name == "test_project"
        assert project.meta == {}

    def test_load_project_not_found(self, tmp_path):
        """Test loading non-existent project."""
        projects_dir = tmp_path / ".novels"

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        project = storage.load_project("missing_project")
        assert project.name == "missing_project"
        assert project.meta == {}
        assert project.chapters == []

    def test_save_project(self, tmp_path):
        """Test saving a project."""
        projects_dir = tmp_path / ".novels"

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        storage.save_project("test_project", meta={"key": "value"})

        project_dir = projects_dir / "test_project"
        assert project_dir.exists()

    def test_save_project_creates_directories(self, tmp_path):
        """Test saving project creates directories."""
        projects_dir = tmp_path / ".novels"

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        storage.save_project("new_project", meta={})

        project_dir = projects_dir / "new_project"
        assert project_dir.exists()

    def test_save_project_with_existing(self, tmp_path):
        """Test saving project that already exists."""
        projects_dir = tmp_path / ".novels"

        config = StorageConfig(base_path=str(projects_dir))
        storage = Storage()
        storage._config = config
        storage._backend = FileStorage(config)

        storage.save_project("test_project", meta={"updated": True})

        saved_project = storage.load_project("test_project")
        assert saved_project.meta == {"updated": True}


class TestStorageBackend:
    """Test StorageBackend abstract base class."""

    def test_abstract_methods(self):
        """Test that StorageBackend is abstract."""
        with pytest.raises(TypeError):
            StorageBackend()
