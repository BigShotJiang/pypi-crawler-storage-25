"""Tests for VerificationEngine."""

from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from core.continuity_parser import ReportStatus
from core.verification_engine import (
    VerificationConfig,
    VerificationEngine,
    VerificationResult,
)


class TestVerificationConfig:
    """Test VerificationConfig model."""

    def test_default_config(self):
        config = VerificationConfig()
        assert config.max_iterations == 5
        assert config.stop_on_pass is True
        assert config.stop_on_critical_only is True
        assert config.allow_major_issues is False
        assert config.allow_minor_issues is True
        assert config.max_minor_issues == 10

    def test_custom_config(self):
        config = VerificationConfig(
            max_iterations=10,
            stop_on_pass=False,
            allow_minor_issues=False,
        )
        assert config.max_iterations == 10
        assert config.stop_on_pass is False
        assert config.allow_minor_issues is False


class TestVerificationResult:
    """Test VerificationResult model."""

    def test_result_creation(self):
        result = VerificationResult(
            project_name="test_project",
            passed=True,
            total_iterations=3,
            final_status=ReportStatus.PASS,
            issues_remaining=0,
            critical_issues=0,
            major_issues=0,
            minor_issues=0,
            iterations=[],
            total_execution_time=10.5,
            verification_timestamp=datetime.now(timezone.utc),
        )
        assert result.project_name == "test_project"
        assert result.passed is True


class TestVerificationEngine:
    """Test VerificationEngine."""

    def test_initialization(self, tmp_path):
        config = VerificationConfig()
        engine = VerificationEngine(str(tmp_path), config)
        assert engine.project_dir == tmp_path
        assert engine.config == config

    def test_map_iteration_status_passed(self, tmp_path):
        from core.rewrite_loop import IterationStatus

        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        status = engine._map_iteration_status(IterationStatus.PASSED)
        assert status == ReportStatus.PASS

    def test_map_iteration_status_max_limit(self, tmp_path):
        from core.rewrite_loop import IterationStatus

        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        status = engine._map_iteration_status(IterationStatus.MAX_LIMIT_REACHED)
        assert status == ReportStatus.FAIL

    def test_map_iteration_status_unknown(self, tmp_path):
        from core.rewrite_loop import IterationStatus

        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        status = engine._map_iteration_status(IterationStatus.STOPPED)
        assert status == ReportStatus.FAIL

    @patch("core.verification_engine.RewriteLoopExecutor")
    def test_verify_project_success(self, mock_executor_class, tmp_path):
        from core.rewrite_loop import IterationStatus, RewriteIteration

        mock_iteration = RewriteIteration(
            iteration_number=1,
            timestamp=datetime.now(timezone.utc),
            status=IterationStatus.PASSED,
            issues_before=2,
            issues_after=0,
            critical_before=0,
            critical_after=0,
            major_before=0,
            major_after=0,
            minor_before=2,
            minor_after=0,
            fixes_applied=2,
            execution_time=5.0,
        )

        mock_executor = Mock()
        mock_executor.iterations = [mock_iteration]
        mock_executor.execute_loop.return_value = mock_iteration
        mock_executor_class.return_value = mock_executor

        config = VerificationConfig(generate_report=False, save_iteration_log=False)
        engine = VerificationEngine(str(tmp_path), config)
        result = engine.verify_project()

        assert result.passed is True
        assert result.total_iterations == 1

    @patch("core.verification_engine.RewriteLoopExecutor")
    def test_verify_project_failure(self, mock_executor_class, tmp_path):
        from core.rewrite_loop import IterationStatus, RewriteIteration

        mock_iteration = RewriteIteration(
            iteration_number=1,
            timestamp=datetime.now(timezone.utc),
            status=IterationStatus.MAX_LIMIT_REACHED,
            issues_before=10,
            issues_after=5,
            critical_before=2,
            critical_after=1,
            major_before=5,
            major_after=2,
            minor_before=3,
            minor_after=2,
            fixes_applied=5,
            execution_time=10.0,
        )

        mock_executor = Mock()
        mock_executor.iterations = [mock_iteration]
        mock_executor.execute_loop.return_value = mock_iteration
        mock_executor_class.return_value = mock_executor

        config = VerificationConfig(generate_report=False, save_iteration_log=False)
        engine = VerificationEngine(str(tmp_path), config)
        result = engine.verify_project()

        assert result.passed is False
        assert result.issues_remaining == 5

    @patch("core.verification_engine.RewriteLoopExecutor")
    def test_verify_project_saves_report(self, mock_executor_class, tmp_path):
        from core.rewrite_loop import IterationStatus, RewriteIteration

        mock_iteration = RewriteIteration(
            iteration_number=1,
            timestamp=datetime.now(timezone.utc),
            status=IterationStatus.PASSED,
            issues_before=2,
            issues_after=0,
            critical_before=0,
            critical_after=0,
            major_before=0,
            major_after=0,
            minor_before=2,
            minor_after=0,
            fixes_applied=2,
            execution_time=5.0,
        )

        mock_executor = Mock()
        mock_executor.iterations = [mock_iteration]
        mock_executor.execute_loop.return_value = mock_iteration
        mock_executor_class.return_value = mock_executor

        config = VerificationConfig(generate_report=True, save_iteration_log=False)
        engine = VerificationEngine(str(tmp_path), config)
        engine.verify_project()

        report_path = tmp_path / "verification_report.md"
        assert report_path.exists()

    @patch("core.verification_engine.RewriteLoopExecutor")
    def test_verify_project_saves_log(self, mock_executor_class, tmp_path):
        from core.rewrite_loop import IterationStatus, RewriteIteration

        mock_iteration = RewriteIteration(
            iteration_number=1,
            timestamp=datetime.now(timezone.utc),
            status=IterationStatus.PASSED,
            issues_before=2,
            issues_after=0,
            critical_before=0,
            critical_after=0,
            major_before=0,
            major_after=0,
            minor_before=2,
            minor_after=0,
            fixes_applied=2,
            execution_time=5.0,
        )

        mock_executor = Mock()
        mock_executor.iterations = [mock_iteration]
        mock_executor.execute_loop.return_value = mock_iteration
        mock_executor.save_iteration_log = Mock(
            side_effect=lambda path: Path(path).write_text("log")
        )
        mock_executor_class.return_value = mock_executor

        config = VerificationConfig(generate_report=False, save_iteration_log=True)
        engine = VerificationEngine(str(tmp_path), config)
        engine.verify_project()

        log_path = tmp_path / "verification_log.md"
        assert log_path.exists()

    def test_verify_chapter_not_found(self, tmp_path):
        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        with pytest.raises(FileNotFoundError):
            engine.verify_chapter(999)

    @patch("core.verification_engine.RewriteLoopExecutor")
    def test_verify_chapter_success(self, mock_executor_class, tmp_path):
        from core.rewrite_loop import IterationStatus, RewriteIteration

        chapter_dir = tmp_path / "chapter_001"
        chapter_dir.mkdir()

        mock_iteration = RewriteIteration(
            iteration_number=1,
            timestamp=datetime.now(timezone.utc),
            status=IterationStatus.PASSED,
            issues_before=2,
            issues_after=0,
            critical_before=0,
            critical_after=0,
            major_before=0,
            major_after=0,
            minor_before=2,
            minor_after=0,
            fixes_applied=2,
            execution_time=5.0,
        )

        mock_executor = Mock()
        mock_executor.iterations = [mock_iteration]
        mock_executor.execute_loop.return_value = mock_iteration
        mock_executor_class.return_value = mock_executor

        config = VerificationConfig(generate_report=False, save_iteration_log=False)
        engine = VerificationEngine(str(tmp_path), config)
        result = engine.verify_chapter(1)

        assert result.passed is True
        assert "_chapter_1" in result.project_name

    def test_quick_verify_file_not_found(self, tmp_path):
        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        with pytest.raises(RuntimeError, match="No continuity report found"):
            engine.quick_verify()

    def test_quick_verify_success(self, tmp_path):
        report_content = """# Continuity Report: Test

**Status:** FAIL

## Summary
- Total Issues: 3
- Critical: 1
- Major: 1
- Minor: 1

## Issues

### Issue 1
- **Type:** character
- **Severity:** critical
"""
        report_file = tmp_path / "continuity_report.md"
        report_file.write_text(report_content)

        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        report = engine.quick_verify()

        assert report.total_issues == 1

    def test_get_fix_plan_no_report(self, tmp_path):
        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        fix_plan = engine.get_fix_plan()
        assert fix_plan is None

    def test_save_fix_plan_no_report(self, tmp_path):
        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        with pytest.raises(RuntimeError, match="Cannot generate fix plan"):
            engine.save_fix_plan()

    def test_get_progress_estimate_no_data(self, tmp_path):
        engine = VerificationEngine(str(tmp_path), VerificationConfig())
        estimate = engine.get_progress_estimate()
        assert "No verification data available" in estimate
