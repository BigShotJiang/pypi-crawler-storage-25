"""
Tests for core.suggestions.learning_tracker module.
"""

from datetime import datetime, timedelta
from unittest.mock import MagicMock

import pytest

from core.suggestions.learning_tracker import LearningTracker
from core.suggestions.models import (
    Suggestion,
    SuggestionCategory,
    SuggestionEvent,
    TriggerType,
)


class TestLearningTracker:
    """Test LearningTracker class."""

    @pytest.fixture
    def mock_kb(self):
        """Create mock knowledge base."""
        kb = MagicMock()
        kb.get_suggestion = MagicMock(return_value=None)
        kb.update_acceptance_rate = MagicMock()
        kb.get_top_suggestions = MagicMock(return_value=[])
        kb.promote_to_global = MagicMock(return_value=True)
        return kb

    @pytest.fixture
    def tracker(self, mock_kb, tmp_path):
        """Create LearningTracker with temporary directory."""
        events_dir = tmp_path / "events"
        events_dir.mkdir()
        return LearningTracker(kb=mock_kb, events_dir=events_dir, promotion_threshold=5)

    @pytest.fixture
    def sample_suggestion(self):
        """Create sample suggestion."""
        return Suggestion(
            id="sug_001",
            name="Test Suggestion",
            description="Test description",
            category=SuggestionCategory.GENRE,
            acceptance_rate=0.7,
            acceptance_count=10,
            accepted_count=7,
        )

    @pytest.fixture
    def sample_event(self):
        """Create sample suggestion event."""
        return SuggestionEvent(
            suggestion_id="sug_001",
            project_id="proj_001",
            user_choice="accepted",
            suggestion_category=SuggestionCategory.GENRE,
            trigger_type=TriggerType.DECISION_POINT,
            accepted_dynamic=True,
            acceptance_prompt_response=True,
        )

    def test_init_creates_events_directory(self, mock_kb, tmp_path):
        """Test initialization creates events directory."""
        events_dir = tmp_path / "events"
        tracker = LearningTracker(kb=mock_kb, events_dir=events_dir)
        assert tracker.events_dir.exists()
        assert tracker.promotion_threshold == 5

    def test_init_with_custom_threshold(self, mock_kb, tmp_path):
        """Test initialization with custom promotion threshold."""
        events_dir = tmp_path / "events"
        tracker = LearningTracker(kb=mock_kb, events_dir=events_dir, promotion_threshold=10)
        assert tracker.promotion_threshold == 10

    def test_record_acceptance(self, tracker, sample_event, mock_kb):
        """Test recording a suggestion acceptance event."""
        tracker.record_acceptance(sample_event)

        mock_kb.update_acceptance_rate.assert_called_once_with("sug_001", True)
        assert tracker._pending_promotions["sug_001"] == 1

    def test_record_acceptance_not_accepted(self, tracker, mock_kb):
        """Test recording a rejected suggestion."""
        event = SuggestionEvent(
            suggestion_id="sug_001",
            project_id="proj_001",
            user_choice="rejected",
            suggestion_category=SuggestionCategory.GENRE,
            trigger_type=TriggerType.DECISION_POINT,
            accepted_dynamic=False,
        )

        tracker.record_acceptance(event)

        mock_kb.update_acceptance_rate.assert_called_once_with("sug_001", False)
        assert "sug_001" not in tracker._pending_promotions

    def test_record_acceptance_async(self, tracker, sample_event):
        """Test async recording of acceptance."""
        import asyncio

        async def test_async():
            await tracker.record_acceptance_async(sample_event)
            assert tracker._pending_promotions["sug_001"] == 1

        asyncio.run(test_async())

    def test_get_acceptance_rate(self, tracker, mock_kb, sample_suggestion):
        """Test getting acceptance rate for a suggestion."""
        mock_kb.get_suggestion.return_value = sample_suggestion

        rate = tracker.get_acceptance_rate("sug_001")
        assert rate == 0.7

    def test_get_acceptance_rate_not_found(self, tracker, mock_kb):
        """Test getting acceptance rate for non-existent suggestion."""
        mock_kb.get_suggestion.return_value = None

        rate = tracker.get_acceptance_rate("nonexistent")
        assert rate == 0.5

    def test_get_suggestion_events(self, tracker, sample_event):
        """Test getting events for a specific suggestion."""
        tracker.record_acceptance(sample_event)

        events = tracker.get_suggestion_events("sug_001")
        assert len(events) == 1
        assert events[0].suggestion_id == "sug_001"

    def test_get_suggestion_events_limit(self, tracker, sample_event):
        """Test getting events with limit."""
        for i in range(10):
            tracker.record_acceptance(sample_event)

        events = tracker.get_suggestion_events("sug_001", limit=5)
        assert len(events) == 5

    def test_get_top_suggestions(self, tracker, mock_kb, sample_suggestion):
        """Test getting top suggestions by category."""
        mock_kb.get_top_suggestions.return_value = [sample_suggestion]

        suggestions = tracker.get_top_suggestions(SuggestionCategory.GENRE, "en", 10)
        assert len(suggestions) == 1
        assert suggestions[0].id == "sug_001"

    def test_should_promote_below_threshold(self, tracker):
        """Test promotion check below threshold."""
        tracker._pending_promotions["sug_001"] = 3
        assert not tracker.should_promote("sug_001", threshold=5)

    def test_should_promote_at_threshold(self, tracker):
        """Test promotion check at threshold."""
        tracker._pending_promotions["sug_001"] = 5
        assert tracker.should_promote("sug_001", threshold=5)

    def test_should_promote_not_pending(self, tracker):
        """Test promotion check for non-pending suggestion."""
        assert not tracker.should_promote("nonexistent", threshold=5)

    def test_promote_to_knowledge_base(self, tracker, mock_kb):
        """Test promoting suggestion to knowledge base."""
        tracker._pending_promotions["sug_001"] = 5

        result = tracker.promote_to_knowledge_base("sug_001")
        assert result is True
        assert "sug_001" not in tracker._pending_promotions

    def test_promote_to_knowledge_base_failure(self, tracker, mock_kb):
        """Test promotion failure when KB rejects it."""
        mock_kb.promote_to_global.return_value = False
        tracker._pending_promotions["sug_001"] = 5

        result = tracker.promote_to_knowledge_base("sug_001")
        assert result is False
        assert "sug_001" in tracker._pending_promotions

    def test_promote_to_learned(self, tracker):
        """Test promote_to_learned is an alias."""
        tracker._pending_promotions["sug_001"] = 5

        result = tracker.promote_to_learned("sug_001")
        assert result is True

    def test_check_and_auto_promote_ready(self, tracker):
        """Test auto-promotion when ready."""
        tracker._pending_promotions["sug_001"] = 5

        result = tracker.check_and_auto_promote("sug_001")
        assert result is True

    def test_check_and_auto_promote_not_ready(self, tracker):
        """Test auto-promotion when not ready."""
        tracker._pending_promotions["sug_001"] = 3

        result = tracker.check_and_auto_promote("sug_001")
        assert result is False

    def test_get_pending_promotions(self, tracker):
        """Test getting pending promotions."""
        tracker._pending_promotions["sug_001"] = 3
        tracker._pending_promotions["sug_002"] = 7

        pending = tracker.get_pending_promotions()
        assert pending["sug_001"] == 3
        assert pending["sug_002"] == 7

    def test_get_pending_promotions_detailed(self, tracker, mock_kb, sample_suggestion):
        """Test getting detailed pending promotions."""
        tracker._pending_promotions["sug_001"] = 3
        mock_kb.get_suggestion.return_value = sample_suggestion

        detailed = tracker.get_pending_promotions_detailed(threshold=5)
        assert len(detailed) == 1
        assert detailed[0]["suggestion"].id == "sug_001"
        assert detailed[0]["acceptance_count"] == 3
        assert detailed[0]["ready_for_promotion"] is False

    def test_get_pending_promotions_detailed_ready(self, tracker, mock_kb, sample_suggestion):
        """Test detailed pending promotions that are ready."""
        tracker._pending_promotions["sug_001"] = 5
        mock_kb.get_suggestion.return_value = sample_suggestion

        detailed = tracker.get_pending_promotions_detailed(threshold=5)
        assert len(detailed) == 1
        assert detailed[0]["ready_for_promotion"] is True

    def test_get_usage_analytics_no_events(self, tracker):
        """Test usage analytics with no events."""
        analytics = tracker.get_usage_analytics(days=7)
        assert analytics["total_events"] == 0
        assert analytics["dynamic_acceptance_rate"] == 0.0

    def test_get_usage_analytics_with_events(self, tracker, sample_event):
        """Test usage analytics with events."""
        tracker.record_acceptance(sample_event)

        analytics = tracker.get_usage_analytics(days=7)
        assert analytics["total_events"] == 1
        assert analytics["dynamic_acceptance_rate"] == 1.0

    def test_get_usage_analytics_mixed_acceptance(self, tracker):
        """Test usage analytics with mixed acceptance rates."""
        for i in range(10):
            event = SuggestionEvent(
                suggestion_id=f"sug_{i}",
                project_id="proj_001",
                user_choice="accepted" if i < 7 else "rejected",
                suggestion_category=SuggestionCategory.GENRE,
                trigger_type=TriggerType.DECISION_POINT,
                accepted_dynamic=i < 7,
            )
            tracker.record_acceptance(event)

        analytics = tracker.get_usage_analytics(days=7)
        assert analytics["total_events"] == 10
        assert analytics["dynamic_acceptance_rate"] == 0.7

    def test_generate_promotion_report(self, tracker):
        """Test generating promotion report with no data."""
        report = tracker.generate_promotion_report(days=7)
        assert "period_days" in report
        assert "analytics" in report
        assert "ready_for_promotion" in report
        assert "near_threshold" in report
        assert "top_performers" in report

    def test_get_learning_insights(self, tracker):
        """Test getting learning insights."""
        insights = tracker.get_learning_insights(days=30)
        assert "period_days" in insights
        assert "total_events" in insights
        assert "overall_acceptance_rate" in insights
        assert "category_performance" in insights
        assert "trigger_performance" in insights
        assert "recommendations" in insights

    def test_get_suggestion_history(self, tracker, sample_event):
        """Test getting suggestion history for a project."""
        tracker.record_acceptance(sample_event)

        history = tracker.get_suggestion_history("proj_001")
        assert len(history) == 1
        assert history[0]["event"].suggestion_id == "sug_001"

    def test_get_suggestion_history_limit(self, tracker):
        """Test getting suggestion history with limit."""
        for i in range(10):
            event = SuggestionEvent(
                suggestion_id=f"sug_{i}",
                project_id="proj_001",
                user_choice="accepted",
                suggestion_category=SuggestionCategory.GENRE,
                trigger_type=TriggerType.DECISION_POINT,
                accepted_dynamic=True,
            )
            tracker.record_acceptance(event)

        history = tracker.get_suggestion_history("proj_001", limit=5)
        assert len(history) == 5

    def test_save_and_load_pending_promotions(self, tracker, tmp_path):
        """Test saving and loading pending promotions."""
        tracker._pending_promotions["sug_001"] = 3
        tracker._save_pending_promotions()

        new_tracker = LearningTracker(
            kb=tracker.kb, events_dir=tracker.events_dir, promotion_threshold=5
        )
        assert new_tracker._pending_promotions["sug_001"] == 3


class TestLearningTrackerEdgeCases:
    """Test edge cases and error handling."""

    @pytest.fixture
    def mock_kb(self):
        """Create mock knowledge base."""
        kb = MagicMock()
        kb.get_suggestion = MagicMock(return_value=None)
        kb.update_acceptance_rate = MagicMock()
        kb.get_top_suggestions = MagicMock(return_value=[])
        kb.promote_to_global = MagicMock(return_value=True)
        return kb

    @pytest.fixture
    def tracker(self, mock_kb, tmp_path):
        """Create LearningTracker with temporary directory."""
        events_dir = tmp_path / "events"
        events_dir.mkdir()
        return LearningTracker(kb=mock_kb, events_dir=events_dir)

    def test_record_acceptance_handles_exception(self, tracker, mock_kb):
        """Test recording acceptance handles exceptions gracefully."""
        mock_kb.update_acceptance_rate.side_effect = Exception("KB error")

        event = SuggestionEvent(
            suggestion_id="sug_001",
            project_id="proj_001",
            user_choice="accepted",
            suggestion_category=SuggestionCategory.GENRE,
            trigger_type=TriggerType.DECISION_POINT,
            accepted_dynamic=True,
        )

        tracker.record_acceptance(event)

    def test_get_suggestion_events_handles_invalid_json(self, tracker, tmp_path):
        """Test getting events handles invalid JSON gracefully."""
        events_file = tracker._events_file
        with open(events_file, "w") as f:
            json_line_1 = (
                '{"suggestion_id": "sug_001", "project_id": "proj_001", '
                '"user_choice": "accepted", "trigger_type": "decision_point", '
                '"suggestion_category": "genre"}\n'
            )
            f.write(json_line_1)
            f.write("invalid json\n")
            json_line_2 = (
                '{"suggestion_id": "sug_001", "project_id": "proj_002", '
                '"user_choice": "accepted", "trigger_type": "decision_point", '
                '"suggestion_category": "genre"}\n'
            )
            f.write(json_line_2)

        events = tracker.get_suggestion_events("sug_001")
        assert len(events) == 2

    def test_load_pending_promotions_handles_invalid_json(self, tmp_path, mock_kb):
        """Test loading pending promotions handles invalid JSON."""
        events_dir = tmp_path / "events"
        events_dir.mkdir()
        pending_file = events_dir / "pending_promotions.json"

        with open(pending_file, "w") as f:
            f.write("invalid json")

        tracker = LearningTracker(kb=mock_kb, events_dir=events_dir)
        assert len(tracker._pending_promotions) == 0

    def test_get_usage_analytics_handles_old_events(self, tracker):
        """Test analytics filters out old events."""
        old_event = SuggestionEvent(
            suggestion_id="sug_001",
            project_id="proj_001",
            user_choice="accepted",
            suggestion_category=SuggestionCategory.GENRE,
            trigger_type=TriggerType.DECISION_POINT,
            accepted_dynamic=True,
            timestamp=datetime.now() - timedelta(days=20),
        )

        tracker.record_acceptance(old_event)

        analytics = tracker.get_usage_analytics(days=7)
        assert analytics["total_events"] == 0

    def test_get_learning_insights_with_recommendations(self, tracker):
        """Test learning insights generates recommendations."""
        insights = tracker.get_learning_insights(days=30)
        assert len(insights["recommendations"]) > 0
        assert isinstance(insights["recommendations"], list)
