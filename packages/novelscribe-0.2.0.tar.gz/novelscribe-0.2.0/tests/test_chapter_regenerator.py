"""Tests for chapter_regenerator.py."""

from unittest.mock import Mock, patch

import pytest

from core.chapter_regenerator import (
    ChapterRegenerator,
    RegenerationConfig,
    RegenerationResult,
    RegenerationStrategy,
)


class TestRegenerationStrategy:
    """Tests for RegenerationStrategy enum."""

    def test_strategy_values(self):
        """Test RegenerationStrategy enum values."""
        assert RegenerationStrategy.FULL == "full"
        assert RegenerationStrategy.TARGETED == "targeted"
        assert RegenerationStrategy.CONTINUITY == "continuity"
        assert RegenerationStrategy.STYLE == "style"


class TestRegenerationConfig:
    """Tests for RegenerationConfig model."""

    def test_config_creation_full(self):
        """Test creating RegenerationConfig with FULL strategy."""
        config = RegenerationConfig(
            strategy=RegenerationStrategy.FULL,
            preserve_dialogue=True,
            preserve_action_scenes=True,
            fix_issues=["issue1", "issue2"],
            style_target="formal",
            max_word_count=1000,
            quality_threshold=0.8,
            story_context={"characters": ["Alice", "Bob"]},
        )
        assert config.strategy == RegenerationStrategy.FULL
        assert config.preserve_dialogue is True
        assert config.preserve_action_scenes is True
        assert config.fix_issues == ["issue1", "issue2"]
        assert config.style_target == "formal"
        assert config.max_word_count == 1000
        assert config.quality_threshold == 0.8
        assert config.story_context == {"characters": ["Alice", "Bob"]}

    def test_config_defaults(self):
        """Test RegenerationConfig with default values."""
        config = RegenerationConfig(strategy=RegenerationStrategy.TARGETED)
        assert config.preserve_dialogue is True
        assert config.preserve_action_scenes is True
        assert config.fix_issues == []
        assert config.style_target is None
        assert config.max_word_count is None
        assert config.quality_threshold == 0.7
        assert config.story_context == {}


class TestRegenerationResult:
    """Tests for RegenerationResult model."""

    def test_result_creation_success(self):
        """Test creating successful RegenerationResult."""
        result = RegenerationResult(
            success=True,
            chapter_number=1,
            new_version=2,
            words_changed=50,
            content_similarity=0.85,
            issues_resolved=["issue1"],
            new_issues=[],
            regeneration_time=1.5,
            quality_score=0.9,
        )
        assert result.success is True
        assert result.chapter_number == 1
        assert result.new_version == 2
        assert result.words_changed == 50
        assert result.content_similarity == 0.85
        assert result.issues_resolved == ["issue1"]
        assert result.new_issues == []
        assert result.regeneration_time == 1.5
        assert result.quality_score == 0.9

    def test_result_creation_failure(self):
        """Test creating failed RegenerationResult."""
        result = RegenerationResult(
            success=False,
            chapter_number=1,
            new_version=0,
            words_changed=0,
            content_similarity=0.0,
            new_issues=["Error occurred"],
            regeneration_time=0.5,
        )
        assert result.success is False
        assert result.new_issues == ["Error occurred"]
        assert result.quality_score is None

    def test_result_defaults(self):
        """Test RegenerationResult with default values."""
        result = RegenerationResult(
            success=True, chapter_number=1, new_version=1, words_changed=0, content_similarity=1.0
        )
        assert result.issues_resolved == []
        assert result.new_issues == []
        assert result.regeneration_time == 0.0
        assert result.quality_score is None


class TestChapterRegenerator:
    """Tests for ChapterRegenerator class."""

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_initialization(self, mock_registry, mock_storage, mock_orchestrator, tmp_path):
        """Test ChapterRegenerator initialization."""
        mock_storage_instance = Mock()
        mock_storage.create.return_value = mock_storage_instance

        regenerator = ChapterRegenerator(str(tmp_path))
        assert regenerator.project_dir == tmp_path
        assert regenerator.draft_manager is not None
        assert regenerator.storage is not None
        assert regenerator.agent_registry is not None
        assert regenerator.orchestrator is not None

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_calculate_similarity(self, mock_registry, mock_storage, mock_orchestrator, tmp_path):
        """Test _calculate_similarity method."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        similarity = regenerator._calculate_similarity("hello world", "hello world")
        assert similarity == 1.0

        similarity = regenerator._calculate_similarity("hello world", "goodbye world")
        assert similarity == 1 / 3

        similarity = regenerator._calculate_similarity("", "content")
        assert similarity == 0.0

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_count_words_changed(self, mock_registry, mock_storage, mock_orchestrator, tmp_path):
        """Test _count_words_changed method."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        changed = regenerator._count_words_changed("hello world", "hello world")
        assert changed == 0

        changed = regenerator._count_words_changed("hello world", "hello brave new world")
        assert changed == 2

        changed = regenerator._count_words_changed("short", "this is much longer text")
        assert changed == 4

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_assess_quality_high(self, mock_registry, mock_storage, mock_orchestrator, tmp_path):
        """Test _assess_quality with high quality content."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        content = (
            "This is a well written chapter. "
            'The character said "Hello!" clearly. '
            "It has good sentence structure and flow. "
            "The plot moves forward effectively."
        )
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL, max_word_count=1000)

        score = regenerator._assess_quality(content, config)
        assert score > 0.8

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_assess_quality_too_long(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _assess_quality when content exceeds max word count."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        content = "word " * 1000
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL, max_word_count=500)

        score = regenerator._assess_quality(content, config)
        assert score == 0.5

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_assess_quality_no_sentences(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _assess_quality with no sentence endings."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        content = "just words without sentences"
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)

        score = regenerator._assess_quality(content, config)
        assert score == 0.5

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_assess_quality_sentence_length(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _assess_quality with extreme sentence lengths."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        short_sentences = "A. B. C. D. E."
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)
        score = regenerator._assess_quality(short_sentences, config)
        assert score == 0.6

        long_sentence = (
            "This is a very long sentence that goes on and on without end and should be penalized."
        )
        score = regenerator._assess_quality(long_sentence, config)
        assert score == 0.8

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_load_chapter_outline_exists(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _load_chapter_outline when file exists."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        outline_dir = tmp_path / "outline"
        outline_dir.mkdir(parents=True, exist_ok=True)
        outline_file = outline_dir / "chapter_001.md"
        outline_file.write_text("Chapter 1 outline content")

        outline = regenerator._load_chapter_outline(1)
        assert outline == "Chapter 1 outline content"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_load_chapter_outline_not_exists(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _load_chapter_outline when file doesn't exist."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        outline = regenerator._load_chapter_outline(1)
        assert "outline not available" in outline.lower()

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_load_continuity_context_exists(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _load_continuity_context when file exists."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        continuity_dir = tmp_path / "continuity"
        continuity_dir.mkdir(parents=True, exist_ok=True)
        context_file = continuity_dir / "context.md"
        context_file.write_text("Continuity context")

        context = regenerator._load_continuity_context(1)
        assert context == "Continuity context"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_load_continuity_context_not_exists(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _load_continuity_context when file doesn't exist."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        context = regenerator._load_continuity_context(1)
        assert "not available" in context.lower()

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_build_regeneration_context(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _build_regeneration_context method."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(
            strategy=RegenerationStrategy.FULL,
            max_word_count=1000,
            style_target="formal",
            story_context={"characters": ["Alice"]},
        )

        context = regenerator._build_regeneration_context(1, config)
        assert context["chapter_number"] == 1
        assert context["project_dir"] == str(tmp_path)
        assert context["max_words"] == 1000
        assert context["style_target"] == "formal"
        assert context["characters"] == ["Alice"]

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_build_regeneration_context_minimal(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _build_regeneration_context with minimal config."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)

        context = regenerator._build_regeneration_context(5, config)
        assert context["chapter_number"] == 5
        assert context["project_dir"] == str(tmp_path)
        assert "max_words" not in context
        assert "style_target" not in context

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_chapter_not_found(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test regenerate when chapter doesn't exist."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)

        result = regenerator.regenerate(1, config)
        assert result.success is False
        assert result.new_issues == ["Chapter not found"]

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_quality_threshold_failed(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test regenerate when quality score is below threshold."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        regenerator.draft_manager.initialize_chapter(1, "Original content", "initial")

        config = RegenerationConfig(strategy=RegenerationStrategy.FULL, quality_threshold=0.95)

        with patch.object(regenerator, "_execute_regeneration", return_value="New content"):
            with patch.object(regenerator, "_get_current_content", return_value="Original content"):
                result = regenerator.regenerate(1, config)

        assert result.success is False
        assert "below threshold" in result.new_issues[0]

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_exception_handling(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test regenerate handles exceptions properly."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        regenerator.draft_manager.initialize_chapter(1, "Original content", "initial")

        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)

        with patch.object(
            regenerator, "_execute_regeneration", side_effect=RuntimeError("Agent failed")
        ):
            with patch.object(regenerator, "_get_current_content", return_value="content"):
                result = regenerator.regenerate(1, config)

        assert result.success is False
        assert "Agent failed" in result.new_issues

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_execute_regeneration_unknown_strategy(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _execute_regeneration with unknown strategy."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)
        config.strategy = "unknown"  # type: ignore

        with pytest.raises(ValueError, match="Unknown strategy"):
            regenerator._execute_regeneration(1, "content", config)

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_targeted_no_issues(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_targeted with no issues to fix."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.TARGETED, fix_issues=[])

        result = regenerator._regenerate_targeted(1, "Original content", config)
        assert result == "Original content"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_targeted_with_issues(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_targeted with issues to fix."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": True, "content": "Fixed content"}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.TARGETED, fix_issues=["grammar"])

        result = regenerator._regenerate_targeted(1, "Original content", config)
        assert result == "Fixed content"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_continuity_success(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_continuity successful case."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": True, "content": "Fixed continuity"}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(
            strategy=RegenerationStrategy.CONTINUITY, fix_issues=["timeline"]
        )

        result = regenerator._regenerate_continuity(1, "Content", config)
        assert result == "Fixed continuity"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_continuity_failure(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_continuity when agent fails."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": False}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.CONTINUITY)

        result = regenerator._regenerate_continuity(1, "Original", config)
        assert result == "Original"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_style_success(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_style successful case."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": True, "content": "Styled content"}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.STYLE, style_target="formal")

        result = regenerator._regenerate_style(1, "Original", config)
        assert result == "Styled content"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_style_default_target(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_style with default style target."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": True, "content": "Improved"}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.STYLE)

        result = regenerator._regenerate_style(1, "Original", config)
        assert result == "Improved"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_batch_regenerate(self, mock_registry, mock_storage, mock_orchestrator, tmp_path):
        """Test batch_regenerate method."""
        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))

        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)

        with patch.object(
            regenerator,
            "regenerate",
            side_effect=[
                RegenerationResult(
                    success=True,
                    chapter_number=1,
                    new_version=2,
                    words_changed=10,
                    content_similarity=0.9,
                ),
                RegenerationResult(
                    success=True,
                    chapter_number=2,
                    new_version=2,
                    words_changed=15,
                    content_similarity=0.85,
                ),
            ],
        ):
            results = regenerator.batch_regenerate([1, 2], config)

        assert len(results) == 2
        assert results[0].chapter_number == 1
        assert results[1].chapter_number == 2

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_full_success(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_full successful case."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": True, "content": "Generated chapter"}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL, max_word_count=1000)

        result = regenerator._regenerate_full(1, config)
        assert result == "Generated chapter"

    @patch("core.chapter_regenerator.create_orchestrator")
    @patch("core.chapter_regenerator.StorageFactory")
    @patch("core.chapter_regenerator.AgentRegistry")
    def test_regenerate_full_failure(
        self, mock_registry, mock_storage, mock_orchestrator, tmp_path
    ):
        """Test _regenerate_full when agent fails."""
        mock_agent = Mock()
        mock_agent.execute.return_value = {"success": False, "error": "Generation failed"}

        mock_registry_instance = Mock()
        mock_registry_instance.get_agent.return_value = mock_agent
        mock_registry.return_value = mock_registry_instance

        mock_storage.create.return_value = Mock()
        regenerator = ChapterRegenerator(str(tmp_path))
        config = RegenerationConfig(strategy=RegenerationStrategy.FULL)

        with pytest.raises(RuntimeError, match="Regeneration failed"):
            regenerator._regenerate_full(1, config)
