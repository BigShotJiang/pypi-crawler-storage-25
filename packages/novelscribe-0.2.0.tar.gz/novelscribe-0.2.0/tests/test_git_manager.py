"""Tests for Git manager module."""

import shutil
import tempfile
from pathlib import Path

import pytest

from core.git_manager import (
    GitManager,
    RepositoryNotFoundError,
    create_git_manager,
)


@pytest.fixture
def temp_git_repo():
    """Create temporary Git repository for testing."""
    temp_dir = tempfile.mkdtemp()
    repo_path = Path(temp_dir)

    try:
        import git

        repo = git.Repo.init(repo_path)

        repo.config_writer().set_value("user", "email", "test@example.com").release()
        repo.config_writer().set_value("user", "name", "Test User").release()

        test_file = repo_path / "test.txt"
        test_file.write_text("Initial content")

        repo.index.add(["test.txt"])
        repo.index.commit("Initial commit")

        yield repo_path
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def git_manager(temp_git_repo):
    """Create Git manager for testing."""
    manager = GitManager(
        project_path=temp_git_repo,
        auto_commit=True,
    )
    import git

    manager._repo = git.Repo(temp_git_repo)
    return manager


@pytest.fixture
def non_repo_path():
    """Create temporary directory without Git repo."""
    temp_dir = tempfile.mkdtemp()
    yield Path(temp_dir)
    shutil.rmtree(temp_dir, ignore_errors=True)


class TestGitManager:
    """Tests for GitManager."""

    def test_initialization(self, temp_git_repo):
        """Test Git manager initialization."""
        manager = GitManager(
            project_path=temp_git_repo,
            auto_commit=True,
        )
        assert manager.project_path == temp_git_repo
        assert manager.auto_commit is True
        assert manager.commit_message_format == "{agent}: {description}"
        assert manager.milestone_tag_prefix == "v"

    def test_is_repository(self, git_manager):
        """Test checking if directory is a Git repository."""
        assert git_manager.is_repository() is True

    def test_is_repository_non_existent(self, non_repo_path):
        """Test checking if non-Git directory is a repository."""
        manager = GitManager(project_path=non_repo_path)
        assert manager.is_repository() is False

    def test_initialize_repository(self, non_repo_path):
        """Test initializing a new Git repository."""
        manager = GitManager(project_path=non_repo_path)
        manager.initialize_repository()

        assert manager.is_repository() is True
        assert (non_repo_path / ".git").exists()

    def test_get_current_commit(self, git_manager):
        """Test getting current commit hash."""
        commit_hash = git_manager.get_current_commit()
        assert len(commit_hash) == 40
        assert isinstance(commit_hash, str)

    def test_add_changed_files(self, git_manager, temp_git_repo):
        """Test staging changed files."""
        new_file = temp_git_repo / "new.txt"
        new_file.write_text("New content")

        git_manager.add_changed_files(["new.txt"])

        staged = git_manager.repo.index.entries
        assert any("new.txt" in str(key[0]) for key in staged.keys())

    def test_add_all_changed_files(self, git_manager, temp_git_repo):
        """Test staging all changed files."""
        new_file1 = temp_git_repo / "new1.txt"
        new_file1.write_text("Content 1")
        new_file2 = temp_git_repo / "new2.txt"
        new_file2.write_text("Content 2")

        git_manager.add_changed_files()

        staged = git_manager.repo.index.entries
        staged_files = [key[0] for key in staged.keys() if not key[0].startswith(".git/")]
        staged_normalized = [f.lstrip("./") for f in staged_files]
        assert "new1.txt" in staged_normalized
        assert "new2.txt" in staged_normalized

    def test_commit(self, git_manager):
        """Test creating a commit."""
        test_file = git_manager.project_path / "test_commit.txt"
        test_file.write_text("Test content")

        git_manager.add_changed_files(["test_commit.txt"])
        commit_hash = git_manager.commit(
            message="Test commit",
            agent="test_agent",
            description="Test description",
        )

        assert len(commit_hash) == 40

    def test_commit_with_custom_format(self, temp_git_repo):
        """Test commit with custom message format."""
        manager = GitManager(
            project_path=temp_git_repo,
            commit_message_format="[{agent}] {description}",
        )

        test_file = temp_git_repo / "test.txt"
        test_file.write_text("Content")
        manager.add_changed_files(["test.txt"])

        commit_hash = manager.commit(
            message="Should not use this",
            agent="writer",
            description="Chapter 1 draft",
        )

        commit = manager.repo.commit(commit_hash)
        assert "[writer] Chapter 1 draft" in commit.message

    def test_auto_commit_step(self, git_manager, temp_git_repo):
        """Test automatic commit of workflow step."""
        test_file = temp_git_repo / "auto.txt"
        test_file.write_text("Auto content")

        commit_hash = git_manager.auto_commit_step(
            agent="writer",
            description="Wrote chapter 1",
            files=["auto.txt"],
        )

        assert commit_hash is not None
        assert len(commit_hash) == 40

    def test_auto_commit_step_disabled(self, temp_git_repo):
        """Test auto-commit when disabled."""
        manager = GitManager(
            project_path=temp_git_repo,
            auto_commit=False,
        )

        test_file = temp_git_repo / "test.txt"
        test_file.write_text("Content")

        commit_hash = manager.auto_commit_step(
            agent="writer",
            description="Test",
            files=["test.txt"],
        )

        assert commit_hash is None

    def test_create_milestone_tag(self, git_manager):
        """Test creating milestone tag."""
        tag_name = git_manager.create_milestone_tag(
            milestone="1.0",
            message="Milestone 1 complete",
        )

        assert tag_name == "v1.0"

        tags = git_manager.get_tags()
        assert len(tags) == 1
        assert tags[0]["name"] == "v1.0"

    def test_create_milestone_tag_custom_prefix(self, temp_git_repo):
        """Test creating tag with custom prefix."""
        manager = GitManager(
            project_path=temp_git_repo,
            milestone_tag_prefix="milestone-",
        )

        tag_name = manager.create_milestone_tag("1.0")
        assert tag_name == "milestone-1.0"

    def test_get_commit_history(self, git_manager, temp_git_repo):
        """Test getting commit history."""
        for i in range(3):
            test_file = temp_git_repo / f"test{i}.txt"
            test_file.write_text(f"Content {i}")
            git_manager.add_changed_files([f"test{i}.txt"])
            git_manager.commit(message=f"Commit {i}")

        history = git_manager.get_commit_history(limit=5)
        assert len(history) >= 3

        assert all("hash" in entry for entry in history)
        assert all("message" in entry for entry in history)
        assert all("author" in entry for entry in history)

    def test_get_tags(self, git_manager):
        """Test getting all tags."""
        git_manager.create_milestone_tag("1.0")
        git_manager.create_milestone_tag("2.0")

        tags = git_manager.get_tags()
        assert len(tags) == 2
        assert tags[0]["name"] == "v1.0"
        assert tags[1]["name"] == "v2.0"

    def test_has_uncommitted_changes(self, git_manager, temp_git_repo):
        """Test checking for uncommitted changes."""
        assert git_manager.has_uncommitted_changes() is False

        new_file = temp_git_repo / "changed.txt"
        new_file.write_text("Uncommitted content")

        assert git_manager.has_uncommitted_changes() is True

    def test_get_changed_files(self, git_manager, temp_git_repo):
        """Test getting list of changed files."""
        assert len(git_manager.get_changed_files()) == 0

        new_file = temp_git_repo / "new.txt"
        new_file.write_text("New")

        modified_file = temp_git_repo / "test.txt"
        modified_file.write_text("Modified")

        changed = git_manager.get_changed_files()
        assert "new.txt" in changed
        assert "test.txt" in changed

    def test_status(self, git_manager):
        """Test getting repository status."""
        status = git_manager.status()

        assert status["is_repository"] is True
        assert status["path"] == str(git_manager.project_path)
        assert "current_branch" in status
        assert "current_commit" in status
        assert "has_changes" in status
        assert isinstance(status["changed_files"], list)

    def test_status_non_repo(self, non_repo_path):
        """Test status for non-Git directory."""
        manager = GitManager(project_path=non_repo_path)
        status = manager.status()

        assert status["is_repository"] is False
        assert status["path"] == str(non_repo_path)

    def test_commit_operations_on_non_repo(self, non_repo_path):
        """Test that commit operations fail on non-repository."""
        manager = GitManager(project_path=non_repo_path)

        with pytest.raises(RepositoryNotFoundError):
            manager.add_changed_files()

        with pytest.raises(RepositoryNotFoundError):
            manager.commit(message="Test")

        with pytest.raises(RepositoryNotFoundError):
            manager.create_milestone_tag("1.0")


class TestCreateGitManager:
    """Tests for create_git_manager factory function."""

    def test_create_with_existing_repo(self, temp_git_repo):
        """Test creating manager for existing repository."""
        manager = create_git_manager(temp_git_repo)

        assert manager.is_repository() is True
        assert manager.auto_commit is True

    def test_create_with_new_repo(self, non_repo_path):
        """Test creating manager initializes new repository."""
        manager = create_git_manager(non_repo_path)

        assert manager.is_repository() is True
        assert (non_repo_path / ".git").exists()

    def test_create_with_custom_config(self, temp_git_repo):
        """Test creating manager with custom configuration."""
        manager = create_git_manager(
            temp_git_repo,
            auto_commit=False,
            commit_message_format="custom: {agent}",
            milestone_tag_prefix="tag-",
        )

        assert manager.auto_commit is False
        assert manager.commit_message_format == "custom: {agent}"
        assert manager.milestone_tag_prefix == "tag-"


class TestGitManagerIntegration:
    """Integration tests for Git manager."""

    def test_full_workflow(self, temp_git_repo):
        """Test complete Git workflow."""
        manager = GitManager(temp_git_repo)

        initial_commit = manager.get_current_commit()

        test_file = temp_git_repo / "workflow.txt"
        test_file.write_text("Workflow test")

        manager.auto_commit_step(
            agent="test",
            description="Test step",
            files=["workflow.txt"],
        )

        manager.create_milestone_tag("0.1", "First milestone")

        assert manager.get_current_commit() != initial_commit
        assert len(manager.get_tags()) == 1
        assert manager.has_uncommitted_changes() is False

    def test_multiple_commits(self, temp_git_repo):
        """Test multiple sequential commits."""
        manager = GitManager(temp_git_repo)

        for i in range(5):
            test_file = temp_git_repo / f"commit{i}.txt"
            test_file.write_text(f"Content {i}")
            manager.auto_commit_step(
                agent=f"agent{i}",
                description=f"Step {i}",
                files=[f"commit{i}.txt"],
            )

        history = manager.get_commit_history(limit=10)
        assert len(history) >= 5

    def test_branch_status(self, temp_git_repo):
        """Test repository includes branch information."""
        manager = GitManager(temp_git_repo)
        status = manager.status()

        assert "current_branch" in status
        assert status["current_branch"] == "main" or status["current_branch"] == "master"
