"""Integration tests for logs router."""

import asyncio
import json
from pathlib import Path
from typing import List
from unittest.mock import MagicMock

from api.models import LogLevel
from api.routers.logs import (
    LogStreamerConfig,
    generate_log_sse_stream,
    get_project_log_file,
    parse_log_entries,
    read_log_file,
)


class MockStorageProvider:
    """Mock storage provider for integration testing."""

    def __init__(self, projects: List[str], base_path: Path):
        self._projects = projects
        self._base_path = base_path

    def list_projects(self) -> List[str]:
        return self._projects

    @property
    def project_dir(self) -> Path:
        return self._base_path


class TestLogFileReadingIntegration:
    """Integration tests for log file reading."""

    async def test_read_single_entry(self, tmp_path):
        """Test reading a single log entry."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test entry"}\n')

        result = read_log_file(log_file)

        assert len(result) == 1
        assert result[0]["level"] == "INFO"
        assert result[0]["message"] == "Test entry"

    async def test_read_multiple_entries(self, tmp_path):
        """Test reading multiple log entries."""
        log_file = tmp_path / "execution.log"
        log_entries = [{"level": "INFO", "message": f"Entry {i}"} for i in range(10)]
        log_file.write_text("\n".join(json.dumps(e) for e in log_entries) + "\n")

        result = read_log_file(log_file)

        assert len(result) == 10

    async def test_read_real_world_format(self, tmp_path):
        """Test reading real-world log format."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "Starting process", "execution_id": "exec123", '
            '"timestamp": "2024-01-15T10:00:00"}\n'
            '{"level": "DEBUG", "message": "Processing step 1", "execution_id": "exec123"}\n'
            '{"level": "WARNING", "message": "High memory usage", "execution_id": "exec123"}\n'
            '{"level": "ERROR", "message": "Failed to connect", "execution_id": "exec123"}\n'
            '{"level": "CRITICAL", "message": "System failure", "execution_id": "exec123"}\n'
        )

        result = read_log_file(log_file)

        assert len(result) == 5
        levels = [r["level"] for r in result]
        assert "INFO" in levels
        assert "ERROR" in levels
        assert "CRITICAL" in levels


class TestMockStorageIntegration:
    """Integration tests with mock storage provider."""

    async def test_storage_provider_list_projects(self, tmp_path):
        """Test storage provider lists projects."""
        projects = ["project1", "project2", "project3"]

        provider = MockStorageProvider(projects, tmp_path)

        assert provider.list_projects() == projects
        assert provider.project_dir == tmp_path

    async def test_end_to_end_with_mock_provider(self, tmp_path):
        """Test end-to-end flow with mock storage provider."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "Test message", "execution_id": "exec1"}\n'
            '{"level": "ERROR", "message": "Error message", "execution_id": "exec1"}\n'
        )

        provider = MockStorageProvider(["test_project"], tmp_path)

        log_file_path = get_project_log_file(provider.project_dir, "test_project")
        raw_logs = read_log_file(log_file_path)
        parsed_logs = parse_log_entries(raw_logs)

        assert len(parsed_logs) == 2
        assert parsed_logs[0].level == LogLevel.INFO
        assert parsed_logs[1].level == LogLevel.ERROR


class TestSSEStreamIntegration:
    """Integration tests for SSE streaming."""

    async def test_stream_generator_produces_events(self, tmp_path):
        """Test that stream generator produces events."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        events = []
        async for event in generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        ):
            events.append(event)
            if len(events) >= 5:
                break

        assert len(events) >= 1

    async def test_stream_with_existing_logs(self, tmp_path):
        """Test streaming with pre-existing logs."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "Log 1"}\n'
            '{"level": "INFO", "message": "Log 2"}\n'
            '{"level": "INFO", "message": "Log 3"}\n'
        )

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        events = []
        async for event in generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=3),
        ):
            events.append(event)

        assert len(events) >= 1


class TestLogFormatVariations:
    """Integration tests for various log formats."""

    async def test_json_with_extra_fields(self, tmp_path):
        """Test parsing JSON with extra fields."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "Test", "extra_field": "value", '
            '"number": 42, "flag": true}\n'
        )

        result = read_log_file(log_file)
        assert len(result) == 1
        assert result[0]["level"] == "INFO"

    async def test_json_with_nested_objects(self, tmp_path):
        """Test parsing JSON with nested objects."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "Test", "metadata": {"nested": {"deep": "value"}}}\n'
        )

        result = read_log_file(log_file)
        assert len(result) == 1
        assert result[0]["metadata"]["nested"]["deep"] == "value"

    async def test_mixed_valid_and_invalid_lines(self, tmp_path):
        """Test reading file with mix of valid and invalid lines."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO"}\n'
            "invalid json\n"
            '{"level": "ERROR"}\n'
            "another invalid\n"
            '{"level": "WARNING"}\n'
        )

        result = read_log_file(log_file)
        assert len(result) == 3


class TestConcurrentAccess:
    """Integration tests for concurrent access patterns."""

    async def test_concurrent_reads(self, tmp_path):
        """Test concurrent reading of log files."""
        log_file = tmp_path / "execution.log"
        lines = [json.dumps({"level": "INFO", "message": "Test"}) + "\n" for i in range(100)]
        log_file.write_text("".join(lines))

        async def read_task():
            return read_log_file(log_file)

        results = await asyncio.gather(*[read_task() for _ in range(10)])
        assert all(len(r) == 100 for r in results)

    async def test_concurrent_parsing(self, tmp_path):
        """Test concurrent parsing of log data."""
        log_data = [{"level": "INFO", "message": f"Log {i}"} for i in range(100)]

        async def parse_task():
            return parse_log_entries(log_data)

        results = await asyncio.gather(*[parse_task() for _ in range(10)])
        assert all(len(r) == 100 for r in results)


class TestErrorRecovery:
    """Integration tests for error recovery scenarios."""

    async def test_recovery_from_empty_file(self, tmp_path):
        """Test recovery from reading empty file."""
        log_file = tmp_path / "execution.log"
        log_file.touch()

        result = read_log_file(log_file)
        assert result == []

    async def test_recovery_from_corrupt_file(self, tmp_path):
        """Test recovery from corrupt file."""
        log_file = tmp_path / "execution.log"
        log_file.write_text("not json\n" * 100)

        result = read_log_file(log_file)
        assert result == []

    async def test_recovery_after_partial_read(self, tmp_path):
        """Test recovery after partial file read."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n{"level": "ERROR"}\n')

        result1 = read_log_file(log_file)
        assert len(result1) == 2

        result2 = read_log_file(log_file)
        assert len(result2) == 2


class TestLargeFileHandling:
    """Integration tests for large file handling."""

    async def test_handles_large_number_of_entries(self, tmp_path):
        """Test handling of large number of entries."""
        log_file = tmp_path / "execution.log"
        log_entries = [json.dumps({"level": "INFO", "message": f"Log {i}"}) for i in range(1000)]
        log_file.write_text("\n".join(log_entries) + "\n")

        result = read_log_file(log_file)
        assert len(result) == 1000

    async def test_pagination_with_large_dataset(self, tmp_path):
        """Test pagination with large dataset."""
        log_data = [{"level": "INFO", "message": f"Log {i}"} for i in range(1000)]

        page_size = 100
        all_entries = []

        for page in range(10):
            offset = page * page_size
            page_data = log_data[offset : offset + page_size]
            parsed = parse_log_entries(page_data)
            all_entries.extend(parsed)

        assert len(all_entries) == 1000
