"""
Tests for CLI version command
"""

import pytest
from click.testing import CliRunner

from cli_version import version


class TestVersionCommand:
    """Test cases for version command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_version_group_exists(self):
        """Test that version command group exists"""
        assert version is not None

    def test_version_help(self, runner):
        """Test version command help"""
        result = runner.invoke(version, ["--help"])

        assert result.exit_code == 0
        assert "Version" in result.output or "version" in result.output

    def test_version_info_command(self, runner):
        """Test version info command"""
        result = runner.invoke(version, ["info"])

        # May fail if VersionManager is not fully initialized
        assert result.exit_code in [0, 1]

    def test_version_info_with_check(self, runner):
        """Test version info with check flag"""
        result = runner.invoke(version, ["info", "--check"])

        # May fail if VersionManager is not fully initialized
        assert result.exit_code in [0, 1]

    def test_version_check_command(self, runner):
        """Test version check command"""
        result = runner.invoke(version, ["check"])

        # May fail if VersionManager is not fully initialized
        assert result.exit_code in [0, 1]

    def test_version_upgrade_command(self, runner):
        """Test version upgrade command"""
        result = runner.invoke(version, ["upgrade"])

        # May fail if VersionManager is not fully initialized
        assert result.exit_code in [0, 1]
