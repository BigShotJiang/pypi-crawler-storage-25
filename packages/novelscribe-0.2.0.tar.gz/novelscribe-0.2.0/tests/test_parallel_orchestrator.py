"""Tests for parallel_orchestrator.py."""

from unittest.mock import AsyncMock, Mock, patch

import pytest

from core.parallel_orchestrator import (
    ExecutionMode,
    OrchestrationResult,
    ParallelConfig,
    ParallelOrchestrator,
    PhaseResult,
    get_parallel_orchestrator,
    reset_parallel_orchestrator,
)


class TestExecutionMode:
    """Tests for ExecutionMode enum."""

    def test_execution_mode_values(self):
        """Test ExecutionMode enum values."""
        assert ExecutionMode.SEQUENTIAL == "sequential"
        assert ExecutionMode.PARALLEL == "parallel"
        assert ExecutionMode.AUTO == "auto"


class TestParallelConfig:
    """Tests for ParallelConfig model."""

    def test_default_config(self):
        """Test ParallelConfig with default values."""
        config = ParallelConfig()
        assert config.enabled is False
        assert config.max_concurrent == 3
        assert config.execution_mode == ExecutionMode.AUTO
        assert config.timeout_per_phase == 300
        assert config.enable_progress is True

    def test_custom_config(self):
        """Test ParallelConfig with custom values."""
        config = ParallelConfig(
            enabled=True,
            max_concurrent=5,
            execution_mode=ExecutionMode.PARALLEL,
            timeout_per_phase=600,
            enable_progress=False,
        )
        assert config.enabled is True
        assert config.max_concurrent == 5
        assert config.execution_mode == ExecutionMode.PARALLEL
        assert config.timeout_per_phase == 600
        assert config.enable_progress is False

    def test_from_dict_empty(self):
        """Test from_dict with empty dict."""
        config = ParallelConfig.from_dict({})
        assert config.enabled is False
        assert config.max_concurrent == 3
        assert config.execution_mode == ExecutionMode.AUTO

    def test_from_dict_full(self):
        """Test from_dict with all values."""
        config = ParallelConfig.from_dict(
            {
                "enabled": True,
                "max_concurrent": 10,
                "execution_mode": "parallel",
                "timeout_per_phase": 900,
                "enable_progress": False,
            }
        )
        assert config.enabled is True
        assert config.max_concurrent == 10
        assert config.execution_mode == ExecutionMode.PARALLEL
        assert config.timeout_per_phase == 900
        assert config.enable_progress is False


class TestPhaseResult:
    """Tests for PhaseResult model."""

    def test_phase_result_success(self):
        """Test PhaseResult with success."""
        result = PhaseResult(
            phase_name="test_phase",
            agent_name="test_agent",
            success=True,
            output="Success output",
            duration=1.5,
            parallel_group=1,
        )
        assert result.phase_name == "test_phase"
        assert result.agent_name == "test_agent"
        assert result.success is True
        assert result.output == "Success output"
        assert result.error is None
        assert result.duration == 1.5
        assert result.parallel_group == 1

    def test_phase_result_failure(self):
        """Test PhaseResult with failure."""
        result = PhaseResult(
            phase_name="test_phase",
            agent_name="test_agent",
            success=False,
            error="Error message",
            duration=0.5,
        )
        assert result.success is False
        assert result.error == "Error message"
        assert result.output is None


class TestOrchestrationResult:
    """Tests for OrchestrationResult model."""

    def test_orchestration_result_success(self):
        """Test OrchestrationResult with all success."""
        phase_results = {
            "phase1": PhaseResult(phase_name="phase1", agent_name="agent1", success=True),
            "phase2": PhaseResult(phase_name="phase2", agent_name="agent2", success=True),
        }
        result = OrchestrationResult(
            success=True,
            phase_results=phase_results,
            total_duration=5.0,
            phases_executed=2,
            phases_failed=0,
        )
        assert result.success is True
        assert result.total_duration == 5.0
        assert result.phases_executed == 2
        assert result.phases_failed == 0
        assert result.failed_phases == []

    def test_orchestration_result_with_failures(self):
        """Test OrchestrationResult with failures."""
        phase_results = {
            "phase1": PhaseResult(phase_name="phase1", agent_name="agent1", success=True),
            "phase2": PhaseResult(phase_name="phase2", agent_name="agent2", success=False),
        }
        result = OrchestrationResult(
            success=False,
            phase_results=phase_results,
            total_duration=5.0,
            phases_executed=1,
            phases_failed=1,
        )
        assert result.success is False
        assert result.failed_phases == ["phase2"]

    def test_orchestration_result_defaults(self):
        """Test OrchestrationResult with default values."""
        result = OrchestrationResult(success=True, phase_results={}, total_duration=0.0)
        assert result.parallel_speedup is None
        assert result.phases_executed == 0
        assert result.phases_failed == 0


class TestParallelOrchestrator:
    """Tests for ParallelOrchestrator class."""

    def test_initialization_default_config(self):
        """Test ParallelOrchestrator initialization with default config."""
        orchestrator = ParallelOrchestrator()
        assert orchestrator.config.enabled is False
        assert orchestrator.config.max_concurrent == 3
        assert orchestrator.metrics["total_executions"] == 0

    def test_initialization_custom_config(self):
        """Test ParallelOrchestrator initialization with custom config."""
        config = ParallelConfig(enabled=True, max_concurrent=5)
        orchestrator = ParallelOrchestrator(config)
        assert orchestrator.config == config
        assert orchestrator.config.max_concurrent == 5

    def test_configure(self):
        """Test configure method."""
        orchestrator = ParallelOrchestrator()
        new_config = ParallelConfig(enabled=True, max_concurrent=10)
        orchestrator.configure(new_config)
        assert orchestrator.config == new_config

    def test_should_parallelize_sequential_mode(self):
        """Test _should_parallelize with SEQUENTIAL mode."""
        orchestrator = ParallelOrchestrator(ParallelConfig(execution_mode=ExecutionMode.SEQUENTIAL))
        phases = []
        result = orchestrator._should_parallelize(phases)
        assert result is False

    def test_should_parallelize_parallel_mode(self):
        """Test _should_parallelize with PARALLEL mode."""
        orchestrator = ParallelOrchestrator(ParallelConfig(execution_mode=ExecutionMode.PARALLEL))
        phases = []
        result = orchestrator._should_parallelize(phases)
        assert result is True

    @patch("core.parallel_orchestrator.PhaseParallelizer")
    def test_has_parallelizable_phases_yes(self, mock_parallelizer):
        """Test _has_parallelizable_phases when parallelizable."""
        orchestrator = ParallelOrchestrator()

        mock_group = Mock()
        mock_group.phases = ["phase1", "phase2"]

        mock_parallelizer_instance = Mock()
        mock_parallelizer_instance.analyze_dependencies.return_value = [mock_group]
        mock_parallelizer.return_value = mock_parallelizer_instance

        orchestrator.phase_parallelizer = mock_parallelizer_instance

        result = orchestrator._has_parallelizable_phases([])
        assert result is True

    @patch("core.parallel_orchestrator.PhaseParallelizer")
    def test_has_parallelizable_phases_no(self, mock_parallelizer):
        """Test _has_parallelizable_phases when not parallelizable."""
        orchestrator = ParallelOrchestrator()

        mock_group = Mock()
        mock_group.phases = ["phase1"]

        mock_parallelizer_instance = Mock()
        mock_parallelizer_instance.analyze_dependencies.return_value = [mock_group]
        mock_parallelizer.return_value = mock_parallelizer_instance

        orchestrator.phase_parallelizer = mock_parallelizer_instance

        result = orchestrator._has_parallelizable_phases([])
        assert result is False

    @pytest.mark.asyncio
    async def test_execute_phase_success(self):
        """Test _execute_phase with success."""
        orchestrator = ParallelOrchestrator()

        from core.parallel_orchestrator import PhaseDependency

        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )

        executor_func = AsyncMock(return_value="Success output")

        result = await orchestrator._execute_phase(phase, executor_func)

        assert result.phase_name == "test_phase"
        assert result.agent_name == "test_agent"
        assert result.success is True
        assert result.output == "Success output"
        assert result.duration > 0

    @pytest.mark.asyncio
    async def test_execute_phase_failure(self):
        """Test _execute_phase with exception."""
        orchestrator = ParallelOrchestrator()

        from core.parallel_orchestrator import PhaseDependency

        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )

        executor_func = AsyncMock(side_effect=RuntimeError("Test error"))

        result = await orchestrator._execute_phase(phase, executor_func)

        assert result.success is False
        assert "Test error" in result.error
        assert result.duration >= 0

    def test_update_metrics(self):
        """Test _update_metrics method."""
        orchestrator = ParallelOrchestrator()

        result = OrchestrationResult(
            success=True,
            phase_results={},
            total_duration=10.0,
            phases_executed=1,
            phases_failed=0,
        )

        orchestrator.metrics["parallel_executions"] = 2

        orchestrator._update_metrics(result)

        assert orchestrator.metrics["total_executions"] == 1
        assert orchestrator.metrics["total_duration"] == 10.0

    def test_get_metrics(self):
        """Test get_metrics method."""
        orchestrator = ParallelOrchestrator()
        orchestrator.metrics["total_executions"] = 5

        metrics = orchestrator.get_metrics()

        assert metrics["total_executions"] == 5
        assert metrics is not orchestrator.metrics

    def test_reset_metrics(self):
        """Test reset_metrics method."""
        orchestrator = ParallelOrchestrator()
        orchestrator.metrics["total_executions"] = 10

        orchestrator.reset_metrics()

        assert orchestrator.metrics["total_executions"] == 0
        assert orchestrator.metrics["total_duration"] == 0.0

    @patch("core.parallel_orchestrator.PhaseParallelizer")
    def test_get_execution_plan(self, mock_parallelizer):
        """Test get_execution_plan method."""
        orchestrator = ParallelOrchestrator()

        mock_parallelizer_instance = Mock()
        mock_parallelizer_instance.get_execution_plan.return_value = "Execution plan"
        mock_parallelizer.return_value = mock_parallelizer_instance

        orchestrator.phase_parallelizer = mock_parallelizer_instance

        plan = orchestrator.get_execution_plan([])

        assert plan == "Execution plan"
        mock_parallelizer_instance.clear_phases.assert_called_once()
        mock_parallelizer_instance.add_phase_batch.assert_called_once()

    @pytest.mark.asyncio
    async def test_execute_phases_sequential(self):
        """Test execute_phases in sequential mode."""
        orchestrator = ParallelOrchestrator(ParallelConfig(execution_mode=ExecutionMode.SEQUENTIAL))

        from core.parallel_orchestrator import PhaseDependency

        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            )
        ]

        executor_func = AsyncMock(return_value="Output")

        result = await orchestrator.execute_phases(phases, executor_func)

        assert result.phases_executed == 1
        assert result.phases_failed == 0
        assert result.success is True
        assert orchestrator.metrics["sequential_executions"] == 1

    @pytest.mark.asyncio
    @patch("core.parallel_orchestrator.AgentQueue")
    @patch("core.parallel_orchestrator.PhaseParallelizer")
    async def test_execute_phases_parallel(self, mock_parallelizer, mock_queue):
        """Test execute_phases in parallel mode."""
        orchestrator = ParallelOrchestrator(ParallelConfig(execution_mode=ExecutionMode.PARALLEL))

        from core.parallel_orchestrator import PhaseDependency, TaskStatus

        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            )
        ]

        mock_group = Mock()
        mock_group.can_parallel_execute = True
        mock_group.group_id = 1
        mock_group.phases = phases

        mock_parallelizer_instance = Mock()
        mock_parallelizer_instance.analyze_dependencies.return_value = [mock_group]
        mock_parallelizer_instance.clear_phases = Mock()
        mock_parallelizer_instance.add_phase_batch = Mock()
        orchestrator.phase_parallelizer = mock_parallelizer_instance

        mock_task_result = Mock()
        mock_task_result.status = TaskStatus.COMPLETED
        mock_task_result.result = "Output"
        mock_task_result.error = None
        mock_task_result.duration = 1.0

        mock_queue_instance = Mock()
        mock_queue_instance.execute_parallel = AsyncMock(return_value={"phase1": mock_task_result})
        mock_queue.return_value = mock_queue_instance

        executor_func = AsyncMock(return_value="Output")

        result = await orchestrator.execute_phases(phases, executor_func)

        assert result.phases_executed == 1
        assert result.success is True
        assert orchestrator.metrics["parallel_executions"] == 1


class TestGlobalOrchestrator:
    """Tests for global orchestrator functions."""

    def test_get_parallel_orchestrator_creates_new(self):
        """Test get_parallel_orchestrator creates new instance."""
        reset_parallel_orchestrator()
        orchestrator = get_parallel_orchestrator()
        assert orchestrator is not None
        assert isinstance(orchestrator, ParallelOrchestrator)

    def test_get_parallel_orchestrator_returns_existing(self):
        """Test get_parallel_orchestrator returns existing instance."""
        reset_parallel_orchestrator()
        orchestrator1 = get_parallel_orchestrator(ParallelConfig(enabled=True, max_concurrent=5))
        orchestrator2 = get_parallel_orchestrator()
        assert orchestrator1 is orchestrator2
        assert orchestrator2.config.max_concurrent == 5

    def test_reset_parallel_orchestrator(self):
        """Test reset_parallel_orchestrator."""
        orchestrator1 = get_parallel_orchestrator()
        reset_parallel_orchestrator()
        orchestrator2 = get_parallel_orchestrator()
        assert orchestrator1 is not orchestrator2
