"""
Comprehensive tests for version.py to increase coverage to 90%+.
Tests version management and update checking.
"""

from unittest.mock import Mock, patch

from novel_harness.core.version import (
    VersionManager,
    check_updates,
    get_version,
    notify_if_update_available,
)


class TestVersionManager:
    """Test VersionManager class."""

    def test_init(self):
        """Test initialization."""
        manager = VersionManager()

        assert manager.package_name == "novel-harness"
        assert manager.current_version is not None
        assert "pypi.org" in manager.pypi_url

    def test_get_version_info(self):
        """Test getting version info."""
        manager = VersionManager()

        info = manager.get_version_info()

        assert "current" in info
        assert "package" in info
        assert info["package"] == "novel-harness"

    @patch("requests.get")
    def test_check_for_updates_no_update(self, mock_get):
        """Test checking for updates when no update available."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "0.0.0"},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        manager.current_version = "0.0.0"

        result = manager.check_for_updates()

        assert result is not None
        assert result["update_available"] is False

    @patch("requests.get")
    def test_check_for_updates_update_available(self, mock_get):
        """Test checking for updates when update is available."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "99.0.0"},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        manager.current_version = "0.0.0"

        result = manager.check_for_updates()

        assert result is not None
        assert result["update_available"] is True
        assert "upgrade_command" in result

    @patch("requests.get")
    def test_check_for_updates_connection_error(self, mock_get):
        """Test checking for updates with connection error."""
        mock_get.side_effect = Exception("Connection error")

        manager = VersionManager()

        result = manager.check_for_updates()

        assert result is None

    @patch("requests.get")
    def test_check_for_updates_http_error(self, mock_get):
        """Test checking for updates with HTTP error."""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_get.return_value = mock_response

        manager = VersionManager()

        result = manager.check_for_updates()

        assert result is None

    def test_is_newer_version_true(self):
        """Test version comparison when latest is newer."""
        manager = VersionManager()
        manager.current_version = "1.0.0"

        result = manager._is_newer_version("2.0.0")

        assert result is True

    def test_is_newer_version_false(self):
        """Test version comparison when latest is older."""
        manager = VersionManager()
        manager.current_version = "2.0.0"

        result = manager._is_newer_version("1.0.0")

        assert result is False

    def test_is_newer_version_equal(self):
        """Test version comparison when versions are equal."""
        manager = VersionManager()
        manager.current_version = "1.0.0"

        result = manager._is_newer_version("1.0.0")

        assert result is False

    def test_is_newer_version_invalid(self):
        """Test version comparison with invalid version."""
        manager = VersionManager()
        manager.current_version = "invalid"

        result = manager._is_newer_version("2.0.0")

        assert result is False

    def test_get_release_notes_with_summary(self):
        """Test getting release notes with summary."""
        manager = VersionManager()

        pypi_data = {
            "info": {
                "summary": "Test summary",
                "description": "Test description",
            }
        }

        result = manager._get_release_notes(pypi_data, "1.0.0")

        assert result == "Test summary"

    def test_get_release_notes_without_summary(self):
        """Test getting release notes without summary."""
        manager = VersionManager()

        pypi_data = {
            "info": {
                "description": "Test description",
            }
        }

        result = manager._get_release_notes(pypi_data, "1.0.0")

        assert result == "Test description"[:500]

    def test_get_release_notes_empty(self):
        """Test getting release notes when empty."""
        manager = VersionManager()

        pypi_data = {"info": {}}

        result = manager._get_release_notes(pypi_data, "1.0.0")

        assert result == "Visit PyPI for details"

    def test_get_upgrade_command(self):
        """Test getting upgrade command."""
        manager = VersionManager()

        command = manager._get_upgrade_command()

        assert "pip" in command or "uv" in command

    @patch("subprocess.run")
    def test_installed_with_pipx_true(self, mock_run):
        """Test checking pipx installation - True."""
        mock_result = Mock()
        mock_result.stdout = "novel-harness"
        mock_run.return_value = mock_result

        manager = VersionManager()

        result = manager._installed_with_pipx()

        assert result is True

    @patch("subprocess.run")
    def test_installed_with_pipx_false(self, mock_run):
        """Test checking pipx installation - False."""
        mock_result = Mock()
        mock_result.stdout = "other-package"
        mock_run.return_value = mock_result

        manager = VersionManager()

        result = manager._installed_with_pipx()

        assert result is False

    @patch("subprocess.run")
    def test_installed_with_pipx_exception(self, mock_run):
        """Test checking pipx installation with exception."""
        mock_run.side_effect = Exception("Command not found")

        manager = VersionManager()

        result = manager._installed_with_pipx()

        assert result is False

    @patch("subprocess.run")
    def test_installed_with_pip_true(self, mock_run):
        """Test checking pip installation - True."""
        mock_result = Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        manager = VersionManager()

        result = manager._installed_with_pip()

        assert result is True

    @patch("subprocess.run")
    def test_installed_with_pip_false(self, mock_run):
        """Test checking pip installation - False."""
        mock_result = Mock()
        mock_result.returncode = 1
        mock_run.return_value = mock_result

        manager = VersionManager()

        result = manager._installed_with_pip()

        assert result is False

    @patch("subprocess.run")
    def test_installed_with_pip_exception(self, mock_run):
        """Test checking pip installation with exception."""
        mock_run.side_effect = Exception("Command not found")

        manager = VersionManager()

        result = manager._installed_with_pip()

        assert result is False

    @patch("subprocess.run")
    def test_installed_with_uv_true(self, mock_run):
        """Test checking uv installation - True."""
        mock_result = Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        manager = VersionManager()

        result = manager._installed_with_uv()

        assert result is True

    @patch("subprocess.run")
    def test_installed_with_uv_false(self, mock_run):
        """Test checking uv installation - False."""
        mock_result = Mock()
        mock_result.returncode = 1
        mock_run.return_value = mock_result

        manager = VersionManager()

        result = manager._installed_with_uv()

        assert result is False

    @patch("subprocess.run")
    def test_installed_with_uv_exception(self, mock_run):
        """Test checking uv installation with exception."""
        mock_run.side_effect = Exception("Command not found")

        manager = VersionManager()

        result = manager._installed_with_uv()

        assert result is False

    @patch.object(VersionManager, "check_for_updates")
    def test_display_update_notification(self, mock_check):
        """Test display update notification."""
        mock_check.return_value = {
            "current": "1.0.0",
            "latest": "2.0.0",
            "update_available": True,
            "release_notes": "Test notes",
            "upgrade_command": "pip install --upgrade novel-harness",
        }

        manager = VersionManager()
        manager.display_update_notification()

    @patch.object(VersionManager, "check_for_updates")
    def test_display_update_notification_no_update(self, mock_check):
        """Test display update notification when no update available."""
        mock_check.return_value = {
            "current": "1.0.0",
            "latest": "1.0.0",
            "update_available": False,
        }

        manager = VersionManager()
        manager.display_update_notification()


class TestModuleFunctions:
    """Test module-level functions."""

    @patch.object(VersionManager, "__init__", return_value=None)
    def test_get_version(self, mock_init):
        """Test get_version function."""
        mock_init.return_value = None
        VersionManager.current_version = "1.0.0"

        version = get_version()

        assert version == "1.0.0"

    @patch.object(VersionManager, "check_for_updates")
    def test_check_updates_function(self, mock_check):
        """Test check_updates function."""
        mock_check.return_value = {"update_available": False}

        result = check_updates()

        assert result is not None
        assert result["update_available"] is False

    @patch.object(VersionManager, "display_update_notification")
    def test_notify_if_update_available(self, mock_display):
        """Test notify_if_update_available function."""
        notify_if_update_available()

        mock_display.assert_called_once()
