"""Test coverage for api/tasks.py."""

import uuid
from datetime import datetime
from unittest.mock import MagicMock, patch

from api.tasks import (
    ExecutionState,
    TaskManager,
    TaskStatus,
    get_task_manager,
)


class TestTaskStatus:
    def test_task_status_values(self):
        assert TaskStatus.PENDING.value == "pending"
        assert TaskStatus.RUNNING.value == "running"
        assert TaskStatus.COMPLETED.value == "completed"
        assert TaskStatus.FAILED.value == "failed"
        assert TaskStatus.CANCELLED.value == "cancelled"


class TestExecutionState:
    def test_basic_creation(self):
        state = ExecutionState(
            execution_id="exec_001",
            project_name="test_project",
            workflow="autonomous",
        )
        assert state.execution_id == "exec_001"
        assert state.status == TaskStatus.PENDING
        assert state.progress == 0.0
        assert state.error is None

    def test_to_dict(self):
        state = ExecutionState(
            execution_id="exec_002",
            project_name="test_project",
            workflow="write_chapter",
            variables={"chapter": 1},
        )
        d = state.to_dict()
        assert d["execution_id"] == "exec_002"
        assert d["workflow"] == "write_chapter"
        assert d["variables"]["chapter"] == 1
        assert d["started_at"] is None
        assert d["completed_at"] is None

    def test_to_dict_with_timestamps(self):
        now = datetime.now()
        state = ExecutionState(
            execution_id="exec_003",
            project_name="test_project",
            workflow="autonomous",
            started_at=now,
            completed_at=now,
            progress=100.0,
        )
        d = state.to_dict()
        assert d["started_at"] is not None
        assert d["completed_at"] is not None


class TestTaskManager:
    def test_init(self):
        manager = TaskManager(max_workers=3)
        assert manager.executor._max_workers == 3
        assert len(manager.executions) == 0
        assert len(manager.progress_callbacks) == 0

    def test_add_progress_callback(self):
        manager = TaskManager()
        callback = MagicMock()
        manager.add_progress_callback(callback)
        assert len(manager.progress_callbacks) == 1

    def test_execute_workflow_creates_state(self):
        manager = TaskManager(max_workers=2)
        with patch.object(manager, "_run_workflow") as mock_run:
            mock_run.side_effect = lambda s: None
            state = manager.execute_workflow(
                project_name="test_project",
                workflow="autonomous",
                variables={},
                background=True,
            )
            assert state.execution_id is not None
            assert state.project_name == "test_project"
            assert state.workflow == "autonomous"

    def test_execute_workflow_registers_execution(self):
        manager = TaskManager()
        state = manager.execute_workflow(
            project_name="test_project",
            workflow="write_chapter",
            variables={"chapter": 5},
        )
        assert state.execution_id in manager.executions
        assert manager.executions[state.execution_id].variables["chapter"] == 5

    def test_execute_workflow_autonomous(self):
        manager = TaskManager(max_workers=2)
        with patch.object(manager, "_run_workflow") as mock_run:
            mock_run.side_effect = lambda s: None
            state = manager.execute_workflow(
                project_name="test_project",
                workflow="autonomous",
                variables={},
            )
            assert state.workflow == "autonomous"

    def test_execute_workflow_write_chapter(self):
        manager = TaskManager(max_workers=2)
        with patch.object(manager, "_run_workflow") as mock_run:
            mock_run.side_effect = lambda s: None
            state = manager.execute_workflow(
                project_name="test_project",
                workflow="write_chapter",
                variables={"chapter": 3},
            )
            assert state.workflow == "write_chapter"

    def test_execute_workflow_generate_outline(self):
        manager = TaskManager(max_workers=2)
        with patch.object(manager, "_run_workflow") as mock_run:
            mock_run.side_effect = lambda s: None
            state = manager.execute_workflow(
                project_name="test_project",
                workflow="generate_outline",
                variables={},
            )
            assert state.workflow == "generate_outline"

    def test_execute_workflow_unknown(self):
        manager = TaskManager(max_workers=2)
        with patch.object(manager, "_run_workflow") as mock_run:
            mock_run.side_effect = lambda s: None
            state = manager.execute_workflow(
                project_name="test_project",
                workflow="unknown_workflow",
                variables={},
            )
            assert state.workflow == "unknown_workflow"

    def test_notify_progress_with_callback_exception(self):
        """Test _notify_progress handles callback exceptions gracefully."""
        manager = TaskManager()

        def failing_callback(exec_id, progress, step):
            raise Exception("Callback error")

        def working_callback(exec_id, progress, step):
            pass

        manager.add_progress_callback(failing_callback)
        manager.add_progress_callback(working_callback)

        # Should not raise exception
        manager._notify_progress("exec_1", 50.0, "Testing")

    def test_run_autonomous_workflow(self):
        """Test _run_autonomous_workflow method."""
        manager = TaskManager()
        orchestrator = MagicMock()
        orchestrator.run_autonomous_workflow.return_value = {"status": "completed", "chapters": []}
        state = ExecutionState(execution_id="exec_1", project_name="test", workflow="autonomous")

        manager._run_autonomous_workflow(orchestrator, state)

        assert state.progress == 85.0
        assert state.result is not None
        assert len(state.logs) > 0

    def test_run_write_chapter_workflow(self):
        """Test _run_write_chapter_workflow method."""
        manager = TaskManager()
        orchestrator = MagicMock()
        orchestrator.run_chapter_workflow.return_value = {"status": "completed", "content": "test"}
        state = ExecutionState(
            execution_id="exec_1",
            project_name="test",
            workflow="write_chapter",
            variables={"chapter": 5},
        )

        manager._run_write_chapter_workflow(orchestrator, state)

        assert state.progress == 100.0
        assert state.result is not None

    def test_run_outline_workflow(self):
        """Test _run_outline_workflow method."""
        manager = TaskManager()
        orchestrator = MagicMock()
        orchestrator.run_outline_workflow.return_value = {"status": "completed", "outline": []}
        state = ExecutionState(
            execution_id="exec_1", project_name="test", workflow="generate_outline"
        )

        manager._run_outline_workflow(orchestrator, state)

        assert state.progress == 100.0
        assert state.result is not None

    def test_run_generic_workflow(self):
        """Test _run_generic_workflow method."""
        manager = TaskManager()
        orchestrator = MagicMock()
        orchestrator.run_workflow.return_value = {"status": "completed"}
        state = ExecutionState(
            execution_id="exec_1", project_name="test", workflow="custom_workflow"
        )

        manager._run_generic_workflow(orchestrator, state)

        assert state.progress == 100.0
        assert state.result is not None

    def test_get_all_executions_empty(self):
        """Test get_all_executions with no executions."""
        manager = TaskManager()
        executions = manager.get_all_executions()
        assert len(executions) == 0

    def test_get_all_executions(self):
        """Test get_all_executions returns all states."""
        manager = TaskManager()

        state1 = ExecutionState(execution_id="exec_1", project_name="project_a", workflow="test")
        state2 = ExecutionState(execution_id="exec_2", project_name="project_b", workflow="test")

        manager.executions["exec_1"] = state1
        manager.executions["exec_2"] = state2

        executions = manager.get_all_executions()
        assert len(executions) == 2

    def test_get_all_executions_with_project_filter(self):
        """Test get_all_executions with project name filter."""
        manager = TaskManager()

        state1 = ExecutionState(execution_id="exec_1", project_name="project_a", workflow="test")
        state2 = ExecutionState(execution_id="exec_2", project_name="project_b", workflow="test")

        manager.executions["exec_1"] = state1
        manager.executions["exec_2"] = state2

        executions = manager.get_all_executions(project_name="project_a")
        assert len(executions) == 1
        assert executions[0].project_name == "project_a"

    def test_cancel_execution_not_found(self):
        manager = TaskManager()
        result = manager.cancel_execution("nonexistent_id")
        assert result is False

    def test_cancel_execution_not_running(self):
        manager = TaskManager()
        state = ExecutionState(
            execution_id="exec_cancel_001",
            project_name="test_project",
            workflow="autonomous",
            status=TaskStatus.PENDING,
        )
        manager.executions["exec_cancel_001"] = state
        result = manager.cancel_execution("exec_cancel_001")
        assert result is False

    def test_cancel_execution_success(self):
        manager = TaskManager()
        exec_id = str(uuid.uuid4())
        state = ExecutionState(
            execution_id=exec_id,
            project_name="test_project",
            workflow="autonomous",
            status=TaskStatus.RUNNING,
        )
        manager.executions[exec_id] = state
        mock_future = MagicMock()
        mock_future.cancel.return_value = True
        manager.active_futures[exec_id] = mock_future
        result = manager.cancel_execution(exec_id)
        assert result is True
        assert manager.executions[exec_id].status == TaskStatus.CANCELLED

    def test_get_execution_status(self):
        manager = TaskManager()
        exec_id = str(uuid.uuid4())
        state = ExecutionState(
            execution_id=exec_id,
            project_name="test_project",
            workflow="autonomous",
        )
        manager.executions[exec_id] = state
        retrieved = manager.get_execution_status(exec_id)
        assert retrieved is state
        assert retrieved.execution_id == exec_id

    def test_get_execution_status_not_found(self):
        manager = TaskManager()
        result = manager.get_execution_status("nonexistent")
        assert result is None

    def test_get_all_executions_filter_by_project(self):
        manager = TaskManager()
        state1 = ExecutionState(
            execution_id="exec_proj_a",
            project_name="proj_a",
            workflow="autonomous",
        )
        state2 = ExecutionState(
            execution_id="exec_proj_b",
            project_name="proj_b",
            workflow="autonomous",
        )
        manager.executions["exec_proj_a"] = state1
        manager.executions["exec_proj_b"] = state2
        filtered = manager.get_all_executions(project_name="proj_a")
        assert len(filtered) == 1
        assert filtered[0].project_name == "proj_a"

    def test_cleanup_old_executions(self):
        manager = TaskManager()
        now = datetime.now()
        old_state = ExecutionState(
            execution_id="exec_old",
            project_name="test_project",
            workflow="autonomous",
            status=TaskStatus.COMPLETED,
            completed_at=datetime.fromtimestamp(now.timestamp() - 7200),
        )
        new_state = ExecutionState(
            execution_id="exec_new",
            project_name="test_project",
            workflow="autonomous",
            status=TaskStatus.COMPLETED,
            completed_at=datetime.now(),
        )
        pending_state = ExecutionState(
            execution_id="exec_pending",
            project_name="test_project",
            workflow="autonomous",
            status=TaskStatus.RUNNING,
        )
        manager.executions["exec_old"] = old_state
        manager.executions["exec_new"] = new_state
        manager.executions["exec_pending"] = pending_state
        removed = manager.cleanup_old_executions(max_age_hours=1)
        assert removed == 1
        assert "exec_new" in manager.executions
        assert "exec_pending" in manager.executions

    def test_cleanup_old_executions_none(self):
        manager = TaskManager()
        state = ExecutionState(
            execution_id="exec_running",
            project_name="test_project",
            workflow="autonomous",
            status=TaskStatus.RUNNING,
        )
        manager.executions["exec_running"] = state
        removed = manager.cleanup_old_executions()
        assert removed == 0


class TestGetTaskManager:
    def setup_method(self):
        import api.tasks

        api.tasks._task_manager = None

    def test_get_task_manager_creates_instance(self):
        result = get_task_manager()
        assert result is not None
        assert isinstance(result, TaskManager)
        import api.tasks

        api.tasks._task_manager = None

    def test_get_task_manager_returns_same_instance(self):
        mgr1 = get_task_manager()
        mgr2 = get_task_manager()
        assert mgr1 is mgr2
        import api.tasks

        api.tasks._task_manager = None
