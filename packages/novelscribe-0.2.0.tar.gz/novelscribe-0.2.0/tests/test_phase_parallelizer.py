"""Tests for phase_parallelizer module."""

from unittest.mock import AsyncMock, patch

import pytest

from core.phase_parallelizer import (
    PhaseDependency,
    PhaseExecutionResult,
    PhaseGroup,
    PhaseParallelizer,
    get_phase_parallelizer,
    reset_phase_parallelizer,
)


class TestPhaseDependency:
    """Test PhaseDependency dataclass."""

    def test_phase_dependency_creation(self):
        """Test PhaseDependency creation."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )
        assert phase.phase_name == "test_phase"
        assert phase.agent_name == "test_agent"
        assert phase.prompt_template == "Test prompt"
        assert phase.depends_on == []
        assert phase.parallel_group == 0
        assert phase.priority == 0
        assert phase.is_optional is False
        assert phase.metadata == {}

    def test_phase_dependency_with_dependencies(self):
        """Test PhaseDependency with dependencies."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
            depends_on=["dep1", "dep2"],
            parallel_group=1,
            priority=5,
            is_optional=True,
            metadata={"key": "value"},
        )
        assert phase.depends_on == ["dep1", "dep2"]
        assert phase.parallel_group == 1
        assert phase.priority == 5
        assert phase.is_optional is True
        assert phase.metadata == {"key": "value"}


class TestPhaseGroup:
    """Test PhaseGroup dataclass."""

    def test_phase_group_creation(self):
        """Test PhaseGroup creation."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
            ),
        ]
        group = PhaseGroup(group_id=1, phases=phases)
        assert group.group_id == 1
        assert len(group.phases) == 2
        assert group.depends_on_groups == set()

    def test_phase_group_with_dependencies(self):
        """Test PhaseGroup with dependencies."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            )
        ]
        group = PhaseGroup(group_id=2, phases=phases, depends_on_groups={0, 1})
        assert group.depends_on_groups == {0, 1}

    def test_can_parallel_execute_true(self):
        """Test can_parallel_execute property with multiple phases."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
            ),
        ]
        group = PhaseGroup(group_id=1, phases=phases)
        assert group.can_parallel_execute is True

    def test_can_parallel_execute_false(self):
        """Test can_parallel_execute property with single phase."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            )
        ]
        group = PhaseGroup(group_id=1, phases=phases)
        assert group.can_parallel_execute is False

    def test_total_phases(self):
        """Test total_phases property."""
        phases = [
            PhaseDependency(
                phase_name=f"phase{i}",
                agent_name=f"agent{i}",
                prompt_template=f"Prompt {i}",
            )
            for i in range(5)
        ]
        group = PhaseGroup(group_id=1, phases=phases)
        assert group.total_phases == 5


class TestPhaseExecutionResult:
    """Test PhaseExecutionResult dataclass."""

    def test_phase_execution_result_success(self):
        """Test PhaseExecutionResult for successful execution."""
        result = PhaseExecutionResult(
            phase_name="test_phase",
            agent_name="test_agent",
            success=True,
            output="Test output",
            duration=1.5,
            parallel_group=0,
        )
        assert result.phase_name == "test_phase"
        assert result.agent_name == "test_agent"
        assert result.success is True
        assert result.output == "Test output"
        assert result.error is None
        assert result.duration == 1.5
        assert result.parallel_group == 0

    def test_phase_execution_result_failure(self):
        """Test PhaseExecutionResult for failed execution."""
        result = PhaseExecutionResult(
            phase_name="test_phase",
            agent_name="test_agent",
            success=False,
            error="Test error",
            duration=0.5,
        )
        assert result.success is False
        assert result.error == "Test error"
        assert result.output is None


class TestPhaseParallelizer:
    """Test PhaseParallelizer class."""

    @pytest.fixture
    def parallelizer(self):
        """Create PhaseParallelizer instance."""
        return PhaseParallelizer()

    def test_initialization(self, parallelizer):
        """Test PhaseParallelizer initialization."""
        assert parallelizer.phases == {}
        assert parallelizer.execution_order == []

    def test_default_parallel_phases_constant(self):
        """Test DEFAULT_PARALLEL_PHASES constant."""
        assert PhaseParallelizer.DEFAULT_PARALLEL_PHASES == [
            "genre_agent",
            "character_agent",
            "world_agent",
        ]

    def test_add_phase(self, parallelizer):
        """Test adding a phase."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )
        parallelizer.add_phase(phase)
        assert "test_phase" in parallelizer.phases
        assert parallelizer.phases["test_phase"] == phase

    def test_add_phase_batch(self, parallelizer):
        """Test adding multiple phases."""
        phases = [
            PhaseDependency(
                phase_name=f"phase{i}",
                agent_name=f"agent{i}",
                prompt_template=f"Prompt {i}",
            )
            for i in range(3)
        ]
        parallelizer.add_phase_batch(phases)
        assert len(parallelizer.phases) == 3
        assert "phase0" in parallelizer.phases
        assert "phase1" in parallelizer.phases
        assert "phase2" in parallelizer.phases

    def test_remove_phase(self, parallelizer):
        """Test removing a phase."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )
        parallelizer.add_phase(phase)
        assert "test_phase" in parallelizer.phases

        result = parallelizer.remove_phase("test_phase")
        assert result is True
        assert "test_phase" not in parallelizer.phases

    def test_remove_phase_not_found(self, parallelizer):
        """Test removing non-existent phase."""
        result = parallelizer.remove_phase("nonexistent")
        assert result is False

    def test_clear_phases(self, parallelizer):
        """Test clearing all phases."""
        phases = [
            PhaseDependency(
                phase_name=f"phase{i}",
                agent_name=f"agent{i}",
                prompt_template=f"Prompt {i}",
            )
            for i in range(3)
        ]
        parallelizer.add_phase_batch(phases)
        assert len(parallelizer.phases) == 3

        parallelizer.clear_phases()
        assert parallelizer.phases == {}
        assert parallelizer.execution_order == []

    def test_analyze_dependencies_empty(self, parallelizer):
        """Test analyzing dependencies with no phases."""
        groups = parallelizer.analyze_dependencies()
        assert groups == []

    def test_analyze_dependencies_single_phase(self, parallelizer):
        """Test analyzing dependencies with single phase."""
        phase = PhaseDependency(
            phase_name="phase1",
            agent_name="agent1",
            prompt_template="Prompt 1",
        )
        parallelizer.add_phase(phase)
        groups = parallelizer.analyze_dependencies()
        assert len(groups) == 1
        assert groups[0].group_id == 0
        assert len(groups[0].phases) == 1

    def test_analyze_dependencies_independent_phases(self, parallelizer):
        """Test analyzing dependencies with independent phases."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
            ),
        ]
        parallelizer.add_phase_batch(phases)
        groups = parallelizer.analyze_dependencies()
        assert len(groups) == 1
        assert len(groups[0].phases) == 2

    def test_analyze_dependencies_with_chained_dependencies(self, parallelizer):
        """Test analyzing dependencies with chained dependencies."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
                depends_on=["phase1"],
            ),
            PhaseDependency(
                phase_name="phase3",
                agent_name="agent3",
                prompt_template="Prompt 3",
                depends_on=["phase2"],
            ),
        ]
        parallelizer.add_phase_batch(phases)
        groups = parallelizer.analyze_dependencies()
        assert len(groups) == 3
        assert groups[0].phases[0].phase_name == "phase1"
        assert groups[1].phases[0].phase_name == "phase2"
        assert groups[2].phases[0].phase_name == "phase3"

    def test_analyze_dependencies_with_parallel_phases(self, parallelizer):
        """Test analyzing dependencies with parallel phases."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
                depends_on=["phase1"],
            ),
            PhaseDependency(
                phase_name="phase3",
                agent_name="agent3",
                prompt_template="Prompt 3",
                depends_on=["phase1"],
            ),
        ]
        parallelizer.add_phase_batch(phases)
        groups = parallelizer.analyze_dependencies()
        assert len(groups) == 2
        assert len(groups[0].phases) == 1
        assert len(groups[1].phases) == 2

    def test_analyze_dependencies_circular(self, parallelizer):
        """Test analyzing dependencies with circular dependencies."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
                depends_on=["phase2"],
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
                depends_on=["phase1"],
            ),
        ]
        parallelizer.add_phase_batch(phases)
        with pytest.raises(ValueError, match="Circular dependency"):
            parallelizer.analyze_dependencies()

    def test_has_cycle_true(self, parallelizer):
        """Test cycle detection with cycle."""
        graph = {"A": ["B"], "B": ["C"], "C": ["A"]}
        assert parallelizer._has_cycle(graph) is True

    def test_has_cycle_false(self, parallelizer):
        """Test cycle detection without cycle."""
        graph = {"A": ["B"], "B": ["C"], "C": []}
        assert parallelizer._has_cycle(graph) is False

    def test_has_cycle_empty_graph(self, parallelizer):
        """Test cycle detection with empty graph."""
        graph = {}
        assert parallelizer._has_cycle(graph) is False

    def test_topological_group_sort(self, parallelizer):
        """Test topological group sort."""
        graph = {"A": ["B", "C"], "B": ["D"], "C": ["D"], "D": []}
        in_degree = {"A": 0, "B": 1, "C": 1, "D": 2}

        phases = {
            "A": PhaseDependency(phase_name="A", agent_name="agentA", prompt_template="PA"),
            "B": PhaseDependency(phase_name="B", agent_name="agentB", prompt_template="PB"),
            "C": PhaseDependency(phase_name="C", agent_name="agentC", prompt_template="PC"),
            "D": PhaseDependency(phase_name="D", agent_name="agentD", prompt_template="PD"),
        }
        parallelizer.phases = phases

        groups = parallelizer._topological_group_sort(graph, in_degree)
        assert len(groups) == 3
        assert groups[0].phases[0].phase_name == "A"
        assert len(groups[1].phases) == 2
        assert groups[2].phases[0].phase_name == "D"

    @pytest.mark.asyncio
    async def test_execute_groups_sequential(self, parallelizer):
        """Test executing groups sequentially."""
        phase1 = PhaseDependency(
            phase_name="phase1",
            agent_name="agent1",
            prompt_template="Prompt 1",
        )
        group = PhaseGroup(group_id=0, phases=[phase1])

        executor_func = AsyncMock(return_value="Result 1")

        with patch("core.agent_queue.AgentQueue"):
            results = await parallelizer.execute_groups([group], executor_func)

        assert "phase1" in results
        assert results["phase1"].success is True
        assert results["phase1"].output == "Result 1"

    @pytest.mark.asyncio
    async def test_execute_phase_success(self, parallelizer):
        """Test executing single phase successfully."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )
        executor_func = AsyncMock(return_value="Test output")

        result = await parallelizer._execute_phase(phase, executor_func)

        assert result.success is True
        assert result.output == "Test output"
        assert result.phase_name == "test_phase"
        assert result.agent_name == "test_agent"
        assert result.duration > 0

    @pytest.mark.asyncio
    async def test_execute_phase_failure(self, parallelizer):
        """Test executing phase with failure."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
        )
        executor_func = AsyncMock(side_effect=Exception("Test error"))

        result = await parallelizer._execute_phase(phase, executor_func)

        assert result.success is False
        assert result.error == "Test error"
        assert result.output is None
        assert result.phase_name == "test_phase"

    def test_get_execution_plan_empty(self, parallelizer):
        """Test getting execution plan with no phases."""
        plan = parallelizer.get_execution_plan()
        assert plan == "Execution Plan:"

    def test_get_execution_plan_sequential(self, parallelizer):
        """Test getting execution plan for sequential phases."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
                depends_on=["phase1"],
            ),
        ]
        parallelizer.add_phase_batch(phases)
        plan = parallelizer.get_execution_plan()
        assert "Execution Plan:" in plan
        assert "Group 0" in plan
        assert "phase1" in plan
        assert "phase2" in plan

    def test_get_execution_plan_parallel(self, parallelizer):
        """Test getting execution plan for parallel phases."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
                depends_on=["phase1"],
            ),
            PhaseDependency(
                phase_name="phase3",
                agent_name="agent3",
                prompt_template="Prompt 3",
                depends_on=["phase1"],
            ),
        ]
        parallelizer.add_phase_batch(phases)
        plan = parallelizer.get_execution_plan()
        assert "PARALLEL" in plan

    def test_create_novel_generation_phases(self):
        """Test creating novel generation phases."""
        parallelizer = PhaseParallelizer.create_novel_generation_phases(project_name="test_project")
        assert len(parallelizer.phases) == 5
        assert "discuss" in parallelizer.phases
        assert "genre" in parallelizer.phases
        assert "characters" in parallelizer.phases
        assert "world" in parallelizer.phases
        assert "outline" in parallelizer.phases

    def test_create_novel_generation_phases_with_genre(self):
        """Test creating novel generation phases with genre."""
        parallelizer = PhaseParallelizer.create_novel_generation_phases(
            project_name="test_project", genre="fantasy"
        )
        assert len(parallelizer.phases) == 5

    def test_create_novel_generation_phases_with_outline(self):
        """Test creating novel generation phases with outline."""
        parallelizer = PhaseParallelizer.create_novel_generation_phases(
            project_name="test_project", outline="Test outline"
        )
        assert len(parallelizer.phases) == 5

    def test_novel_generation_phases_structure(self):
        """Test novel generation phases have correct structure."""
        parallelizer = PhaseParallelizer.create_novel_generation_phases(project_name="test_project")
        groups = parallelizer.analyze_dependencies()

        assert len(groups) == 3
        assert groups[0].phases[0].phase_name == "discuss"
        assert len(groups[1].phases) == 3
        assert groups[2].phases[0].phase_name == "outline"

    def test_novel_generation_dependencies(self):
        """Test novel generation phases have correct dependencies."""
        parallelizer = PhaseParallelizer.create_novel_generation_phases(project_name="test_project")

        genre_phase = parallelizer.phases["genre"]
        assert genre_phase.depends_on == ["discuss"]

        outline_phase = parallelizer.phases["outline"]
        assert "genre" in outline_phase.depends_on
        assert "characters" in outline_phase.depends_on
        assert "world" in outline_phase.depends_on

    def test_phase_metadata_preservation(self, parallelizer):
        """Test that phase metadata is preserved."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
            metadata={"key1": "value1", "key2": 123},
        )
        parallelizer.add_phase(phase)
        assert parallelizer.phases["test_phase"].metadata == {
            "key1": "value1",
            "key2": 123,
        }

    def test_phase_priority_preservation(self, parallelizer):
        """Test that phase priority is preserved."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
            priority=10,
        )
        parallelizer.add_phase(phase)
        assert parallelizer.phases["test_phase"].priority == 10

    def test_phase_optional_preservation(self, parallelizer):
        """Test that phase optional flag is preserved."""
        phase = PhaseDependency(
            phase_name="test_phase",
            agent_name="test_agent",
            prompt_template="Test prompt",
            is_optional=True,
        )
        parallelizer.add_phase(phase)
        assert parallelizer.phases["test_phase"].is_optional is True

    def test_analyze_dependencies_updates_parallel_group(self, parallelizer):
        """Test that analyze_dependencies updates parallel_group."""
        phases = [
            PhaseDependency(
                phase_name="phase1",
                agent_name="agent1",
                prompt_template="Prompt 1",
            ),
            PhaseDependency(
                phase_name="phase2",
                agent_name="agent2",
                prompt_template="Prompt 2",
                depends_on=["phase1"],
            ),
        ]
        parallelizer.add_phase_batch(phases)
        parallelizer.analyze_dependencies()

        assert parallelizer.phases["phase1"].parallel_group == 0
        assert parallelizer.phases["phase2"].parallel_group == 1


class TestGlobalFunctions:
    """Test global functions."""

    def test_get_phase_parallelizer_singleton(self):
        """Test get_phase_parallelizer returns singleton."""
        reset_phase_parallelizer()
        parallelizer1 = get_phase_parallelizer()
        parallelizer2 = get_phase_parallelizer()
        assert parallelizer1 is parallelizer2

    def test_reset_phase_parallelizer(self):
        """Test reset_phase_parallelizer."""
        parallelizer1 = get_phase_parallelizer()
        reset_phase_parallelizer()
        parallelizer2 = get_phase_parallelizer()
        assert parallelizer1 is not parallelizer2

    def test_get_phase_parallelizer_initialization(self):
        """Test get_phase_parallelizer creates instance."""
        reset_phase_parallelizer()
        parallelizer = get_phase_parallelizer()
        assert isinstance(parallelizer, PhaseParallelizer)
