"""Test coverage for core/cost_calculator.py."""

import pytest

from core.cost_calculator import CostCalculator


class TestCostCalculator:
    """Test CostCalculator class."""

    def setup_method(self):
        self.calculator = CostCalculator()

    def test_calculate_gpt4_input(self):
        cost = self.calculator.calculate("openai", "gpt-4", input_tokens=1000, output_tokens=500)
        expected = (1000 / 1000) * 0.03 + (500 / 1000) * 0.06
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_gpt35_turbo(self):
        cost = self.calculator.calculate(
            "openai", "gpt-3.5-turbo", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.0005 + (500 / 1000) * 0.0015
        assert abs(cost - expected) <= 1e-5

    def test_calculate_claude3_opus(self):
        cost = self.calculator.calculate(
            "anthropic", "claude-3-opus", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.015 + (500 / 1000) * 0.075
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_claude3_sonnet(self):
        cost = self.calculator.calculate(
            "anthropic", "claude-3-sonnet", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.003 + (500 / 1000) * 0.015
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_gemini_pro(self):
        cost = self.calculator.calculate(
            "google", "gemini-pro", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.000125 + (500 / 1000) * 0.000375
        assert abs(cost - expected) <= 1e-5

    def test_calculate_ollama_free(self):
        cost = self.calculator.calculate("ollama", "llama2", input_tokens=1000, output_tokens=500)
        assert cost == 0.0

    def test_calculate_unknown_provider(self):
        cost = self.calculator.calculate(
            "unknown", "some-model", input_tokens=1000, output_tokens=500
        )
        assert cost == 0.0

    def test_calculate_unknown_model_with_default(self):
        cost = self.calculator.calculate(
            "ollama", "unknown-model", input_tokens=1000, output_tokens=500
        )
        assert cost == 0.0

    def test_calculate_prefix_match_gpt4(self):
        cost = self.calculator.calculate(
            "openai", "gpt-4-turbo", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.01 + (500 / 1000) * 0.03
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_prefix_match_reverse(self):
        cost = self.calculator.calculate(
            "openai", "gpt-4-turbo-2024-04-09", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.01 + (500 / 1000) * 0.03
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_gpt4o(self):
        cost = self.calculator.calculate("openai", "gpt-4o", input_tokens=1000, output_tokens=500)
        expected = (1000 / 1000) * 0.005 + (500 / 1000) * 0.015
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_gpt4o_mini(self):
        cost = self.calculator.calculate(
            "openai", "gpt-4o-mini", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.00015 + (500 / 1000) * 0.0006
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_claude_instant(self):
        cost = self.calculator.calculate(
            "anthropic", "claude-instant", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.0008 + (500 / 1000) * 0.0024
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_gemini_15_flash(self):
        cost = self.calculator.calculate(
            "google", "gemini-1.5-flash", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.000075 + (500 / 1000) * 0.0003
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_calculate_embeddings_only_input(self):
        cost = self.calculator.calculate(
            "openai", "text-embedding-3-large", input_tokens=1000, output_tokens=500
        )
        expected = (1000 / 1000) * 0.00013 + (500 / 1000) * 0.0
        assert cost == pytest.approx(expected, rel=1e-4)

    def test_get_cost_breakdown_gpt4(self):
        breakdown = self.calculator.get_cost_breakdown("openai", "gpt-4", 1000, 500)
        assert breakdown["provider"] == "openai"
        assert breakdown["model"] == "gpt-4"
        assert breakdown["input_tokens"] == 1000
        assert breakdown["output_tokens"] == 500
        assert breakdown["input_rate_per_1k"] == 0.03
        assert breakdown["output_rate_per_1k"] == 0.06
        assert breakdown["input_cost_usd"] == pytest.approx(0.03, rel=1e-4)
        assert breakdown["output_cost_usd"] == pytest.approx(0.03, rel=1e-4)
        assert breakdown["total_cost_usd"] == pytest.approx(0.06, rel=1e-4)

    def test_get_cost_breakdown_unknown_provider(self):
        breakdown = self.calculator.get_cost_breakdown("unknown", "model", 1000, 500)
        assert breakdown["input_cost_usd"] == 0.0
        assert breakdown["output_cost_usd"] == 0.0
        assert breakdown["total_cost_usd"] == 0.0

    def test_get_supported_models_openai(self):
        models = self.calculator.get_supported_models("openai")
        assert "gpt-4" in models
        assert "gpt-3.5-turbo" in models
        assert "gpt-4o" in models
        assert "text-embedding-3-large" in models

    def test_get_supported_models_anthropic(self):
        models = self.calculator.get_supported_models("anthropic")
        assert "claude-3-opus" in models
        assert "claude-3-sonnet" in models
        assert "claude-instant" in models

    def test_get_supported_models_google(self):
        models = self.calculator.get_supported_models("google")
        assert "gemini-pro" in models
        assert "gemini-1.5-flash" in models

    def test_get_supported_models_ollama(self):
        models = self.calculator.get_supported_models("ollama")
        assert "llama2" in models
        assert "mistral" in models

    def test_get_supported_models_unknown(self):
        models = self.calculator.get_supported_models("unknown")
        assert models == []

    def test_get_provider_rates_openai_gpt4(self):
        rates = self.calculator.get_provider_rates("openai", "gpt-4")
        assert rates is not None
        assert rates["input"] == 0.03
        assert rates["output"] == 0.06

    def test_get_provider_rates_prefix_match(self):
        rates = self.calculator.get_provider_rates("openai", "gpt-4-turbo")
        assert rates is not None
        assert rates["input"] == 0.01
        assert rates["output"] == 0.03

    def test_get_provider_rates_unknown_provider(self):
        rates = self.calculator.get_provider_rates("unknown", "model")
        assert rates is None

    def test_get_provider_rates_unknown_model_with_default(self):
        rates = self.calculator.get_provider_rates("ollama", "unknown-model")
        assert rates is not None
        assert rates["input"] == 0.0
        assert rates["output"] == 0.0

    def test_case_insensitive_provider(self):
        cost = self.calculator.calculate("OPenai", "gpt-4", input_tokens=1000, output_tokens=500)
        assert cost > 0

    def test_calculate_zero_tokens(self):
        cost = self.calculator.calculate("openai", "gpt-4", input_tokens=0, output_tokens=0)
        assert cost == 0.0
