"""Test coverage for API app, routers, and endpoints."""

from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from api.app import app


@pytest.fixture
def client():
    return TestClient(app)


class TestAppHealth:
    def test_health_check(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert data["version"] == "1.0.0"

    def test_root(self, client):
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Novel Generation API"
        assert data["status"] == "running"
        assert "endpoints" in data

    def test_root_includes_documentation(self, client):
        response = client.get("/")
        data = response.json()
        assert data["documentation"] == "/docs"
        assert data["redoc"] == "/redoc"
        assert data["openapi"] == "/openapi.json"

    def test_request_id_middleware(self, client):
        response = client.get("/health")
        assert "x-request-id" in {k.lower() for k in response.headers}

    def test_request_id_custom_header(self, client):
        response = client.get("/health", headers={"X-Request-ID": "custom-id-123"})
        assert response.headers.get("x-request-id") == "custom-id-123"

    def test_get_system_status(self, client):
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["project_a", "project_b"]
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/status")
            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "healthy"
            assert data["projects_count"] == 2
            assert data["active_executions"] == 0
            assert "uptime_seconds" in data

    def test_get_system_status_storage_error(self, client):
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.side_effect = Exception("DB error")
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/status")
            assert response.status_code == 200
            data = response.json()
            assert data["projects_count"] == 0

    def test_exception_handler_http_exception(self, client):
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test"]
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/status/nonexistent_proj")
            assert response.status_code == 404

    def test_exception_handler_general_exception(self, client):
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.side_effect = RuntimeError("Unexpected error")
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/status")
            assert response.status_code == 200
            data = response.json()
            assert data["projects_count"] == 0


class TestProjectsRouter:
    def test_list_projects_empty(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/projects/")
            assert response.status_code == 200
            data = response.json()
            assert data == []

    def test_list_projects_with_data(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_proj.meta = {"status": "created", "created": datetime.now().isoformat()}
            mock_instance.load_project.return_value = mock_proj
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/projects/")
            assert response.status_code == 200
            data = response.json()
            assert len(data) == 1
            assert data[0]["name"] == "my_project"

    def test_list_projects_skips_unloadable(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["good_proj", "bad_proj"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_proj.meta = {
                "status": "created",
                "created": datetime.now().isoformat(),
            }
            mock_instance.load_project.side_effect = [mock_proj, Exception("bad")]
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/projects/")
            assert response.status_code == 200
            data = response.json()
            assert len(data) == 1

    def test_create_project_success(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_proj = MagicMock()
            mock_proj.meta = {"status": "created", "created": datetime.now().isoformat()}
            mock_instance.load_project.return_value = mock_proj
            mock_instance.save_project.return_value = None
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance
            response = client.post(
                "/api/v1/projects/",
                json={"name": "new_project", "provider": "openai", "model": "gpt-4"},
            )
            assert response.status_code == 201
            data = response.json()
            assert data["name"] == "new_project"

    def test_create_project_already_exists(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["existing_project"]
            mock_storage.return_value = mock_instance
            response = client.post(
                "/api/v1/projects/",
                json={"name": "existing_project"},
            )
            assert response.status_code == 400

    def test_create_project_name_with_slash(self, client):
        response = client.post(
            "/api/v1/projects/",
            json={"name": "proj/withslash"},
        )
        assert response.status_code == 422

    def test_get_project_success(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_proj.meta = {
                "status": "created",
                "created": datetime.now().isoformat(),
            }
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/projects/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["name"] == "my_project"

    def test_get_project_not_found(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/projects/nonexistent")
            assert response.status_code == 404

    def test_get_project_path_with_slash(self, client):
        response = client.get("/api/v1/projects/bad/name")
        assert response.status_code == 404

    def test_delete_project_success(self, client):
        with patch("api.routers.projects.Storage") as mock_storage, patch("shutil.rmtree"):
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["to_delete"]
            mock_proj_path = MagicMock()
            mock_proj_path.exists.return_value = True
            mock_instance.project_dir = MagicMock()
            mock_instance.project_dir.__truediv__.return_value = mock_proj_path
            mock_storage.return_value = mock_instance
            response = client.delete("/api/v1/projects/to_delete")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True

    def test_delete_project_not_found(self, client):
        with patch("api.routers.projects.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            response = client.delete("/api/v1/projects/nonexistent")
            assert response.status_code == 404

    def test_get_project_status_invalid_name_with_slash(self, client):
        """Test that project names with slashes return 400."""
        response = client.get("/api/v1/status/proj/ect")
        assert response.status_code == 404

    def test_get_project_status_with_chapters(self, client):
        """Test getting status for a project with chapters."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_chapter = MagicMock()
            mock_chapter.number = 1
            mock_proj = MagicMock()
            mock_proj.chapters = [mock_chapter]
            mock_proj.meta = {
                "status": "writing",
                "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat(),
                "phase": "chapters",
            }
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["chapter_count"] == 1
            assert data["last_activity"] is not None

    def test_get_project_status_without_updated_field(self, client):
        """Test getting status when only created field exists."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_proj.meta = {
                "status": "created",
                "created": datetime.now().isoformat(),
            }
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["last_activity"] is not None

    def test_get_project_status_exception_handling(self, client):
        """Test exception handling in get_project_status."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_instance.load_project.side_effect = Exception("Load error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project")
            assert response.status_code == 500

    def test_get_draft_status_invalid_name(self, client):
        """Test draft status with invalid project name."""
        response = client.get("/api/v1/status/proj/ect/drafts")
        assert response.status_code == 404

    def test_get_draft_status_not_found(self, client):
        """Test draft status for nonexistent project."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/nonexistent/drafts")
            assert response.status_code == 404

    def test_get_draft_status_with_chapters_and_versions(self, client, tmp_path):
        """Test draft status with actual chapter versions."""
        project_dir = tmp_path / "my_project"
        drafts_dir = project_dir / "drafts"
        chapter_dir = drafts_dir / "chapter_1"
        chapter_dir.mkdir(parents=True)
        (chapter_dir / "v1.md").write_text("# Version 1")
        (chapter_dir / "v2.md").write_text("# Version 2")

        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_chapter = MagicMock()
            mock_chapter.number = 1
            mock_chapter.current_version = 2
            mock_proj = MagicMock()
            mock_proj.chapters = [mock_chapter]
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = tmp_path
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project/drafts")
            assert response.status_code == 200
            data = response.json()
            assert data["total_chapters"] == 1
            assert data["total_versions"] == 3
            assert data["chapters"][0]["versions"] == 3

    def test_get_draft_status_exception_handling(self, client):
        """Test exception handling in get_draft_status."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_instance.load_project.side_effect = Exception("Load error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project/drafts")
            assert response.status_code == 500


class TestLogsRouterExtended:
    def test_get_project_logs_empty(self, client):
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_proj.meta = {
                "status": "writing",
                "created": datetime.now().isoformat(),
                "phase": "chapters",
            }
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/logs/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["total"] == 0

    def test_get_project_status_not_found(self, client):
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/status/nonexistent")
            assert response.status_code == 404

    def test_get_project_status_path_with_slash(self, client):
        response = client.get("/api/v1/status/bad/name")
        assert response.status_code == 404

    def test_get_draft_status_no_chapters(self, client):
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/status/my_project/drafts")
            assert response.status_code == 200
            data = response.json()
            assert data["total_chapters"] == 0


class TestLogsRouter:
    def test_get_project_logs_empty(self, client):
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_instance.project_dir = MagicMock()
            mock_instance.project_dir.__truediv__.return_value = MagicMock()
            logs_dir = MagicMock()
            logs_dir.exists.return_value = False
            mock_instance.project_dir.__truediv__.return_value.__truediv__.return_value = logs_dir
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/logs/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["logs"] == []
            assert data["total"] == 0

    def test_get_project_logs_path_with_slash(self, client):
        response = client.get("/api/v1/logs/bad%2Fname")
        assert response.status_code == 404

    def test_get_execution_logs(self, client):
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_instance.project_dir = MagicMock()
            mock_instance.project_dir.__truediv__.return_value = MagicMock()
            logs_dir = MagicMock()
            logs_dir.exists.return_value = False
            mock_instance.project_dir.__truediv__.return_value.__truediv__.return_value = logs_dir
            mock_storage.return_value = mock_instance
            response = client.get("/api/v1/logs/my_project/exec_123")
            assert response.status_code == 200


class TestWorkflowsRouter:
    def test_list_workflows(self, client):
        response = client.get("/api/v1/workflows/")
        assert response.status_code == 200
        data = response.json()
        assert len(data["workflows"]) > 0
        workflow_names = [w["name"] for w in data["workflows"]]
        assert "autonomous" in workflow_names
        assert "write_chapter" in workflow_names

    def test_get_workflow_details(self, client):
        response = client.get("/api/v1/workflows/autonomous")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "autonomous"

    def test_get_workflow_not_found(self, client):
        response = client.get("/api/v1/workflows/nonexistent_workflow")
        assert response.status_code == 404

    def test_run_workflow_project_not_found(self, client):
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            response = client.post(
                "/api/v1/workflows/run",
                json={"project_name": "nonexistent", "workflow": "autonomous"},
            )
            assert response.status_code == 404

    def test_run_workflow_success(self, client):
        with (
            patch("api.routers.workflows.get_task_manager") as mock_task_mgr,
            patch("core.storage.Storage") as mock_storage,
        ):
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_storage.return_value = mock_instance
            mock_manager = MagicMock()
            mock_state = MagicMock()
            mock_state.execution_id = "exec_abc"
            mock_state.status = "pending"
            mock_state.started_at = datetime.now()
            mock_manager.execute_workflow.return_value = mock_state
            mock_task_mgr.return_value = mock_manager
            response = client.post(
                "/api/v1/workflows/run",
                json={
                    "project_name": "my_project",
                    "workflow": "autonomous",
                    "background": True,
                },
            )
            assert response.status_code == 202

    def test_get_execution_status_not_found(self, client):
        with patch("api.routers.workflows.get_task_manager") as mock_task_mgr:
            mock_manager = MagicMock()
            mock_manager.get_execution_status.return_value = None
            mock_task_mgr.return_value = mock_manager
            response = client.get("/api/v1/workflows/run/nonexistent_exec")
            assert response.status_code == 404

    def test_cancel_execution_not_running(self, client):
        from api.tasks import TaskStatus

        with patch("api.routers.workflows.get_task_manager") as mock_task_mgr:
            mock_manager = MagicMock()
            mock_state = MagicMock()
            mock_state.status = TaskStatus.COMPLETED
            mock_manager.get_execution_status.return_value = mock_state
            mock_task_mgr.return_value = mock_manager
            response = client.post("/api/v1/workflows/run/exec_123/cancel")
            assert response.status_code == 400

    def test_cancel_execution_success(self, client):
        from api.tasks import TaskStatus

        with patch("api.routers.workflows.get_task_manager") as mock_task_mgr:
            mock_manager = MagicMock()
            mock_state = MagicMock()
            mock_state.status = TaskStatus.RUNNING
            mock_manager.get_execution_status.return_value = mock_state
            mock_manager.cancel_execution.return_value = True
            mock_task_mgr.return_value = mock_manager
            response = client.post("/api/v1/workflows/run/exec_123/cancel")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True

    def test_map_task_status(self):
        from api.models import ExecutionStatus as APIExecutionStatus
        from api.routers.workflows import _map_task_status
        from api.tasks import TaskStatus

        assert _map_task_status(TaskStatus.PENDING) == APIExecutionStatus.PENDING
        assert _map_task_status(TaskStatus.RUNNING) == APIExecutionStatus.RUNNING
        assert _map_task_status(TaskStatus.COMPLETED) == APIExecutionStatus.COMPLETED
        assert _map_task_status(TaskStatus.FAILED) == APIExecutionStatus.FAILED
        assert _map_task_status(TaskStatus.CANCELLED) == APIExecutionStatus.CANCELLED


class TestWebsocketRouter:
    @pytest.mark.skip(reason="WebSocket tests hang in TestClient")
    def test_websocket_global_endpoint(self, client):
        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr:
            mock_manager = AsyncMock()
            mock_manager.connect.return_value = "client_123"
            mock_manager.disconnect.return_value = AsyncMock()
            mock_manager.send_to_client.return_value = AsyncMock()
            mock_manager.handle_client_message.return_value = None
            mock_mgr.return_value = mock_manager
            with client.websocket_connect("/ws") as websocket:
                websocket.send_json({"type": "ping"})
                websocket.send_json({"type": "subscribe", "event_types": ["log"]})

    @pytest.mark.skip(reason="WebSocket tests hang in TestClient")
    def test_websocket_project_endpoint(self, client):
        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr:
            mock_manager = AsyncMock()
            mock_manager.connect.return_value = "client_456"
            mock_manager.disconnect.return_value = AsyncMock()
            mock_manager.send_to_client.return_value = AsyncMock()
            mock_manager.handle_client_message.return_value = None
            mock_mgr.return_value = mock_manager
            with client.websocket_connect("/ws/my_project") as websocket:
                websocket.send_json({"type": "ping"})

    @pytest.mark.skip(reason="WebSocket tests hang in TestClient")
    def test_websocket_project_invalid_name(self, client):
        with pytest.raises(Exception):
            with client.websocket_connect("/ws/bad%2Fname"):
                pass

    @pytest.mark.skip(reason="WebSocket tests hang in TestClient")
    def test_websocket_execution_endpoint(self, client):
        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr:
            mock_manager = AsyncMock()
            mock_manager.connect.return_value = "client_789"
            mock_manager.send_to_client.return_value = AsyncMock()
            mock_manager.disconnect.return_value = AsyncMock()
            mock_mgr.return_value = mock_manager
            with client.websocket_connect("/ws/my_project/execution/exec_abc") as websocket:
                websocket.send_json({"type": "ping"})

    @pytest.mark.skip(reason="WebSocket tests hang in TestClient")
    def test_websocket_invalid_json(self, client):
        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr:
            mock_manager = AsyncMock()
            mock_manager.connect.return_value = "client_abc"
            mock_manager.send_to_client.return_value = AsyncMock()
            mock_manager.disconnect.return_value = AsyncMock()
            mock_mgr.return_value = mock_manager
            with client.websocket_connect("/ws") as websocket:
                websocket.send_text("not json")


class TestStreamingRouter:
    def test_format_sse(self):
        from api.routers.streaming import format_sse

        result = format_sse("log", {"message": "hello"})
        assert "event: log" in result
        assert '"message": "hello"' in result
        assert result.endswith("\n\n")

    def test_stream_logs_invalid_name(self, client):
        response = client.get("/api/v1/stream/logs/bad%2Fname")
        assert response.status_code == 404

    def test_stream_status_invalid_name(self, client):
        response = client.get("/api/v1/stream/status/bad%2Fname")
        assert response.status_code == 404

    def test_stream_events_invalid_name(self, client):
        response = client.get("/api/v1/stream/events/bad%2Fname")
        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_generate_log_events_nonexistent_project(self):
        from api.routers.streaming import generate_log_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            gen = generate_log_events("nonexistent")
            result = await gen.__anext__()
            assert "error" in result
            assert "Project not found" in result

    @pytest.mark.asyncio
    async def test_generate_status_events_nonexistent_project(self):
        from api.routers.streaming import generate_status_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance
            gen = generate_status_events("nonexistent")
            result = await gen.__anext__()
            assert "error" in result
            assert "Project not found" in result


class TestSuggestionsRouter:
    def test_list_suggestions(self, client):
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_suggestion = MagicMock()
            mock_suggestion.id = "sug_001"
            mock_suggestion.name = "Test Suggestion"
            mock_suggestion.description = "A test"
            mock_suggestion.best_for = []
            mock_suggestion.examples = []
            mock_suggestion.source = MagicMock()
            mock_suggestion.source.value = "static"
            mock_suggestion.acceptance_rate = 0.8
            mock_instance.load_suggestions.return_value = [mock_suggestion]
            mock_kb.return_value = mock_instance
            response = client.get("/api/v1/suggestions/")
            assert response.status_code == 200

    def test_list_suggestions_invalid_category(self, client):
        response = client.get("/api/v1/suggestions/?category=invalid")
        assert response.status_code == 400

    def test_list_suggestions_invalid_source(self, client):
        response = client.get("/api/v1/suggestions/?source=invalid")
        assert response.status_code == 400

    def test_get_suggestion_not_found(self, client):
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_instance.get_suggestion.return_value = None
            mock_kb.return_value = mock_instance
            response = client.get("/api/v1/suggestions/nonexistent_id")
            assert response.status_code == 404

    def test_get_contextual_suggestions_invalid_trigger(self, client):
        response = client.post("/api/v1/suggestions/get?project_id=p1&trigger_type=invalid")
        assert response.status_code == 400

    def test_record_suggestion_invalid_trigger(self, client):
        response = client.post(
            "/api/v1/suggestions/record",
            json={
                "project_name": "p1",
                "suggestion_id": "sug_001",
                "accepted": True,
                "user_choice": "choice",
                "trigger_type": "invalid",
                "category": "genre",
            },
        )
        data = response.json()
        assert data["success"] is False

    def test_record_suggestion_invalid_category(self, client):
        response = client.post(
            "/api/v1/suggestions/record",
            json={
                "project_name": "p1",
                "suggestion_id": "sug_001",
                "accepted": True,
                "user_choice": "choice",
                "trigger_type": "decision_point",
                "category": "invalid",
            },
        )
        data = response.json()
        assert data["success"] is False

    def test_list_learned_suggestions(self, client):
        response = client.get("/api/v1/suggestions/learned")
        assert response.status_code in (200, 404)

    def test_get_analytics(self, client):
        response = client.get("/api/v1/suggestions/analytics?days=7")
        assert response.status_code in (200, 404)

    def test_promote_suggestion_no_confirm(self, client):
        response = client.post("/api/v1/suggestions/sug_001/promote?confirm=false")
        assert response.status_code == 400

    def test_get_learning_insights(self, client):
        response = client.get("/api/v1/suggestions/insights?days=30")
        assert response.status_code in (200, 404)
