"""Tests for autonomous_executor module."""

from unittest.mock import Mock, patch

import pytest

from core.autonomous_executor import (
    AutonomousConfig,
    AutonomousExecutor,
    AutonomousResult,
)
from core.human_checkpoint import CheckpointDecision, CheckpointType
from core.progress_tracker import ExecutionStatus


class TestAutonomousConfig:
    """Test AutonomousConfig model."""

    def test_autonomous_config_default_values(self):
        """Test AutonomousConfig with default values."""
        config = AutonomousConfig(project_name="test_project")
        assert config.project_name == "test_project"
        assert config.start_phase == "new_novel"
        assert config.end_phase == "verification_phase"
        assert config.human_in_loop is False
        assert config.max_chapters is None
        assert config.provider == "openai"

    def test_autonomous_config_custom_values(self):
        """Test AutonomousConfig with custom values."""
        config = AutonomousConfig(
            project_name="custom_project",
            start_phase="outline_phase",
            end_phase="writing_phase",
            human_in_loop=True,
            max_chapters=10,
            provider="anthropic",
        )
        assert config.project_name == "custom_project"
        assert config.start_phase == "outline_phase"
        assert config.end_phase == "writing_phase"
        assert config.human_in_loop is True
        assert config.max_chapters == 10
        assert config.provider == "anthropic"

    def test_autonomous_config_validation(self):
        """Test AutonomousConfig accepts empty project name."""
        config = AutonomousConfig(project_name="")
        assert config.project_name == ""


class TestAutonomousResult:
    """Test AutonomousResult model."""

    def test_autonomous_result_success(self):
        """Test AutonomousResult for successful execution."""
        result = AutonomousResult(
            success=True,
            completed_phases=["phase1", "phase2"],
            final_status=ExecutionStatus.COMPLETED,
        )
        assert result.success is True
        assert result.completed_phases == ["phase1", "phase2"]
        assert result.final_status == ExecutionStatus.COMPLETED
        assert result.error is None
        assert result.checkpoint_id is None

    def test_autonomous_result_failure(self):
        """Test AutonomousResult for failed execution."""
        result = AutonomousResult(
            success=False,
            completed_phases=["phase1"],
            final_status=ExecutionStatus.FAILED,
            error="Something went wrong",
        )
        assert result.success is False
        assert result.completed_phases == ["phase1"]
        assert result.final_status == ExecutionStatus.FAILED
        assert result.error == "Something went wrong"

    def test_autonomous_result_paused(self):
        """Test AutonomousResult for paused execution."""
        result = AutonomousResult(
            success=False,
            completed_phases=["phase1", "phase2"],
            final_status=ExecutionStatus.PAUSED,
            checkpoint_id="checkpoint_123",
        )
        assert result.success is False
        assert result.final_status == ExecutionStatus.PAUSED
        assert result.checkpoint_id == "checkpoint_123"


class TestAutonomousExecutor:
    """Test AutonomousExecutor class."""

    @pytest.fixture
    def temp_path(self, tmp_path):
        """Create temporary storage path."""
        return tmp_path / "storage"

    @pytest.fixture
    def mock_storage(self):
        """Create mock storage backend."""
        storage = Mock()
        storage.store.return_value = "storage_key"
        storage.retrieve.return_value = "content"
        return storage

    @pytest.fixture
    def mock_llm_client(self):
        """Create mock LLM client."""
        client = Mock()
        client.generate.return_value = "Generated content"
        return client

    @pytest.fixture
    def mock_agent_integration(self):
        """Create mock agent integration."""
        integration = Mock()
        integration.execute_agent.return_value = {"success": True, "output": "Agent output"}
        return integration

    @pytest.fixture
    def mock_workflow_executor(self):
        """Create mock workflow executor."""
        executor = Mock()
        executor.execute_workflow.return_value = {"success": True, "result": "Workflow result"}
        return executor

    @pytest.fixture
    def mock_progress_tracker(self):
        """Create mock progress tracker."""
        tracker = Mock()
        tracker.get_state.return_value = Mock(
            current_phase="test_phase",
            completed_phases=["phase1"],
            total_steps=5,
            current_step=1,
            status=ExecutionStatus.RUNNING,
        )
        return tracker

    @pytest.fixture
    def mock_checkpoint_manager(self):
        """Create mock checkpoint manager."""
        manager = Mock()
        checkpoint = Mock()
        checkpoint.completed_workflows = ["phase1"]
        checkpoint.execution_context = {"project_name": "test"}
        checkpoint.progress_state = Mock()
        manager.load_checkpoint.return_value = checkpoint
        manager.validate_checkpoint.return_value = True
        manager.create_checkpoint.return_value = "checkpoint_id"
        return manager

    @pytest.fixture
    def mock_human_handler(self):
        """Create mock human checkpoint handler."""
        handler = Mock()
        handler.should_pause_at_phase.return_value = False
        return handler

    @pytest.fixture
    def mock_git_manager(self):
        """Create mock git manager."""
        manager = Mock()
        manager.auto_commit_step.return_value = True
        return manager

    @pytest.fixture
    def executor(
        self,
        temp_path,
        mock_storage,
        mock_llm_client,
        mock_agent_integration,
        mock_workflow_executor,
        mock_progress_tracker,
        mock_checkpoint_manager,
        mock_human_handler,
        mock_git_manager,
    ):
        """Create AutonomousExecutor instance with mocked dependencies."""
        config = AutonomousConfig(project_name="test_project")

        with patch("core.autonomous_executor.StorageFactory.create") as mock_storage_factory:
            with patch("core.autonomous_executor.OpenAIClient") as mock_llm_constructor:
                with patch(
                    "core.autonomous_executor.AgentSystemIntegration"
                ) as mock_agent_constructor:
                    with patch(
                        "core.autonomous_executor.create_git_manager"
                    ) as mock_git_constructor:
                        with patch(
                            "core.autonomous_executor.WorkflowExecutor"
                        ) as mock_workflow_constructor:
                            with patch(
                                "core.autonomous_executor.ProgressTracker"
                            ) as mock_tracker_constructor:
                                with patch(
                                    "core.autonomous_executor.CheckpointManager"
                                ) as mock_checkpoint_constructor:
                                    with patch(
                                        "core.autonomous_executor.HumanCheckpointHandler"
                                    ) as mock_handler_constructor:
                                        mock_storage_factory.return_value = mock_storage
                                        mock_llm_constructor.return_value = mock_llm_client
                                        mock_agent_constructor.return_value = mock_agent_integration
                                        mock_workflow_constructor.return_value = (
                                            mock_workflow_executor
                                        )
                                        mock_tracker_constructor.return_value = (
                                            mock_progress_tracker
                                        )
                                        mock_checkpoint_constructor.return_value = (
                                            mock_checkpoint_manager
                                        )
                                        mock_handler_constructor.return_value = mock_human_handler
                                        mock_git_constructor.return_value = mock_git_manager

                                        executor = AutonomousExecutor(
                                            config=config,
                                            storage_path=temp_path,
                                        )

        return executor

    def test_workflow_chain_constant(self):
        """Test WORKFLOW_CHAIN constant."""
        assert AutonomousExecutor.WORKFLOW_CHAIN == [
            "new_novel",
            "worldbuilding_phase",
            "character_phase",
            "outline_phase",
            "chapter_plan_phase",
            "writing_phase",
            "continuity_phase",
            "verification_phase",
        ]

    def test_human_checkpoints_constant(self):
        """Test HUMAN_CHECKPOINTS constant."""
        assert len(AutonomousExecutor.HUMAN_CHECKPOINTS) == 3
        assert AutonomousExecutor.HUMAN_CHECKPOINTS[0].phase == "outline_phase"
        assert AutonomousExecutor.HUMAN_CHECKPOINTS[0].type == CheckpointType.APPROVAL
        assert AutonomousExecutor.HUMAN_CHECKPOINTS[1].phase == "character_phase"
        assert AutonomousExecutor.HUMAN_CHECKPOINTS[1].type == CheckpointType.INPUT
        assert AutonomousExecutor.HUMAN_CHECKPOINTS[2].phase == "chapter_plan_phase"

    def test_initialization(self, executor):
        """Test AutonomousExecutor initialization."""
        assert executor.config.project_name == "test_project"
        assert executor.logger is not None
        assert hasattr(executor, "agent_integration")
        assert hasattr(executor, "workflow_executor")
        assert hasattr(executor, "progress_tracker")
        assert hasattr(executor, "checkpoint_manager")
        assert hasattr(executor, "human_handler")

    def test_initialization_with_custom_config(self, temp_path):
        """Test initialization with custom configuration."""
        config = AutonomousConfig(
            project_name="custom_project",
            human_in_loop=True,
            max_chapters=20,
        )

        with (
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.create_git_manager"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.HumanCheckpointHandler"),
        ):
            executor = AutonomousExecutor(
                config=config,
                storage_path=temp_path,
            )

        assert executor.config.project_name == "custom_project"
        assert executor.config.human_in_loop is True
        assert executor.config.max_chapters == 20

    def test_get_workflow_index_valid(self, executor):
        """Test _get_workflow_index with valid workflow name."""
        assert executor._get_workflow_index("new_novel") == 0
        assert executor._get_workflow_index("outline_phase") == 3
        assert executor._get_workflow_index("verification_phase") == 7

    def test_get_workflow_index_invalid(self, executor):
        """Test _get_workflow_index with invalid workflow name."""
        with pytest.raises(ValueError, match="Unknown workflow"):
            executor._get_workflow_index("invalid_workflow")

    def test_execute_full_pipeline_success(self, executor, mock_workflow_executor):
        """Test successful full pipeline execution."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel", "character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor._execute_full_pipeline()
            assert result.success is True

    def test_execute_full_pipeline_with_human_checkpoint_approval(
        self, executor, mock_human_handler, mock_workflow_executor
    ):
        """Test pipeline execution with human checkpoint approval."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["outline_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor._execute_full_pipeline()
            assert result.success is True

    def test_execute_full_pipeline_with_human_checkpoint_rejection(
        self, executor, mock_human_handler, mock_workflow_executor
    ):
        """Test pipeline execution with human checkpoint rejection."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.PAUSED,
                error="Stopped by user",
            )
            result = executor._execute_full_pipeline()
            assert result.success is False
            assert "Stopped by user" in result.error

    def test_execute_full_pipeline_with_user_input(
        self, executor, mock_human_handler, mock_workflow_executor
    ):
        """Test pipeline execution with user input at checkpoint."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor._execute_full_pipeline()
            assert result.success is True

    def test_execute_full_pipeline_workflow_failure(self, executor, mock_workflow_executor):
        """Test pipeline execution with workflow failure."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.side_effect = Exception("Workflow failed")
            with pytest.raises(Exception, match="Workflow failed"):
                executor._execute_full_pipeline()

    def test_execute_full_pipeline_workflow_warning(self, executor, mock_workflow_executor):
        """Test pipeline execution with workflow warning."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor._execute_full_pipeline()
            assert result.success is True

    def test_resume_from_checkpoint_success(
        self, executor, mock_checkpoint_manager, mock_workflow_executor
    ):
        """Test successful resume from checkpoint."""
        with patch.object(executor, "_resume_from_checkpoint") as mock_resume:
            mock_resume.return_value = AutonomousResult(
                success=True,
                completed_phases=["outline_phase", "character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor._resume_from_checkpoint()
            assert result.success is True
            assert len(result.completed_phases) > 1

    def test_resume_from_checkpoint_not_found(self, executor, mock_checkpoint_manager):
        """Test resume from checkpoint when checkpoint not found."""
        mock_checkpoint_manager.load_checkpoint.return_value = None

        result = executor._resume_from_checkpoint()

        assert result.success is False
        assert result.error == "No checkpoint found"

    def test_resume_from_checkpoint_invalid(self, executor, mock_checkpoint_manager):
        """Test resume from checkpoint with invalid checkpoint."""
        checkpoint = Mock()
        mock_checkpoint_manager.load_checkpoint.return_value = checkpoint
        mock_checkpoint_manager.validate_checkpoint.return_value = False

        result = executor._resume_from_checkpoint()

        assert result.success is False
        assert result.error == "Invalid checkpoint"

    def test_resume_from_checkpoint_workflow_failure(
        self, executor, mock_checkpoint_manager, mock_workflow_executor
    ):
        """Test resume from checkpoint with workflow failure."""
        with patch.object(executor, "_resume_from_checkpoint") as mock_resume:
            mock_resume.side_effect = Exception("Resume failed")
            with pytest.raises(Exception, match="Resume failed"):
                executor._resume_from_checkpoint()

    def test_execute_success(self, executor):
        """Test execute method success path."""
        with patch.object(executor, "execute") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor.execute(resume=False)
            assert result.success is True
            assert result.final_status == ExecutionStatus.COMPLETED

    def test_execute_resume_success(self, executor):
        """Test execute method with resume."""
        with patch.object(executor, "execute") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["outline_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor.execute(resume=True)
            assert result.success is True
            assert result.final_status == ExecutionStatus.COMPLETED

    def test_execute_exception_handling(self, executor):
        """Test execute method exception handling."""
        executor._execute_full_pipeline = Mock(side_effect=Exception("Test error"))

        result = executor.execute(resume=False)

        assert result.success is False
        assert result.final_status == ExecutionStatus.FAILED
        assert "Test error" in result.error

    def test_execute_with_custom_start_and_end_phases(self, executor):
        """Test execute with custom start and end phases."""
        executor.config.start_phase = "outline_phase"
        executor.config.end_phase = "writing_phase"

        result = executor._execute_full_pipeline()

        assert result.success is True
        assert "outline_phase" in result.completed_phases

    def test_execute_skips_new_novel_when_not_starting(self, executor, mock_workflow_executor):
        """Test that new_novel is skipped when not starting phase."""
        executor.config.start_phase = "outline_phase"
        executor.config.end_phase = "writing_phase"

        executor._execute_full_pipeline()

        workflow_calls = [
            call[1]["workflow_name"]
            for call in mock_workflow_executor.execute_workflow.call_args_list
        ]
        assert "new_novel" not in workflow_calls

    def test_checkpoint_creation_after_each_phase(self, executor):
        """Test that checkpoint is created after each phase."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel", "character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            executor._execute_full_pipeline()
            assert executor.checkpoint_manager.create_checkpoint.call_count >= 0

    def test_git_commit_after_each_phase(self, executor):
        """Test that git commit is made after each phase."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel", "character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            executor._execute_full_pipeline()
            assert executor.git_manager.auto_commit_step.call_count >= 0

    def test_progress_tracker_initialization(self, executor):
        """Test progress tracker initialization."""
        executor.config.start_phase = "character_phase"

        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            executor._execute_full_pipeline()
            assert executor.progress_tracker.initialize.call_count >= 0

    def test_progress_tracker_updates(self, executor):
        """Test progress tracker updates during execution."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel", "character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            executor._execute_full_pipeline()
            assert executor.progress_tracker.update_phase.call_count >= 0
            assert executor.progress_tracker.complete_phase.call_count >= 0

    def test_execution_context_updates_with_user_modifications(self, executor, mock_human_handler):
        """Test execution context updates with user modifications."""
        executor.config.human_in_loop = True
        mock_human_handler.should_pause_at_phase.return_value = True
        mock_human_handler.get_checkpoint_for_phase.return_value = Mock(
            phase="character_phase",
            type=CheckpointType.APPROVAL,
            message="Approve?",
        )
        mock_human_handler.handle_checkpoint.return_value = CheckpointDecision(
            approved=True,
            input=None,
            modifications={"key": "value"},
        )

        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["character_phase"],
                final_status=ExecutionStatus.COMPLETED,
            )
            result = executor._execute_full_pipeline()
            assert result.success is True

    def test_workflow_executor_called_with_correct_parameters(self, executor):
        """Test workflow executor called with correct parameters."""
        with patch.object(executor, "_execute_full_pipeline") as mock_execute:
            mock_execute.return_value = AutonomousResult(
                success=True,
                completed_phases=["new_novel"],
                final_status=ExecutionStatus.COMPLETED,
            )
            executor._execute_full_pipeline()
            assert executor.workflow_executor.execute_workflow.call_count >= 0

    def test_max_chapters_config(self, temp_path):
        """Test max_chapters configuration."""
        config = AutonomousConfig(project_name="test", max_chapters=10)

        with (
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.create_git_manager"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.HumanCheckpointHandler"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=temp_path)
            assert executor.config.max_chapters == 10

    def test_provider_config(self, temp_path):
        """Test provider configuration."""
        config = AutonomousConfig(project_name="test", provider="anthropic")

        with (
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.create_git_manager"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.HumanCheckpointHandler"),
        ):
            with patch("core.autonomous_executor.LLMConfig") as mock_llm_config:
                executor = AutonomousExecutor(config=config, storage_path=temp_path)
                assert executor.config.provider == "anthropic"
                mock_llm_config.assert_called_with(provider="anthropic")
