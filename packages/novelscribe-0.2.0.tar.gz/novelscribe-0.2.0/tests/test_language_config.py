"""Tests for language configuration and resolution."""

import os
from unittest.mock import patch

import pytest
import yaml

from core.language_config import (
    LanguageCode,
    LanguageConfig,
    LanguageResolver,
    get_current_language,
    is_supported_language,
)


class TestLanguageCode:
    """Test LanguageCode enum."""

    def test_language_code_values(self):
        """Test language code enum values."""
        assert LanguageCode.EN.value == "en"
        assert LanguageCode.ZH_CN.value == "zh-CN"
        assert LanguageCode.ZH_TW.value == "zh-TW"

    def test_language_code_string_conversion(self):
        """Test string conversion of language codes."""
        assert str(LanguageCode.EN) == "en"
        assert str(LanguageCode.ZH_CN) == "zh-CN"
        assert str(LanguageCode.ZH_TW) == "zh-TW"

    def test_language_code_from_string(self):
        """Test creating LanguageCode from string."""
        assert LanguageCode("en") == LanguageCode.EN
        assert LanguageCode("zh-CN") == LanguageCode.ZH_CN
        assert LanguageCode("zh-TW") == LanguageCode.ZH_TW

    def test_language_code_invalid(self):
        """Test invalid language code raises error."""
        with pytest.raises(ValueError):
            LanguageCode("fr")


class TestLanguageConfig:
    """Test LanguageConfig model."""

    def test_default_config(self):
        """Test default language configuration."""
        config = LanguageConfig()
        assert config.default_language == LanguageCode.EN
        assert config.current_language is None

    def test_effective_language_default(self):
        """Test effective language with default config."""
        config = LanguageConfig()
        assert config.get_effective_language() == LanguageCode.EN

    def test_effective_language_with_current(self):
        """Test effective language with current language set."""
        config = LanguageConfig(
            default_language=LanguageCode.EN,
            current_language=LanguageCode.ZH_CN,
        )
        assert config.get_effective_language() == LanguageCode.ZH_CN

    def test_custom_default_language(self):
        """Test custom default language."""
        config = LanguageConfig(default_language=LanguageCode.ZH_TW)
        assert config.default_language == LanguageCode.ZH_TW
        assert config.get_effective_language() == LanguageCode.ZH_TW


class TestLanguageResolver:
    """Test LanguageResolver class."""

    def test_explicit_language_priority(self, tmp_path):
        """Test explicit language has highest priority."""
        resolver = LanguageResolver(project_dir=tmp_path)

        result = resolver.resolve_language(explicit_language=LanguageCode.ZH_CN)
        assert result == LanguageCode.ZH_CN

    def test_project_language_reading(self, tmp_path):
        """Test reading language from META.yaml."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        resolver = LanguageResolver(project_dir=tmp_path)
        result = resolver.resolve_language()
        assert result == LanguageCode.ZH_CN

    def test_project_language_invalid(self, tmp_path):
        """Test invalid language in META.yaml falls back."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "invalid"}), encoding="utf-8")

        resolver = LanguageResolver(project_dir=tmp_path)
        result = resolver.resolve_language()
        assert result == LanguageCode.EN

    def test_user_config_language(self, tmp_path):
        """Test reading language from user config."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"default_language": "zh-TW"}), encoding="utf-8")

        resolver = LanguageResolver(config_path=config_path)
        result = resolver.resolve_language()
        assert result == LanguageCode.ZH_TW

    def test_environment_language(self):
        """Test reading language from environment variable."""
        with patch.dict(os.environ, {"SCRIBE_LANGUAGE": "zh-CN"}):
            resolver = LanguageResolver()
            result = resolver.resolve_language()
            assert result == LanguageCode.ZH_CN

    def test_environment_language_invalid(self):
        """Test invalid environment language falls back."""
        with patch.dict(os.environ, {"SCRIBE_LANGUAGE": "invalid"}):
            resolver = LanguageResolver()
            result = resolver.resolve_language()
            assert result == LanguageCode.EN

    @patch("novel_harness.core.language_config.os.environ.get")
    def test_system_locale_detection(self, mock_get_env):
        """Test system locale detection."""
        mock_get_env.return_value = "zh_CN.UTF-8"

        resolver = LanguageResolver()
        result = resolver.resolve_language()
        assert result == LanguageCode.ZH_CN

    @patch("novel_harness.core.language_config.os.environ.get")
    def test_system_locale_zh_tw(self, mock_get_env):
        """Test system locale detection for Traditional Chinese."""
        mock_get_env.return_value = "zh_TW.UTF-8"

        resolver = LanguageResolver()
        result = resolver.resolve_language()
        assert result == LanguageCode.ZH_TW

    @patch("novel_harness.core.language_config.os.environ.get")
    def test_system_locale_unsupported(self, mock_get_env):
        """Test unsupported system locale falls back to English."""
        mock_get_env.return_value = "fr_FR.UTF-8"

        resolver = LanguageResolver()
        result = resolver.resolve_language()
        assert result == LanguageCode.EN

    def test_priority_chain(self, tmp_path):
        """Test full priority chain."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        with patch.dict(os.environ, {"SCRIBE_LANGUAGE": "zh-TW"}):
            resolver = LanguageResolver(project_dir=tmp_path)

            result = resolver.resolve_language(explicit_language=LanguageCode.EN)
            assert result == LanguageCode.EN

    def test_get_config_creates_default(self, tmp_path):
        """Test get_config creates default if not exists."""
        resolver = LanguageResolver(config_path=tmp_path / "config.yaml")
        config = resolver.get_config()

        assert isinstance(config, LanguageConfig)
        assert config.default_language == LanguageCode.EN

    def test_save_and_load_config(self, tmp_path):
        """Test saving and loading config."""
        config_path = tmp_path / "config.yaml"
        resolver = LanguageResolver(config_path=config_path)

        config = LanguageConfig(default_language=LanguageCode.ZH_CN)
        resolver.save_config(config)

        assert config_path.exists()

        loaded_config = resolver.get_config()
        assert loaded_config.default_language == LanguageCode.ZH_CN

    def test_config_caching(self, tmp_path):
        """Test config is cached after first load."""
        resolver = LanguageResolver(config_path=tmp_path / "config.yaml")

        config1 = resolver.get_config()
        config2 = resolver.get_config()

        assert config1 is config2


class TestConvenienceFunctions:
    """Test convenience functions."""

    def test_get_current_language_default(self):
        """Test get_current_language returns default."""
        language = get_current_language()
        assert language == LanguageCode.EN

    def test_get_current_language_with_explicit(self):
        """Test get_current_language with explicit language."""
        language = get_current_language(explicit_language=LanguageCode.ZH_TW)
        assert language == LanguageCode.ZH_TW

    def test_is_supported_language(self):
        """Test is_supported_language function."""
        assert is_supported_language("en") is True
        assert is_supported_language("zh-CN") is True
        assert is_supported_language("zh-TW") is True
        assert is_supported_language("fr") is False
        assert is_supported_language("invalid") is False


class TestLanguageResolverIntegration:
    """Integration tests for language resolver."""

    def test_full_resolution_chain(self, tmp_path):
        """Test complete resolution chain with all sources."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"default_language": "zh-TW"}), encoding="utf-8")

        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        with patch.dict(os.environ, {"SCRIBE_LANGUAGE": "en"}):
            resolver = LanguageResolver(
                config_path=config_path,
                project_dir=tmp_path,
            )

            result = resolver.resolve_language()
            assert result == LanguageCode.ZH_CN

    def test_explicit_overrides_all(self, tmp_path):
        """Test explicit language overrides everything."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"default_language": "zh-TW"}), encoding="utf-8")

        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        resolver = LanguageResolver(
            config_path=config_path,
            project_dir=tmp_path,
        )

        result = resolver.resolve_language(explicit_language=LanguageCode.EN)
        assert result == LanguageCode.EN

    def test_fallback_to_english(self, tmp_path):
        """Test fallback to English when no source provides language."""
        resolver = LanguageResolver(
            config_path=tmp_path / "nonexistent.yaml",
            project_dir=tmp_path / "nonexistent",
        )

        with patch.dict(os.environ, {}, clear=True):
            with patch("locale.getdefaultlocale", return_value=(None, None)):
                result = resolver.resolve_language()
                assert result == LanguageCode.EN
