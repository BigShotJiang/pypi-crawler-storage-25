"""Comprehensive tests for benchmarking.py to increase coverage."""

import json
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from core.benchmarking import (
    BenchmarkHistory,
    BenchmarkingEngine,
    BenchmarkReport,
    BenchmarkResult,
    BenchmarkType,
    PerformanceMetrics,
)
from core.quality_metrics import QualityMetrics


def create_test_metrics(
    chapter_number: int = 1,
    version: int = 1,
    flesch_kincaid: float = 8.0,
    dialogue_ratio: float = 0.3,
    overall_quality_score: float = 0.8,
) -> QualityMetrics:
    """Helper function to create valid QualityMetrics for testing."""
    return QualityMetrics(
        chapter_number=chapter_number,
        version=version,
        word_count=1000,
        sentence_count=50,
        paragraph_count=10,
        avg_sentence_length=20.0,
        avg_paragraph_length=100.0,
        flesch_kincaid=flesch_kincaid,
        gunning_fog=9.0,
        smog_index=8.5,
        dialogue_ratio=dialogue_ratio,
        dialogue_line_count=15,
        speaker_clarity=0.8,
        scene_variation=0.7,
        action_frequency=0.6,
        character_consistency=0.8,
        plot_continuity=0.75,
        passive_voice_ratio=0.1,
        adverb_frequency=0.05,
        vocabulary_diversity=0.5,
        overall_quality_score=overall_quality_score,
    )


class TestBenchmarkResult:
    """Test BenchmarkResult class."""

    def test_benchmark_result_str_basic(self):
        """Test basic string representation."""
        result = BenchmarkResult(
            benchmark_type=BenchmarkType.PERFORMANCE,
            category="test_category",
            score=85.5,
        )
        output = str(result)
        assert "test_category: 85.50" in output

    def test_benchmark_result_str_with_percentile(self):
        """Test string representation with percentile."""
        result = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="quality_score",
            score=0.85,
            percentile=75.5,
        )
        output = str(result)
        assert "percentile: 75.5%" in output

    def test_benchmark_result_str_with_comparison(self):
        """Test string representation with comparison."""
        result = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="flesch_kincaid",
            score=7.5,
            comparison="within benchmark range",
        )
        output = str(result)
        assert "within benchmark range" in output

    def test_benchmark_result_str_full(self):
        """Test string representation with all fields."""
        result = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="dialogue_ratio",
            score=0.35,
            percentile=80.0,
            comparison="within benchmark range",
            metadata={"in_range": True, "score": 1.0},
        )
        output = str(result)
        assert "dialogue_ratio: 0.35" in output
        assert "percentile: 80.0%" in output
        assert "within benchmark range" in output


class TestBenchmarkReport:
    """Test BenchmarkReport class."""

    def test_performance_score_calculation(self):
        """Test overall performance score calculation."""
        report = BenchmarkReport(
            project_name="test_project",
            timestamp=datetime.now(),
            results=[
                BenchmarkResult(
                    benchmark_type=BenchmarkType.PERFORMANCE, category="wpm1", score=100
                ),
                BenchmarkResult(
                    benchmark_type=BenchmarkType.PERFORMANCE, category="wpm2", score=200
                ),
                BenchmarkResult(
                    benchmark_type=BenchmarkType.QUALITY, category="quality", score=0.8
                ),
            ],
        )
        assert report.performance_score == 150.0

    def test_performance_score_no_performance_results(self):
        """Test performance score with no performance results."""
        report = BenchmarkReport(
            project_name="test_project",
            timestamp=datetime.now(),
            results=[
                BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="quality", score=0.8)
            ],
        )
        assert report.performance_score == 0.0

    def test_quality_score_calculation(self):
        """Test overall quality score calculation."""
        report = BenchmarkReport(
            project_name="test_project",
            timestamp=datetime.now(),
            results=[
                BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="q1", score=0.7),
                BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="q2", score=0.9),
                BenchmarkResult(
                    benchmark_type=BenchmarkType.PERFORMANCE, category="wpm", score=100
                ),
            ],
        )
        assert report.quality_score == 0.8

    def test_quality_score_no_quality_results(self):
        """Test quality score with no quality results."""
        report = BenchmarkReport(
            project_name="test_project",
            timestamp=datetime.now(),
            results=[
                BenchmarkResult(benchmark_type=BenchmarkType.PERFORMANCE, category="wpm", score=100)
            ],
        )
        assert report.quality_score == 0.0

    def test_get_results_by_type(self):
        """Test filtering results by type."""
        report = BenchmarkReport(
            project_name="test_project",
            timestamp=datetime.now(),
            results=[
                BenchmarkResult(
                    benchmark_type=BenchmarkType.PERFORMANCE, category="wpm1", score=100
                ),
                BenchmarkResult(
                    benchmark_type=BenchmarkType.PERFORMANCE, category="wpm2", score=200
                ),
                BenchmarkResult(
                    benchmark_type=BenchmarkType.QUALITY, category="quality", score=0.8
                ),
            ],
        )
        perf_results = report.get_results_by_type(BenchmarkType.PERFORMANCE)
        assert len(perf_results) == 2
        assert all(r.benchmark_type == BenchmarkType.PERFORMANCE for r in perf_results)

    def test_get_results_by_category(self):
        """Test filtering results by category."""
        report = BenchmarkReport(
            project_name="test_project",
            timestamp=datetime.now(),
            results=[
                BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="flesch", score=7.5),
                BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="flesch", score=8.0),
                BenchmarkResult(
                    benchmark_type=BenchmarkType.QUALITY, category="dialogue", score=0.3
                ),
            ],
        )
        flesch_results = report.get_results_by_category("flesch")
        assert len(flesch_results) == 2
        assert all(r.category == "flesch" for r in flesch_results)


class TestBenchmarkHistory:
    """Test BenchmarkHistory class."""

    def test_add_metrics(self):
        """Test adding quality metrics to history."""
        history = BenchmarkHistory(project_name="test_project")
        metrics = create_test_metrics()
        history.add_metrics(metrics)
        assert len(history.entries) == 1
        assert history.entries[0] == metrics

    def test_add_performance(self):
        """Test adding performance metrics to history."""
        history = BenchmarkHistory(project_name="test_project")
        perf = PerformanceMetrics(
            generation_time_seconds=60.0,
            token_count=1000,
            word_count=500,
            words_per_minute=500.0,
            tokens_per_second=16.67,
        )
        history.add_performance(perf)
        assert len(history.performance_entries) == 1
        assert history.performance_entries[0] == perf

    def test_get_trend_insufficient_data(self):
        """Test get_trend with insufficient data."""
        history = BenchmarkHistory(project_name="test_project")
        slope, correlation = history.get_trend("overall_quality_score")
        assert slope == 0.0
        assert correlation == 0.0

    def test_get_trend_missing_attribute(self):
        """Test get_trend with missing attribute in entries."""
        history = BenchmarkHistory(project_name="test_project")
        metrics = create_test_metrics()
        history.add_metrics(metrics)
        slope, correlation = history.get_trend("nonexistent_metric")
        assert slope == 0.0
        assert correlation == 0.0

    def test_get_trend_success(self):
        """Test successful trend calculation."""
        history = BenchmarkHistory(project_name="test_project")
        for i in range(3):
            metrics = create_test_metrics(overall_quality_score=0.8 + i * 0.05)
            history.add_metrics(metrics)
        slope, correlation = history.get_trend("overall_quality_score")
        assert slope > 0
        assert 0 <= correlation <= 1.01


class TestBenchmarkingEngine:
    """Test BenchmarkingEngine class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = Path("/tmp/test_benchmarking")
        self.temp_dir.mkdir(exist_ok=True)

    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil

        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)

    def test_initialization_with_path(self):
        """Test engine initialization with path."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        assert engine.project_root == self.temp_dir
        assert engine.history == {}

    def test_initialization_with_string(self):
        """Test engine initialization with string path."""
        engine = BenchmarkingEngine(project_root=str(self.temp_dir))
        assert engine.project_root == self.temp_dir

    def test_load_history_file_not_exists(self):
        """Test loading history when file doesn't exist."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        assert engine.history == {}

    def test_load_history_invalid_json(self):
        """Test loading history with invalid JSON."""
        scribe_dir = self.temp_dir / ".scribe"
        scribe_dir.mkdir(exist_ok=True)
        history_file = scribe_dir / "benchmark_history.json"
        history_file.write_text("invalid json")

        engine = BenchmarkingEngine(project_root=self.temp_dir)
        assert engine.history == {}

    def test_save_history_write_error(self):
        """Test saving history with write error."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)

        with patch("builtins.open", side_effect=IOError("Permission denied")):
            engine._save_history()

    def test_benchmark_performance_basic(self):
        """Test basic performance benchmarking."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        result = engine.benchmark_performance(
            project_name="test_project", generation_time=60.0, token_count=1000, word_count=500
        )

        assert result.benchmark_type == BenchmarkType.PERFORMANCE
        assert result.category == "words_per_minute"
        assert abs(result.score - 500.0) < 0.001
        assert "test_project" in engine.history

    def test_benchmark_performance_zero_time(self):
        """Test performance benchmarking with zero generation time."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        result = engine.benchmark_performance(
            project_name="test_project", generation_time=0.0, token_count=1000, word_count=500
        )

        assert result.score == 0.0
        assert result.metadata["tokens_per_second"] == 0.0

    def test_benchmark_quality_basic(self):
        """Test basic quality benchmarking."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        metrics = create_test_metrics()

        results = engine.benchmark_quality(
            project_name="test_project", metrics=metrics, comparison_benchmark="published_novel"
        )

        assert len(results) > 0
        assert all(r.benchmark_type == BenchmarkType.QUALITY for r in results)

    def test_benchmark_quality_with_genre(self):
        """Test quality benchmarking with genre-specific benchmarks."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        metrics = create_test_metrics(flesch_kincaid=7.0, dialogue_ratio=0.4)

        results = engine.benchmark_quality(
            project_name="test_project",
            metrics=metrics,
            comparison_benchmark="published_novel",
            genre="fantasy",
        )

        assert len(results) > 0

    def test_generate_benchmark_report_no_history(self):
        """Test generating report with no history."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        report = engine.generate_benchmark_report("test_project")

        assert report.project_name == "test_project"
        assert len(report.results) == 0

    def test_generate_benchmark_report_with_history(self):
        """Test generating report with history."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        metrics = create_test_metrics()
        engine.benchmark_quality(project_name="test_project", metrics=metrics)

        report = engine.generate_benchmark_report("test_project")
        assert len(report.results) > 0

    def test_compare_versions(self):
        """Test comparing two versions of metrics."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        metrics1 = create_test_metrics(overall_quality_score=0.7)
        metrics2 = create_test_metrics(chapter_number=1, version=2, overall_quality_score=0.8)

        comparison = engine.compare_versions("test_project", metrics1, metrics2)

        assert "content_metrics" in comparison
        assert "readability_metrics" in comparison
        assert "dialogue_metrics" in comparison
        assert "style_metrics" in comparison
        assert "overall" in comparison
        assert comparison["overall"]["improved"] is True

    def test_track_progress_no_data(self):
        """Test track progress with no data."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        progress = engine.track_progress("test_project")

        assert progress["trend"] == "no_data"
        assert progress["current"] is None

    def test_track_progress_with_data(self):
        """Test track progress with data."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        for i in range(5):
            metrics = create_test_metrics(
                chapter_number=i + 1,
                flesch_kincaid=8.0 - i * 0.1,
                overall_quality_score=0.7 + i * 0.05,
            )
            engine.benchmark_quality(project_name="test_project", metrics=metrics)

        progress = engine.track_progress("test_project", "overall_quality_score")

        assert progress["trend"] == "improving"
        assert progress["current"] > progress["average"]
        assert progress["improvement"] > 0
        assert progress["total_entries"] == 5

    def test_track_progress_declining(self):
        """Test track progress with declining trend."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        for i in range(3):
            metrics = create_test_metrics(chapter_number=i + 1, overall_quality_score=0.9 - i * 0.1)
            engine.benchmark_quality(project_name="test_project", metrics=metrics)

        progress = engine.track_progress("test_project", "overall_quality_score")

        assert progress["trend"] == "declining"

    def test_calculate_percentile_empty(self):
        """Test percentile calculation with empty list."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        percentile = engine._calculate_percentile(100.0, [])
        assert percentile == 50.0

    def test_calculate_percentile_basic(self):
        """Test basic percentile calculation."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        values = [10.0, 20.0, 30.0, 40.0, 50.0]
        percentile = engine._calculate_percentile(35.0, values)
        assert 60 <= percentile <= 80

    def test_generate_comparison_below_min(self):
        """Test comparison generation for value below minimum."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        comparison = engine._generate_comparison(5.0, 7.0, 10.0)
        assert "below minimum benchmark" in comparison

    def test_generate_comparison_above_max(self):
        """Test comparison generation for value above maximum."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        comparison = engine._generate_comparison(12.0, 7.0, 10.0)
        assert "above maximum benchmark" in comparison

    def test_generate_comparison_in_range(self):
        """Test comparison generation for value in range."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        comparison = engine._generate_comparison(8.5, 7.0, 10.0)
        assert "within benchmark range" in comparison

    def test_determine_quality_gate_platinum(self):
        """Test quality gate determination for platinum."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        gate = engine._determine_quality_gate(0.95)
        assert gate == "platinum"

    def test_determine_quality_gate_gold(self):
        """Test quality gate determination for gold."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        gate = engine._determine_quality_gate(0.85)
        assert gate == "gold"

    def test_determine_quality_gate_silver(self):
        """Test quality gate determination for silver."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        gate = engine._determine_quality_gate(0.75)
        assert gate == "silver"

    def test_determine_quality_gate_bronze(self):
        """Test quality gate determination for bronze."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        gate = engine._determine_quality_gate(0.6)
        assert gate == "bronze"

    def test_export_benchmark_data_no_history(self):
        """Test exporting benchmark data with no history."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        with pytest.raises(ValueError, match="No benchmark history found"):
            engine.export_benchmark_data("test_project")

    def test_export_benchmark_data_success(self):
        """Test successful export of benchmark data."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        metrics = create_test_metrics()
        engine.benchmark_quality(project_name="test_project", metrics=metrics)

        output_path = engine.export_benchmark_data("test_project")
        assert output_path.exists()
        assert output_path.name == "test_project_benchmarks.json"

        with open(output_path) as f:
            data = json.load(f)
            assert data["project_name"] == "test_project"
            assert "quality_metrics" in data
            assert "summary" in data

    def test_get_statistics_no_history(self):
        """Test getting statistics with no history."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        stats = engine.get_statistics("test_project")
        assert "error" in stats

    def test_get_statistics_success(self):
        """Test successful statistics retrieval."""
        engine = BenchmarkingEngine(project_root=self.temp_dir)
        for i in range(5):
            metrics = create_test_metrics(
                chapter_number=i + 1, overall_quality_score=0.7 + i * 0.05
            )
            engine.benchmark_quality(project_name="test_project", metrics=metrics)

        stats = engine.get_statistics("test_project")

        assert stats["project_name"] == "test_project"
        assert "quality_metrics" in stats
        assert "performance_metrics" in stats
        assert stats["quality_metrics"]["total_entries"] == 5
        assert stats["quality_metrics"]["average_score"] is not None
        assert stats["quality_metrics"]["min_score"] is not None
        assert stats["quality_metrics"]["max_score"] is not None
