"""Performance tests for logs router under concurrent load conditions."""

import asyncio
import json
import time
from unittest.mock import MagicMock

import pytest

from api.models import LogLevel
from api.routers.logs import (
    LogStreamerConfig,
    generate_log_sse_stream,
    parse_log_entries,
    read_log_file,
)


class TestReadPerformance:
    """Performance tests for reading log files."""

    @pytest.mark.performance
    @pytest.mark.parametrize("num_entries", [100, 500, 1000])
    def test_read_performance_large_file(self, tmp_path, num_entries):
        """Test read performance with varying file sizes."""
        log_file = tmp_path / "execution.log"
        lines = [
            json.dumps(
                {
                    "level": "INFO",
                    "message": f"Log entry {i}",
                    "timestamp": "2024-01-15T10:00:00",
                    "execution_id": f"exec{i % 10}",
                }
            )
            + "\n"
            for i in range(num_entries)
        ]
        log_file.write_text("".join(lines))

        start_time = time.perf_counter()
        result = read_log_file(log_file)
        elapsed = time.perf_counter() - start_time

        assert len(result) == num_entries
        assert elapsed < 2.0

    def test_read_performance_repeated(self, tmp_path):
        """Test performance with repeated reads."""
        log_file = tmp_path / "execution.log"
        lines = [json.dumps({"level": "INFO", "message": f"Log {i}"}) + "\n" for i in range(100)]
        log_file.write_text("".join(lines))

        iterations = 100
        start_time = time.perf_counter()
        for _ in range(iterations):
            read_log_file(log_file)
        elapsed = time.perf_counter() - start_time

        assert elapsed < 5.0


class TestParsePerformance:
    """Performance tests for parsing log entries."""

    @pytest.mark.performance
    @pytest.mark.parametrize("num_entries", [100, 500, 1000])
    def test_parse_performance(self, num_entries):
        """Test parse performance with varying data sizes."""
        log_data = [
            {
                "level": "INFO",
                "message": f"Log entry {i}",
                "timestamp": "2024-01-15T10:00:00",
                "execution_id": f"exec{i % 10}",
            }
            for i in range(num_entries)
        ]

        start_time = time.perf_counter()
        result = parse_log_entries(log_data)
        elapsed = time.perf_counter() - start_time

        assert len(result) == num_entries
        assert elapsed < 0.5

    @pytest.mark.performance
    def test_parse_with_filters_performance(self):
        """Test parse performance with filters applied."""
        log_data = [
            {
                "level": level,
                "message": f"Log {i}",
                "execution_id": f"exec{i % 5}",
            }
            for i, level in enumerate(["INFO", "ERROR", "WARNING"] * 100)
        ]

        start_time = time.perf_counter()
        parse_log_entries(log_data, level=LogLevel.ERROR, execution_id="exec1")
        elapsed = time.perf_counter() - start_time

        assert elapsed < 0.1


class TestSSEStreamPerformance:
    """Performance tests for SSE streaming."""

    async def test_generator_memory_efficiency(self, tmp_path):
        """Test that generator doesn't accumulate memory."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        generator = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=50),
        )

        event_count = 0
        async for event in generator:
            event_count += 1
            if event_count >= 50:
                break

        assert event_count >= 50

    async def test_generator_cleanup_on_timeout(self, tmp_path):
        """Test generator cleanup after timeout."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        generator = generate_log_sse_stream(
            "test_project",
            storage_provider=storage_factory,
            config=LogStreamerConfig(poll_interval=0.01, max_iterations=10),
        )

        events = []
        async for event in generator:
            events.append(event)
            if len(events) >= 5:
                break

        generator.aclose()


class TestConcurrentStreaming:
    """Performance tests for concurrent streaming."""

    async def test_multiple_concurrent_streams(self, tmp_path):
        """Test performance with multiple concurrent streams."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_dir = project_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        async def storage_factory():
            return mock_storage

        async def run_stream(prefix: str):
            events = []
            async for event in generate_log_sse_stream(
                "test_project",
                storage_provider=storage_factory,
                config=LogStreamerConfig(poll_interval=0.001, max_iterations=10),
            ):
                events.append(event)
                if len(events) >= 10:
                    break
            return events

        num_streams = 5
        start_time = time.perf_counter()
        results = await asyncio.gather(*[run_stream(f"stream_{i}") for i in range(num_streams)])
        elapsed = time.perf_counter() - start_time

        assert len(results) == num_streams
        assert all(len(events) >= 1 for events in results)
        assert elapsed < 60.0


class TestPaginationPerformance:
    """Performance tests for pagination."""

    @pytest.mark.performance
    def test_pagination_performance(self):
        """Test pagination performance with large dataset."""
        log_data = [
            {
                "level": "INFO",
                "message": f"Log entry {i}",
                "execution_id": f"exec{i % 10}",
            }
            for i in range(10000)
        ]

        start_time = time.perf_counter()
        entries = parse_log_entries(log_data)

        page_size = 100
        for page in range(100):
            offset = page * page_size
            _ = entries[offset : offset + page_size]

        elapsed = time.perf_counter() - start_time

        assert elapsed < 1.0

    @pytest.mark.performance
    def test_large_offset_performance(self):
        """Test performance with large offsets."""
        log_data = [{"level": "INFO", "message": f"Log {i}"} for i in range(10000)]

        entries = parse_log_entries(log_data)

        start_time = time.perf_counter()
        result = entries[9900:10000]
        elapsed = time.perf_counter() - start_time

        assert len(result) == 100
        assert elapsed < 0.1


class TestFilterPerformance:
    """Performance tests for filtering operations."""

    @pytest.mark.performance
    @pytest.mark.parametrize(
        "num_entries,filter_type",
        [
            (100, "level"),
            (500, "level"),
            (1000, "level"),
            (100, "execution"),
            (500, "execution"),
            (1000, "execution"),
        ],
    )
    def test_filter_performance(self, num_entries, filter_type):
        """Test filter performance with various data sizes."""
        log_data = [
            {
                "level": ["INFO", "ERROR", "WARNING", "DEBUG"][i % 4],
                "message": f"Log {i}",
                "execution_id": f"exec{i % 20}",
            }
            for i in range(num_entries)
        ]

        start_time = time.perf_counter()
        if filter_type == "level":
            parse_log_entries(log_data, level=LogLevel.ERROR)
        else:
            parse_log_entries(log_data, execution_id="exec5")
        elapsed = time.perf_counter() - start_time

        assert elapsed < 0.5


class TestThroughputMetrics:
    """Throughput measurement tests."""

    @pytest.mark.performance
    def test_read_throughput(self, tmp_path):
        """Measure read throughput in entries per second."""
        num_entries = 1000
        log_file = tmp_path / "execution.log"
        lines = [
            json.dumps(
                {
                    "level": "INFO",
                    "message": f"Log entry {i}",
                }
            )
            + "\n"
            for i in range(num_entries)
        ]
        log_file.write_text("".join(lines))

        iterations = 10
        start_time = time.perf_counter()
        for _ in range(iterations):
            read_log_file(log_file)
        elapsed = time.perf_counter() - start_time

        throughput = (num_entries * iterations) / elapsed
        assert throughput > 500

    @pytest.mark.performance
    def test_parse_throughput(self):
        """Measure parse throughput in entries per second."""
        log_data = [{"level": "INFO", "message": f"Log {i}"} for i in range(10000)]

        iterations = 5
        start_time = time.perf_counter()
        for _ in range(iterations):
            parse_log_entries(log_data)
        elapsed = time.perf_counter() - start_time

        throughput = (10000 * iterations) / elapsed
        assert throughput > 10000


class TestLatencyMetrics:
    """Latency measurement tests."""

    @pytest.mark.performance
    def test_single_read_latency(self, tmp_path):
        """Measure latency of single file read."""
        log_file = tmp_path / "execution.log"
        lines = [json.dumps({"level": "INFO", "message": f"Log {i}"}) + "\n" for i in range(100)]
        log_file.write_text("".join(lines))

        latencies = []
        for _ in range(100):
            start = time.perf_counter()
            read_log_file(log_file)
            latencies.append(time.perf_counter() - start)

        avg_latency = sum(latencies) / len(latencies)
        p99_latency = sorted(latencies)[98]

        assert avg_latency < 0.01
        assert p99_latency < 0.05

    @pytest.mark.performance
    def test_single_parse_latency(self):
        """Measure latency of single parse operation."""
        log_data = [{"level": "INFO", "message": f"Log {i}"} for i in range(100)]

        latencies = []
        for _ in range(100):
            start = time.perf_counter()
            parse_log_entries(log_data)
            latencies.append(time.perf_counter() - start)

        avg_latency = sum(latencies) / len(latencies)

        assert avg_latency < 0.001
