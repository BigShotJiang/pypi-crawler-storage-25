"""
Advanced coverage tests for API routers with complex mocking.
Tests file I/O, orchestrator dependencies, and WebSocket/streaming scenarios.
"""

import json
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from starlette.websockets import WebSocketDisconnect


class TestLogsRouterAdvanced:
    """Advanced tests for logs router with file I/O."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient

        from api.app import app

        return TestClient(app)

    @pytest.fixture
    def mock_log_file(self, tmp_path):
        """Create a mock log file with sample entries."""
        log_dir = tmp_path / "test_project" / "logs"
        log_dir.mkdir(parents=True)
        log_file = log_dir / "execution.log"

        log_entries = [
            {
                "timestamp": "2024-01-01T10:00:00",
                "level": "INFO",
                "message": "Starting workflow",
                "source": "orchestrator",
                "execution_id": "exec_001",
                "chapter": None,
                "metadata": {},
            },
            {
                "timestamp": "2024-01-01T10:01:00",
                "level": "ERROR",
                "message": "Error in chapter 1",
                "source": "executor",
                "execution_id": "exec_001",
                "chapter": 1,
                "metadata": {"error": "timeout"},
            },
            {
                "timestamp": "2024-01-01T10:02:00",
                "level": "WARNING",
                "message": "Low tokens",
                "source": "monitor",
                "execution_id": "exec_002",
                "chapter": 2,
                "metadata": {"tokens": 100},
            },
        ]

        with open(log_file, "w") as f:
            for entry in log_entries:
                f.write(json.dumps(entry) + "\n")

        return log_file, tmp_path

    def test_get_project_logs_with_file_reading(self, client, mock_log_file):
        """Test reading actual log file."""
        log_file, tmp_path = mock_log_file

        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.project_dir = tmp_path
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project?limit=100")
            assert response.status_code == 200
            data = response.json()
            assert data["project"] == "test_project"
            assert data["total"] == 3
            assert len(data["logs"]) == 3

    def test_get_project_logs_with_level_filter(self, client, mock_log_file):
        """Test filtering logs by level."""
        log_file, tmp_path = mock_log_file

        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.project_dir = tmp_path
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project?level=ERROR")
            assert response.status_code == 200
            data = response.json()
            assert data["total"] == 1
            assert data["logs"][0]["level"] == "ERROR"

    def test_get_project_logs_with_invalid_json_lines(self, client, tmp_path):
        """Test handling invalid JSON in log file."""
        log_dir = tmp_path / "test_project" / "logs"
        log_dir.mkdir(parents=True)
        log_file = log_dir / "execution.log"

        with open(log_file, "w") as f:
            f.write('{"timestamp": "2024-01-01T10:00:00", "level": "INFO", "message": "Valid"}\n')
            f.write("invalid json line\n")
            f.write(
                '{"timestamp": "2024-01-01T10:01:00", "level": "ERROR", "message": "Also valid"}\n'
            )

        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.project_dir = tmp_path
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project")
            assert response.status_code == 200
            data = response.json()
            assert data["total"] == 2

    def test_get_execution_logs_filtering(self, client, mock_log_file):
        """Test filtering logs by execution ID."""
        log_file, tmp_path = mock_log_file

        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.project_dir = tmp_path
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project/exec_001")
            assert response.status_code in [200, 500]
            if response.status_code == 200:
                data = response.json()
                assert data["total"] == 2
                assert all(log["execution_id"] == "exec_001" for log in data["logs"])

    def test_get_execution_logs_not_found(self, client):
        """Test execution logs for nonexistent execution."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_instance.project_dir = MagicMock()
            mock_instance.project_dir.__truediv__ = MagicMock(
                return_value=MagicMock(exists=lambda: False)
            )
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project/nonexistent_exec")
            assert response.status_code == 200
            data = response.json()
            assert data["total"] == 0

    def test_get_project_logs_pagination(self, client, mock_log_file):
        """Test pagination of log entries."""
        log_file, tmp_path = mock_log_file

        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.project_dir = tmp_path
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project?offset=1&limit=1")
            assert response.status_code == 200
            data = response.json()
            assert data["total"] == 3
            assert len(data["logs"]) == 1
            assert data["offset"] == 1
            assert data["has_more"] is True


class TestSuggestionsRouterAdvanced:
    """Advanced tests for suggestions router with orchestrator mocking."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient

        from api.app import app

        return TestClient(app)

    def test_list_suggestions_all_categories(self, client):
        """Test listing suggestions across all categories."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_suggestion = MagicMock()
            mock_suggestion.id = "sug_001"
            mock_suggestion.name = "Test"
            mock_suggestion.description = "Test suggestion"
            mock_suggestion.best_for = []
            mock_suggestion.examples = []
            mock_suggestion.source.value = "static"
            mock_suggestion.acceptance_rate = 0.8
            mock_instance.load_suggestions.return_value = [mock_suggestion]
            mock_kb.return_value = mock_instance

            response = client.get("/api/v1/suggestions/")
            assert response.status_code == 200
            data = response.json()
            assert isinstance(data, list)

    def test_list_suggestions_invalid_category(self, client):
        """Test listing suggestions with invalid category."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_instance.load_suggestions.side_effect = ValueError("Invalid category")
            mock_kb.return_value = mock_instance

            response = client.get("/api/v1/suggestions/?category=invalid")
            assert response.status_code == 400

    def test_get_suggestion_success(self, client):
        """Test getting a specific suggestion."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_suggestion = MagicMock()
            mock_suggestion.id = "sug_001"
            mock_suggestion.name = "Test"
            mock_suggestion.description = "Test suggestion"
            mock_suggestion.best_for = ["test"]
            mock_suggestion.examples = ["example 1"]
            mock_suggestion.source.value = "static"
            mock_suggestion.acceptance_rate = 0.8
            mock_instance.get_suggestion.return_value = mock_suggestion
            mock_kb.return_value = mock_instance

            response = client.get("/api/v1/suggestions/sug_001")
            assert response.status_code == 200
            data = response.json()
            assert data["id"] == "sug_001"

    def test_record_suggestion_invalid_trigger(self, client):
        """Test recording with invalid trigger type."""
        response = client.post(
            "/api/v1/suggestions/record",
            json={
                "project_name": "p1",
                "suggestion_id": "sug_001",
                "accepted": True,
                "user_choice": "accepted",
                "trigger_type": "invalid_trigger",
                "category": "genre",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is False

    def test_record_suggestion_invalid_category(self, client):
        """Test recording with invalid category."""
        response = client.post(
            "/api/v1/suggestions/record",
            json={
                "project_name": "p1",
                "suggestion_id": "sug_001",
                "accepted": True,
                "user_choice": "accepted",
                "trigger_type": "decision_point",
                "category": "invalid_category",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is False

    def test_get_contextual_suggestions_with_category(self, client):
        """Test contextual suggestions with category filter."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orchestrator = MagicMock()
            from core.suggestions.models import (
                SuggestionResponse,
                TriggerType,
            )

            mock_response = SuggestionResponse(
                show_suggestions=True,
                trigger_type=TriggerType.DECISION_POINT,
                formatted_suggestions="Test suggestions",
                suggestions=[],
                presented_at=datetime.now(),
            )
            mock_orchestrator.get_suggestions.return_value = mock_response
            mock_orch.return_value = mock_orchestrator

            response = client.post(
                "/api/v1/suggestions/get?project_id=p1&trigger_type=decision_point&category=genre"
            )
            assert response.status_code == 200
            data = response.json()
            assert "show_suggestions" in data

    def test_get_analytics(self, client):
        """Test getting suggestion analytics."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orchestrator = MagicMock()
            mock_orchestrator.get_usage_analytics.return_value = {
                "total_suggestions": 100,
                "acceptance_rate": 0.75,
            }
            mock_orch.return_value = mock_orchestrator

            response = client.get("/api/v1/suggestions/analytics?days=7")
            assert response.status_code in [200, 404]
            if response.status_code == 200:
                data = response.json()
                assert "analytics" in data

    def test_promote_suggestion(self, client):
        """Test promoting a suggestion."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_tracker = MagicMock()
            mock_tracker.promote_to_learned.return_value = True
            mock_kb.return_value = mock_instance

            response = client.post(
                "/api/v1/suggestions/sug_001/promote?confirm=true",
            )
            assert response.status_code in [200, 404]
            if response.status_code == 200:
                data = response.json()
                assert "status" in data


class TestStreamingRouterAdvanced:
    """Advanced tests for streaming router with SSE generators."""

    @pytest.mark.asyncio
    async def test_generate_log_events_connected_event(self):
        """Test SSE generator sends connected event."""
        from api.routers.streaming import generate_log_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            tmp_path = MagicMock()
            tmp_path.mkdir = MagicMock()
            mock_instance.project_dir = tmp_path
            mock_storage.return_value = mock_instance

            events = []
            async for event in generate_log_events("test_project"):
                events.append(event)
                if len(events) >= 2:
                    break

            assert len(events) >= 1
            assert "event: connected" in events[0]

    @pytest.mark.asyncio
    async def test_generate_log_events_nonexistent_project(self):
        """Test SSE generator with nonexistent project."""
        from api.routers.streaming import generate_log_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance

            events = []
            async for event in generate_log_events("nonexistent"):
                events.append(event)
                break

            assert len(events) == 1
            assert "event: error" in events[0]

    @pytest.mark.asyncio
    async def test_generate_status_events_heartbeat(self):
        """Test status generator sends heartbeat."""
        from api.routers.streaming import generate_status_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            with patch("api.tasks.get_task_manager") as mock_tm:
                mock_manager = MagicMock()
                mock_manager.get_all_executions.return_value = []
                mock_tm.return_value = mock_manager

                events = []
                async for event in generate_status_events("test_project"):
                    events.append(event)
                    if len(events) >= 3:
                        break

                assert any("event: heartbeat" in e for e in events)

    @pytest.mark.asyncio
    async def test_generate_status_events_nonexistent_project(self):
        """Test status generator with nonexistent project."""
        from api.routers.streaming import generate_status_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance

            events = []
            async for event in generate_status_events("nonexistent"):
                events.append(event)
                break

            assert len(events) == 1
            assert "event: error" in events[0]


class TestWebSocketRouterAdvanced:
    """Advanced tests for WebSocket router."""

    @pytest.mark.asyncio
    async def test_websocket_global_handler(self):
        """Test global WebSocket handler logic."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.handle_client_message = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(
                side_effect=['{"type": "subscribe", "event_types": ["log"]}', WebSocketDisconnect()]
            )
            mock_ws.send = AsyncMock()

            from api.routers.websocket import websocket_global

            try:
                await websocket_global(mock_ws)
            except (Exception, WebSocketDisconnect):
                pass

            mock_manager.connect.assert_called_once()

    @pytest.mark.asyncio
    async def test_websocket_project_invalid_name(self):
        """Test project WebSocket with invalid project name."""
        from fastapi import WebSocket

        mock_ws = MagicMock(spec=WebSocket)
        mock_ws.close = AsyncMock()

        from api.routers.websocket import websocket_project

        await websocket_project(mock_ws, "proj/ect")

        mock_ws.close.assert_called_once_with(code=4000, reason="Invalid project name")

    @pytest.mark.asyncio
    async def test_websocket_project_handler(self):
        """Test project WebSocket handler logic."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.handle_client_message = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(
                side_effect=['{"type": "subscribe"}', WebSocketDisconnect()]
            )
            mock_ws.send = AsyncMock()

            from api.routers.websocket import websocket_project

            try:
                await websocket_project(mock_ws, "valid_project")
            except (Exception, WebSocketDisconnect):
                pass

            mock_manager.connect.assert_called_once()

    @pytest.mark.asyncio
    async def test_websocket_execution_invalid_name(self):
        """Test execution WebSocket with invalid project name."""
        from fastapi import WebSocket

        mock_ws = MagicMock(spec=WebSocket)
        mock_ws.close = AsyncMock()

        from api.routers.websocket import websocket_execution

        await websocket_execution(mock_ws, "proj/ect", "exec_123")

        mock_ws.close.assert_called_once_with(code=4000, reason="Invalid project name")

    @pytest.mark.asyncio
    async def test_websocket_execution_ping_message(self):
        """Test execution WebSocket ping handling."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.send_to_client = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(
                side_effect=[
                    '{"type": "ping"}',
                    WebSocketDisconnect(),
                ]
            )

            from api.routers.websocket import websocket_execution

            try:
                await websocket_execution(mock_ws, "valid_project", "exec_123")
            except (Exception, WebSocketDisconnect):
                pass

            assert mock_manager.send_to_client.call_count >= 2
