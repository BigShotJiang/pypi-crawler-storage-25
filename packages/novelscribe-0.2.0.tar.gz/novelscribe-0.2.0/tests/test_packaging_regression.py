"""
Regression tests for packaging and deployment issues.

This module contains tests to prevent recurrence of packaging issues:
- Entry point configuration
- Agent YAML validation
- Package structure
- CLI functionality
"""

import subprocess
import sys
from pathlib import Path

import pytest

from core.agent import Agent
from core.agent_loader import AgentLoader


class TestEntryPointConfiguration:
    """Tests for CLI entry point configuration."""

    def test_entry_point_format(self):
        """Test that entry point uses correct format (cli:main, not novel_harness.cli:main)."""
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()

        # Entry point should be "cli:main", not "novel_harness.cli:main"
        assert 'scribe = "cli:main"' in content, (
            "Entry point should be 'cli:main' not 'novel_harness.cli:main'"
        )

        # Should not contain incorrect format
        assert "novel_harness.cli:main" not in content, (
            "Entry point should not use 'novel_harness.cli:main' format"
        )

    def test_cli_main_function_exists(self):
        """Test that cli.main function is importable."""
        try:
            from cli import main

            assert callable(main), "cli.main should be callable"
        except ImportError as e:
            pytest.fail(f"Failed to import cli.main: {e}")


class TestAgentYAMLValidation:
    """Tests for agent YAML frontmatter validation."""

    def test_all_agents_have_valid_category(self):
        """Test that all agent files have valid category field."""
        agents_dir = Path(__file__).parent.parent / "agents" / "en"
        valid_categories = {"analytical", "creative", "validation"}

        for agent_file in agents_dir.glob("*.md"):
            frontmatter = self._extract_frontmatter(agent_file)

            if frontmatter:
                assert "category" in frontmatter, (
                    f"{agent_file.name}: Missing required 'category' field"
                )

                category = frontmatter["category"]
                assert category in valid_categories, (
                    f"{agent_file.name}: Invalid category '{category}'. "
                    f"Must be one of {valid_categories}"
                )

    def test_agents_use_simple_string_format(self):
        """Test that agents use simple strings, not dictionaries, for input/output/dependencies."""
        agents_dir = Path(__file__).parent.parent / "agents" / "en"

        for agent_file in agents_dir.glob("*.md"):
            frontmatter = self._extract_frontmatter(agent_file)

            if not frontmatter:
                continue

            # Check input field
            if "input" in frontmatter:
                for item in frontmatter.get("input", []):
                    assert isinstance(item, str), (
                        f"{agent_file.name}: input should be list of strings, "
                        f"not dicts. Got: {item}"
                    )
                    assert ":" not in item, (
                        f"{agent_file.name}: input should be simple strings, "
                        f"not 'KEY: description' format. Got: {item}"
                    )

            # Check output field
            if "output" in frontmatter:
                for item in frontmatter.get("output", []):
                    assert isinstance(item, str), (
                        f"{agent_file.name}: output should be list of strings, "
                        f"not dicts. Got: {item}"
                    )
                    assert ":" not in item, (
                        f"{agent_file.name}: output should be simple strings, "
                        f"not 'KEY: description' format. Got: {item}"
                    )

            # Check dependencies field
            if "dependencies" in frontmatter:
                for item in frontmatter.get("dependencies", []):
                    assert isinstance(item, str), (
                        f"{agent_file.name}: dependencies should be list of strings, "
                        f"not dicts. Got: {item}"
                    )
                    assert ":" not in item, (
                        f"{agent_file.name}: dependencies should be simple strings, "
                        f"not 'KEY: description' format. Got: {item}"
                    )

    def test_all_agents_load_without_validation_errors(self):
        """Test that all agent files can be loaded without Pydantic validation errors."""
        agents_dir = Path(__file__).parent.parent / "agents"
        loader = AgentLoader(str(agents_dir))

        agents = loader.load_all_agents()

        # Should load at least 13 agents
        assert len(agents) >= 12, f"Expected at least 13 agents to load, but got {len(agents)}"

        # All agents should be valid Agent instances
        for agent in agents:
            assert isinstance(agent, Agent), f"Agent should be an Agent instance, got {type(agent)}"
            assert agent.name, "Agent should have a name"

    def _extract_frontmatter(self, file_path: Path) -> dict:
        """Extract YAML frontmatter from a markdown file."""
        content = file_path.read_text()

        # Check if file starts with ---
        if not content.startswith("---"):
            return {}

        # Find the end of frontmatter
        end_idx = content.find("---", 3)
        if end_idx == -1:
            return {}

        frontmatter_text = content[3:end_idx].strip()

        # Parse YAML
        try:
            import yaml

            return yaml.safe_load(frontmatter_text) or {}
        except yaml.YAMLError:
            return {}


class TestPackageStructure:
    """Tests for package structure and build configuration."""

    def test_agents_package_has_init(self):
        """Test that agents directory has __init__.py file."""
        agents_dir = Path(__file__).parent.parent / "agents"
        init_file = agents_dir / "__init__.py"

        assert init_file.exists(), (
            "agents/__init__.py must exist for agents to be included in package"
        )

    def test_workflows_package_has_init(self):
        """Test that workflows directory has __init__.py file."""
        workflows_dir = Path(__file__).parent.parent / "workflows"
        init_file = workflows_dir / "__init__.py"

        assert init_file.exists(), (
            "workflows/__init__.py must exist for workflows to be included in package"
        )

    def test_pyproject_includes_agents_and_workflows(self):
        """Test that pyproject.toml includes agents and workflows as packages."""
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()

        # Extract packages list from pyproject.toml
        assert 'packages = [' in content, "pyproject.toml must have a packages list"

        # Check that required packages are included (order doesn't matter)
        required_packages = ['"api"', '"agents"', '"workflows"', '"core"']
        for package in required_packages:
            assert package in content, f"pyproject.toml must include {package} in packages list"

    def test_pyproject_includes_py_modules(self):
        """Test that pyproject.toml includes all CLI modules as py-modules."""
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()

        required_modules = [
            '"cli"',
            '"cli_agents"',
            '"cli_autonomous"',
            '"cli_drafts"',
            '"cli_memory"',
            '"cli_pagination"',
            '"cli_parallel"',
            '"cli_performance"',
            '"cli_qa"',
            '"cli_run"',
            '"cli_summary"',
            '"cli_verify"',
            '"cli_version"',
            '"cli_workflows"',
        ]

        for module in required_modules:
            assert module in content, f"pyproject.toml must include {module} in py-modules"

    def test_package_data_includes_markdown_and_yaml(self):
        """Test that pyproject.toml includes .md and .yaml files."""
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        content = pyproject_path.read_text()

        # Should include package data configuration
        assert "include-package-data = true" in content, (
            "pyproject.toml must set include-package-data = true"
        )

        # Should include agents/*.md and workflows/*.yaml
        assert 'agents = ["*.md"]' in content or '"*.md"' in content, (
            "pyproject.toml must include .md files from agents directory"
        )
        assert 'workflows = ["*.yaml"]' in content or '"*.yaml"' in content, (
            "pyproject.toml must include .yaml files from workflows directory"
        )


class TestCLIAgentListing:
    """Tests for CLI agent listing functionality."""

    def test_agents_list_command_succeeds(self):
        """Test that 'scribe agents list' command succeeds."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agents", "list"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Command should succeed
        assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"

        # Output should contain agent categories
        output = result.stdout
        assert "Analytical Agents" in output or "Available Agents" in output, (
            "Output should list agent categories"
        )

    def test_agents_list_shows_all_12_agents(self):
        """Test that agent listing shows all 14 agents."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        loader = AgentLoader(str(agents_dir))

        agents = loader.load_all_agents()

        # Should have exactly 14 agents
        assert len(agents) == 14, f"Expected 14 agents, but found {len(agents)}"

        # Verify expected agents are present
        expected_agents = {
            "chapter_planner_agent",
            "character_agent",
            "continuity_agent",
            "discuss_agent",
            "editor_agent",
            "genre_agent",
            "humanizer_agent",
            "outline_agent",
            "summary_agent",
            "system",
            "test_agent",
            "world_agent",
            "template_agent",
            "writer_agent",
        }

        actual_agents = {agent.name for agent in agents}
        assert actual_agents == expected_agents, (
            f"Agent mismatch. Expected: {expected_agents}, Got: {actual_agents}"
        )

    def test_agents_list_shows_meaningful_info(self):
        """Test that agent listing provides meaningful information."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        loader = AgentLoader(str(agents_dir))

        agents = loader.load_all_agents()

        for agent in agents:
            # Each agent should have a name
            assert agent.name, "Agent should have a name"

            # Each agent should have a description
            assert agent.description, f"Agent '{agent.name}' should have a description"

            # Each agent should have a category
            assert agent.category, f"Agent '{agent.name}' should have a category"

            # Each agent should have input schema (even if empty)
            assert agent.input_schema is not None, f"Agent '{agent.name}' should have input_schema"

            # Each agent should have output schema (even if empty)
            assert agent.output_schema is not None, (
                f"Agent '{agent.name}' should have output_schema"
            )


class TestCLIOutputValidation:
    """Tests for CLI output quality and meaningfulness."""

    def test_agents_list_output_is_readable(self):
        """Test that agents list output is human-readable."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agents", "list"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        output = result.stdout

        # Output should not contain error messages
        assert "Error" not in output, "Output should not contain error messages"
        assert "Warning" not in output or "Failed to load" not in output, (
            "Output should not contain agent loading warnings"
        )

        # Output should be structured
        assert output.strip(), "Output should not be empty"

        # Should have meaningful grouping (Analytical, Creative, Validation)
        categories_found = 0
        if "Analytical" in output:
            categories_found += 1
        if "Creative" in output:
            categories_found += 1
        if "Validation" in output:
            categories_found += 1

        assert categories_found >= 2, (
            "Output should show at least 2 agent categories for better organization"
        )

    def test_agents_show_output_is_detailed(self):
        """Test that agents show command provides detailed information."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        loader = AgentLoader(str(agents_dir))

        agents = loader.load_all_agents()

        # Test a specific agent
        test_agent = next((a for a in agents if a.name == "writer_agent"), None)
        assert test_agent is not None, "writer_agent should exist"

        # Agent should have comprehensive metadata
        assert len(test_agent.description) > 20, (
            "Agent description should be meaningful (>20 chars)"
        )

        if test_agent.input_schema:
            assert len(test_agent.input_schema) > 0, "Agent should have defined inputs"

        if test_agent.output_schema:
            assert len(test_agent.output_schema) > 0, "Agent should have defined outputs"

    def test_cli_help_is_meaningful(self):
        """Test that CLI help provides meaningful information."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "--help"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        output = result.stdout

        # Help should show available commands
        assert "agents" in output, "Help should mention 'agents' command"

        # Help should show verbosity option
        assert "-v" in output or "--verbose" in output, "Help should document verbosity option"

        # Help should be readable (not too verbose, not too sparse)
        assert len(output) > 100 and len(output) < 5000, (
            "Help output should be concise but informative"
        )


class TestDeployMakefileTarget:
    """Tests for Makefile deploy target."""

    def test_makefile_has_deploy_target(self):
        """Test that Makefile has a deploy target."""
        makefile_path = Path(__file__).parent.parent / "../Makefile"

        if not makefile_path.exists():
            pytest.skip("Makefile not found")

        content = makefile_path.read_text()

        # Should have deploy target
        assert "^deploy:" in content or "deploy:" in content, (
            "Makefile should have a 'deploy' target"
        )

    def test_deploy_uses_pipx(self):
        """Test that deploy target uses pipx for installation."""
        makefile_path = Path(__file__).parent.parent / "../Makefile"

        if not makefile_path.exists():
            pytest.skip("Makefile not found")

        content = makefile_path.read_text()

        # Should use pipx install
        assert "pipx install" in content, (
            "Deploy target should use 'pipx install' for proper CLI tool installation"
        )

        # Should use --force flag
        assert "--force" in content, "Deploy target should use --force flag for pipx install"

    def test_deploy_checks_for_existing_build(self):
        """Test that deploy target checks for existing wheel before building."""
        makefile_path = Path(__file__).parent.parent / "../Makefile"

        if not makefile_path.exists():
            pytest.skip("Makefile not found")

        content = makefile_path.read_text()

        # Should check for wheel file
        assert "dist/*.whl" in content, "Deploy target should reference dist/*.whl files"

        # Should have build dependency
        assert "build:" in content or "build" in content, (
            "Deploy target should depend on or call build target"
        )


class TestCLIErrorHandling:
    """Tests for CLI error handling and user-friendly output."""

    def test_cli_has_custom_error_handler(self):
        """Test that CLI uses custom error handler (ScribeCLI class)."""
        cli_path = Path(__file__).parent.parent / "cli.py"
        content = cli_path.read_text()

        # Should have ScribeCLI class
        assert "class ScribeCLI(click.Group):" in content, (
            "CLI should define ScribeCLI class for custom error handling"
        )

        # Should use get_close_matches for suggestions
        assert "get_close_matches" in content, (
            "CLI should use get_close_matches for command suggestions"
        )

        # Should use cls=ScribeCLI in decorator
        assert "cls=ScribeCLI" in content, "CLI should use cls=ScribeCLI in @click.group decorator"

    def test_cli_main_has_error_handling(self):
        """Test that main() has comprehensive error handling."""
        cli_path = Path(__file__).parent.parent / "cli.py"
        content = cli_path.read_text()

        # Should have try/except in main()
        assert "try:" in content and "except click.exceptions.UsageError" in content, (
            "main() should handle Click exceptions"
        )

        # Should handle KeyboardInterrupt
        assert "except KeyboardInterrupt" in content, "main() should handle Ctrl+C gracefully"

        # Should handle generic exceptions
        assert "except Exception" in content, "main() should handle unexpected errors"

    def test_cli_error_messages_are_user_friendly(self):
        """Test that CLI error messages are user-friendly (no tracebacks)."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agent", "list"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Should fail (typo: agent instead of agents)
        assert result.returncode != 0, "Command should fail due to typo"

        # Should NOT show traceback
        assert "Traceback" not in result.stdout, "Error output should not contain Python traceback"
        assert "Traceback" not in result.stderr, (
            "Error output should not contain Python traceback in stderr"
        )

        # Should show helpful error message
        output = result.stdout + result.stderr
        assert "Usage Error" in output or "No such command" in output, (
            "Error message should be user-friendly"
        )

        # Should suggest correct command
        assert "agents" in output, "Error should suggest the correct command 'agents'"

    def test_cli_suggests_similar_commands(self):
        """Test that CLI suggests similar commands for typos."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agent"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        output = result.stdout + result.stderr

        # Should suggest "agents" for typo "agent"
        assert "agents" in output, "Should suggest 'agents' when user types 'agent'"

        # Should show "Did you mean" message
        assert "Did you mean" in output or "• agents" in output, "Should show command suggestions"

    def test_cli_handles_missing_command_gracefully(self):
        """Test that CLI handles missing command gracefully."""
        result = subprocess.run(
            [sys.executable, "-m", "cli"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Should show help, not crash
        assert "Commands:" in result.stdout or "Commands:" in result.stderr, (
            "Should show available commands when called without arguments"
        )

        # Should NOT show traceback
        assert "Traceback" not in result.stdout, "Should not show traceback for missing command"
        assert "Traceback" not in result.stderr, "Should not show traceback in stderr"
