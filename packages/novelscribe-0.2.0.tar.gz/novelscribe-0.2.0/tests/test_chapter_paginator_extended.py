"""
Comprehensive tests for chapter_paginator.py to increase coverage to 90%+.
Tests chapter pagination and page splitting strategies.
"""

from novel_harness.core.chapter_paginator import (
    ChapterPage,
    ChapterPaginator,
    PageMetadata,
    PageSplitStrategy,
    PaginationConfig,
)


class TestPageMetadata:
    """Test PageMetadata dataclass."""

    def test_to_dict(self):
        """Test converting to dictionary."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )

        result = metadata.to_dict()

        assert result["page_number"] == 1
        assert result["word_count"] == 50
        assert "created_at" in result


class TestChapterPage:
    """Test ChapterPage dataclass."""

    def test_word_count_property(self):
        """Test word count property."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="Hello world this is a test",
            metadata=metadata,
        )

        assert page.word_count == 6

    def test_full_content_with_overlap(self):
        """Test full content with overlap."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="New content",
            metadata=metadata,
            overlap_content="Previous content",
        )

        assert "Previous content" in page.full_content
        assert "New content" in page.full_content

    def test_full_content_without_overlap(self):
        """Test full content without overlap."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="Content only",
            metadata=metadata,
        )

        assert page.full_content == "Content only"

    def test_get_context_hint_with_all(self):
        """Test context hint with all metadata."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
            scene_identifier="Scene 1",
            characters_present=["Alice", "Bob"],
            locations_present=["Castle"],
        )
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )

        hint = page.get_context_hint()
        assert "Scene 1" in hint
        assert "Alice" in hint
        assert "Castle" in hint

    def test_get_context_hint_minimal(self):
        """Test context hint with minimal metadata."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )

        hint = page.get_context_hint()
        assert hint == "Continuing story..."


class TestPaginationConfig:
    """Test PaginationConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = PaginationConfig()

        assert config.strategy == PageSplitStrategy.SEMANTIC
        assert config.max_tokens_per_page == 2500

    def test_custom_config(self):
        """Test custom configuration."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.TOKEN_BASED,
            max_tokens_per_page=3000,
        )

        assert config.strategy == PageSplitStrategy.TOKEN_BASED
        assert config.max_tokens_per_page == 3000


class TestChapterPaginator:
    """Test ChapterPaginator class."""

    def test_init_with_defaults(self):
        """Test initialization with defaults."""
        paginator = ChapterPaginator()

        assert paginator.config.strategy == PageSplitStrategy.SEMANTIC
        assert paginator.config.max_tokens_per_page == 2500

    def test_init_with_config(self):
        """Test initialization with custom config."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            max_tokens_per_page=2000,
        )
        paginator = ChapterPaginator(config=config)

        assert paginator.config.strategy == PageSplitStrategy.PARAGRAPH_BASED

    def test_paginate_short_chapter(self):
        """Test paginating a short chapter."""
        paginator = ChapterPaginator()
        short_chapter = "This is a short chapter."

        pages = paginator.paginate_chapter(short_chapter, chapter_number=1)

        assert len(pages) >= 1
        assert pages[0].page_number == 1

    def test_paginate_with_metadata(self):
        """Test paginating with custom metadata."""
        paginator = ChapterPaginator()
        chapter = "Word " * 100

        pages = paginator.paginate_chapter(chapter, chapter_number=5)

        assert len(pages) > 0
        assert pages[0].metadata.page_number == 1

    def test_paginate_with_options(self):
        """Test paginating with custom options."""
        config = PaginationConfig(strategy=PageSplitStrategy.PARAGRAPH_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Paragraph 1\n\nParagraph 2\n\nParagraph 3"

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0


class TestPaginationStrategies:
    """Test different pagination strategies."""

    def test_paragraph_based_strategy(self):
        """Test paragraph-based pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.PARAGRAPH_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Para 1\n\nPara 2\n\nPara 3\n\nPara 4\n\nPara 5"

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0

    def test_scene_based_strategy(self):
        """Test scene-based pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Scene 1: Intro\n\nScene 2: Rising\n\nScene 3: Climax"

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0

    def test_semantic_strategy(self):
        """Test semantic pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.SEMANTIC)
        paginator = ChapterPaginator(config=config)
        chapter = "Word " * 1000

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0

    def test_token_based_strategy(self):
        """Test token-based pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.TOKEN_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Word " * 2000

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0


class TestEdgeCases:
    """Test edge cases."""

    def test_paginate_single_word(self):
        """Test paginating single word."""
        paginator = ChapterPaginator()

        pages = paginator.paginate_chapter("Hello", chapter_number=1)

        assert len(pages) >= 1

    def test_paginate_chapter_number(self):
        """Test that chapter number is set correctly."""
        paginator = ChapterPaginator()
        chapter = "Word " * 100

        pages = paginator.paginate_chapter(chapter, chapter_number=42)

        assert all(p.metadata.page_number == 1 for p in pages)
