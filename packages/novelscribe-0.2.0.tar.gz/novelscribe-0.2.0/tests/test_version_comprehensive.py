"""Comprehensive tests for version management coverage improvement."""

from unittest.mock import Mock, patch

from core.version import (
    VersionManager,
    check_updates,
    get_version,
    notify_if_update_available,
)


class TestVersionManager:
    """Test VersionManager class."""

    def test_initialization(self):
        """Test VersionManager initialization."""
        manager = VersionManager()
        assert manager.package_name == "novel-harness"
        assert manager.pypi_url == "https://pypi.org/pypi/novel-harness/json"
        assert isinstance(manager.current_version, str)

    def test_get_current_version(self):
        """Test getting current version."""
        manager = VersionManager()
        version = manager._get_current_version()
        assert isinstance(version, str)
        assert len(version) > 0

    def test_get_version_info(self):
        """Test getting version info."""
        manager = VersionManager()
        info = manager.get_version_info()
        assert "current" in info
        assert "package" in info
        assert info["package"] == "novel-harness"
        assert isinstance(info["current"], str)

    @patch("requests.get")
    def test_check_for_updates_no_update_available(self, mock_get):
        """Test checking for updates when current is latest."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "0.0.1"},
            "releases": {"0.0.1": [{"upload_time": "2024-01-01T00:00:00"}]},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        manager.current_version = "0.0.1"

        result = manager.check_for_updates()
        assert result is not None
        assert result["update_available"] is False
        assert result["latest"] == "0.0.1"

    @patch("requests.get")
    def test_check_for_updates_update_available(self, mock_get):
        """Test checking for updates when update is available."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "99.99.99", "summary": "New release"},
            "releases": {"99.99.99": [{"upload_time": "2024-01-01T00:00:00"}]},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        manager.current_version = "1.0.0"

        result = manager.check_for_updates()
        assert result is not None
        assert result["update_available"] is True
        assert result["latest"] == "99.99.99"
        assert "upgrade_command" in result

    @patch("requests.get")
    def test_check_for_updates_request_exception(self, mock_get):
        """Test checking for updates with network error."""
        mock_get.side_effect = Exception("Network error")

        manager = VersionManager()
        result = manager.check_for_updates(verbose=True)
        assert result is None

    @patch("requests.get")
    def test_check_for_updates_verbose(self, mock_get):
        """Test checking for updates with verbose output."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "1.0.0"},
            "releases": {},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        manager.current_version = "1.0.0"

        result = manager.check_for_updates(verbose=True)
        assert result is not None

    def test_is_newer_version_true(self):
        """Test version comparison when latest is newer."""
        manager = VersionManager()
        manager.current_version = "1.0.0"
        assert manager._is_newer_version("2.0.0") is True

    def test_is_newer_version_false(self):
        """Test version comparison when latest is older."""
        manager = VersionManager()
        manager.current_version = "2.0.0"
        assert manager._is_newer_version("1.0.0") is False

    def test_is_newer_version_equal(self):
        """Test version comparison when versions are equal."""
        manager = VersionManager()
        manager.current_version = "1.0.0"
        assert manager._is_newer_version("1.0.0") is False

    def test_is_newer_version_invalid_format(self):
        """Test version comparison with invalid format."""
        manager = VersionManager()
        manager.current_version = "1.0.0"
        assert manager._is_newer_version("invalid") is False

    @patch("requests.get")
    def test_get_release_notes_with_summary(self, mock_get):
        """Test getting release notes with summary."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {
                "summary": "Test summary",
                "description": "Test description",
            },
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        notes = manager._get_release_notes(mock_response.json(), "1.0.0")
        assert notes == "Test summary"

    @patch("requests.get")
    def test_get_release_notes_with_description(self, mock_get):
        """Test getting release notes with description fallback."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {
                "description": "Test description",
            },
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        notes = manager._get_release_notes(mock_response.json(), "1.0.0")
        assert notes == "Test description"[:500]

    def test_get_upgrade_command_default(self):
        """Test getting default upgrade command."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=False):
            with patch.object(manager, "_installed_with_pip", return_value=False):
                with patch.object(manager, "_installed_with_uv", return_value=False):
                    command = manager._get_upgrade_command()
                    assert "pip install" in command

    def test_get_upgrade_command_pipx(self):
        """Test getting pipx upgrade command."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=True):
            command = manager._get_upgrade_command()
            assert "pipx upgrade" in command

    def test_get_upgrade_command_pip(self):
        """Test getting pip upgrade command."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=False):
            with patch.object(manager, "_installed_with_pip", return_value=True):
                with patch.object(manager, "_installed_with_uv", return_value=False):
                    command = manager._get_upgrade_command()
                    assert "pip install" in command

    def test_get_upgrade_command_uv(self):
        """Test getting uv upgrade command."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=False):
            with patch.object(manager, "_installed_with_pip", return_value=False):
                with patch.object(manager, "_installed_with_uv", return_value=True):
                    command = manager._get_upgrade_command()
                    assert "uv pip install" in command

    @patch("subprocess.run")
    def test_installed_with_pipx_true(self, mock_run):
        """Test checking if installed with pipx - true case."""
        mock_run.return_value = Mock(stdout="novel-harness\n")

        manager = VersionManager()
        result = manager._installed_with_pipx()
        assert result is True

    @patch("subprocess.run")
    def test_installed_with_pipx_false(self, mock_run):
        """Test checking if installed with pipx - false case."""
        mock_run.return_value = Mock(stdout="other-package\n")

        manager = VersionManager()
        result = manager._installed_with_pipx()
        assert result is False

    @patch("subprocess.run")
    def test_installed_with_pipx_exception(self, mock_run):
        """Test checking if installed with pipx - exception case."""
        mock_run.side_effect = Exception("Command not found")

        manager = VersionManager()
        result = manager._installed_with_pipx()
        assert result is False

    @patch("subprocess.run")
    def test_installed_with_pip_true(self, mock_run):
        """Test checking if installed with pip - true case."""
        mock_run.return_value = Mock(returncode=0)

        manager = VersionManager()
        result = manager._installed_with_pip()
        assert result is True

    @patch("subprocess.run")
    def test_installed_with_pip_false(self, mock_run):
        """Test checking if installed with pip - false case."""
        mock_run.return_value = Mock(returncode=1)

        manager = VersionManager()
        result = manager._installed_with_pip()
        assert result is False

    @patch("subprocess.run")
    def test_installed_with_uv_true(self, mock_run):
        """Test checking if installed with uv - true case."""
        mock_run.return_value = Mock(returncode=0)

        manager = VersionManager()
        result = manager._installed_with_uv()
        assert result is True

    @patch("subprocess.run")
    def test_installed_with_uv_false(self, mock_run):
        """Test checking if installed with uv - false case."""
        mock_run.return_value = Mock(returncode=1)

        manager = VersionManager()
        result = manager._installed_with_uv()
        assert result is False

    @patch("builtins.print")
    @patch.object(VersionManager, "check_for_updates")
    def test_display_update_notification_update_available(self, mock_check, mock_print):
        """Test display update notification with update available."""
        mock_check.return_value = {
            "current": "1.0.0",
            "latest": "2.0.0",
            "update_available": True,
            "release_notes": "New features",
            "upgrade_command": "pip install --upgrade",
        }

        manager = VersionManager()
        manager.display_update_notification()

    @patch("builtins.print")
    @patch.object(VersionManager, "check_for_updates")
    def test_display_update_notification_no_update(self, mock_check, mock_print):
        """Test display update notification with no update."""
        mock_check.return_value = {
            "current": "1.0.0",
            "latest": "1.0.0",
            "update_available": False,
        }

        manager = VersionManager()
        manager.display_update_notification()


class TestModuleFunctions:
    """Test module-level functions."""

    def test_get_version(self):
        """Test get_version function."""
        version = get_version()
        assert isinstance(version, str)
        assert len(version) > 0

    @patch.object(VersionManager, "check_for_updates")
    def test_check_updates(self, mock_check):
        """Test check_updates function."""
        mock_check.return_value = {"update_available": False}
        result = check_updates()
        assert result is not None

    @patch.object(VersionManager, "display_update_notification")
    def test_notify_if_update_available(self, mock_notify):
        """Test notify_if_update_available function."""
        notify_if_update_available()
        mock_notify.assert_called_once()
