from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from intent_hub_cli.client import IntentHubClient
from intent_hub_cli.skill_collector import collect_skills


def get_config_path() -> Path:
    return Path.home() / ".intent-hub" / "config.json"


def load_config() -> dict:
    path = get_config_path()
    if not path.exists():
        raise ValueError("Not logged in. Run intent-hub login --endpoint ... --code ... first.")
    return json.loads(path.read_text(encoding="utf-8"))


def save_config(endpoint: str, access_code: str) -> None:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"endpoint": endpoint, "access_code": access_code}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if os.name != "nt":
        path.chmod(0o600)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="intent-hub")
    subparsers = parser.add_subparsers(dest="command", required=True)

    login_parser = subparsers.add_parser("login")
    login_parser.add_argument("--endpoint", required=True)
    login_parser.add_argument("--code", required=True)

    subparsers.add_parser("whoami")

    route_parser = subparsers.add_parser("route")
    route_parser.add_argument("--dispatch", action="store_true", dest="dispatch_mode")
    route_parser.add_argument("text")
    route_parser.add_argument("--json", action="store_true", dest="json_output")

    skills_parser = subparsers.add_parser("skills")
    skills_subparsers = skills_parser.add_subparsers(dest="skills_command", required=True)
    scan_parser = skills_subparsers.add_parser("scan")
    scan_parser.add_argument("--source-path", required=True)
    scan_parser.add_argument("--source-label")
    scan_parser.add_argument("--source-id")

    sync_parser = subparsers.add_parser("sync")
    sync_parser.add_argument("--route-id", type=int)
    sync_parser.add_argument("--route-ids")
    sync_parser.add_argument("--force-full", action="store_true", dest="force_full")
    sync_parser.add_argument("--json", action="store_true", dest="json_output")

    return parser


def _client_from_config() -> IntentHubClient:
    config = load_config()
    return IntentHubClient(endpoint=config["endpoint"], access_code=config["access_code"])


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "login":
            save_config(endpoint=args.endpoint, access_code=args.code)
            print("Saved login config")
            return 0

        client = _client_from_config()

        if args.command == "whoami":
            print(json.dumps(client.whoami(), ensure_ascii=False))
            return 0

        if args.command == "route":
            payload = client.dispatch(args.text) if args.dispatch_mode else client.route(args.text)
            print(json.dumps(payload, ensure_ascii=False) if args.json_output else payload.get("route_key", ""))
            return 0

        if args.command == "skills" and args.skills_command == "scan":
            resolved_root, skills, errors = collect_skills(args.source_path)
            payload = client.skills_scan_uploaded(
                source_id=args.source_id,
                source_label=args.source_label,
                client_path_hint=resolved_root,
                skills=skills,
            )
            if errors:
                payload["errors"] = list(payload.get("errors", [])) + errors
            print(json.dumps(payload, ensure_ascii=False))
            return 0

        if args.command == "sync":
            route_ids: list[int] = []
            if args.route_id is not None:
                route_ids.append(args.route_id)
            if args.route_ids:
                route_ids.extend(int(part.strip()) for part in args.route_ids.split(",") if part.strip())

            if args.force_full and route_ids:
                raise ValueError("sync does not support combining route ids with --force-full.")

            if route_ids:
                payload = client.sync_routes(route_ids)
            else:
                payload = client.reindex(force_full=args.force_full)

            if args.json_output:
                print(json.dumps(payload, ensure_ascii=False))
            else:
                print(payload.get("message", json.dumps(payload, ensure_ascii=False)))
            return 0
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    parser.error("Unsupported command")
    return 1
