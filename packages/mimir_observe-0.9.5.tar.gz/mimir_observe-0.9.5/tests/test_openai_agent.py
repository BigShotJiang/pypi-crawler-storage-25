"""
End-to-end test: Mimir auto-instrumentation with OpenAI Agents SDK.

Runs the same agent twice with different inputs to produce two runs
that can be compared/diffed in the dashboard.
"""

import asyncio
import os
import sys
from pathlib import Path

# Load .env
env_path = Path(__file__).parent.parent / "mimir" / ".env"
if env_path.exists():
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())

from agents import Agent, Runner, function_tool

# ── Instrument BEFORE creating any agents ──
import mimir
mimir.configure(dashboard_url="http://localhost:9847")
mimir.instrument_openai_agents()
print("[mimir] OpenAI Agents SDK instrumented\n")


# ── Define tools ──

@function_tool
def search_codebase(query: str, file_type: str = "py") -> str:
    """Search the codebase for matching code patterns."""
    # Simulated results based on query
    results = {
        "sql": "Found 3 matches:\n  auth.py:42 - cursor.execute(f'SELECT * FROM users WHERE id={uid}')\n  db.py:15 - raw SQL in get_user()\n  api.py:88 - parameterized query (safe)",
        "auth": "Found 2 matches:\n  auth.py:10 - class AuthHandler\n  middleware.py:5 - JWT validation",
        "test": "Found 1 match:\n  tests/test_auth.py - 3 test cases",
        "error": "Found 2 matches:\n  handlers.py:20 - broad except clause\n  api.py:55 - missing error handling",
    }
    for key, val in results.items():
        if key in query.lower():
            return val
    return f"No results for '{query}' in *.{file_type} files"


@function_tool
def read_file(path: str) -> str:
    """Read the contents of a source file."""
    fake_files = {
        "auth.py": '''class AuthHandler:
    def authenticate(self, uid):
        # WARNING: SQL injection vulnerability
        cursor.execute(f"SELECT * FROM users WHERE id={uid}")
        return cursor.fetchone()

    def validate_token(self, token):
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
''',
        "db.py": '''def get_user(uid):
    return db.execute(f"SELECT * FROM users WHERE id={uid}")

def get_user_safe(uid):
    return db.execute("SELECT * FROM users WHERE id=?", (uid,))
''',
    }
    return fake_files.get(path, f"File not found: {path}")


@function_tool
def write_review(path: str, findings: str, severity: str = "medium") -> str:
    """Write a code review with findings."""
    return f"Review written to {path} ({severity} severity, {len(findings)} chars)"


# ── Create the agent ──

security_reviewer = Agent(
    name="Security Reviewer",
    model="gpt-4o-mini",
    instructions="""You are a security code reviewer. Your job is to:
1. Search the codebase for potential security issues
2. Read suspicious files
3. Write a review with your findings

Focus on: SQL injection, authentication flaws, and error handling.
Be thorough but concise. Always write a review at the end.""",
    tools=[search_codebase, read_file, write_review],
)


async def run_agent(prompt: str, run_label: str):
    print(f"{'='*60}")
    print(f"  RUN: {run_label}")
    print(f"  Prompt: {prompt}")
    print(f"{'='*60}")

    result = await Runner.run(security_reviewer, prompt)

    print(f"\n  Final output ({type(result.final_output).__name__}):")
    output = str(result.final_output)
    # Print first 500 chars
    if len(output) > 500:
        print(f"  {output[:500]}...")
    else:
        print(f"  {output}")
    print()


async def main():
    # Run 1: SQL injection focus
    await run_agent(
        "Review the codebase for SQL injection vulnerabilities. "
        "Search for SQL patterns, read any suspicious files, and write a review.",
        "SQL Injection Audit"
    )

    # Run 2: Same agent, different focus — should produce different tool trace
    await run_agent(
        "Review the authentication and error handling code. "
        "Search for auth patterns and error handling, read relevant files, and write a review.",
        "Auth & Error Handling Audit"
    )

    # Run 3: Same agent, same focus as run 1 — should produce similar trace (for diff comparison)
    await run_agent(
        "Do a quick check for SQL injection in the codebase. "
        "Search for SQL-related code and write a brief review.",
        "Quick SQL Check"
    )

    print("\n" + "="*60)
    print("  All runs complete! Check the dashboard at http://localhost:9847")
    print("="*60)

    # Print what the dashboard should show
    import urllib.request
    import json
    overview = json.loads(urllib.request.urlopen("http://localhost:9847/api/overview").read())
    groups = json.loads(urllib.request.urlopen("http://localhost:9847/api/task-groups").read())
    print(f"\n  Dashboard overview: {json.dumps(overview, indent=2)}")
    print(f"\n  Task groups:")
    for g in groups:
        print(f"    - {g['name']}: {g['run_count']} runs, model={g.get('model','')}")


if __name__ == "__main__":
    asyncio.run(main())
