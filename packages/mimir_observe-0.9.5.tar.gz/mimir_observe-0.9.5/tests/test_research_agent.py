"""
End-to-end test: Mimir instrumentation on a complex research agent.

A multi-step agent that:
  1. Searches the web for agent observability/visibility competitors
  2. Researches each competitor's features
  3. Compares against Mimir's capabilities
  4. Produces a gap analysis and USP report

Uses OpenAI Agents SDK with WebSearchTool for real web searches.
Run twice with slightly different prompts to test dashboard diffs.
"""

import asyncio
import os
from pathlib import Path

# Load .env
env_path = Path(__file__).parent.parent / "mimir" / ".env"
if env_path.exists():
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())

from agents import Agent, Runner, WebSearchTool, function_tool

# ── Instrument BEFORE creating agents ──
import mimir
mimir.configure(dashboard_url="http://localhost:9847")
mimir.instrument_openai_agents()
print("[mimir] OpenAI Agents SDK instrumented\n")


# ── Custom tools ──

@function_tool
def save_findings(section: str, content: str) -> str:
    """Save research findings to a section of the report.
    Use this to persist intermediate findings as you research each competitor."""
    findings_dir = Path("/tmp/mimir_research")
    findings_dir.mkdir(exist_ok=True)
    path = findings_dir / f"{section.replace(' ', '_').lower()}.md"
    path.write_text(content)
    return f"Saved {len(content)} chars to {section}"


@function_tool
def compile_report(title: str, sections: list[str]) -> str:
    """Compile all saved findings into a final report.
    Reads all previously saved sections and combines them."""
    findings_dir = Path("/tmp/mimir_research")
    report_parts = [f"# {title}\n"]
    for section in sections:
        path = findings_dir / f"{section.replace(' ', '_').lower()}.md"
        if path.exists():
            report_parts.append(f"\n## {section}\n{path.read_text()}")
        else:
            report_parts.append(f"\n## {section}\n*No findings saved for this section.*")
    report = "\n".join(report_parts)

    output_path = findings_dir / "final_report.md"
    output_path.write_text(report)
    return f"Report compiled: {len(report)} chars, {len(sections)} sections. Saved to {output_path}"


# ── Research Agent ──

research_agent = Agent(
    name="Competitive Research Analyst",
    model="gpt-4o-mini",
    instructions="""You are a competitive intelligence analyst specializing in AI developer tools.

Your task is to research the agent observability and visibility tool landscape, compare
competitors against Mimir, and produce a thorough gap analysis.

Mimir's current capabilities:
- Auto-instrumentation for OpenAI Agents SDK and Claude SDK (one-line setup)
- Local-first dashboard running on localhost (no cloud dependency)
- Trajectory tracking — groups runs by tool-call fingerprint
- Run diffing — side-by-side comparison of agent executions
- Divergence detection — flags when agent reruns follow different tool patterns
- Token usage and cost tracking per run
- Reasoning block capture between tool calls
- Zero external dependencies (stdlib only)
- Fire-and-forget telemetry (never blocks the agent)

Your research process should be:
1. Search for agent observability/tracing/visibility tools and platforms
2. For each major competitor, research their key features
3. Save findings for each competitor using the save_findings tool
4. Identify gaps in Mimir's offering and unique selling points
5. Save the gap analysis and USPs
6. Compile everything into a final report

Be thorough — search for at least 4-5 competitors. Look at tools like LangSmith,
Arize Phoenix, Braintrust, AgentOps, LangFuse, Helicone, and any others you find.

Always save intermediate findings before moving to the next competitor.""",
    tools=[WebSearchTool(), save_findings, compile_report],
)

async def run_research(prompt: str, run_label: str):
    print(f"\n{'='*70}")
    print(f"  {run_label}")
    print(f"  Prompt: {prompt[:100]}...")
    print(f"{'='*70}\n")

    result = await Runner.run(research_agent, prompt)

    output = str(result.final_output)
    print(f"\n  Output ({len(output)} chars):")
    print(f"  {output[:600]}...")
    return result


async def main():
    # Run 1: Full competitive analysis
    await run_research(
        "Research the current landscape of agent observability and visibility tools. "
        "Find at least 5 competitors, analyze their features, pricing, and approach. "
        "Compare them against Mimir's capabilities. "
        "Produce a report with: competitor overview, feature comparison, gaps in Mimir, "
        "and Mimir's unique selling points.",
        "Run 1: Full Competitive Analysis"
    )

    # Run 2: Same agent, slightly different angle — should produce similar but not identical trace
    await run_research(
        "Do a competitive analysis of agent tracing and debugging tools in the AI space. "
        "Focus on developer experience, ease of setup, and local-first vs cloud approaches. "
        "Compare what you find against Mimir and identify where Mimir wins and where it falls short. "
        "Write a concise report.",
        "Run 2: DX-Focused Competitive Analysis"
    )

    print(f"\n{'='*70}")
    print(f"  Both runs complete!")
    print(f"  Dashboard: http://localhost:9847")
    print(f"{'='*70}\n")

    # Show dashboard state
    import urllib.request
    import json
    overview = json.loads(urllib.request.urlopen("http://localhost:9847/api/overview").read())
    groups = json.loads(urllib.request.urlopen("http://localhost:9847/api/task-groups").read())
    print(f"  Overview: {json.dumps(overview, indent=2)}")
    for g in groups:
        print(f"  Agent: {g['name']} — {g['run_count']} runs")

    # Print the report if it exists
    report_path = Path("/tmp/mimir_research/final_report.md")
    if report_path.exists():
        print(f"\n  Report ({len(report_path.read_text())} chars) at: {report_path}")


if __name__ == "__main__":
    asyncio.run(main())
