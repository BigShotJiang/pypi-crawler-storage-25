"""
Mimir auto-instrumentation for the Claude Agent SDK.

Patches query() to capture every agent execution automatically.
Tries imports in order: claude_code_sdk, claude_agent_sdk, claude_sdk.
"""

from __future__ import annotations

import time
from typing import Any

from .sdk import Task, Run, _safe_serialize

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

_claude_instrumented = False
_original_query = None
_claude_module = None


# ---------------------------------------------------------------------------
# Claude hook helpers
# ---------------------------------------------------------------------------


def claude_hooks(run: Run) -> dict:
    """Build a Claude-style hooks dict that records events into *run*.

    Returns a dict mapping event type names to lists of handler entries.
    """
    _tool_starts: dict[str, float] = {}

    def on_post_tool_use(event) -> None:
        name = getattr(event, "name", "") or getattr(event, "tool_name", "") or "unknown"
        inp = _safe_serialize(getattr(event, "input", None) or getattr(event, "tool_input", None))
        result = _safe_serialize(getattr(event, "result", None) or getattr(event, "output", None))
        start = _tool_starts.pop(name, time.time())
        duration_ms = (time.time() - start) * 1000
        run.tool(name, inp, result, duration_ms)

    def on_pre_tool_use(event) -> None:
        name = getattr(event, "name", "") or getattr(event, "tool_name", "") or "unknown"
        _tool_starts[name] = time.time()

    def on_subagent_start(event) -> None:
        agent_id = getattr(event, "agent_id", "") or getattr(event, "id", "")
        run.reasoning(f"[subagent started: {agent_id}]")

    def on_subagent_stop(event) -> None:
        agent_id = getattr(event, "agent_id", "") or getattr(event, "id", "")
        run.reasoning(f"[subagent completed: {agent_id}]")

    return {
        "PreToolUse": [on_pre_tool_use],
        "PostToolUse": [on_post_tool_use],
        "SubagentStart": [on_subagent_start],
        "SubagentStop": [on_subagent_stop],
    }


def _merge_claude_hooks(user_hooks: dict | None, mimir_hooks: dict) -> dict:
    """Merge user hook dict with mimir hook dict.  User hooks fire first."""
    if not user_hooks:
        return mimir_hooks
    merged: dict[str, list] = {}
    all_keys = set(list(user_hooks.keys()) + list(mimir_hooks.keys()))
    for key in all_keys:
        merged[key] = user_hooks.get(key, []) + mimir_hooks.get(key, [])
    return merged


# ---------------------------------------------------------------------------
# Module discovery
# ---------------------------------------------------------------------------


def _find_claude_module():
    """Try to import the Claude SDK module.  Returns (module, query_fn) or raises."""
    for mod_name in ("claude_code_sdk", "claude_agent_sdk", "claude_sdk"):
        try:
            mod = __import__(mod_name)
            query_fn = getattr(mod, "query", None)
            if query_fn is not None:
                return mod, query_fn
        except ImportError:
            continue
    raise ImportError(
        "Could not find a Claude SDK. Install one of: "
        "claude-code-sdk, claude-agent-sdk, or claude-sdk"
    )


# ---------------------------------------------------------------------------
# Monkey-patching
# ---------------------------------------------------------------------------


def instrument_claude() -> None:
    """Patch query() in the Claude SDK to auto-capture runs."""
    global _claude_instrumented, _original_query, _claude_module

    if _claude_instrumented:
        return

    mod, query_fn = _find_claude_module()
    _claude_module = mod
    _original_query = query_fn

    async def _patched_query(*args, **kwargs):
        # Extract prompt — first positional arg or 'prompt' kwarg
        prompt = ""
        if args:
            prompt = str(args[0])[:500]
        elif "prompt" in kwargs:
            prompt = str(kwargs["prompt"])[:500]

        # Extract options for task metadata
        options = kwargs.get("options") or (args[1] if len(args) > 1 else None)
        agent_name = "claude-agent"
        model = ""
        tools: list[str] = []

        if options is not None:
            agent_name = getattr(options, "agent_name", "") or getattr(options, "name", "") or "claude-agent"
            model = getattr(options, "model", "") or ""
            _tools = getattr(options, "tools", None)
            if _tools:
                tools = [str(t) for t in _tools]
            # Check for existing hooks
            existing_hooks = getattr(options, "hooks", None)

        t = Task(
            name=agent_name,
            config=agent_name,
            tools=tools,
            model=model,
        )

        with t.run(input={"prompt": prompt}) as run:
            mimir_h = claude_hooks(run)
            if options is not None and hasattr(options, "hooks"):
                merged = _merge_claude_hooks(getattr(options, "hooks", None), mimir_h)
                try:
                    options.hooks = merged
                except (AttributeError, TypeError):
                    pass

            async for msg in _original_query(*args, **kwargs):
                yield msg

    setattr(mod, "query", _patched_query)
    _claude_instrumented = True


def uninstrument_claude() -> None:
    """Restore original query() function."""
    global _claude_instrumented, _original_query, _claude_module

    if not _claude_instrumented or _claude_module is None or _original_query is None:
        return

    setattr(_claude_module, "query", _original_query)
    _claude_instrumented = False
    _original_query = None
    _claude_module = None
