"""
Mimir auto-instrumentation for the raw OpenAI Python client.

Patches chat.completions.create (sync and async) on the class level
so every OpenAI client instance is automatically instrumented.

    import mimir
    mimir.instrument_openai()
"""

from __future__ import annotations

import time
from typing import Any

from .sdk import Task, Run, _safe_serialize, get_active_run

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

_instrumented = False
_original_create = None
_original_async_create = None
_task_cache: dict[str, Task] = {}  # model -> Task


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_task(model: str, tools: list[str] | None = None) -> Task:
    if model not in _task_cache:
        _task_cache[model] = Task(
            name=model,
            config=model,
            tools=tools or [],
            model=model,
        )
    return _task_cache[model]


def _extract_prompt(messages) -> str:
    """Walk backward through messages to find the last user message."""
    if not messages:
        return ""
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user" and isinstance(content, str) and content:
                return content[:500]
    return ""


def _extract_tool_names(tools) -> list[str]:
    """Extract tool/function names from the tools parameter."""
    if not tools:
        return []
    names = []
    for t in tools:
        if isinstance(t, dict):
            fn = t.get("function", {})
            name = fn.get("name", "") if isinstance(fn, dict) else ""
            if name:
                names.append(name)
    return names


def _process_response(run: Run, response, model: str, duration_ms: float) -> None:
    """Extract tool calls, usage, and content from an OpenAI response."""
    # Extract per-turn token counts
    turn_in, turn_out = 0, 0
    usage = getattr(response, "usage", None)
    if usage:
        turn_in = getattr(usage, "prompt_tokens", 0) or 0
        turn_out = getattr(usage, "completion_tokens", 0) or 0
        prev_in = run.usage.get("input_tokens", 0)
        prev_out = run.usage.get("output_tokens", 0)
        run.set_usage(prev_in + turn_in, prev_out + turn_out)
        from .sdk import _compute_cost
        cost = _compute_cost(model, prev_in + turn_in, prev_out + turn_out)
        if cost is not None:
            run.cost_usd = round(cost, 6)

    # Record per-turn usage as a step so the dashboard can show it
    if turn_in or turn_out:
        from .sdk import _compute_cost as _cc
        turn_cost = _cc(model, turn_in, turn_out)
        step = {
            "type": "llm_call",
            "model": model,
            "input_tokens": turn_in,
            "output_tokens": turn_out,
            "cost_usd": round(turn_cost, 6) if turn_cost else None,
            "duration_ms": round(duration_ms, 1),
            "ts": time.time(),
        }
        run.steps.append(step)
        from .sdk import _post
        _post("/api/run/step", {"run_id": run.run_id, **step})

    # Process choices
    choices = getattr(response, "choices", []) or []
    for choice in choices:
        msg = getattr(choice, "message", None)
        if not msg:
            continue

        # Tool calls
        tool_calls = getattr(msg, "tool_calls", None) or []
        for tc in tool_calls:
            fn = getattr(tc, "function", None)
            if fn:
                name = getattr(fn, "name", "unknown")
                args = getattr(fn, "arguments", "")
                run.tool(name, args, None, 0)

        # Content (assistant reasoning / response)
        content = getattr(msg, "content", None)
        if content and isinstance(content, str) and content.strip():
            run.reasoning(content[:2000], tokens=turn_out)

        # Refusal
        refusal = getattr(msg, "refusal", None)
        if refusal:
            run.reasoning(f"[refusal] {refusal[:500]}")


# ---------------------------------------------------------------------------
# Patching
# ---------------------------------------------------------------------------


def instrument_openai() -> None:
    """Patch OpenAI chat.completions.create to auto-capture every call."""
    global _instrumented, _original_create, _original_async_create

    if _instrumented:
        return

    try:
        from openai.resources.chat.completions.completions import Completions, AsyncCompletions
    except ImportError:
        raise ImportError(
            "Could not import 'openai'. Install it: pip install openai"
        )

    _original_create = Completions.create
    _original_async_create = AsyncCompletions.create

    def _patched_create(self, *, messages, model, **kwargs):
        active = get_active_run()
        start = time.time()

        if active:
            # Inside an existing run — add steps, don't create a new run
            try:
                result = _original_create(self, messages=messages, model=model, **kwargs)
            except Exception as e:
                active.tool_error("chat.completions.create", {"model": model}, str(e), (time.time() - start) * 1000)
                raise
            _process_response(active, result, model, (time.time() - start) * 1000)
            return result
        else:
            # No active run — create one (single-call use case)
            tools = kwargs.get("tools")
            task = _get_task(model, _extract_tool_names(tools))
            prompt = _extract_prompt(messages)
            with task.run(input={"prompt": prompt}) as run:
                try:
                    result = _original_create(self, messages=messages, model=model, **kwargs)
                except Exception as e:
                    run.tool_error("chat.completions.create", {"model": model}, str(e), (time.time() - start) * 1000)
                    raise
                _process_response(run, result, model, (time.time() - start) * 1000)
                run.set_output(_safe_serialize(getattr(result, "choices", [])))
                return result

    async def _patched_async_create(self, *, messages, model, **kwargs):
        active = get_active_run()
        start = time.time()

        if active:
            try:
                result = await _original_async_create(self, messages=messages, model=model, **kwargs)
            except Exception as e:
                active.tool_error("chat.completions.create", {"model": model}, str(e), (time.time() - start) * 1000)
                raise
            _process_response(active, result, model, (time.time() - start) * 1000)
            return result
        else:
            tools = kwargs.get("tools")
            task = _get_task(model, _extract_tool_names(tools))
            prompt = _extract_prompt(messages)
            with task.run(input={"prompt": prompt}) as run:
                try:
                    result = await _original_async_create(self, messages=messages, model=model, **kwargs)
                except Exception as e:
                    run.tool_error("chat.completions.create", {"model": model}, str(e), (time.time() - start) * 1000)
                    raise
                _process_response(run, result, model, (time.time() - start) * 1000)
                run.set_output(_safe_serialize(getattr(result, "choices", [])))
                return result

    Completions.create = _patched_create
    AsyncCompletions.create = _patched_async_create
    _instrumented = True


def uninstrument_openai() -> None:
    """Restore original OpenAI client methods."""
    global _instrumented, _original_create, _original_async_create

    if not _instrumented:
        return

    try:
        from openai.resources.chat.completions.completions import Completions, AsyncCompletions
    except ImportError:
        return

    if _original_create is not None:
        Completions.create = _original_create
    if _original_async_create is not None:
        AsyncCompletions.create = _original_async_create

    _instrumented = False
    _original_create = None
    _original_async_create = None
    _task_cache.clear()
