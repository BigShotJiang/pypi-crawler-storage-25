"""
Mimir auto-instrumentation for the OpenAI Agents SDK.

Monkey-patches Runner.run and Runner.run_streamed to capture every
agent execution automatically.  User hooks are preserved via composition.
"""

from __future__ import annotations

import time
from typing import Any

from .sdk import Task, Run, _safe_serialize

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

_openai_instrumented = False
_original_run = None
_original_run_streamed = None
_task_cache: dict[str, Task] = {}  # agent.name -> Task

# Populated by instrument_openai_agents() — must inherit from RunHooks
_MimirHooksClass = None
_CompositeHooksClass = None


# ---------------------------------------------------------------------------
# Task identity
# ---------------------------------------------------------------------------


def _get_or_create_task(agent) -> Task:
    """Get or create a Task keyed on agent.name only (stable identity)."""
    from .sdk import Task as _Task

    tools = [t.name for t in (agent.tools or []) if hasattr(t, "name")]
    model = getattr(agent, "model", "") or ""
    if agent.name not in _task_cache:
        _task_cache[agent.name] = _Task(
            name=agent.name,
            config=agent.name,  # stable identity from name
            tools=tools,
            model=model,
        )
    return _task_cache[agent.name]


# ---------------------------------------------------------------------------
# Input extraction
# ---------------------------------------------------------------------------


def _extract_input(input_val) -> dict:
    """Extract a meaningful prompt from various input formats."""
    if isinstance(input_val, str):
        return {"prompt": input_val[:500]}
    elif isinstance(input_val, list):
        for item in reversed(input_val):
            if isinstance(item, dict):
                content = item.get("content", "")
                if isinstance(content, str) and content:
                    return {"prompt": content[:500], "items": len(input_val)}
            # Handle TResponseInputItem objects
            if hasattr(item, "content"):
                content = getattr(item, "content", "")
                if isinstance(content, str) and content:
                    return {"prompt": content[:500], "items": len(input_val)}
        return {"items": len(input_val)}
    return {}


# ---------------------------------------------------------------------------
# Hook class factory — builds RunHooks subclasses at instrument time
# ---------------------------------------------------------------------------


def _build_hook_classes(RunHooks):
    """Create _MimirHooks and _CompositeHooks as RunHooks subclasses."""

    class MimirHooks(RunHooks):
        """Mimir-side hooks that capture tool calls, LLM usage, and agent events."""

        def __init__(self, run: Run):
            self._run = run
            self._tool_starts: dict[str, float] = {}
            self._tool_args: dict[str, Any] = {}
            self._usage_total = {"input_tokens": 0, "output_tokens": 0}

        async def on_tool_start(self, context, agent, tool) -> None:
            name = getattr(tool, "name", str(tool))
            self._tool_starts[name] = time.time()

        async def on_tool_end(self, context, agent, tool, result) -> None:
            name = getattr(tool, "name", str(tool))
            start = self._tool_starts.pop(name, time.time())
            duration_ms = (time.time() - start) * 1000
            args = self._tool_args.pop(name, None)
            result_str = str(result)[:1000] if result is not None else None
            self._run.tool(name, args, result_str, duration_ms)

        async def on_llm_start(self, context, agent, system_prompt, input_items) -> None:
            pass

        async def on_llm_end(self, context, agent, response) -> None:
            # Extract tool call args from response output
            if hasattr(response, "output"):
                for item in response.output:
                    if hasattr(item, "type") and item.type == "function_call":
                        name = getattr(item, "name", "")
                        args = getattr(item, "arguments", "")
                        if name:
                            self._tool_args[name] = args

                    # Capture reasoning from message content
                    if hasattr(item, "content") and isinstance(item.content, list):
                        for block in item.content:
                            if hasattr(block, "text") and block.text:
                                self._run.reasoning(block.text[:1000])

            # Accumulate usage
            if hasattr(response, "usage") and response.usage:
                usage = response.usage
                inp = getattr(usage, "input_tokens", 0) or 0
                out = getattr(usage, "output_tokens", 0) or 0
                self._usage_total["input_tokens"] += inp
                self._usage_total["output_tokens"] += out
                self._run.set_usage(
                    self._usage_total["input_tokens"],
                    self._usage_total["output_tokens"],
                )

        async def on_agent_start(self, context, agent) -> None:
            self._run.reasoning(f"[agent started: {agent.name}]")

        async def on_agent_end(self, context, agent, output) -> None:
            self._run.reasoning(f"[agent completed: {agent.name}]")

        async def on_handoff(self, context, from_agent, to_agent) -> None:
            self._run.reasoning(f"[handoff: {from_agent.name} \u2192 {to_agent.name}]")

    class CompositeHooks(RunHooks):
        """Calls user hooks first, then mimir hooks."""

        def __init__(self, user_hooks, mimir_hooks):
            self._user = user_hooks
            self._mimir = mimir_hooks

        async def _call_both(self, method: str, *args, **kwargs):
            if self._user:
                fn = getattr(self._user, method, None)
                if fn:
                    await fn(*args, **kwargs)
            fn = getattr(self._mimir, method, None)
            if fn:
                await fn(*args, **kwargs)

        async def on_tool_start(self, context, agent, tool):
            await self._call_both("on_tool_start", context, agent, tool)

        async def on_tool_end(self, context, agent, tool, result):
            await self._call_both("on_tool_end", context, agent, tool, result)

        async def on_llm_start(self, context, agent, system_prompt, input_items):
            await self._call_both("on_llm_start", context, agent, system_prompt, input_items)

        async def on_llm_end(self, context, agent, response):
            await self._call_both("on_llm_end", context, agent, response)

        async def on_agent_start(self, context, agent):
            await self._call_both("on_agent_start", context, agent)

        async def on_agent_end(self, context, agent, output):
            await self._call_both("on_agent_end", context, agent, output)

        async def on_handoff(self, context, from_agent, to_agent):
            await self._call_both("on_handoff", context, from_agent, to_agent)

    return MimirHooks, CompositeHooks


# ---------------------------------------------------------------------------
# Public hook constructor (for manual instrumentation)
# ---------------------------------------------------------------------------


def openai_hooks(run: Run):
    """Create a hooks object that records tool calls and LLM usage into *run*."""
    if _MimirHooksClass is None:
        raise RuntimeError("Call instrument_openai_agents() first")
    return _MimirHooksClass(run)


def _merge_hooks(user_hooks, run: Run):
    """Merge user hooks with mimir hooks.  User hooks fire first."""
    mimir = _MimirHooksClass(run)
    if user_hooks is None:
        return mimir
    return _CompositeHooksClass(user_hooks, mimir)


# ---------------------------------------------------------------------------
# Usage extraction from final result
# ---------------------------------------------------------------------------


def _extract_final_usage(run: Run, result) -> None:
    """Overwrite usage with authoritative numbers from result.context_wrapper."""
    try:
        usage = result.context_wrapper.usage
        if usage:
            inp = getattr(usage, "input_tokens", 0) or 0
            out = getattr(usage, "output_tokens", 0) or 0
            if inp or out:
                run.set_usage(inp, out)
    except (AttributeError, TypeError):
        pass


# ---------------------------------------------------------------------------
# Stream wrapper
# ---------------------------------------------------------------------------


class _InstrumentedStreamResult:
    """Wraps RunResultStreaming so the Run stays open until the stream ends."""

    def __init__(self, original, run: Run):
        self._original = original
        self._run = run
        self._finalized = False

    def __getattr__(self, name):
        return getattr(self._original, name)

    async def stream_events(self):
        try:
            async for event in self._original.stream_events():
                yield event
        finally:
            self._finalize()

    def _finalize(self):
        if self._finalized:
            return
        self._finalized = True
        try:
            _extract_final_usage(self._run, self._original)
            output = getattr(self._original, "final_output", None)
            if output is not None:
                self._run.set_output(output)
        except Exception:
            pass
        self._run.__exit__(None, None, None)

    def __del__(self):
        # Safety net if stream is never consumed
        self._finalize()


# ---------------------------------------------------------------------------
# Monkey-patching
# ---------------------------------------------------------------------------


def instrument_openai_agents() -> None:
    """Patch Runner.run and Runner.run_streamed to auto-capture runs."""
    global _openai_instrumented, _original_run, _original_run_streamed
    global _MimirHooksClass, _CompositeHooksClass

    if _openai_instrumented:
        return

    try:
        from agents import Runner, RunHooks
    except ImportError:
        raise ImportError(
            "Could not import 'agents'. Install the OpenAI Agents SDK: pip install openai-agents"
        )

    # Build RunHooks subclasses
    _MimirHooksClass, _CompositeHooksClass = _build_hook_classes(RunHooks)

    _original_run = Runner.run
    _original_run_streamed = Runner.run_streamed

    @classmethod  # type: ignore[misc]
    async def _patched_run(cls, starting_agent, input, **kwargs):
        hooks = kwargs.pop("hooks", None)
        task = _get_or_create_task(starting_agent)
        with task.run(input=_extract_input(input)) as run:
            merged = _merge_hooks(hooks, run)
            result = await _original_run.__func__(cls, starting_agent, input, hooks=merged, **kwargs)
            _extract_final_usage(run, result)
            run.set_output(_safe_serialize(getattr(result, "final_output", None)))
            return result

    @classmethod  # type: ignore[misc]
    def _patched_run_streamed(cls, starting_agent, input, **kwargs):
        hooks = kwargs.pop("hooks", None)
        task = _get_or_create_task(starting_agent)
        run = task.run(input=_extract_input(input))
        run.__enter__()
        merged = _merge_hooks(hooks, run)
        original_result = _original_run_streamed.__func__(cls, starting_agent, input, hooks=merged, **kwargs)
        return _InstrumentedStreamResult(original_result, run)

    Runner.run = _patched_run
    Runner.run_streamed = _patched_run_streamed
    _openai_instrumented = True


def uninstrument_openai_agents() -> None:
    """Restore original Runner methods."""
    global _openai_instrumented, _original_run, _original_run_streamed

    if not _openai_instrumented:
        return

    try:
        from agents import Runner
    except ImportError:
        return

    if _original_run is not None:
        Runner.run = _original_run
    if _original_run_streamed is not None:
        Runner.run_streamed = _original_run_streamed

    _openai_instrumented = False
    _original_run = None
    _original_run_streamed = None
    _task_cache.clear()
