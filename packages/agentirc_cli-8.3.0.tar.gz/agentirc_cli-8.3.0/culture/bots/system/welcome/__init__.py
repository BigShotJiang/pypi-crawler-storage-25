"""Welcome system bot."""
