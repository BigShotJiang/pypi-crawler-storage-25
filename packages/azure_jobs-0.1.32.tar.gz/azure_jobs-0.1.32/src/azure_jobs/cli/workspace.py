"""``aj ws`` — workspace management commands."""

from __future__ import annotations

import click

from azure_jobs.cli import main


@main.group(name="ws")
def ws_group() -> None:
    """Manage Azure ML workspaces."""


def _ensure_workspaces() -> tuple[dict[str, str], list[dict[str, str]]]:
    """Detect subscription and list workspaces, raising on failure."""
    from azure_jobs.core.config import detect_subscription, detect_workspaces
    from azure_jobs.utils.ui import console

    sub = detect_subscription()
    if not sub:
        raise click.ClickException("Cannot detect subscription. Run `az login` first.")

    with console.status("[bold cyan]Listing workspaces…[/bold cyan]", spinner="dots"):
        workspaces = detect_workspaces(sub["subscription_id"])

    if not workspaces:
        raise click.ClickException("No ML workspaces found in this subscription")

    return sub, workspaces


@ws_group.command(name="list")
def ws_list() -> None:
    """List Azure ML workspaces in the current subscription."""
    from rich.table import Table

    from azure_jobs.core.config import read_config
    from azure_jobs.utils.ui import console, print_table

    sub, workspaces = _ensure_workspaces()

    console.print(
        f"\n[dim]Subscription: {sub['subscription_name']}"
        f" ({sub['subscription_id'][:8]}…)[/dim]"
    )

    current_ws = read_config().workspace.workspace_name

    table = Table(
        show_header=True,
        header_style="bold",
        pad_edge=True,
        title="[bold]Workspaces[/bold]",
        title_style="",
    )
    table.add_column("", width=2)
    table.add_column("Name", style="cyan bold")
    table.add_column("Resource Group", style="dim")
    table.add_column("Location", style="dim")

    for ws in workspaces:
        marker = "●" if ws["name"] == current_ws else " "
        table.add_row(marker, ws["name"], ws["resource_group"], ws["location"])

    print_table(table)


@ws_group.command(name="show")
@click.argument("name", required=False)
def ws_show(name: str | None) -> None:
    """Show workspace details.

    Without arguments, shows the currently configured workspace.
    With NAME, looks up that workspace in the subscription.
    """
    from rich.panel import Panel
    from rich.table import Table

    from azure_jobs.core.config import read_config, resolve_workspace
    from azure_jobs.utils.ui import console, warning

    if name:
        try:
            ws = resolve_workspace(name)
        except ValueError as exc:
            raise click.ClickException(str(exc))
    else:
        cfg = read_config()
        if not cfg.workspace.workspace_name:
            warning("No workspace configured. Run `aj ws set` to configure.")
            return
        ws = cfg.workspace

    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold white", justify="right")
    grid.add_column()
    grid.add_row("Workspace", f"[bold cyan]{ws.workspace_name or '—'}[/bold cyan]")
    grid.add_row("Resource Group", ws.resource_group or "—")
    grid.add_row("Subscription", ws.subscription_id or "—")

    title = f"Workspace: {ws.workspace_name}" if name else "Current Workspace"
    console.print()
    console.print(
        Panel(
            grid,
            title=f"[bold]{title}[/bold]",
            border_style="cyan",
            expand=False,
        )
    )
    console.print()


@ws_group.command(name="set")
@click.argument("name", required=False)
def ws_set(name: str | None) -> None:
    """Set the active workspace.

    Without arguments, opens an interactive picker.
    With NAME, sets the workspace by exact name.
    """
    from azure_jobs.core.config import (
        pick_workspace,
        read_config,
        write_config,
    )
    from azure_jobs.utils.ui import success

    sub, workspaces = _ensure_workspaces()

    if name:
        match = [w for w in workspaces if w["name"] == name]
        if not match:
            available = ", ".join(w["name"] for w in workspaces)
            raise click.ClickException(
                f"Workspace '{name}' not found. Available: {available}"
            )
        picked = match[0]
    else:
        picked = pick_workspace(workspaces)
        if not picked:
            picked = {
                "name": click.prompt("Workspace name"),
                "resource_group": click.prompt("Resource group"),
            }

    cfg = read_config()
    cfg["workspace"] = {
        "subscription_id": sub["subscription_id"],
        "resource_group": picked["resource_group"],
        "workspace_name": picked["name"],
    }
    write_config(cfg)
    success(f"Workspace set to [bold]{picked['name']}[/bold]")
