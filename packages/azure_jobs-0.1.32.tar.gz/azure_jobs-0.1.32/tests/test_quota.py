"""Tests for ``aj quota list`` command and quota data model."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from azure_jobs.cli import main
from azure_jobs.cli.quota import (
    _fmt_nodes,
    _parse_compute_nodes,
    _portal_compute_url,
    _vm_sku_label,
)
from azure_jobs.core.sku import (
    SLA_TIERS,
    SeriesQuota,
    SlaTierQuota,
    VCInfo,
    discover_virtual_clusters,
    fetch_vc_quotas,
)


# ---------------------------------------------------------------------------
# SlaTierQuota unit tests
# ---------------------------------------------------------------------------


class TestSlaTierQuota:
    def test_available_with_used(self):
        q = SlaTierQuota(limit=10, used=3)
        assert q.available == 7

    def test_available_when_full(self):
        q = SlaTierQuota(limit=5, used=5)
        assert q.available == 0

    def test_available_clamps_to_zero(self):
        q = SlaTierQuota(limit=5, used=8)
        assert q.available == 0

    def test_available_unknown_used(self):
        q = SlaTierQuota(limit=10, used=None)
        assert q.available == 10

    def test_bool_true(self):
        assert bool(SlaTierQuota(limit=1))

    def test_bool_false(self):
        assert not bool(SlaTierQuota(limit=0))


# ---------------------------------------------------------------------------
# SeriesQuota unit tests
# ---------------------------------------------------------------------------


class TestSeriesQuota:
    def test_set_tier_premium(self):
        sq = SeriesQuota(series="ND_A100_v4")
        sq.set_tier("Premium", 64, 32)
        assert sq.tiers["Premium"].limit == 64
        assert sq.tiers["Premium"].used == 32

    def test_set_tier_none_is_overall(self):
        sq = SeriesQuota(series="ND_A100_v4")
        sq.set_tier(None, 100, 50)
        assert sq.overall is not None
        assert sq.overall.limit == 100

    def test_set_tier_unknown_falls_back_to_basic(self):
        sq = SeriesQuota(series="X")
        sq.set_tier("WeirdTier", 10, 5)
        assert "Basic" in sq.tiers
        assert sq.tiers["Basic"].limit == 10

    def test_has_any_quota_true(self):
        sq = SeriesQuota(series="X")
        sq.set_tier("Premium", 10, 0)
        assert sq.has_any_quota()

    def test_has_any_quota_false(self):
        sq = SeriesQuota(series="X")
        assert not sq.has_any_quota()

    def test_has_any_quota_overall_only(self):
        sq = SeriesQuota(series="X")
        sq.set_tier(None, 10, 5)
        assert sq.has_any_quota()

    def test_accelerator_from_family_map(self):
        sq = SeriesQuota(series="NDH100v5")
        assert sq.accelerator == "H100"

    def test_accelerator_api_format(self):
        sq = SeriesQuota(series="ND_A100_v4")
        assert sq.accelerator == "A100"

    def test_accelerator_inferred_from_name(self):
        sq = SeriesQuota(series="ND_H100_custom_v6")
        assert sq.accelerator == "H100"

    def test_accelerator_cpu_series(self):
        sq = SeriesQuota(series="Eadsv5")
        assert sq.accelerator == "CPU"

    def test_accelerator_unknown_series(self):
        sq = SeriesQuota(series="UNKNOWN_SERIES_XYZ")
        assert sq.accelerator == ""

    def test_gpu_memory_from_family_map(self):
        sq = SeriesQuota(series="NDH100v5")
        assert sq.gpu_memory == 80

    def test_gpu_memory_api_format(self):
        sq = SeriesQuota(series="ND_A100_v4")
        assert sq.gpu_memory == 80

    def test_gpu_memory_unknown(self):
        sq = SeriesQuota(series="UNKNOWN")
        assert sq.gpu_memory == 0


# ---------------------------------------------------------------------------
# fetch_vc_quotas tests
# ---------------------------------------------------------------------------


_MOCK_VC_RESPONSE = {
    "properties": {
        "managed": {
            "defaultGroupPolicyOverallQuotas": {
                "limits": [
                    {"id": "ND_A100_v4", "slaTier": None, "limit": 128, "used": 64},
                ]
            },
            "quotas": {
                "eastus": {
                    "limits": [
                        {
                            "id": "ND_A100_v4",
                            "slaTier": "Premium",
                            "limit": 64,
                            "used": 32,
                        },
                        {
                            "id": "ND_A100_v4",
                            "slaTier": "Standard",
                            "limit": 32,
                            "used": 10,
                        },
                        {
                            "id": "ND_H100_v5",
                            "slaTier": "Premium",
                            "limit": 16,
                            "used": 0,
                        },
                    ]
                },
                "westus": {
                    "limits": [
                        {"id": "NoProd", "slaTier": "Premium", "limit": 0, "used": 0},
                    ]
                },
            },
        }
    }
}


class TestFetchVcQuotas:
    def _make_client(self, response):
        client = MagicMock()
        client.get_vc_quotas_raw.return_value = response
        return client

    def test_merges_both_sources(self):
        results = fetch_vc_quotas(
            "sub", "rg", "myvc", arm_client=self._make_client(_MOCK_VC_RESPONSE)
        )
        series_names = [s.series for s in results]
        assert "ND_A100_v4" in series_names
        assert "ND_H100_v5" in series_names

    def test_sla_tiers_populated(self):
        results = fetch_vc_quotas(
            "sub", "rg", "myvc", arm_client=self._make_client(_MOCK_VC_RESPONSE)
        )
        a100 = next(s for s in results if s.series == "ND_A100_v4")
        assert "Premium" in a100.tiers
        assert a100.tiers["Premium"].limit == 64
        assert a100.tiers["Premium"].used == 32
        assert "Standard" in a100.tiers
        assert a100.overall is not None
        assert a100.overall.limit == 128

    def test_excludes_zero_by_default(self):
        results = fetch_vc_quotas(
            "sub", "rg", "myvc", arm_client=self._make_client(_MOCK_VC_RESPONSE)
        )
        series_names = [s.series for s in results]
        assert "NoProd" not in series_names

    def test_include_zero(self):
        results = fetch_vc_quotas(
            "sub",
            "rg",
            "myvc",
            include_zero=True,
            arm_client=self._make_client(_MOCK_VC_RESPONSE),
        )
        series_names = [s.series for s in results]
        assert "NoProd" in series_names

    def test_empty_on_exception(self):
        client = MagicMock()
        client.get_vc_quotas_raw.side_effect = Exception("fail")
        assert fetch_vc_quotas("sub", "rg", "myvc", arm_client=client) == []

    def test_empty_on_missing_keys(self):
        assert (
            fetch_vc_quotas("sub", "rg", "myvc", arm_client=self._make_client({})) == []
        )


# ---------------------------------------------------------------------------
# discover_virtual_clusters tests
# ---------------------------------------------------------------------------


class TestDiscoverVirtualClusters:
    def test_discovers_vcs_from_resource_graph(self):
        client = MagicMock()
        client.list_subscriptions.return_value = ["sub-1", "sub-2"]
        client.resource_graph_query.return_value = [
            {"name": "vc1", "resourceGroup": "rg1", "subscriptionId": "sub-1"},
            {"name": "vc2", "resourceGroup": "rg2", "subscriptionId": "sub-2"},
        ]
        vcs = discover_virtual_clusters(arm_client=client)
        assert len(vcs) == 2
        assert vcs[0].name == "vc1"
        assert vcs[1].name == "vc2"

    def test_uses_provided_subscriptions(self):
        client = MagicMock()
        client.resource_graph_query.return_value = [
            {"name": "vc1", "resourceGroup": "rg1", "subscriptionId": "sub-a"},
        ]
        vcs = discover_virtual_clusters(subscription_ids=["sub-a"], arm_client=client)
        assert len(vcs) == 1
        # Should NOT call list_subscriptions when IDs provided
        client.list_subscriptions.assert_not_called()

    def test_skips_empty_subscriptions(self):
        client = MagicMock()
        client.list_subscriptions.return_value = []
        assert discover_virtual_clusters(arm_client=client) == []

    def test_handles_exception_gracefully(self):
        client = MagicMock()
        client.list_subscriptions.side_effect = Exception("auth fail")
        assert discover_virtual_clusters(arm_client=client) == []

    def test_empty_on_no_data(self):
        client = MagicMock()
        client.list_subscriptions.return_value = ["sub-1"]
        client.resource_graph_query.return_value = []
        assert discover_virtual_clusters(arm_client=client) == []


# ---------------------------------------------------------------------------
# CLI tests
# ---------------------------------------------------------------------------


class TestQuotaListCli:
    def setup_method(self):
        self.runner = CliRunner()
        self._arm_patcher = patch("azure_jobs.core.rest_client.AzureARMClient")
        self._arm_patcher.start()

    def teardown_method(self):
        self._arm_patcher.stop()

    @patch("azure_jobs.cli.quota._discover_vcs", return_value=[])
    def test_sing_no_vcs_found(self, mock_disc):
        result = self.runner.invoke(main, ["quota", "list"])
        assert result.exit_code != 0
        assert "No Singularity" in result.output

    @patch("azure_jobs.core.sku.fetch_vc_quotas", return_value=[])
    @patch(
        "azure_jobs.cli.quota._discover_vcs",
        return_value=[
            VCInfo(name="myvc", resource_group="rg", subscription_id="s"),
        ],
    )
    def test_sing_vc_with_no_quotas(self, mock_disc, mock_fetch):
        result = self.runner.invoke(main, ["quota", "list"])
        assert result.exit_code == 0
        assert "myvc" in result.output

    @patch("azure_jobs.core.sku.fetch_vc_quotas")
    @patch("azure_jobs.cli.quota._discover_vcs")
    def test_sing_shows_grouped_table(self, mock_disc, mock_fetch):
        mock_disc.return_value = [
            VCInfo(name="vc1", resource_group="rg1", subscription_id="s"),
            VCInfo(name="vc2", resource_group="rg2", subscription_id="s"),
        ]
        sq1 = SeriesQuota(series="NDH100v5")
        sq1.set_tier("Premium", 64, 32)
        sq2 = SeriesQuota(series="NDAMv4")
        sq2.set_tier("Premium", 16, 16)
        mock_fetch.side_effect = [[sq1], [sq2]]

        result = self.runner.invoke(main, ["quota", "list"])
        assert result.exit_code == 0
        assert "vc1" in result.output
        assert "vc2" in result.output
        assert "NDH100v5" in result.output
        assert "NDAMv4" in result.output
        # Accelerator info should be populated
        assert "H100" in result.output
        assert "A100" in result.output

    def test_ql_alias_works(self):
        with patch("azure_jobs.cli.quota._discover_vcs", return_value=[]):
            result = self.runner.invoke(main, ["ql"])
            assert "No Singularity" in result.output

    @patch("azure_jobs.cli.quota._show_aml_quotas")
    def test_aml_flag_routes_to_aml(self, mock_aml):
        self.runner.invoke(main, ["quota", "list", "--aml"])
        mock_aml.assert_called_once_with(False)

    @patch("azure_jobs.cli.quota._show_aml_quotas")
    def test_aml_all_flag(self, mock_aml):
        self.runner.invoke(main, ["quota", "list", "--aml", "--all"])
        mock_aml.assert_called_once_with(True)


# ---------------------------------------------------------------------------
# AML helper tests
# ---------------------------------------------------------------------------


class TestAmlHelpers:
    def test_vm_sku_label_gpu(self):
        assert _vm_sku_label("Standard_ND96amsr_A100_v4") == "80G8-A100"

    def test_vm_sku_label_h100(self):
        assert _vm_sku_label("Standard_ND96isr_H100_v5") == "80G8-H100"

    def test_vm_sku_label_cpu(self):
        assert _vm_sku_label("Standard_DS3_v2") == "CPU"

    def test_vm_sku_label_unknown(self):
        assert _vm_sku_label("UnknownVm_XYZ") == ""

    def test_portal_compute_url(self):
        url = _portal_compute_url("sub1", "rg1", "ws1", "gpu-cluster")
        assert "ml.azure.com/compute/gpu-cluster/details" in url
        assert "sub1" in url
        assert "rg1" in url
        assert "ws1" in url

    def test_parse_compute_nodes(self):
        props = {
            "scaleSettings": {"maxNodeCount": 16},
            "nodeStateCounts": {
                "idleNodeCount": 2,
                "runningNodeCount": 5,
                "preparingNodeCount": 1,
                "leavingNodeCount": 0,
            },
        }
        assert _parse_compute_nodes(props) == (2, 6, 16)

    def test_parse_compute_nodes_empty(self):
        assert _parse_compute_nodes({}) == (0, 0, 0)

    def test_fmt_nodes_all_zero_activity(self):
        s = _fmt_nodes(0, 0, 16, low_priority=True)
        assert "dim" in s  # fully dimmed

    def test_fmt_nodes_busy_highlighted(self):
        s = _fmt_nodes(0, 4, 8, low_priority=False)
        assert "cyan" in s  # busy highlighted
        assert "dim" in s  # idle dimmed

    def test_fmt_nodes_max_zero(self):
        assert _fmt_nodes(0, 0, 0, low_priority=False) == "[dim]0/0[/dim]"
