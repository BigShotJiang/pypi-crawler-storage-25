"""QT9 QMS MCP Server — SOAP Web Services API client."""

__version__ = "0.1.0"
