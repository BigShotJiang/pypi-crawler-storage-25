"""PDF text and image extraction using PyMuPDF."""

import base64
import re
from pathlib import Path

import fitz  # pymupdf

from .models import DocumentContent, ExtractedImage

# Medivis doc code pattern: NY-NNN-TYPE-N or NY-NNN-TYPE.SUB-N
DOC_CODE_PATTERN = re.compile(r"\b(NY-\d{3}-[A-Z0-9]+(?:\.[A-Z0-9]+)*-\d+)\b")


def extract_text(pdf_path: Path) -> DocumentContent:
    doc = fitz.open(str(pdf_path))
    try:
        pages_text = []
        for page in doc:
            pages_text.append(page.get_text())

        full_text = "\n".join(pages_text)
        references = sorted(set(DOC_CODE_PATTERN.findall(full_text)))

        return DocumentContent(
            full_text=full_text,
            page_count=len(doc),
            references_found=references,
        )
    finally:
        doc.close()


def extract_text_and_images(pdf_path: Path) -> DocumentContent:
    doc = fitz.open(str(pdf_path))
    try:
        pages_text = []
        images = []

        for page_num, page in enumerate(doc):
            pages_text.append(page.get_text())

            for img_idx, img_info in enumerate(page.get_images(full=True)):
                xref = img_info[0]
                base_image = doc.extract_image(xref)
                if base_image and len(base_image["image"]) >= 1024:
                    images.append(
                        ExtractedImage(
                            page_number=page_num + 1,
                            image_index=img_idx,
                            mime_type=f"image/{base_image['ext']}",
                            data_base64=base64.b64encode(
                                base_image["image"]
                            ).decode("ascii"),
                            width=base_image.get("width", 0),
                            height=base_image.get("height", 0),
                        )
                    )

        full_text = "\n".join(pages_text)
        references = sorted(set(DOC_CODE_PATTERN.findall(full_text)))

        return DocumentContent(
            full_text=full_text,
            page_count=len(doc),
            references_found=references,
            images=images,
        )
    finally:
        doc.close()
