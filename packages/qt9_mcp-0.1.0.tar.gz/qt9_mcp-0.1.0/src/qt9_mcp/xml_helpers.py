"""SOAP 1.2 XML envelope builder and response parsers for QT9 Web Services."""

from xml.etree import ElementTree as ET

from .exceptions import QT9APIError

SOAP_NS = "http://www.w3.org/2003/05/soap-envelope"
QT9_NS = "QT9.QMS.WebD.WS"

ET.register_namespace("soap12", SOAP_NS)
ET.register_namespace("", QT9_NS)
ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")
ET.register_namespace("xsd", "http://www.w3.org/2001/XMLSchema")


def build_envelope(
    username: str,
    password: str,
    method: str,
    params: dict[str, str],
) -> str:
    envelope = ET.Element(f"{{{SOAP_NS}}}Envelope")
    envelope.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
    envelope.set("xmlns:xsd", "http://www.w3.org/2001/XMLSchema")

    header = ET.SubElement(envelope, f"{{{SOAP_NS}}}Header")
    auth = ET.SubElement(header, f"{{{QT9_NS}}}wsAuthenticator")
    user_el = ET.SubElement(auth, f"{{{QT9_NS}}}UserName")
    user_el.text = username
    pass_el = ET.SubElement(auth, f"{{{QT9_NS}}}Password")
    pass_el.text = password

    body = ET.SubElement(envelope, f"{{{SOAP_NS}}}Body")
    method_el = ET.SubElement(body, f"{{{QT9_NS}}}{method}")
    for key, value in params.items():
        param_el = ET.SubElement(method_el, f"{{{QT9_NS}}}{key}")
        param_el.text = value

    xml_str = ET.tostring(envelope, encoding="unicode", xml_declaration=False)
    return '<?xml version="1.0" encoding="utf-8"?>' + xml_str


def parse_soap_fault(xml_text: str) -> None:
    root = ET.fromstring(xml_text)
    fault = root.find(f".//{{{SOAP_NS}}}Fault")
    if fault is None:
        return None
    code_el = fault.find(f".//{{{SOAP_NS}}}Value")
    reason_el = fault.find(f".//{{{SOAP_NS}}}Text")
    fault_code = code_el.text if code_el is not None else "Unknown"
    fault_string = reason_el.text if reason_el is not None else "Unknown SOAP fault"
    raise QT9APIError(fault_code, fault_string)


def parse_dataset_response(xml_text: str, method_name: str) -> list[dict[str, str]]:
    parse_soap_fault(xml_text)
    root = ET.fromstring(xml_text)
    rows = []
    # QT9 DataSet responses use <NewDataSet xmlns=""> which resets the
    # namespace to empty for Table1 elements. Try both namespaced and bare.
    for table1 in root.iter("Table1"):
        row = {}
        for child in table1:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            row[tag] = child.text or ""
        rows.append(row)
    if not rows:
        for table1 in root.iter(f"{{{QT9_NS}}}Table1"):
            row = {}
            for child in table1:
                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                row[tag] = child.text or ""
            rows.append(row)
    return rows


def parse_object_response(
    xml_text: str, method_name: str, object_tag: str
) -> list[dict[str, str]]:
    parse_soap_fault(xml_text)
    root = ET.fromstring(xml_text)
    objects = []
    for obj in root.iter(f"{{{QT9_NS}}}{object_tag}"):
        item = {}
        for child in obj:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            item[tag] = child.text or ""
        objects.append(item)
    if not objects:
        for obj in root.iter(object_tag):
            item = {}
            for child in obj:
                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                item[tag] = child.text or ""
            objects.append(item)
    return objects


def parse_simple_response(xml_text: str, method_name: str) -> str:
    parse_soap_fault(xml_text)
    root = ET.fromstring(xml_text)
    result_tag = f"{method_name}Result"
    for el in root.iter(f"{{{QT9_NS}}}{result_tag}"):
        return el.text or ""
    for el in root.iter(result_tag):
        return el.text or ""
    return ""
