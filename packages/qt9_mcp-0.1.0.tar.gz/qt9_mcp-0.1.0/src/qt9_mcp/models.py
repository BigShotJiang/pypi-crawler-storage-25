"""Pydantic models for all QT9 SOAP response types.

Each model wraps a raw dict produced by xml_helpers.parse_dataset_response
or xml_helpers.parse_object_response, converting string values to appropriate
Python types (int, bool, etc.) through class-method constructors.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _int(value: str) -> int:
    """Convert a string to int, returning 0 for empty or invalid values."""
    try:
        return int(value)
    except (ValueError, TypeError):
        return 0


def _bool_from_str(value: str) -> bool:
    """Convert QT9 boolean string ('true'/'false') to Python bool."""
    return str(value).strip().lower() == "true"


# ---------------------------------------------------------------------------
# Document models
# ---------------------------------------------------------------------------

class DocumentSummary(BaseModel):
    """Summary row returned by document search / dataset responses."""

    document_id: int = 0
    doc_code: str = ""
    doc_num: int = 0
    doc_name: str = ""
    revision: str = ""
    department: str = ""
    doc_type: str = ""
    status: str = ""
    site_name: str = ""
    current_status: str = ""

    @classmethod
    def from_dataset_row(cls, row: dict[str, str]) -> "DocumentSummary":
        # QT9 splits the doc code: DocumentCode has the prefix (NY-302-QOP.F-)
        # and DocNum has the sequence number (21). Combine them.
        code_prefix = row.get("DocumentCode", "")
        doc_num = row.get("DocNum", "")
        full_code = code_prefix + doc_num if doc_num else code_prefix

        return cls(
            document_id=_int(row.get("DocumentID", "")),
            doc_code=full_code,
            doc_num=_int(doc_num),
            doc_name=row.get("DocumentName", "").strip(),
            # QT9 encodes "Rev. #" as "Rev._x0020__x0023_" in XML column names
            revision=row.get("Rev._x0020__x0023_", ""),
            department=row.get("Department", "").strip(),
            doc_type=row.get("DocType", "").strip(),
            status=row.get("Status", ""),
            site_name=row.get("SiteName", "").strip(),
            current_status=row.get("CurrentStatus", ""),
        )


class DocumentDetail(BaseModel):
    """Full document metadata from object-style responses."""

    document_id: int = 0
    doc_code: str = ""
    doc_name: str = ""
    revision: str = ""
    department: str = ""
    doc_type: str = ""
    status: str = ""
    site_name: str = ""
    description: str = ""
    change_notes: str = ""
    effective_date: str = ""
    review_date: str = ""
    owner: str = ""
    filename: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "DocumentDetail":
        return cls(
            document_id=_int(obj.get("DocumentID", "")),
            doc_code=obj.get("DocumentCode", ""),
            doc_name=obj.get("DocumentName", ""),
            revision=obj.get("Revision", ""),
            department=obj.get("Department", ""),
            doc_type=obj.get("DocType", ""),
            status=obj.get("Status", ""),
            site_name=obj.get("SiteName", ""),
            description=obj.get("Description", ""),
            change_notes=obj.get("ChangeNotes", ""),
            effective_date=obj.get("EffectiveDate", ""),
            review_date=obj.get("ReviewDate", ""),
            owner=obj.get("Owner", ""),
            filename=obj.get("FileName", ""),
        )


# ---------------------------------------------------------------------------
# ISO Actions (Corrective Actions / NCPs / Audits)
# ---------------------------------------------------------------------------

class IsoActionSummary(BaseModel):
    """Dataset row for ISO actions (CA, NCP, audit findings, etc.)."""

    record_number: int = 0
    problem: str = ""
    priority: str = ""
    status: str = ""
    product: str = ""
    customer: str = ""
    supplier: str = ""
    date_created: str = ""
    date_closed: str = ""
    due_date: str = ""

    @classmethod
    def from_dataset_row(cls, row: dict[str, str]) -> "IsoActionSummary":
        return cls(
            record_number=_int(row.get("RecordNumber", "")),
            # QT9 uses lowercase "problem" in some responses
            problem=row.get("problem", row.get("Problem", "")),
            priority=row.get("Priority", ""),
            status=row.get("Status", ""),
            product=row.get("Product", ""),
            customer=row.get("Customer", ""),
            supplier=row.get("Supplier", ""),
            date_created=row.get("DateCreated", ""),
            date_closed=row.get("DateClosed", ""),
            due_date=row.get("DueDate", ""),
        )


# ---------------------------------------------------------------------------
# ECN / ECR
# ---------------------------------------------------------------------------

class ECNSummary(BaseModel):
    """Engineering Change Notification summary."""

    ecn_id: int = 0
    ecn_number: str = ""
    ecn_name: str = ""
    ecn_status: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "ECNSummary":
        return cls(
            ecn_id=_int(obj.get("ECNID", obj.get("ECNId", ""))),
            ecn_number=obj.get("ECNNumber", ""),
            ecn_name=obj.get("ECNName", ""),
            ecn_status=obj.get("ECNStatus", obj.get("Status", "")),
        )


class ECRSummary(BaseModel):
    """Engineering Change Request summary."""

    ecr_id: int = 0
    ecr_number: str = ""
    ecr_name: str = ""
    ecr_status: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "ECRSummary":
        return cls(
            ecr_id=_int(obj.get("ECRID", obj.get("ECRId", ""))),
            ecr_number=obj.get("ECRNumber", ""),
            ecr_name=obj.get("ECRName", ""),
            ecr_status=obj.get("ECRStatus", obj.get("Status", "")),
        )


# ---------------------------------------------------------------------------
# Product
# ---------------------------------------------------------------------------

class ProductSummary(BaseModel):
    """Product record from GetProductsAsList-style responses."""

    product_id: int = 0
    product_name: str = ""
    part_number: str = ""
    description: str = ""
    inactive: bool = False

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "ProductSummary":
        return cls(
            product_id=_int(obj.get("ProductID", "")),
            product_name=obj.get("ProductName", ""),
            part_number=obj.get("PartNumber", ""),
            description=obj.get("Description", ""),
            inactive=_bool_from_str(obj.get("InActive", "false")),
        )


# ---------------------------------------------------------------------------
# Customer
# ---------------------------------------------------------------------------

class CustomerSummary(BaseModel):
    """Customer record from customer list responses."""

    customer_id: int = 0
    customer_name: str = ""
    customer_number: str = ""
    contact: str = ""
    email: str = ""
    phone: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "CustomerSummary":
        return cls(
            customer_id=_int(obj.get("CustomerID", "")),
            customer_name=obj.get("CustomerName", ""),
            customer_number=obj.get("CustomerNumber", ""),
            contact=obj.get("Contact", ""),
            email=obj.get("Email", ""),
            phone=obj.get("Phone", ""),
        )


# ---------------------------------------------------------------------------
# Customer Feedback
# ---------------------------------------------------------------------------

class FeedbackSummary(BaseModel):
    """Customer feedback dataset row."""

    record_number: int = 0
    status: str = ""
    customer: str = ""
    product: str = ""
    date_created: str = ""

    @classmethod
    def from_dataset_row(cls, row: dict[str, str]) -> "FeedbackSummary":
        return cls(
            record_number=_int(row.get("RecordNumber", "")),
            status=row.get("Status", ""),
            customer=row.get("Customer", ""),
            product=row.get("Product", ""),
            date_created=row.get("DateCreated", ""),
        )


# ---------------------------------------------------------------------------
# FMEA
# ---------------------------------------------------------------------------

class FMEARecord(BaseModel):
    """Failure Mode and Effects Analysis record."""

    fmea_id: int = 0
    fmea_name: str = ""
    fmea_type: str = ""
    status: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "FMEARecord":
        return cls(
            fmea_id=_int(obj.get("FMEAID", obj.get("FMEAId", ""))),
            fmea_name=obj.get("FMEAName", ""),
            fmea_type=obj.get("FMEAType", ""),
            status=obj.get("Status", ""),
        )


# ---------------------------------------------------------------------------
# Inspection
# ---------------------------------------------------------------------------

class InspectionSummary(BaseModel):
    """Inspection record summary."""

    inspection_id: int = 0
    product_name: str = ""
    part_number: str = ""
    status: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "InspectionSummary":
        return cls(
            inspection_id=_int(obj.get("InspectionID", obj.get("InspectionId", ""))),
            product_name=obj.get("ProductName", ""),
            part_number=obj.get("PartNumber", ""),
            status=obj.get("Status", ""),
        )


# ---------------------------------------------------------------------------
# Process
# ---------------------------------------------------------------------------

class ProcessSummary(BaseModel):
    """Process record dataset row."""

    process_id: int = 0
    process_name: str = ""

    @classmethod
    def from_dataset_row(cls, row: dict[str, str]) -> "ProcessSummary":
        return cls(
            process_id=_int(row.get("ProcessID", "")),
            process_name=row.get("ProcessName", ""),
        )


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------

class UserRecord(BaseModel):
    """User account record."""

    user_id: int = 0
    user_name: str = ""
    full_name: str = ""
    email: str = ""

    @classmethod
    def from_object_dict(cls, obj: dict[str, str]) -> "UserRecord":
        return cls(
            user_id=_int(obj.get("UserID", obj.get("UserId", ""))),
            user_name=obj.get("UserName", ""),
            full_name=obj.get("FullName", ""),
            email=obj.get("Email", ""),
        )


# ---------------------------------------------------------------------------
# Document content (PDF extraction results)
# ---------------------------------------------------------------------------

class ExtractedImage(BaseModel):
    """An image extracted from a PDF page."""

    page_number: int = 0
    image_index: int = 0
    mime_type: str = "image/png"
    data_base64: str = ""
    width: int = 0
    height: int = 0


class DocumentContent(BaseModel):
    """Result of PDF text and image extraction."""

    full_text: str = ""
    page_count: int = 0
    references_found: list[str] = Field(default_factory=list)
    images: list[ExtractedImage] = Field(default_factory=list)
