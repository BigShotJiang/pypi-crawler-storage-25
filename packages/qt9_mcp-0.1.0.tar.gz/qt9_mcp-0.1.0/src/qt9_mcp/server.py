"""MCP server exposing QT9 QMS SOAP client as tools for Claude."""

from __future__ import annotations

import asyncio
import json
import logging
import os

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import ImageContent, TextContent, Tool

from .client import QT9SoapClient
from .exceptions import QT9Error

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Server instructions — tells Claude how to use these tools effectively
# ---------------------------------------------------------------------------

SERVER_INSTRUCTIONS = """\
QT9 QMS MCP Server — Medivis Quality Management System

This server provides read-only access to the QT9 Quality Management System
via SOAP Web Services. It covers documents, corrective actions, nonconformances,
ECNs, ECRs, products, customers, inspections, FMEA, processes, and more.

TOOL OVERVIEW:
- qt9_hello: Connectivity test. Call first to verify the QT9 server is reachable.
- qt9_search_documents: Search documents by name, code, type, or status.
- qt9_get_document: Get full metadata for a single document by ID.
- qt9_read_document_content: Extract text (and optionally images) from a document PDF.
- qt9_search_records: Search ISO action records (CAR, NCP, PAR) by type, date, status.
- qt9_list_ecns: List Engineering Change Notifications.
- qt9_list_ecrs: List Engineering Change Requests.
- qt9_list_products: List all products.
- qt9_get_product_docs: Get documents linked to a product (by ID or part number).
- qt9_list_customers: List all customers.
- qt9_list_feedback: List customer feedback in a date range.
- qt9_list_inspections: List inspections, optionally filtered by product.
- qt9_list_fmea: List FMEA records.
- qt9_list_processes: List processes.
- qt9_get_udfs: Get user-defined field definitions for a link type.
- qt9_get_udf_answers: Get UDF answers for a specific record.
- qt9_download_file: Download a file by ID and type (returns base64).
- qt9_get_user: Get user details by ID.
- qt9_get_lookup_data: Get lookup/reference data (CAR types, priorities, etc.).

PARALLELIZATION:
All calls are stateless — each opens its own SOAP session. Always parallelize
independent calls. For example, call qt9_search_documents, qt9_list_products,
and qt9_list_customers simultaneously if you need data from all three.

RECOMMENDED WORKFLOWS:
- Document research: qt9_search_documents → qt9_get_document → qt9_read_document_content
- Quality investigation: qt9_search_records (CAR) + qt9_search_records (NCP) in parallel
- Product traceability: qt9_list_products → qt9_get_product_docs for each product

DOC CODE CONVENTIONS:
Medivis document codes follow the pattern SITE-NUMBER-TYPE-SEQUENCE, e.g.:
  NY-401-DMR-1, NY-301-QOP-15, NY-202-DHF.HAWEVD-45

WRITE SAFETY:
This server is read-only. No tools create, update, or delete records.
If a user asks to modify QT9 data, explain that this server only supports reads
and suggest they use the QT9 web interface directly.
"""

# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------

server = Server("qt9-qms", instructions=SERVER_INSTRUCTIONS)

# ---------------------------------------------------------------------------
# Singleton client
# ---------------------------------------------------------------------------

_client: QT9SoapClient | None = None


def _get_client() -> QT9SoapClient:
    """Return (or create) the singleton QT9 SOAP client."""
    global _client
    if _client is None:
        url = os.environ.get("QT9_URL", "")
        username = os.environ.get("QT9_USERNAME", "")
        password = os.environ.get("QT9_PASSWORD", "")
        if not url:
            raise QT9Error("QT9_URL environment variable is not set")
        if not username:
            raise QT9Error("QT9_USERNAME environment variable is not set")
        if not password:
            raise QT9Error("QT9_PASSWORD environment variable is not set")
        _client = QT9SoapClient(base_url=url, username=username, password=password)
    return _client


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _json_response(data: object) -> list[TextContent]:
    """Wrap a JSON-serializable object as a single TextContent block."""
    return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return all available QT9 tools."""
    return [
        # -- Connectivity ---------------------------------------------------
        Tool(
            name="qt9_hello",
            description="Test connectivity to the QT9 server. Returns a greeting on success.",
            inputSchema={"type": "object", "properties": {}},
        ),
        # -- Documents ------------------------------------------------------
        Tool(
            name="qt9_search_documents",
            description="Search QT9 documents by name, code, type, or status. All filters are optional.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Document Name filter (contains match)"},
                    "code": {"type": "string", "description": "Document Code filter (contains match)"},
                    "doc_type": {"type": "string", "description": "Document Type filter"},
                    "status": {"type": "string", "description": "Document Status filter"},
                },
            },
        ),
        Tool(
            name="qt9_get_document",
            description="Get full metadata for a single document by its ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {"type": "integer", "description": "Document ID"},
                },
                "required": ["doc_id"],
            },
        ),
        Tool(
            name="qt9_read_document_content",
            description=(
                "Extract the full text from a document's PDF. Optionally extract "
                "embedded images. Returns page count, discovered cross-references, "
                "and full text."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "doc_id": {"type": "integer", "description": "Document ID"},
                    "include_images": {
                        "type": "boolean",
                        "description": "If true, also extract images from the PDF (slower).",
                        "default": False,
                    },
                },
                "required": ["doc_id"],
            },
        ),
        # -- ISO Actions (CAR / NCP / PAR) ----------------------------------
        Tool(
            name="qt9_search_records",
            description=(
                "Search ISO action records (Corrective Actions, Nonconformances, "
                "Preventive Actions) by type, date range, and/or status."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "action_type": {
                        "type": "string",
                        "description": "Record type to search",
                        "enum": ["CAR", "NCP", "PAR"],
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date (MM/DD/YYYY). Defaults to 1 year ago.",
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date (MM/DD/YYYY). Defaults to today.",
                    },
                    "status": {
                        "type": "string",
                        "description": "Filter by status (e.g. 'Open', 'Closed'). If provided, only status filter is used.",
                    },
                },
                "required": ["action_type"],
            },
        ),
        # -- ECN / ECR ------------------------------------------------------
        Tool(
            name="qt9_list_ecns",
            description="List Engineering Change Notifications (ECNs), optionally sorted.",
            inputSchema={
                "type": "object",
                "properties": {
                    "sort_column": {
                        "type": "string",
                        "description": "Column to sort by (default: EcnNumber)",
                    },
                    "sort_direction": {
                        "type": "string",
                        "description": "Sort direction: 'asc' or 'desc' (default: asc)",
                        "enum": ["asc", "desc"],
                    },
                },
            },
        ),
        Tool(
            name="qt9_list_ecrs",
            description="List all Engineering Change Requests (ECRs).",
            inputSchema={"type": "object", "properties": {}},
        ),
        # -- Products -------------------------------------------------------
        Tool(
            name="qt9_list_products",
            description="List all products in the QT9 system.",
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="qt9_get_product_docs",
            description="Get documents linked to a product. Provide either product_id or part_number.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "integer", "description": "Product ID"},
                    "part_number": {"type": "string", "description": "Product Part Number"},
                },
            },
        ),
        # -- Customers ------------------------------------------------------
        Tool(
            name="qt9_list_customers",
            description="List all customers.",
            inputSchema={"type": "object", "properties": {}},
        ),
        # -- Customer Feedback ----------------------------------------------
        Tool(
            name="qt9_list_feedback",
            description="List customer feedback records in a date range.",
            inputSchema={
                "type": "object",
                "properties": {
                    "start_date": {
                        "type": "string",
                        "description": "Start date (MM/DD/YYYY). Defaults to 1 year ago.",
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date (MM/DD/YYYY). Defaults to today.",
                    },
                },
            },
        ),
        # -- Inspections ----------------------------------------------------
        Tool(
            name="qt9_list_inspections",
            description="List inspections, optionally filtered by product ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "integer",
                        "description": "Product ID to filter by. If omitted, returns all inspections.",
                    },
                },
            },
        ),
        # -- FMEA -----------------------------------------------------------
        Tool(
            name="qt9_list_fmea",
            description="List all FMEA (Failure Mode and Effects Analysis) records.",
            inputSchema={"type": "object", "properties": {}},
        ),
        # -- Processes ------------------------------------------------------
        Tool(
            name="qt9_list_processes",
            description="List all processes.",
            inputSchema={"type": "object", "properties": {}},
        ),
        # -- UDFs -----------------------------------------------------------
        Tool(
            name="qt9_get_udfs",
            description="Get user-defined field definitions for a given link type.",
            inputSchema={
                "type": "object",
                "properties": {
                    "link_type": {
                        "type": "string",
                        "description": "The link type to get UDFs for (e.g. 'ISOAction', 'Document').",
                    },
                },
                "required": ["link_type"],
            },
        ),
        Tool(
            name="qt9_get_udf_answers",
            description="Get user-defined field answers for a specific record.",
            inputSchema={
                "type": "object",
                "properties": {
                    "record_id": {
                        "type": "integer",
                        "description": "The record ID to get UDF answers for.",
                    },
                },
                "required": ["record_id"],
            },
        ),
        # -- File Download --------------------------------------------------
        Tool(
            name="qt9_download_file",
            description="Download a file by ID and type. Returns the file content as base64.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_id": {"type": "integer", "description": "File ID"},
                    "file_type": {
                        "type": "string",
                        "description": "File type (e.g. 'Document', 'ISOAction', 'ECN').",
                    },
                },
                "required": ["file_id", "file_type"],
            },
        ),
        # -- User -----------------------------------------------------------
        Tool(
            name="qt9_get_user",
            description="Get user details by user ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "user_id": {"type": "integer", "description": "User ID"},
                },
                "required": ["user_id"],
            },
        ),
        # -- Lookup Data ----------------------------------------------------
        Tool(
            name="qt9_get_lookup_data",
            description=(
                "Get lookup/reference data from QT9. Use this to discover valid "
                "values for filters (e.g. CAR types, priorities, document types)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "lookup_type": {
                        "type": "string",
                        "description": "The type of lookup data to retrieve.",
                        "enum": [
                            "car_types",
                            "priorities",
                            "problem_types",
                            "sites",
                            "document_types",
                            "document_categories",
                        ],
                    },
                },
                "required": ["lookup_type"],
            },
        ),
    ]


# ---------------------------------------------------------------------------
# Tool dispatch
# ---------------------------------------------------------------------------


@server.call_tool()
async def call_tool(
    name: str, arguments: dict
) -> list[TextContent] | list[TextContent | ImageContent]:
    """Route tool calls to the appropriate client method."""
    try:
        client = _get_client()
        return await _dispatch(name, arguments, client)
    except QT9Error as exc:
        return _json_response({"error": type(exc).__name__, "message": str(exc)})


async def _dispatch(
    name: str,
    arguments: dict,
    client: QT9SoapClient,
) -> list[TextContent] | list[TextContent | ImageContent]:
    """Dispatch a tool call to the correct client method."""

    # -- Connectivity -------------------------------------------------------
    if name == "qt9_hello":
        result = await client.hello_world()
        return _json_response({"message": result})

    # -- Documents ----------------------------------------------------------
    elif name == "qt9_search_documents":
        docs = await client.get_documents_filtered(
            name=arguments.get("name", ""),
            code=arguments.get("code", ""),
            doc_type=arguments.get("doc_type", ""),
            status=arguments.get("status", ""),
        )
        return _json_response({
            "count": len(docs),
            "documents": [d.model_dump() for d in docs],
        })

    elif name == "qt9_get_document":
        doc = await client.get_document_by_id(doc_id=arguments["doc_id"])
        return _json_response(doc.model_dump())

    elif name == "qt9_read_document_content":
        content = await client.read_document_content(
            doc_id=arguments["doc_id"],
            include_images=arguments.get("include_images", False),
        )
        result: list[TextContent | ImageContent] = [
            TextContent(
                type="text",
                text=json.dumps(
                    {
                        "page_count": content.page_count,
                        "references_found": content.references_found,
                        "full_text": content.full_text,
                    },
                    indent=2,
                ),
            )
        ]
        for img in content.images:
            result.append(
                ImageContent(
                    type="image",
                    data=img.data_base64,
                    mimeType=img.mime_type,
                )
            )
        return result

    # -- ISO Actions --------------------------------------------------------
    elif name == "qt9_search_records":
        action_type = arguments["action_type"]
        status = arguments.get("status")

        if status:
            records = await client.get_records_by_status(
                action_type=action_type, status=status
            )
        else:
            start_date = arguments.get(
                "start_date", "1970-01-01T00:00:00.0000000"
            )
            end_date = arguments.get(
                "end_date", "9999-12-31T23:59:59.9999999"
            )
            records = await client.get_all_records(
                action_type=action_type,
                start_date=start_date,
                end_date=end_date,
            )
        return _json_response({
            "count": len(records),
            "records": [r.model_dump() for r in records],
        })

    # -- ECN / ECR ----------------------------------------------------------
    elif name == "qt9_list_ecns":
        ecns = await client.get_sorted_ecn_list(
            sort_column=arguments.get("sort_column", "EcnNumber"),
            sort_direction=arguments.get("sort_direction", "asc"),
        )
        return _json_response({
            "count": len(ecns),
            "ecns": [e.model_dump() for e in ecns],
        })

    elif name == "qt9_list_ecrs":
        ecrs = await client.get_all_ecrs()
        return _json_response({
            "count": len(ecrs),
            "ecrs": [e.model_dump() for e in ecrs],
        })

    # -- Products -----------------------------------------------------------
    elif name == "qt9_list_products":
        products = await client.get_products()
        return _json_response({
            "count": len(products),
            "products": [p.model_dump() for p in products],
        })

    elif name == "qt9_get_product_docs":
        product_id = arguments.get("product_id")
        part_number = arguments.get("part_number")
        if product_id is not None:
            docs = await client.get_product_docs_by_id(product_id=product_id)
        elif part_number is not None:
            docs = await client.get_product_docs_by_part_num(part_num=part_number)
        else:
            return _json_response({
                "error": "InvalidArguments",
                "message": "Provide either product_id or part_number.",
            })
        return _json_response({
            "count": len(docs),
            "documents": [d.model_dump() for d in docs],
        })

    # -- Customers ----------------------------------------------------------
    elif name == "qt9_list_customers":
        customers = await client.get_customers()
        return _json_response({
            "count": len(customers),
            "customers": [c.model_dump() for c in customers],
        })

    # -- Customer Feedback --------------------------------------------------
    elif name == "qt9_list_feedback":
        start_date = arguments.get(
            "start_date", "1970-01-01T00:00:00.0000000"
        )
        end_date = arguments.get(
            "end_date", "9999-12-31T23:59:59.9999999"
        )
        feedback = await client.get_all_feedback(
            start_date=start_date, end_date=end_date
        )
        return _json_response({
            "count": len(feedback),
            "feedback": [f.model_dump() for f in feedback],
        })

    # -- Inspections --------------------------------------------------------
    elif name == "qt9_list_inspections":
        product_id = arguments.get("product_id")
        if product_id is not None:
            inspections = await client.get_inspection_by_product_id(
                product_id=product_id
            )
        else:
            inspections = await client.get_inspections()
        return _json_response({
            "count": len(inspections),
            "inspections": [i.model_dump() for i in inspections],
        })

    # -- FMEA ---------------------------------------------------------------
    elif name == "qt9_list_fmea":
        fmea = await client.get_fmea_records()
        return _json_response({
            "count": len(fmea),
            "fmea_records": [f.model_dump() for f in fmea],
        })

    # -- Processes ----------------------------------------------------------
    elif name == "qt9_list_processes":
        processes = await client.get_processes()
        return _json_response({
            "count": len(processes),
            "processes": [p.model_dump() for p in processes],
        })

    # -- UDFs ---------------------------------------------------------------
    elif name == "qt9_get_udfs":
        udfs = await client.get_udfs_by_link_type(link_type=arguments["link_type"])
        return _json_response({"count": len(udfs), "udfs": udfs})

    elif name == "qt9_get_udf_answers":
        answers = await client.get_udf_record_answers(
            record_id=arguments["record_id"]
        )
        return _json_response({"count": len(answers), "answers": answers})

    # -- File Download ------------------------------------------------------
    elif name == "qt9_download_file":
        import base64

        data = await client.download_file(
            file_id=arguments["file_id"], file_type=arguments["file_type"]
        )
        return _json_response({
            "file_id": arguments["file_id"],
            "file_type": arguments["file_type"],
            "size_bytes": len(data),
            "data_base64": base64.b64encode(data).decode("ascii"),
        })

    # -- User ---------------------------------------------------------------
    elif name == "qt9_get_user":
        user = await client.get_user_by_id(user_id=arguments["user_id"])
        return _json_response(user.model_dump())

    # -- Lookup Data --------------------------------------------------------
    elif name == "qt9_get_lookup_data":
        lookup_type = arguments["lookup_type"]
        if lookup_type == "car_types":
            data = await client.get_car_types()
        elif lookup_type == "priorities":
            data = await client.get_iso_action_priorities()
        elif lookup_type == "problem_types":
            data = await client.get_iso_action_problem_types()
        elif lookup_type == "sites":
            data = await client.get_user_iso_action_sites()
        elif lookup_type == "document_types":
            data = await client.get_document_types()
        elif lookup_type == "document_categories":
            data = await client.get_document_categories()
        else:
            return _json_response({
                "error": "InvalidArguments",
                "message": f"Unknown lookup_type: {lookup_type}",
            })
        return _json_response({"lookup_type": lookup_type, "data": data})

    # -- Unknown tool -------------------------------------------------------
    else:
        return _json_response({
            "error": "UnknownTool",
            "message": f"No handler for tool: {name}",
        })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    """Run the MCP server over stdio."""
    logging.basicConfig(level=logging.INFO)

    async def _run():
        async with stdio_server() as (read, write):
            try:
                await server.run(read, write, server.create_initialization_options())
            finally:
                if _client:
                    await _client.close()

    asyncio.run(_run())


if __name__ == "__main__":
    main()
