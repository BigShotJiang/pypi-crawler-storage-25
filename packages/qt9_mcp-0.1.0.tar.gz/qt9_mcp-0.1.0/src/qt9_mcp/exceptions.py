"""QT9 SOAP API exception hierarchy."""


class QT9Error(Exception):
    """Base exception for all QT9 API errors."""


class QT9ConnectionError(QT9Error):
    """Cannot reach the QT9 server."""


class QT9AuthError(QT9Error):
    """Authentication failed — bad credentials or expired user."""


class QT9APIError(QT9Error):
    """SOAP fault returned by QT9."""

    def __init__(self, fault_code: str, fault_string: str):
        self.fault_code = fault_code
        self.fault_string = fault_string
        super().__init__(f"SOAP fault [{fault_code}]: {fault_string}")


class QT9NotFoundError(QT9Error):
    """Requested record or document does not exist."""
