"""QT9 SOAP API client — wraps all QT9 Web Services endpoints."""

from __future__ import annotations

import httpx

from .exceptions import QT9APIError, QT9AuthError, QT9ConnectionError
from .xml_helpers import (
    build_envelope,
    parse_dataset_response,
    parse_object_response,
    parse_simple_response,
)


class QT9SoapClient:
    """Async client for the QT9 QMS SOAP Web Services API."""

    def __init__(self, base_url: str, username: str, password: str):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self._http = httpx.AsyncClient(timeout=60)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def _call(
        self,
        service: str,
        method: str,
        params: dict[str, str] | None = None,
    ) -> str:
        """Make a SOAP call. Returns raw XML response string.

        Raises QT9ConnectionError on network failure, QT9APIError on SOAP fault.
        """
        url = f"{self.base_url}/services/{service}.asmx"
        body = build_envelope(self.username, self.password, method, params or {})
        try:
            response = await self._http.post(
                url,
                content=body,
                headers={"Content-Type": "application/soap+xml; charset=utf-8"},
            )
            response.raise_for_status()
        except httpx.ConnectError as e:
            raise QT9ConnectionError(f"Cannot connect to {url}: {e}") from e
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise QT9AuthError("Authentication failed") from e
            raise QT9ConnectionError(f"HTTP {e.response.status_code}: {e}") from e
        except httpx.HTTPError as e:
            raise QT9ConnectionError(f"HTTP error: {e}") from e
        return response.text

    # -----------------------------------------------------------------------
    # wsAppComp
    # -----------------------------------------------------------------------

    async def hello_world(self) -> str:
        """Call HelloWorld to verify connectivity."""
        xml = await self._call("wsAppComp", "HelloWorld")
        return parse_simple_response(xml, "HelloWorld")

    # -----------------------------------------------------------------------
    # wsDocuments
    # -----------------------------------------------------------------------

    async def get_all_documents(self) -> list["DocumentSummary"]:
        from .models import DocumentSummary

        xml = await self._call("wsDocuments", "GetAllDocumentsAsDataSet")
        rows = parse_dataset_response(xml, "GetAllDocumentsAsDataSet")
        return [DocumentSummary.from_dataset_row(r) for r in rows]

    async def get_documents_filtered(
        self,
        name: str = "",
        code: str = "",
        doc_type: str = "",
        status: str = "",
    ) -> list["DocumentSummary"]:
        """Search documents. Applies client-side filtering because
        QT9's server-side filters are unreliable."""
        from .models import DocumentSummary

        xml = await self._call(
            "wsDocuments",
            "GetDocumentsFilteredAsDataSet",
            {
                "DocumentName": name,
                "DocumentCode": code,
                "DocType": doc_type,
                "DocStatus": status,
            },
        )
        rows = parse_dataset_response(xml, "GetDocumentsFilteredAsDataSet")
        docs = [DocumentSummary.from_dataset_row(r) for r in rows]

        # Client-side filtering — QT9 server often ignores filter params
        if name:
            name_lower = name.lower()
            docs = [d for d in docs if name_lower in d.doc_name.lower()]
        if code:
            code_lower = code.lower()
            docs = [d for d in docs if code_lower in d.doc_code.lower()]
        if doc_type:
            type_lower = doc_type.lower()
            docs = [d for d in docs if type_lower in d.doc_type.lower()]
        if status:
            status_lower = status.lower()
            docs = [
                d for d in docs
                if status_lower in d.status.lower()
                or status_lower in d.current_status.lower()
            ]
        return docs

    async def get_document_by_id(self, doc_id: int) -> "DocumentDetail":
        from xml.etree import ElementTree as ET

        from .models import DocumentDetail

        xml = await self._call(
            "wsDocuments", "GetDocumentByID", {"DocumentID": str(doc_id)}
        )
        root = ET.fromstring(xml)
        for el in root.iter():
            tag = el.tag.split("}")[-1] if "}" in el.tag else el.tag
            if tag == "GetDocumentByIDResult":
                obj: dict[str, str] = {}
                for child in el:
                    child_tag = (
                        child.tag.split("}")[-1] if "}" in child.tag else child.tag
                    )
                    obj[child_tag] = child.text or ""
                return DocumentDetail.from_object_dict(obj)
        return DocumentDetail()

    async def get_document_types(self) -> list[dict[str, str]]:
        xml = await self._call("wsDocuments", "GetDocumentTypesAsDataSet")
        return parse_dataset_response(xml, "GetDocumentTypesAsDataSet")

    async def get_document_categories(self) -> list[dict[str, str]]:
        xml = await self._call("wsDocuments", "GetDocumentCategoriesAsDataSet")
        return parse_dataset_response(xml, "GetDocumentCategoriesAsDataSet")

    async def doc_num_in_use(self, doc_num: str) -> bool:
        xml = await self._call(
            "wsDocuments", "DocNumInUse", {"DocNum": doc_num}
        )
        result = parse_simple_response(xml, "DocNumInUse")
        return str(result).strip().lower() == "true"

    # -----------------------------------------------------------------------
    # wsISOActions
    # -----------------------------------------------------------------------

    async def get_all_records(
        self,
        action_type: str,
        start_date: str,
        end_date: str,
    ) -> list["IsoActionSummary"]:
        from .models import IsoActionSummary

        xml = await self._call(
            "wsISOActions",
            "GetAllRecords",
            {
                "ActionType": action_type,
                "StartDate": start_date,
                "EndDate": end_date,
            },
        )
        rows = parse_dataset_response(xml, "GetAllRecords")
        return [IsoActionSummary.from_dataset_row(r) for r in rows]

    async def get_records_by_status(
        self, action_type: str, status: str
    ) -> list["IsoActionSummary"]:
        from .models import IsoActionSummary

        xml = await self._call(
            "wsISOActions",
            "GetRecordsByStatus",
            {"ActionType": action_type, "Status": status},
        )
        rows = parse_dataset_response(xml, "GetRecordsByStatus")
        return [IsoActionSummary.from_dataset_row(r) for r in rows]

    async def get_car_types(self) -> list[str]:
        xml = await self._call("wsISOActions", "GetCarTypes")
        objects = parse_object_response(xml, "GetCarTypes", "string")
        if objects:
            return [o.get("", o.get("string", "")) for o in objects]
        result = parse_simple_response(xml, "GetCarTypes")
        return [s.strip() for s in result.split(",") if s.strip()] if result else []

    async def get_iso_action_priorities(self) -> list[str]:
        xml = await self._call("wsISOActions", "GetIsoActionPriorities")
        objects = parse_object_response(xml, "GetIsoActionPriorities", "string")
        if objects:
            return [list(o.values())[0] for o in objects if o]
        result = parse_simple_response(xml, "GetIsoActionPriorities")
        return [s.strip() for s in result.split(",") if s.strip()] if result else []

    async def get_iso_action_problem_types(self) -> list[str]:
        xml = await self._call("wsISOActions", "GetIsoActionProblemTypes")
        objects = parse_object_response(xml, "GetIsoActionProblemTypes", "string")
        if objects:
            return [list(o.values())[0] for o in objects if o]
        result = parse_simple_response(xml, "GetIsoActionProblemTypes")
        return [s.strip() for s in result.split(",") if s.strip()] if result else []

    async def get_user_iso_action_sites(self) -> list[str]:
        xml = await self._call("wsISOActions", "GetUserIsoActionSites")
        objects = parse_object_response(xml, "GetUserIsoActionSites", "string")
        if objects:
            return [list(o.values())[0] for o in objects if o]
        result = parse_simple_response(xml, "GetUserIsoActionSites")
        return [s.strip() for s in result.split(",") if s.strip()] if result else []

    # -----------------------------------------------------------------------
    # wsECN
    # -----------------------------------------------------------------------

    async def get_sorted_ecn_list(
        self,
        sort_column: str = "EcnNumber",
        sort_direction: str = "asc",
    ) -> list["ECNSummary"]:
        from .models import ECNSummary

        xml = await self._call(
            "wsECN",
            "GetSortedEcnList",
            {"SortColumn": sort_column, "SortDirection": sort_direction},
        )
        objects = parse_object_response(xml, "GetSortedEcnList", "QT9ECN")
        if not objects:
            rows = parse_dataset_response(xml, "GetSortedEcnList")
            return [ECNSummary.from_object_dict(r) for r in rows]
        return [ECNSummary.from_object_dict(o) for o in objects]

    async def get_next_ecn_number(self) -> str:
        xml = await self._call("wsECN", "GetNextEcnNumber")
        return parse_simple_response(xml, "GetNextEcnNumber")

    # -----------------------------------------------------------------------
    # wsECR
    # -----------------------------------------------------------------------

    async def get_all_ecrs(self) -> list["ECRSummary"]:
        from .models import ECRSummary

        xml = await self._call("wsECR", "GetAllEcrs")
        objects = parse_object_response(xml, "GetAllEcrs", "QT9ECR")
        if not objects:
            rows = parse_dataset_response(xml, "GetAllEcrs")
            return [ECRSummary.from_object_dict(r) for r in rows]
        return [ECRSummary.from_object_dict(o) for o in objects]

    # -----------------------------------------------------------------------
    # wsCustomerFeedback
    # -----------------------------------------------------------------------

    async def get_all_feedback(
        self, start_date: str, end_date: str
    ) -> list["FeedbackSummary"]:
        from .models import FeedbackSummary

        xml = await self._call(
            "wsCustomerFeedback",
            "GetAllRecords",
            {"StartDate": start_date, "EndDate": end_date},
        )
        rows = parse_dataset_response(xml, "GetAllRecords")
        return [FeedbackSummary.from_dataset_row(r) for r in rows]

    # -----------------------------------------------------------------------
    # wsProducts
    # -----------------------------------------------------------------------

    async def get_products(self) -> list["ProductSummary"]:
        from .models import ProductSummary

        xml = await self._call("wsProducts", "GetProductsAsList")
        objects = parse_object_response(xml, "GetProductsAsList", "QT9Product")
        return [ProductSummary.from_object_dict(o) for o in objects]

    async def get_product_docs_by_id(self, product_id: int) -> list["DocumentSummary"]:
        from .models import DocumentSummary

        xml = await self._call(
            "wsProducts",
            "GetProductDocsByProductID",
            {"ProductID": str(product_id)},
        )
        rows = parse_dataset_response(xml, "GetProductDocsByProductID")
        if rows:
            return [DocumentSummary.from_dataset_row(r) for r in rows]
        objects = parse_object_response(xml, "GetProductDocsByProductID", "QT9Document")
        return [DocumentSummary.from_object_dict(o) for o in objects]

    async def get_product_docs_by_part_num(
        self, part_num: str
    ) -> list["DocumentSummary"]:
        from .models import DocumentSummary

        xml = await self._call(
            "wsProducts",
            "GetProductDocsByPartNum",
            {"PartNum": part_num},
        )
        rows = parse_dataset_response(xml, "GetProductDocsByPartNum")
        if rows:
            return [DocumentSummary.from_dataset_row(r) for r in rows]
        objects = parse_object_response(xml, "GetProductDocsByPartNum", "QT9Document")
        return [DocumentSummary.from_object_dict(o) for o in objects]

    # -----------------------------------------------------------------------
    # wsCustomers
    # -----------------------------------------------------------------------

    async def get_customers(self) -> list["CustomerSummary"]:
        from .models import CustomerSummary

        xml = await self._call("wsCustomers", "GetCustomersAsList")
        objects = parse_object_response(xml, "GetCustomersAsList", "QT9Customer")
        return [CustomerSummary.from_object_dict(o) for o in objects]

    # -----------------------------------------------------------------------
    # wsFMEA
    # -----------------------------------------------------------------------

    async def get_fmea_records(self) -> list["FMEARecord"]:
        from .models import FMEARecord

        xml = await self._call("wsFMEA", "GetFmeaRecordsAsList")
        objects = parse_object_response(xml, "GetFmeaRecordsAsList", "QT9FmeaRecord")
        return [FMEARecord.from_object_dict(o) for o in objects]

    # -----------------------------------------------------------------------
    # wsInspections
    # -----------------------------------------------------------------------

    async def get_inspections(self) -> list["InspectionSummary"]:
        from .models import InspectionSummary

        xml = await self._call("wsInspections", "GetInspections_AsList")
        objects = parse_object_response(xml, "GetInspections_AsList", "QT9Inspection")
        return [InspectionSummary.from_object_dict(o) for o in objects]

    async def get_inspection_by_product_id(
        self, product_id: int
    ) -> list["InspectionSummary"]:
        from .models import InspectionSummary

        xml = await self._call(
            "wsInspections",
            "GetInspectionByProductID_AsList",
            {"ProductID": str(product_id)},
        )
        objects = parse_object_response(
            xml, "GetInspectionByProductID_AsList", "QT9Inspection"
        )
        return [InspectionSummary.from_object_dict(o) for o in objects]

    # -----------------------------------------------------------------------
    # wsProcess
    # -----------------------------------------------------------------------

    async def get_processes(self) -> list["ProcessSummary"]:
        from .models import ProcessSummary

        xml = await self._call("wsProcess", "GetProcessesAsDataSet")
        rows = parse_dataset_response(xml, "GetProcessesAsDataSet")
        return [ProcessSummary.from_dataset_row(r) for r in rows]

    # -----------------------------------------------------------------------
    # wsUDF
    # -----------------------------------------------------------------------

    async def get_udfs_by_link_type(self, link_type: str) -> list[dict[str, str]]:
        xml = await self._call(
            "wsUDF", "GetUdfByLinkTypeList", {"LinkType": link_type}
        )
        return parse_object_response(xml, "GetUdfByLinkTypeList", "QT9UDF")

    async def get_udf_record_answers(self, record_id: int) -> list[dict[str, str]]:
        xml = await self._call(
            "wsUDF",
            "GetUdfRecordAnsByID",
            {"RecordID": str(record_id)},
        )
        return parse_object_response(xml, "GetUdfRecordAnsByID", "QT9UDFAnswer")

    # -----------------------------------------------------------------------
    # wsFileDownload
    # -----------------------------------------------------------------------

    async def get_file_info(
        self, file_id: int, file_type: str
    ) -> tuple[str, int]:
        """Get filename and size for a file. Returns (filename, size_bytes).

        QT9 flow: GetFileDownload returns a GUID filename + size.
        This filename is then used with DownloadChunk.
        """
        from xml.etree import ElementTree as ET

        xml = await self._call(
            "wsFileDownload",
            "GetFileDownload",
            {"FileID": str(file_id), "FileType": file_type},
        )
        root = ET.fromstring(xml)
        filename = ""
        size = 0
        for el in root.iter():
            tag = el.tag.split("}")[-1] if "}" in el.tag else el.tag
            if tag == "FileName" and el.text:
                filename = el.text
            elif tag == "Size" and el.text:
                size = int(el.text)
        return filename, size

    async def download_file(self, file_id: int, file_type: str) -> bytes:
        """Download a complete file by ID and type.

        Flow: GetFileDownload → get filename + size → DownloadChunk in loop.
        """
        import base64

        filename, file_size = await self.get_file_info(file_id, file_type)
        if not filename or file_size == 0:
            return b""

        data = bytearray()
        offset = 0
        while offset < file_size:
            xml = await self._call(
                "wsFileDownload",
                "DownloadChunk",
                {
                    "FileName": filename,
                    "Offset": str(offset),
                },
            )
            chunk_b64 = parse_simple_response(xml, "DownloadChunk")
            if not chunk_b64:
                break
            data.extend(base64.b64decode(chunk_b64))
            offset = len(data)

        # Notify QT9 the download is complete
        try:
            await self._call(
                "wsFileDownload",
                "FileDownloaded",
                {"FileName": filename},
            )
        except Exception:
            pass  # Non-critical

        return bytes(data)

    # -----------------------------------------------------------------------
    # wsUser
    # -----------------------------------------------------------------------

    async def get_user_by_id(self, user_id: int) -> "UserRecord":
        from xml.etree import ElementTree as ET

        from .models import UserRecord

        xml = await self._call("wsUser", "GetUserRecordByID", {"UserID": str(user_id)})
        root = ET.fromstring(xml)
        for el in root.iter():
            tag = el.tag.split("}")[-1] if "}" in el.tag else el.tag
            if tag == "GetUserRecordByIDResult":
                obj: dict[str, str] = {}
                for child in el:
                    child_tag = (
                        child.tag.split("}")[-1] if "}" in child.tag else child.tag
                    )
                    obj[child_tag] = child.text or ""
                return UserRecord.from_object_dict(obj)
        # Fallback: try object-style response
        objects = parse_object_response(xml, "GetUserRecordByID", "QT9User")
        if objects:
            return UserRecord.from_object_dict(objects[0])
        return UserRecord()

    async def get_user_full_name(self, user_id: int) -> str:
        xml = await self._call(
            "wsUser", "GetUserFullNameByID", {"UserID": str(user_id)}
        )
        return parse_simple_response(xml, "GetUserFullNameByID")

    # -----------------------------------------------------------------------
    # High-level helper: read document content
    # -----------------------------------------------------------------------

    async def read_document_content(
        self, doc_id: int, include_images: bool = False
    ) -> "DocumentContent":
        import tempfile
        from pathlib import Path

        from .pdf import extract_text, extract_text_and_images

        pdf_bytes = await self.download_file(doc_id, "Document")
        if not pdf_bytes:
            from .models import DocumentContent

            return DocumentContent()
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp.write(pdf_bytes)
            tmp_path = Path(tmp.name)
        try:
            if include_images:
                return extract_text_and_images(tmp_path)
            else:
                return extract_text(tmp_path)
        finally:
            tmp_path.unlink(missing_ok=True)
