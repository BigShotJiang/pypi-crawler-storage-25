"""Smoke tests against real QT9 API. Skipped unless QT9 creds are set."""

import os
import pytest

from qt9_mcp.client import QT9SoapClient

QT9_URL = os.environ.get("QT9_URL", "https://medivis-co.qt9qms.app")
QT9_USERNAME = os.environ.get("QT9_USERNAME", "")
QT9_PASSWORD = os.environ.get("QT9_PASSWORD", "")

skip_no_creds = pytest.mark.skipif(
    not QT9_USERNAME or not QT9_PASSWORD,
    reason="QT9_USERNAME and QT9_PASSWORD not set",
)


@pytest.fixture
async def live_client():
    client = QT9SoapClient(QT9_URL, QT9_USERNAME, QT9_PASSWORD)
    yield client
    await client.close()


@skip_no_creds
async def test_hello_world_live(live_client):
    result = await live_client.hello_world()
    assert result == "Hello World"


@skip_no_creds
async def test_search_documents_live(live_client):
    docs = await live_client.get_documents_filtered(status="Current")
    assert len(docs) > 0
    assert docs[0].doc_code


@skip_no_creds
async def test_get_all_records_live(live_client):
    records = await live_client.get_all_records(
        "CAR", "1970-01-01T00:00:00", "9999-12-31T23:59:59"
    )
    assert len(records) > 0


@skip_no_creds
async def test_get_processes_live(live_client):
    processes = await live_client.get_processes()
    assert len(processes) > 0
    names = [p.process_name for p in processes]
    assert any("ISO" in n or "FDA" in n for n in names)
