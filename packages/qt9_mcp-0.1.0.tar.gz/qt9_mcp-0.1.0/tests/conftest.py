import pytest
import httpx
import respx

from qt9_mcp.client import QT9SoapClient


@pytest.fixture
def client():
    return QT9SoapClient(
        base_url="https://test.qt9qms.app",
        username="testuser",
        password="testpass",
    )


@pytest.fixture
def mock_api():
    with respx.mock(assert_all_called=False) as router:
        yield router
