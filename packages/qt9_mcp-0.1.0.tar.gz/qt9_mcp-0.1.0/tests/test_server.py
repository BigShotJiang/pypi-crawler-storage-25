from qt9_mcp.server import server, list_tools


async def test_list_tools():
    """Server exposes the expected tools."""
    tools = await list_tools()
    tool_names = [t.name for t in tools]
    assert "qt9_hello" in tool_names
    assert "qt9_search_documents" in tool_names
    assert "qt9_search_records" in tool_names
    assert "qt9_read_document_content" in tool_names
    assert "qt9_list_products" in tool_names
    assert "qt9_get_lookup_data" in tool_names
    assert len(tools) >= 19
