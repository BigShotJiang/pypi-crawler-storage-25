from qt9_mcp.exceptions import (
    QT9Error,
    QT9ConnectionError,
    QT9AuthError,
    QT9APIError,
    QT9NotFoundError,
)


def test_hierarchy():
    """All exceptions inherit from QT9Error."""
    assert issubclass(QT9ConnectionError, QT9Error)
    assert issubclass(QT9AuthError, QT9Error)
    assert issubclass(QT9APIError, QT9Error)
    assert issubclass(QT9NotFoundError, QT9Error)


def test_api_error_fields():
    """QT9APIError carries SOAP fault details."""
    err = QT9APIError("soap:Receiver", "Method not found")
    assert err.fault_code == "soap:Receiver"
    assert err.fault_string == "Method not found"
    assert "Method not found" in str(err)


def test_connection_error_message():
    err = QT9ConnectionError("Cannot reach medivis-co.qt9qms.app")
    assert "Cannot reach" in str(err)


def test_auth_error_message():
    err = QT9AuthError("Invalid credentials for user 'bwolffe'")
    assert "bwolffe" in str(err)
