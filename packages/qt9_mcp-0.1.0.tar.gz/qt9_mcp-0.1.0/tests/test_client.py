"""Tests for QT9SoapClient."""

import pytest
import httpx
import respx

from qt9_mcp.client import QT9SoapClient
from qt9_mcp.exceptions import QT9APIError, QT9ConnectionError
from qt9_mcp.models import DocumentSummary, IsoActionSummary, ProductSummary


# ---------------------------------------------------------------------------
# XML response fixtures
# ---------------------------------------------------------------------------

HELLO_WORLD_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <HelloWorldResponse xmlns="QT9.QMS.WebD.WS">
      <HelloWorldResult>Hello World</HelloWorldResult>
    </HelloWorldResponse>
  </soap:Body>
</soap:Envelope>"""

FAULT_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
  <soap:Body>
    <soap:Fault>
      <soap:Code><soap:Value>soap:Receiver</soap:Value></soap:Code>
      <soap:Reason><soap:Text xml:lang="en">Server was unable to process request.</soap:Text></soap:Reason>
    </soap:Fault>
  </soap:Body>
</soap:Envelope>"""

DOCUMENTS_FILTERED_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <GetDocumentsFilteredAsDataSetResponse xmlns="QT9.QMS.WebD.WS">
      <GetDocumentsFilteredAsDataSetResult>
        <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
          <xs:element name="NewDataSet" />
        </xs:schema>
        <diffgr:diffgram xmlns:diffgr="urn:schemas-microsoft-com:xml-diffgram-v1">
          <NewDataSet>
            <Table1 diffgr:id="Table11">
              <DocumentID>101</DocumentID>
              <DocumentCode>NY-401-SOP-1</DocumentCode>
              <DocumentName>Test SOP</DocumentName>
              <Rev._x0020__x0023_>A</Rev._x0020__x0023_>
              <Department>Engineering</Department>
              <DocType>SOP</DocType>
              <Status>Approved</Status>
              <SiteName>New York</SiteName>
            </Table1>
            <Table1 diffgr:id="Table12">
              <DocumentID>102</DocumentID>
              <DocumentCode>NY-401-WI-3</DocumentCode>
              <DocumentName>Work Instruction 3</DocumentName>
              <Rev._x0020__x0023_>B</Rev._x0020__x0023_>
              <Department>Operations</Department>
              <DocType>WI</DocType>
              <Status>Approved</Status>
              <SiteName>New York</SiteName>
            </Table1>
          </NewDataSet>
        </diffgr:diffgram>
      </GetDocumentsFilteredAsDataSetResult>
    </GetDocumentsFilteredAsDataSetResponse>
  </soap:Body>
</soap:Envelope>"""

ISO_ACTIONS_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <GetAllRecordsResponse xmlns="QT9.QMS.WebD.WS">
      <GetAllRecordsResult>
        <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
          <xs:element name="NewDataSet" />
        </xs:schema>
        <diffgr:diffgram xmlns:diffgr="urn:schemas-microsoft-com:xml-diffgram-v1">
          <NewDataSet>
            <Table1 diffgr:id="Table11">
              <RecordNumber>1001</RecordNumber>
              <problem>Nonconforming part received</problem>
              <Priority>High</Priority>
              <Status>Open</Status>
              <Product>OLO</Product>
              <Customer>Acme Corp</Customer>
              <Supplier>SupplierX</Supplier>
              <DateCreated>2026-01-15</DateCreated>
              <DateClosed></DateClosed>
              <DueDate>2026-02-15</DueDate>
            </Table1>
            <Table1 diffgr:id="Table12">
              <RecordNumber>1002</RecordNumber>
              <problem>Customer complaint</problem>
              <Priority>Medium</Priority>
              <Status>Closed</Status>
              <Product>HAW</Product>
              <Customer>Beta LLC</Customer>
              <Supplier></Supplier>
              <DateCreated>2026-01-20</DateCreated>
              <DateClosed>2026-02-01</DateClosed>
              <DueDate>2026-02-20</DueDate>
            </Table1>
          </NewDataSet>
        </diffgr:diffgram>
      </GetAllRecordsResult>
    </GetAllRecordsResponse>
  </soap:Body>
</soap:Envelope>"""

PRODUCTS_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <GetProductsAsListResponse xmlns="QT9.QMS.WebD.WS">
      <GetProductsAsListResult>
        <QT9Product>
          <ProductID>3</ProductID>
          <ProductName>JAK</ProductName>
          <PartNumber>JAK-001</PartNumber>
          <Description>JAK product</Description>
          <InActive>false</InActive>
        </QT9Product>
        <QT9Product>
          <ProductID>5</ProductID>
          <ProductName>HAW</ProductName>
          <PartNumber>HAW-001</PartNumber>
          <Description>HAW product</Description>
          <InActive>false</InActive>
        </QT9Product>
      </GetProductsAsListResult>
    </GetProductsAsListResponse>
  </soap:Body>
</soap:Envelope>"""


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_hello_world(client, mock_api):
    """hello_world() calls wsAppComp and returns 'Hello World'."""
    mock_api.post("https://test.qt9qms.app/services/wsAppComp.asmx").mock(
        return_value=httpx.Response(200, text=HELLO_WORLD_RESPONSE)
    )
    result = await client.hello_world()
    assert result == "Hello World"


@pytest.mark.asyncio
async def test_soap_fault_raises_api_error(client, mock_api):
    """A SOAP fault response raises QT9APIError with fault code and string."""
    mock_api.post("https://test.qt9qms.app/services/wsAppComp.asmx").mock(
        return_value=httpx.Response(200, text=FAULT_RESPONSE)
    )
    with pytest.raises(QT9APIError) as exc_info:
        await client.hello_world()
    assert "soap:Receiver" in str(exc_info.value)
    assert "unable to process" in str(exc_info.value)


@pytest.mark.asyncio
async def test_connection_error(client, mock_api):
    """A ConnectError from httpx raises QT9ConnectionError."""
    mock_api.post("https://test.qt9qms.app/services/wsAppComp.asmx").mock(
        side_effect=httpx.ConnectError("Connection refused")
    )
    with pytest.raises(QT9ConnectionError) as exc_info:
        await client.hello_world()
    assert "Cannot connect to" in str(exc_info.value)


@pytest.mark.asyncio
async def test_get_documents_filtered(client, mock_api):
    """get_documents_filtered() calls wsDocuments and returns list[DocumentSummary]."""
    mock_api.post("https://test.qt9qms.app/services/wsDocuments.asmx").mock(
        return_value=httpx.Response(200, text=DOCUMENTS_FILTERED_RESPONSE)
    )
    results = await client.get_documents_filtered()
    assert isinstance(results, list)
    assert len(results) == 2
    assert all(isinstance(r, DocumentSummary) for r in results)
    assert results[0].document_id == 101
    assert results[0].doc_code == "NY-401-SOP-1"
    assert results[0].doc_name == "Test SOP"
    assert results[0].revision == "A"
    assert results[1].document_id == 102
    assert results[1].doc_type == "WI"


@pytest.mark.asyncio
async def test_get_all_records(client, mock_api):
    """get_all_records() calls wsISOActions and returns list[IsoActionSummary]."""
    mock_api.post("https://test.qt9qms.app/services/wsISOActions.asmx").mock(
        return_value=httpx.Response(200, text=ISO_ACTIONS_RESPONSE)
    )
    results = await client.get_all_records(
        action_type="NCP",
        start_date="2026-01-01T00:00:00",
        end_date="2026-04-03T23:59:59",
    )
    assert isinstance(results, list)
    assert len(results) == 2
    assert all(isinstance(r, IsoActionSummary) for r in results)
    assert results[0].record_number == 1001
    assert results[0].problem == "Nonconforming part received"
    assert results[0].status == "Open"
    assert results[1].record_number == 1002
    assert results[1].status == "Closed"


@pytest.mark.asyncio
async def test_get_products(client, mock_api):
    """get_products() calls wsProducts and returns list[ProductSummary]."""
    mock_api.post("https://test.qt9qms.app/services/wsProducts.asmx").mock(
        return_value=httpx.Response(200, text=PRODUCTS_RESPONSE)
    )
    results = await client.get_products()
    assert isinstance(results, list)
    assert len(results) == 2
    assert all(isinstance(r, ProductSummary) for r in results)
    assert results[0].product_id == 3
    assert results[0].product_name == "JAK"
    assert results[0].part_number == "JAK-001"
    assert results[1].product_id == 5
    assert results[1].product_name == "HAW"
    assert results[1].inactive is False
