from xml.etree import ElementTree as ET

from qt9_mcp.xml_helpers import (
    build_envelope,
    parse_dataset_response,
    parse_object_response,
    parse_soap_fault,
    parse_simple_response,
)
from qt9_mcp.exceptions import QT9APIError
import pytest


def test_build_envelope_basic():
    """Envelope has correct SOAP 1.2 structure with auth header."""
    xml = build_envelope(
        username="testuser",
        password="testpass",
        method="HelloWorld",
        params={},
    )
    root = ET.fromstring(xml)
    ns = {"soap": "http://www.w3.org/2003/05/soap-envelope", "qt9": "QT9.QMS.WebD.WS"}
    header = root.find("soap:Header/qt9:wsAuthenticator", ns)
    assert header is not None
    assert header.find("qt9:UserName", ns).text == "testuser"
    assert header.find("qt9:Password", ns).text == "testpass"
    body = root.find("soap:Body/qt9:HelloWorld", ns)
    assert body is not None


def test_build_envelope_with_params():
    """Method-specific parameters are included in the body."""
    xml = build_envelope(
        username="u",
        password="p",
        method="GetAllRecords",
        params={
            "ActionType": "NCP",
            "StartDate": "2025-01-01T00:00:00",
            "EndDate": "2026-04-03T23:59:59",
        },
    )
    root = ET.fromstring(xml)
    ns = {"soap": "http://www.w3.org/2003/05/soap-envelope", "qt9": "QT9.QMS.WebD.WS"}
    method_el = root.find("soap:Body/qt9:GetAllRecords", ns)
    assert method_el.find("qt9:ActionType", ns).text == "NCP"
    assert method_el.find("qt9:StartDate", ns).text == "2025-01-01T00:00:00"


def test_build_envelope_escapes_xml_chars():
    """Special chars in password don't break XML."""
    xml = build_envelope(
        username="user",
        password="pass<>&\"'word",
        method="HelloWorld",
        params={},
    )
    ET.fromstring(xml)  # Should parse without error


DATASET_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <GetAllRecordsResponse xmlns="QT9.QMS.WebD.WS">
      <GetAllRecordsResult>
        <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
          <xs:element name="NewDataSet" />
        </xs:schema>
        <diffgr:diffgram xmlns:diffgr="urn:schemas-microsoft-com:xml-diffgram-v1">
          <NewDataSet>
            <Table1 diffgr:id="Table11">
              <RecordNumber>1</RecordNumber>
              <Status>Open</Status>
              <Product>OLO</Product>
            </Table1>
            <Table1 diffgr:id="Table12">
              <RecordNumber>2</RecordNumber>
              <Status>Closed</Status>
              <Product>HAW</Product>
            </Table1>
          </NewDataSet>
        </diffgr:diffgram>
      </GetAllRecordsResult>
    </GetAllRecordsResponse>
  </soap:Body>
</soap:Envelope>"""

OBJECT_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <GetProductsAsListResponse xmlns="QT9.QMS.WebD.WS">
      <GetProductsAsListResult>
        <QT9Product>
          <ProductID>3</ProductID>
          <ProductName>JAK</ProductName>
          <PartNumber></PartNumber>
          <InActive>false</InActive>
        </QT9Product>
        <QT9Product>
          <ProductID>5</ProductID>
          <ProductName>HAW</ProductName>
          <PartNumber>HAW-001</PartNumber>
          <InActive>false</InActive>
        </QT9Product>
      </GetProductsAsListResult>
    </GetProductsAsListResponse>
  </soap:Body>
</soap:Envelope>"""

FAULT_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
  <soap:Body>
    <soap:Fault>
      <soap:Code><soap:Value>soap:Receiver</soap:Value></soap:Code>
      <soap:Reason><soap:Text xml:lang="en">Server was unable to process request.</soap:Text></soap:Reason>
    </soap:Fault>
  </soap:Body>
</soap:Envelope>"""

SIMPLE_RESPONSE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    <HelloWorldResponse xmlns="QT9.QMS.WebD.WS">
      <HelloWorldResult>Hello World</HelloWorldResult>
    </HelloWorldResponse>
  </soap:Body>
</soap:Envelope>"""


def test_parse_dataset_response():
    rows = parse_dataset_response(DATASET_RESPONSE, "GetAllRecords")
    assert len(rows) == 2
    assert rows[0]["RecordNumber"] == "1"
    assert rows[0]["Status"] == "Open"
    assert rows[0]["Product"] == "OLO"
    assert rows[1]["RecordNumber"] == "2"


def test_parse_dataset_empty():
    empty_response = """<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
      <soap:Body>
        <GetAllRecordsResponse xmlns="QT9.QMS.WebD.WS">
          <GetAllRecordsResult>
            <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema" />
            <diffgr:diffgram xmlns:diffgr="urn:schemas-microsoft-com:xml-diffgram-v1">
              <NewDataSet />
            </diffgr:diffgram>
          </GetAllRecordsResult>
        </GetAllRecordsResponse>
      </soap:Body>
    </soap:Envelope>"""
    rows = parse_dataset_response(empty_response, "GetAllRecords")
    assert rows == []


def test_parse_object_response():
    objects = parse_object_response(OBJECT_RESPONSE, "GetProductsAsList", "QT9Product")
    assert len(objects) == 2
    assert objects[0]["ProductID"] == "3"
    assert objects[0]["ProductName"] == "JAK"
    assert objects[1]["PartNumber"] == "HAW-001"


def test_parse_soap_fault():
    with pytest.raises(QT9APIError) as exc_info:
        parse_soap_fault(FAULT_RESPONSE)
    assert "soap:Receiver" in str(exc_info.value)
    assert "unable to process" in str(exc_info.value)


def test_parse_soap_fault_no_fault():
    result = parse_soap_fault(DATASET_RESPONSE)
    assert result is None


def test_parse_simple_response():
    result = parse_simple_response(SIMPLE_RESPONSE, "HelloWorld")
    assert result == "Hello World"
