import json

from qt9_mcp.models import (
    DocumentSummary,
    DocumentDetail,
    IsoActionSummary,
    ECNSummary,
    ECRSummary,
    ProductSummary,
    CustomerSummary,
    FeedbackSummary,
    FMEARecord,
    InspectionSummary,
    ProcessSummary,
    UserRecord,
    DocumentContent,
)


def test_document_summary_from_dataset_row():
    row = {
        "DocumentID": "1083",
        "DocumentCode": "NY-301-QOP-",
        "DocumentName": "Acceptance Activities",
        "Rev._x0020__x0023_": "2",
        "Department": "Quality Assurance",
        "DocType": "Quality SOPs",
        "CurrentStatus": "4",
        "SiteName": "Site 1",
        "Status": "Active",
    }
    doc = DocumentSummary.from_dataset_row(row)
    assert doc.document_id == 1083
    assert doc.doc_code == "NY-301-QOP-"
    assert doc.doc_name == "Acceptance Activities"
    assert doc.revision == "2"
    assert doc.department == "Quality Assurance"
    assert doc.status == "Active"


def test_document_summary_serializes_to_json():
    doc = DocumentSummary(document_id=1, doc_code="NY-1", doc_name="Test")
    data = json.loads(doc.model_dump_json())
    assert data["doc_code"] == "NY-1"


def test_iso_action_summary_from_dataset_row():
    row = {
        "RecordNumber": "25",
        "problem": "Minor Finding (audit)",
        "Status": "Open",
        "Product": "OLO",
        "Priority": "High",
        "DateCreated": "2026-03-27T17:45:08",
    }
    record = IsoActionSummary.from_dataset_row(row)
    assert record.record_number == 25
    assert record.problem == "Minor Finding (audit)"
    assert record.status == "Open"


def test_product_summary_from_object_dict():
    obj = {
        "ProductID": "3",
        "ProductName": "JAK",
        "PartNumber": "",
        "Description": "FDA pro code JAK",
        "InActive": "false",
    }
    product = ProductSummary.from_object_dict(obj)
    assert product.product_id == 3
    assert product.product_name == "JAK"
    assert product.inactive is False


def test_document_content_model():
    content = DocumentContent(
        full_text="This is a test document.",
        page_count=3,
        references_found=["NY-301-QOP-1", "NY-401-DMR-2"],
        images=[],
    )
    assert content.page_count == 3
    assert len(content.references_found) == 2
