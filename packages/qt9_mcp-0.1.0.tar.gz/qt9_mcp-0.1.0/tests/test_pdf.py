from pathlib import Path

from qt9_mcp.pdf import extract_text, extract_text_and_images

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "sample.pdf"


def test_extract_text():
    result = extract_text(FIXTURE_PATH)
    assert "Test SOP" in result.full_text
    assert result.page_count == 1


def test_extract_references():
    result = extract_text(FIXTURE_PATH)
    assert "NY-301-QOP-15" in result.references_found
    assert "NY-401-DMR-2" in result.references_found


def test_extract_text_and_images():
    result = extract_text_and_images(FIXTURE_PATH)
    assert result.page_count == 1
    assert result.images == []  # No images in text-only fixture
