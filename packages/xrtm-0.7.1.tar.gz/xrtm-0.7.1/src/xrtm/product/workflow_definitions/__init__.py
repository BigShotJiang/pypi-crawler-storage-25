"""Builtin workflow blueprint definitions."""
