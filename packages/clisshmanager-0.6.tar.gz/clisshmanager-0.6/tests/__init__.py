"""Tests for sshman."""
