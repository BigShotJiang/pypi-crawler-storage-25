import contextlib
from typing import IO, Any

from azure.ai.documentintelligence import (
    DocumentIntelligenceAdministrationClient,
    DocumentIntelligenceClient,
)
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest, AnalyzeResult
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError, ResourceNotFoundError

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._base import AzureResourceBase, create_cached_resource

# Document Intelligence instance caching (bounded ring buffer, max 10)
_document_intelligence_instances: RingCache = RingCache(maxsize=10)


class AzureDocumentIntelligence(AzureResourceBase):
    """
    Azure AI Document Intelligence (formerly Form Recognizer) management.

    Provides standardized document analysis operations using the Azure AI
    Document Intelligence SDK with integrated logging, error handling, and
    OpenTelemetry tracing support.

    Attributes:
        endpoint: Azure Document Intelligence / AI Services endpoint URL
        service_name: Service identifier for logging and tracing
        service_version: Service version for context
        logger: AzureLogger instance for structured logging
        credential: Azure credential for authentication
        client: DocumentIntelligenceClient instance
        admin_client: DocumentIntelligenceAdministrationClient instance

    """

    def __init__(
        self,
        endpoint: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str = "azure_document_intelligence",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
        enable_analysis: bool = True,
        enable_administration: bool = False,
    ):
        """
        Initialize Azure Document Intelligence client.

        Args:
            endpoint: Document Intelligence endpoint URL
                (e.g., https://<resource>.cognitiveservices.azure.com/)
            credential: Azure credential for authentication
            azure_identity: AzureIdentity instance for credential management
            service_name: Service name for tracing context
            service_version: Service version for metadata
            logger: Optional AzureLogger instance
            connection_string: Application Insights connection string
            enable_analysis: Enable document analysis client
            enable_administration: Enable admin client for model management

        Raises:
            ValueError: If neither credential nor azure_identity is provided
            AzureError: If client initialization fails

        """
        super().__init__(
            credential=credential,
            azure_identity=azure_identity,
            service_name=service_name,
            service_version=service_version,
            logger=logger,
            connection_string=connection_string,
        )

        self.endpoint = endpoint
        self.enable_analysis = enable_analysis
        self.enable_administration = enable_administration

        self.client: DocumentIntelligenceClient | None = None
        self.admin_client: DocumentIntelligenceAdministrationClient | None = None

        self.logger.info(
            f"Azure Document Intelligence initialized for service '{service_name}' v{service_version}",
            extra={
                "endpoint": endpoint,
                "analysis_enabled": enable_analysis,
                "administration_enabled": enable_administration,
            },
        )

    def _ensure_client(self) -> DocumentIntelligenceClient:
        """Return the analysis client, constructing it lazily on first use."""
        if not self.enable_analysis:
            error_msg = "Document analysis not enabled. Set enable_analysis=True during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
        if self.client is None:
            self.client = DocumentIntelligenceClient(
                endpoint=self.endpoint,
                credential=self.credential,
            )
            self.logger.debug("DocumentIntelligenceClient lazily initialized on first use")
        return self.client

    def _ensure_admin_client(self) -> DocumentIntelligenceAdministrationClient:
        """Return the admin client, constructing it lazily on first use."""
        if not self.enable_administration:
            error_msg = "Document administration not enabled. Set enable_administration=True during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
        if self.admin_client is None:
            self.admin_client = DocumentIntelligenceAdministrationClient(
                endpoint=self.endpoint,
                credential=self.credential,
            )
            self.logger.debug("DocumentIntelligenceAdministrationClient lazily initialized on first use")
        return self.admin_client

    # ── Analysis Operations ───────────────────────────────────────

    def analyze_document_from_url(
        self,
        model_id: str,
        url_source: str,
        pages: str | None = None,
        locale: str | None = None,
        **kwargs: Any,
    ) -> AnalyzeResult:
        """
        Analyze a document from a publicly accessible URL.

        Args:
            model_id: Model ID (e.g., 'prebuilt-read', 'prebuilt-layout', 'prebuilt-invoice')
            url_source: URL of the document to analyze
            pages: Optional page range (e.g., '1-3,5')
            locale: Optional locale hint (e.g., 'en-US')
            **kwargs: Additional parameters passed to the SDK

        Returns:
            AnalyzeResult with extracted content, pages, tables, and entities

        Raises:
            RuntimeError: If client is not initialized
            AzureError: If analysis fails

        """
        with self.logger.create_span(
            "AzureDocumentIntelligence.analyze_document_from_url",
            attributes={
                "service.name": self.service_name,
                "operation.type": "document_analysis_url",
                "document_intelligence.model_id": model_id,
                "document_intelligence.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()

            try:
                self.logger.debug(
                    "Analyzing document from URL",
                    extra={"model_id": model_id, "url_source": url_source},
                )

                # The SDK accepts AnalyzeDocumentRequest at runtime even though
                # the type stub claims body is IO[bytes].
                poller = client.begin_analyze_document(  # type: ignore[call-overload]
                    model_id=model_id,
                    body=AnalyzeDocumentRequest(url_source=url_source),
                    pages=pages,
                    locale=locale,
                    **kwargs,
                )
                result: AnalyzeResult = poller.result()

                self.logger.info(
                    "Document analyzed successfully from URL",
                    extra={
                        "model_id": model_id,
                        "page_count": len(result.pages) if result.pages else 0,
                    },
                )
                return result

            except ClientAuthenticationError:
                self.logger.exception(
                    f"Authentication failed for document analysis with model '{model_id}'",
                    extra={"model_id": model_id},
                )
                raise
            except AzureError:
                self.logger.exception(
                    f"Failed to analyze document with model '{model_id}'",
                    extra={"model_id": model_id, "url_source": url_source},
                )
                raise

    def analyze_document_from_bytes(
        self,
        model_id: str,
        document: bytes | IO[bytes],
        pages: str | None = None,
        locale: str | None = None,
        content_type: str = "application/octet-stream",
        **kwargs: Any,
    ) -> AnalyzeResult:
        """
        Analyze a document from raw bytes or a binary stream.

        Args:
            model_id: Model ID (e.g., 'prebuilt-read', 'prebuilt-layout', 'prebuilt-invoice')
            document: Document bytes or binary file-like object
            pages: Optional page range (e.g., '1-3,5')
            locale: Optional locale hint (e.g., 'en-US')
            content_type: MIME type of the document (default: application/octet-stream)
            **kwargs: Additional parameters passed to the SDK

        Returns:
            AnalyzeResult with extracted content, pages, tables, and entities

        Raises:
            RuntimeError: If client is not initialized
            AzureError: If analysis fails

        """
        with self.logger.create_span(
            "AzureDocumentIntelligence.analyze_document_from_bytes",
            attributes={
                "service.name": self.service_name,
                "operation.type": "document_analysis_bytes",
                "document_intelligence.model_id": model_id,
                "document_intelligence.content_type": content_type,
                "document_intelligence.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()

            try:
                self.logger.debug(
                    "Analyzing document from bytes",
                    extra={"model_id": model_id, "content_type": content_type},
                )

                # The SDK accepts bytes at runtime even though the type stub
                # claims body is IO[bytes].
                poller = client.begin_analyze_document(  # type: ignore[call-overload, arg-type]
                    model_id=model_id,
                    body=document,  # type: ignore[arg-type]
                    pages=pages,
                    locale=locale,
                    content_type=content_type,
                    **kwargs,
                )
                result: AnalyzeResult = poller.result()

                self.logger.info(
                    "Document analyzed successfully from bytes",
                    extra={
                        "model_id": model_id,
                        "page_count": len(result.pages) if result.pages else 0,
                    },
                )
                return result

            except ClientAuthenticationError:
                self.logger.exception(
                    f"Authentication failed for document analysis with model '{model_id}'",
                    extra={"model_id": model_id},
                )
                raise
            except AzureError:
                self.logger.exception(
                    f"Failed to analyze document with model '{model_id}'",
                    extra={"model_id": model_id},
                )
                raise

    # ── Administration Operations ─────────────────────────────────

    def list_models(self, **kwargs: Any) -> list[dict[str, Any]]:
        """
        List all custom and prebuilt models in the Document Intelligence resource.

        Args:
            **kwargs: Additional parameters passed to the SDK

        Returns:
            List of model summary dicts

        Raises:
            RuntimeError: If admin client is not initialized
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureDocumentIntelligence.list_models",
            attributes={
                "service.name": self.service_name,
                "operation.type": "model_listing",
                "document_intelligence.endpoint": self.endpoint,
            },
        ):
            admin_client = self._ensure_admin_client()

            try:
                self.logger.debug("Listing Document Intelligence models")
                models = [model.as_dict() for model in admin_client.list_models(**kwargs)]
                self.logger.info(
                    "Models listed successfully",
                    extra={"model_count": len(models)},
                )
                return models
            except AzureError:
                self.logger.exception("Failed to list Document Intelligence models")
                raise

    def get_model(self, model_id: str) -> dict[str, Any] | None:
        """
        Get details for a specific model.

        Args:
            model_id: Model identifier

        Returns:
            Model details dict if found, None if not found

        Raises:
            RuntimeError: If admin client is not initialized
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureDocumentIntelligence.get_model",
            attributes={
                "service.name": self.service_name,
                "operation.type": "model_retrieval",
                "document_intelligence.model_id": model_id,
                "document_intelligence.endpoint": self.endpoint,
            },
        ):
            admin_client = self._ensure_admin_client()

            try:
                self.logger.debug("Retrieving model", extra={"model_id": model_id})
                model = admin_client.get_model(model_id=model_id)
                self.logger.info("Model retrieved successfully", extra={"model_id": model_id})
                return model.as_dict()
            except ResourceNotFoundError:
                self.logger.warning(f"Model '{model_id}' not found", extra={"model_id": model_id})
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve model '{model_id}'",
                    extra={"model_id": model_id},
                )
                raise

    def delete_model(self, model_id: str) -> bool:
        """
        Delete a custom model.

        Args:
            model_id: Model identifier

        Returns:
            True if deleted, False if not found

        Raises:
            RuntimeError: If admin client is not initialized
            AzureError: If deletion fails

        """
        with self.logger.create_span(
            "AzureDocumentIntelligence.delete_model",
            attributes={
                "service.name": self.service_name,
                "operation.type": "model_deletion",
                "document_intelligence.model_id": model_id,
                "document_intelligence.endpoint": self.endpoint,
            },
        ):
            admin_client = self._ensure_admin_client()

            try:
                self.logger.debug("Deleting model", extra={"model_id": model_id})
                admin_client.delete_model(model_id=model_id)
                self.logger.info("Model deleted successfully", extra={"model_id": model_id})
                return True
            except ResourceNotFoundError:
                self.logger.warning(
                    f"Model '{model_id}' not found for deletion",
                    extra={"model_id": model_id},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete model '{model_id}'",
                    extra={"model_id": model_id},
                )
                raise

    # ── Connection Test & Correlation ─────────────────────────────

    def test_connection(self) -> bool:
        """
        Test connection by issuing a no-op request to the service.

        Returns:
            True if connection is successful, False otherwise

        """
        with self.logger.create_span(
            "AzureDocumentIntelligence.test_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_test",
                "document_intelligence.endpoint": self.endpoint,
            },
        ):
            try:
                self.logger.debug("Testing Document Intelligence connection")

                if self.enable_administration:
                    list(self._ensure_admin_client().list_models())
                elif self.enable_analysis:
                    with contextlib.suppress(AzureError):
                        self._ensure_client().begin_analyze_document(  # type: ignore[call-overload, arg-type]
                            model_id="prebuilt-read",
                            body=b" ",  # type: ignore[arg-type]
                            content_type="application/octet-stream",
                        )
                else:
                    self.logger.error("No clients available for connection testing")
                    return False

                self.logger.info("Document Intelligence connection test successful")
                return True

            except AzureError as e:
                self.logger.warning(
                    f"Document Intelligence connection test failed: {e}",
                    extra={"endpoint": self.endpoint},
                )
                return False

def create_azure_document_intelligence(
    endpoint: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str = "azure_document_intelligence",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    enable_analysis: bool = True,
    enable_administration: bool = False,
) -> AzureDocumentIntelligence:
    """
    Factory function to create a cached AzureDocumentIntelligence instance.

    Returns existing instance if one with same configuration exists.
    Creates a default AzureIdentity if neither credential nor
    azure_identity is provided.

    """
    return create_cached_resource(
        AzureDocumentIntelligence,
        _document_intelligence_instances,
        (endpoint, service_name, service_version, connection_string, enable_analysis, enable_administration),
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        endpoint=endpoint,
        enable_analysis=enable_analysis,
        enable_administration=enable_administration,
    )
