"""
Azure resources package for azpaddypy.

This package contains modules for interacting with various Azure resources
including Key Vault, Storage, AI Projects, Document Intelligence, Speech,
and other Azure services.
"""

from .ai_project import AzureAIProject, create_azure_ai_project
from .document_intelligence import AzureDocumentIntelligence, create_azure_document_intelligence
from .keyvault import AzureKeyVault, create_azure_keyvault
from .speech import AzureSpeech, create_azure_speech
from .storage import AzureStorage, create_azure_storage

__all__ = [
    "AzureAIProject",
    "AzureDocumentIntelligence",
    "AzureKeyVault",
    "AzureSpeech",
    "AzureStorage",
    "create_azure_ai_project",
    "create_azure_document_intelligence",
    "create_azure_keyvault",
    "create_azure_speech",
    "create_azure_storage",
]
