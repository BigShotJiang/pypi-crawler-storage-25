"""
Shared utilities for Azure resource clients.

Provides common setup functions for credential and logger initialization
to reduce code duplication across resource classes (AzureStorage, AzureKeyVault, AzureCosmosDB).
"""

from azure.core.credentials import TokenCredential

from ..mgmt._utils import setup_logger
from ..mgmt.identity import AzureIdentity

__all__ = ["setup_credential", "setup_logger"]


def setup_credential(
    credential: TokenCredential | None,
    azure_identity: AzureIdentity | None,
) -> tuple[TokenCredential, AzureIdentity | None]:
    """
    Setup credential from either credential or azure_identity parameter.

    Args:
        credential: Optional Azure credential for authentication
        azure_identity: Optional AzureIdentity instance for credential management

    Returns:
        Tuple of (credential, azure_identity)

    Raises:
        ValueError: If neither credential nor azure_identity is provided

    """
    if azure_identity is not None:
        return azure_identity.get_credential(), azure_identity
    if credential is not None:
        return credential, None
    msg = "Either 'credential' or 'azure_identity' must be provided"
    raise ValueError(msg)
