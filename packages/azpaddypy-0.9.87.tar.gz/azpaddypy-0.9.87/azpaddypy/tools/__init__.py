"""
Azure tools package for azpaddypy.

This package contains utility tools for common Azure operations
including configuration management, data processing,
and other specialized tools.
"""

from .configuration_manager import ConfigurationManager, create_configuration_manager

__all__ = [
    "ConfigurationManager",
    "create_configuration_manager",
]
