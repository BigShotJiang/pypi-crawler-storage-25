"""
Azure configuration and builder patterns.

This module provides sophisticated builder patterns for orchestrating Azure services
with comprehensive configuration management and environment detection.
"""

from .configuration import (
    AzureConfiguration,
    AzureManagementBuilder,
    AzureManagementConfiguration,
    AzureResourceBuilder,
    AzureResourceConfiguration,
    ConfigurationSetupBuilder,
    EnvironmentConfiguration,
)

__all__ = [
    "AzureConfiguration",
    "AzureManagementBuilder",
    "AzureManagementConfiguration",
    "AzureResourceBuilder",
    "AzureResourceConfiguration",
    "ConfigurationSetupBuilder",
    "EnvironmentConfiguration",
]
