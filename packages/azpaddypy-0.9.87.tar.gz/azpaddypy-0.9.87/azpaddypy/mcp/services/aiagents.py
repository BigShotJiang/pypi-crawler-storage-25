import os
from typing import Any

from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import PromptAgentDefinition
from azure.core.exceptions import AzureError

from .base import AzureMCPError, get_context


def list_ai_foundry_projects() -> list[dict[str, Any]]:
    try:
        ctx = get_context()
        client = ctx.resource_client

        resources = list(client.resources.list(filter="resourceType eq 'Microsoft.CognitiveServices/accounts'"))

        ai_projects = []
        for resource in resources:
            resource_dict = resource.as_dict()
            resource_name = resource_dict.get("name", "")
            resource_location = resource_dict.get("location", "")
            resource_id = resource_dict.get("id", "")
            resource_group = resource_id.split("/")[4] if "/" in resource_id and len(resource_id.split("/")) > 4 else ""

            properties = resource_dict.get("properties", {})
            endpoint = properties.get("endpoint", "").rstrip("/")
            ai_project_endpoint = f"{endpoint}/api/projects/{resource_name}"
            ai_projects.append(
                {
                    "name": resource_name,
                    "resource_group": resource_group,
                    "location": resource_location,
                    "id": resource_id,
                    "type": resource_dict.get("type", ""),
                    "endpoint": endpoint,
                    "ai_project_endpoint": ai_project_endpoint,
                }
            )

        return ai_projects
    except AzureMCPError:
        raise
    except AzureError as e:
        msg = f"Failed to list AI Foundry projects: {e}"
        raise AzureMCPError(msg) from e


def _get_ai_project_client(project_endpoint: str | None = None) -> AIProjectClient:
    ctx = get_context()
    ctx.ensure_initialized()

    if project_endpoint is None:
        project_endpoint = os.getenv("AZURE_AI_FOUNDRY_PROJECT_ENDPOINT")

    if not project_endpoint:
        msg = (
            "AZURE_AI_FOUNDRY_PROJECT_ENDPOINT environment variable is required or must be provided as parameter. "
            "Example: https://<your_ai_service_name>.services.ai.azure.com/api/projects/<your_project_name>"
        )
        raise AzureMCPError(msg)

    try:
        return AIProjectClient(endpoint=project_endpoint, credential=ctx.credential)
    except AzureError as e:
        msg = f"Failed to create AI Project client: {e}"
        raise AzureMCPError(msg) from e


def _agent_details_to_dict(agent: Any) -> dict[str, Any]:
    """Convert an AgentDetails or AgentVersionDetails to a serializable dict."""
    result: dict[str, Any] = {
        "id": getattr(agent, "id", None),
        "name": getattr(agent, "name", None),
    }

    if hasattr(agent, "version"):
        result["version"] = agent.version

    if hasattr(agent, "description"):
        result["description"] = agent.description

    if hasattr(agent, "created_at"):
        result["created_at"] = agent.created_at.isoformat() if agent.created_at else None

    if hasattr(agent, "definition") and agent.definition is not None:
        definition = agent.definition
        result["model"] = getattr(definition, "model", None)
        result["instructions"] = getattr(definition, "instructions", None)
        result["kind"] = getattr(definition, "kind", None)

    if hasattr(agent, "versions"):
        result["versions"] = agent.versions

    return result


def list_ai_agents(ai_project_endpoint: str | None = None) -> list[dict[str, Any]]:
    try:
        client = _get_ai_project_client(ai_project_endpoint)
        agents = client.agents.list()

        return [_agent_details_to_dict(agent) for agent in agents]
    except AzureMCPError:
        raise
    except (AzureError, Exception) as e:
        msg = f"Failed to list AI agents: {e}"
        raise AzureMCPError(msg) from e


def get_ai_agent(name: str, ai_project_endpoint: str | None = None) -> dict[str, Any]:
    try:
        client = _get_ai_project_client(ai_project_endpoint)
        agent = client.agents.get(agent_name=name)

        result = _agent_details_to_dict(agent)
        result["available"] = True
        result["project_endpoint"] = ai_project_endpoint or os.getenv("AZURE_AI_FOUNDRY_PROJECT_ENDPOINT")
        return result
    except AzureMCPError:
        raise
    except AzureError as e:
        if "NotFound" in str(e) or "404" in str(e):
            return {"available": False, "message": f"No agent found with name: {name}"}
        msg = f"Failed to get AI agent: {e}"
        raise AzureMCPError(msg) from e


def create_ai_agent(
    name: str,
    model: str,
    instructions: str,
    ai_project_endpoint: str | None = None,
    description: str | None = None,
) -> dict[str, Any]:
    try:
        client = _get_ai_project_client(ai_project_endpoint)

        definition = PromptAgentDefinition(model=model, instructions=instructions)

        agent_version = client.agents.create_version(
            agent_name=name,
            definition=definition,
            description=description,
        )

        return _agent_details_to_dict(agent_version)
    except AzureMCPError:
        raise
    except (AzureError, Exception) as e:
        msg = f"Failed to create AI agent: {e}"
        raise AzureMCPError(msg) from e


def delete_ai_agent(agent_name: str, ai_project_endpoint: str | None = None) -> dict[str, Any]:
    try:
        client = _get_ai_project_client(ai_project_endpoint)

        client.agents.delete(agent_name=agent_name)

        return {"success": True, "message": f"Agent '{agent_name}' deleted successfully"}
    except AzureMCPError:
        raise
    except (AzureError, Exception) as e:
        msg = f"Failed to delete AI agent: {e}"
        raise AzureMCPError(msg) from e


def invoke_ai_agent(
    agent_name: str,
    user_message: str,
    ai_project_endpoint: str | None = None,
) -> dict[str, Any]:
    try:
        client = _get_ai_project_client(ai_project_endpoint)
        openai_client = client.get_openai_client()

        response = openai_client.responses.create(
            model="not-used",
            input=user_message,
            extra_body={
                "agent_reference": {
                    "name": agent_name,
                    "type": "agent_reference",
                },
            },
        )

        return {
            "success": True,
            "response_id": response.id,
            "status": response.status,
            "response": response.output_text,
        }
    except AzureMCPError:
        raise
    except (AzureError, Exception) as e:
        msg = f"Failed to invoke AI agent: {e}"
        raise AzureMCPError(msg) from e
