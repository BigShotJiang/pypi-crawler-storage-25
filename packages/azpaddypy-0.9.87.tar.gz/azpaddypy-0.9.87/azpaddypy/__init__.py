"""
AzPaddyPy - Azure configuration management with builder patterns.

A comprehensive Python package for Azure cloud services integration with
standardized configuration management, OpenTelemetry tracing, and builder patterns.

Key Features:
- Azure Identity management with token caching
- Azure Key Vault integration for secrets management
- Azure Storage operations (blob, file, queue)
- Azure AI Foundry Projects (agents, deployments, connections, evaluations, OpenAI client)
- Azure AI Document Intelligence (analyze documents, manage models)
- Azure Cognitive Services Speech (synthesis, recognition with Entra ID)
- Comprehensive logging with Application Insights
- AI Foundry tracing via dual instrumentation: opentelemetry-instrumentation-openai-v2
  for direct OpenAI SDK calls and azure.ai.projects AIProjectInstrumentor for
  Responses API / agent_reference calls. Opt-in prompt/completion content recording,
  W3C traceparent propagation, and scoped log export are all configurable on the
  AzureLogger constructor.
- Builder patterns for flexible service composition
- Environment detection and configuration management

Usage:
    # Direct imports (simplified)
    from azpaddypy import logger, identity, keyvault, storage_account, ai_project

    # Builder pattern (recommended for complex scenarios)
    from azpaddypy.builder import AzureManagementBuilder, AzureResourceBuilder, ConfigurationSetupBuilder
"""

from .builder import (
    AzureConfiguration,
    AzureManagementBuilder,
    AzureManagementConfiguration,
    AzureResourceBuilder,
    AzureResourceConfiguration,
    ConfigurationSetupBuilder,
    EnvironmentConfiguration,
)
from .mgmt import (
    AzureIdentity,
    AzureLogger,
    LocalDevelopmentSettings,
    create_local_env_manager,
)
from .resources import (
    AzureAIProject,
    AzureDocumentIntelligence,
    AzureKeyVault,
    AzureSpeech,
    AzureStorage,
    create_azure_ai_project,
    create_azure_document_intelligence,
    create_azure_keyvault,
    create_azure_speech,
    create_azure_storage,
)
from .tools import (
    ConfigurationManager,
    create_configuration_manager,
)

__all__ = [
    "AzureAIProject",
    "AzureConfiguration",
    "AzureDocumentIntelligence",
    "AzureIdentity",
    "AzureKeyVault",
    "AzureLogger",
    "AzureManagementBuilder",
    "AzureManagementConfiguration",
    "AzureResourceBuilder",
    "AzureResourceConfiguration",
    "AzureSpeech",
    "AzureStorage",
    "ConfigurationManager",
    "ConfigurationSetupBuilder",
    "EnvironmentConfiguration",
    "LocalDevelopmentSettings",
    "create_azure_ai_project",
    "create_azure_document_intelligence",
    "create_azure_keyvault",
    "create_azure_speech",
    "create_azure_storage",
    "create_configuration_manager",
    "create_local_env_manager",
]
