"""
Shared utilities for Azure management and resource clients.

Provides common setup functions for logger initialization
to reduce code duplication across management and resource classes.
"""

from .logging import AzureLogger


def setup_logger(
    logger: AzureLogger | None,
    service_name: str,
    service_version: str,
    connection_string: str | None,
) -> AzureLogger:
    """
    Setup logger with fallback to default creation.

    Args:
        logger: Optional existing AzureLogger instance
        service_name: Service name for tracing context
        service_version: Service version for metadata
        connection_string: Application Insights connection string

    Returns:
        AzureLogger instance (provided or newly created)

    """
    if logger is not None:
        return logger

    return AzureLogger(
        service_name=service_name,
        service_version=service_version,
        connection_string=connection_string,
        enable_console_logging=True,
    )
