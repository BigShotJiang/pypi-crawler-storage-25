import json
import logging
import os
import pathlib

logger = logging.getLogger(__name__)


class LocalDevelopmentSettings:
    """
    Manages loading of local development settings from .env and JSON files.

    This class provides a standardized way to load configuration from
    .env files and Azure Functions-style `local.settings.json` files into
    environment variables, making local development environments consistent
    with deployed Azure environments.

    It supports overriding existing environment variables and provides clear
    output for loaded settings.
    """

    def __init__(
        self,
        service_name: str = "local_dev_settings",
        service_version: str = "1.0.0",
    ):
        """
        Initializes the LocalDevelopmentSettings manager.

        Args:
            service_name: The name of the service using the settings manager.
            service_version: The version of the service.

        """
        self.service_name = service_name
        self.service_version = service_version
        logger.info("[%s] LocalDevelopmentSettings initialized.", self.service_name)

    def load_from_dotenv(self, dotenv_path: str | pathlib.Path, override: bool = False) -> bool:
        """
        Loads key-value pairs from a .env file into environment variables.

        Args:
            dotenv_path: The path to the .env file.
            override: If True, existing environment variables will be overwritten.

        Returns:
            True if the file was loaded successfully, False otherwise.

        """
        dotenv_path = pathlib.Path(dotenv_path)
        if not dotenv_path.is_file():
            logger.warning("[%s] .env file not found at %s. Skipping.", self.service_name, dotenv_path)
            return False

        try:
            with dotenv_path.open(encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    parts = line.split("=", 1)
                    if len(parts) != 2:
                        continue

                    key, value = parts[0].strip(), parts[1].strip()
                    value = value.strip('"').strip("'")

                    if key not in os.environ or override:
                        os.environ[key] = value
                        logger.debug("[%s] Loaded from .env: %s=%s...", self.service_name, key, value[:8])
                    else:
                        logger.debug("[%s] Skipping from .env (exists): %s", self.service_name, key)

            logger.info("[%s] Successfully loaded settings from %s", self.service_name, dotenv_path)
            return True
        except (OSError, UnicodeError):
            logger.exception("[%s] Error reading .env file at %s", self.service_name, dotenv_path)
            return False

    def load_from_json(self, json_path: str | pathlib.Path, override: bool = False) -> bool:
        """
        Loads settings from a JSON file (e.g., local.settings.json).

        The JSON file is expected to have a "Values" key containing a
        dictionary of settings.

        Args:
            json_path: The path to the JSON settings file.
            override: If True, existing environment variables will be overwritten.

        Returns:
            True if the file was loaded successfully, False otherwise.

        """
        json_path = pathlib.Path(json_path)
        if not json_path.is_file():
            logger.warning("[%s] JSON settings file not found at %s. Skipping.", self.service_name, json_path)
            return False

        try:
            with json_path.open(encoding="utf-8") as f:
                settings = json.load(f)

            if "Values" in settings and isinstance(settings["Values"], dict):
                for key, value in settings["Values"].items():
                    if key not in os.environ or override:
                        os.environ[key] = str(value)
                        logger.debug("[%s] Loaded from JSON: %s=%s...", self.service_name, key, str(value)[:8])
                    else:
                        logger.debug("[%s] Skipping from JSON (exists): %s", self.service_name, key)
                logger.info("[%s] Successfully loaded settings from %s", self.service_name, json_path)
                return True
            logger.warning("[%s] No 'Values' dictionary found in %s. Skipping.", self.service_name, json_path)
            return False
        except json.JSONDecodeError:
            logger.exception("[%s] Error decoding JSON from %s", self.service_name, json_path)
            return False
        except (OSError, UnicodeError):
            logger.exception("[%s] Error reading JSON file at %s", self.service_name, json_path)
            return False

    def apply_settings(self, settings: dict[str, str], override: bool = False) -> None:
        """
        Applies a dictionary of settings to the environment variables.

        Args:
            settings: A dictionary of key-value pairs to set as environment variables.
            override: If True, existing environment variables will be overwritten.

        """
        for key, value in settings.items():
            if key not in os.environ or override:
                os.environ[key] = str(value)
                logger.debug("[%s] Applied setting: %s=%s...", self.service_name, key, str(value)[:8])
            else:
                logger.debug("[%s] Skipping setting (exists): %s", self.service_name, key)
        logger.info("[%s] Applied %d settings to environment.", self.service_name, len(settings))

    def print_settings(self) -> None:
        """Prints all current environment variables (truncated values)."""
        for key, value in os.environ.items():
            logger.debug("[%s] Setting: %s=%s...", self.service_name, key, value[:8])


def create_local_env_manager(
    file_path: str | pathlib.Path = ".env",
    settings: dict[str, str] | None = None,
    override_json: bool = True,
    override_dotenv: bool = True,
    override_settings: bool = True,
) -> LocalDevelopmentSettings:
    """
    Convenience function to load settings from multiple sources.

    This function orchestrates loading settings from a `local.settings.json` file,
    a `.env` file, and a direct dictionary of settings, in that order.

    Args:
        file_path: Base path for `.env` or `local.settings.json`. The function
                   will look for both.
        settings: A dictionary of settings to apply.
        override_json: Whether settings from JSON should override existing env vars.
        override_dotenv: Whether settings from .env should override existing env vars.
        override_settings: Whether settings from the dictionary should override.

    """
    manager = LocalDevelopmentSettings()

    # Try loading local.settings.json
    json_path = pathlib.Path(file_path).parent / "local.settings.json"
    if json_path.is_file():
        manager.load_from_json(json_path, override=override_json)

    # Try loading .env
    dotenv_path = pathlib.Path(file_path)
    if dotenv_path.is_file() and dotenv_path.name == ".env":
        manager.load_from_dotenv(dotenv_path, override=override_dotenv)

    # Apply dictionary settings
    if settings:
        manager.apply_settings(settings, override=override_settings)

    return manager
