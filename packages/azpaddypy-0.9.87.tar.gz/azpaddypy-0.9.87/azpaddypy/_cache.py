"""Ring buffer cache with bounded size and FIFO eviction."""

from collections import OrderedDict
from typing import Any


class RingCache(OrderedDict):
    """
    Bounded cache that evicts the oldest entry when full.

    When the cache exceeds `maxsize`, the oldest (first-inserted)
    entry is removed, behaving like a ring buffer.

    Args:
        maxsize: Maximum number of entries (default 10).

    """

    def __init__(self, maxsize: int = 10) -> None:
        super().__init__()
        self._maxsize = maxsize

    def __setitem__(self, key: Any, value: Any) -> None:
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        while len(self) > self._maxsize:
            self.popitem(last=False)
