import os
from unittest.mock import MagicMock, patch

import pytest

from azpaddypy.mgmt.logging import AzureLogger


@pytest.fixture(
    params=["asyncio"],
)
def anyio_backend(request):
    """Force anyio to use asyncio backend."""
    return request.param


_GENAI_ENV_VARS = (
    "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT",
    "AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED",
    "AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION",
    "AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING",
)


@pytest.fixture(autouse=True)
def _cleanup_genai_env_vars():
    """
    Clear GenAI env vars before and after each test so ordering doesn't leak state.

    Note: APPLICATIONINSIGHTS_CONNECTION_STRING is assumed to be preset in the
    deployment environment; tests pass an explicit connection_string to avoid
    depending on the caller's real env.
    """
    for name in _GENAI_ENV_VARS:
        os.environ.pop(name, None)
    yield
    for name in _GENAI_ENV_VARS:
        os.environ.pop(name, None)


class TestGenAIInstrumentorActivation:
    """Test that OpenAIInstrumentor is activated during logger init."""

    def test_genai_instrumented_flag_set_when_package_available(self):
        """Verify _genai_instrumented is True when opentelemetry-instrumentation-openai-v2 is installed."""
        logger = AzureLogger(
            service_name="test_genai_flag",
            connection_string="InstrumentationKey=test",
        )
        assert logger._genai_instrumented is True

    def test_genai_instrumented_flag_false_when_import_fails(self):
        """Verify _genai_instrumented is False when the package is not available."""
        with patch.dict("sys.modules", {"opentelemetry.instrumentation.openai_v2": None}):
            with patch("builtins.__import__", side_effect=_make_import_blocker("opentelemetry.instrumentation.openai_v2")):
                logger = AzureLogger(
                    service_name="test_genai_missing",
                    connection_string="InstrumentationKey=test",
                )
                assert logger._genai_instrumented is False

    def test_instrumentor_flag_is_bool(self):
        """Verify the _genai_instrumented flag is set to a bool after init."""
        logger = AzureLogger(
            service_name="test_instrumentor_call",
            connection_string="InstrumentationKey=test",
        )
        assert isinstance(logger._genai_instrumented, bool)

    def test_idempotent_instrumentation(self):
        """Creating multiple loggers does not raise from double-instrumentation."""
        logger1 = AzureLogger(
            service_name="test_idempotent_1",
            connection_string="InstrumentationKey=test",
        )
        logger2 = AzureLogger(
            service_name="test_idempotent_2",
            connection_string="InstrumentationKey=test",
        )
        assert logger1._genai_instrumented is True
        assert logger2._genai_instrumented is True


class TestAIProjectInstrumentorActivation:
    """Test that AIProjectInstrumentor is activated during logger init when requested."""

    def test_ai_project_instrumentor_installed_by_default(self):
        """By default the AIProjectInstrumentor bootstrap runs (succeeds if package is present)."""
        logger = AzureLogger(
            service_name="test_aiproject_default",
            connection_string="InstrumentationKey=test",
        )
        # azure-ai-projects is a hard dep in pyproject.toml, so the bootstrap should succeed.
        assert logger._ai_project_instrumented is True

    def test_ai_project_instrumentor_opt_out(self):
        """install_ai_project_instrumentor=False skips the bootstrap entirely."""
        logger = AzureLogger(
            service_name="test_aiproject_opt_out",
            connection_string="InstrumentationKey=test",
            install_ai_project_instrumentor=False,
        )
        assert logger._ai_project_instrumented is False

    def test_ai_project_instrumentor_sets_feature_gate(self):
        """Installing AIProjectInstrumentor sets the AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING gate."""
        AzureLogger(
            service_name="test_aiproject_gate",
            connection_string="InstrumentationKey=test",
            install_ai_project_instrumentor=True,
        )
        assert os.environ.get("AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING") == "true"

    def test_ai_project_instrumentor_does_not_override_existing_gate(self):
        """A pre-existing feature-gate value is preserved (setdefault semantics)."""
        os.environ["AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING"] = "false"
        AzureLogger(
            service_name="test_aiproject_gate_preserve",
            connection_string="InstrumentationKey=test",
            install_ai_project_instrumentor=True,
        )
        assert os.environ["AZURE_EXPERIMENTAL_ENABLE_GENAI_TRACING"] == "false"

    def test_ai_project_instrumentor_import_failure_is_soft(self):
        """If azure.ai.projects.telemetry can't be imported, init still succeeds."""
        with patch.dict("sys.modules", {"azure.ai.projects.telemetry": None}):
            with patch("builtins.__import__", side_effect=_make_import_blocker("azure.ai.projects.telemetry")):
                logger = AzureLogger(
                    service_name="test_aiproject_missing",
                    connection_string="InstrumentationKey=test",
                )
                assert logger._ai_project_instrumented is False


class TestContentRecordingOptIn:
    """Test that capture_gen_ai_content=True sets the right env vars BEFORE instrumentation."""

    def test_default_does_not_set_content_recording_env_vars(self):
        """By default neither the OTel nor the Azure content recording env var is set."""
        AzureLogger(
            service_name="test_default_no_content",
            connection_string="InstrumentationKey=test",
        )
        assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") is None
        assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None

    def test_capture_gen_ai_content_sets_both_env_vars(self):
        """capture_gen_ai_content=True sets BOTH the OTel and Azure vars for mixed stacks."""
        AzureLogger(
            service_name="test_content_opt_in",
            connection_string="InstrumentationKey=test",
            capture_gen_ai_content=True,
        )
        # OTel upstream convention — honored by opentelemetry-instrumentation-openai-v2
        # and azure-ai-projects AIProjectInstrumentor.
        assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") == "true"
        # Legacy Azure-specific — honored by azure-ai-inference AIInferenceInstrumentor.
        assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") == "true"

    def test_capture_gen_ai_content_does_not_override_existing(self):
        """A pre-existing env var is preserved (setdefault semantics)."""
        os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] = "false"
        AzureLogger(
            service_name="test_content_preserve",
            connection_string="InstrumentationKey=test",
            capture_gen_ai_content=True,
        )
        assert os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] == "false"

    def test_log_result_true_no_longer_touches_env_vars(self):
        """log_result=True is now a span-attribute flag only; it must NOT set env vars."""
        logger = AzureLogger(
            service_name="test_log_result_isolated",
            connection_string="InstrumentationKey=test",
        )

        @logger.trace_function(log_result=True)
        def my_func():
            # During the function body, content recording env vars should still be unset
            # because capture_gen_ai_content=False (default) at construction time.
            assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") is None
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None
            return "result"

        result = my_func()
        assert result == "result"
        # And they must still be unset after the call returns.
        assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") is None
        assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None


class TestTracePropagationDefault:
    """Test that W3C trace context propagation to Azure OpenAI is on by default."""

    def test_default_enables_trace_propagation(self):
        """By default the propagation env var is set so server spans correlate."""
        AzureLogger(
            service_name="test_propagation_default",
            connection_string="InstrumentationKey=test",
        )
        assert os.environ.get("AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION") == "true"

    def test_opt_out_of_trace_propagation(self):
        """enable_gen_ai_trace_propagation=False leaves the env var unset."""
        AzureLogger(
            service_name="test_propagation_off",
            connection_string="InstrumentationKey=test",
            enable_gen_ai_trace_propagation=False,
        )
        assert os.environ.get("AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION") is None


class TestNonFoundryUsage:
    """
    Regression: the logger must work fine for apps that do not touch AI Foundry.

    Defaults install AIProjectInstrumentor, enable trace propagation, and set
    the experimental feature gate — but none of that should affect a plain
    Python app that logs messages and traces non-AI functions. The instrumentor
    only patches the OpenAI Responses API; non-Foundry apps never hit that code
    path, so installation must be silent and side-effect-free for them.
    """

    def test_default_logger_works_without_foundry_calls(self):
        """Default logger init succeeds and basic logging/tracing works."""
        logger = AzureLogger(
            service_name="test_non_foundry",
            connection_string="InstrumentationKey=test",
        )
        # Default opt-ins
        assert logger._ai_project_instrumented is True
        assert logger._genai_instrumented is True
        # Trace propagation enabled by default
        assert os.environ.get("AZURE_TRACING_GEN_AI_ENABLE_TRACE_CONTEXT_PROPAGATION") == "true"
        # Content recording stays off by default
        assert os.environ.get("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT") is None

        # Plain logging works
        logger.info("plain info message")
        logger.warning("plain warning")
        logger.debug("debug message")

        # trace_function on a non-AI function works
        @logger.trace_function()
        def compute(x: int, y: int) -> int:
            return x + y

        assert compute(2, 3) == 5

    @pytest.mark.anyio
    async def test_default_logger_async_trace_works_without_foundry(self):
        """Async trace_function works under the default instrumentor stack."""
        logger = AzureLogger(
            service_name="test_non_foundry_async",
            connection_string="InstrumentationKey=test",
        )

        @logger.trace_function()
        async def fetch_value() -> str:
            return "ok"

        result = await fetch_value()
        assert result == "ok"

    def test_default_logger_respects_preset_connection_string(self, monkeypatch):
        """
        When APPLICATIONINSIGHTS_CONNECTION_STRING is preset, logger picks it up.

        Azure Monitor validates the instrumentation key as a UUID, so use one.
        """
        preset = "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://example.com/"
        monkeypatch.setenv("APPLICATIONINSIGHTS_CONNECTION_STRING", preset)
        logger = AzureLogger(service_name="test_preset_conn_string")
        assert logger.connection_string == preset
        assert logger._telemetry_enabled is True


class TestTraceFunctionStillTracesResult:
    """Regression: log_result=True must still add result attributes to the span."""

    def test_log_result_true_still_captures_result_attributes(self):
        """log_result=True still captures function return value on the span."""
        logger = AzureLogger(
            service_name="test_trace_result",
            connection_string="InstrumentationKey=test",
        )

        mock_span = MagicMock()
        mock_tracer = MagicMock()
        mock_tracer.start_as_current_span.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_tracer.start_as_current_span.return_value.__exit__ = MagicMock(return_value=None)

        with patch.object(logger, "tracer", mock_tracer):

            @logger.trace_function(log_result=True)
            def my_func():
                return "traced_result"

            result = my_func()
            assert result == "traced_result"

            attrs = {
                call[0][0]: call[0][1]
                for call in mock_span.set_attribute.call_args_list
                if len(call[0]) == 2
            }
            assert attrs.get("function.decorator.log_result") is True
            assert attrs.get("function.has_result") is True
            assert attrs.get("function.result_type") == "str"

    def test_correlation_id_generated_on_first_trace(self):
        """Correlation ID auto-generation still works."""
        logger = AzureLogger(
            service_name="test_correlation_genai",
            connection_string="InstrumentationKey=test",
        )
        assert logger.get_correlation_id() is None

        @logger.trace_function()
        def my_func():
            return "result"

        my_func()
        assert logger.get_correlation_id() is not None


# ── Test helpers ────────────────────────────────────────────────────


def _make_import_blocker(blocked_module: str):
    """Create an __import__ replacement that blocks a specific module."""
    original_import = __import__

    def blocker(name, *args, **kwargs):
        if name == blocked_module:
            msg = f"Simulated missing module: {blocked_module}"
            raise ImportError(msg)
        return original_import(name, *args, **kwargs)

    return blocker
