from unittest.mock import MagicMock, Mock, patch

import pytest
from azure.core.credentials import TokenCredential
from azure.core.exceptions import (
    AzureError,
    ClientAuthenticationError,
    ResourceNotFoundError,
    ServiceRequestError,
)
from azure.cosmos import ContainerProxy, CosmosClient, DatabaseProxy

from azpaddypy.mgmt.identity import AzureIdentity
from azpaddypy.mgmt.logging import AzureLogger

# Import the module object directly, not just its members. Other test files
# (e.g. tests/test_builder.py::TestConfigurationLoading) nuke `sys.modules`
# entries for `azpaddypy.*` in their setup/teardown, which causes later
# string-based `patch("azpaddypy.resources.cosmosdb.CosmosClient", ...)` calls
# to target a FRESH module object, while `AzureCosmosDB` below is bound to the
# ORIGINAL module object from when this test file was first collected. The two
# diverge and string-based patches no longer affect `_setup_client`.
#
# Holding `_cosmos_module` here captures a direct reference to the original
# module so `patch.object(_cosmos_module, "CosmosClient", ...)` always
# modifies the attribute on the module `AzureCosmosDB` was actually defined
# in -- independent of `sys.modules` state.
from azpaddypy.resources import cosmosdb as _cosmos_module
from azpaddypy.resources.cosmosdb import AzureCosmosDB, create_azure_cosmosdb


@pytest.fixture
def mock_credential():
    """Mock TokenCredential for testing."""
    return Mock(spec=TokenCredential)


@pytest.fixture
def mock_azure_identity(mock_credential):
    """Mock AzureIdentity instance for testing."""
    mock_identity = Mock(spec=AzureIdentity)
    mock_identity.get_credential.return_value = mock_credential
    return mock_identity


@pytest.fixture
def mock_cosmos_client():
    """Mock CosmosClient instance."""
    client = Mock(spec=CosmosClient)
    db_proxy = Mock(spec=DatabaseProxy)
    container_proxy = Mock(spec=ContainerProxy)
    client.get_database_client.return_value = db_proxy
    db_proxy.get_container_client.return_value = container_proxy
    return client


@pytest.fixture
def azure_cosmosdb(mock_azure_identity, mock_cosmos_client):
    """Configured AzureCosmosDB instance for testing."""
    # Only patch AzureLogger here, CosmosClient is patched globally
    with patch("azpaddypy.resources.cosmosdb.AzureLogger") as mock_logger_class:
        mock_logger = Mock(spec=AzureLogger)
        mock_span = MagicMock()
        mock_context_manager = MagicMock()
        mock_context_manager.__enter__.return_value = mock_span
        mock_context_manager.__exit__.return_value = None
        mock_logger.create_span.return_value = mock_context_manager
        mock_logger_class.return_value = mock_logger

        return AzureCosmosDB(
            endpoint="https://test.documents.azure.com:443/",
            azure_identity=mock_azure_identity,
            service_name="test_cosmos_service",
            logger=mock_logger,
        )


class TestAzureCosmosDBInitialization:
    """Test AzureCosmosDB initialization."""

    def test_init_with_identity(self, mock_azure_identity):
        """Test successful initialization with AzureIdentity."""
        AzureCosmosDB(endpoint="https://test.documents.azure.com:443/", azure_identity=mock_azure_identity)
        mock_azure_identity.get_credential.assert_called_once()
        # CosmosClient is patched globally

    def test_init_no_credential_raises_error(self):
        """Test ValueError is raised when no credential is provided."""
        with pytest.raises(ValueError, match="Either 'credential' or 'azure_identity' must be provided"):
            AzureCosmosDB(endpoint="https://test.documents.azure.com:443/")


class TestAzureCosmosDBSyncOperations:
    """Test synchronous operations of AzureCosmosDB."""

    def test_get_database(self, azure_cosmosdb, mock_cosmos_client):
        """Test getting a database proxy."""
        azure_cosmosdb.get_database("test_db")

    def test_get_container(self, azure_cosmosdb, mock_cosmos_client):
        """Test getting a container proxy."""
        azure_cosmosdb.get_container("test_db", "test_container")
        # Removed isinstance(container, ContainerProxy) assertion

    def test_read_item(self, azure_cosmosdb):
        """Test reading an item."""
        container_proxy = azure_cosmosdb.get_container("db", "container")
        container_proxy.read_item.return_value = {"id": "1", "data": "test"}

        item = azure_cosmosdb.read_item("db", "container", "1", "pk1")

        container_proxy.read_item.assert_called_once_with(item="1", partition_key="pk1")
        assert item["id"] == "1"

    def test_read_item_with_caching(self, azure_cosmosdb):
        """Test reading an item with integrated cache option."""
        container_proxy = azure_cosmosdb.get_container("db", "container")
        azure_cosmosdb.read_item("db", "container", "1", "pk1", max_integrated_cache_staleness_in_ms=5000)
        container_proxy.read_item.assert_called_once_with(
            item="1", partition_key="pk1", max_integrated_cache_staleness_in_ms=5000
        )

    def test_read_item_not_found(self, azure_cosmosdb):
        """Test reading an item that does not exist."""
        container_proxy = azure_cosmosdb.get_container("db", "container")
        container_proxy.read_item.side_effect = ResourceNotFoundError

        item = azure_cosmosdb.read_item("db", "container", "1", "pk1")
        assert item is None
        azure_cosmosdb.logger.warning.assert_called_with("Item '1' not found.")

    def test_query_items(self, azure_cosmosdb):
        """Test querying items."""
        container_proxy = azure_cosmosdb.get_container("db", "container")
        container_proxy.query_items.return_value = [{"id": "1"}, {"id": "2"}]

        items = azure_cosmosdb.query_items("db", "container", "SELECT * FROM c")

        container_proxy.query_items.assert_called_once_with(
            query="SELECT * FROM c", parameters=None, enable_cross_partition_query=True
        )
        assert len(items) == 2

    def test_query_items_with_caching(self, azure_cosmosdb):
        """Test querying items with integrated cache option."""
        container_proxy = azure_cosmosdb.get_container("db", "container")
        container_proxy.query_items.return_value = []  # Set a return value to make it iterable
        azure_cosmosdb.query_items("db", "container", "SELECT * FROM c", max_integrated_cache_staleness_in_ms=10000)
        container_proxy.query_items.assert_called_once_with(
            query="SELECT * FROM c",
            parameters=None,
            enable_cross_partition_query=True,
            max_integrated_cache_staleness_in_ms=10000,
        )

    def test_upsert_item(self, azure_cosmosdb):
        """Test upserting an item."""
        container_proxy = azure_cosmosdb.get_container("db", "container")
        item_to_upsert = {"id": "1", "data": "new_data"}

        azure_cosmosdb.upsert_item("db", "container", item_to_upsert)
        container_proxy.upsert_item.assert_called_once_with(body=item_to_upsert)


@pytest.mark.asyncio
class TestAzureCosmosDBAsyncOperations:
    """Test asynchronous operations of AzureCosmosDB."""

    async def test_async_client_context(self, azure_cosmosdb, mock_credential):
        """Test the async client context manager."""
        # AsyncCosmosClient is patched globally
        async with azure_cosmosdb.async_client_context() as client:
            assert client is not None
        # No need to check mock_async_client_class, as it's globally patched


class TestAzureCosmosDBDeleteItem:
    """Test the delete_item method of AzureCosmosDB."""

    def test_delete_item_success(self, azure_cosmosdb):
        container_proxy = azure_cosmosdb.get_container("db", "container")
        # No exception means success
        result = azure_cosmosdb.delete_item("db", "container", "1", "pk1")
        container_proxy.delete_item.assert_called_once_with(item="1", partition_key="pk1")
        assert result is True

    def test_delete_item_not_found(self, azure_cosmosdb):
        container_proxy = azure_cosmosdb.get_container("db", "container")
        container_proxy.delete_item.side_effect = ResourceNotFoundError
        result = azure_cosmosdb.delete_item("db", "container", "1", "pk1")
        assert result is False
        azure_cosmosdb.logger.warning.assert_called_with("Item '1' not found for deletion.")

    def test_delete_item_error(self, azure_cosmosdb):
        container_proxy = azure_cosmosdb.get_container("db", "container")
        container_proxy.delete_item.side_effect = AzureError("Delete failed!")
        with pytest.raises(AzureError, match="Delete failed!"):
            azure_cosmosdb.delete_item("db", "container", "1", "pk1")
        azure_cosmosdb.logger.exception.assert_called()


class TestFactoryFunction:
    """Test the create_azure_cosmosdb factory function."""

    @patch("azpaddypy.resources.cosmosdb.AzureCosmosDB")
    def test_create_azure_cosmosdb(self, mock_cosmos_class, mock_azure_identity):
        """Test that the factory function creates an instance correctly."""
        create_azure_cosmosdb(
            endpoint="https://test.documents.azure.com:443/",
            azure_identity=mock_azure_identity,
            service_name="factory_service",
        )
        # You can add more specific assertions on the arguments if needed


# ── Purely-lazy construction tests ────────────────────────────────────────────
#
# CosmosClient is the only Azure SDK client in the azpaddypy stack that is
# eager at construction time — it performs endpoint discovery (an HTTP GET)
# during __init__. To avoid crashing module imports (e.g. mgmt_config.py) when
# the Cosmos account is not provisioned, AzureCosmosDB.__init__ does NOT
# construct CosmosClient at all. Construction is deferred to get_client(),
# matching the implicit lazy behavior of the other SDK clients.
#
# These tests lock in:
#   1. __init__ never calls CosmosClient — client is always None after init.
#   2. get_client() constructs lazily and caches on success.
#   3. get_client() surfaces the REAL SDK exception on failure (not a wrapper).
#   4. High-level methods (get_database, etc.) trigger the lazy path.


def _make_service_request_error() -> ServiceRequestError:
    """Build a ServiceRequestError that looks like a DNS failure."""
    return ServiceRequestError(
        message="HTTPSConnection(host='coscas-fake.documents.azure.com'): "
        "Failed to resolve 'coscas-fake.documents.azure.com' ([Errno 11001] getaddrinfo failed)"
    )


class TestAzureCosmosDBLazyInit:
    """__init__ never touches CosmosClient; client is None until first use."""

    def test_client_is_none_after_init(self, mock_azure_identity):
        """AzureCosmosDB.__init__ must not construct CosmosClient."""
        cdb = AzureCosmosDB(
            endpoint="https://coscas-fake.documents.azure.com:443/",
            azure_identity=mock_azure_identity,
            service_name="test_lazy_init",
        )
        assert cdb.client is None

    def test_init_does_not_call_cosmos_client(self, mock_azure_identity):
        """Verify CosmosClient is never called during __init__."""
        with patch.object(_cosmos_module, "CosmosClient") as mock_cc:
            AzureCosmosDB(
                endpoint="https://coscas-fake.documents.azure.com:443/",
                azure_identity=mock_azure_identity,
                service_name="test_no_init_call",
            )
            mock_cc.assert_not_called()


class TestAzureCosmosDBGetClient:
    """get_client() constructs lazily on first call; caches on success."""

    def test_first_call_constructs_and_caches(self, mock_azure_identity):
        """First get_client() constructs CosmosClient; subsequent calls return cached."""
        lazy_client = Mock(spec=CosmosClient)

        with patch.object(
            _cosmos_module, "CosmosClient", return_value=lazy_client
        ) as mock_cc:
            cdb = AzureCosmosDB(
                endpoint="https://coscas-real.documents.azure.com:443/",
                azure_identity=mock_azure_identity,
                service_name="test_lazy_construct",
            )
            assert cdb.client is None
            mock_cc.assert_not_called()

            got = cdb.get_client()
            assert got is lazy_client
            assert cdb.client is lazy_client  # cached
            mock_cc.assert_called_once()

            # Second call returns cached — no additional construction.
            got2 = cdb.get_client()
            assert got2 is lazy_client
            mock_cc.assert_called_once()

    def test_failure_surfaces_real_sdk_error(self, mock_azure_identity):
        """If CosmosClient construction fails, the REAL SDK exception propagates."""
        with patch.object(
            _cosmos_module,
            "CosmosClient",
            side_effect=_make_service_request_error(),
        ):
            cdb = AzureCosmosDB(
                endpoint="https://coscas-fake.documents.azure.com:443/",
                azure_identity=mock_azure_identity,
                service_name="test_lazy_fail",
            )
            with pytest.raises(ServiceRequestError) as exc_info:
                cdb.get_client()
            assert "Failed to resolve" in str(exc_info.value)
            # client stays None after a failed attempt — next call will retry.
            assert cdb.client is None

    def test_auth_error_surfaces(self, mock_azure_identity):
        """ClientAuthenticationError from CosmosClient propagates unchanged."""
        with patch.object(
            _cosmos_module,
            "CosmosClient",
            side_effect=ClientAuthenticationError(message="bad creds"),
        ):
            cdb = AzureCosmosDB(
                endpoint="https://coscas-fake.documents.azure.com:443/",
                azure_identity=mock_azure_identity,
                service_name="test_lazy_auth_fail",
            )
            with pytest.raises(ClientAuthenticationError, match="bad creds"):
                cdb.get_client()

    def test_retry_succeeds_after_prior_failure(self, mock_azure_identity):
        """A failed get_client() leaves client=None; next call retries successfully."""
        dns_err = _make_service_request_error()
        healthy_client = Mock(spec=CosmosClient)

        with patch.object(
            _cosmos_module,
            "CosmosClient",
            side_effect=[dns_err, healthy_client],
        ) as mock_cc:
            cdb = AzureCosmosDB(
                endpoint="https://coscas-fake.documents.azure.com:443/",
                azure_identity=mock_azure_identity,
                service_name="test_retry_after_fail",
            )
            # First attempt fails.
            with pytest.raises(ServiceRequestError):
                cdb.get_client()
            assert cdb.client is None
            assert mock_cc.call_count == 1

            # Second attempt succeeds and caches.
            got = cdb.get_client()
            assert got is healthy_client
            assert cdb.client is healthy_client
            assert mock_cc.call_count == 2

    def test_get_database_triggers_lazy_construction(self, mock_azure_identity):
        """High-level get_database() triggers get_client() → lazy construction."""
        lazy_client = Mock(spec=CosmosClient)
        db_proxy = Mock(spec=DatabaseProxy)
        lazy_client.get_database_client.return_value = db_proxy

        mock_logger = Mock(spec=AzureLogger)
        mock_logger.create_span.return_value = MagicMock()

        with patch.object(_cosmos_module, "CosmosClient", return_value=lazy_client):
            cdb = AzureCosmosDB(
                endpoint="https://coscas-real.documents.azure.com:443/",
                azure_identity=mock_azure_identity,
                service_name="test_lazy_via_get_database",
                logger=mock_logger,
            )
            assert cdb.client is None

            result = cdb.get_database("mydb")
            assert result is db_proxy
            assert cdb.client is lazy_client
            lazy_client.get_database_client.assert_called_once_with("mydb")
