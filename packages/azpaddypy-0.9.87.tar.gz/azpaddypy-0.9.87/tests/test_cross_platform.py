"""Tests for cross-platform environment variable loading behavior."""

import json
import os
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from azpaddypy.mgmt.local_env_manager import LocalDevelopmentSettings, create_local_env_manager

# --- UTF-8 encoding tests ---


class TestDotenvUtf8Encoding:
    """Verify .env files are always read as UTF-8, regardless of platform default encoding."""

    def test_load_dotenv_with_utf8_characters(self, tmp_path: Path) -> None:
        env_path = tmp_path / ".env"
        env_path.write_text('GRUSS="Gruesse"\nSTADT=Muenchen', encoding="utf-8")

        os.environ.pop("GRUSS", None)
        os.environ.pop("STADT", None)

        manager = LocalDevelopmentSettings()
        result = manager.load_from_dotenv(env_path)

        assert result is True
        assert os.environ["GRUSS"] == "Gruesse"
        assert os.environ["STADT"] == "Muenchen"

        os.environ.pop("GRUSS", None)
        os.environ.pop("STADT", None)

    def test_load_dotenv_with_unicode_characters(self, tmp_path: Path) -> None:
        env_path = tmp_path / ".env"
        env_path.write_text("EMOJI_KEY=hello-\u00e4\u00f6\u00fc\u00df\nJP_KEY=\u6771\u4eac", encoding="utf-8")

        os.environ.pop("EMOJI_KEY", None)
        os.environ.pop("JP_KEY", None)

        manager = LocalDevelopmentSettings()
        result = manager.load_from_dotenv(env_path)

        assert result is True
        assert os.environ["EMOJI_KEY"] == "hello-\u00e4\u00f6\u00fc\u00df"
        assert os.environ["JP_KEY"] == "\u6771\u4eac"

        os.environ.pop("EMOJI_KEY", None)
        os.environ.pop("JP_KEY", None)

    def test_load_dotenv_rejects_non_utf8_file(self, tmp_path: Path) -> None:
        env_path = tmp_path / ".env"
        env_path.write_bytes(b"KEY1=\xff\xfe invalid utf8")

        manager = LocalDevelopmentSettings()
        result = manager.load_from_dotenv(env_path)

        assert result is False


class TestJsonUtf8Encoding:
    """Verify JSON settings files are always read as UTF-8."""

    def test_load_json_with_utf8_characters(self, tmp_path: Path) -> None:
        json_path = tmp_path / "local.settings.json"
        content = json.dumps({"Values": {"REGION": "M\u00fcnchen", "NOTE": "\u00c4nderung"}})
        json_path.write_text(content, encoding="utf-8")

        os.environ.pop("REGION", None)
        os.environ.pop("NOTE", None)

        manager = LocalDevelopmentSettings()
        result = manager.load_from_json(json_path)

        assert result is True
        assert os.environ["REGION"] == "M\u00fcnchen"
        assert os.environ["NOTE"] == "\u00c4nderung"

        os.environ.pop("REGION", None)
        os.environ.pop("NOTE", None)

    def test_load_json_rejects_non_utf8_file(self, tmp_path: Path) -> None:
        json_path = tmp_path / "local.settings.json"
        json_path.write_bytes(b'{"Values": {"KEY": "\xff\xfe"}}')

        manager = LocalDevelopmentSettings()
        result = manager.load_from_json(json_path)

        assert result is False


# --- Settings dict gate fix tests ---


class TestSettingsDictAlwaysApplied:
    """Verify settings dict is applied even without .env or local.settings.json files."""

    def test_settings_applied_without_any_files(self, tmp_path: Path) -> None:
        nonexistent_env = tmp_path / ".env"
        settings = {"STANDALONE_KEY": "standalone_value"}

        os.environ.pop("STANDALONE_KEY", None)

        create_local_env_manager(file_path=str(nonexistent_env), settings=settings)

        assert os.environ["STANDALONE_KEY"] == "standalone_value"

        os.environ.pop("STANDALONE_KEY", None)

    def test_settings_applied_with_missing_json_and_env(self, tmp_path: Path) -> None:
        nonexistent_env = tmp_path / ".env"
        settings = {"ALPHA": "1", "BETA": "2"}

        os.environ.pop("ALPHA", None)
        os.environ.pop("BETA", None)

        create_local_env_manager(file_path=str(nonexistent_env), settings=settings)

        assert os.environ["ALPHA"] == "1"
        assert os.environ["BETA"] == "2"

        os.environ.pop("ALPHA", None)
        os.environ.pop("BETA", None)

    def test_settings_applied_alongside_dotenv(self, tmp_path: Path) -> None:
        env_path = tmp_path / ".env"
        env_path.write_text("FILE_KEY=file_value", encoding="utf-8")
        settings = {"DICT_KEY": "dict_value"}

        os.environ.pop("FILE_KEY", None)
        os.environ.pop("DICT_KEY", None)

        create_local_env_manager(file_path=str(env_path), settings=settings)

        assert os.environ["FILE_KEY"] == "file_value"
        assert os.environ["DICT_KEY"] == "dict_value"

        os.environ.pop("FILE_KEY", None)
        os.environ.pop("DICT_KEY", None)

    def test_settings_applied_alongside_json(self, tmp_path: Path) -> None:
        json_path = tmp_path / "local.settings.json"
        json_path.write_text(json.dumps({"Values": {"JSON_KEY": "json_value"}}), encoding="utf-8")

        env_path = tmp_path / ".env"
        settings = {"DICT_KEY": "dict_value"}

        os.environ.pop("JSON_KEY", None)
        os.environ.pop("DICT_KEY", None)

        create_local_env_manager(file_path=str(env_path), settings=settings)

        assert os.environ["JSON_KEY"] == "json_value"
        assert os.environ["DICT_KEY"] == "dict_value"

        os.environ.pop("JSON_KEY", None)
        os.environ.pop("DICT_KEY", None)

    def test_none_settings_with_no_files_does_not_crash(self, tmp_path: Path) -> None:
        nonexistent_env = tmp_path / ".env"
        manager = create_local_env_manager(file_path=str(nonexistent_env), settings=None)
        assert manager is not None


# --- Key Vault URI case sensitivity tests ---


class TestKeyVaultUriCaseSensitivity:
    """Verify KEY_VAULT_URI and key_vault_uri are both accepted for Key Vault lookup."""

    def _build_keyvault(self, env_vars: dict[str, str]) -> None:
        from azpaddypy.builder import AzureManagementBuilder, EnvironmentConfiguration
        from azpaddypy.mgmt.identity import AzureIdentity
        from azpaddypy.mgmt.logging import AzureLogger

        env_config = EnvironmentConfiguration(
            running_in_docker=False,
            local_settings={},
            local_env_manager=Mock(),
            service_name="test_service",
            service_version="1.0.0",
            reflection_kind="test",
            logger_enable_console=True,
            logger_connection_string=None,
            logger_instrumentation_options={},
            logger_log_level="INFO",
            identity_enable_token_cache=True,
            identity_allow_unencrypted_storage=True,
            identity_custom_credential_options=None,
            identity_connection_string=None,
        )

        with (
            patch("azpaddypy.builder.configuration.create_app_logger") as mock_logger,
            patch("azpaddypy.builder.configuration.create_azure_identity") as mock_identity,
            patch("azpaddypy.builder.configuration.create_azure_keyvault") as mock_keyvault,
            patch.dict(os.environ, env_vars, clear=False),
        ):
            mock_logger.return_value = Mock(spec=AzureLogger)
            mock_identity.return_value = Mock(spec=AzureIdentity)
            mock_keyvault.return_value = Mock()

            config = (
                AzureManagementBuilder(env_config)
                .with_logger()
                .with_identity()
                .with_keyvault("default")
                .build()
            )

            assert len(config.keyvaults) == 1
            return mock_keyvault.call_args[1]["vault_url"]

    def test_uppercase_key_vault_uri(self) -> None:
        url = self._build_keyvault({"KEY_VAULT_URI": "https://upper.vault.azure.net/"})
        assert url == "https://upper.vault.azure.net/"

    def test_lowercase_key_vault_uri(self) -> None:
        url = self._build_keyvault({"key_vault_uri": "https://lower.vault.azure.net/"})
        assert url == "https://lower.vault.azure.net/"

    @pytest.mark.skipif(os.name == "nt", reason="Windows os.environ is case-insensitive")
    def test_uppercase_takes_precedence_over_lowercase(self) -> None:
        url = self._build_keyvault({
            "KEY_VAULT_URI": "https://upper-wins.vault.azure.net/",
            "key_vault_uri": "https://lower-loses.vault.azure.net/",
        })
        assert url == "https://upper-wins.vault.azure.net/"


# --- Docker detection cross-platform tests ---


class TestDockerDetectionCrossPlatform:
    """Verify _is_running_in_docker behavior across simulated platforms."""

    def test_returns_true_when_dockerenv_exists(self) -> None:
        from azpaddypy.builder import ConfigurationSetupBuilder

        with patch.object(Path, "exists", return_value=True):
            assert ConfigurationSetupBuilder._is_running_in_docker() is True

    def test_returns_true_when_cgroup_contains_docker(self) -> None:
        from azpaddypy.builder import ConfigurationSetupBuilder

        mock_file = Mock()
        mock_file.__enter__ = Mock(return_value=mock_file)
        mock_file.__exit__ = Mock(return_value=False)
        mock_file.read = Mock(return_value="12:memory:/docker/abc123")

        with (
            patch.object(Path, "exists", return_value=False),
            patch.object(Path, "open", return_value=mock_file),
        ):
            assert ConfigurationSetupBuilder._is_running_in_docker() is True

    def test_returns_true_when_cgroup_contains_kubepods(self) -> None:
        from azpaddypy.builder import ConfigurationSetupBuilder

        mock_file = Mock()
        mock_file.__enter__ = Mock(return_value=mock_file)
        mock_file.__exit__ = Mock(return_value=False)
        mock_file.read = Mock(return_value="12:memory:/kubepods/burstable/pod-xyz")

        with (
            patch.object(Path, "exists", return_value=False),
            patch.object(Path, "open", return_value=mock_file),
        ):
            assert ConfigurationSetupBuilder._is_running_in_docker() is True

    def test_returns_false_when_no_docker_indicators(self) -> None:
        from azpaddypy.builder import ConfigurationSetupBuilder

        mock_file = Mock()
        mock_file.__enter__ = Mock(return_value=mock_file)
        mock_file.__exit__ = Mock(return_value=False)
        mock_file.read = Mock(return_value="12:memory:/user.slice/user-1000.slice")

        with (
            patch.object(Path, "exists", return_value=False),
            patch.object(Path, "open", return_value=mock_file),
        ):
            assert ConfigurationSetupBuilder._is_running_in_docker() is False

    def test_returns_false_when_cgroup_not_found(self) -> None:
        """Simulates Windows/macOS where /proc/1/cgroup does not exist."""
        from azpaddypy.builder import ConfigurationSetupBuilder

        with (
            patch.object(Path, "exists", return_value=False),
            patch.object(Path, "open", side_effect=FileNotFoundError),
        ):
            assert ConfigurationSetupBuilder._is_running_in_docker() is False

    def test_returns_false_when_permission_denied(self) -> None:
        """Simulates restricted environments where cgroup is not readable."""
        from azpaddypy.builder import ConfigurationSetupBuilder

        with (
            patch.object(Path, "exists", return_value=False),
            patch.object(Path, "open", side_effect=PermissionError),
        ):
            assert ConfigurationSetupBuilder._is_running_in_docker() is False
