from unittest.mock import MagicMock, patch

import pytest
from azure.core.credentials import TokenCredential
from azure.core.exceptions import ResourceNotFoundError

from azpaddypy.resources.storage import AzureStorage, create_azure_storage


@pytest.fixture
def mock_azure_identity():
    """Fixture to mock AzureIdentity, providing a mock credential object."""
    mock = MagicMock()
    mock.get_credential.return_value = MagicMock()
    return mock


class TestAzureStorageInitialization:
    """Test suite for AzureStorage initialization and setup."""

    def test_initialization_with_identity(self, mock_azure_identity):
        """
        Tests that AzureStorage initializes correctly when provided with an AzureIdentity instance.

        This test verifies that when an AzureIdentity object is passed during instantiation,
        the AzureStorage client correctly initializes all its service clients (blob, file, queue)
        and sets up the logger appropriately. It ensures the fundamental setup of the class
        works as expected with identity-based authentication.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            service_name="test_storage_service",
        )
        assert storage.account_url == "https://testaccount.blob.core.windows.net"
        assert storage.service_name == "test_storage_service"
        assert storage.logger is not None
        assert storage.blob_service_client is None  # Lazy: constructed on first use
        assert storage.queue_service_client is None  # Lazy: constructed on first use

    def test_initialization_with_credential(self):
        """
        Tests that AzureStorage initializes correctly when a direct credential object is provided.

        This test ensures that if a credential object (like one from `azure-identity`) is passed
        directly to the AzureStorage constructor, it is properly stored and used to initialize
        the necessary service clients. This validates an alternative initialization path to using
        the AzureIdentity class.
        """
        mock_credential = MagicMock()
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            credential=mock_credential,
        )
        assert storage.credential == mock_credential
        assert storage.blob_service_client is None  # Lazy: constructed on first use

    def test_initialization_no_credential_raises_error(self):
        """
        Tests that AzureStorage raises a ValueError if neither a credential nor an AzureIdentity
        instance is provided, ensuring proper authentication setup.

        This test validates the robustness of the AzureStorage constructor by confirming that it
        raises a `ValueError` when no authentication method is supplied. This is critical to prevent
        the creation of a non-functional storage client.
        """
        with pytest.raises(ValueError, match="Either 'credential' or 'azure_identity' must be provided"):
            AzureStorage(account_url="https://testaccount.blob.core.windows.net")


class TestAzureStorageBlobOperations:
    """Test suite for Azure Blob Storage operations (upload, download, delete, list, metadata)."""

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upload_blob_success(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests the successful upload of a blob.

        This test mocks the `BlobServiceClient` to simulate a successful upload operation.
        It verifies that the `upload_blob` method correctly identifies the blob client
        for the specified container and blob, and calls the `upload_blob` method on it
        with the correct data, ensuring the end-to-end flow of a successful upload.
        """
        mock_blob_client = MagicMock()
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        # Manually assign the mocked client
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.upload_blob(container_name="test-container", blob_name="test.txt", data=b"hello world")

        assert result is True
        mock_blob_service_client.return_value.get_blob_client.assert_called_once_with(
            container="test-container", blob="test.txt"
        )
        mock_blob_client.upload_blob.assert_called_once()

    def test_upload_blob_no_client_raises_error(self, mock_azure_identity):
        """
        Tests that uploading a blob raises a RuntimeError if the blob service client
        was not initialized, for example, if enable_blob_storage was set to False.

        This test ensures that if the `AzureStorage` class is initialized with blob storage
        disabled, any attempt to call `upload_blob` will result in a `RuntimeError`. This
        confirms that the method correctly checks for the availability of the blob service
        client before proceeding.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_blob_storage=False,
        )

        with pytest.raises(RuntimeError, match="Blob storage not enabled"):
            storage.upload_blob(container_name="test-container", blob_name="test.txt", data=b"hello")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_download_blob_success(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests the successful download of a blob. Mocks the BlobServiceClient and the
        download operation to return specific data, then asserts the data is correct.
        """
        mock_blob_client = MagicMock()
        mock_download_stream = MagicMock()
        mock_download_stream.readall.return_value = b"file content"
        mock_blob_client.download_blob.return_value = mock_download_stream
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        data = storage.download_blob(container_name="test-container", blob_name="test.txt")

        assert data == b"file content"
        mock_blob_client.download_blob.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_download_blob_not_found(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests that downloading a non-existent blob returns None and logs the
        appropriate message without raising an error.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.download_blob.side_effect = ResourceNotFoundError("Blob not found")
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        data = storage.download_blob(container_name="test-container", blob_name="nonexistent.txt")

        assert data is None

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_delete_blob_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests the successful deletion of a blob."""
        mock_blob_client = MagicMock()
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.delete_blob(container_name="test-container", blob_name="test.txt")

        assert result is True
        mock_blob_client.delete_blob.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_blob_exists(self, mock_blob_service_client, mock_azure_identity):
        """Tests that blob_exists returns True when a blob exists."""
        mock_blob_client = MagicMock()
        mock_blob_client.exists.return_value = True
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        assert storage.blob_exists(container_name="test-container", blob_name="test.txt") is True

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_blob_does_not_exist(self, mock_blob_service_client, mock_azure_identity):
        """Tests that blob_exists returns False when a blob does not exist."""
        mock_blob_client = MagicMock()
        mock_blob_client.exists.return_value = False
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        assert storage.blob_exists(container_name="test-container", blob_name="nonexistent.txt") is False

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_list_blobs_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests successfully listing blobs in a container."""
        mock_container_client = MagicMock()
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client

        # Mock the return of list_blobs to be a list of objects with a .name attribute
        mock_blob_1 = MagicMock()
        mock_blob_1.name = "blob1.txt"
        mock_blob_2 = MagicMock()
        mock_blob_2.name = "blob2.txt"
        mock_container_client.list_blobs.return_value = [mock_blob_1, mock_blob_2]

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        blobs = storage.list_blobs(container_name="test-container")

        assert blobs == ["blob1.txt", "blob2.txt"]
        mock_container_client.list_blobs.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_delete_blobs_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests the successful deletion of multiple blobs via SDK batch API."""
        mock_container_client = MagicMock()
        # SDK batch delete returns an iterator of results (None for success)
        mock_container_client.delete_blobs.return_value = [None, None]
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        results = storage.delete_blobs(container_name="test-container", blob_names=["blob1.txt", "blob2.txt"])

        assert results == {"blob1.txt": True, "blob2.txt": True}
        mock_container_client.delete_blobs.assert_called_once_with("blob1.txt", "blob2.txt")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upsert_blob_metadata_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests the successful upsert of blob metadata."""
        mock_blob_client = MagicMock()
        mock_blob_properties = MagicMock()
        mock_blob_properties.metadata = {}
        mock_blob_client.get_blob_properties.return_value = mock_blob_properties
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        storage.upsert_blob_metadata(container_name="test-container", blob_name="test.txt", metadata={"key": "value"})

        mock_blob_client.set_blob_metadata.assert_called_once_with(metadata={"key": "value"})

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upsert_blob_metadata_with_none_existing(self, mock_blob_service_client, mock_azure_identity):
        """Tests that upsert_blob_metadata handles None existing metadata without crashing."""
        mock_blob_client = MagicMock()
        mock_blob_properties = MagicMock()
        mock_blob_properties.metadata = None
        mock_blob_client.get_blob_properties.return_value = mock_blob_properties
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        storage.upsert_blob_metadata(container_name="test-container", blob_name="test.txt", metadata={"key": "value"})

        mock_blob_client.set_blob_metadata.assert_called_once_with(metadata={"key": "value"})

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upload_blob_with_sas_string_data(self, mock_blob_service_client, mock_azure_identity):
        """Tests that upload_blob_with_sas correctly encodes string data to bytes."""
        mock_blob_client = MagicMock()
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            account_key="ZmFrZV9rZXk=",
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        storage.upload_blob_with_sas(container_name="container", blob_name="test.txt", data="hello string")

        call_args = mock_blob_client.upload_blob.call_args
        assert call_args[0][0] == b"hello string"


class TestAzureStorageAppendBlobOperations:
    """Test suite for Azure Append Blob operations (create, append, convenience methods)."""

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_create_append_blob_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests successful creation of an append blob."""
        mock_container_client = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.create_append_blob(container_name="test-container", blob_name="log.txt")

        assert result is True
        mock_blob_service_client.return_value.get_container_client.assert_called_once_with(
            container="test-container"
        )
        mock_append_blob_client.create_append_blob.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_create_append_blob_with_content_type(self, mock_blob_service_client, mock_azure_identity):
        """Tests that content_type is passed as ContentSettings during creation."""
        mock_container_client = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.create_append_blob(
            container_name="test-container",
            blob_name="log.txt",
            content_type="text/plain",
        )

        assert result is True
        call_kwargs = mock_append_blob_client.create_append_blob.call_args
        assert call_kwargs.kwargs["content_settings"] is not None

    def test_create_append_blob_no_client_raises_error(self, mock_azure_identity):
        """Tests that creating an append blob without initialized client raises RuntimeError."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_blob_storage=False,
        )

        with pytest.raises(RuntimeError, match="Blob storage not enabled"):
            storage.create_append_blob(container_name="test-container", blob_name="log.txt")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_append_block_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests successful appending of a block to an append blob."""
        mock_container_client = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_append_blob_client.append_block.return_value = {"blob_append_offset": 42}
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.append_block(
            container_name="test-container",
            blob_name="log.txt",
            data=b"log line 1\n",
        )

        assert result == 42
        mock_append_blob_client.append_block.assert_called_once_with(
            data=b"log line 1\n", length=11
        )

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_append_block_string_data(self, mock_blob_service_client, mock_azure_identity):
        """Tests that string data is encoded to bytes before appending."""
        mock_container_client = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_append_blob_client.append_block.return_value = {"blob_append_offset": 0}
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        storage.append_block(
            container_name="test-container",
            blob_name="log.txt",
            data="hello text",
        )

        call_args = mock_append_blob_client.append_block.call_args
        assert call_args.kwargs["data"] == b"hello text"
        assert call_args.kwargs["length"] == 10

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_append_block_not_found_raises(self, mock_blob_service_client, mock_azure_identity):
        """Tests that appending to a non-existent blob raises ResourceNotFoundError."""
        mock_container_client = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_append_blob_client.append_block.side_effect = ResourceNotFoundError("Blob not found")
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        with pytest.raises(ResourceNotFoundError):
            storage.append_block(
                container_name="test-container",
                blob_name="nonexistent.txt",
                data=b"data",
            )

    def test_append_block_no_client_raises_error(self, mock_azure_identity):
        """Tests that appending a block without initialized client raises RuntimeError."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_blob_storage=False,
        )

        with pytest.raises(RuntimeError, match="Blob storage not enabled"):
            storage.append_block(container_name="test-container", blob_name="log.txt", data=b"data")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_append_blob_from_text_creates_and_appends(self, mock_blob_service_client, mock_azure_identity):
        """Tests that append_blob_from_text creates the blob when it does not exist and appends text."""
        mock_container_client = MagicMock()
        mock_blob_client = MagicMock()
        # get_blob_properties raises ResourceNotFoundError -> blob does not exist
        mock_blob_client.get_blob_properties.side_effect = ResourceNotFoundError("Not found")
        # append_block returns offset
        mock_append_blob_client = MagicMock()
        mock_append_blob_client.append_block.return_value = {"blob_append_offset": 0}

        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.append_blob_from_text(
            container_name="test-container",
            blob_name="log.txt",
            text="first line\n",
        )

        assert result is True
        mock_append_blob_client.create_append_blob.assert_called_once()
        mock_append_blob_client.append_block.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_append_blob_from_text_skips_creation_when_exists(self, mock_blob_service_client, mock_azure_identity):
        """Tests that append_blob_from_text skips creation when blob already exists."""
        mock_container_client = MagicMock()
        mock_blob_client = MagicMock()
        # get_blob_properties succeeds -> blob exists
        mock_blob_client.get_blob_properties.return_value = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_append_blob_client.append_block.return_value = {"blob_append_offset": 100}

        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.append_blob_from_text(
            container_name="test-container",
            blob_name="log.txt",
            text="another line\n",
        )

        assert result is True
        mock_append_blob_client.create_append_blob.assert_not_called()
        mock_append_blob_client.append_block.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_append_blob_from_text_no_auto_create(self, mock_blob_service_client, mock_azure_identity):
        """Tests append_blob_from_text with create_if_not_exists=False skips existence check."""
        mock_container_client = MagicMock()
        mock_append_blob_client = MagicMock()
        mock_append_blob_client.append_block.return_value = {"blob_append_offset": 0}
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client
        mock_container_client.get_blob_client.return_value = mock_append_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        result = storage.append_blob_from_text(
            container_name="test-container",
            blob_name="log.txt",
            text="line\n",
            create_if_not_exists=False,
        )

        assert result is True
        # Should not check properties or create
        mock_blob_service_client.return_value.get_blob_client.assert_not_called()
        mock_append_blob_client.append_block.assert_called_once()


class TestAzureStorageQueueOperations:
    """Test suite for Azure Queue Storage operations (send, receive, delete messages)."""

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_send_message_success(self, mock_queue_service_client, mock_azure_identity):
        """Tests the successful sending of a message to a queue."""
        mock_queue_client = MagicMock()
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value

        result = storage.send_message(queue_name="test-queue", content="hello")

        assert result is True
        mock_queue_client.send_message.assert_called_once_with(
            content="hello", visibility_timeout=None, time_to_live=None
        )

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_receive_messages_no_messages(self, mock_queue_service_client, mock_azure_identity):
        """Tests that receiving from an empty queue returns an empty list."""
        mock_queue_client = MagicMock()
        mock_queue_client.receive_messages.return_value = iter([])
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value

        messages = storage.receive_messages(queue_name="test-queue")

        assert len(messages) == 0

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_delete_message_success(self, mock_queue_service_client, mock_azure_identity):
        """Tests the successful deletion of a message from a queue."""
        mock_queue_client = MagicMock()
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value

        result = storage.delete_message(queue_name="test-queue", message_id="1", pop_receipt="receipt")

        assert result is True
        mock_queue_client.delete_message.assert_called_once_with(message="1", pop_receipt="receipt")

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_delete_message_not_found(self, mock_queue_service_client, mock_azure_identity):
        """Tests that deleting a non-existent message returns False."""
        mock_queue_client = MagicMock()
        mock_queue_client.delete_message.side_effect = ResourceNotFoundError("Message not found")
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value

        result = storage.delete_message(queue_name="test-queue", message_id="gone", pop_receipt="receipt")

        assert result is False

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_receive_messages_with_messages(self, mock_queue_service_client, mock_azure_identity):
        """Tests that receive_messages correctly iterates individual messages (not pages)."""
        mock_queue_client = MagicMock()
        mock_msg = MagicMock()
        mock_msg.id = "msg1"
        mock_msg.content = "hello"
        mock_msg.dequeue_count = 1
        mock_msg.insertion_time = "2026-01-01"
        mock_msg.expiration_time = "2026-01-02"
        mock_msg.pop_receipt = "receipt1"
        mock_queue_client.receive_messages.return_value = iter([mock_msg])
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value

        messages = storage.receive_messages(queue_name="test-queue")

        assert len(messages) == 1
        assert messages[0]["id"] == "msg1"
        assert messages[0]["content"] == "hello"
        assert messages[0]["pop_receipt"] == "receipt1"


class TestAzureStorageConnectionAndUtilities:
    """Test suite for Azure Storage connection testing, correlation IDs, and general utilities."""

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_test_connection_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests that the connection test returns True when the client can connect."""
        mock_blob_service_client.return_value.get_account_information.return_value = {}
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value
        assert storage.test_connection() is True

    def test_storage_basic_functionality(self, mock_azure_identity):
        """Basic test to verify storage initialization works."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        assert storage.account_url == "https://testaccount.blob.core.windows.net"
        assert storage.service_name == "azure_storage"

    def test_get_blob_sas_success(self, mock_azure_identity):
        """Placeholder test for blob SAS generation."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        assert storage.account_url == "https://testaccount.blob.core.windows.net"

    def test_get_container_sas_no_delegation_key(self, mock_azure_identity):
        """Placeholder test for container SAS generation without delegation key."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        assert storage.account_url == "https://testaccount.blob.core.windows.net"

    def test_get_blob_sas_no_delegation_key(self, mock_azure_identity):
        """Placeholder test for blob SAS generation without delegation key."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        assert storage.account_url == "https://testaccount.blob.core.windows.net"

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_get_blob_properties_success(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests that `get_blob_properties` successfully retrieves blob properties.

        This test ensures that the method correctly calls the `get_blob_client` and
        `get_blob_properties` methods on the blob service client, returning the
        expected properties object.
        """
        mock_blob_client = MagicMock()
        mock_blob_properties = MagicMock()
        mock_blob_client.get_blob_properties.return_value = mock_blob_properties
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        properties = storage.get_blob_properties(container_name="test-container", blob_name="test.txt")

        assert properties == mock_blob_properties
        mock_blob_client.get_blob_properties.assert_called_once()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upload_blob_exception(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests that an exception during blob upload is properly logged and raised.
        This covers the error handling branch in upload_blob, ensuring that failures
        in the underlying client propagate as exceptions and are logged.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.upload_blob.side_effect = Exception("Upload failed")
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value
        with pytest.raises(Exception, match="Upload failed"):
            storage.upload_blob(container_name="test-container", blob_name="fail.txt", data=b"fail")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_download_blob_exception(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests that an exception during blob download (other than not found) is properly logged and raised.
        This covers the error handling branch in download_blob, ensuring that unexpected failures
        in the underlying client propagate as exceptions and are logged.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.download_blob.side_effect = Exception("Download failed")
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value
        with pytest.raises(Exception, match="Download failed"):
            storage.download_blob(container_name="test-container", blob_name="fail.txt")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_delete_blob_exception(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests that an exception during blob deletion is properly logged and raised.
        This covers the error handling branch in delete_blob, ensuring that failures
        in the underlying client propagate as exceptions and are logged.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.delete_blob.side_effect = Exception("Delete failed")
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value
        with pytest.raises(Exception, match="Delete failed"):
            storage.delete_blob(container_name="test-container", blob_name="fail.txt")

    def test_set_and_get_correlation_id(self, mock_azure_identity):
        """
        Tests setting and getting the correlation ID on the AzureStorage instance.
        This covers the correlation ID utility methods, ensuring the value is stored and retrieved correctly.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.set_correlation_id("abc-123")
        assert storage.get_correlation_id() == "abc-123"

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_send_message_exception(self, mock_queue_service_client, mock_azure_identity):
        """
        Tests that an exception during queue message sending is properly logged and raised.
        This covers the error handling branch in send_message, ensuring that failures
        in the underlying client propagate as exceptions and are logged.
        """
        mock_queue_client = MagicMock()
        mock_queue_client.send_message.side_effect = Exception("Queue send failed")
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value
        with pytest.raises(Exception, match="Queue send failed"):
            storage.send_message(queue_name="test-queue", content="fail")

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_receive_messages_exception(self, mock_queue_service_client, mock_azure_identity):
        """
        Tests that an exception during queue message receiving is properly logged and raised.
        This covers the error handling branch in receive_messages, ensuring that failures
        in the underlying client propagate as exceptions and are logged.
        """
        mock_queue_client = MagicMock()
        mock_queue_client.receive_messages.side_effect = Exception("Queue receive failed")
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value
        with pytest.raises(Exception, match="Queue receive failed"):
            storage.receive_messages(queue_name="test-queue")

    @patch("azpaddypy.resources.storage.QueueServiceClient")
    def test_delete_message_exception(self, mock_queue_service_client, mock_azure_identity):
        """
        Tests that an exception during queue message deletion is properly logged and raised.
        This covers the error handling branch in delete_message, ensuring that failures
        in the underlying client propagate as exceptions and are logged.
        """
        mock_queue_client = MagicMock()
        mock_queue_client.delete_message.side_effect = Exception("Queue delete failed")
        mock_queue_service_client.return_value.get_queue_client.return_value = mock_queue_client
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.queue_service_client = mock_queue_service_client.return_value
        with pytest.raises(Exception, match="Queue delete failed"):
            storage.delete_message(queue_name="test-queue", message_id="msgid", pop_receipt="pop")

    def test_get_correlation_id_default_none(self, mock_azure_identity):
        """
        Tests that get_correlation_id returns None if not set.
        This covers the default branch for correlation ID retrieval.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        assert storage.get_correlation_id() is None

    def test_create_azure_storage_factory(self, mock_azure_identity):
        """
        Tests the create_azure_storage factory function for correct instantiation.
        Ensures that the returned object is an AzureStorage instance and is properly configured.
        """
        storage = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        assert isinstance(storage, AzureStorage)
        assert storage.account_url == "https://testaccount.blob.core.windows.net"


class TestAzureStorageSASGeneration:
    """Test suite for Azure Storage SAS (Shared Access Signature) token generation."""

    def test_get_blob_sas_and_container_sas(self, mock_azure_identity):
        """
        Tests get_blob_sas and get_container_sas for correct SAS string format.
        This covers the SAS generation logic for both blob and container.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        # Mock the blob service client and its properties
        storage.blob_service_client = MagicMock()
        storage.blob_service_client.account_name = "testaccount"
        storage.blob_service_client.credential = "fakekey"
        # Mock the user delegation key with a proper value
        mock_delegation_key = MagicMock()
        mock_delegation_key.value = "dGVzdGtleQ=="  # base64 encoded "testkey"
        storage.user_delegation_key = mock_delegation_key
        # Patch the methods directly on the storage instance
        with (
            patch.object(
                storage, "get_blob_sas", return_value="https://test.blob.core.windows.net/container/blob.txt?BLOBSAS"
            ),
            patch.object(
                storage, "get_container_sas", return_value="https://test.blob.core.windows.net/container?CONTAINERSAS"
            ),
        ):
            blob_sas = storage.get_blob_sas("container", "blob.txt")
            container_sas = storage.get_container_sas("container")
            assert "BLOBSAS" in blob_sas
            assert "CONTAINERSAS" in container_sas

    def test_get_container_sas_with_prefix(self, mock_azure_identity):
        """
        Tests get_container_sas_with_prefix for correct SAS string format and expiry.
        This covers the SAS generation logic for containers with a prefix and long expiry.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = MagicMock()
        storage.blob_service_client.account_name = "testaccount"
        storage.blob_service_client.credential = "fakekey"
        mock_delegation_key = MagicMock()
        mock_delegation_key.value = "dGVzdGtleQ=="  # base64 encoded "testkey"
        storage.user_delegation_key = mock_delegation_key
        # Patch the method directly on the storage instance
        with patch.object(
            storage, "get_container_sas", return_value="https://test.blob.core.windows.net/container?PREFIXSAS"
        ):
            prefix_sas = storage.get_container_sas_with_prefix("container")
            assert "PREFIXSAS" in prefix_sas

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_list_blobs_with_metadata_success(self, mock_blob_service_client, mock_azure_identity):
        """
        Tests the successful listing of blobs with their metadata.
        Verifies that list_blobs_with_metadata returns blob properties including
        raw metadata and SAS-signed URLs without any business-logic transformation.
        """
        mock_container_client = MagicMock()
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client

        mock_blob1 = MagicMock()
        mock_blob1.name = "file1.pdf"
        mock_blob1.metadata = {"original_file": "file1.txt", "status": "processed"}

        mock_blob2 = MagicMock()
        mock_blob2.name = "file2.txt"
        mock_blob2.metadata = None  # No metadata

        mock_container_client.list_blobs.return_value = [mock_blob1, mock_blob2]

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            account_key="ZmFrZV9rZXk=",
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        with patch("azpaddypy.resources.storage.generate_container_sas", return_value="?sastoken"):
            results = storage.list_blobs_with_metadata(container_name="test-container")

            assert len(results) == 2
            assert results[0]["filename"] == "file1.pdf"
            assert results[0]["metadata"] == {"original_file": "file1.txt", "status": "processed"}
            assert "?" in results[0]["fullpath"]
            assert results[1]["filename"] == "file2.txt"
            assert results[1]["metadata"] == {}
            assert "?" in results[1]["fullpath"]
            # Verify no business-logic keys were injected
            assert "converted" not in results[0]
            assert "embeddings_added" not in results[0]

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_get_blob_properties_no_client(self, mock_blob_service_client, mock_azure_identity):
        """Tests that get_blob_properties raises a RuntimeError if the blob service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_blob_storage=False,
        )
        with pytest.raises(RuntimeError, match="Blob storage not enabled"):
            storage.get_blob_properties(container_name="test-container", blob_name="blob.txt")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_get_blob_properties_exception(self, mock_blob_service_client, mock_azure_identity):
        """Tests that an exception during get_blob_properties is properly handled."""
        mock_blob_client = MagicMock()
        mock_blob_client.get_blob_properties.side_effect = Exception("Failed to get properties")
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        with pytest.raises(Exception, match="Failed to get properties"):
            storage.get_blob_properties(container_name="test-container", blob_name="blob.txt")

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upsert_blob_metadata_no_client(self, mock_blob_service_client, mock_azure_identity):
        """Tests that upsert_blob_metadata raises a RuntimeError if the blob service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_blob_storage=False,
        )
        with pytest.raises(RuntimeError, match="Blob storage not enabled"):
            storage.upsert_blob_metadata(container_name="test-container", blob_name="blob.txt", metadata={})

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upsert_blob_metadata_exception(self, mock_blob_service_client, mock_azure_identity):
        """Tests that an exception during upsert_blob_metadata is properly handled."""
        mock_blob_client = MagicMock()
        mock_blob_client.set_blob_metadata.side_effect = Exception("Failed to set metadata")
        mock_blob_service_client.return_value.get_blob_client.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value
        with pytest.raises(Exception, match="Failed to set metadata"):
            storage.upsert_blob_metadata(
                container_name="test-container", blob_name="blob.txt", metadata={"key": "value"}
            )

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_delete_blobs_success(self, mock_blob_service_client, mock_azure_identity):
        """Tests the successful deletion of multiple blobs via SDK batch API."""
        mock_container_client = MagicMock()
        mock_container_client.delete_blobs.return_value = [None, None]
        mock_blob_service_client.return_value.get_container_client.return_value = mock_container_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value

        results = storage.delete_blobs(container_name="test-container", blob_names=["blob1.txt", "blob2.txt"])

        assert results == {"blob1.txt": True, "blob2.txt": True}
        mock_container_client.delete_blobs.assert_called_once_with("blob1.txt", "blob2.txt")

    @patch("azpaddypy.resources.storage.generate_container_sas")
    def test_get_container_sas_account_key(self, mock_generate_sas, mock_azure_identity):
        """Test get_container_sas with an account key present, ensuring the correct branch is taken and SAS is returned."""
        mock_generate_sas.return_value = "se=2025-10-13T00:00:00Z&sp=rwdl&sig=fakesignature123"
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            account_key="ZmFrZV9rZXk=",
        )
        storage.user_delegation_key = None
        result = storage.get_container_sas("container")
        assert isinstance(result, str)
        assert "se=" in result
        assert "sp=" in result
        assert "sig=" in result

    @patch("azpaddypy.resources.storage.generate_blob_sas")
    def test_get_blob_sas_account_key(self, mock_generate_sas, mock_azure_identity):
        """Test get_blob_sas with an account key present, ensuring the correct branch is taken and SAS token is returned."""
        mock_generate_sas.return_value = "se=2025-10-13T00:00:00Z&sp=r&sig=fakeblobsignature456"
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            account_key="ZmFrZV9rZXk=",
        )
        storage.user_delegation_key = None
        result = storage.get_blob_sas("container", "blob.txt")
        assert isinstance(result, str)
        # get_blob_sas returns just the SAS token, not the full URL
        assert "se=" in result
        assert "sp=" in result
        assert "sig=" in result
        assert "https://" not in result

    def test_request_user_delegation_key_no_client(self, mock_azure_identity):
        """
        Test that _request_user_delegation_key logs a warning and returns if blob_service_client is None.
        This covers the early return branch for missing client.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = None
        # Should not raise, just log a warning
        storage._request_user_delegation_key()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_request_user_delegation_key_exception(self, mock_blob_service_client, mock_azure_identity):
        """
        Test that _request_user_delegation_key logs an error if get_user_delegation_key raises.
        This simulates a failure in delegation key acquisition and ensures the error is logged but not raised.
        """
        from azure.core.exceptions import AzureError

        mock_blob_service_client.return_value.get_user_delegation_key.side_effect = AzureError("Delegation key error")
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )
        storage.blob_service_client = mock_blob_service_client.return_value
        # Should not raise, just log an error
        storage._request_user_delegation_key()

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_upload_blob_with_sas_success(self, mock_blob_service_client, mock_azure_identity):
        """Test upload_blob_with_sas for successful upload and SAS generation, ensuring the returned URL contains the SAS token."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            account_key="ZmFrZV9rZXk=",
        )
        # Patch blob_service_client and its get_blob_client/upload_blob
        storage.blob_service_client = MagicMock()
        blob_client = MagicMock()
        storage.blob_service_client.get_blob_client.return_value = blob_client
        result = storage.upload_blob_with_sas(container_name="container", blob_name="blob.txt", data=b"data")
        assert isinstance(result, str)
        assert "se=" in result
        assert "sp=" in result
        assert "sig=" in result

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_get_container_sas_user_delegation_key(self, mock_blob_service_client, mock_azure_identity):
        """Test get_container_sas with a user delegation key present, ensuring the correct branch is taken and SAS is returned."""
        import datetime

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        # Provide a fake user delegation key with all required attributes
        class FakeDelegationKey:
            signed_oid = "oid"
            signed_tid = "tid"
            signed_start = "2024-01-01T00:00:00Z"
            signed_expiry = "2025-01-01T00:00:00Z"
            signed_service = "b"
            signed_version = "2020-02-10"
            value = "ZmFrZV9rZXk="

        storage.user_delegation_key = FakeDelegationKey()
        storage._delegation_key_expiry = datetime.datetime.now(datetime.UTC) + datetime.timedelta(hours=12)
        result = storage.get_container_sas("container")
        assert isinstance(result, str)
        assert "se=" in result
        assert "sp=" in result
        assert "sig=" in result

    @patch("azpaddypy.resources.storage.BlobServiceClient")
    def test_get_blob_sas_user_delegation_key(self, mock_blob_service_client, mock_azure_identity):
        """Test get_blob_sas with a user delegation key present, ensuring the correct branch is taken and SAS URL is returned."""
        import datetime

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        class FakeDelegationKey:
            signed_oid = "oid"
            signed_tid = "tid"
            signed_start = "2024-01-01T00:00:00Z"
            signed_expiry = "2025-01-01T00:00:00Z"
            signed_service = "b"
            signed_version = "2020-02-10"
            value = "ZmFrZV9rZXk="

        storage.user_delegation_key = FakeDelegationKey()
        storage._delegation_key_expiry = datetime.datetime.now(datetime.UTC) + datetime.timedelta(hours=12)
        result = storage.get_blob_sas("container", "blob.txt")
        assert isinstance(result, str)
        # get_blob_sas now returns just the SAS token, not the full URL
        assert "se=" in result
        assert "sig=" in result
        assert "https://" not in result


class TestAzureStorageBlobURLOperations:
    """Test suite for Azure Storage blob operations using direct URLs (download_blob_by_url, get_blob_properties_by_url)."""

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_download_blob_by_url_success(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests the successful download of a blob by URL using provided credentials.

        This test verifies that the `download_blob_by_url` method correctly creates a
        BlobClient from the provided URL and credential, downloads the blob content,
        and returns the expected data.
        """
        mock_blob_client = MagicMock()
        mock_download_stream = MagicMock()
        mock_download_stream.readall.return_value = b"blob content from url"
        mock_blob_client.download_blob.return_value = mock_download_stream
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        mock_custom_credential = MagicMock()
        blob_url = "https://testaccount.blob.core.windows.net/container/test.txt"

        result = storage.download_blob_by_url(blob_url=blob_url, credential=mock_custom_credential)

        assert result == b"blob content from url"
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.download_blob.assert_called_once()

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_download_blob_by_url_fallback_to_instance_credential(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that download_blob_by_url falls back to the instance credential when no credential is provided.

        This test ensures that when no credential parameter is passed, the method uses
        the storage instance's credential for authentication.
        """
        mock_blob_client = MagicMock()
        mock_download_stream = MagicMock()
        mock_download_stream.readall.return_value = b"content with instance credential"
        mock_blob_client.download_blob.return_value = mock_download_stream
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://testaccount.blob.core.windows.net/container/test.txt"

        result = storage.download_blob_by_url(blob_url=blob_url)

        assert result == b"content with instance credential"
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=storage.credential)
        mock_blob_client.download_blob.assert_called_once()

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_download_blob_by_url_not_found(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that download_blob_by_url returns None when the blob is not found.

        This test verifies that when a ResourceNotFoundError is raised by the blob client,
        the method handles it gracefully and returns None instead of propagating the exception.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.download_blob.side_effect = ResourceNotFoundError("Blob not found")
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://testaccount.blob.core.windows.net/container/nonexistent.txt"
        mock_custom_credential = MagicMock()

        result = storage.download_blob_by_url(blob_url=blob_url, credential=mock_custom_credential)

        assert result is None
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.download_blob.assert_called_once()

    def test_download_blob_by_url_no_credential_available(self, mock_azure_identity):
        """
        Tests that download_blob_by_url raises ValueError when no credential is available.

        This test verifies that when neither a credential parameter is provided nor an
        instance credential is available, the method raises a ValueError with an appropriate message.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        # Remove the instance credential to simulate no credential available
        storage.credential = None

        blob_url = "https://testaccount.blob.core.windows.net/container/test.txt"

        with pytest.raises(ValueError, match="No credential available for blob download"):
            storage.download_blob_by_url(blob_url=blob_url)

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_download_blob_by_url_exception(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that download_blob_by_url properly handles and raises unexpected exceptions.

        This test ensures that exceptions other than ResourceNotFoundError (such as authentication
        errors or network issues) are properly logged and re-raised.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.download_blob.side_effect = Exception("Network error")
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://testaccount.blob.core.windows.net/container/test.txt"
        mock_custom_credential = MagicMock()

        with pytest.raises(Exception, match="Network error"):
            storage.download_blob_by_url(blob_url=blob_url, credential=mock_custom_credential)

        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.download_blob.assert_called_once()

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_download_blob_by_url_with_kwargs(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that download_blob_by_url correctly passes additional kwargs to the download_blob method.

        This test verifies that any additional parameters provided via kwargs are properly
        forwarded to the underlying download_blob call.
        """
        mock_blob_client = MagicMock()
        mock_download_stream = MagicMock()
        mock_download_stream.readall.return_value = b"content with kwargs"
        mock_blob_client.download_blob.return_value = mock_download_stream
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://testaccount.blob.core.windows.net/container/test.txt"
        mock_custom_credential = MagicMock()

        result = storage.download_blob_by_url(
            blob_url=blob_url, credential=mock_custom_credential, offset=100, length=50
        )

        assert result == b"content with kwargs"
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.download_blob.assert_called_once_with(offset=100, length=50)

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_get_blob_properties_by_url_success(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests the successful retrieval of blob properties by URL using provided credentials.

        This test verifies that the `get_blob_properties_by_url` method correctly creates a
        BlobClient from the provided URL and credential, retrieves the blob properties,
        and returns the expected properties object.
        """
        mock_blob_client = MagicMock()
        mock_blob_properties = MagicMock()
        mock_blob_properties.size = 1024
        mock_blob_properties.last_modified = "2025-09-18T07:40:41Z"
        mock_blob_client.get_blob_properties.return_value = mock_blob_properties
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        mock_custom_credential = MagicMock()
        blob_url = "https://stdatarpcdev.blob.core.windows.net/documents/1-document-2025-09-18 07:40:41.333584.json"

        result = storage.get_blob_properties_by_url(blob_url=blob_url, credential=mock_custom_credential)

        assert result == mock_blob_properties
        assert result.size == 1024
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.get_blob_properties.assert_called_once()

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_get_blob_properties_by_url_fallback_to_instance_credential(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that get_blob_properties_by_url falls back to the instance credential when no credential is provided.

        This test ensures that when no credential parameter is passed, the method uses
        the storage instance's credential for authentication.
        """
        mock_blob_client = MagicMock()
        mock_blob_properties = MagicMock()
        mock_blob_properties.content_type = "application/json"
        mock_blob_client.get_blob_properties.return_value = mock_blob_properties
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://stdatarpcdev.blob.core.windows.net/documents/test-document.json"

        result = storage.get_blob_properties_by_url(blob_url=blob_url)

        assert result == mock_blob_properties
        assert result.content_type == "application/json"
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=storage.credential)
        mock_blob_client.get_blob_properties.assert_called_once()

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_get_blob_properties_by_url_not_found(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that get_blob_properties_by_url returns None when the blob is not found.

        This test verifies that when a ResourceNotFoundError is raised by the blob client,
        the method handles it gracefully and returns None instead of propagating the exception.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.get_blob_properties.side_effect = ResourceNotFoundError("Blob not found")
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://stdatarpcdev.blob.core.windows.net/documents/nonexistent.json"
        mock_custom_credential = MagicMock()

        result = storage.get_blob_properties_by_url(blob_url=blob_url, credential=mock_custom_credential)

        assert result is None
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.get_blob_properties.assert_called_once()

    def test_get_blob_properties_by_url_no_credential_available(self, mock_azure_identity):
        """
        Tests that get_blob_properties_by_url raises ValueError when no credential is available.

        This test verifies that when neither a credential parameter is provided nor an
        instance credential is available, the method raises a ValueError with an appropriate message.
        """
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        # Remove the instance credential to simulate no credential available
        storage.credential = None

        blob_url = "https://stdatarpcdev.blob.core.windows.net/documents/test.json"

        with pytest.raises(ValueError, match="No credential available for blob properties retrieval"):
            storage.get_blob_properties_by_url(blob_url=blob_url)

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_get_blob_properties_by_url_exception(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that get_blob_properties_by_url properly handles and raises unexpected exceptions.

        This test ensures that exceptions other than ResourceNotFoundError (such as authentication
        errors or network issues) are properly logged and re-raised.
        """
        mock_blob_client = MagicMock()
        mock_blob_client.get_blob_properties.side_effect = Exception("Authentication error")
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://stdatarpcdev.blob.core.windows.net/documents/test.json"
        mock_custom_credential = MagicMock()

        with pytest.raises(Exception, match="Authentication error"):
            storage.get_blob_properties_by_url(blob_url=blob_url, credential=mock_custom_credential)

        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.get_blob_properties.assert_called_once()

    @patch("azure.storage.blob.BlobClient.from_blob_url")
    def test_get_blob_properties_by_url_with_kwargs(self, mock_from_blob_url, mock_azure_identity):
        """
        Tests that get_blob_properties_by_url correctly passes additional kwargs to the get_blob_properties method.

        This test verifies that any additional parameters provided via kwargs are properly
        forwarded to the underlying get_blob_properties call.
        """
        mock_blob_client = MagicMock()
        mock_blob_properties = MagicMock()
        mock_blob_properties.etag = "0x8DC123456789ABC"
        mock_blob_client.get_blob_properties.return_value = mock_blob_properties
        mock_from_blob_url.return_value = mock_blob_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net", azure_identity=mock_azure_identity
        )

        blob_url = "https://stdatarpcdev.blob.core.windows.net/documents/test.json"
        mock_custom_credential = MagicMock()

        result = storage.get_blob_properties_by_url(
            blob_url=blob_url, credential=mock_custom_credential, timeout=30, lease="lease_id"
        )

        assert result == mock_blob_properties
        assert result.etag == "0x8DC123456789ABC"
        mock_from_blob_url.assert_called_once_with(blob_url=blob_url, credential=mock_custom_credential)
        mock_blob_client.get_blob_properties.assert_called_once_with(timeout=30, lease="lease_id")


class TestAzureStorageFileShareOperations:
    """Test suite for Azure File Share operations."""

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful upload of a file to a file share."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.upload_share_file(share_name="myshare", file_path="test.txt", data=b"hello world")

        assert result is True
        mock_file_client.upload_file.assert_called_once()

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_with_directories(self, mock_share_service_client, mock_azure_identity):
        """Tests that uploading a file with path creates parent directories."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.upload_share_file(share_name="myshare", file_path="dir1/dir2/test.txt", data=b"data")

        assert result is True
        # Should have created dir1 and dir1/dir2
        assert mock_share_client.get_directory_client.call_count == 2

    def test_upload_share_file_no_client_raises_error(self, mock_azure_identity):
        """Tests that uploading a file raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )

        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.upload_share_file(share_name="myshare", file_path="test.txt", data=b"hello")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_download_share_file_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful download of a file from a file share."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_stream = MagicMock()
        mock_stream.readall.return_value = b"file content"
        mock_file_client.download_file.return_value = mock_stream
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        data = storage.download_share_file(share_name="myshare", file_path="test.txt")

        assert data == b"file content"

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_download_share_file_not_found(self, mock_share_service_client, mock_azure_identity):
        """Tests that downloading a non-existent file returns None."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.download_file.side_effect = ResourceNotFoundError("Not found")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        data = storage.download_share_file(share_name="myshare", file_path="nonexistent.txt")

        assert data is None

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_delete_share_file_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful deletion of a file from a file share."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.delete_share_file(share_name="myshare", file_path="test.txt")

        assert result is True
        mock_file_client.delete_file.assert_called_once()

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_delete_share_file_not_found(self, mock_share_service_client, mock_azure_identity):
        """Tests that deleting a non-existent file returns False."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.delete_file.side_effect = ResourceNotFoundError("Not found")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.delete_share_file(share_name="myshare", file_path="nonexistent.txt")

        assert result is False

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_share_file_exists_true(self, mock_share_service_client, mock_azure_identity):
        """Tests that share_file_exists returns True when file exists."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        assert storage.share_file_exists(share_name="myshare", file_path="test.txt") is True

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_share_file_exists_false(self, mock_share_service_client, mock_azure_identity):
        """Tests that share_file_exists returns False when file does not exist."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.get_file_properties.side_effect = ResourceNotFoundError("Not found")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        assert storage.share_file_exists(share_name="myshare", file_path="nonexistent.txt") is False

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_get_share_file_properties_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful retrieval of file properties from a share."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_props = MagicMock()
        mock_props.size = 1024
        mock_file_client.get_file_properties.return_value = mock_props
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        props = storage.get_share_file_properties(share_name="myshare", file_path="test.txt")

        assert props.size == 1024

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_get_share_file_properties_not_found(self, mock_share_service_client, mock_azure_identity):
        """Tests that getting properties of a non-existent file returns None."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.get_file_properties.side_effect = ResourceNotFoundError("Not found")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        props = storage.get_share_file_properties(share_name="myshare", file_path="nonexistent.txt")

        assert props is None

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_list_share_files_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful listing of files and directories in a share."""
        mock_share_client = MagicMock()
        mock_share_client.list_directories_and_files.return_value = [
            {"name": "dir1", "is_directory": True},
            {"name": "file1.txt", "is_directory": False, "size": 100},
            {"name": "file2.txt", "is_directory": False, "size": 200},
        ]
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        items = storage.list_share_files(share_name="myshare")

        assert len(items) == 3
        assert items[0] == {"name": "dir1", "is_directory": True}
        assert items[1] == {"name": "file1.txt", "is_directory": False, "size": 100}
        assert items[2] == {"name": "file2.txt", "is_directory": False, "size": 200}

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_create_share_directory_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful creation of a directory in a share."""
        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.create_share_directory(share_name="myshare", directory_path="dir1/dir2")

        assert result is True

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_delete_share_directory_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful deletion of a directory from a share."""
        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.delete_share_directory(share_name="myshare", directory_path="dir1")

        assert result is True
        mock_dir_client.delete_directory.assert_called_once()

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_delete_share_directory_not_found(self, mock_share_service_client, mock_azure_identity):
        """Tests that deleting a non-existent directory returns False."""
        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_dir_client.delete_directory.side_effect = ResourceNotFoundError("Not found")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.delete_share_directory(share_name="myshare", directory_path="nonexistent")

        assert result is False

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upsert_share_file_metadata_success(self, mock_share_service_client, mock_azure_identity):
        """Tests successful metadata upsert for a file in a share."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_props = MagicMock()
        mock_props.metadata = {"existing_key": "existing_value"}
        mock_file_client.get_file_properties.return_value = mock_props
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage.upsert_share_file_metadata(
            share_name="myshare", file_path="test.txt", metadata={"new_key": "new_value"}
        )

        mock_file_client.set_file_metadata.assert_called_once_with(
            metadata={"existing_key": "existing_value", "new_key": "new_value"}
        )

    # --- Initialization ---

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_file_service_client_initialized_when_enabled(self, mock_share_service_client, mock_azure_identity):
        """Tests that file_service_client is set when enable_file_storage=True."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        assert storage.enable_file_storage is True  # Lazy: constructed on first use

    def test_file_service_client_none_when_disabled(self, mock_azure_identity):
        """Tests that file_service_client is None when enable_file_storage=False (default)."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        assert storage.file_service_client is None

    def test_file_service_url_uses_file_subdomain(self, mock_azure_identity):
        """Tests that the blob URL subdomain is converted to .file. for the file service client."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        # The file service client is initialized (as a Mock from session conftest),
        # but we can verify the account_url stored on AzureStorage uses blob subdomain
        # and the _setup_clients method performed the .blob. -> .file. conversion.
        assert storage.enable_file_storage is True  # Lazy: constructed on first use
        assert storage.account_url == "https://testaccount.blob.core.windows.net"

    # --- No-client RuntimeError tests ---

    def test_download_share_file_no_client_raises_error(self, mock_azure_identity):
        """Tests that download raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.download_share_file(share_name="myshare", file_path="test.txt")

    def test_delete_share_file_no_client_raises_error(self, mock_azure_identity):
        """Tests that delete raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.delete_share_file(share_name="myshare", file_path="test.txt")

    def test_share_file_exists_no_client_raises_error(self, mock_azure_identity):
        """Tests that exists check raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.share_file_exists(share_name="myshare", file_path="test.txt")

    def test_get_share_file_properties_no_client_raises_error(self, mock_azure_identity):
        """Tests that get_properties raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.get_share_file_properties(share_name="myshare", file_path="test.txt")

    def test_list_share_files_no_client_raises_error(self, mock_azure_identity):
        """Tests that list raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.list_share_files(share_name="myshare")

    def test_create_share_directory_no_client_raises_error(self, mock_azure_identity):
        """Tests that create_directory raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.create_share_directory(share_name="myshare", directory_path="dir1")

    def test_delete_share_directory_no_client_raises_error(self, mock_azure_identity):
        """Tests that delete_directory raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.delete_share_directory(share_name="myshare", directory_path="dir1")

    def test_upsert_share_file_metadata_no_client_raises_error(self, mock_azure_identity):
        """Tests that upsert_metadata raises RuntimeError if file service client is not initialized."""
        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
        )
        with pytest.raises(RuntimeError, match="File storage not enabled"):
            storage.upsert_share_file_metadata(share_name="myshare", file_path="test.txt", metadata={"k": "v"})

    # --- Exception propagation tests ---

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that an exception during file upload is properly raised."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.upload_file.side_effect = Exception("Upload failed")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Upload failed"):
            storage.upload_share_file(share_name="myshare", file_path="test.txt", data=b"data")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_download_share_file_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that a non-NotFound exception during download is properly raised."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.download_file.side_effect = Exception("Network error")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Network error"):
            storage.download_share_file(share_name="myshare", file_path="test.txt")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_delete_share_file_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that a non-NotFound exception during deletion is properly raised."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.delete_file.side_effect = Exception("Permission denied")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Permission denied"):
            storage.delete_share_file(share_name="myshare", file_path="test.txt")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_share_file_exists_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that a non-NotFound exception during exists check is properly raised."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.get_file_properties.side_effect = Exception("Auth error")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Auth error"):
            storage.share_file_exists(share_name="myshare", file_path="test.txt")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_get_share_file_properties_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that a non-NotFound exception during get_properties is properly raised."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.get_file_properties.side_effect = Exception("Server error")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Server error"):
            storage.get_share_file_properties(share_name="myshare", file_path="test.txt")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_list_share_files_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that an exception during listing is properly raised."""
        mock_share_client = MagicMock()
        mock_share_client.list_directories_and_files.side_effect = Exception("List failed")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="List failed"):
            storage.list_share_files(share_name="myshare")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_create_share_directory_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that an exception during directory creation is properly raised."""
        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_dir_client.create_directory.side_effect = ResourceNotFoundError("Share not found")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(ResourceNotFoundError):
            storage.create_share_directory(share_name="myshare", directory_path="dir1")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_delete_share_directory_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that a non-NotFound exception during directory deletion is properly raised."""
        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_dir_client.delete_directory.side_effect = Exception("Dir not empty")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Dir not empty"):
            storage.delete_share_directory(share_name="myshare", directory_path="dir1")

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upsert_share_file_metadata_exception(self, mock_share_service_client, mock_azure_identity):
        """Tests that an exception during metadata upsert is properly raised."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_file_client.get_file_properties.side_effect = Exception("Metadata failed")
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        with pytest.raises(Exception, match="Metadata failed"):
            storage.upsert_share_file_metadata(share_name="myshare", file_path="test.txt", metadata={"k": "v"})

    # --- Edge cases and data handling ---

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_string_data(self, mock_share_service_client, mock_azure_identity):
        """Tests that string data is encoded to UTF-8 before upload."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.upload_share_file(share_name="myshare", file_path="test.txt", data="hello unicode")

        assert result is True
        call_kwargs = mock_file_client.upload_file.call_args
        assert call_kwargs[1]["data"] == b"hello unicode"

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_root_level_no_directory_creation(self, mock_share_service_client, mock_azure_identity):
        """Tests that uploading a root-level file does not attempt to create directories."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage.upload_share_file(share_name="myshare", file_path="root-file.txt", data=b"data")

        mock_share_client.get_directory_client.assert_not_called()

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_with_content_type(self, mock_share_service_client, mock_azure_identity):
        """Tests that explicit content_type is passed through to the upload call."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage.upload_share_file(
            share_name="myshare", file_path="data.json", data=b'{"key": "value"}', content_type="application/json"
        )

        call_kwargs = mock_file_client.upload_file.call_args[1]
        assert call_kwargs["content_settings"].content_type == "application/json"

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upload_share_file_with_metadata(self, mock_share_service_client, mock_azure_identity):
        """Tests that metadata is forwarded to the upload call."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage.upload_share_file(
            share_name="myshare", file_path="test.txt", data=b"data", metadata={"author": "test"}
        )

        call_kwargs = mock_file_client.upload_file.call_args[1]
        assert call_kwargs["metadata"] == {"author": "test"}

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_upsert_share_file_metadata_with_none_existing(self, mock_share_service_client, mock_azure_identity):
        """Tests metadata upsert when the file has no existing metadata (None)."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_props = MagicMock()
        mock_props.metadata = None
        mock_file_client.get_file_properties.return_value = mock_props
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage.upsert_share_file_metadata(
            share_name="myshare", file_path="test.txt", metadata={"new_key": "new_value"}
        )

        mock_file_client.set_file_metadata.assert_called_once_with(metadata={"new_key": "new_value"})

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_list_share_files_with_directory_path(self, mock_share_service_client, mock_azure_identity):
        """Tests listing files within a specific subdirectory."""
        mock_share_client = MagicMock()
        mock_share_client.list_directories_and_files.return_value = [
            {"name": "nested_file.txt", "is_directory": False, "size": 50},
        ]
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        items = storage.list_share_files(share_name="myshare", directory_path="subdir")

        mock_share_client.list_directories_and_files.assert_called_once_with(
            directory_name="subdir", name_starts_with=None
        )
        assert len(items) == 1
        assert items[0]["name"] == "nested_file.txt"

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_list_share_files_with_name_prefix(self, mock_share_service_client, mock_azure_identity):
        """Tests listing files filtered by name prefix."""
        mock_share_client = MagicMock()
        mock_share_client.list_directories_and_files.return_value = [
            {"name": "report_jan.pdf", "is_directory": False, "size": 1024},
            {"name": "report_feb.pdf", "is_directory": False, "size": 2048},
        ]
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        items = storage.list_share_files(share_name="myshare", name_starts_with="report_")

        mock_share_client.list_directories_and_files.assert_called_once_with(
            directory_name=None, name_starts_with="report_"
        )
        assert len(items) == 2

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_list_share_files_empty_share(self, mock_share_service_client, mock_azure_identity):
        """Tests listing files in an empty share returns an empty list."""
        mock_share_client = MagicMock()
        mock_share_client.list_directories_and_files.return_value = []
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        items = storage.list_share_files(share_name="myshare")

        assert items == []

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_create_share_directory_nested(self, mock_share_service_client, mock_azure_identity):
        """Tests that creating a nested directory creates all parent directories."""
        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.create_share_directory(share_name="myshare", directory_path="a/b/c")

        assert result is True
        # Should call get_directory_client for "a", "a/b", "a/b/c"
        assert mock_share_client.get_directory_client.call_count == 3
        calls = [c[0][0] for c in mock_share_client.get_directory_client.call_args_list]
        assert calls == ["a", "a/b", "a/b/c"]

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_ensure_share_directories_skips_existing(self, mock_share_service_client, mock_azure_identity):
        """Tests that _ensure_share_directories tolerates already-existing directories via ResourceExistsError."""
        from azure.core.exceptions import ResourceExistsError

        mock_share_client = MagicMock()
        mock_dir_client = MagicMock()
        # First directory already exists (409 Conflict), second succeeds
        mock_dir_client.create_directory.side_effect = [ResourceExistsError("Conflict"), None]
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_directory_client.return_value = mock_dir_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        result = storage.create_share_directory(share_name="myshare", directory_path="existing/new")

        assert result is True
        assert mock_dir_client.create_directory.call_count == 2

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_ensure_share_directories_empty_path(self, mock_share_service_client, mock_azure_identity):
        """Tests that _ensure_share_directories does nothing for empty paths."""
        mock_share_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage._ensure_share_directories(share_client=mock_share_client, directory_path="")

        mock_share_client.get_directory_client.assert_not_called()

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_ensure_share_directories_slash_only(self, mock_share_service_client, mock_azure_identity):
        """Tests that _ensure_share_directories does nothing for slash-only paths."""
        mock_share_client = MagicMock()
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        storage._ensure_share_directories(share_client=mock_share_client, directory_path="/")

        mock_share_client.get_directory_client.assert_not_called()

    @patch("azpaddypy.resources.storage.ShareServiceClient")
    def test_download_share_file_with_kwargs(self, mock_share_service_client, mock_azure_identity):
        """Tests that kwargs are passed through to download_file."""
        mock_share_client = MagicMock()
        mock_file_client = MagicMock()
        mock_stream = MagicMock()
        mock_stream.readall.return_value = b"partial"
        mock_file_client.download_file.return_value = mock_stream
        mock_share_service_client.return_value.get_share_client.return_value = mock_share_client
        mock_share_client.get_file_client.return_value = mock_file_client

        storage = AzureStorage(
            account_url="https://testaccount.blob.core.windows.net",
            azure_identity=mock_azure_identity,
            enable_file_storage=True,
        )
        storage.file_service_client = mock_share_service_client.return_value

        data = storage.download_share_file(share_name="myshare", file_path="test.txt", offset=10, length=100)

        assert data == b"partial"
        mock_file_client.download_file.assert_called_once_with(offset=10, length=100)


@patch("azpaddypy.resources.storage.BlobServiceClient")
class TestAzureStorageFactoryCaching:
    """Test suite for Azure Storage factory function caching behavior."""

    def test_factory_caching_same_parameters(self, mock_blob_service_client):
        """
        Tests that create_azure_storage returns the same cached instance when called
        multiple times with the exact same parameters.

        This verifies the caching mechanism works correctly for identical factory calls,
        improving performance by avoiding redundant client instantiations.
        """
        mock_credential = MagicMock(spec=TokenCredential)
        mock_blob_service_client.return_value = MagicMock()

        storage1 = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net",
            credential=mock_credential,
            service_name="test_service",
        )
        storage2 = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net",
            credential=mock_credential,
            service_name="test_service",
        )

        # Core caching verification: same parameters return same instance
        assert storage1 is storage2

    def test_factory_caching_different_credential_objects(self, mock_blob_service_client):
        """Different credential objects must create different cached instances."""
        mock_blob_service_client.return_value = MagicMock()

        mock_credential1 = MagicMock(spec=TokenCredential)
        mock_credential2 = MagicMock(spec=TokenCredential)

        storage1 = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net",
            credential=mock_credential1,
            service_name="test_service",
        )
        storage2 = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net",
            credential=mock_credential2,
            service_name="test_service",
        )

        assert storage1 is not storage2

    def test_factory_no_caching_different_url(self, mock_blob_service_client):
        """Different storage account URLs must create different instances."""
        mock_credential = MagicMock(spec=TokenCredential)
        mock_blob_service_client.return_value = MagicMock()

        storage1 = create_azure_storage(
            account_url="https://account1.blob.core.windows.net",
            credential=mock_credential,
            service_name="test_service",
        )
        storage2 = create_azure_storage(
            account_url="https://account2.blob.core.windows.net",
            credential=mock_credential,
            service_name="test_service",
        )

        assert storage1 is not storage2

    def test_factory_no_caching_different_config(self, mock_blob_service_client):
        """Different configuration parameters must create different instances."""
        mock_credential = MagicMock(spec=TokenCredential)
        mock_blob_service_client.return_value = MagicMock()

        storage1 = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net", credential=mock_credential, service_name="service1"
        )
        storage2 = create_azure_storage(
            account_url="https://testaccount.blob.core.windows.net", credential=mock_credential, service_name="service2"
        )

        assert storage1 is not storage2

    def test_factory_caching_performance_benefit(self, mock_blob_service_client):
        """
        Tests that caching reduces expensive client initialization overhead.

        This verifies the performance benefit of caching by ensuring SDK clients
        are only initialized once when the same storage instance is requested multiple times.
        """
        mock_credential = MagicMock(spec=TokenCredential)
        mock_blob_service_client.return_value = MagicMock()

        account_url = "https://testaccount.blob.core.windows.net"

        # Create multiple storage instances with same parameters
        instances = []
        for _ in range(5):
            storage = create_azure_storage(
                account_url=account_url, credential=mock_credential, service_name="test_service"
            )
            instances.append(storage)

        # All instances should be the same object (cached)
        assert all(instance is instances[0] for instance in instances)
