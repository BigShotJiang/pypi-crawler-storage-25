"""Compatibility shim — real module lives at `phi_scan.cli.watch`.

This top-level re-export preserves the historical import path
`phi_scan.cli_watch` while the canonical home is the `phi_scan.cli`
package. New code should import from `phi_scan.cli.watch` directly.
"""

from phi_scan.cli import watch as _watch_module
from phi_scan.cli.watch import *  # noqa: F401,F403

__all__ = getattr(
    _watch_module, "__all__", [name for name in dir(_watch_module) if not name.startswith("_")]
)
