"""CI/CD platform detection and PR context extraction.

Auto-detects the running CI/CD platform from environment variables and
extracts PR/MR context into a platform-neutral ``PullRequestContext`` dataclass.
"""

from __future__ import annotations

import enum
import os
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType

from phi_scan.ci._env import fetch_environment_variable

__all__ = [
    "CIPlatform",
    "PullRequestContext",
    "detect_platform",
    "get_pull_request_context",
]

# ---------------------------------------------------------------------------
# Environment variable names — one block per platform
# ---------------------------------------------------------------------------

# GitHub Actions
_ENV_GITHUB_ACTIONS: str = "GITHUB_ACTIONS"
_ENV_GITHUB_REPOSITORY: str = "GITHUB_REPOSITORY"
_ENV_GITHUB_SHA: str = "GITHUB_SHA"
_ENV_GITHUB_REF: str = "GITHUB_REF"
_ENV_PR_NUMBER: str = "PR_NUMBER"

# GitLab CI
_ENV_GITLAB_CI: str = "GITLAB_CI"
_ENV_CI_PROJECT_ID: str = "CI_PROJECT_ID"
_ENV_CI_MERGE_REQUEST_IID: str = "CI_MERGE_REQUEST_IID"
_ENV_CI_SERVER_URL: str = "CI_SERVER_URL"
_ENV_CI_COMMIT_SHA: str = "CI_COMMIT_SHA"
_ENV_CI_COMMIT_REF_NAME: str = "CI_COMMIT_REF_NAME"

# Jenkins
_ENV_JENKINS_URL: str = "JENKINS_URL"
_ENV_CHANGE_ID: str = "CHANGE_ID"
_ENV_CHANGE_URL: str = "CHANGE_URL"

# Azure DevOps
_ENV_TF_BUILD: str = "TF_BUILD"
_ENV_SYSTEM_TEAMFOUNDATIONCOLLECTIONURI: str = "SYSTEM_TEAMFOUNDATIONCOLLECTIONURI"
_ENV_SYSTEM_TEAMPROJECT: str = "SYSTEM_TEAMPROJECT"
_ENV_BUILD_REPOSITORY_ID: str = "BUILD_REPOSITORY_ID"
_ENV_SYSTEM_PULLREQUEST_PULLREQUESTID: str = "SYSTEM_PULLREQUEST_PULLREQUESTID"
_ENV_BUILD_BUILDID: str = "BUILD_BUILDID"
_ENV_BUILD_SOURCEVERSION: str = "BUILD_SOURCEVERSION"

# CircleCI
_ENV_CIRCLECI: str = "CIRCLECI"
_ENV_CIRCLE_PULL_REQUEST: str = "CIRCLE_PULL_REQUEST"
_ENV_CIRCLE_SHA1: str = "CIRCLE_SHA1"
_ENV_CIRCLE_BRANCH: str = "CIRCLE_BRANCH"

# Bitbucket Pipelines
_ENV_BITBUCKET_BUILD_NUMBER: str = "BITBUCKET_BUILD_NUMBER"
_ENV_BITBUCKET_PR_ID: str = "BITBUCKET_PR_ID"
_ENV_BITBUCKET_REPO_SLUG: str = "BITBUCKET_REPO_SLUG"
_ENV_BITBUCKET_WORKSPACE: str = "BITBUCKET_WORKSPACE"
_ENV_BITBUCKET_COMMIT: str = "BITBUCKET_COMMIT"

# AWS CodeBuild
_ENV_CODEBUILD_BUILD_ID: str = "CODEBUILD_BUILD_ID"
_ENV_CODEBUILD_WEBHOOK_TRIGGER: str = "CODEBUILD_WEBHOOK_TRIGGER"
_ENV_CODEBUILD_SOURCE_VERSION: str = "CODEBUILD_SOURCE_VERSION"
_ENV_CODEBUILD_WEBHOOK_BASE_REF: str = "CODEBUILD_WEBHOOK_BASE_REF"

# GitLab default
_GITLAB_DEFAULT_SERVER_URL: str = "https://gitlab.com"

# GitHub ref prefix for PR detection (e.g. "refs/pull/42/merge")
_GITHUB_PR_REF_PREFIX: str = "refs/pull/"
_GITHUB_REF_PR_NUMBER_SEGMENT_INDEX: int = 2

# CodeBuild webhook trigger prefix for PR detection (e.g. "pr/42")
_CODEBUILD_PR_TRIGGER_PREFIX: str = "pr/"
_URL_PATH_SEPARATOR: str = "/"

# Sentinel values for CI platform detection env vars
# Azure DevOps uses "True" (capital T) while all other platforms use "true"
_CI_ENV_SENTINEL_TRUE: str = "true"
_AZURE_ENV_SENTINEL_TRUE: str = "True"


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------


class CIPlatform(enum.Enum):
    """Enumeration of supported CI/CD platforms."""

    GITHUB_ACTIONS = "github_actions"
    GITLAB_CI = "gitlab_ci"
    JENKINS = "jenkins"
    AZURE_DEVOPS = "azure_devops"
    CIRCLECI = "circleci"
    BITBUCKET = "bitbucket"
    CODEBUILD = "codebuild"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class PullRequestContext:
    """Platform-neutral PR/MR context extracted from environment variables.

    Top-level fields that are unavailable on the current platform are ``None``.
    Values inside ``extras`` are always strings (empty string when absent).
    The ``extras`` mapping is frozen via ``MappingProxyType`` to prevent
    mutation of shared context objects between adapter calls.
    """

    platform: CIPlatform
    pull_request_number: str | None
    repository: str | None
    sha: str | None
    branch: str | None
    base_branch: str | None
    extras: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.extras, MappingProxyType):
            object.__setattr__(self, "extras", MappingProxyType(dict(self.extras)))


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------


def detect_platform() -> CIPlatform:
    """Detect the currently running CI/CD platform from environment variables.

    Checks well-known platform sentinel variables in order of specificity.
    Returns ``CIPlatform.UNKNOWN`` when none of the known sentinels are set.
    """
    if os.environ.get(_ENV_GITHUB_ACTIONS) == _CI_ENV_SENTINEL_TRUE:
        return CIPlatform.GITHUB_ACTIONS
    if os.environ.get(_ENV_GITLAB_CI) == _CI_ENV_SENTINEL_TRUE:
        return CIPlatform.GITLAB_CI
    if os.environ.get(_ENV_TF_BUILD) == _AZURE_ENV_SENTINEL_TRUE:
        return CIPlatform.AZURE_DEVOPS
    if os.environ.get(_ENV_CIRCLECI) == _CI_ENV_SENTINEL_TRUE:
        return CIPlatform.CIRCLECI
    if os.environ.get(_ENV_BITBUCKET_BUILD_NUMBER):
        return CIPlatform.BITBUCKET
    if os.environ.get(_ENV_CODEBUILD_BUILD_ID):
        return CIPlatform.CODEBUILD
    if os.environ.get(_ENV_JENKINS_URL):
        return CIPlatform.JENKINS
    return CIPlatform.UNKNOWN


# ---------------------------------------------------------------------------
# Context builders — one per platform
# ---------------------------------------------------------------------------


def _extract_github_pull_request_number(github_ref: str) -> str | None:
    if not github_ref.startswith(_GITHUB_PR_REF_PREFIX):
        return None
    ref_segments = github_ref.split("/")
    if len(ref_segments) <= _GITHUB_REF_PR_NUMBER_SEGMENT_INDEX:
        return None
    return ref_segments[_GITHUB_REF_PR_NUMBER_SEGMENT_INDEX]


def _resolve_github_pull_request_number() -> str | None:
    explicit_pull_request_number = fetch_environment_variable(_ENV_PR_NUMBER)
    if explicit_pull_request_number:
        return explicit_pull_request_number
    github_ref = fetch_environment_variable(_ENV_GITHUB_REF) or ""
    return _extract_github_pull_request_number(github_ref)


def _build_github_context() -> PullRequestContext:
    return PullRequestContext(
        platform=CIPlatform.GITHUB_ACTIONS,
        pull_request_number=_resolve_github_pull_request_number(),
        repository=fetch_environment_variable(_ENV_GITHUB_REPOSITORY),
        sha=fetch_environment_variable(_ENV_GITHUB_SHA),
        branch=fetch_environment_variable(_ENV_GITHUB_REF),
        base_branch=None,
    )


def _build_gitlab_context() -> PullRequestContext:
    return PullRequestContext(
        platform=CIPlatform.GITLAB_CI,
        pull_request_number=fetch_environment_variable(_ENV_CI_MERGE_REQUEST_IID),
        repository=fetch_environment_variable(_ENV_CI_PROJECT_ID),
        sha=fetch_environment_variable(_ENV_CI_COMMIT_SHA),
        branch=fetch_environment_variable(_ENV_CI_COMMIT_REF_NAME),
        base_branch=None,
        extras={
            "ci_server_url": (
                fetch_environment_variable(_ENV_CI_SERVER_URL) or _GITLAB_DEFAULT_SERVER_URL
            ),
        },
    )


def _normalise_collection_url(collection_url: str) -> str:
    if collection_url and not collection_url.endswith(_URL_PATH_SEPARATOR):
        return collection_url + _URL_PATH_SEPARATOR
    return collection_url


def _build_azure_context() -> PullRequestContext:
    raw_collection_url = fetch_environment_variable(_ENV_SYSTEM_TEAMFOUNDATIONCOLLECTIONURI) or ""
    collection_uri = _normalise_collection_url(raw_collection_url)
    return PullRequestContext(
        platform=CIPlatform.AZURE_DEVOPS,
        pull_request_number=fetch_environment_variable(_ENV_SYSTEM_PULLREQUEST_PULLREQUESTID),
        repository=fetch_environment_variable(_ENV_BUILD_REPOSITORY_ID),
        sha=fetch_environment_variable(_ENV_BUILD_SOURCEVERSION),
        branch=None,
        base_branch=None,
        extras={
            "collection_uri": collection_uri,
            "team_project": fetch_environment_variable(_ENV_SYSTEM_TEAMPROJECT) or "",
            "build_id": fetch_environment_variable(_ENV_BUILD_BUILDID) or "",
        },
    )


def _extract_pull_request_number_from_url(pull_request_url: str) -> str | None:
    if not pull_request_url:
        return None
    url_segments = pull_request_url.rstrip("/").split("/")
    if not url_segments:
        return None
    last_url_segment = url_segments[-1]
    return last_url_segment if last_url_segment.isdigit() else None


def _build_circleci_context() -> PullRequestContext:
    circle_pull_request_url = fetch_environment_variable(_ENV_CIRCLE_PULL_REQUEST) or ""
    pull_request_number = _extract_pull_request_number_from_url(circle_pull_request_url)
    return PullRequestContext(
        platform=CIPlatform.CIRCLECI,
        pull_request_number=pull_request_number,
        repository=None,
        sha=fetch_environment_variable(_ENV_CIRCLE_SHA1),
        branch=fetch_environment_variable(_ENV_CIRCLE_BRANCH),
        base_branch=None,
        extras={"circle_pull_request_url": circle_pull_request_url},
    )


def _build_bitbucket_context() -> PullRequestContext:
    return PullRequestContext(
        platform=CIPlatform.BITBUCKET,
        pull_request_number=fetch_environment_variable(_ENV_BITBUCKET_PR_ID),
        repository=fetch_environment_variable(_ENV_BITBUCKET_REPO_SLUG),
        sha=fetch_environment_variable(_ENV_BITBUCKET_COMMIT),
        branch=None,
        base_branch=None,
        extras={
            "workspace": fetch_environment_variable(_ENV_BITBUCKET_WORKSPACE) or "",
        },
    )


def _extract_codebuild_pull_request_number(webhook_trigger: str) -> str | None:
    if not webhook_trigger.startswith(_CODEBUILD_PR_TRIGGER_PREFIX):
        return None
    return webhook_trigger.removeprefix(_CODEBUILD_PR_TRIGGER_PREFIX) or None


def _build_codebuild_context() -> PullRequestContext:
    webhook_trigger = fetch_environment_variable(_ENV_CODEBUILD_WEBHOOK_TRIGGER) or ""
    pull_request_number = _extract_codebuild_pull_request_number(webhook_trigger)
    return PullRequestContext(
        platform=CIPlatform.CODEBUILD,
        pull_request_number=pull_request_number,
        repository=None,
        sha=fetch_environment_variable(_ENV_CODEBUILD_SOURCE_VERSION),
        branch=None,
        base_branch=fetch_environment_variable(_ENV_CODEBUILD_WEBHOOK_BASE_REF),
    )


def _build_jenkins_context() -> PullRequestContext:
    return PullRequestContext(
        platform=CIPlatform.JENKINS,
        pull_request_number=fetch_environment_variable(_ENV_CHANGE_ID),
        repository=None,
        sha=None,
        branch=None,
        base_branch=None,
        extras={"change_url": fetch_environment_variable(_ENV_CHANGE_URL) or ""},
    )


def _build_unknown_context() -> PullRequestContext:
    return PullRequestContext(
        platform=CIPlatform.UNKNOWN,
        pull_request_number=None,
        repository=None,
        sha=None,
        branch=None,
        base_branch=None,
    )


_PLATFORM_CONTEXT_BUILDERS: dict[CIPlatform, Callable[[], PullRequestContext]] = {
    CIPlatform.GITHUB_ACTIONS: _build_github_context,
    CIPlatform.GITLAB_CI: _build_gitlab_context,
    CIPlatform.AZURE_DEVOPS: _build_azure_context,
    CIPlatform.CIRCLECI: _build_circleci_context,
    CIPlatform.BITBUCKET: _build_bitbucket_context,
    CIPlatform.CODEBUILD: _build_codebuild_context,
    CIPlatform.JENKINS: _build_jenkins_context,
    CIPlatform.UNKNOWN: _build_unknown_context,
}


def get_pull_request_context() -> PullRequestContext:
    """Build a ``PullRequestContext`` from the current environment.

    Reads platform-specific environment variables to extract the PR number,
    repository, commit SHA, and branch.
    """
    platform = detect_platform()
    builder = _PLATFORM_CONTEXT_BUILDERS[platform]
    return builder()
