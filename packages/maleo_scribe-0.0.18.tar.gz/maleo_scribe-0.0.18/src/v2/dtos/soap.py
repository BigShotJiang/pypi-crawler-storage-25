from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.types.string import OptStr, OptStrT
from ...common.mixins import (
    Overall,
    OptOtherInformation,
    ChiefComplaint,
    OptAdditionalComplaint,
    OptPainScale,
    OptOnset,
    OptChronology,
    OptLocation,
    OptAggravatingFactor,
    OptRelievingFactor,
    OptPersonalMedicalHistory,
    OptFamilyMedicalHistory,
    OptHabitActivityOccupation,
    OptConsumedMedication,
    OptSystolicBloodPressure,
    OptDiastolicBloodPressure,
    OptTemperature,
    OptRespirationRate,
    OptHeartRate,
    OptOxygenSaturation,
    OptAbdominalCircumference,
    OptWaistCircumference,
    OptWeight,
    OptHeight,
    OptBodyMassIndex,
    OptOrganExaminationDetail,
)


# ----- Subjective ----- #
class SubjectiveDTO(
    OptOtherInformation,
    OptConsumedMedication,
    OptHabitActivityOccupation,
    OptFamilyMedicalHistory,
    OptPersonalMedicalHistory,
    OptRelievingFactor,
    OptAggravatingFactor,
    OptLocation,
    OptChronology,
    OptOnset,
    OptPainScale,
    OptAdditionalComplaint,
    ChiefComplaint[OptStrT],
    Generic[OptStrT],
):
    pass


class FlexibleSubjectiveDTO(SubjectiveDTO[OptStr]):
    chief_complaint: Annotated[
        OptStr, Field(None, description="Patient's chief complaint")
    ] = None


class StrictSubjectiveDTO(SubjectiveDTO[str]):
    pass


OptSubjectiveDTO = SubjectiveDTO | None
OptSubjectiveDTOT = TypeVar("OptSubjectiveDTOT", bound=OptSubjectiveDTO)


# ----- Vital Sign ----- #
class VitalSignDTO(
    OptOrganExaminationDetail,
    OptBodyMassIndex,
    OptWeight,
    OptHeight,
    OptWaistCircumference,
    OptAbdominalCircumference,
    OptOxygenSaturation,
    OptHeartRate,
    OptRespirationRate,
    OptTemperature,
    OptDiastolicBloodPressure,
    OptSystolicBloodPressure,
):
    pass


class VitalSignDTOMixin(BaseModel):
    vital_sign: Annotated[VitalSignDTO, Field(..., description="Vital Sign")]


# ----- Objective ----- #
class ObjectiveDTO(
    OptOtherInformation,
    VitalSignDTOMixin,
    Overall[OptStrT],
    Generic[OptStrT],
):
    pass


class FlexibleObjectiveDTO(ObjectiveDTO[OptStr]):
    overall: Annotated[OptStr, Field(None, description="Overall")] = None


class StrictObjectiveDTO(ObjectiveDTO[str]):
    pass


OptObjectiveDTO = ObjectiveDTO | None
OptObjectiveDTOT = TypeVar("OptObjectiveDTOT", bound=OptObjectiveDTO)


# ----- Assessment ----- #
class Assessment(BaseModel, Generic[OptStrT]):
    assessment: Annotated[OptStrT, Field(..., description="Patient's assessment")]


AssessmentT = TypeVar("AssessmentT", bound=OptStr)


# ----- Plan ----- #
class Plan(BaseModel, Generic[OptStrT]):
    plan: Annotated[OptStrT, Field(..., description="Patient's plan")]


PlanT = TypeVar("PlanT", bound=OptStr)


# ----- SOAP ----- #
class SOAPDTO(
    Generic[
        OptSubjectiveDTOT,
        OptObjectiveDTOT,
        AssessmentT,
        PlanT,
    ],
):
    subjective: Annotated[OptSubjectiveDTOT, Field(..., description="Subjective")]
    objective: Annotated[OptObjectiveDTOT, Field(..., description="Objective")]
    assessment: Annotated[AssessmentT, Field(..., description="Patient's assessment")]
    plan: Annotated[PlanT, Field(..., description="Patient's plan")]


OptSOAPDTO = SOAPDTO | None
OptSOAPDTOT = TypeVar("OptSOAPDTOT", bound=OptSOAPDTO)


class FlexibleSOAPDTO(
    SOAPDTO[
        FlexibleSubjectiveDTO | None,
        FlexibleObjectiveDTO | None,
        OptStr,
        OptStr,
    ]
):
    subjective: Annotated[
        FlexibleSubjectiveDTO | None, Field(None, description="Subjective")
    ] = None
    objective: Annotated[
        FlexibleObjectiveDTO | None, Field(None, description="Objective")
    ] = None
    assessment: Annotated[OptStr, Field(None, description="Assessment")] = None
    plan: Annotated[OptStr, Field(None, description="Plan")] = None


class StrictSOAPDTO(
    SOAPDTO[
        StrictSubjectiveDTO,
        StrictObjectiveDTO,
        str,
        str,
    ]
):
    pass


class SOAPDTOMixin(BaseModel, Generic[OptSOAPDTOT]):
    soap: Annotated[OptSOAPDTOT, Field(..., description="SOAP")]
