from pydantic import BaseModel, Field
from typing import Annotated, Generic
from nexo.types.string import OptStrT


class Original(BaseModel, Generic[OptStrT]):
    original: Annotated[OptStrT, Field(..., description="Original Transcript")]
