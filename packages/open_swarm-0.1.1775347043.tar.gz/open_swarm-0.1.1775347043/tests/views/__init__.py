# Tests for swarm views
