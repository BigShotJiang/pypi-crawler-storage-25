import os
from dotenv import load_dotenv

load_dotenv()

JSON_INDENT = 2
SDS_QUERY_MAX_BATCH = 200

SYNC_DATA_SQL_MAX_BATCH = int(os.environ.get("SYNC_DATA_SQL_MAX_BATCH") or 10000)
SYNC_DATA_MAX_CONCURRENT = int(os.environ.get("SYNC_DATA_MAX_CONCURRENT") or 2)
SYNC_DATA_FILE_UPDATE_GAP = int(os.environ.get("SYNC_DATA_FILE_UPDATE_GAP") or 24)

SYNC_DATA_POSTGRE_HOST = os.environ.get("SYNC_DATA_POSTGRE_HOST")
SYNC_DATA_POSTGRE_PORT = os.environ.get("SYNC_DATA_POSTGRE_PORT")
SYNC_DATA_POSTGRE_USER = os.environ.get("SYNC_DATA_POSTGRE_USER")
SYNC_DATA_POSTGRE_PASSWORD = os.environ.get("SYNC_DATA_POSTGRE_PASSWORD")
SYNC_DATA_POSTGRE_DATABASE = os.environ.get("SYNC_DATA_POSTGRE_DATABASE")

SDS_MNG_LOGISTICS_PATH = (
    os.environ.get("SDS_MNG_LOGISTICS_PATH") or "sds_mng_logistics.json"
)
SDS_MNG_PRODUCTS_PATH = (
    os.environ.get("SDS_MNG_PRODUCTS_PATH") or "sds_mng_products.json"
)
