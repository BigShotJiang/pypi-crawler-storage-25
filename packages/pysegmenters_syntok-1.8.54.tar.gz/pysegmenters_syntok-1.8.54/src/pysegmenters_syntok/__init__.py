"""syntok segmenter"""

__version__ = "1.8.54"
