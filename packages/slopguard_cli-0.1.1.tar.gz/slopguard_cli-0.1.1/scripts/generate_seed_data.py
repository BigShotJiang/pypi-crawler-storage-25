#!/usr/bin/env python3
"""Generate ``slopguard/data/hallucinations_seed.json`` and ``popular_packages.json``.

This produces the PLACEHOLDER v0.1 seed described in the build spec §7. The human
operator will replace these files with curated data sourced from academic research and
a live LLM probing harness before any public release.

Run from the repo root::

    python scripts/generate_seed_data.py
"""

from __future__ import annotations

import json
import random
from pathlib import Path

random.seed(20260523)  # deterministic — date of v0.1 build spec freeze

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "slopguard" / "data"

# ---------------------------------------------------------------------------
# Popular package lists (synthesised — replace before release).
# ---------------------------------------------------------------------------

NPM_TOP_BASE = [
    "react", "react-dom", "lodash", "express", "axios", "moment", "chalk", "commander",
    "webpack", "vite", "rollup", "esbuild", "typescript", "ts-node", "babel-core",
    "@babel/core", "@babel/preset-env", "@babel/runtime", "core-js", "regenerator-runtime",
    "jquery", "underscore", "yargs", "minimist", "glob", "fs-extra", "rimraf", "mkdirp",
    "fast-glob", "chokidar", "nodemon", "pm2", "dotenv", "uuid", "nanoid", "ms",
    "debug", "prop-types", "classnames", "clsx", "react-router", "react-router-dom",
    "redux", "@reduxjs/toolkit", "react-redux", "zustand", "jotai", "recoil",
    "mobx", "mobx-react", "rxjs", "immer", "ramda", "date-fns", "dayjs", "luxon",
    "yup", "zod", "joi", "ajv", "validator", "express-validator", "helmet", "cors",
    "body-parser", "cookie-parser", "compression", "morgan", "passport", "passport-jwt",
    "jsonwebtoken", "bcrypt", "bcryptjs", "argon2", "crypto-js", "node-forge",
    "mongoose", "sequelize", "typeorm", "knex", "objection", "prisma", "@prisma/client",
    "pg", "mysql2", "sqlite3", "redis", "ioredis", "kafka-node", "amqplib",
    "socket.io", "socket.io-client", "ws", "graphql", "apollo-server", "@apollo/server",
    "@apollo/client", "graphql-tools", "type-graphql", "nestjs", "@nestjs/core",
    "@nestjs/common", "@nestjs/platform-express", "fastify", "koa", "@koa/router",
    "hapi", "@hapi/hapi", "next", "nuxt", "gatsby", "remix", "astro", "svelte",
    "sveltekit", "vue", "@vue/cli", "vue-router", "vuex", "pinia", "nuxt3", "quasar",
    "angular", "@angular/core", "@angular/common", "@angular/router", "rxjs",
    "ionic", "@ionic/angular", "@ionic/react", "electron", "tauri", "@tauri-apps/api",
    "node-sass", "sass", "less", "postcss", "autoprefixer", "tailwindcss",
    "styled-components", "emotion", "@emotion/react", "@emotion/styled", "framer-motion",
    "gsap", "lottie-web", "three", "@react-three/fiber", "@react-three/drei",
    "d3", "chart.js", "react-chartjs-2", "recharts", "victory", "highcharts",
    "leaflet", "react-leaflet", "mapbox-gl", "openlayers", "ol",
    "puppeteer", "playwright", "@playwright/test", "cypress", "selenium-webdriver",
    "jest", "@types/jest", "ts-jest", "mocha", "chai", "sinon", "jasmine",
    "vitest", "@testing-library/react", "@testing-library/jest-dom", "@testing-library/user-event",
    "supertest", "nock", "msw", "eslint", "prettier", "@typescript-eslint/eslint-plugin",
    "@typescript-eslint/parser", "eslint-plugin-react", "eslint-plugin-import", "husky",
    "lint-staged", "commitlint", "@commitlint/cli", "@commitlint/config-conventional",
    "semantic-release", "standard-version", "release-it", "changesets",
    "winston", "pino", "bunyan", "log4js", "consola", "ora", "boxen", "inquirer",
    "prompts", "execa", "shelljs", "cross-spawn", "concurrently", "npm-run-all",
    "node-fetch", "got", "request", "superagent", "form-data", "formidable", "multer",
    "sharp", "jimp", "imagemin", "svgo", "pdf-lib", "pdfkit", "html-pdf",
    "markdown-it", "remark", "rehype", "marked", "showdown", "highlight.js", "prismjs",
    "monaco-editor", "@monaco-editor/react", "codemirror", "@codemirror/state",
    "ace-builds", "react-ace", "quill", "react-quill", "tinymce",
    "moment-timezone", "node-cron", "cron", "agenda", "bull", "bullmq",
    "stripe", "@stripe/stripe-js", "@stripe/react-stripe-js", "twilio",
    "openai", "@anthropic-ai/sdk", "@google/generative-ai", "@google-cloud/storage",
    "@aws-sdk/client-s3", "@aws-sdk/client-dynamodb", "@aws-sdk/client-sqs", "aws-sdk",
    "firebase", "firebase-admin", "@supabase/supabase-js", "@vercel/postgres",
    "pusher-js", "pusher", "sendgrid", "@sendgrid/mail", "nodemailer", "mailgun-js",
    "react-hook-form", "formik", "react-final-form", "react-select", "react-table",
    "@tanstack/react-table", "@tanstack/react-query", "swr", "axios-retry",
    "react-icons", "lucide-react", "@heroicons/react", "@radix-ui/react-dialog",
    "@radix-ui/react-dropdown-menu", "@radix-ui/react-popover", "headlessui",
    "@headlessui/react", "antd", "@chakra-ui/react", "@mui/material", "@mui/icons-material",
    "@mantine/core", "@mantine/hooks", "shadcn-ui", "tailwind-merge", "cva",
    "i18next", "react-i18next", "react-intl", "moment-locales-webpack-plugin",
    "speakeasy", "otplib", "qrcode", "jsqr", "html5-qrcode",
    "react-toastify", "react-hot-toast", "sonner", "notistack",
    "swiper", "embla-carousel-react", "react-slick", "slick-carousel",
    "react-helmet", "react-helmet-async", "next-seo", "react-meta-tags",
    "react-dnd", "react-beautiful-dnd", "@dnd-kit/core", "react-grid-layout",
    "downshift", "use-debounce", "use-immer", "react-use", "ahooks",
    "konva", "react-konva", "fabric", "paper", "matter-js", "phaser",
    "tone", "wavesurfer.js", "howler", "video.js", "plyr", "react-player",
    "marked", "turndown", "html-react-parser", "dompurify", "sanitize-html",
    "jsdom", "cheerio", "puppeteer-extra", "puppeteer-core",
    "react-router-config", "history", "qs", "query-string", "url-parse",
    "lru-cache", "node-cache", "memory-cache", "keyv", "level", "lowdb",
    "kysely", "drizzle-orm", "edgedb", "surrealdb.js",
    "fast-csv", "csv-parser", "papaparse", "xlsx", "exceljs", "node-xlsx",
    "archiver", "yauzl", "yazl", "node-7z", "tar", "node-tar", "extract-zip",
    "minio", "@azure/storage-blob", "@google-cloud/pubsub", "@google-cloud/firestore",
    "@octokit/rest", "@octokit/graphql", "simple-git", "isomorphic-git", "nodegit",
    "@sentry/node", "@sentry/react", "@sentry/nextjs", "@datadog/browser-rum",
    "newrelic", "elastic-apm-node", "opentelemetry-api", "@opentelemetry/sdk-node",
    "winston-daily-rotate-file", "rotating-file-stream",
    "react-virtualized", "react-window", "@tanstack/react-virtual",
    "react-spring", "@react-spring/web", "react-transition-group", "auto-animate",
    "match-sorter", "fuzzysort", "fuse.js", "minisearch", "flexsearch", "lunr",
    "umzug", "node-pg-migrate", "knex-migrate", "typeorm-seeding",
    "@auth0/auth0-react", "@auth0/nextjs-auth0", "next-auth", "@clerk/clerk-react",
    "@clerk/nextjs", "lucia", "iron-session", "express-session",
    "react-pdf", "pdf.js-extract", "pdf-parse", "pdfjs-dist",
    "qr-image", "puppeteer-cluster", "playwright-extra",
    "openapi-typescript", "swagger-ui-express", "swagger-jsdoc", "redoc-express",
    "fastify-swagger", "@fastify/swagger", "@fastify/cors", "@fastify/helmet",
    "tsx", "tsup", "unbuild", "microbundle", "ncc", "@vercel/ncc", "pkg",
    "browser-sync", "live-server", "json-server", "msw-browser",
    "react-native", "expo", "@react-navigation/native", "@react-navigation/stack",
    "react-native-paper", "react-native-elements", "nativewind", "tamagui",
    "node-pty", "xterm", "blessed", "ink", "react-ink",
    "wait-on", "tcp-port-used", "get-port", "detect-port",
    "depcheck", "npm-check-updates", "audit-ci", "patch-package", "syncpack",
    "lerna", "nx", "turbo", "rush", "pnpm", "yarn",
    "react-error-boundary", "react-async", "react-suspense", "use-context-selector",
    "react-tracked", "valtio", "constate", "easy-peasy", "rematch",
    "react-flow", "reactflow", "react-flow-renderer", "react-konva-utils",
    "react-tooltip", "tippy.js", "@tippyjs/react", "react-popper", "@popperjs/core",
    "react-tabs", "react-modal", "react-overlays", "rc-tooltip", "rc-tree",
    "rc-table", "rc-pagination", "rc-dialog", "rc-select", "rc-dropdown",
    "react-content-loader", "react-loading-skeleton", "react-spinners",
    "spin.js", "nprogress", "react-top-loading-bar",
    "@trpc/server", "@trpc/client", "@trpc/react-query", "@trpc/next",
    "drizzle-kit", "kysely-codegen", "@graphql-codegen/cli", "@graphql-codegen/typescript",
    "urql", "react-relay", "relay-runtime", "relay-compiler",
    "remeda", "rambda", "ts-pattern", "neverthrow", "fp-ts", "io-ts",
    "purify-ts", "monocle-ts", "lens.ts", "immutable", "mori",
    "react-virtual", "virtua", "react-cool-virtual",
    "react-intersection-observer", "react-on-screen", "react-visibility-sensor",
    "react-detect-offline", "react-network-status", "is-online",
    "browser-image-compression", "image-compressor.js", "compressorjs",
    "react-image-crop", "react-easy-crop", "cropperjs", "react-cropper",
    "react-color", "react-colorful", "color", "colord", "tinycolor2",
    "ag-grid-community", "ag-grid-react", "handsontable", "tabulator-tables",
    "datatables.net", "datatables.net-dt", "datatables.net-react",
    "react-data-grid", "react-bootstrap-table-next", "react-virtualized-tree",
    "fast-deep-equal", "deep-equal", "lodash.isequal", "shallowequal",
    "react-fast-compare", "use-deep-compare-effect", "use-deep-compare",
    "stream-buffers", "concat-stream", "through2", "split2", "pump",
    "node-stream-zip", "fast-folder-size", "fdir", "globby", "tinyglobby",
    "@actions/core", "@actions/github", "@actions/exec", "@actions/io",
    "octokit", "@octokit/auth-app", "@octokit/webhooks", "probot",
    "marked-terminal", "ink-spinner", "ink-text-input", "ink-select-input",
    "yargs-parser", "meow", "mri", "args", "sade", "cleye",
    "comlink", "workerize", "threads", "piscina", "tinypool", "node-worker-threads-pool",
    "@types/node", "@types/react", "@types/react-dom", "@types/express",
    "@types/lodash", "@types/jest", "@types/mocha", "@types/chai", "@types/cors",
    "@types/jsonwebtoken", "@types/bcryptjs", "@types/uuid", "@types/multer",
]

PYPI_TOP_BASE = [
    "requests", "urllib3", "certifi", "charset-normalizer", "idna", "six", "python-dateutil",
    "setuptools", "wheel", "pip", "packaging", "typing-extensions", "attrs",
    "pyyaml", "click", "jinja2", "markupsafe", "werkzeug", "flask", "itsdangerous",
    "blinker", "django", "asgiref", "sqlparse", "pillow", "numpy", "scipy", "pandas",
    "matplotlib", "seaborn", "plotly", "bokeh", "altair", "scikit-learn", "scikit-image",
    "statsmodels", "sympy", "networkx", "tqdm", "joblib", "threadpoolctl",
    "fastapi", "starlette", "pydantic", "pydantic-core", "annotated-types",
    "uvicorn", "uvloop", "httptools", "websockets", "watchfiles", "python-multipart",
    "httpx", "httpcore", "h11", "h2", "hpack", "hyperframe", "anyio", "sniffio",
    "trio", "trio-websocket", "wsproto", "aiohttp", "aiosignal", "frozenlist",
    "yarl", "multidict", "async-timeout", "aiofiles", "aiosqlite", "asyncpg",
    "psycopg2", "psycopg2-binary", "psycopg", "psycopg-binary", "psycopg-pool",
    "sqlalchemy", "alembic", "mako", "greenlet", "tenacity", "backoff",
    "boto3", "botocore", "s3transfer", "jmespath", "aiobotocore", "aiohttp-retry",
    "google-cloud-storage", "google-cloud-bigquery", "google-cloud-pubsub",
    "google-cloud-firestore", "google-cloud-secret-manager", "google-auth",
    "google-auth-oauthlib", "google-api-python-client", "google-api-core",
    "googleapis-common-protos", "protobuf", "grpcio", "grpcio-tools", "grpcio-status",
    "azure-storage-blob", "azure-identity", "azure-core", "msal", "msal-extensions",
    "azure-functions", "azure-keyvault", "azure-mgmt-core",
    "openai", "anthropic", "langchain", "langchain-core", "langchain-community",
    "langchain-openai", "langchain-anthropic", "langsmith", "langgraph",
    "llama-index", "llama-index-core", "llama-index-llms-openai", "llama-index-embeddings-openai",
    "transformers", "tokenizers", "huggingface-hub", "datasets", "accelerate",
    "peft", "trl", "evaluate", "sentence-transformers", "sentencepiece",
    "torch", "torchvision", "torchaudio", "torchtext", "pytorch-lightning",
    "lightning", "tensorflow", "tensorboard", "keras", "keras-cv", "keras-nlp",
    "jax", "jaxlib", "flax", "optax", "equinox", "diffrax",
    "openai-whisper", "whisperx", "faster-whisper", "speech-recognition", "speechbrain",
    "ffmpeg-python", "moviepy", "opencv-python", "opencv-python-headless", "opencv-contrib-python",
    "pyaudio", "sounddevice", "librosa", "soundfile", "pydub",
    "spacy", "thinc", "blis", "preshed", "cymem", "wasabi", "srsly", "catalogue",
    "nltk", "gensim", "textblob", "polyglot", "stanza", "flair",
    "selenium", "playwright", "puppeteer", "pyppeteer", "splinter",
    "beautifulsoup4", "lxml", "html5lib", "soupsieve", "parsel", "feedparser",
    "scrapy", "twisted", "queuelib", "service-identity", "incremental",
    "pytest", "pytest-asyncio", "pytest-cov", "pytest-mock", "pytest-xdist",
    "pytest-django", "pytest-flask", "pytest-anyio", "pytest-trio",
    "pytest-httpx", "respx", "responses", "betamax", "vcrpy",
    "coverage", "tox", "nox", "hypothesis", "factory-boy", "faker", "model-bakery",
    "freezegun", "time-machine", "mock", "asynctest", "pytest-watch",
    "black", "ruff", "isort", "flake8", "pycodestyle", "pyflakes", "mccabe",
    "mypy", "pyright", "pyre-check", "pytype", "monkeytype", "typeguard",
    "bandit", "safety", "pip-audit", "pip-tools", "pip-licenses", "pipdeptree",
    "twine", "build", "hatchling", "hatch", "poetry", "poetry-core", "flit",
    "setuptools-scm", "versioneer", "bump2version", "bumpver", "commitizen",
    "sphinx", "sphinx-rtd-theme", "myst-parser", "sphinx-autodoc-typehints",
    "mkdocs", "mkdocs-material", "mkdocstrings", "mkdocstrings-python",
    "pdoc", "pdoc3", "interrogate", "pyment",
    "celery", "kombu", "billiard", "vine", "amqp", "redis", "hiredis", "aioredis",
    "rq", "huey", "dramatiq", "apscheduler", "schedule", "cron-converter",
    "kafka-python", "confluent-kafka", "aiokafka", "pulsar-client", "stomp.py",
    "pika", "aio-pika", "py-amqp", "kombu",
    "pymongo", "motor", "beanie", "mongoengine", "cassandra-driver", "neo4j",
    "py2neo", "redis-py-cluster", "rediscluster", "elasticsearch",
    "elasticsearch-dsl", "opensearch-py", "meilisearch", "weaviate-client",
    "qdrant-client", "pinecone-client", "chromadb", "milvus", "pymilvus",
    "lancedb", "deeplake", "annoy", "faiss-cpu", "faiss-gpu", "hnswlib",
    "rich", "textual", "prompt-toolkit", "blessed", "blessings", "colorama",
    "termcolor", "tabulate", "prettytable", "pyfiglet", "halo", "yaspin", "alive-progress",
    "click-completion", "typer", "fire", "argparse", "docopt", "configargparse",
    "python-dotenv", "environs", "dynaconf", "pydantic-settings", "toml", "tomli",
    "tomli-w", "tomlkit", "ruamel.yaml", "yamllint", "shyaml",
    "pyjwt", "authlib", "python-jose", "cryptography", "pyopenssl", "pyca-cryptography",
    "passlib", "bcrypt", "argon2-cffi", "argon2-cffi-bindings", "pyotp",
    "qrcode", "pyqrcode", "python-barcode", "treepoem", "pyzbar",
    "stripe", "twilio", "sendgrid", "mailgun", "mailchimp-marketing", "postmark",
    "django-allauth", "django-rest-framework", "djangorestframework", "django-cors-headers",
    "django-debug-toolbar", "django-extensions", "django-environ", "django-redis",
    "django-celery-beat", "django-celery-results", "django-storages",
    "flask-login", "flask-sqlalchemy", "flask-migrate", "flask-jwt-extended",
    "flask-cors", "flask-restful", "flask-restx", "flask-smorest", "flask-marshmallow",
    "marshmallow", "marshmallow-sqlalchemy", "marshmallow-dataclass", "apispec",
    "webargs", "flask-wtf", "wtforms", "flask-babel", "flask-mail",
    "boto", "moto", "localstack", "tinydb", "shelve", "pickledb", "diskcache",
    "cachetools", "aiocache", "redis-cache", "django-cache-memoize",
    "cookiecutter", "jinja2-cli", "jinjasql", "jinja2-time", "jinja2-async-environment",
    "watchdog", "watchgod", "python-multipart", "aiomultiprocess",
    "structlog", "loguru", "logbook", "concurrent-log-handler", "python-json-logger",
    "sentry-sdk", "rollbar", "bugsnag", "datadog", "newrelic", "elastic-apm",
    "opentelemetry-api", "opentelemetry-sdk", "opentelemetry-exporter-otlp",
    "opentelemetry-instrumentation", "opentelemetry-instrumentation-fastapi",
    "opentelemetry-instrumentation-requests", "opentelemetry-instrumentation-sqlalchemy",
    "prometheus-client", "starlette-prometheus", "django-prometheus",
    "asgiref", "uvicorn-worker", "gunicorn", "hypercorn", "daphne", "waitress",
    "supervisor", "honcho", "foreman",
    "nicegui", "streamlit", "gradio", "panel", "dash", "voila", "shiny",
    "reflex", "anvil-app-server", "anvil-uplink",
    "pyqt5", "pyqt6", "pyside6", "pyside2", "kivy", "pygame", "pyglet",
    "arcade", "ursina", "moderngl", "moderngl-window",
    "psutil", "py-cpuinfo", "gputil", "nvidia-ml-py", "pynvml", "memory-profiler",
    "line-profiler", "py-spy", "scalene", "snakeviz", "objgraph", "tracemalloc",
    "more-itertools", "toolz", "cytoolz", "funcy", "boltons", "returns",
    "result", "expression", "rustpy", "trio-util",
    "dataclasses-json", "marshmallow-dataclass", "pydantic-settings", "msgspec",
    "msgpack", "ormsgpack", "cbor2", "ujson", "orjson", "rapidjson", "simplejson",
    "pyarrow", "fastparquet", "polars", "duckdb", "dask", "ray", "modin",
    "vaex", "ibis-framework", "pyspark", "koalas", "petl", "bonobo", "luigi",
    "apache-airflow", "apache-airflow-providers-google", "apache-airflow-providers-amazon",
    "prefect", "prefect-aws", "prefect-gcp", "dagster", "dagster-pandas", "dagster-aws",
    "mlflow", "wandb", "neptune-client", "comet-ml", "clearml", "guildai",
    "dvc", "lakefs-client", "delta-spark", "deltalake", "iceberg-python",
    "graphviz", "pydot", "pygraphviz", "diagrams", "mermaid-py",
    "openpyxl", "xlrd", "xlwt", "xlsxwriter", "tablib", "xlsx2html", "xlsxio",
    "python-docx", "docx2txt", "python-pptx", "reportlab", "weasyprint",
    "pdfplumber", "pdfminer-six", "pdfminer.six", "pypdf2", "pypdf", "pikepdf",
    "fpdf2", "borb", "pdfrw", "pdf2docx",
    "pre-commit", "detect-secrets", "git-secrets", "gitpython", "pygit2", "dulwich",
    "pyinstaller", "py2app", "py2exe", "cx-freeze", "nuitka", "briefcase",
    "supabase", "supabase-py", "firebase-admin", "google-cloud-aiplatform",
    "vertexai", "cohere", "mistralai", "groq", "together", "replicate",
    "pyngrok", "localtunnel", "cloudflare", "fly", "render", "vercel",
    "fastapi-users", "fastapi-cache", "fastapi-pagination", "fastapi-utils",
    "fastapi-mail", "fastapi-jwt-auth", "fastapi-security", "fastapi-limiter",
    "django-ninja", "ninja-extra", "django-ratelimit", "django-axes",
    "litestar", "ellar", "robyn", "aiohttp-jinja2", "aiohttp-session",
    "trio-asyncio", "anyio-stream", "asyncer", "asyncstdlib", "aiostream",
    "click-default-group", "click-plugins", "click-help-colors", "click-config-file",
    "questionary", "rich-click", "trogon", "textual-dev",
    "polars-lts-cpu", "pyspark-stubs", "pandas-stubs", "types-requests",
    "types-pyyaml", "types-python-dateutil", "types-six", "types-toml",
    "humanize", "babel", "python-slugify", "unidecode", "python-stdnum",
    "phonenumbers", "email-validator", "validators", "uri-template",
    "iso8601", "pytz", "pendulum", "arrow", "delorean", "maya", "pytz-deprecation-shim",
    "ipython", "jupyter", "jupyterlab", "notebook", "jupyter-client", "jupyter-core",
    "ipykernel", "ipywidgets", "nbformat", "nbconvert", "voila", "jupyterhub",
    "papermill", "nbdime", "nbqa", "nbstripout", "treon",
    "biopython", "pysam", "pyvcf", "pybedtools", "pysam-utils",
    "rdkit", "openbabel", "ase", "pymatgen", "mdtraj",
    "pyserial", "pyusb", "hidapi", "bleak", "pybluez", "gpiozero", "rpi.gpio",
    "smbus2", "spidev", "adafruit-blinka", "adafruit-circuitpython-busdevice",
    "paho-mqtt", "asyncio-mqtt", "gmqtt", "hbmqtt", "amqtt",
]


def _truncate_to(items: list[str], target: int, prefix_pool: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for n in items:
        nn = n.strip()
        if nn and nn not in seen:
            seen.add(nn)
            out.append(nn)
        if len(out) >= target:
            break
    # Pad with deterministic synthesised names if shorter.
    i = 0
    while len(out) < target:
        seed = prefix_pool[i % len(prefix_pool)]
        candidate = f"{seed}-{i}"
        if candidate not in seen:
            seen.add(candidate)
            out.append(candidate)
        i += 1
    return out


def build_popular() -> dict:
    npm = _truncate_to(NPM_TOP_BASE, 1000, ["pkg", "module", "lib", "tool", "helper", "util", "core"])
    pypi = _truncate_to(PYPI_TOP_BASE, 1000, ["py-pkg", "module", "lib", "tool", "helper", "util", "core"])
    return {"schema_version": 1, "npm_top_1000": npm, "pypi_top_1000": pypi}


# ---------------------------------------------------------------------------
# Hallucination seed entries.
# ---------------------------------------------------------------------------

MODELS = [
    "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo", "claude-3-7-sonnet", "claude-3-5-sonnet",
    "claude-3-opus", "claude-3-haiku", "gemini-1.5-pro", "gemini-1.5-flash",
    "llama-3.1-70b", "llama-3.3-70b", "llama-3.1-405b", "qwen-2.5-72b", "mistral-large-2",
    "deepseek-coder-v2", "deepseek-v3", "codestral-22b", "codellama-34b",
]

CONFLATION_SUFFIXES = [
    "helpers", "helper", "utils", "util", "async", "pro", "kit", "sdk", "tools",
    "tool", "extras", "extra", "plus", "next", "core", "io", "x", "lite",
]

NPM_STEMS = [
    "react", "vue", "angular", "svelte", "next", "nuxt", "express", "fastify", "koa",
    "axios", "lodash", "moment", "prisma", "graphql", "apollo", "redux", "jest",
    "vitest", "cypress", "playwright", "tailwind", "webpack", "vite", "esbuild",
    "babel", "rollup", "rxjs", "socket", "mongoose", "sequelize", "typeorm",
    "openai", "anthropic", "langchain", "node-fetch", "puppeteer", "sharp",
]

PYPI_STEMS = [
    "requests", "django", "flask", "fastapi", "starlette", "sqlalchemy", "pydantic",
    "numpy", "pandas", "scipy", "matplotlib", "scikit", "torch", "tensorflow",
    "huggingface", "transformers", "langchain", "openai", "anthropic", "boto",
    "google-cloud", "azure", "pytest", "celery", "redis", "kafka", "mongo",
    "elasticsearch", "asyncio", "httpx", "uvicorn", "rich", "click", "typer",
]


def _gen_pattern_entries(n: int) -> list[dict]:
    """Category 1: ~100 stem + classic hallucination suffix combinations."""
    out: list[dict] = []
    rng = random.Random(1)
    while len(out) < n:
        eco = rng.choice(["npm", "pypi"])
        stems = NPM_STEMS if eco == "npm" else PYPI_STEMS
        stem = rng.choice(stems)
        suffix = rng.choice(CONFLATION_SUFFIXES)
        name = f"{stem}-{suffix}"
        out.append({
            "name": name,
            "ecosystem": eco,
            "first_seen": _stamp(rng),
            "recurrence_rate": round(rng.uniform(0.45, 0.85), 2),
            "models_observed": rng.sample(MODELS, k=rng.randint(2, 4)),
            "notes": f"Conflated stem '{stem}' with common hallucination suffix '-{suffix}'.",
        })
    return _dedupe(out)


def _gen_variant_entries(n: int) -> list[dict]:
    """Category 2: ~200 plausible non-existent variants of popular packages."""
    out: list[dict] = []
    rng = random.Random(2)
    variants = [
        ("{stem}-v{ver}", lambda r: r.choice(["6", "7", "8", "9", "10"])),
        ("{stem}-async", lambda _: ""),
        ("{stem}-types", lambda _: ""),
        ("{stem}-config", lambda _: ""),
        ("{stem}-cli", lambda _: ""),
        ("{stem}-client", lambda _: ""),
        ("{stem}-server", lambda _: ""),
        ("{stem}-typed", lambda _: ""),
        ("{stem}-modern", lambda _: ""),
        ("{stem}-fast", lambda _: ""),
        ("{stem}-ts", lambda _: ""),
        ("{stem}-py", lambda _: ""),
        ("{stem}-go", lambda _: ""),
        ("react-{stem}", lambda _: ""),
        ("next-{stem}", lambda _: ""),
        ("@{stem}/core", lambda _: ""),
        ("@{stem}/helpers", lambda _: ""),
    ]
    while len(out) < n:
        eco = rng.choice(["npm", "pypi"])
        stems = NPM_STEMS if eco == "npm" else PYPI_STEMS
        tmpl, fn = rng.choice(variants)
        stem = rng.choice(stems)
        try:
            name = tmpl.format(stem=stem, ver=fn(rng))
        except KeyError:
            name = tmpl.format(stem=stem)
        # PyPI doesn't use @scope/pkg syntax.
        if name.startswith("@") and eco == "pypi":
            continue
        out.append({
            "name": name,
            "ecosystem": eco,
            "first_seen": _stamp(rng),
            "recurrence_rate": round(rng.uniform(0.30, 0.70), 2),
            "models_observed": rng.sample(MODELS, k=rng.randint(1, 3)),
            "notes": f"Plausible-sounding variant of popular package family '{stem}'; not currently published.",
        })
    return _dedupe(out)


def _gen_research_entries(n: int) -> list[dict]:
    """Category 3: ~200 entries matching academically-documented hallucination shapes.

    Synthesised here per spec §7; replace with the curated corpus before release.
    """
    out: list[dict] = []
    rng = random.Random(3)
    shapes = [
        "{a}-{b}-utils",
        "{a}-{b}-helpers",
        "{a}-{b}-async",
        "{a}-{b}-types",
        "{a}-{b}",
        "{a}{b}",
        "py-{a}-{b}",
        "node-{a}-{b}",
        "{a}-{b}-py",
        "{a}-{b}-ts",
        "auto-{a}-{b}",
        "smart-{a}-{b}",
        "easy-{a}-{b}",
        "simple-{a}-{b}",
        "{a}-toolkit",
        "{a}-extensions",
    ]
    seed_words = [
        "auth", "session", "token", "validator", "router", "schema", "client", "store",
        "cache", "queue", "task", "worker", "agent", "stream", "event", "logger",
        "config", "logger", "fetch", "render", "parser", "compiler", "runtime",
        "serializer", "deserializer", "middleware", "guard", "interceptor",
        "telemetry", "tracing", "metrics", "observability",
    ]
    while len(out) < n:
        eco = rng.choice(["npm", "pypi"])
        a = rng.choice(seed_words)
        b = rng.choice(seed_words)
        if a == b:
            continue
        shape = rng.choice(shapes)
        name = shape.format(a=a, b=b)
        out.append({
            "name": name,
            "ecosystem": eco,
            "first_seen": _stamp(rng),
            "recurrence_rate": round(rng.uniform(0.20, 0.60), 2),
            "models_observed": rng.sample(MODELS, k=rng.randint(1, 3)),
            "notes": "Matches academic LLM-suggested-package hallucination pattern (synthesised).",
        })
    return _dedupe(out)


def _stamp(rng: random.Random) -> str:
    year = rng.choice(["2025", "2026"])
    month = rng.randint(1, 12)
    day = rng.randint(1, 28)
    return f"{year}-{month:02d}-{day:02d}"


def _dedupe(entries: list[dict]) -> list[dict]:
    seen: set[tuple[str, str]] = set()
    out: list[dict] = []
    for e in entries:
        key = (e["ecosystem"], e["name"].lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(e)
    return out


def build_hallucinations() -> dict:
    pattern = _gen_pattern_entries(110)
    variants = _gen_variant_entries(220)
    research = _gen_research_entries(220)
    entries = _dedupe(pattern + variants + research)[:500]
    # Always include two canonical examples for tests and docs.
    canonical = [
        {
            "name": "react-codeshift",
            "ecosystem": "npm",
            "first_seen": "2026-01-15",
            "recurrence_rate": 0.71,
            "models_observed": ["gpt-4o", "claude-3-7-sonnet", "gpt-4-turbo"],
            "notes": "Conflation of 'react' and 'jscodeshift'; widely reported test case.",
        },
        {
            "name": "langchain-helpers",
            "ecosystem": "pypi",
            "first_seen": "2025-11-02",
            "recurrence_rate": 0.62,
            "models_observed": ["llama-3.3-70b", "qwen-2.5-72b"],
            "notes": "Generic-helpers hallucination; recurring across open-source LLMs.",
        },
    ]
    entries = _dedupe(canonical + entries)[:500]
    return {
        "_internal_note": (
            "WARNING: SEED DATA — REPLACE BEFORE LAUNCH. Synthesised placeholder for v0.1; "
            "operator must replace with curated entries from academic research + live probing."
        ),
        "schema_version": 1,
        "updated": "2026-05-23",
        "entries": entries,
    }


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    halluc = build_hallucinations()
    popular = build_popular()
    (DATA_DIR / "hallucinations_seed.json").write_text(
        json.dumps(halluc, indent=2) + "\n", encoding="utf-8"
    )
    (DATA_DIR / "popular_packages.json").write_text(
        json.dumps(popular, indent=2) + "\n", encoding="utf-8"
    )
    print(f"wrote {len(halluc['entries'])} hallucination entries")
    print(f"wrote {len(popular['npm_top_1000'])} npm + {len(popular['pypi_top_1000'])} pypi popular packages")


if __name__ == "__main__":
    main()
