"""Edge-case tests to round out coverage on smaller modules."""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import respx
from typer.testing import CliRunner

from slopguard.__main__ import main as main_entry
from slopguard.cli import app
from slopguard.config import (
    ConfigError,
    FileConfig,
    default_config_path,
    load_file_config,
    resolve,
)
from slopguard.parsers.npm import NpmParser
from slopguard.registry.npm import NPM_DOWNLOADS, NPM_REGISTRY, NpmRegistryClient
from slopguard.registry.pypi import PYPI_JSON, PYPISTATS_RECENT, PypiRegistryClient


def test_main_entry_invokes_typer(monkeypatch: pytest.MonkeyPatch) -> None:
    # Run via the __main__ shim and assert the version command emits exit-code 0.
    monkeypatch.setattr("sys.argv", ["slopguard", "version"])
    with pytest.raises(SystemExit) as exc_info:
        main_entry()
    assert exc_info.value.code == 0


def test_update_stub_runs() -> None:
    from slopguard.update import run

    assert run() == 0


def test_npm_parser_lockfile_v1(tmp_path: Path) -> None:
    payload = {
        "name": "demo",
        "version": "1.0.0",
        "lockfileVersion": 1,
        "dependencies": {
            "lodash": {"version": "4.17.21"},
            "react": {"version": "18.2.0"},
            "broken": "not a dict",
        },
    }
    p = tmp_path / "package-lock.json"
    p.write_text(json.dumps(payload))
    deps = NpmParser().parse(p)
    names = {d.name for d in deps}
    assert "lodash" in names
    assert "react" in names
    assert "broken" not in names


def test_load_invalid_yaml_raises(tmp_path: Path) -> None:
    p = tmp_path / ".slopguard.yaml"
    p.write_text("not: [valid: yaml")
    with pytest.raises(ConfigError):
        load_file_config(p)


def test_load_top_level_not_mapping_raises(tmp_path: Path) -> None:
    p = tmp_path / ".slopguard.yaml"
    p.write_text("- just\n- a\n- list\n")
    with pytest.raises(ConfigError):
        load_file_config(p)


def test_resolve_invalid_fail_on_raises() -> None:
    with pytest.raises(ConfigError):
        resolve(
            FileConfig(),
            cli_fail_on="banana",
            cli_no_network=False,
            cli_timeout=None,
            cli_concurrency=None,
        )


def test_resolve_invalid_pattern_raises(tmp_path: Path) -> None:
    p = tmp_path / ".slopguard.yaml"
    p.write_text("ignore:\n  patterns:\n    - '['\n")
    cfg = load_file_config(p)
    with pytest.raises(ConfigError):
        resolve(
            cfg,
            cli_fail_on=None,
            cli_no_network=False,
            cli_timeout=None,
            cli_concurrency=None,
        )


def test_default_config_path_walks_parents(tmp_path: Path) -> None:
    nested = tmp_path / "a" / "b" / "c"
    nested.mkdir(parents=True)
    cfg = tmp_path / "a" / ".slopguard.yaml"
    cfg.write_text("fail_on: any\n")
    assert default_config_path(nested) == cfg


def test_default_config_path_missing_returns_none(tmp_path: Path) -> None:
    assert default_config_path(tmp_path) is None


@pytest.mark.asyncio
@respx.mock
async def test_pypi_falls_back_to_maintainer_when_author_missing() -> None:
    payload = {
        "info": {"author": None, "maintainer": "Backup Owner"},
        "releases": {},
    }
    respx.get(f"{PYPI_JSON}/orphan-pkg/json").mock(return_value=httpx.Response(200, json=payload))
    respx.get(f"{PYPISTATS_RECENT}/orphan-pkg/recent").mock(
        return_value=httpx.Response(200, json={"data": {}})
    )
    async with PypiRegistryClient() as client:
        meta = await client.fetch("orphan-pkg")
    assert meta.publisher == "Backup Owner"
    assert meta.first_release is None  # no release files


@pytest.mark.asyncio
@respx.mock
async def test_npm_invalid_json_raises_registry_error() -> None:
    from slopguard.registry.base import RegistryError

    respx.get(f"{NPM_REGISTRY}/garbled").mock(return_value=httpx.Response(200, content=b"not json"))
    async with NpmRegistryClient() as client:
        with pytest.raises(RegistryError):
            await client.fetch("garbled")


def test_scan_specific_file(tmp_path: Path) -> None:
    """When PATH is a single manifest, scan only that file."""
    runner = CliRunner()
    pkg = tmp_path / "package.json"
    pkg.write_text(json.dumps({"name": "x", "dependencies": {"react": "^18.0.0"}}))
    result = runner.invoke(app, ["scan", str(pkg), "--no-network"])
    # No DB hits and only clean deps → exit 0.
    assert result.exit_code == 0


def test_scan_terminal_with_no_findings(tmp_path: Path) -> None:
    runner = CliRunner()
    pkg = tmp_path / "package.json"
    pkg.write_text(json.dumps({"name": "x", "dependencies": {"react": "^18.0.0"}}))
    result = runner.invoke(app, ["scan", str(pkg), "--no-network"])
    assert "All dependencies clean." in result.stdout or "CLEAN" in result.stdout


def test_unused_npm_downloads_404_returns_none() -> None:
    """NpmRegistryClient._fetch_downloads soft-fails — exercise the 404 path."""

    import asyncio

    @respx.mock
    async def _run() -> None:
        respx.get(f"{NPM_REGISTRY}/x").mock(
            return_value=httpx.Response(
                200, json={"time": {"created": "2020-01-01T00:00:00Z"}, "maintainers": []}
            )
        )
        respx.get(f"{NPM_DOWNLOADS}/x").mock(return_value=httpx.Response(404))
        async with NpmRegistryClient() as client:
            meta = await client.fetch("x")
        assert meta.exists is True
        assert meta.downloads_recent is None

    asyncio.run(_run())
