"""Tests for the scoring engine — per-signal coverage + three combined scenarios."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import cast

import pytest

from slopguard.data import load_hallucination_db, load_popular_packages
from slopguard.models import Dependency, DependencySource, Ecosystem, HallucinationEntry, RiskTier
from slopguard.registry.base import PackageMetadata, RegistryClient, RegistryError
from slopguard.scoring import signals
from slopguard.scoring.engine import ScoringConfig, ScoringEngine


class FakeRegistry(RegistryClient):
    """In-memory fake registry, no HTTP. Lets tests script per-name responses."""

    def __init__(self, table: dict[str, PackageMetadata | RegistryError]) -> None:
        self._table = table
        self._cache: dict[str, PackageMetadata] = {}

    async def fetch(self, name: str) -> PackageMetadata:  # type: ignore[override]
        if name in self._cache:
            return self._cache[name]
        entry = self._table.get(name)
        if entry is None:
            entry = PackageMetadata(name=name, exists=False)
        if isinstance(entry, RegistryError):
            raise entry
        self._cache[name] = entry
        return entry

    async def _fetch_uncached(self, name: str) -> PackageMetadata:  # pragma: no cover - unused
        raise NotImplementedError

    async def aclose(self) -> None:  # pragma: no cover
        return None


def _dep(name: str, ecosystem: Ecosystem = Ecosystem.NPM, **kw: object) -> Dependency:
    return Dependency(
        name=name,
        version=cast(str | None, kw.get("version")),
        ecosystem=ecosystem,
        manifest=cast(str, kw.get("manifest", "package.json")),
        source=cast(DependencySource, kw.get("source", DependencySource.REGISTRY)),
        scoped=cast(bool, kw.get("scoped", bool(name.startswith("@")))),
    )


def test_levenshtein_basic() -> None:
    assert signals.levenshtein("react", "react") == 0
    assert signals.levenshtein("react", "reakt") == 1
    assert signals.levenshtein("requests", "request") == 1
    assert signals.levenshtein("openai", "openai-utils") > 2


def test_recently_published_thresholds() -> None:
    now = datetime.now(UTC)
    meta_very = PackageMetadata(name="x", exists=True, first_release=now - timedelta(days=3))
    meta_recent = PackageMetadata(name="x", exists=True, first_release=now - timedelta(days=20))
    meta_old = PackageMetadata(name="x", exists=True, first_release=now - timedelta(days=400))
    very, recent = signals.recently_published(meta_very)
    assert very is not None and recent is None
    very, recent = signals.recently_published(meta_recent)
    assert very is None and recent is not None
    very, recent = signals.recently_published(meta_old)
    assert very is None and recent is None


def test_name_pattern_signal() -> None:
    assert signals.name_pattern_suspicious(_dep("react-helpers")) is not None
    assert signals.name_pattern_suspicious(_dep("openai-utils")) is not None
    assert signals.name_pattern_suspicious(_dep("react")) is None


def test_low_downloads_signal() -> None:
    meta_low = PackageMetadata(name="x", exists=True, downloads_recent=10)
    meta_ok = PackageMetadata(name="x", exists=True, downloads_recent=1000)
    assert signals.low_downloads(meta_low) is not None
    assert signals.low_downloads(meta_ok) is None


def test_new_publisher_and_solo_new_account() -> None:
    now = datetime.now(UTC)
    young = now - timedelta(days=10)
    older = now - timedelta(days=120)
    meta = PackageMetadata(
        name="x", exists=True, publisher_created=young, publisher_package_count=1
    )
    assert signals.new_publisher(meta) is not None
    assert signals.single_release_new_account(meta) is not None
    meta2 = PackageMetadata(
        name="x", exists=True, publisher_created=older, publisher_package_count=1
    )
    assert signals.new_publisher(meta2) is None
    assert signals.single_release_new_account(meta2) is None


def test_levenshtein_typo_uses_popular_set() -> None:
    popular = frozenset({"react", "lodash", "express"})
    # 'reactt' is Levenshtein 1 from 'react'.
    sig = signals.levenshtein_typo(_dep("reactt"), popular)
    assert sig is not None and "react" in sig.detail
    # an actual popular package returns None.
    assert signals.levenshtein_typo(_dep("react"), popular) is None
    # something far away returns None.
    assert signals.levenshtein_typo(_dep("totally-unrelated"), popular) is None


@pytest.mark.asyncio
async def test_db_hit_short_circuits_to_hallucinated(monkeypatch: pytest.MonkeyPatch) -> None:
    fake_entry = HallucinationEntry(
        name="react-codeshift",
        ecosystem=Ecosystem.NPM,
        first_seen="2026-01-15",
        recurrence_rate=0.71,
        models_observed=["gpt-4o"],
        notes="test",
    )
    monkeypatch.setattr(
        "slopguard.scoring.engine.hallucination_index",
        lambda: {(Ecosystem.NPM, "react-codeshift"): fake_entry},
    )
    monkeypatch.setattr("slopguard.scoring.engine.popular_set", lambda _eco: frozenset())
    engine = ScoringEngine(
        npm_client=FakeRegistry({}),
        pypi_client=FakeRegistry({}),
    )
    [finding] = await engine.score_all([_dep("react-codeshift")])
    assert finding.risk is RiskTier.HALLUCINATED
    assert finding.score >= 0.9
    assert any(s.type == "hallucination_db_hit" for s in finding.signals)


@pytest.mark.asyncio
async def test_not_found_plus_new_publisher_plus_typo_is_hallucinated(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("slopguard.scoring.engine.hallucination_index", lambda: {})
    monkeypatch.setattr(
        "slopguard.scoring.engine.popular_set",
        lambda eco: frozenset({"react"}) if eco is Ecosystem.NPM else frozenset(),
    )
    fake = FakeRegistry({"reactt": PackageMetadata(name="reactt", exists=False)})
    engine = ScoringEngine(npm_client=fake, pypi_client=FakeRegistry({}))
    [finding] = await engine.score_all([_dep("reactt")])
    types = {s.type for s in finding.signals}
    assert "registry_not_found" in types
    assert "levenshtein_typo" in types
    # 0.85 (not found) + 0.25 (typo) caps to 1.0 → hallucinated
    assert finding.risk is RiskTier.HALLUCINATED


@pytest.mark.asyncio
async def test_recent_plus_low_downloads_is_suspicious_not_hallucinated(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("slopguard.scoring.engine.hallucination_index", lambda: {})
    monkeypatch.setattr("slopguard.scoring.engine.popular_set", lambda _eco: frozenset())
    now = datetime.now(UTC)
    meta = PackageMetadata(
        name="brand-new", exists=True, first_release=now - timedelta(days=14), downloads_recent=30
    )
    fake = FakeRegistry({"brand-new": meta})
    engine = ScoringEngine(npm_client=fake, pypi_client=FakeRegistry({}))
    [finding] = await engine.score_all([_dep("brand-new")])
    # 0.20 (recent) + 0.15 (low downloads) = 0.35 → below 0.4 suspicious threshold
    # Bump suspicious_min down to confirm both signals are present and the tiering still works.
    assert {s.type for s in finding.signals} == {"recently_published", "low_downloads"}
    assert finding.risk is RiskTier.CLEAN
    engine_low = ScoringEngine(
        npm_client=FakeRegistry({"brand-new": meta}),
        pypi_client=FakeRegistry({}),
        config=ScoringConfig(suspicious_min=0.3),
    )
    [finding2] = await engine_low.score_all([_dep("brand-new")])
    assert finding2.risk is RiskTier.SUSPICIOUS


@pytest.mark.asyncio
async def test_no_network_skips_registry(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("slopguard.scoring.engine.hallucination_index", lambda: {})
    monkeypatch.setattr("slopguard.scoring.engine.popular_set", lambda _eco: frozenset())

    class BoomRegistry(FakeRegistry):
        async def fetch(self, name: str) -> PackageMetadata:  # type: ignore[override]
            raise AssertionError("no_network was set, should not be called")

    engine = ScoringEngine(
        npm_client=BoomRegistry({}),
        pypi_client=BoomRegistry({}),
        no_network=True,
    )
    findings = await engine.score_all([_dep("react-helpers"), _dep("just-a-name")])
    by_name = {f.name: f for f in findings}
    assert by_name["react-helpers"].signals
    assert by_name["react-helpers"].signals[0].type == "name_pattern_suspicious"
    assert by_name["just-a-name"].risk is RiskTier.CLEAN


@pytest.mark.asyncio
async def test_registry_error_becomes_error_finding(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("slopguard.scoring.engine.hallucination_index", lambda: {})
    monkeypatch.setattr("slopguard.scoring.engine.popular_set", lambda _eco: frozenset())
    fake = FakeRegistry({"boom": RegistryError("connection reset")})
    engine = ScoringEngine(npm_client=fake, pypi_client=FakeRegistry({}))
    [finding] = await engine.score_all([_dep("boom")])
    assert finding.risk is RiskTier.ERROR
    assert finding.error is not None and "connection reset" in finding.error


@pytest.mark.asyncio
async def test_scoped_npm_skips_probe(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("slopguard.scoring.engine.hallucination_index", lambda: {})
    monkeypatch.setattr("slopguard.scoring.engine.popular_set", lambda _eco: frozenset())

    class BoomRegistry(FakeRegistry):
        async def fetch(self, name: str) -> PackageMetadata:  # type: ignore[override]
            raise AssertionError("scoped npm should not probe registry")

    engine = ScoringEngine(npm_client=BoomRegistry({}), pypi_client=FakeRegistry({}))
    [finding] = await engine.score_all([_dep("@scope/pkg", scoped=True)])
    assert finding.risk is RiskTier.CLEAN


def test_seed_db_loads() -> None:
    db = load_hallucination_db()
    assert db.schema_version == 1
    # Seed file may be empty at this point in the build; assert schema correctness only.
    assert isinstance(db.entries, list)


def test_popular_packages_load() -> None:
    pkgs = load_popular_packages()
    assert pkgs.schema_version == 1
    assert isinstance(pkgs.npm_top_1000, list)
    assert isinstance(pkgs.pypi_top_1000, list)
