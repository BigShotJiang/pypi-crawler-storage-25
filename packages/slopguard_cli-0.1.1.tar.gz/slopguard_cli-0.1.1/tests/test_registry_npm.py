"""Tests for the npm registry client."""

from __future__ import annotations

import httpx
import pytest
import respx

from slopguard.registry.base import RegistryError
from slopguard.registry.npm import NPM_DOWNLOADS, NPM_REGISTRY, NpmRegistryClient


@pytest.mark.asyncio
@respx.mock
async def test_fetch_existing_package_returns_metadata() -> None:
    payload = {
        "name": "react",
        "time": {
            "created": "2011-10-26T17:46:21.942Z",
            "modified": "2024-04-25T19:08:15.123Z",
        },
        "maintainers": [{"name": "fb-team", "email": "team@fb.com"}],
    }
    respx.get(f"{NPM_REGISTRY}/react").mock(return_value=httpx.Response(200, json=payload))
    respx.get(f"{NPM_DOWNLOADS}/react").mock(
        return_value=httpx.Response(200, json={"downloads": 95000000})
    )
    async with NpmRegistryClient() as client:
        meta = await client.fetch("react")
    assert meta.exists is True
    assert meta.publisher == "fb-team"
    assert meta.first_release is not None
    assert meta.first_release.year == 2011
    assert meta.downloads_recent == 95000000


@pytest.mark.asyncio
@respx.mock
async def test_fetch_404_returns_not_exists() -> None:
    respx.get(f"{NPM_REGISTRY}/totally-fake-pkg-xyz").mock(return_value=httpx.Response(404))
    async with NpmRegistryClient() as client:
        meta = await client.fetch("totally-fake-pkg-xyz")
    assert meta.exists is False
    assert meta.first_release is None


@pytest.mark.asyncio
@respx.mock
async def test_fetch_timeout_raises_registry_error() -> None:
    respx.get(f"{NPM_REGISTRY}/slowpkg").mock(side_effect=httpx.TimeoutException("nope"))
    async with NpmRegistryClient(max_retries=1) as client:
        with pytest.raises(RegistryError):
            await client.fetch("slowpkg")


@pytest.mark.asyncio
@respx.mock
async def test_fetch_caches_within_one_client() -> None:
    route = respx.get(f"{NPM_REGISTRY}/lodash").mock(
        return_value=httpx.Response(
            200, json={"time": {"created": "2010-01-01T00:00:00Z"}, "maintainers": []}
        )
    )
    respx.get(f"{NPM_DOWNLOADS}/lodash").mock(
        return_value=httpx.Response(200, json={"downloads": 1})
    )
    async with NpmRegistryClient() as client:
        await client.fetch("lodash")
        await client.fetch("lodash")
    assert route.call_count == 1


@pytest.mark.asyncio
@respx.mock
async def test_429_backs_off_then_succeeds() -> None:
    responses = [
        httpx.Response(429, headers={"Retry-After": "0"}),
        httpx.Response(200, json={"time": {"created": "2020-01-01T00:00:00Z"}, "maintainers": []}),
    ]
    respx.get(f"{NPM_REGISTRY}/calm").mock(side_effect=responses)
    respx.get(f"{NPM_DOWNLOADS}/calm").mock(return_value=httpx.Response(200, json={"downloads": 5}))
    async with NpmRegistryClient(max_retries=2) as client:
        meta = await client.fetch("calm")
    assert meta.exists is True
    assert meta.downloads_recent == 5
