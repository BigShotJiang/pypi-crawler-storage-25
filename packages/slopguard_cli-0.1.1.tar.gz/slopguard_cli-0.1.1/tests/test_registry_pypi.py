"""Tests for the PyPI registry client."""

from __future__ import annotations

import httpx
import pytest
import respx

from slopguard.registry.base import RegistryError
from slopguard.registry.pypi import PYPI_JSON, PYPISTATS_RECENT, PypiRegistryClient


@pytest.mark.asyncio
@respx.mock
async def test_fetch_existing_package() -> None:
    payload = {
        "info": {"author": "Kenneth Reitz"},
        "releases": {
            "1.0.0": [{"upload_time_iso_8601": "2011-02-13T15:00:00Z"}],
            "2.31.0": [{"upload_time_iso_8601": "2023-05-22T11:00:00Z"}],
        },
    }
    respx.get(f"{PYPI_JSON}/requests/json").mock(return_value=httpx.Response(200, json=payload))
    respx.get(f"{PYPISTATS_RECENT}/requests/recent").mock(
        return_value=httpx.Response(200, json={"data": {"last_week": 123456}})
    )
    async with PypiRegistryClient() as client:
        meta = await client.fetch("requests")
    assert meta.exists is True
    assert meta.publisher == "Kenneth Reitz"
    assert meta.first_release is not None and meta.first_release.year == 2011
    assert meta.latest_release is not None and meta.latest_release.year == 2023
    assert meta.downloads_recent == 123456


@pytest.mark.asyncio
@respx.mock
async def test_fetch_404_returns_not_exists() -> None:
    respx.get(f"{PYPI_JSON}/no-such-pkg/json").mock(return_value=httpx.Response(404))
    async with PypiRegistryClient() as client:
        meta = await client.fetch("no-such-pkg")
    assert meta.exists is False


@pytest.mark.asyncio
@respx.mock
async def test_fetch_timeout_raises() -> None:
    respx.get(f"{PYPI_JSON}/timeout-pkg/json").mock(side_effect=httpx.TimeoutException("slow"))
    async with PypiRegistryClient(max_retries=1) as client:
        with pytest.raises(RegistryError):
            await client.fetch("timeout-pkg")


@pytest.mark.asyncio
@respx.mock
async def test_downloads_failure_is_soft_none() -> None:
    payload = {
        "info": {"author": "Anon"},
        "releases": {"1.0": [{"upload_time_iso_8601": "2024-01-01T00:00:00Z"}]},
    }
    respx.get(f"{PYPI_JSON}/pkg/json").mock(return_value=httpx.Response(200, json=payload))
    respx.get(f"{PYPISTATS_RECENT}/pkg/recent").mock(return_value=httpx.Response(503))
    async with PypiRegistryClient() as client:
        meta = await client.fetch("pkg")
    assert meta.exists is True
    assert meta.downloads_recent is None
