"""Tests for the npm parser."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from slopguard.models import DependencySource, Ecosystem
from slopguard.parsers.base import ParserError
from slopguard.parsers.npm import NpmParser


def _write(tmp_path: Path, name: str, payload: dict | str) -> Path:
    path = tmp_path / name
    if isinstance(payload, str):
        path.write_text(payload)
    else:
        path.write_text(json.dumps(payload))
    return path


def test_parse_plain_package_json(tmp_path: Path) -> None:
    manifest = _write(
        tmp_path,
        "package.json",
        {
            "name": "demo",
            "version": "1.0.0",
            "dependencies": {"react": "^18.2.0", "lodash": "4.17.21"},
            "devDependencies": {"jest": "^29.0.0"},
        },
    )
    deps = NpmParser().parse(manifest)
    by_name = {d.name: d for d in deps}
    assert set(by_name) == {"react", "lodash", "jest"}
    assert by_name["react"].version == "^18.2.0"
    assert by_name["react"].ecosystem is Ecosystem.NPM
    assert by_name["react"].source is DependencySource.REGISTRY
    assert by_name["react"].manifest == "package.json"
    assert all(not d.scoped for d in deps)


def test_parse_scoped_packages(tmp_path: Path) -> None:
    manifest = _write(
        tmp_path,
        "package.json",
        {"dependencies": {"@scope/pkg": "1.0.0", "@types/node": "^20.0.0"}},
    )
    deps = NpmParser().parse(manifest)
    assert all(d.scoped for d in deps)
    assert {d.name for d in deps} == {"@scope/pkg", "@types/node"}


def test_parse_file_and_link_references(tmp_path: Path) -> None:
    manifest = _write(
        tmp_path,
        "package.json",
        {
            "dependencies": {
                "local-a": "file:../local-a",
                "local-b": "link:../local-b",
            }
        },
    )
    deps = NpmParser().parse(manifest)
    by_name = {d.name: d for d in deps}
    assert by_name["local-a"].source is DependencySource.FILE
    assert by_name["local-a"].version is None
    assert by_name["local-b"].source is DependencySource.LINK


def test_parse_git_url_dependencies(tmp_path: Path) -> None:
    manifest = _write(
        tmp_path,
        "package.json",
        {
            "dependencies": {
                "gitpkg": "git+https://github.com/foo/bar.git#abc123",
                "shorthand": "github:foo/baz",
            }
        },
    )
    deps = NpmParser().parse(manifest)
    by_name = {d.name: d for d in deps}
    assert by_name["gitpkg"].source is DependencySource.GIT
    assert by_name["shorthand"].source is DependencySource.GIT


def test_parse_lockfile_v3(tmp_path: Path) -> None:
    payload: dict = {
        "name": "demo",
        "version": "1.0.0",
        "lockfileVersion": 3,
        "packages": {
            "": {"name": "demo", "version": "1.0.0"},
            "node_modules/react": {
                "version": "18.2.0",
                "resolved": "https://registry.npmjs.org/react/-/react-18.2.0.tgz",
            },
            "node_modules/@types/node": {"version": "20.0.0", "name": "@types/node"},
            "node_modules/dup": {"version": "1.0.0"},
            "node_modules/foo/node_modules/dup": {"version": "1.0.0"},
        },
    }
    manifest = _write(tmp_path, "package-lock.json", payload)
    deps = NpmParser().parse(manifest)
    names = sorted(d.name for d in deps)
    # the root project entry "" should not appear; nested duplicate of `dup` deduped
    assert "demo" not in names
    assert names.count("dup") == 1
    assert "react" in names
    assert "@types/node" in names
    assert next(d for d in deps if d.name == "@types/node").scoped


def test_parse_malformed_json_raises(tmp_path: Path) -> None:
    manifest = _write(tmp_path, "package.json", "{this is not json")
    with pytest.raises(ParserError):
        NpmParser().parse(manifest)


def test_parse_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(ParserError):
        NpmParser().parse(tmp_path / "does-not-exist.json")
