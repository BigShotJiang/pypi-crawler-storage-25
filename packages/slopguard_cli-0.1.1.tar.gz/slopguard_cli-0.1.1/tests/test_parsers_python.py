"""Tests for the Python parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from slopguard.models import DependencySource, Ecosystem
from slopguard.parsers.base import ParserError
from slopguard.parsers.python import PythonParser


def _write(tmp_path: Path, name: str, text: str) -> Path:
    p = tmp_path / name
    p.write_text(text)
    return p


def test_requirements_txt_with_comments_and_specifiers(tmp_path: Path) -> None:
    text = """
# A comment
requests==2.31.0
httpx>=0.27.0,<1.0
pydantic ~= 2.6   # inline comment
fastapi[all]==0.110.0
   numpy
typing-extensions; python_version<'3.12'
""".strip()
    p = _write(tmp_path, "requirements.txt", text)
    deps = PythonParser().parse(p)
    by_name = {d.name: d for d in deps}
    assert set(by_name) == {
        "requests",
        "httpx",
        "pydantic",
        "fastapi",
        "numpy",
        "typing-extensions",
    }
    assert by_name["requests"].version == "==2.31.0"
    assert by_name["httpx"].version == ">=0.27.0,<1.0"
    assert by_name["pydantic"].version is not None and "~=" in by_name["pydantic"].version
    assert by_name["fastapi"].version == "==0.110.0"
    assert by_name["numpy"].version is None
    assert all(d.ecosystem is Ecosystem.PYPI for d in deps)


def test_requirements_txt_pip_flags_and_editable(tmp_path: Path) -> None:
    text = """
-r other.txt
--index-url https://example.invalid/simple
-e git+https://github.com/foo/bar.git@v1.0.0#egg=bar-pkg
git+https://github.com/baz/qux.git#egg=qux-pkg
./local-package
""".strip()
    p = _write(tmp_path, "requirements.txt", text)
    deps = PythonParser().parse(p)
    by_name = {d.name: d for d in deps}
    assert "bar-pkg" in by_name
    assert by_name["bar-pkg"].source is DependencySource.GIT
    assert "qux-pkg" in by_name
    assert by_name["qux-pkg"].source is DependencySource.GIT


def test_pyproject_pep621(tmp_path: Path) -> None:
    text = """
[project]
name = "demo"
version = "0.0.1"
dependencies = [
    "requests>=2.31",
    "httpx>=0.27",
]

[project.optional-dependencies]
dev = ["pytest>=8", "ruff"]
""".strip()
    p = _write(tmp_path, "pyproject.toml", text)
    deps = PythonParser().parse(p)
    names = {d.name for d in deps}
    assert names == {"requests", "httpx", "pytest", "ruff"}


def test_pyproject_poetry(tmp_path: Path) -> None:
    text = """
[tool.poetry]
name = "demo"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
requests = "^2.31"
local-pkg = { path = "../local-pkg" }
gitpkg = { git = "https://github.com/foo/bar.git" }

[tool.poetry.group.dev.dependencies]
pytest = "^8.0"
""".strip()
    p = _write(tmp_path, "pyproject.toml", text)
    deps = PythonParser().parse(p)
    by_name = {d.name: d for d in deps}
    assert "python" not in by_name
    assert by_name["requests"].version == "^2.31"
    assert by_name["local-pkg"].source is DependencySource.FILE
    assert by_name["gitpkg"].source is DependencySource.GIT
    assert "pytest" in by_name


def test_pipfile(tmp_path: Path) -> None:
    text = """
[[source]]
url = "https://pypi.org/simple"
verify_ssl = true

[packages]
requests = "*"
httpx = ">=0.27"

[dev-packages]
pytest = "*"
""".strip()
    p = _write(tmp_path, "Pipfile", text)
    deps = PythonParser().parse(p)
    by_name = {d.name: d for d in deps}
    assert {"requests", "httpx", "pytest"} <= set(by_name)
    # "*" pin is stored as None
    assert by_name["requests"].version is None
    assert by_name["httpx"].version == ">=0.27"


def test_malformed_pyproject_raises(tmp_path: Path) -> None:
    p = _write(tmp_path, "pyproject.toml", "this is not = [valid toml")
    with pytest.raises(ParserError):
        PythonParser().parse(p)


def test_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(ParserError):
        PythonParser().parse(tmp_path / "requirements.txt")
