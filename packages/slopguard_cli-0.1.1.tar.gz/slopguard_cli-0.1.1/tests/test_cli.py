"""End-to-end CLI test."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import pytest
from typer.testing import CliRunner

from slopguard.cli import app

# Minimal JSON Schema for the ScanReport wire format — checked verbatim in test #5 of the spec.
SCAN_REPORT_SCHEMA: dict = {
    "type": "object",
    "required": [
        "slopguard_version",
        "scan_id",
        "scanned_at",
        "path",
        "manifests",
        "summary",
        "findings",
        "exit_code",
    ],
    "properties": {
        "slopguard_version": {"type": "string"},
        "scan_id": {"type": "string"},
        "scanned_at": {"type": "string"},
        "path": {"type": "string"},
        "manifests": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["path", "ecosystem", "dependency_count"],
                "properties": {
                    "path": {"type": "string"},
                    "ecosystem": {"type": "string", "enum": ["npm", "pypi"]},
                    "dependency_count": {"type": "integer", "minimum": 0},
                },
            },
        },
        "summary": {
            "type": "object",
            "required": ["total", "clean", "suspicious", "hallucinated", "errors"],
            "properties": {
                "total": {"type": "integer"},
                "clean": {"type": "integer"},
                "suspicious": {"type": "integer"},
                "hallucinated": {"type": "integer"},
                "errors": {"type": "integer"},
            },
        },
        "findings": {
            "type": "array",
            "items": {
                "type": "object",
                "required": [
                    "name",
                    "ecosystem",
                    "manifest",
                    "risk",
                    "score",
                    "signals",
                    "remediation",
                ],
                "properties": {
                    "name": {"type": "string"},
                    "version": {"type": ["string", "null"]},
                    "ecosystem": {"type": "string", "enum": ["npm", "pypi"]},
                    "manifest": {"type": "string"},
                    "risk": {
                        "type": "string",
                        "enum": ["clean", "suspicious", "hallucinated", "error"],
                    },
                    "score": {"type": "number"},
                    "signals": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["type", "weight", "detail"],
                            "properties": {
                                "type": {"type": "string"},
                                "weight": {"type": "number"},
                                "detail": {"type": "string"},
                            },
                        },
                    },
                    "remediation": {"type": "string"},
                    "error": {"type": ["string", "null"]},
                },
            },
        },
        "exit_code": {"type": "integer", "enum": [0, 1, 2]},
    },
}


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def test_version_subcommand(runner: CliRunner) -> None:
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert result.stdout.strip() == "0.1.1"


def test_scan_fixtures_no_network_terminal(runner: CliRunner, fixtures_dir: Path) -> None:
    result = runner.invoke(app, ["scan", str(fixtures_dir), "--no-network"])
    # Expect findings → exit 1 because fixtures contain a HALLUCINATED dep.
    assert result.exit_code == 1, result.stdout
    out = result.stdout
    assert "HALLUCIN" in out
    assert "SUSPICIOUS" in out
    assert "react-codeshift" in out
    # `internal-tool` is ignored by the fixture .slopguard.yaml — should be clean.
    # `mycorp-utils` matches the suspicious name pattern.
    assert "mycorp-utils" in out


def test_scan_fixtures_json_schema(runner: CliRunner, fixtures_dir: Path, tmp_path: Path) -> None:
    out_path = tmp_path / "report.json"
    result = runner.invoke(
        app,
        ["scan", str(fixtures_dir), "--no-network", "--format", "json", "--output", str(out_path)],
    )
    assert result.exit_code == 1
    payload = json.loads(out_path.read_text())
    jsonschema.validate(payload, SCAN_REPORT_SCHEMA)
    # Spec-specified summary numbers — fixture must contain at least one hallucinated + one suspicious.
    assert payload["summary"]["hallucinated"] >= 1
    assert payload["summary"]["suspicious"] >= 1
    # `react-codeshift` is HALLUCINATED via the seed DB.
    finding = next(f for f in payload["findings"] if f["name"] == "react-codeshift")
    assert finding["risk"] == "hallucinated"
    # `mycorp-utils` is SUSPICIOUS via the name pattern + lowered threshold.
    finding = next(f for f in payload["findings"] if f["name"] == "mycorp-utils")
    assert finding["risk"] == "suspicious"
    # `internal-tool` matched an ignore rule.
    ignored = next(f for f in payload["findings"] if f["name"] == "internal-tool")
    assert ignored["risk"] == "clean"
    assert any(s["type"] == "ignored_by_config" for s in ignored["signals"])


def test_scan_fixtures_no_network_blocks_http(
    runner: CliRunner, fixtures_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import httpx

    sent: list[str] = []

    async def _boom(self, *args: object, **kwargs: object):  # type: ignore[no-untyped-def]
        sent.append(args[1] if len(args) > 1 else "?")
        raise AssertionError("--no-network must not perform HTTP requests")

    monkeypatch.setattr(httpx.AsyncClient, "request", _boom)
    result = runner.invoke(app, ["scan", str(fixtures_dir), "--no-network", "--format", "json"])
    assert result.exit_code == 1
    assert sent == []


def test_scan_path_not_exists(runner: CliRunner, tmp_path: Path) -> None:
    result = runner.invoke(app, ["scan", str(tmp_path / "missing")])
    assert result.exit_code == 2


def test_scan_no_manifests_exits_2(runner: CliRunner, tmp_path: Path) -> None:
    result = runner.invoke(app, ["scan", str(tmp_path)])
    assert result.exit_code == 2


def test_module_main_runs() -> None:
    """`python -m slopguard version` should also work."""
    result = subprocess.run(
        [sys.executable, "-m", "slopguard", "version"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert result.stdout.strip() == "0.1.1"
