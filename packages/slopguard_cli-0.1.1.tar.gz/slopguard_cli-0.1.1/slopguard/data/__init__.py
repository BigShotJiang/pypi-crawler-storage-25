"""Embedded data: hallucination seed DB + popular-package lists."""

from __future__ import annotations

import json
from functools import lru_cache
from importlib.resources import files

from slopguard.models import Ecosystem, HallucinationDB, HallucinationEntry, PopularPackages


@lru_cache(maxsize=1)
def load_hallucination_db() -> HallucinationDB:
    """Load and validate the embedded hallucination seed database."""
    raw = files("slopguard.data").joinpath("hallucinations_seed.json").read_text(encoding="utf-8")
    payload = json.loads(raw)
    # Strip non-schema keys (operator notes, etc.) before validating.
    keep = {"schema_version", "updated", "entries"}
    cleaned = {k: v for k, v in payload.items() if k in keep}
    return HallucinationDB.model_validate(cleaned)


@lru_cache(maxsize=1)
def load_popular_packages() -> PopularPackages:
    """Load the embedded top-1000 popularity lists."""
    raw = files("slopguard.data").joinpath("popular_packages.json").read_text(encoding="utf-8")
    return PopularPackages.model_validate_json(raw)


def hallucination_index() -> dict[tuple[Ecosystem, str], HallucinationEntry]:
    """Return a lookup of (ecosystem, lowercased name) → seed entry."""
    db = load_hallucination_db()
    return {(entry.ecosystem, entry.name.lower()): entry for entry in db.entries}


def popular_set(ecosystem: Ecosystem) -> frozenset[str]:
    """Return the lowercased popular-package set for an ecosystem."""
    pkgs = load_popular_packages()
    names = pkgs.npm_top_1000 if ecosystem is Ecosystem.NPM else pkgs.pypi_top_1000
    return frozenset(name.lower() for name in names)
