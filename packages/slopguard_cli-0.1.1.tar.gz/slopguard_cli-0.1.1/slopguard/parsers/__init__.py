"""Manifest parsers for npm and Python ecosystems."""

from __future__ import annotations

from slopguard.parsers.base import Parser, ParserError
from slopguard.parsers.npm import NpmParser
from slopguard.parsers.python import PythonParser

__all__ = ["NpmParser", "Parser", "ParserError", "PythonParser"]
