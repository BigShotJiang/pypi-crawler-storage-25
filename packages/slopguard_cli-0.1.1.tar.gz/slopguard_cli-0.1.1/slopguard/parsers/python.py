"""Python manifest parsers: ``requirements.txt``, ``pyproject.toml``, ``Pipfile``."""

from __future__ import annotations

import re
import tomllib
from pathlib import Path
from typing import Any

from slopguard.models import Dependency, DependencySource, Ecosystem
from slopguard.parsers.base import Parser, ParserError

# PEP 508 name + optional version specifier prefix.
_NAME_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")
# Strip extras like "package[extra,extra2]"
_EXTRAS_RE = re.compile(r"\[[^\]]*\]")
# Match any version specifier portion (==, >=, <=, ~=, !=, <, >).
_SPEC_RE = re.compile(
    r"(==|>=|<=|~=|!=|<|>)\s*[^,;\s]+(?:\s*,\s*(?:==|>=|<=|~=|!=|<|>)\s*[^,;\s]+)*"
)


def _parse_requirement_line(line: str) -> tuple[str, str | None, DependencySource] | None:
    """Parse a single requirements.txt line. Returns (name, version, source) or None to skip."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None
    # Skip pip flags like -r other.txt, -c constraints.txt, --index-url ...
    if stripped.startswith("-"):
        if stripped.startswith(("-e ", "-e\t")):
            # Editable install — usually a local path or VCS URL. Treat as file/git for v0.1.
            target = stripped[2:].strip()
            return _classify_editable(target)
        return None
    # Inline editable: `-e .` already handled above. Direct URL requirements:
    if "://" in stripped or stripped.startswith(("git+", "hg+", "svn+", "bzr+")):
        # Direct VCS / URL install. Try to pull out an egg= fragment for the name.
        name = _name_from_url(stripped)
        if name is None:
            return None
        return (name, None, DependencySource.GIT if "git" in stripped else DependencySource.URL)
    # Local path: starts with "./" or "/" or contains ".whl" / ".tar.gz" at end.
    if stripped.startswith(("./", "/", "../")) or stripped.endswith((".whl", ".tar.gz", ".zip")):
        # No reliable name without inspecting the file — skip.
        return None
    # Strip environment markers (";python_version>='3.10'") and inline comments.
    bare = stripped.split(";", 1)[0].split("#", 1)[0].strip()
    bare = _EXTRAS_RE.sub("", bare)
    name_match = _NAME_RE.match(bare)
    if not name_match:
        return None
    name = name_match.group(1)
    rest = bare[name_match.end() :].strip()
    spec_match = _SPEC_RE.search(rest)
    version = spec_match.group(0).strip() if spec_match else None
    return (name, version, DependencySource.REGISTRY)


def _classify_editable(target: str) -> tuple[str, str | None, DependencySource] | None:
    if "://" in target or target.startswith(("git+", "hg+", "svn+")):
        name = _name_from_url(target)
        if not name:
            return None
        return (name, None, DependencySource.GIT)
    # Local editable install — name is the directory's package name, which we cannot infer
    # without reading setup.cfg / pyproject. Skip.
    return None


def _name_from_url(url: str) -> str | None:
    if "#egg=" in url:
        return url.split("#egg=")[-1].split("&", 1)[0]
    return None


class PythonParser(Parser):
    """Parse Python manifests: ``requirements.txt``, ``pyproject.toml``, ``Pipfile``."""

    @classmethod
    def supported_filenames(cls) -> tuple[str, ...]:
        return ("requirements.txt", "pyproject.toml", "Pipfile")

    def parse(self, path: Path) -> list[Dependency]:
        try:
            blob = path.read_bytes()
        except FileNotFoundError as exc:
            raise ParserError(f"manifest not found: {path}") from exc

        if path.name == "requirements.txt":
            return self._parse_requirements_txt(blob.decode("utf-8", errors="replace"), path)
        if path.name == "pyproject.toml":
            return self._parse_pyproject(blob, path)
        if path.name == "Pipfile":
            return self._parse_pipfile(blob, path)
        raise ParserError(f"unsupported Python manifest: {path.name}")

    def _parse_requirements_txt(self, text: str, path: Path) -> list[Dependency]:
        deps: list[Dependency] = []
        seen: set[tuple[str, str | None]] = set()
        for raw in text.splitlines():
            # Handle line continuations.
            line = raw.rstrip("\\").rstrip()
            parsed = _parse_requirement_line(line)
            if parsed is None:
                continue
            name, version, source = parsed
            key = (name.lower(), version)
            if key in seen:
                continue
            seen.add(key)
            deps.append(
                Dependency(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.PYPI,
                    manifest=path.name,
                    source=source,
                    scoped=False,
                )
            )
        return deps

    def _parse_pyproject(self, blob: bytes, path: Path) -> list[Dependency]:
        try:
            data = tomllib.loads(blob.decode("utf-8"))
        except tomllib.TOMLDecodeError as exc:
            raise ParserError(f"invalid TOML in {path}: {exc}") from exc
        if not isinstance(data, dict):
            raise ParserError(f"expected TOML table at top level of {path}")

        deps: list[Dependency] = []
        seen: set[str] = set()

        # PEP 621: [project] dependencies, [project.optional-dependencies]
        project = data.get("project")
        if isinstance(project, dict):
            for entry in project.get("dependencies", []) or []:
                if not isinstance(entry, str):
                    continue
                parsed = _parse_requirement_line(entry)
                if parsed is None:
                    continue
                name, version, source = parsed
                if name.lower() in seen:
                    continue
                seen.add(name.lower())
                deps.append(
                    Dependency(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.PYPI,
                        manifest=path.name,
                        source=source,
                    )
                )
            opt = project.get("optional-dependencies")
            if isinstance(opt, dict):
                for group in opt.values():
                    if not isinstance(group, list):
                        continue
                    for entry in group:
                        if not isinstance(entry, str):
                            continue
                        parsed = _parse_requirement_line(entry)
                        if parsed is None:
                            continue
                        name, version, source = parsed
                        if name.lower() in seen:
                            continue
                        seen.add(name.lower())
                        deps.append(
                            Dependency(
                                name=name,
                                version=version,
                                ecosystem=Ecosystem.PYPI,
                                manifest=path.name,
                                source=source,
                            )
                        )

        # Poetry: [tool.poetry.dependencies] and [tool.poetry.group.<name>.dependencies]
        tool = data.get("tool")
        if isinstance(tool, dict):
            poetry = tool.get("poetry")
            if isinstance(poetry, dict):
                deps.extend(self._collect_poetry(poetry.get("dependencies"), path, seen))
                groups = poetry.get("group")
                if isinstance(groups, dict):
                    for group_meta in groups.values():
                        if isinstance(group_meta, dict):
                            deps.extend(
                                self._collect_poetry(group_meta.get("dependencies"), path, seen)
                            )

        return deps

    def _collect_poetry(
        self,
        block: Any,
        path: Path,
        seen: set[str],
    ) -> list[Dependency]:
        out: list[Dependency] = []
        if not isinstance(block, dict):
            return out
        for name, spec in block.items():
            if not isinstance(name, str):
                continue
            if name.lower() == "python":
                continue
            if name.lower() in seen:
                continue
            seen.add(name.lower())
            version, source = self._classify_poetry_spec(spec)
            out.append(
                Dependency(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.PYPI,
                    manifest=path.name,
                    source=source,
                )
            )
        return out

    @staticmethod
    def _classify_poetry_spec(spec: Any) -> tuple[str | None, DependencySource]:
        if isinstance(spec, str):
            return (spec, DependencySource.REGISTRY)
        if isinstance(spec, dict):
            if "path" in spec:
                return (None, DependencySource.FILE)
            if "url" in spec:
                return (None, DependencySource.URL)
            if "git" in spec:
                return (None, DependencySource.GIT)
            ver = spec.get("version")
            return (ver if isinstance(ver, str) else None, DependencySource.REGISTRY)
        return (None, DependencySource.REGISTRY)

    def _parse_pipfile(self, blob: bytes, path: Path) -> list[Dependency]:
        try:
            data = tomllib.loads(blob.decode("utf-8"))
        except tomllib.TOMLDecodeError as exc:
            raise ParserError(f"invalid TOML in {path}: {exc}") from exc

        deps: list[Dependency] = []
        seen: set[str] = set()
        for section in ("packages", "dev-packages"):
            block = data.get(section)
            if not isinstance(block, dict):
                continue
            for name, spec in block.items():
                if not isinstance(name, str) or name.lower() in seen:
                    continue
                seen.add(name.lower())
                version, source = PythonParser._classify_poetry_spec(spec)
                if version == "*":
                    version = None
                deps.append(
                    Dependency(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.PYPI,
                        manifest=path.name,
                        source=source,
                    )
                )
        return deps
