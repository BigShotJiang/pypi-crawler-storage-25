"""npm manifest parsers: ``package.json`` and ``package-lock.json``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from slopguard.models import Dependency, DependencySource, Ecosystem
from slopguard.parsers.base import Parser, ParserError


def _classify_npm_spec(spec: str) -> DependencySource:
    """Classify the source of an npm dependency spec string."""
    if spec.startswith(("file:", "link:")):
        return DependencySource.FILE if spec.startswith("file:") else DependencySource.LINK
    if spec.startswith(("git:", "git+", "github:")) or "git@" in spec:
        return DependencySource.GIT
    if spec.startswith(("http://", "https://")):
        return DependencySource.URL
    return DependencySource.REGISTRY


class NpmParser(Parser):
    """Parse ``package.json`` and ``package-lock.json``."""

    @classmethod
    def supported_filenames(cls) -> tuple[str, ...]:
        return ("package.json", "package-lock.json")

    def parse(self, path: Path) -> list[Dependency]:
        try:
            with path.open("rb") as fh:
                data = json.load(fh)
        except FileNotFoundError as exc:
            raise ParserError(f"manifest not found: {path}") from exc
        except json.JSONDecodeError as exc:
            raise ParserError(f"invalid JSON in {path}: {exc.msg}") from exc

        if not isinstance(data, dict):
            raise ParserError(f"expected JSON object at top level of {path}")

        if path.name == "package-lock.json":
            return self._parse_lockfile(data, path)
        return self._parse_manifest(data, path)

    def _parse_manifest(self, data: dict[str, Any], path: Path) -> list[Dependency]:
        deps: list[Dependency] = []
        manifest_rel = path.name
        for section in (
            "dependencies",
            "devDependencies",
            "optionalDependencies",
            "peerDependencies",
        ):
            block = data.get(section)
            if not isinstance(block, dict):
                continue
            for name, spec in block.items():
                if not isinstance(name, str):
                    continue
                spec_str = spec if isinstance(spec, str) else ""
                source = _classify_npm_spec(spec_str)
                version = spec_str if source is DependencySource.REGISTRY else None
                deps.append(
                    Dependency(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.NPM,
                        manifest=manifest_rel,
                        source=source,
                        scoped=name.startswith("@"),
                    )
                )
        return deps

    def _parse_lockfile(self, data: dict[str, Any], path: Path) -> list[Dependency]:
        deps: list[Dependency] = []
        manifest_rel = path.name
        seen: set[tuple[str, str | None]] = set()

        # lockfile v2/v3 puts everything under "packages" keyed by node_modules path.
        packages = data.get("packages")
        if isinstance(packages, dict):
            for node_path, meta in packages.items():
                if not node_path or not isinstance(meta, dict):
                    continue
                # The empty-key entry describes the root project — skip it.
                name = meta.get("name") or self._name_from_node_path(node_path)
                if not name:
                    continue
                version = meta.get("version")
                if not isinstance(version, str):
                    version = None
                source = DependencySource.REGISTRY
                if meta.get("link"):
                    source = DependencySource.LINK
                elif meta.get("resolved", "").startswith("git"):
                    source = DependencySource.GIT
                key = (name, version)
                if key in seen:
                    continue
                seen.add(key)
                deps.append(
                    Dependency(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.NPM,
                        manifest=manifest_rel,
                        source=source,
                        scoped=name.startswith("@"),
                    )
                )
            return deps

        # lockfile v1 stored deps under "dependencies".
        legacy = data.get("dependencies")
        if isinstance(legacy, dict):
            for name, meta in legacy.items():
                if not isinstance(meta, dict):
                    continue
                version = meta.get("version") if isinstance(meta.get("version"), str) else None
                key = (name, version)
                if key in seen:
                    continue
                seen.add(key)
                deps.append(
                    Dependency(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.NPM,
                        manifest=manifest_rel,
                        source=DependencySource.REGISTRY,
                        scoped=name.startswith("@"),
                    )
                )
        return deps

    @staticmethod
    def _name_from_node_path(node_path: str) -> str | None:
        # "node_modules/foo" -> "foo"; "node_modules/@scope/bar" -> "@scope/bar".
        marker = "node_modules/"
        idx = node_path.rfind(marker)
        if idx < 0:
            return None
        return node_path[idx + len(marker) :] or None
