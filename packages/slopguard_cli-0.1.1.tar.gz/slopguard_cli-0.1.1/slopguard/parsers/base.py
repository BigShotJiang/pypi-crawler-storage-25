"""Parser base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from slopguard.models import Dependency


class ParserError(Exception):
    """Raised when a manifest cannot be parsed."""


class Parser(ABC):
    """Abstract parser for a single manifest file."""

    @classmethod
    @abstractmethod
    def supported_filenames(cls) -> tuple[str, ...]:
        """Filenames (basename match) this parser handles."""

    @abstractmethod
    def parse(self, path: Path) -> list[Dependency]:
        """Parse the manifest at ``path`` and return dependencies.

        Raises ``ParserError`` if the file is malformed or unreadable.
        """
