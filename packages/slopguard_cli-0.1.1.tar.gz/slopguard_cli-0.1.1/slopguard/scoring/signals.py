"""Individual risk-signal functions.

Each function consumes the dependency, optional registry metadata, and optional
context (popularity sets, hallucination DB hits). They return a :class:`Signal`
or ``None``. The engine composes them.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta

from slopguard.models import Dependency, HallucinationEntry, Signal
from slopguard.registry.base import PackageMetadata

# Weights mirror the spec section 9 table.
W_DB_HIT = 0.90
W_NOT_FOUND = 0.85
W_RECENT_30 = 0.20
W_RECENT_7 = 0.35
W_LOW_DOWNLOADS = 0.15
W_NEW_PUBLISHER = 0.20
W_SOLO_NEW = 0.30
W_LEVENSHTEIN = 0.25
W_NAME_PATTERN = 0.10

_NAME_PATTERN_RE = re.compile(
    r"^(?:[a-z0-9]+[-_])+(helpers?|utils?|async|pro|kit|sdk|tools?|extras?|plus|next|core)$",
    re.IGNORECASE,
)


def _now() -> datetime:
    return datetime.now(UTC)


def _ensure_aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


def hallucination_db_hit(dep: Dependency, entry: HallucinationEntry | None) -> Signal | None:
    if entry is None:
        return None
    models = ", ".join(entry.models_observed) if entry.models_observed else "unspecified models"
    return Signal(
        type="hallucination_db_hit",
        weight=W_DB_HIT,
        detail=(f"Matched seed DB entry; recurrence {entry.recurrence_rate:.2f} across {models}."),
    )


def registry_not_found(meta: PackageMetadata) -> Signal | None:
    if meta.exists:
        return None
    return Signal(
        type="registry_not_found",
        weight=W_NOT_FOUND,
        detail="Registry returned 404 — package name is not currently published.",
    )


def recently_published(meta: PackageMetadata) -> tuple[Signal | None, Signal | None]:
    """Return (very_recent, recent) signals — at most one will be non-None."""
    if not meta.exists or meta.first_release is None:
        return (None, None)
    age = _now() - _ensure_aware(meta.first_release)
    if age < timedelta(days=7):
        return (
            Signal(
                type="very_recently_published",
                weight=W_RECENT_7,
                detail=f"First release {age.days} day(s) ago.",
            ),
            None,
        )
    if age < timedelta(days=30):
        return (
            None,
            Signal(
                type="recently_published",
                weight=W_RECENT_30,
                detail=f"First release {age.days} day(s) ago.",
            ),
        )
    return (None, None)


def low_downloads(meta: PackageMetadata) -> Signal | None:
    if not meta.exists or meta.downloads_recent is None:
        return None
    if meta.downloads_recent >= 100:
        return None
    return Signal(
        type="low_downloads",
        weight=W_LOW_DOWNLOADS,
        detail=f"{meta.downloads_recent} recent downloads.",
    )


def new_publisher(meta: PackageMetadata) -> Signal | None:
    if not meta.exists or meta.publisher_created is None:
        return None
    age = _now() - _ensure_aware(meta.publisher_created)
    if age < timedelta(days=30):
        return Signal(
            type="new_publisher",
            weight=W_NEW_PUBLISHER,
            detail=f"Publisher account created {age.days} day(s) ago.",
        )
    return None


def single_release_new_account(meta: PackageMetadata) -> Signal | None:
    if not meta.exists or meta.publisher_created is None or meta.publisher_package_count is None:
        return None
    age = _now() - _ensure_aware(meta.publisher_created)
    if meta.publisher_package_count == 1 and age < timedelta(days=60):
        return Signal(
            type="single_release_new_account",
            weight=W_SOLO_NEW,
            detail=(f"Publisher's only release; account {age.days} day(s) old."),
        )
    return None


def levenshtein(a: str, b: str) -> int:
    """Iterative Levenshtein distance. Small inputs — no heuristic shortcuts."""
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        curr = [i] + [0] * len(b)
        for j, cb in enumerate(b, start=1):
            cost = 0 if ca == cb else 1
            curr[j] = min(
                curr[j - 1] + 1,  # insertion
                prev[j] + 1,  # deletion
                prev[j - 1] + cost,  # substitution
            )
        prev = curr
    return prev[-1]


def levenshtein_typo(dep: Dependency, popular: frozenset[str]) -> Signal | None:
    """Flag when the dep name is Levenshtein 1 or 2 from a popular package (and not that package)."""
    lower = dep.name.lower()
    if lower in popular:
        return None
    best: tuple[int, str] | None = None
    for candidate in popular:
        # Quick length-based prune.
        if abs(len(candidate) - len(lower)) > 2:
            continue
        d = levenshtein(lower, candidate)
        if d <= 2 and (best is None or d < best[0]):
            best = (d, candidate)
            if d == 1:
                break
    if best is None:
        return None
    d, candidate = best
    return Signal(
        type="levenshtein_typo",
        weight=W_LEVENSHTEIN,
        detail=f"Levenshtein {d} from popular package '{candidate}'.",
    )


def name_pattern_suspicious(dep: Dependency) -> Signal | None:
    """Flag classic hallucination shapes like `<stem>-helpers`, `<stem>-utils`."""
    if not _NAME_PATTERN_RE.match(dep.name):
        return None
    return Signal(
        type="name_pattern_suspicious",
        weight=W_NAME_PATTERN,
        detail="Name matches a known hallucination shape (e.g. <stem>-helpers / -utils / -async / -pro).",
    )
