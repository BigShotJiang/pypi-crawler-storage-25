"""Risk scoring engine."""

from __future__ import annotations

from slopguard.scoring.engine import ScoringEngine

__all__ = ["ScoringEngine"]
