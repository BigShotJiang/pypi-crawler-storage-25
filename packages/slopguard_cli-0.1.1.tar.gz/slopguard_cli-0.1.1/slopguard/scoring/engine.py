"""Scoring engine — combines signals into a per-dependency risk score."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

from slopguard.data import hallucination_index, popular_set
from slopguard.models import Dependency, DependencySource, Ecosystem, Finding, RiskTier, Signal
from slopguard.registry.base import PackageMetadata, RegistryClient, RegistryError
from slopguard.scoring import signals

DEFAULT_SUSPICIOUS_MIN = 0.4
DEFAULT_HALLUCINATED_MIN = 0.85

_REMEDIATION_HALLUCINATED = (
    "Remove this dependency. Verify the package your AI suggested actually exists "
    "at the source you trust."
)
_REMEDIATION_SUSPICIOUS = (
    "Inspect this dependency before installing — recent publication, low downloads, "
    "or close to a popular package name. If your AI suggested it, double-check the spelling."
)
_REMEDIATION_ERROR = (
    "SlopGuard could not score this dependency. Re-run with network access, or skip "
    "with --no-network plus an ignore rule."
)
_REMEDIATION_CLEAN = "No action required."


@dataclass(frozen=True)
class ScoringConfig:
    suspicious_min: float = DEFAULT_SUSPICIOUS_MIN
    hallucinated_min: float = DEFAULT_HALLUCINATED_MIN
    verbose: bool = False


class ScoringEngine:
    """Scores a list of dependencies against a registry client."""

    def __init__(
        self,
        *,
        npm_client: RegistryClient | None = None,
        pypi_client: RegistryClient | None = None,
        config: ScoringConfig | None = None,
        no_network: bool = False,
        concurrency: int = 16,
    ) -> None:
        self._npm = npm_client
        self._pypi = pypi_client
        self._config = config or ScoringConfig()
        self._no_network = no_network
        self._semaphore = asyncio.Semaphore(concurrency)
        self._db = hallucination_index()
        self._popular_npm = popular_set(Ecosystem.NPM)
        self._popular_pypi = popular_set(Ecosystem.PYPI)

    async def score_all(self, deps: list[Dependency]) -> list[Finding]:
        tasks = [self._score_one(d) for d in deps]
        return await asyncio.gather(*tasks)

    async def _score_one(self, dep: Dependency) -> Finding:
        async with self._semaphore:
            return await self._score_one_inner(dep)

    async def _score_one_inner(self, dep: Dependency) -> Finding:
        # Local file / link refs: scope says ignore. Git URLs: clean with a note.
        if dep.source in (DependencySource.FILE, DependencySource.LINK):
            return self._finding(dep, RiskTier.CLEAN, 0.0, [], _REMEDIATION_CLEAN)
        if dep.source is DependencySource.GIT:
            return self._finding(
                dep,
                RiskTier.CLEAN,
                0.0,
                [
                    Signal(
                        type="git_dependency",
                        weight=0.0,
                        detail="Git URL dependency — out of scope for v0.1 scoring.",
                    )
                ],
                _REMEDIATION_CLEAN,
            )

        # Scoped npm (@org/pkg) bypasses the registry probe unless the DB has it. Spec §9 edge cases.
        if dep.ecosystem is Ecosystem.NPM and dep.scoped:
            entry = self._db.get((dep.ecosystem, dep.name.lower()))
            if entry is None:
                return self._finding(dep, RiskTier.CLEAN, 0.0, [], _REMEDIATION_CLEAN)
            sig = signals.hallucination_db_hit(dep, entry)
            return self._finalize(dep, [sig] if sig else [])

        collected: list[Signal] = []

        # 1) DB hit short-circuits.
        entry = self._db.get((dep.ecosystem, dep.name.lower()))
        db_signal = signals.hallucination_db_hit(dep, entry)
        if db_signal is not None:
            collected.append(db_signal)
            # Only probe further if verbose — for the JSON report's completeness.
            if not (self._config.verbose and not self._no_network):
                return self._finalize(dep, collected)

        # 2) --no-network: only DB + name pattern.
        if self._no_network:
            pattern_sig = signals.name_pattern_suspicious(dep)
            if pattern_sig is not None:
                collected.append(pattern_sig)
            return self._finalize(dep, collected)

        # 3) Registry probe.
        client = self._client_for(dep.ecosystem)
        if client is None:
            return self._finding(
                dep,
                RiskTier.ERROR,
                0.0,
                collected,
                _REMEDIATION_ERROR,
                error=f"no registry client configured for {dep.ecosystem.value}",
            )

        try:
            meta = await client.fetch(dep.name)
        except RegistryError as exc:
            return self._finding(
                dep,
                RiskTier.ERROR,
                0.0,
                collected,
                _REMEDIATION_ERROR,
                error=str(exc),
            )
        except Exception as exc:
            return self._finding(
                dep,
                RiskTier.ERROR,
                0.0,
                collected,
                _REMEDIATION_ERROR,
                error=f"{type(exc).__name__}: {exc}",
            )

        # 4) 404 → registry_not_found and stop. Spec §9 step 3.
        nf = signals.registry_not_found(meta)
        if nf is not None:
            collected.append(nf)
            # Levenshtein is still informative when the package doesn't exist.
            lev = signals.levenshtein_typo(dep, self._popular_for(dep.ecosystem))
            if lev is not None:
                collected.append(lev)
            pat = signals.name_pattern_suspicious(dep)
            if pat is not None:
                collected.append(pat)
            return self._finalize(dep, collected)

        # 5) Full signal sweep.
        collected.extend(self._collect_metadata_signals(dep, meta))
        return self._finalize(dep, collected)

    def _collect_metadata_signals(self, dep: Dependency, meta: PackageMetadata) -> list[Signal]:
        out: list[Signal] = []
        very_recent, recent = signals.recently_published(meta)
        if very_recent is not None:
            out.append(very_recent)
        elif recent is not None:
            out.append(recent)
        low = signals.low_downloads(meta)
        if low is not None:
            out.append(low)
        np_sig = signals.new_publisher(meta)
        if np_sig is not None:
            out.append(np_sig)
        solo = signals.single_release_new_account(meta)
        if solo is not None:
            out.append(solo)
        lev = signals.levenshtein_typo(dep, self._popular_for(dep.ecosystem))
        if lev is not None:
            out.append(lev)
        pat = signals.name_pattern_suspicious(dep)
        if pat is not None:
            out.append(pat)
        return out

    def _finalize(self, dep: Dependency, sigs: list[Signal]) -> Finding:
        score = min(1.0, sum(s.weight for s in sigs))
        tier = self._tier_for(score)
        remediation = self._remediation_for(tier)
        return self._finding(dep, tier, score, sigs, remediation)

    def _tier_for(self, score: float) -> RiskTier:
        if score >= self._config.hallucinated_min:
            return RiskTier.HALLUCINATED
        if score >= self._config.suspicious_min:
            return RiskTier.SUSPICIOUS
        return RiskTier.CLEAN

    @staticmethod
    def _remediation_for(tier: RiskTier) -> str:
        if tier is RiskTier.HALLUCINATED:
            return _REMEDIATION_HALLUCINATED
        if tier is RiskTier.SUSPICIOUS:
            return _REMEDIATION_SUSPICIOUS
        if tier is RiskTier.ERROR:
            return _REMEDIATION_ERROR
        return _REMEDIATION_CLEAN

    @staticmethod
    def _finding(
        dep: Dependency,
        tier: RiskTier,
        score: float,
        sigs: list[Signal],
        remediation: str,
        *,
        error: str | None = None,
    ) -> Finding:
        return Finding(
            name=dep.name,
            version=dep.version,
            ecosystem=dep.ecosystem,
            manifest=dep.manifest,
            risk=tier,
            score=round(score, 4),
            signals=sigs,
            remediation=remediation,
            error=error,
        )

    def _client_for(self, ecosystem: Ecosystem) -> RegistryClient | None:
        return self._npm if ecosystem is Ecosystem.NPM else self._pypi

    def _popular_for(self, ecosystem: Ecosystem) -> frozenset[str]:
        return self._popular_npm if ecosystem is Ecosystem.NPM else self._popular_pypi
