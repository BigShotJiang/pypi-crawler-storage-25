"""Output formatters."""

from __future__ import annotations

from slopguard.report.json import write_json_report
from slopguard.report.terminal import render_terminal_report

__all__ = ["render_terminal_report", "write_json_report"]
