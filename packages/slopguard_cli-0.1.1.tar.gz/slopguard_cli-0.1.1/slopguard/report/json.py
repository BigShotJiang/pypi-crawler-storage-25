"""JSON report writer."""

from __future__ import annotations

import json
from pathlib import Path

from slopguard.models import ScanReport


def write_json_report(report: ScanReport, *, path: Path | None = None) -> str:
    """Serialise ``report`` to JSON. If ``path`` is set, write it there. Returns the JSON string."""
    payload = report.model_dump(mode="json")
    text = json.dumps(payload, indent=2, sort_keys=False) + "\n"
    if path is not None:
        path.write_text(text, encoding="utf-8")
    return text
