"""Rich terminal rendering."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table

from slopguard.models import Finding, RiskTier, ScanReport

_TIER_STYLE = {
    RiskTier.HALLUCINATED: "bold red",
    RiskTier.SUSPICIOUS: "bold yellow",
    RiskTier.CLEAN: "green",
    RiskTier.ERROR: "magenta",
}

_TIER_LABEL = {
    RiskTier.HALLUCINATED: "HALLUCIN.",
    RiskTier.SUSPICIOUS: "SUSPICIOUS",
    RiskTier.CLEAN: "CLEAN",
    RiskTier.ERROR: "ERROR",
}


def render_terminal_report(
    report: ScanReport,
    *,
    console: Console | None = None,
    show_clean: bool = True,
    duration_seconds: float | None = None,
) -> None:
    console = console or Console()
    console.print(f"[bold]SlopGuard v{report.slopguard_version}[/bold] — scanning {report.path}")
    console.print()
    if report.manifests:
        console.print("Detected manifests:")
        for m in report.manifests:
            console.print(
                f"  • {m.path} ([cyan]{m.ecosystem.value}[/cyan], {m.dependency_count} deps)"
            )
        console.print()

    total = report.summary.total
    if duration_seconds is not None:
        console.print(f"Scanned {total} dependencies in {duration_seconds:.1f}s.\n")
    else:
        console.print(f"Scanned {total} dependencies.\n")

    table = Table(show_header=True, header_style="bold")
    table.add_column("Package", no_wrap=False, max_width=40)
    table.add_column("Risk", no_wrap=True)
    table.add_column("Reason", overflow="fold")
    rows_added = 0
    for finding in report.findings:
        if not show_clean and finding.risk is RiskTier.CLEAN:
            continue
        style = _TIER_STYLE[finding.risk]
        label = _TIER_LABEL[finding.risk]
        reason = _summarise_reason(finding)
        table.add_row(finding.name, f"[{style}]{label}[/{style}]", reason)
        rows_added += 1
    if rows_added == 0:
        console.print("[green]All dependencies clean.[/green]")
    else:
        console.print(table)

    console.print()
    console.print(
        f"Summary: [bold red]{report.summary.hallucinated}[/bold red] hallucinated, "
        f"[bold yellow]{report.summary.suspicious}[/bold yellow] suspicious, "
        f"[green]{report.summary.clean}[/green] clean, "
        f"[magenta]{report.summary.errors}[/magenta] error(s)."
    )
    console.print(f"Exit code: [bold]{report.exit_code}[/bold]")


def _summarise_reason(finding: Finding) -> str:
    if finding.error:
        return finding.error
    if not finding.signals:
        return "No signals."
    # Top contributor first, then up to one additional.
    primary = max(finding.signals, key=lambda s: s.weight)
    extras = [s for s in finding.signals if s is not primary][:1]
    parts = [primary.detail]
    parts.extend(s.detail for s in extras)
    return " ".join(parts)
