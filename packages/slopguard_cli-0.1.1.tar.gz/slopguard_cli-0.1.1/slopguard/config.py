"""``.slopguard.yaml`` loader and merged config."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, ValidationError

from slopguard.scoring.engine import DEFAULT_HALLUCINATED_MIN, DEFAULT_SUSPICIOUS_MIN


class IgnoreConfig(BaseModel):
    packages: list[str] = Field(default_factory=list)
    patterns: list[str] = Field(default_factory=list)


class NetworkConfig(BaseModel):
    enabled: bool = True
    timeout_seconds: float = 5.0
    concurrency: int = 16


class ScoringFileConfig(BaseModel):
    suspicious_min_score: float = DEFAULT_SUSPICIOUS_MIN
    hallucinated_min_score: float = DEFAULT_HALLUCINATED_MIN


class FileConfig(BaseModel):
    """The schema of ``.slopguard.yaml``. All fields optional."""

    ignore: IgnoreConfig = Field(default_factory=IgnoreConfig)
    fail_on: str = "suspicious"
    network: NetworkConfig = Field(default_factory=NetworkConfig)
    scoring: ScoringFileConfig = Field(default_factory=ScoringFileConfig)


class ConfigError(Exception):
    """Raised when ``.slopguard.yaml`` is malformed."""


@dataclass(frozen=True)
class IgnoreRules:
    names: frozenset[str]
    patterns: tuple[re.Pattern[str], ...]

    def matches(self, name: str) -> bool:
        if name in self.names:
            return True
        return any(p.search(name) for p in self.patterns)


@dataclass(frozen=True)
class ResolvedConfig:
    """Merged config used by the CLI. CLI flags > file > defaults."""

    fail_on: str
    network_enabled: bool
    timeout_seconds: float
    concurrency: int
    suspicious_min: float
    hallucinated_min: float
    ignore: IgnoreRules = field(default_factory=lambda: IgnoreRules(frozenset(), ()))


def load_file_config(path: Path | None) -> FileConfig:
    """Load the YAML config. Returns defaults if ``path`` is None or missing."""
    if path is None or not path.exists():
        return FileConfig()
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(f"expected a YAML mapping at top level of {path}")
    try:
        return FileConfig.model_validate(raw)
    except ValidationError as exc:
        raise ConfigError(f"invalid .slopguard.yaml schema: {exc}") from exc


def resolve(
    file_cfg: FileConfig,
    *,
    cli_fail_on: str | None,
    cli_no_network: bool,
    cli_timeout: float | None,
    cli_concurrency: int | None,
) -> ResolvedConfig:
    fail_on = cli_fail_on or file_cfg.fail_on
    if fail_on not in {"any", "hallucinated", "suspicious", "none"}:
        raise ConfigError(f"invalid fail_on value: {fail_on!r}")
    network_enabled = file_cfg.network.enabled and not cli_no_network
    timeout = cli_timeout if cli_timeout is not None else file_cfg.network.timeout_seconds
    concurrency = cli_concurrency if cli_concurrency is not None else file_cfg.network.concurrency
    ignore = IgnoreRules(
        names=frozenset(file_cfg.ignore.packages),
        patterns=tuple(_compile_patterns(file_cfg.ignore.patterns)),
    )
    return ResolvedConfig(
        fail_on=fail_on,
        network_enabled=network_enabled,
        timeout_seconds=timeout,
        concurrency=concurrency,
        suspicious_min=file_cfg.scoring.suspicious_min_score,
        hallucinated_min=file_cfg.scoring.hallucinated_min_score,
        ignore=ignore,
    )


def _compile_patterns(patterns: list[str]) -> list[re.Pattern[str]]:
    compiled: list[re.Pattern[str]] = []
    for raw in patterns:
        try:
            compiled.append(re.compile(raw))
        except re.error as exc:
            raise ConfigError(f"invalid ignore pattern {raw!r}: {exc}") from exc
    return compiled


def default_config_path(start: Path) -> Path | None:
    """Search for ``.slopguard.yaml`` in ``start`` and its parents (up to 3 levels)."""
    cur = start.resolve()
    for _ in range(3):
        candidate = cur / ".slopguard.yaml"
        if candidate.exists():
            return candidate
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


def _ensure_yaml_safe(data: Any) -> None:  # pragma: no cover — diagnostic only
    """Belt-and-braces sanity check used by tests."""
    yaml.safe_dump(data)
