"""Pydantic models — wire contract for the JSON report and internal types."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Ecosystem(StrEnum):
    """Supported package ecosystems."""

    NPM = "npm"
    PYPI = "pypi"


class RiskTier(StrEnum):
    """Risk tier emitted for each scanned dependency.

    Ordering (low → high): ``clean`` < ``error`` < ``suspicious`` < ``hallucinated``.
    ``error`` sits below ``suspicious`` because it usually reflects a transient
    network or parse problem rather than evidence of risk.
    """

    CLEAN = "clean"
    ERROR = "error"
    SUSPICIOUS = "suspicious"
    HALLUCINATED = "hallucinated"


class DependencySource(StrEnum):
    """Where a dependency reference came from."""

    REGISTRY = "registry"
    FILE = "file"
    LINK = "link"
    GIT = "git"
    URL = "url"


class Dependency(BaseModel):
    """A single dependency entry parsed from a manifest."""

    model_config = ConfigDict(frozen=True)

    name: str
    version: str | None = None
    ecosystem: Ecosystem
    manifest: str
    source: DependencySource = DependencySource.REGISTRY
    scoped: bool = False


class Signal(BaseModel):
    """One contributing signal toward a finding's risk score."""

    type: str
    weight: float = Field(ge=0.0, le=1.0)
    detail: str


class Finding(BaseModel):
    """The result of scoring a single dependency."""

    name: str
    version: str | None = None
    ecosystem: Ecosystem
    manifest: str
    risk: RiskTier
    score: float = Field(ge=0.0, le=1.0)
    signals: list[Signal] = Field(default_factory=list)
    remediation: str
    error: str | None = None


class ManifestInfo(BaseModel):
    """Summary of a single manifest scanned during this run."""

    path: str
    ecosystem: Ecosystem
    dependency_count: int = Field(ge=0)


class ScanSummary(BaseModel):
    """Aggregate counts over all findings in a scan."""

    total: int = Field(ge=0)
    clean: int = Field(ge=0)
    suspicious: int = Field(ge=0)
    hallucinated: int = Field(ge=0)
    errors: int = Field(ge=0)


class ScanReport(BaseModel):
    """Top-level scan report. This is the JSON wire format — treat as a public API."""

    slopguard_version: str
    scan_id: str
    scanned_at: datetime
    path: str
    manifests: list[ManifestInfo]
    summary: ScanSummary
    findings: list[Finding]
    exit_code: Literal[0, 1, 2]


class HallucinationEntry(BaseModel):
    """One row in the embedded hallucination database."""

    name: str
    ecosystem: Ecosystem
    first_seen: str
    recurrence_rate: float = Field(ge=0.0, le=1.0)
    models_observed: list[str]
    notes: str


class HallucinationDB(BaseModel):
    """Loaded hallucination database."""

    schema_version: int
    updated: str
    entries: list[HallucinationEntry]


class PopularPackages(BaseModel):
    """Top-N popularity lists per ecosystem (used for Levenshtein typosquat checks)."""

    schema_version: int
    npm_top_1000: list[str]
    pypi_top_1000: list[str]
