"""Enables ``python -m slopguard``."""

from __future__ import annotations

from slopguard.cli import app


def main() -> None:
    app()


if __name__ == "__main__":
    main()
