"""Stub for the future ``slopguard update`` remote DB refresh.

# TODO(v0.2): implement a signed-bundle download from a trusted host.
"""

from __future__ import annotations


def run() -> int:
    """Print a not-yet-implemented message and exit 0."""
    print(
        "slopguard update is not implemented in v0.1. The embedded seed database "
        "ships with the package and is refreshed by upgrading slopguard itself."
    )
    return 0
