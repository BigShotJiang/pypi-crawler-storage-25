"""Registry clients for npm and PyPI."""

from __future__ import annotations

from slopguard.registry.base import RegistryClient, RegistryError
from slopguard.registry.npm import NpmRegistryClient
from slopguard.registry.pypi import PypiRegistryClient

__all__ = [
    "NpmRegistryClient",
    "PypiRegistryClient",
    "RegistryClient",
    "RegistryError",
]
