"""npm registry client."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from urllib.parse import quote

from slopguard.registry.base import PackageMetadata, RegistryClient, RegistryError

NPM_REGISTRY = "https://registry.npmjs.org"
NPM_DOWNLOADS = "https://api.npmjs.org/downloads/point/last-month"


def _parse_iso(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    # npm timestamps end with 'Z' — Python <3.11 chokes on it, 3.11+ handles via fromisoformat
    try:
        if value.endswith("Z"):
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        return datetime.fromisoformat(value)
    except ValueError:
        return None


class NpmRegistryClient(RegistryClient):
    """Probe ``registry.npmjs.org`` for package metadata."""

    async def _fetch_uncached(self, name: str) -> PackageMetadata:
        url = f"{NPM_REGISTRY}/{quote(name, safe='@/')}"
        response = await self._request_with_retry("GET", url)
        if response.status_code == 404:
            return PackageMetadata(name=name, exists=False)
        if response.status_code != 200:
            raise RegistryError(f"unexpected status {response.status_code} from {url}")
        try:
            data: dict[str, Any] = response.json()
        except ValueError as exc:
            raise RegistryError(f"invalid JSON from {url}: {exc}") from exc

        time_raw = data.get("time")
        time_block: dict[str, Any] = time_raw if isinstance(time_raw, dict) else {}
        first_release = _parse_iso(time_block.get("created"))
        latest_release = _parse_iso(time_block.get("modified"))

        publisher: str | None = None
        maintainers = data.get("maintainers")
        if isinstance(maintainers, list) and maintainers:
            first = maintainers[0]
            if isinstance(first, dict) and isinstance(first.get("name"), str):
                publisher = first["name"]

        downloads = await self._fetch_downloads(name)

        return PackageMetadata(
            name=name,
            exists=True,
            first_release=first_release,
            latest_release=latest_release,
            publisher=publisher,
            downloads_recent=downloads,
        )

    async def _fetch_downloads(self, name: str) -> int | None:
        url = f"{NPM_DOWNLOADS}/{quote(name, safe='@/')}"
        try:
            response = await self._request_with_retry("GET", url)
        except RegistryError:
            return None
        if response.status_code != 200:
            return None
        try:
            payload = response.json()
        except ValueError:
            return None
        downloads = payload.get("downloads") if isinstance(payload, dict) else None
        return downloads if isinstance(downloads, int) else None
