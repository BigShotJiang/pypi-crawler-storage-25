"""Registry client base + shared metadata type."""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime

import httpx


class RegistryError(Exception):
    """Raised when a registry probe fails in a way the caller should know about."""


@dataclass(frozen=True)
class PackageMetadata:
    """Subset of registry metadata used by the scoring engine."""

    name: str
    exists: bool
    first_release: datetime | None = None
    latest_release: datetime | None = None
    publisher: str | None = None
    publisher_created: datetime | None = None
    publisher_package_count: int | None = None
    downloads_recent: int | None = None
    extras: dict[str, str] = field(default_factory=dict)


class RegistryClient(ABC):
    """Async registry client. Implementations cache responses for the lifetime of one scan."""

    def __init__(
        self,
        *,
        client: httpx.AsyncClient | None = None,
        timeout: float = 5.0,
        max_retries: int = 2,
    ) -> None:
        self._owned_client = client is None
        self._client = client or httpx.AsyncClient(
            timeout=timeout,
            headers={
                "User-Agent": "slopguard/0.1 (+https://github.com/hariomunknownslab/slopguard)"
            },
        )
        self._timeout = timeout
        self._max_retries = max_retries
        self._cache: dict[str, PackageMetadata] = {}
        self._cache_lock = asyncio.Lock()

    async def __aenter__(self) -> RegistryClient:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owned_client:
            await self._client.aclose()

    async def fetch(self, name: str) -> PackageMetadata:
        """Fetch metadata for ``name``. Returns ``exists=False`` on 404.

        Raises :class:`RegistryError` on any error the caller cannot interpret as
        existence / non-existence (network failures, persistent 5xx, etc.).
        """
        async with self._cache_lock:
            cached = self._cache.get(name)
            if cached is not None:
                return cached

        meta = await self._fetch_uncached(name)
        async with self._cache_lock:
            self._cache[name] = meta
        return meta

    @abstractmethod
    async def _fetch_uncached(self, name: str) -> PackageMetadata: ...

    async def _request_with_retry(self, method: str, url: str) -> httpx.Response:
        last_exc: Exception | None = None
        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(method, url, timeout=self._timeout)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                if attempt >= self._max_retries:
                    raise RegistryError(f"network error fetching {url}: {exc}") from exc
                await asyncio.sleep(min(2**attempt * 0.2, 2.0))
                continue
            if response.status_code == 429:
                retry_after = float(response.headers.get("Retry-After", "1") or "1")
                if attempt >= self._max_retries:
                    raise RegistryError(f"rate limited by {url}")
                await asyncio.sleep(min(retry_after, 5.0))
                continue
            if response.status_code >= 500:
                if attempt >= self._max_retries:
                    raise RegistryError(f"server error {response.status_code} at {url}")
                await asyncio.sleep(min(2**attempt * 0.2, 2.0))
                continue
            return response
        # Should be unreachable; the loop either returns or raises above.
        raise RegistryError(f"unexpected retry exhaustion fetching {url}: {last_exc}")
