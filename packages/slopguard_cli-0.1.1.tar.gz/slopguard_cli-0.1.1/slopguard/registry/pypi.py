"""PyPI registry client."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from urllib.parse import quote

from slopguard.registry.base import PackageMetadata, RegistryClient, RegistryError

PYPI_JSON = "https://pypi.org/pypi"
PYPISTATS_RECENT = "https://pypistats.org/api/packages"


def _parse_iso(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        if value.endswith("Z"):
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        return datetime.fromisoformat(value)
    except ValueError:
        return None


class PypiRegistryClient(RegistryClient):
    """Probe ``pypi.org/pypi/<name>/json`` for package metadata."""

    async def _fetch_uncached(self, name: str) -> PackageMetadata:
        url = f"{PYPI_JSON}/{quote(name, safe='')}/json"
        response = await self._request_with_retry("GET", url)
        if response.status_code == 404:
            return PackageMetadata(name=name, exists=False)
        if response.status_code != 200:
            raise RegistryError(f"unexpected status {response.status_code} from {url}")
        try:
            data: dict[str, Any] = response.json()
        except ValueError as exc:
            raise RegistryError(f"invalid JSON from {url}: {exc}") from exc

        info_raw = data.get("info")
        info: dict[str, Any] = info_raw if isinstance(info_raw, dict) else {}
        releases_raw = data.get("releases")
        releases: dict[str, Any] = releases_raw if isinstance(releases_raw, dict) else {}

        first_release: datetime | None = None
        latest_release: datetime | None = None
        timestamps: list[datetime] = []
        for files in releases.values():
            if not isinstance(files, list):
                continue
            for f in files:
                if not isinstance(f, dict):
                    continue
                ts = _parse_iso(f.get("upload_time_iso_8601") or f.get("upload_time"))
                if ts is not None:
                    timestamps.append(ts)
        if timestamps:
            timestamps.sort()
            first_release = timestamps[0]
            latest_release = timestamps[-1]

        author = info.get("author")
        maintainer = info.get("maintainer")
        publisher: str | None = author if isinstance(author, str) and author else None
        if not publisher and isinstance(maintainer, str) and maintainer:
            publisher = maintainer

        downloads = await self._fetch_downloads(name)

        return PackageMetadata(
            name=name,
            exists=True,
            first_release=first_release,
            latest_release=latest_release,
            publisher=publisher,
            downloads_recent=downloads,
        )

    async def _fetch_downloads(self, name: str) -> int | None:
        url = f"{PYPISTATS_RECENT}/{quote(name, safe='')}/recent"
        try:
            response = await self._request_with_retry("GET", url)
        except RegistryError:
            return None
        if response.status_code != 200:
            return None
        try:
            payload = response.json()
        except ValueError:
            return None
        if not isinstance(payload, dict):
            return None
        data = payload.get("data")
        if isinstance(data, dict):
            week = data.get("last_week")
            if isinstance(week, int):
                return week
        return None
