"""Resolver layer package."""
