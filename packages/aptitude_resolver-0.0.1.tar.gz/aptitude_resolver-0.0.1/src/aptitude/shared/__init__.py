"""Shared support package."""
