# mcp-python-bitcoinlib

> An MCP server that exposes the python-bitcoinlib API

[![PyPI](https://img.shields.io/pypi/v/mcp-python-bitcoinlib.svg)](https://pypi.org/project/mcp-python-bitcoinlib/)
[![Python](https://img.shields.io/pypi/pyversions/mcp-python-bitcoinlib.svg)](https://pypi.org/project/mcp-python-bitcoinlib/)
[![Coverage](https://codecov.io/gh/daedalus/mcp-python-bitcoinlib/branch/main/graph/badge.svg)](https://codecov.io/gh/daedalus/mcp-python-bitcoinlib)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

## Install

```bash
pip install mcp-python-bitcoinlib
```

## Usage

```bash
mcp-python-bitcoinlib
```

## MCP Configuration

mcp-name: io.github.daedalus/mcp-python-bitcoinlib

### For Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "mcp-python-bitcoinlib": {
      "command": "mcp-python-bitcoinlib",
      "env": {}
    }
  }
}
```

## Tools

The server exposes the following Bitcoin tools:

- **Key Management**: Generate private keys, convert between WIF and hex
- **Address Generation**: P2PKH, P2SH, P2WPKH, P2WSH addresses
- **Transaction Building**: Create and sign transactions
- **Script Operations**: Parse and create Bitcoin scripts
- **Cryptography**: SHA256, RIPEMD160, Hash160, Hash256, ECDSA signing/verification

## Development

```bash
git clone https://github.com/daedalus/mcp-python-bitcoinlib.git
cd mcp-python-bitcoinlib
pip install -e ".[test]"

# run tests
pytest

# format
ruff format src/ tests/

# lint
ruff check src/ tests/

# type check
mcp-python-bitcoinlib src/
```
