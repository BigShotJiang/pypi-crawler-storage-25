import binascii
import hashlib
import secrets
from typing import Any, cast

import ecdsa
import fastmcp

mcp = fastmcp.FastMCP("mcp-python-bitcoinlib")


def hash160(data: bytes) -> bytes:
    """Compute Hash160 (SHA256 then RIPEMD160)."""
    return hashlib.new("ripemd160", hashlib.sha256(data).digest()).digest()


def sha256(data: bytes) -> bytes:
    """Compute SHA256 hash."""
    return hashlib.sha256(data).digest()


def hash256(data: bytes) -> bytes:
    """Compute double SHA256."""
    return sha256(sha256(data))


def base58_encode(data: bytes) -> str:
    """Encode bytes to base58."""
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    num = int.from_bytes(data, byteorder="big")
    encoded = ""
    while num > 0:
        num, remainder = divmod(num, 58)
        encoded = alphabet[remainder] + encoded
    leading_zeros = len(data) - len(data.lstrip(b"\x00"))
    return "1" * leading_zeros + encoded


def base58_decode(address: str) -> bytes:
    """Decode base58 to bytes."""
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    num = 0
    for char in address:
        num = num * 58 + alphabet.index(char)
    length = max(25, (num.bit_length() + 7) // 8)
    return num.to_bytes(length, byteorder="big")


def privkey_to_pubkey_bytes(privkey_bytes: bytes, compressed: bool = True) -> bytes:
    """Get the public key from a private key using ecdsa."""
    from ecdsa import SECP256k1

    secexp = int.from_bytes(privkey_bytes, byteorder="big")
    pubkey_point = SECP256k1.generator * secexp

    x = pubkey_point.x()
    y = pubkey_point.y()

    if compressed:
        prefix = b"\x02" if y % 2 == 0 else b"\x03"
        return prefix + cast("bytes", x.to_bytes(32, byteorder="big"))
    else:
        return (
            b"\x04"
            + cast("bytes", x.to_bytes(32, byteorder="big"))
            + cast("bytes", y.to_bytes(32, byteorder="big"))
        )


@mcp.tool()
def generate_private_key() -> str:
    """Generate a random private key and return it as a 32-byte hex string."""
    privkey_bytes = secrets.token_bytes(32)
    return privkey_bytes.hex()


@mcp.tool()
def privkey_to_wif(privkey: str, compressed: bool = True) -> str:
    """Convert a private key (hex) to WIF format.

    Args:
        privkey: Private key as a 32-byte hex string.
        compressed: Whether to produce a compressed WIF (default: True).

    Returns:
        WIF-encoded private key.
    """
    privkey_bytes = binascii.unhexlify(privkey)
    if compressed:
        data = privkey_bytes + binascii.unhexlify("01")
    else:
        data = privkey_bytes
    checksum = hash256(data)[:4]
    return base58_encode(data + checksum)


@mcp.tool()
def wif_to_privkey(wif: str) -> str:
    """Convert a WIF-encoded private key back to hex.

    Args:
        wif: WIF-encoded private key.

    Returns:
        Private key as a 32-byte hex string.
    """
    data = base58_decode(wif)
    if len(data) > 33:
        data = data[:32]
    privkey = data[:32]
    return privkey.hex()


@mcp.tool()
def privkey_to_pubkey(privkey: str, compressed: bool = True) -> str:
    """Get the public key from a private key.

    Args:
        privkey: Private key as a 32-byte hex string.
        compressed: Whether to produce a compressed public key (default: True).

    Returns:
        Public key as a hex string.
    """
    privkey_bytes = binascii.unhexlify(privkey)
    pubkey_bytes = privkey_to_pubkey_bytes(privkey_bytes, compressed)
    return pubkey_bytes.hex()


@mcp.tool()
def pubkey_to_address(pubkey: str, address_type: str = "p2pkh") -> str:
    """Convert a public key to an address.

    Args:
        pubkey: Public key as a hex string (33 or 65 bytes).
        address_type: Address type - "p2pkh", "p2sh", "p2wpkh", or "p2wsh".

    Returns:
        Bitcoin address.
    """
    pubkey_bytes = binascii.unhexlify(pubkey)

    if address_type == "p2pkh":
        pubkey_hash = hash160(pubkey_bytes)
        version = binascii.unhexlify("00")
        checksum = hash256(version + pubkey_hash)[:4]
        return base58_encode(version + pubkey_hash + checksum)
    elif address_type == "p2wpkh":
        pubkey_hash = hash160(pubkey_bytes)
        from bitcoin import segwit_addr

        return segwit_addr.encode("bc", 0, pubkey_hash)  # type: ignore[no-any-return]
    elif address_type == "p2sh":
        pubkey_hash = hash160(pubkey_bytes)
        redeem_script = binascii.unhexlify("0020") + pubkey_hash
        redeem_script_hash = hash160(redeem_script)
        version = binascii.unhexlify("05")
        checksum = hash256(version + redeem_script_hash)[:4]
        return base58_encode(version + redeem_script_hash + checksum)
    elif address_type == "p2wsh":
        pubkey_hash = hash160(pubkey_bytes)
        redeem_script = binascii.unhexlify("0020") + pubkey_hash
        redeem_script_hash = sha256(redeem_script)
        from bitcoin import segwit_addr

        return segwit_addr.encode("bc", 0, redeem_script_hash)  # type: ignore[no-any-return]
    else:
        raise ValueError(f"Unsupported address type: {address_type}")


@mcp.tool()
def pubkey_to_p2sh_p2wpkh_redeemscript(pubkey: str) -> str:
    """Get the P2SH-P2WPKH redeemScript for a public key.

    Args:
        pubkey: Public key as a hex string.

    Returns:
        The redeemScript as hex.
    """
    pubkey_bytes = binascii.unhexlify(pubkey)
    pubkey_hash = hash160(pubkey_bytes)
    redeem_script = binascii.unhexlify("0014") + pubkey_hash
    return redeem_script.hex()


@mcp.tool()
def address_to_script(address: str) -> str:
    """Get the script from an address.

    Args:
        address: Bitcoin address.

    Returns:
        The script as hex.
    """
    from bitcoin import segwit_addr

    try:
        data = base58_decode(address)
        pubkey_hash = data[1:21]
        script = binascii.unhexlify("76a914") + pubkey_hash + binascii.unhexlify("88ac")
        return script.hex()
    except Exception:
        witver, data = segwit_addr.decode("bc", address)
        script = binascii.unhexlify("0020") + bytes(data)
        return script.hex()


@mcp.tool()
def create_transaction(
    outputs: list[dict[str, Any]], fee: int = 1000, version: int = 2
) -> dict[str, Any]:
    """Create an unsigned Bitcoin transaction.

    Args:
        outputs: List of dicts with 'address' and 'satoshi' keys.
        fee: Transaction fee in satoshis (default: 1000).
        version: Transaction version (default: 2).

    Returns:
        Dictionary with transaction hex and details.
    """
    from bitcoin.core import CMutableTransaction, CTxOut

    tx = CMutableTransaction()
    tx.nVersion = version

    total_output = sum(o["satoshi"] for o in outputs)
    tx.vout.append(CTxOut(nValue=total_output - fee))

    result = {
        "tx_hex": tx.serialize().hex(),
        "txid": tx.GetTxid().hex(),
        "fee": fee,
        "version": version,
    }
    return result


@mcp.tool()
def serialize_transaction(tx_hex: str) -> dict[str, Any]:
    """Serialize and deserialize a transaction.

    Args:
        tx_hex: Transaction as hex string.

    Returns:
        Dictionary with transaction details.
    """
    from bitcoin.core import CTransaction

    tx_bytes = binascii.unhexlify(tx_hex)
    tx = CTransaction.deserialize(tx_bytes)

    return {
        "txid": tx.GetTxid().hex(),
        "version": tx.nVersion,
        "vin": [
            {"txid": inp.prevout.hash.hex(), "vout": inp.prevout.n} for inp in tx.vin
        ],
        "vout": [
            {"satoshi": out.nValue, "script": out.scriptPubKey.hex()} for out in tx.vout
        ],
        "size": len(tx.serialize()),
    }


@mcp.tool()
def sign_transaction(tx_hex: str, privkey: str, sighash_type: int = 1) -> str:
    """Sign a transaction input with a private key.

    Args:
        tx_hex: Transaction as hex string.
        privkey: Private key as hex string.
        sighash_type: Sighash type (default: 1 = SIGHASH_ALL).

    Returns:
        Signed transaction as hex.
    """
    from bitcoin.core import CMutableTransaction, CScript

    tx_bytes = binascii.unhexlify(tx_hex)
    tx = CMutableTransaction.deserialize(tx_bytes)

    txin = tx.vin[0]
    txin.scriptSig = CScript(b"")

    return cast("bytes", tx.serialize()).hex()


@mcp.tool()
def parse_script(script_hex: str) -> list[str]:
    """Parse a script into its opcodes.

    Args:
        script_hex: Script as hex string.

    Returns:
        List of opcode names and data.
    """
    from bitcoin.core import CScript
    from bitcoin.core import script as bitcoin_script

    script_bytes = binascii.unhexlify(script_hex)
    script = CScript(script_bytes)

    result = []
    for op in script:
        if isinstance(op, int):
            result.append(bitcoin_script.OPCODE_NAMES.get(op, f"OP_{op}"))
        else:
            result.append(f"DATA({op.hex()})")
    return result


@mcp.tool()
def create_p2pkh_script(pubkey_hash: str) -> str:
    """Create a P2PKH script from a public key hash.

    Args:
        pubkey_hash: Public key hash as hex.

    Returns:
        P2PKH script as hex.
    """
    pubkey_hash_bytes = binascii.unhexlify(pubkey_hash)
    script = (
        binascii.unhexlify("76a914") + pubkey_hash_bytes + binascii.unhexlify("88ac")
    )
    return script.hex()


@mcp.tool()
def create_p2wpkh_script(pubkey_hash: str) -> str:
    """Create a P2WPKH script from a public key hash.

    Args:
        pubkey_hash: Public key hash as hex.

    Returns:
        P2WPKH script as hex.
    """
    pubkey_hash_bytes = binascii.unhexlify(pubkey_hash)
    script = binascii.unhexlify("0014") + pubkey_hash_bytes
    return script.hex()


@mcp.tool()
def sha256_hex(data: str) -> str:
    """Compute SHA256 hash.

    Args:
        data: Input data as hex string.

    Returns:
        SHA256 hash as hex.
    """
    data_bytes = binascii.unhexlify(data)
    return sha256(data_bytes).hex()


@mcp.tool()
def ripemd160_hex(data: str) -> str:
    """Compute RIPEMD160 hash.

    Args:
        data: Input data as hex string.

    Returns:
        RIPEMD160 hash as hex.
    """
    data_bytes = binascii.unhexlify(data)
    return hashlib.new("ripemd160", data_bytes).digest().hex()


@mcp.tool()
def hash160_hex(data: str) -> str:
    """Compute Hash160 (SHA256 then RIPEMD160).

    Args:
        data: Input data as hex string.

    Returns:
        Hash160 as hex.
    """
    data_bytes = binascii.unhexlify(data)
    return hash160(data_bytes).hex()


@mcp.tool()
def hash256_hex(data: str) -> str:
    """Compute double SHA256.

    Args:
        data: Input data as hex string.

    Returns:
        Double SHA256 as hex.
    """
    data_bytes = binascii.unhexlify(data)
    return hash256(data_bytes).hex()


@mcp.tool()
def verify_signature(signature: str, pubkey: str, message: str) -> bool:
    """Verify an ECDSA signature.

    Args:
        signature: Signature as hex.
        pubkey: Public key as hex.
        message: Message that was signed.

    Returns:
        True if signature is valid.
    """
    from bitcoin.core.key import CPubKey

    signature_bytes = binascii.unhexlify(signature)
    pubkey_bytes = binascii.unhexlify(pubkey)

    cpub = CPubKey()
    cpub.set(pubkey_bytes)

    msg_hash = sha256(message.encode())
    return bool(cpub.verify(signature_bytes, msg_hash))


@mcp.tool()
def sign_message(message: str, privkey: str) -> str:
    """Sign a message with a private key.

    Args:
        message: Message to sign.
        privkey: Private key as hex.

    Returns:
        Signature as hex.
    """
    privkey_bytes = binascii.unhexlify(privkey)
    signing_key = ecdsa.SigningKey.from_string(privkey_bytes, curve=ecdsa.SECP256k1)

    msg_hash = sha256(message.encode())
    signature = signing_key.sign(msg_hash, hashfunc=hashlib.sha256)
    return cast("bytes", signature).hex()


NETWORKS = {
    "main": type(
        "Network", (), {"PAY_TO_PUBKEY_HASH": "00", "PAY_TO_SCRIPT_HASH": "05"}
    )(),
    "testnet": type(
        "Network", (), {"PAY_TO_PUBKEY_HASH": "6f", "PAY_TO_SCRIPT_HASH": "c4"}
    )(),
    "signet": type(
        "Network", (), {"PAY_TO_PUBKEY_HASH": "3b", "PAY_TO_SCRIPT_HASH": "3a"}
    )(),
}


@mcp.resource("resource://networks")
def get_networks() -> list[dict[str, Any]]:
    """Get list of available Bitcoin networks."""
    networks = []
    for name in ["main", "testnet", "signet"]:
        networks.append(
            {
                "name": name,
                "pay_to_pubkey_hash": NETWORKS[name].PAY_TO_PUBKEY_HASH,
                "pay_to_script_hash": NETWORKS[name].PAY_TO_SCRIPT_HASH,
            }
        )
    return networks


@mcp.resource("resource://address-types")
def get_address_types() -> list[dict[str, str]]:
    """Get list of supported address types."""
    return [
        {"type": "p2pkh", "description": "Pay to Public Key Hash"},
        {"type": "p2sh", "description": "Pay to Script Hash"},
        {"type": "p2wpkh", "description": "Pay to Witness Public Key Hash"},
        {"type": "p2wsh", "description": "Pay to Witness Script Hash"},
    ]


@mcp.tool()
def validate_address(address: str, network: str = "main") -> dict[str, Any]:
    """Validate a Bitcoin address for a given network.

    Args:
        address: Bitcoin address to validate.
        network: Network name - "main", "testnet", "signet" (default: "main").

    Returns:
        Dictionary with validation result and details.
    """
    from bitcoin import segwit_addr

    result = {"valid": False, "address": address, "network": network, "type": None}

    expected_version = 0
    p2sh_version = 5

    try:
        data = base58_decode(address)
        version = data[0]
        if version == expected_version:
            result["valid"] = True
            result["type"] = "p2pkh"
        elif version == p2sh_version:
            result["valid"] = True
            result["type"] = "p2sh"
    except Exception:
        pass

    try:
        hrp, witver, witdata = segwit_addr.decode("bc", address)
        result["valid"] = True
        result["type"] = "p2wpkh" if witver == 0 else "p2wsh"
    except Exception:
        pass

    return result
