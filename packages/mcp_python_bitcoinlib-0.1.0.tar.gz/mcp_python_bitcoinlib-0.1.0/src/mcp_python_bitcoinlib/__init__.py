__version__ = "0.1.0"
__all__ = ["mcp"]

from typing import TYPE_CHECKING

from ._server import mcp

if TYPE_CHECKING:
    from ._server import *
