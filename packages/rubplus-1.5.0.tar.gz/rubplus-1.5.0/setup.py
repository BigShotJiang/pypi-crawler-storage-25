from setuptools import setup, find_packages

setup(
    name="rubplus",
    version="1.5.0",
    author="Mahdi Afsarbeki",
    author_email="mahdiafsarbeki@iran.ir",
    description="Official Rubika Bot API wrapper - Simple, Modern, Powerful",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/mahdiafsarbeki/rubplus",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=["httpx>=0.27.0"],
    license="MIT",
    keywords=["rubika", "bot", "api", "rubplus", "quiz", "poll"],
)