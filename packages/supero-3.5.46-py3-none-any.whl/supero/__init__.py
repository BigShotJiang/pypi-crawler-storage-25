"""
Supero - High-level API for multi-tenant object management.
Enhanced with Platform UI integration for tenant management, schema uploads, and SDK generation.
"""


def init(app_name: str = "supero", log_level: str = "INFO"):
    """Initialize Supero environment (loggers, etc.) without connecting to API."""
    try:
        from py_api_lib import api_logger
        api_logger.initialize_logger(app_name, log_level=log_level)
    except Exception:
        pass


# Core classes
from .core import Supero, SchemaRegistry, SchemaProxy
from .reference import Reference
from .platform_client import (
    PlatformClient,
    AuthenticationError,
    AuthorizationError,
    RateLimitError,
)

# Platform operations
from .platform_operations import (
    register_domain,
    register_user,
    login,
)

# Bootstrap — one-call idempotent setup
from .bootstrap import bootstrap, BootstrapResult

# AI data classes (for type hints)
from .ai_manager import (
    ChatResponse,
    Session,
    Tool,
    ToolResult,
    VectorSearchResult,
)

# CRUD and file managers
from .crud_manager import CrudManager, CrudQueryBuilder
from .file_manager import FileManager, FileReference, BatchUploadResult


# ── Convenience functions ────────────────────────────────────────────────────

def quickstart(name: str, package_namespace: str = None, **kwargs):
    """Convenience function for Supero.quickstart()"""
    return Supero.quickstart(name, package_namespace=package_namespace, **kwargs)


def connect(domain_name: str, api_key: str = None,
            package_namespace: str = None, **kwargs):
    """Convenience function for Supero.connect()"""
    return Supero.connect(
        domain_name,
        api_key=api_key,
        package_namespace=package_namespace,
        **kwargs,
    )


# bootstrap() is already imported directly from .bootstrap above.
# It is available as:
#   from supero import bootstrap
#   supero.bootstrap(domain_name=..., admin_email=..., admin_password=...)
# And as a class method:
#   Supero.bootstrap(domain_name=..., admin_email=..., admin_password=...)



# ── App Server (v1.2.0) ─────────────────────────────────────────────────────
# CORS proxy server + typed service wrappers for all 32 platform services
try:
    from .server import Services
except ImportError:
    Services = None  # httpx not installed

# ── App Setup Helpers (v1.2.0) ───────────────────────────────────────────────
# Reusable setup functions for generated apps
try:
    from .app_setup import (
        AppSetup,
        ensure_services,
        ensure_workflows,
        ensure_access_policies,
        Progress,
        # Policy helpers
        PolicyDef,
        PolicyRule,
        # Response helpers — used in seed_test_data
        extract_uuid,
        extract_error,
        is_ok,
        is_already_exists,
        # Session + URL helpers
        create_session,
        build_base_url,
        parse_host_port,
        # UUID lookups
        fetch_project_uuid,
        fetch_tenant_uuid,
        # Seed helpers
        create_with_children,
        # Schema name normalization (Scope B fix)
        normalize_schema_name,
        to_url_name,
        seed_record,
    )
except ImportError:
    AppSetup = None  # app_setup dependencies not installed

# ── Public API ───────────────────────────────────────────────────────────────

__all__ = [
    # Environment
    'init',

    # One-call setup (NEW)
    'bootstrap',
    'BootstrapResult',

    # Platform operations
    'register_domain',
    'register_user',
    'login',

    # Convenience functions
    'quickstart',
    'connect',

    # Main class
    'Supero',

    # Supporting classes
    'Reference',
    'SchemaRegistry',
    'SchemaProxy',

    # CRUD
    'CrudManager',
    'CrudQueryBuilder',

    # Files
    'FileManager',
    'FileReference',
    'BatchUploadResult',

    # HTTP client
    'PlatformClient',
    'AuthenticationError',
    'AuthorizationError',
    'RateLimitError',

    # AI data classes
    'ChatResponse',
    'Session',
    'Tool',
    'ToolResult',
    'VectorSearchResult',

    # App Server (v1.2.0)
    'Services',
    # Unified Services + Lifecycle (v1.5.70)
    'ServiceLib',
    'service_lib',

    # App Setup (v1.2.0)
    'AppSetup',
    'ensure_services',
    'ensure_workflows',
    'ensure_access_policies',
    'Progress',
    'PolicyDef',
    'PolicyRule',
    'extract_uuid',
    'extract_error',
    'is_ok',
    'is_already_exists',
    'create_session',
    'build_base_url',
    'parse_host_port',
    'fetch_project_uuid',
    'fetch_tenant_uuid',
    'create_with_children',
    'normalize_schema_name',
    'to_url_name',
    'seed_record',
    'make_seed_record',
    'ref_link',
]

__version__ = "3.5.46"
