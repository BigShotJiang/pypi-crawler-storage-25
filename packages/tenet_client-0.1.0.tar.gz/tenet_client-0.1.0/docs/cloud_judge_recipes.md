# Cloud Judge Integration Recipes

`TenetCloudJudgeClient` is the entire SDK surface for the cloud judge.
Where to call it inside your agent — at every tool boundary, only at
the user's input, only at the agent's final output, or somewhere
custom — is **your decision, not ours**. This package deliberately
ships no opinionated middleware: the recipes below show the canonical
attachment points so you can copy what fits and adapt.

Pick from:

| Recipe | When to use |
|---|---|
| 1. `wrap_tool_call` middleware | You want every tool call gated by the judge. The most common shape — compliance violations almost always show up at tool boundaries. |
| 2. `before_agent` / `after_agent` middleware | You want to gate the user's prompt or the agent's final answer. Read the latency caveat first. |
| 3. LangChain callback handler | Your project uses callbacks instead of agent middleware. |
| 4. Framework-free standalone | You're not using LangChain, or you want to call the judge from custom code (a tool wrapper, a pre-execution gate, a webhook). |

All four recipes are self-contained — they import `TenetCloudJudgeClient`
plus whichever LangChain types they need, nothing else from
`tenet_client`. Copy the snippet, drop it into your project, swap
the credentials.

## Choosing a judge

The cloud judge service currently exposes two judges, both with the
same wire shape (`{decision: "allow" | "block", reason: <short>?}`):

| `judge_id` | What it gates | Backend |
|---|---|---|
| `hr-1` (default) | EEO / hiring / employment compliance for HR-vertical agents | Fireworks |
| `healthcare-1` | PHI / HIPAA / clinical-safety compliance for healthcare-vertical agents | Modal |

Pick the judge by passing `judge_id="..."` to `TenetCloudJudgeClient(...)`,
or by setting `TENET_JUDGE_ID` if you construct via `from_env()`:

```python
hr_client = TenetCloudJudgeClient.from_env()  # judge_id="hr-1" by default
healthcare_client = TenetCloudJudgeClient(
    client_id="<your-m2m-client-id>",
    client_secret="<your-m2m-client-secret>",
    judge_id="healthcare-1",
)
```

All four recipes below are judge-agnostic — they show `hr-1`-flavored
class names by default, but the integration shape is identical for
`healthcare-1`. If you gate two verticals from one agent, instantiate
two clients and stack two middleware instances.

## Failure handling — your call

Every recipe shows a `try / except JudgeUnavailableError` block. The
SDK raises `JudgeUnavailableError` whenever it cannot get a verdict
(timeouts, 5xx, malformed responses, Auth0 mint failures, expired
tokens that fail to refresh). It does **not** ship a `fail_open` flag
because that's a policy decision. Two reasonable defaults:

- **Fail-closed** — re-raise from the `except` block; the agent halts.
  Right for compliance-critical surfaces (HR, finance, healthcare).
- **Fail-open** — log a warning and proceed; the tool runs. Right for
  development environments and surfaces where the cost of blocking
  on a transient AWS hiccup outweighs the cost of a missed judge call.

Pick one per environment; don't mix.

---

## Recipe 1 — `wrap_tool_call` middleware

The canonical shape for blocking-judge integration. Calls the judge at
both `tool_pre` and `tool_post`. On `decision="block"`, returns a
`ToolMessage` with a safe template instead of running the tool (or, on
`tool_post`, instead of returning the raw output).

> **Already shipped as a reusable middleware.** The shape below is also
> available as `CloudJudgeMiddleware` in the `tenet-langchain` package.
> If you don't need to customize, prefer that — it's the same pattern
> with extra ergonomics (`from_env()`, `check_pre`/`check_post` toggles,
> trace propagation). The recipe below is here for integrators who want
> a copy-pasteable starting point to modify, or who have policy requirements
> that need a tweaked shape (e.g. a custom `safe_message`, additional logging,
> or a non-default phase strategy). The `tenet-langchain` README is the
> place to start for the pre-built version.

```python
from langchain.agents.middleware import AgentMiddleware
from langchain.agents.middleware.types import ToolCallRequest
from langchain_core.messages import ToolMessage

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient


class HRJudgeMiddleware(AgentMiddleware):
    """Calls the HR cloud judge at every tool boundary.

    Block on `decision="block"`, halt on `JudgeUnavailableError`.
    Flip `fail_open=True` in dev if you want transient cloud errors
    to be silently ignored.
    """

    def __init__(
        self,
        client: TenetCloudJudgeClient,
        *,
        fail_open: bool = False,
        safe_message: str = "Blocked by Tenet compliance judge.",
    ) -> None:
        super().__init__()
        self._client = client
        self._fail_open = fail_open
        self._safe_message = safe_message

    async def awrap_tool_call(self, request: ToolCallRequest, handler):
        tool_name = request.tool_call.get("name", "")
        tool_args = request.tool_call.get("args") or {}
        tool_call_id = request.tool_call.get("id", "")

        # Pre-call check
        try:
            verdict = await self._client.evaluate_async(
                phase="tool_pre",
                tool_name=tool_name,
                tool_input=tool_args,
            )
        except JudgeUnavailableError:
            if not self._fail_open:
                raise
            return await handler(request)

        if verdict.decision == "block":
            return ToolMessage(
                content=self._safe_message,
                tool_call_id=tool_call_id,
                name=tool_name,
                status="error",
            )

        # Tool runs
        result = await handler(request)

        # Post-call check on the tool's output
        output_text = result.content if isinstance(result, ToolMessage) else str(result)
        try:
            verdict = await self._client.evaluate_async(
                phase="tool_post",
                tool_name=tool_name,
                tool_input=tool_args,
                tool_output=output_text,
            )
        except JudgeUnavailableError:
            if not self._fail_open:
                raise
            return result

        if verdict.decision == "block":
            return ToolMessage(
                content=self._safe_message,
                tool_call_id=tool_call_id,
                name=tool_name,
                status="error",
            )
        return result
```

Wire it up the same way as any other `AgentMiddleware`:

```python
from langchain.agents import create_agent

from tenet_client import TenetCloudJudgeClient

client = TenetCloudJudgeClient.from_env()  # reads TENET_* env vars
agent = create_agent(
    model="claude-sonnet-4-5-20250514",
    tools=[...],
    middleware=[HRJudgeMiddleware(client, fail_open=False)],
)
```

---

## Recipe 2 — `before_agent` / `after_agent`

Calls the judge on the user's prompt and the agent's final answer
instead of (or in addition to) tool boundaries.

> **Latency caveat.** Each `evaluate()` call is one Auth0 hop (cached
> after the first) plus one round-trip to the cloud — typically
> 200–600 ms steady-state. Adding a check at `before_agent` and
> `after_agent` adds two of those to every conversation turn. If your
> users are interactive, you may want only one of the two. Tool
> boundaries (Recipe 1) are usually the highest-value surface.
>
> **False-positive caveat.** Blocking the user's prompt produces a
> very visible "your message was rejected" UX. Blocking the final
> answer produces "the agent gave up partway through." Both are
> annoying when the judge is wrong. Most teams turn these on only
> after they've seen the false-positive rate from real traffic.

```python
from typing import Any

from langchain.agents.middleware import AgentMiddleware, hook_config
from langchain.agents.middleware.types import AgentState
from langchain_core.messages import AIMessage, HumanMessage

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient


class HRAgentBoundaryMiddleware(AgentMiddleware):
    """Judges the user's input on entry and the agent's output on exit."""

    def __init__(
        self,
        client: TenetCloudJudgeClient,
        *,
        fail_open: bool = False,
        check_input: bool = True,
        check_output: bool = True,
        safe_message: str = "Blocked by Tenet compliance judge.",
    ) -> None:
        super().__init__()
        self._client = client
        self._fail_open = fail_open
        self._check_input = check_input
        self._check_output = check_output
        self._safe_message = safe_message

    @hook_config(can_jump_to=["end"])
    async def abefore_agent(self, state: AgentState, runtime: Any):
        if not self._check_input:
            return None
        last_human = next(
            (m for m in reversed(state.get("messages", [])) if isinstance(m, HumanMessage)),
            None,
        )
        if last_human is None or not isinstance(last_human.content, str):
            return None

        try:
            verdict = await self._client.evaluate_async(
                phase="agent_input",
                tool_input=last_human.content,
            )
        except JudgeUnavailableError:
            if not self._fail_open:
                raise
            return None

        if verdict.decision == "block":
            return {
                "messages": [{"role": "assistant", "content": self._safe_message}],
                "jump_to": "end",
            }
        return None

    @hook_config(can_jump_to=["end"])
    async def aafter_agent(self, state: AgentState, runtime: Any):
        if not self._check_output:
            return None
        last_ai = next(
            (m for m in reversed(state.get("messages", [])) if isinstance(m, AIMessage)),
            None,
        )
        if last_ai is None or not isinstance(last_ai.content, str):
            return None

        try:
            verdict = await self._client.evaluate_async(
                phase="agent_output",
                tool_output=last_ai.content,
            )
        except JudgeUnavailableError:
            if not self._fail_open:
                raise
            return None

        if verdict.decision == "block":
            return {
                "messages": [{"role": "assistant", "content": self._safe_message}],
                "jump_to": "end",
            }
        return None
```

---

## Recipe 3 — LangChain callback handler

If your project uses LangChain callback handlers instead of agent
middleware (e.g., older code paths, or you're attaching to non-agent
chains), the same pattern works as a `BaseCallbackHandler` /
`AsyncCallbackHandler`.

`on_tool_start` doesn't have a clean way to *replace* the tool call —
LangChain calls the tool right after this hook returns regardless. So
the canonical pattern is to **raise** from `on_tool_start` to abort
the tool and let the agent surface the error. `on_tool_end` is
informational only.

```python
import asyncio
import json
from typing import Any
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient


class HRJudgeCallbackHandler(BaseCallbackHandler):
    """Judges every tool call before it runs.

    Raises a RuntimeError on `decision="block"` to abort the tool.
    On `JudgeUnavailableError`, behavior depends on `fail_open`.
    """

    def __init__(
        self,
        client: TenetCloudJudgeClient,
        *,
        fail_open: bool = False,
        safe_message: str = "Blocked by Tenet compliance judge.",
    ) -> None:
        self._client = client
        self._fail_open = fail_open
        self._safe_message = safe_message

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        tool_name = serialized.get("name", "")
        tool_input = inputs if inputs is not None else _try_parse_json(input_str)

        try:
            # The sync evaluate() makes the call blocking. If your handler
            # runs inside an async context, swap for evaluate_async() in an
            # AsyncCallbackHandler subclass instead.
            verdict = self._client.evaluate(
                phase="tool_pre",
                tool_name=tool_name,
                tool_input=tool_input,
                trace_id=str(run_id),
                parent_span_id=str(parent_run_id) if parent_run_id else None,
            )
        except JudgeUnavailableError:
            if not self._fail_open:
                raise
            return

        if verdict.decision == "block":
            raise RuntimeError(self._safe_message)


def _try_parse_json(s: str) -> Any:
    try:
        return json.loads(s)
    except (ValueError, TypeError):
        return s
```

For the async equivalent, subclass `AsyncCallbackHandler` and call
`await self._client.evaluate_async(...)` instead of the sync
`evaluate()`. Otherwise identical.

---

## Recipe 4 — Framework-free standalone

You don't have to use LangChain at all. Call the client directly from
any code that gates an agent action — a tool wrapper, an HTTP
middleware, a custom orchestration step, a webhook receiver.

```python
from typing import Any

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient


def gated_search_resumes(
    client: TenetCloudJudgeClient,
    *,
    query: str,
    fail_open: bool = False,
) -> list[dict[str, Any]]:
    """Run search_resumes only if the HR judge allows it."""
    tool_input = {"query": query}

    try:
        verdict = client.evaluate(
            phase="tool_pre",
            tool_name="search_resumes",
            tool_input=tool_input,
        )
    except JudgeUnavailableError:
        if not fail_open:
            raise
        verdict = None  # let through

    if verdict is not None and verdict.decision == "block":
        raise PermissionError(
            f"Tenet HR judge blocked search_resumes: {verdict.reason or '<no reason>'}"
        )

    return _real_search_resumes(query)


def _real_search_resumes(query: str) -> list[dict[str, Any]]:
    """Stub for whatever your real backend is — DB query, API call, etc."""
    return []
```

Async version: replace `client.evaluate(...)` with
`await client.evaluate_async(...)` and make the function `async`.

---

## What about HITL / "review" decisions?

Both shipping judges (`hr-1` and `healthcare-1`) return
`"allow" | "block"` only — there's no `"review"` tier. If you want a
soft-fail signal (e.g., log + flag for human review without blocking),
wrap the recipes above with your own threshold logic, or call the
client and route on `verdict.decision` yourself. The cloud API may
grow a richer response shape in a future version; the SDK's
`CloudJudgeResponse` is the place that change will surface.

## Warm the client at process start

The first `evaluate()` call from a fresh client pays a cold-path tax:
TLS handshake to Auth0 (~150 ms cold), the Auth0 token mint round
trip (~150–400 ms), and a TLS handshake to the cloud (~80–150 ms cold).
That can easily reach 600–900 ms on the first call vs. ~50–150 ms
once everything is warm.

Call `warmup()` (or `warmup_async()`) at process start to move the
Auth0 round trip out of the user-facing critical path. It mints the
token + populates the cache; the first real `evaluate()` then only
pays the cloud-side handshake (one-time, ~80–150 ms).

```python
# Sync — module-level startup
from tenet_client import TenetCloudJudgeClient

_client = TenetCloudJudgeClient.from_env()
_client.warmup()  # also doubles as a credential smoke test on startup


# Async — FastAPI startup hook
from contextlib import asynccontextmanager
from fastapi import FastAPI
from tenet_client import TenetCloudJudgeClient


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.judge = TenetCloudJudgeClient.from_env()
    await app.state.judge.warmup_async()
    yield
    await app.state.judge.aclose()


app = FastAPI(lifespan=lifespan)
```

`warmup()` is idempotent — calling it again with a cached token is a
no-op. Failure during warmup raises `JudgeUnavailableError`, so
catching it at startup gives you a clean credential / connectivity
smoke test before the first user request lands.

## Where credentials come from

All recipes assume `TenetCloudJudgeClient` is constructed once at
process start and shared across calls (the in-memory token cache is
per-instance). The simplest pattern:

```python
import os

from tenet_client import TenetCloudJudgeClient


def _build_judge_client() -> TenetCloudJudgeClient:
    """Read M2M creds from env. Each customer's client_id/secret is
    issued by Tenet at provisioning time; rotate via Auth0 dashboard.
    """
    return TenetCloudJudgeClient.from_env()
    # Equivalent explicit form:
    # return TenetCloudJudgeClient(
    #     client_id=os.environ["TENET_CLIENT_ID"],
    #     client_secret=os.environ["TENET_CLIENT_SECRET"],
    # )
```

## Where to read more

- The client API: `tenet_client.cloud_client.TenetCloudJudgeClient`
- Wire types: `tenet_client.cloud_models.{CloudJudgeRequest, CloudJudgeResponse, JudgeUnavailableError}`
- Production cloud surface: `https://api.tenetlabs.com/v1/judge/evaluate`

These recipes target a stable client contract. When the shipping
judges graduate (e.g. `hr-2`, `healthcare-2`) or new judge IDs ship,
nothing in the recipes changes — swap the `judge_id` parameter on the
client and you're done.
