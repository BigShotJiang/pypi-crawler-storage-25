"""Tests for ``tenet_client.recipes`` — partner-configurable policy factories.

The recipes module ships canonical JudgePolicy presets that bake in the
forge-research-informed defaults (RFC-008 §4.4.5). Customers wire these
into ``TenetJudgeMiddleware`` directly, or copy the source as a starting
point for application-specific policies.
"""

from __future__ import annotations

from tenet_client import JudgeAction, JudgeContext, JudgePolicy, JudgeVerdict
from tenet_client.recipes import severity_routed_policy


def _verdict(severity, *, reason="bad input", safe_message="fix it"):
    return JudgeVerdict(
        decision="block",
        status="triggered",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=1,
        severity=severity,
        reason=reason,
        safe_message=safe_message,
    )


def _ctx(tool_name="search"):
    return JudgeContext(phase="tool_pre", tool_name=tool_name)


class TestSeverityRoutedPolicyDefaults:
    """Default mapping: low/medium → retry_nudge; high/critical → tool_error."""

    def test_low_severity_returns_retry_nudge(self):
        p = severity_routed_policy()
        action = p.decide(_ctx(), _verdict("low"))
        assert action.kind == "retry_nudge"
        assert "bad input" in (action.guidance or "")

    def test_medium_severity_returns_retry_nudge(self):
        p = severity_routed_policy()
        action = p.decide(_ctx(), _verdict("medium"))
        assert action.kind == "retry_nudge"

    def test_high_severity_returns_tool_error(self):
        p = severity_routed_policy()
        action = p.decide(_ctx(), _verdict("high"))
        assert action.kind == "tool_error"
        assert "fix it" in (action.message or "")

    def test_critical_severity_returns_tool_error(self):
        p = severity_routed_policy()
        action = p.decide(_ctx(), _verdict("critical"))
        assert action.kind == "tool_error"

    def test_missing_severity_falls_through_to_tool_error(self):
        # When the cloud doesn't populate severity (v1 surface today),
        # the recipe still has to emit a defensible action. Default is
        # tool_error — same as JudgePolicy's pre-Phase-4.5 on_block.
        p = severity_routed_policy()
        v = _verdict(None)
        action = p.decide(_ctx(), v)
        assert action.kind == "tool_error"

    def test_allow_verdict_passes_through(self):
        # Recipe only customizes on_block; allow/review fall through to
        # the existing defaults.
        p = severity_routed_policy()
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
        )
        action = p.decide(_ctx(), v)
        assert action.kind == "allow"


class TestSeverityRoutedPolicyConfigurable:
    def test_custom_retry_nudge_severities(self):
        # Caller can elect to retry-nudge "high" too (e.g. soft launch).
        p = severity_routed_policy(retry_nudge_severities=("low", "medium", "high"))
        assert p.decide(_ctx(), _verdict("high")).kind == "retry_nudge"
        assert p.decide(_ctx(), _verdict("critical")).kind == "tool_error"

    def test_custom_tool_error_severities(self):
        # Tight policy: only "critical" is hard-blocked; everything else
        # is a retry_nudge. (low/medium remain retry_nudge by default.)
        p = severity_routed_policy(
            retry_nudge_severities=("low", "medium", "high"),
            tool_error_severities=("critical",),
        )
        assert p.decide(_ctx(), _verdict("high")).kind == "retry_nudge"
        assert p.decide(_ctx(), _verdict("critical")).kind == "tool_error"

    def test_human_review_severities(self):
        # Optional escalation path — partner-configurable.
        p = severity_routed_policy(human_review_severities=("critical",))
        action = p.decide(_ctx(), _verdict("critical"))
        assert action.kind == "human_review"

    def test_human_review_wins_over_tool_error_when_both_match(self):
        # When a severity appears in both human_review and tool_error
        # buckets, human_review takes precedence — it's the more
        # specific, opt-in escalation.
        p = severity_routed_policy(
            tool_error_severities=("high", "critical"),
            human_review_severities=("critical",),
        )
        assert p.decide(_ctx(), _verdict("critical")).kind == "human_review"
        assert p.decide(_ctx(), _verdict("high")).kind == "tool_error"


class TestSeverityRoutedPolicyComposition:
    def test_passes_through_other_callbacks(self):
        # The recipe should not override unrelated callbacks the caller
        # supplies (on_review, on_unavailable, on_unresolved).
        seen = {}

        def on_unresolved(_ctx, _v):
            seen["unresolved"] = True
            return JudgeAction.retry_nudge("custom unresolved")

        p = severity_routed_policy(on_unresolved=on_unresolved)
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
        )
        action = p.decide(_ctx(), v, resolution_status="unresolved")
        assert seen.get("unresolved") is True
        assert action.guidance == "custom unresolved"

    def test_per_tool_override_composes(self):
        # Per-tool override should still work alongside the recipe.
        strict = JudgePolicy(
            on_block=lambda c, v: JudgeAction.tool_error("hard block for email")
        )
        p = severity_routed_policy(per_tool={"send_email": strict})
        # send_email tool → uses strict policy regardless of severity.
        assert (
            p.decide(_ctx(tool_name="send_email"), _verdict("low")).kind == "tool_error"
        )
        # other tools → recipe applies.
        assert (
            p.decide(_ctx(tool_name="search"), _verdict("low")).kind == "retry_nudge"
        )

    def test_returns_a_judge_policy(self):
        # The recipe must return a real JudgePolicy so it composes with
        # everywhere the type appears (middleware, decorators, dispatch).
        p = severity_routed_policy()
        assert isinstance(p, JudgePolicy)
