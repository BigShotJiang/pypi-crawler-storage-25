"""End-to-end smoke against the live cloud judge service.

Gated on ``TENET_E2E=1`` so CI and routine local pytest runs skip it.
When enabled, the test reads M2M credentials from env, mints a real
Auth0 token, and hits the deployed ``POST /v1/judge/evaluate`` route
through API Gateway (``https://api.tenetlabs.com`` by default).

Required env when ``TENET_E2E=1``:

  TENET_CLIENT_ID          M2M client_id
  TENET_CLIENT_SECRET      M2M client_secret

Optional escape hatches (dev / staging only — defaults point at production):

  TENET_CLOUD_URL           defaults to https://api.tenetlabs.com
  TENET_AUTH0_AUDIENCE      defaults to https://sdk.tenetlabs.com
  TENET_AUTH0_ISSUER_URL    defaults to https://auth.tenetlabs.com/

Two assertion modes — see ``TENET_E2E_EXPECT`` env:

  ``unavailable`` (default; current production state)
      The route returns 503 because the HR Fireworks env vars are not
      yet populated. SDK should map that to ``JudgeUnavailableError``.

  ``verdict``
      The HR model is configured. Both ``allow`` and ``block`` cases
      should round-trip cleanly; the test asserts a structurally valid
      response shape on the neutral input. Block-path verification is
      separate (requires a fixture that the model reliably blocks).

Flip ``TENET_E2E_EXPECT=verdict`` once the operator populates
``judge_image_tag``-shipped ``hr_fireworks_endpoint`` /
``hr_model_name`` in ``ops/terraform.tfvars`` and re-applies.
"""

from __future__ import annotations

import os
import time

import pytest

from tenet_client import (
    CloudJudgeResponse,
    JudgeUnavailableError,
    TenetCloudJudgeClient,
)

E2E_ENABLED = os.environ.get("TENET_E2E") == "1"

pytestmark = pytest.mark.skipif(
    not E2E_ENABLED,
    reason="TENET_E2E=1 not set; live-cloud e2e tests skipped",
)


@pytest.fixture(scope="module")
def client() -> TenetCloudJudgeClient:
    """Construct a real client from TENET_* env vars."""
    return TenetCloudJudgeClient.from_env()


def _expectation_mode() -> str:
    return os.environ.get("TENET_E2E_EXPECT", "unavailable").lower()


class TestLiveSmoke:
    """Hits the live deployed cloud judge through API Gateway."""

    def test_neutral_input_round_trips(self, client: TenetCloudJudgeClient) -> None:
        """Send a clean input and assert the SDK either:

        - raises JudgeUnavailableError (the model is not yet configured;
          API Gateway -> ALB -> uvicorn -> FastAPI all reachable, route
          returns 503), OR
        - returns a structurally valid CloudJudgeResponse (the model is
          live; verdict is most likely "allow" on a benign input).

        The test does NOT assert on the verdict value because the model
        is non-deterministic on borderline inputs. Allow/block path
        coverage belongs in a separate fixture-driven test once the
        model is deployed and stable.
        """
        mode = _expectation_mode()
        start = time.perf_counter()
        try:
            resp = client.evaluate(
                phase="tool_pre",
                tool_name="search_resumes",
                tool_input={"query": "5+ years of Python experience"},
            )
        except JudgeUnavailableError as e:
            elapsed_ms = int((time.perf_counter() - start) * 1000)
            if mode == "unavailable":
                # Expected: cloud returned 503 because HR env vars are unset.
                # The SDK collapsed that into JudgeUnavailableError.
                print(
                    f"\n[e2e] JudgeUnavailableError after {elapsed_ms}ms (expected, "
                    f"mode=unavailable): {e}"
                )
                return
            pytest.fail(
                f"unexpected JudgeUnavailableError in mode={mode}: {e}\n"
                "If the HR model is now configured, this test should be"
                " run with TENET_E2E_EXPECT=verdict; if not, restore the"
                " Fireworks env vars before re-running."
            )

        elapsed_ms = int((time.perf_counter() - start) * 1000)
        assert isinstance(resp, CloudJudgeResponse)
        assert resp.judge_id == "hr-1"
        assert resp.judge_version  # non-empty
        assert resp.decision in ("allow", "block")
        # latency_ms is the SERVER-side latency reported by the judge,
        # always >= 0. Print round-trip latency too so test output gives
        # operators a quick signal on real-world p50.
        assert resp.latency_ms >= 0
        print(
            f"\n[e2e] verdict={resp.decision} server_latency_ms={resp.latency_ms} "
            f"round_trip_ms={elapsed_ms}"
        )
        if mode == "unavailable":
            pytest.fail(
                f"expected JudgeUnavailableError but got verdict={resp.decision}.\n"
                "If the HR model has been configured (Fireworks env vars set "
                "in ops/terraform.tfvars), re-run with TENET_E2E_EXPECT=verdict."
            )

    def test_token_caching_round_trip(self, client: TenetCloudJudgeClient) -> None:
        """Two back-to-back calls should both succeed without re-auth.

        Token-cache *correctness* is exhaustively covered by the unit
        tests in ``test_cloud_client.py`` (mint count assertions on a
        mocked transport, deterministic). This e2e test is a sanity
        check: if the cache were broken end-to-end, the second call
        would either raise a 401 (token rejected) or surface a fresh
        Auth0 mint failure. We do not assert on timing because real-
        world network jitter routinely exceeds the cache savings on
        a fast home connection.
        """
        mode = _expectation_mode()
        if mode != "verdict":
            pytest.skip("token-cache e2e check requires a configured judge model")

        start1 = time.perf_counter()
        try:
            resp1 = client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        except JudgeUnavailableError as e:
            pytest.fail(f"first call raised in mode=verdict: {e}")
        first_ms = int((time.perf_counter() - start1) * 1000)

        start2 = time.perf_counter()
        try:
            resp2 = client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        except JudgeUnavailableError as e:
            pytest.fail(f"second call raised in mode=verdict: {e}")
        second_ms = int((time.perf_counter() - start2) * 1000)

        print(f"\n[e2e] first={first_ms}ms second={second_ms}ms")
        assert resp1.judge_id == "hr-1"
        assert resp2.judge_id == "hr-1"
