"""Tests for the framework-agnostic policy/verdict/action/context types.

Reframes the integration around developer-owned control. The cloud
judge produces a verdict; the application's policy decides the runtime
action. These types live in ``tenet-client`` so non-LangChain consumers
(custom agents, FastAPI middleware, queue workers) can use them too.
"""

from __future__ import annotations

import pytest

from tenet_client import (
    JudgeAction,
    JudgeContext,
    JudgePolicy,
    JudgeVerdict,
)
from tenet_client.cloud_models import CloudJudgeResponse


# ---------------------------------------------------------------------------
# JudgeVerdict — superset of CloudJudgeResponse with review/status/severity
# ---------------------------------------------------------------------------


class TestJudgeVerdict:
    def test_minimum_fields(self):
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=12,
        )
        assert v.decision == "allow"
        assert v.status == "ok"
        assert v.severity is None
        assert v.reason is None
        assert v.safe_message is None
        assert v.findings == []
        assert v.action is None

    def test_review_decision_is_allowed(self):
        v = JudgeVerdict(
            decision="review",
            status="ok",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=12,
            severity="medium",
            reason="suspicious phrasing",
        )
        assert v.decision == "review"
        assert v.severity == "medium"

    def test_block_decision_with_safe_message(self):
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=15,
            severity="high",
            reason="PHI exfiltration",
            safe_message="Blocked: cannot share PHI.",
            findings=[{"rule": "phi", "snippet": "[redacted]"}],
        )
        assert v.decision == "block"
        assert v.safe_message == "Blocked: cannot share PHI."
        assert v.findings == [{"rule": "phi", "snippet": "[redacted]"}]

    def test_invalid_decision_rejected(self):
        with pytest.raises(Exception):
            JudgeVerdict(
                decision="oops",  # type: ignore[arg-type]
                status="ok",
                judge_id="x",
                judge_version="y",
                latency_ms=1,
            )

    def test_invalid_status_rejected(self):
        with pytest.raises(Exception):
            JudgeVerdict(
                decision="allow",
                status="weird",  # type: ignore[arg-type]
                judge_id="x",
                judge_version="y",
                latency_ms=1,
            )

    def test_from_cloud_response_allow(self):
        # Backward-compat shim: today's CloudJudgeResponse is allow|block only.
        cloud = CloudJudgeResponse(
            decision="allow",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "allow"
        assert v.status == "ok"
        assert v.judge_id == "hr-1"
        assert v.latency_ms == 10
        assert v.reason is None

    def test_from_cloud_response_block(self):
        cloud = CloudJudgeResponse(
            decision="block",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=20,
            reason="PHI",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "block"
        assert v.status == "triggered"
        assert v.reason == "PHI"

    def test_from_cloud_response_native_pass_is_allow(self):
        """Native `verdict='pass'` (head_fast_pass) → allow regardless of
        the synthesized legacy decision."""
        cloud = CloudJudgeResponse(
            decision="allow",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="pass",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "allow"

    def test_from_cloud_response_native_route_to_human_is_review(self):
        """Native `verdict='route_to_human'` represents a reviewable
        outcome the user can resolve — distinct from a terminal block."""
        cloud = CloudJudgeResponse(
            decision="block",  # legacy maps non-allow to "block"
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="route_to_human",
            risk_labels=["EEO-AGE-PROXY-01"],
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "review"
        # Risk labels surface on findings for policy callbacks to inspect.
        assert any(
            isinstance(f, dict) and f.get("rule_id") == "EEO-AGE-PROXY-01"
            for f in v.findings
        )

    def test_from_cloud_response_native_defer_is_review(self):
        cloud = CloudJudgeResponse(
            decision="block",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="defer",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "review"

    def test_from_cloud_response_native_exclude_is_review(self):
        cloud = CloudJudgeResponse(
            decision="block",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="exclude",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "review"

    def test_from_cloud_response_native_include_with_caveats_is_review(self):
        cloud = CloudJudgeResponse(
            decision="block",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="include_with_caveats",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "review"

    def test_from_cloud_response_native_block_is_block(self):
        """Only `verdict='block'` maps to terminal block — everything
        else non-pass routes through review."""
        cloud = CloudJudgeResponse(
            decision="block",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="block",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.decision == "block"

    def test_from_cloud_response_severity_propagates(self):
        cloud = CloudJudgeResponse(
            decision="block",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=10,
            verdict="route_to_human",
            severity="high",
        )
        v = JudgeVerdict.from_cloud_response(cloud)
        assert v.severity == "high"


# ---------------------------------------------------------------------------
# JudgeContext — phase + identifiers passed to policy callbacks
# ---------------------------------------------------------------------------


class TestJudgeContext:
    def test_default_context(self):
        ctx = JudgeContext(phase="tool_pre", tool_name="search")
        assert ctx.phase == "tool_pre"
        assert ctx.tool_name == "search"
        assert ctx.tool_input is None
        assert ctx.tool_output is None
        assert ctx.session_id is None
        assert ctx.trace_id is None
        assert ctx.metadata == {}

    def test_full_context(self):
        ctx = JudgeContext(
            phase="tool_post",
            tool_name="get_chart",
            tool_input={"patient_id": "MRN1"},
            tool_output={"chart": "..."},
            session_id="sess-1",
            trace_id="trace-1",
            metadata={"source": "agent"},
        )
        assert ctx.phase == "tool_post"
        assert ctx.metadata == {"source": "agent"}


# ---------------------------------------------------------------------------
# JudgeAction — framework-agnostic decision the policy returns
# ---------------------------------------------------------------------------


class TestJudgeAction:
    def test_allow(self):
        a = JudgeAction.allow()
        assert a.kind == "allow"
        assert a.metadata == {}
        assert a.message is None

    def test_allow_with_metadata(self):
        a = JudgeAction.allow(metadata={"tenet_review": True})
        assert a.kind == "allow"
        assert a.metadata == {"tenet_review": True}

    def test_block(self):
        a = JudgeAction.block(message="cannot proceed")
        assert a.kind == "block"
        assert a.message == "cannot proceed"

    def test_tool_error(self):
        a = JudgeAction.tool_error("Blocked by Tenet.")
        assert a.kind == "tool_error"
        assert a.message == "Blocked by Tenet."

    def test_override_input(self):
        a = JudgeAction.override_input({"q": "[redacted]"})
        assert a.kind == "override_input"
        assert a.payload == {"q": "[redacted]"}

    def test_override_output(self):
        a = JudgeAction.override_output("Sorry, I cannot share PHI.")
        assert a.kind == "override_output"
        assert a.payload == "Sorry, I cannot share PHI."

    def test_raise_error(self):
        err = RuntimeError("network down")
        a = JudgeAction.raise_error(err)
        assert a.kind == "raise_error"
        assert a.error is err

    def test_human_review(self):
        a = JudgeAction.human_review(metadata={"queue": "phi-review"})
        assert a.kind == "human_review"
        assert a.metadata == {"queue": "phi-review"}


# ---------------------------------------------------------------------------
# JudgeAction.retry_nudge — forge-inspired self-correction (RFC-008 §4.4.5)
# ---------------------------------------------------------------------------


class TestJudgeActionRetryNudge:
    """The retry_nudge JudgeAction kind feeds a corrective tool result back
    to the agent loop so it can self-correct on the next iteration — distinct
    from ``tool_error`` ("give up on this call") and ``override_output``
    ("replace with fixed string"). See RFC-008 §4.4.5.
    """

    def test_retry_nudge_constructor_sets_kind_and_guidance(self):
        a = JudgeAction.retry_nudge("Cannot proceed: PHI present. Drop the MRN.")
        assert a.kind == "retry_nudge"
        assert a.guidance == "Cannot proceed: PHI present. Drop the MRN."

    def test_retry_nudge_metadata_passthrough(self):
        a = JudgeAction.retry_nudge("nudge", metadata={"finding_id": "f-1"})
        assert a.metadata == {"finding_id": "f-1"}

    def test_retry_nudge_requires_non_empty_guidance(self):
        with pytest.raises(ValueError):
            JudgeAction.retry_nudge("")

    def test_retry_nudge_requires_non_none_guidance(self):
        # Direct-construction guard: bypassing the factory still validates.
        with pytest.raises(ValueError):
            JudgeAction(kind="retry_nudge", guidance=None)

    def test_other_action_kinds_reject_guidance_field(self):
        # Only retry_nudge may carry guidance; other kinds must keep it None
        # so the discriminated-union semantics stay clean.
        with pytest.raises(ValueError):
            JudgeAction(kind="allow", guidance="oops")
        with pytest.raises(ValueError):
            JudgeAction(kind="tool_error", message="m", guidance="oops")

    def test_retry_nudge_serializes_round_trip(self):
        from dataclasses import asdict

        original = JudgeAction.retry_nudge("guidance text", metadata={"k": "v"})
        d = asdict(original)
        # error is not JSON-serializable as a BaseException; round-trip via
        # the dict shape should preserve the load-bearing fields.
        assert d["kind"] == "retry_nudge"
        assert d["guidance"] == "guidance text"
        assert d["metadata"] == {"k": "v"}
        rebuilt = JudgeAction(
            kind=d["kind"],
            message=d["message"],
            payload=d["payload"],
            error=d["error"],
            metadata=d["metadata"],
            guidance=d["guidance"],
        )
        assert rebuilt == original


class TestJudgeActionRetryNudgeFromVerdict:
    """Canonical constructor that assembles guidance from a JudgeVerdict's
    reason + safe_message via the documented two-line template. Falls back
    when either field is missing.
    """

    def _verdict(self, *, reason=None, safe_message=None):
        return JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="hr-1",
            judge_version="hr-1.0.0",
            latency_ms=1,
            reason=reason,
            safe_message=safe_message,
        )

    def test_uses_reason_and_safe_message(self):
        v = self._verdict(
            reason="PHI present in tool input",
            safe_message="Remove the MRN and retry.",
        )
        a = JudgeAction.retry_nudge_from_verdict(v)
        assert a.kind == "retry_nudge"
        assert "PHI present in tool input" in a.guidance  # type: ignore[operator]
        assert "Remove the MRN and retry." in a.guidance  # type: ignore[operator]
        # Two-line template — reason on line 1, suggested correction on line 2.
        lines = a.guidance.splitlines()  # type: ignore[union-attr]
        assert lines[0].startswith("Cannot proceed as requested:")
        assert lines[1].startswith("Suggested correction:")

    def test_uses_reason_for_correction_when_safe_message_missing(self):
        v = self._verdict(reason="PHI present", safe_message=None)
        a = JudgeAction.retry_nudge_from_verdict(v)
        # When safe_message is missing, the template's correction line
        # falls back to the reason so we still emit valid two-line guidance.
        assert "PHI present" in a.guidance  # type: ignore[operator]
        lines = a.guidance.splitlines()  # type: ignore[union-attr]
        assert lines[0] == "Cannot proceed as requested: PHI present"
        assert lines[1] == "Suggested correction: PHI present"

    def test_uses_safe_message_when_reason_missing(self):
        # No reason → we can't fill the two-line template; emit the
        # safe_message as plain guidance.
        v = self._verdict(reason=None, safe_message="Try again without PII.")
        a = JudgeAction.retry_nudge_from_verdict(v)
        assert a.guidance == "Try again without PII."

    def test_uses_static_fallback_when_both_missing(self):
        v = self._verdict(reason=None, safe_message=None)
        a = JudgeAction.retry_nudge_from_verdict(v)
        assert a.guidance == "Please reconsider this tool call."

    def test_accepts_custom_template(self):
        v = self._verdict(reason="bad input", safe_message="fix it")
        a = JudgeAction.retry_nudge_from_verdict(
            v, template="ERR={reason} :: HINT={safe_message_or_reason}"
        )
        assert a.guidance == "ERR=bad input :: HINT=fix it"


# ---------------------------------------------------------------------------
# JudgePolicy — dispatch table from verdict to action
# ---------------------------------------------------------------------------


class TestJudgePolicyDispatch:
    def test_default_policy_allow(self):
        p = JudgePolicy()
        ctx = JudgeContext(phase="tool_pre", tool_name="search")
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
        )
        action = p.decide(ctx, v)
        assert action.kind == "allow"

    def test_default_policy_block_returns_tool_error(self):
        p = JudgePolicy()
        ctx = JudgeContext(phase="tool_pre", tool_name="search")
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
            reason="bad",
            safe_message="Blocked.",
        )
        action = p.decide(ctx, v)
        assert action.kind == "tool_error"
        assert "Blocked" in (action.message or "")

    def test_default_policy_review_allows(self):
        # By default review is treated as a soft allow with metadata.
        p = JudgePolicy()
        ctx = JudgeContext(phase="tool_pre", tool_name="search")
        v = JudgeVerdict(
            decision="review",
            status="ok",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
        )
        action = p.decide(ctx, v)
        assert action.kind == "allow"
        assert action.metadata.get("tenet_review") is True

    def test_custom_on_block_handler(self):
        called = {}

        def on_block(ctx, verdict):
            called["ctx"] = ctx
            called["verdict"] = verdict
            return JudgeAction.tool_error(verdict.safe_message or "blocked")

        p = JudgePolicy(on_block=on_block)
        ctx = JudgeContext(phase="tool_pre", tool_name="x")
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
            safe_message="HALT",
        )
        action = p.decide(ctx, v)
        assert action.kind == "tool_error"
        assert action.message == "HALT"
        assert called["ctx"] is ctx
        assert called["verdict"] is v

    def test_custom_on_review_can_block(self):
        # The application can elect to treat review as a hard block.
        p = JudgePolicy(on_review=lambda ctx, v: JudgeAction.block(message="reviewed"))
        ctx = JudgeContext(phase="tool_pre", tool_name="x")
        v = JudgeVerdict(
            decision="review",
            status="ok",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
        )
        action = p.decide(ctx, v)
        assert action.kind == "block"

    def test_default_on_unavailable_raises(self):
        # Default policy is fail-closed: re-raise the error.
        p = JudgePolicy()
        ctx = JudgeContext(phase="tool_pre", tool_name="x")
        err = RuntimeError("auth0 down")
        action = p.on_unavailable_action(ctx, err)
        assert action.kind == "raise_error"
        assert action.error is err

    def test_custom_on_unavailable_can_fail_open(self):
        p = JudgePolicy(on_unavailable=lambda ctx, err: JudgeAction.allow())
        ctx = JudgeContext(phase="tool_pre", tool_name="x")
        action = p.on_unavailable_action(ctx, RuntimeError("transient"))
        assert action.kind == "allow"

    def test_default_on_timeout_raises(self):
        p = JudgePolicy()
        ctx = JudgeContext(phase="tool_post", tool_name="x")
        err = TimeoutError("slow")
        action = p.on_timeout_action(ctx, err)
        assert action.kind == "raise_error"
        assert action.error is err

    def test_per_phase_overrides(self):
        # Stricter blocking on tool_post (output leaks), softer on tool_pre.
        per_phase = {
            "tool_pre": JudgePolicy(on_block=lambda c, v: JudgeAction.allow()),
            "tool_post": JudgePolicy(on_block=lambda c, v: JudgeAction.tool_error("post block")),
        }
        p = JudgePolicy(per_phase=per_phase)

        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
        )
        pre = p.decide(JudgeContext(phase="tool_pre", tool_name="x"), v)
        post = p.decide(JudgeContext(phase="tool_post", tool_name="x"), v)
        assert pre.kind == "allow"
        assert post.kind == "tool_error"

    def test_per_tool_overrides(self):
        per_tool = {
            "send_email": JudgePolicy(on_block=lambda c, v: JudgeAction.tool_error("hard block")),
            "search": JudgePolicy(on_block=lambda c, v: JudgeAction.allow()),
        }
        p = JudgePolicy(per_tool=per_tool)

        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
        )
        email = p.decide(JudgeContext(phase="tool_pre", tool_name="send_email"), v)
        search = p.decide(JudgeContext(phase="tool_pre", tool_name="search"), v)
        assert email.kind == "tool_error"
        assert search.kind == "allow"

    def test_on_unresolved_default_returns_retry_nudge_from_verdict(self):
        p = JudgePolicy()
        ctx = JudgeContext(phase="tool_post", tool_name="search")
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
            reason="No matching records",
            safe_message="Try a broader query.",
        )
        action = p.decide(ctx, v, resolution_status="unresolved")
        assert action.kind == "retry_nudge"
        assert "No matching records" in (action.guidance or "")
        assert "Try a broader query." in (action.guidance or "")

    def test_on_unresolved_custom_callback_invoked(self):
        called = {}

        def on_unresolved(ctx, verdict):
            called["hit"] = True
            return JudgeAction.retry_nudge("custom unresolved guidance")

        p = JudgePolicy(on_unresolved=on_unresolved)
        ctx = JudgeContext(phase="tool_post", tool_name="search")
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="hr-1",
            judge_version="x",
            latency_ms=1,
        )
        action = p.decide(ctx, v, resolution_status="unresolved")
        assert called.get("hit") is True
        assert action.kind == "retry_nudge"
        assert action.guidance == "custom unresolved guidance"

    def test_unresolved_overrides_normal_dispatch(self):
        # Even if the verdict says block, an unresolved resolution_status
        # routes through on_unresolved — it's a separate signal.
        p = JudgePolicy(
            on_unresolved=lambda ctx, v: JudgeAction.retry_nudge("unresolved wins"),
            on_block=lambda ctx, v: JudgeAction.tool_error("blocked"),
        )
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
        )
        action = p.decide(
            JudgeContext(phase="tool_post", tool_name="x"), v, resolution_status="unresolved"
        )
        assert action.kind == "retry_nudge"
        assert action.guidance == "unresolved wins"

    def test_resolution_status_resolved_uses_normal_dispatch(self):
        p = JudgePolicy()
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
            safe_message="Blocked.",
        )
        action = p.decide(
            JudgeContext(phase="tool_post", tool_name="x"), v, resolution_status="resolved"
        )
        assert action.kind == "tool_error"

    def test_resolution_status_none_preserves_existing_behavior(self):
        # No resolution_status kwarg → identical to current behavior.
        p = JudgePolicy()
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
            safe_message="Blocked.",
        )
        action = p.decide(JudgeContext(phase="tool_post", tool_name="x"), v)
        assert action.kind == "tool_error"

    def test_per_tool_on_unresolved_overrides_root(self):
        per_tool = {
            "search": JudgePolicy(
                on_unresolved=lambda c, v: JudgeAction.retry_nudge("per-tool unresolved"),
            ),
        }
        p = JudgePolicy(per_tool=per_tool)
        v = JudgeVerdict(
            decision="allow",
            status="ok",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
        )
        action = p.decide(
            JudgeContext(phase="tool_post", tool_name="search"),
            v,
            resolution_status="unresolved",
        )
        assert action.kind == "retry_nudge"
        assert action.guidance == "per-tool unresolved"

    def test_per_tool_takes_precedence_over_per_phase(self):
        per_phase = {
            "tool_pre": JudgePolicy(on_block=lambda c, v: JudgeAction.allow()),
        }
        per_tool = {
            "send_email": JudgePolicy(on_block=lambda c, v: JudgeAction.tool_error("tool wins")),
        }
        p = JudgePolicy(per_phase=per_phase, per_tool=per_tool)
        v = JudgeVerdict(
            decision="block",
            status="triggered",
            judge_id="j",
            judge_version="v",
            latency_ms=1,
        )
        action = p.decide(JudgeContext(phase="tool_pre", tool_name="send_email"), v)
        assert action.kind == "tool_error"
        assert action.message == "tool wins"
