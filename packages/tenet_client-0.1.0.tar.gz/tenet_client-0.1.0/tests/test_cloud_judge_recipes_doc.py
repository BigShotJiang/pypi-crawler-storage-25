"""Smoke test for ``docs/cloud_judge_recipes.md``.

Extracts every ```python code block from the recipes doc and compiles
each one. Catches syntax rot when LangChain imports change, when the
SDK contract drifts, or when copy-paste edits introduce broken code.

Does NOT execute the snippets — running them would require
construction of real LangChain agents + real cloud credentials. The
``test_cloud_client.py`` suite is the authoritative test for client
behavior; this test only guards the doc against syntax decay.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

DOC_PATH = Path(__file__).resolve().parent.parent / "docs" / "cloud_judge_recipes.md"


def _extract_python_blocks(markdown: str) -> list[tuple[int, str]]:
    """Return list of (1-based line number, code) tuples for every
    ```python fence in the markdown. Line number points at the first
    line of code inside the fence so syntax errors are easy to locate.
    """
    blocks: list[tuple[int, str]] = []
    pattern = re.compile(r"^```python\s*$", re.MULTILINE)
    end_pattern = re.compile(r"^```\s*$", re.MULTILINE)

    for fence_open in pattern.finditer(markdown):
        start_idx = markdown.find("\n", fence_open.end()) + 1
        end_match = end_pattern.search(markdown, start_idx)
        if end_match is None:
            raise AssertionError(f"Unterminated ```python fence at offset {fence_open.start()}")
        code = markdown[start_idx : end_match.start()]
        # Convert byte offset -> line number (1-based) for nicer test output.
        line_number = markdown.count("\n", 0, start_idx) + 1
        blocks.append((line_number, code))
    return blocks


def _doc_blocks() -> list[tuple[int, str]]:
    if not DOC_PATH.exists():
        pytest.fail(f"recipes doc missing: {DOC_PATH}")
    return _extract_python_blocks(DOC_PATH.read_text())


class TestRecipeBlocksParse:
    """Each ```python block in the recipes doc must be syntactically valid."""

    def test_doc_has_recipe_blocks(self) -> None:
        blocks = _doc_blocks()
        # Recipes 1-4 + several utility snippets — guard that we found a
        # reasonable count so a future doc edit that accidentally drops
        # all the fenced blocks fails loudly.
        assert len(blocks) >= 4, (
            f"expected >= 4 ```python blocks in {DOC_PATH.name}, found {len(blocks)}"
        )

    def test_every_block_compiles(self) -> None:
        blocks = _doc_blocks()
        failures: list[str] = []
        for line_no, code in blocks:
            location = f"{DOC_PATH.name}:{line_no}"
            try:
                compile(code, location, "exec")
            except SyntaxError as e:
                failures.append(f"{location}: {e}")
        if failures:
            joined = "\n  ".join(failures)
            pytest.fail(
                f"recipe snippets failed to compile:\n  {joined}\n\n"
                "Either fix the snippet in the doc, or update the doc to "
                "match a current LangChain / tenet-langchain API."
            )


class TestRecipeBlocksDoNotImportMiddleware:
    """Recipes are explicitly self-contained: none of them should import
    the local-server ``TenetMiddleware`` (or any middleware class shipped
    by this package). The plan calls these out as docs-only patterns so
    integrators copy + adapt rather than depend on a shipped abstraction.
    """

    def test_no_recipe_imports_tenet_middleware_class(self) -> None:
        text = DOC_PATH.read_text() if DOC_PATH.exists() else ""
        # Capture any import line referencing TenetMiddleware. The cloud
        # client's exception/types/client are fair game — those ARE the
        # SDK surface — but a pre-baked middleware class is not.
        for forbidden in ("TenetMiddleware",):
            for line_no, line in enumerate(text.splitlines(), start=1):
                if forbidden in line and "import" in line:
                    pytest.fail(
                        f"{DOC_PATH.name}:{line_no} imports {forbidden!r} — "
                        "recipes must NOT import a Tenet middleware class. "
                        "Use TenetCloudJudgeClient directly."
                    )
