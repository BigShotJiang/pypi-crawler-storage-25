"""Tests for tenet_client Pydantic models."""

from tenet_client.models import EvaluateRequest, EvaluateResponse, HealthResponse, Violation


class TestEvaluateRequest:
    def test_minimal(self):
        req = EvaluateRequest(tool_name="search")
        assert req.tool_name == "search"
        assert req.tool_input == {}
        assert req.phase == "pre"

    def test_full(self):
        req = EvaluateRequest(
            tool_name="search", tool_input={"query": "test"}, tool_output="results",
            phase="post", session_id="s1", metadata={"run_id": "123"}, tenet_ids=["hipaa"],
        )
        assert req.phase == "post"

    def test_serialization(self):
        req = EvaluateRequest(tool_name="calc", tool_input="2+2", metadata={"tag": "math"})
        d = req.model_dump()
        assert d["tool_name"] == "calc"


class TestViolation:
    def test_construction(self):
        v = Violation(rule_id="r1", rule_name="Test", tenet_id="t1", severity="warning", action="warn", message="test msg")
        assert v.details == {}

    def test_with_details(self):
        v = Violation(rule_id="r1", rule_name="Test", tenet_id="t1", severity="error", action="block", message="blocked", details={"tool": "shell"})
        assert v.details["tool"] == "shell"


class TestEvaluateResponse:
    def test_no_violations(self):
        resp = EvaluateResponse(violations=[], has_violations=False, should_block=False, processing_time_ms=1.0)
        assert resp.pii_entities == []

    def test_with_violations(self):
        resp = EvaluateResponse(
            violations=[Violation(rule_id="r1", rule_name="T", tenet_id="t1", severity="critical", action="block", message="blocked")],
            has_violations=True, should_block=True, processing_time_ms=5.0,
        )
        assert len(resp.violations) == 1


class TestHealthResponse:
    def test_healthy(self):
        h = HealthResponse(status="ok", model_loaded=True, uptime_seconds=100.0)
        assert h.error is None
