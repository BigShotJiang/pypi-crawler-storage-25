"""Tests for ``TenetCloudJudgeClient.evaluate_phase`` — high-level helper.

For developers building fully custom agents who want a one-call
"evaluate this phase + run the policy + return an action" path without
LangChain. Mirrors what the LangChain middleware does internally so
callers don't have to.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from tenet_client import (
    JudgeAction,
    JudgePolicy,
    JudgeUnavailableError,
    JudgeVerdict,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse


def _allow():
    return CloudJudgeResponse(
        decision="allow",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
    )


def _block(reason: str | None = "policy"):
    return CloudJudgeResponse(
        decision="block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=11,
        reason=reason,
    )


class TestEvaluatePhaseSync:
    def test_allow_returns_allow_action(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.return_value = _allow()

        verdict, action = TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=JudgePolicy(),
            phase="tool_pre",
            tool_name="search",
            tool_input={"q": "x"},
        )
        assert isinstance(verdict, JudgeVerdict)
        assert verdict.decision == "allow"
        assert action.kind == "allow"
        client.evaluate.assert_called_once()

    def test_block_returns_tool_error_action(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.return_value = _block("PHI")

        verdict, action = TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=JudgePolicy(),
            phase="tool_pre",
            tool_name="get_chart",
            tool_input={"id": "MRN1"},
        )
        assert verdict.decision == "block"
        assert action.kind == "tool_error"
        assert "PHI" in (action.message or "")

    def test_unavailable_uses_policy_handler(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.side_effect = JudgeUnavailableError("auth0 down")

        # Default = fail-closed → raise_error action.
        _verdict, action = TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=JudgePolicy(),
            phase="tool_pre",
            tool_name="x",
            tool_input={},
        )
        assert action.kind == "raise_error"
        assert isinstance(action.error, JudgeUnavailableError)

    def test_custom_policy_dispatch(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.return_value = _block()

        policy = JudgePolicy(
            on_block=lambda c, v: JudgeAction.override_output("safe answer")
        )
        _verdict, action = TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=policy,
            phase="tool_post",
            tool_name="lookup",
            tool_input={},
            tool_output="leak",
        )
        assert action.kind == "override_output"
        assert action.payload == "safe answer"


class TestEvaluatePhaseResolutionStatus:
    """RFC-008 §4.4.5 wire-contract extension. evaluate_phase accepts
    resolution_status and routes through JudgePolicy.on_unresolved when
    the value is "unresolved" — separate from the on_block/on_review
    branches.
    """

    def test_resolution_status_unresolved_routes_through_on_unresolved(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.return_value = _allow()

        called = {}

        def on_unresolved(_ctx, verdict):
            called["hit"] = True
            return JudgeAction.retry_nudge("try harder")

        _verdict, action = TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=JudgePolicy(on_unresolved=on_unresolved),
            phase="tool_post",
            tool_name="search",
            tool_input={"q": "x"},
            tool_output={"results": []},
            resolution_status="unresolved",
        )
        assert called.get("hit") is True
        assert action.kind == "retry_nudge"
        assert action.guidance == "try harder"

    def test_resolution_status_none_preserves_existing_behavior(self):
        # Default policy + block verdict should still emit tool_error;
        # this is the byte-for-byte backward-compat guarantee.
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.return_value = _block("PHI")

        _verdict, action = TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=JudgePolicy(),
            phase="tool_pre",
            tool_name="x",
            tool_input={},
            # resolution_status omitted
        )
        assert action.kind == "tool_error"

    def test_resolution_status_threaded_to_evaluate(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.return_value = _allow()

        TenetCloudJudgeClient.evaluate_phase(
            client,
            policy=JudgePolicy(),
            phase="tool_post",
            tool_name="search",
            tool_input={"q": "x"},
            tool_output={"results": []},
            resolution_status="unresolved",
        )
        # The high-level helper must forward resolution_status to the
        # low-level evaluate(), which threads it into the request envelope.
        kwargs = client.evaluate.call_args.kwargs
        assert kwargs.get("resolution_status") == "unresolved"

    @pytest.mark.asyncio
    async def test_resolution_status_unresolved_async(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate_async = AsyncMock(return_value=_allow())

        _verdict, action = await TenetCloudJudgeClient.evaluate_phase_async(
            client,
            policy=JudgePolicy(),
            phase="tool_post",
            tool_name="search",
            tool_input={"q": "x"},
            tool_output={"results": []},
            resolution_status="unresolved",
        )
        # Default on_unresolved returns retry_nudge_from_verdict.
        assert action.kind == "retry_nudge"

    @pytest.mark.asyncio
    async def test_resolution_status_threaded_to_evaluate_async(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate_async = AsyncMock(return_value=_allow())

        await TenetCloudJudgeClient.evaluate_phase_async(
            client,
            policy=JudgePolicy(),
            phase="tool_post",
            tool_name="x",
            tool_input={},
            resolution_status="error",
        )
        kwargs = client.evaluate_async.call_args.kwargs
        assert kwargs.get("resolution_status") == "error"


class TestEvaluatePhaseAsync:
    @pytest.mark.asyncio
    async def test_allow_async(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate_async = AsyncMock(return_value=_allow())

        verdict, action = await TenetCloudJudgeClient.evaluate_phase_async(
            client,
            policy=JudgePolicy(),
            phase="tool_pre",
            tool_name="x",
            tool_input={},
        )
        assert verdict.decision == "allow"
        assert action.kind == "allow"

    @pytest.mark.asyncio
    async def test_block_async(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate_async = AsyncMock(return_value=_block("nope"))

        _verdict, action = await TenetCloudJudgeClient.evaluate_phase_async(
            client,
            policy=JudgePolicy(),
            phase="tool_pre",
            tool_name="x",
            tool_input={},
        )
        assert action.kind == "tool_error"


class TestJudgedPolicyArg:
    """The ``@judged`` decorator accepts a ``policy`` argument so callers
    can express override-output, override-input, or fail-open behavior
    without subclassing. ``policy=None`` keeps today's hard-coded
    behavior (raise ``JudgeBlocked`` on block, raise on unavailable).
    """

    def test_policy_override_output_used_as_return(self):
        from tenet_client import judged

        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.side_effect = [_allow(), _block("PHI")]

        policy = JudgePolicy(
            on_block=lambda c, v: JudgeAction.override_output("safe")
        )

        @judged(client, policy=policy)
        def do_thing() -> str:
            return "raw"

        result = do_thing()
        assert result == "safe"

    def test_policy_allow_on_block_lets_value_through(self):
        from tenet_client import judged

        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.side_effect = [_allow(), _block("PHI")]

        policy = JudgePolicy(on_block=lambda c, v: JudgeAction.allow())

        @judged(client, policy=policy)
        def do_thing() -> str:
            return "raw"

        # Allow on post lets the original return value through.
        assert do_thing() == "raw"

    def test_policy_overrides_fail_open_kwarg_when_both_provided(self):
        # Policy is explicit; fail_open is the legacy knob. Policy wins.
        from tenet_client import judged

        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.side_effect = JudgeUnavailableError("transient")

        policy = JudgePolicy(on_unavailable=lambda c, e: JudgeAction.allow())

        @judged(client, policy=policy, fail_open=False)
        def do_thing() -> str:
            return "ran"

        # Policy says allow → function executes → returns "ran".
        assert do_thing() == "ran"
