"""Tests for TenetCloudJudgeClient — Auth0 token exchange + cloud judge call.

Coverage (Phase 4 spec):
- Token mint + cache (exp - 60s window)
- Token refresh after expiry
- 401 from cloud -> refresh + retry once -> bubble on second 401
- 5xx, timeout, malformed response, Auth0 5xx, Auth0 4xx -> JudgeUnavailableError
- Per-call timeout override
- Trace metadata round-trip
- Request body shape

Uses ``httpx.MockTransport`` to keep style consistent with the existing
``test_client.py`` (no respx dependency).
"""

from __future__ import annotations

from typing import Callable

import httpx
import pytest

from tenet_client.cloud_client import TenetCloudJudgeClient
from tenet_client.cloud_models import CloudJudgeResponse, JudgeUnavailableError


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

CLOUD_URL = "https://api.test.tenetlabs.com"
AUTH0_URL = "https://auth.test.tenetlabs.com/"
AUDIENCE = "https://sdk.test.tenetlabs.com"


def _ok_token_response(token: str = "tok-fresh", expires_in: int = 86400) -> dict:
    return {"access_token": token, "token_type": "Bearer", "expires_in": expires_in}


def _ok_cloud_response(
    *,
    verdict: str = "pass",
    severity: str = "info",
    config_version: str = "hr-1.0.0",
    reason: str | None = None,
    risk_labels: list[str] | None = None,
    rule_ids: list[str] | None = None,
    rule_chain: list[dict] | None = None,
    path: str = "head_fast_pass",
) -> dict:
    """Build a synthetic ``/eeo/decide`` response body.

    ``decision`` (legacy SDK field) is derived on the client side from
    ``verdict`` so we don't echo it here — the new server doesn't either.
    """
    decision_metadata: dict = {"config_version": config_version}
    if reason is not None:
        decision_metadata["reason"] = reason
    return {
        "verdict": verdict,
        "severity": severity,
        "risk_labels": risk_labels or [],
        "rule_ids": rule_ids or [],
        "path": path,
        "latency_ms": 12,
        "source_trust_triggers": [],
        "rule_chain": rule_chain or [],
        "evidence_span": None,
        "decision_metadata": decision_metadata,
    }


class _RouteRecorder:
    """Record every Auth0 + cloud request and dispatch responses by route."""

    def __init__(
        self,
        *,
        auth0_handler: Callable[[httpx.Request], httpx.Response] | None = None,
        cloud_handler: Callable[[httpx.Request], httpx.Response] | None = None,
    ) -> None:
        self.auth0_calls: list[httpx.Request] = []
        self.cloud_calls: list[httpx.Request] = []
        self._auth0 = auth0_handler or (lambda _: httpx.Response(200, json=_ok_token_response()))
        self._cloud = cloud_handler or (lambda _: httpx.Response(200, json=_ok_cloud_response()))

    def __call__(self, req: httpx.Request) -> httpx.Response:
        if req.url.path.endswith("/oauth/token"):
            self.auth0_calls.append(req)
            return self._auth0(req)
        self.cloud_calls.append(req)
        return self._cloud(req)


def _build_client(
    recorder: _RouteRecorder,
    *,
    timeout: float = 3.0,
    now: Callable[[], float] | None = None,
) -> TenetCloudJudgeClient:
    """Build a client whose underlying httpx clients use a MockTransport."""
    transport = httpx.MockTransport(recorder)
    async_transport = httpx.MockTransport(recorder)
    client = TenetCloudJudgeClient(
        client_id="test-client-id",
        client_secret="test-client-secret",
        timeout=timeout,
        _cloud_url=CLOUD_URL,
        _audience=AUDIENCE,
        _auth0_issuer_url=AUTH0_URL,
        _sync_transport=transport,
        _async_transport=async_transport,
        _now=now,
    )
    return client


# --------------------------------------------------------------------------
# Warmup
# --------------------------------------------------------------------------


class TestWarmup:
    def test_warmup_mints_token_when_cache_empty(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.warmup()
        assert len(rec.auth0_calls) == 1
        assert len(rec.cloud_calls) == 0

    def test_warmup_is_idempotent_within_cache_window(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.warmup()
        client.warmup()
        client.warmup()
        assert len(rec.auth0_calls) == 1, "warmup must not re-mint when token is cached"

    def test_evaluate_after_warmup_skips_token_mint(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.warmup()
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        assert len(rec.auth0_calls) == 1, "evaluate after warmup should reuse the cached token"
        assert len(rec.cloud_calls) == 1

    def test_warmup_propagates_auth0_failure(self):
        rec = _RouteRecorder(
            auth0_handler=lambda _: httpx.Response(401, json={"error": "bad creds"}),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.warmup()

    @pytest.mark.asyncio
    async def test_warmup_async_mints_token(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        await client.warmup_async()
        assert len(rec.auth0_calls) == 1
        await client.aclose()

    @pytest.mark.asyncio
    async def test_warmup_async_then_evaluate_async_skips_mint(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        await client.warmup_async()
        await client.evaluate_async(phase="tool_pre", tool_name="x", tool_input={})
        assert len(rec.auth0_calls) == 1
        await client.aclose()

    @pytest.mark.asyncio
    async def test_warmup_async_idempotent(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        await client.warmup_async()
        await client.warmup_async()
        assert len(rec.auth0_calls) == 1
        await client.aclose()


# --------------------------------------------------------------------------
# Happy path — token mint + cloud call
# --------------------------------------------------------------------------


class TestEvaluateSync:
    def test_first_call_mints_token_and_returns_verdict(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        resp = client.evaluate(
            phase="tool_pre",
            tool_name="search_resumes",
            tool_input={"query": "Python"},
        )
        assert isinstance(resp, CloudJudgeResponse)
        assert resp.decision == "allow"
        assert resp.judge_id == "hr-1"
        assert len(rec.auth0_calls) == 1
        assert len(rec.cloud_calls) == 1

    def test_token_cached_across_evaluations_within_window(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        for _ in range(3):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        assert len(rec.auth0_calls) == 1, (
            f"expected one Auth0 mint reused across 3 calls, got {len(rec.auth0_calls)}"
        )
        assert len(rec.cloud_calls) == 3

    def test_token_refetched_after_exp_minus_60s(self):
        clock = [1000.0]
        rec = _RouteRecorder(
            auth0_handler=lambda _: httpx.Response(
                200, json=_ok_token_response(token="tok-A", expires_in=120)
            ),
        )
        client = _build_client(rec, now=lambda: clock[0])
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        # exp = 1000 + 120 = 1120; cache window ends at 1060 (exp - 60)
        clock[0] = 1059.0
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        assert len(rec.auth0_calls) == 1
        clock[0] = 1061.0
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        assert len(rec.auth0_calls) == 2

    def test_authorization_bearer_sent_with_minted_token(self):
        rec = _RouteRecorder(
            auth0_handler=lambda _: httpx.Response(
                200, json=_ok_token_response(token="my-special-token")
            ),
        )
        client = _build_client(rec)
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        cloud_req = rec.cloud_calls[0]
        assert cloud_req.headers.get("authorization") == "Bearer my-special-token"

    def test_request_body_shape(self):
        """The SDK translates the legacy public input shape into the new
        ``/eeo/decide`` envelope ({surface, messages, context, phase,
        resolution_status}) on the wire. Integrators keep the legacy
        kwargs at the call site; the wire body uses the new shape.

        ``surface`` is a configuration knob on the client (defaults to
        ``resume_triage``) — NOT derived from ``tool_name``. ``tool_name``
        identifies the tool the agent is calling; ``surface`` selects the
        policy bundle on the engine. They're orthogonal concerns.
        """
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(
            phase="tool_post",
            tool_name="rank_candidates",
            tool_input={"query": "5+ years of Python"},
            tool_output={"results": [{"id": "1"}]},
            session_id="sess-1",
            trace_id="trace-1",
            parent_span_id="span-1",
            metadata={"customer_env": "staging"},
        )
        body = rec.cloud_calls[0].read()
        import json

        sent = json.loads(body)
        # New wire shape.
        assert sent["surface"] == "resume_triage", (
            "surface defaults to the client-configured policy bundle, not tool_name"
        )
        assert sent["phase"] == "tool_post"
        assert isinstance(sent["messages"], list) and len(sent["messages"]) == 1
        assert sent["messages"][0]["role"] == "user"
        # Context preserves the tool_input keys + the EEO pipeline's
        # required `recruiter_prompt` / `candidate_content` keys.
        ctx = sent["context"]
        assert ctx["query"] == "5+ years of Python"
        assert ctx["results"] == [{"id": "1"}]
        assert "recruiter_prompt" in ctx
        assert "candidate_content" in ctx
        # tool_name surfaces inside context (engine visibility) but is not
        # the surface field itself.
        assert ctx.get("tool_name") == "rank_candidates"
        # Legacy fields no longer appear on the wire — the server doesn't
        # consume them. They live only in the SDK's input model.
        assert "judge_id" not in sent
        assert "tool_input" not in sent
        assert "tool_output" not in sent
        assert "session_id" not in sent
        assert "trace_id" not in sent
        assert "parent_span_id" not in sent
        assert "metadata" not in sent

    def test_resolution_status_in_request_body_when_set(self):
        # RFC-008 §4.4.5: evaluate() accepts resolution_status and threads
        # it into the request envelope so the server can branch on it via
        # rails config (Cowork-side branching deferred; the field is
        # echoed through RailContext in this wave).
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(
            phase="tool_post",
            tool_name="search",
            tool_input={"q": "x"},
            tool_output={"results": []},
            resolution_status="unresolved",
        )
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        assert sent["resolution_status"] == "unresolved"

    def test_resolution_status_omitted_when_none_preserves_envelope(self):
        # None must preserve the prior wire envelope so existing customer
        # integrations keep working.
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        # Either the key is absent or it's serialized as null — both shapes
        # are server-tolerant. What must NOT change: the value when the
        # caller did not pass the kwarg.
        assert sent.get("resolution_status") is None

    def test_surface_defaults_to_resume_triage(self):
        """No constructor or per-call override → resume_triage on the wire."""
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(phase="tool_pre", tool_name="search", tool_input={})
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        assert sent["surface"] == "resume_triage"

    def test_surface_configurable_on_client(self):
        """Client-level surface routes every call to the chosen policy bundle."""
        rec = _RouteRecorder()
        transport = httpx.MockTransport(rec)
        client = TenetCloudJudgeClient(
            client_id="cid",
            client_secret="csec",
            surface="job_ad_drafting",
            _cloud_url=CLOUD_URL,
            _audience=AUDIENCE,
            _auth0_issuer_url=AUTH0_URL,
            _sync_transport=transport,
            _async_transport=httpx.MockTransport(rec),
        )
        client.evaluate(phase="tool_pre", tool_name="search", tool_input={})
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        assert sent["surface"] == "job_ad_drafting"

    def test_surface_per_call_overrides_client_default(self):
        """Per-call surface overrides the constructor default for one call."""
        rec = _RouteRecorder()
        transport = httpx.MockTransport(rec)
        client = TenetCloudJudgeClient(
            client_id="cid",
            client_secret="csec",
            surface="resume_triage",
            _cloud_url=CLOUD_URL,
            _audience=AUDIENCE,
            _auth0_issuer_url=AUTH0_URL,
            _sync_transport=transport,
            _async_transport=httpx.MockTransport(rec),
        )
        client.evaluate(
            phase="tool_pre", tool_name="search", tool_input={}, surface="job_ad_drafting"
        )
        client.evaluate(phase="tool_pre", tool_name="search", tool_input={})
        import json

        sent_override = json.loads(rec.cloud_calls[0].read())
        sent_default = json.loads(rec.cloud_calls[1].read())
        assert sent_override["surface"] == "job_ad_drafting"
        assert sent_default["surface"] == "resume_triage"

    @pytest.mark.asyncio
    async def test_surface_per_call_override_async(self):
        rec = _RouteRecorder()
        transport = httpx.MockTransport(rec)
        client = TenetCloudJudgeClient(
            client_id="cid",
            client_secret="csec",
            surface="resume_triage",
            _cloud_url=CLOUD_URL,
            _audience=AUDIENCE,
            _auth0_issuer_url=AUTH0_URL,
            _sync_transport=transport,
            _async_transport=httpx.MockTransport(rec),
        )
        await client.evaluate_async(
            phase="tool_pre", tool_name="x", tool_input={}, surface="custom_bundle"
        )
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        assert sent["surface"] == "custom_bundle"
        await client.aclose()

    def test_surface_from_env_var(self):
        """``TENET_SURFACE`` env var seeds the client default via ``from_env``."""
        import os

        prev = os.environ.get("TENET_SURFACE")
        prev_id = os.environ.get("TENET_CLIENT_ID")
        prev_sec = os.environ.get("TENET_CLIENT_SECRET")
        try:
            os.environ["TENET_CLIENT_ID"] = "cid"
            os.environ["TENET_CLIENT_SECRET"] = "csec"
            os.environ["TENET_SURFACE"] = "healthcare_intake"
            client = TenetCloudJudgeClient.from_env()
            assert client._surface == "healthcare_intake"
        finally:
            if prev is None:
                os.environ.pop("TENET_SURFACE", None)
            else:
                os.environ["TENET_SURFACE"] = prev
            if prev_id is None:
                os.environ.pop("TENET_CLIENT_ID", None)
            if prev_sec is None:
                os.environ.pop("TENET_CLIENT_SECRET", None)

    def test_tool_name_omitted_from_context_when_empty(self):
        """``tool_name=""`` (the user_prompt / agent_input path) should not
        inject an empty ``tool_name`` key into ``context``."""
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(phase="agent_input", tool_name="", tool_input="please help")
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        assert "tool_name" not in sent["context"]

    def test_auth0_token_request_carries_grant_and_audience(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        auth_req = rec.auth0_calls[0]
        # Auth0 token endpoint accepts either application/json or
        # application/x-www-form-urlencoded; the SDK uses JSON for simplicity.
        import json

        sent = json.loads(auth_req.read())
        assert sent["grant_type"] == "client_credentials"
        assert sent["client_id"] == "test-client-id"
        assert sent["client_secret"] == "test-client-secret"
        assert sent["audience"] == AUDIENCE


class TestEvaluateAsync:
    @pytest.mark.asyncio
    async def test_first_call_mints_and_returns(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        resp = await client.evaluate_async(phase="tool_pre", tool_name="x", tool_input={"q": "y"})
        assert resp.decision == "allow"
        assert len(rec.auth0_calls) == 1
        assert len(rec.cloud_calls) == 1
        await client.aclose()

    @pytest.mark.asyncio
    async def test_resolution_status_threaded_in_async_path(self):
        rec = _RouteRecorder()
        client = _build_client(rec)
        await client.evaluate_async(
            phase="tool_post",
            tool_name="search",
            tool_input={"q": "x"},
            tool_output={"results": []},
            resolution_status="unresolved",
        )
        import json

        sent = json.loads(rec.cloud_calls[0].read())
        assert sent["resolution_status"] == "unresolved"
        await client.aclose()

    @pytest.mark.asyncio
    async def test_token_cache_shared_with_sync_path(self):
        """Sync and async use the same in-memory token cache."""
        rec = _RouteRecorder()
        client = _build_client(rec)
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        await client.evaluate_async(phase="tool_pre", tool_name="x", tool_input={})
        assert len(rec.auth0_calls) == 1
        await client.aclose()


# --------------------------------------------------------------------------
# 401 from cloud -> refresh + retry once
# --------------------------------------------------------------------------


class TestRefreshOn401:
    def test_401_then_200_after_refresh(self):
        seq = ["401", "200"]
        rec = _RouteRecorder(
            cloud_handler=lambda _: (
                httpx.Response(401, json={"detail": "expired"})
                if seq.pop(0) == "401"
                else httpx.Response(200, json=_ok_cloud_response())
            ),
        )
        client = _build_client(rec)
        resp = client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        assert resp.decision == "allow"
        # Two cloud calls: original 401 + retry. Two Auth0 calls: initial + refresh.
        assert len(rec.auth0_calls) == 2
        assert len(rec.cloud_calls) == 2

    def test_401_after_refresh_bubbles_as_unavailable(self):
        rec = _RouteRecorder(
            cloud_handler=lambda _: httpx.Response(401, json={"detail": "still bad"}),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        # One refresh attempt -> two Auth0 calls; two cloud calls (both 401).
        assert len(rec.auth0_calls) == 2
        assert len(rec.cloud_calls) == 2


# --------------------------------------------------------------------------
# Failure mapping
# --------------------------------------------------------------------------


class TestFailureMapping:
    def test_5xx_from_cloud_raises_unavailable(self):
        rec = _RouteRecorder(
            cloud_handler=lambda _: httpx.Response(503, json={"detail": "down"}),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})

    def test_timeout_raises_unavailable(self):
        def boom(_req: httpx.Request) -> httpx.Response:
            raise httpx.TimeoutException("upstream slow")

        rec = _RouteRecorder(cloud_handler=boom)
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})

    def test_non_json_response_raises_unavailable(self):
        rec = _RouteRecorder(
            cloud_handler=lambda _: httpx.Response(
                200, content=b"not json", headers={"content-type": "text/plain"}
            ),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})

    def test_missing_verdict_raises_unavailable(self):
        # /eeo/decide MUST emit `verdict`; an absent field is server-side
        # malformation, not a routing signal.
        rec = _RouteRecorder(
            cloud_handler=lambda _: httpx.Response(
                200,
                json={"severity": "info", "latency_ms": 5, "rule_chain": []},
            ),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})

    def test_unknown_verdict_value_treated_as_block(self):
        # An unknown but non-empty verdict string must NOT raise — the
        # server may introduce new verdict values (e.g. ``defer_v2``)
        # and the SDK should default to the safer ``block`` decision
        # without breaking. Severity / risk_labels still pass through
        # so the policy callback can route on them.
        rec = _RouteRecorder(
            cloud_handler=lambda _: httpx.Response(
                200,
                json={
                    "verdict": "maybe_new_verdict",
                    "severity": "medium",
                    "risk_labels": ["new-rule"],
                    "rule_ids": ["new-rule"],
                    "path": "head_fast_pass",
                    "latency_ms": 5,
                    "rule_chain": [],
                    "decision_metadata": {"config_version": "v9"},
                },
            ),
        )
        client = _build_client(rec)
        resp = client.evaluate(phase="tool_pre", tool_name="x", tool_input={})
        assert resp.decision == "block"
        assert resp.verdict == "maybe_new_verdict"
        assert resp.severity == "medium"
        assert resp.risk_labels == ["new-rule"]

    def test_auth0_5xx_during_mint_raises_unavailable(self):
        rec = _RouteRecorder(
            auth0_handler=lambda _: httpx.Response(503, json={"error": "down"}),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})

    def test_auth0_4xx_during_mint_raises_unavailable(self):
        rec = _RouteRecorder(
            auth0_handler=lambda _: httpx.Response(
                401, json={"error": "access_denied", "error_description": "bad creds"}
            ),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})

    def test_auth0_returns_no_token_raises_unavailable(self):
        rec = _RouteRecorder(
            auth0_handler=lambda _: httpx.Response(200, json={"token_type": "Bearer"}),
        )
        client = _build_client(rec)
        with pytest.raises(JudgeUnavailableError):
            client.evaluate(phase="tool_pre", tool_name="x", tool_input={})


# --------------------------------------------------------------------------
# Per-call timeout override
# --------------------------------------------------------------------------


class TestPerCallTimeout:
    def test_explicit_timeout_overrides_default(self):
        observed: list[httpx.Timeout] = []

        def cloud(req: httpx.Request) -> httpx.Response:
            observed.append(req.extensions.get("timeout"))  # populated by httpx
            return httpx.Response(200, json=_ok_cloud_response())

        rec = _RouteRecorder(cloud_handler=cloud)
        client = _build_client(rec, timeout=3.0)
        client.evaluate(phase="tool_pre", tool_name="x", tool_input={}, timeout=0.5)
        # extensions['timeout'] is a dict-like with read/write/connect/pool keys.
        observed_timeout = observed[0]
        assert observed_timeout is not None
        # Per-call override should set all timeout components to 0.5.
        assert observed_timeout["read"] == pytest.approx(0.5)


# --------------------------------------------------------------------------
# from_env factory
# --------------------------------------------------------------------------


class TestFromEnv:
    def test_reads_required_fields(self, monkeypatch):
        monkeypatch.delenv("TENET_CLOUD_URL", raising=False)
        monkeypatch.setenv("TENET_CLIENT_ID", "cid")
        monkeypatch.setenv("TENET_CLIENT_SECRET", "csec")
        client = TenetCloudJudgeClient.from_env()
        assert client._client_id == "cid"
        assert client._client_secret == "csec"
        # Defaults applied
        assert client._cloud_url == "https://judge.tenetlabs.com"
        assert client._audience == "https://sdk.tenetlabs.com"
        assert client._auth0_issuer_url == "https://auth.tenetlabs.com/"
        assert client._judge_id == "hr-1"
        assert client._timeout == 3.0

    def test_cloud_url_override(self, monkeypatch):
        monkeypatch.setenv("TENET_CLOUD_URL", "https://cloud.example")
        monkeypatch.setenv("TENET_CLIENT_ID", "cid")
        monkeypatch.setenv("TENET_CLIENT_SECRET", "csec")
        client = TenetCloudJudgeClient.from_env()
        assert client._cloud_url == "https://cloud.example"

    def test_optional_fields_overridable(self, monkeypatch):
        monkeypatch.setenv("TENET_CLIENT_ID", "cid")
        monkeypatch.setenv("TENET_CLIENT_SECRET", "csec")
        monkeypatch.setenv("TENET_AUTH0_AUDIENCE", "https://other.example")
        monkeypatch.setenv("TENET_JUDGE_TIMEOUT_SECONDS", "1.5")
        client = TenetCloudJudgeClient.from_env()
        assert client._audience == "https://other.example"
        assert client._timeout == 1.5

    def test_missing_required_raises_valueerror(self, monkeypatch):
        for k in ("TENET_CLIENT_ID", "TENET_CLIENT_SECRET"):
            monkeypatch.delenv(k, raising=False)
        with pytest.raises(ValueError, match="TENET_CLIENT_ID"):
            TenetCloudJudgeClient.from_env()

    def test_missing_one_required_names_only_that_one(self, monkeypatch):
        monkeypatch.setenv("TENET_CLIENT_ID", "cid")
        monkeypatch.delenv("TENET_CLIENT_SECRET", raising=False)
        with pytest.raises(ValueError, match=r"^missing.*TENET_CLIENT_SECRET$"):
            TenetCloudJudgeClient.from_env()
