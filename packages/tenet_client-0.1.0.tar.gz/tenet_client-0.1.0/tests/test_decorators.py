"""Tests for ``@judged`` — framework-free function gate via the cloud judge."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from tenet_client import (
    JudgeBlocked,
    JudgeUnavailableError,
    TenetCloudJudgeClient,
    judged,
)
from tenet_client.cloud_models import CloudJudgeResponse


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def _allow() -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
    )


def _block(reason: str | None = "policy violation") -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=12,
        reason=reason,
    )


def _client(*verdicts: CloudJudgeResponse) -> MagicMock:
    """A mocked cloud client; sync and async paths share the verdict list."""
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(verdicts)
    c.evaluate_async = AsyncMock(side_effect=list(verdicts))
    return c


def _client_raises(exc: Exception) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = exc
    c.evaluate_async = AsyncMock(side_effect=exc)
    return c


# --------------------------------------------------------------------------
# Sync function path
# --------------------------------------------------------------------------


class TestSyncFunction:
    def test_allow_runs_and_returns(self):
        c = _client(_allow(), _allow())

        @judged(c)
        def search(query: str) -> str:
            return f"results for {query}"

        assert search("python") == "results for python"
        assert c.evaluate.call_count == 2

    def test_pre_block_raises_before_call(self):
        c = _client(_block("PHI in args"))
        called = []

        @judged(c)
        def get_chart(patient_id: str) -> str:
            called.append(patient_id)
            return "chart"

        with pytest.raises(JudgeBlocked) as exc:
            get_chart("MRN12345")
        assert exc.value.phase == "tool_pre"
        assert exc.value.reason == "PHI in args"
        assert exc.value.tool_name == "get_chart"
        assert exc.value.judge_id == "hr-1"
        assert called == []

    def test_post_block_raises_after_call(self):
        c = _client(_allow(), _block("PHI in output"))
        called = []

        @judged(c)
        def fetch() -> str:
            called.append(True)
            return "leak"

        with pytest.raises(JudgeBlocked) as exc:
            fetch()
        assert exc.value.phase == "tool_post"
        assert called == [True]

    def test_check_post_false_skips_post(self):
        c = _client(_allow())

        @judged(c, check_post=False)
        def fn():
            return 42

        assert fn() == 42
        assert c.evaluate.call_count == 1
        assert c.evaluate.call_args.kwargs["phase"] == "tool_pre"

    def test_check_pre_false_skips_pre(self):
        c = _client(_allow())

        @judged(c, check_pre=False)
        def fn():
            return 42

        assert fn() == 42
        assert c.evaluate.call_count == 1
        assert c.evaluate.call_args.kwargs["phase"] == "tool_post"

    def test_both_phases_off_raises_at_decoration(self):
        c = _client()
        with pytest.raises(ValueError, match="at least one"):
            judged(c, check_pre=False, check_post=False)


class TestSyncFailureSemantics:
    def test_fail_closed_on_pre_unavailable(self):
        c = _client_raises(JudgeUnavailableError("auth0 down"))
        called = []

        @judged(c)
        def fn():
            called.append(True)
            return 1

        with pytest.raises(JudgeUnavailableError):
            fn()
        assert called == []

    def test_fail_open_on_pre_runs_function(self):
        c = MagicMock(spec=TenetCloudJudgeClient)
        c.evaluate.side_effect = [JudgeUnavailableError("transient"), _allow()]

        @judged(c, fail_open=True)
        def fn():
            return "ran"

        assert fn() == "ran"

    def test_fail_open_on_post_returns_value(self):
        c = MagicMock(spec=TenetCloudJudgeClient)
        c.evaluate.side_effect = [_allow(), JudgeUnavailableError("post down")]

        @judged(c, fail_open=True)
        def fn():
            return "value"

        assert fn() == "value"


class TestArgBinding:
    def test_default_builder_binds_args_to_param_names(self):
        c = _client(_allow(), _allow())

        @judged(c)
        def fn(patient_id: str, *, lookup_kind: str = "summary") -> str:
            return "ok"

        fn("MRN1", lookup_kind="full")
        first = c.evaluate.call_args_list[0].kwargs
        assert first["tool_input"] == {"patient_id": "MRN1", "lookup_kind": "full"}

    def test_default_builder_includes_defaults(self):
        c = _client(_allow(), _allow())

        @judged(c)
        def fn(a: int, b: int = 7) -> int:
            return a + b

        fn(1)
        first = c.evaluate.call_args_list[0].kwargs
        assert first["tool_input"] == {"a": 1, "b": 7}

    def test_custom_input_builder(self):
        c = _client(_allow(), _allow())

        def builder(*args, **kwargs):
            return {"redacted": "[args]"}

        @judged(c, input_builder=builder)
        def fn(secret: str) -> str:
            return "ok"

        fn("very-sensitive")
        first = c.evaluate.call_args_list[0].kwargs
        assert first["tool_input"] == {"redacted": "[args]"}

    def test_tool_name_override(self):
        c = _client(_allow(), _allow())

        @judged(c, tool_name="explicit_name")
        def some_internal_thing() -> str:
            return "ok"

        some_internal_thing()
        assert c.evaluate.call_args.kwargs["tool_name"] == "explicit_name"

    def test_default_tool_name_is_func_name(self):
        c = _client(_allow(), _allow())

        @judged(c)
        def my_func() -> str:
            return "ok"

        my_func()
        assert c.evaluate.call_args.kwargs["tool_name"] == "my_func"

    def test_metadata_forwarded(self):
        c = _client(_allow(), _allow())

        @judged(c, metadata={"source": "agent-x"})
        def fn() -> str:
            return "ok"

        fn()
        first = c.evaluate.call_args_list[0].kwargs
        assert first["metadata"] == {"source": "agent-x"}


class TestOutputCoercion:
    def test_string_output_passes_through(self):
        c = _client(_allow(), _allow())

        @judged(c)
        def fn() -> str:
            return "hello"

        fn()
        post = c.evaluate.call_args_list[1].kwargs
        assert post["tool_output"] == "hello"

    def test_dict_output_passes_through(self):
        c = _client(_allow(), _allow())

        @judged(c)
        def fn() -> dict:
            return {"k": "v", "n": 3}

        fn()
        post = c.evaluate.call_args_list[1].kwargs
        assert post["tool_output"] == {"k": "v", "n": 3}

    def test_non_jsonable_output_stringified(self):
        c = _client(_allow(), _allow())

        class _Foo:
            def __str__(self) -> str:
                return "<foo>"

        @judged(c)
        def fn() -> _Foo:
            return _Foo()

        fn()
        post = c.evaluate.call_args_list[1].kwargs
        assert post["tool_output"] == "<foo>"

    def test_custom_output_builder(self):
        c = _client(_allow(), _allow())

        @judged(c, output_builder=lambda v: f"len={len(v)}")
        def fn() -> str:
            return "abcdefg"

        fn()
        post = c.evaluate.call_args_list[1].kwargs
        assert post["tool_output"] == "len=7"


# --------------------------------------------------------------------------
# Async function path
# --------------------------------------------------------------------------


class TestAsyncFunction:
    @pytest.mark.asyncio
    async def test_allow_runs_and_returns(self):
        c = _client(_allow(), _allow())

        @judged(c)
        async def search(query: str) -> str:
            return f"async results for {query}"

        assert await search("python") == "async results for python"
        assert c.evaluate_async.await_count == 2
        c.evaluate.assert_not_called()  # async path must use evaluate_async only

    @pytest.mark.asyncio
    async def test_pre_block_raises_before_call(self):
        c = _client(_block("PHI"))
        called = []

        @judged(c)
        async def fn(x: int) -> int:
            called.append(x)
            return x * 2

        with pytest.raises(JudgeBlocked):
            await fn(5)
        assert called == []

    @pytest.mark.asyncio
    async def test_post_block_raises_after_call(self):
        c = _client(_allow(), _block())
        called = []

        @judged(c)
        async def fn() -> str:
            called.append(True)
            return "leak"

        with pytest.raises(JudgeBlocked):
            await fn()
        assert called == [True]

    @pytest.mark.asyncio
    async def test_fail_closed_async(self):
        c = _client_raises(JudgeUnavailableError("down"))

        @judged(c)
        async def fn() -> int:
            return 1

        with pytest.raises(JudgeUnavailableError):
            await fn()

    @pytest.mark.asyncio
    async def test_fail_open_async(self):
        c = MagicMock(spec=TenetCloudJudgeClient)
        c.evaluate_async = AsyncMock(side_effect=[JudgeUnavailableError("x"), _allow()])

        @judged(c, fail_open=True)
        async def fn() -> str:
            return "ran"

        assert await fn() == "ran"


# --------------------------------------------------------------------------
# Exception details
# --------------------------------------------------------------------------


class TestJudgeBlockedException:
    def test_message_includes_judge_phase_tool(self):
        c = _client(_block("nope"))

        @judged(c)
        def get_chart(p: str) -> str:
            return p

        try:
            get_chart("x")
        except JudgeBlocked as e:
            msg = str(e)
            assert "hr-1" in msg
            assert "tool_pre" in msg
            assert "get_chart" in msg
            assert "nope" in msg
        else:
            pytest.fail("expected JudgeBlocked")

    def test_message_when_reason_none(self):
        c = _client(_block(reason=None))

        @judged(c)
        def fn() -> int:
            return 1

        with pytest.raises(JudgeBlocked) as exc:
            fn()
        # No trailing ": " when reason is empty.
        assert ": " not in str(exc.value).split("'fn'")[-1]
