"""Tests for TenetClient."""

from __future__ import annotations
from unittest.mock import patch
import httpx
import pytest
from tenet_client.client import TenetClient, _read_api_key
from tenet_client.exceptions import TenetConnectionError
from tenet_client.models import EvaluateRequest, EvaluateResponse


class TestReadApiKey:
    def test_reads_existing_key(self, tmp_path):
        key_file = tmp_path / "api_key"
        key_file.write_text("test-key-123\n")
        with patch("tenet_client.client._API_KEY_PATH", key_file):
            assert _read_api_key() == "test-key-123"

    def test_returns_none_when_missing(self, tmp_path):
        with patch("tenet_client.client._API_KEY_PATH", tmp_path / "nonexistent"):
            assert _read_api_key() is None

    def test_returns_none_for_empty_file(self, tmp_path):
        key_file = tmp_path / "api_key"
        key_file.write_text("")
        with patch("tenet_client.client._API_KEY_PATH", key_file):
            assert _read_api_key() is None


class TestTenetClientInit:
    def test_explicit_api_key(self):
        client = TenetClient(api_key="my-key")
        assert client._api_key == "my-key"

    def test_auto_read_api_key(self, tmp_path):
        key_file = tmp_path / "api_key"
        key_file.write_text("auto-key")
        with patch("tenet_client.client._API_KEY_PATH", key_file):
            client = TenetClient()
            assert client._api_key == "auto-key"

    def test_headers_with_key(self):
        client = TenetClient(api_key="my-key")
        assert client._headers == {"Authorization": "Bearer my-key"}

    def test_headers_without_key(self):
        client = TenetClient(api_key="")
        assert client._headers == {}

    def test_custom_url(self):
        client = TenetClient(base_url="http://localhost:8080/")
        assert client._base_url == "http://localhost:8080"


class TestTenetClientSync:
    def test_evaluate_success(self):
        client = TenetClient(api_key="k")
        response_data = {"violations": [], "has_violations": False, "should_block": False, "processing_time_ms": 1.0, "pii_entities": []}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client._sync_client = httpx.Client(base_url=client._base_url, headers=client._headers, transport=transport)
        result = client.evaluate(EvaluateRequest(tool_name="search", tool_input="hello"))
        assert isinstance(result, EvaluateResponse)
        assert result.has_violations is False

    def test_evaluate_fail_open(self):
        client = TenetClient(api_key="k", fail_open=True)
        transport = httpx.MockTransport(lambda req: (_ for _ in ()).throw(httpx.ConnectError("fail")))
        client._sync_client = httpx.Client(base_url=client._base_url, headers=client._headers, transport=transport)
        result = client.evaluate(EvaluateRequest(tool_name="search"))
        assert result.has_violations is False

    def test_evaluate_fail_closed(self):
        client = TenetClient(api_key="k", fail_open=False)
        transport = httpx.MockTransport(lambda req: (_ for _ in ()).throw(httpx.ConnectError("fail")))
        client._sync_client = httpx.Client(base_url=client._base_url, headers=client._headers, transport=transport)
        with pytest.raises(TenetConnectionError):
            client.evaluate(EvaluateRequest(tool_name="search"))


class TestTenetClientAsync:
    @pytest.mark.asyncio
    async def test_evaluate_async_success(self):
        client = TenetClient(api_key="k")
        response_data = {"violations": [], "has_violations": False, "should_block": False, "processing_time_ms": 1.0, "pii_entities": []}
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json=response_data))
        client._async_client = httpx.AsyncClient(base_url=client._base_url, headers=client._headers, transport=transport)
        result = await client.evaluate_async(EvaluateRequest(tool_name="search", tool_input="hello"))
        assert result.has_violations is False
        await client.close_async()

    @pytest.mark.asyncio
    async def test_evaluate_async_fail_open(self):
        client = TenetClient(api_key="k", fail_open=True)
        transport = httpx.MockTransport(lambda req: (_ for _ in ()).throw(httpx.ConnectError("fail")))
        client._async_client = httpx.AsyncClient(base_url=client._base_url, headers=client._headers, transport=transport)
        result = await client.evaluate_async(EvaluateRequest(tool_name="search"))
        assert result.has_violations is False
        await client.close_async()

    @pytest.mark.asyncio
    async def test_evaluate_async_fail_closed(self):
        client = TenetClient(api_key="k", fail_open=False)
        transport = httpx.MockTransport(lambda req: (_ for _ in ()).throw(httpx.ConnectError("fail")))
        client._async_client = httpx.AsyncClient(base_url=client._base_url, headers=client._headers, transport=transport)
        with pytest.raises(TenetConnectionError):
            await client.evaluate_async(EvaluateRequest(tool_name="search"))
        await client.close_async()
