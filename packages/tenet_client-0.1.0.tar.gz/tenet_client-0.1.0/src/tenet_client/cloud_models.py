"""Pydantic models + error types for the Tenet cloud judge client.

The cloud surface is now served by the tenet-judge-engine platform at
``POST /eeo/decide`` on ``judge.tenetlabs.com`` (RFC-008). The new
server response carries a richer envelope than the legacy binary
allow/block: native ``verdict`` / ``severity`` / ``risk_labels`` /
``rule_chain`` / ``path`` / ``decision_metadata`` are all available
to policy callbacks (notably the ``severity_routed_policy`` recipe).

The legacy 5-field response shape (``decision``, ``judge_id``,
``judge_version``, ``latency_ms``, ``reason``) is preserved as
derived attributes on :class:`CloudJudgeResponse` so existing
integrators don't break. The legacy request envelope (``judge_id``,
``phase``, ``tool_name``, ``tool_input``, ...) stays the SDK's public
input shape; the client translates it into the new ``/eeo/decide``
wire body internally so integrator code keeps the same call sites.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

CloudJudgePhase = Literal["agent_input", "tool_pre", "tool_post", "agent_output"]
CloudJudgeDecision = Literal["allow", "block"]
CloudResolutionStatus = Literal["resolved", "unresolved", "error"]

# Native /eeo/decide verdict + severity vocabularies.
CloudJudgeVerdict = Literal[
    "pass",
    "block",
    "route_to_human",
    "include",
    "exclude",
    "include_with_caveats",
    "defer",
    "fast_pass",
]
CloudJudgeSeverity = Literal["info", "low", "medium", "high", "critical"]


class CloudJudgeRequest(BaseModel):
    """Public request envelope (SDK-facing input shape).

    Translated internally to the ``/eeo/decide`` server envelope by
    :mod:`tenet_client.cloud_client`; integrators keep the legacy
    field names at the call site.

    ``surface`` selects the engine-side policy bundle (``resume_triage``,
    ``job_ad_drafting``, etc.) and is orthogonal to ``tool_name`` — the
    same surface can gate calls to many different tools.
    """

    judge_id: str
    phase: CloudJudgePhase
    surface: str = "resume_triage"
    tool_name: str = ""
    tool_input: Any = None
    tool_output: Any = None
    session_id: str | None = None
    trace_id: str | None = None
    parent_span_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    # RFC-008 §4.4.5 wire-contract extension. Client-side heuristic
    # classification of the tool outcome (resolved / unresolved / error);
    # threaded into RailContext server-side so future Tenet DSL rules can
    # branch on it. None = "client did not classify" — preserves
    # pre-Phase-4.5 behavior byte-for-byte.
    resolution_status: CloudResolutionStatus | None = None


class CloudJudgeResponse(BaseModel):
    """Response from the cloud judge.

    Combines the legacy 5-field allow/block envelope (preserved for
    backward compatibility) with the richer native fields served by
    ``POST /eeo/decide`` on the new tenet-judge-engine platform.

    Legacy fields (``decision``, ``judge_id``, ``judge_version``,
    ``latency_ms``, ``reason``) are populated for every response —
    derived from the native fields by
    :mod:`tenet_client.cloud_client._parse_judge_response`.
    """

    # Legacy fields — preserved across the wire-shape cutover.
    decision: CloudJudgeDecision
    judge_id: str
    judge_version: str
    latency_ms: int
    reason: str | None = None

    # Native /eeo/decide fields — populated when the cloud is the new
    # platform; optional so legacy fixtures still parse cleanly.
    # `verdict` and `severity` are intentionally typed as plain ``str |
    # None`` (not the documented Literal) so a future server-side
    # vocabulary addition does not break SDK consumers. The literals
    # are exported as documentation + for use in policy callbacks that
    # want to narrow the type.
    verdict: str | None = None
    severity: str | None = None
    risk_labels: list[str] = Field(default_factory=list)
    rule_ids: list[str] = Field(default_factory=list)
    path: str | None = None
    rule_chain: list[dict[str, Any]] = Field(default_factory=list)
    evidence_span: str | None = None
    source_trust_triggers: list[str] = Field(default_factory=list)
    decision_metadata: dict[str, Any] = Field(default_factory=dict)


class JudgeUnavailableError(Exception):
    """Raised when the cloud judge could not produce a verdict.

    Folds together every failure mode the integrator should treat as a
    "no answer" outcome and decide downstream behavior on:

    - Network timeout reaching the cloud or Auth0 token endpoint
    - 5xx from the cloud
    - 5xx or 4xx from Auth0 during token mint / refresh
    - 4xx (auth) from the cloud after a refresh attempt
    - Malformed cloud response (non-JSON, missing ``decision``, unknown
      ``decision`` value, missing token in Auth0 response, etc.)

    The integrator catches this and chooses what to do (halt the agent,
    return a default, retry, log + proceed). The SDK does not have a
    ``fail_open`` flag — that is downstream policy.

    Error messages intentionally do not echo ``tool_input`` /
    ``tool_output`` content; they describe only the category of failure
    so PII/PHI cannot leak into application logs via this exception.
    """
