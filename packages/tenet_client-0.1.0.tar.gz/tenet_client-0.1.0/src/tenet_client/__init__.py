"""Tenet SDK — cloud judge client and local server client.

Framework-agnostic. The LangChain adapter classes (``TenetMiddleware``,
``TenetCallbackHandler``, ``TenetGuard``) live in the separate
``tenet-langchain`` package and depend on this one.

Surface:

- :class:`TenetCloudJudgeClient` — calls the cloud judge route at
  ``https://api.tenetlabs.com/v1/judge/evaluate``. The primary
  customer-facing entry point.
- :class:`TenetClient` — calls the local Tenet server (HTTP
  ``http://127.0.0.1:19990``). Used by the Tenet desktop app and any
  on-prem-deployed local server.
- :exc:`JudgeUnavailableError` / :exc:`TenetConnectionError` /
  :exc:`TenetViolationError` — exception types for failure handling.
- ``CloudJudgeRequest`` / ``CloudJudgeResponse`` etc. — Pydantic
  wire types if you need them.
"""

from tenet_client.client import TenetClient
from tenet_client.cloud_client import TenetCloudJudgeClient
from tenet_client.cloud_models import (
    CloudJudgeDecision,
    CloudJudgePhase,
    CloudJudgeRequest,
    CloudJudgeResponse,
    JudgeUnavailableError,
)
from tenet_client.decorators import JudgeBlocked, judged
from tenet_client.exceptions import TenetConnectionError, TenetViolationError
from tenet_client.policy import (
    JudgeAction,
    JudgeContext,
    JudgePolicy,
    JudgeVerdict,
)
from tenet_client.models import (
    DetectResponse,
    EvaluateRequest,
    EvaluateResponse,
    FindDecisionRequest,
    FindDecisionResponse,
    HealthResponse,
    RedactResponse,
    StoreDecisionRequest,
    Violation,
)

__all__ = [
    "CloudJudgeDecision",
    "CloudJudgePhase",
    "CloudJudgeRequest",
    "CloudJudgeResponse",
    "DetectResponse",
    "EvaluateRequest",
    "EvaluateResponse",
    "FindDecisionRequest",
    "FindDecisionResponse",
    "HealthResponse",
    "JudgeAction",
    "JudgeBlocked",
    "JudgeContext",
    "JudgePolicy",
    "JudgeUnavailableError",
    "JudgeVerdict",
    "RedactResponse",
    "StoreDecisionRequest",
    "TenetClient",
    "TenetCloudJudgeClient",
    "TenetConnectionError",
    "TenetViolationError",
    "Violation",
    "judged",
]
