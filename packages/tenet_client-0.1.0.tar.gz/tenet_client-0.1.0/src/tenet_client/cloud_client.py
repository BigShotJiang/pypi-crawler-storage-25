"""Tenet cloud judge client — Auth0 token exchange + ``POST /eeo/decide``.

The whole SDK surface for the cloud judge is this client. Integrators wire
it into LangChain (or any other framework) themselves at whichever
attachment point fits their agent — see ``docs/cloud_judge_recipes.md``
for canonical patterns. There is no opinionated middleware in the SDK;
this file ships the client and ``cloud_models`` ships the request /
response / error types.

Authorization model
-------------------
Every ``evaluate()`` / ``evaluate_async()`` call goes through:

1. **Token mint or cache hit.** The first call mints an Auth0
   client_credentials token for ``audience``. Subsequent calls reuse
   the token until ``exp - 60s`` (the 60-second skew window protects
   against clock drift between the SDK process and Auth0).
2. **Cloud call** with ``Authorization: Bearer <token>``.
3. **On 401**, refresh the token once and retry the cloud call. A
   second 401 surfaces as ``JudgeUnavailableError``.

Concurrency
-----------
The token cache is in-memory and per-instance. Within a single
``TenetCloudJudgeClient`` instance, sync and async paths share the
cache so a sync ``evaluate()`` that mints a token saves an Auth0
round-trip on a follow-up ``evaluate_async()``. There is no locking
around the cache — concurrent first-call mints from multiple threads
or tasks may issue redundant Auth0 requests. That race is acceptable
in v1 (Auth0 is idempotent for client_credentials grants) and adds
significantly less complexity than a thread-safe cache.

Failure mapping
---------------
All recoverable + unrecoverable failures collapse into
``JudgeUnavailableError``. The integrator catches one exception type
and decides what to do. This is deliberate — a per-failure exception
hierarchy would push retry policy into the SDK, which is downstream
policy that the integrator owns.
"""

from __future__ import annotations

import os
import time
from typing import Any, Callable

import httpx

from tenet_client.cloud_models import (
    CloudJudgePhase,
    CloudJudgeRequest,
    CloudJudgeResponse,
    CloudResolutionStatus,
    JudgeUnavailableError,
)
from tenet_client.policy import JudgeContext, JudgeVerdict

# --------------------------------------------------------------------------
# Defaults
# --------------------------------------------------------------------------

_DEFAULT_CLOUD_URL = "https://judge.tenetlabs.com"
_DEFAULT_AUDIENCE = "https://sdk.tenetlabs.com"
_DEFAULT_AUTH0_ISSUER_URL = "https://auth.tenetlabs.com/"
_DEFAULT_JUDGE_ID = "hr-1"
_DEFAULT_SURFACE = "resume_triage"
_DEFAULT_TIMEOUT_SECONDS = 3.0
# Refresh tokens this many seconds before their `exp` to absorb clock skew
# between the SDK process and Auth0.
_TOKEN_REFRESH_LEEWAY_SECONDS = 60


# --------------------------------------------------------------------------
# Token cache (in-memory, per-instance)
# --------------------------------------------------------------------------


class _TokenCache:
    """Stores ``(token, expires_at_unix)`` and decides when to refresh."""

    def __init__(self, now: Callable[[], float] = time.time) -> None:
        self._token: str | None = None
        self._expires_at: float = 0.0
        self._now = now

    def get(self) -> str | None:
        if self._token is None:
            return None
        if self._now() >= self._expires_at - _TOKEN_REFRESH_LEEWAY_SECONDS:
            return None
        return self._token

    def set(self, token: str, expires_in: int) -> None:
        self._token = token
        self._expires_at = self._now() + float(expires_in)

    def invalidate(self) -> None:
        self._token = None
        self._expires_at = 0.0


# --------------------------------------------------------------------------
# Client
# --------------------------------------------------------------------------


class TenetCloudJudgeClient:
    """Cloud judge client.

    Parameters
    ----------
    client_id, client_secret:
        Auth0 M2M credentials. Issued per customer at provisioning time.
    judge_id:
        Name of the judge to invoke. Currently supported: ``hr-1``
        (Fireworks-hosted EEO / employment compliance, the default) and
        ``healthcare-1`` (Modal-hosted PHI / clinical-safety compliance).
    timeout:
        Default per-call timeout in seconds. Per-call ``evaluate(...,
        timeout=...)`` overrides this on a single call.

    Internal escape hatches (underscore-prefixed; do not use in
    production integrator code): ``_cloud_url``, ``_audience``,
    ``_auth0_issuer_url`` point at Tenet-operated infrastructure and
    exist only for dev / staging environments. ``_sync_transport``,
    ``_async_transport``, and ``_now`` are test seams.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        judge_id: str = _DEFAULT_JUDGE_ID,
        surface: str = _DEFAULT_SURFACE,
        timeout: float = _DEFAULT_TIMEOUT_SECONDS,
        # --- internal escape hatches; underscore-prefixed to keep them
        # out of the public surface. Production code uses the defaults.
        _cloud_url: str = _DEFAULT_CLOUD_URL,
        _audience: str = _DEFAULT_AUDIENCE,
        _auth0_issuer_url: str = _DEFAULT_AUTH0_ISSUER_URL,
        _sync_transport: httpx.BaseTransport | None = None,
        _async_transport: httpx.AsyncBaseTransport | None = None,
        _now: Callable[[], float] | None = None,
    ) -> None:
        if not client_id or not client_secret:
            raise ValueError("client_id and client_secret are required")

        self._cloud_url = _cloud_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self._audience = _audience
        self._auth0_issuer_url = _auth0_issuer_url.rstrip("/") + "/"
        self._judge_id = judge_id
        self._surface = surface
        self._timeout = timeout

        self._cache = _TokenCache(now=_now or time.time)
        self._sync_transport = _sync_transport
        self._async_transport = _async_transport
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    # -- factory --

    @classmethod
    def from_env(cls) -> TenetCloudJudgeClient:
        """Construct from ``TENET_*`` environment variables.

        Required: ``TENET_CLIENT_ID``, ``TENET_CLIENT_SECRET`` — the
        credentials Tenet provisions for your account.

        Optional tuning: ``TENET_JUDGE_ID`` (defaults to ``hr-1``),
        ``TENET_JUDGE_TIMEOUT_SECONDS`` (defaults to ``3.0``).

        Optional internal overrides, normally untouched: ``TENET_CLOUD_URL``,
        ``TENET_AUTH0_AUDIENCE``, ``TENET_AUTH0_ISSUER_URL``. These point at
        Tenet-operated infrastructure and only need to be set for dev /
        staging environments.

        Raises ``ValueError`` if a required variable is missing or empty,
        naming the offending variable.
        """
        required = ("TENET_CLIENT_ID", "TENET_CLIENT_SECRET")
        missing = [name for name in required if not os.environ.get(name)]
        if missing:
            raise ValueError(
                f"missing required environment variable(s): {', '.join(missing)}"
            )
        return cls(
            client_id=os.environ["TENET_CLIENT_ID"],
            client_secret=os.environ["TENET_CLIENT_SECRET"],
            judge_id=os.environ.get("TENET_JUDGE_ID", _DEFAULT_JUDGE_ID),
            surface=os.environ.get("TENET_SURFACE", _DEFAULT_SURFACE),
            timeout=float(
                os.environ.get("TENET_JUDGE_TIMEOUT_SECONDS", str(_DEFAULT_TIMEOUT_SECONDS))
            ),
            _cloud_url=os.environ.get("TENET_CLOUD_URL", _DEFAULT_CLOUD_URL),
            _audience=os.environ.get("TENET_AUTH0_AUDIENCE", _DEFAULT_AUDIENCE),
            _auth0_issuer_url=os.environ.get("TENET_AUTH0_ISSUER_URL", _DEFAULT_AUTH0_ISSUER_URL),
        )

    # -- httpx clients --

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                timeout=self._timeout,
                transport=self._sync_transport,
            )
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                timeout=self._timeout,
                transport=self._async_transport,
            )
        return self._async_client

    def close(self) -> None:
        if self._sync_client is not None and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client is not None and not self._async_client.is_closed:
            await self._async_client.aclose()

    # -- warmup --

    def warmup(self) -> None:
        """Pre-mint the Auth0 token + open the underlying httpx connection.

        The first ``evaluate()`` from a fresh client incurs (a) a TLS
        handshake to Auth0, (b) the Auth0 token mint round trip, and (c)
        a TLS handshake to the cloud. Calling ``warmup()`` at process
        start moves (a) and (b) — typically 300–600 ms cold — out of the
        user-facing critical path. (c) still happens on the first
        ``evaluate()`` because there is no unauthenticated route to
        ping; cost is ~80–150 ms one-time.

        Idempotent: subsequent calls skip the mint when the token is
        still cached (returns instantly). Safe to call from a startup
        hook even if a previous request already minted.

        Raises ``JudgeUnavailableError`` if Auth0 is unreachable or
        rejects the credentials — caller can use this as a credential
        smoke test at startup.
        """
        if self._cache.get() is None:
            self._mint_token_sync()

    async def warmup_async(self) -> None:
        """Async variant of :meth:`warmup`.

        Same semantics: pre-mints the token if the cache is empty,
        no-op otherwise. Use at async-app startup (e.g. FastAPI
        ``startup`` event handler, LangGraph init).
        """
        if self._cache.get() is None:
            await self._mint_token_async()

    # -- token mint --

    def _build_token_payload(self) -> dict[str, str]:
        return {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "audience": self._audience,
        }

    def _token_endpoint(self) -> str:
        return f"{self._auth0_issuer_url}oauth/token"

    @staticmethod
    def _parse_token_response(resp: httpx.Response) -> tuple[str, int]:
        """Return ``(access_token, expires_in)`` or raise JudgeUnavailableError."""
        if resp.status_code >= 400:
            raise JudgeUnavailableError(f"auth0 token mint failed: {resp.status_code}")
        try:
            data = resp.json()
        except ValueError as e:
            raise JudgeUnavailableError("auth0 returned non-JSON response") from e
        token = data.get("access_token")
        expires_in = data.get("expires_in")
        if not isinstance(token, str) or not token:
            raise JudgeUnavailableError("auth0 response missing access_token")
        if not isinstance(expires_in, (int, float)):
            # Auth0 always returns expires_in for client_credentials but be defensive.
            expires_in = 86400
        return token, int(expires_in)

    def _mint_token_sync(self) -> str:
        client = self._get_sync_client()
        try:
            resp = client.post(
                self._token_endpoint(),
                json=self._build_token_payload(),
            )
        except (httpx.TimeoutException, httpx.TransportError) as e:
            raise JudgeUnavailableError(
                f"auth0 token mint network error: {type(e).__name__}"
            ) from e
        token, expires_in = self._parse_token_response(resp)
        self._cache.set(token, expires_in)
        return token

    async def _mint_token_async(self) -> str:
        client = await self._get_async_client()
        try:
            resp = await client.post(
                self._token_endpoint(),
                json=self._build_token_payload(),
            )
        except (httpx.TimeoutException, httpx.TransportError) as e:
            raise JudgeUnavailableError(
                f"auth0 token mint network error: {type(e).__name__}"
            ) from e
        token, expires_in = self._parse_token_response(resp)
        self._cache.set(token, expires_in)
        return token

    # -- request building / response parsing --

    def _build_request(
        self,
        *,
        phase: CloudJudgePhase,
        tool_name: str,
        tool_input: Any,
        tool_output: Any,
        session_id: str | None,
        trace_id: str | None,
        parent_span_id: str | None,
        metadata: dict[str, Any] | None,
        resolution_status: CloudResolutionStatus | None,
        surface: str | None = None,
    ) -> CloudJudgeRequest:
        return CloudJudgeRequest(
            judge_id=self._judge_id,
            phase=phase,
            surface=surface if surface is not None else self._surface,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            session_id=session_id,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            metadata=metadata or {},
            resolution_status=resolution_status,
        )

    _ALLOW_VERDICTS = frozenset({"pass", "include", "fast_pass"})

    @staticmethod
    def _to_decide_body(req: CloudJudgeRequest) -> dict[str, Any]:
        """Translate the legacy SDK request shape into the new ``/eeo/decide``
        server envelope (RFC-008 §4.1).

        The server reads ``context.recruiter_prompt`` and
        ``context.candidate_content`` per the EEO pipeline contract.
        We extract those keys from ``tool_input`` if present; otherwise
        we pass the full dict through unchanged so future Tenet DSL
        rules can branch on application-specific fields.

        ``surface`` is taken verbatim from ``req.surface`` (a client-level
        config or per-call override) — not derived from ``tool_name``.
        ``tool_name`` is forwarded into ``context.tool_name`` so engine
        rules can branch on the agent's intended tool, when non-empty.
        """
        # Context: build from tool_input (and tool_output for tool_post).
        context: dict[str, Any] = {}
        ti = req.tool_input
        if isinstance(ti, dict):
            context.update(ti)
        elif ti is not None:
            context["tool_input"] = ti
        to = req.tool_output
        if isinstance(to, dict):
            for k, v in to.items():
                context.setdefault(k, v)
        elif to is not None:
            context.setdefault("tool_output", to)
        if req.tool_name:
            context.setdefault("tool_name", req.tool_name)
        # The EEO pipeline keys; populate defaults if the integrator's
        # tool_input did not already supply them.
        if "recruiter_prompt" not in context:
            # Stringify so the EEO guards have a single text blob to scan;
            # dict / list inputs get serialized in a stable way.
            if isinstance(ti, str):
                context["recruiter_prompt"] = ti
            elif ti is None:
                context["recruiter_prompt"] = ""
            else:
                import json as _json
                context["recruiter_prompt"] = _json.dumps(ti, sort_keys=True)
        if "candidate_content" not in context:
            context["candidate_content"] = None

        # Messages: single user turn carrying the recruiter prompt; the
        # pipeline reads messages[0].content for some guard paths.
        messages: list[dict[str, Any]] = [
            {"role": "user", "content": str(context.get("recruiter_prompt", ""))}
        ]

        body: dict[str, Any] = {
            "surface": req.surface,
            "messages": messages,
            "context": context,
        }
        if req.phase is not None:
            body["phase"] = req.phase
        if req.resolution_status is not None:
            body["resolution_status"] = req.resolution_status
        return body

    def _parse_judge_response(self, resp: httpx.Response) -> CloudJudgeResponse:
        """Parse the ``/eeo/decide`` response into a :class:`CloudJudgeResponse`.

        Populates both the new native fields and the synthesized legacy
        ``decision`` / ``judge_id`` / ``judge_version`` / ``reason`` so
        existing integrators (legacy callers checking ``decision``) and
        new policy recipes (severity_routed_policy on ``severity``) both
        work against the same response object.
        """
        try:
            data = resp.json()
        except ValueError as e:
            raise JudgeUnavailableError("cloud returned non-JSON response") from e
        if not isinstance(data, dict):
            raise JudgeUnavailableError("cloud response is not a JSON object")

        verdict = data.get("verdict")
        # /eeo/decide MUST emit `verdict`. A missing field is server-side
        # malformation, not a routing signal; surface as unavailable.
        if not isinstance(verdict, str) or not verdict:
            raise JudgeUnavailableError("cloud response missing 'verdict' field")
        # Map native verdict → legacy binary decision.
        decision = "allow" if verdict in self._ALLOW_VERDICTS else "block"

        decision_metadata = data.get("decision_metadata") or {}
        if not isinstance(decision_metadata, dict):
            decision_metadata = {}

        # judge_version: prefer the server's config_version when reported,
        # then fall back to a stable identifier so legacy callers always
        # see a non-empty string.
        judge_version = (
            decision_metadata.get("config_version")
            or decision_metadata.get("judge_version")
            or "tenet-judge-engine"
        )

        # reason: first non-empty signal from the decision tree.
        reason: str | None = decision_metadata.get("reason")
        if not reason:
            rc = data.get("rule_chain") or []
            if isinstance(rc, list) and rc:
                first = rc[0]
                if isinstance(first, dict):
                    md = first.get("metadata") or {}
                    if isinstance(md, dict):
                        reason = md.get("reason") or first.get("rule_id")
        if not reason:
            reason = data.get("evidence_span")

        merged: dict[str, Any] = {
            "decision": decision,
            "judge_id": self._judge_id,
            "judge_version": str(judge_version),
            "latency_ms": int(data.get("latency_ms") or 0),
            "reason": reason,
            "verdict": verdict,
            "severity": data.get("severity"),
            "risk_labels": data.get("risk_labels") or [],
            "rule_ids": data.get("rule_ids") or [],
            "path": data.get("path"),
            "rule_chain": data.get("rule_chain") or [],
            "evidence_span": data.get("evidence_span"),
            "source_trust_triggers": data.get("source_trust_triggers") or [],
            "decision_metadata": decision_metadata,
        }
        try:
            return CloudJudgeResponse.model_validate(merged)
        except Exception as e:  # pydantic.ValidationError — keep error opaque
            raise JudgeUnavailableError(
                f"cloud response failed validation: {type(e).__name__}"
            ) from e

    def _judge_endpoint(self) -> str:
        # Healthcare (cowork) does not have a sync /decide route on the
        # new platform yet — cowork ingest is async via /cowork/spans
        # → SQS. Raise loudly so the caller doesn't silently 404.
        if self._judge_id == "hr-1":
            return f"{self._cloud_url}/eeo/decide"
        raise JudgeUnavailableError(
            f"judge_id={self._judge_id!r} is not yet served by tenet-judge-engine; "
            "only hr-1 is wired in this cutover. Use the legacy api.tenetlabs.com "
            "client until the cowork sync surface lands."
        )

    @staticmethod
    def _resolve_timeout(timeout: float | None, default: float) -> float:
        return timeout if timeout is not None else default

    # -- evaluate (sync) --

    def evaluate(
        self,
        *,
        phase: CloudJudgePhase,
        tool_name: str = "",
        tool_input: Any = None,
        tool_output: Any = None,
        session_id: str | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timeout: float | None = None,
        resolution_status: CloudResolutionStatus | None = None,
        surface: str | None = None,
    ) -> CloudJudgeResponse:
        req = self._build_request(
            phase=phase,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            session_id=session_id,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            metadata=metadata,
            resolution_status=resolution_status,
            surface=surface,
        )
        body = self._to_decide_body(req)
        effective_timeout = self._resolve_timeout(timeout, self._timeout)

        token = self._cache.get() or self._mint_token_sync()
        resp = self._post_judge_sync(token, body, effective_timeout)
        if resp.status_code == 401:
            # Auth on the cloud side rejected our cached token. Refresh
            # once and retry; a second 401 is fatal.
            self._cache.invalidate()
            token = self._mint_token_sync()
            resp = self._post_judge_sync(token, body, effective_timeout)
            if resp.status_code == 401:
                raise JudgeUnavailableError("cloud rejected refreshed token (401 after refresh)")

        if resp.status_code >= 400:
            raise JudgeUnavailableError(f"cloud returned {resp.status_code}")
        return self._parse_judge_response(resp)

    def _post_judge_sync(self, token: str, body: dict[str, Any], timeout: float) -> httpx.Response:
        client = self._get_sync_client()
        try:
            return client.post(
                self._judge_endpoint(),
                json=body,
                headers={"Authorization": f"Bearer {token}"},
                timeout=timeout,
            )
        except (httpx.TimeoutException, httpx.TransportError) as e:
            raise JudgeUnavailableError(f"cloud network error: {type(e).__name__}") from e

    # -- evaluate (async) --

    async def evaluate_async(
        self,
        *,
        phase: CloudJudgePhase,
        tool_name: str = "",
        tool_input: Any = None,
        tool_output: Any = None,
        session_id: str | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timeout: float | None = None,
        resolution_status: CloudResolutionStatus | None = None,
        surface: str | None = None,
    ) -> CloudJudgeResponse:
        req = self._build_request(
            phase=phase,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            session_id=session_id,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            metadata=metadata,
            resolution_status=resolution_status,
            surface=surface,
        )
        body = self._to_decide_body(req)
        effective_timeout = self._resolve_timeout(timeout, self._timeout)

        token = self._cache.get() or await self._mint_token_async()
        resp = await self._post_judge_async(token, body, effective_timeout)
        if resp.status_code == 401:
            self._cache.invalidate()
            token = await self._mint_token_async()
            resp = await self._post_judge_async(token, body, effective_timeout)
            if resp.status_code == 401:
                raise JudgeUnavailableError("cloud rejected refreshed token (401 after refresh)")

        if resp.status_code >= 400:
            raise JudgeUnavailableError(f"cloud returned {resp.status_code}")
        return self._parse_judge_response(resp)

    async def _post_judge_async(
        self, token: str, body: dict[str, Any], timeout: float
    ) -> httpx.Response:
        client = await self._get_async_client()
        try:
            return await client.post(
                self._judge_endpoint(),
                json=body,
                headers={"Authorization": f"Bearer {token}"},
                timeout=timeout,
            )
        except (httpx.TimeoutException, httpx.TransportError) as e:
            raise JudgeUnavailableError(f"cloud network error: {type(e).__name__}") from e

    # -- evaluate_phase: high-level (verdict + policy → action) ---------

    def evaluate_phase(
        self,
        *,
        policy: Any,
        phase: CloudJudgePhase,
        tool_name: str = "",
        tool_input: Any = None,
        tool_output: Any = None,
        session_id: str | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timeout: float | None = None,
        resolution_status: CloudResolutionStatus | None = None,
        surface: str | None = None,
    ) -> tuple[Any, Any]:
        """Evaluate one phase + apply ``policy`` → ``(JudgeVerdict, JudgeAction)``.

        High-level convenience for callers building their own agents
        without LangChain. Mirrors what
        :class:`tenet_langchain.TenetJudgeMiddleware` does internally:

        1. Call ``evaluate(...)``.
        2. Wrap the response in a :class:`JudgeVerdict`.
        3. Hand the verdict to ``policy.decide(...)``.

        ``resolution_status`` is the RFC-008 §4.4.5 wire-contract
        extension — when set to ``"unresolved"``, ``policy.decide``
        routes through ``on_unresolved`` regardless of the verdict.
        ``None`` preserves pre-Phase-4.5 behavior.

        On :exc:`JudgeUnavailableError`, hands the error to
        ``policy.on_unavailable_action(...)`` and returns a synthesized
        ``unavailable``-status verdict so audit logs see the failure.
        """
        ctx = JudgeContext(
            phase=phase,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            session_id=session_id,
            trace_id=trace_id,
            metadata=metadata or {},
        )
        try:
            resp = self.evaluate(
                phase=phase,
                tool_name=tool_name,
                tool_input=tool_input,
                tool_output=tool_output,
                session_id=session_id,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                metadata=metadata,
                timeout=timeout,
                resolution_status=resolution_status,
                surface=surface,
            )
        except JudgeUnavailableError as err:
            verdict = JudgeVerdict(
                decision="block",
                status="unavailable",
                judge_id=getattr(self, "_judge_id", ""),
                judge_version="",
                latency_ms=0,
                reason=str(err),
            )
            action = policy.on_unavailable_action(ctx, err)
            return verdict, action

        verdict = JudgeVerdict.from_cloud_response(resp)
        action = policy.decide(ctx, verdict, resolution_status=resolution_status)
        return verdict, action

    async def evaluate_phase_async(
        self,
        *,
        policy: Any,
        phase: CloudJudgePhase,
        tool_name: str = "",
        tool_input: Any = None,
        tool_output: Any = None,
        session_id: str | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timeout: float | None = None,
        resolution_status: CloudResolutionStatus | None = None,
        surface: str | None = None,
    ) -> tuple[Any, Any]:
        """Async variant of :meth:`evaluate_phase`."""
        ctx = JudgeContext(
            phase=phase,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            session_id=session_id,
            trace_id=trace_id,
            metadata=metadata or {},
        )
        try:
            resp = await self.evaluate_async(
                phase=phase,
                tool_name=tool_name,
                tool_input=tool_input,
                tool_output=tool_output,
                session_id=session_id,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                metadata=metadata,
                timeout=timeout,
                resolution_status=resolution_status,
                surface=surface,
            )
        except JudgeUnavailableError as err:
            verdict = JudgeVerdict(
                decision="block",
                status="unavailable",
                judge_id=getattr(self, "_judge_id", ""),
                judge_version="",
                latency_ms=0,
                reason=str(err),
            )
            action = policy.on_unavailable_action(ctx, err)
            return verdict, action

        verdict = JudgeVerdict.from_cloud_response(resp)
        action = policy.decide(ctx, verdict, resolution_status=resolution_status)
        return verdict, action
