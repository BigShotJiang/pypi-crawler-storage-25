"""Async and sync HTTP client wrapping the Tenet server API."""

from __future__ import annotations

import logging
from pathlib import Path

import httpx

from tenet_client.exceptions import TenetConnectionError
from tenet_client.models import (
    DetectResponse,
    EvaluateRequest,
    EvaluateResponse,
    FindDecisionRequest,
    FindDecisionResponse,
    HealthResponse,
    RedactResponse,
    StoreDecisionRequest,
)

logger = logging.getLogger(__name__)

_DEFAULT_URL = "http://127.0.0.1:19990"
_API_KEY_PATH = Path("~/.tenet/api_key").expanduser()


def _read_api_key() -> str | None:
    """Read API key from ~/.tenet/api_key if it exists."""
    try:
        if _API_KEY_PATH.exists():
            return _API_KEY_PATH.read_text().strip() or None
    except OSError:
        pass
    return None


class TenetClient:
    """HTTP client for the Tenet server API.

    Supports both async and sync usage patterns.
    Auto-reads the API key from ``~/.tenet/api_key`` if not provided.
    """

    def __init__(
        self,
        base_url: str = _DEFAULT_URL,
        api_key: str | None = None,
        timeout: float = 10.0,
        fail_open: bool = True,
    ):
        if api_key is None:
            api_key = _read_api_key()

        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._fail_open = fail_open
        self._async_client: httpx.AsyncClient | None = None
        self._sync_client: httpx.Client | None = None

    @property
    def _headers(self) -> dict[str, str]:
        if self._api_key:
            return {"Authorization": f"Bearer {self._api_key}"}
        return {}

    # -- Async interface --

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=self._headers,
                timeout=self._timeout,
            )
        return self._async_client

    async def evaluate_async(self, request: EvaluateRequest) -> EvaluateResponse:
        """Evaluate an agent action against tenet rules (async)."""
        client = await self._get_async_client()
        try:
            resp = await client.post("/evaluate", json=request.model_dump())
            resp.raise_for_status()
            return EvaluateResponse.model_validate(resp.json())
        except httpx.ConnectError as exc:
            if self._fail_open:
                logger.warning("Tenet server unreachable (fail_open=True): %s", exc)
                return EvaluateResponse(
                    violations=[], has_violations=False, should_block=False,
                    processing_time_ms=0.0,
                )
            raise TenetConnectionError() from exc

    async def health_async(self) -> HealthResponse:
        client = await self._get_async_client()
        resp = await client.get("/health")
        resp.raise_for_status()
        return HealthResponse.model_validate(resp.json())

    async def detect_async(self, text: str) -> DetectResponse:
        client = await self._get_async_client()
        resp = await client.post("/detect", json={"text": text})
        resp.raise_for_status()
        return DetectResponse.model_validate(resp.json())

    async def redact_async(self, text: str, session_id: str | None = None) -> RedactResponse:
        client = await self._get_async_client()
        payload: dict = {"text": text}
        if session_id:
            payload["session_id"] = session_id
        resp = await client.post("/redact", json=payload)
        resp.raise_for_status()
        return RedactResponse.model_validate(resp.json())

    async def find_decision_async(self, request: FindDecisionRequest) -> FindDecisionResponse:
        client = await self._get_async_client()
        resp = await client.post("/decisions/find", json=request.model_dump())
        resp.raise_for_status()
        return FindDecisionResponse.model_validate(resp.json())

    async def store_decision_async(self, request: StoreDecisionRequest) -> None:
        client = await self._get_async_client()
        resp = await client.post("/decisions/store", json=request.model_dump())
        resp.raise_for_status()

    async def close_async(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.aclose()

    # -- Sync interface --

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                base_url=self._base_url,
                headers=self._headers,
                timeout=self._timeout,
            )
        return self._sync_client

    def evaluate(self, request: EvaluateRequest) -> EvaluateResponse:
        client = self._get_sync_client()
        try:
            resp = client.post("/evaluate", json=request.model_dump())
            resp.raise_for_status()
            return EvaluateResponse.model_validate(resp.json())
        except httpx.ConnectError as exc:
            if self._fail_open:
                logger.warning("Tenet server unreachable (fail_open=True): %s", exc)
                return EvaluateResponse(
                    violations=[], has_violations=False, should_block=False,
                    processing_time_ms=0.0,
                )
            raise TenetConnectionError() from exc

    def health(self) -> HealthResponse:
        client = self._get_sync_client()
        resp = client.get("/health")
        resp.raise_for_status()
        return HealthResponse.model_validate(resp.json())

    def detect(self, text: str) -> DetectResponse:
        client = self._get_sync_client()
        resp = client.post("/detect", json={"text": text})
        resp.raise_for_status()
        return DetectResponse.model_validate(resp.json())

    def redact(self, text: str, session_id: str | None = None) -> RedactResponse:
        client = self._get_sync_client()
        payload: dict = {"text": text}
        if session_id:
            payload["session_id"] = session_id
        resp = client.post("/redact", json=payload)
        resp.raise_for_status()
        return RedactResponse.model_validate(resp.json())

    def find_decision(self, request: FindDecisionRequest) -> FindDecisionResponse:
        client = self._get_sync_client()
        resp = client.post("/decisions/find", json=request.model_dump())
        resp.raise_for_status()
        return FindDecisionResponse.model_validate(resp.json())

    def store_decision(self, request: StoreDecisionRequest) -> None:
        client = self._get_sync_client()
        resp = client.post("/decisions/store", json=request.model_dump())
        resp.raise_for_status()

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()
