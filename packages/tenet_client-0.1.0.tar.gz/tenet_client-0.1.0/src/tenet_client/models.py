"""Pydantic models mirroring the Tenet server's /evaluate API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class EvaluateRequest(BaseModel):
    """Request body for POST /evaluate."""

    tool_name: str = ""  # Empty for agent-level scans (input/output phases)
    tool_input: dict | str = {}
    tool_output: dict | str | None = None
    phase: str = "pre"  # "pre" | "post" | "input" | "output"
    session_id: str | None = None
    metadata: dict = Field(default_factory=dict)
    tenet_ids: list[str] | None = None
    trace_id: str | None = None
    parent_span_id: str | None = None


class Violation(BaseModel):
    """A single rule violation returned by /evaluate."""

    rule_id: str
    rule_name: str
    tenet_id: str
    severity: str  # "info" | "warning" | "error" | "critical"
    action: str  # "warn" | "block" | "redact" | "log"
    message: str
    details: dict = Field(default_factory=dict)


class EvaluateResponse(BaseModel):
    """Response body from POST /evaluate."""

    violations: list[Violation]
    has_violations: bool
    should_block: bool
    redacted_input: str | None = None
    processing_time_ms: float
    pii_entities: list[dict] = Field(default_factory=list)
    trace_id: str | None = None
    span_id: str | None = None


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    uptime_seconds: float
    error: str | None = None


class DetectResponse(BaseModel):
    entities: list[dict]
    has_pii: bool
    processing_time_ms: float


class RedactResponse(BaseModel):
    redacted_text: str
    entities: list[dict]
    replacements: dict[str, str]
    has_pii: bool
    processing_time_ms: float
    record_id: str | None = None


# ---------------------------------------------------------------------------
# Decision memory models (HITL integration)
# ---------------------------------------------------------------------------


class FindDecisionRequest(BaseModel):
    """Request body for POST /decisions/find."""

    entity_type: str
    hook_type: str
    tool_context: str = ""
    confidence_band: str = "medium"
    prompt_category: str = "general"
    session_id: str = ""
    fail_open: bool = True


class FindDecisionResponse(BaseModel):
    """Response from POST /decisions/find."""

    action: str | None = None
    source: str | None = None  # "session" | "persistent" | "tenet_default"


class StoreDecisionRequest(BaseModel):
    """Request body for POST /decisions/store."""

    entity_type: str
    hook_type: str
    tool_context: str = ""
    confidence_band: str = "medium"
    prompt_category: str = "general"
    action: str  # DecisionAction value
    tier: str  # "session" | "persistent"
    session_id: str = ""
