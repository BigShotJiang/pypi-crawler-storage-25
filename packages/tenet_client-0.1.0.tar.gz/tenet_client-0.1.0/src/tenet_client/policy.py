"""Framework-agnostic policy/verdict/action/context types.

The cloud judge produces a *verdict*; the application's *policy* decides
the runtime *action*. Splitting these — modeled loosely on Galileo
Protect's stage/action distinction — lets developers own the runtime
behavior (block, review, override, escalate, fail-open) instead of
inheriting the SDK's defaults.

These types intentionally live in ``tenet-client`` (not
``tenet-langchain``) so non-LangChain consumers — custom agents,
FastAPI middleware, queue workers — can build on the same vocabulary.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, ClassVar, Literal, get_args

from pydantic import BaseModel, Field

from tenet_client.cloud_models import CloudJudgeResponse

JudgePhase = Literal["agent_input", "tool_pre", "tool_post", "agent_output"]
JudgeDecision = Literal["allow", "review", "block"]
JudgeStatus = Literal["ok", "triggered", "paused", "timeout", "error", "unavailable"]
JudgeSeverity = Literal["low", "medium", "high", "critical"]
JudgeResolutionStatus = Literal["resolved", "unresolved", "error"]

# RFC-008 §4.4.5 default English template for retry-nudge guidance. Used
# by `JudgeAction.retry_nudge_from_verdict` when the caller does not pass
# a custom template.
_DEFAULT_RETRY_NUDGE_TEMPLATE = (
    "Cannot proceed as requested: {reason}\n"
    "Suggested correction: {safe_message_or_reason}"
)
_DEFAULT_RETRY_NUDGE_FALLBACK = "Please reconsider this tool call."
JudgeActionKind = Literal[
    "allow",
    "block",
    "tool_error",
    "override_input",
    "override_output",
    "raise_error",
    "human_review",
    "retry_nudge",
]


class JudgeVerdict(BaseModel):
    """A judge's evaluation of a single phase.

    Superset of :class:`CloudJudgeResponse` that adds ``review`` to the
    decision space, an operational ``status`` (so policy callbacks can
    distinguish ``triggered`` from ``timeout``/``error``/``unavailable``),
    plus optional ``severity``, ``safe_message``, and structured
    ``findings``. The cloud's binary ``allow|block`` collapses cleanly
    into this shape — see :meth:`from_cloud_response`.
    """

    decision: JudgeDecision
    status: JudgeStatus
    judge_id: str
    judge_version: str
    latency_ms: int
    severity: JudgeSeverity | None = None
    reason: str | None = None
    safe_message: str | None = None
    findings: list[dict[str, Any]] = Field(default_factory=list)
    # Optional verdict-side action hint (e.g. cloud says "override the
    # output with this safe string"). Policy still owns the runtime
    # decision; this is just data the policy may consult.
    action: dict[str, Any] | None = None

    # Native /eeo/decide verdict → policy decision mapping.
    # ``pass`` / ``include`` / ``fast_pass`` are the unambiguous allow set.
    # ``block`` is the only terminal-block verdict (UI shows dismiss-only).
    # Everything else reviewable (``route_to_human`` / ``defer`` /
    # ``exclude`` / ``include_with_caveats``) routes through ``on_review``
    # so the policy can choose interrupt / override / proceed.
    _NATIVE_ALLOW: ClassVar[frozenset[str]] = frozenset(
        {"pass", "include", "fast_pass"}
    )
    _NATIVE_REVIEW: ClassVar[frozenset[str]] = frozenset(
        {"route_to_human", "defer", "exclude", "include_with_caveats"}
    )
    _PUBLIC_SEVERITIES: ClassVar[frozenset[str]] = frozenset(get_args(JudgeSeverity))

    @classmethod
    def from_cloud_response(cls, resp: CloudJudgeResponse) -> JudgeVerdict:
        """Adapt a cloud response into a policy-side verdict.

        The native ``verdict`` field (RFC-008 §4.1) is the primary signal:
        reviewable outcomes like ``route_to_human`` route through
        ``on_review`` rather than collapsing into binary block. When the
        native verdict is absent, falls back to the binary ``decision``.

        Risk labels are promoted to ``findings`` so policy callbacks can
        branch on protected-class signals (e.g., EEO codes from the
        engine) without reaching into private cloud-response fields.
        """
        native = resp.verdict
        if native in cls._NATIVE_ALLOW:
            decision: JudgeDecision = "allow"
        elif native in cls._NATIVE_REVIEW:
            decision = "review"
        elif native == "block":
            decision = "block"
        else:
            # No native verdict (legacy or malformed): fall back to the
            # binary decision the cloud client synthesizes.
            decision = resp.decision  # type: ignore[assignment]

        status: JudgeStatus = "ok" if decision == "allow" else "triggered"

        # Severity from the native response (RFC-008 §4.1). Treat the
        # operator-only ``info`` value as "no severity" since it is not
        # part of the public JudgeSeverity vocabulary.
        severity: JudgeSeverity | None = None
        if resp.severity in cls._PUBLIC_SEVERITIES:
            severity = resp.severity  # type: ignore[assignment]

        # Promote risk labels into findings so policies can dispatch on
        # protected-class signals without poking at private cloud fields.
        findings: list[dict[str, Any]] = [
            {"rule_id": label} for label in resp.risk_labels if isinstance(label, str)
        ]

        return cls(
            decision=decision,
            status=status,
            judge_id=resp.judge_id,
            judge_version=resp.judge_version,
            latency_ms=resp.latency_ms,
            severity=severity,
            reason=resp.reason,
            findings=findings,
        )


@dataclass
class JudgeContext:
    """Context passed to policy callbacks.

    Carries the phase + identifiers + payloads, so a policy can branch
    on tool name (e.g. stricter for ``send_email``), phase (e.g. softer
    for ``tool_pre`` and harder for ``tool_post``), or any
    application-specific metadata it stuffed into ``metadata``.
    """

    phase: JudgePhase
    tool_name: str = ""
    tool_input: Any = None
    tool_output: Any = None
    session_id: str | None = None
    trace_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class JudgeAction:
    """A runtime action the policy returns from a callback.

    Framework-agnostic. The middleware/decorator translates each
    ``kind`` into framework-native effects (LangChain ``ToolMessage``,
    raised exception, replaced state, etc.).
    """

    kind: JudgeActionKind
    message: str | None = None
    payload: Any = None
    error: BaseException | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    # Populated only when kind == "retry_nudge"; required there, forbidden
    # elsewhere. The discriminated-union shape keeps the type honest.
    guidance: str | None = None

    def __post_init__(self) -> None:
        if self.kind == "retry_nudge":
            if not isinstance(self.guidance, str) or not self.guidance:
                raise ValueError(
                    "JudgeAction(kind='retry_nudge') requires a non-empty `guidance` string"
                )
        elif self.guidance is not None:
            raise ValueError(
                f"JudgeAction(kind={self.kind!r}) must not carry `guidance`; "
                "only retry_nudge uses that field"
            )

    # ----- factory constructors (clearer at call sites than kwargs) -----

    @classmethod
    def allow(cls, *, metadata: dict[str, Any] | None = None) -> JudgeAction:
        return cls(kind="allow", metadata=dict(metadata or {}))

    @classmethod
    def block(cls, *, message: str | None = None) -> JudgeAction:
        """Hard halt — terminates the agent / surface, not just the tool call."""
        return cls(kind="block", message=message)

    @classmethod
    def tool_error(cls, message: str) -> JudgeAction:
        """Return a ``ToolMessage(status="error")``-shaped failure to the agent.

        The agent stays running and may decide to ask the user, try a
        different tool, etc. This is the most common block-equivalent
        for tool-boundary middleware.
        """
        return cls(kind="tool_error", message=message)

    @classmethod
    def override_input(cls, payload: Any) -> JudgeAction:
        """Replace the tool's input with ``payload`` and run it."""
        return cls(kind="override_input", payload=payload)

    @classmethod
    def override_output(cls, payload: Any) -> JudgeAction:
        """Replace the tool's output with ``payload`` (post-execution)."""
        return cls(kind="override_output", payload=payload)

    @classmethod
    def raise_error(cls, error: BaseException) -> JudgeAction:
        """Re-raise ``error`` from the middleware (fail-closed default)."""
        return cls(kind="raise_error", error=error)

    @classmethod
    def human_review(cls, *, metadata: dict[str, Any] | None = None) -> JudgeAction:
        """Hand off to a human review queue (application-defined)."""
        return cls(kind="human_review", metadata=dict(metadata or {}))

    @classmethod
    def retry_nudge(
        cls, guidance: str, *, metadata: dict[str, Any] | None = None
    ) -> JudgeAction:
        """Feed corrective guidance back to the agent loop without
        terminating the tool call.

        The middleware translates this into a
        ``ToolMessage(status="error", content=guidance)`` injected into
        the agent's message list. The agent reads the corrective tool
        result on the next iteration and re-issues the tool call,
        typically with different arguments. This is the forge-research
        "retry nudge" mechanic (RFC-008 §4.4.5): step stays open, model
        self-corrects.

        Distinct from :meth:`tool_error` (which terminates the call) and
        from :meth:`override_output` (which replaces output with a fixed
        string).
        """
        return cls(kind="retry_nudge", guidance=guidance, metadata=dict(metadata or {}))

    @classmethod
    def retry_nudge_from_verdict(
        cls,
        verdict: JudgeVerdict,
        *,
        template: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> JudgeAction:
        """Assemble a ``retry_nudge`` from a verdict's ``reason`` +
        ``safe_message`` via the documented two-line template.

        Default template (English; localization tracked separately)::

            Cannot proceed as requested: {reason}
            Suggested correction: {safe_message_or_reason}

        When ``safe_message`` is missing, ``{safe_message_or_reason}``
        falls back to ``reason`` so the template line 2 stays well-formed.
        When ``reason`` is missing, we cannot fill the template at all
        and emit ``safe_message`` (or the static fallback) as plain
        guidance.
        """
        tmpl = template if template is not None else _DEFAULT_RETRY_NUDGE_TEMPLATE
        if verdict.reason:
            safe = verdict.safe_message or verdict.reason
            guidance = tmpl.format(reason=verdict.reason, safe_message_or_reason=safe)
        else:
            guidance = (
                verdict.safe_message or verdict.reason or _DEFAULT_RETRY_NUDGE_FALLBACK
            )
        return cls.retry_nudge(guidance, metadata=metadata)


# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------


_VerdictHandler = Callable[[JudgeContext, JudgeVerdict], JudgeAction]
_ErrorHandler = Callable[[JudgeContext, BaseException], JudgeAction]


def _default_on_allow(_ctx: JudgeContext, _v: JudgeVerdict) -> JudgeAction:
    return JudgeAction.allow()


def _default_on_review(_ctx: JudgeContext, _v: JudgeVerdict) -> JudgeAction:
    # Soft-allow with metadata so downstream code (callbacks, audit) can
    # see the verdict was a review without taking enforcement action.
    return JudgeAction.allow(metadata={"tenet_review": True})


def _default_on_block(_ctx: JudgeContext, v: JudgeVerdict) -> JudgeAction:
    msg = v.safe_message or "Blocked by Tenet compliance judge."
    if v.reason:
        msg = f"{msg} ({v.reason})"
    return JudgeAction.tool_error(msg)


def _default_on_unresolved(_ctx: JudgeContext, v: JudgeVerdict) -> JudgeAction:
    # Per RFC-008 §4.4.5: unresolved is rarely a compliance issue but is a
    # workflow-correction signal that often warrants a retry_nudge.
    return JudgeAction.retry_nudge_from_verdict(v)


def _default_on_unavailable(_ctx: JudgeContext, err: BaseException) -> JudgeAction:
    return JudgeAction.raise_error(err)


def _default_on_timeout(_ctx: JudgeContext, err: BaseException) -> JudgeAction:
    return JudgeAction.raise_error(err)


@dataclass
class JudgePolicy:
    """Maps verdicts and infrastructure failures to runtime actions.

    Every callback receives the full :class:`JudgeContext` so it can
    branch on phase, tool name, session, or metadata.

    Defaults are fail-closed:

    - ``allow`` → ``JudgeAction.allow()``
    - ``review`` → ``JudgeAction.allow(metadata={"tenet_review": True})``
    - ``block`` → ``JudgeAction.tool_error(safe_message + reason)``
    - ``unavailable`` / ``timeout`` → ``JudgeAction.raise_error(err)``

    Per-phase and per-tool overrides let developers compose stricter or
    softer behavior on a slice of the call surface — e.g. block
    ``send_email`` hard, allow ``search`` soft. Per-tool wins over
    per-phase when both match.
    """

    on_allow: _VerdictHandler = field(default=_default_on_allow)
    on_review: _VerdictHandler = field(default=_default_on_review)
    on_block: _VerdictHandler = field(default=_default_on_block)
    on_unresolved: _VerdictHandler = field(default=_default_on_unresolved)
    on_unavailable: _ErrorHandler = field(default=_default_on_unavailable)
    on_timeout: _ErrorHandler = field(default=_default_on_timeout)
    per_phase: dict[JudgePhase, JudgePolicy] = field(default_factory=dict)
    per_tool: dict[str, JudgePolicy] = field(default_factory=dict)

    # ----- dispatch -----

    def _resolve(self, ctx: JudgeContext) -> JudgePolicy:
        # per-tool wins over per-phase wins over self.
        if ctx.tool_name and ctx.tool_name in self.per_tool:
            return self.per_tool[ctx.tool_name]
        if ctx.phase in self.per_phase:
            return self.per_phase[ctx.phase]
        return self

    def decide(
        self,
        ctx: JudgeContext,
        verdict: JudgeVerdict,
        *,
        resolution_status: JudgeResolutionStatus | None = None,
    ) -> JudgeAction:
        """Pick an action for ``verdict`` in ``ctx``.

        When ``resolution_status == "unresolved"`` the policy routes
        through ``on_unresolved`` regardless of the verdict's decision —
        unresolved is a separate workflow-correction signal (RFC-008
        §4.4.5), not a compliance outcome. ``"resolved"`` and ``"error"``
        fall through to the normal decision dispatch; ``None`` preserves
        existing pre-Phase-4.5 behavior.
        """
        policy = self._resolve(ctx)
        if resolution_status == "unresolved":
            return policy.on_unresolved(ctx, verdict)
        if verdict.decision == "allow":
            return policy.on_allow(ctx, verdict)
        if verdict.decision == "review":
            return policy.on_review(ctx, verdict)
        if verdict.decision == "block":
            return policy.on_block(ctx, verdict)
        # The Literal narrows the input space, so this is unreachable
        # via the type checker; keep an explicit fallback to fail-closed
        # for any future decision we don't know how to handle.
        return JudgeAction.raise_error(
            ValueError(f"unknown verdict decision: {verdict.decision!r}")
        )

    def on_unavailable_action(
        self, ctx: JudgeContext, error: BaseException
    ) -> JudgeAction:
        """Action for ``JudgeUnavailableError`` and similar infrastructure failures."""
        return self._resolve(ctx).on_unavailable(ctx, error)

    def on_timeout_action(self, ctx: JudgeContext, error: BaseException) -> JudgeAction:
        """Action for explicit timeouts during evaluation."""
        return self._resolve(ctx).on_timeout(ctx, error)
