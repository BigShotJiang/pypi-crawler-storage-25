"""``@judged`` — gate any function with the Tenet cloud judge.

Framework-free wrapper around :class:`TenetCloudJudgeClient`. Drop the
decorator on a function and every call goes through the cloud judge
at ``tool_pre`` (before invocation) and ``tool_post`` (after the
function returns). On ``decision="block"`` the wrapper raises
:exc:`JudgeBlocked` instead of running / returning the function body.

Works on both sync and async functions; the wrapper auto-detects via
``inspect.iscoroutinefunction``. For LangChain agents, also exported
from :mod:`tenet_langchain` for convenience.

Example::

    from tenet_client import TenetCloudJudgeClient, judged

    judge = TenetCloudJudgeClient.from_env()

    @judged(judge)
    def get_patient_chart(patient_id: str) -> str:
        return _fetch_chart(patient_id)

    try:
        chart = get_patient_chart("MRN12345")
    except JudgeBlocked as e:
        log.warning("blocked: %s", e.reason)
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable

from tenet_client.cloud_client import TenetCloudJudgeClient
from tenet_client.cloud_models import CloudJudgeResponse, JudgeUnavailableError
from tenet_client.policy import JudgeContext, JudgePolicy, JudgeVerdict


class JudgeBlocked(Exception):
    """Raised by :func:`judged` when the cloud judge returns ``decision="block"``.

    Attributes:
        reason: The judge's explanation (``CloudJudgeResponse.reason``),
            may be ``None``.
        tool_name: Name sent to the judge (defaults to the wrapped
            function's ``__name__`` unless overridden).
        phase: Which phase blocked — ``"tool_pre"`` or ``"tool_post"``.
        judge_id: ID of the judge that produced the verdict.
    """

    def __init__(
        self,
        reason: str | None,
        *,
        tool_name: str,
        phase: str,
        judge_id: str,
    ) -> None:
        self.reason = reason
        self.tool_name = tool_name
        self.phase = phase
        self.judge_id = judge_id
        msg = f"Tenet judge '{judge_id}' blocked {phase} on '{tool_name}'"
        if reason:
            msg = f"{msg}: {reason}"
        super().__init__(msg)


def _default_input_builder(
    sig: inspect.Signature, args: tuple[Any, ...], kwargs: dict[str, Any]
) -> dict[str, Any]:
    """Bind the call's positional + keyword args back to parameter names."""
    try:
        bound = sig.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        return dict(bound.arguments)
    except TypeError:
        return {"args": list(args), "kwargs": dict(kwargs)}


def _coerce_output(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool, list, dict)):
        return value
    return str(value)


def judged(
    client: TenetCloudJudgeClient,
    *,
    tool_name: str | None = None,
    check_pre: bool = True,
    check_post: bool = True,
    fail_open: bool = False,
    policy: JudgePolicy | None = None,
    input_builder: Callable[..., Any] | None = None,
    output_builder: Callable[[Any], Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Gate a function via the Tenet cloud judge.

    Args:
        client: A :class:`TenetCloudJudgeClient` (typically a singleton
            constructed once per process).
        tool_name: Override the name sent to the judge. Defaults to
            ``func.__name__``.
        check_pre, check_post: Toggle the ``tool_pre`` / ``tool_post``
            judge calls. Both default to ``True``.
        fail_open: On :exc:`JudgeUnavailableError`, swallow + proceed.
            Default ``False`` (fail-closed: re-raise). Use ``True`` for
            dev environments where transient cloud errors should not
            block the call path. Ignored when ``policy`` is set — the
            policy's ``on_unavailable`` callback wins.
        policy: A :class:`JudgePolicy` to dispatch verdicts to actions.
            When set, the legacy hard-coded behavior (raise
            :exc:`JudgeBlocked` on block, raise on unavailable when not
            ``fail_open``) is replaced by policy callbacks. ``allow``
            and ``human_review`` actions let the wrapped function run
            and its return value through; ``override_output`` replaces
            the return value; ``tool_error`` / ``block`` raise
            :exc:`JudgeBlocked`; ``raise_error`` re-raises the action's
            error. ``override_input`` is not supported here — use the
            ``input_builder`` arg instead.
        input_builder: ``(*args, **kwargs) -> Any`` — override how the
            function's arguments map to ``tool_input``. Default binds
            args to parameter names via :mod:`inspect`.
        output_builder: ``(return_value) -> Any`` — override the
            ``tool_post`` payload built from the function's return.
            Default coerces non-JSON-natural types via ``str()``.
        metadata: Static metadata appended to every judge call.

    Raises:
        JudgeBlocked: When the judge returns ``decision="block"``.
        JudgeUnavailableError: When the judge cloud is unreachable and
            ``fail_open=False``.
    """
    if not (check_pre or check_post):
        raise ValueError("at least one of check_pre / check_post must be True")

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        sig = inspect.signature(func)
        name = tool_name or getattr(func, "__name__", "<anonymous>")
        is_async = inspect.iscoroutinefunction(func)

        def _build_input(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
            if input_builder is not None:
                return input_builder(*args, **kwargs)
            return _default_input_builder(sig, args, kwargs)

        def _build_output(value: Any) -> Any:
            if output_builder is not None:
                return output_builder(value)
            return _coerce_output(value)

        def _check_block(verdict: CloudJudgeResponse, phase: str) -> None:
            if verdict.decision == "block":
                raise JudgeBlocked(
                    verdict.reason,
                    tool_name=name,
                    phase=phase,
                    judge_id=verdict.judge_id,
                )

        # Sentinel returned by _apply_policy to signal "no override —
        # continue with the wrapped function's return value".
        _CONTINUE = object()

        def _ctx_for(phase: str, tool_input: Any, tool_output: Any = None) -> JudgeContext:
            return JudgeContext(
                phase=phase,  # type: ignore[arg-type]
                tool_name=name,
                tool_input=tool_input,
                tool_output=tool_output,
                metadata=metadata or {},
            )

        def _apply_policy_verdict(
            verdict: CloudJudgeResponse,
            ctx: JudgeContext,
        ) -> Any:
            """Dispatch a successful verdict through the policy.

            Returns ``_CONTINUE`` to keep the wrapped function's
            value, an arbitrary replacement value (``override_output``),
            or raises :exc:`JudgeBlocked` / the policy's error.
            """
            assert policy is not None
            judge_verdict = JudgeVerdict.from_cloud_response(verdict)
            action = policy.decide(ctx, judge_verdict)
            return _act_on(action, verdict, ctx.phase)

        def _apply_policy_unavailable(
            err: JudgeUnavailableError, ctx: JudgeContext
        ) -> Any:
            assert policy is not None
            action = policy.on_unavailable_action(ctx, err)
            return _act_on(action, None, ctx.phase, err=err)

        def _act_on(
            action: Any,
            verdict: CloudJudgeResponse | None,
            phase: str,
            err: BaseException | None = None,
        ) -> Any:
            if action.kind in ("allow", "human_review"):
                return _CONTINUE
            if action.kind == "override_output":
                return action.payload
            if action.kind in ("tool_error", "block"):
                raise JudgeBlocked(
                    action.message or (verdict.reason if verdict else None),
                    tool_name=name,
                    phase=phase,
                    judge_id=verdict.judge_id if verdict else "",
                )
            if action.kind == "raise_error":
                raise action.error or (err or RuntimeError("policy raised"))
            if action.kind == "override_input":
                raise ValueError(
                    "JudgeAction.override_input is not supported in @judged; "
                    "use the input_builder argument instead"
                )
            return _CONTINUE

        if is_async:

            @functools.wraps(func)
            async def awrapper(*args: Any, **kwargs: Any) -> Any:
                tool_input = _build_input(args, kwargs)

                if check_pre:
                    ctx = _ctx_for("tool_pre", tool_input)
                    try:
                        verdict = await client.evaluate_async(
                            phase="tool_pre",
                            tool_name=name,
                            tool_input=tool_input,
                            metadata=metadata,
                        )
                    except JudgeUnavailableError as err:
                        if policy is not None:
                            outcome = _apply_policy_unavailable(err, ctx)
                            if outcome is not _CONTINUE:
                                # override_output at pre is unusual but
                                # honored — replaces the function's
                                # return without running it.
                                return outcome
                        elif not fail_open:
                            raise
                    else:
                        if policy is not None:
                            outcome = _apply_policy_verdict(verdict, ctx)
                            if outcome is not _CONTINUE:
                                return outcome
                        else:
                            _check_block(verdict, "tool_pre")

                result = await func(*args, **kwargs)

                if check_post:
                    ctx = _ctx_for("tool_post", tool_input, _build_output(result))
                    try:
                        verdict = await client.evaluate_async(
                            phase="tool_post",
                            tool_name=name,
                            tool_input=tool_input,
                            tool_output=_build_output(result),
                            metadata=metadata,
                        )
                    except JudgeUnavailableError as err:
                        if policy is not None:
                            outcome = _apply_policy_unavailable(err, ctx)
                            if outcome is not _CONTINUE:
                                return outcome
                        elif not fail_open:
                            raise
                    else:
                        if policy is not None:
                            outcome = _apply_policy_verdict(verdict, ctx)
                            if outcome is not _CONTINUE:
                                return outcome
                        else:
                            _check_block(verdict, "tool_post")

                return result

            return awrapper

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            tool_input = _build_input(args, kwargs)

            if check_pre:
                ctx = _ctx_for("tool_pre", tool_input)
                try:
                    verdict = client.evaluate(
                        phase="tool_pre",
                        tool_name=name,
                        tool_input=tool_input,
                        metadata=metadata,
                    )
                except JudgeUnavailableError as err:
                    if policy is not None:
                        outcome = _apply_policy_unavailable(err, ctx)
                        if outcome is not _CONTINUE:
                            return outcome
                    elif not fail_open:
                        raise
                else:
                    if policy is not None:
                        outcome = _apply_policy_verdict(verdict, ctx)
                        if outcome is not _CONTINUE:
                            return outcome
                    else:
                        _check_block(verdict, "tool_pre")

            result = func(*args, **kwargs)

            if check_post:
                ctx = _ctx_for("tool_post", tool_input, _build_output(result))
                try:
                    verdict = client.evaluate(
                        phase="tool_post",
                        tool_name=name,
                        tool_input=tool_input,
                        tool_output=_build_output(result),
                        metadata=metadata,
                    )
                except JudgeUnavailableError as err:
                    if policy is not None:
                        outcome = _apply_policy_unavailable(err, ctx)
                        if outcome is not _CONTINUE:
                            return outcome
                    elif not fail_open:
                        raise
                else:
                    if policy is not None:
                        outcome = _apply_policy_verdict(verdict, ctx)
                        if outcome is not _CONTINUE:
                            return outcome
                    else:
                        _check_block(verdict, "tool_post")

            return result

        return wrapper

    return decorator
