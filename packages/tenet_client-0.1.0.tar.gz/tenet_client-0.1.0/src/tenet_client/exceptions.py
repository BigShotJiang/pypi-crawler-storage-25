"""Exceptions for tenet-langchain."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tenet_client.models import Violation


class TenetViolationError(Exception):
    """Raised when a tenet rule violation requires blocking an action.

    Raised inside LangChain callbacks to prevent tool execution.
    The agent or caller can catch this to handle the violation
    (e.g., retry with different input, notify user).
    """

    def __init__(self, message: str, violations: list[Violation] | None = None):
        super().__init__(message)
        self.violations = violations or []


class TenetConnectionError(Exception):
    """Raised when the Tenet server is unreachable."""

    def __init__(self, message: str = "Tenet server is unreachable"):
        super().__init__(message)
