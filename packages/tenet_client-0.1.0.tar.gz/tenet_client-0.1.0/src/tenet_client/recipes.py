"""Policy recipe factories — partner-configurable presets.

These are not the policy types themselves (those live in ``policy.py``).
They are factory functions that bake in the canonical, forge-research-
informed defaults from RFC-008 §4.4.5 so callers can wire a sensible
policy with one line and tune from there.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from tenet_client.policy import (
    JudgeAction,
    JudgeContext,
    JudgePolicy,
    JudgeSeverity,
    JudgeVerdict,
)

_DEFAULT_RETRY_NUDGE_SEVERITIES: tuple[JudgeSeverity, ...] = ("low", "medium")
_DEFAULT_TOOL_ERROR_SEVERITIES: tuple[JudgeSeverity, ...] = ("high", "critical")


def severity_routed_policy(
    *,
    retry_nudge_severities: Iterable[JudgeSeverity] = _DEFAULT_RETRY_NUDGE_SEVERITIES,
    tool_error_severities: Iterable[JudgeSeverity] = _DEFAULT_TOOL_ERROR_SEVERITIES,
    human_review_severities: Iterable[JudgeSeverity] = (),
    **policy_kwargs: Any,
) -> JudgePolicy:
    """Build a JudgePolicy whose ``on_block`` routes by verdict severity.

    Default mapping (RFC-008 §4.4.5 forge-informed recommendation):

    - ``low`` / ``medium`` → ``JudgeAction.retry_nudge_from_verdict(verdict)``
    - ``high`` / ``critical`` → ``JudgeAction.tool_error(safe_message + reason)``
    - Missing severity → ``tool_error`` (matches pre-Phase-4.5 default)

    Override any of the three buckets via the keyword arguments;
    ``human_review_severities`` is empty by default and, when populated,
    takes precedence over the tool_error bucket so an opt-in escalation
    path wins.

    Any additional ``JudgePolicy`` fields (``on_unresolved``,
    ``on_unavailable``, ``per_tool``, etc.) can be passed through via
    ``**policy_kwargs``.
    """
    retry_set = frozenset(retry_nudge_severities)
    error_set = frozenset(tool_error_severities)
    review_set = frozenset(human_review_severities)

    def on_block(_ctx: JudgeContext, verdict: JudgeVerdict) -> JudgeAction:
        sev = verdict.severity
        if sev in review_set:
            return JudgeAction.human_review(metadata={"severity": sev})
        if sev in retry_set:
            return JudgeAction.retry_nudge_from_verdict(verdict)
        # Anything else — including `None` and the tool_error bucket —
        # collapses to tool_error with the safe_message/reason composed
        # the same way the default JudgePolicy on_block does.
        _ = error_set  # documented bucket; default-path fallthrough covers it
        msg = verdict.safe_message or "Blocked by Tenet compliance judge."
        if verdict.reason:
            msg = f"{msg} ({verdict.reason})"
        return JudgeAction.tool_error(msg)

    return JudgePolicy(on_block=on_block, **policy_kwargs)
