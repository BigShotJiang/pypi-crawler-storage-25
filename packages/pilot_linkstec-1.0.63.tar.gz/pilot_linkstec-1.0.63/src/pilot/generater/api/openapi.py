import os
import threading
from typing import Dict, Any, Optional

from openai import OpenAI

# 既存の基盤クラスをインポート
from pilot.generater.ai_base import AIBase
from pilot.generater.generation_config import GenerationConfigDTO


class OpenAIAISingleton(AIBase):
    """
    OpenAI 互換API (DeepSeek等) 向けの Singleton クラス
    """
    _instance: Optional['OpenAIAISingleton'] = None
    _lock = threading.Lock()

    def __new__(cls, model_name: str = "deepseek-chat", base_url: str = "https://api.deepseek.com"):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(OpenAIAISingleton, cls).__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self, model_name: str = "deepseek-chat", base_url: str = "https://api.deepseek.com"):
        if not self._initialized:
            with self._lock:
                if not self._initialized:
                    self.model_name = model_name
                    self.base_url = base_url

                    self.api_key = os.environ.get("DEEPSEEK_API_KEY")
                    if not self.api_key:
                        raise ValueError("環境変数 'DEEPSEEK_API_KEY' が設定されていません。")

                    self.client = OpenAI(
                        api_key=self.api_key,
                        base_url=self.base_url
                    )

                    self._initialized = True

    def _build_generation_config(self, gen_config: GenerationConfigDTO) -> Dict[str, Any]:
        config: Dict[str, Any] = {
            "temperature": gen_config.temperature,
        }
        if gen_config.max_output_tokens is not None:
            config["max_tokens"] = gen_config.max_output_tokens
        
        # DeepSeek reasoner model might use thinking_budget
        # if gen_config.thinking_budget is not None:
        #     config["max_tokens"] = gen_config.thinking_budget

        return {k: v for k, v in config.items() if v is not None}

    def generate_content(
            self,
            prompt: str,
            gen_config: Optional[GenerationConfigDTO] = None,
            stream: Optional[bool] = None,
            base_url: Optional[str] = None,
            model: Optional[str] = None,
            **kwargs
    ) -> Dict[str, Any]:
        try:
            if gen_config is None:
                gen_config = GenerationConfigDTO()

            is_stream = stream if stream is not None else gen_config.stream

            messages = []
            if gen_config.system_instruction:
                messages.append({"role": "system", "content": gen_config.system_instruction})
            messages.append({"role": "user", "content": prompt})

            api_kwargs = self._build_generation_config(gen_config)
            if kwargs:
                api_kwargs.update(kwargs)

            req_model = model if model else self.model_name

            if base_url:
                client_to_use = OpenAI(
                    api_key=self.api_key,
                    base_url=base_url
                )
            else:
                client_to_use = self.client

            response = client_to_use.chat.completions.create(
                model=req_model,
                messages=messages,
                stream=is_stream,
                timeout=gen_config.timeout,
                **api_kwargs
            )

            if is_stream:
                full_content = ""
                for chunk in response:
                    if chunk.choices and chunk.choices[0].delta.content:
                        full_content += chunk.choices[0].delta.content

                return {
                    "prompt": prompt,
                    "response": self._remove_code_fence(full_content),
                    "success": True,
                    "error": None
                }
            else:
                content = response.choices[0].message.content

                return {
                    "prompt": prompt,
                    "response": self._remove_code_fence(content),
                    "success": True,
                    "error": None
                }

        except Exception as e:
            return {"prompt": prompt, "response": None, "success": False, "error": str(e)}

    def start_chat(self):
        return _OpenAIChatSession(self)

    def count_tokens(self, text: str) -> int:
        return len(text) // 3

    def _remove_code_fence(self, text: str) -> str:
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        return "\n".join(lines)

    @classmethod
    def get_instance(cls, model_name: str = "deepseek-chat", base_url: str = "https://api.deepseek.com") -> 'OpenAIAISingleton':
        return cls(model_name, base_url)


class _OpenAIChatSession:
    def __init__(self, client: OpenAIAISingleton):
        self._client = client
        self._messages = []

    def send_message(
            self,
            message: str,
            gen_config: Optional[GenerationConfigDTO] = None,
            stream: Optional[bool] = None,
            **kwargs
    ):
        if gen_config is None:
            gen_config = GenerationConfigDTO()

        is_stream = stream if stream is not None else gen_config.stream

        if not self._messages and gen_config.system_instruction:
            self._messages.append({"role": "system", "content": gen_config.system_instruction})

        self._messages.append({"role": "user", "content": message})

        api_kwargs = self._client._build_generation_config(gen_config)

        response = self._client.client.chat.completions.create(
            model=self._client.model_name,
            messages=self._messages,
            stream=is_stream,
            timeout=gen_config.timeout,
            **api_kwargs
        )

        full_reply = ""

        if is_stream:
            for chunk in response:
                if chunk.choices and chunk.choices[0].delta.content:
                    full_reply += chunk.choices[0].delta.content
        else:
            full_reply = response.choices[0].message.content

        # ローカルのチャット履歴には追加
        self._messages.append({"role": "assistant", "content": full_reply})

        class _Resp:
            def __init__(self, text):
                self.text = text

        return _Resp(full_reply)
