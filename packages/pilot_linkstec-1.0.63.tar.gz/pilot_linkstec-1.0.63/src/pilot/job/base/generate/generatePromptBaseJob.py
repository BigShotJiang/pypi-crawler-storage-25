import json
import os
import pathlib
import re
from typing import Mapping, Optional

from pilot.job.impl.base_job import BaseJob

class GeneratePromptBaseJob(BaseJob):
    prompt_file_path: str = None
    template_file_path:list = []
    prompt_content: str
    result_content: str
    result_file_path: str
    replace_map  = {
    }

    def run(self):
        if self.prompt_file_path is None:
            self.prompt_file_path = self.get_new_extension_file_path(self.file_path, 'prompt')
        cwd = os.getcwd()
        self.template_file_path.insert(0, cwd)
        template = os.path.join(*self.template_file_path)
        self.process_file(template, self.prompt_file_path, self.replace_map)
        super().run()

    def load_text(self,file_path: str | pathlib.Path) -> str:
        """讀取檔案內容，返回 Unicode 字串。"""
        path = pathlib.Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {path}")
        return path.read_text(encoding='utf-8')

    def replace_by_map(self,
        text: str,
        replace_map: Mapping[str, str],
        *,
        use_regex: bool = False,
        case_sensitive: bool = True,
    ) -> str:

        if not replace_map:
            return text

        # 若使用正則，先把所有 pattern 編譯好，提高效能
        if use_regex:
            flags = 0 if case_sensitive else re.IGNORECASE
            compiled = [(re.compile(p, flags), repl) for p, repl in replace_map.items()]
            for pattern, repl in compiled:
                text = pattern.sub(repl, text)
        else:
            # 直接使用 str.replace，速度最快
            for old, new in replace_map.items():

                text = text.replace(old, new)

        return text

    def save_text(self,
        file_path: str | pathlib.Path,
        text: str,
        *,
        encoding: Optional[str] = None,
    ) -> None:

        path = pathlib.Path(file_path)
        if not path.parent.exists():
            path.parent.mkdir(parents=True, exist_ok=True)

        enc = encoding or "utf-8"
        path.write_text(text, encoding=enc)

    def process_file(self,
        src_path: str | pathlib.Path,
        dst_path: Optional[str | pathlib.Path] = None,
        replace_map: Optional[Mapping[str, str]] = None,
        *,
        use_regex: bool = False,
        case_sensitive: bool = True,
    ) -> None:

        original = self.load_text(src_path)

        if replace_map:
            new_text = self.replace_by_map(
                original,
                replace_map,
                use_regex=use_regex,
                case_sensitive=case_sensitive,
            )
        else:
            new_text = original

        target = dst_path if dst_path is not None else src_path
        self.save_text(target, new_text)