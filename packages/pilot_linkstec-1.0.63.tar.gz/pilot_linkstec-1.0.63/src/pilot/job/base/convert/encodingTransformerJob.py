import subprocess
import sys

from pilot.job.impl.base_job import BaseJob


class EncodingTransformerJob(BaseJob):
    def nkf_convert(self, file_path, nkf_args):
        """
        nkf を使ってファイルの文字コード変換を行う

        :param file_path: 変換対象のファイルパス
        :param nkf_args: nkf に渡す引数のリスト（例: ['-w']）
        """
        cmd = ['nkf32'] + nkf_args + [file_path]

        try:
            # nkfを実行し標準出力を取得
            result = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True
            )
            print(f"nkfの実行完了しました: {file_path}")
            # nkfの変換結果（バイト列）を返す
            return result.stdout

        except subprocess.CalledProcessError as e:
            print(f"nkfの実行でエラーが発生しました: {e.stderr.decode()}", file=sys.stderr)
            raise

    def run(self):
        nkf_args = ['-w', '--overwrite']
        self.nkf_convert(self.file_path, nkf_args)
        super().run()