from typing import get_type_hints, get_origin, get_args, Union, List

def _extract_model_class(return_type):
    """解析 DAO 方法的返回值类型，提取最底层的实体类"""
    if return_type is type(None):
        return None
    origin = get_origin(return_type)
    if origin is list or origin is List:
        args = get_args(return_type)
        return args[0] if args else None
    if origin is Union:
        args = get_args(return_type)
        actual_types = [t for t in args if t is not type(None)]
        return actual_types[0] if actual_types else None
    return return_type

class MapperProxy:
    """动态代理：拦截接口调用并转化为底层 SQL 执行"""
    def __init__(self, session, dao_class):
        self.session = session
        self.dao_class = dao_class
        self.namespace = dao_class.__name__

    def __getattr__(self, method_name: str):
        if not hasattr(self.dao_class, method_name):
            raise AttributeError(f"[{self.namespace}] 接口中未定义方法: {method_name}")

        statement_id = f"{self.namespace}.{method_name}"
        if statement_id not in self.session.sql_registry:
            raise AttributeError(f"未找到对应的 XML SQL 映射: {statement_id}")

        statement_info = self.session.sql_registry[statement_id]
        sql_type = statement_info["type"]

        # 1. 读取 Type Hints 并提取真实的 Model 类
        method_reference = getattr(self.dao_class, method_name)
        raw_return_type = get_type_hints(method_reference).get('return')
        model_class = _extract_model_class(raw_return_type)
        is_list_return = get_origin(raw_return_type) in (list, List)

        def method_executor(**kwargs):
            if sql_type == "select":
                if is_list_return:
                    return self.session.select_list(statement_id, kwargs, model_class)
                else:
                    return self.session.select_one(statement_id, kwargs, model_class)
            elif sql_type in ("insert", "update", "delete"):
                return self.session.execute_update(statement_id, kwargs)

        return method_executor