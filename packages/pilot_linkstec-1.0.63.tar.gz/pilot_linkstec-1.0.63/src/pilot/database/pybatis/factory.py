import xml.etree.ElementTree as ET
import os
from .session import SqlSession


class SqlSessionFactory:
    """核心工厂：解析全局 XML，管理多数据源"""

    def __init__(self, config_path: str):
        self.environments = {}
        self.default_env = None
        self.base_dir = os.path.dirname(os.path.abspath(config_path))
        self._parse_config(config_path)

    def _parse_config(self, config_path: str):
        tree = ET.parse(config_path)
        root = tree.getroot()
        envs_node = root.find("environments")

        if envs_node is not None:
            self.default_env = envs_node.get("default")
            for env_node in envs_node.findall("environment"):
                env_id = env_node.get("id")

                ds_node = env_node.find("dataSource")
                db_type = ds_node.get("type", "sqlite")
                db_url = ""

                for prop in ds_node.findall("property"):
                    if prop.get("name") == "url":
                        db_url = prop.get("value")
                        if db_type == "sqlite" and db_url != ":memory:":
                            db_url = os.path.join(self.base_dir, db_url)

                mapper_paths = []
                mappers_node = env_node.find("mappers")
                if mappers_node is not None:
                    for mapper in mappers_node.findall("mapper"):
                        m_path = os.path.join(self.base_dir, mapper.get("resource"))
                        mapper_paths.append(m_path)

                self.environments[env_id] = {
                    "db_type": db_type,
                    "db_url": db_url,
                    "mapper_paths": mapper_paths
                }

    def open_session(self, env_id: str) -> SqlSession:
        if env_id not in self.environments:
            raise ValueError(f"未找到环境配置: {env_id}")
        env_config = self.environments[env_id]
        return SqlSession(
            db_type=env_config["db_type"],
            db_url=env_config["db_url"],
            mapper_paths=env_config["mapper_paths"]
        )