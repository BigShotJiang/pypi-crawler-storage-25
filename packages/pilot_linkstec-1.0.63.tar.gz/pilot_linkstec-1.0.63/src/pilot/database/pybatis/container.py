from .factory import SqlSessionFactory


class MyBatisContainer:
    """通用依赖注入容器：一键管理多数据源和自动路由"""

    def __init__(self, config_path: str):
        self.factory = SqlSessionFactory(config_path=config_path)
        self.sessions = {}

        # 默认只开启 default 配置的环境
        target_env = self.factory.default_env
        if target_env:
            self.sessions[target_env] = self.factory.open_session(target_env)

    def get_dao(self, dao_class):
        namespace = dao_class.__name__
        for session in self.sessions.values():
            if session.has_namespace(namespace):
                return session.get_mapper(dao_class)
        raise ValueError(f"装配失败：没有数据库配置挂载 Mapper [{namespace}]")

    def close_all(self):
        for session in self.sessions.values():
            session.close()