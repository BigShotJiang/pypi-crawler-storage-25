import xml.etree.ElementTree as ET
import re
from .proxy import MapperProxy


class SqlSession:
    """数据库会话层：管理连接适配、SQL 加载和方言转换"""

    def __init__(self, db_type: str, db_url: str, mapper_paths: list):
        self.db_type = db_type
        self.registered_namespaces = set()
        self.conn = self._create_connection(db_type, db_url)
        self.sql_registry = {}
        self._load_mappers(mapper_paths)

    def _create_connection(self, db_type: str, db_url: str):
        if db_type == "sqlite":
            import sqlite3
            conn = sqlite3.connect(db_url)
            conn.row_factory = sqlite3.Row
            return conn
        elif db_type == "postgresql":
            import psycopg
            from psycopg.rows import dict_row
            conn = psycopg.connect(db_url, row_factory=dict_row)
            return conn
        else:
            raise ValueError(f"暂不支持该数据库类型: {db_type}")

    def _load_mappers(self, mapper_paths: list):
        for path in mapper_paths:
            tree = ET.parse(path)
            root = tree.getroot()
            namespace = root.attrib.get("namespace")
            self.registered_namespaces.add(namespace)

            for child in root:
                sql_id = f"{namespace}.{child.attrib.get('id')}"
                raw_sql = child.text.strip()

                # 【方言转换】统一 #{name} 转换为底层驱动需要的占位符
                if self.db_type == "sqlite":
                    formatted_sql = re.sub(r'#\{(\w+)\}', r':\1', raw_sql)
                elif self.db_type == "postgresql":
                    formatted_sql = re.sub(r'#\{(\w+)\}', r'%(\1)s', raw_sql)
                else:
                    formatted_sql = raw_sql

                self.sql_registry[sql_id] = {
                    "type": child.tag,
                    "sql": formatted_sql
                }

    def has_namespace(self, namespace: str) -> bool:
        return namespace in self.registered_namespaces

    def _map_result(self, row, model_class):
        if not model_class or not row:
            return row
        if model_class in (int, str, float, bool):
            return list(row.values())[0]
        return model_class(**dict(row))

    def select_one(self, statement_id: str, params: dict = None, model_class=None):
        statement = self.sql_registry.get(statement_id)
        cursor = self.conn.cursor()
        cursor.execute(statement["sql"], params or {})
        row = cursor.fetchone()
        row_dict = dict(row) if row else None
        return self._map_result(row_dict, model_class)

    def select_list(self, statement_id: str, params: dict = None, model_class=None):
        statement = self.sql_registry.get(statement_id)
        cursor = self.conn.cursor()
        cursor.execute(statement["sql"], params or {})
        rows = cursor.fetchall()
        return [self._map_result(dict(row), model_class) for row in rows]

    def execute_update(self, statement_id: str, params: dict = None):
        statement = self.sql_registry.get(statement_id)
        cursor = self.conn.cursor()
        cursor.execute(statement["sql"], params or {})
        self.conn.commit()
        return getattr(cursor, 'lastrowid', 0)

    def close(self):
        self.conn.close()

    def get_mapper(self, dao_class):
        return MapperProxy(self, dao_class)