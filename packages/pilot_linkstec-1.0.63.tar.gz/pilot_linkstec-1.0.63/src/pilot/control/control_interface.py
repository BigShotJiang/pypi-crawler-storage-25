from abc import ABC, abstractmethod

class ControlInterface(ABC):
    @abstractmethod
    def run(self):
        pass

    @abstractmethod
    def copy_result_files_to_next_control(self, from_configfile: str, to_configfile: str):
        pass

    @abstractmethod
    def copy_result_files_to_next_control_without_delete(self, from_configfile: str, to_configfile: str):
        pass
