import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
from pilot.job.impl.base_job import BaseJob


class Job(BaseJob):
    # __init__ は省略。BaseJobのものを継承。

    def run(self):
        super().run()
""").strip()
