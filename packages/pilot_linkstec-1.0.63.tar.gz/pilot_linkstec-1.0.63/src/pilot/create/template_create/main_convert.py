import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
import time
import os
import sys

from {{CONTROLLER_PACKAGE}} import Controller


# 現在のファイルのディレクトリ を基準に src フォルダのパスを取得し、sys.path の先頭に追加
project_root = os.path.dirname(os.path.abspath(__file__))
src_path = os.path.join(project_root, 'src')
if src_path not in sys.path:
    sys.path.insert(0, src_path)


if __name__ == '__main__':
    start = time.time()
    CobolController = Controller()
    CobolController.run("{{PYTHON_CONFIG_PROPERTIES}}")
    end = time.time()
    print(f"処理時間: {end - start:.2f}秒")
""").strip()
