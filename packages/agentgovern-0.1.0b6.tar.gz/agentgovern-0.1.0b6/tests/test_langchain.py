"""Unit tests for AgentGovernCallbackHandler (STORY-011)."""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from agentgovern.client import AgentGovernClient
from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler
from agentgovern.types import ActionStatus, ActionType


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------


def _make_handler(agent_id: str = "test-agent") -> tuple[AgentGovernCallbackHandler, MagicMock]:
    """Build a handler with a mock client (no real HTTP calls)."""
    mock_client = MagicMock(spec=AgentGovernClient)
    handler = AgentGovernCallbackHandler(client=mock_client, agent_external_id=agent_id)
    return handler, mock_client


# ---------------------------------------------------------------------------
# Tool events
# ---------------------------------------------------------------------------


class TestToolEvents:
    def test_on_tool_start_records_started_action(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()
        parent_run_id = uuid4()

        handler.on_tool_start(
            {"name": "web_search"},
            "query: capital of France",
            run_id=run_id,
            parent_run_id=parent_run_id,
        )

        mock_client.track_action.assert_called_once()
        args, kwargs = mock_client.track_action.call_args
        assert args[1] == ActionType.TOOL_CALL
        assert args[2] == "web_search"
        assert kwargs["status"] == ActionStatus.STARTED
        assert kwargs["trace_id"] == str(parent_run_id)
        assert kwargs["span_id"] == str(run_id)

    def test_on_tool_end_records_completed_with_duration(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()

        # Seed run info as on_tool_start would
        handler._runs[str(run_id)] = {
            "start_time": time.monotonic() - 0.1,  # 100ms ago
            "tool_name": "web_search",
            "trace_id": "trace-123",
        }

        handler.on_tool_end("Paris", run_id=run_id)

        args, kwargs = mock_client.track_action.call_args
        assert args[1] == ActionType.TOOL_CALL
        assert kwargs["status"] == ActionStatus.COMPLETED
        assert kwargs["duration_ms"] is not None
        assert kwargs["duration_ms"] >= 90
        assert kwargs["trace_id"] == "trace-123"

    def test_on_tool_error_records_failed_status(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "tool_name": "web_search",
            "trace_id": "trace-abc",
        }

        handler.on_tool_error(RuntimeError("timeout"), run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["status"] == ActionStatus.FAILED
        assert "error" in kwargs["metadata"]

    def test_on_tool_end_clears_run_state(self) -> None:
        handler, _ = _make_handler()
        run_id = uuid4()
        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "tool_name": "tool",
            "trace_id": "t",
        }

        handler.on_tool_end("result", run_id=run_id)

        assert str(run_id) not in handler._runs

    def test_trace_id_consistent_across_start_and_end(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()
        parent_run_id = uuid4()

        handler.on_tool_start(
            {"name": "db_query"}, "SELECT *", run_id=run_id, parent_run_id=parent_run_id
        )
        handler.on_tool_end("row data", run_id=run_id)

        calls = mock_client.track_action.call_args_list
        assert len(calls) == 2
        trace_start = calls[0][1]["trace_id"]
        trace_end = calls[1][1]["trace_id"]
        assert trace_start == trace_end == str(parent_run_id)


# ---------------------------------------------------------------------------
# LLM events
# ---------------------------------------------------------------------------


class TestLLMEvents:
    def test_on_llm_start_records_message_started(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()
        parent_run_id = uuid4()

        handler.on_llm_start(
            {"id": ["langchain", "chat_models", "openai", "gpt-4o"]},
            ["What is 2+2?"],
            run_id=run_id,
            parent_run_id=parent_run_id,
        )

        args, kwargs = mock_client.track_action.call_args
        assert args[1] == ActionType.MESSAGE
        assert args[2] == "llm/gpt-4o"
        assert kwargs["status"] == ActionStatus.STARTED
        assert kwargs["model_id"] == "gpt-4o"

    def test_on_llm_end_records_token_count(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": "trace-xyz",
        }

        mock_response = MagicMock()
        mock_response.llm_output = {"token_usage": {"total_tokens": 42}}

        handler.on_llm_end(mock_response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["status"] == ActionStatus.COMPLETED
        assert kwargs["token_count"] == 42

    def test_on_llm_error_records_failed_with_error(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": "trace-xyz",
        }

        handler.on_llm_error(RuntimeError("rate limit"), run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["status"] == ActionStatus.FAILED
        assert "error" in kwargs["metadata"]

    def test_on_llm_end_without_token_usage_does_not_raise(self) -> None:
        handler, mock_client = _make_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "claude-3",
            "trace_id": "t",
        }

        mock_response = MagicMock()
        mock_response.llm_output = {}

        # Must not raise
        handler.on_llm_end(mock_response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["status"] == ActionStatus.COMPLETED
