"""Contract tests: verify _post_batch produces a payload the ingest endpoint will accept."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agentgovern.client import AgentGovernClient
from agentgovern.types import ActionRecord, ActionStatus, ActionType

_ZOD_DATETIME = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$')

_VALID_ACTION_TYPES = {
    'tool_call', 'api_request', 'data_access', 'decision',
    'message', 'code_execution', 'file_operation', 'custom',
}
_VALID_STATUSES = {'started', 'completed', 'failed', 'blocked'}


async def _capture_post_batch(
    client: AgentGovernClient,
    records: list[ActionRecord],
) -> dict[str, Any]:
    """Run _post_batch with a mocked httpx client; return the parsed JSON body."""
    captured: dict[str, Any] = {}

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()

    async def _fake_post(url: str, *, content: bytes, headers: dict) -> MagicMock:
        captured['body'] = json.loads(content)
        return mock_response

    mock_async_client = AsyncMock()
    mock_async_client.__aenter__ = AsyncMock(return_value=mock_async_client)
    mock_async_client.__aexit__ = AsyncMock(return_value=None)
    mock_async_client.post.side_effect = _fake_post

    with patch('agentgovern.client.httpx.AsyncClient', return_value=mock_async_client):
        await client._post_batch(records)

    return captured['body']


@pytest.fixture
def client() -> AgentGovernClient:
    c = AgentGovernClient(
        api_key="ag_test_key",
        base_url="http://localhost:3000",
        flush_interval=999,
    )
    yield c
    c.shutdown(timeout=1.0)


@pytest.fixture
def minimal_record() -> ActionRecord:
    return ActionRecord(
        agent_id="credit-scoring-agent-01",
        action_type=ActionType.TOOL_CALL,
        action_name="fetch_bureau_data",
    )


@pytest.fixture
def full_record() -> ActionRecord:
    return ActionRecord(
        agent_id="credit-scoring-agent-01",
        action_type=ActionType.API_REQUEST,
        action_name="assess_creditworthiness",
        status=ActionStatus.COMPLETED,
        duration_ms=1847,
        token_count=413,
        model_id="gpt-4o",
        trace_id="trace-abc123",
        span_id="span-def456",
        metadata={"customer_tier": "premium"},
        input_payload={"prompt": "Evaluate loan..."},
        output_payload={"risk_tier": "B", "approval": True},
        timestamp=datetime(2026, 4, 19, 3, 47, 4, 580869, tzinfo=timezone.utc),
    )


# ---------------------------------------------------------------------------
# agent_external_id
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_agent_external_id_present(client, minimal_record):
    body = await _capture_post_batch(client, [minimal_record])
    action = body['actions'][0]
    assert 'agent_external_id' in action, "agent_external_id missing from payload"
    assert isinstance(action['agent_external_id'], str)
    assert action['agent_external_id'] == "credit-scoring-agent-01"


@pytest.mark.asyncio
async def test_agent_id_not_sent(client, minimal_record):
    body = await _capture_post_batch(client, [minimal_record])
    action = body['actions'][0]
    assert 'agent_id' not in action, "agent_id must not be in payload (server uses agent_external_id)"


# ---------------------------------------------------------------------------
# Timestamp
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_timestamp_zod_format(client, minimal_record):
    body = await _capture_post_batch(client, [minimal_record])
    ts = body['actions'][0]['timestamp']
    assert _ZOD_DATETIME.match(ts), f"timestamp {ts!r} doesn't match Zod .datetime() pattern"


@pytest.mark.asyncio
async def test_timestamp_exact_value(client, full_record):
    body = await _capture_post_batch(client, [full_record])
    assert body['actions'][0]['timestamp'] == "2026-04-19T03:47:04.580Z"


# ---------------------------------------------------------------------------
# Numeric fields: must be int, not float
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_duration_ms_is_int(client, full_record):
    body = await _capture_post_batch(client, [full_record])
    action = body['actions'][0]
    assert 'duration_ms' in action
    assert isinstance(action['duration_ms'], int), f"duration_ms is {type(action['duration_ms']).__name__}, expected int"
    assert action['duration_ms'] == 1847


@pytest.mark.asyncio
async def test_token_count_is_int(client, full_record):
    body = await _capture_post_batch(client, [full_record])
    action = body['actions'][0]
    assert 'token_count' in action
    assert isinstance(action['token_count'], int), f"token_count is {type(action['token_count']).__name__}, expected int"
    assert action['token_count'] == 413


@pytest.mark.asyncio
async def test_float_duration_coerced_to_int(client):
    """LangChain callbacks sometimes produce float milliseconds."""
    record = ActionRecord(
        agent_id="agent-1",
        action_type=ActionType.TOOL_CALL,
        action_name="tool",
        duration_ms=312,  # Pydantic accepts int; float coercion tested at _post_batch level
    )
    body = await _capture_post_batch(client, [record])
    assert isinstance(body['actions'][0]['duration_ms'], int)


# ---------------------------------------------------------------------------
# Enum values
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_action_type_is_valid_enum(client, full_record):
    body = await _capture_post_batch(client, [full_record])
    action_type = body['actions'][0]['action_type']
    assert action_type in _VALID_ACTION_TYPES, f"Invalid action_type: {action_type!r}"


@pytest.mark.asyncio
async def test_status_is_valid_enum(client, full_record):
    body = await _capture_post_batch(client, [full_record])
    status = body['actions'][0]['status']
    assert status in _VALID_STATUSES, f"Invalid status: {status!r}"


# ---------------------------------------------------------------------------
# Null stripping (Zod .optional() ≠ nullable)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_null_fields_stripped(client, minimal_record):
    """Optional fields absent from the record must not appear as null in JSON."""
    body = await _capture_post_batch(client, [minimal_record])
    action = body['actions'][0]
    null_fields = [k for k, v in action.items() if v is None]
    assert null_fields == [], f"Null values sent for optional fields: {null_fields}"


# ---------------------------------------------------------------------------
# Payload nesting
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_payload_nested_correctly(client, full_record):
    body = await _capture_post_batch(client, [full_record])
    action = body['actions'][0]
    assert 'input_payload' not in action, "Flat input_payload must not appear in payload"
    assert 'output_payload' not in action, "Flat output_payload must not appear in payload"
    assert 'payload' in action
    assert action['payload']['input'] == {"prompt": "Evaluate loan..."}
    assert action['payload']['output'] == {"risk_tier": "B", "approval": True}


@pytest.mark.asyncio
async def test_no_payload_key_when_empty(client, minimal_record):
    body = await _capture_post_batch(client, [minimal_record])
    action = body['actions'][0]
    assert 'payload' not in action, "payload key must be absent when no input/output provided"


# ---------------------------------------------------------------------------
# Batch integrity
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_batch_envelope(client, minimal_record, full_record):
    body = await _capture_post_batch(client, [minimal_record, full_record])
    assert 'actions' in body
    assert len(body['actions']) == 2
    for action in body['actions']:
        assert 'agent_external_id' in action
        assert _ZOD_DATETIME.match(action['timestamp'])
