"""Tests for instrument_langchain() agent binding resolution."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

import agentgovern
from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler


@pytest.fixture(autouse=True)
def reset_module_state():
    """Reset SDK module-level state before each test."""
    agentgovern._client = None
    agentgovern._last_registered_agent = None
    yield
    agentgovern._client = None
    agentgovern._last_registered_agent = None


@pytest.fixture
def initialized_client():
    """Init the SDK with a mock client that no-ops register_agent."""
    mock_client = MagicMock()
    mock_client.register_agent = MagicMock()
    with patch('agentgovern.AgentGovernClient', return_value=mock_client):
        agentgovern.init(api_key="ag_test_key", base_url="http://localhost:3000")
    return mock_client


# ---------------------------------------------------------------------------
# Error: no agent registered, no arg passed
# ---------------------------------------------------------------------------

def test_raises_when_no_agent_registered_and_no_arg_passed(initialized_client):
    with pytest.raises(RuntimeError, match="instrument_langchain\\(\\) requires an agent_external_id"):
        agentgovern.instrument_langchain()


def test_error_message_mentions_register_agent(initialized_client):
    with pytest.raises(RuntimeError) as exc_info:
        agentgovern.instrument_langchain()
    assert "register_agent" in str(exc_info.value)


def test_error_message_mentions_explicit_arg(initialized_client):
    with pytest.raises(RuntimeError) as exc_info:
        agentgovern.instrument_langchain()
    assert "instrument_langchain('my-agent-id')" in str(exc_info.value)


def test_raises_before_init_too():
    """Should raise about init() missing, not agent_external_id."""
    with pytest.raises(RuntimeError, match="agentgovern.init\\(\\)"):
        agentgovern.instrument_langchain()


# ---------------------------------------------------------------------------
# Uses last registered agent when no arg passed
# ---------------------------------------------------------------------------

def test_uses_last_registered_agent_when_no_arg_passed(initialized_client):
    agentgovern.register_agent("credit-scoring-v2", name="Credit Scoring")
    handler = agentgovern.instrument_langchain()
    assert isinstance(handler, AgentGovernCallbackHandler)
    assert handler._agent_id == "credit-scoring-v2"


def test_last_registered_agent_set_after_register(initialized_client):
    assert agentgovern._last_registered_agent is None
    agentgovern.register_agent("my-agent", name="My Agent")
    assert agentgovern._last_registered_agent == "my-agent"


# ---------------------------------------------------------------------------
# Explicit arg overrides last registered
# ---------------------------------------------------------------------------

def test_explicit_arg_overrides_last_registered(initialized_client):
    agentgovern.register_agent("registered-agent", name="Registered")
    handler = agentgovern.instrument_langchain("explicit-agent")
    assert handler._agent_id == "explicit-agent"
    # last_registered_agent unchanged
    assert agentgovern._last_registered_agent == "registered-agent"


def test_explicit_arg_works_without_any_registration(initialized_client):
    handler = agentgovern.instrument_langchain("standalone-agent")
    assert handler._agent_id == "standalone-agent"


# ---------------------------------------------------------------------------
# Multiple register_agent calls — most recent wins
# ---------------------------------------------------------------------------

def test_multiple_register_agent_calls_use_most_recent(initialized_client):
    agentgovern.register_agent("agent-v1", name="Agent V1")
    agentgovern.register_agent("agent-v2", name="Agent V2")
    agentgovern.register_agent("agent-v3", name="Agent V3")
    handler = agentgovern.instrument_langchain()
    assert handler._agent_id == "agent-v3"


def test_two_handlers_can_bind_to_different_agents(initialized_client):
    handler_a = agentgovern.instrument_langchain("agent-a")
    handler_b = agentgovern.instrument_langchain("agent-b")
    assert handler_a._agent_id == "agent-a"
    assert handler_b._agent_id == "agent-b"


# ---------------------------------------------------------------------------
# AgentGovernCallbackHandler directly — must reject None/empty agent_id
# ---------------------------------------------------------------------------

def test_handler_raises_on_none_agent_id(initialized_client):
    with pytest.raises(ValueError, match="agent_external_id"):
        AgentGovernCallbackHandler(client=initialized_client, agent_external_id=None)


def test_handler_raises_on_empty_string_agent_id(initialized_client):
    with pytest.raises(ValueError, match="agent_external_id"):
        AgentGovernCallbackHandler(client=initialized_client, agent_external_id="")


def test_handler_accepts_valid_agent_id(initialized_client):
    handler = AgentGovernCallbackHandler(client=initialized_client, agent_external_id="my-agent")
    assert handler._agent_id == "my-agent"
