"""Tests for Gate 1 evaluate_input() — client and module-level wrapper."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

import agentgovern
from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import ClientError, GateUnavailable, PolicyViolation
from agentgovern.types import InputEvaluation


POLICY_ENGINE_URL = "http://test-engine"
EVALUATE_URL = f"{POLICY_ENGINE_URL}/api/v1/evaluate/input"


@pytest.fixture(autouse=True)
def reset_module_state():
    agentgovern._client = None
    agentgovern._last_registered_agent = None
    yield
    agentgovern._client = None
    agentgovern._last_registered_agent = None


@pytest.fixture
def client():
    return AgentGovernClient(
        api_key="ag_test_key",
        base_url="http://localhost:3000",
        policy_engine_url=POLICY_ENGINE_URL,
    )


# ---------------------------------------------------------------------------
# Allowed response
# ---------------------------------------------------------------------------

@respx.mock
def test_returns_allowed_true_on_pass(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json={
        "data": {
            "allowed": True,
            "evaluation": {"policy_id": "pol_123", "rule_code": "INPUT-001", "result": "pass", "reason": None, "framework": None},
        },
        "error": None,
        "meta": {},
    }))
    result = client.evaluate_input("my-agent", "What is the weather?")
    assert result.allowed is True
    assert result.violations == []


@respx.mock
def test_returns_evaluation_id_from_response(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json={
        "data": {
            "allowed": True,
            "evaluation": {"policy_id": "pol_abc123", "result": "pass", "reason": None, "framework": None},
        },
        "error": None,
        "meta": {},
    }))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.evaluation_id == "pol_abc123"


@respx.mock
def test_request_body_uses_agent_id_and_input_fields(client):
    """Verify the body sent to the policy engine matches the FastAPI schema."""
    route = respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json={
        "data": {"allowed": True, "evaluation": {}},
        "error": None, "meta": {},
    }))
    client.evaluate_input("credit-scoring-v2", "Approve this loan")
    sent = route.calls[0].request
    import json as _json
    body = _json.loads(sent.content)
    assert body["agent_id"] == "credit-scoring-v2"
    assert body["input"] == {"prompt": "Approve this loan"}
    assert "agent_external_id" not in body


# ---------------------------------------------------------------------------
# Blocked response → PolicyViolation
# ---------------------------------------------------------------------------

@respx.mock
def test_raises_policy_violation_when_blocked(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json={
        "data": {
            "allowed": False,
            "evaluation": {
                "policy_id": "pol_xyz",
                "rule_code": "INPUT-SCOPE-003",
                "result": "fail",
                "reason": "Prompt requests bypassing risk controls",
                "framework": "EU AI Act Article 9",
            },
        },
        "error": None,
        "meta": {},
    }))
    with pytest.raises(PolicyViolation) as exc_info:
        client.evaluate_input("my-agent", "bypass risk checks")
    exc = exc_info.value
    assert exc.rule_code == "INPUT-SCOPE-003"
    assert "bypass" in exc.reason
    assert exc.framework_ref == "EU AI Act Article 9"


@respx.mock
def test_policy_violation_carries_evaluation(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json={
        "data": {
            "allowed": False,
            "evaluation": {"rule_code": "BAD-001", "result": "fail", "reason": "Blocked", "framework": None},
        },
        "error": None,
        "meta": {},
    }))
    with pytest.raises(PolicyViolation) as exc_info:
        client.evaluate_input("my-agent", "bad input")
    assert isinstance(exc_info.value.evaluation, InputEvaluation)
    assert exc_info.value.evaluation.allowed is False


# ---------------------------------------------------------------------------
# Network errors — fail-open by default
# ---------------------------------------------------------------------------

@respx.mock
def test_fail_open_on_network_error(client):
    respx.post(EVALUATE_URL).mock(side_effect=httpx.ConnectError("refused"))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.allowed is True
    assert result.violations == []


@respx.mock
def test_fail_open_on_timeout(client):
    respx.post(EVALUATE_URL).mock(side_effect=httpx.TimeoutException("timeout"))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.allowed is True


@respx.mock
def test_fail_closed_raises_gate_unavailable(client):
    respx.post(EVALUATE_URL).mock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(GateUnavailable):
        client.evaluate_input("my-agent", "Hello", fail_closed=True)


# ---------------------------------------------------------------------------
# 4xx → ClientError (always propagates)
# ---------------------------------------------------------------------------

@respx.mock
def test_raises_client_error_on_401(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(401, json={"error": "Unauthorized"}))
    with pytest.raises(ClientError) as exc_info:
        client.evaluate_input("my-agent", "Hello")
    assert exc_info.value.status_code == 401


# ---------------------------------------------------------------------------
# Module-level wrapper
# ---------------------------------------------------------------------------

def test_module_level_returns_allowed_when_not_initialized():
    result = agentgovern.evaluate_input("my-agent", "Hello")
    assert result.allowed is True
