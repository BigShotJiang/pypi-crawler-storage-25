"""Unit tests for AgentGovernClient (STORY-010)."""

from __future__ import annotations

import asyncio
import sys
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agentgovern.client import AgentGovernClient, _BUFFER_MAXLEN, _WARN_AFTER_FAILURES
from agentgovern.types import ActionStatus, ActionType


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def client() -> AgentGovernClient:
    """Client instance with networking patched out."""
    c = AgentGovernClient(
        api_key="ag_test_key",
        environment="development",
        base_url="http://localhost:3000",
        flush_interval=999,  # disable auto-flush during tests
    )
    yield c
    c.shutdown(timeout=2.0)


# ---------------------------------------------------------------------------
# track_action — buffer behavior
# ---------------------------------------------------------------------------


def test_track_action_appends_to_buffer(client: AgentGovernClient) -> None:
    client.track_action(
        "agent-1",
        ActionType.TOOL_CALL,
        "web_search",
    )
    assert len(client._buffer) == 1


def test_track_action_never_raises_on_bad_input(client: AgentGovernClient) -> None:
    # Passing a completely invalid action_type should not raise
    client.track_action(
        "agent-1",
        "NOT_A_VALID_TYPE",  # type: ignore[arg-type]
        "web_search",
    )
    # No exception raised — buffer may or may not contain entry (Pydantic may reject)


def test_track_action_is_fast(client: AgentGovernClient) -> None:
    """track_action must complete in well under 5ms."""
    start = time.perf_counter()
    for _ in range(1000):
        client.track_action("agent-1", ActionType.TOOL_CALL, "bench_tool")
    elapsed_ms = (time.perf_counter() - start) * 1000
    # 1000 track_action calls should complete in < 500ms (avg < 0.5ms each)
    assert elapsed_ms < 500, f"track_action too slow: {elapsed_ms:.1f}ms for 1000 calls"


def test_buffer_capped_at_max_length(client: AgentGovernClient) -> None:
    for i in range(_BUFFER_MAXLEN + 500):
        client.track_action("agent-1", ActionType.TOOL_CALL, f"tool_{i}")
    assert len(client._buffer) == _BUFFER_MAXLEN


# ---------------------------------------------------------------------------
# Flush — success path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_flush_clears_buffer(client: AgentGovernClient) -> None:
    for _ in range(5):
        client.track_action("agent-1", ActionType.TOOL_CALL, "tool")

    with patch.object(client, "_post_batch", new_callable=AsyncMock) as mock_post:
        await client._flush()

    assert len(client._buffer) == 0
    mock_post.assert_called_once()


@pytest.mark.asyncio
async def test_flush_resets_consecutive_failures_on_success(
    client: AgentGovernClient,
) -> None:
    client._consecutive_failures = 5
    client.track_action("agent-1", ActionType.TOOL_CALL, "tool")

    with patch.object(client, "_post_batch", new_callable=AsyncMock):
        await client._flush()

    assert client._consecutive_failures == 0


@pytest.mark.asyncio
async def test_flush_noop_when_buffer_empty(client: AgentGovernClient) -> None:
    with patch.object(client, "_post_batch", new_callable=AsyncMock) as mock_post:
        await client._flush()

    mock_post.assert_not_called()


# ---------------------------------------------------------------------------
# Flush — failure + retry
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_flush_increments_consecutive_failures_on_error(
    client: AgentGovernClient,
) -> None:
    client.track_action("agent-1", ActionType.TOOL_CALL, "tool")

    with patch.object(
        client, "_post_batch", new_callable=AsyncMock, side_effect=Exception("network error")
    ):
        with patch("asyncio.sleep", new_callable=AsyncMock):
            await client._flush()

    assert client._consecutive_failures >= 1


@pytest.mark.asyncio
async def test_flush_prints_warning_after_threshold_failures(
    client: AgentGovernClient, capsys: pytest.CaptureFixture[str]
) -> None:
    client._consecutive_failures = _WARN_AFTER_FAILURES - 1
    client.track_action("agent-1", ActionType.TOOL_CALL, "tool")

    with patch.object(
        client, "_post_batch", new_callable=AsyncMock, side_effect=Exception("down")
    ):
        with patch("asyncio.sleep", new_callable=AsyncMock):
            await client._flush()

    captured = capsys.readouterr()
    assert "WARNING" in captured.err


@pytest.mark.asyncio
async def test_flush_does_not_raise_even_when_all_retries_fail(
    client: AgentGovernClient,
) -> None:
    client.track_action("agent-1", ActionType.TOOL_CALL, "tool")

    with patch.object(
        client, "_post_batch", new_callable=AsyncMock, side_effect=RuntimeError("fatal")
    ):
        with patch("asyncio.sleep", new_callable=AsyncMock):
            # Must not raise
            await client._flush()


# ---------------------------------------------------------------------------
# Batch size trigger
# ---------------------------------------------------------------------------


def test_early_flush_triggered_when_batch_size_reached(
    client: AgentGovernClient,
) -> None:
    triggered: list[bool] = []
    original = client._trigger_flush

    def spy_trigger():
        triggered.append(True)
        original()

    client._trigger_flush = spy_trigger
    client.batch_size = 3

    # Fill to batch_size
    for _ in range(3):
        client.track_action("agent-1", ActionType.TOOL_CALL, "tool")

    assert len(triggered) >= 1


# ---------------------------------------------------------------------------
# Heartbeat — fail-open
# ---------------------------------------------------------------------------


def test_heartbeat_returns_error_dict_on_failure(client: AgentGovernClient) -> None:
    with patch("httpx.Client") as mock_client_class:
        mock_client_class.return_value.__enter__.return_value.post.side_effect = (
            Exception("connection refused")
        )
        result = client.heartbeat()

    assert result == {"status": "error"}


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------


def test_status_reflects_buffer_size(client: AgentGovernClient) -> None:
    client.track_action("agent-1", ActionType.TOOL_CALL, "tool")
    s = client.status()
    assert s["buffer_size"] == 1
    assert s["environment"] == "development"
    assert s["initialized"] is True
