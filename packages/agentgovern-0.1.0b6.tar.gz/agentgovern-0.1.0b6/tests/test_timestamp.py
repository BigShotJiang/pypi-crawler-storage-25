"""Tests for _iso_timestamp_utc — the Zod-compatible timestamp helper."""

from __future__ import annotations

import re
from datetime import datetime, timezone

import pytest

from agentgovern.client import _iso_timestamp_utc

# Zod .datetime() pattern: YYYY-MM-DDTHH:MM:SS.mmmZ (exactly 3 fractional digits, Z suffix)
_ZOD_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$')


def test_output_ends_with_Z() -> None:
    result = _iso_timestamp_utc()
    assert result.endswith('Z'), f"Expected Z suffix, got: {result!r}"


def test_exactly_three_fractional_digits() -> None:
    result = _iso_timestamp_utc()
    assert _ZOD_PATTERN.match(result), f"Timestamp doesn't match Zod pattern: {result!r}"


def test_matches_zod_datetime_pattern_100_times() -> None:
    """Millisecond truncation must hold at all microsecond values."""
    import time
    for _ in range(100):
        result = _iso_timestamp_utc()
        assert _ZOD_PATTERN.match(result), f"Failed Zod pattern: {result!r}"
        time.sleep(0.001)


def test_naive_datetime_treated_as_utc() -> None:
    naive = datetime(2026, 4, 19, 3, 47, 4, 580869)
    result = _iso_timestamp_utc(naive)
    assert result == "2026-04-19T03:47:04.580Z"


def test_utc_datetime_correct_value() -> None:
    dt = datetime(2026, 4, 19, 3, 47, 4, 580869, tzinfo=timezone.utc)
    result = _iso_timestamp_utc(dt)
    assert result == "2026-04-19T03:47:04.580Z"


def test_microseconds_truncated_to_milliseconds() -> None:
    # 999 microseconds → 0 ms (truncation, not rounding)
    dt = datetime(2026, 1, 1, 0, 0, 0, 999, tzinfo=timezone.utc)
    assert _iso_timestamp_utc(dt) == "2026-01-01T00:00:00.000Z"

    # 1000 microseconds → 1 ms
    dt = datetime(2026, 1, 1, 0, 0, 0, 1000, tzinfo=timezone.utc)
    assert _iso_timestamp_utc(dt) == "2026-01-01T00:00:00.001Z"

    # 999999 microseconds → 999 ms
    dt = datetime(2026, 1, 1, 0, 0, 0, 999999, tzinfo=timezone.utc)
    assert _iso_timestamp_utc(dt) == "2026-01-01T00:00:00.999Z"


def test_non_utc_timezone_converted_to_utc() -> None:
    from datetime import timedelta
    eastern = timezone(timedelta(hours=-5))
    dt = datetime(2026, 4, 19, 0, 0, 0, 0, tzinfo=eastern)  # midnight ET = 05:00 UTC
    result = _iso_timestamp_utc(dt)
    assert result == "2026-04-19T05:00:00.000Z"


def test_round_trips_through_fromisoformat() -> None:
    """Strip Z, add +00:00, parse back — should equal the original UTC datetime."""
    dt_original = datetime(2026, 4, 19, 3, 47, 4, 580000, tzinfo=timezone.utc)
    result = _iso_timestamp_utc(dt_original)

    # Simulate what a consumer would do to parse it back
    parsed = datetime.fromisoformat(result.replace('Z', '+00:00'))
    assert parsed == datetime(2026, 4, 19, 3, 47, 4, 580000, tzinfo=timezone.utc)


def test_no_plus_offset_in_output() -> None:
    dt = datetime(2026, 4, 19, 12, 0, 0, tzinfo=timezone.utc)
    result = _iso_timestamp_utc(dt)
    assert '+' not in result, f"Found offset in output: {result!r}"
    assert result.endswith('Z')
