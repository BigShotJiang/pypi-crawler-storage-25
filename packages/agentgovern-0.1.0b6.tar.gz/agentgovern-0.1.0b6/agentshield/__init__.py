"""
AgentShield SDK — Compliance instrumentation for agentic AI workflows.

Quickstart:
    import agentshield
    agentshield.init(api_key="as_live_...")

Full implementation in Phase 2 (STORY-010 through STORY-015).
"""

from agentshield.client import AgentShieldClient

_client: AgentShieldClient | None = None


def init(
    api_key: str,
    *,
    environment: str = "production",
    agent_id: str | None = None,
    base_url: str = "https://api.agentshield.ai",
    fail_silently: bool = True,
) -> AgentShieldClient:
    """
    Initialize the AgentShield SDK.

    The SDK is designed to never break the customer's agent.
    If AgentShield is unreachable, actions are queued locally and retried.
    If fail_silently=True (default), all errors are swallowed.
    """
    global _client  # noqa: PLW0603
    _client = AgentShieldClient(
        api_key=api_key,
        environment=environment,
        agent_id=agent_id,
        base_url=base_url,
        fail_silently=fail_silently,
    )
    return _client


def status() -> dict[str, object]:
    """Return SDK health status."""
    if _client is None:
        return {"initialized": False}
    return _client.status()


__all__ = ["init", "status", "AgentShieldClient"]
