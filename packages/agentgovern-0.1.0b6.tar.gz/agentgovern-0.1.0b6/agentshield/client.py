"""AgentShield HTTP client with batching, retry, and silent-fail guarantees."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("agentshield")


class AgentShieldClient:
    """
    HTTP client for the AgentShield ingest API.

    Design constraints (CLAUDE.md):
    - SDK overhead per action < 5ms
    - If AgentShield is down, the SDK fails silently — the agent continues
    - Actions are batched and sent async to minimize latency impact

    Full implementation in Phase 2 (STORY-010).
    """

    def __init__(
        self,
        api_key: str,
        *,
        environment: str = "production",
        agent_id: str | None = None,
        base_url: str = "https://api.agentshield.ai",
        fail_silently: bool = True,
        batch_size: int = 100,
        flush_interval_ms: int = 1000,
    ) -> None:
        self.api_key = api_key
        self.environment = environment
        self.agent_id = agent_id
        self.base_url = base_url.rstrip("/")
        self.fail_silently = fail_silently
        self.batch_size = batch_size
        self.flush_interval_ms = flush_interval_ms
        self._initialized = True

        logger.debug(
            "AgentShield SDK initialized (environment=%s, agent_id=%s)",
            environment,
            agent_id,
        )

    def status(self) -> dict[str, Any]:
        return {
            "initialized": self._initialized,
            "environment": self.environment,
            "agent_id": self.agent_id,
            "base_url": self.base_url,
        }

    # Full methods (track, flush, register_agent, heartbeat) implemented in Phase 2
