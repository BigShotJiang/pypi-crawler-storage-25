"""Pydantic models for AgentShield SDK action payloads and agent registration."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class Environment(str, Enum):
    PRODUCTION = "production"
    STAGING = "staging"
    DEVELOPMENT = "development"


class ActionType(str, Enum):
    TOOL_CALL = "tool_call"
    API_REQUEST = "api_request"
    DATA_ACCESS = "data_access"
    DECISION = "decision"
    MESSAGE = "message"
    CODE_EXECUTION = "code_execution"
    FILE_OPERATION = "file_operation"
    CUSTOM = "custom"


class ActionStatus(str, Enum):
    STARTED = "started"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class AgentRegistration(BaseModel):
    """Payload for explicit agent registration (STORY-012)."""

    external_id: str = Field(..., description="Your internal identifier for this agent")
    name: str
    description: str | None = None
    framework: str = "custom"
    framework_version: str | None = None
    environment: Environment = Environment.PRODUCTION
    owner_email: str | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ActionRecord(BaseModel):
    """A single agent action to be ingested (STORY-010)."""

    agent_id: str
    action_type: ActionType
    action_name: str
    status: ActionStatus = ActionStatus.COMPLETED
    duration_ms: int | None = None
    model_id: str | None = None
    token_count: int | None = None
    trace_id: str | None = None
    span_id: str | None = None
    parent_action_id: UUID | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    # Full payload (optional — increases ingest payload size)
    input_payload: dict[str, Any] | None = None
    output_payload: dict[str, Any] | None = None
    reasoning_chain: dict[str, Any] | None = None


class BatchIngestRequest(BaseModel):
    """Batch of actions for the ingest endpoint."""

    actions: list[ActionRecord] = Field(..., min_length=1, max_length=1000)
    agent_id: str | None = None  # Override per-action agent_id if all same


class IngestResponse(BaseModel):
    """Response from POST /v1/ingest/actions."""

    accepted: int
    rejected: int
    batch_id: str
