"""AgentGovern SDK exceptions."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agentgovern.types import InputEvaluation


class PolicyViolation(Exception):
    """
    Raised by Gate 1 when enforcement_mode=enforce and the input is blocked.

    Gate 2 (async ingest) never raises — it fails silently per the fail-open guarantee.
    """

    def __init__(self, evaluation: "InputEvaluation") -> None:
        first = evaluation.violations[0] if evaluation.violations else None
        msg = first.reason if first else "Input blocked by compliance policy."
        super().__init__(msg)
        self.evaluation = evaluation

    @property
    def rule_code(self) -> str | None:
        return self.evaluation.violations[0].rule_code if self.evaluation.violations else None

    @property
    def reason(self) -> str:
        return str(self.args[0])

    @property
    def framework_ref(self) -> str | None:
        return self.evaluation.violations[0].framework_ref if self.evaluation.violations else None

    def __repr__(self) -> str:
        return (
            f"PolicyViolation(rule_code={self.rule_code!r}, "
            f"reason={self.reason!r}, "
            f"framework_ref={self.framework_ref!r})"
        )


class GateUnavailable(Exception):
    """
    Raised when Gate 1 is unreachable and fail_closed=True.

    With the default fail_closed=False, Gate 1 errors are silently treated as
    allowed=True so the agent continues unaffected.
    """


class ClientError(Exception):
    """
    Raised on 4xx responses from the AgentGovern API.

    This always propagates regardless of fail_silently — a 4xx indicates a
    configuration problem (wrong API key, invalid payload) that the caller
    should fix, not a transient network issue.
    """

    def __init__(self, message: str, *, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"ClientError(status_code={self.status_code}, message={str(self.args[0])!r})"
