"""
AgentGovern SDK — Compliance instrumentation for agentic AI workflows.

Quickstart::

    import agentgovern

    agentgovern.init(api_key="ag_prod_...")
    agentgovern.register_agent("my-credit-scoring-agent", name="Credit Scoring Agent")

    # Then instrument LangChain:
    agentgovern.instrument_langchain()

    # Or track actions manually:
    from agentgovern.types import ActionType
    agentgovern.track_action(
        agent_external_id="my-credit-scoring-agent",
        action_type=ActionType.TOOL_CALL,
        action_name="fetch_bureau_data",
    )
"""

from __future__ import annotations

from typing import Any

from agentgovern._version import __version__

from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import ClientError, GateUnavailable, PolicyViolation
from agentgovern.types import ActionStatus, ActionType, Environment, InputEvaluation, RuleViolation

_client: AgentGovernClient | None = None

# Tracks the external_id of the most recently registered agent so that
# instrument_langchain() can bind to it without requiring an explicit arg.
# TODO: minor race condition if register_agent() is called from multiple
# threads concurrently. Acceptable for v0 — startup code is single-threaded.
_last_registered_agent: str | None = None


def init(
    api_key: str,
    *,
    environment: str = "production",
    base_url: str = "https://agentgovern.zirahn.com",
    policy_engine_url: str | None = None,
    fail_silently: bool = True,
) -> AgentGovernClient:
    """
    Initialize the AgentGovern SDK.

    Must be called once at application startup before any other SDK calls.
    The SDK is designed to never break the customer's agent — if AgentGovern
    is unreachable, all errors are silently discarded.

    Args:
        api_key: SDK ingest key from the dashboard.
        environment: ``"production"`` | ``"staging"`` | ``"development"``.
        base_url: Vercel deployment URL (action ingest + agent registration).
        policy_engine_url: Render policy engine URL (Gate 1 evaluate/input).
            Defaults to ``AGENTGOVERN_POLICY_ENGINE_URL`` env var, then
            ``https://agentgovern.onrender.com``.
        fail_silently: If ``True``, SDK errors never raise into your agent.
    """
    global _client  # noqa: PLW0603
    _client = AgentGovernClient(
        api_key=api_key,
        environment=environment,
        base_url=base_url,
        policy_engine_url=policy_engine_url,
        fail_silently=fail_silently,
    )
    return _client


def register_agent(
    external_id: str,
    name: str,
    *,
    description: str | None = None,
    framework: str = "custom",
    framework_version: str | None = None,
    owner_email: str | None = None,
    tags: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Fire-and-forget agent registration. No-op if SDK is not initialized."""
    global _last_registered_agent  # noqa: PLW0603
    if _client is None:
        return
    _client.register_agent(
        external_id,
        name,
        description=description,
        framework=framework,
        framework_version=framework_version,
        owner_email=owner_email,
        tags=tags,
        metadata=metadata,
    )
    _last_registered_agent = external_id


def track_action(
    agent_external_id: str,
    action_type: ActionType,
    action_name: str,
    *,
    status: ActionStatus = ActionStatus.COMPLETED,
    duration_ms: int | None = None,
    input_payload: dict[str, Any] | None = None,
    output_payload: dict[str, Any] | None = None,
    model_id: str | None = None,
    token_count: int | None = None,
    trace_id: str | None = None,
    span_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Enqueue an action for async ingest. No-op if SDK is not initialized."""
    if _client is None:
        return
    _client.track_action(
        agent_external_id,
        action_type,
        action_name,
        status=status,
        duration_ms=duration_ms,
        input_payload=input_payload,
        output_payload=output_payload,
        model_id=model_id,
        token_count=token_count,
        trace_id=trace_id,
        span_id=span_id,
        metadata=metadata,
    )


def evaluate_input(
    agent_external_id: str,
    prompt: str,
    *,
    context: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
    fail_closed: bool = False,
) -> "InputEvaluation":
    """
    Gate 1 synchronous input evaluation. Call before passing a prompt to an LLM.

    Raises PolicyViolation if blocked. Returns InputEvaluation otherwise.
    No-op (returns allowed=True) if SDK is not initialized.
    """
    if _client is None:
        return InputEvaluation(allowed=True)
    return _client.evaluate_input(
        agent_external_id,
        prompt,
        context=context,
        metadata=metadata,
        fail_closed=fail_closed,
    )


def instrument_langchain(
    agent_external_id: str | None = None,
    *,
    auto_evaluate_input: bool = True,
    fail_open: bool = True,
) -> Any:
    """
    Attach AgentGovern to LangChain callbacks.

    Returns the callback handler instance. Requires the 'langchain' extra:
    ``pip install agentgovern[langchain]``

    Resolution order for the agent binding:
      1. ``agent_external_id`` argument if provided
      2. The external_id from the most recent ``register_agent()`` call
      3. RuntimeError — no silent defaults

    Args:
        agent_external_id: Agent to bind to (optional if register_agent was called).
        auto_evaluate_input: If True, Gate 1 evaluation runs before every LLM call.
        fail_open: If True (default), Gate 1 errors allow the LLM call through.
            Set False to block on Gate 1 failures (fail-closed mode).

    Examples::

        # Common: register once, then instrument
        agentgovern.register_agent("my-agent", name="My Agent")
        handler = agentgovern.instrument_langchain()

        # Multiple agents in one process
        handler_a = agentgovern.instrument_langchain("agent-a")
        handler_b = agentgovern.instrument_langchain("agent-b")

        # Fail-closed: block LLM call if Gate 1 is unreachable
        handler = agentgovern.instrument_langchain(fail_open=False)
    """
    if _client is None:
        raise RuntimeError("Call agentgovern.init() before instrument_langchain()")

    resolved = agent_external_id or _last_registered_agent
    if resolved is None:
        raise RuntimeError(
            "instrument_langchain() requires an agent_external_id. "
            "Either: (a) call agentgovern.register_agent(...) before "
            "instrument_langchain(), or (b) pass the agent ID explicitly: "
            "agentgovern.instrument_langchain('my-agent-id')."
        )

    from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler

    return AgentGovernCallbackHandler(
        client=_client,
        agent_external_id=resolved,
        auto_evaluate_input=auto_evaluate_input,
        fail_open=fail_open,
    )


def heartbeat() -> dict[str, Any]:
    """POST /v1/ingest/heartbeat — returns status dict. No-op dict if not initialized."""
    if _client is None:
        return {"status": "not_initialized"}
    return _client.heartbeat()


def status() -> dict[str, Any]:
    """Return SDK health status."""
    if _client is None:
        return {"initialized": False}
    return _client.status()


def shutdown(timeout: float = 5.0) -> None:
    """Flush remaining actions and stop the background thread."""
    if _client is not None:
        _client.shutdown(timeout=timeout)


__all__ = [
    "__version__",
    "init",
    "register_agent",
    "track_action",
    "evaluate_input",
    "instrument_langchain",
    "heartbeat",
    "status",
    "shutdown",
    "AgentGovernClient",
    "PolicyViolation",
    "GateUnavailable",
    "ClientError",
    "ActionType",
    "ActionStatus",
    "Environment",
    "InputEvaluation",
    "RuleViolation",
]
