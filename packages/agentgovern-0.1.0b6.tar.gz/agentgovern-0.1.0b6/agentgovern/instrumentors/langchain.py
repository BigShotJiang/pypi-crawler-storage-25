"""
LangChain callback handler for AgentGovern (STORY-011).

Attaches to any LangChain chain or agent via the callbacks= parameter::

    from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler

    handler = AgentGovernCallbackHandler(client=client, agent_external_id="my-agent")
    chain.invoke({"input": "..."}, config={"callbacks": [handler]})

Or via the module-level helper::

    import agentgovern
    agentgovern.init(api_key="ag_prod_...")
    handler = agentgovern.instrument_langchain("my-agent")

Requires the 'langchain' extra:
    pip install agentgovern[langchain]
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any
from uuid import UUID

# ---------------------------------------------------------------------------
# Conditional base class — inherits from BaseCallbackHandler when langchain-core
# is installed, falls back to object so the module is always importable.
# ---------------------------------------------------------------------------
try:
    from langchain_core.callbacks import BaseCallbackHandler as _BaseCallbackHandler
except ImportError:  # langchain-core not installed
    _BaseCallbackHandler = object  # type: ignore[misc,assignment]

if TYPE_CHECKING:
    from langchain_core.outputs import LLMResult

from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import GateUnavailable, PolicyViolation
from agentgovern.types import ActionStatus, ActionType


class AgentGovernCallbackHandler(_BaseCallbackHandler):
    """
    LangChain callback handler that records tool calls and LLM messages.

    Each LangChain run_id maps to a span_id. The parent_run_id becomes the
    trace_id so all spans within a single chain invocation are correlated.
    """

    def __init__(
        self,
        client: AgentGovernClient,
        agent_external_id: str | None = None,
        *,
        auto_evaluate_input: bool = True,
        fail_open: bool = True,
    ) -> None:
        try:
            super().__init__()
        except TypeError:
            pass  # object.__init__ does not accept extra args

        if not agent_external_id:
            raise ValueError(
                "AgentGovernCallbackHandler requires agent_external_id. "
                "Use agentgovern.instrument_langchain() which resolves the agent automatically, "
                "or pass it explicitly: AgentGovernCallbackHandler(client, 'my-agent-id')."
            )
        self._client = client
        self._agent_id = agent_external_id
        self._auto_evaluate_input = auto_evaluate_input
        self._fail_open = fail_open
        # run_id (str) → {"start_time": float, "tool_name" | "model_id": str, "trace_id": str}
        self._runs: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Tool events
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        tool_name = serialized.get("name", "unknown_tool")
        run_key = str(run_id)
        trace_id = str(parent_run_id) if parent_run_id else run_key
        self._runs[run_key] = {
            "start_time": time.monotonic(),
            "tool_name": tool_name,
            "trace_id": trace_id,
        }
        self._client.track_action(
            self._agent_id,
            ActionType.TOOL_CALL,
            tool_name,
            status=ActionStatus.STARTED,
            trace_id=trace_id,
            span_id=run_key,
            input_payload={"input": input_str} if input_str else None,
        )

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        run_info = self._runs.pop(run_key, {})
        duration_ms = _elapsed_ms(run_info.get("start_time"))
        tool_name = run_info.get("tool_name", "unknown_tool")
        self._client.track_action(
            self._agent_id,
            ActionType.TOOL_CALL,
            tool_name,
            status=ActionStatus.COMPLETED,
            duration_ms=duration_ms,
            trace_id=run_info.get("trace_id"),
            span_id=run_key,
            output_payload={"output": str(output)} if output is not None else None,
        )

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        run_info = self._runs.pop(run_key, {})
        duration_ms = _elapsed_ms(run_info.get("start_time"))
        tool_name = run_info.get("tool_name", "unknown_tool")
        self._client.track_action(
            self._agent_id,
            ActionType.TOOL_CALL,
            tool_name,
            status=ActionStatus.FAILED,
            duration_ms=duration_ms,
            trace_id=run_info.get("trace_id"),
            span_id=run_key,
            metadata={"error": str(error)},
        )

    # ------------------------------------------------------------------
    # LLM events
    # ------------------------------------------------------------------

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        if self._auto_evaluate_input:
            prompt_parts: list[str] = []
            for batch in messages:
                for msg in batch:
                    content = getattr(msg, "content", None)
                    if content:
                        prompt_parts.append(str(content))
            prompt = "\n".join(prompt_parts)[:4000]
            if prompt:
                model_name = (serialized.get("id") or ["unknown"])[-1]
                try:
                    self._client.evaluate_input(
                        self._agent_id,
                        prompt,
                        metadata={"model_id": model_name, "framework": "langchain"},
                        fail_closed=not self._fail_open,
                    )
                except PolicyViolation:
                    raise
                except GateUnavailable:
                    if not self._fail_open:
                        raise
                except Exception:  # noqa: BLE001
                    pass  # fail-open for unexpected errors

        self.on_llm_start(
            serialized,
            [str(msg) for batch in messages for msg in batch],
            run_id=run_id,
            parent_run_id=parent_run_id,
            **kwargs,
        )

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        model_name = (serialized.get("id") or ["unknown"])[-1]
        run_key = str(run_id)
        trace_id = str(parent_run_id) if parent_run_id else run_key
        self._runs[run_key] = {
            "start_time": time.monotonic(),
            "model_id": model_name,
            "trace_id": trace_id,
        }
        self._client.track_action(
            self._agent_id,
            ActionType.MESSAGE,
            f"llm/{model_name}",
            status=ActionStatus.STARTED,
            model_id=model_name,
            trace_id=trace_id,
            span_id=run_key,
        )

    def on_llm_end(
        self,
        response: "LLMResult",
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        run_info = self._runs.pop(run_key, {})
        duration_ms = _elapsed_ms(run_info.get("start_time"))
        model_id = run_info.get("model_id", "unknown")

        token_count: int | None = None
        try:
            usage = response.llm_output or {}
            token_count = (
                usage.get("token_usage", {}).get("total_tokens")
                or usage.get("usage", {}).get("total_tokens")
            )
        except Exception:  # noqa: BLE001
            pass

        self._client.track_action(
            self._agent_id,
            ActionType.MESSAGE,
            f"llm/{model_id}",
            status=ActionStatus.COMPLETED,
            duration_ms=duration_ms,
            model_id=model_id,
            token_count=token_count,
            trace_id=run_info.get("trace_id"),
            span_id=run_key,
        )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        run_info = self._runs.pop(run_key, {})
        duration_ms = _elapsed_ms(run_info.get("start_time"))
        model_id = run_info.get("model_id", "unknown")
        self._client.track_action(
            self._agent_id,
            ActionType.MESSAGE,
            f"llm/{model_id}",
            status=ActionStatus.FAILED,
            duration_ms=duration_ms,
            model_id=model_id,
            trace_id=run_info.get("trace_id"),
            span_id=run_key,
            metadata={"error": str(error)},
        )


def _elapsed_ms(start: float | None) -> int | None:
    if start is None:
        return None
    return int((time.monotonic() - start) * 1000)
