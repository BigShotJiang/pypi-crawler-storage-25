"""
OneRoster client-side validation tests.

Tests that validation happens in the resource layer (before transport)
using a stub transport. Mirrors the TS SDK validation.unit.test.ts.
"""

from __future__ import annotations

from typing import Any

import pytest

from timeback_common import InputValidationError, validate_sourced_id
from timeback_oneroster.client import OneRosterClient
from timeback_oneroster.lib.testing import OneRosterRecordingTransport, create_recording_transport
from timeback_oneroster.types.input import ComponentResourceCreateInput


def _client() -> tuple[OneRosterClient, list[dict[str, str]]]:
    transport = create_recording_transport()
    return OneRosterClient(transport=transport), transport.calls


class _BodyRecordingTransport(OneRosterRecordingTransport):
    def __init__(self) -> None:
        super().__init__()
        self.last_path: str | None = None
        self.last_data: dict[str, Any] | None = None

    async def post(self, path: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        self.last_path = path
        self.last_data = data
        return await super().post(path, data)

    async def put(self, path: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        self.last_path = path
        self.last_data = data
        return await super().put(path, data)


def _body_client() -> tuple[OneRosterClient, _BodyRecordingTransport]:
    transport = _BodyRecordingTransport()
    return OneRosterClient(transport=transport), transport


class TestPaginatorValidation:
    @pytest.mark.asyncio
    async def test_invalid_limit_throws_before_paginated_request(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.list(limit=0)
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_invalid_offset_throws_before_paginated_request(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.list(limit=100, offset=-1)
        assert len(calls) == 0


class TestSourcedIdValidation:
    def test_rejects_empty_string(self) -> None:
        with pytest.raises(InputValidationError):
            validate_sourced_id("", "get user")

    def test_rejects_whitespace(self) -> None:
        with pytest.raises(InputValidationError):
            validate_sourced_id("  ", "get user")

    def test_accepts_non_empty_string(self) -> None:
        validate_sourced_id("abc-123", "get user")


class TestUsersValidation:
    @pytest.mark.asyncio
    async def test_create_validates_input(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.create({})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_posts_normalized_payload(self) -> None:
        client, transport = _body_client()
        await client.users.create(
            {
                "sourcedId": "user-1",
                "enabledUser": "true",
                "givenName": "Jane",
                "familyName": "Doe",
                "email": "jane@example.com",
                "grades": ["pre-k", "K", "4th grade"],
                "roles": [
                    {
                        "roleType": "primary",
                        "role": "student",
                        "org": {"sourcedId": "school-1"},
                    }
                ],
            }
        )

        assert transport.last_data == {
            "user": {
                "sourcedId": "user-1",
                "enabledUser": True,
                "givenName": "Jane",
                "familyName": "Doe",
                "email": "jane@example.com",
                "roles": [
                    {
                        "roleType": "primary",
                        "role": "student",
                        "org": {"sourcedId": "school-1"},
                    }
                ],
                "grades": [-1, 0, 4],
            }
        }

    @pytest.mark.asyncio
    async def test_get_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users("").get()
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_update_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users("").update({})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_delete_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users("").delete()
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_upsert_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.users.upsert("", {})
        assert len(calls) == 0

    def test_scoped_user_validates_user_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            client.users("")
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_add_agent_validates_sourced_id(self) -> None:
        client, calls = _client()
        scoped = client.users("valid-user-id")
        with pytest.raises(InputValidationError):
            await scoped.add_agent({"agentSourcedId": ""})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_register_credential_validates_application_name(self) -> None:
        client, calls = _client()
        scoped = client.users("valid-user-id")
        with pytest.raises(InputValidationError):
            await scoped.register_credential(
                {"applicationName": "", "credentials": {"username": "", "password": ""}}
            )
        assert len(calls) == 0


class TestCoursesValidation:
    @pytest.mark.asyncio
    async def test_create_validates_input(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.create({"sourcedId": "test-id"})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_rejects_resources_because_upstream_drops_them(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.create(
                {
                    "status": "active",
                    "title": "Test Course",
                    "org": {"sourcedId": "school-1"},
                    "resources": [{"sourcedId": "resource-1"}],
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_rejects_unknown_subject_values(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.create(
                {
                    "status": "active",
                    "title": "Test Course",
                    "org": {"sourcedId": "school-1"},
                    "subjects": ["NotASubject"],
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_update_component_resource_validates_full_payload(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.update_component_resource(
                "component-resource-1",
                {"title": "Incomplete Component Resource"},
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_component_resource_requires_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.create_component_resource(
                {
                    "title": "Resource Link",
                    "courseComponent": {"sourcedId": "comp-001"},
                    "resource": {"sourcedId": "resource-001"},
                    "status": "active",
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_update_component_resource_requires_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.courses.update_component_resource(
                "component-resource-1",
                {
                    "title": "Resource Link",
                    "courseComponent": {"sourcedId": "comp-001"},
                    "resource": {"sourcedId": "resource-001"},
                    "status": "active",
                },
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_component_resource_accepts_model_instance_and_posts_clean_payload(
        self,
    ) -> None:
        client, transport = _body_client()
        model = ComponentResourceCreateInput.model_validate(
            {
                "sourcedId": "cr-1",
                "title": "Lesson 1",
                "courseComponent": {"sourcedId": "comp-001"},
                "resource": {"sourcedId": "resource-001"},
                "status": "active",
            }
        )

        await client.courses.create_component_resource(model)

        assert transport.last_data == {
            "componentResource": {
                "sourcedId": "cr-1",
                "title": "Lesson 1",
                "courseComponent": {"sourcedId": "comp-001"},
                "resource": {"sourcedId": "resource-001"},
                "status": "active",
            }
        }

    @pytest.mark.asyncio
    async def test_create_structure_posts_validated_payload_with_aliases(self) -> None:
        client, transport = _body_client()

        await client.courses.create_structure(
            {
                "course": {"sourcedId": "course-1"},
                "course_structure": {"rootComponentSourcedId": "component-1"},
            }
        )

        assert transport.last_path == "/ims/oneroster/rostering/v1p2/courses/structure"
        assert transport.last_data == {
            "course": {"sourcedId": "course-1"},
            "courseStructure": {"rootComponentSourcedId": "component-1"},
        }


class TestClassesValidation:
    @pytest.mark.asyncio
    async def test_create_validates_input(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.classes.create({"title": "Test Class"})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_rejects_resources_because_upstream_drops_them(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.classes.create(
                {
                    "title": "Test Class",
                    "terms": [{"sourcedId": "term-1"}],
                    "course": {"sourcedId": "course-1"},
                    "org": {"sourcedId": "school-1"},
                    "resources": [{"sourcedId": "resource-1"}],
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_update_rejects_unknown_subject_values(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.classes.update("class-1", {"subjects": ["NotASubject"]})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_enroll_validates_sourced_id(self) -> None:
        client, calls = _client()
        scoped = client.classes("valid-class-id")
        with pytest.raises(InputValidationError):
            await scoped.enroll({"sourcedId": "", "role": "student"})
        assert len(calls) == 0


class TestSchoolsValidation:
    @pytest.mark.asyncio
    async def test_create_validates_name(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.schools.create({})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_posts_default_school_type(self) -> None:
        client, transport = _body_client()

        await client.schools.create({"name": "Test School"})

        assert transport.last_data == {
            "org": {
                "name": "Test School",
                "type": "school",
            }
        }


class TestDemographicsValidation:
    @pytest.mark.asyncio
    async def test_create_validates_sourced_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.demographics.create({})
        assert len(calls) == 0


class TestResourcesValidation:
    @pytest.mark.asyncio
    async def test_create_validates_title_and_vendor_resource_id(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.resources.create({"title": "Title only"})
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_rejects_structured_metadata_without_type(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.resources.create(
                {
                    "title": "Structured Resource",
                    "vendorResourceId": "resource-1",
                    "metadata": {
                        "launchUrl": "https://example.com/launch",
                        "toolProvider": "ExampleApp",
                    },
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_rejects_invalid_typed_metadata(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.resources.create(
                {
                    "title": "Structured Resource",
                    "vendorResourceId": "resource-typed-invalid",
                    "metadata": {
                        "type": "interactive",
                        "launchUrl": "not-a-url",
                    },
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_create_rejects_invalid_fail_fast_stagnation_limit(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.resources.create(
                {
                    "title": "Structured Resource",
                    "vendorResourceId": "resource-fast-fail-invalid",
                    "metadata": {
                        "fail_fast": {
                            "stagnation_limit": 0,
                        }
                    },
                }
            )
        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_update_rejects_structured_metadata_without_type(self) -> None:
        client, calls = _client()
        with pytest.raises(InputValidationError):
            await client.resources.update(
                "resource-1",
                {
                    "metadata": {
                        "launchUrl": "https://example.com/launch",
                        "toolProvider": "ExampleApp",
                    }
                },
            )
        assert len(calls) == 0
