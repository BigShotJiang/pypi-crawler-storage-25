"""
Schema validation tests.

Port of the TS primitives.unit.test.ts and oneroster schema tests.
"""

from __future__ import annotations

from typing import ClassVar

import pytest
from pydantic import ValidationError

from timeback_oneroster.types import ResourceUpdateInput as ExportedResourceUpdateInput
from timeback_oneroster.types.assessment import AssessmentLineItem as AssessmentLineItemModel
from timeback_oneroster.types.gradebook import LineItem as LineItemModel
from timeback_oneroster.types.gradebook import Result as ResultModel
from timeback_oneroster.types.input import (
    AssessmentLineItemCreateInput,
    AssessmentResultCreateInput,
    ClassCreateInput,
    ClassUpdateInput,
    ComponentResourceCreateInput,
    CourseComponentCreateInput,
    CourseCreateInput,
    DemographicsCreateInput,
    ResourceCreateInput,
    ResourceUpdateInput,
    ResultCreateInput,
    UserCreateInput,
)
from timeback_oneroster.types.learning_objectives import LearningObjectiveResult
from timeback_oneroster.utils import normalize_grade

# ═══════════════════════════════════════════════════════════════════════════════
# TimebackGrade
# ═══════════════════════════════════════════════════════════════════════════════


class TestTimebackGrade:
    def test_accepts_numeric_string_input(self) -> None:
        assert normalize_grade("3") == 3

    def test_accepts_decimal_string_input_that_represents_an_integer(self) -> None:
        assert normalize_grade("3.0") == 3

    def test_accepts_float_input_that_represents_an_integer(self) -> None:
        assert normalize_grade(3.0) == 3

    def test_accepts_pre_k_string_input(self) -> None:
        assert normalize_grade("-1") == -1

    def test_accepts_kindergarten_aliases(self) -> None:
        assert normalize_grade("K") == 0
        assert normalize_grade("00") == 0

    def test_accepts_pre_k_aliases_and_ordinal_grade_strings(self) -> None:
        assert normalize_grade("pre-k") == -1
        assert normalize_grade("pk") == -1
        assert normalize_grade("4th grade") == 4

    def test_rejects_empty_string_input(self) -> None:
        with pytest.raises(ValueError):
            normalize_grade("")

    def test_rejects_whitespace_only_string_input(self) -> None:
        with pytest.raises(ValueError):
            normalize_grade("   ")

    def test_rejects_bare_grade_string_input(self) -> None:
        with pytest.raises(ValueError):
            normalize_grade("grade")

    def test_accepts_grade_k(self) -> None:
        assert normalize_grade("grade K") == 0

    def test_accepts_grade_pre_k(self) -> None:
        assert normalize_grade("grade pre-k") == -1

    def test_accepts_grade_middle_school(self) -> None:
        assert normalize_grade("grade middle school") == 7

    def test_rejects_out_of_range_string_input(self) -> None:
        with pytest.raises(ValueError):
            normalize_grade("99")


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster course schema
# ═══════════════════════════════════════════════════════════════════════════════


class TestCourseCreateInput:
    def test_requires_status_for_course_create_input(self) -> None:
        with pytest.raises(ValidationError):
            CourseCreateInput.model_validate(
                {
                    "title": "Algebra I",
                    "org": {"sourcedId": "school-1"},
                }
            )

    def test_requires_full_guid_refs_for_school_year(self) -> None:
        with pytest.raises(ValidationError):
            CourseCreateInput.model_validate(
                {
                    "status": "active",
                    "title": "Algebra I",
                    "org": {"sourcedId": "school-1"},
                    "schoolYear": {"sourcedId": "sy-1"},
                }
            )

        result = CourseCreateInput.model_validate(
            {
                "status": "active",
                "title": "Algebra I",
                "org": {"sourcedId": "school-1"},
                "schoolYear": {
                    "sourcedId": "sy-1",
                    "type": "academicSession",
                    "href": "https://api.example.com/academicSessions/sy-1",
                },
            }
        )
        assert result.school_year is not None
        assert result.school_year.sourced_id == "sy-1"

    def test_rejects_resources_because_upstream_drops_them(self) -> None:
        with pytest.raises(ValidationError):
            CourseCreateInput.model_validate(
                {
                    "status": "active",
                    "title": "Algebra I",
                    "org": {"sourcedId": "school-1"},
                    "resources": [{"sourcedId": "resource-1"}],
                }
            )

    @pytest.mark.parametrize("field", ["courseCode", "level", "gradingScheme"])
    def test_rejects_whitespace_only_optional_non_empty_fields(self, field: str) -> None:
        data = {
            "status": "active",
            "title": "Algebra I",
            "org": {"sourcedId": "school-1"},
        }
        data[field] = "   "
        with pytest.raises(ValidationError):
            CourseCreateInput.model_validate(data)

    def test_rejects_unknown_subject_values(self) -> None:
        with pytest.raises(ValidationError):
            CourseCreateInput.model_validate(
                {
                    "status": "active",
                    "title": "Algebra I",
                    "org": {"sourcedId": "school-1"},
                    "subjects": ["NotASubject"],
                }
            )


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster class schema
# ═══════════════════════════════════════════════════════════════════════════════


class TestClassCreateInput:
    def test_rejects_resources_because_upstream_drops_them(self) -> None:
        with pytest.raises(ValidationError):
            ClassCreateInput.model_validate(
                {
                    "title": "Section A",
                    "terms": [{"sourcedId": "term-1"}],
                    "course": {"sourcedId": "course-1"},
                    "org": {"sourcedId": "school-1"},
                    "resources": [{"sourcedId": "resource-1"}],
                }
            )

    @pytest.mark.parametrize("field", ["classCode", "location"])
    def test_rejects_whitespace_only_optional_non_empty_string_fields(self, field: str) -> None:
        data = {
            "title": "Section A",
            "terms": [{"sourcedId": "term-1"}],
            "course": {"sourcedId": "course-1"},
            "org": {"sourcedId": "school-1"},
        }
        data[field] = "   "
        with pytest.raises(ValidationError):
            ClassCreateInput.model_validate(data)

    @pytest.mark.parametrize("field", ["subjectCodes", "periods"])
    def test_rejects_whitespace_only_optional_non_empty_string_lists(self, field: str) -> None:
        data = {
            "title": "Section A",
            "terms": [{"sourcedId": "term-1"}],
            "course": {"sourcedId": "course-1"},
            "org": {"sourcedId": "school-1"},
        }
        data[field] = ["   "]
        with pytest.raises(ValidationError):
            ClassCreateInput.model_validate(data)

    def test_rejects_unknown_subject_values(self) -> None:
        with pytest.raises(ValidationError):
            ClassCreateInput.model_validate(
                {
                    "title": "Section A",
                    "terms": [{"sourcedId": "term-1"}],
                    "course": {"sourcedId": "course-1"},
                    "org": {"sourcedId": "school-1"},
                    "subjects": ["NotASubject"],
                }
            )


class TestClassUpdateInput:
    def test_rejects_unknown_subject_values(self) -> None:
        with pytest.raises(ValidationError):
            ClassUpdateInput.model_validate({"subjects": ["NotASubject"]})


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster resource schema
# ═══════════════════════════════════════════════════════════════════════════════


class TestResourceCreateInput:
    def test_accepts_truly_custom_metadata_without_type(self) -> None:
        result = ResourceCreateInput.model_validate(
            {
                "title": "Custom Resource",
                "vendorResourceId": "resource-1",
                "metadata": {
                    "externalId": "abc-123",
                    "customFlags": {"featured": True},
                    "fail_fast": {"consecutive_failures": 3},
                },
            }
        )
        assert result.metadata is not None

    def test_accepts_typed_metadata_and_preserves_extension_keys(self) -> None:
        result = ResourceCreateInput.model_validate(
            {
                "title": "Interactive Resource",
                "vendorResourceId": "resource-typed",
                "metadata": {
                    "type": "interactive",
                    "launchUrl": "https://example.com/launch",
                    "toolProvider": "ExampleApp",
                    "grades": ["grade K", 2],
                    "estimatedTime": 900,
                },
            }
        )
        assert result.metadata is not None
        assert result.metadata["launchUrl"] == "https://example.com/launch"
        assert result.metadata["grades"] == [0, 2]
        assert result.metadata["estimatedTime"] == 900

    def test_rejects_structured_metadata_keys_without_type(self) -> None:
        with pytest.raises(ValidationError):
            ResourceCreateInput.model_validate(
                {
                    "title": "Bad Resource",
                    "vendorResourceId": "resource-2",
                    "metadata": {
                        "launchUrl": "https://example.com/launch",
                        "toolProvider": "ExampleApp",
                    },
                }
            )

    def test_rejects_snake_case_structured_metadata_keys_without_type(self) -> None:
        with pytest.raises(ValidationError):
            ResourceCreateInput.model_validate(
                {
                    "title": "Bad Resource",
                    "vendorResourceId": "resource-2",
                    "metadata": {
                        "launch_url": "https://example.com/launch",
                        "tool_provider": "ExampleApp",
                    },
                }
            )

    def test_rejects_invalid_typed_metadata_values(self) -> None:
        with pytest.raises(ValidationError):
            ResourceCreateInput.model_validate(
                {
                    "title": "Bad Typed Resource",
                    "vendorResourceId": "resource-typed-invalid",
                    "metadata": {
                        "type": "interactive",
                        "launchUrl": "not-a-url",
                    },
                }
            )


class TestResourceUpdateInput:
    def test_is_reexported_from_types_package(self) -> None:
        result = ExportedResourceUpdateInput.model_validate({"title": "Updated Title"})
        assert result.title == "Updated Title"

    def test_accepts_partial_updates(self) -> None:
        result = ResourceUpdateInput.model_validate({"title": "Updated Title"})
        assert result.title == "Updated Title"

    def test_rejects_structured_metadata_keys_without_type(self) -> None:
        with pytest.raises(ValidationError):
            ResourceUpdateInput.model_validate(
                {
                    "metadata": {
                        "launchUrl": "https://example.com/launch",
                        "toolProvider": "ExampleApp",
                    }
                }
            )

    def test_rejects_invalid_fail_fast_metadata_without_type(self) -> None:
        with pytest.raises(ValidationError):
            ResourceCreateInput.model_validate(
                {
                    "title": "Bad Fast-Fail Resource",
                    "vendorResourceId": "resource-3",
                    "metadata": {
                        "fail_fast": {"consecutive_failures": 0},
                    },
                }
            )

    def test_rejects_invalid_stagnation_limit_without_type(self) -> None:
        with pytest.raises(ValidationError):
            ResourceCreateInput.model_validate(
                {
                    "title": "Bad Fast-Fail Resource",
                    "vendorResourceId": "resource-4",
                    "metadata": {
                        "fail_fast": {"stagnation_limit": 0},
                    },
                }
            )

    @pytest.mark.parametrize("field", ["vendorId", "applicationId"])
    def test_rejects_whitespace_only_optional_non_empty_fields(self, field: str) -> None:
        data = {
            "title": "Custom Resource",
            "vendorResourceId": "resource-1",
        }
        data[field] = "   "
        with pytest.raises(ValidationError):
            ResourceCreateInput.model_validate(data)


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster course component schema
# ═══════════════════════════════════════════════════════════════════════════════


class TestCourseComponentCreateInput:
    _base: ClassVar[dict] = {
        "title": "Unit 1",
        "course": {"sourcedId": "course-1"},
        "status": "active",
    }

    def test_normalizes_legacy_course_component_to_parent(self) -> None:
        result = CourseComponentCreateInput.model_validate(
            {
                **self._base,
                "courseComponent": {"sourcedId": "parent-1"},
            }
        )
        assert result.parent is not None
        assert result.parent.sourced_id == "parent-1"

    def test_preserves_explicit_parent_over_course_component(self) -> None:
        result = CourseComponentCreateInput.model_validate(
            {
                **self._base,
                "parent": {"sourcedId": "explicit-parent"},
                "courseComponent": {"sourcedId": "legacy-parent"},
            }
        )
        assert result.parent is not None
        assert result.parent.sourced_id == "explicit-parent"

    def test_works_without_either_parent_or_course_component(self) -> None:
        result = CourseComponentCreateInput.model_validate(self._base)
        assert result.parent is None

    def test_preserves_explicit_null_parent(self) -> None:
        result = CourseComponentCreateInput.model_validate(
            {
                **self._base,
                "parent": None,
            }
        )
        assert result.parent is None

    def test_preserves_explicit_null_parent_even_when_course_component_is_set(self) -> None:
        result = CourseComponentCreateInput.model_validate(
            {
                **self._base,
                "parent": None,
                "courseComponent": {"sourcedId": "legacy-parent"},
            }
        )
        assert result.parent is None

    def test_accepts_date_only_unlock_date_and_normalizes(self) -> None:
        result = CourseComponentCreateInput.model_validate(
            {
                **self._base,
                "unlockDate": "2026-03-29",
            }
        )
        assert result.unlock_date == "2026-03-29T00:00:00Z"

    def test_rejects_null_sort_order(self) -> None:
        with pytest.raises(ValidationError):
            CourseComponentCreateInput.model_validate(
                {
                    **self._base,
                    "sortOrder": None,
                }
            )


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster user schema
# ═══════════════════════════════════════════════════════════════════════════════


class TestUserCreateInput:
    def test_accepts_string_enabled_user_and_expanded_optional_fields(self) -> None:
        result = UserCreateInput.model_validate(
            {
                "sourcedId": "user-1",
                "givenName": "Jane",
                "familyName": "Doe",
                "email": "jane@example.com",
                "enabledUser": "true",
                "userMasterIdentifier": "sis-123",
                "preferredFirstName": None,
                "primaryOrg": {"sourcedId": "school-1"},
                "roles": [
                    {
                        "roleType": "primary",
                        "role": "student",
                        "org": {"sourcedId": "school-1"},
                    },
                ],
            }
        )
        assert result.enabled_user is True

    def test_requires_valid_email(self) -> None:
        with pytest.raises(ValidationError):
            UserCreateInput.model_validate(
                {
                    "sourcedId": "user-1",
                    "givenName": "Jane",
                    "familyName": "Doe",
                    "email": "not-an-email",
                    "enabledUser": True,
                    "roles": [
                        {
                            "roleType": "primary",
                            "role": "student",
                            "org": {"sourcedId": "school-1"},
                        },
                    ],
                }
            )

    def test_rejects_null_primary_org(self) -> None:
        with pytest.raises(ValidationError):
            UserCreateInput.model_validate(
                {
                    "sourcedId": "user-1",
                    "givenName": "Jane",
                    "familyName": "Doe",
                    "email": "jane@example.com",
                    "enabledUser": True,
                    "primaryOrg": None,
                    "roles": [
                        {
                            "roleType": "primary",
                            "role": "student",
                            "org": {"sourcedId": "school-1"},
                        },
                    ],
                }
            )

    @pytest.mark.parametrize(
        "field",
        [
            "middleName",
            "preferredFirstName",
            "preferredMiddleName",
            "preferredLastName",
            "username",
            "sms",
            "phone",
            "pronouns",
            "password",
        ],
    )
    def test_rejects_whitespace_only_optional_non_empty_fields(self, field: str) -> None:
        data = {
            "sourcedId": "user-1",
            "givenName": "Jane",
            "familyName": "Doe",
            "email": "jane@example.com",
            "enabledUser": True,
            "roles": [
                {
                    "roleType": "primary",
                    "role": "student",
                    "org": {"sourcedId": "school-1"},
                },
            ],
        }
        data[field] = "   "
        with pytest.raises(ValidationError):
            UserCreateInput.model_validate(data)


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster demographics schema
# ═══════════════════════════════════════════════════════════════════════════════


class TestDemographicsCreateInput:
    def test_accepts_supported_fields_with_string_booleans(self) -> None:
        result = DemographicsCreateInput.model_validate(
            {
                "sourcedId": "user-1",
                "birthDate": "2010-05-15",
                "sex": "male",
                "americanIndianOrAlaskaNative": "false",
                "hispanicOrLatinoEthnicity": "true",
                "publicSchoolResidenceStatus": "resident",
            }
        )
        assert result.sourced_id == "user-1"

    def test_rejects_unknown_demographics_keys(self) -> None:
        with pytest.raises(ValidationError):
            DemographicsCreateInput.model_validate(
                {
                    "sourcedId": "user-1",
                    "unsupportedField": "nope",
                }
            )


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster assessment schemas
# ═══════════════════════════════════════════════════════════════════════════════


class TestAssessmentLineItemCreateInput:
    def test_accepts_date_last_modified_and_learning_objective_set(self) -> None:
        result = AssessmentLineItemCreateInput.model_validate(
            {
                "status": "active",
                "dateLastModified": "2026-03-29T12:00:00Z",
                "title": "Midterm",
                "learningObjectiveSet": [
                    {
                        "source": "state-standards",
                        "learningObjectiveIds": ["lo-1", "lo-2"],
                    },
                ],
            }
        )
        assert result.date_last_modified == "2026-03-29T12:00:00Z"
        assert result.learning_objective_set is not None
        assert result.learning_objective_set[0].learning_objective_ids == ["lo-1", "lo-2"]


class TestAssessmentResultCreateInput:
    def test_accepts_date_last_modified(self) -> None:
        result = AssessmentResultCreateInput.model_validate(
            {
                "status": "active",
                "dateLastModified": "2026-03-29T12:00:00Z",
                "assessmentLineItem": {"sourcedId": "ali-1"},
                "student": {"sourcedId": "student-1"},
                "scoreDate": "2024-03-15",
                "scoreStatus": "fully graded",
            }
        )
        assert result.date_last_modified == "2026-03-29T12:00:00Z"

    @pytest.mark.parametrize("field", ["score", "textScore"])
    def test_rejects_null_scored_learning_objective_values(self, field: str) -> None:
        with pytest.raises(ValidationError):
            AssessmentResultCreateInput.model_validate(
                {
                    "status": "active",
                    "assessmentLineItem": {"sourcedId": "ali-1"},
                    "student": {"sourcedId": "student-1"},
                    "scoreDate": "2024-03-15",
                    "scoreStatus": "fully graded",
                    "learningObjectiveSet": [
                        {
                            "source": "state-standards",
                            "learningObjectiveResults": [
                                {
                                    "learningObjectiveId": "lo-1",
                                    field: None,
                                },
                            ],
                        },
                    ],
                }
            )


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster result - learning objective sets
# ═══════════════════════════════════════════════════════════════════════════════


class TestResultLearningObjectiveSet:
    def test_accepts_scored_learning_objective_sets(self) -> None:
        result = ResultCreateInput.model_validate(
            {
                "lineItem": {"sourcedId": "li-1"},
                "student": {"sourcedId": "student-1"},
                "scoreDate": "2024-03-15",
                "scoreStatus": "fully graded",
                "status": "active",
                "learningObjectiveSet": [
                    {
                        "source": "state-standards",
                        "learningObjectiveResults": [
                            {
                                "learningObjectiveId": "lo-1",
                                "score": 0.75,
                                "textScore": "proficient",
                            },
                        ],
                    },
                ],
            }
        )
        assert result.learning_objective_set is not None
        assert len(result.learning_objective_set) == 1

    def test_rejects_line_item_style_learning_objective_sets(self) -> None:
        with pytest.raises(ValidationError):
            ResultCreateInput.model_validate(
                {
                    "lineItem": {"sourcedId": "li-1"},
                    "student": {"sourcedId": "student-1"},
                    "scoreDate": "2024-03-15",
                    "scoreStatus": "fully graded",
                    "status": "active",
                    "learningObjectiveSet": [
                        {
                            "source": "state-standards",
                            "learningObjectiveIds": ["lo-1"],
                        },
                    ],
                }
            )

    @pytest.mark.parametrize("field", ["score", "textScore"])
    def test_rejects_null_scored_learning_objective_values(self, field: str) -> None:
        with pytest.raises(ValidationError):
            ResultCreateInput.model_validate(
                {
                    "lineItem": {"sourcedId": "li-1"},
                    "student": {"sourcedId": "student-1"},
                    "scoreDate": "2024-03-15",
                    "scoreStatus": "fully graded",
                    "status": "active",
                    "learningObjectiveSet": [
                        {
                            "source": "state-standards",
                            "learningObjectiveResults": [
                                {
                                    "learningObjectiveId": "lo-1",
                                    field: None,
                                },
                            ],
                        },
                    ],
                }
            )

    @pytest.mark.parametrize("field", ["inProgress", "incomplete", "late", "missing"])
    def test_rejects_null_optional_string_flags(self, field: str) -> None:
        data = {
            "lineItem": {"sourcedId": "li-1"},
            "student": {"sourcedId": "student-1"},
            "scoreDate": "2024-03-15",
            "scoreStatus": "fully graded",
            "status": "active",
        }
        data[field] = None

        with pytest.raises(ValidationError):
            ResultCreateInput.model_validate(data)


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster component resource
# ═══════════════════════════════════════════════════════════════════════════════


class TestComponentResourceCreateInput:
    def test_accepts_valid_component_resource(self) -> None:
        result = ComponentResourceCreateInput.model_validate(
            {
                "sourcedId": "cr-1",
                "title": "Lesson 1",
                "courseComponent": {"sourcedId": "component-1"},
                "resource": {"sourcedId": "resource-1"},
                "status": "active",
                "lessonType": "quiz",
            }
        )
        assert result.sourced_id == "cr-1"
        assert result.lesson_type == "quiz"

    def test_rejects_non_powerpath_lesson_type(self) -> None:
        with pytest.raises(ValidationError):
            ComponentResourceCreateInput.model_validate(
                {
                    "sourcedId": "cr-1",
                    "title": "Lesson 1",
                    "courseComponent": {"sourcedId": "component-1"},
                    "resource": {"sourcedId": "resource-1"},
                    "status": "active",
                    "lessonType": "instructional",
                }
            )

    def test_rejects_incomplete_component_resource(self) -> None:
        with pytest.raises(ValidationError):
            ComponentResourceCreateInput.model_validate(
                {
                    "title": "Incomplete Component Resource",
                }
            )

    def test_rejects_null_sort_order(self) -> None:
        with pytest.raises(ValidationError):
            ComponentResourceCreateInput.model_validate(
                {
                    "sourcedId": "cr-1",
                    "title": "Lesson 1",
                    "courseComponent": {"sourcedId": "component-1"},
                    "resource": {"sourcedId": "resource-1"},
                    "status": "active",
                    "sortOrder": None,
                }
            )


# ═══════════════════════════════════════════════════════════════════════════════
# OneRoster read models
# ═══════════════════════════════════════════════════════════════════════════════


class TestGradebookReadModels:
    def test_line_item_preserves_academic_session_and_learning_objective_set(self) -> None:
        result = LineItemModel.model_validate(
            {
                "sourcedId": "li-1",
                "title": "Quiz 1",
                "assignDate": "2026-03-29T12:00:00Z",
                "dueDate": "2026-03-30T12:00:00Z",
                "class": {"sourcedId": "class-1"},
                "academicSession": {"sourcedId": "session-1"},
                "learningObjectiveSet": [
                    {
                        "source": "state-standards",
                        "learningObjectiveIds": ["lo-1", "lo-2"],
                    },
                ],
            }
        )
        assert result.academic_session is not None
        assert result.academic_session.sourced_id == "session-1"
        assert result.learning_objective_set is not None
        assert result.learning_objective_set[0].learning_objective_ids == ["lo-1", "lo-2"]

    def test_result_preserves_class_and_score_scale(self) -> None:
        result = ResultModel.model_validate(
            {
                "sourcedId": "result-1",
                "lineItem": {"sourcedId": "li-1"},
                "student": {"sourcedId": "student-1"},
                "class": {"sourcedId": "class-1"},
                "scoreScale": {"sourcedId": "scale-1"},
                "scoreStatus": "fully graded",
            }
        )
        assert result.class_ is not None
        assert result.class_.sourced_id == "class-1"
        assert result.score_scale is not None
        assert result.score_scale.sourced_id == "scale-1"


class TestAssessmentReadModels:
    def test_assessment_line_item_preserves_learning_objective_set(self) -> None:
        result = AssessmentLineItemModel.model_validate(
            {
                "sourcedId": "ali-1",
                "title": "Midterm",
                "learningObjectiveSet": [
                    {
                        "source": "state-standards",
                        "learningObjectiveIds": ["lo-1", "lo-2"],
                    },
                ],
            }
        )
        assert result.learning_objective_set is not None
        assert result.learning_objective_set[0].learning_objective_ids == ["lo-1", "lo-2"]


class TestLearningObjectiveReadModels:
    @pytest.mark.parametrize("field", ["score", "textScore"])
    def test_rejects_null_scored_learning_objective_values(self, field: str) -> None:
        with pytest.raises(ValidationError):
            LearningObjectiveResult.model_validate(
                {
                    "learningObjectiveId": "lo-1",
                    field: None,
                }
            )
