"""
Utility Functions

Internal utilities for the OneRoster client.
"""

from __future__ import annotations

import re

from timeback_common import normalize_boolean, normalize_date_only

_VALID_GRADES = frozenset(range(-1, 14))


def normalize_grade(value: int | float | str) -> int:
    """
    Coerce a single grade value to a numeric Timeback grade code.

    Accepts:
    - Integers already in the valid range (-1 ... 13)
    - Numeric strings (``"5"``, ``"-1"``, ``"00"`` -> 0)
    - Human-readable labels: ``"K"``, ``"pre-k"`` / ``"pk"``,
      ``"middle school"``, ``"4th grade"``, ``"grade K"`` etc.

    Returns:
        The normalized numeric grade.

    Raises:
        ValueError: If the input cannot be mapped to a valid Timeback grade.
    """
    if isinstance(value, bool):
        raise ValueError(f"must be a valid Timeback grade, got {value}")

    if isinstance(value, int):
        if value in _VALID_GRADES:
            return value
        raise ValueError(f"must be a valid Timeback grade, got {value}")

    if isinstance(value, float):
        if not value.is_integer():
            raise ValueError(f"must be a valid Timeback grade, got {value}")
        parsed = int(value)
        if parsed in _VALID_GRADES:
            return parsed
        raise ValueError(f"must be a valid Timeback grade, got {parsed}")

    raw = str(value).lower().strip().replace("_", " ")
    if raw == "":
        raise ValueError("must be a valid Timeback grade")

    # Strip "grade" prefix and ordinal suffixes (1st, 2nd, 3rd, 4th, ...)
    stripped = re.sub(r"\bgrade\b", "", raw)
    stripped = re.sub(r"(\d+)(st|nd|rd|th)\b", r"\1", stripped).strip()
    if stripped == "":
        raise ValueError(f"must be a valid Timeback grade, got '{value}'")

    if stripped in ("pre-k", "pk"):
        return -1
    if stripped == "k":
        return 0
    if stripped == "middle school":
        return 7

    normalized = re.sub(r"\s+", "", stripped)
    without_leading_zeros = normalized.lstrip("0") or "0"

    try:
        parsed_number = float(without_leading_zeros)
    except ValueError:
        raise ValueError(f"must be a valid Timeback grade, got '{value}'") from None

    if not parsed_number.is_integer():
        raise ValueError(f"must be a valid Timeback grade, got '{value}'")

    parsed = int(parsed_number)

    if parsed not in _VALID_GRADES:
        raise ValueError(f"must be a valid Timeback grade, got {parsed}")
    return parsed


def parse_grades(grades: list[str | int] | None) -> list[int] | None:
    """
    Convert grade strings from API responses to numeric grade values.

    The API returns grades as strings (e.g., "5", "-1") because the database
    stores them as text. This function normalizes them to numbers for
    a better developer experience.  It also accepts human-readable labels
    such as ``"K"``, ``"pre-k"``, ``"4th grade"``, etc.

    Args:
        grades: Array of string/int grades from API, or None

    Returns:
        Array of numeric grades, or None if input was None

    Example:
        ```python
        parse_grades(["1", "2", "3"])  # [1, 2, 3]
        parse_grades(None)  # None
        parse_grades(["-1", "0", "13"])  # [-1, 0, 13]
        parse_grades(["K", "pre-k"])  # [0, -1]
        ```
    """
    if grades is None:
        return None
    if not isinstance(grades, list):
        raise TypeError(f"grades must be a list, got {type(grades).__name__}")
    return [normalize_grade(g) for g in grades]


__all__ = [
    "normalize_boolean",
    "normalize_date_only",
    "normalize_grade",
    "parse_grades",
]
