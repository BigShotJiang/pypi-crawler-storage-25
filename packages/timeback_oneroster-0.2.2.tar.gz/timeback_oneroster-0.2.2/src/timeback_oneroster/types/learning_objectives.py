"""
Shared learning objective models for OneRoster response types.
"""

from typing import cast

from pydantic import BaseModel, ConfigDict, Field


class LearningObjectiveSetItem(BaseModel):
    """Per-source group of learning objective IDs."""

    source: str
    learning_objective_ids: list[str] = Field(alias="learningObjectiveIds")

    model_config = ConfigDict(populate_by_name=True)


class LearningObjectiveResult(BaseModel):
    """One scored learning objective entry."""

    learning_objective_id: str = Field(alias="learningObjectiveId")
    score: float = cast("float", None)
    text_score: str = Field(default=cast("str", None), alias="textScore")

    model_config = ConfigDict(populate_by_name=True)


class LearningObjectiveScoreSetItem(BaseModel):
    """Per-source group of learning objective scores."""

    source: str
    learning_objective_results: list[LearningObjectiveResult] = Field(
        alias="learningObjectiveResults"
    )

    model_config = ConfigDict(populate_by_name=True)
