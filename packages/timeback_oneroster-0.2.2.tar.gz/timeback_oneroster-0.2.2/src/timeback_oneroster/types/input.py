"""
OneRoster Input Schemas

Pydantic models for validating OneRoster write operation inputs.

Unknown keys are rejected intentionally; add supported fields here
rather than relying on extra="allow".
"""

from __future__ import annotations

import re
from typing import Annotated, Any, Literal, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    HttpUrl,
    StrictBool,
    StrictFloat,
    StrictInt,
    StrictStr,
    TypeAdapter,
    field_validator,
    model_validator,
)

from timeback_common import NonEmptyString  # noqa: TC001

from ..utils import normalize_grade


def _coerce_grades_before(value: object) -> object:
    if value is None:
        return None
    if isinstance(value, list):
        return [normalize_grade(grade) for grade in value]
    return value


# ═══════════════════════════════════════════════════════════════════════════════
# COMMON TYPES
# ═══════════════════════════════════════════════════════════════════════════════

Status = Literal["active", "tobedeleted"]

UserRole = Literal[
    "administrator",
    "aide",
    "guardian",
    "parent",
    "proctor",
    "relative",
    "student",
    "teacher",
]

OrganizationType = Literal[
    "department",
    "school",
    "district",
    "local",
    "state",
    "national",
]

ClassType = Literal["homeroom", "scheduled"]

SessionType = Literal["gradingPeriod", "semester", "schoolYear", "term"]

ScoreStatus = Literal[
    "exempt",
    "fully graded",
    "not submitted",
    "partially graded",
    "submitted",
]

EnrollRole = Literal["student", "teacher"]

RoleType = Literal["primary", "secondary"]

GuidRefType = Literal[
    "academicSession",
    "assessmentLineItem",
    "category",
    "class",
    "course",
    "demographics",
    "enrollment",
    "gradingPeriod",
    "lineItem",
    "org",
    "resource",
    "result",
    "scoreScale",
    "student",
    "teacher",
    "term",
    "user",
    "componentResource",
    "courseComponent",
]

LessonType = Literal[
    "powerpath-100",
    "quiz",
    "test-out",
    "placement",
    "unit-test",
    "alpha-read-article",
]

TimebackSubject = Literal[
    "Reading",
    "Language",
    "Vocabulary",
    "Social Studies",
    "Writing",
    "Science",
    "FastMath",
    "Math",
    "None",
    "Other",
]

ResourceType = Literal[
    "qti",
    "text",
    "audio",
    "video",
    "interactive",
    "visual",
    "course-material",
    "assessment-bank",
]

QtiSubType = Literal["qti-test", "qti-question", "qti-stimulus", "qti-test-bank"]
CourseMaterialSubType = Literal["unit", "course", "resource-collection"]
QuestionType = Literal[
    "choice",
    "order",
    "associate",
    "match",
    "hotspot",
    "hottext",
    "select-point",
    "graphic-order",
    "graphic-associate",
    "graphic-gap-match",
    "text-entry",
    "extended-text",
    "inline-choice",
    "upload",
    "slider",
    "drawing",
    "media",
    "custom",
]
Difficulty = Literal["easy", "medium", "hard"]


class Ref(BaseModel):
    """Reference to another OneRoster entity."""

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    type: str | None = None
    href: str | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class GuidRef(BaseModel):
    """Strict reference: required URL ``href`` and ``type`` from ``GuidRefType``."""

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    type: GuidRefType
    href: HttpUrl

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# LEARNING OBJECTIVE SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════


class LearningObjectiveSetItemInput(BaseModel):
    """A set of learning objective IDs (for line items and resource metadata)."""

    source: str
    learning_objective_ids: list[str] = Field(alias="learningObjectiveIds")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class LearningObjectiveResultInput(BaseModel):
    """One scored learning objective entry inside a learningObjectiveSet on results."""

    learning_objective_id: str = Field(alias="learningObjectiveId")
    score: float = cast("float", None)
    text_score: str = Field(default=cast("str", None), alias="textScore")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class LearningObjectiveScoreSetItemInput(BaseModel):
    """Per-source group of learning objective scores for gradebook and assessment results."""

    source: str
    learning_objective_results: list[LearningObjectiveResultInput] = Field(
        alias="learningObjectiveResults"
    )

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# USER INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class UserIdInput(BaseModel):
    """External user identifier."""

    type: NonEmptyString
    identifier: NonEmptyString

    model_config = ConfigDict(extra="forbid")


class UserRoleInput(BaseModel):
    """Role assignment for a user."""

    role_type: RoleType = Field(alias="roleType")
    role: UserRole
    org: Ref
    user_profile: str | None = Field(default=None, alias="userProfile")
    metadata: dict[str, Any] | None = None
    begin_date: str | None = Field(default=None, alias="beginDate")
    end_date: str | None = Field(default=None, alias="endDate")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class UserCreateInput(BaseModel):
    """
    Input for creating a OneRoster user.
    """

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    status: Status | None = None
    enabled_user: bool = Field(alias="enabledUser")
    given_name: NonEmptyString = Field(alias="givenName")
    family_name: NonEmptyString = Field(alias="familyName")
    middle_name: NonEmptyString | None = Field(default=None, alias="middleName")
    preferred_first_name: NonEmptyString | None = Field(default=None, alias="preferredFirstName")
    preferred_middle_name: NonEmptyString | None = Field(default=None, alias="preferredMiddleName")
    preferred_last_name: NonEmptyString | None = Field(default=None, alias="preferredLastName")
    username: NonEmptyString | None = None
    email: EmailStr
    user_master_identifier: str | None = Field(default=None, alias="userMasterIdentifier")
    roles: Annotated[list[UserRoleInput], Field(min_length=1)]
    user_ids: list[UserIdInput] | None = Field(default=None, alias="userIds")
    agents: list[Ref] | None = None
    primary_org: Ref = Field(default=cast("Ref", None), alias="primaryOrg")
    grades: list[int] | None = None
    sms: NonEmptyString | None = None
    phone: NonEmptyString | None = None
    pronouns: NonEmptyString | None = None
    password: NonEmptyString | None = None
    metadata: dict[str, Any] | None = None

    @field_validator("enabled_user", mode="before")
    @classmethod
    def _coerce_enabled_user(cls, v: object) -> object:
        if isinstance(v, str):
            if v == "true":
                return True
            if v == "false":
                return False
        return v

    _coerce_grades = field_validator("grades", mode="before")(_coerce_grades_before)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# ORGANIZATION INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class OrgCreateInput(BaseModel):
    """
    Input for creating a OneRoster organization.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status | None = None
    name: NonEmptyString
    type: OrganizationType
    identifier: str | None = None
    parent: Ref | None = None
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class SchoolCreateInput(BaseModel):
    """
    Input for creating a OneRoster school.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status | None = None
    name: NonEmptyString
    type: Literal["school"] = "school"
    identifier: str | None = None
    parent: Ref | None = None
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# COURSE INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class CourseCreateInput(BaseModel):
    """
    Input for creating a OneRoster course.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status
    title: NonEmptyString
    org: Ref
    course_code: NonEmptyString | None = Field(default=None, alias="courseCode")
    subjects: list[TimebackSubject] | None = None
    subject_codes: list[str] | None = Field(default=None, alias="subjectCodes")
    grades: list[int] | None = None
    level: NonEmptyString | None = None
    academic_session: Ref | None = Field(default=None, alias="academicSession")
    school_year: GuidRef | None = Field(default=None, alias="schoolYear")
    grading_scheme: NonEmptyString | None = Field(default=None, alias="gradingScheme")
    metadata: dict[str, Any] | None = None

    # NOTE: ``resources`` is accepted by the upstream CourseSchema but the current
    # implementation of serializeCourse() drops it before writing to the database,
    # so the API silently ignores this field on create/update until the service is
    # extended to persist it.

    _coerce_grades = field_validator("grades", mode="before")(_coerce_grades_before)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class ClassCreateInput(BaseModel):
    """
    Input for creating a OneRoster class.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status | None = None
    title: NonEmptyString
    terms: Annotated[list[Ref], Field(min_length=1)]
    course: Ref
    org: Ref
    class_code: NonEmptyString | None = Field(default=None, alias="classCode")
    class_type: ClassType | None = Field(default=None, alias="classType")
    location: NonEmptyString | None = None
    grades: list[int] | None = None
    subjects: list[TimebackSubject] | None = None
    subject_codes: list[NonEmptyString] | None = Field(default=None, alias="subjectCodes")
    periods: list[NonEmptyString] | None = None
    metadata: dict[str, Any] | None = None

    # NOTE: ``resources`` is accepted by the upstream ClassSchema but the current
    # implementation drops it before writing to the database.

    _coerce_grades = field_validator("grades", mode="before")(_coerce_grades_before)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS UPDATE INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class ClassUpdateInput(BaseModel):
    """
    Input for updating a OneRoster class (partial update).
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status | None = None
    title: NonEmptyString | None = None
    terms: list[Ref] | None = None
    course: Ref | None = None
    org: Ref | None = None
    class_code: NonEmptyString | None = Field(default=None, alias="classCode")
    class_type: ClassType | None = Field(default=None, alias="classType")
    location: NonEmptyString | None = None
    grades: list[int] | None = None
    subjects: list[TimebackSubject] | None = None
    subject_codes: list[NonEmptyString] | None = Field(default=None, alias="subjectCodes")
    periods: list[NonEmptyString] | None = None
    metadata: dict[str, Any] | None = None

    _coerce_grades = field_validator("grades", mode="before")(_coerce_grades_before)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# ACADEMIC SESSION INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class AcademicSessionCreateInput(BaseModel):
    """
    Input for creating a OneRoster academic session.
    """

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    status: Status
    title: NonEmptyString
    start_date: str = Field(alias="startDate")
    end_date: str = Field(alias="endDate")
    type: SessionType
    school_year: NonEmptyString = Field(alias="schoolYear")
    org: Ref
    parent: Ref | None = None
    children: list[Ref] | None = None
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# ENROLLMENT INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class EnrollmentCreateInput(BaseModel):
    """
    Input for creating a OneRoster enrollment.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status | None = None
    user: Ref
    class_: Ref = Field(alias="class")
    school: Ref | None = None
    role: UserRole
    primary: Literal["true", "false"] | None = None
    begin_date: str | None = Field(default=None, alias="beginDate")
    end_date: str | None = Field(default=None, alias="endDate")
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class EnrollmentPatchInput(BaseModel):
    """
    Input for partially updating a OneRoster enrollment.

    All fields are optional -- only provided fields are sent.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status | None = None
    user: Ref | None = None
    class_: Ref | None = Field(default=None, alias="class")
    school: Ref | None = None
    role: UserRole | None = None
    primary: Literal["true", "false"] | None = None
    begin_date: str | None = Field(default=None, alias="beginDate")
    end_date: str | None = Field(default=None, alias="endDate")
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class EnrollInput(BaseModel):
    """
    Input for the convenience enroll method.
    """

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    role: EnrollRole
    primary: Literal["true", "false"] | None = None
    begin_date: str | None = Field(default=None, alias="beginDate")
    end_date: str | None = Field(default=None, alias="endDate")
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# GRADEBOOK: CATEGORY INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class CategoryCreateInput(BaseModel):
    """
    Input for creating a OneRoster category.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    title: NonEmptyString
    status: Status
    weight: float | None = None
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# GRADEBOOK: LINE ITEM INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class LineItemCreateInput(BaseModel):
    """
    Input for creating a OneRoster line item.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    title: NonEmptyString
    class_: Ref = Field(alias="class")
    school: Ref
    category: Ref
    assign_date: str = Field(alias="assignDate")
    due_date: str = Field(alias="dueDate")
    status: Status | None = None
    description: str | None = None
    result_value_min: float | None = Field(default=None, alias="resultValueMin")
    result_value_max: float | None = Field(default=None, alias="resultValueMax")
    grading_period: Ref | None = Field(default=None, alias="gradingPeriod")
    academic_session: Ref | None = Field(default=None, alias="academicSession")
    score_scale: Ref | None = Field(default=None, alias="scoreScale")
    learning_objective_set: list[LearningObjectiveSetItemInput] | None = Field(
        default=None, alias="learningObjectiveSet"
    )
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# GRADEBOOK: RESULT INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class ResultCreateInput(BaseModel):
    """
    Input for creating a OneRoster result (grade).
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    line_item: Ref = Field(alias="lineItem")
    student: Ref
    class_: Ref | None = Field(default=None, alias="class")
    score_date: str = Field(alias="scoreDate")
    score_status: ScoreStatus = Field(alias="scoreStatus")
    score: float | None = None
    text_score: str | None = Field(default=None, alias="textScore")
    status: Status
    score_scale: Ref | None = Field(default=None, alias="scoreScale")
    comment: str | None = None
    learning_objective_set: list[LearningObjectiveScoreSetItemInput] | None = Field(
        default=None, alias="learningObjectiveSet"
    )
    in_progress: str = Field(default=cast("str", None), alias="inProgress")
    incomplete: str = cast("str", None)
    late: str = cast("str", None)
    missing: str = cast("str", None)
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# GRADEBOOK: SCORE SCALE INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class ScoreScaleValueInput(BaseModel):
    """Score scale value entry."""

    item_value_lhs: NonEmptyString = Field(alias="itemValueLHS")
    item_value_rhs: NonEmptyString = Field(alias="itemValueRHS")
    value: str | None = None
    description: str | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class ScoreScaleCreateInput(BaseModel):
    """
    Input for creating a OneRoster score scale.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    title: NonEmptyString
    status: Status
    type: NonEmptyString
    class_: Ref = Field(alias="class")
    course: Ref | None = None
    score_scale_value: Annotated[list[ScoreScaleValueInput], Field(min_length=1)] = Field(
        alias="scoreScaleValue"
    )
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# RESOURCE INPUT
# ═══════════════════════════════════════════════════════════════════════════════

DurationString = Annotated[StrictStr, Field(pattern=r"^\d{2}:\d{2}:\d{2}(\.\d{2})?$")]
StrictNumber = StrictInt | StrictFloat


class FastFailConfig(BaseModel):
    """Fast-fail configuration for interactive resources."""

    consecutive_failures: Annotated[int | None, Field(ge=1, alias="consecutiveFailures")] = None
    stagnation_limit: Annotated[int | None, Field(ge=1, alias="stagnationLimit")] = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class _TypedResourceMetadataBase(BaseModel):
    """Common typed resource metadata fields; preserves unknown extension keys."""

    type: ResourceType
    subject: TimebackSubject | None = None
    grades: list[int] | None = None
    language: StrictStr | None = None
    xp: StrictNumber | None = None
    url: HttpUrl | None = None
    keywords: list[StrictStr] | None = None
    learning_objective_set: list[LearningObjectiveSetItemInput] | None = Field(
        default=None, alias="learningObjectiveSet"
    )
    lesson_type: StrictStr | None = Field(default=None, alias="lessonType")

    _coerce_grades = field_validator("grades", mode="before")(_coerce_grades_before)

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class QtiMetadata(_TypedResourceMetadataBase):
    type: Literal["qti"]
    sub_type: QtiSubType = Field(alias="subType")
    question_type: QuestionType | None = Field(default=None, alias="questionType")
    difficulty: Difficulty | None = None


class TextMetadata(_TypedResourceMetadataBase):
    type: Literal["text"]
    format: StrictStr
    author: StrictStr | None = None
    page_count: StrictNumber | None = Field(default=None, alias="pageCount")


class AudioMetadata(_TypedResourceMetadataBase):
    type: Literal["audio"]
    duration: DurationString | None = None
    format: StrictStr
    speaker: StrictStr | None = None


class VideoMetadata(_TypedResourceMetadataBase):
    type: Literal["video"]
    duration: DurationString | None = None
    captions_available: StrictBool | None = Field(default=None, alias="captionsAvailable")
    format: StrictStr


class InteractiveMetadata(_TypedResourceMetadataBase):
    type: Literal["interactive"]
    launch_url: HttpUrl | None = Field(default=None, alias="launchUrl")
    tool_provider: StrictStr | None = Field(default=None, alias="toolProvider")
    instructional_method: StrictStr | None = Field(default=None, alias="instructionalMethod")
    course_id_on_fail: StrictStr | None = Field(default=None, alias="courseIdOnFail")
    fail_fast: FastFailConfig | None = Field(default=None, alias="failFast")


class VisualMetadata(_TypedResourceMetadataBase):
    type: Literal["visual"]
    format: StrictStr
    resolution: StrictStr | None = None


class CourseMaterialMetadata(_TypedResourceMetadataBase):
    type: Literal["course-material"]
    sub_type: CourseMaterialSubType = Field(alias="subType")
    author: StrictStr | None = None
    format: StrictStr
    instructional_method: StrictStr | None = Field(default=None, alias="instructionalMethod")


class AssessmentBankMetadata(_TypedResourceMetadataBase):
    type: Literal["assessment-bank"]
    resources: list[StrictStr]


TypedResourceMetadata = Annotated[
    QtiMetadata
    | TextMetadata
    | AudioMetadata
    | VideoMetadata
    | InteractiveMetadata
    | VisualMetadata
    | CourseMaterialMetadata
    | AssessmentBankMetadata,
    Field(discriminator="type"),
]

_TYPED_RESOURCE_METADATA_ADAPTER = TypeAdapter(TypedResourceMetadata)
_FAST_FAIL_CONFIG_ADAPTER = TypeAdapter(FastFailConfig)

_RESERVED_RESOURCE_METADATA_KEYS = frozenset(
    {
        # Keys that are the same in camelCase and snake_case
        "type",
        "subject",
        "grades",
        "language",
        "xp",
        "url",
        "keywords",
        "difficulty",
        "format",
        "author",
        "duration",
        "speaker",
        "resolution",
        "resources",
        # camelCase form (from JSON / transport)
        "learningObjectiveSet",
        "lessonType",
        "subType",
        "questionType",
        "pageCount",
        "captionsAvailable",
        "launchUrl",
        "toolProvider",
        "instructionalMethod",
        "courseIdOnFail",
        # snake_case form (from Python callers)
        "learning_objective_set",
        "lesson_type",
        "sub_type",
        "question_type",
        "page_count",
        "captions_available",
        "launch_url",
        "tool_provider",
        "instructional_method",
        "course_id_on_fail",
    }
)


def _validate_resource_metadata(metadata: dict[str, Any] | None) -> dict[str, Any] | None:
    """
    Validate resource metadata.

    If ``type`` is present the metadata is validated against the corresponding
    typed schema while still allowing additional extension keys. Otherwise, any
    key that overlaps with the reserved typed-metadata key set is rejected.
    """
    if metadata is None:
        return metadata

    if not isinstance(metadata, dict):
        raise ValueError("metadata must be a dict")

    if "type" in metadata:
        validated = _TYPED_RESOURCE_METADATA_ADAPTER.validate_python(metadata)
        return validated.model_dump(mode="json", by_alias=True, exclude_unset=True)

    # Normalise camelCase → snake_case before validation
    if "failFast" in metadata:
        rebuilt = {k: v for k, v in metadata.items() if k != "failFast"}
        rebuilt.setdefault("fail_fast", metadata["failFast"])
        metadata = rebuilt

    if "fail_fast" in metadata:
        validated_fail_fast = _FAST_FAIL_CONFIG_ADAPTER.validate_python(metadata["fail_fast"])
        metadata = {
            **metadata,
            "fail_fast": validated_fail_fast.model_dump(mode="json", exclude_unset=True),
        }

    reserved_found = [k for k in metadata if k in _RESERVED_RESOURCE_METADATA_KEYS]
    if reserved_found:
        keys_str = ", ".join(f"`{k}`" for k in reserved_found)
        raise ValueError(f"metadata keys {keys_str} require a valid `type` discriminator")

    return metadata


class ResourceCreateInput(BaseModel):
    """
    Input for creating a OneRoster resource.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    title: NonEmptyString
    vendor_resource_id: NonEmptyString = Field(alias="vendorResourceId")
    roles: list[RoleType] | None = None
    importance: RoleType | None = None
    vendor_id: NonEmptyString | None = Field(default=None, alias="vendorId")
    application_id: NonEmptyString | None = Field(default=None, alias="applicationId")
    status: Status | None = None
    metadata: dict[str, Any] | None = None

    @field_validator("metadata", mode="after")
    @classmethod
    def _check_metadata(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _validate_resource_metadata(v)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class ResourceUpdateInput(BaseModel):
    """
    Input for updating a OneRoster resource.

    Mirrors ``ResourceCreateInput.partial()`` from the TypeScript client:
    every field is optional, but fields remain validated when present.
    """

    sourced_id: NonEmptyString = Field(default=cast("NonEmptyString", None), alias="sourcedId")
    title: NonEmptyString = cast("NonEmptyString", None)
    vendor_resource_id: NonEmptyString = Field(
        default=cast("NonEmptyString", None), alias="vendorResourceId"
    )
    roles: list[RoleType] = cast("list[RoleType]", None)
    importance: RoleType = cast("RoleType", None)
    vendor_id: NonEmptyString | None = Field(default=None, alias="vendorId")
    application_id: NonEmptyString | None = Field(default=None, alias="applicationId")
    status: Status = cast("Status", None)
    metadata: dict[str, Any] | None = None

    @field_validator("metadata", mode="after")
    @classmethod
    def _check_metadata(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _validate_resource_metadata(v)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class AgentInput(BaseModel):
    """
    Input for adding an agent (parent/guardian) relationship.
    """

    agent_sourced_id: NonEmptyString = Field(alias="agentSourcedId")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# DEMOGRAPHICS INPUT
# ═══════════════════════════════════════════════════════════════════════════════


StringBoolean = Literal["true", "false"]


class DemographicsCreateInput(BaseModel):
    """
    Input for creating/updating demographics.
    """

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    status: Status | None = None
    metadata: dict[str, Any] | None = None
    birth_date: str | None = Field(default=None, alias="birthDate")
    sex: Literal["male", "female"] | None = None
    american_indian_or_alaska_native: StringBoolean | None = Field(
        default=None, alias="americanIndianOrAlaskaNative"
    )
    asian: StringBoolean | None = None
    black_or_african_american: StringBoolean | None = Field(
        default=None, alias="blackOrAfricanAmerican"
    )
    native_hawaiian_or_other_pacific_islander: StringBoolean | None = Field(
        default=None, alias="nativeHawaiianOrOtherPacificIslander"
    )
    white: StringBoolean | None = None
    demographic_race_two_or_more_races: StringBoolean | None = Field(
        default=None, alias="demographicRaceTwoOrMoreRaces"
    )
    hispanic_or_latino_ethnicity: StringBoolean | None = Field(
        default=None, alias="hispanicOrLatinoEthnicity"
    )
    country_of_birth_code: str | None = Field(default=None, alias="countryOfBirthCode")
    state_of_birth_abbreviation: str | None = Field(default=None, alias="stateOfBirthAbbreviation")
    city_of_birth: str | None = Field(default=None, alias="cityOfBirth")
    public_school_residence_status: str | None = Field(
        default=None, alias="publicSchoolResidenceStatus"
    )

    @field_validator("birth_date")
    @classmethod
    def _validate_birth_date(cls, v: str | None) -> str | None:
        if v is not None and not re.match(r"^\d{4}-\d{2}-\d{2}$", v):
            raise ValueError("birthDate must be YYYY-MM-DD")
        return v

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# ASSESSMENT INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class AssessmentLineItemCreateInput(BaseModel):
    """
    Input for creating/updating an assessment line item.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status
    date_last_modified: str | None = Field(default=None, alias="dateLastModified")
    title: NonEmptyString
    description: str | None = None
    class_: Ref | None = Field(default=None, alias="class")
    parent_assessment_line_item: Ref | None = Field(default=None, alias="parentAssessmentLineItem")
    score_scale: Ref | None = Field(default=None, alias="scoreScale")
    result_value_min: float | None = Field(default=None, alias="resultValueMin")
    result_value_max: float | None = Field(default=None, alias="resultValueMax")
    component: Ref | None = None
    component_resource: Ref | None = Field(default=None, alias="componentResource")
    learning_objective_set: list[LearningObjectiveSetItemInput] | None = Field(
        default=None, alias="learningObjectiveSet"
    )
    course: Ref | None = None
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class AssessmentResultCreateInput(BaseModel):
    """
    Input for creating/updating an assessment result.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    status: Status
    date_last_modified: str | None = Field(default=None, alias="dateLastModified")
    assessment_line_item: Ref = Field(alias="assessmentLineItem")
    student: Ref
    score: float | None = None
    text_score: str | None = Field(default=None, alias="textScore")
    score_date: NonEmptyString = Field(alias="scoreDate")
    score_scale: Ref | None = Field(default=None, alias="scoreScale")
    score_percentile: float | None = Field(default=None, alias="scorePercentile")
    score_status: ScoreStatus = Field(alias="scoreStatus")
    comment: str | None = None
    learning_objective_set: list[LearningObjectiveScoreSetItemInput] | None = Field(
        default=None, alias="learningObjectiveSet"
    )
    in_progress: str | None = Field(default=None, alias="inProgress")
    incomplete: str | None = None
    late: str | None = None
    missing: str | None = None
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# COURSE COMPONENT INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class CourseComponentCreateInput(BaseModel):
    """
    Input for creating/updating a course component.

    Normalises the legacy ``courseComponent`` field to ``parent``.
    """

    sourced_id: str | None = Field(default=None, alias="sourcedId")
    title: NonEmptyString
    course: Ref
    status: Status
    sort_order: int = Field(default=cast("int", None), alias="sortOrder")
    parent: Ref | None = None
    course_component: Ref | None = Field(default=None, alias="courseComponent", exclude=True)
    prerequisites: list[str] | None = None
    prerequisite_criteria: str | None = Field(default=None, alias="prerequisiteCriteria")
    unlock_date: str | None = Field(default=None, alias="unlockDate")
    metadata: dict[str, Any] | None = None

    @model_validator(mode="after")
    def _normalize_course_component_to_parent(self) -> CourseComponentCreateInput:
        """Map legacy ``courseComponent`` to ``parent`` when ``parent`` was not provided.

        An explicit ``parent: null`` is preserved (signals "clear parent").
        Only when the caller omitted ``parent`` entirely do we fall back to
        ``courseComponent``.
        """
        if "parent" not in self.model_fields_set and self.course_component is not None:
            self.parent = self.course_component
            self.model_fields_set.add("parent")
        self.course_component = None
        return self

    @field_validator("unlock_date", mode="before")
    @classmethod
    def _normalize_unlock_date(cls, v: str | None) -> str | None:
        """Accept date-only values (YYYY-MM-DD) and normalise to ISO datetime."""
        if v is None:
            return v
        if isinstance(v, str) and "T" not in v:
            import re

            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
                raise ValueError(
                    f"unlock_date must be an ISO date (YYYY-MM-DD) or datetime, got '{v}'"
                )
            return f"{v}T00:00:00Z"
        return v

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# COMPONENT RESOURCE INPUT
# ═══════════════════════════════════════════════════════════════════════════════


class ComponentResourceCreateInput(BaseModel):
    """
    Input for creating a component resource.
    """

    sourced_id: NonEmptyString = Field(alias="sourcedId")
    title: NonEmptyString
    course_component: Ref = Field(alias="courseComponent")
    resource: Ref
    status: Status
    sort_order: int = Field(default=cast("int", None), alias="sortOrder")
    lesson_type: LessonType | None = Field(default=None, alias="lessonType")
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


__all__ = [
    "AcademicSessionCreateInput",
    "AgentInput",
    "AssessmentLineItemCreateInput",
    "AssessmentResultCreateInput",
    "CategoryCreateInput",
    "ClassCreateInput",
    "ClassUpdateInput",
    "ComponentResourceCreateInput",
    "CourseComponentCreateInput",
    "CourseCreateInput",
    "DemographicsCreateInput",
    "EnrollInput",
    "EnrollmentCreateInput",
    "GuidRef",
    "LearningObjectiveResultInput",
    "LearningObjectiveScoreSetItemInput",
    "LearningObjectiveSetItemInput",
    "LineItemCreateInput",
    "OrgCreateInput",
    "Ref",
    "ResourceCreateInput",
    "ResourceUpdateInput",
    "ResultCreateInput",
    "SchoolCreateInput",
    "ScoreScaleCreateInput",
    "ScoreScaleValueInput",
    "UserCreateInput",
    "UserIdInput",
    "UserRoleInput",
]
