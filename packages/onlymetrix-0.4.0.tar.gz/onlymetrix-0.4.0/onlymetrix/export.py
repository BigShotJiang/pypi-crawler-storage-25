"""omx export — compile IR to external formats.

Currently supported:
  --format metricflow   → dbt MetricFlow semantic_models + metrics YAML
"""

from __future__ import annotations

import sys
from typing import Any

import click

from onlymetrix.metricflow import export_metricflow, DEFAULT_OUTPUT_PATH


def run_export(
    fmt: str,
    output_path: str | None,
    dry_run: bool,
    client: Any,
) -> int:
    """Execute export. Returns exit code (0 = success, 1 = error, 2 = warnings)."""
    if fmt != "metricflow":
        click.echo(f"  Unknown format: {fmt}. Supported: metricflow", err=True)
        return 1

    # Fetch IR from compiler
    click.echo()
    click.echo("  Fetching compiled IR…")
    try:
        data = client.compiler.status()
    except Exception as e:
        click.echo(f"  Error fetching IR: {e}", err=True)
        return 1

    ir_metrics = data.get("metrics", [])
    if not ir_metrics:
        click.echo("  No compiled metrics found. Run: omx sync --source dbt", err=True)
        return 1

    click.echo(f"  Found {len(ir_metrics)} compiled metrics")

    # Export
    dest = output_path or DEFAULT_OUTPUT_PATH
    try:
        out_path, content, structured, opaque = export_metricflow(
            ir_metrics,
            output_path=output_path,
            dry_run=dry_run,
            source="omx export --format metricflow",
        )
    except Exception as e:
        click.echo(f"  Export failed: {e}", err=True)
        return 1

    # Output
    click.echo()

    if dry_run:
        click.echo("  ─── DRY RUN — no file written ───")
        click.echo()
        click.echo(content)
        click.echo()
    else:
        click.echo(f"  Written: {out_path}")
        click.echo()

    # Summary
    _print_summary(ir_metrics, structured, opaque)

    if dry_run:
        click.echo()
        click.echo("  Run without --dry-run to write the file.")

    click.echo()
    return 0 if opaque == 0 else 2


def _print_summary(metrics: list[dict], structured: int, opaque: int) -> None:
    """Print per-metric status table."""
    name_w = max((len(m["name"]) for m in metrics), default=20)

    for m in metrics:
        name = m["name"]
        kind = m.get("kind", "unknown")
        sem = m.get("semantic", {})
        importance = sem.get("importance", "—")
        taxonomy = " › ".join(sem.get("taxonomy_path", [])) or "—"
        tags = ", ".join(sem.get("tags", [])) or "—"

        if kind == "structured":
            measures = m.get("measures", [])
            agg_summary = ", ".join(
                f"{me['alias']}({me['function'].lower()})" for me in measures
            ) or "—"
            icon = "✓"
            label = f"structured  · importance {importance}  · {agg_summary}"
        else:
            icon = "~"
            label = f"opaque      · manual refinement needed"

        click.echo(f"  {icon} {name.ljust(name_w)}  {label}")

    click.echo()
    click.echo("  " + "─" * 60)

    structured_str = f"{structured} structured"
    opaque_str = f"{opaque} opaque" if opaque else ""
    parts = [p for p in [structured_str, opaque_str] if p]
    click.echo(f"  {' · '.join(parts)}")
    click.echo()

    if opaque > 0:
        click.echo(
            f"  ~ {opaque} opaque metric{'s' if opaque > 1 else ''} exported with placeholder measures."
        )
        click.echo("    Review and replace expr: fields before running dbt compile.")
    else:
        click.echo("  ✓ All metrics structured — safe to run dbt compile.")
