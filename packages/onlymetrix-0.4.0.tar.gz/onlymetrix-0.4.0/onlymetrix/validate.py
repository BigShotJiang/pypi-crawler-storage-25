"""IR → MetricFlow validation gate.

Checks:
  ERRORS (always fail):
    - semantic model missing required fields (name, model, measures)
    - metric measure reference missing from its semantic model
    - non-opaque metric has no measures

  WARNINGS (fail only with --strict):
    - metric is opaque (placeholder measures, needs manual refinement)
    - description is empty
    - taxonomy is empty
    - importance is 0 (not set)
    - multi-measure metric has derived expr that is a placeholder
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any

from onlymetrix.metricflow import build_semantic_model, build_metric


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class ValidationIssue:
    severity: str        # "error" | "warning"
    metric_name: str
    check: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass
class ValidationResult:
    passed: bool
    errors: int
    warnings: int
    issues: list[ValidationIssue] = field(default_factory=list)
    metrics_checked: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "errors": self.errors,
            "warnings": self.warnings,
            "metrics_checked": self.metrics_checked,
            "issues": [i.to_dict() for i in self.issues],
        }


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------


def _check_metric(
    ir: dict[str, Any],
    sm: dict[str, Any],
    m: dict[str, Any],
    strict: bool,
) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    name = ir["name"]
    is_opaque = ir.get("kind") == "opaque"

    # ── Errors ──

    # SM missing required keys
    for required in ("name", "model", "measures"):
        if required not in sm:
            issues.append(ValidationIssue(
                severity="error",
                metric_name=name,
                check="sm_missing_field",
                message=f"Semantic model missing required field: {required!r}",
            ))

    # Non-opaque metric must have at least one measure in IR
    if not is_opaque and not ir.get("measures"):
        issues.append(ValidationIssue(
            severity="error",
            metric_name=name,
            check="no_measures",
            message="Structured metric has no measures in IR",
        ))

    # Metric type_params.measure must reference an existing SM measure
    measure_names = {sm_m["name"] for sm_m in sm.get("measures", [])}
    tp = m.get("type_params", {})
    if m.get("type") == "simple" and "measure" in tp:
        ref = tp["measure"]
        if ref not in measure_names:
            issues.append(ValidationIssue(
                severity="error",
                metric_name=name,
                check="missing_measure_ref",
                message=f"Metric references measure {ref!r} not found in semantic model",
            ))

    # ── Warnings (promoted to errors with --strict) ──

    def warn(check: str, msg: str) -> None:
        issues.append(ValidationIssue(
            severity="error" if strict else "warning",
            metric_name=name,
            check=check,
            message=msg,
        ))

    if is_opaque:
        warn("opaque_metric", "Metric is opaque — placeholder measures need manual refinement before dbt compile")

    semantic = ir.get("semantic", {})

    if not semantic.get("description", "").strip():
        warn("empty_description", "Metric has no description")

    taxonomy = semantic.get("taxonomy_path", [])
    if not taxonomy:
        warn("empty_taxonomy", "Metric has no taxonomy path")

    importance = semantic.get("importance", 0)
    if importance == 0:
        warn("zero_importance", "Metric importance is 0 (not classified)")

    # Multi-measure derived expr placeholder check
    # Keyed off the expr content — a self-referential metric() call means the expr
    # was never refined. measure() calls are valid and should not trigger this.
    if m.get("type") == "derived" and not is_opaque:
        expr = tp.get("expr", "")
        if f"metric('{name}')" in expr:
            warn(
                "derived_placeholder_expr",
                f"Self-referential metric('{name}') call in derived expr — "
                "use measure() to reference measures from the same semantic model",
            )

    return issues


# ---------------------------------------------------------------------------
# Main validate function
# ---------------------------------------------------------------------------


def validate_metricflow(
    ir_metrics: list[dict[str, Any]],
    strict: bool = False,
) -> ValidationResult:
    """Validate IR metrics against MetricFlow rules.

    Returns a ValidationResult with all issues found.
    With strict=True, warnings are treated as errors for pass/fail purposes.
    """
    all_issues: list[ValidationIssue] = []

    for ir in ir_metrics:
        sm = build_semantic_model(ir)
        m = build_metric(ir, sm)
        issues = _check_metric(ir, sm, m, strict=strict)
        all_issues.extend(issues)

    errors = sum(1 for i in all_issues if i.severity == "error")
    warnings = sum(1 for i in all_issues if i.severity == "warning")
    passed = errors == 0

    return ValidationResult(
        passed=passed,
        errors=errors,
        warnings=warnings,
        issues=all_issues,
        metrics_checked=len(ir_metrics),
    )


# ---------------------------------------------------------------------------
# run_validate — called from CLI
# ---------------------------------------------------------------------------


def run_validate(
    fmt: str,
    strict: bool,
    output_fmt: str,
    client: Any,
) -> int:
    """Execute validate. Returns exit code (0 = pass, 1 = errors, 2 = warnings)."""
    import click

    if fmt != "metricflow":
        click.echo(f"  Unknown format: {fmt}. Supported: metricflow", err=True)
        return 1

    quiet = output_fmt == "json"

    if not quiet:
        click.echo()
        click.echo("  Fetching compiled IR…")
    try:
        data = client.compiler.status()
    except Exception as e:
        click.echo(f"  Error fetching IR: {e}", err=True)
        return 1

    ir_metrics = data.get("metrics", [])
    if not ir_metrics:
        click.echo("  No compiled metrics found. Run: omx sync --source dbt", err=True)
        return 1

    if not quiet:
        click.echo(f"  Validating {len(ir_metrics)} compiled metrics…")
        click.echo()

    result = validate_metricflow(ir_metrics, strict=strict)

    if output_fmt == "json":
        click.echo(json.dumps(result.to_dict(), indent=2))
        click.echo()
        return _exit_code(result)

    # Human-readable output
    _print_issues(result, strict=strict)

    return _exit_code(result)


def _exit_code(result: ValidationResult) -> int:
    if result.errors > 0:
        return 1
    if result.warnings > 0:
        return 2
    return 0


def _print_issues(result: ValidationResult, strict: bool) -> None:
    import click

    if not result.issues:
        click.echo(f"  ✓ All {result.metrics_checked} metrics passed validation")
        click.echo()
        return

    # Group by metric
    by_metric: dict[str, list[ValidationIssue]] = {}
    for issue in result.issues:
        by_metric.setdefault(issue.metric_name, []).append(issue)

    for metric_name, issues in by_metric.items():
        for issue in issues:
            icon = "✗" if issue.severity == "error" else "~"
            click.echo(f"  {icon} {metric_name}  [{issue.check}]  {issue.message}")

    click.echo()
    click.echo("  " + "─" * 60)

    parts = []
    if result.errors:
        parts.append(f"{result.errors} error{'s' if result.errors != 1 else ''}")
    if result.warnings:
        parts.append(f"{result.warnings} warning{'s' if result.warnings != 1 else ''}")
    if not parts:
        parts = ["0 issues"]

    flag = " (strict mode)" if strict else ""
    click.echo(f"  {' · '.join(parts)}{flag}")
    click.echo()

    if result.errors > 0:
        click.echo("  ✗ Validation failed — fix errors before running dbt compile.")
    elif result.warnings > 0:
        if strict:
            click.echo("  ✗ Validation failed — warnings treated as errors in strict mode.")
        else:
            click.echo("  ~ Warnings found — review before running dbt compile.")
            click.echo("    Use --strict to treat warnings as errors.")
    click.echo()
