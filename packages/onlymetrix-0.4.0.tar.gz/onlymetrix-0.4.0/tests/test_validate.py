"""Tests for onlymetrix.validate — MetricFlow validation gate."""

from __future__ import annotations

import json
import unittest
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from onlymetrix.cli import cli
from onlymetrix.validate import (
    ValidationIssue,
    ValidationResult,
    validate_metricflow,
)

# ---------------------------------------------------------------------------
# Fixtures (same IR shapes as test_export.py)
# ---------------------------------------------------------------------------

STRUCTURED_SIMPLE = {
    "name": "total_revenue",
    "kind": "structured",
    "measures": [{"alias": "revenue_usd", "function": "Sum"}],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "Total paid revenue in USD",
        "importance": 7,
        "is_primary": True,
        "tags": ["finance"],
        "taxonomy_path": ["Business", "Revenue", "Totals"],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

STRUCTURED_NO_DESCRIPTION = {
    "name": "revenue_raw",
    "kind": "structured",
    "measures": [{"alias": "revenue_usd", "function": "Sum"}],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "",
        "importance": 4,
        "is_primary": False,
        "tags": ["finance"],
        "taxonomy_path": ["Business", "Revenue"],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

STRUCTURED_NO_TAXONOMY = {
    "name": "active_users",
    "kind": "structured",
    "measures": [{"alias": "user_count", "function": "Count"}],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "Active user count",
        "importance": 5,
        "is_primary": False,
        "tags": [],
        "taxonomy_path": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

STRUCTURED_ZERO_IMPORTANCE = {
    "name": "unclassified_metric",
    "kind": "structured",
    "measures": [{"alias": "value", "function": "Sum"}],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "Some metric",
        "importance": 0,
        "is_primary": False,
        "tags": [],
        "taxonomy_path": ["Business"],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

STRUCTURED_MULTI_MEASURE = {
    "name": "top_products",
    "kind": "structured",
    "measures": [
        {"alias": "revenue_usd", "function": "Sum"},
        {"alias": "units_sold", "function": "Sum"},
    ],
    "dimensions": [{"name": "product", "type": "Categorical { values: [] }"}],
    "joins": [{"from": "order_items", "to": "products", "cardinality": "many_to_one", "fanout_risk": False}],
    "semantic": {
        "description": "Top products by revenue",
        "importance": 10,
        "is_primary": True,
        "tags": ["finance", "products"],
        "taxonomy_path": ["Business", "Revenue", "Segmented"],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

OPAQUE_METRIC = {
    "name": "enterprise_churn_rate",
    "kind": "opaque",
    "measures": [],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "Enterprise churn rate",
        "importance": 3,
        "is_primary": False,
        "tags": [],
        "taxonomy_path": ["Business", "Operations"],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

OPAQUE_NO_DESCRIPTION = {
    "name": "mystery_metric",
    "kind": "opaque",
    "measures": [],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "",
        "importance": 0,
        "is_primary": False,
        "tags": [],
        "taxonomy_path": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
}

# A "clean" metric — fully structured, described, classified
CLEAN_METRIC = STRUCTURED_SIMPLE


# ---------------------------------------------------------------------------
# TestValidationResult
# ---------------------------------------------------------------------------


class TestValidationResult(unittest.TestCase):
    def test_passed_when_no_errors(self):
        r = ValidationResult(passed=True, errors=0, warnings=0, metrics_checked=1)
        self.assertTrue(r.passed)

    def test_failed_when_errors(self):
        r = ValidationResult(passed=False, errors=1, warnings=0, metrics_checked=1)
        self.assertFalse(r.passed)

    def test_to_dict_keys(self):
        r = ValidationResult(passed=True, errors=0, warnings=2, issues=[], metrics_checked=3)
        d = r.to_dict()
        self.assertIn("passed", d)
        self.assertIn("errors", d)
        self.assertIn("warnings", d)
        self.assertIn("metrics_checked", d)
        self.assertIn("issues", d)

    def test_issues_serialise_to_list(self):
        issue = ValidationIssue(severity="warning", metric_name="m", check="c", message="msg")
        r = ValidationResult(passed=True, errors=0, warnings=1, issues=[issue], metrics_checked=1)
        d = r.to_dict()
        self.assertEqual(len(d["issues"]), 1)
        self.assertEqual(d["issues"][0]["check"], "c")


# ---------------------------------------------------------------------------
# TestValidateClean
# ---------------------------------------------------------------------------


class TestValidateClean(unittest.TestCase):
    def test_clean_metric_passes(self):
        result = validate_metricflow([CLEAN_METRIC])
        self.assertTrue(result.passed)
        self.assertEqual(result.errors, 0)
        self.assertEqual(result.warnings, 0)
        self.assertEqual(result.metrics_checked, 1)

    def test_multi_measure_passes(self):
        result = validate_metricflow([STRUCTURED_MULTI_MEASURE])
        self.assertTrue(result.passed)
        self.assertEqual(result.errors, 0)

    def test_empty_list_passes(self):
        result = validate_metricflow([])
        self.assertTrue(result.passed)
        self.assertEqual(result.metrics_checked, 0)


# ---------------------------------------------------------------------------
# TestValidateWarnings
# ---------------------------------------------------------------------------


class TestValidateWarnings(unittest.TestCase):
    def test_opaque_triggers_warning(self):
        result = validate_metricflow([OPAQUE_METRIC])
        checks = [i.check for i in result.issues]
        self.assertIn("opaque_metric", checks)
        opaque_issues = [i for i in result.issues if i.check == "opaque_metric"]
        self.assertEqual(opaque_issues[0].severity, "warning")

    def test_empty_description_triggers_warning(self):
        result = validate_metricflow([STRUCTURED_NO_DESCRIPTION])
        checks = [i.check for i in result.issues]
        self.assertIn("empty_description", checks)

    def test_empty_taxonomy_triggers_warning(self):
        result = validate_metricflow([STRUCTURED_NO_TAXONOMY])
        checks = [i.check for i in result.issues]
        self.assertIn("empty_taxonomy", checks)

    def test_zero_importance_triggers_warning(self):
        result = validate_metricflow([STRUCTURED_ZERO_IMPORTANCE])
        checks = [i.check for i in result.issues]
        self.assertIn("zero_importance", checks)

    def test_multi_measure_measure_expr_no_placeholder_warning(self):
        # measure('x') + measure('y') is valid — must NOT trigger derived_placeholder_expr
        result = validate_metricflow([STRUCTURED_MULTI_MEASURE])
        checks = [i.check for i in result.issues]
        self.assertNotIn("derived_placeholder_expr", checks)

    def test_self_referential_metric_expr_triggers_warning(self):
        # metric('name') + metric('name') is the old bad pattern — must still warn
        bad_metric = {
            "name": "bad_derived",
            "kind": "structured",
            "measures": [
                {"alias": "a", "function": "Sum"},
                {"alias": "b", "function": "Sum"},
            ],
            "dimensions": [],
            "joins": [],
            "semantic": {
                "description": "test",
                "importance": 5,
                "is_primary": False,
                "tags": [],
                "taxonomy_path": ["Business"],
            },
            "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
        }
        # Manually patch type_params to simulate old self-referential output
        from onlymetrix.metricflow import build_semantic_model, build_metric
        sm = build_semantic_model(bad_metric)
        m = build_metric(bad_metric, sm)
        m["type"] = "derived"
        m["type_params"] = {"expr": "metric('bad_derived') + metric('bad_derived')"}
        # Validate by re-running check logic directly via a patched IR
        from onlymetrix.validate import _check_metric
        issues = _check_metric(bad_metric, sm, m, strict=False)
        checks = [i.check for i in issues]
        self.assertIn("derived_placeholder_expr", checks)

    def test_warning_does_not_set_passed_false(self):
        result = validate_metricflow([OPAQUE_METRIC])
        # warnings present but no errors → passed should be True
        self.assertTrue(result.passed)
        self.assertGreater(result.warnings, 0)

    def test_multiple_warnings_counted(self):
        result = validate_metricflow([OPAQUE_NO_DESCRIPTION])
        # opaque + empty description + empty taxonomy + zero importance = 4 warnings
        self.assertGreaterEqual(result.warnings, 3)


# ---------------------------------------------------------------------------
# TestValidateStrict
# ---------------------------------------------------------------------------


class TestValidateStrict(unittest.TestCase):
    def test_strict_promotes_warning_to_error(self):
        result = validate_metricflow([OPAQUE_METRIC], strict=True)
        opaque_issues = [i for i in result.issues if i.check == "opaque_metric"]
        self.assertEqual(opaque_issues[0].severity, "error")

    def test_strict_makes_passed_false_on_warning(self):
        result = validate_metricflow([OPAQUE_METRIC], strict=True)
        self.assertFalse(result.passed)
        self.assertGreater(result.errors, 0)

    def test_strict_clean_metric_still_passes(self):
        result = validate_metricflow([CLEAN_METRIC], strict=True)
        self.assertTrue(result.passed)
        self.assertEqual(result.errors, 0)


# ---------------------------------------------------------------------------
# TestValidateCLI
# ---------------------------------------------------------------------------


def _make_client(metrics: list[dict]) -> MagicMock:
    client = MagicMock()
    client.__enter__ = MagicMock(return_value=client)
    client.__exit__ = MagicMock(return_value=False)
    client.compiler.status.return_value = {"metrics": metrics}
    return client


class TestValidateCLI(unittest.TestCase):
    def test_exit_0_all_clean(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([CLEAN_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow"])
        self.assertEqual(result.exit_code, 0)

    def test_exit_2_warnings_only(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([OPAQUE_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow"])
        self.assertEqual(result.exit_code, 2)

    def test_exit_1_strict_with_warnings(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([OPAQUE_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow", "--strict"])
        self.assertEqual(result.exit_code, 1)

    def test_json_output_is_valid_json(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([CLEAN_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow", "--output", "json"])
        # Find the JSON block in output
        out = result.output.strip()
        obj = json.loads(out)
        self.assertIn("passed", obj)
        self.assertIn("issues", obj)

    def test_json_output_strict_failure(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([OPAQUE_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow", "--strict", "--output", "json"])
        out = result.output.strip()
        obj = json.loads(out)
        self.assertFalse(obj["passed"])
        self.assertGreater(obj["errors"], 0)

    def test_no_metrics_returns_error(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow"])
        self.assertEqual(result.exit_code, 1)

    def test_text_output_shows_pass_message(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([CLEAN_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow"])
        self.assertIn("passed validation", result.output)

    def test_text_output_shows_opaque_warning(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([OPAQUE_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow"])
        self.assertIn("opaque_metric", result.output)

    def test_text_output_strict_note(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client", return_value=_make_client([OPAQUE_METRIC])):
            result = runner.invoke(cli, ["validate", "--format", "metricflow", "--strict"])
        self.assertIn("strict", result.output)


if __name__ == "__main__":
    unittest.main()
