from manuscript import Pipeline
from manuscript.utils.visualization import visualize_page
from manuscript.detectors import YOLO, EAST
from manuscript.recognizers import TRBA

img_path = r"example/images/XXXL (1) (2).jpeg"

pipeline = Pipeline(
    detector=YOLO(
        score_thresh=0.1,
        weights=r"yolo26s_obb_text_g1",
        axis_aligned_output=False,
    ),
    recognizer=TRBA(weights="trba_lite_g2", region_preparer="quad_warp"),
)
#bbox
#polygon_mask
#quad_warp
result = pipeline.predict(
    img_path,
)

text = pipeline.get_text(result["page"])
print(text)

vis_img = visualize_page(img_path, result["page"])
vis_img.show()
