"""
node_installer.py — custom node installation for kulai

Clones a git repository into the ComfyUI custom_nodes directory and
optionally installs its requirements.txt into the active Python environment.
"""

from __future__ import annotations

import logging
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class NodeInstallResult:
    display_name: str
    repo: str
    success: bool
    skipped: bool = False
    error: str | None = None
    requirements_installed: bool = False


def install_node(
    display_name: str,
    repo_url: str,
    custom_nodes_dir: Path,
) -> NodeInstallResult:
    """
    Clone *repo_url* into *custom_nodes_dir* and install requirements.txt.

    If the target directory already exists the clone is skipped (treated as
    already installed).  requirements.txt is installed into the Python
    interpreter that is currently running kulai (``sys.executable``).

    Args:
        display_name:     Human-readable label for display purposes.
        repo_url:         Git repository URL.
        custom_nodes_dir: Path to the software's custom_nodes folder.

    Returns:
        NodeInstallResult describing the outcome.
    """
    node_dir = custom_nodes_dir / _repo_name(repo_url)

    if node_dir.exists():
        return NodeInstallResult(
            display_name=display_name,
            repo=repo_url,
            success=True,
            skipped=True,
        )

    custom_nodes_dir.mkdir(parents=True, exist_ok=True)

    try:
        subprocess.run(
            ["git", "clone", "--depth", "1", repo_url, str(node_dir)],
            check=True,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        return NodeInstallResult(
            display_name=display_name,
            repo=repo_url,
            success=False,
            error="git not found — install Git and ensure it is on your PATH.",
        )
    except subprocess.CalledProcessError as exc:
        return NodeInstallResult(
            display_name=display_name,
            repo=repo_url,
            success=False,
            error=f"git clone failed: {(exc.stderr or '').strip() or str(exc)}",
        )

    req_file = node_dir / "requirements.txt"
    requirements_installed = False
    if req_file.exists():
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(req_file), "-q"],
                check=True,
                capture_output=True,
                text=True,
            )
            requirements_installed = True
        except subprocess.CalledProcessError as exc:
            logger.warning(
                "requirements.txt install failed for %s: %s",
                display_name,
                (exc.stderr or "").strip() or str(exc),
            )

    return NodeInstallResult(
        display_name=display_name,
        repo=repo_url,
        success=True,
        skipped=False,
        requirements_installed=requirements_installed,
    )


def _repo_name(repo_url: str) -> str:
    """Derive a directory name from a git URL."""
    name = repo_url.rstrip("/").split("/")[-1]
    return name[:-4] if name.endswith(".git") else name
