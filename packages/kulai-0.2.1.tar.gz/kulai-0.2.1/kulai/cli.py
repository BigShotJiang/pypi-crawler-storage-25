"""
cli.py — kulai command-line interface

Entry points:
  resolve       Parse a workflow, resolve assets, prompt for review, download.
  install       Install all dependencies declared in a .kula file.
  generate      Generate a .kula file from a ComfyUI workflow JSON.
  wizard        Interactive step-by-step .kula file builder.
  check         Fast local-only scan — report which assets are already present.
  cache-list    Show all cached asset mappings.
  cache-clear   Remove one or all cached mappings.
  config-init   Run (or re-run) first-time setup wizard.
  config-show   Print active config with API keys redacted.
"""

from __future__ import annotations

import json
import logging
import os
import re
import traceback
from pathlib import Path
from typing import Any, Optional

import toml  # type: ignore
import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich import box

from .config import config_exists, get_model_path, infer_model_paths, load_config, write_default_config, SOFTWARE_PROFILES
from .downloader import DownloadTask, Downloader
from .kula_parser import (
    KulaCustomNode, KulaFile, KulaMeta, KulaResource, KulaVariant,
    KULAI_VERSION, parse_kula, write_kula,
)
from .node_installer import install_node
from .parser import parse_workflow
from .resolver import Resolver
from .sources.base import ResolutionResult, ResolvedSource
from .sources.civitai import parse_civitai_url, fetch_civitai_version, extract_civitai_file_info
from .storage import delete_mapping, list_mappings, save_mapping, save_mappings
from .ui import UISession

# ---------------------------------------------------------------------------
# App & module-level singletons
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="kulai",
    help="AI asset and workflow package manager.",
    add_completion=False,
    rich_markup_mode="rich",
)
console = Console()
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# resolve
# ---------------------------------------------------------------------------

@app.command()
def resolve(
    workflow: Optional[Path] = typer.Argument(
        None,
        help=(
            "Path to the ComfyUI workflow JSON file. "
            "If omitted, workflows are discovered from your ComfyUI install directory."
        ),
        exists=False,           # checked manually for nicer error messages
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
    ),
    auto: bool = typer.Option(
        False, "--auto",
        help="Skip prompts; use best guess for HIGH-confidence assets only.",
    ),
    auto_all: bool = typer.Option(
        False, "--auto-all",
        help="Skip prompts; use best guess for ALL assets regardless of confidence.",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Resolve and show what would be downloaded — no files are written.",
    ),
    no_cache: bool = typer.Option(
        False, "--no-cache",
        help="Ignore cached mappings and re-resolve every asset from scratch.",
    ),
    download_dir: Optional[Path] = typer.Option(
        None, "--download-dir",
        help="Override the destination directory for every asset type.",
    ),
    concurrent: Optional[int] = typer.Option(
        None, "--concurrent",
        min=1, max=16,
        help="Number of parallel downloads (overrides config value).",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="Emit DEBUG-level logs.",
    ),
) -> None:
    """
    [bold cyan]Resolve and download[/bold cyan] all model assets referenced in a ComfyUI
    workflow JSON file.

    Resolution order per asset:
      1. Local filesystem  2. Cache  3. Config mappings
      4. HuggingFace       5. Civitai (token required)  6. Heuristic

    If no workflow path is supplied, workflows are discovered automatically
    from your ComfyUI install's [dim]user/default/workflows[/dim] folder and
    presented as a numbered pick-list.

    After resolution you are shown a full pre-download review where you can
    edit sources, skip individual assets, or abort entirely before any file
    is written to disk.
    """
    _setup_logging(verbose)

    try:
        _resolve_workflow(
            workflow=workflow,
            auto=auto,
            auto_all=auto_all,
            dry_run=dry_run,
            no_cache=no_cache,
            download_dir=download_dir,
            concurrent=concurrent,
            verbose=verbose,
        )
    except json.JSONDecodeError as exc:
        console.print(f"[red]✗ Invalid JSON in {workflow}[/red]")
        console.print(f"[red]  Line {exc.lineno}, col {exc.colno}: {exc.msg}[/red]")
        if verbose:
            console.print(f"[dim]{exc}[/dim]")
        raise typer.Exit(code=1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        raise typer.Exit(code=130)
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"[red]✗ Unexpected error: {exc}[/red]")
        if verbose:
            console.print(f"[dim]{traceback.format_exc()}[/dim]")
        else:
            console.print("[dim]Re-run with --verbose for a full traceback.[/dim]")
        raise typer.Exit(code=1)


def _resolve_workflow(
    workflow: Optional[Path],
    auto: bool,
    auto_all: bool,
    dry_run: bool,
    no_cache: bool,
    download_dir: Optional[Path],
    concurrent: Optional[int],
    verbose: bool,
) -> None:
    """
    Core resolve pipeline — separated from the @app.command so that the
    exception handlers in the command wrapper stay clean and focused.
    """

    # ── 1. Config ──────────────────────────────────────────────────────────
    ensure_config()
    config = load_config()

    if concurrent is not None:
        config.setdefault("download", {})["concurrent"] = concurrent

    # ── 2. Validate / discover workflow path ────────────────────────────────
    if workflow is None:
        workflow = _pick_workflow(config)
        if workflow is None:
            console.print("[yellow]No workflow selected — exiting.[/yellow]")
            raise typer.Exit(code=0)

    if not workflow.exists():
        console.print(f"[red]✗ Workflow file not found: {workflow}[/red]")
        raise typer.Exit(code=1)
    if not workflow.is_file():
        console.print(f"[red]✗ Path is not a file: {workflow}[/red]")
        raise typer.Exit(code=1)

    # ── 3. Parse ────────────────────────────────────────────────────────────
    console.print(Rule(f"[bold cyan]kulai[/bold cyan]  [dim]{workflow.name}[/dim]"))

    try:
        assets = parse_workflow(workflow)
    except json.JSONDecodeError:
        raise  # re-raise so the outer handler formats it nicely
    except Exception as exc:
        console.print(f"[red]✗ Error parsing workflow: {exc}[/red]")
        raise typer.Exit(code=1)

    if not assets:
        console.print("[yellow]No model assets found in this workflow.[/yellow]")
        console.print(
            "[dim]Possible reasons:\n"
            "  • The workflow uses the ComfyUI web UI export format — try exporting "
            "via [bold]Settings > Export (API)[/bold] instead.\n"
            "  • All referenced models are already present locally.\n"
            "  • The workflow contains no model-loading nodes (e.g. it is a utility "
            "or template workflow).\n"
            "Re-run with [bold]--verbose[/bold] to see every node kulai inspected.[/dim]"
        )
        raise typer.Exit(code=0)

    console.print(f"[cyan]Found {len(assets)} asset(s) in workflow[/cyan]\n")

    # ── 4. Resolve ──────────────────────────────────────────────────────────
    resolver = Resolver(config)

    # --no-cache: monkey-patch the cache check so it always returns None
    if no_cache:
        resolver._check_cache = lambda asset: None  # type: ignore[method-assign]

    with console.status("[cyan]Resolving…[/cyan]", spinner="dots") as status:
        def _progress(name: str) -> None:
            short = name if len(name) <= 50 else name[:47] + "…"
            status.update(f"[cyan]Resolving:[/cyan] [dim]{short}[/dim]")
        results = resolver.resolve_all(assets, on_progress=_progress)

    # ── 5. Auto / interactive resolution modes ──────────────────────────────
    if auto_all:
        confirmed_results = results
        unresolved = sum(1 for r in results if r.source is None)
        console.print(
            f"[yellow]--auto-all: accepting all {len(results)} resolution(s)"
            + (f" ({unresolved} unresolved)" if unresolved else "")
            + "[/yellow]"
        )
    elif auto:
        confirmed_results = [r for r in results if r.confidence == "high"]
        skipped = len(results) - len(confirmed_results)
        console.print(
            f"[yellow]--auto: {len(confirmed_results)} high-confidence, "
            f"{skipped} skipped[/yellow]"
        )
    else:
        session = UISession(results, config)
        confirmed_results = session.run()

    if not confirmed_results:
        console.print("[yellow]Nothing to do after review.[/yellow]")
        raise typer.Exit(code=0)

    # ── 6. Build download task list ─────────────────────────────────────────
    downloader = Downloader(config)
    tasks: list[DownloadTask] = []

    for result in confirmed_results:
        if not result.source:
            continue
        asset_type = result.asset_type
        dest = download_dir if download_dir else _safe_get_model_path(asset_type, config)
        tasks.append(DownloadTask(result=result, destination=dest, asset_type=asset_type))

    if not tasks:
        console.print("[yellow]No resolvable assets — nothing to download.[/yellow]")
        raise typer.Exit(code=0)

    # ── 7. Dry-run ──────────────────────────────────────────────────────────
    if dry_run:
        _ui(config).display_dry_run_table(tasks)
        raise typer.Exit(code=0)

    # ── 8. Pre-download review (interactive only) ───────────────────────────
    if not auto and not auto_all:
        tasks = _ui(config).prompt_pre_download_review(tasks)
        if not tasks:
            console.print("[yellow]No assets selected — nothing to download.[/yellow]")
            raise typer.Exit(code=0)

    # ── 9. Disk-space check ─────────────────────────────────────────────────
    download_tasks = [
        t for t in tasks
        if t.result.source and t.result.source.source_type != "local"
    ]

    if download_tasks:
        try:
            enough, required, available = downloader.check_disk_space(download_tasks)
            if not enough:
                console.print(
                    Panel(
                        f"[bold]Required :[/bold]  {_fmt(required)}\n"
                        f"[bold]Available:[/bold]  {_fmt(available)}",
                        title="[red]⚠ Insufficient disk space[/red]",
                        border_style="red",
                    )
                )
                if not typer.confirm("Continue anyway?", default=False):
                    console.print("[yellow]Aborted.[/yellow]")
                    raise typer.Exit(code=0)
            else:
                console.print(
                    f"[dim]Disk space: {_fmt(required)} required, "
                    f"{_fmt(available)} available[/dim]"
                )
        except typer.Exit:
            raise
        except Exception as exc:
            # Non-fatal — warn and proceed
            console.print(f"[yellow]⚠ Could not check disk space: {exc}[/yellow]")

    # ── 10. Download ────────────────────────────────────────────────────────
    actual_count = len(download_tasks)
    local_count  = len(tasks) - actual_count

    if actual_count:
        msg = f"Downloading [bold]{actual_count}[/bold] asset(s)"
        if local_count:
            msg += f"  [dim]({local_count} already local, skipped)[/dim]"
        console.print(f"\n[cyan]{msg}[/cyan]")
        download_results = downloader.download_all(tasks)
    else:
        console.print("[green]✓ All assets are already present locally.[/green]")
        raise typer.Exit(code=0)

    # ── 11. Persist non-local mappings to cache ─────────────────────────────
    for result in confirmed_results:
        if (
            result.source
            and result.source.source_type != "local"
            and result.confidence in ("high", "medium")
        ):
            try:
                save_mapping(result.input_name, result)
            except Exception as exc:
                logger.warning(
                    "Failed to cache mapping for %s: %s", result.input_name, exc
                )

    # ── 12. Summary ─────────────────────────────────────────────────────────
    _ui(config).display_download_summary(download_results)


# ---------------------------------------------------------------------------
# cache-list
# ---------------------------------------------------------------------------

@app.command(name="cache-list")
def cache_list() -> None:
    """List all cached asset-to-source mappings."""
    mappings = list_mappings()

    if not mappings:
        console.print("[yellow]No cached mappings.[/yellow]")
        return

    table = Table(title="Cached Mappings", box=box.ROUNDED, show_lines=False)
    table.add_column("Asset",            style="cyan",   no_wrap=True)
    table.add_column("Source Type",      style="blue")
    table.add_column("Repository / URL", style="green")
    table.add_column("Confidence",       style="yellow")

    for m in mappings:
        table.add_row(
            m.get("filename", "—"),
            m.get("source", {}).get("type", "—"),
            m.get("source", {}).get("repo", "—"),
            m.get("confidence", "—"),
        )

    console.print(table)
    console.print(f"\n[dim]{len(mappings)} mapping(s) cached[/dim]")


# ---------------------------------------------------------------------------
# cache-clear
# ---------------------------------------------------------------------------

@app.command(name="cache-clear")
def cache_clear(
    name: Optional[str] = typer.Argument(
        None,
        help="Filename of a specific mapping to remove. Omit to clear everything.",
    ),
) -> None:
    """
    Remove cached asset mappings.

    Pass a filename to remove just that entry, or omit it to wipe the entire
    cache (with confirmation).
    """
    if name:
        delete_mapping(name)
        console.print(f"[green]✓ Cleared mapping for: {name}[/green]")
    else:
        count = len(list_mappings())
        if count == 0:
            console.print("[yellow]Cache is already empty.[/yellow]")
            return
        if typer.confirm(f"Clear all {count} cached mapping(s)?", default=False):
            save_mappings({})
            console.print("[green]✓ Cache cleared.[/green]")
        else:
            console.print("[yellow]Cancelled.[/yellow]")


# ---------------------------------------------------------------------------
# config-init
# ---------------------------------------------------------------------------

@app.command(name="config-init")
def config_init(
    software: str = typer.Option(
        "comfyui",
        "--software",
        help=(
            "Software profile to configure paths for. "
            f"Supported: {', '.join(SOFTWARE_PROFILES)}."
        ),
    ),
) -> None:
    """Run the first-time setup wizard (or reinitialise an existing config)."""
    if software not in SOFTWARE_PROFILES:
        console.print(f"[red]✗ Unknown software profile: {software!r}[/red]")
        console.print(f"[dim]Supported: {', '.join(SOFTWARE_PROFILES)}[/dim]")
        raise typer.Exit(code=1)
    if config_exists():
        console.print("[yellow]A config file already exists.[/yellow]")
        if not typer.confirm("Overwrite it?", default=False):
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(code=0)
    run_first_time_setup(software=software)


# ---------------------------------------------------------------------------
# config-show
# ---------------------------------------------------------------------------

@app.command(name="config-show")
def config_show() -> None:
    """Print the active configuration (API keys are redacted)."""
    ensure_config()
    config = load_config()

    # Deep-redact every value under [api_keys]
    if "api_keys" in config:
        config["api_keys"] = {
            k: "***" if v else "" for k, v in config["api_keys"].items()
        }

    console.print(Rule("[bold cyan]Active Configuration[/bold cyan]"))
    console.print(toml.dumps(config))


# ---------------------------------------------------------------------------
# Workflow picker (shown when no path is given on the CLI)
# ---------------------------------------------------------------------------

def _pick_workflow(config: dict[str, Any]) -> Optional[Path]:
    """
    Scan the ComfyUI ``user/default/workflows`` directory for ``.json`` files
    and present them as a numbered pick-list.

    The user may:
    - Enter a number to select a discovered workflow.
    - Type any file path to use a workflow outside the default directory.
    - Press Enter (blank) to abort.

    Returns the selected :class:`Path`, or ``None`` if the user aborts.
    """
    comfyui_dir = config.get("comfyui_dir", "")
    workflows_dir = Path(comfyui_dir) / "user" / "default" / "workflows"

    discovered: list[Path] = []
    if workflows_dir.is_dir():
        discovered = sorted(workflows_dir.glob("*.json"))

    console.print(Rule("[bold cyan]Select a Workflow[/bold cyan]"))

    if discovered:
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold cyan")
        table.add_column("#",        style="dim",    width=4,  justify="right")
        table.add_column("Filename", style="cyan",   no_wrap=True)
        table.add_column("Size",     style="yellow", justify="right")
        table.add_column("Path",     style="dim")

        for i, p in enumerate(discovered, 1):
            try:
                size = _fmt(p.stat().st_size)
            except OSError:
                size = "—"
            table.add_row(str(i), p.name, size, str(p.parent))

        console.print(table)
        console.print(
            f"[dim]Found {len(discovered)} workflow(s) in {workflows_dir}[/dim]\n"
        )
        console.print(
            "[dim]Enter a [bold]number[/bold] to select  •  "
            "a [bold]file path[/bold] to use a different workflow  •  "
            "[bold]blank[/bold] to abort[/dim]"
        )
    else:
        if comfyui_dir:
            console.print(
                f"[yellow]No workflows found in {workflows_dir}[/yellow]\n"
            )
        else:
            console.print("[yellow]ComfyUI directory not configured.[/yellow]\n")
        console.print(
            "[dim]Enter a [bold]file path[/bold] to a workflow JSON, "
            "or leave blank to abort.[/dim]"
        )

    raw = Prompt.ask("\nWorkflow", default="").strip()

    if not raw:
        return None

    # ── Numeric selection ───────────────────────────────────────────────────
    if raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(discovered):
            chosen = discovered[idx]
            console.print(f"[cyan]Selected: {chosen.name}[/cyan]\n")
            return chosen
        console.print(
            f"[red]✗ Invalid selection '{raw}' — valid range is 1–{len(discovered)}.[/red]"
        )
        return None

    # ── Treat as an explicit file path ──────────────────────────────────────
    path = Path(raw)
    if not path.exists():
        console.print(f"[red]✗ File not found: {path}[/red]")
        return None
    if not path.is_file():
        console.print(f"[red]✗ Not a file: {path}[/red]")
        return None
    return path


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _setup_logging(verbose: bool) -> None:
    """Configure root logger verbosity."""
    level = logging.DEBUG if verbose else logging.WARNING
    fmt   = "%(asctime)s  %(name)s  %(levelname)s  %(message)s" if verbose else "%(message)s"
    logging.basicConfig(level=level, format=fmt, force=True)
    if verbose:
        logger.debug("Verbose logging enabled.")


def _safe_get_model_path(asset_type: str, config: dict[str, Any]) -> Path:
    """
    Return the configured model path for *asset_type*.

    Falls back to ``<comfyui_dir>/models/<asset_type>`` if the type is
    unknown or the config lookup fails, so a bad type never crashes downstream.
    """
    try:
        return get_model_path(asset_type, config)
    except Exception:
        base = Path(config.get("comfyui_dir", ".")) / "models"
        fallback = base / asset_type
        logger.warning(
            "Could not resolve model path for type '%s'; falling back to %s",
            asset_type,
            fallback,
        )
        return fallback


def _ui(config: dict[str, Any]) -> UISession:
    """Return a throw-away UISession (used to call display helpers)."""
    return UISession([], config)


def _fmt(size_bytes: int) -> str:
    """Return a human-readable byte size string, e.g. ``1.45 GB``."""
    size = float(size_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"


def run_first_time_setup(software: str = "comfyui") -> dict[str, Any]:
    """
    Prompt for the base installation directory, write the default config,
    and return the freshly-loaded config dict.
    """
    profile = SOFTWARE_PROFILES.get(software, SOFTWARE_PROFILES["comfyui"])
    console.print(
        Panel(
            f"[bold]Welcome to [bold cyan]kulai[/bold cyan]![/bold]\n\n"
            f"Setting up for [cyan]{profile['display']}[/cyan].\n"
            "All model sub-directories will be inferred automatically.\n"
            "You can override individual paths in the generated config file.",
            title="First-time setup",
            border_style="cyan",
        )
    )

    base_dir = typer.prompt(f"{profile['display']} installation directory")

    if not base_dir.strip():
        console.print("[red]✗ Path cannot be empty.[/red]")
        raise typer.Exit(code=1)

    dir_path = Path(base_dir)
    if not dir_path.exists():
        console.print(f"[yellow]⚠ Directory does not exist: {dir_path}[/yellow]")
        if not typer.confirm("Create it and continue anyway?", default=False):
            raise typer.Exit(code=1)

    config_path = write_default_config(str(dir_path), software=software)
    console.print(f"\n[green]✓ Config written to {config_path}[/green]")
    console.print(
        "[dim]Edit the file to set API keys or override individual model paths.[/dim]"
    )
    return load_config()


def ensure_config() -> None:
    """
    Ensure a config file exists.  If not, run the first-time setup wizard
    interactively before proceeding.
    """
    if not config_exists():
        run_first_time_setup()


# ---------------------------------------------------------------------------
# App callback — global help text
# ---------------------------------------------------------------------------

@app.callback()
def _callback(ctx: typer.Context) -> None:
    """
    [bold cyan]kulai[/bold cyan] v0.2 — AI asset and workflow package manager

    Manage model assets and custom nodes for ComfyUI and other AI software.
    Use [bold].kula[/bold] files for portable, reproducible workflow dependencies.
    """
    pass


# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------

@app.command()
def install(
    kula_file: Path = typer.Argument(
        ...,
        help="Path to the .kula dependency manifest.",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
    ),
    required_only: bool = typer.Option(
        False, "--required-only",
        help="Skip optional resources and custom nodes.",
    ),
    nodes_only: bool = typer.Option(
        False, "--nodes-only",
        help="Install custom nodes only; skip model downloads.",
    ),
    variant: Optional[str] = typer.Option(
        None, "--variant",
        help="Override the default variant for all resources (e.g. q8, fp16).",
    ),
    download_dir: Optional[Path] = typer.Option(
        None, "--download-dir",
        help="Override the destination directory for every resource.",
    ),
    concurrent: Optional[int] = typer.Option(
        None, "--concurrent", min=1, max=16,
        help="Number of parallel downloads.",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip confirmation prompt.",
    ),
    civitai_info: bool = typer.Option(
        True, "--civitai-info/--no-civitai-info",
        help="Save a .civitai.info metadata sidecar alongside each Civitai download.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Emit DEBUG-level logs."),
) -> None:
    """
    Install all dependencies declared in a [bold].kula[/bold] file.

    Downloads model assets to the configured paths and clones any custom
    nodes listed in the file.  Pass [bold]--required-only[/bold] to skip
    optional entries, or [bold]--nodes-only[/bold] to clone nodes without
    downloading models.
    """
    _setup_logging(verbose)
    ensure_config()
    config = load_config()
    if concurrent is not None:
        config.setdefault("download", {})["concurrent"] = concurrent

    try:
        kula = parse_kula(kula_file)
    except Exception as exc:
        console.print(f"[red]✗ Could not read {kula_file.name}: {exc}[/red]")
        raise typer.Exit(code=1)

    console.print(Rule(f"[bold cyan]kulai install[/bold cyan]  [dim]{kula_file.name}[/dim]"))
    if kula.meta.name:
        author_part = f"  [dim]by {kula.meta.author}[/dim]" if kula.meta.author else ""
        console.print(f"[cyan]{kula.meta.name}[/cyan] v{kula.meta.version}{author_part}")
    if kula.meta.description:
        console.print(f"[dim]{kula.meta.description}[/dim]")
    console.print()

    # ── Build resource task list ─────────────────────────────────────────────
    resources = kula.resources
    if required_only:
        resources = [r for r in resources if r.required]

    tasks: list[DownloadTask] = []
    skipped_no_source: list[KulaResource] = []

    if not nodes_only:
        for r in resources:
            task = _kula_resource_to_task(r, config, download_dir, variant)
            if task:
                tasks.append(task)
            elif r.effective_file_name(variant):
                skipped_no_source.append(r)

    # ── Build custom node list ───────────────────────────────────────────────
    nodes = kula.custom_nodes
    if required_only:
        nodes = [n for n in nodes if n.required]

    # ── Preview table ────────────────────────────────────────────────────────
    if tasks or nodes or skipped_no_source:
        preview = Table(box=box.SIMPLE, show_header=True, header_style="bold cyan")
        preview.add_column("Resource",    style="cyan",   no_wrap=True)
        preview.add_column("Type",        style="blue",   width=14)
        preview.add_column("File",        style="dim",    no_wrap=True)
        preview.add_column("Destination", style="dim")
        preview.add_column("SHA256",      style="dim",    width=10)

        for t in tasks:
            sha = (t.result.source.sha256 or "")[:8] + "..." if t.result.source and t.result.source.sha256 else ""
            preview.add_row(
                t.result.input_name,
                t.asset_type,
                t.result.source.file if t.result.source else "",
                str(t.destination),
                sha,
            )
        for r in skipped_no_source:
            fname = r.effective_file_name(variant) or ""
            preview.add_row(
                f"[yellow]{r.display_name}[/yellow]",
                r.type,
                fname,
                "[yellow]no source — will skip[/yellow]",
                "",
            )
        console.print(preview)

    if nodes:
        console.print("[bold]Custom nodes:[/bold]")
        for n in nodes:
            req_tag = "" if n.required else " [dim](optional)[/dim]"
            console.print(f"  [cyan]{n.display_name}[/cyan]{req_tag}  [dim]{n.repo}[/dim]")
        console.print()

    if not tasks and not nodes:
        console.print("[yellow]Nothing to install.[/yellow]")
        raise typer.Exit(code=0)

    if not yes and not typer.confirm("Proceed?", default=True):
        console.print("[yellow]Aborted.[/yellow]")
        raise typer.Exit(code=0)

    # ── Download resources ───────────────────────────────────────────────────
    if tasks:
        download_tasks = [t for t in tasks if t.result.source and t.result.source.source_type != "local"]
        local_tasks    = [t for t in tasks if t not in download_tasks]

        if local_tasks:
            console.print(f"[dim]{len(local_tasks)} asset(s) already present locally.[/dim]")

        if download_tasks:
            downloader = Downloader(config)
            try:
                enough, required_bytes, available = downloader.check_disk_space(download_tasks)
                if not enough:
                    console.print(
                        Panel(
                            f"[bold]Required :[/bold]  {_fmt(required_bytes)}\n"
                            f"[bold]Available:[/bold]  {_fmt(available)}",
                            title="[red]⚠ Insufficient disk space[/red]",
                            border_style="red",
                        )
                    )
                    if not typer.confirm("Continue anyway?", default=False):
                        raise typer.Exit(code=0)
            except typer.Exit:
                raise
            except Exception as exc:
                console.print(f"[yellow]⚠ Could not check disk space: {exc}[/yellow]")

            console.print(f"\n[cyan]Downloading [bold]{len(download_tasks)}[/bold] asset(s)...[/cyan]")
            dl_results = downloader.download_all(tasks)
            _ui(config).display_download_summary(dl_results)

            if civitai_info:
                _save_civitai_info_sidecars(dl_results, config)

    # ── Install custom nodes ─────────────────────────────────────────────────
    if nodes:
        comfyui_dir = config.get("comfyui_dir", "")
        custom_nodes_dir = Path(comfyui_dir) / "custom_nodes" if comfyui_dir else Path("custom_nodes")

        console.print(f"\n[cyan]Installing [bold]{len(nodes)}[/bold] custom node(s)...[/cyan]")
        for node in nodes:
            result = install_node(node.display_name, node.repo, custom_nodes_dir)
            if result.skipped:
                console.print(f"  [dim]- {node.display_name} already installed, skipped.[/dim]")
            elif result.success:
                req_note = "  (requirements installed)" if result.requirements_installed else ""
                console.print(f"  [green]✓ {node.display_name}[/green]{req_note}")
            else:
                console.print(f"  [red]✗ {node.display_name}: {result.error}[/red]")

    console.print("\n[green]Done.[/green]")


# ---------------------------------------------------------------------------
# generate
# ---------------------------------------------------------------------------

@app.command()
def generate(
    workflow: Path = typer.Argument(
        ...,
        help="ComfyUI workflow JSON to generate a .kula file from.",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="Output .kula file path. Defaults to <workflow-stem>.kula.",
    ),
    mode: str = typer.Option(
        "semi-auto", "--mode",
        help="Resolution mode: auto (silent) or semi-auto (interactive review).",
    ),
    no_cache: bool = typer.Option(False, "--no-cache", help="Ignore cached mappings."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Emit DEBUG-level logs."),
) -> None:
    """
    Generate a [bold].kula[/bold] dependency file from a ComfyUI workflow JSON.

    Parses the workflow, resolves every referenced model on HuggingFace /
    Civitai, then writes a portable .kula manifest you can ship alongside
    the workflow so anyone can recreate the environment with one command.

    Use [bold]--mode auto[/bold] to skip the interactive review and write
    the file immediately with whatever was found.
    """
    _setup_logging(verbose)
    ensure_config()
    config = load_config()

    if mode not in ("auto", "semi-auto"):
        console.print("[red]✗ --mode must be 'auto' or 'semi-auto'.[/red]")
        raise typer.Exit(code=1)

    out_path = output or workflow.with_suffix(".kula")

    console.print(Rule(f"[bold cyan]kulai generate[/bold cyan]  [dim]{workflow.name}[/dim]"))

    # Parse
    try:
        assets = parse_workflow(workflow)
    except Exception as exc:
        console.print(f"[red]✗ Error parsing workflow: {exc}[/red]")
        raise typer.Exit(code=1)

    if not assets:
        console.print("[yellow]No model assets found in workflow.[/yellow]")
        raise typer.Exit(code=0)

    console.print(f"[cyan]Found {len(assets)} asset(s)[/cyan]\n")

    # Resolve
    resolver = Resolver(config)
    if no_cache:
        resolver._check_cache = lambda asset: None  # type: ignore[method-assign]

    with console.status("[cyan]Resolving...[/cyan]", spinner="dots") as status:
        def _prog(name: str) -> None:
            short = name if len(name) <= 50 else name[:47] + "..."
            status.update(f"[cyan]Resolving:[/cyan] [dim]{short}[/dim]")
        results = resolver.resolve_all(assets, on_progress=_prog)

    # Review (semi-auto only)
    if mode == "semi-auto":
        session = UISession(results, config)
        confirmed = session.run()
        if not confirmed:
            console.print("[yellow]Nothing confirmed — no file written.[/yellow]")
            raise typer.Exit(code=0)
    else:
        confirmed = results

    # Convert to KulaFile
    workflow_name = workflow.stem.replace("_", " ").replace("-", " ").title()
    kula = KulaFile(
        meta=KulaMeta(
            name=workflow_name,
            version="1.0",
            workflow_file=workflow.name,
        ),
        resources=[_result_to_kula_resource(r) for r in confirmed],
        custom_nodes=[],
    )

    write_kula(kula, out_path)
    console.print(f"\n[green]✓ Written to {out_path}[/green]")
    unresolved = sum(1 for r in confirmed if not r.source)
    if unresolved:
        console.print(
            f"[yellow]  {unresolved} asset(s) have no source — "
            "add URLs manually in the .kula file.[/yellow]"
        )
    console.print("[dim]Custom nodes are not auto-detected. Add them manually, or use 'kulai wizard'.[/dim]")


# ---------------------------------------------------------------------------
# wizard
# ---------------------------------------------------------------------------

@app.command()
def wizard(
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="Output .kula file path.",
    ),
) -> None:
    """
    Interactive step-by-step [bold].kula[/bold] file builder.

    Guides you through adding resources (with optional variants and SHA256
    hashes), setting sources, and listing required custom nodes.
    Works for any AI software — not ComfyUI-specific.
    """
    from rich.prompt import Confirm

    console.print(Rule("[bold cyan]kulai wizard[/bold cyan]"))
    console.print("[dim]Build a .kula dependency file interactively. Blank = skip/done.[/dim]\n")

    # ── Meta ─────────────────────────────────────────────────────────────────
    name        = Prompt.ask("Workflow name")
    author      = Prompt.ask("Author", default="")
    description = Prompt.ask("Description", default="")
    wf_file     = Prompt.ask("Workflow JSON filename (optional)", default="")

    meta = KulaMeta(
        name=name,
        author=author,
        description=description,
        version="1.0",
        workflow_file=wf_file,
    )

    # ── Resources ────────────────────────────────────────────────────────────
    console.print(Rule("[bold]Resources[/bold]"))
    resources: list[KulaResource] = []

    ASSET_TYPES = "checkpoints / loras / vae / unet / text_encoders / controlnet / other"

    while True:
        # Step 1: cosmetic name
        display_name = Prompt.ask("\nResource display name [bold](blank to finish)[/bold]", default="")
        if not display_name:
            break

        # Step 2: URL — auto-detect source type and infer as many fields as possible
        url = Prompt.ask(
            "  Download URL [dim](paste HF, Civitai, or direct URL; blank to enter manually)[/dim]",
            default="",
        ).strip()

        inferred: dict[str, Any] = {}
        if url:
            with console.status("[cyan]  Looking up...[/cyan]", spinner="dots"):
                # load_config may be already done above, but we need config here
                cfg_for_lookup = load_config() if config_exists() else {}
                inferred = _wizard_infer_from_url(url, cfg_for_lookup)

            if inferred.get("_error"):
                console.print(f"  [yellow]  {inferred['_error']}[/yellow]")

            if inferred.get("file_name") or inferred.get("asset_type"):
                summary_parts = []
                if inferred.get("file_name"):
                    summary_parts.append(f"file=[cyan]{inferred['file_name']}[/cyan]")
                if inferred.get("asset_type"):
                    summary_parts.append(f"type=[cyan]{inferred['asset_type']}[/cyan]")
                if inferred.get("sha256"):
                    summary_parts.append(f"sha256=[dim]{inferred['sha256'][:12]}...[/dim]")
                if inferred.get("size_bytes"):
                    summary_parts.append(f"size=[dim]{_fmt(inferred['size_bytes'])}[/dim]")
                console.print("  [dim]Inferred:[/dim] " + "  ".join(summary_parts))

        has_variants = Confirm.ask("  Multiple quality variants? (e.g. fp16 / fp8 / q8)", default=False)

        variants: dict[str, KulaVariant] = {}
        default_variant: Optional[str] = None
        file_name: Optional[str] = None
        sha256: Optional[str] = None
        sources: dict[str, str] = dict(inferred.get("sources", {}))

        if has_variants:
            # Clear any inferred single-file sources for variant resources
            sources = {}
            default_variant = Prompt.ask("  Default variant name (e.g. fp16)", default="fp16")
            while True:
                vname = Prompt.ask("  Variant name [bold](blank to finish)[/bold]", default="")
                if not vname:
                    break
                console.print(f"  [cyan]  -- Variant: {vname} --[/cyan]")
                vurl    = Prompt.ask("  Download URL (blank to skip)", default="").strip()
                vinf: dict[str, Any] = {}
                if vurl:
                    with console.status("[cyan]  Looking up...[/cyan]", spinner="dots"):
                        cfg_for_lookup = load_config() if config_exists() else {}
                        vinf = _wizard_infer_from_url(vurl, cfg_for_lookup)
                    if vinf.get("_error"):
                        console.print(f"  [yellow]  {vinf['_error']}[/yellow]")
                vfile   = Prompt.ask("  Filename", default=vinf.get("file_name", ""))
                vsha    = Prompt.ask("  SHA256 (optional)", default=vinf.get("sha256") or "")
                vsources: dict[str, str] = dict(vinf.get("sources", {}))
                if not vsources:
                    vhf     = Prompt.ask("  HuggingFace URL or repo (optional)", default="")
                    vdirect = Prompt.ask("  Direct URL (optional)", default="")
                    if vhf:     vsources["huggingface"] = vhf
                    if vdirect: vsources["direct"]      = vdirect
                variants[vname] = KulaVariant(
                    file_name=vfile,
                    sha256=vsha or None,
                    sources=vsources,
                )
        else:
            file_name = Prompt.ask("  Filename", default=inferred.get("file_name") or "")
            sha256    = (Prompt.ask("  SHA256 (optional)", default=inferred.get("sha256") or "") or None)
            # Allow adding extra sources not already filled from URL lookup
            if not sources:
                hf_src  = Prompt.ask("  HuggingFace URL or repo (optional)", default="")
                civ_src = Prompt.ask("  Civitai URL or ID (optional)", default="")
                direct  = Prompt.ask("  Direct URL (optional)", default="")
                if hf_src:  sources["huggingface"] = hf_src
                if civ_src: sources["civitai"]     = civ_src
                if direct:  sources["direct"]      = direct

        # Remaining metadata (after source fields are known)
        asset_type  = Prompt.ask(
            f"  Asset type [dim]({ASSET_TYPES})[/dim]",
            default=inferred.get("asset_type") or "other",
        )
        required    = Confirm.ask("  Required?", default=True)
        _vram_default = f"{inferred['vram_gb']}gb" if inferred.get("vram_gb") else ""
        vram_raw    = Prompt.ask("  VRAM hint (optional, e.g. 512mb, 1.5gb, 8gb)", default=_vram_default)
        vram_gb     = _parse_vram_hint(vram_raw)
        destination = Prompt.ask("  Destination path", default=f"models/{asset_type}")
        notes       = Prompt.ask("  Notes (optional)", default="")

        resources.append(KulaResource(
            display_name=display_name,
            type=asset_type,
            required=required,
            vram_gb=vram_gb,
            default_variant=default_variant,
            destination=destination or None,
            notes=notes,
            file_name=file_name or None,
            sha256=sha256,
            sources=sources,
            variants=variants,
        ))
        console.print(f"[green]  + Added: {display_name}[/green]")

    # ── Custom nodes ─────────────────────────────────────────────────────────
    console.print(Rule("[bold]Custom Nodes[/bold]"))
    custom_nodes: list[KulaCustomNode] = []

    while True:
        cn_name = Prompt.ask("\nCustom node display name [bold](blank to finish)[/bold]", default="")
        if not cn_name:
            break
        cn_repo     = Prompt.ask("  Repository URL")
        cn_required = Confirm.ask("  Required?", default=True)
        cn_notes    = Prompt.ask("  Notes (optional)", default="")
        custom_nodes.append(KulaCustomNode(
            display_name=cn_name,
            repo=cn_repo,
            required=cn_required,
            notes=cn_notes,
        ))
        console.print(f"[green]  + Added: {cn_name}[/green]")

    # ── Output ───────────────────────────────────────────────────────────────
    console.print(Rule("[bold]Output[/bold]"))
    if not resources and not custom_nodes:
        console.print("[yellow]Nothing added — no file written.[/yellow]")
        raise typer.Exit(code=0)

    slug = name.lower().replace(" ", "_").replace("/", "_")[:40] if name else "workflow"
    default_out = f"{slug}.kula"
    out_raw = Prompt.ask("Output file", default=output.as_posix() if output else default_out)
    out_path = Path(out_raw)

    kula = KulaFile(meta=meta, resources=resources, custom_nodes=custom_nodes)
    write_kula(kula, out_path)
    console.print(f"\n[green]✓ Written to {out_path}[/green]")
    console.print(f"[dim]{len(resources)} resource(s), {len(custom_nodes)} custom node(s)[/dim]")


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------

@app.command()
def check(
    workflow: Path = typer.Argument(
        ...,
        help="ComfyUI workflow JSON to check.",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show full paths for found assets."),
) -> None:
    """
    Fast local-only asset check — no API calls, no downloads.

    Scans your configured model directories and reports which assets
    referenced in the workflow are already present and which are missing.
    """
    _setup_logging(verbose)
    ensure_config()
    config = load_config()

    try:
        assets = parse_workflow(workflow)
    except Exception as exc:
        console.print(f"[red]✗ Error parsing workflow: {exc}[/red]")
        raise typer.Exit(code=1)

    if not assets:
        console.print("[yellow]No model assets found in workflow.[/yellow]")
        raise typer.Exit(code=0)

    console.print(Rule(f"[bold cyan]kulai check[/bold cyan]  [dim]{workflow.name}[/dim]"))

    # Build list of model dirs to search
    comfyui_dir = config.get("comfyui_dir", "")
    search_dirs: list[Path] = []
    if comfyui_dir:
        search_dirs = list(infer_model_paths(comfyui_dir).values())
    if "paths" in config:
        for v in config["paths"].values():
            p = Path(v)
            if p not in search_dirs:
                search_dirs.append(p)

    table = Table(box=box.SIMPLE, show_header=True, header_style="bold cyan")
    table.add_column("Asset",       style="cyan", no_wrap=True)
    table.add_column("Type",        style="blue", width=14)
    table.add_column("Status",      width=12)
    table.add_column("Path",        style="dim")

    found_count = 0
    for asset in assets:
        found_path: Optional[Path] = None
        for d in search_dirs:
            if not d.exists():
                continue
            matches = list(d.rglob(asset.filename))
            if matches:
                found_path = matches[0]
                break

        if found_path:
            found_count += 1
            path_str = str(found_path) if verbose else str(found_path.parent)
            table.add_row(asset.filename, asset.asset_type, "[green]✓ found[/green]", path_str)
        else:
            table.add_row(asset.filename, asset.asset_type, "[red]✗ missing[/red]", "")

    console.print(table)
    missing = len(assets) - found_count
    colour = "green" if missing == 0 else "yellow"
    console.print(f"\n[{colour}]{found_count}/{len(assets)} assets present locally.[/{colour}]")
    if missing:
        console.print(f"[dim]Run [bold]kulai resolve {workflow.name}[/bold] to download the missing {missing}.[/dim]")


# ---------------------------------------------------------------------------
# v0.2 helper functions
# ---------------------------------------------------------------------------

def _kula_resource_to_task(
    resource: KulaResource,
    config: dict[str, Any],
    download_dir: Optional[Path] = None,
    variant_override: Optional[str] = None,
) -> Optional[DownloadTask]:
    """Convert a KulaResource into a DownloadTask, or None if no source available."""
    file_name = resource.effective_file_name(variant_override)
    if not file_name:
        return None

    sources = resource.effective_sources(variant_override)
    sha256  = resource.effective_sha256(variant_override)

    if not sources:
        return None

    resolved = _pick_kula_source(file_name, sources, sha256, config)
    if not resolved:
        return None

    if download_dir:
        dest = download_dir
    elif resource.destination:
        base = Path(config.get("comfyui_dir", "."))
        dest = base / resource.destination
    else:
        dest = _safe_get_model_path(resource.type, config)

    result = ResolutionResult(
        input_name=file_name,
        resolved_name=file_name,
        source=resolved,
        confidence="high",
        asset_type=resource.type,
    )
    return DownloadTask(result=result, destination=dest, asset_type=resource.type)


def _pick_kula_source(
    file_name: str,
    sources: dict[str, str],
    sha256: Optional[str],
    config: dict[str, Any],
) -> Optional[ResolvedSource]:
    """Select the best available source from a resource's sources dict."""
    preferred = config.get("resolution", {}).get("preferred_source", "huggingface")
    order = [preferred] + [s for s in ("huggingface", "civitai", "direct") if s != preferred]

    for source_type in order:
        if source_type not in sources:
            continue
        raw = sources[source_type]

        if source_type == "huggingface":
            repo, file = _parse_hf_source(raw, file_name)
            # Preserve a specific branch/commit if the URL uses one other than main/master
            hf_download_url: Optional[str] = None
            ref_m = re.match(
                r"https?://huggingface\.co/[^/]+/[^/]+/(?:resolve|blob)/([^/]+)/",
                raw,
            )
            if ref_m and ref_m.group(1) not in ("main", "master"):
                hf_download_url = f"https://huggingface.co/{repo}/resolve/{ref_m.group(1)}/{file}"
            return ResolvedSource(
                source_type="huggingface",
                repo=repo,
                file=file,
                download_url=hf_download_url,
                sha256=sha256,
            )
        elif source_type == "civitai":
            if raw.startswith("http"):
                # Full download URL (civitai.com or civitai.red)
                return ResolvedSource(
                    source_type="civitai",
                    repo=raw,
                    file=file_name,
                    download_url=raw,
                    sha256=sha256,
                )
            else:
                # "civitai:modelId" or "civitai:modelId:versionId"
                parts = raw.replace("civitai:", "").strip().split(":")
                # The last numeric segment is the version ID (most specific)
                version_id = parts[-1]
                return ResolvedSource(
                    source_type="civitai",
                    repo=raw,
                    file=file_name,
                    download_url=f"https://civitai.com/api/download/models/{version_id}",
                    sha256=sha256,
                )
        elif source_type == "direct":
            return ResolvedSource(
                source_type="direct_url",
                repo=raw,
                file=file_name,
                download_url=raw,
                sha256=sha256,
            )

    return None


def _parse_hf_source(url_or_repo: str, fallback_file: str) -> tuple[str, str]:
    """Parse a HuggingFace URL or bare repo ID into (repo, filename)."""
    m = re.match(
        r"https?://huggingface\.co/([^/]+/[^/]+)/(?:resolve|blob)/[^/]+/(.+)$",
        url_or_repo,
    )
    if m:
        return m.group(1), m.group(2)
    if re.match(r"^[A-Za-z0-9_./-]+/[A-Za-z0-9_.-]+$", url_or_repo):
        return url_or_repo, fallback_file
    return url_or_repo, fallback_file


def _result_to_kula_resource(result: ResolutionResult) -> KulaResource:
    """Convert a resolved ResolutionResult into a KulaResource for .kula output."""
    src = result.source
    sources: dict[str, str] = {}

    if src:
        if src.source_type == "huggingface":
            sources["huggingface"] = (
                f"https://huggingface.co/{src.repo}/resolve/main/{src.file}"
            )
        elif src.source_type == "civitai":
            # repo is "civitai:modelId:versionId", "civitai:modelId", or a download URL
            sources["civitai"] = src.download_url or src.repo
        elif src.source_type == "direct_url" and src.download_url:
            sources["direct"] = src.download_url

    display_name = (
        Path(result.input_name).stem
        .replace("_", " ")
        .replace("-", " ")
        .title()
    )
    notes = "TODO: verify source and add SHA256" if not src else ""

    return KulaResource(
        display_name=display_name,
        type=result.asset_type,
        required=True,
        destination=f"models/{result.asset_type}",
        file_name=result.input_name,
        sha256=src.sha256 if src else None,
        sources=sources,
        notes=notes,
    )


# ---------------------------------------------------------------------------
# Civitai .civitai.info sidecar
# ---------------------------------------------------------------------------

def _save_civitai_info_sidecars(
    dl_results: list[Any],
    config: dict[str, Any],
) -> None:
    """
    For each successfully downloaded Civitai asset, fetch its version metadata
    and save it as ``{filename}.civitai.info`` in the same destination directory.

    The sidecar format is the raw JSON from ``GET /api/v1/model-versions/{id}``,
    which ComfyUI Manager and similar tools recognise.
    """
    token = os.getenv("KULAI_CIVITAI_TOKEN") or config.get("api_keys", {}).get("civitai")

    saved = 0
    for res in dl_results:
        if not (res.success or res.skipped):
            continue

        task = res.task
        if not task.result.source:
            continue

        src = task.result.source
        if src.source_type != "civitai":
            continue

        # Extract version ID from download URL or repo identifier
        version_id: int | None = None
        if src.download_url:
            m = re.search(r"/api/download/models/(\d+)", src.download_url)
            if m:
                version_id = int(m.group(1))
        if not version_id and src.repo:
            parts = src.repo.replace("civitai:", "").split(":")
            if parts[-1].isdigit():
                version_id = int(parts[-1])

        if not version_id:
            continue

        domain = "civitai.red" if "civitai.red" in (src.download_url or "") else "civitai.com"
        version_data = fetch_civitai_version(version_id, domain=domain, token=token)
        if not version_data:
            logger.debug("Could not fetch civitai.info for version %d", version_id)
            continue

        file_name = src.file or task.result.input_name
        sidecar_path = task.destination / f"{file_name}.civitai.info"
        try:
            sidecar_path.parent.mkdir(parents=True, exist_ok=True)
            sidecar_path.write_text(
                json.dumps(version_data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            saved += 1
            logger.debug("Saved %s", sidecar_path)
        except OSError as exc:
            logger.warning("Could not write %s: %s", sidecar_path, exc)

    if saved:
        console.print(f"[dim]Saved {saved} .civitai.info sidecar(s).[/dim]")


# ---------------------------------------------------------------------------
# Wizard helpers
# ---------------------------------------------------------------------------

def _parse_vram_hint(raw: str) -> float | None:
    """
    Parse a VRAM hint string into a float (GB).

    Accepts:
    - ``"512mb"`` / ``"512 MB"``  → 0.5
    - ``"1.5gb"`` / ``"1.5 GB"``  → 1.5
    - ``"8"``                      → 8.0  (bare number assumed GB)
    - blank / invalid              → None
    """
    raw = raw.strip().lower()
    if not raw:
        return None
    m = re.match(r"^([\d.]+)\s*(mb|gb)?$", raw)
    if not m:
        return None
    value = float(m.group(1))
    unit  = m.group(2) or "gb"
    return round(value / 1024.0, 4) if unit == "mb" else value


def _detect_url_source_type(url: str) -> str | None:
    """
    Return the source type inferred from a URL string.

    Returns ``"huggingface"``, ``"civitai"``, ``"direct"``, or ``None``
    if the string is blank or not a URL.
    """
    url = url.strip()
    if not url.startswith("http"):
        return None
    if "huggingface.co" in url:
        return "huggingface"
    if "civitai.com" in url or "civitai.red" in url:
        return "civitai"
    return "direct"


def _wizard_infer_from_url(url: str, config: dict[str, Any]) -> dict[str, Any]:
    """
    Infer resource fields from a download/page URL.

    Returns a dict with any of these keys populated:
    ``file_name``, ``sha256``, ``size_bytes``, ``asset_type``,
    ``sources``, ``_error`` (on failure).

    For Civitai URLs the API is called to retrieve metadata.
    For HuggingFace URLs the repo and filename are parsed from the URL.
    """
    source_type = _detect_url_source_type(url)
    if source_type is None:
        return {"_error": "Not a recognised URL."}

    result: dict[str, Any] = {}

    if source_type == "huggingface":
        repo, fname = _parse_hf_source(url, "")
        result["sources"] = {"huggingface": url}
        if fname:
            result["file_name"] = fname

    elif source_type == "civitai":
        parsed = parse_civitai_url(url)
        if not parsed:
            result["sources"] = {"civitai": url}
            return result

        domain, _model_id, version_id = parsed
        if not version_id:
            result["sources"] = {"civitai": url}
            result["_error"] = "No modelVersionId found in URL — metadata cannot be fetched automatically."
            return result

        token = (
            os.getenv("KULAI_CIVITAI_TOKEN")
            or config.get("api_keys", {}).get("civitai")
        )
        version_data = fetch_civitai_version(version_id, domain=domain, token=token)
        if not version_data:
            result["sources"] = {"civitai": url}
            result["_error"] = "Could not reach the Civitai API — check your connection or token."
            return result

        info = extract_civitai_file_info(version_data, domain=domain)
        if info.get("file_name"):
            result["file_name"] = info["file_name"]
        if info.get("sha256"):
            result["sha256"] = info["sha256"]
        if info.get("size_bytes"):
            result["size_bytes"] = info["size_bytes"]
            result["vram_gb"] = round(info["size_bytes"] / (1024 ** 3), 2)
        if info.get("asset_type"):
            result["asset_type"] = info["asset_type"]

        download_url = info.get("download_url") or url
        result["sources"] = {"civitai": download_url}

    else:  # direct
        result["sources"] = {"direct": url}

    return result


# ---------------------------------------------------------------------------
# Direct invocation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()