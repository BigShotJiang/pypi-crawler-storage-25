"""
kula_parser.py — .kula dependency manifest parser and writer

.kula files are TOML-based workflow dependency manifests.  They declare
model resources (with optional quality variants, multi-source URLs, and
SHA256 hashes) and custom nodes required to run a workflow.

Format overview
---------------
[meta]
name = "My Workflow"
author = "barkin"
version = "1.0"
min_kulai_version = "0.2.0"
workflow_file = "workflow.json"

[[resource]]
display_name = "WAN 2.2 14B"
type = "unet"
required = true
vram_gb = 14
default_variant = "fp16"
destination = "models/unet"
notes = "fp16 for 24 GB+, q8 for 16 GB"

[resource.variants.fp16]
file_name = "wan22-14b-fp16.safetensors"
sha256 = "abc123..."

[resource.variants.fp16.sources]
huggingface = "https://huggingface.co/Wan-AI/Wan2.2-T2V-14B/resolve/main/wan22-14b-fp16.safetensors"

[resource.variants.q8]
file_name = "wan22-14b-q8.gguf"
sha256 = "def456..."

[resource.variants.q8.sources]
huggingface = "https://huggingface.co/Wan-AI/Wan2.2-T2V-14B-GGUF/resolve/main/wan22-14b-q8.gguf"

[[resource]]
display_name = "WAN VAE"
type = "vae"
required = true
file_name = "wan22_vae.safetensors"
sha256 = "ghi789..."
destination = "models/vae"

[resource.sources]
huggingface = "https://huggingface.co/Wan-AI/Wan2.2-VAE/resolve/main/wan22_vae.safetensors"

[[custom_node]]
display_name = "ComfyUI-WAN"
repo = "https://github.com/example/ComfyUI-WAN"
required = true
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import toml  # type: ignore


KULAI_VERSION = "0.2.0"


# ---------------------------------------------------------------------------
# Data-classes
# ---------------------------------------------------------------------------

@dataclass
class KulaMeta:
    name: str = ""
    author: str = ""
    description: str = ""
    version: str = "1.0"
    min_kulai_version: str = ""
    workflow_file: str = ""


@dataclass
class KulaVariant:
    """One quality/precision variant of a resource (e.g. fp16, fp8, q8)."""
    file_name: str
    sha256: str | None = None
    tags: list[str] = field(default_factory=list)
    sources: dict[str, str] = field(default_factory=dict)


@dataclass
class KulaResource:
    """A single model asset entry in a .kula file."""
    display_name: str
    type: str  # "unet", "loras", "vae", "text_encoders", "checkpoints", etc.
    required: bool = True
    vram_gb: float | None = None
    default_variant: str | None = None
    destination: str | None = None
    notes: str = ""
    conflicts: list[str] = field(default_factory=list)
    # --- simple resource (no variants) ---
    file_name: str | None = None
    sha256: str | None = None
    sources: dict[str, str] = field(default_factory=dict)
    # --- variant resource ---
    variants: dict[str, KulaVariant] = field(default_factory=dict)

    @property
    def has_variants(self) -> bool:
        return bool(self.variants)

    def active_variant(self, override: str | None = None) -> KulaVariant | None:
        """Return the variant that will be installed, or None for simple resources."""
        if not self.has_variants:
            return None
        key = override or self.default_variant or next(iter(self.variants), None)
        return self.variants.get(key) if key else None  # type: ignore[return-value]

    def effective_file_name(self, variant_override: str | None = None) -> str | None:
        if self.has_variants:
            v = self.active_variant(variant_override)
            return v.file_name if v else None
        return self.file_name

    def effective_sources(self, variant_override: str | None = None) -> dict[str, str]:
        if self.has_variants:
            v = self.active_variant(variant_override)
            return v.sources if v else {}
        return self.sources

    def effective_sha256(self, variant_override: str | None = None) -> str | None:
        if self.has_variants:
            v = self.active_variant(variant_override)
            return v.sha256 if v else None
        return self.sha256


@dataclass
class KulaCustomNode:
    display_name: str
    repo: str
    required: bool = True
    notes: str = ""


@dataclass
class KulaFile:
    meta: KulaMeta
    resources: list[KulaResource]
    custom_nodes: list[KulaCustomNode]
    path: Path | None = None


# ---------------------------------------------------------------------------
# Parse
# ---------------------------------------------------------------------------

def parse_kula(path: Path) -> KulaFile:
    """
    Parse a .kula TOML file into a KulaFile.

    Raises:
        FileNotFoundError: if the file does not exist.
        toml.TomlDecodeError: if the TOML is malformed.
        ValueError: if required fields are missing.
    """
    if not path.exists():
        raise FileNotFoundError(f".kula file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        data: dict[str, Any] = toml.load(f)  # type: ignore
    meta = _parse_meta(data.get("meta", {}))
    resources = [_parse_resource(r) for r in data.get("resource", [])]
    custom_nodes = [_parse_custom_node(n) for n in data.get("custom_node", [])]
    return KulaFile(meta=meta, resources=resources, custom_nodes=custom_nodes, path=path)


def _parse_meta(d: dict[str, Any]) -> KulaMeta:
    return KulaMeta(
        name=d.get("name", ""),
        author=d.get("author", ""),
        description=d.get("description", ""),
        version=str(d.get("version", "1.0")),
        min_kulai_version=d.get("min_kulai_version", ""),
        workflow_file=d.get("workflow_file", ""),
    )


def _parse_resource(d: dict[str, Any]) -> KulaResource:
    variants: dict[str, KulaVariant] = {}
    for key, v in d.get("variants", {}).items():
        variants[key] = KulaVariant(
            file_name=v["file_name"],
            sha256=v.get("sha256"),
            tags=v.get("tags", []),
            sources=v.get("sources", {}),
        )
    return KulaResource(
        display_name=d.get("display_name", d.get("file_name", "Unknown")),
        type=d.get("type", "other"),
        required=d.get("required", True),
        vram_gb=d.get("vram_gb"),
        default_variant=d.get("default_variant"),
        destination=d.get("destination"),
        notes=d.get("notes", ""),
        conflicts=d.get("conflicts", []),
        file_name=d.get("file_name"),
        sha256=d.get("sha256"),
        sources=d.get("sources", {}),
        variants=variants,
    )


def _parse_custom_node(d: dict[str, Any]) -> KulaCustomNode:
    if "repo" not in d:
        raise ValueError(f"custom_node entry missing required 'repo' field: {d}")
    return KulaCustomNode(
        display_name=d.get("display_name", d["repo"]),
        repo=d["repo"],
        required=d.get("required", True),
        notes=d.get("notes", ""),
    )


# ---------------------------------------------------------------------------
# Write
# ---------------------------------------------------------------------------

def write_kula(kula: KulaFile, path: Path) -> None:
    """Serialize a KulaFile to a .kula TOML file at *path*."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        _write(f, kula)


def _write(f: Any, kula: KulaFile) -> None:
    """Write .kula TOML to an open file object."""
    m = kula.meta

    # [meta] ----------------------------------------------------------------
    f.write("[meta]\n")
    if m.name:
        f.write(f"name = {_q(m.name)}\n")
    if m.author:
        f.write(f"author = {_q(m.author)}\n")
    if m.description:
        f.write(f"description = {_q(m.description)}\n")
    f.write(f"version = {_q(m.version)}\n")
    f.write(f"min_kulai_version = {_q(KULAI_VERSION)}\n")
    if m.workflow_file:
        f.write(f"workflow_file = {_q(m.workflow_file)}\n")

    # [[resource]] ----------------------------------------------------------
    for resource in kula.resources:
        f.write("\n[[resource]]\n")
        f.write(f"display_name = {_q(resource.display_name)}\n")
        f.write(f"type = {_q(resource.type)}\n")
        f.write(f"required = {'true' if resource.required else 'false'}\n")
        if resource.vram_gb is not None:
            f.write(f"vram_gb = {resource.vram_gb}\n")
        if resource.destination:
            f.write(f"destination = {_q(resource.destination)}\n")
        if resource.notes:
            f.write(f"notes = {_q(resource.notes)}\n")
        if resource.conflicts:
            f.write(f"conflicts = [{', '.join(_q(c) for c in resource.conflicts)}]\n")

        if resource.has_variants:
            if resource.default_variant:
                f.write(f"default_variant = {_q(resource.default_variant)}\n")
            for vname, v in resource.variants.items():
                f.write(f"\n[resource.variants.{vname}]\n")
                f.write(f"file_name = {_q(v.file_name)}\n")
                if v.sha256:
                    f.write(f"sha256 = {_q(v.sha256)}\n")
                if v.tags:
                    f.write(f"tags = [{', '.join(_q(t) for t in v.tags)}]\n")
                if v.sources:
                    f.write(f"\n[resource.variants.{vname}.sources]\n")
                    for k, val in v.sources.items():
                        f.write(f"{k} = {_q(val)}\n")
        else:
            if resource.file_name:
                f.write(f"file_name = {_q(resource.file_name)}\n")
            if resource.sha256:
                f.write(f"sha256 = {_q(resource.sha256)}\n")
            if resource.sources:
                f.write("\n[resource.sources]\n")
                for k, val in resource.sources.items():
                    f.write(f"{k} = {_q(val)}\n")

    # [[custom_node]] -------------------------------------------------------
    for node in kula.custom_nodes:
        f.write("\n[[custom_node]]\n")
        f.write(f"display_name = {_q(node.display_name)}\n")
        f.write(f"repo = {_q(node.repo)}\n")
        f.write(f"required = {'true' if node.required else 'false'}\n")
        if node.notes:
            f.write(f"notes = {_q(node.notes)}\n")


def _q(s: str) -> str:
    """Minimal TOML string quoting — handles backslashes and double-quotes."""
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
