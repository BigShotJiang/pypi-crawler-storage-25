from pathlib import Path
import logging
import toml # type: ignore
from typing import Any

try:
    import yaml  # type: ignore
    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False

logger = logging.getLogger(__name__)

APP_NAME = "kulai"

# ---------------------------------------------------------------------------
# Software profiles
# ---------------------------------------------------------------------------

SOFTWARE_PROFILES: dict[str, dict] = {
    "comfyui": {
        "display": "ComfyUI",
        "model_paths": {
            "checkpoints":    "models/checkpoints",
            "loras":          "models/loras",
            "vae":            "models/vae",
            "text_encoders":  "models/text_encoders",
            "unet":           "models/unet",
            "controlnet":     "models/controlnet",
            "upscale_models": "models/upscale_models",
            "embeddings":     "models/embeddings",
            "clip":           "models/clip",
            "ipadapter":      "models/ipadapter",
        },
        "custom_nodes": "custom_nodes",
    },
    "a1111": {
        "display": "Stable Diffusion WebUI (A1111)",
        "model_paths": {
            "checkpoints":    "models/Stable-diffusion",
            "loras":          "models/Lora",
            "vae":            "models/VAE",
            "embeddings":     "models/embeddings",
            "controlnet":     "models/ControlNet",
            "upscale_models": "models/ESRGAN",
        },
        "custom_nodes": "extensions",
    },
    "forge": {
        "display": "Stable Diffusion WebUI Forge",
        "model_paths": {
            "checkpoints":    "models/Stable-diffusion",
            "loras":          "models/Lora",
            "vae":            "models/VAE",
            "embeddings":     "models/embeddings",
            "controlnet":     "models/ControlNet",
            "upscale_models": "models/ESRGAN",
        },
        "custom_nodes": "extensions",
    },
    "invokeai": {
        "display": "InvokeAI",
        "model_paths": {
            "checkpoints": "models/main",
            "loras":       "models/lora",
            "vae":         "models/vae",
            "embeddings":  "models/embedding",
            "controlnet":  "models/controlnet",
        },
        "custom_nodes": "nodes",
    },
    "swarmui": {
        "display": "SwarmUI",
        "model_paths": {
            "checkpoints":    "Models/Stable-Diffusion",
            "loras":          "Models/Lora",
            "vae":            "Models/VAE",
            "embeddings":     "Models/Embeddings",
            "controlnet":     "Models/controlnet",
        },
        "custom_nodes": "dlbackend/installed/ComfyUI/custom_nodes",
    },
}
def get_config_path() -> Path:
    """Returns the path to the configuration file."""
    return Path.home() / ".config" / APP_NAME / "config.toml"

def config_exists() -> bool:
    """Checks if the configuration file exists."""
    return get_config_path().is_file()

def load_config() -> dict[str, Any]:
    """Loads the configuration from the TOML file, then merges any extra paths
    defined in the ComfyUI extra_model_paths.yaml (gaps only — explicit [paths]
    overrides in the config always take precedence)."""
    if not config_exists():
        return {}
    with open(get_config_path(), "r") as f:
        config: dict[str, Any] = toml.load(f)  # type: ignore

    comfyui_dir = config.get("comfyui_dir")
    if comfyui_dir:
        extra = _load_extra_model_paths(comfyui_dir)
        if extra:
            paths = config.setdefault("paths", {})
            for model_type, path in extra.items():
                if model_type not in paths:
                    paths[model_type] = str(path)

    return config


def _load_extra_model_paths(comfyui_dir: str) -> dict[str, Path]:
    """Parse ComfyUI's extra_model_paths.yaml and return a flat {type: path} dict.

    The file lives at <comfyui_dir>/extra_model_paths.yaml.  Each top-level key
    is an arbitrary label (e.g. "comfyui", "a1111").  Each section may have a
    ``base_path`` and one or more model-type keys whose values are paths
    (absolute, or relative to base_path).  When a type lists multiple paths
    (YAML sequence), the first entry is used as the download destination.

    Returns an empty dict if the file is absent, unreadable, or PyYAML is not
    installed (a debug-level warning is emitted in that last case).
    """
    yaml_path = Path(comfyui_dir) / "extra_model_paths.yaml"
    if not yaml_path.is_file():
        return {}

    if not _YAML_AVAILABLE:
        logger.debug(
            "extra_model_paths.yaml found but PyYAML is not installed — "
            "install it with 'pip install pyyaml' to enable automatic path merging."
        )
        return {}

    try:
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except Exception as exc:
        logger.debug("Could not parse extra_model_paths.yaml: %s", exc)
        return {}

    if not isinstance(data, dict):
        return {}

    result: dict[str, Path] = {}
    for _label, section in data.items():
        if not isinstance(section, dict):
            continue
        base_path_raw = section.get("base_path")
        base = Path(base_path_raw) if base_path_raw else None

        for key, value in section.items():
            if key == "base_path":
                continue
            # Value may be a string path or a YAML list of paths; use the first.
            if isinstance(value, list):
                if not value:
                    continue
                value = value[0]
            raw = Path(str(value))
            resolved = raw if raw.is_absolute() else (base / raw if base else raw)
            # Only record if not already captured (first section wins per type).
            if key not in result:
                result[key] = resolved

    return result

def infer_model_paths(comfyui_dir: str) -> dict[str, Path]:
    """Infers model paths based on the standard ComfyUI folder layout."""
    base_path = Path(comfyui_dir) / "models"
    return {
        "checkpoints": base_path / "checkpoints",
        "loras": base_path / "loras",
        "vae": base_path / "vae",
        "text_encoders": base_path / "text_encoders",
        "unet": base_path / "unet",
        "controlnet": base_path / "controlnet",
        "upscale_models": base_path / "upscale_models",
        "embeddings": base_path / "embeddings",
        "clip": base_path / "clip",
        "ipadapter": base_path / "ipadapter",
        "gligen": base_path / "gligen",
        "style_models": base_path / "style_models",
        "hypernetworks": base_path / "hypernetworks",
        "diffusers": base_path / "diffusers",
        "unclip": base_path / "unclip",
        "insightface": base_path / "insightface",
        "photomaker": base_path / "photomaker",
        "sadtalker": base_path / "sadtalker",
        "audio": base_path / "audio",
        "other": base_path / "other",
    }

def write_default_config(comfyui_dir: str, software: str = "comfyui") -> Path:
    """Writes the default config template using the specified software profile."""
    config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    profile = SOFTWARE_PROFILES.get(software, SOFTWARE_PROFILES["comfyui"])
    base = Path(comfyui_dir)

    # Build commented-out path overrides from the profile's layout
    paths_lines = []
    for model_type, rel_path in profile["model_paths"].items():
        full = (base / rel_path).as_posix()
        paths_lines.append(f'# {model_type} = "{full}"')
    # Also include any extra types from the standard infer_model_paths that the profile doesn't cover
    for k, v in infer_model_paths(comfyui_dir).items():
        if k not in profile["model_paths"]:
            paths_lines.append(f'# {k} = "{v.as_posix()}"')
    paths_section = "\n".join(paths_lines)

    default_content = f"""
comfyui_dir = "{base.as_posix()}"
software = "{software}"

# Individual paths are inferred from comfyui_dir by default.
# Uncomment and edit any line below to override a specific path.

# [paths]
{paths_section}

[api_keys]
# Can also be set via environment variables: KULAI_HF_TOKEN, KULAI_CIVITAI_TOKEN
huggingface = ""
civitai = ""

[download]
concurrent = 2
max_retries = 3

[resolution]
preferred_source = "huggingface"   # "huggingface" | "civitai" | "any"
auto_confidence_threshold = "high" # "high" | "medium"

[mappings]
# Static overrides for private or custom models
# "my_custom_lora.safetensors" = {{ type = "direct_url", url = "https://..." }}
"""
    with open(config_path, "w") as f:
        f.write(default_content.strip())
    return config_path

def get_model_path(asset_type: str, config: dict[str, Any]) -> Path:
    """Returns the override path if set in [paths], else inferred path from comfyui_dir."""
    comfyui_dir = config.get("comfyui_dir")
    if not comfyui_dir:
        raise ValueError("comfyui_dir not found in config.")

    if "paths" in config and asset_type in config["paths"]:
        return Path(config["paths"][asset_type])
    
    inferred_paths = infer_model_paths(comfyui_dir)
    return inferred_paths.get(asset_type, Path(comfyui_dir) / "models" / "other")
