import pytest
from pathlib import Path
from kulai.ui import UISession
from kulai.sources.base import ResolutionResult, ResolvedSource
from kulai.downloader import DownloadTask, DownloadResult


class TestUISession:
    """Tests for the UISession class."""
    
    def test_ui_session_initialization(self):
        """Test that UI session initializes correctly."""
        config = {"comfyui_dir": "C:/test"}
        results = []
        session = UISession(results, config)
        
        assert session.results == results
        assert session.config == config
        assert session.resolver is not None
    
    def test_format_bytes(self):
        """Test byte formatting."""
        config = {"comfyui_dir": "C:/test"}
        session = UISession([], config)
        
        assert session._format_bytes(500) == "500.00 B"
        assert session._format_bytes(1024) == "1.00 KB"
        assert session._format_bytes(1024 * 1024) == "1.00 MB"
        assert session._format_bytes(1024 * 1024 * 1024) == "1.00 GB"
        assert session._format_bytes(5_000_000_000) == "4.66 GB"
    
    def test_display_asset_list_does_not_crash(self):
        """Test that display_asset_list doesn't crash with various inputs."""
        config = {"comfyui_dir": "C:/test"}
        
        results = [
            ResolutionResult(
                input_name="test1.safetensors",
                resolved_name="test1.safetensors",
                source=ResolvedSource(
                    source_type="huggingface",
                    repo="test/repo",
                    file="test1.safetensors",
                    download_url=None,
                    sha256=None,
                    file_size_bytes=1000000,
                ),
                confidence="high",
                error=None,
            ),
            ResolutionResult(
                input_name="test2.safetensors",
                resolved_name="test2.safetensors",
                source=None,
                confidence="unknown",
                error=None,
            ),
        ]
        
        session = UISession(results, config)
        # Should not crash
        session.display_asset_list(results)
    
    def test_display_dry_run_table_does_not_crash(self):
        """Test that display_dry_run_table doesn't crash."""
        config = {"comfyui_dir": "C:/test"}
        session = UISession([], config)
        
        tasks = [
            DownloadTask(
                result=ResolutionResult(
                    input_name="test.safetensors",
                    resolved_name="test.safetensors",
                    source=ResolvedSource(
                        source_type="huggingface",
                        repo="test/repo",
                        file="test.safetensors",
                        download_url=None,
                        sha256=None,
                        file_size_bytes=5_000_000_000,
                    ),
                    confidence="high",
                    error=None,
                ),
                destination=Path("./models/checkpoints"),
                asset_type="checkpoint",
            )
        ]
        
        # Should not crash
        session.display_dry_run_table(tasks)
    
    def test_display_download_summary_does_not_crash(self):
        """Test that display_download_summary doesn't crash."""
        config = {"comfyui_dir": "C:/test"}
        session = UISession([], config)
        
        task = DownloadTask(
            result=ResolutionResult(
                input_name="test.safetensors",
                resolved_name="test.safetensors",
                source=None,
                confidence="high",
                error=None,
            ),
            destination=Path("./models"),
            asset_type="checkpoint",
        )
        
        results = [
            DownloadResult(task=task, success=True, skipped=False, error=None),
            DownloadResult(task=task, success=True, skipped=True, error=None),
            DownloadResult(task=task, success=False, skipped=False, error="Test error"),
        ]
        
        # Should not crash
        session.display_download_summary(results)
