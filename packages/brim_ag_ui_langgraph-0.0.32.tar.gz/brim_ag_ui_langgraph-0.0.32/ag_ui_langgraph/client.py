import logging
import uuid
import json
from typing import AsyncGenerator, Optional, Dict, Any, List

from ag_ui.core import (
    EventType,
    RunAgentInput,
    RunStartedEvent,
    RunFinishedEvent,
    RunErrorEvent,
    RawEvent,
    TextMessageStartEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    ToolCallStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    StateSnapshotEvent,
)

from langgraph_sdk import get_client

logger = logging.getLogger(__name__)

class AGUILangGraphClient:
    """AG-UI Agent that connects to a LangGraph server via langgraph-sdk."""

    def __init__(
        self,
        langgraph_client,
        assistant_id: str,
        name: str = "LangGraphServerAgent",
        description: Optional[str] = None
    ):
        self.client = langgraph_client
        self.assistant_id = assistant_id
        self.name = name
        self.description = description

    def clone(self):
        """Clone method to satisfy middleware expectations."""
        return AGUILangGraphClient(
            langgraph_client=self.client,
            assistant_id=self.assistant_id,
            name=self.name,
            description=self.description
        )

    def _dispatch_event(self, event):
        return event

    async def run(self, input: RunAgentInput) -> AsyncGenerator[str, None]:
        thread_id = input.thread_id
        run_id = input.run_id or str(uuid.uuid4())
        
        if not thread_id:
            logger.warning("AGUILangGraphClient requires a thread_id to join streams properly. Starting a fresh thread.")
            thread = await self.client.threads.create()
            thread_id = thread["thread_id"]

        # Check if there is an active run on this thread to rejoin
        active_runs = await self.client.runs.list(
            thread_id=thread_id, 
            status="running"
        )
        
        pending_runs = await self.client.runs.list(
            thread_id=thread_id,
            status="pending"
        )
        
        all_active = active_runs + pending_runs
        active_run = all_active[0] if all_active else None

        yield self._dispatch_event(
            RunStartedEvent(
                type=EventType.RUN_STARTED,
                thread_id=thread_id,
                run_id=run_id
            )
        )

        try:
            if active_run:
                logger.info(f"Joining active stream for run {active_run['run_id']}")
                stream = self.client.runs.join_stream(
                    thread_id=thread_id,
                    run_id=active_run["run_id"],
                    stream_mode=["messages-tuple", "values", "events"]
                )
            else:
                logger.info(f"Starting new stream for run {run_id}")
                # Naively map ag_ui messages to dicts for LangGraph
                messages = []
                if input.messages:
                    for msg in input.messages:
                        if msg.role == "user":
                            messages.append({"role": "user", "content": msg.content})
                        elif msg.role == "assistant":
                            messages.append({"role": "assistant", "content": msg.content})
                            
                payload = {"messages": messages} if messages else None
                
                stream = self.client.runs.stream(
                    thread_id=thread_id,
                    assistant_id=self.assistant_id,
                    input=payload,
                    stream_mode=["messages-tuple", "values", "events"],
                    version="v2",
                    on_disconnect="continue"
                )

            # Process StreamPartV2 chunks (dicts) or StreamPart chunks (objects from join_stream)
            async for chunk in stream:
                if isinstance(chunk, dict):
                    event_type = chunk.get("event")
                    data = chunk.get("data")
                else:
                    event_type = getattr(chunk, "event", None)
                    data = getattr(chunk, "data", None)
                
                if event_type == "error":
                    yield self._dispatch_event(
                        RunErrorEvent(
                            type=EventType.RUN_ERROR,
                            message=str(data.get("message", "Unknown LangGraph Server Error") if isinstance(data, dict) else "Unknown Error"),
                            raw_event=chunk
                        )
                    )
                    break
                    
                # Always yield RAW
                yield self._dispatch_event(
                    RawEvent(
                        type=EventType.RAW,
                        event=chunk
                    )
                )

                # Map basic messages
                if event_type == "messages/partial" or event_type == "messages/complete":
                    for msg_wrapper in data:
                        msg = msg_wrapper if isinstance(msg_wrapper, dict) else msg_wrapper.get("message", {})
                        
                        # Standard assistant message
                        if msg.get("type") == "ai" and not msg.get("tool_calls"):
                            msg_id = msg.get("id", str(uuid.uuid4()))
                            if event_type == "messages/partial":
                                yield self._dispatch_event(
                                    TextMessageContentEvent(
                                        type=EventType.TEXT_MESSAGE_CONTENT,
                                        message_id=msg_id,
                                        delta=msg.get("content", ""),
                                        raw_event=chunk
                                    )
                                )
                                
                if event_type == "values":
                    yield self._dispatch_event(
                        StateSnapshotEvent(
                            type=EventType.STATE_SNAPSHOT,
                            snapshot=data,
                            raw_event=chunk
                        )
                    )

        except Exception as e:
            logger.error(f"Stream error: {e}", exc_info=True)
            yield self._dispatch_event(
                RunErrorEvent(
                    type=EventType.RUN_ERROR,
                    message=f"Agent exception: {str(e)}"
                )
            )

        yield self._dispatch_event(
            RunFinishedEvent(
                type=EventType.RUN_FINISHED,
                thread_id=thread_id,
                run_id=run_id
            )
        )
