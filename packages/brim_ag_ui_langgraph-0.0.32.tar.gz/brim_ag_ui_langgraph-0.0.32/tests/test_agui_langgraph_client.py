import asyncio
import uuid
import unittest
from unittest.mock import AsyncMock, MagicMock

from ag_ui_langgraph.client import AGUILangGraphClient
from ag_ui.core import RunAgentInput, UserMessage

class TestAGUILangGraphClient(unittest.IsolatedAsyncioTestCase):

    async def test_run_with_no_active_run_starts_new_stream(self):
        # Setup mocks
        mock_sdk_client = AsyncMock()
        mock_sdk_client.threads.create.return_value = {"thread_id": "thread-123"}
        
        # Mock runs.list to return empty (no active runs)
        mock_sdk_client.runs.list.return_value = []
        
        # Mock runs.stream to yield a dummy event
        async def mock_stream(*args, **kwargs):
            yield {"event": "messages/partial", "data": [{"id": "msg-1", "type": "ai", "content": "Hello", "tool_calls": []}]}
        
        mock_sdk_client.runs = MagicMock()
        mock_sdk_client.runs.list = AsyncMock(return_value=[])
        mock_sdk_client.runs.stream = mock_stream
        mock_sdk_client.runs.join_stream = MagicMock()
        
        # Initialize client
        client = AGUILangGraphClient(langgraph_client=mock_sdk_client, assistant_id="asst-1")
        
        input_data = RunAgentInput(
            thread_id="thread-123",
            run_id="run-456",
            state={},
            messages=[UserMessage(id="m1", role="user", content="Hi")],
            tools=[],
            context=[],
            forwarded_props={}
        )
        
        # Execute run
        events = []
        async for event in client.run(input_data):
            events.append(event)
            
        # Verify
        mock_sdk_client.runs.join_stream.assert_not_called()
        
        # Assert we got RUN_STARTED, RAW, TEXT_MESSAGE_CONTENT, RUN_FINISHED
        event_types = [e.type for e in events]
        self.assertIn("RUN_STARTED", event_types)
        self.assertIn("TEXT_MESSAGE_CONTENT", event_types)
        self.assertIn("RUN_FINISHED", event_types)

    async def test_run_with_active_run_joins_stream(self):
        # Setup mocks
        mock_sdk_client = AsyncMock()
        mock_sdk_client.runs = MagicMock()
        
        # Mock runs.list to simulate an active run
        mock_sdk_client.runs.list = AsyncMock(side_effect=[
            [{"run_id": "active-run-789", "status": "running"}], # active
            [] # pending
        ])
        
        # Mock runs.join_stream to yield a dummy event
        async def mock_join_stream(*args, **kwargs):
            yield {"event": "values", "data": {"key": "value"}}
        
        mock_sdk_client.runs.join_stream = mock_join_stream
        mock_sdk_client.runs.stream = MagicMock()
        
        # Initialize client
        client = AGUILangGraphClient(langgraph_client=mock_sdk_client, assistant_id="asst-1")
        
        input_data = RunAgentInput(
            thread_id="thread-123",
            run_id="run-456",
            state={},
            messages=[],
            tools=[],
            context=[],
            forwarded_props={}
        )
        
        # Execute run
        events = []
        async for event in client.run(input_data):
            events.append(event)
            
        # Verify
        mock_sdk_client.runs.stream.assert_not_called()
        
        # Assert we got RUN_STARTED, RAW, STATE_SNAPSHOT, RUN_FINISHED
        event_types = [e.type for e in events]
        self.assertIn("RUN_STARTED", event_types)
        self.assertIn("STATE_SNAPSHOT", event_types)
        self.assertIn("RUN_FINISHED", event_types)

if __name__ == '__main__':
    unittest.main()
