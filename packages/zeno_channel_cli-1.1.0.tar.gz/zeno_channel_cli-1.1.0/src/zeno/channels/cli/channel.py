"""`CliChannel` — the reference terminal channel (R27, R28, R32).

Terminal stdin becomes `IncomingMessage`s; `OutgoingMessage`s are rendered
to stdout. The CLI is deliberately the simplest channel we ship: it
doubles as a manual smoke-test harness and as the working proof that the
generic `Channel` protocol is sufficient for real-world use.

Design notes:
  - `supports_streaming=False` in v0.1. The core `StreamBuffer`
    concatenates chunked replies into one consolidated `send()` at
    finalize-time for non-streaming channels, which the renderer emits
    as a single line. Sub-block token streaming is deferred until the
    `include_partial_messages` question (plan §line 121) is resolved.
  - Stdin is read via `asyncio.to_thread(stream.readline)` to keep the
    channel dependency-free — no `aioconsole`. This means at most one
    line read is in flight at a time, which matches REPL semantics.
  - `user_id` defaults to `$USER` (or "local" if unset) so a developer
    running `python main.py` gets a sensible tenant scope without
    configuration. Explicit override is encouraged in production.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import sys
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TextIO

from zeno.channels.cli.renderer import StdoutRenderer
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities

_log = logging.getLogger("zeno.channels.cli")


class ChannelError(RuntimeError):
    """Raised when the CLI channel is asked to operate after shutdown."""


@dataclass
class CliChannel:
    """Reference terminal channel. Implements `zeno.channels.protocol.Channel`."""

    name: str = "cli"
    user_id: str | None = None
    stdin: TextIO = field(default_factory=lambda: sys.stdin)
    stdout: TextIO = field(default_factory=lambda: sys.stdout)
    prompt: str = "> "
    _capabilities: Capabilities = field(
        default_factory=lambda: Capabilities(
            supports_streaming=False,
            supports_threading=False,
            max_message_length=None,
        ),
        init=False,
        repr=False,
    )
    _renderer: StdoutRenderer = field(init=False, repr=False)
    _started: bool = field(default=False, init=False, repr=False)
    _stopped: bool = field(default=False, init=False, repr=False)
    _inbox: asyncio.Queue[IncomingMessage] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not self.user_id:
            self.user_id = os.environ.get("USER") or "local"
        self._renderer = StdoutRenderer(stream=self.stdout, prompt=self.prompt)
        self._inbox = asyncio.Queue(maxsize=0)  # unbounded

    @property
    def capabilities(self) -> Capabilities:
        return self._capabilities

    async def start(self) -> None:
        """Announce the active `user_id` and print the first prompt. Idempotent."""
        if self._started:
            return
        self._started = True
        self._stopped = False
        _log.info("CliChannel started for user_id=%r", self.user_id)
        self._renderer.write_prompt()

    async def stop(self) -> None:
        """Close the renderer. Safe to call twice."""
        if self._stopped:
            return
        self._stopped = True
        self._renderer.close()

    async def send(self, message: OutgoingMessage) -> None:
        """Render `message.text` to stdout followed by a newline + prompt."""
        if self._stopped:
            raise ChannelError("CliChannel: send() after stop()")
        try:
            self._renderer.write_message(message)
        except ValueError as exc:
            raise ChannelError(str(exc)) from exc
        self._renderer.write_prompt()

    async def inbound_put(self, message: IncomingMessage) -> None:
        """Enqueue a synthetic message onto the receive() path.

        Used by zeno-scheduler to inject proactive messages without stdin.
        """
        await self._inbox.put(message)

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        """Yield one `IncomingMessage` per non-empty line until EOF or inbound_put."""
        assert self.user_id is not None  # post_init guarantees it
        while not self._stopped:
            stdin_task = asyncio.create_task(asyncio.to_thread(self._readline))
            queue_task = asyncio.create_task(self._inbox.get())
            done, pending = await asyncio.wait(
                {stdin_task, queue_task},
                return_when=asyncio.FIRST_COMPLETED,
            )
            # Cancel the loser and drain it to avoid ResourceWarning.
            # NOTE: cancellation of a threaded readline is best-effort; the
            # next line read may still be consumed by a lingering thread if
            # the queue_task wins the race.
            for t in pending:
                t.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await t

            if queue_task in done:
                yield queue_task.result()
                continue

            if stdin_task in done:
                line = stdin_task.result()
                if line == "":  # EOF
                    await self.stop()
                    return
                text = line.rstrip("\n")
                if not text.strip():
                    # Empty line: redraw prompt and keep reading.
                    self._renderer.write_prompt()
                    continue
                yield IncomingMessage(
                    user_id=self.user_id,
                    text=text,
                    received_at=datetime.now(UTC),
                    thread_key=None,
                )

    def _readline(self) -> str:
        try:
            return self.stdin.readline()
        except (EOFError, OSError):
            return ""
