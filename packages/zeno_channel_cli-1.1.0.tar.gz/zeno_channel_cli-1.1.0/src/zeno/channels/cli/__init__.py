"""zeno-channel-cli — reference terminal channel for Zeno."""

from __future__ import annotations

from zeno.channels.cli.channel import ChannelError, CliChannel

__all__ = [
    "ChannelError",
    "CliChannel",
]
