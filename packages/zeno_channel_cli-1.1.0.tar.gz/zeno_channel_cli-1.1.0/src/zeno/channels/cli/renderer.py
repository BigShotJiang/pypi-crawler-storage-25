"""Stdout rendering for `CliChannel` (R27, R33).

Isolated from `channel.py` so tests can swap in a `StringIO` writer without
monkey-patching `sys.stdout`. The renderer is intentionally minimal — one
line per agent reply — so the reference app reads like a plain REPL.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TextIO

from zeno.channels.messages import OutgoingMessage


@dataclass
class StdoutRenderer:
    """Write `OutgoingMessage.text` to a configurable text sink."""

    stream: TextIO
    prompt: str = "> "
    _closed: bool = field(default=False, init=False)

    def close(self) -> None:
        """Mark the sink closed; subsequent writes raise `ValueError`."""
        self._closed = True

    def is_closed(self) -> bool:
        return self._closed

    def write_prompt(self) -> None:
        """Print the REPL prompt without a trailing newline, flush immediately."""
        if self._closed:
            return
        self.stream.write(self.prompt)
        self.stream.flush()

    def write_message(self, msg: OutgoingMessage) -> None:
        """Print the reply's text followed by `\\n`; flush."""
        if self._closed:
            raise ValueError("StdoutRenderer is closed")
        text = msg.text or ""
        if text:
            self.stream.write(text)
        self.stream.write("\n")
        self.stream.flush()
