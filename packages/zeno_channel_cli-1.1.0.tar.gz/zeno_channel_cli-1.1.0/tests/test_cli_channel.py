"""`CliChannel` tests (R27, R28, R32).

Use `io.StringIO` for stdin and a capturing `TextIO` for stdout. No real
terminal interaction required, so these run in headless CI.
"""

from __future__ import annotations

import io
from typing import TYPE_CHECKING

import pytest
from zeno.channels.cli.channel import ChannelError, CliChannel
from zeno.channels.messages import OutgoingMessage
from zeno.channels.protocol import Channel
from zeno.runtime.streaming import StreamBuffer

if TYPE_CHECKING:
    pass


def _make(stdin_text: str = "") -> tuple[CliChannel, io.StringIO]:
    stdin = io.StringIO(stdin_text)
    stdout = io.StringIO()
    ch = CliChannel(user_id="alice", stdin=stdin, stdout=stdout, prompt="")
    return ch, stdout


async def test_channel_protocol_compliance() -> None:
    ch, _ = _make()
    assert isinstance(ch, Channel)


async def test_defaults_user_id_to_env_user(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("USER", "bob")
    ch = CliChannel(stdin=io.StringIO(), stdout=io.StringIO())
    assert ch.user_id == "bob"


async def test_defaults_user_id_to_local_when_env_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("USER", raising=False)
    ch = CliChannel(stdin=io.StringIO(), stdout=io.StringIO())
    assert ch.user_id == "local"


async def test_send_writes_text_with_newline() -> None:
    ch, stdout = _make()
    await ch.start()
    await ch.send(OutgoingMessage(text="hi"))
    assert "hi\n" in stdout.getvalue()


async def test_receive_yields_non_empty_lines() -> None:
    ch, _ = _make("hello\nworld\n")
    msgs = []
    async for m in ch.receive():
        msgs.append(m)
        if len(msgs) == 2:
            await ch.stop()
    assert [m.text for m in msgs] == ["hello", "world"]
    assert all(m.user_id == "alice" for m in msgs)


async def test_receive_skips_empty_lines() -> None:
    ch, _ = _make("\n   \nhi\n")
    msgs = []
    async for m in ch.receive():
        msgs.append(m)
        await ch.stop()
    assert [m.text for m in msgs] == ["hi"]


async def test_receive_terminates_on_eof() -> None:
    ch, _ = _make("one\n")
    msgs = [m async for m in ch.receive()]
    assert [m.text for m in msgs] == ["one"]
    # receive() returned cleanly without needing an explicit stop().


async def test_streaming_via_stream_buffer_emits_one_line() -> None:
    """Three chunks through StreamBuffer finalize to a single "foobarbaz\\n"."""
    ch, stdout = _make()
    await ch.start()
    buf = StreamBuffer(channel=ch)
    await buf.emit_chunk("foo")
    await buf.emit_chunk("bar")
    await buf.emit_chunk("baz")
    await buf.finalize()
    assert "foobarbaz\n" in stdout.getvalue()
    assert "foo\nbar" not in stdout.getvalue()  # no intermediate newlines


async def test_send_after_stop_raises() -> None:
    ch, _ = _make()
    await ch.start()
    await ch.stop()
    with pytest.raises(ChannelError):
        await ch.send(OutgoingMessage(text="nope"))


async def test_stop_is_idempotent() -> None:
    ch, _ = _make()
    await ch.start()
    await ch.stop()
    await ch.stop()  # must not raise


async def test_start_announces_user_id(caplog: pytest.LogCaptureFixture) -> None:
    import logging

    ch, _ = _make()
    with caplog.at_level(logging.INFO, logger="zeno.channels.cli"):
        await ch.start()
    assert any("alice" in record.getMessage() for record in caplog.records)


async def test_capabilities_declares_non_streaming_v0_1() -> None:
    """v0.1 CLI channel buffers through finalize; token streaming deferred."""
    ch, _ = _make()
    assert ch.capabilities.supports_streaming is False
    assert ch.capabilities.max_message_length is None
