"""Tests for CliChannel.inbound_put — scheduler injection path.

These verify that the internal queue bridge works correctly both in isolation
and in combination with stdin input.

Note on "concurrent" delivery: CliChannel.receive() races an asyncio.to_thread
stdin read against an asyncio.Queue get. Cancelling the stdin task does NOT
actually stop the underlying thread — the thread may still consume the next
line from the stream and discard the result. This is a documented v1 limitation.
Tests here therefore verify SEQUENTIAL delivery (inject → consume → stdin →
consume) rather than simultaneous racing, which is non-deterministic by design.
"""

from __future__ import annotations

import asyncio
import io
from datetime import UTC, datetime

from zeno.channels.cli.channel import CliChannel
from zeno.channels.messages import IncomingMessage


def _msg(text: str, user_id: str = "alice") -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 23, 12, 0, 0, tzinfo=UTC),
    )


def _make(stdin_text: str = "") -> CliChannel:
    return CliChannel(
        user_id="alice",
        stdin=io.StringIO(stdin_text),
        stdout=io.StringIO(),
        prompt="",
    )


async def test_inbound_put_enqueues_onto_internal_queue() -> None:
    """inbound_put puts the message directly onto the internal _inbox queue."""
    ch = _make()
    msg = _msg("scheduled trigger")
    await ch.inbound_put(msg)
    assert ch._inbox.qsize() == 1
    assert ch._inbox.get_nowait() is msg


async def test_inbound_put_multiple_messages_fifo() -> None:
    """Multiple inbound_put calls queue messages in order."""
    ch = _make()
    msgs = [_msg(f"msg-{i}") for i in range(3)]
    for m in msgs:
        await ch.inbound_put(m)
    assert [ch._inbox.get_nowait().text for _ in range(3)] == ["msg-0", "msg-1", "msg-2"]


async def test_receive_yields_injected_message_before_stdin() -> None:
    """Pre-populated queue item is yielded before stdin is consulted.

    We inject a message into the queue BEFORE receive() starts iterating.
    The queue_task wins the first asyncio.wait race, so the injected message
    arrives first, before any stdin line.
    """
    # stdin has one line — but the injected message should arrive first.
    ch = _make("stdin_line\n")
    injected = _msg("from_scheduler")
    await ch.inbound_put(injected)

    received: list[IncomingMessage] = []

    async def _collect() -> None:
        async for m in ch.receive():
            received.append(m)
            await ch.stop()  # stop after the first (injected) message

    await asyncio.wait_for(_collect(), timeout=2.0)

    assert len(received) == 1
    assert received[0].text == "from_scheduler"


async def test_receive_yields_injected_when_stdin_is_eof() -> None:
    """receive() yields an injected message when stdin returns EOF immediately."""
    ch = _make("")  # immediate EOF on readline

    injected = _msg("proactive")
    await ch.inbound_put(injected)

    received: list[IncomingMessage] = []

    async def _collect() -> None:
        async for m in ch.receive():
            received.append(m)
            await ch.stop()

    await asyncio.wait_for(_collect(), timeout=2.0)

    assert any(m.text == "proactive" for m in received)


async def test_receive_multiple_injected_all_yielded() -> None:
    """Multiple inbound_put calls are all yielded in FIFO order."""
    ch = _make("")
    messages = [_msg(f"msg-{i}") for i in range(3)]
    for m in messages:
        await ch.inbound_put(m)

    received: list[IncomingMessage] = []

    async def _collect() -> None:
        async for m in ch.receive():
            received.append(m)
            if len(received) >= 3:
                await ch.stop()

    await asyncio.wait_for(_collect(), timeout=2.0)
    assert [m.text for m in received] == ["msg-0", "msg-1", "msg-2"]


async def test_receive_stdin_only_without_injection() -> None:
    """Without any injection, receive() falls back to normal stdin behavior.

    This is the backwards-compat check: queue stays empty, stdin_task always wins.
    """
    ch = _make("hello\nworld\n")
    received: list[str] = []

    async def _collect() -> None:
        async for m in ch.receive():
            received.append(m.text)
            if len(received) >= 2:
                await ch.stop()

    await asyncio.wait_for(_collect(), timeout=2.0)
    assert set(received) == {"hello", "world"}


async def test_inbound_put_after_stdin_message() -> None:
    """An injected message after a stdin message is also delivered.

    Sequence: receive() first gets a stdin line (queue empty), then we
    inject a message into the queue, and receive() delivers it next.
    Uses asyncio.Event coordination to avoid threading races.
    """
    # Create a channel backed by a StringIO with exactly one line.
    ch = _make("stdin_line\n")

    received: list[str] = []
    stdin_received = asyncio.Event()

    async def _collect() -> None:
        async for m in ch.receive():
            received.append(m.text)
            if m.text == "stdin_line":
                stdin_received.set()
            if len(received) >= 2:
                await ch.stop()

    collect_task = asyncio.create_task(_collect())

    # Wait until the stdin line has been processed.
    await asyncio.wait_for(stdin_received.wait(), timeout=2.0)

    # Now inject a scheduled message — this should be picked up next.
    await ch.inbound_put(_msg("injected_after"))

    # Wait for both messages to be received.
    await asyncio.wait_for(collect_task, timeout=2.0)

    assert "stdin_line" in received
    assert "injected_after" in received
