# agentveil

[![PyPI](https://img.shields.io/pypi/v/agentveil)](https://pypi.org/project/agentveil/)
[![Python](https://img.shields.io/pypi/pyversions/agentveil)](https://pypi.org/project/agentveil/)
[![Tests](https://github.com/creatorrmode-lead/avp-sdk/actions/workflows/tests.yml/badge.svg)](https://github.com/creatorrmode-lead/avp-sdk/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![MCP](https://glama.ai/mcp/servers/creatorrmode-lead/avp-sdk/badges/card.svg)](https://glama.ai/mcp/servers/creatorrmode-lead/avp-sdk)

Python SDK for **Agent Veil Protocol** — trust enforcement for autonomous agents.

**PyPI**: [agentveil](https://pypi.org/project/agentveil/) | **API**: [agentveil.dev](https://agentveil.dev) | **Explorer**: [Live Dashboard](https://agentveil.dev/#explorer)

> [Why agent trust infrastructure matters](docs/SECURITY_CONTEXT.md) — verified CVEs, market data, and the structural problem AVP addresses.

<p align="center">
  <img src="docs/demo.gif" alt="AVP SDK Demo — identity, attestation, trust decisions, sybil resistance" width="720">
</p>

```python
from agentveil import AVPAgent

agent = AVPAgent.load("https://agentveil.dev", "my-agent")

# Should I trust this agent with my task?
decision = agent.can_trust("did:key:z6Mk...", min_tier="trusted")
if decision["allowed"]:
    delegate_task()
# → {"allowed": true, "tier": "trusted", "risk_level": "low", "reason": "..."}
```

---

## Install

```bash
pip install agentveil
```

## Quick Start

### Trust decision — one call

```python
from agentveil import AVPAgent

agent = AVPAgent.load("https://agentveil.dev", "my-agent")
decision = agent.can_trust("did:key:z6Mk...", min_tier="trusted")
print(decision["allowed"], decision["reason"])
```

### Auto-track with decorator

```python
from agentveil import avp_tracked

@avp_tracked("https://agentveil.dev", name="reviewer", to_did="did:key:z6Mk...")
def review_code(pr_url: str) -> str:
    return analysis

# Success → positive attestation | Exception → negative attestation
# First call → auto-registers agent + publishes card
```

### Try without a server

```python
agent = AVPAgent.create(mock=True, name="test_agent")
agent.register(display_name="Test Agent")
rep = agent.get_reputation()
print(rep)  # Works offline — real crypto, mocked HTTP
```

---

## Features

- **Trust Check** — `can_trust()` — one-call advisory trust decision: score + tier + risk + explanation
- **Offline Credentials** — Ed25519-signed reputation credentials. Verify trust without API calls
- **One-Line Decorator** — `@avp_tracked()` — auto-register, auto-attest, auto-protect
- **DID Identity** — W3C `did:key` (Ed25519). Portable agent identity
- **Reputation** — Peer-attested scoring with Bayesian confidence. Sybil-resistant
- **Attestations** — Signed peer-to-peer ratings. Negative ratings require SHA-256 evidence. Score updates immediately
- **Dispute Protection** — Contest unfair ratings. Auto-assigned arbitrator from verified pool
- **Agent Discovery** — Publish capabilities, find agents by skill and reputation
- **Webhook Alerts** — Push notifications on score drops ([setup guide](docs/WEBHOOKS.md))
- **Sybil Resistance** — Multi-layer graph analysis blocks fake agent rings
- **Trust Gate** — Reputation-based rate limiting (newcomer → basic → trusted → elite)

---

## Integrations

| Framework | Install | Quick Start |
|-----------|---------|-------------|
| **Any Python** | `pip install agentveil` | `@avp_tracked()` or `AVPAgent` directly |
| **CrewAI** | `pip install agentveil crewai` | `tools=[AVPReputationTool(), AVPDelegationTool()]` |
| **LangGraph** | `pip install agentveil langgraph` | `ToolNode([avp_check_reputation, avp_should_delegate])` |
| **AutoGen** | `pip install agentveil autogen-core` | `tools=avp_reputation_tools()` |
| **OpenAI** | `pip install agentveil openai` | `tools=avp_tool_definitions()` |
| **Claude** | `pip install agentveil mcp` | MCP server with 12 tools |
| **Hermes** | `pip install agentveil mcp` | MCP + agentskills.io skill |
| **Paperclip** | `pip install agentveil` | `avp_should_delegate()` + `avp_evaluate_team()` |

Full integration guides: [docs/INTEGRATIONS.md](docs/INTEGRATIONS.md)

---

## Security

- Ed25519 signature authentication with nonce anti-replay
- Input validation — injection detection, PII scanning
- Agent suspension — compromised agents instantly blocked
- Audit trail — SHA-256 hash-chained log, anchored to IPFS

---

## Documentation

| Doc | Description |
|-----|-------------|
| [API Reference](docs/API.md) | Full SDK method reference with examples |
| [Integrations](docs/INTEGRATIONS.md) | Framework-specific setup guides |
| [Webhook Alerts](docs/WEBHOOKS.md) | Push notification setup |
| [Protocol Spec](docs/PROTOCOL.md) | Wire format and authentication |
| [Security Context](docs/SECURITY_CONTEXT.md) | Why agent trust matters — CVEs and market data |
| [Changelog](CHANGELOG.md) | Version history |

---

## Examples

| Example | Description |
|---------|-------------|
| [`standalone_demo.py`](examples/standalone_demo.py) | No server needed — full SDK demo with mock mode |
| [`quickstart.py`](examples/quickstart.py) | Register, publish card, check reputation |
| [`two_agents.py`](examples/two_agents.py) | Full A2A interaction with attestations |
| [`verify_credential_standalone.py`](examples/verify_credential_standalone.py) | Offline credential verification (no SDK needed) |

Framework examples: [CrewAI](examples/crewai_example.py) · [LangGraph](examples/langgraph_example.py) · [AutoGen](examples/autogen_example.py) · [OpenAI](examples/openai_example.py) · [Claude MCP](examples/claude_mcp_example.py) · [Paperclip](examples/paperclip_example.py)

---

## License

MIT — see [LICENSE](LICENSE).
