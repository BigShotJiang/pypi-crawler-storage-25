"""boxd Python SDK — programmatic access to boxd cloud VMs.

Usage::

    from boxd import Compute

    with Compute(api_key="bxk_...") as c:
        box = c.box.create("my-vm")
        result = box.exec("echo", "hello")
        print(result.stdout)
        box.destroy()

For the async API::

    from boxd.aio import Compute

    async with Compute(api_key="bxk_...") as c:
        box = await c.box.create("my-vm")
        result = await box.exec("echo", "hello")
        print(result.stdout)
"""

from ._sync import (
    Box,
    BoxService,
    Compute,
    DiskHandle,
    DiskService,
    DomainService,
    NetworkService,
    TemplateService,
    TokenService,
)
from .exec import ExecResult, ExecProcess, StreamReader, StreamWriter
from .types import (
    BoxConfig,
    ConfigResult,
    Disk,
    DiskAttachment,
    Domain,
    LifecycleConfig,
    Network,
    NetworkConfig,
    Proxy,
    ProxyEntry,
    PtyInfo,
    ResumeResult,
    SuspendResult,
    Template,
    Token,
    TokenInfo,
    VolumeMount,
    WhoamiResult,
)
from .errors import (
    BoxdError,
    AuthenticationError,
    NotFoundError,
    QuotaExceededError,
    InvalidArgumentError,
    InternalError,
    TimeoutError,
    ConnectionError,
)

try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("boxd")
except Exception:
    # Fallback for source checkouts where the package isn't installed.
    __version__ = "0.0.0+source"

__all__ = [
    # Main client (sync)
    "Compute",
    # VM handle (sync)
    "Box",
    # Services (sync)
    "BoxService",
    "TemplateService",
    "DiskService",
    "DiskHandle",
    "DomainService",
    "NetworkService",
    "TokenService",
    # Exec primitives
    "ExecResult",
    "ExecProcess",
    "StreamReader",
    "StreamWriter",
    # Config / request types
    "BoxConfig",
    "LifecycleConfig",
    "NetworkConfig",
    "ProxyEntry",
    "VolumeMount",
    # Result / response types
    "Proxy",
    "Template",
    "Disk",
    "DiskAttachment",
    "Domain",
    "Network",
    "Token",
    "TokenInfo",
    "SuspendResult",
    "ResumeResult",
    "PtyInfo",
    "WhoamiResult",
    "ConfigResult",
    # Exceptions
    "BoxdError",
    "AuthenticationError",
    "NotFoundError",
    "QuotaExceededError",
    "InvalidArgumentError",
    "InternalError",
    "TimeoutError",
    "ConnectionError",
    # Version
    "__version__",
]
