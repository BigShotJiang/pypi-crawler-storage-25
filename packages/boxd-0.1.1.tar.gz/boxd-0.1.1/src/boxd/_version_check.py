"""SDK update notice — piggybacks on every gRPC call's metadata.

The proxy attaches `x-boxd-py-sdk-latest` to response initial metadata when
a newer SDK version is available. We send `x-boxd-py-sdk-version` outbound
so the server can log who's calling. On the first response that carries a
strictly-newer latest version, we print a one-time stderr nag.
"""

from __future__ import annotations

import re
import sys

import grpc
import grpc.aio

REQ_HEADER = "x-boxd-py-sdk-version"
RESP_HEADER = "x-boxd-py-sdk-latest"
UPGRADE_CMD = "pip install --upgrade boxd"

_notified = False


def _current_version() -> str:
    # Late import so this module is importable from inside the package
    # without circular-import drama (boxd/__init__.py imports a lot).
    from . import __version__

    return __version__


class VersionCheckInterceptor(
    grpc.aio.UnaryUnaryClientInterceptor,
    grpc.aio.UnaryStreamClientInterceptor,
    grpc.aio.StreamUnaryClientInterceptor,
    grpc.aio.StreamStreamClientInterceptor,
):
    """Adds outbound SDK-version header, watches inbound for an upgrade hint."""

    def _add_version(self, client_call_details):
        metadata = list(client_call_details.metadata or [])
        metadata.append((REQ_HEADER, _current_version()))
        return client_call_details._replace(metadata=metadata)

    async def _maybe_notify_from_call(self, call):
        global _notified
        if _notified:
            return
        try:
            md = await call.initial_metadata()
        except Exception:
            return
        if md is None:
            return
        latest = None
        for key, value in md:
            if key.lower() == RESP_HEADER:
                latest = value.strip() if isinstance(value, str) else None
                break
        if not latest:
            return
        current = _current_version()
        if _compare_semver(latest, current) <= 0:
            return
        _notified = True
        print(file=sys.stderr)
        print(
            f"  A new version of boxd is available (v{latest}, you have v{current}). Update with:",
            file=sys.stderr,
        )
        print(f"    {UPGRADE_CMD}", file=sys.stderr)

    async def intercept_unary_unary(self, continuation, client_call_details, request):
        new_details = self._add_version(client_call_details)
        call = await continuation(new_details, request)
        await self._maybe_notify_from_call(call)
        return call

    async def intercept_unary_stream(self, continuation, client_call_details, request):
        new_details = self._add_version(client_call_details)
        call = await continuation(new_details, request)
        await self._maybe_notify_from_call(call)
        return call

    async def intercept_stream_unary(
        self, continuation, client_call_details, request_iterator
    ):
        new_details = self._add_version(client_call_details)
        call = await continuation(new_details, request_iterator)
        await self._maybe_notify_from_call(call)
        return call

    async def intercept_stream_stream(
        self, continuation, client_call_details, request_iterator
    ):
        new_details = self._add_version(client_call_details)
        call = await continuation(new_details, request_iterator)
        await self._maybe_notify_from_call(call)
        return call


_SEMVER_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)(.*)$")
_SUFFIX_SEPARATORS_RE = re.compile(r"[.-]")
_SUFFIX_LETTER_DIGIT_RE = re.compile(r"(?<=\D)(?=\d)|(?<=\d)(?=\D)")


def _compare_semver(a: str, b: str) -> int:
    """Return >0 if a > b, <0 if a < b, 0 if equal/unparseable.

    Handles pre-release suffixes ("0.1.1-dev.4", "0.1.1.dev4") by
    component-wise compare, numeric where both components are all-digits.
    A release (no suffix) ranks above any pre-release of the same
    numeric prefix. Unparseable input returns 0 — never nag on garbage.
    """
    pa = _SEMVER_RE.match(a.strip())
    pb = _SEMVER_RE.match(b.strip())
    if not pa or not pb:
        return 0
    for i in range(1, 4):
        ai, bi = int(pa.group(i)), int(pb.group(i))
        if ai != bi:
            return ai - bi
    sa, sb = pa.group(4) or "", pb.group(4) or ""
    if sa == "" and sb != "":
        return 1
    if sa != "" and sb == "":
        return -1
    return _compare_suffix(sa, sb)


def _compare_suffix(a: str, b: str) -> int:
    if a == b:
        return 0
    parts_a = _parse_suffix(a)
    parts_b = _parse_suffix(b)
    for i in range(max(len(parts_a), len(parts_b))):
        pa = parts_a[i] if i < len(parts_a) else None
        pb = parts_b[i] if i < len(parts_b) else None
        if pa is None:
            return -1  # shorter prerelease ranks lower
        if pb is None:
            return 1
        na = int(pa) if pa.isdigit() else None
        nb = int(pb) if pb.isdigit() else None
        if na is not None and nb is not None:
            if na != nb:
                return na - nb
        elif na is not None:
            return -1  # numeric < alphanumeric (SemVer §11.4.3)
        elif nb is not None:
            return 1
        elif pa != pb:
            return -1 if pa < pb else 1
    return 0


def _parse_suffix(s: str) -> list[str]:
    """Decompose "-dev.6" / ".dev6" into ["dev", "6"]."""
    if not s:
        return []
    stripped = s.lstrip("-.")
    if not stripped:
        return []
    components: list[str] = []
    for piece in _SUFFIX_SEPARATORS_RE.split(stripped):
        if not piece:
            continue
        components.extend(p for p in _SUFFIX_LETTER_DIGIT_RE.split(piece) if p)
    return components
