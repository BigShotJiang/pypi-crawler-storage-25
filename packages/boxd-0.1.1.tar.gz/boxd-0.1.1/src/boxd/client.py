"""Compute — main entry point for the boxd SDK."""

from __future__ import annotations

import os

import grpc
import grpc.aio

from ._generated import api_pb2, api_pb2_grpc
from ._utils import resolve_endpoint
from ._version_check import VersionCheckInterceptor
from .auth import TokenAuth
from .boxes import BoxService
from .disks import DiskService
from .domains import DomainService
from .errors import AuthenticationError, from_grpc_error
from .networks import NetworkService
from .templates import TemplateService
from .tokens import TokenService
from .types import ConfigResult, WhoamiResult

_DEFAULT_API_URL = "http://boxd.sh:9443"
_DEFAULT_EXCHANGE_URL = "https://boxd.sh/api/v1/auth/token"

# Named environments. Each is a (api_url, exchange_url) preset; explicit
# api_url / exchange_url args still override.
_ENVIRONMENT_URLS: dict[str, tuple[str, str]] = {
    "production": (_DEFAULT_API_URL, _DEFAULT_EXCHANGE_URL),
    "staging": (
        "http://boxd-stg.sh:9443",
        "https://boxd-stg.sh/api/v1/auth/token",
    ),
}


def _resolve_environment(explicit: str | None) -> str:
    """Pick environment preset: explicit arg > BOXD_ENVIRONMENT env > production."""
    if explicit:
        if explicit not in _ENVIRONMENT_URLS:
            raise ValueError(
                f"unknown environment {explicit!r}; expected one of "
                f"{sorted(_ENVIRONMENT_URLS)}"
            )
        return explicit
    from_env = os.environ.get("BOXD_ENVIRONMENT")
    if from_env in _ENVIRONMENT_URLS:
        return from_env
    return "production"


class Compute:
    """Main client for the boxd API.

    Usage::

        async with Compute(api_key="bxk_...") as c:
            box = await c.box.create("my-vm")
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        token: str | None = None,
        api_url: str | None = None,
        exchange_url: str | None = None,
        environment: str | None = None,
    ) -> None:
        env = _resolve_environment(environment)
        preset_api_url, preset_exchange_url = _ENVIRONMENT_URLS[env]
        self._api_url = (
            api_url
            or os.environ.get("BOXD_API_URL")
            or preset_api_url
        )
        self._exchange_url = (
            exchange_url
            or os.environ.get("BOXD_EXCHANGE_URL")
            or preset_exchange_url
        )

        resolved_key = api_key or os.environ.get("BOXD_API_KEY")
        resolved_token = token or os.environ.get("BOXD_TOKEN")

        if not resolved_key and not resolved_token:
            raise AuthenticationError(
                "provide api_key, token, or set BOXD_API_KEY / BOXD_TOKEN"
            )

        self._auth = TokenAuth(
            api_key=resolved_key,
            token=resolved_token,
            exchange_url=self._exchange_url,
        )

        self._channel: grpc.aio.Channel | None = None
        self._stub: api_pb2_grpc.BoxdApiStub | None = None

        # Sub-services
        self.box = BoxService(self)
        self.template = TemplateService(self)
        self.disk = DiskService(self)
        self.domain = DomainService(self)
        self.network = NetworkService(self)
        self.token = TokenService(self)

    async def _ensure_channel(self) -> api_pb2_grpc.BoxdApiStub:
        """Lazily create the gRPC channel and return the stub."""
        if self._stub is not None:
            return self._stub

        interceptors = [self._auth.interceptor(), VersionCheckInterceptor()]
        endpoint = resolve_endpoint(self._api_url)

        if endpoint.use_tls:
            creds = grpc.ssl_channel_credentials()
            channel = grpc.aio.secure_channel(
                endpoint.host,
                creds,
                interceptors=interceptors,
            )
        else:
            channel = grpc.aio.insecure_channel(
                endpoint.host,
                interceptors=interceptors,
            )

        self._channel = channel
        self._stub = api_pb2_grpc.BoxdApiStub(channel)
        return self._stub

    async def _call(self, method_name: str, request):
        """Call a gRPC method on the stub, converting errors."""
        stub = await self._ensure_channel()
        method = getattr(stub, method_name)
        try:
            return await method(request)
        except grpc.aio.AioRpcError as e:
            raise from_grpc_error(e) from e

    async def whoami(self) -> WhoamiResult:
        """Return information about the authenticated user."""
        resp = await self._call("Whoami", api_pb2.WhoamiRequest())
        return WhoamiResult(
            user_id=resp.user_id,
            fingerprints=list(resp.pubkey_fingerprints),
            default_network_id=resp.default_network_id,
        )

    async def config(self) -> ConfigResult:
        """Return server configuration."""
        resp = await self._call("GetConfig", api_pb2.GetConfigRequest())
        return ConfigResult(
            default_image=resp.default_image,
            zone=resp.zone,
        )

    async def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._stub = None

    async def __aenter__(self) -> Compute:
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()
