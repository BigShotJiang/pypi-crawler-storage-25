"""End-to-end lifecycle tests (sync).

These tests create and destroy VMs, so they're slow.
Skipped by default. Run with: pytest -m e2e
"""

import time
from pathlib import Path
from tempfile import NamedTemporaryFile

import pytest
from boxd.errors import BoxdError


def _wait_ready(box, timeout=90):
    """Poll until the VM accepts exec commands."""
    for i in range(timeout):
        try:
            box.exec("true")
            return i
        except Exception:
            time.sleep(1)
    pytest.fail(f"VM {box.name} not ready after {timeout}s")


pytestmark = pytest.mark.e2e


# ── Create / Exec / Destroy ─────────────────────────────────────

def test_create_exec_destroy(compute):
    box = compute.box.create()
    try:
        assert box.id
        assert box.name

        _wait_ready(box)

        result = box.exec("echo", "hello from e2e")
        assert result.exit_code == 0
        assert "hello from e2e" in result.stdout
    finally:
        box.destroy()
        assert box.status == "destroyed"


def test_create_with_custom_name(compute):
    box = compute.box.create(name="sdk-test-named")
    try:
        assert box.name == "sdk-test-named"
        _wait_ready(box)
    finally:
        box.destroy()


# ── Exec edge cases ─────────────────────────────────────────────

def test_exec_args_with_spaces(compute):
    """Verify shlex.quote preserves argument boundaries."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        result = box.exec("echo", "hello world")
        assert result.exit_code == 0
        assert "hello world" in result.stdout
    finally:
        box.destroy()


def test_exec_args_with_special_chars(compute):
    """Verify special shell characters are escaped."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        result = box.exec("echo", "a|b&&c;d")
        assert result.exit_code == 0
        assert "a|b&&c;d" in result.stdout
    finally:
        box.destroy()


def test_exec_with_env(compute):
    """Verify env vars are passed correctly."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        result = box.exec("sh", "-c", "echo $MY_VAR", env={"MY_VAR": "test_value"})
        assert result.exit_code == 0
        assert "test_value" in result.stdout
    finally:
        box.destroy()


def test_exec_with_env_spaces(compute):
    """Verify env vars with spaces are quoted properly."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        result = box.exec("sh", "-c", "echo $MY_VAR", env={"MY_VAR": "hello world"})
        assert result.exit_code == 0
        assert "hello world" in result.stdout
    finally:
        box.destroy()


def test_exec_streaming(compute):
    """Verify streaming exec works (validates HasField fix)."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        proc = box.exec("echo", "streaming test", stream=True)
        chunks = list(proc.iter_stdout())
        exit_code = proc.wait()
        output = b"".join(chunks).decode()
        assert "streaming test" in output
        assert exit_code == 0
    finally:
        box.destroy()


# ── File I/O ────────────────────────────────────────────────────

def test_write_read_bytes(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)
        box.write_file(b"e2e test content", "/tmp/e2e-test.txt")
        data = box.read_file("/tmp/e2e-test.txt")
        assert data == b"e2e test content"
    finally:
        box.destroy()


def test_write_read_with_path(compute):
    """Verify write_file accepts a Path object."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        with NamedTemporaryFile(suffix=".txt", delete=False) as f:
            f.write(b"from local path")
            local_path = Path(f.name)
        box.write_file(local_path, "/tmp/e2e-path.txt")
        data = box.read_file("/tmp/e2e-path.txt")
        assert data == b"from local path"
        local_path.unlink()
    finally:
        box.destroy()


def test_write_read_binary(compute):
    """Verify non-UTF8 binary data roundtrips."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        binary_data = bytes(range(256))
        box.write_file(binary_data, "/tmp/e2e-binary.bin")
        data = box.read_file("/tmp/e2e-binary.bin")
        assert data == binary_data
    finally:
        box.destroy()


# ── Fork ────────────────────────────────────────────────────────

def test_fork_preserves_files(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)
        box.write_file(b"fork test data", "/tmp/fork-test.txt")
        # Ensure file is flushed to disk before forking (fork captures disk state)
        box.exec("sync")

        forked = compute.box.fork(box.name)
        try:
            _wait_ready(forked)
            data = forked.read_file("/tmp/fork-test.txt")
            assert data == b"fork test data"
        finally:
            forked.destroy()
    finally:
        box.destroy()


def test_fork_with_custom_name(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)
        forked = compute.box.fork(box.name, name="sdk-test-fork")
        try:
            assert forked.name == "sdk-test-fork"
            _wait_ready(forked)
        finally:
            forked.destroy()
    finally:
        box.destroy()


# ── Suspend / Resume ────────────────────────────────────────────

def test_suspend_resume(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)

        result = box.suspend()
        assert result.suspend_us > 0
        assert box.status == "suspended"

        # SuspendVm currently returns before the raft commit landing the new
        # status is applied (~250ms gap on staging). ResumeVm's admission
        # check then sees status=running and rejects. Poll the server view
        # until it agrees the VM is suspended before attempting resume.
        # Track: server-side fix to make SuspendVm block until commit-applied.
        for _ in range(20):
            if compute.box.get(box.id).status == "suspended":
                break
            time.sleep(0.25)

        result = box.resume()
        assert result.resume_us > 0
        assert box.status == "running"

        time.sleep(2)
        r = box.exec("echo", "after resume")
        assert r.exit_code == 0
        assert "after resume" in r.stdout
    finally:
        box.destroy()


# ── Get by name / lifecycle ─────────────────────────────────────

def test_create_and_get_by_name(compute):
    box = compute.box.create()
    try:
        fetched = compute.box.get(box.name)
        assert fetched.id == box.id
        assert fetched.name == box.name
    finally:
        box.destroy()

    vms = compute.box.list()
    ids = [v.id for v in vms]
    assert box.id not in ids


@pytest.mark.skip(reason="server bug: VM never reaches 'running' after stop/start re-spawn")
def test_stop_start(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)

        box.stop()
        assert box.status == "stopped"

        box.start()
        assert box.status == "running"

        # VM needs time to re-boot after start
        time.sleep(3)
        _wait_ready(box)

        result = box.exec("echo", "after restart")
        assert result.exit_code == 0
        assert "after restart" in result.stdout
    finally:
        box.destroy()


@pytest.mark.skip(reason="server bug: VM never reaches 'running' after reboot re-spawn")
def test_reboot(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)

        box.reboot()
        assert box.status == "running"

        # VM needs time to re-boot
        time.sleep(3)
        _wait_ready(box)

        result = box.exec("echo", "after reboot")
        assert result.exit_code == 0
        assert "after reboot" in result.stdout
    finally:
        box.destroy()


# ── Error paths ─────────────────────────────────────────────────

def test_destroy_twice(compute):
    box = compute.box.create()
    box.destroy()
    with pytest.raises(BoxdError):
        box.destroy()


def test_exec_on_destroyed_vm(compute):
    box = compute.box.create()
    _wait_ready(box)
    box.destroy()
    with pytest.raises(BoxdError):
        box.exec("echo", "should fail")


# ── Proxy lifecycle on fresh VM ─────────────────────────────────

def test_proxy_lifecycle(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)

        proxies = box.proxies()
        assert any(p.is_default for p in proxies)

        proxy = box.create_proxy("e2e-api", port=3001)
        assert proxy.name == "e2e-api"
        assert proxy.port == 3001

        proxies = box.proxies()
        assert "e2e-api" in [p.name for p in proxies]

        box.delete_proxy("e2e-api")
        proxies = box.proxies()
        assert "e2e-api" not in [p.name for p in proxies]
    finally:
        box.destroy()
