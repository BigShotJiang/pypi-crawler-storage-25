"""Unit tests for boxd._version_check — semver compare + interceptor metadata behavior."""

from __future__ import annotations

import pytest
from grpc.aio import ClientCallDetails

from boxd import _version_check
from boxd._version_check import (
    REQ_HEADER,
    RESP_HEADER,
    VersionCheckInterceptor,
    _compare_semver,
)

# Picked to be unambiguously newer/older than any real shipped SDK so tests
# don't silently flip meaning when the package version bumps.
NEWER = "99.0.0"
OLDER = "0.0.1"
CURRENT = "0.1.1"


@pytest.fixture(autouse=True)
def reset_notified():
    _version_check._notified = False
    yield
    _version_check._notified = False


@pytest.fixture
def stub_current(monkeypatch):
    monkeypatch.setattr(_version_check, "_current_version", lambda: CURRENT)


@pytest.fixture
def interceptor():
    return VersionCheckInterceptor()


def _details(metadata):
    return ClientCallDetails(
        method="/test/Method",
        timeout=None,
        metadata=metadata,
        credentials=None,
        wait_for_ready=None,
    )


def _make_call(metadata):
    class FakeCall:
        async def initial_metadata(self):
            return metadata

    return FakeCall()


# --- _compare_semver ---


def test_compare_semver_patch_greater():
    assert _compare_semver("0.1.1", "0.1.0") > 0


def test_compare_semver_patch_lesser():
    assert _compare_semver("0.1.0", "0.1.1") < 0


def test_compare_semver_equal():
    assert _compare_semver("0.1.0", "0.1.0") == 0


def test_compare_semver_major_dominates_minor():
    assert _compare_semver("1.0.0", "0.99.99") > 0


def test_compare_semver_minor_dominates_patch():
    assert _compare_semver("0.2.0", "0.1.99") > 0


def test_compare_semver_release_greater_than_prerelease():
    assert _compare_semver("0.1.1", "0.1.1-dev.4") > 0
    assert _compare_semver("0.1.1-dev.4", "0.1.1") < 0


def test_compare_semver_prerelease_lex_order():
    assert _compare_semver("0.1.1-dev.4", "0.1.1-dev.5") < 0
    assert _compare_semver("0.1.1-dev.5", "0.1.1-dev.4") > 0


def test_compare_semver_unparseable_returns_zero():
    assert _compare_semver("garbage", "0.1.0") == 0
    assert _compare_semver("0.1.0", "garbage") == 0
    assert _compare_semver("v1.0.0", "0.1.0") == 0
    assert _compare_semver("", "0.1.0") == 0


def test_compare_semver_whitespace_tolerated():
    assert _compare_semver("  0.1.1  ", "0.1.0") > 0


# --- VersionCheckInterceptor._add_version ---


def test_add_version_appends_header(stub_current, interceptor):
    new = interceptor._add_version(_details([]))
    assert (REQ_HEADER, CURRENT) in new.metadata


def test_add_version_preserves_existing_metadata(stub_current, interceptor):
    new = interceptor._add_version(_details([("authorization", "Bearer abc")]))
    assert ("authorization", "Bearer abc") in new.metadata
    assert (REQ_HEADER, CURRENT) in new.metadata


def test_add_version_handles_none_metadata(stub_current, interceptor):
    new = interceptor._add_version(_details(None))
    assert new.metadata == [(REQ_HEADER, CURRENT)]


# --- VersionCheckInterceptor._maybe_notify_from_call ---


async def test_maybe_notify_warns_when_latest_greater(stub_current, interceptor, capsys):
    await interceptor._maybe_notify_from_call(_make_call([(RESP_HEADER, NEWER)]))
    err = capsys.readouterr().err
    assert NEWER in err
    assert CURRENT in err
    assert "pip install --upgrade boxd" in err
    assert _version_check._notified is True


@pytest.mark.parametrize(
    "metadata",
    [
        pytest.param([(RESP_HEADER, CURRENT)], id="latest-equal"),
        pytest.param([(RESP_HEADER, OLDER)], id="latest-older"),
        pytest.param([("other-header", "value")], id="header-missing"),
        pytest.param([], id="metadata-empty"),
        pytest.param(None, id="metadata-none"),
        pytest.param([(RESP_HEADER, "   ")], id="header-whitespace-only"),
    ],
)
async def test_maybe_notify_silent(stub_current, interceptor, capsys, metadata):
    await interceptor._maybe_notify_from_call(_make_call(metadata))
    assert capsys.readouterr().err == ""
    assert _version_check._notified is False


async def test_maybe_notify_silent_when_initial_metadata_raises(
    stub_current, interceptor, capsys
):
    class FailingCall:
        async def initial_metadata(self):
            raise RuntimeError("connection lost")

    await interceptor._maybe_notify_from_call(FailingCall())
    assert capsys.readouterr().err == ""


async def test_maybe_notify_warns_only_once(stub_current, interceptor, capsys):
    call = _make_call([(RESP_HEADER, NEWER)])
    await interceptor._maybe_notify_from_call(call)
    assert NEWER in capsys.readouterr().err
    await interceptor._maybe_notify_from_call(call)
    assert capsys.readouterr().err == ""


async def test_maybe_notify_case_insensitive_header(stub_current, interceptor, capsys):
    await interceptor._maybe_notify_from_call(_make_call([("X-Boxd-Py-Sdk-Latest", NEWER)]))
    assert NEWER in capsys.readouterr().err


async def test_maybe_notify_strips_whitespace_in_header_value(
    stub_current, interceptor, capsys
):
    await interceptor._maybe_notify_from_call(_make_call([(RESP_HEADER, f"  {NEWER}  ")]))
    assert NEWER in capsys.readouterr().err
