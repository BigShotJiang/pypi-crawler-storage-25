"""Configuration models with per-camera override support."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from homesec.models.filter import FilterConfig
from homesec.models.vlm import VLMConfig


class AlertPolicyConfig(BaseModel):
    """Alert policy plugin configuration."""

    backend: str = "default"
    enabled: bool = True
    config: dict[str, Any] | BaseModel = Field(default_factory=dict)

    @field_validator("backend", mode="before")
    @classmethod
    def _normalize_backend(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.lower()
        return value


class StoragePathsConfig(BaseModel):
    """Logical storage paths for different artifact types."""

    clips_dir: str = "clips"
    backups_dir: str = "backups"
    artifacts_dir: str = "artifacts"


class StorageConfig(BaseModel):
    """Storage backend configuration."""

    model_config = {"extra": "forbid"}

    backend: str = "dropbox"
    config: dict[str, Any] | BaseModel = Field(default_factory=dict)
    paths: StoragePathsConfig = Field(default_factory=StoragePathsConfig)

    @field_validator("backend", mode="before")
    @classmethod
    def _normalize_backend(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.lower()
        return value


class StateStoreConfig(BaseModel):
    """State store configuration."""

    dsn_env: str | None = None
    dsn: str | None = None

    @model_validator(mode="after")
    def _validate_backend(self) -> StateStoreConfig:
        if not (self.dsn_env or self.dsn):
            raise ValueError("state_store.dsn_env or state_store.dsn required for postgres")
        return self


class NotifierConfig(BaseModel):
    """Notifier configuration entry."""

    backend: str
    enabled: bool = True
    config: dict[str, Any] | BaseModel = Field(default_factory=dict)

    @field_validator("backend", mode="before")
    @classmethod
    def _normalize_backend(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.lower()
        return value


class RetentionConfig(BaseModel):
    """Retention configuration for local storage."""

    model_config = {"extra": "forbid"}

    max_local_size_bytes: int = Field(
        default=1_000_000_000,
        ge=0,
        description="Max local clip bytes to retain before oldest-first pruning.",
    )


_DURATION_PATTERN = re.compile(r"^\s*(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>s|m|h|d)\s*$")


def _parse_duration_seconds(value: str) -> float:
    match = _DURATION_PATTERN.fullmatch(value)
    if match is None:
        raise ValueError("duration must use a number followed by s, m, h, or d")

    amount = float(match.group("value"))
    unit = match.group("unit")
    multiplier = {"s": 1.0, "m": 60.0, "h": 3600.0, "d": 86400.0}[unit]
    return amount * multiplier


class PostgresBackupUploadConfig(BaseModel):
    """Postgres backup upload configuration."""

    model_config = {"extra": "forbid"}

    enabled: bool = True
    storage_backend: Literal["primary"] = "primary"


class PostgresBackupConfig(BaseModel):
    """Periodic Postgres backup configuration."""

    model_config = {"extra": "forbid"}

    enabled: bool = False
    interval: str = "24h"
    keep_count: int = Field(default=5, ge=1)
    local_dir: Path = Path("./backups/postgres")
    timeout_s: float = Field(default=1800.0, gt=0.0)
    compression_level: int = Field(default=6, ge=0, le=9)
    upload: PostgresBackupUploadConfig = Field(default_factory=PostgresBackupUploadConfig)

    @field_validator("interval")
    @classmethod
    def _validate_interval(cls, value: str) -> str:
        seconds = _parse_duration_seconds(value)
        if seconds < 15 * 60:
            raise ValueError("maintenance.postgres_backup.interval must be at least 15m")
        return value.strip()

    @property
    def interval_seconds(self) -> float:
        """Return configured backup interval in seconds."""
        return _parse_duration_seconds(self.interval)


class MaintenanceConfig(BaseModel):
    """Background maintenance configuration."""

    model_config = {"extra": "forbid"}

    postgres_backup: PostgresBackupConfig = Field(default_factory=PostgresBackupConfig)


class ConcurrencyConfig(BaseModel):
    """Concurrency limits for pipeline stages."""

    max_clips_in_flight: int = Field(default=4, ge=1)
    upload_workers: int = Field(default=4, ge=1)
    filter_workers: int = Field(default=4, ge=1)
    vlm_workers: int = Field(default=2, ge=1)


class RetryConfig(BaseModel):
    """Retry configuration for transient failures."""

    max_attempts: int = Field(default=3, ge=1)
    backoff_s: float = Field(default=1.0, ge=0.0)


class HLSPreviewConfig(BaseModel):
    """Backend-specific HLS preview configuration."""

    model_config = {"extra": "forbid"}

    segment_duration_ms: int = Field(
        default=1000,
        ge=1,
        description="HLS segment duration in milliseconds.",
    )
    live_window_segments: int = Field(
        default=4,
        ge=1,
        description="Number of segments retained in the live window.",
    )
    storage_dir: Path = Field(
        default=Path("/tmp/homesec-preview"),
        description="Directory used for live HLS segments and playlists.",
    )
    audio_enabled: bool = Field(
        default=True,
        description="Include audio in preview output when the source provides it.",
    )
    audio_codec: Literal["auto", "copy", "aac"] = Field(
        default="auto",
        description="Preview audio handling mode.",
    )
    video_codec: Literal["auto", "copy", "h264"] = Field(
        default="auto",
        description="Preview video handling mode.",
    )


class PreviewConfig(BaseModel):
    """Top-level live preview configuration."""

    model_config = {"extra": "forbid"}

    enabled: bool = False
    backend: str = "hls"
    token_ttl_s: int = Field(
        default=60,
        ge=1,
        description="Lifetime for camera-scoped preview tokens.",
    )
    idle_timeout_s: float = Field(
        default=30.0,
        ge=0.0,
        description="How long to keep the preview publisher alive without viewers.",
    )
    recording_policy: Literal["stop_on_recording", "allow_during_recording"] = Field(
        default="stop_on_recording",
        description=(
            "How preview behaves while the camera is recording. "
            "'allow_during_recording' is best-effort and may consume an extra RTSP session."
        ),
    )
    config: HLSPreviewConfig = Field(default_factory=HLSPreviewConfig)

    @model_validator(mode="before")
    @classmethod
    def _normalize_and_validate_backend(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value

        config = dict(value)
        backend = config.get("backend", "hls")
        if isinstance(backend, str):
            backend = backend.lower()
            config["backend"] = backend

        if backend != "hls":
            raise ValueError("preview.backend must be 'hls' in config contract v1")

        return config

    @field_validator("backend", mode="before")
    @classmethod
    def _normalize_backend(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.lower()
        return value


class FastAPIServerConfig(BaseModel):
    """Configuration for the FastAPI server."""

    model_config = {"extra": "forbid"}

    enabled: bool = True
    host: str = "0.0.0.0"
    port: int = 8081
    cors_origins: list[str] = Field(default_factory=lambda: ["*"])
    auth_enabled: bool = False
    api_key_env: str | None = None
    ui_dist_dir: str = "ui/dist"

    @model_validator(mode="before")
    @classmethod
    def _apply_env_defaults(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value

        config = dict(value)

        if "ui_dist_dir" not in config:
            ui_dist_dir_env = os.environ.get("HOMESEC_SERVER_UI_DIST_DIR")
            if ui_dist_dir_env:
                config["ui_dist_dir"] = ui_dist_dir_env

        return config

    def get_api_key(self) -> str | None:
        """Resolve API key from environment variable."""
        if not self.api_key_env:
            return None
        return os.environ.get(self.api_key_env)

    @model_validator(mode="after")
    def _validate_auth(self) -> FastAPIServerConfig:
        if self.auth_enabled and not self.api_key_env:
            raise ValueError("server.api_key_env is required when server.auth_enabled is true")
        return self


class CameraSourceConfig(BaseModel):
    """Camera source configuration wrapper."""

    model_config = {"extra": "forbid"}

    backend: str
    config: dict[str, Any] | BaseModel = Field(default_factory=dict)

    @field_validator("backend", mode="before")
    @classmethod
    def _normalize_backend(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.lower()
        return value


class CameraConfig(BaseModel):
    """Camera configuration and clip source selection."""

    name: str
    enabled: bool = True
    source: CameraSourceConfig


class Config(BaseModel):
    """Main configuration with per-camera override support."""

    model_config = {"extra": "forbid"}

    version: int = 1
    cameras: list[CameraConfig]
    storage: StorageConfig
    state_store: StateStoreConfig = Field(default_factory=StateStoreConfig)
    notifiers: list[NotifierConfig] = Field(default_factory=list)
    retention: RetentionConfig = Field(default_factory=RetentionConfig)
    maintenance: MaintenanceConfig = Field(default_factory=MaintenanceConfig)
    concurrency: ConcurrencyConfig = Field(default_factory=ConcurrencyConfig)
    retry: RetryConfig = Field(default_factory=RetryConfig)
    server: FastAPIServerConfig = Field(default_factory=FastAPIServerConfig)
    preview: PreviewConfig = Field(default_factory=PreviewConfig)
    filter: FilterConfig
    vlm: VLMConfig
    alert_policy: AlertPolicyConfig
