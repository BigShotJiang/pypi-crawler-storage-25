"""API route registration."""

from __future__ import annotations

from fastapi import Depends, FastAPI

from homesec.api.dependencies import (
    require_database,
    require_normal_mode,
    verify_api_key,
    verify_media_access,
)
from homesec.api.routes import (
    cameras,
    clips,
    config,
    health,
    maintenance,
    media,
    onvif,
    preview,
    runtime,
    setup,
    stats,
)


def register_routes(app: FastAPI) -> None:
    """Register all API routers."""
    app.include_router(health.router)
    app.include_router(setup.router, dependencies=[Depends(verify_api_key)])
    app.include_router(
        config.router,
        dependencies=[Depends(verify_api_key), Depends(require_normal_mode)],
    )
    app.include_router(
        cameras.router,
        dependencies=[Depends(verify_api_key), Depends(require_normal_mode)],
    )
    app.include_router(
        preview.control_router,
        dependencies=[Depends(verify_api_key), Depends(require_normal_mode)],
    )
    app.include_router(
        preview.playback_router,
        dependencies=[Depends(require_normal_mode)],
    )
    app.include_router(
        clips.router,
        dependencies=[
            Depends(verify_api_key),
            Depends(require_normal_mode),
            Depends(require_database),
        ],
    )
    app.include_router(
        media.router,
        dependencies=[
            Depends(require_normal_mode),
            Depends(require_database),
            Depends(verify_media_access),
        ],
    )
    app.include_router(
        stats.router,
        dependencies=[
            Depends(verify_api_key),
            Depends(require_normal_mode),
            Depends(require_database),
        ],
    )
    app.include_router(
        runtime.router,
        dependencies=[Depends(verify_api_key), Depends(require_normal_mode)],
    )
    app.include_router(
        maintenance.router,
        dependencies=[Depends(verify_api_key), Depends(require_normal_mode)],
    )
    app.include_router(onvif.router, dependencies=[Depends(verify_api_key)])
