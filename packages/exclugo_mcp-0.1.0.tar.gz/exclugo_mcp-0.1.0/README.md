# Exclugo MCP Server

MCP (Model Context Protocol) server for the **Exclugo** healthcare compliance background screening platform. Lets AI assistants (Claude Desktop, Claude Code, Cursor, etc.) interact with Exclugo — managing facilities, employees, vendors, licenses, NPIs, reports, billing, and more.

## Quick Start

### Install

```bash
pip install exclugo-mcp
```

Or run without installing:

```bash
uvx exclugo-mcp
```

### Configure Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "exclugo": {
      "command": "uvx",
      "args": ["exclugo-mcp"],
      "env": {
        "EXCLUGO_BASE_URL": "https://app.exclugo.com",
        "EXCLUGO_API_TOKEN": "your-token-here"
      }
    }
  }
}
```

**Where is this file?**
- **Mac**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

### Configure Claude Code

Add to your Claude Code MCP settings:

```json
{
  "mcpServers": {
    "exclugo": {
      "command": "uvx",
      "args": ["exclugo-mcp"],
      "env": {
        "EXCLUGO_BASE_URL": "https://app.exclugo.com",
        "EXCLUGO_API_TOKEN": "your-token-here"
      }
    }
  }
}
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `EXCLUGO_BASE_URL` | Yes | Your Exclugo instance URL (e.g. `https://app.exclugo.com`) |
| `EXCLUGO_API_TOKEN` | Recommended | Your API auth token (skip the login step) |
| `EXCLUGO_USERNAME` | Optional | Username for the `authenticate` tool |
| `EXCLUGO_PASSWORD` | Optional | Password for the `authenticate` tool |

If you don't have an API token, you can use the `authenticate` tool in your AI assistant to log in with username/password.

## Available Tools (78 total)

### Authentication
- `authenticate` — Sign in with username/password

### Facilities (10 tools)
- `list_facilities` — List all facilities
- `get_facility` — Get facility details
- `create_facility` — Create a new facility
- `update_facility` — Update facility settings
- `delete_facility` — Delete a facility
- `get_facility_products` — Get facility's monitoring products
- `get_facility_fees` — Get facility fees
- `get_facility_files` — Get facility documents
- `get_facility_report` — Get facility reports
- `get_facilities_by_product` — Group facilities by product

### Employees (5 tools)
- `create_employee` — Add employee for screening
- `edit_employee` — Edit employee record
- `search_employees` — Search employees
- `search_by_ssn` — Search by SSN or report number
- `get_employee_address_history` — Get address history

### Vendors (4 tools)
- `create_vendor_individual` — Add individual vendor
- `create_vendor_organization` — Add organization vendor
- `edit_vendor` — Edit vendor record
- `search_vendors` — Search vendors

### Licenses (8 tools)
- `create_license` — Add license for monitoring
- `get_expiring_licenses` — List expiring/expired licenses
- `run_single_license_check` — Run a license verification
- `add_manual_license_check` — Manually add check result
- `get_license_files` — Get license documents
- `generate_613a_letter` — Generate 613A letter
- `send_613a_email` — Email 613A letter
- `email_license_status` — Email license status update

### NPIs (3 tools)
- `create_npi` — Add NPI for monitoring
- `edit_npi` — Edit NPI record
- `search_npis` — Search NPIs

### Reports & Searches (10 tools)
- `list_reports` — List reports by status
- `get_report` — Get report details
- `get_report_searches` — Get searches for a report
- `get_search_detail` — Get search details
- `get_search_alerts` — Get alerts for a search
- `get_ssn_trace` — Get SSN trace info
- `get_report_history` — Get report history
- `add_report_note` — Add a note to a report
- `save_report_document` — Save document to report
- `get_source_lists` — List exclusion sources

### Billing (10 tools)
- `list_invoices` — List all invoices
- `get_invoice` — Get invoice details
- `create_invoice_pdf` — Generate invoice PDF
- `get_invoice_excel` — Export invoice to Excel
- `auto_create_invoices` — Auto-generate invoices
- `bulk_invoice_action` — Bulk invoice operations
- `get_billing_alerts` — Get billing alerts
- `list_sales_reps` — List sales reps
- `get_commission_by_month` — Get commission data
- `create_iif_file` — QuickBooks IIF export

### Calendar (6 tools)
- `create_calendar` — Create/update calendar
- `get_calendar_for_facility` — Get facility calendar
- `get_calendar_events` — Get calendar events
- `get_all_events` — List all events
- `calendar_override` — Override calendar event
- `send_email_reminder` — Send email reminder

### Users (6 tools)
- `get_current_user` — Get current user info
- `list_admin_users` — List admin users
- `get_user_detail` — Get user details
- `add_client_user` — Add client user
- `get_client_users` — List client users
- `get_user_facilities` — Get user's facilities

### Uploads (5 tools)
- `admin_upload` — Admin bulk upload
- `client_upload` — Client bulk upload
- `get_upload_logs` — Get upload history
- `get_failed_records` — Get failed records
- `resolve_failed_records` — Resolve failed records

### Monitoring (6 tools)
- `run_exclusion_matching` — Run exclusion checks
- `run_sex_offender_check` — Run SO registry check
- `run_dmf_check` — Run Death Master File check
- `run_npi_check` — Run NPI registry check
- `run_ssn_plus_exclusion_check` — Run SSN+exclusion check
- `run_ssn_verification` — Run SSN verification

### Dashboard (4 tools)
- `get_dashboard` — Get dashboard summary
- `get_client_report` — Get client report
- `update_alert` — Acknowledge/update alert
- `disable_monitoring` — Disable monitoring for entity

## Publishing to PyPI

```bash
cd exclugo-mcp
pip install build twine
python -m build
twine upload dist/*
```

## Development

```bash
cd exclugo-mcp
pip install -e .

# Run the server
EXCLUGO_BASE_URL=http://localhost:8000 EXCLUGO_API_TOKEN=your-token exclugo-mcp

# Test with MCP inspector
npx @modelcontextprotocol/inspector exclugo-mcp
```

## License

MIT
