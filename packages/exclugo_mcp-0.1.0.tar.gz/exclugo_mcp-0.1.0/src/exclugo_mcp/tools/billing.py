from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def list_invoices() -> list | dict:
        """List all invoices."""
        return await client.get("/api/invoices/")

    @mcp.tool()
    async def get_invoice(invoice_id: int) -> dict:
        """Get details for a specific invoice."""
        return await client.get(f"/api/invoices/{invoice_id}/")

    @mcp.tool()
    async def create_invoice_pdf(invoice_id: int) -> dict:
        """Generate/download a PDF for an invoice."""
        return await client.get(f"/api/createinvoice/{invoice_id}/")

    @mcp.tool()
    async def get_invoice_excel(invoice_id: int) -> dict:
        """Get an Excel export of an invoice."""
        return await client.get(f"/api/invoice/excel/{invoice_id}/")

    @mcp.tool()
    async def auto_create_invoices() -> dict:
        """Auto-generate invoices for all facilities that are due."""
        return await client.post("/api/autocreateinvoices/")

    @mcp.tool()
    async def bulk_invoice_action(action: str, invoice_ids: list[int]) -> dict:
        """Perform a bulk action on invoices. action: 'email', 'charge', 'mark_paid', etc.
        invoice_ids: list of invoice IDs to act on."""
        return await client.post(
            f"/api/bulkinvoiceactions/{action}/",
            json={"ids": invoice_ids},
        )

    @mcp.tool()
    async def get_billing_alerts() -> list | dict:
        """Get billing-related alerts (overdue invoices, etc.)."""
        return await client.get("/api/billingalerts/")

    @mcp.tool()
    async def list_sales_reps() -> list | dict:
        """List all sales representatives."""
        return await client.get("/api/salesrep/")

    @mcp.tool()
    async def get_commission_by_month(start: str, end: str) -> list | dict:
        """Get sales commission data for a date range. start/end format: YYYY-MM-DD."""
        return await client.get(f"/api/commissionbymonth/{start}/{end}/")

    @mcp.tool()
    async def create_iif_file() -> dict:
        """Create a QuickBooks IIF export file for invoices."""
        return await client.post("/api/createiif/")
