from .knn_iris import load_knn_iris
from .text_nb import load_text_nb
from .wine_nb import load_wine_nb
from .digits_nb import load_digits_nb
from .isolation_forest import load_isolation_forest
from .random_forest import load_random_forest
from .bayesian_network import load_bayesian_network
from .hmm_weather import load_hmm_weather
from .hmm_dna import load_hmm_dna
from .speaker_gmm import load_speaker_gmm
from .gmm_digits import load_gmm_digits
from .parzen_shapes import load_parzen_shapes
from .knn_shapes import load_knn_shapes


def about():
    return {
        "load_knn_iris": "KNN on Iris",
        "load_text_nb": "Text Naive Bayes",
        "load_wine_nb": "Wine classification NB",
        "load_digits_nb": "Digit classification NB",
        "load_isolation_forest": "Anomaly detection",
        "load_random_forest": "Random Forest model",
        "load_bayesian_network": "Bayesian Network",
        "load_hmm_weather": "Weather HMM",
        "load_hmm_dna": "DNA HMM",
        "load_speaker_gmm": "Speaker recognition",
        "load_gmm_digits": "Digit clustering GMM",
        "load_parzen_shapes": "Parzen shape classify",
        "load_knn_shapes": "KNN shape classify"
    }