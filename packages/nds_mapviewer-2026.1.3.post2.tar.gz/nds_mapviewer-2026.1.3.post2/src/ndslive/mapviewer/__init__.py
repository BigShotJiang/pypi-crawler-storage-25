"""
ndslive.mapviewer - Python CLI and API for running the NDS MapViewer Docker container.

Usage:
    from ndslive.mapviewer import MapViewer

    # Start with config file
    mv = MapViewer(config="config.yaml", edition="community")
    mv.start()

    # Or with context manager
    with MapViewer(config="config.yaml") as mv:
        mv.start()
        print(f"MapViewer at {mv.url}")
"""

from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("nds-mapviewer")
except Exception:
    __version__ = "0.0.0+dev"

__default_image__ = "latest"

from .viewer import MapViewer
from .exceptions import (
    MapViewerError,
    RuntimeNotInstalled,
    RuntimeNotRunning,
    DockerNotInstalled,
    DockerNotRunning,
    RegistryNotLoggedIn,
    ImagePullFailed,
    ConfigError,
    ContainerError,
    ContainerNotFound,
    ContainerAlreadyRunning,
)

__all__ = [
    "__version__",
    "__default_image__",
    "MapViewer",
    "MapViewerError",
    "RuntimeNotInstalled",
    "RuntimeNotRunning",
    "DockerNotInstalled",
    "DockerNotRunning",
    "RegistryNotLoggedIn",
    "ImagePullFailed",
    "ConfigError",
    "ContainerError",
    "ContainerNotFound",
    "ContainerAlreadyRunning",
]
