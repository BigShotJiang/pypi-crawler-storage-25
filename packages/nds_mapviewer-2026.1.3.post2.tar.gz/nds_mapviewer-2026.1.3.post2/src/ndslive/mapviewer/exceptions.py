"""Custom exceptions for ndslive.mapviewer."""


_DOCTOR_HINT = (
    "Run 'ndslive-setup doctor' for a diagnosis, or 'ndslive-setup' to "
    "reconfigure."
)


class MapViewerError(Exception):
    """Base exception for all MapViewer errors."""

    pass


class RuntimeNotInstalled(MapViewerError):
    """No container runtime (Docker or Podman) is installed."""

    def __init__(self, message: str | None = None):
        self.message = message or (
            "No container runtime found.\n\n"
            "Please install Docker or Podman:\n"
            "  Docker:  https://docs.docker.com/get-docker/\n"
            "  Podman:  https://podman.io/getting-started/installation\n\n"
            f"{_DOCTOR_HINT}"
        )
        super().__init__(self.message)


# Backward-compatible alias
DockerNotInstalled = RuntimeNotInstalled


class RuntimeNotRunning(MapViewerError):
    """Container runtime daemon is not running."""

    def __init__(self, message: str | None = None):
        self.message = message or (
            "Container runtime is not running.\n\n"
            "Please start your container runtime:\n"
            "  Docker (macOS/Windows):  Open Docker Desktop\n"
            "  Docker (Linux):          sudo systemctl start docker\n"
            "  Podman (macOS/Windows):  podman machine start\n"
            "  Podman (Linux):          systemctl --user start podman.socket\n\n"
            f"{_DOCTOR_HINT}"
        )
        super().__init__(self.message)


# Backward-compatible alias
DockerNotRunning = RuntimeNotRunning


class RegistryNotLoggedIn(MapViewerError):
    """User is not logged into the required container registry."""

    def __init__(self, registry: str, edition: str):
        self.registry = registry
        self.edition = edition
        runtime = "docker"
        try:
            from .container_runtime import detect_runtime
            runtime = detect_runtime()
        except Exception:
            pass
        self.message = (
            f"Not logged into registry for {edition} edition.\n\n"
            f"Please login with your NDS credentials:\n"
            f"  {runtime} login {registry}\n\n"
            "To generate an identity token (recommended):\n"
            "  1. Log in to https://artifactory.nds-association.org\n"
            "  2. Click your username (top right) -> Edit Profile\n"
            "  3. Under Identity Tokens, click Generate\n"
            f"  4. Use the token as your password for {runtime} login\n\n"
            f"{_DOCTOR_HINT}"
        )
        super().__init__(self.message)


class ImagePullFailed(MapViewerError):
    """Failed to pull the Docker image."""

    def __init__(self, image: str, reason: str | None = None):
        self.image = image
        self.reason = reason
        msg = f"Failed to pull image: {image}"
        if reason:
            msg += f"\n\nReason: {reason}"
        self.message = msg
        super().__init__(self.message)


class ConfigError(MapViewerError):
    """Error in the MapViewer configuration."""

    def __init__(self, message: str, file_path: str | None = None):
        self.file_path = file_path
        if file_path:
            self.message = f"Configuration error in {file_path}:\n{message}"
        else:
            self.message = f"Configuration error: {message}"
        super().__init__(self.message)


class ContainerError(MapViewerError):
    """Error related to container operations."""

    def __init__(self, message: str, container_id: str | None = None):
        self.container_id = container_id
        self.message = message
        super().__init__(self.message)


class ContainerNotFound(ContainerError):
    """MapViewer container not found."""

    def __init__(self, name: str = "ndslive-mapviewer"):
        self.name = name
        self.message = (
            f"Container '{name}' not found.\n\n"
            "Start the MapViewer first:\n"
            "  mapviewer run /path/to/data"
        )
        super().__init__(self.message)


class ContainerAlreadyRunning(ContainerError):
    """MapViewer container is already running."""

    def __init__(self, name: str = "ndslive-mapviewer", port: int | None = None):
        self.name = name
        self.port = port
        msg = f"Container '{name}' is already running."
        if port:
            msg += f"\n\nAccess the MapViewer at: http://localhost:{port}"
        msg += "\n\nThe running instance will be replaced on next 'mapviewer run'."
        self.message = msg
        super().__init__(self.message)


class RegistryQueryFailed(MapViewerError):
    """Failed to query the remote container registry."""

    def __init__(self, registry: str, reason: str | None = None):
        self.registry = registry
        self.reason = reason
        runtime = "docker"
        try:
            from .container_runtime import detect_runtime
            runtime = detect_runtime()
        except Exception:
            pass
        msg = f"Failed to query registry: {registry}"
        if reason:
            msg += f"\n\nReason: {reason}"
        msg += (
            "\n\nPossible causes:"
            f"\n  - Not logged in: run '{runtime} login {registry}'"
            "\n  - Behind a proxy: configure your runtime's proxy settings"
            f"\n\n{_DOCTOR_HINT}"
        )
        self.message = msg
        super().__init__(self.message)
