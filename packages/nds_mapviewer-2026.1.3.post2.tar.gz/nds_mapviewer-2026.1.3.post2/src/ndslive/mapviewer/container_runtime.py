"""Container runtime abstraction supporting Docker and Podman.

Provides a thin layer over subprocess to invoke whichever container
runtime (``docker`` or ``podman``) is available on the host.  All
higher-level operations in :mod:`docker_client` delegate here.
"""

from __future__ import annotations

import functools
import json
import os
import platform
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Runtime detection
# ---------------------------------------------------------------------------

def _runtime_exists(runtime: str) -> bool:
    """Return ``True`` when *runtime* exists on ``PATH``."""
    return shutil.which(runtime) is not None


def _runtime_is_responsive(runtime: str) -> bool:
    """Return ``True`` when *runtime* responds to ``info`` quickly."""
    try:
        result = subprocess.run(
            [runtime, "info"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def _saved_runtime_preference() -> str | None:
    """Return the ``runtime_name`` saved by ``ndslive-setup``, if any.

    ``ndslive-setup`` writes ``~/.nds/setup.json`` after a successful wizard
    run. When the user has explicitly configured a runtime there, we honour
    that choice ahead of environment-based detection so the two tools stay
    in sync.
    """
    config_path = Path.home() / ".nds" / "setup.json"
    if not config_path.exists():
        return None
    try:
        with open(config_path) as f:
            value = json.load(f).get("runtime_name")
    except (json.JSONDecodeError, OSError):
        return None
    if value in ("docker", "podman"):
        return value
    return None


@functools.lru_cache(maxsize=1)
def detect_runtime() -> str:
    """Return the name of the container runtime to use.

    Resolution order:

    1. Saved ``runtime_name`` in ``~/.nds/setup.json`` (written by ``ndslive-setup``).
    2. ``CONTAINER_RUNTIME`` environment variable (``docker`` or ``podman``).
    3. ``docker`` on ``$PATH``.
    4. ``podman`` on ``$PATH``.

    Raises :class:`FileNotFoundError` when no runtime is found.
    """
    saved = _saved_runtime_preference()
    if saved and _runtime_exists(saved):
        return saved

    env = os.environ.get("CONTAINER_RUNTIME", "").strip().lower()
    if env in ("docker", "podman"):
        if _runtime_exists(env):
            return env
        raise FileNotFoundError(f"Requested container runtime '{env}' not found on PATH.")

    installed = [candidate for candidate in ("docker", "podman") if _runtime_exists(candidate)]
    for candidate in installed:
        if _runtime_is_responsive(candidate):
            return candidate

    if installed:
        # Preserve a clear "runtime not running" error path in higher-level
        # callers when binaries exist but no daemon/service is responsive.
        return installed[0]

    raise FileNotFoundError(
        "No container runtime found.\n\n"
        "Please install Docker or Podman:\n"
        "  Docker: https://docs.docker.com/get-docker/\n"
        "  Podman: https://podman.io/getting-started/installation\n\n"
        "Tip: run 'ndslive-setup doctor' for a guided diagnosis."
    )


def runtime_name() -> str:
    """Human-friendly capitalised name of the detected runtime."""
    return detect_runtime().capitalize()


# ---------------------------------------------------------------------------
# Subprocess helpers
# ---------------------------------------------------------------------------

def run(
    *args: str,
    check: bool = True,
    timeout: float | None = 30,
    extra_env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a container-runtime command, capturing stdout and stderr.

    Parameters
    ----------
    *args:
        Arguments appended after the runtime binary
        (e.g. ``"ps"``, ``"-a"``).
    check:
        Raise :class:`subprocess.CalledProcessError` on non-zero exit.
    timeout:
        Seconds before the process is killed (``None`` = no limit).
    extra_env:
        Additional environment variables merged into the current env.
    """
    cmd = [detect_runtime(), *args]
    env = None
    if extra_env:
        env = {**os.environ, **extra_env}
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=check,
        timeout=timeout,
        env=env,
    )


def run_json(*args: str, timeout: float | None = 30) -> Any:
    """Run a command and return its stdout parsed as JSON."""
    result = run(*args, timeout=timeout)
    return json.loads(result.stdout)


def stream(
    *args: str,
    merge_stderr: bool = False,
) -> subprocess.Popen[str]:
    """Start a long-running runtime command for line-by-line streaming.

    The caller is responsible for reading ``proc.stdout`` and
    eventually calling ``proc.terminate()`` / ``proc.wait()``.

    Parameters
    ----------
    merge_stderr:
        Redirect stderr into stdout so both appear on ``proc.stdout``.
        Useful for commands like ``podman pull`` that write progress
        to stderr.
    """
    cmd = [detect_runtime(), *args]
    return subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT if merge_stderr else subprocess.PIPE,
        text=True,
    )


# ---------------------------------------------------------------------------
# Runtime introspection
# ---------------------------------------------------------------------------

def is_available() -> bool:
    """Return ``True`` if a container runtime binary exists on PATH."""
    try:
        detect_runtime()
        return True
    except FileNotFoundError:
        return False


def is_running() -> bool:
    """Return ``True`` if the runtime daemon is responsive."""
    try:
        result = run("info", check=False, timeout=5)
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def ping() -> None:
    """Verify that the runtime daemon is responsive.

    Raises the same exceptions as :func:`run` on failure.
    """
    run("info", timeout=5)


def get_version() -> str:
    """Return the server version string (e.g. ``"27.0.3"``)."""
    result = run("version", "--format", "{{.Server.Version}}", timeout=5)
    return result.stdout.strip()


def get_platform() -> str:
    """Return the server OS (e.g. ``"linux"``)."""
    try:
        result = run("version", "--format", "{{.Server.Os}}", timeout=5)
        value = result.stdout.strip()
        if value:
            return value
    except Exception:
        pass
    return platform.system().lower()


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def get_auth_config_paths() -> list[Path]:
    """Return candidate auth-config file paths for the active runtime.

    Docker:
        ``~/.docker/config.json``

    Podman (checked in order):
        ``$XDG_RUNTIME_DIR/containers/auth.json``  (Linux session runtime dir)
        ``~/.config/containers/auth.json``         (Linux / macOS default)
        ``$APPDATA/containers/auth.json``          (Windows ``podman machine``)

    Intentionally excludes ``~/.docker/config.json`` for podman: on macOS
    Docker Desktop's ``credsStore`` helper runs on the host and podman
    cannot invoke it, so a Docker login must not imply a Podman login.
    """
    rt = detect_runtime()
    paths: list[Path] = []

    if rt == "podman":
        xdg = os.environ.get("XDG_RUNTIME_DIR")
        if xdg:
            paths.append(Path(xdg) / "containers" / "auth.json")
        paths.append(Path.home() / ".config" / "containers" / "auth.json")
        appdata = os.environ.get("APPDATA")
        if appdata:
            paths.append(Path(appdata) / "containers" / "auth.json")
    else:
        paths.append(Path.home() / ".docker" / "config.json")

    return paths


# ---------------------------------------------------------------------------
# Host networking helpers
# ---------------------------------------------------------------------------

def get_extra_host_args() -> list[str]:
    """Return CLI args for ``host.docker.internal`` on the current platform.

    Docker Desktop (macOS / Windows) resolves it natively.
    On Linux both Docker and Podman need ``--add-host``.
    """
    if platform.system() != "Linux":
        return []
    return ["--add-host", "host.docker.internal:host-gateway"]


# ---------------------------------------------------------------------------
# Stats output parsing
# ---------------------------------------------------------------------------

_UNIT_MULTIPLIERS = {
    "B": 1,
    "kB": 1_000,
    "KB": 1_000,
    "MB": 1_000_000,
    "MiB": 1_048_576,
    "GB": 1_000_000_000,
    "GiB": 1_073_741_824,
    "TB": 1_000_000_000_000,
    "TiB": 1_099_511_627_776,
}

_SIZE_RE = re.compile(r"([\d.]+)\s*([A-Za-z]+)")


def parse_size_string(s: str) -> float:
    """Parse a human-readable size string (e.g. ``"256MiB"``) to bytes."""
    m = _SIZE_RE.match(s.strip())
    if not m:
        return 0.0
    value = float(m.group(1))
    unit = m.group(2)
    return value * _UNIT_MULTIPLIERS.get(unit, 1)
