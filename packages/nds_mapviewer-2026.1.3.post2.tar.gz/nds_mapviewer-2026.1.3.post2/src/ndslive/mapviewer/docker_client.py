"""Container runtime wrapper with validation and error handling.

All container operations go through :mod:`container_runtime` subprocess
calls so that both Docker and Podman are supported transparently.
"""

from __future__ import annotations

import json
import platform
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterator

from . import container_runtime as rt
from .exceptions import (
    ContainerAlreadyRunning,
    ContainerNotFound,
    ImagePullFailed,
    RegistryNotLoggedIn,
    RegistryQueryFailed,
    RuntimeNotInstalled,
    RuntimeNotRunning,
)

CONTAINER_NAME = "ndslive-mapviewer"
CONTAINER_LABEL = "app=ndslive-mapviewer"

REGISTRIES = {
    "community": "artifactory.nds-association.org/ndslive-dockerreg",
    "member": "artifactory.nds-association.org/tooling-dockerreg",
}

IMAGE_NAME = "nds-mapviewer"

KNOWN_TAGS = ["latest", "dev", "dev-rc"]


# ---------------------------------------------------------------------------
# Container info dataclass (replaces Docker SDK Container object)
# ---------------------------------------------------------------------------

@dataclass
class ContainerInfo:
    """Lightweight representation of a container returned by inspect/list."""

    name: str
    id: str
    status: str
    image: str
    host_port: int | None = None
    started_at: str | None = None
    labels: dict[str, str] = field(default_factory=dict)


def _container_from_inspect(data: dict) -> ContainerInfo:
    """Build a :class:`ContainerInfo` from ``<runtime> container inspect`` JSON."""
    name = data.get("Name", "").lstrip("/")
    state = data.get("State", {})
    status = state.get("Status", "unknown")
    started_at = state.get("StartedAt")

    # Image tag — may be full reference or just ID
    image = data.get("Config", {}).get("Image", "")

    # Extract host port for 8089/tcp
    host_port = None
    ports = data.get("NetworkSettings", {}).get("Ports", {})
    binding = ports.get("8089/tcp")
    if binding and isinstance(binding, list) and binding:
        try:
            host_port = int(binding[0].get("HostPort", 0)) or None
        except (ValueError, TypeError):
            pass

    labels = data.get("Config", {}).get("Labels", {}) or {}

    return ContainerInfo(
        name=name,
        id=data.get("Id", "")[:12],
        status=status,
        image=image,
        host_port=host_port,
        started_at=started_at,
        labels=labels,
    )


# ---------------------------------------------------------------------------
# Docker info / runtime health
# ---------------------------------------------------------------------------

@dataclass
class DockerInfo:
    """Information about the container runtime installation."""

    version: str
    running: bool
    platform: str


def get_docker_client() -> None:
    """Verify that the container runtime is installed and responsive.

    This no longer returns a Docker SDK client — it simply validates
    availability and is kept for backward compatibility.
    """
    try:
        rt.detect_runtime()
    except FileNotFoundError as e:
        raise RuntimeNotInstalled(str(e)) from e

    try:
        rt.ping()
    except subprocess.CalledProcessError as e:
        error_str = (e.stderr or "").lower()
        if "not found" in error_str or "no such file" in error_str:
            raise RuntimeNotInstalled() from e
        raise RuntimeNotRunning(f"{rt.runtime_name()} error: {e.stderr}") from e
    except FileNotFoundError as e:
        raise RuntimeNotInstalled() from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeNotRunning(f"{rt.runtime_name()} daemon did not respond") from e


def get_docker_info() -> DockerInfo | None:
    """Get runtime installation info, or ``None`` if unavailable."""
    try:
        get_docker_client()
        return DockerInfo(
            version=rt.get_version(),
            running=True,
            platform=rt.get_platform(),
        )
    except (RuntimeNotInstalled, RuntimeNotRunning):
        return None


# ---------------------------------------------------------------------------
# Architecture / port helpers
# ---------------------------------------------------------------------------

def detect_architecture() -> str:
    """Detect the system architecture for container images."""
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "amd64"
    if machine in ("arm64", "aarch64"):
        return "arm64"
    return "amd64"


def find_free_port(preferred: int = 8089) -> int:
    """Find a free port, trying *preferred* first."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", preferred))
            return preferred
        except OSError:
            pass

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def get_image_tag(edition: str, version: str, arch: str | None = None) -> str:
    """Get the full image tag for the given edition and version."""
    if arch is None:
        arch = detect_architecture()
    registry = REGISTRIES.get(edition)
    if not registry:
        raise ValueError(f"Unknown edition: {edition}. Must be 'community' or 'member'.")
    return f"{registry}/{IMAGE_NAME}:{version}-{arch}"


# ---------------------------------------------------------------------------
# Registry / auth helpers
# ---------------------------------------------------------------------------

_MANIFEST_ENV = {"DOCKER_CLI_EXPERIMENTAL": "enabled"}


def is_logged_in(edition: str) -> bool:
    """Check if the user is logged into the registry for the given edition.

    Tries ``<runtime> login --get-login`` first (works on Podman and
    Docker with credential helpers that support it).  Falls back to
    reading auth config files directly for Docker, which does not
    support ``--get-login`` natively.
    """
    registry = REGISTRIES.get(edition)
    if not registry:
        return False

    registry_host = registry.split("/")[0]

    # Try --get-login (Podman, and Docker with some credential helpers).
    # Podman stores auth under the exact path used during login, Docker
    # under the host — so try both.
    for candidate in (registry, registry_host):
        try:
            result = rt.run("login", "--get-login", candidate,
                             check=False, timeout=10)
            if result.returncode == 0 and result.stdout.strip():
                return True
        except Exception:
            pass

    # Fallback: read auth config files directly (needed for Docker
    # which does not support --get-login).
    for config_path in rt.get_auth_config_paths():
        if not config_path.exists():
            continue
        try:
            with open(config_path) as f:
                config = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue

        if _auth_config_contains(config, registry, registry_host):
            return True

    return False


def _auth_config_contains(
    config: dict, registry: str, registry_host: str,
) -> bool:
    """Return True if ``config`` has credentials for ``registry``.

    A registry counts as present when:

    * ``auths[key]`` has an ``auth`` or ``identitytoken`` value, or
    * ``auths`` has an entry for ``key`` and the file declares a
      ``credsStore`` (helper keeps the actual secret), or
    * ``key`` appears in ``credHelpers`` (host or full registry path).

    ``credsStore`` alone (no matching ``auths`` entry) is not enough —
    it only says "some creds live in the helper", not that any exist
    for this registry.
    """
    auths = config.get("auths", {}) or {}
    creds_store = config.get("credsStore")
    candidate_keys = (
        registry_host,
        f"https://{registry_host}",
        registry,
        f"https://{registry}",
    )
    for key in candidate_keys:
        if key not in auths:
            continue
        entry = auths.get(key) or {}
        if entry.get("auth") or entry.get("identitytoken"):
            return True
        if creds_store:
            return True

    cred_helpers = config.get("credHelpers", {}) or {}
    if any(key in cred_helpers for key in candidate_keys):
        return True

    return False


def ensure_logged_in(edition: str) -> None:
    """Raise :class:`RegistryNotLoggedIn` if the user lacks credentials."""
    if not is_logged_in(edition):
        registry = REGISTRIES.get(edition, "unknown")
        raise RegistryNotLoggedIn(registry, edition)


# ---------------------------------------------------------------------------
# Image operations
# ---------------------------------------------------------------------------

def pull_image(
    edition: str,
    version: str = "latest",
    arch: str | None = None,
    progress_callback: Callable[[dict], None] | None = None,
) -> str:
    """Pull the MapViewer image, returning the full image tag."""
    get_docker_client()
    ensure_logged_in(edition)

    image_tag = get_image_tag(edition, version, arch)

    try:
        # merge_stderr: Podman writes pull progress to stderr
        proc = rt.stream("pull", image_tag, merge_stderr=True)
        # Use readline() instead of iterating proc.stdout to avoid
        # Python's internal block buffering which delays output.
        while True:
            line = proc.stdout.readline()
            if not line and proc.poll() is not None:
                break
            line = line.rstrip("\n\r")
            if not line:
                continue
            if progress_callback:
                progress_callback({"status": line})
        proc.wait()
        if proc.returncode != 0:
            raise ImagePullFailed(image_tag, "Pull failed (see logs above)")
        return image_tag
    except ImagePullFailed:
        raise
    except Exception as e:
        error_str = str(e).lower()
        if "unauthorized" in error_str or "authentication required" in error_str:
            registry = REGISTRIES.get(edition, "unknown")
            raise RegistryNotLoggedIn(registry, edition) from e
        if "not found" in error_str:
            raise ImagePullFailed(image_tag, "Image not found in registry") from e
        raise ImagePullFailed(image_tag, str(e)) from e


def image_exists(edition: str, version: str = "latest", arch: str | None = None) -> bool:
    """Check if the MapViewer image exists locally."""
    try:
        get_docker_client()
        image_tag = get_image_tag(edition, version, arch)
        result = rt.run("image", "inspect", image_tag, check=False, timeout=10)
        return result.returncode == 0
    except Exception:
        return False


def _parse_image_entry(img: dict) -> tuple[str, float]:
    """Extract (tag, size_mb) from Docker or Podman image JSON.

    Docker ``images --format json`` produces keys like
    ``Tag``, ``Repository``, ``Size`` (human-readable string).

    Podman ``images --format json`` produces keys like
    ``names`` (list of full refs), ``size`` (int bytes).
    """
    # Docker format: {"Repository": "...", "Tag": "latest-arm64", "Size": "1.2GB"}
    tag_str = img.get("Tag", "")

    if not tag_str:
        # Podman format: {"names": ["registry/image:tag"], "size": 123456}
        names = img.get("names") or img.get("Names") or []
        if names:
            # names is a list of full references like "registry/image:tag"
            ref = names[0] if isinstance(names, list) else names
            if ":" in ref:
                tag_str = ref.rsplit(":", 1)[-1]

    size = img.get("Size") or img.get("size") or 0
    if isinstance(size, str):
        size_mb = round(rt.parse_size_string(size) / (1024 * 1024), 1)
    else:
        size_mb = round(size / (1024 * 1024), 1)

    return tag_str, size_mb


def list_local_image_versions(edition: str | None = None) -> list[dict]:
    """List locally available nds-mapviewer images.

    Returns list of dicts with keys: edition, version, tag, size_mb.
    """
    try:
        get_docker_client()
    except (RuntimeNotInstalled, RuntimeNotRunning):
        return []

    editions = [edition] if edition else list(REGISTRIES)
    results: list[dict] = []

    for ed in editions:
        registry = REGISTRIES.get(ed)
        if not registry:
            continue
        repo = f"{registry}/{IMAGE_NAME}"
        try:
            raw = rt.run(
                "images", "--format", "json",
                "--filter", f"reference={repo}",
                timeout=10,
            )
            # Docker outputs newline-delimited JSON objects,
            # Podman outputs a single JSON array
            stdout = raw.stdout.strip()
            if not stdout:
                continue
            if stdout.startswith("["):
                data = json.loads(stdout)
            else:
                data = [json.loads(line) for line in stdout.splitlines() if line.strip()]
        except Exception:
            continue

        for img in data:
            tag_str, size_mb = _parse_image_entry(img)
            if not tag_str or tag_str == "<none>":
                continue
            version_str = re.sub(r"-(amd64|arm64)$", "", tag_str)
            results.append({
                "edition": ed,
                "version": version_str,
                "tag": tag_str,
                "size_mb": size_mb,
            })

    return results


# ---------------------------------------------------------------------------
# Update checking
# ---------------------------------------------------------------------------

@dataclass
class UpdateStatus:
    """Result of an update check for a single edition."""

    edition: str
    version: str
    arch: str
    local_digest: str | None
    remote_digest: str | None
    update_available: bool
    error: str | None = None


def list_installed_editions() -> list[str]:
    """Return editions that have at least one local image."""
    try:
        get_docker_client()
    except (RuntimeNotInstalled, RuntimeNotRunning):
        return []
    editions = []
    for edition in REGISTRIES:
        tag = get_image_tag(edition, "latest")
        result = rt.run("image", "inspect", tag, check=False, timeout=10)
        if result.returncode == 0:
            editions.append(edition)
    return editions


def get_local_digest(
    edition: str, version: str = "latest", arch: str | None = None,
) -> str | None:
    """Get the registry digest of a locally installed image."""
    try:
        get_docker_client()
        image_tag = get_image_tag(edition, version, arch)
        data = rt.run_json("image", "inspect", image_tag, timeout=10)
        if isinstance(data, list) and data:
            data = data[0]
        registry = REGISTRIES[edition]
        for rd in data.get("RepoDigests", []):
            if registry in rd:
                return rd.split("@")[-1]
        return None
    except Exception:
        return None


def get_remote_digest(
    edition: str, version: str = "latest", arch: str | None = None,
) -> str | None:
    """Query the remote manifest digest.

    Uses ``<runtime> manifest inspect`` which handles auth and proxy
    configuration through the daemon.
    """
    get_docker_client()
    ensure_logged_in(edition)
    image_tag = get_image_tag(edition, version, arch)
    try:
        result = rt.run("manifest", "inspect", image_tag, timeout=15,
                         extra_env=_MANIFEST_ENV)
        # Parse manifest JSON to extract digest
        try:
            manifest = json.loads(result.stdout)
            # Multi-arch manifest lists have a 'manifests' key
            if "manifests" in manifest:
                for m in manifest["manifests"]:
                    return m.get("digest")
            # Single manifest — use the config digest
            config_digest = manifest.get("config", {}).get("digest")
            if config_digest:
                return config_digest
        except json.JSONDecodeError:
            pass
        # Fallback: check if the command printed a digest header
        for line in result.stderr.splitlines():
            if "Digest:" in line:
                return line.split("Digest:")[-1].strip()
        return None
    except subprocess.CalledProcessError as e:
        error_str = (e.stderr or "").lower()
        if "unauthorized" in error_str or "authentication required" in error_str:
            registry = REGISTRIES.get(edition, "unknown")
            raise RegistryNotLoggedIn(registry, edition) from e
        registry = REGISTRIES.get(edition, "unknown")
        raise RegistryQueryFailed(registry, (e.stderr or "").strip()) from e


def check_for_update(
    edition: str, version: str = "latest", arch: str | None = None,
) -> UpdateStatus:
    """Check if an update is available by comparing local and remote digests."""
    if arch is None:
        arch = detect_architecture()
    local_digest = get_local_digest(edition, version, arch)

    try:
        remote_digest = get_remote_digest(edition, version, arch)
    except (RegistryNotLoggedIn, RegistryQueryFailed) as e:
        return UpdateStatus(
            edition=edition, version=version, arch=arch,
            local_digest=local_digest, remote_digest=None,
            update_available=False, error=str(e),
        )

    update_available = (
        local_digest is not None
        and remote_digest is not None
        and local_digest != remote_digest
    )
    return UpdateStatus(
        edition=edition, version=version, arch=arch,
        local_digest=local_digest, remote_digest=remote_digest,
        update_available=update_available,
    )


# ---------------------------------------------------------------------------
# Image version parsing
# ---------------------------------------------------------------------------

def parse_image_version(raw: str | None) -> tuple[str, str]:
    """Parse ``--version`` output from the container image.

    Args:
        raw: Output like ``"NDS MapViewer version 2025.6.2, Commit ID: abc123f"``

    Returns:
        ``(version, commit)`` tuple.  Falls back to ``("unknown", "unknown")``.
    """
    if not raw:
        return "unknown", "unknown"
    m = re.search(r"version\s+([\w.]+)", raw, re.IGNORECASE)
    version = m.group(1) if m else "unknown"
    m = re.search(r"Commit\s+ID:\s*(\S+)", raw, re.IGNORECASE)
    commit = m.group(1)[:7] if m else "unknown"
    return version, commit


def get_image_version(name: str = CONTAINER_NAME) -> str | None:
    """Get the MapViewer version from a running container via exec."""
    info = get_container(name)
    if info is None or info.status != "running":
        return None
    try:
        result = rt.run("exec", name, "/entrypoint.bash", "--version", timeout=10)
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Container operations
# ---------------------------------------------------------------------------

def get_container(name: str = CONTAINER_NAME) -> ContainerInfo | None:
    """Get the MapViewer container if it exists."""
    try:
        get_docker_client()
        data = rt.run_json("container", "inspect", name, timeout=10)
        if isinstance(data, list) and data:
            data = data[0]
        return _container_from_inspect(data)
    except Exception:
        return None


def get_container_status(name: str = CONTAINER_NAME) -> str:
    """Get the status of the MapViewer container."""
    info = get_container(name)
    if info is None:
        return "not_found"
    return info.status


def list_containers() -> list[ContainerInfo]:
    """List all MapViewer containers (running or stopped)."""
    try:
        get_docker_client()

        result = rt.run(
            "container", "ls", "-a",
            "--filter", f"label={CONTAINER_LABEL}",
            "--format", "{{.Names}}",
            timeout=10,
        )
        names = [n.strip() for n in result.stdout.strip().splitlines() if n.strip()]

        # Backward compat: also check default-named container without label
        if CONTAINER_NAME not in names:
            check = rt.run(
                "container", "inspect", CONTAINER_NAME,
                check=False, timeout=10,
            )
            if check.returncode == 0:
                names.append(CONTAINER_NAME)

        containers = []
        for name in names:
            info = get_container(name)
            if info is not None:
                containers.append(info)
        return containers
    except (RuntimeNotInstalled, RuntimeNotRunning):
        return []


def run_container(
    image_tag: str,
    port: int = 8089,
    bind_address: str = "127.0.0.1",
    config_dir: str | Path | None = None,
    volumes: list[str] | None = None,
    environment: dict[str, str] | None = None,
    name: str = CONTAINER_NAME,
    detach: bool = True,
    remove_existing: bool = False,
) -> ContainerInfo:
    """Run the MapViewer container.

    Args:
        image_tag: Image tag to run.
        port: Host port to bind.
        bind_address: Host address to bind (default ``"127.0.0.1"``).
        config_dir: Config directory to mount at ``/config``.
        volumes: Additional volume mounts as ``"host:container:mode"`` strings.
        environment: Environment variables.
        name: Container name.
        detach: Run in detached mode.
        remove_existing: Remove existing container if running.
    """
    get_docker_client()

    # Check for existing container
    existing = get_container(name)
    if existing:
        if existing.status == "running":
            if not remove_existing:
                raise ContainerAlreadyRunning(name, port)
            rt.run("stop", "-t", "2", name, timeout=30)
        rt.run("rm", name, check=False, timeout=10)

    # Build command
    cmd: list[str] = ["run"]
    if detach:
        cmd.append("-d")
    cmd.extend(["--name", name])
    cmd.extend(["-p", f"{bind_address}:{port}:8089"])

    # Volume mounts
    if config_dir:
        config_path = Path(config_dir).resolve()
        cmd.extend(["-v", f"{config_path}:/config:rw"])

    if volumes:
        for vol in volumes:
            cmd.extend(["-v", vol])

    # Environment
    if environment:
        for key, value in environment.items():
            cmd.extend(["-e", f"{key}={value}"])

    # Extra hosts for host.docker.internal on Linux
    cmd.extend(rt.get_extra_host_args())

    # Labels
    cmd.extend(["--label", "app=ndslive-mapviewer"])

    cmd.append(image_tag)

    rt.run(*cmd, timeout=60)

    info = get_container(name)
    if info is None:
        raise RuntimeError(f"Container '{name}' not found after creation")
    return info


def stop_container(name: str = CONTAINER_NAME, remove: bool = True) -> bool:
    """Stop the MapViewer container."""
    info = get_container(name)
    if info is None:
        raise ContainerNotFound(name)

    if info.status == "running":
        rt.run("stop", "-t", "2", name, timeout=30)

    if remove:
        rt.run("rm", name, check=False, timeout=10)

    return True


def get_container_logs(
    name: str = CONTAINER_NAME,
    follow: bool = False,
    tail: int | str = "all",
) -> Iterator[str] | str:
    """Get logs from the MapViewer container."""
    info = get_container(name)
    if info is None:
        raise ContainerNotFound(name)

    if follow:
        return ContainerLogStream(rt.stream("logs", "--follow", name, merge_stderr=True))
    else:
        cmd = ["logs"]
        if tail != "all":
            cmd.extend(["--tail", str(tail)])
        cmd.append(name)
        result = rt.run(*cmd, check=False, timeout=30)
        # Container logs may appear on stdout, stderr, or both
        logs = result.stdout
        if result.stderr:
            if logs:
                logs += result.stderr
            else:
                logs = result.stderr
        return logs


class ContainerLogStream:
    """Iterable log stream that can be closed from outside the iterator.

    The underlying ``<runtime> logs --follow`` subprocess blocks in
    ``proc.stdout`` until the container exits. Docker closes the pipe
    promptly on ``stop``; Podman can keep the follower alive longer, so we
    expose :meth:`close` to terminate it deterministically on shutdown.
    """

    def __init__(self, proc: subprocess.Popen[str]) -> None:
        self._proc = proc

    def __iter__(self) -> Iterator[str]:
        try:
            for line in self._proc.stdout:
                yield line
        finally:
            self.close()

    def close(self, timeout: float = 3.0) -> None:
        if self._proc.poll() is not None:
            return
        self._proc.terminate()
        try:
            self._proc.wait(timeout=timeout)
            return
        except subprocess.TimeoutExpired:
            pass
        self._proc.kill()
        try:
            self._proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            pass


_READY_SENTINEL = "NDS MapViewer is ready!"


def wait_for_container_ready(
    name: str = CONTAINER_NAME,
    timeout: int = 60,
    port: int = 8089,
    log_callback: Callable[[str], None] | None = None,
) -> bool:
    """Wait for the MapViewer container to be ready.

    Two-phase readiness check:

    Phase 1 — Watch container logs for the sentinel string.
    Phase 2 — Verify the HTTP layer responds with ``/status``.
    """
    import time
    from urllib.error import URLError
    from urllib.request import urlopen

    start_time = time.time()
    last_log_line = ""
    sentinel_seen = False

    # Phase 1: wait for sentinel in logs
    while time.time() - start_time < timeout:
        info = get_container(name)
        if info is None or info.status != "running":
            time.sleep(0.5)
            continue

        try:
            result = rt.run("logs", "--tail", "50", name, check=False, timeout=5)
            logs = result.stdout + (result.stderr or "")

            if _READY_SENTINEL in logs:
                sentinel_seen = True
                break

            if log_callback:
                lines = [ln.strip() for ln in logs.splitlines() if ln.strip()]
                if lines and lines[-1] != last_log_line:
                    last_log_line = lines[-1]
                    log_callback(last_log_line)
        except Exception:
            pass

        time.sleep(0.5)

    if not sentinel_seen:
        return False

    # Phase 2: verify HTTP layer
    health_deadline = time.time() + 5
    while time.time() < health_deadline:
        try:
            response = urlopen(f"http://127.0.0.1:{port}/status", timeout=2)
            if response.status == 200:
                return True
        except (URLError, OSError):
            pass
        time.sleep(0.5)

    # Sentinel was seen but /status didn't respond — proceed anyway
    return True


# ---------------------------------------------------------------------------
# Container stats
# ---------------------------------------------------------------------------

@dataclass
class ContainerStats:
    """Snapshot of container resource usage."""

    cpu_percent: float
    memory_mb: float
    memory_limit_mb: float
    net_rx_mb: float
    net_tx_mb: float


def get_container_stats(name: str = CONTAINER_NAME) -> Iterator[ContainerStats]:
    """Stream container resource stats (~1 sample / second).

    Uses ``<runtime> stats --format json --no-stream`` in a poll loop
    because the JSON streaming format varies between Docker and Podman.
    """
    import time

    info = get_container(name)
    if info is None:
        return

    try:
        while True:
            info = get_container(name)
            if info is None or info.status != "running":
                return

            result = rt.run(
                "stats", "--no-stream", "--format",
                '{"CPUPerc":"{{.CPUPerc}}","MemUsage":"{{.MemUsage}}","NetIO":"{{.NetIO}}"}',
                name,
                check=False, timeout=10,
            )
            if result.returncode != 0:
                return

            for line in result.stdout.strip().splitlines():
                if not line.strip():
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # CPU
                cpu_str = raw.get("CPUPerc", "0%").rstrip("%")
                try:
                    cpu_percent = float(cpu_str)
                except ValueError:
                    cpu_percent = 0.0

                # Memory: "256MiB / 2GiB"
                mem_parts = raw.get("MemUsage", "0 / 0").split("/")
                memory_bytes = rt.parse_size_string(mem_parts[0].strip()) if mem_parts else 0.0
                memory_limit_bytes = rt.parse_size_string(mem_parts[1].strip()) if len(mem_parts) > 1 else 0.0

                # Network: "1.2kB / 3.4kB"
                net_parts = raw.get("NetIO", "0 / 0").split("/")
                net_rx_bytes = rt.parse_size_string(net_parts[0].strip()) if net_parts else 0.0
                net_tx_bytes = rt.parse_size_string(net_parts[1].strip()) if len(net_parts) > 1 else 0.0

                yield ContainerStats(
                    cpu_percent=round(cpu_percent, 1),
                    memory_mb=round(memory_bytes / (1024 * 1024), 1),
                    memory_limit_mb=round(memory_limit_bytes / (1024 * 1024), 1),
                    net_rx_mb=round(net_rx_bytes / (1024 * 1024), 2),
                    net_tx_mb=round(net_tx_bytes / (1024 * 1024), 2),
                )

            time.sleep(1)
    except Exception:
        return
