"""Shared pytest fixtures and container-runtime availability check."""

import shutil
import tempfile
from pathlib import Path

import pytest
import yaml


# Default edition for tests
DEFAULT_EDITION = "member"


@pytest.fixture(scope="session")
def docker_client():
    """Verify the container runtime is available, skipping tests otherwise.

    Returns ``None`` — the fixture is kept for backward compatibility with
    tests that declare it as a dependency to gate on runtime availability.
    """
    from ndslive.mapviewer import docker_client as dc
    from ndslive.mapviewer.exceptions import RuntimeNotInstalled, RuntimeNotRunning

    try:
        dc.get_docker_client()
        return None  # runtime OK
    except RuntimeNotInstalled:
        pytest.skip("No container runtime installed (Docker/Podman)")
    except RuntimeNotRunning:
        pytest.skip("Container runtime is not running")


@pytest.fixture(scope="session")
def edition():
    """Default edition for tests."""
    return DEFAULT_EDITION


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    path = Path(tempfile.mkdtemp(prefix="mapviewer-test-"))
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture
def sample_config(temp_dir):
    """Create a sample config file with HTTP-only sources (no local paths)."""
    config = {
        "http-settings": [
            {
                "scope": "https://api.nds.live/*",
                "api-key": "test-key",
            }
        ],
        "sources": [
            {
                "type": "SmartLayerTileService",
                "uri": "https://api.nds.live/island6/openapi.json",
                "mapId": "Test Island",
            }
        ],
    }
    config_path = temp_dir / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f)
    return config_path


@pytest.fixture
def sample_config_with_local_path(temp_dir):
    """Create a sample config with a local path that needs volume mounting."""
    data_dir = temp_dir / "data" / "maps"
    data_dir.mkdir(parents=True)
    (data_dir / "dummy.db").touch()

    config = {
        "sources": [
            {
                "type": "ClassicFolder",
                "folder": str(data_dir),
                "mapId": "Local Data",
            }
        ],
    }
    config_path = temp_dir / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f)
    return config_path, data_dir


@pytest.fixture
def sample_config_filestore(temp_dir):
    """Create a sample config with filestore: URI."""
    data_dir = temp_dir / "filestore"
    data_dir.mkdir(parents=True)
    (data_dir / "test.nds").touch()

    config = {
        "sources": [
            {
                "type": "SmartLayerTileService",
                "uri": f"filestore:{data_dir}",
                "mapId": "Filestore Test",
            }
        ],
    }
    config_path = temp_dir / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f)
    return config_path, data_dir


@pytest.fixture
def container_name():
    """Generate a unique container name for test isolation."""
    import uuid
    return f"mapviewer-test-{uuid.uuid4().hex[:8]}"


@pytest.fixture
def cleanup_container(docker_client, container_name):
    """Ensure test container is cleaned up after test."""
    from ndslive.mapviewer import container_runtime as rt
    yield container_name
    try:
        rt.run("stop", container_name, check=False, timeout=10)
        rt.run("rm", container_name, check=False, timeout=10)
    except Exception:
        pass


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers", "docker: mark test as requiring Docker"
    )
    config.addinivalue_line(
        "markers", "slow: mark test as slow-running"
    )
