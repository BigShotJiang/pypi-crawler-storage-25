"""Tests for container runtime operations (requires Docker or Podman)."""

import json
import os
import subprocess

import pytest

from ndslive.mapviewer import docker_client as dc
from ndslive.mapviewer import container_runtime as rt
from ndslive.mapviewer.exceptions import ContainerNotFound, ImagePullFailed


@pytest.mark.order(1)
class TestRuntimeAvailability:
    """Container runtime availability check — runs first."""

    def test_runtime_is_available(self, docker_client):
        """A container runtime must be installed and running."""
        assert rt.is_running()


class TestGetDockerClient:
    """Tests for get_docker_client() compatibility shim."""

    def test_does_not_raise(self, docker_client):
        """get_docker_client succeeds when runtime is available."""
        dc.get_docker_client()  # should not raise

    def test_runtime_detected(self, docker_client):
        """A runtime is detected (docker or podman)."""
        runtime = rt.detect_runtime()
        assert runtime in ("docker", "podman")


class TestGetDockerInfo:
    """Tests for get_docker_info()."""

    def test_returns_docker_info(self):
        """get_docker_info returns DockerInfo dataclass."""
        info = dc.get_docker_info()
        assert info is not None
        assert hasattr(info, "version")
        assert hasattr(info, "running")
        assert hasattr(info, "platform")
        assert info.running is True


class TestDetectArchitecture:
    """Tests for detect_architecture()."""

    def test_returns_valid_arch(self):
        """Returns a valid architecture string."""
        arch = dc.detect_architecture()
        assert arch in ("amd64", "arm64")


class TestFindFreePort:
    """Tests for find_free_port()."""

    def test_returns_integer(self):
        """Returns an integer port number."""
        port = dc.find_free_port()
        assert isinstance(port, int)
        assert 1024 <= port <= 65535

    def test_preferred_port_if_available(self):
        """Uses preferred port if available."""
        import socket

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            free_port = s.getsockname()[1]

        result = dc.find_free_port(preferred=free_port)
        assert result == free_port

    def test_fallback_when_preferred_busy(self):
        """Falls back to another port when preferred is busy."""
        import socket

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            busy_port = s.getsockname()[1]
            s.listen(1)

            result = dc.find_free_port(preferred=busy_port)
            assert result != busy_port
            assert isinstance(result, int)


class TestGetImageTag:
    """Tests for get_image_tag()."""

    def test_community_edition(self):
        """Community edition tag format."""
        tag = dc.get_image_tag("community", "latest", arch="amd64")
        assert "ndslive-dockerreg" in tag
        assert "nds-mapviewer" in tag
        assert "latest-amd64" in tag

    def test_member_edition(self):
        """Member edition tag format."""
        tag = dc.get_image_tag("member", "v2025.6.0", arch="arm64")
        assert "tooling-dockerreg" in tag
        assert "nds-mapviewer" in tag
        assert "v2025.6.0-arm64" in tag

    def test_invalid_edition_raises(self):
        """Invalid edition raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            dc.get_image_tag("invalid", "latest")
        assert "Unknown edition" in str(exc_info.value)


class TestIsLoggedIn:
    """Tests for is_logged_in()."""

    def test_returns_boolean(self):
        """Returns a boolean value."""
        result = dc.is_logged_in("member")
        assert isinstance(result, bool)

    def test_invalid_edition_returns_false(self):
        """Invalid edition returns False."""
        result = dc.is_logged_in("nonexistent")
        assert result is False

    def test_global_creds_store_without_registry_auth_returns_false(self, mocker, temp_dir):
        """A global credsStore alone should not count as registry login."""
        config_path = temp_dir / "config.json"
        config_path.write_text(json.dumps({"credsStore": "desktop"}))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is False

    def test_registry_cred_helper_returns_true(self, mocker, temp_dir):
        """A registry-specific credential helper counts as logged in."""
        config_path = temp_dir / "config.json"
        config_path.write_text(json.dumps({
            "credHelpers": {
                "artifactory.nds-association.org": "desktop",
            },
        }))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is True

    def test_creds_store_with_auths_stub_returns_true(self, mocker, temp_dir):
        """credsStore + an empty auths entry for the registry counts as logged in.

        Docker CLI writes ``auths[host] = {}`` and stores the real secret in
        the configured credential helper. The helper alone isn't proof (could
        hold creds for any registry), but the combination is.
        """
        config_path = temp_dir / "config.json"
        config_path.write_text(json.dumps({
            "auths": {"artifactory.nds-association.org": {}},
            "credsStore": "osxkeychain",
        }))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is True

    def test_creds_store_without_registry_auths_returns_false(self, mocker, temp_dir):
        """credsStore + auths for an unrelated registry does not count."""
        config_path = temp_dir / "config.json"
        config_path.write_text(json.dumps({
            "auths": {"ghcr.io": {}},
            "credsStore": "osxkeychain",
        }))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is False

    def test_namespaced_auth_key_returns_true(self, mocker, temp_dir):
        """Podman stores auth under the full namespaced key."""
        config_path = temp_dir / "auth.json"
        config_path.write_text(json.dumps({
            "auths": {
                "artifactory.nds-association.org/tooling-dockerreg": {
                    "auth": "base64encoded",
                },
            },
        }))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is True

    def test_scheme_prefixed_cred_helper_returns_true(self, mocker, temp_dir):
        """``https://``-prefixed credHelpers keys are recognized."""
        config_path = temp_dir / "config.json"
        config_path.write_text(json.dumps({
            "credHelpers": {
                "https://artifactory.nds-association.org": "desktop",
            },
        }))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is True

    def test_https_prefixed_auths_key_returns_true(self, mocker, temp_dir):
        """auths keys stored with an ``https://`` scheme prefix are recognized."""
        config_path = temp_dir / "config.json"
        config_path.write_text(json.dumps({
            "auths": {
                "https://artifactory.nds-association.org/tooling-dockerreg": {
                    "auth": "base64encoded",
                },
            },
        }))

        mock_result = mocker.MagicMock(returncode=1, stdout="")
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(rt, "get_auth_config_paths", return_value=[config_path])

        assert dc.is_logged_in("member") is True


class TestListContainers:
    """Tests for list_containers()."""

    def test_returns_list(self, docker_client):
        """Returns a list (possibly empty)."""
        result = dc.list_containers()
        assert isinstance(result, list)


class TestGetContainer:
    """Tests for get_container()."""

    def test_nonexistent_returns_none(self, docker_client):
        """Returns None for nonexistent container."""
        result = dc.get_container("nonexistent-container-xyz123")
        assert result is None


class TestGetContainerStatus:
    """Tests for get_container_status()."""

    def test_nonexistent_returns_not_found(self, docker_client):
        """Returns 'not_found' for nonexistent container."""
        status = dc.get_container_status("nonexistent-container-xyz123")
        assert status == "not_found"


class TestGetContainerLogs:
    """Tests for get_container_logs()."""

    def test_nonexistent_raises(self, docker_client):
        """Raises ContainerNotFound for nonexistent container."""
        with pytest.raises(ContainerNotFound):
            dc.get_container_logs("nonexistent-container-xyz123")

    def test_follow_merges_stderr(self, mocker):
        """Regression guard for MAPV-486.

        ``get_container_logs(follow=True)`` must pass ``merge_stderr=True``
        to ``rt.stream`` — otherwise the container's stderr output is
        captured in a Popen pipe that is never read by the iterator and
        the TUI's log pane stays empty.
        """
        info = dc.ContainerInfo(
            name="test", id="abc", status="running", image="x",
        )
        mocker.patch.object(dc, "get_container", return_value=info)
        mock_stream = mocker.patch.object(rt, "stream")

        dc.get_container_logs("test", follow=True)

        assert mock_stream.call_args.kwargs.get("merge_stderr") is True, (
            "get_container_logs(follow=True) must pass merge_stderr=True;"
            " without it the container's stderr disappears in the TUI."
        )

    def test_wait_for_ready_scans_stderr(self, mocker):
        """Regression guard for MAPV-486.

        The readiness sentinel can land on stderr (mapget/spdlog often
        log there). ``wait_for_container_ready`` must scan stdout AND
        stderr or it'll time out even though the container is up.
        """
        info = dc.ContainerInfo(
            name="test", id="abc", status="running", image="x",
        )
        mocker.patch.object(dc, "get_container", return_value=info)

        # Sentinel only on stderr — a strict-stdout scan would miss it.
        result = mocker.MagicMock(stdout="", stderr="NDS MapViewer is ready!\n")
        mocker.patch.object(rt, "run", return_value=result)
        # Make the post-sentinel HTTP probe succeed so the function
        # returns immediately rather than retrying for 5s.
        http_response = mocker.MagicMock(status=200)
        mocker.patch("urllib.request.urlopen", return_value=http_response)

        ready = dc.wait_for_container_ready("test", timeout=2, port=8089)
        assert ready is True, (
            "wait_for_container_ready missed the sentinel because it only"
            " scanned stdout. It must include stderr too."
        )

    @pytest.mark.slow
    def test_follow_real_container_emits_stderr_lines(
        self, docker_client, cleanup_container,
    ):
        """End-to-end regression for MAPV-486.

        Spin up a tiny container that writes a marker to stdout and
        another to stderr, then read both back via the follow stream.
        Pre-fix this would only return the stdout marker.
        """
        import time

        name = cleanup_container
        # alpine pulls on first run (~3MB), instant on subsequent runs.
        rt.run(
            "run", "-d", "--name", name, "alpine:latest",
            "sh", "-c",
            "echo stdout-marker-MAPV486;"
            " echo stderr-marker-MAPV486 1>&2;"
            " sleep 30",
            timeout=120,
        )

        # Give the container a moment to flush its output.
        time.sleep(1)

        stream = dc.get_container_logs(name, follow=True)
        collected: list[str] = []
        try:
            deadline = time.time() + 5
            for line in stream:
                collected.append(line.strip())
                if (
                    any("stderr-marker-MAPV486" in s for s in collected)
                    and any("stdout-marker-MAPV486" in s for s in collected)
                ) or time.time() > deadline:
                    break
        finally:
            if hasattr(stream, "close"):
                stream.close()

        assert any("stdout-marker-MAPV486" in s for s in collected), (
            f"Stdout marker missing from follow stream: {collected}"
        )
        assert any("stderr-marker-MAPV486" in s for s in collected), (
            "Stderr marker missing from follow stream — this is the"
            f" exact regression MAPV-486 fixed. Lines: {collected}"
        )


class TestStopContainer:
    """Tests for stop_container()."""

    def test_nonexistent_raises(self, docker_client):
        """Raises ContainerNotFound for nonexistent container."""
        with pytest.raises(ContainerNotFound):
            dc.stop_container("nonexistent-container-xyz123")


class TestContainerLogStream:
    """Tests for ContainerLogStream.close() teardown behaviour."""

    def test_close_skips_when_already_exited(self, mocker):
        proc = mocker.MagicMock()
        proc.poll.return_value = 0
        stream = dc.ContainerLogStream(proc)

        stream.close()

        proc.terminate.assert_not_called()
        proc.kill.assert_not_called()

    def test_close_terminates_and_waits(self, mocker):
        proc = mocker.MagicMock()
        proc.poll.return_value = None
        proc.wait.return_value = 0
        stream = dc.ContainerLogStream(proc)

        stream.close(timeout=1.5)

        proc.terminate.assert_called_once()
        proc.wait.assert_called_once_with(timeout=1.5)
        proc.kill.assert_not_called()

    def test_close_kills_when_terminate_times_out(self, mocker):
        proc = mocker.MagicMock()
        proc.poll.return_value = None
        proc.wait.side_effect = [
            subprocess.TimeoutExpired(cmd="logs", timeout=1.0),
            0,
        ]
        stream = dc.ContainerLogStream(proc)

        stream.close(timeout=1.0)

        proc.terminate.assert_called_once()
        proc.kill.assert_called_once()
        assert proc.wait.call_count == 2

    def test_close_returns_even_if_kill_wait_times_out(self, mocker):
        proc = mocker.MagicMock()
        proc.poll.return_value = None
        proc.wait.side_effect = subprocess.TimeoutExpired(cmd="logs", timeout=1.0)
        stream = dc.ContainerLogStream(proc)

        stream.close(timeout=1.0)

        proc.terminate.assert_called_once()
        proc.kill.assert_called_once()


class TestPullImageErrorHandling:
    """Tests for pull_image() error handling."""

    def test_pull_failure_raises(self, docker_client, mocker):
        """Non-zero exit from pull raises ImagePullFailed."""
        import io
        mocker.patch.object(dc, "is_logged_in", return_value=True)

        mock_proc = mocker.MagicMock()
        mock_proc.stdout = io.StringIO("Pulling image...\nerror: no space left\n")
        mock_proc.poll = mocker.MagicMock(return_value=1)
        mock_proc.wait.return_value = None
        mock_proc.returncode = 1
        mocker.patch.object(rt, "stream", return_value=mock_proc)

        with pytest.raises(ImagePullFailed, match="Pull failed"):
            dc.pull_image("community", "latest", arch="arm64")


class TestListInstalledEditions:
    """Tests for list_installed_editions()."""

    def test_returns_list(self, docker_client):
        """Returns a list of edition strings."""
        result = dc.list_installed_editions()
        assert isinstance(result, list)
        for edition in result:
            assert edition in ("community", "member")


class TestGetLocalDigest:
    """Tests for get_local_digest()."""

    def test_nonexistent_returns_none(self, docker_client):
        """Returns None when image does not exist locally."""
        result = dc.get_local_digest("community", "nonexistent-version-xyz")
        assert result is None


class TestGetRemoteDigest:
    """Tests for get_remote_digest()."""

    def test_with_mocked_manifest(self, docker_client, mocker):
        """Returns digest from manifest inspect response."""
        mock_result = mocker.MagicMock()
        mock_result.stdout = '{"manifests":[{"digest":"sha256:abc123"}]}'
        mock_result.stderr = ""
        mocker.patch.object(rt, "run", return_value=mock_result)
        mocker.patch.object(dc, "is_logged_in", return_value=True)

        result = dc.get_remote_digest("community", "latest", "arm64")
        assert result == "sha256:abc123"

    def test_not_logged_in_raises(self, docker_client, mocker):
        """Raises RegistryNotLoggedIn when not logged in."""
        mocker.patch.object(dc, "is_logged_in", return_value=False)
        from ndslive.mapviewer.exceptions import RegistryNotLoggedIn
        with pytest.raises(RegistryNotLoggedIn):
            dc.get_remote_digest("community", "latest", "arm64")


class TestCheckForUpdate:
    """Tests for check_for_update()."""

    def test_same_digest_no_update(self, docker_client, mocker):
        """Same local and remote digest means no update."""
        mocker.patch.object(dc, "get_local_digest", return_value="sha256:abc")
        mocker.patch.object(dc, "get_remote_digest", return_value="sha256:abc")

        status = dc.check_for_update("community", "latest", "arm64")
        assert status.update_available is False
        assert status.error is None

    def test_different_digest_update_available(self, docker_client, mocker):
        """Different digests means update available."""
        mocker.patch.object(dc, "get_local_digest", return_value="sha256:old")
        mocker.patch.object(dc, "get_remote_digest", return_value="sha256:new")

        status = dc.check_for_update("community", "latest", "arm64")
        assert status.update_available is True
        assert status.error is None

    def test_remote_failure_captured(self, docker_client, mocker):
        """Remote digest failure is captured in error field."""
        from ndslive.mapviewer.exceptions import RegistryQueryFailed
        mocker.patch.object(dc, "get_local_digest", return_value="sha256:abc")
        mocker.patch.object(
            dc, "get_remote_digest",
            side_effect=RegistryQueryFailed("test-registry", "connection refused"),
        )

        status = dc.check_for_update("community", "latest", "arm64")
        assert status.update_available is False
        assert status.error is not None


class TestContainerRuntime:
    """Tests for container_runtime module."""

    def test_detect_runtime(self):
        """detect_runtime returns docker or podman."""
        runtime = rt.detect_runtime()
        assert runtime in ("docker", "podman")

    def test_detect_runtime_prefers_working_runtime(self, tmp_path, mocker, monkeypatch):
        """Auto-detection should skip an installed but unhealthy runtime."""
        rt.detect_runtime.cache_clear()
        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        mocker.patch.dict(os.environ, {"CONTAINER_RUNTIME": ""}, clear=False)
        mocker.patch.object(rt.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}")

        def fake_run(cmd, **kwargs):
            runtime = cmd[0]
            return subprocess.CompletedProcess(
                cmd,
                1 if runtime == "docker" else 0,
                "",
                "down" if runtime == "docker" else "",
            )

        mocker.patch.object(rt.subprocess, "run", side_effect=fake_run)
        try:
            assert rt.detect_runtime() == "podman"
        finally:
            rt.detect_runtime.cache_clear()

    def test_detect_runtime_explicit_env_forces_choice(self, tmp_path, mocker, monkeypatch):
        """CONTAINER_RUNTIME should force the selected runtime."""
        rt.detect_runtime.cache_clear()
        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        mocker.patch.dict(os.environ, {"CONTAINER_RUNTIME": "docker"}, clear=False)
        mocker.patch.object(rt.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}")
        mocker.patch.object(rt.subprocess, "run", side_effect=AssertionError("should not probe"))
        try:
            assert rt.detect_runtime() == "docker"
        finally:
            rt.detect_runtime.cache_clear()

    def test_detect_runtime_returns_first_installed_if_none_respond(
        self, tmp_path, mocker, monkeypatch,
    ):
        """When no runtime is responsive, keep the first installed for later errors."""
        rt.detect_runtime.cache_clear()
        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        mocker.patch.dict(os.environ, {"CONTAINER_RUNTIME": ""}, clear=False)
        mocker.patch.object(rt.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}")
        mocker.patch.object(
            rt.subprocess,
            "run",
            return_value=subprocess.CompletedProcess(["docker", "info"], 1, "", "down"),
        )
        try:
            assert rt.detect_runtime() == "docker"
        finally:
            rt.detect_runtime.cache_clear()

    def test_runtime_name(self):
        """runtime_name returns capitalised name."""
        name = rt.runtime_name()
        assert name in ("Docker", "Podman")

    def test_is_available(self):
        """is_available returns True when a runtime exists."""
        assert rt.is_available() is True

    def test_get_auth_config_paths(self):
        """Auth config paths are returned as list of Path objects."""
        paths = rt.get_auth_config_paths()
        assert isinstance(paths, list)
        assert all(isinstance(p, type(paths[0])) for p in paths)

    def test_detect_runtime_honours_setup_json(self, tmp_path, mocker, monkeypatch):
        """A runtime_name in ~/.nds/setup.json wins over env/autodetect."""
        rt.detect_runtime.cache_clear()
        setup_dir = tmp_path / ".nds"
        setup_dir.mkdir()
        (setup_dir / "setup.json").write_text(json.dumps({"runtime_name": "podman"}))

        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        monkeypatch.setenv("CONTAINER_RUNTIME", "docker")
        mocker.patch.object(rt.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}")
        mocker.patch.object(
            rt.subprocess,
            "run",
            side_effect=AssertionError("should not probe when saved pref wins"),
        )
        try:
            assert rt.detect_runtime() == "podman"
        finally:
            rt.detect_runtime.cache_clear()

    def test_detect_runtime_falls_back_when_saved_missing(
        self, tmp_path, mocker, monkeypatch,
    ):
        """If the saved runtime isn't on PATH, fall back to env/autodetect."""
        rt.detect_runtime.cache_clear()
        setup_dir = tmp_path / ".nds"
        setup_dir.mkdir()
        (setup_dir / "setup.json").write_text(json.dumps({"runtime_name": "podman"}))

        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        monkeypatch.delenv("CONTAINER_RUNTIME", raising=False)
        mocker.patch.object(
            rt.shutil,
            "which",
            side_effect=lambda name: "/usr/bin/docker" if name == "docker" else None,
        )
        mocker.patch.object(
            rt.subprocess,
            "run",
            return_value=subprocess.CompletedProcess(["docker", "info"], 0, "", ""),
        )
        try:
            assert rt.detect_runtime() == "docker"
        finally:
            rt.detect_runtime.cache_clear()

    def test_detect_runtime_ignores_malformed_setup_json(
        self, tmp_path, mocker, monkeypatch,
    ):
        """Garbled ~/.nds/setup.json must not break detection."""
        rt.detect_runtime.cache_clear()
        setup_dir = tmp_path / ".nds"
        setup_dir.mkdir()
        (setup_dir / "setup.json").write_text("{ not valid json")

        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        monkeypatch.delenv("CONTAINER_RUNTIME", raising=False)
        mocker.patch.object(
            rt.shutil,
            "which",
            side_effect=lambda name: "/usr/bin/docker" if name == "docker" else None,
        )
        mocker.patch.object(
            rt.subprocess,
            "run",
            return_value=subprocess.CompletedProcess(["docker", "info"], 0, "", ""),
        )
        try:
            assert rt.detect_runtime() == "docker"
        finally:
            rt.detect_runtime.cache_clear()

    def test_detect_runtime_ignores_unknown_runtime_name(
        self, tmp_path, mocker, monkeypatch,
    ):
        """An unrecognised runtime_name in setup.json is ignored, not rejected."""
        rt.detect_runtime.cache_clear()
        setup_dir = tmp_path / ".nds"
        setup_dir.mkdir()
        (setup_dir / "setup.json").write_text(json.dumps({"runtime_name": "rkt"}))

        monkeypatch.setattr(rt.Path, "home", lambda: tmp_path)
        monkeypatch.delenv("CONTAINER_RUNTIME", raising=False)
        mocker.patch.object(
            rt.shutil,
            "which",
            side_effect=lambda name: "/usr/bin/docker" if name == "docker" else None,
        )
        mocker.patch.object(
            rt.subprocess,
            "run",
            return_value=subprocess.CompletedProcess(["docker", "info"], 0, "", ""),
        )
        try:
            assert rt.detect_runtime() == "docker"
        finally:
            rt.detect_runtime.cache_clear()

    def test_podman_auth_paths_exclude_docker_config(self, monkeypatch):
        """Podman should not consider ~/.docker/config.json as a login source.

        On macOS, Docker Desktop's credsStore runs on the host and podman
        cannot invoke it — so a docker login must not imply a podman login.
        """
        rt.detect_runtime.cache_clear()
        monkeypatch.setenv("CONTAINER_RUNTIME", "podman")
        monkeypatch.delenv("XDG_RUNTIME_DIR", raising=False)
        monkeypatch.delenv("APPDATA", raising=False)
        # shutil.which needs to find podman for detect_runtime to accept env.
        import shutil as _sh
        monkeypatch.setattr(
            rt.shutil, "which",
            lambda name: "/usr/bin/podman" if name == "podman" else None,
        )
        try:
            paths = rt.get_auth_config_paths()
            docker_config = rt.Path.home() / ".docker" / "config.json"
            assert docker_config not in paths
        finally:
            rt.detect_runtime.cache_clear()

    def test_podman_auth_paths_include_appdata_on_windows(self, tmp_path, monkeypatch):
        """When APPDATA is set (Windows), podman auth.json under it is probed."""
        rt.detect_runtime.cache_clear()
        monkeypatch.setenv("CONTAINER_RUNTIME", "podman")
        monkeypatch.setenv("APPDATA", str(tmp_path / "AppData" / "Roaming"))
        monkeypatch.delenv("XDG_RUNTIME_DIR", raising=False)
        monkeypatch.setattr(
            rt.shutil, "which",
            lambda name: "/usr/bin/podman" if name == "podman" else None,
        )
        try:
            paths = rt.get_auth_config_paths()
            expected = rt.Path(str(tmp_path / "AppData" / "Roaming")) / "containers" / "auth.json"
            assert expected in paths
        finally:
            rt.detect_runtime.cache_clear()

    def test_parse_size_string(self):
        """Parse common size format strings."""
        assert rt.parse_size_string("256MiB") == 256 * 1024 * 1024
        assert rt.parse_size_string("1.5GiB") == 1.5 * 1024 * 1024 * 1024
        assert rt.parse_size_string("100kB") == 100_000
        assert rt.parse_size_string("0B") == 0.0


class TestContainerInfo:
    """Tests for ContainerInfo dataclass."""

    def test_container_info_fields(self):
        """ContainerInfo has expected fields."""
        info = dc.ContainerInfo(
            name="test",
            id="abc123",
            status="running",
            image="nginx:latest",
            host_port=8080,
            started_at="2026-01-01T00:00:00Z",
            labels={"app": "test"},
        )
        assert info.name == "test"
        assert info.status == "running"
        assert info.host_port == 8080


class TestParseImageEntry:
    """Tests for _parse_image_entry with Docker and Podman JSON formats."""

    def test_docker_format(self):
        """Docker image JSON uses Tag/Repository/Size keys."""
        img = {
            "Repository": "artifactory.nds-association.org/ndslive-dockerreg/nds-mapviewer",
            "Tag": "latest-arm64",
            "Size": "1.2GB",
        }
        tag, size_mb = dc._parse_image_entry(img)
        assert tag == "latest-arm64"
        assert size_mb > 0

    def test_podman_format(self):
        """Podman image JSON uses names (list) and size (int) keys."""
        img = {
            "names": [
                "artifactory.nds-association.org/ndslive-dockerreg/nds-mapviewer:latest-arm64"
            ],
            "size": 512 * 1024 * 1024,
            "digest": "sha256:abc123",
        }
        tag, size_mb = dc._parse_image_entry(img)
        assert tag == "latest-arm64"
        assert size_mb == 512.0

    def test_podman_format_capitalized_names(self):
        """Podman may also use capitalized Names key."""
        img = {
            "Names": [
                "registry.example.com/image:v1.0-amd64"
            ],
            "size": 256 * 1024 * 1024,
        }
        tag, size_mb = dc._parse_image_entry(img)
        assert tag == "v1.0-amd64"
        assert size_mb == 256.0

    def test_empty_entry(self):
        """Empty dict returns empty tag."""
        tag, size_mb = dc._parse_image_entry({})
        assert tag == ""
        assert size_mb == 0.0


class TestListLocalImagesFormats:
    """Test list_local_image_versions with mocked Docker and Podman output."""

    def test_docker_newline_delimited_json(self, docker_client, mocker):
        """Docker outputs newline-delimited JSON objects."""
        registry = dc.REGISTRIES["community"]
        mock_result = mocker.MagicMock()
        mock_result.stdout = (
            f'{{"Repository":"{registry}/nds-mapviewer","Tag":"latest-arm64","Size":"1.2GB"}}\n'
            f'{{"Repository":"{registry}/nds-mapviewer","Tag":"dev-arm64","Size":"1.1GB"}}\n'
        )
        mock_result.returncode = 0
        mocker.patch.object(rt, "run", return_value=mock_result)

        results = dc.list_local_image_versions("community")
        assert len(results) == 2
        assert results[0]["version"] == "latest"
        assert results[1]["version"] == "dev"

    def test_podman_json_array(self, docker_client, mocker):
        """Podman outputs a single JSON array."""
        registry = dc.REGISTRIES["community"]
        mock_result = mocker.MagicMock()
        mock_result.stdout = json.dumps([
            {
                "names": [f"{registry}/nds-mapviewer:latest-arm64"],
                "size": 512 * 1024 * 1024,
                "digest": "sha256:abc",
            },
            {
                "names": [f"{registry}/nds-mapviewer:dev-arm64"],
                "size": 400 * 1024 * 1024,
                "digest": "sha256:def",
            },
        ])
        mock_result.returncode = 0
        mocker.patch.object(rt, "run", return_value=mock_result)

        results = dc.list_local_image_versions("community")
        assert len(results) == 2
        assert results[0]["version"] == "latest"
        assert results[0]["size_mb"] == 512.0
        assert results[1]["version"] == "dev"
