"""Entity pools for hard, semantically confusable needles.

We use small, fixed pools of similar-looking entities (projects, people,
departments, codes) so that distractors are realistically confusable with the
target needle. Disambiguation forces actual long-range retrieval rather than
pattern-matching on a unique token.
"""

from __future__ import annotations

from dataclasses import dataclass


PROJECTS: tuple[str, ...] = (
    "Aurora",
    "Atlas",
    "Apollo",
    "Andromeda",
    "Artemis",
    "Aegis",
    "Avalon",
    "Anvil",
)

PROJECT_CODES: tuple[str, ...] = (
    "AUR-4521",
    "AUR-4523",
    "ATL-7701",
    "ATL-7704",
    "APO-9912",
    "APO-9914",
    "AND-3340",
    "AND-3346",
    "ART-1180",
    "AEG-2225",
    "AVA-6608",
    "ANV-5503",
)

PEOPLE: tuple[str, ...] = (
    "Dr. Sarah Chen",
    "Dr. Sarah Cheng",
    "Dr. Michael Park",
    "Dr. Michael Parker",
    "Dr. Emily Rodriguez",
    "Dr. Emilia Rodriguez",
    "Dr. James Liu",
    "Dr. James Lui",
    "Dr. Priya Sharma",
    "Dr. Priya Verma",
    "Dr. Hassan Ali",
    "Dr. Hannah Ali",
)

DEPARTMENTS: tuple[str, ...] = (
    "Engineering",
    "Engineering Operations",
    "Research",
    "Research and Development",
    "Platform Engineering",
    "Infrastructure",
    "Data Platform",
    "Data Engineering",
)

DEADLINES: tuple[str, ...] = (
    "March 15",
    "March 17",
    "March 22",
    "March 29",
    "April 03",
    "April 10",
    "April 12",
    "April 24",
    "May 06",
    "May 08",
)

BUDGETS: tuple[str, ...] = (
    "$1.2M",
    "$1.4M",
    "$1.5M",
    "$1.8M",
    "$2.1M",
    "$2.4M",
    "$3.0M",
    "$3.6M",
)


# -----------------------------------------------------------------------------
# Disjoint "unseen" pools for held-out evaluation
# -----------------------------------------------------------------------------
# These pools are guaranteed to share no values with the default pools above.
# They follow the same internal structure (same number of confusable variants
# per slot, same naming patterns) so the model's task remains identical at the
# template level. The only thing that changes is the surface tokens, which
# tests whether the model has memorized the lookup or learned a generalizable
# extraction pattern.

PROJECTS_UNSEEN: tuple[str, ...] = (
    "Brontis",
    "Bronton",
    "Cyclone",
    "Cyclonus",
    "Demeter",
    "Demitra",
    "Enki",
    "Enkidu",
)

PROJECT_CODES_UNSEEN: tuple[str, ...] = (
    "BRX-9001",
    "BRX-9007",
    "CYC-9012",
    "CYC-9018",
    "DEM-9023",
    "DEM-9029",
    "ENK-9034",
    "ENK-9040",
    "BRT-9051",
    "CTC-9060",
    "DTR-9077",
    "EKD-9085",
)

PEOPLE_UNSEEN: tuple[str, ...] = (
    # Same "Dr." title as the default pool so the only novelty under test is
    # the surface form of the *name*, not the prefix token.
    "Dr. Aiko Tanaka",
    "Dr. Aiko Takenaka",
    "Dr. Marco Rossi",
    "Dr. Marco Russi",
    "Dr. Olufemi Adebayo",
    "Dr. Olufemi Adebola",
    "Dr. Lin Wei",
    "Dr. Lin Wai",
    "Dr. Anjali Iyer",
    "Dr. Anjali Iyengar",
    "Dr. Diego Castro",
    "Dr. Diego Castaneda",
)

DEADLINES_UNSEEN: tuple[str, ...] = (
    "June 02",
    "June 05",
    "June 19",
    "June 26",
    "July 08",
    "July 14",
    "July 23",
    "August 03",
    "August 11",
    "August 17",
)

BUDGETS_UNSEEN: tuple[str, ...] = (
    "$4.4M",
    "$4.8M",
    "$5.2M",
    "$5.6M",
    "$6.4M",
    "$7.1M",
    "$8.3M",
    "$9.6M",
)


# Map a pool-set name to the entity/value pools it should use.
# The key shape matches what ``generator._entity_pool_for`` and
# ``generator._value_pool_for`` need: per-needle-type entity and value pools.
POOL_SETS: dict[str, dict[str, tuple[str, ...]]] = {
    "default": {
        "entities": PROJECTS,
        "project_code": PROJECT_CODES,
        "deadline": DEADLINES,
        "budget": BUDGETS,
        "lead": PEOPLE,
    },
    "unseen": {
        "entities": PROJECTS_UNSEEN,
        "project_code": PROJECT_CODES_UNSEEN,
        "deadline": DEADLINES_UNSEEN,
        "budget": BUDGETS_UNSEEN,
        "lead": PEOPLE_UNSEEN,
    },
}


@dataclass(frozen=True)
class NeedleSpec:
    """A single fact placed in the haystack.

    Attributes:
        type: One of the supported needle types ("project_code",
            "deadline", "budget", "lead").
        entity: The disambiguating entity for this needle (e.g. project name).
        value: The hidden value the model must retrieve for that entity.
        sentence: Rendered natural-language sentence inserted into the haystack.
    """

    type: str
    entity: str
    value: str
    sentence: str
