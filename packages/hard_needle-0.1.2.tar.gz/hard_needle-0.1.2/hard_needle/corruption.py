"""Corruption utilities for producing hard negatives.

The original generator mutated the prompt+target string in place, which made
it hard to recover the original target and silently changed the haystack of
its own positive example. ``corrupt_example`` here is pure: it takes a
positive example dict and returns a *new* dict with a clearly labelled
corruption.

Three corruption modes are supported:

- ``"target"``: replace the target value with a different value drawn from
  the same value pool, keeping the haystack untouched. Useful for label-flip
  contrastive training.
- ``"swap_value"``: rewrite the answer needle in the haystack so it points to
  a wrong-but-plausible value, then update the gold target accordingly.
  Tests whether the model trusts surface tokens over the actual document.
- ``"remove"``: remove the answer-bearing needle from the haystack while
  keeping the question. The correct gold becomes ``"unknown"``. Useful for
  abstention training.
"""

from __future__ import annotations

import random
from typing import Any, Dict, Optional

from hard_needle.entities import (
    BUDGETS,
    DEADLINES,
    PEOPLE,
    PROJECT_CODES,
)


_VALUE_POOLS: Dict[str, tuple[str, ...]] = {
    "project_code": PROJECT_CODES,
    "deadline": DEADLINES,
    "budget": BUDGETS,
    "lead": PEOPLE,
}


CORRUPTION_TYPES: tuple[str, ...] = ("target", "swap_value", "remove")


def _pick_other_value(needle_type: str, current: str, rng: random.Random) -> str:
    pool = _VALUE_POOLS[needle_type]
    candidates = [v for v in pool if v != current]
    if not candidates:
        return current
    return rng.choice(candidates)


def _find_target_record(example: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    target_entity = example.get("target_entity")
    target_type = example.get("target_needle_type")
    for r in example.get("needle_records", []):
        if r.get("entity") == target_entity and r.get("type") == target_type:
            return r
    return None


def corrupt_example(
    example: Dict[str, Any],
    *,
    corruption_type: Optional[str] = None,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Return a corrupted copy of ``example``.

    Args:
        example: A positive example dict produced by ``generate_hard_example``.
        corruption_type: One of ``CORRUPTION_TYPES``. If ``None``, a type is
            sampled uniformly.
        seed: Optional integer seed for deterministic corruption.

    Returns:
        A new dict with ``is_corrupted=True``, ``corruption_type`` set, and
        ``original_target`` recording the pre-corruption target.
    """
    if corruption_type is not None and corruption_type not in CORRUPTION_TYPES:
        raise ValueError(
            f"Unknown corruption_type {corruption_type!r}; expected one of {CORRUPTION_TYPES}"
        )

    rng = random.Random(seed)
    ctype = corruption_type or rng.choice(CORRUPTION_TYPES)

    target_record = _find_target_record(example)
    if target_record is None:
        raise ValueError("Example has no matching target record; cannot corrupt safely.")

    original_target = example["target"]
    new_example: Dict[str, Any] = dict(example)
    new_example["needle_records"] = [dict(r) for r in example.get("needle_records", [])]

    if ctype == "target":
        new_value = _pick_other_value(target_record["type"], original_target, rng)
        new_example["target"] = new_value
        new_example["target_value"] = new_value
        new_example["text"] = f"{example['prompt']} {new_value}"

    elif ctype == "swap_value":
        new_value = _pick_other_value(target_record["type"], original_target, rng)
        old_sentence = target_record["sentence"]
        from hard_needle.generator import _render_sentence

        new_sentence = _render_sentence(target_record["type"], target_record["entity"], new_value)
        new_prompt = example["prompt"].replace(old_sentence, new_sentence, 1)
        new_example["prompt"] = new_prompt
        new_example["target"] = new_value
        new_example["target_value"] = new_value
        new_example["text"] = f"{new_prompt} {new_value}"
        for r in new_example["needle_records"]:
            if r["entity"] == target_record["entity"] and r["type"] == target_record["type"]:
                r["value"] = new_value
                r["sentence"] = new_sentence
                r["char_pos"] = new_prompt.find(new_sentence)

    elif ctype == "remove":
        old_sentence = target_record["sentence"]
        new_prompt = example["prompt"].replace(" " + old_sentence, "", 1)
        if new_prompt == example["prompt"]:
            new_prompt = example["prompt"].replace(old_sentence + " ", "", 1)
        if new_prompt == example["prompt"]:
            new_prompt = example["prompt"].replace(old_sentence, "", 1)
        new_example["prompt"] = new_prompt
        new_example["target"] = "unknown"
        new_example["target_value"] = "unknown"
        new_example["text"] = f"{new_prompt} unknown"
        new_example["needle_records"] = [
            r
            for r in new_example["needle_records"]
            if not (
                r["entity"] == target_record["entity"]
                and r["type"] == target_record["type"]
            )
        ]

    else:
        raise AssertionError(f"Unhandled corruption type: {ctype}")

    new_example["is_corrupted"] = True
    new_example["corruption_type"] = ctype
    new_example["original_target"] = original_target
    return new_example
