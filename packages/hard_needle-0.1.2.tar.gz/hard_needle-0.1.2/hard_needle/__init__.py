"""hard-needle: semantically hard multi-needle long-context data generator."""

from hard_needle.entities import (
    BUDGETS,
    BUDGETS_UNSEEN,
    DEADLINES,
    DEADLINES_UNSEEN,
    DEPARTMENTS,
    NeedleSpec,
    PEOPLE,
    PEOPLE_UNSEEN,
    POOL_SETS,
    PROJECT_CODES,
    PROJECT_CODES_UNSEEN,
    PROJECTS,
    PROJECTS_UNSEEN,
)
from hard_needle.distractors import (
    DistractorPool,
    BuiltinDistractorPool,
    PG19DistractorPool,
    load_default_distractor_pool,
)
from hard_needle.generator import (
    POOL_SET_NAMES,
    generate_hard_example,
    generate_dataset,
)
from hard_needle.corruption import corrupt_example

__all__ = [
    "BUDGETS",
    "BUDGETS_UNSEEN",
    "DEADLINES",
    "DEADLINES_UNSEEN",
    "DEPARTMENTS",
    "NeedleSpec",
    "PEOPLE",
    "PEOPLE_UNSEEN",
    "POOL_SETS",
    "POOL_SET_NAMES",
    "PROJECTS",
    "PROJECTS_UNSEEN",
    "PROJECT_CODES",
    "PROJECT_CODES_UNSEEN",
    "DistractorPool",
    "BuiltinDistractorPool",
    "PG19DistractorPool",
    "load_default_distractor_pool",
    "generate_hard_example",
    "generate_dataset",
    "corrupt_example",
]

__version__ = "0.1.2"
