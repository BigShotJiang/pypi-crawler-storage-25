"""Distractor sentence sources for haystack filler.

Two implementations are provided:

- ``BuiltinDistractorPool``: a built-in pool of plausible business / technical
  distractor sentences. Always available, deterministic, and good enough for
  unit tests and small experiments.
- ``PG19DistractorPool``: streams sentences from the PG-19 dataset on demand.
  Requires the optional ``datasets`` extra. Loaded lazily, with a hard cap on
  the number of sentences buffered to avoid the original script's full-pass
  cost.

Both pools implement the ``DistractorPool`` protocol: ``sample(n, rng)``.
"""

from __future__ import annotations

import random
import re
from typing import Iterable, List, Optional, Protocol


_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z])")


def _split_sentences(text: str) -> List[str]:
    text = re.sub(r"\s+", " ", text).strip()
    return [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]


class DistractorPool(Protocol):
    def sample(self, n: int, rng: random.Random) -> List[str]:
        ...


_BUILTIN_DISTRACTORS: tuple[str, ...] = (
    "The team finalized the quarterly review documentation last Tuesday.",
    "Several engineers attended the cross-functional alignment meeting.",
    "The infrastructure migration was completed without major incidents.",
    "Budget allocations were updated following the latest forecast revision.",
    "Stakeholders requested additional clarity on the integration timeline.",
    "A new compliance checklist was distributed to all team leads.",
    "The performance regression suite caught two issues during nightly runs.",
    "Several action items from the offsite remained open after the deadline.",
    "Engineering leadership reaffirmed the priority of platform hardening.",
    "The customer escalation was resolved by the on-call engineer within hours.",
    "Documentation for the new pipeline was updated and reviewed by two peers.",
    "The hiring committee finalized the loop structure for senior candidates.",
    "Minor schema changes were rolled out behind a feature flag.",
    "Capacity planning numbers were revised after the latest traffic spike.",
    "The release was cut from the stabilization branch as planned.",
    "Several long-standing flaky tests were quarantined pending investigation.",
    "Logging and observability dashboards were extended to cover the new region.",
    "An unplanned deployment freeze briefly blocked release activity midweek.",
    "Researchers shared preliminary results during the weekly reading group.",
    "The privacy review for the new surface was completed on schedule.",
    "An updated risk register was circulated ahead of the steering meeting.",
    "Two new vendors were shortlisted for the upcoming procurement cycle.",
    "Threat modeling notes were added to the design document repository.",
    "A new on-call rotation was published for the upcoming quarter.",
    "Several teams requested additional staging capacity for end-of-quarter testing.",
    "The platform team published a deprecation notice for the legacy gateway.",
    "A short tabletop exercise validated the disaster recovery runbook.",
    "Latency on the read path improved after the index rebuild completed.",
    "Annual budgeting cycles required tighter coordination across orgs this year.",
    "Travel approvals for the partner summit were finalized late on Friday.",
    "Several feature toggles were retired after the migration was confirmed stable.",
    "The internal hackathon produced a handful of promising prototypes.",
    "Capacity for offline batch jobs was increased ahead of the campaign.",
    "Storage costs declined modestly after the lifecycle policy was tightened.",
    "Synthetic monitoring caught a brief regional degradation overnight.",
)


class BuiltinDistractorPool:
    """In-memory pool backed by ``_BUILTIN_DISTRACTORS``."""

    def __init__(self, sentences: Optional[Iterable[str]] = None) -> None:
        self._sentences: List[str] = list(sentences) if sentences is not None else list(_BUILTIN_DISTRACTORS)
        if not self._sentences:
            raise ValueError("BuiltinDistractorPool requires at least one sentence")

    def sample(self, n: int, rng: random.Random) -> List[str]:
        if n <= 0:
            return []
        return [rng.choice(self._sentences) for _ in range(n)]


class PG19DistractorPool:
    """Distractor pool sourced from PG-19, loaded lazily.

    A hard cap (``max_sentences``) is enforced so the original script's
    full-pass cost is not paid. Sentences shorter than ``min_chars`` are
    discarded so we don't fill the haystack with stage directions.
    """

    def __init__(
        self,
        max_sentences: int = 20_000,
        min_chars: int = 40,
        max_documents: int = 200,
    ) -> None:
        self._max_sentences = max_sentences
        self._min_chars = min_chars
        self._max_documents = max_documents
        self._sentences: Optional[List[str]] = None

    def _load(self) -> List[str]:
        try:
            from datasets import load_dataset  # type: ignore
        except ImportError as e:
            raise ImportError(
                "PG19DistractorPool requires the 'datasets' package. "
                "Install with: pip install 'hard-needle[datasets]'"
            ) from e

        ds = load_dataset("pg19", split="train", streaming=True)

        sentences: List[str] = []
        seen_docs = 0
        for row in ds:
            seen_docs += 1
            if seen_docs > self._max_documents:
                break
            text = row.get("text", "") or ""
            for s in _split_sentences(text):
                if len(s) < self._min_chars:
                    continue
                sentences.append(s)
                if len(sentences) >= self._max_sentences:
                    return sentences
        if not sentences:
            raise RuntimeError(
                "PG19DistractorPool produced no sentences; "
                "check the 'datasets' install and network access."
            )
        return sentences

    def sample(self, n: int, rng: random.Random) -> List[str]:
        if n <= 0:
            return []
        if self._sentences is None:
            self._sentences = self._load()
        return [rng.choice(self._sentences) for _ in range(n)]


def load_default_distractor_pool(prefer_pg19: bool = False) -> DistractorPool:
    """Return a working distractor pool, falling back to the builtin pool."""
    if prefer_pg19:
        try:
            return PG19DistractorPool()
        except ImportError:
            return BuiltinDistractorPool()
    return BuiltinDistractorPool()
