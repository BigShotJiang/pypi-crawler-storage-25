"""Hard multi-needle long-context example generator.

Design goals (informed by review of the original synthetic_hard_needle_generator.py):

1. Confusable needles: each example places multiple semantically similar facts
   (e.g. multiple project codes) into the haystack, so the model must
   disambiguate by entity.
2. Explicit prompt / target / text fields: the original concatenated
   ``prompt + target`` into a single string. We keep them separate and also
   expose ``text`` for backwards compatibility / drop-in use with text-only
   pipelines.
3. Structured ``needle_records``: instead of a flat list of strings, every
   needle is recorded with its type, entity, value, char position and depth
   fraction. This makes lost-in-the-middle and per-type analyses trivial.
4. Safe corruption: the generator does not mutate fields. ``corrupt_example``
   in ``corruption.py`` is the only path for producing negatives, and it
   builds a fresh dict.
5. Efficient distractors: ``DistractorPool`` is loaded once at module level
   when the CLI is used, and is passed through to every example. PG-19 is
   capped at a configurable number of sentences.
6. Optional token-aware truncation: if a HuggingFace tokenizer is provided,
   the haystack is truncated to ``ctx_tokens`` tokens. We do not claim
   perfect token accounting across needle insertions; this is intended as a
   coarse safety net, not a hard guarantee.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from hard_needle.distractors import (
    BuiltinDistractorPool,
    DistractorPool,
    load_default_distractor_pool,
)
from hard_needle.entities import (
    BUDGETS,
    DEADLINES,
    DEPARTMENTS,
    NeedleSpec,
    PEOPLE,
    POOL_SETS,
    PROJECT_CODES,
    PROJECTS,
)


NEEDLE_TYPES: Tuple[str, ...] = ("project_code", "deadline", "budget", "lead")
POOL_SET_NAMES: Tuple[str, ...] = tuple(POOL_SETS.keys())


def _render_sentence(needle_type: str, entity: str, value: str) -> str:
    if needle_type == "project_code":
        return f"The special project code for {entity} is {value}."
    if needle_type == "deadline":
        return f"The internal deadline for {entity} is {value}."
    if needle_type == "budget":
        return f"The approved budget for {entity} is {value}."
    if needle_type == "lead":
        return f"The lead engineer for {entity} is {value}."
    raise ValueError(f"Unknown needle type: {needle_type}")


def _render_question(needle: NeedleSpec) -> str:
    if needle.type == "project_code":
        return f"What is the special project code for {needle.entity}?"
    if needle.type == "deadline":
        return f"What is the internal deadline for {needle.entity}?"
    if needle.type == "budget":
        return f"What is the approved budget for {needle.entity}?"
    if needle.type == "lead":
        return f"Who is the lead engineer for {needle.entity}?"
    raise ValueError(f"Unknown needle type: {needle.type}")


def _resolve_pool_set(pool_set: str) -> dict:
    if pool_set not in POOL_SETS:
        raise ValueError(
            f"Unknown pool_set {pool_set!r}; expected one of {POOL_SET_NAMES}"
        )
    return POOL_SETS[pool_set]


def _entity_pool_for(needle_type: str, pools: dict) -> Sequence[str]:
    """All needle types are keyed by entity (project name).

    The ``pools["entities"]`` entry holds that pool. We accept ``needle_type``
    in the signature for forward compat with type-specific entity sets.
    """
    if needle_type not in NEEDLE_TYPES:
        raise ValueError(f"Unknown needle type: {needle_type}")
    return pools["entities"]


def _value_pool_for(needle_type: str, pools: dict) -> Sequence[str]:
    if needle_type not in pools:
        raise ValueError(f"Unknown needle type: {needle_type}")
    return pools[needle_type]


def _sample_needles(
    num_needles: int,
    rng: random.Random,
    pools: dict,
) -> List[NeedleSpec]:
    """Sample ``num_needles`` confusable needles.

    All needles share the same ``needle_type`` so the haystack contains
    multiple semantically similar facts (e.g. several project codes), which
    is the whole point of "hard" multi-needle.
    """
    if num_needles <= 0:
        raise ValueError("num_needles must be >= 1")
    needle_type = rng.choice(NEEDLE_TYPES)
    entity_pool = _entity_pool_for(needle_type, pools)
    value_pool = _value_pool_for(needle_type, pools)
    if num_needles > len(entity_pool):
        raise ValueError(
            f"Requested {num_needles} needles but entity pool for "
            f"'{needle_type}' has only {len(entity_pool)} entries."
        )
    if num_needles > len(value_pool):
        raise ValueError(
            f"Requested {num_needles} needles but value pool for "
            f"'{needle_type}' has only {len(value_pool)} entries."
        )

    entities = rng.sample(list(entity_pool), num_needles)
    values = rng.sample(list(value_pool), num_needles)

    needles: List[NeedleSpec] = []
    for entity, value in zip(entities, values):
        needles.append(
            NeedleSpec(
                type=needle_type,
                entity=entity,
                value=value,
                sentence=_render_sentence(needle_type, entity, value),
            )
        )
    return needles


def _build_haystack(
    target_chars: int,
    distractors: DistractorPool,
    rng: random.Random,
) -> List[str]:
    """Sample distractor sentences until the joined char count exceeds target."""
    sentences: List[str] = []
    total = 0
    batch = 64
    while total < target_chars:
        for s in distractors.sample(batch, rng):
            sentences.append(s)
            total += len(s) + 1
            if total >= target_chars:
                break
    return sentences


def _truncate_to_token_budget(
    text: str,
    tokenizer: Any,
    max_tokens: int,
) -> str:
    """Soft token-budget truncation. Returns text unchanged if under budget."""
    ids = tokenizer.encode(text, add_special_tokens=False)
    if len(ids) <= max_tokens:
        return text
    truncated_ids = ids[:max_tokens]
    return tokenizer.decode(truncated_ids, skip_special_tokens=True)


def generate_hard_example(
    num_needles: int = 3,
    ctx_chars: int = 8000,
    distractors: Optional[DistractorPool] = None,
    *,
    ctx_tokens: Optional[int] = None,
    tokenizer: Optional[Any] = None,
    seed: Optional[int] = None,
    pool_set: str = "default",
) -> Dict[str, Any]:
    """Generate a single hard multi-needle example.

    Args:
        num_needles: Number of confusable needles to insert.
        ctx_chars: Approximate context length in characters.
        distractors: A ``DistractorPool``. If ``None``, the builtin pool is
            used. PG-19 is opt-in via ``load_default_distractor_pool(True)``
            to keep imports cheap by default.
        ctx_tokens: If provided together with ``tokenizer``, the haystack is
            additionally truncated to this many tokens after needle insertion.
            Note: token accounting across needle insertions is approximate.
        tokenizer: Optional HuggingFace-style tokenizer used by ``ctx_tokens``.
        seed: Optional integer seed for deterministic generation.
        pool_set: Which entity/value pool set to draw from. ``"default"``
            uses the standard pools; ``"unseen"`` uses a disjoint held-out
            pool for evaluating generalization to novel entities/values.

    Returns:
        A dict with the schema documented in ``README.md``. The chosen
        ``pool_set`` is recorded as a top-level key.
    """
    if num_needles <= 0:
        raise ValueError("num_needles must be >= 1")
    if ctx_chars <= 0:
        raise ValueError("ctx_chars must be > 0")
    if (ctx_tokens is None) != (tokenizer is None):
        raise ValueError(
            "ctx_tokens and tokenizer must be provided together (or neither)."
        )

    pools = _resolve_pool_set(pool_set)
    rng = random.Random(seed)
    pool = distractors if distractors is not None else BuiltinDistractorPool()

    needles = _sample_needles(num_needles, rng, pools)
    target_needle_idx = rng.randrange(len(needles))
    target_needle = needles[target_needle_idx]

    distractor_sentences = _build_haystack(
        target_chars=max(ctx_chars - sum(len(n.sentence) + 1 for n in needles), 1),
        distractors=pool,
        rng=rng,
    )

    if len(distractor_sentences) >= len(needles):
        positions = sorted(
            rng.sample(range(len(distractor_sentences) + 1), len(needles))
        )
    else:
        positions = sorted(rng.choices(range(len(distractor_sentences) + 1), k=len(needles)))

    composed: List[str] = list(distractor_sentences)
    for offset, (pos, needle) in enumerate(zip(positions, needles)):
        composed.insert(pos + offset, needle.sentence)

    haystack_text = " ".join(composed)

    if ctx_tokens is not None and tokenizer is not None:
        haystack_text = _truncate_to_token_budget(haystack_text, tokenizer, ctx_tokens)

    needle_records: List[Dict[str, Any]] = []
    for needle in needles:
        char_pos = haystack_text.find(needle.sentence)
        depth_frac = char_pos / max(len(haystack_text), 1) if char_pos >= 0 else -1.0
        needle_records.append(
            {
                "type": needle.type,
                "entity": needle.entity,
                "value": needle.value,
                "sentence": needle.sentence,
                "char_pos": char_pos,
                "depth_frac": depth_frac,
            }
        )

    question = _render_question(target_needle)
    department_hint = rng.choice(DEPARTMENTS)
    prompt = (
        f"You are an internal assistant for the {department_hint} team. "
        f"Read the document carefully and answer the question.\n\n"
        f"Document:\n{haystack_text}\n\n"
        f"Question: {question}\nAnswer:"
    )
    target = target_needle.value
    text = f"{prompt} {target}"

    return {
        "prompt": prompt,
        "target": target,
        "text": text,
        "question": question,
        "target_needle_type": target_needle.type,
        "target_entity": target_needle.entity,
        "target_value": target_needle.value,
        "needle_records": needle_records,
        "num_needles": num_needles,
        "ctx_chars": ctx_chars,
        "is_corrupted": False,
        "pool_set": pool_set,
    }


def generate_dataset(
    num_examples: int,
    *,
    num_needles: int = 3,
    ctx_chars: int = 8000,
    distractors: Optional[DistractorPool] = None,
    ctx_tokens: Optional[int] = None,
    tokenizer: Optional[Any] = None,
    seed: int = 0,
    include_corrupted: bool = False,
    corruption_ratio: float = 0.2,
    pool_set: str = "default",
) -> List[Dict[str, Any]]:
    """Generate a list of examples, optionally with paired corrupted negatives.

    Each example uses a deterministic per-example seed derived from ``seed``
    so the dataset is reproducible. Corrupted examples are appended after
    their positive counterpart and reference the original in
    ``original_target``.
    """
    if num_examples < 0:
        raise ValueError("num_examples must be >= 0")
    if not 0.0 <= corruption_ratio <= 1.0:
        raise ValueError("corruption_ratio must be in [0, 1]")
    rng = random.Random(seed)
    pool = distractors if distractors is not None else BuiltinDistractorPool()
    out: List[Dict[str, Any]] = []
    for i in range(num_examples):
        ex = generate_hard_example(
            num_needles=num_needles,
            ctx_chars=ctx_chars,
            distractors=pool,
            ctx_tokens=ctx_tokens,
            tokenizer=tokenizer,
            seed=seed * 100_003 + i,
            pool_set=pool_set,
        )
        out.append(ex)
        if include_corrupted and rng.random() < corruption_ratio:
            from hard_needle.corruption import corrupt_example

            neg = corrupt_example(ex, seed=seed * 100_003 + i + 1)
            out.append(neg)
    return out


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="hard-needle-generate",
        description="Generate a hard multi-needle long-context dataset.",
    )
    p.add_argument("--num-examples", type=int, default=100)
    p.add_argument("--num-needles", type=int, default=3)
    p.add_argument("--ctx-chars", type=int, default=8000)
    p.add_argument(
        "--ctx-tokens",
        type=int,
        default=None,
        help="Optional token budget. Requires --tokenizer.",
    )
    p.add_argument(
        "--tokenizer",
        type=str,
        default=None,
        help="HuggingFace tokenizer name. Requires the 'tokenizer' extra.",
    )
    p.add_argument(
        "--distractor-source",
        choices=("builtin", "pg19"),
        default="builtin",
        help="Where to draw distractor sentences from.",
    )
    p.add_argument("--seed", type=int, default=0)
    p.add_argument(
        "--include-corrupted",
        action="store_true",
        help="Emit paired corrupted negatives.",
    )
    p.add_argument(
        "--corruption-ratio",
        type=float,
        default=0.2,
        help="Fraction of positives that get a corrupted partner.",
    )
    p.add_argument(
        "--pool-set",
        choices=POOL_SET_NAMES,
        default="default",
        help=(
            "Which entity/value pool set to draw from. 'default' is the "
            "standard pool. 'unseen' is a disjoint held-out pool for "
            "evaluating generalization to novel entities."
        ),
    )
    p.add_argument(
        "--output",
        type=str,
        default="-",
        help="Output JSONL path. Use '-' for stdout.",
    )
    return p


def _load_tokenizer(name: str) -> Any:
    try:
        from transformers import AutoTokenizer  # type: ignore
    except ImportError as e:
        raise SystemExit(
            "--tokenizer requires the 'transformers' package. "
            "Install with: pip install 'hard-needle[tokenizer]'"
        ) from e
    return AutoTokenizer.from_pretrained(name)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _build_arg_parser().parse_args(argv)

    pool: DistractorPool
    if args.distractor_source == "pg19":
        pool = load_default_distractor_pool(prefer_pg19=True)
    else:
        pool = BuiltinDistractorPool()

    tokenizer = _load_tokenizer(args.tokenizer) if args.tokenizer else None

    if (args.ctx_tokens is None) != (tokenizer is None):
        raise SystemExit("--ctx-tokens and --tokenizer must be provided together.")

    examples = generate_dataset(
        num_examples=args.num_examples,
        num_needles=args.num_needles,
        ctx_chars=args.ctx_chars,
        distractors=pool,
        ctx_tokens=args.ctx_tokens,
        tokenizer=tokenizer,
        seed=args.seed,
        include_corrupted=args.include_corrupted,
        corruption_ratio=args.corruption_ratio,
        pool_set=args.pool_set,
    )

    if args.output == "-":
        for ex in examples:
            sys.stdout.write(json.dumps(ex, ensure_ascii=False) + "\n")
    else:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w", encoding="utf-8") as f:
            for ex in examples:
                f.write(json.dumps(ex, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":  # pragma: no cover - CLI entry
    raise SystemExit(main())
