"""Tests for the disjoint 'unseen' entity/value pool set."""

from __future__ import annotations

import pytest

from hard_needle import (
    BUDGETS,
    BUDGETS_UNSEEN,
    DEADLINES,
    DEADLINES_UNSEEN,
    PEOPLE,
    PEOPLE_UNSEEN,
    POOL_SETS,
    POOL_SET_NAMES,
    PROJECTS,
    PROJECTS_UNSEEN,
    PROJECT_CODES,
    PROJECT_CODES_UNSEEN,
    generate_dataset,
    generate_hard_example,
)


def test_pool_set_names_includes_default_and_unseen() -> None:
    assert "default" in POOL_SET_NAMES
    assert "unseen" in POOL_SET_NAMES


def test_default_and_unseen_pools_are_disjoint() -> None:
    pairs = (
        (PROJECTS, PROJECTS_UNSEEN, "projects"),
        (PROJECT_CODES, PROJECT_CODES_UNSEEN, "project_codes"),
        (PEOPLE, PEOPLE_UNSEEN, "people"),
        (DEADLINES, DEADLINES_UNSEEN, "deadlines"),
        (BUDGETS, BUDGETS_UNSEEN, "budgets"),
    )
    for default_pool, unseen_pool, label in pairs:
        overlap = set(default_pool) & set(unseen_pool)
        assert not overlap, f"{label} pools overlap: {overlap}"


def test_pool_sets_have_required_keys() -> None:
    required = {"entities", "project_code", "deadline", "budget", "lead"}
    for name in POOL_SET_NAMES:
        assert required.issubset(POOL_SETS[name].keys()), name


def test_unseen_example_only_uses_unseen_pools() -> None:
    ex = generate_hard_example(num_needles=3, ctx_chars=4000, seed=7, pool_set="unseen")
    assert ex["pool_set"] == "unseen"
    assert ex["target_entity"] in PROJECTS_UNSEEN
    assert ex["target_entity"] not in PROJECTS

    needle_type = ex["target_needle_type"]
    expected_value_pool = {
        "project_code": PROJECT_CODES_UNSEEN,
        "deadline": DEADLINES_UNSEEN,
        "budget": BUDGETS_UNSEEN,
        "lead": PEOPLE_UNSEEN,
    }[needle_type]
    forbidden_value_pool = {
        "project_code": PROJECT_CODES,
        "deadline": DEADLINES,
        "budget": BUDGETS,
        "lead": PEOPLE,
    }[needle_type]
    assert ex["target_value"] in expected_value_pool
    assert ex["target_value"] not in forbidden_value_pool

    for rec in ex["needle_records"]:
        assert rec["entity"] in PROJECTS_UNSEEN
        assert rec["entity"] not in PROJECTS


def test_default_example_only_uses_default_pools() -> None:
    ex = generate_hard_example(num_needles=3, ctx_chars=4000, seed=7)
    assert ex["pool_set"] == "default"
    assert ex["target_entity"] in PROJECTS
    assert ex["target_entity"] not in PROJECTS_UNSEEN


def test_dataset_default_and_unseen_are_disjoint_in_targets() -> None:
    """An aggregate sanity check: across many examples, no target value
    from the default set ever appears in the unseen set and vice versa.
    """
    default_ds = generate_dataset(num_examples=30, num_needles=3, ctx_chars=2000, seed=11)
    unseen_ds = generate_dataset(
        num_examples=30, num_needles=3, ctx_chars=2000, seed=11, pool_set="unseen"
    )
    default_targets = {ex["target_value"] for ex in default_ds}
    unseen_targets = {ex["target_value"] for ex in unseen_ds}
    assert not (default_targets & unseen_targets)


def test_unseen_pool_set_rejects_unknown_name() -> None:
    with pytest.raises(ValueError):
        generate_hard_example(num_needles=2, ctx_chars=1000, seed=0, pool_set="bogus")
