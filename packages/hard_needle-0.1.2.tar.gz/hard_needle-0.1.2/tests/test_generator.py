from __future__ import annotations

import json

import pytest

from hard_needle import (
    BuiltinDistractorPool,
    generate_dataset,
    generate_hard_example,
)
from hard_needle.entities import PROJECTS


def test_basic_shape():
    ex = generate_hard_example(num_needles=3, ctx_chars=4000, seed=0)
    for key in (
        "prompt",
        "target",
        "text",
        "question",
        "target_needle_type",
        "target_entity",
        "target_value",
        "needle_records",
        "num_needles",
        "ctx_chars",
        "is_corrupted",
    ):
        assert key in ex, f"missing key: {key}"
    assert ex["num_needles"] == 3
    assert ex["ctx_chars"] == 4000
    assert ex["is_corrupted"] is False


def test_text_is_prompt_plus_target():
    ex = generate_hard_example(num_needles=2, ctx_chars=2000, seed=1)
    assert ex["text"] == f"{ex['prompt']} {ex['target']}"


def test_target_is_one_of_the_needles():
    ex = generate_hard_example(num_needles=4, ctx_chars=4000, seed=2)
    values = {r["value"] for r in ex["needle_records"]}
    assert ex["target"] in values
    assert ex["target_entity"] in {r["entity"] for r in ex["needle_records"]}


def test_needle_records_are_structured_and_present_in_prompt():
    ex = generate_hard_example(num_needles=3, ctx_chars=6000, seed=3)
    assert len(ex["needle_records"]) == 3
    for r in ex["needle_records"]:
        assert set(r.keys()) >= {"type", "entity", "value", "sentence", "char_pos", "depth_frac"}
        assert r["sentence"] in ex["prompt"]
        assert 0.0 <= r["depth_frac"] <= 1.0


def test_haystack_is_long_enough():
    ex = generate_hard_example(num_needles=2, ctx_chars=8000, seed=4)
    assert len(ex["prompt"]) >= 4000


def test_determinism_with_same_seed():
    a = generate_hard_example(num_needles=3, ctx_chars=4000, seed=42)
    b = generate_hard_example(num_needles=3, ctx_chars=4000, seed=42)
    assert a == b


def test_different_seeds_yield_different_examples():
    a = generate_hard_example(num_needles=3, ctx_chars=4000, seed=1)
    b = generate_hard_example(num_needles=3, ctx_chars=4000, seed=2)
    assert a != b


def test_invalid_args():
    with pytest.raises(ValueError):
        generate_hard_example(num_needles=0)
    with pytest.raises(ValueError):
        generate_hard_example(ctx_chars=0)
    with pytest.raises(ValueError):
        generate_hard_example(ctx_tokens=128)
    with pytest.raises(ValueError):
        generate_hard_example(num_needles=999)


def test_distractor_pool_is_used():
    sentinel = "SENTINEL_DISTRACTOR_THAT_IS_VERY_UNIQUE_PHRASE_42."
    pool = BuiltinDistractorPool([sentinel])
    ex = generate_hard_example(
        num_needles=1, ctx_chars=2000, distractors=pool, seed=5
    )
    assert sentinel in ex["prompt"]


def test_generate_dataset_jsonl_roundtrip():
    examples = generate_dataset(num_examples=3, num_needles=2, ctx_chars=3000, seed=7)
    assert len(examples) == 3
    for ex in examples:
        s = json.dumps(ex, ensure_ascii=False)
        rt = json.loads(s)
        assert rt == ex


def test_generate_dataset_can_emit_corrupted_pairs():
    examples = generate_dataset(
        num_examples=20,
        num_needles=2,
        ctx_chars=2000,
        seed=11,
        include_corrupted=True,
        corruption_ratio=1.0,
    )
    assert len(examples) == 40
    pos = [e for e in examples if not e["is_corrupted"]]
    neg = [e for e in examples if e["is_corrupted"]]
    assert len(pos) == 20
    assert len(neg) == 20
    for n in neg:
        assert n["corruption_type"] in ("target", "swap_value", "remove")
        assert "original_target" in n


def test_target_entity_is_in_known_pool():
    ex = generate_hard_example(num_needles=3, ctx_chars=4000, seed=0)
    assert ex["target_entity"] in PROJECTS
