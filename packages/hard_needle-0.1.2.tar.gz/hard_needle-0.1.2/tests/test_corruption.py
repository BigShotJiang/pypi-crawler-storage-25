from __future__ import annotations

import pytest

from hard_needle import corrupt_example, generate_hard_example


def test_corrupt_target_only_changes_label():
    ex = generate_hard_example(num_needles=3, ctx_chars=3000, seed=10)
    neg = corrupt_example(ex, corruption_type="target", seed=1)
    assert neg["is_corrupted"] is True
    assert neg["corruption_type"] == "target"
    assert neg["original_target"] == ex["target"]
    assert neg["target"] != ex["target"]
    assert neg["prompt"] == ex["prompt"]
    assert neg["text"] == f"{ex['prompt']} {neg['target']}"


def test_corrupt_swap_value_changes_haystack_and_target():
    ex = generate_hard_example(num_needles=3, ctx_chars=3000, seed=11)
    neg = corrupt_example(ex, corruption_type="swap_value", seed=2)
    assert neg["target"] != ex["target"]
    assert neg["prompt"] != ex["prompt"]
    target_record = next(
        r
        for r in neg["needle_records"]
        if r["entity"] == ex["target_entity"] and r["type"] == ex["target_needle_type"]
    )
    assert target_record["value"] == neg["target"]
    assert target_record["sentence"] in neg["prompt"]


def test_corrupt_remove_drops_the_needle_and_uses_unknown():
    ex = generate_hard_example(num_needles=3, ctx_chars=3000, seed=12)
    target_sentence = next(
        r["sentence"]
        for r in ex["needle_records"]
        if r["entity"] == ex["target_entity"] and r["type"] == ex["target_needle_type"]
    )
    neg = corrupt_example(ex, corruption_type="remove", seed=3)
    assert neg["target"] == "unknown"
    assert target_sentence not in neg["prompt"]
    assert all(
        not (
            r["entity"] == ex["target_entity"] and r["type"] == ex["target_needle_type"]
        )
        for r in neg["needle_records"]
    )


def test_corruption_does_not_mutate_input():
    ex = generate_hard_example(num_needles=3, ctx_chars=3000, seed=13)
    snapshot_target = ex["target"]
    snapshot_records = [dict(r) for r in ex["needle_records"]]
    _ = corrupt_example(ex, corruption_type="swap_value", seed=4)
    assert ex["target"] == snapshot_target
    assert ex["needle_records"] == snapshot_records


def test_corruption_unknown_type_raises():
    ex = generate_hard_example(num_needles=3, ctx_chars=3000, seed=14)
    with pytest.raises(ValueError):
        corrupt_example(ex, corruption_type="bogus", seed=5)


def test_corruption_random_type_when_unspecified():
    ex = generate_hard_example(num_needles=3, ctx_chars=3000, seed=15)
    neg = corrupt_example(ex, seed=99)
    assert neg["is_corrupted"] is True
    assert neg["corruption_type"] in ("target", "swap_value", "remove")
