from __future__ import annotations

import random

import pytest

from hard_needle.distractors import BuiltinDistractorPool, load_default_distractor_pool


def test_builtin_default_pool_returns_strings():
    pool = BuiltinDistractorPool()
    rng = random.Random(0)
    out = pool.sample(5, rng)
    assert len(out) == 5
    assert all(isinstance(s, str) and s for s in out)


def test_builtin_pool_n_zero_returns_empty():
    pool = BuiltinDistractorPool()
    rng = random.Random(0)
    assert pool.sample(0, rng) == []


def test_builtin_pool_requires_nonempty():
    with pytest.raises(ValueError):
        BuiltinDistractorPool([])


def test_load_default_falls_back_when_pg19_missing():
    pool = load_default_distractor_pool(prefer_pg19=False)
    rng = random.Random(0)
    assert len(pool.sample(3, rng)) == 3
