from __future__ import annotations

import json
import sys
from pathlib import Path

from hard_needle.generator import main


def test_cli_writes_jsonl(tmp_path: Path):
    out = tmp_path / "data.jsonl"
    rc = main(
        [
            "--num-examples", "5",
            "--num-needles", "2",
            "--ctx-chars", "1500",
            "--seed", "0",
            "--output", str(out),
        ]
    )
    assert rc == 0
    lines = out.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 5
    for line in lines:
        ex = json.loads(line)
        assert "prompt" in ex
        assert "target" in ex
        assert "needle_records" in ex


def test_cli_stdout(capsys):
    rc = main(
        [
            "--num-examples", "2",
            "--num-needles", "1",
            "--ctx-chars", "800",
            "--seed", "1",
            "--output", "-",
        ]
    )
    assert rc == 0
    captured = capsys.readouterr()
    lines = [ln for ln in captured.out.splitlines() if ln.strip()]
    assert len(lines) == 2
    for line in lines:
        ex = json.loads(line)
        assert ex["num_needles"] == 1
