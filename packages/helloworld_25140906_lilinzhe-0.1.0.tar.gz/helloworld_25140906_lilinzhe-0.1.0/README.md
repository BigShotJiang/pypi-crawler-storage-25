# helloworld-25140906-lilinzhe

A simple Hello World package for testing.

## Installation

```bash
pip install helloworld-25140906-lilinzhe
```

## Usage

### As a command line tool:

```bash
helloworld-25140906-lilinzhe
```

### As a Python module:

```python
from helloworld_25140906_lilinzhe.main import main

main()
```

Or:

```python
from helloworld_25140906_lilinzhe import hello

hello()
```

## License

MIT License
