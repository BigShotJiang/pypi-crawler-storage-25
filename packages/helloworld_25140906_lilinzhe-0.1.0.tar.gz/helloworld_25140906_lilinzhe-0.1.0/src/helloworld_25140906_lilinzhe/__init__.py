"""helloworld-25140906-lilinzhe - A simple Hello World package."""

__version__ = "0.1.0"


def hello():
    """Print Hello World."""
    print("Hello World")
