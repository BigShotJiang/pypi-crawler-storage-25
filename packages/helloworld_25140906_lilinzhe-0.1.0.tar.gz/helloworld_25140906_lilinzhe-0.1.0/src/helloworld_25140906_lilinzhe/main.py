"""Main module for helloworld-25140906-lilinzhe."""


def main():
    """Main entry point."""
    print("Hello World")


if __name__ == "__main__":
    main()
