from __future__ import annotations

from pathlib import Path

import click
import requests

from .client import TuroClientError
from .config import UPLOAD_CHUNK_BYTES, UPLOAD_TIMEOUT


class _ProgressFile:
    """File wrapper that reports read() progress to a click progressbar.

    Exposes __len__ so requests sends a real Content-Length PUT instead of
    chunked transfer encoding — S3 presigned URLs reject chunked bodies.
    """

    def __init__(self, path: Path, size: int, bar):
        self._fh = path.open("rb")
        self._size = size
        self._bar = bar

    def read(self, amt: int = -1) -> bytes:
        if amt is None or amt < 0:
            amt = UPLOAD_CHUNK_BYTES
        else:
            amt = min(amt, UPLOAD_CHUNK_BYTES)
        chunk = self._fh.read(amt)
        if chunk:
            self._bar.update(len(chunk))
        return chunk

    def __len__(self) -> int:
        return self._size

    def close(self) -> None:
        self._fh.close()


def put_file_to_presigned_url(presigned_url: str, path: Path) -> None:
    """Stream a file to the given presigned URL with a progress bar."""
    size = path.stat().st_size
    headers = {"Content-Type": "application/octet-stream"}

    with click.progressbar(length=size, label=f"  uploading {path.name}") as bar:
        body = _ProgressFile(path, size, bar)
        try:
            resp = requests.put(
                presigned_url,
                data=body,
                headers=headers,
                timeout=UPLOAD_TIMEOUT,
            )
        finally:
            body.close()
    if not resp.ok:
        raise TuroClientError(resp.status_code, f"S3 upload failed: {resp.reason}")
