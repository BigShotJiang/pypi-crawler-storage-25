from __future__ import annotations

import getpass
import sys
from pathlib import Path
from typing import Optional

import click

from . import __version__
from .client import TuroClient, TuroClientError
from .config import DEFAULT_BASE_URL, WSI_EXTENSIONS, validate_base_url
from .uploader import put_file_to_presigned_url


DIFFICULTY_CHOICES = click.Choice(["easy", "medium", "hard"], case_sensitive=False)
STATUS_CHOICES = click.Choice(["draft", "published"], case_sensitive=False)
VISIBILITY_CHOICES = click.Choice(["private", "institution", "public"], case_sensitive=False)


@click.group()
@click.version_option(__version__, prog_name="turoeducate")
def main() -> None:
    """Upload WSI files as cases on TuroEducate."""


def _common_options(f):
    f = click.option("--base-url", default=DEFAULT_BASE_URL, show_default=True,
                     help="TuroEducate base URL (https:// required; http://localhost allowed for dev).")(f)
    f = click.option("--email", default=None, help="Account email. Prompted if omitted.")(f)
    f = click.option("--folder-id", default=None, help="Destination folder UUID (optional).")(f)
    f = click.option("--difficulty", type=DIFFICULTY_CHOICES, default="medium", show_default=True)(f)
    f = click.option("--status", "status_", type=STATUS_CHOICES, default="draft", show_default=True)(f)
    f = click.option("--visibility", type=VISIBILITY_CHOICES, default="private", show_default=True)(f)
    return f


def _authenticated_client(base_url: str, email: Optional[str]) -> TuroClient:
    try:
        base_url = validate_base_url(base_url)
    except ValueError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(2)

    if not email:
        email = click.prompt("Email", type=str)
    password = getpass.getpass("Password: ")
    if not password:
        click.echo("Error: password is required", err=True)
        sys.exit(2)

    client = TuroClient(base_url)
    try:
        user = client.login(email, password)
    except TuroClientError as exc:
        click.echo(f"Error: {exc.detail} ({exc.status_code})", err=True)
        sys.exit(1)
    display = user.get("email") or user.get("username") or email
    click.echo(f"Logged in as {display}")
    return client


def _upload_one(
    client: TuroClient,
    path: Path,
    *,
    title: Optional[str],
    folder_id: Optional[str],
    difficulty: str,
    status_: str,
    visibility: str,
) -> dict:
    file_size = path.stat().st_size
    click.echo(f"→ {path.name} ({file_size / (1024*1024):.1f} MB)")

    presigned = client.get_presigned_upload_url(path.name)
    put_file_to_presigned_url(presigned["presigned_url"], path)

    slide = client.confirm_upload(
        s3_key=presigned["s3_key"],
        bucket=presigned["bucket"],
        filename=path.name,
        file_size=file_size,
        name=path.stem,
    )

    case_title = title or path.stem
    case = client.create_case(
        title=case_title,
        primary_slide_id=slide["id"],
        folder_id=folder_id,
        difficulty=difficulty,
        status=status_,
        visibility=visibility,
    )
    case_url = f"{client.base_url}/cases/{case['id']}"
    click.echo(f"  ✓ case created: {case_url}")
    return case


@main.command()
@click.argument("file", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--title", default=None, help="Override the case title (default: filename without extension).")
@_common_options
def upload(
    file: Path,
    title: Optional[str],
    folder_id: Optional[str],
    difficulty: str,
    status_: str,
    visibility: str,
    base_url: str,
    email: Optional[str],
) -> None:
    """Upload a single WSI and create a case."""
    ext = file.suffix.lower()
    if ext not in WSI_EXTENSIONS:
        click.echo(
            f"Error: {file.name} is not a supported WSI. Allowed: {sorted(WSI_EXTENSIONS)}",
            err=True,
        )
        sys.exit(2)

    client = _authenticated_client(base_url, email)
    try:
        _upload_one(
            client,
            file,
            title=title,
            folder_id=folder_id,
            difficulty=difficulty,
            status_=status_,
            visibility=visibility,
        )
    except TuroClientError as exc:
        click.echo(f"Error: {exc.detail} ({exc.status_code})", err=True)
        sys.exit(1)


@main.command("upload-dir")
@click.argument("directory", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--recursive", "-r", is_flag=True, help="Descend into subdirectories.")
@_common_options
def upload_dir(
    directory: Path,
    recursive: bool,
    folder_id: Optional[str],
    difficulty: str,
    status_: str,
    visibility: str,
    base_url: str,
    email: Optional[str],
) -> None:
    """Upload every WSI in a directory (one login, N uploads)."""
    pattern = "**/*" if recursive else "*"
    candidates = sorted(p for p in directory.glob(pattern) if p.is_file())
    wsi_files = [p for p in candidates if p.suffix.lower() in WSI_EXTENSIONS]
    skipped = [p for p in candidates if p.suffix.lower() not in WSI_EXTENSIONS]

    if not wsi_files:
        click.echo(f"No WSI files found in {directory}.", err=True)
        sys.exit(2)

    click.echo(f"Found {len(wsi_files)} WSI file(s)" + (f", skipping {len(skipped)} non-WSI" if skipped else ""))

    client = _authenticated_client(base_url, email)

    uploaded = 0
    failed = 0
    for path in wsi_files:
        try:
            _upload_one(
                client,
                path,
                title=None,
                folder_id=folder_id,
                difficulty=difficulty,
                status_=status_,
                visibility=visibility,
            )
            uploaded += 1
        except TuroClientError as exc:
            click.echo(f"  ✗ {path.name}: {exc.detail} ({exc.status_code})", err=True)
            failed += 1

    click.echo(f"\n{uploaded} uploaded, {failed} failed")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
