from urllib.parse import urlparse

DEFAULT_BASE_URL = "https://turoeducate.turocrates.ai"

WSI_EXTENSIONS = {".svs", ".tif", ".tiff", ".ndpi", ".scn", ".mrxs", ".bif"}

UPLOAD_CHUNK_BYTES = 8 * 1024 * 1024
HTTP_TIMEOUT = 60
UPLOAD_TIMEOUT = 60 * 60


def validate_base_url(url: str) -> str:
    url = url.rstrip("/")
    parsed = urlparse(url)
    if parsed.scheme == "https":
        return url
    if parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1"}:
        return url
    raise ValueError(
        f"Base URL must use https:// (got {url!r}). "
        "http:// is only allowed for localhost during local testing."
    )
