from __future__ import annotations

from typing import Optional

import requests

from .config import HTTP_TIMEOUT


class TuroClientError(Exception):
    """Raised for any non-2xx server response. Carries status + sanitized detail."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")


def _extract_detail(response: requests.Response) -> str:
    try:
        body = response.json()
    except ValueError:
        return response.reason or "unknown error"
    if isinstance(body, dict):
        detail = body.get("detail")
        if isinstance(detail, str):
            return detail
        if isinstance(detail, list) and detail:
            first = detail[0]
            if isinstance(first, dict) and first.get("msg"):
                return str(first["msg"])
        if "message" in body and isinstance(body["message"], str):
            return body["message"]
    return response.reason or "unknown error"


class TuroClient:
    """Thin HTTP client for TuroEducate. Token lives in memory only."""

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._token: Optional[str] = None

    def login(self, username: str, password: str) -> dict:
        resp = self._session.post(
            f"{self.base_url}/api/v1/auth/login",
            json={"username": username, "password": password},
            timeout=HTTP_TIMEOUT,
        )
        if resp.status_code == 429:
            raise TuroClientError(429, "too many login attempts, try again in a minute")
        if resp.status_code == 401:
            raise TuroClientError(401, "invalid credentials")
        if not resp.ok:
            raise TuroClientError(resp.status_code, _extract_detail(resp))
        body = resp.json()
        self._token = body["access_token"]
        return body.get("user", {})

    def _auth_headers(self) -> dict:
        if not self._token:
            raise RuntimeError("login() must be called before authenticated requests")
        return {"Authorization": f"Bearer {self._token}"}

    def get_presigned_upload_url(self, filename: str) -> dict:
        resp = self._session.post(
            f"{self.base_url}/api/v1/slides/presigned-upload-url",
            json={"filename": filename, "content_type": "application/octet-stream"},
            headers=self._auth_headers(),
            timeout=HTTP_TIMEOUT,
        )
        if not resp.ok:
            raise TuroClientError(resp.status_code, _extract_detail(resp))
        return resp.json()

    def confirm_upload(
        self,
        *,
        s3_key: str,
        bucket: str,
        filename: str,
        file_size: int,
        name: Optional[str] = None,
    ) -> dict:
        payload = {
            "s3_key": s3_key,
            "bucket": bucket,
            "filename": filename,
            "file_size": file_size,
        }
        if name:
            payload["name"] = name
        resp = self._session.post(
            f"{self.base_url}/api/v1/slides/confirm-upload",
            json=payload,
            headers=self._auth_headers(),
            timeout=HTTP_TIMEOUT,
        )
        if not resp.ok:
            raise TuroClientError(resp.status_code, _extract_detail(resp))
        return resp.json()

    def create_case(
        self,
        *,
        title: str,
        primary_slide_id: str,
        folder_id: Optional[str] = None,
        difficulty: str = "medium",
        status: str = "draft",
        visibility: str = "private",
    ) -> dict:
        payload = {
            "title": title,
            "primary_slide_id": primary_slide_id,
            "difficulty": difficulty,
            "status": status,
            "visibility": visibility,
        }
        if folder_id:
            payload["folder_id"] = folder_id
        resp = self._session.post(
            f"{self.base_url}/api/v1/cases",
            json=payload,
            headers=self._auth_headers(),
            timeout=HTTP_TIMEOUT,
        )
        if not resp.ok:
            raise TuroClientError(resp.status_code, _extract_detail(resp))
        return resp.json()
