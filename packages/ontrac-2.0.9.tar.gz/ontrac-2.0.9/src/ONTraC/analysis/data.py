"""This module defines the AnaData class and related functions to create it from ONTraC results."""

import os
from optparse import Values
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd
from pandas import DataFrame

from ..log import info, warning
from ..utils import get_meta_data_file, get_rel_params, read_yaml_file


# ----------------------------
# Misc Functions
# ----------------------------
def load_loss_record_data(options) -> Optional[Dict]:
    """
        Parse the log file and save the training loss to a csv file.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Dict
        {'loss_df': DataFrame, 'loss_dict': Dict} or None
            loss_df is the training loss DataFrame
            loss_dict is the final loss dictionary

        loss record example:
    16
        31:47 --- INFO: epoch: 1, batch: 1, loss: 8.55, spectral_loss: -6.65e-06, cluster_loss: 0.07
    """
    loss, loss_name = [], []  # type: ignore
    if options.log is None:
        return None
    with open(options.log, "r") as fhd:
        for line in fhd:  # type: ignore
            # train loss record
            if "INFO" in line and "epoch" in line and "loss" in line:
                loss_ = []
                loss_name = []
                line: list[str] = line.strip().split()  # type: ignore
                init_index = line.index("loss:")  # get the first loss index
                # get loss name & losss
                for i in range(init_index, len(line), 2):  # loss name
                    loss_name.append(line[i].strip(":"))
                for i in range(init_index + 1, len(line), 2):  # loss value
                    loss_.append(float(line[i].strip(",")))
                # insert epoch and batch information
                loss_.insert(0, int(line[init_index - 1].strip(",")))  # batch index
                loss_.insert(0, int(line[init_index - 3].strip(",")))  # epoch index
                loss.append(loss_)
            # eval loss record
            elif "INFO" in line and ("Evaluation loss" in line or "Evaluate loss" in line):
                line = line.strip().split(", ", 1)  # type: ignore
                final_loss_dict: Dict[str, float] = eval(line[1])

    # loss name edit
    loss_name[0] = "total_loss"
    loss_name = ["Epoch", "Batch"] + loss_name[:]

    # save loss to csv
    loss_df = pd.DataFrame(loss, columns=loss_name)
    if options.output is not None:
        loss_df.to_csv(f"{options.output}/train_loss.csv", index=False)

    # calculate epoch loss
    epoch_loss_columns = [col for col in loss_df.columns if "loss" in col]
    epoch_loss_columns.insert(0, "Epoch")
    epoch_loss_df = loss_df[epoch_loss_columns].groupby("Epoch").mean()
    if options.output is not None:
        epoch_loss_df.to_csv(f"{options.output}/train_loss_epoch.csv")

    return {"loss_df": epoch_loss_df, "loss_dict": final_loss_dict}


def load_niche_cluster_connectivity(options: Values) -> Optional[np.ndarray]:
    """
        Load the niche cluster connectivity from the output of GNN.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[np.ndarray]
        the niche cluster connectivity
    """

    if options.GNN_dir is None:
        return None

    niche_cluster_conn_file = f"{options.GNN_dir}/consolidate_out_adj.csv.gz"
    if not os.path.isfile(niche_cluster_conn_file):
        niche_cluster_conn_file = f"{options.GNN_dir}/consolidate_out_adj.csv"
    if not os.path.isfile(niche_cluster_conn_file):  # skip if file not exist
        warning(f"Cannot find niche cluster connectivity file: {niche_cluster_conn_file}.")
        return None

    return np.loadtxt(f"{niche_cluster_conn_file}", delimiter=",")


def load_niche_cluster_score(options: Values) -> Optional[np.ndarray]:
    """
        Load the niche cluster score from the output of NT score.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[np.ndarray]
        the niche cluster score
    """

    if options.NT_dir is None:
        return None

    niche_cluster_score_file = f"{options.NT_dir}/niche_cluster_score.csv.gz"
    if not os.path.isfile(niche_cluster_score_file):
        niche_cluster_score_file = f"{options.NT_dir}/niche_cluster_score.csv"
    if not os.path.isfile(niche_cluster_score_file):  # skip if file not exist
        warning(f"Cannot find niche cluster score file: {niche_cluster_score_file}.")
        return None

    return np.loadtxt(f"{niche_cluster_score_file}", delimiter=",")


def load_niche_level_niche_cluster_assign(options: Values) -> Optional[DataFrame]:
    """
        Load the niche cluster assignment for each niche level.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[DataFrame]
        the niche cluster assignment for each niche level
    """

    if options.GNN_dir is None:
        return None

    niche_level_niche_cluster_assign_file = f"{options.GNN_dir}/niche_level_niche_cluster.csv.gz"
    if not os.path.isfile(niche_level_niche_cluster_assign_file):
        niche_level_niche_cluster_assign_file = f"{options.GNN_dir}/niche_level_niche_cluster.csv"
    if not os.path.isfile(niche_level_niche_cluster_assign_file):  # skip if file not exist
        warning(f"Cannot find niche level niche cluster assign file: {niche_level_niche_cluster_assign_file}.")
        return None

    return pd.read_csv(niche_level_niche_cluster_assign_file, index_col=0)


def load_cell_level_niche_cluster_assign(options: Values) -> Optional[DataFrame]:
    """
        Load the niche cluster assignment for each cell level.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[DataFrame]
        the niche cluster assignment for each cell level
    """

    if options.GNN_dir is None:
        return None

    cell_level_niche_cluster_assign_file = f"{options.GNN_dir}/cell_level_niche_cluster.csv.gz"
    if not os.path.isfile(cell_level_niche_cluster_assign_file):
        cell_level_niche_cluster_assign_file = f"{options.GNN_dir}/cell_level_niche_cluster.csv"
    if not os.path.isfile(cell_level_niche_cluster_assign_file):  # skip if file not exist
        warning(f"Cannot find cell level niche cluster assign file: {cell_level_niche_cluster_assign_file}.")
        return None

    return pd.read_csv(cell_level_niche_cluster_assign_file, index_col=0)


def load_niche_level_max_niche_cluster(options: Values) -> Optional[DataFrame]:
    """
        Load the max niche cluster assignment for each niche level.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[DataFrame]
        the max niche cluster assignment for each niche level
    """

    if options.GNN_dir is None:
        return None

    niche_level_max_niche_cluster_file = f"{options.GNN_dir}/niche_level_max_niche_cluster.csv.gz"
    if not os.path.isfile(niche_level_max_niche_cluster_file):
        niche_level_max_niche_cluster_file = f"{options.GNN_dir}/niche_level_max_niche_cluster.csv"
    if not os.path.isfile(niche_level_max_niche_cluster_file):  # skip if file not exist
        warning(f"Cannot find niche level max niche cluster file: {niche_level_max_niche_cluster_file}.")
        return None

    return pd.read_csv(niche_level_max_niche_cluster_file, index_col=0)


def load_cell_level_max_niche_cluster(options: Values) -> Optional[DataFrame]:
    """
        Load the max niche cluster assignment for each cell level.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[DataFrame]
        the max niche cluster assignment for each cell level
    """

    if options.GNN_dir is None:
        return None

    cell_level_max_niche_cluster_file = f"{options.GNN_dir}/cell_level_max_niche_cluster.csv.gz"
    if not os.path.isfile(cell_level_max_niche_cluster_file):
        cell_level_max_niche_cluster_file = f"{options.GNN_dir}/cell_level_max_niche_cluster.csv"
    if not os.path.isfile(cell_level_max_niche_cluster_file):  # skip if file not exist
        warning(f"Cannot find cell level max niche cluster file: {cell_level_max_niche_cluster_file}.")
        return None

    return pd.read_csv(cell_level_max_niche_cluster_file, index_col=0)


def load_niche_hidden_features(options: Values) -> Optional[np.ndarray]:
    """
        Load the niche hidden features.
    Parameters
    ----------
    options :
        Values, the options from optparse
    Returns
    -------
    Optional[np.ndarray]
        the niche hidden features
    """

    if options.NT_dir is None:
        return None

    niche_hidden_features_file = f"{options.NT_dir}/niche_hidden_features.csv.gz"
    if not os.path.isfile(niche_hidden_features_file):
        niche_hidden_features_file = f"{options.NT_dir}/niche_hidden_features.csv"
    if not os.path.isfile(niche_hidden_features_file):  # skip if file not exist
        warning(f"Cannot find niche hidden features file: {niche_hidden_features_file}.")
        return None

    return np.loadtxt(f"{niche_hidden_features_file}", delimiter=",")


# ----------------------------
# Classes
# ----------------------------


class AnaData:
    """Lazy-loading analysis container for ONTraC outputs.

    ``AnaData`` centralizes metadata and downstream artifacts generated by
    preprocessing (`NN_dir`), graph clustering (`GNN_dir`), and niche trajectory
    scoring (`NT_dir`). Expensive tables are loaded on first access via
    properties, which keeps command-line visualization pipelines lightweight.
    """

    def __init__(self, options: Values) -> None:
        """Initialize an analysis object from parsed CLI options.

                Parameters
                ----------
        options :
            Values
                    Parsed options object that may include ``NN_dir``, ``GNN_dir``,
                    ``NT_dir``, and optional visualization flags.
        """

        # save options
        self.options = options

        # meta_data_df
        if getattr(self.options, "NN_dir", None) is not None:

            # get real path
            params = read_yaml_file(f"{options.NN_dir}/samples.yaml")
            self.rel_params = get_rel_params(options.NN_dir, params)
            # load meta data
            self.meta_data_df = pd.read_csv(get_meta_data_file(options.NN_dir))
        else:  # not NN_dir, only support for visualization of meta_input
            self.meta_data_df = pd.read_csv(self.options.meta_input)

        # ID name check
        if self.meta_data_df.columns[0] == "Cell_ID":
            self.meta_data_df = self.meta_data_df.set_index("Cell_ID")
            self.options.spatial_res = "cell"
            info(message="Cell level meta data loaded.")
            if "Cell_Type" in self.meta_data_df.columns:
                # make the Cell_Type column categorical
                # the order of categories is the same as the order of appearance in the cell_type_codes
                self.meta_data_df["Cell_Type"] = self.meta_data_df["Cell_Type"].astype("category")
        elif self.meta_data_df.columns[0] == "Spot_ID":
            self.meta_data_df = self.meta_data_df.set_index("Spot_ID")
            self.options.spatial_res = "spot"
            info(message="Spot level meta data loaded.")
        else:
            raise ValueError("ID name in meta-data input should be either Cell_ID or Spot_ID.")

        # make the Sample column categorical
        self.meta_data_df["Sample"] = self.meta_data_df["Sample"].astype("str").astype("category")

    @property
    def train_loss(self):
        """Load and cache training-loss summaries parsed from log files.

        Returns
        -------
        dict or None
            Dictionary with ``loss_df`` and ``loss_dict`` keys when a log file is
            available; otherwise ``None``.
        """
        if getattr(self, "_train_loss", None) is None:
            self._train_loss = load_loss_record_data(self.options)
        return self._train_loss

    @property
    def umap_embedding(self) -> Optional[np.ndarray]:
        """Return the 2D UMAP embedding saved by preprocessing.

        Returns
        -------
        np.ndarray or None
            Array of shape ``(n_cells, 2)`` if ``UMAP_embedding.csv`` exists,
            else ``None``.
        """
        if getattr(self, "_umap_embedding", None) is None:  # type: ignore
            if not os.path.isfile(f"{self.options.NN_dir}/UMAP_embedding.csv"):
                warning(
                    "UMAP_embedding.csv are required for clustering visualization. Skip the clustering visualization."
                )
                self._umap_embedding = None
            else:
                self._umap_embedding = np.loadtxt(f"{self.options.NN_dir}/UMAP_embedding.csv", delimiter=",")
        return self._umap_embedding

    @property
    def cell_type_codes(self) -> DataFrame:
        """Load mapping from integer code to cell-type name.

        Returns
        -------
        DataFrame
            Table from ``cell_type_code.csv`` with a ``Cell_Type`` column.
        """
        if getattr(self, "_cell_type_codes", None) is None:  # type: ignore
            self._cell_type_codes = pd.read_csv(f"{self.options.NN_dir}/cell_type_code.csv", index_col=0)
            # order the cell type in meta_data_df
            if "Cell_Type" in self.meta_data_df.columns:
                self.meta_data_df["Cell_Type"] = pd.Categorical(
                    self.meta_data_df["Cell_Type"], categories=self._cell_type_codes["Cell_Type"].tolist()
                )
        return self._cell_type_codes

    @property
    def cell_type_coding(self) -> np.ndarray:
        """Load one-hot-like cell-type coding matrix.

        Returns
        -------
        np.ndarray
            Matrix with shape ``(n_cells_or_spots, n_cell_types)``.
        """
        if getattr(self, "_cell_type_coding", None) is None:
            self._cell_type_coding = pd.read_csv(f"{self.options.NN_dir}/ct_coding.csv", index_col=0).values
        return self._cell_type_coding

    def _load_cell_type_composition(self) -> None:
        """Load per-cell (or per-spot) cell-type composition across all samples.

        This internal helper concatenates per-sample feature matrices, aligns
        them to ``meta_data_df`` ordering, and optionally loads raw and adjusted
        matrices when embedding adjustment is enabled.
        """
        data_df_list, data_2_df_list = [], []  # cell type composition, raw cell type composition
        for sample in self.rel_params["Data"]:
            # cell type composition
            cell_type_composition_df = pd.read_csv(sample["Features"], header=None)
            cell_type_composition_df.columns = self.cell_type_codes.loc[
                np.arange(cell_type_composition_df.shape[1]), "Cell_Type"
            ].tolist()
            sample_df = cell_type_composition_df
            # add index (cell ID)
            coordinates_df = pd.read_csv(sample["Coordinates"], index_col=0)
            sample_df.index = coordinates_df.index
            sample_df["Sample"] = [sample["Name"]] * sample_df.shape[0]
            data_df_list.append(sample_df)

            # raw cell type composition
            if not self.options.embedding_adjust:
                continue
            feature_file = Path(sample["Name"] + "_Raw_CellTypeComposition.csv.gz")
            feature_file = Path(sample["Features"]).parent.joinpath(feature_file)
            if not feature_file.is_file():
                warning(
                    f"Cannot find raw cell type composition file: {feature_file}. Skipping raw composition load."
                )
                continue
            cell_type_composition_df = pd.read_csv(feature_file, header=None)
            cell_type_composition_df.columns = self.cell_type_codes.loc[
                np.arange(cell_type_composition_df.shape[1]), "Cell_Type"
            ].tolist()
            sample_df = cell_type_composition_df
            sample_df.index = coordinates_df.index
            sample_df["Sample"] = [sample["Name"]] * sample_df.shape[0]
            data_2_df_list.append(sample_df)

        data_df = pd.concat(data_df_list)
        if data_df.shape[0] == self.meta_data_df.shape[0]:  # number of niche consistency check
            if self.options.embedding_adjust:  # adjust cell type composition
                data_2_df = pd.concat(data_2_df_list)
                if data_2_df.shape[0] == self.meta_data_df.shape[0]:  # number of niche consistency check
                    self._adjust_cell_type_composition = data_df[
                        self.cell_type_codes["Cell_Type"].tolist() + ["Sample"]
                    ].loc[self.meta_data_df.index]
                    self._cell_type_composition = data_2_df[
                        self.cell_type_codes["Cell_Type"].tolist() + ["Sample"]
                    ].loc[self.meta_data_df.index]
                else:
                    raise ValueError(
                        "Adjusted cell type composition rows "
                        f"({data_2_df.shape[0]}) do not match meta data rows ({self.meta_data_df.shape[0]})."
                    )
            else:  # no adjust cell type composition
                self._cell_type_composition = data_df[self.cell_type_codes["Cell_Type"].tolist() + ["Sample"]].loc[
                    self.meta_data_df.index
                ]
        else:
            raise ValueError(
                "Cell type composition rows "
                f"({data_df.shape[0]}) do not match meta data rows ({self.meta_data_df.shape[0]})."
            )

    @property
    def cell_type_composition(self) -> DataFrame:
        """Return the (possibly raw) cell-type composition matrix.

        Returns
        -------
        DataFrame
            Cell/spot-by-cell-type matrix with an additional ``Sample`` column.
        """
        if getattr(self, "_cell_type_composition", None) is None:
            self._load_cell_type_composition()
        return self._cell_type_composition

    def _load_NT_score(self) -> Optional[DataFrame]:
        """Load and align NT scores to metadata index.

        Returns
        -------
        DataFrame or None
            NT score table indexed like ``meta_data_df`` when available.
        """
        if self.options.NT_dir is None:
            return None
        if not os.path.isfile(f"{self.options.NT_dir}/NTScore.csv.gz"):
            warning(f"Cannot find NT score file: {self.options.NT_dir}/NTScore.csv.gz.")
            return None
        NTScore_df = pd.read_csv(f"{self.options.NT_dir}/NTScore.csv.gz", index_col=0)
        return NTScore_df.loc[self.meta_data_df.index]

    @property
    def adjust_cell_type_composition(self) -> DataFrame:
        """Return embedding-adjusted cell-type composition.

        Returns
        -------
        DataFrame
            Adjusted composition matrix aligned to metadata order.
        """
        if not self.options.embedding_adjust:
            warning("The embedding adjust is not enabled. Skip the adjust cell type composition loading.")
        if getattr(self, "_adjust_cell_type_composition", None) is None:
            self._load_cell_type_composition()
        return self._adjust_cell_type_composition

    @property
    def ct_embedding(self) -> Optional[DataFrame]:
        """Load cell-type embedding used for composition adjustment.

        Returns
        -------
        DataFrame or None
            Cell-type embedding table, or ``None`` if the file is absent.
        """
        if getattr(self, "_ct_embedding", None) is None:  # type: ignore
            if not os.path.isfile(f"{self.options.NN_dir}/ct_embedding.csv"):
                warning(f"Cannot find cell type embedding file: {self.options.NN_dir}/ct_embedding.csv.")
                return None
            self._ct_embedding = pd.read_csv(f"{self.options.NN_dir}/ct_embedding.csv", index_col=0)
        return self._ct_embedding

    @property
    def NT_score(self) -> Optional[DataFrame]:
        """Return cached NT score table."""
        if getattr(self, "_NT_score", None) is None:  # type: ignore
            self._NT_score = self._load_NT_score()
        return self._NT_score

    @property
    def niche_cluster_connectivity(self) -> Optional[np.ndarray]:
        """Return niche-cluster connectivity matrix from GNN output."""
        if getattr(self, "_niche_cluster_connectivity", None) is None:  # type: ignore
            self._niche_cluster_connectivity = load_niche_cluster_connectivity(self.options)
        return self._niche_cluster_connectivity

    @property
    def niche_cluster_score(self) -> Optional[np.ndarray]:
        """Return niche-cluster trajectory scores from NT output."""
        if getattr(self, "_niche_cluster_score", None) is None:  # type: ignore
            self._niche_cluster_score = load_niche_cluster_score(self.options)
        return self._niche_cluster_score

    @property
    def niche_level_niche_cluster_assign(self) -> Optional[DataFrame]:
        """Load niche-cluster assignments at niche level and align by index."""
        if getattr(self, "_niche_level_niche_cluster_assign", None) is None:  # type: ignore
            self._niche_level_niche_cluster_assign = load_niche_level_niche_cluster_assign(self.options)
            if self._niche_level_niche_cluster_assign is None:
                return None
            try:
                self._niche_level_niche_cluster_assign = self._niche_level_niche_cluster_assign.loc[
                    self.meta_data_df.index
                ]
            except:
                pass
        return self._niche_level_niche_cluster_assign

    @property
    def cell_level_niche_cluster_assign(self) -> Optional[DataFrame]:
        """Load niche-cluster assignments at cell level and align by index."""
        if getattr(self, "_cell_level_niche_cluster_assign", None) is None:  # type: ignore
            self._cell_level_niche_cluster_assign = load_cell_level_niche_cluster_assign(self.options)
            if self._cell_level_niche_cluster_assign is None:
                return None
            try:
                self._cell_level_niche_cluster_assign = self._cell_level_niche_cluster_assign.loc[
                    self.meta_data_df.index
                ]
            except:
                pass
        return self._cell_level_niche_cluster_assign

    @property
    def niche_level_max_niche_cluster(self) -> Optional[DataFrame]:
        """Load most-likely niche cluster at niche level."""
        if getattr(self, "_niche_level_max_niche_cluster", None) is None:  # type: ignore
            self._niche_level_max_niche_cluster = load_niche_level_max_niche_cluster(self.options)
            if self._niche_level_max_niche_cluster is None:
                return None
            try:
                self._niche_level_max_niche_cluster = self._niche_level_max_niche_cluster.loc[self.meta_data_df.index]
            except:
                pass
        return self._niche_level_max_niche_cluster

    @property
    def cell_level_max_niche_cluster(self) -> Optional[DataFrame]:
        """Load most-likely niche cluster at cell level."""
        if getattr(self, "_cell_level_max_niche_cluster", None) is None:  # type: ignore
            self._cell_level_max_niche_cluster = load_cell_level_max_niche_cluster(self.options)
            if self._cell_level_max_niche_cluster is None:
                return None
            try:
                self._cell_level_max_niche_cluster = self._cell_level_max_niche_cluster.loc[self.meta_data_df.index]
            except:
                pass
        return self._cell_level_max_niche_cluster

    @property
    def niche_hidden_features(self) -> Optional[np.ndarray]:
        """Load hidden feature representation for each niche."""
        if getattr(self, "_niche_hidden_features", None) is None:  # type: ignore
            self._niche_hidden_features = load_niche_hidden_features(self.options)
            if self._niche_hidden_features is None:
                return None
            try:
                self._niche_hidden_features = self._niche_hidden_features[self.meta_data_df.index]
            except:
                pass
        return self._niche_hidden_features
