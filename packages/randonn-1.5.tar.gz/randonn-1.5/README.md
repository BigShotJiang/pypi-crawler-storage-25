Package Name: randonn

Command to install:
pip install randonn

Use this Command to build:
python setup.py sdist bdist_wheel # To build

Use this Command to install locally for testing:
pip install .\dist\matplotib-0.4-py3-none-any.whl # To install locally(version vary according to build)

Use this command to upload to PyPi:
twine upload dist/*

API Token:

pypi-AgEIcHlwaS5vcmcCJDZjNWNmODc4LWJkMmItNDgxYy05NGM4LWNhNDBmNjU3ZWM2OAACD1sxLFsicmFuZG9ubiJdXQACLFsyLFsiZGNjZTJkMDktODlkZS00YjM4LTljMDEtYzAyZTdjMzE1N2ZkIl1dAAAGIIeAqSLZhJKXKR7qoMm5sPsMfS2jtt1xsmQdBJj4sRQ8