# dl.py

def dl_help():
    print(
        '''
    Welcome to the Deep Learning Practicals CLI! 🧠

    This tool allows you to print the code for various deep learning practicals.
    Run any command from your terminal or call its function in Python.

    =========================
    == General Commands    ==
    =========================
    
    Command: dl-help
    Function: dl_help()
    Description: Shows this help message.

    Command: dl-index
    Function: dl_index()
    Description: Displays the full list of deep learning practicals.

    =========================
    == Practical Commands  ==
    =========================

    --- Practical 1: TensorFlow Fundamentals ---
    dl-prac-1a      (dl_prac_1a)
    dl-prac-1b      (dl_prac_1b)

    --- Practical 2: Linear Regression ---
    dl-prac-2       (dl_prac_2)

    --- Practical 3: CNN Classification ---
    dl-prac-3       (dl_prac_3)

    --- Practical 4: Multi-class Classification ---
    dl-prac-4       (dl_prac_4)

    --- Practical 5: Image Captioning ---
    dl-prac-5       (dl_prac_5)

    --- Practical 6: Autoencoders ---
    dl-prac-6       (dl_prac_6)

    --- Practical 7: Character Recognition ---
    dl-prac-7       (dl_prac_7)

    --- Practical 8: Stock Price Prediction ---
    dl-prac-8       (dl_prac_8)

    --- Practical 9: Generative Adversarial Networks ---
    dl-prac-9       (dl_prac_9)
        '''
    )

def dl_index():
    print(
        '''
Deep Learning Practicals:

1.  TensorFlow Fundamentals
    A. Tensor Operations and Basic TensorFlow
    B. XOR Problem with Deep Neural Network

2.  Linear Regression
    Implement linear regression using TensorFlow/Keras

3.  CNN Classification
    Binary classification using Convolutional Neural Networks

4.  Multi-class Classification
    Iris dataset classification with neural networks

5.  Image Captioning
    Predict a caption for a sample image using LSTM

6.  Autoencoders
    Applying Autoencoder algorithms using MNIST Handwritten Digits

7.  Character Recognition
    Character recognition using RNN and comparison with CNN

8.  Stock Price Prediction
    RNN for sequence analysis using Google stock price

9.  Generative Adversarial Networks
    Applying GANs for image generation and unsupervised tasks
        '''
    )

def dl_prac_1a():
    print(
        '''
# Tensor Operations and Basic TensorFlow

import tensorflow as tf

# a. Create tensors with different shapes and data types
# Scalar
scalar = tf.constant(10)
print("Scalar:", scalar)

# Vector
vector = tf.constant([1, 2, 3], dtype=tf.int32)
print("Vector:", vector)

# Matrix
matrix = tf.constant([[1, 2], [3, 4]], dtype=tf.float32)
print("Matrix:\\n", matrix)

# 3D Tensor
tensor_3d = tf.constant([
    [[1, 2], [3, 4]],
    [[5, 6], [7, 8]]
], dtype=tf.float64)
print("3D Tensor:\\n", tensor_3d)

# b. Basic operations on tensors
a = tf.constant([10, 20, 30])
b = tf.constant([1, 2, 3])

print("Addition:", tf.add(a, b))
print("Subtraction:", tf.subtract(a, b))
print("Multiplication:", tf.multiply(a, b))
print("Division:", tf.divide(a, b))

# c. Reshape, slice, and index tensors
tensor = tf.constant([1, 2, 3, 4, 5, 6])

# Reshape
reshaped = tf.reshape(tensor, (2, 3))
print("Reshaped Tensor:\\n", reshaped)

# Indexing
print("Element at index 2:", tensor[2])

# Slicing
print("Slice (index 1 to 4):", tensor[1:5])

# d. Matrix multiplication and Eigenvalues/Eigenvectors
# Matrix multiplication
mat1 = tf.constant([[1, 2], [3, 4]], dtype=tf.float32)
mat2 = tf.constant([[5, 6], [7, 8]], dtype=tf.float32)

matmul_result = tf.matmul(mat1, mat2)
print("Matrix Multiplication Result:\\n", matmul_result)

# Eigenvalues and Eigenvectors
square_matrix = tf.constant([[4, -2], [1, 1]], dtype=tf.float32)

eigenvalues, eigenvectors = tf.linalg.eig(square_matrix)

print("Eigenvalues:\\n", eigenvalues)
print("Eigenvectors:\\n", eigenvectors)
        '''
    )

def dl_prac_1b():
    print(
        '''
# XOR Problem with Deep Neural Network

import numpy as np 
from tensorflow.keras import layers, models
from tensorflow.keras.optimizers import Adam 

# XOR dataset 
X = np.array([[0,0],[0,1],[1,0],[1,1]], dtype=np.float32) 
y = np.array([[0],[1],[1],[0]], dtype=np.float32) 

# Optimized deep forward network 
model = models.Sequential([ 
    layers.Dense(8, input_dim=2, activation='relu'),   #Hidden Layer 1 
    layers.Dense(8, activation='relu'),                #Hidden Layer 2 
    layers.Dense(1, activation='sigmoid')              #Output layer 
]) 

# Compile model  
model.compile(optimizer=Adam(learning_rate=0.01), loss='binary_crossentropy', metrics=['accuracy']) 

# Train the model 
model.fit(X, y, epochs=500, verbose=1) 

# Evaluate 
loss, accuracy = model.evaluate(X, y) 
print(f"Accuracy: {accuracy*100:.2f}%") 

# Predictions 
predictions = model.predict(X) 
print("Predictions:\\n", np.round(predictions).astype(int))
        '''
    )

def dl_prac_2():
    print(
        '''
# Linear Regression using TensorFlow/Keras

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import models, layers
from tensorflow.keras.optimizers import Adam

# Data
X = np.array([5, 7, 9, 11, 13, 15], dtype=np.float32)
y = np.array([15, 21, 27, 33, 39, 45], dtype=np.float32)

# Model
model = models.Sequential([
    layers.Dense(1, input_shape=(1,))
])

model.compile(optimizer=Adam(0.01), loss="mse")

# Train
history = model.fit(X, y, epochs=300, verbose=0)

# Loss curve
plt.plot(history.history["loss"])
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Training Loss")
plt.show()

# Regression line
pred = model.predict(X)

plt.scatter(X, y, label="Actual")
plt.plot(X, pred, color="red", label="Prediction")
plt.xlabel("Square Footage (100 sq.ft)")
plt.ylabel("Price (Lakhs)")
plt.legend()
plt.show()

# Predictions
new_X = np.array([8, 12, 16], dtype=np.float32)
new_pred = model.predict(new_X)

for x, p in zip(new_X, new_pred):
    print(f"{x*100:.0f} sq.ft → {p[0]:.2f} Lakhs")
        '''
    )

def dl_prac_3():
    print(
        '''
# Binary Classification using CNN

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import models, layers
from tensorflow.keras.datasets import cifar10

# Load data
(X_train, y_train), (X_test, y_test) = cifar10.load_data()

# Binary labels: Vehicle=0, Animal=1
vehicles = [0, 1, 8, 9]
y_train = np.array([0 if y in vehicles else 1 for y in y_train])
y_test  = np.array([0 if y in vehicles else 1 for y in y_test])

# Normalize images
X_train, X_test = X_train / 255.0, X_test / 255.0

# Model
model = models.Sequential([
    layers.Conv2D(32, 3, activation="relu", input_shape=(32,32,3)),
    layers.MaxPooling2D(),
    layers.Conv2D(64, 3, activation="relu"),
    layers.MaxPooling2D(),
    layers.Flatten(),
    layers.Dense(128, activation="relu"),
    layers.Dense(1, activation="sigmoid")
])

model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

# Train
model.fit(X_train, y_train, epochs=10, batch_size=64, validation_split=0.2)

# Evaluate
loss, acc = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {acc*100:.2f}%")

# Predictions
labels = ["Vehicle", "Animal"]
pred = (model.predict(X_test[:5]) > 0.5).astype(int)

plt.figure(figsize=(10,4))
for i in range(5):
    plt.subplot(1,5,i+1)
    plt.imshow(X_test[i])
    plt.title(labels[pred[i][0]])
    plt.axis("off")
plt.show()
        '''
    )

def dl_prac_4():
    print(
        '''
# Multi-class Classification with Iris Dataset

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from tensorflow.keras import models, layers

# Load data
iris = load_iris()
X, y = iris.data, iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# Model
model = models.Sequential([
    layers.Dense(16, activation="relu", input_shape=(4,)),
    layers.Dense(16, activation="relu"),
    layers.Dense(3, activation="softmax")
])

model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)

# Train
model.fit(X_train, y_train, epochs=100, verbose=0)

# Evaluate
loss, acc = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {acc*100:.2f}%")

# Predict 
sample = np.array([[5.1, 3.5, 1.4, 0.2]])
probs = model.predict(sample)[0]

pred_class = np.argmax(probs)
print("Predicted Class:", iris.target_names[pred_class])

# Visualization
plt.bar(iris.target_names, probs)
plt.ylabel("Probability")
plt.title("Prediction Probabilities")
plt.ylim(0, 1)
plt.show()
        '''
    )

def dl_prac_5():
    print(
        '''
# Image Captioning using LSTM

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.layers import Input, Dense, LSTM, Embedding, Add
from tensorflow.keras.models import Model

# Build simple LSTM caption model
def build_model(vocab_size=5000, max_length=34):
    image_input = Input(shape=(4096,))
    image_features = Dense(256, activation='relu')(image_input)

    text_input = Input(shape=(max_length,))
    text_features = Embedding(vocab_size, 256, mask_zero=True)(text_input)
    text_features = LSTM(256)(text_features)

    merged = Add()([image_features, text_features])
    output = Dense(vocab_size, activation='softmax')(merged)

    return Model(inputs=[image_input, text_input], outputs=output)

# Dummy caption generator
def generate_caption():
    captions = [
        "a dog running in the park",
        "a cat sitting on a couch",
        "people walking on the street"
    ]
    return np.random.choice(captions)

# Show image and caption
def show_caption(image_path):
    img = load_img(image_path)
    caption = generate_caption()

    plt.imshow(img)
    plt.axis("off")
    plt.title(caption)
    plt.show()

    print("Generated Caption:", caption)

# Main
image_path = "E:/College/SEM 4/DL/dog_running1.jpeg"
model = build_model()
show_caption(image_path)
        '''
    )

def dl_prac_6():
    print(
        '''
# Autoencoders using MNIST Handwritten Digits

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense

# Load MNIST dataset
(x_train, _), (x_test, _) = mnist.load_data()

# Normalize values between 0 and 1
x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0

# Flatten 28x28 images into 784 values
x_train = x_train.reshape((len(x_train), 784))
x_test = x_test.reshape((len(x_test), 784))

# Autoencoder architecture
input_img = Input(shape=(784,))
encoded = Dense(64, activation='relu')(input_img)   # Encoder
decoded = Dense(784, activation='sigmoid')(encoded) # Decoder

# Build and compile model
autoencoder = Model(input_img, decoded)
autoencoder.compile(optimizer='adam', loss='binary_crossentropy')

# Train model
autoencoder.fit(
    x_train, x_train,
    epochs=10,
    batch_size=256,
    shuffle=True,
    validation_data=(x_test, x_test)
)

# Predict reconstructed images
decoded_imgs = autoencoder.predict(x_test)

# Display original and reconstructed images
n = 5
plt.figure(figsize=(10, 4))
for i in range(n):
    plt.subplot(2, n, i + 1)
    plt.imshow(x_test[i].reshape(28, 28), cmap='gray')
    plt.axis('off')
    plt.title("Original")

    plt.subplot(2, n, i + 1 + n)
    plt.imshow(decoded_imgs[i].reshape(28, 28), cmap='gray')
    plt.axis('off')
    plt.title("Decoded")

plt.tight_layout()
plt.show()
        '''
    )

def dl_prac_7():
    print(
        '''
# Character Recognition using RNN vs CNN

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import layers, models
from tensorflow.keras.datasets import mnist

# Load dataset
(x_train, y_train), (x_test, y_test) = mnist.load_data()

# Normalize
x_train, x_test = x_train / 255.0, x_test / 255.0

# RNN Model
rnn_model = models.Sequential([
    layers.SimpleRNN(64, input_shape=(28, 28)),
    layers.Dense(10, activation='softmax')
])

rnn_model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
rnn_model.fit(x_train, y_train, epochs=3, validation_data=(x_test, y_test), verbose=1)
rnn_acc = rnn_model.evaluate(x_test, y_test, verbose=0)[1]

# CNN Model
x_train_cnn = x_train.reshape(-1, 28, 28, 1)
x_test_cnn = x_test.reshape(-1, 28, 28, 1)

cnn_model = models.Sequential([
    layers.Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1)),
    layers.MaxPooling2D((2,2)),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')
])

cnn_model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
cnn_model.fit(x_train_cnn, y_train, epochs=3, validation_data=(x_test_cnn, y_test), verbose=1)
cnn_acc = cnn_model.evaluate(x_test_cnn, y_test, verbose=0)[1]

print(f"RNN Accuracy: {rnn_acc:.4f}")
print(f"CNN Accuracy: {cnn_acc:.4f}")

# Visualization
rnn_predictions = rnn_model.predict(x_test[:5])
cnn_predictions = cnn_model.predict(x_test_cnn[:5])

plt.figure(figsize=(12,4))
for i in range(5):
    plt.subplot(1,5,i+1)
    plt.imshow(x_test[i], cmap='gray')
    rnn_pred = np.argmax(rnn_predictions[i])
    cnn_pred = np.argmax(cnn_predictions[i])
    plt.title(f"T:{y_test[i]}\\nR:{rnn_pred} C:{cnn_pred}")
    plt.axis('off')

plt.suptitle("RNN vs CNN Predictions", fontsize=14)
plt.show()
        '''
    )

def dl_prac_8():
    print(
        '''
# Stock Price Prediction using RNN (Google Stock Price)

import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense

# Load data
data = yf.download("GOOGL", start="2015-01-01", end="2023-01-01")
prices = data[['Close']].values

# Scale data
scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(prices)

# Create sequences
X, y = [], []
for i in range(60, len(data_scaled)):
    X.append(data_scaled[i-60:i])
    y.append(data_scaled[i])
X, y = np.array(X), np.array(y)

# Split data
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

# Build model
model = Sequential([
    SimpleRNN(50, input_shape=(60,1)),
    Dense(1)
])

model.compile(optimizer='adam', loss='mse')
model.fit(X_train, y_train, epochs=10, batch_size=32)

# Predict and plot
pred = scaler.inverse_transform(model.predict(X_test))
real = scaler.inverse_transform(y_test)

plt.plot(real, label='Actual')
plt.plot(pred, label='Predicted')
plt.legend()
plt.show()
        '''
    )

def dl_prac_9():
    print(
        '''
# Generative Adversarial Networks (GAN) for Image Generation

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import layers, Sequential
from tensorflow.keras.datasets import mnist

# Load data (only small subset for speed)
(X, _), _ = mnist.load_data()
X = (X[:10000] / 127.5) - 1
X = X.reshape(-1, 28, 28, 1)

# Generator
G = Sequential([
    layers.Dense(128, activation='relu', input_dim=100),
    layers.Dense(784, activation='tanh'),
    layers.Reshape((28,28,1))
])

# Discriminator
D = Sequential([
    layers.Flatten(input_shape=(28,28,1)),
    layers.Dense(128, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])
D.compile('adam', 'binary_crossentropy')

# GAN
D.trainable = False
GAN = Sequential([G, D])
GAN.compile('adam', 'binary_crossentropy')

# Training
for i in range(2000):
    idx = np.random.randint(0, X.shape[0], 32)
    real = X[idx]

    noise = np.random.normal(0, 1, (32, 100))
    fake = G.predict(noise, verbose=0)

    D.train_on_batch(real, np.ones((32, 1)))
    D.train_on_batch(fake, np.zeros((32, 1)))

    GAN.train_on_batch(np.random.normal(0, 1, (32, 100)), np.ones((32, 1)))

    if i % 200 == 0:
        print("Step:", i)

# Generate one image
img = G.predict(np.random.normal(0, 1, (1, 100)))
plt.imshow(img[0].reshape(28, 28), cmap='gray')
plt.axis('off')
plt.show()
        '''
    )