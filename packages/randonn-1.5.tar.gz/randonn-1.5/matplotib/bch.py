# bch.py

def bch_help():
    print(
        '''
    Welcome to the Blockchain Practicals CLI! ⛓️

    This tool allows you to print the code for various blockchain practicals.
    Run any command from your terminal or call its function in Python.

    =========================
    == General Commands    ==
    =========================
    
    Command: bch-help
    Function: bch_help()
    Description: Shows this help message.

    Command: bch-index
    Function: bch_index()
    Description: Displays the full list of blockchain practicals.

    =========================
    == Practical Commands  ==
    =========================

    --- Practical 1: Blockchain Fundamentals ---
    bch-prac-1a      (bch_prac_1a)
    bch-prac-1b      (bch_prac_1b)
    bch-prac-1c      (bch_prac_1c)
    bch-prac-1d      (bch_prac_1d)

    --- Practical 2: Mining & Bitcoin ---
    bch-prac-2a      (bch_prac_2a)
    bch-prac-2b      (bch_prac_2b)

    --- Practical 3: Solidity ---
    bch-prac-3a      (bch_prac_3a)
    bch-prac-3b      (bch_prac_3b)
    bch-prac-3c      (bch_prac_3c)
    bch-prac-3d      (bch_prac_3d)
    bch-prac-3e      (bch_prac_3e)

    --- Practical 4: NFT ---
    bch-prac-4       (bch_prac_4)
        '''
    )

def bch_index():
    print(
        '''
Blockchain Practicals:

1.  Blockchain Fundamentals
    A. Develop a secure messaging application where users can exchange messages securely using RSA encryption. 
       Implement a mechanism for generating RSA key pairs and encrypting/decrypting messages.
    B. Create a Python class named Transaction with attributes for sender, receiver, and amount. 
       Implement a method within the class to transfer money from the sender's account to the receiver's account.
    C. Allow users to create multiple transactions and display them in an organized format.
    D. Implement a function to add new blocks to the miner and dump the blockchain.

2.  Mining & Bitcoin
    A. Write a python program to demonstrate mining.
    B. Demonstrate the use of the Bitcoin Core API to interact with a Bitcoin Core node.

3.  Solidity
    A. Write a Solidity program that demonstrates various types of functions including regular functions, view functions, pure functions, and the fallback function.
    B. Write a Solidity program that demonstrates function overloading, mathematical functions, and cryptographic functions.
    C. Write a Solidity program that demonstrates various features including contracts, inheritance, constructors, abstract contracts, interfaces.
    D. Write a Solidity program that demonstrates use of libraries, assembly, events, and error handling.
    E. Build a decentralized application (DApp) using Angular for the front end and Truffle along with Ganache CLI for the back end.

4.  NFT
    A. Demonstration on interacting with NFT
        '''
    )

def bch_prac_1a():
    print(
        '''
# Client Identity and RSA Encryption

# Part 1: Client Identity Generation
import binascii  
from Crypto import Random  
from Crypto.PublicKey import RSA  
from Crypto.Signature import PKCS1_v1_5  
from Crypto.Hash import SHA  

class Client: 
    def __init__(self):   
        random = Random.new().read 
        self._private_key = RSA.generate(1024, random) 
        self._public_key = self._private_key.publickey() 
        self._signer = PKCS1_v1_5.new(self._private_key)  

    @property 
    def identity(self): 
        return binascii.hexlify(self._public_key.exportKey(format='DER')).decode('ascii')  

Demo = Client() 
print(Demo.identity)

# Part 2: RSA Encryption/Decryption
import rsa

publickey, privatekey = rsa.newkeys(512)
message = "Hello World"

encMsg = rsa.encrypt(message.encode(), publickey)
print("Original Message:", message)
print("Encrypted Message:", encMsg)

decMsg = rsa.decrypt(encMsg, privatekey).decode()
print("Decrypted Message:", decMsg)
        '''
    )

def bch_prac_1b():
    print(
        '''
# Transaction Creation and Digital Signatures

import binascii
import datetime
import collections
import Crypto
from Crypto import Random
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA

class Client:
    def __init__(self):
        random = Crypto.Random.new().read
        self._private_key = RSA.generate(1024, random)
        self._public_key = self._private_key.publickey()
        self._signer = PKCS1_v1_5.new(self._private_key)

    @property
    def identity(self):
        return binascii.hexlify(self._public_key.exportKey(format='DER')).decode('ascii')

class Transaction:
    def __init__ (self, sender, receiver, amount):
        self.sender = sender
        self.receiver = receiver
        self.amount = amount
        self.time = datetime.datetime.now()

    def to_dict(self):
        if self.sender == "Genesis":
            identity = "Genesis"
        else:
            identity = self.sender.identity

        return collections.OrderedDict({
            'sender': identity,
            'recipient': self.receiver,
            'value': self.amount,
            'time': self.time })

    def sign_transaction(self):
        private_key = self.sender._private_key
        signer = PKCS1_v1_5.new(private_key)
        h = SHA.new(str(self.to_dict()).encode('utf8'))
        return binascii.hexlify(signer.sign(h)).decode('ascii')

def display_transaction(transaction):
    dict = transaction.to_dict()
    print("Sender: " + dict['sender'])
    print("--------------------------")
    print("Receiver: " + dict['recipient'])
    print("--------------------------")
    print("Amount: " + str(dict['value']))
    print("--------------------------")
    print("Time: " + str(dict['time']))
    print("--------------------------")

Bhavesh = Client()
Prabal = Client()
t= Transaction(Prabal, Bhavesh.identity, 2.0)
signature = t.sign_transaction()
print (signature)

print("")
display_transaction(t)
        '''
    )

def bch_prac_1c():
    print(
        '''
# Block Creation and Transaction Management

import binascii
import datetime
import collections
import Crypto
from Crypto import Random
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA

class Client:
    def __init__(self):
        random = Crypto.Random.new().read
        self._private_key = RSA.generate(1024, random)
        self._public_key = self._private_key.publickey()
        self._signer = PKCS1_v1_5.new(self._private_key)

    @property
    def identity(self):
        return binascii.hexlify(self._public_key.exportKey(format='DER')).decode('ascii')  

class Transaction:
    def __init__ (self, sender, receiver, amount):
        self.sender = sender
        self.receiver = receiver
        self.amount = amount
        self.time = datetime.datetime.now()

    def to_dict(self):
        if self.sender == "Genesis":
            identity = "Genesis"
        else:
            identity = self.sender.identity

        return collections.OrderedDict({
            'sender': identity,
            'recipient': self.receiver,
            'value': self.amount,
            'time': self.time })

    def sign_transaction(self):
        private_key = self.sender._private_key
        signer = PKCS1_v1_5.new(private_key)
        h = SHA.new(str(self.to_dict()).encode('utf8'))
        return binascii.hexlify(signer.sign(h)).decode('ascii')

class Block:
    def __init__(self):
        self.verified_transactions = []
        self.previous_block_hash = ""
        self.Nonce = ""
    last_block_hash = ""

def display_transaction(transaction):
    dict = transaction.to_dict()
    print("Sender: " + dict['sender'])
    print("--------------------------")
    print("Receiver: " + dict['recipient'])
    print("--------------------------")
    print("Amount: " + str(dict['value']))
    print("--------------------------")
    print("Time: " + str(dict['time']))
    print("--------------------------")

transactions = []

Avanti = Client()
Tanvii = Client()
Keerr = Client()
Nishta = Client()

t1= Transaction(Avanti, Tanvii.identity, 2.0)
t1.sign_transaction()
transactions.append(t1)

t2= Transaction(Tanvii, Nishta.identity, 1.0)
t2.sign_transaction()
transactions.append(t2)

t3= Transaction(Keerr, Tanvii.identity, 2.0)
t3.sign_transaction()
transactions.append(t3)

t4= Transaction(Tanvii, Avanti.identity, 1.0)
t4.sign_transaction()
transactions.append(t4)

t5= Transaction(Nishta, Tanvii.identity, 2.0)
t5.sign_transaction()
transactions.append(t5)

for trans in transactions:
    display_transaction(trans)
    print("#################################")
        '''
    )

def bch_prac_1d():
    print(
        '''
import hashlib
import datetime

class Block:
    def __init__(self, index, transactions, prev_hash):
        self.index = index
        self.transactions = transactions
        self.timestamp = datetime.datetime.now()
        self.prev_hash = prev_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        data = str(self.index) + str(self.transactions) + str(self.timestamp) + str(self.prev_hash)
        return hashlib.sha256(data.encode()).hexdigest()


class Blockchain:
    def __init__(self):
        self.chain = []
        self.create_genesis_block()

    def create_genesis_block(self):
        genesis = Block(0, ["Genesis Block"], "0")
        self.chain.append(genesis)

    def add_block(self, transactions):
        prev_block = self.chain[-1]
        new_block = Block(len(self.chain), transactions, prev_block.hash)
        self.chain.append(new_block)

    def dump_blockchain(self):
        for block in self.chain:
            print("\\nBlock:", block.index)
            print("Transactions:", block.transactions)
            print("Timestamp:", block.timestamp)
            print("Previous Hash:", block.prev_hash)
            print("Hash:", block.hash)


bc = Blockchain()

bc.add_block(["A pays B 10"])
bc.add_block(["B pays C 5"])
bc.add_block(["C pays D 2"])

bc.dump_blockchain()
        '''
    )

def bch_prac_2a():
    print(
        '''
import hashlib

def sha256(message):
    return hashlib.sha256(message.encode('ascii')).hexdigest()

def mine(message, difficulty=2):
    prefix = '0' * difficulty 
    
    for nonce in range(100000):
        text = message + str(nonce)
        hash_result = sha256(text)
        
        if hash_result.startswith(prefix):
            print("Block mined!")
            print("Message:", message)
            print("Nonce:", nonce)
            print("Hash:", hash_result)
            return hash_result

mine("testmessage", 2)
        '''
    )

def bch_prac_2b():
    print(
        '''
#pip install bitcoinlib

from bitcoinlib.wallets import Wallet 

w = Wallet.create('Wallet3') 
key1 = w.get_key() 
print(key1.address) 

w.scan() 
print(w.info()) 
        '''
    )

def bch_prac_3a():
    print(
        '''
# Regular functions
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract Test {
   function getResult() public pure returns(uint){ 
      uint a = 1; 
      uint b = 2; 
      uint result = a + b; 
      return result; 
   } 
}

# View functions & Pure functions 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract ViewAndPure { 
    uint public x = 1; 

    function addToX(uint y) public view returns (uint) { 
        return x + y; 
    } 

    function add(uint i, uint j) public pure returns (uint) { 
        return i + j; 
    } 
} 

# Fallback function. 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract FallbackExample { 
    event ReceivedEther(address sender, uint amount); 

    receive() external payable { 
        emit ReceivedEther(msg.sender, msg.value); 
    } 

    fallback() external payable { 
        emit ReceivedEther(msg.sender, msg.value); 
    } 

    function getBalance() external view returns (uint) { 
        return address(this).balance; 
    } 
} 
        '''
    )

def bch_prac_3b():
    print(
        '''
# Function overloading 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract Test { 
   function getSum(uint a, uint b) public pure returns(uint){       
      return a + b; 
   } 

   function getSum(uint a, uint b, uint c) public pure returns(uint){       
      return a + b + c; 
   } 

   function callSumWithTwoArguments() public pure returns(uint){ 
      return getSum(1,2); 
   } 

   function callSumWithThreeArguments() public pure returns(uint){ 
      return getSum(1,2,3); 
   } 
} 

# Mathematical functions
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract Test {    
   function callAddMod() public pure returns(uint){ 
      return addmod(4, 5, 3); 
   } 

   function callMulMod() public pure returns(uint){ 
      return mulmod(4, 5, 3); 
   } 
}

# Cryptographic functions 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract Test {    
   function callKeccak256() public pure returns(bytes32 result){ 
      return keccak256("ABC"); 
   }  
} 
        '''
    )

def bch_prac_3c():
    print(
        '''
# Contracts 
// SPDX-License-Identifier: MIT 
pragma solidity ^0.8.3; 

contract Counter { 
    uint public count; 

    function get() public view returns (uint) { 
        return count; 
    } 

    function inc() public { 
        count += 1; 
    } 
  
    function dec() public { 
        count -= 1; 
    } 
} 

# Inheritance
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
 
contract Parent {
    uint public num = 10;
 
    function showValue() public pure returns (string memory) {
        return "This is Parent contract";
    }
}
 
contract Child is Parent {
 
    function getParentValue() public view returns (uint) {
        return num;
    }
 
    function getParentMessage() public pure returns (string memory) {
        return showValue();
    }
}

# Constructors 
// SPDX-License-Identifier: MIT 
pragma solidity ^0.8.3; 

contract ConstructorExample {
 
    uint public value;
 
    constructor(uint _value) {
        value = _value;
    }
 
    function getValue() public view returns (uint) {
        return value;
    }
}

# Abstract contracts
// SPDX-License-Identifier: MIT 
pragma solidity ^0.8.3; 

abstract contract Calculator {
   function getResult() public pure virtual returns(uint);
}

contract Test is Calculator {
   function getResult() public pure override returns(uint) {
      uint a = 1;
      uint b = 2;
      uint result = a + b;
      return result;
   }
}

# Interfaces. 
// SPDX-License-Identifier: MIT 
pragma solidity ^0.8.3; 

interface Calculator {
   function getResult() external pure returns(uint);
}

contract Test is Calculator {
   constructor() {}

   function getResult() external pure override returns(uint) {
      uint a = 1;
      uint b = 2;
      uint result = a + b;
      return result;
   }
}
        '''
    )

def bch_prac_3d():
    print(
        '''
# Libraries 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
 
library MathLibrary {
    function add(uint a, uint b) public pure returns (uint) {
        return a + b;
    }
}
 
contract LibraryExample {
    function getSum() public pure returns (uint) {
        return MathLibrary.add(5, 3);
    }
}

# Assembly 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
 
library MathLibrary {
    function add(uint a, uint b) public pure returns (uint result) {
        assembly {
            result := add(a, b)
        }
    }
}
 
contract LibraryExample {
    function getSum() public pure returns (uint) {
        return MathLibrary.add(5, 3);
    }
}

# Events 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract EventExample {
    event Message(address sender, string text);

    function sendMessage(string memory _text) public {
        emit Message(msg.sender, _text);
    }
}

# Error Handling 
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.3;

contract Vendor {
    address public seller = msg.sender; 

    function sell(uint amount) public payable {
        require(msg.sender == seller, "Not seller");

        if (amount > msg.value / 2 ether) {
            revert("Not enough Ether");
        }
        // sell logic (dummy)
    }
}
        '''
    )

def bch_prac_3e():
    print(
        '''
# Build a DApp using Angular, Truffle and Ganache CLI

# Open CMD as an administrator to run the following commands

# Step 1: Install Node.js and NPM
# Check installation using commands
node -v
npm -v

# Step 2: Install Angular CLI
npm install -g @angular/cli

# Step 3: Install Truffle and Ganache
npm install -g truffle
npm install -g ganache

# Step 4: Install Metamask extension to your browser

# Step 5: Create an Angular Project
ng new angular-dapp
cd angular-dapp

# (*The first command can give an error. You need to set path manually if not added in environment variables.
# Search for C:\\Users\\<YourUsername>\\AppData\\Roaming\\npm\\ng.cmd.
# Add new path to the PATH variable under user variable in Environment Variables
# - C:\\Users\\<YourUsername>\\AppData\\Roaming\\npm)

# Step 6: install web3 library
npm install web3

# Step 7: Create truffle project in Angular dapp directory
truffle init

# Step 8: write a simple smart contract in contracts directory
// SPDX-License-Identifier: MIT 
// contracts/SimpleStorage.sol 
pragma solidity ^0.8.0; 

contract SimpleStorage { 
    uint256 public data; 

    function set(uint256 _data) public { 
        data = _data; 
    } 

    function get() public view returns (uint256) { 
        return data; 
    } 
} 

# Another method to create contracts:
truffle create contract test

# Step 9: Compile to check for any errors
truffle compile

# Step 10: Create a script in the migration directory to deploy the contract
// migrations/2_deploy_contracts.js 
const SimpleStorage = artifacts.require("SimpleStorage"); 

module.exports = function(deployer) { 
  deployer.deploy(SimpleStorage); 
}; 

# Another method to create migrations: 
truffle create migration deploy_contract

# Step 11: Configure the truffle configuration file (truffle-config.js) 
# Remove comments under networks -> development, it should look like 

networks: { 
  development: { 
    host: "127.0.0.1", 
    port: 8545, // needs to be changed as per Ganache 
    network_id: "*", // Use "*" to match any network ID 
  }, 
}

# Step 12: Deploy the contract 
# Open a new command prompt and run the command 
ganache

# On the earlier command prompt run the command
truffle migrate

# Step 13: Connect Angular and Smart Contract 
# Create a service to handle web interactions in the folder src/app/services/web3.service.ts 

// src/app/services/web3.service.ts 
import { Injectable } from '@angular/core'; 
import Web3 from 'web3'; 

declare global { 
  interface Window { 
    ethereum: any; 
  } 
} 

@Injectable({ 
  providedIn: 'root' 
}) 
export class Web3Service { 
  
  private web3!: Web3; 

  constructor() { 
    if (typeof window.ethereum !== 'undefined') { 
      this.web3 = new Web3(window.ethereum); 
      window.ethereum.request({ method: 'eth_requestAccounts' }); 
    } else { 
      console.warn("No web3 detected."); 
      this.web3 = new Web3("http://127.0.0.1:8545"); 
    } 
  } 

  getWeb3() { 
    return this.web3; 
  } 
} 

# Step 14: Create new component SimpleStorage 
ng generate component SimpleStorage 

# Step 15: Add the following code to get and set data from smart contract 
// src/app/simple-storage/simple-storage.component.ts 
import { Component, OnInit } from '@angular/core'; 
import { Web3Service } from '../services/web3.service'; 
import SimpleStorageContract from '../../../build/contracts/SimpleStorage.json'; 

@Component({ 
  selector: 'app-simple-storage', 
  templateUrl: './simple-storage.component.html', 
  styleUrls: [] 
}) 
export class SimpleStorageComponent implements OnInit { 
  private web3: any; 
  private contract: any; 
  public data!: string; 

  constructor(private web3Service: Web3Service) { 
    this.web3 = this.web3Service.getWeb3(); 
  } 

  async ngOnInit() { 
    const networkId = await this.web3.eth.net.getId(); 
    const deployedNetwork = (SimpleStorageContract.networks as any)[networkId]; 
    this.contract = new this.web3.eth.Contract(SimpleStorageContract.abi, deployedNetwork && deployedNetwork.address); 
  } 

  async setData(data: string) { 
    const accounts = await this.web3.eth.getAccounts(); 
    await this.contract.methods.set(data).send({ from: accounts[0] }); 
  } 

  async getData() { 
    const result = await this.contract.methods.get().call(); 
    this.data = result; 
  } 
} 

# Step 16: Update template to bind data in angular 
<!-- src/app/simple-storage/simple-storage.component.html --> 
<div> 
  <h2>Simple Storage</h2> 
  <input #newData type="text" placeholder="Enter data"> 
  <button (click)="setData(newData.value)">Set Data</button> 
  <button (click)="getData()">Get Data</button> 
  <p>Stored Data: {{ data }}</p> 
</div>

# Step 17: Run the angular application 
# Ensure that ganache is running on another command prompt. 
ng serve

# Step 18: Interact with dapp 
# Open browser and navigate to http://localhost:4200
        '''
    )

def bch_prac_4():
    print(
        '''
# Demonstration on interacting with NFT

# Step 1: 
// SPDX-License-Identifier: MIT 
pragma solidity >=0.6.0 <0.8.0; 

import "https://github.com/OpenZeppelin/openzeppelin-contracts/blob/v3.4.0/contracts/presets/ERC721PresetMinterPauserAutoId.sol"; 

# Step 2: Change the Remix compiler to 0.6.2 and Compile the code 

# Step 3: In the Deploy Tab, change the contract to "ERC721PresetMinterPauserAutoID" 
# Then add the following parameters in the Deploy tab to enable Deploying the contract. 

"MyNFT","NFT","https://my-json-server.typicode.com/abcoathup/samplenft/tokens/" 

# Step 4: Deploy the contract 

# Step 5: After Deploying the contract, under Deployed contract interact with the metadata
        '''
    )
