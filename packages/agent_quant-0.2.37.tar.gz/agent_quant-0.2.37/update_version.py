#!/usr/bin/env python3
"""Auto increment version in pyproject.toml"""

import re
import sys
import os

# pyproject.toml 在当前目录下
pyproject_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pyproject.toml')

# 检查文件是否存在
if not os.path.exists(pyproject_path):
    print(f'Error: pyproject.toml not found at {pyproject_path}')
    sys.exit(1)

# Read pyproject.toml
with open(pyproject_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Find and increment version
version_match = re.search(r'version = "(\d+)\.(\d+)\.(\d+)"', content)
if version_match:
    major, minor, patch = map(int, version_match.groups())
    new_version = f'{major}.{minor}.{patch + 1}'
    content = content.replace(
        f'version = "{major}.{minor}.{patch}"',
        f'version = "{new_version}"'
    )
    with open(pyproject_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f'Version updated: {major}.{minor}.{patch} -> {new_version}')
else:
    print('Version not found in pyproject.toml')
    sys.exit(1)
