---
name: "claw-quant"
description: "A-share stock market data management and backtesting. Supports multi-data source (QMT/BaoStock/Tushare), factor analysis, strategy development, and multi-engine backtesting."
---

# 股票数据管理与回测 Skill

## 快速开始

```bash
# 1. 检查环境
doctor

# 2. 启动数据库
db start

# 3. 下载数据（自动选择可用数据源，优先级：QMT > Tushare > BaoStock）
data download --stocks 000001.SZ --start 20240101 --end 20240601

# 4. 查看数据状态
data stats

# 5. 回测策略
strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
```

## 命令概览

| 命令 | 用途 | 查看详情 |
|------|------|----------|
| `doctor` | 系统环境诊断 | `doctor --help` |
| `db start/stop/status` | 数据库服务管理 | `db --help` |
| `data` | 数据管理（下载/查询/维护） | `data --help` |
| `source` | 多数据源管理 | `source --help` |
| `query` | 查询股票历史数据 | `query --help` |
| `factor` | 因子计算与回测 | `factor --help` |
| `strategy` | 策略回测 | `strategy --help` |
| `strategy-dev` | 策略开发工具（无需编码） | `strategy-dev --help` |
| `result` | 回测结果管理 | `result --help` |
| `engines` | 查看可用回测引擎 | `engines --help` |

## 核心功能

### 1. 数据管理
- **多数据源**: QMT、BaoStock（免费）、Tushare（需Token）
- **数据操作**: 下载、查询、导出、扫描修复
- **股票池**: 支持 hs300、sz50、zz500、zz1000、cyb 等预设池

### 2. 因子系统
- **44个内置因子**: 估值/质量/成长/动量/情绪/技术六大类
- **因子回测**: 支持 IC 测试和分层收益测试
- **动态因子**: 支持运行时编译自定义因子

### 3. 策略回测
- **多引擎支持**: local、vnpy、backtrader、CSKhQuant
- **内置策略**: 均线交叉、MACD、RSI、布林带、多因子选股等
- **策略开发工具**: 无需编写代码，通过 CLI 交互创建和优化策略
- **动态策略**: 支持运行时编译自定义策略
- **结果管理**: 列表、查看、对比、HTML报告

**快速创建策略（无需编码）**:
```bash
# 查看可用模板
strategy-dev list-templates

# 交互式创建策略
strategy-dev create --name 我的策略

# 回测策略配置
strategy-dev backtest 我的策略.json --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

# 参数优化
strategy-dev optimize 我的策略.json --param short_window --range 5,30,5
```

### 4. 高级策略开发 API（可选）

如需编写复杂策略，可使用 Python API：

```python
# 技术指标函数
from claw_quant.backtest.indicators import (
    get_data, get_price, has_position, calc_ma, get_history
)

# 交易成本和风险控制
from claw_quant.backtest.cost import TradeCost, RiskControl, TradeMode

# 股票池管理
from claw_quant.backtest.pools import StockPool
```

**注意**: 大多数策略使用 `strategy-dev` CLI 工具即可，无需编写代码。

## 数据源说明

系统支持多数据源，**默认自动选择**，优先级如下：

1. **QMT**（优先）- 需启动国金QMT客户端，数据质量最高
2. **Tushare** - 需配置Token，数据较完整
3. **BaoStock**（免费）- 无需配置，适合入门

### 数据下载方式

**方式1：自动选择（推荐）**
```bash
# 系统自动按优先级尝试可用数据源
data download --stocks 000001.SZ --start 20240101 --end 20240601
```

**方式2：指定数据源**
```bash
# 明确指定使用某个数据源
data download --source qmt --stocks 000001.SZ --start 20240101 --end 20240601
data download --source tushare --stocks 000001.SZ --start 20240101 --end 20240601 --token YOUR_TOKEN
data download --source baostock --stocks 000001.SZ --start 20240101 --end 20240601
```

**反馈信息**：下载完成后会返回 `active_source` 字段，告知实际使用的数据源。

## 典型工作流

### 首次使用
```bash
doctor              # 检查环境
db start            # 启动数据库
data download --stocks 000001.SZ --start 20240101 --end 20240601  # 自动选择数据源
```

### 数据查询
```bash
data stats          # 数据库统计
data info CODE      # 股票详情
query --code CODE   # 历史数据（见 query --help）
```

### 策略回测
```bash
strategy list                       # 查看可用策略
strategy backtest NAME ...          # 回测（见 strategy backtest --help）
result list                         # 查看结果
result report --open                # 生成报告
```

## 获取帮助

所有命令支持 `--help` 查看详细参数：

```bash
# 一级命令帮助
python -m claw_quant.cli data --help
python -m claw_quant.cli strategy --help
python -m claw_quant.cli factor --help

# 子命令帮助
python -m claw_quant.cli data download --help
python -m claw_quant.cli strategy backtest --help
python -m claw_quant.cli factor calc --help
```
