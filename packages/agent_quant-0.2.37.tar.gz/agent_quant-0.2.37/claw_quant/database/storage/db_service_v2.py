"""
DuckDB 数据库服务 V2 - 修复大数据保存问题

改进:
1. 增加消息大小限制到512MB
2. 添加更好的错误处理
3. 大数据分批处理
"""
import socket
import struct
import pickle
import threading
import logging
import signal
import sys
import os
import time
from typing import Optional

from ..db_manager import DuckDBManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger('db_service_v2')

# 默认配置
DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 9528
HEADER_SIZE = 4  # 4字节表示消息长度
MAX_MSG_SIZE = 512 * 1024 * 1024  # 512MB，增加限制


def send_message(sock: socket.socket, data):
    """发送一条消息（长度前缀 + pickle）"""
    payload = pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
    msg_len = len(payload)
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes > {MAX_MSG_SIZE} bytes")
    header = struct.pack('>I', msg_len)
    sock.sendall(header + payload)


def recv_message(sock: socket.socket):
    """接收一条消息"""
    # 读取4字节长度头
    header = _recv_exact(sock, HEADER_SIZE)
    if header is None:
        return None
    msg_len = struct.unpack('>I', header)[0]
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    # 读取消息体
    payload = _recv_exact(sock, msg_len)
    if payload is None:
        return None
    return pickle.loads(payload)


def _recv_exact(sock: socket.socket, n: int) -> Optional[bytes]:
    """精确读取n字节"""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 65536))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


class DBService:
    """数据库服务 V2"""

    def __init__(self, db_path: str, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
        self.db_path = db_path
        self.host = host
        self.port = port
        self.db: Optional[DuckDBManager] = None
        self.server_socket: Optional[socket.socket] = None
        self._running = False
        self._lock = threading.Lock()

    def start(self):
        """启动服务"""
        # 初始化数据库
        self.db = DuckDBManager(self.db_path)
        logger.info(f"数据库已连接: {self.db_path}")

        # 启动TCP服务
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(16)
        self.server_socket.settimeout(1.0)
        self._running = True

        logger.info(f"数据库服务V2已启动: {self.host}:{self.port}")
        logger.info(f"最大消息大小: {MAX_MSG_SIZE / 1024 / 1024}MB")

        # 主循环
        while self._running:
            try:
                client_sock, addr = self.server_socket.accept()
                t = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock, addr),
                    daemon=True
                )
                t.start()
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    logger.error("accept错误", exc_info=True)
                break

    def stop(self):
        """停止服务"""
        logger.info("正在停止服务...")
        self._running = False
        if self.server_socket:
            self.server_socket.close()
        if self.db:
            self.db.close()
        logger.info("服务已停止")

    def _handle_client(self, client_sock: socket.socket, addr):
        """处理客户端连接"""
        logger.debug(f"客户端连接: {addr}")
        try:
            while self._running:
                request = recv_message(client_sock)
                if request is None:
                    break

                method_name, args, kwargs = request
                response = self._execute(method_name, args, kwargs)
                
                try:
                    send_message(client_sock, response)
                except ValueError as e:
                    # 消息过大
                    logger.error(f"响应消息过大: {e}")
                    error_response = {'ok': False, 'error': f'响应数据过大: {e}'}
                    send_message(client_sock, error_response)
                    
        except Exception as e:
            logger.warning(f"客户端 {addr} 处理异常: {e}")
        finally:
            client_sock.close()
            logger.debug(f"客户端断开: {addr}")

    def _execute(self, method_name: str, args: tuple, kwargs: dict) -> dict:
        """执行数据库操作"""
        if method_name == '__ping__':
            return {'ok': True, 'result': 'pong'}

        if not hasattr(self.db, method_name):
            return {'ok': False, 'error': f"方法不存在: {method_name}"}

        if method_name.startswith('_'):
            return {'ok': False, 'error': f"不允许调用私有方法: {method_name}"}

        try:
            with self._lock:
                method = getattr(self.db, method_name)
                
                # 特殊处理：大数据保存分批
                if method_name == 'save_market_data_daily' and args:
                    df = args[0]
                    if len(df) > 1000:
                        # 大数据分批保存
                        return self._save_large_data(df)
                
                result = method(*args, **kwargs)
            return {'ok': True, 'result': result}
        except Exception as e:
            logger.error(f"执行 {method_name} 失败: {e}")
            import traceback
            traceback.print_exc()
            return {'ok': False, 'error': str(e)}

    def _save_large_data(self, df) -> dict:
        """分批保存大数据"""
        try:
            batch_size = 500
            total = len(df)
            saved = 0
            
            for i in range(0, total, batch_size):
                batch = df.iloc[i:i+batch_size]
                self.db.save_market_data_daily(batch)
                saved += len(batch)
                logger.debug(f"分批保存: {saved}/{total}")
            
            return {'ok': True, 'result': None}
        except Exception as e:
            logger.error(f"分批保存失败: {e}")
            return {'ok': False, 'error': str(e)}


def main():
    import argparse
    parser = argparse.ArgumentParser(description='DuckDB 数据库服务 V2')
    parser.add_argument('--db-path', type=str, default='data/quant_system_new.db',
                        help='数据库文件路径')
    parser.add_argument('--host', type=str, default=DEFAULT_HOST,
                        help=f'监听地址 (默认 {DEFAULT_HOST})')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT,
                        help=f'监听端口 (默认 {DEFAULT_PORT})')
    args = parser.parse_args()

    service = DBService(args.db_path, args.host, args.port)

    def on_signal(signum, frame):
        service.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)

    service.start()


if __name__ == '__main__':
    main()
