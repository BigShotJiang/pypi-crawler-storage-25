"""
DuckDB 数据库服务

独立进程运行，持有唯一的DuckDB连接。
其他脚本通过 db_client 连接本服务来访问数据库，避免DuckDB锁冲突。

协议：
  - TCP socket, localhost
  - 消息格式：4字节长度头 + pickle序列化数据
  - 请求：(method_name: str, args: tuple, kwargs: dict)
  - 响应：{'ok': True, 'result': ...} 或 {'ok': False, 'error': str}
  - DataFrame 通过 pickle 传输（仅限本地，无安全风险）
"""

import socket
import struct
import pickle
import threading
import logging
import signal
import sys
import os
import time
from typing import Optional

# 支持直接运行和作为包模块运行
try:
    from .db_manager import DuckDBManager
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from db_manager import DuckDBManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger('db_service')

# 默认配置
DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 9528
HEADER_SIZE = 4  # 4字节表示消息长度
MAX_MSG_SIZE = 256 * 1024 * 1024  # 256MB


def send_message(sock: socket.socket, data):
    """发送一条消息（长度前缀 + pickle）"""
    payload = pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
    header = struct.pack('>I', len(payload))
    sock.sendall(header + payload)


def recv_message(sock: socket.socket):
    """接收一条消息"""
    # 读取4字节长度头
    header = _recv_exact(sock, HEADER_SIZE)
    if header is None:
        return None
    msg_len = struct.unpack('>I', header)[0]
    if msg_len > MAX_MSG_SIZE:
        raise ValueError(f"消息过大: {msg_len} bytes")
    # 读取消息体
    payload = _recv_exact(sock, msg_len)
    if payload is None:
        return None
    return pickle.loads(payload)


def _recv_exact(sock: socket.socket, n: int) -> Optional[bytes]:
    """精确读取n字节"""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


class DBService:
    """数据库服务"""

    def __init__(self, db_path: str, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
        self.db_path = db_path
        self.host = host
        self.port = port
        self.db: Optional[DuckDBManager] = None
        self.server_socket: Optional[socket.socket] = None
        self._running = False
        self._lock = threading.Lock()  # 串行化所有数据库操作

    def start(self):
        """启动服务"""
        # 初始化数据库
        self.db = DuckDBManager(self.db_path)
        logger.info(f"数据库已连接: {self.db_path}")

        # 启动TCP服务
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(16)
        self.server_socket.settimeout(1.0)  # 便于优雅退出
        self._running = True

        logger.info(f"数据库服务已启动: {self.host}:{self.port}")

        # 主循环
        while self._running:
            try:
                client_sock, addr = self.server_socket.accept()
                t = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock, addr),
                    daemon=True
                )
                t.start()
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    logger.error("accept错误", exc_info=True)
                break

    def stop(self):
        """停止服务"""
        logger.info("正在停止服务...")
        self._running = False
        if self.server_socket:
            self.server_socket.close()
        if self.db:
            self.db.close()
        logger.info("服务已停止")

    def _handle_client(self, client_sock: socket.socket, addr):
        """处理客户端连接（长连接，可发送多个请求）"""
        logger.debug(f"客户端连接: {addr}")
        try:
            while self._running:
                request = recv_message(client_sock)
                if request is None:
                    break  # 客户端断开

                method_name, args, kwargs = request
                response = self._execute(method_name, args, kwargs)
                send_message(client_sock, response)
        except Exception as e:
            logger.warning(f"客户端 {addr} 处理异常: {e}")
        finally:
            client_sock.close()
            logger.debug(f"客户端断开: {addr}")

    def _execute(self, method_name: str, args: tuple, kwargs: dict) -> dict:
        """执行数据库操作（加锁串行化）"""
        # 特殊命令
        if method_name == '__ping__':
            return {'ok': True, 'result': 'pong'}
        
        if method_name == '__info__':
            # 返回数据库信息
            import os
            db_path = self.db_path
            result = {
                'db_type': 'DuckDB',
                'db_path': os.path.abspath(db_path),
            }
            # 检查文件是否存在并获取大小
            if os.path.exists(db_path):
                result['db_exists'] = True
                result['db_size_mb'] = round(os.path.getsize(db_path) / (1024 * 1024), 2)
            else:
                result['db_exists'] = False
                result['db_size_mb'] = 0
            return {'ok': True, 'result': result}
        
        if method_name == '__shutdown__':
            # 停止服务
            import threading
            def delayed_stop():
                time.sleep(0.5)  # 给客户端时间接收响应
                self.stop()
            threading.Thread(target=delayed_stop, daemon=True).start()
            return {'ok': True, 'result': {'success': True, 'message': '服务正在停止'}}

        # 检查方法是否存在
        if not hasattr(self.db, method_name):
            return {'ok': False, 'error': f"方法不存在: {method_name}"}

        # 只暴露DuckDBManager的公开方法
        if method_name.startswith('_'):
            return {'ok': False, 'error': f"不允许调用私有方法: {method_name}"}

        try:
            with self._lock:
                method = getattr(self.db, method_name)
                result = method(*args, **kwargs)
            return {'ok': True, 'result': result}
        except Exception as e:
            logger.error(f"执行 {method_name} 失败: {e}")
            return {'ok': False, 'error': str(e)}


def main():
    import argparse
    parser = argparse.ArgumentParser(description='DuckDB 数据库服务')
    parser.add_argument('--db-path', type=str, default=None,
                        help='数据库文件路径 (默认: ~/.claw_quant/data/quant_system.db)')
    parser.add_argument('--host', type=str, default=DEFAULT_HOST,
                        help=f'监听地址 (默认 {DEFAULT_HOST})')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT,
                        help=f'监听端口 (默认 {DEFAULT_PORT})')
    args = parser.parse_args()
    
    # 使用统一的默认路径
    if args.db_path is None:
        home_dir = os.path.expanduser('~')
        claw_quant_dir = os.path.join(home_dir, '.claw_quant', 'data')
        os.makedirs(claw_quant_dir, exist_ok=True)
        args.db_path = os.path.join(claw_quant_dir, 'quant_system.db')
    
    service = DBService(args.db_path, args.host, args.port)

    # 注册信号处理
    def on_signal(signum, frame):
        service.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)

    service.start()


if __name__ == '__main__':
    main()
