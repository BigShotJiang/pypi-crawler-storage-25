# -*- coding: utf-8 -*-
"""
Tushare 数据源实现

提供从 Tushare Pro 获取A股数据的功能
"""

from typing import List, Dict, Optional, Any
from datetime import date, datetime
import pandas as pd
import logging

from .base import BaseDataSource, DataSourceType

logger = logging.getLogger(__name__)


class TushareDataSource(BaseDataSource):
    """
    Tushare 数据源
    
    特点:
    - 数据质量高
    - 更新及时
    - 需要注册获取 Token
    - 有积分限制
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化 Tushare 数据源
        
        Args:
            config: 配置参数
                - token: Tushare Pro Token（必需）
        """
        super().__init__(DataSourceType.TUSHARE, config)
        self.token = config.get('token') if config else None
        self._pro = None
        
    def connect(self) -> bool:
        """
        连接 Tushare
        
        Returns:
            是否连接成功
        """
        if not self.token:
            logger.error("Tushare Token 未配置")
            return False
            
        try:
            import tushare as ts
            
            # 设置 token
            ts.set_token(self.token)
            self._pro = ts.pro_api()
            
            # 测试连接
            df = self._pro.trade_cal(exchange='SSE', limit=1)
            if df is not None:
                self._connected = True
                logger.info("Tushare 连接成功")
                return True
            else:
                logger.error("Tushare 连接测试失败")
                return False
                
        except ImportError:
            logger.error("tushare 未安装，请运行: pip install tushare")
            return False
        except Exception as e:
            logger.error(f"Tushare 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        self._connected = False
        self._pro = None
        logger.info("Tushare 已断开")
    
    def get_stock_list(self, market: str = 'all') -> List[Dict[str, str]]:
        """
        获取股票列表
        
        Args:
            market: 市场类型 ('all', 'sh', 'sz', 'bj')
            
        Returns:
            股票列表
        """
        if not self._connected:
            raise RuntimeError("Tushare 未连接")
            
        try:
            stocks = []
            
            # 获取所有股票基本信息
            df = self._pro.stock_basic(
                exchange='',
                list_status='L',
                fields='ts_code,symbol,name,area,industry,market,exchange'
            )
            
            if df is None or df.empty:
                return []
                
            for _, row in df.iterrows():
                ts_code = row['ts_code']  # 如 '000001.SZ'
                
                # 市场过滤
                if market != 'all':
                    exchange = row['exchange']
                    if market == 'sh' and exchange != 'SSE':
                        continue
                    if market == 'sz' and exchange != 'SZSE':
                        continue
                        
                stocks.append({
                    'code': ts_code,
                    'name': row['name'],
                    'market': row['market'],
                    'area': row['area'],
                    'industry': row['industry']
                })
                
            logger.info(f"获取到 {len(stocks)} 只股票")
            return stocks
            
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")
            return []
    
    def get_daily_data(
        self,
        code: str,
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        获取日线数据
        
        Args:
            code: 股票代码，如 '000001.SZ'
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        if not self._connected:
            raise RuntimeError("Tushare 未连接")
            
        # 验证日期
        valid, msg = self.validate_dates(start_date, end_date)
        if not valid:
            raise ValueError(msg)
            
        try:
            # 转换日期格式
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            # 查询日线数据
            df = self._pro.daily(
                ts_code=code,
                start_date=start_str,
                end_date=end_str
            )
            
            if df is None or df.empty:
                logger.warning(f"{code} 在 {start_str} ~ {end_str} 无数据")
                return pd.DataFrame()
                
            # 重命名列以统一格式
            df = df.rename(columns={
                'ts_code': 'code',
                'trade_date': 'date',
                'vol': 'volume'
            })
            
            # 转换日期格式
            df['date'] = pd.to_datetime(df['date']).dt.date
            
            # 选择需要的列
            df = df[['date', 'open', 'high', 'low', 'close', 'volume', 'amount', 'code']]
            
            # 按日期排序
            df = df.sort_values('date').reset_index(drop=True)
            
            logger.info(f"获取 {code} 数据 {len(df)} 条")
            return df
            
        except Exception as e:
            logger.error(f"获取 {code} 数据失败: {e}")
            raise
    
    def get_daily_data_batch(
        self,
        codes: List[str],
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        批量获取日线数据
        
        Args:
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        all_data = []
        
        for i, code in enumerate(codes):
            try:
                df = self.get_daily_data(code, start_date, end_date)
                if not df.empty:
                    all_data.append(df)
                    
                # Tushare 有频率限制，每200ms一个请求
                import time
                time.sleep(0.2)
                
            except Exception as e:
                logger.warning(f"获取 {code} 失败: {e}")
                continue
                
        if not all_data:
            return pd.DataFrame()
            
        return pd.concat(all_data, ignore_index=True)
    
    def get_trade_dates(
        self,
        start_date: date,
        end_date: date
    ) -> List[date]:
        """
        获取交易日列表
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            交易日列表
        """
        if not self._connected:
            raise RuntimeError("Tushare 未连接")
            
        try:
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            df = self._pro.trade_cal(
                exchange='SSE',
                start_date=start_str,
                end_date=end_str,
                is_open='1'
            )
            
            if df is None or df.empty:
                return []
                
            dates = pd.to_datetime(df['cal_date']).dt.date.tolist()
            return dates
            
        except Exception as e:
            logger.error(f"获取交易日列表失败: {e}")
            # 返回默认工作日
            return super().get_trade_dates(start_date, end_date)
    
    def get_adj_factor(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """
        获取复权因子（Tushare特有）
        
        Args:
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame，包含复权因子
        """
        if not self._connected:
            raise RuntimeError("Tushare 未连接")
            
        try:
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            df = self._pro.adj_factor(
                ts_code=code,
                start_date=start_str,
                end_date=end_str
            )
            
            if df is not None and not df.empty:
                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date
                
            return df
            
        except Exception as e:
            logger.error(f"获取复权因子失败: {e}")
            return pd.DataFrame()
