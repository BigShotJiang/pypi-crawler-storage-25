# -*- coding: utf-8 -*-
"""
数据源工厂 - 统一创建和管理数据源
"""

from typing import Dict, Any, Optional
from datetime import date
import logging

import pandas as pd

from .base import BaseDataSource, DataSourceType
from .qmt import QMTDataSource
from .baostock import BaostockDataSource
from .tushare import TushareDataSource

logger = logging.getLogger(__name__)


class DataSourceFactory:
    """
    数据源工厂
    
    统一管理数据源的创建和缓存
    """
    
    # 数据源缓存
    _instances: Dict[str, BaseDataSource] = {}
    
    @classmethod
    def create(
        cls,
        source_type: str,
        config: Dict[str, Any] = None,
        use_cache: bool = True
    ) -> BaseDataSource:
        """
        创建数据源实例
        
        Args:
            source_type: 数据源类型 ('qmt', 'baostock', 'tushare', 'duckdb')
            config: 配置参数
            use_cache: 是否使用缓存
            
        Returns:
            数据源实例
            
        Raises:
            ValueError: 不支持的数据源类型
        """
        source_type = source_type.lower()
        cache_key = f"{source_type}:{hash(str(config))}"
        
        # 检查缓存
        if use_cache and cache_key in cls._instances:
            logger.debug(f"使用缓存的数据源: {source_type}")
            return cls._instances[cache_key]
            
        # 创建新实例
        if source_type == 'qmt':
            instance = QMTDataSource(config)
        elif source_type == 'baostock':
            instance = BaostockDataSource(config)
        elif source_type == 'tushare':
            instance = TushareDataSource(config)
        elif source_type == 'duckdb':
            # DuckDB 数据源通过 storage 模块访问
            from ..storage.db_client import DBClient
            # 创建包装器
            instance = DuckDBDataSourceWrapper(config)
        else:
            raise ValueError(f"不支持的数据源类型: {source_type}")
            
        # 连接数据源
        if not instance.connect():
            raise RuntimeError(f"无法连接数据源: {source_type}")
            
        # 缓存实例
        if use_cache:
            cls._instances[cache_key] = instance
            
        return instance
    
    @classmethod
    def get_available_sources(cls) -> Dict[str, str]:
        """
        获取可用的数据源列表
        
        Returns:
            数据源名称和描述的映射
        """
        sources = {
            'qmt': 'QMT/xtquant (本地，需要QMT客户端)',
            'baostock': 'baostock (在线，免费)',
            'tushare': 'Tushare Pro (在线，需要Token)',
            'duckdb': '本地DuckDB数据库',
        }
        return sources
    
    @classmethod
    def check_source_available(cls, source_type: str) -> tuple:
        """
        检查数据源是否可用
        
        Args:
            source_type: 数据源类型
            
        Returns:
            (是否可用, 错误信息)
        """
        source_type = source_type.lower()
        
        if source_type == 'qmt':
            try:
                import sys
                import os
                # 检查是否是 Windows
                if sys.platform != 'win32':
                    return False, "QMT 仅支持 Windows 系统"
                    
                # 检查 xtquant
                from xtquant import xtdata
                return True, ""
            except ImportError:
                return False, "xtquant 未安装"
                
        elif source_type == 'baostock':
            try:
                import baostock
                return True, ""
            except ImportError:
                return False, "baostock 未安装，请运行: pip install baostock"
                
        elif source_type == 'tushare':
            try:
                import tushare
                return True, ""
            except ImportError:
                return False, "tushare 未安装，请运行: pip install tushare"
                
        elif source_type == 'duckdb':
            try:
                import duckdb
                return True, ""
            except ImportError:
                return False, "duckdb 未安装，请运行: pip install duckdb"
                
        else:
            return False, f"未知的数据源类型: {source_type}"
    
    @classmethod
    def clear_cache(cls):
        """清除数据源缓存"""
        for instance in cls._instances.values():
            try:
                instance.disconnect()
            except:
                pass
        cls._instances.clear()
        logger.info("数据源缓存已清除")


class DuckDBDataSourceWrapper(BaseDataSource):
    """
    DuckDB 数据源包装器
    
    将 DBClient 包装为统一的数据源接口
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(DataSourceType.DUCKDB, config)
        self.host = config.get('host', '127.0.0.1') if config else '127.0.0.1'
        self.port = config.get('port', 9528) if config else 9528
        self._client = None
        
    def connect(self) -> bool:
        """连接数据库"""
        try:
            from ..storage.db_client import DBClient
            self._client = DBClient(host=self.host, port=self.port)
            self._connected = self._client.ping()
            return self._connected
        except Exception as e:
            logger.error(f"连接 DuckDB 失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        self._client = None
        self._connected = False
        
    def get_stock_list(self, market: str = 'all') -> list:
        """获取股票列表"""
        df = self._client.get_all_stocks()
        if df.empty:
            return []
            
        stocks = []
        for _, row in df.iterrows():
            if market != 'all':
                code = row.get('code', '')
                if market == 'sh' and not code.endswith('.SH'):
                    continue
                if market == 'sz' and not code.endswith('.SZ'):
                    continue
            stocks.append({
                'code': row.get('code', ''),
                'name': row.get('name', ''),
                'market': row.get('market', '')
            })
        return stocks
    
    def get_daily_data(self, code: str, start_date: date, end_date: date) -> pd.DataFrame:
        """获取日线数据"""
        return self._client.get_market_data_daily(code, start_date, end_date)
    
    def get_daily_data_batch(self, codes: list, start_date: date, end_date: date) -> pd.DataFrame:
        """批量获取日线数据"""
        return self._client.get_market_data_daily_multi(codes, start_date, end_date)
