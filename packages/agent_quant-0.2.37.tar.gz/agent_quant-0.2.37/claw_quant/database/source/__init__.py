# -*- coding: utf-8 -*-
"""
数据源模块 - 支持多种数据源

支持的数据源:
- qmt: QMT/xtquant (本地)
- baostock:  baostock (在线)
- tushare: Tushare (在线)
- duckdb: 本地DuckDB数据库
"""

from .base import BaseDataSource, DataSourceType
from .qmt import QMTDataSource
from .factory import DataSourceFactory

__all__ = [
    'BaseDataSource',
    'DataSourceType',
    'QMTDataSource',
    'DataSourceFactory',
]
