# -*- coding: utf-8 -*-
"""
数据源基类 - 定义统一接口
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Union, Any
from datetime import date, datetime
from enum import Enum
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class DataSourceType(Enum):
    """数据源类型"""
    QMT = "qmt"              # QMT/xtquant
    BAOSTOCK = "baostock"    # baostock
    TUSHARE = "tushare"      # Tushare
    DUCKDB = "duckdb"        # 本地DuckDB


class BaseDataSource(ABC):
    """
    数据源基类
    
    所有数据源必须实现以下接口:
    - get_stock_list: 获取股票列表
    - get_daily_data: 获取日线数据
    - get_minute_data: 获取分钟线数据
    """
    
    def __init__(self, source_type: DataSourceType, config: Dict[str, Any] = None):
        """
        初始化数据源
        
        Args:
            source_type: 数据源类型
            config: 配置参数
        """
        self.source_type = source_type
        self.config = config or {}
        self._connected = False
        
    @property
    def name(self) -> str:
        """数据源名称"""
        return self.source_type.value
    
    @property
    def is_connected(self) -> bool:
        """是否已连接"""
        return self._connected
    
    @abstractmethod
    def connect(self) -> bool:
        """
        连接数据源
        
        Returns:
            是否连接成功
        """
        pass
    
    @abstractmethod
    def disconnect(self):
        """断开连接"""
        pass
    
    @abstractmethod
    def get_stock_list(self, market: str = 'all') -> List[Dict[str, str]]:
        """
        获取股票列表
        
        Args:
            market: 市场类型 ('all', 'sh', 'sz', 'bj')
            
        Returns:
            股票列表，每项包含 code, name, market 等字段
        """
        pass
    
    @abstractmethod
    def get_daily_data(
        self,
        code: str,
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        获取日线数据
        
        Args:
            code: 股票代码，如 '000001.SZ'
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame，包含以下列:
            - date: 日期
            - open: 开盘价
            - high: 最高价
            - low: 最低价
            - close: 收盘价
            - volume: 成交量
            - amount: 成交额
        """
        pass
    
    @abstractmethod
    def get_daily_data_batch(
        self,
        codes: List[str],
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        批量获取日线数据
        
        Args:
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame，包含 code 列区分不同股票
        """
        pass
    
    def get_minute_data(
        self,
        code: str,
        start_date: date,
        end_date: date,
        period: str = '1m'
    ) -> pd.DataFrame:
        """
        获取分钟线数据（可选实现）
        
        Args:
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            period: 周期 ('1m', '5m', '15m', '30m', '60m')
            
        Returns:
            DataFrame
        """
        raise NotImplementedError(f"{self.name} 不支持分钟线数据")
    
    def get_trade_dates(
        self,
        start_date: date,
        end_date: date
    ) -> List[date]:
        """
        获取交易日列表（可选实现）
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            交易日列表
        """
        # 默认实现：返回所有工作日
        dates = []
        current = start_date
        while current <= end_date:
            if current.weekday() < 5:  # 周一到周五
                dates.append(current)
            current += pd.Timedelta(days=1)
        return dates
    
    def normalize_code(self, code: str) -> str:
        """
        标准化股票代码格式
        
        Args:
            code: 原始代码，如 '000001', '000001.SZ'
            
        Returns:
            标准化代码，如 '000001.SZ'
        """
        code = code.strip().upper()
        
        # 如果已经有后缀，直接返回
        if '.' in code:
            return code
            
        # 根据代码前缀判断市场
        if code.startswith('6'):
            return f"{code}.SH"
        elif code.startswith('0') or code.startswith('3'):
            return f"{code}.SZ"
        elif code.startswith('8') or code.startswith('4'):
            return f"{code}.BJ"
        elif code.startswith('68') or code.startswith('69'):
            return f"{code}.SH"  # 科创板
        else:
            # 默认深圳
            return f"{code}.SZ"
    
    def validate_dates(self, start_date: date, end_date: date) -> tuple:
        """
        验证日期范围
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            (是否有效, 错误信息)
        """
        if start_date > end_date:
            return False, "开始日期不能晚于结束日期"
            
        today = date.today()
        if end_date > today:
            return False, "结束日期不能是未来日期"
            
        # 检查日期范围是否合理
        days = (end_date - start_date).days
        if days > 365 * 10:
            return False, "日期范围不能超过10年"
            
        return True, ""
