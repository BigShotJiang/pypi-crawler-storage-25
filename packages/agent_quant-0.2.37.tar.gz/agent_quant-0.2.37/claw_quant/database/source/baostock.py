# -*- coding: utf-8 -*-
"""
Baostock 数据源实现

提供从 baostock 获取A股历史数据的功能
"""

from typing import List, Dict, Optional, Any, Union
from datetime import date, datetime
import pandas as pd
import logging

from .base import BaseDataSource, DataSourceType

logger = logging.getLogger(__name__)


class BaostockDataSource(BaseDataSource):
    """
    Baostock 数据源
    
    特点:
    - 免费开源
    - 支持A股历史数据
    - 不需要登录
    - 数据更新有延迟（T+1）
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化 Baostock 数据源
        
        Args:
            config: 配置参数（baostock 不需要特殊配置）
        """
        super().__init__(DataSourceType.BAOSTOCK, config)
        self._bs = None
        
    def connect(self) -> bool:
        """
        连接 baostock
        
        Returns:
            是否连接成功
        """
        try:
            import baostock as bs
            self._bs = bs
            
            # 登录 baostock
            lg = bs.login()
            if lg.error_code != '0':
                logger.error(f"baostock 登录失败: {lg.error_msg}")
                return False
                
            self._connected = True
            logger.info("baostock 连接成功")
            return True
            
        except ImportError:
            logger.error("baostock 未安装，请运行: pip install baostock")
            return False
        except Exception as e:
            logger.error(f"baostock 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self._bs and self._connected:
            try:
                self._bs.logout()
            except:
                pass
        self._connected = False
        logger.info("baostock 已断开")
    
    def get_stock_list(self, market: str = 'all') -> List[Dict[str, str]]:
        """
        获取股票列表
        
        Args:
            market: 市场类型 ('all', 'sh', 'sz', 'bj')
            
        Returns:
            股票列表
        """
        if not self._connected:
            raise RuntimeError("baostock 未连接")
            
        try:
            stocks = []
            
            # 获取所有A股
            rs = self._bs.query_all_stock(day="")
            
            while (rs.error_code == '0') & rs.next():
                row = rs.get_row_data()
                code = row[0]  # 如 'sh.600000'
                
                # 解析市场
                if code.startswith('sh.'):
                    market_code = 'SH'
                    code_num = code[3:]
                elif code.startswith('sz.'):
                    market_code = 'SZ'
                    code_num = code[3:]
                else:
                    continue
                    
                # 市场过滤
                if market != 'all' and market_code.lower() != market.lower():
                    continue
                    
                stocks.append({
                    'code': f"{code_num}.{market_code}",
                    'name': '',  # baostock 不返回名称
                    'market': market_code
                })
                
            logger.info(f"获取到 {len(stocks)} 只股票")
            return stocks
            
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")
            return []
    
    def get_daily_data(
        self,
        code: str,
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        获取日线数据
        
        Args:
            code: 股票代码，如 '000001.SZ'
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        if not self._connected:
            raise RuntimeError("baostock 未连接")
            
        # 验证日期
        valid, msg = self.validate_dates(start_date, end_date)
        if not valid:
            raise ValueError(msg)
            
        try:
            # 转换代码格式: 000001.SZ -> sz.000001
            code_parts = code.split('.')
            if len(code_parts) == 2:
                bs_code = f"{code_parts[1].lower()}.{code_parts[0]}"
            else:
                bs_code = code
                
            # 转换日期格式
            start_str = start_date.strftime('%Y-%m-%d')
            end_str = end_date.strftime('%Y-%m-%d')
            
            # 查询数据
            rs = self._bs.query_history_k_data_plus(
                bs_code,
                "date,open,high,low,close,volume,amount",
                start_date=start_str,
                end_date=end_str,
                frequency="d",
                adjustflag="3"  # 后复权
            )
            
            if rs.error_code != '0':
                raise RuntimeError(f"查询失败: {rs.error_msg}")
                
            # 解析数据
            data = []
            while (rs.error_code == '0') & rs.next():
                row = rs.get_row_data()
                data.append({
                    'date': pd.to_datetime(row[0]).date(),
                    'open': float(row[1]) if row[1] else 0,
                    'high': float(row[2]) if row[2] else 0,
                    'low': float(row[3]) if row[3] else 0,
                    'close': float(row[4]) if row[4] else 0,
                    'volume': int(float(row[5])) if row[5] else 0,
                    'amount': float(row[6]) if row[6] else 0,
                    'code': code
                })
                
            df = pd.DataFrame(data)
            
            if df.empty:
                logger.warning(f"{code} 在 {start_str} ~ {end_str} 无数据")
                return df
                
            logger.info(f"获取 {code} 数据 {len(df)} 条")
            return df
            
        except Exception as e:
            logger.error(f"获取 {code} 数据失败: {e}")
            raise
    
    def get_daily_data_batch(
        self,
        codes: List[str],
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        批量获取日线数据
        
        Args:
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame
        """
        all_data = []
        
        for i, code in enumerate(codes):
            try:
                df = self.get_daily_data(code, start_date, end_date)
                if not df.empty:
                    all_data.append(df)
                    
                # 每10只股票暂停一下，避免请求过快
                if (i + 1) % 10 == 0:
                    import time
                    time.sleep(0.5)
                    
            except Exception as e:
                logger.warning(f"获取 {code} 失败: {e}")
                continue
                
        if not all_data:
            return pd.DataFrame()
            
        return pd.concat(all_data, ignore_index=True)
    
    def get_trade_dates(
        self,
        start_date: date,
        end_date: date
    ) -> List[date]:
        """
        获取交易日列表
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            交易日列表
        """
        if not self._connected:
            raise RuntimeError("baostock 未连接")
            
        try:
            start_str = start_date.strftime('%Y-%m-%d')
            end_str = end_date.strftime('%Y-%m-%d')
            
            rs = self._bs.query_trade_dates(start_date=start_str, end_date=end_str)
            
            dates = []
            while (rs.error_code == '0') & rs.next():
                row = rs.get_row_data()
                if row[1] == '1':  # 是交易日
                    dates.append(pd.to_datetime(row[0]).date())
                    
            return dates
            
        except Exception as e:
            logger.error(f"获取交易日列表失败: {e}")
            # 返回默认工作日
            return super().get_trade_dates(start_date, end_date)
    
    def download_daily(
        self,
        code: str,
        start_date: Union[str, date],
        end_date: Union[str, date]
    ) -> pd.DataFrame:
        """
        下载日线数据（兼容接口，同 get_daily_data）
        
        Args:
            code: 股票代码
            start_date: 开始日期（字符串或date对象）
            end_date: 结束日期（字符串或date对象）
            
        Returns:
            DataFrame
        """
        # 转换字符串日期为date对象
        if isinstance(start_date, str):
            start_date = pd.to_datetime(start_date).date()
        if isinstance(end_date, str):
            end_date = pd.to_datetime(end_date).date()
        
        return self.get_daily_data(code, start_date, end_date)
