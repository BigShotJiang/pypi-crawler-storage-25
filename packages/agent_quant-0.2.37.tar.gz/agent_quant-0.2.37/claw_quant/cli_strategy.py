# -*- coding: utf-8 -*-
"""
策略管理 CLI 子命令

提供类似 khquant 的策略管理功能：
- strategy list: 列出所有策略
- strategy create: 创建新策略模板
- strategy validate: 验证策略代码
- strategy info: 查看策略信息
"""

import argparse
import json
import sys
import os
import ast
import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

from .strategy.library import get_strategy_by_code
from .strategy.base import BaseStrategy


# 策略代码模板
STRATEGY_TEMPLATE = '''# -*- coding: utf-8 -*-
"""
{strategy_name} 策略

创建时间: {create_time}
"""

from claw_quant.strategy.base import BaseStrategy
import pandas as pd
import numpy as np


class {class_name}(BaseStrategy):
    """
    {strategy_description}
    
    参数:
        short_window: 短期窗口
        long_window: 长期窗口
    """
    
    meta = {{
        'code': '{strategy_code}',
        'name': '{strategy_name}',
        'description': '{strategy_description}',
        'category': '趋势',
        'parameters': {{
            'short_window': {{
                'default': 5,
                'type': 'int',
                'description': '短期均线窗口'
            }},
            'long_window': {{
                'default': 20,
                'type': 'int',
                'description': '长期均线窗口'
            }}
        }}
    }}
    
    def init(self, context):
        """初始化策略"""
        self.short_window = context.params.get('short_window', 5)
        self.long_window = context.params.get('long_window', 20)
        self.holding = False
    
    def on_bar(self, context, data):
        """
        处理每根K线数据
        
        Returns:
            dict: 交易信号
                - {{'action': 'hold'}} - 不操作
                - {{'action': 'buy', 'price': float, 'amount': int}} - 买入
                - {{'action': 'sell', 'price': float, 'amount': int}} - 卖出
        """
        # 获取历史数据
        history = context.get_history(field='close', count=self.long_window + 5)
        
        if len(history) < self.long_window:
            return {{'action': 'hold', 'reason': '数据不足'}}
        
        # 计算均线
        short_ma = history[-self.short_window:].mean()
        long_ma = history[-self.long_window:].mean()
        
        # 生成交易信号
        if short_ma > long_ma and not self.holding:
            self.holding = True
            return {{
                'action': 'buy',
                'price': data['close'],
                'reason': f'金叉: 短期MA({short_ma:.2f}) > 长期MA({long_ma:.2f})'
            }}
        
        elif short_ma < long_ma and self.holding:
            self.holding = False
            return {{
                'action': 'sell',
                'price': data['close'],
                'reason': f'死叉: 短期MA({short_ma:.2f}) < 长期MA({long_ma:.2f})'
            }}
        
        return {{'action': 'hold'}}
'''


# 配置文件模板
CONFIG_TEMPLATE = '''{{
    "strategy_file": "{strategy_file}",
    "backtest": {{
        "start_time": "{start_time}",
        "end_time": "{end_time}",
        "init_capital": 100000,
        "benchmark": "000300.SH",
        "trade_cost": {{
            "commission_rate": 0.0003,
            "stamp_tax_rate": 0.001,
            "min_commission": 5.0,
            "slippage": {{
                "type": "ratio",
                "ratio": 0.001
            }}
        }}
    }},
    "data": {{
        "kline_period": "1d",
        "stock_list": ["000001.SZ"],
        "dividend_type": "front"
    }},
    "risk": {{
        "position_limit": 0.95,
        "order_limit": 100
    }}
}}'''


def cmd_strategy_list(args):
    """列出所有策略"""
    try:
        # 从策略库获取所有策略
        strategies = []
        
        # 内置策略列表
        builtin_strategies = [
            {'code': 'CROSS_STRATEGY', 'name': '均线交叉策略', 'category': '趋势'},
            {'code': 'MACD_STRATEGY', 'name': 'MACD策略', 'category': '技术'},
            {'code': 'RSI_STRATEGY', 'name': 'RSI策略', 'category': '技术'},
            {'code': 'BOLLINGER_STRATEGY', 'name': '布林带策略', 'category': '技术'},
            {'code': 'GRID_STRATEGY', 'name': '网格策略', 'category': '均值回归'},
        ]
        
        strategies.extend(builtin_strategies)
        
        if not strategies:
            print("\n  暂无策略\n")
            return
        
        print(f"\n  共 {len(strategies)} 个策略:\n")
        print(f"  {'代码':<20} {'分类':<15} {'名称':<30}")
        print("  " + "-" * 65)
        
        for s in strategies:
            code = s.get('code', 'N/A')[:18]
            category = s.get('category', 'N/A')[:13]
            name = s.get('name', 'N/A')[:28]
            print(f"  {code:<20} {category:<15} {name:<30}")
        
        print()
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_strategy_create(args):
    """创建新策略模板"""
    name = args.name
    
    # 生成策略代码
    strategy_code = name.upper().replace(' ', '_')
    class_name = ''.join([w.capitalize() for w in name.split()]) + 'Strategy'
    create_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # 确定输出目录
    output_dir = Path(args.dir) if args.dir else Path('strategies')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成文件名
    py_file = output_dir / f"{strategy_code.lower()}.py"
    config_file = output_dir / f"{strategy_code.lower()}.json"
    
    # 检查文件是否已存在
    if py_file.exists() and not args.force:
        print(f"\n  错误: 文件已存在: {py_file}")
        print(f"  使用 --force 覆盖\n")
        sys.exit(1)
    
    # 生成策略代码
    strategy_content = STRATEGY_TEMPLATE.format(
        strategy_name=name,
        strategy_code=strategy_code,
        strategy_description=f'{name}策略 - 请修改描述',
        class_name=class_name,
        create_time=create_time
    )
    
    # 生成配置文件
    import datetime
    end_time = datetime.date.today().strftime('%Y%m%d')
    start_time = (datetime.date.today().replace(year=datetime.date.today().year-1)).strftime('%Y%m%d')
    
    config_content = CONFIG_TEMPLATE.format(
        strategy_file=str(py_file),
        start_time=start_time,
        end_time=end_time
    )
    
    # 写入文件
    with open(py_file, 'w', encoding='utf-8') as f:
        f.write(strategy_content)
    
    with open(config_file, 'w', encoding='utf-8') as f:
        f.write(config_content)
    
    print(f"\n  ✓ 策略创建成功!")
    print(f"\n  策略文件: {py_file}")
    print(f"  配置文件: {config_file}\n")
    print(f"  下一步:")
    print(f"    1. 编辑 {py_file} 实现策略逻辑")
    print(f"    2. 修改 {config_file} 配置回测参数")
    print(f"    3. 运行: python -m claw_quant.cli backtest --config {config_file}\n")


def cmd_strategy_validate(args):
    """验证策略代码"""
    file_path = args.file
    
    if not os.path.exists(file_path):
        print(f"\n  错误: 文件不存在: {file_path}\n")
        sys.exit(1)
    
    try:
        # 读取文件
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # 语法检查
        try:
            tree = ast.parse(code)
            print("\n  ✓ 语法检查通过")
        except SyntaxError as e:
            print(f"\n  ✗ 语法错误: {e}")
            sys.exit(1)
        
        # 检查必需元素
        issues = []
        warnings = []
        
        # 检查类定义
        classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
        if not classes:
            issues.append("未找到策略类定义")
        
        # 检查 init 方法
        has_init = any(
            isinstance(node, ast.FunctionDef) and node.name == 'init'
            for node in ast.walk(tree)
        )
        if not has_init:
            issues.append("缺少 init() 方法")
        
        # 检查 on_bar 方法
        has_on_bar = any(
            isinstance(node, ast.FunctionDef) and node.name == 'on_bar'
            for node in ast.walk(tree)
        )
        if not has_on_bar:
            issues.append("缺少 on_bar() 方法")
        
        # 检查 meta 定义
        has_meta = 'meta' in code
        if not has_meta:
            warnings.append("缺少 meta 定义")
        
        # 输出结果
        print(f"\n  检查结果:")
        print(f"  ──────────────────────────────────")
        
        if issues:
            print(f"  错误 ({len(issues)}):")
            for issue in issues:
                print(f"    ✗ {issue}")
        
        if warnings:
            print(f"  警告 ({len(warnings)}):")
            for warning in warnings:
                print(f"    ! {warning}")
        
        if not issues and not warnings:
            print("  ✓ 策略验证通过\n")
        elif not issues:
            print("\n  ✓ 策略可以运行，但建议处理警告\n")
        else:
            print("\n  ✗ 策略有错误，请修复后再运行\n")
            sys.exit(1)
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_strategy_info(args):
    """查看策略信息"""
    file_path = args.file
    
    if not os.path.exists(file_path):
        print(f"\n  错误: 文件不存在: {file_path}\n")
        sys.exit(1)
    
    try:
        # 读取文件
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # 解析AST
        tree = ast.parse(code)
        
        print(f"\n  策略文件: {file_path}")
        print(f"  ════════════════════════════════════════")
        
        # 提取类信息
        classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
        if classes:
            cls = classes[0]
            print(f"\n  策略类: {cls.name}")
            
            # 检查基类
            bases = [ast.unparse(base) for base in cls.bases]
            if bases:
                print(f"  继承: {', '.join(bases)}")
        
        # 提取方法
        methods = [node for node in ast.walk(tree) 
                   if isinstance(node, ast.FunctionDef)]
        
        print(f"\n  方法列表:")
        for method in methods:
            if method.name.startswith('_'):
                continue
            args_count = len(method.args.args) - 1  # 减去self
            print(f"    - {method.name}({args_count} 参数)")
        
        # 提取导入
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.extend([alias.name for alias in node.names])
            elif isinstance(node, ast.ImportFrom):
                imports.append(node.module)
        
        if imports:
            print(f"\n  依赖模块:")
            for imp in set(imports):
                print(f"    - {imp}")
        
        print(f"  ════════════════════════════════════════\n")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def setup_strategy_parser(subparsers):
    """设置 strategy 子命令解析器"""
    strategy_parser = subparsers.add_parser('strategy', help='策略管理')
    strategy_subparsers = strategy_parser.add_subparsers(dest='strategy_command', help='策略管理命令')
    
    # list 命令
    list_parser = strategy_subparsers.add_parser('list', help='列出所有策略')
    list_parser.set_defaults(func=cmd_strategy_list)
    
    # create 命令
    create_parser = strategy_subparsers.add_parser('create', help='创建新策略模板')
    create_parser.add_argument('name', help='策略名称')
    create_parser.add_argument('--dir', help='输出目录')
    create_parser.add_argument('--force', action='store_true', help='覆盖已存在文件')
    create_parser.set_defaults(func=cmd_strategy_create)
    
    # validate 命令
    validate_parser = strategy_subparsers.add_parser('validate', help='验证策略代码')
    validate_parser.add_argument('file', help='策略文件路径')
    validate_parser.set_defaults(func=cmd_strategy_validate)
    
    # info 命令
    info_parser = strategy_subparsers.add_parser('info', help='查看策略信息')
    info_parser.add_argument('file', help='策略文件路径')
    info_parser.set_defaults(func=cmd_strategy_info)
