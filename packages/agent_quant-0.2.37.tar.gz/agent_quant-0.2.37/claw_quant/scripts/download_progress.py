"""
带进度显示的股票数据下载脚本

支持分步下载和实时进度反馈
通过TCP访问数据库
"""
import sys
import os
import time
import logging
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from claw_quant.api.data_implement import DataAPIImpl, QMTDataSource
from claw_quant.database.storage.db_client import DBClient

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ProgressTracker:
    """进度跟踪器"""
    
    def __init__(self, total_stocks: int):
        self.total = total_stocks
        self.start_time = datetime.now()
        self.last_progress = 0
        
    def on_progress(self, code: str, current: int, total: int, batch_records: int):
        """进度回调函数"""
        progress = (current / total) * 100
        
        # 每10只股票或每1%更新一次显示
        if current % 10 == 0 or progress - self.last_progress >= 1:
            self.last_progress = progress
            elapsed = (datetime.now() - self.start_time).total_seconds()
            speed = current / elapsed if elapsed > 0 else 0
            eta = (total - current) / speed if speed > 0 else 0
            
            print(f"\r进度: {current}/{total} ({progress:.1f}%) | "
                  f"当前: {code} | "
                  f"速度: {speed:.1f}只/秒 | "
                  f"预计剩余: {eta/60:.1f}分钟", end='', flush=True)
    
    def on_complete(self, stats: dict):
        """下载完成回调"""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        print(f"\n\n下载完成!")
        print(f"总耗时: {elapsed/60:.1f}分钟")
        print(f"成功: {stats.get('success', 0)} 只")
        print(f"失败: {stats.get('failed', 0)} 只")
        print(f"总记录: {stats.get('records', 0):,} 条")


def main():
    """主函数"""
    print("="*60)
    print("股票数据下载 - 带进度显示")
    print("="*60)
    
    # 连接数据库服务器
    print("\n连接数据库服务器...")
    db = DBClient(host='127.0.0.1', port=9528)
    if not db.ping():
        print("错误: 无法连接到数据库服务器")
        print("请确保服务器已启动: python -m claw_quant.cli db start")
        sys.exit(1)
    print("✅ 已连接到数据库服务器")
    
    # 初始化QMT数据源
    print("\n初始化QMT数据源...")
    qmt = QMTDataSource()
    if not qmt.is_connected():
        print("错误: 无法连接到QMT")
        sys.exit(1)
    print("✅ QMT已连接")
    
    # 获取股票列表
    print("\n获取股票列表...")
    stocks = qmt.get_stock_list('all')
    print(f"共 {len(stocks)} 只股票")
    
    # 创建进度跟踪器
    tracker = ProgressTracker(len(stocks))
    
    # 下载数据
    print("\n开始下载数据...")
    print("-"*60)
    
    # 这里可以实现批量下载逻辑
    # 暂时只显示进度框架
    for i, code in enumerate(stocks[:10], 1):  # 测试前10只
        tracker.on_progress(code, i, len(stocks[:10]), 0)
        time.sleep(0.1)  # 模拟下载延迟
    
    tracker.on_complete({'success': 10, 'failed': 0, 'records': 100})
    
    print("\n" + "="*60)


if __name__ == '__main__':
    main()
