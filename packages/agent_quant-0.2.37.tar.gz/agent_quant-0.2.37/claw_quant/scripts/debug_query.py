#!/usr/bin/env python
"""调试查询"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from claw_quant.database import DuckDBManager
from datetime import date

db = DuckDBManager('data/quant_system.db')

# 查询所有数据
code = '000001.SZ'
start = date(2024, 1, 1)
end = date(2026, 4, 14)

print(f"查询: {code} 从 {start} 到 {end}")

# 先看看表结构
result = db.conn.execute("DESCRIBE market_data_daily").fetchdf()
print("\n表结构:")
print(result)

# 查询数据
df = db.get_market_data_daily(code, start, end)
print(f"\n返回 {len(df)} 条数据")

if not df.empty:
    print("\n数据预览:")
    print(df.head())
else:
    # 看看有没有这个股票的任何数据
    print("\n检查该股票的所有数据:")
    result = db.conn.execute(
        "SELECT MIN(trade_date), MAX(trade_date), COUNT(*) FROM market_data_daily WHERE code = ?",
        [code]
    ).fetchone()
    print(f"日期范围: {result[0]} 到 {result[1]}, 共 {result[2]} 条")
    
    # 看看有哪些股票
    print("\n数据库中的股票代码示例:")
    result = db.conn.execute("SELECT DISTINCT code FROM market_data_daily LIMIT 10").fetchdf()
    print(result)

db.close()
