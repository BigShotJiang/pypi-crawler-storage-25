"""
全市场股票数据下载脚本

下载所有A股过去5年的日线数据到本地DuckDB数据库
通过HTTP API访问数据库
"""
import sys
import os
import time
import logging
from datetime import date, datetime, timedelta
from typing import List, Dict, Optional

# 添加项目路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from claw_quant.api.data_implement import DataAPIImpl, QMTDataSource
from claw_quant.database.storage.db_client import DBClient

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('data_download.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)


class StockDataDownloader:
    """股票数据下载器"""

    def __init__(self, host: str = '127.0.0.1', port: int = 9528, qmt_path: Optional[str] = None):
        """
        初始化下载器

        Args:
            host: 数据库API服务器地址
            port: 数据库API服务器端口
            qmt_path: QMT安装路径，None则自动检测
        """
        self.host = host
        self.port = port
        self.qmt_path = qmt_path

        # 初始化数据库连接（TCP）
        logger.info(f"连接数据库服务器: {host}:{port}")
        self.db = DBClient(host=host, port=port)
        if not self.db.ping():
            raise ConnectionError(f"无法连接到数据库服务器 {host}:{port}")
        logger.info("数据库连接成功")

        # 初始化API
        config = {
            'data_source': 'auto',
            'db_host': host,
            'db_port': port
        }
        self.api = DataAPIImpl(config)

        # 初始化QMT连接
        self.qmt = None
        self._init_qmt()

    def _init_qmt(self):
        """初始化QMT连接"""
        try:
            self.qmt = QMTDataSource(self.qmt_path)
            if self.qmt.is_connected():
                logger.info("QMT连接成功")
            else:
                logger.warning("QMT连接失败，将使用本地数据")
        except Exception as e:
            logger.error(f"QMT初始化失败: {e}")
            self.qmt = None

    def get_all_stocks(self) -> List[str]:
        """
        获取所有A股股票列表

        Returns:
            股票代码列表
        """
        if not self.qmt or not self.qmt.is_connected():
            logger.error("QMT未连接，无法获取股票列表")
            return []

        logger.info("正在获取全市场股票列表...")
        try:
            stocks = self.qmt.get_stock_list('all')
            logger.info(f"获取到 {len(stocks)} 只股票")
            return stocks
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")
            return []

    def download_stock_data(self, code: str, start_date: date, end_date: date) -> int:
        """
        下载单只股票数据

        Args:
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            下载的记录数
        """
        try:
            # 使用API下载数据
            result = self.api.download(
                code,
                period='1d',
                start=start_date.strftime('%Y%m%d'),
                end=end_date.strftime('%Y%m%d')
            )

            return result.get('records', 0)

        except Exception as e:
            logger.error(f"下载失败 {code}: {e}")
            return 0

    def download_all(self, years: int = 5, batch_size: int = 50,
                     max_stocks: Optional[int] = None) -> Dict:
        """
        下载全市场数据

        Args:
            years: 下载过去几年的数据
            batch_size: 每批处理的股票数
            max_stocks: 最大下载股票数，None表示全部

        Returns:
            下载统计信息
        """
        # 获取股票列表
        stocks = self.get_all_stocks()
        if not stocks:
            logger.error("没有可下载的股票")
            return {'success': 0, 'failed': 0, 'total': 0}

        if max_stocks:
            stocks = stocks[:max_stocks]

        total = len(stocks)
        logger.info(f"计划下载 {total} 只股票，过去 {years} 年数据")

        # 计算日期范围
        end_date = date.today()
        start_date = end_date - timedelta(days=365 * years)

        logger.info(f"日期范围: {start_date} 至 {end_date}")

        # 统计
        stats = {
            'total': total,
            'success': 0,
            'failed': 0,
            'records': 0,
            'start_time': datetime.now(),
            'end_time': None
        }

        # 分批下载
        for i in range(0, total, batch_size):
            batch = stocks[i:i + batch_size]
            batch_num = i // batch_size + 1
            total_batches = (total - 1) // batch_size + 1

            logger.info(f"处理第 {batch_num}/{total_batches} 批，共 {len(batch)} 只股票")

            for j, code in enumerate(batch):
                current = i + j + 1
                progress = (current / total) * 100

                # 每10只记录一次进度
                if current % 10 == 0 or current == 1:
                    logger.info(f"进度: {current}/{total} ({progress:.1f}%) - 当前: {code}")

                try:
                    records = self.download_stock_data(code, start_date, end_date)
                    if records > 0:
                        stats['success'] += 1
                        stats['records'] += records
                    else:
                        stats['failed'] += 1
                        logger.warning(f"未获取到数据: {code}")
                except Exception as e:
                    stats['failed'] += 1
                    logger.error(f"下载失败 {code}: {e}")

                # 每100只股票休息1秒，避免请求过快
                if current % 100 == 0:
                    time.sleep(1)

            # 批次间休息
            logger.info(f"第 {batch_num} 批完成，休息2秒...")
            time.sleep(2)

        stats['end_time'] = datetime.now()

        # 打印统计
        duration = stats['end_time'] - stats['start_time']
        logger.info("=" * 60)
        logger.info("下载完成!")
        logger.info(f"总股票数: {stats['total']}")
        logger.info(f"成功: {stats['success']}")
        logger.info(f"失败: {stats['failed']}")
        logger.info(f"总记录数: {stats['records']}")
        logger.info(f"耗时: {duration}")
        logger.info("=" * 60)

        return stats

    def update_stock_list(self):
        """更新股票基础信息"""
        if not self.qmt or not self.qmt.is_connected():
            logger.error("QMT未连接，无法更新股票列表")
            return

        logger.info("正在更新股票基础信息...")
        try:
            stocks = self.qmt.get_stock_list('all')

            import pandas as pd
            stock_data = []
            for code in stocks:
                if '.SH' in code:
                    market = 'SH'
                elif '.SZ' in code:
                    market = 'SZ'
                elif '.BJ' in code:
                    market = 'BJ'
                else:
                    market = 'Unknown'

                stock_data.append({
                    'code': code,
                    'name': '',
                    'market': market,
                    'industry': '',
                    'list_date': None,
                    'status': 'active'
                })

            df = pd.DataFrame(stock_data)
            self.db.save_stocks(df)
            logger.info(f"已更新 {len(df)} 只股票基础信息")

        except Exception as e:
            logger.error(f"更新股票列表失败: {e}")

    def close(self):
        """关闭连接"""
        if self.db:
            # HTTP客户端无需显式关闭
            logger.info("数据库连接已关闭")


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description='下载A股历史数据')
    parser.add_argument('--years', type=int, default=5, help='下载过去几年的数据 (默认: 5)')
    parser.add_argument('--batch-size', type=int, default=50, help='每批处理的股票数 (默认: 50)')
    parser.add_argument('--max-stocks', type=int, default=None, help='最大下载股票数 (默认: 全部)')
    parser.add_argument('--host', type=str, default='127.0.0.1', help='数据库服务器地址 (默认: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=9528, help='数据库服务器端口 (默认: 9528)')
    parser.add_argument('--qmt-path', type=str, default=None, help='QMT安装路径')
    parser.add_argument('--update-list', action='store_true', help='只更新股票列表')

    args = parser.parse_args()

    # 创建下载器
    downloader = StockDataDownloader(
        host=args.host,
        port=args.port,
        qmt_path=args.qmt_path
    )

    try:
        if args.update_list:
            # 只更新股票列表
            downloader.update_stock_list()
        else:
            # 下载全市场数据
            stats = downloader.download_all(
                years=args.years,
                batch_size=args.batch_size,
                max_stocks=args.max_stocks
            )

            # 打印结果
            print("\n" + "=" * 60)
            print("下载统计")
            print("=" * 60)
            print(f"总股票数: {stats.get('total', 0)}")
            print(f"成功: {stats.get('success', 0)}")
            print(f"失败: {stats.get('failed', 0)}")
            print(f"总记录数: {stats.get('records', 0)}")
            if stats.get('end_time') and stats.get('start_time'):
                duration = stats['end_time'] - stats['start_time']
                print(f"耗时: {duration}")
            print("=" * 60)

    except KeyboardInterrupt:
        logger.info("用户中断下载")
    except Exception as e:
        logger.exception("下载过程出错")
    finally:
        downloader.close()


if __name__ == '__main__':
    main()
