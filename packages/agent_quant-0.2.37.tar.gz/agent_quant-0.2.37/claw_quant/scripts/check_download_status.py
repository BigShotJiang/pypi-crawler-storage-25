"""
检查数据下载状态
通过TCP访问数据库
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from claw_quant.database.storage.db_client import DBClient

def main():
    print('='*60)
    print('数据库下载完成统计')
    print('='*60)
    
    # 连接数据库服务器
    db = DBClient(host='127.0.0.1', port=9528)
    if not db.ping():
        print("错误: 无法连接到数据库服务器")
        print("请确保服务器已启动: python -m claw_quant.cli db start")
        sys.exit(1)
    
    print("✅ 已连接到数据库服务器\n")
    
    try:
        # 日线数据总记录数
        df = db.execute_query("SELECT COUNT(*) as cnt FROM market_data_daily")
        count = df['cnt'].iloc[0] if not df.empty else 0
        print(f'日线数据总记录数: {count:,}')
        
        # 已下载股票数
        df = db.execute_query('SELECT COUNT(DISTINCT code) as cnt FROM market_data_daily')
        stocks = df['cnt'].iloc[0] if not df.empty else 0
        print(f'已下载股票数: {stocks}')
        
        # 数据日期范围
        df = db.execute_query('SELECT MIN(trade_date) as min_date, MAX(trade_date) as max_date FROM market_data_daily')
        if not df.empty:
            print(f'数据日期范围: {df["min_date"].iloc[0]} 至 {df["max_date"].iloc[0]}')
        
        # 每只股票平均记录数
        df = db.execute_query('''
            SELECT AVG(cnt) as avg_cnt FROM (
                SELECT code, COUNT(*) as cnt 
                FROM market_data_daily 
                GROUP BY code
            )
        ''')
        avg_records = df['avg_cnt'].iloc[0] if not df.empty else 0
        print(f'每只股票平均记录数: {avg_records:.0f}')
        
    except Exception as e:
        print(f'查询统计信息失败: {e}')
    
    print('='*60)
    
    # 显示几只股票的数据样本
    print('\n数据样本 (平安银行 000001.SZ):')
    try:
        df = db.execute_query("""
            SELECT trade_date, open, high, low, close, volume 
            FROM market_data_daily 
            WHERE code = '000001.SZ' 
            ORDER BY trade_date DESC 
            LIMIT 5
        """)
        print(df.to_string() if not df.empty else "无数据")
    except Exception as e:
        print(f'查询样本数据失败: {e}')
    
    print('\n' + '='*60)


if __name__ == '__main__':
    main()
