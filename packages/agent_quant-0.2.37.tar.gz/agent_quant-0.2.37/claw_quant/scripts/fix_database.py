#!/usr/bin/env python
"""
修复数据库中的错误数据
1. 删除错误的日期数据（1970年的数据）
2. 重新下载正确的数据
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from claw_quant.database import DuckDBManager
from claw_quant.data_updater import MarketDataUpdater
from datetime import date
import pandas as pd

DB_PATH = 'data/quant_system.db'


def fix_database():
    """修复数据库 - 删除market_data_daily表并重建"""
    print("=" * 60)
    print("修复数据库")
    print("=" * 60)

    db = DuckDBManager(DB_PATH)

    # 检查当前数据
    print("\n1. 检查当前数据...")
    result = db.conn.execute("""
        SELECT code, COUNT(*) as count,
               MIN(trade_date) as min_date,
               MAX(trade_date) as max_date
        FROM market_data_daily
        GROUP BY code
        ORDER BY count DESC
    """).fetchdf()

    if not result.empty:
        print(f"当前数据:")
        print(result)

    # 删除表并重建
    print("\n2. 重建market_data_daily表...")
    db.conn.execute("DROP TABLE IF EXISTS market_data_daily")
    db.conn.execute("""
        CREATE TABLE market_data_daily (
            trade_date DATE NOT NULL,
            code VARCHAR NOT NULL,
            open DOUBLE,
            high DOUBLE,
            low DOUBLE,
            close DOUBLE,
            volume BIGINT,
            amount DOUBLE,
            turnover_rate DOUBLE,
            pe_ratio DOUBLE,
            pb_ratio DOUBLE,
            market_cap DOUBLE,
            created_at TIMESTAMP DEFAULT now(),
            PRIMARY KEY (trade_date, code)
        )
    """)
    print("✓ 表已重建")

    db.close()
    print("\n✓ 数据库修复完成")


def redownload_test_stock():
    """重新下载测试股票数据"""
    print("\n" + "=" * 60)
    print("重新下载测试股票数据")
    print("=" * 60)

    db = DuckDBManager(DB_PATH)

    try:
        updater = MarketDataUpdater(db)
        print("✓ 连接到QMT")
    except Exception as e:
        print(f"✗ 连接QMT失败: {e}")
        db.close()
        return

    # 下载 000001.SZ
    code = '000001.SZ'
    start_date = date(2025, 4, 1)
    end_date = date(2025, 4, 14)

    print(f"\n下载 {code} 从 {start_date} 到 {end_date}")

    try:
        # 1. 下载到QMT缓存
        updater.download_history_data(code, '1d', start_date, end_date)
        print("✓ 下载到QMT缓存")

        # 2. 获取数据
        df = updater.get_market_data(code, '1d', start_date, end_date)
        print(f"✓ 获取到 {len(df)} 条数据")

        if df.empty:
            print("✗ 没有获取到数据")
            db.close()
            return

        print("\n数据预览:")
        print(df.head())
        print(f"\ntime列类型: {df['time'].dtype}")
        print(f"time列示例值: {df['time'].iloc[0]}")

        # 3. 列名转换
        if 'time' in df.columns:
            # QMT的time是Unix时间戳(毫秒)
            df['trade_date'] = pd.to_datetime(df['time'], unit='ms').dt.date
        df['code'] = code

        # 确保所有需要的列都存在
        required_cols = ['trade_date', 'code', 'open', 'high', 'low', 'close', 'volume']
        for col in required_cols:
            if col not in df.columns:
                df[col] = 0

        # 可选列填充默认值
        optional_cols = ['turnover_rate', 'pe_ratio', 'pb_ratio', 'market_cap']
        for col in optional_cols:
            if col not in df.columns:
                df[col] = None

        print(f"\n转换后的trade_date:")
        print(df[['time', 'trade_date']].head())

        # 4. 保存到数据库
        db.save_market_data_daily(df)
        print(f"✓ 保存 {len(df)} 条数据到数据库")

        # 5. 验证查询
        result = db.get_market_data_daily(code, start_date, end_date)
        print(f"✓ 查询验证: 返回 {len(result)} 条数据")

        if not result.empty:
            print("\n查询结果:")
            print(result[['trade_date', 'code', 'open', 'high', 'low', 'close', 'volume']].head())

    except Exception as e:
        print(f"✗ 下载失败: {e}")
        import traceback
        traceback.print_exc()

    db.close()
    print("\n✓ 重新下载完成")


def verify_database():
    """验证数据库"""
    print("\n" + "=" * 60)
    print("验证数据库")
    print("=" * 60)

    db = DuckDBManager(DB_PATH)

    # 检查数据
    result = db.conn.execute("""
        SELECT code, COUNT(*) as count,
               MIN(trade_date) as min_date,
               MAX(trade_date) as max_date
        FROM market_data_daily
        GROUP BY code
        ORDER BY count DESC
    """).fetchdf()

    print(f"\n数据库中共有 {len(result)} 只股票的数据")
    print(result)

    # 检查000001.SZ
    print("\n000001.SZ 数据详情:")
    detail = db.conn.execute("""
        SELECT trade_date, open, high, low, close, volume
        FROM market_data_daily
        WHERE code = '000001.SZ'
        ORDER BY trade_date
    """).fetchdf()
    print(detail)

    db.close()


if __name__ == '__main__':
    fix_database()
    redownload_test_stock()
    verify_database()
