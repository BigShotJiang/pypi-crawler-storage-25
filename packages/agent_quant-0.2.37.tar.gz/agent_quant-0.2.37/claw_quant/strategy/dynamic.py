# -*- coding: utf-8 -*-
"""
动态策略管理模块

支持将策略代码存储在数据库中，运行时动态加载和执行
"""

import json
import logging
import hashlib
from typing import Dict, List, Optional, Any, Type
from datetime import datetime
from dataclasses import dataclass

from .base import BaseStrategy

logger = logging.getLogger(__name__)


@dataclass
class DynamicStrategyRecord:
    """动态策略记录"""
    id: str                          # 唯一ID
    code: str                        # 策略代码
    name: str                        # 策略名称
    description: str                 # 描述
    source_code: str                 # 策略源代码
    meta_json: str                   # 元数据JSON
    created_at: str                  # 创建时间
    updated_at: str                  # 更新时间
    version: int = 1                 # 版本号
    is_active: bool = True           # 是否激活


class DynamicStrategyManager:
    """
    动态策略管理器
    
    负责：
    1. 将策略代码存储到数据库
    2. 从数据库加载策略
    3. 动态编译执行策略代码
    """
    
    TABLE_NAME = 'dynamic_strategies'
    
    def __init__(self, db_client=None):
        """初始化"""
        if db_client is None:
            from claw_quant.database.storage.db_client import DBClient
            db_client = DBClient()
        self.db = db_client
        self._ensure_table()
        
    def _ensure_table(self):
        """确保表存在"""
        sql = f"""
        CREATE TABLE IF NOT EXISTS {self.TABLE_NAME} (
            id VARCHAR PRIMARY KEY,
            code VARCHAR UNIQUE NOT NULL,
            name VARCHAR NOT NULL,
            description VARCHAR,
            source_code TEXT NOT NULL,
            meta_json TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            version INTEGER DEFAULT 1,
            is_active BOOLEAN DEFAULT TRUE
        )
        """
        try:
            self.db.execute_query(sql)
            logger.info(f"确保表 {self.TABLE_NAME} 存在")
        except Exception as e:
            logger.error(f"创建表失败: {e}")
            raise
    
    def _generate_id(self, code: str) -> str:
        """生成唯一ID"""
        return hashlib.md5(code.encode()).hexdigest()[:16]
    
    def save_strategy(self, code: str, name: str, description: str,
                     source_code: str, meta: Dict[str, Any]) -> bool:
        """
        保存策略到数据库
        
        Args:
            code: 策略代码
            name: 策略名称
            description: 描述
            source_code: Python源代码
            meta: 元数据字典
            
        Returns:
            是否成功
        """
        try:
            strategy_id = self._generate_id(code)
            meta_json = json.dumps(meta, ensure_ascii=False)
            
            # 检查是否已存在
            existing = self.get_strategy(code)
            
            if existing:
                # 更新
                sql = f"""
                UPDATE {self.TABLE_NAME}
                SET name = '{name.replace("'", "''")}', 
                    description = '{description.replace("'", "''")}',
                    source_code = '{source_code.replace("'", "''")}', 
                    meta_json = '{meta_json.replace("'", "''")}', 
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE code = '{code}'
                """
                self.db.execute_query(sql)
                logger.info(f"更新策略: {code}")
            else:
                # 插入
                sql = f"""
                INSERT INTO {self.TABLE_NAME}
                (id, code, name, description, source_code, meta_json)
                VALUES (
                    '{strategy_id}', 
                    '{code}', 
                    '{name.replace("'", "''")}', 
                    '{description.replace("'", "''")}', 
                    '{source_code.replace("'", "''")}', 
                    '{meta_json.replace("'", "''")}'
                )
                """
                self.db.execute_query(sql)
                logger.info(f"创建策略: {code}")
            
            return True
        except Exception as e:
            logger.error(f"保存策略失败: {e}")
            return False
    
    def get_strategy(self, code: str) -> Optional[DynamicStrategyRecord]:
        """获取策略"""
        try:
            sql = f"""
            SELECT * FROM {self.TABLE_NAME} 
            WHERE code = '{code}' AND is_active = TRUE
            """
            df = self.db.execute_query(sql)
            
            if not df.empty:
                row = df.iloc[0]
                return DynamicStrategyRecord(
                    id=row['id'],
                    code=row['code'],
                    name=row['name'],
                    description=row['description'],
                    source_code=row['source_code'],
                    meta_json=row['meta_json'],
                    created_at=str(row['created_at']),
                    updated_at=str(row['updated_at']),
                    version=int(row['version']),
                    is_active=bool(row['is_active'])
                )
            return None
        except Exception as e:
            logger.error(f"获取策略失败: {e}")
            return None
    
    def list_strategies(self) -> List[Dict[str, Any]]:
        """列出所有策略"""
        try:
            sql = f"""
            SELECT code, name, description, updated_at, version
            FROM {self.TABLE_NAME}
            WHERE is_active = TRUE
            ORDER BY updated_at DESC
            """
            df = self.db.execute_query(sql)
            
            if not df.empty:
                records = df.to_dict('records')
                # 转换 Timestamp 为字符串
                for record in records:
                    if 'updated_at' in record and hasattr(record['updated_at'], 'strftime'):
                        record['updated_at'] = record['updated_at'].strftime('%Y-%m-%d %H:%M:%S')
                return records
            return []
        except Exception as e:
            logger.error(f"列出策略失败: {e}")
            return []
    
    def delete_strategy(self, code: str) -> bool:
        """删除策略（软删除）"""
        try:
            sql = f"""
            UPDATE {self.TABLE_NAME}
            SET is_active = FALSE, updated_at = CURRENT_TIMESTAMP
            WHERE code = '{code}'
            """
            self.db.execute_query(sql)
            logger.info(f"删除策略: {code}")
            return True
        except Exception as e:
            logger.error(f"删除策略失败: {e}")
            return False
    
    def compile_strategy(self, record: DynamicStrategyRecord) -> Optional[Type[BaseStrategy]]:
        """
        编译策略代码为可执行类
        
        Args:
            record: 策略记录
            
        Returns:
            策略类，如果编译失败返回None
        """
        try:
            # 创建命名空间
            namespace = {
                'BaseStrategy': BaseStrategy,
                'pd': __import__('pandas'),
                'np': __import__('numpy'),
                'logging': __import__('logging'),
            }
            
            # 执行源代码
            exec(record.source_code, namespace)
            
            # 查找策略类（继承自BaseStrategy的类）
            strategy_class = None
            for name, obj in namespace.items():
                if (isinstance(obj, type) and 
                    issubclass(obj, BaseStrategy) and 
                    obj is not BaseStrategy):
                    strategy_class = obj
                    break
            
            if strategy_class is None:
                logger.error(f"未找到有效的策略类: {record.code}")
                return None
            
            logger.info(f"编译策略成功: {record.code}")
            return strategy_class
            
        except Exception as e:
            logger.error(f"编译策略失败 {record.code}: {e}")
            return None


# 全局管理器实例
_dynamic_strategy_manager = None

def get_dynamic_strategy_manager(db_client=None) -> DynamicStrategyManager:
    """获取全局动态策略管理器"""
    global _dynamic_strategy_manager
    if _dynamic_strategy_manager is None:
        _dynamic_strategy_manager = DynamicStrategyManager(db_client)
    return _dynamic_strategy_manager
