# -*- coding: utf-8 -*-
"""
均线交叉策略示例

基于CROSS因子的完整交易策略，包含：
- 信号生成：短期均线上穿长期均线买入，下穿卖出
- 仓位管理：等权重仓位
- 风控：止损止盈
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from ..base import BaseStrategy, StrategyConfig, Signal, SignalType


class CrossStrategy(BaseStrategy):
    """
    均线交叉策略
    
    使用CROSS因子生成交易信号：
    - 金叉（短期均线上穿长期均线）→ 买入
    - 死叉（短期均线下穿长期均线）→ 卖出
    
    参数:
        short_window: 短期均线窗口，默认5日
        long_window: 长期均线窗口，默认20日
    """
    
    def __init__(self, 
                 short_window: int = 5,
                 long_window: int = 20,
                 stop_loss: float = 0.08,
                 take_profit: float = 0.15):
        """
        初始化均线交叉策略
        
        Args:
            short_window: 短期均线窗口
            long_window: 长期均线窗口
            stop_loss: 止损比例
            take_profit: 止盈比例
        """
        config = StrategyConfig(
            code='CROSS_STRATEGY',
            name='均线交叉策略',
            strategy_type='择时',
            description='基于均线金叉死叉的择时策略',
            factor_codes=['CROSS'],
            position_sizing={'type': 'equal', 'max_position': 0.2},
            risk_management={'stop_loss': stop_loss, 'take_profit': take_profit}
        )
        super().__init__(config)
        
        self.short_window = short_window
        self.long_window = long_window
        
        # 记录持仓状态
        self.positions: Dict[str, Dict] = {}  # code -> {entry_price, volume, entry_date}
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据，包含open, high, low, close, volume
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            交易信号列表
        """
        signals = []
        
        if market_data.empty:
            return signals
        
        # 计算均线
        market_data = market_data.copy()
        market_data['ma_short'] = market_data['close'].rolling(window=self.short_window).mean()
        market_data['ma_long'] = market_data['close'].rolling(window=self.long_window).mean()
        
        # 计算金叉死叉
        market_data['cross'] = 0
        market_data.loc[market_data['ma_short'] > market_data['ma_long'], 'cross'] = 1
        market_data['cross_signal'] = market_data['cross'].diff()
        
        # 获取最新数据
        latest = market_data.iloc[-1]
        code = str(latest.get('code', 'unknown'))
        current_price = float(latest['close'])
        
        # 检查是否有持仓（将positions的key都转为字符串比较）
        has_position = any(str(k) == code for k in self.positions.keys())
        
        # 金叉信号 - 买入
        if latest['cross_signal'] == 1 and not has_position:
            signals.append(Signal(
                strategy_code=self.config.code,
                code=code,
                signal_type=SignalType.BUY,
                signal_time=date,
                price=current_price,
                strength=0.8,
                reason=f"{self.short_window}日线上穿{self.long_window}日线，金叉买入"
            ))
            
        # 死叉信号 - 卖出
        elif latest['cross_signal'] == -1 and has_position:
            signals.append(Signal(
                strategy_code=self.config.code,
                code=code,
                signal_type=SignalType.SELL,
                signal_time=date,
                price=current_price,
                strength=0.8,
                reason=f"{self.short_window}日线下穿{self.long_window}日线，死叉卖出"
            ))
            
        # 检查止损止盈
        if has_position:
            # 找到匹配的position（处理StringDtype key）
            pos = None
            for k, v in self.positions.items():
                if str(k) == code:
                    pos = v
                    break
            
            if pos:
                entry_price = pos['entry_price']
                
                # 检查止损
                if self.check_stop_loss(code, entry_price, current_price):
                    signals.append(Signal(
                        strategy_code=self.config.code,
                        code=code,
                        signal_type=SignalType.SELL,
                        signal_time=date,
                        price=current_price,
                        strength=1.0,
                        reason=f"触发止损，亏损{(current_price - entry_price) / entry_price:.2%}"
                    ))
                    
                # 检查止盈
                elif self.check_take_profit(code, entry_price, current_price):
                    signals.append(Signal(
                        strategy_code=self.config.code,
                        code=code,
                        signal_type=SignalType.SELL,
                        signal_time=date,
                        price=current_price,
                        strength=1.0,
                        reason=f"触发止盈，盈利{(current_price - entry_price) / entry_price:.2%}"
                    ))
        
        return signals
    
    def on_signal_executed(self, code: str, signal_type: SignalType, 
                          price: float, volume: int, date: datetime):
        """
        信号执行回调
        
        Args:
            code: 股票代码
            signal_type: 信号类型
            price: 成交价格
            volume: 成交数量
            date: 成交日期
        """
        # 确保code是字符串
        code = str(code)
        
        if signal_type == SignalType.BUY:
            self.positions[code] = {
                'entry_price': float(price),
                'volume': int(volume),
                'entry_date': date
            }
        elif signal_type in [SignalType.SELL, SignalType.CLOSE]:
            # 找到并删除匹配的position（处理StringDtype key）
            keys_to_delete = [k for k in self.positions.keys() if str(k) == code]
            for k in keys_to_delete:
                del self.positions[k]
