# -*- coding: utf-8 -*-
"""
MACD 指数平滑异同平均线策略

基于 MACD 指标的交易策略：
- MACD 柱状线由负转正（金叉）→ 买入
- MACD 柱状线由正转负（死叉）→ 卖出

参数:
    fast: 快线周期，默认12
    slow: 慢线周期，默认26
    signal: 信号线周期，默认9
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from ..base import BaseStrategy, StrategyConfig, Signal, SignalType


def calculate_macd(prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> tuple:
    """
    计算 MACD 指标
    
    Args:
        prices: 价格序列
        fast: 快线周期
        slow: 慢线周期
        signal: 信号线周期
        
    Returns:
        (macd, signal_line, histogram)
    """
    ema_fast = prices.ewm(span=fast, adjust=False).mean()
    ema_slow = prices.ewm(span=slow, adjust=False).mean()
    
    macd = ema_fast - ema_slow
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line
    
    return macd, signal_line, histogram


class MACDStrategy(BaseStrategy):
    """
    MACD 指数平滑异同平均线策略
    
    策略逻辑:
    - MACD 柱状线由负转正（金叉）→ 买入信号
    - MACD 柱状线由正转负（死叉）→ 卖出信号
    - 柱状线持续为正 → 持有
    - 柱状线持续为负 → 空仓
    
    参数:
        fast: 快线周期，默认12
        slow: 慢线周期，默认26
        signal: 信号线周期，默认9
    """
    
    def __init__(self,
                 fast: int = 12,
                 slow: int = 26,
                 signal: int = 9,
                 stop_loss: float = 0.08):
        """
        初始化 MACD 策略
        
        Args:
            fast: 快线周期
            slow: 慢线周期
            signal: 信号线周期
            stop_loss: 止损比例
        """
        config = StrategyConfig(
            code='MACD_STRATEGY',
            name='MACD策略',
            strategy_type='择时',
            description='基于MACD金叉死叉的交易策略',
            factor_codes=['MACD'],
            position_sizing={'type': 'equal', 'max_position': 0.2},
            risk_management={'stop_loss': stop_loss}
        )
        super().__init__(config)
        
        self.fast = fast
        self.slow = slow
        self.signal = signal
        self.stop_loss = stop_loss
        
        # 记录持仓状态
        self.positions: Dict[str, Dict] = {}
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            交易信号列表
        """
        signals = []
        
        min_periods = max(self.fast, self.slow, self.signal) + 10
        if market_data.empty or len(market_data) < min_periods:
            return signals
        
        # 计算 MACD
        market_data = market_data.copy()
        macd, signal_line, histogram = calculate_macd(
            market_data['close'],
            self.fast,
            self.slow,
            self.signal
        )
        
        market_data['macd'] = macd
        market_data['signal'] = signal_line
        market_data['histogram'] = histogram
        
        # 计算柱状线变化（判断金叉死叉）
        market_data['histogram_prev'] = market_data['histogram'].shift(1)
        market_data['golden_cross'] = (market_data['histogram'] > 0) & (market_data['histogram_prev'] <= 0)
        market_data['death_cross'] = (market_data['histogram'] < 0) & (market_data['histogram_prev'] >= 0)
        
        # 获取最新数据
        latest = market_data.iloc[-1]
        code = latest.get('code', 'unknown')
        current_price = latest['close']
        histogram_val = latest['histogram']
        histogram_prev = latest['histogram_prev']
        
        # 检查是否有持仓
        has_position = code in self.positions
        
        # 检查止损
        if has_position:
            entry_price = self.positions[code]['entry_price']
            loss_pct = (entry_price - current_price) / entry_price
            
            if loss_pct >= self.stop_loss:
                signals.append(Signal(
                    strategy_code=self.config.code,
                    signal_type=SignalType.SELL,
                    code=code,
                    price=current_price,
                    volume=self.positions[code]['volume'],
                    reason=f'止损: 亏损{loss_pct*100:.2f}%',
                    signal_time=date
                ))
                del self.positions[code]
                return signals
        
        # MACD 信号判断
        if not has_position and latest['golden_cross']:
            # 金叉买入
            volume = self.calculate_position_size(current_price, portfolio)
            if volume > 0:
                signals.append(Signal(
                    strategy_code=self.config.code,
                    signal_type=SignalType.BUY,
                    code=code,
                    price=current_price,
                    volume=volume,
                    reason=f'MACD金叉: histogram={histogram_val:.4f}',
                    signal_time=date
                ))
                self.positions[code] = {
                    'entry_price': current_price,
                    'volume': volume,
                    'entry_date': date
                }
                
        elif has_position and latest['death_cross']:
            # 死叉卖出
            signals.append(Signal(
                strategy_code=self.config.code,
                signal_type=SignalType.SELL,
                code=code,
                price=current_price,
                volume=self.positions[code]['volume'],
                reason=f'MACD死叉: histogram={histogram_val:.4f}',
                signal_time=date
            ))
            del self.positions[code]
        
        return signals
    
    def on_signal_executed(self, code: str, signal_type: SignalType, 
                          price: float, volume: int, date: datetime):
        """
        信号执行回调
        
        Args:
            code: 股票代码
            signal_type: 信号类型
            price: 成交价格
            volume: 成交数量
            date: 成交日期
        """
        if signal_type == SignalType.BUY:
            self.positions[code] = {
                'entry_price': price,
                'volume': volume,
                'entry_date': date
            }
        elif signal_type in [SignalType.SELL, SignalType.CLOSE]:
            if code in self.positions:
                del self.positions[code]
    
    def calculate_position_size(self, price: float, portfolio: Optional[Dict]) -> int:
        """计算仓位大小"""
        if portfolio is None:
            return 100
        
        total_value = portfolio.get('total_value', 100000)
        max_position = self.config.position_sizing.get('max_position', 0.2)
        
        position_value = total_value * max_position
        volume = int(position_value / price / 100) * 100
        
        return max(volume, 100)
