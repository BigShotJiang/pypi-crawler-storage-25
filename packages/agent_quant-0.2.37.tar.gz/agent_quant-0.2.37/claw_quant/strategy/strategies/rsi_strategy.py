# -*- coding: utf-8 -*-
"""
RSI 相对强弱指标策略

基于 RSI 指标的交易策略：
- RSI < 30（超卖）→ 买入
- RSI > 70（超买）→ 卖出

参数:
    period: RSI计算周期，默认14日
    oversold: 超卖阈值，默认30
    overbought: 超买阈值，默认70
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from ..base import BaseStrategy, StrategyConfig, Signal, SignalType


def calculate_rsi(prices: pd.Series, period: int = 14) -> pd.Series:
    """
    计算 RSI 指标
    
    Args:
        prices: 价格序列
        period: 计算周期
        
    Returns:
        RSI 值序列
    """
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi


class RSIStrategy(BaseStrategy):
    """
    RSI 相对强弱指标策略
    
    策略逻辑:
    - RSI < oversold (30): 超卖区域，买入信号
    - RSI > overbought (70): 超买区域，卖出信号
    - 30 < RSI < 70: 正常区域，持有
    
    参数:
        period: RSI计算周期，默认14日
        oversold: 超卖阈值，默认30
        overbought: 超买阈值，默认70
    """
    
    def __init__(self,
                 period: int = 14,
                 oversold: float = 30,
                 overbought: float = 70,
                 stop_loss: float = 0.05):
        """
        初始化 RSI 策略
        
        Args:
            period: RSI计算周期
            oversold: 超卖阈值
            overbought: 超买阈值
            stop_loss: 止损比例
        """
        config = StrategyConfig(
            code='RSI_STRATEGY',
            name='RSI策略',
            strategy_type='择时',
            description='基于RSI超买超卖的交易策略',
            factor_codes=['RSI'],
            position_sizing={'type': 'equal', 'max_position': 0.2},
            risk_management={'stop_loss': stop_loss}
        )
        super().__init__(config)
        
        self.period = period
        self.oversold = oversold
        self.overbought = overbought
        self.stop_loss = stop_loss
        
        # 记录持仓状态
        self.positions: Dict[str, Dict] = {}
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            交易信号列表
        """
        signals = []
        
        if market_data.empty or len(market_data) < self.period + 1:
            return signals
        
        # 计算 RSI
        market_data = market_data.copy()
        market_data['rsi'] = calculate_rsi(market_data['close'], self.period)
        
        # 获取最新数据
        latest = market_data.iloc[-1]
        code = latest.get('code', 'unknown')
        current_price = latest['close']
        current_rsi = latest['rsi']
        
        # 检查是否有持仓
        has_position = code in self.positions
        
        # 检查止损
        if has_position:
            entry_price = self.positions[code]['entry_price']
            loss_pct = (entry_price - current_price) / entry_price
            
            if loss_pct >= self.stop_loss:
                # 止损卖出
                signals.append(Signal(
                    type=SignalType.SELL,
                    code=code,
                    price=current_price,
                    volume=self.positions[code]['volume'],
                    reason=f'止损: 亏损{loss_pct*100:.2f}%',
                    timestamp=date
                ))
                del self.positions[code]
                return signals
        
        # RSI 信号判断
        if not has_position and current_rsi < self.oversold:
            # 超卖买入
            volume = self.calculate_position_size(current_price, portfolio)
            if volume > 0:
                signals.append(Signal(
                    type=SignalType.BUY,
                    code=code,
                    price=current_price,
                    volume=volume,
                    reason=f'RSI超卖买入: RSI={current_rsi:.2f}',
                    timestamp=date
                ))
                self.positions[code] = {
                    'entry_price': current_price,
                    'volume': volume,
                    'entry_date': date
                }
                
        elif has_position and current_rsi > self.overbought:
            # 超买卖出
            signals.append(Signal(
                type=SignalType.SELL,
                code=code,
                price=current_price,
                volume=self.positions[code]['volume'],
                reason=f'RSI超买卖出: RSI={current_rsi:.2f}',
                timestamp=date
            ))
            del self.positions[code]
        
        return signals
    
    def calculate_position_size(self, price: float, portfolio: Optional[Dict]) -> int:
        """
        计算仓位大小
        
        Args:
            price: 当前价格
            portfolio: 组合信息
            
        Returns:
            买入股数
        """
        if portfolio is None:
            return 100  # 默认买入100股
        
        total_value = portfolio.get('total_value', 100000)
        max_position = self.config.position_sizing.get('max_position', 0.2)
        
        position_value = total_value * max_position
        volume = int(position_value / price / 100) * 100  # 整手
        
        return max(volume, 100)  # 至少100股
