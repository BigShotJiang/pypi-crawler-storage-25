# -*- coding: utf-8 -*-
"""
网格交易策略 (Grid Trading Strategy)

适用于震荡市场的网格交易策略：
- 在预设价格区间内设置多层网格
- 价格下跌到网格线买入
- 价格上涨到网格线卖出

参数:
    upper_price: 网格上限价格
    lower_price: 网格下限价格
    grid_count: 网格数量
    position_per_grid: 每格仓位
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from ..base import BaseStrategy, StrategyConfig, Signal, SignalType


class GridStrategy(BaseStrategy):
    """
    网格交易策略
    
    策略逻辑:
    - 在 [lower_price, upper_price] 区间内设置 grid_count 个网格
    - 价格下跌触及网格线 → 买入一格
    - 价格上涨触及网格线 → 卖出一格
    - 适合震荡市场，不适合趋势市场
    
    参数:
        upper_price: 网格上限价格
        lower_price: 网格下限价格
        grid_count: 网格数量，默认10
        position_per_grid: 每格买入金额比例
    """
    
    def __init__(self,
                 upper_price: float = None,
                 lower_price: float = None,
                 grid_count: int = 10,
                 position_per_grid: float = 0.1):
        """
        初始化网格策略
        
        Args:
            upper_price: 网格上限价格（None则自动计算）
            lower_price: 网格下限价格（None则自动计算）
            grid_count: 网格数量
            position_per_grid: 每格买入金额比例
        """
        config = StrategyConfig(
            code='GRID_STRATEGY',
            name='网格交易策略',
            strategy_type='震荡',
            description='基于价格区间的网格交易策略',
            factor_codes=[],
            position_sizing={'type': 'grid', 'max_position': 0.8},
            risk_management={}
        )
        super().__init__(config)
        
        self.upper_price = upper_price
        self.lower_price = lower_price
        self.grid_count = grid_count
        self.position_per_grid = position_per_grid
        
        # 网格状态
        self.grids: List[float] = []  # 网格价格线
        self.grid_positions: Dict[int, int] = {}  # 网格索引 -> 持仓数量
        self.current_grid_idx: Optional[int] = None
        
        # 记录持仓
        self.positions: Dict[str, Dict] = {}
        
    def init_grids(self, current_price: float, price_history: pd.Series = None):
        """
        初始化网格
        
        Args:
            current_price: 当前价格
            price_history: 历史价格（用于自动计算上下限）
 """
        if self.upper_price is None or self.lower_price is None:
            if price_history is not None and len(price_history) > 20:
                # 基于历史价格自动计算
                self.upper_price = price_history.quantile(0.8)
                self.lower_price = price_history.quantile(0.2)
            else:
                # 基于当前价格计算
                self.upper_price = current_price * 1.2
                self.lower_price = current_price * 0.8
        
        # 生成网格线
        grid_step = (self.upper_price - self.lower_price) / self.grid_count
        self.grids = [self.lower_price + i * grid_step for i in range(self.grid_count + 1)]
        
        # 确定当前所在网格
        for i, grid_price in enumerate(self.grids):
            if current_price <= grid_price:
                self.current_grid_idx = i
                break
        
        if self.current_grid_idx is None:
            self.current_grid_idx = self.grid_count
    
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            交易信号列表
        """
        signals = []
        
        if market_data.empty:
            return signals
        
        # 获取最新数据
        latest = market_data.iloc[-1]
        code = latest.get('code', 'unknown')
        current_price = latest['close']
        
        # 初始化网格
        if not self.grids:
            self.init_grids(current_price, market_data['close'])
        
        # 确定当前所在网格
        new_grid_idx = None
        for i, grid_price in enumerate(self.grids):
            if current_price <= grid_price:
                new_grid_idx = i
                break
        
        if new_grid_idx is None:
            new_grid_idx = self.grid_count
        
        # 网格变化判断
        if self.current_grid_idx is not None and new_grid_idx != self.current_grid_idx:
            if new_grid_idx > self.current_grid_idx:
                # 价格下跌，向下穿越网格线 → 买入
                volume = self.calculate_position_size(current_price, portfolio)
                if volume > 0:
                    signals.append(Signal(
                        type=SignalType.BUY,
                        code=code,
                        price=current_price,
                        volume=volume,
                        reason=f'网格买入: 价格跌至网格{new_grid_idx}',
                        timestamp=date
                    ))
                    self.grid_positions[new_grid_idx] = self.grid_positions.get(new_grid_idx, 0) + volume
                    
            elif new_grid_idx < self.current_grid_idx:
                # 价格上涨，向上穿越网格线 → 卖出
                # 检查是否有持仓可卖
                sell_volume = 0
                for idx in range(new_grid_idx + 1, self.current_grid_idx + 1):
                    if idx in self.grid_positions and self.grid_positions[idx] > 0:
                        sell_volume += self.grid_positions[idx]
                        self.grid_positions[idx] = 0
                
                if sell_volume > 0:
                    signals.append(Signal(
                        type=SignalType.SELL,
                        code=code,
                        price=current_price,
                        volume=sell_volume,
                        reason=f'网格卖出: 价格涨至网格{new_grid_idx}',
                        timestamp=date
                    ))
        
        self.current_grid_idx = new_grid_idx
        
        return signals
    
    def calculate_position_size(self, price: float, portfolio: Optional[Dict]) -> int:
        """计算每格仓位大小"""
        if portfolio is None:
            return 100
        
        total_value = portfolio.get('total_value', 100000)
        cash = portfolio.get('cash', total_value)
        
        # 每格使用一定比例的资金
        grid_value = total_value * self.position_per_grid
        volume = int(grid_value / price / 100) * 100
        
        # 检查现金是否足够
        max_affordable = int(cash / price / 100) * 100
        
        return min(volume, max_affordable, 1000)  # 限制最大买入量
