# -*- coding: utf-8 -*-
"""
布林带策略 (Bollinger Bands Strategy)

基于布林带指标的交易策略：
- 价格触及下轨 → 买入（超卖反弹）
- 价格触及上轨 → 卖出（超买回调）

参数:
    period: 计算周期，默认20日
    std_dev: 标准差倍数，默认2
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict
from datetime import datetime

from ..base import BaseStrategy, StrategyConfig, Signal, SignalType


def calculate_bollinger(prices: pd.Series, period: int = 20, std_dev: float = 2.0) -> tuple:
    """
    计算布林带指标
    
    Args:
        prices: 价格序列
        period: 计算周期
        std_dev: 标准差倍数
        
    Returns:
        (middle, upper, lower)
    """
    middle = prices.rolling(window=period).mean()
    std = prices.rolling(window=period).std()
    
    upper = middle + (std * std_dev)
    lower = middle - (std * std_dev)
    
    return middle, upper, lower


class BollingerStrategy(BaseStrategy):
    """
    布林带策略
    
    策略逻辑:
    - 价格跌破下轨 → 买入（超卖，预期反弹）
    - 价格突破上轨 → 卖出（超买，预期回调）
    - 价格在中轨和上轨之间 → 持有
    - 价格在中轨和下轨之间 → 空仓或观望
    
    参数:
        period: 计算周期，默认20日
        std_dev: 标准差倍数，默认2
    """
    
    def __init__(self,
                 period: int = 20,
                 std_dev: float = 2.0,
                 stop_loss: float = 0.05):
        """
        初始化布林带策略
        
        Args:
            period: 计算周期
            std_dev: 标准差倍数
            stop_loss: 止损比例
        """
        config = StrategyConfig(
            code='BOLLINGER_STRATEGY',
            name='布林带策略',
            strategy_type='均值回归',
            description='基于布林带上下轨的均值回归策略',
            factor_codes=['BOLLINGER'],
            position_sizing={'type': 'equal', 'max_position': 0.2},
            risk_management={'stop_loss': stop_loss}
        )
        super().__init__(config)
        
        self.period = period
        self.std_dev = std_dev
        self.stop_loss = stop_loss
        
        # 记录持仓状态
        self.positions: Dict[str, Dict] = {}
        
    def generate_signals(self,
                         date: datetime,
                         market_data: pd.DataFrame,
                         factor_data: pd.DataFrame,
                         portfolio: Optional[Dict] = None) -> List[Signal]:
        """
        生成交易信号
        
        Args:
            date: 当前日期
            market_data: 市场数据
            factor_data: 因子数据
            portfolio: 当前持仓
            
        Returns:
            交易信号列表
        """
        signals = []
        
        if market_data.empty or len(market_data) < self.period + 1:
            return signals
        
        # 计算布林带
        market_data = market_data.copy()
        middle, upper, lower = calculate_bollinger(
            market_data['close'],
            self.period,
            self.std_dev
        )
        
        market_data['middle'] = middle
        market_data['upper'] = upper
        market_data['lower'] = lower
        
        # 获取最新数据
        latest = market_data.iloc[-1]
        code = latest.get('code', 'unknown')
        current_price = latest['close']
        upper_band = latest['upper']
        lower_band = latest['lower']
        middle_band = latest['middle']
        
        # 检查是否有持仓
        has_position = code in self.positions
        
        # 检查止损
        if has_position:
            entry_price = self.positions[code]['entry_price']
            loss_pct = (entry_price - current_price) / entry_price
            
            if loss_pct >= self.stop_loss:
                signals.append(Signal(
                    type=SignalType.SELL,
                    code=code,
                    price=current_price,
                    volume=self.positions[code]['volume'],
                    reason=f'止损: 亏损{loss_pct*100:.2f}%',
                    timestamp=date
                ))
                del self.positions[code]
                return signals
        
        # 布林带信号判断
        if not has_position and current_price < lower_band:
            # 跌破下轨买入（超卖）
            volume = self.calculate_position_size(current_price, portfolio)
            if volume > 0:
                signals.append(Signal(
                    type=SignalType.BUY,
                    code=code,
                    price=current_price,
                    volume=volume,
                    reason=f'布林带下轨买入: 价格{current_price:.2f} < 下轨{lower_band:.2f}',
                    timestamp=date
                ))
                self.positions[code] = {
                    'entry_price': current_price,
                    'volume': volume,
                    'entry_date': date
                }
                
        elif has_position and current_price > upper_band:
            # 突破上轨卖出（超买）
            signals.append(Signal(
                type=SignalType.SELL,
                code=code,
                price=current_price,
                volume=self.positions[code]['volume'],
                reason=f'布林带上轨卖出: 价格{current_price:.2f} > 上轨{upper_band:.2f}',
                timestamp=date
            ))
            del self.positions[code]
        
        return signals
    
    def calculate_position_size(self, price: float, portfolio: Optional[Dict]) -> int:
        """计算仓位大小"""
        if portfolio is None:
            return 100
        
        total_value = portfolio.get('total_value', 100000)
        max_position = self.config.position_sizing.get('max_position', 0.2)
        
        position_value = total_value * max_position
        volume = int(position_value / price / 100) * 100
        
        return max(volume, 100)
