# -*- coding: utf-8 -*-
"""
交易成本和风险控制模块

提供类似 khquant 的交易成本计算和风险控制功能：
- 交易成本：佣金、印花税、过户费、滑点
- 风险控制：仓位限制、订单限制、止损止盈
"""

from dataclasses import dataclass
from typing import Dict, Optional, Tuple
from enum import Enum


class SlippageType(Enum):
    """滑点类型"""
    TICK = "tick"      # 绝对值滑点（按tick数）
    RATIO = "ratio"    # 比例滑点


@dataclass
class TradeCost:
    """交易成本配置"""
    commission_rate: float = 0.0003      # 佣金率（万三）
    stamp_tax_rate: float = 0.001        # 印花税率（千一，仅卖出）
    min_commission: float = 5.0          # 最低佣金
    flow_fee: float = 0.1                # 过户费（元/笔）
    
    # 滑点配置
    slippage_type: SlippageType = SlippageType.RATIO
    slippage_ratio: float = 0.001        # 滑点比例（默认千一）
    tick_size: float = 0.01              # 最小变动单位
    tick_count: int = 2                  # tick数量（用于TICK滑点）
    
    def calculate_cost(self, price: float, volume: int, is_buy: bool) -> Tuple[float, float]:
        """
        计算交易成本
        
        Args:
            price: 成交价格
            volume: 成交数量
            is_buy: 是否买入
            
        Returns:
            (实际成交价格, 总交易成本)
        """
        # 计算滑点
        if self.slippage_type == SlippageType.TICK:
            slippage = self.tick_size * self.tick_count
        else:
            # 比例滑点，买入时价格上浮，卖出时价格下浮
            slippage = price * self.slippage_ratio
        
        # 应用滑点
        if is_buy:
            executed_price = price + slippage
        else:
            executed_price = price - slippage
        
        # 计算金额
        amount = executed_price * volume
        
        # 佣金（双向收取）
        commission = max(amount * self.commission_rate, self.min_commission)
        
        # 印花税（仅卖出）
        stamp_tax = amount * self.stamp_tax_rate if not is_buy else 0
        
        # 过户费
        flow_fee = self.flow_fee
        
        total_cost = commission + stamp_tax + flow_fee
        
        return executed_price, total_cost
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'commission_rate': self.commission_rate,
            'stamp_tax_rate': self.stamp_tax_rate,
            'min_commission': self.min_commission,
            'flow_fee': self.flow_fee,
            'slippage_type': self.slippage_type.value,
            'slippage_ratio': self.slippage_ratio,
            'tick_size': self.tick_size,
            'tick_count': self.tick_count
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TradeCost':
        """从字典创建"""
        slippage_type = SlippageType(data.get('slippage_type', 'ratio'))
        return cls(
            commission_rate=data.get('commission_rate', 0.0003),
            stamp_tax_rate=data.get('stamp_tax_rate', 0.001),
            min_commission=data.get('min_commission', 5.0),
            flow_fee=data.get('flow_fee', 0.1),
            slippage_type=slippage_type,
            slippage_ratio=data.get('slippage_ratio', 0.001),
            tick_size=data.get('tick_size', 0.01),
            tick_count=data.get('tick_count', 2)
        )


@dataclass
class RiskControl:
    """风险控制配置"""
    position_limit: float = 0.95         # 最大仓位比例（默认95%）
    order_limit: int = 100               # 最大订单数量
    loss_limit: float = 0.1              # 止损比例（默认10%）
    profit_limit: float = 0.2            # 止盈比例（默认20%）
    max_position_per_stock: float = 0.3  # 单只股票最大仓位
    
    def check_position(self, current_position: float, total_asset: float) -> bool:
        """
        检查仓位限制
        
        Args:
            current_position: 当前持仓市值
            total_asset: 总资产
            
        Returns:
            是否允许继续买入
        """
        if total_asset <= 0:
            return False
        position_ratio = current_position / total_asset
        return position_ratio < self.position_limit
    
    def check_order_limit(self, current_orders: int) -> bool:
        """检查订单数量限制"""
        return current_orders < self.order_limit
    
    def check_stop_loss(self, entry_price: float, current_price: float) -> bool:
        """
        检查是否触发止损
        
        Returns:
            True if should stop loss
        """
        if entry_price <= 0:
            return False
        loss_ratio = (entry_price - current_price) / entry_price
        return loss_ratio >= self.loss_limit
    
    def check_take_profit(self, entry_price: float, current_price: float) -> bool:
        """
        检查是否触发止盈
        
        Returns:
            True if should take profit
        """
        if entry_price <= 0:
            return False
        profit_ratio = (current_price - entry_price) / entry_price
        return profit_ratio >= self.profit_limit
    
    def check_single_stock_position(self, stock_value: float, total_asset: float) -> bool:
        """检查单只股票仓位限制"""
        if total_asset <= 0:
            return False
        ratio = stock_value / total_asset
        return ratio < self.max_position_per_stock
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'position_limit': self.position_limit,
            'order_limit': self.order_limit,
            'loss_limit': self.loss_limit,
            'profit_limit': self.profit_limit,
            'max_position_per_stock': self.max_position_per_stock
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'RiskControl':
        """从字典创建"""
        return cls(
            position_limit=data.get('position_limit', 0.95),
            order_limit=data.get('order_limit', 100),
            loss_limit=data.get('loss_limit', 0.1),
            profit_limit=data.get('profit_limit', 0.2),
            max_position_per_stock=data.get('max_position_per_stock', 0.3)
        )


class TradeMode:
    """交易模式检测"""
    
    # T+0 ETF 列表（部分常见ETF）
    T0_ETF_CODES = {
        '510050.SH',  # 50ETF
        '510300.SH',  # 300ETF
        '510500.SH',  # 500ETF
        '159915.SZ',  # 创业板ETF
        '159901.SZ',  # 深100ETF
        '518880.SH',  # 黄金ETF
        '511010.SH',  # 国债ETF
        '511880.SH',  # 银华日利
        '511990.SH',  # 华宝添益
    }
    
    @classmethod
    def detect_mode(cls, stock_codes: list) -> str:
        """
        自动检测交易模式
        
        Args:
            stock_codes: 股票代码列表
            
        Returns:
            'T0' 或 'T1'
        """
        if not stock_codes:
            return 'T1'
        
        # 检查是否全部是T+0标的
        all_t0 = all(
            code in cls.T0_ETF_CODES 
            for code in stock_codes
        )
        
        return 'T0' if all_t0 else 'T1'
    
    @classmethod
    def is_t0_stock(cls, code: str) -> bool:
        """检查是否是T+0标的"""
        return code in cls.T0_ETF_CODES


def calculate_max_buy_volume(
    cash: float,
    price: float,
    trade_cost: TradeCost,
    min_volume: int = 100
) -> int:
    """
    计算最大可买入股数
    
    Args:
        cash: 可用资金
        price: 买入价格
        trade_cost: 交易成本配置
        min_volume: 最小交易单位（默认100股）
        
    Returns:
        最大可买入股数（已考虑交易成本）
    """
    if price <= 0 or cash <= 0:
        return 0
    
    # 估算交易成本（按最大佣金计算）
    estimated_cost_rate = trade_cost.commission_rate + 0.001  # 预留一些成本
    
    # 可用资金扣除成本后的金额
    available_amount = cash / (1 + estimated_cost_rate)
    
    # 计算股数
    volume = int(available_amount / price)
    
    # 调整为最小交易单位的整数倍
    volume = (volume // min_volume) * min_volume
    
    return max(0, volume)


def generate_signal(
    data: Dict,
    stock_code: str,
    price: float,
    ratio: float,
    action: str,
    reason: str = ""
) -> list:
    """
    智能信号生成（类似 khquant 的 generate_signal）
    
    Args:
        data: 数据对象（包含账户信息）
        stock_code: 股票代码
        price: 交易价格
        ratio: 买入时为资金使用比例(<=1)或目标股数(>1)；卖出时为持仓卖出比例
        action: 'buy' 或 'sell'
        reason: 交易原因
        
    Returns:
        信号列表，条件不满足返回空列表
    """
    signals = []
    
    # 获取账户信息
    account = data.get('__account__', {})
    positions = data.get('__positions__', {})
    
    if action == 'buy':
        cash = account.get('cash', 0)
        
        if ratio <= 1:
            # 按比例使用资金
            use_cash = cash * ratio
            volume = int(use_cash / price / 100) * 100  # 调整为100的整数倍
        else:
            # 指定股数
            volume = int(ratio / 100) * 100
        
        if volume >= 100 and cash >= volume * price:
            signals.append({
                'code': stock_code,
                'action': 'buy',
                'price': price,
                'volume': volume,
                'reason': reason
            })
    
    elif action == 'sell':
        position = positions.get(stock_code, {})
        hold_volume = position.get('volume', 0)
        
        if hold_volume > 0:
            if ratio >= 1:
                # 全部卖出
                volume = hold_volume
            else:
                # 按比例卖出
                volume = int(hold_volume * ratio / 100) * 100
            
            if volume >= 100:
                signals.append({
                    'code': stock_code,
                    'action': 'sell',
                    'price': price,
                    'volume': volume,
                    'reason': reason
                })
    
    return signals
