# -*- coding: utf-8 -*-
"""
股票池管理模块

提供类似 khquant 的股票池功能：
- 预设股票池：沪深300、上证50、中证500等
- 股票池成分股更新
- 股票代码格式转换
"""

import os
import json
from typing import List, Dict, Optional
from pathlib import Path


class StockPool:
    """股票池管理"""
    
    # 预设股票池
    PREDEFINED_POOLS = {
        'hs300': {
            'name': '沪深300',
            'description': '沪深300指数成分股',
            'benchmark': '000300.SH'
        },
        'sz50': {
            'name': '上证50',
            'description': '上证50指数成分股',
            'benchmark': '000016.SH'
        },
        'zz500': {
            'name': '中证500',
            'description': '中证500指数成分股',
            'benchmark': '000905.SH'
        },
        'zz1000': {
            'name': '中证1000',
            'description': '中证1000指数成分股',
            'benchmark': '000852.SH'
        },
        'cyb': {
            'name': '创业板指',
            'description': '创业板指数成分股',
            'benchmark': '399006.SZ'
        },
        'kcb': {
            'name': '科创板',
            'description': '科创板股票',
            'benchmark': '000688.SH'
        }
    }
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        初始化股票池管理
        
        Args:
            data_dir: 数据目录路径
        """
        if data_dir is None:
            # 默认使用项目目录
            self.data_dir = Path(__file__).parent.parent.parent / 'data'
        else:
            self.data_dir = Path(data_dir)
        
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.pools_file = self.data_dir / 'stock_pools.json'
    
    def list_pools(self) -> Dict[str, Dict]:
        """
        列出所有可用股票池
        
        Returns:
            {池代码: 池信息}
        """
        return self.PREDEFINED_POOLS.copy()
    
    def get_pool_stocks(self, pool_code: str) -> List[str]:
        """
        获取股票池成分股
        
        Args:
            pool_code: 股票池代码
            
        Returns:
            股票代码列表
        """
        # 尝试从本地文件加载
        pool_file = self.data_dir / f'{pool_code}.txt'
        if pool_file.exists():
            with open(pool_file, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if line.strip()]
        
        # 返回默认股票列表（示例）
        default_pools = {
            'hs300': [
                '000001.SZ', '000002.SZ', '000063.SZ', '000100.SZ', '000333.SZ',
                '000338.SZ', '000413.SZ', '000423.SZ', '000538.SZ', '000568.SZ',
                '000625.SZ', '000651.SZ', '000725.SZ', '000768.SZ', '000776.SZ',
                '000858.SZ', '000895.SZ', '002001.SZ', '002007.SZ', '002024.SZ',
                '600000.SH', '600009.SH', '600016.SH', '600028.SH', '600029.SH',
                '600030.SH', '600031.SH', '600036.SH', '600048.SH', '600050.SH',
            ],
            'sz50': [
                '600000.SH', '600016.SH', '600028.SH', '600030.SH', '600031.SH',
                '600036.SH', '600048.SH', '600050.SH', '600104.SH', '600196.SH',
                '600276.SH', '600309.SH', '600519.SH', '600547.SH', '600570.SH',
                '600585.SH', '600588.SH', '600690.SH', '600703.SH', '600837.SH',
            ],
            'zz500': [
                '000009.SZ', '000012.SZ', '000021.SZ', '000027.SZ', '000039.SZ',
                '000046.SZ', '000060.SZ', '000061.SZ', '000063.SZ', '000066.SZ',
                '600008.SH', '600011.SH', '600015.SH', '600018.SH', '600021.SH',
                '600023.SH', '600025.SH', '600026.SH', '600027.SH', '600032.SH',
            ]
        }
        
        return default_pools.get(pool_code, [])
    
    def save_pool(self, pool_code: str, stocks: List[str]) -> bool:
        """
        保存股票池成分股
        
        Args:
            pool_code: 股票池代码
            stocks: 股票代码列表
            
        Returns:
            是否成功
        """
        try:
            pool_file = self.data_dir / f'{pool_code}.txt'
            with open(pool_file, 'w', encoding='utf-8') as f:
                for stock in stocks:
                    f.write(f"{stock}\n")
            return True
        except Exception as e:
            print(f"保存股票池失败: {e}")
            return False
    
    def update_pool_from_qmt(self, pool_code: str) -> bool:
        """
        从QMT更新股票池成分股
        
        Args:
            pool_code: 股票池代码
            
        Returns:
            是否成功
        """
        try:
            # 尝试导入 xtquant
            from xtquant import xtdata
            
            # 指数代码映射
            index_map = {
                'hs300': '000300.SH',
                'sz50': '000016.SH',
                'zz500': '000905.SH',
                'zz1000': '000852.SH',
                'cyb': '399006.SZ'
            }
            
            index_code = index_map.get(pool_code)
            if not index_code:
                print(f"未知的股票池: {pool_code}")
                return False
            
            # 获取成分股
            stocks = xtdata.get_stock_list_in_sector(index_code)
            
            # 转换代码格式
            formatted_stocks = [self.format_code(s) for s in stocks]
            
            # 保存
            return self.save_pool(pool_code, formatted_stocks)
            
        except ImportError:
            print("未安装 xtquant，无法从QMT更新")
            return False
        except Exception as e:
            print(f"更新股票池失败: {e}")
            return False
    
    @staticmethod
    def format_code(code: str) -> str:
        """
        格式化股票代码
        
        Args:
            code: 原始代码（如 000001 或 sz.000001）
            
        Returns:
            标准格式代码（如 000001.SZ）
        """
        code = code.strip().upper()
        
        # 已经是标准格式
        if '.SH' in code or '.SZ' in code or '.BJ' in code:
            return code
        
        # 处理 baostock 格式（如 sz.000001）
        if '.' in code:
            parts = code.split('.')
            if len(parts) == 2:
                market = parts[0].upper()
                stock_code = parts[1]
                return f"{stock_code}.{market}"
        
        # 纯数字代码，根据规则判断市场
        if len(code) == 6:
            if code.startswith('6') or code.startswith('5'):
                return f"{code}.SH"
            elif code.startswith('0') or code.startswith('3'):
                return f"{code}.SZ"
            elif code.startswith('4') or code.startswith('8'):
                return f"{code}.BJ"
        
        return code
    
    @staticmethod
    def to_baostock_code(code: str) -> str:
        """
        转换为 baostock 格式
        
        Args:
            code: 标准格式代码（如 000001.SZ）
            
        Returns:
            baostock 格式（如 sz.000001）
        """
        if '.' in code:
            parts = code.split('.')
            return f"{parts[1].lower()}.{parts[0]}"
        return code
    
    @staticmethod
    def get_market(code: str) -> str:
        """
        获取股票所属市场
        
        Args:
            code: 股票代码
            
        Returns:
            SH/SZ/BJ
        """
        if '.SH' in code:
            return 'SH'
        elif '.SZ' in code:
            return 'SZ'
        elif '.BJ' in code:
            return 'BJ'
        return 'UNKNOWN'
    
    def create_custom_pool(self, name: str, stocks: List[str], description: str = "") -> str:
        """
        创建自定义股票池
        
        Args:
            name: 股票池名称
            stocks: 股票代码列表
            description: 描述
            
        Returns:
            股票池代码
        """
        # 生成代码
        pool_code = f"custom_{name.lower().replace(' ', '_')}"
        
        # 保存成分股
        self.save_pool(pool_code, stocks)
        
        # 保存配置
        config = {
            'name': name,
            'description': description,
            'type': 'custom',
            'count': len(stocks)
        }
        
        config_file = self.data_dir / f'{pool_code}_config.json'
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        return pool_code


# 全局股票池实例
_pool_manager: Optional[StockPool] = None


def get_pool_manager() -> StockPool:
    """获取全局股票池管理实例"""
    global _pool_manager
    if _pool_manager is None:
        _pool_manager = StockPool()
    return _pool_manager


def get_pool_stocks(pool_code: str) -> List[str]:
    """便捷函数：获取股票池成分股"""
    return get_pool_manager().get_pool_stocks(pool_code)


def list_pools() -> Dict[str, Dict]:
    """便捷函数：列出所有股票池"""
    return get_pool_manager().list_pools()


def format_code(code: str) -> str:
    """便捷函数：格式化股票代码"""
    return StockPool.format_code(code)
