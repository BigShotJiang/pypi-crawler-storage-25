# -*- coding: utf-8 -*-
"""
策略开发 CLI 子命令

提供基于 CLI 的策略开发功能，无需编写 Python 代码：
- strategy-dev create: 交互式创建策略
- strategy-dev edit: 编辑策略参数
- strategy-dev test: 快速测试策略逻辑
- strategy-dev optimize: 参数优化
- strategy-dev list-templates: 列出策略模板
"""

import argparse
import json
import sys
import os
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from .database.api import StockAPI
from .backtest.pools import StockPool


# 策略模板库
STRATEGY_TEMPLATES = {
    'ma_cross': {
        'name': '均线交叉策略',
        'description': '基于短期和长期均线金叉死叉进行买卖',
        'params': {
            'short_window': {'type': 'int', 'default': 5, 'min': 2, 'max': 30, 'description': '短期均线周期'},
            'long_window': {'type': 'int', 'default': 20, 'min': 5, 'max': 120, 'description': '长期均线周期'},
            'stop_loss': {'type': 'float', 'default': 0.05, 'min': 0.01, 'max': 0.5, 'description': '止损比例'},
            'take_profit': {'type': 'float', 'default': 0.1, 'min': 0.01, 'max': 1.0, 'description': '止盈比例'},
        },
        'logic': 'ma_cross'
    },
    'macd': {
        'name': 'MACD策略',
        'description': '基于MACD指标金叉死叉进行买卖',
        'params': {
            'fast': {'type': 'int', 'default': 12, 'min': 5, 'max': 30, 'description': '快线周期'},
            'slow': {'type': 'int', 'default': 26, 'min': 10, 'max': 60, 'description': '慢线周期'},
            'signal': {'type': 'int', 'default': 9, 'min': 5, 'max': 20, 'description': '信号线周期'},
            'stop_loss': {'type': 'float', 'default': 0.05, 'min': 0.01, 'max': 0.5, 'description': '止损比例'},
        },
        'logic': 'macd'
    },
    'rsi': {
        'name': 'RSI策略',
        'description': '基于RSI超买超卖进行买卖',
        'params': {
            'period': {'type': 'int', 'default': 14, 'min': 5, 'max': 30, 'description': 'RSI周期'},
            'overbought': {'type': 'int', 'default': 70, 'min': 50, 'max': 90, 'description': '超买阈值'},
            'oversold': {'type': 'int', 'default': 30, 'min': 10, 'max': 50, 'description': '超卖阈值'},
        },
        'logic': 'rsi'
    },
    'bollinger': {
        'name': '布林带策略',
        'description': '基于布林带上下轨进行买卖',
        'params': {
            'period': {'type': 'int', 'default': 20, 'min': 10, 'max': 60, 'description': '布林带周期'},
            'std_dev': {'type': 'float', 'default': 2.0, 'min': 1.0, 'max': 4.0, 'description': '标准差倍数'},
        },
        'logic': 'bollinger'
    },
    'momentum': {
        'name': '动量策略',
        'description': '基于价格动量进行买卖',
        'params': {
            'lookback': {'type': 'int', 'default': 20, 'min': 5, 'max': 60, 'description': '动量计算周期'},
            'threshold': {'type': 'float', 'default': 0.05, 'min': 0.01, 'max': 0.5, 'description': '动量阈值'},
        },
        'logic': 'momentum'
    },
}


def cmd_strategy_dev_create(args):
    """交互式创建策略"""
    print("\n  ══════════════════════════════════════════════════")
    print("  策略创建向导")
    print("  ══════════════════════════════════════════════════\n")
    
    # 1. 选择模板
    if args.interactive and not args.template:
        # 交互模式：显示模板列表供选择
        print("  可用策略模板:")
        for i, (code, template) in enumerate(STRATEGY_TEMPLATES.items(), 1):
            print(f"    {i}. {template['name']} - {template['description']}")
        
        try:
            choice = input("\n  请选择模板编号或名称: ").strip()
            if choice.isdigit():
                idx = int(choice) - 1
                selected = list(STRATEGY_TEMPLATES.keys())[idx]
            else:
                selected = choice
        except (ValueError, IndexError):
            print("  错误: 无效选择")
            sys.exit(1)
    elif args.template:
        # 非交互模式：使用命令行参数
        if args.template not in STRATEGY_TEMPLATES:
            print(f"\n  错误: 未知模板 '{args.template}'")
            sys.exit(1)
        selected = args.template
    else:
        # 非交互模式但没有指定模板，使用默认
        selected = 'ma_cross'
        print(f"  未指定模板，使用默认: {STRATEGY_TEMPLATES[selected]['name']}")
    
    if selected not in STRATEGY_TEMPLATES:
        print(f"  错误: 未知模板 '{selected}'")
        sys.exit(1)
    
    template = STRATEGY_TEMPLATES[selected]
    print(f"\n  已选择: {template['name']}\n")
    
    # 2. 配置参数
    params = {}
    if args.interactive:
        print("  策略参数配置 (直接回车使用默认值):")
    
    for param_name, param_config in template['params'].items():
        default = param_config['default']
        
        if args.interactive:
            prompt = f"    {param_config['description']} [{default}]: "
            value = input(prompt).strip()
            if not value:
                value = default
            else:
                # 类型转换
                if param_config['type'] == 'int':
                    value = int(value)
                elif param_config['type'] == 'float':
                    value = float(value)
        else:
            value = default
        
        params[param_name] = value
        if args.interactive:
            print(f"      {param_name} = {value}")
    
    # 3. 保存策略
    strategy_config = {
        'name': args.name or f"{template['name']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        'template': selected,
        'description': template['description'],
        'params': params,
        'created_at': datetime.now().isoformat(),
    }
    
    # 保存到文件
    output_dir = Path(args.output_dir) if args.output_dir else Path('strategies')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_file = output_dir / f"{strategy_config['name']}.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(strategy_config, f, indent=2, ensure_ascii=False)
    
    print(f"\n  ✓ 策略已保存: {output_file}")
    print(f"\n  使用以下命令进行回测:")
    print(f"    python -m claw_quant.cli strategy-dev backtest {output_file} --codes 000001.SZ --start 2024-01-01 --end 2024-06-01")
    print()


def cmd_strategy_dev_edit(args):
    """编辑策略参数"""
    config_file = Path(args.file)
    
    if not config_file.exists():
        print(f"\n  错误: 策略文件不存在: {config_file}\n")
        sys.exit(1)
    
    # 读取现有配置
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    print(f"\n  编辑策略: {config['name']}\n")
    print("  当前参数:")
    for param_name, value in config['params'].items():
        print(f"    {param_name} = {value}")
    
    if args.param:
        # 直接修改指定参数
        for param_str in args.param:
            if '=' not in param_str:
                print(f"  错误: 参数格式错误 '{param_str}'，应为 'name=value'")
                continue
            name, value = param_str.split('=', 1)
            name = name.strip()
            value = value.strip()
            
            # 尝试类型转换
            if name in config['params']:
                old_value = config['params'][name]
                if isinstance(old_value, int):
                    value = int(value)
                elif isinstance(old_value, float):
                    value = float(value)
            
            config['params'][name] = value
            print(f"  已更新: {name} = {value}")
    
    # 保存
    config['updated_at'] = datetime.now().isoformat()
    
    with open(config_file, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    print(f"\n  ✓ 策略已更新\n")


def cmd_strategy_dev_backtest(args):
    """回测策略配置"""
    config_file = Path(args.file)
    
    if not config_file.exists():
        print(f"\n  错误: 策略文件不存在: {config_file}\n")
        sys.exit(1)
    
    # 读取配置
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    print(f"\n  回测策略: {config['name']}")
    print(f"  模板: {config['template']}")
    print(f"  参数: {config['params']}\n")
    
    # 构建策略代码
    template_code = config['template']
    params = config['params']
    
    # 模板到策略代码的映射
    TEMPLATE_TO_STRATEGY = {
        'ma_cross': 'CROSS_STRATEGY',
        'macd': 'MACD_STRATEGY',
        'rsi': 'RSI_STRATEGY',
        'bollinger': 'BOLLINGER_STRATEGY',
        'momentum': 'MOMENTUM_STRATEGY',
        'breakout': 'BREAKOUT_STRATEGY',
    }
    
    # 调用 strategy backtest 命令
    import subprocess
    
    # 构建参数
    strategy_name = TEMPLATE_TO_STRATEGY.get(template_code, template_code.upper() + '_STRATEGY')
    params_json = json.dumps(params)
    
    cmd = [
        'python', '-m', 'claw_quant.cli', 'strategy', 'backtest',
        strategy_name,
        '--codes', args.codes,
        '--start', args.start,
        '--end', args.end,
        '--params', params_json
    ]
    
    if args.capital:
        cmd.extend(['--capital', str(args.capital)])
    
    print(f"  执行: {' '.join(cmd)}\n")
    
    # 使用 UTF-8 编码处理子进程输出
    result = subprocess.run(cmd, capture_output=True)
    try:
        stdout = result.stdout.decode('utf-8', errors='replace')
        stderr = result.stderr.decode('utf-8', errors='replace')
    except:
        stdout = result.stdout.decode('gbk', errors='replace') if result.stdout else ''
        stderr = result.stderr.decode('gbk', errors='replace') if result.stderr else ''
    
    print(stdout)
    if stderr:
        print(stderr, file=sys.stderr)
    
    return result.returncode


def cmd_strategy_dev_list_templates(args):
    """列出策略模板"""
    print("\n  ══════════════════════════════════════════════════")
    print("  策略模板列表")
    print("  ══════════════════════════════════════════════════\n")
    
    for code, template in STRATEGY_TEMPLATES.items():
        print(f"  【{template['name']}】")
        print(f"  代码: {code}")
        print(f"  描述: {template['description']}")
        print(f"  参数:")
        for param_name, param_config in template['params'].items():
            print(f"    - {param_name}: {param_config['description']} (默认: {param_config['default']})")
        print()


def cmd_strategy_dev_optimize(args):
    """参数优化"""
    config_file = Path(args.file)
    
    if not config_file.exists():
        print(f"\n  错误: 策略文件不存在: {config_file}\n")
        sys.exit(1)
    
    # 读取配置
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    print(f"\n  参数优化: {config['name']}")
    print(f"  优化参数: {args.param}")
    print(f"  范围: {args.range}\n")
    
    # TODO: 实现网格搜索优化
    print("  参数优化功能开发中...\n")


def setup_strategy_dev_parser(subparsers):
    """设置 strategy-dev 子命令解析器"""
    dev_parser = subparsers.add_parser(
        'strategy-dev',
        help='策略开发工具（无需编写代码）',
        description='提供基于 CLI 的策略开发功能，包括创建、编辑、回测、优化等。'
    )
    dev_subparsers = dev_parser.add_subparsers(dest='dev_command', help='策略开发命令')
    
    # create 命令
    create_parser = dev_subparsers.add_parser(
        'create',
        help='交互式创建策略',
        description='通过向导交互式创建策略配置文件，无需编写代码。'
    )
    create_parser.add_argument('--name', help='策略名称')
    create_parser.add_argument('--template', help='策略模板代码')
    create_parser.add_argument('--output-dir', help='输出目录')
    create_parser.add_argument('--interactive', action='store_true', default=False, help='交互模式（默认非交互）')
    create_parser.set_defaults(func=cmd_strategy_dev_create)
    
    # edit 命令
    edit_parser = dev_subparsers.add_parser(
        'edit',
        help='编辑策略参数',
        description='编辑策略配置文件中的参数。'
    )
    edit_parser.add_argument('file', help='策略配置文件路径')
    edit_parser.add_argument('--param', action='append', help='修改参数，格式: name=value')
    edit_parser.set_defaults(func=cmd_strategy_dev_edit)
    
    # backtest 命令
    backtest_parser = dev_subparsers.add_parser(
        'backtest',
        help='回测策略配置',
        description='回测策略配置文件。'
    )
    backtest_parser.add_argument('file', help='策略配置文件路径')
    backtest_parser.add_argument('--codes', required=True, help='股票代码，逗号分隔')
    backtest_parser.add_argument('--start', required=True, help='开始日期 YYYY-MM-DD')
    backtest_parser.add_argument('--end', required=True, help='结束日期 YYYY-MM-DD')
    backtest_parser.add_argument('--capital', type=float, help='初始资金')
    backtest_parser.set_defaults(func=cmd_strategy_dev_backtest)
    
    # list-templates 命令
    list_parser = dev_subparsers.add_parser(
        'list-templates',
        help='列出策略模板',
        description='显示所有可用的策略模板及其参数。'
    )
    list_parser.set_defaults(func=cmd_strategy_dev_list_templates)
    
    # optimize 命令
    optimize_parser = dev_subparsers.add_parser(
        'optimize',
        help='参数优化',
        description='对策略参数进行网格搜索优化。'
    )
    optimize_parser.add_argument('file', help='策略配置文件路径')
    optimize_parser.add_argument('--param', required=True, help='要优化的参数名')
    optimize_parser.add_argument('--range', required=True, help='参数范围，格式: start,end,step')
    optimize_parser.add_argument('--codes', required=True, help='股票代码')
    optimize_parser.add_argument('--start', required=True, help='开始日期')
    optimize_parser.add_argument('--end', required=True, help='结束日期')
    optimize_parser.set_defaults(func=cmd_strategy_dev_optimize)
