"""
主窗口 - PyQt5实现
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QComboBox, QDateEdit, QSpinBox,
    QDoubleSpinBox, QTextEdit, QProgressBar, QMessageBox,
    QFileDialog, QSplitter, QFrame, QGroupBox, QGridLayout,
    QHeaderView, QMenu, QAction, QToolBar, QStatusBar
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QDate
from PyQt5.QtGui import QFont, QColor, QBrush
from datetime import date, datetime, timedelta
import pandas as pd
import logging

from claw_quant.database.storage.db_client import DBClient
from claw_quant.data_updater import MarketDataUpdater, create_default_scheduler
from claw_quant.factor_library import FactorManager
from claw_quant.strategy_library import StrategyManager
from claw_quant.backtest import BacktestEngine, BacktestTaskManager
from .download_dialog import DataDownloadDialog
from .backtest_dialog import BacktestTaskDialog
from .viewer import StockViewerWidget
from .bulk_downloader import BulkDataDownloaderDialog

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataUpdateThread(QThread):
    """数据更新线程"""
    progress = pyqtSignal(int)
    message = pyqtSignal(str)
    finished_signal = pyqtSignal(bool)
    
    def __init__(self, updater, task_type, **kwargs):
        super().__init__()
        self.updater = updater
        self.task_type = task_type
        self.kwargs = kwargs
        
    def run(self):
        try:
            self.message.emit(f"开始{self.task_type}...")
            
            if self.task_type == 'stock_info':
                self.updater.update_stock_info()
            elif self.task_type == 'daily_data':
                stats = self.updater.update_daily_data(**self.kwargs)
                self.message.emit(f"更新完成: 成功{stats['success']}, 失败{stats['failed']}")
            elif self.task_type == 'realtime':
                self.updater.update_realtime_quotes(**self.kwargs)
                
            self.progress.emit(100)
            self.finished_signal.emit(True)
            
        except Exception as e:
            self.message.emit(f"更新失败: {e}")
            self.finished_signal.emit(False)


class BacktestThread(QThread):
    """回测线程"""
    progress = pyqtSignal(float)
    message = pyqtSignal(str)
    finished_signal = pyqtSignal(dict)
    
    def __init__(self, engine, **kwargs):
        super().__init__()
        self.engine = engine
        self.kwargs = kwargs
        
    def run(self):
        try:
            self.message.emit("开始回测...")
            self.engine.setup(
                progress_callback=self.progress.emit,
                **self.kwargs
            )
            results = self.engine.run()
            self.finished_signal.emit(results)
            
        except Exception as e:
            self.message.emit(f"回测失败: {e}")
            self.finished_signal.emit({})


class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ClawQuant - 量化交易系统")
        self.setGeometry(100, 100, 1400, 900)
        
        # 初始化组件
        self.db = None
        self.updater = None
        self.factor_manager = None
        self.strategy_manager = None
        self.scheduler = None
        
        # 初始化UI
        self.init_ui()
        self.init_database()
        
    def init_ui(self):
        """初始化UI"""
        # 创建工具栏
        toolbar = QToolBar()
        self.addToolBar(toolbar)
        
        toolbar.addAction("连接数据库", self.init_database)
        toolbar.addSeparator()
        toolbar.addAction("数据下载", self.open_data_download)
        toolbar.addAction("批量下载", self.open_bulk_download)
        toolbar.addSeparator()
        toolbar.addAction("启动调度", self.start_scheduler)
        toolbar.addAction("停止调度", self.stop_scheduler)
        toolbar.addSeparator()
        toolbar.addAction("多任务回测", self.open_backtest_tasks)
        toolbar.addSeparator()
        toolbar.addAction("关于", self.show_about)
        
        # 创建状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪")
        
        # 创建标签页
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # 先添加占位标签页
        self.tabs.addTab(QWidget(), "股票浏览")
        self.tabs.addTab(self.create_data_tab(), "数据管理")
        self.tabs.addTab(self.create_factor_tab(), "因子库")
        self.tabs.addTab(self.create_strategy_tab(), "策略库")
        self.tabs.addTab(self.create_backtest_tab(), "回测")
        self.tabs.addTab(self.create_monitor_tab(), "实时监控")

        # 启动时自动连接数据库
        self.init_database()
        
    def init_database(self):
        """初始化数据库 - 通过TCP连接"""
        try:
            self.db = DBClient(host='127.0.0.1', port=9528)
            if not self.db.ping():
                raise ConnectionError("无法连接到数据库服务器")
            
            self.status_bar.showMessage("数据库已连接: 127.0.0.1:9528")
            
            # 初始化管理器
            self.factor_manager = FactorManager(self.db)
            self.strategy_manager = StrategyManager(self.db)
            
            # 刷新数据
            self.refresh_data_stats()
            self.refresh_factor_list()
            self.refresh_strategy_list()

            # 创建并替换股票浏览页
            stock_viewer = StockViewerWidget(self.db)
            old_widget = self.tabs.widget(0)
            self.tabs.removeTab(0)
            self.tabs.insertTab(0, stock_viewer, "股票浏览")
            if old_widget:
                old_widget.deleteLater()

        except Exception as e:
            QMessageBox.critical(self, "错误", f"数据库连接失败: {e}\n\n请确保数据库API服务器已启动:\npython -m database.db_api_server")

    def create_data_tab(self) -> QWidget:
        """创建数据管理页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 数据概览
        overview_group = QGroupBox("数据概览")
        overview_layout = QGridLayout(overview_group)
        
        self.stats_labels = {}
        stats = ['股票数量', '日线记录', '最新日期', '因子数量', '策略数量']
        for i, stat in enumerate(stats):
            overview_layout.addWidget(QLabel(f"{stat}:"), i, 0)
            self.stats_labels[stat] = QLabel("-")
            overview_layout.addWidget(self.stats_labels[stat], i, 1)
            
        layout.addWidget(overview_group)
        
        # 数据更新
        update_group = QGroupBox("数据更新")
        update_layout = QVBoxLayout(update_group)
        
        # 股票信息更新
        btn_stock_info = QPushButton("更新股票列表")
        btn_stock_info.clicked.connect(self.update_stock_info)
        update_layout.addWidget(btn_stock_info)
        
        # 日线数据更新
        daily_layout = QHBoxLayout()
        daily_layout.addWidget(QLabel("开始日期:"))
        self.date_start = QDateEdit()
        self.date_start.setDate(QDate.currentDate().addDays(-365))
        self.date_start.setCalendarPopup(True)
        daily_layout.addWidget(self.date_start)
        
        daily_layout.addWidget(QLabel("结束日期:"))
        self.date_end = QDateEdit()
        self.date_end.setDate(QDate.currentDate())
        self.date_end.setCalendarPopup(True)
        daily_layout.addWidget(self.date_end)
        
        btn_daily = QPushButton("更新日线数据")
        btn_daily.clicked.connect(self.update_daily_data)
        daily_layout.addWidget(btn_daily)
        
        update_layout.addLayout(daily_layout)
        
        # 进度条
        self.progress_data = QProgressBar()
        update_layout.addWidget(self.progress_data)
        
        # 日志
        self.log_data = QTextEdit()
        self.log_data.setMaximumHeight(150)
        update_layout.addWidget(self.log_data)
        
        layout.addWidget(update_group)
        
        # 数据查询
        query_group = QGroupBox("数据查询")
        query_layout = QVBoxLayout(query_group)
        
        query_input_layout = QHBoxLayout()
        query_input_layout.addWidget(QLabel("股票代码:"))
        self.input_code = QTextEdit()
        self.input_code.setMaximumHeight(30)
        self.input_code.setPlaceholderText("输入股票代码，如: 000001.SZ")
        query_input_layout.addWidget(self.input_code)
        
        btn_query = QPushButton("查询")
        btn_query.clicked.connect(self.query_stock_data)
        query_input_layout.addWidget(btn_query)
        
        query_layout.addLayout(query_input_layout)
        
        self.table_data = QTableWidget()
        self.table_data.setColumnCount(0)
        self.table_data.setRowCount(0)
        query_layout.addWidget(self.table_data)
        
        layout.addWidget(query_group)
        
        return widget
        
    def create_factor_tab(self) -> QWidget:
        """创建因子库页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 因子列表
        list_layout = QHBoxLayout()
        
        self.list_factors = QTableWidget()
        self.list_factors.setColumnCount(5)
        self.list_factors.setHorizontalHeaderLabels(['代码', '名称', '分类', '描述', '状态'])
        self.list_factors.horizontalHeader().setStretchLastSection(True)
        list_layout.addWidget(self.list_factors)
        
        # 因子操作
        btn_layout = QVBoxLayout()
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.refresh_factor_list)
        btn_layout.addWidget(btn_refresh)
        
        btn_calc = QPushButton("计算因子")
        btn_calc.clicked.connect(self.calculate_factors)
        btn_layout.addWidget(btn_calc)
        
        btn_layout.addStretch()
        list_layout.addLayout(btn_layout)
        
        layout.addLayout(list_layout)
        
        # 因子值查询
        query_layout = QHBoxLayout()
        query_layout.addWidget(QLabel("日期:"))
        self.factor_date = QDateEdit()
        self.factor_date.setDate(QDate.currentDate())
        self.factor_date.setCalendarPopup(True)
        query_layout.addWidget(self.factor_date)
        
        query_layout.addWidget(QLabel("因子:"))
        self.combo_factor = QComboBox()
        query_layout.addWidget(self.combo_factor)
        
        btn_query_factor = QPushButton("查询")
        btn_query_factor.clicked.connect(self.query_factor_values)
        query_layout.addWidget(btn_query_factor)
        
        query_layout.addStretch()
        layout.addLayout(query_layout)
        
        # 因子值表格
        self.table_factors = QTableWidget()
        self.table_factors.setColumnCount(6)
        self.table_factors.setHorizontalHeaderLabels(['日期', '代码', '因子', '值', '排名', '分位数'])
        layout.addWidget(self.table_factors)
        
        return widget
        
    def create_strategy_tab(self) -> QWidget:
        """创建策略库页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 策略列表
        self.list_strategies = QTableWidget()
        self.list_strategies.setColumnCount(5)
        self.list_strategies.setHorizontalHeaderLabels(['代码', '名称', '类型', '描述', '状态'])
        self.list_strategies.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.list_strategies)
        
        # 策略操作
        btn_layout = QHBoxLayout()
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.refresh_strategy_list)
        btn_layout.addWidget(btn_refresh)
        
        btn_signal = QPushButton("生成信号")
        btn_signal.clicked.connect(self.generate_signals)
        btn_layout.addWidget(btn_signal)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        # 信号列表
        self.table_signals = QTableWidget()
        self.table_signals.setColumnCount(7)
        self.table_signals.setHorizontalHeaderLabels(
            ['时间', '策略', '代码', '类型', '强度', '价格', '原因']
        )
        layout.addWidget(self.table_signals)
        
        return widget
        
    def create_backtest_tab(self) -> QWidget:
        """创建回测页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 回测配置
        config_group = QGroupBox("回测配置")
        config_layout = QGridLayout(config_group)
        
        config_layout.addWidget(QLabel("策略:"), 0, 0)
        self.combo_strategy = QComboBox()
        config_layout.addWidget(self.combo_strategy, 0, 1)
        
        config_layout.addWidget(QLabel("开始日期:"), 1, 0)
        self.bt_start_date = QDateEdit()
        self.bt_start_date.setDate(QDate.currentDate().addDays(-365))
        self.bt_start_date.setCalendarPopup(True)
        config_layout.addWidget(self.bt_start_date, 1, 1)
        
        config_layout.addWidget(QLabel("结束日期:"), 2, 0)
        self.bt_end_date = QDateEdit()
        self.bt_end_date.setDate(QDate.currentDate())
        self.bt_end_date.setCalendarPopup(True)
        config_layout.addWidget(self.bt_end_date, 2, 1)
        
        config_layout.addWidget(QLabel("初始资金:"), 3, 0)
        self.spin_capital = QSpinBox()
        self.spin_capital.setRange(100000, 100000000)
        self.spin_capital.setValue(1000000)
        self.spin_capital.setSingleStep(100000)
        config_layout.addWidget(self.spin_capital, 3, 1)
        
        btn_run = QPushButton("运行回测")
        btn_run.clicked.connect(self.run_backtest)
        config_layout.addWidget(btn_run, 4, 0, 1, 2)
        
        layout.addWidget(config_group)
        
        # 进度
        self.progress_backtest = QProgressBar()
        layout.addWidget(self.progress_backtest)
        
        # 结果
        result_group = QGroupBox("回测结果")
        result_layout = QVBoxLayout(result_group)
        
        self.text_result = QTextEdit()
        self.text_result.setReadOnly(True)
        result_layout.addWidget(self.text_result)
        
        layout.addWidget(result_group)
        
        return widget
        
    def create_monitor_tab(self) -> QWidget:
        """创建实时监控页"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # 实时行情
        layout.addWidget(QLabel("实时行情"))
        self.table_realtime = QTableWidget()
        self.table_realtime.setColumnCount(5)
        self.table_realtime.setHorizontalHeaderLabels(['代码', '价格', '涨跌幅', '成交量', '更新时间'])
        layout.addWidget(self.table_realtime)
        
        # 持仓
        layout.addWidget(QLabel("当前持仓"))
        self.table_positions = QTableWidget()
        self.table_positions.setColumnCount(6)
        self.table_positions.setHorizontalHeaderLabels(
            ['代码', '数量', '成本', '现价', '市值', '盈亏']
        )
        layout.addWidget(self.table_positions)
        
        return widget
        
    # ============================================
    # 数据管理功能
    # ============================================
    
    def refresh_data_stats(self):
        """刷新数据统计"""
        if not self.db:
            return
            
        try:
            # 股票数量
            stock_count = self.db.get_table_count('stocks')
            self.stats_labels['股票数量'].setText(str(stock_count))
            
            # 日线记录
            daily_count = self.db.get_table_count('market_data_daily')
            self.stats_labels['日线记录'].setText(str(daily_count))
            
            # 最新日期
            latest_date = self.db.get_latest_trade_date()
            self.stats_labels['最新日期'].setText(str(latest_date) if latest_date else '-')
            
            # 因子数量
            factor_count = self.db.get_table_count('factor_definitions')
            self.stats_labels['因子数量'].setText(str(factor_count))
            
            # 策略数量
            strategy_count = self.db.get_table_count('strategy_definitions')
            self.stats_labels['策略数量'].setText(str(strategy_count))
            
        except Exception as e:
            logger.error(f"刷新统计失败: {e}")
            
    def update_stock_info(self):
        """更新股票信息"""
        if not self.db:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            if not self.updater:
                self.updater = MarketDataUpdater(self.db)
                
            self.thread = DataUpdateThread(self.updater, 'stock_info')
            self.thread.message.connect(self.log_data.append)
            self.thread.finished_signal.connect(lambda x: self.refresh_data_stats())
            self.thread.start()
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"更新失败: {e}")
            
    def update_daily_data(self):
        """更新日线数据"""
        if not self.db:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            if not self.updater:
                self.updater = MarketDataUpdater(self.db)
                
            start = self.date_start.date().toPyDate()
            end = self.date_end.date().toPyDate()
            
            self.thread = DataUpdateThread(
                self.updater, 'daily_data',
                start_date=start, end_date=end
            )
            self.thread.message.connect(self.log_data.append)
            self.thread.finished_signal.connect(lambda x: self.refresh_data_stats())
            self.thread.start()
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"更新失败: {e}")
            
    def query_stock_data(self):
        """查询股票数据"""
        if not self.db:
            return
            
        code = self.input_code.toPlainText().strip()
        if not code:
            return
            
        try:
            df = self.db.get_market_data_daily(
                code,
                date.today() - timedelta(days=30),
                date.today()
            )
            
            if df.empty:
                QMessageBox.information(self, "提示", "无数据")
                return
                
            self.table_data.setColumnCount(len(df.columns))
            self.table_data.setHorizontalHeaderLabels(df.columns.tolist())
            self.table_data.setRowCount(len(df))
            
            for i, row in df.iterrows():
                for j, col in enumerate(df.columns):
                    self.table_data.setItem(i, j, QTableWidgetItem(str(row[col])))
                    
        except Exception as e:
            QMessageBox.critical(self, "错误", f"查询失败: {e}")
            
    # ============================================
    # 因子库功能
    # ============================================
    
    def refresh_factor_list(self):
        """刷新因子列表"""
        if not self.db:
            return
            
        try:
            df = self.db.get_factor_definitions()
            
            self.list_factors.setRowCount(len(df))
            self.combo_factor.clear()
            
            for i, row in df.iterrows():
                self.list_factors.setItem(i, 0, QTableWidgetItem(row['factor_code']))
                self.list_factors.setItem(i, 1, QTableWidgetItem(row['factor_name']))
                self.list_factors.setItem(i, 2, QTableWidgetItem(row['category']))
                self.list_factors.setItem(i, 3, QTableWidgetItem(row['description']))
                self.list_factors.setItem(i, 4, QTableWidgetItem('启用' if row['is_active'] else '禁用'))
                
                self.combo_factor.addItem(row['factor_code'])
                
        except Exception as e:
            logger.error(f"刷新因子列表失败: {e}")
            
    def calculate_factors(self):
        """计算因子"""
        if not self.factor_manager:
            return
            
        try:
            calc_date = self.factor_date.date().toPyDate()
            self.factor_manager.calculate_all_factors(calc_date)
            QMessageBox.information(self, "成功", "因子计算完成")
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"计算失败: {e}")
            
    def query_factor_values(self):
        """查询因子值"""
        if not self.db:
            return
            
        try:
            calc_date = self.factor_date.date().toPyDate()
            factor_code = self.combo_factor.currentText()
            
            df = self.db.get_factor_values([factor_code], calc_date)
            
            if df.empty:
                return
                
            self.table_factors.setRowCount(len(df))
            
            for i, row in df.iterrows():
                self.table_factors.setItem(i, 0, QTableWidgetItem(str(row['calc_date'])))
                self.table_factors.setItem(i, 1, QTableWidgetItem(row['code']))
                self.table_factors.setItem(i, 2, QTableWidgetItem(row['factor_code']))
                self.table_factors.setItem(i, 3, QTableWidgetItem(f"{row['value']:.4f}"))
                self.table_factors.setItem(i, 4, QTableWidgetItem(f"{row['rank_value']:.0f}"))
                self.table_factors.setItem(i, 5, QTableWidgetItem(f"{row['percentile']:.2%}"))
                
        except Exception as e:
            QMessageBox.critical(self, "错误", f"查询失败: {e}")
            
    # ============================================
    # 策略库功能
    # ============================================
    
    def refresh_strategy_list(self):
        """刷新策略列表"""
        if not self.db:
            return
            
        try:
            df = self.db.conn.execute(
                "SELECT * FROM strategy_definitions ORDER BY created_at DESC"
            ).fetchdf()
            
            self.list_strategies.setRowCount(len(df))
            self.combo_strategy.clear()
            
            for i, row in df.iterrows():
                self.list_strategies.setItem(i, 0, QTableWidgetItem(row['strategy_code']))
                self.list_strategies.setItem(i, 1, QTableWidgetItem(row['strategy_name']))
                self.list_strategies.setItem(i, 2, QTableWidgetItem(row['strategy_type']))
                self.list_strategies.setItem(i, 3, QTableWidgetItem(row['description'] or ''))
                self.list_strategies.setItem(i, 4, QTableWidgetItem(row['status']))
                
                self.combo_strategy.addItem(row['strategy_code'])
                
        except Exception as e:
            logger.error(f"刷新策略列表失败: {e}")
            
    def generate_signals(self):
        """生成信号"""
        if not self.strategy_manager:
            return
            
        try:
            current_date = datetime.now()
            signals = self.strategy_manager.generate_all_signals(current_date)
            
            # 显示信号
            all_signals = []
            for strategy_code, sig_list in signals.items():
                all_signals.extend(sig_list)
                
            self.table_signals.setRowCount(len(all_signals))
            
            for i, signal in enumerate(all_signals):
                self.table_signals.setItem(i, 0, QTableWidgetItem(str(signal.signal_time)))
                self.table_signals.setItem(i, 1, QTableWidgetItem(signal.strategy_code))
                self.table_signals.setItem(i, 2, QTableWidgetItem(signal.code))
                self.table_signals.setItem(i, 3, QTableWidgetItem(signal.signal_type.value))
                self.table_signals.setItem(i, 4, QTableWidgetItem(f"{signal.strength:.2f}"))
                self.table_signals.setItem(i, 5, QTableWidgetItem(f"{signal.price:.2f}"))
                self.table_signals.setItem(i, 6, QTableWidgetItem(signal.reason))
                
        except Exception as e:
            QMessageBox.critical(self, "错误", f"生成信号失败: {e}")
            
    # ============================================
    # 回测功能
    # ============================================
    
    def run_backtest(self):
        """运行回测"""
        if not self.db or not self.strategy_manager:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            strategy_code = self.combo_strategy.currentText()
            start_date = self.bt_start_date.date().toPyDate()
            end_date = self.bt_end_date.date().toPyDate()
            initial_capital = self.spin_capital.value()
            
            engine = BacktestEngine(self.db, self.strategy_manager)
            
            self.bt_thread = BacktestThread(
                engine,
                strategy_code=strategy_code,
                start_date=start_date,
                end_date=end_date,
                initial_capital=initial_capital
            )
            self.bt_thread.progress.connect(self.progress_backtest.setValue)
            self.bt_thread.message.connect(self.text_result.append)
            self.bt_thread.finished_signal.connect(self.show_backtest_results)
            self.bt_thread.start()
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"回测失败: {e}")
            
    def show_backtest_results(self, results: dict):
        """显示回测结果"""
        if not results:
            return
            
        text = f"""
回测完成!
==========
总收益率: {results.get('total_return', 0):.2%}
年化收益率: {results.get('annual_return', 0):.2%}
夏普比率: {results.get('sharpe_ratio', 0):.2f}
最大回撤: {results.get('max_drawdown', 0):.2%}
最终资金: {results.get('final_value', 0):,.2f}
总盈亏: {results.get('total_pnl', 0):,.2f}
交易次数: {results.get('trade_count', 0)}
        """
        self.text_result.append(text)
        
    # ============================================
    # 调度器功能
    # ============================================
    
    def start_scheduler(self):
        """启动调度器"""
        if not self.db:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            self.scheduler = create_default_scheduler(self.db)
            self.scheduler.start()
            self.status_bar.showMessage("调度器已启动")
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"启动失败: {e}")
            
    def stop_scheduler(self):
        """停止调度器"""
        if self.scheduler:
            self.scheduler.shutdown()
            self.scheduler = None
            self.status_bar.showMessage("调度器已停止")
            
    def show_about(self):
        """显示关于"""
        QMessageBox.about(
            self,
            "关于",
            "ClawQuant - 量化交易系统\n\n"
            "版本: 1.0.0\n"
            "基于 DuckDB + PyQt5"
        )
        
    def open_data_download(self):
        """打开数据下载对话框"""
        if not self.db:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            dialog = DataDownloadDialog(self.db, self)
            dialog.exec_()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"打开数据下载失败: {e}")
            
    def open_backtest_tasks(self):
        """打开多任务回测对话框"""
        if not self.db or not self.strategy_manager:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            dialog = BacktestTaskDialog(self.db, self.strategy_manager, self)
            dialog.exec_()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"打开回测任务管理失败: {e}")

    def open_bulk_download(self):
        """打开批量数据下载对话框"""
        if not self.db:
            QMessageBox.warning(self, "警告", "请先连接数据库")
            return
            
        try:
            dialog = BulkDataDownloaderDialog(self.db, self)
            dialog.exec_()
            # 刷新数据
            self.refresh_data_stats()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"打开批量下载失败: {e}")


def main():
    """主函数"""
    from PyQt5.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    
    # 设置样式
    app.setStyle('Fusion')
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
