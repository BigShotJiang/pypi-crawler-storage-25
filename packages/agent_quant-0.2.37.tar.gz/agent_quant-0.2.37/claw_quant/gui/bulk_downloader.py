"""
批量数据下载工具 - 下载全市场历史数据
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QTextEdit, QGroupBox, QGridLayout,
    QSpinBox, QDateEdit, QCheckBox, QMessageBox, QComboBox
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QDate
from datetime import date, datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BulkDownloadWorker(QThread):
    """批量下载工作线程"""
    progress = pyqtSignal(int)  # 总体进度
    stock_progress = pyqtSignal(str, int, int)  # 当前股票, 当前数量, 总数量
    message = pyqtSignal(str)
    finished_signal = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, db_manager, qmt_path=None, years=5, batch_size=50, markets=None):
        super().__init__()
        self.db = db_manager
        self.qmt_path = qmt_path
        self.years = years
        self.batch_size = batch_size
        self.markets = markets or ['all']
        self._is_running = True
        self.xtdata = None

    def stop(self):
        """停止下载"""
        self._is_running = False
        self.message.emit("正在停止下载...")

    def run(self):
        """执行下载"""
        try:
            # 连接QMT
            self.message.emit("正在连接QMT...")
            if not self._connect_qmt():
                self.error.emit("连接QMT失败")
                return

            # 获取股票列表
            self.message.emit("正在获取股票列表...")
            stock_list = self._get_stock_list()
            if not stock_list:
                self.error.emit("获取股票列表失败")
                return

            total_stocks = len(stock_list)
            self.message.emit(f"共 {total_stocks} 只股票需要下载")

            # 计算日期范围
            end_date = date.today()
            start_date = end_date - timedelta(days=365 * self.years)

            # 统计
            stats = {
                'total': total_stocks,
                'success': 0,
                'failed': 0,
                'records': 0,
                'start_time': datetime.now(),
                'end_time': None
            }

            # 分批下载
            for i in range(0, total_stocks, self.batch_size):
                if not self._is_running:
                    self.message.emit("下载已取消")
                    break

                batch = stock_list[i:i + self.batch_size]
                batch_num = i // self.batch_size + 1
                total_batches = (total_stocks - 1) // self.batch_size + 1

                self.message.emit(f"处理第 {batch_num}/{total_batches} 批，共 {len(batch)} 只股票")

                for j, stock_code in enumerate(batch):
                    if not self._is_running:
                        break

                    current = i + j + 1
                    self.stock_progress.emit(stock_code, current, total_stocks)

                    try:
                        records = self._download_stock(stock_code, start_date, end_date)
                        if records > 0:
                            stats['success'] += 1
                            stats['records'] += records
                        else:
                            stats['failed'] += 1
                    except Exception as e:
                        logger.error(f"下载失败 {stock_code}: {e}")
                        stats['failed'] += 1

                    # 更新总体进度
                    progress = int((current / total_stocks) * 100)
                    self.progress.emit(progress)

                # 批次间休息
                if self._is_running:
                    self.message.emit(f"第 {batch_num} 批完成，休息1秒...")
                    self.msleep(1000)

            stats['end_time'] = datetime.now()
            self.finished_signal.emit(stats)

        except Exception as e:
            logger.exception("批量下载失败")
            self.error.emit(str(e))

    def _connect_qmt(self) -> bool:
        """连接QMT"""
        try:
            possible_paths = [
                self.qmt_path,
                r"C:\国金证券QMT交易端",
                r"C:\workspace\国金证券QMT交易端",
                r"C:\Program Files (x86)\国金证券QMT交易端",
                r"D:\国金证券QMT交易端",
            ]

            qmt_path = None
            for path in possible_paths:
                if path and os.path.exists(path):
                    qmt_path = path
                    break

            if not qmt_path:
                return False

            os.environ['QMT_PATH'] = qmt_path
            sys.path.insert(0, os.path.join(qmt_path, 'python'))

            from xtquant import xtdata
            self.xtdata = xtdata

            data_dir = os.path.join(qmt_path, 'userdata_mini', 'datadir')
            if os.path.exists(data_dir):
                self.xtdata.data_dir = data_dir

            return True
        except Exception as e:
            logger.error(f"连接QMT失败: {e}")
            return False

    def _get_stock_list(self) -> list:
        """获取股票列表"""
        stocks = []
        try:
            for market in self.markets:
                if market == 'all':
                    stocks.extend(self.xtdata.get_stock_list_in_sector('沪深A股'))
                elif market == 'SH':
                    stocks.extend(self.xtdata.get_stock_list_in_sector('上证A股'))
                elif market == 'SZ':
                    stocks.extend(self.xtdata.get_stock_list_in_sector('深证A股'))
                elif market == 'BJ':
                    stocks.extend(self.xtdata.get_stock_list_in_sector('北证A股'))
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")

        # 去重并排序
        stocks = list(set(stocks))
        stocks.sort()
        return stocks

    def _download_stock(self, code: str, start_date: date, end_date: date) -> int:
        """下载单只股票数据"""
        try:
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')

            # 先下载数据
            result = self.xtdata.download_history_data(
                code, period='1d', start_time=start_str, end_time=end_str
            )

            # 获取数据
            data = self.xtdata.get_market_data_ex(
                field_list=['time', 'open', 'high', 'low', 'close', 'volume', 'amount',
                           'turnoverrate', 'pe', 'pb', 'totalcapital'],
                stock_list=[code],
                period='1d',
                start_time=start_str,
                end_time=end_str
            )

            if not data or code not in data:
                return 0

            df = data[code].copy()

            if df.empty:
                return 0

            # 标准化数据
            df = self._standardize_data(df, code)

            # 保存到数据库
            self.db.save_market_data_daily(df)

            return len(df)

        except Exception as e:
            logger.error(f"下载股票数据失败 {code}: {e}")
            return 0

    def _standardize_data(self, df: pd.DataFrame, code: str) -> 'pd.DataFrame':
        """标准化数据格式"""
        import pandas as pd

        df = df.copy()
        df['code'] = code

        # 列名映射
        column_mapping = {
            'time': 'trade_date',
            'Time': 'trade_date',
            'turnoverrate': 'turnover_rate',
            'pe': 'pe_ratio',
            'pb': 'pb_ratio',
            'totalcapital': 'market_cap',
        }
        df = df.rename(columns=column_mapping)

        # 确保trade_date是日期格式
        if 'trade_date' in df.columns:
            df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date

        # 确保数值列为float类型
        numeric_cols = ['open', 'high', 'low', 'close', 'volume', 'amount',
                       'turnover_rate', 'pe_ratio', 'pb_ratio', 'market_cap']
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')

        return df


class BulkDataDownloaderDialog(QDialog):
    """批量数据下载对话框"""

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.worker = None
        self.setWindowTitle("批量数据下载 - 全市场历史数据")
        self.setMinimumSize(800, 600)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # 配置区域
        config_group = QGroupBox("下载配置")
        config_layout = QGridLayout(config_group)

        # 数据年限
        config_layout.addWidget(QLabel("历史数据年限:"), 0, 0)
        self.spin_years = QSpinBox()
        self.spin_years.setRange(1, 10)
        self.spin_years.setValue(5)
        config_layout.addWidget(self.spin_years, 0, 1)

        # 批次大小
        config_layout.addWidget(QLabel("每批股票数:"), 0, 2)
        self.spin_batch = QSpinBox()
        self.spin_batch.setRange(10, 200)
        self.spin_batch.setValue(50)
        config_layout.addWidget(self.spin_batch, 0, 3)

        # 市场选择
        config_layout.addWidget(QLabel("下载市场:"), 1, 0)
        self.combo_market = QComboBox()
        self.combo_market.addItems(['全部市场', '上证A股', '深证A股', '北证A股'])
        config_layout.addWidget(self.combo_market, 1, 1, 1, 3)

        # QMT路径
        config_layout.addWidget(QLabel("QMT路径:"), 2, 0)
        self.label_qmt_path = QLabel("自动检测")
        config_layout.addWidget(self.label_qmt_path, 2, 1, 1, 3)

        layout.addWidget(config_group)

        # 进度区域
        progress_group = QGroupBox("下载进度")
        progress_layout = QVBoxLayout(progress_group)

        # 总体进度
        self.label_overall = QLabel("总体进度: 0/0")
        progress_layout.addWidget(self.label_overall)

        self.progress_overall = QProgressBar()
        self.progress_overall.setRange(0, 100)
        progress_layout.addWidget(self.progress_overall)

        # 当前股票
        self.label_current = QLabel("当前: 无")
        progress_layout.addWidget(self.label_current)

        layout.addWidget(progress_group)

        # 日志区域
        log_group = QGroupBox("下载日志")
        log_layout = QVBoxLayout(log_group)

        self.text_log = QTextEdit()
        self.text_log.setReadOnly(True)
        log_layout.addWidget(self.text_log)

        layout.addWidget(log_group)

        # 按钮区域
        btn_layout = QHBoxLayout()

        self.btn_start = QPushButton("开始下载")
        self.btn_start.clicked.connect(self.start_download)
        btn_layout.addWidget(self.btn_start)

        self.btn_stop = QPushButton("停止")
        self.btn_stop.clicked.connect(self.stop_download)
        self.btn_stop.setEnabled(False)
        btn_layout.addWidget(self.btn_stop)

        self.btn_close = QPushButton("关闭")
        self.btn_close.clicked.connect(self.close)
        btn_layout.addWidget(self.btn_close)

        btn_layout.addStretch()
        layout.addLayout(btn_layout)

    def start_download(self):
        """开始下载"""
        years = self.spin_years.value()
        batch_size = self.spin_batch.value()

        # 获取市场选择
        market_map = {
            '全部市场': ['all'],
            '上证A股': ['SH'],
            '深证A股': ['SZ'],
            '北证A股': ['BJ']
        }
        markets = market_map.get(self.combo_market.currentText(), ['all'])

        # 确认对话框
        reply = QMessageBox.question(
            self, '确认下载',
            f'将下载 {self.combo_market.currentText()} 过去 {years} 年的日线数据。\n'
            f'这可能需要较长时间，是否继续？',
            QMessageBox.Yes | QMessageBox.No
        )

        if reply != QMessageBox.Yes:
            return

        # 创建并启动工作线程
        self.worker = BulkDownloadWorker(
            self.db,
            years=years,
            batch_size=batch_size,
            markets=markets
        )

        self.worker.progress.connect(self.update_progress)
        self.worker.stock_progress.connect(self.update_stock_progress)
        self.worker.message.connect(self.log_message)
        self.worker.finished_signal.connect(self.download_finished)
        self.worker.error.connect(self.download_error)

        self.worker.start()

        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.log_message(f"开始下载，数据年限: {years}年，批次大小: {batch_size}")

    def stop_download(self):
        """停止下载"""
        if self.worker:
            self.worker.stop()
        self.btn_stop.setEnabled(False)

    def update_progress(self, progress):
        """更新总体进度"""
        self.progress_overall.setValue(progress)

    def update_stock_progress(self, code, current, total):
        """更新当前股票进度"""
        self.label_current.setText(f"当前: {code}")
        self.label_overall.setText(f"总体进度: {current}/{total}")

    def log_message(self, message):
        """添加日志"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        self.text_log.append(f"[{timestamp}] {message}")

    def download_finished(self, stats):
        """下载完成"""
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)

        duration = stats['end_time'] - stats['start_time']
        minutes = duration.total_seconds() / 60

        result_text = f"""
下载完成!
==========
总股票数: {stats['total']}
成功: {stats['success']}
失败: {stats['failed']}
总记录数: {stats['records']}
耗时: {minutes:.1f} 分钟
        """

        self.log_message(result_text)
        QMessageBox.information(self, "下载完成", result_text)

    def download_error(self, error_msg):
        """下载错误"""
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.log_message(f"错误: {error_msg}")
        QMessageBox.critical(self, "错误", f"下载失败: {error_msg}")

    def closeEvent(self, event):
        """关闭事件"""
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self, '确认关闭',
                '下载正在进行中，是否停止并关闭？',
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.worker.stop()
                self.worker.wait(3000)
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()


def main():
    """测试入口"""
    from PyQt5.QtWidgets import QApplication
    from database import DuckDBManager

    app = QApplication(sys.argv)

    # 创建数据库连接
    db = DuckDBManager("data/test_download.db")

    dialog = BulkDataDownloaderDialog(db)
    dialog.show()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
