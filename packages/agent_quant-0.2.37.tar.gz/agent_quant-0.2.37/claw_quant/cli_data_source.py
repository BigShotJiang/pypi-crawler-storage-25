# -*- coding: utf-8 -*-
"""
数据源管理命令

提供多数据源支持：
- qmt: QMT/xtquant (本地)
- baostock: baostock (在线)
- tushare: Tushare Pro (在线，需要Token)
"""

import json
import sys
from datetime import date
from typing import Optional, Dict, Any
import pandas as pd

from .database.source.factory import DataSourceFactory
from .database.source.base import DataSourceType


def parse_date(date_str: str) -> date:
    """解析日期字符串"""
    try:
        return pd.to_datetime(date_str).date()
    except:
        raise ValueError(f'无效的日期格式: {date_str}，请使用 YYYY-MM-DD 格式')


def format_output(data: dict) -> str:
    """格式化输出为JSON"""
    def json_serial(obj):
        if isinstance(obj, date):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")
    
    return json.dumps(data, ensure_ascii=False, indent=2, default=json_serial)


def cmd_source(args) -> int:
    """数据源管理命令"""
    if args.action == 'list':
        return cmd_source_list(args)
    elif args.action == 'check':
        return cmd_source_check(args)
    elif args.action == 'download':
        return cmd_source_download(args)
    elif args.action == 'stocks':
        return cmd_source_stocks(args)
    else:
        print(format_output({
            'success': False,
            'message': f'未知操作: {args.action}'
        }))
        return 1


def cmd_source_list(args) -> int:
    """列出可用数据源"""
    sources = DataSourceFactory.get_available_sources()
    
    # 检查每个数据源的可用性
    available_info = []
    for source_type, description in sources.items():
        is_available, error_msg = DataSourceFactory.check_source_available(source_type)
        available_info.append({
            'type': source_type,
            'description': description,
            'available': is_available,
            'error': error_msg if not is_available else None
        })
    
    print(format_output({
        'success': True,
        'sources': available_info
    }))
    return 0


def cmd_source_check(args) -> int:
    """检查指定数据源"""
    source_type = args.type
    
    is_available, error_msg = DataSourceFactory.check_source_available(source_type)
    
    if is_available:
        # 尝试连接测试
        try:
            config = {}
            if source_type == 'tushare' and args.token:
                config['token'] = args.token
                
            source = DataSourceFactory.create(source_type, config, use_cache=False)
            
            print(format_output({
                'success': True,
                'type': source_type,
                'available': True,
                'message': f'{source_type} 数据源可用且连接成功'
            }))
            return 0
            
        except Exception as e:
            print(format_output({
                'success': False,
                'type': source_type,
                'available': False,
                'error': str(e)
            }))
            return 1
    else:
        print(format_output({
            'success': False,
            'type': source_type,
            'available': False,
            'error': error_msg
        }))
        return 1


def cmd_source_download(args) -> int:
    """从指定数据源下载数据"""
    source_type = args.type
    
    # 检查数据源可用性
    is_available, error_msg = DataSourceFactory.check_source_available(source_type)
    if not is_available:
        print(format_output({
            'success': False,
            'message': f'{source_type} 数据源不可用: {error_msg}'
        }))
        return 1
    
    # 准备配置
    config = {}
    if source_type == 'tushare' and args.token:
        config['token'] = args.token
    
    try:
        # 创建数据源
        source = DataSourceFactory.create(source_type, config, use_cache=False)
        
        # 解析股票代码
        codes = []
        if args.codes:
            codes = [c.strip() for c in args.codes.split(',')]
        elif args.all:
            # 获取所有股票
            stocks = source.get_stock_list(args.market if args.market else 'all')
            codes = [s['code'] for s in stocks]
            print(f"获取到 {len(codes)} 只股票")
        else:
            print(format_output({
                'success': False,
                'message': '请指定 --codes 股票代码或 --all 下载全部'
            }))
            return 1
        
        if not codes:
            print(format_output({
                'success': False,
                'message': '没有要下载的股票代码'
            }))
            return 1
        
        # 解析日期
        start_date = args.start
        end_date = args.end
        
        print(f"开始从 {source_type} 下载数据...")
        print(f"股票数量: {len(codes)}")
        print(f"日期范围: {start_date} ~ {end_date}")
        
        # 下载数据
        results = []
        errors = []
        
        for i, code in enumerate(codes):
            try:
                df = source.get_daily_data(code, start_date, end_date)
                if not df.empty:
                    # 获取日期列（可能是date或trade_date）
                    date_col = 'date' if 'date' in df.columns else 'trade_date' if 'trade_date' in df.columns else None
                    if date_col:
                        results.append({
                            'code': code,
                            'records': len(df),
                            'start': str(df[date_col].min()),
                            'end': str(df[date_col].max())
                        })
                    else:
                        results.append({
                            'code': code,
                            'records': len(df),
                            'start': 'N/A',
                            'end': 'N/A'
                        })
                else:
                    errors.append({'code': code, 'error': '无数据'})
                    
                # 进度显示
                if (i + 1) % 10 == 0 or i == len(codes) - 1:
                    print(f"  进度: {i+1}/{len(codes)}")
                    
            except Exception as e:
                errors.append({'code': code, 'error': str(e)})
        
        # 保存到数据库
        saved_count = 0
        save_errors = []
        if results and not args.dry_run:
            from .database.api import StockAPI
            api = StockAPI()
            
            if not api.ping():
                print(format_output({
                    'success': False,
                    'message': '数据库未启动，无法保存数据',
                    'downloaded': len(results),
                    'saved': 0,
                    'failed': len(results)
                }))
                return 1
            
            # 重新下载并保存数据
            print(f"正在保存数据到数据库...")
            for i, code in enumerate(codes):
                try:
                    df = source.get_daily_data(code, start_date, end_date)
                    if not df.empty:
                        # 转换列名以匹配数据库格式（如果存在date列）
                        if 'date' in df.columns:
                            df = df.rename(columns={'date': 'trade_date'})
                        # 确保code列存在
                        if 'code' not in df.columns:
                            df['code'] = code
                        # 确保日期格式正确（如果trade_date列存在且需要转换）
                        if 'trade_date' in df.columns:
                            if not pd.api.types.is_datetime64_any_dtype(df['trade_date']):
                                df['trade_date'] = pd.to_datetime(df['trade_date'])
                            df['trade_date'] = df['trade_date'].dt.date
                        # 保存到数据库
                        api.db_client.save_market_data_daily(df)
                        saved_count += 1
                        if (i + 1) % 10 == 0:
                            print(f"  已保存: {i+1}/{len(codes)}")
                except Exception as e:
                    import traceback
                    error_msg = f"{code}: {str(e)}"
                    save_errors.append(error_msg)
                    print(f"  保存 {code} 失败: {e}")
                    traceback.print_exc()
            
            print(f"成功保存 {saved_count}/{len(codes)} 只股票数据到数据库")
            
            # 如果有保存失败，返回失败状态
            if saved_count == 0 and len(codes) > 0:
                print(format_output({
                    'success': False,
                    'message': f'所有数据保存失败: {save_errors[:3]}',
                    'source': source_type,
                    'downloaded': len(results),
                    'saved': saved_count,
                    'failed': len(save_errors),
                    'errors': save_errors[:5]
                }))
                return 1
            
            # 部分保存失败，返回警告
            if save_errors:
                print(format_output({
                    'success': True,
                    'warning': f'部分数据保存失败: {len(save_errors)} 只',
                    'source': source_type,
                    'downloaded': len(results),
                    'saved': saved_count,
                    'failed': len(save_errors),
                    'results': results[:10] if len(results) > 10 else results,
                    'errors': save_errors[:5]
                }))
                return 0
            
        print(format_output({
            'success': True,
            'source': source_type,
            'downloaded': len(results),
            'saved': saved_count,
            'failed': len(errors),
            'results': results[:10] if len(results) > 10 else results,
            'errors': errors[:5] if len(errors) > 5 else errors
        }))
        return 0 if len(results) > 0 else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'下载失败: {str(e)}'
        }))
        return 1


def cmd_source_stocks(args) -> int:
    """从数据源获取股票列表"""
    source_type = args.type
    
    # 检查数据源可用性
    is_available, error_msg = DataSourceFactory.check_source_available(source_type)
    if not is_available:
        print(format_output({
            'success': False,
            'message': f'{source_type} 数据源不可用: {error_msg}'
        }))
        return 1
    
    # 准备配置
    config = {}
    if source_type == 'tushare' and args.token:
        config['token'] = args.token
    
    try:
        source = DataSourceFactory.create(source_type, config, use_cache=False)
        
        market = args.market if args.market else 'all'
        stocks = source.get_stock_list(market)
        
        # 限制返回数量
        if args.limit and len(stocks) > args.limit:
            stocks = stocks[:args.limit]
        
        print(format_output({
            'success': True,
            'source': source_type,
            'market': market,
            'count': len(stocks),
            'stocks': stocks
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'获取股票列表失败: {str(e)}'
        }))
        return 1
