"""
Wrappers for OpenAI and Anthropic SDK clients.

Instead of calling the provider directly, all calls are routed through the
LogicGaze gateway (POST /api/v1/gateway/chat/completions), which records a
Trace + Span automatically and then forwards the request to the real provider.
"""

import asyncio
import inspect
from typing import Any, Dict, List, Optional

from logicgaze.client import get_client
from logicgaze.context import (
    get_current_trace_id,
    get_current_session_id,
    get_current_user_id,
    get_current_service_name,
    get_current_tags,
)


# ---------------------------------------------------------------------------
# Lightweight response shims
# Mimic native SDK response objects so callers never have to change their code.
# ---------------------------------------------------------------------------


class _Usage:
    __slots__ = ("prompt_tokens", "completion_tokens", "total_tokens",
                 "input_tokens", "output_tokens")

    def __init__(self, data: Dict):
        self.prompt_tokens = data.get("prompt_tokens", 0)
        self.completion_tokens = data.get("completion_tokens", 0)
        self.total_tokens = data.get("total_tokens", 0)
        # Anthropic aliases
        self.input_tokens = self.prompt_tokens
        self.output_tokens = self.completion_tokens


class _Message:
    __slots__ = ("role", "content", "tool_calls")

    def __init__(self, data: Dict):
        self.role = data.get("role", "assistant")
        self.content = data.get("content", "")
        self.tool_calls = data.get("tool_calls")


class _Choice:
    __slots__ = ("index", "message", "finish_reason")

    def __init__(self, data: Dict):
        self.index = data.get("index", 0)
        self.message = _Message(data.get("message", {}))
        self.finish_reason = data.get("finish_reason")


class OpenAIChatCompletion:
    """OpenAI-compatible response object built from the gateway JSON response."""

    def __init__(self, data: Dict):
        self.id = data.get("id", "")
        self.object = data.get("object", "chat.completion")
        self.created = data.get("created")
        self.model = data.get("model", "")
        self.choices: List[_Choice] = [_Choice(c) for c in data.get("choices", [])]
        self.usage = _Usage(data.get("usage", {})) if data.get("usage") else None
        self._raw = data

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"ChatCompletion(id={self.id!r}, model={self.model!r}, "
            f"choices={len(self.choices)})"
        )


class _AnthropicContentBlock:
    __slots__ = ("type", "text")

    def __init__(self, data: Dict):
        self.type = data.get("type", "text")
        self.text = data.get("text", "") if self.type == "text" else None


class AnthropicMessage:
    """Anthropic-compatible response object built from the gateway JSON response.

    The gateway returns an OpenAI-format payload; this class converts it back
    to the shape that Anthropic callers expect.
    """

    def __init__(self, data: Dict):
        self.id = data.get("id", "")
        self.type = "message"
        self.role = "assistant"
        self.model = data.get("model", "")

        choices = data.get("choices", [])
        if choices:
            content_text = choices[0].get("message", {}).get("content", "") or ""
            self.content = [
                _AnthropicContentBlock({"type": "text", "text": content_text})
            ]
            self.stop_reason = choices[0].get("finish_reason")
        else:
            self.content = []
            self.stop_reason = None

        usage_data = data.get("usage", {})
        self.usage = _Usage(usage_data) if usage_data else None
        self._raw = data

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"Message(id={self.id!r}, model={self.model!r}, "
            f"stop_reason={self.stop_reason!r})"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tracing_kwargs() -> Dict:
    """Collect any tracing context set by TraceContext / @traceable."""
    ctx: Dict = {}
    if get_current_trace_id():
        ctx["trace_id"] = get_current_trace_id()
    if get_current_session_id():
        ctx["session_id"] = get_current_session_id()
    if get_current_user_id():
        ctx["user_id"] = get_current_user_id()
    if get_current_service_name():
        ctx["service_name"] = get_current_service_name()
    if get_current_tags():
        ctx["tags"] = get_current_tags()
    return ctx


# ---------------------------------------------------------------------------
# wrap_openai
# ---------------------------------------------------------------------------


def wrap_openai(client: Any, *, service_name: Optional[str] = None) -> Any:
    """Patch an OpenAI client so every ``chat.completions.create`` call is
    routed through the LogicGaze gateway for automatic tracing.

    The backend must have the OpenAI provider configured with a valid API key.

    Usage::

        from openai import OpenAI
        import logicgaze
        logicgaze.init(api_key="lgz_...")

        openai_client = logicgaze.wrap_openai(OpenAI())
        response = openai_client.chat.completions.create(
            model="gpt-4o", messages=[...]
        )
        print(response.choices[0].message.content)
    """
    original_create = client.chat.completions.create

    def _build_payload(kwargs: Dict) -> Dict:
        payload = {
            "provider": "openai",
            "model": kwargs.get("model", "gpt-4o"),
            "messages": kwargs.get("messages", []),
        }
        for field in ("temperature", "max_tokens", "stream", "tools"):
            if kwargs.get(field) is not None:
                payload[field] = kwargs[field]
        if service_name:
            payload.setdefault("service_name", service_name)
        payload.update(_tracing_kwargs())
        return payload

    def sync_create(*args, **kwargs):
        tracking_client = get_client()
        payload = _build_payload(kwargs)
        data = tracking_client.chat_completion(**payload)
        return OpenAIChatCompletion(data)

    async def async_create(*args, **kwargs):
        tracking_client = get_client()
        payload = _build_payload(kwargs)
        data = await tracking_client.achat_completion(**payload)
        return OpenAIChatCompletion(data)

    if inspect.iscoroutinefunction(original_create):
        client.chat.completions.create = async_create
    else:
        client.chat.completions.create = sync_create

    return client


# ---------------------------------------------------------------------------
# wrap_anthropic
# ---------------------------------------------------------------------------


def wrap_anthropic(client: Any, *, service_name: Optional[str] = None) -> Any:
    """Patch an Anthropic client so every ``messages.create`` call is routed
    through the LogicGaze gateway for automatic tracing.

    The backend must have the Anthropic provider configured with a valid API key.

    Usage::

        from anthropic import Anthropic
        import logicgaze
        logicgaze.init(api_key="lgz_...")

        anthropic_client = logicgaze.wrap_anthropic(Anthropic())
        response = anthropic_client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(response.content[0].text)
    """
    original_create = client.messages.create

    def _build_payload(kwargs: Dict) -> Dict:
        payload = {
            "provider": "anthropic",
            "model": kwargs.get("model", "claude-3-5-sonnet-20241022"),
            "messages": kwargs.get("messages", []),
        }
        for field in ("temperature", "max_tokens", "stream", "tools"):
            if kwargs.get(field) is not None:
                payload[field] = kwargs[field]
        # Anthropic uses a top-level "system" parameter
        if kwargs.get("system"):
            payload["system"] = kwargs["system"]
        if service_name:
            payload.setdefault("service_name", service_name)
        payload.update(_tracing_kwargs())
        return payload

    def sync_create(*args, **kwargs):
        tracking_client = get_client()
        payload = _build_payload(kwargs)
        data = tracking_client.chat_completion(**payload)
        return AnthropicMessage(data)

    async def async_create(*args, **kwargs):
        tracking_client = get_client()
        payload = _build_payload(kwargs)
        data = await tracking_client.achat_completion(**payload)
        return AnthropicMessage(data)

    if inspect.iscoroutinefunction(original_create):
        client.messages.create = async_create
    else:
        client.messages.create = sync_create

    return client
