import os
import httpx
from typing import Any, Dict, List, Optional


class LogicGazeClient:
    """HTTP client for the LogicGaze observability backend."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:8000",
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("LOGICGAZE_API_KEY")
        # Normalize: strip trailing slash, append /api/v1 once
        base = base_url.rstrip("/")
        if not base.endswith("/api/v1"):
            base = f"{base}/api/v1"
        self.base_url = base
        self.timeout = timeout

        if not self.api_key:
            raise ValueError(
                "api_key must be provided or set via LOGICGAZE_API_KEY env var"
            )

        # Maintain persistent connection pools
        self._client = httpx.Client(timeout=self.timeout)
        self._aclient = httpx.AsyncClient(timeout=self.timeout)

    def close(self):
        """Close the underlying HTTP clients."""
        try:
            self._client.close()
        except Exception:
            pass

    async def aclose(self):
        """Close the underlying async HTTP clients."""
        try:
            await self._aclient.aclose()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, **kwargs) -> Any:
        url = f"{self.base_url}{path}"
        response = self._client.request(method, url, headers=self._headers(), **kwargs)
        response.raise_for_status()
        return response.json()

    async def _arequest(self, method: str, path: str, **kwargs) -> Any:
        url = f"{self.base_url}{path}"
        response = await self._aclient.request(
            method, url, headers=self._headers(), **kwargs
        )
        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------
    # Gateway – LLM proxy (creates traces + spans automatically)
    # ------------------------------------------------------------------

    def chat_completion(
        self,
        provider: str,
        model: str,
        messages: List[Dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        tools: Optional[List] = None,
        system: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        trace_id: Optional[str] = None,
        tags: Optional[Dict] = None,
        **kwargs,
    ) -> Dict:
        """Send a chat completion request through the LogicGaze gateway.

        The gateway calls the actual AI provider and automatically records a
        Trace + Span with token counts, cost, and latency.
        """
        payload: Dict[str, Any] = {
            "provider": provider,
            "model": model,
            "messages": messages,
            "stream": stream,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if tools:
            payload["tools"] = tools
        if system:
            payload["system"] = system
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id
        if service_name:
            payload["service_name"] = service_name
        if trace_id:
            payload["trace_id"] = trace_id
        if tags:
            payload["tags"] = tags

        return self._request("POST", "/gateway/chat/completions", json=payload)

    async def achat_completion(
        self,
        provider: str,
        model: str,
        messages: List[Dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        tools: Optional[List] = None,
        system: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        trace_id: Optional[str] = None,
        tags: Optional[Dict] = None,
        **kwargs,
    ) -> Dict:
        """Async version of chat_completion."""
        payload: Dict[str, Any] = {
            "provider": provider,
            "model": model,
            "messages": messages,
            "stream": stream,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if tools:
            payload["tools"] = tools
        if system:
            payload["system"] = system
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id
        if service_name:
            payload["service_name"] = service_name
        if trace_id:
            payload["trace_id"] = trace_id
        if tags:
            payload["tags"] = tags

        return await self._arequest(
            "POST", "/gateway/chat/completions", json=payload
        )

    # ------------------------------------------------------------------
    # Trace lifecycle (start → gateway calls → end)
    # ------------------------------------------------------------------

    def start_trace(
        self,
        *,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        environment: Optional[str] = None,
        trace_id: Optional[str] = None,
        tags: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
    ) -> Dict:
        """Create a trace shell on the server and return its metadata.

        The returned dict always contains a ``trace_id`` key (str UUID).
        Pass this value as ``trace_id`` to every subsequent :meth:`chat_completion`
        call so the gateway attaches those completions as spans on **this** trace
        rather than creating separate traces.

        Typical usage::

            trace = lg.start_trace(service_name="my-pipeline", user_id="user-123")
            trace_id = trace["trace_id"]

            with lg.trace_context(trace_id=trace_id):
                lg.chat_completion(...)  # injected automatically
                lg.chat_completion(...)

            lg.end_trace(trace_id)
        """
        payload: Dict[str, Any] = {}
        if trace_id:
            payload["trace_id"] = trace_id
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id
        if service_name:
            payload["service_name"] = service_name
        if environment:
            payload["environment"] = environment
        if tags:
            payload["tags"] = tags
        if metadata:
            payload["metadata"] = metadata
        return self._request("POST", "/traces", json=payload)

    def end_trace(self, trace_id: str) -> Dict:
        """Finalise a trace: compute duration and aggregate span metrics.

        Call once all LLM calls belonging to this trace are complete.
        Returns the final trace summary.
        """
        return self._request("PATCH", f"/traces/{trace_id}/end")

    def trace_context(
        self,
        *,
        trace_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        tags: Optional[Dict] = None,
    ):
        """Return a :class:`TraceContext` context-manager pre-filled with the
        given values so you don't have to import it separately.

        Usage::

            with lg.trace_context(trace_id=trace_id, user_id="u-1"):
                lg.chat_completion(...)
        """
        from logicgaze.context import TraceContext
        return TraceContext(
            trace_id=trace_id,
            session_id=session_id,
            user_id=user_id,
            service_name=service_name,
            tags=tags,
        )

    # ------------------------------------------------------------------
    # Traces (read)
    # ------------------------------------------------------------------

    def list_traces(
        self,
        *,
        page: int = 1,
        page_size: int = 50,
        status: Optional[str] = None,
        service_name: Optional[str] = None,
        session_id: Optional[str] = None,
        model: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
    ) -> Dict:
        """List traces with optional filters. Returns TracesListResponse."""
        params: Dict[str, Any] = {"page": page, "page_size": page_size}
        if status:
            params["status"] = status
        if service_name:
            params["service_name"] = service_name
        if session_id:
            params["session_id"] = session_id
        if model:
            params["model"] = model
        if start_time:
            params["start_time"] = start_time
        if end_time:
            params["end_time"] = end_time
        return self._request("GET", "/traces", params=params)

    def get_trace(self, trace_id: str, *, include_spans: bool = False) -> Dict:
        """Get a single trace by ID. Pass include_spans=True to embed spans."""
        params = {"include_spans": include_spans}
        return self._request("GET", f"/traces/{trace_id}", params=params)

    def get_spans(self, trace_id: str) -> List[Dict]:
        """Get all spans for a trace."""
        return self._request("GET", f"/traces/{trace_id}/spans")

    def create_span(
        self,
        trace_id: str,
        span_type: str,
        name: str,
        *,
        parent_span_id: Optional[str] = None,
        duration_ms: Optional[float] = None,
        status: str = "ok",
        provider: Optional[str] = None,
        model: Optional[str] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        total_tokens: Optional[int] = None,
        cost_usd: Optional[float] = None,
        input_messages: Optional[List[Dict]] = None,
        output_message: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
        operation: Optional[str] = None,
    ) -> Dict:
        """Create a span directly on an existing trace (synchronous — no queue).

        ``span_type`` must be one of: ``"llm"``, ``"tool"``, ``"agent"``,
        ``"retrieval"``, ``"embedding"``, ``"rerank"``.

        Returns ``{"span_id": "...", "trace_id": "..."}``.

        Example::

            root = lg.create_span(trace_id, "agent", "research-agent")
            lg.create_span(
                trace_id, "retrieval", "vector-search",
                parent_span_id=root["span_id"], duration_ms=85,
            )
        """
        payload: Dict[str, Any] = {
            "span_type": span_type,
            "name": name,
            "status": status,
        }
        if parent_span_id:
            payload["parent_span_id"] = parent_span_id
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms
        if provider:
            payload["provider"] = provider
        if model:
            payload["model"] = model
        if prompt_tokens is not None:
            payload["prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            payload["completion_tokens"] = completion_tokens
        if total_tokens is not None:
            payload["total_tokens"] = total_tokens
        if cost_usd is not None:
            payload["cost_usd"] = cost_usd
        if input_messages:
            payload["input_messages"] = input_messages
        if output_message:
            payload["output_message"] = output_message
        if metadata:
            payload["metadata"] = metadata
        if operation:
            payload["operation"] = operation
        return self._request("POST", f"/traces/{trace_id}/spans", json=payload)

    async def acreate_span(
        self,
        trace_id: str,
        span_type: str,
        name: str,
        *,
        parent_span_id: Optional[str] = None,
        duration_ms: Optional[float] = None,
        status: str = "ok",
        provider: Optional[str] = None,
        model: Optional[str] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        total_tokens: Optional[int] = None,
        cost_usd: Optional[float] = None,
        input_messages: Optional[List[Dict]] = None,
        output_message: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
        operation: Optional[str] = None,
    ) -> Dict:
        """Async version of :meth:`create_span`. Use inside ``async def`` functions.

        Example::

            async def run_pipeline(trace_id):
                root = await lg.acreate_span(trace_id, "agent", "research-agent")
                embed, retrieval = await asyncio.gather(
                    lg.acreate_span(trace_id, "embedding", "embed-query",
                                    parent_span_id=root["span_id"]),
                    lg.acreate_span(trace_id, "retrieval", "vector-search",
                                    parent_span_id=root["span_id"]),
                )
        """
        payload: Dict[str, Any] = {"span_type": span_type, "name": name, "status": status}
        if parent_span_id:
            payload["parent_span_id"] = parent_span_id
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms
        if provider:
            payload["provider"] = provider
        if model:
            payload["model"] = model
        if prompt_tokens is not None:
            payload["prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            payload["completion_tokens"] = completion_tokens
        if total_tokens is not None:
            payload["total_tokens"] = total_tokens
        if cost_usd is not None:
            payload["cost_usd"] = cost_usd
        if input_messages:
            payload["input_messages"] = input_messages
        if output_message:
            payload["output_message"] = output_message
        if metadata:
            payload["metadata"] = metadata
        if operation:
            payload["operation"] = operation
        return await self._arequest("POST", f"/traces/{trace_id}/spans", json=payload)

    async def astart_trace(self, **kwargs) -> Dict:
        """Async version of :meth:`start_trace`."""
        payload = {k: v for k, v in kwargs.items() if v is not None}
        return await self._arequest("POST", "/traces", json=payload)

    async def aend_trace(self, trace_id: str) -> Dict:
        """Async version of :meth:`end_trace`."""
        return await self._arequest("PATCH", f"/traces/{trace_id}/end")

    async def achat_completion(
        self,
        provider: str,
        model: str,
        messages: List[Dict],
        **kwargs,
    ) -> Dict:
        """Async version of :meth:`chat_completion`. Use inside ``async def`` functions."""
        payload: Dict[str, Any] = {"provider": provider, "model": model, "messages": messages}
        for field in ("temperature", "max_tokens", "stream", "tools", "system",
                      "session_id", "user_id", "service_name", "trace_id", "tags"):
            if kwargs.get(field) is not None:
                payload[field] = kwargs[field]
        return await self._arequest("POST", "/gateway/chat/completions", json=payload)

    def get_agent_graph(self, trace_id: str) -> Dict:
        """Get the agent execution graph for a trace."""
        return self._request("GET", f"/traces/{trace_id}/agent-graph")

    async def aget_agent_graph(self, trace_id: str) -> Dict:
        """Async version of :meth:`get_agent_graph`."""
        return await self._arequest("GET", f"/traces/{trace_id}/agent-graph")

    # ------------------------------------------------------------------
    # SDK Ingestion — batch span/trace events
    # ------------------------------------------------------------------

    def ingest_batch(self, batch: List[Dict], *, metadata: Optional[Dict] = None) -> Dict:
        """Submit a batch of trace/span events via the async ingestion endpoint.

        Each item in *batch* must be a dict with keys:
          ``id``        — client-assigned event ID (str)
          ``type``      — "trace-create" | "span-create" | "score-create"
          ``timestamp`` — ISO-8601 datetime string
          ``body``      — event-specific payload dict

        Returns the server response with ``successes`` and ``errors`` lists.

        Example::

            import uuid, logicgaze
            from datetime import datetime, timezone

            lg = logicgaze.init(api_key="lgz_...")
            trace_id = str(uuid.uuid4())

            batch = [
                {
                    "id": str(uuid.uuid4()),
                    "type": "trace-create",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "body": {"traceId": trace_id, "name": "my-agent"},
                },
                {
                    "id": str(uuid.uuid4()),
                    "type": "span-create",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "body": {
                        "traceId": trace_id,
                        "type": "agent",
                        "name": "my-agent-step",
                    },
                },
            ]
            result = lg.ingest_batch(batch)
        """
        payload: Dict[str, Any] = {"batch": batch}
        if metadata:
            payload["metadata"] = metadata
        return self._request("POST", "/ingestion", json=payload)

    # ------------------------------------------------------------------
    # Dashboard analytics
    # ------------------------------------------------------------------

    def get_dashboard(self, *, window_hours: int = 24) -> Dict:
        """Get overview metrics (requests, cost, latency, errors)."""
        return self._request(
            "GET", "/dashboard/overview", params={"window_hours": window_hours}
        )

    def get_model_distribution(self, *, window_hours: int = 24) -> List[Dict]:
        return self._request(
            "GET",
            "/dashboard/model-distribution",
            params={"window_hours": window_hours},
        )

    def get_provider_breakdown(self, *, window_hours: int = 24) -> List[Dict]:
        return self._request(
            "GET",
            "/dashboard/provider-breakdown",
            params={"window_hours": window_hours},
        )

    # ------------------------------------------------------------------
    # Cost utilities
    # ------------------------------------------------------------------

    def estimate_cost(
        self,
        provider: str,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> Dict:
        """Estimate cost for a given model + token counts."""
        return self._request(
            "POST",
            "/costs/estimate",
            json={
                "provider": provider,
                "model": model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
            },
        )

    def list_model_costs(self, *, provider: Optional[str] = None) -> Dict:
        """Return the pricing catalog. Optionally filter by provider."""
        params = {}
        if provider:
            params["provider"] = provider
        return self._request("GET", "/costs/models", params=params)

    # ------------------------------------------------------------------
    # Guardrails summary
    # ------------------------------------------------------------------

    def get_guardrails_summary(self, *, window_hours: int = 24) -> Dict:
        return self._request(
            "GET",
            "/guardrails/summary",
            params={"window_hours": window_hours},
        )

    # ------------------------------------------------------------------
    # Online Evaluators
    # ------------------------------------------------------------------

    def list_evaluators(self) -> List[Dict]:
        """List all online evaluators for the current tenant."""
        data = self._request("GET", "/online-evaluators")
        return data.get("evaluators", data) if isinstance(data, dict) else data

    def get_evaluator(self, evaluator_id: str) -> Dict:
        """Get a single online evaluator by ID."""
        evaluators = self.list_evaluators()
        for ev in evaluators:
            if ev.get("id") == evaluator_id:
                return ev
        raise ValueError(f"Evaluator {evaluator_id!r} not found")

    def get_evaluator_executions(
        self,
        evaluator_id: str,
        *,
        page: int = 1,
        page_size: int = 50,
        status: Optional[str] = None,
    ) -> Dict:
        """List executions for an online evaluator.

        Returns a dict with keys: ``executions`` (list), ``total``, ``page``, ``page_size``.
        """
        params: Dict[str, Any] = {"page": page, "page_size": page_size}
        if status:
            params["status"] = status
        return self._request(
            "GET",
            f"/online-evaluators/{evaluator_id}/executions",
            params=params,
        )

    def backfill_evaluator(self, evaluator_id: str, *, hours: int = 24) -> Dict:
        """Trigger a backfill run for an evaluator over the past *hours* hours."""
        return self._request(
            "POST",
            f"/online-evaluators/{evaluator_id}/backfill",
            json={"hours": hours},
        )

    def create_evaluator(
        self,
        name: str,
        *,
        score_name: Optional[str] = None,
        template: Optional[str] = None,
        prompt_template: Optional[str] = None,
        score_type: str = "numeric",
        evaluator_model: str = "gpt-4o-mini",
        evaluator_provider: str = "openai",
        sampling_rate: float = 0.1,
        run_on_live: bool = True,
        is_active: bool = True,
        filter_criteria: Optional[Dict] = None,
        pass_threshold: Optional[float] = None,
        variable_mapping: Optional[Dict] = None,
    ) -> Dict:
        """Create a new online evaluator."""
        payload: Dict[str, Any] = {
            "name": name,
            "score_name": score_name or name,
            "template": template,
            "prompt_template": prompt_template,
            "score_type": score_type,
            "evaluator_model": evaluator_model,
            "evaluator_provider": evaluator_provider,
            "sampling_rate": sampling_rate,
            "run_on_live": run_on_live,
            "is_active": is_active,
            "filter_criteria": filter_criteria or {},
            "variable_mapping": variable_mapping or {},
        }
        if pass_threshold is not None:
            payload["pass_threshold"] = pass_threshold
        return self._request("POST", "/online-evaluators", json=payload)

    def update_evaluator(self, evaluator_id: str, **fields) -> Dict:
        """Partially update an online evaluator (e.g., is_active, sampling_rate)."""
        return self._request(
            "PATCH", f"/online-evaluators/{evaluator_id}", json=fields
        )

    def delete_evaluator(self, evaluator_id: str) -> Dict:
        """Delete an online evaluator by ID."""
        return self._request("DELETE", f"/online-evaluators/{evaluator_id}")

    # ------------------------------------------------------------------
    # Custom Dashboards
    # ------------------------------------------------------------------

    def list_dashboards(self) -> List[Dict]:
        """List all custom dashboards for the current tenant."""
        return self._request("GET", "/dashboards/custom")

    def get_dashboard_detail(self, dashboard_id: str) -> Dict:
        """Get a single custom dashboard with its charts."""
        return self._request("GET", f"/dashboards/custom/{dashboard_id}")

    def create_dashboard(
        self,
        name: str,
        *,
        description: Optional[str] = None,
        is_shared: bool = False,
    ) -> Dict:
        """Create a new custom dashboard.

        Example::

            dash = client.create_dashboard(
                "Production Overview",
                description="Key metrics for the prod LLM pipeline",
                is_shared=True,
            )
            dash_id = dash["id"]
        """
        return self._request(
            "POST",
            "/dashboards/custom",
            json={"name": name, "description": description, "is_shared": is_shared},
        )

    def update_dashboard(
        self,
        dashboard_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        is_shared: Optional[bool] = None,
    ) -> Dict:
        """Update dashboard metadata."""
        payload = {k: v for k, v in {"name": name, "description": description, "is_shared": is_shared}.items() if v is not None}
        return self._request("PATCH", f"/dashboards/custom/{dashboard_id}", json=payload)

    def delete_dashboard(self, dashboard_id: str) -> Dict:
        """Delete a custom dashboard and all its charts."""
        return self._request("DELETE", f"/dashboards/custom/{dashboard_id}")

    def add_chart(
        self,
        dashboard_id: str,
        title: str,
        metric: str,
        *,
        chart_type: str = "line",
        group_by: Optional[str] = None,
        filter_criteria: Optional[Dict] = None,
        time_range_hours: int = 24,
        width: int = 6,
        height: int = 4,
        position_x: int = 0,
        position_y: int = 0,
    ) -> Dict:
        """Add a chart to an existing dashboard.

        ``metric`` is one of: ``request_count``, ``cost``, ``token_count``,
        ``avg_latency_ms``, ``error_rate``.

        ``chart_type`` is one of: ``line``, ``bar``, ``area``, ``number``.

        Example::

            client.add_chart(
                dash_id,
                title="Requests / hour",
                metric="request_count",
                chart_type="bar",
                time_range_hours=48,
            )
        """
        return self._request(
            "POST",
            f"/dashboards/custom/{dashboard_id}/charts",
            json={
                "title": title,
                "chart_type": chart_type,
                "metric": metric,
                "group_by": group_by,
                "filter_criteria": filter_criteria or {},
                "time_range_hours": time_range_hours,
                "width": width,
                "height": height,
                "position_x": position_x,
                "position_y": position_y,
            },
        )

    def remove_chart(self, dashboard_id: str, chart_id: str) -> Dict:
        """Remove a chart from a dashboard."""
        return self._request(
            "DELETE", f"/dashboards/custom/{dashboard_id}/charts/{chart_id}"
        )

    def get_dashboard_data(self, dashboard_id: str) -> Dict:
        """Fetch live metric data for all charts in a dashboard."""
        return self._request("GET", f"/dashboards/custom/{dashboard_id}/data")


# ---------------------------------------------------------------------------
# Global singleton
# ---------------------------------------------------------------------------
_client: Optional[LogicGazeClient] = None


def init(
    api_key: Optional[str] = None,
    base_url: str = "http://localhost:8000",
    timeout: float = 30.0,
) -> LogicGazeClient:
    """Initialize the global SDK client.

    Call once at application startup::

        import logicgaze
        logicgaze.init(api_key="lgz_...", base_url="https://your-backend")
    """
    global _client
    _client = LogicGazeClient(api_key=api_key, base_url=base_url, timeout=timeout)
    return _client


def get_client() -> LogicGazeClient:
    global _client
    if _client is None:
        _client = LogicGazeClient()
    return _client


def set_client(client: LogicGazeClient) -> None:
    global _client
    _client = client
