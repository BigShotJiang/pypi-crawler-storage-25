from logicgaze.client import (
    LogicGazeClient,
    get_client,
    set_client,
    init,
)
from logicgaze.context import (
    TraceContext,
    get_current_trace_id,
    get_current_session_id,
    get_current_user_id,
    get_current_service_name,
    get_current_tags,
    get_current_project,
    get_current_run_id,  # backward-compat no-op
)
from logicgaze.decorators import traceable
from logicgaze.wrappers import wrap_openai, wrap_anthropic

__version__ = "1.2.0"

__all__ = [
    # Client
    "LogicGazeClient",
    "get_client",
    "set_client",
    "init",
    # Context
    "TraceContext",
    "get_current_trace_id",
    "get_current_session_id",
    "get_current_user_id",
    "get_current_service_name",
    "get_current_tags",
    "get_current_project",
    "get_current_run_id",
    # Decorators
    "traceable",
    # Wrappers
    "wrap_openai",
    "wrap_anthropic",
]
