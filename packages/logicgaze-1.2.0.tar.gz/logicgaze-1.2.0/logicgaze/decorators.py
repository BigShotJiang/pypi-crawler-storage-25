"""
@traceable decorator

Sets tracing context (session_id, user_id, service_name, tags) for the
duration of the decorated function so that any wrapped LLM client calls
made inside automatically include those fields in the gateway request.
"""

import asyncio
import functools
import inspect
import os
from typing import Callable, Dict, Optional

from logicgaze.context import TraceContext


def traceable(
    func: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    project: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    service_name: Optional[str] = None,
    tags: Optional[Dict] = None,
    run_type: str = "generic",  # kept for backward compatibility
):
    """Mark a function so that all LLM calls inside it are traced together.

    Sets :class:`~logicgaze.context.TraceContext` for the function's
    duration.  Both sync and async functions are supported.

    Can be used with or without arguments::

        @traceable
        def my_func(): ...

        @traceable(session_id="sess-1", service_name="chat-api")
        async def my_async_func(): ...
    """

    def decorator(fn: Callable) -> Callable:
        ctx_kwargs = dict(
            project=project or os.environ.get("LOGICGAZE_PROJECT"),
            session_id=session_id,
            user_id=user_id,
            service_name=service_name or fn.__module__,
            tags=tags,
        )
        # Strip None values so TraceContext doesn't overwrite existing ctx vars
        ctx_kwargs = {k: v for k, v in ctx_kwargs.items() if v is not None}

        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args, **kwargs):
                async with TraceContext(**ctx_kwargs):
                    return await fn(*args, **kwargs)
            return async_wrapper
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args, **kwargs):
                with TraceContext(**ctx_kwargs):
                    return fn(*args, **kwargs)
            return sync_wrapper

    # Support both @traceable and @traceable(...) usage
    if func is not None:
        return decorator(func)
    return decorator
