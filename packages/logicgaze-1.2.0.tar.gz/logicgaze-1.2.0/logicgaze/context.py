import contextvars
from typing import Any, Dict, Optional


# ---------------------------------------------------------------------------
# Per-request context variables (thread-safe, async-safe via contextvars)
# ---------------------------------------------------------------------------

_current_trace_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_trace_id", default=None
)
_current_session_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_session_id", default=None
)
_current_user_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_user_id", default=None
)
_current_service_name: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_service_name", default=None
)
_current_tags: contextvars.ContextVar[Optional[Dict]] = contextvars.ContextVar(
    "current_tags", default=None
)
_current_project: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_project", default=None
)


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


class TraceContext:
    """Context manager that injects tracing metadata into all LLM calls made
    within the block (works with both sync and async ``with`` statements).

    Example::

        with TraceContext(session_id="sess-123", user_id="user-456"):
            client.chat.completions.create(...)  # tagged automatically
    """

    def __init__(
        self,
        *,
        project: Optional[str] = None,
        trace_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        tags: Optional[Dict] = None,
    ):
        self.project = project
        self.trace_id = trace_id
        self.session_id = session_id
        self.user_id = user_id
        self.service_name = service_name
        self.tags = tags
        self._tokens: list = []

    def _enter(self):
        if self.trace_id is not None:
            self._tokens.append(_current_trace_id.set(self.trace_id))
        if self.session_id is not None:
            self._tokens.append(_current_session_id.set(self.session_id))
        if self.user_id is not None:
            self._tokens.append(_current_user_id.set(self.user_id))
        if self.service_name is not None:
            self._tokens.append(_current_service_name.set(self.service_name))
        if self.tags is not None:
            self._tokens.append(_current_tags.set(self.tags))
        if self.project is not None:
            self._tokens.append(_current_project.set(self.project))
        return self

    def _exit(self):
        for token in reversed(self._tokens):
            token.var.reset(token)
        self._tokens.clear()

    def __enter__(self):
        return self._enter()

    def __exit__(self, *_):
        self._exit()
        return False

    async def __aenter__(self):
        return self._enter()

    async def __aexit__(self, *_):
        self._exit()
        return False


# ---------------------------------------------------------------------------
# Accessor helpers (used by wrappers / decorators)
# ---------------------------------------------------------------------------


def get_current_trace_id() -> Optional[str]:
    return _current_trace_id.get()


def get_current_session_id() -> Optional[str]:
    return _current_session_id.get()


def get_current_user_id() -> Optional[str]:
    return _current_user_id.get()


def get_current_service_name() -> Optional[str]:
    return _current_service_name.get()


def get_current_tags() -> Optional[Dict]:
    return _current_tags.get()


def get_current_project() -> Optional[str]:
    return _current_project.get()


def get_current_run_id() -> Optional[str]:
    """Kept for backward compatibility — not used by gateway-based tracing."""
    return None


def set_current_run_id(run_id: str) -> None:
    """Kept for backward compatibility — no-op with gateway-based tracing."""
    pass
