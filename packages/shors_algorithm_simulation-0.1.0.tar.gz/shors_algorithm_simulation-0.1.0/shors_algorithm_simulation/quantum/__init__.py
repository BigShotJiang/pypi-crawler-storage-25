"""Quantum-operator simulation helpers."""
