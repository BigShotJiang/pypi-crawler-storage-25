# Metabolic Network Tools

---

MNTools is a library for loading and representing metabolic networks.
It uses [ChemRecon](gitlab.com/casbjorn/chemrecon) as its backend for handling database information.
