from math import isnan
from typing import Optional

import chemrecon
import libsbml

from mntools import Compartment, MetabolicNetwork, Reaction, Species, StoichCoeff
from mntools.constants import biomass_names


def load_from_sbml(
    filename: str,
    metabolite_annotation_type: Optional[str] = "autodetect",
    reaction_annotation_type: Optional[str] = "autodetect",
) -> MetabolicNetwork:

    model = MetabolicNetwork(name="test", filename=filename)

    # Read the SBML
    reader = libsbml.SBMLReader()
    sbml_file = reader.readSBML(filename)
    sbml_model: libsbml.Model = sbml_file.getModel()

    # Determine the name of the model
    # TODO
    # Fall back to filename if name not found

    # Determine type of id annotations
    metabolite_annotation: Optional[chemrecon.IdentifierTypeCompound]
    reaction_annotation: Optional[chemrecon.IdentifierTypeReaction]
    match metabolite_annotation_type:
        case "autodetect":
            # Autodetect from the annotations
            metabolite_annotation = parse_metabolite_id_type(sbml_model)
        case None:
            # No annotation type set
            metabolite_annotation = None
        case _:
            # Try to parse the string
            metabolite_annotation = chemrecon.recognize_id_type_compound(
                metabolite_annotation_type
            )

    match reaction_annotation_type:
        case "autodetect":
            # Autodetect from the annotations
            reaction_annotation = parse_reaction_id_type(sbml_model)
        case None:
            # No annotation type set
            reaction_annotation = None
        case _:
            # Try to parse the string
            reaction_annotation = chemrecon.recognize_id_type_reaction(
                reaction_annotation_type
            )

    model.set_metabolite_annotation_type(metabolite_annotation)
    model.set_reaction_annotation_type(reaction_annotation)

    # Load compartments
    sbml_compartment_list = sbml_model.getListOfCompartments()
    for sbml_compartment in sbml_compartment_list:
        id = sbml_compartment.getId()
        name = sbml_compartment.getName()

        compartment = Compartment(id=id, name=name)
        model.add_compartment(compartment)

    # Load species
    sbml_species_list = sbml_model.getListOfSpecies()
    for sbml_species in sbml_species_list:
        id = sbml_species.getId()
        name = sbml_species.getName()
        compartment_id = sbml_species.getCompartment()
        compartment = model.get_or_create_compartment(compartment_id)

        # Annotations
        species_annotation_strs: set[str] = set()
        for cvterm in sbml_species.getCVTerms():
            for i in range(cvterm.getNumResources()):
                res = cvterm.getResourceURI(i)
                if res.startswith("http://identifiers.org"):
                    species_annotation_strs.add(res)
                elif res.startswith("https://identifiers.org"):
                    species_annotation_strs.add(res)

        species = Species(id=id, name=name, compartment=compartment)
        species.annotation_strs = species_annotation_strs
        model.add_species(species)

    # Load reactions
    sbml_reaction_list = sbml_model.getListOfReactions()
    for sbml_reaction in sbml_reaction_list:
        id = sbml_reaction.getId()
        name = sbml_reaction.getName()

        # Get species which take part
        lhs: dict[Species, StoichCoeff] = dict()
        rhs: dict[Species, StoichCoeff] = dict()

        for stoich_mult, listOfSpeciesRefs in [
            (-1, sbml_reaction.getListOfReactants()),
            (1, sbml_reaction.getListOfProducts()),
        ]:
            float_stoich_dict: dict[Species, float] = dict()
            int_stoich_dict: dict[Species, int] = dict()

            for sbml_species_ref in listOfSpeciesRefs:
                stoich_float = sbml_species_ref.getStoichiometry()
                species_id = sbml_species_ref.getSpecies()
                species = model.get_species(species_id)
                if species is None:
                    raise ValueError(
                        f"Reaction {id} refers to species {species_id} not found in model."
                    )

                if species in float_stoich_dict:
                    # In this case, assume multiple entries correspond to stoichiometry
                    float_stoich_dict[species] += 1
                    int_stoich_dict[species] += 1

                if isnan(stoich_float):
                    # If no stoichiometry is provided, assume 1
                    stoich_float = 1

                float_stoich_dict[species] = stoich_float * stoich_mult
                int_stoich_dict[species] = int(stoich_float * stoich_mult)

            # Set the dicts
            match stoich_mult:
                case -1:
                    lhs = int_stoich_dict
                case 1:
                    rhs = int_stoich_dict

        # Annotations
        reaction_annotation_strs: set[str] = set()
        for cvterm in sbml_reaction.getCVTerms():
            for i in range(cvterm.getNumResources()):
                res = cvterm.getResourceURI(i)
                if res.startswith("http://identifiers.org"):
                    reaction_annotation_strs.add(res)
                elif res.startswith("https://identifiers.org"):
                    reaction_annotation_strs.add(res)

        # Create reaction and add
        reaction = Reaction(id=id, name=name, lhs=lhs, rhs=rhs)
        reaction.annotation_strs = reaction_annotation_strs
        model.add_reaction(reaction)

    # Finalize and validate
    model.process()
    return model


def is_id_special(id: str) -> bool:
    """Whether a reaction/metabolite id is 'nonstandard', or in some sense apart from the majority of compounds.
    For example, the biomass species is 'special'.
    """
    if id.lower() in biomass_names:
        return True

    return False


def parse_metabolite_id_type(
    sbml_model: libsbml.Model,
) -> Optional[chemrecon.IdentifierTypeCompound]:
    id_strings: list[str] = list()
    sbml_species_list = sbml_model.getListOfSpecies()
    for sbml_species in sbml_species_list:
        species_id = sbml_species.getId()
        id_strings.append(species_id)

    # Check if ChEbI
    if all(s.startswith("M_chebi") for s in id_strings if not is_id_special(s)):
        return chemrecon.C_CHEBI

    # Check if BiGG
    if all(s.startswith("M_") for s in id_strings if not is_id_special(s)):
        return chemrecon.C_BIGG

    # If none found, return none
    return None


def parse_reaction_id_type(
    sbml_model: libsbml.Model,
) -> Optional[chemrecon.IdentifierTypeReaction]:
    id_strings: list[str] = list()
    sbml_reaction_list = sbml_model.getListOfReactions()
    for sbml_reaction in sbml_reaction_list:
        reaction_id = sbml_reaction.getId()
        id_strings.append(reaction_id)

    # Check if BiGG
    if all(s.startswith("R_") for s in id_strings if not is_id_special(s)):
        return chemrecon.R_BIGG

    # If none found, return none
    return None
