from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from mntools.species import Species


class Compartment:
    """todo."""

    id: str  #: Primary identifier
    name: str  #: Name, if present

    # Network
    _species: list[Species]

    # Getters
    def species(self) -> list[Species]:
        return self._species

    # Setters
    def __init__(self, id: str, name: Optional[str]):
        self.id = id
        self.name = name if name is not None else id

        self._species = list()

    def add_species(self, species: Species):
        if species in self._species:
            raise ValueError(f"Species {species} already in compartment {self.id}.")
        self._species.append(species)

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.id
