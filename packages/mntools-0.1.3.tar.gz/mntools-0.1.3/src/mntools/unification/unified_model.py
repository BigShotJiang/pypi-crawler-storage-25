from collections import defaultdict
from typing import Callable

import chemrecon

from mntools import MetabolicNetwork, Species

# Unification functions
# ==============================================================================================================
#: A function called on the species producing a string which should be the same for species that we wish to
# unify.
type SpeciesUnificationFunction = Callable[[Species], str]


def unify_species_by_name(species: Species) -> str:
    return species.name


# Unified data structures
# ==============================================================================================================
class UnifiedCompound:
    """Represents the unification of identical species/compounds across different models/compartments."""

    unified_id: str
    model_species: dict[MetabolicNetwork, set[Species]]

    # Inherited field from the species
    primary_ids: set[str]
    names: set[str]
    entries: set[chemrecon.Compound]

    def add_species(
        self,
        model: MetabolicNetwork,
        species: Species,
        unification_method: SpeciesUnificationFunction,
    ):
        """Add a species to unify with this general compound"""
        self.model_species[model].add(species)
        if self.unified_id is None:
            self.unified_id = unification_method(species)

        # Add fields
        self.primary_ids.add(species.id)
        self.names.add(species.name)
        self.entries.update(species.entries)

    def __init__(self, unified_id: str):
        """ """
        self.unified_id = unified_id
        self.model_species = defaultdict(set)
        self.entries = set()
        self.primary_ids = set()
        self.names = set()
        self.entries = set()


class UnifiedModel:
    """A representation of the unification of a number of metabolic networks, unifying the namespace
    of the compounds.
    """

    # TODO also add unification support for compartments, reactions, ...

    models: list[MetabolicNetwork]

    # Unified compounds
    unification_method_species: SpeciesUnificationFunction
    unification_table_species: dict[str, UnifiedCompound]

    # Getters
    # ----------------------------------------------------------------------------------------------------------
    def get_unified_compounds(self) -> set[UnifiedCompound]:
        return set(self.unification_table_species.values())

    # Creation
    # ----------------------------------------------------------------------------------------------------------
    def __init__(
        self,
        species_unification_function: SpeciesUnificationFunction,
    ):
        """Initialize an empty unification model with the given functions."""
        self.models = list()

        # Species
        self.unification_method_species = species_unification_function
        self.unification_table_species = dict()

    def add_model(self, model: MetabolicNetwork):
        """Adds a model and unifies its entities."""
        if model in self.models:
            raise ValueError("Model already in unified model.")
        self.models.append(model)

        # Add species
        for species in model.all_species():
            self.add_species(model, species)

        # TODO add reactions

        # Done.
        pass

    def add_species(self, model: MetabolicNetwork, species: Species) -> UnifiedCompound:
        """Add a species to the unified model, automatically unifying it with other species. Returns the
        unified compound representation.
        """
        unified_id = self.unification_method_species(species)
        try:
            unified_compound = self.unification_table_species[unified_id]
        except KeyError:
            unified_compound = UnifiedCompound(unified_id)
            unified_compound.add_species(
                model, species, self.unification_method_species
            )
            self.unification_table_species[unified_id] = unified_compound

        return unified_compound
