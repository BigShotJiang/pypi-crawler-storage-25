"""The unification module contains data structures to store 'unified models', where compounds, reactions,
and compartments are identified across models or compartments.
"""

from mntools.unification.unified_model import (
    SpeciesUnificationFunction,
    UnifiedCompound,
    UnifiedModel,
    # Methods
    unify_species_by_name,
)
from mntools.unification.unify import unify

__all__ = [
    "unify",
    "UnifiedModel",
    "UnifiedCompound",
    "SpeciesUnificationFunction",
    "unify_species_by_name",
]
