from mntools.metabolicnetwork import MetabolicNetwork
from mntools.unification.unified_model import SpeciesUnificationFunction, UnifiedModel


def unify(
    models: list[MetabolicNetwork],
    unification_method_species: SpeciesUnificationFunction,
) -> UnifiedModel:
    """Given a set of metabolic network models, produce a unified model which identifies compounds and species
    across the given models.
    """
    unified_model = UnifiedModel(unification_method_species)
    for model in models:
        unified_model.add_model(model)

    return unified_model
