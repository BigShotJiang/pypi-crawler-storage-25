from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import chemrecon

from mntools.types import Side
from mntools.warning import ModelWarning

if TYPE_CHECKING:
    from mntools.compartment import Compartment
    from mntools.metabolite import Metabolite
    from mntools.species import Species
    from mntools.types import StoichCoeff


class Reaction:
    """A reaction."""

    id: str  #: Primary identifier
    name: str  #:

    # Annotations
    primary_entry: Optional[chemrecon.Reaction]
    entries: set[chemrecon.Reaction]
    annotation_strs: set[str]

    # Network
    _species: dict[Side, dict[Species, StoichCoeff]]
    _metabolites: dict[Side, set[Metabolite]] = dict()
    _compartments: dict[Side, set[Compartment]] = dict()

    # Meta
    warnings: list[ModelWarning]

    # Properties
    is_biomass_reaction: bool
    #  - Reversibility
    #  - TODO reversible?
    #  - Transport reactions
    #  - TODO types (simple, antiporter, synporter ...)?
    is_transport_reaction: bool  #: We consider a reaction a transport reaction if it spans more than 1 compartment
    is_transport_reaction_1to1: (
        bool  #: A transport reaction involving only the transported metabolites.
    )

    # Getters
    def get_lhs(self) -> dict[Species, StoichCoeff]:
        return self._species[Side.L]

    def get_rhs(self) -> dict[Species, StoichCoeff]:
        return self._species[Side.R]

    def get_lhs_metabolites(self) -> dict[Metabolite, StoichCoeff]:
        return {
            s.associated_metabolite: coeff
            for s, coeff in self._species[Side.L].items()
            if s.associated_metabolite is not None
        }

    def get_rhs_metabolites(self) -> dict[Metabolite, StoichCoeff]:
        return {
            s.associated_metabolite: coeff
            for s, coeff in self._species[Side.R].items()
            if s.associated_metabolite is not None
        }

    def get_species(self) -> set[Species]:
        """Get the species which appear on both the LHS and RHS, if any."""
        return set(self._species[Side.L].keys()) | set(self._species[Side.R].keys())

    def get_metabolites(self) -> set[Metabolite]:
        """Get the metabolites involved in the reaction (species independent of compartment)."""
        return set(self._metabolites[Side.L]) | set(self._metabolites[Side.R])

    def get_species_with_sum_stoichiometry(self) -> dict[Species, StoichCoeff]:
        """Get all species involved and their stoichiometric coefficient.
        If a species appears on both sides, the sum stoichiometric coefficient is listed.
        """
        return {
            s: self._species[Side.L].get(s, 0) + self._species[Side.R].get(s, 0)
            for s in self._species[Side.L].keys() | self._species[Side.R].keys()
        }

    def get_metabolites_with_sum_stoichiometry(self) -> dict[Metabolite, StoichCoeff]:
        """Get all metabolites involved and their stoichiometric coefficient.
        If a metabolite appears on both sides, the sum stoichiometric coefficient is listed.
        This lists _metabolites_, not species.
        So if this is a transport reaction, the sum stoichiometry should be 0.
        """
        # TODO
        raise NotImplementedError()

    def get_compartment(self) -> Optional[Compartment]:
        """If not a transport reaction, return the compartment in which the reaction takes place."""
        if self.is_transport_reaction:
            return None
        else:
            assert (
                len(self._compartments[Side.L]) == 1
                and len(self._compartments[Side.R]) == 1
            ), "Reaction should only involve one compartment"
            return next(iter(self._compartments[Side.L]))

    def get_compartments(self) -> set[Compartment]:
        """Get the compartments of hte species involved in the reaction."""
        return set(self._compartments[Side.L]) | set(self._compartments[Side.R])

    def __init__(
        self,
        id: str,
        name: Optional[str],
        lhs: dict[Species, StoichCoeff],
        rhs: dict[Species, StoichCoeff],
    ):
        # Annotation
        self.id = id
        self.name = name if name is not None else id
        self.primary_entry = None
        self.entries = set()
        self.annotation_strs = set()

        # Network
        self._species = {Side.L: lhs, Side.R: rhs}
        self._metabolites = dict()
        self._compartments = dict()

        # Properties
        # TODO determine whether this represents biomass
        self.is_biomass_reaction = False

    def process(self):
        # Assign metabolites and compartments
        self._metabolites[Side.L] = set()
        self._metabolites[Side.R] = set()
        self._compartments[Side.L] = set()
        self._compartments[Side.R] = set()
        for side in [Side.L, Side.R]:
            for s in self._species[side]:
                self._compartments[side].add(s.compartment)
                if s.associated_metabolite is not None:
                    self._metabolites[side].add(s.associated_metabolite)
                else:
                    # TODO raise a warning?
                    pass

        # Identify whether this is a transport reaction
        match len(self.get_compartments()):
            # TODO other types of transport reactions (synporter, antiporter, etc.)?
            case 1:
                self.is_transport_reaction = False
                self.is_transport_reaction_1to1 = False
            case 2:
                # Direct transport
                self.is_transport_reaction = True

                # Check whether 1-to-1 (same metabolites in both compartments)
                if self._metabolites[Side.L] == self._metabolites[Side.R]:
                    self.is_transport_reaction_1to1 = True
                else:
                    self.is_transport_reaction_1to1 = False

            case _:
                # Multiple compartments involved.
                # TODO improve support for this case
                self.is_transport_reaction = True
                self.is_transport_reaction_1to1 = False

        # Reversibility
        # TODO:
        #  - Check if set in SBML?
        #  - Check if has an inverse reaction somewhere?

        # Done processing this reaction
        pass

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.id
