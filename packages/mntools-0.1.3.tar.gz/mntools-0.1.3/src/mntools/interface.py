"""This module contains various interface functions."""

from __future__ import annotations

from typing import Optional

from mntools import MetabolicNetwork, UnifiedModel
from mntools.load.loader_sbml import load_from_sbml
from mntools.unification import SpeciesUnificationFunction, unify, unify_species_by_name


def load_sbml_file_to_model(
    filename: str,
    metabolite_annotation_type: Optional[str] = "autodetect",
    reaction_annotation_type: Optional[str] = "autodetect",
) -> MetabolicNetwork:
    """Load an SBML model from a file and return a Model object."""
    return load_sbml_files_to_models(
        [filename], metabolite_annotation_type, reaction_annotation_type
    )[0]


def load_sbml_files_to_models(
    filenames: list[str],
    metabolite_annotation_type: Optional[str] = "autodetect",
    reaction_annotation_type: Optional[str] = "autodetect",
) -> list[MetabolicNetwork]:
    """Load a list of SBML models from files and return a list of Model objects."""
    return [
        load_from_sbml(fname, metabolite_annotation_type, reaction_annotation_type)
        for fname in filenames
    ]


def load_sbml_file_to_unified_model(
    filename: str,
    unification_method_species: SpeciesUnificationFunction = unify_species_by_name,
) -> UnifiedModel:
    """Load an SBML model from a file and return a UnifiedModel object."""
    return load_sbml_files_to_unified_models([filename], unification_method_species)


def load_sbml_files_to_unified_models(
    filenames: list[str],
    unification_method_species: SpeciesUnificationFunction = unify_species_by_name,
) -> UnifiedModel:
    """Load a list of SBML models from files and return a UnifiedModel object."""
    models = load_sbml_files_to_models(filenames)
    return unify(models, unification_method_species=unification_method_species)
