"""Various tables."""

# Names and ids to recognize the extracellular compartment.
extracellular_names: set[str] = {
    "external",
    "extracellular",
    "external_species",
    "c_e",
    "e",
    "External_Species",
    "C_e",
    "extracellular space",
}

biomass_names: set[str] = {
    "biomass",
    "growth",
    "biomass reaction",
}
