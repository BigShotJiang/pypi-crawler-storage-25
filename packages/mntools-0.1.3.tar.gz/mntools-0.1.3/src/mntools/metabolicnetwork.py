"""Main class for defining a metabolic network."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Optional

import chemrecon
from chemrecon.utils.get_id_type import get_id_from_identifiers_org

from mntools.compartment import Compartment
from mntools.metabolite import Metabolite
from mntools.reaction import Reaction
from mntools.species import Species
from mntools.warning import ModelWarning

# Notes:
#  SBML: id and metaid (see: https://sbml.org/documents/elaborations/metaid_syntax/)
#   - id: Must conform to XML id standard
#   - metaid: Legacy - does not need to conform to XML id standard
#  Only use ID - metaid is always just id, but with meta_ prefix or similar.


class MetabolicNetwork:
    """A chemical reaection network."""

    # Basics
    name: str
    filename: str  #: Filename from which this was created.
    model_text: Optional[str]  #: The text file defining the model, if available.
    native_repr: Any  #:

    # Annotations
    _metabolite_annotation_type: Optional[chemrecon.IdentifierTypeCompound]
    _reaction_annotation_type: Optional[chemrecon.IdentifierTypeReaction]

    # Network
    _species: list[Species]
    _metabolites: list[Metabolite]
    _reactions: list[Reaction]
    _compartments: list[Compartment]

    # Network graph
    # TODO

    # Lookup tables
    _compartment_lookup: dict[str, Compartment]  # Lookup for compartments by suffix
    _species_lookup: dict[str, Species]
    _metabolite_lookup: dict[str, Metabolite]
    _reaction_lookup: dict[str, Reaction]

    # Meta
    loader: Optional[
        Any  # TODO
    ]  #: The loader, which created this network, if any. Can be used to access load warnings (parser warnings).
    warnings: list[
        ModelWarning
    ]  #: Any semantic uncertainties encountered when loading the network.

    # Getters
    # ------------------------------------------------------------------------------------------------------------------
    def all_species(self) -> list[Species]:
        return self._species

    def all_metabolites(self) -> list[Metabolite]:
        return self._metabolites

    def all_reactions(self) -> list[Reaction]:
        return self._reactions

    def all_compartments(self) -> list[Compartment]:
        return self._compartments

    def get_species(self, identifier: str) -> Optional[Species]:
        return self._species_lookup.get(identifier, None)

    def get_metabolite(self, identifier: str) -> Optional[Metabolite]:
        return self._metabolite_lookup.get(identifier, None)

    def get_reaction(self, identifier: str) -> Optional[Reaction]:
        return self._reaction_lookup.get(identifier, None)

    def get_compartment(self, identifier: str) -> Optional[Compartment]:
        return self._compartment_lookup.get(identifier, None)

    def get_or_create_compartment(self, identifier: str) -> Compartment:
        if identifier in self._compartment_lookup:
            return self._compartment_lookup[identifier]
        else:
            compartment = Compartment(id=identifier, name=None)
            self.add_compartment(compartment)
            return compartment

    # Analysis
    # ----------------------------------------------------------------------------------------------------------
    # TODO get graph

    # TODO get stoich matrix

    # Warnings
    # ----------------------------------------------------------------------------------------------------------
    def get_warnings_and_errors(self) -> list[ModelWarning]:
        """List all the errors and warnings encountered when loading this model."""
        # TODO
        raise NotImplementedError()

    # Metabolic network creation
    # ----------------------------------------------------------------------------------------------------------
    def __init__(
        self,
        name: str,
        filename: str,
        model_text: Optional[str] = None,
    ):
        """ """
        # Model information
        self.name = name
        self.filename = filename.split("/")[-1]
        self.model_text = model_text

        # Annotations
        self._metabolite_annotation_type = None
        self._reaction_annotation_type = None

        # Reaction network
        self._species = list()
        self._metabolites = list()
        self._reactions = list()
        self._compartments = list()

        self._species_lookup = dict()
        self._metabolite_lookup = dict()
        self._reaction_lookup = dict()
        self._compartment_lookup = dict()

        # Meta
        self.warnings = list()

    # Set annotations
    def set_metabolite_annotation_type(
        self, annotation_type: Optional[chemrecon.IdentifierTypeCompound]
    ):
        """If the 'id' field of the model correspond to specific database annotations, MNTools can extract database
        entries from the ids. Enter a string like 'bigg' or 'chebi' to associate a database entry with the compound ids.
        """
        self._metabolite_annotation_type = annotation_type

    def set_reaction_annotation_type(
        self, annotation_type: Optional[chemrecon.IdentifierTypeReaction]
    ):
        """If the 'id' field of the model correspond to specific database annotations, MNTools can extract database
        entries from the ids. Enter a string like 'bigg' or 'chebi' to associate a database entry with the reaction ids.
        """
        self._reaction_annotation_type = annotation_type

    # Adding network elements
    def add_species(self, species: Species):
        self._species.append(species)
        self._species_lookup[species.id] = species

        # Add to compartment
        species.compartment.add_species(species)

    def add_metabolite(self, metabolite: Metabolite):
        self._metabolites.append(metabolite)
        self._metabolite_lookup[metabolite.id] = metabolite
        for species in metabolite.species():
            if species.associated_metabolite is not None:
                raise ValueError(
                    f"Attempting to assign metabolite to {species} already associated with metabolite {metabolite}."
                )
            species.associated_metabolite = metabolite

    def add_reaction(self, reaction: Reaction):
        self._reactions.append(reaction)
        self._reaction_lookup[reaction.id] = reaction
        for species, coeff in reaction.get_species_with_sum_stoichiometry().items():
            species.add_reaction(reaction, coeff)

    def add_compartment(self, compartment: Compartment):
        if compartment.id in self._compartment_lookup:
            raise ValueError(f"Compartment with id {compartment.id} already exists.")
        self._compartments.append(compartment)
        self._compartment_lookup[compartment.id] = compartment

    def process(self):
        """To be called after adding all elements to the model. Will perform sanity checks and
        post-processing."""

        # Identify and create metabolites (identify species across compartments).
        # - by name
        name_lookup_dict: dict[str, set[Species]] = defaultdict(set)
        for s in self._species:
            if s.name is not None:
                name_lookup_dict[s.name].add(s)
        for common_name, species_set in name_lookup_dict.items():
            metabolite = Metabolite(
                species_set, unified_id=common_name, unified_by="name"
            )
            self.add_metabolite(metabolite)

        # TODO also try to identify compounds based on annotation
        #  - If BiGG/ChEBI: Can parse based on common prefix

        # When metabolites are created, we can process the metabolites/compartments information for all
        # reactions
        for r in self._reactions:
            r.process()

        # Remove empty compartments
        compartments_to_remove: list[Compartment] = list()
        for comp in self._compartments:
            if len(comp.species()) == 0:
                compartments_to_remove.append(comp)

        compartment_keys_to_remove: list[str] = list()
        for comp in compartments_to_remove:
            self._compartments.remove(comp)
            compartment_keys_to_remove.append(comp.id)

        for key in compartment_keys_to_remove:
            del self._compartment_lookup[key]

        # Validate
        #  - All species are in a compartment
        for s in self._species:
            if s.compartment is None or s.compartment not in self._compartments:
                raise ValueError(f"Species {s} is not in a compartment.")

        # - Verify that all species have associated metabolite
        for s in self._species:
            if s.associated_metabolite is None:
                raise ValueError(f"Species {s} does not have metabolite assigned.")

        # - Verify reactions
        # TODO

        # Finalize
        pass

    def create_annotations(self):
        """Adds the annotations as ChemRecon proto-entries (with no looked-up recon id).
        So the entry annotations may or may not exist in ChemRecon.
        TODO add a method which also looks up the entries.
        """
        # Load all identifiers
        compound_annotation_str_map: dict[str, Optional[chemrecon.Compound]] = dict()
        reaction_annotation_str_map: dict[str, Optional[chemrecon.Reaction]] = dict()
        for s in self.all_species():
            for annotation_str in s.annotation_strs:
                compound_annotation_str_map[annotation_str] = None
        for r in self.all_reactions():
            for annotation_str in r.annotation_strs:
                reaction_annotation_str_map[annotation_str] = None

        # Create 'prototype' entries from the identifiers.org strings
        prototype_entries_compound: dict[str, chemrecon.Compound] = dict()
        for compound_str in compound_annotation_str_map.keys():
            id_org_result = get_id_from_identifiers_org(
                compound_str, chemrecon.IdentifierTypeCompound
            )
            if id_org_result is not None:
                prototype_entries_compound[compound_str] = chemrecon.Compound(
                    id_type=id_org_result[0].enum_type,
                    source_id=id_org_result[0].std_identifier(id_org_result[1]),
                )
        prototype_entries_reaction: dict[str, chemrecon.Reaction] = dict()
        for reaction_str in reaction_annotation_str_map.keys():
            id_org_result = get_id_from_identifiers_org(
                reaction_str, chemrecon.IdentifierTypeCompound
            )
            if id_org_result is not None:
                prototype_entries_reaction[reaction_str] = chemrecon.Reaction(
                    id_type=id_org_result[0].enum_type,
                    source_id=id_org_result[0].std_identifier(id_org_result[1]),
                )

        # Assign the prototype entries
        for s in self.all_species():
            s.entries = set()
            for annotation_str in s.annotation_strs:
                try:
                    s.entries.add(prototype_entries_compound[annotation_str])
                except KeyError:
                    # Not found. TODO log warning?
                    pass

        for r in self.all_reactions():
            r.entries = set()
            for annotation_str in r.annotation_strs:
                try:
                    r.entries.add(prototype_entries_reaction[annotation_str])
                except KeyError:
                    # Not found. TODO log warning?
                    pass

        # Add entries to metabolites (union of entries of associated species)
        for m in self.all_metabolites():
            m.entries = set.union(*[s.entries for s in m.species()])
            pass

        # Done.
        pass

    def lookup_annotations(self):
        # TODO method for getting additional data from the looked up annotations in the ChemRecon db.
        pass
