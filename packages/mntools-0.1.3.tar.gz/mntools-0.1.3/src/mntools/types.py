from enum import Enum


class Side(Enum):
    L = -1
    R = 1


type StoichCoeff = int
