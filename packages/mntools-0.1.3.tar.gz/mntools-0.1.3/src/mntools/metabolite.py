from __future__ import annotations

from typing import TYPE_CHECKING, Iterable, Optional

import chemrecon

from mntools.warning import ModelWarning

if TYPE_CHECKING:
    from mntools.compartment import Compartment
    from mntools.species import Species


class Metabolite:
    """
    In this model, a `Metabolite` is a set of species that are in different compartments.
    """

    id: str  #: Primary identifier
    name: str  #:

    # Annotations
    primary_entry: Optional[chemrecon.Compound]
    entries: set[chemrecon.Compound]
    unified_by: str

    # Network
    _species: set[Species]
    _species_by_compartment: dict[Compartment, Species] = dict()

    # Meta
    warnings: list[ModelWarning]

    def species(self) -> set[Species]:
        return self._species

    def get_species_in_compartment(self, compartment: Compartment) -> Optional[Species]:
        return self._species_by_compartment.get(compartment, None)

    def __init__(self, species: Iterable[Species], unified_id: str, unified_by: str):
        """The 'unified_by' field determines the common field unifying the species that make up the compound."""
        self._species = set()
        self.id = unified_id
        self.unified_by = unified_by
        self._species_by_compartment = dict()
        for s in species:
            if s in self._species:
                raise ValueError(f"Species {s} already in metabolite {self.id}.")
            self._species.add(s)
            self._species_by_compartment[s.compartment] = s

        # Derive name/id from the species
        if self.unified_by == "name":
            self.name = unified_id

        # Derive entries
        self.entries = next(iter(species)).entries
        for s in species:
            if s.entries != self.entries:
                # TODO raise warning
                self.entries.update(s.entries)

        # The primary entry of the metabolite is the primary entry of the species only if all agree.
        primary_entry = next(iter(species)).primary_entry
        if all(s.primary_entry == primary_entry for s in species):
            self.primary_entry = primary_entry
        else:
            self.primary_entry = None

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.id
