from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Any, Optional

import chemrecon

from mntools.warning import ModelWarning

if TYPE_CHECKING:
    from mntools.compartment import Compartment
    from mntools.metabolite import Metabolite
    from mntools.reaction import Reaction
    from mntools.types import StoichCoeff


class Species:
    """
    A species is a type of entity that can participate in reactions.
    In this model, a species is a `Metabolite` in a particular `Compartment`.
    """

    id: str  #: Primary identifier
    name: str  #:

    # Annotations
    primary_entry: Optional[chemrecon.Compound]
    entries: set[chemrecon.Compound]
    annotation_strs: set[str]
    is_biomass: bool

    # Network
    compartment: Compartment
    associated_metabolite: Optional[Metabolite]
    _in_reactions: dict[Reaction, StoichCoeff]

    # Meta
    warnings: list[ModelWarning]

    # Getters
    def get_reactions(self) -> dict[Reaction, StoichCoeff]:
        """Get a list of reactions that this species participates in.
        If the species appears on both sides of the reaction, the sum stoichiometric coefficient is listed.
        """
        return {r: stoich for r, stoich in self._in_reactions.items() if stoich != 0}

    # Creation
    def add_reaction(self, reaction: Reaction, stoich: StoichCoeff):
        if reaction in self._in_reactions:
            raise ValueError(f"Species {self.id} already in reaction {reaction.id}.")
        self._in_reactions[reaction] = stoich

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.id

    def __init__(
        self,
        id: str,
        name: Optional[str],
        compartment: Compartment,
    ):
        self.id = id
        self.name = name if name is not None else id
        self.primary_entry = None
        self.entries = set()
        self.annotation_strs = set()
        self.compartment = compartment
        self._in_reactions = defaultdict(int)
        self.associated_metabolite = None
        self.warnings = list()

        # TODO determine whether this represents biomass
        self.is_biomass = False
