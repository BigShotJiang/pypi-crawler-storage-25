import math
from fractions import Fraction


def scale_to_integer(values: list[float]) -> list[int]:
    fracs = [Fraction(v) for v in values]
    denominator_lcm = math.lcm(*[f.denominator for f in fracs])
    ints = [int(f * denominator_lcm) for f in fracs]
    return ints
