class ModelWarning(Exception):
    """A warning emitted by the model loading procedure."""

    message: str


# Types of warnings
# --------------------------------------------------------------------------------------------------------------
class SyntaxWarning(ModelWarning):
    """Something wrong with the syntax of the SBML file."""

    # TODO
    pass


# TODO warn when different annotations between species with the same name(compound)
