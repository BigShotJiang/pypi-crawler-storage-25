################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains IP host base class.

net_addr/ip_host.py

ver 3.0.4
"""

from abc import ABC, abstractmethod
from typing import override

from net_addr.base import Base
from net_addr.ip import Ip
from net_addr.ip4_address import Ip4Address
from net_addr.ip4_host_origin import Ip4HostOrigin
from net_addr.ip4_network import Ip4Network
from net_addr.ip6_address import Ip6Address
from net_addr.ip6_host_origin import Ip6HostOrigin
from net_addr.ip6_network import Ip6Network


class IpHost[
    A: (Ip6Address, Ip4Address),
    N: (Ip6Network, Ip4Network),
    O: (Ip6HostOrigin, Ip4HostOrigin),
](Base, Ip, ABC):
    """
    IP host support base class.
    """

    __slots__ = (
        "_address",
        "_network",
        "_gateway",
        "_origin",
        "_expiration_time",
    )

    _address: A
    _network: N
    _gateway: A | None
    _origin: O
    _expiration_time: int

    @override
    def __str__(self) -> str:
        """
        Get the IP host address log string.
        """

        return f"{self._address}/{len(self._network.mask)}"

    @override
    def __eq__(self, other: object, /) -> bool:
        """
        Compare the IP host address with another object.
        """

        return other is self or (
            isinstance(other, type(self)) and self._address == other._address and self._network == other._network
        )

    @override
    def __hash__(self) -> int:
        """
        Get the IP host hash value.
        """

        return hash((type(self), self._address, self._network))

    @abstractmethod
    def _validate_gateway(self, address: A | None, /) -> None:
        """
        Validate the IP host address gateway.
        """

        raise NotImplementedError

    @property
    def address(self) -> A:
        """
        Get the IP host address '_address' attribute.
        """

        return self._address

    @property
    def network(self) -> N:
        """
        Get the IP host address '_network' attribute.
        """

        return self._network

    @property
    def origin(self) -> O:
        """
        Get the IP host address '_origin' attribute.
        """

        return self._origin

    @origin.setter
    def origin(self, origin: O, /) -> None:
        """
        Set the IP host address '_origin' attribute.
        """

        self._origin = origin

    @property
    def expiration_time(self) -> int:
        """
        Get the IP host address '_expiration_time' attribute.
        """

        return self._expiration_time

    @expiration_time.setter
    def expiration_time(self, time: int, /) -> None:
        """
        Set the IP host address '_expiration_time' attribute.
        """

        self._expiration_time = time

    @property
    def gateway(self) -> A | None:
        """
        Get the IP host address '_gateway' attribute.
        """

        return self._gateway

    @gateway.setter
    def gateway(self, address: A | None, /) -> None:
        """
        Set the IP host address '_gateway' attribute.
        """

        self._validate_gateway(address)

        self._gateway = address
