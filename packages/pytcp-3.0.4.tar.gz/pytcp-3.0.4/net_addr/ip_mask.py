################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains IP mask base class.

net_addr/ip_mask.py

ver 3.0.4
"""

from abc import ABC, abstractmethod
from typing import override

from net_addr.base import Base
from net_addr.ip import Ip


class IpMask(Base, Ip, ABC):
    """
    IP mask support base class.
    """

    __slots__ = ("_mask",)

    _mask: int

    def __len__(self) -> int:
        """
        Get the IP mask prefix length.
        """

        return self._mask.bit_count()

    @override
    def __str__(self) -> str:
        """
        Get the IP mask log string.
        """

        return f"/{len(self)}"

    @abstractmethod
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the IP mask as a memoryview.
        """

        raise NotImplementedError

    def __int__(self) -> int:
        """
        Get the IP mask as integer.
        """

        return self._mask

    @override
    def __eq__(self, other: object, /) -> bool:
        """
        Compare the IP mask with another object.
        """

        return other is self or (isinstance(other, type(self)) and self._mask == other._mask)

    @override
    def __hash__(self) -> int:
        """
        Get the IP mask hash value.
        """

        return hash((type(self), self._mask))

    def _validate_bits(self, bytes_len: int, /) -> bool:
        """
        Validate that mask is made of consecutive bits.
        """

        inverted = (~self._mask) & ((1 << bytes_len) - 1)
        return inverted & (inverted + 1) == 0
