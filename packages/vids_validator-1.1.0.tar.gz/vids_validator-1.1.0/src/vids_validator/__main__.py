"""Allow running as: python -m vids_validator /path/to/dataset"""
from .validator import main

main()
