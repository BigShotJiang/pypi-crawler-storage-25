"""
VIDS Validator — Reference validator for the Verified Imaging Dataset Standard.

Usage:
    CLI:        vids-validate /path/to/dataset
    CLI (JSON): vids-validate /path/to/dataset --json
    Python:     from vids_validator import VIDSValidator

Zero dependencies beyond the Python standard library.
"""

from .validator import VIDSValidator, print_report, main

__version__ = "1.1.0"
__all__ = ["VIDSValidator", "print_report", "main", "__version__"]
