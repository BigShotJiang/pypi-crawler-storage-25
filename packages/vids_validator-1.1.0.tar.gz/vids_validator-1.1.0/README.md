# VIDS Validator

[![PyPI](https://img.shields.io/pypi/v/vids-validator)](https://pypi.org/project/vids-validator/)
[![Python](https://img.shields.io/pypi/pyversions/vids-validator)](https://pypi.org/project/vids-validator/)
[![License](https://img.shields.io/badge/license-Apache%202.0-green)](https://github.com/vids-standard/vids-standard/blob/main/LICENSE-TOOLS)

Reference validator for the **[VIDS (Verified Imaging Dataset Standard)](https://github.com/vids-standard/vids-standard)** specification.

Zero dependencies. Python 3.8+. One command.

## Install

```bash
pip install vids-validator
```

## Usage

### Command line

```bash
# Validate a dataset (auto-detects profile from .vids marker)
vids-validate /path/to/dataset

# Explicit Full profile validation
vids-validate /path/to/dataset --profile full

# JSON output (for CI pipelines)
vids-validate /path/to/dataset --json

# Save report to file
vids-validate /path/to/dataset --output report.json
```

### Python API

```python
from vids_validator import VIDSValidator

validator = VIDSValidator("/path/to/dataset", profile="auto")
report = validator.validate()

print(report["Summary"]["Status"])  # "PASS" or "FAIL"
print(report["Summary"]["Passed"])  # number of rules passed
```

### As a module

```bash
python -m vids_validator /path/to/dataset
```

## What it checks

21 validation rules across 6 categories:

| Category | Rules | Scope |
|----------|-------|-------|
| Structure (S001–S006) | `.vids` marker, `dataset_description.json`, participants, README, subject/session dirs | All profiles |
| Imaging (I001–I004) | NIfTI files, sidecar JSONs, valid JSON, naming convention | All profiles |
| Annotation (A001–A005) | Annotation directory, segmentation files, sidecars, provenance fields | All profiles |
| Quality (Q001–Q003) | Quality directory, quality summary, annotation agreement | Full only |
| ML (M001–M002) | ML directory, splits.json | Full only |
| Metadata (D001) | CHANGES.md | All (WARN) |

A dataset is **compliant** if and only if zero rules have FAIL status.

## Profiles

- **POC** (15 rules) — quick prototypes, pilots, internal research
- **Full** (21 rules) — production, publications, regulatory submissions

The profile is declared in the `.vids` marker file at the dataset root.

## Exit codes

- `0` — validation passed
- `1` — validation failed

## Links

- [VIDS Specification](https://github.com/vids-standard/vids-standard/blob/main/SPEC.md)
- [Validation Rules](https://github.com/vids-standard/vids-standard/blob/main/VALIDATION_RULES.md)
- [Example Datasets](https://github.com/vids-standard/vids-standard/blob/main/EXAMPLES.md)
- [Contributing](https://github.com/vids-standard/vids-standard/blob/main/CONTRIBUTING.md)

## License

Apache License 2.0 — see [LICENSE](https://github.com/vids-standard/vids-standard/blob/main/LICENSE-TOOLS).

VIDS was created by [Princeton Medical Systems](https://princetonmed.systems) and is maintained as an open community standard.
