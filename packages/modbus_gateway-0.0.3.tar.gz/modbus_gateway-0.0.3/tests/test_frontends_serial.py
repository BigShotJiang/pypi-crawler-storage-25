"""Serial frontend tests placeholder."""
