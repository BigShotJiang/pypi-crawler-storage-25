"""Frontend implementations."""
