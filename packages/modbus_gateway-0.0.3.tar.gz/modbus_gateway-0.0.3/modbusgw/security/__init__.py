"""Security helpers."""
