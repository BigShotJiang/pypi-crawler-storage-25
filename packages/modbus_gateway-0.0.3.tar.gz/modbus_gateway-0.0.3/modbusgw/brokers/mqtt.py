"""MQTT broker placeholder."""
