"""Correlator tests — session lifecycle, flow attribution, orphan detection."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import pytest

from mcp_defense.correlation.join import CapturingActionSink, Correlator
from mcp_defense.events import (
    Decision,
    FlowEvent,
    PolicyDecisionEvent,
    ToolCallEvent,
)


def _tool_call(
    correlation_id: str = "tc_aaa",
    server_pid: int = 4242,
    cgroup_id: int | None = 9999,
) -> ToolCallEvent:
    return ToolCallEvent(
        correlation_id=correlation_id,
        timestamp=datetime.now(timezone.utc),
        agent_id="agent-1",
        server_archetype="filesystem",
        server_pid=server_pid,
        container_id=None,
        tool_name="read_file",
        tool_args={"path": "/workspace/main.py"},
        transport="stdio",
        cgroup_id=cgroup_id,
    )


def _decision(
    correlation_id: str = "tc_aaa",
    decision: Decision = Decision.ALLOW,
    rule: str = "default_allow",
) -> PolicyDecisionEvent:
    return PolicyDecisionEvent(
        correlation_id=correlation_id,
        timestamp=datetime.now(timezone.utc),
        decision=decision,
        reason="test",
        matched_rule=rule,
    )


def _flow(
    cgroup_id: int | None = 9999,
    source_pid: int | None = None,
    dst_ip: str = "1.2.3.4",
    action: str = "PASS",
) -> FlowEvent:
    return FlowEvent(
        timestamp=datetime.now(timezone.utc),
        src_ip="10.0.0.5",
        dst_ip=dst_ip,
        src_port=50001,
        dst_port=443,
        protocol=6,
        classification="LEGITIMATE",
        action=action,
        confidence=95,
        cgroup_id=cgroup_id,
        source_pid=source_pid,
    )


@pytest.mark.asyncio
async def test_allow_plus_flows_then_expire_emits_action() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(
        action_sink=sink, window_seconds=0.15, closer_interval=0.05
    )
    await correlator.start()

    await correlator.emit(_tool_call())
    await correlator.emit_decision(_decision())
    await correlator.ingest_flow(_flow())
    await correlator.ingest_flow(_flow(dst_ip="5.6.7.8"))

    # Wait for window to expire + closer tick
    await asyncio.sleep(0.3)
    await correlator.stop()

    assert len(sink.actions) == 1
    action = sink.actions[0]
    assert action.correlation_id == "tc_aaa"
    assert len(action.flows) == 2
    assert action.policy_decision.decision == Decision.ALLOW


@pytest.mark.asyncio
async def test_deny_closes_session_immediately_no_flows() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, window_seconds=5.0, closer_interval=0.05)
    await correlator.start()

    await correlator.emit(_tool_call())
    await correlator.emit_decision(_decision(decision=Decision.DENY, rule="crown_jewel"))

    # Give the emission task a moment to run
    await asyncio.sleep(0.05)
    await correlator.stop()

    assert len(sink.actions) == 1
    assert sink.actions[0].policy_decision.decision == Decision.DENY
    assert sink.actions[0].flows == []


@pytest.mark.asyncio
async def test_require_approval_closes_immediately() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, window_seconds=5.0, closer_interval=0.05)
    await correlator.start()

    await correlator.emit(_tool_call())
    await correlator.emit_decision(
        _decision(decision=Decision.REQUIRE_APPROVAL, rule="sensitive_path")
    )

    await asyncio.sleep(0.05)
    await correlator.stop()

    assert len(sink.actions) == 1
    assert sink.actions[0].policy_decision.decision == Decision.REQUIRE_APPROVAL


@pytest.mark.asyncio
async def test_flow_without_session_emits_orphan() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, window_seconds=1.0, closer_interval=0.05)
    await correlator.start()

    await correlator.ingest_flow(_flow(cgroup_id=12345, action="DROP"))

    await asyncio.sleep(0.05)
    await correlator.stop()

    assert len(sink.orphans) == 1
    orphan = sink.orphans[0]
    assert orphan.reason == "no_matching_session"
    assert orphan.flow.action == "DROP"


@pytest.mark.asyncio
async def test_flow_attributes_via_cgroup_preferred() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, window_seconds=0.2, closer_interval=0.05)
    await correlator.start()

    # Tool call with cgroup_id=9999, pid=4242
    await correlator.emit(_tool_call(cgroup_id=9999, server_pid=4242))
    await correlator.emit_decision(_decision())

    # Flow with cgroup_id match AND a mismatched pid — cgroup wins.
    await correlator.ingest_flow(_flow(cgroup_id=9999, source_pid=9999999))

    await asyncio.sleep(0.3)
    await correlator.stop()

    assert len(sink.actions) == 1
    assert len(sink.actions[0].flows) == 1
    assert sink.orphans == []


@pytest.mark.asyncio
async def test_flow_attributes_via_pid_when_no_cgroup() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, window_seconds=0.2, closer_interval=0.05)
    await correlator.start()

    # Tool call with pid=4242, no cgroup_id
    await correlator.emit(_tool_call(cgroup_id=None, server_pid=4242))
    await correlator.emit_decision(_decision())

    # Flow with matching pid, no cgroup_id
    await correlator.ingest_flow(_flow(cgroup_id=None, source_pid=4242))

    await asyncio.sleep(0.3)
    await correlator.stop()

    assert len(sink.actions) == 1
    assert len(sink.actions[0].flows) == 1


@pytest.mark.asyncio
async def test_expired_session_does_not_match_late_flow() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(
        action_sink=sink, window_seconds=0.05, closer_interval=0.02
    )
    await correlator.start()

    await correlator.emit(_tool_call())
    await correlator.emit_decision(_decision())

    # Wait past the window — session should expire and emit.
    await asyncio.sleep(0.15)

    # Now inject a flow matching the (expired) session's cgroup_id.
    await correlator.ingest_flow(_flow(cgroup_id=9999))
    await asyncio.sleep(0.05)
    await correlator.stop()

    assert len(sink.actions) == 1
    assert sink.actions[0].flows == []
    # The late flow should have been reported as an orphan.
    assert len(sink.orphans) == 1


@pytest.mark.asyncio
async def test_concurrent_sessions_route_correctly() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, window_seconds=0.2, closer_interval=0.05)
    await correlator.start()

    await correlator.emit(_tool_call(correlation_id="tc_aaa", server_pid=1111, cgroup_id=10))
    await correlator.emit_decision(_decision(correlation_id="tc_aaa"))
    await correlator.emit(_tool_call(correlation_id="tc_bbb", server_pid=2222, cgroup_id=20))
    await correlator.emit_decision(_decision(correlation_id="tc_bbb"))

    await correlator.ingest_flow(_flow(cgroup_id=10, dst_ip="1.1.1.1"))
    await correlator.ingest_flow(_flow(cgroup_id=20, dst_ip="2.2.2.2"))
    await correlator.ingest_flow(_flow(cgroup_id=20, dst_ip="2.2.2.3"))

    await asyncio.sleep(0.3)
    await correlator.stop()

    assert len(sink.actions) == 2
    by_cid = {a.correlation_id: a for a in sink.actions}
    assert len(by_cid["tc_aaa"].flows) == 1
    assert len(by_cid["tc_bbb"].flows) == 2
    assert by_cid["tc_aaa"].flows[0].dst_ip == "1.1.1.1"


@pytest.mark.asyncio
async def test_decision_without_session_is_dropped() -> None:
    sink = CapturingActionSink()
    correlator = Correlator(action_sink=sink, closer_interval=0.05)
    await correlator.start()

    await correlator.emit_decision(_decision(correlation_id="tc_unknown"))

    await asyncio.sleep(0.05)
    await correlator.stop()

    assert sink.actions == []
