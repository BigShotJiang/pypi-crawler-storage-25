"""Interactive approval tests."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Awaitable, Callable

import pytest

from mcp_defense.events import Decision, PolicyDecisionEvent, ToolCallEvent
from mcp_defense.policy.approval import (
    ApprovalPrompt,
    ApprovalState,
    InteractiveApprovalGate,
)


def _tool_call(
    tool: str = "read_file",
    args: dict | None = None,
    correlation_id: str = "tc_test",
) -> ToolCallEvent:
    return ToolCallEvent(
        correlation_id=correlation_id,
        timestamp=datetime.now(timezone.utc),
        agent_id="agent",
        server_archetype="filesystem",
        server_pid=1,
        container_id=None,
        tool_name=tool,
        tool_args=args or {"path": "/workspace/.env.local"},
        transport="stdio",
    )


def _decision(
    decision: Decision = Decision.REQUIRE_APPROVAL,
) -> PolicyDecisionEvent:
    return PolicyDecisionEvent(
        correlation_id="tc_test",
        timestamp=datetime.now(timezone.utc),
        decision=decision,
        reason="sensitive path: /workspace/.env.local",
        matched_rule="sensitive_path",
    )


def _scripted(answers: list[str]) -> Callable[[str], Awaitable[str]]:
    queue = list(answers)

    async def ask(_question: str) -> str:
        if not queue:
            return ""
        return queue.pop(0)

    return ask


@pytest.mark.asyncio
async def test_y_approves() -> None:
    prompt = ApprovalPrompt(ask=_scripted(["y"]))
    approved, note = await prompt.prompt(_tool_call(), _decision())
    assert approved
    assert "one-shot" in note


@pytest.mark.asyncio
async def test_uppercase_y_also_approves() -> None:
    prompt = ApprovalPrompt(ask=_scripted(["Y"]))
    approved, _ = await prompt.prompt(_tool_call(), _decision())
    assert approved


@pytest.mark.asyncio
async def test_n_denies() -> None:
    prompt = ApprovalPrompt(ask=_scripted(["n"]))
    approved, note = await prompt.prompt(_tool_call(), _decision())
    assert not approved
    assert "denied" in note.lower()


@pytest.mark.asyncio
async def test_empty_input_denies_by_default() -> None:
    prompt = ApprovalPrompt(ask=_scripted([""]))
    approved, _ = await prompt.prompt(_tool_call(), _decision())
    assert not approved


@pytest.mark.asyncio
async def test_a_remembers_key_for_session() -> None:
    state = ApprovalState()
    prompt = ApprovalPrompt(ask=_scripted(["a"]), session_state=state)
    approved, note = await prompt.prompt(
        _tool_call(args={"path": "/workspace/a"}), _decision()
    )
    assert approved
    assert "session allow-list added" in note
    assert ("read_file", "/workspace/a") in state.allow_keys

    # Second call with the same (tool, primary_arg) auto-approves even with
    # an empty ask queue — proving the session allow list short-circuited.
    prompt2 = ApprovalPrompt(ask=_scripted([]), session_state=state)
    approved2, note2 = await prompt2.prompt(
        _tool_call(args={"path": "/workspace/a"}), _decision()
    )
    assert approved2
    assert "session allow-list matched" in note2


@pytest.mark.asyncio
async def test_a_with_different_path_still_prompts() -> None:
    state = ApprovalState()
    prompt = ApprovalPrompt(ask=_scripted(["a"]), session_state=state)
    await prompt.prompt(_tool_call(args={"path": "/workspace/a"}), _decision())

    # Different path -> different key -> should prompt again.
    prompt2 = ApprovalPrompt(ask=_scripted(["n"]), session_state=state)
    approved, _ = await prompt2.prompt(
        _tool_call(args={"path": "/workspace/b"}), _decision()
    )
    assert not approved


@pytest.mark.asyncio
async def test_capital_A_enables_session_allow_all() -> None:
    state = ApprovalState()
    prompt = ApprovalPrompt(ask=_scripted(["A"]), session_state=state)
    approved, _ = await prompt.prompt(_tool_call(), _decision())
    assert approved
    assert state.allow_all is True

    # Completely different tool + args is still auto-approved.
    prompt2 = ApprovalPrompt(ask=_scripted([]), session_state=state)
    approved2, _ = await prompt2.prompt(
        _tool_call(tool="other_tool", args={"url": "https://x"}), _decision()
    )
    assert approved2


@pytest.mark.asyncio
async def test_tty_failure_auto_denies_and_caches() -> None:
    call_count = 0

    async def failing_ask(_: str) -> str:
        nonlocal call_count
        call_count += 1
        raise OSError("no controlling terminal")

    prompt = ApprovalPrompt(ask=failing_ask)
    approved, note = await prompt.prompt(_tool_call(), _decision())
    assert not approved
    assert "tty" in note.lower()
    assert call_count == 1

    # Second prompt: should not retry the ask (cached _tty_broken).
    approved2, note2 = await prompt.prompt(_tool_call(tool="other"), _decision())
    assert not approved2
    assert call_count == 1
    assert "auto-rejected" in note2


class _AllowGate:
    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent:
        return PolicyDecisionEvent(
            correlation_id=event.correlation_id,
            timestamp=datetime.now(timezone.utc),
            decision=Decision.ALLOW,
            reason="ok",
            matched_rule="default_allow",
        )


class _RequireApprovalGate:
    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent:
        return PolicyDecisionEvent(
            correlation_id=event.correlation_id,
            timestamp=datetime.now(timezone.utc),
            decision=Decision.REQUIRE_APPROVAL,
            reason="sensitive path",
            matched_rule="sensitive_path",
        )


class _DenyGate:
    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent:
        return PolicyDecisionEvent(
            correlation_id=event.correlation_id,
            timestamp=datetime.now(timezone.utc),
            decision=Decision.DENY,
            reason="no",
            matched_rule="crown_jewel",
        )


@pytest.mark.asyncio
async def test_gate_passes_through_allow() -> None:
    gate = InteractiveApprovalGate(_AllowGate(), ApprovalPrompt(ask=_scripted([])))
    result = await gate.evaluate(_tool_call())
    assert result.decision == Decision.ALLOW
    assert result.matched_rule == "default_allow"  # untouched


@pytest.mark.asyncio
async def test_gate_passes_through_deny() -> None:
    gate = InteractiveApprovalGate(_DenyGate(), ApprovalPrompt(ask=_scripted([])))
    result = await gate.evaluate(_tool_call())
    assert result.decision == Decision.DENY


@pytest.mark.asyncio
async def test_gate_transforms_require_approval_to_approved() -> None:
    gate = InteractiveApprovalGate(
        _RequireApprovalGate(), ApprovalPrompt(ask=_scripted(["y"]))
    )
    result = await gate.evaluate(_tool_call())
    assert result.decision == Decision.APPROVED
    assert result.matched_rule == "approval:sensitive_path"
    assert "one-shot approval" in result.reason


@pytest.mark.asyncio
async def test_gate_transforms_require_approval_to_rejected() -> None:
    gate = InteractiveApprovalGate(
        _RequireApprovalGate(), ApprovalPrompt(ask=_scripted(["n"]))
    )
    result = await gate.evaluate(_tool_call())
    assert result.decision == Decision.REJECTED
    assert result.matched_rule == "approval:sensitive_path"
    assert "operator denied" in result.reason
