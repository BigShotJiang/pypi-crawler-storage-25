"""cgroup v2 path parser tests."""

from __future__ import annotations

import sys

from mcp_defense.proxy.cgroup import parse_cgroup_v2_path, pid_to_cgroup_id


def test_parse_v2_basic() -> None:
    raw = "0::/user.slice/user-1000.slice/session-3.scope\n"
    assert parse_cgroup_v2_path(raw) == "/user.slice/user-1000.slice/session-3.scope"


def test_parse_v2_mixed_with_v1_lines() -> None:
    # Hybrid cgroup hosts list v1 controllers too. Our parser picks the v2 line.
    raw = (
        "12:pids:/user.slice/user-1000.slice/session-3.scope\n"
        "11:memory:/user.slice/user-1000.slice/session-3.scope\n"
        "0::/user.slice/user-1000.slice/session-3.scope\n"
    )
    assert parse_cgroup_v2_path(raw) == "/user.slice/user-1000.slice/session-3.scope"


def test_parse_v1_only_returns_none() -> None:
    raw = (
        "12:pids:/user.slice/user-1000.slice/session-3.scope\n"
        "11:memory:/user.slice/user-1000.slice/session-3.scope\n"
    )
    assert parse_cgroup_v2_path(raw) is None


def test_parse_empty() -> None:
    assert parse_cgroup_v2_path("") is None
    assert parse_cgroup_v2_path("\n\n") is None


def test_parse_malformed_lines_skipped() -> None:
    raw = "garbage\nno colons here\n0::/legit/path\n"
    assert parse_cgroup_v2_path(raw) == "/legit/path"


def test_parse_container_path() -> None:
    # Typical docker/containerd cgroup path.
    raw = "0::/system.slice/docker-abcd1234.scope\n"
    assert parse_cgroup_v2_path(raw) == "/system.slice/docker-abcd1234.scope"


def test_pid_to_cgroup_id_on_non_linux_returns_none() -> None:
    if sys.platform == "linux":
        # Can't assert non-linux behavior on linux — skip.
        return
    # On darwin, the function short-circuits before any filesystem access.
    assert pid_to_cgroup_id(1) is None


def test_pid_to_cgroup_id_on_missing_pid_returns_none() -> None:
    # PID 0 is never a real process; read of /proc/0/cgroup fails.
    # On non-linux this returns None via the platform check; on linux via OSError.
    assert pid_to_cgroup_id(0) is None
