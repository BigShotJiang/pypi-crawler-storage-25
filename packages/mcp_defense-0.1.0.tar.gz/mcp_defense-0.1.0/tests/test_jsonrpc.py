"""JSON-RPC parsing tests."""

from mcp_defense.proxy.jsonrpc import parse_line


def test_tool_call_request() -> None:
    line = (
        b'{"jsonrpc":"2.0","id":1,"method":"tools/call",'
        b'"params":{"name":"read_file","arguments":{"path":"/etc/hosts"}}}'
    )
    msg = parse_line(line)
    assert msg is not None
    assert msg.is_request
    assert msg.is_tool_call
    assert msg.tool_name == "read_file"
    assert msg.tool_arguments == {"path": "/etc/hosts"}


def test_non_tool_call_request() -> None:
    msg = parse_line(b'{"jsonrpc":"2.0","id":1,"method":"tools/list"}')
    assert msg is not None
    assert msg.is_request
    assert not msg.is_tool_call
    assert msg.tool_name is None


def test_notification() -> None:
    msg = parse_line(b'{"jsonrpc":"2.0","method":"notifications/log","params":{}}')
    assert msg is not None
    assert msg.is_notification
    assert not msg.is_request


def test_response() -> None:
    msg = parse_line(b'{"jsonrpc":"2.0","id":1,"result":{"ok":true}}')
    assert msg is not None
    assert msg.is_response
    assert not msg.is_request


def test_malformed() -> None:
    assert parse_line(b"not json") is None
    assert parse_line(b"") is None
    assert parse_line(b"   ") is None
    assert parse_line(b"null") is None  # not a dict
    assert parse_line(b"[1,2,3]") is None  # not a dict


def test_unicode_body() -> None:
    msg = parse_line('{"jsonrpc":"2.0","id":1,"method":"tools/call",'
                     '"params":{"name":"read_file","arguments":{"path":"/tmp/café"}}}')
    assert msg is not None
    assert msg.is_tool_call
    assert msg.tool_arguments["path"] == "/tmp/café"
