"""Bridge conversion tests — DetectionEvent-shaped object -> FlowEvent JSON dict."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from mcp_defense.bridges.ternaryphysics import detection_event_to_flow_dict
from mcp_defense.correlation.flow_source import _parse_flow_event


@dataclass
class _FakeDetectionEvent:
    """Duck-typed stand-in for ternaryphysics' DetectionEvent."""
    timestamp: Any
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    proto: int
    classification: Any
    action: Any
    confidence: int


def test_integer_classification_and_action() -> None:
    event = _FakeDetectionEvent(
        timestamp=1_700_000_000_000_000_000,  # nanoseconds
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        proto=6,
        classification=2,  # MALICIOUS
        action=2,  # DROP
        confidence=87,
    )
    d = detection_event_to_flow_dict(event)
    assert d["classification"] == "MALICIOUS"
    assert d["action"] == "DROP"
    assert d["src_port"] == 50001
    assert d["protocol"] == 6
    assert d["cgroup_id"] is None
    assert d["source_pid"] is None
    # Round-trips through JsonLinesFlowSource's parser cleanly.
    flow = _parse_flow_event(d)
    assert flow.classification == "MALICIOUS"
    assert flow.action == "DROP"


def test_string_classification_passthrough() -> None:
    event = _FakeDetectionEvent(
        timestamp=datetime(2026, 4, 24, tzinfo=timezone.utc),
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        proto=6,
        classification="LEGITIMATE",
        action="PASS",
        confidence=95,
    )
    d = detection_event_to_flow_dict(event)
    assert d["classification"] == "LEGITIMATE"
    assert d["action"] == "PASS"


def test_unknown_integer_codes_fall_back() -> None:
    event = _FakeDetectionEvent(
        timestamp=1_700_000_000_000_000_000,
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        proto=6,
        classification=99,  # not in the int map
        action=99,
        confidence=50,
    )
    d = detection_event_to_flow_dict(event)
    assert d["classification"] == "UNKNOWN"
    assert d["action"] == "TAG"


def test_with_cgroup_and_pid_attributes() -> None:
    @dataclass
    class WithExtras(_FakeDetectionEvent):
        cgroup_id: int = 0
        pid: int = 0

    event = WithExtras(
        timestamp=1_700_000_000_000_000_000,
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        proto=6,
        classification=0,
        action=0,
        confidence=90,
        cgroup_id=123456,
        pid=4242,
    )
    d = detection_event_to_flow_dict(event)
    assert d["cgroup_id"] == 123456
    assert d["source_pid"] == 4242


def test_jsonl_roundtrip() -> None:
    """Conversion output must be serializable and consumable by JsonLinesFlowSource."""
    event = _FakeDetectionEvent(
        timestamp=1_700_000_000_000_000_000,
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        proto=6,
        classification=1,
        action=1,
        confidence=75,
    )
    d = detection_event_to_flow_dict(event)
    line = json.dumps(d)
    # Reparse through our consumer.
    redata = json.loads(line)
    flow = _parse_flow_event(redata)
    assert flow.src_ip == "10.0.0.5"
    assert flow.classification == "SUSPICIOUS"
    assert flow.action == "TAG"
