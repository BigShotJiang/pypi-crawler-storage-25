"""Correlation ID generation tests."""

from mcp_defense.proxy.correlation_id import CORRELATION_ID_PREFIX, new_correlation_id


def test_format() -> None:
    cid = new_correlation_id()
    assert cid.startswith(f"{CORRELATION_ID_PREFIX}_")
    suffix = cid[len(CORRELATION_ID_PREFIX) + 1 :]
    assert len(suffix) == 10
    # base32 lowercased -> [a-z2-7]
    assert all(c.isalnum() and not c.isupper() for c in suffix)


def test_uniqueness() -> None:
    ids = {new_correlation_id() for _ in range(10_000)}
    assert len(ids) == 10_000
