"""Path and URL extraction from tool call arguments."""

from mcp_defense.policy.extractor import extract_paths, extract_urls


def test_extract_path_by_prefix() -> None:
    assert extract_paths({"path": "/etc/hosts"}) == ["/etc/hosts"]
    assert extract_paths({"arg1": "./config.json"}) == ["./config.json"]
    assert extract_paths({"arg1": "~/secret"}) == ["~/secret"]


def test_extract_path_by_key_hint() -> None:
    assert extract_paths({"filename": "notes.txt"}) == ["notes.txt"]
    assert extract_paths({"file_path": "script.py"}) == ["script.py"]


def test_skip_urls_as_paths() -> None:
    assert extract_paths({"url": "https://example.com/api"}) == []


def test_extract_url() -> None:
    assert extract_urls({"url": "https://api.github.com/repos"}) == [
        "https://api.github.com/repos"
    ]
    assert extract_urls({"endpoint": "http://10.0.0.1"}) == ["http://10.0.0.1"]


def test_extract_url_bare_host() -> None:
    assert extract_urls({"host": "api.github.com"}) == ["api.github.com"]


def test_nested_arguments() -> None:
    args = {
        "files": ["/a/b.txt", "/c/d.txt"],
        "opts": {"path": "/e/f.txt"},
    }
    paths = extract_paths(args)
    assert "/a/b.txt" in paths
    assert "/c/d.txt" in paths
    assert "/e/f.txt" in paths


def test_ignores_non_string_values() -> None:
    assert extract_paths({"count": 42, "enabled": True}) == []


def test_empty() -> None:
    assert extract_paths({}) == []
    assert extract_urls({}) == []
