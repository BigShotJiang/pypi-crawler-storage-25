"""Stdio proxy unit tests."""

from __future__ import annotations

import pytest

from mcp_defense.events import Decision, ToolCallEvent
from mcp_defense.policy.archetypes import Archetype
from mcp_defense.policy.engine import PolicyEngine
from mcp_defense.proxy.sink import CapturingSink
from mcp_defense.proxy.stdio import StdioProxy


def _proxy(sink: CapturingSink, policy=None) -> StdioProxy:
    return StdioProxy(
        command=["true"],
        archetype="filesystem",
        agent_id="agent-1",
        sink=sink,
        policy=policy,
    )


TOOL_CALL_LINE = (
    b'{"jsonrpc":"2.0","id":1,"method":"tools/call",'
    b'"params":{"name":"read_file","arguments":{"path":"/workspace/main.py"}}}\n'
)


@pytest.mark.asyncio
async def test_emits_tool_call_and_allows() -> None:
    sink = CapturingSink()
    proxy = _proxy(sink)
    decision = await proxy._process_line(TOOL_CALL_LINE)
    assert decision is not None
    assert decision.decision == Decision.ALLOW
    assert len(sink.events) == 1
    assert len(sink.decisions) == 1
    event = sink.events[0]
    assert isinstance(event, ToolCallEvent)
    assert event.tool_name == "read_file"
    assert event.correlation_id == decision.correlation_id


@pytest.mark.asyncio
async def test_ignores_non_tool_call() -> None:
    sink = CapturingSink()
    proxy = _proxy(sink)
    result = await proxy._process_line(b'{"jsonrpc":"2.0","id":2,"method":"tools/list"}\n')
    assert result is None
    assert sink.events == []
    assert sink.decisions == []


@pytest.mark.asyncio
async def test_ignores_garbage() -> None:
    sink = CapturingSink()
    proxy = _proxy(sink)
    assert (await proxy._process_line(b"not json\n")) is None
    assert (await proxy._process_line(b"\n")) is None
    assert sink.events == []


@pytest.mark.asyncio
async def test_policy_denial_surfaces_in_decision() -> None:
    archetypes = {
        "filesystem": Archetype(
            name="filesystem",
            allowed_paths=["/workspace/**"],
            can_network=False,
            can_spawn=False,
        )
    }
    sink = CapturingSink()
    proxy = _proxy(sink, policy=PolicyEngine(archetypes=archetypes))
    line = (
        b'{"jsonrpc":"2.0","id":5,"method":"tools/call",'
        b'"params":{"name":"read_file","arguments":{"path":"/home/alice/.aws/credentials"}}}\n'
    )
    decision = await proxy._process_line(line)
    assert decision is not None
    assert decision.decision == Decision.DENY
    assert decision.matched_rule == "crown_jewel"
    assert sink.decisions[0].matched_rule == "crown_jewel"


@pytest.mark.asyncio
async def test_unique_correlation_ids_across_calls() -> None:
    sink = CapturingSink()
    proxy = _proxy(sink)
    for _ in range(50):
        await proxy._process_line(TOOL_CALL_LINE)
    cids = {e.correlation_id for e in sink.events}
    assert len(cids) == 50
    # Each tool call gets exactly one decision with matching cid
    assert {d.correlation_id for d in sink.decisions} == cids
