"""Glob matcher tests — covers ** semantics that stdlib fnmatch lacks."""

from mcp_defense.policy.matcher import path_matches


def test_exact_match() -> None:
    assert path_matches("/etc/hosts", "/etc/hosts")
    assert not path_matches("/etc/hosts", "/etc/shadow")


def test_anchor_semantics() -> None:
    assert not path_matches("/etc", "etc")
    assert not path_matches("etc", "/etc")


def test_single_star_within_segment() -> None:
    assert path_matches("/home/*/.ssh/id_*", "/home/alice/.ssh/id_rsa")
    assert path_matches("/home/*/.ssh/id_*", "/home/bob/.ssh/id_ed25519")
    # Single * cannot span segments
    assert not path_matches("/home/*", "/home/alice/bob")


def test_double_star_zero_segments() -> None:
    assert path_matches("/workspace/**/.env.local", "/workspace/.env.local")
    assert path_matches("/root/.ssh/**", "/root/.ssh")


def test_double_star_many_segments() -> None:
    assert path_matches("/workspace/**/.env.local", "/workspace/a/b/c/.env.local")
    assert path_matches("/var/run/secrets/kubernetes.io/serviceaccount/**",
                        "/var/run/secrets/kubernetes.io/serviceaccount/token")


def test_double_star_mid_pattern() -> None:
    assert path_matches("/workspace/**/.github/workflows/**",
                        "/workspace/app/.github/workflows/ci.yml")


def test_question_mark() -> None:
    assert path_matches("/tmp/file?.txt", "/tmp/file1.txt")
    assert not path_matches("/tmp/file?.txt", "/tmp/file12.txt")


def test_non_matches() -> None:
    assert not path_matches("/etc/**", "/var/log/syslog")
    assert not path_matches("/home/*/.ssh/id_*", "/home/alice/.ssh/known_hosts")
