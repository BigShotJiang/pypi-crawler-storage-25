"""End-to-end integration tests for StdioProxy.

Spawns a real subprocess (a tiny fake MCP server written as a Python script)
and pipes JSON-RPC through the proxy with a real policy engine. Verifies:

  - ALLOWED tool calls reach the server and get a real response back.
  - DENIED tool calls never reach the server — the proxy synthesizes a
    JSON-RPC result with isError=true and includes the matched rule.
  - The sink receives both events and decisions in order.
  - Non-tool-call requests (e.g. tools/list) pass through untouched.
"""

from __future__ import annotations

import asyncio
import io
import json
import sys
from pathlib import Path

import pytest

from mcp_defense.events import Decision
from mcp_defense.policy.archetypes import Archetype
from mcp_defense.policy.engine import PolicyEngine
from mcp_defense.proxy.sink import CapturingSink
from mcp_defense.proxy.stdio import StdioProxy

_FAKE_SERVER = """\
import json, sys

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        req = json.loads(line)
    except json.JSONDecodeError:
        continue
    if req.get("method") == "tools/call":
        resp = {
            "jsonrpc": "2.0",
            "id": req.get("id"),
            "result": {
                "content": [{"type": "text", "text": f"server handled {req['params']['name']}"}],
                "isError": False,
            },
        }
    elif req.get("method") == "tools/list":
        resp = {"jsonrpc": "2.0", "id": req.get("id"), "result": {"tools": []}}
    elif "id" in req:
        resp = {"jsonrpc": "2.0", "id": req["id"], "result": {}}
    else:
        continue
    sys.stdout.write(json.dumps(resp) + chr(10))
    sys.stdout.flush()
"""


def _write_fake_server(tmp_path: Path) -> Path:
    path = tmp_path / "fake_mcp_server.py"
    path.write_text(_FAKE_SERVER)
    return path


def _make_upstream_in(lines: list[bytes]) -> asyncio.StreamReader:
    reader = asyncio.StreamReader()
    for line in lines:
        reader.feed_data(line)
    reader.feed_eof()
    return reader


def _archetypes() -> dict[str, Archetype]:
    return {
        "filesystem": Archetype(
            name="filesystem",
            allowed_paths=["/workspace/**"],
            can_network=False,
            can_spawn=False,
        ),
    }


def _parse_jsonl(blob: bytes) -> list[dict]:
    out: list[dict] = []
    for line in blob.decode("utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        out.append(json.loads(line))
    return out


@pytest.mark.asyncio
async def test_allow_forwards_and_receives_server_response(tmp_path: Path) -> None:
    server_script = _write_fake_server(tmp_path)
    sink = CapturingSink()
    proxy = StdioProxy(
        command=[sys.executable, str(server_script)],
        archetype="filesystem",
        agent_id="integration-test",
        sink=sink,
        policy=PolicyEngine(archetypes=_archetypes()),
    )

    upstream_in = _make_upstream_in(
        [
            b'{"jsonrpc":"2.0","id":1,"method":"tools/call",'
            b'"params":{"name":"read_file","arguments":{"path":"/workspace/main.py"}}}\n'
        ]
    )
    upstream_out = io.BytesIO()

    exit_code = await proxy._run_with_streams(upstream_in, upstream_out)
    assert exit_code == 0

    responses = _parse_jsonl(upstream_out.getvalue())
    assert len(responses) == 1
    assert responses[0]["id"] == 1
    assert responses[0]["result"]["isError"] is False
    assert "server handled read_file" in responses[0]["result"]["content"][0]["text"]

    assert len(sink.events) == 1
    assert len(sink.decisions) == 1
    assert sink.decisions[0].decision == Decision.ALLOW


@pytest.mark.asyncio
async def test_deny_synthesizes_error_and_does_not_reach_server(tmp_path: Path) -> None:
    server_script = _write_fake_server(tmp_path)
    sink = CapturingSink()
    proxy = StdioProxy(
        command=[sys.executable, str(server_script)],
        archetype="filesystem",
        agent_id="integration-test",
        sink=sink,
        policy=PolicyEngine(archetypes=_archetypes()),
    )

    upstream_in = _make_upstream_in(
        [
            b'{"jsonrpc":"2.0","id":7,"method":"tools/call",'
            b'"params":{"name":"read_file","arguments":{"path":"/home/alice/.aws/credentials"}}}\n'
        ]
    )
    upstream_out = io.BytesIO()

    exit_code = await proxy._run_with_streams(upstream_in, upstream_out)
    assert exit_code == 0

    responses = _parse_jsonl(upstream_out.getvalue())
    assert len(responses) == 1
    assert responses[0]["id"] == 7
    assert responses[0]["result"]["isError"] is True
    text = responses[0]["result"]["content"][0]["text"]
    assert "crown_jewel" in text
    assert "/home/alice/.aws/credentials" in text

    assert sink.decisions[0].decision == Decision.DENY
    assert sink.decisions[0].matched_rule == "crown_jewel"


@pytest.mark.asyncio
async def test_mixed_allow_and_deny(tmp_path: Path) -> None:
    server_script = _write_fake_server(tmp_path)
    sink = CapturingSink()
    proxy = StdioProxy(
        command=[sys.executable, str(server_script)],
        archetype="filesystem",
        agent_id="integration-test",
        sink=sink,
        policy=PolicyEngine(archetypes=_archetypes()),
    )

    upstream_in = _make_upstream_in(
        [
            b'{"jsonrpc":"2.0","id":1,"method":"tools/call",'
            b'"params":{"name":"read_file","arguments":{"path":"/workspace/a.txt"}}}\n',
            b'{"jsonrpc":"2.0","id":2,"method":"tools/call",'
            b'"params":{"name":"read_file","arguments":{"path":"/etc/hosts"}}}\n',
            b'{"jsonrpc":"2.0","id":3,"method":"tools/call",'
            b'"params":{"name":"read_file","arguments":{"path":"/workspace/b.txt"}}}\n',
        ]
    )
    upstream_out = io.BytesIO()

    exit_code = await proxy._run_with_streams(upstream_in, upstream_out)
    assert exit_code == 0

    responses = _parse_jsonl(upstream_out.getvalue())
    by_id = {r["id"]: r for r in responses}
    assert by_id[1]["result"]["isError"] is False
    assert by_id[2]["result"]["isError"] is True  # /etc/hosts outside allowlist
    assert "path_outside_allowlist" in by_id[2]["result"]["content"][0]["text"]
    assert by_id[3]["result"]["isError"] is False

    assert len(sink.events) == 3
    rules = [d.matched_rule for d in sink.decisions]
    assert rules == ["default_allow", "path_outside_allowlist", "default_allow"]


@pytest.mark.asyncio
async def test_non_tool_call_passes_through(tmp_path: Path) -> None:
    server_script = _write_fake_server(tmp_path)
    sink = CapturingSink()
    proxy = StdioProxy(
        command=[sys.executable, str(server_script)],
        archetype="filesystem",
        agent_id="integration-test",
        sink=sink,
        policy=PolicyEngine(archetypes=_archetypes()),
    )

    upstream_in = _make_upstream_in(
        [b'{"jsonrpc":"2.0","id":99,"method":"tools/list"}\n']
    )
    upstream_out = io.BytesIO()

    exit_code = await proxy._run_with_streams(upstream_in, upstream_out)
    assert exit_code == 0

    responses = _parse_jsonl(upstream_out.getvalue())
    assert len(responses) == 1
    assert responses[0]["id"] == 99
    assert "tools" in responses[0]["result"]

    # tools/list is not a tool call — no sink events.
    assert sink.events == []
    assert sink.decisions == []
