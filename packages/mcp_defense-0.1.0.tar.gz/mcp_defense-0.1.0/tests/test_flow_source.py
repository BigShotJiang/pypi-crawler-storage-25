"""Flow source tests — MockFlowSource and JsonLinesFlowSource."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from mcp_defense.correlation.flow_source import JsonLinesFlowSource, MockFlowSource
from mcp_defense.events import FlowEvent


def _flow(src_port: int = 50001) -> FlowEvent:
    return FlowEvent(
        timestamp=datetime.now(timezone.utc),
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=src_port,
        dst_port=443,
        protocol=6,
        classification="MALICIOUS",
        action="DROP",
        confidence=87,
    )


@pytest.mark.asyncio
async def test_mock_flow_source_yields_and_closes() -> None:
    source = MockFlowSource()
    f1 = _flow(50001)
    f2 = _flow(50002)
    source.push(f1)
    source.push(f2)
    source.close()

    collected: list[FlowEvent] = []
    async for event in source.stream():
        collected.append(event)

    assert collected == [f1, f2]


@pytest.mark.asyncio
async def test_json_lines_flow_source_parses(tmp_path) -> None:
    path = tmp_path / "flows.jsonl"
    path.write_text(
        '{"timestamp":"2026-04-24T12:00:00+00:00","src_ip":"10.0.0.5",'
        '"dst_ip":"1.2.3.4","src_port":50001,"dst_port":443,"protocol":6,'
        '"classification":"MALICIOUS","action":"DROP","confidence":87,'
        '"cgroup_id":9999,"source_pid":4242}\n'
        "not json\n"
        "\n"
        '{"timestamp":"2026-04-24T12:00:01+00:00","src_ip":"10.0.0.5",'
        '"dst_ip":"5.6.7.8","src_port":50002,"dst_port":443,"protocol":6,'
        '"classification":"LEGITIMATE","action":"PASS","confidence":95}\n'
    )

    source = JsonLinesFlowSource(path)
    collected: list[FlowEvent] = []
    async for event in source.stream():
        collected.append(event)

    assert len(collected) == 2
    assert collected[0].cgroup_id == 9999
    assert collected[0].source_pid == 4242
    assert collected[0].action == "DROP"
    assert collected[1].cgroup_id is None
    assert collected[1].source_pid is None
    assert collected[1].classification == "LEGITIMATE"


@pytest.mark.asyncio
async def test_json_lines_tolerates_missing_optional_fields(tmp_path) -> None:
    path = tmp_path / "flows.jsonl"
    path.write_text(
        '{"timestamp":"2026-04-24T12:00:00+00:00","src_ip":"10.0.0.5",'
        '"dst_ip":"1.2.3.4","src_port":50001,"dst_port":443,"protocol":6,'
        '"classification":"SUSPICIOUS","action":"TAG","confidence":60}\n'
    )
    source = JsonLinesFlowSource(path)
    events = [e async for e in source.stream()]
    assert len(events) == 1
    assert events[0].cgroup_id is None


@pytest.mark.asyncio
async def test_json_lines_skips_bad_records(tmp_path) -> None:
    path = tmp_path / "flows.jsonl"
    path.write_text(
        '{"missing_fields":true}\n'
        "[1,2,3]\n"  # not a dict
        '{"timestamp":"not-a-date","src_ip":"x","dst_ip":"y","src_port":1,'
        '"dst_port":2,"protocol":6,"classification":"X","action":"Y","confidence":0}\n'
    )
    source = JsonLinesFlowSource(path)
    events = [e async for e in source.stream()]
    assert events == []
