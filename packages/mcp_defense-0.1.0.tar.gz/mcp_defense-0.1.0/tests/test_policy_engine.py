"""Policy engine decision tests."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from mcp_defense.events import Decision, ToolCallEvent
from mcp_defense.policy.archetypes import Archetype
from mcp_defense.policy.engine import AllowAllPolicy, PolicyEngine


def _event(archetype: str, tool_name: str, tool_args: dict) -> ToolCallEvent:
    return ToolCallEvent(
        correlation_id="tc_test",
        timestamp=datetime.now(timezone.utc),
        agent_id="agent-1",
        server_archetype=archetype,
        server_pid=1234,
        container_id=None,
        tool_name=tool_name,
        tool_args=tool_args,
        transport="stdio",
    )


def _archetypes() -> dict[str, Archetype]:
    return {
        "filesystem": Archetype(
            name="filesystem",
            allowed_paths=["/workspace/**", "/tmp/**"],
            can_network=False,
            can_spawn=False,
        ),
        "github": Archetype(
            name="github",
            allowed_paths=["/tmp/**"],
            allowed_ports=[443],
            allowed_hosts=["api.github.com"],
            can_network=True,
            can_spawn=False,
        ),
        "shell": Archetype(
            name="shell",
            allowed_paths=["/workspace/**", "/tmp/**"],
            can_network=False,
            can_spawn=True,
            allowed_children=["bash", "sh"],
        ),
        "generic": Archetype(name="generic", learning_mode=True),
    }


@pytest.mark.asyncio
async def test_allow_all_policy() -> None:
    pol = AllowAllPolicy()
    d = await pol.evaluate(_event("filesystem", "read_file", {"path": "/etc/hosts"}))
    assert d.decision == Decision.ALLOW
    assert d.matched_rule == "observe_only"


@pytest.mark.asyncio
async def test_unknown_archetype_denies() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(_event("nonexistent", "x", {}))
    assert d.decision == Decision.DENY
    assert d.matched_rule == "unknown_archetype"


@pytest.mark.asyncio
async def test_learning_mode_allows() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(_event("generic", "anything", {"url": "https://x"}))
    assert d.decision == Decision.ALLOW
    assert d.matched_rule == "learning_mode"


@pytest.mark.asyncio
async def test_crown_jewel_denies() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("filesystem", "read_file", {"path": "/home/alice/.aws/credentials"})
    )
    assert d.decision == Decision.DENY
    assert d.matched_rule == "crown_jewel"


@pytest.mark.asyncio
async def test_sensitive_path_requires_approval() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("filesystem", "read_file", {"path": "/workspace/app/.env.local"})
    )
    assert d.decision == Decision.REQUIRE_APPROVAL
    assert d.matched_rule == "sensitive_path"


@pytest.mark.asyncio
async def test_archetype_forbids_network() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("filesystem", "fetch", {"url": "https://evil.example.com"})
    )
    assert d.decision == Decision.DENY
    assert d.matched_rule == "archetype_no_network"


@pytest.mark.asyncio
async def test_archetype_forbids_spawn() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("filesystem", "exec_command", {"command": "ls"})
    )
    assert d.decision == Decision.DENY
    assert d.matched_rule == "archetype_no_spawn"


@pytest.mark.asyncio
async def test_path_outside_allowlist() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("filesystem", "read_file", {"path": "/etc/hosts"})
    )
    assert d.decision == Decision.DENY
    assert d.matched_rule == "path_outside_allowlist"


@pytest.mark.asyncio
async def test_path_inside_allowlist_allowed() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("filesystem", "read_file", {"path": "/workspace/app/main.py"})
    )
    assert d.decision == Decision.ALLOW
    assert d.matched_rule == "default_allow"


@pytest.mark.asyncio
async def test_host_outside_allowlist() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("github", "fetch", {"url": "https://evil.example.com/thing"})
    )
    assert d.decision == Decision.DENY
    assert d.matched_rule == "host_outside_allowlist"


@pytest.mark.asyncio
async def test_host_inside_allowlist_allowed() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("github", "fetch", {"url": "https://api.github.com/repos/x/y"})
    )
    assert d.decision == Decision.ALLOW


@pytest.mark.asyncio
async def test_shell_archetype_permits_spawn() -> None:
    engine = PolicyEngine(archetypes=_archetypes())
    d = await engine.evaluate(
        _event("shell", "run_command", {"command": "ls /workspace"})
    )
    # spawn allowed, no path triggers, no URL — default allow
    assert d.decision == Decision.ALLOW
