"""Flight recorder tests — verify output contains expected symbols and text."""

from __future__ import annotations

import io
from datetime import datetime, timezone

import pytest
from rich.console import Console

from mcp_defense.events import (
    AgentActionEvent,
    Decision,
    FlowEvent,
    OrphanFlowEvent,
    PolicyDecisionEvent,
    ToolCallEvent,
)
from mcp_defense.recorder.flight import FlightRecorder


def _make_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, width=200)
    return console, buf


def _tool_call(**overrides) -> ToolCallEvent:
    defaults = dict(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime(2026, 4, 24, 14, 32, 18, 123000, tzinfo=timezone.utc),
        agent_id="agent-1",
        server_archetype="filesystem",
        server_pid=1001,
        container_id=None,
        tool_name="read_file",
        tool_args={"path": "/workspace/main.py"},
        transport="stdio",
        cgroup_id=100,
    )
    defaults.update(overrides)
    return ToolCallEvent(**defaults)


def _decision(decision: Decision = Decision.ALLOW, rule: str = "default_allow") -> PolicyDecisionEvent:
    return PolicyDecisionEvent(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime(2026, 4, 24, 14, 32, 18, 200000, tzinfo=timezone.utc),
        decision=decision,
        reason="test",
        matched_rule=rule,
    )


@pytest.mark.asyncio
async def test_emit_action_allow_with_flow() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    flow = FlowEvent(
        timestamp=datetime.now(timezone.utc),
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        protocol=6,
        classification="LEGITIMATE",
        action="PASS",
        confidence=95,
    )
    action = AgentActionEvent(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime.now(timezone.utc),
        tool_call=_tool_call(),
        policy_decision=_decision(),
        flows=[flow],
    )
    await recorder.emit_action(action)

    output = buf.getvalue()
    assert "ALLOW" in output
    assert "tc_aaaaaaaaaa" in output
    assert "read_file" in output
    assert "/workspace/main.py" in output
    assert "10.0.0.5:50001 → 1.2.3.4:443" in output
    assert "PASS" in output
    assert recorder.count_allow == 1


@pytest.mark.asyncio
async def test_emit_action_deny_shows_rule_and_reason() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    action = AgentActionEvent(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime.now(timezone.utc),
        tool_call=_tool_call(tool_args={"path": "/home/alice/.aws/credentials"}),
        policy_decision=PolicyDecisionEvent(
            correlation_id="tc_aaaaaaaaaa",
            timestamp=datetime.now(timezone.utc),
            decision=Decision.DENY,
            reason="crown jewel: /home/alice/.aws/credentials",
            matched_rule="crown_jewel",
        ),
    )
    await recorder.emit_action(action)

    output = buf.getvalue()
    assert "DENY" in output
    assert "crown_jewel" in output
    assert "/home/alice/.aws/credentials" in output
    assert recorder.count_deny == 1


@pytest.mark.asyncio
async def test_emit_action_require_approval() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    action = AgentActionEvent(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime.now(timezone.utc),
        tool_call=_tool_call(tool_args={"path": "/workspace/.env.local"}),
        policy_decision=_decision(Decision.REQUIRE_APPROVAL, "sensitive_path"),
    )
    await recorder.emit_action(action)

    output = buf.getvalue()
    assert "APPROVE" in output
    assert "sensitive_path" in output
    assert recorder.count_approval == 1


@pytest.mark.asyncio
async def test_emit_action_approved_counts_as_allow() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    action = AgentActionEvent(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime.now(timezone.utc),
        tool_call=_tool_call(),
        policy_decision=_decision(Decision.APPROVED, "approval:sensitive_path"),
    )
    await recorder.emit_action(action)

    output = buf.getvalue()
    assert "APPROVED" in output
    # APPROVED rolls into the allow count for the summary line.
    assert recorder.count_allow == 1
    assert recorder.count_deny == 0


@pytest.mark.asyncio
async def test_emit_action_rejected_counts_as_deny() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    action = AgentActionEvent(
        correlation_id="tc_aaaaaaaaaa",
        timestamp=datetime.now(timezone.utc),
        tool_call=_tool_call(),
        policy_decision=_decision(Decision.REJECTED, "approval:sensitive_path"),
    )
    await recorder.emit_action(action)

    output = buf.getvalue()
    assert "REJECTED" in output
    assert recorder.count_deny == 1
    assert recorder.count_allow == 0


@pytest.mark.asyncio
async def test_emit_orphan() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    flow = FlowEvent(
        timestamp=datetime.now(timezone.utc),
        src_ip="10.0.0.5",
        dst_ip="5.6.7.8",
        src_port=52001,
        dst_port=443,
        protocol=6,
        classification="MALICIOUS",
        action="DROP",
        confidence=87,
    )
    orphan = OrphanFlowEvent(
        timestamp=datetime.now(timezone.utc),
        flow=flow,
        reason="no_matching_session",
    )
    await recorder.emit_orphan(orphan)

    output = buf.getvalue()
    assert "ORPHAN" in output
    assert "10.0.0.5:52001 → 5.6.7.8:443" in output
    assert "DROP" in output
    assert "no_matching_session" in output
    assert recorder.count_orphan == 1


@pytest.mark.asyncio
async def test_summary_counts() -> None:
    console, buf = _make_console()
    recorder = FlightRecorder(console=console)

    await recorder.emit_action(
        AgentActionEvent(
            correlation_id="a",
            timestamp=datetime.now(timezone.utc),
            tool_call=_tool_call(),
            policy_decision=_decision(Decision.ALLOW),
        )
    )
    await recorder.emit_action(
        AgentActionEvent(
            correlation_id="b",
            timestamp=datetime.now(timezone.utc),
            tool_call=_tool_call(),
            policy_decision=_decision(Decision.DENY, "crown_jewel"),
        )
    )
    recorder.print_summary()
    output = buf.getvalue()
    assert "1 allow" in output
    assert "1 deny" in output
