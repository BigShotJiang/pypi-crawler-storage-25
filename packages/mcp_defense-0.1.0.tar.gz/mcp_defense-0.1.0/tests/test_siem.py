"""SIEM connector and TeeActionSink tests.

Uses aiohttp's in-process TestServer rather than mocking — that way we
actually exercise the serialization + HTTP path without being tied to any
real third-party endpoint.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest
from aiohttp import web
from aiohttp.test_utils import TestServer

from mcp_defense.correlation.join import CapturingActionSink
from mcp_defense.events import (
    AgentActionEvent,
    Decision,
    FlowEvent,
    OrphanFlowEvent,
    PolicyDecisionEvent,
    ToolCallEvent,
)
from mcp_defense.siem.base import TeeActionSink, serialize_action, serialize_orphan
from mcp_defense.siem.splunk import SplunkHecConnector
from mcp_defense.siem.webhook import WebhookConnector


def _action_event() -> AgentActionEvent:
    tool_call = ToolCallEvent(
        correlation_id="tc_integration",
        timestamp=datetime(2026, 4, 24, 12, 0, 0, tzinfo=timezone.utc),
        agent_id="test-agent",
        server_archetype="filesystem",
        server_pid=1001,
        container_id=None,
        tool_name="read_file",
        tool_args={"path": "/workspace/main.py"},
        transport="stdio",
        cgroup_id=9999,
    )
    decision = PolicyDecisionEvent(
        correlation_id="tc_integration",
        timestamp=datetime(2026, 4, 24, 12, 0, 0, tzinfo=timezone.utc),
        decision=Decision.ALLOW,
        reason="within baseline",
        matched_rule="default_allow",
    )
    flow = FlowEvent(
        timestamp=datetime(2026, 4, 24, 12, 0, 1, tzinfo=timezone.utc),
        src_ip="10.0.0.5",
        dst_ip="1.2.3.4",
        src_port=50001,
        dst_port=443,
        protocol=6,
        classification="LEGITIMATE",
        action="PASS",
        confidence=95,
        cgroup_id=9999,
    )
    return AgentActionEvent(
        correlation_id="tc_integration",
        timestamp=datetime(2026, 4, 24, 12, 0, 1, tzinfo=timezone.utc),
        tool_call=tool_call,
        policy_decision=decision,
        flows=[flow],
    )


def _orphan_event() -> OrphanFlowEvent:
    flow = FlowEvent(
        timestamp=datetime(2026, 4, 24, 12, 0, 2, tzinfo=timezone.utc),
        src_ip="10.0.0.5",
        dst_ip="5.6.7.8",
        src_port=52001,
        dst_port=443,
        protocol=6,
        classification="MALICIOUS",
        action="DROP",
        confidence=87,
    )
    return OrphanFlowEvent(
        timestamp=datetime(2026, 4, 24, 12, 0, 2, tzinfo=timezone.utc),
        flow=flow,
        reason="no_matching_session",
    )


def test_serialize_action_produces_full_record() -> None:
    d = serialize_action(_action_event())
    assert d["correlation_id"] == "tc_integration"
    assert d["tool_call"]["tool_name"] == "read_file"
    assert d["tool_call"]["cgroup_id"] == 9999
    assert d["policy_decision"]["decision"] == "allow"
    assert d["policy_decision"]["matched_rule"] == "default_allow"
    assert len(d["flows"]) == 1
    assert d["flows"][0]["action"] == "PASS"


def test_serialize_orphan_produces_full_record() -> None:
    d = serialize_orphan(_orphan_event())
    assert d["reason"] == "no_matching_session"
    assert d["flow"]["action"] == "DROP"
    assert d["flow"]["dst_ip"] == "5.6.7.8"


@pytest.mark.asyncio
async def test_tee_fanouts_to_all_sinks() -> None:
    a, b = CapturingActionSink(), CapturingActionSink()
    tee = TeeActionSink([a, b])
    event = _action_event()
    await tee.emit_action(event)
    await tee.emit_orphan(_orphan_event())
    assert len(a.actions) == 1 and len(a.orphans) == 1
    assert len(b.actions) == 1 and len(b.orphans) == 1


@pytest.mark.asyncio
async def test_tee_isolates_sink_failures() -> None:
    class FailingSink:
        async def emit_action(self, event) -> None:
            raise RuntimeError("boom-action")

        async def emit_orphan(self, event) -> None:
            raise RuntimeError("boom-orphan")

    good = CapturingActionSink()
    tee = TeeActionSink([FailingSink(), good])
    await tee.emit_action(_action_event())
    await tee.emit_orphan(_orphan_event())
    assert len(good.actions) == 1
    assert len(good.orphans) == 1


@pytest.mark.asyncio
async def test_webhook_posts_action_and_orphan() -> None:
    received: list[dict] = []

    async def handler(request: web.Request) -> web.Response:
        body = await request.json()
        received.append(body)
        return web.Response(status=200)

    app = web.Application()
    app.router.add_post("/hook", handler)

    async with TestServer(app) as server:
        url = str(server.make_url("/hook"))
        connector = WebhookConnector(url=url)
        try:
            await connector.emit_action(_action_event())
            await connector.emit_orphan(_orphan_event())
        finally:
            await connector.close()

    assert len(received) == 2
    assert received[0]["type"] == "agent_action"
    assert received[0]["event"]["correlation_id"] == "tc_integration"
    assert received[1]["type"] == "orphan_flow"
    assert received[1]["event"]["reason"] == "no_matching_session"


@pytest.mark.asyncio
async def test_webhook_tolerates_upstream_error() -> None:
    async def handler(request: web.Request) -> web.Response:
        return web.Response(status=500, text="boom")

    app = web.Application()
    app.router.add_post("/hook", handler)

    async with TestServer(app) as server:
        url = str(server.make_url("/hook"))
        connector = WebhookConnector(url=url)
        try:
            # Must not raise — the pipeline keeps flowing even if SIEM is down.
            await connector.emit_action(_action_event())
        finally:
            await connector.close()


@pytest.mark.asyncio
async def test_splunk_hec_posts_with_auth_and_sourcetype() -> None:
    received: list[tuple[str, dict]] = []

    async def handler(request: web.Request) -> web.Response:
        auth = request.headers.get("Authorization", "")
        body = await request.json()
        received.append((auth, body))
        return web.Response(status=200, text='{"text":"Success","code":0}')

    app = web.Application()
    app.router.add_post("/services/collector/event", handler)

    async with TestServer(app) as server:
        base = str(server.make_url("")).rstrip("/")
        connector = SplunkHecConnector(url=base, token="secret-hec-token")
        try:
            await connector.emit_action(_action_event())
            await connector.emit_orphan(_orphan_event())
        finally:
            await connector.close()

    assert len(received) == 2
    for auth, body in received:
        assert auth == "Splunk secret-hec-token"
        assert body["source"] == "mcp-defense"
        assert "event" in body
    assert received[0][1]["sourcetype"] == "mcp-defense:agent_action"
    assert received[1][1]["sourcetype"] == "mcp-defense:orphan_flow"


@pytest.mark.asyncio
async def test_splunk_hec_tolerates_upstream_error() -> None:
    async def handler(request: web.Request) -> web.Response:
        return web.Response(status=503, text="busy")

    app = web.Application()
    app.router.add_post("/services/collector/event", handler)

    async with TestServer(app) as server:
        base = str(server.make_url("")).rstrip("/")
        connector = SplunkHecConnector(url=base, token="x")
        try:
            await connector.emit_action(_action_event())
        finally:
            await connector.close()


@pytest.mark.asyncio
async def test_tee_with_two_webhooks_delivers_to_both() -> None:
    received_a: list[dict] = []
    received_b: list[dict] = []

    async def handler_a(request: web.Request) -> web.Response:
        received_a.append(await request.json())
        return web.Response(status=200)

    async def handler_b(request: web.Request) -> web.Response:
        received_b.append(await request.json())
        return web.Response(status=200)

    app_a = web.Application()
    app_a.router.add_post("/hook", handler_a)
    app_b = web.Application()
    app_b.router.add_post("/hook", handler_b)

    async with TestServer(app_a) as server_a, TestServer(app_b) as server_b:
        url_a = str(server_a.make_url("/hook"))
        url_b = str(server_b.make_url("/hook"))
        tee = TeeActionSink([WebhookConnector(url=url_a), WebhookConnector(url=url_b)])
        try:
            await tee.emit_action(_action_event())
        finally:
            for sink in tee.sinks:
                await sink.close()  # type: ignore[attr-defined]

    assert len(received_a) == 1
    assert len(received_b) == 1
