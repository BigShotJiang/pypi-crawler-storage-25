"""Smoke tests — imports, archetype loading, crown jewel classification."""

from pathlib import Path

from mcp_defense.events import Decision
from mcp_defense.policy.archetypes import load_archetypes
from mcp_defense.policy.crown_jewels import Sensitivity, classify_path


def test_imports() -> None:
    assert Decision.ALLOW.value == "allow"


def test_archetypes_load() -> None:
    import mcp_defense
    config = Path(mcp_defense.__file__).parent / "config" / "archetypes.yaml"
    archetypes = load_archetypes(config)
    assert "filesystem" in archetypes
    assert archetypes["filesystem"].can_network is False
    assert "github" in archetypes
    assert 443 in archetypes["github"].allowed_ports


def test_crown_jewel_classification() -> None:
    assert classify_path("/home/alice/.aws/credentials") == Sensitivity.CROWN
    assert classify_path("/workspace/app/.env.local") == Sensitivity.AUTH
    assert classify_path("/workspace/pkg/package.json") == Sensitivity.CONFIG
    assert classify_path("/tmp/unremarkable.log") == Sensitivity.NORMAL
    # Instruction-file persistence surface
    assert classify_path("/workspace/project/CLAUDE.md") == Sensitivity.CONFIG
