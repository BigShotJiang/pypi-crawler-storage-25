# Using mcp-defense with Claude Code

Claude Code spawns MCP servers as local subprocesses over stdio. This guide
walks through wrapping those servers with `mcp-defense stdio` so every tool
call is policy-gated before the server sees it.

Total setup time: ~5 minutes for one server, ~2 minutes per additional server.

---

## Prerequisites

- Python 3.10+
- Claude Code installed and working against at least one MCP server
- `mcp-defense` installed (from source until the PyPI release lands):

```bash
git clone https://github.com/jessfortemnaturae8717/mcp-defense
cd mcp-defense
make install
# Verify:
.venv/bin/mcp-defense --help
```

Put `.venv/bin` on your PATH, or use the absolute path in Claude Code's
config below.

---

## How the wiring works

Claude Code normally spawns an MCP server directly:

```
[Claude Code] ──stdio──▶ [MCP server]
```

With `mcp-defense`, you insert the proxy as the actual spawned process. It
spawns the real server as its own child and pipes JSON-RPC through itself:

```
[Claude Code] ──stdio──▶ [mcp-defense stdio] ──stdio──▶ [MCP server]
                              │
                              ├─ policy engine (archetype + crown jewels)
                              ├─ correlation ID tagging
                              └─ (optional) approval prompt, SIEM fanout
```

Claude Code sees exactly the same protocol on its side. The MCP server sees
exactly the same protocol on its side. The proxy is transparent on
allowed calls and synthesizes a JSON-RPC error response on denied ones.

---

## Wrap your first MCP server: filesystem

Claude Code MCP servers are configured either with `claude mcp add` or by
editing `~/.claude/settings.json` (user scope) or `.claude/settings.json`
(project scope).

### Before

A typical filesystem server entry:

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/Users/you/code"]
    }
  }
}
```

### After

Replace it with an `mcp-defense stdio` invocation that spawns the same
underlying server:

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "mcp-defense",
      "args": [
        "stdio",
        "--archetype", "filesystem",
        "--agent-id", "claude-code",
        "--",
        "npx", "-y", "@modelcontextprotocol/server-filesystem", "/Users/you/code"
      ]
    }
  }
}
```

What changed:

- `command` is now `mcp-defense` (use the absolute path, e.g.
  `/Users/you/mcp-defense/.venv/bin/mcp-defense`, if it's not on your PATH)
- The original command + args moved after `--`
- We added `--archetype filesystem` and `--agent-id claude-code`

Restart Claude Code (or the session) to pick up the config change.

---

## Verify it works

With the wrapped server running, trigger a tool call in Claude Code — ask
it to read a file under the allowed directory. Then check the proxy's
log output. Claude Code surfaces MCP server stderr in its logs:

```
INFO mcp_defense.proxy.stdio stdio_proxy_started pid=12345 cgroup=None archetype=filesystem cmd=npx -y @modelcontextprotocol/server-filesystem /Users/you/code
INFO mcp_defense.proxy.sink tool_call cid=tc_abc1234567 agent=claude-code archetype=filesystem tool=read_file pid=12345 transport=stdio
INFO mcp_defense.proxy.sink policy_decision cid=tc_abc1234567 decision=allow rule=default_allow reason=within archetype baseline
```

Then ask Claude Code to read something outside the allowed dir, e.g.
`/etc/hosts`. You should see:

```
INFO mcp_defense.proxy.sink policy_decision cid=tc_def4567890 decision=deny rule=path_outside_allowlist reason=path outside archetype allowlist: /etc/hosts
```

Claude Code will receive a JSON-RPC error response with `isError: true`
and the denial reason.

---

## Wrap other MCP servers

Pick the archetype that matches the server's role. The proxy ships seven
built-in archetypes; see [src/mcp_defense/config/archetypes.yaml](../src/mcp_defense/config/archetypes.yaml):

| MCP server | Archetype | Why |
|---|---|---|
| `@modelcontextprotocol/server-filesystem` | `filesystem` | file ops, no network, no spawn |
| `@modelcontextprotocol/server-github` | `github` | egress to `api.github.com` only |
| `@modelcontextprotocol/server-postgres` | `database` | DB port only; configure `allowed_hosts` |
| `@modelcontextprotocol/server-fetch` | `web-fetch` | broad HTTPS, no file writes |
| `@modelcontextprotocol/server-puppeteer` | `web-fetch` | same |
| Shell / exec / command servers | `shell` | spawn allowed, network locked |
| Sandboxed code runners | `code-execution` | spawn allowed, network blocked, tmp-only fs |
| Anything else | `generic` | 24h observe, then enforce |

Each gets its own entry in `mcpServers` with its own `--archetype`. Same
pattern for every server — the archetype changes, the agent-id stays
`claude-code` (or whatever you want to call this agent in your SIEM).

---

## Level up: enforcement and approval

### Observation mode (safe default to start)

If you want to wire the proxy in without risking a broken workflow, add
`--observe`. Every tool call is logged, nothing is ever blocked:

```json
"args": [
  "stdio", "--archetype", "filesystem", "--agent-id", "claude-code", "--observe",
  "--", "npx", "-y", "@modelcontextprotocol/server-filesystem", "/Users/you/code"
]
```

Run this for a day. Watch what your agent actually does. Then drop
`--observe` and enforcement kicks in.

### Interactive approval for sensitive paths

Some paths trip `REQUIRE_APPROVAL` instead of `DENY` — `.env.local`,
`.gitconfig`, `.netrc`, and so on (see
[crown_jewels.py](../src/mcp_defense/policy/crown_jewels.py)). By default
those auto-deny. Add `--approval` to get an interactive prompt on your
terminal instead:

```json
"args": [
  "stdio", "--archetype", "filesystem", "--agent-id", "claude-code", "--approval",
  "--", "npx", "-y", "@modelcontextprotocol/server-filesystem", "/Users/you/code"
]
```

Next time Claude Code reaches for a sensitive file, your terminal will
prompt:

```
┌─ mcp-defense approval required ─────────────────────────────────────
│ agent          : claude-code
│ archetype      : filesystem
│ tool           : read_file
│ arguments      :
│   path = /Users/you/code/.env.local
│ reason         : sensitive_path — sensitive path: ...
│ correlation_id : tc_abc1234567
└─────────────────────────────────────────────────────────────────────
[y] allow once  [n] deny (default)  [a] allow+remember  [A] allow-all-session  [q] quit
>
```

The prompt reads/writes `/dev/tty`, so it appears in the terminal you
launched Claude Code from even though stdin/stdout are piped to the agent.

### SIEM delivery

Pipe `AgentActionEvent` / `OrphanFlowEvent` JSON to Splunk or any webhook:

```json
"args": [
  "stdio", "--archetype", "filesystem", "--agent-id", "claude-code",
  "--flow-source", "/tmp/flows",
  "--siem-splunk", "https://splunk.corp:8088:HEC_TOKEN",
  "--siem-webhook", "https://datadog.corp/api/v2/logs",
  "--", "npx", "-y", "@modelcontextprotocol/server-filesystem", "/Users/you/code"
]
```

`--flow-source` is only useful if you're also running the
[ternaryphysics-llm-security](#integrating-with-ternaryphysics-llm-security)
kernel bridge. Without it, SIEM sinks receive nothing (policy events are
emitted but correlator output requires a flow source to assemble).

---

## Integrating with ternaryphysics-llm-security

For full kernel correlation (tool call ↔ network flow), run the bridge on
the same host. It reads ternaryphysics's XDP `DetectionEvent` ringbuf and
writes JSONL `FlowEvent`s to a FIFO that the proxy reads:

```bash
# Terminal 1: start the bridge
mkfifo /tmp/flows
PYTHONPATH=/path/to/ternaryphysics-llm-security \
  sudo mcp-defense bridge-tp --fifo /tmp/flows --interface eth0
```

Then in Claude Code's config, add `--flow-source /tmp/flows` to each
wrapped server. The flight recorder output will now show both the tool
call AND the downstream network flows, plus any orphan flows from
processes that egress without a matching tool call.

---

## Troubleshooting

### Claude Code doesn't find `mcp-defense`

Use the absolute path in the config. If you installed with `make install`
in a cloned repo, the binary is at
`/path/to/mcp-defense/.venv/bin/mcp-defense`. Claude Code spawns the
command from its own working directory, which may not match yours.

### The proxy exits immediately

Check Claude Code's MCP server logs. The proxy writes to its own stderr
(which Claude Code surfaces) before exiting. Common causes:

- Missing `--` separator between proxy args and the server command
- Typo in `--archetype` (see `src/mcp_defense/config/archetypes.yaml` for the full list)
- The real MCP server command is not on PATH

### Approval prompt doesn't appear

The prompt goes to `/dev/tty`. Check:

1. Are you running Claude Code from an actual terminal? If it's launched
   from a non-terminal context (e.g., a background daemon, some IDE
   integrations), `/dev/tty` may not be reachable and the proxy will
   auto-deny with a log warning.
2. Did you pass `--approval`? Without it, `REQUIRE_APPROVAL` decisions
   auto-deny silently.

### I get denied but I actually want this access

Three levers, in order of reach:

1. **Scope your archetype** — if your filesystem server legitimately needs
   `/etc/`, add it to `allowed_paths` in your own copy of
   `src/mcp_defense/config/archetypes.yaml` and pass `--archetypes /path/to/your/copy.yaml`.
2. **Use `--approval`** — turn `REQUIRE_APPROVAL` denials into a prompt.
3. **Use `--observe`** temporarily — never blocks; logs everything for
   later policy tuning.

### Crown jewel denials I don't agree with

`crown_jewels` is a hardcoded Python dict. Edit
[src/mcp_defense/policy/crown_jewels.py](../src/mcp_defense/policy/crown_jewels.py)
and reinstall. A config-file override is on the roadmap.

---

## Where to go next

- `mcp-defense demo` — scripted end-to-end demo with mock flows
- [README](../README.md) — architecture overview
- [src/mcp_defense/config/archetypes.yaml](../src/mcp_defense/config/archetypes.yaml) — archetype reference
- [src/mcp_defense/policy/crown_jewels.py](../src/mcp_defense/policy/crown_jewels.py) — sensitive path list

Questions or a server type we should add an archetype for? Open an issue.
