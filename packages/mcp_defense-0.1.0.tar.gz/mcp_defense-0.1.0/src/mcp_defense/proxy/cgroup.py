"""Resolve cgroup v2 inode IDs from PIDs on Linux.

The correlator prefers cgroup_id as the join key because it's the same
integer the kernel exposes to BPF programs (bpf_get_current_cgroup_id),
and it survives PID reuse. This module parses /proc/<pid>/cgroup (cgroup
v2 unified hierarchy) and stats the corresponding path under /sys/fs/cgroup
to get the inode.

Returns None on non-Linux, missing PIDs, cgroup v1 hosts, or any read error.
The correlator falls back to PID-based matching in that case.
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

log = logging.getLogger(__name__)

CGROUP_MOUNT = "/sys/fs/cgroup"


def pid_to_cgroup_id(pid: int) -> int | None:
    """Return the cgroup v2 inode for `pid`, or None if unresolvable."""
    if sys.platform != "linux":
        return None
    try:
        raw = Path(f"/proc/{pid}/cgroup").read_text()
    except OSError:
        return None
    cg_path = parse_cgroup_v2_path(raw)
    if cg_path is None:
        return None
    try:
        return os.stat(CGROUP_MOUNT + cg_path).st_ino
    except OSError:
        return None


def parse_cgroup_v2_path(cgroup_file_contents: str) -> str | None:
    """Extract the cgroup v2 relative path from /proc/<pid>/cgroup contents.

    cgroup v2 lines look like:
        0::/user.slice/user-1000.slice/session-3.scope
    The hierarchy id is always "0" and the controllers field is empty.
    Returns None if no v2 line is present (pure-cgroup-v1 host).
    """
    for line in cgroup_file_contents.splitlines():
        parts = line.split(":", 2)
        if len(parts) != 3:
            continue
        if parts[0] != "0":
            continue
        return parts[2]
    return None
