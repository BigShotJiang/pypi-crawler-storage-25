"""stdio MCP transport interception with policy gating.

The proxy launches an MCP server as a child subprocess. JSON-RPC flows:
  agent stdin  -> proxy -> server stdin   (intercepted, policy-gated)
  server stdout -> proxy -> agent stdout  (pass-through)

For every tools/call request observed, a ToolCallEvent is created, emitted
to the sink, and evaluated by the policy gate. On ALLOW, the line is
forwarded verbatim. On DENY or REQUIRE_APPROVAL, a synthesized JSON-RPC
error response is written back to the agent and the line is NOT forwarded.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from datetime import datetime, timezone
from typing import IO

from mcp_defense.events import Decision, PolicyDecisionEvent, ToolCallEvent
from mcp_defense.policy.engine import AllowAllPolicy, PolicyGate
from mcp_defense.proxy.cgroup import pid_to_cgroup_id
from mcp_defense.proxy.correlation_id import new_correlation_id
from mcp_defense.proxy.jsonrpc import JsonRpcMessage, parse_line
from mcp_defense.proxy.sink import EventSink, LoggingSink

log = logging.getLogger(__name__)


class StdioProxy:
    def __init__(
        self,
        command: list[str],
        archetype: str,
        agent_id: str,
        sink: EventSink | None = None,
        policy: PolicyGate | None = None,
    ) -> None:
        self.command = command
        self.archetype = archetype
        self.agent_id = agent_id
        self.sink: EventSink = sink or LoggingSink()
        self.policy: PolicyGate = policy or AllowAllPolicy()
        self._proc: asyncio.subprocess.Process | None = None
        self._cgroup_id: int | None = None

    async def run(self) -> int:
        upstream_in = await _wrap_fd_as_reader(sys.stdin.buffer)
        return await self._run_with_streams(upstream_in, sys.stdout.buffer)

    async def _run_with_streams(
        self, upstream_in: asyncio.StreamReader, upstream_out: IO[bytes]
    ) -> int:
        self._proc = await asyncio.create_subprocess_exec(
            *self.command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=sys.stderr,
        )
        self._cgroup_id = pid_to_cgroup_id(self._proc.pid)
        log.info(
            "stdio_proxy_started pid=%s cgroup=%s archetype=%s cmd=%s",
            self._proc.pid,
            self._cgroup_id,
            self.archetype,
            " ".join(self.command),
        )

        upward = asyncio.create_task(
            self._forward_upstream(upstream_in, self._proc.stdin, upstream_out)
        )
        downward = asyncio.create_task(
            self._forward_downstream(self._proc.stdout, upstream_out)
        )

        exit_code = await self._proc.wait()
        for t in (upward, downward):
            if not t.done():
                t.cancel()
        await asyncio.gather(upward, downward, return_exceptions=True)
        log.info("stdio_proxy_exited code=%s", exit_code)
        return exit_code

    async def _forward_upstream(
        self,
        src: asyncio.StreamReader,
        to_server: asyncio.StreamWriter | None,
        to_agent: IO[bytes],
    ) -> None:
        if to_server is None:
            return
        try:
            while True:
                line = await src.readline()
                if not line:
                    break
                decision = await self._process_line(line)
                if decision is None or decision.decision in (Decision.ALLOW, Decision.APPROVED):
                    to_server.write(line)
                    await to_server.drain()
                else:
                    self._write_denial(line, decision, to_agent)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("stdio_proxy_upstream_error")
        finally:
            try:
                if to_server is not None:
                    to_server.close()
            except Exception:
                pass

    async def _forward_downstream(
        self,
        src: asyncio.StreamReader | None,
        dst: IO[bytes],
    ) -> None:
        if src is None:
            return
        try:
            while True:
                line = await src.readline()
                if not line:
                    break
                dst.write(line)
                dst.flush()
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("stdio_proxy_downstream_error")

    async def _process_line(self, line: bytes) -> PolicyDecisionEvent | None:
        """Emit events + get a policy decision. Returns None if line is not a tool call."""
        msg = parse_line(line)
        if msg is None or not msg.is_tool_call:
            return None
        event = ToolCallEvent(
            correlation_id=new_correlation_id(),
            timestamp=datetime.now(timezone.utc),
            agent_id=self.agent_id,
            server_archetype=self.archetype,
            server_pid=self._proc.pid if self._proc else -1,
            container_id=None,
            tool_name=msg.tool_name or "<unknown>",
            tool_args=msg.tool_arguments,
            transport="stdio",
            cgroup_id=self._cgroup_id,
        )
        await self.sink.emit(event)
        decision = await self.policy.evaluate(event)
        await self.sink.emit_decision(decision)
        return decision

    def _write_denial(
        self, original_line: bytes, decision: PolicyDecisionEvent, to_agent: IO[bytes]
    ) -> None:
        """Synthesize a JSON-RPC error response and write it back to the agent."""
        msg: JsonRpcMessage | None = parse_line(original_line)
        request_id = msg.id if msg is not None else None
        body = {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "isError": True,
                "content": [
                    {
                        "type": "text",
                        "text": f"blocked by mcp-defense [{decision.matched_rule}]: {decision.reason}",
                    }
                ],
            },
        }
        to_agent.write((json.dumps(body) + "\n").encode("utf-8"))
        to_agent.flush()


async def _wrap_fd_as_reader(stream: IO[bytes]) -> asyncio.StreamReader:
    loop = asyncio.get_event_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, stream)
    return reader
