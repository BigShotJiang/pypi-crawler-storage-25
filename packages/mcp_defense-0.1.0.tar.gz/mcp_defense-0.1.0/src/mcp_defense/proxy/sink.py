"""Event sink abstraction.

Sinks are observability. They receive every ToolCallEvent the proxy sees
and every PolicyDecisionEvent the engine emits. They never block the
forwarding path — policy gating is a separate concern (see policy.engine).
"""

from __future__ import annotations

import logging
from typing import Protocol

from mcp_defense.events import PolicyDecisionEvent, ToolCallEvent

log = logging.getLogger(__name__)


class EventSink(Protocol):
    async def emit(self, event: ToolCallEvent) -> None: ...

    async def emit_decision(self, event: PolicyDecisionEvent) -> None: ...


class LoggingSink:
    """Default sink. Logs every event."""

    async def emit(self, event: ToolCallEvent) -> None:
        log.info(
            "tool_call cid=%s agent=%s archetype=%s tool=%s pid=%s transport=%s",
            event.correlation_id,
            event.agent_id,
            event.server_archetype,
            event.tool_name,
            event.server_pid,
            event.transport,
        )

    async def emit_decision(self, event: PolicyDecisionEvent) -> None:
        log.info(
            "policy_decision cid=%s decision=%s rule=%s reason=%s",
            event.correlation_id,
            event.decision.value,
            event.matched_rule,
            event.reason,
        )


class CapturingSink:
    """Test helper."""

    def __init__(self) -> None:
        self.events: list[ToolCallEvent] = []
        self.decisions: list[PolicyDecisionEvent] = []

    async def emit(self, event: ToolCallEvent) -> None:
        self.events.append(event)

    async def emit_decision(self, event: PolicyDecisionEvent) -> None:
        self.decisions.append(event)
