"""Correlation ID generation for tool calls.

Every intercepted tool call gets one. Format: `tc_` + 10 lowercase base32 chars
(48 bits of entropy). Compact, obvious on sight, collision-safe for any
realistic traffic volume.
"""

from __future__ import annotations

import base64
import secrets

CORRELATION_ID_PREFIX = "tc"


def new_correlation_id() -> str:
    raw = secrets.token_bytes(6)
    encoded = base64.b32encode(raw).decode("ascii").rstrip("=").lower()
    return f"{CORRELATION_ID_PREFIX}_{encoded}"
