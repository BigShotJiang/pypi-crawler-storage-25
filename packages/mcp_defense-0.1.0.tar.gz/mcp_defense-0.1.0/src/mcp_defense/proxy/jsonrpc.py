"""Minimal JSON-RPC 2.0 message parsing for MCP interception.

We only need enough to recognize tools/call requests, extract name and
arguments, and pass everything else through unchanged. No validation,
no error synthesis — the real server handles all of that.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

MCP_TOOL_CALL_METHOD = "tools/call"


@dataclass
class JsonRpcMessage:
    raw: dict[str, Any]

    @property
    def method(self) -> str | None:
        m = self.raw.get("method")
        return m if isinstance(m, str) else None

    @property
    def params(self) -> dict[str, Any]:
        p = self.raw.get("params")
        return p if isinstance(p, dict) else {}

    @property
    def id(self) -> Any:
        return self.raw.get("id")

    @property
    def is_request(self) -> bool:
        return self.method is not None and "id" in self.raw

    @property
    def is_notification(self) -> bool:
        return self.method is not None and "id" not in self.raw

    @property
    def is_response(self) -> bool:
        return "id" in self.raw and (
            "result" in self.raw or "error" in self.raw
        ) and self.method is None

    @property
    def is_tool_call(self) -> bool:
        return self.is_request and self.method == MCP_TOOL_CALL_METHOD

    @property
    def tool_name(self) -> str | None:
        if not self.is_tool_call:
            return None
        name = self.params.get("name")
        return name if isinstance(name, str) else None

    @property
    def tool_arguments(self) -> dict[str, Any]:
        if not self.is_tool_call:
            return {}
        args = self.params.get("arguments")
        return args if isinstance(args, dict) else {}


def parse_line(line: bytes | str) -> JsonRpcMessage | None:
    """Parse a single line (or SSE POST body) into a JsonRpcMessage.

    Returns None if the input is empty, malformed JSON, or not a JSON object.
    Never raises: malformed input from an MCP session should never crash the
    proxy — we forward unknown bytes verbatim.
    """
    if isinstance(line, bytes):
        try:
            line = line.decode("utf-8")
        except UnicodeDecodeError:
            return None
    line = line.strip()
    if not line:
        return None
    try:
        obj = json.loads(line)
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None
    return JsonRpcMessage(raw=obj)
