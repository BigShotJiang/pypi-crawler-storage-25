"""SSE MCP transport interception with policy gating.

Reverse-proxy in front of an upstream MCP SSE server. The SSE event stream
(GET) is forwarded unchanged. POST requests carrying JSON-RPC are parsed;
tool_call requests run through the policy engine.

On DENY or REQUIRE_APPROVAL, the POST is NOT forwarded upstream. Instead
we return HTTP 403 with a JSON-RPC error body. This is a deliberate break
from pure MCP-SSE semantics — strictly, the response should arrive via the
SSE channel — but it's the cleanest actionable signal we can return from a
reverse proxy. MCP clients that don't handle 403 will see a stalled call,
which is Sticky-Trap-aligned.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone

import aiohttp
from aiohttp import web

from mcp_defense.events import Decision, PolicyDecisionEvent, ToolCallEvent
from mcp_defense.policy.engine import AllowAllPolicy, PolicyGate
from mcp_defense.proxy.correlation_id import new_correlation_id
from mcp_defense.proxy.jsonrpc import JsonRpcMessage, parse_line
from mcp_defense.proxy.sink import EventSink, LoggingSink

log = logging.getLogger(__name__)

_HOP_BY_HOP_HEADERS = frozenset(
    {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
        "host",
        "content-length",
    }
)


class SseProxy:
    def __init__(
        self,
        upstream_url: str,
        archetype: str,
        agent_id: str,
        bind_host: str = "127.0.0.1",
        bind_port: int = 0,
        sink: EventSink | None = None,
        policy: PolicyGate | None = None,
    ) -> None:
        self.upstream_url = upstream_url.rstrip("/")
        self.archetype = archetype
        self.agent_id = agent_id
        self.bind_host = bind_host
        self.bind_port = bind_port
        self.sink: EventSink = sink or LoggingSink()
        self.policy: PolicyGate = policy or AllowAllPolicy()
        self._session: aiohttp.ClientSession | None = None

    async def run(self) -> None:
        app = web.Application()
        app.router.add_route("*", "/{path:.*}", self._handle)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, self.bind_host, self.bind_port)
        self._session = aiohttp.ClientSession()
        await site.start()
        log.info(
            "sse_proxy_listening host=%s port=%s upstream=%s archetype=%s",
            self.bind_host,
            self._actual_port(site),
            self.upstream_url,
            self.archetype,
        )
        try:
            while True:
                await asyncio.sleep(3600)
        except asyncio.CancelledError:
            pass
        finally:
            if self._session is not None:
                await self._session.close()
            await runner.cleanup()

    @staticmethod
    def _actual_port(site: web.TCPSite) -> int:
        srv = site._server
        if srv is None or not srv.sockets:
            return -1
        return srv.sockets[0].getsockname()[1]

    async def _handle(self, request: web.Request) -> web.StreamResponse:
        assert self._session is not None
        body = await request.read()

        if request.method == "POST" and body:
            decision = await self._process_body(body)
            if decision is not None and decision.decision not in (
                Decision.ALLOW,
                Decision.APPROVED,
            ):
                return self._denial_response(body, decision)

        target = self._build_target_url(request)
        headers = {
            k: v
            for k, v in request.headers.items()
            if k.lower() not in _HOP_BY_HOP_HEADERS
        }
        try:
            upstream_resp = await self._session.request(
                request.method,
                target,
                headers=headers,
                data=body,
                allow_redirects=False,
            )
        except aiohttp.ClientError:
            log.exception("sse_proxy_upstream_error target=%s", target)
            return web.Response(status=502, text="Bad Gateway")

        resp = web.StreamResponse(
            status=upstream_resp.status,
            headers={
                k: v
                for k, v in upstream_resp.headers.items()
                if k.lower() not in _HOP_BY_HOP_HEADERS
            },
        )
        await resp.prepare(request)
        try:
            async for chunk in upstream_resp.content.iter_any():
                await resp.write(chunk)
        finally:
            await resp.write_eof()
            upstream_resp.release()
        return resp

    def _build_target_url(self, request: web.Request) -> str:
        path = request.match_info["path"]
        target = f"{self.upstream_url}/{path}" if path else self.upstream_url
        if request.query_string:
            target = f"{target}?{request.query_string}"
        return target

    async def _process_body(self, body: bytes) -> PolicyDecisionEvent | None:
        msg = parse_line(body)
        if msg is None or not msg.is_tool_call:
            return None
        event = ToolCallEvent(
            correlation_id=new_correlation_id(),
            timestamp=datetime.now(timezone.utc),
            agent_id=self.agent_id,
            server_archetype=self.archetype,
            server_pid=-1,
            container_id=None,
            tool_name=msg.tool_name or "<unknown>",
            tool_args=msg.tool_arguments,
            transport="sse",
        )
        await self.sink.emit(event)
        decision = await self.policy.evaluate(event)
        await self.sink.emit_decision(decision)
        return decision

    def _denial_response(
        self, body: bytes, decision: PolicyDecisionEvent
    ) -> web.Response:
        msg: JsonRpcMessage | None = parse_line(body)
        request_id = msg.id if msg is not None else None
        payload = {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": -32600,
                "message": f"blocked by mcp-defense [{decision.matched_rule}]: {decision.reason}",
            },
        }
        return web.Response(
            status=403,
            body=json.dumps(payload).encode("utf-8"),
            content_type="application/json",
        )
