"""MCP transport proxy.

Intercepts stdio and SSE MCP transports between an agent and an MCP server.
Assigns a correlation_id to every tool call. Forwards to the policy engine
for allow/deny decisions. Forwards allowed calls to the server unchanged.
"""
