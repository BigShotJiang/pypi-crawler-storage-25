"""SIEM connector base — protocol, fanout sink, and JSON serializers.

AgentActionSink is already defined in mcp_defense.correlation.join; every
connector implements it. TeeActionSink fans out to a list of sinks, catching
per-sink failures so one broken endpoint doesn't take the pipeline down.
"""

from __future__ import annotations

import logging
from typing import Any

from mcp_defense.correlation.join import AgentActionSink
from mcp_defense.events import (
    AgentActionEvent,
    FlowEvent,
    OrphanFlowEvent,
)

log = logging.getLogger(__name__)


class TeeActionSink(AgentActionSink):
    """Fan out events to multiple sinks. One sink failing never blocks others."""

    def __init__(self, sinks: list[AgentActionSink]) -> None:
        self.sinks = list(sinks)

    async def emit_action(self, event: AgentActionEvent) -> None:
        for sink in self.sinks:
            try:
                await sink.emit_action(event)
            except Exception:
                log.exception(
                    "tee emit_action failed sink=%s", type(sink).__name__
                )

    async def emit_orphan(self, event: OrphanFlowEvent) -> None:
        for sink in self.sinks:
            try:
                await sink.emit_orphan(event)
            except Exception:
                log.exception(
                    "tee emit_orphan failed sink=%s", type(sink).__name__
                )


def _flow_to_dict(flow: FlowEvent) -> dict[str, Any]:
    return {
        "timestamp": flow.timestamp.isoformat(),
        "src_ip": flow.src_ip,
        "src_port": flow.src_port,
        "dst_ip": flow.dst_ip,
        "dst_port": flow.dst_port,
        "protocol": flow.protocol,
        "classification": flow.classification,
        "action": flow.action,
        "confidence": flow.confidence,
        "cgroup_id": flow.cgroup_id,
        "source_pid": flow.source_pid,
    }


def serialize_action(event: AgentActionEvent) -> dict[str, Any]:
    return {
        "correlation_id": event.correlation_id,
        "timestamp": event.timestamp.isoformat(),
        "tool_call": {
            "agent_id": event.tool_call.agent_id,
            "server_archetype": event.tool_call.server_archetype,
            "server_pid": event.tool_call.server_pid,
            "cgroup_id": event.tool_call.cgroup_id,
            "container_id": event.tool_call.container_id,
            "tool_name": event.tool_call.tool_name,
            "tool_args": event.tool_call.tool_args,
            "transport": event.tool_call.transport,
        },
        "policy_decision": {
            "decision": event.policy_decision.decision.value,
            "reason": event.policy_decision.reason,
            "matched_rule": event.policy_decision.matched_rule,
        },
        "flows": [_flow_to_dict(f) for f in event.flows],
        "killed": event.killed,
        "kill_reason": event.kill_reason,
    }


def serialize_orphan(event: OrphanFlowEvent) -> dict[str, Any]:
    return {
        "timestamp": event.timestamp.isoformat(),
        "reason": event.reason,
        "flow": _flow_to_dict(event.flow),
    }
