"""Generic webhook connector.

POSTs JSON to a configured URL. The payload shape is:
    {"type": "agent_action" | "orphan_flow", "event": {...}}

Useful for Datadog logs API (with the right headers), Slack incoming
webhooks with a formatter, Elastic bulk index (with some adjustment),
and anything that accepts JSON over HTTP.
"""

from __future__ import annotations

import logging

import aiohttp

from mcp_defense.correlation.join import AgentActionSink
from mcp_defense.events import AgentActionEvent, OrphanFlowEvent
from mcp_defense.siem.base import serialize_action, serialize_orphan

log = logging.getLogger(__name__)


class WebhookConnector(AgentActionSink):
    def __init__(
        self,
        url: str,
        extra_headers: dict[str, str] | None = None,
        verify_ssl: bool = True,
    ) -> None:
        self.url = url
        self.extra_headers = dict(extra_headers or {})
        self.verify_ssl = verify_ssl
        self._session: aiohttp.ClientSession | None = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers=self.extra_headers,
                connector=aiohttp.TCPConnector(ssl=self.verify_ssl),
            )
        return self._session

    async def emit_action(self, event: AgentActionEvent) -> None:
        await self._post({"type": "agent_action", "event": serialize_action(event)})

    async def emit_orphan(self, event: OrphanFlowEvent) -> None:
        await self._post({"type": "orphan_flow", "event": serialize_orphan(event)})

    async def _post(self, payload: dict) -> None:
        session = await self._ensure_session()
        try:
            async with session.post(self.url, json=payload) as resp:
                if resp.status >= 400:
                    text = await resp.text()
                    log.warning(
                        "webhook status=%s url=%s body=%s",
                        resp.status,
                        self.url,
                        text[:200],
                    )
        except aiohttp.ClientError:
            log.exception("webhook send failed url=%s", self.url)

    async def close(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None
