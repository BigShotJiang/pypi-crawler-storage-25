"""Splunk HTTP Event Collector (HEC) connector.

Posts each AgentActionEvent and OrphanFlowEvent as an HEC event to
<base_url>/services/collector/event. Sourcetype is set per-event so
operators can filter on `sourcetype=mcp-defense:agent_action` or
`sourcetype=mcp-defense:orphan_flow` in Splunk.
"""

from __future__ import annotations

import logging

import aiohttp

from mcp_defense.correlation.join import AgentActionSink
from mcp_defense.events import AgentActionEvent, OrphanFlowEvent
from mcp_defense.siem.base import serialize_action, serialize_orphan

log = logging.getLogger(__name__)


class SplunkHecConnector(AgentActionSink):
    def __init__(
        self,
        url: str,
        token: str,
        sourcetype_prefix: str = "mcp-defense",
        source: str = "mcp-defense",
        verify_ssl: bool = True,
    ) -> None:
        self.endpoint = url.rstrip("/") + "/services/collector/event"
        self.token = token
        self.sourcetype_prefix = sourcetype_prefix
        self.source = source
        self.verify_ssl = verify_ssl
        self._session: aiohttp.ClientSession | None = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={"Authorization": f"Splunk {self.token}"},
                connector=aiohttp.TCPConnector(ssl=self.verify_ssl),
            )
        return self._session

    async def emit_action(self, event: AgentActionEvent) -> None:
        await self._post("agent_action", serialize_action(event))

    async def emit_orphan(self, event: OrphanFlowEvent) -> None:
        await self._post("orphan_flow", serialize_orphan(event))

    async def _post(self, kind: str, payload: dict) -> None:
        session = await self._ensure_session()
        body = {
            "event": payload,
            "sourcetype": f"{self.sourcetype_prefix}:{kind}",
            "source": self.source,
        }
        try:
            async with session.post(self.endpoint, json=body) as resp:
                if resp.status >= 400:
                    text = await resp.text()
                    log.warning(
                        "splunk hec status=%s body=%s", resp.status, text[:200]
                    )
        except aiohttp.ClientError:
            log.exception("splunk hec send failed endpoint=%s", self.endpoint)

    async def close(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None
