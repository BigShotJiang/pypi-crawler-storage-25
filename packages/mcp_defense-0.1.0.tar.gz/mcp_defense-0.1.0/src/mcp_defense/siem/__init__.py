"""SIEM connectors.

Each connector implements AgentActionSink so it can be dropped into the
correlator's output slot (usually via TeeActionSink alongside the flight
recorder). Failures are logged and swallowed — SIEM delivery problems must
not block the enforcement pipeline.
"""

from mcp_defense.siem.base import (
    TeeActionSink,
    serialize_action,
    serialize_orphan,
)
from mcp_defense.siem.splunk import SplunkHecConnector
from mcp_defense.siem.webhook import WebhookConnector

__all__ = [
    "SplunkHecConnector",
    "TeeActionSink",
    "WebhookConnector",
    "serialize_action",
    "serialize_orphan",
]
