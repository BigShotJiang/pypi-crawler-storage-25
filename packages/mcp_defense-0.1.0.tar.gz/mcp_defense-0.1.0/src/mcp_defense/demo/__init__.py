"""Scripted end-to-end demo.

Run via ``mcp-defense demo`` or ``make demo``. Composes the full pipeline
— proxy events, policy engine, correlator, flight recorder — in-process
against a scripted scenario that exercises every decision path.
"""
