"""Crown jewels — agent-specific sensitive paths.

Touching these from an AI agent context is an immediate high-severity event.
Sensitivity scores drive action: CROWN (10) = deny+kill, AUTH (7) = require
approval, CONFIG (3) = log (future: elevate on repeat access).

The list is intentionally agent-centric. It differs from traditional server
crown jewels (/etc/shadow) in that it emphasizes what a prompt-injected AI
agent would reach for: developer credentials, CI tamper surfaces, supply
chain files, and the agent's own instruction files (prompt injection
persistence).
"""

from __future__ import annotations

from enum import IntEnum

from mcp_defense.policy.matcher import path_matches


class Sensitivity(IntEnum):
    NORMAL = 0
    CONFIG = 3
    AUTH = 7
    CROWN = 10


# Glob patterns -> sensitivity. See policy.matcher for pattern semantics.
CROWN_JEWELS: dict[str, Sensitivity] = {
    # ---- SENSITIVITY_CROWN (10) ----
    "/root/.ssh/**": Sensitivity.CROWN,
    "/home/*/.ssh/id_*": Sensitivity.CROWN,
    "/home/*/.ssh/authorized_keys": Sensitivity.CROWN,
    "/home/*/.aws/credentials": Sensitivity.CROWN,
    "/home/*/.aws/config": Sensitivity.CROWN,
    "/home/*/.config/gcloud/application_default_credentials.json": Sensitivity.CROWN,
    "/home/*/.kube/config": Sensitivity.CROWN,
    "/home/*/.docker/config.json": Sensitivity.CROWN,
    "/etc/kubernetes/admin.conf": Sensitivity.CROWN,
    "/var/run/secrets/kubernetes.io/serviceaccount/**": Sensitivity.CROWN,
    "/proc/*/environ": Sensitivity.CROWN,
    "/proc/*/mem": Sensitivity.CROWN,
    "/dev/kmsg": Sensitivity.CROWN,
    "/dev/mem": Sensitivity.CROWN,
    "/dev/kcore": Sensitivity.CROWN,
    # ---- SENSITIVITY_AUTH (7) ----
    "/home/*/.gitconfig": Sensitivity.AUTH,
    "/home/*/.git-credentials": Sensitivity.AUTH,
    "/home/*/.netrc": Sensitivity.AUTH,
    "/home/*/.npmrc": Sensitivity.AUTH,
    "/home/*/.pypirc": Sensitivity.AUTH,
    "/home/*/.cargo/credentials.toml": Sensitivity.AUTH,
    "/home/*/.config/gh/hosts.yml": Sensitivity.AUTH,
    "/home/*/.config/hub": Sensitivity.AUTH,
    "/home/*/.anthropic/**": Sensitivity.AUTH,
    "/home/*/.config/claude/**": Sensitivity.AUTH,
    "/home/*/.config/openai/**": Sensitivity.AUTH,
    "/workspace/.env": Sensitivity.AUTH,
    "/workspace/**/.env.local": Sensitivity.AUTH,
    "/workspace/**/.env.*": Sensitivity.AUTH,
    "/workspace/**/secrets.yaml": Sensitivity.AUTH,
    "/workspace/**/secrets.json": Sensitivity.AUTH,
    "/var/run/docker.sock": Sensitivity.AUTH,
    "/var/run/containerd/containerd.sock": Sensitivity.AUTH,
    # ---- SENSITIVITY_CONFIG (3) — supply chain / CI tamper surface ----
    "/workspace/**/.git/config": Sensitivity.CONFIG,
    "/workspace/**/.git/hooks/**": Sensitivity.CONFIG,
    "/workspace/**/package.json": Sensitivity.CONFIG,
    "/workspace/**/package-lock.json": Sensitivity.CONFIG,
    "/workspace/**/pyproject.toml": Sensitivity.CONFIG,
    "/workspace/**/setup.py": Sensitivity.CONFIG,
    "/workspace/**/Cargo.toml": Sensitivity.CONFIG,
    "/workspace/**/go.mod": Sensitivity.CONFIG,
    "/workspace/**/.github/workflows/**": Sensitivity.CONFIG,
    "/workspace/**/.gitlab-ci.yml": Sensitivity.CONFIG,
    "/workspace/**/Dockerfile": Sensitivity.CONFIG,
    "/workspace/**/docker-compose.yml": Sensitivity.CONFIG,
    # Prompt injection persistence — the agent's own instruction files.
    "/workspace/**/CLAUDE.md": Sensitivity.CONFIG,
    "/workspace/**/.cursorrules": Sensitivity.CONFIG,
    "/workspace/**/.claude/**": Sensitivity.CONFIG,
}


def classify_path(path: str) -> Sensitivity:
    """Return the highest sensitivity level matching the given path."""
    best = Sensitivity.NORMAL
    for pattern, sensitivity in CROWN_JEWELS.items():
        if path_matches(pattern, path) and sensitivity > best:
            best = sensitivity
    return best
