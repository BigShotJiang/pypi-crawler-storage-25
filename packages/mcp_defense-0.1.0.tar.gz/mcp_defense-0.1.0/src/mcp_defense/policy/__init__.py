"""Policy engine and archetype baselines.

Given a ToolCallEvent, returns a PolicyDecisionEvent (allow / deny /
require_approval). Decisions are driven by:

1. The archetype of the MCP server (see archetypes.py)
2. The crown jewel sensitivity of the target resource (see crown_jewels.py)
3. Runtime deviations from the archetype baseline
"""
