"""Policy engine.

Evaluates a ToolCallEvent and returns a PolicyDecisionEvent.

Evaluation order:
  1. Unknown archetype          -> DENY
  2. Learning-mode archetype    -> ALLOW (observation)
  3. Crown jewel path matches   -> DENY (CROWN) / REQUIRE_APPROVAL (AUTH)
  4. Structural archetype rules -> DENY if tool implies disallowed capability
  5. Archetype path allowlist   -> DENY if path outside allowed_paths
  6. Archetype host allowlist   -> DENY if host outside allowed_hosts
  7. Default                    -> ALLOW

Every decision carries a `matched_rule` string identifying which rule fired,
for SIEM filtering and flight recorder grouping.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Protocol
from urllib.parse import urlparse

from mcp_defense.events import Decision, PolicyDecisionEvent, ToolCallEvent
from mcp_defense.policy.archetypes import Archetype
from mcp_defense.policy.crown_jewels import Sensitivity, classify_path
from mcp_defense.policy.extractor import extract_paths, extract_urls
from mcp_defense.policy.matcher import path_matches

_SPAWN_HINTS: frozenset[str] = frozenset(
    {"exec", "execute", "run", "spawn", "shell", "command", "bash", "sh"}
)


class PolicyGate(Protocol):
    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent: ...


class AllowAllPolicy:
    """Observation-only gate. Always ALLOW. Used when no archetypes loaded."""

    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent:
        return _decision(event, Decision.ALLOW, "observe-only", "observe_only")


class PolicyEngine:
    def __init__(self, archetypes: dict[str, Archetype]) -> None:
        self.archetypes = archetypes

    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent:
        archetype = self.archetypes.get(event.server_archetype)
        if archetype is None:
            return _decision(
                event,
                Decision.DENY,
                f"unknown archetype: {event.server_archetype}",
                "unknown_archetype",
            )

        if archetype.learning_mode:
            return _decision(
                event,
                Decision.ALLOW,
                f"archetype '{archetype.name}' in learning mode",
                "learning_mode",
            )

        paths = extract_paths(event.tool_args)
        urls = extract_urls(event.tool_args)

        # 1. Crown jewels — highest priority, checked regardless of archetype.
        for p in paths:
            sens = classify_path(p)
            if sens == Sensitivity.CROWN:
                return _decision(
                    event, Decision.DENY, f"crown jewel: {p}", "crown_jewel"
                )
            if sens == Sensitivity.AUTH:
                return _decision(
                    event,
                    Decision.REQUIRE_APPROVAL,
                    f"sensitive path: {p}",
                    "sensitive_path",
                )

        # 2. Structural archetype rules.
        if _looks_like_spawn(event) and not archetype.can_spawn:
            return _decision(
                event,
                Decision.DENY,
                f"archetype '{archetype.name}' forbids spawn (tool={event.tool_name})",
                "archetype_no_spawn",
            )
        if urls and not archetype.can_network:
            return _decision(
                event,
                Decision.DENY,
                f"archetype '{archetype.name}' forbids network (tool={event.tool_name})",
                "archetype_no_network",
            )

        # 3. Archetype path allowlist.
        if archetype.allowed_paths:
            for p in paths:
                if not any(path_matches(pat, p) for pat in archetype.allowed_paths):
                    return _decision(
                        event,
                        Decision.DENY,
                        f"path outside archetype allowlist: {p}",
                        "path_outside_allowlist",
                    )

        # 4. Archetype host allowlist.
        if archetype.allowed_hosts:
            for url in urls:
                host = _extract_host(url)
                if host is None:
                    continue
                if not any(_host_matches(pat, host) for pat in archetype.allowed_hosts):
                    return _decision(
                        event,
                        Decision.DENY,
                        f"host outside allowlist: {host}",
                        "host_outside_allowlist",
                    )

        return _decision(event, Decision.ALLOW, "within archetype baseline", "default_allow")


def _looks_like_spawn(event: ToolCallEvent) -> bool:
    name = event.tool_name.lower()
    return any(hint in name for hint in _SPAWN_HINTS)


def _extract_host(url_or_host: str) -> str | None:
    if "://" in url_or_host:
        try:
            return urlparse(url_or_host).hostname
        except ValueError:
            return None
    # Bare hostname (from extract_urls key-hint heuristic).
    return url_or_host.split(":", 1)[0] if url_or_host else None


def _host_matches(pattern: str, host: str) -> bool:
    """Exact match or suffix wildcard (e.g. '*.github.com' matches 'api.github.com')."""
    if pattern == host:
        return True
    if pattern.startswith("*.") and host.endswith(pattern[1:]):
        return True
    return False


def _decision(
    event: ToolCallEvent, decision: Decision, reason: str, rule: str
) -> PolicyDecisionEvent:
    return PolicyDecisionEvent(
        correlation_id=event.correlation_id,
        timestamp=datetime.now(timezone.utc),
        decision=decision,
        reason=reason,
        matched_rule=rule,
    )
