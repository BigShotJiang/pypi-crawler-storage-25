"""Interactive approval for REQUIRE_APPROVAL decisions.

When a policy rule returns REQUIRE_APPROVAL (e.g., `sensitive_path` for a
file like `/workspace/.env.local`), an InteractiveApprovalGate pauses and
prompts the operator on /dev/tty:

    y   allow this one call
    n   deny (default on empty input)
    a   allow and remember (tool_name, primary_arg) for this session
    A   allow ALL require_approval decisions for this session
    q   quit the proxy entirely

We talk to /dev/tty directly so the prompt works even when the proxy's
stdin/stdout are piped to an MCP agent (which they always are in stdio
transport). Without a tty, the gate logs once and auto-rejects.

Decision flow:
    inner_gate.evaluate(event)  ->  REQUIRE_APPROVAL
      -> prompt(event, decision) -> (approved?, note)
        -> returns PolicyDecisionEvent with Decision.APPROVED or REJECTED
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Awaitable, Callable

from mcp_defense.events import Decision, PolicyDecisionEvent, ToolCallEvent
from mcp_defense.policy.engine import PolicyGate

log = logging.getLogger(__name__)

AskFunction = Callable[[str], Awaitable[str]]


def default_tty_ask(tty_path: str = "/dev/tty") -> AskFunction:
    """Return an ask coroutine that reads and writes /dev/tty."""

    async def ask(question: str) -> str:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _blocking_tty_io, tty_path, question)

    return ask


def _blocking_tty_io(tty_path: str, question: str) -> str:
    with open(tty_path, "r+") as tty:
        tty.write(question)
        tty.flush()
        return tty.readline()


@dataclass
class ApprovalState:
    """Session-scoped allow state. Shared across prompts in a single process."""

    allow_all: bool = False
    allow_keys: set[tuple[str, str]] = field(default_factory=set)


class ApprovalPrompt:
    """Ask a human operator whether to allow a REQUIRE_APPROVAL tool call."""

    def __init__(
        self,
        ask: AskFunction | None = None,
        session_state: ApprovalState | None = None,
    ) -> None:
        self._ask: AskFunction = ask or default_tty_ask()
        self.state = session_state or ApprovalState()
        self._tty_broken = False

    async def prompt(
        self, event: ToolCallEvent, decision: PolicyDecisionEvent
    ) -> tuple[bool, str]:
        """Return (allowed, note). Note explains the outcome for audit logs."""
        key = self._key(event)

        if self.state.allow_all:
            return True, "session allow-all"
        if key in self.state.allow_keys:
            return True, f"session allow-list matched {key[0]}/{key[1]!r}"
        if self._tty_broken:
            return False, "no tty — auto-rejected"

        question = self._format(event, decision)
        try:
            raw = await self._ask(question)
        except OSError as e:
            log.warning(
                "approval tty unavailable: %s — auto-rejecting this and future approvals",
                e,
            )
            self._tty_broken = True
            return False, f"tty unavailable: {e}"

        stripped = (raw or "").strip()

        if stripped.lower() == "y":
            return True, "one-shot approval"
        if stripped == "a":
            self.state.allow_keys.add(key)
            return True, f"session allow-list added {key[0]}/{key[1]!r}"
        if stripped == "A":
            self.state.allow_all = True
            return True, "session allow-all enabled"
        if stripped.lower() == "q":
            log.info("operator quit during approval; sending SIGTERM to self")
            os.kill(os.getpid(), signal.SIGTERM)
            return False, "quit requested by operator"

        return False, "operator denied"

    @staticmethod
    def _key(event: ToolCallEvent) -> tuple[str, str]:
        """Session allow-list key: (tool_name, first non-empty string arg)."""
        for value in event.tool_args.values():
            if isinstance(value, str) and value:
                return event.tool_name, value
        return event.tool_name, ""

    @staticmethod
    def _format(event: ToolCallEvent, decision: PolicyDecisionEvent) -> str:
        arg_lines = ""
        for k, v in list(event.tool_args.items())[:5]:
            v_str = str(v)
            if len(v_str) > 70:
                v_str = v_str[:67] + "..."
            arg_lines += f"│   {k} = {v_str}\n"
        return (
            "\n"
            "┌─ mcp-defense approval required ─────────────────────────────────────\n"
            f"│ agent          : {event.agent_id}\n"
            f"│ archetype      : {event.server_archetype}\n"
            f"│ tool           : {event.tool_name}\n"
            f"│ arguments      :\n"
            f"{arg_lines}"
            f"│ reason         : {decision.matched_rule} — {decision.reason}\n"
            f"│ correlation_id : {event.correlation_id}\n"
            "└─────────────────────────────────────────────────────────────────────\n"
            "[y] allow once  [n] deny (default)  [a] allow+remember  "
            "[A] allow-all-session  [q] quit\n"
            "> "
        )


class InteractiveApprovalGate(PolicyGate):
    """Wraps a PolicyGate with interactive approval for REQUIRE_APPROVAL."""

    def __init__(
        self,
        inner: PolicyGate,
        prompt: ApprovalPrompt | None = None,
    ) -> None:
        self.inner = inner
        self.prompt = prompt or ApprovalPrompt()

    async def evaluate(self, event: ToolCallEvent) -> PolicyDecisionEvent:
        decision = await self.inner.evaluate(event)
        if decision.decision != Decision.REQUIRE_APPROVAL:
            return decision

        approved, note = await self.prompt.prompt(event, decision)
        return PolicyDecisionEvent(
            correlation_id=decision.correlation_id,
            timestamp=datetime.now(timezone.utc),
            decision=Decision.APPROVED if approved else Decision.REJECTED,
            reason=f"{note} (original: {decision.reason})",
            matched_rule=f"approval:{decision.matched_rule}",
        )
