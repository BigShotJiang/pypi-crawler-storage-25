"""Extract likely paths and URLs from MCP tool call arguments.

MCP tool schemas vary per server. For Week 2 we use heuristics:
  - Any string value that starts with `/`, `./`, `../`, or `~/` is a path.
  - Any string value that starts with an http(s):// (or ws(s)://, ftp://) is a URL.
  - Any string value under a key like `path`, `file`, `dir`, `filename` is a path.
  - Any string value under a key like `url`, `uri`, `endpoint`, `host` is a URL.

Walks nested dicts and lists. Returns flat lists of candidate strings.
Upgradeable in Week 3+ by consuming the server's advertised tool schemas
from the `tools/list` response.
"""

from __future__ import annotations

import re
from typing import Any, Iterable

_PATH_KEY_HINT = re.compile(r"(path|file|dir|directory|filename|filepath)", re.IGNORECASE)
_URL_KEY_HINT = re.compile(r"(url|uri|endpoint|host|address)", re.IGNORECASE)
_URL_PREFIX = re.compile(r"^(https?|s?ftp|wss?)://", re.IGNORECASE)
_PATH_PREFIXES = ("/", "./", "../", "~/")


def extract_paths(args: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for key, value in _walk(args):
        if not isinstance(value, str):
            continue
        if _URL_PREFIX.match(value):
            continue  # URL, not a path
        if value.startswith(_PATH_PREFIXES):
            out.append(value)
        elif _PATH_KEY_HINT.search(key):
            out.append(value)
    return out


def extract_urls(args: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for key, value in _walk(args):
        if not isinstance(value, str):
            continue
        if _URL_PREFIX.match(value):
            out.append(value)
        elif _URL_KEY_HINT.search(key) and "." in value:
            # Hostname without scheme, e.g. "api.github.com"
            out.append(value)
    return out


def _walk(obj: Any, key: str = "") -> Iterable[tuple[str, Any]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _walk(v, k)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            yield from _walk(v, key)
    else:
        yield key, obj
