"""Path glob matcher with gitignore-style `**` recursive wildcards.

Standard `fnmatch` and `pathlib.PurePath.match` don't support `**` spanning
multiple path segments. We need that for crown jewels like
`/workspace/**/.env.local`. Hand-rolled to avoid an extra dependency.

Semantics:
  - `/` anchors: patterns starting with `/` only match absolute paths.
  - `*`  matches any characters within a single segment.
  - `?`  matches a single character within a segment.
  - `**` matches zero or more entire segments.
"""

from __future__ import annotations

import fnmatch


def path_matches(pattern: str, path: str) -> bool:
    if pattern.startswith("/") != path.startswith("/"):
        return False
    pat_segs = [s for s in pattern.strip("/").split("/") if s]
    path_segs = [s for s in path.strip("/").split("/") if s]
    return _match_segs(pat_segs, path_segs)


def _match_segs(pattern: list[str], path: list[str]) -> bool:
    if not pattern:
        return not path
    head = pattern[0]
    rest = pattern[1:]
    if head == "**":
        # Zero-segment match: consume the **, keep the path.
        if _match_segs(rest, path):
            return True
        # One-or-more-segment match: consume a path segment, keep the **.
        if path and _match_segs(pattern, path[1:]):
            return True
        return False
    if not path:
        return False
    if not fnmatch.fnmatchcase(path[0], head):
        return False
    return _match_segs(rest, path[1:])
