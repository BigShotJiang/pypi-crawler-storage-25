"""MCP server archetype baselines.

An archetype declares what a given MCP server type is expected to do:
which paths it touches, which network destinations it reaches, whether it
spawns children. Runtime actions outside the archetype trigger policy.

Archetypes load from config/archetypes.yaml.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class Archetype:
    """Expected behavior shape for a class of MCP server."""

    name: str
    allowed_paths: list[str] = field(default_factory=list)
    allowed_ports: list[int] = field(default_factory=list)
    allowed_hosts: list[str] = field(default_factory=list)
    can_network: bool = False
    can_spawn: bool = False
    allowed_children: list[str] = field(default_factory=list)
    learning_mode: bool = False
    description: str = ""


def load_archetypes(config_path: str | Path) -> dict[str, Archetype]:
    """Load archetypes from a YAML config file."""
    config_path = Path(config_path)
    with config_path.open() as f:
        data: dict[str, Any] = yaml.safe_load(f)

    archetypes: dict[str, Archetype] = {}
    for name, spec in (data.get("archetypes") or {}).items():
        archetypes[name] = Archetype(name=name, **spec)
    return archetypes
