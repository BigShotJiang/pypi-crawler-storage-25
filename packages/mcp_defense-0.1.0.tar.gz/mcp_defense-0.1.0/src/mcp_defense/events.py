"""Unified event schema for mcp-defense.

Every event flowing through the system — from MCP proxy, from the policy
engine, from the kernel correlation layer — normalizes to one of these types.
The flight recorder and SIEM connectors consume AgentActionEvent (and
OrphanFlowEvent for unattributed egress).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"
    APPROVED = "approved"
    REJECTED = "rejected"


class EventSource(str, Enum):
    MCP_PROXY = "mcp_proxy"
    POLICY_ENGINE = "policy_engine"
    KERNEL_XDP = "kernel_xdp"
    KERNEL_LSM = "kernel_lsm"
    CORRELATION = "correlation"


@dataclass
class ToolCallEvent:
    """An MCP tool call observed by the proxy."""

    correlation_id: str
    timestamp: datetime
    agent_id: str
    server_archetype: str
    server_pid: int
    container_id: str | None
    tool_name: str
    tool_args: dict[str, Any]
    transport: str  # "stdio" or "sse"
    cgroup_id: int | None = None  # populated when proxy can resolve /proc/<pid>/cgroup


@dataclass
class FlowEvent:
    """A network flow classified by the XDP layer."""

    timestamp: datetime
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: int
    classification: str  # LEGITIMATE / SUSPICIOUS / MALICIOUS / UNKNOWN
    action: str  # PASS / TAG / DROP / LIMIT
    confidence: int
    cgroup_id: int | None = None
    source_pid: int | None = None


@dataclass
class PolicyDecisionEvent:
    """A policy engine decision on a tool call."""

    correlation_id: str
    timestamp: datetime
    decision: Decision
    reason: str
    matched_rule: str | None


@dataclass
class AgentActionEvent:
    """Unified event. One tool call joined with its downstream kernel effects."""

    correlation_id: str
    timestamp: datetime
    tool_call: ToolCallEvent
    policy_decision: PolicyDecisionEvent
    flows: list[FlowEvent] = field(default_factory=list)
    killed: bool = False
    kill_reason: str | None = None


@dataclass
class OrphanFlowEvent:
    """A flow that couldn't be attributed to any live tool-call session.

    This is the strongest anomaly signal the correlator produces: a process
    egressed the network without any tool call authorizing it. A
    filesystem-archetype MCP server reaching unknown-external:443 is the
    canonical case.
    """

    timestamp: datetime
    flow: FlowEvent
    reason: str  # "no_matching_session" | "archetype_violation" | ...
