"""Flight recorder — live-streaming AgentActionEvents and OrphanFlowEvents
to a rich-styled terminal output.

One line per event as it closes. Color-coded by decision. Orphan flows get
their own row and stand out in red — they're the anomaly signal the demo
exists to surface.
"""

from __future__ import annotations

from rich.console import Console

from mcp_defense.correlation.join import AgentActionSink
from mcp_defense.events import (
    AgentActionEvent,
    Decision,
    OrphanFlowEvent,
)

_DECISION_STYLE: dict[Decision, tuple[str, str]] = {
    Decision.ALLOW: ("green", "ALLOW"),
    Decision.DENY: ("red bold", "DENY"),
    Decision.REQUIRE_APPROVAL: ("yellow", "APPROVE"),
    Decision.APPROVED: ("green", "APPROVED"),
    Decision.REJECTED: ("red bold", "REJECTED"),
}

_FLOW_ACTION_STYLE: dict[str, str] = {
    "PASS": "green",
    "TAG": "yellow",
    "LIMIT": "yellow",
    "DROP": "red bold",
}


class FlightRecorder(AgentActionSink):
    """Streams events to the console and tracks simple counts for a summary."""

    def __init__(self, console: Console | None = None) -> None:
        self.console = console or Console()
        self.count_allow = 0
        self.count_deny = 0
        self.count_approval = 0
        self.count_orphan = 0

    async def emit_action(self, event: AgentActionEvent) -> None:
        decision = event.policy_decision.decision
        style, label = _DECISION_STYLE.get(decision, ("white", decision.value.upper()))

        ts = event.tool_call.timestamp.strftime("%H:%M:%S.%f")[:-3]
        cid = event.correlation_id
        arch = event.tool_call.server_archetype
        tool = event.tool_call.tool_name
        target = self._summarize_args(event.tool_call.tool_args)

        self.console.print(
            f"[dim]{ts}[/dim]  "
            f"[{style}]{label:<8}[/{style}] "
            f"[bold]{cid:<14}[/bold] "
            f"{arch:<12} "
            f"{tool:<24} "
            f"{target}"
        )

        if decision != Decision.ALLOW:
            rule = event.policy_decision.matched_rule or "?"
            self.console.print(
                f"              [dim]↳ {rule}: {event.policy_decision.reason}[/dim]"
            )

        for flow in event.flows:
            flow_style = _FLOW_ACTION_STYLE.get(flow.action, "white")
            self.console.print(
                f"              [dim]└ flow[/dim] "
                f"{flow.src_ip}:{flow.src_port} → {flow.dst_ip}:{flow.dst_port} "
                f"[{flow_style}]{flow.action}[/{flow_style}]"
            )

        if decision in (Decision.ALLOW, Decision.APPROVED):
            self.count_allow += 1
        elif decision in (Decision.DENY, Decision.REJECTED):
            self.count_deny += 1
        elif decision == Decision.REQUIRE_APPROVAL:
            self.count_approval += 1

    async def emit_orphan(self, event: OrphanFlowEvent) -> None:
        ts = event.timestamp.strftime("%H:%M:%S.%f")[:-3]
        flow = event.flow
        flow_style = _FLOW_ACTION_STYLE.get(flow.action, "red")
        self.console.print(
            f"[dim]{ts}[/dim]  "
            f"[red bold]ORPHAN  [/red bold] "
            f"[dim]{'-':<14} -            -                        [/dim]"
            f"[{flow_style}]{flow.src_ip}:{flow.src_port} → "
            f"{flow.dst_ip}:{flow.dst_port} {flow.action}[/{flow_style}]"
        )
        self.console.print(
            f"              [dim]↳ {event.reason}[/dim]"
        )
        self.count_orphan += 1

    def print_summary(self) -> None:
        self.console.print()
        self.console.print(
            f"[dim]{self.count_allow} allow · "
            f"{self.count_deny} deny · "
            f"{self.count_approval} approval · "
            f"{self.count_orphan} orphan[/dim]"
        )

    @staticmethod
    def _summarize_args(args: dict) -> str:
        """Render the first two key=value pairs for compact display."""
        items: list[str] = []
        for i, (k, v) in enumerate(args.items()):
            if i >= 2:
                break
            v_str = str(v)
            if len(v_str) > 48:
                v_str = v_str[:45] + "…"
            items.append(f"{k}={v_str}")
        return " ".join(items)
