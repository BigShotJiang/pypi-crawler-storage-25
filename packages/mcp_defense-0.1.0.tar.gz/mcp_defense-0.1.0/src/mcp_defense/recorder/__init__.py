"""Flight recorder.

Timeline view of every tool call and its downstream kernel effects. Renders
the killer demo: `filesystem.read` at t=0, `unexpected external egress`
appearing as an ORPHAN at t=0.5s, with the cause chain visible.
"""

from mcp_defense.recorder.flight import FlightRecorder

__all__ = ["FlightRecorder"]
