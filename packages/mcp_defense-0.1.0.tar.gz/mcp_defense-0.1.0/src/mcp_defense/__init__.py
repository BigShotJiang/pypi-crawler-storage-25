"""mcp-defense: Kernel-native runtime defense for AI agents."""

__version__ = "0.1.0"
