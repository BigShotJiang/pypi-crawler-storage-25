"""Bridge ternaryphysics-llm-security DetectionEvents -> mcp-defense FlowEvents.

The mcp-defense correlator consumes FlowEvents as newline-delimited JSON via
JsonLinesFlowSource. This module provides:

  - detection_event_to_flow_dict: pure conversion (duck-typed, testable)
  - run_bridge: runs the ternaryphysics loader and writes to a file/FIFO

CLI entry (via mcp-defense bridge-tp):
    mkfifo /tmp/flows
    mcp-defense bridge-tp --fifo /tmp/flows --interface eth0

The importing side runs ternaryphysics-llm-security's LLMSecurityLoader, which
requires BPF on Linux + root. Missing dependencies produce a clear error and
exit non-zero rather than crashing.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

_CLASS_NAMES = {0: "LEGITIMATE", 1: "SUSPICIOUS", 2: "MALICIOUS", 3: "UNKNOWN"}
_ACTION_NAMES = {0: "PASS", 1: "TAG", 2: "DROP", 3: "LIMIT"}


def detection_event_to_flow_dict(event: Any) -> dict[str, Any]:
    """Translate a DetectionEvent-shaped object to a FlowEvent JSON dict.

    Duck-typed: the argument must expose the attributes of
    ternaryphysics_llm_security.inference.loader.DetectionEvent. Accepts both
    integer-coded classification/action (kernel style) and string-coded
    (post-translation style).
    """
    ts = event.timestamp
    if isinstance(ts, (int, float)):
        # ternaryphysics DetectionEvent.timestamp is nanoseconds since epoch.
        dt = datetime.fromtimestamp(ts / 1e9, tz=timezone.utc)
    elif isinstance(ts, datetime):
        dt = ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)
    else:
        dt = datetime.now(timezone.utc)

    classification = event.classification
    if isinstance(classification, int):
        classification = _CLASS_NAMES.get(classification, "UNKNOWN")

    action = event.action
    if isinstance(action, int):
        action = _ACTION_NAMES.get(action, "TAG")

    return {
        "timestamp": dt.isoformat(),
        "src_ip": event.src_ip,
        "dst_ip": event.dst_ip,
        "src_port": int(event.src_port),
        "dst_port": int(event.dst_port),
        "protocol": int(getattr(event, "proto", getattr(event, "protocol", 0))),
        "classification": classification,
        "action": action,
        "confidence": int(event.confidence),
        "cgroup_id": getattr(event, "cgroup_id", None),
        "source_pid": getattr(event, "pid", getattr(event, "source_pid", None)),
    }


def run_bridge(
    fifo_path: str,
    interface: str = "eth0",
    config_path: str | None = None,
) -> int:
    """Start the ternaryphysics loader and write FlowEvents as JSONL."""
    loader_cls = _import_loader()
    if loader_cls is None:
        log.error(
            "bridge-tp requires ternaryphysics-llm-security on PYTHONPATH. "
            "Install it, or run with PYTHONPATH=/path/to/ternaryphysics-llm-security"
        )
        return 2

    out_path = Path(fifo_path)
    log.info("bridge-tp opening %s for write", out_path)
    out = out_path.open("a", buffering=1)  # line-buffered

    loader = loader_cls(interface=interface, config_path=config_path)
    loader.load_bpf()

    def emit(event: Any) -> None:
        try:
            payload = detection_event_to_flow_dict(event)
        except Exception:
            log.exception("bridge-tp conversion failed; dropping event")
            return
        out.write(json.dumps(payload) + "\n")

    try:
        loader.poll_events(callback=emit)
    finally:
        loader.unload()
        out.close()
    return 0


def _import_loader() -> Any | None:
    """Best-effort import of ternaryphysics-llm-security's loader class."""
    # The ternaryphysics repo uses `src.inference.loader` as its package
    # (src/ on PYTHONPATH) rather than publishing a distribution package.
    try:
        from src.inference.loader import LLMSecurityLoader  # type: ignore[import-not-found]
        return LLMSecurityLoader
    except ImportError:
        pass
    try:
        from ternaryphysics_llm_security.inference.loader import (  # type: ignore[import-not-found]
            LLMSecurityLoader,
        )
        return LLMSecurityLoader
    except ImportError:
        pass
    return None


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="mcp-defense bridge-tp",
        description="Bridge ternaryphysics-llm-security DetectionEvents -> mcp-defense FlowEvent JSONL",
    )
    parser.add_argument("--fifo", required=True, help="output FIFO or file path")
    parser.add_argument("--interface", default="eth0", help="network interface")
    parser.add_argument("--config", default=None, help="ternaryphysics config file (optional)")
    args = parser.parse_args(argv)
    return run_bridge(args.fifo, args.interface, args.config)


if __name__ == "__main__":
    sys.exit(main())
