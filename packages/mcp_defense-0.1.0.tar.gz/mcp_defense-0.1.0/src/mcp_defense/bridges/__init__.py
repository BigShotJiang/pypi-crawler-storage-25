"""Kernel event bridges.

Each bridge reads events from a producer (XDP loader, LSM daemon, etc.)
and writes them as JSONL FlowEvents to a file or FIFO that JsonLinesFlowSource
can consume. See ternaryphysics.py for the reference implementation.
"""
