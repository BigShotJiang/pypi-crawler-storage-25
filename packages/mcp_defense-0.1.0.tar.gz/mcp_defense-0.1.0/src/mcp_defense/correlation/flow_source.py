"""Flow event sources.

A FlowSource is anything that asynchronously yields FlowEvents. In
production this is a bridge to ternaryphysics-llm-security's XDP ringbuf.
For tests, use MockFlowSource. For integration with an external producer,
use JsonLinesFlowSource to read newline-delimited JSON from a file or FIFO.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterator, Protocol

from mcp_defense.events import FlowEvent


class FlowSource(Protocol):
    def stream(self) -> AsyncIterator[FlowEvent]: ...


class MockFlowSource:
    """In-memory flow source for testing. Push events, close when done."""

    def __init__(self) -> None:
        self._queue: asyncio.Queue[FlowEvent | None] = asyncio.Queue()

    def push(self, event: FlowEvent) -> None:
        self._queue.put_nowait(event)

    def close(self) -> None:
        self._queue.put_nowait(None)

    async def stream(self) -> AsyncIterator[FlowEvent]:
        while True:
            event = await self._queue.get()
            if event is None:
                return
            yield event


class JsonLinesFlowSource:
    """Read FlowEvents as newline-delimited JSON from a file or FIFO.

    Expected line format:
      {"timestamp": "2026-04-24T12:00:00+00:00", "src_ip": "10.0.0.5",
       "dst_ip": "1.2.3.4", "src_port": 50001, "dst_port": 443,
       "protocol": 6, "classification": "MALICIOUS", "action": "DROP",
       "confidence": 87, "cgroup_id": 1234567, "source_pid": 4242}

    Readers tolerate malformed lines (logged and skipped).
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    async def stream(self) -> AsyncIterator[FlowEvent]:
        loop = asyncio.get_event_loop()
        f = await loop.run_in_executor(None, open, str(self.path), "r")
        try:
            while True:
                line = await loop.run_in_executor(None, f.readline)
                if not line:
                    return
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(data, dict):
                    continue
                try:
                    yield _parse_flow_event(data)
                except (KeyError, ValueError):
                    continue
        finally:
            await loop.run_in_executor(None, f.close)


def _parse_flow_event(data: dict[str, Any]) -> FlowEvent:
    return FlowEvent(
        timestamp=datetime.fromisoformat(data["timestamp"]),
        src_ip=data["src_ip"],
        dst_ip=data["dst_ip"],
        src_port=int(data["src_port"]),
        dst_port=int(data["dst_port"]),
        protocol=int(data["protocol"]),
        classification=data["classification"],
        action=data["action"],
        confidence=int(data["confidence"]),
        cgroup_id=_optional_int(data.get("cgroup_id")),
        source_pid=_optional_int(data.get("source_pid")),
    )


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
