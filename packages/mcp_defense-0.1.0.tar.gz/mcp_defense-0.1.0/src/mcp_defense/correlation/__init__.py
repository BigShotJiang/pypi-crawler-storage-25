"""Correlation layer.

Joins ToolCallEvent (from the proxy) with FlowEvent (from ternaryphysics-
llm-security's XDP classifier) to produce unified AgentActionEvents.

Join strategy: cgroup ID primary, source PID fallback, within a time window.
"""

from mcp_defense.correlation.flow_source import (
    FlowSource,
    JsonLinesFlowSource,
    MockFlowSource,
)
from mcp_defense.correlation.join import (
    AgentActionSink,
    CapturingActionSink,
    Correlator,
    LoggingActionSink,
)

__all__ = [
    "AgentActionSink",
    "CapturingActionSink",
    "Correlator",
    "FlowSource",
    "JsonLinesFlowSource",
    "LoggingActionSink",
    "MockFlowSource",
]
