"""Correlator: joins ToolCallEvents with downstream FlowEvents.

The correlator is an EventSink (from the proxy's perspective) AND a flow
ingestion endpoint (from the kernel/XDP bridge's perspective). It emits
AgentActionEvents when a tool call's time window closes, and
OrphanFlowEvents when a flow cannot be attributed to any live session.

Session lifecycle:
  1. Proxy calls emit(tool_call)        -> session created, indexed by pid/cgroup
  2. Proxy calls emit_decision(decision) -> session gains its policy decision
     - If DENY / REQUIRE_APPROVAL: session closes immediately (no flows expected)
     - If ALLOW: session stays open for `window_seconds` to attribute flows
  3. Flow source calls ingest_flow(flow) -> flow is attached if a session matches
  4. Background closer expires stale sessions and emits AgentActionEvents

Join keys, in priority order:
  1. cgroup_id (kernel-authoritative)
  2. source_pid (when the flow source provides it)

If neither matches a live session, the flow is emitted as an OrphanFlowEvent.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Protocol

from mcp_defense.events import (
    AgentActionEvent,
    Decision,
    FlowEvent,
    OrphanFlowEvent,
    PolicyDecisionEvent,
    ToolCallEvent,
)

log = logging.getLogger(__name__)


class AgentActionSink(Protocol):
    async def emit_action(self, event: AgentActionEvent) -> None: ...

    async def emit_orphan(self, event: OrphanFlowEvent) -> None: ...


class LoggingActionSink:
    async def emit_action(self, event: AgentActionEvent) -> None:
        log.info(
            "agent_action cid=%s tool=%s decision=%s rule=%s flows=%d",
            event.correlation_id,
            event.tool_call.tool_name,
            event.policy_decision.decision.value,
            event.policy_decision.matched_rule,
            len(event.flows),
        )

    async def emit_orphan(self, event: OrphanFlowEvent) -> None:
        log.warning(
            "orphan_flow reason=%s src=%s:%s dst=%s:%s action=%s pid=%s cgroup=%s",
            event.reason,
            event.flow.src_ip,
            event.flow.src_port,
            event.flow.dst_ip,
            event.flow.dst_port,
            event.flow.action,
            event.flow.source_pid,
            event.flow.cgroup_id,
        )


class CapturingActionSink:
    """Test helper."""

    def __init__(self) -> None:
        self.actions: list[AgentActionEvent] = []
        self.orphans: list[OrphanFlowEvent] = []

    async def emit_action(self, event: AgentActionEvent) -> None:
        self.actions.append(event)

    async def emit_orphan(self, event: OrphanFlowEvent) -> None:
        self.orphans.append(event)


@dataclass
class _Session:
    correlation_id: str
    tool_call: ToolCallEvent
    policy_decision: PolicyDecisionEvent | None = None
    flows: list[FlowEvent] = field(default_factory=list)
    created_at: float = 0.0  # monotonic
    expires_at: float = 0.0


class Correlator:
    def __init__(
        self,
        action_sink: AgentActionSink | None = None,
        window_seconds: float = 5.0,
        closer_interval: float = 0.1,
    ) -> None:
        self.action_sink = action_sink or LoggingActionSink()
        self.window_seconds = window_seconds
        self.closer_interval = closer_interval
        self._sessions: dict[str, _Session] = {}
        self._pid_index: dict[int, set[str]] = {}
        self._cgroup_index: dict[int, set[str]] = {}
        self._lock = asyncio.Lock()
        self._closer_task: asyncio.Task[None] | None = None
        self._pending_emits: set[asyncio.Task[None]] = set()

    # ---- EventSink interface (from the proxy) --------------------------

    async def emit(self, event: ToolCallEvent) -> None:
        now = asyncio.get_event_loop().time()
        async with self._lock:
            session = _Session(
                correlation_id=event.correlation_id,
                tool_call=event,
                created_at=now,
                expires_at=now + self.window_seconds,
            )
            self._sessions[event.correlation_id] = session
            if event.server_pid > 0:
                self._pid_index.setdefault(event.server_pid, set()).add(event.correlation_id)
            if event.cgroup_id is not None:
                self._cgroup_index.setdefault(event.cgroup_id, set()).add(event.correlation_id)

    async def emit_decision(self, event: PolicyDecisionEvent) -> None:
        async with self._lock:
            session = self._sessions.get(event.correlation_id)
            if session is None:
                log.warning("decision without session cid=%s", event.correlation_id)
                return
            session.policy_decision = event
            # DENY/REJECTED/REQUIRE_APPROVAL close immediately: the proxy
            # blocked the call, no downstream flows should be expected for
            # this correlation_id. ALLOW and APPROVED keep the session open.
            if event.decision not in (Decision.ALLOW, Decision.APPROVED):
                self._close_session_locked(session)

    # ---- Flow ingestion ------------------------------------------------

    async def ingest_flow(self, flow: FlowEvent) -> None:
        async with self._lock:
            session = self._find_session_locked(flow)
            if session is None:
                orphan = OrphanFlowEvent(
                    timestamp=datetime.now(timezone.utc),
                    flow=flow,
                    reason="no_matching_session",
                )
                self._schedule_emit_orphan(orphan)
                return
            session.flows.append(flow)

    def _find_session_locked(self, flow: FlowEvent) -> _Session | None:
        now = asyncio.get_event_loop().time()
        # Prefer cgroup_id (kernel-authoritative).
        if flow.cgroup_id is not None:
            for cid in self._cgroup_index.get(flow.cgroup_id, ()):
                session = self._sessions.get(cid)
                if session and session.expires_at > now:
                    return session
        # Fall back to source_pid.
        if flow.source_pid is not None:
            for cid in self._pid_index.get(flow.source_pid, ()):
                session = self._sessions.get(cid)
                if session and session.expires_at > now:
                    return session
        return None

    # ---- Session closing ----------------------------------------------

    def _close_session_locked(self, session: _Session) -> None:
        # Remove from all indexes.
        self._sessions.pop(session.correlation_id, None)
        pid = session.tool_call.server_pid
        if pid > 0:
            bucket = self._pid_index.get(pid)
            if bucket is not None:
                bucket.discard(session.correlation_id)
                if not bucket:
                    self._pid_index.pop(pid, None)
        cgid = session.tool_call.cgroup_id
        if cgid is not None:
            bucket = self._cgroup_index.get(cgid)
            if bucket is not None:
                bucket.discard(session.correlation_id)
                if not bucket:
                    self._cgroup_index.pop(cgid, None)
        # Fire emission outside the lock.
        self._schedule_emit_action(session)

    def _schedule_emit_action(self, session: _Session) -> None:
        if session.policy_decision is None:
            # Shouldn't happen in practice: we never close before decision arrives.
            log.warning("closing session without decision cid=%s", session.correlation_id)
            return
        event = AgentActionEvent(
            correlation_id=session.correlation_id,
            timestamp=datetime.now(timezone.utc),
            tool_call=session.tool_call,
            policy_decision=session.policy_decision,
            flows=list(session.flows),
        )
        task = asyncio.create_task(self.action_sink.emit_action(event))
        self._pending_emits.add(task)
        task.add_done_callback(self._pending_emits.discard)

    def _schedule_emit_orphan(self, event: OrphanFlowEvent) -> None:
        task = asyncio.create_task(self.action_sink.emit_orphan(event))
        self._pending_emits.add(task)
        task.add_done_callback(self._pending_emits.discard)

    # ---- Lifecycle ----------------------------------------------------

    async def start(self) -> None:
        if self._closer_task is None:
            self._closer_task = asyncio.create_task(self._closer_loop())

    async def stop(self) -> None:
        if self._closer_task is not None:
            self._closer_task.cancel()
            try:
                await self._closer_task
            except asyncio.CancelledError:
                pass
            self._closer_task = None
        # Flush remaining sessions that have a decision.
        async with self._lock:
            for session in list(self._sessions.values()):
                if session.policy_decision is not None:
                    self._close_session_locked(session)
        # Wait for any pending emissions to complete.
        if self._pending_emits:
            await asyncio.gather(*self._pending_emits, return_exceptions=True)

    async def _closer_loop(self) -> None:
        while True:
            await asyncio.sleep(self.closer_interval)
            async with self._lock:
                now = asyncio.get_event_loop().time()
                expired = [
                    s
                    for s in self._sessions.values()
                    if s.expires_at <= now and s.policy_decision is not None
                ]
                for s in expired:
                    self._close_session_locked(s)
