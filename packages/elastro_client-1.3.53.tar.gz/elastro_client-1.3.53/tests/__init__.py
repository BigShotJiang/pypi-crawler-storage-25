"""Tests package for the elastro module."""
