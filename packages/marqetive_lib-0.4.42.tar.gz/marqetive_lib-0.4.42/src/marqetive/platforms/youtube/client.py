"""YouTube Shorts client using YouTube Data API v3."""

import contextlib
import os
from datetime import UTC, datetime
from typing import Any, cast

import httpx
from pydantic import HttpUrl

from marqetive.core.base import ProgressCallback, SocialMediaPlatform
from marqetive.core.exceptions import (
    PlatformAuthError,
    PlatformError,
    PostNotFoundError,
    ValidationError,
)
from marqetive.core.models import (
    AuthCredentials,
    Comment,
    CommentStatus,
    MediaAttachment,
    MediaType,
    Post,
    PostCreateRequest,
    PostStatus,
    PostUpdateRequest,
)
from marqetive.platforms.youtube.media import (
    YouTubeShortsMediaManager,
    build_video_metadata,
)
from marqetive.utils.file_handlers import download_file

YOUTUBE_API_BASE = "https://www.googleapis.com/youtube/v3"


class YouTubeShortsClient(SocialMediaPlatform):
    """Client for publishing and managing YouTube Shorts via YouTube Data API v3.

    Credentials:
        access_token: OAuth2 Bearer token with youtube.upload and youtube.force-ssl scopes.
        refresh_token: OAuth2 refresh token (used by PlatformFactory).

    Example:
        >>> creds = AuthCredentials(platform="youtube", access_token="ya29.xxx")
        >>> async with YouTubeShortsClient(creds) as client:
        ...     post = await client.create_post(
        ...         PostCreateRequest(
        ...             content="My Short",
        ...             media_urls=["https://example.com/video.mp4"],
        ...             additional_data={"privacy_level": "public"},
        ...         )
        ...     )
        ...     print(post.url)
    """

    def __init__(
        self,
        credentials: AuthCredentials,
        timeout: float = 300.0,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        super().__init__(
            platform_name="youtube",
            credentials=credentials,
            base_url=YOUTUBE_API_BASE,
            timeout=timeout,
            progress_callback=progress_callback,
        )
        self._media_manager: YouTubeShortsMediaManager | None = None
        self._channel_id: str | None = None

    # ── Auth headers ─────────────────────────────────────────────────────────

    def _build_auth_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.credentials.access_token}",
            "Content-Type": "application/json",
        }

    # ── Context manager ──────────────────────────────────────────────────────

    async def _setup_managers(self) -> None:
        if not self.credentials.access_token:
            raise PlatformAuthError("Access token is required", "youtube")
        self._media_manager = YouTubeShortsMediaManager(
            access_token=self.credentials.access_token,
            timeout=self.timeout,
            progress_callback=self._progress_callback,
        )
        await self.authenticate()
        self._channel_id = self.credentials.user_id

    async def _cleanup_managers(self) -> None:
        self._media_manager = None
        self._channel_id = None

    async def __aenter__(self) -> "YouTubeShortsClient":
        await super().__aenter__()
        await self._setup_managers()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self._cleanup_managers()
        await super().__aexit__(exc_type, exc_val, exc_tb)

    @staticmethod
    def _video_to_post(video: dict[str, Any]) -> Post:
        """Convert a YouTube video resource to a universal Post."""
        video_id = video.get("id", "")
        snippet = video.get("snippet", {})
        status = video.get("status", {})
        statistics = video.get("statistics", {})

        privacy = status.get("privacyStatus", "public")
        publish_at = status.get("publishAt")

        if publish_at:
            post_status = PostStatus.SCHEDULED
        elif privacy == "public":
            post_status = PostStatus.PUBLISHED
        else:
            post_status = PostStatus.PUBLISHED

        published_at_str = snippet.get("publishedAt")
        created_at = datetime.now(UTC)
        if published_at_str:
            with contextlib.suppress(ValueError):
                created_at = datetime.fromisoformat(
                    published_at_str.replace("Z", "+00:00")
                )

        scheduled_at = None
        if publish_at:
            with contextlib.suppress(ValueError):
                scheduled_at = datetime.fromisoformat(publish_at.replace("Z", "+00:00"))

        thumbnails = snippet.get("thumbnails", {})
        thumbnail_url: str | None = None
        for quality in ("maxres", "high", "medium", "default"):
            if quality in thumbnails:
                thumbnail_url = thumbnails[quality].get("url")
                break

        shorts_url = cast(HttpUrl, f"https://youtube.com/shorts/{video_id}")
        media = []
        if thumbnail_url:
            media.append(
                MediaAttachment(
                    media_id=video_id,
                    media_type=MediaType.VIDEO,
                    url=shorts_url,
                    thumbnail_url=cast(HttpUrl, thumbnail_url),
                )
            )

        return Post(
            post_id=video_id,
            platform="youtube",
            content=snippet.get("title"),
            media=media,
            status=post_status,
            url=shorts_url,
            created_at=created_at,
            scheduled_at=scheduled_at,
            author_id=snippet.get("channelId"),
            author_name=snippet.get("channelTitle"),
            likes_count=int(statistics.get("likeCount", 0)),
            comments_count=int(statistics.get("commentCount", 0)),
            views_count=int(statistics.get("viewCount", 0)),
            raw_data=video,
        )

    # ── Validation ───────────────────────────────────────────────────────────

    def _validate_create_post_request(self, request: PostCreateRequest) -> None:
        if not request.media_urls:
            raise ValidationError(
                "YouTube Shorts requires at least one video URL in media_urls",
                platform="youtube",
                field="media_urls",
            )

    # ── Authentication ───────────────────────────────────────────────────────

    async def authenticate(self) -> AuthCredentials:
        """Validate the access token by fetching the authenticated user's channel."""
        if not self.api_client:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )
        try:
            response = await self.api_client.get(
                "channels",
                params={"part": "id,snippet", "mine": "true", "maxResults": "1"},
            )
            data = response.data
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise PlatformAuthError(
                    "Invalid or expired access token",
                    platform="youtube",
                    status_code=401,
                ) from e
            raise PlatformError(
                f"YouTube API error: {e.response.status_code} {e.response.text}",
                platform="youtube",
                status_code=e.response.status_code,
            ) from e
        except httpx.HTTPError as e:
            raise PlatformError(f"Network error: {e}", platform="youtube") from e

        items = data.get("items", [])
        if not items:
            raise PlatformAuthError(
                "No YouTube channel found for this account",
                platform="youtube",
            )
        channel = items[0]
        self.credentials.user_id = channel.get("id")
        self.credentials.username = channel.get("snippet", {}).get("title")
        return self.credentials

    async def refresh_token(self) -> AuthCredentials:
        """Refresh the OAuth2 access token via the factory's oauth utility."""
        from marqetive.utils.oauth import refresh_youtube_token

        if not self.credentials.refresh_token:
            raise PlatformAuthError(
                "No refresh token available — reconnect the account",
                platform="youtube",
                requires_reconnection=True,
            )
        return await refresh_youtube_token(
            self.credentials,
            client_id=self.credentials.additional_data.get("client_id", ""),
            client_secret=self.credentials.additional_data.get("client_secret", ""),
        )

    async def is_authenticated(self) -> bool:
        try:
            await self.authenticate()
            return True
        except (PlatformAuthError, PlatformError):
            return False

    # ── Post CRUD ────────────────────────────────────────────────────────────

    async def create_post(self, request: PostCreateRequest) -> Post:
        """Upload a YouTube Short and return the resulting Post.

        Required:
            request.media_urls[0]: URL or local path to the video file.

        Optional additional_data keys:
            privacy_level (str): "public" | "private" | "unlisted" (default "public")
            description (str): Video description body.
            category_id (str|int): YouTube category ID (default "22").
            made_for_kids (bool): COPPA flag (default False).
            embeddable (bool): Allow embedding (default True).
            public_stats_viewable (bool): Show public stats (default True).
            language (str): Default language code (default "en").
            schedule_time (str|int): ISO 8601 or Unix timestamp.
            notify_subscribers (bool): Notify subscribers (default True).
            is_shorts (bool): Append #Shorts to description (default True).
            tags (list[str]): Override request.tags.
        """
        self._validate_create_post_request(request)

        if self._media_manager is None:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )

        additional = request.additional_data
        metadata = build_video_metadata(
            title=request.content or "YouTube Short",
            description=additional.get("description", ""),
            tags=request.tags or additional.get("tags") or None,
            privacy_level=additional.get("privacy_level", "public"),
            category_id=additional.get("category_id", "22"),
            made_for_kids=bool(additional.get("made_for_kids", False)),
            embeddable=bool(additional.get("embeddable", True)),
            public_stats_viewable=bool(additional.get("public_stats_viewable", True)),
            language=additional.get("language", "en"),
            schedule_time=additional.get("schedule_time"),
            notify_subscribers=bool(additional.get("notify_subscribers", True)),
            is_shorts=bool(additional.get("is_shorts", True)),
        )

        video = await self._media_manager.upload_video(
            source=request.media_urls[0],
            metadata=metadata,
        )

        return self._video_to_post(video)

    async def get_post(self, post_id: str) -> Post:
        """Fetch a YouTube video by ID, scoped to the connected channel."""
        if not self.api_client:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )
        try:
            response = await self.api_client.get(
                "videos", params={"part": "snippet,status,statistics", "id": post_id}
            )
            data = response.data
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise PostNotFoundError(
                    post_id, platform="youtube", status_code=404
                ) from e
            raise PlatformError(
                f"YouTube API error: {e.response.status_code} {e.response.text}",
                platform="youtube",
                status_code=e.response.status_code,
            ) from e
        except httpx.HTTPError as e:
            raise PlatformError(f"Network error: {e}", platform="youtube") from e

        items = data.get("items", [])
        if not items:
            raise PostNotFoundError(post_id, platform="youtube", status_code=404)
        video = items[0]
        channel_id = video.get("snippet", {}).get("channelId")
        if self._channel_id and channel_id and channel_id != self._channel_id:
            raise PostNotFoundError(post_id, platform="youtube", status_code=404)
        return self._video_to_post(video)

    async def delete_post(self, post_id: str) -> bool:
        """Delete a YouTube video.

        Returns:
            True on success.

        Raises:
            PostNotFoundError: If the video does not exist.
        """
        if not self.api_client:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )
        try:
            await self.api_client.delete("videos", params={"id": post_id})
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise PostNotFoundError(
                    post_id, platform="youtube", status_code=404
                ) from e
            raise PlatformError(
                f"YouTube API error: {e.response.status_code} {e.response.text}",
                platform="youtube",
                status_code=e.response.status_code,
            ) from e
        except httpx.HTTPError as e:
            raise PlatformError(f"Network error: {e}", platform="youtube") from e
        return True

    # ── Comments ─────────────────────────────────────────────────────────────

    async def get_comments(
        self,
        post_id: str,
        limit: int = 50,
        offset: int = 0,  # noqa: ARG002
    ) -> list[Comment]:
        """Fetch top-level comment threads for a video.

        Note: YouTube's API uses cursor-based pagination, not numeric offsets.
        The *offset* parameter is accepted for interface compatibility but
        ignored; use the raw_data on the last comment for a page token.
        """
        if not self.api_client:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )
        params: dict[str, Any] = {
            "part": "snippet",
            "videoId": post_id,
            "maxResults": min(limit, 100),
            "order": "time",
        }
        try:
            response = await self.api_client.get("commentThreads", params=params)
            data = response.data
        except httpx.HTTPStatusError as e:
            raise PlatformError(
                f"YouTube API error: {e.response.status_code} {e.response.text}",
                platform="youtube",
                status_code=e.response.status_code,
            ) from e
        except httpx.HTTPError as e:
            raise PlatformError(f"Network error: {e}", platform="youtube") from e
        comments: list[Comment] = []
        for item in data.get("items", []):
            top = item.get("snippet", {}).get("topLevelComment", {})
            snippet = top.get("snippet", {})
            created_str = snippet.get("publishedAt", "")
            try:
                created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
            except ValueError:
                created_at = datetime.now(UTC)

            comments.append(
                Comment(
                    comment_id=top.get("id", item.get("id", "")),
                    post_id=post_id,
                    platform="youtube",
                    content=snippet.get("textDisplay", ""),
                    author_id=snippet.get("authorChannelId", {}).get("value", ""),
                    author_username=snippet.get("authorDisplayName"),
                    created_at=created_at,
                    likes_count=int(snippet.get("likeCount", 0)),
                    replies_count=int(
                        item.get("snippet", {}).get("totalReplyCount", 0)
                    ),
                    status=CommentStatus.VISIBLE,
                    raw_data=item,
                )
            )
        return comments

    async def create_comment(
        self,
        post_id: str,
        content: str,
        *,
        parent_comment_id: str | None = None,
    ) -> Comment:
        """Add a comment to a video.

        When parent_comment_id is provided, creates a reply to that comment
        using the ``comments`` resource. Otherwise creates a top-level thread
        using ``commentThreads``.
        """
        if not self.api_client:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )
        if parent_comment_id:
            body = {
                "snippet": {
                    "parentId": parent_comment_id,
                    "textOriginal": content,
                }
            }
            try:
                response = await self.api_client.post("comments?part=snippet", body)
                item = response.data
            except httpx.HTTPStatusError as e:
                raise PlatformError(
                    f"YouTube API error: {e.response.status_code} {e.response.text}",
                    platform="youtube",
                    status_code=e.response.status_code,
                ) from e
            except httpx.HTTPError as e:
                raise PlatformError(f"Network error: {e}", platform="youtube") from e
            snippet = item.get("snippet", {})
            created_str = snippet.get("publishedAt", "")
            try:
                created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
            except ValueError:
                created_at = datetime.now(UTC)
            return Comment(
                comment_id=item.get("id", ""),
                post_id=post_id,
                platform="youtube",
                content=snippet.get("textDisplay", content),
                author_id=snippet.get("authorChannelId", {}).get("value", ""),
                author_username=snippet.get("authorDisplayName"),
                parent_comment_id=parent_comment_id,
                created_at=created_at,
                raw_data=item,
            )

        body = {
            "snippet": {
                "videoId": post_id,
                "topLevelComment": {"snippet": {"textOriginal": content}},
            }
        }
        try:
            response = await self.api_client.post("commentThreads?part=snippet", body)
            item = response.data
        except httpx.HTTPStatusError as e:
            raise PlatformError(
                f"YouTube API error: {e.response.status_code} {e.response.text}",
                platform="youtube",
                status_code=e.response.status_code,
            ) from e
        except httpx.HTTPError as e:
            raise PlatformError(f"Network error: {e}", platform="youtube") from e
        top = item.get("snippet", {}).get("topLevelComment", {})
        snippet = top.get("snippet", {})
        created_str = snippet.get("publishedAt", "")
        try:
            created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
        except ValueError:
            created_at = datetime.now(UTC)
        return Comment(
            comment_id=top.get("id", item.get("id", "")),
            post_id=post_id,
            platform="youtube",
            content=snippet.get("textDisplay", content),
            author_id=snippet.get("authorChannelId", {}).get("value", ""),
            author_username=snippet.get("authorDisplayName"),
            created_at=created_at,
            raw_data=item,
        )

    async def delete_comment(
        self,
        comment_id: str,
        *,
        post_id: str | None = None,  # noqa: ARG002
    ) -> bool:
        """Delete a comment by its ID."""
        if not self.api_client:
            raise PlatformError(
                "Client must be used as async context manager", "youtube"
            )
        try:
            await self.api_client.delete("comments", params={"id": comment_id})
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise PostNotFoundError(
                    comment_id, platform="youtube", status_code=404
                ) from e
            raise PlatformError(
                f"YouTube API error: {e.response.status_code} {e.response.text}",
                platform="youtube",
                status_code=e.response.status_code,
            ) from e
        except httpx.HTTPError as e:
            raise PlatformError(f"Network error: {e}", platform="youtube") from e
        return True

    async def update_post(self, post_id: str, request: PostUpdateRequest) -> Post:  # noqa: ARG002
        """Update a YouTube Short's metadata.

        Note: YouTube does not support updating video files or changing privacy
        from public to private. This method only updates title, description,
        tags, and other mutable metadata fields.
        """
        raise PlatformError(
            "YouTube API does not support updating videos after publishing.",
            self.platform_name,
        )

    # ── Media ────────────────────────────────────────────────────────────────

    async def upload_media(
        self,
        media_url: str,
        media_type: str,  # noqa: ARG002
        alt_text: str | None = None,
    ) -> MediaAttachment:
        """Download a media file and return a MediaAttachment.

        Note: YouTube does not have a standalone media upload endpoint separate
        from video creation. This method downloads the file locally and returns
        metadata so callers can pass the path to create_post.
        """
        file_path = await download_file(media_url)
        file_size = os.path.getsize(file_path)
        return MediaAttachment(
            media_id=file_path,
            media_type=MediaType.VIDEO,
            url=cast(HttpUrl, media_url),
            size_bytes=file_size,
            alt_text=alt_text,
        )
