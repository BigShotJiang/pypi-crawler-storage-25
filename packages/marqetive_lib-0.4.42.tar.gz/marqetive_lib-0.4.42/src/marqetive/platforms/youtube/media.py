"""YouTube Shorts media manager for resumable video uploads.

YouTube uses a resumable upload protocol:
1. Initiate: POST metadata → receive upload URI
2. Upload: PUT chunks to upload URI → receive video resource on completion
3. Resume: Query upload URI with empty PUT to get byte position after interruption
"""

import asyncio
import json
import logging
import os
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any

import aiofiles
import httpx

from marqetive.core.exceptions import MediaUploadError, ValidationError
from marqetive.core.models import ProgressEvent, ProgressStatus
from marqetive.utils.file_handlers import TempFileManager, download_file
from marqetive.utils.media import detect_mime_type

logger = logging.getLogger(__name__)

YOUTUBE_UPLOAD_BASE = "https://www.googleapis.com/upload/youtube/v3/videos"
YOUTUBE_API_BASE = "https://www.googleapis.com/youtube/v3"

# 8MB chunks — must be a multiple of 256KB per Google's requirement
DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024
MAX_UPLOAD_RETRIES = 3

type SyncProgressCallback = Callable[[ProgressEvent], None]
type AsyncProgressCallback = Callable[[ProgressEvent], Awaitable[None]]
type ProgressCallback = SyncProgressCallback | AsyncProgressCallback

_VALID_PRIVACY = frozenset({"public", "private", "unlisted"})


def _to_rfc3339(value: str | int | float) -> str:
    """Convert a Unix timestamp or ISO 8601 string to RFC 3339 format."""
    if isinstance(value, (int, float)):
        dt = datetime.fromtimestamp(value, tz=UTC)
    else:
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def build_video_metadata(
    *,
    title: str,
    description: str = "",
    tags: list[str] | None = None,
    privacy_level: str = "public",
    category_id: str | int = "22",
    made_for_kids: bool = False,
    embeddable: bool = True,
    public_stats_viewable: bool = True,
    language: str = "en",
    schedule_time: str | int | float | None = None,
    notify_subscribers: bool = True,
    is_shorts: bool = True,
) -> dict[str, Any]:
    """Build a YouTube video metadata resource dict.

    Args:
        title: Video title (max 100 chars).
        description: Video description (max 5000 chars).
        tags: List of tags.
        privacy_level: "public", "private", or "unlisted".
        category_id: YouTube category ID (default "22" = People & Blogs).
        made_for_kids: COPPA compliance flag.
        embeddable: Allow embedding on other sites.
        public_stats_viewable: Show public statistics.
        language: Default language code.
        schedule_time: ISO 8601 string or Unix timestamp for scheduling.
        notify_subscribers: Notify channel subscribers on publish.
        is_shorts: Append #Shorts to description if not present.

    Returns:
        YouTube video resource dict with snippet and status sections.
    """
    privacy = privacy_level.lower()
    if privacy not in _VALID_PRIVACY:
        raise ValidationError(
            f"Invalid privacy_level '{privacy_level}'. Must be one of: {', '.join(sorted(_VALID_PRIVACY))}",
            platform="youtube",
            field="privacy_level",
        )

    desc = description
    if is_shorts and "#Shorts" not in desc and "#shorts" not in desc:
        desc = (desc + "\n\n#Shorts").strip()

    snippet: dict[str, Any] = {
        "title": title[:100],
        "description": desc[:5000],
        "categoryId": str(category_id),
        "defaultLanguage": language,
    }
    if tags:
        snippet["tags"] = tags

    status: dict[str, Any] = {
        "privacyStatus": privacy,
        "selfDeclaredMadeForKids": made_for_kids,
        "embeddable": embeddable,
        "publicStatsViewable": public_stats_viewable,
        "madeForKids": made_for_kids,
    }

    if schedule_time is not None:
        status["privacyStatus"] = "private"
        status["publishAt"] = _to_rfc3339(schedule_time)

    return {
        "snippet": snippet,
        "status": status,
        "notifySubscribers": notify_subscribers,
    }


class YouTubeShortsMediaManager:
    """Handles resumable video uploads to YouTube Data API v3.

    Args:
        access_token: OAuth2 Bearer token.
        timeout: HTTP request timeout in seconds.
        chunk_size: Upload chunk size in bytes (must be multiple of 256KB).
        progress_callback: Optional progress callback.
    """

    def __init__(
        self,
        access_token: str,
        *,
        timeout: float = 300.0,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        self._access_token = access_token
        self._timeout = timeout
        self._chunk_size = chunk_size
        self._progress_callback = progress_callback

    async def _emit_progress(
        self,
        operation: str,
        status: ProgressStatus,
        progress: int,
        total: int,
        message: str | None = None,
        *,
        bytes_uploaded: int | None = None,
        total_bytes: int | None = None,
    ) -> None:
        if self._progress_callback is None:
            return
        import inspect

        event = ProgressEvent(
            operation=operation,
            platform="youtube",
            status=status,
            progress=progress,
            total=total,
            message=message,
            bytes_uploaded=bytes_uploaded,
            total_bytes=total_bytes,
        )
        result = self._progress_callback(event)
        if inspect.iscoroutine(result):
            await result

    async def upload_video(
        self,
        source: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        """Upload a video file or URL to YouTube.

        Args:
            source: Local file path or HTTPS URL.
            metadata: Video resource dict from build_video_metadata().

        Returns:
            YouTube video resource with ``id``, ``snippet``, and ``status``.

        Raises:
            MediaUploadError: If upload fails after retries.
            ValidationError: If source is invalid.
        """
        await self._emit_progress(
            "upload_video", ProgressStatus.INITIALIZING, 0, 100, "Preparing upload"
        )

        async with TempFileManager() as tmp:
            if source.startswith("http://") or source.startswith("https://"):
                await self._emit_progress(
                    "upload_video",
                    ProgressStatus.INITIALIZING,
                    5,
                    100,
                    "Downloading video",
                )
                file_path = tmp.create("youtube_")
                file_path = await download_file(source, destination=file_path)
            else:
                file_path = source

            if not os.path.exists(file_path):
                raise ValidationError(
                    f"Video file not found: {file_path}",
                    platform="youtube",
                    field="source",
                )

            file_size = os.path.getsize(file_path)
            mime_type = detect_mime_type(file_path)

            await self._emit_progress(
                "upload_video",
                ProgressStatus.UPLOADING,
                10,
                100,
                "Initiating resumable upload",
            )

            upload_uri = await self._initiate_resumable_upload(
                file_size=file_size,
                metadata=metadata,
                mime_type=mime_type,
            )

            video = await self._upload_chunks(
                upload_uri=upload_uri,
                file_path=file_path,
                file_size=file_size,
                mime_type=mime_type,
            )

        await self._emit_progress(
            "upload_video", ProgressStatus.COMPLETED, 100, 100, "Upload complete"
        )
        return video

    async def _initiate_resumable_upload(
        self,
        file_size: int,
        metadata: dict[str, Any],
        mime_type: str,
    ) -> str:
        """Initiate a resumable upload and return the upload URI.

        Args:
            file_size: Total file size in bytes.
            metadata: Video resource dict.
            mime_type: MIME type of the video.

        Returns:
            Upload URI from the Location response header.

        Raises:
            MediaUploadError: If initiation fails.
        """
        headers = {
            "Authorization": f"Bearer {self._access_token}",
            "Content-Type": "application/json",
            "X-Upload-Content-Type": mime_type,
            "X-Upload-Content-Length": str(file_size),
        }

        params = {"uploadType": "resumable", "part": "snippet,status"}

        # notifySubscribers lives at the query param level, not in the body
        notify = metadata.pop("notifySubscribers", True)
        params["notifySubscribers"] = "true" if notify else "false"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    YOUTUBE_UPLOAD_BASE,
                    headers=headers,
                    params=params,
                    content=json.dumps(metadata).encode(),
                )
                response.raise_for_status()

            location = response.headers.get("Location") or response.headers.get(
                "location"
            )
            if not location:
                raise MediaUploadError(
                    "No Location header in resumable upload initiation response",
                    platform="youtube",
                    media_type="video",
                )
            return location

        except httpx.HTTPStatusError as e:
            raise MediaUploadError(
                f"Failed to initiate upload: {e.response.status_code} {e.response.text}",
                platform="youtube",
                media_type="video",
            ) from e
        except httpx.HTTPError as e:
            raise MediaUploadError(
                f"Network error initiating upload: {e}",
                platform="youtube",
                media_type="video",
            ) from e

    async def _get_resume_position(self, upload_uri: str, file_size: int) -> int:
        """Query the upload URI to find how many bytes were received.

        Args:
            upload_uri: The resumable upload URI.
            file_size: Total file size in bytes.

        Returns:
            Number of bytes already uploaded (0 if none).
        """
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.put(
                    upload_uri,
                    headers={
                        "Authorization": f"Bearer {self._access_token}",
                        "Content-Range": f"bytes */{file_size}",
                        "Content-Length": "0",
                    },
                    content=b"",
                )
            if response.status_code == 308:
                range_header = response.headers.get("Range") or response.headers.get(
                    "range"
                )
                if range_header:
                    # Range: bytes=0-N  →  N+1 bytes received
                    return int(range_header.split("-")[1]) + 1
            return 0
        except Exception:
            return 0

    async def _upload_chunks(
        self,
        upload_uri: str,
        file_path: str,
        file_size: int,
        mime_type: str,
    ) -> dict[str, Any]:
        """Upload the video file in chunks to the upload URI.

        Retries on transient errors, resuming from the last confirmed position.

        Args:
            upload_uri: Resumable upload URI from initiation.
            file_path: Local path to the video file.
            file_size: Total file size in bytes.
            mime_type: MIME type of the video.

        Returns:
            YouTube video resource dict.

        Raises:
            MediaUploadError: If upload fails after MAX_UPLOAD_RETRIES attempts.
        """
        offset = 0
        attempts = 0

        while attempts < MAX_UPLOAD_RETRIES:
            try:
                async with aiofiles.open(file_path, "rb") as f:
                    await f.seek(offset)

                    while offset < file_size:
                        chunk = await f.read(self._chunk_size)
                        if not chunk:
                            break

                        end = offset + len(chunk) - 1
                        headers = {
                            "Authorization": f"Bearer {self._access_token}",
                            "Content-Length": str(len(chunk)),
                            "Content-Range": f"bytes {offset}-{end}/{file_size}",
                            "Content-Type": mime_type,
                        }

                        async with httpx.AsyncClient(
                            timeout=self._timeout
                        ) as http_client:
                            response = await http_client.put(
                                upload_uri,
                                headers=headers,
                                content=chunk,
                            )

                        if response.status_code in (200, 201):
                            return response.json()

                        if response.status_code == 308:
                            # Chunk accepted, advance offset
                            range_header = response.headers.get(
                                "Range"
                            ) or response.headers.get("range")
                            if range_header:
                                offset = int(range_header.split("-")[1]) + 1
                            else:
                                offset += len(chunk)

                            pct = int((offset / file_size) * 90) + 10
                            await self._emit_progress(
                                "upload_video",
                                ProgressStatus.UPLOADING,
                                pct,
                                100,
                                f"Uploaded {offset}/{file_size} bytes",
                                bytes_uploaded=offset,
                                total_bytes=file_size,
                            )
                            continue

                        # Retriable server errors
                        if response.status_code in (500, 502, 503, 504):
                            raise httpx.HTTPStatusError(
                                f"Server error {response.status_code}",
                                request=response.request,
                                response=response,
                            )

                        # Non-retriable error
                        raise MediaUploadError(
                            f"Unexpected upload response: {response.status_code} {response.text}",
                            platform="youtube",
                            media_type="video",
                        )

                # If we exited the while loop without returning, something is off
                raise MediaUploadError(
                    "Upload loop completed without receiving a final video resource",
                    platform="youtube",
                    media_type="video",
                )

            except (httpx.HTTPStatusError, httpx.HTTPError) as e:
                attempts += 1
                if attempts >= MAX_UPLOAD_RETRIES:
                    raise MediaUploadError(
                        f"Upload failed after {MAX_UPLOAD_RETRIES} attempts: {e}",
                        platform="youtube",
                        media_type="video",
                    ) from e

                logger.warning(
                    "Upload chunk error (attempt %d/%d): %s — resuming",
                    attempts,
                    MAX_UPLOAD_RETRIES,
                    e,
                )
                await asyncio.sleep(2**attempts)
                offset = await self._get_resume_position(upload_uri, file_size)

        raise MediaUploadError(
            "Upload failed: exhausted retries",
            platform="youtube",
            media_type="video",
        )
