"""Article related command."""

from __future__ import annotations

import re
from typing import Any

import click
from rich.table import Table

from .. import payloads
from ..exceptions import ZhihuError
from . import common


@click.command(name="article")
@click.argument("id_or_url")
@common.structured_output_options
def article_cmd(id_or_url: str, as_json: bool, as_yaml: bool):
    """查看文章详情。

    ID_OR_URL 可以是文章 ID 或知乎专栏 URL。
    """
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)

    try:
        article_id = client.extract_article_id(id_or_url)
    except ZhihuError as e:
        common.exit_error(f"解析文章 ID 失败: {e}", code="invalid_input")
    cred = common.get_credential(mode="optional")
    info = common.run_or_exit(client.get_article(article_id, credential=cred), "获取文章详情失败")

    cm_data = common.run_optional(
        client.get_comments("articles", article_id, credential=cred),
        "获取评论失败",
    )
    comment_items = cm_data.get("data", []) if cm_data else []

    structured: dict[str, Any] = {
        "article": payloads.normalize_article(info),
    }
    if comment_items:
        structured["comments"] = [payloads.normalize_comment(c) for c in comment_items]
    if common.emit_structured(structured, output_format):
        return

    # Rich output
    author = info.get("author", {})
    column = info.get("column", {})
    content_raw = info.get("content", "")
    content_clean = re.sub(r"<[^>]+>", "", content_raw) if content_raw else ""

    table = Table(title=f"📰 {info.get('title', '')}", show_header=False, border_style="blue")
    table.add_column("Field", style="bold cyan", width=12)
    table.add_column("Value", no_wrap=False, overflow="fold")

    table.add_row("ID", str(article_id))
    table.add_row("标题", info.get("title", ""))
    table.add_row("作者", author.get("name", ""))
    if column and column.get("name"):
        table.add_row("专栏", column.get("name", ""))
    table.add_row("赞同", common.format_count(info.get("voteup_count", 0)))
    table.add_row("评论数", str(info.get("comment_count", 0)))
    if content_clean:
        table.add_row("内容", content_clean)
    table.add_row("链接", f"https://zhuanlan.zhihu.com/p/{article_id}")

    common.console.print(table)

    if comment_items:
        common.console.print("\n[bold]💬 评论:[/bold]\n")
        for c in comment_items[:10]:
            raw_ca = c.get("author", {})
            ca = raw_ca.get("member", raw_ca) if isinstance(raw_ca, dict) else {}
            cc = c.get("content", "")
            likes = c.get("like_count") or c.get("vote_count") or c.get("voteup_count", 0)
            common.console.print(f"  [cyan]{ca.get('name', '')}[/cyan]  [dim](👍 {likes})[/dim]")
            common.console.print(f"  {re.sub(r'<[^>]+>', '', cc)[:120]}")
            common.console.print()
