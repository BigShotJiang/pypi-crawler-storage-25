"""Pin (想法) related commands."""

from __future__ import annotations

import re

import click
from rich.table import Table

from .. import payloads
from ..exceptions import ZhihuError
from . import common


@click.command(name="pin")
@click.argument("id_or_url")
@common.structured_output_options
def pin_cmd(id_or_url: str, as_json: bool, as_yaml: bool):
    """查看想法详情。

    ID_OR_URL 可以是想法 ID 或知乎想法 URL。
    """
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)

    try:
        pin_id = client.extract_pin_id(id_or_url)
    except ZhihuError as e:
        common.exit_error(f"解析想法 ID 失败: {e}", code="invalid_input")
    cred = common.get_credential(mode="optional")
    info = common.run_or_exit(client.get_pin(pin_id, credential=cred), "获取想法详情失败")

    cm_data = common.run_optional(
        client.get_pin_comments(pin_id, credential=cred),
        "获取评论失败",
    )
    comment_items = cm_data.get("data", []) if cm_data else []

    structured: dict = {
        "pin": payloads.normalize_pin(info),
    }
    if comment_items:
        structured["comments"] = [payloads.normalize_comment(c) for c in comment_items]
    if common.emit_structured(structured, output_format):
        return

    # Rich output
    author = info.get("author", {})
    content_parts = info.get("content", [])
    if isinstance(content_parts, list):
        text = " ".join(
            re.sub(r"<[^>]+>", "", p.get("content", ""))
            for p in content_parts
            if p.get("type") == "text"
        )
    else:
        text = re.sub(r"<[^>]+>", "", str(content_parts))

    table = Table(title="💡 想法详情", show_header=False, border_style="blue")
    table.add_column("Field", style="bold cyan", width=12)
    table.add_column("Value", no_wrap=False, overflow="fold")

    table.add_row("ID", str(pin_id))
    table.add_row("作者", author.get("name", ""))
    table.add_row("赞同", common.format_count(info.get("like_count", 0)))
    table.add_row("评论数", str(info.get("comment_count", 0)))
    if info.get("repin_count"):
        table.add_row("转发", str(info.get("repin_count", 0)))
    tags = info.get("tags")
    if isinstance(tags, list) and tags:
        table.add_row("标签", " ".join(tags))
    if text:
        table.add_row("内容", text)
    table.add_row("链接", f"https://www.zhihu.com/pin/{pin_id}")

    common.console.print(table)

    if comment_items:
        common.console.print("\n[bold]💬 评论:[/bold]\n")
        for c in comment_items[:10]:
            raw_ca = c.get("author", {})
            ca = raw_ca.get("member", raw_ca) if isinstance(raw_ca, dict) else {}
            cc = c.get("content", "")
            likes = c.get("vote_count") or c.get("voteup_count", 0)
            common.console.print(f"  [cyan]{ca.get('name', '')}[/cyan]  [dim](👍 {likes})[/dim]")
            common.console.print(f"  {re.sub(r'<[^>]+>', '', cc)[:120]}")
            common.console.print()
