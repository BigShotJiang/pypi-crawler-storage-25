"""Answer related command."""

from __future__ import annotations

import re
from typing import Any

import click
from rich.table import Table

from .. import payloads
from ..exceptions import ZhihuError
from . import common


@click.command(name="answer")
@click.argument("id_or_url")
@common.structured_output_options
def answer_cmd(id_or_url: str, as_json: bool, as_yaml: bool):
    """查看回答详情。

    ID_OR_URL 可以是回答 ID 或知乎 URL。
    """
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)

    try:
        answer_id = client.extract_answer_id(id_or_url)
    except ZhihuError as e:
        common.exit_error(f"解析回答 ID 失败: {e}", code="invalid_input")
    cred = common.get_credential(mode="optional")
    info = common.run_or_exit(client.get_answer(answer_id, credential=cred), "获取回答详情失败")

    cm_data = common.run_optional(
        client.get_comments("answers", answer_id, credential=cred),
        "获取评论失败",
    )
    comment_items = cm_data.get("data", []) if cm_data else []

    structured: dict[str, Any] = {
        "answer": payloads.normalize_answer(info),
    }
    if comment_items:
        structured["comments"] = [payloads.normalize_comment(c) for c in comment_items]
    if common.emit_structured(structured, output_format):
        return

    # Rich output
    author = info.get("author", {})
    question = info.get("question", {})
    content_raw = info.get("content", "")
    content_clean = re.sub(r"<[^>]+>", "", content_raw) if content_raw else ""

    table = Table(title="💬 回答详情", show_header=False, border_style="blue")
    table.add_column("Field", style="bold cyan", width=12)
    table.add_column("Value", no_wrap=False, overflow="fold")

    table.add_row("ID", str(answer_id))
    table.add_row("作者", author.get("name", ""))
    table.add_row("问题", question.get("title", ""))
    table.add_row("赞同", common.format_count(info.get("voteup_count", 0)))
    table.add_row("评论数", str(info.get("comment_count", 0)))
    if content_clean:
        table.add_row("内容", content_clean)
    table.add_row("链接", f"https://www.zhihu.com/question/{question.get('id', '')}/answer/{answer_id}")

    common.console.print(table)

    if comment_items:
        common.console.print("\n[bold]💬 评论:[/bold]\n")
        for c in comment_items[:10]:
            raw_ca = c.get("author", {})
            ca = raw_ca.get("member", raw_ca) if isinstance(raw_ca, dict) else {}
            cc = c.get("content", "")
            likes = c.get("vote_count") or c.get("voteup_count", 0)
            common.console.print(f"  [cyan]{ca.get('name', '')}[/cyan]  [dim](👍 {likes})[/dim]")
            common.console.print(f"  {re.sub(r'<[^>]+>', '', cc)[:120]}")
            common.console.print()
