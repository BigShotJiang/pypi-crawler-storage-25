"""Shared helpers for CLI command modules."""

from __future__ import annotations

import logging
import sys

import click

from .. import auth
from ..exceptions import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ZhihuError,
)
from ..formatter import (  # noqa: F401
    OutputFormat,
    _to_int,
    console,
    emit_or_print,
    emit_structured,
    error_payload,
    exit_error,
    format_count,
    resolve_output_format,
    structured_output_options,
    success_payload,
)


def setup_logging(verbose: bool):
    """Configure global logging based on CLI verbosity."""
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(level=level, format="%(name)s: %(message)s")


def run(coro):
    """Bridge async coroutine into synchronous click command."""
    import asyncio
    return asyncio.run(coro)


def run_or_exit(coro, action: str):
    """Run async call and convert unexpected errors to CLI-friendly failures."""
    try:
        return run(coro)
    except AuthenticationError as e:
        exit_error(f"{action}: {e}", code="not_authenticated")
    except RateLimitError as e:
        exit_error(f"{action}: {e}", code="rate_limited")
    except NotFoundError as e:
        exit_error(f"{action}: {e}", code="not_found")
    except NetworkError as e:
        exit_error(f"{action}: {e}", code="network_error")
    except ZhihuError as e:
        exit_error(f"{action}: {e}", code="upstream_error")
    except Exception as e:
        exit_error(f"{action}: {e}", code="internal_error")


def get_credential(mode: auth.AuthMode = "read"):
    """Read credential from configured auth strategy."""
    return auth.get_credential(mode=mode)


def clear_credential():
    """Remove saved credential."""
    return auth.clear_credential()


def print_login_required(message: str | None = None):
    """Print a standard login-required warning message."""
    if message:
        console.print(f"[yellow]⚠️  {message}[/yellow]")
        return
    console.print("[yellow]⚠️  需要登录。使用 [bold]zhihu login[/bold] 登录。[/yellow]")


def require_login(require_write: bool = False, message: str | None = None):
    """Require login credential and optional write capability."""
    mode: auth.AuthMode = "write" if require_write else "read"
    cred = get_credential(mode=mode)
    if cred:
        return cred

    ctx = click.get_current_context(silent=True)
    params = ctx.params if ctx is not None else {}
    output_format = resolve_output_format(
        as_json=bool(params.get("as_json", False)),
        as_yaml=bool(params.get("as_yaml", False)),
    )
    error_message = message or "未登录。使用 zhihu login 登录。"
    if emit_structured(error_payload("not_authenticated", error_message), output_format):
        sys.exit(1)
    print_login_required(message)
    sys.exit(1)


def run_optional(coro, action: str):
    """Run optional sub-request and print warning on failure."""
    try:
        return run(coro)
    except ZhihuError as e:
        console.print(f"[yellow]⚠️  {action}: {e}[/yellow]")
    except Exception as e:
        console.print(f"[yellow]⚠️  {action}: {e}[/yellow]")
    return None
