"""Account and authentication related commands."""

from __future__ import annotations

import sys

import click
from rich.panel import Panel

from .. import payloads
from . import common


@click.command()
@click.option("--z-c0", prompt="z_c0 cookie", help="Zhihu z_c0 cookie value.")
@click.option("--xsrf-token", prompt=False, default="", help="xsrf_token (optional).")
@click.option("--xsrf", prompt=False, default="", help="_xsrf cookie (optional).")
def login(z_c0: str, xsrf_token: str, xsrf: str):
    """登录 Zhihu（手动输入 Cookie）。"""
    from .. import auth

    if not z_c0.strip():
        common.exit_error("z_c0 不能为空")

    try:
        auth.manual_login(z_c0=z_c0, xsrf_token=xsrf_token, _xsrf=xsrf)
        common.console.print("[green]✅ 登录成功！凭证已保存[/green]")
    except Exception as e:
        common.exit_error(f"登录失败: {e}")


@click.command()
def logout():
    """注销并清除保存的凭证。"""
    common.clear_credential()
    common.console.print("[green]✅ 已注销，凭证已清除[/green]")
    common.console.print("[dim]提示：浏览器 Cookie 仍可能自动生效，如需彻底退出请在浏览器中注销知乎。[/dim]")


@click.command()
@common.structured_output_options
def status(as_json: bool, as_yaml: bool):
    """检查登录状态。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)
    cred = common.get_credential(mode="read")
    if not cred:
        payload = common.error_payload("not_authenticated", "未登录。使用 zhihu login 登录。")
        if common.emit_structured(payload, output_format):
            raise SystemExit(1) from None
        common.print_login_required("未登录。使用 [bold]zhihu login[/bold] 登录。")
        sys.exit(1)

    try:
        info = common.run(client.get_self_info(cred))
    except Exception as exc:
        payload = common.error_payload("api_error", f"检查登录状态失败: {exc}")
        if common.emit_structured(payload, output_format):
            raise SystemExit(1) from None
        common.exit_error(f"检查登录状态失败: {exc}")

    payload = common.success_payload(
        {
            "authenticated": True,
            "user": payloads.normalize_user(info),
        }
    )

    def render() -> None:
        name = info.get("name", "unknown")
        uid = info.get("url_token", info.get("id", "unknown"))
        common.console.print(f"[green]✅ 已登录：[bold]{name}[/bold]  ({uid})[/green]")

    if common.emit_or_print(payload, output_format, render):
        return


@click.command()
@common.structured_output_options
def whoami(as_json: bool, as_yaml: bool):
    """查看当前登录用户的详细信息。"""
    from .. import client

    output_format = common.resolve_output_format(as_json=as_json, as_yaml=as_yaml)

    cred = common.get_credential(mode="read")
    if not cred:
        payload = common.error_payload("not_authenticated", "未登录。使用 zhihu login 登录。")
        if common.emit_structured(payload, output_format):
            raise SystemExit(1) from None
        common.print_login_required("未登录。使用 [bold]zhihu login[/bold] 登录。")
        sys.exit(1)

    try:
        me = common.run(client.get_self_info(cred))
    except Exception as exc:
        payload = common.error_payload("api_error", f"获取用户信息失败: {exc}")
        if common.emit_structured(payload, output_format):
            raise SystemExit(1) from None
        common.exit_error(f"获取用户信息失败: {exc}")

    url_token = me.get("url_token", "")
    # /api/v4/me lacks follower/following counts; fetch full profile
    if url_token:
        try:
            info = common.run(client.get_user_info(url_token, credential=cred))
        except Exception:
            info = me
    else:
        info = me

    payload = common.success_payload({"user": payloads.normalize_user(info)})

    def render() -> None:
        name = info.get("name", "unknown")
        headline = info.get("headline", "")
        follower = info.get("follower_count", 0)
        following = info.get("following_count", 0)
        answer_count = info.get("answer_count", 0)
        article_count = info.get("articles_count", 0)
        question_count = info.get("question_count", 0)
        pins_count = info.get("pins_count", 0)
        columns_count = info.get("columns_count", 0)
        favorite_count = info.get("favorite_count", 0)

        lines = [
            f"👤 [bold]{name}[/bold]  ({url_token})",
            f"👥 粉丝 {common.format_count(follower)}  |  🔔 关注 {common.format_count(following)}",
            f"💬 回答 {answer_count}  |  📰 文章 {article_count}  |  ❓ 提问 {question_count}",
            f"💡 想法 {pins_count}  |  📚 专栏 {columns_count}  |  ⭐ 收藏 {favorite_count}",
        ]
        if headline:
            lines.append(f"📝 {headline}")

        common.console.print(Panel(
            "\n".join(lines),
            title="个人信息",
            border_style="green",
        ))

    if common.emit_or_print(payload, output_format, render):
        return
