"""CLI entry point for zhihu-cli.

Usage:
    zhihu login / logout / status / whoami
    zhihu question <ID或URL> [--answers] [--comments]
    zhihu answer <ID或URL> [--comments]
    zhihu article <ID或URL> [--comments]
    zhihu search <关键词> [--type content|question|people|article|answer]
    zhihu user <url_token>
    zhihu user-answers <url_token>
    zhihu user-articles <url_token>
    zhihu hot
    zhihu favorites / following / collections / feed
    zhihu vote <type> <ID>
    zhihu follow <type> <ID>
    zhihu unfollow <type> <ID>
"""

from __future__ import annotations

import click

from . import __version__
from .commands import (
    account,
    answer,
    article,
    collections,
    common,
    discovery,
    interactions,
    pin,
    question,
    search,
    user,
)


@click.group()
@click.version_option(version=__version__, prog_name="zhihu")
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
def cli(verbose: bool):
    """zhihu — Zhihu CLI tool"""
    common.setup_logging(verbose)


# Account
cli.add_command(account.login)
cli.add_command(account.logout)
cli.add_command(account.status)
cli.add_command(account.whoami)

# Content
cli.add_command(question.question_cmd)
cli.add_command(answer.answer_cmd)
cli.add_command(article.article_cmd)
cli.add_command(pin.pin_cmd)

# User
cli.add_command(user.user_cmd)
cli.add_command(user.user_answers)
cli.add_command(user.user_articles)
cli.add_command(user.user_pins)

# Search
cli.add_command(search.search_cmd)

# Discovery
cli.add_command(discovery.hot_cmd)

# Collections
cli.add_command(collections.favorites)
cli.add_command(collections.following_cmd)
cli.add_command(collections.collections_cmd)
cli.add_command(collections.feed)

# Interactions
cli.add_command(interactions.vote_cmd)
cli.add_command(interactions.follow_cmd)
cli.add_command(interactions.unfollow_cmd)


if __name__ == "__main__":
    cli()
