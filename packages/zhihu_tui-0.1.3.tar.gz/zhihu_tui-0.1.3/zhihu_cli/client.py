"""Zhihu API client — async wrappers around Zhihu REST APIs.

All public functions are async and accept an optional ZhihuCredential for
authenticated operations.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

import aiohttp

from .auth import ZhihuCredential
from .exceptions import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ZhihuError,
)

logger = logging.getLogger(__name__)

_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/133.0.0.0 Safari/537.36"
)

_BASE_HEADERS = {
    "User-Agent": _USER_AGENT,
    "Referer": "https://www.zhihu.com",
    "Origin": "https://www.zhihu.com",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
}


def _build_headers(credential: ZhihuCredential | None = None) -> dict[str, str]:
    """Build request headers, optionally including auth cookies."""
    headers = dict(_BASE_HEADERS)
    if credential:
        cookie_str = credential.as_cookie_header()
        if cookie_str:
            headers["Cookie"] = cookie_str
        if credential._xsrf:
            headers["x-xsrftoken"] = credential._xsrf
        # x-zse-93 只有配合 x-zse-96 签名时才发送，否则会导致 API 返回空数据
    return headers


def _map_api_error(action: str, exc: Exception) -> ZhihuError:
    """Map HTTP/API exceptions into stable local exception types."""
    if isinstance(exc, ZhihuError):
        return exc

    if isinstance(exc, aiohttp.ClientResponseError):
        status = exc.status
        if status in (401, 403):
            return AuthenticationError(f"{action}: HTTP {status}")
        if status == 404:
            return NotFoundError(f"{action}: HTTP 404")
        if status == 429:
            return RateLimitError(f"{action}: HTTP 429")
        return ZhihuError(f"{action}: HTTP {status}")

    if isinstance(exc, (aiohttp.ClientError, asyncio.TimeoutError)):
        return NetworkError(f"{action}: {exc}")

    return ZhihuError(f"{action}: {exc}")


async def _request(
    method: str,
    url: str,
    *,
    credential: ZhihuCredential | None = None,
    params: dict[str, Any] | None = None,
    json_data: dict[str, Any] | None = None,
    action: str = "",
) -> Any:
    """Make an HTTP request and normalize errors."""
    headers = _build_headers(credential)

    timeout = aiohttp.ClientTimeout(total=30)

    try:
        async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
            async with session.request(
                method, url, params=params, json=json_data
            ) as resp:
                if resp.status == 204:
                    return {}
                data = await resp.json(content_type=None)
                if isinstance(data, dict) and data.get("error"):
                    error_msg = data.get("error", {}).get("message", str(data))
                    error_code = data.get("error", {}).get("code", "")
                    if resp.status in (401, 403) or "authenticate" in str(error_code).lower():
                        raise AuthenticationError(f"{action}: {error_msg}")
                    if resp.status == 404:
                        raise NotFoundError(f"{action}: {error_msg}")
                    raise ZhihuError(f"{action}: [{error_code}] {error_msg}")
                return data
    except ZhihuError:
        raise
    except Exception as exc:
        raise _map_api_error(action or url, exc) from exc


async def _get(
    url: str,
    *,
    credential: ZhihuCredential | None = None,
    params: dict[str, Any] | None = None,
    action: str = "",
) -> Any:
    return await _request("GET", url, credential=credential, params=params, action=action)


async def _post(
    url: str,
    *,
    credential: ZhihuCredential | None = None,
    json_data: dict[str, Any] | None = None,
    action: str = "",
) -> Any:
    return await _request("POST", url, credential=credential, json_data=json_data, action=action)


async def _delete(
    url: str,
    *,
    credential: ZhihuCredential | None = None,
    params: dict[str, Any] | None = None,
    action: str = "",
) -> Any:
    return await _request("DELETE", url, credential=credential, params=params, action=action)


# ---------------------------------------------------------------------------
# Content ID helpers
# ---------------------------------------------------------------------------

_QUESTION_ID_RE = re.compile(r"/question/(\d+)")
_ANSWER_ID_RE = re.compile(r"/answer/(\d+)")
_ARTICLE_ID_RE = re.compile(r"/(?:p|article)/(\d+)")


def extract_question_id(url_or_id: str) -> int:
    """Extract question ID from URL or return as-is if numeric."""
    if url_or_id.isdigit():
        return int(url_or_id)
    match = _QUESTION_ID_RE.search(url_or_id)
    if match:
        return int(match.group(1))
    raise ZhihuError(f"无法提取问题 ID: {url_or_id}")


def extract_answer_id(url_or_id: str) -> int:
    """Extract answer ID from URL or return as-is if numeric."""
    if url_or_id.isdigit():
        return int(url_or_id)
    match = _ANSWER_ID_RE.search(url_or_id)
    if match:
        return int(match.group(1))
    raise ZhihuError(f"无法提取回答 ID: {url_or_id}")


_PIN_ID_RE = re.compile(r"/pin/(\d+)")


def extract_pin_id(url_or_id: str) -> int:
    """Extract pin ID from URL or return as-is if numeric."""
    if url_or_id.isdigit():
        return int(url_or_id)
    match = _PIN_ID_RE.search(url_or_id)
    if match:
        return int(match.group(1))
    raise ZhihuError(f"无法提取想法 ID: {url_or_id}")


def extract_article_id(url_or_id: str) -> int:
    """Extract article ID from URL or return as-is if numeric."""
    if url_or_id.isdigit():
        return int(url_or_id)
    match = _ARTICLE_ID_RE.search(url_or_id)
    if match:
        return int(match.group(1))
    raise ZhihuError(f"无法提取文章 ID: {url_or_id}")


# ---------------------------------------------------------------------------
# User / Auth
# ---------------------------------------------------------------------------


async def get_self_info(credential: ZhihuCredential) -> dict[str, Any]:
    """Get logged-in user's own info."""
    return await _get(
        "https://www.zhihu.com/api/v4/me",
        credential=credential,
        action="获取当前用户信息",
    )


async def get_user_info(url_token: str, credential: ZhihuCredential | None = None) -> dict[str, Any]:
    """Fetch user profile by url_token."""
    return await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}",
        credential=credential,
        params={
            "include": (
                "follower_count,following_count,answer_count,"
                "articles_count,question_count,pins_count,"
                "columns_count,favorite_count"
            ),
        },
        action="获取用户信息",
    )


async def get_user_answers(
    url_token: str, *, offset: int = 0, limit: int = 10, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch a user's answers."""
    return await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}/answers",
        credential=credential,
        params={"offset": offset, "limit": limit, "sort_by": "created_time"},
        action="获取用户回答",
    )


async def get_user_articles(
    url_token: str, *, offset: int = 0, limit: int = 10, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch a user's articles."""
    return await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}/articles",
        credential=credential,
        params={"offset": offset, "limit": limit, "sort_by": "created_time"},
        action="获取用户文章",
    )


# ---------------------------------------------------------------------------
# Question
# ---------------------------------------------------------------------------


async def _get_answer_count(
    question_id: int, credential: ZhihuCredential | None = None
) -> int:
    """Get real answer count for a question via the answers API."""
    try:
        data = await _get(
            f"https://www.zhihu.com/api/v4/questions/{question_id}/answers",
            credential=credential,
            params={"limit": 1, "offset": 0},
            action="获取回答数",
        )
        return data.get("paging", {}).get("totals", 0)
    except Exception:
        return 0


async def _get_follower_count(
    question_id: int, credential: ZhihuCredential | None = None
) -> int:
    """Get follower count for a question via the followers API."""
    try:
        data = await _get(
            f"https://www.zhihu.com/api/v4/questions/{question_id}/followers",
            credential=credential,
            params={"limit": 1},
            action="获取关注数",
        )
        return data.get("paging", {}).get("totals", 0)
    except Exception:
        return 0


async def get_question(
    question_id: int, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch question details.

    Tries the v4 question API first. The API often returns ``answer_count: 0``
    even when answers exist, so we always supplement counts from sub-APIs.
    """
    info: dict[str, Any] | None = None

    try:
        info = await _get(
            f"https://www.zhihu.com/api/v4/questions/{question_id}",
            credential=credential,
            action="获取问题详情",
        )
    except ZhihuError:
        logger.debug("v4 question API failed, trying feeds fallback")
        data = await _get(
            f"https://www.zhihu.com/api/v4/questions/{question_id}/feeds",
            credential=credential,
            params={"limit": 1},
            action="获取问题详情(feeds)",
        )
        items = data.get("data", [])
        if items:
            question = items[0].get("target", {}).get("question", {})
            if question:
                info = question

    if info is None:
        info = {
            "id": question_id,
            "title": "",
            "type": "question",
            "url": f"https://www.zhihu.com/question/{question_id}",
        }

    # v4/feeds 均不返回真实计数，从子 API 补充
    real_answers = await _get_answer_count(question_id, credential)
    if real_answers > 0:
        info["answer_count"] = real_answers

    real_followers = await _get_follower_count(question_id, credential)
    if real_followers > 0:
        info["follower_count"] = real_followers

    return info


async def get_question_answers(
    question_id: int,
    *,
    offset: int = 0,
    limit: int = 10,
    sort_by: str = "default",
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch answers for a question."""
    include = (
        "data[*].content,voteup_count,comment_count,is_collapsed,"
        "author,collapsed,excerpt"
    )
    return await _get(
        f"https://www.zhihu.com/api/v4/questions/{question_id}/answers",
        credential=credential,
        params={
            "offset": offset,
            "limit": limit,
            "sort_by": sort_by,
            "include": include,
        },
        action="获取问题回答",
    )


# ---------------------------------------------------------------------------
# Answer
# ---------------------------------------------------------------------------


async def get_answer(
    answer_id: int, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch answer details."""
    include = (
        "data[*].content,voteup_count,comment_count,is_collapsed,"
        "author,collapsed,excerpt,thanks_count"
    )
    return await _get(
        f"https://www.zhihu.com/api/v4/answers/{answer_id}",
        credential=credential,
        params={"include": include},
        action="获取回答详情",
    )


# ---------------------------------------------------------------------------
# Article
# ---------------------------------------------------------------------------


async def get_article(
    article_id: int, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch article details."""
    return await _get(
        f"https://zhuanlan.zhihu.com/api/articles/{article_id}",
        credential=credential,
        action="获取文章详情",
    )


# ---------------------------------------------------------------------------
# Pin (想法)
# ---------------------------------------------------------------------------


async def get_pin(
    pin_id: int, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch pin (想法) details."""
    return await _get(
        f"https://www.zhihu.com/api/v4/pins/{pin_id}",
        credential=credential,
        action="获取想法详情",
    )


async def get_user_pins(
    url_token: str, *, offset: int = 0, limit: int = 10, credential: ZhihuCredential | None = None
) -> dict[str, Any]:
    """Fetch a user's pins (想法)."""
    return await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}/pins",
        credential=credential,
        params={"offset": offset, "limit": limit},
        action="获取用户想法",
    )


async def get_pin_comments(
    pin_id: int,
    *,
    limit: int = 20,
    offset: int = 0,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch comments for a pin using comment_v5 API."""
    data = await _get(
        f"https://www.zhihu.com/api/v4/comment_v5/pins/{pin_id}/root_comment",
        credential=credential,
        params={"limit": limit, "offset": offset if offset else "", "order_by": "score"},
        action="获取想法评论",
    )
    # comment_v5 用 like_count 代替 vote_count，统一字段名
    for item in data.get("data", []):
        if "like_count" in item and "vote_count" not in item:
            item["vote_count"] = item["like_count"]
    return data


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


async def get_comments(
    content_type: str,
    content_id: int,
    *,
    limit: int = 20,
    offset: int = 0,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch comments for a content item.

    content_type: 'answers', 'articles', 'questions'

    Uses comment_v5 API for articles (v4 endpoint returns 404).
    """
    if content_type == "articles":
        data = await _get(
            f"https://www.zhihu.com/api/v4/comment_v5/articles/{content_id}/root_comment",
            credential=credential,
            params={"limit": limit, "offset": offset if offset else "", "order_by": "score"},
            action="获取评论",
        )
        # comment_v5 用 like_count 代替 vote_count，统一字段名
        for item in data.get("data", []):
            if "like_count" in item and "vote_count" not in item:
                item["vote_count"] = item["like_count"]
        return data

    return await _get(
        f"https://www.zhihu.com/api/v4/{content_type}/{content_id}/comments",
        credential=credential,
        params={"limit": limit, "offset": offset, "order": "normal"},
        action="获取评论",
    )


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


async def search(
    keyword: str,
    *,
    search_type: str = "general",
    offset: int = 0,
    limit: int = 20,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Search Zhihu content.

    search_type maps to the ``t`` API parameter:
    'general', 'people', 'scholar', 'column', 'topic', 'zvideo',
    'question', 'pin', 'publication', 'ring'
    """
    return await _get(
        "https://www.zhihu.com/api/v4/search_v3",
        credential=credential,
        params={
            "q": keyword,
            "gk_version": "gz-gaokao",
            "t": search_type,
            "correction": 1,
            "offset": offset,
            "limit": limit,
        },
        action="搜索",
    )


# ---------------------------------------------------------------------------
# Hot
# ---------------------------------------------------------------------------


async def get_hot_list(limit: int = 50, credential: ZhihuCredential | None = None) -> dict[str, Any]:
    """Fetch Zhihu hot list (热榜)."""
    return await _get(
        "https://www.zhihu.com/api/v3/feed/topstory/hot-lists/total",
        credential=credential,
        params={"limit": limit},
        action="获取热榜",
    )


# ---------------------------------------------------------------------------
# Feed
# ---------------------------------------------------------------------------


async def get_feed(
    *,
    page_number: int = 0,
    limit: int = 10,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch personalized feed."""
    if credential is None:
        raise AuthenticationError("需要登录才能查看 feed")
    return await _get(
        "https://www.zhihu.com/api/v3/feed/topstory/recommend",
        credential=credential,
        params={"page_number": page_number, "limit": limit},
        action="获取 feed",
    )


# ---------------------------------------------------------------------------
# Following
# ---------------------------------------------------------------------------


async def get_following(
    url_token: str,
    *,
    offset: int = 0,
    limit: int = 20,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch user's following list."""
    return await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}/followees",
        credential=credential,
        params={"offset": offset, "limit": limit},
        action="获取关注列表",
    )


# ---------------------------------------------------------------------------
# Favorites / Collections
# ---------------------------------------------------------------------------


async def get_favorites(
    *,
    offset: int = 0,
    limit: int = 20,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch user's favorites (收藏夹列表).

    Uses ``/api/v4/me`` to resolve the current user's url_token, then fetches
    their favlists. The list API does not return item/follower counts, so we
    supplement each item with data from the detail API.
    """
    if credential is None:
        raise AuthenticationError("需要登录才能查看收藏")
    me = await get_self_info(credential)
    url_token = me.get("url_token", "")
    if not url_token:
        raise ZhihuError("获取用户 url_token 失败")
    data = await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}/favlists",
        credential=credential,
        params={"offset": offset, "limit": limit},
        action="获取收藏",
    )
    # Supplement each favlist with item_count and follower_count from detail API
    items = data.get("data", [])
    if items:
        tasks = [
            _get(
                f"https://www.zhihu.com/api/v4/collections/{item['id']}",
                credential=credential,
                action="获取收藏夹详情",
            )
            for item in items
        ]
        details = await asyncio.gather(*tasks, return_exceptions=True)
        for item, detail in zip(items, details, strict=False):
            if isinstance(detail, dict):
                coll = detail.get("collection", {})
                item["item_count"] = coll.get("item_count", 0)
                item["follower_count"] = coll.get("follower_count", 0)
    return data


async def get_collections(
    url_token: str,
    *,
    offset: int = 0,
    limit: int = 20,
    credential: ZhihuCredential | None = None,
) -> dict[str, Any]:
    """Fetch user's collections (收藏夹).

    The list API does not return item/follower counts, so we supplement each
    item with data from the detail API.
    """
    data = await _get(
        f"https://www.zhihu.com/api/v4/members/{url_token}/favlists",
        credential=credential,
        params={"offset": offset, "limit": limit},
        action="获取收藏夹",
    )
    items = data.get("data", [])
    if items:
        tasks = [
            _get(
                f"https://www.zhihu.com/api/v4/collections/{item['id']}",
                credential=credential,
                action="获取收藏夹详情",
            )
            for item in items
        ]
        details = await asyncio.gather(*tasks, return_exceptions=True)
        for item, detail in zip(items, details, strict=False):
            if isinstance(detail, dict):
                coll = detail.get("collection", {})
                item["item_count"] = coll.get("item_count", 0)
                item["follower_count"] = coll.get("follower_count", 0)
    return data


# ---------------------------------------------------------------------------
# Interactions
# ---------------------------------------------------------------------------


async def like_answer(
    answer_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Like an answer."""
    return await _post(
        f"https://www.zhihu.com/api/v4/answers/{answer_id}/voters",
        credential=credential,
        json_data={"type": "up"},
        action="点赞",
    )


async def unlike_answer(
    answer_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Unlike (neutral) an answer."""
    return await _post(
        f"https://www.zhihu.com/api/v4/answers/{answer_id}/voters",
        credential=credential,
        json_data={"type": "neutral"},
        action="取消点赞",
    )


async def like_article(
    article_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Like an article."""
    return await _post(
        f"https://www.zhihu.com/api/v4/articles/{article_id}/like",
        credential=credential,
        json_data={},
        action="点赞文章",
    )


async def like_pin(
    pin_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Like a pin (想法)."""
    return await _post(
        f"https://www.zhihu.com/api/v4/pins/{pin_id}/reactions",
        credential=credential,
        json_data={},
        action="点赞想法",
    )


async def unlike_pin(
    pin_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Unlike a pin (想法)."""
    return await _delete(
        f"https://www.zhihu.com/api/v4/pins/{pin_id}/reactions",
        credential=credential,
        action="取消点赞想法",
    )


async def follow_user(
    url_token: str, credential: ZhihuCredential
) -> dict[str, Any]:
    """Follow a user."""
    return await _post(
        f"https://www.zhihu.com/api/v4/members/{url_token}/followers",
        credential=credential,
        json_data={},
        action="关注用户",
    )


async def unfollow_user(
    url_token: str, credential: ZhihuCredential
) -> dict[str, Any]:
    """Unfollow a user."""
    return await _delete(
        f"https://www.zhihu.com/api/v4/members/{url_token}/followers",
        credential=credential,
        action="取消关注用户",
    )


async def follow_question(
    question_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Follow a question."""
    return await _post(
        f"https://www.zhihu.com/api/v4/questions/{question_id}/followers",
        credential=credential,
        json_data={},
        action="关注问题",
    )


async def unfollow_question(
    question_id: int, credential: ZhihuCredential
) -> dict[str, Any]:
    """Unfollow a question."""
    return await _delete(
        f"https://www.zhihu.com/api/v4/questions/{question_id}/followers",
        credential=credential,
        action="取消关注问题",
    )
