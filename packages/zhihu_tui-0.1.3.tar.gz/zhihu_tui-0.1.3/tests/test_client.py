"""Tests for client.py."""

from unittest.mock import AsyncMock, patch

import pytest

from zhihu_cli import client
from zhihu_cli.exceptions import AuthenticationError, ZhihuError


def test_extract_question_id_numeric():
    assert client.extract_question_id("12345") == 12345


def test_extract_question_id_url():
    assert client.extract_question_id("https://www.zhihu.com/question/12345") == 12345


def test_extract_question_id_invalid():
    with pytest.raises(ZhihuError):
        client.extract_question_id("not_a_url")


def test_extract_answer_id_numeric():
    assert client.extract_answer_id("789") == 789


def test_extract_answer_id_url():
    assert client.extract_answer_id("https://www.zhihu.com/question/12345/answer/789") == 789


def test_extract_article_id_numeric():
    assert client.extract_article_id("456") == 456


def test_extract_article_id_url():
    assert client.extract_article_id("https://zhuanlan.zhihu.com/p/456") == 456


@pytest.mark.asyncio
async def test_get_question():
    mock_response = {"id": 123, "title": "Test"}
    with patch("zhihu_cli.client._request", new_callable=AsyncMock, return_value=mock_response):
        result = await client.get_question(123)
        assert result["title"] == "Test"


@pytest.mark.asyncio
async def test_get_user_info():
    mock_response = {"id": "1", "name": "User"}
    with patch("zhihu_cli.client._request", new_callable=AsyncMock, return_value=mock_response):
        result = await client.get_user_info("testuser")
        assert result["name"] == "User"


@pytest.mark.asyncio
async def test_get_hot_list():
    mock_response = {"data": []}
    with patch("zhihu_cli.client._request", new_callable=AsyncMock, return_value=mock_response):
        result = await client.get_hot_list()
        assert result == {"data": []}


@pytest.mark.asyncio
async def test_feed_requires_auth():
    with pytest.raises(AuthenticationError):
        await client.get_feed(credential=None)
