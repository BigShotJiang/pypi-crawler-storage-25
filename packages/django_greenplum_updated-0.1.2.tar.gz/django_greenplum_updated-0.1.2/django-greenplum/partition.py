"""
Greenplum partition definitions for Django models.

Usage — define a class-level attribute `greenplum_partition` on your model:

    from django_greenplum.partition import RangePartition, ListPartition

    class Orders(models.Model):
        order_date = models.DateField()

        greenplum_partition = RangePartition(
            column='order_date',
            start='2020-01-01',
            end='2026-01-01',
            every='1 month',        # automatic sub-partitions
        )

    class Sales(models.Model):
        region = models.CharField(max_length=20)

        greenplum_partition = ListPartition(
            column='region',
            partitions=[
                ('north', ['north', 'northeast']),
                ('south', ['south', 'southeast']),
            ],
        )
"""


class RangePartition:
    """
    Generates a Greenplum PARTITION BY RANGE clause.

    Automatic sub-partitions (using EVERY):
        RangePartition(
            column='created_at',
            start='2020-01-01',
            end='2026-01-01',
            every='1 month',   # string  → INTERVAL '1 month'
                               # integer → plain numeric step
        )

    Manual named sub-partitions:
        RangePartition(
            column='id',
            partitions=[
                ('p1', 1, 1000),
                ('p2', 1000, 2000),
            ],
        )

    Parameters
    ----------
    column : str
        Model field name to partition by.
    start : value, optional
        Inclusive start bound (required when *every* is given).
    end : value, optional
        Exclusive end bound (required when *every* is given).
    every : str | int | float, optional
        Step for automatic sub-partitions.
        A string (e.g. ``"1 month"``) is wrapped as ``INTERVAL '1 month'``.
        A number (e.g. ``10``) is used verbatim.
    partitions : list of (name, start, end), optional
        Explicit named sub-partitions.  Mutually exclusive with *every*.
    start_inclusive : bool
        Whether the start bound is INCLUSIVE (default True).
    end_exclusive : bool
        Whether the end bound is EXCLUSIVE (default True).
    """

    def __init__(
        self,
        column,
        start=None,
        end=None,
        every=None,
        partitions=None,
        start_inclusive=True,
        end_exclusive=True,
    ):
        if every is not None and partitions is not None:
            raise ValueError("Specify either 'every' or 'partitions', not both.")
        if every is not None and (start is None or end is None):
            raise ValueError("'start' and 'end' are required when 'every' is set.")
        if every is None and not partitions:
            raise ValueError("Either 'every' or 'partitions' must be provided.")

        self.column = column
        self.start = start
        self.end = end
        self.every = every
        self.partitions = partitions
        self.start_inclusive = start_inclusive
        self.end_exclusive = end_exclusive

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _every_sql(every):
        if isinstance(every, (int, float)):
            return str(every)
        return "INTERVAL '%s'" % every

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def as_sql(self, schema_editor, model):
        """Return the PARTITION BY … clause to append to CREATE TABLE."""
        col = schema_editor.quote_name(self.column)
        start_kw = 'INCLUSIVE' if self.start_inclusive else 'EXCLUSIVE'
        end_kw = 'EXCLUSIVE' if self.end_exclusive else 'INCLUSIVE'

        if self.every is not None:
            start_val = schema_editor.quote_value(self.start)
            end_val = schema_editor.quote_value(self.end)
            every_sql = self._every_sql(self.every)
            return (
                "PARTITION BY RANGE (%(col)s) "
                "(START (%(start)s) %(start_kw)s "
                "END (%(end)s) %(end_kw)s "
                "EVERY (%(every)s))"
            ) % {
                'col': col,
                'start': start_val,
                'start_kw': start_kw,
                'end': end_val,
                'end_kw': end_kw,
                'every': every_sql,
            }

        # Manual named partitions
        parts = []
        for name, part_start, part_end in self.partitions:
            parts.append(
                "PARTITION %(name)s "
                "START (%(start)s) %(start_kw)s "
                "END (%(end)s) %(end_kw)s" % {
                    'name': schema_editor.quote_name(name),
                    'start': schema_editor.quote_value(part_start),
                    'start_kw': start_kw,
                    'end': schema_editor.quote_value(part_end),
                    'end_kw': end_kw,
                }
            )
        return "PARTITION BY RANGE (%(col)s) (\n    %(parts)s\n)" % {
            'col': col,
            'parts': ',\n    '.join(parts),
        }


class ListPartition:
    """
    Generates a Greenplum PARTITION BY LIST clause.

    Example::

        ListPartition(
            column='region',
            partitions=[
                ('north', ['north', 'northeast']),
                ('south', ['south', 'southeast']),
            ],
        )

    Parameters
    ----------
    column : str
        Model field name to partition by.
    partitions : list of (name, values)
        Each element is a tuple of the partition name and a list of values
        that belong to that partition.
    """

    def __init__(self, column, partitions):
        if not partitions:
            raise ValueError("'partitions' must be a non-empty list.")
        self.column = column
        self.partitions = partitions

    def as_sql(self, schema_editor, model):
        """Return the PARTITION BY … clause to append to CREATE TABLE."""
        col = schema_editor.quote_name(self.column)
        parts = []
        for name, values in self.partitions:
            quoted_values = ', '.join(
                schema_editor.quote_value(v) for v in values
            )
            parts.append(
                "PARTITION %(name)s VALUES (%(values)s)" % {
                    'name': schema_editor.quote_name(name),
                    'values': quoted_values,
                }
            )
        return "PARTITION BY LIST (%(col)s) (\n    %(parts)s\n)" % {
            'col': col,
            'parts': ',\n    '.join(parts),
        }
