# apps.py
from django.apps import AppConfig


class GreenplumConfig(AppConfig):
    # Полный путь до папки (как ты его импортируешь)
    name = 'django_greenplum'

    # Как Django будет называть это приложение внутри (label)
    # Именно этот label используется в app_label для динамических моделей
    label = 'django_greenplum'

    # Человекочитаемое имя для админки
    verbose_name = 'Django Greenplum Connector'
    