default_app_config = 'apps.GreenplumConfig'
