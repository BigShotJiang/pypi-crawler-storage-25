# Django-Greenplum

Django ORM backend for [Greenplum](https://greenplum.org/) — a massively parallel PostgreSQL-based database.

Originally authored by [souno](https://github.com/souno).

---

## Requirements

- Python 3.8+
- Django >= 3.0
- psycopg2 (or psycopg2-binary on Linux)

---

## Installation

You can install the package via `pip` or `uv`:

### Using uv (recommended)

```bash
uv add django-greenplum-updated
```

```python
DATABASES = {
    'default': {
        'ENGINE'  : 'django-greenplum',
        'NAME'    : 'mydb',
        'USER'    : 'gpadmin',
        'PASSWORD': 'secret',
        'HOST'    : '127.0.0.1',
        'PORT'    : '5432',
    }
}
```

---

## Partitioning

Greenplum supports table partitioning at the storage level. This backend lets you declare the partition strategy
directly on your Django model as a class attribute.

Import the partition class and assign it to `greenplum_partition`:

```python
from partition import RangePartition, ListPartition
```

### Range partition — automatic (EVERY)

Splits the table into equal sub-partitions over a continuous range.

```python
class Orders(models.Model):
    order_date = models.DateField()
    amount = models.DecimalField(max_digits=12, decimal_places=2)

    greenplum_partition = RangePartition(
        column='order_date',
        start='2020-01-01',
        end='2026-01-01',
        every='1 month',  # string → INTERVAL '1 month'
        # integer → plain numeric step
    )
```

Generated SQL suffix:

```sql
PARTITION BY RANGE ("order_date")
(START ('2020-01-01') INCLUSIVE END ('2026-01-01') EXCLUSIVE EVERY (INTERVAL '1 month'))
```

### Range partition — manual named partitions

```python
class Events(models.Model):
    event_date = models.DateField()
    description = models.TextField()

    greenplum_partition = RangePartition(
        column='event_date',
        partitions=[
            ('p2023', '2023-01-01', '2024-01-01'),
            ('p2024', '2024-01-01', '2025-01-01'),
            ('p2025', '2025-01-01', '2026-01-01'),
        ],
    )
```

### List partition

```python
class Sales(models.Model):
    region = models.CharField(max_length=20)
    revenue = models.DecimalField(max_digits=14, decimal_places=2)

    greenplum_partition = ListPartition(
        column='region',
        partitions=[
            ('north', ['north', 'northeast']),
            ('south', ['south', 'southeast']),
            ('other', ['west', 'east']),
        ],
    )
```

### RangePartition parameters

| Parameter         | Type                    | Description                                                      |
|-------------------|-------------------------|------------------------------------------------------------------|
| `column`          | `str`                   | Model field name to partition by                                 |
| `start`           | value                   | Inclusive start bound (required with `every`)                    |
| `end`             | value                   | Exclusive end bound (required with `every`)                      |
| `every`           | `str` or `int`          | Step for automatic partitions (`"1 month"`, `"1 year"`, `10`, …) |
| `partitions`      | list of 3-tuples        | Manual named partitions `(name, start, end)`                     |
| `start_inclusive` | `bool` (default `True`) | Whether the start bound is `INCLUSIVE`                           |
| `end_exclusive`   | `bool` (default `True`) | Whether the end bound is `EXCLUSIVE`                             |

`every` and `partitions` are mutually exclusive.

### ListPartition parameters

| Parameter    | Type             | Description                                              |
|--------------|------------------|----------------------------------------------------------|
| `column`     | `str`            | Model field name to partition by                         |
| `partitions` | list of 2-tuples | `(partition_name, [value, value, …])` for each partition |

---

## Notices

1. The primary key is used as the **distribution key** by default. Greenplum does not support multiple unique keys on
   the same table — avoid defining `unique=True` on non-primary-key fields.

2. Because of the above limitation, the default Django `admin` and `auth` applications may not work as expected.

3. Partition child tables are automatically excluded from Django's model introspection — only the parent (root) table is
   visible.
