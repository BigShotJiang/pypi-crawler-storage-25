from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import community_program_closeout_62 as d62


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-community-program-closeout.md\ncommunity-program-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-62-big-upgrade-report.md\nintegrations-community-program-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Community program setup:** publish office-hours cadence and participation rules.\n"
        "- ** — Contributor onboarding activation:** launch orientation flow and ownership handoff loops.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-community-program-closeout.md").write_text(
        d62._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-62-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root / "docs/artifacts/phase3-kickoff-closeout-pack/phase3-kickoff-closeout-summary.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = root / "docs/artifacts/phase3-kickoff-closeout-pack/phase3-kickoff-delivery-board.md"
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  Phase-3 kickoff brief committed",
                "- [ ]  kickoff reviewed with owner + backup",
                "- [ ]  trust ledger exported",
                "- [ ]  KPI scorecard snapshot exported",
                "- [ ]  community program priorities drafted from  learnings",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def test_lane62_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d62.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "community-program-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane62_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d62.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/community-program-closeout-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/community-program-closeout-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/community-program-closeout-summary.json"
    ).exists()
    assert (
        tmp_path / "artifacts/community-program-closeout-pack/community-program-closeout-summary.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/community-program-community-launch-brief.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/community-program-office-hours-cadence.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/community-program-participation-policy.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/community-program-moderation-runbook.md"
    ).exists()
    assert (
        tmp_path / "artifacts/community-program-closeout-pack/community-program-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path / "artifacts/community-program-closeout-pack/community-program-execution-log.md"
    ).exists()
    assert (
        tmp_path / "artifacts/community-program-closeout-pack/community-program-delivery-board.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/community-program-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-program-closeout-pack/evidence/community-program-execution-summary.json"
    ).exists()


def test_lane62_strict_fails_without_prereq_baseline(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/phase3-kickoff-closeout-pack/phase3-kickoff-closeout-summary.json"
    ).unlink()
    assert d62.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane62_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["community-program-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    alias_rc = cli.main(["community-program-closeout", "--root", str(tmp_path), "--format", "text"])
    assert alias_rc == 0
    assert "Community Program Closeout summary" in capsys.readouterr().out
