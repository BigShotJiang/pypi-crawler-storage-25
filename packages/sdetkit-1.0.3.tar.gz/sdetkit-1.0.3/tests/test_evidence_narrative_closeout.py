from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import evidence_narrative_closeout_84 as d84


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-evidence-narrative-closeout.md\nevidence-narrative-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-84-big-upgrade-report.md\nintegrations-evidence-narrative-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Trust FAQ expansion loop:** convert field objections into deterministic trust upgrades.\n"
        "- ** — Evidence narrative closeout lane:** convert trust outcomes into release-ready narrative proof packs.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-evidence-narrative-closeout.md").write_text(
        d84._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-84-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root
        / "docs/artifacts/trust-faq-expansion-closeout-pack/trust-faq-expansion-closeout-summary.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = (
        root
        / "docs/artifacts/trust-faq-expansion-closeout-pack/trust-faq-expansion-delivery-board.md"
    )
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  trust FAQ brief committed",
                "- [ ]  trust FAQ expansion plan committed",
                "- [ ]  trust template upgrade ledger exported",
                "- [ ]  escalation outcomes ledger exported",
                "- [ ]  evidence narrative priorities drafted from  outcomes",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    plan = root / "docs/roadmap/plans/evidence-narrative-plan.json"
    plan.write_text(
        json.dumps(
            {
                "plan_id": "evidence-narrative-001",
                "contributors": ["maintainers", "docs-ops"],
                "narrative_channels": ["release-report", "runbook", "faq"],
                "baseline": {"evidence_coverage": 0.64, "narrative_reuse": 0.42},
                "target": {"evidence_coverage": 0.86, "narrative_reuse": 0.67},
                "owner": "docs-ops",
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def test_lane84_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d84.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "evidence-narrative-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane84_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d84.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/evidence-narrative-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/evidence-narrative-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-closeout-summary.json"
    ).exists()
    assert (
        tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-closeout-summary.md"
    ).exists()
    assert (
        tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-evidence-brief.md"
    ).exists()
    assert (tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-plan.md").exists()
    assert (
        tmp_path
        / "artifacts/evidence-narrative-pack/evidence-narrative-narrative-template-upgrade-ledger.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/evidence-narrative-pack/evidence-narrative-storyline-outcomes-ledger.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/evidence-narrative-pack/evidence-narrative-narrative-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-execution-log.md"
    ).exists()
    assert (
        tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-delivery-board.md"
    ).exists()
    assert (
        tmp_path / "artifacts/evidence-narrative-pack/evidence-narrative-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/evidence-narrative-pack/evidence/evidence-narrative-execution-summary.json"
    ).exists()


def test_lane84_strict_fails_without_prereq_baseline(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/trust-faq-expansion-closeout-pack/trust-faq-expansion-closeout-summary.json"
    ).unlink()
    assert d84.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane84_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["evidence-narrative-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " evidence narrative closeout summary" in capsys.readouterr().out
