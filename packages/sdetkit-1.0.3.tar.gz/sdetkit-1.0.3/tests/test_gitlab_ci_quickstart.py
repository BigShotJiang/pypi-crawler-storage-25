import json
import re

from sdetkit import cli, gitlab_ci_quickstart


def _normalize_ws(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def test_quickstart_default_text(capsys):
    rc = gitlab_ci_quickstart.main([])
    assert rc == 0
    out = capsys.readouterr().out
    assert "GitLab CI quickstart report" in out
    assert "Required sections:" in out
    assert "Page:" in out


def test_quickstart_help_output_is_productized():
    out = _normalize_ws(gitlab_ci_quickstart._build_parser().format_help())
    assert "Render and validate a GitLab CI quickstart report." in out
    assert "--format {text,markdown,json} Output format." in out
    assert "--output OUTPUT" in out
    assert "Optional file path to also write the rendered" in out
    assert "GitLab CI quickstart report." in out


def test_quickstart_markdown_output_uses_productized_headings(capsys):
    rc = gitlab_ci_quickstart.main(["--format", "markdown", "--variant", "strict"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "# GitLab CI quickstart report" in out
    assert "## Required sections" in out
    assert "## Required commands" in out
    assert "## Selected pipeline" in out
    assert "## Quickstart coverage gaps" in out
    assert "## Actions" in out
    assert "strict-gate:" in out
    assert "- Open page: `docs/integrations-gitlab-ci-quickstart.md`" in out


def test_quickstart_json_and_strict_success(capsys):
    rc = gitlab_ci_quickstart.main(["--format", "json", "--strict"])
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["name"] == "gitlab-ci-onboarding"
    assert data["passed_checks"] == data["total_checks"]
    assert data["total_checks"] == 19


def test_quickstart_variant_switches_pipeline(capsys):
    rc = gitlab_ci_quickstart.main(["--format", "json", "--variant", "strict", "--strict"])
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["variant"] == "strict"
    assert "strict-gate:" in data["selected_pipeline"]


def test_quickstart_strict_fails_when_content_missing(tmp_path, capsys):
    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/integrations-gitlab-ci-quickstart.md").write_text(
        "# Placeholder\n", encoding="utf-8"
    )
    rc = gitlab_ci_quickstart.main(["--root", str(tmp_path), "--strict"])
    assert rc == 1
    assert "Quickstart coverage gaps:" in capsys.readouterr().out


def test_quickstart_write_defaults_recovers_missing_file(tmp_path, capsys):
    rc = gitlab_ci_quickstart.main(
        ["--root", str(tmp_path), "--write-defaults", "--format", "json", "--strict"]
    )
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["passed_checks"] == data["total_checks"]
    assert data["touched_files"] == ["docs/integrations-gitlab-ci-quickstart.md"]


def test_quickstart_emit_pack(tmp_path, capsys):
    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/integrations-gitlab-ci-quickstart.md").write_text(
        gitlab_ci_quickstart._DEFAULT_PAGE, encoding="utf-8"
    )
    rc = gitlab_ci_quickstart.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "docs/artifacts/gitlab-ci-onboarding-pack",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert len(data["pack_files"]) == 6
    assert (
        "docs/artifacts/gitlab-ci-onboarding-pack/gitlab-ci-sdetkit-strict.yml"
        in data["pack_files"]
    )


def test_quickstart_execute_writes_evidence(monkeypatch, tmp_path, capsys):
    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/integrations-gitlab-ci-quickstart.md").write_text(
        gitlab_ci_quickstart._DEFAULT_PAGE, encoding="utf-8"
    )

    class _Proc:
        def init_(self):
            self.returncode = 0
            self.stdout = "ok"
            self.stderr = ""

    monkeypatch.setattr(gitlab_ci_quickstart.subprocess, "run", lambda *a, **k: _Proc())

    rc = gitlab_ci_quickstart.main(
        [
            "--root",
            str(tmp_path),
            "--execute",
            "--evidence-dir",
            "docs/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["execution"]["failed_commands"] == 0
    assert (tmp_path / "docs/evidence/gitlab-ci-onboarding-execution-summary.json").exists()


def test_quickstart_execute_strict_fails_on_command_error(monkeypatch, tmp_path, capsys):
    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/integrations-gitlab-ci-quickstart.md").write_text(
        gitlab_ci_quickstart._DEFAULT_PAGE, encoding="utf-8"
    )

    class _Proc:
        def init_(self):
            self.returncode = 1
            self.stdout = ""
            self.stderr = "boom"

    monkeypatch.setattr(gitlab_ci_quickstart.subprocess, "run", lambda *a, **k: _Proc())

    rc = gitlab_ci_quickstart.main(
        ["--root", str(tmp_path), "--execute", "--format", "json", "--strict"]
    )
    assert rc == 1
    data = json.loads(capsys.readouterr().out)
    assert data["execution"]["failed_commands"] == 4


def test_main_cli_dispatches_gitlab_ci_quickstart_alias(capsys):
    rc = cli.main(["gitlab-ci-quickstart", "--format", "text"])
    assert rc == 0
    assert "GitLab CI quickstart report" in capsys.readouterr().out


def test_quickstart_bootstrap_pipeline_writes_selected_variant(tmp_path, capsys):
    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/integrations-gitlab-ci-quickstart.md").write_text(
        gitlab_ci_quickstart._DEFAULT_PAGE, encoding="utf-8"
    )

    rc = gitlab_ci_quickstart.main(
        [
            "--root",
            str(tmp_path),
            "--variant",
            "strict",
            "--bootstrap-pipeline",
            "--pipeline-path",
            ".gitlab-ci.yml",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["bootstrapped_pipeline"] == ".gitlab-ci.yml"
    assert ".gitlab-ci.yml" in data["touched_files"]
    rendered = (tmp_path / ".gitlab-ci.yml").read_text(encoding="utf-8")
    assert "strict-gate:" in rendered
