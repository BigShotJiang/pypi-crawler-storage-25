from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import integration_expansion2_closeout_66 as d66


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-integration-expansion2-closeout.md\nintegration-expansion2-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-66-big-upgrade-report.md\nintegrations-integration-expansion2-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Integration expansion #2:** publish advanced GitLab CI implementation path.\n"
        "- ** — Integration expansion #3:** publish advanced Jenkins implementation path.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-integration-expansion2-closeout.md").write_text(
        d66._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-66-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root / "docs/artifacts/weekly-review-closeout-pack-2/weekly-review-closeout-summary-2.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = (
        root
        / "docs/artifacts/weekly-review-closeout-pack-2/weekly-review-closeout-delivery-board-2.md"
    )
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  weekly brief committed",
                "- [ ]  KPI dashboard snapshot exported",
                "- [ ]  governance decision register published",
                "- [ ]  risk and recovery ledger exported",
                "- [ ]  integration expansion priorities drafted from  review",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    gitlab = root / "templates/ci/gitlab/gitlab-advanced-reference.yml"
    gitlab.write_text(
        "stages:\n"
        "  - lint\n"
        "  - test\n"
        "workflow:\n"
        "  rules:\n"
        "    - if: '$CI_PIPELINE_SOURCE == \"merge_request_event\"'\n"
        "    - if: '$CI_COMMIT_BRANCH'\n"
        "test:matrix:\n"
        "  stage: test\n"
        "  parallel:\n"
        "    matrix:\n"
        "      - PYTHON_VERSION: ['3.10', '3.11']\n"
        "  cache:\n"
        "    key: ${CI_COMMIT_REF_SLUG}\n"
        "    paths:\n"
        "      - .venv/\n",
        encoding="utf-8",
    )


def test_lane66_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d66.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "integration-expansion2-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane66_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d66.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/integration-expansion2-closeout-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/integration-expansion2-closeout-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-closeout-summary.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-closeout-summary.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-integration-brief.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-pipeline-blueprint.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-matrix-plan.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-execution-log.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-delivery-board.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/integration-expansion2-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/integration-expansion2-closeout-pack/evidence/integration-expansion2-execution-summary.json"
    ).exists()


def test_lane66_strict_fails_without_prereq_baseline(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/weekly-review-closeout-pack-2/weekly-review-closeout-summary-2.json"
    ).unlink()
    assert d66.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane66_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["integration-expansion2-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert "Integration Expansion 2 Closeout summary" in capsys.readouterr().out
