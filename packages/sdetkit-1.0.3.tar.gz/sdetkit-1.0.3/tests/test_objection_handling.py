from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import objection_handling as fqo


def _write_fixture(root: Path) -> None:
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-23-ultra-upgrade-report.md\n"
        "docs/objection-handling.md\n"
        "Objection handling\n"
        "objection-handling\n"
        "python -m sdetkit objection-handling --format json --strict\n"
        "release-communications\n",
        encoding="utf-8",
    )
    (root / "README.md").write_text(
        "Objection handling\n"
        "docs/objection-handling.md\n"
        "objection-handling\n"
        "python -m sdetkit objection-handling --format json --strict\n"
        "release-communications\n",
        encoding="utf-8",
    )
    (root / "docs/objection-handling.md").write_text(fqo._DEFAULT_PAGE_TEMPLATE, encoding="utf-8")


def test_faq_json(tmp_path: Path, capsys) -> None:
    _write_fixture(tmp_path)

    rc = fqo.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0

    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "objection-handling"
    assert out["summary"]["faq_score"] == 100.0


def test_faq_emit_pack_and_execute(tmp_path: Path) -> None:
    _write_fixture(tmp_path)

    rc = fqo.main(
        [
            "--root",
            str(tmp_path),
            "--format",
            "json",
            "--strict",
            "--emit-pack-dir",
            "artifacts/objection-handling-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/objection-handling-pack/evidence",
        ]
    )
    assert rc == 0
    assert (tmp_path / "artifacts/objection-handling-pack/objection-handling-summary.json").exists()
    assert (tmp_path / "artifacts/objection-handling-pack/objection-handling-scorecard.md").exists()
    assert (
        tmp_path / "artifacts/objection-handling-pack/objection-handling-response-matrix.md"
    ).exists()
    assert (tmp_path / "artifacts/objection-handling-pack/objection-handling-playbook.md").exists()
    assert (
        tmp_path / "artifacts/objection-handling-pack/objection-handling-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/objection-handling-pack/evidence/objection-handling-execution-summary.json"
    ).exists()


def test_faq_strict_fails_when_required_sections_missing(tmp_path: Path) -> None:
    _write_fixture(tmp_path)
    (tmp_path / "docs/objection-handling.md").write_text("# Objection handling\n", encoding="utf-8")

    rc = fqo.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 1


def test_cli_dispatch(tmp_path: Path, capsys) -> None:
    _write_fixture(tmp_path)

    rc = cli.main(["objection-handling", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert "Objection handling" in capsys.readouterr().out
