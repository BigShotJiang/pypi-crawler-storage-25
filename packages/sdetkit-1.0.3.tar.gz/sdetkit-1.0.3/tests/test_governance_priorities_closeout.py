from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import governance_priorities_closeout_88 as d88


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-governance-priorities-closeout.md\ngovernance-priorities-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-88-big-upgrade-report.md\nintegrations-governance-priorities-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Launch readiness closeout lane:** convert launch readiness outcomes into governance ownership scorecards.\n"
        "- ** — Governance priorities closeout lane:** convert governance handoff outcomes into governed roadmap priorities.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-governance-priorities-closeout.md").write_text(
        d88._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-88-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root
        / "docs/artifacts/governance-handoff-closeout-pack/governance-handoff-closeout-summary.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = (
        root
        / "docs/artifacts/governance-handoff-closeout-pack/governance-handoff-delivery-board.md"
    )
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  evidence brief committed",
                "- [ ]  governance handoff plan committed",
                "- [ ]  narrative template upgrade ledger exported",
                "- [ ]  storyline outcomes ledger exported",
                "- [ ]  governance priorities drafted from  outcomes",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    plan = root / "docs/roadmap/plans/governance-priorities-plan.json"
    plan.write_text(
        json.dumps(
            {
                "plan_id": "governance-priorities-001",
                "contributors": ["maintainers", "release-ops"],
                "narrative_channels": ["launch-brief", "release-report", "faq"],
                "baseline": {"launch_confidence": 0.64, "narrative_reuse": 0.42},
                "target": {"launch_confidence": 0.86, "narrative_reuse": 0.67},
                "owner": "release-ops",
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def test_lane88_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d88.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "governance-priorities-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane88_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d88.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/governance-priorities-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/governance-priorities-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path
        / "artifacts/governance-priorities-pack/governance-priorities-closeout-summary.json"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-priorities-pack/governance-priorities-closeout-summary.md"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-priorities-pack/governance-priorities-evidence-brief.md"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-priorities-pack/governance-priorities-plan.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-priorities-pack/governance-priorities-narrative-template-upgrade-ledger.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-priorities-pack/governance-priorities-storyline-outcomes-ledger.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-priorities-pack/governance-priorities-narrative-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-priorities-pack/governance-priorities-execution-log.md"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-priorities-pack/governance-priorities-delivery-board.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-priorities-pack/governance-priorities-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-priorities-pack/evidence/governance-priorities-execution-summary.json"
    ).exists()


def test_lane88_strict_fails_without_prereq_baseline(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/governance-handoff-closeout-pack/governance-handoff-closeout-summary.json"
    ).unlink()
    assert d88.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane88_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["governance-priorities-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " governance priorities closeout summary" in capsys.readouterr().out
