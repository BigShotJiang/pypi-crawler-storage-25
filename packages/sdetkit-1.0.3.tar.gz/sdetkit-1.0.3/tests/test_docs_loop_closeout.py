from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import docs_loop_closeout_53 as d53


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-docs-loop-closeout.md\ndocs-loop-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-53-big-upgrade-report.md\nintegrations-docs-loop-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Case snippet #2:** publish mini-case on reliability or quality gate value.\n"
        "- ** — Docs loop optimization:** publish mini-case on security/ops workflow value.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-docs-loop-closeout.md").write_text(
        d53._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-53-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = root / "docs/artifacts/narrative-closeout-pack/narrative-closeout-summary.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"check_id": "ok", "passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = root / "docs/artifacts/narrative-closeout-pack/narrative-delivery-board.md"
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  narrative brief committed",
                "- [ ]  narrative reviewed with owner + backup",
                "- [ ]  proof map exported",
                "- [ ]  KPI scorecard snapshot exported",
                "- [ ]  expansion priorities drafted from  learnings",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def test_lane53_docs_loop_closeout_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d53.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "docs-loop-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane53_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d53.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/docs-loop-closeout-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/docs-loop-closeout-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-closeout-summary.json").exists()
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-closeout-summary.md").exists()
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-brief.md").exists()
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-cross-link-map.csv").exists()
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-kpi-scorecard.json").exists()
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-execution-log.md").exists()
    assert (tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-delivery-board.md").exists()
    assert (
        tmp_path / "artifacts/docs-loop-closeout-pack/docs-loop-validation-commands.md"
    ).exists()
    assert (
        tmp_path / "artifacts/docs-loop-closeout-pack/evidence/docs-loop-execution-summary.json"
    ).exists()


def test_lane53_strict_fails_when_lane52_inputs_missing(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/artifacts/narrative-closeout-pack/narrative-closeout-summary.json").unlink()
    rc = d53.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_lane53_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["docs-loop-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert "Docs Loop Closeout summary" in capsys.readouterr().out
