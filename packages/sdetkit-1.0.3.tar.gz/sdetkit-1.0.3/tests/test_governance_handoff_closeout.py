from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import governance_handoff_closeout_87 as d87


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-governance-handoff-closeout.md\ngovernance-handoff-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-87-big-upgrade-report.md\nintegrations-governance-handoff-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Launch readiness closeout lane:** convert launch readiness outcomes into governance ownership scorecards.\n"
        "- ** — Governance handoff closeout lane:** convert launch readiness outcomes into governance ownership scorecards.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-governance-handoff-closeout.md").write_text(
        d87._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-87-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root
        / "docs/artifacts/launch-readiness-closeout-pack/launch-readiness-closeout-summary.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = (
        root / "docs/artifacts/launch-readiness-closeout-pack/launch-readiness-delivery-board.md"
    )
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  evidence brief committed",
                "- [ ]  launch readiness plan committed",
                "- [ ]  narrative template upgrade ledger exported",
                "- [ ]  storyline outcomes ledger exported",
                "- [ ]  governance priorities drafted from  outcomes",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    plan = root / "docs/roadmap/plans/governance-handoff-plan.json"
    plan.write_text(
        json.dumps(
            {
                "plan_id": "governance-handoff-001",
                "contributors": ["maintainers", "release-ops"],
                "narrative_channels": ["launch-brief", "release-report", "faq"],
                "baseline": {"launch_confidence": 0.64, "narrative_reuse": 0.42},
                "target": {"launch_confidence": 0.86, "narrative_reuse": 0.67},
                "owner": "release-ops",
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def test_lane87_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d87.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "governance-handoff-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane87_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d87.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/governance-handoff-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/governance-handoff-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path / "artifacts/governance-handoff-pack/governance-handoff-closeout-summary.json"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-handoff-pack/governance-handoff-closeout-summary.md"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-handoff-pack/governance-handoff-evidence-brief.md"
    ).exists()
    assert (tmp_path / "artifacts/governance-handoff-pack/governance-handoff-plan.md").exists()
    assert (
        tmp_path
        / "artifacts/governance-handoff-pack/governance-handoff-narrative-template-upgrade-ledger.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-handoff-pack/governance-handoff-storyline-outcomes-ledger.json"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-handoff-pack/governance-handoff-narrative-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-handoff-pack/governance-handoff-execution-log.md"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-handoff-pack/governance-handoff-delivery-board.md"
    ).exists()
    assert (
        tmp_path / "artifacts/governance-handoff-pack/governance-handoff-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/governance-handoff-pack/evidence/governance-handoff-execution-summary.json"
    ).exists()


def test_lane87_strict_fails_without_prereq_baseline(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/launch-readiness-closeout-pack/launch-readiness-closeout-summary.json"
    ).unlink()
    assert d87.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane87_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["governance-handoff-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " governance handoff closeout summary" in capsys.readouterr().out
