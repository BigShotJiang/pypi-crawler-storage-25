from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import experiment_lane_37 as d37


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-experiment-lane.md\nexperiment-lane\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-37-big-upgrade-report.md\nintegrations-experiment-lane.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Experiment lane activation:** seed controlled experiments from  distribution misses and KPI deltas.\n"
        "- ** — Distribution batch #1:** publish coordinated posts linking demo assets to docs.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-experiment-lane.md").write_text(
        d37._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-37-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = root / "docs/artifacts/distribution-closeout-pack/distribution-closeout-summary.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 99, "strict_pass": True},
                "checks": [{"check_id": "ok", "passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = root / "docs/artifacts/distribution-closeout-pack/delivery-board.md"
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  launch plan committed",
                "- [ ]  message kit reviewed with owner + backup",
                "- [ ]  posting windows locked",
                "- [ ]  experiment backlog seeded from channel misses",
                "- [ ]  summary owner confirmed",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def test_lane37_distribution_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d37.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "experiment-lane"
    assert out["summary"]["activation_score"] >= 95


def test_lane37_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d37.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/experiment-lane-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/experiment-lane-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (tmp_path / "artifacts/experiment-lane-pack/experiment-lane-summary.json").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/experiment-lane-summary.md").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/experiment-matrix.csv").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/hypothesis-brief.md").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/experiment-scorecard.json").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/decision-log.md").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/delivery-board.md").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/validation-commands.md").exists()
    assert (tmp_path / "artifacts/experiment-lane-pack/evidence/execution-summary.json").exists()


def test_lane37_strict_fails_when_lane36_inputs_missing(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path / "docs/artifacts/distribution-closeout-pack/distribution-closeout-summary.json"
    ).unlink()
    rc = d37.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_lane37_strict_fails_when_lane36_board_is_not_ready(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/artifacts/distribution-closeout-pack/delivery-board.md").write_text(
        "- [ ]  experiment backlog seeded from channel misses\n", encoding="utf-8"
    )
    rc = d37.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_lane37_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["experiment-lane", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " experiment lane summary" in capsys.readouterr().out
