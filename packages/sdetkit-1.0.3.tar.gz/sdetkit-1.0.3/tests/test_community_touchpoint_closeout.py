from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import community_touchpoint_closeout_77 as d77


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-community-touchpoint-closeout.md\ncommunity-touchpoint-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-77-big-upgrade-report.md\nintegrations-community-touchpoint-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "Contributor recognition + community touchpoint strategy chain\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-community-touchpoint-closeout.md").write_text(
        d77._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-77-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root
        / "docs/artifacts/contributor-recognition-closeout-pack/contributor-recognition-closeout-summary.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = (
        root
        / "docs/artifacts/contributor-recognition-closeout-pack/contributor-recognition-delivery-board.md"
    )
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  integration brief committed",
                "- [ ]  contributor recognition plan committed",
                "- [ ]  recognition credits ledger exported",
                "- [ ]  recognition KPI scorecard snapshot exported",
                "- [ ]  scale priorities drafted from  learnings",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    touchpoint_plan = root / "docs/roadmap/plans/community-touchpoint-plan.json"
    touchpoint_plan.write_text(
        json.dumps(
            {
                "plan_id": "community-touchpoint-001",
                "contributors": ["maintainers", "community-team"],
                "touchpoint_tracks": ["office-hours", "release-highlights"],
                "baseline": {"sessions": 1, "participants": 15},
                "target": {"sessions": 3, "participants": 40},
                "owner": "community-ops",
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def test_lane77_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d77.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "community-touchpoint-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane77_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d77.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/community-touchpoint-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/community-touchpoint-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-closeout-summary.json"
    ).exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-closeout-summary.md"
    ).exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-integration-brief.md"
    ).exists()
    assert (tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-plan.md").exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-session-ledger.json"
    ).exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-execution-log.md"
    ).exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-delivery-board.md"
    ).exists()
    assert (
        tmp_path / "artifacts/community-touchpoint-pack/community-touchpoint-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/community-touchpoint-pack/evidence/community-touchpoint-execution-summary.json"
    ).exists()


def test_lane77_strict_fails_without_contributor_recognition_baseline(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/contributor-recognition-closeout-pack/contributor-recognition-closeout-summary.json"
    ).unlink()
    assert d77.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane77_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["community-touchpoint-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert "Community Touchpoint Closeout summary" in capsys.readouterr().out
