from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import distribution_batch_38 as d38


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-distribution-batch.md\ndistribution-batch\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-38-big-upgrade-report.md\nintegrations-distribution-batch.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Distribution batch #1:** publish coordinated posts linking demo assets to docs.\n"
        "- ** — Playbook post #1:** publish Repo Reliability Playbook article #1.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-distribution-batch.md").write_text(
        d38._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-38-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = root / "docs/artifacts/experiment-lane-pack/experiment-lane-summary.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 99, "strict_pass": True},
                "checks": [{"check_id": "ok", "passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = root / "docs/artifacts/experiment-lane-pack/delivery-board.md"
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  experiment matrix committed",
                "- [ ]  hypothesis brief reviewed with owner + backup",
                "- [ ]  scorecard snapshot exported",
                "- [ ]  distribution batch actions selected from winners",
                "- [ ]  fallback plan documented for losing variants",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def test_distribution_batch_distribution_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d38.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "distribution-batch"
    assert out["summary"]["activation_score"] >= 95


def test_distribution_batch_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d38.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/distribution-batch-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/distribution-batch-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (tmp_path / "artifacts/distribution-batch-pack/distribution-batch-summary.json").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/distribution-batch-summary.md").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/channel-plan.csv").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/post-copy.md").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/kpi-scorecard.json").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/execution-log.md").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/delivery-board.md").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/validation-commands.md").exists()
    assert (tmp_path / "artifacts/distribution-batch-pack/evidence/execution-summary.json").exists()


def test_distribution_batch_strict_fails_when_lane37_inputs_missing(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/artifacts/experiment-lane-pack/experiment-lane-summary.json").unlink()
    rc = d38.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_distribution_batch_strict_fails_when_lane37_board_is_not_ready(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/artifacts/experiment-lane-pack/delivery-board.md").write_text(
        "- [ ]  distribution batch actions selected from winners\n", encoding="utf-8"
    )
    rc = d38.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_distribution_batch_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["distribution-batch", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " distribution batch summary" in capsys.readouterr().out
