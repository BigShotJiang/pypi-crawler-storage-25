from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import kpi_instrumentation_35 as d35


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-kpi-instrumentation.md\nkpi-instrumentation\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-35-big-upgrade-report.md\nintegrations-kpi-instrumentation.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — KPI instrumentation:** close attribution gaps and lock weekly review metrics.\n"
        "- ** — Demo asset #3:** produce/publish `security gate` workflow short video or GIF.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-kpi-instrumentation.md").write_text(
        d35._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-35-big-upgrade-report.md").write_text("#  report\n", encoding="utf-8")

    summary = root / "docs/artifacts/demo-asset2-pack/demo-asset2-summary.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 99, "strict_pass": True},
                "checks": [{"check_id": "ok", "passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = root / "docs/artifacts/demo-asset2-pack/demo-asset2-delivery-board.md"
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  script draft committed",
                "- [ ]  first cut rendered",
                "- [ ]  final cut + caption copy approved",
                "- [ ]  KPI instrumentation backlog pre-scoped",
                "- [ ]  community distribution plan updated",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def test_kpi_instrumentation_kpi_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d35.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "kpi-instrumentation"
    assert out["summary"]["activation_score"] >= 95


def test_kpi_instrumentation_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d35.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/kpi-instrumentation-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/kpi-instrumentation-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path / "artifacts/kpi-instrumentation-pack/kpi-instrumentation-summary.json"
    ).exists()
    assert (tmp_path / "artifacts/kpi-instrumentation-pack/kpi-instrumentation-summary.md").exists()
    assert (tmp_path / "artifacts/kpi-instrumentation-pack/kpi-dictionary.csv").exists()
    assert (tmp_path / "artifacts/kpi-instrumentation-pack/alert-policy.md").exists()
    assert (tmp_path / "artifacts/kpi-instrumentation-pack/delivery-board.md").exists()
    assert (
        tmp_path / "artifacts/kpi-instrumentation-pack/kpi-instrumentation-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/kpi-instrumentation-pack/evidence/kpi-instrumentation-execution-summary.json"
    ).exists()


def test_kpi_instrumentation_strict_fails_when_lane34_inputs_missing(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/artifacts/demo-asset2-pack/demo-asset2-summary.json").unlink()
    rc = d35.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_kpi_instrumentation_strict_fails_when_lane34_board_is_not_ready(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/artifacts/demo-asset2-pack/demo-asset2-delivery-board.md").write_text(
        "- [ ]  KPI instrumentation backlog pre-scoped\n", encoding="utf-8"
    )
    rc = d35.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_kpi_instrumentation_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["kpi-instrumentation", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " KPI instrumentation summary" in capsys.readouterr().out
