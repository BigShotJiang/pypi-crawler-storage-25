from __future__ import annotations

import json
from pathlib import Path

from sdetkit import cli
from sdetkit import phase1_hardening_29 as d29


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-phase1-hardening.md\nphase1-hardening\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "impact-29-ultra-upgrade-report.md\nintegrations-phase1-hardening.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Phase-1 hardening:** close stale docs gaps and polish top entry pages.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-weekly-review.md").write_text(
        "# Weekly review #4 ()\n", encoding="utf-8"
    )
    (root / "docs/integrations-phase1-hardening.md").write_text(
        d29._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/impact-29-ultra-upgrade-report.md").write_text("#  report\n", encoding="utf-8")


def test_phase1_hardening_hardening_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d29.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "phase1-hardening"
    assert out["summary"]["activation_score"] >= 90


def test_phase1_hardening_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d29.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/phase1-hardening-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/phase1-hardening-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (tmp_path / "artifacts/phase1-hardening-pack/phase1-hardening-summary.json").exists()
    assert (tmp_path / "artifacts/phase1-hardening-pack/phase1-hardening-summary.md").exists()
    assert (tmp_path / "artifacts/phase1-hardening-pack/phase1-hardening-stale-gaps.json").exists()
    assert (
        tmp_path / "artifacts/phase1-hardening-pack/phase1-hardening-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/phase1-hardening-pack/evidence/phase1-hardening-execution-summary.json"
    ).exists()


def test_phase1_hardening_strict_fails_when_sections_missing(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (tmp_path / "docs/integrations-phase1-hardening.md").write_text(
        "#  — Phase-1 hardening\n", encoding="utf-8"
    )
    rc = d29.main(["--root", str(tmp_path), "--strict", "--format", "json"])
    assert rc == 1


def test_phase1_hardening_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["phase1-hardening", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert " phase-1 hardening summary" in capsys.readouterr().out
