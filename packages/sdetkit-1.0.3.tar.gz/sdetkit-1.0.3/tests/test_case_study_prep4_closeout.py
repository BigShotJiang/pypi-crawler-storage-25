from __future__ import annotations

import json
from pathlib import Path

from sdetkit import case_study_prep4_closeout_72 as d72
from sdetkit import cli


def _seed_repo(root: Path) -> None:

    (root / "templates/ci/gitlab").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/jenkins").mkdir(parents=True, exist_ok=True)

    (root / "templates/ci/tekton").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/plans").mkdir(parents=True, exist_ok=True)

    (root / "docs/roadmap/reports").mkdir(parents=True, exist_ok=True)

    (root / "docs/artifacts").mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(
        "docs/integrations-case-study-prep4-closeout.md\ncase-study-prep4-closeout\n",
        encoding="utf-8",
    )
    (root / "docs").mkdir(parents=True, exist_ok=True)
    (root / "docs/index.md").write_text(
        "-72-big-upgrade-report.md\nintegrations-case-study-prep4-closeout.md\n",
        encoding="utf-8",
    )
    (root / "docs/top-10-github-strategy.md").write_text(
        "- ** — Case-study prep #4:** lock publication-quality evidence and publication readiness handoff.\n"
        "- ** — Publication launch:** convert  outputs into externally shareable case study assets.\n",
        encoding="utf-8",
    )
    (root / "docs/integrations-case-study-prep4-closeout.md").write_text(
        d72._DEFAULT_PAGE_TEMPLATE, encoding="utf-8"
    )
    (root / "docs/big-upgrade-report-72.md").write_text("#  report\n", encoding="utf-8")

    summary = (
        root
        / "docs/artifacts/case-study-prep3-closeout-pack/case-study-prep3-closeout-summary.json"
    )
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        json.dumps(
            {
                "summary": {"activation_score": 100, "strict_pass": True},
                "checks": [{"passed": True}],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    board = (
        root / "docs/artifacts/case-study-prep3-closeout-pack/case-study-prep3-delivery-board.md"
    )
    board.write_text(
        "\n".join(
            [
                "#  delivery board",
                "- [ ]  integration brief committed",
                "- [ ]  triage-speed case-study narrative published",
                "- [ ]  controls and assumptions log exported",
                "- [ ]  KPI scorecard snapshot exported",
                "- [ ]  publication launch priorities drafted from  learnings",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    case_study = root / "docs/roadmap/plans/publication-quality-case-study.json"
    case_study.write_text(
        json.dumps(
            {
                "case_id": "case-study-prep4-publication-quality-001",
                "metric": "publication-quality-score",
                "baseline": {"score": 61.4},
                "after": {"score": 84.9},
                "confidence": 0.91,
                "owner": "quality-systems",
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def test_lane72_json(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = d72.main(["--root", str(tmp_path), "--format", "json", "--strict"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["name"] == "case-study-prep4-closeout"
    assert out["summary"]["activation_score"] >= 95


def test_lane72_emit_pack_and_execute(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    rc = d72.main(
        [
            "--root",
            str(tmp_path),
            "--emit-pack-dir",
            "artifacts/case-study-prep4-closeout-pack",
            "--execute",
            "--evidence-dir",
            "artifacts/case-study-prep4-closeout-pack/evidence",
            "--format",
            "json",
            "--strict",
        ]
    )
    assert rc == 0
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-closeout-summary.json"
    ).exists()
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-closeout-summary.md"
    ).exists()
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-integration-brief.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-case-study-narrative.md"
    ).exists()
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-controls-log.json"
    ).exists()
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-kpi-scorecard.json"
    ).exists()
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-execution-log.md"
    ).exists()
    assert (
        tmp_path / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-delivery-board.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/case-study-prep4-closeout-pack/case-study-prep4-validation-commands.md"
    ).exists()
    assert (
        tmp_path
        / "artifacts/case-study-prep4-closeout-pack/evidence/case-study-prep4-execution-summary.json"
    ).exists()


def test_lane72_strict_fails_without_prior_closeout(tmp_path: Path) -> None:
    _seed_repo(tmp_path)
    (
        tmp_path
        / "docs/artifacts/case-study-prep3-closeout-pack/case-study-prep3-closeout-summary.json"
    ).unlink()
    assert d72.main(["--root", str(tmp_path), "--strict", "--format", "json"]) == 1


def test_lane72_cli_dispatch(tmp_path: Path, capsys) -> None:
    _seed_repo(tmp_path)
    rc = cli.main(["case-study-prep4-closeout", "--root", str(tmp_path), "--format", "text"])
    assert rc == 0
    assert "Case Study Prep4 Closeout summary" in capsys.readouterr().out
