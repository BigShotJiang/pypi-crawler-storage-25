from __future__ import annotations

import json
from pathlib import Path

from sdetkit import doctor, review
from sdetkit.artifact_contract_index import INDEX_SCHEMA_VERSION, build_index, write_index
from sdetkit.checks import artifacts as check_artifacts


def test_artifact_contract_index_schema_versions_are_in_sync() -> None:
    payload = build_index()
    assert payload["schema_version"] == INDEX_SCHEMA_VERSION

    entries = {item["id"]: item for item in payload["artifacts"]}
    assert entries["doctor-json"]["schema_version"] == doctor.SCHEMA_VERSION
    assert entries["doctor-evidence-json"]["schema_version"] == doctor.EVIDENCE_SCHEMA_VERSION
    assert (
        entries["doctor-evidence-manifest-json"]["schema_version"]
        == doctor.EVIDENCE_MANIFEST_SCHEMA_VERSION
    )
    assert entries["review-json"]["schema_version"] == review.SCHEMA_VERSION
    assert (
        entries["checks-verdict-json"]["schema_version"] == check_artifacts.VERDICT_SCHEMA_VERSION
    )
    assert (
        entries["checks-fix-plan-json"]["schema_version"] == check_artifacts.FIX_PLAN_SCHEMA_VERSION
    )
    assert (
        entries["checks-risk-summary-json"]["schema_version"]
        == check_artifacts.RISK_SUMMARY_SCHEMA_VERSION
    )
    assert (
        entries["checks-evidence-zip"]["schema_version"] == check_artifacts.EVIDENCE_SCHEMA_VERSION
    )


def test_artifact_contract_index_includes_canonical_gate_artifacts() -> None:
    payload = build_index()
    entries = {item["id"]: item for item in payload["artifacts"]}

    for artifact_id in ("gate-fast-json", "release-preflight-json"):
        assert artifact_id in entries
        required = set(entries[artifact_id]["required_fields"])
        assert {"ok", "failed_steps", "profile"}.issubset(required)


def test_artifact_contract_index_docs_json_matches_generator_payload() -> None:
    docs_payload = json.loads(Path("docs/artifact-contract-index.json").read_text(encoding="utf-8"))
    assert docs_payload == build_index()


def test_artifact_contract_index_write_index_roundtrip(tmp_path: Path) -> None:
    out = tmp_path / "artifact-contract-index.json"
    write_index(out)
    payload = json.loads(out.read_text(encoding="utf-8"))
    assert payload == build_index()
