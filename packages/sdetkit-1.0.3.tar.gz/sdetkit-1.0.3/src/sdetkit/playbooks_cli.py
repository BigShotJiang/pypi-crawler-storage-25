from __future__ import annotations

import argparse
import json
import re
import sys
from collections.abc import Sequence
from importlib import import_module
from pathlib import Path

RECOMMENDED_PLAYBOOKS: list[str] = [
    "onboarding",
    "onboarding-optimization",
    "weekly-review",
    "evidence-assets",
    "demo",
    "first-contribution",
    "contributor-funnel",
    "triage-templates",
    "startup-readiness",
    "enterprise-readiness",
    "github-actions-onboarding",
    "gitlab-ci-onboarding",
    "contribution-quality-report",
    "reliability-evidence-pack",
    "objection-handling",
    "community-activation",
    "external-contribution",
    "kpi-audit",
]

CORE_COMMANDS: set[str] = {
    "kv",
    "apiget",
    "cassette-get",
    "doctor",
    "gate",
    "ci",
    "patch",
    "repo",
    "dev",
    "report",
    "maintenance",
    "agent",
    "security",
    "ops",
    "notify",
}

DOC_AND_GOV_COMMANDS: set[str] = {
    "docs-quality",
    "docs-governance",
    "roadmap",
    "policy",
    "evidence",
    "release-communications",
    "release-readiness",
    "trust-assets",
}

RESERVED_NAMES: set[str] = (
    {"baseline", "playbooks"} | CORE_COMMANDS | DOC_AND_GOV_COMMANDS | set(RECOMMENDED_PLAYBOOKS)
)

_SERIES_PREFIX = re.compile("^(?:impact|)\\d+_")
_SERIES_CLOSEOUT = re.compile(r"^(.+_closeout)(?:_\d+)?$")

# Stable product lanes promoted from legacy numeric-series naming.
_PRODUCT_CANONICAL_BY_LEGACY_MODULE: dict[str, str] = {
    "weekly_review_28": "weekly-review-lane",
    "phase1_hardening_29": "phase1-hardening",
    "phase1_wrap_30": "phase1-wrap",
    "phase2_kickoff_31": "phase2-kickoff",
    "expansion_automation_41": "expansion-automation",
    # Two legacy modules would collide on optimization-closeout.
    "optimization_closeout_42": "optimization-closeout-foundation",
    "acceleration_closeout_43": "acceleration-closeout",
    "scale_closeout_44": "scale-closeout",
    "expansion_closeout_45": "expansion-closeout",
    "optimization_closeout_46": "optimization-closeout",
    "reliability_closeout_47": "reliability-closeout",
    "objection_closeout_48": "objection-closeout",
    "weekly_review_closeout_49": "weekly-review-closeout",
    "execution_prioritization_closeout_50": "execution-prioritization-closeout",
    "weekly_review_closeout_65": "weekly-review-closeout-2",
}

_PLAYBOOK_MODULE_BY_CANONICAL: dict[str, str] = {
    "evidence-assets": "proof",
    "onboarding-optimization": "onboarding_optimization",
    "external-contribution": "external_contribution",
    "objection-handling": "objection_handling",
    "startup-readiness": "startup_readiness",
    "enterprise-readiness": "enterprise_readiness",
    "github-actions-onboarding": "github_actions_quickstart",
    "gitlab-ci-onboarding": "gitlab_ci_quickstart",
    "contribution-quality-report": "quality_contribution_delta",
    "release-communications": "release_communications",
}

_PLAYBOOK_ALIAS_TO_CANONICAL: dict[str, str] = {
    "proof": "evidence-assets",
    "github-actions-quickstart": "github-actions-onboarding",
    "gitlab-ci-quickstart": "gitlab-ci-onboarding",
    "quality-contribution-delta": "contribution-quality-report",
}


def _contains_day_token(name: str) -> bool:
    return "" in re.split(r"[^a-z0-9]+", name.lower())


def _cmd_to_mod(cmd: str) -> str:
    return cmd.replace("-", "_")


def _mod_to_cmd(mod: str) -> str:
    return mod.replace("_", "-")


def _pkg_dir() -> Path:
    import sdetkit

    return Path(sdetkit.__file__).resolve().parent


def _is_legacy_module(mod: str) -> bool:
    if _SERIES_PREFIX.match(mod):
        return True
    if mod.endswith("_closeout"):
        return True
    if re.search(r"_closeout_\d+$", mod):
        return True
    if re.search(r"_\d+$", mod):
        return True
    return False


def _discover_legacy_modules(pkg_dir: Path) -> list[str]:
    mods: list[str] = []
    for p in pkg_dir.glob("*.py"):
        if not p.is_file():
            continue
        stem = p.stem
        if stem.startswith("__"):
            continue
        if stem in {"cli", "playbooks_cli"}:
            continue
        if _is_legacy_module(stem):
            mods.append(stem)
    return sorted(mods)


def _alias_for_series_closeout(mod: str) -> str | None:
    m = _SERIES_CLOSEOUT.match(mod)
    if not m:
        return None
    alias_mod = m.group(1)
    alias_cmd = _mod_to_cmd(alias_mod)
    if alias_cmd in RESERVED_NAMES:
        return None
    return alias_cmd


def _alias_for_series_module(mod: str) -> str | None:
    if not _SERIES_PREFIX.match(mod):
        return None
    alias_mod = _SERIES_PREFIX.sub("", mod, count=1)
    if not alias_mod:
        return None
    alias_cmd = _mod_to_cmd(alias_mod)
    if alias_cmd in RESERVED_NAMES:
        return None
    return alias_cmd


def _build_registry(pkg_dir: Path) -> tuple[dict[str, str], dict[str, str]]:
    cmd_to_mod: dict[str, str] = {}
    alias_to_canonical: dict[str, str] = {}

    for cmd in RECOMMENDED_PLAYBOOKS:
        mod = (
            _PLAYBOOK_MODULE_BY_CANONICAL[cmd]
            if cmd in _PLAYBOOK_MODULE_BY_CANONICAL
            else _cmd_to_mod(cmd)
        )
        if (pkg_dir / f"{mod}.py").exists():
            cmd_to_mod[cmd] = mod

    for alias, alias_canonical in _PLAYBOOK_ALIAS_TO_CANONICAL.items():
        alias_mod = cmd_to_mod.get(alias_canonical)
        if alias_mod is not None:
            alias_to_canonical[alias] = alias_canonical
            cmd_to_mod[alias] = alias_mod

    for mod in _discover_legacy_modules(pkg_dir):
        legacy_canonical = (
            _PRODUCT_CANONICAL_BY_LEGACY_MODULE.get(mod)
            or _alias_for_series_closeout(mod)
            or _alias_for_series_module(mod)
            or _mod_to_cmd(mod)
        )

        if legacy_canonical in cmd_to_mod and cmd_to_mod[legacy_canonical] != mod:
            legacy_canonical = _mod_to_cmd(mod)

        cmd_to_mod[legacy_canonical] = mod

    return cmd_to_mod, alias_to_canonical


def _apply_search_list(xs: list[str], search: str | None) -> list[str]:
    xs = [x for x in xs if not _contains_day_token(x)]
    if not search:
        return xs
    s = search.lower()
    if _contains_day_token(s):
        s = " ".join(tok for tok in re.split(r"[^a-z0-9]+", s) if tok != "")
        s = s.strip()
        if not s:
            return xs
    return [x for x in xs if s in x.lower()]


def _apply_search_aliases(d: dict[str, str], search: str | None) -> dict[str, str]:
    d = {k: v for k, v in d.items() if not _contains_day_token(k) and not _contains_day_token(v)}
    if not search:
        return d
    s = search.lower()
    if _contains_day_token(s):
        s = " ".join(tok for tok in re.split(r"[^a-z0-9]+", s) if tok != "")
        s = s.strip()
        if not s:
            return d
    return {k: v for k, v in d.items() if (s in k.lower()) or (s in v.lower())}


def _counts(payload: dict[str, object]) -> dict[str, int]:
    out: dict[str, int] = {}
    for k in ["recommended", "legacy", "aliases", "playbooks"]:
        v = payload.get(k)
        if isinstance(v, list):
            out[k] = len(v)
        elif isinstance(v, dict):
            out[k] = len(v)
        else:
            out[k] = 0
    return out


def _list_payload(
    *,
    want_recommended: bool,
    want_legacy: bool,
    want_aliases: bool,
    search: str | None,
) -> dict[str, object]:
    pkg_dir = _pkg_dir()
    cmd_to_mod, alias_to_canonical = _build_registry(pkg_dir)

    recommended = [c for c in RECOMMENDED_PLAYBOOKS if c in cmd_to_mod]
    recommended = _apply_search_list(recommended, search)

    legacy: list[str] = []
    for c in cmd_to_mod.keys():
        if c in recommended:
            continue
        if c in alias_to_canonical:
            continue
        mod = cmd_to_mod.get(c, "")
        if isinstance(mod, str) and _is_legacy_module(mod):
            legacy.append(c)
    legacy = sorted(_apply_search_list(legacy, search))

    aliases = _apply_search_aliases(dict(sorted(alias_to_canonical.items())), search)
    all_names = sorted(
        _apply_search_list(
            sorted([n for n in cmd_to_mod.keys() if n not in alias_to_canonical]), search
        )
    )

    if want_recommended:
        payload: dict[str, object] = {
            "recommended": recommended,
            "legacy": [],
            "aliases": {},
            "playbooks": recommended,
        }
        payload["counts"] = _counts(payload)
        return payload

    if want_legacy:
        payload = {
            "recommended": [],
            "legacy": legacy,
            "aliases": {},
            "playbooks": legacy,
        }
        payload["counts"] = _counts(payload)
        return payload

    if want_aliases:
        alias_names = sorted(list(aliases.keys()))
        payload = {
            "recommended": [],
            "legacy": [],
            "aliases": aliases,
            "playbooks": alias_names,
        }
        payload["counts"] = _counts(payload)
        return payload

    payload = {
        "recommended": recommended,
        "legacy": legacy,
        "aliases": aliases,
        "playbooks": all_names,
    }
    payload["counts"] = _counts(payload)
    return payload


def _print_text(payload: dict[str, object]) -> None:
    recommended = payload.get("recommended", [])
    legacy = payload.get("legacy", [])
    aliases = payload.get("aliases", {})

    print("Recommended playbooks:")
    if isinstance(recommended, list) and recommended:
        for n in recommended:
            print(f"  {n}")
    else:
        print("  (none)")
    print("")
    print("Experimental (transition-era) workflows:")
    if isinstance(legacy, list) and legacy:
        for n in legacy:
            print(f"  {n}")
    else:
        print("  (none)")
    if isinstance(aliases, dict) and aliases:
        print("")
        print("Aliases:")
        for k, v in sorted(aliases.items()):
            print(f"  {k} -> {v}")
    print("")
    print("Run: sdetkit playbooks run <name>")
    print("Tip: these commands still run directly, e.g. sdetkit <name> --help")


def _cmd_list(ns: argparse.Namespace) -> int:
    payload = _list_payload(
        want_recommended=bool(getattr(ns, "recommended", False)),
        want_legacy=bool(getattr(ns, "legacy", False)),
        want_aliases=bool(getattr(ns, "aliases", False)),
        search=getattr(ns, "search", None),
    )

    fmt = getattr(ns, "format", "text")
    if fmt == "json":
        sys.stdout.write(json.dumps(payload, sort_keys=True, indent=2) + "\n")
        return 0

    _print_text(payload)
    return 0


def _cmd_run(ns: argparse.Namespace) -> int:
    pkg_dir = _pkg_dir()
    cmd_to_mod, _alias_to_canonical = _build_registry(pkg_dir)

    name = getattr(ns, "name", "")
    if not isinstance(name, str) or name not in cmd_to_mod:
        sys.stderr.write("playbooks: unknown name\n")
        return 2

    mod_name = cmd_to_mod[name]
    m = import_module(f"sdetkit.{mod_name}")
    fn = getattr(m, "main", None)
    if not callable(fn):
        sys.stderr.write("playbooks: unknown name\n")
        return 2

    args = list(getattr(ns, "args", []) or [])
    if args and args[0] == "--":
        args = args[1:]
    return int(fn(args))


def _selected_playbooks(
    ns: argparse.Namespace,
    all_names: list[str],
    alias_to_canonical: dict[str, str],
) -> list[str]:
    if ns.all:
        return all_names
    if ns.recommended:
        return sorted([n for n in RECOMMENDED_PLAYBOOKS if n in all_names])
    if ns.legacy:
        return [
            n
            for n in all_names
            if n.startswith("impact") or n.endswith("-closeout") or "-closeout-" in n
        ]
    if ns.aliases:
        return sorted(alias_to_canonical.keys())

    explicit = sorted(set(ns.name or []))
    if explicit:
        return explicit
    return sorted([n for n in RECOMMENDED_PLAYBOOKS if n in all_names])


def _cmd_validate(ns: argparse.Namespace) -> int:
    pkg_dir = _pkg_dir()
    cmd_to_mod, alias_to_canonical = _build_registry(pkg_dir)
    all_names = sorted(cmd_to_mod.keys())
    selected = _selected_playbooks(ns, all_names, alias_to_canonical)

    for name in selected:
        if name not in cmd_to_mod:
            sys.stderr.write("playbooks: unknown name\n")
            return 2

    results: list[dict[str, object]] = []
    failed: list[str] = []
    for name in selected:
        mod_name = cmd_to_mod[name]
        error: str | None = None
        ok = True
        try:
            module = import_module(f"sdetkit.{mod_name}")
            fn = getattr(module, "main", None)
            if not callable(fn):
                ok = False
                error = "missing callable main"
        except Exception as exc:  # pragma: no cover - defensive fallback
            ok = False
            error = str(exc)
        if not ok:
            failed.append(name)
        results.append(
            {
                "name": name,
                "module": mod_name,
                "canonical": alias_to_canonical.get(name, name),
                "ok": ok,
                "error": error,
            }
        )

    payload = {
        "ok": not bool(failed),
        "counts": {"selected": len(selected), "failed": len(failed)},
        "failed": failed,
        "results": results,
    }

    if ns.format == "json":
        sys.stdout.write(json.dumps(payload, sort_keys=True, indent=2) + "\n")
    else:
        sys.stdout.write(f"playbooks validate: {'OK' if payload['ok'] else 'FAIL'}\n")
        for item in results:
            marker = "OK" if item["ok"] else "FAIL"
            sys.stdout.write(f"[{marker}] {item['name']}\n")

    return 0 if payload["ok"] else 2


def main(argv: Sequence[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]
    argv = list(argv)
    if not argv:
        argv = ["list"]

    p = argparse.ArgumentParser(
        prog="sdetkit playbooks",
        description="Discover, run, and validate recommended adoption and rollout playbooks.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    listp = sub.add_parser(
        "list",
        help="List recommended playbooks, legacy catalog entries, and aliases.",
        description="List recommended playbooks, legacy catalog entries, and aliases.",
    )
    listp.add_argument("--format", choices=["text", "json"], default="text")
    g = listp.add_mutually_exclusive_group()
    g.add_argument("--recommended", action="store_true")
    g.add_argument("--legacy", action="store_true")
    g.add_argument("--aliases", action="store_true")
    listp.add_argument("--search", default=None)
    listp.set_defaults(_handler=_cmd_list)

    runp = sub.add_parser(
        "run",
        help="Run a playbook by catalog name.",
        description="Run a playbook by catalog name.",
    )
    runp.add_argument("name")
    runp.add_argument("args", nargs=argparse.REMAINDER)
    runp.set_defaults(_handler=_cmd_run)

    validatep = sub.add_parser(
        "validate",
        help="Validate that selected playbooks are importable and expose callable main().",
        description="Validate that selected playbooks are importable and expose callable main().",
    )
    validatep.add_argument("--format", choices=["text", "json"], default="text")
    group = validatep.add_mutually_exclusive_group()
    group.add_argument("--recommended", action="store_true")
    group.add_argument("--legacy", action="store_true")
    group.add_argument("--aliases", action="store_true")
    group.add_argument("--all", action="store_true")
    validatep.add_argument("--name", action="append", default=[])
    validatep.set_defaults(_handler=_cmd_validate)

    ns = p.parse_args(argv)
    h = getattr(ns, "_handler", None)
    if not callable(h):
        return 2
    return int(h(ns))
