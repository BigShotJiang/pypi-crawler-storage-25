from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any, cast

_PAGE_PATH = "docs/integrations-github-actions-quickstart.md"

_SECTION_HEADER = "# GitHub Actions quickstart"
_REQUIRED_SECTIONS = [
    "## Who this recipe is for",
    "## 5-minute setup",
    "## Minimal workflow",
    "## Strict workflow variant",
    "## Nightly reliability variant",
    "## Fast verification commands",
    "## Multi-channel distribution loop",
    "## Failure recovery playbook",
    "## Rollout checklist",
]

_REQUIRED_COMMANDS = [
    "python -m sdetkit doctor --format text",
    "python -m sdetkit repo audit --format json",
    "python -m pytest -q tests/test_github_actions_quickstart.py tests/test_cli_help_lists_subcommands.py",
    "python scripts/check_github_actions_onboarding_contract.py",
    "python -m sdetkit github-actions-onboarding --execute --evidence-dir docs/artifacts/github-actions-onboarding-pack/evidence --format json --strict",
]


def _workflow_content(variant: str) -> str:
    if variant == "strict":
        return """name: sdetkit-github-strict
on:
  pull_request:
  workflow_dispatch:

jobs:
  strict-gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m pip install -r requirements-test.txt -e .
      - run: python -m pytest -q tests/test_cli_sdetkit.py tests/test_github_actions_quickstart.py tests/test_cli_help_lists_subcommands.py
      - run: python -m sdetkit github-actions-onboarding --format json --strict
      - run: python scripts/check_github_actions_onboarding_contract.py
"""

    if variant == "nightly":
        return """name: sdetkit-github-nightly
on:
  schedule:
    - cron: '0 4 * * *'
  workflow_dispatch:

jobs:
  nightly-audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m pip install -r requirements-test.txt -e .
      - run: python -m sdetkit doctor --format text
      - run: python -m sdetkit repo audit --format json
      - run: python -m sdetkit github-actions-onboarding --execute --evidence-dir docs/artifacts/github-actions-onboarding-pack/evidence --format json --strict
"""

    return """name: sdetkit-github-quickstart
on:
  pull_request:
  workflow_dispatch:

jobs:
  quality-gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m pip install -r requirements-test.txt -e .
      - run: python -m sdetkit github-actions-onboarding --format json --strict
      - run: python -m pytest -q tests/test_cli_sdetkit.py tests/test_github_actions_quickstart.py
"""


_DEFAULT_PAGE = f"""# GitHub Actions quickstart

A production-ready integration recipe to run `sdetkit` quality checks in GitHub Actions with quickstart, strict, and nightly variants.

## Who this recipe is for

- Maintainers who need CI guardrails in less than 5 minutes.
- Teams moving from local-only checks to PR gate automation.
- Contributors who want deterministic quality signals in pull requests.

## 5-minute setup

1. Add `.github/workflows/sdetkit-quickstart.yml` with the minimal workflow below.
2. Push a branch and open a pull request.
3. Confirm the quality-gate job passes before merge.

## Minimal workflow

```yaml
{_workflow_content("minimal").rstrip()}
```

## Strict workflow variant

```yaml
{_workflow_content("strict").rstrip()}
```

## Nightly reliability variant

```yaml
{_workflow_content("nightly").rstrip()}
```

## Fast verification commands

Run these locally before opening PRs:

```bash
python -m sdetkit doctor --format text
python -m sdetkit repo audit --format json
python -m pytest -q tests/test_github_actions_quickstart.py tests/test_cli_help_lists_subcommands.py
python scripts/check_github_actions_onboarding_contract.py
python -m sdetkit github-actions-onboarding --execute --evidence-dir docs/artifacts/github-actions-onboarding-pack/evidence --format json --strict
```

## Multi-channel distribution loop

1. Post merged workflow update in engineering chat with before/after CI timing.
2. Publish docs update in `docs/index.md` weekly rollout section.
3. Share one artifact (`github-actions-onboarding-execution-summary.json`) in team retro for adoption tracking.

## Failure recovery playbook

- If checks fail from missing docs content, run `--write-defaults` and rerun strict validation.
- If tests fail, keep quickstart lane blocking and move nightly lane to diagnostics-only until stable.
- If flaky behavior appears, attach evidence logs from `--execute --evidence-dir` to the incident thread.

## Rollout checklist

- [ ] Workflow is enabled on `pull_request` and `workflow_dispatch`.
- [ ] CI installs from `requirements-test.txt` and editable package source.
- [ ] GitHub Actions onboarding contract check is part of docs validation.
- [ ] Execution evidence bundle is generated weekly.
- [ ] Team channel has a pinned link to this quickstart page.
"""


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sdetkit github-actions-onboarding",
        description="Render and validate a GitHub Actions quickstart report.",
    )
    parser.add_argument(
        "--format",
        choices=["text", "markdown", "json"],
        default="text",
        help="Output format.",
    )
    parser.add_argument("--root", default=".", help="Repository root where docs live.")
    parser.add_argument(
        "--output",
        default="",
        help="Optional file path to also write the rendered GitHub Actions quickstart report.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Return non-zero when required quickstart content is missing.",
    )
    parser.add_argument(
        "--write-defaults",
        action="store_true",
        help="Write or repair the GitHub Actions quickstart page before validation.",
    )
    parser.add_argument(
        "--emit-pack-dir",
        default="",
        help="Optional directory to also write the GitHub Actions quickstart pack.",
    )
    parser.add_argument(
        "--variant",
        choices=["minimal", "strict", "nightly"],
        default="minimal",
        help="Workflow variant to render in the report.",
    )
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Run the required GitHub Actions command sequence and capture pass/fail details.",
    )
    parser.add_argument(
        "--evidence-dir",
        default="",
        help="Optional directory to also write execution summary JSON and command logs.",
    )
    parser.add_argument(
        "--timeout-sec",
        type=int,
        default=300,
        help="Per-command timeout in seconds for --execute mode.",
    )
    return parser


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _missing_checks(page_text: str) -> list[str]:
    checks = [
        _SECTION_HEADER,
        *_REQUIRED_SECTIONS,
        *_REQUIRED_COMMANDS,
        "name: sdetkit-github-quickstart",
        "name: sdetkit-github-strict",
        "name: sdetkit-github-nightly",
    ]
    return [item for item in checks if item not in page_text]


def _write_defaults(base: Path) -> list[str]:
    page = base / _PAGE_PATH
    current = _read(page)
    if current and not _missing_checks(current):
        return []

    page.parent.mkdir(parents=True, exist_ok=True)
    page.write_text(_DEFAULT_PAGE, encoding="utf-8")
    return [_PAGE_PATH]


def _emit_pack(base: Path, out_dir: str) -> list[str]:
    root = base / out_dir
    root.mkdir(parents=True, exist_ok=True)

    checklist = root / "github-actions-onboarding-checklist.md"
    checklist.write_text(
        "\n".join(
            [
                "# GitHub Actions onboarding rollout checklist",
                "",
                "- [ ] Validate quickstart page in strict mode.",
                "- [ ] Commit workflow files under .github/workflows/.",
                "- [ ] Verify PR run passes doctor, repo audit, and tests.",
                "- [ ] Generate evidence bundle from --execute mode.",
                "- [ ] Share workflow + evidence links in onboarding docs.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    minimal_workflow = root / "github-actions-sdetkit-quickstart.yml"
    minimal_workflow.write_text(_workflow_content("minimal"), encoding="utf-8")

    strict_workflow = root / "github-actions-sdetkit-strict.yml"
    strict_workflow.write_text(_workflow_content("strict"), encoding="utf-8")

    nightly_workflow = root / "github-actions-sdetkit-nightly.yml"
    nightly_workflow.write_text(_workflow_content("nightly"), encoding="utf-8")

    distribution_plan = root / "github-actions-distribution-plan.md"
    distribution_plan.write_text(
        "\n".join(
            [
                "# GitHub Actions distribution plan",
                "",
                "| Channel | Artifact | Owner | Cadence |",
                "| --- | --- | --- | --- |",
                "| Engineering Slack | quickstart workflow + execution summary | QE lead | weekly |",
                "| Docs portal | GitHub Actions onboarding page | Docs owner | weekly |",
                "| Sprint retro | evidence logs and failure themes | Team lead | bi-weekly |",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    validation = root / "github-actions-validation-commands.md"
    validation.write_text(
        "\n".join(
            ["# GitHub Actions validation commands", "", "```bash", *_REQUIRED_COMMANDS, "```", ""]
        )
        + "\n",
        encoding="utf-8",
    )

    return [
        str(path.relative_to(base))
        for path in (
            checklist,
            minimal_workflow,
            strict_workflow,
            nightly_workflow,
            distribution_plan,
            validation,
        )
    ]


def _execute_commands(commands: list[str], timeout_sec: int) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for idx, command in enumerate(commands, start=1):
        try:
            argv = shlex.split(command)
            if argv and argv[0] == "python":
                argv[0] = sys.executable
            proc = subprocess.run(
                argv,
                shell=False,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                check=False,
            )
            results.append(
                {
                    "index": idx,
                    "command": command,
                    "returncode": proc.returncode,
                    "ok": proc.returncode == 0,
                    "stdout": proc.stdout,
                    "stderr": proc.stderr,
                }
            )
        except subprocess.TimeoutExpired as exc:
            results.append(
                {
                    "index": idx,
                    "command": command,
                    "returncode": 124,
                    "ok": False,
                    "stdout": (exc.stdout or "") if isinstance(exc.stdout, str) else "",
                    "stderr": (exc.stderr or "") if isinstance(exc.stderr, str) else "",
                    "error": f"timed out after {timeout_sec}s",
                }
            )
    return results


def _write_execution_evidence(base: Path, out_dir: str, results: list[dict[str, Any]]) -> list[str]:
    root = base / out_dir
    root.mkdir(parents=True, exist_ok=True)

    summary = root / "github-actions-onboarding-execution-summary.json"
    payload = {
        "name": "github-actions-onboarding-execution",
        "total_commands": len(results),
        "passed_commands": len([r for r in results if r.get("ok")]),
        "failed_commands": len([r for r in results if not r.get("ok")]),
        "results": results,
    }
    summary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    emitted = [summary]
    for row in results:
        log_file = root / f"command-{row['index']:02d}.log"
        log_file.write_text(
            "\n".join(
                [
                    f"command: {row['command']}",
                    f"returncode: {row['returncode']}",
                    f"ok: {row['ok']}",
                    "--- stdout ---",
                    str(row.get("stdout", "")),
                    "--- stderr ---",
                    str(row.get("stderr", "")),
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        emitted.append(log_file)

    return [str(path.relative_to(base)) for path in emitted]


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    base = Path(args.root).resolve()

    touched = _write_defaults(base) if args.write_defaults else []
    page = base / _PAGE_PATH
    text = _read(page)

    missing = _missing_checks(text)
    total = len(
        [
            _SECTION_HEADER,
            *_REQUIRED_SECTIONS,
            *_REQUIRED_COMMANDS,
            "name: sdetkit-github-quickstart",
            "name: sdetkit-github-strict",
            "name: sdetkit-github-nightly",
        ]
    )
    passed = total - len(missing)
    score = round((passed / total) * 100, 1)

    payload: dict[str, Any] = {
        "name": "github-actions-onboarding",
        "page": _PAGE_PATH,
        "variant": args.variant,
        "selected_workflow": _workflow_content(args.variant),
        "required_sections": list(_REQUIRED_SECTIONS),
        "required_commands": list(_REQUIRED_COMMANDS),
        "passed_checks": passed,
        "total_checks": total,
        "score": score,
        "missing": missing,
        "touched_files": touched,
        "actions": {
            "open_page": _PAGE_PATH,
            "validate": "sdetkit github-actions-onboarding --format json --strict",
            "validate_strict_variant": "sdetkit github-actions-onboarding --format json --variant strict --strict",
            "write_defaults": "sdetkit github-actions-onboarding --write-defaults --format json --strict",
            "artifact": "sdetkit github-actions-onboarding --format markdown --variant strict --output docs/artifacts/github-actions-onboarding-sample.md",
            "emit_pack": "sdetkit github-actions-onboarding --emit-pack-dir docs/artifacts/github-actions-onboarding-pack --format json --strict",
            "execute": "sdetkit github-actions-onboarding --execute --evidence-dir docs/artifacts/github-actions-onboarding-pack/evidence --format json --strict",
        },
    }

    if args.emit_pack_dir:
        payload["pack_files"] = _emit_pack(base, args.emit_pack_dir)

    execution_failed = False
    if args.execute:
        commands = [
            "python -m sdetkit doctor --format text",
            "python -m sdetkit repo audit --format json",
            "python -m pytest -q tests/test_github_actions_quickstart.py tests/test_cli_help_lists_subcommands.py",
            "python -m sdetkit github-actions-onboarding --format json --strict",
        ]
        results = _execute_commands(commands, timeout_sec=args.timeout_sec)
        execution = {
            "total_commands": len(results),
            "passed_commands": len([r for r in results if r.get("ok")]),
            "failed_commands": len([r for r in results if not r.get("ok")]),
            "results": results,
        }
        payload["execution"] = execution
        execution_failed = int(cast(Any, execution["failed_commands"])) > 0

        evidence_dir = args.evidence_dir or "docs/artifacts/github-actions-onboarding-pack/evidence"
        payload["evidence_files"] = _write_execution_evidence(base, evidence_dir, results)

    if args.format == "json":
        rendered = json.dumps(payload, indent=2) + "\n"
    elif args.format == "markdown":
        lines = [
            "# GitHub Actions quickstart report",
            "",
            f"- Score: **{payload['score']}** ({payload['passed_checks']}/{payload['total_checks']})",
            f"- Page: `{payload['page']}`",
            f"- Variant: `{payload['variant']}`",
            "",
            "## Required sections",
            "",
        ]
        for item in payload["required_sections"]:
            lines.append(f"- `{item}`")
        lines.extend(["", "## Required commands", "", "```bash"])
        lines.extend(payload["required_commands"])
        lines.extend(["```", "", "## Selected workflow", "", "```yaml"])
        lines.extend(str(payload["selected_workflow"]).rstrip().splitlines())
        lines.extend(["```"])
        if payload.get("execution"):
            exec_data = payload["execution"]
            lines.extend(["", "## Execution summary", ""])
            lines.append(
                f"- Passed commands: **{exec_data['passed_commands']}**/{exec_data['total_commands']}"
            )
            lines.append(f"- Failed commands: **{exec_data['failed_commands']}**")
        if payload.get("evidence_files"):
            lines.extend(["", "## Evidence files", ""])
            for item in payload["evidence_files"]:
                lines.append(f"- `{item}`")
        if payload.get("pack_files"):
            lines.extend(["", "## Emitted pack files", ""])
            for item in payload["pack_files"]:
                lines.append(f"- `{item}`")
        lines.extend(["", "## Quickstart coverage gaps", ""])
        if payload["missing"]:
            for item in payload["missing"]:
                lines.append(f"- `{item}`")
        else:
            lines.append("- none")
        lines.extend(["", "## Actions", ""])
        lines.append(f"- Open page: `{payload['actions']['open_page']}`")
        lines.append(f"- Validate: `{payload['actions']['validate']}`")
        lines.append(
            f"- Validate strict variant: `{payload['actions']['validate_strict_variant']}`"
        )
        lines.append(f"- Write defaults: `{payload['actions']['write_defaults']}`")
        lines.append(f"- Export artifact: `{payload['actions']['artifact']}`")
        lines.append(f"- Emit pack: `{payload['actions']['emit_pack']}`")
        lines.append(f"- Execute: `{payload['actions']['execute']}`")
        rendered = "\n".join(lines) + "\n"
    else:
        lines = [
            "GitHub Actions quickstart report",
            f"Score: {payload['score']} ({payload['passed_checks']}/{payload['total_checks']})",
            "",
            f"Page: {payload['page']}",
            f"Variant: {payload['variant']}",
            "",
            "Required sections:",
        ]
        for idx, item in enumerate(payload["required_sections"], start=1):
            lines.append(f"{idx}. {item}")
        lines.extend(["", "Required commands:"])
        for cmd in payload["required_commands"]:
            lines.append(f"- {cmd}")
        lines.extend(["", "Selected workflow:", ""])
        lines.extend(str(payload["selected_workflow"]).rstrip().splitlines())
        if payload.get("execution"):
            exec_data = payload["execution"]
            lines.extend(["", "Execution summary:"])
            lines.append(f"- Passed: {exec_data['passed_commands']}/{exec_data['total_commands']}")
            lines.append(f"- Failed: {exec_data['failed_commands']}")
        if payload.get("evidence_files"):
            lines.extend(["", "Evidence files:"])
            for item in payload["evidence_files"]:
                lines.append(f"- {item}")
        if payload.get("pack_files"):
            lines.extend(["", "Emitted pack files:"])
            for item in payload["pack_files"]:
                lines.append(f"- {item}")
        if payload["missing"]:
            lines.extend(["", "Quickstart coverage gaps:"])
            for item in payload["missing"]:
                lines.append(f"- {item}")
        else:
            lines.extend(["", "Quickstart coverage gaps: none"])
        lines.extend(["", "Actions:"])
        lines.append(f"- Open page: {payload['actions']['open_page']}")
        lines.append(f"- Validate: {payload['actions']['validate']}")
        lines.append(f"- Validate strict variant: {payload['actions']['validate_strict_variant']}")
        lines.append(f"- Write defaults: {payload['actions']['write_defaults']}")
        lines.append(f"- Export artifact: {payload['actions']['artifact']}")
        lines.append(f"- Emit pack: {payload['actions']['emit_pack']}")
        lines.append(f"- Execute: {payload['actions']['execute']}")
        rendered = "\n".join(lines) + "\n"

    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")

    if args.strict and (missing or execution_failed):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
