from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from sdetkit.security import safe_path

from ..bools import coerce_bool
from .registry import checks_for_mode
from .types import CheckResult, MaintenanceContext

SCHEMA_VERSION = "1.0"
DETERMINISTIC_GENERATED_AT = "1970-01-01T00:00:00+00:00"
_UTC = getattr(dt, "UTC", dt.timezone(dt.timedelta(0)))


class StderrLogger:
    def info(self, message: str) -> None:
        sys.stderr.write(message + "\n")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sdetkit maintenance")
    parser.add_argument("--format", choices=["text", "json", "md"], default="text")
    parser.add_argument("--out", default=None)
    parser.add_argument("--mode", choices=["quick", "full"], default="quick")
    parser.add_argument("--fix", action="store_true")
    parser.add_argument("--deterministic", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument(
        "--include-check",
        action="append",
        default=None,
        help="Run only the named check(s). Can be passed multiple times.",
    )
    parser.add_argument(
        "--exclude-check",
        action="append",
        default=None,
        help="Skip the named check(s). Can be passed multiple times.",
    )
    parser.add_argument(
        "--jobs",
        type=int,
        default=1,
        help="Maximum number of checks to run in parallel (default: 1).",
    )
    return parser


def _render_text(report: dict[str, Any]) -> str:
    failing = [name for name, item in report["checks"].items() if not item["ok"]]
    lines = [
        f"maintenance score: {report['score']}",
        f"overall: {'PASS' if report['ok'] else 'FAIL'}",
        "checks:",
    ]
    for name in sorted(report["checks"]):
        check = report["checks"][name]
        lines.append(f"- {'OK' if check['ok'] else 'FAIL'} {name}: {check['summary']}")
        details = check.get("details", {})
        quality = details.get("quality", {}) if isinstance(details, dict) else {}
        if isinstance(quality, dict) and quality:
            lines.append(
                "    quality: "
                f"{quality.get('passed_checks', 0)} passed / "
                f"{quality.get('failed_checks', 0)} failed / "
                f"{quality.get('skipped_checks', 0)} skipped"
            )
        hint_samples = details.get("hint_samples", []) if isinstance(details, dict) else []
        if isinstance(hint_samples, list):
            for hint in hint_samples[:2]:
                lines.append(f"    hint: {hint}")
    if failing:
        lines.append("failing checks: " + ", ".join(sorted(failing)))
    return "\n".join(lines) + "\n"


def _md_escape_cell(value: Any) -> str:
    text = str(value).replace("\r\n", "\n").replace("\r", "\n").replace("\n", " ")
    return (
        text.replace("\\", "\\\\")
        .replace("|", "\\|")
        .replace("`", "\\`")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def _render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "## Maintenance Report",
        f"- overall: {'PASS' if report['ok'] else 'FAIL'}",
        f"- score: {report['score']}",
        f"- mode: {report['meta']['mode']}",
        "",
        "| Check | Status | Summary |",
        "| --- | --- | --- |",
    ]
    for name in sorted(report["checks"]):
        check = report["checks"][name]
        lines.append(
            f"| {_md_escape_cell(name)} | {'PASS' if check['ok'] else 'FAIL'} | {_md_escape_cell(check['summary'])} |"
        )
    lines.append("")
    lines.append("### Recommendations")
    for rec in report["recommendations"]:
        lines.append(f"- {_md_escape_cell(rec)}")
    lines.append("")
    lines.append("### Quality signals")
    has_quality = False
    for name in sorted(report["checks"]):
        check = report["checks"][name]
        details = check.get("details", {})
        if not isinstance(details, dict):
            continue
        quality = details.get("quality", {})
        if not isinstance(quality, dict) or not quality:
            continue
        has_quality = True
        lines.append(
            f"- `{_md_escape_cell(name)}`: {_md_escape_cell(quality.get('passed_checks', 0))} passed / "
            f"{_md_escape_cell(quality.get('failed_checks', 0))} failed / "
            f"{_md_escape_cell(quality.get('skipped_checks', 0))} skipped; pass rate {_md_escape_cell(str(quality.get('pass_rate', 0)))}%"
        )
    if not has_quality:
        lines.append("- No embedded quality summaries were reported.")
    lines.append("")
    lines.append("### Hint samples")
    has_hints = False
    for name in sorted(report["checks"]):
        check = report["checks"][name]
        details = check.get("details", {})
        if not isinstance(details, dict):
            continue
        hint_samples = details.get("hint_samples", [])
        if not isinstance(hint_samples, list) or not hint_samples:
            continue
        has_hints = True
        lines.append(f"- `{_md_escape_cell(name)}`")
        for hint in hint_samples[:3]:
            lines.append(f"  - {_md_escape_cell(hint)}")
    if not has_hints:
        lines.append("- No hint samples were reported.")
    return "\n".join(lines) + "\n"


def _write_output(path: str | None, content: str) -> None:
    if not path:
        return
    out_path = safe_path(Path.cwd(), path, allow_absolute=True)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(content, encoding="utf-8")


def _deterministic_generated_at(env: dict[str, str]) -> str:
    epoch = env.get("SOURCE_DATE_EPOCH")
    if epoch is None:
        return DETERMINISTIC_GENERATED_AT
    try:
        return dt.datetime.fromtimestamp(int(epoch), _UTC).isoformat()
    except (TypeError, ValueError, OSError, OverflowError):
        return DETERMINISTIC_GENERATED_AT


def _normalize_names(values: list[str] | None) -> list[str]:
    return sorted({value.strip() for value in values or [] if value.strip()})


def _select_checks(
    available_checks: list[tuple[str, Any]],
    *,
    include_checks: list[str] | None = None,
    exclude_checks: list[str] | None = None,
) -> list[tuple[str, Any]]:
    include = set(_normalize_names(include_checks))
    exclude = set(_normalize_names(exclude_checks))
    selected: list[tuple[str, Any]] = []
    for name, runner in available_checks:
        if include and name not in include:
            continue
        if name in exclude:
            continue
        selected.append((name, runner))
    return selected


def _run_check(name: str, runner: Any, ctx: MaintenanceContext) -> tuple[str, CheckResult, bool]:
    try:
        return name, runner(ctx), False
    except Exception as exc:
        return (
            name,
            CheckResult(
                ok=False,
                summary=f"check crashed: {exc}",
                details={"error": repr(exc)},
                actions=[],
            ),
            True,
        )


def _build_recommendations(checks: dict[str, dict[str, Any]]) -> list[str]:
    failing = sorted(name for name, item in checks.items() if not item["ok"])
    if not failing:
        return ["All maintenance checks passed."]

    recommendations = [f"Review failing checks: {', '.join(failing)}."]
    suggested_actions: list[str] = []
    for name in failing:
        actions = checks[name].get("actions", [])
        if not isinstance(actions, list):
            continue
        for action in actions:
            if not isinstance(action, dict):
                continue
            title = str(action.get("title", "")).strip()
            applied = coerce_bool(action.get("applied", False), default=False)
            if title and not applied:
                suggested_actions.append(title)
    if suggested_actions:
        unique_actions = sorted(dict.fromkeys(suggested_actions))
        recommendations.append(f"Suggested next actions: {', '.join(unique_actions[:5])}.")
    doctor_hints = checks.get("doctor_check", {}).get("details", {}).get("hint_samples", [])
    if isinstance(doctor_hints, list) and doctor_hints:
        recommendations.append(f"Doctor hint spotlight: {doctor_hints[0]}")
    return recommendations


def _build_report(
    ctx: MaintenanceContext,
    *,
    deterministic: bool = False,
    include_checks: list[str] | None = None,
    exclude_checks: list[str] | None = None,
    jobs: int = 1,
) -> dict[str, Any]:
    started = time.monotonic()
    checks: dict[str, dict[str, Any]] = {}
    crashes = False
    available_checks = checks_for_mode(ctx.mode)
    selected_checks = _select_checks(
        available_checks,
        include_checks=include_checks,
        exclude_checks=exclude_checks,
    )
    worker_count = max(1, jobs)

    if worker_count == 1 or len(selected_checks) <= 1:
        for name, runner in selected_checks:
            _, result, crashed = _run_check(name, runner, ctx)
            crashes = crashes or crashed
            checks[name] = result.as_dict()
    else:
        with ThreadPoolExecutor(max_workers=worker_count) as pool:
            futures = {
                pool.submit(_run_check, name, runner, ctx): name for name, runner in selected_checks
            }
            for future in as_completed(futures):
                name, result, crashed = future.result()
                crashes = crashes or crashed
                checks[name] = result.as_dict()

    checks = dict(sorted(checks.items()))
    passed = sum(1 for item in checks.values() if item["ok"])
    total = len(checks)
    score = 100 if total == 0 else round((passed / total) * 100)
    recommendations = _build_recommendations(checks)
    report = {
        "ok": all(item["ok"] for item in checks.values()),
        "score": score,
        "checks": checks,
        "recommendations": recommendations,
        "meta": {
            "schema_version": SCHEMA_VERSION,
            "generated_at": _deterministic_generated_at(ctx.env)
            if deterministic
            else dt.datetime.now(_UTC).isoformat(),
            "mode": ctx.mode,
            "fix": ctx.fix,
            "python": ctx.python_exe,
            "duration_seconds": 0.0 if deterministic else round(time.monotonic() - started, 3),
            "had_crash": crashes,
            "jobs": worker_count,
            "available_checks": [name for name, _runner in available_checks],
            "selected_checks": [name for name, _runner in selected_checks],
            "excluded_checks": _normalize_names(exclude_checks),
            "include_checks": _normalize_names(include_checks),
        },
    }
    return report


def _print_summary(report: dict[str, Any]) -> None:
    failing = [name for name, item in report["checks"].items() if not item["ok"]]
    if failing:
        sys.stdout.write(f"Score: {report['score']} | Failing: {', '.join(sorted(failing))}\n")
    else:
        sys.stdout.write(f"Score: {report['score']} | Failing: none\n")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    try:
        ns = parser.parse_args(argv)
    except SystemExit as exc:
        code = exc.code
        if isinstance(code, int):
            return code
        if code is None:
            return 0
        return 2

    env = dict(os.environ)
    if bool(ns.deterministic):
        env["SDETKIT_DETERMINISTIC"] = "1"

    ctx = MaintenanceContext(
        repo_root=Path.cwd(),
        python_exe=sys.executable,
        mode=ns.mode,
        fix=bool(ns.fix),
        env=env,
        logger=StderrLogger(),
    )

    try:
        report = _build_report(
            ctx,
            deterministic=bool(ns.deterministic),
            include_checks=ns.include_check,
            exclude_checks=ns.exclude_check,
            jobs=max(int(ns.jobs), 1),
        )
        rendered = {
            "json": json.dumps(report, sort_keys=True),
            "text": _render_text(report),
            "md": _render_markdown(report),
        }[ns.format]
        _write_output(ns.out, rendered)
        if ns.format == "json":
            sys.stdout.write(rendered + "\n")
        elif not ns.quiet:
            sys.stdout.write(_render_text(report))
        if ns.format != "json" and ns.out and not ns.quiet:
            _print_summary(report)
        if ns.out and ns.format == "json" and not ns.quiet:
            _print_summary(report)
        return 0 if report["ok"] else 1
    except Exception as exc:
        sys.stderr.write(f"maintenance execution error: {exc}\n")
        return 2
