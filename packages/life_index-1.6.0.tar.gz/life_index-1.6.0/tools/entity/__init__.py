"""Entity graph CLI package."""
