import pytest
import asyncio
import threading
import time
from unittest.mock import MagicMock, patch
from opencode_runtime import OpenCodeRuntime

# --- Mock Helper Classes to align with Spec ---

class MockEvent:
    def __init__(self, event_type, session_id, part_id, part_type=None, delta=None, status=None, tool_desc=None, tool_name="unknown_tool"):
        self.type = event_type
        self.properties = MagicMock()
        self.properties.sessionID = session_id
        
        if event_type == "message.part.updated":
            self.properties.part = MagicMock()
            self.properties.part.id = part_id
            self.properties.part.type = part_type
            self.properties.part.tool = tool_name
            
            # Handle state/status for tool calling
            self.properties.part.state = MagicMock()
            self.properties.part.state.status = status
            self.properties.part.state.metadata = {"description": tool_desc} if tool_desc else {}
        
        elif event_type == "message.part.delta":
            self.properties.partID = part_id
            self.properties.delta = delta

def mock_event_generator(events):
    """Simulates the SDK event.list() generator"""
    time.sleep(0.05)  # Time difference defense as per spec
    for e in events:
        yield e

# --- Test Suite ---

@pytest.mark.asyncio
async def test_scenario_a_multimodal_routing():
    """
    Scenario A: Verify routing of reasoning, tool_calling, and output.
    """
    base_url = "http://mock-api.com"
    runtime = OpenCodeRuntime(base_url)
    
    # Mock SDK Client
    mock_client = MagicMock()
    runtime.client = mock_client # Explicit assignment to avoid real network
    
    # Define the event sequence
    events = [
        MockEvent("message.part.updated", "s1", "p1", part_type="reasoning"),
        MockEvent("message.part.delta", "s1", "p1", delta="Hmm..."),
        MockEvent("message.part.updated", "s1", "p2", part_type="tool", status="running", tool_desc="Get Time"),
        MockEvent("message.part.updated", "s1", "p3", part_type="text"),
        MockEvent("message.part.delta", "s1", "p3", delta="Hello"),
    ]
    
    mock_client.event.list.return_value = mock_event_generator(events)
    
    # Mock session.chat to simulate network delay
    def side_effect(*args, **kwargs):
        time.sleep(0.3)
        return True
    mock_client.session.chat.side_effect = side_effect

    # Execute chat_stream
    results = []
    async with asyncio.timeout(5.0):
        async for chunk in runtime.chat_stream("s1", "Hello AI", "model_1", "prov_1"):
            results.append(chunk)

    # Assertions
    expected = [
        {"step": "thinking", "chunk": "Hmm..."},
        {"step": "tool_calling", "tool": "Get Time"},
        {"step": "output", "chunk": "Hello"},
    ]
    assert results == expected
    
    # Verify SDK call parameters (Rule 4.3)
    mock_client.session.chat.assert_called_once()
    args, kwargs = mock_client.session.chat.call_args
    assert args[0] == "s1"
    assert kwargs["model_id"] == "model_1"
    assert kwargs["extra_body"]["model"]["modelID"] == "model_1"

@pytest.mark.asyncio
async def test_scenario_b_fallback_and_error():
    """
    Scenario B: Verify unknown partID defaults to text and session errors are handled.
    """
    # Part 1: Unknown type fallback
    base_url = "http://mock-api.com"
    runtime_fallback = OpenCodeRuntime(base_url)
    mock_client_f = MagicMock()
    runtime_fallback.client = mock_client_f
    
    # Delta event without a preceding 'updated' event for p_unknown
    events_f = [
        MockEvent("message.part.delta", "s2", "p_unknown", delta="Fallback Text"),
    ]
    mock_client_f.event.list.return_value = mock_event_generator(events_f)
    mock_client_f.session.chat.return_value = True

    results_f = []
    async with asyncio.timeout(2.0):
        async for chunk in runtime_fallback.chat_stream("s2", "Test", "m", "p"):
            results_f.append(chunk)
    
    assert {"step": "output", "chunk": "Fallback Text"} in results_f

    # Part 2: Session Error Handling
    runtime_err = OpenCodeRuntime(base_url)
    mock_client_e = MagicMock()
    runtime_err.client = mock_client_e
    
    # session.chat raises exception
    mock_client_e.session.chat.side_effect = Exception("API Connection Failed")
    mock_client_e.event.list.return_value = mock_event_generator([])

    results_e = []
    async with asyncio.timeout(2.0):
        async for chunk in runtime_err.chat_stream("s3", "Test", "m", "p"):
            results_e.append(chunk)
    
    # Should yield an error dict and then terminate
    assert len(results_e) == 1
    assert results_e[0]["step"] == "error"
    assert "API Connection Failed" in results_e[0]["chunk"]

@pytest.mark.asyncio
async def test_tool_deduplication():
    """
    Verify that the same tool partID is not reported multiple times (Rule 2).
    """
    base_url = "http://mock-api.com"
    runtime = OpenCodeRuntime(base_url)
    mock_client = MagicMock()
    runtime.client = mock_client
    
    # Two updated events for the same tool partID
    events = [
        MockEvent("message.part.updated", "s4", "p_tool", part_type="tool", status="running", tool_desc="Search"),
        MockEvent("message.part.updated", "s4", "p_tool", part_type="tool", status="running", tool_desc="Search"),
    ]
    mock_client.event.list.return_value = mock_event_generator(events)
    mock_client.session.chat.return_value = True

    results = []
    async with asyncio.timeout(2.0):
        async for chunk in runtime.chat_stream("s4", "Test", "m", "p"):
            results.append(chunk)
    
    # Should only appear once
    tool_calls = [r for r in results if r.get("step") == "tool_calling"]
    assert len(tool_calls) == 1