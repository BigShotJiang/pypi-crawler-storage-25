from opencode_ai import Opencode

client = Opencode(
    base_url="http://localhost:4096",
)

sessions = client.session.list()

# Determine collection type (list or paginated)
if isinstance(sessions, list):
    session_list = sessions
elif hasattr(sessions, "data"):
    session_list = sessions.data
else:
    session_list = list(sessions)

print(f"{'ID':<45} {'Title':<40}")
print("-" * 95)
for s in session_list:
    title = getattr(s, "title", "") or ""
    sid = getattr(s, "id", str(s))
    status = getattr(s, "status", "unknown") or "unknown"
    print(f"{sid:<45} {title:<40}")
