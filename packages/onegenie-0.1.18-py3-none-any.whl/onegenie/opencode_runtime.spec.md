## 1. 模組概述 (Overview)
本模組為 OneGenie Agent 對接 OpenCode 的單一入口組件。
**[架構職責]**：
- 封裝官方 `opencode_ai.Opencode` SDK。
- 利用背景 Thread 監聽全域事件。
- **[新功能]** 實作狀態追蹤 (State Tracking)：追蹤 `partID` 的事件型別，將零碎的 SDK 事件轉換為 OneGenie 支援的結構化 JSON Dictionary (`text`, `thinking`, `tool_calling`) 進行路由派發。

## 2. 依賴項 (Dependencies)
- 外部套件：`from opencode_ai import Opencode`
- 標準庫：`asyncio`, `threading`, `logging`, `typing`.

## 3. 介面定義 (Interface)

```python
import asyncio
import threading
import logging
from typing import AsyncGenerator
from opencode_ai import Opencode

class OpenCodeRuntime:
    def __init__(self, base_url: str):
        pass

    async def chat_stream(self, session_id: str, prompt: str, model_id: str, provider_id: str) -> AsyncGenerator[dict, None]:
        """單一對外介面：非同步接收結構化的 Dictionary 串流"""
        pass
```

## 4. 內部實作規則 (Rules & Expected Behavior)

### Rule 1: 狀態初始化
- `__init__` 中需初始化：
  - `self.client = Opencode(base_url=base_url)`
  - `self.active_queues: dict[str, asyncio.Queue] = {}`
  - `self._listener_lock = threading.Lock()`
  - `self._listener_thread = None`
  - **[新增]** `self._part_types: dict[str, str] = {}` (快取 partID 對應的 type)
  - **[新增]** `self._reported_tools: set[str] = set()` (防止工具呼叫被重複 Yield)

### Rule 2: 全域事件監聽器與狀態機 (The Multiplexer Worker)
內部方法 `_listener_worker(self, loop: asyncio.AbstractEventLoop)` 的邏輯必須嚴格遵守以下條件分支：
- 呼叫 `stream = self.client.event.list()` 並迭代。
- **[事件 A] 當 `event.type == "message.part.updated"` 時**：
  1. 取出 `props = getattr(event, "properties", None)`。
  2. 取出 `session_id = getattr(props, "sessionID", None)` 與 `part = getattr(props, "part", None)`。
  3. 取出 `part_id = getattr(part, "id", None)` 與 `part_type = getattr(part, "type", None)`。
  4. 若皆存在，寫入快取：`self._part_types[part_id] = part_type`。
  5. **工具呼叫處理**：若 `part_type == "tool"` 且 `part_id not in self._reported_tools`：
     - 取出 `state = getattr(part, "state", None)`。
     - 取出 `status = getattr(state, "status", "")`。
      - 若 `status == "running"`：
        - 從 `state.metadata.get("description")` 嘗試取得描述。
        - 若描述為 `unknown_tool`，則根據 `part.tool` 決定：
          - 若 `tool == "skill"`，則從 `state.input` 取得 `name` 並組裝為 `"Using skill: {Name}"`。
          - 否則，將 `tool` 名稱標題化組裝為 `"Using tool: {ToolName}"`。
        - 組裝訊息：`msg = {"step": "tool_calling", "tool": description}`。
       - 標記已回報：`self._reported_tools.add(part_id)`。
       - 若 `session_id` 在 `self.active_queues` 中，使用 `loop.call_soon_threadsafe(queue.put_nowait, msg)`。

- **[事件 B] 當 `event.type == "message.part.delta"` 時**：
  1. 取出 `props = getattr(event, "properties", None)`。
  2. 取出 `session_id = getattr(props, "sessionID", None)`。
  3. 取出 `part_id = getattr(props, "partID", None)` 與 `delta = getattr(props, "delta", None)`。
  4. 若 `delta` 存在且 `session_id` 在 `self.active_queues` 中：
     - 查詢型別：`p_type = self._part_types.get(part_id, "text")` (預設為 text)。
     - 若為 reasoning：`msg = {"step": "thinking", "chunk": delta}`。
     - 若為 text：`msg = {"step": "output", "chunk": delta}`。
     - 使用 `loop.call_soon_threadsafe(queue.put_nowait, msg)`。

### Rule 3: 懶加載監聽器 (Lazy Initialization)
必須實作一個 async 內部方法 `_ensure_listener_running(self)`：
1. **[CRITICAL]** 必須在最外層（切換 Thread 之前）先取得當前的 Event Loop：`loop = asyncio.get_running_loop()`。
2. 宣告一個同步函數 `start_thread()`：
   - 使用 `with self._listener_lock:` 確保 Thread Safe。
   - 若 `self._listener_thread is None`，建立 `threading.Thread(target=self._listener_worker, args=(loop,), daemon=True)` 並 `start()`。
3. 呼叫 `await asyncio.to_thread(start_thread)` 執行該同步函數（或者因為啟動 Thread 不會阻塞，直接呼叫 `start_thread()` 亦可）。

### Rule 4: chat_stream 核心生命週期 (Pub/Sub Flow)
呼叫 `chat_stream` 時，必須嚴格依序執行：
1. **註冊信箱 (先建信箱)**：建立 `queue = asyncio.Queue()`，並將其放入 `self.active_queues[session_id] = queue`。
2. **啟動監聽 (再啟動背景執行緒)**：`await self._ensure_listener_running()`。
3. **異步啟動請求 (Background Task)**：
   - **[CRITICAL 防止卡死]** 使用 `_task = asyncio.create_task(send_request())` 啟動，必須指派給變數 `_task` 防止 GC。
   - **[CRITICAL SDK 參數綁定]** `send_request` 內部使用 `to_thread` 呼叫 `session.chat`。第一個參數為位置參數，且**必須包含 `extra_body` 以配合 API 改版**：
     ```python
     await asyncio.to_thread(
         self.client.session.chat,
         session_id,
         parts=[{"type": "text", "text": prompt}],
         model_id=model_id,
         provider_id=provider_id,
         extra_body={
             "model": {
                 "modelID": model_id,
                 "providerID": provider_id,
             }
         }
     )
     ```
    - `finally` 區塊中，出錯則發送 `error` dict。最後必須發送 `None` 結束訊號，但在發送前必須 `await asyncio.sleep(0.5)` 以確保所有非同步事件（如最後的文本輸出與完成狀態）已由監聽執行緒處理完畢並放入 Queue。

4. **建立連線緩衝**：在啟動背景 Task 後，主流程必須 **`await asyncio.sleep(0.5)`**，以確保背景監聽執行緒有足夠時間建立 SSE 連線。
5. **開始消費串流 (Consumer Loop)**：
   - 進入 `while True:` 迴圈呼叫 `chunk = await queue.get()`。
   - 若 `chunk is None`，代表對話結束，`break` 離開迴圈。
   - 否則 `yield chunk`。
6. **資源清理**：在最外層 `finally` 中移除 `self.active_queues[session_id]`。

## 5. 測試場景 (Test Scenarios / Red Team)

> **[TO TESTER AI] CRITICAL RULE**:
> 1. **[實例修補陷阱]**：由於 `OpenCodeRuntime` 在 `__init__` 中即建立了 `self.client`。在測試中，你必須顯式地將 Mock 實例指派給 `runtime.client`，否則程式會連往真實網路導致卡死。
> 2. **[MockEvent 結構對齊]**：`part` 物件必須掛在 `event.properties` 之下。
> 3. **[時間差防禦]**：`session.chat` Mock 必須 `time.sleep(0.3)`。`event.list` Mock 必須先 `time.sleep(0.05)` 再 yield 事件。
> 4. **[嚴禁錯誤的 wait_for 語法]**：
>    - **[CRITICAL]** 絕對不可寫出 `async for x in asyncio.wait_for(...)` 這種語法，這會引發 TypeError。
>    - 若需測試超時，請將 `async for` 迴圈放在 `async with asyncio.timeout(2.0):` 區塊內。
> 5. **[非同步檢查]**：驗證 `chat_stream` 是否能在 `session.chat` 執行期間產出事件。

### 場景 A：多模態結構化路由 (Text, Thinking, Tool)
- **Given**: Mock Event Stream 依序產出：
  1. UpdatedEvent(s1, p1, "reasoning")
  2. DeltaEvent(s1, p1, "Hmm...")
  3. UpdatedEvent(s1, p2, "tool", status="running", tool_desc="Get Time")
  4. UpdatedEvent(s1, p3, "text")
  5. DeltaEvent(s1, p3, "Hello")
- **When**: 呼叫 `chat_stream`。
- **Then**: 必須精準產出以下三個 dict：
  - `{"step": "thinking", "chunk": "Hmm..."}`
  - `{"step": "tool_calling", "tool": "Get Time"}`
  - `{"step": "output", "chunk": "Hello"}`

### 場景 B：未知型別降級與錯誤處理
- **Given**: DeltaEvent 帶有未註冊的 `part_id`。
- **Then**: 必須預設當作 text 處理，產出 `{"step": "output", "chunk": "..."}`。
- **Given**: `session.chat` 拋出例外。
- **Then**: 必須產出 `{"step": "error", "chunk": "..."}` 並優雅結束。
