from opencode_ai import Opencode
import threading
import time

client = Opencode(
    base_url="http://localhost:4096",
)

sessions = client.session.list()
session_id = sessions[0].id
print(f"Session ID: {session_id}")


def listen_for_chat_streaming(target_session_id):
    print("\n--- Listening for Chat Stream ---")
    try:
        stream = client.event.list()
        for event in stream:
            if event.type == "message.part.updated":
                props = event.properties
                if hasattr(props, "sessionID") and props.sessionID == target_session_id:
                    print(props)
            if event.type == "message.part.delta":
                props = event.properties
                if hasattr(props, "sessionID") and props.sessionID == target_session_id:
                    print(props)
                    # if hasattr(props, "delta"):
                    # print(props.delta, end="", flush=True)
    except Exception as e:
        print(f"\nStream error: {e}")


listener = threading.Thread(
    target=listen_for_chat_streaming, args=(session_id,), daemon=True
)
listener.start()

time.sleep(1)

print("\n--- Sending chat message ---")
msg = "請用一段話自我介紹，並告訴我現在幾點。"
try:
    client.session.chat(
        session_id,
        parts=[{"type": "text", "text": msg}],
        # model_id="gemma-4-31B",
        model_id="qwen3.6-35B-A3B-FP8",
        # provider_id="oasis",
        provider_id="qwen",
    )
except Exception as e:
    print(f"\nChat error: {e}")

print("\n\n--- Chat completed. ---")
