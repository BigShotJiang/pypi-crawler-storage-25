from typing import List, Callable, Optional, Dict, Any
from pydantic import BaseModel
from .context import Context
import time
import jwt


class ModelConfig(BaseModel):
    id: str
    features: Optional[Dict[str, Any]] = None


class Agent:
    def __init__(
        self,
        id: str,
        name: str,
        desc: str,
        models: List[ModelConfig],
        extra_params: Any = None,
        survey: Any = None,
    ):
        self.id = id
        self.name = name
        self.desc = desc
        self.models = models
        self.extra_params = extra_params
        self.survey = survey
        self._token_cache = {}
        self._run_handler: Optional[Callable[[Context], Any]] = None

    def on_run(self, func: Callable[[Context], Any]):
        self._run_handler = func
        return func

    def serve(self):
        if not self._run_handler:
            raise ValueError("Missing @agent.on_run")

        agent_card = {
            "id": self.id,
            "name": self.name,
            "desc": self.desc,
            "models": [m.model_dump(exclude_none=True) for m in self.models],
        }

        agent_card["extra_params"] = self.extra_params or {}

        if self.survey is not None:
            agent_card["extra_params"]["survey"] = self.survey

        from .daemon import start_daemon

        start_daemon(agent_card, self._run_handler)

    def register(self):
        agent_card = {
            "id": self.id,
            "name": self.name,
            "desc": self.desc,
            "models": [m.model_dump(exclude_none=True) for m in self.models],
        }

        agent_card["extra_params"] = self.extra_params or {}

        if self.survey is not None:
            agent_card["extra_params"]["survey"] = self.survey

        from .daemon import register_agent

        return register_agent(agent_card)

    def _is_token_expired(self, token: str) -> bool:
        try:
            payload = jwt.decode(token, options={"verify_signature": False})
            exp = payload.get("exp")
            if not exp:
                return True
            return time.time() > (exp - 30)
        except Exception:
            return True

    async def retrieve_mpg_token(self, email: str, agent_id: str, agent_token: str):
        if email in self._token_cache:
            cached_token = self._token_cache[email]
            if not self._is_token_expired(cached_token):
                return cached_token

        from .daemon import post_mpg_token

        token_data = await post_mpg_token(email, agent_id, agent_token)

        new_token = token_data.get("token")

        if new_token:
            self._token_cache[email] = new_token

        return new_token
