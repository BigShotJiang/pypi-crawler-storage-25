import asyncio
import logging
from opencode_scheduler import OpenCodeScheduler
from opencode_runtime import OpenCodeRuntime

logging.basicConfig(
    level=logging.WARNING, format="%(asctime)s - %(levelname)s - %(message)s"
)


class Colors:
    GRAY = "\033[90m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    RED = "\033[91m"
    RESET = "\033[0m"


async def main():
    # 1. Setup parameters
    chat_id = "test-scheduler-session"
    provider_id = "qwen"
    model_id = "qwen3.6-35B-A3B-FP8"

    print(f"🚀 Initializing OpenCodeScheduler...")
    scheduler = OpenCodeScheduler()

    try:
        # 2. Spawn a new opencode instance
        print(f"📝 Spawning new OpenCode instance for chat_id: {chat_id}...")
        base_url, session_id = await scheduler.get_runtime_url(chat_id)
        print(f"✅ Instance started at: {base_url}")
        print(f"✅ Session ID: {session_id}")

        # 3. Use runtime to run
        print("🚀 Initializing Runtime...")
        runtime = OpenCodeRuntime(base_url=base_url)

        prompt = "Please use the bash tool to list the files in the current directory and tell me what model are you using?"
        print(f"\n👤 [User]: {prompt}")
        print("-" * 60)

        current_step = None
        async for item in runtime.chat_stream(
            session_id=session_id,
            prompt=prompt,
            model_id=model_id,
            provider_id=provider_id,
        ):
            step = item.get("step")

            if step != current_step:
                if current_step is not None:
                    print(Colors.RESET, end="", flush=True)

                if step == "thinking":
                    print(f"\n{Colors.GRAY}🤔 [Thinking]: ", end="", flush=True)
                elif step == "tool_calling":
                    print(
                        f"\n{Colors.CYAN}🛠️  [Tool Execution]: {item.get('tool')}{Colors.RESET}",
                        flush=True,
                    )
                elif step == "output":
                    print(f"\n{Colors.GREEN}💬 [Assistant]: ", end="", flush=True)
                elif step == "error":
                    print(f"\n{Colors.RED}❌ [Error]: ", end="", flush=True)

                current_step = step

            if step in ("thinking", "output", "error"):
                chunk = item.get("chunk", "")
                if chunk:
                    print(chunk, end="", flush=True)

        print(Colors.RESET)

    except Exception as e:
        print(f"\n{Colors.RED}❌ Execution error: {e}{Colors.RESET}")
    finally:
        print("\n" + "-" * 60)
        print("🛑 Stopping OpenCode instance...")
        scheduler.stop_instance(chat_id)
        print("🏁 Scheduler test finished.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{Colors.RESET}Test interrupted by user.")
