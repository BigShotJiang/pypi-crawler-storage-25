import asyncio
from opencode_api_client import OpenCodeAPIClient


async def main():
    # Replace these with actual values
    OPencode_URL = "http://localhost:4096"
    LLM_URL = "https://llm.oasishpc.hk/v1"
    LLM_TOKEN = "kDpvq0RgmDqx1VyqvXy_EDrSBBNLkmIDFy1OU33HmtE"

    client = OpenCodeAPIClient(OPencode_URL, LLM_URL, LLM_TOKEN)

    try:
        # provider_id = await client.inject_provider()
        # print(f"Provider injected: {provider_id}")

        # session_id = await client.create_session()
        # print(f"Session created: {session_id}")

        print("Sending 'hello'...")
        provider_id = "asd"
        session_id = "ses_204172097ffehqUWLe0Dseb9az"
        async for chunk in client.send_prompt(provider_id, session_id, "hello"):
            print(chunk, end="", flush=True)
        print("\nDone.")

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    asyncio.run(main())
