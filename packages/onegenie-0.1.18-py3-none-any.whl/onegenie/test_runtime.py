import asyncio
import logging
from opencode_runtime import OpenCodeRuntime
from opencode_ai import Opencode

# 建議關閉過多的 DEBUG log，確保畫面乾淨
logging.basicConfig(
    level=logging.WARNING, format="%(asctime)s - %(levelname)s - %(message)s"
)


# 定義終端機顏色代碼，讓輸出更有層次感
class Colors:
    GRAY = "\033[90m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    RED = "\033[91m"
    RESET = "\033[0m"


async def main():
    # 1. 設定參數
    base_url = "http://localhost:4096"
    # provider_id = "oasis"
    # model_id = "gemma-4-31B"
    # provider_id = "qwen"
    # model_id = "qwen3.6-35B-A3B-FP8"
    provider_id = "mpg"
    model_id = "llm"

    print("🚀 初始化 OpenCode SDK 與 Runtime...")
    client = Opencode(base_url=base_url)
    runtime = OpenCodeRuntime(base_url=base_url)

    # 2. 建立新會話
    print("📝 正在建立新會話...")
    try:
        new_session = client.session.create(extra_body={"title": "integration-test"})
        session_id = new_session.id
        print(f"✅ 取得 Session ID: {session_id}")
    except Exception as e:
        print(f"❌ 無法建立 Session: {e}")
        return

    # 3. 測試 chat_stream 整合
    prompt = "請用一段話自我介紹，並告訴我現在的系統時間是幾時幾分幾秒。Please use the bash tool. Also tell me what model are you using?"
    print(f"\n👤 [User]: {prompt}")
    print("-" * 60)

    try:
        current_step = None

        # 開始接收結構化串流
        async for item in runtime.chat_stream(
            session_id=session_id,
            prompt=prompt,
            model_id=model_id,
            provider_id=provider_id,
        ):
            step = item.get("step")

            # --- 狀態切換時的 UI 渲染 ---
            if step != current_step:
                # 離開上一個狀態時重置顏色
                if current_step is not None:
                    print(Colors.RESET, end="", flush=True)

                if step == "thinking":
                    print(f"\n{Colors.GRAY}🤔 [Thinking]: ", end="", flush=True)
                elif step == "tool_calling":
                    print(
                        f"\n{Colors.CYAN}🛠️  [Tool Execution]: {item.get('tool')}{Colors.RESET}",
                        flush=True,
                    )
                elif step == "output":
                    print(f"\n{Colors.GREEN}💬 [Assistant]: ", end="", flush=True)
                elif step == "error":
                    print(f"\n{Colors.RED}❌ [Error]: ", end="", flush=True)

                current_step = step

            # --- 渲染串流內容 ---
            if step in ("thinking", "output", "error"):
                chunk = item.get("chunk", "")
                if chunk:
                    print(chunk, end="", flush=True)

        # 迴圈結束，確保重置顏色
        print(Colors.RESET)

    except Exception as e:
        print(f"\n{Colors.RED}❌ 執行時發生錯誤: {e}{Colors.RESET}")
    finally:
        print("\n" + "-" * 60)
        print("🏁 整合測試結束。")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{Colors.RESET}測試已手動中斷。")
