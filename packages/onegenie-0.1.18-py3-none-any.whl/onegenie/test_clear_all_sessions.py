from opencode_ai import Opencode

client = Opencode(
    base_url="http://localhost:4096",
)

sessions = client.session.list()

if isinstance(sessions, list):
    session_list = sessions
elif hasattr(sessions, "data"):
    session_list = sessions.data
else:
    session_list = list(sessions)

for s in session_list:
    sid = getattr(s, "id", str(s))
    print(f"Deleting session {sid}...")
    client.session.delete(sid)

print("All sessions cleared.")
