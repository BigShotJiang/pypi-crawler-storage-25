"""
sycommon CLI 工具集

Usage:
    sycommon init web my_project              # 交互式创建Web项目
    sycommon init agent my_project            # 交互式创建Agent项目
    sycommon init web my_project --with-db    # 命令行指定功能
    sycommon version                          # 显示版本
    sycommon doctor                           # 项目健康检查
"""
import argparse
import sys
from importlib.metadata import version, PackageNotFoundError

from .core.models import FeatureOptions
from .core.project import init_project
from .core.console import print_error, print_info, print_success, print_warning, Colors


def get_version() -> str:
    """获取已安装的库版本"""
    try:
        return version("sycommon-python-lib")
    except PackageNotFoundError:
        return "unknown (未安装)"


def create_init_parser(subparsers) -> None:
    """创建 init 子命令解析器"""
    init_parser = subparsers.add_parser(
        "init",
        help="创建Web/Agent类型项目模板",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
示例:
  uv pip install -e .
  sycommon init web my_project              # 交互式创建Web项目
  sycommon init agent my_project            # 交互式创建Agent项目
  sycommon init web my_project --dry-run    # 预览将要创建的文件
  sycommon init web my_project --force      # 强制覆盖已存在的目录
  sycommon init web my_project -q           # 静默模式（使用默认配置）
  sycommon init web my_project --with-db --with-mq --with-redis --with-es

项目类型说明:
  web   - 标准 FastAPI Web 服务，适合 RESTful API 开发
  agent - AI Agent 服务，基于 langgraph 实现状态图

Agent 项目结构:
  agent/           - Agent 核心 (main_agent, nodes, states, enums)
  api/sse/         - SSE 流式接口
  tools/           - 工具函数 (含 MQ 处理)
  db/              - 数据库服务
  model/           - 数据模型

Web 项目结构:
  api/             - API 接口 (含 SSE)
  tools/           - 工具函数
  model/           - 数据模型
  client/          - 外部服务客户端

功能模块说明:
  database        - MySQL 数据库支持 (SQLAlchemy)
  rabbitmq        - RabbitMQ 消息队列
  nacos           - Nacos 服务注册与配置中心
  kafka_log       - Kafka 日志收集
  sse             - Server-Sent Events 流式响应
  llm             - LLM 大模型支持 (LangChain/LangGraph)
  redis           - Redis 缓存服务
  elasticsearch   - Elasticsearch 搜索/日志服务
  sentry          - Sentry 错误监控
"""
    )

    # 位置参数
    init_parser.add_argument(
        "project_type",
        choices=["web", "agent"],
        help="项目类型：web / agent"
    )
    init_parser.add_argument(
        "project_name",
        help="工程名称"
    )

    # 功能选项 - 启用
    feature_group = init_parser.add_argument_group("功能选项 (启用)")
    feature_group.add_argument("--with-db", action="store_true",
                               help="启用数据库 (MySQL)")
    feature_group.add_argument("--with-mq", action="store_true",
                               help="启用 RabbitMQ 消息队列")
    feature_group.add_argument("--with-sse", action="store_true",
                               help="启用 SSE 流式响应")
    feature_group.add_argument("--with-redis", action="store_true",
                               help="启用 Redis 缓存")
    feature_group.add_argument("--with-es", action="store_true",
                               help="启用 Elasticsearch")

    # 功能选项 - 禁用
    disable_group = init_parser.add_argument_group("功能选项 (禁用)")
    disable_group.add_argument("--no-nacos", action="store_true",
                               help="禁用 Nacos 服务注册")
    disable_group.add_argument("--no-kafka", action="store_true",
                               help="禁用 Kafka 日志")
    disable_group.add_argument("--no-llm", action="store_true",
                               help="禁用 LLM 大模型支持")
    disable_group.add_argument("--no-sentry", action="store_true",
                               help="禁用 Sentry 错误监控")

    # 行为选项
    behavior_group = init_parser.add_argument_group("行为选项")
    behavior_group.add_argument(
        "-n", "--dry-run", action="store_true", help="仅预览")
    behavior_group.add_argument(
        "-f", "--force", action="store_true", help="强制覆盖")
    behavior_group.add_argument(
        "-q", "--quiet", action="store_true", help="静默模式")
    behavior_group.add_argument(
        "-v", "--verbose", action="store_true", help="详细输出")


def handle_init_command(args) -> bool:
    """处理 init 命令"""
    # 判断是否使用命令行模式
    use_cli_mode = any([
        args.with_db, args.with_mq, args.with_sse, args.with_redis, args.with_es,
        args.no_nacos, args.no_kafka, args.no_llm, args.no_sentry
    ])

    if use_cli_mode or args.quiet:
        features = FeatureOptions(
            database=args.with_db,
            rabbitmq=args.with_mq,
            nacos=not args.no_nacos,
            kafka_log=not args.no_kafka,
            sse=args.with_sse,
            llm=not args.no_llm,
            redis=args.with_redis,
            elasticsearch=args.with_es,
            sentry=not args.no_sentry,
        )
    else:
        features = None  # 交互式选择

    verbose = args.verbose or not args.quiet

    return init_project(
        project_name=args.project_name,
        project_type=args.project_type,
        features=features,
        dry_run=args.dry_run,
        force=args.force,
        verbose=verbose
    )


def create_doctor_parser(subparsers) -> None:
    """创建 doctor 子命令解析器"""
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="项目健康检查",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
检查项目:
  sycommon doctor                    # 检查当前目录
  sycommon doctor /path/to/project   # 检查指定目录

检查项目:
  - 依赖安装状态
  - 配置文件完整性
  - 环境变量配置
  - 代码规范检查
"""
    )
    doctor_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="项目路径 (默认: 当前目录)"
    )
    doctor_parser.add_argument(
        "--fix",
        action="store_true",
        help="自动修复发现的问题"
    )


def handle_doctor_command(args) -> bool:
    """处理 doctor 命令"""
    from pathlib import Path

    project_path = Path(args.path).resolve()

    print(f"\n{Colors.HEADER}🔍 项目健康检查{Colors.ENDC}")
    print(f"检查目录: {project_path}")
    print("-" * 50)

    issues = []
    warnings = []

    # 1. 检查必要文件
    required_files = ["app.py", "requirements.txt"]
    for file in required_files:
        if not (project_path / file).exists():
            issues.append(f"缺少必要文件: {file}")

    # 2. 检查配置文件
    config_files = ["app.yaml", ".env"]
    for file in config_files:
        if not (project_path / file).exists():
            warnings.append(f"缺少配置文件: {file}")

    # 3. 检查目录结构
    recommended_dirs = ["api", "model", "tools", "client"]
    for dir_name in recommended_dirs:
        if not (project_path / dir_name).exists():
            warnings.append(f"缺少推荐目录: {dir_name}/")

    # 4. 检查 Python 版本
    py_version = sys.version_info
    if py_version < (3, 10):
        issues.append(f"Python 版本过低: {py_version.major}.{py_version.minor}，建议 3.10+")

    # 输出结果
    if issues:
        print_error(f"发现 {len(issues)} 个问题:")
        for issue in issues:
            print(f"  ❌ {issue}")

    if warnings:
        print_warning(f"发现 {len(warnings)} 个警告:")
        for warning in warnings:
            print(f"  ⚠️  {warning}")

    if not issues and not warnings:
        print_success("项目结构检查通过!")

    # 5. 检查依赖
    print()
    print_info("检查依赖安装状态...")
    try:
        import importlib.util
        packages = [
            ("fastapi", "FastAPI"),
            ("uvicorn", "Uvicorn"),
            ("sycommon", "sycommon-python-lib"),
        ]
        for module, name in packages:
            spec = importlib.util.find_spec(module)
            if spec:
                print_success(f"{name} 已安装")
            else:
                issues.append(f"未安装依赖: {name}")
    except Exception as e:
        warnings.append(f"依赖检查失败: {e}")

    print("-" * 50)
    if issues:
        print_error(f"检查完成，发现 {len(issues)} 个问题需要修复")
        return False
    else:
        print_success("检查完成，项目健康!")
        return True


def main() -> None:
    """CLI 主入口"""
    parser = argparse.ArgumentParser(
        prog="sycommon",
        description="sycommon 工具集 - 项目初始化与脚手架工具",
        formatter_class=argparse.RawTextHelpFormatter
    )
    subparsers = parser.add_subparsers(
        dest="command", required=True, help="子命令")

    # 注册子命令
    create_init_parser(subparsers)
    create_doctor_parser(subparsers)
    subparsers.add_parser("version", help="显示版本信息")

    try:
        args = parser.parse_args()

        if args.command == "version":
            print(f"sycommon {get_version()}")
            return

        if args.command == "init":
            success = handle_init_command(args)
            if not success:
                sys.exit(1)

        if args.command == "doctor":
            success = handle_doctor_command(args)
            if not success:
                sys.exit(1)

    except argparse.ArgumentError as e:
        print_error(str(e))
        cmd = args.command if 'args' in locals() and hasattr(args, 'command') else ''
        print_info(f"使用 {parser.prog} {cmd} -h 查看帮助")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n")
        print_info("操作已取消")
        sys.exit(130)


if __name__ == "__main__":
    main()
