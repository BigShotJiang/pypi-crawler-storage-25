"""
DeepAgent 便捷封装
提供对 deepagents 的便捷调用，自动集成 get_llm 的 Token 统计和 Langfuse 追踪

核心思路：
- create_deep_agent 的 model 参数可以直接接受 BaseChatModel
- get_llm() 返回的 LLM 已经带有 token 统计和 langfuse 追踪
- 所以不需要额外封装，直接透传即可
"""
from typing import Any, Callable, Dict, List, Optional, Type, Union, Sequence

from langchain_core.tools import BaseTool
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import SystemMessage
from pydantic import BaseModel
from langgraph.graph.state import CompiledStateGraph

from deepagents import create_deep_agent, SubAgent, CompiledSubAgent
from sycommon.llm.get_llm import get_llm
from sycommon.logging.kafka_log import SYLogger


def get_agent(
    model: Union[str, BaseChatModel] = None,
    *,
    tools: Optional[Sequence[Union[BaseTool, Callable, Dict[str, Any]]]] = None,
    system_prompt: Optional[Union[str, SystemMessage]] = None,
    subagents: Optional[List[Union[SubAgent, CompiledSubAgent]]] = None,
    skills: Optional[List[str]] = None,
    memory: Optional[List[str]] = None,
    response_format: Any = None,
    context_schema: Optional[Type] = None,
    checkpointer: Any = None,
    store: Any = None,
    backend: Any = None,
    middleware: Sequence = (),
    interrupt_on: Optional[Dict[str, Any]] = None,
    debug: bool = False,
    name: Optional[str] = None,
    cache: Any = None,
    # LLM 参数（当 model 为字符串时使用）
    temperature: float = 0.1,
    timeout: float = 180,
    max_retries: int = 3,
    **kwargs
) -> CompiledStateGraph:
    """
    创建 Agent（直接返回 deepagents 的 CompiledStateGraph）

    完全透传 deepagents 的所有能力，不做任何隐藏
    当 model 为字符串时，自动使用 get_llm 创建 LLM（自带 token 统计和 langfuse）

    Args:
        model: 模型名称字符串 或 BaseChatModel 实例
            - 字符串：自动调用 get_llm 创建，自带追踪
            - BaseChatModel：直接使用
        tools: 工具列表
        system_prompt: 系统提示词
        subagents: 子 Agent 列表
        skills: 技能描述列表
        memory: 记忆键列表
        response_format: 响应格式（结构化输出）
        context_schema: 上下文 Schema
        checkpointer: 检查点存储器
        store: 状态存储
        backend: 后端协议
        middleware: 中间件列表
        interrupt_on: 中断配置
        debug: 调试模式
        name: Agent 名称
        cache: 缓存配置
        temperature: LLM 温度（仅 model 为字符串时）
        timeout: LLM 超时（仅 model 为字符串时）
        max_retries: LLM 重试次数（仅 model 为字符串时）
        **kwargs: 其他透传参数

    Returns:
        CompiledStateGraph: deepagents 原生 Agent

    Example:
        ```python
        from sycommon.agent import get_agent, SubAgent

        # 简单使用
        agent = get_agent(
            model="Qwen2.5-72B",
            system_prompt="你是助手"
        )
        result = await agent.ainvoke({"messages": ["你好"]})

        # 带工具
        agent = get_agent(
            model="Qwen2.5-72B",
            tools=[search_tool],
            system_prompt="你是搜索助手"
        )

        # 嵌套子 Agent
        agent = get_agent(
            model="Qwen2.5-72B",
            subagents=[
                SubAgent(name="researcher", description="研究助手"),
                SubAgent(name="writer", description="写作助手")
            ]
        )

        # 自定义 LLM
        from sycommon.llm import get_llm
        llm = get_llm("Qwen2.5-72B", temperature=0.7)
        agent = get_agent(model=llm, tools=[...])
        ```
    """
    # 1. 处理 model 参数
    if model is None:
        model = "Qwen2.5-72B"

    # 如果是字符串，调用 get_llm 创建（自带 token 统计和 langfuse）
    if isinstance(model, str):
        llm = get_llm(
            model,
            temperature=temperature,
            timeout=timeout,
            max_retries=max_retries,
            wrap_structured=False
        )
        agent_name = name or model
    else:
        llm = model
        agent_name = name or "agent"

    # 2. 调用 deepagents 的 create_deep_agent
    try:
        compiled_agent = create_deep_agent(
            model=llm,
            tools=tools,
            system_prompt=system_prompt,
            subagents=subagents,
            skills=skills,
            memory=memory,
            response_format=response_format,
            context_schema=context_schema,
            checkpointer=checkpointer,
            store=store,
            backend=backend,
            middleware=middleware,
            interrupt_on=interrupt_on,
            debug=debug,
            name=agent_name,
            cache=cache,
            **kwargs
        )

        SYLogger.info(f"Agent[{agent_name}] 创建成功")
        return compiled_agent

    except Exception as e:
        SYLogger.error(f"Agent[{agent_name}] 创建失败: {str(e)}", exc_info=True)
        raise


# ========== 便捷工厂函数 ==========

def create_tool_agent(
    tools: Sequence,
    system_prompt: str = "你是一个可以使用工具的助手",
    model: str = "Qwen2.5-72B",
    **kwargs
) -> CompiledStateGraph:
    """创建带工具的 Agent"""
    return get_agent(model=model, tools=tools, system_prompt=system_prompt, **kwargs)


def create_multi_agent(
    subagent_configs: List[Dict[str, str]],
    coordinator_prompt: str = "你是协调员，根据任务委派给子 Agent",
    model: str = "Qwen2.5-72B",
    **kwargs
) -> CompiledStateGraph:
    """创建多 Agent 系统"""
    subagents = [
        SubAgent(name=cfg["name"], description=cfg["description"])
        for cfg in subagent_configs
    ]
    return get_agent(model=model, subagents=subagents, system_prompt=coordinator_prompt, **kwargs)


def create_structured_agent(
    output_schema: Type[BaseModel],
    system_prompt: str,
    model: str = "Qwen2.5-72B",
    **kwargs
) -> CompiledStateGraph:
    """创建结构化输出 Agent"""
    return get_agent(model=model, response_format=output_schema, system_prompt=system_prompt, **kwargs)


__all__ = [
    "get_agent",
    "create_tool_agent",
    "create_multi_agent",
    "create_structured_agent",
    "SubAgent",
    "CompiledSubAgent",
    "create_deep_agent",
]
