"""
虚拟员工系统
============

基于 deepagents 封装的业务层抽象，将 Agent 概念化为"虚拟员工"。

核心概念：
- VirtualEmployee: 虚拟员工，拥有自己的技能、内部小团队、记忆系统
- Skill: 员工技能，声明式描述员工能做什么
- SubTeam: 内部小团队，由子员工组成
- MemoryTool: 记忆工具，支持员工记忆和上下文
- Middleware: 中间件，支持权限、监控、缓存等横切关注点

设计理念：
- 更贴近业务语义：员工、技能、小团队
- 声明式配置：通过配置定义员工能力
- 可组合：员工可以组合成更复杂的团队
- 可扩展：通过中间件扩展功能

架构层次：
┌─────────────────────────────────────────────────────────┐
│                    业务层 (VirtualEmployee)              │
│  - 虚拟员工概念                                          │
│  - 技能/小团队/记忆抽象                                   │
│  - 中间件集成                                           │
├─────────────────────────────────────────────────────────┤
│                    封装层 (get_agent)                    │
│  - LLM 创建和追踪                                        │
│  - 参数转换和透传                                        │
├─────────────────────────────────────────────────────────┤
│                   核心层 (deepagents)                    │
│  - create_deep_agent                                    │
│  - SubAgent / CompiledSubAgent                          │
│  - AgentMiddleware                                      │
└─────────────────────────────────────────────────────────┘
"""
from typing import Any, Callable, Dict, List, Optional, Type, Union, Sequence
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from langchain_core.messages import SystemMessage
from langgraph.graph.state import CompiledStateGraph
from langgraph.checkpoint.memory import MemorySaver

from deepagents import SubAgent, CompiledSubAgent
from sycommon.agent.get_agent import get_agent


def _default_checkpointer():
    """延迟创建默认检查点存储器"""
    return MemorySaver()


# ========== 核心数据模型 ==========

class SkillLevel(Enum):
    """技能等级"""
    JUNIOR = 1      # 初级
    INTERMEDIATE = 2  # 中级
    SENIOR = 3      # 高级
    EXPERT = 4      # 专家


@dataclass
class Skill:
    """
    员工技能

    声明式定义员工具备的能力，让 Agent 知道自己能做什么。
    """
    name: str                           # 技能名称
    description: str                    # 技能描述
    level: SkillLevel = SkillLevel.INTERMEDIATE
    tools: List[Union[BaseTool, Callable]] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)  # 使用示例

    def to_skill_string(self) -> str:
        """转换为 deepagents 的 skills 字符串格式"""
        level_str = f"[level:{self.level.value}]"
        examples_str = ""
        if self.examples:
            examples_str = " 示例: " + "; ".join(self.examples[:2])
        return f"{self.name}{level_str}: {self.description}{examples_str}"

    @classmethod
    def simple(cls, name: str, description: str) -> "Skill":
        """创建简单技能"""
        return cls(name=name, description=description)


@dataclass
class SubTeamMember:
    """
    内部小团队成员

    定义一个子员工，作为主员工的内部小团队。
    """
    name: str                           # 成员名称
    role: str                           # 角色描述
    system_prompt: Optional[str] = None # 系统提示词
    tools: List[Union[BaseTool, Callable]] = field(default_factory=list)
    skills: List[Skill] = field(default_factory=list)

    def to_subagent(self) -> SubAgent:
        """转换为 deepagents 的 SubAgent"""
        skill_strings = [s.to_skill_string() for s in self.skills]
        return SubAgent(
            name=self.name,
            description=self.role,
            system_prompt=self.system_prompt,
            tools=self.tools if self.tools else None,
            skills=skill_strings if skill_strings else None
        )


class MemoryType(Enum):
    """记忆类型"""
    CONVERSATION = "conversation"   # 对话记忆
    EPISODIC = "episodic"          # 情景记忆（事件）
    SEMANTIC = "semantic"          # 语义记忆（知识）
    WORKING = "working"            # 工作记忆（短期）


@dataclass
class MemoryConfig:
    """
    记忆配置

    定义员工的记忆能力，支持多种记忆类型。
    """
    types: List[MemoryType] = field(default_factory=lambda: [MemoryType.CONVERSATION])
    max_history: int = 100         # 最大历史记录数
    enable_summary: bool = True    # 是否启用摘要

    def to_memory_list(self) -> List[str]:
        """转换为 deepagents 的 memory 参数"""
        return [t.value for t in self.types]


# ========== 虚拟员工核心类 ==========

# ========== 员工中间件（简化业务使用） ==========

class EmployeeMiddleware(ABC):
    """
    员工中间件基类

    提供简化版的中间件接口，用于 VirtualEmployee。
    继承此类可以创建自定义的员工行为拦截器。
    """

    @abstractmethod
    def before_work(self, employee: "VirtualEmployee", task: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        工作前回调

        Args:
            employee: 虚拟员工实例
            task: 任务内容
            context: 上下文信息

        Returns:
            可选的修改后的上下文
        """
        pass

    @abstractmethod
    def after_work(self, employee: "VirtualEmployee", result: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        工作后回调

        Args:
            employee: 虚拟员工实例
            result: 工作结果
            context: 上下文信息

        Returns:
            可选的修改后的上下文
        """
        pass


class LoggingEmployeeMiddleware(EmployeeMiddleware):
    """日志记录中间件"""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self._logs: List[Dict[str, Any]] = []

    def before_work(self, employee, task, context):
        import datetime
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "employee": employee.name,
            "task": task[:100] if task else "",
            "phase": "before"
        }
        self._logs.append(log_entry)
        if self.verbose:
            print(f"[{employee.name}] 📝 开始任务: {task[:50]}...")
        return None

    def after_work(self, employee, result, context):
        import datetime
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "employee": employee.name,
            "result_length": len(result) if result else 0,
            "phase": "after"
        }
        self._logs.append(log_entry)
        if self.verbose:
            print(f"[{employee.name}] ✅ 任务完成")
        return None

    @property
    def logs(self) -> List[Dict[str, Any]]:
        return self._logs.copy()


class QuotaEmployeeMiddleware(EmployeeMiddleware):
    """配额控制中间件"""

    def __init__(self, max_requests: int = 100):
        self.max_requests = max_requests
        self._request_count = 0

    def before_work(self, employee, task, context):
        if self._request_count >= self.max_requests:
            raise RuntimeError(f"员工 {employee.name} 配额已用尽 ({self._request_count}/{self.max_requests})")
        self._request_count += 1
        return None

    def after_work(self, employee, result, context):
        return None

    @property
    def remaining(self) -> int:
        return self.max_requests - self._request_count


class PermissionEmployeeMiddleware(EmployeeMiddleware):
    """权限控制中间件"""

    def __init__(self, allowed_actions: Optional[List[str]] = None):
        self.allowed_actions = allowed_actions or ["*"]

    def _detect_action(self, task: str) -> str:
        """检测任务动作类型"""
        task_lower = task.lower()
        if any(kw in task_lower for kw in ["删除", "delete"]):
            return "delete"
        if any(kw in task_lower for kw in ["修改", "update"]):
            return "update"
        if any(kw in task_lower for kw in ["创建", "create"]):
            return "create"
        return "read"

    def before_work(self, employee, task, context):
        action = self._detect_action(task)
        if "*" not in self.allowed_actions and action not in self.allowed_actions:
            raise PermissionError(f"员工 {employee.name} 无权执行 '{action}' 操作")
        return None

    def after_work(self, employee, result, context):
        return None


class VirtualEmployee:
    """
    虚拟员工

    基于 deepagents 的上层业务抽象，将 Agent 封装为"员工"概念。

    特性：
    - 拥有明确的技能（skills）
    - 可以有内部小团队（subagents）
    - 拥有记忆能力（memory）
    - 可配置的工作参数
    - 支持中间件扩展
    - 支持结构化输出（response_format）
    - 支持中断控制（interrupt_on）用于人工审核等场景

    Example:
        ```python
        # 创建一个客服员工
        support_agent = VirtualEmployee(
            name="客服小美",
            role="客户支持专员",
            model="Qwen2.5-72B",
            skills=[
                Skill("faq", "回答常见问题"),
                Skill("complaint", "处理客户投诉", level=SkillLevel.SENIOR)
            ],
            tools=[search_faq, create_ticket],
            middleware=[LoggingEmployeeMiddleware()]
        )

        # 执行任务
        result = await support_agent.run("我需要退货")

        # 结构化输出
        from pydantic import BaseModel
        class Response(BaseModel):
            answer: str
            confidence: float

        structured_agent = VirtualEmployee(
            name="分析员",
            role="数据分析",
            response_format=Response
        )

        # 带中断控制（需要人工确认）
        from langgraph.checkpoint.memory import MemorySaver

        approval_agent = VirtualEmployee(
            name="审批员",
            role="审批助手",
            checkpointer=MemorySaver(),
            interrupt_on={"tool_calls": True}  # 工具调用前中断
        )

        # 执行并等待人工确认
        result = await approval_agent.run("删除文件", thread_id="xxx")
        # 检查是否需要人工确认
        state = await approval_agent.aget_state({"configurable": {"thread_id": "xxx"}})
        if state.next:  # 需要继续
            await approval_agent.ainvoke(None, config={"configurable": {"thread_id": "xxx"}})
        ```
    """

    def __init__(
        self,
        name: str,
        role: str,
        model: Union[str, BaseModel] = "Qwen2.5-72B",
        *,
        # 技能和工具
        skills: Optional[List[Skill]] = None,
        tools: Optional[Sequence[Union[BaseTool, Callable]]] = None,
        subteam: Optional[List[SubTeamMember]] = None,
        # 记忆系统
        memory: Optional[MemoryConfig] = None,
        checkpointer: Any = None,
        store: Any = None,
        # 输出控制
        response_format: Any = None,
        context_schema: Optional[Type] = None,
        system_prompt: Optional[str] = None,
        # 运行时配置
        temperature: float = 0.1,
        backend: Any = None,
        cache: Any = None,
        debug: bool = False,
        # 中间件
        middleware: Optional[List[EmployeeMiddleware]] = None,
        agent_middleware: Optional[Sequence] = None,  # deepagents 原生中间件
        # 中断控制
        interrupt_on: Optional[Dict[str, Any]] = None,
        # 其他参数
        **kwargs
    ):
        """
        初始化虚拟员工

        Args:
            name: 员工名称
            role: 员工角色/职位
            model: 使用的模型
            skills: 技能列表
            tools: 工具列表
            subteam: 内部小团队成员
            memory: 记忆配置
            checkpointer: 检查点存储器（用于记忆持久化）
            store: 状态存储器
            response_format: 响应格式（结构化输出）
            context_schema: 上下文 Schema
            system_prompt: 自定义系统提示词
            temperature: LLM 温度
            backend: 后端协议
            cache: 缓存配置
            debug: 调试模式
            middleware: 员工中间件（业务层）
            agent_middleware: Agent 原生中间件（deepagents）
            interrupt_on: 中断配置（用于人工审核等场景）
            **kwargs: 其他透传参数
        """
        self.name = name
        self.role = role
        self.model = model

        # 技能和工具
        self.skills = skills or []
        self.tools = list(tools) if tools else []
        self.subteam = subteam or []

        # 记忆系统
        self.memory = memory or MemoryConfig()
        self.checkpointer = checkpointer
        self.store = store

        # 输出控制
        self.response_format = response_format
        self.context_schema = context_schema
        self.system_prompt = self._build_system_prompt(system_prompt)

        # 运行时配置
        self.temperature = temperature
        self.backend = backend
        self.cache = cache
        self.debug = debug

        # 中间件
        self.middleware = middleware or []
        self.agent_middleware = agent_middleware or []

        # 中断控制
        self.interrupt_on = interrupt_on

        # 其他参数
        self._kwargs = kwargs

        # 编译后的 Agent
        self._agent: Optional[CompiledStateGraph] = None

    def _build_system_prompt(self, custom_prompt: Optional[str]) -> str:
        """构建系统提示词"""
        parts = [f"你是{self.name}，{self.role}。"]

        if self.skills:
            parts.append("\n你的技能包括：")
            for skill in self.skills:
                parts.append(f"- {skill.name}: {skill.description}")

        if self.subteam:
            parts.append("\n你的内部小团队成员：")
            for member in self.subteam:
                parts.append(f"- {member.name}: {member.role}")

        if custom_prompt:
            parts.append(f"\n{custom_prompt}")

        return "\n".join(parts)

    def _compile(self) -> CompiledStateGraph:
        """编译生成 Agent"""
        # 转换技能
        skill_strings = [s.to_skill_string() for s in self.skills]

        # 转换子团队
        subagents = [m.to_subagent() for m in self.subteam]

        # 合并工具
        all_tools = self.tools.copy()
        for skill in self.skills:
            all_tools.extend(skill.tools)

        # 默认检查点
        checkpointer = self.checkpointer if self.checkpointer is not None else _default_checkpointer()

        # 调用 get_agent（完整参数透传）
        return get_agent(
            model=self.model,
            tools=all_tools if all_tools else None,
            system_prompt=self.system_prompt,
            subagents=subagents if subagents else None,
            skills=skill_strings if skill_strings else None,
            memory=self.memory.to_memory_list(),
            response_format=self.response_format,
            context_schema=self.context_schema,
            checkpointer=checkpointer,
            store=self.store,
            backend=self.backend,
            middleware=self.agent_middleware,
            interrupt_on=self.interrupt_on,
            debug=self.debug,
            name=self.name,
            cache=self.cache,
            temperature=self.temperature,
            **self._kwargs
        )

    @property
    def agent(self) -> CompiledStateGraph:
        """获取编译后的 Agent（懒加载）"""
        if self._agent is None:
            self._agent = self._compile()
        return self._agent

    async def run(
        self,
        message: str,
        thread_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> str:
        """
        执行任务（异步）

        Args:
            message: 用户消息
            thread_id: 会话ID（用于保持记忆连续性）
            context: 额外上下文
            **kwargs: 其他参数

        Returns:
            员工的响应
        """
        from langchain_core.messages import HumanMessage

        context = context or {}

        # 执行员工中间件 before_work
        for mw in self.middleware:
            mw.before_work(self, message, context)

        config = {}
        if thread_id:
            config["configurable"] = {"thread_id": thread_id}

        # 合并上下文到 state
        state = {"messages": [HumanMessage(content=message)], **context}

        result = await self.agent.ainvoke(
            state,
            config=config if config else None,
            **kwargs
        )

        response = result["messages"][-1].content

        # 执行员工中间件 after_work
        for mw in self.middleware:
            mw.after_work(self, response, context)

        return response

    def run_sync(
        self,
        message: str,
        thread_id: Optional[str] = None,
        **kwargs
    ) -> str:
        """执行任务（同步）"""
        import asyncio
        return asyncio.run(self.run(message, thread_id, **kwargs))

    async def stream(self, message: str, thread_id: Optional[str] = None):
        """流式输出"""
        from langchain_core.messages import HumanMessage

        config = {}
        if thread_id:
            config["configurable"] = {"thread_id": thread_id}

        async for event in self.agent.astream(
            {"messages": [HumanMessage(content=message)]},
            config=config if config else None
        ):
            yield event

    async def aget_state(self, config: Dict[str, Any]):
        """
        获取当前状态（用于中断恢复场景）

        Args:
            config: 包含 thread_id 的配置

        Returns:
            Agent 当前状态
        """
        return await self.agent.aget_state(config)

    async def ainvoke(
        self,
        input: Optional[Dict[str, Any]],
        config: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        """
        底层 invoke 调用（用于中断恢复等场景）

        Args:
            input: 输入数据，None 表示继续之前中断的任务
            config: 配置（包含 thread_id）
            **kwargs: 其他参数

        Returns:
            Agent 执行结果
        """
        return await self.agent.ainvoke(input, config=config, **kwargs)

    def add_skill(self, skill: Skill) -> "VirtualEmployee":
        """添加技能（链式调用）"""
        self.skills.append(skill)
        self._agent = None  # 重置编译缓存
        return self

    def add_tool(self, tool: Union[BaseTool, Callable]) -> "VirtualEmployee":
        """添加工具（链式调用）"""
        self.tools.append(tool)
        self._agent = None
        return self

    def add_subteam_member(self, member: SubTeamMember) -> "VirtualEmployee":
        """添加小团队成员（链式调用）"""
        self.subteam.append(member)
        self._agent = None
        return self

    def use_middleware(self, middleware: EmployeeMiddleware) -> "VirtualEmployee":
        """添加中间件（链式调用）"""
        self.middleware.append(middleware)
        return self

    def __repr__(self) -> str:
        return f"VirtualEmployee(name='{self.name}', role='{self.role}', skills={len(self.skills)}, subteam={len(self.subteam)})"


# ========== 员工工厂 ==========

class EmployeeFactory:
    """
    员工工厂

    提供快捷方法创建常见类型的虚拟员工。
    """

    @staticmethod
    def create_support_agent(
        name: str = "客服助手",
        tools: Optional[List] = None,
        **kwargs
    ) -> VirtualEmployee:
        """创建客服员工"""
        return VirtualEmployee(
            name=name,
            role="客户支持专员",
            skills=[
                Skill("faq", "回答常见问题", level=SkillLevel.SENIOR),
                Skill("complaint", "处理客户投诉", level=SkillLevel.INTERMEDIATE),
                Skill("escalation", "问题升级处理", level=SkillLevel.EXPERT)
            ],
            tools=tools or [],
            system_prompt="你需要友好、专业地处理客户问题。对于复杂问题可以升级处理。",
            **kwargs
        )

    @staticmethod
    def create_researcher(
        name: str = "研究助手",
        tools: Optional[List] = None,
        **kwargs
    ) -> VirtualEmployee:
        """创建研究员工"""
        return VirtualEmployee(
            name=name,
            role="研究分析师",
            skills=[
                Skill("web_search", "网络搜索和资料收集"),
                Skill("data_analysis", "数据分析和报告"),
                Skill("summarization", "信息总结和归纳")
            ],
            tools=tools or [],
            system_prompt="你需要准确、全面地收集和分析信息，提供客观的研究结论。",
            **kwargs
        )

    @staticmethod
    def create_writer(
        name: str = "内容专家",
        tools: Optional[List] = None,
        **kwargs
    ) -> VirtualEmployee:
        """创建写作员工"""
        return VirtualEmployee(
            name=name,
            role="内容创作者",
            skills=[
                Skill("writing", "撰写各类文档和文章", level=SkillLevel.EXPERT),
                Skill("editing", "文本编辑和润色"),
                Skill("translation", "多语言翻译")
            ],
            tools=tools or [],
            system_prompt="你需要创作高质量、结构清晰的内容。",
            **kwargs
        )

    @staticmethod
    def create_manager(
        name: str = "团队经理",
        subteam: Optional[List[SubTeamMember]] = None,
        **kwargs
    ) -> VirtualEmployee:
        """创建经理员工（带团队）"""
        default_subteam = [
            SubTeamMember(name="研究员", role="负责调研分析"),
            SubTeamMember(name="执行员", role="负责具体执行")
        ]
        return VirtualEmployee(
            name=name,
            role="团队协调经理",
            subteam=subteam or default_subteam,
            skills=[
                Skill("coordination", "协调团队成员工作"),
                Skill("planning", "制定工作计划"),
                Skill("review", "审核工作成果")
            ],
            system_prompt="你需要协调团队成员，合理分配任务，确保工作顺利完成。",
            **kwargs
        )


# ========== 团队组合 ==========

class VirtualTeam:
    """
    虚拟团队

    将多个虚拟员工组合成一个团队，支持协作工作流。
    """

    def __init__(
        self,
        name: str,
        employees: List[VirtualEmployee],
        coordinator: Optional[VirtualEmployee] = None
    ):
        self.name = name
        self.employees = {e.name: e for e in employees}
        self.coordinator = coordinator

    def get_employee(self, name: str) -> Optional[VirtualEmployee]:
        """获取员工"""
        return self.employees.get(name)

    async def delegate(
        self,
        employee_name: str,
        message: str,
        thread_id: Optional[str] = None
    ) -> str:
        """委派任务给特定员工"""
        employee = self.get_employee(employee_name)
        if not employee:
            raise ValueError(f"员工 '{employee_name}' 不存在")
        return await employee.run(message, thread_id)

    def __repr__(self) -> str:
        return f"VirtualTeam(name='{self.name}', employees={list(self.employees.keys())})"


__all__ = [
    # 核心类
    "VirtualEmployee",
    "VirtualTeam",
    "EmployeeFactory",

    # 数据模型
    "Skill",
    "SkillLevel",
    "SubTeamMember",
    "MemoryConfig",
    "MemoryType",

    # 中间件
    "EmployeeMiddleware",
    "LoggingEmployeeMiddleware",
    "QuotaEmployeeMiddleware",
    "PermissionEmployeeMiddleware",
]
