"""
示例 09: 中断和人工审核
======================

展示如何使用 interrupt_on 实现人机协作，在关键步骤暂停等待人工确认。

运行方式:
    python -m sycommon.agent.examples.09_interrupt
"""
import asyncio
from typing import Any, Dict
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver

from sycommon.agent import get_agent


# ========== 工具定义 ==========

@tool
def send_email(to: str, subject: str, body: str) -> str:
    """发送邮件"""
    return f"邮件已发送给 {to}\n主题: {subject}\n内容: {body[:50]}..."


@tool
def transfer_money(amount: float, recipient: str) -> str:
    """转账"""
    return f"已转账 {amount} 元给 {recipient}"


@tool
def delete_file(file_path: str) -> str:
    """删除文件"""
    return f"文件已删除: {file_path}"


@tool
def update_database(query: str) -> str:
    """更新数据库"""
    return f"数据库已更新: {query[:50]}..."


# ========== 示例函数 ==========

async def basic_interrupt():
    """基础中断机制"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[send_email],
        system_prompt="你是邮件助手，帮助用户发送邮件。",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": "send_email"},  # 在调用 send_email 时中断
        name="email_agent"
    )

    thread_id = "email_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("=" * 50)
    print("基础中断机制 - 发送邮件前确认")
    print("=" * 50)

    # 第一次调用 - 会在工具调用前中断
    print("\n用户: 帮我给 boss@company.com 发一封请假邮件")
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(
            content="帮我给 boss@company.com 发一封请假邮件，说我明天请假")]},
        config=config
    )

    # 检查状态
    state = await agent.aget_state(config)
    print(f"\n当前状态: next={state.next}")

    if state.next:
        print("Agent 已暂停，等待人工确认发送邮件")

        # 模拟人工审核
        print("\n--- 人工审核 ---")
        print("请确认是否发送邮件？(y/n): y")

        # 继续执行
        result2 = await agent.ainvoke(
            None,  # 不需要新输入，继续之前的执行
            config=config
        )
        print(f"\n最终结果: {result2['messages'][-1].content}")


async def interrupt_multiple_tools():
    """多个工具的中断"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[transfer_money, send_email],
        system_prompt="你是财务助手，可以转账和发邮件。",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": ["transfer_money", "send_email"]},  # 多个工具都中断
        name="finance_agent"
    )

    thread_id = "finance_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("多个工具的中断")
    print("=" * 50)

    print("\n用户: 给小明转账100元，然后发邮件通知他")

    # 开始执行
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="给小明转账100元，然后发邮件通知他")]},
        config=config
    )

    state = await agent.aget_state(config)
    print(f"\n第一次中断，状态: next={state.next}")

    # 第一次继续
    print("\n--- 确认转账 ---")
    result2 = await agent.ainvoke(None, config=config)

    state = await agent.aget_state(config)
    if state.next:
        print(f"\n第二次中断（发邮件），状态: next={state.next}")

        # 第二次继续
        print("\n--- 确认发邮件 ---")
        result3 = await agent.ainvoke(None, config=config)

        print(f"\n最终结果: {result3['messages'][-1].content}")


async def interrupt_with_approval():
    """带审批流程的中断"""
    @tool
    def approve_request(request_id: str, approver: str) -> str:
        """审批请求"""
        return f"请求 {request_id} 已由 {approver} 审批通过"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[approve_request, update_database],
        system_prompt="""你是审批系统助手。

        流程：
        1. 接收审批请求
        2. 等待人工确认
        3. 执行审批并更新数据库""",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": "approve_request"},
        name="approval_agent"
    )

    thread_id = "approval_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("带审批流程的中断")
    print("=" * 50)

    print("\n用户: 提交一个请假申请，请求ID是 LEAVE-001")

    # 提交申请
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="提交请假申请 LEAVE-001，需要经理审批")]},
        config=config
    )

    state = await agent.aget_state(config)

    if state.next:
        print("\n--- 等待经理审批 ---")
        print("审批意见: 同意")

        # 提供审批输入
        result2 = await agent.ainvoke(
            {"messages": [HumanMessage(content="经理同意，批准申请")]},
            config=config
        )

        print(f"\n审批结果: {result2['messages'][-1].content}")


async def interrupt_state_inspection():
    """中断时检查状态"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[delete_file],
        system_prompt="你是文件管理助手。",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": "delete_file"},
        name="file_agent"
    )

    thread_id = "file_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("中断时检查状态")
    print("=" * 50)

    print("\n用户: 删除 /tmp/old_data.txt 文件")

    # 执行到中断点
    await agent.ainvoke(
        {"messages": [HumanMessage(content="删除 /tmp/old_data.txt 文件")]},
        config=config
    )

    # 检查详细状态
    state = await agent.aget_state(config)

    print("\n中断点状态信息:")
    print(f"- 下一步: {state.next}")
    print(f"- 消息数: {len(state.values.get('messages', []))}")

    # 查看即将执行的工具调用
    if state.tasks:
        for task in state.tasks:
            print(f"- 任务: {task}")

    # 查看历史记录
    print("\n状态历史:")
    history = [s async for s in agent.aget_state_history(config)]
    for i, h in enumerate(history):
        print(f"  {i+1}. next={h.next}")

    # 继续或取消
    print("\n--- 确认删除 ---")
    result = await agent.ainvoke(None, config=config)
    print(f"结果: {result['messages'][-1].content}")


async def interrupt_with_modification():
    """中断后修改参数"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[transfer_money],
        system_prompt="你是转账助手。",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": "transfer_money"},
        name="transfer_agent"
    )

    thread_id = "transfer_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("中断后修改参数")
    print("=" * 50)

    print("\n用户: 给小红转账500元")

    # 执行到中断
    await agent.ainvoke(
        {"messages": [HumanMessage(content="给小红转账500元")]},
        config=config
    )

    state = await agent.aget_state(config)
    print(f"\n中断 - 即将转账 500 元")

    # 修改金额
    print("\n--- 人工干预：金额改为 300 元 ---")

    # 提供新的指令
    result = await agent.ainvoke(
        {"messages": [HumanMessage(content="金额改成300元")]},
        config=config
    )

    print(f"结果: {result['messages'][-1].content}")


async def interrupt_timeout():
    """带超时的中断"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[send_email],
        system_prompt="你是邮件助手。",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": "send_email"},
        name="timeout_agent"
    )

    thread_id = "timeout_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("带超时的中断")
    print("=" * 50)

    print("\n用户: 发送测试邮件")

    # 执行到中断
    await agent.ainvoke(
        {"messages": [HumanMessage(content="发送测试邮件给 test@example.com")]},
        config=config
    )

    print("\n等待确认（模拟5秒超时）...")

    # 模拟超时处理
    try:
        async with asyncio.timeout(5):
            # 这里可以等待用户输入
            await asyncio.sleep(2)  # 模拟用户思考
            print("用户确认: 发送")
            result = await agent.ainvoke(None, config=config)
            print(f"结果: {result['messages'][-1].content}")
    except asyncio.TimeoutError:
        print("超时：操作已取消")


async def interrupt_cancel():
    """取消中断操作"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[delete_file],
        system_prompt="你是文件管理助手。",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": "delete_file"},
        name="cancel_agent"
    )

    thread_id = "cancel_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("取消中断操作")
    print("=" * 50)

    print("\n用户: 删除 important.txt 文件")

    # 执行到中断
    await agent.ainvoke(
        {"messages": [HumanMessage(content="删除 important.txt 文件")]},
        config=config
    )

    state = await agent.aget_state(config)
    print(f"\n中断 - 即将删除文件")

    # 取消操作 - 提供新的指令
    print("\n--- 取消删除 ---")
    result = await agent.ainvoke(
        {"messages": [HumanMessage(content="取消，不要删除了")]},
        config=config
    )

    print(f"结果: {result['messages'][-1].content}")


async def multi_step_interrupt():
    """多步骤中断流程"""
    @tool
    def step1_collect_info(info: str) -> str:
        """收集信息"""
        return f"信息已收集: {info}"

    @tool
    def step2_process(data: str) -> str:
        """处理数据"""
        return f"数据处理完成: {data[:30]}..."

    @tool
    def step3_save(result: str) -> str:
        """保存结果"""
        return f"结果已保存: {result[:30]}..."

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[step1_collect_info, step2_process, step3_save],
        system_prompt="""你是数据处理助手。

        按步骤执行：
        1. 收集信息
        2. 处理数据
        3. 保存结果

        每一步都要等待确认。""",
        checkpointer=MemorySaver(),
        interrupt_on={"tools": ["step1_collect_info",
                                "step2_process", "step3_save"]},
        name="multi_step_agent"
    )

    thread_id = "multi_step_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("多步骤中断流程")
    print("=" * 50)

    print("\n用户: 处理客户数据 '张三,28岁,北京'")

    steps = ["步骤1: 收集信息", "步骤2: 处理数据", "步骤3: 保存结果"]

    # 开始
    await agent.ainvoke(
        {"messages": [HumanMessage(content="处理客户数据 '张三,28岁,北京'")]},
        config=config
    )

    for step in steps:
        state = await agent.aget_state(config)
        if state.next:
            print(f"\n{step} - 等待确认")
            print("确认: 继续")
            await agent.ainvoke(None, config=config)

    # 获取最终结果
    state = await agent.aget_state(config)
    if state.values.get("messages"):
        print(f"\n最终结果: {state.values['messages'][-1].content}")


async def main():
    """运行所有中断示例"""
    print("\n" + "=" * 60)
    print("示例 9.1: 基础中断机制")
    print("=" * 60)
    await basic_interrupt()

    print("\n" + "=" * 60)
    print("示例 9.2: 多个工具的中断")
    print("=" * 60)
    await interrupt_multiple_tools()

    print("\n" + "=" * 60)
    print("示例 9.3: 带审批流程的中断")
    print("=" * 60)
    await interrupt_with_approval()

    print("\n" + "=" * 60)
    print("示例 9.4: 中断时检查状态")
    print("=" * 60)
    await interrupt_state_inspection()

    print("\n" + "=" * 60)
    print("示例 9.5: 中断后修改参数")
    print("=" * 60)
    await interrupt_with_modification()

    print("\n" + "=" * 60)
    print("示例 9.6: 带超时的中断")
    print("=" * 60)
    await interrupt_timeout()

    print("\n" + "=" * 60)
    print("示例 9.7: 取消中断操作")
    print("=" * 60)
    await interrupt_cancel()

    print("\n" + "=" * 60)
    print("示例 9.8: 多步骤中断流程")
    print("=" * 60)
    await multi_step_interrupt()


if __name__ == "__main__":
    asyncio.run(main())
