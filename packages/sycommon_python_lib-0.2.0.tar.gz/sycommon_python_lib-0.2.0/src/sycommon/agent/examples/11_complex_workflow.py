"""
示例 11: 复杂工作流
==================

展示如何组合多种能力（工具、子Agent、结构化输出等）完成复杂任务。

运行方式:
    python -m sycommon.agent.examples.11_complex_workflow
"""
import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver

from sycommon.agent import get_agent, SubAgent


# ========== 工具定义 ==========

@tool
def search_database(query: str) -> str:
    """搜索数据库"""
    # 模拟数据库
    data = {
        "用户": "找到 3 条用户记录: 张三(ID:1), 李四(ID:2), 王五(ID:3)",
        "订单": "找到 5 条订单记录，总金额: ¥15,680",
        "产品": "找到 10 条产品记录，库存总量: 1,234"
    }
    for key, value in data.items():
        if key in query:
            return value
    return f"搜索 '{query}'：找到 0 条记录"


@tool
def generate_report(title: str, content: str) -> str:
    """生成报告"""
    return f"报告已生成: {title}\n内容长度: {len(content)} 字符"


@tool
def send_notification(recipient: str, message: str) -> str:
    """发送通知"""
    return f"通知已发送给 {recipient}: {message[:30]}..."


@tool
def analyze_data(data_type: str) -> str:
    """分析数据"""
    return f"{data_type} 分析完成：发现 3 个趋势，2 个异常"


@tool
def create_visualization(chart_type: str, data: str) -> str:
    """创建可视化图表"""
    return f"已创建 {chart_type} 图表，数据点: {len(data.split())}"


# ========== Schema 定义 ==========

class AnalysisResult(BaseModel):
    """分析结果"""
    summary: str = Field(description="分析摘要")
    key_findings: List[str] = Field(description="关键发现")
    recommendations: List[str] = Field(description="建议")


class WorkflowStatus(BaseModel):
    """工作流状态"""
    step: str = Field(description="当前步骤")
    status: str = Field(description="状态")
    progress: int = Field(description="进度百分比")


# ========== 示例函数 ==========

async def data_analysis_workflow():
    """数据分析工作流"""
    print("=" * 50)
    print("数据分析工作流")
    print("=" * 50)

    # 定义专业子 Agent
    data_collector = SubAgent(
        name="data_collector",
        description="数据收集员，负责从数据库获取数据",
        system_prompt="你是数据收集员，使用 search_database 工具收集所需数据。"
    )

    analyst = SubAgent(
        name="analyst",
        description="分析师，负责分析数据并发现规律",
        system_prompt="你是数据分析师，分析数据并总结关键发现。"
    )

    visualizer = SubAgent(
        name="visualizer",
        description="可视化专家，负责创建图表",
        system_prompt="你是可视化专家，使用 create_visualization 创建图表。"
    )

    # 主协调 Agent
    coordinator = get_agent(
        model="Qwen2.5-72B",
        tools=[search_database, analyze_data, create_visualization, generate_report],
        subagents=[data_collector, analyst, visualizer],
        system_prompt="""你是数据分析工作流的协调者。

        标准流程：
        1. 数据收集 - 使用工具或委派给 data_collector
        2. 数据分析 - 使用 analyze_data 或委派给 analyst
        3. 创建图表 - 委派给 visualizer
        4. 生成报告 - 使用 generate_report

        根据任务复杂度决定是自己执行还是委派。""",
        name="workflow_coordinator"
    )

    print("\n用户: 分析本月的销售数据并生成报告")

    result = await coordinator.ainvoke({
        "messages": [HumanMessage(content="分析本月的销售数据，找出趋势，生成可视化报告")]}
    )

    print(f"\n工作流结果:\n{result['messages'][-1].content}")


async def customer_service_workflow():
    """客户服务工作流"""
    print("\n" + "=" * 50)
    print("客户服务工作流")
    print("=" * 50)

    @tool
    def get_customer_info(customer_id: str) -> str:
        """获取客户信息"""
        return f"客户 {customer_id}: 张三, VIP等级: 金卡, 积分: 5000"

    @tool
    def get_order_status(order_id: str) -> str:
        """获取订单状态"""
        return f"订单 {order_id}: 已发货, 预计3天内送达"

    @tool
    def create_ticket(customer_id: str, issue: str) -> str:
        """创建工单"""
        return f"已创建工单: CUS-{customer_id}-{hash(issue) % 10000}"

    @tool
    def escalate_ticket(ticket_id: str, reason: str) -> str:
        """升级工单"""
        return f"工单 {ticket_id} 已升级，原因: {reason}"

    # 客服 Agent
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_customer_info, get_order_status, create_ticket, escalate_ticket, send_notification],
        system_prompt="""你是客服助手。

        处理流程：
        1. 查询客户信息
        2. 了解问题
        3. 查询相关订单状态
        4. 创建工单或直接解决
        5. 必要时升级或发送通知

        始终保持友好和专业。""",
        checkpointer=MemorySaver(),
        name="service_agent"
    )

    thread_id = "service_001"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n用户: 我是客户 C001，我的订单 O12345 怎么还没到？")

    # 第一轮
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="我是客户 C001，我的订单 O12345 怎么还没到？")]},
        config=config
    )
    print(f"客服: {result1['messages'][-1].content}")

    # 继续对话
    print("\n用户: 好的，帮我创建一个工单跟踪一下")
    result2 = await agent.ainvoke(
        {"messages": [HumanMessage(content="帮我创建一个工单跟踪一下")]},
        config=config
    )
    print(f"客服: {result2['messages'][-1].content}")


async def content_production_workflow():
    """内容生产工作流"""
    print("\n" + "=" * 50)
    print("内容生产工作流")
    print("=" * 50)

    # 内容生产流水线
    researcher = SubAgent(
        name="researcher",
        description="研究员",
        system_prompt="你是研究员，收集和整理信息。"
    )

    writer = SubAgent(
        name="writer",
        description="作者",
        system_prompt="你是作者，撰写高质量内容。"
    )

    editor = SubAgent(
        name="editor",
        description="编辑",
        system_prompt="你是编辑，审核和润色内容。"
    )

    seo_specialist = SubAgent(
        name="seo_specialist",
        description="SEO专家",
        system_prompt="你是SEO专家，优化内容以提高搜索排名。"
    )

    # 内容生产协调者
    producer = get_agent(
        model="Qwen2.5-72B",
        subagents=[researcher, writer, editor, seo_specialist],
        response_format=AnalysisResult,  # 结构化输出
        system_prompt="""你是内容生产协调者。

        生产流程：
        1. researcher - 收集主题信息
        2. writer - 撰写初稿
        3. editor - 审核润色
        4. seo_specialist - SEO优化

        最后输出结构化的分析结果。""",
        name="content_producer"
    )

    print("\n用户: 生产一篇关于 '人工智能在教育领域应用' 的文章")

    result = await producer.ainvoke({
        "messages": [HumanMessage(content="生产一篇关于 '人工智能在教育领域应用' 的文章概要")]}
    )

    print(f"\n生产结果:\n{result['messages'][-1].content}")


async def approval_workflow():
    """审批工作流"""
    print("\n" + "=" * 50)
    print("审批工作流")
    print("=" * 50)

    @tool
    def submit_request(request_type: str, details: str) -> str:
        """提交申请"""
        return f"申请已提交: {request_type}, ID: REQ-{hash(details) % 10000}"

    @tool
    def check_approval_status(request_id: str) -> str:
        """检查审批状态"""
        return f"申请 {request_id}: 待审批"

    @tool
    def approve_request(request_id: str, approver: str, comment: str) -> str:
        """批准申请"""
        return f"申请 {request_id} 已被 {approver} 批准: {comment}"

    @tool
    def reject_request(request_id: str, approver: str, reason: str) -> str:
        """拒绝申请"""
        return f"申请 {request_id} 被 {approver} 拒绝: {reason}"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[submit_request, check_approval_status, approve_request, reject_request, send_notification],
        checkpointer=MemorySaver(),
        interrupt_on={"tools": ["approve_request", "reject_request"]},  # 需要人工确认
        system_prompt="""你是审批流程助手。

        流程：
        1. 提交申请
        2. 等待审批
        3. 发送通知

        批准或拒绝需要人工确认。""",
        name="approval_agent"
    )

    thread_id = "approval_001"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n用户: 提交一个请假申请，请假3天")

    # 提交申请
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="提交一个请假申请，请假3天，原因是家庭事务")]},
        config=config
    )
    print(f"结果: {result1['messages'][-1].content}")

    # 检查状态
    state = await agent.aget_state(config)
    if state.next:
        print("\n等待人工审批...")

        # 模拟审批
        print("审批人决定: 同意")
        result2 = await agent.ainvoke(
            {"messages": [HumanMessage(content="经理同意，批准申请")]},
            config=config
        )
        print(f"最终结果: {result2['messages'][-1].content}")


async def multi_source_integration():
    """多数据源集成工作流"""
    print("\n" + "=" * 50)
    print("多数据源集成工作流")
    print("=" * 50)

    @tool
    def fetch_from_api(endpoint: str) -> str:
        """从API获取数据"""
        return f"API {endpoint} 返回: {{'status': 'ok', 'data': [...]}}"

    @tool
    def query_database(sql: str) -> str:
        """查询数据库"""
        return f"SQL查询返回 10 行数据"

    @tool
    def read_file(file_path: str) -> str:
        """读取文件"""
        return f"文件内容: {file_path} 包含 100 行"

    @tool
    def merge_data(sources: str) -> str:
        """合并数据"""
        return f"已合并 {sources} 个数据源，共 120 条记录"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[fetch_from_api, query_database, read_file, merge_data, generate_report],
        system_prompt="""你是数据集成专家。

        工作流程：
        1. 从多个来源获取数据（API、数据库、文件）
        2. 合并数据
        3. 生成整合报告

        根据任务选择合适的数据源。""",
        name="integration_agent"
    )

    print("\n用户: 从用户API、订单数据库和配置文件整合数据，生成报告")

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="从 /api/users 获取用户数据，从 orders 表获取订单数据，从 config.json 读取配置，然后整合生成报告")]}
    )

    print(f"\n整合结果:\n{result['messages'][-1].content}")


async def event_driven_workflow():
    """事件驱动工作流"""
    print("\n" + "=" * 50)
    print("事件驱动工作流")
    print("=" * 50)

    @tool
    def trigger_event(event_type: str, data: str) -> str:
        """触发事件"""
        return f"事件已触发: {event_type}"

    @tool
    def subscribe_handler(event_type: str, handler: str) -> str:
        """注册事件处理器"""
        return f"已注册处理器: {handler} -> {event_type}"

    @tool
    def process_event(event_type: str, event_data: str) -> str:
        """处理事件"""
        return f"已处理事件 {event_type}: {event_data[:30]}..."

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[trigger_event, subscribe_handler, process_event, send_notification],
        system_prompt="""你是事件处理协调者。

        工作模式：
        1. 监听事件
        2. 触发相应的处理器
        3. 发送通知

        根据事件类型选择处理方式。""",
        name="event_agent"
    )

    print("\n用户: 当用户注册时，发送欢迎邮件并创建初始数据")

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="设置事件处理：当 user_registered 事件发生时，发送欢迎邮件，并在数据库创建初始记录")]}
    )

    print(f"\n配置结果:\n{result['messages'][-1].content}")


async def conditional_workflow():
    """条件分支工作流"""
    print("\n" + "=" * 50)
    print("条件分支工作流")
    print("=" * 50)

    @tool
    def check_inventory(product_id: str) -> str:
        """检查库存"""
        # 模拟库存检查
        return "库存: 5 件"

    @tool
    def reorder_product(product_id: str, quantity: int) -> str:
        """补货"""
        return f"已下单补货: {product_id} x {quantity}"

    @tool
    def notify_manager(message: str) -> str:
        """通知经理"""
        return f"已通知经理: {message}"

    @tool
    def update_status(product_id: str, status: str) -> str:
        """更新状态"""
        return f"产品 {product_id} 状态更新为: {status}"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[check_inventory, reorder_product, notify_manager, update_status],
        system_prompt="""你是库存管理助手。

        决策逻辑：
        - 库存 > 10: 正常
        - 库存 5-10: 警告，通知经理
        - 库存 < 5: 紧急，立即补货并通知经理

        根据库存情况执行不同操作。""",
        name="inventory_agent"
    )

    print("\n用户: 检查产品 P001 的库存并采取相应措施")

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="检查产品 P001 的库存，根据库存情况执行相应操作")]}
    )

    print(f"\n处理结果:\n{result['messages'][-1].content}")


async def main():
    """运行所有复杂工作流示例"""
    print("\n" + "=" * 60)
    print("示例 11.1: 数据分析工作流")
    print("=" * 60)
    await data_analysis_workflow()

    print("\n" + "=" * 60)
    print("示例 11.2: 客户服务工作流")
    print("=" * 60)
    await customer_service_workflow()

    print("\n" + "=" * 60)
    print("示例 11.3: 内容生产工作流")
    print("=" * 60)
    await content_production_workflow()

    print("\n" + "=" * 60)
    print("示例 11.4: 审批工作流")
    print("=" * 60)
    await approval_workflow()

    print("\n" + "=" * 60)
    print("示例 11.5: 多数据源集成工作流")
    print("=" * 60)
    await multi_source_integration()

    print("\n" + "=" * 60)
    print("示例 11.6: 事件驱动工作流")
    print("=" * 60)
    await event_driven_workflow()

    print("\n" + "=" * 60)
    print("示例 11.7: 条件分支工作流")
    print("=" * 60)
    await conditional_workflow()


if __name__ == "__main__":
    asyncio.run(main())
