"""
示例 10: 自定义 LLM 配置
=======================

展示如何精细控制 LLM 的行为，包括温度、超时、重试等参数。

运行方式:
    python -m sycommon.agent.examples.10_custom_llm
"""
import asyncio
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool

from sycommon.agent import get_agent
from sycommon.llm import get_llm


# ========== 工具定义 ==========

@tool
def get_info(topic: str) -> str:
    """获取信息"""
    return f"关于 {topic} 的信息"


# ========== 示例函数 ==========

async def temperature_comparison():
    """不同温度对比"""
    print("=" * 50)
    print("温度参数对比")
    print("=" * 50)

    prompt = "给我讲一个短笑话"

    # 低温度 - 稳定输出
    print("\n低温度 (0.1) - 稳定、确定性高:")
    for i in range(2):
        agent = get_agent(
            model="Qwen2.5-72B",
            temperature=0.1,
            system_prompt="你是一个幽默的助手。"
        )
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=prompt)]}
        )
        print(f"  {i+1}. {result['messages'][-1].content[:80]}...")

    # 高温度 - 创造性输出
    print("\n高温度 (0.9) - 创造性、多样性:")
    for i in range(2):
        agent = get_agent(
            model="Qwen2.5-72B",
            temperature=0.9,
            system_prompt="你是一个幽默的助手。"
        )
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=prompt)]}
        )
        print(f"  {i+1}. {result['messages'][-1].content[:80]}...")


async def timeout_configuration():
    """超时配置"""
    print("\n" + "=" * 50)
    print("超时配置")
    print("=" * 50)

    # 短超时
    print("\n短超时 (10秒):")
    agent = get_agent(
        model="Qwen2.5-72B",
        timeout=10,
        system_prompt="你是一个助手。"
    )

    try:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content="你好")]}
        )
        print(f"成功: {result['messages'][-1].content[:50]}...")
    except asyncio.TimeoutError:
        print("超时！")

    # 长超时
    print("\n长超时 (180秒):")
    agent = get_agent(
        model="Qwen2.5-72B",
        timeout=180,
        system_prompt="你是一个助手。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="你好")]}
    )
    print(f"成功: {result['messages'][-1].content[:50]}...")


async def retry_configuration():
    """重试配置"""
    print("\n" + "=" * 50)
    print("重试配置")
    print("=" * 50)

    # 少重试
    print("\n少重试 (1次):")
    agent = get_agent(
        model="Qwen2.5-72B",
        max_retries=1,
        system_prompt="你是一个助手。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="你好")]}
    )
    print(f"成功: {result['messages'][-1].content[:50]}...")

    # 多重试
    print("\n多重试 (5次):")
    agent = get_agent(
        model="Qwen2.5-72B",
        max_retries=5,
        system_prompt="你是一个助手。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="你好")]}
    )
    print(f"成功: {result['messages'][-1].content[:50]}...")


async def use_custom_llm():
    """使用自定义 LLM 实例"""
    print("\n" + "=" * 50)
    print("使用自定义 LLM 实例")
    print("=" * 50)

    # 方式1：通过 get_agent 参数
    print("\n方式1: 通过 get_agent 参数")
    agent1 = get_agent(
        model="Qwen2.5-72B",
        temperature=0.5,
        timeout=60,
        system_prompt="你是一个助手。"
    )

    result1 = await agent1.ainvoke({
        "messages": [HumanMessage(content="介绍你自己")]}
    )
    print(f"结果: {result1['messages'][-1].content[:100]}...")

    # 方式2：使用预配置的 LLM
    print("\n方式2: 使用预配置的 LLM")
    custom_llm = get_llm(
        "Qwen2.5-72B",
        temperature=0.3,
        max_tokens=100,
        wrap_structured=False
    )

    agent2 = get_agent(
        model=custom_llm,  # 直接传入 LLM 实例
        system_prompt="你是一个简洁的助手。"
    )

    result2 = await agent2.ainvoke({
        "messages": [HumanMessage(content="介绍你自己")]}
    )
    print(f"结果: {result2['messages'][-1].content}")


async def different_models():
    """使用不同模型"""
    print("\n" + "=" * 50)
    print("使用不同模型")
    print("=" * 50)

    models = [
        "Qwen2.5-72B",
        # 可以添加更多模型
    ]

    question = "用一句话解释什么是递归"

    for model_name in models:
        print(f"\n模型: {model_name}")
        try:
            agent = get_agent(
                model=model_name,
                temperature=0.3,
                system_prompt="你是一个简洁的助手。"
            )

            result = await agent.ainvoke({
                "messages": [HumanMessage(content=question)]}
            )
            print(f"回答: {result['messages'][-1].content}")
        except Exception as e:
            print(f"错误: {e}")


async def model_with_tools():
    """带工具的不同配置"""
    print("\n" + "=" * 50)
    print("带工具的不同 LLM 配置")
    print("=" * 50)

    # 精确模式 - 低温度
    print("\n精确模式 (temperature=0.1):")
    precise_agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_info],
        temperature=0.1,
        system_prompt="你是一个精确的信息查询助手。"
    )

    result1 = await precise_agent.ainvoke({
        "messages": [HumanMessage(content="获取 Python 的信息")]}
    )
    print(f"结果: {result1['messages'][-1].content}")

    # 创造模式 - 高温度
    print("\n创造模式 (temperature=0.8):")
    creative_agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_info],
        temperature=0.8,
        system_prompt="你是一个有创意的助手，可以展开联想。"
    )

    result2 = await creative_agent.ainvoke({
        "messages": [HumanMessage(content="获取 Python 的信息，并发挥想象")]}
    )
    print(f"结果: {result2['messages'][-1].content[:150]}...")


async def combined_parameters():
    """组合参数配置"""
    print("\n" + "=" * 50)
    print("组合参数配置")
    print("=" * 50)

    # 生产环境配置
    print("\n生产环境配置 (稳定、可靠):")
    prod_agent = get_agent(
        model="Qwen2.5-72B",
        temperature=0.1,      # 低温度，稳定输出
        timeout=60,           # 适中超时
        max_retries=3,        # 多次重试
        system_prompt="你是一个可靠的助手。"
    )

    result = await prod_agent.ainvoke({
        "messages": [HumanMessage(content="1+1等于几？")]}
    )
    print(f"结果: {result['messages'][-1].content}")

    # 开发环境配置
    print("\n开发环境配置 (快速反馈):")
    dev_agent = get_agent(
        model="Qwen2.5-72B",
        temperature=0.5,
        timeout=30,           # 短超时
        max_retries=1,        # 少重试
        debug=True,           # 调试模式
        system_prompt="你是一个助手。"
    )

    result = await dev_agent.ainvoke({
        "messages": [HumanMessage(content="1+1等于几？")]}
    )
    print(f"结果: {result['messages'][-1].content}")


async def max_tokens_limit():
    """max_tokens 限制"""
    print("\n" + "=" * 50)
    print("max_tokens 限制")
    print("=" * 50)

    # 通过预配置 LLM 限制输出长度
    llm = get_llm(
        "Qwen2.5-72B",
        max_tokens=50,  # 限制输出
        wrap_structured=False
    )

    agent = get_agent(
        model=llm,
        system_prompt="你是一个助手。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="详细介绍一下 Python 编程语言的历史和特点")]}
    )

    print(f"输出（约50 tokens）:\n{result['messages'][-1].content}")
    print(f"\n实际长度: {len(result['messages'][-1].content)} 字符")


async def llm_with_structured_output():
    """LLM 与结构化输出"""
    from pydantic import BaseModel, Field

    class Answer(BaseModel):
        answer: str = Field(description="答案")
        confidence: float = Field(description="置信度 0-1")

    print("\n" + "=" * 50)
    print("LLM 与结构化输出")
    print("=" * 50)

    # 使用低温度确保结构化输出稳定
    agent = get_agent(
        model="Qwen2.5-72B",
        temperature=0.1,  # 低温度
        response_format=Answer,
        system_prompt="你是一个回答问题的助手，给出答案和置信度。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="地球是圆的吗？")]}
    )

    print(f"结构化输出: {result['messages'][-1].content}")


async def main():
    """运行所有自定义 LLM 示例"""
    print("\n" + "=" * 60)
    print("示例 10.1: 温度参数对比")
    print("=" * 60)
    await temperature_comparison()

    print("\n" + "=" * 60)
    print("示例 10.2: 超时配置")
    print("=" * 60)
    await timeout_configuration()

    print("\n" + "=" * 60)
    print("示例 10.3: 重试配置")
    print("=" * 60)
    await retry_configuration()

    print("\n" + "=" * 60)
    print("示例 10.4: 使用自定义 LLM 实例")
    print("=" * 60)
    await use_custom_llm()

    print("\n" + "=" * 60)
    print("示例 10.5: 使用不同模型")
    print("=" * 60)
    await different_models()

    print("\n" + "=" * 60)
    print("示例 10.6: 带工具的不同配置")
    print("=" * 60)
    await model_with_tools()

    print("\n" + "=" * 60)
    print("示例 10.7: 组合参数配置")
    print("=" * 60)
    await combined_parameters()

    print("\n" + "=" * 60)
    print("示例 10.8: max_tokens 限制")
    print("=" * 60)
    await max_tokens_limit()

    print("\n" + "=" * 60)
    print("示例 10.9: LLM 与结构化输出")
    print("=" * 60)
    await llm_with_structured_output()


if __name__ == "__main__":
    asyncio.run(main())
