"""
示例 05: 流式输出
================

展示如何使用流式输出，实时获取 Agent 的响应。

运行方式:
    python -m sycommon.agent.examples.05_streaming
"""
import asyncio
import sys
from langchain_core.messages import HumanMessage

from sycommon.agent import get_agent


async def basic_streaming():
    """基础流式输出"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个讲故事的高手，故事要生动有趣。"
    )

    print("=" * 50)
    print("基础流式输出 - 讲故事")
    print("=" * 50)
    print("\n用户: 讲一个关于勇敢的小兔子的故事")
    print("\nAgent: ", end="", flush=True)

    # 使用 astream_events 获取流式输出
    async for event in agent.astream_events(
        {"messages": [HumanMessage(content="讲一个关于勇敢的小兔子的故事")]},
        version="v1"
    ):
        # 捕获 LLM 的流式输出
        if event["event"] == "on_chat_model_stream":
            chunk = event["data"]["chunk"]
            if hasattr(chunk, "content") and chunk.content:
                print(chunk.content, end="", flush=True)

    print("\n\n故事讲完了！")


async def stream_with_tool_calls():
    """流式输出 + 工具调用"""
    from langchain_core.tools import tool

    @tool
    def get_fact(topic: str) -> str:
        """获取有趣的事实"""
        facts = {
            "太空": "一天在金星上比一年还长。",
            "动物": "蓝鲸的心脏大到可以让一个小孩在动脉里游泳。",
            "科技": "第一台电脑的重量超过 27 吨。",
        }
        return facts.get(topic, f"关于{topic}的有趣事实...")

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_fact],
        system_prompt="你是一个知识渊博的助手，可以分享有趣的事实。"
    )

    print("\n" + "=" * 50)
    print("流式输出 + 工具调用")
    print("=" * 50)
    print("\n用户: 告诉我一个关于太空的有趣事实")

    # 流式处理
    tool_called = False
    async for event in agent.astream_events(
        {"messages": [HumanMessage(content="告诉我一个关于太空的有趣事实")]},
        version="v1"
    ):
        event_type = event["event"]

        # 工具调用开始
        if event_type == "on_tool_start":
            print(f"\n[调用工具: {event['name']}]")
            tool_called = True

        # 工具调用结束
        elif event_type == "on_tool_end":
            print(f"[工具返回: {event['data'].get('output', '')[:100]}...]")
            print("\nAgent: ", end="", flush=True)

        # LLM 流式输出
        elif event_type == "on_chat_model_stream":
            chunk = event["data"]["chunk"]
            if hasattr(chunk, "content") and chunk.content:
                print(chunk.content, end="", flush=True)

    print()


async def stream_with_callback():
    """使用回调函数处理流式输出"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个诗人，擅长写古诗。"
    )

    collected_content = []

    def on_token(token: str):
        """处理每个 token"""
        collected_content.append(token)
        print(token, end="", flush=True)

    print("\n" + "=" * 50)
    print("使用回调处理流式输出")
    print("=" * 50)
    print("\n用户: 写一首关于春天的七言绝句")
    print("\nAgent: ", end="", flush=True)

    async for event in agent.astream_events(
        {"messages": [HumanMessage(content="写一首关于春天的七言绝句")]},
        version="v1"
    ):
        if event["event"] == "on_chat_model_stream":
            chunk = event["data"]["chunk"]
            if hasattr(chunk, "content") and chunk.content:
                on_token(chunk.content)

    print(f"\n\n收集到的内容长度: {len(''.join(collected_content))} 字符")


async def stream_with_timeout():
    """带超时的流式输出"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手，回答要详细但不要过于冗长。"
    )

    print("\n" + "=" * 50)
    print("带超时的流式输出")
    print("=" * 50)
    print("\n用户: 简单介绍一下量子计算")

    try:
        # 设置超时
        async with asyncio.timeout(30):  # 30秒超时
            async for event in agent.astream_events(
                {"messages": [HumanMessage(content="简单介绍一下量子计算")]},
                version="v1"
            ):
                if event["event"] == "on_chat_model_stream":
                    chunk = event["data"]["chunk"]
                    if hasattr(chunk, "content") and chunk.content:
                        print(chunk.content, end="", flush=True)
            print()
    except asyncio.TimeoutError:
        print("\n[超时：响应时间过长]")


async def stream_with_progress():
    """带进度显示的流式输出"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。"
    )

    print("\n" + "=" * 50)
    print("带进度显示的流式输出")
    print("=" * 50)
    print("\n用户: 写一段100字左右的短文")

    token_count = 0
    start_time = asyncio.get_event_loop().time()

    print("\nAgent: ", end="", flush=True)

    async for event in agent.astream_events(
        {"messages": [HumanMessage(content="写一段100字左右的短文，主题是友谊")]},
        version="v1"
    ):
        if event["event"] == "on_chat_model_stream":
            chunk = event["data"]["chunk"]
            if hasattr(chunk, "content") and chunk.content:
                token_count += 1
                print(chunk.content, end="", flush=True)

    end_time = asyncio.get_event_loop().time()
    duration = end_time - start_time

    print(f"\n\n统计:")
    print(f"- 生成 token 数: {token_count}")
    print(f"- 耗时: {duration:.2f} 秒")
    print(f"- 平均速度: {token_count/duration:.1f} tokens/秒")


async def stream_astream_tokens():
    """使用 astream 方法（更简单）"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。"
    )

    print("\n" + "=" * 50)
    print("使用 astream 方法")
    print("=" * 50)
    print("\n用户: 什么是人工智能？用一句话回答")

    # astream 返回的是状态更新
    async for state in agent.astream(
        {"messages": [HumanMessage(content="什么是人工智能？用一句话回答")]}
    ):
        # state 是一个字典，包含各个节点的输出
        for node_name, node_output in state.items():
            if "messages" in node_output:
                last_msg = node_output["messages"][-1]
                if hasattr(last_msg, "content"):
                    print(f"\n节点 [{node_name}] 输出:")
                    print(last_msg.content)


async def stream_multiple_questions():
    """流式处理多个问题"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手，每个回答控制在50字以内。"
    )

    questions = [
        "什么是 Python？",
        "什么是 JavaScript？",
        "什么是 Go？"
    ]

    print("\n" + "=" * 50)
    print("流式处理多个问题")
    print("=" * 50)

    for i, question in enumerate(questions, 1):
        print(f"\n--- 问题 {i}: {question} ---")
        print("Agent: ", end="", flush=True)

        async for event in agent.astream_events(
            {"messages": [HumanMessage(content=question)]},
            version="v1"
        ):
            if event["event"] == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                if hasattr(chunk, "content") and chunk.content:
                    print(chunk.content, end="", flush=True)

        print()  # 换行


async def stream_interruptible():
    """可中断的流式输出"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个详细解答问题的助手。"
    )

    print("\n" + "=" * 50)
    print("可中断的流式输出")
    print("=" * 50)
    print("\n用户: 详细介绍一下机器学习的发展历史")
    print("\nAgent: ", end="", flush=True)

    stop_flag = False
    char_count = 0
    max_chars = 500  # 最多输出500字符

    async for event in agent.astream_events(
        {"messages": [HumanMessage(content="详细介绍一下机器学习的发展历史")]},
        version="v1"
    ):
        if stop_flag:
            break

        if event["event"] == "on_chat_model_stream":
            chunk = event["data"]["chunk"]
            if hasattr(chunk, "content") and chunk.content:
                for char in chunk.content:
                    char_count += 1
                    if char_count > max_chars:
                        print("...", end="")
                        stop_flag = True
                        break
                    print(char, end="", flush=True)

    print(f"\n\n[输出已截断，达到 {max_chars} 字符限制]")


async def main():
    """运行所有流式输出示例"""
    print("\n" + "=" * 60)
    print("示例 5.1: 基础流式输出")
    print("=" * 60)
    await basic_streaming()

    print("\n" + "=" * 60)
    print("示例 5.2: 流式输出 + 工具调用")
    print("=" * 60)
    await stream_with_tool_calls()

    print("\n" + "=" * 60)
    print("示例 5.3: 使用回调处理流式输出")
    print("=" * 60)
    await stream_with_callback()

    print("\n" + "=" * 60)
    print("示例 5.4: 带超时的流式输出")
    print("=" * 60)
    await stream_with_timeout()

    print("\n" + "=" * 60)
    print("示例 5.5: 带进度显示的流式输出")
    print("=" * 60)
    await stream_with_progress()

    print("\n" + "=" * 60)
    print("示例 5.6: 使用 astream 方法")
    print("=" * 60)
    await stream_astream_tokens()

    print("\n" + "=" * 60)
    print("示例 5.7: 流式处理多个问题")
    print("=" * 60)
    await stream_multiple_questions()

    print("\n" + "=" * 60)
    print("示例 5.8: 可中断的流式输出")
    print("=" * 60)
    await stream_interruptible()


if __name__ == "__main__":
    asyncio.run(main())
