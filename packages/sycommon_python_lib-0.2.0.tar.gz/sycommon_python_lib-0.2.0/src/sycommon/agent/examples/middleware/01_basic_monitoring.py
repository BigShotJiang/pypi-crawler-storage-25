"""
中间件示例 01: 基础监控中间件
============================

展示基于 AgentMiddleware 的基础监控、日志、计时等中间件。

运行方式:
    python -m sycommon.agent.examples.middleware.01_basic_monitoring
"""
import asyncio
import time
from typing import Any, Dict, List, Optional, Callable, Awaitable
from datetime import datetime
from collections import defaultdict
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.tools import BaseTool
from langchain.agents.middleware.types import AgentMiddleware, ModelRequest, ModelResponse
from langchain.agents.middleware.types import ToolCallRequest
from langchain_core.messages import ToolMessage

from sycommon.agent import get_agent


# ========== 基础中间件定义 ==========

class TimingMiddleware(AgentMiddleware):
    """
    计时中间件

    功能：测量 Agent 执行各阶段耗时
    继承自 AgentMiddleware
    """

    def __init__(self, name: str = "Timer", verbose: bool = True):
        self.name = name
        self.verbose = verbose
        self._timings: List[float] = []
        self._model_timings: List[float] = []
        self._tool_timings: List[float] = []

    def before_agent(self, state, _runtime) -> dict[str, Any] | None:
        """Agent 执行开始"""
        state["_start_time"] = time.time()
        if self.verbose:
            print(f"[{self.name}] ⏱️ Agent 开始执行...")
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """Agent 执行结束"""
        start = state.get("_start_time", time.time())
        elapsed = time.time() - start
        self._timings.append(elapsed)

        if self.verbose:
            print(f"[{self.name}] ⏱️ Agent 执行完成 - 耗时: {elapsed:.3f}秒")
        return None

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """包装模型调用，测量耗时"""
        start = time.time()
        if self.verbose:
            print(f"[{self.name}] ⏱️ 模型调用开始...")

        response = handler(request)

        elapsed = time.time() - start
        self._model_timings.append(elapsed)

        if self.verbose:
            print(f"[{self.name}] ⏱️ 模型调用完成 - 耗时: {elapsed:.3f}秒")

        return response

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步包装模型调用"""
        start = time.time()
        if self.verbose:
            print(f"[{self.name}] ⏱️ 异步模型调用开始...")

        response = await handler(request)

        elapsed = time.time() - start
        self._model_timings.append(elapsed)

        if self.verbose:
            print(f"[{self.name}] ⏱️ 异步模型调用完成 - 耗时: {elapsed:.3f}秒")

        return response

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """包装工具调用，测量耗时"""
        start = time.time()
        tool_name = request.tool_call.get("name", "unknown")

        if self.verbose:
            print(f"[{self.name}] ⏱️ 工具调用开始: {tool_name}")

        result = handler(request)

        elapsed = time.time() - start
        self._tool_timings.append(elapsed)

        if self.verbose:
            print(f"[{self.name}] ⏱️ 工具调用完成: {tool_name} - 耗时: {elapsed:.3f}秒")

        return result

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]]
    ) -> ToolMessage:
        """异步包装工具调用"""
        start = time.time()
        tool_name = request.tool_call.get("name", "unknown")

        if self.verbose:
            print(f"[{self.name}] ⏱️ 异步工具调用开始: {tool_name}")

        result = await handler(request)

        elapsed = time.time() - start
        self._tool_timings.append(elapsed)

        if self.verbose:
            print(f"[{self.name}] ⏱️ 异步工具调用完成: {tool_name} - 耗时: {elapsed:.3f}秒")

        return result

    @property
    def stats(self) -> Dict[str, Any]:
        def calc_stats(timings: List[float]) -> Dict[str, float]:
            if not timings:
                return {"count": 0, "total": 0, "avg": 0, "min": 0, "max": 0}
            return {
                "count": len(timings),
                "total": sum(timings),
                "avg": sum(timings) / len(timings),
                "min": min(timings),
                "max": max(timings)
            }
        return {
            "agent": calc_stats(self._timings),
            "model": calc_stats(self._model_timings),
            "tool": calc_stats(self._tool_timings)
        }


class LoggingMiddleware(AgentMiddleware):
    """
    日志中间件

    功能：记录 Agent 执行各阶段的日志
    """

    def __init__(self, name: str = "Logger", log_level: str = "INFO"):
        self.name = name
        self.log_level = log_level
        self._logs: List[Dict[str, Any]] = []

    def _log(self, phase: str, **kwargs):
        """记录日志"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "phase": phase,
            **kwargs
        }
        self._logs.append(entry)

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """Agent 执行前"""
        msg_count = len(state.get('messages', []))
        self._log("before_agent", messages=msg_count)
        print(f"[{self.name}] 📝 Agent执行前 - 消息数: {msg_count}")
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """Agent 执行后"""
        msg_count = len(state.get('messages', []))
        self._log("after_agent", messages=msg_count)
        print(f"[{self.name}] 📝 Agent执行后 - 消息数: {msg_count}")
        return None

    def before_model(self, state, runtime) -> dict[str, Any] | None:
        """模型调用前"""
        msg_count = len(state.get('messages', []))
        self._log("before_model", messages=msg_count)
        print(f"[{self.name}] 📝 模型调用前 - 消息数: {msg_count}")
        return None

    def after_model(self, state, runtime) -> dict[str, Any] | None:
        """模型调用后"""
        msg_count = len(state.get('messages', []))
        self._log("after_model", messages=msg_count)
        print(f"[{self.name}] 📝 模型调用后 - 消息数: {msg_count}")
        return None

    def get_logs(self) -> List[Dict[str, Any]]:
        return self._logs


class MetricsMiddleware(AgentMiddleware):
    """
    指标中间件

    功能：收集 Agent 执行的性能指标
    """

    def __init__(self):
        self._metrics: Dict[str, List[Any]] = defaultdict(list)
        self._start_time: float = 0

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录开始时间"""
        self._start_time = time.time()
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """收集指标"""
        elapsed = time.time() - self._start_time
        messages = state.get('messages', [])

        self._metrics['latency'].append(elapsed)
        self._metrics['message_count'].append(len(messages))

        return None

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """收集模型调用指标"""
        start = time.time()
        response = handler(request)
        elapsed = time.time() - start

        self._metrics['model_latency'].append(elapsed)

        # 统计 token 使用
        if hasattr(response, 'usage_metadata') and response.usage_metadata:
            tokens = response.usage_metadata.get('total_tokens', 0)
            self._metrics['tokens_used'].append(tokens)

        return response

    def get_stats(self) -> Dict[str, Any]:
        stats = {}
        for key, values in self._metrics.items():
            if values:
                if all(isinstance(v, (int, float)) for v in values):
                    stats[key] = {
                        'count': len(values),
                        'sum': sum(values),
                        'avg': sum(values) / len(values),
                        'min': min(values),
                        'max': max(values)
                    }
                else:
                    stats[key] = {'count': len(values), 'values': values}
        return stats


class TracingMiddleware(AgentMiddleware):
    """
    追踪中间件

    功能：分布式追踪，生成 trace_id 和 span_id
    """

    def __init__(self, service_name: str = "agent-service"):
        self.service_name = service_name
        self._traces: List[Dict[str, Any]] = []
        self._current_trace_id: Optional[str] = None

    def _generate_id(self, length: int = 16) -> str:
        """生成随机ID"""
        import hashlib
        return hashlib.md5(f"{time.time()}{id(self)}".encode()).hexdigest()[:length]

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """开始追踪"""
        import hashlib
        # 生成或获取 trace_id
        trace_id = state.get("_trace_id")
        if not trace_id:
            trace_id = self._generate_id(16)
        self._current_trace_id = trace_id

        span_id = self._generate_id(8)
        state["_trace_id"] = trace_id
        state["_span_id"] = span_id
        state["_trace_start"] = time.time()

        print(f"[Tracing] 🔍 开始追踪 trace_id={trace_id}, span_id={span_id}")
        return {"_trace_id": trace_id, "_span_id": span_id, "_trace_start": time.time()}

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """结束追踪"""
        elapsed = time.time() - state.get("_trace_start", time.time())

        trace = {
            "service": self.service_name,
            "trace_id": state.get("_trace_id"),
            "span_id": state.get("_span_id"),
            "duration_ms": elapsed * 1000,
            "timestamp": datetime.now().isoformat()
        }
        self._traces.append(trace)

        print(f"[Tracing] 🔍 追踪完成 - 耗时: {elapsed*1000:.2f}ms")
        return None

    def get_traces(self) -> List[Dict[str, Any]]:
        return self._traces


# ========== 示例函数 ==========

async def timing_example():
    """计时中间件示例"""
    print("=" * 60)
    print("示例 1: 计时中间件 (AgentMiddleware)")
    print("=" * 60)

    timer = TimingMiddleware("执行计时器")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。",
        middleware=[timer],
        name="timed_agent"
    )

    # 执行多次
    for i in range(2):
        await agent.ainvoke({"messages": [HumanMessage(content=f"问题{i+1}")]})

    print(f"\n📊 计时统计: {timer.stats}")


async def logging_example():
    """日志中间件示例"""
    print("\n" + "=" * 60)
    print("示例 2: 日志中间件")
    print("=" * 60)

    logger = LoggingMiddleware("详细日志器")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[logger],
        name="logged_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📋 日志条数: {len(logger.get_logs())}")


async def metrics_example():
    """指标中间件示例"""
    print("\n" + "=" * 60)
    print("示例 3: 指标收集中间件")
    print("=" * 60)

    metrics = MetricsMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。",
        middleware=[metrics],
        name="metrics_agent"
    )

    # 执行多次
    for i in range(3):
        await agent.ainvoke({"messages": [HumanMessage(content=f"测试{i+1}")]})

    print(f"\n📊 指标统计: {metrics.get_stats()}")


async def tracing_example():
    """追踪中间件示例"""
    print("\n" + "=" * 60)
    print("示例 4: 分布式追踪中间件")
    print("=" * 60)

    tracer = TracingMiddleware("my-agent-service")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[tracer],
        name="traced_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})
    await agent.ainvoke({"messages": [HumanMessage(content="世界")]})

    print(f"\n🔍 追踪记录: {len(tracer.get_traces())} 条")


async def combined_example():
    """组合使用示例"""
    print("\n" + "=" * 60)
    print("示例 5: 组合多个中间件")
    print("=" * 60)

    timer = TimingMiddleware("总计时")
    logger = LoggingMiddleware("执行日志")
    metrics = MetricsMiddleware()
    tracer = TracingMiddleware("combined-service")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[timer, logger, metrics, tracer],
        name="fully_monitored_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="综合测试")]})

    print(f"\n📊 综合统计:")
    print(f"  计时: {timer.stats}")
    print(f"  指标: {metrics.get_stats()}")


async def concurrent_monitoring():
    """并发监控示例"""
    print("\n" + "=" * 60)
    print("示例 6: 并发执行监控")
    print("=" * 60)

    metrics = MetricsMiddleware()
    timer = TimingMiddleware("并发计时")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。",
        middleware=[metrics, timer],
        name="concurrent_monitored_agent"
    )

    questions = [f"并发问题{i+1}" for i in range(3)]

    print(f"\n并发执行 {len(questions)} 个请求...")

    tasks = [
        agent.ainvoke({"messages": [HumanMessage(content=q)]})
        for q in questions
    ]
    await asyncio.gather(*tasks)

    print(f"\n📊 并发执行统计:")
    print(f"  总耗时: {timer.stats['agent']['total']:.3f}秒")
    print(f"  请求次数: {timer.stats['agent']['count']}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🚀 基础监控中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await timing_example()
    await logging_example()
    await metrics_example()
    await tracing_example()
    await combined_example()
    await concurrent_monitoring()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
