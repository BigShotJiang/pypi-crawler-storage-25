"""
中间件示例 07: 高级功能中间件
============================

展示 A/B 测试、配额控制、用户上下文等高级中间件，基于 AgentMiddleware。

运行方式:
    python -m sycommon.agent.examples.middleware.07_advanced
"""
import asyncio
import time
import random
import threading
import hashlib
from typing import Any, Dict, List, Optional, Callable, Awaitable
from datetime import datetime
from collections import defaultdict
from langchain_core.messages import HumanMessage, AIMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse
)

from sycommon.agent import get_agent


# ========== A/B 测试中间件 ==========

class ABTestMiddleware(AgentMiddleware):
    """
    A/B 测试中间件

    功能：支持不同版本的功能测试
    """

    def __init__(
        self,
        experiment_name: str,
        variants: Optional[Dict[str, float]] = None,
        user_assignment: str = "random"  # random, hash, round_robin
    ):
        self.experiment_name = experiment_name
        self.variants = variants or {"control": 0.5, "treatment": 0.5}
        self.user_assignment = user_assignment
        self._variant_counts: Dict[str, int] = defaultdict(int)
        self._round_robin_index = 0
        self._lock = threading.Lock()

    def _assign_variant(self, user_id: Optional[str] = None) -> str:
        """分配变体"""
        if self.user_assignment == "hash" and user_id:
            # 基于用户ID的哈希分配
            hash_val = int(hashlib.md5(f"{self.experiment_name}{user_id}".encode()).hexdigest(), 16)
            cumulative = 0.0
            for variant, weight in self.variants.items():
                cumulative += weight
                if (hash_val % 10000) / 10000 < cumulative:
                    return variant
            return list(self.variants.keys())[-1]
        elif self.user_assignment == "round_robin":
            # 轮询分配
            with self._lock:
                variants = list(self.variants.keys())
                variant = variants[self._round_robin_index % len(variants)]
                self._round_robin_index += 1
                return variant
        else:
            # 随机分配
            r = random.random()
            cumulative = 0.0
            for variant, weight in self.variants.items():
                cumulative += weight
                if r < cumulative:
                    return variant
            return list(self.variants.keys())[-1]

    def before_agent(self, state, _runtime) -> dict[str, Any] | None:
        """分配实验变体"""
        user_id = state.get("user_id") or state.get("session_id")
        variant = self._assign_variant(user_id)

        with self._lock:
            self._variant_counts[variant] += 1

        state["_experiment"] = self.experiment_name
        state["_variant"] = variant

        print(f"[ABTest] 🧪 实验 '{self.experiment_name}' 分配变体: {variant}")
        return {"_experiment": self.experiment_name, "_variant": variant}

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "experiment": self.experiment_name,
                "variant_counts": dict(self._variant_counts)
            }


class ABTestSystemPromptMiddleware(AgentMiddleware):
    """
    A/B 测试系统提示词中间件

    功能：根据实验变体使用 request.override() 修改系统提示词
    """

    VARIANT_PROMPTS = {
        "control": "你是一个助手。",
        "treatment": "你是一个专业、详细的助手，会提供全面的解答和示例。",
        "concise": "你是一个简洁的助手，会用最少的语言回答问题。"
    }

    def __init__(
        self,
        experiment_name: str = "system_prompt_test",
        variants: Optional[Dict[str, float]] = None
    ):
        self.experiment_name = experiment_name
        self.variants = variants or {"control": 0.33, "treatment": 0.34, "concise": 0.33}
        self._variant_counts: Dict[str, int] = defaultdict(int)
        self._lock = threading.Lock()

    def _assign_variant(self) -> str:
        """随机分配变体"""
        r = random.random()
        cumulative = 0.0
        for variant, weight in self.variants.items():
            cumulative += weight
            if r < cumulative:
                return variant
        return list(self.variants.keys())[-1]

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据实验变体使用 override() 修改系统提示词"""
        from langchain_core.messages import SystemMessage

        variant = self._assign_variant()
        system_prompt = self.VARIANT_PROMPTS.get(variant, self.VARIANT_PROMPTS["control"])

        with self._lock:
            self._variant_counts[variant] += 1

        print(f"[ABTestSystemPrompt] 🧪 变体 '{variant}': 使用对应的系统提示词")

        # 使用 override() 替换系统提示词
        new_request = request.override(
            system_message=SystemMessage(content=system_prompt)
        )

        return handler(new_request)

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "experiment": self.experiment_name,
                "variant_counts": dict(self._variant_counts)
            }


class FeatureFlagMiddleware(AgentMiddleware):
    """
    功能开关中间件

    功能：根据开关控制功能启用
    """

    def __init__(
        self,
        feature_flags: Optional[Dict[str, bool]] = None,
        user_overrides: Optional[Dict[str, List[str]]] = None
    ):
        self.feature_flags = feature_flags or {}
        self.user_overrides = user_overrides or {}  # feature -> [user_ids]
        self._flag_checks: Dict[str, int] = defaultdict(int)

    def is_enabled(self, feature: str, user_id: Optional[str] = None) -> bool:
        """检查功能是否启用"""
        self._flag_checks[feature] += 1

        # 检查用户覆盖
        if feature in self.user_overrides:
            if user_id and user_id in self.user_overrides[feature]:
                return True

        # 检查全局开关
        return self.feature_flags.get(feature, False)

    def before_agent(self, state, _runtime) -> dict[str, Any] | None:
        """记录功能状态"""
        user_id = state.get("user_id")
        flags_state = {}

        for feature in self.feature_flags:
            flags_state[feature] = self.is_enabled(feature, user_id)

        state["_feature_flags"] = flags_state
        print(f"[FeatureFlag] 🚩 功能状态: {flags_state}")
        return {"_feature_flags": flags_state}

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            "flags": self.feature_flags,
            "checks": dict(self._flag_checks)
        }


# ========== 配额中间件 ==========

class QuotaMiddleware(AgentMiddleware):
    """
    配额中间件

    功能：限制用户或全局的请求配额
    """

    def __init__(
        self,
        daily_limit: int = 100,
        hourly_limit: int = 20,
        per_user_limit: Optional[int] = None,
        global_limit: Optional[int] = None
    ):
        self.daily_limit = daily_limit
        self.hourly_limit = hourly_limit
        self.per_user_limit = per_user_limit
        self.global_limit = global_limit

        self._daily_counts: Dict[str, int] = defaultdict(int)  # date -> count
        self._hourly_counts: Dict[str, int] = defaultdict(int)  # hour -> count
        self._user_counts: Dict[str, int] = defaultdict(int)    # user_id -> count
        self._total_count = 0
        self._rejected_count = 0
        self._lock = threading.Lock()

    def _get_current_hour(self) -> str:
        return datetime.now().strftime("%Y-%m-%d-%H")

    def _get_current_date(self) -> str:
        return datetime.now().strftime("%Y-%m-%d")

    def _check_quota(self, user_id: Optional[str] = None) -> tuple:
        """检查配额"""
        date_key = self._get_current_date()
        hour_key = self._get_current_hour()

        # 检查全局限制
        if self.global_limit and self._total_count >= self.global_limit:
            return False, "全局配额已用尽"

        # 检查每日限制
        if self._daily_counts[date_key] >= self.daily_limit:
            return False, "每日配额已用尽"

        # 检查每小时限制
        if self._hourly_counts[hour_key] >= self.hourly_limit:
            return False, "每小时配额已用尽"

        # 检查用户限制
        if self.per_user_limit and user_id:
            if self._user_counts[user_id] >= self.per_user_limit:
                return False, f"用户配额已用尽"

        return True, "OK"

    def _increment(self, user_id: Optional[str] = None):
        """增加计数"""
        date_key = self._get_current_date()
        hour_key = self._get_current_hour()

        self._daily_counts[date_key] += 1
        self._hourly_counts[hour_key] += 1
        self._total_count += 1

        if user_id:
            self._user_counts[user_id] += 1

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查配额"""
        user_id = state.get("user_id")

        with self._lock:
            allowed, message = self._check_quota(user_id)

            if not allowed:
                self._rejected_count += 1
                print(f"[Quota] 🚫 配额限制: {message}")
                raise RuntimeError(f"配额限制: {message}")

            self._increment(user_id)
            print(f"[Quota] ✅ 配额检查通过")

        return None

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_count": self._total_count,
                "rejected_count": self._rejected_count,
                "daily_counts": dict(self._daily_counts),
                "hourly_counts": dict(self._hourly_counts),
                "user_counts": dict(self._user_counts)
            }


class RateLimitMiddleware(AgentMiddleware):
    """
    速率限制中间件

    功能：限制请求速率
    """

    def __init__(
        self,
        requests_per_second: float = 10.0,
        burst_size: int = 20,
        per_user: bool = False
    ):
        self.requests_per_second = requests_per_second
        self.burst_size = burst_size
        self.per_user = per_user

        # Token bucket 算法
        self._tokens: Dict[str, float] = defaultdict(lambda: float(burst_size))
        self._last_update: Dict[str, float] = defaultdict(time.time)
        self._rejected_count = 0
        self._lock = threading.Lock()

    def _get_tokens(self, key: str = "global") -> float:
        """获取当前 token 数"""
        now = time.time()
        elapsed = now - self._last_update[key]
        self._tokens[key] = min(
            self.burst_size,
            self._tokens[key] + elapsed * self.requests_per_second
        )
        self._last_update[key] = now
        return self._tokens[key]

    def _consume_token(self, key: str = "global") -> bool:
        """消费一个 token"""
        tokens = self._get_tokens(key)
        if tokens >= 1:
            self._tokens[key] -= 1
            return True
        return False

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查速率限制"""
        key = state.get("user_id", "global") if self.per_user else "global"

        with self._lock:
            if not self._consume_token(key):
                self._rejected_count += 1
                print(f"[RateLimit] 🚫 速率限制触发")
                raise RuntimeError("请求过于频繁，请稍后再试")

        print(f"[RateLimit] ✅ 请求通过")
        return None

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "rejected_count": self._rejected_count,
                "current_tokens": dict(self._tokens)
            }


# ========== 用户上下文中间件 ==========

class UserContextMiddleware(AgentMiddleware):
    """
    用户上下文中间件

    功能：管理用户会话和上下文
    """

    def __init__(self):
        self._user_sessions: Dict[str, Dict[str, Any]] = {}
        self._session_start_times: Dict[str, float] = {}
        self._lock = threading.Lock()

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """加载用户上下文"""
        user_id = state.get("user_id")
        if not user_id:
            return None

        with self._lock:
            if user_id not in self._user_sessions:
                self._user_sessions[user_id] = {
                    "created_at": datetime.now().isoformat(),
                    "request_count": 0,
                    "preferences": {}
                }
                self._session_start_times[user_id] = time.time()

            self._user_sessions[user_id]["request_count"] += 1
            self._user_sessions[user_id]["last_request"] = datetime.now().isoformat()

            user_context = self._user_sessions[user_id]

        print(f"[UserContext] 👤 用户 {user_id} - 请求 #{user_context['request_count']}")
        return {"user_context": user_context}

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """更新用户上下文"""
        user_id = state.get("user_id")
        if not user_id:
            return None

        with self._lock:
            if user_id in self._user_sessions:
                self._user_sessions[user_id]["last_response"] = datetime.now().isoformat()

        return None

    def get_user_context(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取用户上下文"""
        with self._lock:
            return self._user_sessions.get(user_id)

    def set_user_preference(self, user_id: str, key: str, value: Any):
        """设置用户偏好"""
        with self._lock:
            if user_id in self._user_sessions:
                self._user_sessions[user_id]["preferences"][key] = value

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "active_sessions": len(self._user_sessions),
                "sessions": {
                    uid: {"request_count": s["request_count"]}
                    for uid, s in self._user_sessions.items()
                }
            }


class SessionMiddleware(AgentMiddleware):
    """
    会话中间件

    功能：管理会话状态
    """

    def __init__(self, session_timeout: int = 1800):  # 30分钟
        self.session_timeout = session_timeout
        self._sessions: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def _cleanup_expired(self):
        """清理过期会话"""
        now = time.time()
        expired = [
            sid for sid, s in self._sessions.items()
            if now - s.get("last_activity", 0) > self.session_timeout
        ]
        for sid in expired:
            del self._sessions[sid]

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """获取或创建会话"""
        session_id = state.get("session_id")
        if not session_id:
            session_id = hashlib.md5(f"{time.time()}{id(state)}".encode()).hexdigest()[:16]

        with self._lock:
            self._cleanup_expired()

            if session_id not in self._sessions:
                self._sessions[session_id] = {
                    "created_at": time.time(),
                    "last_activity": time.time(),
                    "message_count": 0
                }
            else:
                self._sessions[session_id]["last_activity"] = time.time()

            self._sessions[session_id]["message_count"] += 1
            session_data = self._sessions[session_id]

        print(f"[Session] 📋 会话 {session_id[:8]}... - 消息 #{session_data['message_count']}")
        return {"session_id": session_id, "session_data": session_data}

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "active_sessions": len(self._sessions)
            }


# ========== 响应增强中间件 ==========

class ResponseEnrichmentMiddleware(AgentMiddleware):
    """
    响应增强中间件

    功能：增强响应内容
    """

    def __init__(
        self,
        add_timestamp: bool = True,
        add_version: bool = True,
        add_metadata: bool = True,
        version: str = "1.0.0"
    ):
        self.add_timestamp = add_timestamp
        self.add_version = add_version
        self.add_metadata = add_metadata
        self.version = version
        self._enriched_count = 0

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """增强响应"""
        metadata = {}

        if self.add_timestamp:
            metadata["timestamp"] = datetime.now().isoformat()

        if self.add_version:
            metadata["version"] = self.version

        if self.add_metadata:
            metadata["message_count"] = len(state.get("messages", []))
            metadata["session_id"] = state.get("session_id", "unknown")

        self._enriched_count += 1
        print(f"[ResponseEnrichment] ✨ 响应已增强: {metadata}")

        return {"_metadata": metadata}

    @property
    def stats(self) -> Dict[str, int]:
        return {"enriched_count": self._enriched_count}


class ContextEnrichmentMiddleware(AgentMiddleware):
    """
    上下文增强中间件

    功能：为请求添加额外上下文
    """

    def __init__(
        self,
        add_system_info: bool = True,
        add_environment: bool = True,
        environment: str = "production"
    ):
        self.add_system_info = add_system_info
        self.add_environment = add_environment
        self.environment = environment
        self._enriched_count = 0

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """增强上下文"""
        context = {}

        if self.add_system_info:
            context["system"] = {
                "timestamp": time.time(),
                "timezone": datetime.now().astimezone().tzname()
            }

        if self.add_environment:
            context["environment"] = self.environment

        self._enriched_count += 1
        print(f"[ContextEnrichment] 📊 上下文已增强")

        return {"_enriched_context": context}

    @property
    def stats(self) -> Dict[str, int]:
        return {"enriched_count": self._enriched_count}


# ========== 示例函数 ==========

async def ab_test_example():
    """A/B 测试示例"""
    print("=" * 60)
    print("示例 1: A/B 测试中间件")
    print("=" * 60)

    ab_test = ABTestMiddleware(
        experiment_name="new_response_format",
        variants={"control": 0.5, "treatment_a": 0.3, "treatment_b": 0.2},
        user_assignment="random"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[ab_test],
        name="ab_test_agent"
    )

    # 执行多次查看分配
    for i in range(5):
        await agent.ainvoke({"messages": [HumanMessage(content=f"测试{i+1}")]})

    print(f"\n📊 A/B 测试统计: {ab_test.stats}")


async def feature_flag_example():
    """功能开关示例"""
    print("\n" + "=" * 60)
    print("示例 2: 功能开关中间件")
    print("=" * 60)

    feature_flags = FeatureFlagMiddleware(
        feature_flags={
            "streaming": True,
            "caching": False,
            "analytics": True
        }
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[feature_flags],
        name="feature_flag_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 功能开关统计: {feature_flags.stats}")


async def quota_example():
    """配额限制示例"""
    print("\n" + "=" * 60)
    print("示例 3: 配额中间件")
    print("=" * 60)

    quota = QuotaMiddleware(
        daily_limit=100,
        hourly_limit=50
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[quota],
        name="quota_agent"
    )

    for i in range(2):
        await agent.ainvoke({"messages": [HumanMessage(content=f"测试{i+1}")]})

    print(f"\n📊 配额统计: {quota.stats}")


async def rate_limit_example():
    """速率限制示例"""
    print("\n" + "=" * 60)
    print("示例 4: 速率限制中间件")
    print("=" * 60)

    rate_limit = RateLimitMiddleware(
        requests_per_second=5,
        burst_size=10
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[rate_limit],
        name="rate_limited_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 速率限制统计: {rate_limit.stats}")


async def user_context_example():
    """用户上下文示例"""
    print("\n" + "=" * 60)
    print("示例 5: 用户上下文中间件")
    print("=" * 60)

    user_ctx = UserContextMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[user_ctx],
        name="user_context_agent"
    )

    # 模拟用户请求
    await agent.ainvoke({
        "messages": [HumanMessage(content="你好")],
        "user_id": "user123"
    })

    print(f"\n📊 用户上下文统计: {user_ctx.stats}")


async def session_example():
    """会话管理示例"""
    print("\n" + "=" * 60)
    print("示例 6: 会话中间件")
    print("=" * 60)

    session = SessionMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[session],
        name="session_agent"
    )

    await agent.ainvoke({
        "messages": [HumanMessage(content="你好")],
        "session_id": "test-session-123"
    })

    print(f"\n📊 会话统计: {session.stats}")


async def response_enrichment_example():
    """响应增强示例"""
    print("\n" + "=" * 60)
    print("示例 7: 响应增强中间件")
    print("=" * 60)

    enrichment = ResponseEnrichmentMiddleware(
        add_timestamp=True,
        add_version=True,
        version="2.0.0"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[enrichment],
        name="enriched_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 响应增强统计: {enrichment.stats}")


async def combined_advanced_example():
    """组合高级功能示例"""
    print("\n" + "=" * 60)
    print("示例 8: 组合高级功能")
    print("=" * 60)

    ab_test = ABTestMiddleware("combined_test")
    feature_flags = FeatureFlagMiddleware({"analytics": True})
    quota = QuotaMiddleware(daily_limit=1000)
    user_ctx = UserContextMiddleware()
    session = SessionMiddleware()
    enrichment = ResponseEnrichmentMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[ab_test, feature_flags, quota, user_ctx, session, enrichment],
        name="advanced_agent"
    )

    await agent.ainvoke({
        "messages": [HumanMessage(content="综合测试")],
        "user_id": "test_user",
        "session_id": "test_session"
    })

    print(f"\n📊 综合统计:")
    print(f"  A/B测试: {ab_test.stats}")
    print(f"  配额: {quota.stats}")
    print(f"  用户上下文: {user_ctx.stats}")
    print(f"  会话: {session.stats}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🚀 高级功能中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await ab_test_example()
    await feature_flag_example()
    await quota_example()
    await rate_limit_example()
    await user_context_example()
    await session_example()
    await response_enrichment_example()
    await combined_advanced_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
