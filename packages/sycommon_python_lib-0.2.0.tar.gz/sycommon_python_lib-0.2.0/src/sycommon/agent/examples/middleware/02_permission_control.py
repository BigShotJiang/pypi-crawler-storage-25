"""
中间件示例 02: 权限控制中间件
============================

展示各种权限控制、认证、授权相关的中间件，基于 AgentMiddleware。

运行方式:
    python -m sycommon.agent.examples.middleware.02_permission_control
"""
import asyncio
import time
import hashlib
import threading
from typing import Any, Dict, List, Optional, Callable, Set, Awaitable
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from langchain_core.messages import HumanMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse
)

from sycommon.agent import get_agent


# ========== 数据模型 ==========

@dataclass
class User:
    """用户模型"""
    user_id: str
    username: str
    role: str
    permissions: Set[str] = field(default_factory=set)
    groups: List[str] = field(default_factory=list)
    is_active: bool = True
    expires_at: Optional[datetime] = None


# ========== 权限控制中间件 ==========

class RoleBasedAccessMiddleware(AgentMiddleware):
    """
    基于角色的访问控制中间件 (RBAC)

    功能：根据用户角色控制访问权限
    """

    def __init__(
        self,
        role_permissions: Optional[Dict[str, Set[str]]] = None
    ):
        self.role_permissions = role_permissions or {
            "admin": {"*"},  # 管理员拥有所有权限
            "manager": {"read", "write", "delete", "report"},
            "user": {"read", "write"},
            "guest": {"read"}
        }
        self._denied_requests: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _extract_action(self, state) -> str:
        """从请求中提取操作类型"""
        messages = state.get("messages", [])
        if not messages:
            return "read"

        content = getattr(messages[-1], "content", "").lower()

        action_keywords = {
            "delete": ["删除", "delete", "移除", "remove"],
            "write": ["修改", "update", "编辑", "edit", "创建", "create"],
            "read": ["查看", "view", "获取", "get", "查询", "query"],
            "report": ["报告", "report", "统计", "statistics"],
            "admin": ["管理", "admin", "配置", "config"]
        }

        for action, keywords in action_keywords.items():
            if any(kw in content for kw in keywords):
                return action

        return "read"

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """在 Agent 执行前检查权限"""
        user_role = state.get("user_role", "guest")
        action = self._extract_action(state)

        # 检查权限
        permissions = self.role_permissions.get(user_role, set())

        if "*" not in permissions and action not in permissions:
            with self._lock:
                self._denied_requests.append({
                    "timestamp": datetime.now().isoformat(),
                    "role": user_role,
                    "action": action,
                    "reason": "permission_denied"
                })
            raise PermissionError(f"角色 '{user_role}' 无权执行 '{action}' 操作")

        print(f"[RBAC] ✅ 权限验证通过 - 角色: {user_role}, 操作: {action}")
        return None

    def get_denied_requests(self) -> List[Dict[str, Any]]:
        with self._lock:
            return self._denied_requests.copy()


class PermissionMiddleware(AgentMiddleware):
    """
    细粒度权限控制中间件

    功能：支持更细粒度的权限控制
    """

    def __init__(
        self,
        user_permissions: Optional[Dict[str, Set[str]]] = None
    ):
        # user_id -> set of permissions
        self.user_permissions = user_permissions or {}
        self._access_log: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _extract_action(self, state) -> str:
        messages = state.get("messages", [])
        if messages:
            content = getattr(messages[-1], "content", "").lower()
            if any(kw in content for kw in ["删除", "delete"]):
                return "delete"
            elif any(kw in content for kw in ["修改", "update"]):
                return "update"
            elif any(kw in content for kw in ["创建", "create"]):
                return "create"
        return "read"

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查细粒度权限"""
        user_id = state.get("user_id", "anonymous")
        resource = state.get("resource", "default")
        action = self._extract_action(state)

        # 获取用户权限
        permissions = self.user_permissions.get(user_id, set())
        required_permission = f"{resource}:{action}"

        # 检查权限
        has_permission = (
            "*:*" in permissions or
            f"{resource}:*" in permissions or
            f"*:{action}" in permissions or
            required_permission in permissions
        )

        # 记录访问
        with self._lock:
            self._access_log.append({
                "timestamp": datetime.now().isoformat(),
                "user_id": user_id,
                "resource": resource,
                "action": action,
                "allowed": has_permission
            })

        if not has_permission:
            raise PermissionError(
                f"用户 '{user_id}' 无权执行 '{required_permission}'"
            )

        print(f"[Permission] ✅ {user_id} -> {required_permission}")
        return None

    def grant_permission(self, user_id: str, permission: str):
        """授予权限"""
        if user_id not in self.user_permissions:
            self.user_permissions[user_id] = set()
        self.user_permissions[user_id].add(permission)

    def revoke_permission(self, user_id: str, permission: str):
        """撤销权限"""
        if user_id in self.user_permissions:
            self.user_permissions[user_id].discard(permission)


class AuthenticationMiddleware(AgentMiddleware):
    """
    认证中间件

    功能：验证用户身份
    """

    def __init__(
        self,
        valid_tokens: Optional[Dict[str, User]] = None,
        token_header: str = "Authorization"
    ):
        self.valid_tokens = valid_tokens or {}
        self.token_header = token_header
        self._auth_failures: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _log_failure(self, error_type: str, message: str):
        with self._lock:
            self._auth_failures.append({
                "timestamp": datetime.now().isoformat(),
                "error_type": error_type,
                "message": message
            })

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """在 Agent 执行前验证身份"""
        # 从 state 获取 token
        token = state.get("token") or state.get("headers", {}).get(self.token_header)

        if not token:
            self._log_failure("missing_token", "No token provided")
            raise PermissionError("缺少认证令牌")

        # 验证 token
        user = self.valid_tokens.get(token)

        if not user:
            self._log_failure("invalid_token", f"Invalid token: {token[:10]}...")
            raise PermissionError("无效的认证令牌")

        if not user.is_active:
            self._log_failure("inactive_user", f"User {user.user_id} is inactive")
            raise PermissionError("用户已被禁用")

        if user.expires_at and user.expires_at < datetime.now():
            self._log_failure("expired", f"User {user.user_id} account expired")
            raise PermissionError("账户已过期")

        print(f"[Auth] ✅ 认证成功 - 用户: {user.username} ({user.role})")
        return {"_user": user}

    def add_token(self, token: str, user: User):
        """添加有效 token"""
        self.valid_tokens[token] = user

    def remove_token(self, token: str):
        """移除 token"""
        self.valid_tokens.pop(token, None)


class RateLimitByUserMiddleware(AgentMiddleware):
    """
    按用户的速率限制中间件

    功能：限制每个用户的请求频率
    """

    def __init__(
        self,
        default_limit: int = 10,
        window_seconds: int = 60,
        user_limits: Optional[Dict[str, int]] = None
    ):
        self.default_limit = default_limit
        self.window_seconds = window_seconds
        self.user_limits = user_limits or {}  # user_id -> limit
        self._user_requests: Dict[str, List[float]] = {}
        self._lock = threading.Lock()

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查用户速率限制"""
        user_id = state.get("user_id", "anonymous")

        with self._lock:
            now = time.time()

            # 获取用户请求记录
            if user_id not in self._user_requests:
                self._user_requests[user_id] = []

            # 清理过期记录
            self._user_requests[user_id] = [
                t for t in self._user_requests[user_id]
                if now - t < self.window_seconds
            ]

            # 获取用户限制
            limit = self.user_limits.get(user_id, self.default_limit)

            # 检查限制
            if len(self._user_requests[user_id]) >= limit:
                raise RuntimeError(
                    f"用户 '{user_id}' 请求过于频繁，"
                    f"{self.window_seconds}秒内已请求 {len(self._user_requests[user_id])} 次"
                )

            # 记录请求
            self._user_requests[user_id].append(now)

            current = len(self._user_requests[user_id])
            print(f"[RateLimit] 🚦 用户 {user_id}: {current}/{limit}")

        return None


class IPWhitelistMiddleware(AgentMiddleware):
    """
    IP 白名单中间件

    功能：只允许特定 IP 访问
    """

    def __init__(
        self,
        whitelist: Optional[List[str]] = None,
        enabled: bool = True
    ):
        self.whitelist = set(whitelist or ["127.0.0.1", "::1"])
        self.enabled = enabled
        self._blocked_ips: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查 IP 白名单"""
        if not self.enabled:
            return None

        # 获取客户端 IP
        client_ip = state.get("client_ip", "127.0.0.1")

        if client_ip not in self.whitelist:
            with self._lock:
                self._blocked_ips.append({
                    "timestamp": datetime.now().isoformat(),
                    "ip": client_ip
                })
            raise PermissionError(f"IP '{client_ip}' 不在白名单中")

        print(f"[IPWhitelist] ✅ IP 验证通过: {client_ip}")
        return None

    def add_to_whitelist(self, ip: str):
        self.whitelist.add(ip)

    def remove_from_whitelist(self, ip: str):
        self.whitelist.discard(ip)


class GroupBasedAccessMiddleware(AgentMiddleware):
    """
    基于组的访问控制中间件

    功能：根据用户所属组控制访问
    """

    def __init__(
        self,
        group_permissions: Optional[Dict[str, Set[str]]] = None,
        user_groups: Optional[Dict[str, List[str]]] = None
    ):
        self.group_permissions = group_permissions or {
            "developers": {"code_read", "code_write", "deploy_staging"},
            "admins": {"*"},
            "viewers": {"code_read"}
        }
        self.user_groups = user_groups or {}
        self._lock = threading.Lock()

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查组权限"""
        user_id = state.get("user_id", "anonymous")
        required_permission = state.get("required_permission", "read")

        # 获取用户所属组
        groups = self.user_groups.get(user_id, [])

        # 收集用户所有权限
        all_permissions: Set[str] = set()
        for group in groups:
            group_perms = self.group_permissions.get(group, set())
            all_permissions.update(group_perms)

        # 检查权限
        has_permission = (
            "*" in all_permissions or
            required_permission in all_permissions
        )

        if not has_permission:
            raise PermissionError(
                f"用户 '{user_id}' (组: {groups}) 无 '{required_permission}' 权限"
            )

        print(f"[GroupAccess] ✅ {user_id} in {groups} -> {required_permission}")
        return None

    def add_user_to_group(self, user_id: str, group: str):
        if user_id not in self.user_groups:
            self.user_groups[user_id] = []
        if group not in self.user_groups[user_id]:
            self.user_groups[user_id].append(group)


class TimeBasedAccessMiddleware(AgentMiddleware):
    """
    基于时间的访问控制中间件

    功能：在特定时间段允许/禁止访问
    """

    def __init__(
        self,
        allowed_hours: tuple = (9, 18),  # 9:00 - 18:00
        allowed_days: tuple = (0, 1, 2, 3, 4),  # 周一到周五
        timezone_offset: int = 8  # UTC+8
    ):
        self.allowed_hours = allowed_hours
        self.allowed_days = allowed_days
        self.timezone_offset = timezone_offset
        self._denied_access: List[Dict[str, Any]] = []

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查时间访问限制"""
        now = datetime.utcnow() + timedelta(hours=self.timezone_offset)
        current_hour = now.hour
        current_day = now.weekday()

        # 检查时间
        hour_allowed = self.allowed_hours[0] <= current_hour < self.allowed_hours[1]
        day_allowed = current_day in self.allowed_days

        if not (hour_allowed and day_allowed):
            self._denied_access.append({
                "timestamp": now.isoformat(),
                "hour": current_hour,
                "day": current_day
            })
            raise PermissionError(
                f"当前时间不允许访问 "
                f"(工作时间: {self.allowed_hours[0]}:00-{self.allowed_hours[1]}:00, "
                f"工作日: 周一到周五)"
            )

        print(f"[TimeAccess] ✅ 时间验证通过 - {now.strftime('%Y-%m-%d %H:%M')}")
        return None


class AuditLogMiddleware(AgentMiddleware):
    """
    审计日志中间件

    功能：记录所有访问用于审计
    """

    def __init__(self, audit_enabled: bool = True):
        self.audit_enabled = audit_enabled
        self._audit_log: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _extract_action(self, state) -> str:
        messages = state.get("messages", [])
        if messages:
            return getattr(messages[-1], "content", "")[:50]
        return "unknown"

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录请求开始"""
        if not self.audit_enabled:
            return None

        state["_audit_record"] = {
            "timestamp": datetime.now().isoformat(),
            "user_id": state.get("user_id", "anonymous"),
            "action": self._extract_action(state),
            "status": "pending"
        }
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录请求完成"""
        if not self.audit_enabled:
            return None

        record = state.get("_audit_record", {})
        record["status"] = "success"

        with self._lock:
            self._audit_log.append(record)

        print(f"[Audit] 📋 {record['user_id']} -> {record['action']} ({record['status']})")
        return None

    def get_audit_log(self) -> List[Dict[str, Any]]:
        with self._lock:
            return self._audit_log.copy()


# ========== 示例函数 ==========

async def rbac_example():
    """RBAC 权限控制示例"""
    print("=" * 60)
    print("示例 1: 基于角色的访问控制 (RBAC)")
    print("=" * 60)

    rbac = RoleBasedAccessMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[rbac],
        name="rbac_agent"
    )

    # 测试不同角色
    test_cases = [
        ("admin", "查看系统配置"),
        ("user", "查看数据"),
        ("guest", "查看报告"),  # 应该失败
    ]

    for role, action in test_cases:
        print(f"\n测试: 角色={role}, 操作={action}")
        try:
            await agent.ainvoke({
                "messages": [HumanMessage(content=action)],
                "user_role": role
            })
        except PermissionError as e:
            print(f"❌ 权限拒绝: {e}")


async def authentication_example():
    """认证中间件示例"""
    print("\n" + "=" * 60)
    print("示例 2: 认证中间件")
    print("=" * 60)

    # 创建测试用户
    test_user = User(
        user_id="u001",
        username="testuser",
        role="user",
        permissions={"read", "write"}
    )

    auth = AuthenticationMiddleware()
    auth.add_token("valid_token_123", test_user)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[auth],
        name="auth_agent"
    )

    # 有效 token
    print("\n使用有效 token:")
    await agent.ainvoke({
        "messages": [HumanMessage(content="你好")],
        "token": "valid_token_123"
    })

    # 无效 token
    print("\n使用无效 token:")
    try:
        await agent.ainvoke({
            "messages": [HumanMessage(content="你好")],
            "token": "invalid_token"
        })
    except PermissionError as e:
        print(f"❌ 认证失败: {e}")


async def rate_limit_example():
    """用户速率限制示例"""
    print("\n" + "=" * 60)
    print("示例 3: 按用户速率限制")
    print("=" * 60)

    rate_limiter = RateLimitByUserMiddleware(
        default_limit=3,
        window_seconds=60,
        user_limits={"vip_user": 10}  # VIP 用户更高限制
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。",
        middleware=[rate_limiter],
        name="rate_limited_agent"
    )

    # 普通用户快速请求
    print("\n普通用户连续请求:")
    for i in range(4):
        try:
            await agent.ainvoke({
                "messages": [HumanMessage(content=f"请求{i+1}")],
                "user_id": "normal_user"
            })
        except RuntimeError as e:
            print(f"❌ {e}")


async def ip_whitelist_example():
    """IP 白名单示例"""
    print("\n" + "=" * 60)
    print("示例 4: IP 白名单")
    print("=" * 60)

    ip_filter = IPWhitelistMiddleware(
        whitelist=["192.168.1.100", "10.0.0.1"],
        enabled=True
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[ip_filter],
        name="ip_filtered_agent"
    )

    # 白名单 IP
    print("\n白名单 IP:")
    await agent.ainvoke({
        "messages": [HumanMessage(content="你好")],
        "client_ip": "192.168.1.100"
    })

    # 非白名单 IP
    print("\n非白名单 IP:")
    try:
        await agent.ainvoke({
            "messages": [HumanMessage(content="你好")],
            "client_ip": "1.2.3.4"
        })
    except PermissionError as e:
        print(f"❌ {e}")


async def time_based_access_example():
    """基于时间的访问控制示例"""
    print("\n" + "=" * 60)
    print("示例 5: 基于时间的访问控制")
    print("=" * 60)

    time_access = TimeBasedAccessMiddleware(
        allowed_hours=(0, 23),  # 允许全天（演示用）
        allowed_days=(0, 1, 2, 3, 4, 5, 6)  # 允许每天
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[time_access],
        name="time_limited_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})


async def audit_log_example():
    """审计日志示例"""
    print("\n" + "=" * 60)
    print("示例 6: 审计日志")
    print("=" * 60)

    audit = AuditLogMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[audit],
        name="audited_agent"
    )

    # 执行多次请求
    for i in range(3):
        await agent.ainvoke({
            "messages": [HumanMessage(content=f"操作{i+1}")],
            "user_id": f"user_{i%2}"
        })

    print(f"\n📋 审计日志条数: {len(audit.get_audit_log())}")


async def combined_permission_example():
    """组合权限控制示例"""
    print("\n" + "=" * 60)
    print("示例 7: 组合多种权限控制")
    print("=" * 60)

    # 组合认证 + RBAC + 速率限制
    test_user = User(
        user_id="u001",
        username="combineduser",
        role="user",
        permissions={"read", "write"}
    )

    auth = AuthenticationMiddleware()
    auth.add_token("combined_token", test_user)

    rbac = RoleBasedAccessMiddleware()
    rate_limiter = RateLimitByUserMiddleware(default_limit=5)
    audit = AuditLogMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[auth, rbac, rate_limiter, audit],
        name="fully_secured_agent"
    )

    await agent.ainvoke({
        "messages": [HumanMessage(content="查看数据")],
        "token": "combined_token",
        "user_id": "u001"
    })

    print(f"\n📋 审计日志: {len(audit.get_audit_log())} 条")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🔒 权限控制中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await rbac_example()
    await authentication_example()
    await rate_limit_example()
    await ip_whitelist_example()
    await time_based_access_example()
    await audit_log_example()
    await combined_permission_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
