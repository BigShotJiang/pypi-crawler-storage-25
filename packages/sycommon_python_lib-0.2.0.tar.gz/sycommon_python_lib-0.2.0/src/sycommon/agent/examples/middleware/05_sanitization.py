"""
中间件示例 05: 数据清洗中间件
============================

展示输入清洗、输出清洗、内容过滤相关的中间件，基于 AgentMiddleware。

运行方式:
    python -m sycommon.agent.examples.middleware.05_sanitization
"""
import asyncio
import re
import html
from typing import Any, Dict, List, Optional, Callable, Awaitable
from datetime import datetime
from langchain_core.messages import HumanMessage, AIMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse
)

from sycommon.agent import get_agent


# ========== 输入清洗中间件 ==========

class InputSanitizationMiddleware(AgentMiddleware):
    """
    输入清洗中间件

    功能：清洗用户输入，防止注入攻击
    使用 request.override() 修改消息内容
    """

    def __init__(
        self,
        max_length: int = 10000,
        strip_html: bool = True,
        escape_special_chars: bool = True,
        remove_scripts: bool = True
    ):
        self.max_length = max_length
        self.strip_html = strip_html
        self.escape_special_chars = escape_special_chars
        self.remove_scripts = remove_scripts
        self._sanitized_count = 0
        self._blocked_count = 0

    def _sanitize(self, text: str) -> str:
        """清洗文本"""
        # 限制长度
        if len(text) > self.max_length:
            text = text[:self.max_length]
            print(f"[InputSanitization] ⚠️ 文本已截断到 {self.max_length} 字符")

        # 移除脚本
        if self.remove_scripts:
            text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.IGNORECASE | re.DOTALL)
            text = re.sub(r'javascript:', '', text, flags=re.IGNORECASE)

        # 清洗HTML
        if self.strip_html:
            text = html.escape(text)

        # 转义特殊字符
        if self.escape_special_chars:
            text = text.replace('\x00', '')  # 移除空字节
            text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)

        return text.strip()

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """使用 override() 清洗消息内容"""
        sanitized_messages = []
        has_changes = False

        for msg in request.messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                original = msg.content
                sanitized = self._sanitize(original)

                if sanitized != original:
                    self._sanitized_count += 1
                    has_changes = True
                    print(f"[InputSanitization] 🧹 输入已清洗")

                    # 创建新的消息对象
                    if isinstance(msg, HumanMessage):
                        sanitized_messages.append(HumanMessage(content=sanitized))
                    else:
                        sanitized_messages.append(type(msg)(content=sanitized))
                else:
                    sanitized_messages.append(msg)
            else:
                sanitized_messages.append(msg)

        # 使用 override() 替换消息
        if has_changes:
            new_request = request.override(messages=sanitized_messages)
            return handler(new_request)

        return handler(request)

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "sanitized_count": self._sanitized_count,
            "blocked_count": self._blocked_count
        }


class SQLInjectionMiddleware(AgentMiddleware):
    """
    SQL注入防护中间件

    功能：检测和阻止SQL注入攻击
    """

    # 常见SQL注入模式
    SQL_PATTERNS = [
        r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|TRUNCATE)\b)",
        r"(--|#|/\*|\*/)",
        r"(\bOR\b|\bAND\b)\s+\d+\s*=\s*\d+",
        r"(\bOR\b|\bAND\b)\s+['\"]\w+['\"]\s*=\s*['\"]\w+['\"]",
        r"(;|\|)\s*(SELECT|INSERT|UPDATE|DELETE|DROP)",
        r"'\s*(OR|AND)\s*'",
        r"\bEXEC\b.*\bXP_",
    ]

    def __init__(self, block_on_detection: bool = True, warning_only: bool = False):
        self.block_on_detection = block_on_detection
        self.warning_only = warning_only
        self._patterns = [re.compile(p, re.IGNORECASE) for p in self.SQL_PATTERNS]
        self._detection_count = 0
        self._blocked_count = 0

    def _detect_sql_injection(self, text: str) -> bool:
        """检测SQL注入"""
        return any(pattern.search(text) for pattern in self._patterns)

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """在 Agent 执行前检测 SQL 注入"""
        messages = state.get("messages", [])

        for msg in messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                if self._detect_sql_injection(msg.content):
                    self._detection_count += 1
                    print(f"[SQLInjection] 🚨 检测到可疑SQL注入模式!")

                    if self.block_on_detection and not self.warning_only:
                        self._blocked_count += 1
                        raise ValueError("检测到SQL注入攻击，请求已被阻止")

        return None

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "detection_count": self._detection_count,
            "blocked_count": self._blocked_count
        }


class XSSFilterMiddleware(AgentMiddleware):
    """
    XSS过滤中间件

    功能：检测和过滤跨站脚本攻击
    使用 request.override() 修改消息内容
    """

    XSS_PATTERNS = [
        r'<script[^>]*>.*?</script>',
        r'javascript:',
        r'on\w+\s*=',  # onclick=, onload=, etc.
        r'<iframe[^>]*>',
        r'<object[^>]*>',
        r'<embed[^>]*>',
        r'<link[^>]*>',
        r'<style[^>]*>.*?</style>',
        r'expression\s*\(',
        r'vbscript:',
        r'data:text/html',
    ]

    def __init__(self, mode: str = "sanitize"):
        """
        Args:
            mode: 'sanitize' (清洗) 或 'block' (阻止)
        """
        self.mode = mode
        self._patterns = [re.compile(p, re.IGNORECASE | re.DOTALL) for p in self.XSS_PATTERNS]
        self._filtered_count = 0

    def _detect_xss(self, text: str) -> bool:
        """检测XSS"""
        return any(pattern.search(text) for pattern in self._patterns)

    def _sanitize_xss(self, text: str) -> str:
        """清洗XSS"""
        for pattern in self._patterns:
            text = pattern.sub('', text)
        return html.escape(text)

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """使用 override() 过滤 XSS 内容"""
        filtered_messages = []
        has_changes = False

        for msg in request.messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                original = msg.content

                if self.mode == "sanitize":
                    filtered = self._sanitize_xss(original)
                    if filtered != original:
                        self._filtered_count += 1
                        has_changes = True
                        print(f"[XSSFilter] 🛡️ XSS内容已过滤")

                    # 创建新的消息对象
                    if isinstance(msg, HumanMessage):
                        filtered_messages.append(HumanMessage(content=filtered))
                    else:
                        filtered_messages.append(type(msg)(content=filtered))
                else:  # block mode
                    if self._detect_xss(original):
                        self._filtered_count += 1
                        raise ValueError("检测到XSS攻击，请求已被阻止")
                    filtered_messages.append(msg)
            else:
                filtered_messages.append(msg)

        # 使用 override() 替换消息
        if has_changes:
            new_request = request.override(messages=filtered_messages)
            return handler(new_request)

        return handler(request)

    @property
    def stats(self) -> Dict[str, int]:
        return {"filtered_count": self._filtered_count}


# ========== 输出清洗中间件 ==========

class OutputSanitizationMiddleware(AgentMiddleware):
    """
    输出清洗中间件

    功能：清洗AI输出，确保安全
    """

    def __init__(
        self,
        hide_internal_info: bool = True,
        mask_sensitive_data: bool = True,
        max_output_length: int = 50000
    ):
        self.hide_internal_info = hide_internal_info
        self.mask_sensitive_data = mask_sensitive_data
        self.max_output_length = max_output_length
        self._masked_count = 0

        # 敏感数据模式
        self._sensitive_patterns = [
            (re.compile(r'\b\d{16,19}\b'), '****CARD****'),  # 信用卡
            (re.compile(r'\b\d{17,19}X?\b'), '****ID****'),  # 身份证
            (re.compile(r'\b[\w\.-]+@[\w\.-]+\.\w+\b'), '****@****.***'),  # 邮箱
            (re.compile(r'\b1[3-9]\d{9}\b'), '****PHONE****'),  # 手机号
            (re.compile(r'\b[A-Za-z0-9]{32,}\b'), '****TOKEN****'),  # Token
        ]

        # 内部信息模式
        self._internal_patterns = [
            re.compile(r'/home/\w+', re.IGNORECASE),
            re.compile(r'/var/log/\S+'),
            re.compile(r'C:\\Users\\\w+', re.IGNORECASE),
            re.compile(r'password\s*[:=]\s*\S+', re.IGNORECASE),
            re.compile(r'secret\s*[:=]\s*\S+', re.IGNORECASE),
            re.compile(r'api[_-]?key\s*[:=]\s*\S+', re.IGNORECASE),
        ]

    def _mask_sensitive(self, text: str) -> str:
        """掩码敏感数据"""
        for pattern, replacement in self._sensitive_patterns:
            if pattern.search(text):
                self._masked_count += 1
                text = pattern.sub(replacement, text)
        return text

    def _hide_internal(self, text: str) -> str:
        """隐藏内部信息"""
        for pattern in self._internal_patterns:
            if pattern.search(text):
                self._masked_count += 1
                text = pattern.sub('[INTERNAL]', text)
        return text

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """在 Agent 执行后清洗输出"""
        messages = state.get("messages", [])
        if not messages:
            return None

        sanitized_messages = []
        for msg in messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                content = msg.content

                # 限制长度
                if len(content) > self.max_output_length:
                    content = content[:self.max_output_length] + "...[已截断]"

                # 掩码敏感数据
                if self.mask_sensitive_data:
                    content = self._mask_sensitive(content)

                # 隐藏内部信息
                if self.hide_internal_info:
                    content = self._hide_internal(content)

                sanitized_messages.append(AIMessage(content=content)
                                         if isinstance(msg, AIMessage)
                                         else msg)
            else:
                sanitized_messages.append(msg)

        return {"messages": sanitized_messages}

    @property
    def stats(self) -> Dict[str, int]:
        return {"masked_count": self._masked_count}


class ContentFilterMiddleware(AgentMiddleware):
    """
    内容过滤中间件

    功能：过滤不当内容
    """

    def __init__(
        self,
        block_keywords: Optional[List[str]] = None,
        warning_keywords: Optional[List[str]] = None,
        block_mode: str = "replace"  # replace, mask, block
    ):
        self.block_keywords = block_keywords or []
        self.warning_keywords = warning_keywords or []
        self.block_mode = block_mode
        self._blocked_count = 0
        self._warning_count = 0

    def _check_content(self, content: str) -> None:
        """检查内容"""
        content_lower = content.lower()

        for keyword in self.block_keywords:
            if keyword.lower() in content_lower:
                self._blocked_count += 1
                if self.block_mode == "block":
                    raise ValueError(f"内容包含禁止的关键词: {keyword}")
                print(f"[ContentFilter] 🚫 检测到禁止内容")

        for keyword in self.warning_keywords:
            if keyword.lower() in content_lower:
                self._warning_count += 1
                print(f"[ContentFilter] ⚠️ 检测到警告内容")

    def _filter_content(self, content: str) -> str:
        """过滤内容"""
        for keyword in self.block_keywords:
            if keyword.lower() in content.lower():
                if self.block_mode == "replace":
                    content = re.sub(
                        re.escape(keyword),
                        '*' * len(keyword),
                        content,
                        flags=re.IGNORECASE
                    )
                elif self.block_mode == "mask":
                    content = re.sub(
                        re.escape(keyword),
                        '[已过滤]',
                        content,
                        flags=re.IGNORECASE
                    )
        return content

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查输入内容"""
        messages = state.get("messages", [])
        for msg in messages:
            if hasattr(msg, "content"):
                self._check_content(str(msg.content))
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """过滤输出内容"""
        messages = state.get("messages", [])
        filtered_messages = []

        for msg in messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                filtered = self._filter_content(msg.content)
                filtered_messages.append(AIMessage(content=filtered)
                                        if isinstance(msg, AIMessage)
                                        else msg)
            else:
                filtered_messages.append(msg)

        return {"messages": filtered_messages}

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "blocked_count": self._blocked_count,
            "warning_count": self._warning_count
        }


class PIIProtectionMiddleware(AgentMiddleware):
    """
    PII保护中间件

    功能：保护个人身份信息
    使用 request.override() 修改消息内容
    """

    PII_PATTERNS = {
        "email": re.compile(r'\b[\w\.-]+@[\w\.-]+\.\w+\b'),
        "phone_cn": re.compile(r'\b1[3-9]\d{9}\b'),
        "phone_intl": re.compile(r'\+\d{1,3}[\s-]?\d{6,14}'),
        "ssn_us": re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
        "id_cn": re.compile(r'\b\d{17}[\dXx]\b'),
        "credit_card": re.compile(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'),
        "ip_address": re.compile(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'),
        "mac_address": re.compile(r'\b([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\b'),
    }

    MASKS = {
        "email": "****@****.***",
        "phone_cn": "1**********",
        "phone_intl": "+***********",
        "ssn_us": "***-**-****",
        "id_cn": "******************",
        "credit_card": "****-****-****-****",
        "ip_address": "***.***.***.***",
        "mac_address": "**:**:**:**:**:**",
    }

    def __init__(self, preserve_length: bool = False):
        self.preserve_length = preserve_length
        self._masked_count = 0
        self._detected_types: Dict[str, int] = {}

    def _mask_pii(self, text: str) -> tuple:
        """掩码PII"""
        detected = []

        for pii_type, pattern in self.PII_PATTERNS.items():
            matches = pattern.findall(text)
            if matches:
                detected.append(pii_type)
                mask = self.MASKS.get(pii_type, "[REDACTED]")
                text = pattern.sub(mask, text)

        return text, detected

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """使用 override() 掩码 PII"""
        masked_messages = []
        has_changes = False

        for msg in request.messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                masked_content, detected = self._mask_pii(msg.content)

                for pii_type in detected:
                    self._detected_types[pii_type] = self._detected_types.get(pii_type, 0) + 1

                if detected:
                    self._masked_count += 1
                    has_changes = True
                    print(f"[PIIProtection] 🔒 检测并掩码PII: {detected}")

                # 创建新的消息对象
                if isinstance(msg, HumanMessage):
                    masked_messages.append(HumanMessage(content=masked_content))
                else:
                    masked_messages.append(type(msg)(content=masked_content))
            else:
                masked_messages.append(msg)

        # 使用 override() 替换消息
        if has_changes:
            new_request = request.override(messages=masked_messages)
            return handler(new_request)

        return handler(request)

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            "masked_count": self._masked_count,
            "detected_types": self._detected_types
        }


# ========== 示例函数 ==========

async def input_sanitization_example():
    """输入清洗示例"""
    print("=" * 60)
    print("示例 1: 输入清洗中间件")
    print("=" * 60)

    sanitizer = InputSanitizationMiddleware(max_length=1000)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[sanitizer],
        name="sanitized_agent"
    )

    # 正常输入
    print("\n--- 正常输入 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    # 包含脚本的输入
    print("\n--- 包含脚本的输入 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="<script>alert('xss')</script>你好")]})

    print(f"\n📊 清洗统计: {sanitizer.stats}")


async def sql_injection_example():
    """SQL注入防护示例"""
    print("\n" + "=" * 60)
    print("示例 2: SQL注入防护")
    print("=" * 60)

    sql_guard = SQLInjectionMiddleware(block_on_detection=True, warning_only=True)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[sql_guard],
        name="sql_protected_agent"
    )

    # 正常输入
    print("\n--- 正常输入 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="查询用户信息")]})

    # 可疑输入（警告模式）
    print("\n--- 可疑输入 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="SELECT * FROM users WHERE id=1")]})

    print(f"\n📊 SQL防护统计: {sql_guard.stats}")


async def xss_filter_example():
    """XSS过滤示例"""
    print("\n" + "=" * 60)
    print("示例 3: XSS过滤")
    print("=" * 60)

    xss_filter = XSSFilterMiddleware(mode="sanitize")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[xss_filter],
        name="xss_protected_agent"
    )

    # 包含XSS的输入
    print("\n--- 包含XSS的输入 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="<script>alert('xss')</script>测试")]})

    print(f"\n📊 XSS过滤统计: {xss_filter.stats}")


async def output_sanitization_example():
    """输出清洗示例"""
    print("\n" + "=" * 60)
    print("示例 4: 输出清洗")
    print("=" * 60)

    output_sanitizer = OutputSanitizationMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手，请回复用户的问候。",
        middleware=[output_sanitizer],
        name="output_sanitized_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 输出清洗统计: {output_sanitizer.stats}")


async def content_filter_example():
    """内容过滤示例"""
    print("\n" + "=" * 60)
    print("示例 5: 内容过滤")
    print("=" * 60)

    content_filter = ContentFilterMiddleware(
        block_keywords=["敏感词", "违禁词"],
        warning_keywords=["警告"],
        block_mode="replace"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[content_filter],
        name="filtered_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 内容过滤统计: {content_filter.stats}")


async def pii_protection_example():
    """PII保护示例"""
    print("\n" + "=" * 60)
    print("示例 6: PII保护")
    print("=" * 60)

    pii_protector = PIIProtectionMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[pii_protector],
        name="pii_protected_agent"
    )

    # 包含PII的输入
    print("\n--- 包含PII的输入 ---")
    await agent.ainvoke({
        "messages": [HumanMessage(content="我的邮箱是test@example.com，手机是13812345678")]
    })

    print(f"\n📊 PII保护统计: {pii_protector.stats}")


async def combined_sanitization_example():
    """组合清洗示例"""
    print("\n" + "=" * 60)
    print("示例 7: 组合清洗机制")
    print("=" * 60)

    input_sanitizer = InputSanitizationMiddleware()
    sql_guard = SQLInjectionMiddleware(warning_only=True)
    xss_filter = XSSFilterMiddleware()
    output_sanitizer = OutputSanitizationMiddleware()
    pii_protector = PIIProtectionMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[
            input_sanitizer,
            sql_guard,
            xss_filter,
            output_sanitizer,
            pii_protector
        ],
        name="fully_sanitized_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好，请帮我处理一些数据")]})

    print(f"\n📊 综合清洗统计:")
    print(f"  输入清洗: {input_sanitizer.stats}")
    print(f"  SQL防护: {sql_guard.stats}")
    print(f"  XSS过滤: {xss_filter.stats}")
    print(f"  PII保护: {pii_protector.stats}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🧹 数据清洗中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await input_sanitization_example()
    await sql_injection_example()
    await xss_filter_example()
    await output_sanitization_example()
    await content_filter_example()
    await pii_protection_example()
    await combined_sanitization_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
