"""
中间件示例: request.override() 高级用法
=======================================

展示如何使用 request.override() 方法修改请求，这是中间件的核心功能之一。

运行方式:
    python -m sycommon.agent.examples.middleware.override_examples
"""
import asyncio
from typing import Any, Dict, Callable, Awaitable
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse, ToolCallRequest
)
from langchain_core.messages import ToolMessage
from langchain_core.tools import tool

from sycommon.agent import get_agent


# ========== 工具定义 ==========

@tool
def search_web(query: str) -> str:
    """搜索网络"""
    return f"搜索结果: {query}"


@tool
def send_email(to: str, subject: str, body: str) -> str:
    """发送邮件"""
    return f"邮件已发送给 {to}"


# ========== ModelRequest.override() 示例 ==========

class SystemPromptOverrideMiddleware(AgentMiddleware):
    """
    系统提示词覆盖中间件

    功能：使用 request.override() 动态修改系统提示词
    """

    def __init__(self, new_system_prompt: str):
        self.new_system_prompt = new_system_prompt

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """使用 override() 替换系统提示词"""
        print(f"[SystemPromptOverride] 🔄 替换系统提示词...")

        # 使用 override() 创建新的请求，替换 system_message
        new_request = request.override(
            system_message=SystemMessage(content=self.new_system_prompt)
        )

        return handler(new_request)


class DynamicModelMiddleware(AgentMiddleware):
    """
    动态模型切换中间件

    功能：根据条件使用 request.override() 切换模型
    """

    def __init__(self, fallback_model: str = "gpt-3.5-turbo"):
        self.fallback_model = fallback_model

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据消息长度动态切换模型"""
        message_count = len(request.messages)

        # 如果消息太长，切换到更大上下文的模型
        if message_count > 10:
            print(f"[DynamicModel] 🔄 消息数 {message_count} > 10，切换模型...")

            # 这里演示 override model 参数
            # 实际使用需要实例化对应的模型
            from langchain_openai import ChatOpenAI
            new_model = ChatOpenAI(model=self.fallback_model)

            new_request = request.override(model=new_model)
            return handler(new_request)

        return handler(request)


class ToolInjectionMiddleware(AgentMiddleware):
    """
    工具注入中间件

    功能：使用 request.override() 动态添加工具
    """

    def __init__(self, extra_tools: list):
        self.extra_tools = extra_tools

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """动态注入额外工具"""
        print(f"[ToolInjection] 🔧 注入 {len(self.extra_tools)} 个额外工具...")

        # 合并现有工具和额外工具
        all_tools = list(request.tools) + self.extra_tools

        # 使用 override() 替换工具列表
        new_request = request.override(tools=all_tools)

        return handler(new_request)


class MessageRewriteMiddleware(AgentMiddleware):
    """
    消息重写中间件

    功能：使用 request.override() 重写消息内容
    """

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """重写消息，添加上下文前缀"""
        rewritten_messages = []

        for msg in request.messages:
            if hasattr(msg, "content") and isinstance(msg.content, str):
                # 给每条消息添加前缀
                new_content = f"[用户消息] {msg.content}"
                rewritten_messages.append(
                    HumanMessage(content=new_content)
                )
            else:
                rewritten_messages.append(msg)

        print(f"[MessageRewrite] ✏️ 重写了 {len(rewritten_messages)} 条消息")

        # 使用 override() 替换消息列表
        new_request = request.override(messages=rewritten_messages)
        return handler(new_request)


class ModelSettingsMiddleware(AgentMiddleware):
    """
    模型设置中间件

    功能：使用 request.override() 修改模型参数
    """

    def __init__(self, temperature: float = 0.7, max_tokens: int = 1000):
        self.temperature = temperature
        self.max_tokens = max_tokens

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """注入模型设置"""
        print(f"[ModelSettings] ⚙️ 设置 temperature={self.temperature}, max_tokens={self.max_tokens}")

        # 合并模型设置
        new_settings = {
            **request.model_settings,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens
        }

        # 使用 override() 更新模型设置
        new_request = request.override(model_settings=new_settings)
        return handler(new_request)


class StateEnrichmentMiddleware(AgentMiddleware):
    """
    状态增强中间件

    功能：使用 request.override() 丰富 state
    """

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """在 state 中添加额外信息"""
        # 创建增强的 state
        enriched_state = {
            **request.state,
            "_enriched": True,
            "_timestamp": asyncio.get_event_loop().time() if asyncio.get_event_loop().is_running() else 0
        }

        print(f"[StateEnrichment] 📊 增强了 state")

        # 使用 override() 更新 state
        new_request = request.override(state=enriched_state)
        return handler(new_request)


# ========== ToolCallRequest.override() 示例 ==========

class ToolArgsModifierMiddleware(AgentMiddleware):
    """
    工具参数修改中间件

    功能：使用 request.override() 修改工具调用参数
    """

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """修改工具调用参数"""
        tool_name = request.tool_call.get("name", "")
        tool_args = dict(request.tool_call.get("args", {}))

        # 示例：给搜索查询添加时间戳
        if tool_name == "search_web" and "query" in tool_args:
            original_query = tool_args["query"]
            tool_args["query"] = f"{original_query} (搜索时间: 2024)"

            print(f"[ToolArgsModifier] ✏️ 修改了工具参数: {tool_name}")

            # 使用 override() 创建新的请求
            modified_call = {
                **request.tool_call,
                "args": tool_args
            }
            new_request = request.override(tool_call=modified_call)
            return handler(new_request)

        return handler(request)


class ToolNameRewriteMiddleware(AgentMiddleware):
    """
    工具名称重写中间件

    功能：使用 request.override() 重定向工具调用
    """

    def __init__(self, rewrite_map: Dict[str, str] = None):
        self.rewrite_map = rewrite_map or {
            "google_search": "search_web",
            "mail_send": "send_email"
        }

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """重写工具名称"""
        tool_name = request.tool_call.get("name", "")

        if tool_name in self.rewrite_map:
            new_name = self.rewrite_map[tool_name]
            print(f"[ToolNameRewrite] 🔄 重定向: {tool_name} -> {new_name}")

            # 使用 override() 修改工具名称
            modified_call = {
                **request.tool_call,
                "name": new_name
            }
            new_request = request.override(tool_call=modified_call)
            return handler(new_request)

        return handler(request)


class ToolValidationMiddleware(AgentMiddleware):
    """
    工具验证中间件

    功能：使用 request.override() 验证并修正参数
    """

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """验证并修正工具参数"""
        tool_name = request.tool_call.get("name", "")
        tool_args = dict(request.tool_call.get("args", {}))

        modified = False

        # 示例：验证邮箱格式
        if tool_name == "send_email" and "to" in tool_args:
            email = tool_args["to"]
            if "@" not in email:
                # 尝试修正
                tool_args["to"] = f"{email}@example.com"
                modified = True
                print(f"[ToolValidation] 🔧 修正了邮箱格式: {tool_args['to']}")

        if modified:
            modified_call = {
                **request.tool_call,
                "args": tool_args
            }
            new_request = request.override(tool_call=modified_call)
            return handler(new_request)

        return handler(request)


# ========== 组合使用 override() 示例 ==========

class MultiOverrideMiddleware(AgentMiddleware):
    """
    多重覆盖中间件

    功能：展示如何同时 override 多个参数
    """

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """同时修改多个参数"""
        print(f"[MultiOverride] 🔄 同时修改多个参数...")

        # 一次性 override 多个参数
        new_request = request.override(
            system_message=SystemMessage(content="你是一个专业的编程助手。"),
            model_settings={
                **request.model_settings,
                "temperature": 0.3
            }
        )

        return handler(new_request)


class ConditionalOverrideMiddleware(AgentMiddleware):
    """
    条件覆盖中间件

    功能：根据条件决定是否 override
    """

    def __init__(self, max_messages: int = 5):
        self.max_messages = max_messages

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据消息长度条件性 override"""
        msg_count = len(request.messages)

        if msg_count > self.max_messages:
            print(f"[ConditionalOverride] ⚠️ 消息数 {msg_count} > {self.max_messages}，需要处理...")

            # 只保留最近的消息
            recent_messages = request.messages[-self.max_messages:]
            new_request = request.override(messages=recent_messages)

            return handler(new_request)

        print(f"[ConditionalOverride] ✅ 消息数 {msg_count} 在限制内")
        return handler(request)


# ========== 示例函数 ==========

async def system_prompt_override_example():
    """系统提示词覆盖示例"""
    print("=" * 60)
    print("示例 1: 系统提示词覆盖")
    print("=" * 60)

    middleware = SystemPromptOverrideMiddleware(
        new_system_prompt="你是一个专业的Python编程专家，用简洁的语言回答问题。"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[middleware],
        name="system_override_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="什么是列表推导式？")]})


async def tool_injection_example():
    """工具注入示例"""
    print("\n" + "=" * 60)
    print("示例 2: 动态工具注入")
    print("=" * 60)

    middleware = ToolInjectionMiddleware(
        extra_tools=[search_web]
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[middleware],
        name="tool_injection_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})


async def model_settings_example():
    """模型设置示例"""
    print("\n" + "=" * 60)
    print("示例 3: 模型设置覆盖")
    print("=" * 60)

    middleware = ModelSettingsMiddleware(temperature=0.5, max_tokens=500)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[middleware],
        name="model_settings_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})


async def tool_args_modifier_example():
    """工具参数修改示例"""
    print("\n" + "=" * 60)
    print("示例 4: 工具参数修改")
    print("=" * 60)

    middleware = ToolArgsModifierMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web],
        system_prompt="你是一个助手，可以帮助用户搜索信息。",
        middleware=[middleware],
        name="tool_args_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="搜索Python教程")]})


async def multi_override_example():
    """多重覆盖示例"""
    print("\n" + "=" * 60)
    print("示例 5: 多重参数覆盖")
    print("=" * 60)

    middleware = MultiOverrideMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[middleware],
        name="multi_override_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="什么是装饰器？")]})


async def conditional_override_example():
    """条件覆盖示例"""
    print("\n" + "=" * 60)
    print("示例 6: 条件性参数覆盖")
    print("=" * 60)

    middleware = ConditionalOverrideMiddleware(max_messages=3)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[middleware],
        name="conditional_override_agent"
    )

    # 短消息列表
    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})


async def combined_override_example():
    """组合覆盖示例"""
    print("\n" + "=" * 60)
    print("示例 7: 组合多个 override 中间件")
    print("=" * 60)

    system_override = SystemPromptOverrideMiddleware(
        new_system_prompt="你是一个技术专家，用专业但易懂的语言回答。"
    )
    model_settings = ModelSettingsMiddleware(temperature=0.3)
    tool_injection = ToolInjectionMiddleware(extra_tools=[search_web])

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[system_override, model_settings, tool_injection],
        name="combined_override_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="解释一下异步编程")]})


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🔧 request.override() 高级用法示例")
    print("=" * 70)

    print("\n💡 override() 方法是中间件的核心功能：")
    print("   - ModelRequest.override() - 修改模型请求参数")
    print("   - ToolCallRequest.override() - 修改工具调用参数")
    print("   - 返回新的请求对象，不修改原始请求（不可变模式）")

    await system_prompt_override_example()
    await tool_injection_example()
    await model_settings_example()
    await tool_args_modifier_example()
    await multi_override_example()
    await conditional_override_example()
    await combined_override_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
