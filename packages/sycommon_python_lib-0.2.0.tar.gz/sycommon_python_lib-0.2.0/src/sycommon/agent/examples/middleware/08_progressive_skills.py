"""
中间件示例 08: 渐进式技能加载
==============================

展示如何结合 skills 参数和 middleware request.override() 实现渐进式工具/技能加载。

核心概念：
    - skills 参数：声明 Agent 的能力和对应工具
    - 渐进式加载：根据用户权限等级逐步解锁 skills 中的工具
    - request.override()：不可变模式修改请求参数（tools、system_message）

运行方式:
    python -m sycommon.agent.examples.middleware.08_progressive_skills
"""
import asyncio
import threading
from typing import Any, Dict, List, Optional, Callable, Awaitable, Set
from datetime import datetime
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool, BaseTool
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse
)

from sycommon.agent import get_agent


# ========== 工具定义 ==========

@tool
def basic_search(query: str) -> str:
    """基础搜索功能"""
    return f"[基础搜索] {query}: 找到 5 条结果"


@tool
def basic_calculate(expression: str) -> str:
    """基础计算"""
    try:
        return f"计算结果: {eval(expression)}"
    except:
        return "计算错误"


@tool
def advanced_search(query: str, filters: str = "") -> str:
    """高级搜索（支持过滤条件）"""
    return f"[高级搜索] {query} (过滤: {filters}): 找到 20 条结果"


@tool
def data_analysis(data: str) -> str:
    """数据分析"""
    return f"[数据分析] 输入: {data[:30]}... -> 趋势上升, 均值50"


@tool
def database_query(sql: str) -> str:
    """数据库查询"""
    return f"[数据库] {sql}: 返回 100 行"


@tool
def ml_predict(model: str, input_data: str) -> str:
    """机器学习预测"""
    return f"[ML预测] {model}: 预测结果=0.92"


@tool
def execute_code(code: str) -> str:
    """执行代码（危险操作）"""
    return f"[代码执行] 完成"


@tool
def admin_config(key: str, value: str) -> str:
    """管理员配置（危险操作）"""
    return f"[配置] {key}={value}"


# ========== 技能定义 - 与工具对应 ==========

SKILLS_DEFINITION = {
    "basic": {
        "skills": [
            "basic_search: 基础搜索，快速查找信息",
            "basic_calculate: 简单数学计算"
        ],
        "tools": {"basic_search", "basic_calculate"},
        "description": "基础功能"
    },
    "standard": {
        "skills": [
            "basic_search: 基础搜索",
            "basic_calculate: 简单计算",
            "advanced_search: 高级搜索，支持过滤条件",
            "data_analysis: 数据分析，生成报告"
        ],
        "tools": {"basic_search", "basic_calculate", "advanced_search", "data_analysis"},
        "description": "标准功能"
    },
    "professional": {
        "skills": [
            "basic_search: 基础搜索",
            "basic_calculate: 简单计算",
            "advanced_search: 高级搜索",
            "data_analysis: 数据分析",
            "database_query: 数据库查询，SQL操作",
            "ml_predict: 机器学习预测"
        ],
        "tools": {"basic_search", "basic_calculate", "advanced_search", "data_analysis",
                  "database_query", "ml_predict"},
        "description": "专业功能"
    },
    "admin": {
        "skills": [
            "basic_search: 基础搜索",
            "basic_calculate: 简单计算",
            "advanced_search: 高级搜索",
            "data_analysis: 数据分析",
            "database_query: 数据库查询",
            "ml_predict: ML预测",
            "execute_code: 执行代码（需确认）",
            "admin_config: 管理员配置（需确认）"
        ],
        "tools": {"basic_search", "basic_calculate", "advanced_search", "data_analysis",
                  "database_query", "ml_predict", "execute_code", "admin_config"},
        "description": "管理员功能（全部权限）"
    }
}


# ========== 渐进式技能加载中间件 ==========

class ProgressiveSkillLoaderMiddleware(AgentMiddleware):
    """
    渐进式技能加载中间件

    功能：根据用户权限等级，动态加载 skills 参数中对应的工具
    使用 request.override() 修改 tools 和 system_message

    权限等级：
        - basic: 基础搜索、计算
        - standard: +高级搜索、数据分析
        - professional: +数据库、ML
        - admin: +危险操作
    """

    def __init__(
        self,
        permission_level: str = "basic",
        skills_definition: Optional[Dict[str, Dict]] = None,
        all_tools: Optional[List[BaseTool]] = None
    ):
        """
        初始化

        Args:
            permission_level: 初始权限等级
            skills_definition: 技能定义字典
            all_tools: 所有可用工具列表
        """
        self.permission_level = permission_level
        self.skills_definition = skills_definition or SKILLS_DEFINITION
        self.all_tools = all_tools or []
        self._tool_map: Dict[str, BaseTool] = {}
        self._level_history: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

        # 构建工具名称到工具对象的映射
        for tool_obj in self.all_tools:
            tool_name = getattr(tool_obj, "name", None)
            if tool_name:
                self._tool_map[tool_name] = tool_obj

    def set_permission_level(self, level: str):
        """设置权限等级"""
        if level in self.skills_definition:
            with self._lock:
                self.permission_level = level
            print(f"[ProgressiveSkill] 🔐 权限等级设置为: {level}")
        else:
            print(f"[ProgressiveSkill] ⚠️ 未知权限等级: {level}")

    def _get_allowed_tools(self) -> List[BaseTool]:
        """获取当前权限允许的工具"""
        level_config = self.skills_definition.get(
            self.permission_level,
            self.skills_definition["basic"]
        )
        allowed_names = level_config["tools"]

        # 过滤出允许的工具
        allowed_tools = [
            self._tool_map[name]
            for name in allowed_names
            if name in self._tool_map
        ]
        return allowed_tools

    def _build_skill_prompt(self) -> str:
        """构建技能说明提示词"""
        level_config = self.skills_definition.get(
            self.permission_level,
            self.skills_definition["basic"]
        )

        skills_list = "\n".join(f"  - {s}" for s in level_config["skills"])

        return f"""
## 当前可用技能 ({level_config['description']})

{skills_list}

**权限等级**: {self.permission_level}
"""

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """使用 override() 修改 tools 和 system_message"""
        allowed_tools = self._get_allowed_tools()
        skill_prompt = self._build_skill_prompt()

        # 记录
        with self._lock:
            self._level_history.append({
                "level": self.permission_level,
                "allowed_tools": [t.name for t in allowed_tools],
                "timestamp": datetime.now().isoformat()
            })

        print(f"[ProgressiveSkill] 🎯 权限: {self.permission_level}, 可用工具: {[t.name for t in allowed_tools]}")

        # 构建新的系统消息
        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_content = original_content + skill_prompt
        new_system = SystemMessage(content=new_content)

        # 关键：使用 override() 修改 tools 和 system_message
        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools  # 动态设置可用工具
        )

        return handler(modified_request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步版本"""
        allowed_tools = self._get_allowed_tools()
        skill_prompt = self._build_skill_prompt()

        with self._lock:
            self._level_history.append({
                "level": self.permission_level,
                "allowed_tools": [t.name for t in allowed_tools],
                "timestamp": datetime.now().isoformat()
            })

        print(f"[ProgressiveSkill] 🎯 权限: {self.permission_level}, 可用工具: {[t.name for t in allowed_tools]}")

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_content = original_content + skill_prompt
        new_system = SystemMessage(content=new_content)

        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return await handler(modified_request)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._lock:
            return {
                "current_level": self.permission_level,
                "allowed_tools": list(self.skills_definition.get(
                    self.permission_level,
                    self.skills_definition["basic"]
                )["tools"]),
                "history_count": len(self._level_history)
            }


class RoleBasedSkillMiddleware(AgentMiddleware):
    """
    基于角色的技能中间件

    功能：根据用户角色自动分配权限等级
    使用 request.override() 动态修改工具和提示词
    """

    ROLE_PERMISSIONS = {
        "guest": "basic",
        "user": "standard",
        "developer": "professional",
        "admin": "admin"
    }

    def __init__(
        self,
        skills_definition: Optional[Dict[str, Dict]] = None,
        all_tools: Optional[List[BaseTool]] = None,
        default_role: str = "guest"
    ):
        self.skills_definition = skills_definition or SKILLS_DEFINITION
        self.all_tools = all_tools or []
        self.default_role = default_role
        self._tool_map: Dict[str, BaseTool] = {}
        self._role_history: List[str] = []

        for tool_obj in self.all_tools:
            tool_name = getattr(tool_obj, "name", None)
            if tool_name:
                self._tool_map[tool_name] = tool_obj

    def _detect_role(self, request: ModelRequest) -> str:
        """检测用户角色"""
        # 优先从 state 获取
        if "user_role" in request.state:
            return request.state["user_role"]

        # 从消息推断
        messages = request.messages
        if messages:
            content = getattr(messages[-1], "content", "").lower()
            if any(kw in content for kw in ["管理员", "admin", "配置"]):
                return "admin"
            if any(kw in content for kw in ["代码", "开发", "数据库", "sql"]):
                return "developer"

        return self.default_role

    def _get_permission_for_role(self, role: str) -> str:
        """获取角色对应的权限等级"""
        return self.ROLE_PERMISSIONS.get(role, "basic")

    def _get_allowed_tools(self, permission: str) -> List[BaseTool]:
        """获取权限对应的工具"""
        level_config = self.skills_definition.get(
            permission,
            self.skills_definition["basic"]
        )
        allowed_names = level_config["tools"]

        return [
            self._tool_map[name]
            for name in allowed_names
            if name in self._tool_map
        ]

    def _build_skill_prompt(self, permission: str) -> str:
        """构建技能提示"""
        level_config = self.skills_definition.get(
            permission,
            self.skills_definition["basic"]
        )
        skills_list = "\n".join(f"  - {s}" for s in level_config["skills"])
        return f"\n## 可用技能 ({level_config['description']})\n{skills_list}"

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据角色动态加载工具"""
        role = self._detect_role(request)
        permission = self._get_permission_for_role(role)
        allowed_tools = self._get_allowed_tools(permission)
        skill_prompt = self._build_skill_prompt(permission)

        self._role_history.append(role)
        print(f"[RoleBasedSkill] 👤 角色: {role}, 权限: {permission}, 工具: {[t.name for t in allowed_tools]}")

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_system = SystemMessage(content=original_content + skill_prompt)

        # 使用 override() 修改
        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return handler(modified_request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步版本"""
        role = self._detect_role(request)
        permission = self._get_permission_for_role(role)
        allowed_tools = self._get_allowed_tools(permission)
        skill_prompt = self._build_skill_prompt(permission)

        self._role_history.append(role)
        print(f"[RoleBasedSkill] 👤 角色: {role}, 权限: {permission}")

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_system = SystemMessage(content=original_content + skill_prompt)

        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return await handler(modified_request)


class TrustBasedProgressionMiddleware(AgentMiddleware):
    """
    基于信任度的渐进解锁中间件

    功能：根据用户成功使用次数，逐步解锁更高权限的工具
    使用 request.override() 动态修改可用工具
    """

    TRUST_LEVELS = {
        1: "basic",        # 0-4 次成功
        2: "standard",     # 5-9 次成功
        3: "professional", # 10-19 次成功
        4: "admin"         # 20+ 次成功
    }

    def __init__(
        self,
        skills_definition: Optional[Dict[str, Dict]] = None,
        all_tools: Optional[List[BaseTool]] = None,
        initial_trust: int = 1
    ):
        self.skills_definition = skills_definition or SKILLS_DEFINITION
        self.all_tools = all_tools or []
        self.trust_level = initial_trust
        self._successful_calls = 0
        self._tool_map: Dict[str, BaseTool] = {}
        self._lock = threading.Lock()

        for tool_obj in self.all_tools:
            tool_name = getattr(tool_obj, "name", None)
            if tool_name:
                self._tool_map[tool_name] = tool_obj

    def _get_permission_for_trust(self) -> str:
        """根据信任度获取权限"""
        return self.TRUST_LEVELS.get(self.trust_level, "basic")

    def _check_upgrade(self):
        """检查是否升级"""
        with self._lock:
            self._successful_calls += 1

            # 升级逻辑
            old_level = self.trust_level
            if self._successful_calls >= 20 and self.trust_level < 4:
                self.trust_level = 4
            elif self._successful_calls >= 10 and self.trust_level < 3:
                self.trust_level = 3
            elif self._successful_calls >= 5 and self.trust_level < 2:
                self.trust_level = 2

            if old_level != self.trust_level:
                print(f"[TrustBased] 🌟 信任度升级: {old_level} -> {self.trust_level} (成功调用: {self._successful_calls})")

    def after_agent(self, state, _runtime) -> dict[str, Any] | None:
        """Agent 完成后更新信任度"""
        self._check_upgrade()
        return None

    def _get_allowed_tools(self) -> List[BaseTool]:
        """获取当前允许的工具"""
        permission = self._get_permission_for_trust()
        level_config = self.skills_definition.get(permission, self.skills_definition["basic"])
        allowed_names = level_config["tools"]

        return [
            self._tool_map[name]
            for name in allowed_names
            if name in self._tool_map
        ]

    def _build_skill_prompt(self) -> str:
        """构建技能提示"""
        permission = self._get_permission_for_trust()
        level_config = self.skills_definition.get(permission, self.skills_definition["basic"])
        skills_list = "\n".join(f"  - {s}" for s in level_config["skills"])

        return f"""
## 可用技能 (信任等级: {self.trust_level})

{skills_list}

*随着使用，更多技能将被解锁*
"""

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据信任度加载工具"""
        allowed_tools = self._get_allowed_tools()
        skill_prompt = self._build_skill_prompt()

        print(f"[TrustBased] 🔐 信任: {self.trust_level}, 权限: {self._get_permission_for_trust()}, 工具: {[t.name for t in allowed_tools]}")

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_system = SystemMessage(content=original_content + skill_prompt)

        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return handler(modified_request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步版本"""
        allowed_tools = self._get_allowed_tools()
        skill_prompt = self._build_skill_prompt()

        print(f"[TrustBased] 🔐 信任: {self.trust_level}")

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_system = SystemMessage(content=original_content + skill_prompt)

        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return await handler(modified_request)

    def get_trust_info(self) -> Dict[str, Any]:
        """获取信任信息"""
        with self._lock:
            return {
                "trust_level": self.trust_level,
                "permission": self._get_permission_for_trust(),
                "successful_calls": self._successful_calls
            }


class ContextAwareSkillMiddleware(AgentMiddleware):
    """
    上下文感知技能中间件

    功能：根据请求内容和上下文，临时提升权限
    使用 request.override() 动态修改工具
    """

    def __init__(
        self,
        skills_definition: Optional[Dict[str, Dict]] = None,
        all_tools: Optional[List[BaseTool]] = None,
        base_permission: str = "basic"
    ):
        self.skills_definition = skills_definition or SKILLS_DEFINITION
        self.all_tools = all_tools or []
        self.base_permission = base_permission
        self._tool_map: Dict[str, BaseTool] = {}
        self._upgrade_count = 0

        for tool_obj in self.all_tools:
            tool_name = getattr(tool_obj, "name", None)
            if tool_name:
                self._tool_map[tool_name] = tool_obj

    def _detect_needed_permission(self, request: ModelRequest) -> str:
        """检测需要的权限等级"""
        messages = request.messages
        if not messages:
            return self.base_permission

        content = getattr(messages[-1], "content", "").lower()

        # 关键词检测
        if any(kw in content for kw in ["执行代码", "管理员", "admin", "配置系统"]):
            return "admin"
        if any(kw in content for kw in ["数据库", "sql", "机器学习", "ml", "预测"]):
            return "professional"
        if any(kw in content for kw in ["高级搜索", "分析", "详细"]):
            return "standard"

        return self.base_permission

    def _get_allowed_tools(self, permission: str) -> List[BaseTool]:
        """获取工具"""
        level_config = self.skills_definition.get(permission, self.skills_definition["basic"])
        allowed_names = level_config["tools"]

        return [
            self._tool_map[name]
            for name in allowed_names
            if name in self._tool_map
        ]

    def _build_skill_prompt(self, permission: str, is_upgraded: bool) -> str:
        """构建技能提示"""
        level_config = self.skills_definition.get(permission, self.skills_definition["basic"])
        skills_list = "\n".join(f"  - {s}" for s in level_config["skills"])

        upgrade_note = ""
        if is_upgraded:
            upgrade_note = "\n\n*已临时提升权限以处理此请求*"

        return f"""
## 可用技能 ({level_config['description']})

{skills_list}
{upgrade_note}
"""

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据上下文动态调整权限"""
        needed_permission = self._detect_needed_permission(request)

        # 确定最终权限（不低于基础权限）
        permission_order = ["basic", "standard", "professional", "admin"]
        base_idx = permission_order.index(self.base_permission)
        needed_idx = permission_order.index(needed_permission)

        # 只能提升，不能降低
        final_idx = max(base_idx, needed_idx)
        final_permission = permission_order[final_idx]
        is_upgraded = final_idx > base_idx

        if is_upgraded:
            self._upgrade_count += 1
            print(f"[ContextAware] 🚀 临时提升权限: {self.base_permission} -> {final_permission}")

        allowed_tools = self._get_allowed_tools(final_permission)
        skill_prompt = self._build_skill_prompt(final_permission, is_upgraded)

        print(f"[ContextAware] 🎯 最终权限: {final_permission}, 工具: {[t.name for t in allowed_tools]}")

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_system = SystemMessage(content=original_content + skill_prompt)

        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return handler(modified_request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步版本"""
        needed_permission = self._detect_needed_permission(request)

        permission_order = ["basic", "standard", "professional", "admin"]
        base_idx = permission_order.index(self.base_permission)
        needed_idx = permission_order.index(needed_permission)

        final_idx = max(base_idx, needed_idx)
        final_permission = permission_order[final_idx]
        is_upgraded = final_idx > base_idx

        if is_upgraded:
            self._upgrade_count += 1
            print(f"[ContextAware] 🚀 临时提升权限: {self.base_permission} -> {final_permission}")

        allowed_tools = self._get_allowed_tools(final_permission)
        skill_prompt = self._build_skill_prompt(final_permission, is_upgraded)

        original_system = request.system_message
        original_content = getattr(original_system, "content", "") if original_system else ""
        new_system = SystemMessage(content=original_content + skill_prompt)

        modified_request = request.override(
            system_message=new_system,
            tools=allowed_tools
        )

        return await handler(modified_request)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计"""
        return {
            "base_permission": self.base_permission,
            "upgrade_count": self._upgrade_count
        }


# ========== 示例函数 ==========

async def progressive_skill_loading_example():
    """渐进式技能加载示例"""
    print("=" * 60)
    print("示例 1: 根据权限渐进加载 Skills 中的工具")
    print("=" * 60)

    all_tools = [basic_search, basic_calculate, advanced_search, data_analysis,
                 database_query, ml_predict, execute_code, admin_config]

    progressive_loader = ProgressiveSkillLoaderMiddleware(
        permission_level="basic",
        skills_definition=SKILLS_DEFINITION,
        all_tools=all_tools
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=all_tools,
        skills=SKILLS_DEFINITION["admin"]["skills"],  # 传入全部技能定义
        system_prompt="你是一个智能助手，根据权限使用工具。",
        middleware=[progressive_loader],
        name="progressive_agent"
    )

    # Basic 权限
    print("\n--- Basic 权限 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索 Python")]})

    # 升级到 Standard
    print("\n--- 升级到 Standard ---")
    progressive_loader.set_permission_level("standard")
    await agent.ainvoke({"messages": [HumanMessage(content="高级搜索 Python 教程")]})

    # 升级到 Professional
    print("\n--- 升级到 Professional ---")
    progressive_loader.set_permission_level("professional")
    await agent.ainvoke({"messages": [HumanMessage(content="查询数据库")]})

    print(f"\n📊 统计: {progressive_loader.get_stats()}")


async def role_based_skill_example():
    """基于角色的技能加载示例"""
    print("\n" + "=" * 60)
    print("示例 2: 根据用户角色加载 Skills")
    print("=" * 60)

    all_tools = [basic_search, basic_calculate, advanced_search, data_analysis,
                 database_query, ml_predict, execute_code, admin_config]

    role_based = RoleBasedSkillMiddleware(
        skills_definition=SKILLS_DEFINITION,
        all_tools=all_tools,
        default_role="guest"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=all_tools,
        skills=SKILLS_DEFINITION["admin"]["skills"],
        system_prompt="你是一个助手。",
        middleware=[role_based],
        name="role_based_agent"
    )

    # Guest 用户
    print("\n--- Guest 用户 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索信息")]})

    # Developer 用户（通过 state 指定）
    print("\n--- Developer 用户 ---")
    await agent.ainvoke({
        "messages": [HumanMessage(content="查询数据库")],
        "user_role": "developer"
    })

    # Admin 用户
    print("\n--- Admin 用户 ---")
    await agent.ainvoke({
        "messages": [HumanMessage(content="系统配置")],
        "user_role": "admin"
    })


async def trust_based_progression_example():
    """基于信任度的渐进解锁示例"""
    print("\n" + "=" * 60)
    print("示例 3: 根据信任度渐进解锁 Skills")
    print("=" * 60)

    all_tools = [basic_search, basic_calculate, advanced_search, data_analysis,
                 database_query, ml_predict]

    trust_based = TrustBasedProgressionMiddleware(
        skills_definition=SKILLS_DEFINITION,
        all_tools=all_tools,
        initial_trust=1
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=all_tools,
        skills=SKILLS_DEFINITION["professional"]["skills"],
        system_prompt="你是一个助手。",
        middleware=[trust_based],
        name="trust_based_agent"
    )

    # 执行多次，观察信任度变化
    for i in range(6):
        print(f"\n--- 第 {i+1} 次请求 ---")
        await agent.ainvoke({"messages": [HumanMessage(content=f"搜索 {i+1}")]})

    print(f"\n📊 信任信息: {trust_based.get_trust_info()}")


async def context_aware_skill_example():
    """上下文感知技能加载示例"""
    print("\n" + "=" * 60)
    print("示例 4: 根据上下文临时提升权限")
    print("=" * 60)

    all_tools = [basic_search, basic_calculate, advanced_search, data_analysis,
                 database_query, ml_predict, execute_code]

    context_aware = ContextAwareSkillMiddleware(
        skills_definition=SKILLS_DEFINITION,
        all_tools=all_tools,
        base_permission="basic"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=all_tools,
        skills=SKILLS_DEFINITION["admin"]["skills"],
        system_prompt="你是一个助手。",
        middleware=[context_aware],
        name="context_aware_agent"
    )

    # 基础请求
    print("\n--- 基础请求 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索信息")]})

    # 触发权限提升（包含"数据库"关键词）
    print("\n--- 触发权限提升 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="查询数据库用户表")]})

    # 再次基础请求
    print("\n--- 再次基础请求 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="计算 1+1")]})

    print(f"\n📊 统计: {context_aware.get_stats()}")


async def combined_middleware_example():
    """组合中间件示例"""
    print("\n" + "=" * 60)
    print("示例 5: 组合多种渐进加载策略")
    print("=" * 60)

    all_tools = [basic_search, basic_calculate, advanced_search, data_analysis,
                 database_query, ml_predict]

    # 组合：角色基础 + 信任度提升 + 上下文感知
    role_based = RoleBasedSkillMiddleware(
        skills_definition=SKILLS_DEFINITION,
        all_tools=all_tools,
        default_role="user"
    )
    context_aware = ContextAwareSkillMiddleware(
        skills_definition=SKILLS_DEFINITION,
        all_tools=all_tools,
        base_permission="standard"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=all_tools,
        skills=SKILLS_DEFINITION["professional"]["skills"],
        system_prompt="你是一个智能助手。",
        middleware=[role_based, context_aware],
        name="combined_agent"
    )

    # 普通用户
    print("\n--- 普通用户 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索")]})

    # Developer + 需要数据库
    print("\n--- Developer + 数据库请求 ---")
    await agent.ainvoke({
        "messages": [HumanMessage(content="查询数据库")],
        "user_role": "developer"
    })

    print(f"\n📊 ContextAware 统计: {context_aware.get_stats()}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🚀 渐进式技能加载示例 (skills + request.override)")
    print("=" * 70)

    await progressive_skill_loading_example()
    await role_based_skill_example()
    await trust_based_progression_example()
    await context_aware_skill_example()
    await combined_middleware_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
