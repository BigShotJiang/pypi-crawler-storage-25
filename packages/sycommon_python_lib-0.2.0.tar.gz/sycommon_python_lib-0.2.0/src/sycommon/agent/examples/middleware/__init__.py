"""
中间件示例集合
=============

展示各种中间件的使用方法。

示例列表:
    01_basic_monitoring.py    - 基础监控（计时、日志、指标、追踪）
    02_permission_control.py  - 权限控制（RBAC、认证、IP白名单、审计）
    03_tool_skill_filter.py   - 工具和技能过滤
    04_caching_retry.py       - 缓存和重试（缓存、重试、断路器、降级）
    05_sanitization.py        - 数据清洗（输入清洗、输出清洗、内容过滤）
    06_tracking.py            - 追踪审计（审计日志、成本追踪、分布式追踪）
    07_advanced.py            - 高级功能（A/B测试、配额、用户上下文）
    08_progressive_skills.py  - 渐进式技能加载（技能等级、上下文感知、工具解锁）
    override_examples.py      - request.override() 高级用法

运行方式:
    python -m sycommon.agent.examples.middleware.01_basic_monitoring
    python -m sycommon.agent.examples.middleware.02_permission_control
    python -m sycommon.agent.examples.middleware.03_tool_skill_filter
    python -m sycommon.agent.examples.middleware.04_caching_retry
    python -m sycommon.agent.examples.middleware.05_sanitization
    python -m sycommon.agent.examples.middleware.06_tracking
    python -m sycommon.agent.examples.middleware.07_advanced
    python -m sycommon.agent.examples.middleware.08_progressive_skills
    python -m sycommon.agent.examples.middleware.override_examples
"""

__all__ = [
    "01_basic_monitoring",
    "02_permission_control",
    "03_tool_skill_filter",
    "04_caching_retry",
    "05_sanitization",
    "06_tracking",
    "07_advanced",
    "08_progressive_skills",
    "override_examples",
]
