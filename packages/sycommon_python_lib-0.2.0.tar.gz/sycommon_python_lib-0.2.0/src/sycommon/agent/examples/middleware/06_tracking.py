"""
中间件示例 06: 追踪审计中间件
============================

展示审计日志、成本追踪、分布式追踪相关的中间件，基于 AgentMiddleware。

运行方式:
    python -m sycommon.agent.examples.middleware.06_tracking
"""
import asyncio
import time
import json
import threading
from typing import Any, Dict, List, Optional, Callable, Awaitable
from datetime import datetime
from collections import defaultdict
from langchain_core.messages import HumanMessage, AIMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse, ToolCallRequest
)
from langchain_core.messages import ToolMessage

from sycommon.agent import get_agent


# ========== 审计中间件 ==========

class AuditMiddleware(AgentMiddleware):
    """
    审计中间件

    功能：记录所有操作的审计日志
    """

    def __init__(
        self,
        include_request: bool = True,
        include_response: bool = True,
        sensitive_fields: Optional[List[str]] = None
    ):
        self.include_request = include_request
        self.include_response = include_response
        self.sensitive_fields = sensitive_fields or ["password", "token", "secret", "key"]
        self._audit_logs: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _mask_sensitive(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """掩码敏感字段"""
        masked = {}
        for key, value in data.items():
            if any(sf in key.lower() for sf in self.sensitive_fields):
                masked[key] = "***MASKED***"
            elif isinstance(value, dict):
                masked[key] = self._mask_sensitive(value)
            else:
                masked[key] = value
        return masked

    def _create_audit_entry(self, action: str, details: Dict[str, Any]) -> Dict[str, Any]:
        """创建审计条目"""
        return {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "details": self._mask_sensitive(details) if self.include_request else {}
        }

    def _log(self, entry: Dict[str, Any]):
        """记录审计日志"""
        with self._lock:
            self._audit_logs.append(entry)

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录 Agent 开始"""
        entry = self._create_audit_entry(
            "agent_start",
            {
                "message_count": len(state.get("messages", [])),
                "session_id": state.get("session_id", "unknown")
            }
        )
        self._log(entry)
        print(f"[Audit] 📋 Agent 开始执行")
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录 Agent 结束"""
        entry = self._create_audit_entry(
            "agent_end",
            {
                "message_count": len(state.get("messages", [])),
                "session_id": state.get("session_id", "unknown")
            }
        )
        self._log(entry)
        print(f"[Audit] 📋 Agent 执行完成")
        return None

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """记录模型调用"""
        entry = self._create_audit_entry(
            "model_call_start",
            {"message_count": len(request.state.get("messages", []))}
        )
        self._log(entry)

        response = handler(request)

        entry = self._create_audit_entry(
            "model_call_end",
            {
                "has_response": bool(response),
                "has_structured_response": hasattr(response, 'structured_response') and response.structured_response is not None
            }
        )
        self._log(entry)

        return response

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """记录工具调用"""
        tool_name = request.tool_call.get("name", "unknown")
        tool_args = request.tool_call.get("args", {})

        entry = self._create_audit_entry(
            "tool_call_start",
            {"tool": tool_name, "args": tool_args}
        )
        self._log(entry)
        print(f"[Audit] 📋 工具调用: {tool_name}")

        result = handler(request)

        entry = self._create_audit_entry(
            "tool_call_end",
            {"tool": tool_name, "success": True}
        )
        self._log(entry)

        return result

    @property
    def logs(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._audit_logs)

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            action_counts = defaultdict(int)
            for log in self._audit_logs:
                action_counts[log["action"]] += 1
            return {
                "total_entries": len(self._audit_logs),
                "action_counts": dict(action_counts)
            }


class CostTrackingMiddleware(AgentMiddleware):
    """
    成本追踪中间件

    功能：追踪 LLM 调用成本
    """

    # 每千 token 价格 (USD)
    PRICING = {
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
        "claude-3-opus": {"input": 0.015, "output": 0.075},
        "claude-3-sonnet": {"input": 0.003, "output": 0.015},
        "qwen": {"input": 0.002, "output": 0.006},  # 估算
    }

    def __init__(self, default_model: str = "qwen"):
        self.default_model = default_model
        self._costs: List[Dict[str, Any]] = []
        self._total_input_tokens = 0
        self._total_output_tokens = 0
        self._total_cost = 0.0
        self._lock = threading.Lock()

    def _calculate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """计算成本"""
        pricing = self.PRICING.get(model, self.PRICING["qwen"])
        input_cost = (input_tokens / 1000) * pricing["input"]
        output_cost = (output_tokens / 1000) * pricing["output"]
        return input_cost + output_cost

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """追踪模型调用成本"""
        response = handler(request)

        # 尝试获取 token 使用信息
        input_tokens = 0
        output_tokens = 0

        if hasattr(response, 'usage_metadata') and response.usage_metadata:
            input_tokens = response.usage_metadata.get('input_tokens', 0)
            output_tokens = response.usage_metadata.get('output_tokens', 0)
        elif hasattr(response, 'result') and response.result:
            # 估算
            for msg in response.result:
                if hasattr(msg, 'content'):
                    output_tokens += len(msg.content) // 4  # 粗略估算

        cost = self._calculate_cost(self.default_model, input_tokens, output_tokens)

        with self._lock:
            self._total_input_tokens += input_tokens
            self._total_output_tokens += output_tokens
            self._total_cost += cost
            self._costs.append({
                "timestamp": datetime.now().isoformat(),
                "model": self.default_model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cost": cost
            })

        print(f"[CostTracking] 💰 Token使用: 输入={input_tokens}, 输出={output_tokens}, 成本=${cost:.6f}")

        return response

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_input_tokens": self._total_input_tokens,
                "total_output_tokens": self._total_output_tokens,
                "total_cost": self._total_cost,
                "call_count": len(self._costs)
            }


class DistributedTracingMiddleware(AgentMiddleware):
    """
    分布式追踪中间件

    功能：实现完整的分布式追踪
    """

    def __init__(self, service_name: str = "agent-service"):
        self.service_name = service_name
        self._spans: List[Dict[str, Any]] = []
        self._current_trace_id: Optional[str] = None
        self._lock = threading.Lock()

    def _generate_id(self, length: int = 16) -> str:
        import hashlib
        return hashlib.md5(f"{time.time()}{id(self)}".encode()).hexdigest()[:length]

    def _create_span(
        self,
        span_name: str,
        trace_id: str,
        parent_span_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """创建 span"""
        return {
            "trace_id": trace_id,
            "span_id": self._generate_id(8),
            "parent_span_id": parent_span_id,
            "name": span_name,
            "service": self.service_name,
            "start_time": time.time(),
            "end_time": None,
            "duration_ms": None,
            "tags": {}
        }

    def _finish_span(self, span: Dict[str, Any]) -> None:
        """结束 span"""
        span["end_time"] = time.time()
        span["duration_ms"] = (span["end_time"] - span["start_time"]) * 1000
        with self._lock:
            self._spans.append(span)

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """开始追踪"""
        trace_id = state.get("_trace_id") or self._generate_id(16)
        self._current_trace_id = trace_id

        span = self._create_span("agent_execution", trace_id)
        state["_root_span"] = span
        state["_trace_id"] = trace_id

        print(f"[DistributedTracing] 🔍 开始追踪 trace_id={trace_id}")
        return {"_trace_id": trace_id, "_root_span": span}

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """结束追踪"""
        span = state.get("_root_span")
        if span:
            self._finish_span(span)
            print(f"[DistributedTracing] 🔍 追踪完成 duration={span['duration_ms']:.2f}ms")
        return None

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """追踪模型调用"""
        trace_id = request.state.get("_trace_id", self._generate_id(16))
        parent_span_id = request.state.get("_root_span", {}).get("span_id")

        span = self._create_span("model_call", trace_id, parent_span_id)
        print(f"[DistributedTracing] 📡 模型调用 span_id={span['span_id']}")

        response = handler(request)

        self._finish_span(span)
        return response

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """追踪工具调用"""
        trace_id = request.state.get("_trace_id", self._generate_id(16))
        parent_span_id = request.state.get("_root_span", {}).get("span_id")
        tool_name = request.tool_call.get("name", "unknown")

        span = self._create_span(f"tool_{tool_name}", trace_id, parent_span_id)
        span["tags"]["tool"] = tool_name
        print(f"[DistributedTracing] 🔧 工具调用: {tool_name} span_id={span['span_id']}")

        result = handler(request)

        self._finish_span(span)
        return result

    @property
    def traces(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._spans)

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_spans": len(self._spans),
                "trace_ids": list(set(s["trace_id"] for s in self._spans))
            }


class RequestLoggingMiddleware(AgentMiddleware):
    """
    请求日志中间件

    功能：详细记录请求和响应
    """

    def __init__(
        self,
        log_request_body: bool = True,
        log_response_body: bool = True,
        max_body_length: int = 1000
    ):
        self.log_request_body = log_request_body
        self.log_response_body = log_response_body
        self.max_body_length = max_body_length
        self._request_logs: List[Dict[str, Any]] = []

    def _truncate(self, text: str) -> str:
        """截断文本"""
        if len(text) > self.max_body_length:
            return text[:self.max_body_length] + "...[truncated]"
        return text

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录请求"""
        messages = state.get("messages", [])
        request_content = ""

        if messages and self.log_request_body:
            last_msg = messages[-1]
            if hasattr(last_msg, "content"):
                request_content = self._truncate(str(last_msg.content))

        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "type": "request",
            "message_count": len(messages),
            "content": request_content
        }
        self._request_logs.append(log_entry)

        print(f"[RequestLogging] 📥 请求: {request_content[:50]}...")
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录响应"""
        messages = state.get("messages", [])
        response_content = ""

        if messages and self.log_response_body:
            last_msg = messages[-1]
            if hasattr(last_msg, "content"):
                response_content = self._truncate(str(last_msg.content))

        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "type": "response",
            "message_count": len(messages),
            "content": response_content
        }
        self._request_logs.append(log_entry)

        print(f"[RequestLogging] 📤 响应: {response_content[:50]}...")
        return None

    @property
    def logs(self) -> List[Dict[str, Any]]:
        return list(self._request_logs)


class PerformanceTrackingMiddleware(AgentMiddleware):
    """
    性能追踪中间件

    功能：追踪各阶段性能指标
    """

    def __init__(self):
        self._metrics: Dict[str, List[float]] = defaultdict(list)
        self._start_times: Dict[str, float] = {}

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录开始时间"""
        self._start_times["agent"] = time.time()
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """记录 Agent 总耗时"""
        if "agent" in self._start_times:
            elapsed = time.time() - self._start_times["agent"]
            self._metrics["agent_total"].append(elapsed)
        return None

    def before_model(self, state, runtime) -> dict[str, Any] | None:
        """记录模型调用开始"""
        self._start_times["model"] = time.time()
        return None

    def after_model(self, state, runtime) -> dict[str, Any] | None:
        """记录模型调用结束"""
        if "model" in self._start_times:
            elapsed = time.time() - self._start_times["model"]
            self._metrics["model_call"].append(elapsed)
        return None

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """追踪工具调用"""
        tool_name = request.tool_call.get("name", "unknown")
        start = time.time()

        result = handler(request)

        elapsed = time.time() - start
        self._metrics[f"tool_{tool_name}"].append(elapsed)

        return result

    @property
    def metrics(self) -> Dict[str, Dict[str, float]]:
        result = {}
        for key, values in self._metrics.items():
            if values:
                result[key] = {
                    "count": len(values),
                    "total": sum(values),
                    "avg": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values)
                }
        return result


# ========== 示例函数 ==========

async def audit_example():
    """审计示例"""
    print("=" * 60)
    print("示例 1: 审计中间件")
    print("=" * 60)

    audit = AuditMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[audit],
        name="audited_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 审计统计: {audit.stats}")


async def cost_tracking_example():
    """成本追踪示例"""
    print("\n" + "=" * 60)
    print("示例 2: 成本追踪")
    print("=" * 60)

    cost_tracker = CostTrackingMiddleware(default_model="qwen")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[cost_tracker],
        name="cost_tracked_agent"
    )

    # 执行多次
    for i in range(2):
        await agent.ainvoke({"messages": [HumanMessage(content=f"测试{i+1}")]})

    print(f"\n📊 成本统计: {cost_tracker.stats}")


async def distributed_tracing_example():
    """分布式追踪示例"""
    print("\n" + "=" * 60)
    print("示例 3: 分布式追踪")
    print("=" * 60)

    tracer = DistributedTracingMiddleware("my-agent-service")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[tracer],
        name="traced_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 追踪统计: {tracer.stats}")


async def request_logging_example():
    """请求日志示例"""
    print("\n" + "=" * 60)
    print("示例 4: 请求日志")
    print("=" * 60)

    req_logger = RequestLoggingMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[req_logger],
        name="logged_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📋 日志条数: {len(req_logger.logs)}")


async def performance_tracking_example():
    """性能追踪示例"""
    print("\n" + "=" * 60)
    print("示例 5: 性能追踪")
    print("=" * 60)

    perf_tracker = PerformanceTrackingMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[perf_tracker],
        name="perf_tracked_agent"
    )

    # 执行多次
    for i in range(3):
        await agent.ainvoke({"messages": [HumanMessage(content=f"测试{i+1}")]})

    print(f"\n📊 性能指标: {perf_tracker.metrics}")


async def combined_tracking_example():
    """组合追踪示例"""
    print("\n" + "=" * 60)
    print("示例 6: 组合追踪机制")
    print("=" * 60)

    audit = AuditMiddleware()
    cost_tracker = CostTrackingMiddleware()
    tracer = DistributedTracingMiddleware("combined-service")
    perf = PerformanceTrackingMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[audit, cost_tracker, tracer, perf],
        name="fully_tracked_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="综合测试")]})

    print(f"\n📊 综合统计:")
    print(f"  审计: {audit.stats}")
    print(f"  成本: {cost_tracker.stats}")
    print(f"  追踪: {tracer.stats}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🔍 追踪审计中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await audit_example()
    await cost_tracking_example()
    await distributed_tracing_example()
    await request_logging_example()
    await performance_tracking_example()
    await combined_tracking_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
