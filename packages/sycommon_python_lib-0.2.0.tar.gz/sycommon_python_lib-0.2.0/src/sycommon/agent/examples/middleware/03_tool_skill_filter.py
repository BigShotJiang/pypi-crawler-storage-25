"""
中间件示例 03: 工具和技能过滤中间件
==================================

展示工具调用过滤、技能访问控制相关的中间件，基于 AgentMiddleware。

运行方式:
    python -m sycommon.agent.examples.middleware.03_tool_skill_filter
"""
import asyncio
import time
import threading
from typing import Any, Dict, List, Optional, Callable, Set, Awaitable
from datetime import datetime
from collections import defaultdict
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool, BaseTool
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse, ToolCallRequest
)
from langchain_core.messages import ToolMessage

from sycommon.agent import get_agent


# ========== 工具定义 ==========

@tool
def search_web(query: str) -> str:
    """搜索网络"""
    return f"搜索结果: {query}"


@tool
def query_database(sql: str) -> str:
    """查询数据库"""
    return f"SQL 执行结果: {sql}"


@tool
def send_email(to: str, subject: str, body: str) -> str:
    """发送邮件"""
    return f"邮件已发送给 {to}"


@tool
def delete_file(path: str) -> str:
    """删除文件"""
    return f"文件已删除: {path}"


@tool
def execute_code(code: str) -> str:
    """执行代码"""
    return f"代码执行完成"


@tool
def admin_config(key: str, value: str) -> str:
    """管理员配置"""
    return f"配置已更新: {key}={value}"


# ========== 工具过滤中间件 ==========

class ToolWhitelistMiddleware(AgentMiddleware):
    """
    工具白名单中间件

    功能：只允许使用白名单中的工具
    """

    def __init__(self, allowed_tools: Optional[Set[str]] = None):
        self.allowed_tools = allowed_tools or {"search_web", "send_email"}
        self._blocked_calls: List[Dict[str, Any]] = []
        self._allowed_calls: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """包装工具调用，检查白名单"""
        tool_name = request.tool_call.get("name", "")

        if tool_name not in self.allowed_tools:
            with self._lock:
                self._blocked_calls.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "reason": "not_in_whitelist"
                })
            raise PermissionError(
                f"工具 '{tool_name}' 不在允许列表中。"
                f"允许的工具: {self.allowed_tools}"
            )

        with self._lock:
            self._allowed_calls.append({
                "timestamp": datetime.now().isoformat(),
                "tool": tool_name
            })

        print(f"[ToolWhitelist] ✅ 工具调用已授权: {tool_name}")
        return handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]]
    ) -> ToolMessage:
        """异步包装工具调用"""
        tool_name = request.tool_call.get("name", "")

        if tool_name not in self.allowed_tools:
            with self._lock:
                self._blocked_calls.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "reason": "not_in_whitelist"
                })
            raise PermissionError(
                f"工具 '{tool_name}' 不在允许列表中。"
                f"允许的工具: {self.allowed_tools}"
            )

        with self._lock:
            self._allowed_calls.append({
                "timestamp": datetime.now().isoformat(),
                "tool": tool_name
            })

        print(f"[ToolWhitelist] ✅ 工具调用已授权: {tool_name}")
        return await handler(request)

    def add_tool(self, tool_name: str):
        self.allowed_tools.add(tool_name)

    def remove_tool(self, tool_name: str):
        self.allowed_tools.discard(tool_name)

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "allowed_calls": len(self._allowed_calls),
                "blocked_calls": len(self._blocked_calls),
                "allowed_tools": list(self.allowed_tools)
            }


class ToolBlacklistMiddleware(AgentMiddleware):
    """
    工具黑名单中间件

    功能：禁止使用黑名单中的工具
    """

    def __init__(self, blocked_tools: Optional[Set[str]] = None):
        self.blocked_tools = blocked_tools or {"delete_file", "execute_code"}
        self._blocked_calls: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """包装工具调用，检查黑名单"""
        tool_name = request.tool_call.get("name", "")

        if tool_name in self.blocked_tools:
            with self._lock:
                self._blocked_calls.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "reason": "in_blacklist"
                })
            raise PermissionError(f"工具 '{tool_name}' 被禁止使用")

        print(f"[ToolBlacklist] ✅ 工具调用检查通过: {tool_name}")
        return handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]]
    ) -> ToolMessage:
        """异步包装工具调用"""
        tool_name = request.tool_call.get("name", "")

        if tool_name in self.blocked_tools:
            with self._lock:
                self._blocked_calls.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "reason": "in_blacklist"
                })
            raise PermissionError(f"工具 '{tool_name}' 被禁止使用")

        print(f"[ToolBlacklist] ✅ 工具调用检查通过: {tool_name}")
        return await handler(request)


class ToolQuotaMiddleware(AgentMiddleware):
    """
    工具配额中间件

    功能：限制每个工具的使用次数
    """

    def __init__(
        self,
        tool_quotas: Optional[Dict[str, int]] = None,
        default_quota: int = 10
    ):
        self.tool_quotas = tool_quotas or {
            "search_web": 20,
            "query_database": 5,
            "send_email": 10,
            "execute_code": 3
        }
        self.default_quota = default_quota
        self._usage: Dict[str, int] = defaultdict(int)
        self._lock = threading.Lock()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """包装工具调用，检查配额"""
        tool_name = request.tool_call.get("name", "")
        quota = self.tool_quotas.get(tool_name, self.default_quota)

        with self._lock:
            if self._usage[tool_name] >= quota:
                raise RuntimeError(
                    f"工具 '{tool_name}' 配额已用尽 "
                    f"({self._usage[tool_name]}/{quota})"
                )
            self._usage[tool_name] += 1
            current = self._usage[tool_name]

        print(f"[ToolQuota] 📊 {tool_name}: {current}/{quota}")
        return handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]]
    ) -> ToolMessage:
        """异步包装工具调用"""
        tool_name = request.tool_call.get("name", "")
        quota = self.tool_quotas.get(tool_name, self.default_quota)

        with self._lock:
            if self._usage[tool_name] >= quota:
                raise RuntimeError(
                    f"工具 '{tool_name}' 配额已用尽 "
                    f"({self._usage[tool_name]}/{quota})"
                )
            self._usage[tool_name] += 1
            current = self._usage[tool_name]

        print(f"[ToolQuota] 📊 {tool_name}: {current}/{quota}")
        return await handler(request)

    def get_usage_report(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "usage": dict(self._usage),
                "quotas": self.tool_quotas
            }


# ========== 技能过滤中间件 ==========

class SkillAccessMiddleware(AgentMiddleware):
    """
    技能访问控制中间件

    功能：根据用户等级控制可用的技能
    """

    def __init__(
        self,
        tier_skills: Optional[Dict[str, Set[str]]] = None,
        default_tier: str = "free"
    ):
        self.tier_skills = tier_skills or {
            "free": {"basic_chat", "simple_search"},
            "pro": {"basic_chat", "simple_search", "advanced_analysis",
                    "code_generation", "translation"},
            "enterprise": {"*"}  # 企业版拥有所有技能
        }
        self.default_tier = default_tier
        self._skill_requests: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def _extract_skill(self, state) -> str:
        """从请求中提取技能"""
        if "_requested_skill" in state:
            return state["_requested_skill"]

        content = ""
        messages = state.get("messages", [])
        if messages:
            content = getattr(messages[-1], "content", "").lower()

        skill_keywords = {
            "basic_chat": ["聊天", "对话", "chat"],
            "simple_search": ["搜索", "查找", "search"],
            "advanced_analysis": ["深度分析", "详细分析", "advanced analysis"],
            "code_generation": ["生成代码", "写代码", "code generation"],
            "translation": ["翻译", "translate"],
            "data_visualization": ["可视化", "图表", "visualization"],
            "image_generation": ["生成图片", "画图", "image generation"]
        }

        for skill, keywords in skill_keywords.items():
            if any(kw in content for kw in keywords):
                return skill

        return "basic_chat"

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查技能访问权限"""
        user_tier = state.get("user_tier", self.default_tier)
        requested_skill = self._extract_skill(state)

        # 获取该等级可用的技能
        available_skills = self.tier_skills.get(user_tier, set())

        # 检查技能是否可用
        skill_available = (
            "*" in available_skills or
            requested_skill in available_skills
        )

        with self._lock:
            self._skill_requests.append({
                "timestamp": datetime.now().isoformat(),
                "user_tier": user_tier,
                "skill": requested_skill,
                "available": skill_available
            })

        if not skill_available:
            print(f"[SkillAccess] ⚠️ 技能不可用: {requested_skill} (等级: {user_tier})")
            return {
                "_skill_unavailable": True,
                "_upgrade_message": f"技能 '{requested_skill}' 需要升级订阅。当前等级: {user_tier}"
            }

        print(f"[SkillAccess] ✨ 技能可用: {requested_skill} (等级: {user_tier})")
        return None

    def get_skill_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_requests": len(self._skill_requests),
                "requests": self._skill_requests.copy()
            }


class SkillRateLimitMiddleware(AgentMiddleware):
    """
    技能速率限制中间件

    功能：限制每个技能的使用频率
    """

    def __init__(
        self,
        skill_limits: Optional[Dict[str, Dict[str, int]]] = None
    ):
        # skill -> {max_calls, window_seconds}
        self.skill_limits = skill_limits or {
            "advanced_analysis": {"max_calls": 5, "window_seconds": 3600},
            "code_generation": {"max_calls": 10, "window_seconds": 3600},
            "image_generation": {"max_calls": 20, "window_seconds": 86400}
        }
        self._usage: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()

    def _extract_skill(self, state) -> str:
        content = ""
        messages = state.get("messages", [])
        if messages:
            content = getattr(messages[-1], "content", "").lower()

        skill_keywords = {
            "advanced_analysis": ["深度分析", "详细分析"],
            "code_generation": ["生成代码", "写代码"],
            "image_generation": ["生成图片", "画图"]
        }

        for skill, keywords in skill_keywords.items():
            if any(kw in content for kw in keywords):
                return skill
        return "basic_chat"

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """检查技能速率限制"""
        skill = self._extract_skill(state)

        if skill not in self.skill_limits:
            return None

        limit_config = self.skill_limits[skill]
        max_calls = limit_config["max_calls"]
        window = limit_config["window_seconds"]

        with self._lock:
            now = time.time()
            # 清理过期记录
            self._usage[skill] = [
                t for t in self._usage[skill] if now - t < window
            ]

            if len(self._usage[skill]) >= max_calls:
                raise RuntimeError(
                    f"技能 '{skill}' 使用过于频繁。"
                    f"{window}秒内已使用 {len(self._usage[skill])} 次"
                )

            self._usage[skill].append(now)
            current = len(self._usage[skill])

        print(f"[SkillRateLimit] 🚦 {skill}: {current}/{max_calls} ({window}s)")
        return None


class DangerousToolMiddleware(AgentMiddleware):
    """
    危险工具中间件

    功能：对危险工具进行特殊检查和确认
    """

    def __init__(
        self,
        dangerous_tools: Optional[Set[str]] = None,
        require_confirmation: bool = True
    ):
        self.dangerous_tools = dangerous_tools or {
            "delete_file", "execute_code", "admin_config"
        }
        self.require_confirmation = require_confirmation
        self._dangerous_calls: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """包装工具调用，检查危险工具"""
        tool_name = request.tool_call.get("name", "")

        if tool_name in self.dangerous_tools:
            # 检查是否有确认标志
            confirmed = request.state.get("_confirmed_dangerous", False)

            with self._lock:
                self._dangerous_calls.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "confirmed": confirmed
                })

            if self.require_confirmation and not confirmed:
                raise PermissionError(
                    f"工具 '{tool_name}' 属于危险操作，需要确认。"
                    f"请在 state 中设置 _confirmed_dangerous=True"
                )

            print(f"[DangerousTool] ⚠️ 危险工具已确认: {tool_name}")

        return handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]]
    ) -> ToolMessage:
        """异步包装工具调用"""
        tool_name = request.tool_call.get("name", "")

        if tool_name in self.dangerous_tools:
            confirmed = request.state.get("_confirmed_dangerous", False)

            with self._lock:
                self._dangerous_calls.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "confirmed": confirmed
                })

            if self.require_confirmation and not confirmed:
                raise PermissionError(
                    f"工具 '{tool_name}' 属于危险操作，需要确认。"
                    f"请在 state 中设置 _confirmed_dangerous=True"
                )

            print(f"[DangerousTool] ⚠️ 危险工具已确认: {tool_name}")

        return await handler(request)


class ToolLoggingMiddleware(AgentMiddleware):
    """
    工具日志中间件

    功能：记录所有工具调用
    """

    def __init__(self):
        self._tool_logs: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage]
    ) -> ToolMessage:
        """包装工具调用，记录日志"""
        tool_name = request.tool_call.get("name", "")
        tool_args = request.tool_call.get("args", {})
        start_time = time.time()

        print(f"[ToolLogging] 📞 调用工具: {tool_name}({tool_args})")

        try:
            result = handler(request)

            elapsed = time.time() - start_time
            with self._lock:
                self._tool_logs.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "args": tool_args,
                    "duration_ms": elapsed * 1000,
                    "status": "success"
                })

            print(f"[ToolLogging] ✅ 工具完成: {tool_name} ({elapsed*1000:.2f}ms)")
            return result

        except Exception as e:
            elapsed = time.time() - start_time
            with self._lock:
                self._tool_logs.append({
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "args": tool_args,
                    "duration_ms": elapsed * 1000,
                    "status": "error",
                    "error": str(e)
                })
            raise

    @property
    def logs(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._tool_logs)


# ========== 示例函数 ==========

async def tool_whitelist_example():
    """工具白名单示例"""
    print("=" * 60)
    print("示例 1: 工具白名单 (AgentMiddleware)")
    print("=" * 60)

    whitelist = ToolWhitelistMiddleware(
        allowed_tools={"search_web", "send_email"}
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web, send_email, delete_file],
        system_prompt="你是一个助手。",
        middleware=[whitelist],
        name="whitelist_agent"
    )

    # 允许的工具
    print("\n允许的工具 (search_web):")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索 Python")]})

    print(f"\n📊 白名单统计: {whitelist.get_stats()}")


async def tool_blacklist_example():
    """工具黑名单示例"""
    print("\n" + "=" * 60)
    print("示例 2: 工具黑名单")
    print("=" * 60)

    blacklist = ToolBlacklistMiddleware(
        blocked_tools={"delete_file", "execute_code"}
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web, send_email, delete_file, execute_code],
        system_prompt="你是一个助手。",
        middleware=[blacklist],
        name="blacklist_agent"
    )

    # 允许
    print("\n允许的工具 (search_web):")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索信息")]})


async def tool_quota_example():
    """工具配额示例"""
    print("\n" + "=" * 60)
    print("示例 3: 工具配额")
    print("=" * 60)

    quota = ToolQuotaMiddleware(
        tool_quotas={"search_web": 3},
        default_quota=5
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web],
        system_prompt="你是一个简洁的助手。",
        middleware=[quota],
        name="quota_agent"
    )

    # 使用配额
    for i in range(2):
        print(f"\n第 {i+1} 次搜索:")
        await agent.ainvoke({"messages": [HumanMessage(content="搜索信息")]})

    print(f"\n📊 使用报告: {quota.get_usage_report()}")


async def skill_access_example():
    """技能访问控制示例"""
    print("\n" + "=" * 60)
    print("示例 4: 技能访问控制")
    print("=" * 60)

    skill_access = SkillAccessMiddleware(
        tier_skills={
            "free": {"basic_chat", "simple_search"},
            "pro": {"basic_chat", "simple_search", "advanced_analysis", "code_generation"},
            "enterprise": {"*"}
        }
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[skill_access],
        name="skill_agent"
    )

    # 免费用户
    print("\n免费用户尝试高级分析:")
    await agent.ainvoke({
        "messages": [HumanMessage(content="进行深度分析")],
        "user_tier": "free"
    })

    # 专业用户
    print("\n专业用户尝试高级分析:")
    await agent.ainvoke({
        "messages": [HumanMessage(content="进行深度分析")],
        "user_tier": "pro"
    })


async def skill_rate_limit_example():
    """技能速率限制示例"""
    print("\n" + "=" * 60)
    print("示例 5: 技能速率限制")
    print("=" * 60)

    rate_limit = SkillRateLimitMiddleware(
        skill_limits={
            "code_generation": {"max_calls": 3, "window_seconds": 60}
        }
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[rate_limit],
        name="skill_rate_agent"
    )

    for i in range(2):
        print(f"\n第 {i+1} 次代码生成:")
        await agent.ainvoke({"messages": [HumanMessage(content="生成代码")]})


async def dangerous_tool_example():
    """危险工具示例"""
    print("\n" + "=" * 60)
    print("示例 6: 危险工具控制")
    print("=" * 60)

    dangerous = DangerousToolMiddleware(
        dangerous_tools={"delete_file", "execute_code"},
        require_confirmation=True
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web, delete_file, execute_code],
        system_prompt="你是一个助手。",
        middleware=[dangerous],
        name="dangerous_agent"
    )

    # 安全工具
    print("\n安全工具 (search_web):")
    await agent.ainvoke({"messages": [HumanMessage(content="搜索信息")]})


async def tool_logging_example():
    """工具日志示例"""
    print("\n" + "=" * 60)
    print("示例 7: 工具调用日志")
    print("=" * 60)

    tool_logger = ToolLoggingMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web, send_email],
        system_prompt="你是一个助手。",
        middleware=[tool_logger],
        name="logged_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="搜索 Python")]})

    print(f"\n📋 工具调用日志: {len(tool_logger.logs)} 条")


async def combined_filter_example():
    """组合过滤示例"""
    print("\n" + "=" * 60)
    print("示例 8: 组合工具和技能过滤")
    print("=" * 60)

    whitelist = ToolWhitelistMiddleware(
        allowed_tools={"search_web", "send_email", "query_database"}
    )
    quota = ToolQuotaMiddleware(
        tool_quotas={"search_web": 5, "query_database": 2}
    )
    skill_access = SkillAccessMiddleware()
    tool_logger = ToolLoggingMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_web, send_email, query_database],
        system_prompt="你是一个助手。",
        middleware=[whitelist, quota, skill_access, tool_logger],
        name="fully_filtered_agent"
    )

    await agent.ainvoke({
        "messages": [HumanMessage(content="搜索 Python 信息")],
        "user_tier": "pro"
    })

    print(f"\n📊 工具配额: {quota.get_usage_report()}")
    print(f"📊 技能统计: {skill_access.get_skill_stats()}")
    print(f"📋 工具日志: {len(tool_logger.logs)} 条")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🔧 工具和技能过滤中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await tool_whitelist_example()
    await tool_blacklist_example()
    await tool_quota_example()
    await skill_access_example()
    await skill_rate_limit_example()
    await dangerous_tool_example()
    await tool_logging_example()
    await combined_filter_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
