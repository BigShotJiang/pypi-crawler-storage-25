"""
中间件示例 04: 缓存和重试中间件
==============================

展示缓存、重试、容错相关的中间件，基于 AgentMiddleware。

运行方式:
    python -m sycommon.agent.examples.middleware.04_caching_retry
"""
import asyncio
import time
import hashlib
import threading
from typing import Any, Dict, List, Optional, Callable, Awaitable
from datetime import datetime
from langchain_core.messages import HumanMessage, AIMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse
)

from sycommon.agent import get_agent


# ========== 缓存中间件 ==========

class CacheMiddleware(AgentMiddleware):
    """
    缓存中间件

    功能：缓存相同的模型请求，避免重复计算
    """

    def __init__(
        self,
        enabled: bool = True,
        ttl: int = 300,  # 5分钟
        max_size: int = 1000
    ):
        self.enabled = enabled
        self.ttl = ttl
        self.max_size = max_size
        self._cache: Dict[str, tuple] = {}  # key -> (result, timestamp)
        self._hits = 0
        self._misses = 0
        self._lock = threading.Lock()

    def _generate_key(self, request: ModelRequest) -> str:
        """生成缓存键"""
        messages = request.state.get('messages', [])
        content = str([getattr(m, 'content', str(m)) for m in messages])
        return hashlib.md5(content.encode()).hexdigest()

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """包装模型调用，实现缓存"""
        if not self.enabled:
            return handler(request)

        cache_key = self._generate_key(request)

        with self._lock:
            # 检查缓存
            if cache_key in self._cache:
                cached_result, timestamp = self._cache[cache_key]
                if time.time() - timestamp < self.ttl:
                    self._hits += 1
                    print(f"[Cache] 🎯 缓存命中！")
                    return cached_result

            self._misses += 1

            # LRU 清理
            if len(self._cache) >= self.max_size:
                self._evict_oldest()

        print(f"[Cache] 💾 缓存未命中，执行...")

        result = handler(request)

        with self._lock:
            self._cache[cache_key] = (result, time.time())

        return result

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步包装模型调用"""
        if not self.enabled:
            return await handler(request)

        cache_key = self._generate_key(request)

        with self._lock:
            if cache_key in self._cache:
                cached_result, timestamp = self._cache[cache_key]
                if time.time() - timestamp < self.ttl:
                    self._hits += 1
                    print(f"[Cache] 🎯 缓存命中！")
                    return cached_result

            self._misses += 1

            if len(self._cache) >= self.max_size:
                self._evict_oldest()

        print(f"[Cache] 💾 缓存未命中，执行...")

        result = await handler(request)

        with self._lock:
            self._cache[cache_key] = (result, time.time())

        return result

    def _evict_oldest(self):
        """清理最旧的缓存"""
        if self._cache:
            oldest_key = min(self._cache.keys(), key=lambda k: self._cache[k][1])
            del self._cache[oldest_key]

    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self.hit_rate,
                "cache_size": len(self._cache),
                "max_size": self.max_size
            }

    def clear(self):
        with self._lock:
            self._cache.clear()
            self._hits = 0
            self._misses = 0


class SmartCacheMiddleware(AgentMiddleware):
    """
    智能缓存中间件

    功能：根据请求类型智能决定是否缓存
    使用 request.override() 在特定场景下修改请求
    """

    def __init__(
        self,
        cacheable_actions: Optional[List[str]] = None,
        ttl: int = 300
    ):
        self.cacheable_actions = cacheable_actions or ["read", "query", "search", "get"]
        self.ttl = ttl
        self._cache: Dict[str, tuple] = {}
        self._lock = threading.Lock()

    def _detect_action(self, request: ModelRequest) -> str:
        """检测操作类型"""
        messages = request.state.get("messages", [])
        if messages:
            content = getattr(messages[-1], "content", "").lower()
            if any(kw in content for kw in ["删除", "delete"]):
                return "delete"
            if any(kw in content for kw in ["修改", "update"]):
                return "update"
            if any(kw in content for kw in ["创建", "create"]):
                return "create"
        return "read"

    def _generate_key(self, request: ModelRequest) -> str:
        """生成缓存键"""
        messages = request.state.get('messages', [])
        content = str([getattr(m, 'content', str(m)) for m in messages])
        return hashlib.md5(content.encode()).hexdigest()

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        action = self._detect_action(request)

        if action not in self.cacheable_actions:
            print(f"[SmartCache] ⏭️ 操作 '{action}' 不缓存")
            return handler(request)

        cache_key = self._generate_key(request)

        with self._lock:
            if cache_key in self._cache:
                cached_result, timestamp = self._cache[cache_key]
                if time.time() - timestamp < self.ttl:
                    print(f"[SmartCache] 🎯 缓存命中 ({action})")
                    return cached_result

        result = handler(request)

        with self._lock:
            self._cache[cache_key] = (result, time.time())
            print(f"[SmartCache] 💾 已缓存 ({action})")

        return result


class SystemPromptCachingMiddleware(AgentMiddleware):
    """
    系统提示词缓存中间件

    功能：根据对话类型动态设置系统提示词
    使用 request.override() 修改 system_message
    """

    SYSTEM_PROMPTS = {
        "code": "你是一个专业的编程助手，擅长写清晰、高效的代码。",
        "translate": "你是一个专业的翻译助手，能够准确翻译各种语言。",
        "write": "你是一个专业的写作助手，擅长创作各类文章和文案。",
        "default": "你是一个助手。"
    }

    def __init__(self, ttl: int = 600):
        self.ttl = ttl
        self._prompt_cache: Dict[str, str] = {}
        self._lock = threading.Lock()

    def _detect_type(self, request: ModelRequest) -> str:
        """检测对话类型"""
        messages = request.messages
        if messages:
            content = getattr(messages[-1], "content", "").lower()
            if any(kw in content for kw in ["代码", "编程", "code", "function", "class"]):
                return "code"
            if any(kw in content for kw in ["翻译", "translate"]):
                return "translate"
            if any(kw in content for kw in ["写", "文章", "写作", "write", "article"]):
                return "write"
        return "default"

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """根据对话类型使用 override() 设置系统提示词"""
        from langchain_core.messages import SystemMessage

        conv_type = self._detect_type(request)
        system_prompt = self.SYSTEM_PROMPTS.get(conv_type, self.SYSTEM_PROMPTS["default"])

        print(f"[SystemPromptCaching] 🎨 对话类型: {conv_type}, 设置专用提示词")

        # 使用 override() 替换系统提示词
        new_request = request.override(
            system_message=SystemMessage(content=system_prompt)
        )

        return handler(new_request)


# ========== 重试中间件 ==========

class RetryMiddleware(AgentMiddleware):
    """
    重试中间件

    功能：自动重试失败的模型调用
    """

    def __init__(
        self,
        max_retries: int = 3,
        delay: float = 1.0,
        backoff: float = 2.0,
        retryable_exceptions: Optional[tuple] = None
    ):
        self.max_retries = max_retries
        self.delay = delay
        self.backoff = backoff
        self.retryable_exceptions = retryable_exceptions or (Exception,)
        self._retry_count = 0
        self._success_after_retry = 0

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """包装模型调用，实现重试"""
        delay = self.delay
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                if attempt > 0:
                    self._retry_count += 1
                    print(f"[Retry] 🔄 第 {attempt + 1} 次重试...")

                return handler(request)

            except self.retryable_exceptions as e:
                last_error = e
                if attempt < self.max_retries:
                    print(f"[Retry] ⚠️ 失败: {e}，{delay:.1f}秒后重试")
                    time.sleep(delay)
                    delay *= self.backoff
                else:
                    print(f"[Retry] ❌ 重试次数用尽")
                    raise

        raise last_error

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        """异步重试"""
        delay = self.delay
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                if attempt > 0:
                    self._retry_count += 1
                    print(f"[Retry] 🔄 第 {attempt + 1} 次重试...")

                return await handler(request)

            except self.retryable_exceptions as e:
                last_error = e
                if attempt < self.max_retries:
                    print(f"[Retry] ⚠️ 失败: {e}，{delay:.1f}秒后重试")
                    await asyncio.sleep(delay)
                    delay *= self.backoff
                else:
                    print(f"[Retry] ❌ 重试次数用尽")
                    raise

        raise last_error

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "total_retries": self._retry_count,
            "success_after_retry": self._success_after_retry
        }


class CircuitBreakerMiddleware(AgentMiddleware):
    """
    断路器中间件

    功能：在连续失败后熔断，防止雪崩
    """

    STATE_CLOSED = "closed"      # 正常
    STATE_OPEN = "open"          # 熔断
    STATE_HALF_OPEN = "half_open"  # 半开

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_requests: int = 3
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_requests = half_open_requests

        self._state = self.STATE_CLOSED
        self._failure_count = 0
        self._last_failure_time = 0
        self._half_open_success = 0
        self._lock = threading.Lock()

    def _get_state(self) -> str:
        now = time.time()

        if self._state == self.STATE_OPEN:
            if now - self._last_failure_time >= self.recovery_timeout:
                self._state = self.STATE_HALF_OPEN
                self._half_open_success = 0
                print(f"[CircuitBreaker] 🔵 转换到半开状态")

        return self._state

    def _on_success(self):
        self._failure_count = 0

        if self._state == self.STATE_HALF_OPEN:
            self._half_open_success += 1
            if self._half_open_success >= self.half_open_requests:
                self._state = self.STATE_CLOSED
                print(f"[CircuitBreaker] 🟢 恢复到关闭状态")

    def _on_failure(self):
        self._failure_count += 1
        self._last_failure_time = time.time()

        if self._state == self.STATE_HALF_OPEN:
            self._state = self.STATE_OPEN
            print(f"[CircuitBreaker] 🔴 半开测试失败，回到开启状态")

        elif self._failure_count >= self.failure_threshold:
            self._state = self.STATE_OPEN
            print(f"[CircuitBreaker] 🔴 失败次数达到阈值，进入开启状态")

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        with self._lock:
            current_state = self._get_state()

            if current_state == self.STATE_OPEN:
                raise RuntimeError("断路器处于开启状态，请求被拒绝")

            if current_state == self.STATE_HALF_OPEN:
                print(f"[CircuitBreaker] 🟡 半开状态，测试请求")

        try:
            result = handler(request)

            with self._lock:
                self._on_success()

            return result

        except Exception as e:
            with self._lock:
                self._on_failure()
            raise

    @property
    def state(self) -> str:
        with self._lock:
            return self._get_state()

    @property
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "state": self._get_state(),
                "failure_count": self._failure_count,
                "threshold": self.failure_threshold
            }


class FallbackMiddleware(AgentMiddleware):
    """
    降级中间件

    功能：在主逻辑失败时使用备用逻辑
    """

    def __init__(
        self,
        fallback_handler: Optional[Callable] = None,
        fallback_message: str = "服务暂时不可用，请稍后重试"
    ):
        self.fallback_handler = fallback_handler
        self.fallback_message = fallback_message
        self._fallback_count = 0

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        try:
            return handler(request)
        except Exception as e:
            self._fallback_count += 1
            print(f"[Fallback] ⚠️ 模型调用失败，启用降级: {e}")

            # 返回降级响应
            return ModelResponse(
                result=[AIMessage(content=self.fallback_message)]
            )

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        try:
            return await handler(request)
        except Exception as e:
            self._fallback_count += 1
            print(f"[Fallback] ⚠️ 模型调用失败，启用降级: {e}")

            if self.fallback_handler:
                return await self.fallback_handler(request, e)

            return ModelResponse(
                result=[AIMessage(content=self.fallback_message)]
            )

    @property
    def stats(self) -> Dict[str, int]:
        return {"fallback_count": self._fallback_count}


class TimeoutMiddleware(AgentMiddleware):
    """
    超时中间件

    功能：限制模型调用时间
    """

    def __init__(self, timeout_seconds: float = 30.0):
        self.timeout_seconds = timeout_seconds
        self._timeout_count = 0

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]]
    ) -> ModelResponse:
        try:
            async with asyncio.timeout(self.timeout_seconds):
                return await handler(request)
        except asyncio.TimeoutError:
            self._timeout_count += 1
            print(f"[Timeout] ⏰ 模型调用超时 ({self.timeout_seconds}秒)")
            raise RuntimeError(f"模型调用超时 ({self.timeout_seconds}秒)")

    @property
    def stats(self) -> Dict[str, int]:
        return {"timeout_count": self._timeout_count}


# ========== 示例函数 ==========

async def cache_example():
    """缓存中间件示例"""
    print("=" * 60)
    print("示例 1: 基础缓存 (AgentMiddleware)")
    print("=" * 60)

    cache = CacheMiddleware(ttl=60)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[cache],
        name="cache_agent"
    )

    # 第一次请求
    print("\n--- 第一次请求 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="什么是Python？")]})

    # 第二次相同请求
    print("\n--- 第二次相同请求 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="什么是Python？")]})

    print(f"\n📊 缓存统计: {cache.stats}")


async def smart_cache_example():
    """智能缓存示例"""
    print("\n" + "=" * 60)
    print("示例 2: 智能缓存")
    print("=" * 60)

    smart_cache = SmartCacheMiddleware(
        cacheable_actions=["read", "query", "search"]
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[smart_cache],
        name="smart_cache_agent"
    )

    # 查询操作（会缓存）
    print("\n--- 查询操作 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="查询数据")]})

    # 删除操作（不会缓存）
    print("\n--- 删除操作 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="删除数据")]})


async def retry_example():
    """重试中间件示例"""
    print("\n" + "=" * 60)
    print("示例 3: 重试中间件")
    print("=" * 60)

    retry = RetryMiddleware(max_retries=3, delay=0.5)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[retry],
        name="retry_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 重试统计: {retry.stats}")


async def circuit_breaker_example():
    """断路器示例"""
    print("\n" + "=" * 60)
    print("示例 4: 断路器中间件")
    print("=" * 60)

    circuit = CircuitBreakerMiddleware(
        failure_threshold=3,
        recovery_timeout=10
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[circuit],
        name="circuit_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 断路器状态: {circuit.stats}")


async def fallback_example():
    """降级示例"""
    print("\n" + "=" * 60)
    print("示例 5: 降级中间件")
    print("=" * 60)

    fallback = FallbackMiddleware(
        fallback_message="自定义降级响应：服务暂时不可用"
    )

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[fallback],
        name="fallback_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 降级统计: {fallback.stats}")


async def timeout_example():
    """超时示例"""
    print("\n" + "=" * 60)
    print("示例 6: 超时中间件")
    print("=" * 60)

    timeout = TimeoutMiddleware(timeout_seconds=60)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[timeout],
        name="timeout_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})

    print(f"\n📊 超时统计: {timeout.stats}")


async def combined_resilience_example():
    """组合容错示例"""
    print("\n" + "=" * 60)
    print("示例 7: 组合容错机制")
    print("=" * 60)

    cache = CacheMiddleware(ttl=60)
    retry = RetryMiddleware(max_retries=2)
    circuit = CircuitBreakerMiddleware()
    fallback = FallbackMiddleware()

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[cache, retry, circuit, fallback],
        name="resilient_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="测试")]})

    print(f"\n📊 综合统计:")
    print(f"  缓存: {cache.stats}")
    print(f"  断路器: {circuit.state}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("📦 缓存和重试中间件示例 (AgentMiddleware)")
    print("=" * 70)

    await cache_example()
    await smart_cache_example()
    await retry_example()
    await circuit_breaker_example()
    await fallback_example()
    await timeout_example()
    await combined_resilience_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
