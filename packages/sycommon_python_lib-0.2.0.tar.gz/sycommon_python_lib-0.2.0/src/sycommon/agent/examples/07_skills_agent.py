"""
示例 07: 技能系统
================

展示如何使用 skills 参数声明 Agent 的能力，让 Agent 知道自己能做什么。

运行方式:
    python -m sycommon.agent.examples.07_skills_agent
"""
import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool

from sycommon.agent import get_agent


# ========== 工具定义 ==========

@tool
def translate_text(text: str, target_language: str) -> str:
    """翻译文本到目标语言"""
    translations = {
        "en": {"你好": "Hello", "世界": "World", "谢谢": "Thank you"},
        "ja": {"你好": "こんにちは", "世界": "世界", "谢谢": "ありがとう"},
        "fr": {"你好": "Bonjour", "世界": "Monde", "谢谢": "Merci"}
    }
    lang = translations.get(target_language.lower(), {})
    result = lang.get(text, f"[{text} -> {target_language}]")
    return f"翻译结果: {result}"


@tool
def summarize_text(text: str) -> str:
    """总结文本"""
    return f"摘要: {text[:100]}... (原文 {len(text)} 字符，摘要 100 字符)"


@tool
def analyze_sentiment(text: str) -> str:
    """分析文本情感"""
    positive_words = ["好", "棒", "优秀", "喜欢", "满意"]
    negative_words = ["差", "糟", "失望", "讨厌", "不满"]

    score = 0
    for word in positive_words:
        if word in text:
            score += 1
    for word in negative_words:
        if word in text:
            score -= 1

    if score > 0:
        return f"情感分析: 正面 (得分: +{score})"
    elif score < 0:
        return f"情感分析: 负面 (得分: {score})"
    else:
        return "情感分析: 中性 (得分: 0)"


@tool
def extract_keywords(text: str) -> str:
    """提取关键词"""
    words = text.split()
    keywords = list(set(words))[:5]
    return f"关键词: {', '.join(keywords)}"


@tool
def count_words(text: str) -> str:
    """统计字数"""
    return f"字数统计: {len(text)} 字符, {len(text.split())} 单词"


# ========== 示例函数 ==========

async def basic_skills():
    """基础技能声明"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[translate_text, summarize_text, count_words],
        skills=[
            "translation: 翻译文本到多种语言",
            "summarization: 总结长文本",
            "word_count: 统计文本字数"
        ],
        system_prompt="""你是一个文本处理助手。

        你拥有以下技能：
        - translation: 翻译文本
        - summarization: 总结文本
        - word_count: 统计字数

        根据用户需求选择合适的技能。"""
    )

    print("=" * 50)
    print("基础技能声明")
    print("=" * 50)

    requests = [
        "把'你好世界'翻译成英语",
        "统计这段话的字数：人工智能正在改变世界",
    ]

    for req in requests:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=req)]}
        )
        print(f"\n用户: {req}")
        print(f"Agent: {result['messages'][-1].content}")


async def skill_combination():
    """技能组合"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[translate_text, summarize_text,
               analyze_sentiment, extract_keywords],
        skills=[
            "translation: 翻译文本到英语、日语、法语",
            "summarization: 总结文本主要内容",
            "sentiment_analysis: 分析文本情感倾向",
            "keyword_extraction: 提取文本关键词"
        ],
        system_prompt="""你是一个多功能文本分析助手。

        可以组合使用多个技能来完成复杂任务。"""
    )

    print("\n" + "=" * 50)
    print("技能组合")
    print("=" * 50)
    print("\n用户: 分析这段评论：'这个产品非常好用，我很喜欢！但价格有点贵。'")

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="分析这段评论：'这个产品非常好用，我很喜欢！但价格有点贵。' 分析情感并提取关键词")]}
    )

    print(f"Agent: {result['messages'][-1].content}")


async def skill_description():
    """详细的技能描述"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[translate_text],
        skills=[
            "translation_en: 将中文翻译成英语，保持原意和语气",
            "translation_ja: 将中文翻译成日语，使用敬语形式",
            "translation_fr: 将中文翻译成法语，保持优雅表达"
        ],
        system_prompt="""你是翻译专家，精通多种语言。

        每种语言的翻译有不同特点：
        - 英语：直接准确
        - 日语：礼貌得体
        - 法语：优雅自然

        根据目标语言选择合适的翻译风格。"""
    )

    print("\n" + "=" * 50)
    print("详细的技能描述")
    print("=" * 50)

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="把'谢谢'分别翻译成英语、日语和法语")]}
    )

    print(f"用户: 把'谢谢'分别翻译成英语、日语和法语")
    print(f"Agent: {result['messages'][-1].content}")


async def skill_with_tools():
    """技能 + 工具对应"""
    @tool
    def search_product(product_name: str) -> str:
        """搜索产品信息"""
        return f"找到产品: {product_name}, 价格: ¥299, 评分: 4.5"

    @tool
    def compare_products(product1: str, product2: str) -> str:
        """比较两个产品"""
        return f"比较 {product1} 和 {product2}: 功能相似，{product1} 价格更低"

    @tool
    def recommend_product(category: str) -> str:
        """推荐产品"""
        return f"推荐 {category} 类别最佳产品: SuperX 2000"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_product, compare_products, recommend_product],
        skills=[
            "product_search: 搜索和查找产品信息",
            "product_comparison: 比较不同产品的优缺点",
            "product_recommendation: 根据需求推荐最适合的产品"
        ],
        system_prompt="""你是购物助手，帮助用户找到合适的产品。

        技能说明：
        - product_search: 当用户想了解某个产品时使用
        - product_comparison: 当用户在多个产品间犹豫时使用
        - product_recommendation: 当用户不确定要买什么时使用

        根据用户意图选择合适的技能。"""
    )

    print("\n" + "=" * 50)
    print("技能 + 工具对应")
    print("=" * 50)

    questions = [
        "帮我查一下 iPhone 的信息",
        "iPhone 和 Samsung 哪个好？",
        "推荐一款性价比高的手机"
    ]

    for q in questions:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=q)]}
        )
        print(f"\n用户: {q}")
        print(f"Agent: {result['messages'][-1].content[:150]}...")


async def domain_skills():
    """领域专业技能"""
    @tool
    def diagnose_symptoms(symptoms: str) -> str:
        """诊断症状（模拟）"""
        return f"症状分析: {symptoms} -> 可能原因: 普通感冒, 建议: 多休息"

    @tool
    def check_drug_interaction(drugs: str) -> str:
        """检查药物相互作用"""
        return f"药物检查: {drugs} -> 无明显相互作用"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[diagnose_symptoms, check_drug_interaction],
        skills=[
            "symptom_diagnosis: 根据症状进行初步诊断",
            "drug_safety: 检查药物相互作用和安全用药建议",
            "health_consultation: 提供一般健康咨询"
        ],
        system_prompt="""你是健康咨询助手（非医生）。

        你可以：
        - 分析症状并给出初步判断
        - 检查药物相互作用
        - 提供健康建议

        重要：对于严重问题，建议就医。"""
    )

    print("\n" + "=" * 50)
    print("领域专业技能")
    print("=" * 50)

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="我头疼、发烧，可能是什么原因？")]}
    )

    print(f"用户: 我头疼、发烧，可能是什么原因？")
    print(f"Agent: {result['messages'][-1].content}")


async def skill_levels():
    """技能等级"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[translate_text],
        skills=[
            "basic_translation [level:1]: 简单句子翻译",
            "advanced_translation [level:2]: 复杂文本翻译，保持风格",
            "expert_translation [level:3]: 专业领域翻译，术语准确"
        ],
        system_prompt="""你是翻译专家，有不同级别的翻译能力。

        级别说明：
        - Level 1: 日常简单翻译
        - Level 2: 文学、商务翻译
        - Level 3: 法律、医疗等专业翻译

        根据文本难度选择合适的级别。"""
    )

    print("\n" + "=" * 50)
    print("技能等级")
    print("=" * 50)

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="翻译：'The contract shall be governed by the laws of the State of New York.'")]}
    )

    print(f"用户: 翻译法律条款")
    print(f"Agent: {result['messages'][-1].content}")


async def skill_documentation():
    """技能文档化"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[summarize_text, analyze_sentiment,
               extract_keywords, count_words],
        skills=[
            """text_analysis:
              描述: 全面的文本分析
              功能:
                - 情感分析: 判断正面/负面/中性
                - 关键词提取: 提取核心词汇
                - 字数统计: 准确计数
              输入: 任意文本
              输出: 结构化分析报告""",
            """text_summarization:
              描述: 智能文本摘要
              功能:
                - 提取主要观点
                - 保持核心信息
              输入: 长文本
              输出: 简洁摘要"""
        ],
        system_prompt="""你是文本分析专家，提供全面的文本分析服务。

        使用合适的技能组合满足用户需求。"""
    )

    print("\n" + "=" * 50)
    print("技能文档化")
    print("=" * 50)

    text = "这个产品太棒了！功能强大，价格合理，客服也很专业。强烈推荐！"
    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"全面分析这段文本: {text}")]}
    )

    print(f"用户: 全面分析文本")
    print(f"Agent: {result['messages'][-1].content}")


async def conditional_skills():
    """条件技能"""
    @tool
    def quick_search(query: str) -> str:
        """快速搜索"""
        return f"[快速] {query}: 结果 A, B, C"

    @tool
    def deep_search(query: str) -> str:
        """深度搜索"""
        return f"[深度] {query}: 详细结果包含 A, B, C, D, E 及相关分析"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[quick_search, deep_search],
        skills=[
            "quick_search: 快速获取简要结果，适合简单查询",
            "deep_search: 深度分析全面结果，适合复杂研究"
        ],
        system_prompt="""你是搜索助手。

        根据查询复杂度选择：
        - 简单问题 -> quick_search
        - 复杂问题 -> deep_search

        判断标准：
        - 是否需要详细分析？
        - 是否涉及多个方面？
        - 用户是否需要深入了解？"""
    )

    print("\n" + "=" * 50)
    print("条件技能")
    print("=" * 50)

    queries = [
        "什么是 Python",
        "深入分析 Python 在机器学习领域的应用、优势和未来趋势"
    ]

    for q in queries:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=q)]}
        )
        print(f"\n用户: {q}")
        print(f"Agent: {result['messages'][-1].content[:150]}...")


async def main():
    """运行所有技能系统示例"""
    print("\n" + "=" * 60)
    print("示例 7.1: 基础技能声明")
    print("=" * 60)
    await basic_skills()

    print("\n" + "=" * 60)
    print("示例 7.2: 技能组合")
    print("=" * 60)
    await skill_combination()

    print("\n" + "=" * 60)
    print("示例 7.3: 详细的技能描述")
    print("=" * 60)
    await skill_description()

    print("\n" + "=" * 60)
    print("示例 7.4: 技能 + 工具对应")
    print("=" * 60)
    await skill_with_tools()

    print("\n" + "=" * 60)
    print("示例 7.5: 领域专业技能")
    print("=" * 60)
    await domain_skills()

    print("\n" + "=" * 60)
    print("示例 7.6: 技能等级")
    print("=" * 60)
    await skill_levels()

    print("\n" + "=" * 60)
    print("示例 7.7: 技能文档化")
    print("=" * 60)
    await skill_documentation()

    print("\n" + "=" * 60)
    print("示例 7.8: 条件技能")
    print("=" * 60)
    await conditional_skills()


if __name__ == "__main__":
    asyncio.run(main())
