"""
示例 08: 中间件和调试
====================

展示如何使用中间件监控、控制 Agent 执行过程。

注意：更多中间件示例请查看 middleware 子目录：
    - middleware/01_basic_monitoring.py  - 基础监控（计时、日志、指标、追踪）
    - middleware/02_permission_control.py - 权限控制（RBAC、认证、IP白名单）
    - middleware/03_tool_skill_filter.py  - 工具和技能过滤
    - middleware/04_caching_retry.py      - 缓存和重试（缓存、重试、断路器）
    - middleware/05_sanitization.py       - 数据清洗（输入清洗、输出清洗）
    - middleware/06_tracking.py           - 追踪审计（审计日志、成本追踪）
    - middleware/07_advanced.py           - 高级功能（A/B测试、配额、会话）

运行方式:
    python -m sycommon.agent.examples.08_middleware
"""
import asyncio
from typing import Any, Dict, Callable
from langchain_core.messages import HumanMessage
from langchain.agents.middleware.types import (
    AgentMiddleware, ModelRequest, ModelResponse
)

from sycommon.agent import get_agent


# ========== 简单中间件示例 ==========

class SimpleTimingMiddleware(AgentMiddleware):
    """
    简单计时中间件

    功能：测量 Agent 执行耗时
    """

    def __init__(self, name: str = "Timer"):
        self.name = name
        self._call_count = 0

    def before_agent(self, state, _runtime) -> dict[str, Any] | None:
        """Agent 执行前"""
        import time
        state["_start_time"] = time.time()
        print(f"[{self.name}] ⏱️ 开始执行...")
        return None

    def after_agent(self, state, _runtime) -> dict[str, Any] | None:
        """Agent 执行后"""
        import time
        start = state.get("_start_time", time.time())
        elapsed = time.time() - start
        self._call_count += 1
        print(f"[{self.name}] ⏱️ 执行完成 - 耗时: {elapsed:.3f}秒 (第{self._call_count}次)")
        return None


class SimpleLoggingMiddleware(AgentMiddleware):
    """
    简单日志中间件

    功能：记录执行日志
    """

    def __init__(self, name: str = "Logger"):
        self.name = name

    def before_agent(self, state, runtime) -> dict[str, Any] | None:
        """Agent 执行前"""
        msg_count = len(state.get('messages', []))
        print(f"[{self.name}] 📝 执行前 - 消息数: {msg_count}")
        return None

    def after_agent(self, state, runtime) -> dict[str, Any] | None:
        """Agent 执行后"""
        msg_count = len(state.get('messages', []))
        print(f"[{self.name}] 📝 执行后 - 消息数: {msg_count}")
        return None


class SimpleRetryMiddleware(AgentMiddleware):
    """
    简单重试中间件

    功能：自动重试失败的模型调用
    """

    def __init__(self, max_retries: int = 3, delay: float = 1.0):
        self.max_retries = max_retries
        self.delay = delay
        self._retry_count = 0

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """包装模型调用，实现重试"""
        import time
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                if attempt > 0:
                    self._retry_count += 1
                    print(f"[Retry] 🔄 第 {attempt + 1} 次重试...")
                    time.sleep(self.delay)

                return handler(request)

            except Exception as e:
                last_error = e
                if attempt >= self.max_retries:
                    print(f"[Retry] ❌ 重试次数用尽")
                    raise

        raise last_error

    @property
    def stats(self) -> dict:
        return {"total_retries": self._retry_count}


class SimpleCacheMiddleware(AgentMiddleware):
    """
    简单缓存中间件

    功能：缓存模型调用结果
    """

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._cache: Dict[str, ModelResponse] = {}
        self._hits = 0
        self._misses = 0

    def _get_cache_key(self, request: ModelRequest) -> str:
        """生成缓存键"""
        import hashlib
        messages = request.state.get('messages', [])
        content = str([getattr(m, 'content', str(m)) for m in messages])
        return hashlib.md5(content.encode()).hexdigest()

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse]
    ) -> ModelResponse:
        """包装模型调用，实现缓存"""
        if not self.enabled:
            return handler(request)

        cache_key = self._get_cache_key(request)

        if cache_key in self._cache:
            self._hits += 1
            print(f"[Cache] 🎯 缓存命中！")
            return self._cache[cache_key]

        self._misses += 1
        print(f"[Cache] 💾 缓存未命中，执行...")

        result = handler(request)
        self._cache[cache_key] = result
        return result

    @property
    def stats(self) -> dict:
        total = self._hits + self._misses
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self._hits / total if total > 0 else 0.0
        }


# ========== 示例函数 ==========

async def basic_middleware_example():
    """基础中间件示例"""
    print("=" * 60)
    print("示例 1: 基础中间件使用")
    print("=" * 60)

    timer = SimpleTimingMiddleware("执行计时器")
    logger = SimpleLoggingMiddleware("执行日志器")

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。",
        middleware=[timer, logger],
        name="basic_middleware_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})


async def retry_middleware_example():
    """重试中间件示例"""
    print("\n" + "=" * 60)
    print("示例 2: 重试中间件")
    print("=" * 60)

    retry = SimpleRetryMiddleware(max_retries=3, delay=0.5)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[retry],
        name="retry_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="你好")]})
    print(f"\n📊 重试统计: {retry.stats}")


async def cache_middleware_example():
    """缓存中间件示例"""
    print("\n" + "=" * 60)
    print("示例 3: 缓存中间件")
    print("=" * 60)

    cache = SimpleCacheMiddleware(enabled=True)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[cache],
        name="cache_agent"
    )

    # 第一次请求
    print("\n--- 第一次请求 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="什么是Python？")]})

    # 第二次相同请求
    print("\n--- 第二次相同请求 ---")
    await agent.ainvoke({"messages": [HumanMessage(content="什么是Python？")]})

    print(f"\n📊 缓存统计: {cache.stats}")


async def combined_middleware_example():
    """组合中间件示例"""
    print("\n" + "=" * 60)
    print("示例 4: 组合多个中间件")
    print("=" * 60)

    timer = SimpleTimingMiddleware("总计时")
    logger = SimpleLoggingMiddleware("执行日志")
    cache = SimpleCacheMiddleware()
    retry = SimpleRetryMiddleware(max_retries=2)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        middleware=[timer, logger, cache, retry],
        name="combined_middleware_agent"
    )

    await agent.ainvoke({"messages": [HumanMessage(content="综合测试")]})

    print(f"\n📊 综合统计:")
    print(f"  缓存: {cache.stats}")
    print(f"  重试: {retry.stats}")


async def main():
    """运行所有示例"""
    print("\n" + "=" * 70)
    print("🔧 中间件和调试示例")
    print("=" * 70)

    print("\n💡 更多中间件示例请查看 middleware 子目录:")
    print("   - 01_basic_monitoring.py  - 基础监控")
    print("   - 02_permission_control.py - 权限控制")
    print("   - 03_tool_skill_filter.py  - 工具和技能过滤")
    print("   - 04_caching_retry.py      - 缓存和重试")
    print("   - 05_sanitization.py       - 数据清洗")
    print("   - 06_tracking.py           - 追踪审计")
    print("   - 07_advanced.py           - 高级功能")

    await basic_middleware_example()
    await retry_middleware_example()
    await cache_middleware_example()
    await combined_middleware_example()

    print("\n" + "=" * 70)
    print("✅ 所有示例完成")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
