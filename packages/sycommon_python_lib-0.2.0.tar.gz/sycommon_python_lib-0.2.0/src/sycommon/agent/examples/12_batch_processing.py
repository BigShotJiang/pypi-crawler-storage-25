"""
示例 12: 批量处理
================

展示如何使用并发和批量处理提高 Agent 处理效率。

运行方式:
    python -m sycommon.agent.examples.12_batch_processing
"""
import asyncio
import time
from typing import List, Dict, Any
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool

from sycommon.agent import get_agent


# ========== 工具定义 ==========

@tool
def process_item(item_id: str) -> str:
    """处理单个项目"""
    return f"项目 {item_id} 处理完成"


@tool
def get_status(item_id: str) -> str:
    """获取状态"""
    return f"项目 {item_id}: 状态正常"


# ========== Schema 定义 ==========

class BatchResult(BaseModel):
    """批量处理结果"""
    total: int = Field(description="总数")
    success: int = Field(description="成功数")
    failed: int = Field(description="失败数")
    results: List[str] = Field(description="结果列表")


# ========== 示例函数 ==========

async def basic_batch():
    """基础批量处理"""
    print("=" * 50)
    print("基础批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个文本分类器，将文本分类为：正面、负面、中性。"
    )

    texts = [
        "这个产品非常好用！",
        "质量太差了，不满意",
        "一般般，没什么特别的",
        "客服态度很好",
        "物流太慢了",
        "性价比不错"
    ]

    print(f"\n处理 {len(texts)} 条文本...")

    start_time = time.time()

    # 串行处理
    results = []
    for text in texts:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=f"分类：{text}")]}
        )
        results.append(result["messages"][-1].content)

    elapsed = time.time() - start_time

    print("\n结果:")
    for text, result in zip(texts, results):
        print(f"  '{text}' -> {result}")

    print(f"\n串行处理耗时: {elapsed:.2f}秒")


async def concurrent_batch():
    """并发批量处理"""
    print("\n" + "=" * 50)
    print("并发批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个文本分类器，将文本分类为：正面、负面、中性。只输出分类结果。"
    )

    texts = [
        "这个产品非常好用！",
        "质量太差了，不满意",
        "一般般，没什么特别的",
        "客服态度很好",
        "物流太慢了",
        "性价比不错"
    ]

    print(f"\n并发处理 {len(texts)} 条文本...")

    start_time = time.time()

    # 并发处理
    tasks = [
        agent.ainvoke({
            "messages": [HumanMessage(content=f"分类：{text}")]}
        )
        for text in texts
    ]

    results = await asyncio.gather(*tasks)

    elapsed = time.time() - start_time

    print("\n结果:")
    for text, result in zip(texts, results):
        print(f"  '{text}' -> {result['messages'][-1].content}")

    print(f"\n并发处理耗时: {elapsed:.2f}秒")


async def batch_with_semaphore():
    """带信号量限制的批量处理"""
    print("\n" + "=" * 50)
    print("带并发限制的批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。"
    )

    items = [f"任务{i+1}" for i in range(10)]

    # 限制并发数为 3
    semaphore = asyncio.Semaphore(3)

    async def process_with_limit(item: str) -> str:
        async with semaphore:
            result = await agent.ainvoke({
                "messages": [HumanMessage(content=f"处理: {item}")]}
            )
            return result["messages"][-1].content

    print(f"\n处理 {len(items)} 个任务（并发限制：3）...")

    start_time = time.time()

    tasks = [process_with_limit(item) for item in items]
    results = await asyncio.gather(*tasks)

    elapsed = time.time() - start_time

    print(f"\n完成 {len(results)} 个任务")
    print(f"耗时: {elapsed:.2f}秒")


async def batch_with_progress():
    """带进度的批量处理"""
    print("\n" + "=" * 50)
    print("带进度的批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手。"
    )

    items = [f"项目{i+1}" for i in range(5)]

    completed = 0
    total = len(items)

    async def process_with_progress(item: str) -> str:
        nonlocal completed
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=f"处理: {item}")]}
        )
        completed += 1
        progress = (completed / total) * 100
        print(f"  进度: {completed}/{total} ({progress:.0f}%) - 完成 {item}")
        return result["messages"][-1].content

    print(f"\n处理 {total} 个项目...")

    tasks = [process_with_progress(item) for item in items]
    results = await asyncio.gather(*tasks)

    print(f"\n全部完成！")


async def batch_with_error_handling():
    """带错误处理的批量处理"""
    print("\n" + "=" * 50)
    print("带错误处理的批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。"
    )

    items = ["正常1", "正常2", "正常3", "正常4", "正常5"]

    async def process_safe(item: str) -> Dict[str, Any]:
        try:
            result = await agent.ainvoke({
                "messages": [HumanMessage(content=f"处理: {item}")]}
            )
            return {"item": item, "status": "success", "result": result["messages"][-1].content}
        except Exception as e:
            return {"item": item, "status": "failed", "error": str(e)}

    print(f"\n处理 {len(items)} 个项目（带错误处理）...")

    tasks = [process_safe(item) for item in items]
    results = await asyncio.gather(*tasks)

    success_count = sum(1 for r in results if r["status"] == "success")
    failed_count = sum(1 for r in results if r["status"] == "failed")

    print(f"\n结果统计:")
    print(f"  成功: {success_count}")
    print(f"  失败: {failed_count}")


async def batch_with_timeout():
    """带超时的批量处理"""
    print("\n" + "=" * 50)
    print("带超时的批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        timeout=10,  # 单个任务超时
        system_prompt="你是一个助手。"
    )

    items = ["任务1", "任务2", "任务3"]

    async def process_with_timeout(item: str) -> Dict[str, Any]:
        try:
            async with asyncio.timeout(15):  # 整体超时
                result = await agent.ainvoke({
                    "messages": [HumanMessage(content=f"处理: {item}")]}
                )
                return {"item": item, "status": "success", "result": result["messages"][-1].content}
        except asyncio.TimeoutError:
            return {"item": item, "status": "timeout"}
        except Exception as e:
            return {"item": item, "status": "error", "error": str(e)}

    print(f"\n处理 {len(items)} 个项目（带超时）...")

    tasks = [process_with_timeout(item) for item in items]
    results = await asyncio.gather(*tasks)

    for r in results:
        print(f"  {r['item']}: {r['status']}")


async def batch_chunks():
    """分块批量处理"""
    print("\n" + "=" * 50)
    print("分块批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手，可以一次处理多个项目。"
    )

    items = [f"项目{i+1}" for i in range(20)]
    chunk_size = 5

    print(f"\n将 {len(items)} 个项目分成 {chunk_size} 个一组处理...")

    results = []

    for i in range(0, len(items), chunk_size):
        chunk = items[i:i + chunk_size]
        print(f"\n处理第 {i//chunk_size + 1} 块: {chunk}")

        # 将整块作为一个请求处理
        chunk_text = ", ".join(chunk)
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=f"处理以下项目: {chunk_text}")]}
        )
        results.append(result["messages"][-1].content)

    print(f"\n处理完成，共 {len(results)} 个块")


async def batch_with_retry():
    """带重试的批量处理"""
    print("\n" + "=" * 50)
    print("带重试的批量处理")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        max_retries=3,  # 自动重试
        system_prompt="你是一个助手。"
    )

    items = ["任务A", "任务B", "任务C"]

    async def process_with_retry(item: str, max_attempts: int = 3) -> Dict[str, Any]:
        for attempt in range(max_attempts):
            try:
                result = await agent.ainvoke({
                    "messages": [HumanMessage(content=f"处理: {item}")]}
                )
                return {"item": item, "status": "success", "attempts": attempt + 1}
            except Exception as e:
                if attempt == max_attempts - 1:
                    return {"item": item, "status": "failed", "error": str(e)}
                await asyncio.sleep(1)  # 等待后重试

    print(f"\n处理 {len(items)} 个项目（最多重试3次）...")

    tasks = [process_with_retry(item) for item in items]
    results = await asyncio.gather(*tasks)

    for r in results:
        print(f"  {r['item']}: {r['status']} (尝试次数: {r.get('attempts', 'N/A')})")


async def batch_structured_output():
    """批量结构化输出"""
    print("\n" + "=" * 50)
    print("批量结构化输出")
    print("=" * 50)

    class ItemResult(BaseModel):
        """单个结果"""
        item: str = Field(description="项目名")
        category: str = Field(description="分类")
        score: int = Field(description="评分1-5")

    class BatchOutput(BaseModel):
        """批量输出"""
        results: List[ItemResult] = Field(description="结果列表")
        summary: str = Field(description="总结")

    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=BatchOutput,
        system_prompt="你是分类助手，处理多个项目并返回结构化结果。"
    )

    items = ["苹果", "香蕉", "橙子", "葡萄", "西瓜"]

    print(f"\n处理 {len(items)} 个水果...")

    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"对以下水果进行分类和评分(1-5): {', '.join(items)}")]}
    )

    print(f"\n结构化输出:\n{result['messages'][-1].content}")


async def batch_comparison():
    """串行 vs 并发对比"""
    print("\n" + "=" * 50)
    print("串行 vs 并发对比")
    print("=" * 50)

    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个简洁的助手，回答要短。"
    )

    questions = [f"问题{i+1}" for i in range(5)]

    # 串行
    print("\n串行处理...")
    start = time.time()
    for q in questions:
        await agent.ainvoke({"messages": [HumanMessage(content=q)]})
    serial_time = time.time() - start
    print(f"串行耗时: {serial_time:.2f}秒")

    # 并发
    print("\n并发处理...")
    start = time.time()
    tasks = [agent.ainvoke({"messages": [HumanMessage(content=q)]}) for q in questions]
    await asyncio.gather(*tasks)
    concurrent_time = time.time() - start
    print(f"并发耗时: {concurrent_time:.2f}秒")

    print(f"\n性能提升: {serial_time/concurrent_time:.1f}x")


async def main():
    """运行所有批量处理示例"""
    print("\n" + "=" * 60)
    print("示例 12.1: 基础批量处理（串行）")
    print("=" * 60)
    await basic_batch()

    print("\n" + "=" * 60)
    print("示例 12.2: 并发批量处理")
    print("=" * 60)
    await concurrent_batch()

    print("\n" + "=" * 60)
    print("示例 12.3: 带并发限制的批量处理")
    print("=" * 60)
    await batch_with_semaphore()

    print("\n" + "=" * 60)
    print("示例 12.4: 带进度的批量处理")
    print("=" * 60)
    await batch_with_progress()

    print("\n" + "=" * 60)
    print("示例 12.5: 带错误处理的批量处理")
    print("=" * 60)
    await batch_with_error_handling()

    print("\n" + "=" * 60)
    print("示例 12.6: 带超时的批量处理")
    print("=" * 60)
    await batch_with_timeout()

    print("\n" + "=" * 60)
    print("示例 12.7: 分块批量处理")
    print("=" * 60)
    await batch_chunks()

    print("\n" + "=" * 60)
    print("示例 12.8: 带重试的批量处理")
    print("=" * 60)
    await batch_with_retry()

    print("\n" + "=" * 60)
    print("示例 12.9: 批量结构化输出")
    print("=" * 60)
    await batch_structured_output()

    print("\n" + "=" * 60)
    print("示例 12.10: 串行 vs 并发对比")
    print("=" * 60)
    await batch_comparison()


if __name__ == "__main__":
    asyncio.run(main())
