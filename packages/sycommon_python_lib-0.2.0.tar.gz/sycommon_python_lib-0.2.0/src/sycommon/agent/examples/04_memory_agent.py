"""
示例 04: 记忆和上下文
====================

展示如何让 Agent 拥有记忆能力，记住之前的对话内容。

运行方式:
    python -m sycommon.agent.examples.04_memory_agent
"""
import asyncio
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import MemorySaver

from sycommon.agent import get_agent


# ========== 示例函数 ==========

async def basic_memory():
    """基础记忆功能 - 使用 MemorySaver"""
    # 创建带记忆的 Agent
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个有记忆的助手，能记住之前对话的内容。",
        checkpointer=MemorySaver(),  # 使用内存存储检查点
        name="memory_agent"
    )

    # 使用相同的 thread_id 来保持对话连续性
    thread_id = "user_001"
    config = {"configurable": {"thread_id": thread_id}}

    print("=" * 50)
    print("开始多轮对话（有记忆）")
    print("=" * 50)

    # 第一轮：告诉 Agent 你的名字
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="你好，我叫小明，我喜欢打篮球")]},
        config=config
    )
    print(f"\n用户: 你好，我叫小明，我喜欢打篮球")
    print(f"Agent: {result1['messages'][-1].content}")

    # 第二轮：问 Agent 是否记得你的名字
    result2 = await agent.ainvoke(
        {"messages": [HumanMessage(content="你还记得我叫什么吗？")]},
        config=config
    )
    print(f"\n用户: 你还记得我叫什么吗？")
    print(f"Agent: {result2['messages'][-1].content}")

    # 第三轮：问 Agent 你的爱好
    result3 = await agent.ainvoke(
        {"messages": [HumanMessage(content="我有什么爱好？")]},
        config=config
    )
    print(f"\n用户: 我有什么爱好？")
    print(f"Agent: {result3['messages'][-1].content}")


async def different_sessions():
    """不同会话隔离"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个有记忆的助手。",
        checkpointer=MemorySaver(),
        name="session_agent"
    )

    print("\n" + "=" * 50)
    print("不同会话隔离测试")
    print("=" * 50)

    # 会话 A
    config_a = {"configurable": {"thread_id": "session_a"}}
    await agent.ainvoke(
        {"messages": [HumanMessage(content="我是用户A，我喜欢蓝色")]},
        config=config_a
    )

    # 会话 B
    config_b = {"configurable": {"thread_id": "session_b"}}
    await agent.ainvoke(
        {"messages": [HumanMessage(content="我是用户B，我喜欢红色")]},
        config=config_b
    )

    # 在会话 A 中询问
    result_a = await agent.ainvoke(
        {"messages": [HumanMessage(content="我喜欢什么颜色？")]},
        config=config_a
    )
    print(f"\n会话A用户: 我喜欢什么颜色？")
    print(f"Agent: {result_a['messages'][-1].content}")

    # 在会话 B 中询问
    result_b = await agent.ainvoke(
        {"messages": [HumanMessage(content="我喜欢什么颜色？")]},
        config=config_b
    )
    print(f"\n会话B用户: 我喜欢什么颜色？")
    print(f"Agent: {result_b['messages'][-1].content}")


async def check_state():
    """检查和恢复对话状态"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个有记忆的助手。",
        checkpointer=MemorySaver(),
        name="state_agent"
    )

    thread_id = "state_check_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("对话状态检查")
    print("=" * 50)

    # 进行对话
    await agent.ainvoke(
        {"messages": [HumanMessage(content="我的项目代号是 Alpha")]},
        config=config
    )

    # 检查当前状态
    state = await agent.aget_state(config)
    print(f"\n当前对话状态:")
    print(f"- 消息数量: {len(state.values.get('messages', []))}")
    print(f"- 下一步: {state.next}")

    # 继续对话
    await agent.ainvoke(
        {"messages": [HumanMessage(content="项目代号是什么？")]},
        config=config
    )

    # 再次检查状态
    state = await agent.aget_state(config)
    print(f"\n对话后状态:")
    print(f"- 消息数量: {len(state.values.get('messages', []))}")


async def conversation_summary():
    """对话摘要（长对话场景）"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个项目助手，记住所有项目相关的信息。",
        checkpointer=MemorySaver(),
        memory=["conversation"],  # 启用对话记忆
        name="project_agent"
    )

    thread_id = "project_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("项目信息对话")
    print("=" * 50)

    # 模拟项目讨论
    messages = [
        "我们项目名称是 SmartHome",
        "项目预算是 50 万",
        "项目周期是 3 个月",
        "团队有 5 个人",
        "技术栈使用 Python 和 React"
    ]

    for msg in messages:
        await agent.ainvoke(
            {"messages": [HumanMessage(content=msg)]},
            config=config
        )
        print(f"用户: {msg}")

    # 让 Agent 总结项目信息
    result = await agent.ainvoke(
        {"messages": [HumanMessage(content="请总结一下我们讨论的项目信息")]},
        config=config
    )
    print(f"\n用户: 请总结一下我们讨论的项目信息")
    print(f"Agent: {result['messages'][-1].content}")


async def memory_with_tools():
    """带工具的记忆 Agent"""
    from langchain_core.tools import tool

    @tool
    def save_note(content: str) -> str:
        """保存笔记"""
        return f"已保存笔记: {content[:50]}..."

    @tool
    def search_notes(keyword: str) -> str:
        """搜索笔记"""
        # 模拟搜索
        return f"找到与 '{keyword}' 相关的笔记"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[save_note, search_notes],
        system_prompt="你是一个笔记助手，帮助用户管理和搜索笔记。",
        checkpointer=MemorySaver(),
        name="note_agent"
    )

    thread_id = "note_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("笔记助手（带记忆）")
    print("=" * 50)

    # 保存笔记
    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="保存一条笔记：明天下午3点开会")]},
        config=config
    )
    print(f"\n用户: 保存一条笔记：明天下午3点开会")
    print(f"Agent: {result1['messages'][-1].content}")

    # 询问之前保存的内容
    result2 = await agent.ainvoke(
        {"messages": [HumanMessage(content="我刚才保存了什么笔记？")]},
        config=config
    )
    print(f"\n用户: 我刚才保存了什么笔记？")
    print(f"Agent: {result2['messages'][-1].content}")


async def replay_conversation():
    """重放对话历史"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        checkpointer=MemorySaver(),
        name="replay_agent"
    )

    thread_id = "replay_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("对话历史重放")
    print("=" * 50)

    # 进行多轮对话
    for i in range(3):
        await agent.ainvoke(
            {"messages": [HumanMessage(content=f"这是第 {i+1} 条消息")]},
            config=config
        )

    # 获取完整的对话历史
    state = await agent.aget_state(config)
    messages = state.values.get("messages", [])

    print(f"\n对话历史（共 {len(messages)} 条消息）:")
    for i, msg in enumerate(messages):
        msg_type = type(msg).__name__
        content = msg.content[:50] if hasattr(msg, 'content') else str(msg)[:50]
        print(f"  {i+1}. [{msg_type}] {content}...")


async def clear_conversation():
    """清除对话历史"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个助手。",
        checkpointer=MemorySaver(),
        name="clear_agent"
    )

    thread_id = "clear_session"
    config = {"configurable": {"thread_id": thread_id}}

    print("\n" + "=" * 50)
    print("清除对话历史")
    print("=" * 50)

    # 进行对话
    await agent.ainvoke(
        {"messages": [HumanMessage(content="记住我的名字是小明")]},
        config=config
    )

    result1 = await agent.ainvoke(
        {"messages": [HumanMessage(content="我叫什么？")]},
        config=config
    )
    print(f"\n清除前 - 用户: 我叫什么？")
    print(f"Agent: {result1['messages'][-1].content}")

    # 清除状态（开始新对话）
    # 方法1：使用新的 thread_id
    new_config = {"configurable": {"thread_id": "clear_session_new"}}

    result2 = await agent.ainvoke(
        {"messages": [HumanMessage(content="我叫什么？")]},
        config=new_config
    )
    print(f"\n新会话 - 用户: 我叫什么？")
    print(f"Agent: {result2['messages'][-1].content}")


async def main():
    """运行所有记忆示例"""
    print("\n" + "=" * 60)
    print("示例 4.1: 基础记忆功能")
    print("=" * 60)
    await basic_memory()

    print("\n" + "=" * 60)
    print("示例 4.2: 不同会话隔离")
    print("=" * 60)
    await different_sessions()

    print("\n" + "=" * 60)
    print("示例 4.3: 检查对话状态")
    print("=" * 60)
    await check_state()

    print("\n" + "=" * 60)
    print("示例 4.4: 项目信息对话")
    print("=" * 60)
    await conversation_summary()

    print("\n" + "=" * 60)
    print("示例 4.5: 带工具的记忆 Agent")
    print("=" * 60)
    await memory_with_tools()

    print("\n" + "=" * 60)
    print("示例 4.6: 重放对话历史")
    print("=" * 60)
    await replay_conversation()

    print("\n" + "=" * 60)
    print("示例 4.7: 清除对话历史")
    print("=" * 60)
    await clear_conversation()


if __name__ == "__main__":
    asyncio.run(main())
