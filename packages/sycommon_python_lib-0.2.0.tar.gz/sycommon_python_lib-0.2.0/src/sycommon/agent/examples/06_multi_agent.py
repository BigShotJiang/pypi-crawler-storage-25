"""
示例 06: 多 Agent 协作
=====================

展示如何创建多 Agent 系统，让多个专业 Agent 协作完成任务。

运行方式:
    python -m sycommon.agent.examples.06_multi_agent
"""
import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool

from sycommon.agent import get_agent, SubAgent


# ========== 工具定义 ==========

@tool
def search_web(query: str) -> str:
    """搜索网络获取信息"""
    # 模拟搜索结果
    results = {
        "AI": "人工智能（AI）是计算机科学的一个分支，致力于创建能够执行需要人类智能的任务的系统...",
        "Python": "Python 是一种高级编程语言，以其简洁的语法和丰富的库生态系统而闻名...",
        "机器学习": "机器学习是 AI 的子领域，通过算法让系统从数据中学习..."
    }
    for key, value in results.items():
        if key.lower() in query.lower():
            return f"搜索结果: {value}"
    return f"搜索结果: 找到与 '{query}' 相关的 10 条信息"


@tool
def write_document(title: str, content: str) -> str:
    """写入文档"""
    return f"文档已保存: {title} ({len(content)} 字符)"


@tool
def analyze_data(data: str) -> str:
    """分析数据"""
    return f"分析完成: 检测到 {len(data.split())} 个数据点，发现 3 个趋势"


# ========== 示例函数 ==========

async def basic_multi_agent():
    """基础多 Agent 协作"""
    # 定义专业的子 Agent
    researcher = SubAgent(
        name="researcher",
        description="研究专家，擅长搜索和收集信息",
        system_prompt="你是研究专家，负责搜索和收集相关信息。输出要详细、准确。"
    )

    writer = SubAgent(
        name="writer",
        description="写作专家，擅长撰写文章和报告",
        system_prompt="你是写作专家，负责将信息整理成流畅的文章。"
    )

    # 创建主协调 Agent
    coordinator = get_agent(
        model="Qwen2.5-72B",
        subagents=[researcher, writer],
        system_prompt="""你是项目协调者，负责协调研究员和作家。

        工作流程：
        1. 先让研究员收集信息
        2. 然后让作家根据研究结果撰写文章
        3. 最后综合输出完整内容

        根据任务需要委派给合适的子 Agent。"""
    )

    print("=" * 50)
    print("基础多 Agent 协作")
    print("=" * 50)
    print("\n用户: 帮我写一篇关于人工智能的短文")

    result = await coordinator.ainvoke({
        "messages": [HumanMessage(content="帮我写一篇关于人工智能的短文，200字左右")]
    })

    print(f"\n最终输出:\n{result['messages'][-1].content}")


async def three_agent_pipeline():
    """三 Agent 流水线"""
    # 定义三个专业 Agent
    researcher = SubAgent(
        name="researcher",
        description="信息收集和分析专家",
        system_prompt="你是研究员，负责收集和分析信息。输出要点列表。"
    )

    drafter = SubAgent(
        name="drafter",
        description="草稿撰写专家",
        system_prompt="你是起草专家，根据研究信息撰写初稿。"
    )

    editor = SubAgent(
        name="editor",
        description="编辑和润色专家",
        system_prompt="你是编辑，负责润色文章，使语言更流畅、专业。"
    )

    # 创建流水线协调者
    pipeline = get_agent(
        model="Qwen2.5-72B",
        subagents=[researcher, drafter, editor],
        system_prompt="""你是内容生产流水线的协调者。

        严格按顺序执行：
        1. researcher - 收集和分析信息
        2. drafter - 撰写初稿
        3. editor - 润色定稿

        确保每个步骤完成后才进入下一步。"""
    )

    print("\n" + "=" * 50)
    print("三 Agent 流水线")
    print("=" * 50)
    print("\n用户: 生产一篇关于 Python 编程语言的介绍")

    result = await pipeline.ainvoke({
        "messages": [HumanMessage(content="生产一篇关于 Python 编程语言的介绍，100字左右")]}
    )

    print(f"\n最终输出:\n{result['messages'][-1].content}")


async def agent_with_tools():
    """带工具的子 Agent"""
    # 定义带工具的子 Agent
    search_agent = SubAgent(
        name="search_agent",
        description="搜索专家，可以搜索网络获取最新信息",
        system_prompt="你是搜索专家，使用 search_web 工具获取信息。",
        tools=[search_web]
    )

    doc_agent = SubAgent(
        name="doc_agent",
        description="文档专家，可以创建和保存文档",
        system_prompt="你是文档专家，使用 write_document 工具保存内容。",
        tools=[write_document]
    )

    # 主 Agent 也有工具
    coordinator = get_agent(
        model="Qwen2.5-72B",
        tools=[analyze_data],
        subagents=[search_agent, doc_agent],
        system_prompt="""你是信息处理协调者。

        可用资源：
        - 自己有 analyze_data 工具
        - search_agent 可以搜索网络
        - doc_agent 可以保存文档

        根据任务选择合适的处理方式。"""
    )

    print("\n" + "=" * 50)
    print("带工具的子 Agent")
    print("=" * 50)
    print("\n用户: 搜索 AI 最新进展，分析后保存文档")

    result = await coordinator.ainvoke({
        "messages": [HumanMessage(content="搜索 AI 最新进展，分析后保存文档")]}
    )

    print(f"\n输出:\n{result['messages'][-1].content}")


async def specialist_agents():
    """专业领域 Agent"""
    # 不同领域的专家
    tech_expert = SubAgent(
        name="tech_expert",
        description="技术专家，回答编程和技术相关问题",
        system_prompt="你是技术专家，专注于编程、软件架构等技术问题。"
    )

    business_expert = SubAgent(
        name="business_expert",
        description="商业专家，回答商业和策略相关问题",
        system_prompt="你是商业专家，专注于商业策略、市场分析等问题。"
    )

    creative_expert = SubAgent(
        name="creative_expert",
        description="创意专家，回答设计和创意相关问题",
        system_prompt="你是创意专家，专注于设计、创意、用户体验等问题。"
    )

    # 智能路由 Agent
    router = get_agent(
        model="Qwen2.5-72B",
        subagents=[tech_expert, business_expert, creative_expert],
        system_prompt="""你是智能路由器，根据问题类型选择合适的专家。

        - 技术问题 -> tech_expert
        - 商业问题 -> business_expert
        - 创意问题 -> creative_expert

        分析用户问题，选择最合适的专家回答。"""
    )

    print("\n" + "=" * 50)
    print("专业领域 Agent")
    print("=" * 50)

    questions = [
        "如何设计一个高并发的系统架构？",
        "如何制定产品的定价策略？",
        "如何设计一个吸引人的登录页面？"
    ]

    for q in questions:
        result = await router.ainvoke({
            "messages": [HumanMessage(content=q)]}
        )
        print(f"\n问题: {q}")
        print(f"回答: {result['messages'][-1].content[:200]}...")


async def hierarchical_agents():
    """层级 Agent 结构"""
    # 底层执行 Agent
    python_coder = SubAgent(
        name="python_coder",
        description="Python 程序员",
        system_prompt="你是 Python 专家，编写和调试 Python 代码。"
    )

    js_coder = SubAgent(
        name="js_coder",
        description="JavaScript 程序员",
        system_prompt="你是 JavaScript 专家，编写和调试 JS 代码。"
    )

    # 中层管理 Agent
    dev_lead = SubAgent(
        name="dev_lead",
        description="开发组长，管理程序员",
        system_prompt="""你是开发组长，管理 Python 和 JavaScript 程序员。
        根据任务需求分配给合适的程序员。""",
        subagents=[python_coder, js_coder]
    )

    # 顶层项目 Agent
    project_manager = get_agent(
        model="Qwen2.5-72B",
        subagents=[dev_lead],
        system_prompt="""你是项目经理，协调开发组长完成任务。
        技术开发任务交给 dev_lead 处理。"""
    )

    print("\n" + "=" * 50)
    print("层级 Agent 结构")
    print("=" * 50)
    print("\n用户: 我需要一个 Python 数据处理脚本")

    result = await project_manager.ainvoke({
        "messages": [HumanMessage(content="我需要一个 Python 数据处理脚本，读取 CSV 文件并计算平均值")]},
    )

    print(f"\n输出:\n{result['messages'][-1].content}")


async def parallel_agents():
    """并行 Agent 执行"""
    # 多个独立 Agent
    analyzer_1 = SubAgent(
        name="analyzer_1",
        description="数据分析师1",
        system_prompt="你是数据分析师，从技术角度分析问题。"
    )

    analyzer_2 = SubAgent(
        name="analyzer_2",
        description="数据分析师2",
        system_prompt="你是数据分析师，从用户角度分析问题。"
    )

    analyzer_3 = SubAgent(
        name="analyzer_3",
        description="数据分析师3",
        system_prompt="你是数据分析师，从商业角度分析问题。"
    )

    # 主 Agent 可以并行调用
    coordinator = get_agent(
        model="Qwen2.5-72B",
        subagents=[analyzer_1, analyzer_2, analyzer_3],
        system_prompt="""你是分析协调者，可以从多个角度分析问题。
        让三个分析师分别从技术、用户、商业角度分析，然后综合他们的观点。"""
    )

    print("\n" + "=" * 50)
    print("并行 Agent 执行")
    print("=" * 50)
    print("\n用户: 分析一下云计算服务的优缺点")

    result = await coordinator.ainvoke({
        "messages": [HumanMessage(content="分析一下云计算服务的优缺点，从多个角度")]}
    )

    print(f"\n综合分析:\n{result['messages'][-1].content}")


async def debate_agents():
    """辩论 Agent"""
    # 两个对立观点的 Agent
    supporter = SubAgent(
        name="supporter",
        description="支持者，强调 AI 的积极影响",
        system_prompt="你是 AI 技术的支持者，强调 AI 带来的积极影响和机遇。"
    )

    critic = SubAgent(
        name="critic",
        description="批评者，关注 AI 的风险和挑战",
        system_prompt="你是 AI 技术的批评者，关注 AI 带来的风险、挑战和负面影响。"
    )

    # 裁判 Agent
    moderator = get_agent(
        model="Qwen2.5-72B",
        subagents=[supporter, critic],
        system_prompt="""你是辩论主持人。

        让支持者和批评者分别表达观点，然后：
        1. 总结双方的核心论点
        2. 给出平衡的结论

        确保双方观点都得到充分表达。"""
    )

    print("\n" + "=" * 50)
    print("辩论 Agent")
    print("=" * 50)
    print("\n话题: 人工智能对就业市场的影响")

    result = await moderator.ainvoke({
        "messages": [HumanMessage(content="讨论人工智能对就业市场的影响")]},
    )

    print(f"\n辩论总结:\n{result['messages'][-1].content}")


async def agent_with_memory():
    """带记忆的多 Agent"""
    from langgraph.checkpoint.memory import MemorySaver

    # 子 Agent
    note_taker = SubAgent(
        name="note_taker",
        description="记录员，记录会议要点",
        system_prompt="你是记录员，记录和整理会议要点。"
    )

    action_planner = SubAgent(
        name="action_planner",
        description="行动计划专家，制定后续行动计划",
        system_prompt="你是行动计划专家，根据讨论内容制定后续行动。"
    )

    # 带记忆的主 Agent
    meeting_host = get_agent(
        model="Qwen2.5-72B",
        subagents=[note_taker, action_planner],
        system_prompt="""你是会议主持人，协调记录员和行动专家。

        会议流程：
        1. 讨论议题
        2. 让 note_taker 记录要点
        3. 让 action_planner 制定行动

        记住之前会议的内容。""",
        checkpointer=MemorySaver(),
        name="meeting_host"
    )

    print("\n" + "=" * 50)
    print("带记忆的多 Agent")
    print("=" * 50)

    thread_id = "meeting_001"
    config = {"configurable": {"thread_id": thread_id}}

    # 第一轮
    print("\n会议 1: 讨论产品发布")
    result1 = await meeting_host.ainvoke(
        {"messages": [HumanMessage(content="我们讨论一下新产品的发布计划")]},
        config=config
    )
    print(f"输出: {result1['messages'][-1].content[:200]}...")

    # 第二轮（延续记忆）
    print("\n会议 2: 继续讨论")
    result2 = await meeting_host.ainvoke(
        {"messages": [HumanMessage(content="上次我们讨论了什么？")]},
        config=config
    )
    print(f"输出: {result2['messages'][-1].content[:200]}...")


async def main():
    """运行所有多 Agent 示例"""
    print("\n" + "=" * 60)
    print("示例 6.1: 基础多 Agent 协作")
    print("=" * 60)
    await basic_multi_agent()

    print("\n" + "=" * 60)
    print("示例 6.2: 三 Agent 流水线")
    print("=" * 60)
    await three_agent_pipeline()

    print("\n" + "=" * 60)
    print("示例 6.3: 带工具的子 Agent")
    print("=" * 60)
    await agent_with_tools()

    print("\n" + "=" * 60)
    print("示例 6.4: 专业领域 Agent")
    print("=" * 60)
    await specialist_agents()

    print("\n" + "=" * 60)
    print("示例 6.5: 层级 Agent 结构")
    print("=" * 60)
    await hierarchical_agents()

    print("\n" + "=" * 60)
    print("示例 6.6: 并行 Agent 执行")
    print("=" * 60)
    await parallel_agents()

    print("\n" + "=" * 60)
    print("示例 6.7: 辩论 Agent")
    print("=" * 60)
    await debate_agents()

    print("\n" + "=" * 60)
    print("示例 6.8: 带记忆的多 Agent")
    print("=" * 60)
    await agent_with_memory()


if __name__ == "__main__":
    asyncio.run(main())
