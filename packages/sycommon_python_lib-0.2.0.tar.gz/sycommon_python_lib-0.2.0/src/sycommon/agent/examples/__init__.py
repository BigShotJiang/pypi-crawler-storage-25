"""
DeepAgent 示例集合
================

展示 create_deep_agent 的各种使用场景，从简单到复杂。

示例列表:
    01_basic_agent.py      - 基础 Agent 使用
    02_tool_agent.py       - 带工具的 Agent
    03_structured_output.py - 结构化输出
    04_memory_agent.py     - 记忆和上下文
    05_streaming.py        - 流式输出
    06_multi_agent.py      - 多 Agent 协作
    07_skills_agent.py     - 技能系统
    08_middleware.py       - 中间件和调试
    09_interrupt.py        - 中断和人工审核
    10_custom_llm.py       - 自定义 LLM 配置
    11_complex_workflow.py - 复杂工作流
    12_batch_processing.py - 批量处理

运行方式:
    # 运行单个示例
    python -m sycommon.agent.examples.01_basic_agent

    # 或在代码中导入
    from sycommon.agent.examples.01_basic_agent import basic_chat
    import asyncio
    asyncio.run(basic_chat())
"""

__all__ = [
    "01_basic_agent",
    "02_tool_agent",
    "03_structured_output",
    "04_memory_agent",
    "05_streaming",
    "06_multi_agent",
    "07_skills_agent",
    "08_middleware",
    "09_interrupt",
    "10_custom_llm",
    "11_complex_workflow",
    "12_batch_processing",
]
