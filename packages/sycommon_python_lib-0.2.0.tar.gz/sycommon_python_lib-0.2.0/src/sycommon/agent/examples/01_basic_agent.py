"""
示例 01: 基础 Agent 使用
========================

最简单的 Agent 调用方式，无需工具、子 Agent 等复杂配置。

运行方式:
    python -m sycommon.agent.examples.01_basic_agent
"""
import asyncio
from langchain_core.messages import HumanMessage

from sycommon.agent import get_agent


async def basic_chat():
    """最基础的对话 Agent"""
    # 创建 Agent - 只需指定模型和系统提示词
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个友好的助手，回答简洁明了。"
    )

    # 调用 Agent
    result = await agent.ainvoke({
        "messages": [HumanMessage(content="你好，介绍一下自己")]
    })

    print("=" * 50)
    print("用户: 你好，介绍一下自己")
    print("=" * 50)
    print("Agent:", result["messages"][-1].content)


async def multi_turn_chat():
    """多轮对话（无记忆）"""
    agent = get_agent(
        model="Qwen2.5-72B",
        system_prompt="你是一个编程助手，擅长解释技术概念。"
    )

    questions = [
        "什么是 Python 装饰器？",
        "它有什么用途？",
        "能举个实际例子吗？"
    ]

    # 注意：这里每次调用都是独立的，Agent 不会记住之前的对话
    for q in questions:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=q)]
        })
        print(f"\n用户: {q}")
        print(f"Agent: {result['messages'][-1].content}")


async def different_models():
    """使用不同模型"""
    models = ["Qwen2.5-72B", "Qwen3-235B-A22B"]
    question = "用一句话解释什么是机器学习"

    for model_name in models:
        try:
            agent = get_agent(
                model=model_name,
                system_prompt="你是一个简洁的助手，用一句话回答问题。"
            )

            result = await agent.ainvoke({
                "messages": [HumanMessage(content=question)]
            })

            print(f"\n模型 {model_name}:")
            print(f"回答: {result['messages'][-1].content}")
        except Exception as e:
            print(f"\n模型 {model_name}: 调用失败 - {e}")


async def custom_temperature():
    """自定义温度参数"""
    # 低温度 - 更稳定、确定性的输出
    stable_agent = get_agent(
        model="Qwen2.5-72B",
        temperature=0.1,
        system_prompt="你是一个精确的助手。"
    )

    # 高温度 - 更有创造性
    creative_agent = get_agent(
        model="Qwen2.5-72B",
        temperature=0.9,
        system_prompt="你是一个有创意的助手。"
    )

    prompt = "给我讲一个短笑话"

    print("低温度 (0.1) - 稳定输出:")
    result1 = await stable_agent.ainvoke({
        "messages": [HumanMessage(content=prompt)]
    })
    print(result1["messages"][-1].content)

    print("\n高温度 (0.9) - 创造性输出:")
    result2 = await creative_agent.ainvoke({
        "messages": [HumanMessage(content=prompt)]
    })
    print(result2["messages"][-1].content)


async def main():
    """运行所有基础示例"""
    print("\n" + "=" * 60)
    print("示例 1.1: 基础对话")
    print("=" * 60)
    await basic_chat()

    print("\n" + "=" * 60)
    print("示例 1.2: 多轮对话（无记忆）")
    print("=" * 60)
    await multi_turn_chat()

    print("\n" + "=" * 60)
    print("示例 1.3: 使用不同模型")
    print("=" * 60)
    await different_models()

    print("\n" + "=" * 60)
    print("示例 1.4: 自定义温度参数")
    print("=" * 60)
    await custom_temperature()


if __name__ == "__main__":
    asyncio.run(main())
