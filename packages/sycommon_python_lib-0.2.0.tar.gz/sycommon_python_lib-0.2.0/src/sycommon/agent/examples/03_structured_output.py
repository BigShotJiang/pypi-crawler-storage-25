"""
示例 03: 结构化输出
===================

展示如何使用 response_format 参数让 Agent 输出结构化数据。

运行方式:
    python -m sycommon.agent.examples.03_structured_output
"""
import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage

from sycommon.agent import get_agent


# ========== 定义输出 Schema ==========

class PersonInfo(BaseModel):
    """人员信息"""
    name: str = Field(description="姓名")
    age: int = Field(description="年龄")
    occupation: str = Field(description="职业")
    email: Optional[str] = Field(default=None, description="邮箱地址")


class ProductReview(BaseModel):
    """产品评价"""
    product_name: str = Field(description="产品名称")
    rating: int = Field(ge=1, le=5, description="评分 1-5")
    pros: List[str] = Field(description="优点列表")
    cons: List[str] = Field(description="缺点列表")
    summary: str = Field(description="评价总结")


class TaskPlan(BaseModel):
    """任务计划"""
    task_name: str = Field(description="任务名称")
    priority: str = Field(description="优先级：high/medium/low")
    estimated_hours: float = Field(description="预估工时")
    subtasks: List[str] = Field(description="子任务列表")
    dependencies: List[str] = Field(default_factory=list, description="依赖项")


class AnalysisReport(BaseModel):
    """分析报告"""
    title: str = Field(description="报告标题")
    summary: str = Field(description="总结")
    key_findings: List[str] = Field(description="关键发现")
    recommendations: List[str] = Field(description="建议列表")
    confidence_score: float = Field(ge=0, le=1, description="置信度 0-1")


class CodeReview(BaseModel):
    """代码审查结果"""
    file_path: str = Field(description="文件路径")
    issues: List["CodeIssue"] = Field(description="问题列表")
    overall_score: int = Field(ge=0, le=100, description="整体评分")
    suggestions: List[str] = Field(description="改进建议")


class CodeIssue(BaseModel):
    """代码问题"""
    line_number: int = Field(description="行号")
    severity: str = Field(description="严重程度：error/warning/info")
    message: str = Field(description="问题描述")


# 需要更新 forward reference
CodeReview.model_rebuild()


# ========== 示例函数 ==========

async def extract_person_info():
    """提取人员信息"""
    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=PersonInfo,
        system_prompt="从文本中提取人员信息，返回 JSON 格式。"
    )

    texts = [
        "张三今年28岁，是一名软件工程师，邮箱是 zhangsan@example.com",
        "李四，35岁，产品经理",
        "王五今年刚毕业，22岁，目前是实习生"
    ]

    for text in texts:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=f"提取信息：{text}")]
        })
        print(f"\n输入: {text}")
        print(f"输出: {result['messages'][-1].content}")


async def analyze_product_review():
    """分析产品评价"""
    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=ProductReview,
        system_prompt="分析产品评价，提取关键信息并结构化输出。"
    )

    review = """
    我最近购买了一款无线蓝牙耳机，总体来说体验不错。
    优点：音质很好，续航能力强，佩戴舒适，降噪效果明显。
    缺点：价格偏高，充电盒有点大，有时候连接不太稳定。
    总体评分4分，性价比还可以。
    """

    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"分析这条评价：{review}")]
    })

    print("=" * 50)
    print("输入评价:")
    print(review)
    print("=" * 50)
    print("结构化输出:")
    print(result["messages"][-1].content)


async def create_task_plan():
    """创建任务计划"""
    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=TaskPlan,
        system_prompt="根据需求描述，创建结构化的任务计划。"
    )

    requirement = """
    需要开发一个用户登录功能：
    - 支持用户名密码登录
    - 支持手机验证码登录
    - 支持第三方登录（微信、支付宝）
    - 需要有登录失败次数限制
    """

    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"为以下需求创建任务计划：{requirement}")]
    })

    print("=" * 50)
    print("需求:")
    print(requirement)
    print("=" * 50)
    print("任务计划:")
    print(result["messages"][-1].content)


async def generate_analysis_report():
    """生成分析报告"""
    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=AnalysisReport,
        system_prompt="分析用户反馈数据，生成结构化的分析报告。"
    )

    feedback_data = """
    本月用户反馈汇总：
    1. 界面改版后用户体验提升明显，好评率提升20%
    2. 搜索功能响应速度仍需优化，30%用户反映速度慢
    3. 新增的深色模式功能受到欢迎
    4. 移动端适配存在问题，部分页面显示异常
    5. 客服响应时间从24小时缩短到4小时，用户满意度提升
    6. 希望增加数据导出功能
    7. 价格方面反馈较为中性
    """

    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"分析这些反馈并生成报告：{feedback_data}")]
    })

    print("=" * 50)
    print("反馈数据:")
    print(feedback_data)
    print("=" * 50)
    print("分析报告:")
    print(result["messages"][-1].content)


async def nested_schema():
    """嵌套 Schema 示例"""
    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=CodeReview,
        system_prompt="对代码进行审查，返回结构化的审查结果。"
    )

    code = '''
def calculate_total(items):
    total = 0
    for item in items:
        total = total + item.price * item.quantity
    return total

def process_order(order):
    items = order.items
    total = calculate_total(items)
    order.total = total
    return order
    '''

    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"审查这段代码：\n{code}")]
    })

    print("=" * 50)
    print("代码:")
    print(code)
    print("=" * 50)
    print("审查结果:")
    print(result["messages"][-1].content)


async def list_extraction():
    """列表提取示例"""
    class TodoList(BaseModel):
        """待办事项列表"""
        category: str = Field(description="分类")
        items: List[str] = Field(description="待办事项")
        total_count: int = Field(description="总数量")

    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=TodoList,
        system_prompt="从文本中提取待办事项列表。"
    )

    text = """
    今天的工作安排：
    - 上午：开项目会议、回复邮件、整理文档
    - 下午：写代码、测试功能、code review
    - 晚上：学习新技术、健身
    """

    result = await agent.ainvoke({
        "messages": [HumanMessage(content=f"提取待办事项：{text}")]
    })

    print("=" * 50)
    print("输入:")
    print(text)
    print("=" * 50)
    print("提取结果:")
    print(result["messages"][-1].content)


async def enum_field():
    """枚举字段示例"""
    from enum import Enum

    class Priority(str, Enum):
        HIGH = "high"
        MEDIUM = "medium"
        LOW = "low"

    class Status(str, Enum):
        TODO = "todo"
        IN_PROGRESS = "in_progress"
        DONE = "done"

    class Task(BaseModel):
        """任务"""
        name: str = Field(description="任务名称")
        priority: Priority = Field(description="优先级")
        status: Status = Field(description="状态")
        assignee: str = Field(description="负责人")

    agent = get_agent(
        model="Qwen2.5-72B",
        response_format=Task,
        system_prompt="根据描述创建任务，优先级和状态必须是枚举值之一。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="创建一个紧急的进行中任务：修复登录Bug，负责人是小明")]
    })

    print("=" * 50)
    print("任务创建结果:")
    print(result["messages"][-1].content)


async def main():
    """运行所有结构化输出示例"""
    print("\n" + "=" * 60)
    print("示例 3.1: 提取人员信息")
    print("=" * 60)
    await extract_person_info()

    print("\n" + "=" * 60)
    print("示例 3.2: 分析产品评价")
    print("=" * 60)
    await analyze_product_review()

    print("\n" + "=" * 60)
    print("示例 3.3: 创建任务计划")
    print("=" * 60)
    await create_task_plan()

    print("\n" + "=" * 60)
    print("示例 3.4: 生成分析报告")
    print("=" * 60)
    await generate_analysis_report()

    print("\n" + "=" * 60)
    print("示例 3.5: 嵌套 Schema")
    print("=" * 60)
    await nested_schema()

    print("\n" + "=" * 60)
    print("示例 3.6: 列表提取")
    print("=" * 60)
    await list_extraction()

    print("\n" + "=" * 60)
    print("示例 3.7: 枚举字段")
    print("=" * 60)
    await enum_field()


if __name__ == "__main__":
    asyncio.run(main())
