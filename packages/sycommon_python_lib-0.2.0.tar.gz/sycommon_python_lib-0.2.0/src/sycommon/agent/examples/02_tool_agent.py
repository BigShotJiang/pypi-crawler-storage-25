"""
示例 02: 带工具的 Agent
=======================

展示如何为 Agent 添加工具（Tools），让 Agent 能够调用外部功能。

运行方式:
    python -m sycommon.agent.examples.02_tool_agent
"""
import asyncio
from typing import Optional
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage

from sycommon.agent import get_agent


# ========== 定义工具 ==========

@tool
def get_weather(city: str) -> str:
    """
    获取指定城市的天气信息

    Args:
        city: 城市名称，如 "北京"、"上海"

    Returns:
        天气信息字符串
    """
    # 模拟天气 API 返回
    weather_data = {
        "北京": "晴天，温度 25°C，空气质量良好，东风 2 级",
        "上海": "多云，温度 28°C，有轻微雾霾，南风 3 级",
        "深圳": "小雨，温度 30°C，湿度 85%，无风",
        "广州": "阴天，温度 29°C，湿度 80%，微风",
        "成都": "晴天，温度 22°C，空气质量优，北风 1 级",
    }
    return weather_data.get(city, f"未找到 {city} 的天气信息，请尝试其他城市")


@tool
def calculate(expression: str) -> str:
    """
    执行数学计算

    Args:
        expression: 数学表达式，如 "123 * 456" 或 "(100 + 200) / 3"

    Returns:
        计算结果字符串
    """
    try:
        # 安全计算（仅支持基本运算）
        allowed_chars = set("0123456789+-*/.() ")
        if not all(c in allowed_chars for c in expression):
            return "错误：表达式包含不允许的字符"

        result = eval(expression)
        return f"计算结果: {result}"
    except Exception as e:
        return f"计算错误: {str(e)}"


@tool
def search_knowledge(query: str) -> str:
    """
    搜索知识库

    Args:
        query: 搜索关键词

    Returns:
        搜索结果
    """
    # 模拟知识库
    knowledge_base = {
        "Python": "Python 是一种高级编程语言，由 Guido van Rossum 于 1991 年创建。特点：简洁易读、跨平台、丰富的库。",
        "机器学习": "机器学习是人工智能的一个分支，让计算机从数据中学习模式，无需明确编程。",
        "深度学习": "深度学习是机器学习的子领域，使用多层神经网络进行学习和特征提取。",
        "LangChain": "LangChain 是一个开发大语言模型应用的框架，提供链式调用、工具集成等能力。",
    }

    for key, value in knowledge_base.items():
        if key.lower() in query.lower():
            return f"找到相关知识：{value}"

    return f"未找到与 '{query}' 相关的知识"


@tool
def get_current_time(timezone: Optional[str] = None) -> str:
    """
    获取当前时间

    Args:
        timezone: 时区（可选），如 "Asia/Shanghai"

    Returns:
        当前时间字符串
    """
    from datetime import datetime
    now = datetime.now()
    return f"当前时间: {now.strftime('%Y-%m-%d %H:%M:%S')}"


# ========== 示例函数 ==========

async def single_tool():
    """使用单个工具"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_weather],
        system_prompt="""你是一个天气助手。
        当用户询问天气时，使用 get_weather 工具获取信息。
        根据返回的结果，给用户一个友好的回复。"""
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="北京今天天气怎么样？适合户外活动吗？")]
    })

    print("=" * 50)
    print("用户: 北京今天天气怎么样？适合户外活动吗？")
    print("=" * 50)
    print("Agent:", result["messages"][-1].content)


async def multiple_tools():
    """使用多个工具"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_weather, calculate, get_current_time],
        system_prompt="""你是一个智能助手，可以帮助用户：
        1. 查询天气
        2. 进行数学计算
        3. 获取当前时间

        根据用户的需求选择合适的工具。"""
    )

    questions = [
        "现在几点了？",
        "帮我算一下 (1234 + 5678) * 2",
        "深圳天气怎么样？"
    ]

    for q in questions:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=q)]
        })
        print(f"\n用户: {q}")
        print(f"Agent: {result['messages'][-1].content}")


async def tool_chain():
    """工具链式调用 - 一个任务需要多个工具配合"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_weather, calculate],
        system_prompt="""你是一个助手，需要综合使用多个工具完成任务。
        当需要多个工具时，按顺序调用它们。"""
    )

    # 这个问题需要先获取天气，然后可能需要计算
    result = await agent.ainvoke({
        "messages": [HumanMessage(content="查询北京和上海的天气，然后计算两个城市温度差")]
    })

    print("=" * 50)
    print("用户: 查询北京和上海的天气，然后计算两个城市温度差")
    print("=" * 50)
    print("Agent:", result["messages"][-1].content)


async def knowledge_search():
    """知识搜索工具"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[search_knowledge],
        system_prompt="""你是一个知识助手。
        当用户询问技术概念时，先使用 search_knowledge 工具搜索知识库。
        然后基于搜索结果给出详细解释。"""
    )

    questions = [
        "什么是 Python？",
        "介绍一下 LangChain",
        "什么是深度学习？"
    ]

    for q in questions:
        result = await agent.ainvoke({
            "messages": [HumanMessage(content=q)]
        })
        print(f"\n用户: {q}")
        print(f"Agent: {result['messages'][-1].content}")


async def tool_with_error_handling():
    """工具错误处理"""
    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[get_weather, calculate],
        system_prompt="你是一个助手，遇到错误时给用户友好的提示。"
    )

    # 故意问一个不存在的城市
    result = await agent.ainvoke({
        "messages": [HumanMessage(content="火星基地的天气怎么样？")]
    })

    print("=" * 50)
    print("用户: 火星基地的天气怎么样？")
    print("=" * 50)
    print("Agent:", result["messages"][-1].content)


async def custom_tool_decorator():
    """使用 @tool 装饰器创建自定义工具"""

    # 定义更多自定义工具
    @tool
    def convert_currency(amount: float, from_currency: str, to_currency: str) -> str:
        """
        货币换算（示例汇率）

        Args:
            amount: 金额
            from_currency: 原货币（USD, CNY, EUR）
            to_currency: 目标货币

        Returns:
            换算结果
        """
        # 模拟汇率
        rates = {
            "USD": {"CNY": 7.2, "EUR": 0.92},
            "CNY": {"USD": 0.14, "EUR": 0.13},
            "EUR": {"USD": 1.09, "CNY": 7.85}
        }

        from_currency = from_currency.upper()
        to_currency = to_currency.upper()

        if from_currency == to_currency:
            return f"{amount} {from_currency}"

        if from_currency in rates and to_currency in rates[from_currency]:
            rate = rates[from_currency][to_currency]
            result = amount * rate
            return f"{amount} {from_currency} = {result:.2f} {to_currency}"

        return f"不支持从 {from_currency} 到 {to_currency} 的换算"

    agent = get_agent(
        model="Qwen2.5-72B",
        tools=[convert_currency],
        system_prompt="你是一个货币换算助手。"
    )

    result = await agent.ainvoke({
        "messages": [HumanMessage(content="100美元等于多少人民币？")]
    })

    print("=" * 50)
    print("用户: 100美元等于多少人民币？")
    print("=" * 50)
    print("Agent:", result["messages"][-1].content)


async def main():
    """运行所有工具示例"""
    print("\n" + "=" * 60)
    print("示例 2.1: 单工具使用")
    print("=" * 60)
    await single_tool()

    print("\n" + "=" * 60)
    print("示例 2.2: 多工具使用")
    print("=" * 60)
    await multiple_tools()

    print("\n" + "=" * 60)
    print("示例 2.3: 工具链式调用")
    print("=" * 60)
    await tool_chain()

    print("\n" + "=" * 60)
    print("示例 2.4: 知识搜索")
    print("=" * 60)
    await knowledge_search()

    print("\n" + "=" * 60)
    print("示例 2.5: 工具错误处理")
    print("=" * 60)
    await tool_with_error_handling()

    print("\n" + "=" * 60)
    print("示例 2.6: 自定义工具")
    print("=" * 60)
    await custom_tool_decorator()


if __name__ == "__main__":
    asyncio.run(main())
