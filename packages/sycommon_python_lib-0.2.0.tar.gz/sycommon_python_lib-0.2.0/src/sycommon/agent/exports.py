"""
sycommon.agent 导出
=====================

提供对 deepagents 的便捷调用，自动集成 get_llm 的 Token 统计和 Langfuse 追踪。

## 使用示例

```python
from sycommon.agent import get_agent, SubAgent

# 创建 Agent
agent = get_agent(
    model="Qwen2.5-72B",
    tools=[my_tool],
    system_prompt="你是助手"
)

# 执行
result = await agent.ainvoke({"messages": ["你好"]})

# 多 Agent
agent = get_agent(
    model="Qwen2.5-72B",
    subagents=[
        SubAgent(name="researcher", description="研究助手"),
    ]
)

# 虚拟员工（业务层封装）
from sycommon.agent import VirtualEmployee, Skill, EmployeeFactory

support = EmployeeFactory.create_support_agent(name="客服小美")
result = await support.run("我需要帮助")
```
"""

# 主要接口
from sycommon.agent.get_agent import (
    get_agent,
    create_tool_agent,
    create_multi_agent,
    create_structured_agent,
)

# 透传 deepagents 的核心类，方便用户直接使用
from deepagents import (
    SubAgent,
    CompiledSubAgent,
    create_deep_agent,
    MemoryMiddleware,
    FilesystemMiddleware,
    SubAgentMiddleware,
)

# 虚拟员工系统（业务层封装）
from sycommon.agent.virtual_employee import (
    VirtualEmployee,
    VirtualTeam,
    EmployeeFactory,
    Skill,
    SkillLevel,
    SubTeamMember,
    MemoryConfig,
    MemoryType,
    EmployeeMiddleware,
    LoggingEmployeeMiddleware,
    QuotaEmployeeMiddleware,
    PermissionEmployeeMiddleware,
)

# 技能系统中间件（从 deepagents 导入）
from sycommon.agent.skills import (
    SkillsMiddleware,
    SkillMetadata,
)

__all__ = [
    # 主要接口
    "get_agent",
    "create_tool_agent",
    "create_multi_agent",
    "create_structured_agent",
    # deepagents 透传
    "SubAgent",
    "CompiledSubAgent",
    "create_deep_agent",
    "MemoryMiddleware",
    "FilesystemMiddleware",
    "SubAgentMiddleware",
    # 虚拟员工系统
    "VirtualEmployee",
    "VirtualTeam",
    "EmployeeFactory",
    "Skill",
    "SkillLevel",
    "SubTeamMember",
    "MemoryConfig",
    "MemoryType",
    "EmployeeMiddleware",
    "LoggingEmployeeMiddleware",
    "QuotaEmployeeMiddleware",
    "PermissionEmployeeMiddleware",
    # 技能系统中间件
    "SkillsMiddleware",
    "SkillMetadata",
]
