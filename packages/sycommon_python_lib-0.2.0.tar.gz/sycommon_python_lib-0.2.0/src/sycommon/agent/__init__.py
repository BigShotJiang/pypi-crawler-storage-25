"""
sycommon.agent - DeepAgents 便捷封装

提供对 deepagents 的便捷调用，自动集成 get_llm 的 Token 统计和 Langfuse 追踪
"""

from sycommon.agent.exports import *

__all__ = [
    # 主要接口
    "get_agent",
    "create_tool_agent",
    "create_multi_agent",
    "create_structured_agent",
    # deepagents 透传
    "SubAgent",
    "CompiledSubAgent",
    "create_deep_agent",
    "MemoryMiddleware",
    "FilesystemMiddleware",
    "SubAgentMiddleware",
    # 虚拟员工系统
    "VirtualEmployee",
    "VirtualTeam",
    "EmployeeFactory",
    "Skill",
    "SkillLevel",
    "SubTeamMember",
    "MemoryConfig",
    "MemoryType",
    "EmployeeMiddleware",
    "LoggingEmployeeMiddleware",
    "QuotaEmployeeMiddleware",
    "PermissionEmployeeMiddleware",
    # 技能系统中间件
    "SkillsMiddleware",
    "SkillMetadata",
]
