#!/usr/bin/env python3
"""
FAQ 搜索脚本

使用方式:
    python search.py "退货政策"
"""
import sys
import json


# 模拟的 FAQ 数据库
FAQ_DATABASE = {
    "退货": {
        "question": "退货政策是什么？",
        "answer": "购买后7天内可无理由退货，商品需保持原包装完整。退货将在收到商品后3-5个工作日内处理。",
        "category": "售后"
    },
    "配送": {
        "question": "配送需要多长时间？",
        "answer": "一线城市1-2天，其他地区3-5天，偏远地区5-7天。",
        "category": "物流"
    },
    "退款": {
        "question": "退款多久到账？",
        "answer": "退款将在3-5个工作日内原路返回到您的支付账户。",
        "category": "售后"
    },
    "发票": {
        "question": "如何获取发票？",
        "answer": "下单时可选择开具电子发票或纸质发票，电子发票将发送至您的邮箱。",
        "category": "财务"
    }
}


def search_faq(keyword: str) -> str:
    """搜索 FAQ"""
    keyword = keyword.lower().strip()

    results = []
    for key, faq in FAQ_DATABASE.items():
        if (keyword in key.lower() or
            keyword in faq["question"].lower() or
            keyword in faq["answer"].lower()):
            results.append(faq)

    if not results:
        return f"未找到与 '{keyword}' 相关的常见问题。建议您创建工单咨询人工客服。"

    output = []
    for i, faq in enumerate(results[:3], 1):
        output.append(f"{i}. {faq['question']}")
        output.append(f"   {faq['answer']}")
        output.append(f"   [分类: {faq['category']}]")
        output.append("")

    return "\n".join(output)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python search.py <关键词>")
        sys.exit(1)

    keyword = " ".join(sys.argv[1:])
    result = search_faq(keyword)
    print(result)
