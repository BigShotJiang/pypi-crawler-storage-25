"""
技能系统导出
================

直接使用 deepagents 的中间件，无需重复封装。

## 默认中间件栈

使用 `create_deep_agent` 或 `get_agent` 时，以下中间件会**自动添加**：

1. **TodoListMiddleware** - 任务列表管理（来自 langchain.agents.middleware）
2. **FilesystemMiddleware** - 文件操作 + execute 命令执行
3. **SubAgentMiddleware** - 子代理调用
4. **SummarizationMiddleware** - 自动摘要
5. **AnthropicPromptCachingMiddleware** - Prompt 缓存
6. **PatchToolCallsMiddleware** - 工具调用修补

可选中间件（需要参数触发）：
- **MemoryMiddleware** - 记忆系统（需要 `memory` 参数）
- **SkillsMiddleware** - 技能加载（需要 `skills` 参数）

## 使用 SkillsMiddleware

```python
from sycommon.agent import get_agent

agent = get_agent(
    model="Qwen2.5-72B",
    skills=["/skills/user/", "/skills/project/"],  # 启用技能中间件
    memory=["/memory/AGENTS.md"],  # 启用记忆中间件
)
```

## 直接使用中间件

如果你不使用 `create_deep_agent`，而是直接使用 `create_agent`，则需要手动添加中间件：

```python
from langchain.agents import create_agent
from langchain.agents.middleware import TodoListMiddleware
from deepagents.middleware import FilesystemMiddleware

agent = create_agent(
    model,
    middleware=[
        TodoListMiddleware(),
        FilesystemMiddleware(),
    ]
)
```
"""

# 直接从 deepagents 导入核心类
from deepagents.middleware.skills import (
    SkillMetadata,
    SkillsMiddleware,
    SkillsState,
)

# 透传 deepagents 其他中间件
from deepagents.middleware import (
    FilesystemMiddleware,
    MemoryMiddleware,
    SubAgentMiddleware,
    SummarizationMiddleware,
)

__all__ = [
    # 技能系统
    "SkillMetadata",
    "SkillsMiddleware",
    "SkillsState",
    # 其他中间件
    "FilesystemMiddleware",
    "MemoryMiddleware",
    "SubAgentMiddleware",
    "SummarizationMiddleware",
]
