import yaml


class SingletonMeta(type):
    """单例元类

    注意：非线程安全，应在程序启动时（同步环境）提前初始化单例，
    避免在协程环境中首次调用导致问题。
    """
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


class Config(metaclass=SingletonMeta):
    def __init__(self, config_file='app.yaml'):
        with open(config_file, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        self.MaxBytes = self.config.get('MaxBytes', 209715200)
        self.Timeout = self.config.get('Timeout', 600000)
        self.MaxRetries = self.config.get('MaxRetries', 3)
        self.llm_configs = []
        self.embedding_configs = []
        self.reranker_configs = []
        self.sentry_configs = []
        self.langfuse_configs = []
        self.elasticsearch_configs = []
        self._process_config()

    def get_llm_config(self, model_name):
        for llm in self.llm_configs:
            if llm.get('model') == model_name:
                return llm
        raise ValueError(f"No configuration found for model: {model_name}")

    def get_default_llm_config(self):
        """获取默认的 LLM 配置

        Returns:
            dict: 默认模型的配置，如果没有设置 default=True 则返回第一个配置

        Raises:
            ValueError: 如果没有任何 LLM 配置
        """
        if not self.llm_configs:
            raise ValueError("No LLM configuration found")

        # 查找 default=True 的配置
        for llm in self.llm_configs:
            if llm.get('default') is True:
                return llm

        # 如果没有设置 default，返回第一个配置
        return self.llm_configs[0]

    def get_default_llm_model_name(self):
        """获取默认模型名称

        Returns:
            str: 默认模型的名称
        """
        config = self.get_default_llm_config()
        return config.get('model')

    def get_embedding_config(self, model_name):
        for llm in self.embedding_configs:
            if llm.get('model') == model_name:
                return llm
        raise ValueError(f"No configuration found for model: {model_name}")

    def get_reranker_config(self, model_name):
        for llm in self.reranker_configs:
            if llm.get('model') == model_name:
                return llm
        raise ValueError(f"No configuration found for model: {model_name}")

    def get_sentry_config(self, name):
        for sentry in self.sentry_configs:
            if sentry.get('name') == name:
                return sentry
        raise ValueError(f"No configuration found for server: {name}")

    def get_langfuse_config(self, name):
        for langfuse in self.langfuse_configs:
            if langfuse.get('name') == name:
                return langfuse
        raise ValueError(f"No configuration found for server: {name}")

    def get_elasticsearch_config(self, name="default"):
        for es in self.elasticsearch_configs:
            if es.get('name') == name:
                return es
        raise ValueError(f"No configuration found for elasticsearch: {name}")

    def _process_config(self):
        llm_config_list = self.config.get('LLMConfig', [])
        for llm_config in llm_config_list:
            try:
                # 延迟导入 LLMConfigModel
                from sycommon.config.LLMConfig import LLMConfig
                validated_config = LLMConfig(**llm_config)
                self.llm_configs.append(validated_config.model_dump())
            except ValueError as e:
                print(f"Invalid LLM configuration: {e}")

        embedding_config_list = self.config.get('EmbeddingConfig', [])
        for embedding_config in embedding_config_list:
            try:
                from sycommon.config.EmbeddingConfig import EmbeddingConfig
                validated_config = EmbeddingConfig(**embedding_config)
                self.embedding_configs.append(validated_config.model_dump())
            except ValueError as e:
                print(f"Invalid LLM configuration: {e}")

        reranker_config_list = self.config.get('RerankerConfig', [])
        for reranker_config in reranker_config_list:
            try:
                from sycommon.config.RerankerConfig import RerankerConfig
                validated_config = RerankerConfig(**reranker_config)
                self.reranker_configs.append(validated_config.model_dump())
            except ValueError as e:
                print(f"Invalid LLM configuration: {e}")

        sentry_config_list = self.config.get('SentryConfig', [])
        for sentry_config in sentry_config_list:
            try:
                from sycommon.config.SentryConfig import SentryConfig
                validated_config = SentryConfig(**sentry_config)
                self.sentry_configs.append(validated_config.model_dump())
            except ValueError as e:
                print(f"Invalid Sentry configuration: {e}")

        elasticsearch_config_list = self.config.get('ElasticsearchConfig', [])
        for es_config in elasticsearch_config_list:
            try:
                from sycommon.config.ElasticsearchConfig import ElasticsearchConfig
                validated_config = ElasticsearchConfig(**es_config)
                self.elasticsearch_configs.append(
                    validated_config.model_dump())
            except ValueError as e:
                print(f"Invalid Elasticsearch configuration: {e}")

    def set_attr(self, share_configs: dict):
        self.config = {**self.config, **
                       share_configs.get('llm', {}), **share_configs}
        self._process_config()
