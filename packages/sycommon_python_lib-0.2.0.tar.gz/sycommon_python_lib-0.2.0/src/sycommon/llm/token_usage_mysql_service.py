"""
Token 使用量记录服务（MySQL版本）
按用户+系统+日期维度聚合存储，每个人每天每个系统只保留一条记录

使用独立的数据库连接（llm 配置中的数据库），与业务系统数据库隔离
"""
import asyncio
import logging
from datetime import datetime, date
from typing import Optional, Dict, Any, List

from sqlalchemy import select, text
from sqlalchemy.dialects.mysql import insert

from sycommon.config.Config import SingletonMeta, Config
from sycommon.logging.kafka_log import SYLogger
from sycommon.database.token_usage_db_service import TokenUsageDBService
from sycommon.models.token_usage_mysql import TokenUsageMySQL

logger = SYLogger


class TokenUsageMySQLService(metaclass=SingletonMeta):
    """Token 使用量记录服务（MySQL异步版本）

    使用独立的数据库连接，连接到 shengye_platform_ai_middleware 库
    配置来源：Config().config.get("llm", {}).get("spring", {}).get("datasource", {})
    """

    _initialized: bool = False
    _table_ensured: bool = False
    _db_service: Optional[TokenUsageDBService] = None
    _service_name: Optional[str] = None
    _system_env: Optional[str] = None

    def __init__(self):
        pass

    @classmethod
    def _load_service_info(cls):
        """加载服务信息（延迟加载，确保 Config 已加载）"""
        # 如果已经加载过且不为空，则跳过
        if cls._service_name is not None and cls._system_env is not None:
            return

        try:
            config = Config().config
            if cls._service_name is None:
                service_name = config.get('Name', None)
                if service_name:
                    cls._service_name = service_name
                    logging.info(
                        f"TokenUsageMySQLService 加载 service_name: {cls._service_name}")

            if cls._system_env is None:
                env = config.get('Nacos', {}).get('namespaceId', None)
                if env:
                    cls._system_env = env
                    logging.info(
                        f"TokenUsageMySQLService 加载 system_env: {cls._system_env}")

        except Exception as e:
            logging.warning(f"获取服务信息失败: {e}")

    @classmethod
    def init(cls):
        """
        初始化 Token 记录服务

        使用独立的数据库连接（llm 配置中的数据库），不依赖业务系统的数据库
        """
        if cls._initialized:
            return

        # 先加载服务信息（确保 Config 已初始化）
        cls._load_service_info()

        try:
            # 初始化独立的 Token 使用量数据库服务
            cls._db_service = TokenUsageDBService()
            if cls._db_service.init():
                asyncio.create_task(cls._ensure_table())
                cls._initialized = True
                logging.info("TokenUsageMySQLService 初始化成功")
            else:
                logging.warning("TokenUsageMySQLService 初始化失败: 数据库服务未就绪")
        except Exception as e:
            logging.warning(f"TokenUsageMySQLService 初始化失败: {e}")

    @classmethod
    async def _ensure_table(cls):
        """确保表存在"""
        if cls._table_ensured:
            return

        if not cls._db_service:
            return

        try:
            async with cls._db_service.session() as session:
                # 创建表（如果不存在）
                await session.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS token_usage_daily (
                        id INT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
                        user_id VARCHAR(128) NULL COMMENT '用户ID',
                        tenant_id VARCHAR(128) NULL COMMENT '租户ID',
                        service_name VARCHAR(128) NULL COMMENT '服务名称',
                        system_env VARCHAR(128) NULL COMMENT '系统环境',
                        input_tokens INT DEFAULT 0 COMMENT '输入token数',
                        output_tokens INT DEFAULT 0 COMMENT '输出token数',
                        total_tokens INT DEFAULT 0 COMMENT '总token数',
                        model VARCHAR(128) NULL COMMENT '最近使用的模型',
                        usage_date DATE NOT NULL COMMENT '使用日期',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                        UNIQUE KEY uniq_user_service_env_date (user_id, service_name, system_env, usage_date),
                        INDEX idx_user_id (user_id),
                        INDEX idx_service_name (service_name),
                        INDEX idx_tenant_id (tenant_id),
                        INDEX idx_usage_date (usage_date),
                        INDEX idx_system_env (system_env)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Token使用量日统计表'
                """))
                cls._table_ensured = True
                logging.info("MySQL 表 token_usage_daily 确认存在")
        except Exception as e:
            logging.error(f"创建 MySQL 表失败: {e}", exc_info=True)

    @classmethod
    def record_sync(
        cls,
        user_id: Optional[str],
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> bool:
        """
        同步记录 Token 使用量（Fire-and-forget 模式）

        Args:
            user_id: 用户ID（从请求头获取，没有则为空）
            input_tokens: 输入 token 数量
            output_tokens: 输出 token 数量
            model: 模型名称（从 get_llm 参数获取）
            trace_id: 链路追踪ID（MySQL版本不使用）
            tenant_id: 租户ID
            service_name: 服务名称（当前系统服务信息）
            system_env: 系统环境（当前是什么环境）

        Returns:
            bool: 是否成功提交记录任务
        """
        if not cls._initialized:
            cls.init()

        if not cls._initialized:
            logging.warning("TokenUsageMySQLService 未初始化，跳过 Token 记录")
            return False

        # 延迟加载服务信息（确保 Config 已初始化）
        cls._load_service_info()

        # 使用初始化时加载的服务信息
        if service_name is None:
            service_name = cls._service_name
        if system_env is None:
            system_env = cls._system_env

        logging.info(
            f"TokenUsageMySQLService record_sync: service_name={service_name}, system_env={system_env}, cls._service_name={cls._service_name}, cls._system_env={cls._system_env}")

        try:
            try:
                loop = asyncio.get_running_loop()
                # 创建任务并添加回调处理异常，避免静默失败
                task = loop.create_task(cls._do_record(
                    user_id=user_id,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    tenant_id=tenant_id,
                    service_name=service_name,
                    system_env=system_env
                ))
                # 添加回调处理异常

                def _handle_task_exception(t):
                    try:
                        t.result()
                    except Exception as e:
                        logging.error(f"Token 记录任务失败: {e}", exc_info=True)
                task.add_done_callback(_handle_task_exception)
            except RuntimeError:
                # 没有运行中的事件循环，使用 asyncio.run
                asyncio.run(cls._do_record(
                    user_id=user_id,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    tenant_id=tenant_id,
                    service_name=service_name,
                    system_env=system_env
                ))
            return True
        except Exception as e:
            logging.error(f"记录 Token 使用量失败: {e}", exc_info=True)
            return False

    @classmethod
    async def record(
        cls,
        user_id: Optional[str],
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        trace_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> bool:
        """
        异步记录 Token 使用量

        每个用户每个服务每天只保留一条记录，如果存在则累加更新

        Args:
            user_id: 用户ID（从请求头获取，没有则为空）
            input_tokens: 输入 token 数量
            output_tokens: 输出 token 数量
            model: 模型名称（从 get_llm 参数获取）
            trace_id: 链路追踪ID（MySQL版本不使用）
            tenant_id: 租户ID
            service_name: 服务名称（当前系统服务信息）
            system_env: 系统环境（当前是什么环境）

        Returns:
            bool: 是否成功记录
        """
        if not cls._initialized:
            cls.init()

        if not cls._initialized:
            return False

        # 延迟加载服务信息（确保 Config 已初始化）
        cls._load_service_info()

        # 使用初始化时加载的服务信息
        if service_name is None:
            service_name = cls._service_name
        if system_env is None:
            system_env = cls._system_env

        return await cls._do_record(
            user_id=user_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=model,
            tenant_id=tenant_id,
            service_name=service_name,
            system_env=system_env
        )

    @classmethod
    async def _do_record(
        cls,
        user_id: Optional[str],
        input_tokens: int,
        output_tokens: int,
        model: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_name: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> bool:
        """
        执行记录操作（使用 MySQL INSERT ON DUPLICATE KEY UPDATE 实现 upsert）
        """
        if not cls._db_service:
            return False

        # 延迟加载服务信息（确保 Config 已初始化）
        cls._load_service_info()

        # 使用类缓存的服务信息作为默认值
        if service_name is None:
            service_name = cls._service_name
        if system_env is None:
            system_env = cls._system_env

        try:
            # 确保表存在（阻塞等待表创建完成）
            await cls._ensure_table()

            today = date.today()
            total = input_tokens + output_tokens

            logging.info(
                f"TokenUsageMySQLService _do_record 参数: service_name={service_name}, system_env={system_env}")

            # 唯一索引字段：为空时存空字符串，确保唯一索引能正确去重
            user_id = user_id or ''
            service_name = service_name or ''
            system_env = system_env or ''

            async with cls._db_service.session() as session:
                # 使用 MySQL 的 INSERT ... ON DUPLICATE KEY UPDATE
                stmt = insert(TokenUsageMySQL).values(
                    user_id=user_id,
                    tenant_id=tenant_id,
                    service_name=service_name,
                    system_env=system_env,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=total,
                    model=model,
                    usage_date=today
                )

                # 冲突时累加更新
                stmt = stmt.on_duplicate_key_update(
                    input_tokens=TokenUsageMySQL.input_tokens + input_tokens,
                    output_tokens=TokenUsageMySQL.output_tokens + output_tokens,
                    total_tokens=TokenUsageMySQL.total_tokens + total,
                    model=model,  # 更新为最新使用的模型
                    updated_at=datetime.now()
                )

                await session.execute(stmt)
                return True

        except Exception as e:
            logging.error(f"记录 Token 使用量到 MySQL 失败: {e}", exc_info=True)
            return False

    @classmethod
    async def get_user_daily_usage(
        cls,
        user_id: str,
        usage_date: Optional[date] = None,
        service_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        查询用户某天的 Token 使用量

        Args:
            user_id: 用户ID
            usage_date: 使用日期，默认今天
            service_name: 服务名称（可选）
            tenant_id: 租户ID（可选）
            system_env: 系统环境（可选）

        Returns:
            Dict: 包含 input_tokens, output_tokens, total_tokens 的统计
        """
        if not cls._db_service:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            if usage_date is None:
                usage_date = date.today()

            async with cls._db_service.session() as session:
                conditions = [
                    TokenUsageMySQL.user_id == user_id,
                    TokenUsageMySQL.usage_date == usage_date
                ]

                if service_name:
                    conditions.append(TokenUsageMySQL.service_name == service_name)
                if tenant_id:
                    conditions.append(TokenUsageMySQL.tenant_id == tenant_id)
                if system_env:
                    conditions.append(TokenUsageMySQL.system_env == system_env)

                stmt = select(TokenUsageMySQL).where(*conditions)
                result = await session.execute(stmt)
                record = result.scalar_one_or_none()

                if record:
                    return {
                        "input_tokens": record.input_tokens,
                        "output_tokens": record.output_tokens,
                        "total_tokens": record.total_tokens,
                        "model": record.model,
                        "service_name": record.service_name,
                        "system_env": record.system_env,
                        "date": record.usage_date.isoformat()
                    }
                else:
                    return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        except Exception as e:
            logging.error(f"查询用户日 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def get_user_usage(
        cls,
        user_id: str,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        service_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        system_env: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        查询用户 Token 使用量统计（跨天聚合）

        Args:
            user_id: 用户ID
            start_date: 开始日期
            end_date: 结束日期
            service_name: 服务名称（可选）
            tenant_id: 租户ID（可选）
            system_env: 系统环境（可选）

        Returns:
            Dict: 包含 input_tokens, output_tokens, total_tokens 的聚合统计
        """
        if not cls._db_service:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            async with cls._db_service.session() as session:
                conditions = [TokenUsageMySQL.user_id == user_id]

                if service_name:
                    conditions.append(TokenUsageMySQL.service_name == service_name)
                if tenant_id:
                    conditions.append(TokenUsageMySQL.tenant_id == tenant_id)
                if system_env:
                    conditions.append(TokenUsageMySQL.system_env == system_env)
                if start_date:
                    conditions.append(TokenUsageMySQL.usage_date >= start_date)
                if end_date:
                    conditions.append(TokenUsageMySQL.usage_date <= end_date)

                stmt = select(TokenUsageMySQL).where(*conditions)
                result = await session.execute(stmt)
                records = result.scalars().all()

                total_input = sum(r.input_tokens for r in records)
                total_output = sum(r.output_tokens for r in records)
                total_tokens = sum(r.total_tokens for r in records)

                return {
                    "input_tokens": total_input,
                    "output_tokens": total_output,
                    "total_tokens": total_tokens,
                    "days": len(records)
                }

        except Exception as e:
            logging.error(f"查询用户 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def get_usage(
        cls,
        user_id: Optional[str] = None,
        service_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        system_env: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        group_by_user: bool = False,
        group_by_service: bool = False,
        group_by_tenant: bool = False,
        group_by_env: bool = False,
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        通用查询 Token 使用量统计

        Args:
            user_id: 用户ID（可选）
            service_name: 服务名称（可选）
            tenant_id: 租户ID（可选）
            system_env: 系统环境（可选）
            start_date: 开始日期
            end_date: 结束日期
            group_by_user: 是否按用户分组统计
            group_by_service: 是否按服务分组统计
            group_by_tenant: 是否按租户分组统计
            group_by_env: 是否按环境分组统计
            limit: 返回分组数量

        Returns:
            Dict: 包含统计结果
        """
        if not cls._db_service:
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        try:
            async with cls._db_service.session() as session:
                conditions = []

                if user_id:
                    conditions.append(TokenUsageMySQL.user_id == user_id)
                if service_name:
                    conditions.append(TokenUsageMySQL.service_name == service_name)
                if tenant_id:
                    conditions.append(TokenUsageMySQL.tenant_id == tenant_id)
                if system_env:
                    conditions.append(TokenUsageMySQL.system_env == system_env)
                if start_date:
                    conditions.append(TokenUsageMySQL.usage_date >= start_date)
                if end_date:
                    conditions.append(TokenUsageMySQL.usage_date <= end_date)

                stmt = select(TokenUsageMySQL)
                if conditions:
                    stmt = stmt.where(*conditions)

                result = await session.execute(stmt)
                records = result.scalars().all()

                # 计算总计
                total_input = sum(r.input_tokens for r in records)
                total_output = sum(r.output_tokens for r in records)
                total_tokens = sum(r.total_tokens for r in records)

                response = {
                    "input_tokens": total_input,
                    "output_tokens": total_output,
                    "total_tokens": total_tokens
                }

                # 按用户分组
                if group_by_user:
                    user_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.user_id or "unknown"
                        if key not in user_stats:
                            user_stats[key] = {
                                "input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        user_stats[key]["input_tokens"] += r.input_tokens
                        user_stats[key]["output_tokens"] += r.output_tokens
                        user_stats[key]["total_tokens"] += r.total_tokens

                    response["by_user"] = [
                        {"user_id": uid, **stats}
                        for uid, stats in sorted(user_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                # 按服务分组
                if group_by_service:
                    service_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.service_name or "unknown"
                        if key not in service_stats:
                            service_stats[key] = {
                                "input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        service_stats[key]["input_tokens"] += r.input_tokens
                        service_stats[key]["output_tokens"] += r.output_tokens
                        service_stats[key]["total_tokens"] += r.total_tokens

                    response["by_service"] = [
                        {"service_name": svc, **stats}
                        for svc, stats in sorted(service_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                # 按租户分组
                if group_by_tenant:
                    tenant_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.tenant_id or "unknown"
                        if key not in tenant_stats:
                            tenant_stats[key] = {
                                "input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        tenant_stats[key]["input_tokens"] += r.input_tokens
                        tenant_stats[key]["output_tokens"] += r.output_tokens
                        tenant_stats[key]["total_tokens"] += r.total_tokens

                    response["by_tenant"] = [
                        {"tenant_id": tid, **stats}
                        for tid, stats in sorted(tenant_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                # 按环境分组
                if group_by_env:
                    env_stats: Dict[str, Dict] = {}
                    for r in records:
                        key = r.system_env or "unknown"
                        if key not in env_stats:
                            env_stats[key] = {
                                "input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
                        env_stats[key]["input_tokens"] += r.input_tokens
                        env_stats[key]["output_tokens"] += r.output_tokens
                        env_stats[key]["total_tokens"] += r.total_tokens

                    response["by_env"] = [
                        {"system_env": env, **stats}
                        for env, stats in sorted(env_stats.items(), key=lambda x: x[1]["total_tokens"], reverse=True)[:limit]
                    ]

                return response

        except Exception as e:
            logging.error(f"查询 Token 使用量失败: {e}", exc_info=True)
            return {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    @classmethod
    async def query_usage(
        cls,
        user_ids: Optional[List[str]] = None,
        service_names: Optional[List[str]] = None,
        tenant_ids: Optional[List[str]] = None,
        system_envs: Optional[List[str]] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        group_by: Optional[List[str]] = None,
        include_details: bool = False,
        order_by: str = "total_tokens",
        order_desc: bool = True,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        灵活查询 Token 使用量统计

        Args:
            user_ids: 用户ID列表（可选，支持多用户查询）
            service_names: 服务名称列表（可选，支持多服务查询）
            tenant_ids: 租户ID列表（可选）
            system_envs: 系统环境列表（可选）
            start_date: 开始日期
            end_date: 结束日期
            group_by: 分组维度列表，可选值: ["user_id", "service_name", "tenant_id", "system_env", "date"]
            include_details: 是否包含明细记录
            order_by: 排序字段，默认按 total_tokens
            order_desc: 是否降序，默认 True
            limit: 返回数量限制
            offset: 分页偏移量

        Returns:
            Dict: 包含统计结果和分组数据

        Examples:
            # 按用户维度统计
            await query_usage(group_by=["user_id"])

            # 按服务维度统计
            await query_usage(group_by=["service_name"])

            # 指定时间区间，按服务和用户双维度统计
            await query_usage(
                start_date=date(2024, 1, 1),
                end_date=date(2024, 1, 31),
                group_by=["service_name", "user_id"]
            )

            # 查询特定用户在特定服务的时间区间统计
            await query_usage(
                user_ids=["user1", "user2"],
                service_names=["service-a"],
                start_date=date(2024, 1, 1),
                end_date=date(2024, 1, 31),
                group_by=["user_id", "service_name"]
            )
        """
        if not cls._db_service:
            return {
                "total": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                "groups": [],
                "details": []
            }

        valid_group_fields = {"user_id", "service_name",
                              "tenant_id", "system_env", "date"}
        if group_by:
            group_by = [g for g in group_by if g in valid_group_fields]

        try:
            async with cls._db_service.session() as session:
                # 构建查询条件
                conditions = []

                if user_ids:
                    if len(user_ids) == 1:
                        conditions.append(
                            TokenUsageMySQL.user_id == user_ids[0])
                    else:
                        conditions.append(
                            TokenUsageMySQL.user_id.in_(user_ids))

                if service_names:
                    if len(service_names) == 1:
                        conditions.append(TokenUsageMySQL.service_name == service_names[0])
                    else:
                        conditions.append(TokenUsageMySQL.service_name.in_(service_names))

                if tenant_ids:
                    if len(tenant_ids) == 1:
                        conditions.append(
                            TokenUsageMySQL.tenant_id == tenant_ids[0])
                    else:
                        conditions.append(
                            TokenUsageMySQL.tenant_id.in_(tenant_ids))

                if system_envs:
                    if len(system_envs) == 1:
                        conditions.append(
                            TokenUsageMySQL.system_env == system_envs[0])
                    else:
                        conditions.append(
                            TokenUsageMySQL.system_env.in_(system_envs))

                if start_date:
                    conditions.append(TokenUsageMySQL.usage_date >= start_date)
                if end_date:
                    conditions.append(TokenUsageMySQL.usage_date <= end_date)

                # 查询明细记录
                stmt = select(TokenUsageMySQL)
                if conditions:
                    stmt = stmt.where(*conditions)

                result = await session.execute(stmt)
                records = result.scalars().all()

                # 计算总计
                total_input = sum(r.input_tokens for r in records)
                total_output = sum(r.output_tokens for r in records)
                total_tokens = sum(r.total_tokens for r in records)

                response = {
                    "total": {
                        "input_tokens": total_input,
                        "output_tokens": total_output,
                        "total_tokens": total_tokens,
                        "record_count": len(records)
                    },
                    "groups": [],
                    "details": []
                }

                # 分组统计
                if group_by:
                    group_stats: Dict[tuple, Dict] = {}

                    for r in records:
                        # 构建分组 key
                        key_parts = []
                        for g in group_by:
                            if g == "date":
                                key_parts.append(r.usage_date.isoformat())
                            elif g == "user_id":
                                key_parts.append(r.user_id or "unknown")
                            elif g == "service_name":
                                key_parts.append(r.service_name or "unknown")
                            elif g == "tenant_id":
                                key_parts.append(r.tenant_id or "unknown")
                            elif g == "system_env":
                                key_parts.append(r.system_env or "unknown")

                        key = tuple(key_parts)

                        if key not in group_stats:
                            group_stats[key] = {
                                "input_tokens": 0,
                                "output_tokens": 0,
                                "total_tokens": 0,
                                "record_count": 0
                            }
                            # 添加分组字段
                            for i, g in enumerate(group_by):
                                group_stats[key][g] = key_parts[i]

                        group_stats[key]["input_tokens"] += r.input_tokens
                        group_stats[key]["output_tokens"] += r.output_tokens
                        group_stats[key]["total_tokens"] += r.total_tokens
                        group_stats[key]["record_count"] += 1

                    # 排序
                    def get_sort_value(item):
                        return item[1].get(order_by, 0)

                    sorted_groups = sorted(
                        group_stats.items(),
                        key=get_sort_value,
                        reverse=order_desc
                    )

                    # 分页
                    paginated = sorted_groups[offset:offset + limit]
                    response["groups"] = [stats for _, stats in paginated]
                    response["total_groups"] = len(group_stats)

                # 明细记录
                if include_details:
                    details = []
                    for r in records:
                        details.append({
                            "user_id": r.user_id,
                            "tenant_id": r.tenant_id,
                            "service_name": r.service_name,
                            "system_env": r.system_env,
                            "input_tokens": r.input_tokens,
                            "output_tokens": r.output_tokens,
                            "total_tokens": r.total_tokens,
                            "model": r.model,
                            "usage_date": r.usage_date.isoformat(),
                            "updated_at": r.updated_at.isoformat() if r.updated_at else None
                        })

                    # 按指定字段排序
                    if order_by in details[0] if details else {}:
                        details.sort(key=lambda x: x.get(
                            order_by, 0), reverse=order_desc)

                    response["details"] = details[offset:offset + limit]

                return response

        except Exception as e:
            logging.error(f"查询 Token 使用量失败: {e}", exc_info=True)
            return {
                "total": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                "groups": [],
                "details": []
            }

    @classmethod
    async def get_user_stats(
        cls,
        user_id: str,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """
        查询指定用户的 Token 使用统计（按服务分组）

        Args:
            user_id: 用户ID
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            Dict: 用户在各服务的使用统计
        """
        return await cls.query_usage(
            user_ids=[user_id],
            start_date=start_date,
            end_date=end_date,
            group_by=["service_name"],
            order_by="total_tokens",
            order_desc=True
        )

    @classmethod
    async def get_service_stats(
        cls,
        service_name: str,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """
        查询指定服务的 Token 使用统计（按用户分组）

        Args:
            service_name: 服务名称
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            Dict: 服务中各用户的使用统计
        """
        return await cls.query_usage(
            service_names=[service_name],
            start_date=start_date,
            end_date=end_date,
            group_by=["user_id"],
            order_by="total_tokens",
            order_desc=True
        )
