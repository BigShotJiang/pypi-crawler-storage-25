# -*- coding: utf-8 -*-
"""
带 Token 统计的 LLM 包装类（非结构化输出场景）

用于 wrap_structured=False 时的 Token 统计和 Langfuse 追踪
"""

from typing import Optional, Dict, Any
from langfuse import Langfuse
from langchain_core.language_models import BaseChatModel
from pydantic import BaseModel, Field

from sycommon.config.LLMConfig import LLMConfig
from sycommon.llm.token_usage_mysql_service import TokenUsageMySQLService
from sycommon.tools.merge_headers import get_header_value


class LLMWithTokenTracking(BaseChatModel):
    """
    带Token统计的LLM包装类（非结构化输出场景）
    用于 wrap_structured=False 时的 Token 统计和 Langfuse 追踪

    设计原则：最小化重写，只重写核心的 _generate 和 _agenerate
    所有其他方法（invoke, ainvoke, batch, abatch, stream, astream）
    都会自动通过 BaseChatModel 的默认实现调用这两个核心方法
    """
    llm: BaseChatModel = Field(default=None)
    langfuse: Optional[Langfuse] = Field(default=None, exclude=True)
    llmConfig: Optional[LLMConfig] = Field(default=None, exclude=True)

    def __init__(self, llm: BaseChatModel, langfuse: Langfuse = None, llmConfig: LLMConfig = None, **kwargs):
        super().__init__(llm=llm, langfuse=langfuse, llmConfig=llmConfig, **kwargs)

    def _get_user_id(self) -> Optional[str]:
        """获取当前用户ID（从请求头获取，没有则为空）"""
        from sycommon.logging.kafka_log import SYLogger
        userid = get_header_value(SYLogger.get_headers(), "x-userid-header")
        return userid if userid else None

    def _get_tenant_id(self) -> Optional[str]:
        """获取当前租户ID"""
        from sycommon.logging.kafka_log import SYLogger
        return get_header_value(SYLogger.get_headers(), "x-tenant-header")

    def _record_token_usage(self, usage: Dict[str, Any]):
        """记录 Token 使用量到 MySQL（同步，Fire-and-forget 模式）"""
        if not usage:
            return

        # 检查是否有有效的 token 数据
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)
        if input_tokens == 0 and output_tokens == 0:
            return

        try:
            from sycommon.logging.kafka_log import SYLogger
            SYLogger.debug(
                f"记录 Token 使用量: input={input_tokens}, output={output_tokens}")
            # service_name 和 system_env 由服务内部自动获取
            TokenUsageMySQLService.record_sync(
                user_id=self._get_user_id(),
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model=self.llmConfig.model if self.llmConfig else None,
                tenant_id=self._get_tenant_id()
            )
        except Exception as e:
            from sycommon.logging.kafka_log import SYLogger
            SYLogger.warning(f"Token 使用量记录失败: {e}")

    async def _record_token_usage_async(self, usage: Dict[str, Any]):
        """记录 Token 使用量到 MySQL（异步）"""
        if not usage:
            return

        # 检查是否有有效的 token 数据
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)
        if input_tokens == 0 and output_tokens == 0:
            return

        try:
            from sycommon.logging.kafka_log import SYLogger
            SYLogger.debug(
                f"记录 Token 使用量(async): input={input_tokens}, output={output_tokens}")
            # service_name 和 system_env 由服务内部自动获取
            await TokenUsageMySQLService.record(
                user_id=self._get_user_id(),
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model=self.llmConfig.model if self.llmConfig else None,
                tenant_id=self._get_tenant_id()
            )
        except Exception as e:
            from sycommon.logging.kafka_log import SYLogger
            SYLogger.warning(f"Token 使用量记录失败: {e}")

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        """
        同步生成 - 核心方法
        BaseChatModel 的 invoke/batch/stream 最终都会调用此方法
        """
        result = self.llm._generate(
            messages, stop=stop, run_manager=run_manager, **kwargs)
        return self._inject_token_usage(result, is_async=False)

    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
        """
        异步生成 - 核心方法
        BaseChatModel 的 ainvoke/abatch/astream 最终都会调用此方法
        """
        result = await self.llm._agenerate(messages, stop=stop, run_manager=run_manager, **kwargs)
        return self._inject_token_usage(result, is_async=True)

    def _inject_token_usage(self, result, is_async: bool = False):
        """
        从 LLM 结果中提取 Token 统计并注入到响应消息中
        支持单条和多条 generations

        Args:
            result: LLM 返回结果
            is_async: 是否在异步上下文中调用
        """
        try:
            if hasattr(result, 'generations') and result.generations:
                for gen_group in result.generations:
                    for generation in gen_group:
                        if hasattr(generation, 'message') and generation.message:
                            usage = None
                            # 优先从 generation_info 获取
                            if hasattr(generation, 'generation_info') and generation.generation_info:
                                gen_info = generation.generation_info
                                usage = {
                                    "input_tokens": gen_info.get('input_tokens', gen_info.get('prompt_tokens', 0)),
                                    "output_tokens": gen_info.get('output_tokens', gen_info.get('completion_tokens', 0)),
                                    "total_tokens": gen_info.get('total_tokens', 0)
                                }
                                generation.message._token_usage_ = usage
                            # 从 llm_output 获取（部分模型）
                            elif hasattr(result, 'llm_output') and result.llm_output:
                                llm_output = result.llm_output
                                if 'token_usage' in llm_output:
                                    token_usage = llm_output['token_usage']
                                    usage = {
                                        "input_tokens": token_usage.get('prompt_tokens', token_usage.get('input_tokens', 0)),
                                        "output_tokens": token_usage.get('completion_tokens', token_usage.get('output_tokens', 0)),
                                        "total_tokens": token_usage.get('total_tokens', 0)
                                    }
                                    generation.message._token_usage_ = usage

                            # 从 response_metadata 获取（部分 LangChain 模型，如 ChatOpenAI）
                            elif hasattr(generation.message, 'response_metadata') and generation.message.response_metadata:
                                metadata = generation.message.response_metadata
                                if 'token_usage' in metadata:
                                    token_usage = metadata['token_usage']
                                    usage = {
                                        "input_tokens": token_usage.get('prompt_tokens', token_usage.get('input_tokens', 0)),
                                        "output_tokens": token_usage.get('completion_tokens', token_usage.get('output_tokens', 0)),
                                        "total_tokens": token_usage.get('total_tokens', 0)
                                    }
                                    generation.message._token_usage_ = usage
                                elif 'usage' in metadata:
                                    token_usage = metadata['usage']
                                    usage = {
                                        "input_tokens": token_usage.get('prompt_tokens', token_usage.get('input_tokens', 0)),
                                        "output_tokens": token_usage.get('completion_tokens', token_usage.get('output_tokens', 0)),
                                        "total_tokens": token_usage.get('total_tokens', 0)
                                    }
                                    generation.message._token_usage_ = usage

                            # 记录 Token 使用量
                            if usage and (usage.get('input_tokens', 0) > 0 or usage.get('output_tokens', 0) > 0):
                                # 异步上下文使用 fire-and-forget 模式
                                if is_async:
                                    import asyncio
                                    try:
                                        loop = asyncio.get_running_loop()
                                        loop.create_task(
                                            self._record_token_usage_async(usage))
                                    except RuntimeError:
                                        self._record_token_usage(usage)
                                else:
                                    # 同步上下文使用 record_sync
                                    self._record_token_usage(usage)
                            else:
                                # 调试：打印 result 结构，帮助排查 Token 获取问题
                                from sycommon.logging.kafka_log import SYLogger
                                SYLogger.debug(f"未找到 Token 使用信息，result 类型: {type(result).__name__}, "
                                               f"generation_info: {getattr(generation, 'generation_info', None)}, "
                                               f"llm_output: {getattr(result, 'llm_output', None)}, "
                                               f"response_metadata: {getattr(generation.message, 'response_metadata', None) if hasattr(generation, 'message') else None}")
        except Exception as e:
            from sycommon.logging.kafka_log import SYLogger
            SYLogger.warning(f"Token 统计注入失败: {str(e)}")

        return result

    @property
    def _llm_type(self) -> str:
        return self.llm._llm_type

    def _stream(self, messages, stop=None, run_manager=None, **kwargs):
        """流式生成 - 委托给底层 LLM"""
        yield from self.llm._stream(messages, stop=stop, run_manager=run_manager, **kwargs)

    async def _astream(self, messages, stop=None, run_manager=None, **kwargs):
        """异步流式生成 - 委托给底层 LLM"""
        async for chunk in self.llm._astream(messages, stop=stop, run_manager=run_manager, **kwargs):
            yield chunk

    def __getattr__(self, name):
        """代理所有其他属性到原始 llm（如 model_name, max_tokens, with_structured_output 等）"""
        try:
            return super().__getattribute__(name)
        except AttributeError:
            return getattr(self.llm, name)
