"""
Token 使用量记录专用数据库服务
独立于业务系统的数据库连接，使用 llm 配置中的数据库信息
"""
import logging
from contextlib import asynccontextmanager
from typing import Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
    AsyncEngine,
)

from sycommon.config.Config import SingletonMeta
from sycommon.config.DatabaseConfig import DatabaseConfig, convert_dict_keys
from sycommon.logging.kafka_log import SYLogger


class TokenUsageDBService(metaclass=SingletonMeta):
    """
    Token 使用量记录专用数据库服务

    使用独立的数据库连接，连接到 shengye_platform_ai_middleware 库
    配置来源：Config().config.get("llm", {}).get("spring", {}).get("datasource", {})
    """

    _engine: Optional[AsyncEngine] = None
    _session_factory: Optional[async_sessionmaker] = None
    _initialized: bool = False

    def __init__(self):
        pass

    @classmethod
    def init(cls) -> bool:
        """
        初始化 Token 使用量记录数据库连接

        从 Config().config.get("llm", {}) 中读取数据库配置
        该配置独立于业务系统的数据库配置

        Returns:
            bool: 是否初始化成功
        """
        if cls._initialized:
            return True

        try:
            from sycommon.config.Config import Config

            # 从 llm 配置中获取数据库信息
            llm_config = Config().config.get("llm", {})
            datasource_config = llm_config.get("spring", {}).get("datasource", None)

            if not datasource_config:
                logging.warning("TokenUsageDBService: 未找到 llm.spring.datasource 配置，Token 记录功能将禁用")
                return False

            # 转换配置键名（从 Java 风格转 Python 风格）
            converted_dict = convert_dict_keys(datasource_config)
            db_config = DatabaseConfig.model_validate(converted_dict)

            # 创建数据库连接
            connector = TokenUsageDBConnector(db_config)
            cls._engine = connector.engine

            # 创建 Session 工厂
            cls._session_factory = async_sessionmaker(
                bind=cls._engine,
                class_=AsyncSession,
                expire_on_commit=False
            )

            cls._initialized = True
            logging.info("TokenUsageDBService 初始化成功")
            return True

        except Exception as e:
            logging.error(f"TokenUsageDBService 初始化失败: {e}", exc_info=True)
            return False

    @classmethod
    @asynccontextmanager
    async def session(cls):
        """
        异步数据库会话上下文管理器

        自动处理会话的创建、提交、回滚和关闭
        """
        if not cls._initialized:
            cls.init()

        if not cls._initialized or not cls._session_factory:
            raise RuntimeError("TokenUsageDBService 未初始化成功，无法获取数据库会话")

        async with cls._session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception as e:
                await session.rollback()
                SYLogger.error(f"TokenUsageDBService database operation failed: {str(e)}")
                raise

    @classmethod
    def engine(cls) -> Optional[AsyncEngine]:
        """获取数据库引擎"""
        if not cls._initialized:
            cls.init()
        return cls._engine

    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化"""
        return cls._initialized


class TokenUsageDBConnector(metaclass=SingletonMeta):
    """Token 使用量数据库连接器"""

    def __init__(self, db_config: DatabaseConfig):
        # 从 DatabaseConfig 中提取数据库连接信息
        self.db_user = db_config.username
        self.db_password = db_config.password

        # 提取 URL 中的主机、端口和数据库名
        url_parts = db_config.url.split('//')[1].split('/')
        host_port = url_parts[0].split(':')
        self.db_host = host_port[0]
        self.db_port = host_port[1] if len(host_port) > 1 else '3306'
        self.db_name = url_parts[1].split('?')[0]

        # 提取 URL 中的参数
        params_str = url_parts[1].split('?')[1] if len(url_parts[1].split('?')) > 1 else ''
        params = {}
        for param in params_str.split('&'):
            if param:
                key, value = param.split('=')
                params[key] = value

        # 移除不需要的参数
        for key in ['useUnicode', 'characterEncoding', 'serverTimezone', 'zeroDateTimeBehavior']:
            if key in params:
                del params[key]

        # 构建数据库连接 URL（使用 aiomysql 支持异步）
        self.db_url = f'mysql+aiomysql://{self.db_user}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}'

        # 日志中隐藏密码
        safe_url = f'mysql+aiomysql://{self.db_user}:***@{self.db_host}:{self.db_port}/{self.db_name}'
        SYLogger.info(f"TokenUsageDBService Database URL: {safe_url}")

        # 创建异步引擎
        self.engine = create_async_engine(
            self.db_url,
            connect_args=params,
            pool_size=5,  # Token 记录连接池较小
            max_overflow=10,
            pool_timeout=30,
            pool_recycle=3600,
            pool_pre_ping=True,
            echo=False,
        )

        # 注册 SQL 日志拦截器
        from sycommon.logging.async_sql_logger import AsyncSQLTraceLogger
        AsyncSQLTraceLogger.setup_sql_logging(self.engine)

    async def test_connection(self) -> bool:
        """测试数据库连接"""
        try:
            async with self.engine.connect() as connection:
                await connection.execute(text("SELECT 1"))
                return True
        except Exception as e:
            SYLogger.error(f"TokenUsageDBService connection test failed: {e}")
            return False
