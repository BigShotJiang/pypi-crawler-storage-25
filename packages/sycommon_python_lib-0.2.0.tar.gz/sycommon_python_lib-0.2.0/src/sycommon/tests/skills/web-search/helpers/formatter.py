#!/usr/bin/env python3
"""
搜索结果格式化器
将搜索结果格式化为结构化的 Markdown 输出
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class SearchResult:
    """单个搜索结果"""
    title: str
    url: str
    snippet: str
    source: Optional[str] = None
    date: Optional[str] = None


@dataclass
class SearchReport:
    """搜索报告"""
    query: str
    results: List[SearchResult]
    key_findings: List[str]
    summary: str
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")


def format_search_report(
    query: str,
    results: List[SearchResult],
    key_findings: List[str],
    summary: str,
    suggestions: Optional[List[str]] = None
) -> str:
    """
    格式化搜索报告为 Markdown
    
    Args:
        query: 原始搜索查询
        results: 搜索结果列表
        key_findings: 关键发现列表
        summary: 总结文本
        suggestions: 后续建议（可选）
    
    Returns:
        Markdown 格式的报告
    """
    lines = []
    
    # 标题
    lines.append(f"## 搜索结果: {query}")
    lines.append("")
    lines.append(f"> 搜索时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("")
    
    # 关键发现
    lines.append("### 🔍 关键发现")
    lines.append("")
    for i, finding in enumerate(key_findings, 1):
        lines.append(f"{i}. {finding}")
    lines.append("")
    
    # 详细总结
    lines.append("### 📝 详细信息")
    lines.append("")
    lines.append(summary)
    lines.append("")
    
    # 来源列表
    lines.append("### 📚 来源")
    lines.append("")
    for i, result in enumerate(results, 1):
        source_info = f"**{result.title}**"
        if result.date:
            source_info += f" ({result.date})"
        lines.append(f"{i}. [{source_info}]({result.url})")
        if result.snippet:
            lines.append(f"   > {result.snippet}")
    lines.append("")
    
    # 后续建议
    if suggestions:
        lines.append("### 💡 建议")
        lines.append("")
        for suggestion in suggestions:
            lines.append(f"- {suggestion}")
        lines.append("")
    
    return "\n".join(lines)


def format_quick_result(
    query: str,
    answer: str,
    sources: List[SearchResult]
) -> str:
    """
    格式化快速回答
    
    Args:
        query: 搜索查询
        answer: 直接回答
        sources: 来源列表
    
    Returns:
        Markdown 格式的快速结果
    """
    lines = []
    
    lines.append(f"### {query}")
    lines.append("")
    lines.append(answer)
    lines.append("")
    
    if sources:
        lines.append("**来源:**")
        for source in sources[:3]:  # 最多显示3个来源
            lines.append(f"- [{source.title}]({source.url})")
    
    return "\n".join(lines)


def format_comparison(
    topic: str,
    items: List[dict]
) -> str:
    """
    格式化对比表格
    
    Args:
        topic: 对比主题
        items: 对比项列表，每项包含 name 和多个属性
    
    Returns:
        Markdown 格式的对比表格
    """
    lines = []
    
    lines.append(f"### {topic} 对比")
    lines.append("")
    
    if not items:
        return "暂无对比数据"
    
    # 获取所有属性名
    all_keys = set()
    for item in items:
        all_keys.update(item.keys())
    all_keys.discard("name")
    headers = ["名称"] + sorted(all_keys)
    
    # 表头
    lines.append("| " + " | ".join(headers) + " |")
    lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
    
    # 表格内容
    for item in items:
        row = [item.get("name", "")]
        for key in sorted(all_keys):
            row.append(str(item.get(key, "-")))
        lines.append("| " + " | ".join(row) + " |")
    
    return "\n".join(lines)


# 示例用法
if __name__ == "__main__":
    # 示例搜索结果
    results = [
        SearchResult(
            title="Python 官方文档 - 异步编程",
            url="https://docs.python.org/3/library/asyncio.html",
            snippet="Python 的异步 I/O 框架，提供编写并发代码的基础设施",
            source="docs.python.org",
            date="2024"
        ),
        SearchResult(
            title="异步编程最佳实践",
            url="https://example.com/async-best-practices",
            snippet="介绍 Python 异步编程的常见模式和反模式",
            source="example.com"
        )
    ]
    
    # 格式化完整报告
    print(format_search_report(
        query="Python async/await 教程",
        results=results,
        key_findings=[
            "asyncio 是 Python 标准库中的异步框架",
            "使用 async def 定义协程函数",
            "await 用于等待异步操作完成"
        ],
        summary="Python 的异步编程通过 asyncio 库实现，使用 async/await 语法。\n主要适用于 I/O 密集型任务，可以显著提高并发性能。",
        suggestions=[
            "深入了解 asyncio 的事件循环机制",
            "学习如何处理异步上下文中的异常"
        ]
    ))
