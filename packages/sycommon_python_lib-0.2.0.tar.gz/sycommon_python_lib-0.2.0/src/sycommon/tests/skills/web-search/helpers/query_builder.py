#!/usr/bin/env python3
"""
搜索查询构建器
帮助构建优化的搜索查询字符串
"""

from typing import List, Optional
from urllib.parse import quote


class SearchQueryBuilder:
    """构建优化的搜索查询"""
    
    def __init__(self):
        self.keywords: List[str] = []
        self.exact_phrases: List[str] = []
        self.exclude_terms: List[str] = []
        self.site_limits: List[str] = []
        self.file_types: Optional[str] = None
    
    def add_keyword(self, keyword: str) -> "SearchQueryBuilder":
        """添加关键词"""
        self.keywords.append(keyword)
        return self
    
    def add_exact_phrase(self, phrase: str) -> "SearchQueryBuilder":
        """添加精确短语（会用引号包裹）"""
        self.exact_phrases.append(phrase)
        return self
    
    def exclude(self, term: str) -> "SearchQueryBuilder":
        """排除词（添加减号前缀）"""
        self.exclude_terms.append(term)
        return self
    
    def limit_to_site(self, site: str) -> "SearchQueryBuilder":
        """限定搜索站点"""
        self.site_limits.append(site)
        return self
    
    def set_file_type(self, file_type: str) -> "SearchQueryBuilder":
        """限定文件类型（如 pdf, doc）"""
        self.file_type = file_type
        return self
    
    def build(self) -> str:
        """构建最终搜索查询字符串"""
        parts = []
        
        # 添加关键词
        parts.extend(self.keywords)
        
        # 添加精确短语
        for phrase in self.exact_phrases:
            parts.append(f'"{phrase}"')
        
        # 添加排除词
        for term in self.exclude_terms:
            parts.append(f"-{term}")
        
        # 添加站点限制
        for site in self.site_limits:
            parts.append(f"site:{site}")
        
        # 添加文件类型
        if self.file_type:
            parts.append(f"filetype:{self.file_type}")
        
        return " ".join(parts)
    
    def build_url_encoded(self) -> str:
        """构建 URL 编码的查询字符串"""
        return quote(self.build())
    
    def reset(self) -> "SearchQueryBuilder":
        """重置所有条件"""
        self.keywords = []
        self.exact_phrases = []
        self.exclude_terms = []
        self.site_limits = []
        self.file_types = None
        return self


def quick_search(query: str, site: Optional[str] = None) -> str:
    """
    快速构建搜索查询
    
    Args:
        query: 搜索内容
        site: 可选的站点限制
    
    Returns:
        优化后的搜索字符串
    """
    builder = SearchQueryBuilder()
    builder.add_keyword(query)
    if site:
        builder.limit_to_site(site)
    return builder.build()


# 示例用法
if __name__ == "__main__":
    # 示例1: 简单搜索
    print("简单搜索:")
    builder = SearchQueryBuilder()
    builder.add_keyword("Python").add_keyword("async").add_keyword("tutorial")
    print(f"  {builder.build()}")
    
    # 示例2: 精确短语搜索
    print("\n精确短语搜索:")
    builder.reset()
    builder.add_exact_phrase("machine learning").add_keyword("beginner")
    print(f"  {builder.build()}")
    
    # 示例3: 站内搜索
    print("\n站内搜索:")
    builder.reset()
    builder.add_keyword("async await").limit_to_site("docs.python.org")
    print(f"  {builder.build()}")
    
    # 示例4: 排除搜索
    print("\n排除搜索:")
    builder.reset()
    builder.add_keyword("python").exclude("snake").exclude("monty")
    print(f"  {builder.build()}")
    
    # 示例5: 文件类型搜索
    print("\n文件类型搜索:")
    builder.reset()
    builder.add_keyword("API documentation").set_file_type("pdf")
    print(f"  {builder.build()}")
    
    # 示例6: 复杂组合
    print("\n复杂组合搜索:")
    builder.reset()
    (builder
     .add_keyword("Docker")
     .add_keyword("compose")
     .add_exact_phrase("best practices")
     .exclude("windows")
     .limit_to_site("docs.docker.com"))
    print(f"  {builder.build()}")
