import json
import threading
import time
from typing import Callable, Optional, Dict, List
from sycommon.synacos.nacos_client_base import NacosClientBase
import yaml
from sycommon.logging.kafka_log import SYLogger


class NacosConfigManager:
    """Nacos配置管理类 - 负责配置读取和监听"""

    def __init__(self, client_base: NacosClientBase):
        self.client_base = client_base

        # 状态
        self.share_configs: Dict = {}
        self._config_listeners: Dict[str, Callable[[str], None]] = {}
        self._config_cache: Dict[str, str] = {}
        # Nacos原生监听器跟踪
        self._nacos_watchers: Dict[str, bool] = {}
        self._watcher_lock = threading.Lock()

    def read_configs(self, shared_configs: List[Dict]) -> dict:
        """读取共享配置"""
        configs = {}

        for config in shared_configs:
            data_id = config['dataId']
            group = config.get('group', 'DEFAULT_GROUP')

            for attempt in range(self.client_base.max_retries):
                try:
                    if not self.client_base.ensure_client_connected():
                        self.client_base.reconnect_nacos_client()

                    content = self.client_base.nacos_client.get_config(
                        data_id, group)

                    # 缓存原始内容
                    self._config_cache[data_id] = content

                    try:
                        configs[data_id] = json.loads(content)
                    except json.JSONDecodeError:
                        try:
                            configs[data_id] = yaml.safe_load(content)
                        except yaml.YAMLError:
                            SYLogger.error(f"nacos:无法解析 {data_id} 的内容")
                    break
                except Exception as e:
                    if attempt < self.client_base.max_retries - 1:
                        SYLogger.warning(
                            f"nacos:读取配置 {data_id} 失败 (尝试 {attempt+1}/{self.client_base.max_retries}): {e}")
                        time.sleep(self.client_base.retry_delay)
                    else:
                        SYLogger.error(
                            f"nacos:读取配置 {data_id} 失败，已达到最大重试次数: {e}")

        self.share_configs = configs
        return configs

    def add_config_listener(self, data_id: str, callback: Callable[[str], None], group: str = "DEFAULT_GROUP"):
        """添加配置变更监听器（支持热响应）"""
        self._config_listeners[data_id] = callback

        # 立即触发一次回调
        if config := self.get_config(data_id, group):
            self._config_cache[data_id] = config
            callback(config)

        # 注册Nacos原生监听器实现热响应
        self._register_nacos_watcher(data_id, group)

    def _register_nacos_watcher(self, data_id: str, group: str = "DEFAULT_GROUP"):
        """注册Nacos原生配置监听器（实时热响应）"""
        with self._watcher_lock:
            watcher_key = f"{data_id}:{group}"
            if watcher_key in self._nacos_watchers:
                return

            if not self.client_base.ensure_client_connected():
                return

            try:
                def config_change_callback(args):
                    """Nacos配置变更回调"""
                    try:
                        new_content = args.get('content') if isinstance(args, dict) else args
                        if new_content:
                            SYLogger.info(f"nacos:检测到配置变更 - dataId: {data_id}")

                            # 更新缓存
                            self._config_cache[data_id] = new_content

                            # 解析新配置
                            try:
                                self.share_configs[data_id] = json.loads(new_content)
                            except json.JSONDecodeError:
                                try:
                                    self.share_configs[data_id] = yaml.safe_load(new_content)
                                except yaml.YAMLError:
                                    SYLogger.error(f"nacos:无法解析变更后的配置 {data_id}")
                                    return

                            # 触发用户回调
                            if data_id in self._config_listeners:
                                self._config_listeners[data_id](new_content)

                            # 同步更新到全局 Config 单例
                            self._sync_to_global_config()

                            SYLogger.info(f"nacos:配置热更新完成 - dataId: {data_id}")
                    except Exception as e:
                        SYLogger.error(f"nacos:配置变更回调处理失败: {e}")

                # 使用Nacos SDK的原生监听器
                self.client_base.nacos_client.add_config_watcher(
                    data_id=data_id,
                    group=group,
                    cb=config_change_callback
                )
                self._nacos_watchers[watcher_key] = True
                SYLogger.info(f"nacos:已注册配置监听器 - dataId: {data_id}, group: {group}")

            except Exception as e:
                SYLogger.error(f"nacos:注册配置监听器失败 - dataId: {data_id}: {e}")

    def get_config(self, data_id: str, group: str = "DEFAULT_GROUP") -> Optional[str]:
        """获取配置内容"""
        if not self.client_base.ensure_client_connected():
            return None

        try:
            return self.client_base.nacos_client.get_config(data_id, group=group)
        except Exception as e:
            SYLogger.error(f"nacos:获取配置 {data_id} 失败: {str(e)}")
            return None

    def _sync_to_global_config(self):
        """同步配置到全局 Config 单例

        当 Nacos 配置变更时，更新 Config 单例中的 LLMConfig 等配置，
        使得 get_llm() 等函数能获取到最新的配置。
        """
        try:
            from sycommon.config.Config import Config
            Config().set_attr(self.share_configs)
            SYLogger.debug("nacos:配置已同步到全局 Config 单例")
        except Exception as e:
            SYLogger.error(f"nacos:同步配置到全局单例失败: {e}")
