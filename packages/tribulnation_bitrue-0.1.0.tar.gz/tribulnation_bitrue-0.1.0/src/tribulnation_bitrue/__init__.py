"""
### Tribulnation Bitrue
> An SDK to connect Bitrue with the Tribulnation ecosystem.

- Details
"""