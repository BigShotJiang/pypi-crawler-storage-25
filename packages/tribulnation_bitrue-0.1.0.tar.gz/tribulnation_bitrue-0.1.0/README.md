# Tribulnation Bitrue SDK

> An SDK to connect Bitrue with the Tribulnation ecosystem.

🚧 Under construction.