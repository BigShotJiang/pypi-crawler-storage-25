"""Knowledge graph package."""
