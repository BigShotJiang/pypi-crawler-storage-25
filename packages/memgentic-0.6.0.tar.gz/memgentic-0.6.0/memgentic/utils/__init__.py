"""Memgentic utility helpers."""
