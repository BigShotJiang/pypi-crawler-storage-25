from typing import Any, Generic, TypeVar
from uuid import UUID

import requests
from deprecation import deprecated
from picsellia import Datalake, ModelVersion

from picsellia_cv_engine.core.contexts.processing.common.picsellia_context import (
    PicselliaProcessingContext,
)
from picsellia_cv_engine.core.parameters import Parameters

TParameters = TypeVar("TParameters", bound=Parameters)


class PicselliaDatalakeProcessingContext(
    PicselliaProcessingContext, Generic[TParameters]
):
    """
    Context for running Picsellia datalake processing jobs.
    """

    def __init__(
        self,
        processing_parameters_cls: type[TParameters],
        api_token: str | None = None,
        host: str | None = None,
        organization_id: str | None = None,
        organization_name: str | None = None,
        job_id: str | None = None,
        use_id: bool | None = True,
        working_dir: str | None = None,
    ):
        super().__init__(
            processing_parameters_cls=processing_parameters_cls,
            api_token=api_token,
            host=host,
            organization_id=organization_id,
            organization_name=organization_name,
            job_id=job_id,
            use_id=use_id,
            working_dir=working_dir,
        )

        self.data_ids = self.get_data_ids()
        self.target = self.client.get_datalake(id=self.target_id)

    def get_data_ids(self) -> list[UUID]:
        """
        Retrieve data IDs from the job payload.

        Raises:
            ValueError: If the payload URL is missing or invalid.
        """
        if not self.payload_presigned_url:
            raise ValueError("Payload presigned URL not found.")
        payload = requests.get(self.payload_presigned_url).json()
        return [UUID(data_id) for data_id in payload["data_ids"]]

    def to_dict(self) -> dict[str, Any]:
        base = super().to_dict()
        base.update(
            {
                "model_version_id": self._model_version_id,
                "input_datalake_id": self._input_datalake_id,
                "output_datalake_id": self._output_datalake_id,
            }
        )
        return base

    def _load_legacy_inputs(self) -> None:
        self._model_version_id = self.inputs.get("model_version_id")
        self._input_datalake_id = self.target_id
        self._output_datalake_id = self.inputs.get("output_datalake_id")

        if not self._input_datalake_id:
            raise ValueError("Input datalake ID not found.")

        self.input_datalake = self.get_datalake(self._input_datalake_id)
        self.output_datalake = (
            self.get_datalake(self._output_datalake_id)
            if self._output_datalake_id
            else None
        )

        self.model_version = (
            self.get_model_version() if self._model_version_id else None
        )

    @deprecated(
        details="get_datalake will be removed in a future version. Use the new input system instead."
    )
    def get_datalake(self, datalake_id: str) -> Datalake:
        return self.client.get_datalake(id=datalake_id)

    @deprecated(
        details="get_model_version will be removed in a future version. Use the new input system instead."
    )
    def get_model_version(self) -> ModelVersion:
        return self.client.get_model_version_by_id(self._model_version_id)
