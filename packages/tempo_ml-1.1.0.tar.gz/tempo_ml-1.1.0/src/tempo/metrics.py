import numpy as np
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, f1_score, roc_auc_score,
    average_precision_score, confusion_matrix, precision_score, recall_score
)
from sklearn.preprocessing import label_binarize

def evaluate_predictions(y_true, preds, probs, n_classes):
    """Calculates your comprehensive suite of performance metrics."""
    y_test_bin = label_binarize(y_true, classes=range(n_classes))
    cm = confusion_matrix(y_true, preds)
    
    specs, npvs = [], []
    for i in range(n_classes):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        tn = cm.sum() - (tp + fp + fn)
        specs.append(tn / (tn + fp + 1e-9))
        npvs.append(tn / (tn + fn + 1e-9))

    return {
        "Accuracy": accuracy_score(y_true, preds),
        "Balanced Accuracy": balanced_accuracy_score(y_true, preds),
        "AUC (Macro)": roc_auc_score(y_test_bin, probs, multi_class='ovr', average='macro'),
        "AUCPRC (Macro)": average_precision_score(y_test_bin, probs, average='macro'),
        "F1 Macro": f1_score(y_true, preds, average='macro'),
        "PPV (Precision)": precision_score(y_true, preds, average='macro', zero_division=0),
        "NPV": np.mean(npvs),
        "Sensitivity (Recall)": recall_score(y_true, preds, average='macro'),
        "Specificity": np.mean(specs)
    }