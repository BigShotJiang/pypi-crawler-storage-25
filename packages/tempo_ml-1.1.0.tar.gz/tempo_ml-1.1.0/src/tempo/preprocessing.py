import pandas as pd
import numpy as np
import gc
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split

def prepare_omics_efficient(files, subtype_file, save_path='processed_data.pkl'):
    print("Starting Energy-Efficient Alignment...")

    subtypes = pd.read_csv(subtype_file, sep='\t', index_col=0)
    subtypes.index = subtypes.index.str.replace('.', '-', regex=False).str.upper()
    subtypes = subtypes.dropna(subset=[subtypes.columns[0]])
    common_samples = subtypes.index
    y = subtypes.iloc[:, 0].values

    X_parts = []
    omic_dims = []

    for file in files:
        try:
            print(f"Processing {file}...")
            df = pd.read_csv(file, sep='\t', index_col=0).T
            df.index = df.index.str.replace('.', '-', regex=False).str.upper()
            df = df.reindex(common_samples)

            df = df.dropna(axis=1, how='all')
            df = df.loc[:, df.nunique() > 1]

            if df.shape[1] == 0:
                print(f"Skipping {file}: No overlap found.")
                continue

            for col in df.select_dtypes(include=['object']).columns:
                df[col] = pd.factorize(df[col])[0]

            val = df.fillna(0).values
            val = StandardScaler().fit_transform(val)

            if df.shape[1] > 2000:
                print(f"PCA reducing {file} from {df.shape[1]} to 500 features...")
                n_comp = min(500, df.shape[0], df.shape[1])
                pca = PCA(n_components=n_comp, random_state=42)
                combined = pca.fit_transform(val).astype(np.float32)
            else:
                print(f"Keeping raw features + mask for {file}...")
                mask = df.notna().astype(np.float32).values
                combined = np.hstack([val, mask]).astype(np.float32)

            X_parts.append(combined)
            omic_dims.append(combined.shape[1])
            del df, val; gc.collect()

        except Exception as e:
            print(f"Error on {file}: {e}")
            continue

    print("Combining parts...")
    X_all = np.concatenate(X_parts, axis=1)
    del X_parts; gc.collect()

    print("Splitting...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_all, y, test_size=0.2, stratify=y, random_state=42
    )
    del X_all; gc.collect()

    data = {'X_train': X_train, 'X_test': X_test, 'y_train': y_train, 'y_test': y_test, 'omic_dims': omic_dims}
    
    if save_path:
        with open(save_path, 'wb') as f:
            pickle.dump(data, f, protocol=4)
        print(f"DONE. Final features: {sum(omic_dims)}. Saved to {save_path}")
        
    return (X_train, X_test, y_train, y_test), omic_dims