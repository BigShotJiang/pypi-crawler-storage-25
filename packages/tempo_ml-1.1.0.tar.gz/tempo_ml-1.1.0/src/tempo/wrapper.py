import torch
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
import numpy as np
import time

from tempo.models import TEMPO, FocalLoss
from tempo.metrics import evaluate_predictions

class TempoClassifier:
    """A scikit-learn style wrapper for the TEMPO neural network."""
    def __init__(self, omic_dims, n_classes, n_hid=9, steps=16, lr=1e-3, epochs=50, batch_size=64):
        self.omic_dims = omic_dims
        self.n_classes = n_classes
        self.epochs = epochs
        self.batch_size = batch_size
        
        self.model = TEMPO(omic_dims, n_hid, n_classes, steps)
        self.optimizer = optim.AdamW(self.model.parameters(), lr=lr, weight_decay=0.01)
        self.criterion = None # Will be initialized in fit() based on class weights

    def _split_to_list(self, X):
        curr, out = 0, []
        for d in self.omic_dims: 
            out.append(torch.tensor(X[:, curr:curr+d]).float())
            curr += d
        return out

    def fit(self, X_train, y_train):
        print("⚙️ Training TEMPO Model...")
        class_counts = np.bincount(y_train)
        soft_weights = torch.tensor(np.sqrt(len(y_train) / (class_counts * self.n_classes)), dtype=torch.float)
        self.criterion = FocalLoss(alpha=soft_weights, gamma=1.0)

        x_train_list = self._split_to_list(X_train)
        sampler = WeightedRandomSampler(soft_weights[y_train], len(y_train))
        train_loader = DataLoader(TensorDataset(*x_train_list, torch.tensor(y_train)), 
                                  batch_size=self.batch_size, sampler=sampler)

        for epoch in range(self.epochs):
            self.model.train()
            for batch in train_loader:
                self.optimizer.zero_grad()
                logits, _ = self.model(batch[:-1])
                loss = self.criterion(logits, batch[-1])
                loss.backward()
                self.optimizer.step()
        return self

    def predict(self, X_test, y_test=None):
        self.model.eval()
        x_test_list = self._split_to_list(X_test)
        
        with torch.no_grad():
            start_lat = time.time()
            logits, _ = self.model(x_test_list, training=False)
            latency = (time.time() - start_lat) / len(X_test)
            
            flops_per_sample, synops_per_sample = self.model.calculate_efficiency(len(X_test))
            probs = torch.softmax(logits, dim=1).numpy()
            preds = torch.argmax(logits, dim=1).numpy()

        results = {
            "Predictions": preds,
            "Probabilities": probs,
            "Efficiency": {
                "FLOPs/Sample": flops_per_sample,
                "SynOps/Sample": synops_per_sample,
                "Latency": latency
            }
        }
        
        # If true labels are provided, evaluate metrics automatically
        if y_test is not None:
            metrics = evaluate_predictions(y_test, preds, probs, self.n_classes)
            results["Metrics"] = metrics
            
        return results