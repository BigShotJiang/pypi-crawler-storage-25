import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from snntorch import surrogate, leaky, spikegen

class FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=1.0, reduction='mean'):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', weight=self.alpha)
        pt = torch.exp(-ce_loss)
        focal_loss = ((1 - pt) ** self.gamma) * ce_loss
        return focal_loss.mean() if self.reduction == 'mean' else focal_loss.sum()

class TEMPO(nn.Module):
    def __init__(self, omic_dims, n_hid, n_out, steps=16):
        super().__init__()
        self.omic_dims = omic_dims
        self.n_hid_fft = 2**(int(n_hid) - 1).bit_length()
        self.steps = steps
        self.n_modalities = len(omic_dims)
        self.n_out = n_out

        # Analog Front-end
        self.encoders = nn.ModuleList([
            nn.Sequential(nn.Linear(d, 128), nn.BatchNorm1d(128), nn.GELU()) for d in omic_dims
        ])
        self.router = nn.Sequential(
            nn.Linear(128 * self.n_modalities, 64),
            nn.GELU(),
            nn.Linear(64, self.n_modalities)
        )
        self.fusion_net = nn.Linear(128 * self.n_modalities, self.n_hid_fft)

        # Spiking Back-end
        self.spike_bn = nn.BatchNorm1d(self.n_hid_fft)
        self.spa_pointer = nn.Parameter(torch.randn(self.n_hid_fft))
        self.lif = leaky.Leaky(beta=0.8, spike_grad=surrogate.atan(), init_hidden=False)
        self.output_layer = nn.Linear(self.n_hid_fft, n_out)

        self.spk_in_count = 0
        self.spk_hid_count = 0

    def forward(self, x_omics, training=True):
        self.spk_in_count = 0
        self.spk_hid_count = 0

        enc_outs = [enc(x) for enc, x in zip(self.encoders, x_omics)]
        cat_vec = torch.cat(enc_outs, dim=-1)
        route_weights = F.gumbel_softmax(self.router(cat_vec), tau=0.8, hard=not training)

        fused_vec = self.fusion_net(torch.cat([
            enc_outs[i] * route_weights[:, i].unsqueeze(-1) for i in range(self.n_modalities)
        ], dim=-1))

        # Semantic Addressing (FFT)
        x_fft = torch.fft.rfft(fused_vec, n=self.n_hid_fft)
        p_fft = torch.fft.rfft(self.spa_pointer, n=self.n_hid_fft)
        semantic_gate = torch.sigmoid(torch.fft.irfft(x_fft * torch.conj(p_fft), n=self.n_hid_fft))

        spk_in = spikegen.rate(torch.sigmoid(fused_vec), num_steps=self.steps)
        self.spk_in_count = spk_in.sum().item()

        spk_rec = []
        mem = self.lif.init_leaky()

        for t in range(self.steps):
            curr = self.spike_bn(spk_in[t] * semantic_gate)
            spk, mem = self.lif(curr, mem)
            spk_rec.append(spk)
            self.spk_hid_count += spk.sum().item()

        return self.output_layer(torch.stack(spk_rec).mean(0)), torch.stack(spk_rec)

    def calculate_efficiency(self, batch_size):
        enc_flops = sum([d * 128 for d in self.omic_dims])
        router_flops = (128 * self.n_modalities * 64) + (64 * self.n_modalities)
        fusion_flops = (128 * self.n_modalities * self.n_hid_fft)
        fft_flops = 5 * self.n_hid_fft * np.log2(self.n_hid_fft + 1e-9)
        total_flops = enc_flops + router_flops + fusion_flops + fft_flops
        total_synops = (self.spk_in_count + (self.spk_hid_count * self.n_out)) / batch_size
        return total_flops, total_synops