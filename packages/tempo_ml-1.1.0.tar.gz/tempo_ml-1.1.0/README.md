# TEMPO: A Hybrid-Neuromorphic Pipeline for Efficient Multi-Omic Cancer Data Integration

TEMPO is a professional-grade, energy-efficient Python package designed for multi-omic cancer data integraton. Using an innovative hybrid ANN-SNN hybrid model and advanced features, TEMPO has drastically reduces computational overhead (Synaptic Operations and FLOPs) while maintaining state-of-the-art classification performance on highly imbalanced pan-cancer datasets.

---

## Key Features

* **Multi-Omic Integration:** Seamlessly aligns disparate modalities (e.g., mRNA expression, Proteomics, CNV, Clinical data).
* **Neuromorphic Efficiency:** Leverages Leaky Integrate-and-Fire (LIF) neurons to minimize computational power.
* **Smart Routing & Gating:** Implements Gumbel-Softmax modality routing and Fast Fourier Transform (FFT) semantic addressing.
* **Scikit-Learn Style API:** Clean, intuitive `.fit()` and `.predict()` wrapper built over PyTorch execution blocks.
* **Imbalance-Aware:** Built-in balanced Focal Loss and automated sample weighting to handle rare cancer subtypes.

---

## Installation

To install TEMPO locally in editable development mode, navigate to your root package directory and run:

```bash
pip install -e .
