import numpy as np
from tempo import TempoClassifier

def test_tempo_classifier_shapes():
    """Test that the classifier accepts data, trains, and outputs the correct shapes."""
    # Tiny synthetic dataset for rapid testing
    omic_dims = [50, 50] # 2 modalities, 50 features each
    n_classes = 3
    num_samples = 10
    total_features = sum(omic_dims)
    
    X = np.random.randn(num_samples, total_features).astype(np.float32)
    y = np.random.randint(0, n_classes, size=(num_samples,))

    # Initialize with 1 epoch just to test the forward/backward pass
    clf = TempoClassifier(omic_dims=omic_dims, n_classes=n_classes, epochs=1, batch_size=2)
    
    # Test Training
    clf.fit(X, y)
    
    # Test Inference
    results = clf.predict(X)
    
    # Assertions to guarantee the package is working properly
    assert len(results["Predictions"]) == num_samples, "Output prediction length mismatch."
    assert results["Probabilities"].shape == (num_samples, n_classes), "Probability shape mismatch."
    assert "Efficiency" in results, "Efficiency metrics are missing from output."
    print("success")