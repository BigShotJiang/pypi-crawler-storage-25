import os, requests, sys, json
from ..models.enums import EnvironmentVariablesEnum
from ..models.pipeline_details import PipelineDetails

class DataConnectorAPI:
    def __init__(self, environment = None):
        self.server_endpoint = os.environ.get(EnvironmentVariablesEnum.SERVER_ENDPOINT.value)
        self.pipeline_id = os.environ.get(EnvironmentVariablesEnum.PIPELINE_ID.value)
        self.server_api_key = os.environ.get(EnvironmentVariablesEnum.SERVER_API_KEY.value)
        self.pipelines_base_url = f"{self.server_endpoint}/api/pipelines"

    def get(self, endpoint):
        return self._request("GET", endpoint)

    def post(self, endpoint, body=None):
        return self._request("POST", endpoint, body)

    def put(self, endpoint, body=None):
        return self._request("PUT", endpoint, body)

    def log(self, message, stage, task, error=None, internal=False):
        print("Log Output: ", message)
        PIPELINE_RUN_HISTORY_ID = os.environ.get(EnvironmentVariablesEnum.PIPELINE_RUN_HISTORY_ID.value)
        payload = {
            'PipelineID': self.pipeline_id,
            'PipelineRunHistoryID': PIPELINE_RUN_HISTORY_ID,
            'LogStageID': stage,
            'LogTXT': message,
            'ExternalFacingFLG': 0 if internal else 1,
            'ErrorLocationDSC': None, # TODO: UPDATE THIS
            'LogTypeCD': 2 if error else 1,
            'LogTypeDSC': 'Error' if error else 'Info',
            'task': task,
        }

        self.post('log', payload)

    def logv2(self, logger_payload):
        PIPELINE_RUN_HISTORY_ID = os.environ.get(EnvironmentVariablesEnum.PIPELINE_RUN_HISTORY_ID.value)
        payload = {
            'PipelineID': self.pipeline_id,
            'PipelineRunHistoryID': PIPELINE_RUN_HISTORY_ID,
            **logger_payload
        }

        self.post('logv2', payload)

    def get_pipeline_details(self, pipeline_id: str, task, pipeline_run_history_id: str, pipeline_mapping_id: str = None):
        url = f"{pipeline_id}"
        if pipeline_mapping_id:
            url = f"{url}?PipelineMappingID={pipeline_mapping_id}"
        json = self.get(url)

        return PipelineDetails(json, task, pipeline_id, pipeline_run_history_id)

    def create_new_history(self, pipeline_id, pipeline_mapping_id: str = None):
        if pipeline_mapping_id:
            body = {"PipelineMappingID": pipeline_mapping_id}
        else:
            body = None
        response = self.post(f"{pipeline_id}/history", body)

        return response['PipelineRunHistoryID']

    def send_new_credentials(self, source_flg, pipeline_id, credentials):
        self.post(f"credentials/{pipeline_id}", {"source": source_flg, "credentials": json.dumps(credentials)})

    def get_credential_updates(self, source_flg, pipeline_id):
        response = self.get(f"credentials/{pipeline_id}?source={'true' if source_flg else 'false'}")

        return response

    def _request(self, method, endpoint, body=None):
        url = f"{self.pipelines_base_url}/{endpoint}"

        try:
            response = requests.request(
                method=method,
                url=url,
                data=body,
                headers={
                    'Accept': 'application/json',
                    'x-data-connector-access-token': self.server_api_key
                },
                timeout=10  # 🔥 IMPORTANT
            )

            # Try to parse JSON safely
            try:
                response_data = response.json()
            except ValueError:
                response_data = response.text

            if response.ok:
                return response_data
            else:
                raise Exception(
                    f"API ERROR: {method} {endpoint} failed | "
                    f"Status: {response.status_code} | "
                    f"Response: {response_data}"
                )

        except requests.exceptions.Timeout:
            raise Exception(
                f"API ERROR: {method} {endpoint} timed out (10s)"
            )

        except requests.exceptions.ConnectionError:
            raise Exception(
                f"API ERROR: {method} {endpoint} failed — no response from server"
            )

        except requests.exceptions.RequestException as e:
            raise Exception(
                f"API ERROR: {method} {endpoint} unexpected error | {str(e)}"
            )
