from importlib.metadata import version
from dc_sdk.src.services.environment import PipelineEnvironment

PipelineEnvironment.validate_environment()

import os, sys, json, traceback
from dc_sdk.src.models.enums import RunStagesEnum, TasksEnum, UpdateRunHistoryActionEnum, EnvironmentVariablesEnum
from dc_sdk.src.services.api import DataConnectorAPI
from datetime import datetime, timezone
from dc_sdk.src.pipeline import PipelineConductor
from dc_sdk.src.models.errors import Error
from dc_sdk.errors import Error as SDKError

TASK = PipelineEnvironment.task
PIPELINE_ID = PipelineEnvironment.pipeline_id
APP_ENV = PipelineEnvironment.app_env
api = DataConnectorAPI()

is_source = TasksEnum.SOURCE.value == TASK
print("Initialized Connector task: ", TASK)

def run_pipeline():
    print("version: ", version("dc-python-sdk"))
    try:
        if PipelineEnvironment.pipeline_run_history_id is None:
            pipeline_run_history_id = api.create_new_history(PipelineEnvironment.pipeline_id)
            PipelineEnvironment.set_pipeline_run_history_id(pipeline_run_history_id)
        
        pipeline_conductor = PipelineConductor(PipelineEnvironment.task, pipeline_id=PipelineEnvironment.pipeline_id, pipeline_run_history_id=PipelineEnvironment.pipeline_run_history_id, pipeline_mapping_id=PipelineEnvironment.pipeline_mapping_id if PipelineEnvironment.pipeline_mapping_id else None)
        pipeline_conductor.internal_log(pipeline_conductor.log_templates.INTERNAL_CONNECTOR_START.format(TASK.title(), pipeline_conductor.pipeline_details.connector_nm))
    except Exception as e:
        error_trace = traceback.format_exc()
        
        # Print detailed error information
        print("=== Exception Details ===")
        print(f"Error Type: {type(e).__name__}")
        print(f"Error Message: {str(e)}")
        print("\n=== Full Stack Trace ===")
        print(error_trace)
        
        # Get detailed system info
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        line_no = exc_tb.tb_lineno

        # Create a more detailed error message
        message = (
            f"An unhandled exception occurred:\n"
            f"Type: {type(e).__name__}\n"
            f"Location: {fname}, line {line_no}\n"
            f"Details: {str(e)}\n"
            f"Arguments: {e.args}\n"
            f"Full trace: {error_trace}"
        )
        api.log("Fatal error occurred", RunStagesEnum.INITIALIZING_SOURCE_STAGE.value if is_source else RunStagesEnum.INITIALIZING_DESTINATION_STAGE.value, TASK, message, True)
        api.log("An unrecognized issue has occurred on our side. Our team will be in contact within 24-48 hours, or try emailing support@dataconnector.com.", RunStagesEnum.INITIALIZING_SOURCE_STAGE.value if is_source else RunStagesEnum.INITIALIZING_DESTINATION_STAGE.value, TASK, e)
        sys.exit(1)

    fail = False
    unhandled = False

    # If job was initialized correctly, start actions    
    try:
        pipeline_conductor.pipeline_details.increment_stage()
        if TASK == TasksEnum.SOURCE.value:
            pipeline_conductor.authenticate_source()
            pipeline_conductor.pipeline_details.increment_stage()
            
            if not pipeline_conductor.pipeline_details.pipeline_mapping_json:
                pipeline_conductor.configure_fields()

            pipeline_conductor.pipeline_details.increment_stage()
            pipeline_conductor.get_data()
            
            pipeline_conductor.pipeline_details.increment_stage()

            next_job_id = None

            if APP_ENV != 'local':
                next_job_id = pipeline_conductor.start_next_connector()
            else:
                raise Error("Next connector not started because connector was ran locally.", "NextNotInvokedError - ", False)
            if PipelineEnvironment.platform == "aws":
                destination_start = {
                        "DestinationECSInstanceID": next_job_id,
                        "updateAction": UpdateRunHistoryActionEnum.DESTINATION_PIPELINE_START.value
                    }
            elif PipelineEnvironment.platform == "azure":
                destination_start = {
                    "DestinationAzureExecutionNM": next_job_id,
                    "updateAction": UpdateRunHistoryActionEnum.DESTINATION_PIPELINE_START.value
                }

            pipeline_conductor.update_history(destination_start)

        else:
            pipeline_conductor.authenticate_destination()
            pipeline_conductor.pipeline_details.increment_stage()
            pipeline_conductor.load_data(PipelineEnvironment.batch_start)

    except (SDKError, Error) as e:
        print(traceback.format_exc())
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        fail = True
        if e.internal:
            pipeline_conductor.internal_error(pipeline_conductor.log_templates.INTERNAL_ERROR_MESSAGE.format(type(e).__name__, e.message), e)
        else:
            pipeline_conductor.error(pipeline_conductor.log_templates.ERROR_MESSAGE.format(e.error_name, e.message), e)
    except Exception as ex:
        fail = True
        error_trace = traceback.format_exc()
        
        # Print detailed error information
        print("=== Exception Details ===")
        print(f"Error Type: {type(ex).__name__}")
        print(f"Error Message: {str(ex)}")
        print("\n=== Full Stack Trace ===")
        print(error_trace)
        
        # Get detailed system info
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        line_no = exc_tb.tb_lineno

        # Create a more detailed error message
        message = (
            f"An unhandled exception occurred:\n"
            f"Type: {type(ex).__name__}\n"
            f"Location: {fname}, line {line_no}\n"
            f"Details: {str(ex)}\n"
            f"Arguments: {ex.args}\n"
            f"Full trace: {error_trace}"
        )

        pipeline_conductor.internal_error(message, error_trace, unhandled=True)
        unhandled = True

    if is_source:
        end_payload = {
            "StatusCD": 1 if not fail else 3,
            "StatusDSC": "Running" if not fail else "Failed",
            "BytesTransferredNBR": pipeline_conductor.bytes_transferred,
            "RowsRetrievedNBR": pipeline_conductor.row_count,
            "updateAction": UpdateRunHistoryActionEnum.SOURCE_PIPELINE_END.value,
            "internal_error_flg": 1 if unhandled else 0,
            "credentials": json.dumps(pipeline_conductor.connector.credentials)
        }
    else:
        end_payload = {
            "StatusCD": 2 if not fail else 3,
            "StatusDSC": "Finished" if not fail else "Failed",
            "RowsInsertedNBR": pipeline_conductor.row_count,
            "updateAction": UpdateRunHistoryActionEnum.DESTINATION_PIPELINE_END.value,
            "internal_error_flg": 1 if unhandled else 0,
            "credentials": json.dumps(pipeline_conductor.connector.credentials)
        }

    pipeline_conductor.update_history(end_payload)

    if PipelineEnvironment.connected_container and fail:
        sys.exit(1)

def main():
    # TODO: Create new history if environment=local
    try:
        run_pipeline()
    except Exception as e:
        error_trace = traceback.format_exc()
        
        # Print detailed error information
        print("=== Exception Details ===")
        print(f"Error Type: {type(e).__name__}")
        print(f"Error Message: {str(e)}")
        print("\n=== Full Stack Trace ===")
        print(error_trace)
        
        # Get detailed system info
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        line_no = exc_tb.tb_lineno

        # Create a more detailed error message
        message = (
            f"An unhandled exception occurred:\n"
            f"Type: {type(e).__name__}\n"
            f"Location: {fname}, line {line_no}\n"
            f"Details: {str(e)}\n"
            f"Arguments: {e.args}\n"
            f"Full trace: {error_trace}"
        )
        print(message)
        sys.exit(1)