from dc_sdk.errors import Error
from dc_sdk.src.mapping import Mapping
import traceback
from importlib.metadata import version

def get_action_name(action: int) -> str:
    return {
        0: "authenticating",
        1: "retrieving fields",
        2: "retrieving 5 row preview",
        3: "testing connection",
        4: "starting the connector"
    }[action]

def apply_data_filters(results, data_filters):
    if not data_filters:
        return results

    # Connectors may return either:
    # 1) a bare list of rows, or
    # 2) an envelope: {"data": [...], "next_page": ...}
    is_envelope = isinstance(results, dict) and isinstance(results.get("data"), list)
    rows = results.get("data") if is_envelope else results
    if not isinstance(rows, list):
        return results

    # 🔹 UI → backend operator mapping
    OPERATOR_MAP = {
        # text
        "text_contains": "CONTAINS",
        "text_not_contains": "NOT_CONTAINS",
        "text_starts_with": "STARTS_WITH",
        "text_ends_with": "ENDS_WITH",

        # equality
        "is_equal": "EQ",
        "is_not_equal": "NEQ",

        # empty
        "is_empty": "IS_EMPTY",
        "is_not_empty": "IS_NOT_EMPTY",

        # numeric
        "gt": "GT",
        "gte": "GTE",
        "lt": "LT",
        "lte": "LTE",

        # range
        "between": "BETWEEN",
        "not_between": "NOT_BETWEEN",

        # ignore
        "none": None,
    }

    def try_parse_number(val):
        try:
            return float(val)
        except:
            return val

    def normalize(row_val, v1, v2=None):
        row_num = try_parse_number(row_val)
        v1_num = try_parse_number(v1)
        v2_num = try_parse_number(v2) if v2 is not None else None

        # If both are numbers → compare as numbers
        if isinstance(row_num, float) and isinstance(v1_num, float):
            return row_num, v1_num, v2_num

        # Otherwise → compare as strings
        return str(row_val), str(v1), str(v2) if v2 is not None else None

    def match(row, f):
        ui_operator = f.get("operator_cd")
        operator = OPERATOR_MAP.get(ui_operator)

        if operator is None:
            return True  # skip "none"

        col = f.get("column_name")
        val1 = f.get("value_1_txt")
        val2 = f.get("value_2_txt")

        # Some connectors can emit non-dict rows; keep filtering resilient.
        if not isinstance(row, dict):
            return False
        row_val = row.get(col)

        # ---- EMPTY HANDLING ----
        if operator == "IS_EMPTY":
            return row_val is None or str(row_val).strip() == ""

        if operator == "IS_NOT_EMPTY":
            return row_val is not None and str(row_val).strip() != ""

        if row_val is None:
            return False

        # Normalize values
        row_val, v1, v2 = normalize(row_val, val1, val2)

        # ---- OPERATORS ----

        if operator == "EQ":
            return row_val == v1

        elif operator == "NEQ":
            return row_val != v1

        elif operator == "GT":
            return row_val > v1

        elif operator == "GTE":
            return row_val >= v1

        elif operator == "LT":
            return row_val < v1

        elif operator == "LTE":
            return row_val <= v1

        elif operator == "BETWEEN":
            return v1 <= row_val <= v2

        elif operator == "NOT_BETWEEN":
            return not (v1 <= row_val <= v2)

        elif operator == "CONTAINS":
            return str(v1).lower() in str(row_val).lower()

        elif operator == "NOT_CONTAINS":
            return str(v1).lower() not in str(row_val).lower()

        elif operator == "STARTS_WITH":
            return str(row_val).lower().startswith(str(v1).lower())

        elif operator == "ENDS_WITH":
            return str(row_val).lower().endswith(str(v1).lower())

        return True

    # 🔹 Apply filters (AND logic)
    filtered_rows = [row for row in rows if all(match(row, f) for f in data_filters)]
    if is_envelope:
        return {**results, "data": filtered_rows}
    return filtered_rows


def handler(event, context):
    print("version: ", version("dc-python-sdk"))
    """Lambda Handler"""
    action_name = None
    internal_error = False
    message = None
    results = None
    error = None
    mapping = None
    action = int(event['action']) if 'action' in event else 4
    get_objects = event.get('get_objects', True)
    credentials_dict = event['credentials'] if 'credentials' in event else None
    object_id = event['object_id'] if 'object_id' in event else None
    field_ids = event['mapping'] if 'mapping' in event else None
    options = event['options'] if 'options' in event else dict()
    next_page = event['next_page'] if 'next_page' in event else None
    n_rows = event['n_rows'] if 'n_rows' in event else None
    filters = event['filters'] if 'filters' in event else None
    data_filters = event['data_filters'] if 'data_filters' in event else None

    try:
        action_name = get_action_name(action)
        mapping = Mapping(credentials_dict)

        if action == 0:
            if get_objects:
                results, message = mapping.connect_get_objects()
            else:
                results, message = mapping.authenticate()
        elif action == 1:
            results, message = mapping.get_fields(object_id, options)
        elif action == 2:
            results, message = mapping.get_five_row_preview(
                object_id, field_ids, options, n_rows, filters, next_page)
            results = apply_data_filters(results, data_filters)
        elif action == 3:
            results, message = mapping.test_connection()
        else:
            raise Error("Invalid action", "InvalidActionError")
    except Error as e:
        message = e.message
        internal_error = e.internal
        error_trace = traceback.format_exc()
        error = error_trace

    except Exception as e:
        error_trace = traceback.format_exc()
        error = error_trace
        internal_error = True

    if error:
        print(error)

    return {
        'message': message if not internal_error else f"Something went wrong with {action_name}",
        'results': results,
        'credentials': mapping.connector.credentials if mapping else None,
        'error': error,
        'internal_error': internal_error
    }
