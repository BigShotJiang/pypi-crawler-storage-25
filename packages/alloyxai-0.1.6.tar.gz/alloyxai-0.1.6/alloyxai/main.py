#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlloyXAI 主脚本

统一管理材料描述符计算、机器学习模型训练和可解释性分析的完整流程。

支持:
- 运行完整流程（描述符 → 数据清理 → 特征工程 → 机器学习 → 可解释性）
- 单独运行某个步骤
- 自定义每个步骤的参数
- 化学元素列处理：默认保留，可自定义删除
"""

import os
import sys
import argparse
import logging
import time
import glob


def _get_project_root():
    return os.getcwd()


def setup_logging():
    """
    设置日志记录

    返回:
    logger: 配置好的日志记录器
    """
    log_dir = os.path.join(_get_project_root(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)

    log_filename = f'alloyxai_main_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)

    logger = logging.getLogger('AlloyXAI_Main')
    logger.setLevel(logging.INFO)

    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)

    return logger


logger = setup_logging()


def _run_step(description, step_func, step_args=None):
    logger.info(f"\n{'='*60}")
    logger.info(f"开始: {description}")
    logger.info(f"{'='*60}")
    try:
        if step_args is not None:
            step_func(step_args)
        else:
            step_func()
        logger.info(f"{'='*60}")
        logger.info(f"完成: {description}")
        logger.info(f"{'='*60}")
        return True
    except Exception as e:
        logger.error(f"{'='*60}")
        logger.error(f"错误: {description} 执行失败: {e}")
        logger.error(f"{'='*60}")
        return False


def parse_arguments():
    """
    解析命令行参数

    返回:
    argparse.Namespace: 解析后的参数
    """
    parser = argparse.ArgumentParser(
        description='AlloyXAI 主脚本 - 统一管理完整分析流程-Jin',
        epilog='''
使用示例:
    # 运行完整流程（描述符 → 数据清理 → 特征工程 → 机器学习 → 可解释性）
    alloyxai --all -i data/your_data.xlsx

    # 只运行描述符计算
    alloyxai --descriptors -i data/your_data.xlsx

    # 只运行数据清理（保留化学元素列）
    alloyxai --clean

    # 只运行数据清理（删除化学元素列）
    alloyxai --clean --delete-elements

    # 只运行特征工程（保护化学元素列）
    alloyxai --feature-eng

    # 只运行特征工程（不保护化学元素列）
    alloyxai --feature-eng --no-protect-elements

    # 只运行机器学习
    alloyxai --ml

    # 只运行可解释性分析
    alloyxai --explanation

    # 自定义每个步骤的参数
    alloyxai --descriptors -i data/your_data.xlsx -c "composition" --clean --feature-eng -m 2 --ml -a random_forest --explanation -e shap -e ale
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('--all', action='store_true',
                        help='运行完整流程（数据预处理 + 描述符 + 数据清理 + 特征工程 + 机器学习 + 可解释性）')
    parser.add_argument('--preprocess', action='store_true',
                        help='运行数据预处理（成分格式转换）')
    parser.add_argument('--descriptors', action='store_true',
                        help='运行材料描述符计算')
    parser.add_argument('--clean', action='store_true',
                        help='运行数据清理')
    parser.add_argument('--feature-eng', action='store_true',
                        help='运行特征工程')
    parser.add_argument('--ml', action='store_true',
                        help='运行机器学习模型训练')
    parser.add_argument('--explanation', action='store_true',
                        help='运行可解释性分析')

    parser.add_argument('--preprocess-input', type=str,
                        help='数据预处理：输入的 Excel 文件路径')
    parser.add_argument('--preprocess-output', type=str,
                        help='数据预处理：输出目录')
    parser.add_argument('--preprocess-column', type=str,
                        help='数据预处理：要处理的列名（默认 alloy_composition）')
    parser.add_argument('--preprocess-save-csv', action='store_true',
                        help='数据预处理：同时保存为 CSV 格式')

    parser.add_argument('-i', '--input', type=str,
                        help='描述符计算：输入的 Excel 文件路径')
    parser.add_argument('--desc-output', type=str,
                        help='描述符计算：输出目录')
    parser.add_argument('-c', '--column', type=str,
                        help='描述符计算：要处理的列名')

    parser.add_argument('-a', '--algorithm', type=str, action='append',
                        help='机器学习：指定使用的算法（可多次指定）')
    parser.add_argument('--test-size', type=float,
                        help='机器学习：测试集大小')
    parser.add_argument('--ml-data', type=str,
                        help='机器学习：数据文件路径')
    parser.add_argument('--ml-target', type=str,
                        help='机器学习：目标变量列名')
    parser.add_argument('--task-type', type=str, choices=['regression', 'classification'],
                        help='机器学习：任务类型')

    parser.add_argument('--clean-input', type=str,
                        help='数据清理：输入的 Excel 文件路径')
    parser.add_argument('--delete-elements', action='store_true',
                        help='数据清理：删除化学元素列（默认保留）')

    parser.add_argument('--fe-mode', type=int, choices=[1, 2], default=1,
                        help='特征工程：处理模式 (1-普通模式, 2-增强模式), 默认1')
    parser.add_argument('--fe-target', type=str,
                        help='特征工程：目标变量列名')
    parser.add_argument('--no-protect-elements', action='store_true',
                        help='特征工程：不保护化学元素列（默认保护）')

    parser.add_argument('--exp-model', type=str,
                        help='可解释性分析：模型文件路径')
    parser.add_argument('--exp-data', type=str,
                        help='可解释性分析：数据文件路径')
    parser.add_argument('--exp-target', type=str,
                        help='可解释性分析：目标变量名称')
    parser.add_argument('-e', '--exp-method', type=str, action='append',
                        choices=['shap', 'lime', 'feature_importance', 'ale', 'pdp'],
                        help='可解释性分析：分析方法（可多次指定）')
    parser.add_argument('--exp-output', type=str,
                        help='可解释性分析：输出目录')

    args = parser.parse_args()

    if getattr(args, 'all', False):
        if not hasattr(args, 'scaling') or args.scaling is None:
            args.scaling = 'standardize'
        if not hasattr(args, 'task') or args.task is None:
            if hasattr(args, 'task_type') and args.task_type:
                args.task = args.task_type
            else:
                args.task = 'regression'
        if not hasattr(args, 'model') or args.model is None:
            args.model = 'all'
        if not hasattr(args, 'mode') or args.mode is None:
            if hasattr(args, 'ml_mode') and args.ml_mode is not None:
                args.mode = args.ml_mode
            else:
                args.mode = 'quick'
        if not hasattr(args, 'test_size') or args.test_size is None:
            args.test_size = 0.2

    if not (args.all or args.preprocess or args.descriptors or args.clean or args.feature_eng or args.ml or args.explanation):
        parser.error('请至少指定一个要运行的步骤：--all, --preprocess, --descriptors, --clean, --feature-eng, --ml, 或 --explanation')

    return args


def _build_preprocess_namespace(args):
    return argparse.Namespace(
        input=args.preprocess_input if args.preprocess_input else args.input,
        output=args.preprocess_output,
        column=args.preprocess_column if args.preprocess_column else 'alloy_composition',
        save_csv=args.preprocess_save_csv,
    )


def _build_descriptors_namespace(args):
    return argparse.Namespace(
        input_file=args.input,
        output_dir=args.desc_output,
        column_name=args.column if args.column else 'alloy_composition_after_process',
    )


def _build_clean_namespace(args):
    return argparse.Namespace(
        input=args.clean_input if args.clean_input else args.input,
        delete_elements=args.delete_elements,
    )


def _build_feature_eng_namespace(args):
    return argparse.Namespace(
        mode=args.fe_mode,
        target=args.fe_target,
        no_protect_elements=args.no_protect_elements,
        scaling='standardize',
    )


def _build_ml_namespace(args):
    return argparse.Namespace(
        algorithm=args.algorithm,
        test_size=getattr(args, 'test_size', 0.2) if getattr(args, 'test_size', None) is not None else 0.2,
        data=args.ml_data,
        target=args.ml_target,
        task=getattr(args, 'task', 'regression'),
        mode=getattr(args, 'mode', 'quick'),
        model=getattr(args, 'model', 'all'),
        output=getattr(args, 'output', 'results/alloy_machine_learning') if getattr(args, 'output', None) else 'results/alloy_machine_learning',
    )


def _build_explanation_namespace(args):
    base_dir = os.getcwd()

    model = args.exp_model
    if not model:
        from .explanation import find_best_model
        best_model = find_best_model()
        if best_model:
            model = best_model
            logger.info(f"自动选择最优模型: {best_model}")
        else:
            model_patterns = [
                'results/alloy_machine_learning/**/models/*.joblib',
                'heaML/**/models/*.joblib',
            ]
            all_models = []
            for pattern in model_patterns:
                all_models.extend(glob.glob(os.path.join(base_dir, pattern), recursive=True))
            if all_models:
                all_models.sort(key=os.path.getmtime, reverse=True)
                model = all_models[0]
                logger.info(f"未找到可用评估结果，自动选择最近修改的模型: {model}")

    data = args.exp_data
    if not data:
        data_patterns = [
            'results/engineer/feature_engineering/*.csv',
            'results/feature_engineering/*.csv',
            'data/*.csv',
            'data/*.xlsx',
        ]
        all_data = []
        for pattern in data_patterns:
            all_data.extend(glob.glob(os.path.join(base_dir, pattern), recursive=True))
        all_data = [p for p in all_data if not os.path.basename(p).startswith('~$')]
        if all_data:
            def _exp_data_sort_key(path):
                p_norm = path.replace('\\', '/')
                if 'engineer/feature_engineering' in p_norm and path.endswith('.csv'):
                    tier = 2
                elif path.endswith('.csv'):
                    tier = 1
                else:
                    tier = 0
                return (tier, os.path.getmtime(path))
            all_data.sort(key=_exp_data_sort_key, reverse=True)
            data = all_data[0]
            logger.info(f"自动选择最新数据: {data}")

    return argparse.Namespace(
        model=model,
        data=data,
        target=args.exp_target,
        explanation=args.exp_method if args.exp_method else ['shap', 'lime', 'feature_importance', 'ale', 'pdp'],
        output=args.exp_output if args.exp_output else os.path.join(os.getcwd(), 'results', 'explanation'),
    )


def main():
    """主函数"""
    args = parse_arguments()

    logger.info("\n" + "="*60)
    logger.info("AlloyXAI - 合金材料机器学习分析平台")
    logger.info("="*60)

    success_count = 0
    total_count = 0

    if args.all or args.preprocess:
        total_count += 1
        from . import data_processing
        ns = _build_preprocess_namespace(args)
        if _run_step("数据预处理（成分格式转换）", data_processing.run, ns):
            success_count += 1

    if args.all or args.descriptors:
        total_count += 1
        from . import alloy_descriptor_calculator
        ns = _build_descriptors_namespace(args)
        if _run_step("材料描述符计算", alloy_descriptor_calculator.run, ns):
            success_count += 1

    if args.all or args.clean:
        total_count += 1
        from . import descript_data_clean
        ns = _build_clean_namespace(args)
        if _run_step("数据清理", descript_data_clean.run, ns):
            success_count += 1

    if args.all or args.feature_eng:
        total_count += 1
        from . import feature_engineering
        ns = _build_feature_eng_namespace(args)
        if _run_step("特征工程", feature_engineering.run, ns):
            success_count += 1

    if args.all or args.ml:
        total_count += 1
        from . import machine_learning
        ns = _build_ml_namespace(args)
        if _run_step("机器学习模型训练", machine_learning.run, ns):
            success_count += 1

    if args.all or args.explanation:
        total_count += 1
        from . import explanation
        ns = _build_explanation_namespace(args)
        if _run_step("可解释性分析", explanation.run, ns):
            success_count += 1

    logger.info("\n" + "="*60)
    logger.info("流程执行完成")
    logger.info(f"总步骤: {total_count}")
    logger.info(f"成功: {success_count}")
    logger.info(f"失败: {total_count - success_count}")
    logger.info("="*60)

    if success_count == total_count:
        logger.info("\n🎉 所有步骤执行成功！")
        sys.exit(0)
    else:
        logger.error(f"\n⚠️  有 {total_count - success_count} 个步骤执行失败")
        sys.exit(1)


if __name__ == '__main__':
    main()
