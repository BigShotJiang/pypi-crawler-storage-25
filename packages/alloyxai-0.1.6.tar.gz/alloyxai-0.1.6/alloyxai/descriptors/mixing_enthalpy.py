# -*- coding: utf-8 -*-
import sys
import re

from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions
from ..config.hij_data import HIJ_PAIRS


def load_hij_data():
    """
    从硬编码的 HIJ_PAIRS 字典加载混合焓参数数据
    返回一个字典，格式为{(element_i, element_j): Hij_value}
    """
    try:
        hij_dict = {}

        for key_str, value in HIJ_PAIRS.items():
            elements = key_str.strip('()').split(', ')
            if len(elements) == 2:
                element1, element2 = elements
                hij_dict[(element1, element2)] = float(value)
                hij_dict[(element2, element1)] = float(value)

        print(f"成功加载混合焓数据，共包含 {len(hij_dict)} 个元素对")
        return hij_dict
    except Exception as e:
        print(f"加载Hij数据时出错: {e}")
        return {}

# 加载Hij数据
HIJ_DATA = load_hij_data()

def mixing_enthalpy(formula):
    """
    计算混合焓 ΔH_m = 4 * ΣΣ(c_i * c_j * H_ij^m) ，其中 i ≠ j
    
    参数:
        formula (str): 化学式字符串，例如 'Fe2Ni', 'CuZn', 'Al2O3'
    
    返回:
        float: 混合焓值
    
    异常:
        ValueError: 当化学式格式无效或包含不在数据库中的元素时
    """
    # 检查输入类型
    if not isinstance(formula, str):
        raise ValueError("化学式必须是字符串类型")
    
    # 使用formula_parser解析化学式
    try:
        elements_and_counts = get_elements_and_counts(formula)
        molar_fractions = get_molar_fractions(formula)
    except Exception as e:
        raise ValueError(f"解析化学式 '{formula}' 时出错: {e}")
    
    # 检查所有元素是否在Hij数据库中
    elements = list(molar_fractions.keys())
    for element in elements:
        if not any((element == e1 or element == e2) for e1, e2 in HIJ_DATA.keys()):
            raise ValueError(f"元素 '{element}' 在混合焓数据库中不存在")
    
    # 计算混合焓
    mixing_enthalpy_value = 0.0
    
    # 遍历所有唯一的元素对 (i, j) 其中 i < j，避免重复计算
    for i in range(len(elements)):
        for j in range(i + 1, len(elements)):
            element_i = elements[i]
            element_j = elements[j]
            c_i = molar_fractions[element_i]
            c_j = molar_fractions[element_j]
            
            # 获取H_ij^m值
            hij = HIJ_DATA.get((element_i, element_j), 0.0)
            
            # 累加项: 4 * c_i * c_j * H_ij^m
            # 由于只计算i<j的情况，且H_ij^m = H_ji^m，所以需要乘以2来包含(i,j)和(j,i)的贡献
            mixing_enthalpy_value += 4 * c_i * c_j * hij * 2
    
    return mixing_enthalpy_value



# 测试函数
def test_mixing_enthalpy():
    """
    测试混合焓计算函数
    """
    print("开始测试混合焓计算...")
    
    # 测试用例
    test_cases = [
        "Hf0.5Ti2ZrVNb",
        "Al0.0HfNbZrTaTi",
        "Hf0.5Ti2ZrVNb",
        "Hf0.25Nb0.5TiV0.5Zr0.5",
        'AgCd',    # 二元合金
        'AgIn',    # 二元合金
        'CdIn',    # 二元合金
        'AgCdIn',  # 三元合金
        'Ag2Cd3',  # 带系数的二元合金
        '(Ag0.5Cd0.5)'
    ]
    
    # 执行测试
    for formula in test_cases:
        try:
            result = mixing_enthalpy(formula)
            print(f"混合焓({formula}) = {result:.4f}")
        except ValueError as e:
            print(f"计算混合焓({formula})时出错: {e}")
    
    # 测试无效输入
    print("\n测试无效输入:")
    invalid_cases = [
        123,            # 非字符串类型
        'Invalid',      # 无效的化学式
        'XYZ',          # 不存在的元素
        'AgCuAu'        # 多元素合金
    ]
    
    for formula in invalid_cases:
        try:
            result = mixing_enthalpy(formula)
            print(f"成功: 混合焓({formula}) = {result}")
        except ValueError as e:
            print(f"预期的错误: {e}")
    
    # 测试摩尔分数
    print("\n测试摩尔分数:")
    formula = 'Ag2Cd3'
    try:
        molar_fractions = get_molar_fractions(formula)
        print(f"{formula} 的摩尔分数: {molar_fractions}")
        # 验证摩尔分数总和是否接近1.0
        total = sum(molar_fractions.values())
        print(f"摩尔分数总和: {total:.6f}")
        assert abs(total - 1.0) < 1e-6, f"摩尔分数总和应为1.0，实际为{total}"
    except Exception as e:
        print(f"测试摩尔分数时出错: {e}")
    
    print("\n所有测试完成!")

if __name__ == "__main__":
    test_mixing_enthalpy()