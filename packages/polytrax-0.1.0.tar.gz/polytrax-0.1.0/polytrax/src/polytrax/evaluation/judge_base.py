# polytrax/src/polytrax/evaluation/judge_base.py
"""
polytrax.evaluation.judge_base — abstract base class for evaluation judges.

All evaluation judges (LLM-based or deterministic) must inherit from
``BaseJudge`` and implement the ``evaluate`` method, returning a dict
that conforms to the rubric schema defined in ``rubric.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BaseJudge(ABC):
    """Abstract base class for evaluation judges.

    Subclasses must set ``name`` and implement ``evaluate()``.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this judge instance."""
        ...

    @abstractmethod
    def evaluate(
        self,
        briefing_text: str,
        consolidated_assessment: Optional[str],
        run_report: Dict[str, Any],
        trace_summary: Optional[Dict[str, Any]] = None,
        raw_inputs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Evaluate a run and return a dict matching the rubric schema.

        Parameters
        ----------
        briefing_text:
            The final briefing or output text produced by the MAS run.
        consolidated_assessment:
            Optional consolidated assessment text (e.g. from a supervisor).
        run_report:
            The run_report.json dict containing graph, propagation,
            offline_tps, containment, and metadata sections.
        trace_summary:
            Optional summary of the trace (e.g. event counts, agent list).

        Returns
        -------
        dict
            Evaluation dict conforming to ``RUBRIC_SCHEMA``.
        """
        raise NotImplementedError
