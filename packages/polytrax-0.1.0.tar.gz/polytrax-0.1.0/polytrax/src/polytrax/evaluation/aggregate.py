# polytrax/src/polytrax/evaluation/aggregate.py
"""
polytrax.evaluation.aggregate — cross-run evaluation aggregation.

Loads per-run ``eval.json`` files and computes summary statistics across
runs: per-scenario means, per-dimension means, judge disagreement,
and correlation between O-TPS and overall_score.
"""

from __future__ import annotations

import json
import math
import os
import statistics
from typing import Any, Dict, List, Optional, Tuple


# ── Helpers ─────────────────────────────────────────────────────────


def _load_eval(run_dir: str) -> Optional[Dict[str, Any]]:
    """Load eval.json from a run directory; return None if missing."""
    path = os.path.join(run_dir, "eval.json")
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _safe_mean(values: List[float]) -> float:
    """Mean of non-empty list, else 0.0."""
    if not values:
        return 0.0
    return statistics.mean(values)


def _safe_stdev(values: List[float]) -> float:
    """Standard deviation; 0.0 for fewer than 2 values."""
    if len(values) < 2:
        return 0.0
    return statistics.stdev(values)


def _pearson_correlation(
    xs: List[float], ys: List[float]
) -> Optional[float]:
    """Compute Pearson correlation coefficient between two lists.

    Returns None if fewer than 2 pairs or zero variance in either list.
    """
    n = min(len(xs), len(ys))
    if n < 2:
        return None

    x_vals = xs[:n]
    y_vals = ys[:n]

    mean_x = statistics.mean(x_vals)
    mean_y = statistics.mean(y_vals)

    cov = sum((x - mean_x) * (y - mean_y) for x, y in zip(x_vals, y_vals))
    var_x = sum((x - mean_x) ** 2 for x in x_vals)
    var_y = sum((y - mean_y) ** 2 for y in y_vals)

    denom = math.sqrt(var_x * var_y)
    if denom < 1e-12:
        return None

    return round(cov / denom, 4)


# ── Public API ──────────────────────────────────────────────────────


def aggregate_evaluations(run_dirs: List[str]) -> Dict[str, Any]:
    """Aggregate evaluation results across multiple runs.

    Loads ``eval.json`` from each run directory and computes:
    - Per-scenario means for all trust dimensions, accuracy, relevance
    - Per-dimension global means
    - Judge disagreement (std of overall scores across judges per run)
    - Pearson correlation between O-TPS and overall_score

    Parameters
    ----------
    run_dirs:
        List of run directory paths, each expected to contain ``eval.json``.

    Returns
    -------
    dict
        Structured summary with per_scenario, global, disagreement, and
        correlation sections.
    """
    # ── Load all eval.json files ────────────────────────────────────
    evals: List[Dict[str, Any]] = []
    for rd in run_dirs:
        ev = _load_eval(rd)
        if ev is not None:
            evals.append(ev)

    if not evals:
        return {
            "n_runs": 0,
            "per_scenario": {},
            "global_means": {},
            "judge_disagreement": {},
            "o_tps_vs_overall_correlation": None,
        }

    # ── Group by scenario ───────────────────────────────────────────
    by_scenario: Dict[str, List[Dict[str, Any]]] = {}
    for ev in evals:
        scenario = ev.get("scenario", "unknown")
        by_scenario.setdefault(scenario, []).append(ev)

    # ── Dimension fields to aggregate ───────────────────────────────
    _AGGREGATE_FIELDS = [
        "mean_constraint_score",
        "mean_evidence_score",
        "mean_provenance_score",
        "mean_accuracy_score",
        "mean_relevance_score",
        "mean_critique_quality_score",
        "mean_context_precision_score",
        "mean_context_recall_score",
        "mean_overall_score",
    ]

    # ── Per-scenario aggregation ────────────────────────────────────
    per_scenario: Dict[str, Dict[str, Any]] = {}
    for scenario, scenario_evals in sorted(by_scenario.items()):
        scenario_stats: Dict[str, Any] = {"n_runs": len(scenario_evals)}
        for field in _AGGREGATE_FIELDS:
            values = [
                float(ev.get("aggregated", {}).get(field, 0))
                for ev in scenario_evals
            ]
            scenario_stats[field] = round(_safe_mean(values), 4)
            scenario_stats[f"std_{field}"] = round(_safe_stdev(values), 4)
        per_scenario[scenario] = scenario_stats

    # ── Global means ────────────────────────────────────────────────
    global_means: Dict[str, Any] = {"n_runs": len(evals)}
    for field in _AGGREGATE_FIELDS:
        values = [
            float(ev.get("aggregated", {}).get(field, 0))
            for ev in evals
        ]
        global_means[field] = round(_safe_mean(values), 4)
        global_means[f"std_{field}"] = round(_safe_stdev(values), 4)

    # ── Judge disagreement ──────────────────────────────────────────
    # Per-run inter-judge variance, then summarise across runs.
    variances = [
        float(ev.get("aggregated", {}).get("inter_judge_variance", 0))
        for ev in evals
    ]
    disagreement = {
        "mean_inter_judge_variance": round(_safe_mean(variances), 4),
        "max_inter_judge_variance": round(max(variances) if variances else 0.0, 4),
        "n_runs_with_variance": sum(1 for v in variances if v > 0),
    }

    # ── O-TPS vs overall_score correlation ──────────────────────────
    o_tps_values = [
        float(ev.get("o_tps_score", 0)) for ev in evals
    ]
    overall_values = [
        float(ev.get("aggregated", {}).get("mean_overall_score", 0))
        for ev in evals
    ]
    correlation = _pearson_correlation(o_tps_values, overall_values)

    return {
        "n_runs": len(evals),
        "per_scenario": per_scenario,
        "global_means": global_means,
        "judge_disagreement": disagreement,
        "o_tps_vs_overall_correlation": correlation,
    }
