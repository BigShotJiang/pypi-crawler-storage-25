# polytrax/src/polytrax/evaluation/dimension_pipelines.py
"""
polytrax.evaluation.dimension_pipelines — trust dimension evaluation pipelines.

Each pipeline function blends LLM judge scores with structural graph-based
signals to ensure evaluation is never purely LLM-based.  This implements
the supervisor requirement for hybrid evaluation across three trust dimensions.

Blending weights: judge score (0.6) + structural signal (0.4).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def _safe_float(val: Any, default: float = 0.0) -> float:
    """Safely convert a value to float."""
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _clamp(val: float, lo: float = 0.0, hi: float = 5.0) -> float:
    """Clamp a value to [lo, hi]."""
    return max(lo, min(hi, val))


# ── Constraint Pipeline ────────────────────────────────────────────


def evaluate_constraints(
    judge_scores: List[Dict[str, Any]],
    run_report: Dict[str, Any],
) -> Dict[str, Any]:
    """Evaluate constraint adherence.
    
    Research Hardening: Decoupled from O-TPS to avoid leakage.
    Score is primarily based on judge assessment.
    """
    if judge_scores:
        judge_mean = sum(
            _safe_float(j.get("constraint_score", 0)) for j in judge_scores
        ) / len(judge_scores)
    else:
        judge_mean = 0.0

    # Structural signal is auxiliary now, not blended by default unless explicitly justified.
    prop = run_report.get("propagation", {})
    vpr = _safe_float(prop.get("violation_persistence_ratio", 0.0))
    
    # Blended score is now judge-primary
    blended = judge_mean 

    return {
        "judge_score": round(judge_mean, 4),
        "blended_score": round(blended, 4),
        "details": {
            "violation_persistence_ratio": round(vpr, 4),
            "n_judges": len(judge_scores),
        },
    }


def evaluate_evidence(
    judge_scores: List[Dict[str, Any]],
    run_report: Dict[str, Any],
    briefing_text: str = "",
) -> Dict[str, Any]:
    """Evaluate evidence grounding.
    
    Research Hardening: Decoupled from O-TPS.
    """
    if judge_scores:
        judge_mean = sum(
            _safe_float(j.get("evidence_score", 0)) for j in judge_scores
        ) / len(judge_scores)
    else:
        judge_mean = 0.0

    # Citation density as auxiliary signal
    text = briefing_text or ""
    total_words = max(len(text.split()), 1)
    citation_count = text.count("[SRC-") + text.count("[REF-")
    citation_density = min(float(citation_count) / (total_words / 100.0), 1.0)

    # Blended score is now judge-primary
    blended = judge_mean

    return {
        "judge_score": round(judge_mean, 4),
        "citation_density": round(citation_density, 4),
        "blended_score": round(blended, 4),
        "details": {
            "citation_count": citation_count,
            "total_words": total_words,
            "n_judges": len(judge_scores),
        },
    }


def evaluate_provenance(
    judge_scores: List[Dict[str, Any]],
    run_report: Dict[str, Any],
) -> Dict[str, Any]:
    """Evaluate provenance traceability.
    
    Research Hardening: Decoupled from O-TPS.
    """
    if judge_scores:
        judge_mean = sum(
            _safe_float(j.get("provenance_score", 0)) for j in judge_scores
        ) / len(judge_scores)
    else:
        judge_mean = 0.0

    # Structural signals are auxiliary
    prop = run_report.get("propagation", {})
    first_violation_hop = prop.get("first_violation_hop")

    # Blended score is now judge-primary
    blended = judge_mean

    return {
        "judge_score": round(judge_mean, 4),
        "blended_score": round(blended, 4),
        "details": {
            "first_violation_hop": first_violation_hop,
            "n_judges": len(judge_scores),
        },
    }
