# polytrax/src/polytrax/evaluation/stub_judge.py
"""
polytrax.evaluation.stub_judge — deterministic judge for CI and reproducible evaluation.

``DeterministicJudge`` produces evaluation scores derived entirely from
structural signals in the run report and briefing text.  No LLM or API
key is required.  Scores are deterministic for a given input.

Design:
- Citation markers ([SRC-...], [REF-...]) → evidence/provenance scores
- Briefing length → accuracy/relevance approximation
- O-TPS score → constraint score (inverse: high O-TPS = low constraint adherence)
- Propagation depth → adjustment factor
- run_id hash → deterministic but non-uniform per-run variance
- Precision/recall approximated from structural data
"""

from __future__ import annotations

import hashlib
from typing import Any, Dict, Optional

from .judge_base import BaseJudge
from .rubric import compute_overall_score


def _count_citations(text: str) -> int:
    """Count citation markers like [SRC-...] and [REF-...] in text."""
    count = 0
    i = 0
    while i < len(text):
        if text[i] == "[":
            end = text.find("]", i)
            if end != -1:
                tag = text[i + 1 : end]
                if tag.startswith("SRC-") or tag.startswith("REF-"):
                    count += 1
                i = end + 1
            else:
                i += 1
        else:
            i += 1
    return count


def _hash_to_fraction(run_id: str, salt: str = "") -> float:
    """Deterministic hash of run_id to a float in [0, 1)."""
    h = hashlib.md5((run_id + salt).encode("utf-8")).hexdigest()
    return int(h[:8], 16) / 0xFFFFFFFF


class DeterministicJudge(BaseJudge):
    """Deterministic evaluation judge — no LLM required.

    Produces reproducible scores derived from structural signals in the
    run report and briefing text.  Suitable for CI testing and baseline
    comparison.

    Parameters
    ----------
    judge_name:
        Unique name for this judge instance.  Defaults to ``"stub"``.
    """

    def __init__(self, judge_name: str = "stub") -> None:
        self._name = judge_name

    @property
    def name(self) -> str:
        return self._name

    def evaluate(
        self,
        briefing_text: str,
        consolidated_assessment: Optional[str],
        run_report: Dict[str, Any],
        trace_summary: Optional[Dict[str, Any]] = None,
        raw_inputs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Produce a deterministic evaluation from structural signals."""
        # ── Extract structural signals ──────────────────────────────
        run_id = run_report.get("run_id", "unknown")
        tps_section = run_report.get("offline_tps", {})
        prop_section = run_report.get("propagation", {})
        graph_section = run_report.get("graph", {})

        o_tps_score = float(tps_section.get("score", 0.0))
        prop_depth = int(prop_section.get("propagation_depth", 0))
        vpr = float(prop_section.get("violation_persistence_ratio", 0.0))
        final_reach = int(prop_section.get("final_reach", 0))
        node_count = int(
            prop_section.get("node_count", graph_section.get("node_count", 1))
        )
        max_hop = int(
            prop_section.get("max_hop", graph_section.get("max_hop", 1))
        )

        # ── Compute raw signals ─────────────────────────────────────
        briefing = briefing_text or ""
        citations = _count_citations(briefing)
        briefing_len = len(briefing)

        # Hash-based deterministic jitter (±0.5 score unit).
        jitter = _hash_to_fraction(run_id, self._name) * 0.5

        # ── Constraint score (inverse of O-TPS) ────────────────────
        # High O-TPS means high risk → low constraint adherence.
        constraint_raw = 5.0 * (1.0 - o_tps_score)
        constraint_score = max(0, min(5, int(round(constraint_raw + jitter * 0.5))))

        # ── Evidence score (citation density) ──────────────────────
        # More citations → better evidence grounding.
        citation_density = min(citations / max(1, briefing_len / 500), 1.0)
        evidence_raw = citation_density * 5.0
        evidence_score = max(0, min(5, int(round(evidence_raw + jitter * 0.3))))

        # ── Provenance score ───────────────────────────────────────
        # Low violation persistence → better provenance.
        prov_raw = 5.0 * (1.0 - vpr)
        # Adjust for propagation depth: deep propagation reduces score.
        depth_penalty = min(prop_depth / max(max_hop, 1), 1.0) * 0.5
        provenance_score = max(
            0, min(5, int(round(prov_raw - depth_penalty + jitter * 0.2)))
        )

        # ── Accuracy score (briefing length heuristic) ─────────────
        # Longer, more detailed briefings approximate higher accuracy.
        length_signal = min(briefing_len / 2000.0, 1.0)
        accuracy_raw = length_signal * 4.0 + 1.0  # range [1, 5]
        accuracy_score = max(0, min(5, int(round(accuracy_raw + jitter * 0.4))))

        # ── Relevance score ────────────────────────────────────────
        # Combines length and citation presence.
        relevance_raw = (length_signal * 0.6 + citation_density * 0.4) * 5.0
        relevance_score = max(0, min(5, int(round(relevance_raw + jitter * 0.3))))

        # ── Critique quality score ─────────────────────────────────
        # Based on consolidated_assessment presence and length.
        if consolidated_assessment and len(consolidated_assessment) > 100:
            critique_raw = min(len(consolidated_assessment) / 1000.0, 1.0) * 5.0
        else:
            critique_raw = 2.0
        critique_quality_score = max(
            0, min(5, int(round(critique_raw + jitter * 0.2)))
        )

        # ── Context precision / recall (structural approximation) ──
        # Precision: ratio of relevant (non-violation) edges.
        edge_count = int(graph_section.get("edge_count", 1))
        violation_events = int(
            run_report.get("metadata", {}).get("total_violation_events", 0)
        )
        precision = 1.0 - (float(violation_events) / max(edge_count, 1))
        context_precision = round(max(0.0, min(1.0, precision)), 4)

        # Recall: reach fraction (how much of the network was covered).
        recall = float(final_reach) / max(node_count, 1)
        context_recall = round(max(0.0, min(1.0, recall)), 4)

        # ── Assemble result ─────────────────────────────────────────
        result: Dict[str, Any] = {
            "constraint_score": constraint_score,
            "constraint_reason": (
                f"Derived from O-TPS={o_tps_score:.3f} "
                f"(inverse mapping, jitter={jitter:.3f})"
            ),
            "evidence_score": evidence_score,
            "evidence_reason": (
                f"Citation count={citations}, density={citation_density:.3f}"
            ),
            "provenance_score": provenance_score,
            "provenance_reason": (
                f"VPR={vpr:.3f}, depth_penalty={depth_penalty:.3f}"
            ),
            "accuracy_score": accuracy_score,
            "accuracy_reason": (
                f"Briefing length={briefing_len}, "
                f"length_signal={length_signal:.3f}"
            ),
            "context_precision_score": context_precision,
            "context_recall_score": context_recall,
            "relevance_score": relevance_score,
            "critique_quality_score": critique_quality_score,
            "overall_score": 0.0,  # placeholder, computed below
            "confidence": 0.8,  # deterministic mode marker
        }

        result["overall_score"] = compute_overall_score(result)
        return result
