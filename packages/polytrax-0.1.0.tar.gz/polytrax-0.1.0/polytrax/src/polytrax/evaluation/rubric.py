# polytrax/src/polytrax/evaluation/rubric.py
"""
polytrax.evaluation.rubric — scoring schema and validation for evaluation artefacts.

Defines the canonical rubric schema for multi-dimensional trust evaluation,
including score ranges, required fields, and weighted overall computation.

All scores are deterministic and JSON-serialisable.
"""

from __future__ import annotations

from typing import Any, Dict

# ── Dimension weights for overall_score computation ─────────────────
# These weights sum to 1.0 and control the weighted mean.

DIMENSION_WEIGHTS: Dict[str, float] = {
    "constraint": 0.25,
    "evidence": 0.25,
    "provenance": 0.20,
    "accuracy": 0.15,
    "relevance": 0.15,
}

# ── Rubric schema definition ───────────────────────────────────────
# Describes each field's expected type and valid range.

RUBRIC_SCHEMA: Dict[str, Dict[str, Any]] = {
    "constraint_score":        {"type": int, "min": 0, "max": 5},
    "constraint_reason":       {"type": str},
    "evidence_score":          {"type": int, "min": 0, "max": 5},
    "evidence_reason":         {"type": str},
    "provenance_score":        {"type": int, "min": 0, "max": 5},
    "provenance_reason":       {"type": str},
    "accuracy_score":          {"type": int, "min": 0, "max": 5},
    "accuracy_reason":         {"type": str},
    "context_precision_score": {"type": float, "min": 0.0, "max": 1.0},
    "context_recall_score":    {"type": float, "min": 0.0, "max": 1.0},
    "relevance_score":         {"type": int, "min": 0, "max": 5},
    "critique_quality_score":  {"type": int, "min": 0, "max": 5},
    "overall_score":           {"type": float},
    "confidence":              {"type": float, "min": 0.0, "max": 1.0},
}

# Fields that carry dimension scores used in overall_score computation.
_DIMENSION_FIELDS = {
    "constraint": "constraint_score",
    "evidence": "evidence_score",
    "provenance": "provenance_score",
    "accuracy": "accuracy_score",
    "relevance": "relevance_score",
}


# ── Overall score computation ──────────────────────────────────────


def compute_overall_score(data: Dict[str, Any]) -> float:
    """Compute the weighted overall score from dimension scores.

    Each dimension score (0–5) is normalised to 0–1 before weighting.

    Parameters
    ----------
    data:
        Dictionary containing at least the five dimension score fields.

    Returns
    -------
    float
        Weighted overall score in [0.0, 1.0].
    """
    total = 0.0
    for dim_name, weight in DIMENSION_WEIGHTS.items():
        field = _DIMENSION_FIELDS[dim_name]
        raw = data.get(field, 0)
        normalised = float(raw) / 5.0
        total += weight * normalised
    return round(total, 4)


# ── Validation ──────────────────────────────────────────────────────


def validate_evaluation_dict(data: Dict[str, Any]) -> None:
    """Validate an evaluation dictionary against the rubric schema.

    Parameters
    ----------
    data:
        Evaluation result dictionary to validate.

    Raises
    ------
    ValueError
        If any required key is missing, has the wrong type, or is out of range.
    """
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict, got {type(data).__name__}")

    for field_name, spec in RUBRIC_SCHEMA.items():
        # Check presence.
        if field_name not in data:
            raise ValueError(f"Missing required field: '{field_name}'")

        value = data[field_name]
        expected_type = spec["type"]

        # Type check — allow int where float is expected.
        if expected_type is float:
            if not isinstance(value, (int, float)):
                raise ValueError(
                    f"Field '{field_name}': expected numeric, "
                    f"got {type(value).__name__}"
                )
        elif expected_type is int:
            if not isinstance(value, int) or isinstance(value, bool):
                raise ValueError(
                    f"Field '{field_name}': expected int, "
                    f"got {type(value).__name__}"
                )
        elif expected_type is str:
            if not isinstance(value, str):
                raise ValueError(
                    f"Field '{field_name}': expected str, "
                    f"got {type(value).__name__}"
                )

        # Range check.
        if "min" in spec and float(value) < spec["min"]:
            raise ValueError(
                f"Field '{field_name}': value {value} below minimum {spec['min']}"
            )
        if "max" in spec and float(value) > spec["max"]:
            raise ValueError(
                f"Field '{field_name}': value {value} above maximum {spec['max']}"
            )
