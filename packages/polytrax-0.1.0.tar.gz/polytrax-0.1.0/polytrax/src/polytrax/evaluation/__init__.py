# polytrax/src/polytrax/evaluation/__init__.py
"""
polytrax.evaluation — research-grade multi-judge evaluation module.

Provides:
- **Rubric**: scoring schema, validation, and weighted overall computation.
- **Judges**: abstract base, deterministic stub, and LLM-based evaluators.
- **Dimension Pipelines**: hybrid LLM + structural evaluation for
  constraints, evidence, and provenance.
- **Runner**: per-run evaluation orchestration with multi-judge aggregation.
- **Aggregate**: cross-run summary statistics and correlation analysis.

LLM dependencies are lazily imported.  The stub judge works without API
keys, enabling CI testing and reproducible baselines.
"""

from .rubric import (
    DIMENSION_WEIGHTS,
    RUBRIC_SCHEMA,
    compute_overall_score,
    validate_evaluation_dict,
)
from .judge_base import BaseJudge
from .stub_judge import DeterministicJudge
from .llm_judge import LLMJudge
from .dimension_pipelines import (
    evaluate_constraints,
    evaluate_evidence,
    evaluate_provenance,
)
from .runner import evaluate_run
from .aggregate import aggregate_evaluations

__all__ = [
    # Rubric
    "DIMENSION_WEIGHTS",
    "RUBRIC_SCHEMA",
    "compute_overall_score",
    "validate_evaluation_dict",
    # Judges
    "BaseJudge",
    "DeterministicJudge",
    "LLMJudge",
    # Dimension pipelines
    "evaluate_constraints",
    "evaluate_evidence",
    "evaluate_provenance",
    # Runner & aggregate
    "evaluate_run",
    "aggregate_evaluations",
]
