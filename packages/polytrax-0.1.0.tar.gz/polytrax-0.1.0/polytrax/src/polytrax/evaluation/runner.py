# polytrax/src/polytrax/evaluation/runner.py
"""
polytrax.evaluation.runner — run-level evaluation orchestrator.

Loads run artefacts, invokes multiple judges, runs dimension pipelines,
computes aggregated statistics, and writes structured JSON output.
"""

from __future__ import annotations

import json
import os
import statistics
from typing import Any, Dict, List, Optional

from .judge_base import BaseJudge
from .rubric import validate_evaluation_dict
from .dimension_pipelines import (
    evaluate_constraints,
    evaluate_evidence,
    evaluate_provenance,
)


# ── Helpers ─────────────────────────────────────────────────────────


def _load_json(path: str) -> Optional[Dict[str, Any]]:
    """Load a JSON file; return None if it does not exist."""
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _load_text(path: str) -> Optional[str]:
    """Load a text file; return None if it does not exist."""
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def _safe_stdev(values: List[float]) -> float:
    """Standard deviation; returns 0.0 for fewer than 2 values."""
    if len(values) < 2:
        return 0.0
    return statistics.stdev(values)


def _aggregate_judge_results(
    judge_results: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    """Compute mean and std dev per dimension across judges."""
    score_fields = [
        "constraint_score",
        "evidence_score",
        "provenance_score",
        "accuracy_score",
        "relevance_score",
        "critique_quality_score",
        "context_precision_score",
        "context_recall_score",
        "overall_score",
        "confidence",
    ]

    aggregated: Dict[str, Any] = {}
    all_overalls: List[float] = []

    for field in score_fields:
        values = [
            float(res.get(field, 0))
            for res in judge_results.values()
        ]
        if values:
            mean_key = f"mean_{field}"
            std_key = f"std_{field}"
            aggregated[mean_key] = round(statistics.mean(values), 4)
            aggregated[std_key] = round(_safe_stdev(values), 4)
            if field == "overall_score":
                all_overalls = values

    # Inter-judge variance (variance of overall scores).
    if len(all_overalls) >= 2:
        aggregated["inter_judge_variance"] = round(
            statistics.variance(all_overalls), 4
        )
    else:
        aggregated["inter_judge_variance"] = 0.0

    return aggregated


# ── Public API ──────────────────────────────────────────────────────


def evaluate_run(
    run_dir: str,
    judges: List[BaseJudge],
    output_filename: str = "eval.json",
    *,
    corpus_type: Optional[str] = None,
    timing: Optional[str] = None,
) -> Dict[str, Any]:
    """Evaluate a single run using multiple judges.

    Steps:
    1. Load run_report.json, meta.json, final_briefing.txt from *run_dir*.
    2. Call each judge's ``evaluate()`` method.
    3. Run dimension pipelines with mean of judge scores.
    4. Aggregate statistics (mean, std, inter-judge variance).
    5. Write structured JSON to ``run_dir/output_filename``.

    Parameters
    ----------
    run_dir:
        Path to a run directory containing at least ``run_report.json``.
    judges:
        List of ``BaseJudge`` instances (minimum 1).
    output_filename:
        Name of the output JSON file.  Default ``"eval.json"``.

    Returns
    -------
    dict
        Complete evaluation results including judge_results, aggregated
        stats, and dimension pipeline outputs.

    Raises
    ------
    FileNotFoundError
        If ``run_report.json`` is missing.
    ValueError
        If no judges are provided.
    """
    if not judges:
        raise ValueError("At least one judge must be provided.")

    # ── Load artefacts ──────────────────────────────────────────────
    report_path = os.path.join(run_dir, "run_report.json")
    run_report = _load_json(report_path)
    if run_report is None:
        raise FileNotFoundError(
            f"run_report.json not found in {run_dir}"
        )

    meta = _load_json(os.path.join(run_dir, "meta.json")) or {}
    briefing_text = _load_text(
        os.path.join(run_dir, "final_briefing.txt")
    ) or ""

    # ── Load raw artefacts for grounded evaluation ──────────────
    raw_inputs: Dict[str, Any] = {}
    
    # Try mission goal
    goal = _load_text(os.path.join(run_dir, "mission_goal.txt"))
    if goal:
        raw_inputs["mission_goal"] = goal
    
    # Try agent messages summary
    messages = _load_json(os.path.join(run_dir, "messages.json"))
    if messages is None:
        messages_path = os.path.join(run_dir, "messages.jsonl")
        if os.path.isfile(messages_path):
            with open(messages_path, "r", encoding="utf-8") as fh:
                parsed_messages = []
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        parsed_messages.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
            messages = parsed_messages
    if messages:
        raw_inputs["messages"] = messages

    # ── Invoke judges ───────────────────────────────────────────────
    judge_results: Dict[str, Dict[str, Any]] = {}
    for judge in judges:
        try:
            result = judge.evaluate(
                briefing_text=briefing_text,
                consolidated_assessment=None,
                run_report=run_report,
                raw_inputs=raw_inputs,
            )
            validate_evaluation_dict(result)
            judge_results[judge.name] = result
        except Exception as exc:
            # Record the error but continue with other judges.
            judge_results[judge.name] = {"_error": str(exc)}

    # ── Dimension pipelines ─────────────────────────────────────────
    # Use only successful judge results for pipeline blending.
    valid_scores = [
        v for v in judge_results.values() if "_error" not in v
    ]

    dimension_results = {
        "constraints": evaluate_constraints(valid_scores, run_report),
        "evidence": evaluate_evidence(
            valid_scores, run_report, briefing_text=briefing_text
        ),
        "provenance": evaluate_provenance(valid_scores, run_report),
    }

    # ── Aggregate ───────────────────────────────────────────────────
    valid_judge_results = {
        k: v for k, v in judge_results.items() if "_error" not in v
    }
    aggregated = _aggregate_judge_results(valid_judge_results)

    # ── Assemble output ─────────────────────────────────────────────
    # Standardize library scores (0-5 or 0-1) to corpus scale (0-10)
    from .scoring import finalize_eval_data

    standardized_results = {}
    for name, res in judge_results.items():
        if "_error" in res:
            standardized_results[name] = res
            continue
            
        def _scale(v, factor=2.0):
            try: return round(float(v) * factor, 2)
            except: return 0.0

        standardized_results[name] = {
            "accuracy": _scale(res.get("accuracy_score", 0)),
            "relevance": _scale(res.get("relevance_score", 0)),
            "context_precision": _scale(res.get("context_precision_score", 0), 10.0),
            "context_recall": _scale(res.get("context_recall_score", 0), 10.0),
            "critique_quality": _scale(res.get("critique_quality_score", 0)),
        }
        standardized_results[name]["overall"] = round(
            (
                standardized_results[name]["accuracy"]
                + standardized_results[name]["relevance"]
                + standardized_results[name]["context_precision"]
                + standardized_results[name]["context_recall"]
                + standardized_results[name]["critique_quality"]
            ) / 5.0,
            2,
        )

    # Use the unified scoring logic to produce canonical output
    otps = run_report.get("offline_tps", {}).get("trust_risk_score", 
           run_report.get("offline_tps", {}).get("score", 0.0))

    output = finalize_eval_data(
        run_id=meta.get("run_id", run_report.get("run_id", "")),
        judge_results=standardized_results,
        scenario=meta.get("scenario", "unknown"),
        timing=timing if timing is not None else meta.get("timing", ""),
        corpus_type=corpus_type if corpus_type is not None else meta.get("corpus_type", "live"),
        original_o_tps=otps
    )

    output["judges_failed"] = [
        name for name, res in standardized_results.items()
        if "_error" in res or res.get("overall", 0) <= 0
    ]
    output["judges_available"] = [
        name for name, res in standardized_results.items()
        if "_error" not in res and res.get("overall", 0) > 0
    ]

    # Preserve library-specific metadata for backward compatibility
    output["judge_results"] = standardized_results
    output["dimension_pipelines"] = dimension_results
    output["_library_metadata"] = {
        "raw_judge_results": judge_results,
        "aggregated": aggregated,
        "seed": meta.get("seed")
    }

    # ── Write output ────────────────────────────────────────────────
    if output_filename:
        out_path = os.path.join(run_dir, output_filename)
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        print(f"[POLYTRAX-AUDIT] evaluate_run_write | {__file__} | {out_path} | keys={list(output.keys())} | otps_score={output.get('o_tps_score')}")
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(output, fh, indent=2, default=str)
            fh.write("\n")

    return output


def main():
    import argparse
    from .stub_judge import DeterministicJudge
    from .llm_judge import LLMJudge
    from .aggregate import aggregate_evaluations

    parser = argparse.ArgumentParser(description="PolyTrax Evaluation Runner")
    parser.add_argument("--runs-dir", required=True, help="Directory containing run subfolders")
    parser.add_argument("--output-filename", default="eval.json")
    parser.add_argument("--model", default="gpt-4o")
    args = parser.parse_args()

    runs_dir = args.runs_dir
    if not os.path.isdir(runs_dir):
        print(f"Error: {runs_dir} is not a directory")
        return

    # Setup judges
    judges: List[BaseJudge] = []
    
    # Always include a high-entropy stub judge for baseline comparison
    judges.append(DeterministicJudge(judge_name="det-ref-1"))
    
    # Add LLM judge if API key is present
    if os.getenv("OPENAI_API_KEY") or os.getenv("GEMINI_API_KEY"):
        judges.append(LLMJudge(judge_name="llm-judge-1", model=args.model))

    print(f"Starting evaluation on {runs_dir}...")
    print(f"Judges: {[j.name for j in judges]}")

    run_paths: List[str] = []
    
    # Discover runs (subdirs with run_report.json)
    for entry in sorted(os.listdir(runs_dir)):
        run_path = os.path.join(runs_dir, entry)
        if not os.path.isdir(run_path):
            continue
        
        report_path = os.path.join(run_path, "run_report.json")
        if not os.path.isfile(report_path):
            continue
            
        print(f"  Evaluating {entry}...")
        try:
            evaluate_run(run_path, judges, args.output_filename)
            run_paths.append(run_path)
        except Exception as e:
            print(f"    Failed: {e}")

    if run_paths:
        # Generate aggregate report in the parent directory
        agg_path = os.path.join(runs_dir, "evaluation_summary.json")
        summary = aggregate_evaluations(run_paths)
        with open(agg_path, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"\nEvaluation complete. Summary written to {agg_path}")
    else:
        print("\nNo runs evaluated.")


if __name__ == "__main__":
    main()
