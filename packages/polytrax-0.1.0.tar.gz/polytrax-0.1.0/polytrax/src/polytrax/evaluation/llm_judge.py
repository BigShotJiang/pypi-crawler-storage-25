# polytrax/src/polytrax/evaluation/llm_judge.py
"""
polytrax.evaluation.llm_judge — LLM-based evaluation judge using OpenAI API.

``LLMJudge`` sends structured prompts to an LLM (default: gpt-4o) and
expects strict JSON responses conforming to the rubric schema.

Dependencies are lazily imported so the module can be loaded without
``openai`` installed.  An ``OPENAI_API_KEY`` environment variable (or
explicit ``api_key``) is required only when ``evaluate()`` is called.  Supports
    custom ``base_url`` (e.g. for Groq or local LLMs).
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

from .judge_base import BaseJudge
from .rubric import RUBRIC_SCHEMA, compute_overall_score, validate_evaluation_dict


# ── Prompt templates ────────────────────────────────────────────────

_SYSTEM_PROMPT = """\
You are an expert evaluator for multi-agent system (MAS) communication traces.

You MUST evaluate the provided run along the following dimensions and return
ONLY a JSON object (no markdown, no explanation, no commentary).

## Scoring Rubric

Each dimension is scored on an integer scale of 0–5:
  0 = completely fails
  1 = severe deficiencies
  2 = significant issues
  3 = acceptable with notable gaps
  4 = good with minor issues
  5 = excellent

### Dimensions

1. **Constraint Adherence** (constraint_score, constraint_reason)
   How well the system respects declared operational constraints and guardrails.

2. **Evidence Grounding** (evidence_score, evidence_reason)
   Whether claims are supported by citations, source references, and verifiable data.

3. **Provenance Traceability** (provenance_score, provenance_reason)
   Whether information can be traced back to its origin through the chain of agents.

4. **Accuracy** (accuracy_score, accuracy_reason)
   Factual correctness and consistency of the output.

5. **Relevance** (relevance_score, relevance_reason)
   How relevant the output is to the stated mission or query.

6. **Critique Quality** (critique_quality_score)
   Quality of self-assessment, identification of limitations, and uncertainty.

### Additional Metrics (float 0–1)

- **context_precision_score**: Precision of context used (0.0–1.0)
- **context_recall_score**: Recall of relevant context (0.0–1.0)
- **confidence**: Your confidence in this evaluation (0.0–1.0)

### Computed Field

- **overall_score**: Set to 0.0 (will be recalculated by the system)

## Required JSON Schema

{
  "constraint_score": int (0-5),
  "constraint_reason": str,
  "evidence_score": int (0-5),
  "evidence_reason": str,
  "provenance_score": int (0-5),
  "provenance_reason": str,
  "accuracy_score": int (0-5),
  "accuracy_reason": str,
  "context_precision_score": float (0-1),
  "context_recall_score": float (0-1),
  "relevance_score": int (0-5),
  "critique_quality_score": int (0-5),
  "overall_score": 0.0,
  "confidence": float (0-1)
}

Return ONLY the JSON object. No markdown fences. No extra text."""

_USER_PROMPT_TEMPLATE = """\
## Briefing Text

{briefing_text}

## Consolidated Assessment

{consolidated_assessment}

## Run Report (structural metrics)

{run_report_json}

## Trace Summary

{trace_summary_json}

## Raw Operational Inputs (Grounded Truth)

{raw_inputs_json}

Evaluate this run and return the JSON evaluation object."""


def _truncate_text(text: Optional[str], limit: int) -> str:
    value = (text or "").strip()
    if len(value) <= limit:
        return value
    return value[: limit - 3] + "..."


def _compact_run_report(run_report: Dict[str, Any]) -> Dict[str, Any]:
    offline = run_report.get("offline_tps", {}) if isinstance(run_report, dict) else {}
    propagation = run_report.get("propagation", {}) if isinstance(run_report, dict) else {}
    graph = run_report.get("graph", {}) if isinstance(run_report, dict) else {}
    metadata = run_report.get("metadata", {}) if isinstance(run_report, dict) else {}
    return {
        "run_id": run_report.get("run_id"),
        "offline_tps": {
            "trust_risk_score": offline.get("trust_risk_score", offline.get("score")),
            "risk_class": offline.get("risk_class"),
            "recommended_action": offline.get("recommended_action"),
            "primary_metrics": offline.get("primary_metrics", {}),
        },
        "propagation": {
            "final_reach": propagation.get("final_reach"),
            "propagation_depth": propagation.get("propagation_depth"),
            "violation_persistence_ratio": propagation.get("violation_persistence_ratio"),
            "first_violation_hop": propagation.get("first_violation_hop"),
        },
        "graph": {
            "node_count": graph.get("node_count"),
            "edge_count": graph.get("edge_count"),
            "max_hop": graph.get("max_hop"),
        },
        "metadata": {
            "total_events": metadata.get("total_events"),
            "total_violation_events": metadata.get("total_violation_events"),
        },
    }


def _compact_raw_inputs(raw_inputs: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    raw_inputs = raw_inputs or {}
    messages = raw_inputs.get("messages", [])
    compact_messages = []
    for message in messages[:6]:
        compact_messages.append(
            {
                "sender": message.get("sender"),
                "receiver": message.get("receiver"),
                "payload": _truncate_text(json.dumps(message.get("payload", {}), default=str), 280),
            }
        )
    return {
        "mission_goal": _truncate_text(raw_inputs.get("mission_goal"), 500),
        "messages_sample": compact_messages,
        "message_count": len(messages) if isinstance(messages, list) else 0,
    }


def _extract_json_payload(raw_text: str) -> str:
    """Best-effort extraction of a JSON object from model output."""
    cleaned = (raw_text or "").strip()

    if "</think>" in cleaned:
        cleaned = cleaned.split("</think>")[-1].strip()

    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        lines = [
            ln for ln in lines
            if not ln.strip().startswith("```")
        ]
        cleaned = "\n".join(lines).strip()

    if cleaned.startswith("{") and cleaned.endswith("}"):
        return cleaned

    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1 and end > start:
        return cleaned[start:end + 1]

    return cleaned


def _coerce_to_rubric(data: Dict[str, Any]) -> Dict[str, Any]:
    if "constraint_score" in data:
        return data

    if not {"accuracy", "relevance", "context_precision", "context_recall", "critique_quality"}.issubset(data.keys()):
        return data

    accuracy = int(round(float(data.get("accuracy", 0)) / 2.0))
    relevance = int(round(float(data.get("relevance", 0)) / 2.0))
    context_precision = max(0.0, min(1.0, float(data.get("context_precision", 0)) / 10.0))
    context_recall = max(0.0, min(1.0, float(data.get("context_recall", 0)) / 10.0))
    critique_quality = int(round(float(data.get("critique_quality", 0)) / 2.0))

    return {
        "constraint_score": relevance,
        "constraint_reason": "Derived from compact judge response.",
        "evidence_score": int(round(float(data.get("context_precision", 0)) / 2.0)),
        "evidence_reason": "Derived from compact judge response.",
        "provenance_score": int(round(float(data.get("context_recall", 0)) / 2.0)),
        "provenance_reason": "Derived from compact judge response.",
        "accuracy_score": accuracy,
        "accuracy_reason": "Derived from compact judge response.",
        "context_precision_score": context_precision,
        "context_recall_score": context_recall,
        "relevance_score": relevance,
        "critique_quality_score": critique_quality,
        "overall_score": 0.0,
        "confidence": 0.8,
    }


class LLMJudge(BaseJudge):
    """LLM-based evaluation judge using the OpenAI API.

    Parameters
    ----------
    judge_name:
        Unique name for this judge instance.
    model:
        OpenAI model identifier.  Default ``"gpt-4o"``.
    base_url:
        Optional base URL for the API (e.g. "https://api.groq.com/openai/v1").
    temperature:
        Sampling temperature.  Default ``0`` for deterministic output.
    max_tokens:
        Maximum tokens in the response.  Default ``2048``.
    """

    def __init__(
        self,
        judge_name: str = "llm",
        *,
        model: str = "gpt-4o",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.0,
        max_tokens: int = 2048,
    ) -> None:
        self._name = judge_name
        self._model = model
        self._api_key = api_key
        self._base_url = base_url
        self._temperature = temperature
        self._max_tokens = max_tokens

    @property
    def name(self) -> str:
        return self._name

    def _is_groq_backed(self) -> bool:
        model_name = self._model.lower()
        base_url = (self._base_url or "").lower()
        return (
            "llama" in model_name
            or "qwen" in model_name
            or "groq" in base_url
        )

    def _candidate_api_keys(self) -> list[str]:
        """Return de-duplicated candidate API keys in fallback order."""
        candidates: list[str] = []

        primary_key = (self._api_key or os.environ.get("OPENAI_API_KEY") or "").strip()
        if primary_key:
            candidates.append(primary_key)

        if self._is_groq_backed():
            for env_name in ("GROQ_API_KEY", "NEW_GROQ_API_KEY", "BRAND_NEW_GROQ_API_KEY"):
                value = (os.environ.get(env_name) or "").strip()
                if value:
                    candidates.append(value)

        # Preserve order while removing duplicates.
        deduped: list[str] = []
        for key in candidates:
            if key not in deduped:
                deduped.append(key)
        return deduped

    def _get_client(self, api_key: str) -> Any:
        """Lazily import and instantiate the OpenAI-compatible client."""
        try:
            from openai import OpenAI  # type: ignore[import-untyped]
        except ImportError as exc:
            raise RuntimeError(
                "LLMJudge requires the 'openai' package. "
                "Install it with: pip install openai"
            ) from exc

        if not api_key:
            raise RuntimeError(
                f"LLMJudge ({self._name}) requires an API key. "
                "Set OPENAI_API_KEY (or GROQ_API_KEY for Groq models)."
            )

        return OpenAI(api_key=api_key, base_url=self._base_url)

    def evaluate(
        self,
        briefing_text: str,
        consolidated_assessment: Optional[str],
        run_report: Dict[str, Any],
        trace_summary: Optional[Dict[str, Any]] = None,
        raw_inputs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Call the LLM to evaluate a run and return a rubric-conformant dict."""
        candidate_keys = self._candidate_api_keys()
        if not candidate_keys:
            raise RuntimeError(
                f"LLMJudge ({self._name}) requires an API key. "
                "Set OPENAI_API_KEY (or GROQ_API_KEY for Groq models)."
            )

        user_prompt = _USER_PROMPT_TEMPLATE.format(
            briefing_text=_truncate_text(briefing_text or "(no briefing available)", 4000),
            consolidated_assessment=(
                _truncate_text(consolidated_assessment or "(no consolidated assessment)", 1000)
            ),
            run_report_json=json.dumps(_compact_run_report(run_report), indent=2, default=str),
            trace_summary_json=json.dumps(
                trace_summary or {}, indent=2, default=str
            ),
            raw_inputs_json=json.dumps(
                _compact_raw_inputs(raw_inputs), indent=2, default=str
            ),
        )

        last_exc: Optional[Exception] = None
        raw_text = ""
        for api_key in candidate_keys:
            client = self._get_client(api_key)
            try:
                response = client.chat.completions.create(
                    model=self._model,
                    temperature=self._temperature,
                    max_tokens=self._max_tokens,
                    messages=[
                        {"role": "system", "content": _SYSTEM_PROMPT},
                        {"role": "user", "content": user_prompt},
                    ],
                )
                raw_text = response.choices[0].message.content or ""
                break
            except Exception as exc:
                last_exc = exc
                error_text = str(exc).lower()
                is_auth_failure = "401" in error_text or "invalid api key" in error_text
                if not (self._is_groq_backed() and is_auth_failure):
                    raise
        else:
            assert last_exc is not None
            raise last_exc


        cleaned = _extract_json_payload(raw_text)

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"LLM returned invalid JSON: {exc}\nRaw response:\n{raw_text}"
            ) from exc

        data = _coerce_to_rubric(data)

        # Recompute overall_score with our weights.
        data["overall_score"] = compute_overall_score(data)

        # Validate against schema.
        validate_evaluation_dict(data)

        return data
