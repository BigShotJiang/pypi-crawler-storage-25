# polytrax/src/polytrax/analysis/graph.py
"""
Offline analysis: lightweight directed communication graph for USL traces.

- Builds a deterministic, in-memory graph from a completed JSONL trace.
- Includes ONLY message events: event_type in {"message_sent", "message_blocked"}.
- Requires sender and receiver.
- Does not mutate input events.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Set, Tuple


@dataclass(frozen=True)
class Edge:
    sender: str
    receiver: str
    hop_index: int
    event_id: str
    event_type: str
    ts: Optional[str]
    trust: Optional[dict]
    payload: dict
    # Step-aware identifiers
    sender_step: Optional[Tuple[str, int]] = None
    receiver_step: Optional[Tuple[str, int]] = None


class CommGraph:
    """Directed communication graph backed by adjacency lists."""

    def __init__(self, step_aware: bool = False) -> None:
        self.nodes: Set[str | Tuple[str, int]] = set()
        self.edges: List[Edge] = []
        self.adjacency: Dict[str | Tuple[str, int], List[Edge]] = {}
        self.step_aware = step_aware

    def add_edge(self, edge: Edge) -> None:
        self.edges.append(edge)
        u = edge.sender_step if self.step_aware and edge.sender_step else edge.sender
        v = edge.receiver_step if self.step_aware and edge.receiver_step else edge.receiver
        self.nodes.add(u)
        self.nodes.add(v)
        self.adjacency.setdefault(u, []).append(edge)

    def outgoing(self, node: str | Tuple[str, int]) -> List[Edge]:
        return list(self.adjacency.get(node, []))

    def incoming(self, node: str | Tuple[str, int]) -> List[Edge]:
        # Deterministic: preserve edge order as stored in self.edges
        if self.step_aware:
            return [e for e in self.edges if e.receiver_step == node]
        return [e for e in self.edges if e.receiver == node]

    def edge_count(self) -> int:
        return len(self.edges)

    def node_count(self) -> int:
        return len(self.nodes)

    def max_hop(self) -> int:
        if not self.edges:
            return 0
        return max(e.hop_index for e in self.edges)

    def sort_edges(self) -> None:
        # Deterministic ordering: hop_index then event_id
        self.edges.sort(key=lambda e: (e.hop_index, e.event_id))
        # Rebuild adjacency in the same deterministic order
        self.adjacency.clear()
        for e in self.edges:
            u = e.sender_step if self.step_aware and e.sender_step else e.sender
            self.adjacency.setdefault(u, []).append(e)


def _safe_int(x: object, default: int = 0) -> int:
    try:
        if isinstance(x, (int, float, str)):
            return int(x)
    except:
        pass
    return default


def build_graph(events: Iterable[dict], step_aware: bool = False) -> CommGraph:
    """
    Build a CommGraph from an iterable of USL event dicts.

    Rules:
    - Include only message events: {"message_sent","message_blocked"}
    - Require sender and receiver (strings)
    - hop_index defaults to 0 if missing/invalid
    - Preserve trust and payload references (no mutation)
    - Deterministic ordering via sort_edges()
    - if step_aware=True, node IDs are (agent_name, hop_index)
    """
    g = CommGraph(step_aware=step_aware)

    for ev in events:
        if not isinstance(ev, dict):
            continue

        event_type = ev.get("event_type")
        if event_type not in {"message_sent", "message_blocked"}:
            continue

        sender = ev.get("sender")
        receiver = ev.get("receiver")
        if not isinstance(sender, str) or not isinstance(receiver, str):
            continue

        hop_index = _safe_int(ev.get("hop_index"), default=0)
        event_id = ev.get("event_id")
        if not isinstance(event_id, str):
            event_id = ""

        ts = ev.get("ts")
        if not isinstance(ts, str):
            ts = None

        trust = ev.get("trust")
        if trust is not None and not isinstance(trust, dict):
            trust = None

        payload = ev.get("payload")
        if not isinstance(payload, dict):
            payload = {}

        g.add_edge(
            Edge(
                sender=sender,
                receiver=receiver,
                hop_index=hop_index,
                event_id=event_id,
                event_type=str(event_type),
                ts=ts,
                trust=trust,
                payload=payload,
                sender_step=(sender, hop_index),
                receiver_step=(receiver, hop_index),
            )
        )

    g.sort_edges()
    return g