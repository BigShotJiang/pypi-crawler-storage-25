# polytrax/src/polytrax/analysis/__init__.py
"""
polytrax.analysis — offline / analysis plane.

Provides deterministic post-hoc analysis for completed USL traces:
- graph reconstruction
- traversal utilities
- propagation metrics
- authoritative Offline TPS (O-TPS)
- containment replay simulation (halt/gate)
"""

from .graph import Edge, CommGraph, build_graph
from .propagation import compute_run_metrics
from .tps_replay import compute_o_tps, replay_o_tps, OfflineTPSOutput
from .containment import apply_halt, apply_gate, containment_effectiveness
from .localization import BreachLocalizer, LocalizationResult

__all__ = [
    "Edge",
    "CommGraph",
    "build_graph",
    "compute_run_metrics",
    "compute_o_tps",
    "replay_o_tps",
    "OfflineTPSOutput",
    "apply_halt",
    "apply_gate",
    "containment_effectiveness",
    "BreachLocalizer",
    "LocalizationResult",
]