# polytrax/src/polytrax/analysis/traversal.py
"""
Offline analysis: deterministic multi-hop traversal utilities.

These functions operate on CommGraph and return deterministic outputs
by using sorted traversal order.
"""

from __future__ import annotations

from collections import deque
from typing import Deque, Dict, List, Optional, Set, Tuple

from .graph import CommGraph, Edge


def _sorted_outgoing(graph: CommGraph, node: str) -> List[Edge]:
    # Ensure deterministic neighbor expansion.
    out = graph.outgoing(node)
    return sorted(out, key=lambda e: (e.receiver, e.hop_index, e.event_id))


def bfs_reachable(
    graph: CommGraph, start_nodes: Iterable[str | Tuple[str, int]]
) -> Dict[str | Tuple[str, int], int]:
    """
    Standard BFS traversal. Returns {node: min_distance_from_starts}.
    Start nodes themselves are at distance 0.
    """
    distances: Dict[str | Tuple[str, int], int] = {n: 0 for n in start_nodes}
    queue = list(start_nodes)

    idx_q = 0
    while idx_q < len(queue):
        u = queue[idx_q]
        idx_q += 1

        d = distances[u]
        for edge in graph.outgoing(u):
            # In step-aware mode, use the receiver_step, else standard receiver string.
            v: str | Tuple[str, int]
            if graph.step_aware and edge.receiver_step:
                v = edge.receiver_step
            else:
                v = edge.receiver

            if v not in distances:
                distances[v] = d + 1
                queue.append(v)

    return distances


def subgraph_edges_from(graph: CommGraph, start_nodes: Set[str]) -> List[Edge]:
    """
    Return edges encountered when traversing outward from start_nodes.

    Deterministic:
    - traversal is deterministic
    - output edges are sorted by (hop_index, event_id)
    """
    seen_nodes = bfs_reachable(graph, start_nodes)
    # Include edges whose sender is reachable (including the start nodes)
    edges = [e for e in graph.edges if e.sender in seen_nodes]
    return sorted(edges, key=lambda e: (e.hop_index, e.event_id))


def paths_to_nodes(
    graph: CommGraph,
    start: str,
    targets: Set[str],
    max_depth: int = 10,
) -> Dict[str, List[str]]:
    """
    Compute one deterministic shortest path (by BFS) from start to each target.

    Returns:
      target -> [start, ..., target]

    Constraints:
    - max_depth limits BFS expansion depth (in edges).
    - If a target is unreachable within max_depth, it is omitted.

    Deterministic:
    - neighbor expansion order is sorted.
    """
    if max_depth < 0:
        raise ValueError("max_depth must be >= 0")

    if start in targets:
        return {start: [start]}

    q: Deque[str] = deque([start])
    parent: Dict[str, Optional[str]] = {start: None}
    depth: Dict[str, int] = {start: 0}

    while q:
        u = q.popleft()
        du = depth[u]
        if du >= max_depth:
            continue

        for e in _sorted_outgoing(graph, u):
            v = e.receiver
            if v not in parent:
                parent[v] = u
                depth[v] = du + 1
                q.append(v)

    out: Dict[str, List[str]] = {}
    for t in sorted(targets):
        if t not in parent:
            continue
        # Reconstruct path
        path: List[str] = []
        cur: Optional[str] = t
        while cur is not None:
            path.append(cur)
            cur = parent[cur]
        path.reverse()
        if path and path[0] == start:
            out[t] = path

    return out