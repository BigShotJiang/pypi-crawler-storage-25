"""
Token usage estimation for PolyTrax runs.

For LLM runs where exact token counts were not captured at runtime,
this module derives principled per-run estimates from actual trace content.

Methodology
-----------
GPT-4o-mini token estimation uses the approximation:
  tokens ≈ len(text) / 4

This is the standard rule-of-thumb for English text with OpenAI tokenisers
(verified against tiktoken for typical intelligence briefing content).
It produces run-specific estimates that vary meaningfully between runs
because they are derived from actual payload content lengths — specifically
the state_snapshot field which grows as the MAS accumulates intel reports.

Per-call overhead is added to account for system prompt, role tokens, and
structured output schema tokens not present in the payload snapshot.

Model pricing (GPT-4o-mini, early 2026):
  Input:  $0.15 per 1M tokens
  Output: $0.60 per 1M tokens

Estimation is only applied to llm_real corpus runs.
Stub runs receive zero / null token values (no LLM calls are made).
"""

from __future__ import annotations

from typing import Dict, List, Optional

# ─── Per-node-type system prompt overhead (tokens) ─────────────────────────
# Estimates of system prompt + schema instruction size for each node category.
NODE_OVERHEAD: Dict[str, int] = {
    "collector": 450,   # domain context + collection schema
    "analyst":   520,   # analysis instructions + source_chain schema
    "fusion":    680,   # corroboration rules + provenance_map schema
    "senior":    600,   # all-source assessment framework
    "briefing":  550,   # dissemination format instructions
    "default":   400,   # all other nodes
}

# ─── Output / input token ratio by node type ────────────────────────────────
OUTPUT_RATIO: Dict[str, float] = {
    "collector": 0.35,
    "analyst":   0.45,
    "fusion":    0.55,
    "senior":    0.60,
    "briefing":  0.70,
    "default":   0.40,
}

INPUT_PRICE_PER_M  = 0.15   # USD per 1M input tokens (GPT-4o-mini)
OUTPUT_PRICE_PER_M = 0.60   # USD per 1M output tokens (GPT-4o-mini)


def get_node_category(node_name: str) -> str:
    """Map node name to category for overhead/output-ratio estimation."""
    n = node_name.lower()
    if "collect" in n:                     return "collector"
    if "analyst" in n:                     return "analyst"
    if "fusion" in n:                      return "fusion"
    if "senior" in n:                      return "senior"
    if "briefing" in n or "composer" in n: return "briefing"
    return "default"


def _count_chars(obj) -> int:
    """Recursively count total characters in all string values of an object."""
    if isinstance(obj, str):
        return len(obj)
    if isinstance(obj, dict):
        return sum(_count_chars(v) for v in obj.values())
    if isinstance(obj, (list, tuple)):
        return sum(_count_chars(item) for item in obj)
    return 0


def estimate_payload_tokens(payload: dict) -> int:
    """
    Estimate tokens in a payload dict by summing text content lengths.
    Uses len(text) / 4 approximation for English text.
    Minimum 1 token to avoid zero-division downstream.
    """
    if not isinstance(payload, dict):
        return 1
    return max(1, _count_chars(payload) // 4)


def estimate_run_tokens(events: List[dict]) -> dict:
    """
    Estimate total token usage for a run from its USL trace events.

    Groups message_sent events by (receiver, hop_index) to count unique
    LLM calls — each invocation of a node triggers one API call.

    Returns a dict matching the existing token_usage.json schema:
        run_id:                  (caller should add)
        corpus_type:             (caller should add)
        total_prompt_tokens:     int
        total_completion_tokens: int
        total_tokens:            int
        estimated_cost_usd:      float
        per_node_calls:          int   (number of LLM calls estimated)
        is_estimate:             True  (flag to distinguish from exact counts)
        methodology:             str
    """
    message_events = [
        e for e in events
        if isinstance(e, dict)
        and e.get("event_type") == "message_sent"
        and isinstance(e.get("payload"), dict)
        and e.get("sender") not in ("__start__", "polytrax", None)
    ]

    # Each unique (receiver, hop_index) represents one LLM invocation.
    # receiver = the node being called; hop_index disambiguates re-invocations.
    llm_calls: Dict[tuple, dict] = {}
    for e in message_events:
        receiver = e.get("receiver", "")
        hop = e.get("hop_index", 0)
        key = (receiver, hop)
        if key not in llm_calls:
            llm_calls[key] = {
                "node": receiver,
                "payload_tokens": estimate_payload_tokens(e.get("payload", {})),
                "category": get_node_category(receiver),
            }

    total_prompt = 0
    total_completion = 0

    for call in llm_calls.values():
        cat = call["category"]
        overhead = NODE_OVERHEAD.get(cat, NODE_OVERHEAD["default"])
        payload_tokens = call["payload_tokens"]
        prompt_tokens = overhead + payload_tokens
        completion_tokens = max(50, int(prompt_tokens * OUTPUT_RATIO.get(cat, 0.40)))
        total_prompt += prompt_tokens
        total_completion += completion_tokens

    total = total_prompt + total_completion
    cost = (
        total_prompt     / 1_000_000 * INPUT_PRICE_PER_M
        + total_completion / 1_000_000 * OUTPUT_PRICE_PER_M
    )

    return {
        "total_prompt_tokens":     total_prompt,
        "total_completion_tokens": total_completion,
        "total_tokens":            total,
        "estimated_cost_usd":      round(cost, 6),
        "per_node_calls":          len(llm_calls),
        "is_estimate":             True,
        "methodology": (
            "Estimated from trace payload content using len(text)/4 token approximation "
            "plus per-node-type system prompt overhead. Varies between runs because the "
            "state_snapshot field grows as the MAS accumulates intel reports."
        ),
    }


def estimate_contained_tokens(
    full_token_data: Optional[dict],
    original_hops: int,
    contained_hops: int,
) -> Optional[dict]:
    """
    Estimate tokens saved by containment using proportional hop reduction.

    Assumes token usage scales approximately linearly with hops executed.
    This is a conservative estimate — the nodes skipped may be heavier (e.g.
    fusion, senior analyst) so actual savings may exceed this estimate.

    Returns None if full_token_data is not available or original_hops == 0.
    """
    if not full_token_data or original_hops == 0:
        return None

    ratio = contained_hops / original_hops
    full_total = full_token_data.get("total_tokens", 0)
    full_prompt = full_token_data.get("total_prompt_tokens", 0)
    full_completion = full_token_data.get("total_completion_tokens", 0)
    full_cost = full_token_data.get("estimated_cost_usd", 0.0)

    contained_total = int(full_total * ratio)
    contained_prompt = int(full_prompt * ratio)
    contained_completion = int(full_completion * ratio)
    contained_cost = round(full_cost * ratio, 6)

    tokens_saved = full_total - contained_total
    cost_saved = round(full_cost - contained_cost, 6)

    return {
        "total_prompt_tokens":     contained_prompt,
        "total_completion_tokens": contained_completion,
        "total_tokens":            contained_total,
        "estimated_cost_usd":      contained_cost,
        "tokens_saved":            tokens_saved,
        "cost_saved_usd":          cost_saved,
        "is_estimate":             True,
        "methodology": (
            "Proportional estimate based on contained_hops/original_hops ratio. "
            "Actual savings may be higher if skipped nodes are token-heavy (fusion, senior)."
        ),
    }
