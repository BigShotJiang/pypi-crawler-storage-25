# polytrax/src/polytrax/analysis/propagation.py
"""
Offline analysis: trust violation localisation and propagation metrics.

Violation rule (edge-level):
- event_type == "message_blocked"
OR
- trust C/E/P severity > 0

Severity extraction for trust[dim]:
- trust[dim]["severity"] if present
- trust[dim]["status"] mapped: ok=0.0, warn=0.5, fail=1.0
- missing/invalid -> 0.0
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

from .graph import CommGraph, Edge
from .traversal import bfs_reachable


def _clamp01(x: float) -> float:
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return float(x)


def _status_to_severity(status: str) -> float:
    m = {"ok": 0.0, "warn": 0.5, "fail": 1.0}
    return float(m.get(status, 0.0))


def _dim_severity(dim_val: object) -> float:
    if not isinstance(dim_val, dict):
        return 0.0
    if "severity" in dim_val:
        try:
            return _clamp01(float(dim_val["severity"]))
        except Exception:
            return 0.0
    if "status" in dim_val:
        try:
            return _clamp01(_status_to_severity(str(dim_val["status"]).lower()))
        except Exception:
            return 0.0
    return 0.0


def _is_offline_replay_block(edge: Edge) -> bool:
    payload = edge.payload if isinstance(edge.payload, dict) else {}
    containment = payload.get("containment")
    return (
        edge.event_type == "message_blocked"
        and isinstance(containment, dict)
        and containment.get("reason") == "offline_replay"
    )


def edge_severity(edge: Edge, *, wC: float = 0.33, wE: float = 0.33, wP: float = 0.34) -> float:
    """Compute weighted severity for a message edge. message_blocked => 1.0."""
    if _is_offline_replay_block(edge):
        return 0.0
    if edge.event_type == "message_blocked":
        return 1.0
    trust = edge.trust if isinstance(edge.trust, dict) else None
    if not trust:
        return 0.0
    c = _dim_severity(trust.get("constraints"))
    e = _dim_severity(trust.get("evidence"))
    p = _dim_severity(trust.get("provenance"))
    return _clamp01((wC * c) + (wE * e) + (wP * p))


# Thresholds for research-grade hardening
WARNING_THRESHOLD = 0.4
VIOLATION_THRESHOLD = 0.7


def classify_edge_status(edge: Edge) -> str:
    """Classify edge as clean, warning, or violation based on severity."""
    if _is_offline_replay_block(edge):
        return "clean"
    if edge.event_type == "message_blocked":
        return "violation"
    
    # Research-Grade Sensitivity Fix:
    # A violation is triggered if the consolidated severity is high,
    # OR if any single dimension has a severity >= VIOLATION_THRESHOLD.
    # Research-Grade Mask: Initial setup at mission_controller hop 0
    # often lacks citations/provenance as it is the bootstrap goal.
    if edge.receiver == "mission_controller" and edge.hop_index == 0:
        return "clean"

    trust = edge.trust if isinstance(edge.trust, dict) else {}
    c = _dim_severity(trust.get("constraints"))
    e = _dim_severity(trust.get("evidence"))
    p = _dim_severity(trust.get("provenance"))
    
    sev = edge_severity(edge)
    
    if sev >= VIOLATION_THRESHOLD or any(d >= VIOLATION_THRESHOLD for d in [c, e, p]):
        return "violation"
    if sev >= WARNING_THRESHOLD:
        return "warning"
    return "clean"


def is_warning(edge: Edge) -> bool:
    return classify_edge_status(edge) == "warning"


def is_violation(edge: Edge) -> bool:
    """True if edge is a violation (severity >= 0.7 or blocked)."""
    return classify_edge_status(edge) == "violation"


def find_violation_edges(graph: CommGraph) -> List[Edge]:
    """Return violating edges in deterministic order (graph edges are already sorted)."""
    return [e for e in graph.edges if is_violation(e)]


def first_violation_hop(graph: CommGraph) -> Optional[int]:
    """Return the smallest hop_index among violating edges, else None."""
    vio = find_violation_edges(graph)
    if not vio:
        return None
    return min(e.hop_index for e in vio)


def violation_persistence_ratio(graph: CommGraph) -> float:
    """
    Ratio of violating message edges to all message edges in the trace.
    Graph contains message edges only, so M = edge_count.
    """
    m = max(graph.edge_count(), 1)
    v = len(find_violation_edges(graph))
    return float(v) / float(m)


def propagation_depth(graph: CommGraph) -> int:
    """
    Depth proxy: max BFS hop-distance from violating receivers.

    Start nodes = ONLY the receivers of violating edges.
    If no violations, depth=0.
    """
    vio = find_violation_edges(graph)
    if not vio:
        return 0
    # Research Correction: start only from receivers
    starts: Set[str] = {e.receiver for e in vio}

    dist = bfs_reachable(graph, starts)
    if not dist:
        return 0
    return max(dist.values())


def final_reach(graph: CommGraph) -> int:
    """
    Reach proxy: number of nodes reachable (including start nodes) from
    violating receivers via directed traversal.

    If no violations, reach=0.
    """
    vio = find_violation_edges(graph)
    if not vio:
        return 0
    # Research Correction: start only from receivers
    starts: Set[str] = {e.receiver for e in vio}
    dist = bfs_reachable(graph, starts)
    return len(dist)


def graph_stats(graph: CommGraph) -> Dict[str, int]:
    """Basic graph stats."""
    return {
        "node_count": graph.node_count(),
        "edge_count": graph.edge_count(),
        "max_hop": graph.max_hop(),
    }


def compute_run_metrics(graph: CommGraph) -> Dict:
    """
    Compute core propagation metrics for a completed run.

    Returns:
      {
        first_violation_hop,
        propagation_depth,
        final_reach,
        violation_persistence_ratio,
        node_count,
        edge_count,
        max_hop
      }
    """
    stats = graph_stats(graph)
    vio_edges = find_violation_edges(graph)
    first_vio_hop = (
        min(
            e.hop_index for e in vio_edges
            if hasattr(e, 'hop_index') and e.hop_index is not None
        )
        if vio_edges else None
    )
    return {
        "first_violation_hop": first_vio_hop,
        "propagation_depth": propagation_depth(graph),
        "final_reach": final_reach(graph),
        "violation_persistence_ratio": violation_persistence_ratio(graph),
        "node_count": stats["node_count"],
        "edge_count": stats["edge_count"],
        "max_hop": stats["max_hop"],
    }
