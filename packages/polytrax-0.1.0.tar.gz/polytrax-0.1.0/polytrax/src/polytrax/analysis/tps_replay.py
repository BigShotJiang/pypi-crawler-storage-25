"""
Offline TPS (O-TPS) — PolyTrax authoritative post-hoc trust risk score.

Design principle: two-layer trust observability
------------------------------------------------
O-TPS operates on the STRUCTURAL LAYER. It answers: how severe and how
widespread is trust degradation in this run?

BreachLocalizer operates across STRUCTURAL + SEMANTIC LAYERS simultaneously.
It answers: where did the breach originate?

The two systems share a deliberate signal vocabulary:

  O-TPS VR  <->  localisation candidate pool
                 (same violated-edge set — high VR = rich localisation signal)
  O-TPS SV  <->  localisation local_severity
                 (same noise-floor principle: violating edges only)
  O-TPS IM  <->  localisation propagation_influence
                 (same quantity at different granularity: run vs per-candidate)
  O-TPS DP  <->  localisation temporal_priority
                 (both capture pipeline position)

This coherence is by design. O-TPS quantifies the severity and spread of
trust degradation. Localisation attributes it to an origin. Together:

  High O-TPS + clear localisation  = contained, traceable breach
  High O-TPS + low confidence      = systemic degradation, no single origin
  Low O-TPS  + localisation result = structural noise, review trust policies

Semantic layer in O-TPS
-----------------------
O-TPS does NOT include semantic drift as a formula component. Adding it
would create correlation with SV and IM (semantic degradation causes
structural violations), violating component independence.

Instead, mean_semantic_drift is reported as an OBSERVATION FIELD alongside
the score — available in components['semantic_observation'] — so the
dashboard can display structural severity and semantic coherence degradation
side by side without conflating them in the weighted formula.

Semantic observation is computed only if sentence-transformers is available.
If not available, it is None and the five-component formula is unaffected.

Five-component formula
----------------------
VR  Violation Rate:      violating_edges / total_edges
CS  Cascade Spread:      final_reach / total_nodes
DP  Propagation Depth:   propagation_depth / max_hop  (linear)
SV  Severity:            mean severity of violating edges ONLY
IM  Impact:              downstream violation ratio after first breach hop

score = sigmoid(5 * weighted_sum - 2.5)

Default weights are pre-calibration starting points. After running
evaluation/scripts/calibrate_otps.py, pass recommended_configuration
weights via the weights parameter.
"""
from __future__ import annotations

import os
import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from .graph import build_graph
from .propagation import compute_run_metrics, find_violation_edges, edge_severity


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))

def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


DEFAULT_WEIGHTS: Dict[str, float] = {
    "violation_rate":    0.20,
    "cascade_spread":    0.20,
    "propagation_depth": 0.15,
    "severity":          0.25,
    "impact":            0.20,
}


@dataclass(frozen=True)
class OfflineTPSOutput:
    trust_risk_score: float
    risk_class: str
    recommended_action: str
    components: Dict
    metrics: Dict
    reasons: List[str]


def _compute_mean_semantic_drift(events: list[dict]) -> Optional[float]:
    """
    Compute mean semantic drift across all annotated events in the trace.
    Uses _semantic_drift field written by BreachLocalizer if localisation
    has already been run on this trace. Otherwise attempts local computation.
    Returns None if sentence-transformers is unavailable.
    This is an OBSERVATION FIELD — it does not feed into the O-TPS formula.
    """
    # First try to read pre-computed drift scores from annotated events
    drift_scores = [
        e.get("_semantic_drift")
        for e in events
        if isinstance(e.get("_semantic_drift"), (int, float))
    ]
    if drift_scores:
        return round(sum(drift_scores) / len(drift_scores), 4)

    # If not pre-computed, attempt local computation
    global _SENTENCE_MODEL_CACHE
    try:
        from sentence_transformers import SentenceTransformer
        import numpy as np
        if '_SENTENCE_MODEL_CACHE' not in globals() or globals()['_SENTENCE_MODEL_CACHE'] is None:
            try:
                globals()['_SENTENCE_MODEL_CACHE'] = SentenceTransformer(
                    "all-MiniLM-L6-v2",
                    local_files_only=True,
                )
            except Exception:
                globals()['_SENTENCE_MODEL_CACHE'] = SentenceTransformer("all-MiniLM-L6-v2")
        model = globals()['_SENTENCE_MODEL_CACHE']
    except ImportError:
        return None

    def _extract_text(payload: dict) -> str:
        if not isinstance(payload, dict):
            return ""
        parts = []
        for v in payload.values():
            if isinstance(v, str) and len(v) > 10:
                parts.append(v)
            elif isinstance(v, list):
                parts.extend(str(i) for i in v if isinstance(i, str))
        return " ".join(parts)[:500]

    message_events = [
        e for e in events
        if e.get("event_type") == "message_sent"
        and isinstance(e.get("payload"), dict)
    ]

    if len(message_events) < 4:
        return None

    window = 3
    drifts = []
    for i in range(window, len(message_events)):
        current_text = _extract_text(message_events[i].get("payload", {}))
        upstream_texts = [
            _extract_text(message_events[j].get("payload", {}))
            for j in range(i - window, i)
        ]
        upstream_text = " ".join(t for t in upstream_texts if t)
        if not current_text or not upstream_text:
            continue
        try:
            import threading
            result = [None]
            def _encode():
                result[0] = model.encode(
                    [current_text, upstream_text],
                    convert_to_numpy=True,
                    show_progress_bar=False,
                )
            t = threading.Thread(target=_encode, daemon=True)
            t.start()
            t.join(15)
            if result[0] is None:
                continue
            embs = result[0]
            dot = float(np.dot(embs[0], embs[1]))
            norm = float(np.linalg.norm(embs[0]) * np.linalg.norm(embs[1]))
            drift = 1.0 - (dot / norm if norm > 0 else 0.0)
            drifts.append(_clamp01(drift))
        except Exception:
            continue

    return round(sum(drifts) / len(drifts), 4) if drifts else None


def compute_o_tps(
    events: Iterable[dict],
    weights: Optional[Dict[str, float]] = None,
    include_semantic_observation: bool = True,
    noise_floor: float = 0.0,
) -> OfflineTPSOutput:
    """
    Compute Offline TPS (O-TPS) from a completed USL trace.

    Parameters
    ----------
    events : Iterable[dict]
        Full USL event list from trace.jsonl.

    weights : dict | None
        Component weights for the five structural components.
        Keys: violation_rate, cascade_spread, propagation_depth,
              severity, impact. Values must sum to 1.0.
        Pass calibrated weights from calibration_results.json after
        running the calibration study. Default: DEFAULT_WEIGHTS.

    include_semantic_observation : bool
        If True, compute mean_semantic_drift as an observation field
        alongside the score. Does not affect the formula.
        Set False to skip if performance is a concern.
    """
    w = weights if weights is not None else DEFAULT_WEIGHTS
    events = list(events)

    graph = build_graph(events)
    metrics = compute_run_metrics(graph)

    total_edges = max(graph.edge_count(), 1)
    total_nodes = max(graph.node_count(), 1)

    all_hops = [
        e.hop_index for e in graph.edges
        if hasattr(e, 'hop_index') and e.hop_index is not None
    ]
    max_hop = max(all_hops) if all_hops else 1

    vio_edges = find_violation_edges(graph)

    # VR
    VR = float(len(vio_edges)) / float(total_edges)

    # CS
    CS = _clamp01(float(metrics.get("final_reach", 0)) / float(total_nodes))

    # DP — linear, interpretable: DP=0.5 means breach reached pipeline midpoint
    DP_raw = float(metrics.get("propagation_depth", 0))
    first_vio_hop = metrics.get("first_violation_hop", None)
    if first_vio_hop is not None and first_vio_hop < max_hop:
        post_breach_window = float(max_hop - first_vio_hop)
        DP = _clamp01(DP_raw / post_breach_window) if post_breach_window > 0 else 0.0
    else:
        DP = _clamp01(DP_raw / float(max_hop))

    # SV — violating edges only, same noise-floor principle as localisation
    vio_sevs = [edge_severity(e) for e in vio_edges]
    SV = _clamp01(sum(vio_sevs) / len(vio_sevs) if vio_sevs else 0.0)

    # IM — downstream violation ratio, same quantity as propagation_influence
    first_vio_hop_for_im = metrics.get("first_violation_hop", None)
    if first_vio_hop_for_im is not None and vio_edges:
        downstream_total = sum(
            1 for e in graph.edges
            if hasattr(e, 'hop_index') and e.hop_index is not None
            and e.hop_index > first_vio_hop_for_im
        )
        downstream_vio = sum(
            1 for e in vio_edges
            if hasattr(e, 'hop_index') and e.hop_index is not None
            and e.hop_index > first_vio_hop_for_im
        )
        IM = _clamp01(float(downstream_vio) / downstream_total if downstream_total > 0 else 0.0)
    else:
        IM = 0.0

    # Weighted sum → sigmoid(5x - 2.5)
    score_raw = (
        w.get("violation_rate",    0.20) * VR
        + w.get("cascade_spread",  0.20) * CS
        + w.get("propagation_depth", 0.15) * DP
        + w.get("severity",        0.25) * SV
        + w.get("impact",          0.20) * IM
    )
    score = _clamp01(_sigmoid(5.0 * score_raw - 2.5))

    if noise_floor > 0.0:
        relative = (score - noise_floor) / (1.0 - noise_floor) if (1.0 - noise_floor) > 0 else score
        relative = _clamp01(relative)
        if relative < 0.15:
            risk_class, recommended_action = "LOW", "NO_ACTION"
        elif relative < 0.50:
            risk_class, recommended_action = "MEDIUM", "MONITOR"
        else:
            risk_class, recommended_action = "HIGH", "HALT"
    else:
        if score < 0.35:
            risk_class, recommended_action = "LOW", "NO_ACTION"
        elif score < 0.70:
            risk_class, recommended_action = "MEDIUM", "MONITOR"
        else:
            risk_class, recommended_action = "HIGH", "HALT"

    # Semantic observation — does not affect score
    semantic_obs = None
    if include_semantic_observation:
        try:
            semantic_obs = _compute_mean_semantic_drift(events)
        except Exception:
            semantic_obs = None

    primary_metrics = {
        "violation_rate":    round(VR, 4),
        "cascade_spread":    round(CS, 4),
        "propagation_depth": round(DP, 4),
        "severity":          round(SV, 4),
        "impact":            round(IM, 4),
    }

    components = {
        **primary_metrics,
        "score_raw":             round(score_raw, 4),
        "weights_used":          dict(w),
        "semantic_observation":  semantic_obs,
    }

    reasons = [
        f"VR (Violation Rate)      = {len(vio_edges)}/{total_edges} = {VR:.4f}",
        f"CS (Cascade Spread)      = {int(metrics.get('final_reach',0))}/{total_nodes} = {CS:.4f}",
        f"DP (Propagation Depth)   = {DP_raw:.1f}/{max_hop} hops = {DP:.4f}",
        f"SV (Severity)            = mean of {len(vio_edges)} violating edges = {SV:.4f}",
        f"IM (Impact)              = downstream violation ratio = {IM:.4f}",
        f"Semantic drift (obs)     = {semantic_obs if semantic_obs is not None else 'unavailable'}",
        f"score_raw                = {score_raw:.4f}",
        f"O-TPS (sigmoid scaled)   = {score:.4f} → {risk_class}",
    ]

    return OfflineTPSOutput(
        trust_risk_score=score,
        risk_class=risk_class,
        recommended_action=recommended_action,
        components=components,
        metrics=dict(metrics),
        reasons=reasons,
    )


def replay_o_tps(events: Iterable[dict]) -> OfflineTPSOutput:
    return compute_o_tps(events)
