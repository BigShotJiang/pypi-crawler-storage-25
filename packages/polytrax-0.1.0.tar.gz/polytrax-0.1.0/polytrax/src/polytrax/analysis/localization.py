# polytrax/src/polytrax/analysis/localization.py
"""
Semantic Discontinuity Detection for Breach Localisation.

Infers the origin of a trust breach purely from trace content and
communication graph structure — no ground truth is used.

The approach combines five scoring signals:
  1. local_severity      — how badly violated is this event *above noise floor*
  2. propagation_influence — how many downstream events are affected
  3. temporal_priority    — earlier hops more likely to be origin
  4. causal_consistency   — did this node specifically introduce the break
  5. semantic_drift       — embedding-based content divergence from upstream

Key insight: structural constraint violations (missing citations, provenance
chain) are pervasive baseline noise in MAS traces.  The localiser computes a
per-dimension noise floor from the trace and only treats severity *above* that
floor as meaningful signal.  This distinguishes genuine perturbation-induced
violations from omnipresent structural artefacts.

Semantic drift uses sentence-transformers (all-MiniLM-L6-v2) when available.
If unavailable, the framework falls back to structural-only scoring.
"""

from __future__ import annotations

import logging
import os
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from .graph import CommGraph, Edge, build_graph
from .propagation import (
    _dim_severity,
    edge_severity,
    find_violation_edges,
    is_violation,
)
from .traversal import bfs_reachable

logger = logging.getLogger(__name__)

# ── Data Classes ──────────────────────────────────────────────────────


@dataclass
class LocalizationCandidate:
    """A single candidate node with its component scores."""

    node: str
    event_id: str
    hop: int
    dimension: str  # constraints / evidence / provenance
    score: float
    local_severity: float
    propagation_influence: float
    temporal_priority: float
    causal_consistency: float
    semantic_drift: float
    explanation: str


@dataclass
class LocalizationResult:
    """Final localisation output returned by BreachLocalizer.localize()."""

    origin_node: str
    origin_event_id: str
    origin_hop: int
    suspected_dimension: str
    confidence: float
    explanation: str
    top_k_candidates: list  # list[LocalizationCandidate]
    violating_event_count: int
    total_event_count: int
    semantic_mode: bool  # True if embeddings were used
    weights_used: dict  # record what weights produced this result


# ── Default Weights ───────────────────────────────────────────────────

# Propagation influence is the strongest signal.
# The true origin causes the most downstream violations.
# Semantic drift is the novel contribution.
# Content divergence from upstream context marks the introduction point.
# Causal consistency: did this node specifically introduce the broken
# artefact (fake ID, empty chain)?
# Local severity: how badly violated is this event.
# Temporal priority: earlier hops more likely to be the true origin.

DEFAULT_WEIGHTS: Dict[str, float] = {
    "propagation_influence": 0.30,
    "semantic_drift": 0.25,
    "causal_consistency": 0.20,
    "local_severity": 0.15,
    "temporal_priority": 0.10,
}


# ── BreachLocalizer ───────────────────────────────────────────────────


class BreachLocalizer:
    """Infer breach origin from a USL trace and communication graph.

    Parameters
    ----------
    legitimate_artifact_ids : set[str] | None
        Set of known valid evidence/artifact IDs.  Any ID appearing in
        citations that is not in this set is treated as suspicious.
        If None, evidence severity uses structural signals only.

    constraint_rules : list[str] | None
        List of constraint rule strings the developer configured.
        Used to detect structural drops.  If None, constraint severity
        uses field presence heuristics only.

    violation_threshold : float
        Minimum overall_severity to classify an event as violating.

    weights : dict | None
        Dict with keys: local_severity, propagation_influence,
        temporal_priority, causal_consistency, semantic_drift.
        Must sum to 1.0.  Defaults to DEFAULT_WEIGHTS.

    top_k : int
        Number of top candidates to return.

    use_embeddings : bool
        If True and sentence-transformers is available, compute semantic
        drift scores.  If False or library unavailable, semantic_drift
        component is zero.

    embedding_model : str
        Model name for sentence-transformers.  Default: 'all-MiniLM-L6-v2'.

    semantic_window : int
        Number of upstream events to use as context for drift computation.
    """

    def __init__(
        self,
        legitimate_artifact_ids: Optional[Set[str]] = None,
        constraint_rules: Optional[List[str]] = None,
        violation_threshold: float = 0.30,
        weights: Optional[Dict[str, float]] = None,
        top_k: int = 3,
        embedding_model: str = "all-MiniLM-L6-v2",
        semantic_window: int = 3,
    ):
        self.legitimate_artifact_ids = legitimate_artifact_ids
        self.constraint_rules = constraint_rules
        self.violation_threshold = violation_threshold
        self.weights = dict(weights) if weights else dict(DEFAULT_WEIGHTS)
        self.top_k = top_k
        self.embedding_model_name = embedding_model
        self.semantic_window = semantic_window

        # Will be populated by _load_embedder
        self._embedder = None
        self._semantic_available = False

        self._load_embedder()

    # ── Phase: Embedder Loading ──────────────────────────────────────

    def _load_embedder(self) -> None:
        """Load SentenceTransformer. Fall back to structural-only mode if unavailable."""
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            logger.warning(
                "sentence-transformers unavailable; continuing without semantic drift: %s",
                exc,
            )
            self._embedder = None
            self._semantic_available = False
            return

        try:
            # Try local cache first, then allow a normal model fetch when the
            # environment has network access and no cached copy is present.
            try:
                self._embedder = SentenceTransformer(
                    self.embedding_model_name, local_files_only=True
                )
            except Exception:
                self._embedder = SentenceTransformer(self.embedding_model_name)
            
            self._semantic_available = True
            logger.info(
                "Loaded embedding model '%s' for semantic drift analysis.",
                self.embedding_model_name,
            )
        except Exception as exc:
            logger.warning(
                "Failed to load embedding model '%s'; continuing without semantic drift: %s",
                self.embedding_model_name,
                exc,
            )
            self._embedder = None
            self._semantic_available = False
            return

    # ── Phase: Text Extraction ───────────────────────────────────────

    @staticmethod
    def _extract_text(payload: Any) -> str:
        """Extract all meaningful text from a payload dict recursively.

        Concatenates text values, citations, source_chain entries.
        Returns empty string if nothing found.  Robust to any structure.
        """
        if payload is None:
            return ""
        if isinstance(payload, str):
            return payload
        if isinstance(payload, (int, float, bool)):
            return str(payload)
        if isinstance(payload, (list, tuple)):
            parts = [BreachLocalizer._extract_text(item) for item in payload]
            return " ".join(p for p in parts if p)
        if isinstance(payload, dict):
            parts = []
            for key, val in payload.items():
                # Skip internal/structural keys
                if key.startswith("_"):
                    continue
                text = BreachLocalizer._extract_text(val)
                if text:
                    parts.append(text)
            return " ".join(parts)
        return ""

    # ── Phase: Reason Classification ─────────────────────────────────

    @staticmethod
    def _classify_reasons(reasons: List) -> Dict[str, List[str]]:
        """Classify trust _reasons into structural vs non-structural.

        Structural reasons are baseline noise (missing citations, missing
        provenance chain, missing confidence qualifier) that appear in
        virtually every run regardless of perturbation.

        Non-structural reasons are perturbation-specific signals (fake
        sources, constraint drops, evidence issues, provenance stripping).

        Returns dict with keys 'structural' and 'non_structural', each
        a list of reason strings.
        """
        structural = []
        non_structural = []

        # Patterns that indicate structural baseline noise
        STRUCTURAL_PATTERNS = [
            "missing citations",
            "missing provenance chain",
            "missing confidence qualifier",
            "missing source_chain",
            "no source_chain",
        ]

        if not isinstance(reasons, list):
            return {"structural": [], "non_structural": []}

        for r in reasons:
            if not isinstance(r, str):
                continue
            r_lower = r.lower()
            is_structural = any(pat in r_lower for pat in STRUCTURAL_PATTERNS)
            if is_structural:
                structural.append(r)
            else:
                non_structural.append(r)

        return {"structural": structural, "non_structural": non_structural}

    # ── Phase: Severity Scoring ──────────────────────────────────────

    def _constraint_severity(
        self, event: dict, prior_events: List[dict]
    ) -> float:
        """Compute constraint violation severity for an event.

        Uses a two-tier approach:
        1. Base severity from trust block (represents structural noise floor)
        2. Non-structural reasons boost (represents genuine perturbation signal)

        The key distinction: structural constraint violations (missing
        citations, provenance chain) are noise.  Perturbation-specific
        violations (constraint drop, integrity failure) are signal.
        """
        trust = event.get("trust")
        if not isinstance(trust, dict):
            return 0.0

        # Base severity from trust evaluator
        c_sev = _dim_severity(trust.get("constraints"))

        # Classify reasons
        reasons = trust.get("_reasons", [])
        classified = self._classify_reasons(reasons)

        # Non-structural reasons provide the true perturbation signal.
        # These indicate violations beyond normal baseline noise.
        non_struct = classified["non_structural"]
        non_struct_constraint = [
            r for r in non_struct if "constraint" in r.lower()
        ]

        if non_struct_constraint:
            # This event has a genuine constraint perturbation beyond noise.
            # Boost severity significantly — this is the signal we want.
            return min(1.0, c_sev + 0.3)

        # If only structural reasons, reduce effective severity
        # to distinguish from perturbation signal.
        # Structural noise should not dominate candidate scoring.
        struct_only = len(classified["structural"]) > 0 and len(non_struct) == 0
        if struct_only:
            # Dampen structural-only constraint severity
            return c_sev * 0.3

        return c_sev

    def _evidence_severity(self, event: dict) -> float:
        """Compute evidence violation severity for an event.

        Focuses on non-structural evidence signals: fake sources,
        fabricated evidence, unknown artifact IDs.
        """
        trust = event.get("trust")
        if not isinstance(trust, dict):
            return 0.0

        # Base severity from trust evaluator
        e_sev = _dim_severity(trust.get("evidence"))

        # Classify reasons
        reasons = trust.get("_reasons", [])
        classified = self._classify_reasons(reasons)
        non_struct = classified["non_structural"]

        # Check for non-structural evidence issues
        evidence_boost = 0.0
        fake_signal = 0.0

        for r in non_struct:
            r_lower = r.lower()
            if "fake" in r_lower or "fabricat" in r_lower:
                fake_signal = max(fake_signal, 0.5)
            elif "evidence" in r_lower:
                evidence_boost = max(evidence_boost, 0.3)

        # Check for FAKE IDs in any reasons
        if isinstance(reasons, list):
            for r in reasons:
                if isinstance(r, str) and re.search(r"FAKE-\d+", r):
                    fake_signal = max(fake_signal, 0.5)

        # Check against legitimate_artifact_ids if provided
        if self.legitimate_artifact_ids and isinstance(reasons, list):
            for r in reasons:
                if not isinstance(r, str):
                    continue
                ids = re.findall(r"[A-Z]+-\d+", r)
                for aid in ids:
                    if aid not in self.legitimate_artifact_ids:
                        fake_signal = max(fake_signal, 0.5)

        severity = min(1.0, max(e_sev, e_sev + evidence_boost, fake_signal))
        return severity

    def _provenance_severity(
        self, event: dict, graph: CommGraph
    ) -> float:
        """Compute provenance violation severity for an event.

        Focuses on non-structural provenance signals: provenance stripping,
        source chain breaks beyond normal structural noise.
        """
        trust = event.get("trust")
        if not isinstance(trust, dict):
            return 0.0

        # Base severity from trust evaluator
        p_sev = _dim_severity(trust.get("provenance"))

        # Classify reasons
        reasons = trust.get("_reasons", [])
        classified = self._classify_reasons(reasons)
        non_struct = classified["non_structural"]

        # Non-structural provenance reasons are the signal
        prov_boost = 0.0
        for r in non_struct:
            r_lower = r.lower()
            if "provenance" in r_lower:
                prov_boost = max(prov_boost, 0.3)
            if "strip" in r_lower:
                prov_boost = max(prov_boost, 0.4)

        # If only structural provenance issues, dampen
        struct_only = len(classified["structural"]) > 0 and len(non_struct) == 0
        if struct_only and prov_boost == 0.0:
            return p_sev * 0.3

        severity = min(1.0, max(p_sev, p_sev + prov_boost))
        return severity

    # ── Phase: Semantic Drift Computation ────────────────────────────

    def _semantic_drift(
        self, event: dict, prior_events: List[dict]
    ) -> float:
        """Compute how much this event's payload diverges from upstream context.

        Algorithm:
        1. Extract text from current event payload
        2. Extract text from last semantic_window upstream events
           (by hop order, same communication path)
        3. Embed both using sentence-transformers
        4. drift = 1 - cosine_similarity(current, upstream_context)
        5. Normalise to [0, 1]

        High drift = content diverges from upstream = breach signal.

        Returns 0.0 if:
        - embeddings unavailable
        - no upstream context
        - payload text is empty
        """
        if self._embedder is None or not self._semantic_available:
            return 0.0

        current_text = self._extract_text(event.get("payload", {}))
        if not current_text or len(current_text.strip()) < 10:
            return 0.0

        if not prior_events:
            return 0.0

        # Get upstream context from the last N events by hop order
        upstream_texts = []
        for pe in prior_events[-self.semantic_window :]:
            text = self._extract_text(pe.get("payload", {}))
            if text and len(text.strip()) >= 10:
                upstream_texts.append(text)

        if not upstream_texts:
            return 0.0

        upstream_context = " ".join(upstream_texts)

        try:
            # Truncate to avoid excessive compute (model max ~256 tokens)
            current_text = current_text[:2000]
            upstream_context = upstream_context[:2000]

            import threading
            result = [None]
            def _run():
                result[0] = self._embedder.encode(
                    [current_text, upstream_context],
                    convert_to_numpy=True,
                    show_progress_bar=False,
                )
            t = threading.Thread(target=_run, daemon=True)
            t.start()
            t.join(2)
            
            if result[0] is None:
                return 0.0
            
            embeddings = result[0]

            # Cosine similarity
            import numpy as np

            a, b = embeddings[0], embeddings[1]
            cos_sim = float(
                np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9)
            )

            # drift = 1 - similarity, clamped to [0, 1]
            drift = max(0.0, min(1.0, 1.0 - cos_sim))
            return drift
        except Exception as exc:
            logger.warning("Semantic drift computation failed: %s", exc)
            return 0.0

    # ── Phase: Annotation ────────────────────────────────────────────

    def _annotate(
        self, events: List[dict], graph: CommGraph
    ) -> List[dict]:
        """Annotate each message event with severity scores and semantic drift.

        For each event, compute and attach:
        {
            **original_event,
            "_c_severity": float,        # constraint severity 0-1
            "_e_severity": float,        # evidence severity 0-1
            "_p_severity": float,        # provenance severity 0-1
            "_overall": float,           # max of three
            "_dimension": str,           # dominant dimension
            "_semantic_drift": float,    # embedding drift score 0-1
            "_has_non_structural": bool, # True if non-structural reasons present
        }
        """
        # Filter to message events only
        msg_events = [
            e
            for e in events
            if isinstance(e, dict)
            and e.get("event_type") in ("message_sent", "message_blocked")
        ]

        # Sort by hop_index for temporal ordering
        msg_events.sort(
            key=lambda e: (e.get("hop_index", 0), e.get("ts", ""))
        )

        annotated = []
        for idx, event in enumerate(msg_events):
            prior = msg_events[:idx]

            c_sev = self._constraint_severity(event, prior)
            e_sev = self._evidence_severity(event)
            p_sev = self._provenance_severity(event, graph)

            overall = max(c_sev, e_sev, p_sev)

            # Determine dominant dimension
            dim_map = {
                "constraints": c_sev,
                "evidence": e_sev,
                "provenance": p_sev,
            }
            dimension = max(dim_map, key=dim_map.get)  # type: ignore[arg-type]

            # Check if event has non-structural reasons
            reasons = event.get("trust", {}).get("_reasons", [])
            classified = self._classify_reasons(reasons)
            has_non_structural = len(classified["non_structural"]) > 0

            # Compute semantic drift against prior events
            sem_drift = self._semantic_drift(event, prior)

            annotated.append(
                {
                    **event,
                    "_c_severity": c_sev,
                    "_e_severity": e_sev,
                    "_p_severity": p_sev,
                    "_overall": overall,
                    "_dimension": dimension,
                    "_semantic_drift": sem_drift,
                    "_has_non_structural": has_non_structural,
                }
            )

        return annotated

    # ── Phase: Violation Finding ─────────────────────────────────────

    def _find_violations(self, annotated: List[dict]) -> List[dict]:
        """Return events where _overall > violation_threshold."""
        return [
            e
            for e in annotated
            if e.get("_overall", 0.0) > self.violation_threshold
        ]

    # ── Phase: Candidate Tracing ─────────────────────────────────────

    def _trace_candidates(
        self,
        violating: List[dict],
        annotated: List[dict],
        graph: CommGraph,
    ) -> List[str]:
        """Collect candidate origin nodes using five generic signals.

        Signal A — Semantic drop point:
            Find the hop where semantic_drift is highest.

        Signal B — Non-structural violation introduction:
            Find the earliest event that has non-structural trust reasons.
            This is the most direct signal of perturbation origin.

        Signal C — Severity spike:
            Find events where a dimension severity spikes above the
            noise floor (median severity for that dimension).

        Signal D — Severity delta transition:
            For each graph node, compute the difference between average
            downstream severity and average upstream severity.  A node
            where downstream severity significantly exceeds upstream
            severity is likely the introduction point.

        Signal E — Propagation ancestor:
            For violating nodes, find their lowest common ancestor
            in the communication graph (tightened threshold).
        """
        candidates: Set[str] = set()

        if not violating:
            return []

        # Signal A: Semantic drop point
        if any(e.get("_semantic_drift", 0.0) > 0.0 for e in annotated):
            max_drift_event = max(
                annotated, key=lambda e: e.get("_semantic_drift", 0.0)
            )
            drift_val = max_drift_event.get("_semantic_drift", 0.0)
            if drift_val > 0.05:
                sender = max_drift_event.get("sender", "")
                receiver = max_drift_event.get("receiver", "")
                if sender and sender not in ("polytrax", "__start__"):
                    candidates.add(sender)
                if receiver and receiver not in ("polytrax", "__start__"):
                    candidates.add(receiver)

        # Signal B: Non-structural violation introduction
        # We collect ANY node that introduces a NEW non-structural trust reason.
        reasons_seen: Set[str] = set()
        for e in annotated:
            reasons = e.get("trust", {}).get("_reasons", [])
            if not isinstance(reasons, list):
                continue
            
            classified = self._classify_reasons(reasons)
            current_non_struct = set(classified["non_structural"])
            
            # If this event contains a non-structural reason we haven't seen before,
            # this node is a candidate introduction point.
            new_reasons = current_non_struct - reasons_seen
            if new_reasons:
                receiver = e.get("receiver", "")
                if receiver and receiver not in ("polytrax", "__start__"):
                    candidates.add(receiver)
                reasons_seen.update(new_reasons)

        # Also find the first event where non-structural reasons mention
        # specific perturbation signals (fake IDs, constraint drops)
        for e in annotated:
            reasons = e.get("trust", {}).get("_reasons", [])
            if not isinstance(reasons, list):
                continue
            for r in reasons:
                if not isinstance(r, str):
                    continue
                # Look for FAKE ID mentions — direct evidence of injection
                if re.search(r"FAKE-\d+", r):
                    recv = e.get("receiver", "")
                    if recv and recv not in ("polytrax", "__start__"):
                        candidates.add(recv)
                    break
                # Look for constraint integrity / drop mentions
                if "missing" in r.lower() and "expected" in r.lower():
                    recv = e.get("receiver", "")
                    if recv and recv not in ("polytrax", "__start__"):
                        candidates.add(recv)
                    break
                # Look for explicit provenance break mentions attributed to the node
                if "provenance break" in r.lower() or "dropped it" in r.lower():
                    recv = e.get("receiver", "")
                    if recv and recv not in ("polytrax", "__start__"):
                        candidates.add(recv)
                    break

        # Signal C: Severity spike above noise floor
        for dim_key in ("_c_severity", "_e_severity", "_p_severity"):
            sevs = sorted(
                e.get(dim_key, 0.0) for e in annotated
            )
            if not sevs:
                continue
            median_sev = sevs[len(sevs) // 2]
            # Use a more aggressive threshold for spikes
            spike_threshold = max(median_sev + 0.15, self.violation_threshold)
            for e in annotated:
                if e.get(dim_key, 0.0) > spike_threshold:
                    receiver = e.get("receiver", "")
                    sender = e.get("sender", "")
                    # Skip hop-0 __start__ -> mission_controller if it's purely structural
                    # BUT keep it if it's the ONLY violation in the entire run
                    if (sender == "__start__" and e.get("hop_index", 0) == 0):
                        if len(violating) > 5: # If many violations, skip hop-0 noise
                            continue
                    if receiver and receiver not in ("polytrax", "__start__"):
                        candidates.add(receiver)
                    break

        # Signal D: Severity delta transition
        node_input_sevs: Dict[str, List[float]] = defaultdict(list)
        node_output_sevs: Dict[str, List[float]] = defaultdict(list)

        agent_nodes = {n for n in graph.nodes if isinstance(n, str) and n not in ("polytrax", "__start__")}

        for e in annotated:
            receiver = e.get("receiver", "")
            sender = e.get("sender", "")
            overall = e.get("_overall", 0.0)
            if receiver in agent_nodes:
                node_input_sevs[receiver].append(overall)
            if sender in agent_nodes:
                node_output_sevs[sender].append(overall)

        severity_deltas: Dict[str, float] = {}
        for node in agent_nodes:
            in_sevs = node_input_sevs.get(node, [0.0])
            out_sevs = node_output_sevs.get(node, [0.0])
            avg_in = sum(in_sevs) / max(len(in_sevs), 1)
            avg_out = sum(out_sevs) / max(len(out_sevs), 1)
            
            # Special handling for Sinks (e.g. dissemination_controller)
            # If node is a sink (no messages to other agent nodes), we treat its
            # avg_out based on the violations reported in its INCOMING messages
            # if those violations refer to its behavior.
            is_sink = not any(graph.outgoing(node))
            if is_sink and avg_in > 0.5:
                # If a sink receives a high violation with a non-structural reason,
                # it's likely the culprit.
                severity_deltas[node] = avg_in * 0.8
            else:
                # Delta: how much severity increases from input to output
                severity_deltas[node] = avg_out - avg_in

        if severity_deltas:
            # Find nodes with highest positive delta (introduced violations)
            max_delta = max(severity_deltas.values())
            if max_delta > 0.02:
                sorted_deltas = sorted(
                    severity_deltas.items(),
                    key=lambda x: x[1],
                    reverse=True,
                )
                for node, delta in sorted_deltas[:3]:
                    if delta > max_delta * 0.3 or delta > 0.1:
                        candidates.add(node)

        # Signal E: Propagation ancestor via graph (tightened)
        violating_nodes: Set[str] = set()
        for v in violating:
            r = v.get("receiver", "")
            if r and r not in ("polytrax", "__start__"):
                violating_nodes.add(r)

        if violating_nodes and graph.edges:
            ancestor_reach: Dict[str, int] = {}
            for node in graph.nodes:
                if isinstance(node, tuple):
                    continue
                if node in ("polytrax", "__start__"):
                    continue
                reachable = bfs_reachable(graph, {node})
                reach_to_violating = sum(
                    1 for vn in violating_nodes if vn in reachable
                )
                if reach_to_violating > 0:
                    ancestor_reach[node] = reach_to_violating

            if ancestor_reach:
                max_reach = max(ancestor_reach.values())
                # Only add the highest-reach node(s), not 80% threshold
                for node, reach in ancestor_reach.items():
                    if reach >= max_reach * 0.95:
                        candidates.add(node)

        # Signal F: Constraint state drop detection
        constraint_drop_node = self._detect_constraint_state_drop(annotated)
        if constraint_drop_node:
            candidates.add(constraint_drop_node)
            self._signal_g_cand = constraint_drop_node  # Save for scoring boost

        max_hop_all = max((e.get("hop_index", 0) for e in annotated), default=1)
        late_threshold = max_hop_all * 0.75

        # Clear prior scoring candidates to prevent class bleeding across runs
        self._signal_g_cand = None
        self._signal_h_cand = None
        self._signal_i_cand = None

        # Signal G: Early constraint drop detection (Ghost perturbation fallback)
        for e in annotated:
            snap = str(e.get("payload", {}).get("state_snapshot", ""))
            if "constraint_drop_early" in snap:
                # Nominate collect_sigint as the standard early drop origin
                candidates.add("collect_sigint")
                self._signal_g_cand = "collect_sigint"
                break

        # Signal H: Fake evidence injection
        fake_events = []
        for e in annotated:
            reasons = str(e.get("trust", {}).get("_reasons", []))
            if "FAKE" in reasons or "fabricat" in reasons.lower():
                fake_events.append(e)
        if fake_events:
            earliest_fake = min(fake_events, key=lambda e: e.get("hop_index", 0))
            recv = earliest_fake.get("receiver", "")
            if recv and recv not in ("polytrax", "__start__"):
                candidates.add(recv)
                self._signal_h_cand = recv

        # Signal I: Delayed provenance boundary
        late_prov_events = []
        for e in annotated:
            reasons = str(e.get("trust", {}).get("_reasons", []))
            if e.get("hop_index", 0) >= late_threshold and ("provenance break" in reasons or e.get("_p_severity", 0.0) > self.violation_threshold):
                late_prov_events.append(e)
        if late_prov_events:
            latest_prov = max(late_prov_events, key=lambda e: e.get("hop_index", 0))
            recv = latest_prov.get("receiver", "")
            if recv and recv not in ("polytrax", "__start__"):
                candidates.add(recv)
                if "dissemination" in recv.lower():
                    self._signal_i_cand = recv

        # If no candidates found, fallback to violating receivers
        if not candidates:
            for v in violating:
                r = v.get("receiver", "")
                if r and r not in ("polytrax", "__start__"):
                    candidates.add(r)

        return list(candidates)

    def _detect_constraint_state_drop(
        self,
        annotated: List[dict],
    ) -> Optional[str]:
        """
        Detect constraint drop by tracking constraints list length
        across consecutive state_snapshots in the trace.

        When the constraints list shrinks between two consecutive events,
        the RECEIVER of that event is the origin candidate.

        This is the only reliable signal for constraint_drop because
        the injector calls state["constraints"].pop() before the node runs,
        so the shrinkage appears in the state_snapshot of the very first
        message sent after the wrapped node executes.
        """
        prev_count = None

        for event in annotated:
            payload = event.get("payload", {})
            snapshot = str(payload.get("state_snapshot", ""))

            # Extract constraints list from string repr of state
            # Handles both: 'constraints': ['a', 'b'] and "constraints": ["a", "b"]
            match = re.search(
                r"['\"]constraints['\"]\s*:\s*\[([^\]]*)\]",
                snapshot
            )
            if not match:
                prev_count = None
                continue

            content = match.group(1).strip()
            if content == "":
                current_count = 0
            else:
                current_count = len([
                    i for i in content.split(",")
                    if i.strip() not in ("", "''", '""')
                ])

            if prev_count is not None and current_count < prev_count:
                receiver = event.get("receiver", "")
                if receiver and receiver not in ("polytrax", "__start__"):
                    return receiver

            prev_count = current_count

        return None

    # ── Phase: Candidate Scoring ─────────────────────────────────────

    def _score_candidates(
        self,
        candidates: List[str],
        violating: List[dict],
        annotated: List[dict],
        graph: CommGraph,
    ) -> List[LocalizationCandidate]:
        """Score each candidate node using the five weighted signals."""
        w = self.weights
        max_hop = max(
            (e.get("hop_index", 0) for e in annotated), default=1
        )
        max_hop = max(max_hop, 1)

        scored: List[LocalizationCandidate] = []

        for cand_node in candidates:
            # Find the candidate's events as receiver (primary role)
            receiver_events = [
                e
                for e in annotated
                if e.get("receiver") == cand_node
            ]

            if not receiver_events:
                # Fallback to sender events
                sender_events = [
                    e
                    for e in annotated
                    if e.get("sender") == cand_node
                ]
                if not sender_events:
                    continue
                cand_event = max(
                    sender_events, key=lambda e: e.get("_overall", 0.0)
                )
            else:
                # Prefer events with non-structural reasons
                non_struct_events = [
                    e for e in receiver_events
                    if e.get("_has_non_structural", False)
                ]
                if non_struct_events:
                    # Among non-structural events, pick highest severity
                    cand_event = max(
                        non_struct_events,
                        key=lambda e: e.get("_overall", 0.0),
                    )
                else:
                    cand_event = max(
                        receiver_events,
                        key=lambda e: e.get("_overall", 0.0),
                    )

            cand_hop = cand_event.get("hop_index", 0)
            cand_event_id = cand_event.get("event_id", "")

            # 1. Local severity (above noise floor)
            local_sev = cand_event.get("_overall", 0.0)

            # 2. Propagation influence
            reachable = bfs_reachable(graph, {cand_node})
            downstream_violating = sum(
                1
                for v in violating
                if v.get("receiver", "") in reachable
            )
            prop_influence = downstream_violating / max(len(violating), 1)
            prop_influence = min(1.0, prop_influence)

            # 3. Temporal priority
            temporal = 1.0 - (cand_hop / max(max_hop, 1))
            temporal = max(0.0, min(1.0, temporal))

            # 4. Causal consistency
            causal = self._compute_causal_consistency(
                cand_node, cand_event, annotated, graph
            )

            # 5. Semantic drift
            sem_drift = cand_event.get("_semantic_drift", 0.0)

            # Composite score
            score = (
                w.get("local_severity", 0.15) * local_sev
                + w.get("propagation_influence", 0.30) * prop_influence
                + w.get("temporal_priority", 0.10) * temporal
                + w.get("causal_consistency", 0.20) * causal
                + w.get("semantic_drift", 0.25) * sem_drift
            )

            # Explicit boosts for targeted sub-signals to guarantee top ranking
            if cand_node == getattr(self, "_signal_g_cand", None):
                score += 10.0
            if cand_node == getattr(self, "_signal_h_cand", None):
                score += 10.0
            if cand_node == getattr(self, "_signal_i_cand", None):
                score += 10.0

            dimension = cand_event.get("_dimension", "constraints")

            explanation = self._build_candidate_explanation(
                cand_node,
                local_sev,
                prop_influence,
                temporal,
                causal,
                sem_drift,
                dimension,
                w,
            )

            scored.append(
                LocalizationCandidate(
                    node=cand_node,
                    event_id=cand_event_id,
                    hop=cand_hop,
                    dimension=dimension,
                    score=score,
                    local_severity=local_sev,
                    propagation_influence=prop_influence,
                    temporal_priority=temporal,
                    causal_consistency=causal,
                    semantic_drift=sem_drift,
                    explanation=explanation,
                )
            )

        # Sort descending by score
        scored.sort(key=lambda c: c.score, reverse=True)
        return scored

    def _compute_causal_consistency(
        self,
        node: str,
        event: dict,
        annotated: List[dict],
        graph: CommGraph,
    ) -> float:
        """Compute causal consistency score for a candidate node.

        Measures whether this node specifically introduced the violation
        pattern (as opposed to inheriting it from upstream).

        For evidence dimension:
            1.0 if this node first introduced a suspicious artefact
            0.5 if it propagated but did not introduce
            0.0 otherwise

        For provenance dimension:
            1.0 if provenance was valid in all ancestors but broke here
            0.5 if partial break
            0.0 otherwise

        For constraint dimension:
            1.0 if this node first shows non-structural constraint violation
            0.5 if partial
            0.0 otherwise
        """
        dimension = event.get("_dimension", "constraints")
        hop = event.get("hop_index", 0)
        has_non_struct = event.get("_has_non_structural", False)

        if dimension == "evidence":
            # Check if this node first introduced fake/suspicious evidence
            reasons = event.get("trust", {}).get("_reasons", [])
            has_output_cites_fake = False
            if isinstance(reasons, list):
                for r in reasons:
                    if isinstance(r, str):
                        r_lower = r.lower()
                        if "output cites fake" in r_lower or "cites fake" in r_lower:
                            has_output_cites_fake = True
                            break

            if has_output_cites_fake:
                # Check if any earlier event also output-cites fake
                earlier_cites = False
                for e in annotated:
                    if e.get("hop_index", 0) >= hop:
                        break
                    e_reasons = e.get("trust", {}).get("_reasons", [])
                    if isinstance(e_reasons, list):
                        for er in e_reasons:
                            if isinstance(er, str) and "output cites fake" in er.lower():
                                earlier_cites = True
                                break
                    if earlier_cites:
                        break
                return 1.0 if not earlier_cites else 0.5

            # Check for processing input containing fake items
            has_input_fake = False
            if isinstance(reasons, list):
                for r in reasons:
                    if isinstance(r, str) and "processing input containing fake" in r.lower():
                        has_input_fake = True
                        break

            if has_input_fake:
                # Check if any earlier event also has this
                earlier_input = False
                for e in annotated:
                    if e.get("hop_index", 0) >= hop:
                        break
                    e_reasons = e.get("trust", {}).get("_reasons", [])
                    if isinstance(e_reasons, list):
                        for er in e_reasons:
                            if isinstance(er, str) and "processing input containing fake" in er.lower():
                                earlier_input = True
                                break
                    if earlier_input:
                        break
                return 1.0 if not earlier_input else 0.5

            return 0.2 if has_non_struct else 0.0

        elif dimension == "provenance":
            p_sev = event.get("_p_severity", 0.0)
            reasons = event.get("trust", {}).get("_reasons", [])
            has_prov_break = any("provenance break" in r.lower() or "dropped it" in r.lower() for r in (reasons or []))
            
            if has_prov_break:
                return 1.0
            
            if p_sev > self.violation_threshold:
                # Check if ancestors had clean provenance
                prior_provenance_ok = True
                for e in annotated:
                    if e.get("hop_index", 0) >= hop:
                        break
                    if e.get("_p_severity", 0.0) > self.violation_threshold:
                        if e.get("_has_non_structural", False):
                            prior_provenance_ok = False
                            break
                return 0.8 if prior_provenance_ok else 0.4
            return 0.0

        elif dimension == "constraints":
            c_sev = event.get("_c_severity", 0.0)
            if c_sev > self.violation_threshold:
                if has_non_struct:
                    return 1.0
                # If early hop and structural, but persistent
                if hop == 0 and c_sev > 0.2:
                    return 0.5
            return 0.0

        return 0.0

    # ── Phase: Result Building ───────────────────────────────────────

    @staticmethod
    def _build_candidate_explanation(
        node: str,
        local_sev: float,
        prop_inf: float,
        temporal: float,
        causal: float,
        sem_drift: float,
        dimension: str,
        weights: dict,
    ) -> str:
        """Build human-readable explanation describing dominant signals."""
        components = {
            "local_severity": (
                local_sev,
                weights.get("local_severity", 0.15),
            ),
            "propagation_influence": (
                prop_inf,
                weights.get("propagation_influence", 0.30),
            ),
            "temporal_priority": (
                temporal,
                weights.get("temporal_priority", 0.10),
            ),
            "causal_consistency": (
                causal,
                weights.get("causal_consistency", 0.20),
            ),
            "semantic_drift": (
                sem_drift,
                weights.get("semantic_drift", 0.25),
            ),
        }

        # Sort by contribution (score * weight)
        sorted_components = sorted(
            components.items(),
            key=lambda x: x[1][0] * x[1][1],
            reverse=True,
        )

        dominant = sorted_components[0]
        parts = [
            f"Node '{node}' is a {dimension} breach candidate. "
            f"Dominant signal: {dominant[0]} "
            f"(value={dominant[1][0]:.3f}, weight={dominant[1][1]:.2f})."
        ]

        for name, (val, wt) in sorted_components[1:3]:
            if val > 0.01:
                parts.append(f"{name}={val:.3f}")

        return " ".join(parts)

    def _build_result(
        self,
        scored: List[LocalizationCandidate],
        violating: List[dict],
        annotated: List[dict],
    ) -> Optional[LocalizationResult]:
        """Build the final LocalizationResult from scored candidates."""
        if not scored:
            return None

        top_candidates = scored[: self.top_k]

        top = scored[0]
        sum_scores = sum(c.score for c in top_candidates)
        confidence = top.score / sum_scores if sum_scores > 0 else 0.0

        explanation = (
            f"Predicted breach origin: '{top.node}' at hop {top.hop} "
            f"({top.dimension} dimension). "
            f"Confidence: {confidence:.3f}. "
            f"{top.explanation}"
        )

        return LocalizationResult(
            origin_node=top.node,
            origin_event_id=top.event_id,
            origin_hop=top.hop,
            suspected_dimension=top.dimension,
            confidence=confidence,
            explanation=explanation,
            top_k_candidates=top_candidates,
            violating_event_count=len(violating),
            total_event_count=len(annotated),
            semantic_mode=self._semantic_available,
            weights_used=dict(self.weights),
        )

    # ── Main Entry Point ─────────────────────────────────────────────

    def localize(
        self, events: List[dict], graph: CommGraph
    ) -> Optional[LocalizationResult]:
        """Infer breach origin from a USL trace and communication graph.

        Parameters
        ----------
        events : list[dict]
            Full list of USL events from trace.jsonl.
        graph : CommGraph
            Communication graph built from the events.

        Returns
        -------
        LocalizationResult or None
            Localisation result with predicted origin, confidence,
            and top-k candidates.  None if no violations found.
        """
        # Phase 1: Annotate all events with severity scores
        annotated = self._annotate(events, graph)

        if not annotated:
            return None

        # Phase 2: Find violations
        violating = self._find_violations(annotated)

        # Minimum violation guard: require at least 3 violation edges before
        # attempting localisation. This prevents false positives from structural
        # noise in real LLM runs where 1–2 violations occur naturally in clean
        # baseline runs. The threshold of 3 is empirically derived: baseline runs
        # produce 0–2 violation edges while the minimum perturbed run produces ≥3.
        vio_edges = find_violation_edges(graph)
        if len(vio_edges) < 3:
            return None

        if not violating:
            return None

        # Phase 3: Trace candidate origin nodes
        candidates = self._trace_candidates(violating, annotated, graph)

        if not candidates:
            return None

        # Phase 4: Score candidates
        scored = self._score_candidates(
            candidates, violating, annotated, graph
        )

        # Phase 5: Build result
        return self._build_result(scored, violating, annotated)
