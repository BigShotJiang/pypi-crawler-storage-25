# polytrax/src/polytrax/trust/__init__.py
"""
polytrax.trust — policy-based trust evaluation for MAS communication.

Provides:
- ``TrustEvaluator``: registry of composable trust policies that produce
  USL-compatible trust annotations at the communication level.
- ``TrustResult``: per-dimension severity scores from a single policy.
- Default structural policies (provenance, evidence, constraint checks).
"""

from .evaluator import TrustEvaluator, TrustResult
from .policies import provenance_policy, evidence_policy, constraint_policy

__all__ = [
    "TrustEvaluator",
    "TrustResult",
    "provenance_policy",
    "evidence_policy",
    "constraint_policy",
]
