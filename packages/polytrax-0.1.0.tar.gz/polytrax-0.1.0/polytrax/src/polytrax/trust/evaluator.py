# polytrax/src/polytrax/trust/evaluator.py
"""
Policy-based trust evaluator for inter-agent communication.

The ``TrustEvaluator`` inspects message payloads at the communication level
and produces USL-compatible trust annotations using a registry of composable
policy functions.  Each policy checks one dimension of trust (provenance
integrity, evidence quality, constraint compliance) and returns a
``TrustResult`` with per-dimension severity scores.

Aggregation rule
~~~~~~~~~~~~~~~~
When multiple policies are registered, the evaluator takes the **maximum**
severity per dimension across all policies.  A single failing policy is
sufficient to flag that trust dimension.  This is the most conservative
(and auditable) aggregation strategy.

Context contract
~~~~~~~~~~~~~~~~
The ``context`` dict is shared across all policy evaluations within a run.
Standard keys (set by the caller or adapter):

- ``"evidence_blocklist"`` : ``set[str]``
    Known-bad source IDs to flag in evidence checks.
- ``"constraints"`` : ``list[str]``
    Operational constraints declared for the run.
- ``"run_id"`` : ``str``
    Current run identifier.
- ``"hop_index"`` : ``int``
    Current hop index in the trace.
- ``"node_name"`` : ``str``
    Name of the receiving node being evaluated.

Callers may add domain-specific keys as needed.

Example
-------
::

    evaluator = TrustEvaluator()
    evaluator.register("provenance", my_provenance_policy)

    trust = evaluator.evaluate(
        sender="analyst_a",
        receiver="fusion_1",
        node_input=state,
        node_output=result,
    )
    # trust = {"constraints": {"severity": 0.0}, ...}
    # or None if all severities are 0.0
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass(frozen=True)
class TrustResult:
    """Result from a single trust policy evaluation.

    All severity values are clamped to ``[0.0, 1.0]``.
    A value of ``0.0`` means "no issue detected" for that dimension.

    Parameters
    ----------
    constraints_severity :
        Severity of constraint violations (0.0 = compliant).
    evidence_severity :
        Severity of evidence integrity issues (0.0 = clean).
    provenance_severity :
        Severity of provenance breaks (0.0 = intact).
    reasons :
        Human-readable explanations of why this severity was assigned.
        Used for audit trails and debugging — not written to the trace
        unless explicitly requested.
    """

    constraints_severity: float = 0.0
    evidence_severity: float = 0.0
    provenance_severity: float = 0.0
    reasons: tuple = ()  # tuple for frozen compatibility

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "constraints_severity",
            max(0.0, min(1.0, float(self.constraints_severity))),
        )
        object.__setattr__(
            self, "evidence_severity",
            max(0.0, min(1.0, float(self.evidence_severity))),
        )
        object.__setattr__(
            self, "provenance_severity",
            max(0.0, min(1.0, float(self.provenance_severity))),
        )
        # Normalise reasons to tuple
        if not isinstance(self.reasons, tuple):
            object.__setattr__(self, "reasons", tuple(self.reasons))

    @property
    def has_violation(self) -> bool:
        """True if any severity dimension is > 0."""
        return (
            self.constraints_severity > 0
            or self.evidence_severity > 0
            or self.provenance_severity > 0
        )


# Policy function signature type alias.
PolicyFn = Callable[
    [str, str, Any, Any, Dict[str, Any]],
    TrustResult,
]


def _severity_to_status(severity: float) -> str:
    """Map a severity float to a human-readable status string."""
    if severity <= 0.0:
        return "ok"
    if severity < 0.7:
        return "warn"
    return "fail"


class TrustEvaluator:
    """Policy-based trust evaluator for inter-agent messages.

    Register one or more policy functions, then call ``evaluate()`` on each
    inter-agent message.  The evaluator runs all policies and aggregates
    results using **max severity per dimension** (most conservative strategy).

    Parameters
    ----------
    context :
        Optional shared context dict passed to every policy function.
        See module docstring for standard key contract.
    """

    def __init__(self, *, context: Optional[Dict[str, Any]] = None) -> None:
        self._policies: Dict[str, PolicyFn] = {}
        self._context: Dict[str, Any] = context or {}

    @property
    def context(self) -> Dict[str, Any]:
        """Mutable context dict shared across evaluations."""
        return self._context

    def register(self, name: str, policy_fn: PolicyFn) -> None:
        """Register a named trust policy function.

        Parameters
        ----------
        name :
            Unique name for this policy (used for audit/debugging).
        policy_fn :
            Callable:
            ``(sender, receiver, node_input, node_output, context) -> TrustResult``

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._policies:
            raise ValueError(f"Policy '{name}' is already registered")
        if not callable(policy_fn):
            raise TypeError(f"policy_fn must be callable, got {type(policy_fn)}")
        self._policies[name] = policy_fn

    def evaluate(
        self,
        sender: str,
        receiver: str,
        node_input: Any,
        node_output: Any,
    ) -> Optional[Dict[str, Any]]:
        """Run all registered policies and produce a trust annotation.

        Aggregation: **max severity per dimension** across all policies.

        Parameters
        ----------
        sender / receiver :
            Names of the sending and receiving nodes.
        node_input :
            The state/input the node received.
        node_output :
            The result/output the node produced (may be an error stub).

        Returns
        -------
        dict or None
            USL-compatible trust block, or ``None`` if all clean.
        """
        if not self._policies:
            return None

        results: List[TrustResult] = []
        all_reasons: List[str] = []

        for policy_name, policy_fn in sorted(self._policies.items()):
            try:
                result = policy_fn(
                    sender, receiver, node_input, node_output, self._context,
                )
                if isinstance(result, TrustResult):
                    results.append(result)
                    for r in result.reasons:
                        all_reasons.append(f"[{policy_name}] {r}")
            except Exception:
                # Policy errors must not crash the pipeline.
                pass

        if not results:
            return None

        # Aggregation: max per dimension (most conservative).
        max_c = max(r.constraints_severity for r in results)
        max_e = max(r.evidence_severity for r in results)
        max_p = max(r.provenance_severity for r in results)

        if max_c <= 0.0 and max_e <= 0.0 and max_p <= 0.0:
            return None

        trust: Dict[str, Any] = {
            "constraints": {
                "severity": round(max_c, 4),
                "status": _severity_to_status(max_c),
            },
            "evidence": {
                "severity": round(max_e, 4),
                "status": _severity_to_status(max_e),
            },
            "provenance": {
                "severity": round(max_p, 4),
                "status": _severity_to_status(max_p),
            },
        }

        if all_reasons:
            trust["_reasons"] = all_reasons

        return trust
