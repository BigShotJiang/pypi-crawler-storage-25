# polytrax/src/polytrax/trust/policies.py
"""
Default structural trust policies shipped with PolyTrax.

These policies check communication-level trust properties that are
domain-agnostic.  They operate on the node's input/output dicts and
use the evaluator's shared context for configuration.

Policy contract
~~~~~~~~~~~~~~~
Every policy follows the signature::

    (sender, receiver, node_input, node_output, context) -> TrustResult

- ``node_input``: the state dict the node received
- ``node_output``: the dict the node returned (or error stub)
- ``context``: shared config dict (see evaluator module for key contract)

Citation semantics
~~~~~~~~~~~~~~~~~~
A "citation" is a string source ID appearing in the node output's
``citations`` list or ``source_chain`` list.  These are explicit,
structured references — free-text mentions are not checked.
"""

from __future__ import annotations

from typing import Any, Dict, List, Set

from .evaluator import TrustResult

# Keys in node_output that indicate substantive communication
_SUBSTANTIVE_KEYS = frozenset({
    "intel_reports", "analyses", "fused_assessments",
    "consolidated_assessment", "final_briefing",
})


def _extract_citations(output: dict) -> List[str]:
    """Extract all explicit citation IDs from a node output dict.

    Looks in: output["citations"], output["source_chain"],
    and nested dicts under container keys.
    """
    cited: List[str] = []

    # Direct fields
    for key in ("citations", "source_chain"):
        val = output.get(key, [])
        if isinstance(val, list):
            cited.extend(str(c) for c in val)

    # Nested container dicts (intel_reports, analyses, fused_assessments)
    for container_key in ("intel_reports", "analyses", "fused_assessments"):
        container = output.get(container_key, {})
        if isinstance(container, dict):
            for _k, v in container.items():
                if isinstance(v, dict):
                    for key in ("citations", "source_chain"):
                        nested = v.get(key, [])
                        if isinstance(nested, list):
                            cited.extend(str(c) for c in nested)

    return cited


def provenance_policy(
    sender: str,
    receiver: str,
    node_input: Any,
    node_output: Any,
    context: Dict[str, Any],
) -> TrustResult:
    """Check provenance chain integrity at the communication edge.

    Flags when a node produces substantive output without a source chain
    while its inputs had provenance.  This indicates a provenance break:
    information forwarded without attribution.

    Severity scale:
    - 0.0: source_chain present and non-empty, or node has no provenance-relevant output
    - 0.5: no source_chain in output and input also had none (weak provenance)
    - 0.8: input had source_chain but output dropped it (provenance break)
    """
    if not isinstance(node_output, dict):
        return TrustResult()

    # Only check nodes that produce provenance-relevant output
    has_provenance_output = any(k in node_output for k in _SUBSTANTIVE_KEYS)
    if not has_provenance_output and "source_chain" not in node_output:
        return TrustResult()

    # Check output source chain
    output_citations = _extract_citations(node_output)
    if output_citations:
        return TrustResult()  # Provenance intact

    # Check if input state had existing provenance
    if isinstance(node_input, dict):
        existing = node_input.get("analyses", {})
        if isinstance(existing, dict):
            for analysis in existing.values():
                if isinstance(analysis, dict) and analysis.get("source_chain"):
                    return TrustResult(
                        provenance_severity=0.8,
                        reasons=(
                            f"{receiver}: input has provenance chain but "
                            f"output dropped it (provenance break)",
                        ),
                    )

    return TrustResult(
        provenance_severity=0.5,
        reasons=(f"{receiver}: output has no source_chain (weak provenance)",),
    )


def evidence_policy(
    sender: str,
    receiver: str,
    node_input: Any,
    node_output: Any,
    context: Dict[str, Any],
) -> TrustResult:
    """Check evidence integrity against a known-bad source blocklist.

    Examines explicit citation IDs in the node output (``citations``
    and ``source_chain`` fields) for matches against the blocklist
    provided in ``context["evidence_blocklist"]``.

    Severity scale:
    - 0.0: no blocklisted sources cited
    - 0.3: some blocklisted sources (minority)
    - 0.6–0.9: proportional to blocklisted fraction
    - 1.0: all cited sources are blocklisted
    """
    blocklist: Set[str] = set(context.get("evidence_blocklist", []))
    if not blocklist or not isinstance(node_output, dict):
        return TrustResult()

    cited = _extract_citations(node_output)
    if not cited:
        return TrustResult()

    bad = [src for src in cited if src in blocklist]
    if not bad:
        return TrustResult()

    ratio = len(bad) / len(cited)
    severity = max(0.3, min(1.0, ratio * 1.2))

    return TrustResult(
        evidence_severity=severity,
        reasons=(
            f"{receiver}: {len(bad)}/{len(cited)} citations are blocklisted "
            f"({', '.join(bad[:5])})",
        ),
    )


def constraint_policy(
    sender: str,
    receiver: str,
    node_input: Any,
    node_output: Any,
    context: Dict[str, Any],
) -> TrustResult:
    """Check operational constraint compliance.

    Verifies that the node's output respects declared constraints from
    the input state.  Checks structural properties based on canonical
    constraint patterns:

    - ``"cite"`` / ``"source"``: output must contain citations
    - ``"provenance"``: output must have a source chain
    - ``"confidence"``: output must include confidence qualifiers

    Severity scale:
    - 0.0: all checkable constraints satisfied
    - 0.5: one constraint violated
    - 0.7–1.0: multiple constraints violated (proportional)
    """
    if not isinstance(node_input, dict) or not isinstance(node_output, dict):
        return TrustResult()

    constraints = node_input.get("constraints", [])
    if not isinstance(constraints, list) or not constraints:
        return TrustResult()

    # Only check nodes with substantive output
    if not any(k in node_output for k in _SUBSTANTIVE_KEYS):
        return TrustResult()

    citations = _extract_citations(node_output)
    violations: List[str] = []
    checks = 0

    for constraint in constraints:
        if not isinstance(constraint, str):
            continue
        c_lower = constraint.lower()

        if "cite" in c_lower or "source" in c_lower:
            checks += 1
            if not citations:
                violations.append("missing citations (constraint: cite sources)")

        if "provenance" in c_lower:
            checks += 1
            # Look for source_chain in top level OR nested substantive containers
            found_prov = False
            for v in node_output.values():
                if isinstance(v, dict) and v.get("source_chain"):
                    found_prov = True
                    break
                # Sub-nesting (e.g. fused_assessments['fusion_2'])
                if isinstance(v, dict):
                    for sv in v.values():
                        if isinstance(sv, dict) and sv.get("source_chain"):
                            found_prov = True
                            break
                if found_prov: break
            if not found_prov:
                violations.append("missing provenance chain")

        if "confidence" in c_lower:
            checks += 1
            # Check for confidence in output values (direct or nested)
            has_confidence = False
            for v in node_output.values():
                if isinstance(v, dict) and ("confidence" in v or "confidence_level" in v):
                    has_confidence = True
                    break
                if isinstance(v, dict):
                    for sv in v.values():
                        if isinstance(sv, dict) and ("confidence" in sv or "confidence_level" in sv):
                            has_confidence = True
                            break
                        if isinstance(sv, str) and any(
                            q in sv.lower() for q in ("high confidence", "moderate confidence", "low confidence")
                        ):
                            has_confidence = True
                            break
                if isinstance(v, str) and any(
                    q in v.lower() for q in ("high confidence", "moderate confidence", "low confidence")
                ):
                    has_confidence = True
                    break
                if has_confidence: break
            if not has_confidence:
                violations.append("missing confidence qualifier")

    if checks == 0 or not violations:
        return TrustResult()

    ratio = len(violations) / checks
    severity = max(0.5, min(1.0, ratio))

    return TrustResult(
        constraints_severity=severity,
        reasons=tuple(f"{receiver}: {v}" for v in violations),
    )
