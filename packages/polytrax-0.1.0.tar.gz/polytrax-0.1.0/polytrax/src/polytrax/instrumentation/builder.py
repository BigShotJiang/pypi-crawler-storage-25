# polytrax/src/polytrax/instrumentation/builder.py
"""
EventBuilder: small helper to reduce adapter boilerplate.

Typical adapter usage:

    builder = EventBuilder(run_id="run-123", default_sender="agent_a", default_receiver="agent_b")
    event = builder.build(event_type="message", payload={"text": "hi"})
    # event is a valid USL event dict (ready for validation + sinks)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, Any


def _build_usl_event(
    *,
    run_id: str,
    sender: str,
    receiver: str,
    hop_index: int,
    event_type: str,
    payload: Dict[str, Any],
    trust: Optional[Dict[str, Any]] = None,
) -> dict:
    """
    Build a USL event using polytrax.usl.build_event if available; otherwise use schema helpers.

    This function intentionally does not validate; validation is handled by Instrumentor
    (or by sinks that validate internally).
    """
    # Preferred: public USL builder.
    try:
        from polytrax.usl import build_event as _build_event  # type: ignore
    except Exception:
        _build_event = None  # type: ignore

    if _build_event is not None:
        return _build_event(
            run_id,
            sender,
            receiver,
            hop_index,
            event_type,
            payload,
            trust=trust,
        )

    # Fallback: compose via schema template + fill fields.
    from polytrax.usl.schema import default_event_template  # type: ignore

    event = default_event_template(include_trust=(trust is not None))
    event["run_id"] = run_id
    event["sender"] = sender
    event["receiver"] = receiver
    event["hop_index"] = hop_index
    event["event_type"] = event_type
    event["payload"] = payload
    if trust is not None:
        event["trust"] = trust
    return event


@dataclass
class EventBuilder:
    """
    Helper for building valid USL event dicts with defaults and hop counting.

    - Maintains an internal hop counter starting at 0.
    - If hop_index is not provided, uses the internal counter and increments
      once per build call.
    - sender/receiver can be omitted if defaults were provided at init.
    """

    run_id: str
    default_sender: Optional[str] = None
    default_receiver: Optional[str] = None
    _hop_counter: int = field(default=0, init=False, repr=False)

    def build(
        self,
        *,
        sender: Optional[str] = None,
        receiver: Optional[str] = None,
        event_type: str,
        payload: dict,
        hop_index: Optional[int] = None,
        trust: Optional[dict] = None,
    ) -> dict:
        """
        Build a USL event dict.

        Parameters
        ----------
        sender / receiver:
            If omitted, defaults are used. If no default exists, raises ValueError.
        event_type:
            Free-form event type string.
        payload:
            Event payload dict (JSON-serialisable).
        hop_index:
            If None, uses internal hop counter and increments per call.
            If provided, uses that value and does not modify internal counter.
        trust:
            Optional trust annotation dict; passed through as-is when provided.
        """
        resolved_sender = sender if sender is not None else self.default_sender
        resolved_receiver = receiver if receiver is not None else self.default_receiver

        if not resolved_sender:
            raise ValueError("sender must be provided (no default_sender set)")
        if not resolved_receiver:
            raise ValueError("receiver must be provided (no default_receiver set)")

        if hop_index is None:
            resolved_hop = self._hop_counter
            self._hop_counter += 1
        else:
            resolved_hop = hop_index

        # Build using USL helpers (preferred build_event, fallback otherwise).
        return _build_usl_event(
            run_id=self.run_id,
            sender=resolved_sender,
            receiver=resolved_receiver,
            hop_index=resolved_hop,
            event_type=event_type,
            payload=payload,
            trust=trust,
        )