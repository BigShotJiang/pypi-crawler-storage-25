# polytrax/src/polytrax/instrumentation/instrumentor.py
"""
Instrumentor: validate + emit USL events to one or more sinks.

Adapters should treat Instrumentor as the single "write path":
- optionally validate (validate=True),
- write to sinks (JsonlSink, MemorySink, NoopSink, ...),
- flush/close lifecycle managed via context manager.

No analysis is performed here; it is purely build/validate/write.
"""

from __future__ import annotations

from collections.abc import Sequence as _Sequence
from typing import Iterable, List, Optional, Union

from polytrax.sinks import EventSink
from polytrax.usl import validate_event

from .builder import EventBuilder


def _normalise_sinks(sink: Union[EventSink, _Sequence[EventSink]]) -> List[EventSink]:
    # Treat a single EventSink as single, and sequences as multiple.
    if isinstance(sink, EventSink):
        return [sink]

    # Accept any Sequence[EventSink] (list/tuple/etc.)
    if isinstance(sink, _Sequence):
        sinks: List[EventSink] = []
        for s in sink:
            if not isinstance(s, EventSink):
                raise TypeError(
                    f"All sinks must implement EventSink; got {type(s).__name__}"
                )
            sinks.append(s)
        if not sinks:
            raise ValueError("At least one sink must be provided")
        return sinks

    raise TypeError(
        "sink must be an EventSink or a sequence of EventSink instances"
    )


class Instrumentor:
    """
    Emit validated USL events to one or more sinks.

    Parameters
    ----------
    sink:
        An EventSink or a sequence of EventSinks.
    validate:
        If True (default), calls polytrax.usl.validate_event(event) on emit().
        Note: some sinks also validate internally; keeping validate=True makes
        failures deterministic before partial writes.
    """

    def __init__(
        self,
        sink: Union[EventSink, _Sequence[EventSink]],
        *,
        validate: bool = True,
    ) -> None:
        self._sinks: List[EventSink] = _normalise_sinks(sink)
        self._validate: bool = bool(validate)

    def emit(self, event: dict) -> None:
        """Validate (optional) and write *event* to all sinks."""
        if self._validate:
            validate_event(event)

        # Write to all sinks. If a sink raises, we let it propagate.
        for sink in self._sinks:
            sink.write(event)

    def emit_built(self, builder: EventBuilder, **kwargs) -> dict:
        """
        Convenience: build via EventBuilder, emit, and return the built event.

        Example:
            instr.emit_built(builder, event_type="message", payload={"text": "hi"})
        """
        event = builder.build(**kwargs)
        self.emit(event)
        return event

    def flush(self) -> None:
        """Flush all sinks."""
        for sink in self._sinks:
            sink.flush()

    def close(self) -> None:
        """Close all sinks (idempotency depends on sink implementations)."""
        for sink in self._sinks:
            sink.close()

    def __enter__(self) -> "Instrumentor":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        self.close()