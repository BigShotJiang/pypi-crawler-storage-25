# polytrax/src/polytrax/instrumentation/__init__.py
"""
polytrax.instrumentation — runtime-agnostic event emission.

Adapters (LangGraph, ADK, custom runtimes, etc.) should use this layer to:
1) build USL event dicts (via EventBuilder),
2) optionally validate them (Instrumentor(validate=True)),
3) emit to one or more sinks (JsonlSink, MemorySink, etc.).

This module performs NO analysis (no graphs, no TPS). It only builds + validates + writes.
"""

from .builder import EventBuilder
from .instrumentor import Instrumentor

__all__ = [
    "EventBuilder",
    "Instrumentor",
]