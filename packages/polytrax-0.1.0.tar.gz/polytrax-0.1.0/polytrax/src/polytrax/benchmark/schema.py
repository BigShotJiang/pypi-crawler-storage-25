# polytrax/src/polytrax/benchmark/schema.py
"""
polytrax.benchmark — data structures for research-grade benchmark runs.

Defines dataclasses for:
- Run metadata (Meta)
- Per-run results (RunResult)
- Grouping key (GroupKey)
- Per-group aggregated summary (GroupSummary)
- Top-level benchmark output (BenchmarkResult)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Meta:
    """Metadata for a single benchmark run."""

    run_id: str
    architecture: str
    scenario: str
    seed: Optional[int] = None
    replicate_id: Optional[str] = None
    n_agents: Optional[int] = None
    notes: Optional[str] = None
    ts: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "run_id": self.run_id,
            "architecture": self.architecture,
            "scenario": self.scenario,
            "seed": self.seed,
            "replicate_id": self.replicate_id,
            "n_agents": self.n_agents,
            "notes": self.notes,
            "ts": self.ts,
        }


@dataclass
class RunResult:
    """Result of a single benchmark run."""

    meta: Meta
    report: Dict[str, Any]

    # Convenience extracted fields (duplicated for flat table output).
    node_count: int
    edge_count: int
    max_hop: int
    first_violation_hop: Optional[int]
    propagation_depth: int
    final_reach: int
    violation_persistence_ratio: float
    o_tps_score: float
    o_tps_class: str
    o_tps_action: str

    # Early-warning metrics.
    tps_cross_hop: Optional[int] = None
    lead_vs_first_violation: Optional[int] = None
    lead_vs_end: Optional[int] = None

    # Containment policy results: policy_name -> outcome dict.
    containment: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "meta": self.meta.to_dict(),
            "report": self.report,
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "max_hop": self.max_hop,
            "first_violation_hop": self.first_violation_hop,
            "propagation_depth": self.propagation_depth,
            "final_reach": self.final_reach,
            "violation_persistence_ratio": self.violation_persistence_ratio,
            "o_tps_score": self.o_tps_score,
            "o_tps_class": self.o_tps_class,
            "o_tps_action": self.o_tps_action,
            "tps_cross_hop": self.tps_cross_hop,
            "lead_vs_first_violation": self.lead_vs_first_violation,
            "lead_vs_end": self.lead_vs_end,
            "containment": self.containment,
        }


@dataclass
class GroupKey:
    """Grouping key for benchmark aggregation."""

    architecture: str
    scenario: str

    def to_dict(self) -> Dict[str, str]:
        """Return a JSON-serialisable dictionary."""
        return {
            "architecture": self.architecture,
            "scenario": self.scenario,
        }


@dataclass
class GroupSummary:
    """Aggregated summary for a (architecture, scenario) group."""

    key: GroupKey
    n_runs: int
    stats: Dict[str, Any]
    amplification: Dict[str, Any]
    early_warning: Dict[str, Any]
    containment: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "key": self.key.to_dict(),
            "n_runs": self.n_runs,
            "stats": self.stats,
            "amplification": self.amplification,
            "early_warning": self.early_warning,
            "containment": self.containment,
        }


@dataclass
class BenchmarkResult:
    """Top-level output of a benchmark run."""

    corpus_dir: str
    created_ts: str
    params: Dict[str, Any]
    runs: List[RunResult]
    groups: List[GroupSummary]
    derived: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "corpus_dir": self.corpus_dir,
            "created_ts": self.created_ts,
            "params": self.params,
            "runs": [r.to_dict() for r in self.runs],
            "groups": [g.to_dict() for g in self.groups],
            "derived": self.derived,
        }
