# polytrax/src/polytrax/benchmark/__init__.py
"""
polytrax.benchmark — research-grade multi-run benchmark runner.

Re-exports the public API so callers can write::

    from polytrax.benchmark import run_benchmark, BenchmarkResult
"""

from .schema import (
    BenchmarkResult,
    GroupKey,
    GroupSummary,
    Meta,
    RunResult,
)
from .runner import (
    aggregate_groups,
    build_run_result,
    compute_tps_cross_hop,
    derive_global_insights,
    discover_runs,
    evaluate_containment_policies,
    load_meta,
    load_or_generate_report,
    run_benchmark,
)

__all__ = [
    # schema
    "Meta",
    "RunResult",
    "GroupKey",
    "GroupSummary",
    "BenchmarkResult",
    # runner
    "discover_runs",
    "load_meta",
    "load_or_generate_report",
    "compute_tps_cross_hop",
    "evaluate_containment_policies",
    "build_run_result",
    "aggregate_groups",
    "derive_global_insights",
    "run_benchmark",
]
