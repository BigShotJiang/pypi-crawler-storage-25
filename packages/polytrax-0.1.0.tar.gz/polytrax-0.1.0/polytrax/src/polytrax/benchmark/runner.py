# polytrax/src/polytrax/benchmark/runner.py
"""
polytrax.benchmark.runner — deterministic benchmark execution engine.

Implements multi-run aggregation across architectures, perturbation scenarios,
and replicates.  Produces derived research metrics including amplification
factors, early-warning lead time, and containment trade-offs.

All outputs are deterministic (stable ordering, sorted keys).
Standard library only.
"""

from __future__ import annotations

import csv
import json
import os
import statistics
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from polytrax.usl import read_jsonl
from polytrax.analysis.graph import build_graph
from polytrax.analysis.propagation import compute_run_metrics
from polytrax.analysis.tps_replay import replay_o_tps
from polytrax.analysis.containment import apply_halt, containment_effectiveness
from polytrax.reporting import generate_run_report

from .schema import (
    BenchmarkResult,
    GroupKey,
    GroupSummary,
    Meta,
    RunResult,
)


# ── 1. discover_runs ────────────────────────────────────────────────


def discover_runs(corpus_dir: str) -> List[str]:
    """Return sorted list of run directory paths that contain trace.jsonl.

    Parameters
    ----------
    corpus_dir:
        Root directory containing run sub-folders.

    Returns
    -------
    list[str]
        Sorted absolute paths to run directories.
    """
    corpus = os.path.abspath(corpus_dir)
    run_dirs: List[str] = []
    if not os.path.isdir(corpus):
        return run_dirs
    for entry in sorted(os.listdir(corpus)):
        candidate = os.path.join(corpus, entry)
        if os.path.isdir(candidate) and entry != "_bench":
            trace_path = os.path.join(candidate, "trace.jsonl")
            if os.path.isfile(trace_path):
                run_dirs.append(candidate)
    return run_dirs


# ── 2. load_meta ────────────────────────────────────────────────────


def load_meta(run_dir: str) -> Meta:
    """Read meta.json if it exists; otherwise build a default Meta.

    Parameters
    ----------
    run_dir:
        Path to a run directory.

    Returns
    -------
    Meta
        Parsed or default metadata.
    """
    meta_path = os.path.join(run_dir, "meta.json")
    folder_name = os.path.basename(run_dir)

    if os.path.isfile(meta_path):
        with open(meta_path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        return Meta(
            run_id=raw.get("run_id", folder_name),
            architecture=raw.get("architecture", "unknown"),
            scenario=raw.get("scenario", "unknown"),
            seed=raw.get("seed"),
            replicate_id=raw.get("replicate_id"),
            n_agents=raw.get("n_agents"),
            notes=raw.get("notes"),
            ts=raw.get("ts"),
        )

    return Meta(
        run_id=folder_name,
        architecture="unknown",
        scenario="unknown",
    )


# ── 3. load_or_generate_report ──────────────────────────────────────


def load_or_generate_report(
    run_dir: str,
    *,
    force: bool = False,
    include_containment: bool = True,
) -> Dict[str, Any]:
    """Load an existing run_report.json or generate one from the trace.

    Parameters
    ----------
    run_dir:
        Path to a run directory that contains trace.jsonl.
    force:
        If ``True``, regenerate even when run_report.json exists.
    include_containment:
        Passed to ``reporting.generate_run_report``.

    Returns
    -------
    dict
        Report as a JSON-serialisable dictionary.
    """
    report_path = os.path.join(run_dir, "run_report.json")
    trace_path = os.path.join(run_dir, "trace.jsonl")

    if os.path.isfile(report_path) and not force:
        with open(report_path, "r", encoding="utf-8") as fh:
            return json.load(fh)

    events = list(read_jsonl(trace_path))
    report_obj = generate_run_report(
        events=events,
        include_containment=include_containment,
    )
    report_dict = report_obj.to_dict()

    # Write deterministically.
    os.makedirs(os.path.dirname(report_path) or ".", exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as fh:
        json.dump(report_dict, fh, indent=2, sort_keys=True)
        fh.write("\n")

    return report_dict


# ── 4. compute_tps_cross_hop ────────────────────────────────────────


def compute_tps_cross_hop(
    events: List[dict],
    *,
    threshold: float,
) -> Optional[int]:
    """Find the first hop where the O-TPS score crosses the threshold.

    For each message event in *events* (ordered by hop_index), compute
    O-TPS on the prefix of events up to and including that hop.  Return
    the ``hop_index`` of the first message event whose cumulative O-TPS
    ``trust_risk_score`` >= *threshold*.

    Parameters
    ----------
    events:
        Full list of USL event dicts for the run.
    threshold:
        Score threshold (e.g. 0.65).

    Returns
    -------
    int or None
        hop_index where the score first crosses, or None if it never does.
    """
    # Collect distinct hop indices from message events.
    message_types = {"message_sent", "message_blocked"}
    hop_set: set[int] = set()
    for ev in events:
        if isinstance(ev, dict) and ev.get("event_type") in message_types:
            h = ev.get("hop_index")
            if isinstance(h, int):
                hop_set.add(h)

    if not hop_set:
        return None

    sorted_hops = sorted(hop_set)

    for hop in sorted_hops:
        # Build prefix: all events with hop_index <= hop.
        prefix = [
            ev for ev in events
            if isinstance(ev, dict)
            and isinstance(ev.get("hop_index"), int)
            and ev["hop_index"] <= hop
        ]
        tps_out = replay_o_tps(prefix)
        if tps_out.trust_risk_score >= threshold:
            return hop

    return None


# ── 5. evaluate_containment_policies ────────────────────────────────


def evaluate_containment_policies(
    events: List[dict],
    report: Dict[str, Any],
    *,
    tps_threshold: float,
) -> Dict[str, Any]:
    """Evaluate standard containment policies for a run.

    Policies:
    - ``halt@first_violation``: halt at first_violation_hop
    - ``halt@first_violation+1``: halt at first_violation_hop + 1
    - ``halt@tps_cross``: halt at tps_cross_hop (skipped if None)

    For each policy, apply halt, rebuild the graph, compute metrics,
    and measure containment effectiveness.

    Parameters
    ----------
    events:
        Full event list.
    report:
        Report dict (from ``generate_run_report().to_dict()``).
    tps_threshold:
        Threshold for ``compute_tps_cross_hop``.

    Returns
    -------
    dict
        Mapping of policy_name to outcome dict.  Empty if no violations.
    """
    fvh = report.get("propagation", {}).get("first_violation_hop")
    if fvh is None:
        return {}

    original_graph = build_graph(events)
    original_metrics = compute_run_metrics(original_graph)

    tps_cross = compute_tps_cross_hop(events, threshold=tps_threshold)

    policies: Dict[str, Optional[int]] = {
        "halt@first_violation": fvh,
        "halt@first_violation+1": fvh + 1,
    }
    if tps_cross is not None:
        policies["halt@tps_cross"] = tps_cross

    result: Dict[str, Any] = {}
    for policy_name, halt_hop in sorted(policies.items()):
        if halt_hop is None:
            continue
        halted_events = apply_halt(events, halt_hop)
        halted_graph = build_graph(halted_events)
        halted_metrics = compute_run_metrics(halted_graph)
        eff = containment_effectiveness(original_metrics, halted_metrics)
        result[policy_name] = {
            "halt_at_hop": halt_hop,
            "halted_metrics": halted_metrics,
            **eff,
        }

    return result


# ── 6. build_run_result ─────────────────────────────────────────────


def build_run_result(run_dir: str, params: Dict[str, Any]) -> RunResult:
    """Build a RunResult for a single run directory.

    Parameters
    ----------
    run_dir:
        Path to the run directory.
    params:
        Benchmark parameters dict (contains tps_threshold, etc.).

    Returns
    -------
    RunResult
    """
    trace_path = os.path.join(run_dir, "trace.jsonl")
    events = list(read_jsonl(trace_path))

    meta = load_meta(run_dir)
    report = load_or_generate_report(
        run_dir,
        force=params.get("force_regenerate_reports", False),
        include_containment=params.get("include_containment", True),
    )

    # Extract fields from report.
    graph_sec = report.get("graph", {})
    prop_sec = report.get("propagation", {})
    tps_sec = report.get("offline_tps", {})

    node_count = graph_sec.get("node_count", 0)
    edge_count = graph_sec.get("edge_count", 0)
    max_hop = graph_sec.get("max_hop", 0)
    first_viol = prop_sec.get("first_violation_hop")
    prop_depth = prop_sec.get("propagation_depth", 0)
    f_reach = prop_sec.get("final_reach", 0)
    vpr = prop_sec.get("violation_persistence_ratio", 0.0)
    o_score = tps_sec.get("score", 0.0)
    o_class = tps_sec.get("risk_class", "LOW")
    o_action = tps_sec.get("recommended_action", "NO_ACTION")

    # Early-warning metrics.
    tps_threshold = params.get("tps_threshold", 0.65)
    tps_cross = compute_tps_cross_hop(events, threshold=tps_threshold)

    H = max_hop
    k = first_viol
    t = tps_cross

    if k is not None and t is not None:
        lead_vs_first_violation = k - t
    else:
        lead_vs_first_violation = None

    if t is not None:
        lead_vs_end = H - t
    else:
        lead_vs_end = None

    # Containment policies.
    if params.get("include_containment", True):
        containment = evaluate_containment_policies(
            events, report, tps_threshold=tps_threshold,
        )
    else:
        containment = {}

    return RunResult(
        meta=meta,
        report=report,
        node_count=node_count,
        edge_count=edge_count,
        max_hop=max_hop,
        first_violation_hop=first_viol,
        propagation_depth=prop_depth,
        final_reach=f_reach,
        violation_persistence_ratio=vpr,
        o_tps_score=o_score,
        o_tps_class=o_class,
        o_tps_action=o_action,
        tps_cross_hop=tps_cross,
        lead_vs_first_violation=lead_vs_first_violation,
        lead_vs_end=lead_vs_end,
        containment=containment,
    )


# ── helpers for aggregate_groups ────────────────────────────────────


def _compute_stats(values: List[float]) -> Dict[str, Any]:
    """Compute mean, median, stdev, min, max, n for a list of floats."""
    n = len(values)
    if n == 0:
        return {"mean": 0.0, "median": 0.0, "stdev": 0.0, "min": 0.0, "max": 0.0, "n": 0}
    m = statistics.mean(values)
    med = statistics.median(values)
    sd = statistics.stdev(values) if n >= 2 else 0.0
    return {
        "mean": m,
        "median": med,
        "stdev": sd,
        "min": min(values),
        "max": max(values),
        "n": n,
    }


def _safe_mean(values: List[float]) -> float:
    """Mean of non-empty list, else 0.0."""
    if not values:
        return 0.0
    return statistics.mean(values)


# ── 7. aggregate_groups ─────────────────────────────────────────────


def aggregate_groups(
    run_results: List[RunResult],
    *,
    baseline_arch: str = "pipeline",
) -> List[GroupSummary]:
    """Aggregate run results into (architecture, scenario) groups.

    Parameters
    ----------
    run_results:
        List of RunResult objects.
    baseline_arch:
        Architecture used as baseline for amplification factors.

    Returns
    -------
    list[GroupSummary]
        Sorted by (scenario, architecture).
    """
    # Group runs by (architecture, scenario).
    groups_map: Dict[tuple[str, str], List[RunResult]] = {}
    for rr in run_results:
        key = (rr.meta.architecture, rr.meta.scenario)
        groups_map.setdefault(key, []).append(rr)

    # Build baseline lookup: scenario -> baseline group runs.
    baseline_means: Dict[str, Dict[str, float]] = {}
    for (arch, scenario), runs in groups_map.items():
        if arch == baseline_arch:
            baseline_means[scenario] = {
                "final_reach": _safe_mean([r.final_reach for r in runs]),
                "propagation_depth": _safe_mean(
                    [float(r.propagation_depth) for r in runs]
                ),
            }

    summaries: List[GroupSummary] = []

    for (arch, scenario), runs in groups_map.items():
        gk = GroupKey(architecture=arch, scenario=scenario)
        n_runs = len(runs)

        # Stats for selected metrics.
        stats: Dict[str, Any] = {}
        for metric_name, extractor in [
            ("o_tps_score", lambda r: r.o_tps_score),
            ("final_reach", lambda r: float(r.final_reach)),
            ("propagation_depth", lambda r: float(r.propagation_depth)),
            ("violation_persistence_ratio", lambda r: r.violation_persistence_ratio),
            ("lead_vs_end", lambda r: r.lead_vs_end),
        ]:
            if metric_name == "lead_vs_end":
                vals = [float(extractor(r)) for r in runs if extractor(r) is not None]
            else:
                vals = [extractor(r) for r in runs]
            stats[metric_name] = _compute_stats(vals)

        # Amplification factors relative to baseline.
        amplification: Dict[str, Any] = {}
        bl = baseline_means.get(scenario)
        if bl is not None and arch != baseline_arch:
            grp_reach = _safe_mean([float(r.final_reach) for r in runs])
            grp_depth = _safe_mean([float(r.propagation_depth) for r in runs])
            amplification = {
                "reach_amp": grp_reach / max(bl["final_reach"], 1e-9),
                "depth_amp": grp_depth / max(bl["propagation_depth"], 1e-9),
                "baseline_arch": baseline_arch,
            }

        # Containment aggregation.
        containment_agg: Dict[str, Any] = {}
        # Collect all policy names seen.
        all_policies: set[str] = set()
        for r in runs:
            all_policies.update(r.containment.keys())
        for policy in sorted(all_policies):
            prevented = [
                r.containment[policy]["prevented_ratio"]
                for r in runs
                if policy in r.containment
                and "prevented_ratio" in r.containment[policy]
            ]
            if prevented:
                containment_agg[policy] = {
                    "mean_prevented_ratio": _safe_mean(prevented),
                    "n": len(prevented),
                }

        # Early-warning aggregation.
        ew_lead_end = [
            float(r.lead_vs_end) for r in runs if r.lead_vs_end is not None
        ]
        ew_lead_fv = [
            float(r.lead_vs_first_violation)
            for r in runs
            if r.lead_vs_first_violation is not None
        ]
        early_warning: Dict[str, Any] = {}
        if ew_lead_end:
            early_warning["lead_vs_end"] = {
                "mean": _safe_mean(ew_lead_end),
                "median": statistics.median(ew_lead_end),
                "n": len(ew_lead_end),
            }
        if ew_lead_fv:
            early_warning["lead_vs_first_violation"] = {
                "mean": _safe_mean(ew_lead_fv),
                "median": statistics.median(ew_lead_fv),
                "n": len(ew_lead_fv),
            }

        summaries.append(
            GroupSummary(
                key=gk,
                n_runs=n_runs,
                stats=stats,
                amplification=amplification,
                early_warning=early_warning,
                containment=containment_agg,
            )
        )

    # Sort by (scenario, architecture) for determinism.
    summaries.sort(key=lambda gs: (gs.key.scenario, gs.key.architecture))
    return summaries


# ── 8. derive_global_insights ───────────────────────────────────────


def derive_global_insights(groups: List[GroupSummary]) -> Dict[str, Any]:
    """Compute global derived metrics from group summaries.

    Parameters
    ----------
    groups:
        List of GroupSummary from ``aggregate_groups``.

    Returns
    -------
    dict
        Global derived metrics including architecture ranking and
        worst-case scenarios.
    """
    # Architecture ranking by weighted mean O-TPS.
    arch_totals: Dict[str, Dict[str, float]] = {}  # arch -> {score_sum, n}
    for gs in groups:
        arch = gs.key.architecture
        s = arch_totals.setdefault(arch, {"score_sum": 0.0, "n": 0.0})
        otps_stats = gs.stats.get("o_tps_score", {})
        mean_score = otps_stats.get("mean", 0.0)
        n = gs.n_runs
        s["score_sum"] += mean_score * n
        s["n"] += n

    arch_ranking: List[Dict[str, Any]] = []
    for arch in sorted(arch_totals.keys()):
        info = arch_totals[arch]
        n = info["n"]
        weighted_mean = info["score_sum"] / max(n, 1.0)
        arch_ranking.append({
            "architecture": arch,
            "weighted_mean_o_tps": weighted_mean,
            "total_runs": int(n),
        })
    # Sort by weighted mean O-TPS descending (higher risk first).
    arch_ranking.sort(key=lambda x: (-x["weighted_mean_o_tps"], x["architecture"]))

    # Worst-case scenario per architecture by reach_amp.
    worst_case: Dict[str, Any] = {}
    for gs in groups:
        amp = gs.amplification
        if not amp:
            continue
        arch = gs.key.architecture
        reach_amp = amp.get("reach_amp", 0.0)
        if arch not in worst_case or reach_amp > worst_case[arch]["reach_amp"]:
            worst_case[arch] = {
                "scenario": gs.key.scenario,
                "reach_amp": reach_amp,
            }

    # Summary counts.
    unique_archs = sorted({gs.key.architecture for gs in groups})
    unique_scenarios = sorted({gs.key.scenario for gs in groups})

    return {
        "architecture_ranking": arch_ranking,
        "worst_case_by_arch": worst_case,
        "summary_counts": {
            "n_groups": len(groups),
            "n_architectures": len(unique_archs),
            "n_scenarios": len(unique_scenarios),
            "architectures": unique_archs,
            "scenarios": unique_scenarios,
        },
    }


# ── 9. run_benchmark ────────────────────────────────────────────────


def run_benchmark(
    corpus_dir: str = "runs",
    *,
    tps_threshold: float = 0.65,
    include_containment: bool = True,
    force_regenerate_reports: bool = False,
    baseline_arch: str = "pipeline",
) -> BenchmarkResult:
    """Execute a full benchmark run across a corpus of traces.

    Parameters
    ----------
    corpus_dir:
        Root directory containing run sub-folders.
    tps_threshold:
        O-TPS score threshold for early-warning detection.
    include_containment:
        Whether to evaluate containment policies.
    force_regenerate_reports:
        If ``True``, regenerate run_report.json even if it exists.
    baseline_arch:
        Architecture used as baseline for amplification factors.

    Returns
    -------
    BenchmarkResult
        Complete benchmark output.  Also writes output files to
        ``<corpus_dir>/_bench/``.
    """
    params: Dict[str, Any] = {
        "tps_threshold": tps_threshold,
        "include_containment": include_containment,
        "force_regenerate_reports": force_regenerate_reports,
        "baseline_arch": baseline_arch,
    }

    # Discover and build results.
    run_dirs = discover_runs(corpus_dir)

    run_results: List[RunResult] = []
    for rd in run_dirs:
        rr = build_run_result(rd, params)
        run_results.append(rr)

    # Aggregate and derive.
    groups = aggregate_groups(run_results, baseline_arch=baseline_arch)
    derived = derive_global_insights(groups)

    created_ts = datetime.now(timezone.utc).isoformat()

    result = BenchmarkResult(
        corpus_dir=os.path.abspath(corpus_dir),
        created_ts=created_ts,
        params=params,
        runs=run_results,
        groups=groups,
        derived=derived,
    )

    # Write outputs.
    bench_dir = os.path.join(corpus_dir, "_bench")
    os.makedirs(bench_dir, exist_ok=True)

    # bench_results.json
    results_path = os.path.join(bench_dir, "bench_results.json")
    with open(results_path, "w", encoding="utf-8") as fh:
        json.dump(result.to_dict(), fh, indent=2, sort_keys=True)
        fh.write("\n")

    # bench_summary.json
    summary_dict = {
        "created_ts": created_ts,
        "params": params,
        "groups": [g.to_dict() for g in groups],
        "derived": derived,
    }
    summary_path = os.path.join(bench_dir, "bench_summary.json")
    with open(summary_path, "w", encoding="utf-8") as fh:
        json.dump(summary_dict, fh, indent=2, sort_keys=True)
        fh.write("\n")

    # bench_table.csv
    _write_csv_table(run_results, bench_dir)

    return result


def _write_csv_table(run_results: List[RunResult], bench_dir: str) -> None:
    """Write flat CSV table of per-run metrics."""
    if not run_results:
        # Write empty CSV with headers only.
        csv_path = os.path.join(bench_dir, "bench_table.csv")
        with open(csv_path, "w", encoding="utf-8", newline="") as fh:
            fh.write("")
        return

    # Collect all containment policy names across runs for column headers.
    all_policies: List[str] = sorted(
        {p for rr in run_results for p in rr.containment.keys()}
    )

    fieldnames = [
        "run_id",
        "architecture",
        "scenario",
        "seed",
        "replicate_id",
        "n_agents",
        "node_count",
        "edge_count",
        "max_hop",
        "first_violation_hop",
        "propagation_depth",
        "final_reach",
        "violation_persistence_ratio",
        "o_tps_score",
        "o_tps_class",
        "o_tps_action",
        "tps_cross_hop",
        "lead_vs_first_violation",
        "lead_vs_end",
    ]
    for policy in all_policies:
        fieldnames.append(f"containment_{policy}_prevented_ratio")

    csv_path = os.path.join(bench_dir, "bench_table.csv")
    with open(csv_path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()

        for rr in run_results:
            row: Dict[str, Any] = {
                "run_id": rr.meta.run_id,
                "architecture": rr.meta.architecture,
                "scenario": rr.meta.scenario,
                "seed": rr.meta.seed if rr.meta.seed is not None else "",
                "replicate_id": rr.meta.replicate_id if rr.meta.replicate_id is not None else "",
                "n_agents": rr.meta.n_agents if rr.meta.n_agents is not None else "",
                "node_count": rr.node_count,
                "edge_count": rr.edge_count,
                "max_hop": rr.max_hop,
                "first_violation_hop": rr.first_violation_hop if rr.first_violation_hop is not None else "",
                "propagation_depth": rr.propagation_depth,
                "final_reach": rr.final_reach,
                "violation_persistence_ratio": rr.violation_persistence_ratio,
                "o_tps_score": rr.o_tps_score,
                "o_tps_class": rr.o_tps_class,
                "o_tps_action": rr.o_tps_action,
                "tps_cross_hop": rr.tps_cross_hop if rr.tps_cross_hop is not None else "",
                "lead_vs_first_violation": rr.lead_vs_first_violation if rr.lead_vs_first_violation is not None else "",
                "lead_vs_end": rr.lead_vs_end if rr.lead_vs_end is not None else "",
            }
            for policy in all_policies:
                col = f"containment_{policy}_prevented_ratio"
                if policy in rr.containment and "prevented_ratio" in rr.containment[policy]:
                    row[col] = rr.containment[policy]["prevented_ratio"]
                else:
                    row[col] = ""
            writer.writerow(row)
