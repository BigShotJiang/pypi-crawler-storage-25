# polytrax/src/polytrax/adapters/langgraph.py
"""
LangGraphAdapter — instruments compiled LangGraph graphs with USL events.

This adapter wraps node callables in a compiled LangGraph ``CompiledGraph``
so that each node invocation emits a ``message_sent`` USL event via the
PolyTrax instrumentation pipeline.  It also supports runtime control hooks
(``halt_run``, ``gate_message``) identical to the GenericAdapter contract.

Optionally accepts a ``TrustEvaluator`` to perform policy-based trust
assessment on each inter-agent message, attaching USL trust annotations
when violations are detected.

**LangGraph is an optional dependency.**  It is imported lazily inside
``attach()`` — if the package is missing, an informative ``ImportError``
is raised.  Importing this module alone never triggers a langgraph import.

Limitations
-----------
- Only node-level transitions are intercepted (not internal LangChain
  runnable sub-steps).
- State snapshots in payloads are truncated to ``_MAX_STATE_REPR`` chars
  to avoid oversized events.
- The adapter wraps ``RunnableCallable.func``; if LangGraph changes that
  internal representation, the wrapping logic may need updating.

Example
-------
::

    from polytrax.sinks import JsonlSink
    from polytrax.instrumentation import Instrumentor
    from polytrax.adapters.langgraph import LangGraphAdapter

    instrumentor = Instrumentor(JsonlSink("trace.jsonl"), validate=True)
    adapter = LangGraphAdapter(instrumentor, run_id="lg_run_1")

    adapter.attach(graph)       # graph is a compiled LangGraph instance
    graph.invoke(input_data)    # events emitted automatically
    adapter.detach()
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional, Set, Tuple

from polytrax.instrumentation import EventBuilder, Instrumentor

from .base import RuntimeAdapter
from .exceptions import AdapterNotAttachedError, AdapterControlError

# Maximum characters for a state repr snapshot inside event payloads.
# Maximum characters for a state repr snapshot inside event payloads.
_MAX_STATE_REPR = 50000

# Optional trust evaluator import (always available since polytrax.trust
# is part of the same package, but guarded for safety).
try:
    from polytrax.trust import TrustEvaluator as _TrustEvaluator
except ImportError:  # pragma: no cover
    _TrustEvaluator = None  # type: ignore[assignment,misc]


class LangGraphAdapter(RuntimeAdapter):
    """
    Adapter for instrumenting compiled LangGraph graphs.

    Wraps node callables so that each invocation emits USL ``message_sent``
    events (or ``message_blocked`` when gated).  Supports ``halt_run`` to
    interrupt execution and ``gate_message`` to block specific edges.

    Parameters
    ----------
    instrumentor :
        The :class:`~polytrax.instrumentation.Instrumentor` used to emit events.
    run_id :
        Unique identifier for this run / trace.
    trust_evaluator :
        Optional :class:`~polytrax.trust.TrustEvaluator` for policy-based
        trust assessment.  When provided, each ``message_sent`` event will
        include a ``trust`` block computed by running the evaluator's
        registered policies against the node's input and output.
    """

    def __init__(
        self,
        instrumentor: Instrumentor,
        *,
        run_id: str,
        trust_evaluator: Any = None,
    ) -> None:
        super().__init__(instrumentor)
        self._run_id: str = run_id
        self._builder: EventBuilder = EventBuilder(
            run_id=run_id,
            default_sender="polytrax",
            default_receiver="polytrax",
        )
        self._hop_index: int = 0
        self._attached: bool = False
        self._halted: bool = False
        self._gated_edges: Set[Tuple[str, str]] = set()
        self._trust_evaluator: Any = trust_evaluator
        self._node_depths: Dict[str, int] = {"__start__": 0}

        # Populated on attach() for cleanup on detach().
        self._graph: Any = None
        self._original_funcs: Dict[str, Callable[..., Any]] = {}
        self._last_node: Optional[str] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def attach(self, graph: Any = None) -> None:  # type: ignore[override]
        """
        Attach to a compiled LangGraph graph and wrap its node callables.

        Parameters
        ----------
        graph :
            A compiled ``langgraph.graph.state.CompiledStateGraph`` (or any
            ``CompiledGraph`` subclass).  Its ``.nodes`` dict is iterated and
            each node's ``.func`` is replaced with an instrumented wrapper.

        Raises
        ------
        ImportError
            If ``langgraph`` is not installed.
        RuntimeError
            If the adapter is already attached.
        """
        # --- lazy import --------------------------------------------------
        try:
            import langgraph  # noqa: F401
        except ImportError:
            raise ImportError(
                "LangGraphAdapter requires the 'langgraph' package.  "
                "Install it with:  pip install langgraph"
            )

        if self._attached:
            raise RuntimeError(
                "LangGraphAdapter is already attached.  "
                "Call detach() before attaching to another graph."
            )

        if graph is None:
            raise ValueError("A compiled LangGraph graph must be provided to attach().")

        self._graph = graph
        self._last_node = "__start__"
        self._original_funcs.clear()

        # --- wrap each node -----------------------------------------------
        nodes: Dict[str, Any] = getattr(graph, "nodes", {})
        for node_name, runnable in nodes.items():
            # Standard RunnableCallable
            original_func = getattr(runnable, "func", None)
            if original_func is not None:
                self._original_funcs[node_name] = (runnable, "func", original_func)
                runnable.func = self._make_wrapper(node_name, original_func)
                continue

            # PregelNode wrapping a RunnableLambda
            bound = getattr(runnable, "bound", None)
            if bound is not None:
                original_func = getattr(bound, "func", None)
                if original_func is not None:
                    self._original_funcs[node_name] = (bound, "func", original_func)
                    bound.func = self._make_wrapper(node_name, original_func)
                    continue

        self._attached = True

        self.emit_built(
            self._builder,
            event_type="adapter_attached",
            payload={
                "adapter": "langgraph",
                "run_id": self._run_id,
                "nodes": list(nodes.keys()),
            },
        )

    def detach(self) -> None:
        """
        Restore original node callables and mark the adapter as detached.

        Safe to call even if not currently attached (no-op).
        """
        if not self._attached:
            return

        # Restore originals.
        if self._graph is not None:
            for node_name, (obj, attr, original_func) in self._original_funcs.items():
                setattr(obj, attr, original_func)

        self._attached = False
        self._original_funcs.clear()
        self._graph = None
        self._last_node = None

        self.emit_built(
            self._builder,
            event_type="adapter_detached",
            payload={"adapter": "langgraph"},
        )

    # ------------------------------------------------------------------
    # Runtime control hooks
    # ------------------------------------------------------------------

    def halt_run(self, reason: str) -> None:
        """
        Halt the current run.

        Sets an internal flag that causes the next (or in-progress) node
        invocation to raise ``RuntimeError``, interrupting LangGraph execution.

        Parameters
        ----------
        reason :
            Human-readable explanation for the halt.
        """
        if not self._attached:
            raise AdapterNotAttachedError(
                "halt_run requires adapter to be attached"
            )
        self._halted = True
        self.emit_built(
            self._builder,
            event_type="run_halted",
            payload={"reason": reason},
        )

    def gate_message(self, sender: str, receiver: str, *, reason: str) -> None:
        """
        Block a specific sender -> receiver edge.

        When the wrapped node matching *receiver* is invoked and the
        inferred sender matches *sender*, a ``message_blocked`` event is
        emitted and the node is skipped (state returned unchanged).

        Parameters
        ----------
        sender :
            Name of the sending node.
        receiver :
            Name of the receiving (target) node to block.
        reason :
            Human-readable explanation for the gate.
        """
        if not self._attached:
            raise AdapterNotAttachedError(
                "gate_message requires adapter to be attached"
            )
        self._gated_edges.add((sender, receiver))
        self.emit_built(
            self._builder,
            sender=sender,
            receiver=receiver,
            event_type="gate_applied",
            payload={
                "sender": sender,
                "receiver": receiver,
                "reason": reason,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _evaluate_trust(
        self,
        sender: str,
        receiver: str,
        node_input: Any,
        node_output: Any,
    ) -> Optional[Dict[str, Any]]:
        """Run trust evaluator if configured; return trust block or None."""
        if self._trust_evaluator is None:
            return None
        try:
            # Update evaluator context with per-hop metadata.
            ctx = self._trust_evaluator.context
            ctx["run_id"] = self._run_id
            ctx["hop_index"] = self._hop_index
            ctx["node_name"] = receiver
            return self._trust_evaluator.evaluate(
                sender, receiver, node_input, node_output,
            )
        except Exception:
            return None

    def _make_wrapper(
        self,
        node_name: str,
        original_func: Callable[..., Any],
    ) -> Callable[..., Any]:
        """
        Return a wrapper around *original_func* that emits USL events.

        The wrapper:
        1. Checks ``_halted`` — raises ``RuntimeError`` if set.
        2. Checks ``_gated_edges`` — emits ``message_blocked`` and returns
           state unchanged if the edge is gated.
        3. Calls the original function.
        4. Evaluates trust (if evaluator configured) using input + output.
        5. Emits ``message_sent`` with the trust block attached.
        6. Updates ``_last_node`` to this node for the next transition.

        Exception handling:
        If the node function raises, the wrapper emits a ``message_sent``
        event with an error payload and elevated provenance severity,
        then re-raises the exception.
        """
        adapter = self  # closure reference

        def _wrapped(state: Any, *args: Any, **kwargs: Any) -> Any:
            # --- halt check -----------------------------------------------
            if adapter._halted:
                raise RuntimeError(
                    f"LangGraphAdapter: run halted before node '{node_name}'"
                )

            sender_name = adapter._last_node or "__start__"
            receiver_name = node_name

            # --- gate check -----------------------------------------------
            if (sender_name, receiver_name) in adapter._gated_edges:
                adapter.emit_built(
                    adapter._builder,
                    sender=sender_name,
                    receiver=receiver_name,
                    event_type="message_blocked",
                    hop_index=adapter._hop_index,
                    payload={
                        "node": receiver_name,
                        "sender": sender_name,
                        "reason": "gated_edge",
                        "state_snapshot": repr(state)[:_MAX_STATE_REPR],
                    },
                )
                return state

            # --- execute original node ------------------------------------
            node_error = None
            result = None
            try:
                result = original_func(state, *args, **kwargs)
            except Exception as exc:
                node_error = exc
                result = {"_error": type(exc).__name__, "_message": str(exc)[:200]}

            # --- trust evaluation (post-execution) ------------------------
            trust_block = adapter._evaluate_trust(
                sender_name, receiver_name, state, result,
            )

            # If the node errored, add a provenance severity bump.
            if node_error is not None and trust_block is None:
                trust_block = {
                    "constraints": {"severity": 0.0, "status": "ok"},
                    "evidence": {"severity": 0.0, "status": "ok"},
                    "provenance": {"severity": 0.5, "status": "warn"},
                    "_reasons": [f"Node '{node_name}' raised {type(node_error).__name__}"],
                }

            # --- calculate hop depth --------------------------------------
            sender_depth = adapter._node_depths.get(sender_name, 0)
            current_depth = sender_depth + 1
            adapter._node_depths[receiver_name] = current_depth
            
            # --- emit message_sent ----------------------------------------
            emit_kwargs: Dict[str, Any] = {
                "sender": sender_name,
                "receiver": receiver_name,
                "event_type": "message_sent",
                "hop_index": current_depth,
                "payload": {
                    "node": receiver_name,
                    "state_snapshot": repr(state)[:_MAX_STATE_REPR],
                    "message_sequence": adapter._hop_index,
                },
            }
            if trust_block is not None:
                emit_kwargs["trust"] = trust_block

            print(f"[POLYTRAX-TRUTH] EVENT_EMIT | session={adapter._run_id} | sender={sender_name} | receiver={receiver_name} | type=message_sent | hop={current_depth} | has_trust={trust_block is not None}")
            adapter.emit_built(adapter._builder, **emit_kwargs)
            adapter._hop_index += 1

            # --- track transition -----------------------------------------
            adapter._last_node = node_name

            # --- re-raise if node errored ---------------------------------
            if node_error is not None:
                raise node_error

            return result

        # Preserve useful metadata for debugging.
        _wrapped.__name__ = f"polytrax_wrapped_{node_name}"
        _wrapped.__qualname__ = f"LangGraphAdapter._wrapped_{node_name}"
        _wrapped.__doc__ = (
            f"PolyTrax-instrumented wrapper for LangGraph node '{node_name}'."
        )

        return _wrapped
