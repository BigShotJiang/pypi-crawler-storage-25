# polytrax/src/polytrax/adapters/base.py
"""
RuntimeAdapter contract.

Adapters translate runtime-specific signals (messages, tool calls, state changes)
into USL events emitted via polytrax.instrumentation.Instrumentor.

This module intentionally contains no runtime-specific imports.
"""

from __future__ import annotations

import abc
from typing import Any

from polytrax.instrumentation import EventBuilder, Instrumentor


class RuntimeAdapter(abc.ABC):
    """
    Abstract base class for runtime adapters.

    Concrete adapters should:
    - attach/detach to a runtime lifecycle
    - optionally support controls (halt run, gate a message edge)
    - emit USL events via the provided Instrumentor
    """

    def __init__(self, instrumentor: Instrumentor) -> None:
        self._instrumentor = instrumentor

    @abc.abstractmethod
    def attach(self) -> None:
        """Attach adapter to runtime lifecycle (or mark as attached)."""

    @abc.abstractmethod
    def detach(self) -> None:
        """Detach adapter from runtime lifecycle (or mark as detached)."""

    @abc.abstractmethod
    def halt_run(self, reason: str) -> None:
        """Request that the runtime halts the current run for the given reason."""

    @abc.abstractmethod
    def gate_message(self, sender: str, receiver: str, *, reason: str) -> None:
        """Request that messages from sender->receiver are gated/blocked with the given reason."""

    def emit_event(self, event: dict) -> None:
        """Emit an already-built USL event dict."""
        self._instrumentor.emit(event)

    def emit_built(self, builder: EventBuilder, **kwargs: Any) -> dict:
        """Build via EventBuilder, emit, and return the built event."""
        return self._instrumentor.emit_built(builder, **kwargs)