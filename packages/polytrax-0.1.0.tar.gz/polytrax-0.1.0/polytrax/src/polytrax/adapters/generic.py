# polytrax/src/polytrax/adapters/generic.py
"""
GenericAdapter: lightweight in-process adapter for demos/tests.

This simulates a multi-agent "run" deterministically without any external runtime.
Useful for validating end-to-end plumbing:
USL builder/validator -> Instrumentor -> sinks.

Supported architectures:
- pipeline: A->B->C->... (wrap around)
- peer: round-robin edges among agents (every ordered pair excluding self)
- supervisor: Supervisor<->AgentX alternating
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Set, Tuple

from polytrax.instrumentation import EventBuilder, Instrumentor

from .base import RuntimeAdapter
from .exceptions import AdapterNotAttachedError, AdapterControlError


class GenericAdapter(RuntimeAdapter):
    """
    In-process adapter that emits USL events for a simulated multi-agent run.

    Notes:
    - Deterministic: same (agents, architecture, steps) -> same event sequence.
    - Trust is optional and never required; you may include it via payload_factory if desired.
    """

    def __init__(
        self,
        instrumentor: Instrumentor,
        *,
        run_id: str,
        agents: Optional[List[str]] = None,
        architecture: str = "pipeline",  # "pipeline", "peer", "supervisor"
    ) -> None:
        super().__init__(instrumentor)
        self._run_id = run_id
        self._architecture = architecture

        # Default agent set if none provided.
        self._agents: List[str] = list(agents) if agents is not None else ["A", "B", "C"]

        if not self._agents:
            raise ValueError("agents must contain at least one agent name")

        if self._architecture not in {"pipeline", "peer", "supervisor"}:
            raise ValueError('architecture must be one of: "pipeline", "peer", "supervisor"')

        # Ensure Supervisor exists for supervisor architecture.
        if self._architecture == "supervisor" and "Supervisor" not in self._agents:
            self._agents = ["Supervisor"] + self._agents

        # Provide defaults so non-message lifecycle events can emit without sender/receiver.
        self._builder = EventBuilder(
            run_id=self._run_id,
            default_sender="polytrax",
            default_receiver="polytrax",
        )

        self._attached: bool = False
        self._halted: bool = False
        self._gated_edges: Set[Tuple[str, str]] = set()

    def attach(self) -> None:
        self._attached = True
        self.emit_built(
            self._builder,
            event_type="adapter_attached",
            payload={
                "adapter": "generic",
                "architecture": self._architecture,
                "agents": list(self._agents),
            },
        )

    def detach(self) -> None:
        # Detach is allowed even if already detached; keep deterministic and simple.
        self._attached = False
        self.emit_built(
            self._builder,
            event_type="adapter_detached",
            payload={"adapter": "generic"},
        )

    def gate_message(self, sender: str, receiver: str, *, reason: str) -> None:
        if not self._attached:
            raise AdapterNotAttachedError("gate_message requires adapter to be attached")
        self._gated_edges.add((sender, receiver))
        self.emit_built(
            self._builder,
            sender=sender,
            receiver=receiver,
            event_type="gate_applied",
            payload={"sender": sender, "receiver": receiver, "reason": reason},
        )

    def halt_run(self, reason: str) -> None:
        if not self._attached:
            raise AdapterNotAttachedError("halt_run requires adapter to be attached")
        self._halted = True
        self.emit_built(
            self._builder,
            event_type="run_halted",
            payload={"reason": reason},
        )

    def run(
        self,
        *,
        steps: int = 5,
        payload_factory: Optional[Callable[[int, str, str], Dict]] = None,
    ) -> None:
        """
        Simulate a run and emit message events.

        For each step i:
        - choose (sender, receiver) based on architecture
        - if the edge is gated: emit message_blocked (and do not emit message_sent)
        - else emit message_sent

        payload_factory (optional):
          Callable(step_i, sender, receiver) -> dict payload
          Trust is not required; if you want, you can return {"trust": {...}, ...}
          and it will be included in payload only. USL trust field is not touched by default.
        """
        if not self._attached:
            raise AdapterNotAttachedError("run requires adapter to be attached")
        if self._halted:
            raise AdapterControlError("run cannot start: adapter is halted")
        if steps < 0:
            raise ValueError("steps must be >= 0")

        # Precompute deterministic edge sequences for each architecture.
        if self._architecture == "pipeline":
            edges = self._pipeline_edges()
        elif self._architecture == "peer":
            edges = self._peer_edges()
        else:  # supervisor
            edges = self._supervisor_edges()

        if not edges:
            # Should not happen, but keep behavior explicit.
            raise AdapterControlError("no valid edges available to simulate run")

        for i in range(steps):
            if self._halted:
                break

            sender, receiver = edges[i % len(edges)]

            # Default payload (deterministic)
            if payload_factory is None:
                payload: Dict = {
                    "step": i,
                    "content": f"msg-{i} {sender}->{receiver}",
                    "meta": {
                        "architecture": self._architecture,
                    },
                }
            else:
                payload = payload_factory(i, sender, receiver)
                if not isinstance(payload, dict):
                    raise TypeError("payload_factory must return a dict")

            if (sender, receiver) in self._gated_edges:
                self.emit_built(
                    self._builder,
                    sender=sender,
                    receiver=receiver,
                    event_type="message_blocked",
                    payload={
                        "step": i,
                        "sender": sender,
                        "receiver": receiver,
                        "reason": "gated_edge",
                        "intended": payload,
                    },
                )
                continue

            self.emit_built(
                self._builder,
                sender=sender,
                receiver=receiver,
                event_type="message_sent",
                payload=payload,
            )

    def _pipeline_edges(self) -> List[Tuple[str, str]]:
        # A->B->C->... wrap
        agents = list(self._agents)
        if len(agents) == 1:
            # Self-loop only.
            return [(agents[0], agents[0])]
        edges: List[Tuple[str, str]] = []
        for idx, a in enumerate(agents):
            b = agents[(idx + 1) % len(agents)]
            edges.append((a, b))
        return edges

    def _peer_edges(self) -> List[Tuple[str, str]]:
        # Deterministic ordered pairs, excluding self.
        agents = list(self._agents)
        edges: List[Tuple[str, str]] = []
        for s in agents:
            for r in agents:
                if s != r:
                    edges.append((s, r))
        return edges

    def _supervisor_edges(self) -> List[Tuple[str, str]]:
        # Supervisor<->AgentX alternating: Sup->A0, A0->Sup, Sup->A1, A1->Sup, ...
        agents = [a for a in self._agents if a != "Supervisor"]
        if not agents:
            # Only Supervisor exists -> self-loop.
            return [("Supervisor", "Supervisor")]

        edges: List[Tuple[str, str]] = []
        for a in agents:
            edges.append(("Supervisor", a))
            edges.append((a, "Supervisor"))
        return edges