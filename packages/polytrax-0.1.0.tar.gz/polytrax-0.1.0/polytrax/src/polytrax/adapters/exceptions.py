# polytrax/src/polytrax/adapters/exceptions.py
"""
Adapter exceptions.

Adapters are runtime integration layers. These exceptions provide a small,
stable surface for control/attachment errors without depending on any runtime.
"""


class AdapterError(Exception):
    """Base class for all adapter-related errors."""


class AdapterNotAttachedError(AdapterError):
    """Raised when an adapter operation requires attach() but the adapter is not attached."""


class AdapterControlError(AdapterError):
    """Raised when an adapter cannot complete a requested control action (halt/gate/etc.)."""