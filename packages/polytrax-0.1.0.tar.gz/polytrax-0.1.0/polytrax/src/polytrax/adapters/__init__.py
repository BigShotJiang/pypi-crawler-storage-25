# polytrax/src/polytrax/adapters/__init__.py
"""
polytrax.adapters — runtime adapter contracts and integrations.

- RuntimeAdapter: abstract contract for runtime integrations.
- GenericAdapter: in-process adapter for tests/demos (no runtime dependencies).
- LangGraphAdapter: optional adapter for LangGraph workflows (requires langgraph).
"""

from .base import RuntimeAdapter
from .generic import GenericAdapter
from .exceptions import AdapterError, AdapterNotAttachedError, AdapterControlError

# LangGraphAdapter is optional; langgraph may not be installed.
try:
    from .langgraph import LangGraphAdapter
except Exception:  # pragma: no cover
    LangGraphAdapter = None  # type: ignore[assignment,misc]

__all__ = [
    "RuntimeAdapter",
    "GenericAdapter",
    "LangGraphAdapter",
    "AdapterError",
    "AdapterNotAttachedError",
    "AdapterControlError",
]