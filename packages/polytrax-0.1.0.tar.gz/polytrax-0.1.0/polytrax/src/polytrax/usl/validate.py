"""USL event validation.

Every event must satisfy a small set of structural invariants before
it is persisted or transmitted.  The functions here enforce those rules
and raise :class:`ValueError` with a human-readable message on any
violation.

Trust is *optional* — an event without a ``trust`` key is valid.
When ``trust`` is present it must be a well-formed dict whose
sub-keys (if any) are JSON-serialisable.
"""

from __future__ import annotations

import json
from typing import Iterable

from .schema import REQUIRED_FIELDS, TRUST_KEYS, USL_VERSION

# ── single-event validation ────────────────────────────────────────


def validate_event(event: dict, *, allow_empty: bool = False) -> None:
    """Validate *event* against the USL schema.

    Parameters
    ----------
    event:
        The candidate event dictionary.
    allow_empty:
        When ``True``, string fields (``run_id``, ``sender``,
        ``receiver``, ``event_id``, ``ts``, ``event_type``) are
        allowed to be empty.  This is useful for validating a freshly
        created template before the caller has filled in the
        context-specific values.

    Raises
    ------
    ValueError
        If any schema rule is violated.
    """
    # 1. Must be a dict
    if not isinstance(event, dict):
        raise ValueError(f"Event must be a dict, got {type(event).__name__}")

    # 2. All required fields present
    missing = REQUIRED_FIELDS - event.keys()
    if missing:
        raise ValueError(f"Missing required fields: {sorted(missing)}")

    # 3. usl_version must match
    if event["usl_version"] != USL_VERSION:
        raise ValueError(
            f"usl_version must be {USL_VERSION!r}, "
            f"got {event['usl_version']!r}"
        )

    # 4. String fields
    _str_fields = ("run_id", "event_id", "sender", "receiver", "ts", "event_type")
    for field in _str_fields:
        value = event[field]
        if not isinstance(value, str):
            raise ValueError(
                f"{field!r} must be a str, got {type(value).__name__}"
            )
        if not allow_empty and value == "":
            raise ValueError(f"{field!r} must be a non-empty str")

    # 5. hop_index
    if not isinstance(event["hop_index"], int):
        raise ValueError(
            f"'hop_index' must be an int, got "
            f"{type(event['hop_index']).__name__}"
        )
    if event["hop_index"] < 0:
        raise ValueError(
            f"'hop_index' must be >= 0, got {event['hop_index']}"
        )

    # 6. payload
    if not isinstance(event["payload"], dict):
        raise ValueError(
            f"'payload' must be a dict, got "
            f"{type(event['payload']).__name__}"
        )

    # 7. trust (optional — only validated when present)
    if "trust" in event:
        trust = event["trust"]
        if not isinstance(trust, dict):
            raise ValueError(
                f"'trust' must be a dict, got {type(trust).__name__}"
            )
        for key in TRUST_KEYS:
            if key in trust:
                # Sub-value must be JSON-serialisable on its own
                try:
                    json.dumps(trust[key], ensure_ascii=False)
                except (TypeError, ValueError, OverflowError) as exc:
                    raise ValueError(
                        f"'trust.{key}' is not JSON-serialisable: {exc}"
                    ) from exc

    # 8. Full event must be JSON-serialisable
    try:
        json.dumps(event, ensure_ascii=False)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"Event is not JSON-serialisable: {exc}") from exc


# ── trace validation ───────────────────────────────────────────────


def validate_trace(
    events: Iterable[dict], *, allow_empty: bool = False
) -> None:
    """Validate every event in an iterable sequence.

    Raises :class:`ValueError` on the first invalid event, annotated
    with the event's position in the trace.
    """
    for idx, event in enumerate(events):
        try:
            validate_event(event, allow_empty=allow_empty)
        except ValueError as exc:
            raise ValueError(f"Trace event [{idx}]: {exc}") from exc
