"""USL schema definitions and event-template factory.

USL (Universal Structured Logs) defines the canonical envelope for
message-level multi-agent communication.  Every event that travels
between agents is a plain ``dict`` that conforms to the schema
described here.

Trust is an *optional annotation layer* — it may be absent at event
creation time and enriched later (inline or post-hoc).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

# ── version & field catalogue ──────────────────────────────────────

USL_VERSION: str = "1.0"

REQUIRED_FIELDS: set[str] = {
    "usl_version",
    "run_id",
    "event_id",
    "ts",
    "sender",
    "receiver",
    "hop_index",
    "event_type",
    "payload",
}

TRUST_KEYS: tuple[str, ...] = ("constraints", "evidence", "provenance")

# ── helpers ────────────────────────────────────────────────────────


def new_event_id() -> str:
    """Return a fresh UUID-4 string suitable for ``event_id``."""
    return str(uuid.uuid4())


def now_ts() -> str:
    """Return the current UTC time as an ISO-8601 string ending with ``Z``."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def empty_trust() -> Dict[str, Any]:
    """Return a minimal trust annotation with all sub-keys empty.

    Useful when the caller wants to attach a trust block explicitly but
    has no constraints, evidence, or provenance to record yet.
    """
    return {
        "constraints": {},
        "evidence": {},
        "provenance": {},
    }


# ── template & builder ────────────────────────────────────────────


def default_event_template(*, include_trust: bool = False) -> Dict[str, Any]:
    """Return a new event ``dict`` pre-filled with sensible defaults.

    All :data:`REQUIRED_FIELDS` are present.  String fields that depend
    on the caller (``run_id``, ``sender``, ``receiver``, ``event_type``)
    are set to the empty string so they can be filled in later.

    Parameters
    ----------
    include_trust:
        If ``True`` an empty trust annotation is included.  By default
        trust is omitted, reflecting USL's trust-optional model.
    """
    event: Dict[str, Any] = {
        "usl_version": USL_VERSION,
        "run_id": "",
        "event_id": new_event_id(),
        "ts": now_ts(),
        "sender": "",
        "receiver": "",
        "hop_index": 0,
        "event_type": "",
        "payload": {},
    }
    if include_trust:
        event["trust"] = empty_trust()
    return event


def build_event(
    run_id: str,
    sender: str,
    receiver: str,
    hop_index: int,
    event_type: str,
    payload: Dict[str, Any],
    *,
    trust: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Create a fully-populated USL event ready for validation and I/O.

    Parameters
    ----------
    run_id:
        Identifier for the current run / session.
    sender:
        Agent or component that produced this event.
    receiver:
        Intended recipient agent or component.
    hop_index:
        Monotonically-increasing hop counter (``>= 0``).
    event_type:
        Free-form string describing the kind of event (e.g.
        ``"message"``, ``"tool_call"``, ``"observation"``).
    payload:
        Arbitrary JSON-serialisable dict with event-specific data.
    trust:
        Optional trust annotation dict.  When ``None`` (default) the
        event is created without a trust block.
    """
    event: Dict[str, Any] = {
        "usl_version": USL_VERSION,
        "run_id": run_id,
        "event_id": new_event_id(),
        "ts": now_ts(),
        "sender": sender,
        "receiver": receiver,
        "hop_index": hop_index,
        "event_type": event_type,
        "payload": payload,
    }
    if trust is not None:
        event["trust"] = trust
    return event
