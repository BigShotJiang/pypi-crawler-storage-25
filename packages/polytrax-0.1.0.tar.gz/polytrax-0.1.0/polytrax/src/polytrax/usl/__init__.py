"""polytrax.usl — Universal Structured Logs.

Public API re-exports so callers can write::

    from polytrax.usl import validate_event, write_jsonl, build_event
"""

from .schema import (
    REQUIRED_FIELDS,
    TRUST_KEYS,
    USL_VERSION,
    build_event,
    default_event_template,
    empty_trust,
    new_event_id,
    now_ts,
)
from .validate import validate_event, validate_trace
from .io import iter_jsonl, read_jsonl, write_jsonl

__all__ = [
    # schema
    "USL_VERSION",
    "REQUIRED_FIELDS",
    "TRUST_KEYS",
    "new_event_id",
    "now_ts",
    "empty_trust",
    "default_event_template",
    "build_event",
    # validate
    "validate_event",
    "validate_trace",
    # io
    "write_jsonl",
    "read_jsonl",
    "iter_jsonl",
]
