"""USL JSONL I/O — write and read one-event-per-line log files."""

from __future__ import annotations

import json
import pathlib
from typing import Iterator, Union

from .validate import validate_event

# ── write ──────────────────────────────────────────────────────────


def write_jsonl(
    path: Union[str, pathlib.Path],
    event: dict,
    *,
    append: bool = True,
) -> None:
    """Persist *event* as a single JSON line in *path*.

    Parameters
    ----------
    path:
        Destination file.  Parent directories are created if needed.
    event:
        A USL event dict.  It is validated before writing.
    append:
        If ``True`` (default) the line is appended; otherwise the file
        is overwritten.
    """
    validate_event(event)

    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    mode = "a" if append else "w"
    line = json.dumps(event, ensure_ascii=False)

    with path.open(mode, encoding="utf-8") as fh:
        fh.write(line + "\n")


# ── read ───────────────────────────────────────────────────────────


def read_jsonl(
    path: Union[str, pathlib.Path],
    *,
    validate: bool = True,
) -> Iterator[dict]:
    """Yield USL event dicts from a JSONL file.

    Parameters
    ----------
    path:
        Source file (must exist).
    validate:
        If ``True`` (default) each event is validated after parsing.
    """
    path = pathlib.Path(path)

    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            stripped = line.strip()
            if not stripped:
                continue
            event = json.loads(stripped)
            if validate:
                validate_event(event)
            yield event


# convenience alias
iter_jsonl = read_jsonl
