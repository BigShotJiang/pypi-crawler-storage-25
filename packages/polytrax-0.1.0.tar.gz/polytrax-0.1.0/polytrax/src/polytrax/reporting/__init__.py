# polytrax/src/polytrax/reporting/__init__.py
"""
polytrax.reporting — run-level report generation.

Re-exports the public API so callers can write::

    from polytrax.reporting import generate_run_report, RunReport
"""

from .report import RunReport, generate_run_report

__all__ = [
    "RunReport",
    "generate_run_report",
]
