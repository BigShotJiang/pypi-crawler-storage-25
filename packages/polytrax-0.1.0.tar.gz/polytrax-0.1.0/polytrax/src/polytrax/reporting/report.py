# polytrax/src/polytrax/reporting/report.py
"""
polytrax.reporting — deterministic run-level report generation.

Orchestrates existing analysis modules to produce a single consolidated
RunReport from a completed trace (list of USL events or JSONL path).

This module does NOT:
- Perform runtime control
- Modify trace contents
- Recompute logic outside analysis modules
- Introduce new algorithms
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional

from polytrax.usl import read_jsonl
from polytrax.analysis.graph import build_graph
from polytrax.analysis.propagation import (
    compute_run_metrics,
    find_violation_edges,
    first_violation_hop,
    graph_stats,
)
from polytrax.analysis.tps_replay import compute_o_tps
from polytrax.analysis.containment import apply_halt, containment_effectiveness


@dataclass
class RunReport:
    """Consolidated run-level report for a completed trace."""

    run_id: str
    node_count: int
    edge_count: int
    max_hop: int

    propagation_metrics: dict
    tps: dict
    containment: dict
    metadata: dict

    def to_dict(self) -> dict:
        """Return a deterministic, JSON-serialisable dictionary."""
        return {
            "run_id": self.run_id,
            "graph": {
                "node_count": self.node_count,
                "edge_count": self.edge_count,
                "max_hop": self.max_hop,
            },
            "propagation": dict(self.propagation_metrics),
            "offline_tps": dict(self.tps),
            "containment": dict(self.containment),
            "metadata": dict(self.metadata),
        }

    def to_json(self, indent: int = 2) -> str:
        """Serialise to a deterministic JSON string."""
        return json.dumps(self.to_dict(), indent=indent, sort_keys=False)


# ── helpers ──────────────────────────────────────────────────────────


def _count_message_events(events: List[dict]) -> int:
    """Count message events (message_sent + message_blocked)."""
    return sum(
        1
        for ev in events
        if isinstance(ev, dict)
        and ev.get("event_type") in {"message_sent", "message_blocked"}
    )


def _build_tps_dict(tps_output: object) -> dict:
    """Map an OfflineTPSOutput to the report's offline_tps section."""
    # Note: We include both current (standard) and legacy (corpus/frontend) names
    # to maintain backward compatibility while fixing live run rendering.
    out = {
        "score": getattr(tps_output, "trust_risk_score"),
        "trust_risk_score": getattr(tps_output, "trust_risk_score"),  # Legacy/Corpus
        "risk_class": getattr(tps_output, "risk_class"),
        "recommended_action": getattr(tps_output, "recommended_action"),
        "primary_metrics": {},
        "components": {},  # Legacy/Corpus
        "semantic_observation": getattr(tps_output, "components", {}).get("semantic_observation"),
        "legacy_metrics": {},
    }
    comps = getattr(tps_output, "components", {})
    
    # Extract primary metrics (VR, CS, DP, SV, IM)
    for k in ["violation_rate", "cascade_spread", "propagation_depth", "severity", "impact"]:
        if k in comps:
            out["primary_metrics"][k] = comps[k]
            out["components"][k] = comps[k]  # Legacy/Corpus
    
    # Ensure score_raw is in components (required by frontend metrics tab)
    if "score_raw" in comps:
        out["components"]["score_raw"] = comps["score_raw"]

    # Extract legacy metrics
    if "legacy" in comps:
        out["legacy_metrics"] = comps["legacy"]
        
    return out


def _build_containment(
    events: List[dict],
    original_metrics: dict,
    original_o_tps: object,
    halt_at_hop: Optional[int],
) -> dict:
    """Compute containment section.  Returns {} if no violations exist."""
    fvh = original_metrics.get("first_violation_hop")
    if fvh is None:
        # No violations → empty containment
        return {}

    effective_halt = halt_at_hop if halt_at_hop is not None else fvh

    halted_events = apply_halt(events, effective_halt)
    halted_graph = build_graph(halted_events)
    halted_metrics = compute_run_metrics(halted_graph)
    
    # Recompute O-TPS for halted trace
    halted_tps = compute_o_tps(halted_events)

    eff = containment_effectiveness(
        original_metrics, 
        halted_metrics,
        original_o_tps=getattr(original_o_tps, "trust_risk_score"),
        contained_o_tps=halted_tps.trust_risk_score
    )

    return {
        "halt_at_hop": effective_halt,
        "halted_metrics": halted_metrics,
        "original_o_tps": eff.get("original_o_tps"),
        "replay_o_tps": eff.get("replay_o_tps"),
        "o_tps_reduction": eff.get("o_tps_reduction"),
        "reach_reduction": eff.get("reach_reduction"),
        "depth_reduction": eff.get("depth_reduction"),
        "vpr_reduction": eff.get("vpr_reduction"),
    }


# ── public API ───────────────────────────────────────────────────────


def generate_run_report(
    events: Optional[Iterable[dict]] = None,
    jsonl_path: Optional[str] = None,
    include_containment: bool = True,
    halt_at_hop: Optional[int] = None,
) -> RunReport:
    """Generate a deterministic run-level report from a completed trace.

    Parameters
    ----------
    events:
        Iterable of USL event dicts.  Mutually exclusive with *jsonl_path*.
    jsonl_path:
        Path to a JSONL file of USL events.  Mutually exclusive with *events*.
    include_containment:
        If ``True`` (default), compute containment replay analysis.
    halt_at_hop:
        Hop index for the halt simulation.  Defaults to
        ``first_violation_hop`` when omitted.

    Returns
    -------
    RunReport
        Consolidated report dataclass.

    Raises
    ------
    ValueError
        If neither or both of *events* / *jsonl_path* are provided.
    """
    # ── validate input ───────────────────────────────────────────────
    if (events is None) == (jsonl_path is None):
        raise ValueError(
            "Exactly one of 'events' or 'jsonl_path' must be provided."
        )

    # ── load & materialise events ────────────────────────────────────
    if jsonl_path is not None:
        event_list: List[dict] = list(read_jsonl(jsonl_path))
    else:
        event_list = list(events)  # type: ignore[arg-type]

    # ── extract run_id ───────────────────────────────────────────────
    run_id = ""
    if event_list:
        first = event_list[0]
        if isinstance(first, dict):
            rid = first.get("run_id")
            if isinstance(rid, str):
                run_id = rid

    # ── graph ────────────────────────────────────────────────────────
    graph = build_graph(event_list)
    stats = graph_stats(graph)

    # ── propagation metrics ──────────────────────────────────────────
    propagation_metrics = compute_run_metrics(graph)

    # ── offline TPS ──────────────────────────────────────────────────
    tps_output = compute_o_tps(event_list)
    tps_dict = _build_tps_dict(tps_output)

    # ── containment ──────────────────────────────────────────────────
    if include_containment:
        containment_dict = _build_containment(
            event_list, propagation_metrics, tps_output, halt_at_hop
        )
    else:
        containment_dict = {}

    # ── metadata ─────────────────────────────────────────────────────
    violation_edges = find_violation_edges(graph)
    metadata = {
        "total_events": len(event_list),
        "total_message_events": _count_message_events(event_list),
        "total_violation_events": len(violation_edges),
        "timestamp_generated": datetime.now(timezone.utc).isoformat(),
    }

    # ── assemble report ──────────────────────────────────────────────
    report = RunReport(
        run_id=run_id,
        node_count=stats["node_count"],
        edge_count=stats["edge_count"],
        max_hop=stats["max_hop"],
        propagation_metrics=propagation_metrics,
        tps=tps_dict,
        containment=containment_dict,
        metadata=metadata,
    )
    print(f"[POLYTRAX-AUDIT] generate_run_report | {__file__} | N/A | keys={list(report.to_dict().keys())} | otps_keys={list(report.to_dict().get('offline_tps', {}).keys())}")
    return report
