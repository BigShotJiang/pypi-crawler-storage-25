"""polytrax.sinks.memory — In-memory event sink.

Stores validated USL events in a plain Python list.  Useful for
testing, debugging, and short-lived pipelines where persistence is
not required.
"""

from __future__ import annotations

from typing import List, Optional

from polytrax.usl import validate_event

from .base import EventSink


class MemorySink(EventSink):
    """Keep USL events in memory.

    Parameters
    ----------
    max_events:
        Optional upper bound on stored events.  When set, only the
        most recent *max_events* are retained (older events are
        silently dropped).
    """

    def __init__(self, *, max_events: Optional[int] = None) -> None:
        self._events: List[dict] = []
        self._max_events = max_events

    # ── EventSink interface ─────────────────────────────────────────

    def write(self, event: dict) -> None:
        """Validate *event* and append it to the internal list.

        If *max_events* is set and the list exceeds that size, the
        oldest events are dropped to stay within the limit.
        """
        validate_event(event)
        self._events.append(event)

        if self._max_events is not None and len(self._events) > self._max_events:
            self._events = self._events[-self._max_events:]

    def flush(self) -> None:
        """No-op — in-memory storage requires no flushing."""

    def close(self) -> None:
        """No-op — no external resources to release."""

    # ── extra helpers ───────────────────────────────────────────────

    def get_events(self) -> List[dict]:
        """Return a shallow copy of the stored events."""
        return list(self._events)

    def clear(self) -> None:
        """Remove all stored events."""
        self._events.clear()
