"""polytrax.sinks.base — Sink interface and no-op implementation.

Sinks provide an interchangeable destination for validated USL events.
They are a pure storage / transport abstraction and must **not** contain
trust logic, TPS logic, or MAS runtime logic.

Every concrete sink implements :class:`EventSink` (an abstract base class)
and can be used as a context manager::

    with JsonlSink("events.jsonl") as sink:
        sink.write(event)
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class EventSink(ABC):
    """Abstract base class for all event sinks.

    Subclasses must implement :meth:`write`, :meth:`flush`, and
    :meth:`close`.  Context-manager support (``__enter__`` /
    ``__exit__``) is provided automatically.
    """

    # ── abstract interface ──────────────────────────────────────────

    @abstractmethod
    def write(self, event: dict) -> None:
        """Persist or transmit a single USL event."""

    @abstractmethod
    def flush(self) -> None:
        """Force any buffered data to its destination."""

    @abstractmethod
    def close(self) -> None:
        """Release resources held by this sink."""

    # ── context-manager support ─────────────────────────────────────

    def __enter__(self) -> "EventSink":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        self.close()


class NoopSink(EventSink):
    """A sink that silently discards every event.

    Useful for disabling logging without changing call-site code.
    """

    def write(self, event: dict) -> None:  # noqa: D102
        pass

    def flush(self) -> None:  # noqa: D102
        pass

    def close(self) -> None:  # noqa: D102
        pass
