"""polytrax.sinks — Interchangeable event-sink abstraction.

Sinks accept validated USL events and route them to a destination
(file, memory, network, …).  They are a pure storage / transport layer
and contain **no** trust, TPS, or MAS runtime logic.

Public API::

    from polytrax.sinks import EventSink, NoopSink, JsonlSink, MemorySink
"""

from .base import EventSink, NoopSink
from .jsonl import JsonlSink
from .memory import MemorySink

__all__ = [
    "EventSink",
    "NoopSink",
    "JsonlSink",
    "MemorySink",
]
