"""polytrax.sinks.jsonl — JSONL file sink.

Writes validated USL events as one JSON object per line (UTF-8,
``ensure_ascii=False``).  Parent directories are created automatically.
"""

from __future__ import annotations

import json
import pathlib
from typing import IO, Optional, Union

from polytrax.usl import validate_event

from .base import EventSink


class JsonlSink(EventSink):
    """Append (or overwrite) USL events to a ``.jsonl`` file.

    Parameters
    ----------
    path:
        Filesystem path for the output file.  Parent directories are
        created if they do not already exist.
    append:
        When ``True`` (default) new events are appended to an existing
        file.  When ``False`` the file is truncated on first open.
    flush_every:
        Number of :meth:`write` calls between automatic flushes.
        The default (``1``) flushes after every write.
    """

    def __init__(
        self,
        path: Union[str, pathlib.Path],
        *,
        append: bool = True,
        flush_every: int = 1,
    ) -> None:
        self._path = pathlib.Path(path)
        self._append = append
        self._flush_every = max(1, flush_every)

        self._fh: Optional[IO[str]] = None
        self._writes_since_flush: int = 0

    # ── lazy file open ──────────────────────────────────────────────

    def _ensure_open(self) -> IO[str]:
        """Open the file handle lazily on first write."""
        if self._fh is None:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            mode = "a" if self._append else "w"
            self._fh = open(self._path, mode=mode, encoding="utf-8")  # noqa: SIM115
        return self._fh

    # ── EventSink interface ─────────────────────────────────────────

    def write(self, event: dict) -> None:
        """Validate *event* and write it as a single JSON line.

        Raises :class:`ValueError` (via ``validate_event``) if the
        event is malformed; nothing is written in that case.
        """
        validate_event(event)

        fh = self._ensure_open()
        line = json.dumps(event, ensure_ascii=False)
        fh.write(line + "\n")

        self._writes_since_flush += 1
        if self._writes_since_flush >= self._flush_every:
            fh.flush()
            self._writes_since_flush = 0

    def flush(self) -> None:
        """Flush the underlying file handle if it is open."""
        if self._fh is not None:
            self._fh.flush()
            self._writes_since_flush = 0

    def close(self) -> None:
        """Close the file handle safely (idempotent)."""
        if self._fh is not None:
            try:
                self._fh.close()
            finally:
                self._fh = None
