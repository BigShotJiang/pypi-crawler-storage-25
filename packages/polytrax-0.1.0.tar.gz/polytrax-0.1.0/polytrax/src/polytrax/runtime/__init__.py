# polytrax/src/polytrax/runtime/__init__.py
"""
polytrax.runtime — runtime plane (R-TPS + runtime policy control).

This package contains:
- RuntimeTPS: streaming trust risk scoring (no offline replay)
- RuntimePolicy / PolicyConfig: confirmation-based intervention decisions
- RuntimeController: applies decisions via RuntimeAdapter hooks
- RuntimeAudit: in-memory auditable records
"""

from .types import TPSOutput, TPSComponents, RiskClass, InterventionType
from .tps import RuntimeTPS
from .policies import RuntimePolicy, PolicyConfig
from .controller import RuntimeController
from .audit import RuntimeAudit

__all__ = [
    "RuntimeTPS",
    "RuntimeController",
    "RuntimePolicy",
    "PolicyConfig",
    "RuntimeAudit",
    "TPSOutput",
    "TPSComponents",
    "RiskClass",
    "InterventionType",
]