# polytrax/src/polytrax/runtime/tps.py
"""
RuntimeTPS (R-TPS): streaming trust risk scoring.

Consumes streaming USL events and produces a deterministic risk score in [0,1].
Scoring is grounded in C/E/P when trust annotations exist, but does not require them.
No ML, no external libs, no graph reconstruction.
"""

from __future__ import annotations

from collections import deque
from typing import Deque, Dict, Optional, Set, Tuple, Any

from .types import TPSComponents, TPSOutput, RiskClass, InterventionType


def _clamp01(x: float) -> float:
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return float(x)


def _status_to_severity(status: str) -> float:
    m = {"ok": 0.0, "warn": 0.5, "fail": 1.0}
    return float(m.get(status, 0.0))


def _dim_severity(dim_val: Any) -> float:
    """
    Extract severity from a dimension expressed as:
      - {"severity": float in [0,1]}, OR
      - {"status": "ok"|"warn"|"fail"}
    Missing/invalid -> 0.0
    """
    if not isinstance(dim_val, dict):
        return 0.0
    if "severity" in dim_val:
        try:
            return _clamp01(float(dim_val["severity"]))
        except Exception:
            return 0.0
    if "status" in dim_val:
        try:
            return _clamp01(_status_to_severity(str(dim_val["status"]).lower()))
        except Exception:
            return 0.0
    return 0.0


class RuntimeTPS:
    """
    Streaming risk scorer.

    update(event) ingests one USL event.
    score() returns TPSOutput based on the accumulated stream state.
    """

    def __init__(
        self,
        *,
        window_size: int = 10,
        w_freq: float = 0.25,
        w_persist: float = 0.25,
        w_spread: float = 0.20,
        w_early: float = 0.15,
        w_severity: float = 0.15,
        severity_weights: Optional[Dict[str, float]] = None,
        early_lambda: float = 0.5,
        streak_cap: int = 5,
    ) -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        if streak_cap <= 0:
            raise ValueError("streak_cap must be > 0")

        self.window_size = int(window_size)
        self.w_freq = float(w_freq)
        self.w_persist = float(w_persist)
        self.w_spread = float(w_spread)
        self.w_early = float(w_early)
        self.w_severity = float(w_severity)
        self.severity_weights = severity_weights or {
            "constraints": 0.33,
            "evidence": 0.33,
            "provenance": 0.34,
        }
        self.early_lambda = float(early_lambda)
        self.streak_cap = int(streak_cap)

        # Streaming state
        self.event_count: int = 0
        self.violation_count: int = 0
        self.last_event_id: Optional[str] = None
        self.max_hop_seen: int = 0
        self.first_violation_hop: Optional[int] = None
        self.consecutive_violation_streak: int = 0

        self._window: Deque[float] = deque(maxlen=self.window_size)
        self.edges_seen: Set[Tuple[str, str]] = set()
        self.violation_edges: Set[Tuple[str, str]] = set()

        self.sum_severity: float = 0.0
        self.count_severity: int = 0

    def _extract_severity_and_violation(self, event: dict) -> Tuple[float, int]:
        event_type = event.get("event_type")

        # Strong signal: message blocked
        if event_type == "message_blocked":
            s = 1.0
            return s, 1

        trust = event.get("trust")
        if isinstance(trust, dict):
            c = _dim_severity(trust.get("constraints"))
            e = _dim_severity(trust.get("evidence"))
            p = _dim_severity(trust.get("provenance"))

            wc = float(self.severity_weights.get("constraints", 0.0))
            we = float(self.severity_weights.get("evidence", 0.0))
            wp = float(self.severity_weights.get("provenance", 0.0))

            s = _clamp01((wc * c) + (we * e) + (wp * p))
            return s, 1 if s > 0.0 else 0

        return 0.0, 0

    def update(self, event: dict) -> None:
        """Ingest one USL event dict (streaming)."""
        self.event_count += 1

        eid = event.get("event_id")
        if isinstance(eid, str):
            self.last_event_id = eid
        else:
            # Keep last_event_id unchanged if missing/invalid
            pass

        hop = event.get("hop_index")
        if isinstance(hop, int):
            if hop > self.max_hop_seen:
                self.max_hop_seen = hop

        event_type = event.get("event_type")
        sender = event.get("sender")
        receiver = event.get("receiver")

        if event_type in {"message_sent", "message_blocked"} and isinstance(sender, str) and isinstance(receiver, str):
            self.edges_seen.add((sender, receiver))

        s, v = self._extract_severity_and_violation(event)

        if v:
            self.violation_count += 1
            if self.first_violation_hop is None:
                if isinstance(hop, int):
                    self.first_violation_hop = hop
                else:
                    self.first_violation_hop = 0

            self.consecutive_violation_streak += 1
            self._window.append(float(s))

            if isinstance(sender, str) and isinstance(receiver, str):
                self.violation_edges.add((sender, receiver))

            self.sum_severity += float(s)
            self.count_severity += 1
        else:
            self.consecutive_violation_streak = 0
            self._window.append(0.0)

    def score(self) -> TPSOutput:
        """Compute current TPSOutput from streaming state."""
        event_count = max(self.event_count, 1)
        freq = float(self.violation_count) / float(event_count)

        window_len = len(self._window) if len(self._window) > 0 else 1
        window_viol = sum(1 for x in self._window if x > 0.0)
        window_density = float(window_viol) / float(window_len)

        streak_term = min(float(self.consecutive_violation_streak) / float(self.streak_cap), 1.0)
        persistence = _clamp01((0.6 * streak_term) + (0.4 * window_density))

        if self.edges_seen:
            spread = float(len(self.violation_edges)) / float(len(self.edges_seen))
        else:
            spread = 0.0

        if self.first_violation_hop is None:
            early = 0.0
        else:
            early = min(self.early_lambda * (1.0 / float(self.first_violation_hop + 1)), self.early_lambda)
        early = _clamp01(float(early))

        if self.count_severity > 0:
            severity = float(self.sum_severity) / float(self.count_severity)
        else:
            severity = 0.0
        severity = _clamp01(severity)

        raw = (
            (self.w_freq * freq)
            + (self.w_persist * persistence)
            + (self.w_spread * spread)
            + (self.w_early * early)
            + (self.w_severity * severity)
        )
        trust_risk_score = _clamp01(raw)

        if trust_risk_score < 0.30:
            risk_class = RiskClass.LOW
            recommended = InterventionType.NO_ACTION
        elif trust_risk_score < 0.65:
            risk_class = RiskClass.MEDIUM
            recommended = InterventionType.SELECTIVE_GATE
        else:
            risk_class = RiskClass.HIGH
            recommended = InterventionType.HALT

        reasons = [
            f"freq: {self.violation_count}/{self.event_count} events flagged ({freq:.3f})",
            f"persistence: streak={self.consecutive_violation_streak} (cap={self.streak_cap}) "
            f"window={window_viol}/{window_len} -> {persistence:.3f}",
            f"spread: violation_edges={len(self.violation_edges)}/{len(self.edges_seen)} -> {spread:.3f}",
            f"early: first_violation_hop={self.first_violation_hop} -> {early:.3f}",
            f"avg_severity: {severity:.3f} (n={self.count_severity})",
            f"score: {trust_risk_score:.3f} class={risk_class.value} recommended={recommended.value}",
        ]

        comps = TPSComponents(
            freq=_clamp01(freq),
            persistence=_clamp01(persistence),
            spread=_clamp01(spread),
            early=_clamp01(early),
            severity=_clamp01(severity),
        )
        
        print(f"[POLYTRAX-TRUTH] R-TPS_PATH | score={trust_risk_score:.4f} | action={recommended.value} | violations={self.violation_count} | reason={reasons[-1]}")

        return TPSOutput(
            trust_risk_score=trust_risk_score,
            risk_class=risk_class,
            recommended_action=recommended,
            reasons=reasons,
            last_event_id=self.last_event_id,
            first_violation_hop=self.first_violation_hop,
            components=comps,
            event_count=self.event_count,
            violation_count=self.violation_count,
        )