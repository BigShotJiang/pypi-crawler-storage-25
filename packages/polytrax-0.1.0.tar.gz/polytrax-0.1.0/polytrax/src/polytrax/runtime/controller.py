# polytrax/src/polytrax/runtime/controller.py
"""
RuntimeController: wiring for R-TPS -> policy -> adapter controls -> audit.

Consumes events one-by-one (streaming). On each event:
- update TPS state
- compute score
- decide intervention using confirmation policy
- apply adapter control hooks (gate/halt) conservatively
- record auditable decision
"""

from __future__ import annotations

from typing import Optional

from polytrax.adapters import RuntimeAdapter

from .audit import RuntimeAudit
from .policies import RuntimePolicy
from .tps import RuntimeTPS
from .types import InterventionType, TPSOutput


class RuntimeController:
    def __init__(
        self,
        adapter: RuntimeAdapter,
        *,
        tps: Optional[RuntimeTPS] = None,
        policy: Optional[RuntimePolicy] = None,
        audit: Optional[RuntimeAudit] = None,
    ) -> None:
        self._adapter = adapter
        self._tps = tps or RuntimeTPS()
        self._policy = policy or RuntimePolicy()
        self._audit = audit or RuntimeAudit()

    @property
    def tps(self) -> RuntimeTPS:
        return self._tps

    @property
    def policy(self) -> RuntimePolicy:
        return self._policy

    @property
    def audit(self) -> RuntimeAudit:
        return self._audit

    def on_event(self, event: dict) -> TPSOutput:
        self._tps.update(event)
        out = self._tps.score()

        action = self._policy.decide(out)

        if action == InterventionType.HALT:
            self._adapter.halt_run("TPS threshold confirmed")
        elif action == InterventionType.SELECTIVE_GATE:
            sender = event.get("sender")
            receiver = event.get("receiver")
            if isinstance(sender, str) and isinstance(receiver, str):
                self._adapter.gate_message(sender, receiver, reason="TPS gate")

        self._audit.record(out, action)
        return out