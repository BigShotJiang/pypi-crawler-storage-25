# polytrax/src/polytrax/runtime/audit.py
"""
RuntimeAudit: in-memory audit log of TPS decisions.

No file IO; caller can export/serialize later if needed.
"""

from __future__ import annotations

from typing import Dict, List

from .types import InterventionType, TPSOutput


class RuntimeAudit:
    """Stores auditable decision records as a list of dicts."""

    def __init__(self) -> None:
        self._records: List[Dict] = []

    def record(self, output: TPSOutput, action: InterventionType) -> None:
        self._records.append(
            {
                "event_id": output.last_event_id,
                "score": float(output.trust_risk_score),
                "risk_class": output.risk_class.value,
                "action": action.value,
                "reasons": list(output.reasons),
            }
        )

    def get_records(self) -> List[Dict]:
        return list(self._records)

    def clear(self) -> None:
        self._records.clear()