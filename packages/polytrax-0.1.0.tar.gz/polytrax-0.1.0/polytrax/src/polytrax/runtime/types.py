# polytrax/src/polytrax/runtime/types.py
"""
Runtime plane types for PolyTrax (R-TPS + policy control).

These types are intentionally small and stable. They support deterministic,
explainable, streaming risk scoring and intervention decisions.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class RiskClass(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class InterventionType(str, Enum):
    NO_ACTION = "no_action"
    SELECTIVE_GATE = "selective_gate"
    HALT = "halt"


@dataclass(frozen=True)
class TPSComponents:
    freq: float
    persistence: float
    spread: float
    early: float
    severity: float


@dataclass(frozen=True)
class TPSOutput:
    trust_risk_score: float
    risk_class: RiskClass
    recommended_action: InterventionType
    reasons: List[str]
    last_event_id: Optional[str]
    first_violation_hop: Optional[int]
    components: TPSComponents
    event_count: int
    violation_count: int