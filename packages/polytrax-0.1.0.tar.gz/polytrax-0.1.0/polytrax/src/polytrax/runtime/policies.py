# polytrax/src/polytrax/runtime/policies.py
"""
RuntimePolicy: conservative confirmation logic for interventions.

This policy layer reduces false alarms by requiring a confirmed number of
consecutive threshold breaches before applying runtime controls.
"""

from __future__ import annotations

from dataclasses import dataclass

from .types import InterventionType, TPSOutput


@dataclass
class PolicyConfig:
    gate_threshold: float = 0.30
    halt_threshold: float = 0.65
    confirm_events: int = 3
    min_events_before_action: int = 5
    allow_gate: bool = True
    allow_halt: bool = True


class RuntimePolicy:
    """
    Confirmation-based policy.

    Counters increment when score crosses thresholds; otherwise they reset.
    Actions are only taken when confirmed for `confirm_events` consecutive decisions.
    """

    def __init__(self, config: PolicyConfig | None = None) -> None:
        self.config = config or PolicyConfig()
        self.consecutive_gate: int = 0
        self.consecutive_halt: int = 0

    def decide(self, tps_out: TPSOutput) -> InterventionType:
        cfg = self.config

        if tps_out.event_count < cfg.min_events_before_action:
            # Do not build confirmation streaks before minimum sample size.
            self.consecutive_gate = 0
            self.consecutive_halt = 0
            return InterventionType.NO_ACTION

        score = float(tps_out.trust_risk_score)

        if score >= cfg.halt_threshold:
            self.consecutive_halt += 1
        else:
            self.consecutive_halt = 0

        if score >= cfg.gate_threshold:
            self.consecutive_gate += 1
        else:
            self.consecutive_gate = 0

        if cfg.allow_halt and self.consecutive_halt >= cfg.confirm_events:
            return InterventionType.HALT

        if cfg.allow_gate and self.consecutive_gate >= cfg.confirm_events:
            return InterventionType.SELECTIVE_GATE

        return InterventionType.NO_ACTION