# PolyTrax

PolyTrax is a Python library for communication-level observability, runtime trust control, and post-run analysis in multi-agent systems.

It provides:

- Universal Structured Log (USL) schema and validation
- Event instrumentation utilities and sinks
- Runtime Trust Perturbation Score (R-TPS) monitoring and intervention policies
- Offline propagation and containment analysis
- Evaluation tooling (deterministic and LLM-based judges)

## Install

Core library:

```bash
pip install polytrax
```

With optional integrations:

```bash
pip install "polytrax[openai]"      # LLM judge via OpenAI-compatible APIs
pip install "polytrax[langgraph]"   # LangGraph adapter
pip install "polytrax[semantic]"    # Semantic drift/localization extras
pip install "polytrax[full]"        # All optional dependencies
```

## Quick Example

```python
from polytrax.instrumentation import Instrumentor, EventBuilder
from polytrax.sinks import MemorySink

sink = MemorySink()
instr = Instrumentor(run_id="demo_run", sinks=[sink])
builder = EventBuilder(run_id="demo_run")

event = (
    builder
    .with_sender("collector_1")
    .with_receiver("analyst_1")
    .with_payload({"message": "hello"})
    .build()
)

instr.emit(event)
print(len(sink.events))
```

## CLI

Evaluation runner:

```bash
polytrax-eval --runs-dir ./runs --output-filename eval.json
```

## Project Layout

- Publishable library package: `polytrax/src/polytrax`
- Demo frontend/backend app (not packaged): `apps/polytrax_demo`
- Evaluation protocols and scripts: `evaluation`

## License

MIT
