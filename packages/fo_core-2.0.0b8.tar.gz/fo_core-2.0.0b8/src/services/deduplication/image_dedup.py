# pyre-ignore-all-errors
"""Image deduplication module using perceptual hashing.

Provides ImageDeduplicator class with support for pHash, dHash, and aHash
algorithms for detecting visually similar images. Uses the imagededup library
for efficient perceptual hashing and Hamming distance calculations.
"""

from __future__ import annotations

import logging
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Literal

try:
    from imagededup.methods import AHash, DHash, PHash  # pyre-ignore[21]

    _IMAGEDEDUP_AVAILABLE = True
except ImportError:
    AHash = DHash = PHash = None
    _IMAGEDEDUP_AVAILABLE = False

# imagededup is not packaged for Python ≥ 3.14 (upstream has not released a
# compatible wheel).  We detect this early so the error message is actionable.
_PY314_PLUS = sys.version_info >= (3, 14)

try:
    import numpy as np

    _NUMPY_AVAILABLE = True
except ImportError:  # pragma: no cover - numpy is optional (fo-core[search]/[dedup-image])
    # The ignore is only emitted when numpy IS resolvable (then mypy sees a
    # type clash with the inferred Module).  When numpy is absent (the
    # type-check job's [dev] env), mypy follows the ImportError branch and
    # the ignore would otherwise be flagged "unused-ignore".  Suppress both.
    np = None  # type: ignore[assignment,unused-ignore]
    _NUMPY_AVAILABLE = False

from PIL.Image import (  # noqa: E402
    DecompressionBombError,
)

from .image_utils import SUPPORTED_FORMATS, safedir_image_open  # noqa: E402

logger = logging.getLogger(__name__)

# Supported hash algorithms
HashMethod = Literal["phash", "dhash", "ahash"]


class ImageDeduplicator:
    """Detects duplicate and visually similar images using perceptual hashing.

    Uses imagededup library for computing perceptual hashes and comparing
    images based on visual similarity rather than exact byte matches.

    Supported algorithms:
    - pHash (Perceptual Hash): Best for general similarity detection
    - dHash (Difference Hash): Fast, good for detecting resized images
    - aHash (Average Hash): Fastest, good for exact duplicates

    Attributes:
        hash_method: Hash algorithm to use
        threshold: Maximum Hamming distance for similarity (0-64)
        hasher: Initialized hash computation object
    """

    def __init__(self, hash_method: HashMethod = "phash", threshold: int = 10):
        """Initialize the ImageDeduplicator.

        Args:
            hash_method: Hash algorithm ("phash", "dhash", or "ahash")
            threshold: Maximum Hamming distance for images to be considered
                      similar. Lower values = more strict matching.
                      - 0: Exact match only
                      - 1-5: Very similar (minor compression/edits)
                      - 6-10: Similar (resized, color adjusted)
                      - 11-20: Somewhat similar (cropped, filtered)
                      - 21+: Potentially different images

        Raises:
            ImportError: If imagededup is not installed.
                Install with: ``pip install 'fo-core[dedup-image]'``
            ValueError: If hash_method is not supported or threshold is invalid
        """
        if not _IMAGEDEDUP_AVAILABLE:
            if _PY314_PLUS:  # pragma: no cover — CI runs on Python 3.11
                raise ImportError(
                    "imagededup does not yet support Python 3.14+. "
                    "Image deduplication is unavailable on this Python version."
                )
            raise ImportError(
                "imagededup is required for image deduplication. "
                "Install it with: pip install 'fo-core[dedup-image]'"
            )

        if hash_method not in ("phash", "dhash", "ahash"):
            raise ValueError(
                f"Unsupported hash method: {hash_method}. Use 'phash', 'dhash', or 'ahash'."
            )

        if not 0 <= threshold <= 64:
            raise ValueError(f"Threshold must be between 0 and 64, got {threshold}")

        self.hash_method = hash_method
        self.threshold = threshold

        # Initialize hasher based on method
        if hash_method == "phash":
            self.hasher = PHash()
        elif hash_method == "dhash":
            self.hasher = DHash()
        else:  # ahash
            self.hasher = AHash()

    def get_image_hash(self, image_path: Path, *, trusted_root: Path | None = None) -> str | None:
        """Compute perceptual hash for a single image.

        Routes the image read through :func:`safedir_image_open` so a
        symlinked image is refused at every path component when
        ``trusted_root`` is supplied (closes the dedup-ingestion
        symlink-exfiltration vector, #264). The PIL Image is converted
        to a numpy array and handed to ``imagededup``'s
        ``encode_image(image_array=...)`` API — bypassing the path-based
        ``encode_image(path)`` codepath that would otherwise dereference
        symlinks inside imagededup itself.

        Args:
            image_path: Path to image file.
            trusted_root: Anchor directory that bounds the SafeDir
                traversal. When supplied (typically the directory the
                walk started from), every intermediate component of
                ``image_path.relative_to(trusted_root)`` is checked for
                symlinks. ``find_duplicates``, ``cluster_by_similarity``,
                and ``batch_compute_hashes`` thread their root through.
                When ``None``, falls back to parent-rooted protection
                (final component only) — OK for ad-hoc calls.

        Returns:
            Hexadecimal string representation of perceptual hash,
            or None if image could not be processed.
        """
        if not image_path.exists():
            logger.warning(f"Image not found: {image_path}")
            return None

        if not image_path.is_file():
            logger.warning(f"Path is not a file: {image_path}")
            return None

        if image_path.suffix.lower() not in SUPPORTED_FORMATS:
            logger.warning(
                f"Unsupported image format: {image_path.suffix}. Supported: {SUPPORTED_FORMATS}"
            )
            return None

        try:
            if not _NUMPY_AVAILABLE:
                logger.warning("numpy required for image hashing; install fo-core[dedup-image]")
                return None
            # Open via SafeDir, convert PIL Image → numpy array, pass to
            # imagededup's image_array= API. This bypasses imagededup's
            # path-based codepath which would call Pillow's path-based
            # Image.open() internally and re-introduce the symlink
            # dereference we're trying to close.
            with safedir_image_open(image_path, trusted_root=trusted_root) as (img, _fd):
                # imagededup interprets numpy arrays as RGB: its
                # ``preprocess_image`` runs ``PIL.Image.fromarray(array)``
                # which PIL maps to RGB for 3-channel uint8 arrays, then
                # converts to grayscale via the same luminance formula
                # used on the path-based codepath. Passing an RGB array
                # here therefore matches what
                # ``encode_image(image_file=str(path))`` would have
                # produced — same color photo, same perceptual hash.
                if img.mode != "RGB":
                    img = img.convert("RGB")
                image_array = np.ascontiguousarray(np.asarray(img))
            encoding = self.hasher.encode_image(image_array=image_array)
            return str(encoding) if encoding is not None else None
        except OSError as e:
            logger.warning(f"Could not read image {image_path}: {e}")
            return None
        except DecompressionBombError as e:
            # PIL refuses images over MAX_IMAGE_PIXELS — recoverable
            # per-file error, not a reason to abort find_duplicates /
            # batch_compute_hashes scans. Mirrors how
            # image_utils.get_image_metadata handles it.
            logger.error(f"Decompression bomb detected for {image_path}: {e}")
            return None
        except (ValueError, RuntimeError) as e:
            logger.error(f"Error processing image {image_path}: {e}")
            return None

    def compute_hamming_distance(self, hash1: str, hash2: str) -> int:
        """Calculate Hamming distance between two perceptual hashes.

        Hamming distance is the number of bit positions where the two
        hashes differ. Lower distance = more similar images.

        Args:
            hash1: First perceptual hash (hex string)
            hash2: Second perceptual hash (hex string)

        Returns:
            Hamming distance (0-64 for 64-bit hashes)

        Raises:
            ValueError: If hashes are not valid hex strings
        """
        try:
            # Convert hex strings to integers
            int1 = int(hash1, 16)
            int2 = int(hash2, 16)

            # XOR gives 1 for different bits, 0 for same bits
            xor = int1 ^ int2

            # Count number of 1s (different bits)
            distance = bin(xor).count("1")

            return distance
        except ValueError as e:
            raise ValueError(f"Invalid hash format: {e}") from e

    def compute_similarity(self, img1: Path, img2: Path) -> float | None:
        """Compute similarity score between two images.

        Args:
            img1: Path to first image
            img2: Path to second image

        Returns:
            Similarity score from 0.0 (completely different) to 1.0 (identical),
            or None if either image could not be processed.
            Formula: 1 - (hamming_distance / 64)
        """
        hash1 = self.get_image_hash(img1)
        hash2 = self.get_image_hash(img2)

        if hash1 is None or hash2 is None:
            return None

        distance = self.compute_hamming_distance(hash1, hash2)

        # Convert distance to similarity score (0-1)
        # 64 is max possible distance for 64-bit hash
        similarity = 1.0 - (distance / 64.0)

        return similarity

    def find_duplicates(
        self,
        directory: Path,
        recursive: bool = True,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> dict[str, list[Path]]:
        """Find duplicate and similar images in a directory.

        Groups images by similarity, with each group containing one representative
        image and all its duplicates/similar images.

        Args:
            directory: Directory to scan for images
            recursive: If True, scan subdirectories recursively
            progress_callback: Optional callback function(current, total) called
                             during processing to report progress

        Returns:
            Dictionary mapping representative image hash to list of similar image paths.
            Only groups with 2+ images are included.

        Example:
            {
                "abc123...": [Path("img1.jpg"), Path("img2.jpg")],
                "def456...": [Path("img3.png"), Path("img4.png"), Path("img5.png")]
            }
        """
        if not directory.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")

        if not directory.is_dir():
            raise ValueError(f"Path is not a directory: {directory}")

        # Find all image files
        image_files = self._find_image_files(directory, recursive)

        if not image_files:
            logger.info(f"No images found in {directory}")
            return {}

        logger.info(f"Found {len(image_files)} images to process")

        # Compute hashes for all images
        image_hashes: dict[Path, str] = {}

        for idx, img_path in enumerate(image_files, 1):
            # ``directory`` is the trusted root: every image was found
            # under this walk, so SafeDir anchoring traverses each
            # intermediate component with O_NOFOLLOW.
            img_hash = self.get_image_hash(img_path, trusted_root=directory)
            if img_hash is not None:
                image_hashes[img_path] = img_hash

            if progress_callback:
                progress_callback(idx, len(image_files))

        logger.info(f"Successfully hashed {len(image_hashes)} images")

        # Find duplicates using imagededup's find_duplicates method
        # Create mapping from string path to hash for imagededup
        encoding_map = {str(path): hash_val for path, hash_val in image_hashes.items()}

        # imagededup's find_duplicates returns dict[filename] -> list of similar filenames
        duplicates_dict = self.hasher.find_duplicates(
            encoding_map=encoding_map, max_distance_threshold=self.threshold
        )

        # Convert back to Path objects and group by representative
        grouped_duplicates: dict[str, list[Path]] = {}
        processed: set[str] = set()

        for image_str, similar_list in duplicates_dict.items():
            if image_str in processed:
                continue

            # Only include if there are actual duplicates
            if similar_list:
                image_path = Path(image_str)
                similar_paths = [Path(s) for s in similar_list]

                # Use the hash as the key for grouping
                representative_hash = image_hashes[image_path]

                # Create group with all similar images
                group = [image_path] + similar_paths
                grouped_duplicates[representative_hash] = group

                # Mark all as processed
                processed.add(image_str)
                processed.update(similar_list)

        logger.info(f"Found {len(grouped_duplicates)} duplicate groups")

        return grouped_duplicates

    def cluster_by_similarity(
        self, images: list[Path], progress_callback: Callable[[int, int], None] | None = None
    ) -> list[list[Path]]:
        """Cluster images into groups of similar images.

        Uses single-linkage clustering: if any image in a cluster is similar
        to a new image, the new image joins that cluster.

        Args:
            images: List of image paths to cluster
            progress_callback: Optional callback function(current, total) for progress

        Returns:
            List of clusters, where each cluster is a list of similar image paths
        """
        if not images:
            return []

        # Compute hashes for all images
        image_hashes: dict[Path, str] = {}

        for idx, img_path in enumerate(images, 1):
            # cluster_by_similarity takes an arbitrary list of paths;
            # there's no single trusted root we can anchor against.
            # Fall back to parent-rooted protection (final-component
            # O_NOFOLLOW only) — documented as the standalone-caller
            # contract in safedir_image_open.
            img_hash = self.get_image_hash(img_path)
            if img_hash is not None:
                image_hashes[img_path] = img_hash

            if progress_callback:
                progress_callback(idx, len(images))

        if not image_hashes:
            return []

        # Build clusters using single-linkage
        clusters: list[list[Path]] = []
        processed: set[Path] = set()

        for img_path, img_hash in image_hashes.items():
            if img_path in processed:
                continue

            # Start new cluster
            cluster = [img_path]
            processed.add(img_path)

            # Find all similar images
            for other_path, other_hash in image_hashes.items():
                if other_path in processed:
                    continue

                distance = self.compute_hamming_distance(img_hash, other_hash)
                if distance <= self.threshold:
                    cluster.append(other_path)
                    processed.add(other_path)

            clusters.append(cluster)

        # Filter out single-image clusters
        clusters = [c for c in clusters if len(c) > 1]

        return clusters

    def batch_compute_hashes(
        self, image_paths: list[Path], progress_callback: Callable[[int, int], None] | None = None
    ) -> dict[Path, str]:
        """Compute perceptual hashes for multiple images.

        Processes images sequentially but returns all results together.
        Failed images are logged but don't stop batch processing.

        Args:
            image_paths: List of image paths to hash
            progress_callback: Optional callback function(current, total) for progress

        Returns:
            Dictionary mapping image paths to their perceptual hashes.
            Images that couldn't be hashed are excluded from results.
        """
        results: dict[Path, str] = {}

        for idx, img_path in enumerate(image_paths, 1):
            # batch_compute_hashes takes an arbitrary list of paths; no
            # single trusted root. Falls back to parent-rooted SafeDir
            # protection — same as cluster_by_similarity.
            img_hash = self.get_image_hash(img_path)
            if img_hash is not None:
                results[img_path] = img_hash

            if progress_callback:
                progress_callback(idx, len(image_paths))

        return results

    def _find_image_files(self, directory: Path, recursive: bool = True) -> list[Path]:
        """Find all supported image files in a directory.

        Args:
            directory: Directory to search
            recursive: If True, search subdirectories

        Returns:
            List of paths to image files
        """
        image_files: list[Path] = []

        if recursive:
            pattern = "**/*"
        else:
            pattern = "*"

        for path in directory.glob(pattern):
            # ``Path.is_file()`` follows symlinks (PR3f / Codex finding).
            # Filter symlinked entries here so SafeDir's per-component
            # check inside the dedup hash flow remains the only place
            # that decides whether a symlinked image is processed —
            # never silently accepted by the walk.
            if path.is_symlink():
                logger.debug("Skipping symlinked image in walk: %s", path)
                continue
            if path.is_file() and path.suffix.lower() in SUPPORTED_FORMATS:
                image_files.append(path)

        return image_files

    def validate_image(self, image_path: Path) -> tuple[bool, str | None]:
        """Validate that an image can be processed.

        Checks:
        - File exists and is readable
        - Format is supported
        - Image can be opened with PIL

        Args:
            image_path: Path to image file

        Returns:
            Tuple of (is_valid, error_message)
            - If valid: (True, None)
            - If invalid: (False, "error description")
        """
        if not image_path.exists():
            return False, f"File not found: {image_path}"

        if not image_path.is_file():
            return False, f"Path is not a file: {image_path}"

        if image_path.suffix.lower() not in SUPPORTED_FORMATS:
            return False, f"Unsupported format: {image_path.suffix}"

        try:
            with safedir_image_open(image_path) as (img, _fd):
                # Try to load image data to verify it's not corrupt
                img.verify()
            return True, None
        except OSError as e:
            return False, f"Cannot read image: {e}"
        except (ValueError, RuntimeError) as e:
            return False, f"Corrupt or invalid image: {e}"
