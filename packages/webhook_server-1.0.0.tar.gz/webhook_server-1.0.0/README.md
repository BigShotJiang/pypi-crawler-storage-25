# Datadog to Telegram webhook
Provides a basic authenticated webhook to forward alerts from Datadog to Telegram
## Requirements
- A Datadog account
- A Telegram account

### Quickstart
#### Datadog
1. Set up a [Datadog Webhook integration](https://docs.datadoghq.com/integrations/webhooks/)
2. Create a new webhook with the following URL:
   ```
   https://<your-server-host>:8080/telegram/<telegram_chat_id>
   ```
3. Use basic authentication credentials matching the ones configured on the server (see below)
4. Use the webhook in your Datadog monitors by adding `@webhook-<webhook_name>` in the notification body

#### Telegram
1. Create a Telegram bot via [BotFather](https://t.me/botfather) and note the **API token**
2. Get your **chat ID** by messaging your bot and visiting:
   ```
   https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates
   ```
   The `chat.id` field in the response is your chat ID

#### Webhook server
1. Install dependencies:
   ```bash
   uv sync 
   ```
2. Configure the following secrets either as environment variables or as Docker secrets in `/var/run/secrets/`:

   | Environment Variable              | Docker Secret                      | Description                      |
   |-----------------------------------|------------------------------------|----------------------------------|
   | `WEBHOOK_FLASK_SECRET_KEY`        | `webhook_flask_secret_key`         | Flask secret key for sessions    |
   | `WEBHOOK_BASIC_AUTH_USERNAME`     | `webhook_basic_auth_username`      | Basic auth username              |
   | `WEBHOOK_BASIC_AUTH_PASSWORD`     | `webhook_basic_auth_password`      | Basic auth password              |
   | `WEBHOOK_TELEGRAM_BOT_API_TOKEN` | `webhook_telegram_bot_api_token`   | Telegram bot API token           |

3. Run the server:
   ```bash
   python app.py
   ```
   The server starts on `127.0.0.1:8080` by default

Example curl:
```
curl -X POST -H "Content-Type: application/json"\
 -d '{
    "body": "%%%\n## What happened\n\nLorem ipsum\n\n- - - - - - - - - - - - -\n[[View Security Signal](https://app.datadoghq.eu/security/signals?event=AQAAAZ1Ywej15QMmZwAAAABBWjFZd2VqMUFBQ19SNDg2NGFTSW9BQUE&start=1775308796341&end=1775312396341&utm_source=notification&utm_medium=email,webhook)]\n@webhook-telegram_webhook\n%%%",
    "last_updated": "1775320543",
    "event_type": "api",
    "title": "Alert",
    "date": "1775320543",
    "org": {
        "id": "12345",
        "name": "ORG_NAME"
    },
    "id": "54321"
}' -u "${WEBHOOK_BASIC_AUTH_USERNAME}:${WEBHOOK_BASIC_AUTH_PASSWORD}" http://localhost:8080/telegram/${TELEGRAM_CHATID}
```

### Documentation

### Contribute
Open to any PR/comments/issues

## Licence
Copyright 2023 DaisukiXCI

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
