from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
import re


@dataclass
class DatadogOrg:
    id: int
    name: str


@dataclass
class DatadogAlertContent:
    title: str
    event_type: str
    body: str
    date: int
    org: DatadogOrg
    id: int
    last_updated: int

    def to_dict(self) -> dict:
        return asdict(self)


class DatadogAlert:
    def __init__(self, alert: DatadogAlertContent):
        self._alert = alert

    def get_message(self) -> str:
        message = f"""*{_datadog_to_telegram_md(self._alert.title)}*
In Org {_escape_md(self._alert.org['name'])}\({_escape_md(self._alert.org['id'])}\)
At {_escape_md(datetime.fromtimestamp(int(self._alert.date), tz=UTC).strftime("%Y/%m/%d %H:%M"))}
{_datadog_to_telegram_md(self._alert.body)}"""
        return message


def _escape_md(text: str) -> str:
    return re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)


def _datadog_to_telegram_md(text: str) -> str:
    text = text.strip().strip("%").strip()

    links = []

    def extract_link(match):
        links.append((match.group(1), match.group(2)))
        return f"LINKTOKEN{len(links)-1}END"

    text = re.sub(r"\[\[(.*?)\]\((.*?)\)\]", extract_link, text)

    # Process lines
    lines = text.splitlines()
    result = []

    for line in lines:
        line = line.strip()

        if line.startswith("## "):
            content = _escape_md(line[3:])
            result.append(f"*{content}*")
            continue

        if line.startswith("- - -"):
            continue

        result.append(_escape_md(line))

    text = "\n".join(result)

    # Restore links
    for i, (label, url) in enumerate(links):
        safe_label = _escape_md(label)
        print(safe_label + " " + url)
        text = text.replace(f"LINKTOKEN{i}END", f"[{safe_label}]({url})")

    return text
