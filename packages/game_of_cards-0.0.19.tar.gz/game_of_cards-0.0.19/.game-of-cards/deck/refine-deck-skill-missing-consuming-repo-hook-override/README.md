---
title: refine-deck-skill-missing-consuming-repo-hook-override
summary: refine-deck is the only deck-mutating skill that doesn't load a `.game-of-cards/hooks/<name>.md` override, so consuming repos can't extend its hygiene pass with project-specific decay thresholds, categories, or generalization hunters. Add the `!cat` injection line, ship the hook stub, and mention the extension point in the body.
status: done
stage: null
contribution: low
created: "2026-05-14T12:30:11Z"
closed_at: 2026-05-14T12:40:15Z
human_gate: none
advances: []
advanced_by: []
tags: [story, infra]
definition_of_done: |
  - [x] `goc/templates/skills/refine-deck/SKILL.md` loads `.game-of-cards/hooks/refine-deck.md` via `!`cat ... 2>/dev/null || true`` in a `## Context (project-local extension)` block between Preflight and the `# Refine the deck` H1; the `## Context` H2 is required so the OpenClaw porter's `PREFLIGHT_RE` (which spans up to the next H1/H2 boundary) doesn't strip the hook line
  - [x] One body sentence near the top of refine-deck names the hook as a consuming-repo extension point (so future readers discover it without reverse-engineering the `!cat` line)
  - [x] `goc/templates/game_of_cards/hooks/refine-deck.md` stub exists, mirroring the boilerplate in `audit-deck.md` (header comment explains the injection mechanism; file body is empty)
  - [x] `uv run goc validate` passes; `sync-plugin-assets` pre-commit hook regenerates `.claude/skills/refine-deck/SKILL.md` and `claude-plugin/skills/refine-deck/SKILL.md` from the template
  - [x] `openclaw-plugin/skills/refine-deck/SKILL.md` reflects the hook (re-port via `scripts/port_skills_to_openclaw.py` confirmed; non-refine-deck OpenClaw drift was reverted to stay scoped — separate cleanup card should be filed)
worker: {who: Rodja Trappe, where: main}
---

# refine-deck-skill-missing-consuming-repo-hook-override

## Problem

`refine-deck` is the only deck-mutating skill in the family of six
that lacks a `!`cat .game-of-cards/hooks/<name>.md`` injection point.
The pattern is established in five sibling skills:

| Skill | Hook-load line |
|---|---|
| audit-deck | `goc/templates/skills/audit-deck/SKILL.md:21` |
| create-card | `goc/templates/skills/create-card/SKILL.md:111` |
| decide-card | `goc/templates/skills/decide-card/SKILL.md:105` |
| finish-card | `goc/templates/skills/finish-card/SKILL.md:73`, `210` |
| pull-card | `goc/templates/skills/pull-card/SKILL.md:58` |
| **refine-deck** | **(missing)** |

A `grep -rn 'hooks/' goc/templates/skills/refine-deck/` returns zero
results. Consuming repos that want to extend the hygiene pass with
project-specific behavior — different decay thresholds, additional
surfacing categories, a pattern-discovery pass with specialized
reviewers — currently have no documented injection surface for
refine-deck. They would need to fork the skill or build an entirely
separate skill, which defeats the consuming-repo extension contract
the other skills honor.

## Solution

Three mechanical edits, all in the `goc/templates/` source-of-truth
tree (auto-sync handles the consumer + plugin mirrors):

### 1. Add `!cat` line to refine-deck SKILL.md

Insert between the existing `## Preflight` section (ending at L8) and
the `# Refine the deck` H1 (currently L10), structurally analogous to
audit-deck's L11–L23 "Context" block:

```markdown
## Preflight

If any `!` block below shows `goc: command not found`, ...

!`cat .game-of-cards/hooks/refine-deck.md 2>/dev/null || true`

# Refine the deck
```

### 2. Mention the hook in the body

Add one sentence near the top of the body (right after the
introductory paragraph that mentions backlog refinement) along the
lines of:

> The consuming repo may extend this hygiene flow via
> `.game-of-cards/hooks/refine-deck.md` (already loaded above) —
> e.g., to demand a pattern-discovery pass with specialized
> reviewers, override decay thresholds, or surface
> project-specific categories beyond the generic ones below.

This is the load-bearing extensibility hint. Without it, a future
reader sees the `!cat` line as dead code and may strip it.

### 3. Ship the hook stub

Drop `goc/templates/game_of_cards/hooks/refine-deck.md` with the
same boilerplate as the audit-deck stub:

```markdown
<!-- .game-of-cards/hooks/refine-deck.md
     Project-local workflow-hook injected into the goc-shipped `refine-deck` skill
     body via `!\`cat .game-of-cards/hooks/refine-deck.md\`` at the documented
     hook-point. The skill follows whatever instructions you write here at
     that point in its workflow.

     If this file is empty, the skill proceeds with its generic flow. -->
```

`_sync_game_of_cards_config()` in `goc/install.py:649` already copies
the entire `game_of_cards/hooks/` tree into consuming repos, so no
install.py edit is needed — the new stub ships automatically.

## Propagation

Per CLAUDE.md, the SKILL.md edit auto-propagates:

- `goc/templates/skills/refine-deck/SKILL.md` (edit target)
- → `.claude/skills/refine-deck/SKILL.md` (regenerated by
  `scripts/sync_plugin_assets.py` in pre-commit)
- → `claude-plugin/skills/refine-deck/SKILL.md` (same)
- → `openclaw-plugin/skills/refine-deck/SKILL.md` (NOT auto-synced;
  re-port via `scripts/port_skills_to_openclaw.py`)

The hook stub at `goc/templates/game_of_cards/hooks/refine-deck.md`
is project-state, not plugin-asset, so it's NOT in the auto-sync.
It ships only via `goc install` to new consuming repos.

## Verification

```bash
# 1. SKILL.md loads the hook
grep -n 'hooks/refine-deck' goc/templates/skills/refine-deck/SKILL.md
# Expected: at least one `!`cat ...`` match between preflight and the H1

# 2. Stub file exists
test -f goc/templates/game_of_cards/hooks/refine-deck.md && echo OK

# 3. Sync + validate
pre-commit run --all-files
uv run goc validate
```

## Why not just put the hook in audit-deck or other existing hooks

audit-deck's hook is for spike-style defect hunting (probe recipes,
hunter rosters). refine-deck's hygiene pass is a different
operational mode (backlog refinement, not spike). Folding them
together would conflate the two operating modes and force the
consuming repo to multiplex configuration. Separate hook = separate
extension surface, matching the existing 1:1 skill:hook pattern.
