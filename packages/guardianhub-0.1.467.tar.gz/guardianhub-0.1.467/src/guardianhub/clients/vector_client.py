"""
Vector Service Client for interacting with vector database.

This module provides functionality for:
- Managing vector collections
- Storing and retrieving document embeddings (via the service)
- Handling semantic and agentic tools
- Chunking large documents
- Sanitizing metadata
"""

import json
import time
import asyncio
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Union
from contextlib import asynccontextmanager

import httpx
from guardianhub import get_logger
from guardianhub.config.settings import settings
from guardianhub.models import VectorQueryResponse, VectorQueryRequest
from guardianhub.models.builtins.vector_models import VectorQueryResult
from guardianhub.clients.sovereign_base_client import SovereignBaseClient

# Module logger
logger = get_logger(__name__)

# Constants
DEFAULT_COLLECTION_DOCS = "document_templates"
BULLET_COLLECTION = "ace_context_bullets"

class VectorClient(SovereignBaseClient):
    """
    Production-ready Vector Service Client with circuit breaker, retry logic,
    and comprehensive error handling for mission-critical operations.
    
    Features:
    - Circuit breaker pattern for service protection
    - Exponential backoff retry logic with jitter
    - Intelligent chunking with boundary detection
    - Comprehensive input validation and sanitization
    - Production-grade HTTP client with connection pooling
    - Detailed operational logging with emoji indicators
    - Health monitoring and metrics collection
    
    Usage:
        config = VectorClientConfig(max_retries=3, circuit_breaker_threshold=5)
        client = VectorClient(shared_client=http_client)
        await client.initialize()
        
        # Atomic document storage
        await client.upsert_atomic("collection", "doc_id", "content", {"meta": "data"})
        
        # Chunked document storage
        await client.upsert_chunked("collection", "source_id", "large_content", {"meta": "data"})
        
        # Semantic search
        results = await client.query("search query", "collection", n_results=10)
    """

    # ============================================================================
    # INITIALIZATION & CONFIGURATION
    # ============================================================================

    def __init__(self, shared_client, config=None):
        # 1. Initialize via the Sovereign Base with the shared pool
        from guardianhub.config.settings import settings
        self.config = settings.vector
        # 🎯 FORCE EXPLICIT CASING TO PREVENT STRING COMPARISON CRASHES
        # 🎯 MAXIMUM RESILIENCY: Force-cast all numerical config parameters
        try:
            self.config.max_document_length = int(self.config.max_document_length)
            self.config.max_batch_size = int(self.config.max_batch_size)
            self.config.circuit_breaker_threshold = int(self.config.circuit_breaker_threshold)
            self.config.retry_delay = float(self.config.retry_delay)  # 🎯 FIX HERE
            self.config.circuit_breaker_timeout = float(self.config.circuit_breaker_timeout)  # 🎯 FIX HERE
            self.config.health_check_interval = float(self.config.health_check_interval)  # 🎯 FIX HERE
        except Exception as type_err:
            logger.error(f"⚠️ [VECTOR_INIT] Failed config type casting, using defaults: {type_err}")
            # Fallback inline assignments if configuration elements are missing
            self.config.retry_delay = 2.0
            self.config.circuit_breaker_timeout = 30.0




        super().__init__(
            shared_client=shared_client,
            base_url=settings.endpoints.VECTOR_SERVICE_URL
        )

        self.target_collections = list(set(
            [self.config.default_collection] + self.config.additional_collections
        ))
        self.initialized = False

        # Circuit breaker state (required by existing methods)
        self._failure_count = 0
        self._circuit_open = False
        self._circuit_open_time = 0
        self._last_health_check = 0

    async def initialize(self) -> bool:
        """
        Warms up the vector well by ensuring collections exist.
        Now uses the shared _request logic for auth/tenant propagation.
        """
        logger.info(f"🔧 [VECTOR] Vector URL = {settings.endpoints.VECTOR_SERVICE_URL}")
        logger.info(f"🔧 [VECTOR] Bootstrapping collections: {self.target_collections}")
        try:
            for name in self.target_collections:
                # Use SovereignBaseClient._request to ensure headers are sent

                await self._request("POST", f"/collections/{name}/ensure", json={})

            self.initialized = True
            return True
        except Exception as e:
            logger.error(f"❌ [VECTOR] Bootstrap failed: {str(e)}")
            return False

    # ============================================================================
    # COLLECTION MANAGEMENT
    # ============================================================================

    async def ensure_collection_exists(self, collection_names: List[str], **collection_kwargs) -> None:
        """Production-ready collection creation with retry logic.
        
        Args:
            collection_names: List of collection names to ensure exist
            **collection_kwargs: Additional collection configuration
            
        Raises:
            RuntimeError: If circuit breaker is open
            ConnectionError: If service is unreachable
        """
        logger.debug(f"📦 [VECTOR_CLIENT] Ensuring {len(collection_names)} collections exist")
        
        for name in collection_names:
            if not name or not name.strip():
                logger.warning(f"⚠️ [VECTOR_CLIENT] Skipping empty collection name")
                continue
                
            await self._with_retry(
                operation=lambda: self._create_single_collection(name, **collection_kwargs),
                operation_name=f"ensure_collection_exists({name})"
            )
    
    async def _create_single_collection(self, name: str, **collection_kwargs) -> None:
        """Create a single collection with error handling.
        
        Args:
            name: Collection name to create
            **collection_kwargs: Additional collection configuration
        """
        try:
            logger.debug(f"🔨 [VECTOR_CLIENT] Creating collection: {name}")
            # Try to create collection using vector service API
            response = await self._request("POST", f"/collections/{name}/ensure", json=collection_kwargs,
                timeout=10.0)

            # Response is already JSON parsed by base client
            logger.debug(f"✅ [VECTOR_CLIENT] Collection Confirmed Existence: {name}")
            
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 409:
                logger.debug(f"✅ [VECTOR_CLIENT] Collection already exists: {name}")
            elif e.response.status_code == 500:
                # Try to check if collection exists instead
                try:
                    check_response = await self._request("GET", f"/collections/{name}", json={})
                    # Response is already JSON parsed by base client, check if it's valid
                    if check_response and isinstance(check_response, dict):
                        logger.debug(f"✅ [VECTOR_CLIENT] Collection already exists: {name}")
                        return
                except:
                    pass
                logger.warning(f"⚠️ [VECTOR_CLIENT] Failed to create collection {name}, but continuing...")
            else:
                raise
    
    async def _validate_operations(self) -> None:
        """Validate basic operations are working."""
        test_collection = self.default_collection
        
        # Test query operation
        # await self.query(
        #     query_text="health_check",
        #     collection=test_collection,
        #     n_results=1
        # )
        #
        logger.debug("✅ Basic operations validation passed")

    async def delete_collection(self, name: str) -> None:
        """Delete a collection."""
        await self._request("DELETE", f"/collections/{name}", json={})
        logger.info(f"Deleted collection {name}")

    # ============================================================================
    # HEALTH & CONNECTION
    # ============================================================================

    async def _check_connection(self) -> None:
        """Production health check with circuit breaker logic."""
        current_time = time.time()
        
        # Rate limit health checks
        if current_time - self._last_health_check < self.config.health_check_interval:
            if self.initialized:  # Skip if we were recently healthy
                return
                
        self._last_health_check = current_time
        
        try:
            response = await self._request("GET", f"/health", timeout=5.0, json={})
            # Response is already JSON parsed by base client
            
            # Validate health response
            health_data = response
            status = health_data.get("status", "").lower()
            if status not in ["healthy", "ok", "200"]:
                raise ValueError(f"Service reports unhealthy: {health_data}")
                
            self.initialized = True
            logger.debug("✅ Vector service health check passed")
            
        except Exception as e:
            self.initialized = False
            logger.error(f"❌ Vector client health check failed: {str(e)}")
            raise

    async def close(self) -> None:
        """Graceful shutdown with cleanup."""
        try:
            # await self._client.aclose()
            logger.info("✅ VectorClient closed gracefully")
        except Exception as e:
            logger.error(f"⚠️ Error closing VectorClient: {e}")
    
    # ============================================================================
    # CIRCUIT BREAKER & RETRY LOGIC
    # ============================================================================
    
    def _is_circuit_open(self) -> bool:
        """Check if circuit breaker is open.
        
        Returns:
            bool: True if circuit breaker is open, False otherwise
        """
        if not self._circuit_open:
            return False
            
        # Check if circuit should be half-open
        if time.time() - self._circuit_open_time > self.config.circuit_breaker_timeout:
            logger.info(f"🔄 [VECTOR_CLIENT] Circuit breaker transitioning to HALF-OPEN")
            self._circuit_open = False
            self._failure_count = 0
            return False
            
        return True
    
    def _record_failure(self) -> None:
        """Record a failure and potentially open circuit breaker.
        
        Increments failure count and opens circuit breaker if threshold exceeded.
        """
        self._failure_count += 1
        logger.warning(f"⚠️ [VECTOR_CLIENT] Failure recorded: {self._failure_count}/{self.config.circuit_breaker_threshold}")
        
        if self._failure_count >= self.config.circuit_breaker_threshold:
            self._circuit_open = True
            self._circuit_open_time = time.time()
            logger.error(f"🚨 [VECTOR_CLIENT] Circuit breaker OPENED - {self.config.circuit_breaker_timeout}s timeout")
    
    def _reset_circuit_breaker(self) -> None:
        """Reset circuit breaker after successful operation.
        
        Logs successful reset and clears failure state.
        """
        if self._failure_count > 0:
            logger.info(f"✅ [VECTOR_CLIENT] Circuit breaker reset after {self._failure_count} failures")
        self._failure_count = 0
        self._circuit_open = False

    async def _with_retry(self, operation, operation_name: str):
        """Execute operation with retry logic and circuit breaker."""
        if self._is_circuit_open():
            raise RuntimeError(f"Circuit breaker open - cannot execute {str(operation_name)}")

        last_exception = None
        # Ensure max_retries is strictly calculated as an integer
        total_retries = int(getattr(self.config, "max_retries", 3))

        for attempt in range(total_retries + 1):
            try:
                result = await operation()
                if attempt > 0:
                    logger.info(f"✅ [VECTOR_CLIENT] {str(operation_name)} succeeded on attempt {int(attempt) + 1}")
                self._reset_circuit_breaker()
                return result

            except Exception as e:
                last_exception = e
                if attempt < total_retries:
                    # Explicitly convert retry delays to clear float numbers
                    base_delay = float(getattr(self.config, "retry_delay", 1.0))
                    delay = base_delay * (2 ** int(attempt))

                    # 🎯 FIXED: Safeguard string interpolation by explicit casting
                    op_str = str(operation_name)
                    attempt_str = str(attempt + 1)
                    delay_str = f"{delay:.2f}"
                    err_str = str(e)

                    logger.warning(
                        f"⚠️ [VECTOR_CLIENT] {op_str} failed on attempt {attempt_str}, retrying in {delay_str}s: {err_str}")
                    await asyncio.sleep(delay)
                else:
                    self._record_failure()
                    logger.error(
                        f"❌ [VECTOR_CLIENT] {str(operation_name)} failed after {total_retries + 1} attempts: {str(e)}")

        raise last_exception
    
    @asynccontextmanager
    async def _operation_context(self, operation_name: str):
        """Context manager for operations with timing and error handling.
        
        Args:
            operation_name: Human-readable operation name for logging
            
        Yields:
            None: Control passes to the operation
            
        Raises:
            Exception: Original exception with timing information added
        """
        start_time = time.time()
        try:
            yield
            duration = time.time() - start_time
            logger.debug(f"⏱️ [VECTOR_CLIENT] {operation_name} completed in {duration:.2f}s")
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"❌ [VECTOR_CLIENT] {operation_name} failed after {duration:.2f}s: {str(e)}")
            raise

    # ============================================================================
    # PRODUCTION WRITE INTERFACE
    # ============================================================================

    async def upsert_atomic(self, collection: str, doc_id: str, text: str, metadata: Dict):
        """Production atomic upsert with validation and error handling.
        
        Stores document as a single unbroken unit without chunking.
        Ideal for tool outputs, AARs, and context-sensitive documents.
        
        Args:
            collection: Target collection name
            doc_id: Unique document identifier
            text: Document content to store
            metadata: Document metadata dictionary
            
        Returns:
            dict: Operation result with status and details
            
        Raises:
            ValueError: If required parameters are missing or invalid
            RuntimeError: If circuit breaker is open
        """
        logger.info(f"📄 [VECTOR_CLIENT] Starting atomic upsert: {doc_id} -> {collection}")
        # 🎯 STRUCTURAL DIAGNOSTIC LOGGING
        logger.info(f"📋 [DIAGNOSTIC] collection: {collection} (type: {type(collection).__name__})")
        logger.info(f"📋 [DIAGNOSTIC] doc_id: {doc_id} (type: {type(doc_id).__name__})")
        logger.info(f"📋 [DIAGNOSTIC] text length: {len(text) if text else 0} (type: {type(text).__name__})")
        logger.info(f"📋 [DIAGNOSTIC] metadata keys: {list(metadata.keys()) if metadata else 'None'}")

        logger.info(f"📄 [VECTOR_CLIENT] Starting atomic upsert: {doc_id} -> {collection}")
        
        # Input validation
        if not collection or not doc_id or not text:
            raise ValueError("Collection, doc_id, and text are required")
            
        if len(text) > self.config.max_document_length:
            raise ValueError(f"Document too long: {len(text)} > {self.config.max_document_length}")
        
        logger.debug(f"📊 [VECTOR_CLIENT] Document size: {len(text)} chars")
        logger.debug(f"🏷️ [VECTOR_CLIENT] Metadata keys: {list(metadata.keys())}")
        
        try:
            async with self._operation_context(f"upsert_atomic({doc_id})"):
                meta = self._prepare_metadata(metadata)
                meta.update({
                    "is_atomic": True,
                    "original_doc_id": doc_id,
                    "ingested_at": datetime.utcnow().isoformat(),
                    "type": metadata.get("type", "generic_record")
                })
                
                result = await self._with_retry(
                    operation=lambda: self._execute_upsert(collection, [doc_id], [text], [meta]),
                    operation_name=f"upsert_atomic({doc_id})"
                )
                
                logger.info(f"✅ [VECTOR_CLIENT] Atomic upsert completed: {doc_id}")
                
                return result
                
        except Exception as e:
            logger.error(f"❌ [VECTOR_CLIENT] Atomic upsert failed: {str(e)}")
            raise

    async def upsert_chunked(self, collection: str, source_id: str, full_text: str, metadata: Dict):
        """Production chunked upsert with batch processing and validation.
        
        Intelligently chunks large documents for optimal retrieval.
        Preserves semantic coherence through boundary detection.
        
        Args:
            collection: Target collection name
            source_id: Source document identifier
            full_text: Complete document content to chunk
            metadata: Document metadata dictionary
            
        Returns:
            dict: Operation result with chunk count and status
            
        Raises:
            ValueError: If required parameters are missing or invalid
            RuntimeError: If circuit breaker is open
        """
        logger.info(f"📚 [VECTOR_CLIENT] Starting chunked upsert: {source_id} -> {collection}")
        
        if not collection or not source_id or not full_text:
            raise ValueError("Collection, source_id, and full_text are required")
            
        if len(full_text) > self.config.max_document_length:
            raise ValueError(f"Document too long: {len(full_text)} > {self.config.max_document_length}")
        
        logger.debug(f"📊 [VECTOR_CLIENT] Document size: {len(full_text)} chars")
        logger.debug(f"🏷️ [VECTOR_CLIENT] Metadata keys: {list(metadata.keys())}")
        
        async with self._operation_context(f"upsert_chunked({source_id})"):
            chunks = self._process_chunks(full_text)
            if not chunks:
                raise ValueError("Chunking produced no content")
            
            logger.info(f"🔪 [VECTOR_CLIENT] Created {len(chunks)} chunks from {len(full_text)} chars")
            
            # Process in batches to avoid overwhelming the service
            batch_size = min(self.config.max_batch_size, len(chunks))
            batches_processed = 0
            
            for i in range(0, len(chunks), batch_size):
                batch_chunks = chunks[i:i + batch_size]
                batch_start = i
                batch_num = i // batch_size + 1
                total_batches = (len(chunks) + batch_size - 1) // batch_size
                
                logger.debug(f"📦 [VECTOR_CLIENT] Processing batch {batch_num}/{total_batches}: {len(batch_chunks)} chunks")
                
                ids = [f"{source_id}-{batch_start + j}" for j in range(len(batch_chunks))]
                
                base_meta = self._prepare_metadata(metadata)
                metadatas = []
                for j, chunk in enumerate(batch_chunks):
                    m = base_meta.copy()
                    m.update({
                        "chunk_index": batch_start + j,
                        "is_atomic": False,
                        "original_doc_id": source_id,
                        "chunk_total": len(chunks)
                    })
                    metadatas.append(m)
                
                await self._with_retry(
                    operation=lambda: self._execute_upsert(collection, ids, batch_chunks, metadatas),
                    operation_name=f"upsert_chunked_batch({source_id}, batch {batch_num})"
                )
                
                batches_processed += 1
            
            logger.info(f"✅ [VECTOR_CLIENT] Chunked upsert completed: {source_id} ({len(chunks)} chunks, {batches_processed} batches)")
            return {"status": "success", "chunks_processed": len(chunks), "source_id": source_id, "batches_processed": batches_processed}

    # ============================================================================
    # PRODUCTION QUERY INTERFACE
    # ============================================================================
    async def query(self, request: VectorQueryRequest) -> VectorQueryResponse:
        """Production query with validation and circuit breaker.
        
        Performs semantic search with comprehensive error handling and metrics.
        
        Args:
            query_text: Search query string
            collection: Target collection name
            n_results: Maximum number of results to return (1-100)
            where: Optional metadata filter dictionary
            
        Returns:
            List[Dict]: Search results with content, metadata, and scores
            
        Raises:
            ValueError: If required parameters are missing or invalid
            RuntimeError: If circuit breaker is open
        """
        query_text = request.query
        collection = request.collection
        n_results = request.n_results
        where = request.filters
        
        logger.info(f"🔍 [VECTOR_CLIENT] Starting query: '{query_text[:50]}...' -> {collection}")
        
        # Input validation
        if not query_text or not collection:
            raise ValueError("Query text and collection are required")
            
        if len(query_text) > self.config.max_query_length:
            raise ValueError(f"Query too long: {len(query_text)} > {self.config.max_query_length}")
            
        if n_results <= 0 or n_results > 100:
            raise ValueError(f"Invalid n_results: {n_results}. Must be between 1 and 100")
        
        logger.debug(f"📊 [VECTOR_CLIENT] Query length: {len(query_text)} chars")
        logger.debug(f"🎯 [VECTOR_CLIENT] Max results: {n_results}")
        if where:
            logger.debug(f"🔎 [VECTOR_CLIENT] Filter: {where}")
        
        try:
            async with self._operation_context(f"query({collection}, n={n_results})"):
                # ChromaDB query format
                payload = {
                    "query_texts": [query_text],
                    "n_results": n_results
                }
                
                # Add where filter if provided
                if where:
                    payload["where"] = where

                response: VectorQueryResponse = await self._with_retry(
                    operation=lambda: self._execute_query(payload, collection),
                    operation_name=f"query({collection})"
                )
                
                logger.info(f"✅ [VECTOR_CLIENT] Query completed: {len(response.results)} results from {collection}")
                # 5. Intelligence Metrics
                if response.results:
                    avg_sim = sum(r.similarity for r in response.results) / len(response.results)
                    logger.info(f"✅ [VECTOR] Found {len(response.results)} facts. Avg Similarity: {avg_sim:.3f}")

                return response
                
        except Exception as e:
            logger.error(f"❌ [VECTOR_CLIENT] Query failed: {str(e)}")
            raise

    async def _execute_query(self, payload: Dict, collection: str) -> VectorQueryResponse:
        """
        Execute query and COERCE the parallel-array mess into a
        Standardized Sovereign Response.
        """
        # _request handles OTel tracing, Tenant ID, and error checking automatically
        data = await self._request(
            "POST",
            f"/collections/{collection}/query",
            json=payload
        )
        # Handle different response wrappers
        data = data.get("results", data)

        # 1. Forensic validation of raw vector DB arrays
        if not (data and "documents" in data and data["documents"]):
            logger.warning(f"📡 [VECTOR] Empty or invalid response from {collection}")
            return VectorQueryResponse(results=[])

        # 2. Extract the parallel arrays (Handling Chroma/Milvus style nested lists)
        documents = data["documents"][0] if isinstance(data["documents"][0], list) else data["documents"]
        metadatas = data.get("metadatas", [[]])[0] or [{}] * len(documents)
        distances = data.get("distances", [[]])[0] or [1.0] * len(documents)
        ids = data.get("ids", [[]])[0] or [str(uuid.uuid4()) for _ in range(len(documents))]

        # 3. Build validated Result objects
        structured_results = []
        for i, doc in enumerate(documents):
            # 🎯 THE 10-FOLD MOVE: Use your new Pydantic Model here
            result_item = VectorQueryResult(
                id=ids[i],
                document_text=doc,  # Maps to 'content' via alias
                similarity_score=float(1.0 - distances[i]),  # Maps to 'similarity' via alias
                metadata=metadatas[i] if i < len(metadatas) else {}
            )
            structured_results.append(result_item)

        # 4. Return the Unified Response
        return VectorQueryResponse(results=structured_results)
    # ============================================================================
    # PRODUCTION HELPER METHODS
    # ============================================================================

    def _process_chunks(self, text: str) -> List[str]:
        """Production chunking with intelligent boundary detection."""
        if not text:
            return []

        # 🎯 FIX 1: Enforce integer type casting in case of dynamic configuration leakage
        try:
            max_chars = int(getattr(self.config, "max_chunk_size", 2000))
        except Exception:
            max_chars = 2000

        chunks = []
        start = 0

        while start < len(text):
            end = min(len(text), start + max_chars)

            if end < len(text):
                slice_text = text[start:end]
                last_newline = slice_text.rfind('\n')
                last_space = slice_text.rfind(' ')
                last_period = slice_text.rfind('.')

                # Choose the best break point
                best_break = max(last_newline, last_space, last_period)

                # 🎯 FIX 2: Safeguard against -1 index outcomes and explicitly cast values to int
                if int(best_break) > 0 and int(best_break) > int(max_chars * 0.8):
                    end = start + best_break + 1

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start = end

        return chunks

    def _prepare_metadata(self, metadata: Dict) -> Dict:
        """Production metadata sanitization with comprehensive validation."""
        if not metadata:
            return {}

        clean = {}
        for k, v in metadata.items():
            if v is None:
                continue

            # Sanitize key
            if not isinstance(k, str) or not k.strip():
                continue
            key = k.strip().lower()

            # 🎯 THE STRATEGIC FIX: Cast values to string to prevent upstream
            # concatenation crashes inside SovereignBaseClient logging/headers
            if isinstance(v, bool):
                clean[key] = str(v).lower()  # "true" / "false"
            elif isinstance(v, (int, float)):
                clean[key] = str(v)  # 💾 Force string representation ("1", "0.4")
            elif isinstance(v, (dict, list)):
                try:
                    clean[key] = json.dumps(v, separators=(',', ':'))
                except (TypeError, ValueError):
                    clean[key] = str(v)
            else:
                clean[key] = str(v)

        return clean
    async def _execute_upsert(self, collection: str, ids: List[str], docs: List[str], metas: List[Dict]):
        """Production upsert with validation and error handling."""
        # Validate inputs
        if not all([ids, docs, metas]) or len(ids) != len(docs) or len(docs) != len(metas):
            raise ValueError("Mismatched input arrays for upsert")
            
        if len(ids) > self.config.max_batch_size:
            raise ValueError(f"Batch too large: {len(ids)} > {self.config.max_batch_size}")
        
        # Validate each document
        for i, doc in enumerate(docs):
            if not doc or not doc.strip():
                raise ValueError(f"Empty document at index {i}")
        
        payload = {"ids": ids, "documents": docs, "metadatas": metas}

        result = await self._request("POST", f"/collections/{collection}/add", json=payload)
        logger.debug(f"Upserted {len(ids)} documents to {collection}")
        return result


    async def delete_document(self, doc_id: str, collection: str) -> None:
        """Production document deletion with validation and error handling."""
        if not doc_id or not collection:
            raise ValueError("Document ID and collection are required")
            
        async with self._operation_context(f"delete_document({doc_id})"):
            await self._with_retry(
                operation=lambda: self._execute_delete(doc_id, collection),
                operation_name=f"delete_document({doc_id})"
            )
    
    async def _execute_delete(self, doc_id: str, collection: str) -> None:
        """Execute the actual deletion with proper error handling."""

        result = await self._request("POST", f"/collections/{collection}/delete", timeout=5.0, json={
                "where": {
                    "original_doc_id": doc_id
                }
            })
        deleted_count = result.get("deleted", 0)
        logger.info(f"Deleted {deleted_count} document chunks for ID {doc_id} from {collection}")

    # ============================================================================
    # PRODUCTION SPECIALIZED QUERY METHODS
    # ============================================================================

        # ============================================================================
        # PRODUCTION SPECIALIZED QUERY METHODS
        # ============================================================================

    async def retrieve_relevant_context(self, query: str, collection: str = "general", n_results: int = 5) -> List[
        Dict[str, Any]]:
        """Production RAG context retrieval via Standardized Contract."""
        if not query:
            return []

        # 🎯 THE STITCH: Wrap the string into our new Contract
        request = VectorQueryRequest(
            query=query,
            collection=collection,
            n_results=n_results
        )

        response = await self.query(request)

        # Map to the format expected by the Reasoning Engines
        return [{
            "text": r.content,
            "source": r.metadata.get("source", "unknown"),
            "score": r.similarity,
            "metadata": r.metadata
        } for r in response.results]

    async def query_context_bullets(self, query: str, template_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Production ACE Playbook assembly using standard metadata filters."""
        if not query or not template_id:
            raise ValueError("Query and template_id are required")

        # 🎯 THE STITCH: Construct request with filters
        request = VectorQueryRequest(
            query=query,
            collection=BULLET_COLLECTION,
            n_results=limit,
            filters={"template_id": template_id}
        )

        response = await self.query(request)

        # Returns model_dumped dicts for workflow compatibility
        return [res.model_dump() for res in response.results]

    async def get_recent_episodes(self, query: str, limit: int = 10, threshold: float = 0.7) -> List[
        Dict[str, Any]]:
        """Production mission episode retrieval with similarity thresholding."""
        if not query:
            return []

        # 🎯 THE STITCH: Package the request
        request = VectorQueryRequest(
            query=query,
            collection="episodes",
            n_results=limit
        )

        response = await self.query(request)

        # 1. Filter by threshold (using similarity score, not raw distance)
        # 2. Sort by similarity (descending) and timestamp (descending)
        episodes = [r.model_dump() for r in response.results if r.similarity >= threshold]

        return sorted(
            episodes,
            key=lambda x: (-x["similarity"], x["metadata"].get("timestamp", ""))
        )

    # ============================================================================
    # PRODUCTION HEALTH AND MONITORING
    # ============================================================================

    async def health_check(self) -> Dict[str, Any]:
        """
        Comprehensive Sovereign Health Audit.
        Validates connectivity, circuit breaker state, and collection integrity.
        """
        health_status = {
            "status": "unhealthy",
            "timestamp": datetime.utcnow().isoformat(),
            "circuit_breaker": {
                "open": self._circuit_open,
                "failure_count": self._failure_count,
                "threshold": self.config.circuit_breaker_threshold
            },
            "collections": {},
            "errors": []
        }

        try:
            # 1. Base Service Connectivity check
            response = await self._request("GET", f"/health", timeout=5.0, json={})
            # Response is already JSON parsed by base client

            # 2. Deep Collection Integrity Audit
            # We iterate through required target collections
            for coll in self.target_collections:
                try:
                    # 🎯 THE STITCH: Construct a minimal standardized request
                    # We use a neutral query string that won't trigger heavy compute
                    ping_request = VectorQueryRequest(
                        query="ping",
                        collection=coll,
                        n_results=1
                    )

                    # Execute via the main query method to test the full logic path
                    await self.query(ping_request)
                    health_status["collections"][coll] = "healthy"

                except Exception as e:
                    # Capture specific failure without crashing the whole audit
                    error_msg = f"Collection '{coll}' integrity check failed: {str(e)}"
                    health_status["collections"][coll] = "unhealthy"
                    health_status["errors"].append(error_msg)
                    logger.error(f"🏥 [HEALTH_CHECK] {error_msg}")

            # 3. Overall Status Synthesis
            # If everything is healthy, status is 'healthy'
            # If base service is up but some collections are down, status is 'degraded'
            all_collections_healthy = all(
                s == "healthy" for s in health_status["collections"].values()
            )

            if all_collections_healthy:
                health_status["status"] = "healthy"
            elif health_status["collections"]:
                health_status["status"] = "degraded"
            else:
                health_status["status"] = "unhealthy"

        except Exception as e:
            health_status["errors"].append(f"Vector Service unreachable: {str(e)}")
            logger.error(f"🚨 [HEALTH_CHECK] Critical Service Failure: {str(e)}")

        return health_status