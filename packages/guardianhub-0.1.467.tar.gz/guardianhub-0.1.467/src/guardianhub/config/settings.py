"""Core settings for the GuardianHub Foundation SDK."""
from __future__ import annotations

import json
import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Dict, Any, Optional, List

from pydantic import BaseModel, Field, ConfigDict
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from guardianhub import DEFAULT_SYSTEM_TENANT_ID

# Import version from the version file
from guardianhub._version import __version__
# Set up logger for configuration loading
config_logger = logging.getLogger(__name__)

#TODO: Remove this function once we have a proper vault client
def _merge_vault_config_for_dev(config_data: dict) -> dict:
    """Merge Vault credentials into config for development environment.
    Directly uses hvac to avoid circular imports with the SDK VaultClient."""
    try:
        import hvac  # Lazy import of the raw driver

        # Pull Vault connectivity from the already loaded JSON config_data
        vault_url = config_data.get("vault", {}).get("url", "http://guardianhub:8200")
        vault_token = config_data.get("vault", {}).get("token")

        if not vault_token:
            config_logger.warning("⚠️ No Vault token found in config_data, skipping Vault merge.")
            return config_data

        # Initialize raw client
        client = hvac.Client(url=vault_url, token=vault_token)

        # 1. Get postgres credentials from Vault
        try:
            # Matches your silo-based storage path
            pg_path = f"yantramops/tenants/{DEFAULT_SYSTEM_TENANT_ID}/core/postgres_cred"
            pg_res = client.secrets.kv.v2.read_secret_version(path=pg_path)

            if pg_res and 'data' in pg_res and 'data' in pg_res['data']:
                postgres_creds = pg_res['data']['data']
                config_logger.info("✅ Loaded postgres credentials from Vault")

                # Build postgres URL - using MASTER_TENANT_DB per your recent update
                pg_url = (
                    f"postgresql+asyncpg://{postgres_creds.get('DB_USERNAME', 'adminuser')}:"
                    f"{postgres_creds.get('DB_PASSWORD', '')}@"
                    f"{postgres_creds.get('DB_HOST', 'guardianhub')}:"
                    f"{postgres_creds.get('DB_PORT', '5432')}/"
                    f"{postgres_creds.get('MASTER_TENANT_DB', 'db_guardian_tenant_master')}"
                )

                if "endpoints" not in config_data:
                    config_data["endpoints"] = {}
                config_data["endpoints"]["POSTGRES_URL"] = pg_url
                config_logger.info("🔧 Merged Vault postgres URL into config[endpoints][POSTGRES_URL]")
        except Exception as e:
            config_logger.warning(f"⚠️ Could not load postgres from Vault: {e}")

        # 2. Get langfuse credentials from Vault
        try:
            langfuse_path = f"yantramops/tenants/{DEFAULT_SYSTEM_TENANT_ID}/observability/langfuse"
            lf_res = client.secrets.kv.v2.read_secret_version(path=langfuse_path)

            if lf_res and 'data' in lf_res and 'data' in lf_res['data']:
                langfuse_creds = lf_res['data']['data']
                config_logger.info("✅ Loaded langfuse credentials from Vault")

                if "credentials" not in config_data:
                    config_data["credentials"] = {}

                # Map Vault keys to SDK Credential keys
                mapping = {
                    "LANGFUSE_PUBLIC_KEY": "LANGFUSE_PUBLIC_KEY",
                    "LANGFUSE_SECRET_KEY": "LANGFUSE_SECRET_KEY",
                    "LANGFUSE_PROJECT_ID": "LANGFUSE_PROJECT_ID"
                }

                for v_key, c_key in mapping.items():
                    if langfuse_creds.get(v_key):
                        config_data["credentials"][c_key] = langfuse_creds[v_key]

                if langfuse_creds.get("LANGFUSE_HOST"):
                    if "endpoints" not in config_data:
                        config_data["endpoints"] = {}
                    config_data["endpoints"]["LANGFUSE_HOST"] = langfuse_creds["LANGFUSE_HOST"]

                config_logger.info("🔧 Merged Vault langfuse credentials into config[credentials]")
        except Exception as e:
            config_logger.warning(f"⚠️ Could not load langfuse from Vault: {e}")

        # 3. Get Vector (ChromaDB) credentials from Vault
        try:
            # Path updated to acme_corp as per your requirement
            vector_path = f"yantramops/tenants/{DEFAULT_SYSTEM_TENANT_ID}/core/chromadb"
            vector_res = client.secrets.kv.v2.read_secret_version(path=vector_path)

            if vector_res and 'data' in vector_res and 'data' in vector_res['data']:
                vector_creds = vector_res['data']['data']
                config_logger.info("✅ Loaded vector (ChromaDB) credentials from Vault")

                if "endpoints" not in config_data:
                    config_data["endpoints"] = {}

                # Merge VECTOR_SERVICE_URL into endpoints
                if vector_creds.get("VECTOR_SERVICE_URL"):
                    config_data["endpoints"]["VECTOR_SERVICE_URL"] = vector_creds["VECTOR_SERVICE_URL"]

                # Merge VECTOR_COLLECTION_NAME into credentials or settings
                if vector_creds.get("VECTOR_COLLECTION_NAME"):
                    if "credentials" not in config_data:
                        config_data["credentials"] = {}
                    config_data["credentials"]["VECTOR_COLLECTION_NAME"] = vector_creds["VECTOR_COLLECTION_NAME"]

                config_logger.info("🔧 Merged Vault vector credentials into config")
        except Exception as e:
            config_logger.warning(f"⚠️ Could not load vector config from Vault: {e}")

        # 3. Get GraphDB(Neo4J)  credentials from Vault
        try:
            # Path updated to acme_corp as per your requirement
            vector_path = f"yantramops/tenants/{DEFAULT_SYSTEM_TENANT_ID}/core/chromadb"
            vector_res = client.secrets.kv.v2.read_secret_version(path=vector_path)

            if vector_res and 'data' in vector_res and 'data' in vector_res['data']:
                vector_creds = vector_res['data']['data']
                config_logger.info("✅ Loaded vector (ChromaDB) credentials from Vault")

                if "endpoints" not in config_data:
                    config_data["endpoints"] = {}

                # Merge VECTOR_SERVICE_URL into endpoints
                if vector_creds.get("VECTOR_SERVICE_URL"):
                    config_data["endpoints"]["VECTOR_SERVICE_URL"] = vector_creds["VECTOR_SERVICE_URL"]

                # Merge VECTOR_COLLECTION_NAME into credentials or settings
                if vector_creds.get("VECTOR_COLLECTION_NAME"):
                    if "credentials" not in config_data:
                        config_data["credentials"] = {}
                    config_data["credentials"]["VECTOR_COLLECTION_NAME"] = vector_creds["VECTOR_COLLECTION_NAME"]

                config_logger.info("🔧 Merged Vault vector credentials into config")
        except Exception as e:
            config_logger.warning(f"⚠️ Could not load vector config from Vault: {e}")

        # 3. Get GraphDB  credentials from Vault
        try:
            # Path updated to acme_corp as per your requirement
            vector_path = f"yantramops/tenants/{DEFAULT_SYSTEM_TENANT_ID}/core/chromadb"
            vector_res = client.secrets.kv.v2.read_secret_version(path=vector_path)

            if vector_res and 'data' in vector_res and 'data' in vector_res['data']:
                vector_creds = vector_res['data']['data']
                config_logger.info("✅ Loaded vector (ChromaDB) credentials from Vault")

                if "endpoints" not in config_data:
                    config_data["endpoints"] = {}

                # Merge VECTOR_SERVICE_URL into endpoints
                if vector_creds.get("VECTOR_SERVICE_URL"):
                    config_data["endpoints"]["VECTOR_SERVICE_URL"] = vector_creds["VECTOR_SERVICE_URL"]

                # Merge VECTOR_COLLECTION_NAME into credentials or settings
                if vector_creds.get("VECTOR_COLLECTION_NAME"):
                    if "credentials" not in config_data:
                        config_data["credentials"] = {}
                    config_data["credentials"]["VECTOR_COLLECTION_NAME"] = vector_creds["VECTOR_COLLECTION_NAME"]

                config_logger.info("🔧 Merged Vault vector credentials into config")
        except Exception as e:
            config_logger.warning(f"⚠️ Could not load vector config from Vault: {e}")

    except ImportError:
        config_logger.error("❌ hvac library not found. Run 'pip install hvac'.")
    except Exception as e:
        config_logger.warning(f"⚠️ Vault config merge failed: {e}")

    return config_data


def _load_config_defaults(env: str = None) -> dict:
    """Load configuration defaults from JSON files based on environment."""
    env = (env or os.environ.get("ENVIRONMENT", "development")).lower()
    env = "development" if env == "dev" else env

    config_logger.info(f"Loading configuration for environment: {env}")

    config_dir = Path(__file__).parent
    possible_files = [f"config_{env}.json", "config_dev.json", "config_development.json"]

    config_data = {}

    for filename in possible_files:
        config_path = config_dir / filename
        if config_path.exists():
            try:
                with open(config_path) as f:
                    config_data = json.load(f)
                    config_logger.info(f"Loaded config from {filename}")
                    break
            except Exception as e:
                config_logger.warning(f"Failed to load {filename}: {e}")
                continue

    # For development environment, merge Vault credentials (Vault takes precedence)
    if env == "development":
        config_logger.info("🔐 Development mode: Attempting Vault credential hydration...")
        #config_data = _merge_vault_config_for_dev(config_data)

    return config_data

# --- Pydantic Models for Configuration Sections ---

class ServiceInfo(BaseModel):
    name: str = "guardianhub-service"
    version: str = "0.0.1"
    sdk_version: str = __version__
    id: str = "guardian-01"
    host: str = "0.0.0.0"
    port: int = 8001

class LoggingSettings(BaseModel):
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

class ModelConfig(BaseModel):
    model_name: str
    provider: str = "OPENAI"
    base_url: str
    api_key: str = "your-api-key-here"
    temperature: float = 0.1
    max_tokens: int = 2048
    streaming: bool = False
    headers: Dict[str, str] = {}
    model_kwargs: Dict[str, Any] = {}

class LLMSettings(BaseModel):
    model_configs: Dict[str, ModelConfig] = Field(default_factory=dict)
    def get_config(self, key: str = "default") -> ModelConfig:
        return self.model_configs.get(key, self.model_configs.get("default"))

class CredentialConfig(BaseModel):
    model_config = ConfigDict(extra="allow")
    def __init__(self, **data):
        processed_data = {k.upper(): v for k, v in data.items()}
        super().__init__(**processed_data)
    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key.upper(), default)

class VaultSettings(BaseModel):
    url: str = "http://guardianhub:8200"
    token: Optional[str] = "hvs.VagzCTdfYwpXayUr154DleIS"
    mount_point: str = "secret"
    enabled: bool = False

class SpecialistSettings(BaseModel):
    agent_name: str = "specialist-default"
    agent_domain: str = "infrastructure"
    capabilities: List[str] = Field(default_factory=list)
    hop_limit: int = 3
    callback_timeout: int = 300
    task_queue: str = "acme-corp-specialist-queue"

    def __init__(self, **data):
        processed_data = {k.replace('-', '_'): v for k, v in data.items()}
        super().__init__(**processed_data)

class ServiceEndpoints(BaseModel):
    model_config = ConfigDict(extra="allow")
    ENVIRONMENT: str = "development"
    CONSUL_HTTP_ADDR: str = "http://consul-server.consul.svc.cluster.local:8500"
    GRAPH_DB_URL: str = "http://graph-db-service.default.svc.cluster.local:8009"
    LLM_URL: str = "http://aura-llm-service.default.svc.cluster.local:8000/v1"
    LANGFUSE_HOST: str = "http://langfuse-web.langfuse.svc.cluster.local:3000"
    POSTGRES_URL: str = "postgresql://user:password@localhost:5432/guardianhub"
    TEXT_EMBEDDING_SERVICE_URL: str = "http://localhost:8010"
    TOOL_REGISTRY_URL: str = "http://localhost:8000"
    TOOL_EXECUTOR_URL: str = "http://localhost:8003"
    VECTOR_SERVICE_URL: str = "http://vector-db-service.default.svc.cluster.local:8005"
    TEMPORAL_HOST_URL: str = "guardianhub-temporal-frontend.temporal.svc.cluster.local:7233"
    SUTRAM_CALLBACK_URL: str = "http://sutram-ai-host-service.default.svc.cluster.local:8001/api/v1/agent/callback"
    VAULT_MANAGER_URL: str = "http://localhost:7036"
    CLASSIFICATION_SERVICE_URL: str = "http://localhost:8000/v1/agent/callback"
    METADATA_EXTRACTION_SERVICE_URL: str = "http://localhost:8000/v1/agent/callback"
    PAPERLESS_SERVICE_URL: str = "http://localhost:8000/v1/agent/callback"

    def __init__(self, **data):
        # Merge defaults with runtime data (case-insensitive)
        super().__init__(**{k.upper(): v for k, v in data.items()})

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key.upper(), default)

class VectorSettings(BaseModel):
    default_collection: str = "mission_templates"
    max_document_length: int = 100000
    max_query_length: int = 1000
    health_check_interval: int = 30
    circuit_breaker_timeout: int = 60
    circuit_breaker_threshold: int = 5
    max_retries: int = 3
    retry_delay: float = 1.0
    max_batch_size: int = 100
    additional_collections: List[str] = Field(default_factory=lambda: ["ace_context_bullets", "episodes", "lessons", "cmdb_reconciliation_audit","sutram_tools","test_collection"])

# --- Main Settings Class ---

class CoreSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="GH_",
        env_nested_delimiter="__",
        extra="allow"
    )
    vault: VaultSettings = Field(default_factory=VaultSettings)
    specialist: SpecialistSettings = Field(default_factory=SpecialistSettings)
    service: ServiceInfo = Field(default_factory=ServiceInfo)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    llm: LLMSettings = Field(default_factory=LLMSettings)
    endpoints: ServiceEndpoints = Field(default_factory=ServiceEndpoints)
    credentials: CredentialConfig = Field(default_factory=CredentialConfig)
    vector: VectorSettings = Field(default_factory=VectorSettings)

    @model_validator(mode="before")
    @classmethod
    def _bootstrap_config(cls, data: Any) -> Any:
        if isinstance(data, dict):
            env = data.get("ENVIRONMENT") or os.environ.get("ENVIRONMENT", "development")
            config_data = _load_config_defaults(env)
            # Merge runtime overrides into file defaults
            if isinstance(config_data, dict):
                return {**config_data, **data}
        return data

@lru_cache()
def get_cached_settings() -> CoreSettings:
    return CoreSettings()

settings: CoreSettings = get_cached_settings()