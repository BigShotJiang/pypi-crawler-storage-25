"""planfile — universal ticket standard for developer toolchains.

This package provides:
- Strategy and sprint modeling in YAML
- Ticket-based project management (CRUD, import, sync)
- Task execution with intelligent model selection
- Integration with various LLM providers
- CLI and API for applying and reviewing strategies
"""

__version__ = "0.1.85"
__author__ = "Tom Sapletta"
__email__ = "tom@sapletta.com"

from pathlib import Path
from typing import TYPE_CHECKING

# Core models (single source of truth)
from planfile.core.models import (
    Goal,
    ModelHints,
    ModelTier,
    QualityGate,
    Sprint,
    Strategy,
    Task,
    TaskPattern,
    TaskType,
    Ticket,
    TicketSource,
    TicketStatus,
)
from planfile.core.store import PlanfileStore
from planfile.testql_integration import (
    build_testql_tickets,
    run_testql_validation,
    sync_testql_tickets,
    upsert_testql_tickets,
)
from planfile.ticket_validation import validate_planfile_tickets
from planfile.todo_sync import sync_todo_checkboxes_from_planfile

# Backward compat aliases
StrategyV1 = Strategy
StrategyV2 = Strategy
ModelTierV2 = ModelTier

# Lazy loading for executors to improve startup performance
if TYPE_CHECKING:
    from planfile import executor_standalone, runner
    from planfile.executor_standalone import (
        LLMClient,
        StrategyExecutor,
        TaskResult,
        create_litellm_client,
        create_openai_client,
        execute_strategy,
    )
    from planfile.runner import load_valid_strategy, run_strategy, verify_strategy_post_execution


class Planfile:
    """Main entry point — convenience wrapper around PlanfileStore."""

    MAX_BULK_TICKETS = 50

    def __init__(self, project_path: str = "."):
        self.store = PlanfileStore(project_path)
        if not self.store.is_initialized():
            self.store.init()

    @classmethod
    def auto_discover(cls, start_path: str = ".") -> "Planfile":
        """Find .planfile/ in CWD or parent directories."""
        path = Path(start_path).resolve()
        while path != path.parent:
            if (path / ".planfile").exists():
                return cls(str(path))
            path = path.parent
        return cls(start_path)  # init in CWD

    def create_ticket(self, name: str, **kwargs) -> Ticket:
        ticket_id = self.store.next_id()
        ticket = Ticket(id=ticket_id, name=name, **kwargs)
        return self.store.create_ticket(ticket)

    def get_ticket(self, ticket_id: str):
        return self.store.get_ticket(ticket_id)

    def list_tickets(self, **filters):
        return self.store.list_tickets(**filters)

    def update_ticket(self, ticket_id: str, **updates):
        return self.store.update_ticket(ticket_id, **updates)

    def delete_ticket(self, ticket_id: str) -> bool:
        """Delete a single ticket by ID. Returns True if deleted, False if not found."""
        return self.store.delete_ticket(ticket_id)

    def delete_tickets(self, ticket_ids: list[str]) -> tuple[list[str], list[str]]:
        """Delete multiple tickets by ID. Returns (deleted_ids, not_found_ids)."""
        return self.store.delete_tickets_bulk(ticket_ids)

    def create_tickets_bulk(self, tickets_data: list[dict],
                            source: str = None, sprint: str = "current"):
        created = []
        for data in tickets_data[:self.MAX_BULK_TICKETS]:
            if source and "source" not in data:
                data["source"] = {"tool": source}
            data.setdefault("sprint", sprint)
            ticket = self.create_ticket(**data)
            created.append(ticket)
        if len(tickets_data) > self.MAX_BULK_TICKETS:
            # Keep the limit explicit so callers can surface it in UX/logs.
            pass
        return created


def quick_ticket(name: str, tool: str = "unknown", **kwargs) -> Ticket:
    """One-liner ticket creation for tools."""
    pf = Planfile.auto_discover()
    source = TicketSource(tool=tool, context=kwargs.pop("context", {}))
    return pf.create_ticket(name=name, source=source, **kwargs)


__all__ = [
    # Models
    "Strategy", "StrategyV1", "StrategyV2",
    "Sprint", "Task", "TaskPattern", "TaskType",
    "ModelHints", "ModelTier", "ModelTierV2",
    "Goal", "QualityGate",
    # Tickets
    "Ticket", "TicketStatus", "TicketSource",
    # Store & API
    "PlanfileStore", "Planfile", "quick_ticket",
    # Executors (lazy loaded)
    "StrategyExecutor", "execute_strategy", "TaskResult", "LLMClient",
    "create_openai_client", "create_litellm_client",
    # Runner (lazy loaded)
    "load_valid_strategy", "run_strategy", "verify_strategy_post_execution",
    "sync_todo_checkboxes_from_planfile",
    "run_testql_validation",
    "build_testql_tickets",
    "upsert_testql_tickets",
    "sync_testql_tickets",
    "validate_planfile_tickets",
]

# Lazy loading functions for executors
def __getattr__(name):
    """Lazy import executor modules when accessed."""
    if name in ["runner", "executor_standalone"]:
        import importlib
        return importlib.import_module(f"planfile.{name}")
    elif name in ["load_valid_strategy", "run_strategy", "verify_strategy_post_execution"]:
        from planfile.runner import (
            load_valid_strategy,
            run_strategy,
            verify_strategy_post_execution,
        )
        if name == "load_valid_strategy":
            return load_valid_strategy
        elif name == "run_strategy":
            return run_strategy
        else:
            return verify_strategy_post_execution
    elif name in ["StrategyExecutor", "execute_strategy", "TaskResult", "LLMClient",
                 "create_openai_client", "create_litellm_client"]:
        from planfile.executor_standalone import (
            LLMClient,
            StrategyExecutor,
            TaskResult,
            create_litellm_client,
            create_openai_client,
            execute_strategy,
        )
        if name == "StrategyExecutor":
            return StrategyExecutor
        elif name == "execute_strategy":
            return execute_strategy
        elif name == "TaskResult":
            return TaskResult
        elif name == "LLMClient":
            return LLMClient
        elif name == "create_openai_client":
            return create_openai_client
        else:
            return create_litellm_client
    raise AttributeError(f"module 'planfile' has no attribute '{name}'")
