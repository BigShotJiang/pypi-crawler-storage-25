from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from typing import Any

from ._normalize import _normalize_search_data


@dataclass
class ScoreDistributionResult:
    """Distribution summary of the scores across a search run.

    This dataclass carries computed numbers only. Plotting lives in the
    companion package ``gfo-plotlib``; import it to attach a ``.plot``
    method, or call ``gfo_plotlib.plot_score_distribution(result, ax)``
    explicitly.

    Attributes
    ----------
    scores : list[float]
        All valid scores in evaluation order. NaN, Inf, and missing
        entries are excluded.
    n_invalid : int
        Number of score entries that were missing, NaN, or Inf.
    mean, std, min, max, median : float
        Standard statistics over ``scores``. NaN if no valid scores.
    quartiles : tuple[float, float, float]
        (Q1, Q2, Q3) via the inclusive quantile method. All NaN when
        fewer than four valid scores are available.
    """

    scores: list[float]
    n_invalid: int
    mean: float
    std: float
    min: float
    max: float
    median: float
    quartiles: tuple[float, float, float]


def score_distribution(data: Any) -> ScoreDistributionResult:
    """Compute summary statistics over the scores of a search run."""
    records = _normalize_search_data(data)
    raw = [r.get("score") for r in records]

    valid: list[float] = []
    n_invalid = 0
    for s in raw:
        if s is None:
            n_invalid += 1
            continue
        try:
            sf = float(s)
        except (TypeError, ValueError):
            n_invalid += 1
            continue
        if math.isnan(sf) or math.isinf(sf):
            n_invalid += 1
        else:
            valid.append(sf)

    if not valid:
        nan = math.nan
        return ScoreDistributionResult(
            scores=[],
            n_invalid=n_invalid,
            mean=nan,
            std=nan,
            min=nan,
            max=nan,
            median=nan,
            quartiles=(nan, nan, nan),
        )

    mean = statistics.fmean(valid)
    std = statistics.stdev(valid) if len(valid) >= 2 else 0.0
    median = statistics.median(valid)

    if len(valid) >= 4:
        q = statistics.quantiles(valid, n=4, method="inclusive")
        quartiles = (q[0], q[1], q[2])
    else:
        quartiles = (math.nan, math.nan, math.nan)

    return ScoreDistributionResult(
        scores=valid,
        n_invalid=n_invalid,
        mean=mean,
        std=std,
        min=min(valid),
        max=max(valid),
        median=median,
        quartiles=quartiles,
    )
