from __future__ import annotations

from typing import Any


def _normalize_search_data(data: Any) -> list[dict]:
    """Coerce common search-data formats into a list of dicts.

    The diagnostics module keeps its public functions decoupled from
    any specific data structure. Users pass whatever they have on hand,
    this helper converts it to a uniform list-of-dicts representation
    that the diagnostic functions consume internally.

    Supported inputs
    ----------------
    - ``list`` of dict-like records (returned as-is without copying)
    - ``pandas.DataFrame`` (detected via ``iloc`` plus ``to_dict``)
    - ``polars.DataFrame`` (detected via ``to_dicts``)
    - ``dict`` of equal-length sequences (column-oriented table)

    Raises
    ------
    TypeError
        If the input is none of the above, or if a list contains
        non-dict elements.
    ValueError
        If a dict-of-sequences has columns of differing length.
    """
    if hasattr(data, "to_dicts") and callable(data.to_dicts):
        return list(data.to_dicts())

    if hasattr(data, "iloc") and hasattr(data, "to_dict"):
        return data.to_dict("records")

    if isinstance(data, list):
        if data and not isinstance(data[0], dict):
            raise TypeError(
                "Expected list of dicts; got list of "
                f"{type(data[0]).__name__}."
            )
        return data

    if isinstance(data, dict):
        if not data:
            return []
        keys = list(data.keys())
        seqs = [data[k] for k in keys]
        n = len(seqs[0])
        for k, s in zip(keys, seqs):
            if len(s) != n:
                raise ValueError(
                    "Dict-of-sequences column lengths differ "
                    f"(expected {n}, got {len(s)} for {k!r})."
                )
        return [{k: s[i] for k, s in zip(keys, seqs)} for i in range(n)]

    raise TypeError(
        f"Unsupported search-data format: {type(data).__name__}. "
        "Expected list of dicts, pandas/polars DataFrame, "
        "or dict of equal-length sequences."
    )
