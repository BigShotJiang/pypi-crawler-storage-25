from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from ._normalize import _normalize_search_data


@dataclass
class ConvergenceResult:
    """Running-best trajectory over iterations.

    This dataclass carries computed numbers only. Plotting lives in the
    companion package ``gfo-plotlib``; import it to attach a ``.plot``
    method, or call ``gfo_plotlib.plot_convergence(result, ax)``
    explicitly.

    Attributes
    ----------
    iterations : list[int]
        Iteration indices (0..n-1).
    best_scores : list[float]
        Running maximum score up to each iteration. Values before any
        valid score are NaN.
    improvement_points : list[int]
        Iteration indices at which the running best strictly improved.
    iterations_to_best : int
        Iteration index at which the final best score was first reached.
        Zero if no valid score was ever observed.
    """

    iterations: list[int]
    best_scores: list[float]
    improvement_points: list[int]
    iterations_to_best: int


def convergence(data: Any) -> ConvergenceResult:
    """Compute the running-best trajectory from search data.

    NaN and Inf scores are not counted as improvements but still occupy
    their iteration slot. Iterations before any valid score carry NaN
    so that plotting libraries skip them as gaps.

    Parameters
    ----------
    data
        List of dicts, pandas or polars DataFrame, or dict of equal-length
        sequences. Each record must contain a ``"score"`` field.
    """
    records = _normalize_search_data(data)
    scores = [r.get("score") for r in records]

    iterations = list(range(len(scores)))
    best_scores: list[float] = []
    improvement_points: list[int] = []
    current_best = -math.inf

    for i, s in enumerate(scores):
        if s is None:
            best_scores.append(
                current_best if current_best != -math.inf else math.nan
            )
            continue
        try:
            sf = float(s)
        except (TypeError, ValueError):
            best_scores.append(
                current_best if current_best != -math.inf else math.nan
            )
            continue
        if not math.isnan(sf) and not math.isinf(sf) and sf > current_best:
            current_best = sf
            improvement_points.append(i)
        best_scores.append(
            current_best if current_best != -math.inf else math.nan
        )

    iterations_to_best = improvement_points[-1] if improvement_points else 0

    return ConvergenceResult(
        iterations=iterations,
        best_scores=best_scores,
        improvement_points=improvement_points,
        iterations_to_best=iterations_to_best,
    )
