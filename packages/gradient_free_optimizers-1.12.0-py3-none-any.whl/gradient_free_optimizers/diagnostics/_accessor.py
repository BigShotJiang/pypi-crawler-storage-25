from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._convergence import ConvergenceResult
    from ._parameter_importance import ParameterImportanceResult
    from ._score_distribution import ScoreDistributionResult


class DiagnosticsAccessor:
    """Bundled access to diagnostics for a live optimizer instance.

    Exposes the same functionality as the free functions in
    :mod:`gradient_free_optimizers.diagnostics` but pre-wired to the
    optimizer's ``search_data``. Intended for interactive use, typically
    inside Jupyter notebooks.

    For saved runs or cross-run analysis, prefer the free functions
    which accept any list-of-dicts, pandas DataFrame, polars DataFrame,
    or dict-of-sequences input.
    """

    def __init__(self, optimizer):
        self._optimizer = optimizer

    def _data(self):
        return self._optimizer.search_data

    def convergence(self) -> ConvergenceResult:
        """See :func:`gradient_free_optimizers.diagnostics.convergence`."""
        from ._convergence import convergence

        return convergence(self._data())

    def score_distribution(self) -> ScoreDistributionResult:
        """See :func:`gradient_free_optimizers.diagnostics.score_distribution`."""
        from ._score_distribution import score_distribution

        return score_distribution(self._data())

    def parameter_importance(
        self,
        *,
        parameter_names: str | list[str] = "auto",
        n_trees: int = 64,
        random_state: int | None = None,
        n_permutations: int = 5,
    ) -> ParameterImportanceResult:
        """See :func:`gradient_free_optimizers.diagnostics.parameter_importance`."""
        from ._parameter_importance import parameter_importance

        return parameter_importance(
            self._data(),
            parameter_names=parameter_names,
            n_trees=n_trees,
            random_state=random_state,
            n_permutations=n_permutations,
        )
