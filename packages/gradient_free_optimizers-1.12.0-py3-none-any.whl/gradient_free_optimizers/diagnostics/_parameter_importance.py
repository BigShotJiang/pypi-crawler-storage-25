from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any

from .._estimators import RandomForestRegressor
from ._normalize import _normalize_search_data


@dataclass
class ParameterImportanceResult:
    """Permutation-based parameter importance from a surrogate forest.

    This dataclass carries computed numbers only. Plotting lives in the
    companion package ``gfo-plotlib``; import it to attach a ``.plot``
    method, or call
    ``gfo_plotlib.plot_parameter_importance(result, ax)`` explicitly.

    Attributes
    ----------
    parameter_names : list[str]
        Parameter names in the order used for fitting the surrogate.
    importance_scores : list[float]
        Importances in the same order as ``parameter_names``. Normalized
        to sum to 1 when the surrogate is informative; all-zero if the
        surrogate cannot discriminate between columns.
    """

    parameter_names: list[str]
    importance_scores: list[float]


def parameter_importance(
    data: Any,
    *,
    parameter_names: str | list[str] = "auto",
    n_trees: int = 64,
    random_state: int | None = None,
    n_permutations: int = 5,
) -> ParameterImportanceResult:
    """Compute permutation-based parameter importance from search data.

    A RandomForest surrogate is fit on the valid records, then each
    parameter column is shuffled ``n_permutations`` times. Importance
    is the mean increase in mean-squared error relative to the
    unshuffled baseline, clipped to non-negative and normalized to
    sum to 1.

    Parameters
    ----------
    data
        List of dicts, pandas/polars DataFrame, or dict of equal-length
        sequences.
    parameter_names : "auto" or list[str], default "auto"
        When ``"auto"``, every key except ``"score"`` is treated as a
        parameter. Otherwise, restricts to the given names.
    n_trees : int, default 64
        Number of trees in the surrogate forest.
    random_state : int or None, default None
        Seed for both the surrogate forest and the permutation shuffles.
    n_permutations : int, default 5
        Number of shuffles per column. Higher reduces noise, costs
        proportionally more predict calls.

    Raises
    ------
    ValueError
        On empty input, no parameter columns, missing parameter in a
        record, or non-numerical parameter values.
    """
    records = _normalize_search_data(data)

    valid: list[tuple[dict, float]] = []
    for r in records:
        s = r.get("score")
        if s is None:
            continue
        try:
            sf = float(s)
        except (TypeError, ValueError):
            continue
        if math.isnan(sf) or math.isinf(sf):
            continue
        valid.append((r, sf))

    if len(valid) < 2:
        raise ValueError(
            "parameter_importance needs at least 2 valid records; "
            f"got {len(valid)}."
        )

    if parameter_names == "auto":
        keys: set[str] = set()
        for r, _ in valid:
            keys.update(r.keys())
        keys.discard("score")
        names = sorted(keys)
    else:
        names = list(parameter_names)

    if not names:
        raise ValueError(
            "parameter_importance needs at least one parameter column."
        )

    X: list[list[float]] = []
    y: list[float] = []
    for r, s in valid:
        row: list[float] = []
        for name in names:
            if name not in r:
                raise ValueError(
                    f"Parameter {name!r} missing from record."
                )
            v = r[name]
            try:
                row.append(float(v))
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Parameter {name!r} has non-numerical value {v!r}; "
                    "categorical parameters are not yet supported."
                ) from exc
        X.append(row)
        y.append(s)

    forest = RandomForestRegressor(
        n_estimators=n_trees,
        random_state=random_state,
    )
    forest.fit(X, y)

    baseline_pred = [float(p) for p in forest.predict(X)]
    baseline_mse = _mse(y, baseline_pred)

    rng = random.Random(random_state)
    importances: list[float] = []
    for col in range(len(names)):
        deltas: list[float] = []
        for _ in range(n_permutations):
            permuted = [row[:] for row in X]
            col_values = [row[col] for row in permuted]
            rng.shuffle(col_values)
            for i in range(len(permuted)):
                permuted[i][col] = col_values[i]
            permuted_pred = [float(p) for p in forest.predict(permuted)]
            permuted_mse = _mse(y, permuted_pred)
            deltas.append(max(0.0, permuted_mse - baseline_mse))
        importances.append(sum(deltas) / len(deltas))

    total = sum(importances)
    if total > 0:
        importances = [imp / total for imp in importances]

    return ParameterImportanceResult(
        parameter_names=names,
        importance_scores=importances,
    )


def _mse(y_true: list[float], y_pred: list[float]) -> float:
    n = len(y_true)
    if n == 0:
        return 0.0
    total = 0.0
    for a, b in zip(y_true, y_pred):
        d = a - b
        total += d * d
    return total / n
