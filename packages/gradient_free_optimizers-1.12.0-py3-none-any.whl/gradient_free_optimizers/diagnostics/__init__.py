"""Diagnostics for gradient-free optimization runs.

Each diagnostic is a free function that takes search data in an open
format (list of dicts, pandas/polars DataFrame, or dict of equal-length
sequences) and returns a result dataclass carrying the computed numbers.

This module is compute-only. GFO itself ships no plotting. For plots,
install the companion package ``gfo-plotlib`` which provides
``plot_convergence``, ``plot_score_distribution``,
``plot_parameter_importance`` as free functions and also attaches
a ``.plot`` method to the result dataclasses on import.

Examples
--------
Compute from a live optimizer::

    opt.search(objective, n_iter=200)
    result = opt.diagnostics.convergence()
    print(result.iterations_to_best, len(result.improvement_points))

Compute from saved data::

    import pandas as pd
    from gradient_free_optimizers.diagnostics import convergence
    df = pd.read_csv("my_run.csv")
    result = convergence(df)

Plotting (requires ``pip install gfo-plotlib``)::

    from gfo_plotlib import plot_convergence
    fig, ax = plt.subplots()
    plot_convergence(result, ax, color="black")
"""

from ._accessor import DiagnosticsAccessor
from ._convergence import ConvergenceResult, convergence
from ._parameter_importance import (
    ParameterImportanceResult,
    parameter_importance,
)
from ._score_distribution import ScoreDistributionResult, score_distribution

__all__ = [
    "convergence",
    "ConvergenceResult",
    "score_distribution",
    "ScoreDistributionResult",
    "parameter_importance",
    "ParameterImportanceResult",
    "DiagnosticsAccessor",
]
