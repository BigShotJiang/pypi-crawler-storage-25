"""Anporia MCP server (JP-redacted) exposes the Anporia network to MCP-compatible clients.

Run via:

    python -m anporia_mcp_server

or, after install:

    anporia-mcp-server

See README.md for the .mcp.json / claude_desktop_config.json stanza.
"""

from .server import build_server

__version__ = "0.1.0"
__all__ = ["build_server"]
