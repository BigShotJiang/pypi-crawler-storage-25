# SPDX-FileCopyrightText: © 2026 Joe T. Sylve, Ph.D. <joe.sylve@gmail.com>
#
# SPDX-License-Identifier: MIT

"""Segment moving and program rebasing tools."""

from __future__ import annotations

import ida_ida
import ida_segment
from fastmcp import FastMCP
from pydantic import BaseModel, Field

from ida_mcp.helpers import (
    ANNO_DESTRUCTIVE,
    Address,
    IDAError,
    format_address,
    parse_address,
    resolve_address,
    resolve_segment,
)
from ida_mcp.session import session


class MoveSegmentResult(BaseModel):
    """Result of moving a segment."""

    segment: str = Field(description="Segment name.")
    old_start: str = Field(description="Previous start address (hex).")
    new_start: str = Field(description="New start address (hex).")


class RebaseProgramResult(BaseModel):
    """Result of rebasing the program."""

    old_base: str = Field(description="Previous base address (hex).")
    delta: str = Field(description="Rebase delta (hex).")


def register(mcp: FastMCP):
    @mcp.tool(
        annotations=ANNO_DESTRUCTIVE,
        tags={"segments"},
    )
    @session.require_open
    def move_segment(
        address: Address,
        new_start: Address,
    ) -> MoveSegmentResult:
        """Move a segment to a new starting address.

        Relocates the entire segment and updates all references.

        Args:
            address: Any address within the segment to move.
            new_start: New starting address for the segment.
        """
        seg = resolve_segment(address)
        to = resolve_address(new_start)

        old_start = seg.start_ea
        name = ida_segment.get_segm_name(seg)
        code = ida_segment.move_segm(seg, to)

        if code != 0:
            error_msg = ida_segment.move_segm_strerror(code)
            raise IDAError(
                f"Failed to move segment: {error_msg}",
                error_type="MoveFailed",
                error_code=int(code),
            )

        return MoveSegmentResult(
            segment=name,
            old_start=format_address(old_start),
            new_start=format_address(to),
        )

    @mcp.tool(
        annotations=ANNO_DESTRUCTIVE,
        tags={"segments"},
    )
    @session.require_open
    def rebase_program(delta: str) -> RebaseProgramResult:
        """Rebase the entire program by a given delta.

        Shifts all addresses in the database by the specified amount.

        Args:
            delta: Address delta to shift by (can be negative with "0x" prefix,
                e.g. "0x1000" to shift forward, "-0x1000" to shift back).
        """
        try:
            delta_val = -parse_address(delta[1:]) if delta.startswith("-") else parse_address(delta)
        except ValueError as e:
            raise IDAError(str(e), error_type="InvalidAddress") from e

        old_base = ida_ida.inf_get_min_ea()
        code = ida_segment.rebase_program(delta_val, ida_segment.MSF_FIXONCE)
        if code != 0:
            raise IDAError(
                f"Rebase failed with code {code}",
                error_type="RebaseFailed",
                error_code=int(code),
            )

        return RebaseProgramResult(
            old_base=format_address(old_base),
            delta=format_address(delta_val) if delta_val >= 0 else f"-{format_address(-delta_val)}",
        )
