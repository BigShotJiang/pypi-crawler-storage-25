from setuptools import setup, find_packages

setup(
    name="siliconmetatrader5",
    version="1.2.2",
    packages=find_packages(),
    py_modules=["server"],
    install_requires=[
        "rpyc>=5.0.0",
        "plumbum>=1.8.0",
    ],
)
