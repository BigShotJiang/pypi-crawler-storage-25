import requests


class EmailDesigner:
    def __init__(self, secret: str, base_url: str = "https://api.emaildesigner.org"):
        self.secret = secret
        self.base_url = base_url

    def render(self, design_id: str, variables: dict = None) -> str:
        if variables is None:
            variables = {}

        res = requests.post(
            f"{self.base_url}/designs/{design_id}/render",
            json={
                "secret": self.secret,
                "variables": variables
            }
        )

        if res.status_code != 200:
            try:
                err = res.json()
                message = err.get("message", str(err))
            except Exception:
                message = res.text

            raise Exception(f"Render failed ({res.status_code}): {message}")

        data = res.json()
        return data["code"]