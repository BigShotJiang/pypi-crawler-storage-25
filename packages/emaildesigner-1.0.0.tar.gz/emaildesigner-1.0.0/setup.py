from setuptools import setup, find_packages

setup(
    name="emaildesigner",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.8",
    description="Render email templates via API",
    url="https://github.com/yourusername/emaildesigner",
    author="Selixe",
    author_email="selixe@atlantisservices.net",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)