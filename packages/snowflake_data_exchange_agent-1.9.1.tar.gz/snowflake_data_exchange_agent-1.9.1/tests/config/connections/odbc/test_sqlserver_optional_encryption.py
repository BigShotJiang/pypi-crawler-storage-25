"""Tests for optional encryption parameters in SQLServerConnectionConfig."""

from data_exchange_agent.config.sections.connections.odbc.sqlserver import (
    SQLServerConnectionConfig,
)


class TestOptionalEncryption:
    """Tests for optional encryption and trust_server_certificate parameters."""

    def test_encryption_not_in_connection_string_when_not_specified(self):
        """Test that Encrypt and TrustServerCertificate are not in connection string when not specified."""
        config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 17 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            # encrypt and trust_server_certificate not specified
        )

        conn_str = config.build_connection_string()
        assert "Encrypt=" not in conn_str
        assert "TrustServerCertificate=" not in conn_str
        assert "DRIVER={ODBC Driver 17 for SQL Server}" in conn_str
        assert "SERVER=localhost,1433" in conn_str
        assert "DATABASE=testdb" in conn_str

    def test_encryption_included_when_specified_as_false(self):
        """Test that Encrypt is included in connection string when explicitly set to False."""
        config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 17 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            encrypt=False,
        )

        conn_str = config.build_connection_string()
        assert "Encrypt=no" in conn_str
        assert "TrustServerCertificate=" not in conn_str

    def test_both_encryption_params_included_when_specified(self):
        """Test that both Encrypt and TrustServerCertificate are included when specified."""
        config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 18 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            encrypt=True,
            trust_server_certificate=False,
        )

        conn_str = config.build_connection_string()
        assert "Encrypt=yes" in conn_str
        assert "TrustServerCertificate=no" in conn_str

    def test_warning_issued_for_encryption_with_driver_17(self):
        """
        Test that encryption with Driver 17 works and issues a warning.

        Note: The warning is logged but difficult to capture in tests due to custom logger configuration.
        This test verifies that the config is created successfully despite the encryption+driver17 combination,
        which would trigger a warning in normal operation (visible in pytest's "Captured log call" output).
        """
        # Create config with Driver 17 and encryption enabled
        # This should trigger a warning (visible in test output) but not fail
        config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 17 for SQL Server",
            encrypt=True,
            auto_detect_driver=False,  # Don't validate driver existence
        )

        # Verify the config was created successfully with the specified settings
        assert config.odbc_driver == "ODBC Driver 17 for SQL Server"
        assert config.encrypt == "yes"
        assert "Encrypt=yes" in config.build_connection_string()

    def test_no_warning_for_encryption_with_driver_18(self, caplog):
        """Test that no warning is issued when using encryption with Driver 18."""
        import logging

        caplog.set_level(logging.WARNING, logger="data_exchange_agent.config.sections.connections.odbc.sqlserver")

        _config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 18 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            encrypt=True,
        )

        # Verify no warning was issued
        assert not any(
            "encryption" in record.message.lower() and "Driver 17" in record.message for record in caplog.records
        )

    def test_no_warning_when_encryption_not_enabled(self, caplog):
        """Test that no warning is issued when encryption is not enabled."""
        import logging

        caplog.set_level(logging.WARNING, logger="data_exchange_agent.config.sections.connections.odbc.sqlserver")

        _config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 17 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            encrypt=False,
        )

        # Verify no warning was issued
        assert not any("encryption" in record.message.lower() for record in caplog.records)

    def test_windows_auth_without_encryption(self):
        """Test Windows authentication without encryption parameters."""
        config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            use_windows_auth=True,
            odbc_driver="ODBC Driver 17 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
        )

        conn_str = config.build_connection_string()
        assert "Trusted_Connection=yes" in conn_str
        assert "Encrypt=" not in conn_str
        assert "TrustServerCertificate=" not in conn_str

    def test_named_instance_without_encryption(self):
        """Test named instance without encryption parameters."""
        config = SQLServerConnectionConfig(
            database="testdb",
            host="localhost\\SQLEXPRESS",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 17 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
        )

        conn_str = config.build_connection_string()
        assert "SERVER=localhost\\SQLEXPRESS" in conn_str
        assert "Encrypt=" not in conn_str
        assert "TrustServerCertificate=" not in conn_str

    def test_boolean_values_converted_to_odbc_strings(self):
        """Test that boolean values are correctly converted to 'yes'/'no' strings."""
        # Test True -> "yes"
        config_true = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 18 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            encrypt=True,
            trust_server_certificate=True,
        )

        conn_str = config_true.build_connection_string()
        assert "Encrypt=yes" in conn_str
        assert "TrustServerCertificate=yes" in conn_str

        # Test False -> "no"
        config_false = SQLServerConnectionConfig(
            database="testdb",
            host="localhost",
            username="sa",
            password="password",
            odbc_driver="ODBC Driver 18 for SQL Server",
            auto_detect_driver=False,  # Don't validate driver existence
            encrypt=False,
            trust_server_certificate=False,
        )

        conn_str = config_false.build_connection_string()
        assert "Encrypt=no" in conn_str
        assert "TrustServerCertificate=no" in conn_str
