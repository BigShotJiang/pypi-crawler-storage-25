"""Unit tests for Teradata ODBC connection configuration."""

from data_exchange_agent.config.sections.connections.connection_registry import (
    ConnectionRegistry,
)
from data_exchange_agent.config.sections.connections.odbc import (
    DEFAULT_TERADATA_ODBC_DRIVER,
    DEFAULT_TERADATA_PORT,
    TeradataConnectionConfig,
)


class TestTeradataConnectionString:
    """Tests for Teradata ODBC connection string formatting."""

    def test_basic_connection_string_uses_host_as_dbc_name(self):
        cfg = TeradataConnectionConfig(
            driver_name="Teradata Database ODBC Driver 17.20",
            host="tdcop.example.com",
            port=1025,
            database="tpcds",
            username="dbc",
            password="secret",
        )
        cs = cfg.connection_string
        assert "DRIVER={Teradata Database ODBC Driver 17.20}" in cs
        assert "DBCName=tdcop.example.com" in cs
        assert "UID=dbc" in cs
        assert "PWD=secret" in cs
        assert "Database=tpcds" in cs
        assert "PortNumber=1025" in cs

    def test_dbc_name_override(self):
        cfg = TeradataConnectionConfig(
            driver_name="Teradata Database ODBC Driver 17.20",
            host="10.0.0.1",
            dbc_name="MYTDSYS",
            port=1025,
            database="tpcds",
            username="u",
            password="p",
        )
        assert "DBCName=MYTDSYS" in cfg.connection_string
        assert "DBCName=10.0.0.1" not in cfg.connection_string

    def test_extra_options_appended(self):
        cfg = TeradataConnectionConfig(
            driver_name="Teradata Database ODBC Driver 17.20",
            host="h",
            database="d",
            username="u",
            password="p",
            extra_options={"UseUnicode": "1"},
        )
        cs = cfg.connection_string
        assert "UseUnicode=1" in cs

    def test_from_config_dict_merges_extra_options_and_kwargs(self):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="tpcds",
            username="u",
            host="td.example.com",
            password="p",
            extra_options={"UseUnicode": "1"},
            MechanismName="LDAP",
        )
        cs = cfg.connection_string
        assert "UseUnicode=1" in cs
        assert "MechanismName=LDAP" in cs

    def test_defaults_from_constants(self):
        cfg = TeradataConnectionConfig(
            host="localhost",
            database="db",
            username="u",
        )
        assert cfg.port == DEFAULT_TERADATA_PORT
        assert cfg.driver_name == DEFAULT_TERADATA_ODBC_DRIVER


class TestTeradataConnectionRegistry:
    """Teradata is registered under connection name 'teradata'."""

    def test_teradata_registered(self):
        assert ConnectionRegistry.is_registered("teradata")

    def test_create_from_dict(self):
        cfg = ConnectionRegistry.create(
            "teradata",
            database="tpcds",
            username="u",
            host="h",
            password="p",
        )
        assert isinstance(cfg, TeradataConnectionConfig)
        assert "Database=tpcds" in cfg.connection_string
