"""Unit tests for TaskManager._assign_tasks_to_idle_workers."""

import queue
import unittest
from unittest.mock import Mock, patch

from data_exchange_agent.constants import task_keys
from data_exchange_agent.tasks import manager as manager_mod


def _make_manager_for_assigner() -> manager_mod.TaskManager:
    with patch.object(manager_mod.TaskManager, "__init__", lambda self, **kwargs: None):
        m = manager_mod.TaskManager()
    m.logger = Mock()
    m.stop_workers = False
    m.task_source_adapter = Mock()
    m._idle_worker_queue = queue.Queue()
    m._worker_mailboxes = [queue.Queue(maxsize=1) for _ in range(3)]
    return m


class TestTaskAssigner(unittest.TestCase):
    """Tests for batched pull assignment into worker mailboxes."""

    def test_assigner_skips_when_no_idle_workers(self) -> None:
        """Does not call the task source when the idle queue is empty."""
        m = _make_manager_for_assigner()
        m._assign_tasks_to_idle_workers()
        m.task_source_adapter.get_tasks.assert_not_called()

    def test_assigner_calls_get_tasks_with_idle_count(self) -> None:
        """get_tasks receives max_tasks equal to the number of drained idle workers."""
        m = _make_manager_for_assigner()
        for wid in (0, 1):
            m._idle_worker_queue.put(wid)
        m.task_source_adapter.get_tasks.return_value = []
        m._assign_tasks_to_idle_workers()
        m.task_source_adapter.get_tasks.assert_called_once_with(max_tasks=2)

    def test_assigner_delivers_tasks_and_requeues_remainder(self) -> None:
        """Tasks map to drained worker order; extras stay on the idle queue."""
        m = _make_manager_for_assigner()
        for wid in (0, 1, 2):
            m._idle_worker_queue.put(wid)
        t0 = {task_keys.ID: "a"}
        t1 = {task_keys.ID: "b"}
        m.task_source_adapter.get_tasks.return_value = [t0, t1]
        m._assign_tasks_to_idle_workers()
        self.assertEqual(m._worker_mailboxes[0].get_nowait(), t0)
        self.assertEqual(m._worker_mailboxes[1].get_nowait(), t1)
        self.assertEqual(m._idle_worker_queue.get_nowait(), 2)

    def test_assigner_on_pull_error_requeues_all_idle(self) -> None:
        """Failed pull puts all drained worker ids back for a later tick."""
        m = _make_manager_for_assigner()
        for wid in (0, 1):
            m._idle_worker_queue.put(wid)
        m.task_source_adapter.get_tasks.side_effect = RuntimeError("net down")
        m._assign_tasks_to_idle_workers()
        got = [m._idle_worker_queue.get_nowait(), m._idle_worker_queue.get_nowait()]
        self.assertEqual(sorted(got), [0, 1])

    def test_assigner_noop_when_stopped(self) -> None:
        """When stop_workers is set, do not pull tasks."""
        m = _make_manager_for_assigner()
        m._idle_worker_queue.put(0)
        m.stop_workers = True
        m._assign_tasks_to_idle_workers()
        m.task_source_adapter.get_tasks.assert_not_called()


if __name__ == "__main__":
    unittest.main()
