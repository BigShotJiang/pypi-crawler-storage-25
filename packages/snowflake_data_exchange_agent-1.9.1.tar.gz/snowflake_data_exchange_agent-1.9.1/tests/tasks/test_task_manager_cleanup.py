"""Tests for TaskManager local export cleanup after successful upload."""

import os
import tempfile
from unittest.mock import Mock, patch

import pytest

try:
    from data_exchange_agent.tasks.manager import TaskManager

    TASK_MANAGER_AVAILABLE = True
except ImportError:
    TASK_MANAGER_AVAILABLE = False


def _bare_manager():
    with patch.object(TaskManager, "__init__", lambda self, **kwargs: None):
        m = TaskManager()
        m.logger = Mock()
        return m


@pytest.mark.skipif(not TASK_MANAGER_AVAILABLE, reason="TaskManager not available")
class TestRemoveExportArtifactsAfterSuccess:
    """Cover ``TaskManager._remove_export_artifacts_after_success``."""

    def test_removes_timestamp_dir_and_empty_task_parent(self):
        manager = _bare_manager()
        with tempfile.TemporaryDirectory() as tmp:
            task_dir = os.path.join(tmp, "task_99", "2026-03-31_12-00-00_000")
            os.makedirs(task_dir, exist_ok=True)
            marker = os.path.join(task_dir, "sample.parquet")
            with open(marker, "wb") as f:
                f.write(b"x")

            manager._remove_export_artifacts_after_success(task_dir)

            assert not os.path.exists(task_dir)
            assert not os.path.exists(os.path.join(tmp, "task_99"))

    def test_keeps_task_parent_if_other_runs_remain(self):
        manager = _bare_manager()
        with tempfile.TemporaryDirectory() as tmp:
            t1 = os.path.join(tmp, "task_100", "2026-03-31_12-00-00_000")
            t2 = os.path.join(tmp, "task_100", "2026-03-31_12-00-01_000")
            os.makedirs(t1, exist_ok=True)
            os.makedirs(t2, exist_ok=True)
            with open(os.path.join(t1, "a.parquet"), "wb"):
                pass
            with open(os.path.join(t2, "b.parquet"), "wb"):
                pass

            manager._remove_export_artifacts_after_success(t1)

            assert not os.path.exists(t1)
            assert os.path.isdir(t2)

    def test_skips_when_parent_not_task_prefixed(self):
        manager = _bare_manager()
        with tempfile.TemporaryDirectory() as tmp:
            weird = os.path.join(tmp, "not_task", "sub")
            os.makedirs(weird, exist_ok=True)
            with open(os.path.join(weird, "f.parquet"), "wb"):
                pass

            manager._remove_export_artifacts_after_success(weird)

            assert os.path.isfile(os.path.join(weird, "f.parquet"))

    def test_unknown_task_id_parent_is_cleaned(self):
        manager = _bare_manager()
        with tempfile.TemporaryDirectory() as tmp:
            export_dir = os.path.join(tmp, "unknown_task_id", "2026-03-31_12-00-00_000")
            os.makedirs(export_dir, exist_ok=True)
            with open(os.path.join(export_dir, "x.parquet"), "wb"):
                pass

            manager._remove_export_artifacts_after_success(export_dir)

            assert not os.path.exists(export_dir)
            assert not os.path.exists(os.path.join(tmp, "unknown_task_id"))
