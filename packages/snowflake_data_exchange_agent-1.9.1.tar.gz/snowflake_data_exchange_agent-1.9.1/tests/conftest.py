import logging

import pytest


@pytest.fixture(autouse=True, scope="session")
def _suppress_app_logging():
    """
    Prevent SFLogger console noise during test runs.

    Background threads from container integration tests hit error-logging
    code-paths (e.g. "Engine not found in source connections"), producing
    thousands of noisy lines to stderr via pytest's log capture.  Setting the
    ``data_exchange_agent`` logger to CRITICAL silences them without affecting
    test assertions that check ``mock_logger.error.assert_called()``.
    """
    logger = logging.getLogger("data_exchange_agent")
    original_level = logger.level
    logger.setLevel(logging.CRITICAL)
    for handler in logger.handlers:
        handler.setLevel(logging.CRITICAL)
    yield
    logger.setLevel(original_level)
