"""
Data source implementations for various database systems.

This package contains modules for connecting to and extracting data from
different database engines, handling ODBC connections, and data export utilities.
"""

from data_exchange_agent.constants.data_source_types import DataSourceType
from data_exchange_agent.data_sources.base import BaseDataSource
from data_exchange_agent.data_sources.bcp_data_source import BCPDataSource
from data_exchange_agent.data_sources.data_source_registry import DataSourceRegistry
from data_exchange_agent.data_sources.odbc_data_source import ODBCDataSource
from data_exchange_agent.data_sources.unload_data_source import UnloadDataSource


# Register data source types
DataSourceRegistry.register(DataSourceType.ODBC, ODBCDataSource)
DataSourceRegistry.register(DataSourceType.BCP, BCPDataSource)
DataSourceRegistry.register(DataSourceType.UNLOAD, UnloadDataSource)

__all__ = [
    "BaseDataSource",
    "BCPDataSource",
    "DataSourceRegistry",
    "ODBCDataSource",
    "UnloadDataSource",
]
