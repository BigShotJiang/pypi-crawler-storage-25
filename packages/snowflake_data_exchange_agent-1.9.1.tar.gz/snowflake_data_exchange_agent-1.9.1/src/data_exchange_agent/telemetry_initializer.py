"""
Telemetry initialization for the Data Exchange Agent.

This module provides a single function to initialize the shared telemetry client
when a Snowflake connection becomes available. It was extracted from
SnowflakeDataSource so that connection management and telemetry are decoupled.
"""

import logging
import os

from data_exchange_agent.__version__ import __version__
from shared.telemetry import (
    detect_runtime_environment,
    get_telemetry_client,
    initialize_telemetry,
)


logger = logging.getLogger(__name__)


def initialize_telemetry_if_needed(connection: object) -> None:
    """
    Initialize the global telemetry client if it hasn't been set up yet.

    This is a no-op when telemetry is already active. Any failure is
    swallowed and logged at debug level so that a telemetry problem never
    prevents the agent from operating.

    Args:
        connection: A live ``snowflake.connector.SnowflakeConnection`` instance.

    """
    try:
        telemetry_client = get_telemetry_client()
        if telemetry_client is not None and telemetry_client.is_enabled():
            return

        env = os.getenv("ENVIRONMENT", "prod")
        runtime = detect_runtime_environment()
        initialize_telemetry(
            conn=connection,
            app_name="data_exchange_agent",
            app_version=__version__,
            env=env,
            runtime=runtime,
        )
        logger.debug("Telemetry initialized (env=%s, runtime=%s)", env, runtime.value)
    except Exception as e:
        # Don't fail connection creation if telemetry fails
        logger.debug("Telemetry initialization skipped: %s", e)
