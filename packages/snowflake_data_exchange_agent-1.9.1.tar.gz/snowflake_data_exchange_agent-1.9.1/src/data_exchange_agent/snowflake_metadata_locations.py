"""Snowflake task-queue metadata location (must match orchestrator deployment)."""

from data_exchange_agent.config.manager import ConfigManager
from data_exchange_agent.constants import config_keys
from data_exchange_agent.constants.config_defaults import (
    DEFAULT__APPLICATION__SNOWFLAKE_DATABASE_FOR_METADATA,
    DEFAULT__APPLICATION__SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA,
)


def qualified_data_migration_metadata_schema(program_config: ConfigManager) -> str:
    """Return database.schema where PULL_TASKS / COMPLETE_TASK / FAIL_TASK live."""
    db = program_config.get(
        config_keys.APPLICATION__SNOWFLAKE_DATABASE_FOR_METADATA,
        DEFAULT__APPLICATION__SNOWFLAKE_DATABASE_FOR_METADATA,
    )
    schema = program_config.get(
        config_keys.APPLICATION__SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA,
        DEFAULT__APPLICATION__SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA,
    )
    return f"{db}.{schema}"
