"""Snowflake password authentication configuration."""

from pydantic import Field

from data_exchange_agent.config.sections.connections.cloud_storages.snowflake.authenticator_type import (
    SnowflakeAuthenticatorType,
)
from data_exchange_agent.config.sections.connections.cloud_storages.snowflake.base import (
    SnowflakeExtendedBaseConnectionConfig,
)


class SnowflakeConnectionPasswordConfig(SnowflakeExtendedBaseConnectionConfig):
    """Configuration class for Snowflake connection using user and password."""

    authenticator: SnowflakeAuthenticatorType = Field(
        default=SnowflakeAuthenticatorType.SNOWFLAKE,
        description="Snowflake authenticator type",
    )
    password: str = Field(..., description="Snowflake password")

    def _repr_fields(self) -> str:
        """Get string representation of fields (for use in __repr__)."""
        return super()._repr_fields() + ", password='***'"
