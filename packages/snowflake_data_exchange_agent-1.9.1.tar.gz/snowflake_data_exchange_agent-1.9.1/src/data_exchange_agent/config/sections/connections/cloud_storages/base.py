from data_exchange_agent.config.sections.connections.base import BaseConnectionConfig


class BaseCloudStorageConnectionConfig(BaseConnectionConfig):
    """Base configuration class for cloud storage connection settings."""

    pass
