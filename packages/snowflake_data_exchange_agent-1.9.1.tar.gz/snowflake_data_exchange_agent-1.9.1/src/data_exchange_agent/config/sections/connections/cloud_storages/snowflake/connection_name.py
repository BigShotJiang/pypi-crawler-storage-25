"""Snowflake connection name configuration."""

from pydantic import Field, field_validator

from data_exchange_agent.config.sections.connections.cloud_storages.snowflake.base import SnowflakeConnectionConfig
from data_exchange_agent.constants.connection_types import SPCS_CONNECTION_NAME


class SnowflakeConnectionNameConfig(SnowflakeConnectionConfig):
    """Configuration class for Snowflake connection using a named connection."""

    connection_name: str = Field(
        ...,
        description='Named connection from Snowflake config file, or "@SPCS_CONNECTION" to use SPCS-provided credentials',
    )

    @field_validator("connection_name")
    @classmethod
    def validate_connection_name(cls, v: str) -> str:
        """Validate Snowflake connection name."""
        # Allow the special SPCS connection name
        if v == SPCS_CONNECTION_NAME:
            return v

        return cls._validate_identifier_with_hyphen(v, "Connection name")

    def __repr__(self) -> str:
        """Return string representation of Snowflake connection name configuration."""
        return f"SnowflakeConnectionNameConfig(connection_name='{self.connection_name}')"
