from pydantic import Field

from data_exchange_agent.config.sections.base_section_config import BaseSectionConfig


class ServerConfig(BaseSectionConfig):
    """Configuration class for server host and port settings."""

    host: str | None = Field(default=None, description="Host address to bind to")
    port: int | None = Field(default=None, ge=1, le=65535, description="Port number to bind to")

    def __repr__(self) -> str:
        """Return string representation of server configuration."""
        return f"ServerConfig(host='{self.host}', port={self.port})"
