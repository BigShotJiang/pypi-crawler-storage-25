from typing import Any

from pydantic import BaseModel, ConfigDict


class BaseSectionConfig(BaseModel):
    """Base configuration class with Pydantic validation."""

    model_config = ConfigDict(
        # Allow extra fields to be passed (they will be ignored)
        extra="forbid",
        # Validate default values
        validate_default=True,
        # Use enum values instead of enum objects
        use_enum_values=True,
    )

    def get(self, key: str, default: Any = None) -> Any:
        """Get an item from the configuration."""
        if not self.__contains__(key):
            return default
        return self.__getitem__(key)

    def __getitem__(self, key: str) -> Any:
        """Get an item from the configuration."""
        if not self.__contains__(key):
            raise KeyError(f"'{key}' not found in configuration.")
        return getattr(self, key)

    def __contains__(self, key: str) -> bool:
        """Check if an item exists in the configuration."""
        return not key.startswith("_") and hasattr(self, key)

    @staticmethod
    def _mask_sensitive_data(data: str) -> str:
        """Mask sensitive data for security in repr."""
        if len(data) <= 2:
            return "*" * len(data)
        unmasked_length = min(3, len(data) - 2)
        asterisks = "*" * (len(data) - unmasked_length)
        return f"{data[:unmasked_length]}{asterisks}"
