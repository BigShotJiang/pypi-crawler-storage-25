from pydantic import Field, field_validator

from data_exchange_agent.config.sections.task_sources.task_source import TaskSourceConfig


class ApiConfig(TaskSourceConfig):
    """Configuration class for API task source settings."""

    key: str = Field(..., description="API key for authentication")

    @field_validator("key")
    @classmethod
    def validate_key(cls, v: str) -> str:
        """Validate that API key contains only printable characters."""
        if not all(c.isprintable() for c in v):
            raise ValueError("API key contains invalid characters.")
        return v

    def __repr__(self) -> str:
        """Return string representation of API configuration."""
        return "ApiConfig(key='***')"
