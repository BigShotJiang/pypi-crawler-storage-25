"""Task source configuration module."""

from data_exchange_agent.config.sections.base_section_config import BaseSectionConfig


class TaskSourceConfig(BaseSectionConfig):
    """Base configuration class for task source settings."""

    pass
