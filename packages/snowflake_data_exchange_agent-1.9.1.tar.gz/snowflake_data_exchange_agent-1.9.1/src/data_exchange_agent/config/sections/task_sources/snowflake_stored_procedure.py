from pydantic import Field, field_validator

from data_exchange_agent.config.sections.task_sources.task_source import TaskSourceConfig
from data_exchange_agent.constants.connection_types import SPCS_CONNECTION_NAME


class SnowflakeStoredProcedureConfig(TaskSourceConfig):
    """Configuration class for Snowflake stored procedure task source settings."""

    connection_name: str = Field(
        ...,
        description='Connection name for Snowflake stored procedure, or "@SPCS_CONNECTION" to use SPCS-provided credentials',
    )

    @field_validator("connection_name")
    @classmethod
    def validate_connection_name(cls, v: str) -> str:
        """Validate the connection name."""
        # Allow the special SPCS connection name
        if v == SPCS_CONNECTION_NAME:
            return v

        if not all(c.isprintable() for c in v):
            raise ValueError("Connection name contains invalid characters.")
        return v

    def __repr__(self) -> str:
        """Return string representation of Snowflake stored procedure configuration."""
        return f"SnowflakeStoredProcedureConfig(connection_name='{self.connection_name}')"
