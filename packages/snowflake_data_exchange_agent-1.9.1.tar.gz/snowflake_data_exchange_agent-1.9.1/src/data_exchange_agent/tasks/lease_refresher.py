"""
Lease refresher for maintaining task leases.

This module provides the LeaseRefresher class which runs a background thread
to periodically refresh task leases by calling the REFRESH_LEASES stored procedure.
Optionally runs a per-tick callback (e.g. centralized task pull) on a shorter interval.
"""

import random
import threading
import time

from collections.abc import Callable

from dependency_injector.wiring import Provide, inject

from data_exchange_agent import custom_exceptions
from data_exchange_agent.config.manager import ConfigManager
from data_exchange_agent.constants import config_keys, container_keys
from data_exchange_agent.constants.config_defaults import (
    DEFAULT__APPLICATION__LEASE_REFRESH_INTERVAL,
    DEFAULT__APPLICATION__TASK_FETCH_INTERVAL,
)
from data_exchange_agent.data_sources.sf_connection import SnowflakeDataSource
from data_exchange_agent.snowflake_metadata_locations import (
    qualified_data_migration_metadata_schema,
)
from data_exchange_agent.utils.sf_logger import SFLogger
from snowflake.connector.errors import ProgrammingError


# Covers partial deployments where REFRESH_LEASES doesn't exist yet.
SF_UNKNOWN_FUNCTION_ERROR_CODE = 2141

_TICK_JITTER_MAX_SECONDS = 2.0


class LeaseRefresher:
    """
    Background thread that periodically refreshes task leases.

    This class ensures that tasks being processed by workers don't expire
    by periodically calling the REFRESH_LEASES stored procedure in Snowflake.

    Attributes:
        agent_id (str): Agent ID used to identify which leases to refresh
        refresh_interval (int): Interval in seconds between lease refresh calls
        _stop_event (threading.Event): Event to signal the thread to stop
        _thread (threading.Thread | None): The background refresh thread

    """

    REFRESH_LEASES_SP_NAME = "REFRESH_LEASES"

    @inject
    def __init__(
        self,
        logger: SFLogger = Provide[container_keys.SF_LOGGER],
        program_config: ConfigManager = Provide[container_keys.PROGRAM_CONFIG],
        snowflake_datasource: SnowflakeDataSource = Provide[container_keys.SF_DATA_SOURCE],
    ) -> None:
        """
        Initialize the LeaseRefresher.

        Args:
            logger: Logger instance for logging messages
            program_config: Program configuration containing connection and agent settings
            snowflake_datasource: Shared Snowflake datasource (thread-safe, uses thread-local connections)

        Raises:
            ConfigurationError: If required configuration is missing

        """
        self.logger = logger

        try:
            self.agent_id = program_config[config_keys.APPLICATION__AGENT_ID]
        except (KeyError, AttributeError) as e:
            raise custom_exceptions.ConfigurationError("Agent ID is missing or incomplete.") from e

        self.refresh_interval = program_config.get(
            config_keys.APPLICATION__LEASE_REFRESH_INTERVAL,
            DEFAULT__APPLICATION__LEASE_REFRESH_INTERVAL,
        )
        self._qualified_data_migration_metadata_schema = qualified_data_migration_metadata_schema(program_config)

        # Use the shared, thread-safe SnowflakeDataSource singleton.
        # The LeaseRefresher thread will get its own connection via thread-local storage.
        self.snowflake_datasource = snowflake_datasource
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._after_tick: Callable[[], None] | None = None
        self._tick_interval_seconds: float | None = None

    def start(
        self,
        after_tick: Callable[[], None] | None = None,
        tick_interval_seconds: float | None = None,
    ) -> None:
        """
        Start the lease refresh background thread.

        Creates and starts a daemon thread that will periodically refresh leases.
        If the thread is already running, this method does nothing.

        Args:
            after_tick: If set, invoked once per loop iteration after lease refresh
                scheduling (used for centralized task pull). When set,
                ``tick_interval_seconds`` controls how long the thread waits between
                iterations (plus jitter), defaulting to ``task_fetch_interval``.
            tick_interval_seconds: Base wait between iterations when ``after_tick`` is set.

        """
        if self._thread is not None and self._thread.is_alive():
            self.logger.warning("Lease refresher is already running.")
            return

        self._after_tick = after_tick
        if after_tick is not None:
            self._tick_interval_seconds = (
                float(tick_interval_seconds) if tick_interval_seconds is not None else float(DEFAULT__APPLICATION__TASK_FETCH_INTERVAL)
            )
        else:
            self._tick_interval_seconds = None

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._refresh_loop,
            daemon=True,
            name="LeaseRefresher",
        )
        self._thread.start()
        self.logger.info(f"Agent starting with UUID (consumer_id): {self.agent_id}")
        if self._after_tick is not None:
            self.logger.info(
                f"Lease refresher started (lease interval: {self.refresh_interval}s, "
                f"assigner tick base: {self._tick_interval_seconds}s)"
            )
        else:
            self.logger.info(f"Lease refresher started (interval: {self.refresh_interval}s)")

    def stop(self) -> None:
        """
        Stop the lease refresh background thread.

        Signals the background thread to stop and waits for it to finish.
        """
        if self._thread is None or not self._thread.is_alive():
            return

        self.logger.info("Stopping lease refresher...")
        self._stop_event.set()
        self._thread.join(timeout=5)

        if self._thread.is_alive():
            self.logger.warning("Lease refresher thread did not stop gracefully.")
        else:
            self.logger.info("Lease refresher stopped.")

        self._thread = None
        self._after_tick = None
        self._tick_interval_seconds = None

        # Close the Snowflake connection used by this thread
        self.snowflake_datasource.close_connection()

    def _refresh_loop(self) -> None:
        """
        Execute a loop that periodically refreshes leases.

        Without ``after_tick``: same as legacy behavior — refresh every
        ``refresh_interval``. With ``after_tick``: refresh when lease interval has
        elapsed, run the callback every iteration, then wait ``tick_interval`` (+ jitter).
        """
        if self._after_tick is None:
            while not self._stop_event.is_set():
                try:
                    self._refresh_leases()
                except Exception as e:
                    self.logger.error("Failed to refresh leases.", exception=e)

                self._stop_event.wait(timeout=self.refresh_interval)
            return

        last_lease_refresh: float | None = None
        tick_base = self._tick_interval_seconds or float(DEFAULT__APPLICATION__TASK_FETCH_INTERVAL)

        while not self._stop_event.is_set():
            now = time.monotonic()
            if last_lease_refresh is None or now - last_lease_refresh >= self.refresh_interval:
                try:
                    self._refresh_leases()
                except Exception as e:
                    self.logger.error("Failed to refresh leases.", exception=e)
                last_lease_refresh = now

            try:
                self._after_tick()
            except Exception as e:
                self.logger.error("Task assigner tick failed.", exception=e)

            wait_s = tick_base + random.uniform(0, _TICK_JITTER_MAX_SECONDS)
            self._stop_event.wait(timeout=wait_s)

    def _refresh_leases(self) -> None:
        """
        Call the REFRESH_LEASES stored procedure.

        This updates the leasing_time for all tasks currently leased to this agent,
        preventing them from being reclaimed by other agents.

        Uses a persistent connection to avoid the overhead of creating a new connection
        on each refresh cycle. The connection is only recreated if it's closed or fails.
        """
        qm = self._qualified_data_migration_metadata_schema
        refresh_statement = f"CALL {qm}.{self.REFRESH_LEASES_SP_NAME}(%s)"
        params = (self.agent_id,)

        try:
            # Ensure connection exists (creates one if closed or not yet established)
            if self.snowflake_datasource.is_closed():
                self.snowflake_datasource.create_connection()

            result = next(
                iter(self.snowflake_datasource.execute_statement(refresh_statement, params)),
                None,
            )
            if result:
                # The stored procedure returns a boolean indicating if any rows were updated
                leases_refreshed = result.get(self.REFRESH_LEASES_SP_NAME, False)
                if leases_refreshed:
                    self.logger.debug(f"Leases refreshed for agent '{self.agent_id}'")
                else:
                    self.logger.debug(f"No active leases found for agent '{self.agent_id}'")
        except ProgrammingError as e:
            if e.errno == SF_UNKNOWN_FUNCTION_ERROR_CODE:
                self.logger.warning("Stored procedure not found (schema may still be deploying). Will retry on next cycle.")
                return
            # Close the potentially broken connection so it gets recreated on the next attempt
            self.snowflake_datasource.close_connection()
            raise Exception(f"Failed to refresh leases executing statement: {refresh_statement}.") from e
        except Exception as e:
            # Close the potentially broken connection so it gets recreated on the next attempt
            self.snowflake_datasource.close_connection()
            raise Exception(f"Failed to refresh leases executing statement: {refresh_statement}.") from e
